from __future__ import annotations  # Python 3.6+ compatibility

from omnipkg.common_utils import safe_print

#!/usr/bin/env python3

"""
Flask Port Finder - Automatically finds available ports for Flask apps and patches app.run() calls to use them.

Features:
- Windows-compatible socket handling
- Concurrent-safe port allocation (prevents race conditions)
- Interactive mode with validation-only option
- Graceful shutdown handling
- Port reservation system

Usage:
1. Add this to the test execution wrapper
2. It will automatically patch Flask apps to use random available ports
"""

import atexit
import concurrent.futures
import os
import platform
import re
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from contextlib import closing
from pathlib import Path
from typing import Optional, Tuple
from omnipkg.i18n import _

try:
    from .common_utils import safe_print
except ImportError:
    try:
        pass
    except ImportError:

        def safe_print(*args, **kwargs):
            try:
                print(*args, **kwargs)
            except (UnicodeEncodeError, UnicodeDecodeError):
                msg = " ".join(str(arg).encode("ascii", "replace").decode("ascii") for arg in args)
                print(msg, **kwargs)


# Global port reservation system (thread-safe)
_port_lock = threading.Lock()
_reserved_ports = set()
_port_pids = {}  # Track which PID owns which port


def is_windows():
    """Check if running on Windows."""
    return platform.system() == "Windows" or sys.platform == "win32"


def reserve_port(port: int, duration: float = 5.0) -> bool:
    """
    Reserve a port to prevent concurrent allocation race conditions.
    """
    with _port_lock:
        if port in _reserved_ports:
            return False
        _reserved_ports.add(port)
        _port_pids[port] = os.getpid()

    def release_later():
        time.sleep(duration)
        release_port(port)

    threading.Thread(target=release_later, daemon=True).start()
    return True


def release_port(port: int):
    """Release a reserved port."""
    with _port_lock:
        _reserved_ports.discard(port)
        _port_pids.pop(port, None)


def is_port_actually_free(port: int) -> bool:
    """
    Double-check if a port is actually free (not just unreserved).
    NOTE: Do NOT set SO_REUSEADDR here — on Linux it allows double-binds,
    making already-bound ports falsely appear free.
    """
    try:
        if is_windows():
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                sock.bind(("127.0.0.1", port))
                sock.close()
                return True
            except OSError:
                sock.close()
                return False
        else:
            with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
                sock.bind(("127.0.0.1", port))
                return True
    except OSError:
        return False
    except Exception:
        return False


def find_free_port(start_port=5000, max_attempts=100, reserve=True) -> int:
    """
    Find an available port with concurrent safety.
    The reservation check-and-set must be atomic inside the lock to prevent
    the TOCTOU race where multiple threads pass the free check simultaneously.
    """
    for port in range(start_port, start_port + max_attempts):
        with _port_lock:
            if port in _reserved_ports:
                continue
            if not is_port_actually_free(port):
                continue
            if reserve:
                _reserved_ports.add(port)
                _port_pids[port] = os.getpid()

                def _release_later(p=port):
                    time.sleep(10.0)
                    release_port(p)

                threading.Thread(target=_release_later, daemon=True).start()
            return port

    raise RuntimeError(
        f"Could not find free port in range {start_port}-{start_port + max_attempts}"
    )


def validate_flask_app(code: str, port: int, timeout: float = 5.0) -> bool:
    """
    Validate Flask app can start without actually running it persistently.
    Uses Flask's test client for validation instead of real server.
    """
    # CRITICAL FIX: Set __name__ to something NOT '__main__'
    # This prevents app.run() from blocking inside the validation step!
    validation_code = f"""
import sys
try:
    from .common_utils import safe_print
except ImportError:
    from omnipkg.common_utils import safe_print
app_code = {repr(code)}
# SAFETY: Prevent app.run() from executing by changing __name__
exec_globals = {{'__name__': '__omnipkg_validation__'}}
try:
    exec(app_code, exec_globals)
except Exception as e:
    print(f"EXEC_ERROR: {{e}}", file=sys.stderr)
    sys.exit(1)

app = exec_globals.get('app')
if app is None:
    # Fallback: try to find any Flask instance
    from flask import Flask
    for val in exec_globals.values():
        if isinstance(val, Flask):
            app = val
            break

if app is None:
    print("ERROR: No Flask app found", file=sys.stderr)
    sys.exit(1)

try:
    # Use test client to verify app structure without binding port
    with app.test_client() as client:
        # Just checking we can create the client is often enough,
        # but we can try a 404 check to ensure routing works
        response = client.get('/_omnipkg_health_check')
        print(f"VALIDATION_SUCCESS: App validated")
        sys.exit(0)
except Exception as e:
    print(f"VALIDATION_ERROR: {{e}}", file=sys.stderr)
    sys.exit(1)
"""

    try:
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"] = "1"
        result = subprocess.run(
            [sys.executable, "-c", validation_code],
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=timeout,
            env=env,
        )

        if result.returncode == 0 and "VALIDATION_SUCCESS" in result.stdout:
            return True

        # Only print stderr if validation failed to keep logs clean on success
        if result.stderr:
            safe_print(_('Flask validation failed details: {}').format(result.stderr.strip()))
        return False
    except subprocess.TimeoutExpired:
        safe_print(f"Flask validation timed out after {timeout}s")
        return False
    except Exception as e:
        safe_print(_('Flask validation error: {}').format(e))
        return False


class FlaskAppManager:
    """
    Manages Flask app lifecycle with graceful shutdown support.
    """

    def __init__(self, code: str, port: int, validate_only: bool = False):
        self.code = code
        self.port = port
        self.validate_only = validate_only
        self.process: Optional[subprocess.Popen] = None
        self.is_running = False
        self.shutdown_file = Path(tempfile.gettempdir()).resolve() / f"flask_shutdown_{port}.signal"

        if self.shutdown_file.exists():
            self.shutdown_file.unlink()

        atexit.register(self.shutdown)

    def start(self) -> bool:
        """Start the Flask app (or just validate it)."""
        if self.validate_only:
            safe_print(_('🔍 Validating Flask app on port {}...').format(self.port))
            return validate_flask_app(self.code, self.port)

        # Use forward slashes / raw string to avoid backslash corruption on Windows
        _shutdown_file_str = str(self.shutdown_file).replace("\\", "/")
        wrapper_code = f"""
import signal
import sys
import time
from pathlib import Path
shutdown_file = Path(r"{self.shutdown_file}")

def check_shutdown_signal(signum=None, frame=None):
    if shutdown_file.exists():
        # safe_print("\\n🛑 Shutdown signal received, stopping Flask app...")
        sys.exit(0)

signal.signal(signal.SIGTERM, check_shutdown_signal)
if hasattr(signal, 'SIGBREAK'):  # Windows
    signal.signal(signal.SIGBREAK, check_shutdown_signal)

import threading
def periodic_check():
    while True:
        time.sleep(0.5)
        check_shutdown_signal()

threading.Thread(target=periodic_check, daemon=True).start()

{self.code}
"""

        try:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, encoding="utf-8") as f:
                f.write(wrapper_code)
                temp_file = f.name

            popen_env = os.environ.copy()
            popen_env["PYTHONIOENCODING"] = "utf-8"
            popen_env["PYTHONUTF8"] = "1"
            # Use DEVNULL not PIPE — on Windows unread PIPE buffers block the process
            self.process = subprocess.Popen(
                [sys.executable, temp_file],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                env=popen_env,
            )

            self.is_running = True
            safe_print(_('✅ Flask app started on port {} (PID: {})').format(self.port, self.process.pid))
            safe_print(_('🌐 Access at: http://127.0.0.1:{}').format(self.port))
            safe_print(_('🛑 To stop: FlaskAppManager.shutdown() or delete {}').format(self.shutdown_file))

            return True
        except Exception as e:
            safe_print(_('❌ Failed to start Flask app: {}').format(e))
            return False

    def shutdown(self):
        """Gracefully shutdown the Flask app."""
        if not self.is_running and self.process is None:
            if not self.validate_only:
                safe_print("✅ No active process to shutdown")
            if self.shutdown_file.exists():
                try:
                    self.shutdown_file.unlink()
                except OSError:
                    pass
            release_port(self.port)
            return

        if self.process is None:
            # Still clean up shutdown file even if no process (validate_only mode)
            if self.shutdown_file.exists():
                try:
                    self.shutdown_file.unlink()
                except OSError:
                    pass
            release_port(self.port)
            return

        try:
            self.shutdown_file.write_text("SHUTDOWN")
            try:
                self.process.wait(timeout=3.0)
                safe_print(_('✅ Flask app (PID {}) shut down gracefully').format(self.process.pid))
            except subprocess.TimeoutExpired:
                self.process.terminate()
                try:
                    self.process.wait(timeout=2.0)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                safe_print(_('⚠️  Flask app (PID {}) force killed').format(self.process.pid))

            if self.shutdown_file.exists():
                self.shutdown_file.unlink()

            release_port(self.port)
            self.is_running = False
        except Exception as e:
            safe_print(_('⚠️  Error during shutdown: {}').format(e))
            release_port(self.port)  # Always release port

    def wait_for_ready(self, timeout: float = 10.0) -> bool:
        """Wait for Flask app to be ready to accept connections."""
        import sys as _sys
        start_time = time.time()
        while time.time() - start_time < timeout:
            # Check if process died early — no point waiting if it crashed
            if self.process is not None and self.process.poll() is not None:
                safe_print(_('⚠️  Flask process exited early with code {}').format(self.process.returncode))
                return False
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                    sock.settimeout(0.5)
                    result = sock.connect_ex(("127.0.0.1", self.port))
                    if result == 0:
                        safe_print(_('✅ Flask app is ready on port {}').format(self.port))
                        return True
            except Exception:
                pass
            time.sleep(0.2)

        safe_print(_('⚠️  Flask app did not become ready within {}s').format(timeout))
        # Log process state for debugging
        if self.process is not None:
            code = self.process.poll()
            safe_print(f'   Process returncode: {code} (None=still running)')
        return False


def patch_flask_code(
    code: str, interactive: bool = False, validate_only: bool = False, port: int = None
) -> Tuple[str, int, Optional[FlaskAppManager]]:
    """
    Patch Flask code to use an available port with optional interactive mode.

    Args:
        code: Python source code containing Flask app
        interactive: If True, returns a FlaskAppManager for controlled execution
        validate_only: If True (with interactive), only validates without running
        port: If provided, use this port instead of finding a new one

    Returns:
        Tuple of (patched_code, port_number, optional_manager)
    """
    free_port = port if port is not None else find_free_port(reserve=True)
    pattern = r"app\.run\s*\([^)]*\)"

    if not re.search(pattern, code):
        patched_code = code
    else:
        # CRITICAL FIX: Always inject use_reloader=False to ensure process management works
        # The reloader spawns a child process that is hard to kill cleanly via Popen.
        patched_code = re.sub(
            pattern, _('app.run(port={}, debug=False, use_reloader=False)').format(free_port), code
        )

    manager = FlaskAppManager(patched_code, free_port, validate_only) if interactive else None
    return patched_code, free_port, manager


def auto_patch_flask_port(code: str, interactive: bool = False, validate_only: bool = False) -> str:
    """
    Automatically patch Flask code to use an available port.
    """
    if "flask" in code.lower() and re.search(r"app\.run\s*\(", code):
        patched_code, port, manager = patch_flask_code(code, interactive, validate_only)

        if manager:
            success = manager.start()
            if success and validate_only:
                # Silent success for validation to keep logs clean
                pass
            elif success and not validate_only:
                safe_print(_('🔧 Flask app running on port {}').format(port))
            else:
                safe_print("❌ Flask app failed to start/validate")
        else:
            safe_print(_('🔧 Auto-patched Flask app to use port {}').format(port), file=sys.stderr)

        return patched_code
    return code


if __name__ == "__main__":

    class TestEnhancedFlaskPortFinder(unittest.TestCase):
        def test_1_basic_port_allocation(self):
            port = find_free_port(reserve=False)
            self.assertTrue(5000 <= port < 5100, "Port should be in expected range")
            safe_print(_('✅ Found and reserved free port: {}').format(port))
            self.assertTrue(True)

        def test_2_concurrent_allocation(self):
            def allocate_port(thread_id):
                port = find_free_port(reserve=True)
                time.sleep(0.05)
                release_port(port)
                return port

            with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                futures = [executor.submit(allocate_port, i) for i in range(10)]
                ports = [f.result() for f in concurrent.futures.as_completed(futures)]

            self.assertEqual(len(ports), len(set(ports)), "Ports should be unique")
            safe_print(_('✅ All {} ports unique: {}').format(len(ports), sorted(ports)))
            self.assertTrue(True)

        def test_3_windows_compatibility(self):
            port = find_free_port(reserve=False)
            safe_print(_('✅ Port {} found, demonstrating platform-agnostic socket operations.').format(port))
            self.assertTrue(True)

        def test_4_flask_validation(self):
            valid_app = """
from flask import Flask
app = Flask(__name__)

@app.route('/')
def hello():
    return 'Hello World!'
            """
            # Note: validate_flask_app logic now prevents app.run() from executing automatically
            # so we don't need to worry about it hanging here.
            port = find_free_port(reserve=True)
            success = validate_flask_app(valid_app, port)
            self.assertTrue(success, "Valid app should pass validation")
            safe_print(_('🔍 Validating Flask app on port {}...').format(port))
            safe_print("  ✅ Valid app correctly passed validation.")
            release_port(port)

        def test_5_patch_flask_code(self):
            original_code = """
from flask import Flask
app = Flask(__name__)

@app.route('/')
def home():
    return 'Test'

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
            """
            patched_code, port, changes_made = patch_flask_code(original_code, interactive=True)
            self.assertIn(f"port={port}", patched_code)
            self.assertIn("debug=False", patched_code)
            self.assertIn("use_reloader=False", patched_code)
            safe_print(_('✅ Code patched successfully to use port {}.').format(port))
            release_port(port)

        def test_6_flask_manager_lifecycle(self):
            test_app = """
from flask import Flask
app = Flask(__name__)

@app.route('/')
def index():
    return 'Lifecycle Test'

if __name__ == '__main__':
    app.run()
            """
            port = find_free_port(start_port=5000, max_attempts=100, reserve=True)
            patched_code, port, manager = patch_flask_code(test_app, interactive=True)
            safe_print(f"  ✅ Manager created for port {port}.")

            success = manager.start()
            self.assertTrue(success, "Manager start should succeed")

            if not manager.validate_only:
                safe_print(_('✅ Flask app started on port {} (PID: {})').format(port, manager.process.pid))
                safe_print(_('🌐 Access at: http://127.0.0.1:{}').format(port))
                safe_print(
                    _('🛑 To stop: FlaskAppManager.shutdown() or delete {}').format(manager.shutdown_file)
                )

                # Wait longer for CI
                self.assertTrue(manager.wait_for_ready(timeout=15.0), "App should be ready")
                safe_print("✅ Server is ready and listening.")
                manager.shutdown()
            else:
                safe_print("  ✅ Validation-only mode passed")

            manager.shutdown()
            self.assertTrue(is_port_actually_free(port), "Port should be released")
            safe_print("✅ TEST 6 PASSED")

    suite = unittest.TestLoader().loadTestsFromTestCase(TestEnhancedFlaskPortFinder)
    unittest.TextTestRunner(verbosity=2).run(suite)
