# mcp-canada

MCP server providing AI agents with structured access to Canadian federal government data.

**Status:** Under active development. Coming soon.

~90 tools across 7 no-auth federal APIs:
- Bank of Canada (exchange rates, interest rates, inflation)
- Open Parliament (bills, MPs, votes, Hansard)
- Recalls & Safety Alerts (food, vehicles, health products)
- MSC Weather (conditions, forecasts, climate, hydro)
- Drug Product Database (medications, ingredients, schedules)
- CKAN Open Data (80,000+ federal datasets)
- Canadian Nutrient File (food nutrition data)

Built with [FastMCP](https://github.com/jlowin/fastmcp) + Python 3.12.

By [Reyem Tech](https://reyem.tech).
