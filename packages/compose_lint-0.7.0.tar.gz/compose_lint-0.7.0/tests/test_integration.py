"""Integration tests: full CLI against multi-issue compose files."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

FIXTURES = Path(__file__).parent / "compose_files"


def run_cli(*args: str) -> subprocess.CompletedProcess[str]:
    """Run compose-lint CLI as a subprocess."""
    return subprocess.run(
        [sys.executable, "-m", "compose_lint", *args],
        capture_output=True,
        text=True,
    )


class TestIntegration:
    """End-to-end tests against mixed.yml."""

    def test_mixed_file_finds_multiple_issues(self) -> None:
        result = run_cli(str(FIXTURES / "mixed.yml"))
        assert result.returncode == 1
        assert "CL-0001" in result.stdout
        assert "CL-0002" in result.stdout
        assert "CL-0003" in result.stdout
        assert "CL-0004" in result.stdout
        assert "CL-0005" in result.stdout

    def test_mixed_file_json_output(self) -> None:
        result = run_cli("--format", "json", str(FIXTURES / "mixed.yml"))
        assert result.returncode == 1
        data = json.loads(result.stdout)
        assert isinstance(data, list)
        assert len(data) > 5

        rule_ids = {f["rule_id"] for f in data}
        assert "CL-0001" in rule_ids
        assert "CL-0002" in rule_ids

        for finding in data:
            assert "file" in finding
            assert "rule_id" in finding
            assert "severity" in finding
            assert "service" in finding
            assert "message" in finding
            assert "fix" in finding
            assert "references" in finding

    def test_mixed_file_fail_on_critical(self) -> None:
        result = run_cli(
            "--fail-on",
            "critical",
            str(FIXTURES / "mixed.yml"),
        )
        assert result.returncode == 1

    def test_clean_file_exits_zero(self) -> None:
        result = run_cli(str(FIXTURES / "valid_basic.yml"))
        assert result.returncode == 0

    def test_self_hosted_fixture_lints_clean_at_low_threshold(self) -> None:
        # The hardened compose-lint-runs-compose-lint configuration in the
        # README must produce zero findings across every rule. Asserting
        # at --fail-on low makes any new rule that fires on it a release
        # blocker — i.e. compose-lint must always be able to dogfood.
        result = run_cli("--fail-on", "low", str(FIXTURES / "safe_self_hosted.yml"))
        assert result.returncode == 0, result.stdout + result.stderr

    def test_medium_only_exits_zero_by_default(self) -> None:
        """Medium findings alone should not cause exit 1 with default --fail-on high."""
        result = run_cli(str(FIXTURES / "warnings_only.yml"))
        assert result.returncode == 0
        assert "MEDIUM" in result.stdout
        assert "HIGH" not in result.stdout
        assert "CRITICAL" not in result.stdout

    def test_medium_only_exits_one_with_fail_on_medium(self) -> None:
        """--fail-on medium should cause exit 1 when medium findings are present."""
        result = run_cli("--fail-on", "medium", str(FIXTURES / "warnings_only.yml"))
        assert result.returncode == 1

    def test_medium_only_exits_zero_with_fail_on_critical(self) -> None:
        """Medium-only file exits 0 even with --fail-on critical."""
        result = run_cli(
            "--fail-on",
            "critical",
            str(FIXTURES / "warnings_only.yml"),
        )
        assert result.returncode == 0

    def test_secure_db_not_flagged_for_ports(self) -> None:
        result = run_cli("--format", "json", str(FIXTURES / "mixed.yml"))
        data = json.loads(result.stdout)
        db_port_findings = [
            f for f in data if f["service"] == "db" and f["rule_id"] == "CL-0005"
        ]
        assert len(db_port_findings) == 0

    def test_suppressed_findings_shown_by_default(self) -> None:
        """Disabled rules produce SUPPRESSED findings in output."""
        config = str(FIXTURES / "suppress_config.yml")
        result = run_cli("--config", config, str(FIXTURES / "mixed.yml"))
        assert "SUPPRESSED" in result.stdout
        assert "SEC-1234" in result.stdout
        assert "suppressed" in result.stdout.lower()

    def test_suppressed_findings_in_json(self) -> None:
        """JSON output includes suppressed field and reason."""
        config = str(FIXTURES / "suppress_config.yml")
        result = run_cli(
            "--format", "json", "--config", config, str(FIXTURES / "mixed.yml")
        )
        data = json.loads(result.stdout)
        suppressed = [f for f in data if f.get("suppressed")]
        assert len(suppressed) > 0
        with_reason = [f for f in suppressed if f.get("suppression_reason")]
        assert any("SEC-1234" in f["suppression_reason"] for f in with_reason)

    def test_suppressed_findings_do_not_affect_exit_code(self) -> None:
        """Suppressed findings should not cause exit 1."""
        config = str(FIXTURES / "suppress_config.yml")
        result = run_cli("--config", config, str(FIXTURES / "warnings_only.yml"))
        assert result.returncode == 0

    def test_skip_suppressed_hides_findings(self) -> None:
        """--skip-suppressed removes suppressed findings from output."""
        config = str(FIXTURES / "suppress_config.yml")
        result = run_cli(
            "--skip-suppressed", "--config", config, str(FIXTURES / "mixed.yml")
        )
        assert "SUPPRESSED" not in result.stdout

    def test_skip_suppressed_json(self) -> None:
        """--skip-suppressed removes suppressed findings from JSON output."""
        config = str(FIXTURES / "suppress_config.yml")
        result = run_cli(
            "--format",
            "json",
            "--skip-suppressed",
            "--config",
            config,
            str(FIXTURES / "mixed.yml"),
        )
        data = json.loads(result.stdout)
        suppressed = [f for f in data if f.get("suppressed")]
        assert len(suppressed) == 0

    def test_suppressed_findings_in_sarif(self) -> None:
        """SARIF output uses native suppressions array."""
        config = str(FIXTURES / "suppress_config.yml")
        result = run_cli(
            "--format", "sarif", "--config", config, str(FIXTURES / "mixed.yml")
        )
        sarif = json.loads(result.stdout)
        results = sarif["runs"][0]["results"]
        suppressed = [r for r in results if "suppressions" in r]
        assert len(suppressed) > 0
        assert suppressed[0]["suppressions"][0]["kind"] == "external"

    def test_multiple_files(self) -> None:
        result = run_cli(
            "--format",
            "json",
            str(FIXTURES / "mixed.yml"),
            str(FIXTURES / "valid_basic.yml"),
        )
        data = json.loads(result.stdout)
        files = {f["file"] for f in data}
        assert len(files) >= 1
