from qmars._internal.settings import (
	global_settings
)

from qmars._internal.classic_prop.syntax import (
	Boolean,
	Proposition,
	AND,
	FALSE,
	IFF,
	IMPLIES,
	LEFTARROW,
	NAND,
	NOR,
	NOT,
	OR,
	RIGHTARROW,
	TRUE,
	XNOR,
	XOR,
)

from qmars._internal.classic_prop.model import (
	Interpretation,
)
