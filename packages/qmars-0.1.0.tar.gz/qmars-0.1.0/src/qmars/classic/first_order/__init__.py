from qmars._internal.settings import (
	global_settings
)

# from qmars._internal.util import (
# 	debug_print,
# )

from qmars._internal.classic_fo.syntax import (
	Boolean,
	ConstSymbol,
	FiniteObject,
	Formula,
	FormulaLikeCallable,
	FormulaLikePluggable,
	FuncSymbol,
	OpSymbol,
	PredSymbol,
	Sort,
	Statement,
	Term,
	TermLikeCallable,
	TermLikePluggable,
	Variable,
	AND,
	EQ,
	EQUALS,
	FALSE,
	IFF,
	IMPLIES,
	LEFTARROW,
	NAND,
	NEQ,
	NOR,
	NOT,
	OR,
	RIGHTARROW,
	TRUE,
	XNOR,
	XOR,
)

from qmars._internal.classic_fo.var import (
	exists,
	forall,
	formula,
	inputvar,
	statement,
	such_that,
	term,
)

from qmars._internal.classic_fo.model import (
	FiniteModel,
)
