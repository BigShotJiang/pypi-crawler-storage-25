from __future__ import annotations

from collections.abc import Callable
from copy import deepcopy
from enum import Enum
from functools import cache
from typing import Any, ClassVar, Protocol, Sequence, Union, cast


from qmars._internal.errors import TokenError, UsageError, assert_arity, assert_type



class BaseType:
	_created	: ClassVar[dict[int, BaseType]] = {}
	_runid		: int
	
	def __init__(self) -> None:
		self._runid = len(BaseType._created)
		BaseType._created[self._runid] = self
	
	def copy[_Cls : BaseType](self : _Cls) -> _Cls:
		dc = deepcopy(self)
		dc._runid = len(BaseType._created)
		BaseType._created[dc._runid] = dc
		return dc
	
	def __repr__(self) -> str:
		if hasattr(self, 'name'):
			if getattr(self, 'name') == None:
				self_name = ""
			else:
				self_name = " " + repr(getattr(self, 'name'))
		else:
			self_name = ""
		if hasattr(self, 'name_ascii'):
			if getattr(self, 'name_ascii') == None:
				self_name_ascii = ""
			else:
				self_name_ascii = " (" + repr(getattr(self, 'name_ascii')) + ")"
		else:
			self_name_ascii = ""
		return f"<{self.__class__.__name__}{self_name}{self_name_ascii} runid={self._runid}>"



class Composable(Protocol):
	def compose(self,
	 			*,
				others : Union[
					Composable,
					Sequence[Composable],
				],
				new_arity : int | None,
			) -> Composable: ...


class Token(BaseType):
	names		: ClassVar[set[str]] = set()

	name		: str
	name_ascii	: str | None
	info		: Any
	
	@classmethod
	def add_token(cls, token : Token) -> None:
		if token.name in Token.names:
			msg = f'A token with name "{token.name}" already exists'
			raise TokenError(msg)
		Token.names.add(token.name)
	
	@classmethod
	def remove_token(cls, token : Token) -> None:
		if token.name not in Token.names:
			msg = f'No token with name "{token.name}" found'
			raise TokenError(msg)
		Token.names.remove(token.name)
	
	def __init__(self,
				*,
				name : str,
				name_ascii : str | None = None,
				info : Any = None,
			) -> None:
		super().__init__()
		self.name		= name
		self.name_ascii	= name_ascii
		self.info		= info
		Token.add_token(self)
	
	def compose(
				self : Composable,
				*,
				others : Union[
					Composable,
					Sequence[Composable],
				],
				new_arity : int | None,
			) -> PendMap:
		
		others_tych : list[Token | PendMap] = []
		
		try:
			if isinstance(others, Token | PendMap):
				others_tych = [others]
			else:
				assert isinstance(others, Sequence)
				for other in others:
					assert isinstance(other, Token | PendMap)
					others_tych.append(other)
		except AssertionError:
			raise TypeError
		
		
		others_inclass : type | None = None
		others_outclass : type | None = None
		for other in others_tych:
			if not isinstance(other, Token | PendMap):
				raise TypeError
			if isinstance(other, PendMap):
				assert_type(want=others_inclass, got=other._inclass, symmetric_none=True)
				if others_inclass == None:
					others_inclass = other._inclass
				assert_type(want=others_outclass, got=other._outclass, symmetric_none=True)
				if others_outclass == None:
					others_outclass = other._outclass
				assert_arity(want=new_arity, got=other.arity, symmetric_none=True)
				if new_arity == None:
					new_arity = other.arity
		
		return PendMap(
			inclass=others_inclass,
			midclass=others_outclass,
			outclass=None,
			arity=new_arity,
			root=self,
			args=others_tych,
		)




class FoundationTokenEnum(Enum):
	NONE		= Token(name="FOUNDATION_NONE")
	PI_OUT		= Token(name="FOUNDATION_PI_OUT")
	MIRROR_K	= Token(name="FOUNDATION_MIRROR_K")




class ObjectType[_VAL](BaseType):
	value	: _VAL


class SymbolType(BaseType):
	names		: ClassVar[set[str]] = set()
	def __init__(self) -> None:
		super().__init__()

class VariableType(BaseType):
	underlying	: Token

	def __init__(self) -> None:
		super().__init__()
		self.underlying = Token(name=f"[token for runid={self._runid}]")
	



class MakeMap[
		_In : BaseType,
		_Out : BaseType,
	](BaseType):

	_itpt_for	: int
	name		: str
	arity		: int | None
	make		: Callable[[*tuple[_In,...]], _Out]
	_inclass	: type[_In] | None
	_outclass	: type[_Out] | None
	
	def __init__(self,
				*,
				itpt_for : int,
				name : str,
				inclass : type[_In] | None,
				outclass : type[_Out] | None,
				arity : int | None,
				make : Callable[[*tuple[_In,...]], _Out],
			) -> None:
		super().__init__()
		# if inclass == None:
		# 	assert arity == 0
		self._itpt_for	= itpt_for
		self.name		= name
		self._inclass	= inclass
		self._outclass	= outclass
		self.arity		= arity
		self.make		= make


	def make_compose[
				_Pre : BaseType,
			](self,
				others : Union[
							MakeMap[_Pre, _In],
							Sequence[
									MakeMap[_Pre, _In],
							],
						],
			) -> MakeMap[_Pre, _Out]:
		
		if isinstance(others, MakeMap):
			others = [others]
		elif isinstance(others, Sequence):
			others = list(others)
			for other in others:
				if not isinstance(other, MakeMap):
					raise TypeError
		else:
			raise TypeError
		assert_arity(want=self.arity, got=len(others), symmetric_none=True)
		# if self.arity == 0:
		# 	msg = "Cannot perform compose when the second argument is an empty sequence"
		# 	raise UsageError(msg)
		arity_constraint : int | None = None
		for other in others:
			if arity_constraint == None:
				arity_constraint = other.arity
			else:
				assert_arity(want=arity_constraint, got=other.arity, symmetric_none=True)
				
		# others_makemap : list[MakeMap[_Pre, _In]] = []

		def new_make(*args : _Pre) -> _Out:
			new_args : list[_In] = [
				other.make(*args)
				for other in others
			]
			return self.make(*new_args)
		
		root_runid = self._runid
		others_runid = '; '.join([
			repr(other._runid)
			for other in others
		])
		return MakeMap[_Pre, _Out](
			itpt_for=self._runid,
			name=f"<MakeMap root=[{root_runid}] args=[{others_runid}]>",
			inclass = others[0]._inclass if len(others) > 0 else None,
			outclass = self._outclass,
			arity = arity_constraint,
			make = new_make,
		)
	
	def __call__(self,
			*args : _In,
			) -> _Out:
		assert_arity(want=self.arity, got=len(args), symmetric_none=False)
		return self.make(*args)





class PendMap[
		_In : BaseType,
		_Out : BaseType,
	](BaseType):
	
	name		: str | None = None
	name_ascii	: str | None = None
	arity		: int | None
	root		: Union[
						PendMap[BaseType, _Out],
						Token,
					]
	args		: list[Union[
						PendMap[_In, BaseType],
						Token,
					]]
	_inclass	: type[_In] | None
	_midclass	: type[BaseType] | None
	_outclass	: type[_Out] | None

	def __init__(self,
				*,
				inclass : type[_In] | None,
				midclass : type[BaseType] | None,
				outclass : type[_Out] | None,
				arity : int | None,
				root : Composable,
				args : Sequence[Union[
							Composable,
							int,
						]],
			) -> None:
		
		super().__init__()
		
		if isinstance(root, PendMap):
			assert_type(want=root._inclass, got=midclass, symmetric_none=True)
			assert_type(want=root._outclass, got=outclass, symmetric_none=True)
		elif isinstance(root, Token):
			pass
		else:
			raise TypeError
		for arg in args:
			if isinstance(arg, int):
				if arity != None:
					assert arg in range(arity)
			elif isinstance(arg, PendMap):
				assert_type(want=inclass, got=arg._inclass, symmetric_none=True)
				assert_type(want=midclass, got=arg._outclass, symmetric_none=True)
				assert_arity(want=arity, got=arg.arity, symmetric_none=True)
			elif isinstance(arg, Token):
				pass
			else:
				raise TypeError
		
		self._inclass	= inclass
		self._midclass	= midclass
		self._outclass	= outclass
		self.arity		= arity
		self.root		= root
		self.args		= []
		
		for arg in args:
			if isinstance(arg, int):
				assert_type(want=midclass, got=inclass, symmetric_none=True)
				pi = pi_pendmap(
					inclass=inclass,
					n=arity,
					k=arg
				)
				self.args.append(pi)
			elif isinstance(arg, PendMap):
				assert_type(want=midclass, got=arg._outclass, symmetric_none=True)
				self.args.append(arg)
			elif isinstance(arg, Token):
				self.args.append(arg)
			else:
				raise TypeError


	def compose[
				_Pre : BaseType,
			](self,
				*,
				others : Union[
							Composable,
							Sequence[
									Composable,
							]
						],
				new_arity : int | None,
			) -> PendMap[_Pre, _Out]:
		
		others_tych : list[Token | PendMap[_Pre, _In]] = []

		try:
			if isinstance(others, Token | PendMap):
				others_tych = [others]
			else:
				assert isinstance(others, Sequence)
				for other in others:
					assert isinstance(other, Token | PendMap)
					others_tych.append(other)
		except AssertionError:
			raise TypeError

		others_inclass : type[_Pre] | None = None
		others_outclass : type[_In] | None = None
		for other in others_tych:
			if not isinstance(other, Token | PendMap):
				raise TypeError
			if isinstance(other, PendMap):
				assert_type(want=others_inclass, got=other._inclass, symmetric_none=True)
				if others_inclass == None:
					others_inclass = other._inclass
				assert_type(want=others_outclass, got=other._outclass, symmetric_none=True)
				if others_outclass == None:
					others_outclass = other._outclass
				assert_arity(want=new_arity, got=other.arity, symmetric_none=True)
				if new_arity == None:
					new_arity = other.arity
		
		assert_type(want=self._inclass, got=others_outclass, symmetric_none=True)
			
		return PendMap[_Pre, _Out](
			inclass=others_inclass,
			midclass=others_outclass,
			outclass=self._outclass,
			arity=new_arity,
			root=self,
			args=others_tych,
		)


	def fill(self,
				*,
				where : int,
				with_what : Token,
			) -> PendMap[_In, _Out]:
		
		assert self.arity != None
		assert isinstance(where, int) and 0 <= where < self.arity

		new_args : list[PendMap[_In, _In] | Token] = []
		for idx in range(self.arity):
			if idx < where:
				pi = pi_pendmap(
					inclass=self._inclass,
					n=self.arity-1,
					k=idx,
				)
				new_args.append(pi)
			elif idx == where:
				new_args.append(with_what)
			else:
				pi = pi_pendmap(
					inclass=self._inclass,
					n=self.arity-1,
					k=idx-1,
				)
				new_args.append(pi)

		return PendMap[_In, _Out](
			inclass=self._inclass,
			midclass=self._inclass,
			outclass=self._outclass,
			arity=self.arity-1,
			root=self,
			args=new_args,
		)




@cache
def pi_pendmap[
			_In : BaseType,
		](
			*,
			inclass : type[_In] | None,
			n : int | None,
			k : int,
		) -> PendMap[_In, _In]:
	'''Returns a map which takes n arguments and returns the k-th (zero-indexed!!!) argument.'''
	if n != None:
		effective_n = n
	else:
		effective_n = k + 1
	return PendMap[_In, _In](
		inclass=inclass,
		midclass=None,
		outclass=inclass,
		arity=n,
		root=FoundationTokenEnum.PI_OUT.value,
		args=[
			FoundationTokenEnum.MIRROR_K.value if i == k else FoundationTokenEnum.NONE.value
			for i in range(effective_n)
		]
	)

