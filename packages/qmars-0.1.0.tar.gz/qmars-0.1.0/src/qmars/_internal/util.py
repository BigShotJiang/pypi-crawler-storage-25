from typing import Any, Iterable

from qmars._internal import foundation as fond
from qmars._internal.settings import Settings, global_settings



def get_name(
			unicode_name : str,
			ascii_name : str | None = None,
			# *,
			settings : Settings | None = None
		) -> str:
	if settings == None:
		settings = global_settings
	settings._display_allow_unicode.cite()
	if settings._display_allow_unicode.get():
		return unicode_name
	if ascii_name != None:
		return ascii_name
	elif unicode_name.isascii():
		return unicode_name
	else:
		return ascii(unicode_name)




def gather_runid(
			*,
			thing : Any = None,
			# all_created : list,
		) -> dict[int, Any]:
	
	runid_dict : dict[int, Any] = {}

	if thing == None:
		for runid, bt in fond.BaseType._created.items():
		# for creature in all_created:
			runid_dict[runid] = bt
		return runid_dict
	
	if hasattr(thing, "_runid"):
		runid_dict[thing._runid] = thing
	if hasattr(thing, "root"):
		runid_dict |= gather_runid(thing=thing.root)
		# runid_dict |= gather_runid(thing=thing.root, all_created=all_created)
	if hasattr(thing, "args") and isinstance(thing.args, Iterable):
		for arg in thing.args:
			runid_dict |= gather_runid(thing=arg)
			# runid_dict |= gather_runid(thing=arg, all_created=all_created)
	if hasattr(thing, "underlying"):
		runid_dict |= gather_runid(thing=thing.underlying)
		# runid_dict |= gather_runid(thing=thing.underlying, all_created=all_created)
	
	return runid_dict



def debug_print(
			# *,
			thing : Any = None,
			# all_created : list,
		) -> None:
	
	runid_dict = gather_runid(thing=thing)
	# runid_dict = gather_runid(thing=thing, all_created=all_created)

	print('')
	print('-'*25 + ' debug_print ' + '-'*25)
	print('')

	for runid in sorted(runid_dict.keys()):
		thingy = runid_dict[runid]
		dashed : bool = False

		print('')
		print(f' *  runid:      {runid}')
		print(f'    type:       {type(thingy)}')
		
		if hasattr(thingy, "_itpt_for"):
			print(f'    itpt for:   {repr(thingy._itpt_for)}')
		
		if hasattr(thingy, "name"):
			name = repr(thingy.name)
			print(f'    name:       {name}')
		
		if hasattr(thingy, "name_ascii"):
			name_ascii = repr(thingy.name_ascii)
			print(f'    name_ascii: {name_ascii}')
		
		if hasattr(thingy, "_funcname") and thingy._funcname != None:
			funcname = repr(thingy._funcname)
			print(f'    funcname:   {funcname}')
		
		if hasattr(thingy, "arity"):
			arity = repr(thingy.arity)
			print(f'    arity:      {arity}')
		

		if hasattr(thingy, "underlying"):
			if not dashed:
				print(f'    ---')
				dashed = True
			print(f'    underlying: {repr(thingy.underlying)}')
		
		if hasattr(thingy, "root"):
			if not dashed:
				print(f'    ---')
				dashed = True
			print(f'    root:       {repr(thingy.root)}')
	
		if hasattr(thingy, "args"):
			args = [
				repr(arg)
				for arg in thingy.args
			]
			if not dashed:
				print(f'    ---')
				dashed = True
			print(f'    len(args):  {len(args)}')
			print(f'    args:       {', '.join(args)}')
		
		if hasattr(thingy, "varname"):
			varname = repr(thingy.varname)
			if not dashed:
				print(f'    ---')
				dashed = True
			print(f'    varname:    {varname}')

		print('')

	print('')
	print('-'*63)
	print('')



def get_BaseType_from_runid(runid : int) -> fond.BaseType:
	if runid not in fond.BaseType._created:
		raise LookupError
	return fond.BaseType._created[runid]

def get_PendMap_from_runid(runid : int) -> fond.PendMap:
	bt = get_BaseType_from_runid(runid)
	if not isinstance(bt, fond.PendMap):
		raise TypeError
	return bt

def get_Token_from_runid(runid : int) -> fond.Token:
	bt = get_BaseType_from_runid(runid)
	if not isinstance(bt, fond.Token):
		raise TypeError
	return bt
