

class ArityError(Exception): pass
# class DevError(Exception): pass
class LogicError(Exception): pass
class ModelError(Exception): pass
class ScopeError(Exception): pass
class TokenError(Exception): pass
class UsageError(Exception): pass



def assert_arity(
			*,
			want : int | None,
			got : int | None,
			symmetric_none : bool,
		) -> None:
	if want == None:
		return
	if got == None:
		if symmetric_none == True:
			return
		else:
			msg = f'Expected an integer for "got", but "got" is None'
			raise TypeError(msg)
	if want == 1:
		input_word = "input"
	else:
		input_word = "inputs"
	msg = f"Expected {want} {input_word} but got {got}"
	if want != got:
		raise ArityError(msg)



def assert_type(
			*,
			want : type | None,
			got : type | None,
			symmetric_none : bool,
		) -> None:
	if want == None:
		return
	if got == None:
		if symmetric_none == True:
			return
		else:
			msg = f'Expected a type for "got", but "got" is None'
			raise TypeError(msg)
	if want != got:
		msg = f"Expected type {want} but got type {got}"
		raise TypeError(msg)
