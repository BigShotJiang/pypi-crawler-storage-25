from __future__ import annotations

from collections.abc import Callable, Iterable
from typing import Union, cast, overload

from qmars._internal.classic_fo.syntax import (
	Boolean,
	ConstSymbol,
	FiniteObject,
	Formula,
	FormulaLikeCallable,
	FormulaLikePluggable,
	FuncSymbol,
	PredSymbol,
	QuantifierEnum,
	Sort,
	_FALSE,
	_TRUE,
	AND,
	EQ,
	EQUALS,
	IFF,
	IMPLIES,
	LEFTARROW,
	NAND,
	NEQ,
	NOR,
	NOT,
	OR,
	PI_2_0,
	PI_2_1,
	RIGHTARROW,
	XNOR,
	XOR,
)
from qmars._internal.errors import (
	ArityError,
	LogicError,
	ModelError,
	UsageError,
	assert_arity,
)
from qmars._internal.foundation import (
	BaseType,
	FoundationTokenEnum,
	MakeMap,
	PendMap,
	Token,
)




def bfb2mm(
			*,
			bfb : Callable[[*tuple[bool,...]], bool],
			arity : int | None,
			itpt_for : int,
			name : str,
		) -> MakeMap[Boolean, Boolean]:
	
	def make(*args : Boolean) -> Boolean:
		new_args : list[bool] = [arg.value for arg in args]
		return Boolean(bfb(*new_args))
	
	return MakeMap[Boolean, Boolean](
		inclass=Boolean,
		outclass=Boolean,
		arity=arity,
		make=make,
		itpt_for=itpt_for,
		name=name,
	)

def ofb2mm[_OBJ](
			*,
			ofb : Callable[[*tuple[_OBJ,...]], bool],
			arity : int | None,
			itpt_for : int,
			name : str,
		) -> MakeMap[FiniteObject[_OBJ], Boolean]:
	
	def make(*args : FiniteObject[_OBJ]) -> Boolean:
		new_args : list[_OBJ] = [arg.value for arg in args]
		return Boolean(ofb(*new_args))
	
	return MakeMap[FiniteObject[_OBJ], Boolean](
		inclass=FiniteObject[_OBJ],
		outclass=Boolean,
		arity=arity,
		make=make,
		itpt_for=itpt_for,
		name=name,
	)

def ofo2mm[_OBJ](
			*,
			ofo : Callable[[*tuple[_OBJ,...]], _OBJ],
			arity : int | None,
			itpt_for : int,
			name : str,
		) -> MakeMap[FiniteObject[_OBJ], FiniteObject[_OBJ]]:
	
	def make(*args : FiniteObject[_OBJ]) -> FiniteObject[_OBJ]:
		new_args : list[_OBJ] = [arg.value for arg in args]
		return FiniteObject[_OBJ](ofo(*new_args))
	
	return MakeMap[FiniteObject[_OBJ], FiniteObject[_OBJ]](
		inclass=FiniteObject[_OBJ],
		outclass=FiniteObject[_OBJ],
		arity=arity,
		make=make,
		itpt_for=itpt_for,
		name=name,
	)


def ofbguard[_OBJ](
			domain : set[_OBJ],
			func : Callable[[*tuple[_OBJ,...]], bool],
		) -> Callable[[*tuple[_OBJ,...]], bool]:
	
	def wrapped(*args : _OBJ) -> bool:
		for i in range(len(args)):
			if args[i] not in domain:
				msg = f"args[{i}]={repr(args[i])} not in domain"
				raise ModelError(msg)
		
		ret = func(*args)
		
		if type(ret) != bool:
			msg = f"Output {repr(ret)} not a boolean"
			raise ModelError(msg)
		
		return ret
	
	return wrapped


def ofoguard[_OBJ](
			domain : set[_OBJ],
			func : Callable[[*tuple[_OBJ,...]], _OBJ],
		) -> Callable[[*tuple[_OBJ,...]], _OBJ]:
	
	def wrapped(*args : _OBJ) -> _OBJ:
		for i in range(len(args)):
			if args[i] not in domain:
				msg = f"args[{i}]={repr(args[i])} not in domain"
				raise ModelError(msg)
		
		ret = func(*args)
		
		if ret not in domain:
			msg = f"Output {repr(ret)} not in domain"
			raise ModelError(msg)
		
		return ret
	
	return wrapped



def bfbnot(*args : bool) -> bool:
	return not args[0]
def bfband(*args : bool) -> bool:
	for arg in args:
		if arg == False:
			return False
	return True
def bfbor(*args : bool) -> bool:
	for arg in args:
		if arg == True:
			return True
	return False
def bfbxor(*args : bool) -> bool:
	trues = 0
	for arg in args:
		if arg == True:
			trues += 1
	return trues % 2 == 1
def bfbpi0(*args : bool) -> bool:
	return args[0]
def bfbpi1(*args : bool) -> bool:
	return args[1]

mmnot = bfb2mm(bfb=bfbnot, arity=1, itpt_for=NOT.underlying._runid, name="<MakeMap for NOT>")
mmand = bfb2mm(bfb=bfband, arity=None, itpt_for=AND.underlying._runid, name="<MakeMap for AND>")
mmor = bfb2mm(bfb=bfbor, arity=None, itpt_for=OR.underlying._runid, name="<MakeMap for OR>")
mmxor = bfb2mm(bfb=bfbxor, arity=None, itpt_for=XOR.underlying._runid, name="<MakeMap for XOR>")
mmpi0 = bfb2mm(bfb=bfbpi0, arity=2, itpt_for=PI_2_0._runid, name="<MakeMap for PI_n_0>")
mmpi1 = bfb2mm(bfb=bfbpi1, arity=2, itpt_for=PI_2_1._runid, name="<MakeMap for PI_n_1>")
mmtrue = bfb2mm(bfb=bfband, arity=None, itpt_for=_TRUE.underlying._runid, name="<MakeMap for TRUE>")

def MMNOT(
		arg : MakeMap[Boolean, Boolean],
	) -> MakeMap[Boolean, Boolean]:
	return mmnot.make_compose(arg)

def MMAND(
		*args : MakeMap[Boolean, Boolean],
	) -> MakeMap[Boolean, Boolean]:
	return mmand.make_compose(args)

def MMOR(
		*args : MakeMap[Boolean, Boolean],
	) -> MakeMap[Boolean, Boolean]:
	return MMNOT(MMAND(*[MMNOT(arg) for arg in args]))




def ofbeq[_OBJ](*args : _OBJ) -> bool:
	assert_arity(want=2, got=len(args), symmetric_none=False)
	return args[0] == args[1]

mmeq = ofb2mm(ofb=ofbeq, arity=2, itpt_for=EQ.underlying._runid, name="<MakeMap for EQ>")

def mm_pi[_OBJ](
			*,
			n : int | None,
			k : int,
			itpt_for : int,
			name : str,
		) -> MakeMap:
	
	def make[_T : BaseType](*args : _T) -> _T:
		return args[k]
	
	return MakeMap(
		inclass=None,
		outclass=None,
		arity=n,
		make=make,
		itpt_for=itpt_for,
		name=name,
	)



def mm_quant[_OBJ](
		*,
		thing_root : MakeMap[FiniteObject[_OBJ], Boolean],
		thing_otherargs : list[MakeMap[FiniteObject[_OBJ], FiniteObject[_OBJ]]],
		thing_arity : int | None,
		thing_runid : int,
		quant_idx : int,
		domain : set[FiniteObject[_OBJ]],
		criterion : Callable[[list[bool]], bool],
	) -> MakeMap[FiniteObject[_OBJ], Boolean]:

	def make(*makeargs : FiniteObject[_OBJ]) -> Boolean:
		assert_arity(want=thing_arity, got=len(makeargs), symmetric_none=True)
		args_eval : list[FiniteObject[_OBJ]] = [
			otherarg(*makeargs)
			for otherarg in thing_otherargs
		]
		rangeover : list[bool] = []
		for element in domain:
			new_args = args_eval[:quant_idx] + [element] + args_eval[quant_idx:]
			rangeover.append(thing_root(*new_args).value)
		return Boolean(criterion(rangeover))
	
	return MakeMap[FiniteObject[_OBJ], Boolean](
		inclass=FiniteObject[_OBJ],
		outclass=Boolean,
		arity=thing_arity,
		make=make,
		itpt_for=thing_runid,
		name=f"<MakeMap for runid={thing_runid}>",
	)






class FiniteModel[_OBJ]:

	_domain		: set[_OBJ]
	mem2sort	: dict[_OBJ, Sort[_OBJ] | None]
	const_itpt	: dict[
						Token,
						MakeMap[FiniteObject[_OBJ], FiniteObject[_OBJ]],
					]
	func_itpt	: dict[
						Token,
						MakeMap[FiniteObject[_OBJ], FiniteObject[_OBJ]],
					]
	pred_itpt	: dict[
						Token,
						MakeMap[FiniteObject[_OBJ], Boolean],
					]


	def __init__(self, objs : Iterable[_OBJ]) -> None:
		self._domain	= set(objs)
		if len(self._domain) == 0:
			msg = "objs cannot be empty (consult a mathematical logic reference to see why empty models are ill-behaved)"
			raise LogicError(msg)
		self.const_itpt	= {}
		self.func_itpt	= {}
		self.pred_itpt	= {}
		self.mem2sort	= {e : None for e in self._domain}


	def interpret_const(self,
				constsymbol : ConstSymbol[_OBJ],
				itpt : _OBJ,
			) -> None:
		
		if not isinstance(constsymbol, ConstSymbol):
			msg = "Expected ConstSymbol"
			raise TypeError(msg)
		if itpt not in self._domain:
			msg = f"{repr(itpt)} not in domain"
			raise ModelError(msg)
		
		def cte_map(*args : _OBJ) -> _OBJ:
			return cast(_OBJ, itpt)
		
		self.const_itpt[constsymbol.underlying] = ofo2mm(
			ofo=cte_map,
			arity=None,
			itpt_for=constsymbol.underlying._runid,
			name=f"<MakeMap for {constsymbol.underlying.name}>",
		)


	@overload
	def interpret_func(self,
				funcsymbol : FuncSymbol[_OBJ],
				itpt : Callable[..., _OBJ],
			) -> None: ...
	@overload
	def interpret_func(self,
				funcsymbol : FuncSymbol[_OBJ],
				itpt : None = None,
			) -> Callable[
						[Callable[..., _OBJ]],
						Callable[..., _OBJ],
					]: ...
	def interpret_func(self,
				funcsymbol : FuncSymbol[_OBJ],
				itpt : Callable[..., _OBJ] | None = None,
			) -> Union[
						Callable[
							[Callable[..., _OBJ]],
							Callable[..., _OBJ],
						],
						None,
					]:
		if not isinstance(funcsymbol, FuncSymbol):
			msg = "Expected FuncSymbol"
			raise TypeError(msg)
		
		def func_deco(
					func : Callable[..., _OBJ],
				) -> Callable[..., _OBJ]:
			
			self.func_itpt[funcsymbol.underlying] = ofo2mm(
				ofo=ofoguard(self._domain, func),
				arity=funcsymbol.arity,
				itpt_for=funcsymbol.underlying._runid,
				name=f"<MakeMap for {funcsymbol.underlying.name}>",
			)
			return func
		
		if itpt == None:
			return func_deco
		elif isinstance(itpt, Callable):
			func_deco(itpt)
			return None
		else:
			msg = 'Unknown "itpt" type'
			raise TypeError(msg)
	

	@overload
	def interpret_pred(self,
				predsymbol : PredSymbol[_OBJ],
				itpt : Callable[..., bool],
			) -> None: ...
	@overload
	def interpret_pred(self,
				predsymbol : PredSymbol[_OBJ],
				itpt : None = None,
			) -> Callable[
						[Callable[..., bool]],
						Callable[..., bool],
					]: ...
	def interpret_pred(self,
				predsymbol : PredSymbol[_OBJ],
				itpt : Callable[..., bool] | None = None,
			) -> Union[
						Callable[
							[Callable[..., bool]],
							Callable[..., bool],
						],
						None,
					]:

		if not isinstance(predsymbol, PredSymbol):
			msg = "Expected PredSymbol"
			raise TypeError(msg)
			
		def pred_deco(
					func : Callable[..., bool],
				) -> Callable[..., bool]:
			
			self.pred_itpt[predsymbol.underlying] = ofb2mm(
				ofb=ofbguard(self._domain, func),
				arity=predsymbol.arity,
				itpt_for=predsymbol.underlying._runid,
				name=f"<MakeMap for {predsymbol.underlying.name}>",
			)
			return func
		
		if itpt == None:
			return pred_deco
		elif isinstance(itpt, Callable):
			pred_deco(itpt)
			return None
		else:
			msg = 'Unknown "itpt" type'
			raise TypeError(msg)
	

	def interpret_sort(self,
				sort : Sort[_OBJ],
				itpt : Iterable[_OBJ],
			) -> None:
		
		if not isinstance(sort, Sort):
			msg = "Expected Sort"
			raise TypeError(msg)

		for el in itpt:
			if el not in self._domain:
				msg = f"{repr(el)} not in domain"
				raise ModelError(msg)
			if self.mem2sort[el] != None:
				msg = f"{repr(el)} already has a sort"
				raise ModelError(msg)
			self.mem2sort[el] = sort
		
		def sortfunc(
					*args : _OBJ,
				) -> bool:
			return self.mem2sort[args[0]] == sort
		
		self.interpret_pred(sort, sortfunc)


	@overload
	def _itpt[_In : BaseType, _Out : BaseType](self,
				thing : PendMap[_In, _Out],
			) -> MakeMap[_In, _Out]: ...
	@overload
	def _itpt(self,
				thing : Token,
			) -> MakeMap: ...
	def _itpt(self,
				thing : PendMap | Token,
			) -> MakeMap:
		
		if isinstance(thing, PendMap):
		
			if thing.root == FoundationTokenEnum.PI_OUT.value:
				n = len(thing.args)
				k : int | None = None
				for idx in range(n):
					if thing.args[idx] == FoundationTokenEnum.MIRROR_K.value:
						if k == None:
							k = idx
						else:
							msg = "Expected exactly one MIRROR_K arg"
							raise UsageError(msg)
					elif thing.args[idx] == FoundationTokenEnum.NONE.value:
						pass
					else:
						msg = f"Invalid PendMap arg: {thing.args[idx]}"
						raise UsageError(msg)
				if k == None:
					msg = "Expected exactly one MIRROR_K arg"
					raise UsageError(msg)
				
				return mm_pi(
					n=n,
					k=k,
					itpt_for=thing._runid,
					name=f"<MakeMap for PI_{n}_{k}>",
				)
			
			quant_idx : int | None = None
			for idx in range(len(thing.args)):
				if thing.args[idx] in [mem.value for mem in QuantifierEnum]:
					if quant_idx == None:
						quant_idx = idx
					else:
						msg = f"At most one quantifier expected in args"
						raise UsageError(msg)
			
			if quant_idx == None:
				return self._itpt(thing.root).make_compose([
					self._itpt(arg)
					for arg in thing.args
				])
			
			quant = thing.args[quant_idx]
			root_itpt : MakeMap[FiniteObject[_OBJ], Boolean] = cast(
				MakeMap[FiniteObject[_OBJ], Boolean],	# trust me bro
				self._itpt(thing.root)
			)
			otherargs_itpt : list[MakeMap[FiniteObject[_OBJ], FiniteObject[_OBJ]]] = [
				cast(
					MakeMap[FiniteObject[_OBJ], FiniteObject[_OBJ]],	# trust me bro
					self._itpt(thing.args[i])
				)
				for i in range(len(thing.args)) if i != quant_idx
			]
			
			if quant == QuantifierEnum.FORALL.value:
				return mm_quant(
					thing_root=root_itpt,
					thing_otherargs=otherargs_itpt,
					thing_arity=thing.arity,
					thing_runid=thing._runid,
					quant_idx=quant_idx,
					domain={FiniteObject[_OBJ](element) for element in self._domain},
					criterion=(lambda blist: all(blist)),
				)
			if quant == QuantifierEnum.EXISTS.value:
				return mm_quant(
					thing_root=root_itpt,
					thing_otherargs=otherargs_itpt,
					thing_arity=thing.arity,
					thing_runid=thing._runid,
					quant_idx=quant_idx,
					domain={FiniteObject[_OBJ](element) for element in self._domain},
					criterion=(lambda blist: not all([not b for b in blist])),
				)
			msg = "No interpretation found"
			raise ModelError(msg)
		
		elif isinstance(thing, Token):
		
			if thing in [EQ.underlying, EQUALS.underlying]:
				return mmeq
			if thing == NEQ.underlying:
				return mmnot.make_compose(mmeq)
			if thing == _TRUE.underlying:
				return mmtrue
			if thing == _FALSE.underlying:
				return MMNOT(mmtrue)
			
			if thing == AND.underlying:
				return mmand
			if thing == NOT.underlying:
				return mmnot
			if thing == NAND.underlying:
				return MMNOT(mmand)
			if thing == NOR.underlying:
				return MMNOT(mmor)
			if thing == OR.underlying:
				return mmor
			if thing == XOR.underlying:
				return mmxor
			if thing in [XNOR.underlying, IFF.underlying]:
				return MMNOT(mmxor)
			if thing in [RIGHTARROW.underlying, IMPLIES.underlying]:
				return MMOR(MMNOT(mmpi0), mmpi1)
			if thing == LEFTARROW.underlying:
				return MMOR(mmpi0, MMNOT(mmpi1))

			if thing in self.const_itpt:
				return self.const_itpt[thing]
			if thing in self.func_itpt:
				return self.func_itpt[thing]
			if thing in self.pred_itpt:
				return self.pred_itpt[thing]
			
			msg = f"No interpretation found for token {repr(thing)}"
			raise ModelError(msg)

		else:
			raise TypeError

	def partitioned(self) -> bool:
		num_of_sorted : int = 0
		
		for el in self._domain:
			if self.mem2sort[el] != None:
				num_of_sorted += 1

		if num_of_sorted == 0:
			# default sort only
			return True
		elif num_of_sorted == len(self._domain):
			return True
		else:
			return False

	def models(self,
				formula : FormulaLikeCallable[_OBJ],
				*args : _OBJ,
			) -> bool:
		
		if not self.partitioned():
			msg = f"Model not correctly partitioned by sorts"
			raise ModelError(msg)
		
		formula_itpt = self._itpt(formula.underlying)
		ret = formula_itpt(*[
			FiniteObject[_OBJ](arg)
			for arg in args
		])
		return ret.value
	
	def satisfies(self,
				formula : FormulaLikeCallable[_OBJ],
				*args : _OBJ,
			) -> bool:
		return self.models(formula, *args)
