from __future__ import annotations

from collections.abc import Callable
from typing import ClassVar, Union

from qmars._internal import foundation as fond
from qmars._internal.classic_fo import syntax
from qmars._internal.errors import ScopeError, UsageError, assert_arity




class VariableScope[_OBJ]:
	_active_scope	: ClassVar[VariableScope | None] = None

	vcmlist			: list[
							tuple[
								VariableContextManager[_OBJ],
								syntax.FormulaLikePluggable[_OBJ] | None,
							]
						]
	
	@classmethod
	def add_scope(cls, scope : VariableScope) -> None:
		if VariableScope._active_scope != None:
			msg = "Scope already active"
			raise ScopeError(msg)
		VariableScope._active_scope = scope
	
	@classmethod
	def remove_scope(cls) -> None:
		if VariableScope._active_scope == None:
			msg = "Scope not found"
			raise ScopeError(msg)
		VariableScope._active_scope = None
	
	@classmethod
	def get_active_scope(cls) -> VariableScope:
		if VariableScope._active_scope == None:
			msg = "Scope not found"
			raise ScopeError(msg)
		return VariableScope._active_scope

	def __init__(self,
				# inputlen : int,
			) -> None:
		self.vcmlist = []
		# self.vcmlist = [
		# 	(
		# 		VariableContextManager[_OBJ](
		# 			bound=None,
		# 			constraint=None,
		# 		),
		# 		None,
		# 	)
		# 	for i in range(inputlen)
		# ]
	
	def __enter__(self) -> None:
		VariableScope.add_scope(self)
		# for vcm, cond in self.vcmlist:
		# 	vcm.__enter__(already_enlisted=True)
	
	def __exit__(self, *args) -> None:
		for vcm, cond in reversed(self.vcmlist):
			vcm.__exit__()
		VariableScope.remove_scope()
	
	def add_vcm(self,
				vcm : VariableContextManager[_OBJ],
				enter_vcm : bool = True,
			) -> None:
		self.vcmlist.append((vcm, None))
		if enter_vcm:
			vcm.__enter__()
	
	def add_cond(self,
				cond : syntax.FormulaLikePluggable[_OBJ],
			) -> None:
		if not isinstance(cond, syntax.Formula):
			msg = '"cond" should have type Formula'
			raise TypeError(msg)
		# assert_arity(want=0, got=cond.arity, symmetric_none=True) ???
		if len(self.vcmlist) == 0:
			msg = "No VariableContextManager available"
			raise ScopeError(msg)
		vcm, current_cond = self.vcmlist[-1]
		if not isinstance(vcm.bound, syntax.QuantifierEnum):
			msg = "Variable not bound by quantifier"
			raise UsageError(msg)
		self.vcmlist[-1] = (vcm, current_cond & cond)
		
	def recursive_underlying_resolve(self,
				*,
				thing : Union[
							fond.PendMap,
							fond.Token,
						],
				pi_dict : dict[
							fond.Token,
							fond.PendMap,
						],
			) -> Union[
						fond.PendMap,
						fond.Token,
					]:
		
		if thing in pi_dict:
			return pi_dict[thing]
		if isinstance(thing, fond.Token):
			return thing
		return thing.root.compose(
			others=[
				self.recursive_underlying_resolve(
					thing=arg,
					pi_dict=pi_dict,
				)
				for arg in thing.args
			],
			new_arity=len(pi_dict),
		)


	def resolve_formula(self, formula : syntax.FormulaLikePluggable[_OBJ]) -> syntax.Formula[_OBJ]:
		
		seen_quantifier = False
		# pi_dict : dict[fond.Token, fond.PendMap] = {}
		n = len(self.vcmlist)
		new_formula = formula
		
		try:
			for vcm, cond in self.vcmlist:
				if vcm.bound == None:
					assert vcm.constraint == None
					assert cond == None
					assert not seen_quantifier
				else:
					seen_quantifier = True
				# pi_dict[vcm.var.underlying] = syntax.pi(n, k)
		except AssertionError:
			raise UsageError
		
		# for m in range(n, 0, -1):
		for m in reversed(range(n)):
			# vcm, cond = self.vcmlist[-1]
			vcm, cond = self.vcmlist[m]
			# Add conditions
			complete_condition : syntax.Formula | None = None
			if vcm.constraint != None:
				complete_condition = complete_condition & vcm.constraint(vcm.var)
			if cond != None:
				complete_condition = complete_condition & cond
			
			if vcm.bound == syntax.QuantifierEnum.FORALL:
				new_formula = complete_condition >> new_formula
			elif vcm.bound == syntax.QuantifierEnum.EXISTS:
				new_formula = complete_condition & new_formula
			# Replace any existing variables
			new_underlying = self.recursive_underlying_resolve(
				thing=new_formula.underlying,
				pi_dict={
					self.vcmlist[k][0].var.underlying : syntax.pi(m+1, k)
					for k in range(m+1)
				},
			)
			assert isinstance(new_underlying, fond.PendMap)	# always true
			new_formula = syntax.Formula[_OBJ](
				underlying=new_underlying,
			)
			if isinstance(vcm.bound, syntax.QuantifierEnum):
				new_formula = syntax.Formula[_OBJ](
					underlying=new_formula.underlying.fill(
						where=m,
						with_what=vcm.bound.value,
					)
				)
		return new_formula
	
	def resolve_term(self, term : syntax.TermLikePluggable[_OBJ]) -> syntax.Term[_OBJ]:
		
		# pi_dict : dict[fond.Token, fond.PendMap] = {}
		n = len(self.vcmlist)

		try:
			for vcm, cond in self.vcmlist:
				assert vcm.bound == None
				assert vcm.constraint == None
				assert cond == None
				# pi_dict[vcm.var.underlying] = syntax.pi(n, k)
		except AssertionError:
			raise UsageError
		
		new_underlying = self.recursive_underlying_resolve(
			thing=term.underlying,
			pi_dict={
				self.vcmlist[k][0].var.underlying : syntax.pi(n, k)
				for k in range(n)
			},
		)
		assert isinstance(new_underlying, fond.PendMap)	# always true
		return syntax.Term[_OBJ](
			underlying=new_underlying,
		)



class VariableContextManager[_OBJ]:
	
	num_of_active	: ClassVar[int] = 0
	varname			: str | None
	bound			: syntax.QuantifierEnum | None
	constraint		: syntax.FormulaLikeCallable[_OBJ] | None
	var				: syntax.Variable

	def __init__(self,
				*,
				bound : syntax.QuantifierEnum | None,
				constraint : syntax.FormulaLikeCallable[_OBJ] | None) -> None:
		self.bound	= bound
		self.var	= syntax.Variable()
		if constraint == None:
			self.constraint = None
		else:
			self.add_constraint(constraint)

	def __enter__(self,
				# *,
				# already_enlisted : bool = False,
			) -> syntax.Variable:
		# if not already_enlisted:
		# 	VariableScope.get_active_scope().add_vcm(self)
		self.varname = f"[VAR {VariableContextManager.num_of_active}]"
		VariableContextManager.num_of_active += 1
		return self.var
	
	def __exit__(self, *args) -> None:
		VariableContextManager.num_of_active -= 1

	def add_constraint(self, constraint : syntax.FormulaLikeCallable[_OBJ]) -> None:
		assert_arity(want=1, got=constraint.arity, symmetric_none=True)
		self.constraint = constraint
	


def formula[_OBJ](
			formula_func : Callable[[], syntax.FormulaLikePluggable[_OBJ]],
		) -> syntax.Formula[_OBJ]:

	scope = VariableScope()

	with scope:
		formula_func_out = formula_func()
		output_formula = scope.resolve_formula(formula_func_out)
		try:
			funcname = formula_func.__name__
		except AttributeError:
			# pass
			raise
		output_formula.name = funcname
		output_formula.underlying.name = funcname
		
	return output_formula



def term[_OBJ](
			term_func : Callable[[], syntax.TermLikePluggable[_OBJ]],
		) -> syntax.Term[_OBJ]:
	
	scope = VariableScope()
		
	
	with scope:
		term_func_out = term_func()
		output_term = scope.resolve_term(term_func_out)
		try:
			funcname = term_func.__name__
		except AttributeError:
			# pass
			raise
		output_term.name = funcname
		output_term.underlying.name = funcname
	
	return output_term


def statement[_OBJ](
			formula_func : Callable[[], syntax.FormulaLikePluggable[_OBJ]],
		) -> syntax.Formula[_OBJ]:
	return formula(formula_func)



def inputvar[_OBJ]() -> syntax.Variable:
	vcm = VariableContextManager[_OBJ](
		bound=None,
		constraint=None,
	)
	VariableScope.get_active_scope().add_vcm(vcm)
	return vcm.var


def such_that[_OBJ](
			cond : syntax.FormulaLikePluggable[_OBJ],
		) -> None:
	VariableScope.get_active_scope().add_cond(cond)




def forall[_OBJ](
			constraint : syntax.FormulaLikeCallable[_OBJ] | None = None,
		) -> VariableContextManager[_OBJ]:
	
	if isinstance(constraint, syntax.Formula | syntax.PredSymbol | syntax.Sort | None):
		vcm_constraint = constraint
	else:
		msg = '"constraint", if given, should have type Formula, Predicate or Sort'
		raise UsageError(msg)
	
	vcm = VariableContextManager[_OBJ](
		bound=syntax.QuantifierEnum.FORALL,
		constraint=vcm_constraint,
	)
	VariableScope.get_active_scope().add_vcm(vcm)
	return vcm

def exists[_OBJ](
			constraint : syntax.FormulaLikeCallable[_OBJ] | None = None,
		) -> VariableContextManager[_OBJ]:
	
	if isinstance(constraint, syntax.Formula | syntax.PredSymbol | syntax.Sort | None):
		vcm_constraint = constraint
	else:
		msg = '"constraint", if given, should have type Formula, Predicate or Sort'
		raise UsageError(msg)
	
	vcm = VariableContextManager[_OBJ](
		bound=syntax.QuantifierEnum.EXISTS,
		constraint=vcm_constraint,
	)
	VariableScope.get_active_scope().add_vcm(vcm)
	return vcm




################## TRASH CAN

# def formula[_OBJ](
# 			*,
# 			arity : int,
# 		) -> Callable[
# 					[
# 						Callable[
# 							...,
# 							syntax.FormulaLikePluggable[_OBJ]
# 						],
# 					],
# 					syntax.Formula[_OBJ]
# 				]:
	
# 	def formula_n(
# 				func : Callable[
# 							...,
# 							syntax.FormulaLikePluggable[_OBJ]
# 						],
# 			) -> syntax.Formula[_OBJ]:
		
# 		scope = VariableScope(arity)
		
# 		args = [
# 			scope.vcmlist[i][0].var
# 			for i in range(arity)
# 		]
# 		with scope:
# 			func_out = func(*args)
# 			output_formula = scope.resolve_formula(func_out)
# 			try:
# 				funcname = func.__name__
# 			except AttributeError:
# 				# pass
# 				raise
# 			output_formula.name = funcname
# 			output_formula.underlying.name = funcname
		
# 		return output_formula

# 	return formula_n


# def term[_OBJ](
# 			*,
# 			arity : int,
# 		) -> Callable[
# 					[
# 						Callable[
# 							...,
# 							syntax.TermLikePluggable[_OBJ]
# 						],
# 					],
# 					syntax.Term[_OBJ]
# 				]:
	
# 	def term_n(
# 				func : Callable[
# 							...,
# 							syntax.TermLikePluggable[_OBJ]
# 						],
# 			) -> syntax.Term[_OBJ]:
		
# 		scope = VariableScope(arity)
		
# 		args = [
# 			scope.vcmlist[i][0].var
# 			for i in range(arity)
# 		]
# 		with scope:
# 			func_out = func(*args)
# 			output_term = scope.resolve_term(func_out)
# 			try:
# 				funcname = func.__name__
# 			except AttributeError:
# 				# pass
# 				raise
# 			output_term.name = funcname
# 			output_term.underlying.name = funcname
		
# 		return output_term

# 	return term_n



# def statement[_OBJ](
# 			*,
# 			arity : int,
# 		) -> Callable[
# 					[
# 						Callable[
# 							...,
# 							syntax.FormulaLikePluggable[_OBJ]
# 						],
# 					],
# 					syntax.Formula[_OBJ]
# 				]:
# 	return formula(arity=arity)
