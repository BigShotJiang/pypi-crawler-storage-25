from __future__ import annotations
from enum import Enum
from types import UnionType


from qmars._internal import foundation as fond




type TermLikePluggable[_OBJ]	= Term[_OBJ] | ConstSymbol[_OBJ] | Variable
type TermLikeCallable[_OBJ]		= Term[_OBJ] | ConstSymbol[_OBJ] | Variable | FuncSymbol[_OBJ]
type FormulaLikePluggable[_OBJ]	= Formula[_OBJ]
type FormulaLikeCallable[_OBJ]	= Formula[_OBJ] | PredSymbol[_OBJ] | Sort[_OBJ]



class Object[_OBJ](fond.ObjectType[_OBJ]): pass

# class FiniteObject[_OBJ](fond.ObjectType[_OBJ]):
class FiniteObject[_OBJ](Object[_OBJ]):
	def __init__(self, value : _OBJ) -> None:
		self.value	= value
	


# type Object[_OBJ] = FiniteObject[_OBJ]


class Boolean(fond.ObjectType[bool]):
	def __init__(self, value : bool) -> None:
		self.value	= value
	


class Variable(fond.VariableType):
	
	def __init__(self) -> None:
		super().__init__()
	
	def eq[_OBJ](self, other : TermLikePluggable[_OBJ]) -> Formula[_OBJ]:
		return EQ(self, other)
	
	def neq[_OBJ](self, other : TermLikePluggable[_OBJ]) -> Formula[_OBJ]:
		return NEQ(self, other)
	
	def equals[_OBJ](self, other : TermLikePluggable[_OBJ]) -> Formula[_OBJ]:
		return EQUALS(self, other)
	




class Term[_OBJ](fond.SymbolType):
	
	name		: str | None = None
	name_ascii	: str | None = None
	arity		: int | None
	underlying	: fond.PendMap[Object[_OBJ], Object[_OBJ]]

	def __init__(self,
				*,
				underlying : fond.PendMap[Object[_OBJ], Object[_OBJ]],
				name : str | None = None,
				name_ascii : str | None = None,
			) -> None:
		super().__init__()
		self.arity		= underlying.arity
		self.underlying	= underlying
	
	def __call__(self, *args : TermLikePluggable[_OBJ]) -> Term[_OBJ]:
		return self._compose(*args)

	def _compose(self,
				*others : TermLikePluggable[_OBJ],
			) -> Term[_OBJ]:
		new_underlying = self.underlying.compose(
			others=[
				other.underlying
				for other in others
			],
			new_arity=None,
		)
		return Term[_OBJ](
			underlying=new_underlying,
		)
	
	def eq(self, other : TermLikePluggable[_OBJ]) -> Formula[_OBJ]:
		return EQ(self, other)
	
	def neq(self, other : TermLikePluggable[_OBJ]) -> Formula[_OBJ]:
		return NEQ(self, other)
	
	def equals(self, other : TermLikePluggable[_OBJ]) -> Formula[_OBJ]:
		return EQUALS(self, other)
	




class Formula[_OBJ](fond.SymbolType):
	
	name		: str | None = None
	name_ascii	: str | None = None
	arity		: int | None
	underlying	: fond.PendMap[Object[_OBJ], Boolean]
	
	def __init__(self,
				*,
				underlying : fond.PendMap[Object[_OBJ], Boolean],
			) -> None:
		super().__init__()
		self.arity		= underlying.arity
		self.underlying	= underlying
	
	def __call__(self, *args : TermLikePluggable[_OBJ]) -> Formula[_OBJ]:
		return self._compose(*args)
	
	def _compose(self,
				*others : TermLikePluggable[_OBJ],
			) -> Formula[_OBJ]:
		new_underlying = self.underlying.compose(
			others=[
				other.underlying
				for other in others
			],
			new_arity=None,
		)
		return Formula[_OBJ](
			underlying=new_underlying,
		)
	
	def __and__(self, other : FormulaLikePluggable[_OBJ] | None) -> Formula[_OBJ]:
		if other == None:
			return self
		return AND(self, other)
	def __rand__(self, lother : None) -> Formula[_OBJ]:
		return self
	
	def __or__(self, other : FormulaLikePluggable[_OBJ] | None) -> Formula[_OBJ]:
		if other == None:
			return self
		return OR(self, other)
	def __ror__(self, lother: None) -> Formula[_OBJ]:
		return self
	
	def __invert__(self) -> Formula[_OBJ]:
		return NOT(self)
	
	def __rshift__(self, other : FormulaLikePluggable[_OBJ]) -> Formula[_OBJ]:
		return RIGHTARROW(self, other)
	def __rrshift__(self, lother : None) -> Formula[_OBJ]:
		return self
	
	def __lshift__(self, other : FormulaLikePluggable[_OBJ] | None) -> Formula[_OBJ]:
		if other == None:
			return self
		return LEFTARROW(self, other)
	
	
	def implies(self, other : FormulaLikePluggable[_OBJ]) -> Formula[_OBJ]:
		return IMPLIES(self, other)
	
	def iff(self, other : FormulaLikePluggable[_OBJ]) -> Formula[_OBJ]:
		return IFF(self, other)
	


class OpSymbol[_OBJ](fond.SymbolType):

	arity		: int | None
	name		: str
	name_ascii	: str | None
	underlying	: fond.Token

	def __init__(self,
				arity : int | None,
				name : str,
				name_ascii : str | None = None,
			) -> None:
		super().__init__()
		token = fond.Token(name=name, name_ascii=name_ascii)
		self.arity		= arity
		self.name		= name
		self.name_ascii	= name_ascii
		self.underlying	= token
	
	def __call__(self, *args : FormulaLikePluggable[_OBJ]) -> Formula[_OBJ]:
		return self._compose(*args)
	
	def _compose(self,
				*others : FormulaLikePluggable[_OBJ],
			) -> Formula[_OBJ]:
		new_underlying = self.underlying.compose(
			others=[
				other.underlying
				for other in others
			],
			new_arity=None,
		)
		return Formula[_OBJ](
			underlying=new_underlying,
		)



class FuncSymbol[_OBJ](fond.SymbolType):
	
	arity		: int | None
	name		: str
	name_ascii	: str | None
	underlying	: fond.Token

	def __init__(self,
				arity : int | None,
				name : str,
				name_ascii : str | None = None,
			) -> None:
		super().__init__()
		token = fond.Token(name=name, name_ascii=name_ascii)
		self.arity		= arity
		self.name		= name
		self.name_ascii	= name_ascii
		self.underlying	= token
	
	def __call__(self, *args : TermLikePluggable[_OBJ]) -> Term[_OBJ]:
		return self._compose(*args)
	
	def _compose(self,
				*others : TermLikePluggable[_OBJ],
			) -> Term[_OBJ]:
		new_underlying = self.underlying.compose(
			others=[
				other.underlying
				for other in others
			],
			new_arity=None,
		)
		return Term[_OBJ](
			underlying=new_underlying,
		)



class PredSymbol[_OBJ](fond.SymbolType):
		
	arity		: int | None
	name		: str
	name_ascii	: str | None
	underlying	: fond.Token

	def __init__(self,
				arity : int | None,
				name : str,
				name_ascii : str | None = None,
			) -> None:
		super().__init__()
		token = fond.Token(name=name, name_ascii=name_ascii)
		self.arity		= arity
		self.name		= name
		self.name_ascii	= name_ascii
		self.underlying	= token
	
	def __call__(self, *args : TermLikePluggable[_OBJ]) -> Formula[_OBJ]:
		return self._compose(*args)
	
	def _compose(self,
				*others : TermLikePluggable[_OBJ],
			) -> Formula[_OBJ]:
		new_underlying = self.underlying.compose(
			others=[
				other.underlying
				for other in others
			],
			new_arity=None,
		)
		return Formula[_OBJ](
			underlying=new_underlying,
		)
	
	

class ConstSymbol[_OBJ](fond.SymbolType):
	
	name		: str
	name_ascii	: str | None
	underlying	: fond.Token

	def __init__(self,
				name : str,
				name_ascii : str | None = None,
			) -> None:
		super().__init__()
		token = fond.Token(name=name, name_ascii=name_ascii)
		self.name		= name
		self.name_ascii	= name_ascii
		self.underlying	= token




class Sort[_OBJ](PredSymbol[_OBJ]):

	def __init__(self,
				name: str,
				name_ascii: str | None = None,
			) -> None:
		super().__init__(1, name, name_ascii)

	# internal_pred	: PredSymbol[_OBJ]

	# def __init__(self,
	# 			name : str,
	# 			name_ascii : str | None = None,
	# 		) -> None:
	# 	super().__init__()
	# 	self.internal_pred = PredSymbol(1, name, name_ascii)
	
	# def __call__(self, *args : TermLikePluggable[_OBJ]) -> Formula[_OBJ]:
	# 	return self._compose(*args)
	
	# def _compose(self,
	# 			*others : TermLikePluggable[_OBJ],
	# 		) -> Formula[_OBJ]:
	# 	new_underlying = self.internal_pred.underlying.compose(
	# 		others=[
	# 			other.underlying
	# 			for other in others
	# 		],
	# 		new_arity=None,
	# 	)
	# 	return Formula[_OBJ](
	# 		underlying=new_underlying,
	# 	)
	



###### Definitions



class QuantifierEnum(Enum):
	FORALL		= fond.Token(name="∀", name_ascii="CFO_FORALL")
	EXISTS		= fond.Token(name="∃", name_ascii="CFO_EXISTS")

# class PredEnum(Enum):
_TRUE		= PredSymbol(0,		"⊤",	"TRUE")
_FALSE		= PredSymbol(0,		"⊥",	"FALSE")
EQ			= PredSymbol(2,		"=")
NEQ			= PredSymbol(2,		"≠",	"NEQ")
EQUALS		= EQ

# class OpEnum(Enum):
AND			= OpSymbol(None,	"∧",	"AND")
NOT			= OpSymbol(1,		"¬",	"NOT")
OR			= OpSymbol(None,	"∨",	"OR")
NAND		= OpSymbol(None,	"NAND")
NOR			= OpSymbol(None,	"NOR")
XOR			= OpSymbol(None,	"XOR")
XNOR		= OpSymbol(None,	"XNOR")
IFF			= OpSymbol(2,		"↔",	"<->")
RIGHTARROW	= OpSymbol(2,		"→",	"->")
LEFTARROW	= OpSymbol(2,		"←",	"<-")
IMPLIES		= RIGHTARROW



_TRUE_PM = fond.PendMap(
	inclass=None,
	midclass=None,
	outclass=Boolean,
	arity=None,
	root=_TRUE.underlying,
	args=[],
)

_FALSE_PM = fond.PendMap(
	inclass=None,
	midclass=None,
	outclass=Boolean,
	arity=None,
	root=_FALSE.underlying,
	args=[],
)

TRUE = Formula(underlying=_TRUE_PM)
FALSE = Formula(underlying=_FALSE_PM)


# def AND[_OBJ](*args : FormulaLikePluggable[_OBJ]) -> Formula[_OBJ]:
# 	return OpEnum.AND.value._compose(*args)

# def OR[_OBJ](*args : FormulaLikePluggable[_OBJ]) -> Formula[_OBJ]:
# 	return OpEnum.OR.value._compose(*args)

# def NOT[_OBJ](arg : FormulaLikePluggable[_OBJ]) -> Formula[_OBJ]:
# 	return OpEnum.NOT.value._compose(arg)

# def XOR[_OBJ](*args : FormulaLikePluggable[_OBJ]) -> Formula[_OBJ]:
# 	return OpEnum.XOR.value._compose(*args)

# def XNOR[_OBJ](*args : FormulaLikePluggable[_OBJ]) -> Formula[_OBJ]:
# 	return OpEnum.XNOR.value._compose(*args)

# def IFF[_OBJ](arg1 : FormulaLikePluggable[_OBJ], arg2 : FormulaLikePluggable[_OBJ]) -> Formula[_OBJ]:
# 	return OpEnum.IFF.value._compose(arg1, arg2)

# def RIGHTARROW[_OBJ](arg1 : FormulaLikePluggable[_OBJ], arg2 : FormulaLikePluggable[_OBJ]) -> Formula[_OBJ]:
# 	return OpEnum.RIGHTARROW.value._compose(arg1, arg2)

# def LEFTARROW[_OBJ](arg1 : FormulaLikePluggable[_OBJ], arg2 : FormulaLikePluggable[_OBJ]) -> Formula[_OBJ]:
# 	return OpEnum.LEFTARROW.value._compose(arg1, arg2)

# def IMPLIES[_OBJ](arg1 : FormulaLikePluggable[_OBJ], arg2 : FormulaLikePluggable[_OBJ]) -> Formula[_OBJ]:
# 	return RIGHTARROW(arg1, arg2)


# def EQ[_OBJ](arg1 : TermLikePluggable[_OBJ], arg2 : TermLikePluggable[_OBJ]) -> Formula[_OBJ]:
# 	return PredEnum.EQ.value._compose(arg1, arg2)

# def NEQ[_OBJ](arg1 : TermLikePluggable[_OBJ], arg2 : TermLikePluggable[_OBJ]) -> Formula[_OBJ]:
# 	return PredEnum.NEQ.value._compose(arg1, arg2)

# def EQUALS[_OBJ](arg1 : TermLikePluggable[_OBJ], arg2 : TermLikePluggable[_OBJ]) -> Formula[_OBJ]:
# 	return EQ(arg1, arg2)


Statement = Formula


def pi[_OBJ](
			n : int,
			k : int,
		) -> fond.PendMap[Object[_OBJ], Object[_OBJ]]:
	return fond.pi_pendmap(
		inclass=Object,
		n=n,
		k=k,
	)

PI_2_0 = pi(2, 0)
PI_2_1 = pi(2, 1)
