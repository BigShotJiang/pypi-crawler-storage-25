from __future__ import annotations
from dataclasses import dataclass
from typing import ClassVar, NoReturn


@dataclass
class Me:
	first = "Ali"
	last = "Hadizadeh Moghadam"
	mail = "ali.hadizadeh79 \\atsign\\ sharif \\dot\\ edu"
	i = "i"
	me = "me"
	my = "my"


SETTING_NAME_JOIN = '.'
def makename(*parts : str):
	return SETTING_NAME_JOIN.join(parts)


class SettingHolder[_V]:
	_inst_dict	: ClassVar[dict[str, SettingHolder]] = {}
	
	modified_by	: list[SettingsMenu]
	name		: str
	settings	: Settings
	value		: _V
	
	def __init__(self, apply_to : Settings, *, name : str, default_value : _V) -> None:
		self.settings = apply_to
		if name in SettingHolder._inst_dict:
			raise ValueError(f'Name "{name}" already taken')
		
		self.modified_by	= []
		self.name			= name
		self.value			= default_value

		SettingHolder._inst_dict[name] = self
	
	def __bool__(self) -> NoReturn: raise RuntimeError

	def get(self) -> _V:
		return self.value
	
	def set(self, value : _V, *, by : SettingsMenu) -> None:
		self.value = value
		self.modified_by.append(by)
	
	def cite(self) -> None:
		self.settings._cited.add(self)



class Settings:
	
	_cited	: set[SettingHolder]

	def __init__(self) -> None:
		self.reset()
		self.evil_syntax	= Settings_EvilSyntax(self, name='evil_syntax')
		self.display		= Settings_Display(self, name='display')
		self.auto			= Settings_Auto(self, name='auto')
	
	def reset(self) -> None:
		self._cited = set()
		self._evil_syntax = SettingHolder[bool](self,
									name="Evil Syntax",
									default_value=False)
		self._display_allow_unicode = SettingHolder[bool](self,
									name="Allow Unicode in display",
									default_value=True)
		# self._display_indent = SettingHolder[str | None](self,
		# 							name="Display indentation",
		# 							default_value=None)
		self._display_infix_nonspecial_funcs = SettingHolder[bool](self,
									name="Display nonspecial binary function symbols as infix",
									default_value=True)
		self._display_infix_nonspecial_ops = SettingHolder[bool](self,
									name="Display nonspecial binary operators as infix",
									default_value=True)
		self._display_infix_nonspecial_preds = SettingHolder[bool](self,
									name="Display nonspecial binary predicate symbols as infix",
									default_value=True)
		self._display_infix_special_funcs = SettingHolder[bool](self,
									name="Display special binary function symbols as infix",
									default_value=True)
		self._display_infix_special_ops = SettingHolder[bool](self,
									name="Display special binary operators as infix",
									default_value=True)
		self._display_infix_special_preds = SettingHolder[bool](self,
									name="Display special binary predicate symbols as infix",
									default_value=True)
		self._resolve_empty_curry = SettingHolder[bool](self,
									name="Attempt to resolve currying when 0 arguments are given",
									default_value=True)
		self._resolve_multi_curry = SettingHolder[bool](self,
									name="Attempt to resolve currying when >= 1 arguments are given",
									default_value=True)
	
	def why(self) -> None:
		msg_start = "---------------- qmars ----------------"
		msg_end = msg_start
		print(			f"")
		print(			f"")
		print(			msg_start)
		print(			f"")
		print(			f"You have asked why(). "
						f"Perhaps a feature has been unclear, "
						f"or there's a bug roaming out there and has got your attention. "
						f"I will attempt to explain what has been done during the execution until now; "
						f"I hope that would help.")
		
		print(			f"")

		print(			f"The code run until now has (internally) cited the following settings for its decisions:")
		if len(self._cited) == 0:
			print(		f'  no data available; sorry. :(')
		for sh in self._cited:
			print(		f'  - "name: {sh.name}"')
			print(		f'      - current value: {sh.value}')
			if len(sh.modified_by) == 0:
				print(	f'      - not modified.')
			else:
				print(	f'      - modified by: '
					   + ', '.join([sm.name for sm in sh.modified_by]))

		print(			f"")
		print(			f" ---")
		print(			f"")

		print(			f"If you feel something's missing, "
						f"or that the default behavior is wrong, unexpected, or confusing, "
						f"please let {Me.me} know:")
		print(			f"  - {Me.last}, {Me.first}")
		print(			f"  - mail: {Me.mail}")
		print(			f"")
		print(			f"Thanks for being here! <3")
		print(			f"")
		print(			msg_end)
		print(			f"")
		print(			f"")



class SettingsMenu:
	def __init__(self, apply_to : Settings, *, name : str) -> None:
		self.name		= name
		self._settings	= apply_to


class Settings_EvilSyntax(SettingsMenu):
	def hehe(self) -> None:
		self._settings._evil_syntax.set(True, by=self)
	def not_hehe(self) -> None:
		self._settings._evil_syntax.set(False, by=self)


class Settings_Display(SettingsMenu):
	def __init__(self, apply_to: Settings, *, name : str) -> None:
		super().__init__(apply_to, name=name)
		# self.indent = Settings_Display_Indent(apply_to, name=makename(self.name, 'indent'))
		self.infix = Settings_Display_Infix(apply_to, name=makename(self.name, 'infix'))
		self.unicode = Settings_Display_Unicode(apply_to, name=makename(self.name, 'unicode'))


# class Settings_Display_Indent(SettingsMenu):
# 	def spaces(self, num : int) -> None:
# 		self._settings._display_indent.set(" "*num, by=self)
# 	def tabs(self, num : int) -> None:
# 		self._settings._display_indent.set("\t"*num, by=self)
# 	def none(self) -> None:
# 		self._settings._display_indent.set(None, by=self)


class Settings_Display_Infix(SettingsMenu):

	def none(self) -> None:
		self._settings._display_infix_nonspecial_funcs.set(False, by=self)
		self._settings._display_infix_nonspecial_ops.set(False, by=self)
		self._settings._display_infix_nonspecial_preds.set(False, by=self)
		self._settings._display_infix_special_funcs.set(False, by=self)
		self._settings._display_infix_special_ops.set(False, by=self)
		self._settings._display_infix_special_preds.set(False, by=self)
	
	def specials_only(self) -> None:
		self._settings._display_infix_nonspecial_funcs.set(False, by=self)
		self._settings._display_infix_nonspecial_ops.set(False, by=self)
		self._settings._display_infix_nonspecial_preds.set(False, by=self)
		self._settings._display_infix_special_funcs.set(True, by=self)
		self._settings._display_infix_special_ops.set(True, by=self)
		self._settings._display_infix_special_preds.set(True, by=self)

	def all(self) -> None:
		self._settings._display_infix_nonspecial_funcs.set(True, by=self)
		self._settings._display_infix_nonspecial_ops.set(True, by=self)
		self._settings._display_infix_nonspecial_preds.set(True, by=self)
		self._settings._display_infix_special_funcs.set(True, by=self)
		self._settings._display_infix_special_ops.set(True, by=self)
		self._settings._display_infix_special_preds.set(True, by=self)

class Settings_Display_Unicode(SettingsMenu):
	def enable(self) -> None:
		self._settings._display_allow_unicode.set(True, by=self)
	def disable(self) -> None:
		self._settings._display_allow_unicode.set(False, by=self)




class Settings_Auto(SettingsMenu):
	def __init__(self, apply_to: Settings, *, name : str) -> None:
		super().__init__(apply_to, name=name)
		self.deduce_empty_curry = Settings_Auto_DeduceEmptyCurry(apply_to,
									name=makename(self.name, 'deduce_empty_curry'))
		self.deduce_multiple_curry = Settings_Auto_DeduceMultipleCurry(apply_to,
									name=makename(self.name, 'deduce_multiple_curry'))


class Settings_Auto_DeduceEmptyCurry(SettingsMenu):

	def enable(self) -> None:
		self._settings._resolve_empty_curry.set(True, by=self)
	
	def disable(self) -> None:
		self._settings._resolve_empty_curry.set(False, by=self)


class Settings_Auto_DeduceMultipleCurry(SettingsMenu):

	def enable(self) -> None:
		self._settings._resolve_multi_curry.set(True, by=self)
	
	def disable(self) -> None:
		self._settings._resolve_multi_curry.set(False, by=self)




global_settings = Settings()
