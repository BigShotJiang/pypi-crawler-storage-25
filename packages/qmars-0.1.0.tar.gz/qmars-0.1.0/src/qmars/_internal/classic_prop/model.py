from __future__ import annotations

import qmars._internal.classic_fo.model as CFO_model
import qmars._internal.classic_prop.syntax as syntax

from qmars._internal.errors import UsageError


class Interpretation:

	_internal	: CFO_model.FiniteModel[None]

	def __init__(self) -> None:
		self._internal = CFO_model.FiniteModel[None]([None])
	
	def interpret(self, prop : syntax.Proposition, value : bool) -> None:
		if prop._underlying_pred == None or prop in [syntax.TRUE, syntax.FALSE]:
			msg = "Only atomic propositions (other than TRUE and FALSE) are allowed"
			raise UsageError(msg)
		def itpt() -> bool:
			return value
		self._internal.interpret_pred(prop._underlying_pred, itpt)
	
	def __call__(self, prop : syntax.Proposition) -> bool:
		return self._internal.models(prop.underlying)
	