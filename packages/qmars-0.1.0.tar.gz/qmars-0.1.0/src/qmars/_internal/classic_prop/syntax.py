from __future__ import annotations


import qmars._internal.classic_fo.syntax as CFO_syntax
import qmars._internal.foundation as fond


AND			= CFO_syntax.AND
IFF			= CFO_syntax.IFF
IMPLIES		= CFO_syntax.IMPLIES
LEFTARROW	= CFO_syntax.LEFTARROW
NAND		= CFO_syntax.NAND
NOR			= CFO_syntax.NOR
NOT			= CFO_syntax.NOT
OR			= CFO_syntax.OR
RIGHTARROW	= CFO_syntax.RIGHTARROW
XNOR		= CFO_syntax.XNOR
XOR			= CFO_syntax.XOR


class Boolean(CFO_syntax.Boolean): pass

class Proposition(fond.SymbolType):

	name				: str
	name_ascii			: str | None
	underlying			: CFO_syntax.Formula[None]
	_underlying_pred	: CFO_syntax.PredSymbol[None] | None

	def __init__(self,
				name : str,
				name_ascii : str | None = None,
				*,
				_underlying_formula : CFO_syntax.Formula[None] | None = None,
			) -> None:
		super().__init__()
		self.name		= name
		self.name_ascii	= name_ascii
		if _underlying_formula == None:
			self._underlying_pred	= CFO_syntax.PredSymbol(0, name, name_ascii)
			self.underlying			= self._underlying_pred()
		else:
			self.underlying			= _underlying_formula
			self._underlying_pred	= None
	
	def __and__(self, other : Proposition) -> Proposition:
		return Proposition(f"AND({self}, {other})", None,
			_underlying_formula=AND(self.underlying, other.underlying),
		)
	def __or__(self, other : Proposition) -> Proposition:
		return Proposition(f"OR({self}, {other})", None,
			_underlying_formula=OR(self.underlying, other.underlying),
		)
	def __invert__(self) -> Proposition:
		return Proposition(f"NOT({self})", None,
			_underlying_formula=NOT(self.underlying),
		)
	def __rshift__(self, other : Proposition) -> Proposition:
		return Proposition(f"RIGHTARROW({self}, {other})", None,
			_underlying_formula=RIGHTARROW(self.underlying, other.underlying),
		)
	def __lshift__(self, other : Proposition) -> Proposition:
		return Proposition(f"LEFTARROW({self}, {other})", None,
			_underlying_formula=LEFTARROW(self.underlying, other.underlying),
		)
	def implies(self, other : Proposition) -> Proposition:
		return Proposition(f"IMPLIES({self}, {other})", None,
			_underlying_formula=IMPLIES(self.underlying, other.underlying),
		)
	def iff(self, other : Proposition) -> Proposition:
		return Proposition(f"IFF({self}, {other})", None,
			_underlying_formula=IFF(self.underlying, other.underlying),
		)

FALSE		= Proposition("⊥", "FALSE", _underlying_formula=CFO_syntax.FALSE)
TRUE		= Proposition("⊤", "TRUE", _underlying_formula=CFO_syntax.TRUE)