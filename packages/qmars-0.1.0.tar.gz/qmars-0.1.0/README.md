# qmars: A Proof Assistant in Python

Version 0.1.0; still under development.

You may find me at ali.hadizadeh atsymbol sharif dot edu.
