# Organic Content Frameworks

Structures for Reels, TikTok, and carousels. These differ from paid ad frameworks - organic prioritizes value and engagement over direct conversion.

---

## Core Principle: Hook-Retain-Reward

Every piece of organic content follows this structure:

```
HOOK (0-3 seconds)
Stop the scroll. Create curiosity or recognition.

RETAIN (3-45 seconds)
Deliver value. Maintain attention through the middle.

REWARD (final 5-15 seconds)
Payoff the hook. Soft CTA.
```

**Why this works:** Algorithms favor watch time and saves. Content that delivers value gets pushed to more people.

---

## Saves-First Content Design

**Why saves matter most:** TikTok Shop meta-analysis (Q4 2025) shows saves are the #1 purchase intent signal — ahead of shares, comments, and likes. People save content they plan to act on. Saveable content = educational, actionable, reference-worthy.

### The Save-Ability Test

Before finalizing any script, ask:

| Question | If yes | If no |
|----------|--------|-------|
| Would someone come back to this? | Save-worthy — keep | Rethink the value density |
| Does this teach a framework or give a step-by-step? | High save signal | Consider adding structure |
| Could someone screenshot this for later? | Save-worthy | Increase actionable specificity |
| Is this entertaining but not actionable? | Share-worthy (good for reach, not intent) | Fine for awareness, won't drive saves |

### Metric Hierarchy for Purchase Intent

1. **Saves** — Strongest intent signal. They want to use this.
2. **Shares** — Social signal. They want others to see this.
3. **Comments** — Engagement signal. They want to discuss this.
4. **Likes** — Weakest signal. They acknowledged this.

Design for saves first. Shares follow naturally from strong content.

---

## Framework 1: Educational

**Structure:** Hook -> Tips/Steps -> Takeaway

**Best for:** How-to content, lists, advice, tutorials

### Components

| Section | Purpose | Example |
|---------|---------|---------|
| **Hook** | Promise specific value | "3 things I wish I knew before starting my business" |
| **Setup** | Brief context (optional) | "After 5 years of trial and error..." |
| **Tips 1-3** | One clear idea per beat | "First: Don't wait until you're ready" |
| **Takeaway** | Summarize or add perspective | "The real secret? Just start." |
| **CTA** | Soft engagement ask | "Save this for when you need a reminder" |

### Timing (30-60 seconds)

```
Hook:     3 seconds
Setup:    5 seconds (optional)
Tip 1:    8 seconds
Tip 2:    8 seconds
Tip 3:    8 seconds
Takeaway: 5 seconds
CTA:      3 seconds
```

### Example Script

```
HOOK:
"3 mistakes killing your content (and what to do instead)"

RETAIN:
Mistake one: Posting without a hook.
Every scroll is a decision. Give them a reason to stop.

Mistake two: Trying to say too much.
One idea per post. That's it. Save the rest for tomorrow.

Mistake three: Skipping the CTA.
If you don't tell them what to do, they'll do nothing.

REWARD:
The fix? Hook. One idea. Clear ask. Repeat.

CTA:
Save this. You'll need it.
```

---

## Framework 2: Story-Based

**Structure:** Hook -> Trigger Event -> Journey -> Outcome -> Result

**Best for:** Personal narratives, lessons learned, case studies

### Components

| Section | Purpose | Example |
|---------|---------|---------|
| **Hook** | Tease the transformation | "This one decision changed everything" |
| **Trigger** | What happened to start the journey | "Three years ago, I got fired" |
| **Journey** | The struggle or process | "I tried everything. Nothing worked until..." |
| **Outcome** | What you discovered/did | "Then I realized I was solving the wrong problem" |
| **Result** | Where you are now | "Now I run a business I actually love" |
| **CTA** | Invite engagement | "Comment if you've been there" |

### Timing (45-90 seconds)

```
Hook:     3 seconds
Trigger:  10 seconds
Journey:  20-40 seconds
Outcome:  10 seconds
Result:   5 seconds
CTA:      3 seconds
```

### Example Script

```
HOOK:
"The hardest lesson I learned building my business"

TRIGGER:
Two years ago, I hit rock bottom.
Revenue was up, but I was miserable.
Working 80-hour weeks. Missing everything that mattered.

JOURNEY:
I tried time management apps. Delegation frameworks.
Productivity systems from every guru on the internet.
Nothing changed.

OUTCOME:
Then I realized: I wasn't overworked.
I was doing the wrong work.
Building someone else's version of success.

RESULT:
Now I make half what I used to.
And I've never been happier.

CTA:
Has anyone else been through this? Drop a comment.
```

---

## Framework 3: Transformation

**Structure:** Before -> Turning Point -> After

**Best for:** Journey content, case studies, before/after reveals

### Components

| Section | Purpose | Example |
|---------|---------|---------|
| **Hook** | Tease the gap | "6 months ago vs today" |
| **Before** | Where you/they started | "I was posting every day with zero engagement" |
| **Turning Point** | What changed | "Then I stopped chasing views and started this instead" |
| **After** | Where you/they are now | "Now my content actually converts" |
| **Bridge** | How they can do it too | "Here's what I changed..." |
| **CTA** | Soft ask | "Follow for more breakdowns like this" |

### Timing (30-60 seconds)

```
Hook:           3 seconds
Before:         10 seconds
Turning Point:  10 seconds
After:          10 seconds
Bridge:         10 seconds
CTA:            3 seconds
```

### Example Script

```
HOOK:
"What changed when I stopped trying to go viral"

BEFORE:
Six months ago, I was obsessed with views.
Posting three times a day.
Copying trends. Chasing algorithms.
My content was everywhere. My business? Nowhere.

TURNING POINT:
Then I asked myself one question:
"What do I actually want people to DO?"
Not watch. DO.

AFTER:
Now I post half as much.
Get fewer views.
And my DMs are full of people ready to buy.

BRIDGE:
The shift? I stopped making content for the algorithm.
Started making content for my actual customer.

CTA:
Save this if you needed to hear it.
```

---

## Framework 4: Problem-Solution (PAS for Organic)

**Structure:** Hook (Problem) -> Agitate -> Solution -> Proof

**Best for:** Pain point content, myth-busting, "stop doing this"

### Components

| Section | Purpose | Example |
|---------|---------|---------|
| **Hook** | Name the problem | "This 'advice' is ruining your content" |
| **Problem** | Describe the pain | "You've heard you need to post every day" |
| **Agitate** | Make it worse | "So you burn out. Quality drops. Engagement tanks." |
| **Solution** | Present the fix | "Here's what actually works..." |
| **Proof** | Why this works | "I tested this for 90 days..." |
| **CTA** | Engagement ask | "Comment 'LESS' if you're trying this" |

### Timing (30-45 seconds)

```
Hook:     3 seconds
Problem:  8 seconds
Agitate:  8 seconds
Solution: 10 seconds
Proof:    8 seconds
CTA:      3 seconds
```

### Example Script

```
HOOK:
"Stop batching your content. Seriously."

PROBLEM:
Everyone says batch create a month of content at once.
Sounds efficient, right?

AGITATE:
But here's what happens:
Week one content is fire.
Week four? Generic. Disconnected. Stale.
Because you're not in the same headspace you were when you wrote it.

SOLUTION:
Instead: Create same-day.
Not more content. Better content.
Content that matches your energy RIGHT NOW.

PROOF:
My engagement went up 40% when I stopped batching.
Because the content felt real. Because it was.

CTA:
Try it for one week. Comment and let me know what happens.
```

---

## Framework 5: Contrarian/Hot Take

**Structure:** Hook (Bold Claim) -> Evidence -> Reframe -> New Perspective

**Best for:** Challenging conventional wisdom, standing out, sparking discussion

### Components

| Section | Purpose | Example |
|---------|---------|---------|
| **Hook** | Make bold claim | "Consistency is overrated" |
| **Evidence** | Support the claim | "I've seen creators post daily and fail..." |
| **Reframe** | Shift perspective | "It's not about frequency. It's about..." |
| **New Perspective** | What to do instead | "Focus on resonance, not routine" |
| **CTA** | Invite debate | "Agree or disagree? Comment below" |

### Timing (30-45 seconds)

```
Hook:            3 seconds
Evidence:        10 seconds
Reframe:         10 seconds
New Perspective: 10 seconds
CTA:             3 seconds
```

### Example Script

```
HOOK:
"Niching down is bad advice. Here's why."

EVIDENCE:
I followed the niche-down playbook for two years.
Picked one topic. One format. One audience.
Know what happened? I got bored. My content got boring.
And my growth flatlined.

REFRAME:
The real rule isn't "niche down."
It's "be known for something."

NEW PERSPECTIVE:
You can talk about multiple things.
As long as they all point back to your core perspective.
Your ANGLE is your niche. Not your topic.

CTA:
Hot take or truth? Tell me in the comments.
```

---

## Choosing the Right Framework

| Content Type | Best Framework |
|--------------|----------------|
| How-to, tutorial | Educational |
| Personal story | Story-Based |
| Before/after, case study | Transformation |
| Myth-busting, "stop doing X" | Problem-Solution |
| Bold opinion, debate starter | Contrarian |

---

## Hook Formulas

Strong hooks create curiosity or recognition. Use these patterns:

### Curiosity Hooks

- "The one thing [successful people] do that you don't"
- "This changed everything for me"
- "Nobody talks about this, but..."
- "I was today years old when I learned..."
- "Here's why [common advice] is wrong"

### Recognition Hooks

- "POV: You just realized [relatable thing]"
- "When [specific situation] happens and you [relatable response]"
- "You're not [negative label]. You're just [reframe]"
- "[Number] signs you're actually [positive identity]"

### Controversy Hooks

- "Unpopular opinion: [bold claim]"
- "Stop [common behavior]. Here's why."
- "[Common advice] is ruining your [outcome]"
- "I'm going to get hate for this, but..."

### Story Hooks

- "The day I [pivotal moment]"
- "I almost [gave up/quit/failed], then this happened"
- "Nobody knew this about me until now"
- "This is the story I never told"

### Enemy-Driven Hooks

Named enemies create identity contrast. Each content pillar should fight a concept (never a person or company). Use the enemy as the hook, then pivot to your position.

**Pattern:** "[Enemy] is [destroying/costing/stealing] [specific thing]. Here's what to do instead."

**Examples by enemy:**
- **Complexity:** "You don't need 47 tools to run a business. You need 3."
- **Screen addiction:** "The best business decision I made this year was closing my laptop at 3pm."
- **Sounding like AI:** "If your content could have been written by ChatGPT, nobody will save it."
- **Rented infrastructure:** "Your business lives on someone else's server. What happens when they change the rules?"

**Rules:**
- Enemy is always a concept, never a person or company
- Name it explicitly — vague enemies ("the system") don't land
- Each pillar fights one primary enemy
- Enemy hooks work best with Contrarian and Problem-Solution frameworks

---

## Retention Techniques

Keep viewers watching through the middle:

### Pattern Interrupts

Change the visual or vocal pattern every 5-8 seconds:
- Change camera angle
- Add text overlay
- Shift energy/tone
- Use jump cuts

### Open Loops

Create mini-cliffhangers:
- "But that's not the crazy part..."
- "And then I made a mistake..."
- "Wait, it gets better..."

### Value Stacking

Each beat should feel like its own payoff:
- "First... Second... But here's the real secret..."
- Give 80% of value before asking for anything

---

## Soft CTAs for Organic

Organic content uses soft CTAs that prioritize engagement over conversion:

| Hard CTA (Avoid) | Soft CTA (Use) |
|------------------|----------------|
| "Link in bio to buy" | "Save this for later" |
| "Sign up now" | "Follow for more like this" |
| "Limited time offer" | "Comment [word] if you want more" |
| "Don't miss out" | "Share with someone who needs this" |
| "DM me to work together" | "Tag a friend who's going through this" |

**Exception:** If the user's voice file shows they successfully use harder CTAs, match their style.

Comment-keyword and DM-keyword CTAs can be drafted as strategy, but Main Branch
does not execute comment-to-DM, auto-reply, follow, or inbox automation through
organic generation. Fulfillment stays manual or inside a separately approved
provider path.

For X/Twitter, prefer public resource delivery: put the resource in the post,
thread, repo link, landing page, or a manual public reply/link playbook. Do not
frame "comment for the DM" as a Main Branch-executable workflow. If the plan
needs to persist, save it as `pushes/<push>/playbooks/<playbook>.md` with
`type: playbook`; the file is an approval record and setup recipe, not an
automation run.

---

## Platform-Specific Notes

### Instagram Reels

- Optimal length: 15-30 seconds (up to 60 for story content)
- First frame matters (appears in grid)
- Captions should complement, not repeat
- Save-worthy content gets boosted

### TikTok

- Can go longer (60-90 seconds) if retention stays high
- Hook must work with sound off
- Trends can be adapted but not required
- Stitch/duet opportunities increase reach

### Both Platforms

- Watch time > views
- Saves > likes
- Comments > shares (for engagement signal)
- Reply to comments quickly (boosts distribution)
