---
name: mb-status
description: "Thin Main Branch status wrapper. Use when the operator asks what changed, what is healthy, what is stale, what to do next, or wants a daily briefing inside Claude Code."
loops: [sense]
---

# Status

Show the operator the deterministic Main Branch briefing without duplicating
repo-health checks in prose.

**CLI facts first:** Run `mb status --json --peek` before answering, then use
that JSON as the source of truth.

## Workflow

1. Confirm you are in the business repo. If not, ask the operator to `cd` into
   the business repo or pass the repo path.
2. Run:

```bash
mb status --json --peek
```

3. Treat the JSON as the source of truth for setup, update, drift, GitHub,
   onboarding, integrations, team, bets, journal activity, since-last-check,
   readiness, vocabulary, content_strategy, money_path, and ranked actions.
4. Summarize the top `ranked_actions` first. For each one, include:
   - title
   - command or slash command
   - reason
   - cited signal summaries
5. Then summarize only the sections that matter for the operator's question.
   Use `money_path` when the question is about the path from customer progress
   to offer, proof, CTA, channel, push, playbook, page readiness, or outcome
   feedback. Keep the language evidence-based: legible, supported, connected,
   instrumented. Do not say the offer is good, bad, likely to convert, or ready
   to win.
   Use `content_strategy` when the question is about content strategy health,
   layered channel/account/person files, stale platform rules, or disconnected
   content layers. Do not infer that health by parsing markdown yourself unless
   status says the section is unavailable.
   If `vocabulary.terms.push` defines display words, use them in
   operator-facing prose without changing current paths, frontmatter, JSON
   keys, validator rules, or command names.
   Use `team` facts and GitHub activity `author_display` / `author_known` fields
   when naming people; keep unknown contributors as handles.
   Do not re-run shell probes that duplicate status facts.
   For "what changed?" or "what happened since last time?", answer from
   `since_last_check.journal` first, then top-level `journal` for recent
   context.
6. If provider readiness is the question, use `integrations.github` and
   `integrations.providers` from status first. If the operator needs choices or
   repair commands, run:

```bash
mb connect plan
mb connect doctor --json
```

Summarize GitHub, Cloudflare, Google/Workspace, Meta Ads, and Apify as numbered
business choices. Use the CLI's `next_command` or `repair_command`; do not ask
the operator to paste tokens into files or public issue text.

## Mutating The Last-Check Marker

`--peek` is the default inside this skill because a conversation may inspect
status before the operator is ready to record a daily check.

If the operator explicitly says this is the daily check-in and wants it
recorded, run:

```bash
mb status --json
```

Use the new report for the answer.

## Privacy

Respect each action and signal's `safe_to_share` field. If `safe_to_share` is
false, keep evidence local to the conversation and do not suggest pasting it
into public GitHub without review.
