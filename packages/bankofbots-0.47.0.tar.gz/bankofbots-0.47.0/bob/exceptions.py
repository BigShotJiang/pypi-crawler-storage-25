"""Typed exceptions for the Bank of Bots SDK."""


class BoBError(Exception):
    """Base exception for all SDK errors."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class AuthenticationError(BoBError):
    """Raised on 401 — invalid or missing API key."""

    def __init__(self, message: str = "invalid or missing api key"):
        super().__init__(message, status_code=401)


class ForbiddenError(BoBError):
    """Raised on 403 — valid key but insufficient permissions."""

    def __init__(self, message: str = "access denied"):
        super().__init__(message, status_code=403)


class NotFoundError(BoBError):
    """Raised on 404 — resource does not exist."""

    def __init__(self, message: str = "resource not found"):
        super().__init__(message, status_code=404)


class ConflictError(BoBError):
    """Raised on 409 — request conflicts with current server state.

    Common cause: attempting to create a second agent for an operator that
    already has one (one-agent-per-operator constraint).
    """

    def __init__(self, message: str = "resource conflict"):
        super().__init__(message, status_code=409)
