import pandas as pd
import sys
from .analyzer import analyze

def main():
    if len(sys.argv) < 2:
        print("Usage: autoeda <file.csv>")
        return

    file = sys.argv[1]

    try:
        df = pd.read_csv(file)
    except Exception as e:
        print("Error reading file:", e)
        return

    analyze(df)