import matplotlib.pyplot as plt
import seaborn as sns

def plot_missing(df):
    plt.figure()
    sns.heatmap(df.isnull(), cbar=False)
    plt.title("Missing Values Heatmap")
    plt.show()

def plot_corr(df):
    plt.figure()
    corr = df.corr(numeric_only=True)
    sns.heatmap(corr, annot=True)
    plt.title("Correlation Matrix")
    plt.show()