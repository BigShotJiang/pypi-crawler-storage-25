import pandas as pd
from .visualizer import plot_missing, plot_corr
from .insights import generate_insights

def analyze(df: pd.DataFrame):
    print("\n BASIC INFO")
    print(df.info())

    print("\n SUMMARY STATS")
    print(df.describe())

    print("\n MISSING VALUES")
    missing = df.isnull().sum()
    print(missing)

    print("\n DUPLICATES:", df.duplicated().sum())

    plot_missing(df)
    plot_corr(df)

    generate_insights(df)
