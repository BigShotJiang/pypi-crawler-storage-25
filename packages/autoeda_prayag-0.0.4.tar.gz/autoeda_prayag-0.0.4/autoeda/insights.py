def generate_insights(df):
    print("\n INSIGHTS:")

    if df.isnull().sum().sum() > 0:
        print("- Missing values detected. Consider imputation.")

    if df.duplicated().sum() > 0:
        print("- Duplicate rows found. Consider removing them.")

    if len(df.columns) > 15:
        print("- High number of features. Feature selection may help.")

    numeric = df.select_dtypes(include="number")

    if not numeric.empty:
        if numeric.var().mean() < 1:
            print("- Low variance detected. Scaling recommended.")