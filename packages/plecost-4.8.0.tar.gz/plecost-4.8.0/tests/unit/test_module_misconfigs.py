import pytest
import respx
import httpx
from plecost.engine.context import ScanContext
from plecost.engine.http_client import PlecostHTTPClient
from plecost.models import ScanOptions, Severity
from plecost.modules.misconfigs import MisconfigsModule


@pytest.fixture
def ctx():
    ctx = ScanContext(ScanOptions(url="https://example.com"))
    ctx.is_wordpress = True
    return ctx


async def test_detects_wp_config_exposed(ctx):
    async with respx.mock:
        respx.get("https://example.com/wp-config.php").mock(
            return_value=httpx.Response(200, text="<?php define('DB_PASSWORD', 'secret');")
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert any(f.id == "PC-MCFG-001" for f in ctx.findings)
    assert any(f.severity == Severity.CRITICAL for f in ctx.findings)


async def test_detects_env_file(ctx):
    """AC-2 (existing): /.env returns 200 with text/plain content → emits PC-MCFG-003."""
    async with respx.mock:
        respx.get("https://example.com/.env").mock(
            return_value=httpx.Response(
                200, text="DB_PASSWORD=secret",
                headers={"content-type": "text/plain"}
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert any(f.id == "PC-MCFG-003" for f in ctx.findings)


async def test_env_soft404_html_response_no_finding(ctx):
    """AC-1: /.env returns 200 + Content-Type text/html (WordPress soft-404) → NO PC-MCFG-003."""
    async with respx.mock:
        respx.get("https://example.com/.env").mock(
            return_value=httpx.Response(
                200,
                text="<html><body>Envios y devoluciones</body></html>",
                headers={"content-type": "text/html; charset=utf-8"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert not any(f.id == "PC-MCFG-003" for f in ctx.findings)


async def test_env_plaintext_response_emits_finding(ctx):
    """AC-2: /.env returns 200 + Content-Type text/plain with env-like content → SÍ PC-MCFG-003."""
    async with respx.mock:
        respx.get("https://example.com/.env").mock(
            return_value=httpx.Response(
                200,
                text="APP_KEY=base64:abc123\nDB_PASSWORD=supersecret\n",
                headers={"content-type": "text/plain"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert any(f.id == "PC-MCFG-003" for f in ctx.findings)


async def test_env_redirect_to_different_url_no_finding(ctx):
    """AC-3: /.env redirects to a different URL → NO PC-MCFG-003 (soft-404 redirect detection)."""
    async with respx.mock:
        # httpx follows the redirect automatically; the final response URL will be the destination.
        # We mock the destination URL directly so httpx sees a 200 at the redirected location.
        respx.get("https://example.com/.env").mock(
            return_value=httpx.Response(
                301,
                headers={"location": "https://example.com/envios-y-devoluciones/"},
            )
        )
        respx.get("https://example.com/envios-y-devoluciones/").mock(
            return_value=httpx.Response(
                200,
                text="<html><body>Envios y devoluciones page</body></html>",
                headers={"content-type": "text/html; charset=utf-8"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert not any(f.id == "PC-MCFG-003" for f in ctx.findings)


async def test_no_findings_if_all_404(ctx):
    async with respx.mock:
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    misconfig_findings = [f for f in ctx.findings if f.id.startswith("PC-MCFG")]
    assert len(misconfig_findings) == 0


async def test_misconfigs_debug_log_accessible(ctx):
    """GET /wp-content/debug.log returning 200 with content must emit a finding."""
    async with respx.mock:
        # MisconfigsModule checks /debug.log (not /wp-content/debug.log) — see _CHECKS
        respx.get("https://example.com/debug.log").mock(
            return_value=httpx.Response(200, text="[13-Apr-2026 12:00:00 UTC] PHP Notice: ...")
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404, text="Not Found"))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)

    assert any(f.id == "PC-MCFG-005" for f in ctx.findings)


async def test_misconfigs_htaccess_accessible(ctx):
    """GET /.htaccess returning 200 must NOT emit any finding — .htaccess is not in _CHECKS."""
    async with respx.mock:
        respx.get("https://example.com/.htaccess").mock(
            return_value=httpx.Response(200, text="Options -Indexes\nDeny from all")
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404, text="Not Found"))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)

    # .htaccess is NOT in _CHECKS — the module must not emit a finding for it.
    # If a bug added .htaccess detection without a proper check list entry, this test
    # would catch it.  The previous assertion (isinstance(list, list)) was always True
    # and would not catch such a bug.
    htaccess_findings = [f for f in ctx.findings if "htaccess" in f.title.lower()]
    assert htaccess_findings == [], (
        ".htaccess is not in _CHECKS — no PC-MCFG finding should be emitted for it"
    )


async def test_misconfigs_no_false_positives_on_404(ctx):
    """All sensitive endpoints returning 404 must produce zero misconfig findings."""
    async with respx.mock:
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404, text="Not Found"))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)

    misconfig_findings = [f for f in ctx.findings if f.id.startswith("PC-MCFG")]
    assert len(misconfig_findings) == 0


# -----------------------------------------------------------------------
# New findings: AC-1 to AC-4
# -----------------------------------------------------------------------

async def test_pc_mcfg_013_wp_content_debug_log(ctx):
    """AC-1: /wp-content/debug.log accessible with plaintext content → PC-MCFG-013 HIGH."""
    async with respx.mock:
        respx.get("https://example.com/wp-content/debug.log").mock(
            return_value=httpx.Response(
                200,
                text="[13-Apr-2026 12:00:00 UTC] PHP Notice: error in /var/www",
                headers={"content-type": "text/plain"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    ids = [f.id for f in ctx.findings]
    assert "PC-MCFG-013" in ids
    f = next(f for f in ctx.findings if f.id == "PC-MCFG-013")
    assert f.severity == Severity.HIGH


async def test_pc_mcfg_013_not_triggered_on_html_response(ctx):
    """AC-1: /wp-content/debug.log returns HTML (soft-404) → no PC-MCFG-013."""
    async with respx.mock:
        respx.get("https://example.com/wp-content/debug.log").mock(
            return_value=httpx.Response(
                200,
                text="<html><body>Not found</body></html>",
                headers={"content-type": "text/html"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert not any(f.id == "PC-MCFG-013" for f in ctx.findings)


async def test_pc_mcfg_014_adminer_with_signature(ctx):
    """AC-2: /adminer.php with 'class Adminer' in body → PC-MCFG-014 CRITICAL."""
    async with respx.mock:
        respx.get("https://example.com/adminer.php").mock(
            return_value=httpx.Response(
                200,
                text="<!doctype html><html><body>class Adminer { ... }</body></html>",
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    ids = [f.id for f in ctx.findings]
    assert "PC-MCFG-014" in ids
    f = next(f for f in ctx.findings if f.id == "PC-MCFG-014")
    assert f.severity == Severity.CRITICAL


async def test_pc_mcfg_014_not_triggered_without_signature(ctx):
    """AC-2: /adminer.php without 'class Adminer' in body → no PC-MCFG-014."""
    async with respx.mock:
        respx.get("https://example.com/adminer.php").mock(
            return_value=httpx.Response(200, text="<html><body>something else</body></html>")
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert not any(f.id == "PC-MCFG-014" for f in ctx.findings)


async def test_pc_mcfg_015_wp_config_tilde(ctx):
    """AC-3: /wp-config.php~ with plaintext content → PC-MCFG-015 CRITICAL."""
    async with respx.mock:
        respx.get("https://example.com/wp-config.php~").mock(
            return_value=httpx.Response(
                200,
                text="<?php // WordPress config\ndefine('DB_PASSWORD','secret');",
                headers={"content-type": "text/plain"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    ids = [f.id for f in ctx.findings]
    assert "PC-MCFG-015" in ids
    f = next(f for f in ctx.findings if f.id == "PC-MCFG-015")
    assert f.severity == Severity.CRITICAL


async def test_pc_mcfg_016_wp_config_old(ctx):
    """AC-3: /wp-config.php.old → PC-MCFG-016 CRITICAL."""
    async with respx.mock:
        respx.get("https://example.com/wp-config.php.old").mock(
            return_value=httpx.Response(
                200, text="define('DB_HOST','localhost');",
                headers={"content-type": "text/plain"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert any(f.id == "PC-MCFG-016" for f in ctx.findings)


async def test_pc_mcfg_017_wp_config_bak(ctx):
    """AC-3: /wp-config.php_bak → PC-MCFG-017 CRITICAL."""
    async with respx.mock:
        respx.get("https://example.com/wp-config.php_bak").mock(
            return_value=httpx.Response(
                200, text="DB_NAME=wordpress",
                headers={"content-type": "text/plain"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert any(f.id == "PC-MCFG-017" for f in ctx.findings)


async def test_pc_mcfg_018_wp_config_orig(ctx):
    """AC-3: /wp-config.php.orig → PC-MCFG-018 CRITICAL."""
    async with respx.mock:
        respx.get("https://example.com/wp-config.php.orig").mock(
            return_value=httpx.Response(
                200, text="define('DB_PASSWORD','secret');",
                headers={"content-type": "text/plain"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert any(f.id == "PC-MCFG-018" for f in ctx.findings)


async def test_pc_mcfg_019_wp_config_save(ctx):
    """AC-3: /wp-config.php.save → PC-MCFG-019 CRITICAL."""
    async with respx.mock:
        respx.get("https://example.com/wp-config.php.save").mock(
            return_value=httpx.Response(
                200, text="define('DB_PASSWORD','secret');",
                headers={"content-type": "text/plain"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert any(f.id == "PC-MCFG-019" for f in ctx.findings)


async def test_pc_mcfg_020_database_sql(ctx):
    """AC-4: /database.sql accessible with plaintext → PC-MCFG-020 HIGH."""
    async with respx.mock:
        respx.get("https://example.com/database.sql").mock(
            return_value=httpx.Response(
                200,
                text="-- MySQL dump\nCREATE TABLE wp_users",
                headers={"content-type": "text/plain"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    ids = [f.id for f in ctx.findings]
    assert "PC-MCFG-020" in ids
    f = next(f for f in ctx.findings if f.id == "PC-MCFG-020")
    assert f.severity == Severity.HIGH


# -----------------------------------------------------------------------
# AC-3 negative: wp-config variants with HTML soft-404 → no finding
# -----------------------------------------------------------------------

async def test_pc_mcfg_015_not_triggered_on_html_response(ctx):
    """AC-3: /wp-config.php~ returns HTML (soft-404) → no PC-MCFG-015."""
    async with respx.mock:
        respx.get("https://example.com/wp-config.php~").mock(
            return_value=httpx.Response(
                200,
                text="<html><body>Page not found</body></html>",
                headers={"content-type": "text/html"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert not any(f.id == "PC-MCFG-015" for f in ctx.findings)


async def test_pc_mcfg_016_not_triggered_on_html_response(ctx):
    """AC-3: /wp-config.php.old returns HTML (soft-404) → no PC-MCFG-016."""
    async with respx.mock:
        respx.get("https://example.com/wp-config.php.old").mock(
            return_value=httpx.Response(
                200,
                text="<html><body>Page not found</body></html>",
                headers={"content-type": "text/html"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert not any(f.id == "PC-MCFG-016" for f in ctx.findings)


# -----------------------------------------------------------------------
# AC-4 negative: database.sql with HTML soft-404 → no finding
# -----------------------------------------------------------------------

async def test_pc_mcfg_020_not_triggered_on_html_response(ctx):
    """AC-4: /database.sql returns HTML (soft-404) → no PC-MCFG-020."""
    async with respx.mock:
        respx.get("https://example.com/database.sql").mock(
            return_value=httpx.Response(
                200,
                text="<html><body>Page not found</body></html>",
                headers={"content-type": "text/html"},
            )
        )
        respx.route(url__regex=r".*").mock(return_value=httpx.Response(404))
        async with PlecostHTTPClient(ctx.opts) as http:
            await MisconfigsModule().run(ctx, http)
    assert not any(f.id == "PC-MCFG-020" for f in ctx.findings)
