"""Brute force credential attack module (subpackage)."""
from plecost.modules.brute.module import BruteModule

__all__ = ["BruteModule"]
