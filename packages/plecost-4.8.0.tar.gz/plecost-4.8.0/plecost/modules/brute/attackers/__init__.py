"""Attacker implementations for the brute module."""
