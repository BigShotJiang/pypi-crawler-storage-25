"""
YAML config loader/writer for dev-vault.

Config stores metadata only -- secrets live in the OS keyring.

Schema:
  version: 1
  defaults:
    vault: default
  vaults:
    default:
      items:
        datadog:
          kind: static
          fields: [api_key, app_key]
    prod:
      items:
        admin@example.com:
          kind: oidc
          provider: keycloak
          config:
            sso_url: https://sso.example.com/realms/Production
            auth_type: user
            email: admin@example.com
            client_id: delivery-ops-frontend-client
          fields: [password]
"""

import os
import shutil
import logging
import yaml
from datetime import datetime
from typing import Dict, Any, Optional, List

logger = logging.getLogger(__name__)

CONFIG_DIR = os.path.expanduser("~/.config/dev-vault")
CONFIG_FILENAME = "config.yaml"
FALLBACK_FILENAME = ".dv.yaml"


def find_config_path() -> str:
    """Return the config file path, checking in order:
    1. DV_CONFIG env var
    2. ~/.config/dev-vault/config.yaml
    3. ~/.dv.yaml
    """
    env_path = os.environ.get("DV_CONFIG", "")
    if env_path and os.path.exists(env_path):
        # Validate ownership: config file must belong to current user
        try:
            stat = os.stat(env_path)
            if stat.st_uid != os.getuid():
                logger.warning(
                    "DV_CONFIG=%s is owned by uid %d, not current user %d. Ignoring.",
                    env_path, stat.st_uid, os.getuid(),
                )
            else:
                logger.debug("Config found at %s (DV_CONFIG)", env_path)
                return env_path
        except OSError:
            pass

    xdg_path = os.path.join(CONFIG_DIR, CONFIG_FILENAME)
    if os.path.exists(xdg_path):
        logger.debug("Config found at %s", xdg_path)
        return xdg_path

    fallback = os.path.expanduser(f"~/{FALLBACK_FILENAME}")
    if os.path.exists(fallback):
        logger.debug("Config found at %s", fallback)
        return fallback

    logger.debug("No config found, defaulting to %s", xdg_path)
    return xdg_path


def load_config(path: Optional[str] = None) -> Dict[str, Any]:
    """Load and return the full config dict.

    Returns a normalized config with version and vaults keys.
    Raises FileNotFoundError if no config exists.
    """
    config_path = path or find_config_path()
    if not os.path.exists(config_path):
        raise FileNotFoundError(
            f"No config found at {config_path}. Run 'dv setup' to create one."
        )

    logger.debug("Loading config from %s", config_path)
    with open(config_path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    # Normalize to versioned format
    if "vaults" not in raw:
        raw = {"version": 1, "defaults": {"vault": "default"}, "vaults": {}}

    return raw


def save_config(config: Dict[str, Any], path: Optional[str] = None) -> str:
    """Write config to disk with restrictive permissions. Returns the path written to."""
    config_path = path or find_config_path()
    config_dir = os.path.dirname(config_path)
    if config_dir:
        os.makedirs(config_dir, mode=0o700, exist_ok=True)

    # Write with restrictive permissions (owner-only read/write)
    fd = os.open(config_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        yaml.dump(config, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
    # Ensure permissions are correct even if file existed before
    os.chmod(config_path, 0o600)
    logger.debug("Config saved to %s (mode 0600)", config_path)
    return config_path


def ensure_config() -> Dict[str, Any]:
    """Load config or create a minimal default if none exists."""
    try:
        return load_config()
    except FileNotFoundError:
        return {"version": 1, "defaults": {"vault": "default"}, "vaults": {}}


def get_vault(config: Dict[str, Any], vault_name: str) -> Dict[str, Any]:
    """Get or create a vault in the config."""
    vaults = config.setdefault("vaults", {})
    if vault_name not in vaults:
        vaults[vault_name] = {"items": {}}
    return vaults[vault_name]


def get_item(config: Dict[str, Any], vault_name: str, item_name: str) -> Optional[Dict[str, Any]]:
    """Get an item from a vault, or None if not found."""
    vault = config.get("vaults", {}).get(vault_name, {})
    return vault.get("items", {}).get(item_name)


def get_default_vault(config: Dict[str, Any]) -> str:
    """Return the default vault name from config."""
    return config.get("defaults", {}).get("vault", "default")


def list_all_items(config: Dict[str, Any]) -> List[Dict[str, str]]:
    """Return a flat list of all items across all vaults."""
    items = []
    for vault_name, vault_data in config.get("vaults", {}).items():
        for item_name, item_data in vault_data.get("items", {}).items():
            items.append({
                "vault": vault_name,
                "item": item_name,
                "kind": item_data.get("kind", "static"),
            })
    return items


def backup_config(config_path: str) -> str:
    """Move config to a timestamped backup. Returns the backup path."""
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    directory = os.path.dirname(config_path) or os.path.expanduser("~")
    backup_path = os.path.join(directory, f"backup_{ts}_{os.path.basename(config_path)}")
    shutil.move(config_path, backup_path)
    return backup_path
