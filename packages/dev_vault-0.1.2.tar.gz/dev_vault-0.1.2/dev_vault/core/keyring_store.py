"""
Secure secret storage via the system keyring.

Secrets are NEVER stored in YAML or environment variables.
This module is the single place that reads/writes them.

Keyring key format: {vault}/{item}/{field}
"""

import logging
import keyring
import keyring.errors
from typing import Optional

logger = logging.getLogger(__name__)

_SERVICE = "dev-vault"

# Characters that could enable path traversal or keyring key injection
_FORBIDDEN_CHARS = set("\x00\\/")  # null, backslash, forward slash (separator)
_MAX_NAME_LEN = 256


def _validate_name(name: str, label: str) -> None:
    """Validate vault/item/field names to prevent injection attacks."""
    if not name:
        raise ValueError(f"{label} name cannot be empty.")
    if len(name) > _MAX_NAME_LEN:
        raise ValueError(f"{label} name exceeds {_MAX_NAME_LEN} characters.")
    if any(c in _FORBIDDEN_CHARS for c in name):
        raise ValueError(f"{label} name contains forbidden characters.")
    if name.startswith(".") or ".." in name:
        raise ValueError(f"{label} name cannot start with '.' or contain '..'.")


def _key(vault: str, item: str, field: str) -> str:
    _validate_name(vault, "Vault")
    _validate_name(item, "Item")
    _validate_name(field, "Field")
    return f"{vault}/{item}/{field}"


def store_secret(vault: str, item: str, field: str, secret: str) -> None:
    """Persist a secret in the OS keyring."""
    key = _key(vault, item, field)
    keyring.set_password(_SERVICE, key, secret)
    logger.debug("Stored secret: %s/%s", _SERVICE, key)


def get_secret(vault: str, item: str, field: str) -> Optional[str]:
    """Retrieve a secret from the OS keyring (None if not found)."""
    key = _key(vault, item, field)
    result = keyring.get_password(_SERVICE, key)
    logger.debug("Keyring lookup %s/%s: %s", _SERVICE, key, "found" if result else "NOT FOUND")
    return result


def delete_secret(vault: str, item: str, field: str) -> None:
    """Remove a secret from the OS keyring (no-op if absent)."""
    try:
        keyring.delete_password(_SERVICE, _key(vault, item, field))
    except keyring.errors.PasswordDeleteError:
        pass


def get_secret_legacy(env_key: str, user_key: str) -> Optional[str]:
    """Read from the old sso-cli keyring format for migration."""
    return keyring.get_password("sso-cli", f"{env_key}/{user_key}")
