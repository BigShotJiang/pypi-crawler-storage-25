"""
Project manifest parser for .dv.yaml files.

A .dv.yaml file declares which secrets a project needs:

  secrets:
    DD_API_KEY: datadog/api_key
    DD_APP_KEY: datadog/app_key
    BEARER_TOKEN: prod/admin@example.com
"""

import os
import logging
import yaml
from typing import Dict, Optional

logger = logging.getLogger(__name__)

MANIFEST_FILENAME = ".dv.yaml"


def find_manifest(start_dir: Optional[str] = None) -> Optional[str]:
    """Walk up from start_dir looking for .dv.yaml. Returns path or None."""
    current = start_dir or os.getcwd()
    while True:
        candidate = os.path.join(current, MANIFEST_FILENAME)
        if os.path.exists(candidate):
            logger.debug("Manifest found at %s", candidate)
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            break
        current = parent
    return None


def load_manifest(path: Optional[str] = None) -> Dict[str, str]:
    """Load .dv.yaml and return {ENV_VAR: secret_ref} mapping.

    Raises FileNotFoundError if no manifest found.
    """
    manifest_path = path or find_manifest()
    if not manifest_path:
        raise FileNotFoundError(
            f"No {MANIFEST_FILENAME} found in current directory or parents."
        )

    with open(manifest_path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    secrets = raw.get("secrets", {})
    if not isinstance(secrets, dict):
        raise ValueError(f"Invalid manifest: 'secrets' must be a mapping.")

    logger.debug("Loaded %d secret(s) from %s", len(secrets), manifest_path)
    return secrets
