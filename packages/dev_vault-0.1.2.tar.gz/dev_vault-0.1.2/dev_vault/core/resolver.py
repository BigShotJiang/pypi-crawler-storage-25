"""
Resolve secret references to (vault, item, field) tuples.

Supported formats:
  dv://vault/item/field     -- full URI
  dv://vault/item           -- field omitted (primary)
  dv://item                 -- vault + field omitted
  vault/item/field          -- shorthand (no scheme)
  vault/item                -- shorthand, field omitted
  item                      -- just item name (default vault, primary field)
"""

import re
from typing import Tuple, Optional

_URI_PATTERN = re.compile(r"^dv://(.+)$")

DEFAULT_VAULT = "default"
DEFAULT_FIELD = "value"
OIDC_TOKEN_FIELD = "access_token"


def resolve(
    ref: str,
    default_vault: str = DEFAULT_VAULT,
    known_vaults: list = None,
) -> Tuple[str, str, Optional[str]]:
    """Parse a secret reference into (vault, item, field).

    field=None means "use the primary field" -- caller decides what that is
    based on item kind (static -> first/only field, oidc -> access_token).

    When known_vaults is provided, 2-part refs are disambiguated:
      - If part[0] is a known vault -> (vault, item, None)
      - Otherwise -> (default_vault, item, field)
    """
    # Strip dv:// prefix if present
    m = _URI_PATTERN.match(ref)
    path = m.group(1) if m else ref

    parts = path.split("/")

    if len(parts) == 3:
        return parts[0], parts[1], parts[2]
    elif len(parts) == 2:
        if known_vaults and parts[0] not in known_vaults:
            # Treat as item/field in default vault
            return default_vault, parts[0], parts[1]
        return parts[0], parts[1], None
    elif len(parts) == 1:
        return default_vault, parts[0], None
    else:
        raise ValueError(f"Invalid secret reference: {ref}")


def resolve_prefix(query: str, options: list, label: str) -> str:
    """Resolve a prefix to a unique match in options."""
    if query in options:
        return query
    matches = [o for o in options if o.startswith(query)]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        raise ValueError(f"Ambiguous {label} '{query}'. Matches: {', '.join(matches)}")
    raise ValueError(f"{label.capitalize()} '{query}' not found. Available: {', '.join(options)}")
