"""OIDC provider registry."""

from .keycloak import KeycloakProvider

PROVIDERS = {
    "keycloak": KeycloakProvider(),
}
