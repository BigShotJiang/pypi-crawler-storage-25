"""Base protocol for OIDC token providers."""

from typing import Protocol, Dict, Any, List


class OIDCProvider(Protocol):
    """Contract for OIDC token providers."""

    name: str

    async def get_token(self, config: Dict[str, Any], secret: str) -> str:
        """Fetch an access_token given item config and the secret from keyring."""
        ...

    async def get_roles(self, config: Dict[str, Any], secret: str, token: str) -> Dict[str, List[str]]:
        """Extract roles from token or introspection endpoint."""
        ...

    def validate_config(self, config: Dict[str, Any]) -> None:
        """Raise ValueError if config is incomplete."""
        ...
