"""
Keycloak OIDC provider.

Supports password grant (user) and client_credentials grant (client).
Ported from sso-cli auth.py.
"""

import base64
import json
import logging
import httpx
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

_DEFAULT_CLIENT_ID = "delivery-ops-frontend-client"


class KeycloakProvider:
    name = "keycloak"

    def validate_config(self, config: Dict[str, Any]) -> None:
        if "sso_url" not in config:
            raise ValueError("Keycloak provider requires 'sso_url' in config.")
        if "auth_type" not in config:
            raise ValueError("Keycloak provider requires 'auth_type' (user or client).")
        sso_url = config["sso_url"]
        if not sso_url.startswith("https://"):
            if config.get("allow_insecure"):
                logger.warning("SSO URL uses insecure HTTP: %s", sso_url)
            else:
                raise ValueError(
                    f"SSO URL must use HTTPS: {sso_url}. "
                    "Set 'allow_insecure: true' in item config for local dev only."
                )

    async def get_token(self, config: Dict[str, Any], secret: str) -> str:
        """Fetch an access_token from Keycloak."""
        self.validate_config(config)
        token_url = f"{config['sso_url']}/protocol/openid-connect/token"
        auth_type = config["auth_type"]

        if auth_type == "client":
            data = {
                "grant_type": "client_credentials",
                "client_id": config["client_id"],
                "client_secret": secret,
            }
        else:
            data = {
                "grant_type": "password",
                "client_id": config.get("client_id", _DEFAULT_CLIENT_ID),
                "username": config["email"],
                "password": secret,
            }

        logger.debug("POST %s grant_type=%s", token_url, data["grant_type"])
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(token_url, data=data)
                logger.debug("Response: %d %s", response.status_code, response.reason_phrase)
                response.raise_for_status()
                token = response.json()["access_token"]
                logger.debug("Token obtained (%d chars)", len(token))
                return token
        except httpx.HTTPStatusError as e:
            # Sanitize: never expose response body (may echo credentials)
            raise RuntimeError(
                f"Token request failed: HTTP {e.response.status_code} from {token_url}"
            ) from None
        except httpx.RequestError as e:
            raise RuntimeError(
                f"Token request failed: could not reach {token_url}"
            ) from None

    async def get_roles(
        self, config: Dict[str, Any], secret: str, token: str
    ) -> Dict[str, List[str]]:
        """Extract roles from JWT and server endpoints."""
        base_url = config["sso_url"]
        jwt_roles = _extract_roles_from_payload(_decode_jwt(token))

        try:
            return await self._fetch_roles(config, secret, token, base_url, jwt_roles)
        except httpx.HTTPStatusError as e:
            raise RuntimeError(
                f"Role lookup failed: HTTP {e.response.status_code}"
            ) from None
        except httpx.RequestError:
            raise RuntimeError("Role lookup failed: network error") from None

    async def _fetch_roles(self, config, secret, token, base_url, jwt_roles):
        if config["auth_type"] == "client":
            url = f"{base_url}/protocol/openid-connect/token/introspect"
            logger.debug("POST %s (introspection)", url)
            async with httpx.AsyncClient() as client:
                resp = await client.post(url, data={
                    "token": token,
                    "client_id": config["client_id"],
                    "client_secret": secret,
                })
                resp.raise_for_status()
                server_roles = _extract_roles_from_payload(resp.json())
            return {"jwt": jwt_roles, "introspection": server_roles}
        else:
            url = f"{base_url}/protocol/openid-connect/userinfo"
            logger.debug("GET %s", url)
            async with httpx.AsyncClient() as client:
                resp = await client.get(url, headers={"Authorization": f"Bearer {token}"})
                resp.raise_for_status()
                server_roles = _extract_roles_from_payload(resp.json())
            return {"jwt": jwt_roles, "userinfo": server_roles}


def _decode_jwt(token: str) -> Dict[str, Any]:
    """Decode JWT payload without verification."""
    parts = token.split(".")
    if len(parts) != 3:
        return {}
    payload = parts[1]
    payload += "=" * ((4 - len(payload) % 4) % 4)
    return json.loads(base64.urlsafe_b64decode(payload))


def _extract_roles_from_payload(payload: Dict[str, Any]) -> List[str]:
    """Extract realm and resource roles from a JWT/introspection payload."""
    roles = []
    if isinstance(payload.get("realm_access"), dict):
        roles.extend(payload["realm_access"].get("roles", []))
    if isinstance(payload.get("resource_access"), dict):
        for resource, access in payload["resource_access"].items():
            if isinstance(access, dict):
                for role in access.get("roles", []):
                    roles.append(f"{resource}:{role}")
    return sorted(roles)
