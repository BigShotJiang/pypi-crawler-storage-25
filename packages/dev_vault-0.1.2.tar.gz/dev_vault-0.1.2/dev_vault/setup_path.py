"""Setup script to add Python scripts directory to PATH automatically."""

import os
import sys
import sysconfig
import platform
from pathlib import Path


def is_windows():
    return platform.system() == 'Windows'


def get_shell_config_file():
    if is_windows():
        return None
    shell = os.environ.get('SHELL', '')
    if 'zsh' in shell:
        return Path.home() / '.zshrc'
    elif 'bash' in shell:
        bash_profile = Path.home() / '.bash_profile'
        if bash_profile.exists():
            return bash_profile
        return Path.home() / '.bashrc'
    elif 'fish' in shell:
        return Path.home() / '.config' / 'fish' / 'config.fish'
    else:
        if platform.system() == 'Darwin':
            return Path.home() / '.zshrc'
        return Path.home() / '.bashrc'


def get_scripts_path():
    if is_windows():
        try:
            import site
            user_base = site.getuserbase()
            scripts_path = os.path.join(user_base, 'Scripts')
            if os.path.exists(scripts_path):
                return scripts_path
        except Exception:
            pass
        return sysconfig.get_path('scripts')
    else:
        try:
            import site
            user_base = site.getuserbase()
            scripts_path = os.path.join(user_base, 'bin')
            if os.path.exists(scripts_path):
                return scripts_path
        except Exception:
            pass
        return sysconfig.get_path('scripts')


def setup_path_unix(scripts_path, config_file):
    path_export = f'export PATH="{scripts_path}:$PATH"'
    if config_file.exists():
        with open(config_file, 'r', encoding='utf-8') as f:
            content = f.read()
        if scripts_path in content:
            if path_export in content or f'"{scripts_path}' in content:
                print(f"PATH already configured in {config_file}")
                return True
    try:
        with open(config_file, 'a', encoding='utf-8') as f:
            f.write(f'\n# Added by dev-vault\n{path_export}\n')
        print(f"Added {scripts_path} to PATH in {config_file}")
        print(f"Run: source {config_file}")
        return True
    except Exception as e:
        print(f"Failed to update {config_file}: {e}")
        print(f"Manually add: {path_export}")
        return False


def setup_path():
    scripts_path = get_scripts_path()
    if not scripts_path or not os.path.exists(scripts_path):
        print(f"Scripts directory not found: {scripts_path}")
        return False
    if is_windows():
        print(f"Add to PATH manually: {scripts_path}")
        return False
    config_file = get_shell_config_file()
    if not config_file:
        print("Could not determine shell config file")
        return False
    return setup_path_unix(scripts_path, config_file)


if __name__ == '__main__':
    setup_path()
