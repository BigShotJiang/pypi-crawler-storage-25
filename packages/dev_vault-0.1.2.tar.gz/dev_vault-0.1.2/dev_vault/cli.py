"""
dev-vault CLI entry point.

Routes subcommands to their respective handlers.
"""

import argparse
import logging
import os
import sys

from rich.console import Console
from rich.logging import RichHandler

from . import __version__

console = Console()
logger = logging.getLogger("dev_vault")


def _setup_logging(verbose: bool) -> None:
    enabled = verbose or os.environ.get("DV_DEBUG", "").strip() in ("1", "true", "yes")
    if not enabled:
        return
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(
            console=Console(stderr=True),
            rich_tracebacks=True,
            show_path=False,
        )],
    )
    logger.debug("Verbose mode enabled")


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="dv",
        description="dev-vault -- Developer secret vault + OIDC token provider",
    )
    parser.add_argument("--version", action="version", version=f"dev-vault {__version__}")
    parser.add_argument("-v", "--verbose", action="store_true", help="enable debug output")
    parser.add_argument("--json", action="store_true", help="JSON output")

    sub = parser.add_subparsers(dest="command")

    # dv get -- supports both:
    #   dv get prod caetano           (positional: vault item)
    #   dv get prod caetano password  (positional: vault item field)
    #   dv get caetano                (just item, default vault)
    #   dv get prod/caetano           (slash shorthand still works)
    p_get = sub.add_parser("get", help="retrieve a secret or OIDC token")
    p_get.add_argument("args", nargs="+", help="[vault] item [field] or vault/item[/field]")

    # dv set -- supports:
    #   dv set item field [value]
    #   dv set vault item field [value]
    p_set = sub.add_parser("set", help="store a secret")
    p_set.add_argument("args", nargs="+", help="[vault] item field [value]")

    # dv run
    p_run = sub.add_parser("run", help="run command with secrets injected as env vars")
    p_run.add_argument("-s", "--secret", action="append", help="KEY=ref mapping")
    p_run.add_argument("run_command", nargs=argparse.REMAINDER, help="command to run (after --)")

    # dv inject
    sub.add_parser("inject", help="replace {{dv://...}} refs in stdin")

    # dv item
    p_item = sub.add_parser("item", help="manage items")
    item_sub = p_item.add_subparsers(dest="item_action")

    item_sub.add_parser("list", help="list items")
    p_ic = item_sub.add_parser("create", help="create item")
    p_ic.add_argument("name", help="item name")
    p_ic.add_argument("--kind", choices=["static", "oidc"], default="static")
    p_ic.add_argument("--vault", help="override vault")

    p_is = item_sub.add_parser("show", help="show item details")
    p_is.add_argument("name", help="item name")
    p_is.add_argument("--vault", help="override vault")

    p_id = item_sub.add_parser("delete", help="delete item")
    p_id.add_argument("name", help="item name")
    p_id.add_argument("--vault", help="override vault")

    # dv vault
    p_vault = sub.add_parser("vault", help="manage vaults")
    vault_sub = p_vault.add_subparsers(dest="vault_action")
    vault_sub.add_parser("list", help="list vaults")
    vc = vault_sub.add_parser("create", help="create vault")
    vc.add_argument("name", help="vault name")
    vd = vault_sub.add_parser("delete", help="delete vault")
    vd.add_argument("name", help="vault name")

    # dv setup
    p_setup = sub.add_parser("setup", help="interactive setup wizard")
    p_setup.add_argument("--reset", action="store_true", help="backup config and start fresh")

    # dv migrate
    p_migrate = sub.add_parser("migrate", help="import from another tool")
    p_migrate.add_argument("source", nargs="?", default="sso-cli", help="source tool (default: sso-cli)")

    # dv config
    p_config = sub.add_parser("config", help="show configuration")
    config_sub = p_config.add_subparsers(dest="config_action")
    config_sub.add_parser("show", help="display current config")

    return parser


def cli() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    _setup_logging(args.verbose)

    # Strip leading '--' from run command
    if args.command == "run" and hasattr(args, "run_command"):
        cmd = getattr(args, "run_command", [])
        if cmd and cmd[0] == "--":
            args.run_command = cmd[1:]

    if not args.command:
        parser.print_help()
        return

    # Propagate --json to args
    try:
        _dispatch(args)
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        sys.exit(130)
    except Exception as e:
        logger.debug("Error: %s", e, exc_info=True)
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def _dispatch(args) -> None:
    cmd = args.command
    if cmd == "get":
        from .commands.get import run
        run(args)
    elif cmd == "set":
        from .commands.set_cmd import run
        run(args)
    elif cmd == "run":
        from .commands.run import run as run_cmd
        run_cmd(args)
    elif cmd == "inject":
        from .commands.inject import run
        run(args)
    elif cmd == "item":
        from .commands.item import run
        run(args)
    elif cmd == "vault":
        from .commands.vault import run
        run(args)
    elif cmd == "setup":
        from .commands.setup import run
        run(args)
    elif cmd == "migrate":
        from .commands.migrate import run
        run(args)
    elif cmd == "config":
        from .commands.config_cmd import run
        run(args)
    else:
        print(f"Unknown command: {cmd}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    cli()
