"""dev-vault -- Developer secret vault + OIDC token provider."""

__version__ = "0.1.0"
