"""
dv vault -- manage vaults.

Usage:
  dv vault list
  dv vault create <name>
  dv vault delete <name>
"""

import json as json_mod
import logging
import sys

from ..core.config import ensure_config, save_config
from ..core.keyring_store import delete_secret

logger = logging.getLogger(__name__)


def run(args) -> None:
    """Route vault subcommands."""
    action = args.vault_action
    if action == "list":
        _list_vaults(args)
    elif action == "create":
        _create_vault(args)
    elif action == "delete":
        _delete_vault(args)
    else:
        print(f"Unknown vault action: {action}", file=sys.stderr)
        sys.exit(1)


def _list_vaults(args) -> None:
    config = ensure_config()
    vaults = config.get("vaults", {})

    if getattr(args, "json", False):
        result = [{"name": k, "items": len(v.get("items", {}))} for k, v in vaults.items()]
        print(json_mod.dumps(result, indent=2))
        return

    if not vaults:
        print("No vaults found.", file=sys.stderr)
        return

    for name, data in vaults.items():
        n_items = len(data.get("items", {}))
        default = " (default)" if name == config.get("defaults", {}).get("vault") else ""
        print(f"  {name}{default}  ({n_items} item(s))")


def _create_vault(args) -> None:
    config = ensure_config()
    vaults = config.setdefault("vaults", {})

    if args.name in vaults:
        print(f"Error: vault '{args.name}' already exists.", file=sys.stderr)
        sys.exit(1)

    vaults[args.name] = {"items": {}}
    save_config(config)

    if getattr(args, "json", False):
        print(json_mod.dumps({"vault": args.name, "created": True}))
    else:
        print(f"Created vault: {args.name}", file=sys.stderr)


def _delete_vault(args) -> None:
    config = ensure_config()
    vaults = config.get("vaults", {})

    if args.name not in vaults:
        print(f"Error: vault '{args.name}' not found.", file=sys.stderr)
        sys.exit(1)

    # Delete all secrets in the vault
    vault_data = vaults[args.name]
    for item_name, item_data in vault_data.get("items", {}).items():
        for field in item_data.get("fields", []):
            delete_secret(args.name, item_name, field)

    del vaults[args.name]
    save_config(config)

    if getattr(args, "json", False):
        print(json_mod.dumps({"vault": args.name, "deleted": True}))
    else:
        print(f"Deleted vault: {args.name}", file=sys.stderr)
