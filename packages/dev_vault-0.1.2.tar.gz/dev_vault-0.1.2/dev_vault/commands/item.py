"""
dv item -- manage items in vaults.

Usage:
  dv item list [-v vault]
  dv item create <name> --kind static|oidc [-v vault]
  dv item show <name> [-v vault]
  dv item delete <name> [-v vault]
"""

import json as json_mod
import logging
import sys

from ..core.config import ensure_config, get_vault, get_item, list_all_items, save_config
from ..core.keyring_store import delete_secret

logger = logging.getLogger(__name__)


def run(args) -> None:
    """Route item subcommands."""
    action = args.item_action
    if action == "list":
        _list_items(args)
    elif action == "create":
        _create_item(args)
    elif action == "show":
        _show_item(args)
    elif action == "delete":
        _delete_item(args)
    else:
        print(f"Unknown item action: {action}", file=sys.stderr)
        sys.exit(1)


def _list_items(args) -> None:
    config = ensure_config()
    vault_filter = getattr(args, "vault", None)

    items = list_all_items(config)
    if vault_filter:
        items = [i for i in items if i["vault"] == vault_filter]

    if getattr(args, "json", False):
        print(json_mod.dumps(items, indent=2))
        return

    if not items:
        print("No items found.", file=sys.stderr)
        return

    for i in items:
        print(f"  {i['vault']}/{i['item']}  [{i['kind']}]")


def _create_item(args) -> None:
    config = ensure_config()
    vault_name = args.vault or config.get("defaults", {}).get("vault", "default")
    vault = get_vault(config, vault_name)
    items = vault.setdefault("items", {})

    if args.name in items:
        print(f"Error: item '{args.name}' already exists in vault '{vault_name}'.", file=sys.stderr)
        sys.exit(1)

    kind = getattr(args, "kind", "static") or "static"
    items[args.name] = {"kind": kind, "fields": []}
    save_config(config)

    if getattr(args, "json", False):
        print(json_mod.dumps({"vault": vault_name, "item": args.name, "kind": kind, "created": True}))
    else:
        print(f"Created: {vault_name}/{args.name} [{kind}]", file=sys.stderr)


def _show_item(args) -> None:
    config = ensure_config()
    vault_name = args.vault or config.get("defaults", {}).get("vault", "default")
    item = get_item(config, vault_name, args.name)
    if not item:
        print(f"Error: item '{args.name}' not found in vault '{vault_name}'.", file=sys.stderr)
        sys.exit(1)

    if getattr(args, "json", False):
        print(json_mod.dumps({"vault": vault_name, "item": args.name, **item}, indent=2))
        return

    kind = item.get("kind", "static")
    fields = item.get("fields", [])
    print(f"  {vault_name}/{args.name}  [{kind}]")
    print(f"  Fields: {', '.join(fields) if fields else '(none)'}")
    if kind == "oidc":
        provider = item.get("provider", "keycloak")
        oidc_config = item.get("config", {})
        print(f"  Provider: {provider}")
        for k, v in oidc_config.items():
            print(f"    {k}: {v}")


def _delete_item(args) -> None:
    config = ensure_config()
    vault_name = args.vault or config.get("defaults", {}).get("vault", "default")
    vault_data = config.get("vaults", {}).get(vault_name, {})
    items = vault_data.get("items", {})

    if args.name not in items:
        print(f"Error: item '{args.name}' not found in vault '{vault_name}'.", file=sys.stderr)
        sys.exit(1)

    item = items[args.name]
    fields = item.get("fields", [])
    for field in fields:
        delete_secret(vault_name, args.name, field)

    del items[args.name]
    save_config(config)

    if getattr(args, "json", False):
        print(json_mod.dumps({"vault": vault_name, "item": args.name, "deleted": True}))
    else:
        print(f"Deleted: {vault_name}/{args.name}", file=sys.stderr)
