"""
dv set -- store a secret in the vault.

Usage:
  dv set <item> <field> [value]           # default vault
  dv set <vault> <item> <field> [value]   # specific vault
"""

import getpass
import json as json_mod
import logging
import sys

from ..core.config import ensure_config, get_vault, get_default_vault, save_config
from ..core.keyring_store import store_secret

logger = logging.getLogger(__name__)


def _parse_args(args) -> tuple:
    """Parse positional args into (vault, item, field, value).

    2 args: item field         -> (default, item, field, None)
    3 args: item field value   -> (default, item, field, value)
            OR vault item field -> (vault, item, field, None)
    4 args: vault item field value
    """
    parts = args.args
    config = ensure_config()
    default_vault = get_default_vault(config)
    vaults = list(config.get("vaults", {}).keys())

    if len(parts) == 2:
        return default_vault, parts[0], parts[1], None
    elif len(parts) == 3:
        if parts[0] in vaults:
            return parts[0], parts[1], parts[2], None
        return default_vault, parts[0], parts[1], parts[2]
    elif len(parts) == 4:
        return parts[0], parts[1], parts[2], parts[3]
    else:
        print("Usage: dv set [vault] <item> <field> [value]", file=sys.stderr)
        sys.exit(1)


def run(args) -> None:
    config = ensure_config()
    vault_name, item_name, field_name, value = _parse_args(args)
    inline = value is not None

    vault = get_vault(config, vault_name)
    items = vault.setdefault("items", {})

    item = items.get(item_name)
    if not item:
        item = {"kind": "static", "fields": []}
        items[item_name] = item

    fields = item.setdefault("fields", [])
    if isinstance(fields, list) and field_name not in fields:
        fields.append(field_name)

    if not value:
        value = getpass.getpass(f"Enter value for {vault_name}/{item_name}/{field_name}: ")

    if not value or not value.strip():
        print("Error: empty or blank value.", file=sys.stderr)
        sys.exit(1)

    if inline:
        print(
            "Warning: value passed as argument -- it may be visible in shell history. "
            "Omit the value to use masked input.",
            file=sys.stderr,
        )

    store_secret(vault_name, item_name, field_name, value)
    save_config(config)

    if getattr(args, "json", False):
        print(json_mod.dumps({"vault": vault_name, "item": item_name, "field": field_name, "stored": True}))
    else:
        print(f"Stored: {vault_name}/{item_name}/{field_name}", file=sys.stderr)
