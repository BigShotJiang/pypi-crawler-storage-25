"""
dv run -- execute a command with secrets injected as env vars.

Usage:
  dv run -- <command>                        # uses .dv.yaml manifest
  dv run -s DD_API_KEY=datadog/api_key -- python app.py
"""

import asyncio
import logging
import os
import subprocess
import sys

from ..core.config import ensure_config, get_item, get_default_vault
from ..core.keyring_store import get_secret
from ..core.manifest import load_manifest
from ..core.resolver import resolve
from ..providers import PROVIDERS

logger = logging.getLogger(__name__)


def run(args) -> None:
    """Execute the run command."""
    asyncio.run(_run(args))


async def _run(args) -> None:
    if not args.run_command:
        print("Error: no command specified after '--'.", file=sys.stderr)
        sys.exit(1)

    config = ensure_config()
    default_vault = get_default_vault(config)
    env = dict(os.environ)

    # Collect secret mappings: from -s flags and/or .dv.yaml manifest
    mappings = {}

    # Explicit -s mappings take priority
    for mapping in (args.secret or []):
        if "=" not in mapping:
            print(f"Error: invalid mapping '{mapping}'. Use KEY=ref format.", file=sys.stderr)
            sys.exit(1)
        env_var, ref = mapping.split("=", 1)
        mappings[env_var] = ref

    # Load .dv.yaml manifest if no explicit mappings (or merge)
    if not mappings:
        try:
            manifest = load_manifest()
            mappings.update(manifest)
        except FileNotFoundError:
            print(
                "Error: no -s mappings and no .dv.yaml manifest found.",
                file=sys.stderr,
            )
            sys.exit(1)

    # Resolve all secrets
    for env_var, ref in mappings.items():
        value = await _resolve_secret(config, ref, default_vault)
        env[env_var] = value
        logger.debug("Injected %s from %s", env_var, ref)

    logger.debug("Running: %s", " ".join(args.run_command))
    result = subprocess.run(args.run_command, env=env)
    sys.exit(result.returncode)


async def _resolve_secret(config: dict, ref: str, default_vault: str) -> str:
    """Resolve a secret reference to its value."""
    known_vaults = list(config.get("vaults", {}).keys())
    vault, item_name, field = resolve(ref, default_vault, known_vaults=known_vaults)
    item = get_item(config, vault, item_name)

    if not item:
        print(f"Error: item '{item_name}' not found in vault '{vault}'.", file=sys.stderr)
        sys.exit(1)

    kind = item.get("kind", "static")

    if kind == "oidc" and field is None:
        return await _get_oidc_token(item, vault, item_name)

    resolved_field = field or _primary_field(item)
    value = get_secret(vault, item_name, resolved_field)
    if value is None:
        print(f"Error: no secret for {vault}/{item_name}/{resolved_field}.", file=sys.stderr)
        sys.exit(1)
    return value


async def _get_oidc_token(item: dict, vault: str, item_name: str) -> str:
    """Fetch a fresh OIDC token."""
    provider_name = item.get("provider", "keycloak")
    provider = PROVIDERS.get(provider_name)
    if not provider:
        print(f"Error: unknown provider '{provider_name}'.", file=sys.stderr)
        sys.exit(1)

    item_config = item.get("config", {})
    secret_field = "client_secret" if item_config.get("auth_type") == "client" else "password"
    secret = get_secret(vault, item_name, secret_field)
    if secret is None:
        print(f"Error: no {secret_field} for {vault}/{item_name}.", file=sys.stderr)
        sys.exit(1)

    return await provider.get_token(item_config, secret)


def _primary_field(item: dict) -> str:
    fields = item.get("fields", [])
    if isinstance(fields, list) and fields:
        return fields[0]
    return "value"
