"""
dv setup -- interactive wizard for configuring vaults and items.

Usage:
  dv setup
"""

import getpass
import re
import sys
import logging
from typing import Any, Dict

import inquirer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt

from ..core.config import ensure_config, find_config_path, load_config, save_config, backup_config
from ..core.keyring_store import store_secret, get_secret, delete_secret

logger = logging.getLogger(__name__)
console = Console()

_BACK = "[<] Back"
_SAVE_QUIT = "[q] Save & quit"


def run(args) -> None:
    """Execute the setup command."""
    reset = getattr(args, "reset", False)
    if reset:
        path = find_config_path()
        import os
        if os.path.exists(path):
            backup = backup_config(path)
            console.print(f"[dim]Backed up config to: {backup}[/dim]")

    run_setup_wizard(append=not reset)


def _pick(title: str, options: list) -> str:
    questions = [inquirer.List("choice", message=title, choices=options, carousel=True)]
    try:
        answers = inquirer.prompt(questions)
        if answers is None:
            sys.exit(0)
        return answers["choice"]
    except (KeyboardInterrupt, EOFError):
        sys.exit(0)


def _prompt_static_item(config: Dict, vault_name: str) -> None:
    """Prompt for a new static item."""
    vault = config["vaults"].setdefault(vault_name, {"items": {}})
    items = vault.setdefault("items", {})

    item_name = Prompt.ask("  Item name (e.g. datadog, github-token)").strip()
    if not item_name:
        return

    field_name = Prompt.ask("  Field name (e.g. api_key, token)", default="value").strip()
    secret = getpass.getpass(f"  Value for {field_name}: ")

    items[item_name] = {"kind": "static", "fields": [field_name]}
    store_secret(vault_name, item_name, field_name, secret)
    console.print(f"  [green]Stored: {vault_name}/{item_name}/{field_name}[/green]")


def _prompt_oidc_item(config: Dict, vault_name: str) -> None:
    """Prompt for a new OIDC item."""
    vault = config["vaults"].setdefault(vault_name, {"items": {}})
    items = vault.setdefault("items", {})

    auth_type = _pick("  Auth type", ["user", "client"])

    if auth_type == "user":
        email = Prompt.ask("  Email").strip()
        item_name = email
        raw = Prompt.ask("  SSO base URL (e.g. sso.example.com)").strip().rstrip("/")
        if not raw.startswith(("http://", "https://")):
            raw = "https://" + raw
        console.print("  [dim](case-sensitive in Keycloak)[/dim]")
        realm = Prompt.ask("  Realm name", default="master").strip()
        sso_url = f"{raw}/realms/{realm}"
        secret = getpass.getpass("  Password: ")

        items[item_name] = {
            "kind": "oidc",
            "provider": "keycloak",
            "config": {
                "sso_url": sso_url,
                "auth_type": "user",
                "email": email,
            },
            "fields": ["password"],
        }
        store_secret(vault_name, item_name, "password", secret)
    else:
        client_id = Prompt.ask("  Client ID").strip()
        item_name = client_id
        raw = Prompt.ask("  SSO base URL (e.g. sso.example.com)").strip().rstrip("/")
        if not raw.startswith(("http://", "https://")):
            raw = "https://" + raw
        console.print("  [dim](case-sensitive in Keycloak)[/dim]")
        realm = Prompt.ask("  Realm name", default="master").strip()
        sso_url = f"{raw}/realms/{realm}"
        secret = getpass.getpass("  Client Secret: ")

        items[item_name] = {
            "kind": "oidc",
            "provider": "keycloak",
            "config": {
                "sso_url": sso_url,
                "auth_type": "client",
                "client_id": client_id,
            },
            "fields": ["client_secret"],
        }
        store_secret(vault_name, item_name, "client_secret", secret)

    console.print(f"  [green]Configured: {vault_name}/{item_name}[/green]")


def run_setup_wizard(append: bool = True) -> str:
    """Interactive setup wizard. Returns config path."""
    if append:
        config = ensure_config()
    else:
        config = {"version": 1, "defaults": {"vault": "default"}, "vaults": {}}

    console.print()
    console.print(Panel(
        "[bold cyan]dev-vault Config Manager[/bold cyan]\n\n"
        "Arrow keys to navigate, Enter to select.\n"
        "[+] Add   [-] Delete   [<] Back   [q] Save & quit\n"
        "Secrets are [bold red]never[/bold red] written to disk.",
        border_style="cyan",
        title="Setup",
    ))

    vaults = config.setdefault("vaults", {})

    if not vaults:
        console.print("\n[dim]No vaults yet -- creating 'default'.[/dim]")
        vaults["default"] = {"items": {}}
        vault_name = "default"
        kind = _pick("  What would you like to add?", ["Static secret", "OIDC provider"])
        if kind == "Static secret":
            _prompt_static_item(config, vault_name)
        else:
            _prompt_oidc_item(config, vault_name)

    while True:
        vault_lines = []
        for vk, vd in vaults.items():
            n_items = len(vd.get("items", {}))
            vault_lines.append(f"{vk}  ({n_items} item(s))")

        options = vault_lines + ["[+] Add to vault", "[+] New vault", _SAVE_QUIT]
        choice = _pick("Vaults", options)

        if choice == _SAVE_QUIT:
            break
        elif choice == "[+] New vault":
            name = Prompt.ask("  Vault name").strip()
            if name:
                vaults.setdefault(name, {"items": {}})
        elif choice == "[+] Add to vault":
            vault_names = list(vaults.keys())
            if len(vault_names) == 1:
                target = vault_names[0]
            else:
                target = _pick("  Which vault?", vault_names)
            kind = _pick("  What to add?", ["Static secret", "OIDC provider", _BACK])
            if kind == "Static secret":
                _prompt_static_item(config, target)
            elif kind == "OIDC provider":
                _prompt_oidc_item(config, target)
        else:
            # Selected a vault -- show its items
            vault_name = list(vaults.keys())[vault_lines.index(choice)]
            _vault_menu(config, vault_name)

    out_path = find_config_path()
    save_config(config, out_path)
    console.print()
    console.print(Panel(f"[green]Config saved to [bold]{out_path}[/bold][/green]", border_style="green"))
    return out_path


def _vault_menu(config: Dict, vault_name: str) -> None:
    """Interactive menu for a specific vault."""
    vault = config["vaults"][vault_name]
    items = vault.get("items", {})

    while True:
        item_lines = []
        for ik, id_ in items.items():
            kind = id_.get("kind", "static")
            item_lines.append(f"  {ik}  [{kind}]")

        options = item_lines + ["[+] Add item", "[-] Delete vault", _BACK]
        choice = _pick(f"Vault: {vault_name}", options)

        if choice == _BACK:
            return
        elif choice == "[+] Add item":
            kind = _pick("  What to add?", ["Static secret", "OIDC provider"])
            if kind == "Static secret":
                _prompt_static_item(config, vault_name)
            else:
                _prompt_oidc_item(config, vault_name)
        elif choice == "[-] Delete vault":
            if not Confirm.ask(f"  Delete vault '{vault_name}' and all items?", default=False):
                continue
            for ik, id_ in items.items():
                for f in id_.get("fields", []):
                    delete_secret(vault_name, ik, f)
            del config["vaults"][vault_name]
            return
        else:
            # Show item details
            idx = item_lines.index(choice)
            item_name = list(items.keys())[idx]
            console.print(f"\n  [bold]{vault_name}/{item_name}[/bold]")
            item = items[item_name]
            console.print(f"  Kind: {item.get('kind', 'static')}")
            console.print(f"  Fields: {', '.join(item.get('fields', []))}")
            if item.get("config"):
                for k, v in item["config"].items():
                    console.print(f"    {k}: {v}")
