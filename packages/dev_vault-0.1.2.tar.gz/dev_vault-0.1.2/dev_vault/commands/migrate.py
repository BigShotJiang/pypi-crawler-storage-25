"""
dv migrate sso-cli -- import config and secrets from sso-cli.

Reads ~/sso_config.yaml and copies secrets from the sso-cli keyring
to the dev-vault keyring.
"""

import json as json_mod
import logging
import os
import sys

import yaml

from ..core.config import ensure_config, save_config
from ..core.keyring_store import store_secret, get_secret_legacy

logger = logging.getLogger(__name__)


def run(args) -> None:
    """Execute the migrate command."""
    source = getattr(args, "source", "sso-cli")
    if source != "sso-cli":
        print(f"Error: unknown migration source '{source}'. Only 'sso-cli' is supported.", file=sys.stderr)
        sys.exit(1)

    _migrate_sso_cli(args)


def _migrate_sso_cli(args) -> None:
    """Import sso-cli config and secrets into dev-vault."""
    # Find sso-cli config
    sso_config_path = os.environ.get("SSO_CONFIG_PATH", "")
    if not sso_config_path or not os.path.exists(sso_config_path):
        sso_config_path = os.path.expanduser("~/sso_config.yaml")
    if not os.path.exists(sso_config_path):
        print(f"Error: sso-cli config not found at {sso_config_path}.", file=sys.stderr)
        sys.exit(1)

    print(f"Reading sso-cli config from: {sso_config_path}", file=sys.stderr)

    with open(sso_config_path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    env_cfg = raw.get("environments", raw)
    if not isinstance(env_cfg, dict):
        print("Error: invalid sso-cli config format.", file=sys.stderr)
        sys.exit(1)

    config = ensure_config()
    migrated = 0

    _LEGACY = {"password": "user", "client_credentials": "client"}

    for env_key, env_data in env_cfg.items():
        if not isinstance(env_data, dict) or not env_data.get("sso_url"):
            print(f"  Skipping invalid environment: {env_key}", file=sys.stderr)
            continue

        # Create vault for this environment
        vault = config.setdefault("vaults", {}).setdefault(env_key, {"items": {}})
        items = vault.setdefault("items", {})

        users = env_data.get("users", {})
        for user_key, user_data in users.items():
            if not isinstance(user_data, dict):
                continue

            auth_type = _LEGACY.get(user_data.get("auth_type", ""), user_data.get("auth_type", "user"))

            # Create OIDC item
            if auth_type == "client":
                secret_field = "client_secret"
                item_config = {
                    "sso_url": env_data["sso_url"],
                    "auth_type": "client",
                    "client_id": user_data.get("client_id", user_key),
                }
            else:
                secret_field = "password"
                item_config = {
                    "sso_url": env_data["sso_url"],
                    "auth_type": "user",
                    "email": user_data.get("email", user_key),
                }

            items[user_key] = {
                "kind": "oidc",
                "provider": "keycloak",
                "config": item_config,
                "fields": [secret_field],
            }

            # Migrate secret from sso-cli keyring
            old_secret = get_secret_legacy(env_key, user_key)
            if old_secret:
                store_secret(env_key, user_key, secret_field, old_secret)
                print(f"  Migrated: {env_key}/{user_key} ({auth_type})", file=sys.stderr)
                migrated += 1
            else:
                print(f"  Warning: no keyring secret for {env_key}/{user_key}", file=sys.stderr)

    path = save_config(config)
    print(f"\nMigrated {migrated} item(s). Config saved to: {path}", file=sys.stderr)

    if getattr(args, "json", False):
        print(json_mod.dumps({"migrated": migrated, "config_path": path}))
