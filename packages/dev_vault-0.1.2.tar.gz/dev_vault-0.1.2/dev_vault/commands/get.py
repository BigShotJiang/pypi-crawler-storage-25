"""
dv get -- retrieve a secret or OIDC token.

Usage:
  dv get <item>                    # default vault, primary field
  dv get <vault> <item>            # specific vault
  dv get <vault> <item> <field>    # specific vault + field
  dv get vault/item/field          # slash shorthand
"""

import asyncio
import json as json_mod
import logging
import sys

from ..core.config import ensure_config, get_item, get_default_vault, list_all_items
from ..core.keyring_store import get_secret
from ..core.resolver import resolve, resolve_prefix
from ..providers import PROVIDERS

logger = logging.getLogger(__name__)


def run(args) -> None:
    asyncio.run(_get(args))


def _parse_args(args) -> tuple:
    """Parse positional args into (vault, item, field).

    Supports:
      ["item"]                -> (default, item, None)
      ["vault", "item"]      -> (vault, item, None)
      ["vault", "item", "f"] -> (vault, item, f)
      ["vault/item"]         -> resolve via slash
      ["vault/item/field"]   -> resolve via slash
    """
    parts = args.args
    config = ensure_config()
    default_vault = get_default_vault(config)

    # If single arg with slashes, use resolver
    if len(parts) == 1 and "/" in parts[0]:
        return resolve(parts[0], default_vault)

    if len(parts) == 1:
        # Could be just an item name (default vault)
        # Or could be a vault name if it matches a vault
        vaults = list(config.get("vaults", {}).keys())
        if parts[0] in vaults:
            # Ambiguous: is it a vault or an item in default vault?
            # Check if it's also an item in default vault
            default_items = config.get("vaults", {}).get(default_vault, {}).get("items", {})
            if parts[0] in default_items:
                return default_vault, parts[0], None
            # It's a vault name but no item specified
            print(f"Error: vault '{parts[0]}' specified but no item name.", file=sys.stderr)
            print(f"Usage: dv get {parts[0]} <item>", file=sys.stderr)
            sys.exit(1)
        return default_vault, parts[0], None
    elif len(parts) == 2:
        return parts[0], parts[1], None
    elif len(parts) == 3:
        return parts[0], parts[1], parts[2]
    else:
        print("Error: too many arguments. Usage: dv get [vault] <item> [field]", file=sys.stderr)
        sys.exit(1)


async def _get(args) -> None:
    config = ensure_config()
    vault, item_name, field = _parse_args(args)
    logger.debug("Resolved: vault=%s item=%s field=%s", vault, item_name, field)

    item = get_item(config, vault, item_name)
    if not item:
        print(f"Error: item '{item_name}' not found in vault '{vault}'.", file=sys.stderr)
        sys.exit(1)

    kind = item.get("kind", "static")

    if kind == "oidc" and field is None:
        value = await _get_oidc_token(item, vault, item_name)
    elif kind == "oidc" and field == "access_token":
        value = await _get_oidc_token(item, vault, item_name)
    else:
        resolved_field = field or _primary_field(item)
        if not resolved_field:
            print(f"Error: item '{item_name}' has no fields.", file=sys.stderr)
            sys.exit(1)
        value = get_secret(vault, item_name, resolved_field)
        if value is None:
            print(
                f"Error: no secret for {vault}/{item_name}/{resolved_field}. "
                "Run 'dv set' to store it.",
                file=sys.stderr,
            )
            sys.exit(1)

    if getattr(args, "json", False):
        print(json_mod.dumps({"vault": vault, "item": item_name, "field": field, "value": value}))
    else:
        print(value)


async def _get_oidc_token(item: dict, vault: str, item_name: str) -> str:
    provider_name = item.get("provider", "keycloak")
    provider = PROVIDERS.get(provider_name)
    if not provider:
        print(f"Error: unknown OIDC provider '{provider_name}'.", file=sys.stderr)
        sys.exit(1)

    item_config = item.get("config", {})
    auth_type = item_config.get("auth_type", "user")
    secret_field = "client_secret" if auth_type == "client" else "password"
    secret = get_secret(vault, item_name, secret_field)
    if secret is None:
        print(
            f"Error: no {secret_field} in keyring for {vault}/{item_name}. "
            "Run 'dv setup' to configure.",
            file=sys.stderr,
        )
        sys.exit(1)

    return await provider.get_token(item_config, secret)


def _primary_field(item: dict) -> str:
    fields = item.get("fields", [])
    if isinstance(fields, list) and fields:
        return fields[0]
    if isinstance(fields, dict) and fields:
        return next(iter(fields))
    return "value"
