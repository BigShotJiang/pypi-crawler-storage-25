"""
dv inject -- replace {{dv://...}} references in stdin.

Usage:
  dv inject < template.env > .env
  cat template.yaml | dv inject > output.yaml
"""

import asyncio
import logging
import re
import sys

from ..core.config import ensure_config, get_item, get_default_vault
from ..core.keyring_store import get_secret
from ..core.resolver import resolve
from ..providers import PROVIDERS

logger = logging.getLogger(__name__)

_REF_PATTERN = re.compile(r"\{\{(dv://[^}]+)\}\}")


def run(args) -> None:
    """Execute the inject command."""
    asyncio.run(_inject(args))


async def _inject(args) -> None:
    config = ensure_config()
    default_vault = get_default_vault(config)

    template = sys.stdin.read()
    refs = _REF_PATTERN.findall(template)

    if not refs:
        print(template, end="")
        return

    # Resolve all references
    resolved = {}
    for ref in set(refs):
        known_vaults = list(config.get("vaults", {}).keys())
        vault, item_name, field = resolve(ref, default_vault, known_vaults=known_vaults)
        item = get_item(config, vault, item_name)
        if not item:
            print(f"Error: item '{item_name}' not found in vault '{vault}'.", file=sys.stderr)
            sys.exit(1)

        kind = item.get("kind", "static")
        if kind == "oidc" and field is None:
            value = await _get_oidc_token(item, vault, item_name)
        else:
            resolved_field = field or _primary_field(item)
            value = get_secret(vault, item_name, resolved_field)
            if value is None:
                print(f"Error: no secret for {vault}/{item_name}/{resolved_field}.", file=sys.stderr)
                sys.exit(1)

        resolved[ref] = value

    # Replace all references
    def replacer(match):
        return resolved[match.group(1)]

    output = _REF_PATTERN.sub(replacer, template)
    print(output, end="")


async def _get_oidc_token(item: dict, vault: str, item_name: str) -> str:
    provider_name = item.get("provider", "keycloak")
    provider = PROVIDERS.get(provider_name)
    if not provider:
        print(f"Error: unknown provider '{provider_name}'.", file=sys.stderr)
        sys.exit(1)

    item_config = item.get("config", {})
    secret_field = "client_secret" if item_config.get("auth_type") == "client" else "password"
    secret = get_secret(vault, item_name, secret_field)
    if secret is None:
        print(f"Error: no {secret_field} for {vault}/{item_name}.", file=sys.stderr)
        sys.exit(1)

    return await provider.get_token(item_config, secret)


def _primary_field(item: dict) -> str:
    fields = item.get("fields", [])
    if isinstance(fields, list) and fields:
        return fields[0]
    return "value"
