"""
dv config show -- display current configuration.

Usage:
  dv config show
"""

import json as json_mod
import logging
import sys

import yaml

from ..core.config import find_config_path, load_config

logger = logging.getLogger(__name__)


def run(args) -> None:
    """Execute the config command."""
    action = getattr(args, "config_action", "show")
    if action == "show":
        _show(args)
    else:
        print(f"Unknown config action: {action}", file=sys.stderr)
        sys.exit(1)


def _show(args) -> None:
    config_path = find_config_path()
    try:
        config = load_config()
    except FileNotFoundError:
        print(f"No config found at: {config_path}", file=sys.stderr)
        sys.exit(1)

    if getattr(args, "json", False):
        print(json_mod.dumps({"path": config_path, "config": config}, indent=2))
        return

    print(f"Config: {config_path}\n")
    print(yaml.dump(config, default_flow_style=False, sort_keys=False), end="")
