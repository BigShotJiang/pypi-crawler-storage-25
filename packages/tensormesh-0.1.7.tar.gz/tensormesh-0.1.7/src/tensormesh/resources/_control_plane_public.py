from __future__ import annotations

from typing import Any, Iterator, Mapping

from tensormesh.resources._control_plane_activities_generated import \
    ACTIVITIES_GET_OPERATION
from tensormesh.resources._control_plane_activities_generated import \
    ACTIVITIES_LIST_OPERATION
from tensormesh.resources._control_plane_activities_generated import \
    activities_next_numbered_page
from tensormesh.resources._control_plane_activities_generated import \
    build_activities_get_path
from tensormesh.resources._control_plane_activities_generated import \
    build_activities_list_params
from tensormesh.resources._control_plane_activities_generated import \
    parse_activities_get_response
from tensormesh.resources._control_plane_activities_generated import \
    parse_activities_list_response
from tensormesh.resources._control_plane_models_generated import \
    build_models_delete_params
from tensormesh.resources._control_plane_models_generated import \
    build_models_delete_path
from tensormesh.resources._control_plane_models_generated import \
    build_models_get_params
from tensormesh.resources._control_plane_models_generated import \
    build_models_get_path
from tensormesh.resources._control_plane_models_generated import \
    build_models_list_params
from tensormesh.resources._control_plane_models_generated import \
    MODELS_DELETE_OPERATION
from tensormesh.resources._control_plane_models_generated import \
    MODELS_GET_OPERATION
from tensormesh.resources._control_plane_models_generated import \
    MODELS_LIST_OPERATION
from tensormesh.resources._control_plane_models_generated import \
    parse_models_delete_response
from tensormesh.resources._control_plane_models_generated import \
    parse_models_get_response
from tensormesh.resources._control_plane_models_generated import \
    parse_models_list_response
from tensormesh.resources._control_plane_shared import \
    coerce_request as _coerce_request
from tensormesh.resources._control_plane_shared import \
    compact_params as _compact_params
from tensormesh.resources._control_plane_shared import \
    ControlPlaneSurfaceProtocol as _ControlPlaneSurfaceProtocol
from tensormesh.resources._control_plane_shared import \
    quote_path_value as _quote_path_value
from tensormesh.resources._control_plane_shared import \
    require_response_list_field as _require_response_list_field
from tensormesh.resources._control_plane_shared import \
    require_response_mapping_field as _require_response_mapping_field
from tensormesh.resources._control_plane_user_api_keys_generated import \
    build_user_api_keys_create_payload
from tensormesh.resources._control_plane_user_api_keys_generated import \
    build_user_api_keys_delete_params
from tensormesh.resources._control_plane_user_api_keys_generated import \
    build_user_api_keys_list_params
from tensormesh.resources._control_plane_user_api_keys_generated import \
    parse_user_api_keys_create_response
from tensormesh.resources._control_plane_user_api_keys_generated import \
    parse_user_api_keys_delete_response
from tensormesh.resources._control_plane_user_api_keys_generated import \
    parse_user_api_keys_list_response
from tensormesh.resources._control_plane_user_api_keys_generated import \
    USER_API_KEYS_CREATE_OPERATION
from tensormesh.resources._control_plane_user_api_keys_generated import \
    USER_API_KEYS_DELETE_OPERATION
from tensormesh.resources._control_plane_user_api_keys_generated import \
    USER_API_KEYS_LIST_OPERATION
from tensormesh.types.control_plane import ActivitiesPage
from tensormesh.types.control_plane import Activity
from tensormesh.types.control_plane import ApiKey
from tensormesh.types.control_plane import CreateUserApiKeyRequest
from tensormesh.types.control_plane import DeletionResult
from tensormesh.types.control_plane import DeployModelRequest
from tensormesh.types.control_plane import EmptyResult
from tensormesh.types.control_plane import Model
from tensormesh.types.control_plane import ModelChatRequest
from tensormesh.types.control_plane import ModelChatResponse
from tensormesh.types.control_plane import ModelCheckRequest
from tensormesh.types.control_plane import ModelCheckResult
from tensormesh.types.control_plane import Product
from tensormesh.types.control_plane import UpdateUserProfileRequest
from tensormesh.types.control_plane import User
from tensormesh.types.control_plane import ValidateModelNameRequest
from tensormesh.types.control_plane import ValidationResult


class ModelsClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def list(
        self,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> list[Model]:
        response = self._surface.request(
            MODELS_LIST_OPERATION.method,
            MODELS_LIST_OPERATION.path,
            params=build_models_list_params(user_id=user_id),
            timeout=timeout,
        )
        return parse_models_list_response(response.json())

    def get(
        self,
        model_id: str,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> Model | None:
        response = self._surface.request(
            MODELS_GET_OPERATION.method,
            build_models_get_path(model_id),
            params=build_models_get_params(user_id=user_id),
            timeout=timeout,
        )
        return parse_models_get_response(response.json())

    def delete(
        self,
        model_id: str,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> EmptyResult:
        response = self._surface.request(
            MODELS_DELETE_OPERATION.method,
            build_models_delete_path(model_id),
            params=build_models_delete_params(user_id=user_id),
            timeout=timeout,
        )
        return parse_models_delete_response(response.json())

    def chat(
        self,
        model_id: str,
        *,
        request: ModelChatRequest | Mapping[str, Any] | None = None,
        body: str | None = None,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> ModelChatResponse:
        payload = _coerce_request(
            request=request,
            request_cls=ModelChatRequest,
            request_name="model chat request",
            fields={
                "body": body,
                "user_id": user_id,
            },
        )
        response = self._surface.request(
            "POST",
            f"/v1/models/{_quote_path_value(model_id)}:chat",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return ModelChatResponse.from_dict(response.json())

    def search_by_infra(
        self,
        *,
        request: Mapping[str, Any] | None = None,
        infra: Mapping[str, Any] | None = None,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> list[Model]:
        if request is not None and (infra is not None or user_id is not None):
            raise ValueError(
                "Pass either `request=` or individual search-by-infra fields, not both."
            )
        if request is None:
            if infra is None:
                raise ValueError(
                    "Missing required fields for model infra search request: `infra`."
                )
            json_body = _compact_params({
                "infra": dict(infra),
                "userId": user_id,
            })
        else:
            json_body = _compact_params(dict(request))
        response = self._surface.request(
            "POST",
            "/v1/models:search-by-infra",
            json_body=json_body,
            timeout=timeout,
        )
        body = response.json()
        return [
            Model.from_dict(item) for item in _require_response_list_field(
                body,
                "models",
                context="model infra search response",
            )
        ]

    def validate_name(
        self,
        *,
        request: ValidateModelNameRequest | Mapping[str, Any] | None = None,
        model_name: str | None = None,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> ValidationResult:
        payload = _coerce_request(
            request=request,
            request_cls=ValidateModelNameRequest,
            request_name="model validation request",
            fields={
                "model_name": model_name,
                "user_id": user_id,
            },
        )
        response = self._surface.request(
            "POST",
            "/v1/models:validate",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return ValidationResult.from_dict(response.json())

    def deploy(
        self,
        *,
        request: DeployModelRequest | Mapping[str, Any] | None = None,
        model_name: str | None = None,
        user_id: str | None = None,
        description: str | None = None,
        infra: Mapping[str, Any] | None = None,
        model_path: str | None = None,
        gpu_count: int | None = None,
        gpu_type: str | None = None,
        model_spec: Mapping[str, Any] | None = None,
        api_key: str | None = None,
        hf_token: str | None = None,
        kv_cache_enabled: bool | None = None,
        cpu_offloading_enabled: bool | None = None,
        node_id: str | None = None,
        timeout: float | None = None,
    ) -> Model | None:
        payload = _coerce_request(
            request=request,
            request_cls=DeployModelRequest,
            request_name="model deploy request",
            fields={
                "model_name":
                model_name,
                "user_id":
                user_id,
                "description":
                description,
                "infra":
                infra,
                "model_path":
                model_path,
                "gpu_count":
                gpu_count,
                "gpu_type":
                gpu_type,
                "model_spec":
                dict(model_spec)
                if isinstance(model_spec, Mapping) else model_spec,
                "api_key":
                api_key,
                "hf_token":
                hf_token,
                "kv_cache_enabled":
                kv_cache_enabled,
                "cpu_offloading_enabled":
                cpu_offloading_enabled,
                "node_id":
                node_id,
            },
        )
        response = self._surface.request(
            "POST",
            "/v1/models",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return Model.from_dict(
            _require_response_mapping_field(
                response.json(),
                "model",
                context="model deploy response",
            ))

    def check(
        self,
        *,
        request: ModelCheckRequest | Mapping[str, Any] | None = None,
        model_id: str | None = None,
        timeout: float | None = None,
    ) -> ModelCheckResult:
        payload = _coerce_request(
            request=request,
            request_cls=ModelCheckRequest,
            request_name="model check request",
            fields={"model_id": model_id},
        )
        response = self._surface.request(
            "POST",
            "/v1/models/check",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return ModelCheckResult.from_dict(response.json())


class UserApiKeysClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def list(
        self,
        *,
        user_id: str | None = None,
        include_deleted: bool | None = None,
        timeout: float | None = None,
    ) -> list[ApiKey]:
        response = self._surface.request(
            USER_API_KEYS_LIST_OPERATION.method,
            USER_API_KEYS_LIST_OPERATION.path,
            params=build_user_api_keys_list_params(
                user_id=user_id,
                include_deleted=include_deleted,
            ),
            timeout=timeout,
        )
        return parse_user_api_keys_list_response(response.json())

    def create(
        self,
        *,
        request: CreateUserApiKeyRequest | Mapping[str, Any] | None = None,
        user_id: str | None = None,
        name: str | None = None,
        scopes: list[str] | None = None,
        expires_at: str | None = None,
        timeout: float | None = None,
    ) -> ApiKey | None:
        payload = build_user_api_keys_create_payload(
            request=request,
            user_id=user_id,
            name=name,
            scopes=scopes,
            expires_at=expires_at,
        )
        response = self._surface.request(
            USER_API_KEYS_CREATE_OPERATION.method,
            USER_API_KEYS_CREATE_OPERATION.path,
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return parse_user_api_keys_create_response(response.json())

    def delete(
        self,
        *,
        api_key: str,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> EmptyResult:
        response = self._surface.request(
            USER_API_KEYS_DELETE_OPERATION.method,
            USER_API_KEYS_DELETE_OPERATION.path,
            params=build_user_api_keys_delete_params(
                api_key=api_key,
                user_id=user_id,
            ),
            timeout=timeout,
        )
        return parse_user_api_keys_delete_response(response.json())


class UsersClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface
        self.api_keys = UserApiKeysClient(surface)

    def get_auth_profile(self, *, timeout: float | None = None) -> User | None:
        response = self._surface.request("GET",
                                         "/auth/profile",
                                         timeout=timeout)
        return User.from_dict(
            _require_response_mapping_field(
                response.json(),
                "user",
                context="auth profile response",
            ))

    def accept_tos(
        self,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> User | None:
        response = self._surface.request(
            "POST",
            "/v1/users/accept-tos",
            params=_compact_params({"userId": user_id}),
            json_body={},
            timeout=timeout,
        )
        return User.from_dict(
            _require_response_mapping_field(
                response.json(),
                "user",
                context="accept terms response",
            ))

    def get(
        self,
        user_id: str,
        *,
        user_email: str | None = None,
        timeout: float | None = None,
    ) -> User | None:
        response = self._surface.request(
            "GET",
            f"/v1/users/{_quote_path_value(user_id)}",
            params=_compact_params({"userEmail": user_email}),
            timeout=timeout,
        )
        return User.from_dict(
            _require_response_mapping_field(
                response.json(),
                "user",
                context="user lookup response",
            ))

    def get_by_email(
        self,
        user_email: str,
        *,
        user_id: str | None = None,
        timeout: float | None = None,
    ) -> User | None:
        response = self._surface.request(
            "GET",
            f"/v1/users/by-email/{_quote_path_value(user_email)}",
            params=_compact_params({"userId": user_id}),
            timeout=timeout,
        )
        return User.from_dict(
            _require_response_mapping_field(
                response.json(),
                "user",
                context="user by email response",
            ))

    def update(
        self,
        user_id: str,
        *,
        request: UpdateUserProfileRequest | Mapping[str, Any] | None = None,
        first_name: str | None = None,
        last_name: str | None = None,
        display_name: str | None = None,
        company: str | None = None,
        timeout: float | None = None,
    ) -> EmptyResult:
        payload = _coerce_request(
            request=request,
            request_cls=UpdateUserProfileRequest,
            request_name="user update request",
            fields={
                "first_name": first_name,
                "last_name": last_name,
                "display_name": display_name,
                "company": company,
            },
        )
        response = self._surface.request(
            "PUT",
            f"/v1/users/{_quote_path_value(user_id)}",
            json_body=payload.to_dict(),
            timeout=timeout,
        )
        return EmptyResult.from_dict(
            _require_response_mapping_field(
                response.json(),
                "empty",
                context="user update response",
            ))


class ActivitiesClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def list(
        self,
        *,
        user_id: str | None = None,
        action: str | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        page: int | None = None,
        size: int | None = None,
        timeout: float | None = None,
    ) -> ActivitiesPage:
        response = self._surface.request(
            ACTIVITIES_LIST_OPERATION.method,
            ACTIVITIES_LIST_OPERATION.path,
            params=build_activities_list_params(
                user_id=user_id,
                action=action,
                resource_type=resource_type,
                resource_id=resource_id,
                start_time=start_time,
                end_time=end_time,
                page=page,
                size=size,
            ),
            timeout=timeout,
        )
        return parse_activities_list_response(response.json())

    def get(
        self,
        activity_id: str,
        *,
        timeout: float | None = None,
    ) -> Activity | None:
        response = self._surface.request(
            ACTIVITIES_GET_OPERATION.method,
            build_activities_get_path(activity_id),
            timeout=timeout,
        )
        return parse_activities_get_response(response.json())

    def auto_paging_iter(
        self,
        *,
        user_id: str | None = None,
        action: str | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        page: int | None = None,
        size: int | None = None,
        timeout: float | None = None,
    ) -> Iterator[Activity]:
        current_page = 1 if page is None else page
        while True:
            current = self.list(
                user_id=user_id,
                action=action,
                resource_type=resource_type,
                resource_id=resource_id,
                start_time=start_time,
                end_time=end_time,
                page=current_page,
                size=size,
                timeout=timeout,
            )
            for activity in current.activities:
                yield activity

            has_more, next_page = activities_next_numbered_page(
                current, current_page=current_page, size=size)
            if not has_more:
                return
            current_page = next_page


class ProductsClient:

    def __init__(self, surface: _ControlPlaneSurfaceProtocol) -> None:
        self._surface = surface

    def list(self, *, timeout: float | None = None) -> list[Product]:
        response = self._surface.request("GET",
                                         "/v1/products",
                                         timeout=timeout)
        body = response.json()
        return [
            Product.from_dict(item) for item in _require_response_list_field(
                body,
                "products",
                context="product list response",
            )
        ]

    def delete(
        self,
        product_id: str,
        *,
        timeout: float | None = None,
    ) -> DeletionResult:
        response = self._surface.request(
            "DELETE",
            f"/v1/products/{_quote_path_value(product_id)}",
            timeout=timeout,
        )
        return DeletionResult.from_dict(response.json())
