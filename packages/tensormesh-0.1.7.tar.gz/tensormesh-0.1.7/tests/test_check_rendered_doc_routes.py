from __future__ import annotations

from pathlib import Path
from urllib import error

from tests.script_test_utils import load_script_module

SCRIPT_PATH = (Path(__file__).resolve().parents[1] / "scripts" /
               "check-rendered-doc-routes.py")
REPO_ROOT = Path(__file__).resolve().parents[1]


def test_page_route_normalizes_index_pages() -> None:
    mod = load_script_module(SCRIPT_PATH)

    assert mod.page_route("index") == "/"
    assert mod.page_route("cli/index") == "/cli"
    assert mod.page_route("cli/reference/index") == "/cli/reference"
    assert mod.page_route("sdk/guides/inference") == "/sdk/guides/inference"


def test_expected_routes_include_docs_pages_openapi_groups_and_redirects(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    docs = mod.load_docs_json(REPO_ROOT / "docs" / "docs.json")

    routes = mod.expected_routes(docs)

    assert "/" in routes
    assert "/api-quickstart" in routes
    assert "/cli" in routes
    assert "/api-reference/on-demand" in routes
    assert "/tensormesh-api/billing/v1/pricing_service" in routes
    assert "/api-reference/on-demand/post/v1/chat/completions" in routes
    assert "/tensormesh-api/user/v1/user_service/users/get-user-by-email" in routes
    assert (
        "/tensormesh-api/billing/v1/pricing_service/post/v1/admin/billing/gpu-pricing"
        in routes)


def test_expected_routes_can_exclude_redirect_sources() -> None:
    mod = load_script_module(SCRIPT_PATH)
    docs = mod.load_docs_json(REPO_ROOT / "docs" / "docs.json")

    routes = mod.expected_routes(docs, include_redirects=False)

    assert "/api-reference/on-demand" in routes
    assert "/api-reference/on-demand/post/v1/chat/completions" not in routes


def test_iter_authored_mdx_routes_includes_non_nav_api_pages() -> None:
    mod = load_script_module(SCRIPT_PATH)

    routes = mod.iter_authored_mdx_routes(REPO_ROOT / "docs")

    assert "/" in routes
    assert "/api-reference/on-demand" in routes
    assert "/api-reference/serverless" in routes
    assert "/tensormesh-api" in routes
    assert "/tensormesh-api/user/v1/user_service" in routes
    assert "/tensormesh-api/model/v1/model" in routes
    assert "/tensormesh-api/support/v1/support_service" in routes
    assert "/tensormesh-api/billing/v1/pricing_service" in routes


def test_fetch_status_falls_back_to_get_after_head_500(monkeypatch) -> None:
    mod = load_script_module(SCRIPT_PATH)

    class _Response:

        def __init__(self, status: int) -> None:
            self.status = status
            self.headers = {}

        def __enter__(self) -> "_Response":
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            return None

    def fake_urlopen(req, timeout):  # type: ignore[no-untyped-def]
        del timeout
        method = req.get_method()
        if method == "HEAD":
            raise error.HTTPError(req.full_url, 500, "boom", hdrs={}, fp=None)
        assert method == "GET"
        return _Response(200)

    monkeypatch.setattr(mod.request, "urlopen", fake_urlopen)

    status, location = mod.fetch_status("http://localhost:3000",
                                        "/cli",
                                        timeout=1.0)

    assert status == 200
    assert location is None


def test_fetch_status_falls_back_to_get_after_head_timeout(
        monkeypatch) -> None:
    mod = load_script_module(SCRIPT_PATH)

    class _Response:

        def __init__(self, status: int) -> None:
            self.status = status
            self.headers = {}

        def __enter__(self) -> "_Response":
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            return None

    def fake_urlopen(req, timeout):  # type: ignore[no-untyped-def]
        del timeout
        method = req.get_method()
        if method == "HEAD":
            raise TimeoutError("slow compile")
        assert method == "GET"
        return _Response(200)

    monkeypatch.setattr(mod.request, "urlopen", fake_urlopen)

    status, location = mod.fetch_status("http://localhost:3000",
                                        "/cli",
                                        timeout=1.0)

    assert status == 200
    assert location is None


def test_fetch_status_retries_transient_5xx(monkeypatch) -> None:
    mod = load_script_module(SCRIPT_PATH)

    class _Response:

        def __init__(self, status: int) -> None:
            self.status = status
            self.headers = {}

        def __enter__(self) -> "_Response":
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            return None

    calls = iter([
        error.HTTPError("http://localhost:3000/cli",
                        500,
                        "boom",
                        hdrs={},
                        fp=None),
        error.HTTPError("http://localhost:3000/cli",
                        500,
                        "boom",
                        hdrs={},
                        fp=None),
        _Response(200),
    ])

    def fake_urlopen(req, timeout):  # type: ignore[no-untyped-def]
        del req, timeout
        result = next(calls)
        if isinstance(result, Exception):
            raise result
        return result

    monkeypatch.setattr(mod.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(mod.time, "sleep", lambda _: None)

    status, location = mod.fetch_status("http://localhost:3000",
                                        "/cli",
                                        timeout=1.0)

    assert status == 200
    assert location is None


def test_fetch_status_retries_transient_request_timeouts(monkeypatch) -> None:
    mod = load_script_module(SCRIPT_PATH)

    class _Response:

        def __init__(self, status: int) -> None:
            self.status = status
            self.headers = {}

        def __enter__(self) -> "_Response":
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            return None

    calls = iter([
        TimeoutError("slow compile"),
        TimeoutError("slow compile"),
        _Response(200),
    ])

    def fake_urlopen(req, timeout):  # type: ignore[no-untyped-def]
        del req, timeout
        result = next(calls)
        if isinstance(result, Exception):
            raise result
        return result

    monkeypatch.setattr(mod.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(mod.time, "sleep", lambda _: None)

    status, location = mod.fetch_status("http://localhost:3000",
                                        "/sdk",
                                        timeout=1.0)

    assert status == 200
    assert location is None


def test_fetch_status_tolerates_longer_transient_5xx_bursts(
        monkeypatch) -> None:
    mod = load_script_module(SCRIPT_PATH)

    class _Response:

        def __init__(self, status: int) -> None:
            self.status = status
            self.headers = {}

        def __enter__(self) -> "_Response":
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            return None

    calls = iter([
        error.HTTPError("http://localhost:3000/sdk",
                        500,
                        "boom",
                        hdrs={},
                        fp=None),
        error.HTTPError("http://localhost:3000/sdk",
                        500,
                        "boom",
                        hdrs={},
                        fp=None),
        error.HTTPError("http://localhost:3000/sdk",
                        500,
                        "boom",
                        hdrs={},
                        fp=None),
        error.HTTPError("http://localhost:3000/sdk",
                        500,
                        "boom",
                        hdrs={},
                        fp=None),
        error.HTTPError("http://localhost:3000/sdk",
                        500,
                        "boom",
                        hdrs={},
                        fp=None),
        error.HTTPError("http://localhost:3000/sdk",
                        500,
                        "boom",
                        hdrs={},
                        fp=None),
        error.HTTPError("http://localhost:3000/sdk",
                        500,
                        "boom",
                        hdrs={},
                        fp=None),
        error.HTTPError("http://localhost:3000/sdk",
                        500,
                        "boom",
                        hdrs={},
                        fp=None),
        _Response(200),
    ])

    def fake_urlopen(req, timeout):  # type: ignore[no-untyped-def]
        del req, timeout
        result = next(calls)
        if isinstance(result, Exception):
            raise result
        return result

    monkeypatch.setattr(mod.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(mod.time, "sleep", lambda _: None)

    status, location = mod.fetch_status("http://localhost:3000",
                                        "/sdk",
                                        timeout=1.0)

    assert status == 200
    assert location is None


def test_wait_for_route_readiness_retries_until_routes_stop_returning_5xx(
        monkeypatch) -> None:
    mod = load_script_module(SCRIPT_PATH)

    responses = {
        "/": iter([(200, None)]),
        "/cli": iter([(500, None), (200, None)]),
    }
    calls: list[str] = []

    def fake_probe_warmup_status(base_url: str, route: str, *,
                                 timeout: float) -> tuple[int, str | None]:
        del base_url, timeout
        calls.append(route)
        return next(responses[route])

    monotonic_values = iter([0.0, 0.1, 0.2, 0.3, 0.4])

    monkeypatch.setattr(mod, "probe_warmup_status", fake_probe_warmup_status)
    monkeypatch.setattr(mod.time, "sleep", lambda _: None)
    monkeypatch.setattr(mod.time, "monotonic", lambda: next(monotonic_values))

    failures = mod.wait_for_route_readiness(base_url="http://localhost:3000",
                                            routes=["/", "/cli"],
                                            timeout=1.0,
                                            warmup_timeout=2.0)

    assert failures == []
    assert calls == ["/", "/cli", "/cli"]


def test_wait_for_route_readiness_reports_routes_that_never_warm(
        monkeypatch) -> None:
    mod = load_script_module(SCRIPT_PATH)

    def fake_probe_warmup_status(base_url: str, route: str, *,
                                 timeout: float) -> tuple[int, str | None]:
        del base_url, timeout
        assert route == "/cli"
        return 500, None

    monotonic_values = iter([0.0, 0.2, 0.6, 1.1])

    monkeypatch.setattr(mod, "probe_warmup_status", fake_probe_warmup_status)
    monkeypatch.setattr(mod.time, "sleep", lambda _: None)
    monkeypatch.setattr(mod.time, "monotonic", lambda: next(monotonic_values))

    failures = mod.wait_for_route_readiness(base_url="http://localhost:3000",
                                            routes=["/cli"],
                                            timeout=1.0,
                                            warmup_timeout=1.0)

    assert failures == ["/cli: warmup stalled at HTTP 500"]


def test_wait_for_route_readiness_stops_once_deadline_is_exceeded(
        monkeypatch) -> None:
    mod = load_script_module(SCRIPT_PATH)

    calls: list[str] = []

    def fake_probe_warmup_status(base_url: str, route: str, *,
                                 timeout: float) -> tuple[int, str | None]:
        del base_url, timeout
        calls.append(route)
        return 500, None

    monotonic_values = iter([0.0, 0.5, 1.1])

    monkeypatch.setattr(mod, "probe_warmup_status", fake_probe_warmup_status)
    monkeypatch.setattr(mod.time, "sleep", lambda _: None)
    monkeypatch.setattr(mod.time, "monotonic", lambda: next(monotonic_values))

    failures = mod.wait_for_route_readiness(base_url="http://localhost:3000",
                                            routes=["/one", "/two"],
                                            timeout=1.0,
                                            warmup_timeout=1.0)

    assert failures == [
        "/one: warmup stalled at HTTP 500",
        "/two: warmup stalled at HTTP 500",
    ]
    assert calls == ["/one", "/two"]


def test_warmup_request_timeout_uses_fast_timeout_for_large_pending_sets(
) -> None:
    mod = load_script_module(SCRIPT_PATH)

    assert mod.warmup_request_timeout(
        timeout=15.0,
        pending_count=100) == mod._WARMUP_FAST_REQUEST_TIMEOUT_SECONDS
    assert mod.warmup_request_timeout(
        timeout=15.0, pending_count=mod._WARMUP_MAX_WORKERS) == 15.0


def test_warmup_routes_focus_on_section_and_reference_seed_pages() -> None:
    mod = load_script_module(SCRIPT_PATH)
    docs = mod.load_docs_json(REPO_ROOT / "docs" / "docs.json")

    routes = mod.warmup_routes(docs)

    assert "/" in routes
    assert "/sdk" in routes
    assert "/cli" in routes
    assert "/cli/reference/auth" in routes
    assert "/api-reference/serverless" in routes
    assert "/api-reference/on-demand/post/v1/chat/completions" not in routes
    assert "/tensormesh-api/user/v1/user_service/users/get-user-by-email" not in routes
