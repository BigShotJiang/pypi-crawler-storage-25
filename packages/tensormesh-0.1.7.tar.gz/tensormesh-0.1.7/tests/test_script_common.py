from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import socket
import stat
import subprocess
import textwrap

from tests.cli_test_utils import write_controlplane_auth_json
from tests.cli_test_utils import write_runtime_home

REPO_ROOT = Path(__file__).resolve().parents[1]


def _run_common(function_call: str,
                env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    merged_env = os.environ.copy()
    merged_env.update(env)
    return subprocess.run(
        [
            "bash",
            "-lc",
            f"source '{REPO_ROOT / 'scripts/lib/common.sh'}'; {function_call}",
        ],
        cwd=REPO_ROOT,
        env=merged_env,
        capture_output=True,
        text=True,
        check=False,
    )


def _run_mintlify(function_call: str,
                  env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    merged_env = os.environ.copy()
    merged_env.update(env)
    return subprocess.run(
        [
            "bash",
            "-lc",
            f"source '{REPO_ROOT / 'scripts/lib/mintlify.sh'}'; {function_call}",
        ],
        cwd=REPO_ROOT,
        env=merged_env,
        capture_output=True,
        text=True,
        check=False,
    )


def test_gateway_chat_url_uses_configured_provider(tmp_path: Path) -> None:
    result = _run_common(
        "tm_gateway_chat_completions_url",
        {
            "HOME":
            write_runtime_home(home=tmp_path,
                               gateway_provider="lambda",
                               gateway_api_key=None,
                               gateway_user_id=None,
                               gateway_model_id=None)
        },
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip(
    ) == "https://external.lambda.tensormesh.ai/v1/chat/completions"


def test_verify_script_does_not_refresh_published_control_plane_specs_when_sync_is_skipped(
) -> None:
    verify_script = (REPO_ROOT / "scripts" /
                     "verify.sh").read_text(encoding="utf-8")

    assert "update-tensormesh-docs-json.py --write-published-specs-only" not in verify_script


def test_verify_script_rechecks_published_control_plane_specs_for_stability(
) -> None:
    verify_script = (REPO_ROOT / "scripts" /
                     "verify.sh").read_text(encoding="utf-8")

    assert "verify_published_control_plane_specs_stable" in verify_script
    assert "--published-specs-dir" in verify_script
    assert "diff -qr" in verify_script


def test_clean_script_preserves_checked_in_published_control_plane_specs(
) -> None:
    clean_script = (REPO_ROOT / "scripts" /
                    "clean.sh").read_text(encoding="utf-8")

    assert "docs/openapi/.generated/tensormesh-api/published-specs" not in clean_script
    assert 'rm -rf \\' in clean_script
    assert '"$ROOT_DIR/docs/tensormesh-api/.tmp"' in clean_script


def test_verify_script_runs_manifest_validation_and_rendered_route_smoke(
) -> None:
    verify_script = (REPO_ROOT / "scripts" /
                     "verify.sh").read_text(encoding="utf-8")

    assert '"$PYTHON_BIN" ./scripts/validate-sdk-codegen-manifest.py' in verify_script
    assert "bash ./scripts/verify-rendered-doc-routes.sh" in verify_script


def test_verify_script_can_skip_rendered_route_smoke() -> None:
    verify_script = (REPO_ROOT / "scripts" /
                     "verify.sh").read_text(encoding="utf-8")

    assert 'if [[ "${VERIFY_RENDERED_DOCS:-1}" != "0" ]]; then' in verify_script
    assert 'echo "skip: rendered docs verify (VERIFY_RENDERED_DOCS=0)" >&2' in verify_script


def test_verify_script_snapshots_repo_state_without_path_allowlist() -> None:
    verify_script = (REPO_ROOT / "scripts" /
                     "verify.sh").read_text(encoding="utf-8")

    assert 'git -C "$ROOT_DIR" status --short --untracked-files=all' in verify_script
    assert '-- "${GENERATED_PATHS[@]}"' not in verify_script


def test_verify_network_script_uses_repo_ca_bundle_and_surface_integration_suite(
) -> None:
    script = (REPO_ROOT / "scripts" /
              "verify-network.sh").read_text(encoding="utf-8")

    assert 'export TENSORMESH_CA_BUNDLE="${TENSORMESH_CA_BUNDLE:-$ROOT_DIR/certs/extra-ca.pem}"' in script
    assert "tests/integration/test_gateway_integration.py" in script
    assert "tests/integration/test_inference_surface_integration.py" in script


def test_verify_network_script_requires_live_inference_inputs() -> None:
    script = (REPO_ROOT / "scripts" /
              "verify-network.sh").read_text(encoding="utf-8")

    assert "gateway_api_key" in script
    assert "missing live inference input" in script


def test_doctor_script_uses_active_config_root() -> None:
    script = (REPO_ROOT / "scripts" / "doctor.sh").read_text(encoding="utf-8")

    assert 'ACTIVE_CONFIG_PATH="$(tm_controlplane_config_path "$ROOT_DIR")"' in script
    assert 'ACTIVE_CONFIG_DISPLAY="$(tm_controlplane_config_path_display "$ROOT_DIR")"' in script
    assert 'echo "config: $ACTIVE_CONFIG_DISPLAY present"' in script
    assert 'echo "managed: $ACTIVE_CONFIG_DISPLAY [managed] present"' in script


def test_common_config_helpers_use_tm_config_home_when_resolving_state_root(
) -> None:
    script = (REPO_ROOT / "scripts" / "lib" /
              "common.sh").read_text(encoding="utf-8")

    assert "tm_controlplane_config_path()" in script
    assert 'local config_home="${TM_CONFIG_HOME:-$HOME/.config/tensormesh}"' in script
    assert 'config_path="$(tm_controlplane_config_path "$root")"' in script


def test_verify_network_script_does_not_hard_require_gateway_model_or_provider(
) -> None:
    script = (REPO_ROOT / "scripts" /
              "verify-network.sh").read_text(encoding="utf-8")

    assert "require_gateway_network_inputs" not in script
    assert "missing gateway network inputs" not in script


def test_verify_rendered_docs_script_uses_mintlify_start_stop_helpers(
) -> None:
    script = (REPO_ROOT / "scripts" /
              "verify-rendered-doc-routes.sh").read_text(encoding="utf-8")

    assert "tm_mintlify_dev_start" in script
    assert "tm_mintlify_dev_stop" in script
    assert "$ROOT_DIR/scripts/check-rendered-doc-routes.py" in script


def test_verify_rendered_docs_script_is_executable() -> None:
    mode = (REPO_ROOT / "scripts" /
            "verify-rendered-doc-routes.sh").stat().st_mode

    assert mode & stat.S_IXUSR


def test_verify_rendered_docs_script_retries_route_sweep_after_startup_warmup(
) -> None:
    script = (REPO_ROOT / "scripts" /
              "verify-rendered-doc-routes.sh").read_text(encoding="utf-8")

    assert "TM_RENDERED_DOC_ROUTE_ATTEMPTS" in script
    assert "TM_RENDERED_DOC_ROUTE_RETRY_DELAY_SECONDS" in script
    assert "TM_RENDERED_DOC_WARMUP_TIMEOUT_SECONDS" in script
    assert 'ATTEMPTS="${TM_RENDERED_DOC_ROUTE_ATTEMPTS:-3}"' in script
    assert 'RETRY_DELAY_SECONDS="${TM_RENDERED_DOC_ROUTE_RETRY_DELAY_SECONDS:-3}"' in script
    assert 'WARMUP_TIMEOUT_SECONDS="${TM_RENDERED_DOC_WARMUP_TIMEOUT_SECONDS:-90}"' in script
    assert "--warmup-timeout" in script
    assert "retry: rendered docs sweep attempt=" in script


def test_bootstrap_script_preflights_npm_registry_tls() -> None:
    bootstrap_script = (REPO_ROOT / "scripts" /
                        "bootstrap.sh").read_text(encoding="utf-8")

    assert "tm_verify_node_https" in bootstrap_script
    assert "https://registry.npmjs.org/-/ping?write=true" in bootstrap_script


def test_bootstrap_script_skips_rendered_docs_verify_in_fast_path() -> None:
    bootstrap_script = (REPO_ROOT / "scripts" /
                        "bootstrap.sh").read_text(encoding="utf-8")

    assert 'VERIFY_RENDERED_DOCS=0 VERIFY_SYNC=0 ./scripts/verify.sh' in bootstrap_script


def test_common_gateway_url_helper_does_not_keep_redundant_base_wrapper(
) -> None:
    common_script = (REPO_ROOT / "scripts" / "lib" /
                     "common.sh").read_text(encoding="utf-8")

    assert "tm_require_gateway_base()" not in common_script


def test_gateway_smoke_scripts_pass_repo_root_to_chat_url_helper() -> None:
    inference_script = (REPO_ROOT / "scripts" /
                        "test-inference-direct.sh").read_text(encoding="utf-8")
    playground_script = (REPO_ROOT / "scripts" /
                         "test-playground-proxy.sh").read_text(
                             encoding="utf-8")

    assert 'GATEWAY_URL="$(tm_gateway_chat_completions_url "$ROOT_DIR")"' in inference_script
    assert 'TM_GATEWAY_CHAT_URL="$(tm_gateway_chat_completions_url "$ROOT_DIR")"' in playground_script


def test_gateway_chat_url_rejects_control_plane_style_provider_name(
        tmp_path: Path) -> None:
    result = _run_common(
        "tm_gateway_chat_completions_url",
        {
            "HOME":
            write_runtime_home(
                home=tmp_path,
                gateway_provider="CLOUD_PROVIDER_LAMBDA",
                gateway_api_key=None,
                gateway_user_id=None,
                gateway_model_id=None,
            )
        },
    )

    assert result.returncode != 0
    assert "Invalid value for gateway_provider" in result.stderr


def test_gateway_chat_url_defaults_from_resolved_config(
        tmp_path: Path) -> None:
    result = _run_common("tm_gateway_chat_completions_url",
                         {"HOME": str(tmp_path)})

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip(
    ) == "https://external.nebius.tensormesh.ai/v1/chat/completions"


def test_gateway_chat_url_rejects_invalid_provider(tmp_path: Path) -> None:
    result = _run_common(
        "tm_gateway_chat_completions_url",
        {
            "HOME":
            write_runtime_home(home=tmp_path,
                               gateway_provider="unknown",
                               gateway_api_key=None,
                               gateway_user_id=None,
                               gateway_model_id=None)
        },
    )

    assert result.returncode != 0
    assert "Invalid value for gateway_provider" in result.stderr


def test_mintlify_find_free_port_returns_bindable_port() -> None:
    result = _run_mintlify("tm_mintlify_find_free_port", {})

    assert result.returncode == 0, result.stderr
    port = int(result.stdout.strip())
    assert port > 0

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", port))


def test_mintlify_dev_stop_only_targets_configured_pid() -> None:
    result = _run_mintlify(
        'sleep 30 & pid=$!; TM_MINTLIFY_PID="$pid"; tm_mintlify_dev_stop; if kill -0 "$pid" >/dev/null 2>&1; then echo "still-running" >&2; exit 1; fi',
        {},
    )

    assert result.returncode == 0, result.stderr


def test_mintlify_helpers_use_process_group_cleanup() -> None:
    script = (REPO_ROOT / "scripts" / "lib" /
              "mintlify.sh").read_text(encoding="utf-8")

    assert "setsid" in script
    assert 'setsid "$mintlify_bin" dev --no-open --port "$TM_MINTLIFY_PORT"' in script
    assert "setsid tm_mintlify" not in script
    assert 'kill -- -"$TM_MINTLIFY_PID"' in script


def test_resolve_python312_bin_prefers_supported_python() -> None:
    result = _run_common("tm_resolve_python312_bin", {})

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() in {"python3.12", "python3"}


def test_resolve_repo_python312_bin_falls_back_from_stale_repo_venv(
        tmp_path: Path) -> None:
    fake_python = tmp_path / ".venv" / "bin" / "python"
    fake_python.parent.mkdir(parents=True)
    fake_python.write_text(
        textwrap.dedent("""\
            #!/usr/bin/env bash
            if [[ "$1" == "-c" ]]; then
              echo "3.11"
              exit 0
            fi
            exit 0
        """),
        encoding="utf-8",
    )
    fake_python.chmod(0o755)

    result = _run_common(f'tm_resolve_repo_python312_bin "{tmp_path}"', {})

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() in {"python3.12", "python3"}
    assert "warning: ignoring unsupported repo venv" in result.stderr


def test_controlplane_access_token_reads_auth_json(tmp_path: Path) -> None:
    if shutil.which("jq") is None:
        return

    write_controlplane_auth_json(home=tmp_path,
                                 access_token="tok_from_auth_json")
    result = _run_common(
        f'tm_controlplane_access_token "{REPO_ROOT}"',
        {"HOME": str(tmp_path)},
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "tok_...json"


def test_controlplane_access_token_unsafe_reads_auth_json(
        tmp_path: Path) -> None:
    if shutil.which("jq") is None:
        return

    write_controlplane_auth_json(home=tmp_path,
                                 access_token="tok_from_auth_json")
    result = _run_common(
        f'tm_controlplane_access_token_unsafe "{REPO_ROOT}"',
        {"HOME": str(tmp_path)},
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "tok_from_auth_json"


def test_controlplane_auth_json_path_respects_tm_config_home(
        tmp_path: Path) -> None:
    config_home = tmp_path / "tm-state"
    auth_json = config_home / "auth.json"
    auth_json.parent.mkdir(parents=True, exist_ok=True)
    auth_json.write_text('{"access_token":"tok"}\n', encoding="utf-8")

    result = _run_common(
        f'tm_controlplane_auth_json_path "{REPO_ROOT}"',
        {
            "HOME": str(tmp_path),
            "TM_CONFIG_HOME": str(config_home),
        },
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == str(auth_json)


def test_controlplane_auth_json_path_uses_existing_file(
        tmp_path: Path) -> None:
    write_controlplane_auth_json(home=tmp_path,
                                 access_token="tok_from_auth_json")
    home = str(tmp_path)
    auth_json = tmp_path / ".config" / "tensormesh" / "auth.json"

    result = _run_common(
        f'tm_controlplane_auth_json_path "{REPO_ROOT}"',
        {"HOME": home},
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == str(auth_json)


def test_resolved_config_value_redacts_gateway_api_key(tmp_path: Path) -> None:
    home = write_runtime_home(home=tmp_path, gateway_api_key="gw_secret_key")

    result = _run_common(
        f'tm_resolved_config_value "{REPO_ROOT}" gateway_api_key',
        {"HOME": home},
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "gw_s..._key"


def test_resolved_config_secret_value_returns_unredacted_gateway_api_key(
        tmp_path: Path) -> None:
    home = write_runtime_home(home=tmp_path, gateway_api_key="gw_secret_key")

    result = _run_common(
        f'tm_resolved_config_secret_value "{REPO_ROOT}" gateway_api_key',
        {"HOME": home},
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "gw_secret_key"


def test_resolved_config_secret_value_respects_tm_config_home(
        tmp_path: Path) -> None:
    home = tmp_path / "home"
    config_home = tmp_path / "custom-state"
    config_home.mkdir(parents=True, exist_ok=True)
    (config_home / "config.toml").write_text(
        '[managed]\n'
        'gateway_api_key = "gw_secret_key"\n',
        encoding="utf-8",
    )

    result = _run_common(
        f'tm_resolved_config_secret_value "{REPO_ROOT}" gateway_api_key',
        {
            "HOME": str(home),
            "TM_CONFIG_HOME": str(config_home),
        },
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "gw_secret_key"


def test_resolved_config_sources_json_preserves_value_and_source_shapes(
        tmp_path: Path) -> None:
    home = write_runtime_home(
        home=tmp_path,
        gateway_provider="lambda",
        gateway_api_key="gw_secret_key",
    )

    result = _run_common(
        f'tm_resolved_config_sources_json "{REPO_ROOT}"',
        {"HOME": home},
    )

    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["values"]["gateway_provider"] == "lambda"
    assert payload["values"]["gateway_api_key"] == "gw_s..._key"
    assert payload["sources"]["gateway_provider"] == "managed:gateway_provider"
    assert payload["sources"]["gateway_api_key"] == "managed:gateway_api_key"


def test_e2e_cli_inference_does_not_pass_gateway_api_key_on_argv() -> None:
    script = (REPO_ROOT / "scripts" / "e2e-cli.sh").read_text(encoding="utf-8")

    assert '--api-key "$GATEWAY_API_KEY"' not in script


def test_inference_direct_script_uses_private_temp_dir_and_explicit_secret_helper(
) -> None:
    script = (REPO_ROOT / "scripts" /
              "test-inference-direct.sh").read_text(encoding="utf-8")

    assert "tm_resolved_config_secret_value" in script
    assert "mktemp -d /tmp/tm-inference-direct." in script
    assert 'trap cleanup EXIT' in script
    assert "/tmp/tm_inference_401.json" not in script


def test_resolved_config_value_respects_runtime_env_overrides(
        tmp_path: Path) -> None:
    home = write_runtime_home(
        home=tmp_path,
        gateway_api_key=None,
        gateway_user_id=None,
        gateway_model_id=None,
    )

    result = _run_common(
        f'tm_resolved_config_value "{REPO_ROOT}" timeout_seconds',
        {
            "HOME": home,
            "TENSORMESH_TIMEOUT_SECONDS": "9",
        },
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "9.0"


def test_resolved_config_source_respects_runtime_env_overrides(
        tmp_path: Path) -> None:
    home = write_runtime_home(
        home=tmp_path,
        gateway_api_key=None,
        gateway_user_id=None,
        gateway_model_id=None,
    )

    result = _run_common(
        f'tm_resolved_config_source "{REPO_ROOT}" timeout_seconds',
        {
            "HOME": home,
            "TENSORMESH_TIMEOUT_SECONDS": "9",
        },
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "TENSORMESH_TIMEOUT_SECONDS"
