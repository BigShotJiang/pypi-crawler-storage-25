from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.script_test_utils import load_script_module

SCRIPT_PATH = (Path(__file__).resolve().parents[1] / "scripts" /
               "update-tensormesh-docs-json.py")
REPO_ROOT = Path(__file__).resolve().parents[1]


def test_group_label_for_generated_model_surface_is_plain_model() -> None:
    mod = load_script_module(SCRIPT_PATH)

    assert mod._group_label("model/v1/model.openapi.json") == "Model"


def test_publish_manifest_declares_merged_model_surface() -> None:
    mod = load_script_module(SCRIPT_PATH)
    manifest = mod._load_publish_manifest(
        REPO_ROOT / "docs" / "tensormesh-api" / "publish-manifest.json")

    assert manifest["model/v1/model.openapi.json"]["sources"] == [
        "model/v1/model_service.openapi.json",
        "billing/v1/billing_model_service.openapi.json",
    ]


def test_publish_manifest_declares_group_and_operation_overrides() -> None:
    mod = load_script_module(SCRIPT_PATH)
    manifest_path = REPO_ROOT / "docs" / "tensormesh-api" / "publish-manifest.json"

    group_labels = mod._load_group_labels(manifest_path)
    tag_overrides = mod._load_tag_overrides_by_spec(manifest_path)
    operation_overrides = mod._load_operation_overrides_by_spec(manifest_path)

    assert group_labels["user/v1/user_service.openapi.json"] == "Users"
    assert tag_overrides["model/v1/model.openapi.json"] == "Models"
    assert (operation_overrides["user/v1/user_service.openapi.json"]
            ["GET /v1/users/by-email/{userEmail}"]["summary"] ==
            "Get User By Email")


def test_publish_manifest_declares_excluded_internal_user_paths() -> None:
    mod = load_script_module(SCRIPT_PATH)
    excluded = mod._load_excluded_paths_by_spec(
        REPO_ROOT / "docs" / "tensormesh-api" / "publish-manifest.json")

    assert excluded["user/v1/user_service.openapi.json"] == [
        "/internal/auth/api-keys/introspect"
    ]
    assert excluded["billing/v1/stripe_service.openapi.json"] == [
        "/v1/billing/stripe/webhook"
    ]


def test_publish_manifest_declares_excluded_deprecated_user_api_key_field(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    excluded = mod._load_excluded_schema_properties_by_spec(
        REPO_ROOT / "docs" / "tensormesh-api" / "publish-manifest.json")

    assert excluded["user/v1/user_service.openapi.json"] == {
        "v1User": ["apiKey"]
    }
    assert excluded["user/v1/admin_user_service.openapi.json"] == {
        "v1User": ["apiKey"]
    }


def test_docs_base_excludes_generated_control_plane_tab() -> None:
    mod = load_script_module(SCRIPT_PATH)
    docs_base = mod._load_docs_base(REPO_ROOT / "docs" / "docs.base.json")

    assert all(
        tab.get("tab") != mod.GENERATED_CONTROL_PLANE_TAB
        for tab in docs_base["navigation"]["tabs"])


def test_build_nav_specs_merges_model_surface_specs() -> None:
    mod = load_script_module(SCRIPT_PATH)
    raw_specs_dir = REPO_ROOT / mod.RAW_CONTROL_PLANE_SPECS_DIR
    published_specs_dir = REPO_ROOT / mod.PUBLISHED_CONTROL_PLANE_SPECS_DIR
    merged_nav_specs = mod._load_publish_manifest(
        REPO_ROOT / "docs" / "tensormesh-api" / "publish-manifest.json")

    nav_specs = dict(
        mod._build_nav_specs(
            raw_specs_dir,
            merged_nav_specs=merged_nav_specs,
            excluded_paths_by_spec=mod._load_excluded_paths_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            excluded_schema_properties_by_spec=(
                mod._load_excluded_schema_properties_by_spec(
                    REPO_ROOT / "docs" / "tensormesh-api" /
                    "publish-manifest.json")),
            tag_overrides_by_spec=mod._load_tag_overrides_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            operation_overrides_by_spec=mod._load_operation_overrides_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            output_specs_dir=published_specs_dir))

    assert "model/v1/model.openapi.json" in nav_specs
    assert "model/v1/model_service.openapi.json" not in nav_specs
    assert "billing/v1/billing_model_service.openapi.json" not in nav_specs

    merged_paths = nav_specs["model/v1/model.openapi.json"]["paths"]
    assert "get" in merged_paths["/v1/models"]
    assert "post" in merged_paths["/v1/models"]
    assert "post" in merged_paths["/v1/models/check"]


def test_build_nav_specs_excludes_internal_user_service_paths() -> None:
    mod = load_script_module(SCRIPT_PATH)
    raw_specs_dir = REPO_ROOT / mod.RAW_CONTROL_PLANE_SPECS_DIR

    nav_specs = dict(
        mod._build_nav_specs(
            raw_specs_dir,
            merged_nav_specs=mod._load_publish_manifest(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            excluded_paths_by_spec=mod._load_excluded_paths_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            excluded_schema_properties_by_spec=(
                mod._load_excluded_schema_properties_by_spec(
                    REPO_ROOT / "docs" / "tensormesh-api" /
                    "publish-manifest.json")),
            tag_overrides_by_spec=mod._load_tag_overrides_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            operation_overrides_by_spec=mod._load_operation_overrides_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            write_generated_specs=False))

    user_paths = nav_specs["user/v1/user_service.openapi.json"]["paths"]
    assert "/auth/profile" in user_paths
    assert "/internal/auth/api-keys/introspect" not in user_paths


def test_build_nav_specs_excludes_stripe_webhook_path() -> None:
    mod = load_script_module(SCRIPT_PATH)
    raw_specs_dir = REPO_ROOT / mod.RAW_CONTROL_PLANE_SPECS_DIR

    nav_specs = dict(
        mod._build_nav_specs(
            raw_specs_dir,
            merged_nav_specs=mod._load_publish_manifest(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            excluded_paths_by_spec=mod._load_excluded_paths_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            excluded_schema_properties_by_spec=(
                mod._load_excluded_schema_properties_by_spec(
                    REPO_ROOT / "docs" / "tensormesh-api" /
                    "publish-manifest.json")),
            tag_overrides_by_spec=mod._load_tag_overrides_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            operation_overrides_by_spec=mod._load_operation_overrides_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            write_generated_specs=False))

    stripe_paths = nav_specs["billing/v1/stripe_service.openapi.json"]["paths"]
    assert "/v1/billing/stripe/payment-intents" in stripe_paths
    assert "/v1/billing/stripe/webhook" not in stripe_paths


def test_build_nav_specs_excludes_deprecated_user_api_key_field() -> None:
    mod = load_script_module(SCRIPT_PATH)
    raw_specs_dir = REPO_ROOT / mod.RAW_CONTROL_PLANE_SPECS_DIR

    nav_specs = dict(
        mod._build_nav_specs(
            raw_specs_dir,
            merged_nav_specs=mod._load_publish_manifest(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            excluded_paths_by_spec=mod._load_excluded_paths_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            excluded_schema_properties_by_spec=(
                mod._load_excluded_schema_properties_by_spec(
                    REPO_ROOT / "docs" / "tensormesh-api" /
                    "publish-manifest.json")),
            tag_overrides_by_spec=mod._load_tag_overrides_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            operation_overrides_by_spec=mod._load_operation_overrides_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            write_generated_specs=False))

    user_properties = nav_specs["user/v1/user_service.openapi.json"][
        "components"]["schemas"]["v1User"]["properties"]
    admin_user_properties = nav_specs[
        "user/v1/admin_user_service.openapi.json"]["components"]["schemas"][
            "v1User"]["properties"]

    assert "apiKey" not in user_properties
    assert "apiKey" not in admin_user_properties


def test_build_nav_specs_writes_published_outputs_and_cleans_stale_files(
    tmp_path: Path, ) -> None:
    mod = load_script_module(SCRIPT_PATH)
    raw_specs_dir = tmp_path / "raw"
    published_specs_dir = tmp_path / "published"

    source_spec = {
        "openapi": "3.0.3",
        "info": {
            "title": "Model Service",
            "version": "0.1.0",
        },
        "paths": {
            "/v1/models": {
                "get": {
                    "responses": {
                        "200": {
                            "description": "ok"
                        }
                    }
                }
            }
        },
    }
    extra_spec = {
        "openapi": "3.0.3",
        "info": {
            "title": "User Service",
            "version": "0.1.0",
        },
        "paths": {
            "/auth/profile": {
                "get": {
                    "responses": {
                        "200": {
                            "description": "ok"
                        }
                    }
                }
            }
        },
    }

    model_source_path = (raw_specs_dir / "model" / "v1" /
                         "model_service.openapi.json")
    model_source_path.parent.mkdir(parents=True, exist_ok=True)
    model_source_path.write_text(json.dumps(source_spec), encoding="utf-8")

    user_source_path = (raw_specs_dir / "user" / "v1" /
                        "user_service.openapi.json")
    user_source_path.parent.mkdir(parents=True, exist_ok=True)
    user_source_path.write_text(json.dumps(extra_spec), encoding="utf-8")

    stale_path = (published_specs_dir / "stale" / "v1" /
                  "stale_service.openapi.json")
    stale_path.parent.mkdir(parents=True, exist_ok=True)
    stale_path.write_text("{}", encoding="utf-8")

    nav_specs = dict(
        mod._build_nav_specs(raw_specs_dir,
                             merged_nav_specs={
                                 "model/v1/model.openapi.json": {
                                     "sources":
                                     ["model/v1/model_service.openapi.json"],
                                     "title":
                                     "Model",
                                 }
                             },
                             excluded_paths_by_spec={},
                             excluded_schema_properties_by_spec={},
                             output_specs_dir=published_specs_dir))

    assert set(nav_specs) == {
        "model/v1/model.openapi.json",
        "user/v1/user_service.openapi.json",
    }
    assert json.loads(
        model_source_path.read_text(encoding="utf-8")) == source_spec
    assert not stale_path.exists()
    assert not (published_specs_dir / "model" / "v1" /
                "model_service.openapi.json").exists()
    assert (published_specs_dir / "model" / "v1" /
            "model.openapi.json").exists()
    assert (published_specs_dir / "user" / "v1" /
            "user_service.openapi.json").exists()


def test_operation_redirects_match_current_mintlify_route_shape() -> None:
    mod = load_script_module(SCRIPT_PATH)
    openapi = {
        "paths": {
            "/v1/chat/completions": {
                "post": {
                    "tags": ["inference.openapi_Inference"],
                    "summary": "Create Chat Completion",
                }
            },
            "/v1/support/tickets/{ticketId}/messages": {
                "post": {
                    "tags": ["SupportService"],
                    "summary": "Append Ticket Message",
                }
            },
        }
    }

    redirects = mod._operation_redirects(directory="api-reference/on-demand",
                                         openapi=openapi)

    assert {
        "source":
        "/api-reference/on-demand/post/v1/chat/completions",
        "destination":
        "/api-reference/on-demand/inferenceopenapi_inference/create-chat-completion",
    } in redirects

    service_redirects = mod._operation_redirects(
        directory="tensormesh-api/support/v1/support_service",
        openapi=openapi,
    )
    assert {
        "source":
        "/tensormesh-api/support/v1/support_service/post/v1/support/tickets/{ticketId}/messages",
        "destination":
        "/tensormesh-api/support/v1/support_service/supportservice/append-ticket-message",
    } in service_redirects


def test_operation_redirects_hyphenate_space_separated_tags() -> None:
    mod = load_script_module(SCRIPT_PATH)
    openapi = {
        "paths": {
            "/v1/admin/models": {
                "get": {
                    "tags": ["Admin Models"],
                    "summary": "List Models",
                }
            }
        }
    }

    redirects = mod._operation_redirects(
        directory="tensormesh-api/model/v1/admin_model_service",
        openapi=openapi,
    )

    assert {
        "source":
        "/tensormesh-api/model/v1/admin_model_service/get/v1/admin/models",
        "destination":
        "/tensormesh-api/model/v1/admin_model_service/admin-models/list-models",
    } in redirects


def test_build_docs_json_includes_openapi_method_path_redirects() -> None:
    mod = load_script_module(SCRIPT_PATH)

    docs = mod.build_docs_json(REPO_ROOT, write_output=False)
    redirects = docs["redirects"]

    assert {
        "source": "/api-reference/on-demand/post/v1/chat/completions",
        "destination": "/api-reference/on-demand",
    } in redirects
    assert {
        "source": "/api-reference/serverless/post/v1/chat/completions",
        "destination": "/api-reference/serverless",
    } in redirects
    assert {
        "source":
        "/tensormesh-api/billing/v1/pricing_service/post/v1/admin/billing/gpu-pricing",
        "destination":
        "/tensormesh-api/billing/v1/pricing_service/pricing/create-gpu-pricing",
    } in redirects


def test_build_docs_json_preserves_legacy_control_plane_operation_slugs(
) -> None:
    mod = load_script_module(SCRIPT_PATH)

    docs = mod.build_docs_json(REPO_ROOT, write_output=False)
    redirects = docs["redirects"]

    assert {
        "source":
        "/tensormesh-api/support/v1/support_service/supportservice/list-tickets",
        "destination":
        "/tensormesh-api/support/v1/support_service/support/list-tickets",
    } in redirects


def test_build_docs_json_prepends_authored_control_plane_group_pages() -> None:
    mod = load_script_module(SCRIPT_PATH)

    docs = mod.build_docs_json(REPO_ROOT, write_output=False)
    api_tab = next(tab for tab in docs["navigation"]["tabs"]
                   if tab["tab"] == "Control Plane API")
    overview_group = api_tab["groups"][0]
    user_group = next(group for group in api_tab["groups"]
                      if group["group"] == "Users")
    model_group = next(group for group in api_tab["groups"]
                       if group["group"] == "Models")

    assert overview_group == {
        "group":
        "Overview",
        "pages": [
            "tensormesh-api/index",
            "tensormesh-api/pagination-and-retries",
        ],
    }
    assert user_group["pages"][0] == "tensormesh-api/user/v1/user_service"
    assert model_group["pages"][0] == "tensormesh-api/model/v1/model"


def test_build_docs_json_prioritizes_core_control_plane_groups_in_nav(
) -> None:
    mod = load_script_module(SCRIPT_PATH)

    docs = mod.build_docs_json(REPO_ROOT, write_output=False)
    api_tab = next(tab for tab in docs["navigation"]["tabs"]
                   if tab["tab"] == "Control Plane API")
    labels = [group["group"] for group in api_tab["groups"]]

    assert labels[:5] == [
        "Overview",
        "Users",
        "Admin Users",
        "Models",
        "Admin Models",
    ]


def test_require_authored_page_path_for_directory_raises_when_missing(
) -> None:
    mod = load_script_module(SCRIPT_PATH)

    with pytest.raises(RuntimeError,
                       match="Missing required authored docs page"):
        mod._require_authored_page_path_for_directory(
            REPO_ROOT, "tensormesh-api/not-a-real-page")


def test_build_docs_json_requires_authored_control_plane_group_pages(
    monkeypatch: pytest.MonkeyPatch, ) -> None:
    mod = load_script_module(SCRIPT_PATH)

    def fake_build_nav_specs(*args, **kwargs):
        del args, kwargs
        return [(
            "support/v1/fake_service.openapi.json",
            {
                "openapi": "3.0.3",
                "info": {
                    "title": "Fake Service",
                    "version": "0.1.0",
                },
                "paths": {
                    "/v1/fake": {
                        "get": {
                            "summary": "Get Fake",
                            "responses": {
                                "200": {
                                    "description": "ok"
                                }
                            },
                        }
                    }
                },
            },
        )]

    monkeypatch.setattr(mod, "_build_nav_specs", fake_build_nav_specs)

    with pytest.raises(RuntimeError,
                       match="Missing required authored docs page"):
        mod.build_docs_json(REPO_ROOT, write_output=False)


def test_published_docs_source_is_derived_from_output_subtree() -> None:
    mod = load_script_module(SCRIPT_PATH)

    assert mod.PUBLISHED_CONTROL_PLANE_DOCS_SOURCE_DIR == Path(
        "openapi/.generated/tensormesh-api/published-specs")
    assert mod._published_docs_source("user/v1/user_service.openapi.json") == (
        "/openapi/.generated/tensormesh-api/published-specs/user/v1/user_service.openapi.json"
    )


def test_detect_duplicate_operations_raises_with_conflicting_specs() -> None:
    mod = load_script_module(SCRIPT_PATH)

    with pytest.raises(RuntimeError,
                       match="Duplicate operation ownership detected"):
        mod._detect_duplicate_operations([
            ("billing/v1/billing_model_service.openapi.json",
             ["POST /v1/models"]),
            ("model/v1/model_service.openapi.json", ["POST /v1/models"]),
        ])


def test_checked_in_docs_json_matches_generated_base_plus_manifest() -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_docs_json(REPO_ROOT, write_output=False)
    checked_in = json.loads(
        (REPO_ROOT / "docs" / "docs.json").read_text(encoding="utf-8"))

    assert generated == checked_in


def test_generated_control_plane_openapi_sources_use_generated_openapi_sources(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_docs_json(REPO_ROOT, write_output=False)
    tabs = generated["navigation"]["tabs"]
    api_tab = next(tab for tab in tabs
                   if tab["tab"] == mod.GENERATED_CONTROL_PLANE_TAB)

    for group in api_tab["groups"]:
        if "openapi" not in group:
            continue
        source = group["openapi"]["source"]
        assert source.startswith(
            "/openapi/.generated/tensormesh-api/published-specs/")
        assert not source.startswith("/docs/tensormesh-api/specs/")


def test_generated_control_plane_openapi_sources_resolve_to_existing_docs_files(
) -> None:
    mod = load_script_module(SCRIPT_PATH)
    generated = mod.build_docs_json(REPO_ROOT, write_output=False)
    tabs = generated["navigation"]["tabs"]
    api_tab = next(tab for tab in tabs
                   if tab["tab"] == mod.GENERATED_CONTROL_PLANE_TAB)

    for group in api_tab["groups"]:
        if "openapi" not in group:
            continue
        source = group["openapi"]["source"]
        resolved = REPO_ROOT / "docs" / source.lstrip("/")
        assert resolved.exists(), source


def test_build_docs_json_can_write_published_specs_to_custom_dir(
    tmp_path: Path, ) -> None:
    mod = load_script_module(SCRIPT_PATH)
    custom_dir = tmp_path / "published"

    mod.build_docs_json(
        REPO_ROOT,
        write_output=False,
        write_published_specs=True,
        write_docs_json=False,
        published_specs_dir=custom_dir,
    )

    assert (custom_dir / "model" / "v1" / "model.openapi.json").exists()
    assert (custom_dir / "user" / "v1" / "user_service.openapi.json").exists()


def test_build_nav_specs_applies_public_tag_and_summary_overrides() -> None:
    mod = load_script_module(SCRIPT_PATH)
    nav_specs = dict(
        mod._build_nav_specs(
            REPO_ROOT / mod.RAW_CONTROL_PLANE_SPECS_DIR,
            merged_nav_specs=mod._load_publish_manifest(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            excluded_paths_by_spec=mod._load_excluded_paths_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            excluded_schema_properties_by_spec=(
                mod._load_excluded_schema_properties_by_spec(
                    REPO_ROOT / "docs" / "tensormesh-api" /
                    "publish-manifest.json")),
            tag_overrides_by_spec=mod._load_tag_overrides_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            operation_overrides_by_spec=mod._load_operation_overrides_by_spec(
                REPO_ROOT / "docs" / "tensormesh-api" /
                "publish-manifest.json"),
            write_generated_specs=False))

    user_by_email = nav_specs["user/v1/user_service.openapi.json"]["paths"][
        "/v1/users/by-email/{userEmail}"]["get"]
    create_model = nav_specs["model/v1/model.openapi.json"]["paths"][
        "/v1/models"]["post"]

    assert user_by_email["summary"] == "Get User By Email"
    assert user_by_email["tags"] == ["Users"]
    assert create_model["summary"] == "Create Model"
    assert create_model["tags"] == ["Models"]


def test_group_label_preserves_shared_acronym_policy() -> None:
    mod = load_script_module(SCRIPT_PATH)

    assert mod._group_label("user/v1/api_keys_service.openapi.json") == (
        "User - API Keys")
