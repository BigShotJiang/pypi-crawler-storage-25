from __future__ import annotations

from pathlib import Path

from tests.script_test_utils import load_script_module

SCRIPT_PATH = (Path(__file__).resolve().parents[1] / "scripts" /
               "generate-control-plane-resources.py")


def test_flat_list_parser_aligns_first_arg_when_it_fits() -> None:
    mod = load_script_module(SCRIPT_PATH)

    lines = mod._emit_flat_list_parser(  # type: ignore[attr-defined]
        "user_api_keys",
        {
            "response_item_type": "ApiKey",
            "response_list_field": "apiKeys",
        },
    )

    assert lines[1] == "    items = require_response_list_field(body,"
    assert lines[2] == '                                        "apiKeys",'
    assert lines[
        3] == '                                        context="user api keys list response")'


def test_get_parser_wraps_long_response_helper_calls() -> None:
    mod = load_script_module(SCRIPT_PATH)

    lines = mod._emit_get_parser(  # type: ignore[attr-defined]
        "activities",
        {
            "response_type": "Activity | None",
            "response_field": "activity",
            "response_item_type": "Activity",
        },
    )

    assert lines[1] == "    activity = require_response_mapping_field("
    assert lines[
        2] == '        body, "activity", context="activities get response")'


def test_get_parser_aligns_first_arg_when_it_fits() -> None:
    mod = load_script_module(SCRIPT_PATH)

    lines = mod._emit_get_parser(  # type: ignore[attr-defined]
        "models",
        {
            "response_type": "Model | None",
            "response_field": "model",
            "response_item_type": "Model",
        },
    )

    assert lines[1] == "    model = require_response_mapping_field(body,"
    assert lines[2] == '                                           "model",'
    assert lines[
        3] == '                                           context="models get response")'


def test_delete_parser_wraps_long_response_helper_calls() -> None:
    mod = load_script_module(SCRIPT_PATH)

    lines = mod._emit_delete_parser(
        "user_api_keys")  # type: ignore[attr-defined]

    assert lines[2] == "    empty = require_response_mapping_field("
    assert lines[
        3] == '        body, "empty", context="user api keys delete response")'


def test_create_parser_wraps_long_response_helper_calls() -> None:
    mod = load_script_module(SCRIPT_PATH)

    lines = mod._emit_create_response_parser(  # type: ignore[attr-defined]
        "user_api_keys",
        {
            "response_field": "apiKey",
            "response_item_type": "ApiKey",
        },
    )

    assert lines[2] == "    api_key = require_response_mapping_field("
    assert lines[
        3] == '        body, "apiKey", context="user api keys create response")'
