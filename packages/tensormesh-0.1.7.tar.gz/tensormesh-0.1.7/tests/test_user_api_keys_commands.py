from __future__ import annotations

from tests.cli_test_utils import controlplane_env
from tests.cli_test_utils import invoke_tm
from tests.http_test_utils import assert_last_request
from tests.http_test_utils import json_response
from tests.http_test_utils import serve_controlplane_routes


def _api_key_routes():
    return {
        ("GET", "/v1/users/api-keys"): json_response({"apiKeys": []}),
        ("POST", "/v1/users/api-keys"): json_response({"apiKey": {
            "id": "k1"
        }}),
        ("DELETE", "/v1/users/api-keys"): json_response({"empty": {}}),
    }


def test_user_api_keys_list_builds_query() -> None:
    with serve_controlplane_routes(_api_key_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "users",
                "api-keys",
                "list",
                "--user-id",
                "u1",
                "--include-deleted",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="GET",
        path="/v1/users/api-keys",
        query={
            "userId": ["u1"],
            "includeDeleted": ["true"],
        },
    )


def test_user_api_keys_create_builds_payload_from_flags() -> None:
    with serve_controlplane_routes(_api_key_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "users",
                "api-keys",
                "create",
                "--user-id",
                "u1",
                "--name",
                "CI key",
                "--scope",
                "inference:read",
                "--scope",
                "models:write",
                "--expires-at",
                "2026-12-31T00:00:00Z",
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="POST",
        path="/v1/users/api-keys",
        body={
            "userId": "u1",
            "name": "CI key",
            "scopes": ["inference:read", "models:write"],
            "expiresAt": "2026-12-31T00:00:00Z",
        },
    )


def test_user_api_keys_delete_builds_query_from_flags() -> None:
    with serve_controlplane_routes(_api_key_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "users",
                "api-keys",
                "delete",
                "--api-key",
                "sk_live_1",
                "--user-id",
                "u1",
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="DELETE",
        path="/v1/users/api-keys",
        query={
            "apiKey": ["sk_live_1"],
            "userId": ["u1"],
        },
    )


def test_user_api_keys_delete_json_overrides_flags() -> None:
    with serve_controlplane_routes(_api_key_routes()) as recorder:
        result = invoke_tm(
            [
                "--output",
                "json",
                "users",
                "api-keys",
                "delete",
                "--api-key",
                "flag-key",
                "--user-id",
                "flag-user",
                "--json",
                '{"apiKey":"json-key","userId":"json-user"}',
                "--yes",
            ],
            env=controlplane_env(),
        )

    assert result.exit_code == 0, result.output
    assert_last_request(
        recorder,
        method="DELETE",
        path="/v1/users/api-keys",
        query={
            "apiKey": ["json-key"],
            "userId": ["json-user"],
        },
    )
