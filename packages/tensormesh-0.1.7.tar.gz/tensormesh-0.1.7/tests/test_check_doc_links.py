from __future__ import annotations

from pathlib import Path

from tests.script_test_utils import load_script_module

SCRIPT_PATH = (Path(__file__).resolve().parents[1] / "scripts" /
               "check-doc-links.py")


def test_candidate_targets_accepts_published_docs_routes() -> None:
    mod = load_script_module(SCRIPT_PATH)
    source = Path("/repo/docs/cli/index.mdx")

    candidates = mod.candidate_targets(source, "/cli/reference/infer/chat")

    assert mod.ROOT / "docs" / "cli" / "reference" / "infer" / "chat.mdx" in candidates
    assert mod.ROOT / "docs" / "cli" / "reference" / "infer" / "chat" / "index.mdx" in candidates


def test_is_known_virtual_route_accepts_generated_openapi_routes() -> None:
    mod = load_script_module(SCRIPT_PATH)

    assert mod.is_known_virtual_route(
        "/api-reference/on-demand/post/v1/chat/completions")
    assert mod.is_known_virtual_route(
        "/api-reference/serverless/post/v1/chat/completions")
    assert mod.is_known_virtual_route(
        "/tensormesh-api/billing/v1/pricing_service")
    assert mod.is_known_virtual_route(
        "/tensormesh-api/user/v1/user_service/users/get-user-by-email")


def test_is_known_virtual_route_rejects_nonexistent_method_path_slugs(
) -> None:
    mod = load_script_module(SCRIPT_PATH)

    assert not mod.is_known_virtual_route(
        "/tensormesh-api/billing/v1/pricing_service/post/v1/admin/billing/gpu-pricing/extra"
    )


def test_iter_docs_includes_src_tensormesh_cli_readme() -> None:
    mod = load_script_module(SCRIPT_PATH)

    docs = mod.iter_docs()

    assert mod.ROOT / "src" / "tensormesh_cli" / "README.md" in docs


def test_iter_docs_includes_api_reference_yaml_source_inputs() -> None:
    mod = load_script_module(SCRIPT_PATH)

    docs = mod.iter_docs()

    assert (mod.ROOT / "docs" / "api-reference" / "src" /
            "on-demand.overlay.yaml") in docs
    assert (mod.ROOT / "docs" / "api-reference" / "src" /
            "serverless.overlay.yaml") in docs


def test_generated_control_plane_readme_uses_repo_root_relative_links(
) -> None:
    readme = (Path(__file__).resolve().parents[1] / "openapi" / ".generated" /
              "tensormesh-api" / "README.md").read_text(encoding="utf-8")

    assert "[../../../README.md](../../../README.md)" in readme
    assert ("[../../../dev/control-plane-publish-policy.md]"
            "(../../../dev/control-plane-publish-policy.md)" in readme)
    assert ("[../../../dev/docs-system.md]"
            "(../../../dev/docs-system.md)" in readme)


def test_gitignore_tracks_generated_published_control_plane_specs() -> None:
    gitignore = (Path(__file__).resolve().parents[1] /
                 ".gitignore").read_text(encoding="utf-8")

    assert "docs/openapi/.generated/tensormesh-api/published-specs/" not in gitignore
