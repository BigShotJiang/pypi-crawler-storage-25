import django_filters
from django_celery_results.models import TaskResult
from drf_spectacular.utils import extend_schema
from rest_framework import viewsets, filters

from utg_base.celery.filters import TaskResultFilterSet
from utg_base.celery.serializers import TaskResultSerializer
from utg_base.permissions.decorators import has_class_perm


@has_class_perm({
    'create': 'task_result.create',
    'list': 'task_result.read',
    'retrieve': 'task_result.read',
    'partial_update': 'task_result.update',
    'update': 'task_result.update',
    'destroy': 'task_result.delete',
})
@extend_schema(tags=['admin/task-results'])
class TaskResultViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = TaskResult.objects.all()
    serializer_class = TaskResultSerializer
    filterset_class = TaskResultFilterSet
    filter_backends = [filters.SearchFilter, django_filters.rest_framework.DjangoFilterBackend]
    search_fields = ['task_name']
