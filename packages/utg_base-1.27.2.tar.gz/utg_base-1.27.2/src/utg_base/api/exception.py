from rest_framework import serializers
from rest_framework.exceptions import ErrorDetail, APIException


def raise_external_error(data):
    if data.get('type') == 'validation_error':
        error_dict = {
            'error_type': [ErrorDetail('External service', code='ext_error')],
        }
        for error in data.get('errors', []):
            error_dict.setdefault(error['attr'], []).append(ErrorDetail(error['detail'], code=error['code']))
        raise serializers.ValidationError(error_dict)

    raise APIException({'error_type': [ErrorDetail(data, code='ext_error')]})
