import operator
from functools import reduce

from django.db import models
from rest_framework.fields import CharField
from rest_framework.filters import SearchFilter, search_smart_split
from utg_base.utils import transliterate


class LatinCyrillSearch(SearchFilter):
    def get_search_terms(self, request):
        value = request.query_params.get(self.search_param, '')
        field = CharField(trim_whitespace=False, allow_blank=True)
        cleaned_value = field.run_validation(value)
        if transliterate.is_cyrillic(cleaned_value):
            cleaned_value2 = transliterate.to_latin(cleaned_value)
        else:
            cleaned_value2 = transliterate.to_cyrillic(cleaned_value)

        terms = search_smart_split(cleaned_value)
        terms2 = search_smart_split(cleaned_value2)
        return terms, terms2

    def filter_queryset(self, request, queryset, view):
        search_fields = self.get_search_fields(view, request)
        search_terms = self.get_search_terms(request)

        if not search_fields or not search_terms[0]:
            return queryset

        orm_lookups = [
            self.construct_search(str(search_field), queryset)
            for search_field in search_fields
        ]

        base = queryset
        # generator which for each term builds the corresponding search
        # for orginal search
        conditions1 = (
            reduce(
                operator.or_,
                (models.Q(**{orm_lookup: term}) for orm_lookup in orm_lookups)
            ) for term in search_terms[0]
        )
        # for transliterated search
        conditions2 = (
            reduce(
                operator.or_,
                (models.Q(**{orm_lookup: term}) for orm_lookup in orm_lookups)
            ) for term in search_terms[1]
        )

        q1 = reduce(operator.and_, conditions1)
        q2 = reduce(operator.and_, conditions2)
        queryset = queryset.filter(reduce(operator.or_, (q1, q2)))

        # Remove duplicates from results, if necessary
        if self.must_call_distinct(queryset, search_fields):
            # inspired by django.contrib.admin
            # this is more accurate than .distinct form M2M relationship
            # also is cross-database
            queryset = queryset.filter(pk=models.OuterRef('pk'))
            queryset = base.filter(models.Exists(queryset))
        return queryset
