# EvaSuite – Evaluation Suite for Climate Data

![EvaSuite Logo](https://gitlab.dkrz.de/clm-community/public/evasuite/-/raw/main/DOCS/LOGO/LOGO_small.png)

- [**Documentation**](https://gitlab.dkrz.de/clm-community/public/evasuite/-/tree/main/DOCS?ref_type=heads)
- [**EvaSuite Installation**](https://gitlab.dkrz.de/clm-community/public/evasuite/-/blob/main/DOCS/EXTRA_CHAPTERS/Installation.md?ref_type=heads)
- [**EvaSuite Examples**](https://gitlab.dkrz.de/clm-community/public/evasuite/-/tree/main/EXAMPLE/RUNNERS?ref_type=heads)
- [**EvaSuite Test Data**](https://gitlab.dkrz.de/clm-community/public/evasuite/-/tree/main/EXAMPLE/DATA?ref_type=heads)
- [**EvaSuite Extensions**](https://gitlab.dkrz.de/clm-community/public/evasuite-addons)

## Introduction

**Evaluation Suite (EvaSuite)** is a modular software framework for the standardised evaluation of regional climate model (RCM) simulations against observational and reference datasets, including model sensitivity analysis. It is designed for high-performance computing platforms and addresses the need for transparent, reproducible, and flexible evaluation workflows for RCMs. EvaSuite combines data harmonisation, spatial and temporal remapping, statistical evaluation, and visualisation within a unified **fully configurable, end-to-end workflow**. EvaSuite is an open-source evaluation framework maintained by the [CLM-Community](https://www.clm-community.eu/). It provides a  covering preprocessing, regridding, statistical evaluation, and visualization.

All evaluation workflows in EvaSuite are controlled via **YAML configuration files**, which define:

- the system settings (external dependencies)
- the input datasets (model simulations and reference observations)
- preprocessing steps (e.g. regridding, masking, temporal aggregation)
- evaluation metrics (e.g. bias, RMSE, correlation, quantiles)
- visualization settings (maps, time series, Taylor diagrams)

 For a comprehensive introduction to EvaSuite please visit our [documentation](https://gitlab.dkrz.de/clm-community/public/evasuite/-/tree/main/DOCS?ref_type=heads) page.

## Key Features

- **End-to-end evaluation workflow**
  - Data harmonisation, regridding, metric computation, visualisation
- **YAML-driven configuration**
  - Fully reproducible and automation-friendly workflows
- **HPC-ready design**
  - Optimised for SLURM-based execution and batch processing
- **Flexible data support**
  - CF-compliant NetCDF datasets (models, reanalysis, observations)
- **Advanced diagnostics**
  - Bias, RMSE, correlation, quantile-based metrics, significance testing
- **Integrated visualisation**
  - Maps, time series, QQ plots, Taylor diagrams
- **Modular extensions**
  - GeoPackage, GriddedStations, ScoPi, PlotSmart, UrbanPlot

## General Information
The [history and recent updates](https://gitlab.dkrz.de/clm-community/public/evasuite/-/blob/main/DOCS/EXTRA_CHAPTERS/New_updates.md?ref_type=heads) of EvaSuite provide an overview of the framework evolution and newly introduced features. Detailed instructions for installation and system setup are described in the [Installation Guide](https://gitlab.dkrz.de/clm-community/public/evasuite/-/blob/main/DOCS/EXTRA_CHAPTERS/Installation.md?ref_type=heads), including environment preparation and known issues. EvaSuite can be executed in different modes (main, interactive, debug), as explained in the [running documentation](https://gitlab.dkrz.de/clm-community/public/evasuite/-/blob/main/DOCS/EXTRA_CHAPTERS/Running.md?ref_type=heads), allowing flexible usage for both batch HPC workflows and exploratory analysis. User-specific customization of plots, maps, and diagnostics is controlled via configuration files, documented in the user settings sections for [plots](https://gitlab.dkrz.de/clm-community/public/evasuite/-/blob/main/DOCS/EXTRA_CHAPTERS/Plots_user_settings.md?ref_type=heads), [maps](https://gitlab.dkrz.de/clm-community/public/evasuite/-/blob/main/DOCS/EXTRA_CHAPTERS/Maps_user_settings.md?ref_type=heads) and [Taylor diagrams](https://gitlab.dkrz.de/clm-community/public/evasuite/-/blob/main/DOCS/EXTRA_CHAPTERS/Taylor_user_settings.md?ref_type=heads). A comprehensive collection of reproducible workflows is available in the [examples](https://gitlab.dkrz.de/clm-community/public/evasuite/-/tree/main/EXAMPLE/RUNNERS?ref_type=heads), demonstrating typical evaluation setups and wrapper-based pipelines. Additional technical details, module descriptions, and theoretical background are provided in the [full documentation](https://gitlab.dkrz.de/clm-community/public/evasuite/-/blob/main/DOCS/Documentation_EvaSuite_v1_0.pdf?ref_type=heads). For advanced applications and extensions (e.g. SPICE workflows), see the dedicated [SPICE documentation](https://gitlab.dkrz.de/clm-community/public/evasuite/-/blob/main/spice/README.md?ref_type=heads). Modular extensions presented in separate projects [GeoPackage](https://gitlab.dkrz.de/clm-community/public/evasuite-addons/evasuite_geopackage), [GriddedStations](https://gitlab.dkrz.de/clm-community/public/evasuite-addons/evasuite_gridded_stations), [ScoPi](https://gitlab.dkrz.de/clm-community/public/evasuite-addons/evasuite_scopi) and [UrbanPlot](https://pypi.org/project/urbanplot/)

## Getting help

The easiest way to get help, if you cannot find the answer in the documentation in our [docs](https://gitlab.dkrz.de/clm-community/public/evasuite/-/tree/main/DOCS?ref_type=heads), is to open an [issue on GitLab](https://gitlab.dkrz.de/clm-community/public/evasuite/-/issues?sort=created_date&state=opened&first_page_size=100).

## Citation

If you use **EvaSuite** in your research, please cite:

> Petrik, R., Geyer, B., Churiulin, E., Rockel, B., & Braun, C. (2026).
> *EvaSuite (Evaluation Suite for climate data) (v1.0.1)*.
> Zenodo. https://doi.org/10.5281/zenodo.19223685

### BibTeX

```bibtex
@software{petrik2026evasuite,
  author       = {Petrik, Ronny and Geyer, Beate and Churiulin, Evgenii and Rockel, Burkhardt and Braun, Christoph},
  title        = {EvaSuite (Evaluation Suite for climate data)},
  year         = {2026},
  version      = {v1.0.1},
  publisher    = {Zenodo},
  doi          = {10.5281/zenodo.19223685},
  url          = {https://doi.org/10.5281/zenodo.19223685}
}
```



## Contributing
If you would like to contribute a new diagnostic or feature, please have a join to the [CLM-Community](https://www.clm-community.eu/) and read CLM-Community contribution guidelines.