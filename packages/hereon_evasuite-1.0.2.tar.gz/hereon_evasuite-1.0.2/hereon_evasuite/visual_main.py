# Evaluation Suite (EvaSuite)
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2026, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# ---------------------------------------------------------------
#    Program description:
#    This script provides a comprehensive visualization interface for evaluating
#    and comparing climate model outputs stored in NetCDF format. It supports
#    generating:
#
#    - 2D spatial maps (e.g., full-domain temperature fields),
#    - 1D time series plots across subregions (e.g., for domain-specific trends),
#    - Taylor diagrams for performance comparison across models and seasons.
#
#    The `Visualization` class manages dynamic input loading, automated metadata
#    validation, and adapts visualization strategies based on available data and
#     user-specified flags.
#
#    History:
#    Version    Date       Name
#    ---------- ---------- ----
#    1.1        04.2025   Evgenii Churiulin, IMKTRO
#                         Initial realise
# ---------------------------------------------------------------
# -- Import standard modules:
import os
import numpy as np
from typing import List, Dict, Optional, Any, Union, cast
from itertools import chain
# -- Import user modules:
from hereon_evasuite.visual_methods import Plot1D, Plot2D, Taylor_plot
from hereon_evasuite.visual_data_processing import Read_nc4_2dmap
from hereon_evasuite.visual_support import Control_data_types, compare_values, PathClassifier, json_report, log_paths_compact
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
from hereon_evasuite.visual_advance_plots import create_adv_plots
from hereon_evasuite.visual_config import Builder_maps_config

logger = get_logger()


class Cartopy_Visualization:
    """
    A class for managing and executing multiple modes of climate data visualization.

    This class acts as a unified interface for generating:
    - 2D maps for full-domain fields (e.g., monthly temperature distributions),
    - 1D time series plots across multiple subregions,
    - Taylor diagrams for statistical comparison of models.

    Attributes:
    -----------
    l1dplots : bool
        Flag to enable 1D time series plotting (regional trends).
    l2d_maps : bool
        Flag to enable 2D spatial map generation (full domain).
    ltaylor_plot : bool
        Flag to enable Taylor diagram generation (model performance).
    nc_reader : Read_nc4_2dmap
        Responsible for loading and renaming NetCDF content.
    ctr : Control_data_types
        Utility for recursive validation of data types and structure.

    Methods:
    --------
    visual_main(paths: List[str]) -> None
        The main driver that orchestrates visualization by processing files,
        validating contents, and triggering appropriate plotting routines
        based on the internal flags.
    """
    @log_function_name
    def __init__(
        self,
        visualization_configs: Dict[str, Union[None, str]],
        cfggen: Dict[str, Any],
    ) -> None:
        """
        Initialize the visualization control interface for NetCDF evaluation.

        Parameters
        ----------
        visualization_configs : Dict
            Dictionary of visualization settings, such as figure size, color maps, and fonts.
            Values can be strings or None if defaults should be used.

        cfggen: Dict
            Dictionary with general user settings for EvaSuite

        Returns
        -------
            None
        """
        # -- Logical variables for activation different methods for visualization:
        self.path2configs = visualization_configs

        # -- Get pole_longitude and pole_latitude values:
        pole_longitude, pole_latitude = -162.0, 39.25
        map_path = (
            os.path.abspath(os.path.expanduser(self.path2configs["MAPCONFIG"]))
            if self.path2configs["MAPCONFIG"] is not None else None
        )
        if map_path:
            tmp_cfg_maps = Builder_maps_config()
            proj_settings = tmp_cfg_maps._read_yaml_config(map_path)
            pole_longitude = proj_settings.get('map_pole_longitude', pole_longitude)
            pole_latitude = proj_settings.get('map_pole_latitude', pole_latitude)
        else:
            logger.info("Failed to read MAPCONFIG, using defaults values")

        # -- Initialization of user classes:
        self.nc_reader = Read_nc4_2dmap(pole_longitude, pole_latitude)
        self.ctr = Control_data_types()

        # -- Get some parameters from general config file:
        #    a. Evaluation mode, typically one of 'CompareRAW' or 'EvalRAW':
        self.eval_mode = cast(str, cfggen.get('eval_Mode'))
        #    b. File path to the CMOR table used for interpreting NetCDF metadata:
        self.mapping_csv_path = cast(str, cfggen.get('eval_cmor_table'))
        #    c. Whether to generate 1D plots (e.g., time series). Default is False.
        self.l1dplots = cfggen.get('eval_create_1D_plots', False)
        #    d. Whether to generate 2D spatial plots (e.g., maps). Default is False.
        self.l2d_maps = cfggen.get('eval_create_2D_plots', False)
        #    e. Whether to generate Taylor diagrams. Default is False.
        self.ltaylor_plot = cfggen.get('eval_create_Taylor_plots', False)
        #    f. Type of plot to produce. Supported types: 'line', 'scatter', 'hist'. Default is 'line'.
        self.plot_1d_type = cfggen.get('eval_plot_type', 'line')
        #    g. Projection type for spatial plots. Supported types include:
        #    'copat2_LambertConformal', 'global_PlateCarree', and 'RotatedPole'.
        #    Default is 'copat2_LambertConformal'.
        self.domain_type = cfggen.get('eval_proj_type', 'copat2_LambertConformal')
        #    Names of reference and model datasets
        self.refer = cast(list[str], cfggen.get('evaldata_acronyms'))
        self.models = cast(list[str], cfggen.get('data2proof_acronyms'))
        #    Activate land/sea mask:
        self.ls_mask = cfggen.get('eval_lsmask', True)
        #    Special debugging mode flaq:
        self.ldebug = False

        logger.info(
            "\n--- Evaluation Configuration Loaded ---\n"
            f"Mode                : {self.eval_mode}\n"
            f"CMOR Mapping Table  : {self.mapping_csv_path}\n"
            f"Generate 1D Plots   : {self.l1dplots}\n"
            f"Generate 2D Maps    : {self.l2d_maps}\n"
            f"Taylor Diagrams     : {self.ltaylor_plot}\n"
            f"1D Plot Type        : {self.plot_1d_type}\n"
            f"Spatial Projection  : {self.domain_type}\n"
            f"Reference datasets  : {self.refer}\n"
            f"Model datasets      : {self.models}\n"
            f"Use land/sea mask   : {self.ls_mask}\n"
            f"Use ldebug flag     : {self.ldebug}\n"
            f"Center of RotatePole (lon, lat): {pole_longitude, pole_latitude}"
            "----------------------------------------\n"
        )

        # -- Simple control:
        if self.l1dplots is None or self.l2d_maps is None or self.ltaylor_plot is None:
            raise ValueError(
                'Please check values of "eval_create_1D_plots", "eval_create_2D_plots"'
                ' or "eval_create_Taylor_plots" in cfggen YAML file: expected a list'
            )
        if not isinstance(self.mapping_csv_path, str) or not self.mapping_csv_path.strip():
            raise TypeError(
                f"'path2cmor_table' must be a non-empty string. Got: {self.mapping_csv_path}"
            )

    @log_function_name
    def __infer_time_prefix(
        self,
        time_array: Optional[Union[int, List[Any]]],
    ) -> Optional[str]:
        """
        Infers a prefix like 'monthly', 'seasonal', etc. based on the number of time steps.
        Accepts either an int or a list/array.

        Returns:
        ----------------------------
            str: A time resolution prefix.
        """
        if not time_array:
            logger.warning("Time array is empty or None")
            return 'unknown'

        # -- Control data types:
        if isinstance(time_array, int):
            time_len = time_array
        elif isinstance(time_array, (list, tuple, np.ndarray)):
            time_len = len(time_array)
        else:
            logger.warning(f"Unsupported type for time_array: {type(time_array)}")
            return 'unknown'
        # -- Time frequency:
        time_map = {24: 'hourly', 12: 'monthly', 4: 'seasonal'}
        prefix = time_map.get(time_len)
        if prefix is None:
            logger.warning(f"Unknown time step count: {time_len}")
            prefix = ""
        return prefix

    @log_function_name
    def visual_main(self, input_paths: List[str], vis_standalone: bool = False) -> None:
        """
        Main method for visualizing NetCDF datasets.

        Based on logical flags (self.l2d_maps, self.l1dplots, self.ltaylor_plot), this method:
        ----------------------------
        - Reads and renames NetCDF files from given directories.
        - Separates full-domain and sub-domain files.
        - Creates visualizations:
            - 2D map visualizations for full-domain files.
            - 1D line plots for sub-domain comparisons.
            - Taylor diagrams for performance metrics.

        Args:
        ----------------------------
            paths (List[str]): List of directory paths containing NetCDF files.
        """
        if not any([self.l2d_maps, self.l1dplots, self.ltaylor_plot]):
            logger.info(
                'Visualization mode was turned off. Please set at least one of'
                ' l2d_maps, l1dplots, or ltaylor_plot to True to activate it.')
            return

        # -- Local variables:
        simple_1d_types = ['line', 'scatter', 'bar']
        adv_1d_types = [
            'qqplot_percentiles', 'percentiles_diff', 'qqplot_scatter', 'qqplot', 'hist'
        ]

        # -- Initialization of class for work with paths:
        path_filter = PathClassifier()
        # -- Control input paths:
        if not input_paths:
            raise ValueError("'input_paths' is missing or empty.")

        # -- Build file list:
        datafiles_experimental: Union[List[str], List[List[str]]] = (
            [path_filter._get_list(p) for p in input_paths] if vis_standalone else input_paths
        )

        # -- Flatten the list if it contains nested lists:
        all_paths: List[str] = list(chain.from_iterable(datafiles_experimental))

        # -- Build output directory:
        output_path = f'{path_filter._create_output_path(all_paths)}/Visualization'
        logger.info(f"Visualization output path set to: {output_path}")

        # -- Taylor plot (independent from input paths):
        if self.ltaylor_plot:
            # -- Taylor application:
            logger.info('Create Taylor diagram')
            act_taylor = Taylor_plot(self.path2configs)
            act_taylor.taylor_clim()
            act_taylor.taylor_clim_season()
        else:
            # -- Filter data in folders (WP03, WP04) -> if not NetCDF move:
            valid_paths = [p for p in all_paths if path_filter._check_files(p)]
            if not valid_paths:
                raise ValueError("No valid NetCDF files found after filtering.")
            # -- Pause before renaming:
            path_filter._time_for_sleep(10)

            # -- Separate the paths into two categories (full-domain and sub-domains):
            full_domain_files, sub_domain_files = path_filter._classify_paths(valid_paths)
            subdomain_groups = path_filter.split_subdomain_paths_by_surface(sub_domain_files)

            # -- Visualization for 2D maps:
            if self.l2d_maps:
                logger.info('2D Visualization')
                logger.info("Starting renaming of 2D datasets...")
                for path in full_domain_files:
                    self.nc_reader.rename_nc(path, self.mapping_csv_path)
                logger.info("Renaming of 2D datasets successfully finished")
                logger.info(f'Input paths: {full_domain_files}')
                # -- Wait 10 seconds:
                path_filter._time_for_sleep(10)
                # -- Create a list of datasets for 2D visualization based on EvaSuite
                #    WP4 input data with a special prefix full_domain:
                datasets = [self.nc_reader.read_nc(path) for path in full_domain_files]

                # -- Declare the variable with the correct type:
                set4visualization: Dict[str, str | float | int]

                # -- If there's only one dataset, skip comparisons:
                if len(datasets) == 1:
                    # -- Cycle over keys in dataset:
                    lst4datasets = datasets[0]
                    for dataset_key in lst4datasets:
                        if not isinstance(dataset_key, str):
                            raise TypeError(
                                f'Prep4vis: dataset_key of {datasets[0]} is not str!')
                        # -- Safely retrieve and validate the dataset key:
                        logger.info(f"Selected key: {dataset_key}")
                        # -- Safely get data from dataset:
                        data4visualization = lst4datasets.get(dataset_key)
                        if data4visualization is None:
                            raise KeyError(
                                f"Key '{dataset_key}' not found in the dataset.")

                        # -- Validate required keys in the selected dataset
                        required_keys = {'time', 'var4vis', 'var_lon', 'var_lat', 'units', 'long_name'}
                        missing_keys = required_keys - set(data4visualization.keys())
                        if missing_keys:
                            raise KeyError(
                                f"The dataset is missing required keys: {missing_keys}")
                        # -- Prepare data for visualization:
                        ts = data4visualization.get('time')
                        long_name = data4visualization.get('long_name')
                        units = data4visualization.get('units')

                        # -- Use different algorithms depending on timesteps:
                        if len(ts) == 1:
                            logger.info('We are using only one timestep')
                            time_step = ts[0]
                            data4visualization['var4vis'] = data4visualization['var4vis'][len(ts) - 1]
                            # -- Create user settings for visualization:
                            set4visualization = {
                                'type4plot': 'single_map',
                                'plt_title': f'{dataset_key}, fullperiod, {time_step}',
                                'plt_label': f'{long_name}, {units}',
                                'plt_domain_type': self.domain_type,
                                'plt_out': f'{output_path}/{dataset_key}'
                            }
                            # -- Visualization:
                            plot_2d_maker = Plot2D(
                                self.eval_mode,
                                self.ls_mask,
                                data4visualization,
                                set4visualization,
                                self.path2configs,
                                collage_type = None,
                                eval_variable = dataset_key,
                            )
                            plot_2d_maker.create_collage_plot_2d_auto()

                        elif len(ts) > 1:
                            logger.info('We are using simple collage')
                            # -- Define time prefix:
                            prefix = self.__infer_time_prefix(len(ts))
                            # -- Create dictionary for visualization:
                            set4visualization = {
                                'type4plot': 'collage',
                                'plt_title': f'{dataset_key}, {prefix}',
                                'plt_label': f'{long_name}, {units}',
                                'plt_domain_type': self.domain_type,
                                'plt_out': f'{output_path}/{dataset_key}'
                            }
                            # -- Create collage plot:
                            plot_2d_maker = Plot2D(
                                self.eval_mode,
                                self.ls_mask,
                                data4visualization,
                                set4visualization,
                                self.path2configs,
                                collage_type = None,
                                eval_variable = dataset_key,
                            )
                            plot_2d_maker.create_collage_plot_2d_auto()
                        else:
                            raise ValueError(
                                'Timesteps for 2d visualization are incorrect!')

                elif len(datasets) > 1:
                    logger.info('We are using time collage')
                    # Step 1: Gather all keys from all datasets
                    all_keys = set().union(*(dataset.keys() for dataset in datasets))

                    # Step 2: Process one key at a time
                    dict4visualization = {}
                    for key in all_keys:
                        dict4visualization[key] = [dataset.get(key) for dataset in datasets if key in dataset]

                    for dataset_key in all_keys:
                        lst4visualization = dict4visualization[dataset_key]

                        ds_data, ds_names = [], []
                        for i in range(len(lst4visualization)):
                            step = 1
                            item = lst4visualization[i]
                            if item is None:
                                raise ValueError(f"Missing dataset for visualization at index {i}")
                            if i < len(lst4visualization) - step:
                                item_next = lst4visualization[i + step]
                                if item_next is not None:
                                    lat = compare_values(item, item_next, 'var_lat')
                                    lon = compare_values(item, item_next, 'var_lon')
                                    time = compare_values(item, item_next, 'time')
                                    units = compare_values(item, item_next, 'units')
                                    long_name = compare_values(item, item_next, 'long_name')
                                else:
                                    raise ValueError(f"Missing dataset for comparison at index {i + step}")
                            ds_data.append(item.get('var4vis'))
                            ds_names.append(item.get('ds_name'))

                        # -- Transpose test to have 12 timesteps with size 3 (datasets):
                        var4vis_transposed = list(map(list, zip(*ds_data)))
                        # -- Determine prefix from time length
                        prefix = self.__infer_time_prefix(len(time))
                        print('prefix', prefix)
                        # -- Merge all data in one dictionary
                        data4visualization = {
                            'var4vis': var4vis_transposed,
                            'var_lon': lon,
                            'var_lat': lat,
                            'time': time,
                            'units': units,
                            'long_name': long_name,
                            'ds_name': ds_names,
                        }
                        # -- Use settings for visualization:
                        set4visualization = {
                            'type4plot': 'time_collage',
                            'plt_title': f'{dataset_key}, {prefix}',
                            'plt_label': f'{long_name}, {units}',
                            'plt_domain_type': self.domain_type,
                            'plt_out': f'{output_path}/{dataset_key}'
                        }
                        # -- Run visualization:
                        plot_2d_maker = Plot2D(
                            self.eval_mode,
                            self.ls_mask,
                            data4visualization,
                            set4visualization,
                            self.path2configs,
                            collage_type = None,
                            eval_variable = dataset_key,
                        )
                        plot_2d_maker.create_collage_plot_2d_auto()

            # -- Visualization for 1D plots:
            if self.l1dplots:
                logger.info('1D Visualization')
                logger.info("Starting renaming of 2D datasets...")

                for group, sub_domain_files in subdomain_groups.items():
                    logger.info(f"Processing subdomain group: {group}")

                    # -- Rename variables (if needed - 1D plots):
                    for path in sub_domain_files:
                        self.nc_reader.rename_nc(path, self.mapping_csv_path)
                    logger.info(f'Renaming 1D datasets finished for group: {group}')

                    # -- User-specified regions (can be empty):
                    user_regions = sorted({path.split('.')[-2] for path in sub_domain_files})
                    logger.info(f"Subregions ({group}): {user_regions} \n")

                    # -- Group region-specific files into a dictionary:
                    region_files_dict: Dict[str, List[str]] = {}
                    for path in sub_domain_files:
                        region = path.split('.')[-2]
                        if region not in region_files_dict:
                            region_files_dict[region] = []
                        region_files_dict[region].append(path)

                    # -- Show in log file the full catalog of input paths:
                    log_paths_compact(
                        logger,
                        region_files_dict,
                        header=f"Full catalog of subregions ({group})",
                        max_items=5,
                        level="debug",
                    )
                    logger.info("")

                    dict_data4visualization: Dict[str, Dict[str, Dict]] = {}
                    dict_set4visualization: Dict[str, Dict[str, Dict[str, str | float | int]]] = {}
                    for region in user_regions:
                        # -- Initialization the region key in special storages
                        if region not in dict_data4visualization:
                            dict_data4visualization[region] = {}
                            dict_set4visualization[region] = {}
                        # -- Get list of actual paths for unique region:
                        act_paths: Optional[List[str]] = region_files_dict.get(region)
                        # -- Print actual subregion path:
                        log_paths_compact(
                            logger,
                            act_paths,
                            header=f"Paths for subregion '{region}' ({group})",
                            max_items=None,
                            level="debug",
                        )

                        if act_paths is None:
                            raise ValueError(f"No paths for region: {region}")

                        # -- Control datatype of user settings for visualization (set by user):
                        self.ctr.control_types4dict(
                            {'act_paths': (act_paths, list, str)},
                            func_name = '1d_plots',
                        )

                        # -- Read data:
                        datasets = [self.nc_reader.read_nc(path) for path in act_paths]

                        # -- If there's only one dataset, skip comparisons:
                        if len(datasets) == 1:
                            summary_log = []
                            dataset = datasets[0]

                            for dataset_key, content in dataset.items():
                                var_data = content.get('var4vis')
                                var_shape = getattr(var_data, 'shape', None)
                                var_lname = content.get('long_name')
                                var_units = content.get('units')
                                var_ds_names = content.get('ds_name')
                                var_time = content.get('time')
                                var_time_len = len(content.get('time', []))

                                # -- Create dictionary with data for visualization:
                                data4visualization = {
                                    'var4vis': [var_data],
                                    'time': var_time,
                                    'units': var_units,
                                    'long_name': var_lname,
                                    'ds_name': [var_ds_names],
                                }

                                # -- Handle inf values:
                                if np.any(np.isinf(var_data)):
                                    var_data = np.where(np.isinf(var_data), np.nan, var_data)
                                    logger.info(f'{region} - found inf in single dataset')

                                min_value, max_value = np.nanmin(var_data), np.nanmax(var_data)

                                # -- Create a summary log list:
                                summary_log.append(
                                    f"{dataset_key} | shape={var_shape} | time_len={var_time_len} \n"
                                    f"| units={var_units} | long_name={var_lname} \n"
                                    f"| min={min_value} | max={max_value} \n"
                                )

                                # -- Determine prefix from time length
                                prefix = self.__infer_time_prefix(len(var_data))
                                set4visualization = {
                                    'type4plot': self.plot_1d_type,
                                    'plt_title': f'{dataset_key}, {prefix}',
                                    'plt_label': f"{var_lname}, {var_units}",
                                    'plt_domain_type': region,
                                    'plotabsmin': min_value,
                                    'plotabsmax': max_value,
                                    'plt_out': f'{output_path}/{dataset_key}_{region}'
                                }
                                dict_data4visualization[region][dataset_key] = data4visualization
                                dict_set4visualization[region][dataset_key] = set4visualization

                            # -- Show statistic:
                            logger.info("\n---------------------")
                            logger.info(f"--- Summary for region '{region}' (1D, single dataset case) ---")
                            for line in summary_log:
                                logger.info(line)
                            logger.info("---------------------\n")

                        elif len(datasets) > 1:
                            # -- Step 1: Gather all keys from all datasets
                            all_keys = set().union(*(dataset.keys() for dataset in datasets))

                            # -- Step 2: Process one key at a time
                            dict4visualization = {}
                            for key in all_keys:
                                dict4visualization[key] = [dataset.get(key) for dataset in datasets if key in dataset]

                            # -- Step 3: Create a new datastructure:
                            for dataset_key in all_keys:
                                lst4visualization = dict4visualization[dataset_key]
                                ds_data, ds_names = [], []

                                if len(lst4visualization) == 1:
                                    raise RuntimeError('Please rerun visualization in standalone mode')

                                for i in range(len(lst4visualization)):
                                    step = 1
                                    item = lst4visualization[i]
                                    if item is None:
                                        raise ValueError(f"Missing dataset for visualization at index {i}")
                                    if i < len(lst4visualization) - step:
                                        item_next = lst4visualization[i + step]
                                        if item_next is not None:
                                            time = compare_values(item, item_next, 'time')
                                            units = compare_values(item, item_next, 'units')
                                            long_name = compare_values(item, item_next, 'long_name')
                                        else:
                                            raise ValueError(
                                                f"Missing dataset for comparison at index {i + step}")
                                    ds_data.append(item.get('var4vis'))
                                    ds_names.append(item.get('ds_name'))

                                # -- Find min and max values for region:
                                combined_ds_data = np.concatenate(ds_data)

                                # -- Check if np.inf or -np.inf exists and replace to NaN:
                                if np.any(np.isinf(combined_ds_data)):
                                    combined_ds_data = np.where(
                                        np.isinf(combined_ds_data),
                                        np.nan,
                                        combined_ds_data
                                    )
                                    logger.info(
                                        f'{region}: In your dataset were np.inf values')

                                # -- Find the minimum and maximum values, ignoring NaN:
                                min_value = np.nanmin(combined_ds_data)
                                max_value = np.nanmax(combined_ds_data)

                                # -- Get a representative array to determine the time resolution:
                                #    (need only for correct prefix)
                                example_data = next((arr for arr in ds_data if arr is not None), None)
                                prefix = self.__infer_time_prefix(len(example_data))

                                # -- Merge all data in one dictionary
                                data4visualization = {
                                    'var4vis': ds_data,
                                    'time': time,
                                    'units': units,
                                    'long_name': long_name,
                                    'ds_name': ds_names,
                                }

                                # -- Use settings for visualization:
                                set4visualization = {
                                    'type4plot': self.plot_1d_type,
                                    'plt_title': f'{dataset_key}, {prefix}',
                                    'plt_label': f'{long_name}, {units}',
                                    'plt_domain_type': region,
                                    'plotabsmin': min_value,
                                    'plotabsmax': max_value,
                                    'plt_out': f'{output_path}/{dataset_key}_{region}'
                                }
                                dict_data4visualization[region][dataset_key] = data4visualization
                                dict_set4visualization[region][dataset_key] = set4visualization

                    # Create an empty dictionary to store params as keys and regions as values
                    params_to_regions: Dict[str, Dict[str, Dict[str, Any]]] = {}
                    for region, data_dict in dict_data4visualization.items():
                        for param, data4visualization in data_dict.items():
                            if param not in params_to_regions:
                                params_to_regions[param] = {}

                            params_to_regions[param][region] = {
                                'data4visualization': data4visualization,
                                'set4visualization': dict_set4visualization.get(region, {}).get(param, {})
                            }

                    # -- Create JSON file for understanding data structure:
                    if self.ldebug:
                        json_report(params_to_regions, 'params_to_regions.json')

                    # -- Start visualization:
                    for param, region_dict in params_to_regions.items():
                        if region_dict is None:
                            raise ValueError(f"Missing regions for param: {param}")

                        if len(region_dict) == 1:
                            for region, bundle in region_dict.items():
                                logger.info(f'We are using single mode for 1d plot for {param} over {region}')
                                loc_data4visualization = bundle.get('data4visualization')
                                loc_set4visualization = bundle.get('set4visualization')
                                if loc_data4visualization is None or loc_set4visualization is None:
                                    raise ValueError(f"Missing data or settings for {param} in {region}")

                                # -- Run visualization:
                                if self.plot_1d_type in simple_1d_types:
                                    plot_1d_maker = Plot1D(
                                        self.eval_mode,
                                        loc_data4visualization,
                                        loc_set4visualization,
                                        self.path2configs,
                                        collage_type = None,
                                    )
                                    plot_1d_maker.create_single_plot_1d()

                                elif self.plot_1d_type in adv_1d_types:
                                    if self.eval_mode == 'CompareRAW':
                                        create_adv_plots(
                                            loc_data4visualization,
                                            loc_set4visualization,
                                            self.path2configs,
                                            self.refer,
                                            self.models,
                                        )
                                    else:
                                        logger.warning(
                                            "Advanced 1D plot '%s' is available only in CompareRAW mode. "
                                            "Current mode: %s — skipping advanced plots.",
                                            self.plot_1d_type, self.eval_mode
                                        )
                                        return
                                else:
                                    raise TypeError('self.plot_1d_type is incorrect')

                        elif len(region_dict) > 1:
                            logger.info(f'We are using subplot mode for 1d plots for {param} over regions')

                            # -- Collect data for all regions in one go:
                            loc_data4visualization = [
                                bundle['data4visualization']
                                for region in region_dict
                                if (bundle := region_dict.get(region)) and 'data4visualization' in bundle
                            ]
                            loc_set4visualization = [
                                bundle['set4visualization']
                                for region in region_dict
                                if (bundle := region_dict.get(region)) and 'set4visualization' in bundle
                            ]
                            if loc_data4visualization is None or loc_set4visualization is None:
                                raise ValueError(f"Missing data or settings for {param} in {region}")

                            # -- Create JSON file for understanding data structure:
                            if self.ldebug:
                                json_report(loc_data4visualization, 'loc_data4visualization.json')

                            # -- Set correct output prefix per subdomain group (norm / land / sea):
                            suffix = "" if group == "norm" else f"_{group}"
                            for cfg in loc_set4visualization:
                                cfg['plt_out'] = f"{output_path}/{param}{suffix}"

                            # -- Initialization of vis_func:
                            if self.plot_1d_type in simple_1d_types:
                                plot_1d_maker = Plot1D(
                                    self.eval_mode,
                                    loc_data4visualization,
                                    loc_set4visualization,
                                    self.path2configs,
                                    collage_type = 'yes'
                                )
                                plot_1d_maker.create_collage_plot_1d_auto()

                            elif self.plot_1d_type in adv_1d_types:
                                if self.eval_mode == 'CompareRAW':
                                    create_adv_plots(
                                        loc_data4visualization,
                                        loc_set4visualization,
                                        self.path2configs,
                                        self.refer,
                                        self.models,
                                    )
                                else:
                                    logger.warning(
                                        "Advanced 1D plot '%s' is available only in CompareRAW mode. "
                                        "Current mode: %s — skipping advanced plots.",
                                        self.plot_1d_type, self.eval_mode
                                    )
                                    return
                            else:
                                raise TypeError('self.plot_1d_type is incorrect')
                        else:
                            raise ValueError('Incorrect amount of subdomains')
