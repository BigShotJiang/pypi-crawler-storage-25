# Evaluation Suite (EvaSuite)
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2026, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# -- Program classes for the Evaluation Suite:

# -- Import Python modules:
import os
import subprocess as sp
import cdo as pycdo
from typing import Any, Optional, Dict, List, Union

# -- Import EvaSuite modules:
from hereon_evasuite.GeneralUtils import ShellLogging, SuiteUtilities
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name

GenUti = SuiteUtilities()
logger = get_logger()


# -- Start:
class CDONCOprog(object):
    @log_function_name
    def __init__(
        self: 'CDONCOprog',
        name: str,
        cfgprogram: Dict[str, Any],
        eval_suite_wdir: Optional[str] = None,
    ) -> None:
        """Initialization of CDONCOprog. Program doesn't have return variables,
           but save data as a self.variable
        """
        self.name = name
        self.EVAL_suite_workdir = eval_suite_wdir
        self.cfgprogram = cfgprogram
        logger.debug(f"Program instance: {self.name}")

    @log_function_name
    def _validate_executables(
        self,
        binary_path: str,
        executables: Union[str, Dict[str, str]],
    ) -> Union[str, Dict[str, str]]:
        """
        Validate the existence and executability of program binaries.

        Parameters:
        ----------------------------
            binary_path (str):
                Path to either a single executable (e.g., for 'cdo') or a directory
                containing multiple executables (e.g., for NCO or NCSYS tools).
            executables (str or list of str):
                - If a string: assumed to be a full path to a single binary (e.g., '/path/to/cdo').
                - If a list of strings: each string is the name of a binary that is expected
                  to exist in the provided binary_path directory.

        Returns:
        ----------------------------
            str:
                If a single binary is passed and successfully validated, returns the normalized path.
            dict:
                If a list of binaries is passed, returns a dictionary mapping each binary name
                to its validated full path.

        Raises:
        ----------------------------
            FileNotFoundError:
                If the directory does not exist, or if one or more expected binaries are missing
                or not executable.
        """
        bindir = os.path.normpath(
            os.path.dirname(binary_path)
            if isinstance(executables, str)
            else binary_path
        )
        logger.info(f"The programs of {self.name} are taken from {bindir}")
        # -- Control of the path:
        if not os.path.isdir(bindir):
            raise FileNotFoundError(f"The directory of {self.name} does not exist")

        # -- Get a single binary (e.g., cdo):
        if isinstance(executables, str):
            if not (os.path.isfile(executables) and os.access(executables, os.X_OK)):
                raise FileNotFoundError(
                    f"{self.name.upper()} binary not found or not executable at "
                    f"'{executables}'. Check your 'binary-location' in cfgprogram."
                )
            return os.path.normpath(executables)

        # -- Get multiple binaries (e.g., ncks, nccopy, etc.):
        full_paths = {cmd: f"{bindir}/{cmd}" for cmd in executables}
        missing = [
            cmd for cmd, path in full_paths.items()
            if not (os.path.isfile(path) and os.access(path, os.X_OK))
        ]
        if missing:
            raise FileNotFoundError(
                f"The following {self.name} program(s) are missing or not "
                f"executable: {', '.join(missing)}"
            )
        return full_paths


class CDO(CDONCOprog):
    @log_function_name
    def __init__(
        self: 'CDO',
        cfgprogram: Dict[str, Any],
        eval_suite_wdir: Optional[str] = None,
    ) -> None:
        """Initialization of CDO: """
        def versionparse(v):
            """Internal function for controling CDO version:"""
            return tuple(map(int, (v.split("."))))

        # -- Set a deligation rules for CDO class:
        super().__init__("cdo", cfgprogram, eval_suite_wdir)
        # -- Get CDO binary file:
        self.executable = self._validate_executables(
            binary_path=self.cfgprogram["binary-location"],
            executables=self.cfgprogram["binary-location"],
        )

        # -- Ensure that the same cdo version is used for pycdo as user-specified:
        os.environ.update({'CDO': self.executable})
        # -- The coordinates attribute:
        self.attcoord_cdo = '1' if versionparse(cfgprogram["version"]) < versionparse("1.9.3") else '0'
        logger.debug(f'******SET COORDINATES ATTRIBUTE OF CDO to {self.attcoord_cdo}')
        os.environ.update({'IGNORE_ATT_COORDINATES': self.attcoord_cdo})

        # -- Create instance of class pycdo.Cdo and set up it:
        self.pycdo = pycdo.Cdo()
        #    debug message from pycdo deactivated:
        self.pycdo.debug = False
        #    number of threads for cdo operations:
        self.ompthreads = cfgprogram["ompthreads"]
        #    repair level for netcdf:
        self.repairlevel = 2

    @log_function_name
    def FindVarName(
        self: 'CDO', datafile: str, varnamelist: Union[str, List[str]],
    ) -> tuple[list[str], list[str]]:
        """ Looks in the datafile for variables named as given in the 'varnamelist';
            returns the variables which intersect with the list 'varnamelist' and returns
            the variable names found in 'datafile'
            WARNING: this method is prone to errors if cdo throw out warnings

            Input Variables:
            ----------------------------
                self --> hereon_evasuite.Prog_CDONCO.CDO object at 0x7fffc2559b40
                datafile --> absolute path to dataset (
                    /work/bm1159/XCES/data4xces/reanalysis/reanalysis/ECMWF/IFS/
                    ERA5/mon/atmos//hfls/r1i1p1/hfls_Amon_reanalysis_era5_r1i1p1_19590101-19591231.nc
                )
                varnamelist --> list of variables for search (['hfls'])
        """
        if isinstance(varnamelist, str):
            raise TypeError('varnamelist cannot be a string in this case')

        cmd = "-s showvar " + datafile
        shellcmd = ShellLogging(cmd = self.executable + " " + cmd)
        shellout = shellcmd.ConsoleOutput()
        varns_file = GenUti.check_for_list(shellout.split(' '))
        # -- Remove the empty strings:
        # EV pay attention chanhed to list (varns_file = list(filter(None, varns_file)))
        varns_file = filter(None, varns_file)
        # -- Remove \n:
        varns_file = list(map(lambda s: s.strip('\n'), varns_file))

        temp1 = list(set(varnamelist).intersection(set(varns_file)))
        temp2 = varns_file
        return temp1, temp2

    @log_function_name
    def AllVarNamesRelevant(
        self: 'CDO', datafile: str, varnamelist: Union[str, List[str]]
    ) -> bool:
        """ looks in the datafile for variables named as given in the 'varnamelist';
            if all variables in datafile are in 'varnamelist', a TRUE is given back;
            WARNING: this method is prone to errors if cdo throw out warnings
        """
        if isinstance(varnamelist, str):
            raise TypeError('varnamelist cannot be a string in this case')

        cmd = "-s showvar " + datafile
        shellcmd = ShellLogging(cmd = self.executable + " " + cmd)
        shellout = shellcmd.ConsoleOutput()
        varns_file = GenUti.check_for_list(shellout.split(' '))
        # -- Remove the empty strings:
        varns_file = filter(None, varns_file)
        # -- Remove \n:
        varns_file = list(map(lambda s: s.strip('\n'), varns_file))
        return len(GenUti.check_for_list(varnamelist)) == len(varns_file)

    @log_function_name
    def MergeFiles(
        self: 'CDO', filesin: List[str], fileout: str,
        tmpfile: Optional[bool] = True,
    ) -> str:
        """
            Merge a list of strings containing filenames to one file:

            Input variables:
            ----------------------------
                1. filesin -> list of absolute paths for merging datasets [ds1, ds2]
                2. fileout -> absolute path to output file
                3. tmpfile -> mode swither

            Output variables:
            ----------------------------
                1. Return str (path to the merged NetCDF)
        """
        # -- Local variables:
        opts = f'-s -P {self.ompthreads}'
        filesinstr = ' '.join(filesin)
        # -- Merge data:
        if tmpfile is True:
            return self.pycdo.mergetime(input = filesinstr, options = opts)
        else:
            self.pycdo.mergetime(input = filesinstr, options = opts, output = fileout)
            return fileout

    @log_function_name
    def ExtractGridDesF(self: 'CDO', targetncdf: str, griddesfile: str) -> None:
        """Extract the grid description file:

            Input variables:
            ----------------------------
                1. targetncdf -> absolute path to NetCDF file (/scratch/../ERA5-monthly_Merge..nc)
                2. griddesfile -> method? (example: griddes_gridded_ERA5-monthly)
        """
        # -- Control of input variables:
        if not targetncdf:
            raise ValueError("Input NetCDF file path cannot be empty.")
        if not griddesfile:
            raise ValueError("Output grid description file name cannot be empty.")

        # -- Local variables:
        logger.debug(
            "ExtractGridDesF called with targetncdf='%s', griddesfile='%s'",
            targetncdf, griddesfile
        )

        opts = f'-s -P {self.ompthreads}'
        cmd = f"{targetncdf}>{griddesfile}"
        logger.debug(
            "Running CDO griddes2 with opts='%s' and input='%s'",
            opts, cmd
        )

        # -- Main part:
        try:
            self.pycdo.griddes2(input = cmd, options = opts)
        except Exception as e:
            logger.error(
                "CDO griddes2 failed for input='%s'. Error: %s",
                cmd, str(e), exc_info=True
            )
            raise

        # -- Verify output file exists:
        if os.path.exists(griddesfile):
            logger.debug(
                "Griddes file successfully created: '%s' (%d bytes)",
                griddesfile, os.path.getsize(griddesfile)
            )
        else:
            logger.warning("Griddes file was not created: '%s'", griddesfile)

    @log_function_name
    def IntpolHori(
        self: 'CDO',
        filein: str,
        fileout: str,
        method: str,
        griddesf: str,
        lcc: bool = False,
        genweights: bool = False,
    ):
        """
        Perform horizontal interpolation using CDO operators.

        Parameters:
        ----------
        filein : str
            Path to the input NetCDF file to be interpolated.
        fileout : str
            Path to the output NetCDF file to be generated.
        method : str
            Interpolation method. Supported methods:
                - 'bilinear'
                - 'nearestn'
                - 'conservative1st'
                - 'conservative2nd'
                - 'distance'
                - 'largestarea'
        griddesf : str
            Grid description file used as interpolation target.
        lcc : bool, optional
            If True, sets the IGNORE_ATT_COORDINATES environment variable (used for lambert conformal grids),
            but only when method is 'conservative1st' or 'conservative2nd'.
        genweights : bool, optional
            If True, generates and uses interpolation weights. Only supported for method == 'bilinear'.

        Behavior:
        --------
        - If genweights=False:
            - Uses corresponding CDO remap operator for the selected method.
            - For conservative methods ('conservative1st', 'conservative2nd') and lcc=True,
              temporarily sets IGNORE_ATT_COORDINATES during the call.
            - Returns fileout if operation succeeds.

        - If genweights=True:
            - Only supports 'bilinear'.
            - First generates weights using 'genbil'.
            - Then uses 'remap' with weights to produce final fileout.
            - Deletes temporary weights file after use.
            - Returns fileout if operation succeeds.

        Returns:
        -------
        str
            Path to the interpolated output file (fileout), or raises an exception on error.

        Raises:
        ------
        ValueError:
            - If method is not supported.
            - If genweights=True and method is not 'bilinear'.

        Notes:
        -----
        - Returns None only if interpolation is skipped upstream (not within this function).
        - This function always returns fileout on success, never None.
        - Environment variable IGNORE_ATT_COORDINATES is preserved after use.
        """
        # -- Set CDO methods for interpolation:
        cdo_methods = {
            "bilinear": self.pycdo.remapbil,
            "nearestn": self.pycdo.remapnn,
            "conservative1st": self.pycdo.remapcon,
            "conservative2nd": self.pycdo.remapcon2,
            "distance": self.pycdo.remapdis,
            "largestarea": self.pycdo.remaplaf,
        }
        # -- Number of threads:
        cdo_opts = f'-s -P {self.ompthreads}'
        logger.debug(
            "Starting interpolation using method='%s', genweights=%s, lcc=%s",
            method, genweights, lcc
        )

        # -- Intrepolation without weights
        if not genweights:
            # -- Control of available methods:
            if method not in cdo_methods:
                logger.error("Unsupported method '%s'", method)
                raise ValueError(f"Unsupported CDO method for interpolation: {method}")
            # -- Start interpolation based on known methods:
            try:
                # -- Apply IGNORE_ATT_COORDINATES for conservative methods with lcc
                if method in {"conservative1st", "conservative2nd"}:
                    old_env = os.environ.get("IGNORE_ATT_COORDINATES", "")
                    if lcc:
                        logger.debug(
                            "Temporarily setting IGNORE_ATT_COORDINATES to %s",
                            self.attcoord_cdo
                        )
                        os.environ["IGNORE_ATT_COORDINATES"] = self.attcoord_cdo
                    logger.debug(
                        "Calling CDO method '%s' with input='%s', output='%s'",
                        method, filein, fileout
                    )
                    cdo_methods[method](griddesf, input=filein, options=cdo_opts, output=fileout)

                    if lcc:
                        os.environ["IGNORE_ATT_COORDINATES"] = old_env
                        logger.debug("Restored IGNORE_ATT_COORDINATES to previous value")
                else:
                    logger.debug(
                        "Calling CDO method '%s' with input='%s', output='%s'",
                        method, filein, fileout
                    )
                    cdo_methods[method](
                        griddesf,
                        input = filein,
                        options = cdo_opts,
                        output = fileout,
                    )
                return fileout

            except Exception as e:
                logger.error("Error during remapping with method '%s': %s", method, str(e), exc_info=True)
                raise
        # -- Interpolation using generated weights (only for bilinear)
        else:
            if method == "bilinear":
                # -- local parameters:
                fileweights = f'{os.path.dirname(fileout)}/genweights.nc'
                fgenbil_input = f"-seltimestep,1 {filein}"
                fgrid_weights = f"{griddesf},{fileweights}"
                try:
                    # -- get weigths of grid:
                    logger.debug("Generating weights with genbil -> weights file: '%s'", fileweights)
                    self.pycdo.genbil(
                        griddesf,
                        input = fgenbil_input,
                        options = cdo_opts,
                        output = fileweights,
                    )
                    # -- run interpolation with weights file:
                    logger.debug("Running remap with weights file")
                    self.pycdo.remap(
                        fgrid_weights,
                        input = filein,
                        options = cdo_opts,
                        output = fileout,
                    )
                    logger.info("Interpolation with weights completed successfully")
                finally:
                    if os.path.exists(fileweights):
                        logger.debug("Cleaning up temporary weights file: '%s'", fileweights)
                        sp.check_call(["rm", "-f", fileweights])
                return fileout
            else:
                logger.error(
                    "genweights=True only supports 'bilinear' method (requested: %s)", method)
                raise ValueError(
                    f"genweights=True only supports 'bilinear' method (requested: {method})")

    @log_function_name
    def IntpolVert(
        self: 'CDO',
        filein: str,
        fileout: str,
        intpolmethod: Optional[str] = "linear",
        targetlevs: Optional[Any] = None,
        tmpfile: Optional[bool] = False,
    ):
        """Perform a vertical interpolation depending on the method
           only linear is supported by cdo's at the moment """
        logger.warning(
            "EvaSuite Warning: You are using an untested function.\n"
            "If possible, please send your configuration files to: "
            "evgenii.churiulin@kit.edu for testing and validation support."
        )
        # -- Local variables:
        opts = f'-s -P {self.ompthreads}'

        levellist = ','.join(
            GenUti.check_for_list(
                GenUti.nparr_to_str(targetlevs)
            )
        )
        if intpolmethod == "linear":
            if tmpfile is True:
                return self.pycdo.intlevel(
                    levellist, input = filein, options = opts)
            else:
                self.pycdo.intlevel(
                    levellist, input = filein, options = opts, output = fileout)
                return fileout
        else:
            logger.error(
                f'The {intpolmethod} -method for vertical interpolation is not supported.'
            )

    @log_function_name
    def SetValidRange(
        self: 'CDO',
        filein: str,
        fileout: str,
        levdwn = None,
        levup = None,
    ) -> str:
        """ Set all values within an range to 1 and all others to nan: """
        logger.warning(
            "EvaSuite Warning: You are using an untested function.\n"
            "If possible, please send your configuration files to: "
            "evgenii.churiulin@kit.edu for testing and validation support."
        )
        # -- Local variables:
        if levdwn is None or levup is None:
            raise ValueError('levdwn or levup variable(s) is (are) equal None')

        oper = f'-ifthenc,1.0 -setvrange,{levdwn},{levup}'
        opt = f'-s -P {self.ompthreads}'

        self.pycdo.addc(
            0.0, input = oper + " " + filein, options = opt, output = fileout)
        return fileout

    @log_function_name
    def SetRangeToMissRestMask(
        self: 'CDO',
        filein: str,
        fileout: str,
        levdwn: float | None = None,
        levup: float | None = None,
        bigthanc: bool = True,
    ) -> str:
        """
        Apply a threshold-based mask to a NetCDF file.

        This operation sets all values **within** the range `[levdwn, levup]` to
        missing values (NaN), and then creates a binary mask based on a comparison
        against either the lower or upper threshold.

        Parameters
        ----------
        filein : str
            Path to the input NetCDF file to process.
        fileout : str
            Output NetCDF file path where the resulting mask will be written.
        levdwn : float or None, optional
            Lower threshold used for ``setrtomiss`` and ``gec`` when ``bigthanc=True``.
        levup : float or None, optional
            Upper threshold used for ``setrtomiss`` and ``lec`` when ``bigthanc=False``.
        bigthanc : bool, default True
            Selects which comparison operator to apply:
            - ``True``  → use ``gec(levdwn)``
            - ``False`` → use ``lec(levup)``

        Returns
        -------
        str
            Path to the output NetCDF file written to ``fileout``.

        Notes
        -----
        This function is commonly used in EvaSuite to construct land/sea subregion
        masks from continuous fields (e.g., fractional land-sea masks), by:
            1. setting intermediate values to missing,
            2. thresholding the remaining values to binary masks.

        After masking:
            - If ``bigthanc`` is ``True``  → the operator ``gec(levdwn)`` is applied
                (values >= levdwn → 1, values < levdwn → missing)
            - If ``bigthanc`` is ``False`` → the operator ``lec(levup)`` is applied
                (values <= levup → 1, values > levup → missing)
        """
        # -- Local variables:
        opts = f'-s -P {self.ompthreads}'
        finput = f"-setrtomiss,{levdwn},{levup} {filein}"
        # --- Dictionary-based operator selection and execute operator:
        cdo_oper = {True: self.pycdo.gec, False: self.pycdo.lec}[bigthanc]
        threshold = levdwn if bigthanc else levup
        cdo_oper(threshold, input=finput, options=opts, output=fileout)
        return fileout

    @log_function_name
    def CombOfTwoDatsets(
        self: 'CDO',
        filein1: str,
        filein2: str,
        method: str,
        varlist: Optional[List] = None,
        fileout: Optional[str] = None,
    ):
        """
        Combine two datasets using a CDO binary operator.

        Depending on the selected method, this function computes the minimum,
        maximum, mean, or element-wise product of two NetCDF datasets. Optional
        variable selection may be applied prior to the operation. The result is
        returned as a CDO object or written directly to an output file.

        Parameters
        ----------
        filein1 : str
            Path to the first input NetCDF file.
        filein2 : str
            Path to the second input NetCDF file.
        method : {"min", "max", "mean", "mul"}
            Combination method:
                - "min": gridpoint-wise minimum
                - "max": gridpoint-wise maximum
                - "mean": gridpoint-wise average
                - "mul": gridpoint-wise multiplication
        varlist : list of str, optional
            List of variables to select from each input file before processing.
            If None, all variables are used.
        fileout : str, optional
            Path to the output file. If None, the CDO operator result is returned
            directly instead of being written to disk.

        Returns
        -------
        str or CDO
            If `fileout` is None, returns the CDO operation object (lazy result).
            If `fileout` is given, returns the path of the output file.

        Raises
        ------
        ValueError
            If an unsupported method is provided.
        """
        # -- Local variables:
        cdo_opts = f'-Q -s -P {self.ompthreads}'
        cdo_methods = {
            'min': self.pycdo.min, 'max': self.pycdo.max,
            'mean': self.pycdo.mulc, 'mul': self.pycdo.mul,
        }
        # -- Check current cdo method:
        if method not in cdo_methods:
            raise ValueError(f"Unsupported method: {method}")

        # -- Check varlist values:
        if varlist is None:
            cmdvar = ''
        else:
            cmdvar = (
                f"-selvar,{varlist[0]}"
                if len(varlist) == 1
                else f"-selvar,{','.join(varlist)}"
            )

        # -- Build complete CDO input command:
        cmdprep = f"{cmdvar} {filein1} {cmdvar} {filein2}"

        # -- Show final CDO call before executing:
        if method == "mean":
            cdo_input, cdo_args = f"-add {cmdprep}", ("0.5",)
        else:
            cdo_input, cdo_args = cmdprep, ()

        # -- Execute operator:
        if fileout is None:
            return cdo_methods[method](
                *cdo_args, input = cdo_input, options = cdo_opts)
        else:
            cdo_methods[method](
                *cdo_args, input=cdo_input, options=cdo_opts, output=fileout)
            return fileout

    @log_function_name
    def ConvertSpatialOperaToCdoCmd(
        self: 'CDO',
        spatial_operax: str,
        spatial_operay: str,
    ) -> Union[str, bool]:
        """
        Convert spatial operation keywords from configuration files
        to corresponding CDO spatial aggregation commands.

        Parameters:
        ----------------------------
            spatial_operax (str): First part of the spatial operator (e.g., 'mean').
            spatial_operay (str): Second part of the spatial operator (e.g., 'mean').

        Returns:
        ----------------------------
            Union[str, bool]: Corresponding CDO operator (e.g., 'fldmean'), or False
                              if the combination maps explicitly to False.

        Raises:
        ----------------------------
            KeyError: If the combined operator is not found in the mapping.
            SystemExit: If the key is missing and error handling is enabled.
        """
        cdo_operator_map: dict[str, Union[str, bool]] = {
            "mean+mean": "fldmean",
            "sum+sum": "fldsum",
            "-+-": False,
        }
        combined_operator = f"{spatial_operax}+{spatial_operay}"

        error_message = (
            f"Unsupported spatial aggregation type '{combined_operator}' — "
            f"no corresponding CDO command found."
        )

        logger.debug(
            f"Attempting to convert spatial operation '{combined_operator}' to CDO command.")

        result = GenUti.safe_access_bib(
            errmsg=error_message,
            exception=KeyError,
            dicttest=cdo_operator_map,
            dictkey=combined_operator,
            errhandle=True
        )
        logger.info(
            f"Successfully converted '{combined_operator}' to CDO command: {result}")
        return result


class NCO(CDONCOprog):
    @log_function_name
    def __init__(
        self: 'NCO',
        cfgprogram: Dict[str, Any],
        eval_suite_wdir: Optional[str] = None,
    ) -> None:
        """Initialization of NCO class"""
        # -- Set a deligation rules for NCO class:
        super().__init__("nco", cfgprogram, eval_suite_wdir)
        # -- Get NCO binary files:
        self.executable = self._validate_executables(
            binary_path=self.cfgprogram["binary-directory"],
            executables=["ncks", "ncrcat", "ncatted", "ncrename"]
        )
        # -- How deeply to correct nco-processed netcdf-files:
        self.repairlevel = 1
        self.ompthreads = cfgprogram["ompthreads"]

    @log_function_name
    def FindVarName(
        self: 'NCO', datafile: str, varnamelist: Union[str, List],
        PartString: Optional[bool] = False,
    ) -> List:
        """ Looks in the datafile for variables named as given in the 'varnamelist';
            if partstring = True, this routine gives back those varnames in
            datafile which contain as substring something from varnamelist

            Input variables:
            ----------------------------
                1. datafile -> absolute path to NetCDF file
                2. varnamelist -> name of parameters for work. It can be str or list[str]
                3. PartString -> module switcher

            Output variables:
            ----------------------------
                1. List
        """
        cmd = "-m " + datafile + "| grep -E ': type' | cut -f 1 -d ' ' | sed 's/://' | sort"
        shellcmd = ShellLogging(cmd = self.executable["ncks"] + " " + cmd)
        shellout = shellcmd.ConsoleOutput()
        varns_file = GenUti.check_for_list(shellout.split('\n'))
        if PartString:
            matching = []
            for searchstr in GenUti.check_for_list(varnamelist):
                matching.extend(
                    [varns for varns in varns_file if searchstr in varns]
                )
            return matching
        else:
            return list(set(GenUti.check_for_list(varnamelist)).intersection(set(varns_file)))

    @log_function_name
    def FindAttributes(
        self: 'NCO', datafile: str, attributes: List[str],
        varname: Optional[str] = None,
    ) -> List:
        """
            Prints out a group of tuples [variable name, attribute and value] w.r.t.
            those netcdf-variables which contain one of the attributes in the list 'attribues';
            if varname is given.

            Input variables:
            ----------------------------
                1. datafile -> absolute path to the data
                2. attributes -> list of attributes
                    ['coordinates', 'grid_mapping', 'grid_mapping_name',
                     'grid_north_pole_latitude', 'grid_north_pole_longitude']
                3. varname -> name of variables

            Output variables:
            ----------------------------
                dictvarattrvalue

        """
        dictvarattrvalue = []
        cmd = "-m " + datafile + "| grep -E ' attribute '"
        #
        for attr in attributes:
            cmd2 = cmd + " | grep -E " + attr
            if varname is not None:
                cmd2 = cmd2 + " | grep -E " + varname

            shellcmd = ShellLogging(cmd = self.executable["ncks"] + " " + cmd2)
            shellout = shellcmd.ConsoleOutput()
            if shellout is not None:
                for line in shellout.split('\n'):
                    if attr in line.split('value')[0]:
                        dictvarattrvalue.append(
                            [
                                line.split(' ')[0],
                                line.split(' size =')[0].partition(':')[-1].partition(',')[0].strip(),
                                line.split(' value =')[-1].strip(),
                            ]
                        )
        return dictvarattrvalue

    @log_function_name
    def PutAttribute(
        self: 'NCO',
        filein: str,
        varlist: List[str],
        attriblist: List[str],
        valuelist: List[str],
        AttrType: Optional[str] = 'c',
        mode: Optional[str] = 'o',
    ) -> None:
        """ Put a list of attributes to corresponding variables using the default
            mode modify and type char:

            Input variables:
            ----------------------------
                1. filein --> input path to the file
                    (/scratch/../P_Mediterranean_mask.nc)
                2. varlist --> list of something (['global', 'global'])
                3. attriblist --> list of attributes (['EVASUITE_subdom_name', 'EVASUITE_targetgrid'])
                4. valuelist --> list of something (['P_Mediterranean', 'Eobs_v25_Ex'])
                5. AttrType
                6. mode
        """
        cmd = '-O '
        for lauf in range(len(varlist)):
            cmd = cmd + f" -a {attriblist[lauf]},{varlist[lauf]},{mode},{AttrType},'{valuelist[lauf]}'"

        sp.check_call(
            [self.executable["ncatted"] + ' ' + cmd + ' ' + filein],
            stderr = sp.STDOUT,
            shell = True,
        )

    @log_function_name
    def CopyVariableFile2File(self: 'NCO', source: str, targetf: str, param: str) -> None:
        """ Copy a specific parameter (or list) from one file to another:"""
        cmd = '-h -A -C '
        cmd = cmd + '-v ' + ','.join(GenUti.check_for_list(param))
        sp.check_call(
            [self.executable["ncks"] + " " + cmd + ' ' + source + ' ' + targetf],
            stderr = sp.STDOUT,
            shell = True,
        )

    @log_function_name
    def CutDomainXYZ(
        self: 'NCO', filein: str, fileout: str,
        RangeSpat: Optional[Union[Dict[str, List], bool]] = None,
        RangeLev: Optional[Union[Dict[str, List], bool]] = None,
    ) -> None:
        """ Cut out a sub-domain out of the whole domain;
            RangeSpat is a dictionary of two entries, each with a list of indices for
            the x- and the y-direction seperately; RangeLev is a dictionary of one entry

            Input variables:
            ----------------------------
                1. filein -> input path (absolute)
                2. fileout -> output path (absolute)
                3. RangeSpat -> bool option for activation RangeSpat algorithm.
                4. RangeLev -> bool option for activation RangeLev algorithm.

            Output variables:
            ----------------------------
        """
        cmdprep = ' -h -O'
        if RangeSpat:
            # -- Check if RangeSpat is a dictionary:
            if isinstance(RangeSpat, dict):
                for keyes in RangeSpat.keys():
                    cmdprep = cmdprep + f'  -d {keyes},{RangeSpat[keyes][0]},{RangeSpat[keyes][1]}'
            else:
                raise TypeError('RangeSpat has incorrect type. Has to be a dictionary')

        if RangeLev:
            # Check if RangeLev is a dictionary
            if isinstance(RangeLev, dict):
                keyes = list(RangeLev.keys())[0]
                cmdprep = cmdprep + f' -d {keyes},{RangeLev[keyes][0]},{RangeLev[keyes][1]}'
                if len(RangeLev[keyes]) == 3:
                    cmdprep = cmdprep + ',' + str(RangeLev[keyes][2])
            else:
                raise TypeError('RangeLev has incorrect type. Has to be a dictionary')

        if cmdprep:
            sp.check_call(
                [self.executable["ncks"] + cmdprep + ' ' + filein + ' ' + fileout],
                stderr = sp.STDOUT,
                shell = True,
            )


class NCSYS(CDONCOprog):
    @log_function_name
    def __init__(
        self: 'NCSYS',
        cfgprogram: Dict[str, Any],
        eval_suite_wdir: Optional[str] = None,
    ) -> None:
        """ Initialization of NCSYS class """
        # -- Set a deligation rules for NCSYS class:
        super().__init__("ncsys", cfgprogram, eval_suite_wdir)
        # -- Get NCSYS binary files:
        self.executable = self._validate_executables(
            binary_path=self.cfgprogram["binary-directory"],
            executables=["nccopy", "ncdump"]
        )
        # -- How deeply to correct nco-processed netcdf-files:
        self.repairlevel = 1
        self.ompthreads = cfgprogram["ompthreads"]

    @log_function_name
    def DeflateCheck(self: 'NCSYS', filein: str, variable: str) -> bool:
        """
        Check whether a variable in a NetCDF file has deflation enabled.

        Parameters:
        ----------------------------
            filein (str): Path to the NetCDF file.
            variable (str): Name of the variable to check.

        Returns:
        ----------------------------
            bool: True if deflate level is found for the variable, False otherwise.
        """
        cmd = "-h -s " + filein + " | fgrep " + variable + " | fgrep DeflateLevel | cut -f2 -d'=' | cut -f1 -d';'"
        shellcmd = ShellLogging(cmd = self.executable["ncdump"] + " " + cmd)
        shellout = shellcmd.ConsoleOutput()
        if shellout == '':
            return False
        else:
            return True

    @log_function_name
    def DeflateNcdf(self: 'NCSYS', filein: str, fileout: str) -> None:
        """ Deflate internally zipped NetCDF files using nccopy """
        import time
        start = time.perf_counter()

        cmd = [
            self.executable["nccopy"],
            "-k", "3",
            "-d", "0",
            filein,
            fileout
        ]
        sp.check_call(cmd, stderr=sp.STDOUT)
        end = time.perf_counter()
        logger.info(f"DeflateNcdf runtime: {end - start:.4f} seconds")
