# Evaluation Suite (EvaSuite)
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2026, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# ---------------------------------------------------------------
#    Program description:
#    User GUI form for creationg YAML file:
#       1. __init__(self, root) - Initializes the GUI layout, loads default
#               settings, and builds all frames with scrollbars and controls.
#
#       2. create_entry(self, parent, label, default, row) - Creates a labeled
#               input field (Entry) for one parameter with default value handling
#               and change detection.
#
#       3. update_entry_color(self, entry, default) - Updates the background color
#               of an Entry widget depending on whether the user has modified the value.
#
#       4. toggle_grid_fields(self) - Enables or disables the grid-related input
#              fields based on the 'Grid Add' checkbox state.
#
#       5. save_settings(self) - Saves only the modified (user-edited) settings
#              into a YAML file. Cleans up inputs before saving.
#
#       6. load_projection_options(self, event=None) - Loads projection-specific
#              subplot settings and creates subplot-related input fields dynamically.
#
#       7. toggle_subplot_params(self, option) - Enables or disables input fields
#              for a selected subplot configuration based on the associated checkbox.
#
#       8. on_user_edit(self, entry, option, param) - Detects changes in subplot
#              parameter fields and updates their color to indicate modification.
#
#       9. on_user_edit_general(self, entry, key) - Detects changes in general
#              parameter fields and updates their color to indicate modification.
#
#      10. debug_compare_with_defaults(self) - Compares current GUI settings with
#              the default values and prints mismatches for debugging purposes.
#
#      11. save_defaults_to_yaml(self) - Saves the full default configuration into
#              a YAML file for later comparison or reuse.
#
#      12. clean_input_value(self, value) - Cleans user inputs by removing extra
#              spaces and ensures consistent formatting of string values.
#
#      13. restore_default_values(self) - Restore default values
#
#      14. load_special_limits_csv(self, is_diff) - Load min and max values from CSV
#          files
#
#    History:
#    Version    Date       Name
#    ---------- ---------- ----
#    1.1        04.2025   Evgenii Churiulin, IMKTRO
#                         Initial realise
# ---------------------------------------------------------------
# -- Import Python modules:
import tkinter as tk
import yaml
import re
import pandas as pd
from tkinter import ttk, filedialog, messagebox
from typing import Any, Optional
# -- Import user map_settings:
from hereon_evasuite.visual_config import Builder_maps_config


class MapSettingsGUI:
    """
    MapSettingsGUI is a graphical user interface (GUI) tool for configuring
    and managing 2D map visualization settings for scientific plotting.

    This class provides an interactive environment to adjust parameters
    related to general map appearance, Cartopy layers, grid properties,
    and subplot configurations. The GUI allows the user to edit settings,
    automatically detect modifications (via color highlighting), and
    save the configuration into YAML files either as default templates
    or as user-modified settings.

    Core Features:
    --------------
    - Dynamically generates input fields based on the configuration structure.
    - Supports projection-specific subplot settings (e.g., LambertConformal, PlateCarree).
    - Highlights modified fields to indicate user changes.
    - Enables or disables input fields for grids and subplots based on user interaction.
    - Provides functions to compare current settings with defaults (debugging).
    - Supports export of both default and user-modified settings into YAML format.
    - Handles special data types like Cartopy projections and Python `range()` objects gracefully.

    Intended Usage:
    ---------------
    Designed for researchers and developers working with map-based
    visualizations who need flexible and editable configuration management.
    """

    def __init__(self, root: tk.Tk) -> None:
        """
        Initialize the MapSettingsGUI application and build the user interface.

        This constructor:
        ----------------------------
          - Loads the default map visualization settings from Builder_maps_config.
          - Categorizes parameters into groups (general, cartopy, grid, special) for
            organized GUI layout.
          - Sets up a scrollable Tkinter window with labeled frames and entry fields
            for each configurable parameter.
          - Initializes GUI color scheme for distinguishing default vs. modified values.
          - Prepares projection-related defaults and associated subplot configuration fields.
          - Creates interactive buttons for saving, restoring, exporting, and debugging settings.
          - Connects help buttons to context-specific documentation popups.

        Args:
        ----------------------------
            root (tk.Tk):
                The root Tkinter window that will host the GUI widgets.

        Side Effects:
        ----------------------------
            - Modifies the `root` window title and embeds a scrollable canvas for the configuration form.
            - Populates internal dictionaries (`entries`, `general_defaults`, `special_limits_data`,
              `default_subplot_values`) for later settings manipulation.
            - Binds event handlers for live change detection and dynamic enabling/disabling of fields.
        """
        map_conf = Builder_maps_config()
        map_settings = map_conf._build_maps_settings().values
        map_conf._control_maps_settings(map_settings)
        # -- General parameters (automatically based on map_ prefix):
        general_parameters = [
            key for key in map_settings.keys() if key.startswith('map_')]
        # -- Cartopy_parameters (automatically based on coast_, land_,ocean_  prefixes):
        cartopy_parameters = [
            key for key in map_settings.keys() if key.startswith(('coast_', 'land_', 'ocean_'))]
        # -- Grid_parameters (automatically based on grid_ prefix):
        grid_parameters = [
            key for key in map_settings.keys() if key.startswith('grid_')]
        # -- Special parameters (change logic of visual_map_settings):
        special_parameters = [
            key for key in map_settings.keys() if key.startswith('maps_')]
        # -- Projections (if you want to add more projections you have to add
        #    proj_n here and modify self.default_subplot_values and proj_combo):
        proj_1 = "copat2_LambertConformal"
        proj_2 = "global_PlateCarree"
        proj_3 = "RotatedPole"
        # -- CSV field auto-detection and entry mapping:
        self.special_limits_data = {
            'maps_min_values': {},
            'maps_max_values': {},
            'maps_min_values_diff': {},
            'maps_max_values_diff': {},
        }
        # -- GUI form colors:
        self.form_color_default = 'lightgray'
        self.form_color_modif = 'white'

        # -- Start main section:
        self.root = root
        self.root.title("2D Map Settings Generator")

        # -- Scrollable Frame Setup:
        self.canvas = tk.Canvas(self.root, borderwidth=0, width=1200, height=800)
        self.frame = ttk.Frame(self.canvas)
        # -- Vertical Scrollbar:
        self.vsb = tk.Scrollbar(
            self.root, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vsb.set)
        # Horizontal Scrollbar
        self.hsb = tk.Scrollbar(
            self.root, orient="horizontal", command=self.canvas.xview)
        self.canvas.configure(xscrollcommand=self.hsb.set)
        # Packing order
        self.vsb.pack(side="right", fill="y")
        self.hsb.pack(side="bottom", fill="x")
        self.canvas.pack(side="left", fill="both", expand=True)
        # Window for the frame inside the canvas
        self.canvas_window = self.canvas.create_window((0, 0), window=self.frame, anchor="nw")

        # Adjust scrollregion dynamically:
        def on_frame_configure(event):
            self.canvas.configure(scrollregion=self.canvas.bbox("all"))

        self.frame.bind("<Configure>", on_frame_configure)
        self.entries = {}
        # -- General Settings Frame --
        general_frame = ttk.LabelFrame(self.frame, text="General Settings")
        general_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=5)
        btn = tk.Button(general_frame, text="?", command=lambda: self.show_info(section="general"))
        btn.grid(row=0, column=2, padx=5, pady=2)
        for idx, param in enumerate(general_parameters):
            self.create_entry(general_frame, param, map_settings.get(param), idx)

        # -- Special settings:
        special_frame = ttk.LabelFrame(self.frame, text="Special Parameters")
        special_frame.grid(row=0, column=1, sticky="nsew", padx=10, pady=5)  # Or next row if left-column stacking
        btn = tk.Button(special_frame, text="?", command=lambda: self.show_info(section="special"))
        btn.grid(row=0, column=2, padx=5, pady=2)
        for idx, param in enumerate(special_parameters):
            self.create_entry(special_frame, param, map_settings.get(param), idx)
        # -- Buttons to load separate CSVs for standard and diff maps
        self.load_std_csv_button = tk.Button(
            special_frame,
            text="Load Standard CSV (maps_min/max_values)",
            command=lambda: self.load_special_limits_csv(is_diff=False),
            bg="#e0f7fa"
        )
        self.load_std_csv_button.grid(row=len(special_parameters) + 1, column=0, columnspan=2, pady=(5, 2))

        self.load_diff_csv_button = tk.Button(
            special_frame,
            text="Load Diff CSV (maps_min/max_values_diff)",
            command=lambda: self.load_special_limits_csv(is_diff=True),
            bg="#ffe0b2"
        )
        self.load_diff_csv_button.grid(row=len(special_parameters) + 2, column=0, columnspan=2, pady=(2, 5))

        warning_label = tk.Label(
            special_frame,
            text="Don't change these values unless you're sure! They override default behavior in map visualization.",
            fg="red",
            wraplength=1000,
            justify="left"
        )
        warning_label.grid(row=len(special_parameters) + 3, column=0, columnspan=3, sticky="w", padx=5, pady=(0, 5))

        # -- Cartopy Layers Properties --
        cartopy_frame = ttk.LabelFrame(self.frame, text="Cartopy Layers Properties")
        cartopy_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        btn = tk.Button(cartopy_frame, text="?", command=lambda: self.show_info(section="cartopy"))
        btn.grid(row=1, column=2, padx=5, pady=1)
        for idx, param in enumerate(cartopy_parameters):
            self.create_entry(cartopy_frame, param, map_settings.get(param), idx)

        # -- Grid Properties --
        grid_frame = ttk.LabelFrame(self.frame, text="Grid Properties")
        grid_frame.grid(row=2, column=0, sticky="nsew", padx=10, pady=5)
        btn = tk.Button(grid_frame, text="?", command=lambda: self.show_info(section="grid"))
        btn.grid(row=1, column=2, padx=5, pady=1)
        self.grid_add_var = tk.BooleanVar(value=True)
        grid_check = ttk.Checkbutton(
            grid_frame,
            text="Grid Add",
            variable=self.grid_add_var,
            command=self.toggle_grid_fields)
        grid_check.grid(row=0, column=0, columnspan=2)
        self.grid_entries = []
        # Start from row 1 because row 0 is the "Grid Add" checkbox
        for idx, param in enumerate(grid_parameters, start=1):
            value = map_settings.get(param)
            # Convert grid_xlocs and grid_ylocs to string if they are ranges or lists
            if param in ['grid_xlocs', 'grid_ylocs']:
                value = str(value)
            self.grid_entries.append(self.create_entry(grid_frame, param, value, idx))

        # -- Default Settings --
        self.default_subplot_values = {
            proj_1: map_settings.get(proj_1),
            proj_2: map_settings.get(proj_2),
            proj_3: map_settings.get(proj_3),
        }

        # -- Projection Settings --
        self.proj_frame = ttk.LabelFrame(self.frame, text="Projection Settings")
        self.proj_frame.grid(row=3, column=0, sticky="nsew", padx=10, pady=5)
        # -- Add help:
        btn = tk.Button(
            self.proj_frame,
            text="?",
            command=lambda: self.show_info(section="projection")
        )
        btn.grid(row=0, column=2, padx=5, pady=2)

        self.proj_type = tk.StringVar(value="")
        ttk.Label(self.proj_frame, text="Projection Type:").grid(row=0, column=0, sticky="e")
        proj_combo = ttk.Combobox(
            self.proj_frame,
            textvariable=self.proj_type,
            values=[proj_1, proj_2, proj_3],
        )
        proj_combo.grid(row=0, column=1)
        proj_combo.bind("<<ComboboxSelected>>", self.load_projection_options)
        # -- Button (SAVE):
        self.save_button = tk.Button(
            self.frame,
            text = "Save Settings as YAML",
            command = self.save_settings)
        self.save_button.grid(row=5, column=0, pady=10)
        # -- Button (DEBUG):
        self.debug_button = tk.Button(
            self.frame,
            text = "DEBUG: Compare with Defaults",
            command = self.debug_compare_with_defaults)
        self.debug_button.grid(row=6, column=0, pady=10)
        # -- Button (EXPORT):
        self.export_defaults_button = tk.Button(
            self.frame,
            text="Export Default Configuration",
            command=self.save_defaults_to_yaml)
        self.export_defaults_button.grid(row=7, column=0, pady=10)
        # -- Restore default configuration
        self.restore_defaults_button = tk.Button(
            self.frame,
            text="Restore Default Configuration",
            command=self.restore_default_values,
            bg="#ffe0e0"
        )
        self.restore_defaults_button.grid(row=8, column=0, pady=10)
        # -- Grid
        self.toggle_grid_fields()

    def create_entry(
        self,
        parent: tk.Widget,
        label: str,
        default: Any,
        row: int
    ) -> tk.Entry:
        """
        Creates a labeled Entry field in the given parent frame, adds it to the GUI,
        and sets up color-based indication for default vs. user-modified values.

        Parameters:
        -----------
        parent : tkinter Frame
            The frame (e.g., general_frame, cartopy_frame, grid_frame) where the entry will be placed.
        label : str
            The name of the setting (used as label text and dictionary key).
        default : any
            The default value for this parameter (used to pre-fill the entry).
        row : int
            The row number in the grid layout where this entry will be placed.

        Returns:
        --------
            entry : tkinter Entry
                The created Entry widget for later reference.
        """
        # -- Create the label widget for the parameter name:
        label_widget = tk.Label(parent, text=label + ":")
        label_widget.grid(row=row, column=0, sticky="w", padx=(5, 2), pady=2)

        # -- Create the Entry widget for user input:
        entry = tk.Entry(parent, bg = self.form_color_default, fg = 'gray')
        entry.insert(0, str(default) if default is not None else 'None')
        entry.grid(row=row, column=1, sticky="ew", padx=(2, 5), pady=2)

        # -- Allow the second column (the Entry field) to expand if the parent frame resizes:
        parent.grid_columnconfigure(1, weight=1)
        # -- Store this entry in the self.entries dictionary for later access:
        self.entries[label] = entry
        # -- Initialize the general defaults dictionary if it doesn't exist yet:
        if not hasattr(self, 'general_defaults'):
            self.general_defaults = {}
        # -- Save the default value for this parameter:
        self.general_defaults[label] = default
        # -- Add a listener to check for user edits:
        #    When the user changes the value, this will trigger color update:
        entry.bind(
            "<KeyRelease>",
            lambda event,
            e=entry,
            key=label: self.on_user_edit_general(e, key),
        )
        return entry

    def update_entry_color(self, entry: tk.Entry, default: Any) -> None:
        """
        Update the background color of an Entry widget based on whether
        the user has modified the value from its default.

        - Gray (lightgray): Value matches the default (not modified).
        - White: Value has been changed by the user.

        Args:
        ----------------------------
            entry (tk.Entry): The input field (Entry widget) to check.
            default (any): The default value to compare against.
        """
        if entry.get() == str(default):
            entry.configure(bg = self.form_color_default)
        else:
            entry.configure(bg = self.form_color_modif)

    def toggle_grid_fields(self) -> None:
        """
        Enable or disable the grid-related Entry fields depending on
        the state of the 'Grid Add' checkbox.

        - If 'Grid Add' is checked (True), the fields are enabled.
        - If unchecked (False), the fields are disabled (grayed out).

        This prevents user interaction with grid settings when they are
        not supposed to be active.
        """
        state = 'normal' if self.grid_add_var.get() else 'disabled'
        for entry in self.grid_entries:
            entry.configure(state=state)

    def load_special_limits_csv(self, is_diff=False) -> None:
        """
        Load a CSV file containing 'title', 'vmin', and 'vmax' columns, and update the
        corresponding special limits in the GUI.

        Args:
        ----------------------------
            is_diff (bool, optional):
                If True, load difference-map limits (`maps_min_values_diff`, `maps_max_values_diff`);
                otherwise load standard-map limits (`maps_min_values`, `maps_max_values`).
                Defaults to False.

        Side Effects:
        ----------------------------
            - Updates `self.special_limits_data` with new min/max values.
            - Modifies GUI entry fields to reflect loaded values.
            - Displays message boxes for errors and success.
        """
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not file_path:
            return

        try:
            df = pd.read_csv(file_path)
            df.columns = [col.strip().lower() for col in df.columns]
            required_cols = {'title', 'vmin', 'vmax'}
            if not required_cols.issubset(df.columns):
                messagebox.showerror("Invalid CSV", "CSV must contain 'title', 'vmin', and 'vmax' columns.")
                return

            # Choose correct keys based on flag
            min_key = 'maps_min_values_diff' if is_diff else 'maps_min_values'
            max_key = 'maps_max_values_diff' if is_diff else 'maps_max_values'

            self.special_limits_data[min_key] = {}
            self.special_limits_data[max_key] = {}

            for _, row in df.iterrows():
                title = str(row['title']).strip()
                try:
                    vmin = float(row['vmin']) if str(row['vmin']).strip().lower() != 'none' else None
                    vmax = float(row['vmax']) if str(row['vmax']).strip().lower() != 'none' else None
                except ValueError:
                    messagebox.showerror("Invalid Value", f"Non-numeric vmin/vmax for title: {title}")
                    return

                self.special_limits_data[min_key][title] = vmin
                self.special_limits_data[max_key][title] = vmax

            # Update GUI entries with plain dict-like strings
            for field in [min_key, max_key]:
                if field in self.entries:
                    entry_value = str(self.special_limits_data[field])
                    self.entries[field].delete(0, tk.END)
                    self.entries[field].insert(0, entry_value)
                    self.entries[field].configure(bg=self.form_color_modif, fg='black')

            msg = "Diff" if is_diff else "Standard"
            messagebox.showinfo("Success", f"{msg} CSV loaded and limits updated.")

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load CSV: {str(e)}")

    def load_projection_options(self, event: Optional[tk.Event] = None) -> None:
        """
        Load projection-specific subplot configuration options into the GUI.

        This method:
        ----------------------------
          - Clears any existing subplot configuration fields.
          - Updates the `map_zoom2domain` entry for the selected projection.
          - Dynamically builds a labeled frame containing all subplot options and
            their editable parameters based on `self.default_subplot_values`.
          - Initializes each field with its default value and disables it until
            the corresponding subplot option is activated.
          - Binds events so that enabling a subplot option allows its parameters
            to be edited and tracked for modifications.

        Args:
        ----------------------------
            event (Optional[tk.Event], optional):
                The Tkinter event triggering this function, typically from a projection
                type combobox selection. Defaults to None when called programmatically.

        Side Effects:
        ----------------------------
            - Updates `self.entries` with the `map_zoom2domain` entry.
            - Creates/updates `self.subplots_frame`, `self.subplot_vars`, and
              `self.subplot_param_entries` for interactive subplot configuration.
            - Displays a message box indicating which projection options were loaded.
        """
        # -- Clear previous widgets if they exist:
        if hasattr(self, 'subplots_frame'):
            self.subplots_frame.destroy()
        # -- Projection type:
        projection = self.proj_type.get()

        # Remove previous map_zoom2domain if exists
        if hasattr(self, 'map_zoom_entry'):
            self.map_zoom_label.destroy()
            self.map_zoom_entry.destroy()

        # Create label and entry dynamically
        self.map_zoom_label = tk.Label(self.proj_frame, text="map_zoom2domain:")
        self.map_zoom_label.grid(row=1, column=0, sticky="e")
        self.map_zoom_entry = tk.Entry(
            self.proj_frame,
            bg = self.form_color_default)
        self.map_zoom_entry.insert(0, self.default_subplot_values[projection]['map_zoom2domain'])

        self.map_zoom_entry.default_value = self.default_subplot_values[projection]['map_zoom2domain']
        self.map_zoom_entry.grid(row=1, column=1)
        self.entries['map_zoom2domain'] = self.map_zoom_entry
        self.map_zoom_entry.bind(
            "<KeyRelease>",
            lambda event,
            e=self.map_zoom_entry,
            key='map_zoom2domain': self.on_user_edit_general(e, key),
        )

        self.entries['map_zoom2domain'].delete(0, tk.END)
        self.entries['map_zoom2domain'].insert(0, self.default_subplot_values[projection]['map_zoom2domain'])

        # -- Define subplot options for each projection type:
        subplot_options = list(self.default_subplot_values[projection].keys())

        # -- Remove 'map_zoom2domain' from options if it exists:
        if 'map_zoom2domain' in subplot_options:
            subplot_options.remove('map_zoom2domain')
        # -- Get all possible parameters associated with subplots: (assuming consistent structure)
        subplot_params = list(
            self.default_subplot_values[projection][subplot_options[0]].keys())

        # -- Create subplots frame:
        self.subplots_frame = ttk.LabelFrame(self.root, text="Subplot Options")
        self.subplots_frame = ttk.LabelFrame(self.frame, text="Subplot Options")
        self.subplots_frame.grid(row=4, column=0, sticky="nsew", padx=10, pady=5)
        btn = tk.Button(
            self.subplots_frame,
            text="?",
            command=lambda: self.show_info(section="subplots")
        )
        btn.grid(row=0, column=len(self.default_subplot_values) + 4, padx=5, pady=2)
        self.subplot_vars = {}
        self.subplot_param_entries = {}

        for idx, option in enumerate(subplot_options):
            var = tk.BooleanVar()
            chk = ttk.Checkbutton(
                self.subplots_frame,
                text=option,
                variable=var,
                command=lambda opt=option: self.toggle_subplot_params(opt),
            )
            chk.grid(row=0, column=idx)
            self.subplot_vars[option] = var
            # -- Create parameter entries for this subplot option but keep them
            #    disabled initially
            self.subplot_param_entries[option] = {}
            for p_idx, param in enumerate(subplot_params):
                # -- Show labels only in the first column (idx == 0)
                if idx == 0:
                    label = tk.Label(self.subplots_frame, text=f"{param}:")
                    label.grid(row=p_idx + 1, column=0, sticky="e")
                # -- Entry fields always appear in every column
                entry = tk.Entry(
                    self.subplots_frame,
                    state='disabled',
                    bg=self.form_color_default,
                )
                entry.grid(row=p_idx + 1, column=idx + 1, padx=(5, 15))
                self.subplot_param_entries[option][param] = entry

            # -- Insert default values into each entry:
            defaults = self.default_subplot_values[projection].get(option, {})
            for param, entry in self.subplot_param_entries[option].items():
                if param in defaults:
                    entry.configure(state='normal')
                    value = defaults[param]
                    if isinstance(value, list):
                        # Convert list to string like '[1, 2, 3]':
                        value_str = str(value)
                    elif value is None:
                        value_str = 'None'
                    else:
                        value_str = str(value)
                    entry.insert(0, value_str)
                    entry.configure(state='disabled', bg=self.form_color_default)
        messagebox.showinfo(
            "Projection Loaded",
            f"Loaded subplot options for: {projection}"
        )

    def toggle_subplot_params(self, option: str) -> None:
        """
        Enable or disable subplot parameter fields based on the checkbox state.

        Args:
        ----------------------------
            option (str): The name of the subplot configuration (e.g., 'single', 'r1c4', etc.).

        Behavior:
        ----------------------------
            - When the checkbox for a subplot option is active (checked),
              the related entry fields are enabled (editable) and initially gray.
            - When unchecked, the fields are disabled (grayed out and uneditable).
            - Adds/removes key event bindings to detect changes in active fields.
        """
        # -- Main part
        active = self.subplot_vars[option].get()
        for param, entry in self.subplot_param_entries[option].items():
            if active:
                entry.configure(state='normal', bg = self.form_color_default)
                # -- Bind event to detect manual changes and turn white:
                entry.bind(
                    "<KeyRelease>",
                    lambda event,
                    e=entry,
                    opt=option,
                    p=param: self.on_user_edit(e, opt, p)
                )
            else:
                entry.configure(state='disabled', bg = self.form_color_default)
                # -- Remove the binding if checkbox is off
                entry.unbind("<KeyRelease>")

    def on_user_edit(self, entry: tk.Entry, option: str, param: str) -> None:
        """
        Detects changes in subplot parameter fields and updates their background color.

        Args:
        ----------------------------
            entry (tk.Entry): The Entry widget being edited.
            option (str): The subplot configuration name (e.g., 'single', 'r1c4').
            param (str): The specific parameter being edited
                  (e.g., 'map_size', 'map_cbar').

        Behavior:
        ----------------------------
            - If the current value differs from the default value, set background
                 to white (indicating user modification).
            - If the current value matches the default, keep the background gray.
        """
        default_value = self.default_subplot_values[self.proj_type.get()].get(option, {}).get(param)
        current_value = entry.get()
        # --If changed from default, turn white, else keep gray
        if str(current_value) != str(default_value):
            entry.configure(bg = self.form_color_modif)
        else:
            entry.configure(bg = self.form_color_default)

    def on_user_edit_general(self, entry: tk.Entry, key: str) -> None:
        """
        Detects changes in general (non-subplot) fields and updates their background and text color.

        Args:
        ----------------------------
            entry (tk.Entry): The Entry widget being edited.
            key (str): The parameter name (e.g., 'map_tolerance', 'map_colorbar').

        Behavior:
        ----------------------------
            - If the current value differs from the default value,
              set background to white and text color to black (indicating user modification).
            - If unchanged, background remains light gray and text color is gray.
        """
        default_value = self.general_defaults.get(key)
        current_value = entry.get()
        if str(current_value) != str(default_value):
            entry.configure(bg = self.form_color_modif, fg = 'black')
        else:
            entry.configure(bg = self.form_color_default, fg = 'gray')

    def debug_compare_with_defaults(self) -> None:
        """
        Debugging function to compare current GUI state with default settings.
        It activates all fields, reads their values, and compares with defaults.
        """
        # -- Ensure projection is selected:
        if not self.proj_type.get():
            print("No projection type selected. Setting default 'copat2_LambertConformal'.")
            self.proj_type.set("copat2_LambertConformal")
        # -- Check if subplots are loaded — if not, load them!
        if not hasattr(self, 'subplot_vars'):
            self.load_projection_options()
        # -- Activate all subplot options for comparison:
        for option, var in self.subplot_vars.items():
            var.set(True)
            self.toggle_subplot_params(option)
        # -- Check General Settings:
        for key, entry in self.entries.items():
            current_value = entry.get()
            if key == 'map_zoom2domain':
                projection = self.proj_type.get()
                default_value = self.default_subplot_values[projection]['map_zoom2domain']
            else:
                default_value = self.general_defaults.get(key)
                # Use the new normalize function here:
            if not self.normalize_value(key, current_value, default_value):
                print(
                    f"[General] Mismatch in '{key}': Current='{current_value}' | Default='{default_value}'")

        # -- Check Subplot Settings:
        projection = self.proj_type.get()
        for option, params in self.subplot_param_entries.items():
            defaults = self.default_subplot_values.get(projection, {}).get(option, {})
            for param, entry in params.items():
                current_value = entry.get()
                default_value = defaults.get(param)
                if str(current_value) != str(default_value):
                    print(f"[{option}] Mismatch in '{param}': Current='{current_value}' | Default='{default_value}'")

    def normalize_value(
        self,
        key: str,
        current_value: Any,
        default_value: Any,
    ) -> bool:
        """
        Compare a current GUI field value against its default, normalizing formats
        for certain parameter types before comparison.

        Normalization rules:
        ----------------------------
          - Boolean defaults: Convert `current_value` to bool from string/int form
            (e.g., "1" -> True) before comparison.
          - 'map_zoom2domain': Convert `current_value` to a list of floats and compare
            to the default list.
          - All other types: Compare string representations directly.

        Args:
        ----------------------------
            key (str):
                The parameter name (used to determine special normalization rules).
            current_value (Any):
                The current value from the GUI entry.
            default_value (Any):
                The reference default value for this parameter.

        Returns:
        ----------------------------
            bool:
                True if `current_value` matches `default_value` after normalization,
                False otherwise.
        """
        # -- Handle booleans (grid_add, x_inline, y_inline):
        if isinstance(default_value, bool):
            str_val = str(current_value).strip().lower()
            if str_val in ("1", "true", "yes", "on"):
                return default_value
            if str_val in ("0", "false", "no", "off"):
                return not default_value
            # If it’s something unexpected, treat as mismatch
            return False

        # -- Handle map_zoom2domain (convert string to list of floats):
        if key == 'map_zoom2domain':
            try:
                current_list = [float(v) for v in current_value.replace(',', ' ').split()]
                return current_list == default_value
            except Exception:
                return False
        # -- Default string comparison:
        return str(current_value) == str(default_value)

    def restore_default_values(self) -> None:
        """
        Resets all GUI entries and subplot fields to their original default values.
        """
        for key, entry in self.entries.items():
            default = self.general_defaults.get(key)
            entry.configure(state='normal')
            entry.delete(0, tk.END)
            entry.insert(0, str(default) if default is not None else "")
            entry.configure(bg=self.form_color_default, fg='gray')

        # Reset grid checkbox
        self.grid_add_var.set(True)
        self.toggle_grid_fields()

        # Reset projection combo (if exists)
        if hasattr(self, 'proj_type') and hasattr(self, 'default_subplot_values'):
            projection = list(self.default_subplot_values.keys())[0]
            self.proj_type.set(projection)
            self.load_projection_options()

        # Reset subplot fields
        if hasattr(self, 'subplot_vars'):
            for option, var in self.subplot_vars.items():
                var.set(False)
                self.toggle_subplot_params(option)
                for param, entry in self.subplot_param_entries[option].items():
                    default_val = self.default_subplot_values[projection][option].get(param)
                    entry.configure(state='disabled')
                    entry.delete(0, tk.END)
                    entry.insert(0, str(default_val) if default_val is not None else "")
                    entry.configure(bg=self.form_color_default, fg='gray')

        messagebox.showinfo("Defaults Restored", "All settings have been reset to their default values.")

    def clean_input_value(self, value: str) -> str:
        """
        Cleans the input string by:
        ----------------------------
            - Removing leading/trailing spaces.
            - Removing spaces after '(' and before ')'.
            - Removing spaces around commas.

        Args:
        ----------------------------
            value (str): The input string to clean.

        Returns:
        ----------------------------
            str: The cleaned string.
        """
        # -- If not a string, return as-is:
        if not isinstance(value, str):
            return value
        # -- Strip leading and trailing whitespace:
        value = value.strip()
        # -- Remove spaces after '(':
        value = re.sub(r'\(\s*', '(', value)
        # -- Remove spaces before ')':
        value = re.sub(r'\s*\)', ')', value)
        # -- Remove spaces around commas:
        value = re.sub(r'\s*,\s*', ',', value)
        return value

    def save_settings(self) -> None:
        """
        Save the user-modified settings into a YAML file.
        Only fields that are modified (white background) are included.
        Cleans string values to remove extra spaces before saving.
        """
        # -- General settings (only white fields)
        general_settings = {}
        for key, entry in self.entries.items():
            # -- Skip map_zoom2domain here (belongs to projection settings!):
            if key == 'map_zoom2domain':
                continue
            # -- Check if the field was modified:
            if entry.cget('bg') == self.form_color_modif:
                val = entry.get()
                # -- Clean string inputs:
                if isinstance(val, str):
                    val = self.clean_input_value(val)
                if key.startswith("maps_") and key not in ["maps_subtitle", "maps_title"] or key == "map_colorbar":
                    try:
                        parsed_val = eval(val)
                    except Exception:
                        parsed_val = val
                    general_settings[key] = parsed_val
                # -- Try to cast numbers if possible:
                else:
                    try:
                        general_settings[key] = float(val) if "." in val else int(val)
                    except ValueError:
                        if key in ["maps_subtitle", "maps_title"]:
                            general_settings[key] = [v.strip() for v in val.split(',') if v.strip()]
                        else:
                            general_settings[key] = val
        # -- Check if grid_add differs from the default (True)
        if self.grid_add_var.get() is not True:
            general_settings['grid_add'] = self.grid_add_var.get()
        projection = self.proj_type.get()
        projection_settings = {}
        # -- Always add map_zoom2domain only if the field is white:
        zoom_entry = self.entries.get("map_zoom2domain")
        if zoom_entry and zoom_entry.cget('bg') == self.form_color_modif:
            zoom_value = zoom_entry.get()
            zoom_value = self.clean_input_value(zoom_value)
            try:
                # -- Correctly parse input into a list of floats/ints:
                zoom_list = [float(v) if "." in v else int(v) for v in zoom_value.replace(",", " ").split()]
                projection_settings['map_zoom2domain'] = zoom_list
            except ValueError:
                # -- If parsing fails, save as string (safety net):
                projection_settings['map_zoom2domain'] = zoom_value
        # -- Add active subplot options with only white fields:
        if hasattr(self, 'subplot_vars'):
            for option, var in self.subplot_vars.items():
                # -- Only active subplots:
                if var.get():
                    subplot_params = {}
                    for param, entry in self.subplot_param_entries[option].items():
                        # -- Only user-edited fields:
                        if entry.cget('bg') == self.form_color_modif:
                            val = entry.get()
                            val = self.clean_input_value(val)
                            # -- Handle list parsing or keep string:
                            if val.startswith("[") and val.endswith("]"):
                                try:
                                    parsed_val = eval(val)
                                except Exception:
                                    parsed_val = val
                            else:
                                try:
                                    parsed_val = float(val) if "." in val else int(val)
                                except ValueError:
                                    parsed_val = val
                            subplot_params[param] = parsed_val
                    # -- Only add if something was modified:
                    if subplot_params:
                        projection_settings[option] = subplot_params
        # -- Combine general and projection-specific settings:
        final_settings = {}
        if general_settings:
            final_settings.update(general_settings)
        if projection_settings:
            final_settings[projection] = projection_settings
        # -- Case without changes:
        if not final_settings:
            messagebox.showinfo("No Changes", "No modified settings to save!")
            return
        # -- Save to YAML:
        file_path = filedialog.asksaveasfilename(
            defaultextension=".yaml",
            filetypes=[("YAML files", "*.yaml")]
        )
        if file_path:
            with open(file_path, 'w') as file:
                yaml.dump(final_settings, file, sort_keys=False)
            messagebox.showinfo("Success", f"Settings saved to {file_path}")

    def save_defaults_to_yaml(self) -> None:
        """
        Save the current default configuration into a YAML file for later comparison.
        Applies cleaning to string values before saving (removes extra spaces).
        """
        # --- Check for modified fields ---
        for entry in self.entries.values():
            if entry.cget('bg') == self.form_color_modif:
                messagebox.showerror(
                    "Aborted",
                    "Some fields have been modified.\nUse 'Save Settings' to export custom changes."
                )
                return
        # -- Prepare the defaults dictionary:
        defaults_to_save = {}
        # -- General defaults:
        for key, default_value in self.general_defaults.items():
            cleaned_value = default_value
            if isinstance(cleaned_value, str):
                cleaned_value = self.clean_input_value(cleaned_value)
            defaults_to_save[key] = cleaned_value
        # -- Always save 'grid_add' (for defaults YAML):
        if hasattr(self, 'grid_add_var'):
            defaults_to_save['grid_add'] = self.grid_add_var.get()
        # -- Projection-specific defaults:
        for projection, proj_data in self.default_subplot_values.items():
            proj_section = {}
            zoom_value = proj_data.get('map_zoom2domain')
            if zoom_value:
                # -- Clean zoom domain if it's a string:
                proj_section['map_zoom2domain'] = (
                    self.clean_input_value(zoom_value)
                    if isinstance(zoom_value, str)
                    else zoom_value
                )
            for option, params in proj_data.items():
                if option == 'map_zoom2domain':
                    continue
                subplot_section = {}
                for param, value in params.items():
                    if isinstance(value, str):
                        value = self.clean_input_value(value)
                    subplot_section[param] = value
                proj_section[option] = subplot_section
            defaults_to_save[projection] = proj_section
        # -- Write to YAML file:
        file_path = filedialog.asksaveasfilename(defaultextension=".yaml", filetypes=[("YAML files", "*.yaml")])
        if file_path:
            with open(file_path, 'w') as file:
                yaml.dump(defaults_to_save, file, sort_keys=False)
            messagebox.showinfo("Success", f"Default configuration saved to {file_path}")

    def show_info(self, section: Optional[str] = None) -> None:
        """
        Displays context-specific help information for each parameter group in the GUI.

        Parameters:
        -----------
        section : str, optional
            The section name that determines which help message to show.
            Options: 'general', 'cartopy', 'grid', 'projection', 'subplots'.
        """
        if section == "general":
            messagebox.showinfo(
                "Info for General Settings",
                "Explanation of General Plot Parameters:\n\n"
                "• map_tolerance:\n"
                "  Value that controls tolerance for contour levels in plots.\n"
                "  Example: 0.05 → defines contour step behavior.\n\n"
                "• map_colorbar:\n"
                "  Colormaps used for the plots (e.g., 'tas':'Spectral_r', 'hfls':'viridis').\n\n"
                "• map_colorbar_diff:\n"
                "  Colormap for difference plots (e.g., 'seismic').\n\n"
                "• map_colorbar_orientation / map_colorbar_orientation_diff:\n"
                "  Orientation of the colorbar: 'horizontal' or 'vertical'.\n"
                "  Can be set separately for regular and difference plots.\n\n"
                "• map_colorbar_extend / map_colorbar_extend_diff:\n"
                "  Controls how colorbars handle out-of-bound values:\n"
                "  Options: 'neither', 'both', 'min', 'max'.\n\n"
                "• map_extend_ticks_manual: Extend colorbar ticks to ensure :\n"
                "  that both vmin and vmax are included as ticks.\n\n"
                "• map_nan_colors: special color for NaN values. \n\n"
                "• map_lamb_center_lon: center of lambert projection. Important with\n"
                "  copat2_LambertConformal projection. \n\n"
                "• map_lamb_center_lat: center of lambert projection. Important with\n"
                "  copat2_LambertConformal projection. \n\n"
                "• map_pole_longitude: center of rotated projection. Important with \n"
                "  ICON (rlat and rlon data or for RotatedPole projection). \n\n"
                "• map_pole_latitude: center of rotated projection. Important with \n"
                "  ICON (rlat and rlon data or for RotatedPole projection). \n\n"
                "• map_format:\n"
                "  Output file format (e.g., 'png', 'pdf', 'jpg').\n\n"
                "• map_dpi:\n"
                "  Resolution of the saved plot (Dots Per Inch).\n"
                "  Higher DPI provides better quality but increases file size.\n\n"
            )
        elif section == "special":
            messagebox.showinfo(
                "Info for Special Parameters",
                "Explanation of Special Parameters:\n\n"
                "• maps_title:\n"
                "  List of titles corresponding to each parameter (e.g., BIASmean, BIASnorm). Must be a list of strings\n"
                "  like COSMO, ICON — without brackets ([]). If set, overrides the automatic titles from the NetCDF attributes.\n\n"
                "• maps_subtitle:\n"

                "  List of subtitles for each subplot or region (e.g., A, B, C or COSMO, ICON, CLM). Must be a list of strings,\n"
                "  comma-separated, without brackets. If mismatched in length, the default subtitles will be used.\n\n"
                "• maps_min_values / maps_max_values:\n"

                "  Manual override for colorbar scaling. Provide as dictionaries in the form:\n"
                "    { 'parameter_name, season': vmin or vmax }\n"
                "  Use only if exact colorbar limits are needed for consistent visual comparison (e.g., across phases).\n\n"
                "• maps_min_values_diff / maps_max_values_diff:\n"
                "  Same format as above, but for difference plots. Useful when emphasizing symmetric or absolute value changes."
            )
        elif section == "cartopy":
            messagebox.showinfo(
                "Info for Cartopy Layers Properties",
                "Explanation of Cartopy Layer Parameters:\n\n"
                "• coast_resolution:\n"
                "  Resolution of the coastlines ('10m', '50m', '110m').\n\n"
                "• coast_lw:\n"
                "  Line width of the coastlines.\n\n"
                "• coast_lc:\n"
                "  Line color of the coastlines.\n\n"
                "• ocean_color:\n"
                "  Fill color of the ocean areas (e.g., 'white').\n\n"
                "• ocean_zorder:\n"
                "  Drawing order for the ocean layer (higher zorder draws on top).\n\n"
                "• land_color:\n"
                "  Fill color for land areas (e.g., 'sienna').\n\n"
                "• land_zorder:\n"
                "  Drawing order for the land layer.\n\n"
                "• land_lw:\n"
                "  Line width for land boundaries (e.g., islands).\n\n"
                "• land_edgecolor:\n"
                "  Edge color for land boundaries.\n\n"
                "• land_alpha:\n"
                "  Transparency of the land layer (0.0 = fully transparent, 1.0 = fully opaque)."
            )
        elif section == "grid":
            messagebox.showinfo(
                "Info for Grid Properties",
                "Explanation of Grid Parameters:\n\n"
                "• grid_add:\n"
                "  Enables (True) or disables (False) the grid overlay.\n\n"
                "• grid_lw:\n"
                "  Line width of the grid lines.\n\n"
                "• grid_color:\n"
                "  Color of the grid lines (e.g., 'gray').\n\n"
                "• grid_alpha:\n"
                "  Transparency of the grid lines (0.0 to 1.0).\n\n"
                "• grid_x_inline / grid_y_inline:\n"
                "  Whether grid labels for X and Y lines are placed inline on the axis.\n\n"
                "• grid_xlocs / grid_ylocs:\n"
                "  Defines grid line locations (e.g., 'range(-180, 180, 15)').\n"
                "  Supports Python 'range' or list of values."
            )
        elif section == "projection":
            messagebox.showinfo(
                "Info for Projection Settings",
                "Projection configuration:\n\n"
                "• Select the projection type (e.g., LambertConformal, PlateCarree).\n"
                "• map_zoom2domain: Defines the zoomed area (e.g., [xmin, xmax, ymin, ymax]).\n"
                "• Subplot options become available after selecting the projection."
            )
        elif section == "subplots":
            messagebox.showinfo(
                "Info for Subplot Options",
                "Explanation of Subplot Parameters:\n\n"
                "• Subplot Layouts:\n"
                "  Options like 'single', 'r1c4', etc., define subplot arrangement.\n\n"
                "• map_size:\n"
                "  Figure size as [width, height] in inches.\n\n"
                "• map_cbar:\n"
                "  Location of the colorbar as a list: [x, y, width, height].\n\n"
                "• map_cbar_n1c2 / map_cbar_diff / map_cbar_n1c3:\n"
                "  Colorbar locations for different subplot configurations.\n"
                "  (Use None if not applicable for the selected layout.)\n\n"
                "• map_ncols / map_nrows:\n"
                "  Number of columns and rows for subplot grids.\n\n"
                "• map_wspace / map_hspace:\n"
                "  Horizontal and vertical space between subplots.\n\n"
                "• map_title_loc:\n"
                "  Title position as [x, y, alignment ('left', 'center'), font size].\n\n"
                "• map_title_pad / map_title_fsize:\n"
                "  Padding and font size for the plot title.\n\n"
                "• map_label_pad / map_label_fsize / map_label_rotation:\n"
                "  Padding, font size, and rotation angle for axis labels."
            )
        else:
            messagebox.showinfo("Info", "No section selected or recognized for help.")


if __name__ == "__main__":
    root = tk.Tk()
    app = MapSettingsGUI(root)
    root.mainloop()
