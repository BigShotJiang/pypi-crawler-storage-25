# Evaluation Suite (EvaSuite)
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2026, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------
import functools
import warnings
import numpy as np
import xarray as xr
import xskillscore as xskill
from typing import Optional, Callable, List
from hereon_evasuite.log_EvaSuite import get_logger
logger = get_logger()


def validate_inputs_with_warning(require_coordxy=False, require_coordtime=False):
    """
    Decorator to validate inputs and emit WARNING-ERROR messages without altering behavior.

    Parameters:
    ----------------------------
    - require_coordxy (bool): Whether coordxy must be explicitly provided.
    - require_coordtime (bool): Whether coordtime must be explicitly provided.
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(x, daproof, daref, coordtime=None, coordxy=None, option=None):
            fname = func.__name__
            # -- Quality control of input dataset:
            if not isinstance(x, xr.Dataset):
                raise TypeError(f"{fname}: 'x' must be an xarray.Dataset.")

            # -- Quality control of input daproof and daref variables:
            for varname, varval in [("daproof", daproof), ("daref", daref)]:
                if not isinstance(varval, str):
                    raise TypeError(f"{fname}: '{varname}' must be a string.")
                if varval not in x.data_vars:
                    raise KeyError(
                        f"{fname}: '{varname}'='{varval}' not found in dataset"
                        f" variables {list(x.data_vars)}.")

            if x[daproof].shape != x[daref].shape:
                warnings.warn(
                    f"WARNING-ERROR: {fname}: Input arrays must have the same shape.",
                    UserWarning
                )

            # -- Quality control of coordxy variable:
            if require_coordxy:
                if coordxy is None:
                    warnings.warn(
                        f"WARNING-ERROR: {fname}: 'coordxy' must be provided.",
                        UserWarning
                    )
                elif isinstance(coordxy, list) and len(coordxy) == 0:
                    raise ValueError(
                        f"{fname}: 'coordxy' must contain at least one coordinate name."
                    )

            if coordxy is not None:
                if not isinstance(coordxy, list):
                    warnings.warn(
                        f"WARNING-ERROR: {fname}: 'coordxy' must be a list of coordinate names.",
                        UserWarning
                    )
                else:
                    for dim in coordxy:
                        if not isinstance(dim, str):
                            raise ValueError(
                                f"{fname}: 'coordxy' contains non-string item: {dim!r}.")
                        elif dim not in x.dims:
                            raise ValueError(
                                f"{fname}: 'coordxy' entry '{dim}' not found"
                                f" in dataset dimensions {list(x.dims)}.")

            # -- Quality control of coordtime variable:
            if require_coordtime:
                if coordtime is None:
                    warnings.warn(
                        f"WARNING-ERROR: {fname}: 'coordtime' must be provided.",
                        UserWarning
                    )

            if coordtime is not None:
                if not isinstance(coordtime, str):
                    raise ValueError(
                        f"{fname}: 'coordtime' must be a string when required."
                    )
                elif coordtime not in x.dims:
                    raise ValueError(
                        f"{fname}: 'coordtime'='{coordtime}' not found in"
                        f" dataset dimensions {list(x.dims)}.")

            return func(x, daproof, daref, coordtime, coordxy, option)
        return wrapper
    return decorator


class JESSupport:
    """
    Utilities for Jolliffe–Ebert (JE) half-width CI significance tests
    with consistent diagnostics and chunk-safe handling.

    This class centralizes the common logic used by:
      - TbiasdiffJESmean  (metric='me')
      - TrmsediffJESmean  (metric='rmse')

    It computes the JE significance for the difference between two forecasts
    (daproof vs daskillref) relative to a common truth (daref), using
    xskill.halfwidth_ci_test. It returns a mask with:
        +1  -> proof is significantly better than ref
        -1  -> proof is significantly worse than ref
         0  -> not significant
        NaN -> undefined (missing)
    """
    def __init__(self):
        pass

    def _summarize_metric(
        self,
        forecast: xr.DataArray,
        truth: xr.DataArray,
        coordtime: str,
        metric: str
    ) -> xr.DataArray:
        """
        Summarize a forecast-vs-truth error over time for a given metric.

        Parameters
        ----------
        forecast : xr.DataArray
            Forecast field.
        truth : xr.DataArray
            Reference / truth field.
        coordtime : str
            Name of the time dimension.
        metric : {'me','rmse'}
            'me'   -> mean error (bias) over time
            'rmse' -> root-mean-square error over time

        Returns
        -------
        xr.DataArray
            (rlat, rlon) field of the chosen error summary.
        """
        if metric == "me":
            # mean error (bias)
            return (forecast - truth).mean(dim=coordtime)
        elif metric == "rmse":
            # root-mean-square error
            se = (forecast - truth) ** 2
            return np.sqrt(se.mean(dim=coordtime))
        else:
            raise ValueError(f"Unsupported metric '{metric}'. Use 'me' or 'rmse'.")

    def jes_sig_generic(
        self,
        *,
        x: xr.Dataset,
        daproof: str,
        daskillref: str,
        daref: str,
        coordtime: str,
        metric: str,
        alpha: float,
        compute: bool,
        caller_name: str,
    ) -> xr.DataArray:
        """
        Jolliffe–Ebert half-width CI test (generic).

        Parameters
        ----------
        x : xr.Dataset
            Input dataset containing daproof, daskillref, daref variables.
        daproof : str
            Name of the forecast-under-test variable in `x`.
        daskillref : str
            Name of the benchmark/reference-forecast variable in `x`.
        daref : str
            Name of the truth/observation variable in `x`.
        coordtime : str
            Time dimension name.
        metric : {'me','rmse'}
            Error metric for JE test: 'me' (bias) or 'rmse'.
        alpha : float
            Significance level (e.g., 0.05).
        compute : bool
            If True, trigger dask.compute on the final mask (and intermediates from JE).
        caller_name : str
            Name used in log/diagnostics.
        logger : logging.Logger | None
            Optional logger. If None, prints will be used.

        Returns
        -------
        xr.DataArray
            Significance mask (+1, -1, 0, NaN) with (rlat, rlon) dims.
        """
        import time
        import psutil
        import dask

        # --- diagnostics start
        start_time = time.time()
        process = psutil.Process()
        mem_before = process.memory_info().rss / 1024**2
        peakmem_start = psutil.virtual_memory().used / 1024**2
        nslices = x[coordtime].size if coordtime in x.coords else 1

        logger.debug(f"\n========== [{caller_name}] START ==========")

        # -- Chunk overview
        for v in [daproof, daskillref, daref]:
            if hasattr(x[v], "chunks"):
                logger.debug(f"[{caller_name}]  - {v}: {x[v].chunks}")

        # --- JE half-width CI test
        # Returns: sign_diff (bool), diff, hwci (all broadcast to spatial dims)
        sign_diff, diff, hwci = xskill.halfwidth_ci_test(
            x[daproof], x[daskillref], x[daref],
            metric,
            time_dim=coordtime,
            dim=[],           # reduce time only
            alpha=alpha,
        )

        # Summaries for both forecasts, used to set sign of the mask
        summ_proof = self._summarize_metric(x[daproof], x[daref], coordtime, metric)
        summ_ref = self._summarize_metric(x[daskillref], x[daref], coordtime, metric)

        # --- Build significance mask:
        # +1 if proof better (smaller magnitude), -1 if worse, 0 if not significant, NaN if undefined.
        JEsigt = xr.where(
            (np.abs(summ_proof) < np.abs(summ_ref)) & (sign_diff), 1.0, np.nan
        )
        JEsigt = xr.where(
            (np.abs(summ_proof) > np.abs(summ_ref)) & (sign_diff), -1.0, JEsigt
        )
        JEsigt = xr.where(~sign_diff, 0.0, JEsigt)
        JEsigt = JEsigt.where(summ_proof.notnull() & summ_ref.notnull())

        # Optional compute
        if compute:
            logger.debug(f"[{caller_name}] Computing full JE significance mask...")
            JEsigt = dask.compute(JEsigt)[0]

        # --- diagnostics end
        elapsed = time.time() - start_time
        mem_after = process.memory_info().rss / 1024**2
        peakmem_after = psutil.virtual_memory().used / 1024**2

        logger.debug(
            f"[{caller_name}] Time: {elapsed:.2f}s "
            f"| Mem used: {mem_after - mem_before:.2f}MB "
            f"| Peak used: {peakmem_after - peakmem_start:.2f}MB "
            f"| Slices: {nslices} | Computed: {compute}"
        )
        logger.info(f"========== [{caller_name}] END ==========")

        return JEsigt


class BSSBootstrap_support:
    def __init__(self, iterations: int = 250):
        self.iterations = iterations

    def _quantile_block(
        self,
        block: xr.DataArray,
        q: float,
        reduce_dim: str,
        template_dims: tuple[str, ...],
    ) -> xr.DataArray:
        """
        Block-wise quantile reducer (ragged-chunk safe).

        This is a helper passed into ``xr.map_blocks`` to compute quantiles across
        the bootstrap ``iteration`` dimension (or any chosen `reduce_dim`).
        It is designed to be *safe for irregular / ragged dask chunks* by:

          - Reducing along the given ``reduce_dim`` using ``np.nanquantile``.
          - Preserving coordinate values from the input block for all other dims.
          - Falling back to ``np.arange`` if coordinate length mismatches data length
            (common at ragged chunk boundaries).
          - Transposing the result into the canonical dimension order specified by
            ``template_dims``.

        Parameters
        ----------
        block : xr.DataArray
            Input chunk (from ``map_blocks``). Must contain the reduction dimension.
        q : float
            Quantile to compute in [0, 1] (e.g., 0.025, 0.975).
        reduce_dim : str
            Name of the dimension along which to compute the quantile (e.g., "iteration").
        template_dims : tuple of str
            Target dimension order for the output, typically taken from the map_blocks template.

        Returns
        -------
        xr.DataArray
            Chunk-local quantile result with dimensions = ``template_dims``.
            Coordinates are carried over from the block if possible, otherwise
            replaced with simple integer ranges to avoid mismatch errors.
        """
        # -- Which axis we reduce:
        axis = block.get_axis_num(reduce_dim)
        data = np.nanquantile(block.data, q, axis=axis)

        # -- Dims/coords after reduction:
        dims_out = tuple(d for d in block.dims if d != reduce_dim)
        coords_out = {d: block[d].values for d in dims_out}

        # -- Sanity on coord lengths vs data lengths:
        for d in dims_out:
            d_len_coord = coords_out[d].shape[0]
            d_len_data = data.shape[dims_out.index(d)]
            if d_len_coord != d_len_data:
                logger.warning(
                    f"Coord length mismatch for {d}: coords={d_len_coord} vs data={d_len_data}"
                )
                coords_out[d] = np.arange(d_len_data)

        # -- Build DA:
        da_out = xr.DataArray(data, dims=dims_out, coords=coords_out)
        # -- Enforce canonical order (match template):
        return da_out.transpose(*template_dims)

    def _make_ragged_template(
        self,
        bspf: xr.DataArray,
        drop_dim: str = "iteration",
    ) -> xr.DataArray:
        """
        Build a ragged-chunk–safe template for ``xr.map_blocks``.

        This helper constructs an empty ``xarray.DataArray`` with the same
        shape, dimension names, chunking, and coordinates as ``bspf``
        **except** with the reduction dimension (e.g., "iteration") dropped.

        It ensures that map_blocks outputs have consistent dimension order
        and chunk structure, even when input dask chunks are irregular
        (ragged edges).

        Parameters
        ----------
        bspf : xr.DataArray
            Input bootstrap array, typically with dimensions
            (iteration, rlat, rlon) after time reduction.
        drop_dim : str, default="iteration"
            Dimension to remove when building the template (the one along
            which quantiles will be reduced).

        Returns
        -------
        xr.DataArray
            Empty ragged-safe template with:
              - dimensions = all dims of ``bspf`` except ``drop_dim``
              - dask array backend (``da.empty``) with matching chunk structure
              - coordinates inherited from ``bspf`` for remaining dimensions

        Notes
        -----
        This template is passed to ``xr.map_blocks`` so that the dispatcher
        knows the expected output structure of each block. Coordinates are
        preserved dimension-wise, but no actual data is stored.

        Example
        -------
        >>> template = _make_ragged_template(bspf, drop_dim="iteration")
        >>> template.dims
        ('rlat', 'rlon')
        >>> template.chunks
        ((55, 55, 55, 6), (55, 55, 55, 6))
        """
        import dask.array as da
        dims_out = tuple(d for d in bspf.dims if d != drop_dim)
        shape_out = tuple(bspf.sizes[d] for d in dims_out)
        chunks_out = tuple(bspf.chunks[bspf.get_axis_num(d)] for d in dims_out)

        for d, sh, ch in zip(dims_out, shape_out, chunks_out):
            logger.debug(f"  - {d}: shape={sh}, chunks={ch}")

        return xr.DataArray(
            da.empty(shape_out, chunks=chunks_out),
            dims=dims_out,
            coords={d: bspf[d] for d in dims_out},
        )

    def _get_spatial_dims(self, da: xr.DataArray) -> List[str]:
        """Identify spatial dimensions by excluding known non-spatial ones."""
        non_spatial = {"time", "iteration"}
        return [dim for dim in da.dims if dim not in non_spatial]

    def bss_sig_generic(
        self,
        *,
        x: xr.Dataset,
        arr_proof: xr.DataArray,
        arr_ref: xr.DataArray,
        coordtime: str,
        alpha: float,
        compute: bool,
        caller_name: str,
        reduce_op: str = "mean",
        post_reduce_transform: Optional[Callable[[xr.DataArray], xr.DataArray]] = None,
    ) -> xr.DataArray:
        """
        Core bootstrap significance testing pipeline for skill metrics.

        This method implements the generic steps for computing bootstrap-based
        confidence intervals and significance masks on differences of two
        candidate metrics (e.g., bias, MAE, MAD, RMSE).

        The function is designed to be *chunk-safe* (works with irregular / ragged
        dask chunking) and reusable across different metric types.

        Pipeline
        --------
        1. **Bootstrap resampling**: Resample both input arrays along `coordtime`
           using index resampling with replacement.
        2. **Reduce over time**: Apply `reduce_op` ("mean" or "median") along
           `coordtime` for each bootstrap replicate.
        3. **Optional transform**: Apply a post-reduction transform
           (e.g., `sqrt` for RMSE).
        4. **Difference of magnitudes**: Compute ``|proof| - |ref|``.
        5. **Quantiles**: Use ``xr.map_blocks`` + ragged-safe template to estimate
           bootstrap quantile bounds across the ``iteration`` dimension.
        6. **Significance mask**:
             - -1.0 → proof significantly worse
             - +1.0 → proof significantly better
             -  0.0 → not significant
             -  NaN → undefined / missing
        7. **Diagnostics**: Timing, memory use, chunk layout are logged.

        Parameters
        ----------
        x : xr.Dataset
            Original dataset, used for coordinate/time context and chunk diagnostics.
        arr_proof : xr.DataArray
            Candidate/proof error array (time, rlat, rlon) aligned to `coordtime`.
        arr_ref : xr.DataArray
            Reference error array (time, rlat, rlon) aligned to `coordtime`.
        coordtime : str
            Name of the time-like dimension along which bootstrapping is performed.
        alpha : float
            Significance level (e.g., 0.05 for 95% confidence intervals).
        compute : bool
            If True, immediately trigger computation (`dask.compute`).
            If False, return lazy dask-backed DataArray.
        caller_name : str
            Identifier used in logging (helps track different metric functions).
        reduce_op : {"mean", "median"}, default="mean"
            Reduction operation to apply across time per bootstrap sample.
        post_reduce_transform : callable, optional
            Transform applied *after* reduction, e.g. `np.sqrt` for RMSE.

        Returns
        -------
        xr.DataArray
            Significance mask array with shape (rlat, rlon), chunked safely,
            containing values {-1.0, 0.0, 1.0, NaN} as described above.

        Notes
        -----
        - This function is not normally called directly. Instead, it is wrapped
          by metric-specific frontends (e.g., `TbiasdiffBSSmean`, `TmaediffBSSmean`).
        - Supports ragged dask chunks and irregular edge sizes via
          `_make_ragged_template` + `_quantile_block`.

        Example
        -------
        >>> bss = BSSBootstrap_support()
        >>> sig = bss.bss_sig_generic(
        ...     x=ds,
        ...     arr_proof=ds["daproof"] - ds["daref"],
        ...     arr_ref=ds["daskillref"] - ds["daref"],
        ...     coordtime="time",
        ...     alpha=0.05,
        ...     compute=True,
        ...     caller_name="TbiasdiffBSSmean",
        ... )
        >>> sig.shape
        (100, 100)
        >>> sig.values
        array([[ 1.,  0., nan, ...], ...])
        """
        import time
        import psutil
        import dask

        # --- diagnostics start
        start_time = time.time()
        process = psutil.Process()
        mem_before = process.memory_info().rss / 1024**2
        peakmem_start = psutil.virtual_memory().used / 1024**2

        dimbs = "iteration"
        nslices = x[coordtime].size if coordtime in x.coords else 1

        logger.info(f"\n========== [{caller_name}] START ==========")

        # -- Chunk overview:
        for v in x.data_vars:
            if hasattr(x[v], "chunks"):
                logger.debug(f"[{caller_name}]  - {v}: {x[v].chunks}")

        # -- Bootstrap (iteration, time, rlat, rlon) → mean over time
        bsp1 = xskill.resample_iterations_idx(
            arr_proof, iterations=self.iterations, dim=coordtime, replace=True)
        bsp2 = xskill.resample_iterations_idx(
            arr_ref, iterations=self.iterations, dim=coordtime, replace=True)

        # -- Pick reducer
        if reduce_op == "mean":
            red = lambda da: da.mean(dim=coordtime)
        elif reduce_op == "median":
            red = lambda da: da.median(dim=coordtime)
        else:
            raise ValueError(f"[{caller_name}] reduce_op must be 'mean' or 'median', got: {reduce_op}")

        r1, r2 = red(bsp1), red(bsp2)

        # -- Optional transform (e.g., sqrt for RMSE):
        if post_reduce_transform is not None:
            r1, r2 = post_reduce_transform(r1), post_reduce_transform(r2)

        # -- Difference of magnitudes:
        bspf = np.abs(r1) - np.abs(r2)

        # -- Dim/chunk safety:
        spatial_dims = self._get_spatial_dims(bspf)
        if bspf.dims != (dimbs, *spatial_dims):
            logger.debug(f"[{caller_name}] Coordinates {spatial_dims}")
            logger.debug(f"[{caller_name}] Fixing bspf dim order from {bspf.dims}")
            bspf = bspf.transpose(dimbs, *spatial_dims)
        if dimbs in bspf.dims:
            bspf = bspf.chunk({dimbs: -1})

        logger.debug(f"[{caller_name}] bspf dims: {bspf.dims}, shape={bspf.shape}")
        logger.debug(f"[{caller_name}] bspf chunks: {bspf.chunks}")

        # -- Quantiles via ragged-safe template + map_blocks:
        template = self._make_ragged_template(bspf, drop_dim=dimbs)
        template_dims = tuple(template.dims)

        q_lo = alpha / 2.0
        q_hi = 1.0 - alpha / 2.0

        biaslb = xr.map_blocks(
            self._quantile_block, bspf,
            kwargs={"q": q_lo, "reduce_dim": dimbs, "template_dims": template_dims},
            template=template,
        )
        biasub = xr.map_blocks(
            self._quantile_block, bspf,
            kwargs={"q": q_hi, "reduce_dim": dimbs, "template_dims": template_dims},
            template=template,
        )

        logger.debug(f"[{caller_name}] biaslb chunks: {getattr(biaslb, 'chunks', None)}")
        logger.debug(f"[{caller_name}] biasub chunks: {getattr(biasub, 'chunks', None)}")

        # -- Significance mask:
        BSsigt = xr.where((biaslb > 0.0), -1.0, np.nan)
        BSsigt = xr.where((biasub < 0.0), 1.0, BSsigt)
        BSsigt = xr.where((biaslb < 0.0) & (biasub > 0.0), 0.0, BSsigt)
        BSsigt = BSsigt.where(biaslb.notnull())

        logger.debug(f"[{caller_name}] BSsigt chunks: {getattr(BSsigt, 'chunks', None)}")

        # -- Compute if requested:
        if compute:
            logger.debug(f"[{caller_name}] Computing full BSsigt graph...")
            biaslb, biasub, BSsigt = dask.compute(biaslb, biasub, BSsigt)

        # --- Diagnostics end
        elapsed = time.time() - start_time
        mem_after = process.memory_info().rss / 1024**2
        peakmem_after = psutil.virtual_memory().used / 1024**2

        logger.debug(
            f"[{caller_name}] Time: {elapsed:.2f}s "
            f"| Mem used: {mem_after - mem_before:.2f}MB "
            f"| Peak used: {peakmem_after - peakmem_start:.2f}MB "
            f"| Slices: {nslices} | Computed: {compute}"
        )
        logger.info(f"========== [{caller_name}] END ==========")

        return BSsigt

    def amsess_sig(
        self,
        *,
        x: xr.Dataset,
        arr_proof: xr.DataArray,   # residuals or fields to compare (time, rlat, rlon)
        arr_ref: xr.DataArray,     # residuals or fields to compare (time, rlat, rlon)
        coordtime: str,
        alpha: float,
        compute: bool,
        caller_name: str = "TamsessBSSmean",
    ) -> xr.DataArray:
        """
        Bootstrap significance test for AMSESS (Anomaly MSE Skill Score),
        safe for ragged dask chunks.

        Workflow:
        ----------
        1. Bootstrap resample `arr_proof` and `arr_ref` along `coordtime`.
        2. For each iteration:
             - Compute MSE_proof = mean_t((arr_proof)^2)
             - Compute MSE_ref   = mean_t((arr_ref)^2)
             - Ratio = MSE_ref / MSE_proof
             - AMSESS = 1 - max(Ratio, 1/Ratio)
                        (implemented piecewise as
                         AMSESS = Ratio - 1 if Ratio ≤ 1,
                                  -1/Ratio + 1 if Ratio > 1)
        3. Estimate bootstrap confidence interval across iterations:
             - Lower bound = q(alpha/2)
             - Upper bound = q(1 - alpha/2)
        4. Construct significance mask:
             +1 : significantly positive AMSESS
             -1 : significantly negative AMSESS
              0 : not significant
            NaN : undefined / missing

        Arguments:
        ----------
        x : xr.Dataset
            Input dataset containing the proof, reference, and skill-ref fields.
        arr_proof : xr.DataArray
            DataArray of proof residuals (time, rlat, rlon).
        arr_ref : xr.DataArray
            DataArray of reference residuals (time, rlat, rlon).
        coordtime : str
            Time coordinate name for bootstrap resampling.
        alpha : float
            Significance level (e.g., 0.05 for 95% CI).
        compute : bool
            If True, trigger full dask computation before returning.
        caller_name : str
            Used only for logging/debug output.

        Returns:
        --------
        xr.DataArray
            Significance mask with dims (rlat, rlon). Values:
              +1 : proof significantly better than reference
              -1 : proof significantly worse than reference
               0 : not significant
             NaN : undefined
        """
        import time
        import psutil
        import dask

        # --- diagnostics start
        start_time = time.time()
        process = psutil.Process()
        mem_before = process.memory_info().rss / 1024**2
        peakmem_start = psutil.virtual_memory().used / 1024**2

        dimbs = "iteration"
        nslices = x[coordtime].size if coordtime in x.coords else 1

        logger.info(f"\n========== [{caller_name}] START ==========")
        for v in x.data_vars:
            if hasattr(x[v], "chunks"):
                logger.debug(f"[{caller_name}]  - {v}: {x[v].chunks}")

        # -- Bootstrap residual (or field) arrays
        bsp1 = xskill.resample_iterations_idx(
            arr_proof, iterations=self.iterations, dim=coordtime, replace=True)
        bsp2 = xskill.resample_iterations_idx(
            arr_ref, iterations=self.iterations, dim=coordtime, replace=True)

        # -- MSE per iteration, then ratio ref/proof
        mse_proof = (bsp1 ** 2).mean(dim=coordtime)
        mse_ref = (bsp2 ** 2).mean(dim=coordtime)
        ratio = mse_ref / mse_proof

        # -- AMSESS per iteration (piecewise 1 - max(ratio, 1/ratio))
        amsess_iter = xr.where((ratio - 1.0) > 0.0, (-1.0) / ratio + 1.0, ratio - 1.0)
        # dims now: (iteration, rlat, rlon)

        # -- Dim/chunk safety
        spatial_dims = self._get_spatial_dims(amsess_iter)
        if amsess_iter.dims != (dimbs, *spatial_dims):
            logger.debug(f"[{caller_name}] Coordinates {spatial_dims}")
            logger.debug(f"[{caller_name}] Fixing dims from {amsess_iter.dims}")
            amsess_iter = amsess_iter.transpose(dimbs, *spatial_dims)
        if dimbs in amsess_iter.dims:
            amsess_iter = amsess_iter.chunk({dimbs: -1})

        logger.debug(f"[{caller_name}] amsess_iter dims: {amsess_iter.dims}, shape={amsess_iter.shape}")
        logger.debug(f"[{caller_name}] amsess_iter chunks: {amsess_iter.chunks}")

        # -- Quantiles (ragged-safe)
        template = self._make_ragged_template(amsess_iter, drop_dim=dimbs)
        template_dims = tuple(template.dims)
        q_lo, q_hi = alpha / 2.0, 1.0 - alpha / 2.0

        amsesslb = xr.map_blocks(
            self._quantile_block, amsess_iter,
            kwargs={"q": q_lo, "reduce_dim": dimbs, "template_dims": template_dims},
            template=template,
        )
        amsessub = xr.map_blocks(
            self._quantile_block, amsess_iter,
            kwargs={"q": q_hi, "reduce_dim": dimbs, "template_dims": template_dims},
            template=template,
        )

        logger.debug(f"[{caller_name}] amsesslb chunks: {getattr(amsesslb, 'chunks', None)}")
        logger.debug(f"[{caller_name}] amsessub chunks: {getattr(amsessub, 'chunks', None)}")

        # -- Significance mask: +1 / -1 / 0 / NaN
        amsessBS = xr.where((amsesslb) > 0.0, 1.0, np.nan)
        amsessBS = xr.where((amsessub) < 0.0, -1.0, amsessBS)
        amsessBS = xr.where((amsesslb < 0.0) & (amsessub > 0.0), 0.0, amsessBS)
        amsessBS = amsessBS.where(amsesslb.notnull())

        logger.debug(f"[{caller_name}] amsessBS chunks: {getattr(amsessBS, 'chunks', None)}")

        # -- Compute if requested
        if compute:
            logger.info(f"[{caller_name}] Computing full AMSESS significance graph...")
            amsesslb, amsessub, amsessBS = dask.compute(amsesslb, amsessub, amsessBS)

        # --- diagnostics end
        elapsed = time.time() - start_time
        mem_after = process.memory_info().rss / 1024**2
        peakmem_after = psutil.virtual_memory().used / 1024**2

        logger.debug(
            f"[{caller_name}] Time: {elapsed:.2f}s "
            f"| Mem used: {mem_after - mem_before:.2f}MB "
            f"| Peak used: {peakmem_after - peakmem_start:.2f}MB "
            f"| Slices: {nslices} | Computed: {compute}"
        )
        logger.info(f"========== [{caller_name}] END ==========")

        return amsessBS
