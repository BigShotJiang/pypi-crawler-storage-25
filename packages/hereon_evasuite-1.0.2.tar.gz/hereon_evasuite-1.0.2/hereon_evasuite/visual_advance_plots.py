# Evaluation Suite (EvaSuite)
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2026, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# ---------------------------------------------------------------
#    Program description:
#
#    History:
#    Version    Date       Name
#    ---------- ---------- ----
#    1.1     Mon Aug 11 13:46:54 2025   Evgenii Churiulin, IMKTRO
#                       Initial realise
# ---------------------------------------------------------------
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
import pandas as pd
from pathlib import Path
from typing import Optional, Literal, List, Tuple, Sequence, Union, Dict, List, cast, Any
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
from matplotlib.figure import Figure
from os import PathLike
from matplotlib.colors import Normalize, Colormap

logger = get_logger()


class ClimatePlotter:
    """
    Compact plotting helper for comparing a reference series against one or more
    model series across several common diagnostics (QQ variants and histograms).

    The class lays out panels in a grid (up to 4 columns per row), uses common
    axis limits/bins for fair comparison, and can export both figures and tidy
    CSVs (per-model and/or one combined file) with consistent naming.

    Options for visualization:
    -------
    Plot reference vs model(s) for:
      - qqplot_scatter (density scatter + QQ line)
      - qqplot (quantiles with optional bootstrap band)
      - hist (side/overlap/line modes)
      - percentiles_diff (model - ref)
      - qqplot_percentiles (values vs percentile)

    Options for export (only CSV):
    -------
      - csv_mode: "auto" (default) | "per-model" | "combined" | "both"
      - combine_threshold: switch to combined when >= this many models (only used in "auto")
      - csv_format: "long" (tidy, default)
    """
    @log_function_name
    def __init__(
        self,
        ref: np.ndarray,
        models: list[np.ndarray],
        labels: Optional[list[str]] = None,
        units: str = "",
        region: str = "",
        csv_mode: Optional[str] = "auto",
        combine_threshold: int = 6,
        csv_format: Optional[str] = "long"
    ) -> None:
        """
        Initialize a ClimatePlotter instance.

        Parameters
        ----------
        ref : np.ndarray
            Reference series (e.g., observations). Non-finite values are ignored in plots.
        models : list[np.ndarray]
            One or more model series to compare to `ref`.
        labels : Optional[list of str], default None
            Names for each model series. If ``None``, defaults to ["Model 1", "Model 2", ...].
        units : str, optional
            Physical units to display on plot axis labels (e.g., "K").
        region : str, optional
            Region identifier used in figure and CSV filenames.
        csv_mode : {"auto", "per-model", "combined", "both"}, default "auto"
            How to export CSV outputs:
              * "per-model" → separate CSV file for each model.
              * "combined"  → one CSV with a ``label`` column.
              * "both"      → export both formats.
              * "auto"      → choose per-model if number of models < `combine_threshold`,
                              otherwise use combined.
        combine_threshold : int, default 6
            Number of models at which "auto" switches from per-model to combined CSV output.
        csv_format : {"long"}, default "long"
            Output layout format for combined CSVs (currently only "long" is supported).

        Returns
        -------
        None
        """
        self.ref = np.asarray(ref, float)
        self.models = [np.asarray(m, float) for m in models]
        self.labels = labels if labels else [f"Model {i+1}" for i in range(len(models))]
        self.units = units
        self.region = region

        # -- Control of input mode:
        if csv_mode not in ("auto", "per-model", "combined", "both"):
            raise ValueError(f"Invalid csv_mode: {csv_mode}")

        self.csv_mode = csv_mode
        self.combine_threshold = combine_threshold
        self.csv_format = csv_format

    # ---------- helpers ----------
    @log_function_name
    def _finite(self, arr: np.ndarray) -> np.ndarray:
        """
        Return only the finite (non-NaN, non-infinite) values from an array.

        Parameters
        ----------
        arr : np.ndarray
            Input data array.

        Returns
        -------
        np.ndarray
            1D NumPy array containing only finite values from `arr`.
            If no finite values are found, returns an empty array.
        """
        return arr[np.isfinite(arr)]

    @log_function_name
    def _axis_limits(self) -> tuple[float, float]:
        """
        Compute global axis limits across the reference and all model arrays.

        Only finite values (i.e., not NaN/±inf) are considered. This is used to
        apply the same [min, max] to both X and Y axes in QQ-style plots so that
        the 1:1 line is meaningful across panels.

        Returns
        -------
        tuple[float, float]
            A pair ``(mn, mx)`` with the minimum and maximum finite values found
            across ``self.ref`` and all ``self.models``. If no finite values exist,
            returns ``(0.0, 1.0)`` as a safe fallback.
        """
        xs = [self._finite(self.ref)] + [self._finite(m) for m in self.models]
        mn = float(min(np.min(a) for a in xs if a.size))
        mx = float(max(np.max(a) for a in xs if a.size))
        return mn, mx

    @log_function_name
    def _point_density(
        self,
        x: np.ndarray,
        y: np.ndarray,
        bins: tuple[int, int] = (60, 60)
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Compute a per-point density value using a 2D histogram of (x, y).

        The function filters both inputs to finite values, builds a 2D histogram
        with the given bin counts, and assigns each point the count of the bin it
        falls into. Densities are normalized to the range [0, 1] (max → 1) if the
        maximum histogram count is > 0; otherwise the raw (all-zero) counts are
        returned.

        Parameters
        ----------
        x : np.ndarray
            X-coordinates (e.g., reference values). Will be coerced to float.
        y : np.ndarray
            Y-coordinates (e.g., model values). Will be coerced to float.
        bins : tuple[int, int], default (60, 60)
            Number of bins along x and y for the 2D histogram.

        Returns
        -------
        tuple[np.ndarray, np.ndarray, np.ndarray]
            A 3-tuple ``(xf, yf, d)`` where:
              * ``xf`` and ``yf`` are 1D arrays of the finite points (same length),
              * ``d`` is a 1D array of per-point densities (same length as ``xf``),
                normalized to [0, 1] when possible.

        Notes
        -----
        - Bin membership is computed via ``np.digitize`` against the histogram edges.
        - If all points fall into empty bins (unlikely), the returned densities are zeros.
        - This is suitable for coloring scatter points (e.g., via ``c=d``).
        """
        x, y = np.asarray(x, float), np.asarray(y, float)
        m = np.isfinite(x) & np.isfinite(y)
        x, y = x[m], y[m]
        H, xedges, yedges = np.histogram2d(x, y, bins=bins)
        xi = np.clip(np.digitize(x, xedges) - 1, 0, H.shape[0] - 1)
        yi = np.clip(np.digitize(y, yedges) - 1, 0, H.shape[1] - 1)
        dens = H[xi, yi]
        return x, y, (dens / dens.max()) if dens.max() > 0 else dens

    @log_function_name
    def _qq_points(
        self,
        step: float = 1.0,
        low_trim: float = 0.0,
        high_trim: float = 100.0
    ) -> List[Tuple[np.ndarray, np.ndarray, np.ndarray]]:
        """
        Compute matched quantiles between the reference and each model.

        For each model, this computes:
          - qa: quantiles of the reference array
          - qb: quantiles of the model array
          - q : the percentile levels used

        Parameters
        ----------
        step : float, default=1.0
            Step in percentiles (e.g., 1.0 → 0, 1, 2, ..., 100).
        low_trim : float, default=0.0
            Lower percentile bound (inclusive) to skip extreme tails.
        high_trim : float, default=100.0
            Upper percentile bound (exclusive) to skip extreme tails.

        Returns
        -------
        list[tuple[np.ndarray, np.ndarray, np.ndarray]]
            One tuple per model:
              (qa, qb, q)
              qa : reference quantile values
              qb : model quantile values
              q  : percentile levels (same for qa and qb)
        """
        out = []
        r = self._finite(self.ref)
        q = np.arange(max(step, low_trim), min(100.0, high_trim), step)
        for m in self.models:
            m2 = self._finite(m)
            out.append((np.percentile(r, q), np.percentile(m2, q), q))
        return out

    @log_function_name
    def _qq_ci_band(
        self,
        ref: np.ndarray,
        model: np.ndarray,
        q: np.ndarray,
        ci: int = 95,
        n_boot: int = 300,
        random_state: Optional[int] = None
    ) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
        """
        Bootstrap a confidence band for the QQ curve (model quantiles vs fixed ref quantiles).

        The reference quantiles are kept fixed at the percentile levels `q`. The model
        array is bootstrapped `n_boot` times (sampling with replacement, same length as
        the original model), and quantiles at `q` are computed for each bootstrap sample.
        The lower/upper envelopes are then taken as the `ci`% central interval across
        bootstrap replicates.

        Parameters
        ----------
        ref : np.ndarray
            Reference values; only their finite values matter to define `q` (via the caller).
        model : np.ndarray
            Model values to be bootstrapped.
        q : np.ndarray
            Percentile levels (in [0, 100)) at which to compute the QQ curve.
        ci : int, default 95
            Confidence level for the band (e.g., 95 → 2.5th and 97.5th percentiles).
        n_boot : int, default 300
            Number of bootstrap replicates.
        random_state : int or None, default None
            Seed passed to ``np.random.default_rng`` for reproducibility.

        Returns
        -------
        (low, high) : tuple[Optional[np.ndarray], Optional[np.ndarray]]
            Lower and upper bounds of the QQ band, each shaped like `q`. If either
            `ref` or `model` contains no finite values, returns ``(None, None)``.
        """
        r, m = self._finite(ref), self._finite(model)
        if r.size == 0 or m.size == 0:
            return None, None

        rng = np.random.default_rng(random_state)
        qb_samples = np.empty((n_boot, len(q)))
        for b in range(n_boot):
            mb = m[rng.integers(0, m.size, m.size)]
            qb_samples[b] = np.percentile(mb, q)
        lo = np.percentile(qb_samples, (100 - ci) / 2.0, axis=0)
        hi = np.percentile(qb_samples, 100 - (100 - ci) / 2.0, axis=0)
        return lo, hi

    @log_function_name
    def _common_bins(self, nbins: int) -> tuple[np.ndarray, np.ndarray, float]:
        """
        Compute shared histogram bins across the reference and all model arrays.

        Uses only finite values from ``self.ref`` and ``self.models`` to build a
        common set of bin edges so that all panels are comparable. If no finite
        values are available, falls back to the range [0.0, 1.0].

        Parameters
        ----------
        nbins : int
            Number of histogram bins to generate.

        Returns
        -------
        tuple[np.ndarray, np.ndarray, float]
            ``(edges, centers, width)`` where:
              * ``edges``   : array of shape (nbins+1,) with bin boundaries.
              * ``centers`` : array of shape (nbins,) with bin midpoints.
              * ``width``   : scalar bin width (``edges[1] - edges[0]``).
        """
        all_data = np.concatenate([self._finite(self.ref)] + [self._finite(m) for m in self.models])
        if all_data.size == 0:
            all_data = np.array([0.0, 1.0])

        edges = np.linspace(np.nanmin(all_data), np.nanmax(all_data), nbins + 1)
        centers = (edges[:-1] + edges[1:]) / 2.0
        width = edges[1] - edges[0]
        return edges, centers, width

    @log_function_name
    def _grid_setup(
        self,
        max_cols: int = 4,
        sharex: bool = True,
        sharey: bool = True,
        n_panels: Optional[int] = None
    ) -> tuple[Figure, np.ndarray]:
        """
        Create a subplot grid sized for the number of panels, with at most
        ``max_cols`` columns per row, and return a flattened axes array.

        The number of panels ``n`` defaults to ``len(self.models)`` unless
        ``n_panels`` is provided explicitly. The grid uses:
        ``ncols = min(max_cols, max(1, n))`` and
        ``nrows = ceil(n / ncols)``.

        Parameters
        ----------
        max_cols : int, default 4
            Maximum number of columns per row.
        sharex : bool, default True
            Whether x-axes are shared across subplots.
        sharey : bool, default True
            Whether y-axes are shared across subplots.
        n_panels : int, optional
            Override for the number of panels; if ``None``, uses
            ``len(self.models)``.

        Returns
        -------
        (fig, axes) : tuple[matplotlib.figure.Figure, np.ndarray]
            The Matplotlib figure and a **1D** NumPy array of Axes objects,
            obtained by flattening the grid with ``np.atleast_1d(...).ravel()``.
            The array length equals ``nrows * ncols``; some trailing axes may be
            unused if ``n`` is not a multiple of ``ncols``.
        """
        n = len(self.models) if n_panels is None else n_panels
        ncols = min(max_cols, max(1, n))
        nrows = int(np.ceil(n / ncols))
        fig, axes = plt.subplots(
            nrows, ncols,
            figsize=(5 * ncols + 1, 4 * nrows),
            sharex=sharex, sharey=sharey
        )
        axes = np.atleast_1d(axes).ravel()
        return fig, axes

    @log_function_name
    def _hide_unused(self, axes: np.ndarray, used: int) -> None:
        """
        Hide any subplot axes after the last 'used' panel.

        Parameters
        ----------
        axes : np.ndarray
            Flattened array of Matplotlib Axes (as returned by `_grid_setup`).
        used : int
            Number of axes that were actually populated with plots. Axes at
            indices ``used .. len(axes)-1`` are turned off via ``axis("off")``.
        """
        for j in range(used, len(axes)):
            axes[j].axis("off")

    @log_function_name
    def _ticks_on(self, axes: Sequence[plt.Axes]) -> None:
        """
        Ensure bottom and left tick labels are visible for the given axes.

        Parameters
        ----------
        axes : Sequence[matplotlib.axes.Axes]
            Iterable of Axes to adjust (e.g., the subset that were used).
        """
        for ax in axes:
            ax.tick_params(labelbottom=True, labelleft=True)

    @log_function_name
    def _auto_colorbar(
        self,
        fig: Figure,
        axes: Sequence[plt.Axes],
        norm: Normalize,
        cmap: Colormap,
        label: str = "Density",
        side: Literal["right", "left"] = "right",
        pad: float = 0.02,
        width: float = 0.02
    ) -> None:
        """
        Add a vertical colorbar snug to the subplot grid with automatic height.

        The function inspects the positions of all *visible* axes in `axes`,
        computes the combined vertical span (min bottom to max top), and places a
        slim colorbar either to the **right** (default) or **left** of the grid.

        Parameters
        ----------
        fig : matplotlib.figure.Figure
            Target figure.
        axes : Sequence[matplotlib.axes.Axes]
            Axes that form the grid (typically from `_grid_setup`), some of which
            may be unused/hidden. Only visible axes contribute to layout.
        norm : matplotlib.colors.Normalize
            Normalization used by the scatter/image being represented.
        cmap : matplotlib.colors.Colormap
            Colormap used by the scatter/image being represented.
        label : str, default "Density"
            Colorbar label text.
        side : {"right", "left"}, default "right"
            Which side of the grid to place the colorbar.
        pad : float, default 0.02
            Horizontal padding (in figure-relative coordinates) between the outer
            edge of the grid and the colorbar.
        width : float, default 0.02
            Colorbar axis width (in figure-relative coordinates).

        Returns
        -------
        None
        """
        if not len(axes):
            return

        # -- Ensure layout is computed:
        fig.canvas.draw()

        # -- Only consider visible axes for bounding box calculations:
        bboxes = [ax.get_position() for ax in axes if ax.get_visible()]
        if not bboxes:
            return

        min_bottom, max_top = min(b.y0 for b in bboxes), max(b.y1 for b in bboxes)
        if side == "right":
            x = max(b.x1 for b in bboxes) + pad
        else:  # left
            x = min(b.x0 for b in bboxes) - pad - width

        cax = fig.add_axes([x, min_bottom, width, max_top - min_bottom])
        fig.colorbar(
            cm.ScalarMappable(norm=norm, cmap=cmap),
            cax=cax,
            orientation="vertical",
            label=label
        )

    @log_function_name
    def _save(
        self,
        fig: Figure,
        out_dir: Union[str, PathLike[str]],
        filename: str,
        suptitle: str = "",
        rect: tuple[float, float, float, float] = (0.05, 0.03, 0.95, 0.95),
        dpi: int = 150
    ) -> None:
        """
        Apply a super-title, tighten layout, and save the figure to disk.

        Parameters
        ----------
        fig : matplotlib.figure.Figure
            Figure to save.
        out_dir : str or os.PathLike
            Directory where the file will be written. Created if missing.
        filename : str
            File name (e.g., "qq_grid_P_Alps.png").
        suptitle : str, optional
            Text placed at the top via ``fig.suptitle`` (if non-empty).
        rect : tuple[float, float, float, float], default (0.05, 0.03, 0.95, 0.95)
            Bounding box for ``tight_layout`` in figure-relative coordinates:
            ``(left, bottom, right, top)``.
        dpi : int, default 150
            Output resolution.

        Returns
        -------
        None
        """
        if suptitle:
            fig.suptitle(suptitle, y=0.97)

        fig.tight_layout(rect=rect)
        out = Path(out_dir) / filename
        fig.savefig(out, dpi=dpi)
        plt.close(fig)

    @log_function_name
    def _csv_flags(self) -> tuple[bool, bool]:
        """
        Decide CSV export strategy based on `csv_mode` and number of models.

        Returns
        -------
        tuple[bool, bool]
            ``(combine, per_model)``, where:
              * ``combine``   → write one combined CSV (stacked with a ``label`` column)
              * ``per_model`` → write a separate CSV per model

        Notes
        -----
        Behavior by mode:
          - "combined"   → (True,  False)
          - "per-model"  → (False, True)
          - "both"       → (True,  True)
          - "auto"       → (n >= combine_threshold, n < combine_threshold)
        """
        n = len(self.models)
        if self.csv_mode == "combined":
            return True, False
        if self.csv_mode == "per-model":
            return False, True
        if self.csv_mode == "both":
            return True, True
        # auto
        return (n >= self.combine_threshold), (n < self.combine_threshold)

    @log_function_name
    def _save_combined_long(
        self,
        rows: List[pd.DataFrame],
        out_path: Union[str, PathLike[str], Path]
    ) -> None:
        """
        Concatenate per-model DataFrames and write one tidy (long) CSV.

        Parameters
        ----------
        rows : list of pandas.DataFrame
            Each DataFrame should already include a ``label`` column identifying
            the model/panel it came from. Columns should be schema-compatible to
            allow concatenation.
        out_path : str | os.PathLike | pathlib.Path
            Target path for the combined CSV.

        Returns
        -------
        None
        """
        if not rows:
            return
        df = pd.concat(rows, ignore_index=True)
        df.to_csv(out_path, index=False)

    # ==========================================================================
    # --------------------- Main functions for visualization -------------------
    # ==========================================================================
    @log_function_name
    def hist(
        self,
        out_dir: Union[str, PathLike[str]] = "out",
        region_title: str = "",
        var: str = "",
        bins: int = 15,
        mode: Optional[str] = "side"
    ) -> None:
        """
        Histogram comparison of each model against the reference.

        Two display modes:
          * "side"    – side-by-side bars per bin (Ref left, Model right).
          * "overlap" – overlapping bars with transparency.

        Bins are computed once from ref + all models (finite values only) so each
        panel is comparable. CSV export follows ``self.csv_mode``:
          - per-model → ``hist_{label}_{mode}_{region}.csv``
          - combined  → ``hist_ALL_{mode}_{region}.csv`` (tidy/long with ``label``)

        Parameters
        ----------
        out_dir : str | os.PathLike, default "out"
            Output directory for the figure and CSVs (created if missing).
        region_title : str, optional
            Title text shown on each panel (e.g., the region name).
        var: str, optional
            Variable
        bins : int, default 15
            Number of histogram bins (shared across all panels).
        mode : {"side", "overlap", "line"}, default "side"
            Rendering style for bars.

        Returns
        -------
        None
            Saves a PNG (``hist_grid_{mode}_{region}.png``) and CSVs as per export mode.
        """
        # -- Local variables:
        alp_side: float = 0.85
        alp_ovlp: float = 0.5

        ref_color: str = "black"
        mod_color: str = "C0"
        align: str = "center"
        ref_label: str = "ref"
        loc_where: str = "mid"

        if mode not in ("side", "overlap", "line"):
            raise ValueError(f"Invalid mode: {mode}")

        # -- Create output folder:
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        fig, axes = self._grid_setup()
        edges, centers, width = self._common_bins(bins)
        bar_w = 0.3 * width

        # -- CSV report (initialization):
        combine, per_model = self._csv_flags()
        combined_rows = []

        used = 0
        for ax, model, label in zip(axes, self.models, self.labels):
            ref_counts, _ = np.histogram(self.ref, bins=edges)
            mod_counts, _ = np.histogram(model, bins=edges)

            if mode == "side":
                ax.bar(
                    centers - bar_w / 2, ref_counts,
                    width = bar_w, color = ref_color,
                    alpha = alp_side, label = ref_label, align = align,
                )
                ax.bar(
                    centers + bar_w / 2, mod_counts,
                    width = bar_w, color = mod_color,
                    alpha = alp_side, label = label, align = align,
                )
            elif mode == "overlap":
                w_size = 0.9 * width
                ax.bar(
                    centers, ref_counts,
                    width = w_size, color = ref_color,
                    alpha = alp_ovlp, label = ref_label, align = align
                )
                ax.bar(
                    centers, mod_counts,
                    width = w_size, color = mod_color,
                    alpha = alp_ovlp, label = label, align = align
                )
            elif mode == "line":
                ax.step(
                    edges[:-1], ref_counts,
                    where = loc_where, color = ref_color, label = ref_label,
                )
                ax.step(
                    edges[:-1], mod_counts,
                    where = loc_where, color = mod_color, label = label,
                )
            else:
                raise ValueError(f"Unknown mode: {mode}")

            ax.set_title(region_title)
            ax.set_xlabel(f"Value [{self.units}]")
            ax.set_ylabel("Frequency")
            ax.grid(True, linestyle="--", alpha=0.5)
            ax.legend()

            # -- Collect data for report:
            df_model = pd.DataFrame({
                "bin_left": edges[:-1],
                "bin_right": edges[1:],
                "ref_count": ref_counts,
                "model_count": mod_counts,
                "label": label
            })
            # -- Short report:
            if per_model:
                df_model.to_csv(
                    out_dir / f"hist_{label}_{mode}_{self.region}.csv", index=False
                )
            if combine:
                combined_rows.append(df_model)

            used += 1

        self._hide_unused(axes, used)
        self._ticks_on(axes[:used])
        self._save(
            fig, out_dir, f"hist_grid_{mode}_{self.region}.png",
            suptitle=f"Histogram of {var} ({mode} mode)"
        )
        # -- Full CSV report:
        if combine:
            self._save_combined_long(combined_rows, out_dir / f"hist_ALL_{mode}_{self.region}.csv")

    @log_function_name
    def qqplot(
        self,
        out_dir: Union[str, PathLike[str]] = "out",
        region_title: str = "",
        var: str = "",
        qq_step: float = 1.0,
        trim_low: float = 0.5,
        trim_high: float = 99.5,
        show_band: bool = True,
        ci: int = 95,
        n_boot: int = 300,
        band_color: str = "tab:red",
        band_alpha: float = 0.25,
        random_state: int | None = None,
        ref_name: str = 'Eobs'
    ) -> None:
        """
        QQ plot (model quantiles vs reference quantiles) with optional bootstrap band.

        For each model panel:
          * Computes quantiles of reference and model at levels q in
            ``[trim_low, trim_high)`` with step ``qq_step``.
          * Plots scatter of (ref_q, model_q) and a 1:1 reference line.
          * Optionally shades a bootstrap confidence band for model quantiles
            at the fixed reference quantiles.

        CSV export follows ``self.csv_mode``:
          - per-model → ``qq_{label}_{region}.csv``
          - combined  → ``qq_ALL_{region}.csv`` (long/tidy with a ``label`` column)
          - both/auto as configured.

        Parameters
        ----------
        out_dir : str | os.PathLike, default "out"
            Output directory; created if missing.
        region_title : str, optional
            Title shown on each panel.
        var: str, optional
            Variable
        qq_step : float, default 1.0
            Percentile step (e.g., 1.0 → 1%, 2%, ...).
        trim_low : float, default 0.5
            Lower percentile bound (inclusive).
        trim_high : float, default 99.5
            Upper percentile bound (exclusive).
        show_band : bool, default True
            If True, draw a bootstrap confidence band for the model quantiles.
        ci : int, default 95
            Confidence level for the band (e.g., 95 → central 95%).
        n_boot : int, default 300
            Number of bootstrap replicates.
        band_color : str, default "tab:red"
            Fill color for the band.
        band_alpha : float, default 0.25
            Alpha for the band fill.
        random_state : int or None, default None
            Seed for reproducible bootstrapping.
        ref_name : str
            Reference name

        Returns
        -------
        None
            Saves a PNG (``qq_grid_{region}.png``) and CSVs per mode.
        """
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        fig, axes = self._grid_setup()
        mn, mx = self._axis_limits()
        qq_results = self._qq_points(qq_step, trim_low, trim_high)

        # -- CSV report (initialization):
        combine, per_model = self._csv_flags()
        combined_rows = []

        used = 0
        for ax, model, label, (qa, qb, q) in zip(axes, self.models, self.labels, qq_results):
            lo = hi = None
            if show_band:
                lo, hi = self._qq_ci_band(self.ref, model, q, ci=ci, n_boot=n_boot, random_state=random_state)
                if lo is not None:
                    ax.fill_between(qa, lo, hi, color=band_color, alpha=band_alpha, label=f"{int(ci)}% QQ band")

            ax.scatter(qa, qb, s=8, color="C0", label=f"{label} quantiles")
            ax.plot([mn, mx], [mn, mx], "k-", lw=1.0, label="1:1 line")
            ax.plot(qa, qb, color="magenta", lw=1.75, label="QQ line")

            ax.set_title(region_title)
            ax.set_xlabel(ref_name + (f" [{self.units}]" if self.units else ""))
            ax.set_ylabel(label + (f" [{self.units}]" if self.units else ""))
            ax.set_xlim(mn, mx)
            ax.set_ylim(mn, mx)
            ax.grid(True, linestyle="--", alpha=0.4)
            ax.legend()

            # -- Collect data for report:
            df = pd.DataFrame({"ref_q": qa, "model_q": qb, "label": label})
            # -- Short report:
            if show_band and lo is not None:
                df["band_low"], df["band_high"] = lo, hi
            if per_model:
                df.to_csv(out_dir / f"qq_{label}_{self.region}.csv", index=False)
            if combine:
                combined_rows.append(df)
            used += 1

        self._hide_unused(axes, used)
        self._ticks_on(axes[:used])
        self._save(
            fig, out_dir, f"qq_grid_{self.region}.png",
            suptitle=f"QQ plot of {var}" + (f" [{self.units}]" if self.units else ""),
            rect=(0.05, 0.03, 0.98, 0.95)
        )
        # -- Full CSV report:
        if combine:
            self._save_combined_long(combined_rows, out_dir / f"qq_ALL_{self.region}.csv")

    @log_function_name
    def qqplot_scatter(
        self,
        out_dir: Union[str, PathLike[str]] = "out",
        region_title: str = "",
        var: str = "",
        bins: tuple[int, int] = (60, 60),
        qq_step: float = 1.0,
        trim_low: float = 0.5,
        trim_high: float = 99.5,
        colorbar_side: Literal["right", "left"] = "right",
        ref_name: str = 'Eobs'
    ) -> None:
        """
        Density-colored scatter of model vs reference with 1:1 line and QQ curve.

        For each model panel:
          * Colors scatter points by local density (via a 2D histogram).
          * Draws a 1:1 reference line (black).
          * Overlays the QQ curve (magenta), computed at percentiles in
            ``[trim_low, trim_high)`` with step ``qq_step``.

        A vertical colorbar is placed snug to the subplot grid with automatic height;
        use ``colorbar_side`` to choose left/right if space overlaps.

        CSV export behavior follows ``self.csv_mode``:
          - per-model → ``qqscatter_{label}_{region}.csv``
          - combined  → ``qqscatter_ALL_{region}.csv`` (long/tidy with a ``label`` column)
          - both/auto as configured.

        Parameters
        ----------
        out_dir : str | os.PathLike, default "out"
            Output directory for the figure and CSVs. Created if missing.
        region_title : str, optional
            Title used on each panel (e.g., region name displayed in the axes).
        var: str, optional
            Variable
        bins : tuple[int, int], default (60, 60)
            Number of bins along x and y for the 2D density histogram.
        qq_step : float, default 1.0
            Percentile step for the QQ line (e.g., 1.0 → 1%, 2%, ...).
        trim_low : float, default 0.5
            Lower percentile bound (inclusive) to trim tails.
        trim_high : float, default 99.5
            Upper percentile bound (exclusive) to trim tails.
        colorbar_side : {"right", "left"}, default "right"
            Which side of the grid to place the colorbar.
        ref_name : str
            Reference name

        Returns
        -------
        None
            Saves a PNG figure (``qq_density_grid_{region}.png``) and CSVs as per
            the CSV mode configuration.
        """
        # -- Create output folder:
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        # -- Create figure:
        fig, axes = self._grid_setup()
        mn, mx = self._axis_limits()
        # -- Get CMAP and NORM values:
        cmap: Colormap = cm.get_cmap("viridis")
        norm: Normalize = Normalize(0.0, 1.0)

        qq_results = self._qq_points(qq_step, trim_low, trim_high)

        # -- CSV report (initialization):
        combine, per_model = self._csv_flags()
        combined_rows = []

        used = 0
        for ax, model, label, (qa, qb, _) in zip(axes, self.models, self.labels, qq_results):
            x, y, d = self._point_density(self.ref, model, bins=bins)
            ax.scatter(x, y, c=d, s=6, cmap=cmap, norm=norm, rasterized=True, label=label)
            ax.plot([mn, mx], [mn, mx], color="black", lw=1.0, label="1:1 line")
            ax.plot(qa, qb, color="magenta", lw=1.75, label="QQ line")
            ax.set_title(region_title)
            ax.set_xlabel(ref_name + (f" [{self.units}]" if self.units else ""))
            ax.set_ylabel(label + (f" [{self.units}]" if self.units else ""))
            ax.set_xlim(mn, mx)
            ax.set_ylim(mn, mx)
            ax.grid(True, linestyle="--", alpha=0.5)
            ax.legend()

            # -- Short CSV report:
            df = pd.DataFrame({"ref_q": qa, "model_q": qb, "label": label})
            if per_model:
                df.to_csv(out_dir / f"qqscatter_{label}_{self.region}.csv", index=False)
            if combine:
                combined_rows.append(df)
            used += 1

        axes_used = axes[:used]
        self._hide_unused(axes, used)
        self._ticks_on(axes_used)
        self._auto_colorbar(fig, axes_used, norm, cmap, label="Density", side=colorbar_side)
        self._save(
            fig, out_dir, f"qq_density_grid_{self.region}.png",
            suptitle=f"Scatter and QQline of {var} {('['+self.units+']') if self.units else ''}",
            rect=(0.05, 0.03, 0.90, 0.95)
        )
        # -- Full CSV report:
        if combine:
            self._save_combined_long(
                combined_rows, out_dir / f"qqscatter_ALL_{self.region}.csv")

    @log_function_name
    def percentiles_diff(
        self,
        out_dir: Union[str, PathLike[str]] = "out",
        region_title: str = "",
        var: str = "",
        qq_step: float = 1.0,
        trim_low: float = 0.5,
        trim_high: float = 99.5,
        relative: bool = False
    ) -> None:
        """
        Percentile-wise difference of model vs reference.

        For each model panel, compute percentiles at levels q in
        ``[trim_low, trim_high)`` with step ``qq_step`` and plot either:

          * **Absolute** difference: ``diff = model_q - ref_q`` (default), or
          * **Relative** difference: ``diff = (model_q - ref_q) / ref_q * 100``.

        CSV export follows ``self.csv_mode``:
          - per-model → ``perc_diff_{label}_{region}.csv``
          - combined  → ``perc_diff_ALL_{abs|rel}_{region}.csv`` (tidy/long with ``label``)
          - both/auto as configured.

        Parameters
        ----------
        out_dir : str | os.PathLike, default "out"
            Output directory; created if missing.
        region_title : str, optional
            Title shown on each panel (e.g., region name).
        var: str, optional
            Variable
        qq_step : float, default 1.0
            Percentile step size (e.g., 1.0 → 1%, 2%, ...).
        trim_low : float, default 0.5
            Lower percentile bound (inclusive).
        trim_high : float, default 99.5
            Upper percentile bound (exclusive).
        relative : bool, default False
            If True, plot relative (%) differences; otherwise absolute units.

        Returns
        -------
        None
            Saves a PNG (``perc_diff_grid_{abs|rel}_{region}.png``) and CSVs per mode.
        """
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        fig, axes = self._grid_setup(sharex=False, sharey=False)
        qq_results = self._qq_points(qq_step, trim_low, trim_high)

        # -- CSV report (initialization):
        combine, per_model = self._csv_flags()
        combined_rows = []

        used = 0
        for ax, model, label, (qa, qb, q) in zip(axes, self.models, self.labels, qq_results):
            diff = (qb - qa) if not relative else (qb - qa) / qa * 100.0
            ax.plot(q, diff, color="C0", label=label)
            ax.axhline(0, color="black", lw=1.0, label="Baseline (0 diff)")
            ax.set_title(region_title)
            ax.set_xlabel("Percentile")
            ax.set_ylabel(f"Diff [{self.units}]" if not relative else "Diff [%]")
            ax.grid(True, linestyle="--", alpha=0.5)
            ax.legend()
            # -- Collect data for report:
            df = pd.DataFrame({"percentile": q, "diff": diff, "label": label})
            # -- Short report:
            if per_model:
                df.to_csv(out_dir / f"perc_diff_{label}_{self.region}.csv", index=False)
            if combine:
                combined_rows.append(df)
            used += 1
        # -- Save figure:
        self._hide_unused(axes, used)
        self._ticks_on(axes[:used])
        self._save(
            fig, out_dir, f"perc_diff_grid_{'rel' if relative else 'abs'}_{self.region}.png",
            suptitle=f"Percentile difference of {var}"
        )
        # -- Full CSV report:
        if combine:
            self._save_combined_long(
                combined_rows,
                out_dir / f"perc_diff_ALL_{'rel' if relative else 'abs'}_{self.region}.csv"
            )

    @log_function_name
    def qqplot_percentiles(
        self,
        out_dir: Union[str, PathLike[str]] = "out",
        region_title: str = "",
        var: str = "",
        qq_step: float = 1.0,
        trim_low: float = 0.5,
        trim_high: float = 99.5
    ) -> None:
        """
        Plot values vs percentile for reference (black) and each model (colored).

        For each model panel:
          * Compute percentile levels q in ``[trim_low, trim_high)`` with step ``qq_step``.
          * Plot reference percentile curve (black) and model percentile curve (colored).

        CSV export follows ``self.csv_mode``:
          - per-model → ``qqperc_{label}_{region}.csv``
          - combined  → ``qqperc_ALL_{region}.csv`` (tidy/long with a ``label`` column)
          - both/auto as configured.

        Parameters
        ----------
        out_dir : str | os.PathLike, default "out"
            Output directory; created if missing.
        region_title : str, optional
            Title shown on each panel (e.g., region name).
        var: str, optional
            Variable
        qq_step : float, default 1.0
            Percentile step size.
        trim_low : float, default 0.5
            Lower percentile bound (inclusive).
        trim_high : float, default 99.5
            Upper percentile bound (exclusive).

        Returns
        -------
        None
            Saves a PNG (``qqperc_grid_{region}.png``) and CSVs per mode.
        """
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        fig, axes = self._grid_setup(sharex=False, sharey=False)
        r = self._finite(self.ref)
        q = np.arange(max(qq_step, trim_low), min(100.0, trim_high), qq_step)
        ref_vals = np.percentile(r, q)
        qq_results = self._qq_points(qq_step, trim_low, trim_high)

        # -- CSV report (initialization):
        combine, per_model = self._csv_flags()
        combined_rows = []

        used = 0
        for ax, model, label, (_, qb, _) in zip(axes, self.models, self.labels, qq_results):
            ax.plot(q, ref_vals, color="black", label="Ref")
            ax.plot(q, qb, color="C0", label=label)
            ax.set_title(region_title)
            ax.set_xlabel("Percentile")
            ax.set_ylabel(f"Value [{self.units}]")
            ax.grid(True, linestyle="--", alpha=0.5)
            ax.legend()
            # -- Collect data for report:
            df = pd.DataFrame({"percentile": q, "ref_val": ref_vals, "model_val": qb, "label": label})
            # -- Short report:
            if per_model:
                df.to_csv(out_dir / f"qqperc_{label}_{self.region}.csv", index=False)
            if combine:
                combined_rows.append(df)
            used += 1

        # -- Save figure:
        self._hide_unused(axes, used)
        self._ticks_on(axes[:used])
        self._save(
            fig, out_dir, f"qqperc_grid_{self.region}.png",
            suptitle=f"Percentiles of {var}"
        )
        # -- Full CSV report:
        if combine:
            self._save_combined_long(
                combined_rows, out_dir / f"qqperc_ALL_{self.region}.csv"
            )


@log_function_name
def create_adv_plots(
    data4visualization: Union[Dict[str, np.ndarray], List[Dict[str, np.ndarray]]],
    settings4visualization: Union[Dict, List],
    config_paths: Dict[str, Union[None, str]],
    refer_ds: List[str],
    model_ds: List[str],
) -> None:
    """
    Generate advanced climate comparison plots and corresponding CSV reports
    for each region using various statistical and visualization methods.

    Parameters
    ----------
    data4visualization : Union[Dict[str, np.ndarray], List[Dict[str, np.ndarray]]],
        A list where each element is a dictionary containing dataset arrays
        and related metadata for a specific region.
        Expected keys per dictionary:
            - 'var4vis' : list[np.ndarray]
                List of NumPy arrays (one per dataset) to be visualized.
            - 'ds_name' : list[str]
                Dataset names corresponding to the arrays.
    settings4visualization : dict or list
        Visualization settings for each region.
        If a list, must be aligned with `data4visualization` order.
        Expected keys per dict:
            - 'plt_domain_type' : str
            - 'plt_out' : str (output directory)
            - 'qqplot_scatter' : str (plot type)
            - 'plt_title' : str
            - 'plt_label' : str (e.g. ", K" — unit after comma)
    config_paths : dict[str, str | None]
        Paths to configuration files or directories (may be unused here).
    refer_ds : List[str]
        - 'evaldata_acronyms' : list[str]
            Names of datasets to be treated as the reference(s).
    model_ds : List[str]
        - 'data2proof_acronyms' : list[str]
            Names of datasets to be treated as models for comparison.

    Local Variables (Defaults for Plot Parameters)
    -----------------------------------------------
    def_bins : int
        Number of bins for histograms.
    def_qq_bins : tuple[int, int]
        Bin configuration for QQ-plot scatter plots.
    def_qq_step : float
        Step size for QQ-plot x-axis sampling.
    def_trim_low : float
        Lower percentile cutoff for trimming extreme values in plots.
    def_trim_high : float
        Upper percentile cutoff for trimming extreme values in plots.
    def_ci : int
        Confidence interval percentage for QQ-plots.
    def_boot_n : int
        Number of bootstrap samples for confidence bands in QQ-plots.
    def_random_seed : int
        Random seed for reproducible bootstrap sampling.
    def_show_band : bool
        Whether to show the confidence band in QQ-plots.
    def_relative : bool
        Whether to display relative differences in percentile difference plots.

    Notes
    -----
    - The function determines the reference dataset index dynamically by
      matching `evaldata_acronyms` against `ds_name`.
    - Remaining datasets in `data2proof_acronyms` are treated as models.
    - Logging is verbose to facilitate debugging and reproducibility.

    Raises
    ------
    TypeError
        If the plot type is unsupported or data structures are not as expected.
    """
    # -- Local variables:
    def_bins: int = 30
    def_qq_bins = (60, 60)
    def_qq_step: float = 1.0
    def_trim_low: float = 0.5
    def_trim_high: float = 99.5
    def_ci: int = 95
    def_boot_n: int = 300
    def_random_seed: int = 42
    def_show_band: bool = True
    def_relative: bool = False
    csv_report_mode: str = 'combined'

    # -- Normalize inputs to lists so processing loop works for both single/multi-region:
    if isinstance(data4visualization, dict):
        data4visualization = [data4visualization]
    if isinstance(settings4visualization, dict):
        settings4visualization = [settings4visualization]

    # -- Create visualization:
    for sub_region_data, sub_region_settings in zip(data4visualization, settings4visualization):
        # -- Get user settings:
        region: str = sub_region_settings.get('plt_domain_type')
        pout: str = sub_region_settings.get('plt_out')
        plot_type: str = sub_region_settings.get('type4plot')

        title: str = sub_region_settings.get('plt_title')
        label: str = sub_region_settings.get('plt_label', '')
        units: str = label.split(',')[-1].strip()

        # -- Get data for visualization:
        region_data = cast(list[np.ndarray], sub_region_data.get('var4vis'))
        region_ds_names = cast(List[str], sub_region_data.get('ds_name'))

        logger.info(
            f"Region: {region} {title} ({units})\n"
            f"  Output Path   : {pout}\n"
            f"  Plot Type     : {plot_type}\n"
            f"  Input Datasets: {region_ds_names}\n"
            f"  Reference Dataset: {refer_ds}\n"
            f"  Model Datasets: {model_ds}\n"
        )

        # -- Simple control:
        if not isinstance(region_data, list):
            raise TypeError("'region_data' must be a list of numpy arrays")
        if not isinstance(region_ds_names, list):
            raise TypeError("'region_ds_names' must be a list of str")

        # -- Split data to reference and models:
        # -- Find reference index by name:
        ref_idx = next(i for i, name in enumerate(region_ds_names) if name in refer_ds)
        ref = region_data[ref_idx]
        ref_name = region_ds_names[ref_idx]

        # -- Find model indices by names:
        model_indices = [i for i, name in enumerate(region_ds_names) if name in model_ds]
        models = [region_data[i] for i in model_indices]
        labels = [region_ds_names[i] for i in model_indices]

        logger.info(
            f"  Reference     : idx={ref_idx}, name='{ref_name}'\n"
            f"  Models        : idxs={model_indices}, names={labels}\n"
        )

        # -- Initialization:
        plotter = ClimatePlotter(
            ref, models, labels, units = units, region = region, csv_mode = csv_report_mode)

        # -- Generate plots + CSVs reports:
        match plot_type:
            case "hist":
                modes = ['side', 'overlap', 'line']
                for mode in modes:
                    plotter.hist(
                        out_dir = pout,
                        region_title = region,
                        var = title,
                        bins = def_bins,
                        mode = mode,
                    )
                method_used = f"Histogram (bins={def_bins}, modes={modes})"

            case "qqplot_scatter":
                plotter.qqplot_scatter(
                    out_dir=pout,
                    region_title = region,
                    var = title,
                    bins = def_qq_bins,
                    qq_step = def_qq_step,
                    trim_low = def_trim_low,
                    trim_high = def_trim_high,
                    ref_name = ref_name,
                )
                method_used = (
                    f"QQ-Plot Scatter (bins={def_qq_bins}, step={def_qq_step}, "
                    f"trim=({def_trim_low}, {def_trim_high}))"
                )

            case "qqplot":
                plotter.qqplot(
                    out_dir = pout,
                    region_title = region,
                    var = title,
                    qq_step = def_qq_step,
                    trim_low = def_trim_low,
                    trim_high = def_trim_high,
                    show_band = def_show_band,
                    ci = def_ci,
                    n_boot = def_boot_n,
                    random_state = def_random_seed,
                    ref_name = ref_name,
                )
                method_used = (
                    f"QQ-Plot (step={def_qq_step}, trim=({def_trim_low}, {def_trim_high}), "
                    f"CI={def_ci}%, boot={def_boot_n}, seed={def_random_seed})"
                )

            case "percentiles_diff":
                plotter.percentiles_diff(
                    out_dir = pout,
                    region_title = region,
                    var = title,
                    qq_step = def_qq_step,
                    trim_low = def_trim_low,
                    trim_high = def_trim_high,
                    relative = def_relative,
                )
                method_used = (
                    f"Percentiles Diff (step={def_qq_step}, trim=({def_trim_low}, "
                    f"{def_trim_high}), relative={def_relative})"
                )

            case "qqplot_percentiles":
                plotter.qqplot_percentiles(
                    out_dir = pout,
                    region_title = region,
                    var = title,
                    qq_step = def_qq_step,
                    trim_low = def_trim_low,
                    trim_high = def_trim_high,
                )
                method_used = (
                    f"QQ-Plot Percentiles (step={def_qq_step}, trim=({def_trim_low}, "
                    f"{def_trim_high}))"
                )
            # -- Wildcard:
            case _:
                raise TypeError(f"Unsupported plot_type: {plot_type}")

        logger.info(
            f"Generated plot for region: {region} \n"
            f"Method : {method_used}\n"
            f"All plots and CSVs reports saved successfully."
        )
