# Evaluation Suite (EvaSuite)
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2026, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# ---------------------------------------------------------------
# This program defines a configuration system for the EvaSuite climate data
# visualization framework. It provides structured default settings and validation
# mechanisms for generating high-quality visualizations, including:
#
#    1. 2D Map Plots (Builder_maps_config):
#        - Uses Cartopy projections (e.g., PlateCarree, LambertConformal)
#        - Supports subplot layouts for full-domain maps
#        - Configures coastline, land/ocean, colorbars, DPI, format, and more
#
#    2. 1D Line/Bar/Scatter Plots (Builder_plots_config):
#        - Handles multiple variables with unique line/marker/bar styles
#        - Controls grid, axis formatting, legend, time axis, and subplot layout
#        - Supports both numeric and time-based X-axes
#
#    3. Configuration Management (Config_class):
#        - Stores, retrieves, and orders plot/map parameters
#        - Loads YAML configuration files and evaluates embedded Python expressions
#          (e.g., range, projections)
#        - Supports merging and type-checking for user-modified settings
#
#    4. Validation Utilities:
#        - Ensures all user or default settings conform to expected data types
#        - Offers recursive control over nested dictionaries and lists
#
# Usage:
# ------
# - Run the script directly to test and compare default vs. user configurations.
# - Toggle between default and custom YAML files using the `ldef`, `lmap_setup`,
#   and `lplot_setup` flags in the __main__ section.
# - YAML files must follow a structured format compatible with internal
#   configuration expectations (see qui forms).
#
#    History:
#    Version    Date       Name
#    ---------- ---------- ----
#    1.1        02.2025   Evgenii Churiulin, IMKTRO
#                         Initial realise
# ---------------------------------------------------------------
# -- Import python libraries
import inspect
import cartopy.crs as ccrs
from typing import Dict, Any, Optional, List
import yaml
# -- Import user methods:
from hereon_evasuite.visual_support import compare_dicts, Control_data_types
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
logger = get_logger()


class Config_class:
    """
    A configuration utility class for managing plot and map settings.

    This class allows:
    ----------------------------
    - Storing and retrieving named configurations
    - Loading YAML files containing plot or map setup
    - Evaluating embedded Python expressions (e.g., range or Cartopy projections)
    - Converting PFT-specific dictionaries to ordered lists
    """
    def __init__(self) -> None:
        """Initialize an empty configuration storage."""
        self._settings: Dict[str, Any] = {}

    def add(self, key: str, values: Any) -> None:
        """
        Add a key-value pair to the configuration.

        Args:
        ----------------------------
            key (str): The name of the configuration section.
            values (Any): The configuration content.
        """
        self._settings[key] = values

    def get(self, key: str) -> Any:
        """
        Retrieve a nested value using the same key twice (assumes structure like {key: {key: value}}).

        Args:
        ----------------------------
            key (str): The key to retrieve from the settings.

        Returns:
        ----------------------------
            Any: The value associated with the nested key.
        """
        return self._settings[key][key]

    @log_function_name
    def toListInOrder(self, d: Dict[str, Any], orderedPfts: List[str]) -> List[Any]:
        """
        Convert a PFT dictionary to a list ordered by a given list of PFT names.

        Args:
        ----------------------------
            d (Dict[str, Any]): Dictionary with PFT keys and values.
            orderedPfts (List[str]): List specifying the order of PFT keys.

        Returns:
        ----------------------------
            List[Any]: Ordered list of values from the dictionary.
        """
        newlist = []
        for pft in orderedPfts:
            newlist.append(d[pft])
        return newlist

    @log_function_name
    def load_yaml_configs(self, yaml_path: str) -> Dict[str, Any]:
        """
        Loads the map and plot configuration from YAML files and returns them as dictionaries.

        Args:
        -----
        yaml_path
            Path to the YAML file containing the map or plot configuration

        Returns:
        --------
        Dict[str, Any]:
            A tuple with the MAP or PLOT setup dictionary
        """
        def _load_yaml(path: str) -> Dict[str, Any]:
            with open(path, 'r') as file:
                return yaml.safe_load(file)

        def _safe_eval(value: str) -> Any:
            """
            Safely evaluates a string with support for range() and Cartopy projections.

            Args:
            -----
            value : str
                The string to evaluate.

            Returns:
            --------
            any : Evaluated Python object (range, projection, number, etc.).
            """
            allowed_globals = {
                'range': range,
                'PlateCarree': ccrs.PlateCarree,
                'LambertConformal': ccrs.LambertConformal,
                'RotatedPole': ccrs.RotatedPole,
                # Add more projections if needed
                '__builtins__': {}  # Disable built-ins for safety
            }

            if isinstance(value, str):
                try:
                    result = eval(value, allowed_globals)
                    # Auto-call if it’s a Cartopy class (not an instance):
                    if isinstance(result, type) and issubclass(result, ccrs.Projection):
                        return result()  # Call the constructor!
                    return result
                except Exception:
                    return value
            elif isinstance(value, list):
                return [_safe_eval(item) for item in value]
            elif isinstance(value, dict):
                return {k: _safe_eval(v) for k, v in value.items()}
            else:
                return value

        # Load both configurations
        raw_config = _load_yaml(yaml_path)
        processed_config = _safe_eval(raw_config)
        return processed_config

    @property
    def values(self) -> Dict[str, Any]:
        """
        Expose the internal settings dictionary.

        Returns:
        ----------------------------
            Dict[str, Any]: The entire configuration store.
        """
        return self._settings


class Builder_maps_config:
    """
    A configuration builder class for 2D map visualizations.

    This class defines default map settings used for creating climate
    visualizations, including properties for colorbars, projections,
    domain zoom levels, and subplot layouts.

    It supports:
    - Building default map configurations
    - Merging user-defined YAML configurations with defaults
    - Validating types of all map parameters
    """
    @log_function_name
    def __init__(self) -> None:
        """
        Initialize map configuration builder with internal defaults.
        """
        # -- Max possible numbers of lines presented on one figure
        self.__lim_len_var = 21

    def _build_maps_settings(self) -> Config_class:
        """
        Define and return default configuration for map visualizations.

        Returns:
        ----------------------------
            Config_class: A configuration object populated with default map settings.
        """
        cfg = Config_class()
        # -- Common plot settings:
        #    plot tolerance:
        cfg.add('map_tolerance', 0.05)

        # -- Colorbar settings (orientation, extend, colormap)
        cfg.add(
            'map_colorbar', {
                'tas': 'YlOrRd',
                'pr_amount': 'Greens',
                'def_full': 'Spectral_r',
                'def_positive': 'YlGn',
                'def_negative': 'YlGn_r',
            },
        )
        cfg.add('map_colorbar_diff', 'seismic')
        cfg.add('map_colorbar_orientation', 'horizontal')
        cfg.add('map_colorbar_orientation_diff', 'horizontal')
        cfg.add('map_colorbar_extend', 'neither')
        cfg.add('map_colorbar_extend_diff', 'both')
        # -- Play with colorbar ticks:
        cfg.add('map_extend_ticks_manual', False)
        # -- Color for NaN values:
        cfg.add('map_nan_colors', 'lightgrey')
        # -- Special properties for copat2_LambertConformal projection:
        cfg.add('map_lamb_center_lon', 10)
        cfg.add('map_lamb_center_lat', 50)

        # -- Special properties for RotatedPole projection:
        cfg.add('map_pole_longitude', -162.0)
        cfg.add('map_pole_latitude', 39.25)

        # -- Cartopy layers properties:
        #    1. Coastline properties:
        cfg.add('coast_resolution', '50m')
        cfg.add('coast_lw', 0.3)
        cfg.add('coast_lc', 'black')
        #    2. Ocean properties:
        cfg.add('ocean_color', 'white')
        cfg.add('ocean_zorder', 0.0)
        #    3. Land properties:
        cfg.add('land_color', 'sienna')
        cfg.add('land_zorder', 0.0)
        cfg.add('land_lw', 0.5)
        cfg.add('land_edgecolor', 'black')
        cfg.add('land_alpha', 0.05)
        #    4. Grid line properties:
        cfg.add('grid_add', True)
        cfg.add('grid_lw', 0.1)
        cfg.add('grid_x_inline', False)
        cfg.add('grid_y_inline', False)
        cfg.add('grid_alpha', 0.5)
        cfg.add('grid_color', 'gray')
        cfg.add('grid_xlocs', range(-180, 180, 15))
        cfg.add('grid_ylocs', range(-90, 90, 15))
        #   5. Special settings (by default EvaSuite uses internal algorithms):
        cfg.add('maps_title', None)
        cfg.add('maps_subtitle', None)
        cfg.add('maps_min_values', None)
        cfg.add('maps_max_values', None)
        cfg.add('maps_min_values_diff', None)
        cfg.add('maps_max_values_diff', None)

        # -- Output figure resolution:
        cfg.add('map_dpi', 300)
        # -- Output plot format:
        cfg.add('map_format', '.png')

        # -- Add uniq plot (single) and subplots (r..c..) properties for
        #    global domain with projection PlateCarree. More than 3 columns in
        #    row looks overfull:
        cfg.add(
            'global_PlateCarree', {
                # -- Zoom to research domain (Commot for all subplots options):
                'map_zoom2domain': [-180, 180, -90, 90],
                # -- Single plot properties:
                'single': {
                    # -- Plot size (figure):
                    'map_size': [16.0, 12.0],
                    # -- Location colorbar:
                    'map_cbar': [0.2, 0.15, 0.6, 0.015],
                    # -- Not relevant for single:
                    'map_cbar_n1c2': None,
                    'map_cbar_diff': None,
                    'map_cbar_n1c3': None,
                    # -- Plot optimal settings (rows, cols, space by wight, space by height):
                    'map_ncols': None,
                    'map_nrows': None,
                    'map_wspace': None,
                    'map_hspace': None,
                    # -- Title pad:
                    'map_title_loc': [0.130, 0.85, 'left', 16],
                    'map_title_pad': 20.0,
                    'map_title_fsize': 20.0,
                    # -- Label pad, fontsize, rotation (in deg) :
                    'map_label_pad': 20.0,
                    'map_label_fsize': 14.0,
                    'map_label_rotation': 0.0,
                },
                # -- Subplots properties (max number of columns and subplot properties):
                #    1 row, 3 columns:
                'r1c3': {
                    'map_size': [16.0, 6.0],
                    'map_cbar': [0.2, 0.24, 0.6, 0.015],
                    # -- Unique settings for case nrows = 1, ncols = 2
                    'map_cbar_n1c2': [0.15, 0.2, 0.3, 0.015],
                    'map_cbar_diff': [0.53, 0.2, 0.175, 0.015],
                    'map_cbar_n1c3': None,
                    'map_ncols': 3,
                    'map_nrows': 1,
                    'map_wspace': 0.1,
                    'map_hspace': 0.5,
                    'map_title_loc': [0.120, 0.8, 'left', 16],
                    'map_title_pad': 12.0,
                    'map_title_fsize': 12.0,
                    'map_label_pad': 12.0,
                    'map_label_fsize': 12.0,
                    'map_label_rotation': 0.0,
                },
                #    2 rows, 3 columns:
                'r2c3': {
                    'map_size': [16.0, 7.0],
                    'map_cbar': [0.2, 0.07, 0.6, 0.015],
                    'map_cbar_n1c2': None,
                    'map_cbar_diff': None,
                    'map_cbar_n1c3': None,
                    'map_ncols': 3,
                    'map_nrows': 2,
                    'map_wspace': 0.1,
                    'map_hspace': 0.05,
                    'map_title_loc': [0.120, 0.95, 'left', 16],
                    'map_title_pad': 12.0,
                    'map_title_fsize': 12.0,
                    'map_label_pad': 12.0,
                    'map_label_fsize': 12.0,
                    'map_label_rotation': 0.0,
                },
                #    3 rows, 3 columns:
                'r3c3': {
                    'map_size': [16.0, 10.0],
                    'map_cbar': [0.2, 0.07, 0.6, 0.015],
                    'map_cbar_n1c2': None,
                    'map_cbar_diff': None,
                    'map_cbar_n1c3': None,
                    'map_ncols': 3,
                    'map_nrows': 3,
                    'map_wspace': 0.1,
                    'map_hspace': 0.3,
                    'map_title_loc': [0.120, 0.95, 'left', 16],
                    'map_title_pad': 12.0,
                    'map_title_fsize': 12.0,
                    'map_label_pad': 12.0,
                    'map_label_fsize': 12.0,
                    'map_label_rotation': 0.0,
                },
                #    4 rows, 3 columns:
                'r4c3': {
                    'map_size': [16.0, 12.0],
                    'map_cbar': [0.2, 0.07, 0.6, 0.015],
                    'map_cbar_n1c2': None,
                    'map_cbar_diff': None,
                    'map_cbar_n1c3': None,
                    'map_ncols': 3,
                    'map_nrows': 4,
                    'map_wspace': 0.1,
                    'map_hspace': 0.1,
                    'map_title_loc': [0.120, 0.94, 'left', 16],
                    'map_title_pad': 8.0,
                    'map_title_fsize': 12.0,
                    'map_label_pad': 12.0,
                    'map_label_fsize': 12.0,
                    'map_label_rotation': 0.0,
                },
            }
        )
        # -- Add uniq plot (single) and subplots (r..c..) properties for
        #    copat domain with projection LambertConformal. More than 4 columns in
        #    row and more than 3 rows looks overfull:
        cfg.add(
            'copat2_LambertConformal', {
                # -- Zoom to research domain:
                'map_zoom2domain': [-25, 45, 30, 75],
                # -- Subplots properties:
                # -- Single plot properties:
                'single': {
                    # -- Plot size (figure):
                    'map_size': [16.0, 12.0],
                    # -- Location colorbar:
                    'map_cbar': [0.2, 0.07, 0.6, 0.015],
                    'map_cbar_n1c2': None,
                    'map_cbar_diff': None,
                    'map_cbar_n1c3': None,
                    # -- Plot optimal settings (rows, cols, space by wight, space by height):
                    'map_ncols': None,
                    'map_nrows': None,
                    'map_wspace': None,
                    'map_hspace': None,
                    # -- Title pad (map_title_loc --> not useful for single):
                    'map_title_loc': [0.120, 0.95, 'left', 16],
                    'map_title_pad': 20.0,
                    'map_title_fsize': 20.0,
                    # -- Label pad, fontsize, rotation (in deg) :
                    'map_label_pad': 20.0,
                    'map_label_fsize': 14.0,
                    'map_label_rotation': 0.0,
                },
                # -- Subplots properties (max number of columns and subplot properties):
                #    1 row, 4 columns:
                'r1c4': {
                    'map_size': [16.0, 6.0],
                    # -- Common location for case nrows = 1, ncols = 4
                    'map_cbar': [0.2, 0.2, 0.6, 0.015],
                    # -- Unique settings for case nrows = 1, ncols = 2
                    'map_cbar_n1c2': [0.15, 0.2, 0.3, 0.015],
                    'map_cbar_diff': [0.53, 0.2, 0.175, 0.015],
                    # -- Unique settings for case nrows = 1, ncols = 3
                    'map_cbar_n1c3': [0.2, 0.2, 0.4, 0.015],
                    'map_ncols': 4,
                    'map_nrows': 1,
                    'map_wspace': 0.1,
                    'map_hspace': 0.5,
                    'map_title_loc': [0.120, 0.85, 'left', 16],
                    'map_title_pad': 12.0,
                    'map_title_fsize': 12.0,
                    'map_label_pad': 12.0,
                    'map_label_fsize': 12.0,
                    'map_label_rotation': 0.0,
                },
                #    2 rows, 4 columns:
                'r2c4': {
                    'map_size': [16.0, 8.0],
                    'map_cbar': [0.2, 0.08, 0.6, 0.015],
                    'map_cbar_n1c2': None,
                    'map_cbar_diff': None,
                    'map_cbar_n1c3': None,
                    'map_ncols': 4,
                    'map_nrows': 2,
                    'map_wspace': 0.15,
                    'map_hspace': 0.12,
                    'map_title_loc': [0.120, 0.95, 'left', 16],
                    'map_title_pad': 12.0,
                    'map_title_fsize': 12.0,
                    'map_label_pad': 12.0,
                    'map_label_fsize': 12.0,
                    'map_label_rotation': 0.0,
                },
                #    3 rows, 4 columns:
                'r3c4': {
                    'map_size': [16.0, 10.0],
                    'map_cbar': [0.2, 0.07, 0.6, 0.015],
                    'map_cbar_n1c2': None,
                    'map_cbar_diff': None,
                    'map_cbar_n1c3': None,
                    'map_ncols': 4,
                    'map_nrows': 3,
                    'map_wspace': 0.15,
                    'map_hspace': 0.15,
                    'map_title_loc': [0.120, 0.96, 'left', 16],
                    'map_title_pad': 10.0,
                    'map_title_fsize': 12.0,
                    'map_label_pad': 12.0,
                    'map_label_fsize': 12.0,
                    'map_label_rotation': 0.0,
                },
            }
        )
        cfg.add(
            'RotatedPole', {
                # -- Zoom to research domain:
                'map_zoom2domain': [-25, 45, 30, 75],
                # -- Subplots properties:
                # -- Single plot properties:
                'single': {
                    # -- Plot size (figure):
                    'map_size': [16.0, 12.0],
                    # -- Location colorbar:
                    'map_cbar': [0.2, 0.07, 0.6, 0.015],
                    'map_cbar_n1c2': None,
                    'map_cbar_diff': None,
                    'map_cbar_n1c3': None,
                    # -- Plot optimal settings (rows, cols, space by wight, space by height):
                    'map_ncols': None,
                    'map_nrows': None,
                    'map_wspace': None,
                    'map_hspace': None,
                    # -- Title pad (map_title_loc --> not useful for single):
                    'map_title_loc': [0.120, 0.95, 'left', 16],
                    'map_title_pad': 20.0,
                    'map_title_fsize': 20.0,
                    # -- Label pad, fontsize, rotation (in deg) :
                    'map_label_pad': 20.0,
                    'map_label_fsize': 14.0,
                    'map_label_rotation': 0.0,
                },
                # -- Subplots properties (max number of columns and subplot properties):
                #    1 row, 4 columns:
                'r1c4': {
                    'map_size': [16.0, 6.0],
                    # -- Common location for case nrows = 1, ncols = 4
                    'map_cbar': [0.2, 0.2, 0.6, 0.015],
                    # -- Unique settings for case nrows = 1, ncols = 2
                    'map_cbar_n1c2': [0.15, 0.2, 0.3, 0.015],
                    'map_cbar_diff': [0.53, 0.2, 0.175, 0.015],
                    # -- Unique settings for case nrows = 1, ncols = 3
                    'map_cbar_n1c3': [0.2, 0.2, 0.4, 0.015],
                    'map_ncols': 4,
                    'map_nrows': 1,
                    'map_wspace': 0.1,
                    'map_hspace': 0.5,
                    'map_title_loc': [0.120, 0.85, 'left', 16],
                    'map_title_pad': 12.0,
                    'map_title_fsize': 12.0,
                    'map_label_pad': 12.0,
                    'map_label_fsize': 12.0,
                    'map_label_rotation': 0.0,
                },
                #    2 rows, 4 columns:
                'r2c4': {
                    'map_size': [16.0, 8.0],
                    'map_cbar': [0.2, 0.08, 0.6, 0.015],
                    'map_cbar_n1c2': None,
                    'map_cbar_diff': None,
                    'map_cbar_n1c3': None,
                    'map_ncols': 4,
                    'map_nrows': 2,
                    'map_wspace': 0.15,
                    'map_hspace': 0.12,
                    'map_title_loc': [0.120, 0.95, 'left', 16],
                    'map_title_pad': 12.0,
                    'map_title_fsize': 12.0,
                    'map_label_pad': 12.0,
                    'map_label_fsize': 12.0,
                    'map_label_rotation': 0.0,
                },
                #    3 rows, 4 columns:
                'r3c4': {
                    'map_size': [16.0, 10.0],
                    'map_cbar': [0.2, 0.07, 0.6, 0.015],
                    'map_cbar_n1c2': None,
                    'map_cbar_diff': None,
                    'map_cbar_n1c3': None,
                    'map_ncols': 4,
                    'map_nrows': 3,
                    'map_wspace': 0.15,
                    'map_hspace': 0.15,
                    'map_title_loc': [0.120, 0.96, 'left', 16],
                    'map_title_pad': 10.0,
                    'map_title_fsize': 12.0,
                    'map_label_pad': 12.0,
                    'map_label_fsize': 12.0,
                    'map_label_rotation': 0.0,
                },
            }
        )
        return cfg

    def _get_map_setting(self, *keys, dict4settings: Optional[Dict[str, Any]] = None) -> Any:
        """
        Retrieve a nested value from a dictionary based on a sequence of keys.

        Parameters:
        ----------------------------
            keys: Sequence of keys to navigate the dictionary.
            dict4settings: Optional dictionary to use for retrieving the value.
                           If None, defaults to `self._map_settings`.

        Returns:
        ----------------------------
            Any: The value corresponding to the sequence of keys
        """
        # -- Local variables:
        map_settings = self._build_maps_settings().values
        # -- Get user settings from current dictionary:
        current_level = dict4settings if dict4settings is not None else map_settings
        try:
            for key in keys:
                current_level = current_level[key]
            return current_level
        except KeyError as e:
            raise KeyError(
                f"Key path {' -> '.join(keys)} not found in the figure settings.") from e

    @log_function_name
    def _control_maps_settings(
        self,
        act_user_settings: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Validate the types of user-provided or default map settings.

        Parameters
        ----------
        act_user_settings : dict, optional
            If provided, checks these settings instead of defaults.

        Raises
        ------
        TypeError
            If any field has an incorrect type.
        """
        # -- Local variables:
        ctr = Control_data_types()  # initialization of control methods
        func_name = inspect.currentframe().f_code.co_name

        # -- Inform user about current visualization settings:
        logger.info(
            f"{func_name}: You are using "
            f"{'user' if act_user_settings else 'default'} settings for visualization"
        )
        # -- Use user settings if provided; otherwise, validate defaults:
        source = act_user_settings if act_user_settings is not None else self._build_maps_settings().values
        # ----------------------------------------------------------------------
        # =============== Check settings that can be NONE ======================
        # ----------------------------------------------------------------------
        none_list_settings = {
            'maps_title': (str,), 'maps_subtitle': (str,),
        }
        none_dict_settings = {
            'maps_min_values': (float, int), 'maps_max_values': (float, int),
            'maps_min_values_diff': (float, int), 'maps_max_values_diff': (float, int),
        }
        # -- Control of none_list_settings:
        for key, str_types in none_list_settings.items():
            val = self._get_map_setting(key, dict4settings=source)
            ctr.control_simple_list_with_none(val, f"Key '{key}'", str_types, func_name)
        # -- Control of none_dict_settings:
        for key, num_types in none_dict_settings.items():
            val = self._get_map_setting(key, dict4settings=source)
            ctr.control_dict_with_none(val, f"Key '{key}'", num_types, func_name)

        # ----------------------------------------------------------------------
        # =============== Check settings that CANNOT BE NONE ===================
        # ----------------------------------------------------------------------
        simple_checks = {
            # -- Map & colorbar options:
            'map_tolerance': (int, float), 'map_colorbar_orientation': str,
            'map_colorbar_extend': str, 'map_colorbar_diff': str,
            'map_colorbar_orientation_diff': str, 'map_colorbar_extend_diff': str,
            'map_extend_ticks_manual': bool, 'map_nan_colors': str,
            'map_lamb_center_lon': (int, float), 'map_lamb_center_lat': (int, float),
            'map_pole_longitude': (int, float), 'map_pole_latitude': (int, float),
            # -- Cartopy layers:
            #    1. Coastline properties:
            'coast_resolution': str, 'coast_lw': (int, float), 'coast_lc': str,
            #    2. Ocean properties:
            'ocean_color': str, 'ocean_zorder': (int, float),
            #    3. Land properties:
            'land_color': str, 'land_zorder': (int, float), 'land_lw': (int, float),
            'land_edgecolor': str, 'land_alpha': (int, float),
            #    4. Grid line properties:
            'grid_add': bool, 'grid_lw': (int, float), 'grid_x_inline': bool,
            'grid_y_inline': bool, 'grid_alpha': (int, float), 'grid_color': str,
            'grid_xlocs': range, 'grid_ylocs': range,
            # -- Output:
            'map_dpi': int, 'map_format': str,
        }
        ctr.control_types4dict(
            {
                f"Key '{key}'": (
                    self._get_map_setting(key, dict4settings=source),
                    expected_type
                )
                for key, expected_type in simple_checks.items()
            },
            func_name=func_name,
        )
        # ---------- Special validation for map_colorbar ----------
        map_colorbar = self._get_map_setting('map_colorbar', dict4settings=source)
        if not isinstance(map_colorbar, dict):
            raise TypeError(
                f"Key 'map_colorbar' must be a dict, got {type(map_colorbar).__name__}")
        for k, v in map_colorbar.items():
            if not isinstance(v, str):
                raise TypeError(
                    f"map_colorbar['{k}'] must be str (colormap name), got {type(v).__name__}: {v!r}")
        # ----------------------------------------------------------------------
        # ==================== Check SUBPLOT SETTINGS ==========================
        # ----------------------------------------------------------------------
        excluded_keys = set(none_dict_settings.keys())

        # -- Get list of projection names:
        proj_names = [
            key for key, value in source.items()
            if isinstance(value, dict) and key not in excluded_keys and key != "map_colorbar"
        ]

        # -- Check values in different subplots:
        for proj_name in proj_names:
            map_subplots = self._get_map_setting(proj_name, dict4settings=source)

            #  -- Loop over all subplot keys (e.g., r1c4, r2c2):
            for subplot_key, settings in map_subplots.items():
                if subplot_key != 'map_zoom2domain':
                    # -- None-allowed vars:
                    for var in ['map_ncols', 'map_nrows', 'map_wspace', 'map_hspace']:
                        if var in settings:
                            ctr.control_simple_value(
                                settings.get(var),
                                f"_build_maps_settings.get({subplot_key}).get({var})",
                                (float, int),
                                func_name,
                            )
                    # -- Must-have vars:
                    subplot_type_checks = {
                        'map_size': (list, (int, float)),
                        'map_cbar': (list, (int, float)),
                        'map_title_loc': (list, (int, float, str)),
                        'map_title_pad': (int, float),
                        'map_title_fsize': (int, float),
                        'map_label_pad': (int, float),
                        'map_label_fsize': (int, float),
                        'map_label_rotation': (int, float),
                    }
                    ctr.control_types4dict(
                        {
                            f"_build_maps_settings.get({subplot_key}).get('{var}')": (
                                self._get_map_setting(var, dict4settings=settings),
                                expected_type
                            )
                            for var, expected_type in subplot_type_checks.items()
                        },
                        func_name=func_name
                    )
                    # -- None-allowed lists:
                    for var in ['map_cbar_n1c2', 'map_cbar_diff', 'map_cbar_n1c3']:
                        ctr.control_simple_list_with_none(
                            self._get_map_setting(var, dict4settings=settings),
                            f"_build_maps_settings.get({subplot_key}).get('{var}')",
                            (int, float),
                            func_name
                        )
                else:
                    # -- Please pay attention settings in that case is equil to list:
                    ctr.control_types4dict(
                        {
                            "_build_maps_settings.get('map_zoom2domain')": (settings, list, int),
                        },
                        func_name = func_name
                    )

    @log_function_name
    def _merge_user_map_settings(self, defaults: Dict, user_input: Dict) -> Dict:
        """
        Recursively merge user-modified MAP settings with the default MAP settings.
        Only user-defined fields override defaults, supporting nested structures
        and list-type parameters. Does not modify the original defaults.

        Args:
        -----
        defaults : dict
            Program-defined default MAP configuration.
        user_input : dict
            User configuration loaded and processed via read_yaml_config.

        Returns:
        --------
        dict
            A new merged configuration (defaults + user overrides).
        """
        import copy
        merged = copy.deepcopy(defaults)

        def recursive_merge(default, user):
            if isinstance(default, dict) and isinstance(user, dict):
                for key, user_value in user.items():
                    if key in default:
                        default_value = default[key]
                        if isinstance(default_value, dict) and isinstance(user_value, dict):
                            recursive_merge(default_value, user_value)
                        elif isinstance(default_value, list) and isinstance(user_value, list):
                            default[key] = [
                                user_value[i] if i < len(user_value) and user_value[i] is not None else default_value[i]
                                for i in range(len(default_value))
                            ]
                        else:
                            default[key] = user_value  # scalar, range, projection, etc.
                    else:
                        default[key] = user_value  # if new key, add it
            else:
                return user  # fallback for safety
        recursive_merge(merged, user_input)
        return merged

    @log_function_name
    def _read_yaml_config(self, path: str) -> Dict[str, Any]:
        """
        Load map configuration from a YAML file and evaluate embedded Python expressions.

        Args:
        ----------------------------
            path (str): Path to the YAML file.

        Returns:
        ----------------------------
            Dict[str, Any]: The loaded and processed configuration.
        """
        cfg = Config_class()
        map_configuration = cfg.load_yaml_configs(path)
        return map_configuration


class Builder_plots_config:
    """
    A configuration builder for 1D time series plots.

    This class defines the default plotting settings for 1D visualizations
    such as line, bar, and scatter plots, including axis formatting,
    subplot layouts, and styling for lines, markers, and bars.

    It supports:
    ----------------------------
    - Building and retrieving default settings
    - Loading and merging user YAML configurations
    - Validating and controlling structure and types
    """
    @log_function_name
    def __init__(self) -> None:
        """
        Initialize plot configuration builder with internal defaults.
        """
        # -- Max possible numbers of lines presented on one figure
        self.__lim_len_var = 21

    def _build_plot1d_settings(self) -> Config_class:
        """
        Define and return default configuration for 1D plots.

        Returns:
        ----------------------------
            Config_class: A configuration object populated with default 1D plot settings.
        """
        cfg = Config_class()
        # -- Set common parameters for all figures:
        #    Title color, size and space betveen axis and plot title:
        cfg.add('plt_title_color', 'black')
        #    Labels color and size:
        cfg.add('plt_labels_color', 'black')
        #    Do you want to add legend and it's location:
        cfg.add('plt_llegend', True)
        #    Do you want to add grid?
        cfg.add('plt_lgrid', True)
        #    Which axis do you want to use for grid (major or additional):
        cfg.add('plt_gtype', 'major')
        #    Grid color. line style, transparacy
        cfg.add('plt_gclr', 'grey')
        cfg.add('plt_gstyle', 'dashed')
        cfg.add('plt_galpha', 0.2)
        #    Format of X axis:
        cfg.add('plt_num_x_axis', False)  # Do you want to use numerical X axis (labels)
        cfg.add('plt_time_x_axis', True)  # Do you want to use time X axis (labels)
        cfg.add('plt_ftime', '%Y-%m-%d')  # '%H')#'%Y-%m-%d')  # If time_x_axis choose format of axis '%H'
        cfg.add('plt_day_locator', 15)    # Extra tick
        #    Split range between to values on this step. (2 - 1) / 5
        cfg.add('plt_minor_locator', 5)
        #    Default rotation, color and size for units on X axis:
        cfg.add('plt_l_xrotation', True)
        cfg.add('plt_x_unit_color', 'black')
        #    Default rotation, color and size for units on Y axis:
        cfg.add('plt_l_yrotation', True)
        cfg.add('plt_y_rotation', 0.0)
        cfg.add('plt_y_unit_size', 14.0)
        cfg.add('plt_y_unit_color', 'black')
        #    Add extra exis for Y axis
        cfg.add('plt_lextra_axis', True)
        #    Special settings (by default EvaSuite uses NetCDF attributes or internal algorithms):
        cfg.add('plts_title', None)
        cfg.add('plts_subtitle', None)
        cfg.add('plts_min_values', None)
        cfg.add('plts_max_values', None)
        #    General properties for figure (save, format, dpi, size):
        cfg.add('plt_lsave', True)
        cfg.add('plt_format', 'png')
        cfg.add('plt_dpi', 300)

        # -- Set settings for lines, markers, bar plots:
        #    Line settings (Matplotlib assigns automatically):
        cfg.add('vplt_colors', [None] * self.__lim_len_var)
        cfg.add('vplt_ln_styles', [None] * self.__lim_len_var)
        cfg.add('vplt_ln_widths', [None] * self.__lim_len_var)
        cfg.add('vplt_alphas', [None] * self.__lim_len_var)
        #    Marker settings (Matplotlib assigns automatically):
        cfg.add('vplt_mkr_color', [None] * self.__lim_len_var)
        cfg.add('vplt_mkr_size', [None] * self.__lim_len_var)
        cfg.add('vplt_mkr_style', [None] * self.__lim_len_var)
        #    Bar plot settings (Matplotlib assigns automatically):
        cfg.add('vplt_bar_hatch', [None] * self.__lim_len_var)
        cfg.add('vplt_bar_widths', [0.8] * self.__lim_len_var)
        # -- Set settings for subplots:
        cfg.add(
            'subplots', {
                'single': {
                    'splt_size': [16.0, 10.0],
                    'splt_nrows': 1,
                    'splt_ncols': 1,
                    'splt_wspace': None,
                    'splt_hspace': None,
                    'splt_bottom': None,
                    'splt_top': None,
                    'splt_title_fsize': 20.0,
                    'splt_title_pad': 20.0,
                    'splt_label_fsize': 14.0,
                    'splt_xlabel_pad': 20.0,
                    'splt_ylabel_pad': 20.0,
                    'splt_x_rotation': 45.0,
                    'splt_x_unit_size': 14.0,
                    'splt_l_pos': 'upper left',
                    'splt_bbox_x_loc': None,
                    'splt_bbox_y_loc': None,
                },
                #     1 row, 4 columns:
                'r1c4': {
                    'splt_size': [16.0, 5.0],
                    'splt_nrows': 1,
                    'splt_ncols': 4,
                    'splt_wspace': 0.4,
                    'splt_hspace': 0.1,
                    'splt_bottom': 0.2,
                    'splt_top': 0.75,
                    'splt_title_fsize': 12.0,
                    'splt_title_pad': 10.0,
                    'splt_label_fsize': 12.0,
                    'splt_xlabel_pad': 10.0,
                    'splt_ylabel_pad': 14.0,
                    'splt_x_rotation': 90.0,
                    'splt_x_unit_size': 12.0,
                    'splt_l_pos': 'upper right',
                    'splt_bbox_x_loc': 0.90,
                    'splt_bbox_y_loc': 0.95,
                },
                #    2 rows, 4 columns:
                'r2c4': {
                    'splt_size': [16.0, 8.0],
                    'splt_nrows': 2,
                    'splt_ncols': 4,
                    'splt_wspace': 0.25,
                    'splt_hspace': 0.2,
                    'splt_bottom': None,
                    'splt_top': None,
                    'splt_title_fsize': 12.0,
                    'splt_title_pad': 10.0,
                    'splt_label_fsize': 12.0,
                    'splt_xlabel_pad': 10.0,
                    'splt_ylabel_pad': 20.0,
                    'splt_x_rotation': 60.0,
                    'splt_x_unit_size': 12.0,
                    'splt_l_pos': 'upper left',
                    'splt_bbox_x_loc': 0.60,
                    'splt_bbox_y_loc': 0.25,
                },
                #    3 rows, 4 columns:
                'r3c4': {
                    'splt_size': [16.0, 12.0],
                    'splt_nrows': 3,
                    'splt_ncols': 4,
                    'splt_wspace': 0.25,
                    'splt_hspace': 0.15,
                    'splt_bottom': None,
                    'splt_top': None,
                    'splt_title_fsize': 12.0,
                    'splt_title_pad': 10.0,
                    'splt_label_fsize': 12.0,
                    'splt_xlabel_pad': 10.0,
                    'splt_ylabel_pad': 20.0,
                    'splt_x_rotation': 60.0,
                    'splt_x_unit_size': 12.0,
                    'splt_l_pos': 'upper right',
                    'splt_bbox_x_loc': 0.90,
                    'splt_bbox_y_loc': 0.97,
                },
            }
        )

        return cfg

    def _get_plot_setting(
        self,
        *keys,
        dict4settings: Optional[Dict[str, Any]] = None
    ) -> Any:
        """
        Retrieve a nested value from a dictionary based on a sequence of keys.

        Parameters:
        ----------------------------
            keys: Sequence of keys to navigate the dictionary.
            dict4settings: Optional dictionary to use for retrieving the value.
                           If None, defaults to `self._map_settings`.

        Returns:
        ----------------------------
            Any: The value corresponding to the sequence of keys
        """
        # -- Local variables:
        #    1. Upload default user settings
        plots_settings = self._build_plot1d_settings().values

        # -- Get user settings from current dictionary:
        current_level = dict4settings if dict4settings is not None else plots_settings
        try:
            for key in keys:
                current_level = current_level[key]
            return current_level
        except KeyError as e:
            raise KeyError(
                f"Key path {' -> '.join(keys)} not found in the figure settings.") from e

    @log_function_name
    def _control_user_settings(
        self,
        act_user_settings: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Validate the structure and types of user-provided or default 1D plot settings.

        Args:
        ----------------------------
            act_user_settings (Optional[Dict]): If provided, checks user config instead of defaults.

        Raises:
        ----------------------------
            TypeError: If any field has an incorrect type.
        """
        # -- Local variables:
        ctr = Control_data_types()  # initialization of control methods
        func_name = inspect.currentframe().f_code.co_name

        # -- Inform user about current mode:
        logger.info(
            f"{func_name}: You are using "
            f"{'user' if act_user_settings else 'default'} settings for visualization"
        )

        # ----------------------------------------------------------------------
        # =============== Check settings that can be NONE ======================
        # ----------------------------------------------------------------------
        none_list_settings = {
            'plts_title': (str,), 'plts_subtitle': (str,),
        }
        none_dict_settings = {
            'plts_min_values': (float, int), 'plts_max_values': (float, int),
        }
        # -- Control none_list_settings:
        for key, str_types in none_list_settings.items():
            val = self._get_plot_setting(key, dict4settings=act_user_settings)
            ctr.control_simple_list_with_none(
                val, f"_build_plot1d_settings.get({key})", str_types, func_name
            )
        # -- Control none_dict_settings:
        for key, num_types in none_dict_settings.items():
            val = self._get_plot_setting(key, dict4settings=act_user_settings)
            ctr.control_dict_with_none(
                val, f"_build_plot1d_settings.get({key})", num_types, func_name)

        # ----------------------------------------------------------------------
        # =============== Check settings that CANNOT BE NONE ===================
        # ----------------------------------------------------------------------
        type_checks = {
            # -- Title & label settings:
            'plt_title_color': (int, str), 'plt_labels_color': str,
            # -- Legend settings:
            'plt_llegend': bool,
            # -- Grid settings:
            'plt_lgrid': bool, 'plt_gtype': str, 'plt_gclr': str, 'plt_gstyle': str, 'plt_galpha': (int, float),
            # -- X-axis settings:
            'plt_num_x_axis': bool, 'plt_time_x_axis': bool, 'plt_ftime': str,
            'plt_day_locator': int, 'plt_minor_locator': int, 'plt_l_xrotation': bool,
            'plt_x_unit_color': str,
            # -- Y-axis settings (including lextra_axis):
            'plt_l_yrotation': bool, 'plt_y_rotation': (int, float), 'plt_y_unit_size': (int, float),
            'plt_y_unit_color': str, 'plt_lextra_axis': bool,
            # -- Figure settings:
            'plt_lsave': bool, 'plt_format': str, 'plt_dpi': int,
        }
        ctr.control_types4dict(
            {
                f"_build_plot1d_settings.get('{key}')": (
                    self._get_plot_setting(key, dict4settings = act_user_settings),
                    expected_type
                )
                for key, expected_type in type_checks.items()
            },
            func_name = func_name
        )

        # ----------------------------------------------------------------------
        # ============== Check LIST settings that ALLOW NONE ===================
        # ----------------------------------------------------------------------
        list_with_none_checks = {
            'vplt_colors': (str,), 'vplt_ln_styles': (str,),
            'vplt_ln_widths': (float,), 'vplt_alphas': (float,),
            'vplt_mkr_color': (str,), 'vplt_mkr_size': (float,), 'vplt_mkr_style': (str,),
            'vplt_bar_hatch': (str,), 'vplt_bar_widths': (float,),
        }
        for key, types_ in list_with_none_checks.items():
            val = self._get_plot_setting(key, dict4settings=act_user_settings)
            ctr.control_simple_list_with_none(
                val, f"_build_plot1d_settings.get('{key}')", types_, func_name)

        # ----------------------------------------------------------------------
        # ==================== Check SUBPLOT SETTINGS ==========================
        # ----------------------------------------------------------------------
        plt_subplots = self._get_plot_setting('subplots', dict4settings = act_user_settings)
        vars_with_none = {
            'splt_nrows', 'splt_ncols', 'splt_wspace', 'splt_hspace',
            'splt_bottom', 'splt_top', 'splt_bbox_x_loc', 'splt_bbox_y_loc',
        }
        for subplot_key, settings in plt_subplots.items():
            # -- Check values that may be None:
            for var in vars_with_none:
                if var in settings:
                    ctr.control_simple_value(
                        settings.get(var),
                        f"_build_plot1d_settings.get({subplot_key}).get({var})",
                        (float, int),
                        func_name
                    )
            # -- Check values that must have a type:
            subplot_type_checks = {
                'splt_size': (list, (int, float)),
                'splt_title_fsize': (float, int),
                'splt_title_pad': (float, int),
                'splt_label_fsize': (float, int),
                'splt_xlabel_pad': (float, int),
                'splt_ylabel_pad': (float, int),
                'splt_x_rotation': (float, int),
                'splt_x_unit_size': (float, int),
                'splt_l_pos': str,
            }

            ctr.control_types4dict(
                {
                    f"_build_plot1d_settings.get({subplot_key}).get('{var}')": (
                        self._get_plot_setting(var, dict4settings=settings),
                        type_info
                    )
                    for var, type_info in subplot_type_checks.items()
                },
                func_name=func_name
            )

        logger.info('All 1D plot settings have correct data types.')

    @log_function_name
    def _read_yaml_config(self, path: str) -> Dict:
        """
        Load 1D plot configuration from a YAML file and evaluate embedded Python expressions.

        Args:
        ----------------------------
            path (str): Path to the YAML file.

        Returns:
        ----------------------------
            Dict[str, Any]: The loaded and processed configuration.
        """
        cfg = Config_class()
        plt_configuration = cfg.load_yaml_configs(path)
        return plt_configuration

    @log_function_name
    def _update_user_settings(self, settings: Dict, user_input: Dict) -> Dict:
        """
        Update the default settings with user-defined settings.

        Only fields present in `user_input` will override the corresponding
        fields in `settings`. If a parameter is missing in `user_input`,
        the default value remains unchanged.

        Supports:
        ----------------------------
        - Scalar values (e.g., 'plt_dpi', 'lsave', etc.)
        - List-type values (e.g., 'colors', 'bar_widths', etc.)
        - Nested 'subplots' dictionary with its own logic.

        Args:
        -----
        settings : dict
            Full default configuration dictionary.
        user_input : dict
            Dictionary with user-modified parameters.

        Returns:
        --------
        dict
            Updated configuration dictionary.
        """
        for key, user_value in user_input.items():
            # -- Special case for 'subplots' block (nested dict):
            if key == 'subplots' and isinstance(user_value, dict):
                if 'subplots' not in settings:
                    continue
                for subplot_key, subplot_values in user_value.items():
                    if subplot_key in settings['subplots']:
                        for param, val in subplot_values.items():
                            settings['subplots'][subplot_key][param] = val
                continue  # Skip the rest for 'subplots'

            # -- Normal parameters:
            default_value = settings.get(key)
            # Case: list-type parameter → update individual elements
            if isinstance(default_value, list) and isinstance(user_value, list):
                settings[key] = [
                    user_value[i] if i < len(user_value) and user_value[i] is not None else default_value[i]
                    for i in range(len(default_value))
                ]
            else:
                # Scalar: just override directly
                settings[key] = user_value
        return settings

    @log_function_name
    def _merge_user_settings(self, defaults: Dict, user_input: Dict) -> Dict:
        """
        Merge user-modified settings with default settings into a new dictionary
        without modifying the originals.

        Only user-defined fields will override the defaults.
        Supports nested structures (e.g., 'subplots') and list-type parameters.

        Args:
        -----
        defaults : dict
            Default reference configuration (from program).
        user_input : dict
            YAML-loaded user configuration with modified parameters.

        Returns:
        --------
        dict
            A new merged configuration (defaults + user overrides).
        """
        import copy
        merged = copy.deepcopy(defaults)  # Keep the original defaults safe

        for key, user_value in user_input.items():
            if key == 'subplots' and isinstance(user_value, dict):
                # Handle nested subplots separately
                if 'subplots' in merged:
                    for subplot_key, subplot_values in user_value.items():
                        if subplot_key in merged['subplots']:
                            for param, val in subplot_values.items():
                                merged['subplots'][subplot_key][param] = val
                continue  # Skip normal merging for 'subplots'

            default_value = defaults.get(key)
            # Handle list-type parameters
            if isinstance(default_value, list) and isinstance(user_value, list):
                merged[key] = [
                    user_value[i] if i < len(user_value) and user_value[i] is not None else default_value[i]
                    for i in range(len(default_value))
                ]
            else:
                # Scalar or other types → replace directly
                merged[key] = user_value
        return merged


# -- Run script:
if __name__ == '__main__':
    # -- You can use this option as a debug mode to understand how it works:
    # -- Local parameters:
    ldef = True
    lmap_setup = False
    lplot_setup = True

    main = "/work/bb0105/b381275/GIT_PROJECTS/EVA_ALL_IN_ONE/EVA_NEW2/EXAMPLE/CONFIGS"
    if ldef:
        # -- Test of default settings:
        map_path = f'{main}/default_conf_map.yaml'
        plt_path = f'{main}/default_conf_plot.yaml'
    else:
        map_path = f'{main}/user_conf_map.yaml'
        plt_path = f'{main}/user_conf_plt.yaml'

    if lmap_setup:
        # -- Check maps settings:
        map_conf = Builder_maps_config()
        # -- Load default configuration settings:
        map_settings_prog_default = map_conf._build_maps_settings().values
        # -- Control variables (default and user):
        map_conf._control_maps_settings(map_settings_prog_default)

        # -- Load test configuration settings based on GUI Form:
        if map_path is not None and map_path != '':
            map_settings_user = map_conf._read_yaml_config(map_path)
            # Update the settings with user configuration:
            map_settings_prog_user = map_conf._merge_user_map_settings(
                # -- Default settings:
                map_settings_prog_default,
                # -- User settings
                map_settings_user,
            )
            map_conf._control_maps_settings(map_settings_prog_user)
            # -- Compare default and reference:
            compare_dicts(map_settings_prog_default, map_settings_prog_user)
        else:
            logger.info('There is no YAML file with user settings for MAP configuration')

    if lplot_setup:
        # -- Check plots settings:
        plt_conf = Builder_plots_config()
        plt_settings_prog_default = plt_conf._build_plot1d_settings().values

        # -- Control variables:
        plt_conf._control_user_settings(plt_settings_prog_default)

        # -- Load test configuration settings based on GUI Form:
        if plt_path is not None and plt_path != '':
            # User configuration
            plt_settings_user = plt_conf._read_yaml_config(plt_path)
            # Update the settings with user configuration:
            plt_settings_prog_user = plt_conf._merge_user_settings(
                # -- Default settings:
                plt_settings_prog_default,
                # -- User settings
                plt_settings_user
            )
            # -- Control of the new data:
            plt_conf._control_user_settings(plt_settings_prog_user)
            # -- Compare default and reference:
            compare_dicts(plt_settings_prog_default, plt_settings_prog_user)
        else:
            logger.info('There is no YAML file with user settings for PLOT configuration')
