# Evaluation Suite (EvaSuite)
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2026, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------
# -- import Python modules:
import yaml
import pandas as pd
import geopandas as gpd
import tkinter as tk
from typing import Dict, Any
from argparse import ArgumentParser
from shapely import wkt
# -- Import EvaSuite classes and modules:
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
from hereon_evasuite.visual_gui_map_configuration import MapSettingsGUI
from hereon_evasuite.visual_gui_plt_configuration import Plot1DSettingsGUI
from hereon_evasuite.visual_gui_taylor_configuration import TaylorSettingsGUI
logger = get_logger()


class Init_parser:
    """
    Command-line argument parser and configuration handler for EvaSuite.

    This class is responsible for:
    ----------------------------
      - Defining and parsing all supported command-line arguments for EvaSuite.
      - Launching interactive configuration GUIs for maps, plots, and Taylor diagrams.
      - Executing polygon-related file operations (viewing attributes, combining datasets, adding polygons).
      - Logging and printing system and visualization configuration summaries.

    Typical Usage:
    ----------------------------
        parser = Init_parser()
        options = parser.handlingparser()
        parser.optionsprints(options, sys_settings)
        parser.log_visual_config_info(options, enable_taylor=True)

    Methods
    -------
    handlingparser() -> dict
        Defines the command-line interface, parses arguments, and returns them as a dictionary.
    optionsprints(optset: dict, sysset: dict) -> None
        Executes actions based on parsed options, such as printing system config, launching GUIs,
        or processing polygon data.
    log_visual_config_info(optionss: dict, enable_taylor: bool) -> None
        Logs a summary of visualization-related configuration settings.
    """

    def __init__(self) -> None:
        """Initialization of parser: """
        logger.info("Initializator was activated")

    @log_function_name
    def handlingparser(self) -> Dict[Any, Any]:
        """
        Define and parse all supported EvaSuite command-line arguments.

        This method builds an `argparse.ArgumentParser` with options for:
        ----------------------------
          - System configuration control (`--printsys`, `--cfgsys`).
          - General and dataset-specific YAML configuration files (`--cfggen`, `--inprefdat`, `--inpproofdat`).
          - Polygon operations (`--showpolygons`, `--addpolygondb`, `--addpolygonascii`).
          - Launching GUI configuration tools for maps, 1D plots, and Taylor diagrams.
          - Visualization configuration file paths (`--map-config`, `--plot-config`, `--taylor-config`).

        Returns:
        ----------------------------
            dict:
                A dictionary mapping argument names to their parsed values, as returned by
                `argparse.Namespace` converted via `vars()`.

        Notes:
        ----------------------------
            - Flags like `--printsys` are returned as booleans.
            - Multi-argument options (e.g., `--addpolygondb`) are returned as lists of strings.
            - YAML configuration arguments return `None` if not provided.
        """
        parser = ArgumentParser()
        # parser.add_argument('-e','--echo', nargs='+','integers', metavar='N', type=int, nargs='+',
        #   help='an integer for the accumulator',dest='accumulate',
        #   action='store_const',const=sum, default=max)
        parser.add_argument(
            "-s",
            "--printsys",
            dest = "SYSPRINT",
            default = False,
            help = "print the system configuration for external programs",
            action = "store_true",
        )
        parser.add_argument(
            "-c",
            "--cfgsys",
            dest = "CFGSYS",
            default = None,
            type = str,
            help = (
                "the system configuration for external programs (yaml-format); "
                "if not given take the preinstalled system configuration, otherwise "
                "use the yaml-file given. Check with --printsys the preinstalled "
                "system settings"
            ),
            metavar = "yaml-cfgsys",
            nargs = 1,
        )
        parser.add_argument(
            "-g",
            "--cfggen",
            dest = "CFGGEN",
            default = None,
            type = str,
            help = "the general options (yaml-format) for the evasuite",
            metavar = "yaml-cfggen",
            nargs = 1,
        )
        parser.add_argument(
            "-r",
            "--inprefdat",
            dest = "INPREF",
            default = None,
            type = str,
            help = "the definition of the reference data sets",
            metavar = "yaml-cfgrefdat",
            nargs = 1,
        )
        parser.add_argument(
            "-p",
            "--inpproofdat",
            dest = "INPMOD",
            default = None,
            type = str,
            help = "the definition of the model data sets",
            metavar = "yaml-cfgproofdat",
            nargs = 1,
        )
        parser.add_argument(
            "--showpolygons",
            dest = "POLYSHOW",
            default = None,
            type = str,
            help = "print a shortened list of information available in the file (first parameter) \
                or give a list of entries according to the polygon file (first parameter) and the \
                identifier (second parameter) given",
            metavar = ("polyfile", "attrib-id"),
            nargs = "+",
        )
        parser.add_argument(
            "--addpolygondb",
            dest = "ADDPOLYGONDB",
            default = None,
            type = str,
            help = "add from file A (first parameter) the attribute (second paramater) with the \
                values (third parameter, single string or comma-separated list) to the file B \
                (fourth parameter) and its attribute (fifth parameter). Write the final result \
                in file C (sixth parameter)",
            metavar = ("polyfileA", "attribA", "attribvalsA", "polyfileB", "attribB", "polyfileend"),
            nargs = 6,
        )
        parser.add_argument(
            "--addpolygonascii",
            dest = "ADDPOLYGONASCII",
            default = None,
            type = str,
            help = "add from file A (first parameter), given in wkt format, the polygons with \
              attribute (second parameter) to the file B (third parameter) and its attribute \
              (fourth parameter). Write the final result in file C (fifth parameter)",
            metavar = ("wktfileA", "attribA", "polyfileB", "attribB", "polyfileend"),
            nargs = 5,
        )
        # -- Visualization GUI forms for creating new configuration files:
        parser.add_argument(
            "--gui_map_configuration",
            dest="GUIMAP",
            action="store_true",
            help="Launch the GUI for 2D map configuration",
        )
        parser.add_argument(
            "--gui_plt_configuration",
            dest="GUIPLOT",
            action="store_true",
            help="Launch the GUI for 1D plot configuration",
        )
        parser.add_argument(
            "--gui_taylor_configuration",
            dest="GUITAYLOR",
            action="store_true",
            help="Launch the GUI for Taylor plot configuration",
        )
        # -- Visualization YAML configs (all optional by default):
        parser.add_argument(
            "--plot-config",
            dest = "PLOTCONFIG",
            type=str,
            default=None,
            help="Parses command-line arguments to retrieve the path to the PLOT configuration \
                YAML file. The user can provide a custom PLOT configuration file using \
                the `--plot-config` argument when running the script. If the argument is \
                not provided, this function returns `None`, and the program will use the \
                default PLOT settings. \
                Example (Command-line usage): python your_script.py --plt-config path/to/user_conf_plt.yaml",
        )
        parser.add_argument(
            "--map-config",
            dest = "MAPCONFIG",
            type=str,
            default=None,
            help="The user can provide a custom MAP configuration file using the `--map-config` \
                argument when running the script. If the argument is not provided, this \
                function returns `None`, and the program will use the default MAP settings.\
                Example (Command-line usage): python your_script.py --map-config path/to/user_conf_map.yaml"
        )
        parser.add_argument(
            "--taylor-config",
            dest = "TAYLORCONFIG",
            type=str,
            required=False,
            help="Parses command-line arguments to retrieve the path to the TAYLOR \
                configuration YAML file. The user MUST provide a TAYLOR configuration \
                file using the `--taylor-config` argument when running the script. \
                If the argument is not provided, the program will exit with an error. \
                Example (Command-line usage): \
                python your_script.py --taylor-config path/to/your_taylor_settings.yaml"
        )
        options = parser.parse_args()
        return vars(options)

    @log_function_name
    def optionsprints(self, optset: dict, sysset: dict) -> Any:
        """
        Execute actions based on parsed command-line options.

        Depending on the provided options, this method can:
        ----------------------------
          - Print the system configuration (`--printsys`).
          - Launch the GUI for configuring 2D maps (`--gui_map_configuration`),
            1D plots (`--gui_plt_configuration`), or Taylor plots (`--gui_taylor_configuration`).
          - Display polygon file attributes and optionally a specific attribute list (`--showpolygons`).
          - Add attributes from one polygon file to another (`--addpolygondb`).
          - Merge polygons from an ASCII WKT file into an existing polygon file (`--addpolygonascii`).

        Args:
        ----------------------------
            optset (dict[str, Any]):
                Parsed command-line arguments as returned by `handlingparser()`.
            sysset (dict[str, Any]):
                System configuration dictionary, typically loaded from a YAML file.

        Returns:
        ----------------------------
            None

        Side Effects:
        ----------------------------
            - Logs actions and results using the global EvaSuite logger.
            - May open GUI windows and block execution until they are closed.
            - Reads/writes GeoPackage (`.gpkg`) and other vector data files.
            - Exits the program (`quit()`) after completing the selected action.
        """
        #
        logger.info("Options given through the command line")
        logger.info(optset)
        logger.info("")
        if optset["SYSPRINT"]:
            ("Configuration of external programs")
            logger.info(
                yaml.dump(
                    sysset,
                    indent = 2,
                    sort_keys = False,
                    default_flow_style = False,
                )
            )
            quit()
        elif optset["GUIMAP"]:
            root = tk.Tk()
            MapSettingsGUI(root)
            root.mainloop()
            quit()

        elif optset["GUIPLOT"]:
            root = tk.Tk()
            Plot1DSettingsGUI(root)
            root.mainloop()
            quit()

        elif optset["GUITAYLOR"]:
            root = tk.Tk()
            TaylorSettingsGUI(root)
            root.mainloop()
            quit()

        elif optset["POLYSHOW"] is not None:
            polyfile = gpd.read_file(optset["POLYSHOW"][0])
            logger.info(polyfile)
            logger.info("Attributes in the polygon file: " + ','.join(polyfile.columns))
            if len(list(optset["POLYSHOW"])) == 2:
                logger.info(list(polyfile[optset["POLYSHOW"][1]]))
            quit()

        elif optset["ADDPOLYGONDB"] is not None:
            fileA = optset["ADDPOLYGONDB"][0]
            fileAid = optset["ADDPOLYGONDB"][1]
            fileAvalues = optset["ADDPOLYGONDB"][2].split(',')
            fileB = optset["ADDPOLYGONDB"][3]
            fileBid = optset["ADDPOLYGONDB"][4]
            fileC = optset["ADDPOLYGONDB"][5]
            polysA = gpd.read_file(fileA)
            polysB = gpd.read_file(fileB)
            polysB_comb = polysB
            for key in fileAvalues:
                select = polysA[polysA[fileAid] == key]
                select[fileBid] = key
                newpoly = select[[fileBid, "geometry"]]
                newpoly = newpoly.to_crs(polysB.crs)
                polysB_comb = pd.concat(
                    [polysB_comb, newpoly], ignore_index = True)
            polysB_comb.to_file(fileC, driver = "GPKG")
            logger.info("")
            logger.info("Attribute values of combined polygon file: ")
            logger.info(list(polysB_comb[fileBid]))
            logger.info("")
            quit()

        elif optset["ADDPOLYGONASCII"] is not None:
            fileA = optset["ADDPOLYGONASCII"][0]
            fileAid = optset["ADDPOLYGONASCII"][1]
            fileB = optset["ADDPOLYGONASCII"][2]
            fileBid = optset["ADDPOLYGONASCII"][3]
            fileC = optset["ADDPOLYGONASCII"][4]
            # -- Read csv file:
            wktA = pd.read_csv(fileA, sep = ";")
            wktA['geometry'] = wktA['geometry'].apply(wkt.loads)
            polysA = gpd.GeoDataFrame(wktA, crs = 'epsg:4326')
            polysA[fileBid] = polysA[fileAid]
            #
            polysB = gpd.read_file(fileB)
            polysA = polysA.to_crs(polysB.crs)
            polysB_comb = pd.concat([polysB, polysA], ignore_index = True)
            polysB_comb.to_file(fileC, driver = "GPKG")
            logger.info("")
            logger.info("Attribute values of combined polygon file: ")
            logger.info(list(polysB_comb[fileBid]))
            logger.info("")
            quit()

    @log_function_name
    def log_visual_config_info(self, optionss: dict, enable_taylor: bool) -> None:
        """
        Log a summary of visualization configuration file settings.

        This method checks whether the user has provided paths to custom MAP,
        PLOT, and (optionally) TAYLOR configuration YAML files via command-line
        arguments, and logs a human-readable summary of the findings.

        Args:
        ----------------------------
            optionss (dict[str, Any]):
                Dictionary of parsed command-line options, typically the result
                from `handlingparser()`.
            enable_taylor (bool):
                Whether Taylor diagram visualization is enabled. If True, the
                presence of a `--taylor-config` argument is required.

        Returns:
        ----------------------------
            None

        Raises:
        ----------------------------
            ValueError:
                If `enable_taylor` is True but no TAYLOR configuration file
                path is provided in `optionss`.

        Side Effects:
            - Writes a formatted summary to the EvaSuite logger.
        """
        logger.info("========== Visualization Configuration Summary ==========")

        if optionss.get("MAPCONFIG"):
            logger.info(f"MAP configuration file provided by the user: {optionss['MAPCONFIG']}")
        else:
            logger.info("No MAP configuration file provided by the user. Default MAP settings will be used.")

        if optionss.get("PLOTCONFIG"):
            logger.info(f"PLOT configuration file provided by the user: {optionss['PLOTCONFIG']}")
        else:
            logger.info("No PLOT configuration file provided by the user. Default PLOT settings will be used.")

        if enable_taylor:
            if not optionss.get("TAYLORCONFIG"):
                raise ValueError(
                    "Taylor visualization is enabled, but no --taylor-config was provided.")
            else:
                logger.info(f"TAYLOR configuration file provided: {optionss['TAYLORCONFIG']}")
        else:
            logger.info("Taylor visualization is disabled. No TAYLOR config needed.")
        logger.info("=========================================================")
