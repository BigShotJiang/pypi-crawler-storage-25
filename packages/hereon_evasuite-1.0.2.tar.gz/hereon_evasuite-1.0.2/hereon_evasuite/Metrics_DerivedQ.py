# Evaluation Suite (EvaSuite)
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2026, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# -- EvaSuite program: Metrics_DerivedQ:
# -- Import Python modules:
import os
import subprocess as sp
import numpy as np
import xarray as xr
from typing import Any, Optional, Dict, List, Callable, Tuple

# -- Import EvaSuite modules:
import hereon_evasuite.def_Metric_formulae as dmf
from hereon_evasuite.GeneralUtils import SuiteUtilities
from hereon_evasuite.Prog_PyXarray_PyVis import PyXarray
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name

Genuti = SuiteUtilities()
logger = get_logger()


# -- Main Class for the different Evaluation modes:
class MetricCalc(object):
    @log_function_name
    def __init__(
        self: 'MetricCalc',
        name: str,
        MetricCalcProgClass: PyXarray,
        cfggeneral: Dict[str, Any],
        MetricMode: str,
        cfgMetricMode: Dict[str, int],
        DSdims_squeeze: bool,
        fname_result: str,
    ) -> None:
        """
        Initialize the MetricCalc class for computing evaluation metrics.

        This class handles the setup required for running metric computations
        using a specified calculation engine (typically based on PyXarray). It
        stores all necessary configuration and runtime parameters needed to
        execute metrics in a given evaluation mode (e.g., temporal or spatial).

        Parameters
        ----------
        name : str
            Name identifier for the metric class instance (e.g., "EvalRAW_CalcMetric").

        MetricCalcProgClass : PyXarray
            Instance of the internal EvaSuite class responsible for performing metric calculations.

        cfggeneral : dict
            General configuration settings for the evaluation process (e.g., output format, paths, flags).

        MetricMode : str
            The evaluation mode for which metrics will be calculated (e.g., "temporal", "spatial").

        cfgMetricMode : dict
            Dictionary describing the dataset roles involved in the metric (e.g.):
            {
                'involved_Data2Proof': 1,
                'involved_RefData': 1
            }

        DSdims_squeeze : bool
            Whether to apply a `.squeeze()` operation on the dataset dimensions before metric calculation
            to remove singleton dimensions.

        fname_result : str
            Absolute path to the NetCDF file where the computed results should be stored.

        Notes
        -----
        - This constructor only sets up internal variables; it does not execute calculations.
        - All attributes are stored as `self.<attribute>` for use in later steps.
        - The resulting file (`fname_result`) must have a valid `.nc` extension.
        """
        # -- Variables to use within this class but coming from other classes:
        self.cfgposdims = cfggeneral["PossibleDimNames"]
        self.cfgdatamining = cfggeneral["datamining"]
        self.eval_parameters = cfggeneral["eval_parameters"]
        self.eval_metrics = cfggeneral["eval_metrics"]
        self.MetricCalcProg = MetricCalcProgClass
        self.MetricMode = MetricMode

        # -- Variables initialized for specfic using within this class:
        #    length one dimensions are squeezed or retained:
        self.DSdims_squeeze = DSdims_squeeze
        cfgMM_data2proof = cfgMetricMode["involved_Data2Proof"]
        cfgMM_refdata = cfgMetricMode["involved_RefData"]

        if cfgMM_data2proof == 1 and cfgMM_refdata == 1:
            self.DScount = "1Proof1Ref"
        elif cfgMM_data2proof == 2 and cfgMM_refdata == 1:
            self.DScount = "2Proof1Ref"

        # -- Identifying the MetricComp-class by mother 'EVALmode':
        self.name = name
        # -- Python-operation related to user-specified aggregation:
        self.aggregatetime_mode = self.cfgdatamining["aggregate_temporal"]
        # -- Contain information about what to repair in the final dataset:
        self.RepairTime: Dict[Any, Any] = {}
        # -- Specify the final output file for all results:
        self.fname_result = fname_result

    @log_function_name
    def daskopen(self, DSfile: str, varnames: List[str]) -> xr.Dataset:
        """Proof to open data with dask array for multiprocessing,
        find optimal chunk length by searching for single chunk
        size of ~2,000,000 entries. Only the first variable in file
        is taken as orientation. Should not be a show-stopper because
        all variables should carry the same dimensions before metric calculations.

        Inputs:
        ----------------------------
            DSfile     -> path to the NetCDF file (include .nc)
            varnames   -> list of target variables (e.g., ['hlrs'])
        """
        import time
        import psutil
        logger.info("\n ====== DASKOPEN START ====== \n")
        start_time = time.time()
        process = psutil.Process(os.getpid())
        mem_start = process.memory_info().rss / 1024**2  # MB

        # Optional cache to avoid re-opening same dataset
        cache_key = (DSfile, tuple(varnames), self.MetricMode, self.MetricCalcProg.chunking)
        if not hasattr(self, "_ds_cache"):
            self._ds_cache = {}
        if cache_key in self._ds_cache:
            logger.debug(f"Using cached dataset for {DSfile}")
            logger.info("\n ====== DASKOPEN END (cache) ====== \n")
            return self._ds_cache[cache_key]

        logger.debug(f"Inspecting metadata: {DSfile}")
        meta = xr.open_dataset(DSfile, chunks=None)

        var0 = varnames[0]
        if var0 not in meta:
            raise KeyError(f"Variable '{var0}' not found in file: {list(meta.data_vars)}")

        logger.debug(f"Dataset variables: {list(meta.data_vars.keys())}")
        logger.debug(f"Dataset dimensions: {meta.dims}")
        logger.debug(f"Target variable(s): {varnames}")

        chunking = self.MetricCalcProg.chunking
        if not chunking:
            logger.debug("Chunking disabled — opening unchunked dataset.")
            ds = xr.open_dataset(DSfile, chunks=None)
            self._ds_cache[cache_key] = ds
            try: meta.close()
            except Exception: pass
            logger.info("\n ====== DASKOPEN END ====== \n")
            return ds

        schunkdim = 2000000 if chunking is True else int(chunking)

        meta_dim = self.MetricCalcProg.FindDimsCoordsOfVariables(
            varnamelist=varnames, mode='dims', dataset=meta
        )
        split_mode = 'spatial' if self.MetricMode == 'skill_temporal' else 'temporal'
        logger.debug(f"Chunking mode set to: {split_mode}")

        dim_com = Genuti.SplitMetaDim(meta_dim, mode=split_mode, PossibleDimDict=self.cfgposdims)
        logger.debug(f"Selected chunking dimensions: {dim_com}")

        sizes0 = meta[var0].sizes
        dssize = np.prod([sizes0[d] for d in sizes0])
        nch_com = max(1, min(int(np.round(dssize / schunkdim)), 10))
        logger.debug(f"Data size: {dssize} → Target chunk count: {nch_com} (max 10)")

        # Choose chunk dimension and size
        if split_mode == 'spatial':
            logger.debug(f"schunkdim: {schunkdim} and nchspat {nch_com}")
            dimsizes = {d: sizes0[d] for d in dim_com[var0] if d in sizes0}
            dsspat_bigkey = max(dimsizes, key=dimsizes.get)
            target_size = sizes0[dsspat_bigkey]

            raw_chunk = target_size // nch_com
            remainder = target_size % nch_com
            if remainder != 0:
                raw_chunk += 1  # Avoid last chunk being 1
            target_chunks = {dsspat_bigkey: raw_chunk}
            logger.debug(f"Open file with parameters {dsspat_bigkey}/{raw_chunk}")
        else:
            logger.debug(f"schunkdim: {schunkdim} and nchtime {nch_com}")
            time_dim = dim_com[var0][0]
            target_size = sizes0[time_dim]

            raw_chunk = target_size // nch_com
            remainder = target_size % nch_com
            if remainder != 0:
                raw_chunk += 1
            target_chunks = {time_dim: raw_chunk}
            logger.debug(f"Open file in chunked mode in dim {time_dim} with size {raw_chunk}")

        # Final open with chunks
        ds = xr.open_dataset(DSfile, chunks=target_chunks)

        # Sanity checks
        if var0 not in ds:
            raise KeyError(f"Variable '{var0}' missing after chunking.")

        if ds[var0] is None:
            raise ValueError(f"Variable '{var0}' is None after chunking.")

        if not hasattr(ds[var0], "dims") or not hasattr(ds[var0], "shape"):
            raise TypeError(f"Variable '{var0}' has no valid dims or shape.")

        chunk_info = ds[var0].chunks
        if chunk_info:
            logger.debug(f"Final chunk layout: {chunk_info}")
        else:
            logger.debug("No chunking applied (unchunked).")

        logger.debug(f"Final dims: {list(ds[var0].dims)} / shape: {ds[var0].shape}")
        mem_end = process.memory_info().rss / 1024**2
        elapsed = time.time() - start_time
        logger.debug(f"Memory: {mem_start:.2f} MB → {mem_end:.2f} MB | Time: {elapsed:.2f}s")
        logger.info("\n ====== DASKOPEN END ====== \n")

        self._ds_cache[cache_key] = ds
        try: meta.close()
        except Exception: pass
        return ds


    @log_function_name
    def OpenPrepare(
        self: 'MetricCalc',
        DSfile_ref: str,
        DSfile_proof: str,
        varnames_ref: List[str],
        varnames_proof: List[str],
        DSfile_skillref: Any,
        varnames_skillref: Any,
    ) -> None:
        """
        Opens, prepares, and harmonizes datasets for metric calculation.

        Depending on the dataset setup (e.g., 1Proof1Ref or 2Proof1Ref), this method:
        - Loads reference and proof datasets with or without Dask chunking.
        - Optionally loads a third "skill reference" dataset.
        - Applies `.squeeze()` if configured.
        - Harmonizes temporal, vertical, and horizontal grids between datasets.
        - Stores opened and harmonized datasets in instance attributes (`self.DSref`, `self.DSproof`, etc.).
        - Initializes an empty `xarray.Dataset` (`self.FinalDS`) for later metric results.

        Parameters
        ----------
        DSfile_ref : str
            Path to the NetCDF file of the reference dataset
            (e.g., ERA5-monthly_Merged_RelevantTimeAndParam.nc_FinalEvalGrid_EvalFrequency).

        DSfile_proof : str
            Path to the NetCDF file of the model/research dataset
            (e.g., hfls_Amon_MIROC6_195001-201412.nc_FinalEvalGrid_EvalFrequency).

        varnames_ref : list of str
            Variable names to extract from the reference dataset (e.g., ['hfls']).

        varnames_proof : list of str
            Variable names to extract from the research dataset (e.g., ['hfls']).

        DSfile_skillref : str or None
            Path to the skill reference dataset (required only if `self.DScount == "2Proof1Ref"`).
            Set to `None` if unused.

        varnames_skillref : list of str or None
            Variable names for the skill reference dataset. Set to `None` if not used.

        Notes
        -----
        - Dask chunking behavior is determined by `self.MetricCalcProg.chunking` (bool or int).
        - Chunking is applied along either spatial or temporal dimensions, depending on the metric mode.
        - This method assumes that all input datasets share compatible coordinate systems after harmonization.
        - A helper function `daskopen()` is defined inside to abstract chunk-aware opening logic.
        """
        #
        if self.DScount in ["1Proof1Ref", "2Proof1Ref"]:
            # -- Opening and naming:
            #    Reference dataset:
            self.DSfile_ref = DSfile_ref
            self.varns_ref = varnames_ref
            self.DSref = self.daskopen(DSfile_ref, varnames = varnames_ref)
            #    Research dataset:
            self.DSfile_proof = DSfile_proof
            self.varns_proof = varnames_proof
            self.DSproof = self.daskopen(DSfile_proof, varnames = varnames_proof)

            # -- Squeeze dimensions to make easy operations on datasets
            #    (prevent from A(x,y)*B(x,y,height10M):
            #    instead of using squeeze try to select here only those
            #    parts/dimensions of self.DSref and self.DSproof
            #    which are not belonging to the coordinates related to dim_z, dim_xy
            #    and dim_time (do that also within harmonizeGrid and not here)
            if self.DSdims_squeeze:
                self.DSref, self.DSproof = self.DSref.squeeze(), self.DSproof.squeeze()
            # -- Harmonize the spatial and temporal grid (for easy operations on
            #    dataarrays with xarray start with the temporal grid and vertical
            #    grid because this is manually done to prevent unwanted physics:
            self.DSproof, self.DSref = self.MetricCalcProg.HarmonizeTempGrid(
                dsetref = self.DSref,
                dsetmod = self.DSproof,
                posdimnames = self.cfgposdims,
                varnsref = self.varns_ref,
                varnsmod = self.varns_proof,
                unifreqme = self.cfgdatamining["target_EvalFrequency"]["method"],
            )
            self.DSproof, self.DSref = self.MetricCalcProg.HarmonizeVertGrid(
                dsetref = self.DSref,
                dsetmod = self.DSproof,
                posdimnames = self.cfgposdims,
                varnsref = self.varns_ref,
                varnsmod = self.varns_proof,
            )
            self.DSproof = self.MetricCalcProg.HarmonizeHoriGrid(
                dsetref = self.DSref,
                dsetmod = self.DSproof,
                posdimnames = self.cfgposdims,
                varnsref = self.varns_ref,
                varnsmod = self.varns_proof,
            )
        if self.DScount == "2Proof1Ref":
            self.DSfile_skillref = DSfile_skillref
            self.varns_skillref = varnames_skillref
            self.DSskillref = self.daskopen(DSfile_skillref, varnames = varnames_skillref)

            if self.DSdims_squeeze:
                self.DSskillref = self.DSskillref.squeeze()

            self.DSskillref, self.DSref = self.MetricCalcProg.HarmonizeTempGrid(
                dsetref = self.DSref,
                dsetmod = self.DSskillref,
                posdimnames = self.cfgposdims,
                varnsref = self.varns_ref,
                varnsmod = self.varns_skillref,
                unifreqme = self.cfgdatamining["target_EvalFrequency"]["method"],
            )
            self.DSskillref, self.DSref = self.MetricCalcProg.HarmonizeVertGrid(
                dsetref = self.DSref,
                dsetmod = self.DSskillref,
                posdimnames = self.cfgposdims,
                varnsref = self.varns_ref,
                varnsmod = self.varns_skillref,
            )
            self.DSskillref = self.MetricCalcProg.HarmonizeHoriGrid(
                dsetref = self.DSref,
                dsetmod = self.DSskillref,
                posdimnames = self.cfgposdims,
                varnsref = self.varns_ref,
                varnsmod = self.varns_skillref,
            )

        # -- Define the final xarray-Dataset containing all the results of
        #    one metric group:
        self.FinalDS = xr.Dataset()

    @log_function_name
    def SolveDependencies(
        self: 'MetricCalc',
        metrics: List[str],
        metrfnam: str,
        metr_setup: Dict[str, Any],
        dirout: str,
    ) -> Tuple[
        Dict[str, str],
        Dict[str, str],
        Dict[str, Any],
        Dict[str, List[str]],
        Dict[str, List[str]],
        Dict[str, Any]
    ]:
        """
            Look for dependencies and try to compute them first;

            The second part of this method assumes that all single metrics chosen
            by the user are already splitted if	an option is given

            This routine can also be used to redefine metric list by considering
            the multiple options for one metric and extract many metrics

            Input variables:
            ----------------------------
                1. metrics --> user statistical parameters ['BIAS_temporal']
                2. metrfnam --> name of EvalMode (EvalRAW_temporal_)
                3. metr_setup --> user settings for statistical analysis
                                 (user can set them in general settings):
                    3.1 types (List[str])
                    3.2 typespec (Dict[str, Dict[str, int]])
                    3.3 skill_scores_skillref_idx (int)
                    3.4 BIAS_temporal (Dict[str, str])
                    3.5 BIASnorm_temporal
                    3.6 MAE_temporal
                    3.7 MAD_temporal
                    3.8 ....
                    3.9 LinCorrsigZOUm_temporal
                    3.10 LinCorrsigZOUs_temporal
                4. dirout --> output path

            Output variables:
            ----------------------------
                1. dep_fnam_ref -> stat_param: path to the file (reference)
                2. dep_fnam_proof -> stat_param: path to the file (model)
                3. dep_fnam_skill ->
                4. dep_varns_ref -> name of variable in refer dataset
                5. dep_varns_proof -> name of variable in model dataset
                6. dep_varns_skill ->
        """
        options: Dict[Any, Any] = {}
        for metricsgl in metrics:
            depcy = metr_setup[metricsgl]["dependency"]
            optlist = Genuti.check_for_list(metr_setup[metricsgl]["option"])
            if depcy is not None:
                if depcy in list(options.keys()):
                    options[depcy] = list(
                        set(Genuti.check_for_list(options[depcy]) + optlist)
                    )
                else:
                    options[depcy] = optlist

        # -- Resolve dependencies on options and get the right filenames and
        #    varnames for each metric
        dep_fnam_ref = Genuti.filldict(allkeys = metrics, fillval = self.DSfile_ref)
        dep_fnam_proof = Genuti.filldict(allkeys = metrics, fillval = self.DSfile_proof)
        dep_varns_ref = Genuti.filldict(allkeys = metrics, fillval = self.varns_ref)
        dep_varns_proof = Genuti.filldict(allkeys = metrics, fillval = self.varns_proof)

        if self.DScount == "2Proof1Ref":
            fillvalfnam, fillvalvarns = self.DSfile_skillref, self.varns_skillref
        else:
            fillvalfnam, fillvalvarns = None, None

        dep_fnam_skill = Genuti.filldict(allkeys = metrics, fillval = fillvalfnam)
        dep_varns_skill = Genuti.filldict(allkeys = metrics, fillval = fillvalvarns)

        for depcy in options.keys():
            logger.info(
                'Found dependencies for the recent metricgroup. Calculation needed.'
            )
            if depcy == "Contingency":
                for opt in options[depcy]:
                    logger.debug(f'Calculate for {depcy} the option {opt}')
                    fileref, fileproof, varnsref, varnsproof = self.Contingency(
                        threshld = opt, metrfnam = metrfnam, dirout = dirout,
                    )
                    for metricsgl in metrics:
                        depcysgl = metr_setup[metricsgl]["dependency"]
                        optsgl = metr_setup[metricsgl]["option"]
                        if depcysgl == depcy and optsgl == opt:
                            dep_fnam_ref[metricsgl] = fileref
                            dep_fnam_proof[metricsgl] = fileproof
                            dep_varns_ref[metricsgl] = varnsref
                            dep_varns_proof[metricsgl] = varnsproof
        # -- Return for each metric the depedencies on filenames and variables
        #    to process in final calculation
        return dep_fnam_ref, dep_fnam_proof, dep_fnam_skill, dep_varns_ref, dep_varns_proof, dep_varns_skill

    @log_function_name
    def Calculate(
        self: 'MetricCalc',
        metric: str,
        varnames_result: List[str],
        metr_option: Optional[Any] = None,
    ) -> None:
        """
            Decides for the different metrics;
            input contains the variable name(s) of the evaluation result and
            meta information about the dimensions w.r.t. to each variable in
            self.DSref

            Input variables:
            ----------------------------
                metric --> stat. parameter (BIAS_temporal)
                varnames_result --> stat. variable (['BIAS_temporal_hfls'])
                metr_option

            Output variables:
            ----------------------------
                Function return self.FinalDS

        """
        logger.debug("-- Timing: Before Calculation of the score")

        meta_dim = self.MetricCalcProg.FindDimsCoordsOfVariables(
            varnamelist = self.varns_ref, mode = 'dims', dataset = self.DSref,
        )
        dim_time = Genuti.SplitMetaDim(
            meta_dim, mode = 'temporal', PossibleDimDict = self.cfgposdims)
        dim_xy = Genuti.SplitMetaDim(
            meta_dim, mode = 'spatial', PossibleDimDict = self.cfgposdims)

        # -- Create to functions to be applied for metric calculations:
        funcoI, funcoImt, funcunit = self._func_method_wrapper(metricn = metric)

        logger.info(f"Rufe metric-Berechnung {metric} mit der Option: {metr_option}")
        # -- Do an ordered metric calculation:
        if self.MetricMode in ['temporal', 'spatial']:
            Datasetfinal = self.TemporalSpatialMetric(
                funcTs = funcoI,
                funcTm = funcoImt,
                funcUnit = funcunit,
                varns_result = varnames_result,
                aggregtime = self.aggregatetime_mode,
                dim_time = dim_time,
                dim_xy = dim_xy,
                metr_option = metr_option,
            )

        if self.MetricMode == 'skill_temporal':
            Datasetfinal = self.TemporalSkillMetric(
                funcTs = funcoI,
                funcTm = funcoImt,
                funcUnit = funcunit,
                varns_result = varnames_result,
                aggregtime = self.aggregatetime_mode,
                dim_time = dim_time,
                metr_option = metr_option,
            )
        logger.debug("-- Timing: After Calculation of the score")
        # -- Get final dataset:
        self.FinalDS = xr.merge([self.FinalDS, Datasetfinal])
        # -- Close dataset:
        self.safe_close_objects('Failed to close the dataset Datasetfinal', Datasetfinal)

    @log_function_name
    def Update_Attributes(
        self: 'MetricCalc', Datasetobj: xr.Dataset, variable: str,
        stdname: Optional[str] = None,
        units: Optional[str] = None,
        longname: Optional[str] = None,
    ) -> None:
        """ Updates the attributes for variables originating from a metric calculation:"""
        if stdname is not None:
            Datasetobj[variable].attrs['standard_name'] = stdname
        if units is not None:
            Datasetobj[variable].attrs['units'] = units
        if longname is not None:
            Datasetobj[variable].attrs['long_name'] = longname

    @log_function_name
    def RepairProcess(self: 'MetricCalc') -> None:
        """ Repair the destroyed time coordinate from the groupby-method
            (name 'month' instead of 'time'),
            use hardcoded-coordinate name 'time'
        """
        if self.RepairTime['Needed']:
            self.FinalDS = self.MetricCalcProg.RepairProcessTime(
                datrepair = self.FinalDS,
                RepairTimeP = self.RepairTime,
                groupby_mode = self.aggregatetime_mode,
            )
            logger.debug("The final dataset is repaired.")

    @log_function_name
    def Finalize(self: 'MetricCalc'):
        """ Exiting the class by closing all files opened: """
        import traceback
        try:
            # -- Local variables:
            msg_ds2close = 'Failed to close the dataset'
            # -- Close datasets:
            if self.DScount == "1Proof1Ref":
                self.safe_close_objects(f'{msg_ds2close} self.DSref', self.DSref)
                self.safe_close_objects(f'{msg_ds2close} self.DSproof', self.DSproof)

            if self.DScount == "2Proof1Ref":
                self.safe_close_objects(f'{msg_ds2close} self.DSskillref', self.DSskillref)

            # -- Run repair if needed:
            if self.RepairTime:
                logger.debug("[Finalize] RepairTime is enabled. Calling RepairProcess().")
                self.RepairProcess()

            # -- Write final result file in case of option result file is given:
            if self.fname_result is not None:
                # deb
                logger.debug(f"[Finalize] fname_result = {self.fname_result}")
                if self.FinalDS is None:
                    logger.error("self.FinalDS is None before writing!")
                    raise ValueError("self.FinalDS is None")

                if not isinstance(self.FinalDS, xr.Dataset):
                    logger.error(f"self.FinalDS is not a Dataset but {type(self.FinalDS)}")
                    raise TypeError("self.FinalDS is not a valid xarray.Dataset")

                if self.FinalDS.nbytes == 0:
                    logger.warning("FinalDS exists but is empty (0 bytes)")

                logger.debug(f"[Finalize] FinalDS nbytes = {self.FinalDS.nbytes}")

                logger.debug('--- FinalDS Diagnostic Summary ---')
                logger.debug(f"Variables in FinalDS: {list(self.FinalDS.data_vars)}")
                for var in self.FinalDS.data_vars:
                    data = self.FinalDS[var]
                    logger.debug(f"  -> {var}: dims={data.dims}, shape={data.shape}, dtype={data.dtype}")
                logger.debug(f"FinalDS total size (MB): {self.FinalDS.nbytes / 1024**2:.2f}")
                # end deb

                if self.FinalDS.nbytes == 0:
                    logger.debug("The dataset is empty. No file needs to be written.")

                elif os.access(self.fname_result, os.F_OK) and (self.FinalDS.nbytes > 0):
                    logger.debug("[Finalize] Existing result file detected. Merging with current FinalDS.")
                    ExistingResF = xr.open_dataset(self.fname_result)
                    self.FinalDS = xr.merge([self.FinalDS, ExistingResF])

                    # -- deb
                    logger.debug("[Finalize] After merge - FinalDS variables:")
                    for var in self.FinalDS.data_vars:
                        data = self.FinalDS[var]
                        logger.debug(f"  -> {var}: dims={data.dims}, shape={data.shape}, dtype={data.dtype}")

                    logger.debug(f"[Finalize] Dataset structure: dims={self.FinalDS.dims}, vars={list(self.FinalDS.data_vars.keys())}")
                    logger.debug(f"[Finalize] Dataset chunking: { {k: v.chunks for k,v in self.FinalDS.data_vars.items() if hasattr(v, 'chunks')} }")
                    logger.debug(f"[Finalize] Dataset nbytes: {self.FinalDS.nbytes}")
                    # end

                    for var in self.FinalDS.data_vars:
                        data = self.FinalDS[var]
                        logger.debug(f"[Finalize:Deep] '{var}': dims={data.dims}, shape={data.shape}, dtype={data.dtype}")
                        if hasattr(data, 'chunks'):
                            logger.debug(f"[Finalize:Deep] '{var}': chunks={data.chunks}")
                        try:
                            # This will raise if dask graph is broken
                            data.load()
                        except Exception as e:
                            logger.error(f"[Finalize:Deep] ERROR loading variable '{var}': {e}")
                            raise

                    # -- Save to NetCDF:
                    self.FinalDS.to_netcdf(f"{self.fname_result}new")
                    logger.debug("The results with metrics were combined into netcdf.")

                    # -- Close both datasets, otherwise the content remains in memory:
                    self.safe_close_objects(f'{msg_ds2close} self.FinalDS', self.FinalDS)
                    self.safe_close_objects(f'{msg_ds2close} ExistingResF', ExistingResF)
                    sp.check_call(
                        ["sh", "-c", "mv " + self.fname_result + 'new' + " " + self.fname_result])
                    logger.debug(f"[Finalize] File moved to final destination: {self.fname_result}")

                else:
                    logger.debug("[Finalize] No existing result file. Writing new dataset.")

                    logger.debug(f"[Finalize] Dataset structure: dims={self.FinalDS.dims}, vars={list(self.FinalDS.data_vars.keys())}")
                    logger.debug(f"[Finalize] Dataset chunking: { {k: v.chunks for k,v in self.FinalDS.data_vars.items() if hasattr(v, 'chunks')} }")
                    logger.debug(f"[Finalize] Dataset nbytes: {self.FinalDS.nbytes}")

                    self.FinalDS.to_netcdf(self.fname_result)
                    logger.debug("The result with first metric was written.")
                    self.safe_close_objects(f'{msg_ds2close} self.FinalDS', self.FinalDS)
            else:
                logger.error("[Finalize] No file specified for the final results")
                raise Exception("No file specified for the final results")

        except Exception as e:
            logger.error("[Finalize] Exception occurred:")
            logger.error(traceback.format_exc())
            raise

    @log_function_name
    def safe_close_objects(
        self: 'MetricCalc', errmsg: str, DSobject: xr.Dataset,
        errhandle: Optional[bool] = True,
    ) -> None:
        """
        Attempt to close the dataset object safely, handling any exceptions that occur.

        Parameters:
        ----------------------------
            1. self --> Instance of the MetricCalc class.
            2. errmsg --> Error message to be displayed if closing the dataset fails.
            3. DSobject --> dataset object to be closed.
            4. errhandle --> Flag indicating whether to handle the error.

        Returns:
        ----------------------------
            None. Function close dataset
        """
        try:
            DSobject.close()
        except:
            if errhandle:
                raise NameError(errmsg)
            else:
                return None

    @log_function_name
    def _func_method_wrapper(self, metricn: Optional[str] = None) -> Tuple[Optional[Callable], Callable, str]:
        """
        Determine and return the appropriate computation functions and metadata for the given metric name.

        This internal helper method retrieves two callable functions (if available) for a given metric name:
        - `func1`: The base metric function applied to each timestep (can be `None` for non-timestep metrics).
        - `func2`: The aggregated metric function (e.g., time-mean, spatial-mean).
        - `funcunit`: The unit string for labeling output results.
        It also sets flags for special handling like `inf2nan` or `nanunique`, and updates internal variables
        used for label descriptions and error handling.

        Parameters:
        -----------
        metricn : str, optional
            Name of the metric to retrieve. Supports exact match or prefix match (e.g., "RMSE_temporal").

        Returns:
        --------
        Tuple[Optional[Callable], Callable, str]
            - func1: First-stage metric function (may be None for metrics without timestep computation)
            - func2: Aggregated metric function
            - funcunit: Unit string for the metric's output

        Raises:
        -------
        ValueError:
            If the metric name is unknown or not registered in the internal metric catalog.

        Side Effects:
        -------------
        Sets the following internal attributes:
        - self.func_longvar : str
            Descriptive label used in plots (e.g., "temporal RMSE of")
        - self.func_noaggregerrmsg : str or None
            Message shown if user tries to compute a per-step metric that is invalid
        - self.func_nanunique : bool
            Set to True if metric requires counting of NaN-unique values
        - self.func_inf2nan : bool
            Set to True if metric needs `inf` values replaced by `NaN`
        """
        # -- Special metrics with nanunique attribute:
        metrics_with_nanunique = [
            'LinCorr_temporal', 'LinCorr_spatial', 'KlingGupta_temporal', 'quantile_bias_temporal',
            'quantile_mae_temporal', 'quantile_iqd_temporal', 'pdf_pss_temporal', 'LinCorrsigZOUm_temporal',
            'LinCorrsigZOUs_temporal',
        ]
        metrics_with_inf2nan = [
            'KlingGupta', 'quantile', 'pdf_pss', 'FAR_', 'POD_', 'SUCRATIO_',
            'LOG-ODDS-R_', 'ETS_', 'SEDI_',
        ]
        # -- Set standard values which are only changed in some metrics:
        self.func_inf2nan = False
        self.func_nanunique = False

        # -- Catalog of metrics:
        logger.debug(f"Normalized metric name: {metricn}")
        metric_functions = {
            # -- BIAS and relatives:
            #    BIAS(x,y) = 1/N{dim_t} * SUM_{dim_t} ( MOD(x,y,t) - OBS(x,y,t) )
            'BIAS_temporal': (dmf.Tbias, dmf.Tbiasmean, dmf.units_stay, 'temporal BIAS of ', None),
            #    BIAS(x,y) = 1/N{dim_t} * SUM_{dim_t} ( MOD(x,y,t) - OBS(x,y,t) ) /mean(OBS)
            'BIASnorm_temporal': (dmf.Tbiasnorm, dmf.Tbiasnormmean, dmf.units_one, 'temporal relative BIAS of ', None),
            #    BIAS(t) = 1/N{dim_xy} * SUM_{dim_xy} ( MOD(x,y,t) - OBS(x,y,t) )
            'BIAS_spatial': (dmf.Sbias, dmf.Sbiasmean, dmf.units_stay, 'spatial BIAS of ', None),
            #    BIAS(t) = 1/N{dim_xy} * SUM_{dim_xy} ( MOD(x,y,t) - OBS(x,y,t) ) /mean(OBS)
            'BIASnorm_spatial': (dmf.Sbiasnorm, dmf.Sbiasnormmean, dmf.units_one, 'spatial relative BIAS of ', None),

            # -- MAE, MAD:
            #    MAE(x,y) = 1/N{dim_t} * SUM_{dim_t} ABS( MOD(x,y,t) - OBS(x,y,t) )
            'MAE_temporal': (dmf.Tmae, dmf.Tmaemean, dmf.units_stay, 'temporal MAE of ', None),
            #    MAE(t) = 1/N{dim_xy} * SUM_{dim_xy} ABS( MOD(x,y,t) - OBS(x,y,t) )
            'MAE_spatial': (dmf.Smae, dmf.Smaemean, dmf.units_stay, 'spatial MAE of ', None),
            #    MAE(x,y) = MEDIAN ( MOD(x,y,t) - MEDIAN(OBS(x,y,t)) )
            'MAD_temporal': (dmf.Tmad, dmf.Tmadmean, dmf.units_stay, 'temporal MAD of ', None),
            #    MAE(x,y) = MEDIAN ( MOD(x,y,t) - MEDIAN(OBS(x,y,t)) )
            'MAD_spatial': (dmf.Smad, dmf.Smadmean, dmf.units_stay, 'spatial MAD of ', None),

            # -- RMSE:
            #    RMSE(x,y) = SQRT( 1/N{dim_t} * SUM_{dim_t} ( MOD(x,y,t) - OBS(x,y,t) )^2 )
            'RMSE_temporal': (
                dmf.Trmse, dmf.Trmsemean, dmf.units_stay, 'temporal RMSE of ',
                'The RMSE_temporal computation makes no sense for each single time step '
            ),
            #    RMSE(x,y) = SQRT( 1/N{dim_t} * SUM_{dim_t} ( MOD(x,y,t) - OBS(x,y,t) - BIAS(x,y) )^2 )
            'RMSEbcn_temporal': (
                dmf.Trmsebcn, dmf.Trmsebcnmean, dmf.units_stay, 'temporal bias-cor. RMSE of ',
                'The RMSEbc_temporal computation makes no sense for each single time step '
            ),
            #    RMSE(t) = SQRT( 1/N{dim_xy} * SUM_{dim_xy} ( MOD(x,y,t) - OBS(x,y,t) )^2 )
            'RMSE_spatial': (dmf.Srmse, dmf.Srmsemean, dmf.units_stay, 'spatial RMSE of ', None),

            # -- Correlation:
            #    LinCorr(x,y) = ??? --> no single time step rate -> None for 1st function
            'LinCorr_temporal': (
                None, dmf.Tcorrelmean, dmf.units_one, 'temporal lin. correl. of ',
                'The Linear Corr. computation makes no sense for each single time step '
            ),
            #    LinCorr(t) = ???
            'LinCorr_spatial': (dmf.Scorrel, dmf.Scorrelmean, dmf.units_one, 'spatial lin. correl. of ', None),

            # -- Kling-Gupta:
            #    no single time step rate -> None for 1st function:
            'KlingGupta_temporal': (
                None, dmf.Tklingcuptamean, dmf.units_one, 'Kling-Gupta coeff. of ',
                'The Kling-Gupta computation makes no sense for each single time step '
            ),

            # -- Distribution-based:
            #    # no single time step rate -> None for 1st function
            'quantile_bias_temporal': (
                None, dmf.quantile_bias_temporal, dmf.units_stay, 'BIAS in quantiles of ',
                'The BIAS in quantiles makes no sense for each single time step '
            ),
            'quantile_mae_temporal': (
                None, dmf.quantile_mae_temporal, dmf.units_stay, 'MAE in quantiles of ',
                'The MAE in quantiles makes no sense for each single time step '
            ),
            'quantile_iqd_temporal': (
                None, dmf.quantile_iqd_temporal, dmf.units_rmse, 'IQD of quantiles of ',
                'The IQD of quantiles makes no sense for each single time step '
            ),
            'pdf_pss_temporal': (
                None, dmf.pdf_pss_temporal, dmf.units_one, 'Perkins Skill Score of ',
                'The PSS of distribution makes no sense for each single time step '
            ),

            # -- Skill scores:
            #    Compute the Mean Squared Error skill Score:
            'AMSESS_temporal': (
                dmf.Tamsess, dmf.Tamsessmean, dmf.units_one, 'temporal AMSESS of ',
                'The computation of a modified MSE skill score makes no sense for each single time step '
            ),

            # -- Significance metrics:
            #    Compute MSE skill score and check for difference on moderate significance levels (moderately, strongly)::
            'AMSESSsigm_temporal': (
                None, dmf.TamsessBSSmean, dmf.units_one,
                'signicant better RMSE for model: ',
                'The computation of significance makes no sense for each single time step '
            ),
            'AMSESSsigs_temporal': (
                None, dmf.TamsessBSSmean, dmf.units_one,
                'signicant better RMSE for model: ',
                'The computation of significance makes no sense for each single time step '
            ),

            #    Compute BIAS and check for difference weak significance levels (moderately, strongly):
            'BIASsigJEm_temporal': (
                None, dmf.TbiasdiffJESmean, dmf.units_one,
                'moderately signicant better BIAS for model: ',
                'The computation of significance makes no sense for each single time step '
            ),
            'BIASsigJEs_temporal': (
                None, dmf.TbiasdiffJESmean, dmf.units_one,
                'strongly signicant better BIAS for model: ',
                'The computation of significance makes no sense for each single time step '
            ),

            #    Compute BIAS and check for difference weak significance levels (moderately, strongly):
            #    https://www.jmp.com/en_ch/statistics-knowledge-portal/t-test/two-sample-t-test.html
            'BIASsigTTm_temporal': (
                None, dmf.TbiasdiffTTSmean, dmf.units_one,
                'moderately signicant better BIAS for model: ',
                'The computation of significance makes no sense for each single time step '
            ),
            'BIASsigTTs_temporal': (
                None, dmf.TbiasdiffTTSmean, dmf.units_one,
                'strongly signicant better BIAS for model: ',
                'The computation of significance makes no sense for each single time step '
            ),

            #    Compute BIAS and check for difference on weak significance levels (moderately, strongly):
            'BIASsigBSm_temporal': (
                None, dmf.TbiasdiffBSSmean, dmf.units_one,
                'moderately signicant better BIAS for model: ',
                'The computation of significance makes no sense for each single time step '
            ),
            'BIASsigBSs_temporal': (
                None, dmf.TbiasdiffBSSmean, dmf.units_one,
                'strongly signicant better BIAS for model: ',
                'The computation of significance makes no sense for each single time step '
            ),

            #    Compute MAE and check for difference on weak significance levels (moderately, strongly):
            'MAEsigBSm_temporal': (
                None, dmf.TmaediffBSSmean, dmf.units_one,
                'moderately signicant better MAE for model: ',
                'The computation of significance makes no sense for each single time step '
            ),
            'MAEsigBSs_temporal': (
                None, dmf.TmaediffBSSmean, dmf.units_one,
                'strongly signicant better MAE for model: ',
                'The computation of significance makes no sense for each single time step '
            ),

            #    Compute MAD and check for difference on weak significance levels (moderately, strongly):
            'MADsigBSm_temporal': (
                None, dmf.TmaddiffBSSmean, dmf.units_one,
                'moderately signicant better MAD for model: ',
                'The computation of significance makes no sense for each single time step '
            ),
            'MADsigBSs_temporal': (
                None, dmf.TmaddiffBSSmean, dmf.units_one,
                'strongly signicant better MAD for model: ',
                'The computation of significance makes no sense for each single time step '
            ),

            #    Compute RMSE and check for difference on weak significance levels (moderately, strongly):
            'RMSEsigJEm_temporal': (
                None, dmf.TrmsediffJESmean, dmf.units_one,
                'moderately signicant better RMSE for model: ',
                'The computation of significance makes no sense for each single time step '
            ),
            'RMSEsigJEs_temporal': (
                None, dmf.TrmsediffJESmean, dmf.units_one,
                'strongly signicant better RMSE for model: ',
                'The computation of significance makes no sense for each single time step '
            ),

            #    Compute RMSE and check for difference on weak significance levels (moderately, strongly):
            'RMSEsigBSm_temporal': (
                None, dmf.TrmsediffBSSmean, dmf.units_one,
                'moderately signicant better RMSE for model: ',
                'The computation of significance makes no sense for each single time step '
            ),
            'RMSEsigBSs_temporal': (
                None, dmf.TrmsediffBSSmean, dmf.units_one,
                'strongly signicant better RMSE for model: ',
                'The computation of significance makes no sense for each single time step '
            ),

            #    Compute temporal correlation and check for difference on weak significance leves (moderately, strongly):
            #    a) https://cran.r-project.org/web/packages/cocor/cocor.pdf b) https://garstats.wordpress.com/2019/07/12/compcorrcov/
            #    c) https://seriousstats.wordpress.com/2012/02/05/comparing-correlations/
            #    d) https://imaging.mrc-cbu.cam.ac.uk/statswiki/FAQ/rsqdiff
            'LinCorrsigZOUm_temporal': (
                None, dmf.TcorrelZOUSmean, dmf.units_one,
                'moderately signicant better Pearson correlation for model: ',
                'The computation of significance makes no sense for each single time step '
            ),
            'LinCorrsigZOUs_temporal': (
                None, dmf.TcorrelZOUSmean, dmf.units_one,
                'strongly signicant better Pearson correlation for model: ',
                'The computation of significance makes no sense for each single time step '
            ),

            # -- Contingency metrics by prefix:
            #    Documentation: http://www.cawcr.gov.au/projects/verification/verif_web_page.html
            #    1. Accuracy rate based on a boolean contingency-based data
            #       ACCURACY(x,y) = (HITS+CORRREJ)/(TOTAL)
            'ACCURACY_': (
                None, dmf.Taccuracy, dmf.units_one, 'Accuracy rate of ',
                'The accuracy computation makes no sense for each single time step'
            ),
            #    2. The False Alarm rate based on boolean contingency data
            #       FalseAlarmRatio(x,y) = (FALSEALARM)/(HITS+FALSEALARMS)
            'FAR_': (
                None, dmf.Tfalsealarm, dmf.units_one, 'False alarm ratio of ',
                'The FalseAlarmRatio computation makes no sense for each single time step'
            ),
            #    3. The Probability of detection based on boolean contingency data
            #       POD(x,y) = (HITS)/(HITS+MISSES)
            'POD_': (
                None, dmf.Tprobofdetect, dmf.units_one, 'Probab. of Detect. for ',
                'The ProbabilityOfDetection computation makes for each single time step'
            ),
            #    4. The SuccessRatio based on boolean contingency data
            #       SUCRATIO(x,y) = (HITS)/(HITS+FALSEALARMS)
            'SUCRATIO_': (
                None, dmf.Tsuccessratio, dmf.units_one, 'Success Ratio of ',
                'The SuccessRatio computation makes no sense for single dates'
            ),
            #    5. The LogOddsRatio based on boolean contingency data
            #       LOGODDS(x,y) = LOG(HITS*CORRREJ)/(FALSEALARMS*MISSES)
            #           >0  : the hit rate exceeds the False alarm rate
            #           0..1: the forecast is no more skillful than random forecast
            #           >1  : indicate a significant skillful forecast
            'LOG-ODDS-R_': (
                None, dmf.Tlogoddsratio, dmf.units_one, 'Log-Odds-ratio of ',
                'The Log-Odds-ratio computation makes no sense for single dates'
            ),
            #    6. The Equitable thread score based on boolean contingency data
            #       ETS(x,y) = (HITS - HITSrandom) / (HITS + MISSES + FALSEALARMS - HITSrandom)
            #       with HITSrandom being ( (HITS+MISSES)*(HITS+FALSEALARMS) )/(TOTAL);
            'ETS_': (
                None, dmf.Tequitthreadsc, dmf.units_one, 'Equitable Threat Score of ',
                'The EquitableThreatScore computation makes no sense for single dates'
            ),
            #    7. The Symmetric Extremal Dependency Index based on contigency
            #       SEDI(x,y) = ( logF-logH-log(1-F)+log(1-H) )/( logF+logH+log(1-F)+log(1-H) )
            #       with H being the hitrate and F being the False alarm rate; presentation DWD;
            #       interpretation rules still missing
            'SEDI_': (
                None, dmf.Tsediratio, dmf.units_one, 'SEDI ratio of ',
                'The (Symmetric Extremal Dependency Index) computation makes no sense for single dates'
            ),
        }

        # -- Define metrics:
        for key, (func1, func2, funcunit, longvar, errmsg) in metric_functions.items():
            if metricn == key or metricn.startswith(key):
                self.func_longvar = longvar
                self.func_noaggregerrmsg = errmsg
                if metricn in metrics_with_nanunique:
                    self.func_nanunique = True
                if any(k in key for k in metrics_with_inf2nan):
                    self.func_inf2nan = True
                logger.debug(
                    "\n--- Metric Configuration ---\n"
                    f"Metric key           : {key}\n"
                    f"Long variable name   : {self.func_longvar}\n"
                    f"No-aggregate error  : {self.func_noaggregerrmsg}\n"
                    f"NaN unique handling : {self.func_nanunique}\n"
                    f"Inf → NaN handling  : {self.func_inf2nan}\n"
                    "-----------------------------\n"
                )
                return func1, func2, funcunit
        raise ValueError(f"Unknown or unregistered metric: {metricn}")

    @log_function_name
    def TemporalSpatialMetric(
        self: 'MetricCalc',
        funcTs: Callable[..., Any],
        funcTm: Callable[..., Any],
        funcUnit: Callable[..., Any],
        varns_result: List[str],
        aggregtime: str,
        dim_time: Dict[str, List[str]],
        dim_xy: Dict[str, List[str]],
        metr_option: Optional[Any] = None,
    ) -> xr.Dataset:
        """ The function for Spatial and Temporal Metrics using the function wrapper:

            Input variables:
            ----------------------------
            1. funcTs --> user function from def_Metric_formulae or None
            2. funcTm --> user function from def_Metric_formulae
            3. funcUnit --> user function for units from def_Metric_formulae
            4. varns_result -->  research parameter
            5. aggregtime --> type of aggregation (fullperiod)
            6. dim_time --> time variable in NetCDF
            7. dim_xy --> lon and lat varibles in NetCDF
            8. metr_option --> extra settings for compution. It can to be a
                a. significance level for the next functions
                    TamsessBSSmean --> (defualt - 0.05),
                    TbiasdiffJESmean --> (defualt - 0.05),
                    TbiasdiffTTSmean --> (defualt - 0.05),
                    TbiasdiffBSSmean --> (defualt - 0.05),
                    TmaediffBSSmean --> (defualt - 0.05),
                    TmaddiffBSSmean --> (defualt - 0.05),
                    TrmsediffJESmean --> (defualt - 0.05),
                    TrmsediffBSSmean --> (defualt - 0.05),
                    TcorrelZOUSmean --> (defualt - 0.075),
                b dictionary with user properties:
                    pdf_pss_temporal --> (defualt - {'biascor': False, 'binlimits': None}))
                    quantile_bias_temporal --> (defualt - {'biascor': False, 'quantiles': [0.2, 0.4, 0.6, 0.8]})
                    quantile_mae_temporal --> (defualt - {'biascor': False, 'quantiles': [0.2, 0.4, 0.6, 0.8]})
                    quantile_iqd_temporal --> (defualt - {'biascor': False, 'quantiles': [0.2, 0.4, 0.6, 0.8]})
        """
        # -- Control None values in dim_time and dim_xy variables:
        if dim_time is None or dim_xy is None:
            raise ValueError(
                'TemporalSpatialMetric: dim_time or dim_xy variables are equal None')

        endresult = xr.Dataset()
        for varnsproof, varnsref, varnsres in zip(self.varns_proof, self.varns_ref, varns_result):
            if self.func_nanunique is True:
                # -- Ensure that only time/location is considerd being present
                #    in both datasets (otherwise some metrics could be reach
                #    unphysical values, i.e. LC>1.0)
                self.DSproof = self.DSproof[varnsproof].where(
                    self.DSref[varnsref].notnull().data).to_dataset(name = varnsproof)

                self.DSref = self.DSref[varnsref].where(
                    self.DSproof[varnsproof].notnull().data).to_dataset(name = varnsref)

            # -- Rename the data variables and combine both datasets for evaluation:
            daref, daproof = f"{varnsres}_ref", f"{varnsres}_mod"
            self.DSref = self.DSref.rename({varnsref: daref})
            self.DSproof = self.DSproof.rename({varnsproof: daproof})

            DScomb = xr.merge([self.DSref, self.DSproof], compat = 'override')
            # -- Extract the name of time coordinate:
            coordtime = self.MetricCalcProg.ListDimsToXarray(dim_time[varnsref])
            # -- Only needed for spatial op.:
            coordxy = self.MetricCalcProg.ListDimsToXarray(dim_xy[varnsref])
            # -- Do the computation dependent on aggregation:
            if aggregtime == 'fullperiod':
                DSnew = funcTm(
                    DScomb,
                    daproof = daproof,
                    daref = daref,
                    coordtime = coordtime,
                    coordxy = coordxy,
                    option = metr_option,
                ).to_dataset(name = varnsres)
                self.RepairTime.update({'Needed': True})
                self.RepairTime['tlost'] = (
                    self.DSref[coordtime].data[0] +
                    (self.DSref[coordtime].data[-1] - self.DSref[coordtime].data[0]) / 2.0
                )
                self.RepairTime.update({'timeref': self.DSref[coordtime]})

            elif aggregtime == '-':
                if funcTs is not None:
                    DSnew = funcTs(
                        DScomb,
                        daproof = daproof,
                        daref = daref,
                        coordtime = coordtime,
                        coordxy = coordxy,
                        option = metr_option,
                    ).to_dataset(name = varnsres)
                    self.RepairTime.update({'Needed': False})
                else:
                    raise ValueError(self.func_noaggregerrmsg)

            elif "overperiod" in aggregtime:
                grpby_method = self.MetricCalcProg.ags.ConvertAggregKey2Groupby(aggregtime)
                DSnew = DScomb.groupby(coordtime + '.' + grpby_method).apply(
                    funcTm,
                    daproof = daproof,
                    daref = daref,
                    coordtime = coordtime,
                    coordxy = coordxy,
                    option = metr_option,
                )
                DSnew = DSnew.to_dataset(name = varnsres)

                # -- Update properties:
                self.RepairTime.update({'Needed': True})
                self.RepairTime.update({'start': self.DSref[coordtime].data[0]})
                self.RepairTime.update({'end': self.DSref[coordtime].data[-1]})
                self.RepairTime.update({'timeref': self.DSref[coordtime]})

            elif "overperiod" not in aggregtime:
                resamplefreq = self.MetricCalcProg.ags.ConvertAggregKey2Resample(aggregtime)

                DSnew = DScomb.resample(time = resamplefreq).apply(
                    funcTm,
                    daproof = daproof,
                    daref = daref,
                    coordtime = coordtime,
                    coordxy = coordxy,
                    option = metr_option,
                )
                DSnew = DSnew.to_dataset(name = varnsres)

                for var in DSnew.data_vars:
                    print(f"Attributes for variable '{var}' after2:")
                    print(DSnew[var].attrs)
                    print("-" * 40)

                # -- Resampling destroys time attributes:
                self.RepairTime.update({'Needed': True})
                self.RepairTime.update({'timeref': self.DSref[coordtime]})

            del DScomb
            logger.debug(f"GRIDS After calculation the metrices '{DSnew.sizes}'")

            # -- Replace infinity values with nan-values:
            if self.func_inf2nan is True:
                DSnew[varnsres].data[np.isinf(DSnew[varnsres].data)] = np.nan
            # -- Rename back:
            self.DSref = self.DSref.rename({daref: varnsref})
            self.DSproof = self.DSproof.rename({daproof: varnsproof})
            # -- Define new units and names:
            unitsold = Genuti.safe_access_bib(
                '',
                KeyError,
                dicttest = self.DSref[varnsref].attrs,
                dictkey = 'units',
                errhandle = False,
            )
            if unitsold is None:
                unitsold = '-'

            unitsnew = funcUnit(units = unitsold)
            # -- Get long name of variable from self.DSref[varnsref]
            longvarold = Genuti.safe_access_bib(
                '',
                KeyError,
                dicttest = self.DSref[varnsref].attrs,
                dictkey = 'long_name',
                errhandle = False,
            )
            # -- Create a new name of variable:
            longvarnew = f'{self.func_longvar} {longvarold}'

            self.Update_Attributes(
                Datasetobj = DSnew,
                variable = varnsres,
                stdname = varnsres,
                units = unitsnew,
                longname = longvarnew,
            )
            endresult = xr.merge([endresult, DSnew])
            del DSnew
        return endresult

    @log_function_name
    def TemporalSkillMetric(
        self: 'MetricCalc',
        funcTs: Callable[..., Any],
        funcTm: Callable[..., Any],
        funcUnit: Callable[..., Any],
        varns_result: List[str],
        aggregtime: str,
        dim_time: Dict[str, List[str]],
        metr_option: Optional[Any] = None,
    ) -> xr.Dataset:
        """ The function for the Skill Metrics using the function wrapper:"""
        # -- Control None values in dim_time and dim_xy variables:
        if dim_time is None:
            raise ValueError(
                'TemporalSkillMetric: dim_time variable is equal None')

        endresult = xr.Dataset()
        for varnsskillref, varnsproof, varnsref, varnsres in zip(
                self.varns_skillref, self.varns_proof, self.varns_ref, varns_result):
            if self.func_nanunique is True:
                # -- Ensure that only time/location is considerd being present
                #    in both datasets (otherwise some metrics could be reach
                #    unphysical values, i.e. LC>1.0):
                self.DSproof = self.DSproof[varnsproof].where(
                    self.DSref[varnsref].notnull()).to_dataset(name = varnsproof)

                self.DSref = self.DSref[varnsref].where(
                    self.DSproof[varnsproof].notnull()).to_dataset(name = varnsref)

                self.DSskillref = self.DSskillref[varnsskillref].where(
                    self.DSref[varnsref].notnull()).to_dataset(name = varnsskillref)

            # -- Rename the data variables and combine both datasets for evaluation:
            daref, daproof = f'{varnsres}_ref', f'{varnsres}_mod'
            daskillref = f'{varnsres}_skill'
            self.DSref = self.DSref.rename({varnsref: daref})
            self.DSproof = self.DSproof.rename({varnsproof: daproof})
            self.DSskillref = self.DSskillref.rename({varnsskillref: daskillref})

            DScomb = xr.merge(
                [self.DSref, self.DSproof, self.DSskillref], compat = 'override',
            )
            # -- Extract the name of time coordinate:
            coordtime = self.MetricCalcProg.ListDimsToXarray(dim_time[varnsref])
            # -- Do the computation dependent on aggregation:
            if aggregtime == 'fullperiod':
                DSnew = funcTm(
                    DScomb,
                    daproof = daproof,
                    daref = daref,
                    daskillref = daskillref,
                    coordtime = coordtime,
                    option = metr_option,
                ).to_dataset(name = varnsres)
                self.RepairTime.update({'Needed': True})
                self.RepairTime['tlost'] = (
                    self.DSref[coordtime].data[0] +
                    (self.DSref[coordtime].data[-1] - self.DSref[coordtime].data[0]) / 2.0
                )
                self.RepairTime.update({'timeref': self.DSref[coordtime]})

            elif aggregtime == '-':
                if funcTs is not None:
                    DSnew = funcTs(
                        DScomb,
                        daproof = daproof,
                        daref = daref,
                        daskillref = daskillref,
                        coordtime = coordtime,
                        option = metr_option,
                    ).to_dataset(name = varnsres)
                    self.RepairTime.update({'Needed': False})
                else:
                    logger.error(self.func_noaggregerrmsg)
                    raise ValueError(self.func_noaggregerrmsg)

            elif "overperiod" in aggregtime:
                grpby_method = self.MetricCalcProg.ags.ConvertAggregKey2Groupby(aggregtime)
                DSnew = DScomb.groupby(coordtime + '.' + grpby_method).apply(
                    funcTm,
                    daproof = daproof,
                    daref = daref,
                    daskillref = daskillref,
                    coordtime = coordtime,
                    option = metr_option,
                )
                DSnew = DSnew.to_dataset(name = varnsres)
                self.RepairTime.update({'Needed': True})
                self.RepairTime.update({'start': self.DSref[coordtime].data[0]})
                self.RepairTime.update({'end': self.DSref[coordtime].data[-1]})
                self.RepairTime.update({'timeref': self.DSref[coordtime]})

            elif "overperiod" not in aggregtime:
                resamplefreq = self.MetricCalcProg.ags.ConvertAggregKey2Resample(aggregtime)
                DSnew = DScomb.resample(time = resamplefreq).apply(
                    funcTm,
                    daproof = daproof,
                    daref = daref,
                    daskillref = daskillref,
                    coordtime = coordtime,
                    option = metr_option,
                )
                DSnew = DSnew.to_dataset(name = varnsres)
                self.RepairTime.update({'Needed': False})
            del DScomb

            # -- Replace infinity values with nan-values:
            if self.func_inf2nan is True:
                DSnew[varnsres].data[np.isinf(DSnew[varnsres].data)] = np.nan
            # -- Rename back:
            self.DSref = self.DSref.rename({daref: varnsref})
            self.DSproof = self.DSproof.rename({daproof: varnsproof})
            self.DSskillref = self.DSskillref.rename({daskillref: varnsskillref})

            # -- Define new units and names:
            unitsold = Genuti.safe_access_bib(
                '',
                KeyError,
                dicttest = self.DSref[varnsref].attrs,
                dictkey = 'units',
                errhandle = False,
            )
            if unitsold is None:
                unitsold = '-'
            unitsnew = funcUnit(units = unitsold)
            longvarold = Genuti.safe_access_bib(
                '',
                KeyError,
                dicttest = self.DSref[varnsref].attrs,
                dictkey = 'long_name',
                errhandle = False,
            )
            longvarnew = f'{self.func_longvar} {longvarold}'
            self.Update_Attributes(
                Datasetobj = DSnew,
                variable = varnsres,
                stdname = varnsres,
                units = unitsnew,
                longname = longvarnew,
            )
            endresult = xr.merge([endresult, DSnew])
            del DSnew
        return endresult

    # The Methods resolving dependencies to the metrics (e.g. Contingency-Tables)
    @log_function_name
    def Contingency(
        self: 'MetricCalc',
        threshld = None,
        metrfnam = None,
        dirout = None,
    ):
        """ Compute the precursor for contigency tables and for a specific threshold:
            bool_fc(x,y,t) = 1 if (fc(x,y,t) > thresh) else 0 """
        # -- Define the new variable name prefix:
        logger.warning(
            "EvaSuite Warning: You are using an untested function.\n"
            "If possible, please send your configuration files to: "
            "evgenii.churiulin@kit.edu for testing and validation support."
        )
        varns_respre = f'Bool_thrs{threshld}_'
        DSrefnew, DSproofnew = xr.Dataset(), xr.Dataset()

        for varnsproof, varnsref in zip(self.varns_proof, self.varns_ref):
            # -- Ensure that only time stamps are considerd being present in
            #    both datasets (otherwise LC>1)
            # -- Harmonize the nan's between both datasets, part A:
            self.DSproof = self.DSproof[varnsproof].where(
                self.DSref[varnsref].notnull()).to_dataset(name = varnsproof)

            # -- Harmonize the nan's between both datasets, part B:
            self.DSref = self.DSref[varnsref].where(
                self.DSproof[varnsproof].notnull()).to_dataset(name = varnsref)
            #
            DSnew = xr.where(self.DSref[varnsref] > threshld, 1.0, 0.0)
            DSnew = DSnew.where(self.DSref[varnsref].notnull())
            # with numpy: DSnew[np.isnan(self.DSref[varnsref])] = np.nan
            # with numpy: DSnew = xr.DataArray(DSnew.reshape(self.DSref[varnsref].shape), \
            #      dims=self.DSref[varnsref].dims,coords=self.DSref[varnsref].coords)
            DSnew.attrs = self.DSref[varnsref].attrs
            DSnew = DSnew.to_dataset(name = varns_respre + varnsref)
            DSrefnew = xr.merge([DSrefnew, DSnew])
            del DSnew

            DSnew = xr.where(self.DSproof[varnsproof] > threshld, 1.0, 0.0)
            DSnew = DSnew.where(self.DSproof[varnsproof].notnull())
            # with numpy: DSnew[np.isnan(self.DSproof[varnsproof])] = np.nan
            # with numpy: DSnew = xr.DataArray(DSnew.reshape(self.DSproof[varnsproof].shape), \
            #      dims=self.DSproof[varnsproof].dims,coords=self.DSproof[varnsproof].coords)
            DSnew.attrs = self.DSproof[varnsproof].attrs
            DSnew = DSnew.to_dataset(name = varns_respre + varnsproof)
            DSproofnew = xr.merge([DSproofnew, DSnew])
            del DSnew
            #
        filerefnew = f"{dirout}/{metrfnam}_contingency_Refdata_{threshld}.nc"
        fileproofnew = f"{dirout}/{metrfnam}_contingency_Proofdata_{threshld}.nc"

        # -- Save new data as NetCDF:
        DSrefnew.to_netcdf(filerefnew)
        DSproofnew.to_netcdf(fileproofnew)
        # -- Closing of files is not needed because never opened:
        del DSrefnew
        del DSproofnew

        return filerefnew, fileproofnew, [varns_respre + varnsref for varnsref in self.varns_ref], \
            [varns_respre + varnsproof for varnsproof in self.varns_proof]
