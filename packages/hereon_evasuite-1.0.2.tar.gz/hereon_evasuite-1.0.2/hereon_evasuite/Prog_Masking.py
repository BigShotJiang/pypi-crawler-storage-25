# Evaluation Suite (EvaSuite)
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2026, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# -- Program classes for the Evaluation Suite:
# -- Import Python modules
import os
import xarray as xr
import geopandas as gpd
import regionmask
from typing import Any, Dict, List

# -- Import EvaSuite modules:
from hereon_evasuite.GeneralUtils import SuiteUtilities
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
GenUti = SuiteUtilities()
logger = get_logger()


# -- Start:
class Masking(object):
    @log_function_name
    def __init__(self: 'Masking', name: str, cfgprogram: Dict[str, str]) -> None:
        """Initialization of Prog_Masking. Program doesn't have return variables,
           but save data as a self.variable """
        self.name = name
        self.cfgprogram = cfgprogram
        #
        logger.debug(f"Program instance: {self.name}")


class PyRegionmask(Masking):
    @log_function_name
    def __init__(self: 'PyRegionmask', cfgprogram: Dict[str, str]):
        # -- Set a deligation rules for PyRegionmask class:
        super().__init__("PyRegionmask", cfgprogram)

    @log_function_name
    def CheckPolygons(
        self: 'PyRegionmask',
        polyfile: str,
        nameattrib: str,
        regions: List[str],
    ) -> List[Any]:
        """Work with polygon files:

            Input variables:
            ----------------------------
                1. polyfile -> absolute path to polygon file
                    /work/../EvaSuite_allpolygons_regiklim.gpkg
                2. nameattrib -> variable name of attribute (NAME_0)
                3. regions -> list of regions

            Output variables:
            ----------------------------
                1. List of uniq regions
        """
        shapef = gpd.read_file(polyfile)
        regsinshape = list(shapef[nameattrib])
        return list(set(regions) - set(regsinshape))

    @log_function_name
    def RegionMask(
        self: 'PyRegionmask',
        regions: List[str],
        targetgrid_ncfile: str,
        outputdir: str,
        polyfile: str,
        nameattrib: str,
    ) -> Dict[str, str]:
        """ Creating a netcdf-file containing the mask to each subregion;

            Notes:
            ----------------------------
            - returns a dictionary of the netcdf-file location and subregion;
            - regions: contains the subregion names
            - polyfile: contains polygon file
            - targetgrid_ncfile: is the grid  which needs to be masked;
            - outputdir: is the final directory where to store the masks;

            Input variables:
            ----------------------------
                1. regions -> list of regions ['Germany', 'P_Alps' ....]
                2. targetgrid_ncfile -> absolute path to NetCDF
                    (/scratch/../rr_ens_mean_0.1deg_reg_v25.0e.2014.nc_domcut_refgrid_FinalEvalGrid)
                3. outputdir -> path to the output folder
                    (/scratch/../Subregion_Masks/)
                4. polyfile -> path to the poligon file
                    (/work/../EvaSuite_allpolygons_regiklim.gpkg)
                5. nameattrib -> name of attribute in polyfile

            Output variables:
            ----------------------------
                dictMaskReg -> dictionary with domain: path
                    'subdommasks': {
                        'Germany': '/scratch/../Subregion_Masks//Germany_mask.nc'
                    }
        """
        dictMaskReg = {}
        shapef = gpd.read_file(polyfile)
        targetf = xr.open_dataset(targetgrid_ncfile)
        try:
            lonsdat, latsdat = targetf["lon"], targetf["lat"]
        except:
            lonsdat, latsdat = targetf["longitude"], targetf["latitude"]
        targetf.close()

        # -- Get data from shape-file:
        region_table = regionmask.from_geopandas(
            shapef, names = nameattrib, abbrevs = "_from_name")
        # -- Iterate over each subregion in the list
        for subreg in regions:
            # -- Find the index of the current subregion in the region_table:
            idxh = region_table.names.index(subreg)

            # -- Create the mask for the region at index idxh:
            # -- Important note (idxh, - should be in code. Otherwise program doesn't work)
            masksgl = region_table[idxh,].mask(lonsdat, latsdat)

            # -- Generate a 0-1 mask regardless of the region:
            masksgl = masksgl * 0.0 + 1.0
            maskoutfile = f'{outputdir}/{subreg}_mask.nc'
            masksgl.to_dataset(name = "MASK").to_netcdf(maskoutfile)

            if not os.access(maskoutfile, os.F_OK):
                raise Exception(
                    f'Creation of mask for subregion {subreg} did not work')
            dictMaskReg.update({subreg: maskoutfile})
        return dictMaskReg
