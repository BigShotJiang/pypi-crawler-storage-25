# Evaluation Suite (EvaSuite)
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2026, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------
import os
import pandas as pd
from collections import defaultdict
from typing import Dict, Any, Set
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
logger = get_logger()


class Cmor_generator:
    """
    A class to generate a rename mapping table from standardized variable names
    (from paramdict in dataset YAMLs) to dataset-specific variable names.

    Attributes:
    ----------------------------
        reverse_map (defaultdict): Map from standard name to set of dataset-specific names.
        long_name_map (dict): Mapping of standard names to human-readable long descriptions.
        separator (str): Separator used between old variable names in the CSV.
        pout (str): Path to the output CSV file.
    """
    @log_function_name
    def __init__(
        self,
        mod_data_collection: Dict[str, Any],
        ref_data_collection: Dict[str, Any],
        output_csv_path: str,
    ) -> None:
        """
        Initialize the Generator with model and reference dataset dictionaries.

        Args:
        ----------------------------
            mod_data_collection (dict): Parsed YAML dictionary for model datasets.
            ref_data_collection (dict): Parsed YAML dictionary for reference datasets.
            output_csv_path (str): Path where the CSV file will be saved.
        """
        # -- Initialize reverse mapping:
        logger.info("Initializing Cmor_generator...")
        self.reverse_map: defaultdict[str, Set[str]] = defaultdict(set)

        # -- Collect mappings from both datasets:
        logger.debug(
            f"Collecting model dataset paramdicts from {len(mod_data_collection)} entries...")
        self.mod_collection = self._collect_paramdicts(mod_data_collection)
        logger.debug(
            f"Collecting reference dataset paramdicts from {len(ref_data_collection)} entries...")
        self.ref_collection = self._collect_paramdicts(ref_data_collection)

        # -- Long names for standardized variable names:
        self.long_name_map: Dict[str, str] = {
            "tas": "Near-surface air temperature",
            "tasmax": "Daily maximum near-surface temperature",
            "tasmin": "Daily minimum near-surface temperature",
            "pr_amount": "Total precipitation amount",
            "psl": "Sea level pressure",
            "rsds": "Surface downwelling shortwave radiation",
            "rlds": "Surface downwelling longwave radiation",
            "rlus": "Surface upwelling longwave radiation",
            "rsut": "Top of atmosphere outgoing shortwave radiation",
            "rlut": "Top of atmosphere outgoing longwave radiation",
            "clt": "Total cloud cover",
            "clwlvi": "Column-integrated cloud liquid water",
            "prw": "Precipitable water",
            "dtr": "Diurnal temperature range",
            "hurs": "Relative humidity",
            "hfls": "Surface latent heat flux",
            "hfss": "Surface sensible heat flux",
            "skt": "Skin temperature",
            "as": "Surface albedo",
            "es": "Surface evaporation",
            # Extend with more standardized names if needed
        }
        # -- Separator for CSV old_names column:
        self.separator: str = "|"
        # -- Output file path:
        self.pout: str = output_csv_path

        # -- Validate output path
        if not self.pout or os.path.isdir(self.pout):
            raise ValueError(
                f"Invalid CMOR table output path: {self.pout}. "
                "You must provide a full file path, not just a directory. "
                "For example: '/path/to/rename_mapping.csv'"
            )

        # -- Optional: enforce CSV file extension
        if not self.pout.endswith('.csv'):
            raise ValueError(
                f"CMOR table path must end with '.csv', but got: {self.pout}"
            )

    @log_function_name
    def _collect_paramdicts(self, data: Dict[str, Any]) -> None:
        """
        Internal method to collect paramdict entries and populate reverse_map.

        Args:
        ----------------------------
            data (dict): A parsed dataset config containing 'paramdict' sections.
        """
        for dataset in data.values():
            paramdict = dataset.get("paramdict", {})
            for std_name, dataset_name in paramdict.items():
                self.reverse_map[std_name].add(dataset_name)

    @log_function_name
    def create_cmor_table(self) -> None:
        """
        Generate the rename mapping table and write it to the configured CSV path.

        The CSV will contain:
        ----------------------------
            - new_name: standardized variable name
            - old_names: dataset-specific variable names (pipe-separated)
            - long_name: descriptive label (if defined)
        """
        logger.info("Create a cmor table:")
        rows: list[Dict[str, str]] = []
        for std_name, old_names in sorted(self.reverse_map.items()):
            rows.append({
                "new_name": std_name,
                "old_names": self.separator.join(sorted(old_names)),
                "long_name": self.long_name_map.get(std_name, "")
            })
        # -- Create a DataFrame and export to CSV:
        rename_mapping_df = pd.DataFrame(rows)
        rename_mapping_df.to_csv(self.pout, index=False)
        logger.info(f"Rename mapping with long names saved to {self.pout}")
