# Evaluation Suite (EvaSuite)
#
# ---------------------------------------------------------------
# Copyright (C) 2004-2026, Hereon
# Contact information: beate.geyer@hereon.de, imktro-climate-modelling@lists.kit.edu
# See AUTHORS.TXT for a list of authors
# See LICENSES/ for license information
# SPDX-License-Identifier: Apache-2.0
# ---------------------------------------------------------------

# -- Import Python modules:
import os
import numpy as np
from typing import Any, Optional, Dict, List, Union, Tuple

# -- Import EvaSuite modules:
from hereon_evasuite.log_EvaSuite import get_logger, log_function_name
from hereon_evasuite.Dataset import Dataset
from hereon_evasuite.GeneralUtils import SuiteUtilities
from hereon_evasuite.Metrics_DerivedQ import MetricCalc
from hereon_evasuite.Prog_Masking import PyRegionmask
from hereon_evasuite.DataMiningGD import DataMiningGridded, DataMiningStation
from hereon_evasuite.Prog_CDONCO import CDO, NCO, NCSYS
from hereon_evasuite.Prog_PyXarray_PyVis import PyXarray
from hereon_evasuite.visual_main import Cartopy_Visualization

# -- Initialization common methods and loggers:
GenUti = SuiteUtilities()
logger = get_logger()


# -- Main Class for the different Evaluation modes:
class EVALmode(object):
    @log_function_name
    def __init__(
        self: 'EVALmode',
        name: str,
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        GridOperaToUse: Dict[str, Union[DataMiningGridded, DataMiningStation]],
        MaskProgToUse: PyRegionmask,
        dataToProof: List[Dataset],
        dataForEval: List[Dataset],
        cfggeneral: Dict[str, Any],
        rootdatadir: str,
        rootvisualdir: str,
        rootsubregdir: str,
        visual_settings: Dict[str, Union[None, str]],
    ) -> None:
        """ Initialization of EVALmode:
            Input variables:
            ----------------------------
                1. name -> name of child class, which call __init__ of EVALmode
                2. DataProgsToUse -> EvaSuite classes for data processing
                3. GridOperaToUse -> EvaSuite classes for grid processing
                4. MaskProgToUse -> EvaSuite class for masking
                5. dataToProof -> EvaSuite class for work with datasets
                6. dataForEval -> EvaSuite class for work with datasets
                7. cfggeneral -> user settings for data processing
                8. rootdatadir -> path to the temporal data (scratch)
                9. rootvisualdir -> path to the visualization (scratch)
                10. rootsubregdir -> path to the subregion_masks (scratch)
                11. visual_settings -> dictionary with pahts to configuration YAML files

            Output variables:
            ----------------------------
                Initialize all variables with self.
        """
        # -- Variables to use within this class but coming from other classes:
        self.rootdatadir = rootdatadir
        self.rootvisualdir = rootvisualdir
        self.subregdir = rootsubregdir
        self.DataProgsToUse = DataProgsToUse
        self.MaskProgToUse = MaskProgToUse
        self.GridOperaToUse = GridOperaToUse
        self.cfggeneral = cfggeneral
        self.cfgdatamining = cfggeneral["datamining"]
        self.cfgmetrics = cfggeneral["metrics_setup"]
        self.eval_parameters = cfggeneral["eval_parameters"]
        self.cfgEVALmode = cfggeneral["EVAL_modes_setup"]
        self.vis_settings = visual_settings

        # -- Variables initialized for specfic using within this class:
        self.name = name   # name of the Evalmode

        # -- Defines whether metrics are going to be computed or not:
        #    (important for getting informations)
        self.eval_metrics = (
            cfggeneral["eval_metrics"]
            if (self.cfgEVALmode[name]["metrics2compute"] == "${user-defined}")
            else self.cfgEVALmode[name]["metrics2compute"]
        )

        # -- Dataset classes which contain the results of evaluation
        #    (depending on the evalmode):
        self.FinalResDatasets: List[Any] = []
        # -- Dataset classes which are actually used as evaluation reference
        #    (changing during evaluation):
        self.RecentEvalDatasets: List[Any] = []
        # -- Neta data for plotting collected for each dataset:
        self.MetaDatasets2Visual: Dict[Any, Any] = {}
        # -- Dictionary filled during execution of evaluation
        #    (dimensions, aggregation, res variables):
        self.description_plotdict: Dict[Any, Any] = {}
        logger.debug(f"EVAL-method instance: {self.name}")

        # -- The derived quantities and combined datasets
        gen = self.cfggeneral
        self.DerivQuant = self.__cfg_value(gen["eval_RecompVar_type"])
        self.cfgEvalDataCombine = self.__cfg_value(gen["evaldata_combine_method"])
        # -- The subregions, the orography filter and the landsea mask filter to consider:
        dm = self.cfgdatamining
        self.submaskreg = self.__cfg_value(dm["subregions_acronyms"], req_nonempty = True)
        self.submaskOro = self.__cfg_value(dm["mask_Orography"], req_nonempty = True)
        self.submasklndsea = self.__cfg_value(dm["mask_landsea"], req_nonempty=True)

        # -- Update the dataset definition of the target temporal grid (if needed):
        #    indicates a temporal reselection and the related netcdf-file:
        self.refgrid_time = None
        self.refgrid_timevars = None
        cfgfreq = self.cfgdatamining["target_EvalFrequency"]
        if cfgfreq["method"] == "reselect":
            for dataset in dataToProof + dataForEval:
                if dataset.getName() == cfgfreq["targetgrid"]:
                    dataset.UpdateAttributes(eval_timerefgrid = True)
                    self.refgrid_time = dataset.getRecentResFiles()[0]
                    self.refgrid_timevars = dataset.getVarNamelist(self.eval_parameters)
                else:
                    dataset.UpdateAttributes(eval_timerefgrid = False)

    @log_function_name
    def __cfg_value(self, val: Any, req_nonempty: bool = False) -> Optional[Any]:
        """
        Validate a configuration value.

        Parameters
        ----------
        val : Any
            Configuration value to validate.
        req_nonempty : bool, optional
            If True, empty containers or strings are treated as invalid.

        Returns
        -------
        Any or None
            ``val`` if valid, otherwise ``None``.
        """
        if val is False or val is None:
            return None
        if req_nonempty and not val:
            return None
        return val

    @log_function_name
    def getDataSetList(self: 'EVALmode'):
        """ Return the recent list of Datasets initialized """
        # -- Get
        def safe_len(attr_name):
            return len(getattr(self, attr_name)) if hasattr(self, attr_name) else 'MISSING'
        logger.info(
            f"{self.__class__.__name__}.getDataSetList: "
            f"FinalResDatasets={safe_len('FinalResDatasets')}, "
            f"dataToProof={safe_len('dataToProof')}, "
            f"RecentEvalDatasets={safe_len('RecentEvalDatasets')}"
        )
        # -- Control of Eval methods for work with getDataSetList function
        datasets1 = self.FinalResDatasets if self.FinalResDatasets else self.dataToProof
        return datasets1 + self.RecentEvalDatasets

    @log_function_name
    def CheckForCompatibility2DS(self: 'EVALmode', DS1: Dataset, DS2: Dataset) -> bool:
        """ The compatibility of two datasets is checked prior evaluation, i.e. the attributes of
            two datasets are checked for different criteria; a boolean value is returned """
        comb_gridtype = list(np.unique([DS1.getGridtype(), DS2.getGridtype()]))
        comb_levtype = list(np.unique([DS1.getLevtype(), DS2.getLevtype()]))
        comb_EPtype = (DS1.getEPTypeOfData() == DS2.getEPTypeOfData())
        if (
            (not(DS1.getRefgrid() is False and DS2.getRefgrid() is False) and len(comb_gridtype) > 1) or
            (not(DS1.getRefVert() is False and DS2.getRefVert() is False) and len(comb_levtype) > 1) or
            comb_EPtype
        ):
            logger.error(
                f'Dataset {DS1.getName()} is not compatible with {DS2.getName()}'
            )
            logger.error(' --> The evaluation is stopped.')
            return False
        else:
            return True

    @log_function_name
    def CombineInitReferenceDatasets(self: 'EVALmode') -> None:
        """
        Initialize and validate combination of reference datasets.

        This method evaluates the user configuration for combining reference
        datasets and validates whether the selected datasets can be combined.
        Supported modes include combining all datasets into a single dataset
        using a mean method or producing multiple datasets using a min–max
        strategy. If no combining is configured, all datasets are processed
        independently.

        The method also initializes the final directory structure for all
        reference datasets.

        Raises
        ------
        ValueError
            If datasets to be combined use incompatible grid types or if an
            obsolete and unsupported combination branch is activated.
        """
        cfgEval = self.cfgEvalDataCombine
        evalDat = self.RecentEvalDatasets
        wp_dir = self.cfggeneral["directoryDM_WPcompeval"]

        logger.info("Combine reference data sets using the user-specified setting %s", cfgEval)

        if (cfgEval is None) or (cfgEval is False):
            logger.info(
                "No combining chosen by the user -> all eval-datasets are considered separately."
            )
        else:
            combgridtype = [ds.getGridtype() for ds in evalDat]
            comb_refgridb = [ds.getRefgrid() for ds in evalDat]

            len_uniq_grid = len(np.unique(combgridtype))
            len_uniq_ref = len(np.unique(comb_refgridb))
            len_comb_grid = len(combgridtype)

            if len_uniq_grid == 1 and len_comb_grid == 1:
                logger.debug("Only one dataset is given -> nothing to combine.")
            elif len_uniq_grid > 1:
                raise ValueError("Datasets to combine carry different grid types")

            # -- No active branch (was in 0.92_beta with a lot of errors):
            elif len_uniq_grid == 1 and len_comb_grid > 1 and len_uniq_ref == 1:
                raise ValueError(
                    'CombineInitReferenceDatasets: You have activated an old branch'
                    ' that is no longer supported. All related routines (CombineNDatasets,'
                    ' RenameVariables, MinMaxMeanOfTwoDatasets) have been removed.'
                    ' If you need to use this functionality, please contact evgenii.churiulin@kit.edu'
                    ' and provide the necessary configuration files. I will try to restore'
                    ' the functionality as soon as possible. Alternatively, you can'
                    ' try using an older version.'
                )

        # -- Create final directory structure of reference datasets:
        for datasets in evalDat:
            datasets.createDirs(self.rootdatadir, wp_dir)

    def _create_subregion_masks(
        self,
        cdo_object: "CDO",
        nco_object: "NCO",
        sourcemaskfile: str,
        mode: str,
        attri_reload: List[str],
    ) -> dict[str, str]:
        """
        Create derived subregion masks using orography or land–sea filtering.

        This function interpolates a source mask to the target grid, applies
        threshold-based filtering depending on the selected mode, and multiplies
        the filtered mask with each base subregion mask to generate new derived
        masks. Each output mask is written to disk and registered with metadata.

        Parameters
        ----------
        cdo_object : CDO
            CDO interface used for interpolation, filtering, and mask combination.
        nco_object : NCO
            NCO interface used for writing global NetCDF attributes.
        sourcemaskfile : str
            Path to the input orography or land–sea mask file.
        mode : {"orography", "landsea"}
            Filtering mode that determines thresholding logic.
        attri_reload : list
            Attribute names used when writing EVA-specific metadata.

        Returns
        -------
        dict of str to str
            Mapping from derived subregion names to their generated NetCDF mask
            file paths.

        Raises
        ------
        ValueError
            If an invalid mode is provided.
        """
        logger.debug(
            "Creating subregion masks: mode=%s, sourcemaskfile=%s",
            mode, sourcemaskfile
        )

        # -- Local variables
        result_dict: dict[str, str] = {}
        submaskdict = self.maskfilesdict

        # -- Reference interpolation mask and cdo methods for IntpolHori and CombOfTwoDatsets:
        reference_mask = list(submaskdict.values())[0]
        m_intpl = "nearestn"
        m_comb = "mul"

        # -- Allowed modes:
        m_orog, m_ls = "orography", "landsea"

        # -- Select output interpolated mask file:
        # ------------------------------------------------------------------
        if mode == m_orog:
            targetgridfile = f"{self.subregdir}/EU_oro_targetgrid.nc"
        elif mode == m_ls:
            targetgridfile = f"{self.subregdir}/landseamask_targetgrid.nc"
        else:
            raise ValueError(f"Invalid mode '{mode}'. Expected '{m_orog}' or '{m_ls}'.")
        logger.debug("Interpolating %s to target grid: %s", sourcemaskfile, targetgridfile)

        # -- Interpolate source mask to target grid:
        # ------------------------------------------------------------------
        cdo_object.IntpolHori(
            filein = sourcemaskfile,
            fileout = targetgridfile,
            method = m_intpl,
            griddesf = reference_mask,
        )

        # -- For each base region, build the derived masks
        # ------------------------------------------------------------------
        for subreg, base_mask in submaskdict.items():
            # Orography → dynamic thresholds per region:
            if mode == m_orog:
                newsubs, limits = GenUti.create_subregs_from_Oromask(subreg, self.submaskOro)
                flags = [None] * len(newsubs)

            # Land/sea → fixed thresholds + bigthanc flags:
            else:
                newsubs = [f"{subreg}_lnd", f"{subreg}_sea"]
                limits = [[-0.1, 0.75], [0.76, 1.1]]
                flags = [True, False]
            logger.debug("Derived subregions for '%s': %s", subreg, newsubs)

            # -- Loop over derived submasks:
            for newsub, thr, flag in zip(newsubs, limits, flags):
                # -- Paths to output mask and temporal file:
                maskoutf = f"{self.subregdir}/{newsub}_mask.nc"
                root, ext = os.path.splitext(maskoutf)
                tmpfile = f"{root}_prestep{ext}"

                # -- Step 2a – Build threshold mask:
                if mode == m_orog:
                    cdo_object.SetValidRange(
                        filein = targetgridfile,
                        fileout = tmpfile,
                        levdwn = thr[0],
                        levup = thr[1],
                    )
                else:
                    cdo_object.SetRangeToMissRestMask(
                        filein = targetgridfile,
                        fileout = tmpfile,
                        levdwn = thr[0],
                        levup = thr[1],
                        bigthanc = flag,
                    )

                # -- Step 2b – Combine with base subregion mask:
                cdo_object.CombOfTwoDatsets(
                    filein1 = base_mask,
                    filein2 = tmpfile,
                    method = m_comb,
                    varlist = None,
                    fileout = maskoutf,
                )

                # -- Remove temporal file:
                try:
                    os.remove(tmpfile)
                except FileNotFoundError:
                    logger.debug("Temporary file already removed: %s", tmpfile)

                # -- Step 2c – Add EvaSuite attributes:
                nco_object.PutAttribute(
                    maskoutf,
                    ['global', 'global'],
                    attri_reload,
                    [newsub, self.cfgdatamining["targetgrid_horizontal"]],
                )

                # -- Save:
                result_dict[newsub] = maskoutf
                logger.debug("Created derived mask: %s", maskoutf)
        return result_dict

    @log_function_name
    def CreateLoadSubRegMasks(self: 'EVALmode') -> None:
        """
        Create and load subregion masks used for EvaSuite processing. Builds base
        masks from polygon definitions, repairs dataset attributes, and optionally
        applies orography and/or land–sea filtering. The resulting masks are stored
        in `self.maskfilesdict` and the full list of subregions is updated in
        `self.subregions`
        """
        # -- Local variables and methods:
        if isinstance(self.DataProgsToUse["cdo"], CDO):
            cdo_object = self.DataProgsToUse["cdo"]

        if isinstance(self.DataProgsToUse["nco"], NCO):
            nco_object = self.DataProgsToUse["nco"]

        attri_reload = ['EVASUITE_subdom_name', 'EVASUITE_targetgrid']
        subregion_box = self.cfgdatamining["subregions_BoxCorner_files"]

        # Step 1: Build base subregion masks:
        # ----------------------------------------------------------------------
        if self.submaskreg is None:
            self.subregions = None
            self.maskfilesdict = {}
            logger.info("Generation of subregion masks skipped (no submaskreg).")
            return

        logger.info(
            "Generating subregion masks with optional orography and land–sea filtering."
        )
        # -- Validate polygon names:
        missreg = self.MaskProgToUse.CheckPolygons(
            polyfile = subregion_box["polyfile"],
            nameattrib = subregion_box["attribregion"],
            regions = self.submaskreg,
        )

        if missreg:
            logger.warning(
                "Some requested subregions were not found in the polygon file: %s. "
                "They will be ignored.",
                missreg,
            )

            # -- Keep only the valid ones:
            self.submaskreg = list(set(self.submaskreg) - set(missreg))
            logger.info("Valid subregions after filtering: %s", self.submaskreg)
            if not self.submaskreg:
                raise ValueError(
                    "None of the requested subregions could be matched with polygons. "
                    "Please check the region names in your configuration."
                )

        # -- Determine for each region a netcdf-file mask based on the dataset
        #    with the reference grid; repair at first its attributes
        targetncgrid = None
        for dataset in self.getDataSetList():
            if dataset.getOrigRefgrid():
                dataset.RepairNcdfVarsAndAttributes(
                    self.DataProgsToUse,
                    cdo_object.repairlevel,
                    filelist = dataset.getRecentResFiles(allfiles = True),
                )
                targetncgrid = dataset.getRecentResFiles()[0]
                logger.debug("Dataset %s repaired.", dataset.getName())
        logger.info("Building base masks on target grid: %s", targetncgrid)

        # -- Build initial region masks:
        self.maskfilesdict = {}
        self.maskfilesdict.update(
            self.MaskProgToUse.RegionMask(
                regions = self.submaskreg,
                targetgrid_ncfile = targetncgrid,
                outputdir = self.subregdir,
                polyfile = subregion_box["polyfile"],
                nameattrib = subregion_box["attribregion"],
            )
        )

        # -- Add metadata attributes
        for subreg, maskfile in self.maskfilesdict.items():
            nco_object.PutAttribute(
                maskfile,
                ['global', 'global'],
                attri_reload,
                [subreg, self.cfgdatamining["targetgrid_horizontal"]],
            )

        logger.debug("Base region masks created: %s", list(self.maskfilesdict.keys()))
        self.subregions = list(self.maskfilesdict.keys())
        os.chdir(self.rootdatadir)

        # Step 2: Apply orography / land-sea filters (optional)
        # ----------------------------------------------------------------------
        logger.info("Applying additional subregion filtering (orography / land-sea)")

        oromaskfilesdict = {}
        lndseamaskfilesdict = {}

        # -- Orography filtering:
        if self.submaskOro is not None:
            oromaskfilesdict = self._create_subregion_masks(
                cdo_object,
                nco_object,
                sourcemaskfile = self.cfgdatamining["mask_dataf_Orography"],
                mode = "orography",
                attri_reload = attri_reload,
            )
            self.maskfilesdict.update(oromaskfilesdict)

        # -- Land/sea filtering:
        if self.submasklndsea is not None:
            lndseamaskfilesdict = self._create_subregion_masks(
                cdo_object,
                nco_object,
                sourcemaskfile = self.cfgdatamining["mask_dataf_landsea"],
                mode = "landsea",
                attri_reload = attri_reload,
            )
            self.maskfilesdict.update(lndseamaskfilesdict)
        self.subregions = list(self.maskfilesdict.keys())
        logger.info("Final subregion list: %s", self.subregions)

    @log_function_name
    def UnifyFreq(self: 'EVALmode') -> None:
        """ Unify the different temporal frequencies of the datasets to one (controlled
            by user-settings 'cfg.datamining')"""
        logger.info('Unify temporal frequency of the different datasets')
        #
        for datasets in self.getDataSetList():
            logger.info(f'Unify frequency for dataset {datasets.getName()}')
            datafilelist = GenUti.ConvertBibToList(input = datasets.getRecentResFiles())
            # -- Helper to overcome False or None Problem from YAML:
            helpsub = self.cfgdatamining["target_RollingMean"]
            cfgrollingm = helpsub if ((helpsub is not False) and (helpsub is not None)) else None
            #
            datasets.ChangeFrequency(
                DataProgsToUse = self.DataProgsToUse,
                evalparas = self.eval_parameters,
                filelist = datafilelist,
                resultdir = datasets.getSubDirs()[0],
                cfgRestime = self.cfgdatamining["target_EvalFrequency"],
                cfgrollingm = cfgrollingm,
                refgrid_time = self.refgrid_time,
                refgrid_timevars = self.refgrid_timevars,
                posdimnames = self.cfggeneral["PossibleDimNames"],
            )

            logger.info('Unification of frequency finished')

    @log_function_name
    def DerivedQuantity(self: 'EVALmode') -> None:
        """ Transform the original variables to something different controlled by user
            (cfggen.eval_RecompVar_type);
            this routine should not be called if no modification of variables is wished;
            recently it is done with if-statement but one could also throw away this method
            from cfgmetrcics.workingsteps.
        """
        if self.DerivQuant is not None:
            logger.error("EV: I found some problems here. Please send setup (evgenii.churiulin@kit.edu)")
            logger.info(
                'Transform original variables to other quantities. Update Eval Parameters')
            #
            evalparadd = "deriv"
            for datasets in self.getDataSetList():
                logger.info(
                    f'Derive new quantity for dataset {datasets.getName()} '
                    f'using method {self.cfggeneral["eval_RecompVar_type"]}'
                )
                datafilelist = GenUti.ConvertBibToList(
                    input = datasets.getRecentResFiles(),
                )

                datasets.RecomputeQuant(
                    self.cfggeneral["eval_RecompVar_type"],
                    DataProgsToUse = self.DataProgsToUse,
                    evalparas = self.eval_parameters,
                    dictPossDimNames = self.cfggeneral["PossibleDimNames"],
                    filelist = datafilelist,
                    resultdir = datasets.getSubDirs()[0],
                    evalparadd = evalparadd,
                )

                logger.info('Derivation finished')
            self.eval_parameters = [x + evalparadd for x in self.eval_parameters]
        else:
            logger.info('The original variables are taken as they are.')

    @log_function_name
    def AddMetaDataToFinalDatasets(self: 'EVALmode', dataobjects: List[Dataset]) -> None:
        for metricsgl in GenUti.IterNoneComp(self.eval_metrics):
            metricsgl_key = metricsgl if self.eval_metrics is not None else None
            for evalpara in self.eval_parameters:
                all_paths = []
                for datasetsgl in dataobjects:
                    hitstometric = datasetsgl.getVarNamelist(
                        evalparas = GenUti.check_for_list(evalpara),
                        metrickey = metricsgl_key,
                    )
                    if hitstometric:
                        datafiles = GenUti.check_for_list(
                            datasetsgl.getRecentResFiles(metrickey = metricsgl_key)
                        )
                        all_paths.append(datafiles)

        self.datafiles_experimental = all_paths

    @log_function_name
    def Visualization_org1D2D(self: 'EVALmode', dataobjects: List[Dataset]) -> None:
        """
        Main function for visualization. Use it for CompareRAW and EvalRAW:
        """
        # -- Inform user that computation phase was sussesfully finished:
        logger.info('\n' + '*' * 50)
        logger.info(
            'Congratulations, you have successfully finished the computational part. '
            'Go to visualization. After that, you can use the standalone version for '
            'visualization.'
        )
        logger.info('\n' + '*' * 50)

        # -- Initialization of new visualization scheme:
        cartopy_visual = Cartopy_Visualization(self.vis_settings, self.cfggeneral)
        # -- Get a list of all output paths:
        self.AddMetaDataToFinalDatasets(dataobjects = dataobjects)
        # -- Create new figures:
        cartopy_visual.visual_main(self.datafiles_experimental)


class CompareRAW(EVALmode):
    @log_function_name
    def __init__(
        self: 'CompareRAW',
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        GridOperaToUse: Dict[str, Union[DataMiningGridded, DataMiningStation]],
        MaskProgToUse: PyRegionmask,
        dataToProof: List[Dataset],
        dataForEval: List[Dataset],
        cfggeneral: Dict[str, Any],
        rootdatadir: str,
        rootvisualdir: str,
        rootsubregdir: str,
        visual_settings: Dict[str, Union[None, str]],
    ) -> None:
        """ Initialization of CompareRAW subclass. See detailed description of
            input parameters in EVALmode __init__
        """
        super().__init__(
            "CompareRAW",
            DataProgsToUse, GridOperaToUse, MaskProgToUse,
            dataToProof, dataForEval,
            cfggeneral,
            rootdatadir, rootvisualdir, rootsubregdir, visual_settings,
        )
        # -- The data sets to proof are not overwritten in ComparRAW:
        self.FinalResDatasets = dataToProof
        # -- The Evaluation data sets are maybe changed dependent on 'CombineReferenceDataSets':
        self.RecentEvalDatasets = dataForEval
        # -- Define the metrical quantities to compute (nothing at all):
        self.eval_metrics = None
        # -- Create directory names for the data to proof and for the eval data:
        for datasets in self.RecentEvalDatasets + self.FinalResDatasets:
            datasets.createDirs(
                self.rootdatadir, cfggeneral["directoryDM_WPcompeval"])

        # -- The final evaluation data sets and directories are initialiazed
        #    later on by 'CombineReferenceDataSets'
        if isinstance(DataProgsToUse["cdo"], CDO):
            cdo_object = DataProgsToUse["cdo"]

        self.description_plotdict['opera_time'] = self.cfgdatamining['aggregate_temporal']
        self.description_plotdict['opera_spat'] = "_opxy-" + \
            str(cdo_object.ConvertSpatialOperaToCdoCmd(
                spatial_operax = self.cfgdatamining["operator_spatial_x"],
                spatial_operay = self.cfgdatamining["operator_spatial_y"],
            )
        )
        logger.info('Check ConvertSpatialOperaToCdoCmd')

    @log_function_name
    def AggregDims(self: 'CompareRAW') -> None:
        """For the final comparison, results are condensed according to the
           user-specified temporal and spatial operations
        """
        # -- Local variables:
        if isinstance(self.DataProgsToUse["pyxarray"], PyXarray):
            pyxarray_object = self.DataProgsToUse["pyxarray"]
        # -- Start
        logger.info(
            'Aggregate data sets in temporal and spatial dimensions '
            'regarding user settings')

        # The condensation of Dimensions (CompareRAW only) is a final step for comparing
        #   two datasets --> mimic a aggregation with predefined method 'resample'
        #   "{'method':'resample','freq':'monthly','how':'mean'}"

        # -- Rolling Mean is part already of unify frequency
        if self.cfgdatamining["aggregate_temporal"] is None:
            logger.info('No further aggregation needed')
        else:
            cfgRestime = {
                'method': 'resample',
                'how': self.cfgdatamining["operator_time"],
                'freq': self.cfgdatamining["aggregate_temporal"],
            }
            cfgrollingm = None
            for datasets in self.RecentEvalDatasets + self.FinalResDatasets:
                logger.info(f'Condense Dimensions for dataset {datasets.getName()}')
                datafilelist = (
                    GenUti.ConvertBibToList(
                        input = datasets.getRecentResFiles(),
                    )
                )

                datasets.CondenseDimensions(
                    DataProgsToUse = self.DataProgsToUse,
                    GridOperaToUse = self.GridOperaToUse,
                    evalparas = self.eval_parameters,
                    filelist = datafilelist,
                    resultdir = datasets.getSubDirs()[0],
                    cfgRestime = cfgRestime,
                    posdimnames = self.cfggeneral["PossibleDimNames"],
                    cfgrollingm = cfgrollingm,
                    opera_x = self.cfgdatamining["operator_spatial_x"],
                    opera_y = self.cfgdatamining["operator_spatial_y"],
                    opera_z = self.cfgdatamining["operator_spatial_z"],
                )

            logger.info('Aggregation finished')

        for datasets in self.RecentEvalDatasets + self.FinalResDatasets:
            if self.subregions is not None:
                fileoutpre = (
                    f'{os.path.dirname(datasets.getRecentResFiles()[0])}/'
                    f'{self.eval_parameters[0]}.CompareRAW.'
                    f'{self.description_plotdict["opera_time"]}'
                    f'{self.description_plotdict["opera_spat"]}.'
                    f'{datasets.getName()}.'
                )

                subregion_files = pyxarray_object.ComputeSubDomains(
                    filenam = datasets.getRecentResFiles()[0],
                    fileoutpre = fileoutpre,
                    fvarnames = datasets.getVarNamelist(
                        GenUti.check_for_list(self.eval_parameters)
                    ),
                    subdoml = self.subregions,
                    subdommasks = self.maskfilesdict,
                    PossDimDict = self.cfggeneral["PossibleDimNames"],
                )

                datasets.UpdateAttributes(
                    RecResFiles = datasets.getRecentResFiles() + subregion_files
                )

        logger.info('Calculation of subregional things finished.')

    @log_function_name
    def DetermineMetrics(self: 'CompareRAW') -> None:
        """Determ Metrics CompareRaw: """
        logger.info(f'{self.name} - No Metrics have to be computed. --> Bye')

    @log_function_name
    def Visualization(self: 'CompareRAW') -> None:
        """Visualization of CompareRaw method: """
        logger.info(f'{self.name} - Plotting of all datasets')
        dataobjects = self.RecentEvalDatasets + self.FinalResDatasets
        # -- organize the visualization:
        self.Visualization_org1D2D(dataobjects = dataobjects)


class EvalRAW(EVALmode):
    @log_function_name
    def __init__(
        self: 'EvalRAW',
        DataProgsToUse: Dict[str, Union[CDO, NCO, NCSYS, PyXarray]],
        GridOperaToUse: Dict[str, Union[DataMiningGridded, DataMiningStation]],
        MaskProgToUse: PyRegionmask,
        dataToProof: List[Dataset],
        dataForEval: List[Dataset],
        cfggeneral: Dict[str, Any],
        rootdatadir: str,
        rootvisualdir: str,
        rootsubregdir: str,
        visual_settings: Dict[str, Union[None, str]],
    ) -> None:
        """
        Initialize the EvalRAW evaluation mode.

        EvalRAW is a non-interpolative evaluation method that directly compares raw values
        between reference datasets (`dataToProof`) and model datasets (`dataForEval`)
        without spatial remapping or frequency adjustment. It is best suited for evaluations
        where native grid and time alignment are already consistent.

        Parameters
        ----------
        DataProgsToUse : dict
            Dictionary mapping program names (e.g., 'cdo', 'nco') to their respective processing backends.

        GridOperaToUse : dict
            Dictionary of grid operation handlers for both gridded and station-based datasets.

        MaskProgToUse : PyRegionmask
            Instance of the masking backend to apply subregion or land/sea masks.

        dataToProof : list of Dataset
            Reference datasets (e.g., observations, reanalyses) to be compared against.

        dataForEval : list of Dataset
            Model datasets being evaluated.

        cfggeneral : dict
            General configuration parameters shared across all evaluation modes.

        rootdatadir : str
            Root path where input NetCDF data files are located.

        rootvisualdir : str
            Root directory where plots, figures, and result visualizations will be stored.

        rootsubregdir : str
            Directory containing subregion masks used for regional analysis (if applicable).

        visual_settings : dict
            Configuration for controlling visual aspects of output (e.g., plot style, format).
            May contain entries like `'plot_template'`, `'map_style'`, or `'output_format'`.

        Notes
        -----
        This constructor does not perform any data loading or computation. It prepares all
        components for later use in evaluation steps such as preprocessing, metric computation,
        and visualization.
        """
        super().__init__(
            "EvalRAW",
            DataProgsToUse, GridOperaToUse, MaskProgToUse,
            dataToProof, dataForEval,
            cfggeneral,
            rootdatadir, rootvisualdir, rootsubregdir, visual_settings,
        )
        # -- store the data sets for the class EVALmode:
        # -- Data2proof not overwritten in ComparRAW:
        self.dataToProof = dataToProof
        # -- Dependent on the 'CombineReferenceDataSets':
        self.RecentEvalDatasets = dataForEval
        # -- Create directory names for the final data sets
        #    the final reference data sets and directory structure initialiazed
        #    by CombineReferenceDataSets. FinalResDatasets are also initiliazed
        #    not before the method 'DetermineMetrics':
        for datasets in self.getDataSetList():
            datasets.createDirs(
                self.rootdatadir, cfggeneral["directoryDM_WPcompeval"],
            )

        # -- Redefine the subregions in case of spatial-operating metrics
        for metricsgl in self.eval_metrics:
            if self.cfgmetrics[metricsgl]["calctype"] == "spatial":
                logger.warning(
                    "SUBDOMAIN CALCULATIONS HAS TO BE SWITCHED OFF!!!"
                    "no support up to now for spatial metrical operators")
                self.submaskreg = None

        # -- Redefine the metrical quantities associated with options (overwrite
        #    the rules from EVALmode.init):
        eval_metrics_old = self.eval_metrics
        # -- A copy must be created:
        cfgmetsetup_old = self.cfgmetrics.copy()
        self.eval_metrics = []
        for metricsgl in eval_metrics_old:

            metricsgl_op = GenUti.safe_access_bib(
                dicttest = self.cfgmetrics[metricsgl],
                dictkey = 'option',
                errhandle = False,
            )

            metricsgl_dep = GenUti.safe_access_bib(
                dicttest = self.cfgmetrics[metricsgl],
                dictkey = 'dependency',
                errhandle = False,
            )
            logger.info("{}\n{}\n{}".format(metricsgl, metricsgl_op, metricsgl_dep))

            if metricsgl_dep is None:
                if metricsgl_op is None:
                    self.eval_metrics.append(metricsgl)
                    self.cfgmetrics[metricsgl]["option"] = None
                    self.cfgmetrics[metricsgl]["root"] = metricsgl
                elif isinstance(metricsgl_op, (float, dict)):
                    self.eval_metrics.append(metricsgl)
                    self.cfgmetrics[metricsgl]["root"] = metricsgl
            else:
                cfgmetsetup_new = {}
                for metricop in metricsgl_op:
                    metricnew = metricsgl + '_' + str(metricop)
                    self.eval_metrics.append(metricnew)
                    cfgmetsetup_new[metricnew] = cfgmetsetup_old[metricsgl].copy()
                    # -- Overwrite the old option:
                    cfgmetsetup_new[metricnew]["option"] = metricop
                    # -- Define a new root:
                    cfgmetsetup_new[metricnew]["root"] = metricsgl
                    # -- error trap (was commented by Ronny):
                    # del cfgmetsetup_new[metricnew]["options"]
                del self.cfgmetrics[metricsgl]
                self.cfgmetrics.update(cfgmetsetup_new)

        # -- For plotting options:
        self.description_plotdict['opera_time'] = self.cfgdatamining["aggregate_temporal"]
        # -- obsolete due to metric operators:
        self.description_plotdict['opera_spat'] = ''

    @log_function_name
    def AggregDims(self: 'EvalRAW') -> None:
        """
        Skip aggregation step for EvalRAW.

        No additional dimension aggregation is needed, as this is handled
        directly within the metric computation functions.
        """
        logger.info(
            f'{self.name} - No extra Aggregation is needed - '
            f'done by metric computations. --> Bye')

    @log_function_name
    def VarNaFMetEvalP(
        self: 'EvalRAW',
        metric: str,
        para: List[str],
        metrop: Optional[str] = None,
    ) -> Union[List[str], str]:
        """ Generate a variable name from a metric and a evalulation parameter """
        metradd = '' if (metrop is None) or (metrop == "None") else "_" + str(metrop)
        if isinstance(para, list) and not isinstance(metric, list):
            return list(map((lambda x: metric + '_' + x + metradd), para))
        elif isinstance(metric, list) and not isinstance(para, list):
            return list(map((lambda x: x + '_' + para + metradd), metric))
        else:
            return metric + '_' + para + metradd

    @log_function_name
    def DetMetricGroupsFromMetricList(
        self: 'EvalRAW',
        metrics: List[str],
        mgroups: List[str],
    ) -> Dict[str, List[str]]:
        """
        Determine metric groups covered by a given list of metrics.

        This method analyzes each metric from the provided list and groups them
        based on their associated calculation type (`calctype`) as defined in the
        configuration (`cfgmetrics`). The result is a dictionary mapping each
        unique metric group to the list of metrics it contains.

        Parameters
        ----------
        metrics : list of str
            List of metric names to analyze.

        mgroups : list of str
            List of possible metric group names (not directly used in logic, kept for interface compatibility).

        Returns
        -------
        dict
            A dictionary where keys are metric group names (`calctype`) and values are lists of metrics
            belonging to each group.

        Example
        -------
        Input: metrics = ['BIAS', 'MAE', 'BIASnorm']
        Output: {
            'spatial': ['BIAS', 'BIASnorm'],
            'temporal': ['MAE']
        }

        Notes
        -----
        This method assumes that each metric in `metrics` exists in `self.cfgmetrics`
        and that the entry includes a valid `'calctype'` field.
        """
        mgroups_filt: Dict[str, List[str]] = {}
        for metricsingle in metrics:
            singlegrp = self.cfgmetrics[metricsingle]["calctype"]
            if not(singlegrp in mgroups_filt):
                mgroups_filt.update({singlegrp: []})
            mgroups_filt[singlegrp].append(metricsingle)
        return mgroups_filt

    @log_function_name
    def DeterDataLoopStruct(
        self: 'EvalRAW',
        mgroup: str,
        dataref: List[Dataset],
        dataproof: List[Dataset],
    ) -> Tuple[float, Dict[str, List[Any]]]:
        """ Determines the loop structure for an evaluation, i.e. for skill
            scores other  loops than for BIAS; result stored in a dictionary,
            in addition this method  returns the Depth of the loop levels.

            Input variables:
            ----------------------------
                1. mgroup -> type of methods (temporal)
                2. dataref -> reference dataset object
                3. dataproof -> model dataset object

            Output variables:
            ----------------------------
                1. depth -> ?
                2. loopstruct -> a dictionary with dataset objects for
                                 reference, model and skill_scores dataset. Later
                                 these properties will be included to the final dataset
        """
        loopstruct: Dict[str, List[Any]] = {}
        if mgroup in ("temporal", "spatial"):
            loopstruct["lev1"] = dataref
            loopstruct["lev2"] = dataproof
            # -- Third inner loop for skill metrics:
            loopstruct["lev3"] = ["-"]
            depth = 2.0

        elif mgroup in ("skill_temporal", "skill_spatial"):
            proofref = self.cfggeneral["data2proof_acronyms"][self.cfgmetrics["skill_scores_skillref_idx"]]
            loopstruct["lev1"], loopstruct["lev2"], loopstruct["lev3"] = dataref, [], []
            for datasets in dataproof:
                if datasets.getName() == proofref:
                    loopstruct["lev3"].append(datasets)
                else:
                    loopstruct["lev2"].append(datasets)
            depth = 3.0

        return depth, loopstruct

    @log_function_name
    def Spec_MetricCalcLoop_3rdLevel(
        self: 'EvalRAW',
        metricgroup: str,
        dataref: Dataset,
        dataproof: Dataset,
        dataskillref: Union[str, Dataset],
    ) -> Tuple[str, Optional[str], Optional[str], Optional[List]]:
        """ Specify how the 3rd level of the loop for metric calculations looks like;
            returns the parameters needed to compute the 3rd level loop

            Input variables:
            ----------------------------
                1. metricgroup -> metric name ('temporal')
                2. dataref -> object for reference dataset
                3. dataproof -> object for model dataset
                4. dataskillref - it can be "-" or object of Dataset (see outcome in DeterDataLoopStruct)

            Output variables:
            ----------------------------
                1. newcombname
                2. DSskillrefname
                3. DSskillrefiles
                4. DSskillrefvars

        """
        if not("skill" in metricgroup):
            newcombname = f'{dataproof.getName()}_vs_{dataref.getName()}'
            newcombname = newcombname + "-T" if "temporal" in metricgroup else newcombname + "-S"
            DSskillrefname, DSskillrefiles, DSskillrefvars = None, None, None

        elif "skill" in metricgroup:
            if isinstance(dataskillref, Dataset):
                newcombname = f'{dataproof.getName()}_vs_{dataskillref.getName()}_ag_{dataref.getName()}'
                newcombname = newcombname + "-T" if "temporal" in metricgroup else newcombname + "-S"
                DSskillrefname = dataskillref.getName()
                DSskillrefiles = dataskillref.getRecentResFiles()[0]
                DSskillrefvars = dataskillref.getVarNamelist(self.eval_parameters)
            else:
                raise AttributeError(
                    'Function Spec_MetricCalcLoop_3rdLevel of EvalRAW. dataskillref'
                    ' is not object of Dataset class'
                )
        return newcombname, DSskillrefname, DSskillrefiles, DSskillrefvars

    @log_function_name
    def DetermineMetrics(self: 'EvalRAW') -> None:
        """ The Metric Calculation is based on each EvalDataset which is at this
            time of execution available:
        """
        # -- Local variables:
        if isinstance(self.DataProgsToUse["pyxarray"], PyXarray):
            pyxarray_object = self.DataProgsToUse["pyxarray"]

        logger.info(
            f'{self.name} - Determine the Metrics and store the Final Result datasets')
        #
        metricclasses_filt = self.DetMetricGroupsFromMetricList(
            self.eval_metrics, self.cfgmetrics["types"])

        for metricgroup in metricclasses_filt.keys():
            loopdepth, datloop = self.DeterDataLoopStruct(
                metricgroup,
                dataref = self.RecentEvalDatasets,
                dataproof = self.dataToProof,
            )
            for dataref in datloop["lev1"]:
                for dataproof in datloop["lev2"]:
                    #
                    if not(self.CheckForCompatibility2DS(DS1 = dataproof, DS2 = dataref)):
                        raise ValueError(
                            "Incompatible datasets: proof and reference datasets"
                            "cannot be evaluated together."
                        )
                    for dataskillref in datloop["lev3"]:
                        newcombname, DSskillrefname, DSskillrefiles, DSskillrefvars = (
                            self.Spec_MetricCalcLoop_3rdLevel(
                                metricgroup,
                                dataref,
                                dataproof,
                                dataskillref,
                            )
                        )
                        if loopdepth >= 3.0:
                            if not self.CheckForCompatibility2DS(DS1 = dataskillref, DS2 = dataref):
                                raise ValueError(
                                    "Incompatible datasets: skill reference and "
                                    "reference datasets cannot be evaluated together."
                                )
                        # -- Initialize the new dataset:
                        #    if init_loop is True: [see also else case], this
                        #    feature would help to get "temporal" and "spatial"
                        #    metrics in one dataset -->  metricclasses_filt is
                        #    not seperating between "spatial" and "temporal" but
                        #    the MetricCLASS still has to consider it:
                        datasetnew = Dataset(
                            newcombname,
                            "FinalEvalMode",
                            settingsDataset = {"gridtype": dataref.getGridtype()},
                            evalparas = [],
                            eval_refgridhor = dataref.getRefgrid(),
                            eval_origrefgrid = False,
                            eval_refvertb = dataref.getRefVert(),
                            eval_timerefgrid = True,
                            DSevalbase = dataref.getName(),
                            DStoproof = dataproof.getName(),
                            DSskillref = DSskillrefname,
                        )

                        datasetnew.createDirs(
                            self.rootdatadir, self.cfggeneral["directoryDM_WPcompeval"]
                        )
                        logger.info(f'Dataset {newcombname} was initialized successfully')

                        datasetnew.UpdateAttributes(
                            Protect_varnames = dataref.getProtectVarNames(),
                            ReinitCfgSettings = True,
                            Protect_attrib = dataref.getProtectAttributes(),
                        )
                        evalresult_file = (
                            f'{datasetnew.getSubDirs()[1]}/{self.name}.'
                            f'{self.eval_parameters[0]}.Type-{metricgroup}.'
                            f'{self.description_plotdict["opera_time"]}'
                            f'{self.description_plotdict["opera_spat"]}.'
                            f'{newcombname}.nc'
                        )
                        RecentResFiles: Dict[Any, Any] = {}
                        DictParam: Dict[Any, Any] = {}

                        self.FinalResDatasets.append(datasetnew)
                        # else: RecentResFiles = datasetnew.getRecentResfiles(); DictParam = datasetnew.getCfgParamDict()
                        # initialize the metric operator class and start opening files
                        #    (only first file of each datset is opened):
                        logger.info(f'Initialize Metric Operator class "{metricgroup}"')
                        SubDomCalcPos = -1 if "temporal" in metricgroup else 0

                        # -- Initialization of MetricCalc class:
                        Metric_class = MetricCalc(
                            f'{self.name}_CalcMetric',
                            pyxarray_object,
                            self.cfggeneral,
                            MetricMode = metricgroup,
                            cfgMetricMode = self.cfgmetrics["typespec"][metricgroup],
                            DSdims_squeeze = True,
                            fname_result = evalresult_file,
                        )
                        # -- Set dependencies (open datasets):
                        logger.debug(
                            "\n=========== Metric Call (First Time) ============"
                            "\nReference Dataset:"
                            f"\n  DSfile_ref:    {dataref.getRecentResFiles()[0]}"
                            f"\n  varnames_ref:  {dataref.getVarNamelist(self.eval_parameters)}"
                            "\nProof Dataset:"
                            f"\n  DSfile_proof:    {dataproof.getRecentResFiles()[0]}"
                            f"\n  varnames_proof:  {dataproof.getVarNamelist(self.eval_parameters)}"
                            "\nSkill Reference:"
                            f"\n  DSfile_skillref:    {DSskillrefiles}"
                            f"\n  varnames_skillref:  {DSskillrefvars}"
                            "\n=================================================\n"
                        )
                        Metric_class.OpenPrepare(
                            DSfile_ref = dataref.getRecentResFiles()[0],
                            DSfile_proof = dataproof.getRecentResFiles()[0],
                            varnames_ref = dataref.getVarNamelist(self.eval_parameters),
                            varnames_proof = dataproof.getVarNamelist(self.eval_parameters),
                            DSfile_skillref = DSskillrefiles,
                            varnames_skillref = DSskillrefvars,
                        )
                        #
                        dep_fnam_ref, dep_fnam_proof, dep_fnam_skill, dep_varns_ref, dep_varns_proof, dep_varns_skill = \
                            Metric_class.SolveDependencies(
                                metrics = metricclasses_filt[metricgroup],
                                dirout = datasetnew.getSubDirs()[1],
                                metrfnam = f'{self.name}_{metricgroup}_',
                                metr_setup = self.cfgmetrics,
                            )
                        # -- Finalize metrics:
                        Metric_class.Finalize()

                        # -- Do the evaluations after solving dependencies:
                        for metsgl in metricclasses_filt[metricgroup]:

                            RecentResFiles[metsgl] = []
                            moptio = self.cfgmetrics[metsgl]["option"]

                            logger.debug(
                                "\n=========== Metric Call (Second Time) ============"
                                "\nReference Dataset:"
                                f"\n  DSfile_ref:    {dep_fnam_ref[metsgl]}"
                                f"\n  varnames_ref:  {dep_varns_ref[metsgl]}"
                                "\nProof Dataset:"
                                f"\n  DSfile_proof:    {dep_fnam_proof[metsgl]}"
                                f"\n  varnames_proof:  {dep_varns_proof[metsgl]}"
                                "\nSkill Reference:"
                                f"\n  DSfile_skillref:    {dep_fnam_skill[metsgl]}"
                                f"\n  varnames_skillref:  {DSskillrefvars}"
                                "\n=================================================\n"
                            )
                            Metric_class.OpenPrepare(
                                DSfile_ref = dep_fnam_ref[metsgl],
                                DSfile_proof = dep_fnam_proof[metsgl],
                                varnames_ref = dep_varns_ref[metsgl],
                                varnames_proof = dep_varns_proof[metsgl],
                                DSfile_skillref = dep_fnam_skill[metsgl],
                                varnames_skillref = dep_varns_skill[metsgl],
                            )
                            new_varns = self.VarNaFMetEvalP(
                                metric = metsgl,
                                para = self.eval_parameters,
                            )

                            Metric_class.Calculate(
                                metric = metsgl,
                                varnames_result = new_varns,
                                metr_option = moptio,
                            )
                            logger.debug(
                                'Metric %s (class "%s") calculated with option: %s',
                                metsgl, metricgroup, moptio,
                            )

                            # -- Each metric knows its result:
                            RecentResFiles[metsgl].append(evalresult_file)
                            for evalparasgl in self.eval_parameters:
                                DictParam[evalparasgl, metsgl] = self.VarNaFMetEvalP(
                                    metric = metsgl,
                                    para = evalparasgl,
                                )
                            # -- Repairing the dataset and afterwards write it to file:
                            Metric_class.Finalize()
                        #
                        logger.info(
                            f'Calculations in metric operator class '
                            f'"{metricgroup}" finished.'
                        )

                        # -- Organize to calculate the subregional means and
                        #    find the final filenames:
                        if (self.subregions is not None) and (SubDomCalcPos == -1):
                            ffilepre, ffileext = os.path.splitext(evalresult_file)
                            subregion_files = pyxarray_object.ComputeSubDomains(
                                filenam = evalresult_file,
                                fileoutpre = ffilepre,
                                fvarnames = list(DictParam.values()),
                                subdoml = self.subregions,
                                subdommasks = self.maskfilesdict,
                                PossDimDict = self.cfggeneral["PossibleDimNames"],
                            )
                            # -- Append subregion files to RecentResFiles:
                            for metricsgl in metricclasses_filt[metricgroup]:
                                RecentResFiles[metricsgl] += subregion_files

                        # -- Do some final updates and repairings of the
                        #    dataset-instance 'datasetnew':

                        datasetnew.UpdateAttributes(
                            RecResFiles = RecentResFiles,
                            BibParamdict = DictParam,
                        )
                        logger.info(
                            f'Calculation of subregional things for the group "'
                            f'{metricgroup}" finished.'
                        )

    @log_function_name
    def Visualization(self: 'EvalRAW') -> None:
        """Vizualization of EvalRaw: """
        logger.info(f'{self.name} - Plotting of all datasets')
        dataobjects = self.FinalResDatasets
        # -- Organize the visualization:
        self.Visualization_org1D2D(dataobjects = dataobjects)
