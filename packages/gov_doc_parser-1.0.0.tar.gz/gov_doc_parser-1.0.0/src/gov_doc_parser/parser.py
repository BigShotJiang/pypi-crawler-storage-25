"""Main GovDocParser — orchestrates parsing and AI reference extraction."""

from __future__ import annotations

import re
import time
from typing import Any

from gov_doc_parser.extractors import (
    parse_atrs,
    parse_bailii,
    parse_fca,
    parse_govuk,
    parse_hansard,
    parse_ico,
)
from gov_doc_parser.models import (
    AIReference,
    ATRSRecord,
    DocumentSource,
    GovDocument,
    HansardEntry,
    ParseResult,
)

_AI_TERMS = [
    r"\bai\b",
    r"\bartificial intelligence\b",
    r"\bmachine learning\b",
    r"\bdeep learning\b",
    r"\bneural network\b",
    r"\balgorithm(?:ic)?\b",
    r"\bautomated decision(?:-making)?\b",
    r"\bautomatic(?:ed)? processing\b",
    r"\blarge language model\b",
    r"\bllm\b",
    r"\bgenerative ai\b",
    r"\bnatural language processing\b",
    r"\bpredictive (?:analytics|model|system)\b",
    r"\bfacial recognition\b",
    r"\bprofiling\b",
    r"\bfoundation model\b",
]
_AI_PATTERN = re.compile("|".join(_AI_TERMS), re.IGNORECASE)

_POSITIVE = re.compile(
    r"\b(benefit|opportunit|innovat|improve|efficien|effective|potenti|promis|support)\b",
    re.IGNORECASE,
)
_NEGATIVE = re.compile(
    r"\b(risk|harm|bias|discriminat|concern|danger|threat|fail|unlawful|breach|penalt)\b",
    re.IGNORECASE,
)
_REGULATORY = re.compile(
    r"\b(regulat|compli|govern|accountab|oversigh|audit|monitor|enforce|transparent|dpia)\b",
    re.IGNORECASE,
)

_SOURCE_PARSERS = {
    DocumentSource.GOVUK: parse_govuk,
    DocumentSource.HANSARD: parse_hansard,
    DocumentSource.ICO: parse_ico,
    DocumentSource.FCA: parse_fca,
    DocumentSource.BAILII: parse_bailii,
}


def _detect_source(html: str, url: str = "") -> DocumentSource:
    url_lower = url.lower()
    if "parliament.uk" in url_lower or "hansard" in url_lower:
        return DocumentSource.HANSARD
    if "ico.org.uk" in url_lower:
        return DocumentSource.ICO
    if "fca.org.uk" in url_lower:
        return DocumentSource.FCA
    if "bailii.org" in url_lower:
        return DocumentSource.BAILII
    if "atrs" in url_lower or "algorithmic-transparency" in url_lower:
        return DocumentSource.ATRS
    if "gov.uk" in url_lower:
        return DocumentSource.GOVUK
    html_lower = html[:3000].lower()
    if "information commissioner" in html_lower:
        return DocumentSource.ICO
    if "financial conduct authority" in html_lower:
        return DocumentSource.FCA
    if "hansard" in html_lower or "house of commons" in html_lower:
        return DocumentSource.HANSARD
    if "bailii" in html_lower or "neutral citation" in html_lower:
        return DocumentSource.BAILII
    return DocumentSource.GOVUK


class GovDocParser:
    """
    Parse UK government documents into structured data.

    Supports: GOV.UK, Hansard, ICO, FCA, BAILII, ATRS.

    Example:
        parser = GovDocParser()
        doc = parser.parse(html_text, source="ico")
        print(doc.title, doc.date, doc.metadata)

        result = parser.parse_full(html_text, source="govuk")
        for ref in result.ai_references:
            print(ref.sentiment, ref.term, ref.context[:80])

        doc, atrs = parser.parse_atrs(atrs_html)
        print(atrs.governance_score)
    """

    def __init__(self, keep_raw_html: bool = False) -> None:
        self.keep_raw_html = keep_raw_html

    def parse(
        self, html: str, source: str | DocumentSource = DocumentSource.UNKNOWN, url: str = ""
    ) -> GovDocument:
        """Parse HTML from a UK government source."""
        if isinstance(source, str):
            if source in ("auto", "unknown"):
                source = _detect_source(html, url)
            else:
                source = DocumentSource(source)
        parser_fn = _SOURCE_PARSERS.get(source)
        if parser_fn is None:
            if source == DocumentSource.ATRS:
                doc, _ = parse_atrs(html)
            else:
                source = _detect_source(html, url)
                parser_fn = _SOURCE_PARSERS.get(source, parse_govuk)
                doc = parser_fn(html)
        else:
            doc = parser_fn(html)
        doc.url = url
        if not self.keep_raw_html:
            doc.raw_html = ""
        return doc

    def parse_atrs(self, html: str, url: str = "") -> tuple[GovDocument, ATRSRecord]:
        """Parse an ATRS record, returning (GovDocument, ATRSRecord)."""
        doc, record = parse_atrs(html)
        doc.url = url
        if not self.keep_raw_html:
            doc.raw_html = ""
        return doc, record

    def extract_ai_references(
        self, doc: GovDocument, context_chars: int = 300
    ) -> list[AIReference]:
        """Extract all AI and algorithmic references from a parsed document."""
        if not doc.body_text:
            return []
        references: list[AIReference] = []
        sentences = re.split(r"(?<=[.!?])\s+", doc.body_text)
        for i, sentence in enumerate(sentences):
            if not _AI_PATTERN.search(sentence):
                continue
            match = _AI_PATTERN.search(sentence)
            if not match:
                continue
            term = match.group(0).lower()
            start = max(0, i - 1)
            end = min(len(sentences), i + 2)
            context = " ".join(sentences[start:end])[:context_chars]
            if _REGULATORY.search(context):
                sentiment = "regulatory"
            elif _NEGATIVE.search(context):
                sentiment = "negative"
            elif _POSITIVE.search(context):
                sentiment = "positive"
            else:
                sentiment = "neutral"
            section = ""
            for sec_name, sec_text in doc.sections.items():
                if sentence[:50] in sec_text:
                    section = sec_name
                    break
            references.append(
                AIReference(
                    term=term, context=context, section=section, sentiment=sentiment, line_number=i
                )
            )
        return references

    def parse_full(
        self, html: str, source: str | DocumentSource = DocumentSource.UNKNOWN, url: str = ""
    ) -> ParseResult:
        """Parse a document and run all extractions in one call."""
        t0 = time.time()
        errors: list[str] = []
        atrs_record: ATRSRecord | None = None
        hansard_entries: list[HansardEntry] = []

        if isinstance(source, str) and source not in ("auto", "unknown"):
            src = DocumentSource(source)
        elif isinstance(source, DocumentSource):
            src = source
        else:
            src = _detect_source(html, url)

        try:
            if src == DocumentSource.ATRS:
                doc, atrs_record = self.parse_atrs(html, url=url)
            else:
                doc = self.parse(html, source=src, url=url)
                if src == DocumentSource.HANSARD:
                    raw_entries = doc.metadata.get("entries", [])
                    hansard_entries = raw_entries if isinstance(raw_entries, list) else []
        except Exception as e:
            doc = GovDocument(source=src, title="")
            errors.append(str(e))

        ai_refs = self.extract_ai_references(doc) if doc.body_text else []
        return ParseResult(
            document=doc,
            ai_references=ai_refs,
            atrs_record=atrs_record,
            hansard_entries=hansard_entries,
            errors=errors,
            parse_time_ms=round((time.time() - t0) * 1000, 2),
        )

    def batch_parse(self, documents: list[dict[str, Any]]) -> list[ParseResult]:
        """Parse multiple documents. Each dict needs 'html', optional 'source' and 'url'."""
        return [
            self.parse_full(
                html=d.get("html", ""), source=d.get("source", "auto"), url=d.get("url", "")
            )
            for d in documents
        ]
