"""Source-specific HTML extractors — one function per UK government source."""

from __future__ import annotations

import re

from gov_doc_parser.html_utils import (
    clean_text,
    extract_attr,
    extract_date,
    find_all_tags,
    find_tag,
    html_to_text,
)
from gov_doc_parser.models import ATRSRecord, DocumentSource, GovDocument, HansardEntry


def parse_govuk(html: str) -> GovDocument:
    """Parse a GOV.UK publication or guidance page."""
    doc = GovDocument(source=DocumentSource.GOVUK, title="", raw_html=html)
    title_html = find_tag(html, "h1")
    if title_html:
        doc.title = clean_text(html_to_text(title_html))
    else:
        og = re.search(r'property="og:title"\s+content="([^"]+)"', html, re.IGNORECASE)
        if og:
            doc.title = og.group(1).strip()
    time_html = find_tag(html, "time")
    if time_html:
        doc.date = extract_attr(f"<time>{time_html}</time>", "datetime") or extract_date(time_html)
    if not doc.date:
        doc.date = extract_date(html[:5000])
    dept = find_all_tags(html, "span", {"class": "organisations"}) or find_all_tags(
        html, "a", {"class": "organisation-link"}
    )
    if dept:
        doc.metadata["department"] = clean_text(html_to_text(dept[0]))
    type_m = re.search(
        r'class="[^"]*document-type[^"]*"[^>]*>(.*?)<', html, re.IGNORECASE | re.DOTALL
    )
    if type_m:
        doc.metadata["document_type"] = clean_text(html_to_text(type_m.group(1)))
    body_candidates = [
        find_tag(html, "div", {"class": "govspeak"}),
        find_tag(html, "div", {"class": "gem-c-govspeak"}),
        find_tag(html, "main"),
        find_tag(html, "article"),
    ]
    body_html = next((b for b in body_candidates if b), None)
    if body_html:
        doc.body_text = html_to_text(body_html)
        doc.sections = _extract_sections(body_html)
    else:
        doc.body_text = html_to_text(html)[:8000]
    return doc


def parse_hansard(html: str) -> GovDocument:
    """Parse a Hansard parliamentary record."""
    doc = GovDocument(source=DocumentSource.HANSARD, title="", raw_html=html)
    title_html = find_tag(html, "h1") or find_tag(html, "h2")
    if title_html:
        doc.title = clean_text(html_to_text(title_html))
    doc.date = extract_date(html[:3000])
    if re.search(r"house of lords|lords\b", html[:2000], re.IGNORECASE):
        doc.metadata["house"] = "lords"
    elif re.search(r"house of commons|commons\b", html[:2000], re.IGNORECASE):
        doc.metadata["house"] = "commons"
    body_html = find_tag(html, "div", {"class": "debate"}) or find_tag(html, "main") or html
    doc.body_text = html_to_text(body_html)
    doc.sections = _extract_sections(body_html)
    entries = _extract_hansard_entries(html, doc.date, doc.metadata.get("house", "unknown"))
    doc.metadata["entry_count"] = len(entries)
    doc.metadata["entries"] = entries
    return doc


def parse_ico(html: str) -> GovDocument:
    """Parse an ICO enforcement notice, penalty notice, or guidance document."""
    doc = GovDocument(source=DocumentSource.ICO, title="", raw_html=html)
    title_html = find_tag(html, "h1")
    if title_html:
        doc.title = clean_text(html_to_text(title_html))
    doc.date = extract_date(html[:5000])
    if re.search(r"enforcement notice", html[:3000], re.IGNORECASE):
        doc.metadata["document_type"] = "enforcement_notice"
    elif re.search(r"penalty notice", html[:3000], re.IGNORECASE):
        doc.metadata["document_type"] = "penalty_notice"
    elif re.search(r"guidance", html[:3000], re.IGNORECASE):
        doc.metadata["document_type"] = "guidance"
    else:
        doc.metadata["document_type"] = "publication"
    fine_m = re.search(r"£([\d,]+(?:\.\d{2})?)\s*(?:penalty|fine|monetary)", html, re.IGNORECASE)
    if fine_m:
        doc.metadata["penalty_amount"] = fine_m.group(0)
    body_html = (
        find_tag(html, "article")
        or find_tag(html, "main")
        or find_tag(html, "div", {"class": "content"})
        or html
    )
    doc.body_text = html_to_text(body_html)
    doc.sections = _extract_sections(body_html)
    return doc


def parse_fca(html: str) -> GovDocument:
    """Parse an FCA regulatory document."""
    doc = GovDocument(source=DocumentSource.FCA, title="", raw_html=html)
    title_html = find_tag(html, "h1")
    if title_html:
        doc.title = clean_text(html_to_text(title_html))
    doc.date = extract_date(html[:5000])
    type_patterns = {
        "dear_ceo": r"dear\s+(?:ceo|chief executive)",
        "policy_statement": r"policy\s+statement",
        "consultation": r"consultation\s+paper",
        "guidance": r"finalised\s+guidance|fg\d+",
        "supervisory": r"supervisory\s+statement|ss\d+",
    }
    for dtype, pattern in type_patterns.items():
        if re.search(pattern, html[:3000], re.IGNORECASE):
            doc.metadata["document_type"] = dtype
            break
    ref_m = re.search(r"\b(PS|CP|FG|SS|DP)\s*\d{2}/\d+\b", html[:3000])
    if ref_m:
        doc.metadata["fca_reference"] = ref_m.group(0)
    body_html = (
        find_tag(html, "article")
        or find_tag(html, "main")
        or find_tag(html, "div", {"class": "content-block"})
        or html
    )
    doc.body_text = html_to_text(body_html)
    doc.sections = _extract_sections(body_html)
    return doc


def parse_bailii(html: str) -> GovDocument:
    """Parse a BAILII case law document."""
    doc = GovDocument(source=DocumentSource.BAILII, title="", raw_html=html)
    title_html = find_tag(html, "h1")
    if title_html:
        doc.title = clean_text(html_to_text(title_html))
    doc.date = extract_date(html[:5000])
    citation_m = re.search(
        r"\[20\d{2}\]\s+(?:UKSC|EWCA|EWHC|UKUT|UKET|UKFTT|UKHL)\s+\d+(?:\s+\([^)]+\))?",
        html[:3000],
    )
    if citation_m:
        doc.metadata["citation"] = citation_m.group(0)
    court_patterns = {
        "supreme_court": r"supreme court",
        "court_of_appeal": r"court of appeal",
        "high_court": r"high court|EWHC",
        "upper_tribunal": r"upper tribunal|UKUT",
    }
    for court, pattern in court_patterns.items():
        if re.search(pattern, html[:3000], re.IGNORECASE):
            doc.metadata["court"] = court
            break
    judge_m = re.search(
        r"(?:Mr Justice|Mrs Justice|Lord Justice|Lady Justice|HHJ)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)",
        html[:5000],
    )
    if judge_m:
        doc.metadata["judge"] = judge_m.group(0)
    body_html = find_tag(html, "div", {"class": "judgment"}) or find_tag(html, "main") or html
    doc.body_text = html_to_text(body_html)
    doc.sections = _extract_sections(body_html)
    return doc


def parse_atrs(html: str) -> tuple[GovDocument, ATRSRecord]:
    """Parse an ATRS record, returning both a GovDocument and structured ATRSRecord."""
    doc = GovDocument(source=DocumentSource.ATRS, title="", raw_html=html)
    title_html = find_tag(html, "h1")
    if title_html:
        doc.title = clean_text(html_to_text(title_html))
    doc.date = extract_date(html[:5000])
    doc.body_text = html_to_text(html)
    record = ATRSRecord(system_name=doc.title, date_published=doc.date)
    _extract_atrs_fields(html, record)
    return doc, record


def _extract_atrs_fields(html: str, record: ATRSRecord) -> None:
    text = html_to_text(html).lower()
    org_m = re.search(r"(?:organisation|department|owner)\s*:?\s*([^\n]+)", text)
    if org_m:
        record.organisation = org_m.group(1).strip()[:100]
    risk_m = re.search(r"risk\s+(?:tier|level|rating)\s*:?\s*([^\n,]+)", text, re.IGNORECASE)
    if risk_m:
        record.risk_tier = risk_m.group(1).strip()[:50]
    record.dpia_completed = _extract_yes_no(text, r"dpia\s+(?:completed|conducted|undertaken)")
    record.dpia_published = _extract_yes_no(text, r"dpia\s+(?:published|available|public)")
    record.human_review = _extract_yes_no(text, r"human\s+(?:review|oversight|in the loop)")
    oversight_patterns = [
        "human review",
        "audit trail",
        "appeal process",
        "regular review",
        "quality assurance",
        "monitoring",
        "evaluation",
        "oversight committee",
    ]
    record.oversight_mechanisms = [p for p in oversight_patterns if p in text]
    for lp in ["public task", "legal obligation", "legitimate interests", "consent", "contract"]:
        if lp in text:
            record.legal_basis = lp
            break
    scale_m = re.search(r"(?:scale|volume|number of decisions?)\s*:?\s*([^\n,]+)", text)
    if scale_m:
        record.scale = scale_m.group(1).strip()[:100]


def _extract_yes_no(text: str, pattern: str) -> bool | None:
    match = re.search(pattern + r".{0,100}", text, re.IGNORECASE)
    if not match:
        return None
    snippet = match.group(0).lower()
    if any(w in snippet for w in ["yes", "completed", "published", "available", "true"]):
        return True
    if any(w in snippet for w in ["no", "not completed", "not published", "n/a", "false"]):
        return False
    return None


def _extract_sections(html: str) -> dict[str, str]:
    sections: dict[str, str] = {}
    heading_pattern = re.compile(
        r"<h([2-4])[^>]*>(.*?)</h\1>(.*?)(?=<h[2-4]|$)", re.DOTALL | re.IGNORECASE
    )
    for match in heading_pattern.finditer(html):
        heading = clean_text(html_to_text(match.group(2)))
        content = html_to_text(match.group(3)).strip()
        if heading and content:
            sections[heading] = content[:2000]
    return sections


def _extract_hansard_entries(html: str, date: str, house: str) -> list[HansardEntry]:
    entries: list[HansardEntry] = []
    pattern = re.compile(
        r'<(?:div|p)[^>]*class="[^"]*(?:contribution|speech)[^"]*"[^>]*>(.*?)</(?:div|p)>',
        re.DOTALL | re.IGNORECASE,
    )
    for match in pattern.finditer(html):
        content = match.group(1)
        text = html_to_text(content).strip()
        if not text:
            continue
        speaker_m = re.search(r"<(?:strong|b)[^>]*>(.*?)</(?:strong|b)>", content, re.IGNORECASE)
        speaker = clean_text(html_to_text(speaker_m.group(1))) if speaker_m else ""
        entries.append(
            HansardEntry(
                date=date,
                house=house,
                speaker=speaker,
                text=text[:1000],
                ai_mentioned=bool(
                    re.search(
                        r"\b(?:artificial intelligence|algorithm|machine learning|automated decision)\b",
                        text,
                        re.IGNORECASE,
                    )
                ),
            )
        )
    return entries[:50]
