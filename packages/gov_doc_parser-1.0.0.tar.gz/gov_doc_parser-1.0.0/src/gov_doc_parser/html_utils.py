"""Lightweight HTML parsing — zero external dependencies, stdlib only."""

from __future__ import annotations

import html
import html.parser
import re


class _TextExtractor(html.parser.HTMLParser):
    SKIP_TAGS = {"script", "style", "head", "nav", "footer", "noscript"}
    BLOCK_TAGS = {
        "p",
        "div",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "li",
        "tr",
        "td",
        "th",
        "blockquote",
        "article",
        "section",
        "header",
        "main",
        "aside",
    }

    def __init__(self) -> None:
        super().__init__()
        self._parts: list[str] = []
        self._skip_depth = 0

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag in self.SKIP_TAGS:
            self._skip_depth += 1
        if tag in self.BLOCK_TAGS and self._parts and self._parts[-1] != "\n":
            self._parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in self.SKIP_TAGS:
            self._skip_depth = max(0, self._skip_depth - 1)
        if tag in self.BLOCK_TAGS:
            self._parts.append("\n")

    def handle_data(self, data: str) -> None:
        if self._skip_depth == 0:
            self._parts.append(data)

    def handle_entityref(self, name: str) -> None:
        self._parts.append(html.unescape(f"&{name};"))

    def handle_charref(self, name: str) -> None:
        self._parts.append(html.unescape(f"&#{name};"))

    def get_text(self) -> str:
        text = "".join(self._parts)
        return re.sub(r"\n{3,}", "\n\n", text).strip()


def html_to_text(html_str: str) -> str:
    """Convert HTML to plain text using stdlib only."""
    extractor = _TextExtractor()
    try:
        extractor.feed(html_str)
        return extractor.get_text()
    except Exception:
        text = re.sub(r"<[^>]+>", " ", html_str)
        return re.sub(r"\s+", " ", text).strip()


def find_tag(html_str: str, tag: str, attrs: dict[str, str] | None = None) -> str | None:
    """Find first occurrence of a tag and return its inner HTML."""
    if attrs:
        attr_patterns = "".join(
            rf'(?=[^>]*{re.escape(k)}=["\'][^"\']*{re.escape(v)}[^"\']*["\'])'
            for k, v in attrs.items()
        )
        pattern = rf"<{re.escape(tag)}{attr_patterns}[^>]*>(.*?)</{re.escape(tag)}>"
    else:
        pattern = rf"<{re.escape(tag)}[^>]*>(.*?)</{re.escape(tag)}>"
    match = re.search(pattern, html_str, re.DOTALL | re.IGNORECASE)
    return match.group(1) if match else None


def find_all_tags(html_str: str, tag: str, attrs: dict[str, str] | None = None) -> list[str]:
    """Find all occurrences of a tag and return their inner HTML."""
    if attrs:
        attr_patterns = "".join(
            rf'(?=[^>]*{re.escape(k)}=["\'][^"\']*{re.escape(v)}[^"\']*["\'])'
            for k, v in attrs.items()
        )
        pattern = rf"<{re.escape(tag)}{attr_patterns}[^>]*>(.*?)</{re.escape(tag)}>"
    else:
        pattern = rf"<{re.escape(tag)}[^>]*>(.*?)</{re.escape(tag)}>"
    return re.findall(pattern, html_str, re.DOTALL | re.IGNORECASE)


def extract_attr(tag_html: str, attr: str) -> str:
    """Extract a specific attribute value from a tag string."""
    match = re.search(rf'{re.escape(attr)}=["\']([^"\']*)["\']', tag_html, re.IGNORECASE)
    return match.group(1) if match else ""


def clean_text(text: str) -> str:
    """Normalise whitespace and unescape HTML entities."""
    text = html.unescape(text)
    return re.sub(r"\s+", " ", text).strip()


def extract_date(text: str) -> str:
    """Extract a date from text, returning ISO format where possible."""
    MONTH_MAP = {
        "january": "01",
        "february": "02",
        "march": "03",
        "april": "04",
        "may": "05",
        "june": "06",
        "july": "07",
        "august": "08",
        "september": "09",
        "october": "10",
        "november": "11",
        "december": "12",
        "jan": "01",
        "feb": "02",
        "mar": "03",
        "apr": "04",
        "jun": "06",
        "jul": "07",
        "aug": "08",
        "sep": "09",
        "oct": "10",
        "nov": "11",
        "dec": "12",
    }
    m = re.search(r"\b(20\d{2})-(\d{2})-(\d{2})\b", text)
    if m:
        return m.group(0)
    m = re.search(
        r"\b(\d{1,2})(?:st|nd|rd|th)?\s+(january|february|march|april|may|june|july|"
        r"august|september|october|november|december)\s+(20\d{2})\b",
        text,
        re.IGNORECASE,
    )
    if m:
        day = m.group(1).zfill(2)
        month = MONTH_MAP.get(m.group(2).lower(), "00")
        return f"{m.group(3)}-{month}-{day}"
    m = re.search(
        r"\b(january|february|march|april|may|june|july|august|september|"
        r"october|november|december)\s+(20\d{2})\b",
        text,
        re.IGNORECASE,
    )
    if m:
        month = MONTH_MAP.get(m.group(1).lower(), "00")
        return f"{m.group(2)}-{month}"
    m = re.search(r"\b(20\d{2})\b", text)
    return m.group(1) if m else ""
