"""Data models for gov-doc-parser."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class DocumentSource(str, Enum):
    GOVUK = "govuk"
    HANSARD = "hansard"
    ICO = "ico"
    FCA = "fca"
    BAILII = "bailii"
    ATRS = "atrs"
    UNKNOWN = "unknown"


@dataclass
class GovDocument:
    source: DocumentSource
    title: str
    date: str = ""
    url: str = ""
    body_text: str = ""
    sections: dict[str, str] = field(default_factory=dict)
    references: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    raw_html: str = ""

    @property
    def word_count(self) -> int:
        return len(self.body_text.split()) if self.body_text else 0

    @property
    def has_content(self) -> bool:
        return bool(self.title or self.body_text)

    def excerpt(self, chars: int = 300) -> str:
        return self.body_text[:chars] + ("…" if len(self.body_text) > chars else "")

    def __repr__(self) -> str:
        return f"GovDocument(source={self.source.value}, title={self.title[:50]!r}, date={self.date!r}, words={self.word_count})"


@dataclass
class AIReference:
    term: str
    context: str
    section: str = ""
    sentiment: str = "neutral"
    line_number: int = 0

    def __repr__(self) -> str:
        return f"AIReference({self.term!r}, {self.context[:60]!r})"


@dataclass
class ATRSRecord:
    system_name: str = ""
    organisation: str = ""
    department: str = ""
    description: str = ""
    date_published: str = ""
    risk_tier: str = ""
    oversight_mechanisms: list[str] = field(default_factory=list)
    human_review: bool | None = None
    dpia_completed: bool | None = None
    dpia_published: bool | None = None
    data_sources: list[str] = field(default_factory=list)
    personal_data: bool | None = None
    decisions_affected: str = ""
    scale: str = ""
    legal_basis: str = ""
    source_url: str = ""
    raw_fields: dict[str, Any] = field(default_factory=dict)

    @property
    def governance_score(self) -> int:
        score = 0
        if self.dpia_completed:
            score += 20
        if self.dpia_published:
            score += 20
        if self.human_review:
            score += 20
        if self.oversight_mechanisms:
            score += 20
        if self.legal_basis:
            score += 10
        if self.description and len(self.description) > 100:
            score += 10
        return score

    def __repr__(self) -> str:
        return f"ATRSRecord({self.system_name!r}, org={self.organisation!r}, risk={self.risk_tier!r}, gov_score={self.governance_score})"


@dataclass
class HansardEntry:
    date: str = ""
    house: str = ""
    entry_type: str = ""
    title: str = ""
    speaker: str = ""
    speaker_role: str = ""
    text: str = ""
    column: str = ""
    url: str = ""
    ai_mentioned: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        return f"HansardEntry(date={self.date!r}, house={self.house!r}, speaker={self.speaker!r})"


@dataclass
class ParseResult:
    document: GovDocument
    ai_references: list[AIReference] = field(default_factory=list)
    atrs_record: ATRSRecord | None = None
    hansard_entries: list[HansardEntry] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    parse_time_ms: float = 0.0

    @property
    def success(self) -> bool:
        return not self.errors and self.document.has_content

    def __repr__(self) -> str:
        return (
            f"ParseResult(source={self.document.source.value}, "
            f"ai_refs={len(self.ai_references)}, "
            f"{'OK' if self.success else 'ERRORS'})"
        )
