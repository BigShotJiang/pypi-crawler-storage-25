"""
gov_doc_parser — parse UK government documents into structured data.

Supports: GOV.UK, Hansard, ICO, FCA, BAILII, ATRS.
Zero external dependencies — pure Python stdlib.

Quick start:
    from gov_doc_parser import GovDocParser

    parser = GovDocParser()
    doc = parser.parse(html_text, source="ico")
    print(doc.title, doc.date)

    result = parser.parse_full(html_text, source="govuk")
    for ref in result.ai_references:
        print(ref.sentiment, ref.term)

    doc, atrs = parser.parse_atrs(atrs_html)
    print(atrs.governance_score)
"""

from gov_doc_parser.models import (
    AIReference,
    ATRSRecord,
    DocumentSource,
    GovDocument,
    HansardEntry,
    ParseResult,
)
from gov_doc_parser.parser import GovDocParser

__version__ = "1.0.0"
__author__ = "Linda Oraegbunam"
__all__ = [
    "GovDocParser",
    "GovDocument",
    "DocumentSource",
    "AIReference",
    "ATRSRecord",
    "HansardEntry",
    "ParseResult",
]
