"""gov-doc-parser CLI."""

from __future__ import annotations

import argparse
import json
import sys


def main() -> None:
    p = argparse.ArgumentParser(prog="gov-doc-parser", description="Parse UK government documents")
    p.add_argument("file", nargs="?", help="HTML file to parse (or stdin)")
    p.add_argument(
        "--source",
        "-s",
        default="auto",
        choices=["auto", "govuk", "hansard", "ico", "fca", "bailii", "atrs"],
    )
    p.add_argument("--url", default="")
    p.add_argument("--ai-refs", action="store_true")
    p.add_argument("--atrs", action="store_true")
    p.add_argument("--json", action="store_true", dest="json_out")
    args = p.parse_args()

    from gov_doc_parser import GovDocParser

    if args.file:
        from pathlib import Path

        html = Path(args.file).read_text(encoding="utf-8")
    elif not sys.stdin.isatty():
        html = sys.stdin.read()
    else:
        p.print_help()
        sys.exit(1)

    parser = GovDocParser()

    if args.atrs:
        doc, atrs = parser.parse_atrs(html, url=args.url)
        if args.json_out:
            print(
                json.dumps(
                    {
                        "system_name": atrs.system_name,
                        "organisation": atrs.organisation,
                        "risk_tier": atrs.risk_tier,
                        "dpia_completed": atrs.dpia_completed,
                        "governance_score": atrs.governance_score,
                    },
                    indent=2,
                )
            )
        else:
            print(f"\nSystem: {atrs.system_name}")
            print(f"Organisation: {atrs.organisation}")
            print(f"Risk tier: {atrs.risk_tier}")
            print(f"Governance score: {atrs.governance_score}/100\n")
    else:
        result = parser.parse_full(html, source=args.source, url=args.url)
        doc = result.document
        if args.json_out:
            out: dict = {
                "title": doc.title,
                "source": doc.source.value,
                "date": doc.date,
                "word_count": doc.word_count,
                "metadata": doc.metadata,
            }
            if args.ai_refs:
                out["ai_references"] = [
                    {"term": r.term, "sentiment": r.sentiment, "context": r.context}
                    for r in result.ai_references
                ]
            print(json.dumps(out, indent=2))
        else:
            print(f"\nTitle:   {doc.title}")
            print(f"Source:  {doc.source.value}")
            print(f"Date:    {doc.date}")
            print(f"Words:   {doc.word_count:,}")
            if args.ai_refs and result.ai_references:
                print(f"\nAI References ({len(result.ai_references)}):")
                for ref in result.ai_references[:5]:
                    print(f"  [{ref.sentiment}] {ref.term}: {ref.context[:80]}...")
            print()


if __name__ == "__main__":
    main()
