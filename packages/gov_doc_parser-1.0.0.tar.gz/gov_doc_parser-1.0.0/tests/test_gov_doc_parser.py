"""Tests for gov-doc-parser. Run: pytest tests/ -v"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from gov_doc_parser import (
    AIReference,
    ATRSRecord,
    DocumentSource,
    GovDocParser,
    GovDocument,
    ParseResult,
)
from gov_doc_parser.extractors import (
    parse_atrs,
    parse_bailii,
    parse_fca,
    parse_govuk,
    parse_hansard,
    parse_ico,
)
from gov_doc_parser.html_utils import (
    clean_text,
    extract_date,
    find_all_tags,
    find_tag,
    html_to_text,
)

# ── HTML fixtures ──────────────────────────────────────────────

GOVUK_HTML = """<!DOCTYPE html><html><body>
<h1>UK Artificial Intelligence Strategy</h1>
<time datetime="2026-04-09">9 April 2026</time>
<div class="govspeak">
<h2>Introduction</h2>
<p>The UK government is committed to developing artificial intelligence responsibly.
Machine learning and automated decision-making systems must comply with UK GDPR.</p>
<h2>Key Policy Areas</h2>
<p>This guidance covers algorithms used in public sector decision-making.
Human oversight of AI systems is required for high-risk applications.</p>
</div></body></html>"""

HANSARD_HTML = """<!DOCTYPE html><html><body>
<h1>AI Governance Debate</h1>
<p class="date">Wednesday 9 April 2026</p>
<p>House of Commons</p>
<div class="contribution">
<strong>The Minister for Technology</strong>
<p>The government is developing a framework for artificial intelligence governance.</p>
</div></body></html>"""

ICO_HTML = """<!DOCTYPE html><html><body>
<h1>Enforcement Notice: DataCorp Ltd</h1>
<p>Published: 15 March 2026</p>
<p>A penalty of £250,000 monetary penalty was imposed for breach of UK GDPR Article 22
on automated decision-making. The company deployed an AI algorithm without adequate
human oversight.</p>
<h2>Background</h2>
<p>DataCorp used machine learning to process loan applications automatically.</p>
</body></html>"""

FCA_HTML = """<!DOCTYPE html><html><body>
<h1>Dear CEO Letter: AI in Financial Services</h1>
<p class="date">1 April 2026</p>
<p>This letter sets out our expectations for firms using artificial intelligence
and machine learning models in credit decisioning. Firms must ensure algorithmic
models are explainable, fair, and subject to regular review.</p>
</body></html>"""

BAILII_HTML = """<!DOCTYPE html><html><body>
<h1>R (Digital Rights Foundation) v Secretary of State [2026] EWHC 123 (Admin)</h1>
<p>Judgment handed down: 9 April 2026</p>
<p>Before: Mr Justice Thompson</p>
<p>This case concerns the lawfulness of an automated decision-making system.
The algorithm was found to be unlawful under the Equality Act 2010.</p>
</body></html>"""

ATRS_HTML = """<!DOCTYPE html><html><body>
<h1>Automated Case Routing System</h1>
<p>Organisation: HM Revenue and Customs</p>
<p>Date published: March 2026</p>
<p>Risk tier: Medium</p>
<p>DPIA completed: Yes</p>
<p>DPIA published: No</p>
<p>Human review: Yes — all decisions reviewed by case officer</p>
<p>Legal basis: Public task</p>
<p>This system uses machine learning to route tax returns.</p>
</body></html>"""


# ── html_utils tests ───────────────────────────────────────────


class TestHtmlUtils:
    def test_html_to_text_strips_tags(self):
        text = html_to_text("<p>Hello <strong>world</strong></p>")
        assert "Hello" in text and "world" in text and "<" not in text

    def test_html_to_text_empty(self):
        assert html_to_text("") == ""

    def test_html_to_text_skips_script(self):
        text = html_to_text("<p>Visible</p><script>var x=1;</script>")
        assert "Visible" in text and "var x" not in text

    def test_extract_date_iso(self):
        assert extract_date("Published 2026-04-09") == "2026-04-09"

    def test_extract_date_uk_format(self):
        assert extract_date("9 April 2026") == "2026-04-09"

    def test_extract_date_year_only(self):
        assert extract_date("Published in 2026") == "2026"

    def test_extract_date_none(self):
        assert extract_date("no date here") == ""

    def test_find_tag_basic(self):
        assert find_tag("<div><p>Hello</p></div>", "p") == "Hello"

    def test_find_tag_missing(self):
        assert find_tag("<div>no p here</div>", "p") is None

    def test_find_all_tags(self):
        results = find_all_tags("<ul><li>A</li><li>B</li></ul>", "li")
        assert len(results) == 2

    def test_clean_text(self):
        assert clean_text("  hello   world  ") == "hello world"

    def test_clean_text_entities(self):
        assert "&amp;" not in clean_text("AT&amp;T")


# ── GovDocument model ──────────────────────────────────────────


class TestGovDocument:
    def test_word_count(self):
        doc = GovDocument(source=DocumentSource.GOVUK, title="Test", body_text="hello world foo")
        assert doc.word_count == 3

    def test_has_content_with_title(self):
        assert GovDocument(source=DocumentSource.GOVUK, title="Test").has_content

    def test_has_content_empty(self):
        assert not GovDocument(source=DocumentSource.GOVUK, title="").has_content

    def test_excerpt(self):
        doc = GovDocument(source=DocumentSource.GOVUK, title="T", body_text="A" * 500)
        assert len(doc.excerpt(100)) <= 104

    def test_repr(self):
        doc = GovDocument(source=DocumentSource.GOVUK, title="UK AI Strategy")
        assert "govuk" in repr(doc)


# ── Source-specific parsers ────────────────────────────────────


class TestGovUKParser:
    def test_extracts_title(self):
        doc = parse_govuk(GOVUK_HTML)
        assert "Artificial Intelligence" in doc.title or "AI" in doc.title

    def test_extracts_date(self):
        doc = parse_govuk(GOVUK_HTML)
        assert "2026" in doc.date

    def test_extracts_sections(self):
        doc = parse_govuk(GOVUK_HTML)
        assert len(doc.sections) >= 1

    def test_body_text_has_content(self):
        assert len(parse_govuk(GOVUK_HTML).body_text) > 50

    def test_source_is_govuk(self):
        assert parse_govuk(GOVUK_HTML).source == DocumentSource.GOVUK


class TestHansardParser:
    def test_extracts_title(self):
        assert parse_hansard(HANSARD_HTML).title

    def test_extracts_date(self):
        assert "2026" in parse_hansard(HANSARD_HTML).date

    def test_detects_house(self):
        assert parse_hansard(HANSARD_HTML).metadata.get("house") == "commons"

    def test_source_is_hansard(self):
        assert parse_hansard(HANSARD_HTML).source == DocumentSource.HANSARD


class TestICOParser:
    def test_extracts_title(self):
        doc = parse_ico(ICO_HTML)
        assert "DataCorp" in doc.title or "Enforcement" in doc.title

    def test_detects_document_type(self):
        doc = parse_ico(ICO_HTML)
        assert "enforcement" in doc.metadata.get("document_type", "").lower()

    def test_source_is_ico(self):
        assert parse_ico(ICO_HTML).source == DocumentSource.ICO


class TestFCAParser:
    def test_extracts_title(self):
        assert parse_fca(FCA_HTML).title

    def test_detects_dear_ceo(self):
        assert parse_fca(FCA_HTML).metadata.get("document_type") == "dear_ceo"

    def test_source_is_fca(self):
        assert parse_fca(FCA_HTML).source == DocumentSource.FCA


class TestBAILIIParser:
    def test_extracts_title(self):
        assert parse_bailii(BAILII_HTML).title

    def test_extracts_citation(self):
        doc = parse_bailii(BAILII_HTML)
        assert "citation" in doc.metadata and "EWHC" in doc.metadata["citation"]

    def test_extracts_judge(self):
        doc = parse_bailii(BAILII_HTML)
        assert "judge" in doc.metadata and "Thompson" in doc.metadata["judge"]

    def test_source_is_bailii(self):
        assert parse_bailii(BAILII_HTML).source == DocumentSource.BAILII


class TestATRSParser:
    def test_returns_tuple(self):
        result = parse_atrs(ATRS_HTML)
        assert isinstance(result, tuple) and len(result) == 2

    def test_extracts_organisation(self):
        _, atrs = parse_atrs(ATRS_HTML)
        assert "revenue" in atrs.organisation.lower() or "hmrc" in atrs.organisation.lower()

    def test_extracts_risk_tier(self):
        _, atrs = parse_atrs(ATRS_HTML)
        assert atrs.risk_tier

    def test_dpia_completed(self):
        _, atrs = parse_atrs(ATRS_HTML)
        assert atrs.dpia_completed is True

    def test_human_review(self):
        _, atrs = parse_atrs(ATRS_HTML)
        assert atrs.human_review is True

    def test_legal_basis(self):
        _, atrs = parse_atrs(ATRS_HTML)
        assert atrs.legal_basis


# ── ATRSRecord model ───────────────────────────────────────────


class TestATRSRecord:
    def test_governance_score_increases_with_fields(self):
        r = ATRSRecord()
        empty_score = r.governance_score
        r.dpia_completed = True
        r.dpia_published = True
        r.human_review = True
        r.oversight_mechanisms = ["human review"]
        r.legal_basis = "public task"
        assert r.governance_score > empty_score

    def test_max_governance_score(self):
        r = ATRSRecord(
            dpia_completed=True,
            dpia_published=True,
            human_review=True,
            oversight_mechanisms=["review"],
            legal_basis="public task",
            description="A" * 200,
        )
        assert r.governance_score == 100

    def test_repr(self):
        r = ATRSRecord(system_name="Test System", risk_tier="high")
        assert "Test System" in repr(r)


# ── GovDocParser ───────────────────────────────────────────────


class TestGovDocParser:
    @pytest.fixture
    def parser(self):
        return GovDocParser()

    def test_parse_govuk(self, parser):
        doc = parser.parse(GOVUK_HTML, source="govuk")
        assert doc.source == DocumentSource.GOVUK and doc.title

    def test_parse_auto_detect_ico(self, parser):
        doc = parser.parse(ICO_HTML, source="auto", url="https://ico.org.uk/enforcement/")
        assert doc.source == DocumentSource.ICO

    def test_parse_auto_detect_from_content(self, parser):
        # Auto-detect without URL falls back based on content signals
        result = parser.parse(ICO_HTML, source="auto")
        assert result.source in (DocumentSource.ICO, DocumentSource.GOVUK)

    def test_parse_atrs_returns_tuple(self, parser):
        doc, atrs = parser.parse_atrs(ATRS_HTML)
        assert isinstance(doc, GovDocument) and isinstance(atrs, ATRSRecord)

    def test_extract_ai_references_govuk(self, parser):
        doc = parser.parse(GOVUK_HTML, source="govuk")
        refs = parser.extract_ai_references(doc)
        assert len(refs) >= 1
        assert all(isinstance(r, AIReference) for r in refs)

    def test_ai_references_have_context(self, parser):
        doc = parser.parse(GOVUK_HTML, source="govuk")
        refs = parser.extract_ai_references(doc)
        assert all(r.context for r in refs)

    def test_ai_references_have_valid_sentiment(self, parser):
        doc = parser.parse(GOVUK_HTML, source="govuk")
        refs = parser.extract_ai_references(doc)
        valid = {"positive", "negative", "neutral", "regulatory"}
        assert all(r.sentiment in valid for r in refs)

    def test_extract_ai_from_enforcement_notice(self, parser):
        doc = parser.parse(ICO_HTML, source="ico")
        assert len(parser.extract_ai_references(doc)) >= 1

    def test_parse_full_returns_parse_result(self, parser):
        assert isinstance(parser.parse_full(GOVUK_HTML, source="govuk"), ParseResult)

    def test_parse_full_has_ai_refs(self, parser):
        assert len(parser.parse_full(GOVUK_HTML, source="govuk").ai_references) >= 1

    def test_parse_full_success(self, parser):
        assert parser.parse_full(GOVUK_HTML, source="govuk").success

    def test_parse_full_atrs(self, parser):
        result = parser.parse_full(ATRS_HTML, source="atrs")
        assert result.atrs_record is not None

    def test_batch_parse(self, parser):
        docs = [
            {"html": GOVUK_HTML, "source": "govuk"},
            {"html": ICO_HTML, "source": "ico"},
            {"html": FCA_HTML, "source": "fca"},
        ]
        results = parser.batch_parse(docs)
        assert len(results) == 3 and all(isinstance(r, ParseResult) for r in results)

    def test_parse_time_recorded(self, parser):
        assert parser.parse_full(GOVUK_HTML, source="govuk").parse_time_ms >= 0

    def test_no_raw_html_by_default(self, parser):
        assert parser.parse(GOVUK_HTML, source="govuk").raw_html == ""

    def test_keep_raw_html_flag(self):
        parser = GovDocParser(keep_raw_html=True)
        assert parser.parse(GOVUK_HTML, source="govuk").raw_html

    def test_empty_html_no_crash(self, parser):
        assert isinstance(parser.parse_full("", source="govuk"), ParseResult)

    def test_parse_fca_document(self, parser):
        doc = parser.parse(FCA_HTML, source="fca")
        assert doc.source == DocumentSource.FCA and doc.title

    def test_parse_bailii_document(self, parser):
        assert "citation" in parser.parse(BAILII_HTML, source="bailii").metadata

    def test_parse_result_repr(self, parser):
        assert "ParseResult" in repr(parser.parse_full(GOVUK_HTML, source="govuk"))
