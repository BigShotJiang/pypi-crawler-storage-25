# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import PluginBase, MainPageResult, SearchResult, MovieInfo, SeriesInfo, Episode, ExtractResult, HTMLHelper
import re

class FilmciBaba(PluginBase):
    name        = "FilmciBaba"
    language    = "tr"
    main_url    = "https://izleplus.com"
    favicon     = f"https://www.google.com/s2/favicons?domain={main_url}&sz=64"
    description = "Filmci Baba, film izleme sitesi 4k Full film izle, 1080p ve 4k kalite de sinema filmleri ve dizileri, tek parça hd kalitede türkçe dublajlı filmler seyret."

    main_page = {
        f"{main_url}/Kategori/en-populer-filmler/page"        : "En Popüler Filmler",
        f"{main_url}/Kategori/tur/aksiyon-filmleri/page"      : "Aksiyon",
        f"{main_url}/Kategori/tur/macera-filmleri/page"       : "Macera",
        f"{main_url}/Kategori/tur/bilim-kurgu-filmleri/page"  : "Bilim Kurgu",
        f"{main_url}/Kategori/tur/fantastik-filmler/page"     : "Fantastik",
        f"{main_url}/Kategori/tur/korku-filmleri/page"        : "Korku",
        f"{main_url}/Kategori/tur/gerilim-filmleri-hd/page"   : "Gerilim",
        f"{main_url}/Kategori/tur/gizem-filmleri/page"        : "Gizem",
        f"{main_url}/Kategori/tur/dram-filmleri-hd/page"      : "Dram",
        f"{main_url}/Kategori/tur/komedi-filmleri-hd/page"    : "Komedi",
        f"{main_url}/Kategori/tur/romantik-filmler/page"      : "Romantik",
        f"{main_url}/Kategori/tur/aile-filmleri/page"         : "Aile",
        f"{main_url}/Kategori/tur/animasyon-filmleri/page"    : "Animasyon",
        f"{main_url}/Kategori/tur/biyografi-filmleri/page"    : "Biyografi",
        f"{main_url}/Kategori/tur/polisiye-suc-filmleri/page" : "Polisiye / Suç",
        f"{main_url}/Kategori/tur/savas-filmleri/page"        : "Savaş",
        f"{main_url}/Kategori/tur/western-filmler/page"       : "Western",
        f"{main_url}/Kategori/tur/hint-filmleri/page"         : "Hint Filmleri",
        f"{main_url}/Kategori/tur/kore-filmleri/page"         : "Kore Filmleri",
        f"{main_url}/Kategori/tur/yerli-filmler-izle/page"    : "Yerli Filmler",
        f"{main_url}/Kategori/tur/yerli-diziler/page"         : "Yerli Diziler",
        f"{main_url}/Kategori/tur/18-erotik-filmler/page"     : "+18 Erotik Filmler",
    }

    async def get_main_page(self, page: int, url: str, category: str) -> list[MainPageResult]:
        istek  = await self.httpx.get(f"{url}/{page}/")
        secici = HTMLHelper(istek.text)

        results = []
        for item in secici.select("div.movie-preview, div.v50-card"):
            title_el = item.select_first(".movie-title a") or item.select_first("a")
            if not title_el:
                continue

            title  = title_el.attrs.get("title") or title_el.text(strip=True)
            href   = self.fix_url(title_el.attrs.get("href"))
            poster = self.fix_url(item.select_poster(".movie-poster img, img"))

            results.append(MainPageResult(
                category = category,
                title    = title,
                url      = href,
                poster   = poster
            ))

        return results

    async def search(self, query: str) -> list[SearchResult]:
        istek  = await self.httpx.get(f"{self.main_url}/?s={query}")
        secici = HTMLHelper(istek.text)

        results = []
        for item in secici.select("div.movie-preview, div.v50-card"):
            title_el = item.select_first(".movie-title a") or item.select_first("a")
            if not title_el:
                continue

            title  = title_el.attrs.get("title") or title_el.text(strip=True)
            href   = self.fix_url(title_el.attrs.get("href"))
            poster = self.fix_url(item.select_poster(".movie-poster img, img"))

            results.append(SearchResult(
                title  = title,
                url    = href,
                poster = poster
            ))

        return results

    async def load_item(self, url: str) -> MovieInfo | SeriesInfo:
        istek  = await self.httpx.get(url)
        secici = HTMLHelper(istek.text)

        title  = secici.select_text("h1.p-v12-main-title") or secici.select_text("div.title h1")
        poster = secici.select_poster(".p-v12-poster-main img") or secici.select_poster("img.wp-post-image") or secici.select_poster(".poster img")

        description = secici.select_text("div.p-v12-story-content") or secici.select_text(".excerpt p")
        if description:
            h2_el = secici.select_first("div.p-v12-story-content h2")
            if h2_el:
                h2_text = h2_el.text(strip=True)
                if description.startswith(h2_text):
                    description = description[len(h2_text):].strip()
            description = description.replace("kesintisizfilmcibabaizle", "").strip()

        year   = secici.extract_year(".p-v12-meta-info span.meta-item", ".meta-item", ".release", ".movie-info")
        rating = secici.regex_first(r"([\d\.]+)", secici.select_text(".p-v12-imdb-badge")) or secici.regex_first(r"([\d\.]+)", secici.select_text(".imdb-rating"))
        tags   = secici.select_texts(".p-v12-meta-info a[href*='/Kategori/tur/']") or secici.select_texts(".p-v12-info-centered a[href*='/Kategori/tur/']") or secici.select_texts("div.categories a[href*='/Kategori/tur/']")
        actors = secici.select_texts("a[href*='/oyuncular/']") or secici.select_texts(".cast-list .actor-name, .cast-list a")

        if not actors and description:
            actor_matches = re.findall(r"([A-Z][a-z]+ [A-Z][a-z]+)(?:\s*\([^)]*rolünde\))", description)
            if actor_matches:
                actors = list(dict.fromkeys(actor_matches))

        # Bölüm linklerini kontrol et
        ep_elements = secici.select(".parts-middle a, .parts-middle .part.active")

        if not ep_elements:
            return MovieInfo(
                url         = url,
                title       = title,
                description = description if description else None,
                poster      = self.fix_url(poster),
                year        = year,
                rating      = rating if rating != "." else None,
                tags        = tags,
                actors      = actors
            )

        episodes = []
        for i, el in enumerate(ep_elements):
            name = el.select_text(".part-name") or f"Bölüm {i+1}"
            href = el.attrs.get("href") or url
            s, e = secici.extract_season_episode(name)
            episodes.append(Episode(season=s or 1, episode=e or (i + 1), title=name, url=self.fix_url(href)))

        return SeriesInfo(
            url         = url,
            title       = title,
            description = description if description else None,
            poster      = self.fix_url(poster),
            year        = year,
            rating      = rating,
            tags        = tags,
            actors      = actors,
            episodes    = episodes
        )

    async def load_links(self, url: str) -> list[ExtractResult]:
        istek  = await self.httpx.get(url)
        secici = HTMLHelper(istek.text)

        iframe = None
        for sel in ["iframe[data-litespeed-src*='hotstream.club']",
                    "iframe[data-src*='hotstream.club']",
                    "iframe[src*='hotstream.club']",
                    ".plus-v12-player-wrap iframe",
                    "iframe"]:
            el = secici.select_first(sel)
            if el:
                iframe = el.attrs.get("data-litespeed-src") or el.attrs.get("data-src") or el.attrs.get("src")
                if iframe and iframe != "about:blank":
                    break

        results = []

        if iframe:
            iframe = self.fix_url(iframe)

            # Use general extract method
            extracted = await self.extract(iframe)
            if extracted:
                self.collect_results(results, extracted)
            else:
                 results.append(ExtractResult(
                    name    = "FilmciBaba | External",
                    url     = iframe,
                    referer = url
                ))

        return results
