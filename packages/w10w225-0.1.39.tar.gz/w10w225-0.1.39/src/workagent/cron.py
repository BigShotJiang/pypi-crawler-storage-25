from __future__ import annotations

import logging
import subprocess
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

CRON_MARKER = "# workagent-codex-cleanup"
CRON_SCHEDULE = "0 3 * * *"


def _project_root() -> Path:
    # src/workagent/cron.py → src/workagent → src → project root
    return Path(__file__).parent.parent.parent


def _build_cron_line(project_root: Path, python_executable: str, logs_dir: Path) -> str:
    script = project_root / "scripts" / "cleanup_codex_logs.py"
    log_file = logs_dir / "cleanup_codex_logs.log"
    return (
        f"{CRON_SCHEDULE} "
        f"cd {project_root} && {python_executable} {script} "
        f">> {log_file} 2>&1 {CRON_MARKER}"
    )


def _read_crontab() -> str:
    result = subprocess.run(["crontab", "-l"], capture_output=True, text=True)  # noqa: S607 S603
    return result.stdout if result.returncode == 0 else ""


def _write_crontab(content: str) -> None:
    subprocess.run(["crontab", "-"], input=content, text=True, check=True)  # noqa: S607 S603


def register_cleanup_cron(
    *,
    python_executable: str | None = None,
    project_root: Path | None = None,
    logs_dir: Path | None = None,
) -> bool:
    """Register the daily codex log cleanup cron job.

    Returns True if newly registered, False if already present.
    """
    root = project_root or _project_root()
    python = python_executable or sys.executable
    resolved_logs_dir = logs_dir or (Path.home() / ".personal-work-agent" / "logs")

    cron_line = _build_cron_line(root, python, resolved_logs_dir)
    current = _read_crontab()

    if CRON_MARKER in current:
        logger.debug("cron cleanup job already registered")
        return False

    new_content = current
    if new_content and not new_content.endswith("\n"):
        new_content += "\n"
    new_content += cron_line + "\n"

    _write_crontab(new_content)
    logger.info("cron cleanup job registered schedule=%s", CRON_SCHEDULE)
    return True


def unregister_cleanup_cron() -> bool:
    """Remove the daily codex log cleanup cron job.

    Returns True if removed, False if it was not present.
    """
    current = _read_crontab()
    if CRON_MARKER not in current:
        logger.debug("cron cleanup job not found, nothing to remove")
        return False

    lines = [line for line in current.splitlines() if CRON_MARKER not in line]
    new_content = "\n".join(lines)
    if new_content and not new_content.endswith("\n"):
        new_content += "\n"

    _write_crontab(new_content)
    logger.info("cron cleanup job unregistered")
    return True
