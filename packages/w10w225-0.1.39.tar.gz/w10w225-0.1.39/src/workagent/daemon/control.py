from __future__ import annotations

import os
import signal
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import uvicorn

from workagent.app.server import create_app
from workagent.config.paths import AppPaths, ensure_app_directories, resolve_app_paths
from workagent.runtime_logging import build_uvicorn_log_config, cleanup_runtime_log_files, resolve_daily_log_file


class ProcessOps(Protocol):
    def spawn(self, args: list[str], cwd: Path) -> int: ...

    def is_running(self, pid: int) -> bool: ...

    def terminate(self, pid: int) -> None: ...


@dataclass(slots=True)
class PosixProcessOps:
    def spawn(self, args: list[str], cwd: Path) -> int:
        process = subprocess.Popen(  # noqa: S603
            args,
            cwd=str(cwd),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
        return int(process.pid)

    def is_running(self, pid: int) -> bool:
        try:
            os.kill(pid, 0)
        except OSError:
            return False
        return True

    def terminate(self, pid: int) -> None:
        os.kill(pid, signal.SIGTERM)


class LocalDaemonController:
    def __init__(
        self,
        *,
        paths: AppPaths | None = None,
        process_ops: ProcessOps | None = None,
        host: str = "127.0.0.1",
        port: int = 8713,
    ) -> None:
        self.paths = paths or resolve_app_paths()
        self.process_ops = process_ops or PosixProcessOps()
        self.host = host
        self.port = port

    def is_running(self) -> bool:
        pid = self._read_pid()
        if pid is None:
            return False
        if self.process_ops.is_running(pid):
            return True
        self._remove_pidfile()
        return False

    def start_background(self) -> None:
        ensure_app_directories(self.paths)
        if self.is_running():
            return
        args = [
            sys.executable,
            "-m",
            "workagent",
            "serve",
            "--foreground",
        ]
        pid = self.process_ops.spawn(args, self.paths.root)
        self.paths.daemon_pid_file.write_text(f"{pid}\n", encoding="utf-8")

    def stop(self) -> None:
        pid = self._read_pid()
        if pid is None:
            return
        if self.process_ops.is_running(pid):
            self.process_ops.terminate(pid)
        self._remove_pidfile()

    def restart_background(self) -> None:
        self.stop()
        self.start_background()

    def serve_foreground(self) -> None:
        ensure_app_directories(self.paths)
        cleanup_runtime_log_files(home_dir=self.paths.root)
        log_file = resolve_daily_log_file(prefix="serve", home_dir=self.paths.root)
        uvicorn.run(
            create_app(),
            host=self.host,
            port=self.port,
            log_level="info",
            log_config=build_uvicorn_log_config(log_file),
        )

    def _read_pid(self) -> int | None:
        if not self.paths.daemon_pid_file.exists():
            return None
        raw = self.paths.daemon_pid_file.read_text(encoding="utf-8").strip()
        return int(raw) if raw else None

    def _remove_pidfile(self) -> None:
        self.paths.daemon_pid_file.unlink(missing_ok=True)
