from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path

from workagent.config.store import ConfigPaths
from workagent.cron import register_cleanup_cron, unregister_cleanup_cron
from workagent.runtime.process_env import build_workagent_process_env
from workagent.runtime_logging import cleanup_runtime_log_files, resolve_daily_log_file


class DaemonStatus(StrEnum):
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    FAILED = "failed"


def _write_daemon_lifecycle_log(action: str, *, home_dir: Path | None = None, **details: object) -> None:
    log_file = resolve_daily_log_file(prefix="serve", home_dir=home_dir)
    timestamp = datetime.now(UTC).isoformat()
    detail_blob = " ".join(f"{key}={value}" for key, value in details.items())
    with log_file.open("a", encoding="utf-8") as handle:
        handle.write(f"{timestamp} INFO [workagent.daemon] action={action} {detail_blob}\n")


def build_background_command(python_executable: str | None = None, home_dir: Path | None = None) -> list[str]:
    command = [
        python_executable or sys.executable,
        "-m",
        "workagent",
    ]
    if home_dir is not None:
        command.extend(["--home", str(home_dir)])
    command.extend(["serve", "--foreground"])
    return command


def read_pidfile(pid_file: Path) -> int | None:
    if not pid_file.exists():
        return None
    raw_value = pid_file.read_text(encoding="utf-8").strip()
    if not raw_value:
        return None
    try:
        return int(raw_value)
    except ValueError:
        return None


def write_pidfile(pid_file: Path, pid: int) -> None:
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    pid_file.write_text(f"{pid}\n", encoding="utf-8")


def is_pid_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    if sys.platform.startswith("linux"):
        state = _linux_process_state(pid)
        if state == "Z":
            return False
    return True


def _linux_process_state(pid: int) -> str | None:
    stat_path = Path(f"/proc/{pid}/stat")
    try:
        raw = stat_path.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    closing = raw.rfind(")")
    if closing < 0 or closing + 2 >= len(raw):
        return None
    state = raw[closing + 2 :].split(" ", 1)[0].strip()
    return state or None


def cleanup_stale_pidfile(pid_file: Path) -> None:
    pid = read_pidfile(pid_file)
    if pid is None:
        if pid_file.exists():
            pid_file.unlink(missing_ok=True)
        return
    if not is_pid_running(pid):
        pid_file.unlink(missing_ok=True)


def determine_status(pid_file: Path) -> DaemonStatus:
    cleanup_stale_pidfile(pid_file)
    pid = read_pidfile(pid_file)
    if pid is None:
        return DaemonStatus.STOPPED
    return DaemonStatus.RUNNING if is_pid_running(pid) else DaemonStatus.STOPPED


def _finalize_stopped(pid_file: Path, *, pid: int | None = None, status: str = "stopped") -> bool:
    pid_file.unlink(missing_ok=True)
    _write_daemon_lifecycle_log("stop", home_dir=pid_file.parent.parent, pid=pid, status=status)
    try:
        unregister_cleanup_cron()
    except Exception:
        pass  # cron removal is best-effort
    return True


def kill_all_workagent_serve_processes() -> list[int]:
    """Kill lingering workagent/w10w225 processes, including orphaned wrappers."""
    current_pid = os.getpid()
    try:
        result = subprocess.run(
            ["ps", "-eo", "pid=,ppid=,args="],
            capture_output=True,
            text=True,
        )
    except Exception:
        return []

    processes: list[tuple[int, int, str]] = []
    for raw_line in result.stdout.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            continue
        pid = int(parts[0])
        ppid = int(parts[1])
        command = parts[2]
        if pid == current_pid:
            continue
        normalized = f" {command} "
        if " w10w225 " not in normalized and "/w10w225 " not in normalized and " -m workagent " not in normalized:
            continue
        processes.append((pid, ppid, command))

    if not processes:
        return []

    parents = {pid: ppid for pid, ppid, _ in processes}

    def _depth(pid: int) -> int:
        depth = 0
        seen: set[int] = set()
        current = pid
        while current in parents and current not in seen:
            seen.add(current)
            current = parents[current]
            depth += 1
        return depth

    ordered = sorted(processes, key=lambda item: (-_depth(item[0]), item[0]))
    killed: list[int] = []
    for pid, _ppid, _command in ordered:
        try:
            os.kill(pid, signal.SIGTERM)
            killed.append(pid)
        except OSError:
            continue

    if killed:
        time.sleep(0.5)
    for pid in list(killed):
        if not is_pid_running(pid):
            continue
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            continue

    return killed


class DaemonController:
    def __init__(self, paths: ConfigPaths, python_executable: str | None = None):
        self.paths = paths
        self.python_executable = python_executable or sys.executable

    def status(self) -> DaemonStatus:
        return determine_status(self.paths.pid_file)

    def start(self) -> int:
        kill_all_workagent_serve_processes()
        self.paths.pid_file.unlink(missing_ok=True)

        self.paths.logs_dir.mkdir(parents=True, exist_ok=True)
        self.paths.runs_dir.mkdir(parents=True, exist_ok=True)
        cleanup_runtime_log_files(logs_dir=self.paths.logs_dir)
        process = subprocess.Popen(
            build_background_command(self.python_executable, home_dir=self.paths.root_dir),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
            env=build_workagent_process_env(self.paths.root_dir),
        )
        write_pidfile(self.paths.pid_file, process.pid)
        _write_daemon_lifecycle_log("start", home_dir=self.paths.root_dir, pid=process.pid)
        try:
            register_cleanup_cron(
                python_executable=self.python_executable,
                logs_dir=self.paths.logs_dir,
            )
        except Exception:
            pass  # cron registration is best-effort
        return process.pid

    def stop(self) -> bool:
        pid = read_pidfile(self.paths.pid_file)
        if pid is None:
            killed = kill_all_workagent_serve_processes()
            if killed:
                return _finalize_stopped(self.paths.pid_file, status="stopped_orphans")
            _write_daemon_lifecycle_log("stop", home_dir=self.paths.root_dir, status="missing_pidfile")
            return False
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            self.paths.pid_file.unlink(missing_ok=True)
            _write_daemon_lifecycle_log("stop", home_dir=self.paths.root_dir, pid=pid, status="missing_process")
            return False
        for _ in range(10):
            if not is_pid_running(pid):
                return _finalize_stopped(self.paths.pid_file, pid=pid, status="stopped")
            time.sleep(0.1)
        if not is_pid_running(pid):
            return _finalize_stopped(self.paths.pid_file, pid=pid, status="stopped")
        killed = kill_all_workagent_serve_processes()
        if killed:
            time.sleep(0.5)
            if not is_pid_running(pid):
                return _finalize_stopped(self.paths.pid_file, pid=pid, status="stopped_force_cleanup")
        _write_daemon_lifecycle_log("stop", home_dir=self.paths.root_dir, pid=pid, status="timeout")
        return False

    def restart(self) -> int:
        self.stop()
        pid = self.start()
        _write_daemon_lifecycle_log("restart", home_dir=self.paths.root_dir, pid=pid)
        return pid
