from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Protocol


def _utc_now() -> datetime:
    return datetime.now(UTC)


class CursorStore(Protocol):
    async def load(self) -> str | None: ...

    async def save(self, cursor: str | None) -> None: ...


class JiraClient(Protocol):
    async def search_issues(self, jql: str, *, limit: int = 20) -> list[dict]: ...


@dataclass(frozen=True, slots=True)
class JiraSyncEvent:
    id: str
    issue_key: str
    project_key: str
    summary: str
    updated_at: str
    payload: dict


@dataclass(frozen=True, slots=True)
class JiraSyncBatch:
    events: list[JiraSyncEvent]
    previous_cursor: str | None
    next_cursor: str | None


class JiraSyncService:
    def __init__(
        self,
        *,
        client: JiraClient,
        cursor_store: CursorStore,
        limit: int = 20,
        lookback_window_minutes: int = 0,
        preset: str = "personal_inbox",
        project_keys: list[str] | None = None,
        optional_keywords: list[str] | None = None,
        optional_jql: str | None = None,
    ) -> None:
        self._client = client
        self._cursor_store = cursor_store
        self._limit = limit
        self._lookback_window_minutes = max(0, int(lookback_window_minutes))
        self._preset = str(preset or "personal_inbox").strip() or "personal_inbox"
        self._project_keys = [item.strip() for item in (project_keys or []) if item.strip()]
        self._optional_keywords = [item.strip().lower() for item in (optional_keywords or []) if item.strip()]
        self._optional_jql = str(optional_jql or "").strip() or None

    async def sync_once(self) -> JiraSyncBatch:
        previous_cursor = await self._cursor_store.load()
        request_cursor = self._request_cursor(previous_cursor)
        raw_issues = await self._client.search_issues(self._build_jql(request_cursor), limit=self._limit)
        events = [
            self._normalize_issue(issue)
            for issue in raw_issues
            if self._matches_watch_profile(issue)
        ]
        next_cursor = self._next_cursor(events, previous_cursor)
        return JiraSyncBatch(events=events, previous_cursor=previous_cursor, next_cursor=next_cursor)

    async def commit(self, batch: JiraSyncBatch) -> None:
        await self._cursor_store.save(batch.next_cursor)

    def _request_cursor(self, stored_cursor: str | None) -> str | None:
        if self._lookback_window_minutes <= 0:
            return stored_cursor
        lookback_floor = _utc_now() - timedelta(minutes=self._lookback_window_minutes)
        if not stored_cursor:
            return _format_cursor(lookback_floor)
        parsed_cursor = _parse_cursor(stored_cursor)
        if parsed_cursor is None:
            return stored_cursor
        return _format_cursor(min(parsed_cursor, lookback_floor))

    def _build_jql(self, cursor: str | None) -> str:
        clauses = ["order by updated desc"]
        filters: list[str] = []
        if cursor:
            filters.append(f'updated >= "{_format_jql_timestamp(cursor)}"')
        if self._project_keys:
            quoted = ", ".join(f'"{item}"' for item in self._project_keys)
            filters.append(f"project in ({quoted})")
        signal_clause = self._signal_clause()
        if signal_clause:
            filters.append(f"({signal_clause})")
        if self._optional_jql:
            filters.append(f"({self._optional_jql})")
        if not filters:
            return " ".join(clauses)
        return " AND ".join(filters + clauses)

    def _signal_clause(self) -> str | None:
        if self._preset != "personal_inbox":
            return None
        return "assignee = currentUser() OR reporter = currentUser() OR watcher = currentUser() OR text ~ currentUser()"

    def _matches_watch_profile(self, issue: dict) -> bool:
        event = self._normalize_issue(issue)
        if not event.issue_key or not event.updated_at or not event.summary:
            return False
        if self._project_keys and event.project_key not in self._project_keys:
            return False
        status_name = str((event.payload.get("status") or {}).get("name") or "").strip().lower()
        status_category = str(
            ((event.payload.get("status") or {}).get("statusCategory") or {}).get("name") or ""
        ).strip().lower()
        if status_name in {"done", "closed", "resolved"} or status_category == "done":
            return False
        if not self._optional_keywords:
            return True
        haystacks = [event.summary.lower(), event.project_key.lower()]
        description = event.payload.get("description")
        if isinstance(description, str):
            haystacks.append(description.lower())
        combined = "\n".join(haystacks)
        return any(keyword in combined for keyword in self._optional_keywords)

    @staticmethod
    def _normalize_issue(issue: dict) -> JiraSyncEvent:
        fields = issue.get("fields") if isinstance(issue.get("fields"), dict) else {}
        project = fields.get("project") if isinstance(fields.get("project"), dict) else {}
        issue_key = str(issue.get("key") or "").strip()
        updated_at = str(fields.get("updated") or "").strip()
        return JiraSyncEvent(
            id=f"{issue_key}:{updated_at}" if issue_key and updated_at else issue_key or updated_at,
            issue_key=issue_key,
            project_key=str(project.get("key") or "").strip(),
            summary=str(fields.get("summary") or "").strip(),
            updated_at=updated_at,
            payload=fields,
        )

    @staticmethod
    def _next_cursor(events: list[JiraSyncEvent], previous_cursor: str | None) -> str | None:
        timestamps = [_parse_cursor(event.updated_at) for event in events]
        parsed_values = [value for value in timestamps if value is not None]
        if not parsed_values:
            return previous_cursor
        return _format_cursor(max(parsed_values))


def _parse_cursor(raw_value: str) -> datetime | None:
    value = str(raw_value or "").strip()
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _format_cursor(value: datetime) -> str:
    return value.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _format_jql_timestamp(raw_cursor: str) -> str:
    parsed = _parse_cursor(raw_cursor)
    if parsed is None:
        return raw_cursor
    return parsed.astimezone(UTC).strftime("%Y-%m-%d %H:%M")
