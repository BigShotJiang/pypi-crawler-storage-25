from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True, slots=True)
class SlackMessage:
    channel_id: str
    message_ts: str
    text: str
    user_id: str
    thread_ts: str | None = None


@dataclass(frozen=True, slots=True)
class SlackFetchResponse:
    messages: list[SlackMessage]
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class SlackSyncEvent:
    event_type: str
    channel_id: str
    message_ts: str
    thread_ts: str | None
    user_id: str
    text: str


@dataclass(frozen=True, slots=True)
class SlackSyncBatch:
    events: list[SlackSyncEvent]
    previous_cursor: str | None
    next_cursor: str | None


class CursorStore(Protocol):
    async def load(self) -> str | None: ...

    async def save(self, cursor: str | None) -> None: ...


class SlackClient(Protocol):
    async def fetch_recent(self, *, cursor: str | None = None, limit: int = 50) -> SlackFetchResponse: ...


class SlackSyncPoller:
    def __init__(self, *, client: SlackClient, cursor_store: CursorStore, limit: int = 50) -> None:
        self._client = client
        self._cursor_store = cursor_store
        self._limit = limit

    async def poll_once(self) -> SlackSyncBatch:
        previous_cursor = await self._cursor_store.load()
        response = await self._client.fetch_recent(cursor=previous_cursor, limit=self._limit)
        next_cursor = response.next_cursor if response.next_cursor is not None else previous_cursor
        return SlackSyncBatch(
            events=[self._normalize(message) for message in response.messages],
            previous_cursor=previous_cursor,
            next_cursor=next_cursor,
        )

    async def commit(self, batch: SlackSyncBatch) -> None:
        await self._cursor_store.save(batch.next_cursor)

    @staticmethod
    def _normalize(message: SlackMessage) -> SlackSyncEvent:
        event_type = "thread_reply" if message.thread_ts else "message"
        return SlackSyncEvent(
            event_type=event_type,
            channel_id=message.channel_id,
            message_ts=message.message_ts,
            thread_ts=message.thread_ts,
            user_id=message.user_id,
            text=message.text,
        )
