from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class MicrosoftTeamsApiError(Exception):
    status_code: int
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class MicrosoftTeamsApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_token: str,
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.transport = transport
        self.timeout = timeout

    async def get_current_user(self) -> dict[str, Any]:
        return await self._request_json("GET", "/v1.0/me")

    async def get_message(self, team_id: str, channel_id: str, message_id: str) -> dict[str, Any]:
        return await self._request_json(
            "GET",
            f"/v1.0/teams/{team_id}/channels/{channel_id}/messages/{message_id}",
        )

    async def search_messages(self, query: str, *, limit: int = 20) -> list[dict[str, Any]]:
        payload = await self._request_json(
            "POST",
            "/v1.0/search/query",
            json={
                "requests": [
                    {
                        "entityTypes": ["chatMessage"],
                        "query": {"queryString": query},
                        "from": 0,
                        "size": limit,
                    }
                ]
            },
        )
        value = payload.get("value")
        if not isinstance(value, list) or not value:
            return []
        hits_containers = value[0].get("hitsContainers") if isinstance(value[0], dict) else None
        if not isinstance(hits_containers, list) or not hits_containers:
            return []
        hits = hits_containers[0].get("hits") if isinstance(hits_containers[0], dict) else None
        if not isinstance(hits, list):
            return []
        results: list[dict[str, Any]] = []
        for item in hits:
            if not isinstance(item, dict):
                continue
            resource = item.get("resource")
            if isinstance(resource, dict):
                results.append(resource)
        return results

    async def create_message(self, team_id: str, channel_id: str, text: str) -> dict[str, Any]:
        return await self._request_json(
            "POST",
            f"/v1.0/teams/{team_id}/channels/{channel_id}/messages",
            json={"body": {"content": text}},
        )

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        async with httpx.AsyncClient(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = await client.request(
                method,
                path,
                json=json,
                params=params,
                headers={"Authorization": f"Bearer {self.api_token}"},
            )
        if response.status_code >= 400:
            payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            error = payload.get("error") if isinstance(payload, dict) else {}
            message = str(
                (error.get("message") if isinstance(error, dict) else None)
                or f"Microsoft Teams API request failed with status {response.status_code}"
            )
            code = str((error.get("code") if isinstance(error, dict) else None) or "microsoft_teams_api_error")
            raise MicrosoftTeamsApiError(status_code=response.status_code, code=code, message=message)
        payload = response.json()
        if not isinstance(payload, dict):
            raise MicrosoftTeamsApiError(
                status_code=500,
                code="microsoft_teams_api_error",
                message="Microsoft Teams API returned an invalid response",
            )
        return payload
