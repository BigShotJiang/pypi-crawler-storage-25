from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Protocol


def _utc_now() -> datetime:
    return datetime.now(UTC)


class CursorStore(Protocol):
    async def load(self) -> str | None: ...

    async def save(self, cursor: str | None) -> None: ...


class GoogleDriveClient(Protocol):
    async def search_files(self, query: str, *, limit: int = 20) -> list[dict]: ...


@dataclass(frozen=True, slots=True)
class GoogleDriveSyncEvent:
    id: str
    file_id: str
    drive_id: str
    name: str
    modified_at: str
    url: str | None
    payload: dict


@dataclass(frozen=True, slots=True)
class GoogleDriveSyncBatch:
    events: list[GoogleDriveSyncEvent]
    previous_cursor: str | None
    next_cursor: str | None


class GoogleDriveSyncService:
    def __init__(
        self,
        *,
        client: GoogleDriveClient,
        cursor_store: CursorStore,
        limit: int = 20,
        lookback_window_minutes: int = 0,
        preset: str = "personal_inbox",
        drive_ids: list[str] | None = None,
        optional_keywords: list[str] | None = None,
        optional_query: str | None = None,
    ) -> None:
        self._client = client
        self._cursor_store = cursor_store
        self._limit = limit
        self._lookback_window_minutes = max(0, int(lookback_window_minutes))
        self._preset = str(preset or "personal_inbox").strip() or "personal_inbox"
        self._drive_ids = [item.strip() for item in (drive_ids or []) if item.strip()]
        self._optional_keywords = [item.strip().lower() for item in (optional_keywords or []) if item.strip()]
        self._optional_query = str(optional_query or "").strip() or None

    async def sync_once(self) -> GoogleDriveSyncBatch:
        previous_cursor = await self._cursor_store.load()
        request_cursor = self._request_cursor(previous_cursor)
        raw_files = await self._client.search_files(self._build_query(request_cursor), limit=self._limit)
        events = [
            self._normalize_file(file_payload)
            for file_payload in raw_files
            if self._matches_watch_profile(file_payload)
        ]
        next_cursor = self._next_cursor(events, previous_cursor)
        return GoogleDriveSyncBatch(events=events, previous_cursor=previous_cursor, next_cursor=next_cursor)

    async def commit(self, batch: GoogleDriveSyncBatch) -> None:
        await self._cursor_store.save(batch.next_cursor)

    def _request_cursor(self, stored_cursor: str | None) -> str | None:
        if self._lookback_window_minutes <= 0:
            return stored_cursor
        lookback_floor = _utc_now() - timedelta(minutes=self._lookback_window_minutes)
        if not stored_cursor:
            return _format_cursor(lookback_floor)
        parsed_cursor = _parse_cursor(stored_cursor)
        if parsed_cursor is None:
            return stored_cursor
        return _format_cursor(min(parsed_cursor, lookback_floor))

    def _build_query(self, cursor: str | None) -> str:
        clauses = ["trashed = false"]
        if cursor:
            clauses.append(f'modified_time >= "{cursor}"')
        if self._drive_ids:
            quoted = ", ".join(f'"{item}"' for item in self._drive_ids)
            clauses.append(f"drive in ({quoted})")
        signal_clause = self._signal_clause()
        if signal_clause:
            clauses.append(f"({signal_clause})")
        if self._optional_query:
            clauses.append(f"({self._optional_query})")
        return " AND ".join(clauses) + " order by modified_time desc"

    def _signal_clause(self) -> str | None:
        if self._preset != "personal_inbox":
            return None
        return "shared_with_me = true OR owner_me = true"

    def _matches_watch_profile(self, file_payload: dict) -> bool:
        event = self._normalize_file(file_payload)
        if not event.file_id or not event.name or not event.modified_at:
            return False
        if bool(file_payload.get("trashed")):
            return False
        if self._drive_ids and event.drive_id not in self._drive_ids:
            return False
        if self._preset == "personal_inbox":
            shared_with_me = bool(file_payload.get("sharedWithMe"))
            owned_by_me = bool(file_payload.get("ownedByMe") or file_payload.get("isOwner"))
            if not (shared_with_me or owned_by_me):
                return False
        if not self._optional_keywords:
            return True
        haystacks = [
            event.name.lower(),
            str(file_payload.get("description") or "").strip().lower(),
            event.drive_id.lower(),
        ]
        return any(keyword in "\n".join(haystacks) for keyword in self._optional_keywords)

    @staticmethod
    def _normalize_file(file_payload: dict) -> GoogleDriveSyncEvent:
        file_id = str(file_payload.get("id") or "").strip()
        modified_at = str(file_payload.get("modifiedTime") or "").strip()
        return GoogleDriveSyncEvent(
            id=f"{file_id}:{modified_at}" if file_id and modified_at else file_id or modified_at,
            file_id=file_id,
            drive_id=str(file_payload.get("driveId") or "").strip(),
            name=str(file_payload.get("name") or "").strip(),
            modified_at=modified_at,
            url=str(file_payload.get("webViewLink") or "").strip() or None,
            payload=file_payload,
        )

    @staticmethod
    def _next_cursor(events: list[GoogleDriveSyncEvent], previous_cursor: str | None) -> str | None:
        timestamps = [_parse_cursor(event.modified_at) for event in events]
        parsed_values = [value for value in timestamps if value is not None]
        if not parsed_values:
            return previous_cursor
        return _format_cursor(max(parsed_values))


def _parse_cursor(raw_value: str) -> datetime | None:
    value = str(raw_value or "").strip()
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _format_cursor(value: datetime) -> str:
    return value.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
