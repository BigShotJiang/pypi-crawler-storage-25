from __future__ import annotations

import html
import re
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime
from typing import Any

_SLACK_USER_MENTION_RE = re.compile(r"<@[^|>]+(?:\|([^>]+))?>")


def format_slack_search_messages(messages: Sequence[Mapping[str, Any]]) -> str:
    normalized = [
        _SlackRenderItem(
            channel_id=str(message.get("channelId") or "").strip(),
            message_ts=str(message.get("messageTs") or "").strip(),
            thread_ts=str(message.get("threadTs") or "").strip() or None,
            text=str(message.get("text") or "").strip(),
        )
        for message in messages
        if isinstance(message, Mapping)
    ]
    return _render_items(normalized)


def format_slack_evidence_records(evidence_records: Sequence[Mapping[str, Any]]) -> str:
    normalized = []
    for record in evidence_records:
        if not isinstance(record, Mapping):
            continue
        metadata = record.get("metadata")
        if not isinstance(metadata, Mapping):
            metadata = {}
        normalized.append(
            _SlackRenderItem(
                channel_id=str(metadata.get("channelId") or "").strip(),
                message_ts=str(metadata.get("messageTs") or "").strip(),
                thread_ts=str(metadata.get("threadTs") or "").strip() or None,
                text=str(record.get("content") or "").strip(),
            )
        )
    return _render_items(normalized)


class _SlackRenderItem:
    __slots__ = ("channel_id", "message_ts", "thread_ts", "text")

    def __init__(self, *, channel_id: str, message_ts: str, thread_ts: str | None, text: str) -> None:
        self.channel_id = channel_id
        self.message_ts = message_ts
        self.thread_ts = thread_ts
        self.text = text


def _render_items(items: Sequence[_SlackRenderItem]) -> str:
    visible_items = [item for item in items if item.channel_id or item.message_ts or item.text]
    if not visible_items:
        return "No Slack messages matched the search query."
    lines = [f"Found {len(visible_items)} Slack message{'s' if len(visible_items) != 1 else ''}:", ""]
    for index, item in enumerate(visible_items[:5], start=1):
        lines.append(f"{index}. {_format_location(item)}")
        body = _format_text(item.text)
        for body_line in body.splitlines() or ["(no text)"]:
            lines.append(f"   {body_line}")
        if index != min(len(visible_items), 5):
            lines.append("")
    return "\n".join(lines)


def _format_location(item: _SlackRenderItem) -> str:
    parts: list[str] = []
    if item.thread_ts and item.thread_ts != item.message_ts:
        parts.append("Thread reply")
    channel_id = item.channel_id or "unknown"
    parts.append(f"Channel {channel_id}")
    parts.append(_format_timestamp(item.message_ts))
    return " · ".join(parts)


def _format_timestamp(raw_ts: str) -> str:
    try:
        dt = datetime.fromtimestamp(float(raw_ts), UTC)
    except (TypeError, ValueError, OSError):
        return raw_ts or "unknown time"
    return dt.strftime("%Y-%m-%d %H:%M UTC")


def _format_text(text: str) -> str:
    normalized = html.unescape(text or "").strip() or "(no text)"
    normalized = _SLACK_USER_MENTION_RE.sub(_replace_user_mention, normalized)
    return "\n".join(line.rstrip() for line in normalized.splitlines()).strip() or "(no text)"


def _replace_user_mention(match: re.Match[str]) -> str:
    label = str(match.group(1) or "").strip()
    return f"@{label}" if label else "@user"
