from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Protocol


def _utc_now() -> datetime:
    return datetime.now(UTC)


class CursorStore(Protocol):
    async def load(self) -> str | None: ...

    async def save(self, cursor: str | None) -> None: ...


class DiscordClient(Protocol):
    async def search_messages(self, query: str, *, limit: int = 20) -> list[dict]: ...


@dataclass(frozen=True, slots=True)
class DiscordSyncEvent:
    id: str
    message_id: str
    channel_id: str
    guild_id: str
    content: str
    timestamp: str
    payload: dict


@dataclass(frozen=True, slots=True)
class DiscordSyncBatch:
    events: list[DiscordSyncEvent]
    previous_cursor: str | None
    next_cursor: str | None


class DiscordSyncService:
    def __init__(
        self,
        *,
        client: DiscordClient,
        cursor_store: CursorStore,
        limit: int = 20,
        lookback_window_minutes: int = 0,
        preset: str = "personal_inbox",
        guild_ids: list[str] | None = None,
        optional_keywords: list[str] | None = None,
        optional_query: str | None = None,
    ) -> None:
        self._client = client
        self._cursor_store = cursor_store
        self._limit = limit
        self._lookback_window_minutes = max(0, int(lookback_window_minutes))
        self._preset = str(preset or "personal_inbox").strip() or "personal_inbox"
        self._guild_ids = [item.strip() for item in (guild_ids or []) if item.strip()]
        self._optional_keywords = [item.strip().lower() for item in (optional_keywords or []) if item.strip()]
        self._optional_query = str(optional_query or "").strip() or None

    async def sync_once(self) -> DiscordSyncBatch:
        previous_cursor = await self._cursor_store.load()
        request_cursor = self._request_cursor(previous_cursor)
        raw_messages = await self._client.search_messages(self._build_query(request_cursor), limit=self._limit)
        events = [
            self._normalize_message(message)
            for message in raw_messages
            if self._matches_watch_profile(message)
        ]
        next_cursor = self._next_cursor(events, previous_cursor)
        return DiscordSyncBatch(events=events, previous_cursor=previous_cursor, next_cursor=next_cursor)

    async def commit(self, batch: DiscordSyncBatch) -> None:
        await self._cursor_store.save(batch.next_cursor)

    def _request_cursor(self, stored_cursor: str | None) -> str | None:
        if self._lookback_window_minutes <= 0:
            return stored_cursor
        lookback_floor = _utc_now() - timedelta(minutes=self._lookback_window_minutes)
        if not stored_cursor:
            return _format_cursor(lookback_floor)
        parsed_cursor = _parse_cursor(stored_cursor)
        if parsed_cursor is None:
            return stored_cursor
        return _format_cursor(min(parsed_cursor, lookback_floor))

    def _build_query(self, cursor: str | None) -> str:
        clauses = ["type:message"]
        if cursor:
            clauses.append(f'timestamp >= "{cursor}"')
        if self._guild_ids:
            quoted = ", ".join(f'"{item}"' for item in self._guild_ids)
            clauses.append(f"guild_id in ({quoted})")
        signal_clause = self._signal_clause()
        if signal_clause:
            clauses.append(f"({signal_clause})")
        if self._optional_query:
            clauses.append(f"({self._optional_query})")
        return " AND ".join(clauses) + " order by timestamp desc"

    def _signal_clause(self) -> str | None:
        if self._preset != "personal_inbox":
            return None
        return "mentioned_me = true OR is_dm = true"

    def _matches_watch_profile(self, message: dict) -> bool:
        event = self._normalize_message(message)
        if not event.message_id or not event.content or not event.timestamp:
            return False
        if self._guild_ids and event.guild_id not in self._guild_ids:
            return False
        if self._preset == "personal_inbox":
            if not (bool(message.get("mentionedMe")) or bool(message.get("isDm"))):
                return False
        if not self._optional_keywords:
            return True
        haystacks = [
            event.content.lower(),
            event.guild_id.lower(),
            event.channel_id.lower(),
        ]
        return any(keyword in "\n".join(haystacks) for keyword in self._optional_keywords)

    @staticmethod
    def _normalize_message(message: dict) -> DiscordSyncEvent:
        message_id = str(message.get("id") or "").strip()
        timestamp = str(message.get("timestamp") or "").strip()
        return DiscordSyncEvent(
            id=f"{message_id}:{timestamp}" if message_id and timestamp else message_id or timestamp,
            message_id=message_id,
            channel_id=str(message.get("channel_id") or "").strip(),
            guild_id=str(message.get("guild_id") or "").strip(),
            content=str(message.get("content") or "").strip(),
            timestamp=timestamp,
            payload=message,
        )

    @staticmethod
    def _next_cursor(events: list[DiscordSyncEvent], previous_cursor: str | None) -> str | None:
        timestamps = [_parse_cursor(event.timestamp) for event in events]
        parsed_values = [value for value in timestamps if value is not None]
        if not parsed_values:
            return previous_cursor
        return _format_cursor(max(parsed_values))


def _parse_cursor(raw_value: str) -> datetime | None:
    value = str(raw_value or "").strip()
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _format_cursor(value: datetime) -> str:
    return value.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
