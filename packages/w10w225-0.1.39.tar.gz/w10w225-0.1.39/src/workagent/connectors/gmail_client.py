from __future__ import annotations

import base64
from dataclasses import dataclass
from email.message import EmailMessage
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class GmailApiError(Exception):
    status_code: int
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class GmailApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_token: str,
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.transport = transport
        self.timeout = timeout

    async def get_current_user(self) -> dict[str, Any]:
        return await self._request_json("GET", "/gmail/v1/users/me/profile")

    async def get_message(self, message_id: str) -> dict[str, Any]:
        return await self._request_json("GET", f"/gmail/v1/users/me/messages/{message_id}")

    async def search_messages(self, query: str, *, limit: int = 20) -> list[dict[str, Any]]:
        payload = await self._request_json(
            "GET",
            "/gmail/v1/users/me/messages",
            params={"q": query, "maxResults": limit},
        )
        messages = payload.get("messages")
        if not isinstance(messages, list):
            return []
        results: list[dict[str, Any]] = []
        for row in messages:
            if not isinstance(row, dict):
                continue
            message_id = str(row.get("id") or "").strip()
            if not message_id:
                continue
            message = await self.get_message(message_id)
            results.append(message)
        return results

    async def send_message(self, *, to: str, subject: str, body: str) -> dict[str, Any]:
        message = EmailMessage()
        message["To"] = to
        message["Subject"] = subject
        message.set_content(body)
        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8").rstrip("=")
        return await self._request_json(
            "POST",
            "/gmail/v1/users/me/messages/send",
            json={"raw": raw_message},
        )

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        async with httpx.AsyncClient(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = await client.request(
                method,
                path,
                json=json,
                params=params,
                headers={"Authorization": f"Bearer {self.api_token}"},
            )
        if response.status_code >= 400:
            payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            error = payload.get("error") if isinstance(payload, dict) else {}
            message = str(
                (error.get("message") if isinstance(error, dict) else None)
                or f"Gmail API request failed with status {response.status_code}"
            )
            code = str((error.get("status") if isinstance(error, dict) else None) or "gmail_api_error")
            raise GmailApiError(status_code=response.status_code, code=code, message=message)
        payload = response.json()
        if not isinstance(payload, dict):
            raise GmailApiError(status_code=500, code="gmail_api_error", message="Gmail API returned an invalid response")
        return payload
