from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from urllib.parse import quote

import httpx


@dataclass(frozen=True, slots=True)
class GitLabApiError(Exception):
    status_code: int
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class GitLabApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        private_token: str,
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.private_token = private_token
        self.transport = transport
        self.timeout = timeout

    async def list_activity(self, *, cursor: str | None = None, limit: int = 20) -> tuple[list[dict[str, Any]], str | None]:
        assigned = await self._request_json(
            "GET",
            "/api/v4/merge_requests",
            params={
                "scope": "assigned_to_me",
                "state": "opened",
                "per_page": limit,
                **({"updated_after": cursor} if cursor else {}),
            },
        )
        review_requested = await self._request_json(
            "GET",
            "/api/v4/merge_requests",
            params={
                "scope": "reviews_for_me",
                "state": "opened",
                "per_page": limit,
                **({"updated_after": cursor} if cursor else {}),
            },
        )
        todos = await self._request_json(
            "GET",
            "/api/v4/todos",
            params={"state": "pending", "per_page": limit},
        )

        events = [
            *[
                {
                    "id": f"assigned:{item['project_id']}:{item['iid']}",
                    "kind": "assigned",
                    "projectPath": str(item.get("references", {}).get("full") or item.get("project_id") or ""),
                    "mergeRequestIid": item.get("iid"),
                    "occurredAt": str(item.get("updated_at") or ""),
                    "payload": item,
                }
                for item in assigned
            ],
            *[
                {
                    "id": f"review_requested:{item['project_id']}:{item['iid']}",
                    "kind": "review_requested",
                    "projectPath": str(item.get("references", {}).get("full") or item.get("project_id") or ""),
                    "mergeRequestIid": item.get("iid"),
                    "occurredAt": str(item.get("updated_at") or ""),
                    "payload": item,
                }
                for item in review_requested
            ],
            *[
                {
                    "id": f"note:{item['id']}",
                    "kind": "note",
                    "projectPath": str(item.get("target", {}).get("references", {}).get("full") or item.get("project_id") or ""),
                    "mergeRequestIid": item.get("target", {}).get("iid"),
                    "occurredAt": str(item.get("created_at") or ""),
                    "payload": item,
                }
                for item in todos
                if item.get("target_type") == "MergeRequest"
            ],
        ]
        next_cursor = max((str(event["occurredAt"]) for event in events if event["occurredAt"]), default=cursor)
        return events, next_cursor

    async def get_current_user(self) -> dict[str, Any]:
        payload = await self._request_json("GET", "/api/v4/user")
        return payload if isinstance(payload, dict) else {}

    async def get_merge_request(self, project_path: str, merge_request_iid: int) -> dict[str, Any]:
        return await self._request_json("GET", f"/api/v4/projects/{self._project_ref(project_path)}/merge_requests/{merge_request_iid}")

    async def get_discussions(self, project_path: str, merge_request_iid: int) -> list[dict[str, Any]]:
        return await self._request_json(
            "GET",
            f"/api/v4/projects/{self._project_ref(project_path)}/merge_requests/{merge_request_iid}/discussions",
        )

    async def get_pipeline(self, project_path: str, pipeline_id: int) -> dict[str, Any]:
        return await self._request_json("GET", f"/api/v4/projects/{self._project_ref(project_path)}/pipelines/{pipeline_id}")

    async def get_commit_summary(self, project_path: str, sha: str) -> dict[str, Any]:
        return await self._request_json(
            "GET",
            f"/api/v4/projects/{self._project_ref(project_path)}/repository/commits/{sha}",
        )

    async def create_merge_request_note(self, project_path: str, merge_request_iid: int, body: str) -> dict[str, Any]:
        payload = await self._request_json(
            "POST",
            f"/api/v4/projects/{self._project_ref(project_path)}/merge_requests/{merge_request_iid}/notes",
            json={"body": body},
        )
        return payload if isinstance(payload, dict) else {}

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        async with httpx.AsyncClient(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = await client.request(
                method,
                path,
                json=json,
                params=params,
                headers={"PRIVATE-TOKEN": self.private_token},
            )
        if response.status_code >= 400:
            payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            message = payload.get("message") if isinstance(payload, dict) else None
            raise GitLabApiError(
                status_code=response.status_code,
                code="gitlab_api_error",
                message=str(message or f"GitLab API request failed with status {response.status_code}"),
            )
        return response.json()

    @staticmethod
    def _project_ref(project_path: str) -> str:
        return quote(project_path, safe="")
