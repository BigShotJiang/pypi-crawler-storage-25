from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Protocol

SUPPORTED_GITLAB_EVENT_KINDS = {"assigned", "review_requested", "note"}


def _utc_now() -> datetime:
    return datetime.now(UTC)


class CursorStore(Protocol):
    async def load(self) -> str | None: ...

    async def save(self, cursor: str | None) -> None: ...


class GitLabClient(Protocol):
    async def list_activity(self, *, cursor: str | None = None, limit: int = 20) -> tuple[list[dict], str | None]: ...


@dataclass(frozen=True, slots=True)
class GitLabSyncEvent:
    id: str
    kind: str
    project_path: str
    merge_request_iid: int | None
    occurred_at: str
    payload: dict


@dataclass(frozen=True, slots=True)
class GitLabSyncBatch:
    events: list[GitLabSyncEvent]
    previous_cursor: str | None
    next_cursor: str | None


class GitLabSyncService:
    def __init__(
        self,
        *,
        client: GitLabClient,
        cursor_store: CursorStore,
        limit: int = 20,
        lookback_window_minutes: int = 0,
        project_scope_prefixes: list[str] | None = None,
        optional_keywords: list[str] | None = None,
    ) -> None:
        self._client = client
        self._cursor_store = cursor_store
        self._limit = limit
        self._lookback_window_minutes = max(0, int(lookback_window_minutes))
        self._project_scope_prefixes = [item.strip() for item in (project_scope_prefixes or []) if item.strip()]
        self._optional_keywords = [item.strip().lower() for item in (optional_keywords or []) if item.strip()]

    async def sync_once(self) -> GitLabSyncBatch:
        previous_cursor = await self._cursor_store.load()
        request_cursor = self._request_cursor(previous_cursor)
        raw_events, next_cursor = await self._client.list_activity(cursor=request_cursor, limit=self._limit)
        normalized = [
            self._normalize_event(event)
            for event in raw_events
            if self._is_supported(event) and self._matches_watch_profile(event)
        ]
        effective_cursor = next_cursor if next_cursor is not None else previous_cursor
        return GitLabSyncBatch(
            events=normalized,
            previous_cursor=previous_cursor,
            next_cursor=effective_cursor,
        )

    async def commit(self, batch: GitLabSyncBatch) -> None:
        await self._cursor_store.save(batch.next_cursor)

    @staticmethod
    def _is_supported(event: dict) -> bool:
        return str(event.get("kind") or "").strip() in SUPPORTED_GITLAB_EVENT_KINDS

    def _request_cursor(self, stored_cursor: str | None) -> str | None:
        if self._lookback_window_minutes <= 0:
            return stored_cursor
        lookback_floor = _utc_now() - timedelta(minutes=self._lookback_window_minutes)
        if not stored_cursor:
            return _format_cursor(lookback_floor)
        parsed_cursor = _parse_cursor(stored_cursor)
        if parsed_cursor is None:
            return stored_cursor
        return _format_cursor(min(parsed_cursor, lookback_floor))

    def _matches_watch_profile(self, event: dict) -> bool:
        project_path = str(event.get("projectPath") or "").strip()
        if self._project_scope_prefixes and not any(
            project_path.startswith(prefix) for prefix in self._project_scope_prefixes
        ):
            return False
        if not self._optional_keywords:
            return True
        haystacks = [project_path.lower(), str(event.get("kind") or "").strip().lower()]
        payload = event.get("payload")
        if isinstance(payload, dict):
            haystacks.extend(
                str(value).strip().lower()
                for key, value in payload.items()
                if key in {"note", "title", "description", "summary"} and value is not None
            )
        combined = "\n".join(haystacks)
        return any(keyword in combined for keyword in self._optional_keywords)

    @staticmethod
    def _normalize_event(event: dict) -> GitLabSyncEvent:
        return GitLabSyncEvent(
            id=str(event.get("id") or "").strip(),
            kind=str(event.get("kind") or "").strip(),
            project_path=str(event.get("projectPath") or "").strip(),
            merge_request_iid=int(event["mergeRequestIid"]) if event.get("mergeRequestIid") is not None else None,
            occurred_at=str(event.get("occurredAt") or "").strip(),
            payload=event.get("payload") if isinstance(event.get("payload"), dict) else {},
        )


def _parse_cursor(raw_value: str) -> datetime | None:
    value = str(raw_value or "").strip()
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _format_cursor(value: datetime) -> str:
    return value.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
