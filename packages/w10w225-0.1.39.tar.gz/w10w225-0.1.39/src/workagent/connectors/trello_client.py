from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class TrelloApiError(Exception):
    status_code: int
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class TrelloApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_token: str,
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.transport = transport
        self.timeout = timeout

    async def get_current_member(self) -> dict[str, Any]:
        payload = await self._request_json("GET", "/1/members/me")
        return payload if isinstance(payload, dict) else {}

    async def get_card(self, card_id: str) -> dict[str, Any]:
        payload = await self._request_json("GET", f"/1/cards/{card_id}")
        return payload if isinstance(payload, dict) else {}

    async def create_card_comment(self, card_id: str, text: str) -> dict[str, Any]:
        payload = await self._request_json(
            "POST",
            f"/1/cards/{card_id}/actions/comments",
            json={"text": text},
        )
        return payload if isinstance(payload, dict) else {}

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        async with httpx.AsyncClient(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = await client.request(
                method,
                path,
                json=json,
                params=params,
                headers={"Authorization": f"Bearer {self.api_token}"},
            )
        if response.status_code >= 400:
            payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            message = str(payload.get("message") or payload.get("error") or f"Trello API request failed with status {response.status_code}")
            code = str(payload.get("error") or "trello_api_error")
            raise TrelloApiError(status_code=response.status_code, code=code, message=message)
        payload = response.json()
        if not isinstance(payload, dict):
            raise TrelloApiError(status_code=500, code="trello_api_error", message="Trello API returned an invalid response")
        return payload
