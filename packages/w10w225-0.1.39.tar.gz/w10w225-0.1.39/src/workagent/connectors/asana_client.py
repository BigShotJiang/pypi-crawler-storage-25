from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class AsanaApiError(Exception):
    status_code: int
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class AsanaApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_token: str,
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.transport = transport
        self.timeout = timeout

    async def get_current_user(self) -> dict[str, Any]:
        payload = await self._request_json("GET", "/api/1.0/users/me")
        user = payload.get("data")
        return user if isinstance(user, dict) else {}

    async def get_task(self, task_id: str) -> dict[str, Any]:
        payload = await self._request_json("GET", f"/api/1.0/tasks/{task_id}")
        task = payload.get("data")
        return task if isinstance(task, dict) else {}

    async def search_tasks(self, query: str, *, limit: int = 20) -> list[dict[str, Any]]:
        payload = await self._request_json(
            "GET",
            "/api/1.0/tasks/search",
            params={"query": query, "limit": limit},
        )
        data = payload.get("data")
        return [item for item in data if isinstance(item, dict)] if isinstance(data, list) else []

    async def create_task_comment(self, task_id: str, text: str) -> dict[str, Any]:
        payload = await self._request_json(
            "POST",
            f"/api/1.0/tasks/{task_id}/stories",
            json={"data": {"text": text}},
        )
        story = payload.get("data")
        return story if isinstance(story, dict) else {}

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        async with httpx.AsyncClient(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = await client.request(
                method,
                path,
                json=json,
                params=params,
                headers={"Authorization": f"Bearer {self.api_token}"},
            )
        if response.status_code >= 400:
            payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            errors = payload.get("errors") if isinstance(payload, dict) else None
            first_error = errors[0] if isinstance(errors, list) and errors and isinstance(errors[0], dict) else {}
            message = str(first_error.get("message") or f"Asana API request failed with status {response.status_code}")
            code = str(first_error.get("phrase") or first_error.get("error") or "asana_api_error")
            raise AsanaApiError(status_code=response.status_code, code=code, message=message)
        payload = response.json()
        if not isinstance(payload, dict):
            raise AsanaApiError(status_code=500, code="asana_api_error", message="Asana API returned an invalid response")
        return payload
