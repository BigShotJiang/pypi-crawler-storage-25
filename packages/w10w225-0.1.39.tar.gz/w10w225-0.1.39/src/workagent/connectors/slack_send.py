from __future__ import annotations

from dataclasses import dataclass

import httpx


@dataclass(frozen=True, slots=True)
class SlackSendResult:
    channel_id: str
    message_ts: str
    thread_ts: str | None


@dataclass(frozen=True, slots=True)
class SlackSendError(Exception):
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class SlackOutboundSender:
    def __init__(
        self,
        *,
        base_url: str = "https://slack.com",
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.transport = transport
        self.timeout = timeout

    def send_message(self, *, token: str, channel_id: str, text: str) -> SlackSendResult:
        return self._post_message(token=token, channel_id=channel_id, text=text, thread_ts=None)

    def reply_in_thread(self, *, token: str, channel_id: str, thread_ts: str, text: str) -> SlackSendResult:
        return self._post_message(token=token, channel_id=channel_id, text=text, thread_ts=thread_ts)

    def _post_message(
        self,
        *,
        token: str,
        channel_id: str,
        text: str,
        thread_ts: str | None,
    ) -> SlackSendResult:
        payload: dict[str, str] = {"channel": channel_id, "text": text}
        if thread_ts:
            payload["thread_ts"] = thread_ts

        with httpx.Client(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = client.post(
                "/api/chat.postMessage",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json; charset=utf-8",
                },
                json=payload,
            )

        response.raise_for_status()
        body = response.json()
        if body.get("ok") is not True:
            raise self._normalize_error(str(body.get("error") or "unknown_error").strip() or "unknown_error")

        return SlackSendResult(
            channel_id=str(body.get("channel") or channel_id).strip(),
            message_ts=str(body.get("ts") or "").strip(),
            thread_ts=str(body.get("thread_ts") or "").strip() or thread_ts,
        )

    @staticmethod
    def _normalize_error(code: str) -> SlackSendError:
        mapping = {
            "invalid_auth": "Slack token is invalid or expired.",
            "missing_scope": "Slack token lacks the required permission for this send.",
            "not_in_channel": "Slack token does not have access to the target channel.",
            "channel_not_found": "Slack channel was not found.",
            "thread_not_found": "Slack thread was not found.",
            "message_not_found": "Slack message was not found.",
        }
        return SlackSendError(code=code, message=mapping.get(code, "Slack send failed."))
