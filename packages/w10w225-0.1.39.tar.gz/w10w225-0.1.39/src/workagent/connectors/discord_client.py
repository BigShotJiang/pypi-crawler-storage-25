from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class DiscordApiError(Exception):
    status_code: int
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class DiscordApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_token: str,
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.transport = transport
        self.timeout = timeout

    async def get_current_user(self) -> dict[str, Any]:
        return await self._request_json("GET", "/api/v10/users/@me")

    async def get_message(self, channel_id: str, message_id: str) -> dict[str, Any]:
        return await self._request_json("GET", f"/api/v10/channels/{channel_id}/messages/{message_id}")

    async def search_messages(self, query: str, *, limit: int = 20) -> list[dict[str, Any]]:
        payload = await self._request_json(
            "GET",
            "/api/v10/messages/search",
            params={"query": query, "limit": limit},
        )
        messages = payload.get("messages")
        if isinstance(messages, list):
            flattened: list[dict[str, Any]] = []
            for item in messages:
                if isinstance(item, dict):
                    flattened.append(item)
                elif isinstance(item, list):
                    flattened.extend(candidate for candidate in item if isinstance(candidate, dict))
            return flattened
        return []

    async def create_message(self, channel_id: str, text: str) -> dict[str, Any]:
        return await self._request_json(
            "POST",
            f"/api/v10/channels/{channel_id}/messages",
            json={"content": text},
        )

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        async with httpx.AsyncClient(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = await client.request(
                method,
                path,
                json=json,
                params=params,
                headers={"Authorization": f"Bot {self.api_token}"},
            )
        if response.status_code >= 400:
            payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            message = str(payload.get("message") or f"Discord API request failed with status {response.status_code}")
            code = str(payload.get("code") or "discord_api_error")
            raise DiscordApiError(status_code=response.status_code, code=code, message=message)
        payload = response.json()
        if not isinstance(payload, dict):
            raise DiscordApiError(status_code=500, code="discord_api_error", message="Discord API returned an invalid response")
        return payload
