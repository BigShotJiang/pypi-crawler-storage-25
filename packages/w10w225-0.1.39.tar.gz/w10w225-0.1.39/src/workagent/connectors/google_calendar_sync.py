from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Protocol


def _utc_now() -> datetime:
    return datetime.now(UTC)


class CursorStore(Protocol):
    async def load(self) -> str | None: ...

    async def save(self, cursor: str | None) -> None: ...


class GoogleCalendarClient(Protocol):
    async def list_events(self, query: str, *, limit: int = 20) -> list[dict]: ...


@dataclass(frozen=True, slots=True)
class GoogleCalendarSyncEvent:
    id: str
    event_id: str
    calendar_id: str
    summary: str
    updated_at: str
    url: str | None
    payload: dict


@dataclass(frozen=True, slots=True)
class GoogleCalendarSyncBatch:
    events: list[GoogleCalendarSyncEvent]
    previous_cursor: str | None
    next_cursor: str | None


class GoogleCalendarSyncService:
    def __init__(
        self,
        *,
        client: GoogleCalendarClient,
        cursor_store: CursorStore,
        limit: int = 20,
        lookback_window_minutes: int = 0,
        preset: str = "personal_inbox",
        calendar_ids: list[str] | None = None,
        optional_keywords: list[str] | None = None,
        optional_query: str | None = None,
    ) -> None:
        self._client = client
        self._cursor_store = cursor_store
        self._limit = limit
        self._lookback_window_minutes = max(0, int(lookback_window_minutes))
        self._preset = str(preset or "personal_inbox").strip() or "personal_inbox"
        self._calendar_ids = [item.strip() for item in (calendar_ids or []) if item.strip()]
        self._optional_keywords = [item.strip().lower() for item in (optional_keywords or []) if item.strip()]
        self._optional_query = str(optional_query or "").strip() or None

    async def sync_once(self) -> GoogleCalendarSyncBatch:
        previous_cursor = await self._cursor_store.load()
        request_cursor = self._request_cursor(previous_cursor)
        raw_events = await self._client.list_events(self._build_query(request_cursor), limit=self._limit)
        events = [
            self._normalize_event(event)
            for event in raw_events
            if self._matches_watch_profile(event)
        ]
        next_cursor = self._next_cursor(events, previous_cursor)
        return GoogleCalendarSyncBatch(events=events, previous_cursor=previous_cursor, next_cursor=next_cursor)

    async def commit(self, batch: GoogleCalendarSyncBatch) -> None:
        await self._cursor_store.save(batch.next_cursor)

    def _request_cursor(self, stored_cursor: str | None) -> str | None:
        if self._lookback_window_minutes <= 0:
            return stored_cursor
        lookback_floor = _utc_now() - timedelta(minutes=self._lookback_window_minutes)
        if not stored_cursor:
            return _format_cursor(lookback_floor)
        parsed_cursor = _parse_cursor(stored_cursor)
        if parsed_cursor is None:
            return stored_cursor
        return _format_cursor(min(parsed_cursor, lookback_floor))

    def _build_query(self, cursor: str | None) -> str:
        clauses: list[str] = []
        if cursor:
            clauses.append(f'updated_min = "{cursor}"')
        if self._calendar_ids:
            quoted = ", ".join(f'"{item}"' for item in self._calendar_ids)
            clauses.append(f"calendar in ({quoted})")
        signal_clause = self._signal_clause()
        if signal_clause:
            clauses.append(signal_clause)
        if self._optional_query:
            clauses.append(self._optional_query)
        return " AND ".join(clauses)

    def _signal_clause(self) -> str | None:
        if self._preset != "personal_inbox":
            return None
        return "attendee_me OR organizer_me"

    def _matches_watch_profile(self, event: dict) -> bool:
        normalized = self._normalize_event(event)
        if not normalized.event_id or not normalized.summary or not normalized.updated_at:
            return False
        if self._calendar_ids and normalized.calendar_id not in self._calendar_ids:
            return False
        status = str(event.get("status") or "").strip().lower()
        if status == "cancelled":
            return False
        if self._preset == "personal_inbox":
            attendee_me = bool(event.get("attendeeMe"))
            organizer_me = bool(event.get("organizerMe"))
            if not (attendee_me or organizer_me):
                return False
        if not self._optional_keywords:
            return True
        haystacks = [
            normalized.summary.lower(),
            str(event.get("description") or "").strip().lower(),
        ]
        return any(keyword in "\n".join(haystacks) for keyword in self._optional_keywords)

    @staticmethod
    def _normalize_event(event: dict) -> GoogleCalendarSyncEvent:
        event_id = str(event.get("id") or "").strip()
        updated_at = str(event.get("updated") or "").strip()
        return GoogleCalendarSyncEvent(
            id=f"{event_id}:{updated_at}" if event_id and updated_at else event_id or updated_at,
            event_id=event_id,
            calendar_id=str(event.get("calendarId") or "primary").strip(),
            summary=str(event.get("summary") or "").strip(),
            updated_at=updated_at,
            url=str(event.get("htmlLink") or "").strip() or None,
            payload=event,
        )

    @staticmethod
    def _next_cursor(events: list[GoogleCalendarSyncEvent], previous_cursor: str | None) -> str | None:
        timestamps = [_parse_cursor(event.updated_at) for event in events]
        parsed_values = [value for value in timestamps if value is not None]
        if not parsed_values:
            return previous_cursor
        return _format_cursor(max(parsed_values))


def _parse_cursor(raw_value: str) -> datetime | None:
    value = str(raw_value or "").strip()
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _format_cursor(value: datetime) -> str:
    return value.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
