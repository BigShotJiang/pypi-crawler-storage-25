from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class GoogleDriveApiError(Exception):
    status_code: int
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class GoogleDriveApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_token: str,
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.transport = transport
        self.timeout = timeout

    async def get_current_user(self) -> dict[str, Any]:
        payload = await self._request_json("GET", "/drive/v3/about", params={"fields": "user"})
        user = payload.get("user")
        return user if isinstance(user, dict) else {}

    async def get_file(self, file_id: str) -> dict[str, Any]:
        return await self._request_json("GET", f"/drive/v3/files/{file_id}", params={"fields": "id,name,webViewLink"})

    async def search_files(self, query: str, *, limit: int = 20) -> list[dict[str, Any]]:
        payload = await self._request_json(
            "GET",
            "/drive/v3/files",
            params={"q": query, "pageSize": limit, "fields": "files(id,name,webViewLink,modifiedTime,driveId,description,trashed)"},
        )
        files = payload.get("files")
        return [item for item in files if isinstance(item, dict)] if isinstance(files, list) else []

    async def create_file_comment(self, file_id: str, content: str) -> dict[str, Any]:
        return await self._request_json(
            "POST",
            f"/drive/v3/files/{file_id}/comments",
            json={"content": content},
        )

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        async with httpx.AsyncClient(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = await client.request(
                method,
                path,
                json=json,
                params=params,
                headers={"Authorization": f"Bearer {self.api_token}"},
            )
        if response.status_code >= 400:
            payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            error = payload.get("error") if isinstance(payload, dict) else {}
            message = str(
                (error.get("message") if isinstance(error, dict) else None)
                or f"Google Drive API request failed with status {response.status_code}"
            )
            code = str((error.get("status") if isinstance(error, dict) else None) or "google_drive_api_error")
            raise GoogleDriveApiError(status_code=response.status_code, code=code, message=message)
        payload = response.json()
        if not isinstance(payload, dict):
            raise GoogleDriveApiError(
                status_code=500,
                code="google_drive_api_error",
                message="Google Drive API returned an invalid response",
            )
        return payload
