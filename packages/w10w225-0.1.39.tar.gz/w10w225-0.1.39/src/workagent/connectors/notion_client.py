from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class NotionApiError(Exception):
    status_code: int
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class NotionApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_token: str,
        notion_version: str = "2022-06-28",
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.notion_version = notion_version
        self.transport = transport
        self.timeout = timeout

    async def get_current_user(self) -> dict[str, Any]:
        return await self._request_json("GET", "/v1/users/me")

    async def get_page(self, page_id: str) -> dict[str, Any]:
        return await self._request_json("GET", f"/v1/pages/{page_id}")

    async def search_pages(self, query: str, *, limit: int = 20) -> list[dict[str, Any]]:
        payload = await self._request_json(
            "POST",
            "/v1/search",
            json={
                "query": query,
                "page_size": limit,
                "filter": {"property": "object", "value": "page"},
            },
        )
        results = payload.get("results")
        return [item for item in results if isinstance(item, dict)] if isinstance(results, list) else []

    async def create_page_comment(self, page_id: str, text: str) -> dict[str, Any]:
        return await self._request_json(
            "POST",
            "/v1/comments",
            json={
                "parent": {"page_id": page_id},
                "rich_text": [{"type": "text", "text": {"content": text}}],
            },
        )

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        async with httpx.AsyncClient(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = await client.request(
                method,
                path,
                json=json,
                params=params,
                headers={
                    "Authorization": f"Bearer {self.api_token}",
                    "Notion-Version": self.notion_version,
                },
            )
        if response.status_code >= 400:
            payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            message = str(payload.get("message") or f"Notion API request failed with status {response.status_code}")
            code = str(payload.get("code") or "notion_api_error")
            raise NotionApiError(status_code=response.status_code, code=code, message=message)
        payload = response.json()
        if not isinstance(payload, dict):
            raise NotionApiError(status_code=500, code="notion_api_error", message="Notion API returned an invalid response")
        return payload
