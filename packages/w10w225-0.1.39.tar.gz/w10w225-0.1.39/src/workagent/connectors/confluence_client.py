from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class ConfluenceApiError(Exception):
    status_code: int
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class ConfluenceApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_token: str,
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.transport = transport
        self.timeout = timeout

    async def search_pages(self, query: str, *, limit: int = 10) -> list[dict[str, Any]]:
        results = await self.search_content(f'siteSearch ~ "{query}"', limit=limit)
        return [
            {
                "id": str(item.get("id") or "").strip(),
                "title": str(item.get("title") or "").strip(),
                "webui": str(item.get("webui") or "").strip(),
            }
            for item in results
        ]

    async def search_content(self, cql: str, *, limit: int = 20) -> list[dict[str, Any]]:
        payload = await self._request_json(
            "GET",
            "/wiki/rest/api/search",
            params={"cql": cql, "limit": limit},
        )
        results = payload.get("results")
        normalized: list[dict[str, Any]] = []
        for row in results if isinstance(results, list) else []:
            if not isinstance(row, dict):
                continue
            content = row.get("content") if isinstance(row.get("content"), dict) else {}
            space = content.get("space") if isinstance(content.get("space"), dict) else {}
            links = row.get("_links") if isinstance(row.get("_links"), dict) else {}
            version = content.get("version") if isinstance(content.get("version"), dict) else {}
            last_modifier = row.get("lastModifier") if isinstance(row.get("lastModifier"), dict) else {}
            normalized.append(
                {
                    "id": str(content.get("id") or "").strip(),
                    "title": str(content.get("title") or "").strip(),
                    "spaceKey": str(space.get("key") or "").strip(),
                    "webui": str(links.get("webui") or "").strip(),
                    "lastModified": str(row.get("lastModified") or "").strip(),
                    "excerpt": str(row.get("excerpt") or "").strip(),
                    "version": str(version.get("number") or "").strip(),
                    "authorAccountId": str(last_modifier.get("accountId") or "").strip(),
                    "contentType": str(content.get("type") or "page").strip(),
                }
            )
        return normalized

    async def get_page_summary(self, page_id: str) -> dict[str, Any]:
        payload = await self._request_json(
            "GET",
            f"/wiki/rest/api/content/{page_id}",
            params={"expand": "body.storage,version,space"},
        )
        space = payload.get("space") if isinstance(payload.get("space"), dict) else {}
        version = payload.get("version") if isinstance(payload.get("version"), dict) else {}
        body = payload.get("body") if isinstance(payload.get("body"), dict) else {}
        storage = body.get("storage") if isinstance(body.get("storage"), dict) else {}
        return {
            "id": str(payload.get("id") or "").strip(),
            "title": str(payload.get("title") or "").strip(),
            "spaceKey": str(space.get("key") or "").strip(),
            "version": int(version.get("number") or 0),
            "storage": str(storage.get("value") or "").strip(),
        }

    async def get_current_user(self) -> dict[str, Any]:
        payload = await self._request_json("GET", "/wiki/rest/api/user/current")
        return payload if isinstance(payload, dict) else {}

    async def create_page_comment(self, page_id: str, body: str) -> dict[str, Any]:
        payload = await self._request_json(
            "POST",
            f"/wiki/rest/api/content/{page_id}/child/comment",
            json={
                "type": "comment",
                "container": {"id": page_id, "type": "page"},
                "body": {"storage": {"value": body, "representation": "storage"}},
            },
        )
        return payload if isinstance(payload, dict) else {}

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        async with httpx.AsyncClient(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = await client.request(
                method,
                path,
                json=json,
                params=params,
                headers={"Authorization": f"Bearer {self.api_token}"},
            )
        if response.status_code >= 400:
            payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            message = payload.get("message") if isinstance(payload, dict) else None
            raise ConfluenceApiError(
                status_code=response.status_code,
                code="confluence_api_error",
                message=str(message or f"Confluence API request failed with status {response.status_code}"),
            )
        payload = response.json()
        if not isinstance(payload, dict):
            raise ConfluenceApiError(status_code=500, code="confluence_api_error", message="Confluence API returned an invalid response")
        return payload
