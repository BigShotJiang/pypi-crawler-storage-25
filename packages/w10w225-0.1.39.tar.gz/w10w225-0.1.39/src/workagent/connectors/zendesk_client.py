from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class ZendeskApiError(Exception):
    status_code: int
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class ZendeskApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_token: str,
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.transport = transport
        self.timeout = timeout

    async def get_current_user(self) -> dict[str, Any]:
        payload = await self._request_json("GET", "/api/v2/users/me.json")
        user = payload.get("user")
        return user if isinstance(user, dict) else {}

    async def get_ticket(self, ticket_id: str) -> dict[str, Any]:
        payload = await self._request_json("GET", f"/api/v2/tickets/{ticket_id}.json")
        ticket = payload.get("ticket")
        return ticket if isinstance(ticket, dict) else {}

    async def search_tickets(self, query: str, *, limit: int = 20) -> list[dict[str, Any]]:
        payload = await self._request_json(
            "GET",
            "/api/v2/search.json",
            params={"query": query, "per_page": limit},
        )
        results = payload.get("results")
        return [item for item in results if isinstance(item, dict)] if isinstance(results, list) else []

    async def create_ticket_comment(self, ticket_id: str, body: str, *, public: bool = True) -> dict[str, Any]:
        payload = await self._request_json(
            "PUT",
            f"/api/v2/tickets/{ticket_id}.json",
            json={
                "ticket": {
                    "comment": {
                        "body": body,
                        "public": public,
                    }
                }
            },
        )
        ticket = payload.get("ticket")
        return ticket if isinstance(ticket, dict) else {}

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        async with httpx.AsyncClient(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = await client.request(
                method,
                path,
                json=json,
                params=params,
                headers={"Authorization": f"Bearer {self.api_token}"},
            )
        if response.status_code >= 400:
            payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            error = payload.get("error") if isinstance(payload, dict) else None
            description = payload.get("description") if isinstance(payload, dict) else None
            message = ", ".join(str(item) for item in [error, description] if item) or (
                f"Zendesk API request failed with status {response.status_code}"
            )
            raise ZendeskApiError(
                status_code=response.status_code,
                code=str(error or "zendesk_api_error"),
                message=message,
            )
        payload = response.json()
        if not isinstance(payload, dict):
            raise ZendeskApiError(status_code=500, code="zendesk_api_error", message="Zendesk API returned an invalid response")
        return payload
