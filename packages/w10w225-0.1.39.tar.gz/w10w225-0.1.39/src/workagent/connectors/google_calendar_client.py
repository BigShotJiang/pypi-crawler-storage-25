from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class GoogleCalendarApiError(Exception):
    status_code: int
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class GoogleCalendarApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_token: str,
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.transport = transport
        self.timeout = timeout

    async def get_current_user(self) -> dict[str, Any]:
        return await self._request_json("GET", "/calendar/v3/calendars/primary")

    async def get_event(self, calendar_id: str, event_id: str) -> dict[str, Any]:
        return await self._request_json("GET", f"/calendar/v3/calendars/{calendar_id}/events/{event_id}")

    async def list_events(self, query: str, *, limit: int = 20) -> list[dict[str, Any]]:
        payload = await self._request_json(
            "GET",
            "/calendar/v3/calendars/primary/events",
            params={"q": query, "maxResults": limit},
        )
        items = payload.get("items")
        return [item for item in items if isinstance(item, dict)] if isinstance(items, list) else []

    async def create_event(self, calendar_id: str, *, summary: str, start: str, end: str) -> dict[str, Any]:
        return await self._request_json(
            "POST",
            f"/calendar/v3/calendars/{calendar_id}/events",
            json={
                "summary": summary,
                "start": {"dateTime": start},
                "end": {"dateTime": end},
            },
        )

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        async with httpx.AsyncClient(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = await client.request(
                method,
                path,
                json=json,
                params=params,
                headers={"Authorization": f"Bearer {self.api_token}"},
            )
        if response.status_code >= 400:
            payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            error = payload.get("error") if isinstance(payload, dict) else {}
            message = str(
                (error.get("message") if isinstance(error, dict) else None)
                or f"Google Calendar API request failed with status {response.status_code}"
            )
            code = str((error.get("status") if isinstance(error, dict) else None) or "google_calendar_api_error")
            raise GoogleCalendarApiError(status_code=response.status_code, code=code, message=message)
        payload = response.json()
        if not isinstance(payload, dict):
            raise GoogleCalendarApiError(
                status_code=500,
                code="google_calendar_api_error",
                message="Google Calendar API returned an invalid response",
            )
        return payload
