from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Protocol


def _utc_now() -> datetime:
    return datetime.now(UTC)


class CursorStore(Protocol):
    async def load(self) -> str | None: ...

    async def save(self, cursor: str | None) -> None: ...


class GmailClient(Protocol):
    async def search_messages(self, query: str, *, limit: int = 20) -> list[dict]: ...


@dataclass(frozen=True, slots=True)
class GmailSyncEvent:
    id: str
    message_id: str
    thread_id: str
    snippet: str
    received_at: str
    web_url: str | None
    payload: dict


@dataclass(frozen=True, slots=True)
class GmailSyncBatch:
    events: list[GmailSyncEvent]
    previous_cursor: str | None
    next_cursor: str | None


class GmailSyncService:
    def __init__(
        self,
        *,
        client: GmailClient,
        cursor_store: CursorStore,
        limit: int = 20,
        lookback_window_minutes: int = 0,
        preset: str = "personal_inbox",
        label_ids: list[str] | None = None,
        optional_keywords: list[str] | None = None,
        optional_query: str | None = None,
    ) -> None:
        self._client = client
        self._cursor_store = cursor_store
        self._limit = limit
        self._lookback_window_minutes = max(0, int(lookback_window_minutes))
        self._preset = str(preset or "personal_inbox").strip() or "personal_inbox"
        self._label_ids = [item.strip() for item in (label_ids or []) if item.strip()]
        self._optional_keywords = [item.strip().lower() for item in (optional_keywords or []) if item.strip()]
        self._optional_query = str(optional_query or "").strip() or None

    async def sync_once(self) -> GmailSyncBatch:
        previous_cursor = await self._cursor_store.load()
        request_cursor = self._request_cursor(previous_cursor)
        raw_messages = await self._client.search_messages(self._build_query(request_cursor), limit=self._limit)
        events = [
            self._normalize_message(message)
            for message in raw_messages
            if self._matches_watch_profile(message)
        ]
        next_cursor = self._next_cursor(events, previous_cursor)
        return GmailSyncBatch(events=events, previous_cursor=previous_cursor, next_cursor=next_cursor)

    async def commit(self, batch: GmailSyncBatch) -> None:
        await self._cursor_store.save(batch.next_cursor)

    def _request_cursor(self, stored_cursor: str | None) -> str | None:
        if self._lookback_window_minutes <= 0:
            return stored_cursor
        lookback_floor = _utc_now() - timedelta(minutes=self._lookback_window_minutes)
        if not stored_cursor:
            return _format_cursor(lookback_floor)
        parsed_cursor = _parse_cursor(stored_cursor)
        if parsed_cursor is None:
            return stored_cursor
        return _format_cursor(min(parsed_cursor, lookback_floor))

    def _build_query(self, cursor: str | None) -> str:
        clauses: list[str] = []
        if cursor:
            parsed = _parse_cursor(cursor)
            if parsed is not None:
                clauses.append(f"after:{parsed.strftime('%Y/%m/%d')}")
        for label_id in self._label_ids:
            clauses.append(f"label:{label_id}")
        signal_clause = self._signal_clause()
        if signal_clause:
            clauses.append(signal_clause)
        if self._optional_query:
            clauses.append(self._optional_query)
        return " ".join(clauses).strip()

    def _signal_clause(self) -> str | None:
        if self._preset != "personal_inbox":
            return None
        return "category:primary OR label:INBOX"

    def _matches_watch_profile(self, message: dict) -> bool:
        event = self._normalize_message(message)
        if not event.message_id or not event.received_at:
            return False
        label_ids = [str(item).strip() for item in message.get("labelIds", []) if str(item).strip()] if isinstance(message.get("labelIds"), list) else []
        if self._label_ids and not all(label in label_ids for label in self._label_ids):
            return False
        if "TRASH" in label_ids:
            return False
        if self._preset == "personal_inbox":
            to_me = bool(message.get("toMe"))
            from_vip = bool(message.get("fromVip"))
            label_inbox = "INBOX" in label_ids
            if not (to_me or from_vip or label_inbox):
                return False
        if not self._optional_keywords:
            return True
        haystacks = [
            event.snippet.lower(),
            str(message.get("subject") or "").strip().lower(),
            str(message.get("from") or "").strip().lower(),
        ]
        return any(keyword in "\n".join(haystacks) for keyword in self._optional_keywords)

    @staticmethod
    def _normalize_message(message: dict) -> GmailSyncEvent:
        message_id = str(message.get("id") or "").strip()
        received_at = str(message.get("receivedAt") or message.get("internalDate") or "").strip()
        return GmailSyncEvent(
            id=f"{message_id}:{received_at}" if message_id and received_at else message_id or received_at,
            message_id=message_id,
            thread_id=str(message.get("threadId") or "").strip(),
            snippet=str(message.get("snippet") or "").strip(),
            received_at=received_at,
            web_url=str(message.get("webUrl") or "").strip() or None,
            payload=message,
        )

    @staticmethod
    def _next_cursor(events: list[GmailSyncEvent], previous_cursor: str | None) -> str | None:
        timestamps = [_parse_cursor(event.received_at) for event in events]
        parsed_values = [value for value in timestamps if value is not None]
        if not parsed_values:
            return previous_cursor
        return _format_cursor(max(parsed_values))


def _parse_cursor(raw_value: str) -> datetime | None:
    value = str(raw_value or "").strip()
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _format_cursor(value: datetime) -> str:
    return value.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
