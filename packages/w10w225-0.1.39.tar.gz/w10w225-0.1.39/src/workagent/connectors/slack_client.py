from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

from workagent.connectors.slack_sync import SlackFetchResponse, SlackMessage


@dataclass(frozen=True, slots=True)
class SlackApiError(Exception):
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class SlackApiClient:
    def __init__(
        self,
        *,
        base_url: str = "https://slack.com",
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.transport = transport
        self.timeout = timeout

    def list_conversations(self, *, token: str, limit: int = 100, types: str = "im,public_channel") -> list[dict[str, Any]]:
        payload = self._request(
            "GET",
            "/api/conversations.list",
            token=token,
            params={"limit": limit, "types": types},
        )
        channels = payload.get("channels")
        return channels if isinstance(channels, list) else []

    def auth_test(self, *, token: str) -> dict[str, Any]:
        return self._request("POST", "/api/auth.test", token=token)

    def fetch_recent(
        self,
        *,
        token: str,
        channel_id: str,
        cursor: str | None = None,
        limit: int = 50,
    ) -> SlackFetchResponse:
        params: dict[str, Any] = {"channel": channel_id, "limit": limit}
        if cursor:
            params["cursor"] = cursor
        payload = self._request("GET", "/api/conversations.history", token=token, params=params)
        messages = self._normalize_messages(channel_id=channel_id, rows=payload.get("messages"))
        next_cursor = self._extract_next_cursor(payload)
        return SlackFetchResponse(messages=messages, next_cursor=next_cursor)

    def fetch_thread_replies(
        self,
        *,
        token: str,
        channel_id: str,
        thread_ts: str,
    ) -> list[SlackMessage]:
        payload = self._request(
            "GET",
            "/api/conversations.replies",
            token=token,
            params={"channel": channel_id, "ts": thread_ts},
        )
        return self._normalize_messages(channel_id=channel_id, rows=payload.get("messages"))

    def search_messages(self, *, token: str, query: str, limit: int = 20) -> dict[str, Any]:
        payload = self._request(
            "GET",
            "/api/search.messages",
            token=token,
            params={"query": query, "count": limit},
        )
        matches = payload.get("messages", {}).get("matches") if isinstance(payload.get("messages"), dict) else []
        normalized: list[SlackMessage] = []
        for row in matches if isinstance(matches, list) else []:
            if not isinstance(row, dict):
                continue
            channel = row.get("channel") if isinstance(row.get("channel"), dict) else {}
            channel_id = str(channel.get("id") or "").strip()
            ts = str(row.get("ts") or "").strip()
            text = str(row.get("text") or "").strip()
            user_id = str(row.get("user") or "").strip()
            thread_ts = str(row.get("thread_ts") or "").strip() or None
            if channel_id and ts and text:
                normalized.append(
                    SlackMessage(
                        channel_id=channel_id,
                        message_ts=ts,
                        text=text,
                        user_id=user_id,
                        thread_ts=thread_ts,
                    )
                )
        return {"messages": normalized, "next_cursor": self._extract_next_cursor(payload)}

    def _request(
        self,
        method: str,
        path: str,
        *,
        token: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        with httpx.Client(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = client.request(
                method,
                path,
                params=params,
                headers={"Authorization": f"Bearer {token}"},
            )

        response.raise_for_status()
        payload = response.json()
        if not isinstance(payload, dict):
            raise SlackApiError(code="invalid_response", message="Slack API returned an invalid response.")
        if payload.get("ok") is not True:
            raise self._normalize_error(str(payload.get("error") or "unknown_error").strip() or "unknown_error")
        return payload

    @staticmethod
    def _extract_next_cursor(payload: dict[str, Any]) -> str | None:
        meta = payload.get("response_metadata")
        if isinstance(meta, dict):
            next_cursor = str(meta.get("next_cursor") or "").strip()
            return next_cursor or None
        return None

    @staticmethod
    def _normalize_messages(*, channel_id: str, rows: Any) -> list[SlackMessage]:
        messages: list[SlackMessage] = []
        for row in rows if isinstance(rows, list) else []:
            if not isinstance(row, dict):
                continue
            ts = str(row.get("ts") or "").strip()
            text = str(row.get("text") or "").strip()
            user_id = str(row.get("user") or "").strip()
            thread_ts = str(row.get("thread_ts") or "").strip() or None
            if ts and text:
                messages.append(
                    SlackMessage(
                        channel_id=channel_id,
                        message_ts=ts,
                        text=text,
                        user_id=user_id,
                        thread_ts=thread_ts,
                    )
                )
        return messages

    @staticmethod
    def _normalize_error(code: str) -> SlackApiError:
        mapping = {
            "invalid_auth": "Slack token is invalid or expired.",
            "missing_scope": "Slack token lacks the required permission.",
            "channel_not_found": "Slack channel was not found.",
            "thread_not_found": "Slack thread was not found.",
        }
        return SlackApiError(code=code, message=mapping.get(code, "Slack API request failed."))
