from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class LinearApiError(Exception):
    status_code: int
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class LinearApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_token: str,
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.transport = transport
        self.timeout = timeout

    async def get_current_user(self) -> dict[str, Any]:
        payload = await self._request_graphql(
            """
            query Viewer {
              viewer {
                id
                name
                email
              }
            }
            """,
            variables={},
        )
        viewer = payload.get("viewer")
        return viewer if isinstance(viewer, dict) else {}

    async def get_issue(self, issue_id: str) -> dict[str, Any]:
        payload = await self._request_graphql(
            """
            query Issue($issueId: String!) {
              issue(id: $issueId) {
                id
                title
                url
                state {
                  name
                }
              }
            }
            """,
            variables={"issueId": issue_id},
        )
        issue = payload.get("issue")
        return issue if isinstance(issue, dict) else {}

    async def search_issues(self, query: str, *, limit: int = 20) -> list[dict[str, Any]]:
        payload = await self._request_graphql(
            """
            query SearchIssues($query: String!, $first: Int!) {
              issueSearch(query: $query, first: $first) {
                nodes {
                  id
                  title
                  url
                  description
                  updatedAt
                  assignee {
                    id
                  }
                  state {
                    name
                  }
                  team {
                    id
                  }
                }
              }
            }
            """,
            variables={"query": query, "first": limit},
        )
        results = payload.get("issueSearch")
        if not isinstance(results, dict):
            return []
        nodes = results.get("nodes")
        return [item for item in nodes if isinstance(item, dict)] if isinstance(nodes, list) else []

    async def create_issue_comment(self, issue_id: str, body: str) -> dict[str, Any]:
        payload = await self._request_graphql(
            """
            mutation CreateComment($issueId: String!, $body: String!) {
              commentCreate(input: {issueId: $issueId, body: $body}) {
                success
                comment {
                  id
                  body
                }
              }
            }
            """,
            variables={"issueId": issue_id, "body": body},
        )
        created = payload.get("commentCreate")
        if not isinstance(created, dict):
            return {}
        comment = created.get("comment")
        return comment if isinstance(comment, dict) else {}

    async def _request_graphql(
        self,
        query: str,
        *,
        variables: dict[str, Any],
    ) -> dict[str, Any]:
        async with httpx.AsyncClient(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = await client.post(
                "/graphql",
                json={"query": query, "variables": variables},
                headers={"Authorization": self.api_token},
            )
        if response.status_code >= 400:
            payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            message = str(payload.get("message") or f"Linear API request failed with status {response.status_code}")
            code = str(payload.get("code") or "linear_api_error")
            raise LinearApiError(status_code=response.status_code, code=code, message=message)
        payload = response.json()
        if not isinstance(payload, dict):
            raise LinearApiError(status_code=500, code="linear_api_error", message="Linear API returned an invalid response")
        errors = payload.get("errors")
        if isinstance(errors, list) and errors:
            first_error = errors[0] if isinstance(errors[0], dict) else {}
            raise LinearApiError(
                status_code=400,
                code=str(first_error.get("extensions", {}).get("code") or "linear_graphql_error"),
                message=str(first_error.get("message") or "Linear GraphQL request failed"),
            )
        data = payload.get("data")
        if not isinstance(data, dict):
            raise LinearApiError(status_code=500, code="linear_api_error", message="Linear API returned an invalid data payload")
        return data
