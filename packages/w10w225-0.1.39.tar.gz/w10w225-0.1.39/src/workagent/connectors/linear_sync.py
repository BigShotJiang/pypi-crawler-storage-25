from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Protocol


def _utc_now() -> datetime:
    return datetime.now(UTC)


class CursorStore(Protocol):
    async def load(self) -> str | None: ...

    async def save(self, cursor: str | None) -> None: ...


class LinearClient(Protocol):
    async def search_issues(self, query: str, *, limit: int = 20) -> list[dict]: ...


@dataclass(frozen=True, slots=True)
class LinearSyncEvent:
    id: str
    issue_id: str
    team_id: str
    title: str
    updated_at: str
    url: str | None
    payload: dict


@dataclass(frozen=True, slots=True)
class LinearSyncBatch:
    events: list[LinearSyncEvent]
    previous_cursor: str | None
    next_cursor: str | None


class LinearSyncService:
    def __init__(
        self,
        *,
        client: LinearClient,
        cursor_store: CursorStore,
        limit: int = 20,
        lookback_window_minutes: int = 0,
        preset: str = "personal_inbox",
        team_ids: list[str] | None = None,
        optional_keywords: list[str] | None = None,
        optional_query: str | None = None,
    ) -> None:
        self._client = client
        self._cursor_store = cursor_store
        self._limit = limit
        self._lookback_window_minutes = max(0, int(lookback_window_minutes))
        self._preset = str(preset or "personal_inbox").strip() or "personal_inbox"
        self._team_ids = [item.strip() for item in (team_ids or []) if item.strip()]
        self._optional_keywords = [item.strip().lower() for item in (optional_keywords or []) if item.strip()]
        self._optional_query = str(optional_query or "").strip() or None

    async def sync_once(self) -> LinearSyncBatch:
        previous_cursor = await self._cursor_store.load()
        request_cursor = self._request_cursor(previous_cursor)
        raw_issues = await self._client.search_issues(self._build_query(request_cursor), limit=self._limit)
        events = [
            self._normalize_issue(issue)
            for issue in raw_issues
            if self._matches_watch_profile(issue)
        ]
        next_cursor = self._next_cursor(events, previous_cursor)
        return LinearSyncBatch(events=events, previous_cursor=previous_cursor, next_cursor=next_cursor)

    async def commit(self, batch: LinearSyncBatch) -> None:
        await self._cursor_store.save(batch.next_cursor)

    def _request_cursor(self, stored_cursor: str | None) -> str | None:
        if self._lookback_window_minutes <= 0:
            return stored_cursor
        lookback_floor = _utc_now() - timedelta(minutes=self._lookback_window_minutes)
        if not stored_cursor:
            return _format_cursor(lookback_floor)
        parsed_cursor = _parse_cursor(stored_cursor)
        if parsed_cursor is None:
            return stored_cursor
        return _format_cursor(min(parsed_cursor, lookback_floor))

    def _build_query(self, cursor: str | None) -> str:
        clauses = ["resource = issue"]
        if cursor:
            clauses.append(f'updated_at >= "{cursor}"')
        if self._team_ids:
            quoted = ", ".join(f'"{item}"' for item in self._team_ids)
            clauses.append(f"team in ({quoted})")
        signal_clause = self._signal_clause()
        if signal_clause:
            clauses.append(f"({signal_clause})")
        if self._optional_query:
            clauses.append(f"({self._optional_query})")
        return " AND ".join(clauses) + " order by updated_at desc"

    def _signal_clause(self) -> str | None:
        if self._preset != "personal_inbox":
            return None
        return "assignee_me OR mentioned_me"

    def _matches_watch_profile(self, issue: dict) -> bool:
        event = self._normalize_issue(issue)
        if not event.issue_id or not event.title or not event.updated_at:
            return False
        if self._team_ids and event.team_id not in self._team_ids:
            return False
        state = issue.get("state") if isinstance(issue.get("state"), dict) else {}
        state_name = str(state.get("name") or "").strip().lower()
        if state_name in {"done", "closed", "canceled", "cancelled"}:
            return False
        if self._preset == "personal_inbox":
            assignee = issue.get("assignee") if isinstance(issue.get("assignee"), dict) else {}
            mention_user_ids = issue.get("mentionUserIds")
            if not assignee and not mention_user_ids:
                return False
        if not self._optional_keywords:
            return True
        haystacks = [
            event.title.lower(),
            event.team_id.lower(),
            str(issue.get("description") or "").strip().lower(),
        ]
        return any(keyword in "\n".join(haystacks) for keyword in self._optional_keywords)

    @staticmethod
    def _normalize_issue(issue: dict) -> LinearSyncEvent:
        issue_id = str(issue.get("id") or "").strip()
        updated_at = str(issue.get("updatedAt") or "").strip()
        team = issue.get("team") if isinstance(issue.get("team"), dict) else {}
        return LinearSyncEvent(
            id=f"{issue_id}:{updated_at}" if issue_id and updated_at else issue_id or updated_at,
            issue_id=issue_id,
            team_id=str(team.get("id") or issue.get("teamId") or "").strip(),
            title=str(issue.get("title") or "").strip(),
            updated_at=updated_at,
            url=str(issue.get("url") or "").strip() or None,
            payload=issue,
        )

    @staticmethod
    def _next_cursor(events: list[LinearSyncEvent], previous_cursor: str | None) -> str | None:
        timestamps = [_parse_cursor(event.updated_at) for event in events]
        parsed_values = [value for value in timestamps if value is not None]
        if not parsed_values:
            return previous_cursor
        return _format_cursor(max(parsed_values))


def _parse_cursor(raw_value: str) -> datetime | None:
    value = str(raw_value or "").strip()
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _format_cursor(value: datetime) -> str:
    return value.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
