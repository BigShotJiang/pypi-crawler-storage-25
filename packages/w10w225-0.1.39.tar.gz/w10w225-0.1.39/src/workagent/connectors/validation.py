from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urlparse

import httpx

from workagent.config.models import Platform


@dataclass(frozen=True, slots=True)
class ValidationResult:
    platform: Platform
    ok: bool
    status_code: int
    detail: str
    metadata: dict[str, str] = field(default_factory=dict)


class ConnectorValidationError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class HttpConnectorValidator:
    timeout: float = 5.0

    def validate(self, platform: Platform, base_url: str, secret: str) -> ValidationResult:
        return validate_connector_config(platform, base_url, secret, timeout=self.timeout)


def _normalize_base_url(base_url: str) -> str:
    normalized = base_url.strip().rstrip("/")
    parsed = urlparse(normalized)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ConnectorValidationError("base URL must start with http:// or https://")
    return normalized


def _request_config(platform: Platform, base_url: str, token: str) -> tuple[str, str, dict[str, str]]:
    if platform == Platform.SLACK:
        return "POST", f"{base_url}/api/auth.test", {"Authorization": f"Bearer {token}"}
    if platform == Platform.GITLAB:
        return "GET", f"{base_url}/api/v4/user", {"PRIVATE-TOKEN": token}
    if platform == Platform.JIRA:
        return "GET", f"{base_url}/rest/api/3/myself", {"Authorization": f"Bearer {token}"}
    if platform == Platform.CONFLUENCE:
        return "GET", f"{base_url}/wiki/rest/api/user/current", {"Authorization": f"Bearer {token}"}
    raise ConnectorValidationError(f"unsupported platform: {platform}")


def validate_connector_config(
    platform: Platform,
    base_url: str,
    token: str,
    *,
    transport: httpx.BaseTransport | None = None,
    timeout: float = 5.0,
) -> ValidationResult:
    normalized_base_url = _normalize_base_url(base_url)
    if not token.strip():
        raise ConnectorValidationError("token is required")

    method, url, headers = _request_config(platform, normalized_base_url, token.strip())

    try:
        with httpx.Client(transport=transport, timeout=timeout) as client:
            response = client.request(method, url, headers=headers)
    except httpx.HTTPError as exc:
        raise ConnectorValidationError(f"{platform.value} validation request failed") from exc

    if response.status_code >= 400:
        raise ConnectorValidationError(f"{platform.value} validation returned status {response.status_code}")

    payload = response.json()
    if platform == Platform.SLACK:
        if payload.get("ok") is not True:
            raise ConnectorValidationError(f"slack validation failed: {payload.get('error') or 'unknown_error'}")

    return ValidationResult(
        platform=platform,
        ok=True,
        status_code=response.status_code,
        detail="validated",
        metadata=_identity_metadata(platform, payload if isinstance(payload, dict) else {}),
    )


def _identity_metadata(platform: Platform, payload: dict[str, Any]) -> dict[str, str]:
    metadata: dict[str, str] = {"platformId": platform.value}
    if platform == Platform.SLACK:
        metadata["externalId"] = str(payload.get("user_id") or payload.get("user") or "").strip()
        metadata["identityDisplay"] = metadata["externalId"] or str(payload.get("team") or "").strip()
        metadata["workspace"] = str(payload.get("team") or "").strip()
        return {key: value for key, value in metadata.items() if value}
    if platform == Platform.GITLAB:
        metadata["externalId"] = str(payload.get("id") or "").strip()
        metadata["username"] = str(payload.get("username") or "").strip()
        metadata["displayName"] = str(payload.get("name") or "").strip()
        metadata["identityDisplay"] = metadata["username"] or metadata["displayName"]
        return {key: value for key, value in metadata.items() if value}
    if platform == Platform.JIRA:
        metadata["externalId"] = str(payload.get("accountId") or "").strip()
        metadata["displayName"] = str(payload.get("displayName") or "").strip()
        metadata["email"] = str(payload.get("emailAddress") or "").strip()
        metadata["identityDisplay"] = metadata["email"] or metadata["displayName"] or metadata["externalId"]
        return {key: value for key, value in metadata.items() if value}
    if platform == Platform.CONFLUENCE:
        metadata["externalId"] = str(payload.get("accountId") or "").strip()
        metadata["displayName"] = str(payload.get("publicName") or payload.get("displayName") or "").strip()
        metadata["email"] = str(payload.get("email") or payload.get("emailAddress") or "").strip()
        metadata["identityDisplay"] = metadata["email"] or metadata["displayName"] or metadata["externalId"]
        return {key: value for key, value in metadata.items() if value}
    return metadata
