from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Protocol


def _utc_now() -> datetime:
    return datetime.now(UTC)


class CursorStore(Protocol):
    async def load(self) -> str | None: ...

    async def save(self, cursor: str | None) -> None: ...


class ZendeskClient(Protocol):
    async def search_tickets(self, query: str, *, limit: int = 20) -> list[dict]: ...


@dataclass(frozen=True, slots=True)
class ZendeskSyncEvent:
    id: str
    ticket_id: str
    view_id: str
    subject: str
    updated_at: str
    url: str | None
    payload: dict


@dataclass(frozen=True, slots=True)
class ZendeskSyncBatch:
    events: list[ZendeskSyncEvent]
    previous_cursor: str | None
    next_cursor: str | None


class ZendeskSyncService:
    def __init__(
        self,
        *,
        client: ZendeskClient,
        cursor_store: CursorStore,
        limit: int = 20,
        lookback_window_minutes: int = 0,
        preset: str = "personal_inbox",
        view_ids: list[str] | None = None,
        optional_keywords: list[str] | None = None,
        optional_query: str | None = None,
    ) -> None:
        self._client = client
        self._cursor_store = cursor_store
        self._limit = limit
        self._lookback_window_minutes = max(0, int(lookback_window_minutes))
        self._preset = str(preset or "personal_inbox").strip() or "personal_inbox"
        self._view_ids = [item.strip() for item in (view_ids or []) if item.strip()]
        self._optional_keywords = [item.strip().lower() for item in (optional_keywords or []) if item.strip()]
        self._optional_query = str(optional_query or "").strip() or None

    async def sync_once(self) -> ZendeskSyncBatch:
        previous_cursor = await self._cursor_store.load()
        request_cursor = self._request_cursor(previous_cursor)
        raw_tickets = await self._client.search_tickets(self._build_query(request_cursor), limit=self._limit)
        events = [
            self._normalize_ticket(ticket)
            for ticket in raw_tickets
            if self._matches_watch_profile(ticket)
        ]
        next_cursor = self._next_cursor(events, previous_cursor)
        return ZendeskSyncBatch(events=events, previous_cursor=previous_cursor, next_cursor=next_cursor)

    async def commit(self, batch: ZendeskSyncBatch) -> None:
        await self._cursor_store.save(batch.next_cursor)

    def _request_cursor(self, stored_cursor: str | None) -> str | None:
        if self._lookback_window_minutes <= 0:
            return stored_cursor
        lookback_floor = _utc_now() - timedelta(minutes=self._lookback_window_minutes)
        if not stored_cursor:
            return _format_cursor(lookback_floor)
        parsed_cursor = _parse_cursor(stored_cursor)
        if parsed_cursor is None:
            return stored_cursor
        return _format_cursor(min(parsed_cursor, lookback_floor))

    def _build_query(self, cursor: str | None) -> str:
        clauses = ["type:ticket"]
        if cursor:
            clauses.append(f'updated_at >= "{cursor}"')
        if self._view_ids:
            quoted = ", ".join(f'"{item}"' for item in self._view_ids)
            clauses.append(f"view_id in ({quoted})")
        signal_clause = self._signal_clause()
        if signal_clause:
            clauses.append(f"({signal_clause})")
        if self._optional_query:
            clauses.append(f"({self._optional_query})")
        return " AND ".join(clauses) + " order by updated_at desc"

    def _signal_clause(self) -> str | None:
        if self._preset != "personal_inbox":
            return None
        return "assignee_me = true OR requester_me = true"

    def _matches_watch_profile(self, ticket: dict) -> bool:
        event = self._normalize_ticket(ticket)
        if not event.ticket_id or not event.subject or not event.updated_at:
            return False
        if self._view_ids and event.view_id not in self._view_ids:
            return False
        if self._preset == "personal_inbox":
            if not (bool(ticket.get("assigneeMe")) or bool(ticket.get("requesterMe"))):
                return False
        if not self._optional_keywords:
            return True
        haystacks = [
            event.subject.lower(),
            str(ticket.get("description") or "").strip().lower(),
            event.view_id.lower(),
        ]
        return any(keyword in "\n".join(haystacks) for keyword in self._optional_keywords)

    @staticmethod
    def _normalize_ticket(ticket: dict) -> ZendeskSyncEvent:
        ticket_id = str(ticket.get("id") or "").strip()
        updated_at = str(ticket.get("updatedAt") or ticket.get("updated_at") or "").strip()
        return ZendeskSyncEvent(
            id=f"{ticket_id}:{updated_at}" if ticket_id and updated_at else ticket_id or updated_at,
            ticket_id=ticket_id,
            view_id=str(ticket.get("viewId") or "").strip(),
            subject=str(ticket.get("subject") or "").strip(),
            updated_at=updated_at,
            url=str(ticket.get("url") or "").strip() or None,
            payload=ticket,
        )

    @staticmethod
    def _next_cursor(events: list[ZendeskSyncEvent], previous_cursor: str | None) -> str | None:
        timestamps = [_parse_cursor(event.updated_at) for event in events]
        parsed_values = [value for value in timestamps if value is not None]
        if not parsed_values:
            return previous_cursor
        return _format_cursor(max(parsed_values))


def _parse_cursor(raw_value: str) -> datetime | None:
    value = str(raw_value or "").strip()
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _format_cursor(value: datetime) -> str:
    return value.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
