from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass(frozen=True, slots=True)
class JiraApiError(Exception):
    status_code: int
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class JiraApiClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_token: str,
        transport: httpx.BaseTransport | None = None,
        timeout: float = 10.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_token = api_token
        self.transport = transport
        self.timeout = timeout

    async def search_issues(self, jql: str, *, limit: int = 20) -> list[dict[str, Any]]:
        payload = await self._request_json(
            "POST",
            "/rest/api/3/search/jql",
            json={"jql": jql, "maxResults": limit},
        )
        issues = payload.get("issues")
        return issues if isinstance(issues, list) else []

    async def get_issue(self, issue_key: str, *, expand: str | None = None) -> dict[str, Any]:
        params = {"expand": expand} if expand else None
        payload = await self._request_json(
            "GET",
            f"/rest/api/3/issue/{issue_key}",
            params=params,
        )
        return payload if isinstance(payload, dict) else {}

    async def get_current_user(self) -> dict[str, Any]:
        payload = await self._request_json("GET", "/rest/api/3/myself")
        return payload if isinstance(payload, dict) else {}

    async def create_issue_comment(self, issue_key: str, body: str) -> dict[str, Any]:
        payload = await self._request_json(
            "POST",
            f"/rest/api/3/issue/{issue_key}/comment",
            json={"body": body},
        )
        return payload if isinstance(payload, dict) else {}

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        async with httpx.AsyncClient(base_url=self.base_url, transport=self.transport, timeout=self.timeout) as client:
            response = await client.request(
                method,
                path,
                json=json,
                params=params,
                headers={"Authorization": f"Bearer {self.api_token}"},
            )
        if response.status_code >= 400:
            payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
            messages = payload.get("errorMessages") if isinstance(payload, dict) else None
            detail = ", ".join(str(item) for item in messages) if isinstance(messages, list) else None
            raise JiraApiError(
                status_code=response.status_code,
                code="jira_api_error",
                message=detail or f"Jira API request failed with status {response.status_code}",
            )
        return response.json()
