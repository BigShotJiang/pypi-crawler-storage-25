from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Protocol


def _utc_now() -> datetime:
    return datetime.now(UTC)


class CursorStore(Protocol):
    async def load(self) -> str | None: ...

    async def save(self, cursor: str | None) -> None: ...


class ConfluenceClient(Protocol):
    async def search_content(self, cql: str, *, limit: int = 20) -> list[dict]: ...


@dataclass(frozen=True, slots=True)
class ConfluenceSyncEvent:
    id: str
    page_id: str
    title: str
    space_key: str
    last_modified_at: str
    webui: str | None
    payload: dict


@dataclass(frozen=True, slots=True)
class ConfluenceSyncBatch:
    events: list[ConfluenceSyncEvent]
    previous_cursor: str | None
    next_cursor: str | None


class ConfluenceSyncService:
    def __init__(
        self,
        *,
        client: ConfluenceClient,
        cursor_store: CursorStore,
        limit: int = 20,
        lookback_window_minutes: int = 0,
        preset: str = "personal_inbox",
        space_keys: list[str] | None = None,
        optional_keywords: list[str] | None = None,
        optional_cql: str | None = None,
    ) -> None:
        self._client = client
        self._cursor_store = cursor_store
        self._limit = limit
        self._lookback_window_minutes = max(0, int(lookback_window_minutes))
        self._preset = str(preset or "personal_inbox").strip() or "personal_inbox"
        self._space_keys = [item.strip() for item in (space_keys or []) if item.strip()]
        self._optional_keywords = [item.strip().lower() for item in (optional_keywords or []) if item.strip()]
        self._optional_cql = str(optional_cql or "").strip() or None

    async def sync_once(self) -> ConfluenceSyncBatch:
        previous_cursor = await self._cursor_store.load()
        request_cursor = self._request_cursor(previous_cursor)
        raw_pages = await self._client.search_content(self._build_cql(request_cursor), limit=self._limit)
        events = [
            self._normalize_page(page)
            for page in raw_pages
            if self._matches_watch_profile(page)
        ]
        next_cursor = self._next_cursor(events, previous_cursor)
        return ConfluenceSyncBatch(events=events, previous_cursor=previous_cursor, next_cursor=next_cursor)

    async def commit(self, batch: ConfluenceSyncBatch) -> None:
        await self._cursor_store.save(batch.next_cursor)

    def _request_cursor(self, stored_cursor: str | None) -> str | None:
        if self._lookback_window_minutes <= 0:
            return stored_cursor
        lookback_floor = _utc_now() - timedelta(minutes=self._lookback_window_minutes)
        if not stored_cursor:
            return _format_cursor(lookback_floor)
        parsed_cursor = _parse_cursor(stored_cursor)
        if parsed_cursor is None:
            return stored_cursor
        return _format_cursor(min(parsed_cursor, lookback_floor))

    def _build_cql(self, cursor: str | None) -> str:
        clauses = ["type = page"]
        if cursor:
            clauses.append(f'lastmodified >= "{_format_cql_timestamp(cursor)}"')
        if self._space_keys:
            quoted = ", ".join(f'"{item}"' for item in self._space_keys)
            clauses.append(f"space in ({quoted})")
        signal_clause = self._signal_clause()
        if signal_clause:
            clauses.append(f"({signal_clause})")
        if self._optional_cql:
            clauses.append(f"({self._optional_cql})")
        return " AND ".join(clauses) + " order by lastmodified desc"

    def _signal_clause(self) -> str | None:
        if self._preset != "personal_inbox":
            return None
        return "creator = currentUser() OR contributor = currentUser()"

    def _matches_watch_profile(self, page: dict) -> bool:
        event = self._normalize_page(page)
        if not event.page_id or not event.title or not event.last_modified_at:
            return False
        if self._space_keys and event.space_key not in self._space_keys:
            return False
        if str(event.payload.get("contentType") or "page").strip().lower() != "page":
            return False
        if not self._optional_keywords:
            return True
        haystacks = [
            event.title.lower(),
            event.space_key.lower(),
            str(event.payload.get("excerpt") or "").strip().lower(),
        ]
        return any(keyword in "\n".join(haystacks) for keyword in self._optional_keywords)

    @staticmethod
    def _normalize_page(page: dict) -> ConfluenceSyncEvent:
        page_id = str(page.get("id") or "").strip()
        last_modified_at = str(page.get("lastModified") or "").strip()
        version = str(page.get("version") or "").strip()
        event_id = f"{page_id}:{version or last_modified_at}" if page_id else version or last_modified_at
        return ConfluenceSyncEvent(
            id=event_id,
            page_id=page_id,
            title=str(page.get("title") or "").strip(),
            space_key=str(page.get("spaceKey") or "").strip(),
            last_modified_at=last_modified_at,
            webui=str(page.get("webui") or "").strip() or None,
            payload=page,
        )

    @staticmethod
    def _next_cursor(events: list[ConfluenceSyncEvent], previous_cursor: str | None) -> str | None:
        timestamps = [_parse_cursor(event.last_modified_at) for event in events]
        parsed_values = [value for value in timestamps if value is not None]
        if not parsed_values:
            return previous_cursor
        return _format_cursor(max(parsed_values))


def _parse_cursor(raw_value: str) -> datetime | None:
    value = str(raw_value or "").strip()
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _format_cursor(value: datetime) -> str:
    return value.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _format_cql_timestamp(raw_cursor: str) -> str:
    parsed = _parse_cursor(raw_cursor)
    if parsed is None:
        return raw_cursor
    return parsed.astimezone(UTC).strftime("%Y/%m/%d %H:%M")
