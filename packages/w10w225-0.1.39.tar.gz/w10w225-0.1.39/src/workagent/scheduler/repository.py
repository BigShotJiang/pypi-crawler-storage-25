from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.models import ScheduledJob
from workagent.scheduler.service import SchedulerJobState


class SqlAlchemySchedulerJobRepository:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def list_jobs(self) -> list[SchedulerJobState]:
        async with self.session_factory() as session:
            rows = (await session.execute(select(ScheduledJob).order_by(ScheduledJob.name.asc()))).scalars().all()
        return [
            SchedulerJobState(
                job_id=row.id,
                name=row.name,
                cron_expression=row.cron_expression,
                is_enabled=row.is_enabled,
                next_run_at=row.next_run_at,
                payload_json=row.payload_json or {},
            )
            for row in rows
        ]

    async def save_jobs(self, jobs: list[SchedulerJobState]) -> None:
        async with self.session_factory() as session:
            for job in jobs:
                row = await session.get(ScheduledJob, job.job_id)
                if row is None:
                    continue
                row.name = job.name
                row.cron_expression = job.cron_expression
                row.is_enabled = job.is_enabled
                row.next_run_at = job.next_run_at
                row.payload_json = job.payload_json
            await session.commit()
