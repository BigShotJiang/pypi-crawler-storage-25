from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from workagent.scheduler.service import SchedulerJobState, identify_runnable_jobs, reconcile_due_jobs


class SchedulerJobRepository(Protocol):
    async def list_jobs(self) -> list[SchedulerJobState]: ...

    async def save_jobs(self, jobs: list[SchedulerJobState]) -> None: ...


class ScheduledJobLauncher(Protocol):
    async def launch(self, job: SchedulerJobState) -> str: ...


@dataclass(frozen=True, slots=True)
class SchedulerRuntimeResult:
    runnable_jobs: list[SchedulerJobState]
    reconciled_jobs: list[SchedulerJobState]


class SchedulerRuntime:
    def __init__(
        self,
        repository: SchedulerJobRepository,
        *,
        launcher: ScheduledJobLauncher | None = None,
    ) -> None:
        self.repository = repository
        self.launcher = launcher
        self._run_lock = asyncio.Lock()

    async def run_once(self, now: datetime) -> SchedulerRuntimeResult:
        async with self._run_lock:
            jobs = await self.repository.list_jobs()
            runnable_jobs = identify_runnable_jobs(jobs, now)
            reconciled_jobs = reconcile_due_jobs(jobs, now)
            await self.repository.save_jobs(reconciled_jobs)
            if self.launcher is not None:
                for job in runnable_jobs:
                    await self.launcher.launch(job)
            return SchedulerRuntimeResult(
                runnable_jobs=runnable_jobs,
                reconciled_jobs=reconciled_jobs,
            )
