from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import UTC, datetime
from typing import Any

from croniter import croniter


@dataclass(frozen=True, slots=True)
class SchedulerJobState:
    job_id: str
    name: str
    cron_expression: str
    is_enabled: bool
    next_run_at: datetime | None
    payload_json: dict[str, Any] = field(default_factory=dict)


def _normalize_datetime(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value


def compute_next_run(cron_expression: str, now: datetime) -> datetime:
    return _normalize_datetime(croniter(cron_expression, _normalize_datetime(now)).get_next(datetime))


def identify_runnable_jobs(jobs: list[SchedulerJobState], now: datetime) -> list[SchedulerJobState]:
    return [
        job
        for job in jobs
        if job.is_enabled
        and job.next_run_at is not None
        and _normalize_datetime(job.next_run_at) <= _normalize_datetime(now)
    ]


def reconcile_due_jobs(jobs: list[SchedulerJobState], now: datetime) -> list[SchedulerJobState]:
    reconciled: list[SchedulerJobState] = []
    for job in jobs:
        if not job.is_enabled:
            reconciled.append(job)
            continue
        if job.next_run_at is None or _normalize_datetime(job.next_run_at) <= _normalize_datetime(now):
            reconciled.append(replace(job, next_run_at=compute_next_run(job.cron_expression, now)))
            continue
        reconciled.append(job)
    return reconciled
