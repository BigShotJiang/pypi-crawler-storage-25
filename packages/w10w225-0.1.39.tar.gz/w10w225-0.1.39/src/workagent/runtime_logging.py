from __future__ import annotations

from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from uvicorn.config import LOGGING_CONFIG

from workagent.config.env import resolve_workagent_home

DEFAULT_RUNTIME_LOG_RETAIN_DAYS = 14
DEFAULT_RUNTIME_LOG_MAX_FILES = 30


def resolve_workagent_logs_dir(*, home_dir: Path | None = None) -> Path:
    logs_dir = resolve_workagent_home(home_override=home_dir) / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    return logs_dir


def resolve_daily_log_file(
    *,
    prefix: str = "serve",
    now: datetime | None = None,
    home_dir: Path | None = None,
) -> Path:
    timestamp = (now or datetime.now(UTC)).astimezone(UTC)
    return resolve_workagent_logs_dir(home_dir=home_dir) / f"{prefix}-{timestamp.strftime('%Y-%m-%d')}.log"


def cleanup_runtime_log_files(
    *,
    logs_dir: Path | None = None,
    home_dir: Path | None = None,
    retain_days: int = DEFAULT_RUNTIME_LOG_RETAIN_DAYS,
    max_files: int = DEFAULT_RUNTIME_LOG_MAX_FILES,
    now: datetime | None = None,
) -> list[str]:
    target_dir = logs_dir or resolve_workagent_logs_dir(home_dir=home_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    cutoff_ts = (now or datetime.now(UTC)).timestamp() - (retain_days * 86400)
    log_files = sorted(
        (path for path in target_dir.iterdir() if path.is_file() and path.suffix == ".log"),
        key=lambda path: (path.stat().st_mtime, path.name),
    )
    to_remove: list[Path] = [path for path in log_files if path.stat().st_mtime < cutoff_ts]
    survivors = [path for path in log_files if path not in to_remove]
    overflow = max(0, len(survivors) - max_files)
    if overflow:
        to_remove.extend(survivors[:overflow])

    removed_names: list[str] = []
    seen: set[Path] = set()
    for path in to_remove:
        if path in seen:
            continue
        seen.add(path)
        path.unlink(missing_ok=True)
        removed_names.append(path.name)
    return removed_names


def build_uvicorn_log_config(log_file: Path) -> dict[str, Any]:
    config = deepcopy(LOGGING_CONFIG)
    config["formatters"]["workagent_file"] = {
        "format": "%(asctime)s %(levelname)s [%(name)s] %(message)s",
    }
    config["handlers"]["workagent_file"] = {
        "class": "logging.FileHandler",
        "filename": str(log_file),
        "encoding": "utf-8",
        "formatter": "workagent_file",
    }
    config["loggers"]["workagent"] = {
        "handlers": ["workagent_file"],
        "level": "INFO",
        "propagate": False,
    }

    for logger_name in ("uvicorn.error", "uvicorn.access"):
        logger_config = config["loggers"].setdefault(logger_name, {})
        handlers = list(logger_config.get("handlers", []))
        if "workagent_file" not in handlers:
            handlers.append("workagent_file")
        logger_config["handlers"] = handlers

    return config
