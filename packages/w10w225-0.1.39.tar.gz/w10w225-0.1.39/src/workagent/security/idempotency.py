from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class IdempotencyKeyError(ValueError):
    message: str = "idempotency key is required"

    def __str__(self) -> str:
        return self.message


def normalize_idempotency_key(raw_value: str) -> str:
    normalized = raw_value.strip()
    if not normalized:
        raise IdempotencyKeyError()
    return normalized
