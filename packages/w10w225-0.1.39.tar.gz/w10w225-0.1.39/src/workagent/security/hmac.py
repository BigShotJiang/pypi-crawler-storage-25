from __future__ import annotations

import hashlib
import hmac
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime


@dataclass(frozen=True, slots=True)
class InvalidSignatureError(ValueError):
    message: str = "invalid signature"

    def __str__(self) -> str:
        return self.message


def _build_signing_payload(*, method: str, path: str, timestamp: str, body: bytes) -> bytes:
    return b"\n".join(
        [
            method.upper().encode("utf-8"),
            path.encode("utf-8"),
            timestamp.encode("utf-8"),
            body,
        ]
    )


@dataclass(frozen=True, slots=True)
class HmacSha256Signer:
    secret: str
    timestamp_provider: Callable[[], str] | None = None

    def sign(self, *, method: str, path: str, body: bytes) -> dict[str, str]:
        timestamp = self.timestamp_provider() if self.timestamp_provider else datetime.now(UTC).isoformat()
        payload = _build_signing_payload(method=method, path=path, timestamp=timestamp, body=body)
        digest = hmac.new(self.secret.encode("utf-8"), payload, hashlib.sha256).hexdigest()
        return {
            "x-workagent-timestamp": timestamp,
            "x-workagent-signature": digest,
        }


def verify_signature(
    *,
    secret: str,
    method: str,
    path: str,
    body: bytes,
    timestamp: str,
    signature: str,
) -> None:
    payload = _build_signing_payload(method=method, path=path, timestamp=timestamp, body=body)
    expected = hmac.new(secret.encode("utf-8"), payload, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature):
        raise InvalidSignatureError()


def is_timestamp_within_skew(timestamp: str, *, now: datetime | None = None, max_skew_seconds: int = 300) -> bool:
    reference = now or datetime.now(UTC)
    parsed = datetime.fromisoformat(timestamp)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    skew = abs((reference - parsed).total_seconds())
    return skew <= max_skew_seconds
