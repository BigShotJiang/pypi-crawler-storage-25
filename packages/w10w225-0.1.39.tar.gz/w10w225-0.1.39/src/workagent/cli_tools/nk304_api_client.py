"""nk304 API client with HMAC-based token exchange and JWT auto-refresh.

Token exchange flow:
    1. Build enhanced HMAC signature: HMAC-SHA256(secret, "{installation_id}\\n{timestamp}\\n{method}\\n{path}")
    2. POST /api/v2/assistant/agent-token with HMAC headers
    3. Receive short-lived JWT (10 min)
    4. Use JWT as Bearer token for all subsequent API calls
    5. Auto-refresh JWT 1 minute before expiry
"""
from __future__ import annotations

import hashlib
import hmac
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta

import httpx

from workagent.config.env import get_supported_env_value
from workagent.config.installation import load_agent_secret, load_installation_id
from workagent.sync.factory import DEFAULT_REVIEW_BASE_URL

logger = logging.getLogger(__name__)

# Refresh JWT this many seconds before it actually expires.
_REFRESH_MARGIN_SECONDS = 60


@dataclass(frozen=True, slots=True)
class Nk304TokenError(Exception):
    message: str

    def __str__(self) -> str:
        return self.message


@dataclass(slots=True)
class _CachedToken:
    """In-memory cache for a JWT obtained from the token-exchange endpoint."""
    jwt: str
    expires_at: datetime


@dataclass(slots=True)
class Nk304ApiClient:
    """HTTP client for nk304 APIs using JWT Bearer auth.

    The client lazily obtains (and auto-refreshes) a JWT by exchanging HMAC
    credentials via ``POST /api/v2/assistant/agent-token``.

    Config values are loaded from the standard workagent config system:
        - ``base_url``: WORKAGENT_REVIEW_BASE_URL env / .env (default: https://w10w225.uk)
        - ``installation_id``: ~/.personal-work-agent/installation-id
        - ``secret``: ~/.personal-work-agent/agent-secret
    """
    base_url: str
    installation_id: str
    secret: str
    timeout: float = 10.0
    _cached_token: _CachedToken | None = field(default=None, init=False, repr=False)

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def from_env(cls, *, home_dir=None, cwd=None) -> Nk304ApiClient:  # noqa: ANN001
        """Build a client from the standard config / env locations."""
        base_url = get_supported_env_value("WORKAGENT_REVIEW_BASE_URL", cwd=cwd) or DEFAULT_REVIEW_BASE_URL
        installation_id = load_installation_id(home_dir=home_dir, cwd=cwd)
        if not installation_id:
            raise Nk304TokenError("installation_id not configured (run 'w10w225 setup' first)")
        secret = load_agent_secret(home_dir=home_dir, cwd=cwd)
        if not secret:
            raise Nk304TokenError("agent secret not configured (run 'w10w225 setup' first)")
        return cls(base_url=base_url.rstrip("/"), installation_id=installation_id, secret=secret)

    # ------------------------------------------------------------------
    # Public API helpers
    # ------------------------------------------------------------------

    async def get(self, path: str, *, params: dict | None = None) -> dict:
        """Perform an authenticated GET against the nk304 API."""
        return await self._authed_request("GET", path, params=params)

    async def post(self, path: str, *, json_body: dict | None = None) -> dict:
        """Perform an authenticated POST against the nk304 API."""
        return await self._authed_request("POST", path, json_body=json_body)

    async def put(self, path: str, *, json_body: dict | None = None) -> dict:
        """Perform an authenticated PUT against the nk304 API."""
        return await self._authed_request("PUT", path, json_body=json_body)

    async def patch(self, path: str, *, json_body: dict | None = None) -> dict:
        """Perform an authenticated PATCH against the nk304 API."""
        return await self._authed_request("PATCH", path, json_body=json_body)

    async def delete(self, path: str) -> dict:
        """Perform an authenticated DELETE against the nk304 API."""
        return await self._authed_request("DELETE", path)

    async def post_with_hmac(self, path: str, json_body: dict | None = None) -> dict:
        """Send a POST with raw HMAC headers instead of JWT Bearer.

        Used for endpoints (like secret rotation) that require HMAC auth
        directly rather than a JWT Bearer token.
        """
        headers = self._build_agent_headers(method="POST", path=path)
        async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as client:
            resp = await client.post(path, json=json_body, headers=headers)
            resp.raise_for_status()
            payload = resp.json()
            return payload.get("data", payload)

    # ------------------------------------------------------------------
    # HMAC signature (enhanced: includes method + path)
    # ------------------------------------------------------------------

    def _build_agent_signature(self, *, timestamp: str, method: str, path: str) -> str:
        """HMAC-SHA256(secret, "{installation_id}\\n{timestamp}\\n{method}\\n{path}")"""
        payload = f"{self.installation_id}\n{timestamp}\n{method.upper()}\n{path}"
        return hmac.new(
            self.secret.encode("utf-8"),
            payload.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    def _build_agent_headers(self, *, method: str, path: str) -> dict[str, str]:
        """Return HMAC auth headers for the agent-token exchange endpoint."""
        timestamp = datetime.now(UTC).isoformat()
        signature = self._build_agent_signature(timestamp=timestamp, method=method, path=path)
        return {
            "x-agent-installation-id": self.installation_id,
            "x-agent-timestamp": timestamp,
            "x-agent-signature": signature,
        }

    # ------------------------------------------------------------------
    # Token exchange + caching
    # ------------------------------------------------------------------

    async def _ensure_token(self) -> str:
        """Return a valid JWT, refreshing if needed."""
        now = datetime.now(UTC)
        if self._cached_token is not None and now < self._cached_token.expires_at:
            return self._cached_token.jwt
        return await self._exchange_token()

    async def _exchange_token(self) -> str:
        """POST /api/v2/assistant/agent-token to get a fresh JWT."""
        path = "/api/v2/assistant/agent-token"
        headers = self._build_agent_headers(method="POST", path=path)
        async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as client:
            response = await client.post(path, headers=headers)
        if response.status_code == 401:
            raise Nk304TokenError("HMAC authentication failed (check installation_id and agent secret)")
        response.raise_for_status()

        data = response.json()
        body = data.get("data", data)
        jwt_token = body.get("access_token") or body.get("token") or body.get("accessToken")
        if not jwt_token:
            raise Nk304TokenError(f"token exchange response missing token field: {list(body.keys())}")

        # Parse expiry: use expiresIn (seconds) if available, else default 10 min.
        expires_in = body.get("expires_in") or body.get("expiresIn", 600)
        expires_at = datetime.now(UTC) + timedelta(seconds=max(expires_in - _REFRESH_MARGIN_SECONDS, 30))
        self._cached_token = _CachedToken(jwt=jwt_token, expires_at=expires_at)

        # Detect secret rotation advisory
        if body.get("secret_expires_soon") or body.get("secretExpiresSoon"):
            logger.warning(
                "nk304: agent secret expires soon -- rotate via 'w10w225 reconnect'"
            )

        return jwt_token

    # ------------------------------------------------------------------
    # Authenticated request dispatcher
    # ------------------------------------------------------------------

    async def _authed_request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict | None = None,
        params: dict | None = None,
    ) -> dict:
        """Issue an API request with a Bearer JWT obtained from token exchange."""
        token = await self._ensure_token()
        headers = {
            "Authorization": f"Bearer {token}",
        }
        async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as client:
            response = await client.request(method, path, json=json_body, params=params, headers=headers)

        # If we got a 401 the JWT might have been revoked / expired early.
        # Try one token refresh and retry.
        if response.status_code == 401:
            self._cached_token = None
            token = await self._ensure_token()
            headers["Authorization"] = f"Bearer {token}"
            async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout) as client:
                response = await client.request(method, path, json=json_body, params=params, headers=headers)

        response.raise_for_status()
        payload = response.json()
        return payload.get("data", payload)
