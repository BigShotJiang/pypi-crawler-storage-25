"""User domain CLI commands for the nk304 API.

Each async function accepts an ``Nk304ApiClient`` instance and returns
a human-readable string (designed for LLM consumption) that will be
printed to stdout by the CLI entry point.

WBS 6-7-1 .. 6-7-3
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

import httpx


# ---------------------------------------------------------------------------
# Error handling helpers
# ---------------------------------------------------------------------------

_ERROR_MESSAGES: dict[int, str] = {
    403: "접근 권한이 없습니다",
    404: "사용자를 찾을 수 없습니다",
}


def _handle_http_error(exc: httpx.HTTPStatusError) -> str:
    code = exc.response.status_code
    detail = _ERROR_MESSAGES.get(code)
    if detail:
        return f"[오류 {code}] {detail}"
    return f"[오류 {code}] {exc.response.text[:300]}"


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _fmt_dt(iso: str | None) -> str:
    if not iso:
        return ""
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return iso


def _fmt_user_detail(user: dict[str, Any]) -> list[str]:
    """Format user data into display lines."""
    user_id = user.get("id", "?")
    nickname = user.get("nickname") or user.get("name", "")
    email = user.get("email", "")
    department = user.get("department") or user.get("departmentName", "")
    position = user.get("position") or user.get("positionName", "")
    phone = user.get("phone") or user.get("phoneNumber", "")
    status = user.get("status") or user.get("statusMessage", "")
    avatar = user.get("avatarUrl") or user.get("profileImageUrl", "")
    created = _fmt_dt(user.get("createdAt"))

    lines = [f"ID: {user_id}"]
    if nickname:
        lines.append(f"이름: {nickname}")
    if email:
        lines.append(f"이메일: {email}")
    if department:
        lines.append(f"부서: {department}")
    if position:
        lines.append(f"직위: {position}")
    if phone:
        lines.append(f"전화: {phone}")
    if status:
        lines.append(f"상태: {status}")
    if avatar:
        lines.append(f"프로필 이미지: {avatar}")
    if created:
        lines.append(f"가입일: {created}")
    return lines


def _fmt_user_summary(user: dict[str, Any]) -> str:
    """Format a single user as a one-line summary for search results."""
    user_id = user.get("id", "?")
    nickname = user.get("nickname") or user.get("name", "")
    email = user.get("email", "")
    department = user.get("department") or user.get("departmentName", "")
    parts = [f"[{user_id}] {nickname}"]
    if department:
        parts.append(f"({department})")
    if email:
        parts.append(f"<{email}>")
    return "  " + " ".join(parts)


# ---------------------------------------------------------------------------
# 6-7-1: user-me
# ---------------------------------------------------------------------------

async def user_me(client: Any) -> str:
    """GET /api/v2/users/me

    Retrieve the current user's profile.
    """
    try:
        data = await client.get("/api/v2/users/me")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    lines = ["=== 내 프로필 ==="]
    lines.extend(_fmt_user_detail(data))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-7-2: user-search
# ---------------------------------------------------------------------------

async def user_search(client: Any, query: str) -> str:
    """GET /api/v2/users/search

    Search users by name, email, or department.
    """
    try:
        data = await client.get("/api/v2/users/search", params={"query": query})
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    users: list[dict[str, Any]] = data if isinstance(data, list) else data.get("users", data)
    if not isinstance(users, list):
        users = []

    lines = [f'=== 사용자 검색 결과 (query="{query}") ===']
    if not users:
        lines.append("검색 결과가 없습니다.")
    else:
        for user in users:
            lines.append(_fmt_user_summary(user))

    lines.append(f"--- 총 {len(users)}건 ---")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-7-3: user-info
# ---------------------------------------------------------------------------

async def user_info(client: Any, user_id: str) -> str:
    """GET /api/v2/users/public/{user_id}

    Retrieve another user's public profile.
    """
    try:
        data = await client.get(f"/api/v2/users/public/{user_id}")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    lines = [f"=== 사용자 정보 ({user_id}) ==="]
    lines.extend(_fmt_user_detail(data))
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

USER_COMMANDS: dict[str, dict[str, Any]] = {
    "me": {
        "fn": user_me,
        "help": "내 프로필 조회",
        "args": [],
    },
    "search": {
        "fn": user_search,
        "help": "사용자 검색",
        "args": [
            {"name": "--query", "required": True, "help": "검색어 (이름, 이메일, 부서)"},
        ],
    },
    "info": {
        "fn": user_info,
        "help": "사용자 공개 프로필 조회",
        "args": [
            {"name": "--user-id", "required": True, "help": "사용자 ID"},
        ],
    },
}


async def dispatch_user_command(client: Any, command: str, args: dict[str, Any]) -> str:
    """Dispatch a user subcommand by name."""
    spec = USER_COMMANDS.get(command)
    if spec is None:
        return f"[오류] 알 수 없는 user 명령: {command}"
    fn = spec["fn"]
    return await fn(client, **args)
