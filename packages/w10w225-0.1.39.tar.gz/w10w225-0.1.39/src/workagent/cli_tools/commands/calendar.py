"""Calendar domain CLI commands for the nk304 API.

Read commands (list, get) call the nk304 calendar API.
Write commands (create, update, delete) output ACTION_PROPOSAL markers
for the ChatPipeline approval flow.
"""
from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import httpx

# ---------------------------------------------------------------------------
# Error handling helpers
# ---------------------------------------------------------------------------

_ERROR_MESSAGES: dict[int, str] = {
    403: "접근 권한이 없습니다",
    404: "일정을 찾을 수 없습니다",
}


def _handle_http_error(exc: httpx.HTTPStatusError) -> str:
    code = exc.response.status_code
    detail = _ERROR_MESSAGES.get(code)
    if detail:
        return f"[오류 {code}] {detail}"
    return f"[오류 {code}] {exc.response.text[:300]}"


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _fmt_dt(iso: str | None, *, timezone: str | None = None) -> str:
    if not iso:
        return ""
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        if timezone:
            try:
                dt = dt.astimezone(ZoneInfo(timezone))
            except ZoneInfoNotFoundError:
                pass
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return iso


def _pick(payload: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in payload:
            return payload[key]
    return None


def _fmt_event_summary(event: dict[str, Any]) -> str:
    event_id = _pick(event, "id") or "?"
    title = _pick(event, "title") or "(제목 없음)"
    timezone = _pick(event, "timezone")
    start = _fmt_dt(_pick(event, "startAt", "start_at"), timezone=timezone)
    end = _fmt_dt(_pick(event, "endAt", "end_at"), timezone=timezone)
    all_day = " [종일]" if bool(_pick(event, "allDay", "all_day")) else ""
    color_value = _pick(event, "color")
    color = f" ({color_value})" if color_value else ""
    return f"  [{event_id}] {title}{all_day} {start} ~ {end}{color}"


# ---------------------------------------------------------------------------
# ACTION_PROPOSAL helper
# ---------------------------------------------------------------------------

def _format_write_proposal(kind: str, payload: dict[str, Any], reason: str) -> str:
    payload_json = json.dumps(payload, ensure_ascii=False)
    return (
        f"---ACTION_PROPOSAL---\n"
        f"kind: {kind}\n"
        f"target: {{}}\n"
        f"payload: {payload_json}\n"
        f"content: |\n"
        f"  {payload_json}\n"
        f"reason: {reason}\n"
        f"---END_ACTION_PROPOSAL---"
    )


# ---------------------------------------------------------------------------
# calendar list
# ---------------------------------------------------------------------------

async def calendar_list(client: Any, start: str, end: str) -> str:
    """GET /api/v2/calendar/events

    List calendar events within a date range.
    """
    try:
        data = await client.get("/api/v2/calendar/events", params={"start": start, "end": end})
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    events: list[dict[str, Any]] = data if isinstance(data, list) else data.get("items", [])
    if not isinstance(events, list):
        events = []

    lines = [f"=== 캘린더 일정 ({start} ~ {end}) ==="]
    if not events:
        lines.append("일정이 없습니다.")
    else:
        for event in events:
            lines.append(_fmt_event_summary(event))

    lines.append(f"--- 총 {len(events)}건 ---")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# calendar get
# ---------------------------------------------------------------------------

async def calendar_get(client: Any, event_id: str) -> str:
    """GET /api/v2/calendar/events/{event_id}

    Retrieve a single calendar event.
    """
    try:
        data = await client.get(f"/api/v2/calendar/events/{event_id}")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    title = _pick(data, "title") or "(제목 없음)"
    description = _pick(data, "description") or ""
    timezone = _pick(data, "timezone") or "UTC"
    start = _fmt_dt(_pick(data, "startAt", "start_at"), timezone=timezone)
    end = _fmt_dt(_pick(data, "endAt", "end_at"), timezone=timezone)
    all_day = "예" if bool(_pick(data, "allDay", "all_day")) else "아니오"
    color = _pick(data, "color") or ""
    created = _fmt_dt(_pick(data, "createdAt", "created_at"), timezone=timezone)
    updated = _fmt_dt(_pick(data, "updatedAt", "updated_at"), timezone=timezone)

    lines = [
        f"=== 일정 상세 ({event_id}) ===",
        f"제목: {title}",
        f"시작: {start}",
        f"종료: {end}",
        f"종일: {all_day}",
        f"시간대: {timezone}",
    ]
    if color:
        lines.append(f"색상: {color}")
    lines.append(f"생성일: {created}")
    if updated and updated != created:
        lines.append(f"수정일: {updated}")
    if description:
        lines.append(f"\n{description}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# calendar create (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def calendar_create(
    title: str,
    start_at: str,
    end_at: str,
    description: str | None = None,
    all_day: bool = False,
    timezone: str = "UTC",
    color: str | None = None,
) -> str:
    payload: dict[str, Any] = {
        "title": title,
        "startAt": start_at,
        "endAt": end_at,
        "allDay": all_day,
        "timezone": timezone,
    }
    if description:
        payload["description"] = description
    if color:
        payload["color"] = color
    return _format_write_proposal(
        kind="nk304_calendar_create",
        payload=payload,
        reason=f"일정 생성: {title}",
    )


# ---------------------------------------------------------------------------
# calendar update (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def calendar_update(
    event_id: str,
    title: str | None = None,
    start_at: str | None = None,
    end_at: str | None = None,
    description: str | None = None,
    all_day: bool | None = None,
    timezone: str | None = None,
    color: str | None = None,
) -> str:
    payload: dict[str, Any] = {"eventId": event_id}
    if title is not None:
        payload["title"] = title
    if start_at is not None:
        payload["startAt"] = start_at
    if end_at is not None:
        payload["endAt"] = end_at
    if description is not None:
        payload["description"] = description
    if all_day is not None:
        payload["allDay"] = all_day
    if timezone is not None:
        payload["timezone"] = timezone
    if color is not None:
        payload["color"] = color
    return _format_write_proposal(
        kind="nk304_calendar_update",
        payload=payload,
        reason=f"일정 수정: {event_id}",
    )


# ---------------------------------------------------------------------------
# calendar delete (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def calendar_delete(event_id: str) -> str:
    return _format_write_proposal(
        kind="nk304_calendar_delete",
        payload={"eventId": event_id},
        reason=f"일정 삭제: {event_id}",
    )


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

_WRITE_COMMANDS = {"create", "update", "delete"}

CALENDAR_COMMANDS: dict[str, dict[str, Any]] = {
    "list": {
        "fn": calendar_list,
        "help": "일정 목록 조회 (기간 지정)",
        "args": [
            {"name": "--start", "required": True, "help": "조회 시작일 (ISO 8601, 예: 2026-04-01T00:00:00)"},
            {"name": "--end", "required": True, "help": "조회 종료일 (ISO 8601, 예: 2026-04-30T23:59:59)"},
        ],
    },
    "get": {
        "fn": calendar_get,
        "help": "일정 상세 조회",
        "args": [
            {"name": "--event-id", "required": True, "help": "일정 ID"},
        ],
    },
    "create": {
        "fn": calendar_create,
        "help": "일정 생성 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--title", "required": True, "help": "일정 제목"},
            {"name": "--start-at", "required": True, "help": "시작 시간 (ISO 8601)"},
            {"name": "--end-at", "required": True, "help": "종료 시간 (ISO 8601)"},
            {"name": "--description", "help": "일정 설명"},
            {"name": "--all-day", "type": bool, "default": False, "help": "종일 여부"},
            {"name": "--timezone", "default": "UTC", "help": "시간대 (기본 UTC)"},
            {"name": "--color", "help": "색상"},
        ],
    },
    "update": {
        "fn": calendar_update,
        "help": "일정 수정 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--event-id", "required": True, "help": "일정 ID"},
            {"name": "--title", "help": "일정 제목"},
            {"name": "--start-at", "help": "시작 시간 (ISO 8601)"},
            {"name": "--end-at", "help": "종료 시간 (ISO 8601)"},
            {"name": "--description", "help": "일정 설명"},
            {"name": "--all-day", "type": bool, "help": "종일 여부"},
            {"name": "--timezone", "help": "시간대"},
            {"name": "--color", "help": "색상"},
        ],
    },
    "delete": {
        "fn": calendar_delete,
        "help": "일정 삭제 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--event-id", "required": True, "help": "일정 ID"},
        ],
    },
}


async def dispatch_calendar_command(client: Any, command: str, args: dict[str, Any]) -> str:
    spec = CALENDAR_COMMANDS.get(command)
    if spec is None:
        return f"[오류] 알 수 없는 calendar 명령: {command}"
    fn = spec["fn"]
    if command in _WRITE_COMMANDS:
        return fn(**args)
    return await fn(client, **args)
