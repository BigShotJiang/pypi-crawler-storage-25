"""Memo domain CLI commands for the nk304 API.

Each async function accepts an ``Nk304ApiClient`` instance and returns
a human-readable string (designed for LLM consumption) that will be
printed to stdout by the CLI entry point.

Write commands (create, update, delete) output ACTION_PROPOSAL markers
so the ChatPipeline can route them through the standard write_draft
approval flow (action_parser -> transport.create_write_draft -> user
approval -> ActionExecutor).

WBS 6-4-1 .. 6-4-5
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any

import httpx


# ---------------------------------------------------------------------------
# Error handling helpers
# ---------------------------------------------------------------------------

_ERROR_MESSAGES: dict[int, str] = {
    403: "접근 권한이 없습니다",
    404: "메모를 찾을 수 없습니다",
}


def _handle_http_error(exc: httpx.HTTPStatusError) -> str:
    code = exc.response.status_code
    detail = _ERROR_MESSAGES.get(code)
    if detail:
        return f"[오류 {code}] {detail}"
    return f"[오류 {code}] {exc.response.text[:300]}"


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _fmt_dt(iso: str | None) -> str:
    if not iso:
        return ""
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return iso


def _fmt_memo_summary(memo: dict[str, Any]) -> str:
    """Format a single memo as a one-line summary."""
    memo_id = memo.get("id", "?")
    title = memo.get("title", "(제목 없음)")
    updated = _fmt_dt(memo.get("updatedAt") or memo.get("createdAt"))
    content = memo.get("body", "")
    preview = content[:60] + "..." if len(content) > 60 else content
    preview = preview.replace("\n", " ")
    return f"  [{memo_id}] {title} ({updated}) {preview}"


# ---------------------------------------------------------------------------
# ACTION_PROPOSAL helper (replaces old _write_draft HTTP call)
# ---------------------------------------------------------------------------

def _format_write_proposal(kind: str, payload: dict[str, Any], reason: str) -> str:
    """Return an ACTION_PROPOSAL block for the ChatPipeline to parse.

    The ChatPipeline's ``action_parser.parse()`` will detect the markers,
    extract kind/target/content/payload/reason, and call
    ``transport.create_write_draft()`` which uses the proper HMAC/session
    transport -- bypassing the JWT auth limitation of direct API calls.
    """
    payload_json = json.dumps(payload, ensure_ascii=False)
    return (
        f"---ACTION_PROPOSAL---\n"
        f"kind: {kind}\n"
        f"target: {{}}\n"
        f"payload: {payload_json}\n"
        f"content: |\n"
        f"  {payload_json}\n"
        f"reason: {reason}\n"
        f"---END_ACTION_PROPOSAL---"
    )


# ---------------------------------------------------------------------------
# 6-4-1: memo-list
# ---------------------------------------------------------------------------

async def memo_list(client: Any, limit: int = 20) -> str:
    """GET /api/v2/memos

    List memos for the current user.
    """
    try:
        data = await client.get("/api/v2/memos", params={"limit": limit})
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    memos: list[dict[str, Any]] = data if isinstance(data, list) else data.get("items", [])
    if not isinstance(memos, list):
        memos = []

    lines = ["=== 메모 목록 ==="]
    if not memos:
        lines.append("메모가 없습니다.")
    else:
        for memo in memos:
            lines.append(_fmt_memo_summary(memo))

    lines.append(f"--- 총 {len(memos)}건 ---")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-4-2: memo-get
# ---------------------------------------------------------------------------

async def memo_get(client: Any, memo_id: str) -> str:
    """GET /api/v2/memos/{memo_id}

    Retrieve a single memo with full content.
    """
    try:
        data = await client.get(f"/api/v2/memos/{memo_id}")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    title = data.get("title", "(제목 없음)")
    content = data.get("body", "")
    created = _fmt_dt(data.get("createdAt"))
    updated = _fmt_dt(data.get("updatedAt"))
    author = (
        data.get("authorName")
        or (data.get("author") or {}).get("nickname", "")
    )

    lines = [
        f"=== 메모 상세 ({memo_id}) ===",
        f"제목: {title}",
    ]
    if author:
        lines.append(f"작성자: {author}")
    lines.append(f"생성일: {created}")
    if updated and updated != created:
        lines.append(f"수정일: {updated}")
    lines.append(f"\n{content}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-4-3: memo-create (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def memo_create(title: str, content: str) -> str:
    """Output an ACTION_PROPOSAL for memo creation.

    The ChatPipeline will parse the markers and route through the
    write_draft approval flow.
    """
    return _format_write_proposal(
        kind="nk304_memo_create",
        payload={"title": title, "body": content},
        reason=f"메모 생성: {title}",
    )


# ---------------------------------------------------------------------------
# 6-4-4: memo-update (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def memo_update(memo_id: str, title: str, content: str) -> str:
    """Output an ACTION_PROPOSAL for memo update."""
    return _format_write_proposal(
        kind="nk304_memo_update",
        payload={"memoId": memo_id, "title": title, "body": content},
        reason=f"메모 수정: {memo_id} - {title}",
    )


# ---------------------------------------------------------------------------
# 6-4-5: memo-delete (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def memo_delete(memo_id: str) -> str:
    """Output an ACTION_PROPOSAL for memo deletion."""
    return _format_write_proposal(
        kind="nk304_memo_delete",
        payload={"memoId": memo_id},
        reason=f"메모 삭제: {memo_id}",
    )


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Which commands need an API client (read) vs. pure output (write)
# ---------------------------------------------------------------------------

_WRITE_COMMANDS = {"create", "update", "delete"}

MEMO_COMMANDS: dict[str, dict[str, Any]] = {
    "list": {
        "fn": memo_list,
        "help": "메모 목록 조회",
        "args": [
            {"name": "--limit", "type": int, "default": 20, "help": "조회 건수 (기본 20)"},
        ],
    },
    "get": {
        "fn": memo_get,
        "help": "메모 상세 조회",
        "args": [
            {"name": "--memo-id", "required": True, "help": "메모 ID"},
        ],
    },
    "create": {
        "fn": memo_create,
        "help": "메모 생성 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--title", "required": True, "help": "메모 제목"},
            {"name": "--content", "required": True, "help": "메모 내용"},
        ],
    },
    "update": {
        "fn": memo_update,
        "help": "메모 수정 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--memo-id", "required": True, "help": "메모 ID"},
            {"name": "--title", "required": True, "help": "메모 제목"},
            {"name": "--content", "required": True, "help": "메모 내용"},
        ],
    },
    "delete": {
        "fn": memo_delete,
        "help": "메모 삭제 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--memo-id", "required": True, "help": "메모 ID"},
        ],
    },
}


async def dispatch_memo_command(client: Any, command: str, args: dict[str, Any]) -> str:
    """Dispatch a memo subcommand by name.

    Read commands (list, get) are async and require the API client.
    Write commands (create, update, delete) are sync and return
    ACTION_PROPOSAL text -- no client needed.
    """
    spec = MEMO_COMMANDS.get(command)
    if spec is None:
        return f"[오류] 알 수 없는 memo 명령: {command}"
    fn = spec["fn"]
    if command in _WRITE_COMMANDS:
        return fn(**args)
    return await fn(client, **args)
