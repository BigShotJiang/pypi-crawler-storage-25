"""Notification domain CLI commands for the nk304 API.

Each async function accepts an ``Nk304ApiClient`` instance and returns
a human-readable string (designed for LLM consumption) that will be
printed to stdout by the CLI entry point.

WBS 6-8-1 .. 6-8-2
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

import httpx


# ---------------------------------------------------------------------------
# Error handling helpers
# ---------------------------------------------------------------------------

_ERROR_MESSAGES: dict[int, str] = {
    403: "접근 권한이 없습니다",
    404: "알림을 찾을 수 없습니다",
}


def _handle_http_error(exc: httpx.HTTPStatusError) -> str:
    code = exc.response.status_code
    detail = _ERROR_MESSAGES.get(code)
    if detail:
        return f"[오류 {code}] {detail}"
    return f"[오류 {code}] {exc.response.text[:300]}"


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _fmt_dt(iso: str | None) -> str:
    if not iso:
        return ""
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return iso


def _notification_type_label(ntype: str) -> str:
    labels = {
        "mention": "멘션",
        "reply": "답글",
        "ticket": "티켓",
        "memo": "메모",
        "system": "시스템",
        "chat": "채팅",
    }
    return labels.get(ntype, ntype)


def _fmt_notification(n: dict[str, Any]) -> str:
    """Format a single notification for display."""
    ntype = _notification_type_label(n.get("type") or n.get("notificationType", ""))
    title = n.get("title", "")
    body = n.get("body") or n.get("message") or n.get("content", "")
    ts = _fmt_dt(n.get("createdAt"))
    is_read = n.get("isRead") or n.get("read", False)
    read_marker = "" if is_read else " [NEW]"
    sender = (
        n.get("senderName")
        or (n.get("sender") or {}).get("nickname", "")
    )
    sender_part = f" from {sender}" if sender else ""

    parts = [f"  [{ntype}]{read_marker}"]
    if title:
        parts.append(title)
    if body:
        preview = body[:80] + "..." if len(body) > 80 else body
        preview = preview.replace("\n", " ")
        parts.append(f"- {preview}")
    parts.append(f"({ts}{sender_part})")
    return " ".join(parts)


# ---------------------------------------------------------------------------
# 6-8-1: notification-list
# ---------------------------------------------------------------------------

async def notification_list(client: Any, limit: int = 20) -> str:
    """GET /api/v2/notifications

    List recent notifications for the current user.
    """
    try:
        data = await client.get("/api/v2/notifications", params={"limit": limit})
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    notifications: list[dict[str, Any]] = (
        data if isinstance(data, list) else data.get("notifications", data)
    )
    if not isinstance(notifications, list):
        notifications = []

    lines = ["=== 알림 목록 ==="]
    if not notifications:
        lines.append("알림이 없습니다.")
    else:
        for n in notifications:
            lines.append(_fmt_notification(n))

    lines.append(f"--- 총 {len(notifications)}건 ---")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-8-2: notification-unread-count
# ---------------------------------------------------------------------------

async def notification_unread_count(client: Any) -> str:
    """GET /api/v2/notifications/unread-count

    Retrieve the count of unread notifications.
    """
    try:
        data = await client.get("/api/v2/notifications/unread-count")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    count = data.get("count") or data.get("unreadCount", 0)
    return f"=== 읽지 않은 알림 ===\n개수: {count}"


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

NOTIFICATION_COMMANDS: dict[str, dict[str, Any]] = {
    "list": {
        "fn": notification_list,
        "help": "알림 목록 조회",
        "args": [
            {"name": "--limit", "type": int, "default": 20, "help": "조회 건수 (기본 20)"},
        ],
    },
    "unread-count": {
        "fn": notification_unread_count,
        "help": "읽지 않은 알림 수 조회",
        "args": [],
    },
}


async def dispatch_notification_command(client: Any, command: str, args: dict[str, Any]) -> str:
    """Dispatch a notification subcommand by name."""
    spec = NOTIFICATION_COMMANDS.get(command)
    if spec is None:
        return f"[오류] 알 수 없는 notification 명령: {command}"
    fn = spec["fn"]
    return await fn(client, **args)
