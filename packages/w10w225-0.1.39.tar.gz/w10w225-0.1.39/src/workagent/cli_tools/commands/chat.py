"""Chat domain CLI commands for the nk304 open-chat API.

Each async function accepts an ``Nk304ApiClient`` instance and returns
a human-readable string (designed for LLM consumption) that will be
printed to stdout by the CLI entry point.

Write commands (send, edit, delete, reply, wiki-set, wiki-create,
wiki-edit, wiki-delete, notice-create, notice-update, notice-delete)
output ACTION_PROPOSAL markers so the ChatPipeline can route them through
the standard write_draft approval flow (action_parser -> transport.create_write_draft
-> user approval -> ActionExecutor).

WBS 6-3-1 .. 6-3-8
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any

import httpx


# ---------------------------------------------------------------------------
# Error handling helpers
# ---------------------------------------------------------------------------

_ERROR_MESSAGES: dict[int, str] = {
    403: "접근 권한이 없습니다",
    404: "리소스를 찾을 수 없습니다",
}


def _handle_http_error(exc: httpx.HTTPStatusError) -> str:
    """Convert an httpx status error into a localised message."""
    code = exc.response.status_code
    detail = _ERROR_MESSAGES.get(code)
    if detail:
        return f"[오류 {code}] {detail}"
    return f"[오류 {code}] {exc.response.text[:300]}"


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _fmt_dt(iso: str | None) -> str:
    """Format an ISO-8601 datetime string to ``YYYY-MM-DD HH:MM``."""
    if not iso:
        return ""
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return iso


def _fmt_message(msg: dict[str, Any]) -> str:
    """Format a single chat message for display.

    Output: ``[sender_name] (YYYY-MM-DD HH:MM) content``
    """
    sender = (
        msg.get("senderName")
        or (msg.get("senderUser") or {}).get("nickname")
        or msg.get("senderType", "?")
    )
    ts = _fmt_dt(msg.get("createdAt"))
    content = msg.get("content", "")
    reply_count = msg.get("replyCount")
    suffix = f"  [답글 {reply_count}개]" if reply_count else ""
    return f"[{sender}] ({ts}) {content}{suffix}"


def _safe_get(d: dict[str, Any], *keys: str, default: Any = "") -> Any:
    """Nested dict access with a default value."""
    current: Any = d
    for k in keys:
        if isinstance(current, dict):
            current = current.get(k, default)
        else:
            return default
    return current


def _room_type_label(room: dict[str, Any]) -> str:
    visibility = room.get("visibility", "")
    room_type = room.get("roomType", "")
    parts: list[str] = []
    if visibility:
        parts.append(visibility)
    if room_type:
        parts.append(room_type)
    return "/".join(parts) if parts else "unknown"


def _member_role_label(member: dict[str, Any]) -> str:
    role = member.get("role", "member")
    labels = {"owner": "방장", "moderator": "관리자", "member": "멤버"}
    return labels.get(role, role)


# ---------------------------------------------------------------------------
# 6-3-1: chat-room-info
# ---------------------------------------------------------------------------

async def chat_room_info(client: Any, room_id: str) -> str:
    """GET /api/v2/open-chat/rooms/{room_id}

    Retrieve and format room metadata.
    """
    try:
        data = await client.get(f"/api/v2/open-chat/rooms/{room_id}")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    name = data.get("name", "")
    description = data.get("description", "")
    member_count = data.get("memberCount") or _safe_get(data, "_count", "members", default="?")
    type_label = _room_type_label(data)
    topic = data.get("topic", "")
    tags = ", ".join(data.get("tags", []))
    created = _fmt_dt(data.get("createdAt"))
    locked = "잠금" if data.get("isLocked") else "공개"

    lines = [
        f"=== 채팅방 정보 ({room_id}) ===",
        f"이름: {name}",
    ]
    if description:
        lines.append(f"설명: {description}")
    lines.append(f"유형: {type_label}")
    lines.append(f"상태: {locked}")
    if topic:
        lines.append(f"주제: {topic}")
    if tags:
        lines.append(f"태그: {tags}")
    lines.append(f"멤버 수: {member_count}")
    lines.append(f"생성일: {created}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-3-2: chat-messages
# ---------------------------------------------------------------------------

async def chat_messages(
    client: Any,
    room_id: str,
    limit: int = 50,
    before: str | None = None,
) -> str:
    """GET /api/v2/open-chat/rooms/{room_id}/messages

    Retrieve recent messages in a room.
    """
    params: dict[str, Any] = {"limit": limit}
    if before:
        params["before"] = before

    try:
        data = await client.get(
            f"/api/v2/open-chat/rooms/{room_id}/messages",
            params=params,
        )
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    # data is a list of OpenChatMessage dicts
    messages: list[dict[str, Any]] = data if isinstance(data, list) else data.get("messages", data)
    if not isinstance(messages, list):
        messages = []

    lines = [f"=== 채팅방 메시지 ({room_id}) ==="]
    for msg in messages:
        lines.append(_fmt_message(msg))

    count = len(messages)
    if count > 0 and count >= limit:
        oldest_ts = messages[-1].get("createdAt", "")
        lines.append(
            f'--- {count}건 표시 / --before "{oldest_ts}" 으로 이전 메시지 조회 가능 ---'
        )
    else:
        lines.append(f"--- {count}건 표시 ---")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-3-3: chat-search
# ---------------------------------------------------------------------------

async def chat_search(
    client: Any,
    room_id: str,
    query: str,
    sender: str | None = None,
    after: str | None = None,
    before: str | None = None,
) -> str:
    """GET /api/v2/open-chat/search

    Search messages across rooms (or within a specific room).
    """
    params: dict[str, Any] = {"query": query, "roomId": room_id}
    if sender:
        params["senderId"] = sender
    if after:
        params["after"] = after
    if before:
        params["before"] = before

    try:
        data = await client.get("/api/v2/open-chat/search", params=params)
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    messages: list[dict[str, Any]] = data.get("messages", []) if isinstance(data, dict) else []
    total = data.get("total", len(messages)) if isinstance(data, dict) else len(messages)
    has_more = data.get("hasMore", False) if isinstance(data, dict) else False
    next_cursor = data.get("nextCursor") if isinstance(data, dict) else None

    lines = [f'=== 메시지 검색 결과 (query="{query}", room={room_id}) ===']
    for msg in messages:
        lines.append(_fmt_message(msg))

    footer_parts = [f"{len(messages)}건 표시"]
    if total is not None:
        footer_parts.append(f"전체 {total}건")
    if has_more and next_cursor:
        footer_parts.append(f'--cursor "{next_cursor}" 으로 다음 페이지 조회 가능')
    lines.append(f"--- {' / '.join(footer_parts)} ---")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-3-4: chat-thread
# ---------------------------------------------------------------------------

async def chat_thread(
    client: Any,
    message_id: str,
    limit: int = 50,
) -> str:
    """GET /api/v2/open-chat/messages/{message_id}/replies

    Retrieve thread replies for a message.
    """
    params: dict[str, Any] = {"limit": limit}

    try:
        data = await client.get(
            f"/api/v2/open-chat/messages/{message_id}/replies",
            params=params,
        )
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    messages: list[dict[str, Any]] = data if isinstance(data, list) else data.get("messages", data)
    if not isinstance(messages, list):
        messages = []

    lines = [f"=== 스레드 답글 (parent={message_id}) ==="]
    for msg in messages:
        lines.append(_fmt_message(msg))

    count = len(messages)
    lines.append(f"--- {count}건 표시 ---")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-3-5: chat-members
# ---------------------------------------------------------------------------

async def chat_members(client: Any, room_id: str) -> str:
    """GET /api/v2/open-chat/rooms/{room_id}/members

    Retrieve member list for a room.
    """
    try:
        data = await client.get(f"/api/v2/open-chat/rooms/{room_id}/members")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    members: list[dict[str, Any]] = data if isinstance(data, list) else data.get("members", data)
    if not isinstance(members, list):
        members = []

    lines = [f"=== 채팅방 멤버 ({room_id}) ==="]
    for m in members:
        name = (
            m.get("memberName")
            or m.get("profileName")
            or _safe_get(m, "memberUser", "nickname", default="?")
        )
        role = _member_role_label(m)
        joined = _fmt_dt(m.get("joinedAt"))
        active = "활성" if m.get("isActive") else "비활성"
        lines.append(f"  {name} ({role}, {active}, 참여: {joined})")

    lines.append(f"--- 총 {len(members)}명 ---")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-3-6: chat-summary
# ---------------------------------------------------------------------------

async def chat_summary(client: Any, room_id: str) -> str:
    """GET /api/v2/open-chat/rooms/{room_id}/summary

    Retrieve AI-generated room summary.
    """
    try:
        data = await client.get(f"/api/v2/open-chat/rooms/{room_id}/summary")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    available = data.get("available", False) if isinstance(data, dict) else False
    if not available:
        return f"=== 채팅방 요약 ({room_id}) ===\n요약이 아직 생성되지 않았습니다."

    summary = data.get("summary") or {}
    created = _fmt_dt(data.get("createdAt"))

    lines = [f"=== 채팅방 요약 ({room_id}) ==="]
    if created:
        lines.append(f"생성일: {created}")

    # The summary object has locale keys: en, ko, ja, zhTw
    for lang, label in [("ko", "한국어"), ("en", "English"), ("ja", "日本語"), ("zhTw", "繁體中文")]:
        text = summary.get(lang, "")
        if text:
            lines.append(f"\n[{label}]")
            lines.append(text)

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-3-7: chat-pins
# ---------------------------------------------------------------------------

async def chat_pins(client: Any, room_id: str) -> str:
    """GET /api/v2/open-chat/rooms/{room_id}/pins

    Retrieve pinned messages in a room.
    """
    try:
        data = await client.get(f"/api/v2/open-chat/rooms/{room_id}/pins")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    pins: list[dict[str, Any]] = data if isinstance(data, list) else data.get("pins", data)
    if not isinstance(pins, list):
        pins = []

    lines = [f"=== 고정 메시지 ({room_id}) ==="]
    if not pins:
        lines.append("고정된 메시지가 없습니다.")
    else:
        for pin in pins:
            pinned_at = _fmt_dt(pin.get("pinnedAt"))
            pinned_by = _safe_get(pin, "pinnedByUser", "nickname", default="?")
            msg = pin.get("message", {})
            msg_text = _fmt_message(msg) if msg else "(메시지 없음)"
            lines.append(f"  [고정: {pinned_by}, {pinned_at}] {msg_text}")

    lines.append(f"--- 총 {len(pins)}건 ---")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-3-8: chat-my-rooms
# ---------------------------------------------------------------------------

async def chat_my_rooms(client: Any) -> str:
    """GET /api/v2/open-chat/rooms/my

    List rooms the current user has joined.
    """
    try:
        data = await client.get("/api/v2/open-chat/rooms/my")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    rooms: list[dict[str, Any]] = data if isinstance(data, list) else data.get("rooms", data)
    if not isinstance(rooms, list):
        rooms = []

    lines = ["=== 내 채팅방 목록 ==="]
    if not rooms:
        lines.append("참여 중인 채팅방이 없습니다.")
    else:
        for room in rooms:
            rid = room.get("id", "?")
            name = room.get("name", "")
            type_label = _room_type_label(room)
            member_count = room.get("memberCount") or _safe_get(room, "_count", "members", default="?")
            last_msg = room.get("lastMessage")
            last_preview = ""
            if isinstance(last_msg, dict):
                sender = (
                    last_msg.get("senderName")
                    or _safe_get(last_msg, "senderUser", "nickname", default="")
                )
                content = last_msg.get("content", "")
                # Truncate long messages
                if len(content) > 40:
                    content = content[:40] + "..."
                ts = _fmt_dt(last_msg.get("createdAt"))
                last_preview = f"  최근: [{sender}] ({ts}) {content}"

            lines.append(f"  [{rid}] {name} ({type_label}, 멤버 {member_count}명)")
            if last_preview:
                lines.append(f"  {last_preview}")

    lines.append(f"--- 총 {len(rooms)}개 ---")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# ACTION_PROPOSAL helper (replaces old _write_draft HTTP call)
# ---------------------------------------------------------------------------

def _format_write_proposal(kind: str, payload: dict[str, Any], reason: str) -> str:
    """Return an ACTION_PROPOSAL block for the ChatPipeline to parse.

    The ChatPipeline's ``action_parser.parse()`` will detect the markers,
    extract kind/target/content/payload/reason, and call
    ``transport.create_write_draft()`` which uses the proper HMAC/session
    transport -- bypassing the JWT auth limitation of direct API calls.
    """
    payload_json = json.dumps(payload, ensure_ascii=False)
    return (
        f"---ACTION_PROPOSAL---\n"
        f"kind: {kind}\n"
        f"target: {{}}\n"
        f"payload: {payload_json}\n"
        f"content: |\n"
        f"  {payload_json}\n"
        f"reason: {reason}\n"
        f"---END_ACTION_PROPOSAL---"
    )


# ---------------------------------------------------------------------------
# 6-3-9: chat-wiki (read)
# ---------------------------------------------------------------------------

async def chat_wiki(client: Any, room_id: str) -> str:
    """GET /api/v2/open-chat/rooms/{room_id}/wiki-notice

    Retrieve wiki and notices for a room.
    """
    try:
        data = await client.get(f"/api/v2/open-chat/rooms/{room_id}/wiki-notice")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    lines = [f"=== 채팅방 위키/공지 ({room_id}) ==="]

    # Wiki section
    wiki = data.get("wiki") if isinstance(data, dict) else None
    if isinstance(wiki, dict):
        wiki_id = wiki.get("id", "")
        wiki_title = wiki.get("title", "")
        wiki_content = wiki.get("content", "")
        wiki_updated = _fmt_dt(wiki.get("updatedAt") or wiki.get("createdAt"))
        lines.append(f"\n[위키] (id={wiki_id})")
        if wiki_title:
            lines.append(f"제목: {wiki_title}")
        if wiki_updated:
            lines.append(f"수정일: {wiki_updated}")
        if wiki_content:
            lines.append(f"\n{wiki_content}")
    elif isinstance(wiki, list) and wiki:
        for w in wiki:
            wiki_id = w.get("id", "")
            wiki_title = w.get("title", "")
            wiki_content = w.get("content", "")
            wiki_updated = _fmt_dt(w.get("updatedAt") or w.get("createdAt"))
            lines.append(f"\n[위키] (id={wiki_id})")
            if wiki_title:
                lines.append(f"제목: {wiki_title}")
            if wiki_updated:
                lines.append(f"수정일: {wiki_updated}")
            if wiki_content:
                lines.append(f"\n{wiki_content}")
    else:
        lines.append("\n위키가 없습니다.")

    # Notices section
    notices = data.get("notices", []) if isinstance(data, dict) else []
    if not isinstance(notices, list):
        notices = []
    if notices:
        lines.append(f"\n--- 공지사항 ({len(notices)}건) ---")
        for notice in notices:
            notice_id = notice.get("id", "")
            notice_title = notice.get("title", "")
            notice_content = notice.get("content", "")
            notice_active = "활성" if notice.get("isActive", True) else "비활성"
            notice_updated = _fmt_dt(notice.get("updatedAt") or notice.get("createdAt"))
            lines.append(f"\n  [{notice_id}] {notice_title} ({notice_active}, {notice_updated})")
            if notice_content:
                lines.append(f"  {notice_content}")
    else:
        lines.append("\n공지사항이 없습니다.")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-3-10: chat-send (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def chat_send(room_id: str, content: str) -> str:
    """Output an ACTION_PROPOSAL for sending a chat message."""
    return _format_write_proposal(
        kind="nk304_chat_message",
        payload={"roomId": room_id, "content": content},
        reason=f"채팅방 메시지 전송: {room_id}",
    )


# ---------------------------------------------------------------------------
# 6-3-11: chat-wiki-set (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def chat_wiki_set(room_id: str, content: str, title: str = "Wiki") -> str:
    """Output an ACTION_PROPOSAL for setting/updating room wiki."""
    return _format_write_proposal(
        kind="nk304_wiki_set",
        payload={"roomId": room_id, "title": title, "content": content},
        reason=f"채팅방 위키 설정: {room_id}",
    )


# ---------------------------------------------------------------------------
# 6-3-12: chat-notice-create (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def chat_notice_create(room_id: str, content: str, title: str = "공지") -> str:
    """Output an ACTION_PROPOSAL for creating a room notice."""
    return _format_write_proposal(
        kind="nk304_notice_create",
        payload={"roomId": room_id, "title": title, "content": content},
        reason=f"채팅방 공지 생성: {room_id}",
    )


# ---------------------------------------------------------------------------
# 6-3-13: chat-notice-update (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def chat_notice_update(room_id: str, notice_id: str, content: str, title: str | None = None) -> str:
    """Output an ACTION_PROPOSAL for updating a room notice."""
    payload: dict[str, Any] = {"roomId": room_id, "noticeId": notice_id, "content": content}
    if title:
        payload["title"] = title
    return _format_write_proposal(
        kind="nk304_notice_update",
        payload=payload,
        reason=f"채팅방 공지 수정: {room_id}/{notice_id}",
    )


# ---------------------------------------------------------------------------
# 6-3-14: chat-notice-delete (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def chat_notice_delete(room_id: str, notice_id: str) -> str:
    """Output an ACTION_PROPOSAL for deleting a room notice."""
    return _format_write_proposal(
        kind="nk304_notice_delete",
        payload={"roomId": room_id, "noticeId": notice_id},
        reason=f"채팅방 공지 삭제: {room_id}/{notice_id}",
    )


# ---------------------------------------------------------------------------
# 6-3-15: chat-edit (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def chat_edit(message_id: str, content: str) -> str:
    """Output an ACTION_PROPOSAL for editing a chat message."""
    return _format_write_proposal(
        kind="nk304_chat_edit",
        payload={"messageId": message_id, "content": content},
        reason=f"채팅 메시지 수정: {message_id}",
    )


# ---------------------------------------------------------------------------
# 6-3-16: chat-delete (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def chat_delete(message_id: str) -> str:
    """Output an ACTION_PROPOSAL for deleting a chat message."""
    return _format_write_proposal(
        kind="nk304_chat_delete",
        payload={"messageId": message_id},
        reason=f"채팅 메시지 삭제: {message_id}",
    )


# ---------------------------------------------------------------------------
# 6-3-17: chat-reply (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def chat_reply(message_id: str, room_id: str, content: str) -> str:
    """Output an ACTION_PROPOSAL for replying to a thread."""
    return _format_write_proposal(
        kind="nk304_chat_reply",
        payload={"messageId": message_id, "roomId": room_id, "content": content},
        reason=f"스레드 답글: {room_id}/{message_id}",
    )


# ---------------------------------------------------------------------------
# 6-3-18: chat-wiki-create (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def chat_wiki_create(room_id: str, title: str, content: str) -> str:
    """Output an ACTION_PROPOSAL for creating a room wiki."""
    return _format_write_proposal(
        kind="nk304_wiki_create",
        payload={"roomId": room_id, "title": title, "content": content},
        reason=f"채팅방 위키 생성: {room_id}",
    )


# ---------------------------------------------------------------------------
# 6-3-19: chat-wiki-edit (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def chat_wiki_edit(room_id: str, wiki_id: str, title: str | None = None, content: str | None = None) -> str:
    """Output an ACTION_PROPOSAL for editing a room wiki."""
    payload: dict[str, Any] = {"roomId": room_id, "wikiId": wiki_id}
    if title:
        payload["title"] = title
    if content:
        payload["content"] = content
    return _format_write_proposal(
        kind="nk304_wiki_edit",
        payload=payload,
        reason=f"채팅방 위키 수정: {room_id}/{wiki_id}",
    )


# ---------------------------------------------------------------------------
# 6-3-20: chat-wiki-delete (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def chat_wiki_delete(room_id: str, wiki_id: str) -> str:
    """Output an ACTION_PROPOSAL for deleting a room wiki."""
    return _format_write_proposal(
        kind="nk304_wiki_delete",
        payload={"roomId": room_id, "wikiId": wiki_id},
        reason=f"채팅방 위키 삭제: {room_id}/{wiki_id}",
    )


# ---------------------------------------------------------------------------
# Registry: maps subcommand name -> (function, description)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Which commands need an API client (read) vs. pure output (write)
# ---------------------------------------------------------------------------

_WRITE_COMMANDS = {
    "send", "edit", "delete", "reply",
    "wiki-set", "wiki-create", "wiki-edit", "wiki-delete",
    "notice-create", "notice-update", "notice-delete",
}

CHAT_COMMANDS: dict[str, dict[str, Any]] = {
    "room-info": {
        "fn": chat_room_info,
        "help": "채팅방 상세 정보 조회",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
        ],
    },
    "messages": {
        "fn": chat_messages,
        "help": "채팅방 메시지 조회",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
            {"name": "--limit", "type": int, "default": 50, "help": "조회 건수 (기본 50)"},
            {"name": "--before", "default": None, "help": "이 시각 이전 메시지 조회 (ISO-8601)"},
        ],
    },
    "search": {
        "fn": chat_search,
        "help": "메시지 검색",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
            {"name": "--query", "required": True, "help": "검색어"},
            {"name": "--sender", "default": None, "help": "발신자 ID로 필터"},
            {"name": "--after", "default": None, "help": "이 시각 이후 메시지 (ISO-8601)"},
            {"name": "--before", "default": None, "help": "이 시각 이전 메시지 (ISO-8601)"},
        ],
    },
    "thread": {
        "fn": chat_thread,
        "help": "스레드 답글 조회",
        "args": [
            {"name": "--message-id", "required": True, "help": "부모 메시지 ID"},
            {"name": "--limit", "type": int, "default": 50, "help": "조회 건수 (기본 50)"},
        ],
    },
    "members": {
        "fn": chat_members,
        "help": "채팅방 멤버 목록",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
        ],
    },
    "summary": {
        "fn": chat_summary,
        "help": "채팅방 AI 요약 조회",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
        ],
    },
    "pins": {
        "fn": chat_pins,
        "help": "고정 메시지 목록",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
        ],
    },
    "my-rooms": {
        "fn": chat_my_rooms,
        "help": "내 채팅방 목록",
        "args": [],
    },
    "wiki": {
        "fn": chat_wiki,
        "help": "채팅방 위키/공지 조회",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
        ],
    },
    "send": {
        "fn": chat_send,
        "help": "채팅방 메시지 전송 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
            {"name": "--content", "required": True, "help": "메시지 내용"},
        ],
    },
    "wiki-set": {
        "fn": chat_wiki_set,
        "help": "채팅방 위키 설정/수정 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
            {"name": "--content", "required": True, "help": "위키 내용"},
            {"name": "--title", "default": "Wiki", "help": "위키 제목 (기본: Wiki)"},
        ],
    },
    "notice-create": {
        "fn": chat_notice_create,
        "help": "채팅방 공지 생성 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
            {"name": "--content", "required": True, "help": "공지 내용"},
            {"name": "--title", "default": "공지", "help": "공지 제목 (기본: 공지)"},
        ],
    },
    "notice-update": {
        "fn": chat_notice_update,
        "help": "채팅방 공지 수정 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
            {"name": "--notice-id", "required": True, "help": "공지 ID"},
            {"name": "--content", "required": True, "help": "수정할 공지 내용"},
            {"name": "--title", "default": None, "help": "수정할 공지 제목"},
        ],
    },
    "notice-delete": {
        "fn": chat_notice_delete,
        "help": "채팅방 공지 삭제 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
            {"name": "--notice-id", "required": True, "help": "공지 ID"},
        ],
    },
    "edit": {
        "fn": chat_edit,
        "help": "채팅 메시지 수정 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--message-id", "required": True, "help": "메시지 ID"},
            {"name": "--content", "required": True, "help": "수정할 메시지 내용"},
        ],
    },
    "delete": {
        "fn": chat_delete,
        "help": "채팅 메시지 삭제 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--message-id", "required": True, "help": "메시지 ID"},
        ],
    },
    "reply": {
        "fn": chat_reply,
        "help": "스레드 답글 전송 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--message-id", "required": True, "help": "부모 메시지 ID"},
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
            {"name": "--content", "required": True, "help": "답글 내용"},
        ],
    },
    "wiki-create": {
        "fn": chat_wiki_create,
        "help": "채팅방 위키 생성 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
            {"name": "--title", "required": True, "help": "위키 제목"},
            {"name": "--content", "required": True, "help": "위키 내용"},
        ],
    },
    "wiki-edit": {
        "fn": chat_wiki_edit,
        "help": "채팅방 위키 수정 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
            {"name": "--wiki-id", "required": True, "help": "위키 ID"},
            {"name": "--title", "default": None, "help": "수정할 위키 제목"},
            {"name": "--content", "default": None, "help": "수정할 위키 내용"},
        ],
    },
    "wiki-delete": {
        "fn": chat_wiki_delete,
        "help": "채팅방 위키 삭제 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
            {"name": "--wiki-id", "required": True, "help": "위키 ID"},
        ],
    },
}


async def dispatch_chat_command(client: Any, command: str, args: dict[str, Any]) -> str:
    """Dispatch a chat subcommand by name.

    Read commands (room-info, messages, search, thread, members, summary,
    pins, my-rooms, wiki) are async and require the API client.
    Write commands (send, edit, delete, reply, wiki-set, wiki-create,
    wiki-edit, wiki-delete, notice-create, notice-update,
    notice-delete) are sync and return ACTION_PROPOSAL text -- no client
    needed.

    Parameters
    ----------
    client:
        An ``Nk304ApiClient`` instance.
    command:
        One of the keys in ``CHAT_COMMANDS``.
    args:
        Keyword arguments for the command function (already parsed by argparse).

    Returns
    -------
    str
        Human-readable output.
    """
    spec = CHAT_COMMANDS.get(command)
    if spec is None:
        return f"[오류] 알 수 없는 chat 명령: {command}"
    fn = spec["fn"]
    if command in _WRITE_COMMANDS:
        return fn(**args)
    return await fn(client, **args)
