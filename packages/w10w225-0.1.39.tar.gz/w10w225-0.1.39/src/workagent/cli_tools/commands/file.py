"""File domain CLI commands for the nk304 open-chat API.

Each async function accepts an ``Nk304ApiClient`` instance and returns
a human-readable string (designed for LLM consumption) that will be
printed to stdout by the CLI entry point.

WBS 6-6-1 .. 6-6-2
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

import httpx


# ---------------------------------------------------------------------------
# Error handling helpers
# ---------------------------------------------------------------------------

_ERROR_MESSAGES: dict[int, str] = {
    403: "접근 권한이 없습니다",
    404: "파일을 찾을 수 없습니다",
}


def _handle_http_error(exc: httpx.HTTPStatusError) -> str:
    code = exc.response.status_code
    detail = _ERROR_MESSAGES.get(code)
    if detail:
        return f"[오류 {code}] {detail}"
    return f"[오류 {code}] {exc.response.text[:300]}"


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _fmt_dt(iso: str | None) -> str:
    if not iso:
        return ""
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return iso


def _fmt_file_size(size: int | None) -> str:
    """Format a file size in human-readable form."""
    if size is None:
        return "?"
    if size < 1024:
        return f"{size} B"
    if size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    if size < 1024 * 1024 * 1024:
        return f"{size / (1024 * 1024):.1f} MB"
    return f"{size / (1024 * 1024 * 1024):.1f} GB"


def _fmt_file_entry(f: dict[str, Any]) -> str:
    """Format a single file entry as a one-line summary."""
    file_id = f.get("id", "?")
    name = f.get("name") or f.get("fileName", "(이름 없음)")
    size = _fmt_file_size(f.get("size") or f.get("fileSize"))
    mime = f.get("mimeType") or f.get("contentType", "")
    uploaded = _fmt_dt(f.get("createdAt") or f.get("uploadedAt"))
    return f"  [{file_id}] {name} ({size}, {mime}) {uploaded}"


# ---------------------------------------------------------------------------
# 6-6-1: file-list
# ---------------------------------------------------------------------------

async def file_list(client: Any, limit: int = 20) -> str:
    """GET /api/v2/open-chat/my-files

    List files uploaded by the current user.
    """
    try:
        data = await client.get("/api/v2/open-chat/my-files", params={"limit": limit})
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    files: list[dict[str, Any]] = data if isinstance(data, list) else data.get("files", data)
    if not isinstance(files, list):
        files = []

    lines = ["=== 내 파일 목록 ==="]
    if not files:
        lines.append("파일이 없습니다.")
    else:
        for f in files:
            lines.append(_fmt_file_entry(f))

    lines.append(f"--- 총 {len(files)}건 ---")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-6-2: file-summary
# ---------------------------------------------------------------------------

async def file_summary(client: Any) -> str:
    """GET /api/v2/open-chat/my-files/summary

    Retrieve a summary of the user's file storage usage.
    """
    try:
        data = await client.get("/api/v2/open-chat/my-files/summary")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    total_count = data.get("totalCount", data.get("count", "?"))
    total_size = _fmt_file_size(data.get("totalSize", data.get("size")))
    limit_size = _fmt_file_size(data.get("limitSize", data.get("storageLimit")))

    lines = [
        "=== 파일 저장소 요약 ===",
        f"파일 수: {total_count}",
        f"사용 용량: {total_size}",
    ]
    if data.get("limitSize") or data.get("storageLimit"):
        lines.append(f"저장 한도: {limit_size}")

    # Show per-type breakdown if available
    by_type = data.get("byType") or data.get("breakdown")
    if isinstance(by_type, dict):
        lines.append("\n유형별:")
        for type_name, info in by_type.items():
            if isinstance(info, dict):
                count = info.get("count", "?")
                size = _fmt_file_size(info.get("size"))
                lines.append(f"  {type_name}: {count}건, {size}")
            else:
                lines.append(f"  {type_name}: {info}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

FILE_COMMANDS: dict[str, dict[str, Any]] = {
    "list": {
        "fn": file_list,
        "help": "내 파일 목록 조회",
        "args": [
            {"name": "--limit", "type": int, "default": 20, "help": "조회 건수 (기본 20)"},
        ],
    },
    "summary": {
        "fn": file_summary,
        "help": "파일 저장소 요약",
        "args": [],
    },
}


async def dispatch_file_command(client: Any, command: str, args: dict[str, Any]) -> str:
    """Dispatch a file subcommand by name."""
    spec = FILE_COMMANDS.get(command)
    if spec is None:
        return f"[오류] 알 수 없는 file 명령: {command}"
    fn = spec["fn"]
    return await fn(client, **args)
