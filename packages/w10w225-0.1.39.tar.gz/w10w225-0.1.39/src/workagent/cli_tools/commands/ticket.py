"""Ticket domain CLI commands for the nk304 open-chat API.

Each async function accepts an ``Nk304ApiClient`` instance and returns
a human-readable string (designed for LLM consumption) that will be
printed to stdout by the CLI entry point.

Write commands (create, comment, update) output ACTION_PROPOSAL markers
so the ChatPipeline can route them through the standard write_draft
approval flow (action_parser -> transport.create_write_draft -> user
approval -> ActionExecutor).

WBS 6-5-1 .. 6-5-6
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any

import httpx


# ---------------------------------------------------------------------------
# Error handling helpers
# ---------------------------------------------------------------------------

_ERROR_MESSAGES: dict[int, str] = {
    403: "접근 권한이 없습니다",
    404: "티켓을 찾을 수 없습니다",
}


def _handle_http_error(exc: httpx.HTTPStatusError) -> str:
    code = exc.response.status_code
    detail = _ERROR_MESSAGES.get(code)
    if detail:
        return f"[오류 {code}] {detail}"
    return f"[오류 {code}] {exc.response.text[:300]}"


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _fmt_dt(iso: str | None) -> str:
    if not iso:
        return ""
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return iso


def _status_label(status: str) -> str:
    labels = {
        "not_started": "시작 전",
        "in_progress": "진행 중",
        "done": "완료",
    }
    return labels.get(status, status)


def _fmt_ticket_summary(ticket: dict[str, Any]) -> str:
    """Format a single ticket as a one-line summary."""
    ticket_id = ticket.get("id", "?")
    title = ticket.get("title", "(제목 없음)")
    status = _status_label(ticket.get("status", ""))
    updated = _fmt_dt(ticket.get("updatedAt") or ticket.get("createdAt"))
    assignee = (
        ticket.get("assigneeName")
        or (ticket.get("assignee") or {}).get("nickname", "")
    )
    assignee_part = f" @{assignee}" if assignee else ""
    return f"  [{ticket_id}] [{status}] {title}{assignee_part} ({updated})"


def _fmt_comment(comment: dict[str, Any]) -> str:
    """Format a single ticket comment."""
    author = (
        comment.get("authorName")
        or (comment.get("author") or {}).get("nickname", "?")
    )
    ts = _fmt_dt(comment.get("createdAt"))
    content = comment.get("content", "")
    return f"  [{author}] ({ts}) {content}"


# ---------------------------------------------------------------------------
# ACTION_PROPOSAL helper (replaces old _write_draft HTTP call)
# ---------------------------------------------------------------------------

def _format_write_proposal(kind: str, payload: dict[str, Any], reason: str) -> str:
    """Return an ACTION_PROPOSAL block for the ChatPipeline to parse.

    The ChatPipeline's ``action_parser.parse()`` will detect the markers,
    extract kind/target/content/payload/reason, and call
    ``transport.create_write_draft()`` which uses the proper HMAC/session
    transport -- bypassing the JWT auth limitation of direct API calls.
    """
    payload_json = json.dumps(payload, ensure_ascii=False)
    return (
        f"---ACTION_PROPOSAL---\n"
        f"kind: {kind}\n"
        f"target: {{}}\n"
        f"payload: {payload_json}\n"
        f"content: |\n"
        f"  {payload_json}\n"
        f"reason: {reason}\n"
        f"---END_ACTION_PROPOSAL---"
    )


# ---------------------------------------------------------------------------
# 6-5-1: ticket-list
# ---------------------------------------------------------------------------

async def ticket_list(client: Any, status: str | None = None) -> str:
    """GET /api/v2/open-chat/tickets/my

    List tickets assigned to or created by the current user.
    """
    params: dict[str, Any] = {}
    if status:
        params["status"] = status

    try:
        data = await client.get("/api/v2/open-chat/tickets/my", params=params or None)
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    tickets: list[dict[str, Any]] = data if isinstance(data, list) else data.get("items", [])
    if not isinstance(tickets, list):
        tickets = []

    header = "=== 내 티켓 목록 ==="
    if status:
        header = f"=== 내 티켓 목록 (상태: {_status_label(status)}) ==="
    lines = [header]

    if not tickets:
        lines.append("티켓이 없습니다.")
    else:
        for ticket in tickets:
            lines.append(_fmt_ticket_summary(ticket))

    lines.append(f"--- 총 {len(tickets)}건 ---")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-5-2: ticket-get
# ---------------------------------------------------------------------------

async def ticket_get(client: Any, ticket_id: str) -> str:
    """GET /api/v2/open-chat/tickets/{ticket_id}

    Retrieve a single ticket with full details.
    """
    try:
        data = await client.get(f"/api/v2/open-chat/tickets/{ticket_id}")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    title = data.get("title", "(제목 없음)")
    description = data.get("description", "")
    status = _status_label(data.get("status", ""))
    created = _fmt_dt(data.get("createdAt"))
    updated = _fmt_dt(data.get("updatedAt"))
    creator = (
        data.get("creatorName")
        or (data.get("creator") or {}).get("nickname", "")
    )
    assignee = (
        data.get("assigneeName")
        or (data.get("assignee") or {}).get("nickname", "")
    )
    room_id = data.get("roomId", "")
    comment_count = data.get("commentCount", data.get("_count", {}).get("comments", "?"))

    lines = [
        f"=== 티켓 상세 ({ticket_id}) ===",
        f"제목: {title}",
        f"상태: {status}",
    ]
    if creator:
        lines.append(f"작성자: {creator}")
    if assignee:
        lines.append(f"담당자: {assignee}")
    if room_id:
        lines.append(f"채팅방: {room_id}")
    lines.append(f"생성일: {created}")
    if updated and updated != created:
        lines.append(f"수정일: {updated}")
    lines.append(f"댓글 수: {comment_count}")
    if description:
        lines.append(f"\n{description}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-5-3: ticket-comments
# ---------------------------------------------------------------------------

async def ticket_comments(client: Any, ticket_id: str) -> str:
    """GET /api/v2/open-chat/tickets/{ticket_id}/comments

    Retrieve comments on a ticket.
    """
    try:
        data = await client.get(f"/api/v2/open-chat/tickets/{ticket_id}/comments")
    except httpx.HTTPStatusError as exc:
        return _handle_http_error(exc)

    comments: list[dict[str, Any]] = data if isinstance(data, list) else data.get("items", [])
    if not isinstance(comments, list):
        comments = []

    lines = [f"=== 티켓 댓글 ({ticket_id}) ==="]
    if not comments:
        lines.append("댓글이 없습니다.")
    else:
        for comment in comments:
            lines.append(_fmt_comment(comment))

    lines.append(f"--- 총 {len(comments)}건 ---")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6-5-4: ticket-create (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def ticket_create(
    room_id: str,
    title: str,
    description: str,
) -> str:
    """Output an ACTION_PROPOSAL for ticket creation."""
    return _format_write_proposal(
        kind="nk304_ticket_create",
        payload={"roomId": room_id, "title": title, "description": description},
        reason=f"티켓 생성: {title}",
    )


# ---------------------------------------------------------------------------
# 6-5-5: ticket-comment (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def ticket_comment(ticket_id: str, content: str) -> str:
    """Output an ACTION_PROPOSAL for adding a ticket comment."""
    return _format_write_proposal(
        kind="nk304_ticket_comment",
        payload={"ticketId": ticket_id, "content": content},
        reason=f"티켓 댓글 추가: {ticket_id}",
    )


# ---------------------------------------------------------------------------
# 6-5-6: ticket-update (ACTION_PROPOSAL)
# ---------------------------------------------------------------------------

def ticket_update(ticket_id: str, status: str) -> str:
    """Output an ACTION_PROPOSAL for ticket status update."""
    return _format_write_proposal(
        kind="nk304_ticket_update",
        payload={"ticketId": ticket_id, "status": status},
        reason=f"티켓 상태 변경: {ticket_id} → {_status_label(status)}",
    )


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Which commands need an API client (read) vs. pure output (write)
# ---------------------------------------------------------------------------

_WRITE_COMMANDS = {"create", "comment", "update"}

TICKET_COMMANDS: dict[str, dict[str, Any]] = {
    "list": {
        "fn": ticket_list,
        "help": "내 티켓 목록 조회",
        "args": [
            {"name": "--status", "default": None, "help": "상태 필터 (not_started, in_progress, done)"},
        ],
    },
    "get": {
        "fn": ticket_get,
        "help": "티켓 상세 조회",
        "args": [
            {"name": "--ticket-id", "required": True, "help": "티켓 ID"},
        ],
    },
    "comments": {
        "fn": ticket_comments,
        "help": "티켓 댓글 조회",
        "args": [
            {"name": "--ticket-id", "required": True, "help": "티켓 ID"},
        ],
    },
    "create": {
        "fn": ticket_create,
        "help": "티켓 생성 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--room-id", "required": True, "help": "채팅방 ID"},
            {"name": "--title", "required": True, "help": "티켓 제목"},
            {"name": "--description", "required": True, "help": "티켓 설명"},
        ],
    },
    "comment": {
        "fn": ticket_comment,
        "help": "티켓 댓글 추가 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--ticket-id", "required": True, "help": "티켓 ID"},
            {"name": "--content", "required": True, "help": "댓글 내용"},
        ],
    },
    "update": {
        "fn": ticket_update,
        "help": "티켓 상태 변경 (ACTION_PROPOSAL → 사용자 승인)",
        "args": [
            {"name": "--ticket-id", "required": True, "help": "티켓 ID"},
            {"name": "--status", "required": True, "help": "변경할 상태 (not_started, in_progress, done)"},
        ],
    },
}


async def dispatch_ticket_command(client: Any, command: str, args: dict[str, Any]) -> str:
    """Dispatch a ticket subcommand by name.

    Read commands (list, get, comments) are async and require the API client.
    Write commands (create, comment, update) are sync and return
    ACTION_PROPOSAL text -- no client needed.
    """
    spec = TICKET_COMMANDS.get(command)
    if spec is None:
        return f"[오류] 알 수 없는 ticket 명령: {command}"
    fn = spec["fn"]
    if command in _WRITE_COMMANDS:
        return fn(**args)
    return await fn(client, **args)
