"""nk304 CLI tool -- query nk304 APIs with user-equivalent permissions.

Subcommands are registered automatically from the ``commands/*.py`` COMMANDS
registries so that the argparse CLI always matches the rich command set
(room-info, messages, search, thread, members, summary, pins, my-rooms, etc.).

Usage examples:
  nk304 chat messages --room-id ROOM_ID [--limit 50]
  nk304 chat room-info --room-id ROOM_ID
  nk304 chat search --room-id ROOM_ID --query QUERY
  nk304 chat my-rooms
  nk304 memo list [--limit 20]
  nk304 memo get --memo-id ID
  nk304 ticket list [--status open]
  nk304 file list [--limit 20]
  nk304 user me
  nk304 notification list [--limit 20]
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from typing import Any

from workagent.cli_tools.nk304_api_client import Nk304ApiClient, Nk304TokenError

from workagent.cli_tools.commands.chat import CHAT_COMMANDS, dispatch_chat_command
from workagent.cli_tools.commands.memo import MEMO_COMMANDS, dispatch_memo_command
from workagent.cli_tools.commands.ticket import TICKET_COMMANDS, dispatch_ticket_command
from workagent.cli_tools.commands.file import FILE_COMMANDS, dispatch_file_command
from workagent.cli_tools.commands.user import USER_COMMANDS, dispatch_user_command
from workagent.cli_tools.commands.notification import NOTIFICATION_COMMANDS, dispatch_notification_command
from workagent.cli_tools.commands.calendar import CALENDAR_COMMANDS, dispatch_calendar_command


# ---------------------------------------------------------------------------
# Output formatting
# ---------------------------------------------------------------------------

def _error_exit(msg: str) -> None:
    print(json.dumps({"error": msg}), file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# Domain registry: maps domain name -> (COMMANDS dict, dispatch function)
# ---------------------------------------------------------------------------

_DOMAIN_REGISTRY: dict[str, dict[str, Any]] = {
    "chat": {
        "commands": CHAT_COMMANDS,
        "dispatch": dispatch_chat_command,
        "help": "Chat / messaging commands",
    },
    "memo": {
        "commands": MEMO_COMMANDS,
        "dispatch": dispatch_memo_command,
        "help": "Memo / note commands",
    },
    "ticket": {
        "commands": TICKET_COMMANDS,
        "dispatch": dispatch_ticket_command,
        "help": "Ticket / issue commands",
    },
    "file": {
        "commands": FILE_COMMANDS,
        "dispatch": dispatch_file_command,
        "help": "File commands",
    },
    "user": {
        "commands": USER_COMMANDS,
        "dispatch": dispatch_user_command,
        "help": "User commands",
    },
    "notification": {
        "commands": NOTIFICATION_COMMANDS,
        "dispatch": dispatch_notification_command,
        "help": "Notification commands",
    },
    "calendar": {
        "commands": CALENDAR_COMMANDS,
        "dispatch": dispatch_calendar_command,
        "help": "Calendar event commands",
    },
}


# ---------------------------------------------------------------------------
# Argparse registration from COMMANDS registries
# ---------------------------------------------------------------------------

def _register_domain_from_commands(
    domain_subparsers: argparse._SubParsersAction,  # type: ignore[type-arg]
    domain_name: str,
    commands: dict[str, dict[str, Any]],
    help_text: str,
) -> None:
    """Register a domain (e.g. 'chat') and all its subcommands from a COMMANDS dict."""
    sp = domain_subparsers.add_parser(domain_name, help=help_text)
    sp.set_defaults(nk304_domain=domain_name)
    sub = sp.add_subparsers(dest="action", required=True)

    for cmd_name, spec in commands.items():
        p = sub.add_parser(cmd_name, help=spec.get("help", ""))
        for arg_spec in spec.get("args", []):
            # Build kwargs from the arg spec dict
            name = arg_spec["name"]
            kwargs: dict[str, Any] = {}
            if "required" in arg_spec:
                kwargs["required"] = arg_spec["required"]
            if "type" in arg_spec:
                kwargs["type"] = arg_spec["type"]
            if "default" in arg_spec:
                kwargs["default"] = arg_spec["default"]
            if "help" in arg_spec:
                kwargs["help"] = arg_spec["help"]
            p.add_argument(name, **kwargs)


# ---------------------------------------------------------------------------
# Argparse namespace -> dispatch kwargs conversion
# ---------------------------------------------------------------------------

def _namespace_to_dispatch_kwargs(args: argparse.Namespace, commands: dict[str, dict[str, Any]], action: str) -> dict[str, Any]:
    """Convert an argparse.Namespace into the keyword arguments expected by a dispatch function.

    Argparse converts ``--room-id`` to ``args.room_id``.  The dispatch functions
    expect keyword names matching the function signatures (e.g. ``room_id``).
    We derive the kwarg names from the COMMANDS arg spec.
    """
    spec = commands.get(action, {})
    kwargs: dict[str, Any] = {}
    for arg_spec in spec.get("args", []):
        # '--room-id' -> 'room_id'
        attr_name = arg_spec["name"].lstrip("-").replace("-", "_")
        kwargs[attr_name] = getattr(args, attr_name, arg_spec.get("default"))
    return kwargs


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def _register_all_domains(domain_subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register every domain from _DOMAIN_REGISTRY."""
    for domain_name, info in _DOMAIN_REGISTRY.items():
        _register_domain_from_commands(
            domain_subparsers,
            domain_name,
            info["commands"],
            info["help"],
        )


def register_nk304_subcommands(subparsers: argparse._SubParsersAction) -> None:  # type: ignore[type-arg]
    """Register the ``nk304`` top-level subcommand under the given *subparsers*.

    Called from ``cli.py``::

        register_nk304_subcommands(subparsers)
    """
    nk304_parser = subparsers.add_parser("nk304", help="Query nk304 APIs")
    nk304_parser.set_defaults(nk304_domain=None)
    domain_subparsers = nk304_parser.add_subparsers(dest="nk304_domain")
    _register_all_domains(domain_subparsers)


def run_nk304_command(args: argparse.Namespace) -> int:
    """Dispatch to the correct nk304 domain handler and run it.

    Returns 0 on success, 1 on error.
    """
    domain: str | None = getattr(args, "nk304_domain", None)
    if not domain:
        _error_exit("No nk304 domain specified. Use: nk304 <chat|memo|ticket|file|user|notification|calendar> <command>")
        return 1  # unreachable

    registry_entry = _DOMAIN_REGISTRY.get(domain)
    if registry_entry is None:
        _error_exit(f"Unknown nk304 domain: {domain}")
        return 1  # unreachable

    action: str | None = getattr(args, "action", None)
    if not action:
        _error_exit(f"No action specified for domain '{domain}'.")
        return 1  # unreachable

    try:
        client = Nk304ApiClient.from_env()
        dispatch_fn = registry_entry["dispatch"]
        commands = registry_entry["commands"]
        kwargs = _namespace_to_dispatch_kwargs(args, commands, action)
        output = asyncio.run(dispatch_fn(client, action, kwargs))
        print(output)
    except Nk304TokenError as exc:
        _error_exit(str(exc))
        return 1  # unreachable
    except SystemExit:
        raise
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        _error_exit(str(exc))
        return 1  # unreachable

    return 0


# ---------------------------------------------------------------------------
# Standalone entry point (nk304 command)
# ---------------------------------------------------------------------------

def main() -> int:
    """Entry point for the ``nk304`` standalone CLI."""
    parser = argparse.ArgumentParser(
        prog="nk304",
        description="Query nk304 APIs with user-equivalent permissions",
    )
    domain_subparsers = parser.add_subparsers(dest="nk304_domain")
    _register_all_domains(domain_subparsers)

    args = parser.parse_args()
    return run_nk304_command(args)
