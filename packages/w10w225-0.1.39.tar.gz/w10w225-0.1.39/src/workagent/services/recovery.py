from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.enums import CaseStatus, ReviewCommandStatus
from workagent.db.models import Case, ReviewCommand
from workagent.services.review_commands import ReviewCommandProcessor


@dataclass(frozen=True, slots=True)
class RecoverySummary:
    requeued_case_ids: list[str]
    pending_outbound_ids: list[str]


class RecoveryService:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory
        self.review_command_processor = ReviewCommandProcessor(session_factory)

    async def recover(self, *, queue) -> RecoverySummary:  # noqa: ANN001
        async with self.session_factory() as session:
            pending_command_ids = (
                await session.execute(
                    select(ReviewCommand.id)
                    .where(ReviewCommand.status == ReviewCommandStatus.pending)
                    .order_by(ReviewCommand.created_at)
                )
            ).scalars().all()

        for command_id in pending_command_ids:
            await self.review_command_processor.process_command(command_id)

        async with self.session_factory() as session:
            requeue_rows = (
                await session.execute(
                    select(Case).where(
                        Case.status.in_(
                            [
                                CaseStatus.queued_for_local_run,
                                CaseStatus.researching,
                                CaseStatus.revising,
                                CaseStatus.interactive_queued,
                                CaseStatus.interactive_running,
                                CaseStatus.ready_to_execute,
                            ]
                        )
                    )
                )
            ).scalars().all()
        requeued_ids: list[str] = []
        for row in requeue_rows:
            await queue.enqueue(row.id)
            requeued_ids.append(row.id)

        return RecoverySummary(
            requeued_case_ids=requeued_ids,
            pending_outbound_ids=[],  # OutboundMessage model deleted
        )
