from __future__ import annotations

from dataclasses import dataclass

from workagent.connectors.gitlab_sync import CursorStore, GitLabClient, GitLabSyncService
from workagent.runtime.queue import LocalRunQueue

# GitLabIngestService removed in MVP1 — ingest_service parameter is now optional (None)


@dataclass(frozen=True, slots=True)
class GitLabSyncCycleSummary:
    polled_events: int
    created_cases: int
    previous_cursor: str | None
    next_cursor: str | None


class GitLabSyncCycle:
    def __init__(
        self,
        *,
        client: GitLabClient,
        cursor_store: CursorStore,
        ingest_service: object | None,
        queue: LocalRunQueue,
        limit: int = 20,
    ) -> None:
        self._sync_service = GitLabSyncService(client=client, cursor_store=cursor_store, limit=limit)
        self._ingest_service = ingest_service
        self._queue = queue

    async def run_once(self) -> GitLabSyncCycleSummary:
        batch = await self._sync_service.sync_once()
        case_ids = await self._ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self._queue.enqueue(case_id)
        await self._sync_service.commit(batch)
        return GitLabSyncCycleSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            previous_cursor=batch.previous_cursor,
            next_cursor=batch.next_cursor,
        )
