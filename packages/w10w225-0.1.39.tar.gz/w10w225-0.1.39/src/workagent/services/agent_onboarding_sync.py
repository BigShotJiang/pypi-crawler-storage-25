from __future__ import annotations

import logging
import subprocess
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Protocol

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.config.env import resolve_agents_skills_home
from workagent.config.models import AppConfig, ConnectorConfig, Platform, WatchProfile, WatchProfilePreset
from workagent.config.store import ConfigStore
from workagent.db.enums import AgentConnectedAccountStatus, AgentOnboardingItemStatus, AgentOnboardingItemType
from workagent.db.models import (
    AgentConnectedAccount,
    AgentOnboardingItem,
    AppSetting,
    AuditEvent,
    ProjectAgentDefinition,
    ScheduledJob,
)
from workagent.runtime.secrets import SecretStore
from workagent.services.agent_model_catalog import refresh_cached_agent_model_catalog
from workagent.services.connected_account_health import perform_connected_account_health_check
from workagent.services.credentials import sync_config_credentials_to_db
from workagent.sync.models import (
    AgentConnectedAccountStatusPayload,
    AgentOnboardingItemAckPayload,
    AgentOnboardingItemRecord,
    AgentOnboardingItemResultPayload,
    ProjectAgentInstallationStatusPayload,
)

logger = logging.getLogger("workagent.agent_sync")
logger.propagate = True


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _interval_minutes_to_cron(interval_minutes: int) -> str:
    """Convert an interval in minutes to a cron expression.

    Examples: 1 → '* * * * *', 30 → '*/30 * * * *', 60 → '0 * * * *', 1440 → '0 0 * * *'
    """
    minutes = max(1, int(interval_minutes))
    if minutes == 1:
        return "* * * * *"
    if minutes < 60:
        return f"*/{minutes} * * * *"
    hours = minutes // 60
    if hours == 1:
        return "0 * * * *"
    if hours < 24:
        return f"0 */{hours} * * *"
    days = hours // 24
    if days == 1:
        return "0 0 * * *"
    return f"0 0 */{days} * *"


def _normalize_reasoning_effort(raw_value: object) -> str | None:
    value = str(raw_value or "").strip().lower()
    if not value:
        return None
    if value == "xhigh":
        return "high"
    if value in {"low", "medium", "high"}:
        return value
    return "medium"


def _normalize_execution_engine(raw_value: object) -> str | None:
    value = str(raw_value or "").strip()
    if value in {"codex_cli", "copilot_cli", "claude_cli", "gemini_cli"}:
        return value
    return None


class OnboardingPoller(Protocol):
    async def poll_once(self): ...  # noqa: ANN201

    async def commit(self, batch) -> None: ...  # noqa: ANN001


class OnboardingSyncApi(Protocol):
    async def ack_agent_onboarding_item(self, item_id: str, payload: AgentOnboardingItemAckPayload) -> dict: ...

    async def push_agent_onboarding_item_result(self, item_id: str, payload: AgentOnboardingItemResultPayload) -> dict: ...

    async def push_agent_connected_account_status(self, payload: AgentConnectedAccountStatusPayload) -> dict: ...
    async def push_project_agent_installation_status(self, payload: ProjectAgentInstallationStatusPayload) -> dict: ...


@dataclass(frozen=True, slots=True)
class AgentOnboardingItemBatch:
    items: list[AgentOnboardingItemRecord]
    previous_cursor: str | None
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class SyncedOnboardingItemOutcome:
    item_id: str
    status: str


@dataclass(frozen=True, slots=True)
class RefreshAttemptOutcome:
    refreshed: bool
    reason: str | None = None
    payload: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class AgentOnboardingSyncService:
    session_factory: async_sessionmaker[AsyncSession]
    poller: OnboardingPoller
    sync_api: OnboardingSyncApi
    secret_store: SecretStore
    config_store: ConfigStore | None = None
    project_agent_snapshot_pushed: bool = False

    async def sync_once(self) -> list[SyncedOnboardingItemOutcome]:
        batch = await self.poller.poll_once()
        await refresh_cached_agent_model_catalog(self.session_factory, self.sync_api)
        outcomes: list[SyncedOnboardingItemOutcome] = []
        for item in batch.items:
            outcomes.append(await self.process_remote_item(item))
        await self._run_provider_token_health_check()
        if not self.project_agent_snapshot_pushed:
            await self._push_project_agent_installation_snapshot()
            self.project_agent_snapshot_pushed = True
        await self.poller.commit(batch)
        return outcomes

    def _is_synthetic_item(self, item: AgentOnboardingItemRecord) -> bool:
        """Synthetic items (e.g. system_skills_push) are emitted by the server
        without a backing DB row.  They must NOT be ACK-ed or result-pushed."""
        return str(item.payload.get("type") or "") == "system_skills_push"

    async def process_remote_item(self, item: AgentOnboardingItemRecord) -> SyncedOnboardingItemOutcome:
        provider_account_id = str(item.payload.get("providerAccountId") or "account-unknown")
        target_installation_id = str(item.payload.get("targetInstallationId") or "installation-unknown")
        logger.info(
            "w10w225 onboarding item received item_id=%s item_type=%s platform_id=%s provider_account_id=%s target_installation_id=%s",
            item.id,
            item.item_type,
            item.platform_id,
            provider_account_id,
            target_installation_id,
        )

        # Synthetic items (no DB row on server) — process only, skip ACK/result
        if self._is_synthetic_item(item):
            try:
                result = await self._process_item(item)
                logger.info("w10w225 synthetic onboarding item completed item_id=%s result=%s", item.id, result)
                return SyncedOnboardingItemOutcome(item_id=item.id, status="completed")
            except Exception as exc:  # noqa: BLE001
                logger.exception("w10w225 synthetic onboarding item failed item_id=%s error=%s", item.id, exc)
                return SyncedOnboardingItemOutcome(item_id=item.id, status="failed")

        if await self._is_already_completed(item.id):
            logger.info("w10w225 onboarding item reprocessing item_id=%s reason=already_completed_locally", item.id)
        await self._upsert_local_item(item)
        ack_payload = AgentOnboardingItemAckPayload(receiptId=f"{item.id}:claimed", status="claimed")
        await self.sync_api.ack_agent_onboarding_item(item.id, ack_payload)
        logger.info("w10w225 onboarding item ack stored item_id=%s status=%s", item.id, ack_payload.status)
        try:
            result = await self._process_item(item)
        except Exception as exc:  # noqa: BLE001
            logger.exception(
                "w10w225 onboarding item processing failed item_id=%s item_type=%s error=%s",
                item.id,
                item.item_type,
                exc,
            )
            try:
                await self.sync_api.push_agent_onboarding_item_result(
                    item.id,
                    AgentOnboardingItemResultPayload(status="failed", result={"error": str(exc)}),
                )
            except Exception:  # noqa: BLE001
                logger.warning("w10w225 onboarding item failed result push also failed item_id=%s", item.id)
            return SyncedOnboardingItemOutcome(item_id=item.id, status="failed")
        await self.sync_api.push_agent_onboarding_item_result(
            item.id,
            AgentOnboardingItemResultPayload(status="completed", result=result),
        )
        logger.info(
            "w10w225 onboarding item completed item_id=%s status=completed platform_id=%s provider_account_id=%s account_status=%s status_reason=%s",
            item.id,
            item.platform_id,
            provider_account_id,
            str(result.get("accountStatus") or "active"),
            str(result.get("statusReason") or ""),
        )
        return SyncedOnboardingItemOutcome(item_id=item.id, status="completed")

    async def _is_already_completed(self, item_id: str) -> bool:
        async with self.session_factory() as session:
            existing = await session.get(AgentOnboardingItem, item_id)
            return existing is not None and existing.status == AgentOnboardingItemStatus.completed

    async def _upsert_local_item(self, item: AgentOnboardingItemRecord) -> None:
        async with self.session_factory() as session:
            existing = await session.get(AgentOnboardingItem, item.id)
            if existing is None:
                session.add(
                    AgentOnboardingItem(
                        id=item.id,
                        workspace_id=str(item.payload.get("workspaceId") or "workspace-unknown"),
                        target_installation_id=str(item.payload.get("targetInstallationId") or "installation-unknown"),
                        item_type=AgentOnboardingItemType(item.item_type),
                        status=AgentOnboardingItemStatus.pending,
                        payload_json=item.payload,
                        delivery_envelope_json=item.delivery_envelope,
                        idempotency_key=f"onboarding:{item.id}",
                    )
                )
            else:
                existing.payload_json = item.payload
                existing.delivery_envelope_json = item.delivery_envelope
                if existing.status != AgentOnboardingItemStatus.completed:
                    existing.status = AgentOnboardingItemStatus.pending
                existing.updated_at = _utcnow()
            await session.commit()

    async def _process_item(self, item: AgentOnboardingItemRecord) -> dict[str, object]:
        item_type = AgentOnboardingItemType(item.item_type)
        if item_type is AgentOnboardingItemType.oauth_refresh_required:
            return await self._process_refresh_required(item)
        if item_type is AgentOnboardingItemType.oauth_disconnect_requested:
            return await self._process_disconnect_requested(item)
        if item_type is AgentOnboardingItemType.connection_health_check_requested:
            return await self._process_connection_health_check(item)
        if item_type is AgentOnboardingItemType.agent_character_sync:
            if str(item.payload.get("type") or "") == "system_skills_push":
                return await self._process_system_skills_push(item)
            return await self._process_character_sync(item)
        if item_type is AgentOnboardingItemType.project_agent_definition_sync:
            return await self._process_project_agent_definition_sync(item)
        if item_type is AgentOnboardingItemType.project_agent_install_update_requested:
            return await self._process_project_agent_install_update_requested(item)

        platform_id = item.platform_id
        provider_account_id = str(item.payload.get("providerAccountId") or "account-unknown")
        stored_secret_keys = _store_delivery_secrets(
            secret_store=self.secret_store,
            platform_id=platform_id,
            provider_account_id=provider_account_id,
            delivery_envelope=item.delivery_envelope,
        )
        stored_secret_keys.extend(
            _store_payload_runtime_metadata(
                secret_store=self.secret_store,
                platform_id=platform_id,
                provider_account_id=provider_account_id,
                payload=item.payload,
            )
        )
        sanitized_delivery_envelope = _purged_delivery_envelope_metadata(item.delivery_envelope)

        async with self.session_factory() as session:
            account = await session.scalar(
                select(AgentConnectedAccount).where(
                    AgentConnectedAccount.platform_id == platform_id,
                    AgentConnectedAccount.provider_account_id == provider_account_id,
                )
            )
            if account is None:
                account = AgentConnectedAccount(
                    workspace_id=str(item.payload.get("workspaceId") or "workspace-unknown"),
                    target_installation_id=str(item.payload.get("targetInstallationId") or "installation-unknown"),
                    platform_id=platform_id,
                    provider_account_id=provider_account_id,
                    provider_account_label=str(item.payload.get("providerAccountLabel") or "").strip() or None,
                    connection_name=str(item.payload.get("connectionName") or f"{platform_id}:{provider_account_id}"),
                    status=AgentConnectedAccountStatus.active,
                    scope_hash=str(item.payload.get("scopeHash") or "").strip() or None,
                )
                session.add(account)
            else:
                account.provider_account_label = str(item.payload.get("providerAccountLabel") or "").strip() or None
                account.status = AgentConnectedAccountStatus.active
                account.last_delivered_at = _utcnow()
                account.updated_at = _utcnow()

            onboarding_item = await session.get(AgentOnboardingItem, item.id)
            if onboarding_item is not None:
                onboarding_item.status = AgentOnboardingItemStatus.completed
                onboarding_item.delivery_envelope_json = sanitized_delivery_envelope
                onboarding_item.completed_at = _utcnow()
                onboarding_item.updated_at = _utcnow()
            session.add(
                AuditEvent(
                    event_type="connection.delivered",
                    entity_type="connected_account",
                    entity_id=f"{platform_id}:{provider_account_id}",
                    payload_json={
                        "platformId": platform_id,
                        "providerAccountId": provider_account_id,
                        "providerAccountLabel": str(item.payload.get("providerAccountLabel") or "").strip() or None,
                        "deliveryMode": sanitized_delivery_envelope.get("deliveryMode"),
                        "storedSecretKeys": stored_secret_keys,
                        "scopeHash": str(item.payload.get("scopeHash") or "").strip() or None,
                    },
                )
            )
            await session.commit()

        await self._sync_local_runtime_connector(
            platform_id=platform_id,
            provider_account_id=provider_account_id,
            payload=item.payload,
            account_status=AgentConnectedAccountStatus.active,
        )
        logger.info(
            "w10w225 onboarding runtime connector synced platform_id=%s provider_account_id=%s",
            platform_id,
            provider_account_id,
        )

        result = {"platformId": platform_id, "providerAccountId": provider_account_id}
        if stored_secret_keys:
            result["storedSecretKeys"] = stored_secret_keys
        if sanitized_delivery_envelope:
            result["deliveryMode"] = sanitized_delivery_envelope.get("deliveryMode")
        if self.config_store is not None:
            health = await perform_connected_account_health_check(
                config_store=self.config_store,
                secret_store=self.secret_store,
                platform_id=platform_id,
                provider_account_id=provider_account_id,
            )
            async with self.session_factory() as session:
                account = await session.scalar(
                    select(AgentConnectedAccount).where(
                        AgentConnectedAccount.platform_id == platform_id,
                        AgentConnectedAccount.provider_account_id == provider_account_id,
                    )
                )
                if account is not None:
                    if health.provider_account_label:
                        account.provider_account_label = health.provider_account_label
                    account.status = (
                        AgentConnectedAccountStatus.active
                        if health.status == AgentConnectedAccountStatus.active.value
                        else AgentConnectedAccountStatus.refresh_required
                    )
                    account.updated_at = _utcnow()
                    if account.status is AgentConnectedAccountStatus.active:
                        account.last_validated_at = _utcnow()
                    await session.commit()
            result["accountStatus"] = health.status
            result["statusReason"] = health.reason
            if health.provider_account_label:
                result["providerAccountLabel"] = health.provider_account_label
            logger.info(
                "w10w225 onboarding health check completed platform_id=%s provider_account_id=%s account_status=%s status_reason=%s provider_account_label=%s",
                platform_id,
                provider_account_id,
                health.status,
                health.reason,
                health.provider_account_label or "",
            )
        return result

    async def _process_system_skills_push(self, item: AgentOnboardingItemRecord) -> dict[str, object]:
        """Save system AI skills to ~/.personal-work-agent/skills/{category}/{skill_id}/SKILL.md

        Each skill entry may include a ``category`` field (``"external"`` or
        ``"internal"``).  When the field is absent the skill is placed under
        ``external`` for backward-compatibility.
        """
        from pathlib import Path
        skills_root = Path.home() / ".personal-work-agent" / "skills"
        system_skills = item.payload.get("systemSkills") or []
        saved = 0
        for skill_data in system_skills:
            skill_id = str(skill_data.get("skillId") or "").strip()
            content = str(skill_data.get("contentText") or "").strip()
            category = str(skill_data.get("category") or "external").strip()
            if category not in ("external", "internal"):
                category = "external"
            if skill_id and content:
                skill_dir = skills_root / category / skill_id
                skill_dir.mkdir(parents=True, exist_ok=True)
                (skill_dir / "SKILL.md").write_text(content, encoding="utf-8")
                saved += 1
        logger.info("system_skills_push saved %d skills to %s", saved, skills_root)
        return {"type": "system_skills_push", "savedCount": saved}

    async def _process_character_sync(self, item: AgentOnboardingItemRecord) -> dict[str, object]:
        character = str(item.payload.get("character") or "").strip()
        task = str(item.payload.get("task") or "").strip()
        scheduled_tasks = item.payload.get("scheduledTasks") or []
        stored_engine_api_keys = _store_engine_api_keys(secret_store=self.secret_store, delivery_envelope=item.delivery_envelope)
        async with self.session_factory() as session:
            for key, value in [("agent_character", character), ("agent_task", task)]:
                row = await session.get(AppSetting, key)
                if row is None:
                    session.add(AppSetting(key=key, value_json={"text": value}))
                else:
                    row.value_json = {"text": value}

            defaults_key = "agent_execution_defaults"
            defaults_row = await session.get(AppSetting, defaults_key)
            default_engine = _normalize_execution_engine(item.payload.get("defaultEngine"))
            default_model_mode = str(item.payload.get("defaultModelMode") or "").strip().lower() or None
            default_model = str(item.payload.get("defaultModel") or "").strip()
            default_reasoning_effort = _normalize_reasoning_effort(item.payload.get("defaultReasoningEffort"))
            defaults_payload = {
                "modelMode": default_model_mode,
                "model": default_model or None,
                "reasoningEffort": default_reasoning_effort,
            }
            if default_engine:
                defaults_payload["engine"] = default_engine
            if defaults_row is None:
                session.add(AppSetting(key=defaults_key, value_json=defaults_payload))
            else:
                defaults_row.value_json = defaults_payload

            # Sync agent Slack channel
            slack_channel_id = str(item.payload.get("slackChannelId") or "").strip()
            channel_key = "agent_slack_channel_id"
            channel_row = await session.get(AppSetting, channel_key)
            if slack_channel_id:
                if channel_row is None:
                    session.add(AppSetting(key=channel_key, value_json={"channelId": slack_channel_id}))
                else:
                    channel_row.value_json = {"channelId": slack_channel_id}

            # Sync scheduled tasks → ScheduledJob rows
            existing_rows = (
                await session.execute(select(ScheduledJob).where(ScheduledJob.name.like("scheduled_task_%")))
            ).scalars().all()
            existing_by_name = {row.name: row for row in existing_rows}
            incoming_names: set[str] = set()
            for task_item in scheduled_tasks:
                logger.info("w10w225 agent_character_sync raw_task_item=%r", task_item)
                task_id = str(task_item.get("id") or "").strip()
                task_text = str(task_item.get("text") or "").strip()
                interval_minutes = int(task_item.get("intervalMinutes") or 60)
                enabled = bool(task_item.get("enabled", True))
                if not task_id or not task_text:
                    continue
                job_name = f"scheduled_task_{task_id}"
                incoming_names.add(job_name)
                cron_expr = _interval_minutes_to_cron(interval_minutes)
                payload = {
                    "taskId": task_id,
                    "taskText": task_text,
                    "intervalMinutes": interval_minutes,
                }
                task_model_mode = str(task_item.get("modelMode") or "").strip().lower() or None
                task_model = str(task_item.get("model") or "").strip()
                task_reasoning_effort = _normalize_reasoning_effort(task_item.get("reasoningEffort"))
                if task_model_mode:
                    payload["modelMode"] = task_model_mode
                if task_model:
                    payload["model"] = task_model
                if task_reasoning_effort:
                    payload["reasoningEffort"] = task_reasoning_effort
                row = existing_by_name.get(job_name)
                if row is None:
                    session.add(ScheduledJob(
                        name=job_name,
                        cron_expression=cron_expr,
                        is_enabled=enabled,
                        payload_json=payload,
                    ))
                else:
                    row.cron_expression = cron_expr
                    row.is_enabled = enabled
                    row.payload_json = payload
                    row.next_run_at = None  # reset so scheduler recalculates

            for name, row in existing_by_name.items():
                if name not in incoming_names:
                    await session.delete(row)

            onboarding_item = await session.get(AgentOnboardingItem, item.id)
            if onboarding_item is not None:
                onboarding_item.status = AgentOnboardingItemStatus.completed
                onboarding_item.delivery_envelope_json = _purged_delivery_envelope_metadata(item.delivery_envelope)
                onboarding_item.completed_at = _utcnow()
                onboarding_item.updated_at = _utcnow()
            await session.commit()
        default_engine = _normalize_execution_engine(item.payload.get("defaultEngine")) or "(none)"
        default_model = str(item.payload.get("defaultModel") or "").strip() or "(none)"
        default_reasoning = _normalize_reasoning_effort(item.payload.get("defaultReasoningEffort")) or "(none)"
        logger.info(
            "w10w225 agent_character_sync applied character_len=%d task_len=%d scheduled_tasks=%d "
            "default_engine=%s default_model=%s default_reasoning=%s",
            len(character),
            len(task),
            len(incoming_names),
            default_engine,
            default_model,
            default_reasoning,
        )
        for task_item in scheduled_tasks:
            task_id = str(task_item.get("id") or "").strip()
            task_text = str(task_item.get("text") or "").strip()
            interval_minutes = int(task_item.get("intervalMinutes") or 60)
            task_model = str(task_item.get("model") or "").strip() or "(remote default)"
            task_reasoning = _normalize_reasoning_effort(task_item.get("reasoningEffort")) or "(remote default)"
            if task_id and task_text:
                logger.info(
                    "w10w225 agent_character_sync scheduled_task task_id=%s interval_minutes=%d "
                    "task_model=%s task_reasoning=%s task_text=%r",
                    task_id,
                    interval_minutes,
                    task_model,
                    task_reasoning,
                    task_text,
                )
        result = {"type": "agent_character_sync", "characterLen": len(character), "taskLen": len(task), "scheduledTasksCount": len(incoming_names)}
        if stored_engine_api_keys:
            result["storedSecretKeys"] = stored_engine_api_keys
        return result

    async def _process_project_agent_definition_sync(self, item: AgentOnboardingItemRecord) -> dict[str, object]:
        workspace_id = str(item.payload.get("workspaceId") or "workspace-unknown").strip() or "workspace-unknown"
        target_installation_id = (
            str(item.payload.get("targetInstallationId") or "installation-unknown").strip() or "installation-unknown"
        )
        project_id = str(item.payload.get("projectId") or "").strip()
        project_agent_id = str(item.payload.get("projectAgentId") or "").strip()
        if not project_id or not project_agent_id:
            raise ValueError("project_agent_definition_sync requires projectId and projectAgentId")

        desired_version = int(item.payload.get("desiredVersion") or 1)
        name = str(item.payload.get("name") or "").strip() or project_agent_id
        role = str(item.payload.get("role") or "custom").strip() or "custom"
        execution_mode = str(item.payload.get("executionMode") or "worker").strip() or "worker"
        shared_prompt_text = str(item.payload.get("sharedPromptText") or "").strip() or None
        fixed_prompt_text = str(item.payload.get("fixedPromptText") or "").strip() or None
        pinned_skill_ids = [str(value).strip() for value in list(item.payload.get("pinnedSkillIds") or []) if str(value).strip()]
        allowed_skill_ids = [str(value).strip() for value in list(item.payload.get("allowedSkillIds") or []) if str(value).strip()]
        desired_prompt_hash = str(item.payload.get("desiredPromptHash") or "").strip() or None
        desired_skill_set_hash = str(item.payload.get("desiredSkillSetHash") or "").strip() or None

        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(ProjectAgentDefinition).where(
                        ProjectAgentDefinition.project_agent_id == project_agent_id,
                    )
                )
            ).scalar_one_or_none()
            if row is None:
                row = ProjectAgentDefinition(
                    workspace_id=workspace_id,
                    target_installation_id=target_installation_id,
                    project_id=project_id,
                    project_agent_id=project_agent_id,
                    name=name,
                    role=role,
                    execution_mode=execution_mode,
                    shared_prompt_text=shared_prompt_text,
                    fixed_prompt_text=fixed_prompt_text,
                    pinned_skill_ids_json=pinned_skill_ids,
                    allowed_skill_ids_json=allowed_skill_ids,
                    desired_version=desired_version,
                    desired_prompt_hash=desired_prompt_hash,
                    desired_skill_set_hash=desired_skill_set_hash,
                    updated_by_onboarding_item_id=item.id,
                )
                session.add(row)
            else:
                row.workspace_id = workspace_id
                row.target_installation_id = target_installation_id
                row.project_id = project_id
                row.name = name
                row.role = role
                row.execution_mode = execution_mode
                row.shared_prompt_text = shared_prompt_text
                row.fixed_prompt_text = fixed_prompt_text
                row.pinned_skill_ids_json = pinned_skill_ids
                row.allowed_skill_ids_json = allowed_skill_ids
                row.desired_version = desired_version
                row.desired_prompt_hash = desired_prompt_hash
                row.desired_skill_set_hash = desired_skill_set_hash
                row.updated_by_onboarding_item_id = item.id
                row.updated_at = _utcnow()

            onboarding_item = await session.get(AgentOnboardingItem, item.id)
            if onboarding_item is not None:
                onboarding_item.status = AgentOnboardingItemStatus.completed
                onboarding_item.delivery_envelope_json = _purged_delivery_envelope_metadata(item.delivery_envelope)
                onboarding_item.completed_at = _utcnow()
                onboarding_item.updated_at = _utcnow()

            session.add(
                AuditEvent(
                    event_type="project_agent.definition_synced",
                    entity_type="project_agent_definition",
                    entity_id=project_agent_id,
                    payload_json={
                        "workspaceId": workspace_id,
                        "targetInstallationId": target_installation_id,
                        "projectId": project_id,
                        "projectAgentId": project_agent_id,
                        "desiredVersion": desired_version,
                    },
                )
            )
            await session.commit()

        logger.info(
            "w10w225 project_agent_definition_sync applied project_id=%s project_agent_id=%s desired_version=%d",
            project_id,
            project_agent_id,
            desired_version,
        )
        return {
            "type": "project_agent_definition_sync",
            "projectId": project_id,
            "projectAgentId": project_agent_id,
            "desiredVersion": desired_version,
        }

    async def _process_project_agent_install_update_requested(self, item: AgentOnboardingItemRecord) -> dict[str, object]:
        project_id = str(item.payload.get("projectId") or "").strip()
        project_agent_id = str(item.payload.get("projectAgentId") or "").strip()
        if not project_id or not project_agent_id:
            raise ValueError("project_agent_install_update_requested requires projectId and projectAgentId")

        desired_version = int(item.payload.get("desiredVersion") or 1)
        desired_prompt_hash = str(item.payload.get("desiredPromptHash") or "").strip() or None
        desired_skill_set_hash = str(item.payload.get("desiredSkillSetHash") or "").strip() or None
        skills = list(item.payload.get("skills") or [])
        skill_root = resolve_agents_skills_home() / "installed"
        skill_root.mkdir(parents=True, exist_ok=True)
        installed_skill_ids: list[str] = []

        try:
            for raw_skill in skills:
                if not isinstance(raw_skill, dict):
                    raise ValueError("skills entries must be objects")
                skill_id = str(raw_skill.get("skillId") or "").strip()
                source_type = str(raw_skill.get("sourceType") or "").strip()
                source_uri = str(raw_skill.get("sourceUri") or "").strip()
                pinned_revision = str(raw_skill.get("pinnedRevision") or "").strip()
                if not skill_id or source_type != "git_repo" or not source_uri:
                    raise ValueError("only curated git_repo skills with sourceUri are supported")
                # Validate skill_id to prevent path traversal / absolute-path escapes
                if "/" in skill_id or "\\" in skill_id or skill_id.startswith("."):
                    raise ValueError(f"invalid skillId: {skill_id!r}")
                destination_dir = (skill_root / skill_id).resolve()
                if not destination_dir.is_relative_to(skill_root.resolve()):
                    raise ValueError(f"skillId escapes skill root: {skill_id!r}")
                self._install_curated_skill_repo(
                    destination_dir=destination_dir,
                    source_uri=source_uri,
                    pinned_revision=pinned_revision or None,
                )
                installed_skill_ids.append(skill_id)
        except Exception as exc:  # noqa: BLE001
            async with self.session_factory() as session:
                row = (
                    await session.execute(
                        select(ProjectAgentDefinition).where(
                            ProjectAgentDefinition.project_agent_id == project_agent_id,
                        )
                    )
                ).scalar_one_or_none()
                if row is not None:
                    row.observed_install_status = "failed"
                    row.last_error = str(exc)
                    row.updated_at = _utcnow()
                await session.commit()
            raise

        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(ProjectAgentDefinition).where(
                        ProjectAgentDefinition.project_agent_id == project_agent_id,
                    )
                )
            ).scalar_one_or_none()
            if row is None:
                raise ValueError("project agent definition must be synced before install/update")
            row.desired_version = desired_version
            row.desired_prompt_hash = desired_prompt_hash
            row.desired_skill_set_hash = desired_skill_set_hash
            row.observed_install_status = "installed"
            row.observed_prompt_hash = desired_prompt_hash
            row.observed_skill_set_hash = desired_skill_set_hash
            row.last_error = None
            row.updated_by_onboarding_item_id = item.id
            row.updated_at = _utcnow()
            await session.commit()

        return {
            "type": "project_agent_install_update_requested",
            "projectId": project_id,
            "projectAgentId": project_agent_id,
            "installedVersion": desired_version,
            "installStatus": "installed",
            "appliedPromptHash": desired_prompt_hash,
            "appliedSkillSetHash": desired_skill_set_hash,
            "installedSkillIds": installed_skill_ids,
        }

    async def _push_project_agent_installation_snapshot(self) -> None:
        async with self.session_factory() as session:
            rows = (await session.execute(select(ProjectAgentDefinition))).scalars().all()
        for row in rows:
            await self.sync_api.push_project_agent_installation_status(
                ProjectAgentInstallationStatusPayload(
                    targetInstallationId=row.target_installation_id,
                    projectId=row.project_id,
                    projectAgentId=row.project_agent_id,
                    installedVersion=row.desired_version if row.observed_install_status == "installed" else None,
                    installStatus=row.observed_install_status,
                    appliedPromptHash=row.observed_prompt_hash,
                    appliedSkillSetHash=row.observed_skill_set_hash,
                    lastError=row.last_error,
                )
            )

    @staticmethod
    def _install_curated_skill_repo(
        *,
        destination_dir: Path,
        source_uri: str,
        pinned_revision: str | None,
    ) -> None:
        destination_dir.parent.mkdir(parents=True, exist_ok=True)
        if destination_dir.exists():
            subprocess.run(["git", "-C", str(destination_dir), "pull", "--ff-only"], check=True)
        else:
            subprocess.run(["git", "clone", "--depth", "1", source_uri, str(destination_dir)], check=True)
        if pinned_revision:
            subprocess.run(["git", "-C", str(destination_dir), "checkout", pinned_revision], check=True)

    async def _process_refresh_required(self, item: AgentOnboardingItemRecord) -> dict[str, object]:
        platform_id = item.platform_id
        provider_account_id = str(item.payload.get("providerAccountId") or "account-unknown")

        async with self.session_factory() as session:
            account = await self._get_or_create_account(session=session, item=item, status=AgentConnectedAccountStatus.refresh_required)
            account.provider_account_label = str(item.payload.get("providerAccountLabel") or "").strip() or account.provider_account_label
            account.status = AgentConnectedAccountStatus.refresh_required
            account.scope_hash = str(item.payload.get("scopeHash") or "").strip() or account.scope_hash
            account.updated_at = _utcnow()

            onboarding_item = await session.get(AgentOnboardingItem, item.id)
            if onboarding_item is not None:
                onboarding_item.status = AgentOnboardingItemStatus.completed
                onboarding_item.delivery_envelope_json = _purged_delivery_envelope_metadata(item.delivery_envelope)
                onboarding_item.completed_at = _utcnow()
                onboarding_item.updated_at = _utcnow()

            session.add(
                AuditEvent(
                    event_type="connection.refresh_required",
                    entity_type="connected_account",
                    entity_id=f"{platform_id}:{provider_account_id}",
                    payload_json={
                        "platformId": platform_id,
                        "providerAccountId": provider_account_id,
                        "providerAccountLabel": str(item.payload.get("providerAccountLabel") or "").strip() or None,
                        "scopeHash": str(item.payload.get("scopeHash") or "").strip() or None,
                        "reason": "remote_refresh_required",
                    },
                )
            )
            await session.commit()

        await self._sync_local_runtime_connector(
            platform_id=platform_id,
            provider_account_id=provider_account_id,
            payload=item.payload,
            account_status=AgentConnectedAccountStatus.refresh_required,
        )

        return {
            "platformId": platform_id,
            "providerAccountId": provider_account_id,
            "accountStatus": AgentConnectedAccountStatus.refresh_required.value,
        }

    async def _process_disconnect_requested(self, item: AgentOnboardingItemRecord) -> dict[str, object]:
        platform_id = item.platform_id
        provider_account_id = str(item.payload.get("providerAccountId") or "account-unknown")
        deleted_secret_keys = _delete_local_secrets(
            secret_store=self.secret_store,
            platform_id=platform_id,
            provider_account_id=provider_account_id,
        )

        async with self.session_factory() as session:
            account = await self._get_or_create_account(session=session, item=item, status=AgentConnectedAccountStatus.disconnected)
            account.provider_account_label = str(item.payload.get("providerAccountLabel") or "").strip() or account.provider_account_label
            account.status = AgentConnectedAccountStatus.disconnected
            account.updated_at = _utcnow()

            onboarding_item = await session.get(AgentOnboardingItem, item.id)
            if onboarding_item is not None:
                onboarding_item.status = AgentOnboardingItemStatus.completed
                onboarding_item.delivery_envelope_json = _purged_delivery_envelope_metadata(item.delivery_envelope)
                onboarding_item.completed_at = _utcnow()
                onboarding_item.updated_at = _utcnow()

            session.add(
                AuditEvent(
                    event_type="connection.disconnected",
                    entity_type="connected_account",
                    entity_id=f"{platform_id}:{provider_account_id}",
                    payload_json={
                        "platformId": platform_id,
                        "providerAccountId": provider_account_id,
                        "providerAccountLabel": str(item.payload.get("providerAccountLabel") or "").strip() or None,
                        "deletedSecretKeys": deleted_secret_keys,
                    },
                )
            )
            await session.commit()

        await self._sync_local_runtime_connector(
            platform_id=platform_id,
            provider_account_id=provider_account_id,
            payload=item.payload,
            account_status=AgentConnectedAccountStatus.disconnected,
        )

        return {
            "platformId": platform_id,
            "providerAccountId": provider_account_id,
            "accountStatus": AgentConnectedAccountStatus.disconnected.value,
            "deletedSecretKeys": deleted_secret_keys,
        }

    async def _process_connection_health_check(self, item: AgentOnboardingItemRecord) -> dict[str, object]:
        platform_id = item.platform_id
        provider_account_id = str(item.payload.get("providerAccountId") or "account-unknown")
        health = await perform_connected_account_health_check(
            config_store=self.config_store,
            secret_store=self.secret_store,
            platform_id=platform_id,
            provider_account_id=provider_account_id,
        )

        async with self.session_factory() as session:
            account = await self._get_or_create_account(
                session=session,
                item=item,
                status=AgentConnectedAccountStatus.refresh_required
                if health.status != AgentConnectedAccountStatus.active.value
                else AgentConnectedAccountStatus.active,
            )
            if health.provider_account_label:
                account.provider_account_label = health.provider_account_label
            account.status = (
                AgentConnectedAccountStatus.active
                if health.status == AgentConnectedAccountStatus.active.value
                else AgentConnectedAccountStatus.refresh_required
            )
            account.updated_at = _utcnow()
            if account.status is AgentConnectedAccountStatus.active:
                account.last_validated_at = _utcnow()

            onboarding_item = await session.get(AgentOnboardingItem, item.id)
            if onboarding_item is not None:
                onboarding_item.status = AgentOnboardingItemStatus.completed
                onboarding_item.delivery_envelope_json = _purged_delivery_envelope_metadata(item.delivery_envelope)
                onboarding_item.completed_at = _utcnow()
                onboarding_item.updated_at = _utcnow()

            session.add(
                AuditEvent(
                    event_type="connection.health_check_performed",
                    entity_type="connected_account",
                    entity_id=f"{platform_id}:{provider_account_id}",
                    payload_json={
                        "platformId": platform_id,
                        "providerAccountId": provider_account_id,
                        "status": health.status,
                        "reason": health.reason,
                    },
                )
            )
            await session.commit()

        await self._push_remote_account_status(
            platform_id=platform_id,
            provider_account_id=provider_account_id,
            status=health.status,
            status_reason=health.reason,
            provider_account_label=health.provider_account_label or str(item.payload.get("providerAccountLabel") or "").strip() or None,
            connection_name=str(item.payload.get("connectionName") or "").strip() or None,
        )
        return {
            "platformId": platform_id,
            "providerAccountId": provider_account_id,
            "accountStatus": health.status,
            "statusReason": health.reason,
        }

    async def _run_provider_token_health_check(self) -> None:
        async with self.session_factory() as session:
            account_rows = (
                await session.execute(
                    select(AgentConnectedAccount).where(AgentConnectedAccount.status == AgentConnectedAccountStatus.active)
                )
            ).scalars().all()
            for account in account_rows:
                if _has_active_local_access_token(
                    secret_store=self.secret_store,
                    platform_id=account.platform_id,
                    provider_account_id=account.provider_account_id,
                ):
                    continue
                refreshed = await refresh_connected_account_access_token(
                    secret_store=self.secret_store,
                    platform_id=account.platform_id,
                    provider_account_id=account.provider_account_id,
                )
                if refreshed.refreshed:
                    account.last_validated_at = _utcnow()
                    account.updated_at = _utcnow()
                    await self._push_remote_account_status(
                        platform_id=account.platform_id,
                        provider_account_id=account.provider_account_id,
                        status=AgentConnectedAccountStatus.active.value,
                        status_reason=refreshed.reason or "token_refreshed",
                        provider_account_label=account.provider_account_label,
                        connection_name=account.connection_name,
                    )
                    continue
                refresh_reason = refreshed.reason or "token_missing_or_refresh_failed"
                account.status = AgentConnectedAccountStatus.refresh_required
                account.updated_at = _utcnow()
                await self._push_remote_account_status(
                    platform_id=account.platform_id,
                    provider_account_id=account.provider_account_id,
                    status=AgentConnectedAccountStatus.refresh_required.value,
                    status_reason=refresh_reason,
                    provider_account_label=account.provider_account_label,
                    connection_name=account.connection_name,
                )
                session.add(
                    AuditEvent(
                        event_type="connection.health_check_failed",
                        entity_type="connected_account",
                        entity_id=f"{account.platform_id}:{account.provider_account_id}",
                        payload_json={
                            "platformId": account.platform_id,
                            "providerAccountId": account.provider_account_id,
                            "reason": refresh_reason,
                        },
                    )
                )
            await session.commit()

    async def _push_remote_account_status(
        self,
        *,
        platform_id: str,
        provider_account_id: str,
        status: str,
        status_reason: str,
        provider_account_label: str | None,
        connection_name: str | None,
    ) -> None:
        push_status = getattr(self.sync_api, "push_agent_connected_account_status", None)
        if not callable(push_status):
            return
        try:
            await push_status(
                AgentConnectedAccountStatusPayload(
                    platformId=platform_id,
                    providerAccountId=provider_account_id,
                    status=status,
                    statusReason=status_reason,
                    providerAccountLabel=provider_account_label,
                    connectionName=connection_name,
                )
            )
        except Exception:  # noqa: BLE001
            return

    async def _get_or_create_account(
        self,
        *,
        session: AsyncSession,
        item: AgentOnboardingItemRecord,
        status: AgentConnectedAccountStatus,
    ) -> AgentConnectedAccount:
        platform_id = item.platform_id
        provider_account_id = str(item.payload.get("providerAccountId") or "account-unknown")
        account = await session.scalar(
            select(AgentConnectedAccount).where(
                AgentConnectedAccount.platform_id == platform_id,
                AgentConnectedAccount.provider_account_id == provider_account_id,
            )
        )
        if account is not None:
            return account
        account = AgentConnectedAccount(
            workspace_id=str(item.payload.get("workspaceId") or "workspace-unknown"),
            target_installation_id=str(item.payload.get("targetInstallationId") or "installation-unknown"),
            platform_id=platform_id,
            provider_account_id=provider_account_id,
            provider_account_label=str(item.payload.get("providerAccountLabel") or "").strip() or None,
            connection_name=str(item.payload.get("connectionName") or f"{platform_id}:{provider_account_id}"),
            status=status,
            scope_hash=str(item.payload.get("scopeHash") or "").strip() or None,
        )
        session.add(account)
        return account

    async def _sync_local_runtime_connector(
        self,
        *,
        platform_id: str,
        provider_account_id: str,
        payload: dict[str, object],
        account_status: AgentConnectedAccountStatus,
    ) -> None:
        if self.config_store is None:
            return
        try:
            platform = Platform(platform_id)
        except ValueError:
            return

        config = self.config_store.load() or AppConfig()
        runtime_secret_key = f"platform:{platform.value}:api_token"

        if account_status in {
            AgentConnectedAccountStatus.refresh_required,
            AgentConnectedAccountStatus.disconnected,
            AgentConnectedAccountStatus.revoked,
        }:
            self.secret_store.delete(runtime_secret_key)
            config.connectors.pop(platform.value, None)
            config.watch_profiles.pop(platform.value, None)
            self.config_store.save(config)
            await sync_config_credentials_to_db(self.session_factory, config)
            return

        runtime_base_url = _resolve_runtime_base_url(platform=platform, payload=payload)
        workspace_base_url = _resolve_workspace_base_url(platform=platform, payload=payload)
        runtime_access_token = str(
            self.secret_store.get(f"platform:{platform_id}:{provider_account_id}:access_token") or ""
        ).strip()
        if not runtime_base_url or not workspace_base_url or not runtime_access_token:
            return

        self.secret_store.save(runtime_secret_key, runtime_access_token)
        config.connectors[platform.value] = ConnectorConfig(
            baseUrl=workspace_base_url,
            apiBaseUrl=runtime_base_url if runtime_base_url != workspace_base_url else None,
            secretKey=runtime_secret_key,
        )
        if platform.value not in config.watch_profiles:
            config.watch_profiles[platform.value] = [_default_watch_profile(platform)]
        self.config_store.save(config)
        await sync_config_credentials_to_db(self.session_factory, config)


def _store_delivery_secrets(
    *,
    secret_store: SecretStore,
    platform_id: str,
    provider_account_id: str,
    delivery_envelope: dict[str, object],
) -> list[str]:
    stored_secret_keys: list[str] = []
    for secret_key, secret_value in _iter_delivery_secret_entries(delivery_envelope):
        secret_store.save(f"platform:{platform_id}:{provider_account_id}:{secret_key}", secret_value)
        stored_secret_keys.append(secret_key)
    return stored_secret_keys


def _delete_local_secrets(
    *,
    secret_store: SecretStore,
    platform_id: str,
    provider_account_id: str,
) -> list[str]:
    deleted_secret_keys: list[str] = []
    for secret_key in ("access_token", "refresh_token", "oauth_code", "pkce_verifier"):
        storage_key = f"platform:{platform_id}:{provider_account_id}:{secret_key}"
        if secret_store.get(storage_key) is None:
            continue
        secret_store.delete(storage_key)
        deleted_secret_keys.append(secret_key)
    return deleted_secret_keys


def _iter_delivery_secret_entries(delivery_envelope: dict[str, object]) -> list[tuple[str, str]]:
    mappings = [
        ("oauthCode", "oauth_code"),
        ("pkceVerifier", "pkce_verifier"),
        ("accessToken", "access_token"),
        ("refreshToken", "refresh_token"),
        ("oauthClientSecret", "oauth_client_secret"),
        ("encryptedAccessToken", "access_token"),
        ("encryptedRefreshToken", "refresh_token"),
        ("encryptedClientSecret", "oauth_client_secret"),
    ]
    entries: list[tuple[str, str]] = []
    for source_key, target_key in mappings:
        value = str(delivery_envelope.get(source_key) or "").strip()
        if value:
            entries.append((target_key, value))
    return entries


def _store_engine_api_keys(
    *,
    secret_store: SecretStore,
    delivery_envelope: dict[str, object],
) -> list[str]:
    stored_secret_keys: list[str] = []
    for source_key, secret_key in (
        ("geminiApiKey", "engine:gemini:api_key"),
        ("openaiApiKey", "engine:openai:api_key"),
        ("anthropicApiKey", "engine:anthropic:api_key"),
    ):
        value = str(delivery_envelope.get(source_key) or "").strip()
        if not value:
            continue
        secret_store.save(secret_key, value)
        stored_secret_keys.append(secret_key)
    return stored_secret_keys


def _purged_delivery_envelope_metadata(delivery_envelope: dict[str, object]) -> dict[str, object]:
    secret_keys = {
        "oauthCode",
        "pkceVerifier",
        "accessToken",
        "refreshToken",
        "encryptedAccessToken",
        "encryptedRefreshToken",
        "encryptedPkceVerifier",
        "geminiApiKey",
        "openaiApiKey",
        "anthropicApiKey",
        "encryptedGeminiApiKey",
        "encryptedOpenaiApiKey",
        "encryptedAnthropicApiKey",
    }
    sanitized = {
        key: value
        for key, value in delivery_envelope.items()
        if key not in secret_keys
    }
    if any(key in delivery_envelope for key in secret_keys):
        sanitized["deliveryMode"] = sanitized.get("deliveryMode") or _infer_delivery_mode(delivery_envelope)
        sanitized["purged"] = True
    return sanitized


def _infer_delivery_mode(delivery_envelope: dict[str, object]) -> str | None:
    if str(delivery_envelope.get("deliveryMode") or "").strip():
        return str(delivery_envelope.get("deliveryMode") or "").strip()
    if any(
        str(delivery_envelope.get(key) or "").strip()
        for key in ("oauthCode", "pkceVerifier", "encryptedPkceVerifier")
    ):
        return "authorization_code"
    if any(
        str(delivery_envelope.get(key) or "").strip()
        for key in ("accessToken", "refreshToken", "encryptedAccessToken", "encryptedRefreshToken")
    ):
        return "token_bundle"
    return None


def _has_active_local_access_token(
    *,
    secret_store: SecretStore,
    platform_id: str,
    provider_account_id: str,
) -> bool:
    access_token = secret_store.get(f"platform:{platform_id}:{provider_account_id}:access_token")
    if not access_token:
        return False
    expires_at = str(
        secret_store.get(f"platform:{platform_id}:{provider_account_id}:access_token_expires_at") or ""
    ).strip()
    if not expires_at:
        return True
    try:
        parsed = datetime.fromisoformat(expires_at)
    except ValueError:
        return True
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed > datetime.now(UTC)


async def refresh_connected_account_access_token(
    *,
    secret_store: SecretStore,
    platform_id: str,
    provider_account_id: str,
) -> RefreshAttemptOutcome:
    access_token_present = bool(
        str(secret_store.get(f"platform:{platform_id}:{provider_account_id}:access_token") or "").strip()
    )
    refresh_token = str(
        secret_store.get(f"platform:{platform_id}:{provider_account_id}:refresh_token") or ""
    ).strip()
    token_url = str(secret_store.get(f"platform:{platform_id}:{provider_account_id}:token_url") or "").strip()
    client_id = str(secret_store.get(f"platform:{platform_id}:{provider_account_id}:oauth_client_id") or "").strip()
    client_secret = str(
        secret_store.get(f"platform:{platform_id}:{provider_account_id}:oauth_client_secret") or ""
    ).strip() or None
    if not refresh_token or not token_url or not client_id:
        if not refresh_token:
            return RefreshAttemptOutcome(
                refreshed=False,
                reason="token_expired_refresh_unavailable" if access_token_present else "token_missing",
            )
        return RefreshAttemptOutcome(refreshed=False, reason="refresh_missing_metadata")

    try:
        payload, reason = await _request_refresh_token(
            platform_id=platform_id,
            token_url=token_url,
            refresh_token=refresh_token,
            client_id=client_id,
            client_secret=client_secret,
        )
    except httpx.HTTPError:
        return RefreshAttemptOutcome(refreshed=False, reason="refresh_network_error")
    if reason:
        return RefreshAttemptOutcome(refreshed=False, reason=reason)
    access_token = str(payload.get("access_token") or "").strip()
    if not access_token:
        return RefreshAttemptOutcome(refreshed=False, reason="refresh_response_invalid")
    secret_store.save(f"platform:{platform_id}:{provider_account_id}:access_token", access_token)
    secret_store.save(f"platform:{platform_id}:api_token", access_token)
    next_refresh_token = str(payload.get("refresh_token") or "").strip()
    if next_refresh_token:
        secret_store.save(f"platform:{platform_id}:{provider_account_id}:refresh_token", next_refresh_token)
    expires_at = _compute_expires_at(payload)
    if expires_at:
        secret_store.save(f"platform:{platform_id}:{provider_account_id}:access_token_expires_at", expires_at)
    return RefreshAttemptOutcome(
        refreshed=True,
        reason="token_refreshed",
        payload={
            "accessToken": access_token,
            **({"refreshToken": next_refresh_token} if next_refresh_token else {}),
            **({"accessTokenExpiresAt": expires_at} if expires_at else {}),
        },
    )


async def _request_refresh_token(
    *,
    platform_id: str,
    token_url: str,
    refresh_token: str,
    client_id: str,
    client_secret: str | None,
) -> tuple[dict[str, object], str | None]:
    if platform_id == Platform.NOTION.value and client_secret:
        import base64

        basic_auth = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
        async with httpx.AsyncClient(timeout=20.0) as client:
            response = await client.post(
                token_url,
                json={"grant_type": "refresh_token", "refresh_token": refresh_token},
                headers={"Authorization": f"Basic {basic_auth}"},
            )
    else:
        form_data = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": client_id,
            **({"client_secret": client_secret} if client_secret else {}),
        }
        async with httpx.AsyncClient(timeout=20.0) as client:
            response = await client.post(token_url, data=form_data)
    if response.status_code >= 400:
        payload = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
        error_code = str(payload.get("error") if isinstance(payload, dict) else "").strip().lower()
        if error_code == "invalid_grant":
            return {}, "refresh_invalid_grant"
        if response.status_code in {401, 403}:
            return {}, "refresh_unauthorized"
        return {}, "refresh_http_error"
    payload = response.json()
    return (payload if isinstance(payload, dict) else {}, None)


def _compute_expires_at(payload: dict[str, object]) -> str | None:
    raw_value = payload.get("expires_in")
    try:
        expires_in = int(raw_value)
    except (TypeError, ValueError):
        return None
    if expires_in <= 0:
        return None
    return (datetime.now(UTC) + timedelta(seconds=expires_in)).isoformat()


def _store_payload_runtime_metadata(
    *,
    secret_store: SecretStore,
    platform_id: str,
    provider_account_id: str,
    payload: dict[str, object],
) -> list[str]:
    mappings = [
        ("oauthClientId", "oauth_client_id"),
        ("tokenUrl", "token_url"),
        ("accessTokenExpiresAt", "access_token_expires_at"),
    ]
    stored_keys: list[str] = []
    for source_key, storage_key_suffix in mappings:
        value = str(payload.get(source_key) or "").strip()
        if not value:
            continue
        secret_store.save(f"platform:{platform_id}:{provider_account_id}:{storage_key_suffix}", value)
        stored_keys.append(storage_key_suffix)
    return stored_keys


def _default_watch_profile(platform: Platform) -> WatchProfile:
    return WatchProfile(
        enabled=True,
        platform=platform,
        preset=WatchProfilePreset.personal_inbox,
        scope={},
        personalSignals=[],
        optionalKeywords=[],
        pollInterval=60,
        lookbackWindow=120,
    )


def _resolve_runtime_base_url(*, platform: Platform, payload: dict[str, object]) -> str | None:
    explicit_api_base_url = str(payload.get("apiBaseUrl") or "").strip()
    if explicit_api_base_url:
        return explicit_api_base_url
    explicit_base_url = str(payload.get("baseUrl") or "").strip()
    if explicit_base_url:
        return explicit_base_url
    defaults = {
        Platform.NOTION: "https://api.notion.com",
        Platform.LINEAR: "https://api.linear.app",
        Platform.GMAIL: "https://www.googleapis.com",
        Platform.GOOGLE_CALENDAR: "https://www.googleapis.com",
        Platform.GOOGLE_DRIVE: "https://www.googleapis.com",
        Platform.ASANA: "https://app.asana.com",
        Platform.DISCORD: "https://discord.com",
        Platform.MICROSOFT_TEAMS: "https://graph.microsoft.com",
        Platform.GITLAB: "https://gitlab.com",
        Platform.TRELLO: "https://api.trello.com",
    }
    return defaults.get(platform)


def _resolve_workspace_base_url(*, platform: Platform, payload: dict[str, object]) -> str | None:
    explicit_base_url = str(payload.get("baseUrl") or "").strip()
    if explicit_base_url:
        return explicit_base_url
    return _resolve_runtime_base_url(platform=platform, payload=payload)
