from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.enums import ConnectorType
from workagent.db.models import AuditEvent, SyncCursor


class SqlAlchemyCursorStore:
    def __init__(self, *, session_factory: async_sessionmaker[AsyncSession], connector_type: ConnectorType) -> None:
        self.session_factory = session_factory
        self.connector_type = connector_type

    async def load(self) -> str | None:
        async with self.session_factory() as session:
            row = await session.get(SyncCursor, self.connector_type.value)
            return None if row is None else row.cursor_value

    async def save(self, cursor: str | None) -> None:
        async with self.session_factory() as session:
            row = await session.get(SyncCursor, self.connector_type.value)
            if row is None:
                session.add(
                    SyncCursor(
                        connector_type=self.connector_type.value,
                        cursor_value=cursor,
                        metadata_json={},
                    )
                )
            else:
                row.cursor_value = cursor
            await session.commit()


class SlackSeenStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def has_seen(self, channel_id: str, message_ts: str) -> bool:
        entity_id = f"{channel_id}:{message_ts}"
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(AuditEvent).where(
                        AuditEvent.event_type == "slack.sync.seen",
                        AuditEvent.entity_type == "slack_message",
                        AuditEvent.entity_id == entity_id,
                    )
                )
            ).scalar_one_or_none()
            return row is not None

    async def mark_seen(self, channel_id: str, message_ts: str) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="slack.sync.seen",
                    entity_type="slack_message",
                    entity_id=f"{channel_id}:{message_ts}",
                    payload_json={"channelId": channel_id, "messageTs": message_ts},
                )
            )
            await session.commit()


class GitLabSeenStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def has_seen(self, event_id: str) -> bool:
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(AuditEvent).where(
                        AuditEvent.event_type == "gitlab.sync.seen",
                        AuditEvent.entity_type == "gitlab_event",
                        AuditEvent.entity_id == event_id,
                    )
                )
            ).scalar_one_or_none()
            return row is not None

    async def mark_seen(self, event_id: str) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="gitlab.sync.seen",
                    entity_type="gitlab_event",
                    entity_id=event_id,
                    payload_json={"eventId": event_id},
                )
            )
            await session.commit()


class JiraSeenStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def has_seen(self, event_id: str) -> bool:
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(AuditEvent).where(
                        AuditEvent.event_type == "jira.sync.seen",
                        AuditEvent.entity_type == "jira_event",
                        AuditEvent.entity_id == event_id,
                    )
                )
            ).scalar_one_or_none()
            return row is not None

    async def mark_seen(self, event_id: str) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="jira.sync.seen",
                    entity_type="jira_event",
                    entity_id=event_id,
                    payload_json={"eventId": event_id},
                )
            )
            await session.commit()


class ConfluenceSeenStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def has_seen(self, event_id: str) -> bool:
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(AuditEvent).where(
                        AuditEvent.event_type == "confluence.sync.seen",
                        AuditEvent.entity_type == "confluence_event",
                        AuditEvent.entity_id == event_id,
                    )
                )
            ).scalar_one_or_none()
            return row is not None

    async def mark_seen(self, event_id: str) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="confluence.sync.seen",
                    entity_type="confluence_event",
                    entity_id=event_id,
                    payload_json={"eventId": event_id},
                )
            )
            await session.commit()


class NotionSeenStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def has_seen(self, event_id: str) -> bool:
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(AuditEvent).where(
                        AuditEvent.event_type == "notion.sync.seen",
                        AuditEvent.entity_type == "notion_event",
                        AuditEvent.entity_id == event_id,
                    )
                )
            ).scalar_one_or_none()
            return row is not None

    async def mark_seen(self, event_id: str) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="notion.sync.seen",
                    entity_type="notion_event",
                    entity_id=event_id,
                    payload_json={"eventId": event_id},
                )
            )
            await session.commit()


class AsanaSeenStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def has_seen(self, event_id: str) -> bool:
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(AuditEvent).where(
                        AuditEvent.event_type == "asana.sync.seen",
                        AuditEvent.entity_type == "asana_event",
                        AuditEvent.entity_id == event_id,
                    )
                )
            ).scalar_one_or_none()
            return row is not None

    async def mark_seen(self, event_id: str) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="asana.sync.seen",
                    entity_type="asana_event",
                    entity_id=event_id,
                    payload_json={"eventId": event_id},
                )
            )
            await session.commit()


class LinearSeenStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def has_seen(self, event_id: str) -> bool:
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(AuditEvent).where(
                        AuditEvent.event_type == "linear.sync.seen",
                        AuditEvent.entity_type == "linear_event",
                        AuditEvent.entity_id == event_id,
                    )
                )
            ).scalar_one_or_none()
            return row is not None

    async def mark_seen(self, event_id: str) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="linear.sync.seen",
                    entity_type="linear_event",
                    entity_id=event_id,
                    payload_json={"eventId": event_id},
                )
            )
            await session.commit()


class GmailSeenStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def has_seen(self, event_id: str) -> bool:
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(AuditEvent).where(
                        AuditEvent.event_type == "gmail.sync.seen",
                        AuditEvent.entity_type == "gmail_event",
                        AuditEvent.entity_id == event_id,
                    )
                )
            ).scalar_one_or_none()
            return row is not None

    async def mark_seen(self, event_id: str) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="gmail.sync.seen",
                    entity_type="gmail_event",
                    entity_id=event_id,
                    payload_json={"eventId": event_id},
                )
            )
            await session.commit()


class GoogleCalendarSeenStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def has_seen(self, event_id: str) -> bool:
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(AuditEvent).where(
                        AuditEvent.event_type == "google_calendar.sync.seen",
                        AuditEvent.entity_type == "google_calendar_event",
                        AuditEvent.entity_id == event_id,
                    )
                )
            ).scalar_one_or_none()
            return row is not None

    async def mark_seen(self, event_id: str) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="google_calendar.sync.seen",
                    entity_type="google_calendar_event",
                    entity_id=event_id,
                    payload_json={"eventId": event_id},
                )
            )
            await session.commit()


class GoogleDriveSeenStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def has_seen(self, event_id: str) -> bool:
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(AuditEvent).where(
                        AuditEvent.event_type == "google_drive.sync.seen",
                        AuditEvent.entity_type == "google_drive_event",
                        AuditEvent.entity_id == event_id,
                    )
                )
            ).scalar_one_or_none()
            return row is not None

    async def mark_seen(self, event_id: str) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="google_drive.sync.seen",
                    entity_type="google_drive_event",
                    entity_id=event_id,
                    payload_json={"eventId": event_id},
                )
            )
            await session.commit()


class ZendeskSeenStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def has_seen(self, event_id: str) -> bool:
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(AuditEvent).where(
                        AuditEvent.event_type == "zendesk.sync.seen",
                        AuditEvent.entity_type == "zendesk_event",
                        AuditEvent.entity_id == event_id,
                    )
                )
            ).scalar_one_or_none()
            return row is not None

    async def mark_seen(self, event_id: str) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="zendesk.sync.seen",
                    entity_type="zendesk_event",
                    entity_id=event_id,
                    payload_json={"eventId": event_id},
                )
            )
            await session.commit()


class DiscordSeenStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def has_seen(self, event_id: str) -> bool:
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(AuditEvent).where(
                        AuditEvent.event_type == "discord.sync.seen",
                        AuditEvent.entity_type == "discord_event",
                        AuditEvent.entity_id == event_id,
                    )
                )
            ).scalar_one_or_none()
            return row is not None

    async def mark_seen(self, event_id: str) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="discord.sync.seen",
                    entity_type="discord_event",
                    entity_id=event_id,
                    payload_json={"eventId": event_id},
                )
            )
            await session.commit()


class MicrosoftTeamsSeenStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def has_seen(self, event_id: str) -> bool:
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(AuditEvent).where(
                        AuditEvent.event_type == "microsoft_teams.sync.seen",
                        AuditEvent.entity_type == "microsoft_teams_event",
                        AuditEvent.entity_id == event_id,
                    )
                )
            ).scalar_one_or_none()
            return row is not None

    async def mark_seen(self, event_id: str) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="microsoft_teams.sync.seen",
                    entity_type="microsoft_teams_event",
                    entity_id=event_id,
                    payload_json={"eventId": event_id},
                )
            )
            await session.commit()
