from __future__ import annotations

import json
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ActionProposal:
    kind: str
    target_ref: dict[str, object]
    content: str
    reason: str
    payload: dict[str, object]


class ActionParser:
    ACTION_START = "---ACTION_PROPOSAL---"
    ACTION_END = "---END_ACTION_PROPOSAL---"

    def parse(self, text: str) -> tuple[ActionProposal | None, str]:
        normalized = str(text or "").strip()
        if self.ACTION_START not in normalized or self.ACTION_END not in normalized:
            return None, normalized

        before, remainder = normalized.split(self.ACTION_START, 1)
        action_block, after = remainder.split(self.ACTION_END, 1)
        action = self._parse_action_block(action_block.strip())
        sections = [segment.strip() for segment in (before, action.reason, after) if segment.strip()]
        return action, "\n\n".join(sections)

    def _parse_action_block(self, block_text: str) -> ActionProposal:
        values: dict[str, object] = {}
        lines = block_text.splitlines()
        index = 0
        while index < len(lines):
            raw_line = lines[index].rstrip()
            stripped = raw_line.strip()
            index += 1
            if not stripped:
                continue
            key, _, value = stripped.partition(":")
            if not _:
                raise ValueError(f"invalid action line: {raw_line}")
            key = key.strip()
            value = value.strip()
            if value == "|":
                content_lines: list[str] = []
                while index < len(lines):
                    next_line = lines[index]
                    if next_line.startswith("  ") or next_line.startswith("\t"):
                        content_lines.append(next_line.lstrip())
                        index += 1
                        continue
                    if not next_line.strip():
                        content_lines.append("")
                        index += 1
                        continue
                    break
                values[key] = "\n".join(content_lines).strip()
                continue
            if key in {"target", "payload"}:
                values[key] = json.loads(value) if value else {}
                continue
            values[key] = value

        kind = str(values.get("kind") or "").strip()
        content = str(values.get("content") or "").strip()
        reason = str(values.get("reason") or "").strip()
        target_ref = dict(values.get("target") or {})
        payload = dict(values.get("payload") or {})
        if not payload:
            payload = {**target_ref, "text": content}
        if not kind or not content or not reason:
            raise ValueError("action proposal requires kind, content, and reason")
        return ActionProposal(
            kind=kind,
            target_ref=target_ref,
            content=content,
            reason=reason,
            payload=payload,
        )
