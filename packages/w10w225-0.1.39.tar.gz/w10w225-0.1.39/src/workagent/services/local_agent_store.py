from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path


class LocalAgentStore:
    """Stores agent definitions + skills received from nk304 to ~/.personal-work-agent/agents/{agent_id}/"""

    def __init__(self, agents_dir: Path) -> None:
        self.agents_dir = agents_dir

    def _safe_path(self, *parts: str) -> Path | None:
        base = self.agents_dir.resolve()
        candidate = base.joinpath(*parts).resolve()
        if candidate.is_relative_to(base):
            return candidate
        return None

    def save_agent(
        self,
        agent_id: str,
        agent_prompt: str,
        skills: list[dict],
        version: int,
        content_hash: str,
    ) -> None:
        agent_dir = self._safe_path(agent_id)
        if agent_dir is None:
            return
        skills_dir = agent_dir / "skills"
        skills_dir.mkdir(parents=True, exist_ok=True)

        (agent_dir / "agent.md").write_text(agent_prompt, encoding="utf-8")

        # Remove old skills and write fresh
        for existing in skills_dir.glob("*.md"):
            existing.unlink()
        for skill in skills:
            skill_id = skill.get("skillId", "unknown")
            content = skill.get("contentText", "")
            if content:
                skill_file = self._safe_path(agent_id, "skills", f"{skill_id}.md")
                if skill_file is not None:
                    skill_file.write_text(content, encoding="utf-8")

        meta = {
            "version": version,
            "contentHash": content_hash,
            "skillIds": [s.get("skillId") for s in skills],
            "updatedAt": datetime.now(UTC).isoformat(),
        }
        (agent_dir / "meta.json").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")

    def load_agent_prompt(self, agent_id: str) -> str | None:
        agent_file = self._safe_path(agent_id, "agent.md")
        if agent_file is None:
            return None
        if agent_file.exists():
            return agent_file.read_text(encoding="utf-8")
        return None

    def load_skills(self, agent_id: str) -> list[str]:
        skills_dir = self._safe_path(agent_id, "skills")
        if skills_dir is None:
            return []
        if not skills_dir.exists():
            return []
        return [f.read_text(encoding="utf-8") for f in sorted(skills_dir.glob("*.md"))]

    def is_up_to_date(self, agent_id: str, content_hash: str) -> bool:
        meta_file = self._safe_path(agent_id, "meta.json")
        if meta_file is None:
            return False
        if not meta_file.exists():
            return False
        try:
            meta = json.loads(meta_file.read_text(encoding="utf-8"))
            return meta.get("contentHash") == content_hash
        except (json.JSONDecodeError, OSError):
            return False
