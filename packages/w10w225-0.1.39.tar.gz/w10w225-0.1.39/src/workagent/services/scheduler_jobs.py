from __future__ import annotations

from datetime import UTC, datetime

from croniter import croniter
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.models import ScheduledJob
from workagent.scheduler.service import compute_next_run


class SchedulerJobService:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def create_job(
        self,
        *,
        name: str,
        cron_expression: str,
        payload_json: dict,
        now: datetime,
    ) -> ScheduledJob:
        if not croniter.is_valid(cron_expression):
            raise ValueError("invalid cron expression")
        async with self.session_factory() as session:
            job = ScheduledJob(
                name=name,
                cron_expression=cron_expression,
                is_enabled=True,
                next_run_at=compute_next_run(cron_expression, now),
                payload_json=payload_json,
            )
            session.add(job)
            await session.commit()
            await session.refresh(job)
            job.next_run_at = _normalize_datetime(job.next_run_at)
            return job

    async def list_jobs(self) -> list[ScheduledJob]:
        async with self.session_factory() as session:
            jobs = (
                await session.execute(select(ScheduledJob).order_by(ScheduledJob.name.asc()))
            ).scalars().all()
        for job in jobs:
            job.next_run_at = _normalize_datetime(job.next_run_at)
        return jobs

    async def set_enabled(self, job_id: str, is_enabled: bool) -> ScheduledJob:
        async with self.session_factory() as session:
            job = await session.get(ScheduledJob, job_id)
            if job is None:
                raise ValueError(f"scheduled job not found: {job_id}")
            job.is_enabled = is_enabled
            await session.commit()
            await session.refresh(job)
            job.next_run_at = _normalize_datetime(job.next_run_at)
            return job


def _normalize_datetime(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value
