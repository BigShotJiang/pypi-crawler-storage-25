from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path


class FileMemoryStore:
    """
    File-based long-term memory for the local agent.
    Stores conversation summaries and decisions in ~/.personal-work-agent/memory/MEMORY.md.
    Included in prompts so the agent has context from past interactions.
    """

    MAX_MEMORY_CHARS = 200_000  # ~200KB, roughly 300+ conversation summaries

    def __init__(self, memory_dir: Path) -> None:
        self.memory_dir = memory_dir
        self.memory_file = memory_dir / "MEMORY.md"

    def _ensure_dir(self) -> None:
        self.memory_dir.mkdir(parents=True, exist_ok=True)

    def read(self) -> str:
        """Read the full memory content. Returns empty string if no memory exists."""
        if not self.memory_file.exists():
            return ""
        content = self.memory_file.read_text(encoding="utf-8")
        return content

    def read_recent(self, max_chars: int = 20_000) -> str:
        """Read the most recent memory entries, truncated to max_chars."""
        content = self.read()
        if len(content) <= max_chars:
            return content
        # Keep the tail (most recent entries)
        truncated = content[-max_chars:]
        # Find the first complete entry boundary
        marker = "\n## "
        idx = truncated.find(marker)
        if idx > 0:
            truncated = truncated[idx:]
        return f"(... older entries truncated ...)\n{truncated}"

    def append(
        self,
        *,
        summary: str,
        source: str = "chat",
        session_id: str | None = None,
        agent_id: str | None = None,
    ) -> None:
        """Append a memory entry after a completed interaction."""
        self._ensure_dir()
        timestamp = datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")
        entry_parts = [
            f"\n## [{timestamp}] {source}",
        ]
        if session_id:
            entry_parts.append(f"session: {session_id}")
        if agent_id:
            entry_parts.append(f"agent: {agent_id}")
        entry_parts.append(f"\n{summary.strip()}\n")
        entry = "\n".join(entry_parts)

        # Append to file
        with self.memory_file.open("a", encoding="utf-8") as f:
            f.write(entry)

        # Trim if too large
        self._trim_if_needed()

    def _trim_if_needed(self) -> None:
        """Remove oldest entries if the file exceeds MAX_MEMORY_CHARS."""
        if not self.memory_file.exists():
            return
        content = self.memory_file.read_text(encoding="utf-8")
        if len(content) <= self.MAX_MEMORY_CHARS:
            return
        # Keep the most recent portion
        trimmed = content[-(self.MAX_MEMORY_CHARS):]
        marker = "\n## "
        idx = trimmed.find(marker)
        if idx > 0:
            trimmed = trimmed[idx:]
        header = "# Agent Memory\n\n(older entries trimmed)\n"
        self.memory_file.write_text(header + trimmed, encoding="utf-8")

    def clear(self) -> None:
        """Clear all memory."""
        if self.memory_file.exists():
            self.memory_file.unlink()
