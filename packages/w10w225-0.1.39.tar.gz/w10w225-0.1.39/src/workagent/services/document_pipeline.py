from __future__ import annotations

from typing import TYPE_CHECKING, Any

from workagent.sync.models import AgentPendingItemRecord

if TYPE_CHECKING:
    from workagent.services.local_agent_store import LocalAgentStore


class DocumentPipeline:
    def __init__(self, *, executor, transport, agent_store: LocalAgentStore | None = None) -> None:  # noqa: ANN001
        self.executor = executor
        self.transport = transport
        self.agent_store = agent_store

    async def execute(self, pending_item: AgentPendingItemRecord) -> None:
        payload = pending_item.payload

        agent_id = payload.get("agent_id") or payload.get("agentId")
        agent_prompt = None
        skill_contents: list[str] = []
        if agent_id and self.agent_store:
            agent_prompt = self.agent_store.load_agent_prompt(str(agent_id))
            skill_contents = self.agent_store.load_skills(str(agent_id))

        prompt = self.build_document_prompt(
            instruction=str(payload.get("requestText") or "").strip(),
            input_documents=list(payload.get("inputDocuments") or payload.get("input_documents") or []),
            agent_prompt=agent_prompt,
            skill_contents=skill_contents,
        )
        result = await self.executor.run(prompt)
        workflow_payload = dict(payload.get("projectWorkflow") or {})
        await self.transport.push_project_workflow_stage_result(
            str(workflow_payload.get("workflowRunId") or "").strip(),
            {
                "targetInstallationId": str(payload.get("targetInstallationId") or "").strip(),
                "boardId": str(workflow_payload.get("projectId") or "").strip(),
                "stageId": str(workflow_payload.get("stageId") or "").strip(),
                "artifactKind": str(workflow_payload.get("artifactKind") or "").strip(),
                "contentText": result.text,
                "requestingUserId": str(payload.get("requestingUserId") or "").strip(),
                "localCaseId": str(payload.get("localCaseId") or "").strip() or pending_item.session_id or pending_item.id,
            },
        )

    @staticmethod
    def build_document_prompt(
        *,
        instruction: str,
        input_documents: list[dict[str, Any]],
        agent_prompt: str | None = None,
        skill_contents: list[str] | None = None,
    ) -> str:
        sections: list[str] = []
        if agent_prompt:
            sections.append(f"Agent Prompt:\n{agent_prompt.strip()}")
        if skill_contents:
            for i, skill in enumerate(skill_contents, 1):
                sections.append(f"Skill {i}:\n{skill.strip()}")
        sections.append(f"Instruction:\n{instruction.strip()}")
        document_sections = [
            f"[{str(document.get('title') or '').strip()}]\n{str(document.get('content') or '').strip()}"
            for document in input_documents
            if isinstance(document, dict)
            and str(document.get("title") or "").strip()
            and str(document.get("content") or "").strip()
        ]
        if document_sections:
            sections.append("Input Documents:\n" + "\n\n".join(document_sections))
        return "\n\n".join(section for section in sections if section.strip())
