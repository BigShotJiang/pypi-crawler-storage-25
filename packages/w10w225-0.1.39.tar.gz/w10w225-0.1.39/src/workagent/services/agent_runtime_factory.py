from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.config.store import ConfigStore, default_config_paths
from workagent.db.enums import ExecutionEngine
from workagent.db.models import AppSetting
from workagent.runtime.secrets import FileSecretStore, SecretStore
from workagent.services.agent_onboarding_sync import AgentOnboardingItemBatch, AgentOnboardingSyncService
from workagent.services.agent_pending_sync import AgentPendingItemBatch, AgentPendingItemSyncService
from workagent.sync.agent_runtime import AgentOnboardingSyncRuntime, AgentPendingSyncRuntime
from workagent.sync.agent_socket_transport import LocalAgentSocketTransport


class AgentPendingItemCursorStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def load(self) -> str | None:
        async with self.session_factory() as session:
            row = await session.get(AppSetting, "agent_pending_item_cursor")
            if row is None:
                return None
            return str(row.value_json.get("cursor") or "").strip() or None

    async def save(self, cursor: str | None) -> None:
        async with self.session_factory() as session:
            row = await session.get(AppSetting, "agent_pending_item_cursor")
            payload = {"cursor": cursor}
            if row is None:
                row = AppSetting(key="agent_pending_item_cursor", value_json=payload)
                session.add(row)
            else:
                row.value_json = payload
            await session.commit()


class AgentOnboardingItemCursorStore:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def load(self) -> str | None:
        async with self.session_factory() as session:
            row = await session.get(AppSetting, "agent_onboarding_item_cursor")
            if row is None:
                return None
            return str(row.value_json.get("cursor") or "").strip() or None

    async def save(self, cursor: str | None) -> None:
        async with self.session_factory() as session:
            row = await session.get(AppSetting, "agent_onboarding_item_cursor")
            payload = {"cursor": cursor}
            if row is None:
                row = AppSetting(key="agent_onboarding_item_cursor", value_json=payload)
                session.add(row)
            else:
                row.value_json = payload
            await session.commit()


class AgentPendingItemPoller:
    def __init__(self, *, client, cursor_store: AgentPendingItemCursorStore, limit: int = 20) -> None:  # noqa: ANN001
        self.client = client
        self.cursor_store = cursor_store
        self.limit = limit

    async def poll_once(self) -> AgentPendingItemBatch:
        previous_cursor = await self.cursor_store.load()
        response = await self.client.pull_agent_pending_items(cursor=previous_cursor, limit=self.limit)
        next_cursor = response.next_cursor if response.next_cursor is not None else previous_cursor
        return AgentPendingItemBatch(items=response.items, previous_cursor=previous_cursor, next_cursor=next_cursor)

    async def commit(self, batch: AgentPendingItemBatch) -> None:
        await self.cursor_store.save(batch.next_cursor)


class AgentOnboardingItemPoller:
    def __init__(self, *, client, cursor_store: AgentOnboardingItemCursorStore, limit: int = 20) -> None:  # noqa: ANN001
        self.client = client
        self.cursor_store = cursor_store
        self.limit = limit

    async def poll_once(self) -> AgentOnboardingItemBatch:
        previous_cursor = await self.cursor_store.load()
        response = await self.client.pull_agent_onboarding_items(cursor=previous_cursor, limit=self.limit)
        next_cursor = response.next_cursor if response.next_cursor is not None else previous_cursor
        return AgentOnboardingItemBatch(items=response.items, previous_cursor=previous_cursor, next_cursor=next_cursor)

    async def commit(self, batch: AgentOnboardingItemBatch) -> None:
        await self.cursor_store.save(batch.next_cursor)


def build_agent_socket_transport(
    review_client, *, initial_retry_delay_seconds: float = 5.0  # noqa: ANN001
) -> LocalAgentSocketTransport | None:
    if review_client is None:
        return None
    base_url = str(getattr(review_client, "_base_url", "") or "").strip()
    installation_id = str(getattr(review_client, "_target_installation_id", "") or "").strip()
    secret = str(getattr(review_client, "_local_agent_secret", "") or "").strip()
    if not base_url or not installation_id or not secret:
        return None
    return LocalAgentSocketTransport(
        base_url=base_url,
        installation_id=installation_id,
        secret=secret,
        initial_retry_delay_seconds=initial_retry_delay_seconds,
    )


def build_agent_pending_sync_runtime(
    *,
    session_factory: async_sessionmaker[AsyncSession],
    review_client,
    queue=None,  # noqa: ANN001
    request_router=None,  # noqa: ANN001
    execution_engine: ExecutionEngine = ExecutionEngine.codex_cli,
    socket_transport=None,  # noqa: ANN001
    memory_writer=None,  # noqa: ANN001
):
    if review_client is None or not hasattr(review_client, "pull_agent_pending_items"):
        return None
    return AgentPendingSyncRuntime(
        sync_service=AgentPendingItemSyncService(
            session_factory=session_factory,
            poller=AgentPendingItemPoller(
                client=review_client,
                cursor_store=AgentPendingItemCursorStore(session_factory),
            ),
            sync_api=review_client,
            request_router=request_router,
            execution_engine=execution_engine,
            queue=queue,
            memory_writer=memory_writer,
        ),
        socket_transport=socket_transport,
    )


def build_agent_onboarding_sync_runtime(
    *,
    session_factory: async_sessionmaker[AsyncSession],
    review_client,
    secret_store: SecretStore,
    socket_transport=None,  # noqa: ANN001
):
    if review_client is None or not hasattr(review_client, "pull_agent_onboarding_items"):
        return None
    config_store = (
        ConfigStore(default_config_paths(secret_store.path.parent))
        if isinstance(secret_store, FileSecretStore)
        else None
    )
    return AgentOnboardingSyncRuntime(
        sync_service=AgentOnboardingSyncService(
            session_factory=session_factory,
            poller=AgentOnboardingItemPoller(
                client=review_client,
                cursor_store=AgentOnboardingItemCursorStore(session_factory),
            ),
            sync_api=review_client,
            secret_store=secret_store,
            config_store=config_store,
        ),
        socket_transport=socket_transport,
    )
