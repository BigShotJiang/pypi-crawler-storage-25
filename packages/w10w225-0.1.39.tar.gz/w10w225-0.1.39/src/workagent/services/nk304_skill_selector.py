"""nk304 skill loader for the chat pipeline.

WBS 8-1-1 .. 8-2-2

Internal nk304 skills are always loaded (they are small and language-agnostic).
The LLM decides which ones to use based on the user's request.
Template variables (e.g. {{room_id}}) are rendered with actual payload values.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Skill directory layout
# ---------------------------------------------------------------------------

_DEFAULT_SKILLS_DIR = Path.home() / ".personal-work-agent" / "skills" / "internal"

_SKILL_IDS = ("nk304-chat", "nk304-memo", "nk304-ticket", "nk304-file", "nk304-user")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def select_nk304_skills(pending_item_payload: dict[str, Any]) -> list[str]:  # noqa: ARG001
    """Return all internal nk304 skill IDs.

    Internal skills are always loaded regardless of language or request content.
    They are small enough (a few KB each) that the token cost is negligible,
    and the LLM is better at deciding relevance than keyword matching.
    """
    return list(_SKILL_IDS)


def load_nk304_skill_contents(
    skill_ids: list[str],
    payload: dict[str, Any],
    *,
    skills_dir: Path | None = None,
) -> list[str]:
    """Load and render SKILL.md files for the given skill IDs.

    Template variables like ``{{room_id}}`` are replaced with values
    from the pending item payload.

    Parameters
    ----------
    skill_ids:
        Output of :func:`select_nk304_skills`.
    payload:
        The pending item payload (used for template variable substitution).
    skills_dir:
        Override the default external skills directory.

    Returns
    -------
    list[str]
        Rendered skill markdown contents.
    """
    base_dir = skills_dir or _DEFAULT_SKILLS_DIR
    template_vars = _build_template_vars(payload)
    contents: list[str] = []

    for skill_id in skill_ids:
        skill_file = base_dir / skill_id / "SKILL.md"
        if not skill_file.is_file():
            continue
        raw_text = skill_file.read_text(encoding="utf-8")
        rendered = _render_template(raw_text, template_vars)
        contents.append(rendered)

    return contents


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _build_template_vars(payload: dict[str, Any]) -> dict[str, str]:
    """Build the template variable mapping from the payload."""
    return {
        "room_id": str(payload.get("roomId") or "").strip(),
        "workspace_id": str(payload.get("workspaceId") or "").strip(),
        "user_id": str(
            payload.get("requestingUserId")
            or payload.get("replyingUserId")
            or ""
        ).strip(),
        "session_id": str(payload.get("sessionId") or "").strip(),
        "thread_id": str(payload.get("threadId") or "").strip(),
    }


def _render_template(text: str, variables: dict[str, str]) -> str:
    """Replace ``{{variable_name}}`` placeholders with actual values."""
    def _replacer(match: re.Match[str]) -> str:
        key = match.group(1).strip()
        return variables.get(key, match.group(0))

    return re.sub(r"\{\{(\s*\w+\s*)\}\}", _replacer, text)
