from __future__ import annotations

import logging
import re
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from typing import Any, Protocol
from urllib.parse import urlparse

from workagent.connectors.confluence_client import ConfluenceApiClient
from workagent.connectors.gitlab_client import GitLabApiClient
from workagent.connectors.jira_client import JiraApiClient
from workagent.connectors.slack_client import SlackApiClient
from workagent.connectors.slack_sync import SlackMessage
from workagent.services.prompting import REDACTED_KEYS

logger = logging.getLogger("workagent.tool_shim")


class AuditRecorder(Protocol):
    async def record(
        self,
        *,
        event_type: str,
        entity_type: str,
        entity_id: str,
        payload: dict[str, Any] | None = None,
    ) -> None: ...


class ReadToolShim(Protocol):
    name: str

    async def run(self, arguments: Mapping[str, Any]) -> dict[str, Any]: ...
type ToolShimServiceFactory = Callable[[], "ToolShimService | None"]


@dataclass(frozen=True, slots=True)
class ToolShimResult:
    tool_name: str
    data: dict[str, Any]


@dataclass(frozen=True, slots=True)
class ToolShimError(Exception):
    code: str
    message: str
    failure_kind: str = "fatal"

    def __str__(self) -> str:
        return self.message

    def as_dict(self) -> dict[str, str]:
        return {
            "code": self.code,
            "failureKind": self.failure_kind,
            "message": self.message,
        }


def manual_required_internal_url_error() -> ToolShimError:
    return ToolShimError(
        code="manual_required",
        message="The requested internal URL is inaccessible to the read-only tool shim and requires manual follow-up.",
        failure_kind="manual_required",
    )


class ToolShimService:
    def __init__(
        self,
        *,
        tools: Iterable[ReadToolShim],
        audit_service: AuditRecorder | None = None,
    ) -> None:
        self._tools = {tool.name: tool for tool in tools}
        self._audit_service = audit_service

    async def execute(self, tool_name: str, arguments: Mapping[str, Any]) -> ToolShimResult:
        tool = self._tools.get(tool_name)
        if tool is None:
            raise ToolShimError(code="tool_not_found", message=f"Unknown tool shim: {tool_name}")

        redacted_arguments = _redact_value(dict(arguments))
        logger.info("tool shim executing tool_name=%s arguments=%s", tool_name, redacted_arguments)
        try:
            raw_result = await tool.run(arguments)
            result = _redact_value(raw_result)
        except ToolShimError as exc:
            logger.warning("tool shim failed tool_name=%s code=%s message=%s", tool_name, exc.code, exc.message)
            await self._record(
                event_type="tool_shim.failed",
                entity_id=tool_name,
                payload={
                    "arguments": redacted_arguments,
                    "error": exc.as_dict(),
                    "status": "error",
                },
            )
            raise
        except Exception as exc:  # noqa: BLE001
            error = ToolShimError(code="tool_execution_failed", message=str(exc))
            logger.exception("tool shim failed tool_name=%s", tool_name)
            await self._record(
                event_type="tool_shim.failed",
                entity_id=tool_name,
                payload={
                    "arguments": redacted_arguments,
                    "error": error.as_dict(),
                    "status": "error",
                },
            )
            raise error from exc

        logger.info(
            "tool shim completed tool_name=%s result_summary=%s",
            tool_name,
            _result_summary(result),
        )
        await self._record(
            event_type="tool_shim.executed",
            entity_id=tool_name,
            payload={
                "arguments": redacted_arguments,
                "result": result,
                "status": "ok",
            },
        )
        return ToolShimResult(tool_name=tool_name, data=result)

    async def _record(self, *, event_type: str, entity_id: str, payload: dict[str, Any]) -> None:
        if self._audit_service is None:
            return
        await self._audit_service.record(
            event_type=event_type,
            entity_type="tool_shim",
            entity_id=entity_id,
            payload=payload,
        )


def _result_summary(result: dict[str, Any]) -> str:
    messages = result.get("messages")
    if isinstance(messages, list):
        return f"messages={len(messages)} nextCursor={'yes' if result.get('nextCursor') else 'no'}"
    if isinstance(result, dict):
        return "keys=" + ",".join(sorted(result.keys()))
    return type(result).__name__


class DynamicToolShimService:
    def __init__(self, *, service_factory: ToolShimServiceFactory) -> None:
        self._service_factory = service_factory

    async def execute(self, tool_name: str, arguments: Mapping[str, Any]) -> ToolShimResult:
        service = self._service_factory()
        if service is None:
            raise ToolShimError(code="tool_service_unconfigured", message="No connected read tools are configured.")
        return await service.execute(tool_name, arguments)


@dataclass(slots=True)
class SlackSearchTool:
    client: SlackApiClient
    token: str
    name: str = "slack_search"

    async def run(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        query = _require_str(arguments, "query")
        limit = _int_argument(arguments, "limit", default=20)
        result = self.client.search_messages(token=self.token, query=query, limit=limit)
        return {
            "messages": [_slack_message_to_dict(item) for item in result.get("messages", [])],
            "nextCursor": result.get("next_cursor"),
        }


@dataclass(slots=True)
class SlackThreadTool:
    client: SlackApiClient
    token: str
    name: str = "slack_thread"

    async def run(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        channel_id = _require_str(arguments, "channel_id")
        thread_ts = _require_str(arguments, "thread_ts")
        messages = self.client.fetch_thread_replies(
            token=self.token,
            channel_id=channel_id,
            thread_ts=thread_ts,
        )
        return {"messages": [_slack_message_to_dict(item) for item in messages]}


@dataclass(slots=True)
class GitLabReadTool:
    client: GitLabApiClient
    name: str = "gitlab_read"

    async def run(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        project_path = _string_argument(arguments, "project_path")
        merge_request_iid = _int_argument(arguments, "merge_request_iid")
        if not project_path or merge_request_iid is None:
            merge_request_url = _string_argument(arguments, "merge_request_url")
            project_path, merge_request_iid = _parse_gitlab_merge_request_url(
                merge_request_url,
                expected_base_url=self.client.base_url,
            )

        merge_request = await self.client.get_merge_request(project_path, merge_request_iid)
        result: dict[str, Any] = {"mergeRequest": merge_request}
        if _bool_argument(arguments, "include_discussions", default=False):
            result["discussions"] = await self.client.get_discussions(project_path, merge_request_iid)
        return result


@dataclass(slots=True)
class JiraReadTool:
    client: JiraApiClient
    expected_base_url: str | None = None
    name: str = "jira_read"

    async def run(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        display_base_url = self.expected_base_url or self.client.base_url
        issue_key = _string_argument(arguments, "issue_key")
        if not issue_key:
            issue_key = _parse_jira_issue_url(
                _string_argument(arguments, "issue_url"),
                expected_base_url=display_base_url,
            )
        expand = _string_argument(arguments, "expand") or None
        issue = await self.client.get_issue(issue_key, expand=expand)
        return {
            "evidence": _jira_evidence(issue, base_url=display_base_url),
            "issue": issue,
            "metadata": {"atlassian": _atlassian_metadata(base_url=display_base_url)},
        }


@dataclass(slots=True)
class ConfluenceReadTool:
    client: ConfluenceApiClient
    expected_base_url: str | None = None
    name: str = "confluence_read"

    async def run(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        display_base_url = self.expected_base_url or self.client.base_url
        page_id = _string_argument(arguments, "page_id")
        if not page_id:
            page_id = _parse_confluence_page_url(
                _string_argument(arguments, "page_url"),
                expected_base_url=display_base_url,
            )
        page = await self.client.get_page_summary(page_id)
        return {
            "evidence": _confluence_evidence(page, base_url=display_base_url),
            "metadata": {"atlassian": _atlassian_metadata(base_url=display_base_url)},
            "page": page,
        }


def _string_argument(arguments: Mapping[str, Any], key: str) -> str:
    value = arguments.get(key)
    return str(value or "").strip()


def _require_str(arguments: Mapping[str, Any], key: str) -> str:
    value = _string_argument(arguments, key)
    if not value:
        raise ToolShimError(code="invalid_arguments", message=f"Missing required argument: {key}")
    return value


def _int_argument(arguments: Mapping[str, Any], key: str, default: int | None = None) -> int | None:
    value = arguments.get(key)
    if value is None or value == "":
        return default
    return int(value)


def _bool_argument(arguments: Mapping[str, Any], key: str, *, default: bool) -> bool:
    value = arguments.get(key)
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _slack_message_to_dict(message: SlackMessage) -> dict[str, Any]:
    return {
        "channelId": message.channel_id,
        "messageTs": message.message_ts,
        "text": message.text,
        "threadTs": message.thread_ts,
        "userId": message.user_id,
    }


def _atlassian_metadata(*, base_url: str) -> dict[str, str | None]:
    return {
        "baseUrl": base_url.rstrip("/"),
        "cloudId": None,
    }


def _jira_evidence(issue: Mapping[str, Any], *, base_url: str) -> dict[str, str]:
    key = str(issue.get("key") or "").strip()
    fields = issue.get("fields") if isinstance(issue.get("fields"), Mapping) else {}
    summary = str(fields.get("summary") or "").strip() if isinstance(fields, Mapping) else ""
    evidence = {
        "source": "jira",
        "locator": key,
        "title": summary or key,
    }
    if key:
        evidence["url"] = f"{base_url.rstrip('/')}/browse/{key}"
    return evidence


def _confluence_evidence(page: Mapping[str, Any], *, base_url: str) -> dict[str, str]:
    page_id = str(page.get("id") or "").strip()
    space_key = str(page.get("spaceKey") or "").strip()
    title = str(page.get("title") or "").strip()
    evidence = {
        "source": "confluence",
        "locator": " ".join(part for part in [page_id, title] if part).strip(),
        "title": title or page_id,
    }
    if page_id and space_key:
        evidence["url"] = f"{base_url.rstrip('/')}/wiki/spaces/{space_key}/pages/{page_id}"
    return evidence


def _parse_gitlab_merge_request_url(url: str, *, expected_base_url: str) -> tuple[str, int]:
    parsed = _parse_same_origin_url(url, expected_base_url=expected_base_url)
    match = re.search(r"^/(?P<project>.+)/-/merge_requests/(?P<iid>\d+)$", parsed.path)
    if match is None:
        raise manual_required_internal_url_error()
    return match.group("project"), int(match.group("iid"))


def _parse_jira_issue_url(url: str, *, expected_base_url: str) -> str:
    parsed = _parse_same_origin_url(url, expected_base_url=expected_base_url)
    match = re.search(r"/browse/(?P<issue>[A-Z][A-Z0-9]+-\d+)$", parsed.path)
    if match is None:
        raise manual_required_internal_url_error()
    return match.group("issue")


def _parse_confluence_page_url(url: str, *, expected_base_url: str) -> str:
    parsed = _parse_same_origin_url(url, expected_base_url=expected_base_url)
    match = re.search(r"/pages/(?P<page_id>\d+)(?:/|$)", parsed.path)
    if match is None:
        raise manual_required_internal_url_error()
    return match.group("page_id")


def _parse_same_origin_url(url: str, *, expected_base_url: str):
    parsed = urlparse(url)
    expected = urlparse(expected_base_url)
    if not parsed.scheme or not parsed.netloc:
        raise manual_required_internal_url_error()
    if (parsed.scheme, parsed.netloc) != (expected.scheme, expected.netloc):
        raise manual_required_internal_url_error()
    return parsed


def _redact_value(value: Any) -> Any:
    if isinstance(value, dict):
        redacted: dict[str, Any] = {}
        for key, child in value.items():
            normalized = key.replace("-", "").replace("_", "").lower()
            if normalized in REDACTED_KEYS:
                redacted[key] = "[REDACTED]"
            else:
                redacted[key] = _redact_value(child)
        return redacted
    if isinstance(value, list):
        return [_redact_value(item) for item in value]
    return value
