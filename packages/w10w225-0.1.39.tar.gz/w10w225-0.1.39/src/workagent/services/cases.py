from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Protocol

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.enums import CaseSource, CaseStatus, ConnectorType
from workagent.db.models import AuditEvent, Case, CaseEvent
from workagent.domain.case_state import assert_case_transition_allowed
from workagent.scheduler.service import SchedulerJobState


class DefaultSlackChannelStore(Protocol):
    async def get_channel_id(self) -> str | None: ...


def _utcnow() -> datetime:
    return datetime.now(UTC)


class CaseService:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def create_case(
        self,
        *,
        source: CaseSource,
        connector_type: ConnectorType | None,
        title: str,
        payload: dict[str, Any] | None = None,
    ) -> Case:
        async with self.session_factory() as session:
            case = Case(
                source=source,
                status=CaseStatus.new,
                connector_type=connector_type,
                title=title,
                payload_json=payload or {},
            )
            session.add(case)
            await session.flush()
            session.add(
                CaseEvent(
                    case_id=case.id,
                    event_type="case.created",
                    payload_json=payload or {},
                )
            )
            await session.commit()
            await session.refresh(case)
            return case

    async def transition_case(self, case_id: str, new_status: CaseStatus, *, payload: dict[str, Any] | None = None) -> None:
        async with self.session_factory() as session:
            case = await session.get(Case, case_id)
            if case is None:
                raise ValueError(f"case not found: {case_id}")
            assert_case_transition_allowed(case.status, new_status)
            case.status = new_status
            case.updated_at = _utcnow()
            session.add(
                CaseEvent(
                    case_id=case.id,
                    event_type=f"case.transition.{new_status.value}",
                    payload_json=payload or {},
                )
            )
            await session.commit()

    async def add_evidence(
        self,
        case_id: str,
        *,
        source_type: str,
        content_text: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        pass  # CaseEvidence model deleted

    async def add_artifact(
        self,
        case_id: str,
        *,
        artifact_type: str,
        relative_path: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        pass  # CaseArtifact model deleted

    async def enqueue_outbound_message(
        self,
        *,
        case_id: str,
        connector_type: ConnectorType,
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> None:
        pass  # OutboundMessage model deleted

    async def record_audit_event(
        self,
        *,
        event_type: str,
        entity_type: str,
        entity_id: str,
        payload: dict[str, Any] | None = None,
    ) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type=event_type,
                    entity_type=entity_type,
                    entity_id=entity_id,
                    payload_json=payload or {},
                )
            )
            await session.commit()


class ScheduledCaseLauncher:
    def __init__(
        self,
        *,
        case_service: CaseService,
        queue,  # noqa: ANN001
        channel_store: DefaultSlackChannelStore | None = None,
    ) -> None:
        self.case_service = case_service
        self.queue = queue
        self.channel_store = channel_store

    async def launch(self, job: SchedulerJobState) -> str:
        task_text = str(job.payload_json.get("taskText") or "").strip()
        channel_id: str | None = None
        if self.channel_store is not None:
            channel_id = await self.channel_store.get_channel_id()
        connector_type = ConnectorType.slack if channel_id else None
        payload: dict[str, Any] = {
            "scheduledJobId": job.job_id,
            "scheduledJobName": job.name,
        }
        if task_text:
            payload["taskText"] = task_text
        model_mode = str(job.payload_json.get("modelMode") or "").strip()
        model = str(job.payload_json.get("model") or "").strip()
        reasoning_effort = str(job.payload_json.get("reasoningEffort") or "").strip()
        if model_mode:
            payload["modelMode"] = model_mode
        if model:
            payload["model"] = model
        if reasoning_effort:
            payload["reasoningEffort"] = reasoning_effort
        if channel_id:
            payload["channelId"] = channel_id
        case = await self.case_service.create_case(
            source=CaseSource.scheduled_job,
            connector_type=connector_type,
            title=task_text or job.name,
            payload=payload,
        )
        await self.case_service.transition_case(
            case.id,
            CaseStatus.queued_for_local_run,
            payload={"reason": "scheduled_job"},
        )
        await self.queue.enqueue(case.id)
        return case.id
