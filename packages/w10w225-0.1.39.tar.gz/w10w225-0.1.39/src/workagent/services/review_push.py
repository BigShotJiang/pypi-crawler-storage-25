from __future__ import annotations

import json
import re

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.enums import AgentWriteDraftKind, AgentWriteDraftStatus, CaseSource, CaseStatus, ConnectorType
from workagent.db.models import AgentSession, AgentWriteDraft, AuditEvent, Case, CaseEvent
from workagent.services.agent_artifacts import build_attachment_session_metadata, build_attachment_session_note
from workagent.sync.models import (
    AgentRoomMessagePayload,
    AgentSessionMessagePayload,
    AgentWriteDraftCreatePayload,
    ProjectWorkflowStageResultPayload,
    ReviewCasePushPayload,
    ReviewThreadContext,
)


class ReviewPushService:
    DEFAULT_BOT_USER_ID = "w10w225bot"

    def __init__(
        self,
        session_factory: async_sessionmaker[AsyncSession],
        review_client,
        *,
        bot_user_id: str | None = None,
        bot_user_nickname: str | None = None,
        memory_writer: object | None = None,
    ) -> None:  # noqa: ANN001
        self.session_factory = session_factory
        self.review_client = review_client
        self.bot_user_id = bot_user_id or self.DEFAULT_BOT_USER_ID
        self.bot_user_nickname = bot_user_nickname or self.bot_user_id
        self.memory_writer = memory_writer

    async def push_ready_cases(self) -> list[str]:
        async with self.session_factory() as session:
            rows = (
                await session.execute(
                    select(Case)
                    .where(
                        Case.status.in_(
                            [
                                CaseStatus.draft_ready,
                                CaseStatus.clarification_needed,
                                CaseStatus.rejected,
                                CaseStatus.expired,
                                CaseStatus.failed,
                                CaseStatus.manual_required,
                            ]
                        )
                    )
                    .order_by(Case.created_at.asc())
                )
            ).scalars().all()

        results: list[str] = []
        for row in rows:
            if row.source in {CaseSource.w10w225_direct_request, CaseSource.project_workflow}:
                pushed = await self._push_interactive_case(row)
                if pushed is not None:
                    results.append(pushed)
                continue
            draft = str(row.payload_json.get("draft") or "").strip()
            if not draft:
                continue
            pushed = await self._push_non_interactive_case_to_room(row, draft)
            if pushed is not None:
                results.append(pushed)
        return results

    async def _push_non_interactive_case_to_room(self, row: Case, draft: str) -> str | None:
        source_url = await self._resolve_source_url(row.id, row.payload_json)
        lines: list[str] = [draft]
        if source_url:
            lines.append(f"Source: {source_url}")
        if row.summary:
            lines.append(f"Summary: {row.summary}")
        text = "\n\n".join(lines)
        metadata = {
            "caseId": row.id,
            "caseSource": row.source.value,
            "caseStatus": row.status.value,
            **({"connectorType": row.connector_type.value} if row.connector_type else {}),
            **({"skillProvenance": row.payload_json.get("skillProvenance")} if row.payload_json.get("skillProvenance") else {}),
            **(
                {"skillValidationNotes": row.payload_json.get("skillValidationNotes")}
                if row.payload_json.get("skillValidationNotes")
                else {}
            ),
            **(
                {"skillValidationFailures": row.payload_json.get("skillValidationFailures")}
                if row.payload_json.get("skillValidationFailures")
                else {}
            ),
        }
        post_room_message = getattr(self.review_client, "post_agent_room_message", None)
        if callable(post_room_message):
            response = await post_room_message(
                AgentRoomMessagePayload(
                    text=text,
                    metadata=metadata,
                )
            )
        else:
            response = await self.review_client.push_review_case(
                ReviewCasePushPayload(
                    caseId=row.id,
                    source=row.source.value,
                    status=row.status.value,
                    draft=draft,
                    summary=row.summary,
                    sourceUrl=source_url,
                    metadata=metadata,
                )
            )
        response_message_id = str(response.get("messageId") or "").strip() or None
        payload_updates = {
            "conversationTurns": self._append_conversation_turn(
                row.payload_json or {},
                role="agent",
                text=text,
                message_id=response_message_id,
            ),
            "lastAgentReply": text,
        }
        for key in ("roomId", "threadId", "messageId"):
            value = str(response.get(key) or "").strip()
            if value:
                payload_updates[key] = value
        await self._mark_case_completed(row.id, payload_updates=payload_updates)
        await self._record_case_audit(
            row.id,
            event_type="non_interactive.room_message_posted",
            payload={"source": row.source.value},
        )
        return "room_message_posted"

    async def _push_interactive_case(self, row: Case) -> str | None:
        agent_session = await self._resolve_agent_session(row.id)
        if agent_session is None:
            return None
        attachment_note = build_attachment_session_note(row.payload_json)
        attachment_metadata = build_attachment_session_metadata(row.payload_json)
        if row.status == CaseStatus.clarification_needed:
            question = str(row.payload_json.get("clarificationQuestion") or "").strip()
            if not question:
                return None
            message_text = self._merge_attachment_note(question, attachment_note)
            response = await self.review_client.post_agent_session_message(
                agent_session.id,
                AgentSessionMessagePayload(
                    messageType="clarification",
                    text=message_text,
                    metadata=self._with_attachment_metadata(
                        {"caseId": row.id},
                        attachment_metadata=attachment_metadata,
                    ),
                ),
            )
            conversation_turns = self._append_conversation_turn(
                row.payload_json,
                role="agent",
                text=message_text,
                message_id=str(response.get("messageId") or "").strip() or None,
            )
            await self._update_case_after_interactive_push(
                row.id,
                new_status=CaseStatus.waiting_user_reply,
                payload_updates={
                    "agentSessionId": agent_session.id,
                    "conversationTurns": conversation_turns,
                    "lastAgentReply": message_text,
                },
            )
            await self._record_case_audit(
                row.id,
                event_type="interactive.clarification_posted",
                payload={"sessionId": agent_session.id, "question": question},
            )
            await self._write_interactive_memories(case_id=row.id)
            return "clarification_posted"

        if row.status in {
            CaseStatus.rejected,
            CaseStatus.expired,
            CaseStatus.failed,
            CaseStatus.manual_required,
        }:
            already_posted = str(row.payload_json.get("terminalMessagePostedForStatus") or "").strip()
            if already_posted == row.status.value:
                return None
            failure_detail = _redact_sensitive_detail(
                str(row.payload_json.get("executionFailureDetail") or "").strip()
            )
            base_message = f"Interactive request {row.status.value}."
            if failure_detail:
                base_message = f"{base_message} ({failure_detail})"
            terminal_text = self._merge_attachment_note(base_message, attachment_note)
            response = await self.review_client.post_agent_session_message(
                agent_session.id,
                AgentSessionMessagePayload(
                    messageType="result",
                    text=terminal_text,
                    metadata=self._with_attachment_metadata(
                        {"caseId": row.id, "status": row.status.value},
                        attachment_metadata=attachment_metadata,
                    ),
                ),
            )
            conversation_turns = self._append_conversation_turn(
                row.payload_json,
                role="agent",
                text=terminal_text,
                message_id=str(response.get("messageId") or "").strip() or None,
            )
            await self._update_case_after_interactive_push(
                row.id,
                new_status=row.status,
                payload_updates={
                    "terminalMessagePostedForStatus": row.status.value,
                    "agentSessionId": agent_session.id,
                    "conversationTurns": conversation_turns,
                    "lastAgentReply": terminal_text,
                },
            )
            await self._record_case_audit(
                row.id,
                event_type="interactive.terminal_posted",
                payload={"sessionId": agent_session.id, "status": row.status.value},
            )
            return "terminal_posted"

        if row.source == CaseSource.project_workflow:
            result_text = str(row.payload_json.get("draft") or "").strip()
            if not result_text:
                return None
            result_text = self._merge_attachment_note(result_text, attachment_note)
            project_workflow = row.payload_json.get("projectWorkflow")
            if not isinstance(project_workflow, dict):
                return None
            await self.review_client.push_project_workflow_stage_result(
                str(project_workflow.get("workflowRunId") or "").strip(),
                ProjectWorkflowStageResultPayload(
                    targetInstallationId=agent_session.target_installation_id,
                    boardId=str(project_workflow.get("projectId") or "").strip(),
                    stageId=str(project_workflow.get("stageId") or "").strip(),
                    artifactKind=str(project_workflow.get("artifactKind") or "").strip(),
                    contentText=result_text,
                    requestingUserId=agent_session.requesting_user_id,
                    localCaseId=row.id,
                ),
            )
            conversation_turns = self._append_conversation_turn(
                row.payload_json,
                role="agent",
                text=result_text,
                message_id=None,
            )
            await self._update_case_after_interactive_push(
                row.id,
                new_status=CaseStatus.completed,
                payload_updates={
                    "agentSessionId": agent_session.id,
                    "conversationTurns": conversation_turns,
                    "lastAgentReply": result_text,
                },
            )
            await self._record_case_audit(
                row.id,
                event_type="interactive.project_workflow_result_pushed",
                payload={"sessionId": agent_session.id, "workflowRunId": project_workflow.get("workflowRunId")},
            )
            await self._write_interactive_memories(case_id=row.id, final_reply_text=result_text)
            return "project_workflow_result_pushed"

        if str(row.payload_json.get("directRequestIntent") or "").strip() == "read":
            result_text = str(row.payload_json.get("draft") or "").strip()
            if not result_text:
                return None
            result_text = self._merge_attachment_note(result_text, attachment_note)
            project_workflow = row.payload_json.get("projectWorkflow")
            if isinstance(project_workflow, dict):
                await self.review_client.push_project_workflow_stage_result(
                    str(project_workflow.get("workflowRunId") or "").strip(),
                    ProjectWorkflowStageResultPayload(
                        targetInstallationId=agent_session.target_installation_id,
                        boardId=str(project_workflow.get("projectId") or "").strip(),
                        stageId=str(project_workflow.get("stageId") or "").strip(),
                        artifactKind=str(project_workflow.get("artifactKind") or "").strip(),
                        contentText=result_text,
                        requestingUserId=agent_session.requesting_user_id,
                        localCaseId=row.id,
                    ),
                )
                conversation_turns = self._append_conversation_turn(
                    row.payload_json,
                    role="agent",
                    text=result_text,
                    message_id=None,
                )
                await self._update_case_after_interactive_push(
                    row.id,
                    new_status=CaseStatus.completed,
                    payload_updates={
                        "agentSessionId": agent_session.id,
                        "conversationTurns": conversation_turns,
                        "lastAgentReply": result_text,
                    },
                )
                await self._record_case_audit(
                    row.id,
                    event_type="interactive.project_workflow_result_pushed",
                    payload={"sessionId": agent_session.id, "workflowRunId": project_workflow.get("workflowRunId")},
                )
                await self._write_interactive_memories(case_id=row.id, final_reply_text=result_text)
                return "project_workflow_result_pushed"
            response = await self.review_client.post_agent_session_message(
                agent_session.id,
                AgentSessionMessagePayload(
                    messageType="result",
                    text=result_text,
                    metadata=self._with_attachment_metadata(
                        {"caseId": row.id, "intent": "read"},
                        attachment_metadata=attachment_metadata,
                    ),
                ),
            )
            conversation_turns = self._append_conversation_turn(
                row.payload_json,
                role="agent",
                text=result_text,
                message_id=str(response.get("messageId") or "").strip() or None,
            )
            await self._update_case_after_interactive_push(
                row.id,
                new_status=CaseStatus.completed,
                payload_updates={
                    "agentSessionId": agent_session.id,
                    "conversationTurns": conversation_turns,
                    "lastAgentReply": result_text,
                },
            )
            await self._record_case_audit(
                row.id,
                event_type="interactive.read_result_posted",
                payload={"sessionId": agent_session.id, "intent": "read"},
            )
            await self._write_interactive_memories(case_id=row.id, final_reply_text=result_text)
            return "read_result_posted"

        draft = str(row.payload_json.get("draft") or "").strip()
        if not draft:
            return None
        draft_kind, target_ref, draft_payload = self._build_interactive_draft_payload(row)
        proposal_text = self._format_interactive_draft_proposal(
            draft=draft,
            draft_kind=draft_kind,
            target_ref=target_ref,
            draft_payload=draft_payload,
        )
        proposal_text = self._merge_attachment_note(proposal_text, attachment_note)
        response = await self.review_client.create_agent_write_draft(
            AgentWriteDraftCreatePayload(
                sessionId=agent_session.id,
                draftKind=draft_kind,
                targetRef=target_ref,
                draftText=proposal_text,
                draftPayload=draft_payload,
            )
        )
        write_draft_id = str(response.get("draftId") or "").strip() or None
        if write_draft_id:
            await self._upsert_local_interactive_write_draft(
                draft_id=write_draft_id,
                session_id=agent_session.id,
                draft_kind=draft_kind,
                target_ref=target_ref,
                draft_text=draft,
                draft_payload=draft_payload,
            )
        response = await self.review_client.post_agent_session_message(
            agent_session.id,
                AgentSessionMessagePayload(
                    messageType="draft_proposal",
                    text=proposal_text,
                    metadata={
                        "caseId": row.id,
                        **({"writeDraftId": write_draft_id} if write_draft_id else {}),
                        **({"skillProvenance": row.payload_json.get("skillProvenance")} if row.payload_json.get("skillProvenance") else {}),
                        **(
                            {"skillValidationNotes": row.payload_json.get("skillValidationNotes")}
                            if row.payload_json.get("skillValidationNotes")
                            else {}
                        ),
                        **(
                            {"skillValidationFailures": row.payload_json.get("skillValidationFailures")}
                            if row.payload_json.get("skillValidationFailures")
                            else {}
                        ),
                        **(
                            self._with_attachment_metadata({}, attachment_metadata=attachment_metadata)
                            if attachment_metadata is not None
                            else {}
                        ),
                    },
                ),
            )
        conversation_turns = self._append_conversation_turn(
            row.payload_json,
            role="agent",
            text=proposal_text,
            message_id=str(response.get("messageId") or "").strip() or None,
        )
        await self._update_case_after_interactive_push(
            row.id,
            new_status=CaseStatus.awaiting_send_approval,
            payload_updates={
                "agentSessionId": agent_session.id,
                "conversationTurns": conversation_turns,
                "lastAgentReply": proposal_text,
                **({"writeDraftId": write_draft_id} if write_draft_id else {}),
            },
        )
        await self._record_case_audit(
            row.id,
            event_type="interactive.draft_posted",
            payload={
                "sessionId": agent_session.id,
                "writeDraftId": write_draft_id,
                "draftKind": draft_kind,
                "targetRef": target_ref,
            },
        )
        return "draft_posted"

    @staticmethod
    def _merge_attachment_note(text: str, note: str | None) -> str:
        normalized_text = str(text).strip()
        normalized_note = str(note or "").strip()
        if not normalized_note:
            return normalized_text
        if not normalized_text:
            return normalized_note
        if normalized_note in normalized_text:
            return normalized_text
        return f"{normalized_text}\n\n{normalized_note}"

    @staticmethod
    def _with_attachment_metadata(
        metadata: dict[str, object],
        *,
        attachment_metadata: dict[str, object] | None,
    ) -> dict[str, object]:
        if attachment_metadata is None:
            return metadata
        return {
            **metadata,
            "attachmentHandling": str(attachment_metadata.get("attachmentHandling") or "").strip(),
            "attachmentSummary": attachment_metadata,
        }

    @staticmethod
    def _append_conversation_turn(
        payload: dict,
        *,
        role: str,
        text: str,
        message_id: str | None,
    ) -> list[dict[str, str]]:
        turns: list[dict[str, str]] = []
        for raw_turn in list(payload.get("conversationTurns") or []):
            if not isinstance(raw_turn, dict):
                continue
            turn_role = str(raw_turn.get("role") or "").strip()
            turn_text = str(raw_turn.get("text") or "").strip()
            turn_message_id = str(raw_turn.get("messageId") or "").strip()
            if not turn_role or not turn_text:
                continue
            turn = {"role": turn_role, "text": turn_text}
            if turn_message_id:
                turn["messageId"] = turn_message_id
            turns.append(turn)
        normalized_text = str(text).strip()
        normalized_message_id = str(message_id or "").strip()
        if normalized_text:
            if normalized_message_id:
                for existing in turns:
                    if existing.get("role") == role and existing.get("messageId") == normalized_message_id:
                        return turns
            elif turns and turns[-1].get("role") == role and turns[-1].get("text") == normalized_text:
                return turns
            turn = {"role": role, "text": normalized_text}
            if normalized_message_id:
                turn["messageId"] = normalized_message_id
            turns.append(turn)
        return turns

    async def _mark_case_completed(self, case_id: str, *, payload_updates: dict | None = None) -> None:
        async with self.session_factory() as session:
            case = await session.get(Case, case_id)
            if case is None:
                return
            case.status = CaseStatus.completed
            if payload_updates:
                case.payload_json = {**case.payload_json, **payload_updates}
            await session.commit()

    async def _mark_awaiting_review(self, case_id: str) -> None:
        async with self.session_factory() as session:
            case = await session.get(Case, case_id)
            if case is None:
                return
            case.status = CaseStatus.awaiting_review
            await session.commit()

    async def _update_case_after_interactive_push(
        self,
        case_id: str,
        *,
        new_status: CaseStatus,
        payload_updates: dict | None = None,
    ) -> None:
        async with self.session_factory() as session:
            case = await session.get(Case, case_id)
            if case is None:
                return
            case.status = new_status
            if payload_updates:
                case.payload_json = {**case.payload_json, **payload_updates}
            await session.commit()

    async def _upsert_local_interactive_write_draft(
        self,
        *,
        draft_id: str,
        session_id: str,
        draft_kind: str,
        target_ref: dict,
        draft_text: str,
        draft_payload: dict,
    ) -> None:
        async with self.session_factory() as session:
            row = await session.get(AgentWriteDraft, draft_id)
            kind = AgentWriteDraftKind(draft_kind)
            if row is None:
                session.add(
                    AgentWriteDraft(
                        id=draft_id,
                        session_id=session_id,
                        draft_kind=kind,
                        target_ref_json=target_ref,
                        draft_text=draft_text,
                        draft_payload_json=draft_payload,
                        status=AgentWriteDraftStatus.awaiting_approval,
                    )
                )
            else:
                row.draft_kind = kind
                row.target_ref_json = target_ref
                row.draft_text = draft_text
                row.draft_payload_json = draft_payload
                row.status = AgentWriteDraftStatus.awaiting_approval
            await session.commit()

    async def _record_case_audit(self, case_id: str, *, event_type: str, payload: dict) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type=event_type,
                    entity_type="case",
                    entity_id=case_id,
                    payload_json=payload,
                )
            )
            await session.commit()

    async def _write_interactive_memories(self, *, case_id: str, final_reply_text: str | None = None) -> None:
        pass  # memory writing removed (MemoryWriteService deleted)

    async def _resolve_source_url(self, case_id: str, payload_json: dict) -> str | None:
        direct = self._coerce_source_url(payload_json)
        if direct:
            return direct

        async with self.session_factory() as session:
            case_event_rows = (
                await session.execute(
                    select(CaseEvent)
                    .where(CaseEvent.case_id == case_id, CaseEvent.event_type == "case.created")
                    .order_by(CaseEvent.created_at.asc())
                )
            ).scalars().all()
            for row in case_event_rows:
                value = self._coerce_source_url(row.payload_json)
                if value:
                    return value

        return None

    @staticmethod
    def _coerce_source_url(payload: dict | None) -> str | None:
        if not isinstance(payload, dict):
            return None
        for key in ("sourceUrl", "externalUrl", "url"):
            value = str(payload.get(key) or "").strip()
            if value:
                return value
        return None

    @staticmethod
    def _build_thread_context(payload: dict | None) -> ReviewThreadContext | None:
        if not isinstance(payload, dict):
            return None
        thread_id = str(payload.get("threadId") or "").strip() or None
        if thread_id is None:
            return None
        topic_session_id = str(payload.get("topicSessionId") or "").strip() or thread_id
        reply_mode = str(payload.get("replyMode") or "").strip() or "same_thread"
        return ReviewThreadContext(
            threadId=thread_id,
            topicSessionId=topic_session_id,
            replyMode=reply_mode,
        )

    async def _resolve_agent_session(self, case_id: str) -> AgentSession | None:
        async with self.session_factory() as session:
            return await session.scalar(
                select(AgentSession).where(AgentSession.local_case_id == case_id).order_by(AgentSession.updated_at.desc())
            )

    @staticmethod
    def _build_interactive_draft_payload(row: Case) -> tuple[str, dict, dict]:
        payload = dict(row.payload_json or {})
        action_intent = payload.get("actionIntent") if isinstance(payload.get("actionIntent"), dict) else None
        if action_intent is not None:
            return (
                str(action_intent.get("draftKind") or "generic_external_action"),
                dict(action_intent.get("targetRef") or {}),
                dict(action_intent.get("payload") or {}),
            )
        explicit_draft_kind = str(payload.get("draftKind") or "").strip()
        explicit_target_ref = payload.get("targetRef") if isinstance(payload.get("targetRef"), dict) else None
        explicit_draft_payload = payload.get("draftPayload") if isinstance(payload.get("draftPayload"), dict) else None
        if explicit_draft_kind and explicit_target_ref is not None and explicit_draft_payload is not None:
            return explicit_draft_kind, dict(explicit_target_ref), dict(explicit_draft_payload)
        if isinstance(payload.get("draftPayload"), dict):
            draft_payload = dict(payload["draftPayload"])
        else:
            draft_payload = {"text": str(payload.get("draft") or "").strip()}
        if row.connector_type == ConnectorType.slack:
            channel_id = str(payload.get("channelId") or "").strip()
            thread_ts = str(payload.get("threadTs") or "").strip()
            if channel_id:
                draft_payload.setdefault("channelId", channel_id)
            if thread_ts:
                draft_payload.setdefault("threadTs", thread_ts)
            draft_kind = "slack_thread_reply" if thread_ts else "slack_send_message"
            target_ref = {k: v for k, v in {"channelId": channel_id or None, "threadTs": thread_ts or None}.items() if v}
            return draft_kind, target_ref, draft_payload
        target_ref = payload.get("targetRef") if isinstance(payload.get("targetRef"), dict) else {}
        return "generic_external_action", dict(target_ref), draft_payload

    @staticmethod
    def _format_interactive_draft_proposal(
        *,
        draft: str,
        draft_kind: str,
        target_ref: dict,
        draft_payload: dict,
    ) -> str:
        impact = {
            "slack_send_message": "Send 1 Slack message.",
            "slack_thread_reply": "Send 1 Slack thread reply.",
            "gitlab_note_create": "Post 1 GitLab merge request note.",
            "jira_comment_create": "Post 1 Jira issue comment.",
            "confluence_comment_create": "Post 1 Confluence page comment.",
            "nk304_memo_create": "Create 1 nk304 memo.",
            "nk304_memo_update": "Update 1 nk304 memo.",
            "nk304_memo_delete": "Delete 1 nk304 memo.",
            "nk304_ticket_create": "Create 1 nk304 ticket.",
            "nk304_ticket_comment": "Post 1 nk304 ticket comment.",
            "nk304_ticket_update": "Update 1 nk304 ticket.",
            "nk304_chat_message": "Send 1 nk304 chat message.",
            "nk304_chat_edit": "Edit 1 nk304 chat message.",
            "nk304_chat_delete": "Delete 1 nk304 chat message.",
            "nk304_chat_reply": "Send 1 nk304 thread reply.",
            "nk304_wiki_set": "Set/update 1 nk304 room wiki.",
            "nk304_wiki_create": "Create 1 nk304 room wiki.",
            "nk304_wiki_edit": "Edit 1 nk304 room wiki.",
            "nk304_wiki_delete": "Delete 1 nk304 room wiki.",
            "nk304_notice_create": "Create 1 nk304 room notice.",
            "nk304_notice_update": "Update 1 nk304 room notice.",
            "nk304_notice_delete": "Delete 1 nk304 room notice.",
            "nk304_calendar_create": "Create 1 nk304 calendar event.",
            "nk304_calendar_update": "Update 1 nk304 calendar event.",
            "nk304_calendar_delete": "Delete 1 nk304 calendar event.",
        }.get(draft_kind, "Execute 1 external write action.")
        target_text = json.dumps(target_ref, ensure_ascii=True, sort_keys=True)
        payload_text = json.dumps(draft_payload, ensure_ascii=True, sort_keys=True)
        return "\n\n".join(
            [
                "Draft Proposal",
                f"Draft:\n{draft}",
                f"Target:\n{target_text}",
                f"Impact:\n{impact}",
                f"Execution Payload:\n{payload_text}",
            ]
        )


_SENSITIVE_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # Absolute file paths (Unix & Windows)
    (re.compile(r"(/(?:home|Users|tmp|var|etc|root|opt|usr|private)/\S+)"), "<redacted-path>"),
    (re.compile(r"([A-Za-z]:\\(?:Users|Windows|Temp)\\\S+)"), "<redacted-path>"),
    # Tokens, keys, secrets — explicit keyword patterns (must precede generic ENV_VAR= rule)
    (re.compile(r"\b(?:token|secret|password|credential)[=:\s]+\S+", re.IGNORECASE), "<redacted-credential>"),
    # Environment variable assignments (e.g. API_KEY=value)
    (re.compile(r"([A-Z_]{2,})=(\S+)"), r"\1=<redacted>"),
]

_MAX_DETAIL_LENGTH = 200


def _redact_sensitive_detail(detail: str) -> str:
    """Remove potentially sensitive information from failure detail before external transmission."""
    if not detail:
        return detail
    redacted = detail
    for pattern, replacement in _SENSITIVE_PATTERNS:
        redacted = pattern.sub(replacement, redacted)
    if len(redacted) > _MAX_DETAIL_LENGTH:
        redacted = redacted[:_MAX_DETAIL_LENGTH] + "..."
    return redacted
