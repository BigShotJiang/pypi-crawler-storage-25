from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Protocol

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.enums import ReviewCommandStatus, ReviewDecisionType
from workagent.db.models import AppSetting, Case, ReviewCommand, ReviewCommandReceipt
from workagent.services.review_commands import ReviewCommandProcessor
from workagent.sync.models import (
    ReviewBotIdentity,
    ReviewCommandAckPayload,
    ReviewCommandResultPayload,
    ReviewThreadContext,
)
from workagent.sync.poller import CommandBatch


def _utcnow() -> datetime:
    return datetime.now(UTC)


class CommandPoller(Protocol):
    async def poll_once(self) -> CommandBatch: ...

    async def commit(self, batch: CommandBatch) -> None: ...


class ReviewSyncApi(Protocol):
    async def ack_review_command(self, command_id: str, payload: ReviewCommandAckPayload) -> dict: ...

    async def push_review_command_result(self, command_id: str, payload: ReviewCommandResultPayload) -> dict: ...


@dataclass(frozen=True, slots=True)
class SyncedCommandOutcome:
    command_id: str
    status: str


class ReviewCommandSyncService:
    def __init__(
        self,
        *,
        session_factory: async_sessionmaker[AsyncSession],
        poller: CommandPoller,
        sync_api: ReviewSyncApi,
        queue=None,  # noqa: ANN001
        memory_writer: object | None = None,
    ) -> None:
        self.session_factory = session_factory
        self.poller = poller
        self.sync_api = sync_api
        self.processor = ReviewCommandProcessor(
            session_factory,
            queue=queue,
            memory_writer=memory_writer,
        )

    async def sync_once(self) -> list[SyncedCommandOutcome]:
        batch = await self.poller.poll_once()
        outcomes: list[SyncedCommandOutcome] = []
        for remote_command in batch.commands:
            existing_command = await self._get_existing_command(remote_command.id)
            if existing_command is not None and existing_command.status == ReviewCommandStatus.completed:
                await self._report_ack(
                    remote_command.id,
                    command_id_for_receipt=existing_command.id,
                    thread_context=remote_command.thread_context,
                    bot_identity=remote_command.bot_identity,
                )
                await self._report_result(
                    remote_command.id,
                    ReviewCommandResultPayload(
                        status="completed",
                        result=await self._build_completed_result(existing_command.case_id),
                        threadContext=remote_command.thread_context,
                        botIdentity=remote_command.bot_identity,
                    ),
                    command_id_for_receipt=existing_command.id,
                )
                outcomes.append(SyncedCommandOutcome(command_id=remote_command.id, status="completed"))
                continue
            if existing_command is not None and existing_command.status == ReviewCommandStatus.failed:
                await self._report_ack(
                    remote_command.id,
                    command_id_for_receipt=existing_command.id,
                    thread_context=remote_command.thread_context,
                    bot_identity=remote_command.bot_identity,
                )
                await self._report_result(
                    remote_command.id,
                    ReviewCommandResultPayload(
                        status="failed",
                        result=self._build_failed_result(existing_command),
                        threadContext=remote_command.thread_context,
                        botIdentity=remote_command.bot_identity,
                    ),
                    command_id_for_receipt=existing_command.id,
                )
                outcomes.append(SyncedCommandOutcome(command_id=remote_command.id, status="failed"))
                continue
            if not await self._case_exists(remote_command.case_id):
                await self._report_ack(
                    remote_command.id,
                    command_id_for_receipt=None,
                    thread_context=remote_command.thread_context,
                    bot_identity=remote_command.bot_identity,
                )
                await self._report_result(
                    remote_command.id,
                    ReviewCommandResultPayload(
                        status="failed",
                        result={"error": f"case not found: {remote_command.case_id}"},
                        threadContext=remote_command.thread_context,
                        botIdentity=remote_command.bot_identity,
                    ),
                    command_id_for_receipt=None,
                )
                outcomes.append(SyncedCommandOutcome(command_id=remote_command.id, status="failed"))
                continue
            await self._persist_remote_command(
                remote_command.id,
                remote_command.case_id,
                remote_command.action,
                remote_command.payload,
                thread_context=remote_command.thread_context,
                bot_identity=remote_command.bot_identity,
            )
            await self._report_ack(
                remote_command.id,
                command_id_for_receipt=remote_command.id,
                thread_context=remote_command.thread_context,
                bot_identity=remote_command.bot_identity,
            )
            try:
                processed = await self.processor.process_command(remote_command.id)
            except Exception as exc:  # noqa: BLE001
                await self._mark_command_failed(remote_command.id, {"error": str(exc)})
                await self._report_result(
                    remote_command.id,
                    ReviewCommandResultPayload(
                        status="failed",
                        result={"error": str(exc)},
                        threadContext=remote_command.thread_context,
                        botIdentity=remote_command.bot_identity,
                    ),
                    command_id_for_receipt=remote_command.id,
                )
                outcomes.append(SyncedCommandOutcome(command_id=remote_command.id, status="failed"))
                continue

            await self._report_result(
                remote_command.id,
                ReviewCommandResultPayload(
                    status="completed",
                    result={
                        "caseId": processed.case_id,
                        "newCaseStatus": processed.new_case_status.value,
                    },
                    threadContext=remote_command.thread_context,
                    botIdentity=remote_command.bot_identity,
                ),
                command_id_for_receipt=remote_command.id,
            )
            outcomes.append(SyncedCommandOutcome(command_id=remote_command.id, status="completed"))
        await self.poller.commit(batch)
        return outcomes

    async def _case_exists(self, case_id: str) -> bool:
        async with self.session_factory() as session:
            return await session.get(Case, case_id) is not None

    async def _get_existing_command(self, command_id: str) -> ReviewCommand | None:
        async with self.session_factory() as session:
            return await session.get(ReviewCommand, command_id)

    async def _build_completed_result(self, case_id: str) -> dict[str, str]:
        async with self.session_factory() as session:
            case = await session.get(Case, case_id)
        if case is None:
            return {"caseId": case_id, "newCaseStatus": "missing"}
        return {
            "caseId": case.id,
            "newCaseStatus": case.status.value,
        }

    async def _persist_remote_command(
        self,
        command_id: str,
        case_id: str,
        action: ReviewDecisionType,
        payload: dict,
        *,
        thread_context: ReviewThreadContext | None,
        bot_identity: ReviewBotIdentity | None,
    ) -> None:
        persisted_payload = {
            **payload,
            **_flatten_thread_context(thread_context),
            **_flatten_bot_identity(bot_identity),
        }
        async with self.session_factory() as session:
            existing = await session.get(ReviewCommand, command_id)
            if existing is None:
                session.add(
                    ReviewCommand(
                        id=command_id,
                        case_id=case_id,
                        command_type=ReviewDecisionType(action.value),
                        status=ReviewCommandStatus.pending,
                        payload_json=persisted_payload,
                    )
                )
            else:
                existing.payload_json = persisted_payload
                existing.status = ReviewCommandStatus.pending
                existing.updated_at = _utcnow()
            await session.commit()

    async def _mark_command_failed(self, command_id: str, payload: dict) -> None:
        async with self.session_factory() as session:
            command = await session.get(ReviewCommand, command_id)
            if command is not None:
                command.status = ReviewCommandStatus.failed
                command.payload_json = {**command.payload_json, **payload}
                command.updated_at = _utcnow()
                await session.commit()

    async def _report_ack(
        self,
        command_id: str,
        *,
        command_id_for_receipt: str | None,
        thread_context: ReviewThreadContext | None,
        bot_identity: ReviewBotIdentity | None,
    ) -> None:
        payload = ReviewCommandAckPayload(
            receiptId=f"{command_id}:claimed",
            status="claimed",
            threadContext=thread_context,
            botIdentity=bot_identity,
        )
        if await self._receipt_exists(command_id, receipt_type="ack", command_id_for_receipt=command_id_for_receipt):
            return
        await self.sync_api.ack_review_command(command_id, payload)
        await self._store_receipt(
            command_id,
            receipt_type="ack",
            payload=payload.model_dump(by_alias=True),
            command_id_for_receipt=command_id_for_receipt,
        )

    async def _report_result(
        self,
        command_id: str,
        payload: ReviewCommandResultPayload,
        *,
        command_id_for_receipt: str | None,
    ) -> None:
        if await self._receipt_exists(command_id, receipt_type="result", command_id_for_receipt=command_id_for_receipt):
            return
        await self.sync_api.push_review_command_result(command_id, payload)
        await self._store_receipt(
            command_id,
            receipt_type="result",
            payload=payload.model_dump(by_alias=True),
            command_id_for_receipt=command_id_for_receipt,
        )

    async def _receipt_exists(
        self,
        command_id: str,
        *,
        receipt_type: str,
        command_id_for_receipt: str | None,
    ) -> bool:
        async with self.session_factory() as session:
            if command_id_for_receipt is None:
                return await session.get(AppSetting, self._receipt_storage_key(command_id, receipt_type)) is not None
            receipt = await session.scalar(
                select(ReviewCommandReceipt).where(
                    ReviewCommandReceipt.idempotency_key == self._receipt_storage_key(command_id, receipt_type)
                )
            )
            return receipt is not None

    async def _store_receipt(
        self,
        command_id: str,
        *,
        receipt_type: str,
        payload: dict,
        command_id_for_receipt: str | None,
    ) -> None:
        async with self.session_factory() as session:
            storage_key = self._receipt_storage_key(command_id, receipt_type)
            if command_id_for_receipt is None:
                existing_setting = await session.get(AppSetting, storage_key)
                if existing_setting is None:
                    session.add(AppSetting(key=storage_key, value_json=payload))
                    await session.commit()
                return

            existing_receipt = await session.scalar(
                select(ReviewCommandReceipt).where(ReviewCommandReceipt.idempotency_key == storage_key)
            )
            if existing_receipt is None:
                session.add(
                    ReviewCommandReceipt(
                        command_id=command_id_for_receipt,
                        receipt_type=receipt_type,
                        idempotency_key=storage_key,
                        payload_json=payload,
                    )
                )
                await session.commit()

    @staticmethod
    def _receipt_storage_key(command_id: str, receipt_type: str) -> str:
        return f"review_command_receipt:{command_id}:{receipt_type}"

    @staticmethod
    def _build_failed_result(command: ReviewCommand) -> dict[str, str]:
        error = str(command.payload_json.get("error") or f"review command failed: {command.id}")
        return {"error": error}


def _flatten_thread_context(thread_context: ReviewThreadContext | None) -> dict[str, str]:
    if thread_context is None:
        return {}
    payload: dict[str, str] = {}
    if thread_context.thread_id:
        payload["threadId"] = thread_context.thread_id
    if thread_context.topic_session_id:
        payload["topicSessionId"] = thread_context.topic_session_id
    if thread_context.reply_mode:
        payload["replyMode"] = thread_context.reply_mode
    return payload


def _flatten_bot_identity(bot_identity: ReviewBotIdentity | None) -> dict[str, str]:
    if bot_identity is None:
        return {}
    payload = {"botSenderUserId": bot_identity.sender_user_id}
    if bot_identity.sender_user_nickname:
        payload["botSenderUserNickname"] = bot_identity.sender_user_nickname
    return payload
