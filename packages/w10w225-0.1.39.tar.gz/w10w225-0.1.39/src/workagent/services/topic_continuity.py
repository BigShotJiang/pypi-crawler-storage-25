from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.enums import CaseSource, ConnectorType
from workagent.db.models import Case


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _as_utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


@dataclass(frozen=True, slots=True)
class TopicContinuityDecision:
    topic_key: str
    topic_session_id: str
    reply_mode: str
    continuity_reason: str
    thread_id: str | None = None


class TopicContinuityService:
    def __init__(
        self,
        *,
        session_factory: async_sessionmaker[AsyncSession],
        lookback_minutes: int = 7 * 24 * 60,
        ambiguous_topic_decider: Callable[[Case, str, dict[str, Any]], bool] | None = None,
    ) -> None:
        self.session_factory = session_factory
        self.lookback_minutes = lookback_minutes
        self.ambiguous_topic_decider = ambiguous_topic_decider

    async def enrich_payload(
        self,
        *,
        source: CaseSource,
        connector_type: ConnectorType | None,
        title: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        if connector_type not in {ConnectorType.slack, ConnectorType.gitlab}:
            return payload
        seeded_topic_session_id = str(payload.get("topicSessionId") or "").strip() or None
        if seeded_topic_session_id is not None:
            topic_key = str(payload.get("topicKey") or "").strip() or seeded_topic_session_id
            return {
                **payload,
                "topicKey": topic_key,
                "topicSessionId": seeded_topic_session_id,
                "replyMode": str(payload.get("replyMode") or "").strip() or "new_thread",
                "continuityReason": str(payload.get("continuityReason") or "").strip() or "seeded_topic",
            }
        topic_key = self._build_topic_key(source=source, connector_type=connector_type, title=title, payload=payload)
        if topic_key is None:
            return payload

        existing = await self._find_existing_topic(connector_type=connector_type, topic_key=topic_key)
        if existing is None:
            related_case = await self._find_related_case(connector_type=connector_type, payload=payload)
            if (
                related_case is not None
                and self.ambiguous_topic_decider is not None
                and _as_utc(related_case.created_at) >= _utcnow() - timedelta(minutes=self.lookback_minutes)
                and self._call_ambiguous_decider(related_case, title, payload)
            ):
                related_payload = related_case.payload_json or {}
                decision = TopicContinuityDecision(
                    topic_key=topic_key,
                    topic_session_id=str(related_payload.get("topicSessionId") or topic_key),
                    reply_mode="same_thread",
                    continuity_reason="ambiguous_same_topic",
                    thread_id=str(related_payload.get("threadId") or "").strip() or None,
                )
            else:
                related_payload = related_case.payload_json or {} if related_case is not None else {}
                decision = TopicContinuityDecision(
                    topic_key=topic_key,
                    topic_session_id=topic_key,
                    reply_mode="new_thread",
                    continuity_reason=(
                        "new_topic"
                        if related_case is None
                        else (
                            "topic_break_ambiguous_rejected"
                            if str(related_payload.get("continuityReason") or "") == "seeded_topic"
                            else (
                                "ambiguous_new_topic"
                                if connector_type == ConnectorType.slack
                                else "topic_break_ambiguous"
                            )
                        )
                    ),
                )
        elif _as_utc(existing.created_at) < _utcnow() - timedelta(minutes=self.lookback_minutes):
            decision = TopicContinuityDecision(
                topic_key=topic_key,
                topic_session_id=f"{topic_key}:{int(_utcnow().timestamp())}",
                reply_mode="new_thread",
                continuity_reason="topic_break_lookback_expired",
            )
        else:
            existing_payload = existing.payload_json or {}
            decision = TopicContinuityDecision(
                topic_key=topic_key,
                topic_session_id=str(existing_payload.get("topicSessionId") or topic_key),
                reply_mode="same_thread",
                continuity_reason="same_topic",
                thread_id=str(existing_payload.get("threadId") or "").strip() or None,
            )

        enriched = {
            **payload,
            "topicKey": decision.topic_key,
            "topicSessionId": decision.topic_session_id,
            "replyMode": decision.reply_mode,
            "continuityReason": decision.continuity_reason,
        }
        if decision.thread_id:
            enriched["threadId"] = decision.thread_id
        return enriched

    def _call_ambiguous_decider(self, related_case: Case, title: str, payload: dict[str, Any]) -> bool:
        assert self.ambiguous_topic_decider is not None
        try:
            return bool(self.ambiguous_topic_decider(related_case, title, payload))
        except TypeError:
            return bool(self.ambiguous_topic_decider(related_case.payload_json or {}, payload))

    async def _find_existing_topic(
        self,
        *,
        connector_type: ConnectorType,
        topic_key: str,
    ) -> Case | None:
        async with self.session_factory() as session:
            rows = (
                await session.execute(
                    select(Case)
                    .where(Case.connector_type == connector_type)
                    .order_by(Case.created_at.desc())
                )
            ).scalars().all()
        for row in rows:
            if str((row.payload_json or {}).get("topicKey") or "").strip() == topic_key:
                return row
        return None

    async def _find_related_case(
        self,
        *,
        connector_type: ConnectorType,
        payload: dict[str, Any],
    ) -> Case | None:
        async with self.session_factory() as session:
            rows = (
                await session.execute(
                    select(Case)
                    .where(Case.connector_type == connector_type)
                    .order_by(Case.created_at.desc())
                )
            ).scalars().all()
        for row in rows:
            existing_payload = row.payload_json or {}
            if connector_type == ConnectorType.slack:
                if str(existing_payload.get("channelId") or "").strip() == str(payload.get("channelId") or "").strip():
                    return row
            if connector_type == ConnectorType.gitlab:
                if str(existing_payload.get("projectPath") or "").strip() == str(payload.get("projectPath") or "").strip():
                    return row
        return None

    @staticmethod
    def _build_topic_key(
        *,
        source: CaseSource,
        connector_type: ConnectorType,
        title: str,
        payload: dict[str, Any],
    ) -> str | None:
        if connector_type == ConnectorType.slack:
            channel_id = str(payload.get("channelId") or "").strip()
            root_ts = str(payload.get("threadTs") or payload.get("messageTs") or "").strip()
            if channel_id and root_ts:
                return f"slack:{channel_id}:{root_ts}"
        if connector_type == ConnectorType.gitlab:
            project_path = str(payload.get("projectPath") or "").strip()
            merge_request_iid = str(payload.get("mergeRequestIid") or "").strip()
            if project_path and merge_request_iid:
                return f"gitlab:{project_path}:mr:{merge_request_iid}"
        normalized_title = " ".join(title.lower().split())
        if normalized_title:
            return f"{source.value}:{connector_type.value}:{normalized_title}"
        return None
