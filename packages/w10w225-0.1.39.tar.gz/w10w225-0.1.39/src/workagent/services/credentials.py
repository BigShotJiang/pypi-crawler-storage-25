from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.config.models import AppConfig
from workagent.db.enums import ConnectorType
from workagent.db.models import CredentialBindingMetadata
from workagent.runtime.secrets import SecretStore


def _utcnow() -> datetime:
    return datetime.now(UTC)


async def sync_config_credentials_to_db(
    session_factory: async_sessionmaker[AsyncSession],
    config: AppConfig,
) -> None:
    enabled_connectors = {ConnectorType(platform.value): connector for platform, connector in config.platforms.items()}

    async with session_factory() as session:
        existing_rows = (
            await session.execute(select(CredentialBindingMetadata))
        ).scalars().all()
        existing_by_type = {row.connector_type: row for row in existing_rows}

        for connector_type, connector in enabled_connectors.items():
            row = existing_by_type.get(connector_type)
            if row is None:
                row = CredentialBindingMetadata(
                    connector_type=connector_type,
                    base_url=connector.base_url,
                    secret_key=connector.secret_key,
                    is_enabled=True,
                    last_validated_at=_utcnow(),
                )
                session.add(row)
            else:
                row.base_url = connector.base_url
                row.secret_key = connector.secret_key
                row.is_enabled = True
                row.last_validated_at = _utcnow()

        for connector_type, row in existing_by_type.items():
            if connector_type not in enabled_connectors:
                row.is_enabled = False

        await session.commit()


async def set_connector_enabled(
    session_factory: async_sessionmaker[AsyncSession],
    *,
    connector_type: ConnectorType,
    is_enabled: bool,
) -> None:
    async with session_factory() as session:
        row = (
            await session.execute(
                select(CredentialBindingMetadata).where(CredentialBindingMetadata.connector_type == connector_type)
            )
        ).scalars().one_or_none()
        if row is None:
            raise ValueError(f"connector metadata not found: {connector_type.value}")
        row.is_enabled = is_enabled
        await session.commit()


class CredentialTokenResolver:
    def __init__(
        self,
        *,
        session_factory: async_sessionmaker[AsyncSession],
        secret_store: SecretStore,
    ) -> None:
        self.session_factory = session_factory
        self.secret_store = secret_store

    async def get_token(self, connector_type: ConnectorType) -> str | None:
        async with self.session_factory() as session:
            row = (
                await session.execute(
                    select(CredentialBindingMetadata).where(
                        CredentialBindingMetadata.connector_type == connector_type,
                        CredentialBindingMetadata.is_enabled.is_(True),
                    )
                )
            ).scalar_one_or_none()
        if row is None or not row.secret_key:
            return None
        return self.secret_store.get(row.secret_key)
