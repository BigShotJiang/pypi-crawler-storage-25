from __future__ import annotations

from dataclasses import dataclass

from workagent.connectors.slack_sync import CursorStore, SlackClient, SlackSyncPoller
from workagent.runtime.queue import LocalRunQueue

# SlackIngestService removed in MVP1 — ingest_service parameter is now optional (None)


@dataclass(frozen=True, slots=True)
class SlackSyncCycleSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None


class SlackSyncCycle:
    def __init__(
        self,
        *,
        client: SlackClient,
        cursor_store: CursorStore,
        ingest_service: object | None,
        queue: LocalRunQueue,
        limit: int = 50,
    ) -> None:
        self._poller = SlackSyncPoller(client=client, cursor_store=cursor_store, limit=limit)
        self._cursor_store = cursor_store
        self._ingest_service = ingest_service
        self._queue = queue

    async def run_once(self) -> SlackSyncCycleSummary:
        batch = await self._poller.poll_once()
        case_ids = await self._ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self._queue.enqueue(case_id)
        await self._poller.commit(batch)
        return SlackSyncCycleSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )
