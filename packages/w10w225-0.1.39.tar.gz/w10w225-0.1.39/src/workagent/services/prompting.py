from __future__ import annotations

import json
from typing import Any

from workagent.db.enums import CaseSource

REDACTED_KEYS = {"api_key", "apikey", "apitoken", "authorization", "password", "secret", "token"}


def _system_prompt_for_source(source: CaseSource) -> str:
    if source == CaseSource.slack_sync:
        return "You are handling a Slack work inquiry. Investigate available Slack/JIRA/Confluence context and draft a precise reply."
    if source == CaseSource.gitlab_sync:
        return "You are handling a GitLab review request. Investigate merge request context and draft a concise review response."
    if source == CaseSource.jira_sync:
        return "You are handling a Jira work issue. Investigate issue history and draft a concise next action."
    if source == CaseSource.confluence_sync:
        return "You are handling a Confluence page change. Investigate the page update and draft the required follow-up."
    if source == CaseSource.scheduled_job:
        return "You are handling a scheduled work check. Review the job context and draft the required follow-up."
    return "You are handling a work case. Investigate context and draft the next response."
