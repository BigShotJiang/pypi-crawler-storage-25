from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import tarfile
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


def _sanitize_artifact_path_component(value: Any, *, fallback: str) -> str:
    component = str(value or "").strip()
    if not component:
        component = fallback
    component = component.replace("\\", "/").split("/")[-1].strip()
    if component in {"", ".", ".."}:
        component = fallback
    sanitized = re.sub(r"[^A-Za-z0-9._-]", "_", component)[:255]
    if sanitized in {"", ".", ".."}:
        sanitized = re.sub(r"[^A-Za-z0-9._-]", "_", fallback)[:255] or "artifact"
    return sanitized


def _safe_path_within(base_dir: Path, *parts: str) -> Path:
    path = base_dir
    for part in parts:
        path /= part
    resolved_base = base_dir.resolve()
    resolved_path = path.resolve()
    if not resolved_path.is_relative_to(resolved_base):
        raise ValueError("unsafe_artifact_path")
    return resolved_path


def _normalized_attachment_handling(payload: dict[str, Any] | None) -> str | None:
    normalized_payload = payload or {}
    explicit = str(normalized_payload.get("attachmentHandling") or "").strip()
    if explicit:
        return explicit
    local_artifacts = normalized_payload.get("localArtifactsById")
    if isinstance(local_artifacts, dict) and any(
        isinstance(entry, dict) and str(entry.get("downloadStatus") or "").strip() == "failed"
        for entry in local_artifacts.values()
    ):
        return "fetch_failed"
    if isinstance(local_artifacts, dict) and any(
        isinstance(entry, dict) and str(entry.get("extractionStatus") or "").strip() == "failed"
        for entry in local_artifacts.values()
    ):
        return "extraction_failed"
    if isinstance(local_artifacts, dict) and any(
        isinstance(entry, dict) and str(entry.get("extractionStatus") or "").strip() == "ready"
        for entry in local_artifacts.values()
    ):
        return "extracted_text_used"
    if isinstance(local_artifacts, dict) and any(
        isinstance(entry, dict) and str(entry.get("extractionMode") or "").strip() == "metadata_only"
        for entry in local_artifacts.values()
    ):
        return "metadata_only_fallback"
    artifacts = normalized_payload.get("messageArtifactsById")
    if isinstance(artifacts, dict) and artifacts:
        return "attached"
    return None


def _attachment_display_names(summary: dict[str, Any]) -> str:
    artifact_names = [str(name).strip() for name in list(summary.get("artifactNames") or []) if str(name).strip()]
    display_names = ", ".join(artifact_names[:3])
    if len(artifact_names) > 3:
        display_names = f"{display_names}, +{len(artifact_names) - 3} more"
    return display_names


def build_attachment_session_metadata(payload: dict[str, Any] | None) -> dict[str, Any] | None:
    normalized_payload = payload or {}
    artifacts = normalized_payload.get("messageArtifactsById")
    if not isinstance(artifacts, dict) or not artifacts:
        return None
    local_artifacts = normalized_payload.get("localArtifactsById")
    local_map = local_artifacts if isinstance(local_artifacts, dict) else {}
    entries: list[dict[str, Any]] = []
    artifact_names: list[str] = []
    ready_count = 0
    pending_count = 0
    failed_count = 0
    error_counts: dict[str, int] = {}
    for artifact_id, raw_artifact in artifacts.items():
        if not isinstance(raw_artifact, dict):
            continue
        local_entry = local_map.get(artifact_id) if isinstance(local_map.get(artifact_id), dict) else {}
        status = str(local_entry.get("downloadStatus") or "").strip() or "unknown"
        if status == "ready":
            ready_count += 1
        elif status == "failed":
            failed_count += 1
        else:
            pending_count += 1
        error_code = str(local_entry.get("errorCode") or "").strip() or None
        if error_code:
            error_counts[error_code] = error_counts.get(error_code, 0) + 1
        name = str(raw_artifact.get("name") or "").strip()
        if name:
            artifact_names.append(name)
        entry: dict[str, Any] = {
            "artifactId": str(raw_artifact.get("artifactId") or artifact_id).strip() or str(artifact_id).strip(),
            "kind": str(raw_artifact.get("kind") or "").strip() or "unknown",
            "mimeType": str(raw_artifact.get("mimeType") or "").strip(),
            "name": name,
            "status": status,
        }
        message_id = str(raw_artifact.get("messageId") or "").strip()
        if message_id:
            entry["messageId"] = message_id
        if str(raw_artifact.get("pageCount") or "").strip():
            entry["pageCount"] = int(raw_artifact["pageCount"])
        if str(raw_artifact.get("width") or "").strip():
            entry["width"] = int(raw_artifact["width"])
        if str(raw_artifact.get("height") or "").strip():
            entry["height"] = int(raw_artifact["height"])
        if error_code:
            entry["errorCode"] = error_code
        extraction_status = str(local_entry.get("extractionStatus") or "").strip()
        extraction_mode = str(local_entry.get("extractionMode") or "").strip()
        if extraction_status:
            entry["extractionStatus"] = extraction_status
        if extraction_mode:
            entry["extractionMode"] = extraction_mode
        entries.append(entry)
    if not entries:
        return None
    return {
        "attachmentHandling": _normalized_attachment_handling(normalized_payload) or "attached",
        "artifactNames": artifact_names,
        "readyCount": ready_count,
        "pendingCount": pending_count,
        "failedCount": failed_count,
        "errorCounts": error_counts,
        "artifacts": entries,
    }


def build_attachment_session_note(payload: dict[str, Any] | None) -> str | None:
    summary = build_attachment_session_metadata(payload)
    if summary is None:
        return None
    handling = str(summary.get("attachmentHandling") or "").strip()
    display_names = _attachment_display_names(summary)
    if handling == "fetch_failed":
        error_counts = summary.get("errorCounts") if isinstance(summary.get("errorCounts"), dict) else {}
        error_text = ", ".join(
            f"{str(code).strip()}={int(count)}"
            for code, count in sorted(error_counts.items())
            if str(code).strip()
        )
        return (
            "Note: The local agent could not fetch attached files"
            f"{f' ({display_names})' if display_names else ''}. "
            f"{f'Failure details: {error_text}. ' if error_text else ''}"
            "Re-upload the file or retry the request."
        )
    if handling == "extraction_failed":
        return (
            "Note: The local agent could not extract usable content from attached files"
            f"{f' ({display_names})' if display_names else ''}. "
            "This response may rely on metadata only."
        )
    if handling in {"fallback_text", "metadata_only_fallback"}:
        return (
            "Note: The current engine could not inspect attached files natively in this runtime"
            f"{f' ({display_names})' if display_names else ''}. "
            "This response used attachment metadata only."
        )
    return None


def build_agent_artifact_prompt_section(payload: dict[str, Any] | None) -> str | None:
    normalized_payload = payload or {}
    artifacts = normalized_payload.get("messageArtifactsById")
    if not isinstance(artifacts, dict) or not artifacts:
        return None
    local_artifacts = normalized_payload.get("localArtifactsById")
    local_map = local_artifacts if isinstance(local_artifacts, dict) else {}
    lines = ["Artifacts:"]
    for artifact_id, raw_artifact in artifacts.items():
        if not isinstance(raw_artifact, dict):
            continue
        name = str(raw_artifact.get("name") or "").strip()
        mime_type = str(raw_artifact.get("mimeType") or "").strip()
        kind = str(raw_artifact.get("kind") or "").strip()
        message_id = str(raw_artifact.get("messageId") or "").strip()
        page_count = int(raw_artifact.get("pageCount") or 0) if str(raw_artifact.get("pageCount") or "").strip() else 0
        local_entry = local_map.get(artifact_id) if isinstance(local_map.get(artifact_id), dict) else {}
        download_status = str(local_entry.get("downloadStatus") or "").strip() or "unknown"
        cache_path = str(local_entry.get("cachePath") or "").strip()
        if not name or not mime_type:
            continue
        line = f"- {name} ({mime_type}, kind={kind or 'unknown'}, status={download_status})"
        if message_id:
            line += f" messageId={message_id}"
        if page_count > 0:
            line += f" pageCount={page_count}"
        if cache_path:
            line += f" localPath={cache_path}"
        lines.append(line)
    return "\n".join(lines) if len(lines) > 1 else None


def build_extracted_artifact_prompt_section(payload: dict[str, Any] | None) -> str | None:
    normalized_payload = payload or {}
    artifacts = normalized_payload.get("messageArtifactsById")
    if not isinstance(artifacts, dict) or not artifacts:
        return None
    local_artifacts = normalized_payload.get("localArtifactsById")
    local_map = local_artifacts if isinstance(local_artifacts, dict) else {}
    lines = ["Extracted Artifact Content:"]
    remaining_chars = 4000
    for artifact_id, raw_artifact in artifacts.items():
        if not isinstance(raw_artifact, dict):
            continue
        local_entry = local_map.get(artifact_id) if isinstance(local_map.get(artifact_id), dict) else {}
        if str(local_entry.get("extractionStatus") or "").strip() != "ready":
            continue
        extracted_path = Path(str(local_entry.get("extractedTextPath") or "").strip())
        if not extracted_path.exists():
            continue
        extracted_text = extracted_path.read_text(encoding="utf-8").strip()
        if not extracted_text:
            continue
        excerpt = extracted_text[: min(len(extracted_text), 1200, remaining_chars)]
        if not excerpt:
            continue
        remaining_chars -= len(excerpt)
        name = str(raw_artifact.get("name") or artifact_id).strip()
        mode = str(local_entry.get("extractionMode") or "").strip() or "unknown"
        lines.append(f"- {name} ({mode})")
        lines.append(excerpt)
        if remaining_chars <= 0:
            break
    return "\n".join(lines) if len(lines) > 1 else None


def build_attachment_execution_note(
    payload: dict[str, Any] | None,
    *,
    native_support: bool,
) -> str | None:
    artifact_summary = build_agent_artifact_prompt_section(payload)
    if not artifact_summary:
        return None
    session_metadata = build_attachment_session_metadata(payload)
    handling = str((session_metadata or {}).get("attachmentHandling") or "").strip()
    display_names = _attachment_display_names(session_metadata or {})
    if handling == "fetch_failed":
        return (
            "The local agent could not fetch attached files"
            f"{f' ({display_names})' if display_names else ''}. "
            "Do not claim you inspected the files. Explain the fetch failure and rely only on any surviving artifact metadata."
        )
    if handling == "extraction_failed":
        return (
            "The local agent could not extract usable content from attached files"
            f"{f' ({display_names})' if display_names else ''}. "
            "Do not claim you inspected or parsed the files successfully. Fall back to metadata and explain the extraction failure."
        )
    if handling == "extracted_text_used":
        return (
            "Attached text-like artifacts were extracted locally"
            f"{f' ({display_names})' if display_names else ''}. "
            "Use the Extracted Artifact Content section as primary context."
        )
    if handling == "metadata_only_fallback":
        return (
            "Attached artifacts are present"
            f"{f' ({display_names})' if display_names else ''}, "
            "but only metadata is available in this runtime. Do not claim you inspected or transcribed the files."
        )
    if native_support:
        return (
            "Attached artifacts are present and this engine can inspect ready image/PDF files natively. "
            "Use the provided attachment bytes together with the prompt context."
        )
    return (
        "Attached artifacts are present but the current engine does not support native attachment inspection in this "
        "runtime. Use artifact metadata and any localPath hints as fallback context only, and do not claim you visually "
        "inspected the files unless the prompt explicitly contains file content."
    )


def _artifact_family(raw_artifact: dict[str, Any]) -> str:
    return str(raw_artifact.get("family") or raw_artifact.get("kind") or "").strip() or "binary"


MAX_EXTRACTED_TEXT_CHARS = 20_000
MAX_ARCHIVE_ENTRIES_SCANNED = 100
MAX_ARCHIVE_TOTAL_BYTES = 25 * 1024 * 1024
MAX_OFFICE_PARSE_BYTES = 25 * 1024 * 1024
MAX_EXTRACTION_INPUT_BYTES = 50 * 1024 * 1024
MAX_SPREADSHEET_ROWS = 20
MAX_SPREADSHEET_VALUES_PER_ROW = 10
MAX_TRANSCRIPT_MEDIA_DURATION_SECONDS = 15 * 60
SUPPORTED_NATIVE_AUDIO_MIME_TYPES = {
    "audio/mpeg",
    "audio/wav",
    "audio/x-wav",
    "audio/mp4",
    "audio/webm",
    "audio/ogg",
}
SUPPORTED_NATIVE_VIDEO_MIME_TYPES = {
    "video/mp4",
    "video/quicktime",
    "video/webm",
}


@dataclass(frozen=True, slots=True)
class ArtifactExtractionResult:
    extraction_status: str
    extraction_mode: str
    extracted_text: str | None = None
    error_code: str | None = None
    error_detail: str | None = None
    metadata: dict[str, Any] | None = None


def _extract_text_document(raw_bytes: bytes, *, mime_type: str) -> str:
    normalized_mime = str(mime_type or "").strip().lower()
    if normalized_mime == "application/json":
        return json.dumps(json.loads(raw_bytes.decode("utf-8")), ensure_ascii=True, indent=2, sort_keys=True)
    if normalized_mime == "text/csv":
        reader = csv.reader(io.StringIO(raw_bytes.decode("utf-8")))
        rows = [", ".join(row) for row in list(reader)[:50]]
        return "\n".join(rows)
    if normalized_mime in {"application/xml", "text/xml"}:
        return "\n".join(_collect_xml_text(raw_bytes))
    if normalized_mime == "text/html":
        html_text = raw_bytes.decode("utf-8")
        return re.sub(r"<[^>]+>", " ", html_text).replace("&nbsp;", " ").strip()
    return raw_bytes.decode("utf-8")


def _collect_xml_text(xml_bytes: bytes, *, tag_suffixes: tuple[str, ...] | None = None) -> list[str]:
    root = ET.fromstring(xml_bytes)
    collected: list[str] = []
    suffixes = tag_suffixes or ()
    for element in root.iter():
        text = str(element.text or "").strip()
        if not text:
            continue
        if suffixes and not any(str(element.tag).endswith(suffix) for suffix in suffixes):
            continue
        collected.append(text)
    return collected


def _extract_docx_text(path: Path) -> str:
    with zipfile.ZipFile(path) as archive:
        document_xml = archive.read("word/document.xml")
    return "\n".join(_collect_xml_text(document_xml, tag_suffixes=("}t",)))


def _extract_pptx_text(path: Path) -> str:
    lines: list[str] = []
    with zipfile.ZipFile(path) as archive:
        slide_names = sorted(
            name for name in archive.namelist() if name.startswith("ppt/slides/slide") and name.endswith(".xml")
        )
        for index, slide_name in enumerate(slide_names, start=1):
            slide_text = " ".join(_collect_xml_text(archive.read(slide_name), tag_suffixes=("}t",))).strip()
            if slide_text:
                lines.append(f"Slide {index}: {slide_text}")
    return "\n".join(lines)


def _count_pptx_slides(path: Path) -> int:
    with zipfile.ZipFile(path) as archive:
        return len(
            [
                name
                for name in archive.namelist()
                if name.startswith("ppt/slides/slide") and name.endswith(".xml")
            ]
        )


def _extract_xlsx_text(path: Path) -> str:
    shared_strings: list[str] = []
    lines: list[str] = []
    with zipfile.ZipFile(path) as archive:
        if "xl/sharedStrings.xml" in archive.namelist():
            shared_strings = _collect_xml_text(archive.read("xl/sharedStrings.xml"), tag_suffixes=("}t",))
        worksheet_names = sorted(
            name for name in archive.namelist() if name.startswith("xl/worksheets/sheet") and name.endswith(".xml")
        )
        for worksheet_name in worksheet_names[:5]:
            root = ET.fromstring(archive.read(worksheet_name))
            lines.append(f"Sheet: {Path(worksheet_name).stem}")
            row_count = 0
            for row in root.iter():
                if not str(row.tag).endswith("}row"):
                    continue
                row_count += 1
                if row_count > MAX_SPREADSHEET_ROWS:
                    break
                values: list[str] = []
                for cell in list(row):
                    if not str(cell.tag).endswith("}c"):
                        continue
                    cell_ref = str(cell.attrib.get("r") or "").strip()
                    cell_type = str(cell.attrib.get("t") or "").strip()
                    value_text = ""
                    value_node = next((child for child in list(cell) if str(child.tag).endswith("}v")), None)
                    if value_node is not None and value_node.text is not None:
                        raw_value = str(value_node.text).strip()
                        if cell_type == "s" and raw_value.isdigit():
                            index = int(raw_value)
                            if 0 <= index < len(shared_strings):
                                value_text = shared_strings[index]
                        else:
                            value_text = raw_value
                    if cell_ref and value_text:
                        values.append(f"{cell_ref}={value_text}")
                if values:
                    lines.append(", ".join(values[:MAX_SPREADSHEET_VALUES_PER_ROW]))
    return "\n".join(lines)


def _count_xlsx_sheets(path: Path) -> int:
    with zipfile.ZipFile(path) as archive:
        return len(
            [
                name
                for name in archive.namelist()
                if name.startswith("xl/worksheets/sheet") and name.endswith(".xml")
            ]
        )


def _extract_archive_summary(path: Path) -> tuple[str, int]:
    if path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as archive:
            infos = [info for info in archive.infolist() if not info.is_dir()]
            total_bytes = sum(int(info.file_size or 0) for info in infos)
            if len(infos) > MAX_ARCHIVE_ENTRIES_SCANNED:
                raise ValueError("archive_too_many_entries")
            if total_bytes > MAX_ARCHIVE_TOTAL_BYTES:
                raise ValueError("archive_too_large")
            names = sorted(info.filename for info in infos)[:MAX_ARCHIVE_ENTRIES_SCANNED]
    else:
        with tarfile.open(path, mode="r:*") as archive:
            members = [member for member in archive.getmembers() if member.isfile()]
            total_bytes = sum(int(member.size or 0) for member in members)
            if len(members) > MAX_ARCHIVE_ENTRIES_SCANNED:
                raise ValueError("archive_too_many_entries")
            if total_bytes > MAX_ARCHIVE_TOTAL_BYTES:
                raise ValueError("archive_too_large")
            names = sorted(member.name for member in members)[:MAX_ARCHIVE_ENTRIES_SCANNED]
    source_like = [
        name
        for name in names
        if Path(name).suffix.lower() in {
            ".py",
            ".ts",
            ".tsx",
            ".js",
            ".jsx",
            ".go",
            ".java",
            ".rs",
            ".rb",
            ".php",
            ".sh",
            ".md",
            ".json",
            ".yaml",
            ".yml",
            ".toml",
        }
        or Path(name).name.lower() in {"readme.md", "package.json", "pyproject.toml", "cargo.toml"}
    ]
    lines = [f"Archive entries: {len(names)}"]
    if source_like:
        lines.append("Source-like files:")
        lines.extend(f"- {name}" for name in source_like[:20])
    else:
        lines.append("Entries:")
        lines.extend(f"- {name}" for name in names[:20])
    return "\n".join(lines), len(names)


def _resolve_extraction_mode(raw_artifact: dict[str, Any]) -> str:
    family = _artifact_family(raw_artifact)
    mime_type = str(raw_artifact.get("mimeType") or "").strip().lower()
    name = str(raw_artifact.get("name") or "").strip().lower()
    if family == "text_document":
        return "plain_text"
    if family == "office_document":
        if mime_type in {
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        }:
            return "office_text"
        return "metadata_only"
    if family == "archive":
        if name.endswith((".zip", ".tar", ".tgz", ".tar.gz")) or mime_type in {
            "application/zip",
            "application/x-zip-compressed",
            "application/x-tar",
            "application/gzip",
            "application/x-gzip",
        }:
            return "archive_summary"
        return "metadata_only"
    if family == "audio":
        return "provider_native" if mime_type in SUPPORTED_NATIVE_AUDIO_MIME_TYPES else "metadata_only"
    if family == "video":
        return "provider_native" if mime_type in SUPPORTED_NATIVE_VIDEO_MIME_TYPES else "metadata_only"
    if family == "binary":
        return "metadata_only"
    if family in {"image", "pdf"}:
        return "provider_native"
    return "metadata_only"


def _extract_plain_text_result(path: Path, raw_artifact: dict[str, Any]) -> ArtifactExtractionResult:
    mime_type = str(raw_artifact.get("mimeType") or "").strip().lower()
    try:
        extracted_text = _extract_text_document(path.read_bytes(), mime_type=mime_type).strip()
    except Exception as exc:  # noqa: BLE001
        return ArtifactExtractionResult(
            extraction_status="failed",
            extraction_mode="plain_text",
            error_code="text_extract_failed",
            error_detail=str(exc),
        )
    return ArtifactExtractionResult(
        extraction_status="ready",
        extraction_mode="plain_text",
        extracted_text=extracted_text[:MAX_EXTRACTED_TEXT_CHARS],
        metadata={"truncated": len(extracted_text) > MAX_EXTRACTED_TEXT_CHARS},
    )


def _extract_office_text_result(path: Path, raw_artifact: dict[str, Any]) -> ArtifactExtractionResult:
    mime_type = str(raw_artifact.get("mimeType") or "").strip().lower()
    if path.stat().st_size > MAX_OFFICE_PARSE_BYTES:
        return ArtifactExtractionResult(
            extraction_status="failed",
            extraction_mode="office_text",
            error_code="office_too_large",
        )
    try:
        if mime_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            extracted_text = _extract_docx_text(path)
            metadata = {"truncated": False}
        elif mime_type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
            extracted_text = _extract_xlsx_text(path)
            metadata = {"truncated": False, "sheetCount": _count_xlsx_sheets(path)}
        elif mime_type == "application/vnd.openxmlformats-officedocument.presentationml.presentation":
            extracted_text = _extract_pptx_text(path)
            metadata = {"truncated": False, "slideCount": _count_pptx_slides(path)}
        else:
            return ArtifactExtractionResult(
                extraction_status="failed",
                extraction_mode="office_text",
                error_code="unsupported_office_format",
            )
    except Exception as exc:  # noqa: BLE001
        return ArtifactExtractionResult(
            extraction_status="failed",
            extraction_mode="office_text",
            error_code="office_parse_failed",
            error_detail=str(exc),
        )
    extracted_text = extracted_text.strip()
    metadata["truncated"] = len(extracted_text) > MAX_EXTRACTED_TEXT_CHARS
    return ArtifactExtractionResult(
        extraction_status="ready",
        extraction_mode="office_text",
        extracted_text=extracted_text[:MAX_EXTRACTED_TEXT_CHARS],
        metadata=metadata,
    )


def _extract_archive_summary_result(path: Path, raw_artifact: dict[str, Any]) -> ArtifactExtractionResult:  # noqa: ARG001
    try:
        extracted_text, entry_count = _extract_archive_summary(path)
    except ValueError as exc:
        error_code = str(exc)
        return ArtifactExtractionResult(
            extraction_status="failed",
            extraction_mode="archive_summary",
            error_code=error_code,
        )
    except Exception as exc:  # noqa: BLE001
        return ArtifactExtractionResult(
            extraction_status="failed",
            extraction_mode="archive_summary",
            error_code="archive_parse_failed",
            error_detail=str(exc),
        )
    extracted_text = extracted_text.strip()
    return ArtifactExtractionResult(
        extraction_status="ready",
        extraction_mode="archive_summary",
        extracted_text=extracted_text[:MAX_EXTRACTED_TEXT_CHARS],
        metadata={
            "truncated": len(extracted_text) > MAX_EXTRACTED_TEXT_CHARS,
            "archiveEntryCount": entry_count,
        },
    )


ARTIFACT_EXTRACTOR_REGISTRY: dict[str, Any] = {
    "plain_text": _extract_plain_text_result,
    "office_text": _extract_office_text_result,
    "archive_summary": _extract_archive_summary_result,
}


async def ensure_local_artifact_extraction(
    payload: dict[str, Any] | None,
    *,
    artifacts_dir: Path,
) -> dict[str, Any]:
    normalized_payload = dict(payload or {})
    artifacts = normalized_payload.get("messageArtifactsById")
    if not isinstance(artifacts, dict) or not artifacts:
        return normalized_payload
    local_artifacts = dict(normalized_payload.get("localArtifactsById") or {})
    extracted_root = artifacts_dir / "agent-extracted"
    for artifact_id, raw_artifact in artifacts.items():
        if not isinstance(raw_artifact, dict):
            continue
        local_entry = dict(local_artifacts.get(artifact_id) or {})
        if str(local_entry.get("downloadStatus") or "").strip() != "ready":
            local_artifacts[artifact_id] = local_entry
            continue
        cache_path = Path(str(local_entry.get("cachePath") or "").strip())
        if not cache_path.exists():
            local_artifacts[artifact_id] = local_entry
            continue
        extraction_mode = _resolve_extraction_mode(raw_artifact)
        if extraction_mode not in {"metadata_only", "provider_native"} and cache_path.stat().st_size > MAX_EXTRACTION_INPUT_BYTES:
            local_entry.update(
                {
                    "extractionStatus": "failed",
                    "extractionMode": extraction_mode,
                    "extractErrorCode": "extraction_input_too_large",
                }
            )
            local_artifacts[artifact_id] = local_entry
            continue
        if extraction_mode in {"metadata_only", "provider_native"}:
            local_entry["extractionStatus"] = "skipped"
            local_entry["extractionMode"] = extraction_mode
            local_artifacts[artifact_id] = local_entry
            continue
        existing_extracted_path = Path(str(local_entry.get("extractedTextPath") or "").strip())
        if (
            str(local_entry.get("extractionStatus") or "").strip() == "ready"
            and existing_extracted_path.exists()
            and str(local_entry.get("sourceVerifiedSha256") or "").strip()
            == str(local_entry.get("verifiedSha256") or "").strip()
        ):
            local_entry["extractionMode"] = extraction_mode
            local_artifacts[artifact_id] = local_entry
            continue
        extractor = ARTIFACT_EXTRACTOR_REGISTRY.get(extraction_mode)
        if extractor is None:
            local_entry.update(
                {
                    "extractionStatus": "failed",
                    "extractionMode": extraction_mode,
                    "extractErrorCode": "extractor_missing",
                }
            )
            local_artifacts[artifact_id] = local_entry
            continue
        result = extractor(cache_path, raw_artifact)
        if result.extraction_status != "ready" or result.extracted_text is None:
            local_entry.update(
                {
                    "extractionStatus": result.extraction_status,
                    "extractionMode": result.extraction_mode,
                    "extractErrorCode": result.error_code or "extract_failed",
                    **({"extractError": result.error_detail} if result.error_detail else {}),
                    **(result.metadata or {}),
                }
            )
            local_artifacts[artifact_id] = local_entry
            continue
        try:
            extracted_text = result.extracted_text.strip()
            safe_artifact_id = _sanitize_artifact_path_component(artifact_id, fallback="artifact")
            extracted_path = _safe_path_within(extracted_root, safe_artifact_id, "content.txt")
            extracted_path.parent.mkdir(parents=True, exist_ok=True)
            extracted_path.write_text(extracted_text, encoding="utf-8")
            local_entry.update(
                {
                    "extractionStatus": result.extraction_status,
                    "extractionMode": result.extraction_mode,
                    "extractedTextPath": str(extracted_path),
                    "extractedCharCount": len(extracted_text),
                    "extractedSha256": hashlib.sha256(extracted_text.encode("utf-8")).hexdigest(),
                    "sourceVerifiedSha256": str(local_entry.get("verifiedSha256") or "").strip() or None,
                    **(result.metadata or {}),
                }
            )
        except Exception as exc:  # noqa: BLE001
            local_entry.update(
                {
                    "extractionStatus": "failed",
                    "extractionMode": extraction_mode,
                    "extractErrorCode": "extract_failed",
                    "extractError": str(exc),
                }
            )
        local_artifacts[artifact_id] = local_entry
    normalized_payload["localArtifactsById"] = local_artifacts
    return normalized_payload


def prune_stale_artifact_cache(artifacts_dir: Path, *, older_than_seconds: int) -> int:
    if older_than_seconds <= 0 or not artifacts_dir.exists():
        return 0
    threshold = datetime.now(UTC).timestamp() - older_than_seconds
    removed = 0
    for path in artifacts_dir.rglob("*"):
        if not path.is_file():
            continue
        try:
            if path.stat().st_mtime <= threshold:
                path.unlink()
                removed += 1
        except FileNotFoundError:
            continue
    for root, dirs, files in os.walk(artifacts_dir, topdown=False):
        if dirs or files:
            continue
        current = Path(root)
        if current != artifacts_dir:
            current.rmdir()
    return removed


def collect_ready_executor_attachments(payload: dict[str, Any] | None) -> list[dict[str, Any]]:
    normalized_payload = payload or {}
    artifacts = normalized_payload.get("messageArtifactsById")
    if not isinstance(artifacts, dict) or not artifacts:
        return []
    local_artifacts = normalized_payload.get("localArtifactsById")
    local_map = local_artifacts if isinstance(local_artifacts, dict) else {}
    collected: list[dict[str, Any]] = []
    for artifact_id, raw_artifact in artifacts.items():
        if not isinstance(raw_artifact, dict):
            continue
        local_entry = local_map.get(artifact_id)
        if not isinstance(local_entry, dict):
            continue
        if str(local_entry.get("downloadStatus") or "").strip() != "ready":
            continue
        cache_path = str(local_entry.get("cachePath") or "").strip()
        if not cache_path:
            continue
        path = Path(cache_path)
        if not path.exists():
            continue
        collected.append(
            {
                "artifactId": str(raw_artifact.get("artifactId") or artifact_id),
                "kind": str(raw_artifact.get("kind") or "").strip(),
                "mimeType": str(raw_artifact.get("mimeType") or "").strip(),
                "name": str(raw_artifact.get("name") or path.name).strip(),
                "cachePath": str(path),
                "contentBytes": path.read_bytes(),
            }
        )
    return collected


async def ensure_local_artifact_cache(
    payload: dict[str, Any] | None,
    *,
    session_id: str,
    artifacts_dir: Path,
    sync_api: object,
) -> dict[str, Any]:
    normalized_payload = dict(payload or {})
    artifacts = normalized_payload.get("messageArtifactsById")
    if not isinstance(artifacts, dict) or not artifacts:
        return normalized_payload
    local_artifacts = dict(normalized_payload.get("localArtifactsById") or {})
    for artifact_id, raw_artifact in artifacts.items():
        if not isinstance(raw_artifact, dict):
            continue
        existing = local_artifacts.get(artifact_id)
        existing_path = (
            Path(str(existing.get("cachePath") or "").strip())
            if isinstance(existing, dict) and str(existing.get("cachePath") or "").strip()
            else None
        )
        if (
            isinstance(existing, dict)
            and str(existing.get("downloadStatus") or "").strip() == "ready"
            and existing_path is not None
            and existing_path.exists()
        ):
            existing["lastAccessedAt"] = datetime.now(UTC).isoformat()
            local_artifacts[artifact_id] = existing
            continue
        try:
            fetcher = sync_api.fetch_agent_session_artifact_content
            content_bytes, resolved_mime_type = await fetcher(session_id, artifact_id)
            expected_size = int(raw_artifact.get("sizeBytes") or 0) if str(raw_artifact.get("sizeBytes") or "").strip() else 0
            if expected_size and len(content_bytes) != expected_size:
                local_artifacts[artifact_id] = {
                    "artifactId": artifact_id,
                    "downloadStatus": "failed",
                    "errorCode": "size_mismatch",
                }
                continue
            expected_sha = str(raw_artifact.get("sha256") or "").strip().lower()
            verified_sha = hashlib.sha256(content_bytes).hexdigest()
            if expected_sha and verified_sha != expected_sha:
                local_artifacts[artifact_id] = {
                    "artifactId": artifact_id,
                    "downloadStatus": "failed",
                    "errorCode": "checksum_mismatch",
                }
                continue
            safe_session_id = _sanitize_artifact_path_component(session_id, fallback="session")
            safe_artifact_id = _sanitize_artifact_path_component(artifact_id, fallback="artifact")
            safe_name = _sanitize_artifact_path_component(raw_artifact.get("name"), fallback=safe_artifact_id)
            artifact_path = _safe_path_within(artifacts_dir / "agent-pending", safe_session_id, safe_artifact_id, safe_name)
            artifact_path.parent.mkdir(parents=True, exist_ok=True)
            artifact_path.write_bytes(content_bytes)
            timestamp = datetime.now(UTC).isoformat()
            local_artifacts[artifact_id] = {
                "artifactId": artifact_id,
                "cachePath": str(artifact_path),
                "downloadStatus": "ready",
                "byteSize": len(content_bytes),
                "downloadedAt": timestamp,
                "lastAccessedAt": timestamp,
                "mimeType": str(resolved_mime_type or raw_artifact.get("mimeType") or "").strip() or None,
                "verifiedSha256": verified_sha,
            }
        except Exception as exc:  # noqa: BLE001
            local_artifacts[artifact_id] = {
                "artifactId": artifact_id,
                "downloadStatus": "failed",
                "errorCode": "fetch_failed",
                "error": str(exc),
            }
    normalized_payload["localArtifactsById"] = local_artifacts
    return normalized_payload


def initialize_local_artifact_state(payload: dict[str, Any] | None) -> dict[str, Any]:
    normalized_payload = dict(payload or {})
    artifacts = normalized_payload.get("messageArtifactsById")
    if not isinstance(artifacts, dict) or not artifacts:
        return normalized_payload
    local_artifacts = dict(normalized_payload.get("localArtifactsById") or {})
    for artifact_id in artifacts.keys():
        key = str(artifact_id).strip()
        if not key:
            continue
        existing = local_artifacts.get(key)
        if isinstance(existing, dict) and str(existing.get("downloadStatus") or "").strip():
            continue
        local_artifacts[key] = {
            "artifactId": key,
            "downloadStatus": "pending",
        }
    normalized_payload["localArtifactsById"] = local_artifacts
    return normalized_payload


@dataclass(slots=True)
class AgentArtifactCacheService:
    artifacts_dir: Path
    sync_api: object

    async def ensure_case_payload(self, payload: dict[str, Any], *, session_id: str) -> dict[str, Any]:
        prune_stale_artifact_cache(self.artifacts_dir, older_than_seconds=60 * 60 * 24 * 7)
        cached_payload = await ensure_local_artifact_cache(
            payload,
            session_id=session_id,
            artifacts_dir=self.artifacts_dir,
            sync_api=self.sync_api,
        )
        return await ensure_local_artifact_extraction(
            cached_payload,
            artifacts_dir=self.artifacts_dir,
        )
