from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.models import (
    AgentConnectedAccount,
    AgentOnboardingItem,
    AgentPendingItem,
    AgentSession,
    AppSetting,
    AuditEvent,
    Case,
    CaseEvent,
    CredentialBindingMetadata,
    ExecutionRun,
    ReviewCommand,
)


def _to_iso8601(value: datetime | None) -> str | None:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return value.astimezone(UTC).isoformat()


def _parse_datetime(raw_value) -> datetime | None:  # noqa: ANN001
    if not raw_value:
        return None
    value = datetime.fromisoformat(str(raw_value))
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


@dataclass(frozen=True, slots=True)
class TimelineEvent:
    created_at: datetime
    event_type: str
    source: str
    payload: dict

    def to_payload(self) -> dict[str, object]:
        return {
            "createdAt": _to_iso8601(self.created_at),
            "eventType": self.event_type,
            "source": self.source,
            "payload": self.payload,
        }


class AdminQueryService:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def get_status_snapshot(self) -> dict[str, object]:
        async with self.session_factory() as session:
            total_cases = await session.scalar(select(func.count()).select_from(Case))
            case_rows = (
                await session.execute(
                    select(Case.status, func.count()).group_by(Case.status)
                )
            ).all()
            credential_rows = (
                await session.execute(
                    select(CredentialBindingMetadata).order_by(CredentialBindingMetadata.connector_type.asc())
                )
            ).scalars().all()
            agent_session_rows = (
                await session.execute(select(AgentSession.status, func.count()).group_by(AgentSession.status))
            ).all()
            agent_pending_rows = (
                await session.execute(select(AgentPendingItem.status, func.count()).group_by(AgentPendingItem.status))
            ).all()
            onboarding_rows = (
                await session.execute(select(AgentOnboardingItem.status, func.count()).group_by(AgentOnboardingItem.status))
            ).all()
            connected_account_rows = (
                await session.execute(
                    select(AgentConnectedAccount.status, func.count()).group_by(AgentConnectedAccount.status)
                )
            ).all()
        by_status = {status.value: int(count) for status, count in case_rows}
        credentials = {
            row.connector_type.value: {
                "isEnabled": row.is_enabled,
                "lastValidatedAt": _to_iso8601(row.last_validated_at),
                "manualActionRequired": bool(row.metadata_json.get("manualActionRequired")),
                "lastError": row.metadata_json.get("lastError"),
                "lastErrorCode": row.metadata_json.get("lastErrorCode"),
            }
            for row in credential_rows
        }
        return {
            "cases": {
                "total": int(total_cases or 0),
                "byStatus": by_status,
            },
            "credentials": {
                "byConnector": credentials,
            },
            "agentSync": {
                "sessions": {
                    "total": int(sum(int(count) for _, count in agent_session_rows)),
                    "byStatus": {status.value: int(count) for status, count in agent_session_rows},
                },
                "pendingItems": {status.value: int(count) for status, count in agent_pending_rows},
                "onboardingItems": {status.value: int(count) for status, count in onboarding_rows},
                "connectedAccounts": {status.value: int(count) for status, count in connected_account_rows},
            },
        }

    async def get_agent_sync_snapshot(self) -> dict[str, object]:
        async with self.session_factory() as session:
            session_rows = (
                await session.execute(select(AgentSession.status, func.count()).group_by(AgentSession.status))
            ).all()
            pending_rows = (
                await session.execute(select(AgentPendingItem.status, func.count()).group_by(AgentPendingItem.status))
            ).all()
            onboarding_rows = (
                await session.execute(select(AgentOnboardingItem.status, func.count()).group_by(AgentOnboardingItem.status))
            ).all()
            account_rows = (
                await session.execute(
                    select(AgentConnectedAccount.status, func.count()).group_by(AgentConnectedAccount.status)
                )
            ).all()
        return {
            "sessions": {
                "total": int(sum(int(count) for _, count in session_rows)),
                "byStatus": {status.value: int(count) for status, count in session_rows},
            },
            "pendingItems": {status.value: int(count) for status, count in pending_rows},
            "onboardingItems": {status.value: int(count) for status, count in onboarding_rows},
            "connectedAccounts": {status.value: int(count) for status, count in account_rows},
        }

    async def get_case_timeline(self, case_id: str) -> dict[str, object] | None:
        async with self.session_factory() as session:
            case = await session.get(Case, case_id)
            if case is None:
                return None
            case_events = (
                await session.execute(
                    select(CaseEvent).where(CaseEvent.case_id == case_id).order_by(CaseEvent.created_at.asc())
                )
            ).scalars().all()
            audit_events = (
                await session.execute(
                    select(AuditEvent)
                    .where(AuditEvent.entity_type == "case", AuditEvent.entity_id == case_id)
                    .order_by(AuditEvent.created_at.asc())
                )
            ).scalars().all()
        events: list[TimelineEvent] = [
            TimelineEvent(
                created_at=row.created_at,
                event_type=row.event_type,
                source="case_event",
                payload=row.payload_json,
            )
            for row in case_events
        ]
        events.extend(
            TimelineEvent(
                created_at=row.created_at,
                event_type=row.event_type,
                source="audit_event",
                payload=row.payload_json,
            )
            for row in audit_events
        )
        events.sort(key=lambda item: item.created_at)
        return {
            "caseId": case.id,
            "status": case.status.value,
            "events": [item.to_payload() for item in events],
        }

    async def get_metrics_snapshot(self, *, daemon_running: bool, queue_depth: int) -> dict[str, object]:
        async with self.session_factory() as session:
            execution_rows = (await session.execute(select(ExecutionRun))).scalars().all()
            review_rows = (await session.execute(select(ReviewCommand))).scalars().all()
            sync_rows = (
                await session.execute(
                    select(AppSetting).where(AppSetting.key.like("sync_metadata:%"))
                )
            ).scalars().all()

        now = datetime.now(UTC)
        execution_durations_ms = [
            int((row.updated_at - row.created_at).total_seconds() * 1000)
            for row in execution_rows
            if row.updated_at and row.created_at
        ]
        review_latencies_ms = [
            int((row.completed_at - row.created_at).total_seconds() * 1000)
            for row in review_rows
            if row.completed_at and row.created_at
        ]
        connectors = {}
        for row in sync_rows:
            connector_name = row.key.removeprefix("sync_metadata:")
            payload = row.value_json
            last_success_at = _parse_datetime(payload.get("last_success_at"))
            attempt_count = int(payload.get("attempt_count") or 0)
            failure_total = int(payload.get("failure_total") or 0)
            connectors[connector_name] = {
                "failureCount": int(payload.get("failure_count") or 0),
                "errorRate": (failure_total / attempt_count) if attempt_count else 0.0,
                "lastError": payload.get("last_error"),
                "lastSuccessAt": _to_iso8601(last_success_at),
                "lastSyncAgeSeconds": int((now - last_success_at).total_seconds()) if last_success_at is not None else None,
                "nextAllowedAt": payload.get("next_allowed_at"),
            }
        return {
            "daemon": {
                "status": "running" if daemon_running else "stopped",
            },
            "queue": {
                "depth": queue_depth,
            },
            "connectors": connectors,
            "execution": {
                "count": len(execution_rows),
                "avgDurationMs": int(sum(execution_durations_ms) / len(execution_durations_ms)) if execution_durations_ms else 0,
            },
            "review": {
                "completedCount": sum(1 for row in review_rows if row.completed_at is not None),
                "avgLatencyMs": int(sum(review_latencies_ms) / len(review_latencies_ms)) if review_latencies_ms else 0,
            },
        }

