from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Protocol

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.enums import (
    AgentExecutionDecisionType,
    AgentPendingItemStatus,
    AgentPendingItemType,
    AgentSessionMode,
    AgentSessionStatus,
    AgentWriteDraftStatus,
    CaseSource,
    CaseStatus,
    ConnectorType,
    ExecutionEngine,
)
from workagent.db.models import (
    AgentPendingItem,
    AgentPendingItemReceipt,
    AgentSession,
    AgentWriteDraft,
    AuditEvent,
    Case,
    ExecutionRun,
)
from workagent.sync.models import AgentPendingItemAckPayload, AgentPendingItemRecord, AgentPendingItemResultPayload

logger = logging.getLogger("workagent.agent_sync")
logger.propagate = True


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _truncate_for_log(value: str | None, *, limit: int = 400) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    if len(normalized) <= limit:
        return normalized
    return f"{normalized[: limit - 3]}..."


def _connector_type_from_payload(payload: dict[str, object]) -> ConnectorType | None:
    raw_value = str(payload.get("connectorType") or "").strip().lower()
    if not raw_value:
        return None
    try:
        return ConnectorType(raw_value)
    except ValueError:
        return None


def _connector_type_from_draft(draft: AgentWriteDraft | None) -> ConnectorType | None:
    if draft is None:
        return None
    kind = str(draft.draft_kind.value).strip().lower()
    if kind.startswith("slack_"):
        return ConnectorType.slack
    if kind.startswith("gitlab_"):
        return ConnectorType.gitlab
    if kind.startswith("jira_"):
        return ConnectorType.jira
    if kind.startswith("confluence_"):
        return ConnectorType.confluence
    return None


def _pending_item_result_status(_: dict[str, object]) -> str:
    return AgentPendingItemStatus.completed.value


class PendingItemPoller(Protocol):
    async def poll_once(self): ...  # noqa: ANN201

    async def commit(self, batch) -> None: ...  # noqa: ANN001


class PendingItemSyncApi(Protocol):
    async def ack_agent_pending_item(self, item_id: str, payload: AgentPendingItemAckPayload) -> dict: ...

    async def push_agent_pending_item_result(self, item_id: str, payload: AgentPendingItemResultPayload) -> dict: ...


@dataclass(frozen=True, slots=True)
class AgentPendingItemBatch:
    items: list[AgentPendingItemRecord]
    previous_cursor: str | None
    next_cursor: str | None


@dataclass(frozen=True, slots=True)
class SyncedPendingItemOutcome:
    item_id: str
    status: str


@dataclass(slots=True)
class AgentPendingItemSyncService:
    session_factory: async_sessionmaker[AsyncSession]
    poller: PendingItemPoller
    sync_api: PendingItemSyncApi
    request_router: object | None = None
    execution_engine: ExecutionEngine = ExecutionEngine.codex_cli
    queue: object | None = None
    memory_writer: object | None = None
    artifacts_dir: object | None = None

    async def sync_once(self) -> list[SyncedPendingItemOutcome]:
        batch = await self.poller.poll_once()
        if batch.items:
            logger.info(
                "w10w225 pending batch received count=%s previous_cursor=%r next_cursor=%r",
                len(batch.items),
                batch.previous_cursor,
                batch.next_cursor,
            )
        outcomes: list[SyncedPendingItemOutcome] = []
        for item in batch.items:
            outcomes.append(await self.process_remote_item(item))
        await self.poller.commit(batch)
        return outcomes

    async def process_remote_item(self, item: AgentPendingItemRecord) -> SyncedPendingItemOutcome:
        logger.info(
            "w10w225 pending item received item_id=%s item_type=%s session_id=%s thread_id=%s message_id=%s "
            "request_text=%r reply_text=%r decision_type=%r",
            item.id,
            item.item_type,
            item.session_id,
            item.thread_id,
            item.message_id,
            _truncate_for_log(str(item.payload.get("requestText") or "")) or None,
            _truncate_for_log(str(item.payload.get("replyText") or "")) or None,
            str(item.payload.get("decisionType") or "").strip() or None,
        )
        if await self._is_already_completed(item.id):
            await self._replay_completed_result(item.id)
            logger.info("w10w225 pending item skipped item_id=%s reason=already_completed", item.id)
            return SyncedPendingItemOutcome(item_id=item.id, status="completed")
        try:
            await self._upsert_local_item(item)
            await self._report_ack(item.id)
            result = await self._process_item(item)
            await self._report_result(item.id, result=result)
            logger.info(
                "w10w225 pending item processed item_id=%s action=%r case_id=%r session_id=%r result_status=%s",
                item.id,
                str(result.get("action") or result.get("decisionType") or "").strip() or None,
                str(result.get("caseId") or "").strip() or None,
                str(result.get("sessionId") or "").strip() or None,
                _pending_item_result_status(result),
            )
            return SyncedPendingItemOutcome(item_id=item.id, status="completed")
        except Exception as exc:
            await self._mark_local_item_failed(item.id, error_message=str(exc))
            logger.exception("w10w225 pending item failed item_id=%s item_type=%s", item.id, item.item_type)
            raise

    async def _is_already_completed(self, item_id: str) -> bool:
        async with self.session_factory() as session:
            existing = await session.get(AgentPendingItem, item_id)
            return existing is not None and existing.status == AgentPendingItemStatus.completed

    async def _upsert_local_item(self, item: AgentPendingItemRecord) -> None:
        async with self.session_factory() as session:
            existing = await session.get(AgentPendingItem, item.id)
            session_id = item.session_id
            if session_id:
                linked_session = await session.get(AgentSession, session_id)
                if linked_session is None:
                    session_id = None
            if existing is None:
                session.add(
                    AgentPendingItem(
                        id=item.id,
                        session_id=session_id,
                        workspace_id=str(item.payload.get("workspaceId") or "workspace-unknown"),
                        target_installation_id=str(item.payload.get("targetInstallationId") or "installation-unknown"),
                        thread_id=item.thread_id,
                        message_id=item.message_id,
                        item_type=AgentPendingItemType(item.item_type),
                        status=AgentPendingItemStatus.pending,
                        payload_json=item.payload,
                        idempotency_key=f"pending:{item.id}",
                    )
                )
            else:
                existing.payload_json = item.payload
                if session_id:
                    existing.session_id = session_id
                if existing.status != AgentPendingItemStatus.completed:
                    existing.status = AgentPendingItemStatus.pending
                existing.updated_at = _utcnow()
            await session.commit()

    async def _report_ack(self, item_id: str) -> None:
        async with self.session_factory() as session:
            receipt = await session.scalar(
                select(AgentPendingItemReceipt).where(
                    AgentPendingItemReceipt.pending_item_id == item_id,
                    AgentPendingItemReceipt.receipt_type == "ack",
                )
            )
            if receipt is not None:
                return
        payload = AgentPendingItemAckPayload(receiptId=f"{item_id}:claimed", status="claimed")
        await self.sync_api.ack_agent_pending_item(item_id, payload)
        async with self.session_factory() as session:
            pending_item = await session.get(AgentPendingItem, item_id)
            local_case_id = await _resolve_local_case_id_for_pending_item(session, pending_item) if pending_item is not None else None
            session.add(
                AgentPendingItemReceipt(
                    pending_item_id=item_id,
                    target_installation_id="installation-unknown",
                    local_case_id=local_case_id,
                    receipt_type="ack",
                    receipt_status="claimed",
                    result_json=payload.model_dump(by_alias=True),
                )
            )
            await session.commit()

    async def _report_result(self, item_id: str, *, result: dict[str, object]) -> None:
        async with self.session_factory() as session:
            receipt = await session.scalar(
                select(AgentPendingItemReceipt).where(
                    AgentPendingItemReceipt.pending_item_id == item_id,
                    AgentPendingItemReceipt.receipt_type == "result",
                )
            )
            if receipt is not None:
                return
        payload = AgentPendingItemResultPayload(status=_pending_item_result_status(result), result=result)
        await self.sync_api.push_agent_pending_item_result(item_id, payload)
        async with self.session_factory() as session:
            local_case_id = str(result.get("caseId") or "").strip() or None
            session.add(
                AgentPendingItemReceipt(
                    pending_item_id=item_id,
                    target_installation_id="installation-unknown",
                    local_case_id=local_case_id,
                    receipt_type="result",
                    receipt_status=payload.status,
                    result_json=payload.model_dump(by_alias=True),
                )
            )
            await session.commit()

    async def _replay_completed_result(self, item_id: str) -> None:
        payload = await self._completed_result_payload(item_id)
        if payload is None:
            return
        await self.sync_api.push_agent_pending_item_result(item_id, payload)
        await self._store_result_receipt(item_id, payload=payload)

    async def _completed_result_payload(self, item_id: str) -> AgentPendingItemResultPayload | None:
        async with self.session_factory() as session:
            receipt = await session.scalar(
                select(AgentPendingItemReceipt).where(
                    AgentPendingItemReceipt.pending_item_id == item_id,
                    AgentPendingItemReceipt.receipt_type == "result",
                )
            )
            if receipt is not None:
                try:
                    return AgentPendingItemResultPayload.model_validate(receipt.result_json or {})
                except Exception:  # noqa: BLE001
                    logger.warning("w10w225 pending item stored result receipt invalid item_id=%s", item_id)

            pending_item = await session.get(AgentPendingItem, item_id)
            if pending_item is None:
                return None
            local_case_id = await _resolve_local_case_id_for_pending_item(session, pending_item)
            result: dict[str, object] = {}
            if local_case_id is not None:
                result["caseId"] = local_case_id
            if pending_item.session_id is not None:
                result["sessionId"] = pending_item.session_id
            if pending_item.item_type is AgentPendingItemType.interactive_user_reply:
                result["action"] = "case_resumed"
            elif pending_item.item_type in {
                AgentPendingItemType.new_direct_request,
                AgentPendingItemType.project_workflow_stage_execute,
            }:
                result["action"] = "case_created"
            elif pending_item.item_type is AgentPendingItemType.interactive_execution_decision:
                decision_type = str((pending_item.payload_json or {}).get("decisionType") or "").strip()
                if decision_type:
                    result["decisionType"] = decision_type
            return AgentPendingItemResultPayload(status=AgentPendingItemStatus.completed.value, result=result)

    async def _store_result_receipt(self, item_id: str, *, payload: AgentPendingItemResultPayload) -> None:
        async with self.session_factory() as session:
            receipt = await session.scalar(
                select(AgentPendingItemReceipt).where(
                    AgentPendingItemReceipt.pending_item_id == item_id,
                    AgentPendingItemReceipt.receipt_type == "result",
                )
            )
            if receipt is not None:
                receipt.receipt_status = payload.status
                receipt.result_json = payload.model_dump(by_alias=True)
                await session.commit()
                return
            session.add(
                AgentPendingItemReceipt(
                    pending_item_id=item_id,
                    target_installation_id="installation-unknown",
                    local_case_id=str(payload.result.get("caseId") or "").strip() or None,
                    receipt_type="result",
                    receipt_status=payload.status,
                    result_json=payload.model_dump(by_alias=True),
                )
            )
            await session.commit()

    async def _process_item(self, item: AgentPendingItemRecord) -> dict[str, object]:
        item_type = AgentPendingItemType(item.item_type)
        if item_type is AgentPendingItemType.new_direct_request:
            return await self._process_cli_request(
                item,
                case_source=CaseSource.w10w225_direct_request,
                title=str(item.payload.get("requestText") or "").strip() or "Interactive request",
                connector_type=_connector_type_from_payload(item.payload),
                result_action="case_created",
            )
        if item_type is AgentPendingItemType.project_workflow_stage_execute:
            return await self._process_cli_request(
                item,
                case_source=CaseSource.project_workflow,
                title=str(item.payload.get("requestText") or "").strip() or "Project workflow request",
                connector_type=None,
                result_action="case_created",
            )
        if item_type is AgentPendingItemType.interactive_user_reply:
            return await self._process_user_reply(item)
        return await self._process_execution_decision(item)

    async def _process_cli_request(
        self,
        item: AgentPendingItemRecord,
        *,
        case_source: CaseSource,
        title: str,
        connector_type: ConnectorType | None,
        result_action: str,
    ) -> dict[str, object]:
        case_id, session_id = await self._create_case_for_item(
            item,
            case_source=case_source,
            title=title,
            connector_type=connector_type,
        )
        run_id = await self._create_execution_run(case_id=case_id, item=item)
        try:
            await self._route_item(item, case_id=case_id)
        except Exception as exc:
            await self._fail_case(
                case_id=case_id,
                session_id=session_id,
                item_id=item.id,
                run_id=run_id,
                error_message=str(exc),
            )
            raise
        await self._complete_execution_run(run_id, metadata={"resultAction": result_action})
        await self._finalize_cli_case(case_id=case_id, session_id=session_id, item_id=item.id)
        return {"caseId": case_id, "sessionId": session_id, "action": result_action}

    async def _process_user_reply(self, item: AgentPendingItemRecord) -> dict[str, object]:
        session_id = str(item.session_id or "").strip()
        if not session_id:
            return await self._ignore_reply(item, reason="session_missing")

        async with self.session_factory() as session:
            agent_session = await session.get(AgentSession, session_id)
            if agent_session is None:
                return await self._ignore_reply(item, reason="session_missing")
            if item.message_id and await session.scalar(
                select(AgentPendingItem.id).where(
                    AgentPendingItem.session_id == session_id,
                    AgentPendingItem.item_type == AgentPendingItemType.interactive_user_reply,
                    AgentPendingItem.message_id == item.message_id,
                    AgentPendingItem.status == AgentPendingItemStatus.completed,
                    AgentPendingItem.id != item.id,
                )
            ):
                return await self._ignore_reply(item, reason="duplicate_reply")

        case_id, resolved_session_id = await self._create_case_for_item(
            item,
            case_source=CaseSource.w10w225_direct_request,
            title=str(item.payload.get("replyText") or "").strip() or "Interactive reply",
            connector_type=_connector_type_from_payload(item.payload),
        )
        run_id = await self._create_execution_run(case_id=case_id, item=item)
        try:
            await self._route_item(item, case_id=case_id)
        except Exception as exc:
            await self._fail_case(
                case_id=case_id,
                session_id=resolved_session_id,
                item_id=item.id,
                run_id=run_id,
                error_message=str(exc),
            )
            raise
        await self._complete_execution_run(run_id, metadata={"resultAction": "case_resumed"})
        await self._finalize_cli_case(case_id=case_id, session_id=resolved_session_id, item_id=item.id)
        return {"caseId": case_id, "sessionId": resolved_session_id, "action": "case_resumed"}

    async def _process_execution_decision(self, item: AgentPendingItemRecord) -> dict[str, object]:
        session_id = str(item.session_id or item.payload.get("sessionId") or "").strip()
        if not session_id:
            raise ValueError("interactive session not found")

        decision_type = AgentExecutionDecisionType(str(item.payload.get("decisionType") or "").strip().lower())
        draft_id = str(item.payload.get("writeDraftId") or "").strip() or None

        async with self.session_factory() as session:
            agent_session = await session.get(AgentSession, session_id)
            if agent_session is None:
                raise ValueError(f"interactive session not found: {session_id}")
            draft = await session.get(AgentWriteDraft, draft_id) if draft_id else None

        case_id, resolved_session_id = await self._create_case_for_item(
            item,
            case_source=CaseSource.w10w225_direct_request,
            title=f"Execution decision: {decision_type.value}",
            connector_type=_connector_type_from_draft(draft),
        )

        if decision_type is AgentExecutionDecisionType.request_followup:
            await self._finalize_followup_decision(case_id=case_id, session_id=resolved_session_id, item_id=item.id)
            return {"caseId": case_id, "sessionId": resolved_session_id, "decisionType": decision_type.value}

        try:
            await self._route_item(item, case_id=case_id)
        except Exception as exc:
            await self._fail_case(
                case_id=case_id,
                session_id=resolved_session_id,
                item_id=item.id,
                run_id=None,
                error_message=str(exc),
            )
            raise

        await self._finalize_execution_decision(
            case_id=case_id,
            session_id=resolved_session_id,
            item_id=item.id,
            draft_id=draft_id,
            decision_type=decision_type,
        )
        return {"caseId": case_id, "sessionId": resolved_session_id, "decisionType": decision_type.value}

    async def _create_case_for_item(
        self,
        item: AgentPendingItemRecord,
        *,
        case_source: CaseSource,
        title: str,
        connector_type: ConnectorType | None,
    ) -> tuple[str, str]:
        session_id = str(item.session_id or item.id).strip() or item.id
        async with self.session_factory() as session:
            agent_session = await session.get(AgentSession, session_id)
            if agent_session is None:
                agent_session = AgentSession(
                    id=session_id,
                    workspace_id=str(item.payload.get("workspaceId") or "workspace-unknown"),
                    room_id=str(item.payload.get("roomId") or "").strip() or None,
                    thread_id=item.thread_id,
                    requesting_user_id=str(
                        item.payload.get("requestingUserId")
                        or item.payload.get("replyingUserId")
                        or item.payload.get("decisionUserId")
                        or "user-unknown"
                    ),
                    target_installation_id=str(item.payload.get("targetInstallationId") or "installation-unknown"),
                    local_case_id=None,
                    mode=AgentSessionMode.interactive,
                    status=AgentSessionStatus.running,
                )
                session.add(agent_session)
                await session.flush()
            else:
                agent_session.workspace_id = str(item.payload.get("workspaceId") or agent_session.workspace_id)
                agent_session.room_id = str(item.payload.get("roomId") or "").strip() or agent_session.room_id
                agent_session.thread_id = item.thread_id
                agent_session.requesting_user_id = str(
                    item.payload.get("requestingUserId")
                    or item.payload.get("replyingUserId")
                    or item.payload.get("decisionUserId")
                    or agent_session.requesting_user_id
                )
                agent_session.target_installation_id = str(
                    item.payload.get("targetInstallationId") or agent_session.target_installation_id
                )

            case = Case(
                source=case_source,
                status=CaseStatus.interactive_running,
                connector_type=connector_type,
                title=title[:120] or "Pending item",
                payload_json={
                    **dict(item.payload or {}),
                    "threadId": item.thread_id,
                    "messageId": item.message_id,
                },
            )
            session.add(case)
            await session.flush()

            agent_session.local_case_id = case.id
            agent_session.status = AgentSessionStatus.running
            if item.message_id:
                agent_session.latest_user_message_id = item.message_id
            agent_session.updated_at = _utcnow()

            pending = await session.get(AgentPendingItem, item.id)
            if pending is not None:
                pending.session_id = agent_session.id
                pending.updated_at = _utcnow()

            session.add(
                AuditEvent(
                    event_type="interactive.case_created",
                    entity_type="case",
                    entity_id=case.id,
                    payload_json={"pendingItemId": item.id, "sessionId": agent_session.id},
                )
            )
            await session.commit()
            return case.id, agent_session.id

    async def _create_execution_run(self, *, case_id: str, item: AgentPendingItemRecord) -> str:
        async with self.session_factory() as session:
            run = ExecutionRun(
                case_id=case_id,
                engine=self.execution_engine,
                status="running",
                thread_id=item.thread_id,
                metadata_json={
                    "pendingItemId": item.id,
                    "sessionId": item.session_id,
                    "itemType": item.item_type,
                    "messageId": item.message_id,
                },
            )
            session.add(run)
            await session.commit()
            return run.id

    async def _complete_execution_run(self, run_id: str, *, metadata: dict[str, object] | None = None) -> None:
        async with self.session_factory() as session:
            run = await session.get(ExecutionRun, run_id)
            if run is None:
                return
            run.status = "completed"
            if metadata:
                run.metadata_json = {**dict(run.metadata_json or {}), **metadata}
            await session.commit()

    async def _fail_case(
        self,
        *,
        case_id: str,
        session_id: str,
        item_id: str,
        run_id: str | None,
        error_message: str,
    ) -> None:
        async with self.session_factory() as session:
            case = await session.get(Case, case_id)
            agent_session = await session.get(AgentSession, session_id)
            pending = await session.get(AgentPendingItem, item_id)
            run = await session.get(ExecutionRun, run_id) if run_id else None
            if case is not None:
                case.status = CaseStatus.failed
                case.updated_at = _utcnow()
            if agent_session is not None:
                agent_session.status = AgentSessionStatus.failed
                agent_session.updated_at = _utcnow()
            if pending is not None:
                pending.status = AgentPendingItemStatus.failed
                pending.error_message = error_message
                pending.updated_at = _utcnow()
            if run is not None:
                run.status = "failed"
                run.metadata_json = {**dict(run.metadata_json or {}), "error": error_message}
            if case is not None:
                session.add(
                    AuditEvent(
                        event_type="interactive.case_failed",
                        entity_type="case",
                        entity_id=case.id,
                        payload_json={"pendingItemId": item_id, "error": error_message},
                    )
                )
            await session.commit()

    async def _route_item(self, item: AgentPendingItemRecord, *, case_id: str) -> None:
        if self.request_router is None:
            raise RuntimeError("request router is not configured")
        routed_item = item.model_copy(update={"payload": {**dict(item.payload or {}), "localCaseId": case_id}})
        await self.request_router.route(routed_item)

    async def _finalize_cli_case(self, *, case_id: str, session_id: str, item_id: str) -> None:
        async with self.session_factory() as session:
            case = await session.get(Case, case_id)
            agent_session = await session.get(AgentSession, session_id)
            if case is None or agent_session is None:
                return
            draft = (
                await session.get(AgentWriteDraft, agent_session.current_write_draft_id)
                if agent_session.current_write_draft_id
                else None
            )
            if draft is not None and draft.status == AgentWriteDraftStatus.awaiting_approval:
                case.status = CaseStatus.awaiting_send_approval
                agent_session.status = AgentSessionStatus.awaiting_approval
            elif case.source is CaseSource.project_workflow:
                case.status = CaseStatus.completed
                agent_session.status = AgentSessionStatus.completed
            else:
                case.status = CaseStatus.completed
                agent_session.status = AgentSessionStatus.waiting_user_reply
            case.updated_at = _utcnow()
            agent_session.updated_at = _utcnow()
            await _complete_pending_item(session, item_id)
            session.add(
                AuditEvent(
                    event_type="interactive.case_completed",
                    entity_type="case",
                    entity_id=case.id,
                    payload_json={
                        "pendingItemId": item_id,
                        "sessionId": session_id,
                        "caseStatus": case.status.value,
                    },
                )
            )
            await session.commit()

    async def _finalize_execution_decision(
        self,
        *,
        case_id: str,
        session_id: str,
        item_id: str,
        draft_id: str | None,
        decision_type: AgentExecutionDecisionType,
    ) -> None:
        async with self.session_factory() as session:
            case = await session.get(Case, case_id)
            agent_session = await session.get(AgentSession, session_id)
            draft = await session.get(AgentWriteDraft, draft_id) if draft_id else None
            if case is None or agent_session is None:
                return
            if decision_type is AgentExecutionDecisionType.reject:
                case.status = CaseStatus.rejected
                agent_session.status = AgentSessionStatus.waiting_user_reply
            elif draft is not None and draft.status == AgentWriteDraftStatus.executed:
                case.status = CaseStatus.completed
                agent_session.status = AgentSessionStatus.waiting_user_reply
            else:
                case.status = CaseStatus.failed
                agent_session.status = AgentSessionStatus.failed
            case.updated_at = _utcnow()
            agent_session.updated_at = _utcnow()
            await _complete_pending_item(session, item_id)
            session.add(
                AuditEvent(
                    event_type="interactive.execution_decision_completed",
                    entity_type="case",
                    entity_id=case.id,
                    payload_json={
                        "pendingItemId": item_id,
                        "sessionId": session_id,
                        "decisionType": decision_type.value,
                        "writeDraftId": draft_id,
                        "caseStatus": case.status.value,
                    },
                )
            )
            await session.commit()

    async def _finalize_followup_decision(self, *, case_id: str, session_id: str, item_id: str) -> None:
        async with self.session_factory() as session:
            case = await session.get(Case, case_id)
            agent_session = await session.get(AgentSession, session_id)
            if case is None or agent_session is None:
                return
            case.status = CaseStatus.waiting_user_reply
            case.updated_at = _utcnow()
            agent_session.status = AgentSessionStatus.waiting_user_reply
            agent_session.updated_at = _utcnow()
            await _complete_pending_item(session, item_id)
            await session.commit()

    async def _ignore_reply(self, item: AgentPendingItemRecord, *, reason: str) -> dict[str, object]:
        async with self.session_factory() as session:
            await _complete_pending_item(session, item.id)
            await session.commit()
        return {
            "sessionId": item.session_id,
            "action": "reply_ignored",
            "reason": reason,
        }

    async def _mark_local_item_failed(self, item_id: str, *, error_message: str) -> None:
        async with self.session_factory() as session:
            row = await session.get(AgentPendingItem, item_id)
            if row is None:
                return
            row.status = AgentPendingItemStatus.failed
            row.error_message = error_message
            row.updated_at = _utcnow()
            await session.commit()


async def _complete_pending_item(session: AsyncSession, item_id: str) -> None:
    pending = await session.get(AgentPendingItem, item_id)
    if pending is None:
        return
    pending.status = AgentPendingItemStatus.completed
    pending.completed_at = _utcnow()
    pending.updated_at = _utcnow()


async def _resolve_local_case_id_for_pending_item(session: AsyncSession, pending_item: AgentPendingItem | None) -> str | None:
    if pending_item is None or pending_item.session_id is None:
        return None
    agent_session = await session.get(AgentSession, pending_item.session_id)
    if agent_session is None:
        return None
    return agent_session.local_case_id
