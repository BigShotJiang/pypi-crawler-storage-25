from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.enums import ConnectorType
from workagent.db.models import AppSetting


@dataclass(frozen=True, slots=True)
class SyncMetadataStatus:
    connector: ConnectorType
    last_success_at: datetime | None
    failure_count: int
    attempt_count: int
    failure_total: int
    next_allowed_at: datetime | None
    last_error: str | None


class SyncMetadataService:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession], *, base_backoff_seconds: int = 30) -> None:
        self.session_factory = session_factory
        self.base_backoff_seconds = base_backoff_seconds

    async def get_status(self, connector: ConnectorType) -> SyncMetadataStatus:
        async with self.session_factory() as session:
            row = await session.get(AppSetting, self._key(connector))
            payload = row.value_json if row is not None else {}
        return SyncMetadataStatus(
            connector=connector,
            last_success_at=self._parse_datetime(payload.get("last_success_at")),
            failure_count=int(payload.get("failure_count") or 0),
            attempt_count=int(payload.get("attempt_count") or 0),
            failure_total=int(payload.get("failure_total") or 0),
            next_allowed_at=self._parse_datetime(payload.get("next_allowed_at")),
            last_error=str(payload.get("last_error") or "").strip() or None,
        )

    async def is_sync_allowed(self, connector: ConnectorType, *, now: datetime | None = None) -> bool:
        status = await self.get_status(connector)
        reference = now or datetime.now(UTC)
        if status.next_allowed_at is None:
            return True
        return reference >= status.next_allowed_at

    async def record_success(
        self,
        connector: ConnectorType,
        *,
        at: datetime | None = None,
    ) -> SyncMetadataStatus:
        timestamp = self._normalize_datetime(at)
        current = await self.get_status(connector)
        await self._save(
            connector,
            {
                "last_success_at": timestamp.isoformat(),
                "failure_count": 0,
                "attempt_count": current.attempt_count + 1,
                "failure_total": current.failure_total,
                "next_allowed_at": None,
                "last_error": None,
            },
        )
        return await self.get_status(connector)

    async def record_failure(
        self,
        connector: ConnectorType,
        *,
        error: str,
        at: datetime | None = None,
    ) -> SyncMetadataStatus:
        timestamp = self._normalize_datetime(at)
        current = await self.get_status(connector)
        failure_count = current.failure_count + 1
        next_allowed_at = timestamp + timedelta(seconds=self.base_backoff_seconds * failure_count)
        await self._save(
            connector,
            {
                "last_success_at": current.last_success_at.isoformat() if current.last_success_at else None,
                "failure_count": failure_count,
                "attempt_count": current.attempt_count + 1,
                "failure_total": current.failure_total + 1,
                "next_allowed_at": next_allowed_at.isoformat(),
                "last_error": error,
            },
        )
        return await self.get_status(connector)

    async def _save(self, connector: ConnectorType, payload: dict) -> None:
        async with self.session_factory() as session:
            row = await session.get(AppSetting, self._key(connector))
            if row is None:
                row = AppSetting(key=self._key(connector), value_json=payload)
                session.add(row)
            else:
                row.value_json = payload
            await session.commit()

    @staticmethod
    def _key(connector: ConnectorType) -> str:
        return f"sync_metadata:{connector.value}"

    @staticmethod
    def _parse_datetime(raw_value) -> datetime | None:  # noqa: ANN001
        if not raw_value:
            return None
        parsed = datetime.fromisoformat(str(raw_value))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=UTC)
        return parsed

    @staticmethod
    def _normalize_datetime(value: datetime | None) -> datetime:
        if value is None:
            return datetime.now(UTC)
        if value.tzinfo is None:
            return value.replace(tzinfo=UTC)
        return value.astimezone(UTC)
