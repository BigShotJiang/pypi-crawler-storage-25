from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any

from workagent.db.models import AppSetting

AGENT_MODEL_CATALOG_CACHE_KEY = "agent_model_catalog_snapshot"


def _utcnow() -> datetime:
    return datetime.now(UTC)


def normalize_model_mode(raw_value: object, *, has_explicit_model: bool = False) -> str:
    normalized = str(raw_value or "").strip().lower()
    if normalized in {"auto", "manual"}:
        return normalized
    return "manual" if has_explicit_model else "auto"


async def load_cached_agent_model_catalog(session) -> dict[str, Any] | None:  # noqa: ANN001
    row = await session.get(AppSetting, AGENT_MODEL_CATALOG_CACHE_KEY)
    if row is None or not isinstance(row.value_json, dict):
        return None
    return dict(row.value_json)


async def store_cached_agent_model_catalog(session_factory, payload: Mapping[str, Any]) -> dict[str, Any]:  # noqa: ANN001
    async with session_factory() as session:
        row = await session.get(AppSetting, AGENT_MODEL_CATALOG_CACHE_KEY)
        serialized = dict(payload)
        if row is None:
            row = AppSetting(key=AGENT_MODEL_CATALOG_CACHE_KEY, value_json=serialized)
            session.add(row)
        else:
            row.value_json = serialized
        await session.commit()
        return serialized


async def refresh_cached_agent_model_catalog(session_factory, sync_api) -> dict[str, Any] | None:  # noqa: ANN001
    fetch_catalog = getattr(sync_api, "fetch_agent_model_catalog", None)
    if not callable(fetch_catalog):
        return None
    payload = await fetch_catalog()
    if not isinstance(payload, dict):
        return None
    return await store_cached_agent_model_catalog(session_factory, payload)


def _catalog_engine(catalog: Mapping[str, Any] | None, engine_name: str) -> Mapping[str, Any] | None:
    if not isinstance(catalog, Mapping):
        return None
    for raw_engine in list(catalog.get("engines") or []):
        if not isinstance(raw_engine, Mapping):
            continue
        if str(raw_engine.get("engineType") or "").strip() == engine_name:
            return raw_engine
    return None


def _ordered_profile_models(engine_entry: Mapping[str, Any] | None, profile_name: str) -> list[str]:
    if not isinstance(engine_entry, Mapping):
        return []
    profiles = engine_entry.get("profiles")
    if not isinstance(profiles, Mapping):
        return []
    return [
        str(model_id).strip()
        for model_id in list(profiles.get(profile_name) or [])
        if str(model_id).strip()
    ]


def model_supports_reasoning_effort(
    catalog: Mapping[str, Any] | None,
    *,
    engine_name: str,
    model_id: str | None,
) -> bool:
    normalized_model_id = str(model_id or "").strip()
    if not normalized_model_id:
        return False
    engine_entry = _catalog_engine(catalog, engine_name)
    if not isinstance(engine_entry, Mapping):
        return True
    for raw_model in list(engine_entry.get("models") or []):
        if not isinstance(raw_model, Mapping):
            continue
        if str(raw_model.get("modelId") or "").strip() != normalized_model_id:
            continue
        return bool(raw_model.get("supportsReasoningEffort"))
    return True


def select_planner_model_from_catalog(
    catalog: Mapping[str, Any] | None,
    *,
    engine_name: str,
    fallback_model: str | None,
) -> tuple[str | None, str]:
    engine_entry = _catalog_engine(catalog, engine_name)
    planner_models = _ordered_profile_models(engine_entry, "planner")
    if planner_models:
        return planner_models[0], "catalog"
    return fallback_model, "config_fallback"


def resolve_execution_profile(*, task_category: str, request_text: str) -> str:
    normalized_category = str(task_category or "general").strip()
    if normalized_category in {"code_write", "code_read"}:
        return "coding"
    if normalized_category in {"web_search", "platform_lookup", "shell_op"}:
        return "reasoning"
    if len(request_text.strip()) <= 400:
        return "fast"
    return "reasoning"


def select_execution_model_from_catalog(
    catalog: Mapping[str, Any] | None,
    *,
    engine_name: str,
    task_category: str,
    request_text: str,
    fallback_model: str | None,
) -> tuple[str, str | None, str]:
    profile = resolve_execution_profile(task_category=task_category, request_text=request_text)
    engine_entry = _catalog_engine(catalog, engine_name)
    profile_models = _ordered_profile_models(engine_entry, profile)
    if profile_models:
        return profile, profile_models[0], "catalog"
    return profile, fallback_model, "config_fallback"


def reasoning_effort_for_profile(profile: str, *, supports_reasoning: bool = True) -> str | None:
    if not supports_reasoning:
        return None
    if profile == "fast":
        return "low"
    if profile == "coding":
        return "high"
    return "medium"


def catalog_version(catalog: Mapping[str, Any] | None) -> str | None:
    if not isinstance(catalog, Mapping):
        return None
    value = str(catalog.get("catalogVersion") or "").strip()
    return value or None
