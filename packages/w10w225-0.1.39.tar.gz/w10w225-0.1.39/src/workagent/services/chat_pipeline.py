from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from workagent.sync.models import AgentPendingItemRecord

if TYPE_CHECKING:
    from workagent.services.file_memory import FileMemoryStore
    from workagent.services.local_agent_store import LocalAgentStore

logger = logging.getLogger(__name__)


class ChatPipeline:
    def __init__(self, *, executor, transport, action_parser, action_executor, agent_store: LocalAgentStore | None = None, memory_store: FileMemoryStore | None = None) -> None:  # noqa: ANN001
        self.executor = executor
        self.transport = transport
        self.action_parser = action_parser
        self.action_executor = action_executor
        self.agent_store = agent_store
        self.memory_store = memory_store

    async def handle_new_request(self, pending_item: AgentPendingItemRecord) -> None:
        request_text = str(pending_item.payload.get("requestText") or "").strip()
        await self._run_and_publish(pending_item, request_text=request_text)

    async def handle_reply(self, pending_item: AgentPendingItemRecord) -> None:
        reply_text = str(pending_item.payload.get("replyText") or "").strip()
        await self._run_and_publish(pending_item, request_text=reply_text)

    async def handle_decision(self, pending_item: AgentPendingItemRecord) -> None:
        payload = pending_item.payload
        draft_id = str(payload.get("writeDraftId") or "").strip()
        decision_type = str(payload.get("decisionType") or "").strip().lower()

        if decision_type == "reject":
            if draft_id:
                await self.transport.update_write_draft_status(draft_id=draft_id, status="rejected")
            return
        if decision_type == "request_followup":
            return

        action_payload = self._resolve_action_payload_safe(payload, draft_id=draft_id, decision_type=decision_type)
        if action_payload is None:
            if draft_id:
                await self.transport.update_write_draft_status(draft_id=draft_id, status="failed")
            return
        execution_result = await self.action_executor.execute(action_payload)
        if draft_id:
            await self.transport.update_write_draft_status(
                draft_id=draft_id,
                status="executed" if execution_result.success else "failed",
                execution_result=execution_result.to_dict(),
            )

    async def _run_and_publish(self, pending_item: AgentPendingItemRecord, *, request_text: str) -> None:
        payload = pending_item.payload
        session_id = pending_item.session_id or pending_item.id
        room_id = payload.get("roomId") or payload.get("room_id")
        agent_id = payload.get("agent_id") or payload.get("agentId")

        logger.info(
            "pipeline start session_id=%s room_id=%s agent_id=%s request=%s",
            session_id, room_id, agent_id, request_text[:100],
        )

        agent_prompt = None
        skill_contents: list[str] = []
        if agent_id and self.agent_store:
            agent_prompt = self.agent_store.load_agent_prompt(str(agent_id))
            skill_contents = self.agent_store.load_skills(str(agent_id))

        logger.info("pipeline agent skills=%d", len(skill_contents))

        # Read long-term memory for context
        memory_context = ""
        if self.memory_store:
            memory_context = self.memory_store.read_recent(max_chars=20_000)

        prompt = self.build_chat_prompt(
            conversation_turns=list(payload.get("conversationTurns") or []),
            request_text=request_text,
            agent_prompt=agent_prompt,
            skill_contents=skill_contents,
            memory_context=memory_context,
            invocation_context={
                "roomId": payload.get("roomId") or "",
                "threadId": payload.get("threadId") or "",
                "sessionId": str(session_id),
                "messageId": payload.get("messageId") or "",
                "requestingUserId": payload.get("requestingUserId") or "",
                "userTimezone": payload.get("userTimezone") or "",
            },
        )

        logger.info("pipeline executing LLM engine=%s prompt_length=%d", type(self.executor).__name__, len(prompt))

        # Send initial processing status + periodic heartbeat while LLM runs
        result = await self._run_with_heartbeat(session_id, prompt)
        logger.info("pipeline LLM response received length=%d", len(result.text))

        action, clean_text = self.action_parser.parse(result.text)

        # Write to long-term memory
        if self.memory_store and request_text and result.text:
            self.memory_store.append(
                summary=f"Q: {request_text[:200]}\nA: {result.text[:500]}",
                source="chat",
                session_id=str(session_id),
                agent_id=str(agent_id) if agent_id else None,
            )

        # Collect status message IDs to dismiss in frontend
        dismiss_ids = getattr(self, "_last_status_message_ids", [])

        if action is None:
            logger.info("pipeline result type=text_response session_id=%s", session_id)
            await self.transport.post_session_message(
                session_id=session_id,
                message_type="result",
                text=result.text,
                metadata={"dismissStatusMessageIds": dismiss_ids} if dismiss_ids else {},
            )
            return

        logger.info("pipeline result type=action_proposal kind=%s session_id=%s", action.kind, session_id)

        # Scheduled jobs auto-execute without approval — user already consented when registering the task
        if payload.get("_scheduled_job"):
            logger.info("pipeline scheduled_job auto-execute kind=%s session_id=%s", action.kind, session_id)
            action_payload = {
                "kind": action.kind,
                "targetRef": action.target_ref,
                "payload": action.payload,
                "content": action.content,
            }
            execution_result = await self.action_executor.execute(action_payload)
            await self.transport.post_session_message(
                session_id=session_id,
                message_type="result",
                text=clean_text,
                metadata={
                    "autoExecuted": True,
                    "executionResult": execution_result.to_dict(),
                    "dismissStatusMessageIds": dismiss_ids,
                } if dismiss_ids else {
                    "autoExecuted": True,
                    "executionResult": execution_result.to_dict(),
                },
            )
            return

        draft_id = await self.transport.create_write_draft(
            session_id=session_id,
            draft_kind=action.kind,
            target_ref=action.target_ref,
            draft_text=action.content,
            draft_payload=action.payload,
        )
        logger.info("pipeline write_draft created draft_id=%s kind=%s", draft_id, action.kind)
        await self.transport.post_session_message(
            session_id=session_id,
            message_type="draft_proposal",
            text=clean_text,
            metadata={"writeDraftId": draft_id, "dismissStatusMessageIds": dismiss_ids} if dismiss_ids else {"writeDraftId": draft_id},
        )

    _HEARTBEAT_INTERVAL = 30  # seconds between status updates
    _HEARTBEAT_MESSAGES = [
        "Processing your request...",
        "Still working on it...",
        "Almost there, still processing...",
        "This is taking a moment, hang tight...",
        "Still working — analyzing content...",
    ]

    async def _run_with_heartbeat(self, session_id: str, prompt: str) -> Any:
        """Run the LLM executor with periodic heartbeat messages to the user.

        Status message IDs are collected so they can be referenced
        (``dismissStatusMessageIds``) in the final response metadata,
        allowing the frontend to hide them immediately.
        """
        import asyncio

        status_message_ids: list[str] = []

        # Send initial processing message
        try:
            mid = await self.transport.post_session_message(
                session_id=session_id,
                message_type="status",
                text=self._HEARTBEAT_MESSAGES[0],
                metadata={"agentStatus": "processing"},
            )
            if mid:
                status_message_ids.append(mid)
        except Exception:  # noqa: BLE001
            logger.debug("pipeline heartbeat initial message failed", exc_info=True)

        # Run LLM with concurrent heartbeat
        heartbeat_count = 0
        stop_heartbeat = asyncio.Event()

        async def _heartbeat_loop() -> None:
            nonlocal heartbeat_count
            while not stop_heartbeat.is_set():
                try:
                    await asyncio.wait_for(stop_heartbeat.wait(), timeout=self._HEARTBEAT_INTERVAL)
                    return
                except asyncio.TimeoutError:
                    pass
                heartbeat_count += 1
                msg = self._HEARTBEAT_MESSAGES[min(heartbeat_count, len(self._HEARTBEAT_MESSAGES) - 1)]
                try:
                    mid = await self.transport.post_session_message(
                        session_id=session_id,
                        message_type="status",
                        text=msg,
                        metadata={"agentStatus": "processing", "elapsed": heartbeat_count * self._HEARTBEAT_INTERVAL},
                    )
                    if mid:
                        status_message_ids.append(mid)
                except Exception:  # noqa: BLE001
                    logger.debug("pipeline heartbeat update failed", exc_info=True)

        heartbeat_task = asyncio.create_task(_heartbeat_loop())
        try:
            result = await self.executor.run(prompt)
        finally:
            stop_heartbeat.set()
            await heartbeat_task

        # Store collected IDs so _run_and_publish can include them in response metadata
        self._last_status_message_ids = status_message_ids
        return result

    @staticmethod
    def build_chat_prompt(
        *,
        conversation_turns: list[dict[str, Any]],
        request_text: str,
        agent_prompt: str | None = None,
        skill_contents: list[str] | None = None,
        memory_context: str | None = None,
        invocation_context: dict[str, str] | None = None,
    ) -> str:
        from pathlib import Path

        preamble: list[str] = []

        # System instruction: home directory structure and available resources
        pwa_home = Path.home() / ".personal-work-agent"
        skills_base = pwa_home / "skills"
        agents_dir = pwa_home / "agents"

        # Discover available skills (both external and internal)
        available_external_skills: list[str] = []
        available_internal_skills: list[str] = []
        for category, target_list in [("external", available_external_skills), ("internal", available_internal_skills)]:
            category_dir = skills_base / category
            if category_dir.exists():
                target_list.extend(sorted(
                    d.name for d in category_dir.iterdir()
                    if d.is_dir() and (d / "SKILL.md").exists()
                ))
        available_skills = available_external_skills + available_internal_skills

        # Discover available project agents
        available_agents: list[str] = []
        if agents_dir.exists():
            available_agents = sorted(
                d.name for d in agents_dir.iterdir()
                if d.is_dir() and (d / "agent.md").exists()
            )

        from datetime import datetime, timezone as tz_class, timedelta
        import zoneinfo

        ctx_pre = invocation_context or {}
        user_tz_name = ctx_pre.get("userTimezone") or "UTC"
        try:
            user_tz = zoneinfo.ZoneInfo(user_tz_name)
        except (KeyError, Exception):
            user_tz = tz_class.utc
            user_tz_name = "UTC"
        now_local = datetime.now(user_tz)
        current_date_str = now_local.strftime("%Y-%m-%d")
        current_time_str = now_local.strftime("%H:%M")
        current_weekday = ["월", "화", "수", "목", "금", "토", "일"][now_local.weekday()]

        system_instructions = [
            "You are a personal work agent running locally via the w10w225 CLI tool.",
            "",
            f"Current date and time ({user_tz_name}): {current_date_str} ({current_weekday}) {current_time_str}",
            f"User timezone: {user_tz_name}",
            f"Use this as the reference for '오늘', 'today', '내일', 'tomorrow', '어제', 'yesterday', etc.",
            "",
            f"Home directory: {pwa_home}",
            "Directory structure:",
            f"  {pwa_home}/skills/external/{{platform}}/SKILL.md  — External system integration skills",
            f"  {pwa_home}/skills/internal/{{skill_name}}/SKILL.md — Internal platform skills (e.g. nk304-calendar)",
            f"  {pwa_home}/agents/{{agent_id}}/agent.md            — Project sub-agent definitions",
            f"  {pwa_home}/agents/{{agent_id}}/skills/{{skill}}.md — Project agent skills",
            f"  {pwa_home}/memory/MEMORY.md                        — Long-term conversation memory",
            f"  {pwa_home}/data/app.db                             — Local database (credentials, queue)",
        ]

        if available_internal_skills:
            system_instructions.append(f"\nInternal platform skills: {', '.join(available_internal_skills)}")
            system_instructions.append(
                "Internal skills (nk304-*) provide direct access to the platform's own features. "
                f"SKILL.md files at {skills_base}/internal/{{skill_name}}/SKILL.md — use the exact skill name from the list above as {{skill_name}} (e.g. nk304-calendar, NOT calendar). "
                "Read them silently when needed — never mention reading skill files to the user."
            )

        if available_external_skills:
            system_instructions.append(f"\nConnected external systems: {', '.join(available_external_skills)}")
            system_instructions.append(
                f"SKILL.md files at {skills_base}/external/{{platform}}/SKILL.md contain available w10w225 CLI commands. "
                "Read them silently when needed — never mention reading skill files to the user."
            )

        if available_agents:
            system_instructions.append(f"\nAvailable project agents: {', '.join(available_agents)}")
            system_instructions.append(
                "Each agent has agent.md (role/prompt) and skills/ directory. "
                f"Read {agents_dir}/{{agent_id}}/agent.md for the agent's instructions."
            )

        system_instructions.append(
            "\nYou can execute w10w225 CLI commands via bash to interact with external systems. "
            "Read the relevant SKILL.md to understand available commands, but do this silently — "
            "NEVER tell the user you are reading skill files, documentation, or internal references. "
            "Just perform the action and present the result directly."
            "\n\nIMPORTANT — Response formatting rule:"
            "\nNever narrate your internal reasoning or tool-checking process in the response. "
            "Do not say things like '스킬을 확인하겠습니다', '형식을 확인하겠습니다', "
            "'경로를 확인해서', 'let me check', 'verifying the format'. "
            "Only present the final result or action proposal to the user."
        )

        # Invocation context — tells the LLM where this request came from
        ctx = invocation_context or {}
        room_id = ctx.get("roomId", "")
        if room_id:
            system_instructions.append(
                f"\n## Current Invocation Context"
                f"\nThis request was sent from nk304 chat room: {room_id}"
                f"\nWhen the user says 'this channel/room', they mean room ID: {room_id}"
                f"\nUse `w10w225 nk304 chat messages --room-id {room_id}` to read recent messages."
                f"\nUse `w10w225 nk304 chat search --room-id {room_id} --query \"...\"` to search messages."
                f"\nFor date-specific queries, use search with --after/--before: "
                f"`w10w225 nk304 chat search --room-id {room_id} --query \"\" --after \"YYYY-MM-DD\" --before \"YYYY-MM-DD\"`"
                f"\nAll nk304 commands are available under `w10w225 nk304 <domain> <command>`."
            )
        thread_id = ctx.get("threadId", "")
        if thread_id:
            system_instructions.append(f"Thread ID: {thread_id}")

        # Action proposal rules for external write operations
        system_instructions.append(
            "\n## External Action Rules (CRITICAL)"
            "\nWhen you need to SEND, WRITE, CREATE, UPDATE, or DELETE anything on an external system "
            "(e.g. send a Slack message, create a Jira issue, post a comment), you MUST NOT execute it directly."
            "\nInstead, output your proposal in the following format so the user can approve or reject it:"
            "\n"
            "\n---ACTION_PROPOSAL---"
            "\nkind: slack_send_message"
            "\ntarget: {\"channelId\": \"C123\", \"channelName\": \"#general\"}"
            "\ncontent: |"
            "\n  The actual message text to send"
            "\nreason: Why this action is needed"
            "\n---END_ACTION_PROPOSAL---"
            "\n"
            "\nSupported action kinds: slack_send_message, slack_thread_reply, "
            "jira_comment_create, gitlab_note_create, confluence_comment_create, "
            "nk304_chat_message, nk304_chat_edit, nk304_chat_delete, nk304_chat_reply, "
            "nk304_wiki_set, nk304_wiki_create, nk304_wiki_edit, nk304_wiki_delete, "
            "nk304_notice_create, nk304_notice_update, nk304_notice_delete, "
            "nk304_memo_create, nk304_memo_update, nk304_memo_delete, "
            "nk304_ticket_create, nk304_ticket_comment, nk304_ticket_update, "
            "nk304_calendar_create, nk304_calendar_update, nk304_calendar_delete, "
            "generic_external_action"
            "\n"
            "\nIMPORTANT:"
            "\n- READ operations (list, get, search, read) can be executed directly without proposal."
            "\n- WRITE operations (send, create, update, delete, reply, comment) MUST use ACTION_PROPOSAL."
            "\n- Never ask the user 'should I send this?' in text. Always use the ACTION_PROPOSAL format."
            "\n- The user will see an approve/reject button in their chat interface."
        )
        preamble.append("System:\n" + "\n".join(system_instructions))

        if agent_prompt:
            preamble.append(f"Agent Prompt:\n{agent_prompt.strip()}")
        if skill_contents:
            for i, skill in enumerate(skill_contents, 1):
                preamble.append(f"Skill {i}:\n{skill.strip()}")
        if memory_context and memory_context.strip():
            preamble.append(f"Previous Interactions (Long-term Memory):\n{memory_context.strip()}")

        turn_lines = [
            f"{str(turn.get('role') or '').strip()}: {str(turn.get('text') or '').strip()}"
            for turn in conversation_turns
            if isinstance(turn, dict) and str(turn.get("role") or "").strip() and str(turn.get("text") or "").strip()
        ]
        sections = [*preamble, "Conversation:", *turn_lines, "", "Latest request:", request_text.strip()]
        return "\n".join(section for section in sections if section is not None).strip()

    def _resolve_action_payload_safe(self, payload: dict[str, object], *, draft_id: str, decision_type: str = "") -> dict[str, object] | None:
        """Resolve action payload from decision payload, falling back to local DB draft."""
        # Try from decision payload first — prefer edited payload for edit-and-send/execute decisions
        if decision_type in ("edit_and_send", "edit_and_execute"):
            key_order = ("editedPayload", "editedPayloadJson", "originalPayload", "originalPayloadJson")
        else:
            key_order = ("originalPayload", "originalPayloadJson", "editedPayload", "editedPayloadJson")
        for key in key_order:
            value = payload.get(key)
            if isinstance(value, dict):
                return dict(value)

        # Fall back: load draft_payload from local DB
        if draft_id:
            try:
                from pathlib import Path

                from sqlalchemy import create_engine, text

                db_path = Path.home() / ".personal-work-agent" / "data" / "app.db"
                if db_path.exists():
                    engine = create_engine(f"sqlite:///{db_path}")
                    with engine.connect() as conn:
                        row = conn.execute(
                            text("SELECT draft_payload_json, draft_kind, target_ref_json, draft_text FROM agent_write_drafts WHERE id = :id"),
                            {"id": draft_id},
                        ).fetchone()
                        if row:
                            draft_payload = row[0]
                            if isinstance(draft_payload, str):
                                import json
                                draft_payload = json.loads(draft_payload)
                            import json
                            target_ref = json.loads(row[2]) if isinstance(row[2], str) else (row[2] or {})
                            return self._rehydrate_draft_payload(
                                decision_payload=payload,
                                draft_payload=draft_payload if isinstance(draft_payload, dict) else {},
                                draft_kind=str(row[1] or ""),
                                target_ref=target_ref if isinstance(target_ref, dict) else {},
                                draft_text=str(row[3] or ""),
                            )
                    engine.dispose()
            except Exception:
                pass

        return None

    @staticmethod
    def _rehydrate_draft_payload(
        *,
        decision_payload: dict[str, object],
        draft_payload: dict[str, object],
        draft_kind: str,
        target_ref: dict[str, object],
        draft_text: str,
    ) -> dict[str, object]:
        rehydrated = dict(draft_payload or {})
        normalized_kind = str(draft_kind or "").strip()
        if normalized_kind and not str(rehydrated.get("kind") or "").strip():
            rehydrated["kind"] = normalized_kind
        for key, value in dict(target_ref or {}).items():
            rehydrated.setdefault(key, value)
        timezone_name = str(
            rehydrated.get("timezone")
            or decision_payload.get("userTimezone")
            or "UTC"
        ).strip() or "UTC"
        if "timezone" not in rehydrated and timezone_name:
            rehydrated["timezone"] = timezone_name
        if normalized_kind.startswith("nk304_calendar_") and draft_text and "text" not in rehydrated:
            rehydrated["text"] = draft_text
        return rehydrated
