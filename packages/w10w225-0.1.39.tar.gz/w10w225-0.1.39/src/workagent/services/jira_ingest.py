from __future__ import annotations

from typing import Protocol

from workagent.connectors.jira_sync import JiraSyncEvent
from workagent.db.enums import CaseSource, ConnectorType


class SeenStore(Protocol):
    async def has_seen(self, event_id: str) -> bool: ...

    async def mark_seen(self, event_id: str) -> None: ...


class CaseServiceLike(Protocol):
    async def create_case(self, *, source, connector_type, title, payload): ...  # noqa: ANN001


class JiraIngestService:
    def __init__(
        self,
        *,
        case_service: CaseServiceLike,
        seen_store: SeenStore,
        jira_base_url: str | None = None,
    ) -> None:
        self.case_service = case_service
        self.seen_store = seen_store
        self.jira_base_url = jira_base_url.rstrip("/") if jira_base_url else None

    async def ingest(self, events: list[JiraSyncEvent]) -> list[str]:
        created_case_ids: list[str] = []
        for event in events:
            if await self.seen_store.has_seen(event.id):
                continue
            source_url = self._build_source_url(event)
            result = await self.case_service.create_case(
                source=CaseSource.jira_sync,
                connector_type=ConnectorType.jira,
                title=self._build_title(event),
                payload={
                    "eventId": event.id,
                    "issueKey": event.issue_key,
                    "projectKey": event.project_key,
                    "summary": event.summary,
                    "updatedAt": event.updated_at,
                    "payload": event.payload,
                    **({"sourceUrl": source_url} if source_url else {}),
                },
            )
            case_id = self._extract_case_id(result)
            await self._record_artifacts(case_id, event, source_url)
            await self.seen_store.mark_seen(event.id)
            created_case_ids.append(case_id)
        return created_case_ids

    @staticmethod
    def _build_title(event: JiraSyncEvent) -> str:
        return f"Jira {event.issue_key}: {event.summary}".strip()

    @staticmethod
    def _extract_case_id(result) -> str:  # noqa: ANN001
        if isinstance(result, dict):
            return str(result.get("id") or "")
        if hasattr(result, "id"):
            return str(result.id)
        return str(result)

    def _build_source_url(self, event: JiraSyncEvent) -> str | None:
        if not self.jira_base_url or not event.issue_key:
            return None
        return f"{self.jira_base_url}/browse/{event.issue_key}"

    async def _record_artifacts(self, case_id: str, event: JiraSyncEvent, source_url: str | None) -> None:
        add_artifact = getattr(self.case_service, "add_artifact", None)
        if not callable(add_artifact) or not source_url:
            return
        await add_artifact(  # type: ignore[misc]
            case_id,
            artifact_type="jira_issue_link",
            relative_path=f"jira/{event.issue_key}",
            metadata={
                "label": "Jira issue",
                "sourceUrl": source_url,
            },
        )
