from __future__ import annotations

from typing import Protocol

from workagent.connectors.zendesk_sync import ZendeskSyncEvent
from workagent.db.enums import CaseSource, ConnectorType


class SeenStore(Protocol):
    async def has_seen(self, event_id: str) -> bool: ...

    async def mark_seen(self, event_id: str) -> None: ...


class CaseServiceLike(Protocol):
    async def create_case(self, *, source, connector_type, title, payload): ...  # noqa: ANN001


class ZendeskIngestService:
    def __init__(
        self,
        *,
        case_service: CaseServiceLike,
        seen_store: SeenStore,
    ) -> None:
        self.case_service = case_service
        self.seen_store = seen_store

    async def ingest(self, events: list[ZendeskSyncEvent]) -> list[str]:
        created_case_ids: list[str] = []
        for event in events:
            if await self.seen_store.has_seen(event.id):
                continue
            result = await self.case_service.create_case(
                source=CaseSource.zendesk_sync,
                connector_type=ConnectorType.zendesk,
                title=self._build_title(event),
                payload={
                    "eventId": event.id,
                    "ticketId": event.ticket_id,
                    "viewId": event.view_id,
                    "subject": event.subject,
                    "updatedAt": event.updated_at,
                    "payload": event.payload,
                    **({"sourceUrl": event.url} if event.url else {}),
                },
            )
            case_id = self._extract_case_id(result)
            await self._record_artifacts(case_id, event)
            await self.seen_store.mark_seen(event.id)
            created_case_ids.append(case_id)
        return created_case_ids

    @staticmethod
    def _build_title(event: ZendeskSyncEvent) -> str:
        return f"Zendesk {event.view_id}: {event.subject}".strip()

    @staticmethod
    def _extract_case_id(result) -> str:  # noqa: ANN001
        if isinstance(result, dict):
            return str(result.get("id") or "")
        if hasattr(result, "id"):
            return str(result.id)
        return str(result)

    async def _record_artifacts(self, case_id: str, event: ZendeskSyncEvent) -> None:
        add_artifact = getattr(self.case_service, "add_artifact", None)
        if not callable(add_artifact) or not event.url:
            return
        await add_artifact(  # type: ignore[misc]
            case_id,
            artifact_type="zendesk_ticket_link",
            relative_path=f"zendesk/{event.view_id}/{event.ticket_id}",
            metadata={
                "label": "Zendesk ticket",
                "sourceUrl": event.url,
            },
        )
