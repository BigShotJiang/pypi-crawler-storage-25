from __future__ import annotations

from typing import Protocol

from workagent.connectors.confluence_sync import ConfluenceSyncEvent
from workagent.db.enums import CaseSource, ConnectorType


class SeenStore(Protocol):
    async def has_seen(self, event_id: str) -> bool: ...

    async def mark_seen(self, event_id: str) -> None: ...


class CaseServiceLike(Protocol):
    async def create_case(self, *, source, connector_type, title, payload): ...  # noqa: ANN001


class ConfluenceIngestService:
    def __init__(
        self,
        *,
        case_service: CaseServiceLike,
        seen_store: SeenStore,
        confluence_base_url: str | None = None,
    ) -> None:
        self.case_service = case_service
        self.seen_store = seen_store
        self.confluence_base_url = confluence_base_url.rstrip("/") if confluence_base_url else None

    async def ingest(self, events: list[ConfluenceSyncEvent]) -> list[str]:
        created_case_ids: list[str] = []
        for event in events:
            if await self.seen_store.has_seen(event.id):
                continue
            source_url = self._build_source_url(event)
            result = await self.case_service.create_case(
                source=CaseSource.confluence_sync,
                connector_type=ConnectorType.confluence,
                title=self._build_title(event),
                payload={
                    "eventId": event.id,
                    "pageId": event.page_id,
                    "title": event.title,
                    "spaceKey": event.space_key,
                    "lastModified": event.last_modified_at,
                    "payload": event.payload,
                    **({"sourceUrl": source_url} if source_url else {}),
                },
            )
            case_id = self._extract_case_id(result)
            await self._record_artifacts(case_id, event, source_url)
            await self.seen_store.mark_seen(event.id)
            created_case_ids.append(case_id)
        return created_case_ids

    @staticmethod
    def _build_title(event: ConfluenceSyncEvent) -> str:
        return f"Confluence {event.space_key}: {event.title}".strip()

    @staticmethod
    def _extract_case_id(result) -> str:  # noqa: ANN001
        if isinstance(result, dict):
            return str(result.get("id") or "")
        if hasattr(result, "id"):
            return str(result.id)
        return str(result)

    def _build_source_url(self, event: ConfluenceSyncEvent) -> str | None:
        if event.webui:
            if event.webui.startswith("http://") or event.webui.startswith("https://"):
                return event.webui
            if self.confluence_base_url:
                return f"{self.confluence_base_url}{event.webui}"
        return None

    async def _record_artifacts(self, case_id: str, event: ConfluenceSyncEvent, source_url: str | None) -> None:
        add_artifact = getattr(self.case_service, "add_artifact", None)
        if not callable(add_artifact) or not source_url:
            return
        await add_artifact(  # type: ignore[misc]
            case_id,
            artifact_type="confluence_page_link",
            relative_path=f"confluence/{event.space_key}/{event.page_id}",
            metadata={
                "label": "Confluence page",
                "sourceUrl": source_url,
            },
        )
