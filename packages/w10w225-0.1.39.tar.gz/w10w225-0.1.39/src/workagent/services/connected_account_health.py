from __future__ import annotations

from dataclasses import dataclass

from workagent.config.models import Platform
from workagent.config.store import ConfigStore
from workagent.connectors.asana_client import AsanaApiClient, AsanaApiError
from workagent.connectors.confluence_client import ConfluenceApiClient, ConfluenceApiError
from workagent.connectors.discord_client import DiscordApiClient, DiscordApiError
from workagent.connectors.gitlab_client import GitLabApiClient, GitLabApiError
from workagent.connectors.gmail_client import GmailApiClient, GmailApiError
from workagent.connectors.google_calendar_client import GoogleCalendarApiClient, GoogleCalendarApiError
from workagent.connectors.google_drive_client import GoogleDriveApiClient, GoogleDriveApiError
from workagent.connectors.jira_client import JiraApiClient, JiraApiError
from workagent.connectors.linear_client import LinearApiClient, LinearApiError
from workagent.connectors.microsoft_teams_client import MicrosoftTeamsApiClient, MicrosoftTeamsApiError
from workagent.connectors.notion_client import NotionApiClient, NotionApiError
from workagent.connectors.slack_client import SlackApiClient, SlackApiError
from workagent.connectors.trello_client import TrelloApiClient, TrelloApiError
from workagent.connectors.zendesk_client import ZendeskApiClient, ZendeskApiError
from workagent.runtime.secrets import SecretStore


@dataclass(frozen=True, slots=True)
class ConnectedAccountHealthCheckOutcome:
    status: str
    reason: str
    provider_account_label: str | None = None


async def perform_connected_account_health_check(
    *,
    config_store: ConfigStore | None,
    secret_store: SecretStore,
    platform_id: str,
    provider_account_id: str,
) -> ConnectedAccountHealthCheckOutcome:
    if config_store is None:
        return ConnectedAccountHealthCheckOutcome(status="refresh_required", reason="connector_not_configured")
    try:
        platform = Platform(platform_id)
    except ValueError:
        return ConnectedAccountHealthCheckOutcome(status="refresh_required", reason="unsupported_platform")

    config = config_store.load()
    connector = config.connectors.get(platform.value) if config is not None else None
    if connector is None:
        return ConnectedAccountHealthCheckOutcome(status="refresh_required", reason="connector_not_configured")

    access_token = str(secret_store.get(f"platform:{platform_id}:{provider_account_id}:access_token") or "").strip()
    if not access_token:
        return ConnectedAccountHealthCheckOutcome(status="refresh_required", reason="token_missing")

    try:
        label = await _check_platform_identity(
            platform=platform,
            base_url=str(connector.api_base_url or connector.base_url),
            expected_label=str(connector.base_url or "").strip() or None,
            access_token=access_token,
        )
    except (
        SlackApiError,
        GitLabApiError,
        JiraApiError,
        ConfluenceApiError,
        NotionApiError,
        LinearApiError,
        GmailApiError,
        GoogleCalendarApiError,
        GoogleDriveApiError,
        AsanaApiError,
        DiscordApiError,
        MicrosoftTeamsApiError,
        TrelloApiError,
        ZendeskApiError,
    ) as exc:
        status_code = getattr(exc, "status_code", None)
        if status_code in {401, 403}:
            return ConnectedAccountHealthCheckOutcome(status="refresh_required", reason="health_check_auth_invalid")
        return ConnectedAccountHealthCheckOutcome(status="refresh_required", reason="health_check_failed")
    except Exception:  # noqa: BLE001
        return ConnectedAccountHealthCheckOutcome(status="refresh_required", reason="health_check_failed")

    return ConnectedAccountHealthCheckOutcome(
        status="active",
        reason="health_check_ok",
        provider_account_label=label,
    )


async def _check_platform_identity(
    *,
    platform: Platform,
    base_url: str,
    expected_label: str | None,
    access_token: str,
) -> str | None:
    if platform is Platform.SLACK:
        payload = SlackApiClient(base_url=base_url).auth_test(token=access_token)
        return str(payload.get("team") or payload.get("user_id") or "").strip() or expected_label
    if platform is Platform.GITLAB:
        payload = await GitLabApiClient(base_url=base_url, private_token=access_token).get_current_user()
        return str(payload.get("username") or payload.get("name") or "").strip() or expected_label
    if platform is Platform.JIRA:
        payload = await JiraApiClient(base_url=base_url, api_token=access_token).get_current_user()
        return str(payload.get("emailAddress") or payload.get("displayName") or "").strip() or expected_label
    if platform is Platform.CONFLUENCE:
        payload = await ConfluenceApiClient(base_url=base_url, api_token=access_token).get_current_user()
        return str(payload.get("email") or payload.get("publicName") or "").strip() or expected_label
    if platform is Platform.NOTION:
        payload = await NotionApiClient(base_url=base_url, api_token=access_token).get_current_user()
        return str(payload.get("name") or payload.get("id") or "").strip() or expected_label
    if platform is Platform.LINEAR:
        payload = await LinearApiClient(base_url=base_url, api_token=access_token).get_current_user()
        return str(payload.get("email") or payload.get("name") or "").strip() or expected_label
    if platform is Platform.GMAIL:
        payload = await GmailApiClient(base_url=base_url, api_token=access_token).get_current_user()
        return str(payload.get("emailAddress") or "").strip() or expected_label
    if platform is Platform.GOOGLE_CALENDAR:
        payload = await GoogleCalendarApiClient(base_url=base_url, api_token=access_token).get_current_user()
        return str(payload.get("summary") or payload.get("id") or "").strip() or expected_label
    if platform is Platform.GOOGLE_DRIVE:
        payload = await GoogleDriveApiClient(base_url=base_url, api_token=access_token).get_current_user()
        return str(payload.get("displayName") or payload.get("emailAddress") or "").strip() or expected_label
    if platform is Platform.ASANA:
        payload = await AsanaApiClient(base_url=base_url, api_token=access_token).get_current_user()
        return str(payload.get("email") or payload.get("name") or "").strip() or expected_label
    if platform is Platform.DISCORD:
        payload = await DiscordApiClient(base_url=base_url, api_token=access_token).get_current_user()
        return str(payload.get("username") or payload.get("id") or "").strip() or expected_label
    if platform is Platform.MICROSOFT_TEAMS:
        payload = await MicrosoftTeamsApiClient(base_url=base_url, api_token=access_token).get_current_user()
        return str(payload.get("mail") or payload.get("displayName") or "").strip() or expected_label
    if platform is Platform.TRELLO:
        payload = await TrelloApiClient(base_url=base_url, api_token=access_token).get_current_member()
        return str(payload.get("fullName") or payload.get("username") or "").strip() or expected_label
    if platform is Platform.ZENDESK:
        payload = await ZendeskApiClient(base_url=base_url, api_token=access_token).get_current_user()
        return str(payload.get("email") or payload.get("name") or "").strip() or expected_label
    return expected_label
