from __future__ import annotations

from dataclasses import dataclass

from workagent.connectors.gitlab_sync import GitLabSyncBatch
from workagent.connectors.slack_sync import SlackSyncBatch
from workagent.runtime.queue import LocalRunQueue


@dataclass(frozen=True, slots=True)
class SyncIngestionSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None = None


class SlackSyncIngestionRuntime:
    def __init__(self, *, poller, ingest_service, queue: LocalRunQueue) -> None:  # noqa: ANN001
        self.poller = poller
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> SyncIngestionSummary:
        batch: SlackSyncBatch = await self.poller.poll_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.poller.commit(batch)
        return SyncIngestionSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )


class GitLabSyncIngestionRuntime:
    def __init__(self, *, poller, ingest_service, queue: LocalRunQueue) -> None:  # noqa: ANN001
        self.poller = poller
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> SyncIngestionSummary:
        batch: GitLabSyncBatch = await self.poller.sync_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.poller.commit(batch)
        return SyncIngestionSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )
