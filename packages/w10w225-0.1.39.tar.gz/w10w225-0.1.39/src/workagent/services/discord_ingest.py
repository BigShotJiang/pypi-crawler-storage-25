from __future__ import annotations

from typing import Protocol

from workagent.connectors.discord_sync import DiscordSyncEvent
from workagent.db.enums import CaseSource, ConnectorType


class SeenStore(Protocol):
    async def has_seen(self, event_id: str) -> bool: ...

    async def mark_seen(self, event_id: str) -> None: ...


class CaseServiceLike(Protocol):
    async def create_case(self, *, source, connector_type, title, payload): ...  # noqa: ANN001


class DiscordIngestService:
    def __init__(
        self,
        *,
        case_service: CaseServiceLike,
        seen_store: SeenStore,
    ) -> None:
        self.case_service = case_service
        self.seen_store = seen_store

    async def ingest(self, events: list[DiscordSyncEvent]) -> list[str]:
        created_case_ids: list[str] = []
        for event in events:
            if await self.seen_store.has_seen(event.id):
                continue
            result = await self.case_service.create_case(
                source=CaseSource.discord_sync,
                connector_type=ConnectorType.discord,
                title=self._build_title(event),
                payload={
                    "eventId": event.id,
                    "messageId": event.message_id,
                    "channelId": event.channel_id,
                    "guildId": event.guild_id,
                    "content": event.content,
                    "timestamp": event.timestamp,
                    "payload": event.payload,
                },
            )
            case_id = self._extract_case_id(result)
            await self._record_artifacts(case_id, event)
            await self.seen_store.mark_seen(event.id)
            created_case_ids.append(case_id)
        return created_case_ids

    @staticmethod
    def _build_title(event: DiscordSyncEvent) -> str:
        return f"Discord {event.channel_id}: {event.content}".strip()

    @staticmethod
    def _extract_case_id(result) -> str:  # noqa: ANN001
        if isinstance(result, dict):
            return str(result.get("id") or "")
        if hasattr(result, "id"):
            return str(result.id)
        return str(result)

    async def _record_artifacts(self, case_id: str, event: DiscordSyncEvent) -> None:
        add_artifact = getattr(self.case_service, "add_artifact", None)
        if not callable(add_artifact):
            return
        guild_segment = event.guild_id or "dm"
        await add_artifact(  # type: ignore[misc]
            case_id,
            artifact_type="discord_message_ref",
            relative_path=f"discord/{guild_segment}/{event.channel_id}/{event.message_id}",
            metadata={
                "label": "Discord message",
                "channelId": event.channel_id,
            },
        )
