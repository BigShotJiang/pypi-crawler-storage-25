from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Protocol, runtime_checkable


class CancelSignal(Protocol):
    def is_cancelled(self) -> bool: ...


class ExecutionCancelled(RuntimeError):
    pass


class ExecutionFailureKind(StrEnum):
    retryable = "retryable"
    manual_required = "manual_required"
    fatal = "fatal"


class NormalizedExecutionErrorCode(StrEnum):
    retryable = "retryable"
    manual_required = "manual_required"
    fatal = "fatal"


class ExecutionStreamEventKind(StrEnum):
    output_delta = "output_delta"
    output_complete = "output_complete"
    lifecycle = "lifecycle"
    tool = "tool"


@dataclass(frozen=True, slots=True)
class NormalizedExecutionResult:
    thread_id: str | None
    draft: str
    summary: str | None
    evidence_refs: list[str]
    raw_transcript: str
    clarification_question: str | None = None
    skill_provenance: list[dict[str, Any]] = field(default_factory=list)
    skill_validation_notes: list[str] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class ExecutionRequest:
    system_instructions: tuple[str, ...] = ()
    user_prompt: str = ""
    attachments: tuple[dict[str, Any], ...] = ()
    compiled_skills: tuple[Any, ...] = ()
    available_tools: tuple[dict[str, Any], ...] = ()
    response_contract: str | None = None
    reasoning_effort: str | None = None
    resume_thread_id: str | None = None

    def render_prompt(self) -> str:
        sections: list[str] = []
        if self.system_instructions:
            sections.append("System Instructions:\n" + "\n".join(f"- {item}" for item in self.system_instructions))
        if self.compiled_skills:
            sections.append("Compiled Skills:\n" + "\n\n".join(_render_compiled_skill(skill) for skill in self.compiled_skills))
        if self.available_tools:
            tool_names = [
                str(tool.get("name") or "").strip()
                for tool in self.available_tools
                if str(tool.get("name") or "").strip()
            ]
            if tool_names:
                sections.append("Available Tools:\n" + ", ".join(tool_names))
        if self.response_contract:
            sections.append(f"Response Contract:\n{self.response_contract}")
        if self.user_prompt.strip():
            sections.append(self.user_prompt.strip())
        return "\n\n".join(section for section in sections if section.strip())


@dataclass(frozen=True, slots=True)
class ExecutionStreamEvent:
    kind: ExecutionStreamEventKind
    sequence: int
    text: str | None = None
    metadata: dict[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class NormalizedExecutionError:
    code: NormalizedExecutionErrorCode
    message: str
    retryable: bool
    metadata: dict[str, Any] | None = None


class EngineFeatureSupport(StrEnum):
    none = "none"
    shim = "shim"
    native = "native"


@dataclass(frozen=True, slots=True)
class EngineCapabilityMatrix:
    streaming: EngineFeatureSupport
    resume: EngineFeatureSupport
    tool_use: EngineFeatureSupport
    image_input: EngineFeatureSupport
    sandbox: EngineFeatureSupport
    cost_tracking: EngineFeatureSupport


@runtime_checkable
class ExecutionEngine(Protocol):
    def is_available(self) -> bool: ...

    def run_fresh(self, *, model: str | None, prompt: str, cancel_signal: CancelSignal | None = None, execution_request: ExecutionRequest | None = None): ...  # noqa: ANN201

    def run_resume(
        self,
        *,
        thread_id: str,
        prompt: str | None = None,
        cancel_signal: CancelSignal | None = None,
        execution_request: ExecutionRequest | None = None,
    ): ...  # noqa: ANN201

    def normalize_output(self, output): ...  # noqa: ANN201, ANN001

    def classify_failure(self, output): ...  # noqa: ANN201, ANN001


ExecutorAdapter = ExecutionEngine


def render_prompt_from_request(*, prompt: str, execution_request: ExecutionRequest | None) -> str:
    if execution_request is None:
        return prompt
    rendered = execution_request.render_prompt().strip()
    if rendered:
        return rendered
    return prompt


def _render_compiled_skill(skill: Any) -> str:
    sections = [f"Skill: {getattr(skill, 'skill_id', '')}".rstrip()]
    instructions = tuple(getattr(skill, "instructions", ()) or ())
    checklist = tuple(getattr(skill, "checklist", ()) or ())
    workflow_steps = tuple(getattr(skill, "workflow_steps", ()) or ())
    allowed_tools = tuple(getattr(skill, "allowed_tools", ()) or ())
    blocked_tools = tuple(getattr(skill, "blocked_tools", ()) or ())
    preferred_tools = tuple(getattr(skill, "preferred_tools", ()) or ())
    validation_rules = tuple(getattr(skill, "validation_rules", ()) or ())
    if instructions:
        sections.append("Instructions:\n" + "\n".join(f"- {item}" for item in instructions))
    if checklist:
        sections.append("Checklist:\n" + "\n".join(f"- {item}" for item in checklist))
    if workflow_steps:
        sections.append("Workflow:\n" + "\n".join(f"- {item}" for item in workflow_steps))
    tool_lines: list[str] = []
    if allowed_tools:
        tool_lines.append("Allowed: " + ", ".join(allowed_tools))
    if blocked_tools:
        tool_lines.append("Blocked: " + ", ".join(blocked_tools))
    if preferred_tools:
        tool_lines.append("Preferred: " + ", ".join(preferred_tools))
    if tool_lines:
        sections.append("Tool Policy:\n" + "\n".join(tool_lines))
    if validation_rules:
        sections.append("Validation:\n" + "\n".join(f"- {item}" for item in validation_rules))
    return "\n\n".join(section for section in sections if section.strip())


class ExecutorRegistry:
    def __init__(self, *, executors: dict[str, ExecutionEngine], future_engines: list[str]) -> None:
        self._executors = executors
        self._future_engines = future_engines

    def get(self, engine_name: str) -> ExecutionEngine:
        return self._executors[engine_name]

    def has(self, engine_name: str) -> bool:
        return engine_name in self._executors

    def supported_engine_names(self) -> list[str]:
        return sorted(self._executors.keys())

    def future_engine_names(self) -> list[str]:
        return list(self._future_engines)

    @classmethod
    def with_defaults(cls) -> ExecutorRegistry:
        from workagent.executors.cli_adapters import ClaudeCliEngine, CopilotCliEngine, GeminiCliEngine
        from workagent.executors.codex import CodexCliExecutor

        return cls(
            executors={
                "codex_cli": CodexCliExecutor(),
                "copilot_cli": CopilotCliEngine(),
                "claude_cli": ClaudeCliEngine(),
                "gemini_cli": GeminiCliEngine(),
            },
            future_engines=["anthropic_api", "gemini_api", "openai_api"],
        )
