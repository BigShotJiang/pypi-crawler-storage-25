from __future__ import annotations

import os


class EngineConfigLoader:
    def __init__(self, *, env_prefix: str = "WORKAGENT_") -> None:
        self.env_prefix = env_prefix

    def load(self, provider_name: str) -> dict[str, str]:
        provider = provider_name.upper()
        values = {
            "api_key": os.getenv(f"{self.env_prefix}{provider}_API_KEY", "").strip(),
            "model": os.getenv(f"{self.env_prefix}{provider}_MODEL", "").strip(),
            "base_url": os.getenv(f"{self.env_prefix}{provider}_BASE_URL", "").strip(),
        }
        return {key: value for key, value in values.items() if value}
