from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Protocol

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.db.models import AuditEvent
from workagent.executors.base import ExecutionFailureKind, ExecutorRegistry
from workagent.executors.cli_base import CliSubprocessEngine


class EngineRoutingMode(StrEnum):
    cheap = "cheap"
    fast = "fast"
    reasoning = "reasoning"
    local_only = "local_only"


@dataclass(frozen=True, slots=True)
class EngineUsageRecord:
    engine_name: str
    task_type: str
    mode: EngineRoutingMode
    success: bool
    duration_ms: int
    estimated_cost_usd: float | None


@dataclass(frozen=True, slots=True)
class EngineRoutingResult:
    engine_name: str
    output: object


class EngineAuditLike(Protocol):
    async def record_usage(self, record: EngineUsageRecord) -> None: ...

    async def record_fallback(self, *, case_id: str, from_engine: str, to_engine: str, reason: str) -> None: ...


@dataclass(slots=True)
class EngineRoutingPolicy:
    default_engine: str = "codex_cli"
    task_defaults: dict[str, str] = field(default_factory=dict)
    mode_defaults: dict[EngineRoutingMode, str] = field(default_factory=dict)
    user_preferences: dict[str, str] = field(default_factory=dict)
    fallback_chains: dict[str, list[str]] = field(default_factory=dict)

    def select_engine(
        self,
        *,
        task_type: str,
        mode: EngineRoutingMode | None = None,
        user_id: str | None = None,
    ) -> str:
        if user_id and self.user_preferences.get(user_id):
            return self.user_preferences[user_id]
        if mode and self.mode_defaults.get(mode):
            return self.mode_defaults[mode]
        if self.task_defaults.get(task_type):
            return self.task_defaults[task_type]
        return self.default_engine

    def fallback_chain_for(self, *, primary_engine: str, mode: EngineRoutingMode | None = None) -> list[str]:
        ordered = list(self.fallback_chains.get(primary_engine, []))
        if mode and self.mode_defaults.get(mode):
            ordered.append(self.mode_defaults[mode])
        ordered.append(self.default_engine)
        seen: set[str] = {primary_engine}
        results: list[str] = []
        for name in ordered:
            if not name or name in seen:
                continue
            seen.add(name)
            results.append(name)
        return results

    def resolve_candidates(
        self,
        *,
        registry: ExecutorRegistry,
        task_type: str,
        mode: EngineRoutingMode | None = None,
        user_id: str | None = None,
    ) -> list[str]:
        primary = self.select_engine(task_type=task_type, mode=mode, user_id=user_id)
        supported = registry.supported_engine_names()
        candidates = [name for name in [primary, *self.fallback_chain_for(primary_engine=primary, mode=mode)] if name in supported]
        if mode is not EngineRoutingMode.local_only:
            return candidates
        return [
            name
            for name in candidates
            if isinstance(registry.get(name), CliSubprocessEngine) or name.endswith("_cli")
        ]


class EngineUsageAuditService:
    def __init__(self, session_factory: async_sessionmaker[AsyncSession]) -> None:
        self.session_factory = session_factory

    async def record_usage(self, record: EngineUsageRecord) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="engine.usage",
                    entity_type="engine",
                    entity_id=record.engine_name,
                    payload_json={
                        "taskType": record.task_type,
                        "mode": record.mode.value,
                        "success": record.success,
                        "durationMs": record.duration_ms,
                        "estimatedCostUsd": record.estimated_cost_usd,
                    },
                )
            )
            await session.commit()

    async def record_fallback(
        self,
        *,
        case_id: str,
        from_engine: str,
        to_engine: str,
        reason: str,
    ) -> None:
        async with self.session_factory() as session:
            session.add(
                AuditEvent(
                    event_type="engine.fallback",
                    entity_type="case",
                    entity_id=case_id,
                    payload_json={
                        "fromEngine": from_engine,
                        "toEngine": to_engine,
                        "reason": reason,
                    },
                )
            )
            await session.commit()


class EngineExecutionService:
    def __init__(
        self,
        *,
        registry: ExecutorRegistry,
        policy: EngineRoutingPolicy,
        audit_service: EngineAuditLike | None = None,
    ) -> None:
        self.registry = registry
        self.policy = policy
        self.audit_service = audit_service

    async def execute(
        self,
        *,
        task_type: str,
        prompt: str,
        case_id: str | None = None,
        mode: EngineRoutingMode = EngineRoutingMode.reasoning,
        user_id: str | None = None,
        model: str | None = None,
    ) -> EngineRoutingResult:
        candidates = self.policy.resolve_candidates(
            registry=self.registry,
            task_type=task_type,
            mode=mode,
            user_id=user_id,
        )
        if not candidates:
            raise RuntimeError("no execution engines are available for this request")

        last_failure: tuple[str, object, ExecutionFailureKind] | None = None
        for index, engine_name in enumerate(candidates):
            engine = self.registry.get(engine_name)
            started_at = time.monotonic()
            output = engine.run_fresh(model=model, prompt=prompt)
            duration_ms = int((time.monotonic() - started_at) * 1000)
            success = int(getattr(output, "return_code", 1)) == 0
            if self.audit_service is not None:
                await self.audit_service.record_usage(
                    EngineUsageRecord(
                        engine_name=engine_name,
                        task_type=task_type,
                        mode=mode,
                        success=success,
                        duration_ms=duration_ms,
                        estimated_cost_usd=None,
                    )
                )
            if success:
                return EngineRoutingResult(engine_name=engine_name, output=output)

            failure_kind = engine.classify_failure(output)
            last_failure = (engine_name, output, failure_kind)
            if index + 1 >= len(candidates):
                break
            if self.audit_service is not None and case_id is not None:
                await self.audit_service.record_fallback(
                    case_id=case_id,
                    from_engine=engine_name,
                    to_engine=candidates[index + 1],
                    reason=failure_kind.value,
                )

        assert last_failure is not None
        engine_name, output, failure_kind = last_failure
        raise RuntimeError(f"all execution engines failed; last_engine={engine_name} failure={failure_kind.value}") from None
