from __future__ import annotations

import os
import shutil


def _resolve_command_path(command: str) -> str:
    """Resolve a CLI command to its absolute path.

    Falls back to searching common package manager install locations
    when the command is not found in the current PATH. This is necessary
    for daemon processes that may not inherit the full interactive shell PATH
    (e.g. nvm, Homebrew, npm global).
    """
    resolved = shutil.which(command)
    if resolved:
        return resolved

    home = os.path.expanduser("~")
    extra_dirs: list[str] = []

    nvm_node_root = os.path.join(home, ".nvm", "versions", "node")
    if os.path.isdir(nvm_node_root):
        try:
            versions = sorted(os.listdir(nvm_node_root), reverse=True)
            extra_dirs.extend(os.path.join(nvm_node_root, v, "bin") for v in versions)
        except OSError:
            pass

    extra_dirs.extend([
        os.path.join(home, ".npm-global", "bin"),
        os.path.join(home, "AppData", "Roaming", "npm"),
        "/usr/local/bin",
        "/opt/homebrew/bin",
        "/usr/local/homebrew/bin",
    ])

    extended_path = os.pathsep.join(extra_dirs) + os.pathsep + os.environ.get("PATH", "")
    resolved = shutil.which(command, path=extended_path)
    return resolved if resolved else command


class CliSubprocessEngine:
    def __init__(self, *, command: str, runner=None, timeout_seconds: int = 600) -> None:  # noqa: ANN001
        self.command = _resolve_command_path(command)
        self.runner = runner
        self.timeout_seconds = timeout_seconds

    def is_available(self) -> bool:
        return shutil.which(self.command) is not None
