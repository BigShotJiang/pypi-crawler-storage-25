from __future__ import annotations

import json
from dataclasses import dataclass, field

from workagent.executors.base import ExecutionFailureKind, NormalizedExecutionResult, render_prompt_from_request
from workagent.executors.cli_base import CliSubprocessEngine
from workagent.executors.codex import CommandRunner, ExecutionOutput, SubprocessRunner


@dataclass(frozen=True, slots=True)
class CliAdapterCandidate:
    engine_name: str
    command: str
    description: str
    preference_rank: int


@dataclass(frozen=True, slots=True)
class CliSessionState:
    engine_name: str
    thread_id: str
    working_directory: str | None = None
    metadata: dict[str, str] = field(default_factory=dict)

    def to_payload(self) -> dict[str, object]:
        return {
            "engineName": self.engine_name,
            "threadId": self.thread_id,
            "workingDirectory": self.working_directory,
            "metadata": self.metadata,
        }

    @classmethod
    def from_payload(cls, payload: dict[str, object]) -> CliSessionState:
        return cls(
            engine_name=str(payload.get("engineName") or ""),
            thread_id=str(payload.get("threadId") or ""),
            working_directory=str(payload.get("workingDirectory") or "") or None,
            metadata={str(key): str(value) for key, value in dict(payload.get("metadata") or {}).items()},
        )


@dataclass(frozen=True, slots=True)
class ParsedCliOutput:
    thread_id: str | None
    assistant_text: str


class JsonlCliOutputParser:
    def parse(self, stdout: str) -> ParsedCliOutput:
        thread_id: str | None = None
        assistant_chunks: list[str] = []
        for raw_line in stdout.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(payload, dict):
                if isinstance(payload.get("thread_id"), str):
                    thread_id = payload["thread_id"]
                message = payload.get("message")
                if isinstance(message, dict) and isinstance(message.get("content"), str):
                    assistant_chunks.append(message["content"])
                elif isinstance(payload.get("content"), str):
                    assistant_chunks.append(str(payload["content"]))
        return ParsedCliOutput(thread_id=thread_id, assistant_text="\n".join(assistant_chunks).strip())


@dataclass(frozen=True, slots=True)
class EngineCapabilityMetadata:
    engine_name: str
    session_persistence: str
    stdout_format: str
    suggested_models: list[str]
    image_input_mode: str
    pdf_input_mode: str
    text_document_input_mode: str
    office_document_input_mode: str
    archive_input_mode: str
    audio_input_mode: str
    video_input_mode: str
    binary_input_mode: str
    local_file_path_support: bool
    remote_url_support: bool
    max_attachment_count: int
    max_payload_bytes_guidance: int | None
    attachment_support_stability: str
    attachment_self_test_required: bool


def list_cli_adapter_candidates() -> list[CliAdapterCandidate]:
    return sorted(
        [
            CliAdapterCandidate(
                engine_name="codex_cli",
                command="codex",
                description="Primary local coding CLI engine",
                preference_rank=1,
            ),
            CliAdapterCandidate(
                engine_name="copilot_cli",
                command="copilot",
                description="GitHub Copilot CLI coding engine",
                preference_rank=2,
            ),
            CliAdapterCandidate(
                engine_name="claude_cli",
                command="claude",
                description="Alternative local CLI engine with thread resume semantics",
                preference_rank=3,
            ),
            CliAdapterCandidate(
                engine_name="gemini_cli",
                command="gemini",
                description="Candidate local CLI engine with plain-text output semantics",
                preference_rank=4,
            ),
        ],
        key=lambda item: item.preference_rank,
    )


def get_engine_capability_metadata(engine_name: str) -> EngineCapabilityMetadata:
    mapping = {
        "codex_cli": EngineCapabilityMetadata(
            engine_name="codex_cli",
            session_persistence="thread_resume",
            stdout_format="jsonl",
            suggested_models=["gpt-5.4", "gpt-5.4-mini"],
            image_input_mode="fallback_text",
            pdf_input_mode="fallback_text",
            text_document_input_mode="extracted_text",
            office_document_input_mode="extracted_text",
            archive_input_mode="extracted_text",
            audio_input_mode="metadata_only",
            video_input_mode="metadata_only",
            binary_input_mode="metadata_only",
            local_file_path_support=False,
            remote_url_support=False,
            max_attachment_count=5,
            max_payload_bytes_guidance=None,
            attachment_support_stability="version_gated",
            attachment_self_test_required=True,
        ),
        "copilot_cli": EngineCapabilityMetadata(
            engine_name="copilot_cli",
            session_persistence="thread_resume",
            stdout_format="jsonl",
            suggested_models=["claude-sonnet-4.5", "claude-opus-4.6", "gpt-5.2-codex"],
            image_input_mode="fallback_text",
            pdf_input_mode="fallback_text",
            text_document_input_mode="extracted_text",
            office_document_input_mode="extracted_text",
            archive_input_mode="extracted_text",
            audio_input_mode="metadata_only",
            video_input_mode="metadata_only",
            binary_input_mode="metadata_only",
            local_file_path_support=False,
            remote_url_support=False,
            max_attachment_count=5,
            max_payload_bytes_guidance=None,
            attachment_support_stability="version_gated",
            attachment_self_test_required=True,
        ),
        "claude_cli": EngineCapabilityMetadata(
            engine_name="claude_cli",
            session_persistence="thread_resume",
            stdout_format="jsonl",
            suggested_models=["sonnet", "haiku"],
            image_input_mode="fallback_text",
            pdf_input_mode="fallback_text",
            text_document_input_mode="extracted_text",
            office_document_input_mode="extracted_text",
            archive_input_mode="extracted_text",
            audio_input_mode="metadata_only",
            video_input_mode="metadata_only",
            binary_input_mode="metadata_only",
            local_file_path_support=False,
            remote_url_support=False,
            max_attachment_count=5,
            max_payload_bytes_guidance=None,
            attachment_support_stability="version_gated",
            attachment_self_test_required=True,
        ),
        "gemini_cli": EngineCapabilityMetadata(
            engine_name="gemini_cli",
            session_persistence="stateless",
            stdout_format="plain_text",
            suggested_models=["gemini-2.5-pro", "gemini-2.5-flash"],
            image_input_mode="fallback_text",
            pdf_input_mode="fallback_text",
            text_document_input_mode="extracted_text",
            office_document_input_mode="extracted_text",
            archive_input_mode="extracted_text",
            audio_input_mode="metadata_only",
            video_input_mode="metadata_only",
            binary_input_mode="metadata_only",
            local_file_path_support=False,
            remote_url_support=False,
            max_attachment_count=5,
            max_payload_bytes_guidance=None,
            attachment_support_stability="version_gated",
            attachment_self_test_required=True,
        ),
        "openai_api": EngineCapabilityMetadata(
            engine_name="openai_api",
            session_persistence="stateless",
            stdout_format="json",
            suggested_models=["gpt-5.4", "gpt-5.4-mini"],
            image_input_mode="native",
            pdf_input_mode="native",
            text_document_input_mode="extracted_text",
            office_document_input_mode="extracted_text",
            archive_input_mode="extracted_text",
            audio_input_mode="metadata_only",
            video_input_mode="metadata_only",
            binary_input_mode="metadata_only",
            local_file_path_support=False,
            remote_url_support=False,
            max_attachment_count=5,
            max_payload_bytes_guidance=20 * 1024 * 1024,
            attachment_support_stability="stable",
            attachment_self_test_required=False,
        ),
        "gemini_api": EngineCapabilityMetadata(
            engine_name="gemini_api",
            session_persistence="stateless",
            stdout_format="json",
            suggested_models=["gemini-2.5-pro", "gemini-2.5-flash"],
            image_input_mode="native",
            pdf_input_mode="native",
            text_document_input_mode="extracted_text",
            office_document_input_mode="extracted_text",
            archive_input_mode="extracted_text",
            audio_input_mode="native",
            video_input_mode="native",
            binary_input_mode="metadata_only",
            local_file_path_support=False,
            remote_url_support=False,
            max_attachment_count=5,
            max_payload_bytes_guidance=20 * 1024 * 1024,
            attachment_support_stability="stable",
            attachment_self_test_required=False,
        ),
        "anthropic_api": EngineCapabilityMetadata(
            engine_name="anthropic_api",
            session_persistence="stateless",
            stdout_format="json",
            suggested_models=["claude-sonnet-4-6", "claude-opus-4-6", "claude-haiku-4-5"],
            image_input_mode="native",
            pdf_input_mode="native",
            text_document_input_mode="extracted_text",
            office_document_input_mode="extracted_text",
            archive_input_mode="extracted_text",
            audio_input_mode="metadata_only",
            video_input_mode="metadata_only",
            binary_input_mode="metadata_only",
            local_file_path_support=False,
            remote_url_support=False,
            max_attachment_count=5,
            max_payload_bytes_guidance=20 * 1024 * 1024,
            attachment_support_stability="stable",
            attachment_self_test_required=False,
        ),
    }
    return mapping[engine_name]


def run_cli_attachment_self_test(engine_name: str, executor: object) -> bool:
    metadata = get_engine_capability_metadata(engine_name)
    if not metadata.attachment_self_test_required:
        return metadata.image_input_mode == "native" or metadata.pdf_input_mode == "native"
    return False


class ClaudeCliOutputParser:
    """Parses the stream-json output format produced by the Claude Code CLI."""

    def parse(self, stdout: str) -> ParsedCliOutput:
        thread_id: str | None = None
        result_text: str | None = None
        for raw_line in stdout.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(payload, dict):
                continue
            # session_id is the thread-resume identifier in Claude CLI output
            if isinstance(payload.get("session_id"), str) and not thread_id:
                thread_id = payload["session_id"]
            # The final "result" event holds the consolidated assistant response
            if str(payload.get("type") or "") == "result" and isinstance(payload.get("result"), str):
                result_text = payload["result"].strip()
        return ParsedCliOutput(thread_id=thread_id, assistant_text=result_text or "")


class ClaudeCliEngine(CliSubprocessEngine):
    """Executor that delegates to the locally-installed Claude Code CLI."""

    def __init__(
        self,
        *,
        command: str = "claude",
        model: str | None = None,
        runner: CommandRunner | None = None,
        timeout_seconds: int = 600,
    ) -> None:
        super().__init__(command=command, runner=runner or SubprocessRunner(), timeout_seconds=timeout_seconds)
        self.model = model
        self.output_parser = ClaudeCliOutputParser()

    def build_fresh_command(self, *, model: str | None, prompt: str) -> list[str]:
        resolved_model = model or self.model
        command = [
            self.command,
            "--dangerously-skip-permissions",
            "-p", prompt,
            "--output-format", "stream-json",
            "--verbose",
        ]
        if resolved_model:
            command.extend(["--model", resolved_model])
        return command

    def build_resume_command(self, *, thread_id: str, prompt: str | None = None) -> list[str]:
        command = [
            self.command,
            "--dangerously-skip-permissions",
            "--resume", thread_id,
            "--output-format", "stream-json",
            "--verbose",
        ]
        if prompt:
            command.extend(["-p", prompt])
        return command

    def run_fresh(self, *, model: str | None, prompt: str, cancel_signal=None, execution_request=None) -> ExecutionOutput:  # noqa: ANN001
        effective_prompt = render_prompt_from_request(prompt=prompt, execution_request=execution_request)
        return_code, stdout, stderr = self.runner.run(
            self.build_fresh_command(model=model, prompt=effective_prompt),
            timeout_seconds=self.timeout_seconds,
            cancel_signal=cancel_signal,
        )
        parsed = self.output_parser.parse(stdout)
        return ExecutionOutput(
            thread_id=parsed.thread_id,
            assistant_text=parsed.assistant_text,
            raw_stdout=stdout,
            raw_stderr=stderr,
            return_code=return_code,
        )

    def run_resume(self, *, thread_id: str, prompt: str | None = None, cancel_signal=None, execution_request=None) -> ExecutionOutput:  # noqa: ANN001
        effective_prompt = render_prompt_from_request(prompt=prompt or "", execution_request=execution_request)
        return_code, stdout, stderr = self.runner.run(
            self.build_resume_command(thread_id=thread_id, prompt=effective_prompt or None),
            timeout_seconds=self.timeout_seconds,
            cancel_signal=cancel_signal,
        )
        parsed = self.output_parser.parse(stdout)
        return ExecutionOutput(
            thread_id=parsed.thread_id,
            assistant_text=parsed.assistant_text,
            raw_stdout=stdout,
            raw_stderr=stderr,
            return_code=return_code,
        )

    def normalize_output(self, output: ExecutionOutput) -> NormalizedExecutionResult:
        draft = output.assistant_text.strip()
        summary = draft.splitlines()[0].strip() if draft else None
        return NormalizedExecutionResult(
            thread_id=output.thread_id,
            draft=draft,
            summary=summary,
            evidence_refs=[],
            raw_transcript=output.raw_stdout,
        )

    def classify_failure(self, output: ExecutionOutput) -> ExecutionFailureKind:
        stderr = output.raw_stderr.lower()
        if "timeout" in stderr or "network" in stderr:
            return ExecutionFailureKind.retryable
        if "permission denied" in stderr or "auth" in stderr or "unauthorized" in stderr:
            return ExecutionFailureKind.manual_required
        # Claude writes errors to stdout as JSON events, not stderr
        stdout = output.raw_stdout.lower()
        if "rate_limit" in stdout or "overloaded" in stdout or "rate limit" in stdout:
            return ExecutionFailureKind.retryable
        if "authentication_error" in stdout or "invalid_api_key" in stdout or "permission_error" in stdout:
            return ExecutionFailureKind.manual_required
        return ExecutionFailureKind.fatal

    def capability_metadata(self) -> EngineCapabilityMetadata:
        return get_engine_capability_metadata("claude_cli")


class GeminiCliEngine(CliSubprocessEngine):
    """Executor that delegates to the locally-installed Google Gemini CLI.

    The Gemini CLI is stateless (no session resume). stdout is plain text.
    Authentication is handled externally via the GEMINI_API_KEY env variable
    or Google Cloud ADC credentials.
    """

    def __init__(
        self,
        *,
        command: str = "gemini",
        model: str | None = None,
        runner: CommandRunner | None = None,
        timeout_seconds: int = 600,
    ) -> None:
        super().__init__(command=command, runner=runner or SubprocessRunner(), timeout_seconds=timeout_seconds)
        self.model = model

    def build_fresh_command(self, *, model: str | None, prompt: str) -> list[str]:
        resolved_model = model or self.model
        command = [self.command, "--yolo", "-p", prompt]
        if resolved_model:
            command.extend(["--model", resolved_model])
        return command

    def run_fresh(self, *, model: str | None, prompt: str, cancel_signal=None, execution_request=None) -> ExecutionOutput:  # noqa: ANN001
        effective_prompt = render_prompt_from_request(prompt=prompt, execution_request=execution_request)
        return_code, stdout, stderr = self.runner.run(
            self.build_fresh_command(model=model, prompt=effective_prompt),
            timeout_seconds=self.timeout_seconds,
            cancel_signal=cancel_signal,
        )
        return ExecutionOutput(
            thread_id=None,
            assistant_text=stdout.strip(),
            raw_stdout=stdout,
            raw_stderr=stderr,
            return_code=return_code,
        )

    def run_resume(self, *, thread_id: str, prompt: str | None = None, cancel_signal=None, execution_request=None) -> ExecutionOutput:  # noqa: ANN001
        # Gemini CLI is stateless — resume is not supported; fall back to a fresh run
        return self.run_fresh(model=None, prompt=prompt or "", cancel_signal=cancel_signal, execution_request=execution_request)

    def normalize_output(self, output: ExecutionOutput) -> NormalizedExecutionResult:
        draft = output.assistant_text.strip()
        summary = draft.splitlines()[0].strip() if draft else None
        return NormalizedExecutionResult(
            thread_id=output.thread_id,
            draft=draft,
            summary=summary,
            evidence_refs=[],
            raw_transcript=output.raw_stdout,
        )

    def classify_failure(self, output: ExecutionOutput) -> ExecutionFailureKind:
        stderr = output.raw_stderr.lower()
        if "timeout" in stderr or "network" in stderr or "rate limit" in stderr or "quota" in stderr:
            return ExecutionFailureKind.retryable
        if "auth" in stderr or "unauthorized" in stderr or "api key" in stderr or "invalid api key" in stderr:
            return ExecutionFailureKind.manual_required
        return ExecutionFailureKind.fatal

    def capability_metadata(self) -> EngineCapabilityMetadata:
        return get_engine_capability_metadata("gemini_cli")


class CopilotCliEngine(CliSubprocessEngine):
    def __init__(
        self,
        *,
        command: str = "copilot",
        auth_token: str | None = None,
        runner: CommandRunner | None = None,
        timeout_seconds: int = 600,
    ) -> None:
        super().__init__(command=command, runner=runner or SubprocessRunner(), timeout_seconds=timeout_seconds)
        self.auth_token = auth_token
        self.output_parser = JsonlCliOutputParser()

    def build_fresh_command(self, *, model: str | None, prompt: str) -> list[str]:
        command = [
            self.command,
            "--yolo",
            "--autopilot",
            "--output-format=json",
        ]
        if model:
            command.append(f"--model={model}")
        command.append(f"--prompt={prompt}")
        return command

    def build_resume_command(self, *, thread_id: str, prompt: str | None = None) -> list[str]:
        command = [
            self.command,
            "--yolo",
            "--autopilot",
            "--output-format=json",
            f"--resume={thread_id}",
        ]
        if prompt:
            command.append(f"--prompt={prompt}")
        return command

    def run_fresh(self, *, model: str | None, prompt: str, cancel_signal=None, execution_request=None) -> ExecutionOutput:  # noqa: ANN001
        effective_prompt = render_prompt_from_request(prompt=prompt, execution_request=execution_request)
        return self._run(self.build_fresh_command(model=model, prompt=effective_prompt), cancel_signal=cancel_signal)

    def run_resume(self, *, thread_id: str, prompt: str | None = None, cancel_signal=None, execution_request=None) -> ExecutionOutput:  # noqa: ANN001
        effective_prompt = render_prompt_from_request(prompt=prompt or "", execution_request=execution_request)
        return self._run(self.build_resume_command(thread_id=thread_id, prompt=effective_prompt or None), cancel_signal=cancel_signal)

    def normalize_output(self, output: ExecutionOutput) -> NormalizedExecutionResult:
        draft = output.assistant_text.strip()
        summary = draft.splitlines()[0].strip() if draft else None
        return NormalizedExecutionResult(
            thread_id=output.thread_id,
            draft=draft,
            summary=summary,
            evidence_refs=[],
            raw_transcript=output.raw_stdout,
        )

    def classify_failure(self, output: ExecutionOutput) -> ExecutionFailureKind:
        stderr = output.raw_stderr.lower()
        if "timeout" in stderr or "network" in stderr or "temporarily unavailable" in stderr:
            return ExecutionFailureKind.retryable
        if "auth" in stderr or "unauthorized" in stderr or "forbidden" in stderr:
            return ExecutionFailureKind.manual_required
        return ExecutionFailureKind.fatal

    def capability_metadata(self) -> EngineCapabilityMetadata:
        return get_engine_capability_metadata("copilot_cli")

    def _run(self, command: list[str], *, cancel_signal=None) -> ExecutionOutput:  # noqa: ANN001
        if self.runner is None:
            raise RuntimeError("runner is required for Copilot CLI execution")
        env = {"COPILOT_GITHUB_TOKEN": self.auth_token} if self.auth_token else None
        return_code, stdout, stderr = self.runner.run(
            command,
            timeout_seconds=self.timeout_seconds,
            cancel_signal=cancel_signal,
            env=env,
        )
        parsed = self.output_parser.parse(stdout)
        assistant_text = parsed.assistant_text.strip() or stdout.strip()
        return ExecutionOutput(
            thread_id=parsed.thread_id,
            assistant_text=assistant_text,
            raw_stdout=stdout,
            raw_stderr=stderr,
            return_code=return_code,
        )
