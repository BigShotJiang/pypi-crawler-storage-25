from __future__ import annotations

import base64
import logging
from dataclasses import dataclass, field
from typing import Any

import httpx

from workagent.executors.base import ExecutionFailureKind, NormalizedExecutionResult, render_prompt_from_request
from workagent.executors.cli_adapters import EngineCapabilityMetadata
from workagent.executors.codex import ExecutionOutput

logger = logging.getLogger("workagent.executor.api")


def _truncate_for_log(value: str | None, *, limit: int = 200) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    if len(normalized) <= limit:
        return normalized
    return f"{normalized[: limit - 3]}..."


@dataclass(frozen=True, slots=True)
class ApiAuthConfig:
    provider_name: str
    secret_key: str
    base_url: str | None = None
    metadata: dict[str, str] = field(default_factory=dict)

    def to_payload(self) -> dict[str, object]:
        return {
            "providerName": self.provider_name,
            "secretKey": self.secret_key,
            "baseUrl": self.base_url,
            "metadata": self.metadata,
        }

    @classmethod
    def from_payload(cls, payload: dict[str, object]) -> ApiAuthConfig:
        return cls(
            provider_name=str(payload.get("providerName") or ""),
            secret_key=str(payload.get("secretKey") or ""),
            base_url=str(payload.get("baseUrl") or "") or None,
            metadata={str(key): str(value) for key, value in dict(payload.get("metadata") or {}).items()},
        )


@dataclass(frozen=True, slots=True)
class ApiRetryPolicy:
    max_attempts: int = 3
    base_backoff_seconds: float = 2.0

    @property
    def backoff_seconds(self) -> list[float]:
        return [1.0, 2.0, 5.0][: self.max_attempts]


@dataclass(frozen=True, slots=True)
class ApiEngineCapabilityMetadata:
    engine_name: str
    suggested_models: list[str]
    supports_tools: bool
    supports_images: bool
    supports_streaming: bool


@dataclass(slots=True)
class ApiExecutionEngine:
    model_name: str
    api_key: str | None = None
    base_url: str | None = None
    transport: httpx.BaseTransport | None = None
    timeout: float = 120.0

    @property
    def provider_name(self) -> str:
        raise NotImplementedError

    def is_available(self) -> bool:
        return bool(self.api_key)

    def auth_storage_key(self) -> str:
        return f"engine:{self.provider_name}:api_key"

    def auth_config(self, *, secret_key: str) -> ApiAuthConfig:
        return ApiAuthConfig(
            provider_name=self.provider_name,
            secret_key=secret_key,
            base_url=self.base_url,
            metadata={"model": self.model_name},
        )

    def retry_policy(self) -> ApiRetryPolicy:
        return ApiRetryPolicy()

    def capability_metadata(self) -> EngineCapabilityMetadata:
        return EngineCapabilityMetadata(
            engine_name=f"{self.provider_name}_api",
            session_persistence="provider_managed",
            stdout_format="api_json",
            suggested_models=[self.model_name],
            image_input_mode="native",
            pdf_input_mode="native",
            text_document_input_mode="extracted_text",
            office_document_input_mode="extracted_text",
            archive_input_mode="extracted_text",
            audio_input_mode="metadata_only",
            video_input_mode="metadata_only",
            binary_input_mode="metadata_only",
            local_file_path_support=False,
            remote_url_support=False,
            max_attachment_count=5,
            max_payload_bytes_guidance=20 * 1024 * 1024,
            attachment_support_stability="stable",
            attachment_self_test_required=False,
        )

    def run_fresh(
        self,
        *,
        model: str | None,
        prompt: str,
        attachments: list[dict[str, Any]] | None = None,
        reasoning_effort_override: str | None = None,
        cancel_signal=None,
        execution_request=None,
    ):  # noqa: ANN001, ANN201, ARG002
        resolved_model = model or self.model_name
        effective_prompt = render_prompt_from_request(prompt=prompt, execution_request=execution_request)
        if not self.api_key:
            return ExecutionOutput(
                thread_id=None,
                assistant_text="",
                raw_stdout="",
                raw_stderr="status=401 api key missing",
                return_code=1,
            )
        path, headers, payload = self.build_request(
            model=resolved_model,
            prompt=effective_prompt,
            attachments=attachments,
            reasoning_effort=reasoning_effort_override,
        )
        logger.info(
            "api request started provider=%s model=%s reasoning_effort=%s path=%s",
            self.provider_name,
            resolved_model,
            reasoning_effort_override or "",
            path,
        )
        try:
            with httpx.Client(
                base_url=self.resolved_base_url(),
                transport=self.transport,
                timeout=self.timeout,
            ) as client:
                response = client.post(path, headers=headers, json=payload)
        except httpx.TimeoutException as exc:
            return ExecutionOutput(
                thread_id=None,
                assistant_text="",
                raw_stdout="",
                raw_stderr=f"timeout {exc}",
                return_code=1,
            )
        except httpx.HTTPError as exc:
            return ExecutionOutput(
                thread_id=None,
                assistant_text="",
                raw_stdout="",
                raw_stderr=f"network {exc}",
                return_code=1,
            )

        raw_stdout = response.text
        if response.is_error:
            logger.warning(
                "api request failed provider=%s model=%s status=%s body=%r",
                self.provider_name,
                resolved_model,
                response.status_code,
                _truncate_for_log(raw_stdout),
            )
            return ExecutionOutput(
                thread_id=None,
                assistant_text="",
                raw_stdout=raw_stdout,
                raw_stderr=f"status={response.status_code} {raw_stdout}",
                return_code=1,
            )

        payload_json = response.json()
        assistant_text = self.extract_assistant_text(payload_json)
        logger.info(
            "api request completed provider=%s model=%s thread_id=%s assistant_text=%r",
            self.provider_name,
            resolved_model,
            self.extract_thread_id(payload_json) or "",
            _truncate_for_log(assistant_text),
        )
        return ExecutionOutput(
            thread_id=self.extract_thread_id(payload_json),
            assistant_text=assistant_text,
            raw_stdout=raw_stdout,
            raw_stderr="",
            return_code=0,
        )

    def run_resume(self, *, thread_id: str, prompt: str | None = None, cancel_signal=None, execution_request=None):  # noqa: ANN001, ANN201, ARG002
        return self.run_fresh(model=self.model_name, prompt=prompt or thread_id, execution_request=execution_request)

    def normalize_output(self, output):  # noqa: ANN001, ANN201
        draft = str(getattr(output, "assistant_text", "") or "").strip()
        summary = draft.splitlines()[0].strip() if draft else None
        return NormalizedExecutionResult(
            thread_id=getattr(output, "thread_id", None),
            draft=draft,
            summary=summary,
            evidence_refs=[],
            raw_transcript=str(getattr(output, "raw_stdout", "") or ""),
        )

    def classify_failure(self, output):  # noqa: ANN001, ANN201, ARG002
        stderr = str(getattr(output, "raw_stderr", "") or "").lower()
        if "timeout" in stderr or "network" in stderr or "status=5" in stderr:
            return ExecutionFailureKind.retryable
        if "status=401" in stderr or "status=403" in stderr or "api key" in stderr or "unauthorized" in stderr:
            return ExecutionFailureKind.manual_required
        return ExecutionFailureKind.fatal

    def resolved_base_url(self) -> str:
        return (self.base_url or self.default_base_url()).rstrip("/")

    def default_base_url(self) -> str:
        raise NotImplementedError

    def build_request(
        self,
        *,
        model: str,
        prompt: str,
        attachments: list[dict[str, Any]] | None = None,
        reasoning_effort: str | None = None,
    ) -> tuple[str, dict[str, str], dict[str, Any]]:
        raise NotImplementedError

    def extract_assistant_text(self, payload: dict[str, Any]) -> str:
        raise NotImplementedError

    def extract_thread_id(self, payload: dict[str, Any]) -> str | None:
        for key in ("id", "response_id"):
            value = str(payload.get(key) or "").strip()
            if value:
                return value
        return None


@dataclass(slots=True)
class OpenAIExecutionEngine(ApiExecutionEngine):
    @property
    def provider_name(self) -> str:
        return "openai"

    def default_base_url(self) -> str:
        return "https://api.openai.com/v1"

    def build_request(
        self,
        *,
        model: str,
        prompt: str,
        attachments: list[dict[str, Any]] | None = None,
        reasoning_effort: str | None = None,
    ) -> tuple[str, dict[str, str], dict[str, Any]]:
        payload: dict[str, Any] = {"model": model}
        if attachments:
            content: list[dict[str, Any]] = [{"type": "input_text", "text": prompt}]
            for attachment in attachments:
                mime_type = str(attachment.get("mimeType") or "").strip()
                data = base64.b64encode(bytes(attachment.get("contentBytes") or b"")).decode("ascii")
                if mime_type.startswith("image/"):
                    content.append(
                        {
                            "type": "input_image",
                            "image_url": f"data:{mime_type};base64,{data}",
                        }
                    )
                else:
                    content.append(
                        {
                            "type": "input_file",
                            "filename": str(attachment.get("name") or "attachment").strip() or "attachment",
                            "file_data": f"data:{mime_type};base64,{data}",
                        }
                    )
            payload["input"] = [{"role": "user", "content": content}]
        else:
            payload["input"] = prompt
        if reasoning_effort:
            payload["reasoning"] = {"effort": reasoning_effort}
        return (
            "/responses",
            {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            payload,
        )

    def extract_assistant_text(self, payload: dict[str, Any]) -> str:
        output = payload.get("output")
        if isinstance(output, list):
            texts: list[str] = []
            for item in output:
                if not isinstance(item, dict):
                    continue
                content = item.get("content")
                for part in content if isinstance(content, list) else []:
                    if not isinstance(part, dict):
                        continue
                    text = str(part.get("text") or "").strip()
                    if text:
                        texts.append(text)
            if texts:
                return "\n".join(texts)
        return str(payload.get("output_text") or "").strip()


@dataclass(slots=True)
class GeminiExecutionEngine(ApiExecutionEngine):
    file_upload_threshold_bytes: int = 20 * 1024 * 1024

    @property
    def provider_name(self) -> str:
        return "gemini"

    def default_base_url(self) -> str:
        return "https://generativelanguage.googleapis.com/v1beta"

    def build_request(
        self,
        *,
        model: str,
        prompt: str,
        attachments: list[dict[str, Any]] | None = None,
        reasoning_effort: str | None = None,
    ) -> tuple[str, dict[str, str], dict[str, Any]]:
        parts: list[dict[str, Any]] = [{"text": prompt}]
        for attachment in attachments or []:
            mime_type = str(attachment.get("mimeType") or "").strip()
            content_bytes = bytes(attachment.get("contentBytes") or b"")
            file_uri = str(attachment.get("fileUri") or "").strip()
            if not file_uri and len(content_bytes) > self.file_upload_threshold_bytes:
                file_uri = self._upload_file_via_file_api(
                    mime_type=mime_type,
                    content_bytes=content_bytes,
                    display_name=str(attachment.get("name") or "attachment").strip() or "attachment",
                )
            if file_uri:
                parts.append(
                    {
                        "file_data": {
                            "mime_type": mime_type,
                            "file_uri": file_uri,
                        }
                    }
                )
                continue
            data = base64.b64encode(content_bytes).decode("ascii")
            parts.append(
                {
                    "inline_data": {
                        "mime_type": mime_type,
                        "data": data,
                    }
                }
            )
        payload: dict[str, Any] = {
            "contents": [
                {
                    "parts": parts
                }
            ]
        }
        if reasoning_effort:
            payload["generationConfig"] = {
                "thinkingConfig": {
                    "thinkingLevel": reasoning_effort,
                }
            }
        return (
            f"/models/{model}:generateContent",
            {
                "Content-Type": "application/json",
                "x-goog-api-key": str(self.api_key or ""),
            },
            payload,
        )

    def _upload_file_via_file_api(
        self,
        *,
        mime_type: str,
        content_bytes: bytes,
        display_name: str,
    ) -> str:
        upload_base_url = self.resolved_base_url().replace("/v1beta", "")
        headers = {
            "x-goog-api-key": str(self.api_key or ""),
            "X-Goog-Upload-Protocol": "resumable",
            "X-Goog-Upload-Command": "start",
            "X-Goog-Upload-Header-Content-Length": str(len(content_bytes)),
            "X-Goog-Upload-Header-Content-Type": mime_type,
            "Content-Type": "application/json",
        }
        with httpx.Client(base_url=upload_base_url, transport=self.transport, timeout=self.timeout) as client:
            start_response = client.post(
                "/upload/v1beta/files",
                headers=headers,
                json={"file": {"display_name": display_name}},
            )
            start_response.raise_for_status()
            upload_url = str(start_response.headers.get("x-goog-upload-url") or "").strip()
            if not upload_url:
                raise RuntimeError("gemini file upload url missing")
            finalize_response = client.post(
                upload_url,
                headers={
                    "x-goog-api-key": str(self.api_key or ""),
                    "Content-Length": str(len(content_bytes)),
                    "X-Goog-Upload-Offset": "0",
                    "X-Goog-Upload-Command": "upload, finalize",
                },
                content=content_bytes,
            )
            finalize_response.raise_for_status()
            payload = finalize_response.json()
        file_info = payload.get("file") if isinstance(payload, dict) else None
        file_uri = str(file_info.get("uri") or "").strip() if isinstance(file_info, dict) else ""
        if not file_uri:
            raise RuntimeError("gemini file uri missing")
        return file_uri

    def extract_assistant_text(self, payload: dict[str, Any]) -> str:
        candidates = payload.get("candidates")
        for candidate in candidates if isinstance(candidates, list) else []:
            if not isinstance(candidate, dict):
                continue
            content = candidate.get("content")
            if not isinstance(content, dict):
                continue
            parts = content.get("parts")
            texts = [str(part.get("text") or "").strip() for part in parts if isinstance(part, dict)]
            texts = [text for text in texts if text]
            if texts:
                return "\n".join(texts)
        return ""


@dataclass(slots=True)
class AnthropicExecutionEngine(ApiExecutionEngine):
    @property
    def provider_name(self) -> str:
        return "anthropic"

    def default_base_url(self) -> str:
        return "https://api.anthropic.com"

    def build_request(
        self,
        *,
        model: str,
        prompt: str,
        attachments: list[dict[str, Any]] | None = None,
        reasoning_effort: str | None = None,
    ) -> tuple[str, dict[str, str], dict[str, Any]]:
        content: list[dict[str, Any]] = [{"type": "text", "text": prompt}]
        for attachment in attachments or []:
            mime_type = str(attachment.get("mimeType") or "").strip()
            data = base64.b64encode(bytes(attachment.get("contentBytes") or b"")).decode("ascii")
            if mime_type.startswith("image/"):
                content.append(
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": mime_type,
                            "data": data,
                        },
                    }
                )
            else:
                content.append(
                    {
                        "type": "document",
                        "source": {
                            "type": "base64",
                            "media_type": mime_type,
                            "data": data,
                        },
                    }
                )
        payload: dict[str, Any] = {
            "model": model,
            "max_tokens": 4096,
            "messages": [
                {
                    "role": "user",
                    "content": content if attachments else prompt,
                }
            ],
        }
        if reasoning_effort:
            payload["output_config"] = {"effort": reasoning_effort}
        return (
            "/v1/messages",
            {
                "x-api-key": str(self.api_key or ""),
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json",
            },
            payload,
        )

    def extract_assistant_text(self, payload: dict[str, Any]) -> str:
        content = payload.get("content")
        texts = [
            str(item.get("text") or "").strip()
            for item in content if isinstance(item, dict)
            if str(item.get("type") or "").strip() == "text"
        ] if isinstance(content, list) else []
        return "\n".join(text for text in texts if text)
