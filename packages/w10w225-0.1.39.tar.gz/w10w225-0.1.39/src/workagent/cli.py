from __future__ import annotations

import argparse
import asyncio
import json
import shutil
import subprocess
import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Protocol

import uvicorn
from sqlalchemy import select

from workagent.app.server import create_app
from workagent.config.installation import (
    ensure_agent_secret,
    ensure_installation_id,
    load_agent_secret,
    load_installation_id,
)
from workagent.config.models import (
    AppConfig,
    ClaudeCliSettings,
    CodexCliSettings,
    ConnectorConfig,
    CopilotCliSettings,
    EngineName,
    EngineSettings,
    GeminiCliSettings,
    LauncherLanguage,
    LocalSettings,
    Platform,
    ProviderApiSettings,
    WatchProfile,
    WatchProfilePreset,
)
from workagent.config.store import ConfigStore, default_config_paths
from workagent.connectors import HttpConnectorValidator, ValidationResult
from workagent.daemon.process import DaemonController, DaemonStatus
from workagent.db.models import AppSetting, Case, ScheduledJob
from workagent.db.session import create_engine_and_session_factory, initialize_database
from workagent.executors import get_engine_capability_metadata
from workagent.runtime.factory import build_daemon_runtime_bundle
from workagent.runtime.process_env import build_codex_env_overrides
from workagent.runtime.secrets import SecretStore, build_default_secret_store
from workagent.runtime.ui import Choice, MenuOption, QuestionaryUI, UIBackend
from workagent.runtime_logging import build_uvicorn_log_config, cleanup_runtime_log_files, resolve_daily_log_file
from workagent.scheduler import SchedulerRuntime, SqlAlchemySchedulerJobRepository
from workagent.services import sync_config_credentials_to_db
from workagent.services.audit import AuditService
from workagent.services.credentials import set_connector_enabled
from workagent.sync.factory import build_review_sync_client_from_env

PLATFORM_LABELS: dict[Platform, str] = {
    Platform.SLACK: "Slack",
    Platform.JIRA: "JIRA",
    Platform.CONFLUENCE: "Confluence",
    Platform.GITLAB: "GitLab",
}

ENGINE_LABELS: dict[EngineName, str] = {
    EngineName.codex_cli: "Codex CLI",
    EngineName.copilot_cli: "GitHub Copilot CLI",
    EngineName.claude_cli: "Claude CLI (Claude Code)",
    EngineName.gemini_cli: "Gemini CLI (Google)",
    EngineName.openai_api: "OpenAI API",
    EngineName.anthropic_api: "Anthropic API",
    EngineName.gemini_api: "Gemini API",
}

WIZARD_ENGINE_CHOICES: tuple[EngineName, ...] = (
    EngineName.codex_cli,
    EngineName.copilot_cli,
    EngineName.claude_cli,
    EngineName.gemini_cli,
)

COPILOT_MODEL_CHOICES = ["claude-sonnet-4.5", "claude-opus-4.6", "gpt-5.2-codex"]
CLAUDE_CLI_MODEL_CHOICES = ["claude-sonnet-4-6", "claude-opus-4-6", "claude-haiku-4-5"]
GEMINI_CLI_MODEL_CHOICES = ["gemini-2.5-pro", "gemini-2.5-flash"]
OPENAI_MODEL_CHOICES = ["gpt-5.4", "gpt-5.4-mini", "gpt-5.4-nano"]
ANTHROPIC_MODEL_CHOICES = ["claude-sonnet-4-6", "claude-opus-4-6", "claude-haiku-4-5"]
GEMINI_MODEL_CHOICES = ["gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.5-flash-lite"]
CODEX_REASONING_EFFORT_CHOICES = ["low", "medium", "high", "xhigh"]

TRANSLATIONS: dict[LauncherLanguage, dict[str, str]] = {
    LauncherLanguage.en: {
        "background_started": "Background daemon started.",
        "background_restarted": "Background daemon restarted.",
        "background_stopped": "Background daemon stopped.",
        "background_stop_failed": "Failed to stop background daemon.",
        "change_language": "Change Language",
        "choose_action": "Choose an action",
        "choose_engine": "Choose an execution engine",
        "choose_language": "Choose a language",
        "codex_auth_mode": "Codex auth mode",
        "codex_cli_command": "Codex CLI command",
        "codex_code_model": "Codex model (code tasks, use default to inherit)",
        "codex_code_model_custom": "Custom code model",
        "codex_model": "Codex model (general tasks)",
        "codex_model_custom": "Custom Codex model",
        "codex_profile": "Codex profile",
        "codex_reasoning_effort": "Codex reasoning effort",
        "copilot_auth_mode": "Copilot auth mode",
        "copilot_cli_command": "Copilot CLI command",
        "copilot_model": "Copilot model",
        "copilot_model_custom": "Custom Copilot model",
        "credentials_footer": "Register this Installation ID in nk304, then use the pairing code to connect.",
        "credentials_title": "w10w225 Local Agent Info",
        "credentials_connected": "Connected",
        "credentials_not_connected": "Not connected — run 'w10w225 reconnect' or pair from nk304",
        "wizard_complete": "Settings saved.",
        "current_value": "Keep Current ({value})",
        "daemon_status": "Daemon Status: {status}",
        "default_execution_settings": "Default Execution Settings",
        "engine_label": "engine",
        "directory_added": "Added: {path}",
        "directory_missing": "Warning: '{path}' does not exist. Adding it anyway.",
        "directory_prompt": "Directory path (press Enter to finish):",
        "disabled": "disabled",
        "enabled": "enabled",
        "exit": "Exit",
        "gemini_auth_info": (
            "Gemini CLI authentication uses the GEMINI_API_KEY environment variable "
            "or Google Cloud ADC (Application Default Credentials)."
        ),
        "gemini_cli_command": "Gemini CLI command",
        "gemini_model": "Gemini CLI model",
        "gemini_model_custom": "Custom Gemini CLI model",
        "github_token": "GitHub token",
        "installation_register_hint": (
            "Register this in w10w225 Assistant Settings > Local Agent and configure platform connections."
        ),
        "keep_workspace_dirs": "Keep existing workspace directories? (y/n)",
        "language_changed": "Launcher language changed to {language_label}.",
        "language_english": "English",
        "language_korean": "한국어",
        "local_agent_status": "Local Agent Status",
        "local_settings_hint": (
            "Local environment settings can be edited in ~/.personal-work-agent/config.toml:\n"
            "  [local]\n"
            "  workspace_dirs = [\"/home/user/code/my-project\"]"
        ),
        "minutes": "{minutes} min",
        "model_label": "model",
        "next_run_at": "next_run_at",
        "none": "none",
        "no_scheduled_tasks": "Scheduled Tasks: none",
        "not_calculated": "not calculated",
        "not_set": "not set",
        "reconfigure": "Reconfigure",
        "registration": "Connection Info",
        "saved_and_running": "Settings saved. Background daemon is running.",
        "scheduled_tasks": "Scheduled Tasks: {count}",
        "show_status": "Status",
        "source": "source",
        "reasoning_label": "reasoning",
        "start_background": "Start Background",
        "stop_background": "Stop Running Background Process",
        "switch_code_task_model": (
            "Code-task model/reasoning settings. The agent switches automatically for code work."
        ),
        "task": "task",
        "task_id": "taskId",
        "task_model_label": "task model",
        "task_reasoning_label": "task reasoning",
        "use_default": "Use Default",
        "use_remote_default": "use remote default",
        "workspace_current": "Current workspace directories:\n{directories}",
        "workspace_none": "No workspace directories configured",
        "workspace_setup": (
            "Workspace directory setup\n"
            "Enter directories the agent may read and modify locally.\n"
            "Example: /home/user/code/my-project\n"
            "You can update this later in config.toml under [local]."
        ),
        "workspace_summary": "Workspace directories: {directories}",
        "workspace_summary_none": "No workspace directories configured",
        "workspace_list_prompt": "Enter additional directories one per line. Leave blank to finish.",
        "api_key": "{engine_label} API key",
        "api_base_url": "{engine_label} base URL",
        "api_model": "{engine_label} model",
        "api_custom_model": "Custom {engine_label} model",
        "custom_input": "Custom Input",
        "attachment_cache": "Attachment Cache",
        "attachment_cache_failed_reasons": "failed reasons",
        "attachment_cache_failed_label": "failed",
        "attachment_cache_pending_label": "pending",
        "attachment_cache_ready_label": "ready",
        "extraction_cache": "Extraction Cache",
        "extraction_cache_failed_reasons": "failed reasons",
        "extraction_cache_failed_label": "failed",
        "extraction_cache_pending_label": "pending",
        "extraction_cache_ready_label": "ready",
        "extraction_cache_skipped_label": "skipped",
        "extraction_cache_repeated_failures": "repeated failures",
        "attachment_troubleshooting": "Attachment Troubleshooting",
        "attachment_troubleshooting_cache_corruption": (
            "cache corruption: clear the affected local attachment cache entry and retry the request"
        ),
        "attachment_troubleshooting_large_pdf": (
            "large PDF rejection: switch to an API engine or reduce PDF size/page count"
        ),
        "attachment_troubleshooting_archive_large": (
            "archive too large: reduce archive size or number of entries before retrying"
        ),
        "attachment_troubleshooting_office_parse": (
            "office parse failure: export the document to txt or pdf if parsing keeps failing"
        ),
        "attachment_troubleshooting_extractor_dependency": (
            "extractor missing dependency: use a simpler file format or install the required local parser support"
        ),
        "attachment_troubleshooting_transcript": (
            "transcript unavailable: audio/video currently falls back to metadata only unless a transcript path is added"
        ),
        "attachment_troubleshooting_stale_url": (
            "stale artifact URL: retry the request or re-upload the file if artifact fetch auth expired"
        ),
        "attachment_troubleshooting_unsupported_engine": (
            "unsupported engine: some CLI engines fall back to metadata-only attachment handling"
        ),
        "interval": "interval",
        "cron": "cron",
        "restart_background": "Restart Background",
        "reconnect": "Reconnect to Server",
        "pairing_intro": (
            "Your Installation ID: {installation_id}\n\n"
            "1. Register this ID in nk304 Assistant Settings > Local Agent\n"
            "2. Click 'Pairing' to get a 6-character code\n"
            "3. Enter the code below"
        ),
        "pairing_prompt": "Pairing code",
        "pairing_success": "Pairing successful! Connection verified.",
        "pairing_failed": "Pairing failed: {error}",
        "already_paired": "Already paired. Use 'Reconnect' to re-pair.",
        "claude_cli_command": "Claude CLI command",
        "claude_model": "Claude CLI model",
        "claude_model_custom": "Custom Claude CLI model",
    },
    LauncherLanguage.ko: {
        "all_commands": "모든 커맨드 (차단 목록 제외)",
        "background_started": "백그라운드 데몬을 시작했습니다.",
        "background_restarted": "백그라운드 데몬을 다시 시작했습니다.",
        "background_stopped": "백그라운드 데몬을 중지했습니다.",
        "background_stop_failed": "백그라운드 데몬을 중지하지 못했습니다.",
        "change_language": "언어 변경",
        "choose_action": "작업을 선택하세요",
        "choose_engine": "실행 엔진을 선택하세요",
        "choose_language": "언어를 선택하세요",
        "codex_auth_mode": "Codex 인증 방식",
        "codex_cli_command": "Codex CLI command",
        "codex_code_model": "코드 태스크용 Codex model (기본값 사용 시 일반 모델 상속)",
        "codex_code_model_custom": "커스텀 코드 모델",
        "codex_model": "Codex model (일반 태스크용)",
        "codex_model_custom": "커스텀 Codex 모델",
        "codex_profile": "Codex profile",
        "codex_reasoning_effort": "Codex reasoning effort",
        "command_policy": "커맨드 정책",
        "copilot_auth_mode": "Copilot 인증 방식",
        "copilot_cli_command": "Copilot CLI command",
        "copilot_model": "Copilot model",
        "copilot_model_custom": "커스텀 Copilot 모델",
        "credentials_footer": "이 Installation ID를 nk304에 등록한 후, 페어링 코드로 연결하세요.",
        "credentials_title": "w10w225 Local Agent 정보",
        "credentials_connected": "연결됨",
        "credentials_not_connected": "미연결 — 'w10w225 reconnect' 또는 nk304에서 페어링하세요",
        "wizard_complete": "설정이 저장되었습니다.",
        "current_value": "현재값 유지 ({value})",
        "daemon_status": "데몬 상태: {status}",
        "default_execution_settings": "기본 실행 설정",
        "engine_label": "engine",
        "directory_added": "추가됨: {path}",
        "directory_missing": "경고: '{path}' 디렉토리가 존재하지 않습니다. 그래도 추가합니다.",
        "directory_prompt": "디렉토리 경로 (완료시 Enter):",
        "disabled": "비활성",
        "enabled": "활성",
        "exit": "종료",
        "gemini_auth_info": (
            "Gemini CLI 인증: GEMINI_API_KEY 환경변수 또는 Google Cloud ADC(Application Default "
            "Credentials)를 사용합니다."
        ),
        "gemini_cli_command": "Gemini CLI command",
        "gemini_model": "Gemini CLI model",
        "gemini_model_custom": "커스텀 Gemini CLI 모델",
        "github_token": "GitHub token",
        "installation_register_hint": (
            "w10w225 Assistant Settings에서 Local Agent Installation ID를 저장하고 플랫폼 연결을 설정하세요."
        ),
        "keep_workspace_dirs": "기존 워크스페이스 디렉토리를 유지하시겠습니까? (y/n)",
        "language_changed": "언어가 {language_label}로 변경되었습니다.",
        "language_english": "English",
        "language_korean": "한국어",
        "local_agent_status": "로컬 에이전트 상태",
        "local_settings_hint": (
            "로컬 환경 설정은 ~/.personal-work-agent/config.toml의 [local] 섹션에서 수정할 수 있습니다:\n"
            "  [local]\n"
            "  workspace_dirs = [\"/home/user/code/my-project\"]"
        ),
        "minutes": "{minutes}분",
        "model_label": "model",
        "next_run_at": "next_run_at",
        "none": "없음",
        "no_scheduled_tasks": "정기 태스크 등록: 없음",
        "not_calculated": "미계산",
        "not_set": "미설정",
        "reconfigure": "설정 다시 하기",
        "registration": "연결 정보 확인",
        "saved_and_running": "설정이 저장되었고 백그라운드 데몬이 실행 중입니다.",
        "scheduled_tasks": "정기 태스크 등록: {count}개",
        "show_status": "상태 보기",
        "source": "source",
        "reasoning_label": "reasoning",
        "start_background": "백그라운드 시작",
        "stop_background": "실행 중인 백그라운드 프로세스 끄기",
        "switch_code_task_model": "코드 수정 태스크용 모델/reasoning 설정 (LLM이 코드 작업으로 판단 시 자동 전환됩니다)",
        "task": "task",
        "task_id": "taskId",
        "task_model_label": "task model",
        "task_reasoning_label": "task reasoning",
        "use_default": "기본값 사용",
        "use_remote_default": "원격 기본값 사용",
        "workspace_current": "현재 워크스페이스 디렉토리:\n{directories}",
        "workspace_none": "워크스페이스 미설정",
        "workspace_setup": (
            "워크스페이스 디렉토리 설정\n"
            "에이전트가 로컬 소스코드를 읽고 수정할 수 있는 디렉토리를 입력하세요.\n"
            "예: /home/user/code/my-project\n"
            "나중에 config.toml의 [local] 섹션에서도 수정할 수 있습니다."
        ),
        "workspace_summary": "워크스페이스 디렉토리: {directories}",
        "workspace_summary_none": "워크스페이스 미설정",
        "workspace_list_prompt": "추가할 디렉토리를 한 줄씩 입력하세요. 빈 줄을 입력하면 완료됩니다.",
        "api_key": "{engine_label} API key",
        "api_base_url": "{engine_label} base URL",
        "api_model": "{engine_label} model",
        "api_custom_model": "커스텀 {engine_label} 모델",
        "custom_input": "직접 입력",
        "attachment_cache": "첨부 캐시",
        "attachment_cache_failed_reasons": "실패 사유",
        "attachment_cache_failed_label": "failed",
        "attachment_cache_pending_label": "pending",
        "attachment_cache_ready_label": "ready",
        "extraction_cache": "추출 캐시",
        "extraction_cache_failed_reasons": "실패 사유",
        "extraction_cache_failed_label": "failed",
        "extraction_cache_pending_label": "pending",
        "extraction_cache_ready_label": "ready",
        "extraction_cache_skipped_label": "skipped",
        "extraction_cache_repeated_failures": "반복 실패",
        "attachment_troubleshooting": "첨부 트러블슈팅",
        "attachment_troubleshooting_cache_corruption": (
            "cache corruption: 문제가 있는 로컬 첨부 캐시를 지우고 요청을 다시 실행하세요"
        ),
        "attachment_troubleshooting_large_pdf": (
            "large PDF rejection: API 엔진으로 전환하거나 PDF 크기/페이지 수를 줄이세요"
        ),
        "attachment_troubleshooting_archive_large": (
            "archive too large: 압축 파일 크기나 엔트리 수를 줄인 뒤 다시 시도하세요"
        ),
        "attachment_troubleshooting_office_parse": (
            "office parse failure: 계속 실패하면 문서를 txt 또는 pdf로 내보내 다시 시도하세요"
        ),
        "attachment_troubleshooting_extractor_dependency": (
            "extractor missing dependency: 더 단순한 파일 형식을 쓰거나 필요한 로컬 파서를 설치하세요"
        ),
        "attachment_troubleshooting_transcript": (
            "transcript unavailable: 오디오/비디오는 transcript 경로가 추가되기 전까지 메타데이터 fallback만 사용합니다"
        ),
        "attachment_troubleshooting_stale_url": (
            "stale artifact URL: 첨부 fetch 인증이 만료됐으면 요청을 다시 시도하거나 파일을 재업로드하세요"
        ),
        "attachment_troubleshooting_unsupported_engine": (
            "unsupported engine: 일부 CLI 엔진은 첨부를 메타데이터 기반 fallback으로만 처리합니다"
        ),
        "interval": "interval",
        "cron": "cron",
        "restart_background": "백그라운드 다시 시작",
        "reconnect": "서버 재접속",
        "pairing_intro": (
            "Installation ID: {installation_id}\n\n"
            "1. nk304 어시스턴트 설정 > 로컬 에이전트에서 이 ID를 등록하세요\n"
            "2. '페어링' 버튼을 눌러 6자리 코드를 확인하세요\n"
            "3. 아래에 코드를 입력하세요"
        ),
        "pairing_prompt": "페어링 코드",
        "pairing_success": "페어링 성공! 연결이 확인되었습니다.",
        "pairing_failed": "페어링 실패: {error}",
        "already_paired": "이미 페어링되어 있습니다. '서버 재접속'으로 다시 페어링할 수 있습니다.",
        "claude_cli_command": "Claude CLI command",
        "claude_model": "Claude CLI model",
        "claude_model_custom": "커스텀 Claude CLI 모델",
    },
}


class ConnectorValidator(Protocol):
    def validate(self, platform: Platform, base_url: str, secret: str) -> ValidationResult | None: ...


@dataclass(frozen=True, slots=True)
class LauncherContext:
    store: ConfigStore
    secrets: SecretStore
    ui: UIBackend
    validator: ConnectorValidator
    daemon: DaemonController


def _coerce_launcher_language(language: LauncherLanguage | str | None) -> LauncherLanguage:
    if isinstance(language, LauncherLanguage):
        return language
    try:
        return LauncherLanguage(str(language or LauncherLanguage.en.value))
    except ValueError:
        return LauncherLanguage.en


def _current_launcher_language(config: AppConfig | None) -> LauncherLanguage:
    if config is None:
        return LauncherLanguage.en
    return _coerce_launcher_language(config.local.launcher_language)


def _t(language: LauncherLanguage | str | None, key: str, **kwargs: object) -> str:
    resolved = _coerce_launcher_language(language)
    template = TRANSLATIONS[resolved][key]
    return template.format(**kwargs)


def _language_label(option: LauncherLanguage | str, *, display_language: LauncherLanguage | str | None = None) -> str:
    resolved_option = _coerce_launcher_language(option)
    resolved_display = _coerce_launcher_language(display_language)
    key = "language_english" if resolved_option is LauncherLanguage.en else "language_korean"
    return _t(resolved_display, key)


def _format_interval_label(language: LauncherLanguage | str | None, interval_minutes: object) -> str:
    if str(interval_minutes).isdigit():
        return _t(language, "minutes", minutes=int(interval_minutes))
    return _t(language, "not_set")


def _format_status_datetime(language: LauncherLanguage | str | None, value: datetime | None) -> str:
    if value is None:
        return _t(language, "not_calculated")
    normalized = value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)
    return f"{normalized.isoformat(timespec='seconds')} UTC"


def _build_credentials_message(
    language: LauncherLanguage | str | None,
    *,
    installation_id: str,
    agent_secret: str,
) -> str:
    has_secret = bool(agent_secret and agent_secret.strip())
    status = _t(language, "credentials_connected") if has_secret else _t(language, "credentials_not_connected")
    return (
        f"\n{_t(language, 'credentials_title')}\n"
        f"{'─' * 50}\n"
        f"Installation ID : {installation_id}\n"
        f"Status          : {status}\n"
        f"{'─' * 50}\n"
        f"{_t(language, 'credentials_footer')}"
    )


async def _build_status_report_async(context: LauncherContext) -> str:
    config = context.store.load() or AppConfig()
    language = _current_launcher_language(config)
    daemon_status = context.daemon.status().value
    db_path = context.store.paths.data_dir / "app.db"
    scheduled_jobs = []
    execution_defaults_row = None
    attachment_status_counts = {"ready": 0, "pending": 0, "failed": 0}
    attachment_error_counts: dict[str, int] = {}
    extraction_status_counts = {"ready": 0, "pending": 0, "failed": 0, "skipped": 0}
    extraction_error_counts: dict[str, int] = {}
    repeated_extraction_failures: dict[str, int] = {}

    if db_path.exists():
        engine, session_factory = create_engine_and_session_factory(context.store.paths)
        try:
            await initialize_database(engine)
            async with session_factory() as session:
                scheduled_jobs = (
                    await session.execute(
                        select(ScheduledJob)
                        .where(ScheduledJob.name.like("scheduled_task_%"))
                        .order_by(ScheduledJob.name.asc())
                    )
                ).scalars().all()
                execution_defaults_row = await session.get(AppSetting, "agent_execution_defaults")
                case_rows = (await session.execute(select(Case))).scalars().all()
                for case_row in case_rows:
                    payload_json = case_row.payload_json if isinstance(case_row.payload_json, dict) else {}
                    local_artifacts = payload_json.get("localArtifactsById")
                    if not isinstance(local_artifacts, dict):
                        continue
                    for entry in local_artifacts.values():
                        if not isinstance(entry, dict):
                            continue
                        status = str(entry.get("downloadStatus") or "").strip() or "pending"
                        if status not in attachment_status_counts:
                            status = "pending"
                        attachment_status_counts[status] += 1
                        error_code = str(entry.get("errorCode") or "").strip()
                        if error_code:
                            attachment_error_counts[error_code] = attachment_error_counts.get(error_code, 0) + 1
                        extraction_status = str(entry.get("extractionStatus") or "").strip()
                        if extraction_status:
                            if extraction_status not in extraction_status_counts:
                                extraction_status = "pending"
                            extraction_status_counts[extraction_status] += 1
                        extraction_error_code = str(entry.get("extractErrorCode") or "").strip()
                        if extraction_error_code:
                            extraction_error_counts[extraction_error_code] = (
                                extraction_error_counts.get(extraction_error_code, 0) + 1
                            )
        finally:
            await engine.dispose()

    repeated_extraction_failures = {
        error_code: count for error_code, count in extraction_error_counts.items() if count > 1
    }

    lines = [
        _t(language, "local_agent_status"),
        f"{'─' * 50}",
        _t(language, "daemon_status", status=daemon_status),
        "",
    ]

    execution_defaults_payload = dict(execution_defaults_row.value_json or {}) if execution_defaults_row is not None else {}
    default_engine = str(execution_defaults_payload.get("engine") or "").strip() or _t(language, "not_set")
    default_model = str(execution_defaults_payload.get("model") or "").strip() or _t(language, "not_set")
    default_reasoning = str(execution_defaults_payload.get("reasoningEffort") or "").strip() or _t(language, "not_set")
    lines.extend(
        [
            _t(language, "default_execution_settings"),
            f"- {_t(language, 'engine_label')}: {default_engine}",
            f"- {_t(language, 'model_label')}: {default_model}",
            f"- {_t(language, 'reasoning_label')}: {default_reasoning}",
            "",
        ]
    )

    if scheduled_jobs:
        visible_jobs = [row for row in scheduled_jobs if row.is_enabled]
        if visible_jobs:
            lines.append(_t(language, "scheduled_tasks", count=len(visible_jobs)))
        else:
            lines.append(_t(language, "no_scheduled_tasks"))
        for row in visible_jobs:
            payload = row.payload_json or {}
            task_id = str(payload.get("taskId") or "-")
            task_text = str(payload.get("taskText") or _t(language, "none"))
            interval_minutes = payload.get("intervalMinutes")
            task_model = str(payload.get("model") or "").strip() or _t(language, "use_remote_default")
            task_reasoning = str(payload.get("reasoningEffort") or "").strip() or _t(language, "use_remote_default")
            interval_label = _format_interval_label(language, interval_minutes)
            next_run_at = _format_status_datetime(language, row.next_run_at)
            enabled_label = _t(language, "enabled") if row.is_enabled else _t(language, "disabled")
            lines.extend(
                [
                    f"- {row.name} [{enabled_label}]",
                    f"  {_t(language, 'task_id')}: {task_id}",
                    f"  {_t(language, 'task')}: {task_text}",
                    f"  {_t(language, 'interval')}: {interval_label}",
                    f"  {_t(language, 'task_model_label')}: {task_model}",
                    f"  {_t(language, 'task_reasoning_label')}: {task_reasoning}",
                    f"  {_t(language, 'cron')}: {row.cron_expression}",
                    f"  {_t(language, 'next_run_at')}: {next_run_at}",
                ]
            )
    else:
        lines.append(_t(language, "no_scheduled_tasks"))

    lines.extend(
        [
            "",
            _t(language, "attachment_cache"),
            f"- {_t(language, 'attachment_cache_ready_label')}: {attachment_status_counts['ready']}",
            f"- {_t(language, 'attachment_cache_pending_label')}: {attachment_status_counts['pending']}",
            f"- {_t(language, 'attachment_cache_failed_label')}: {attachment_status_counts['failed']}",
            (
                f"- {_t(language, 'attachment_cache_failed_reasons')}: "
                + ", ".join(
                    f"{error_code}={count}"
                    for error_code, count in sorted(attachment_error_counts.items())
                )
                if attachment_error_counts
                else f"- {_t(language, 'attachment_cache_failed_reasons')}: {_t(language, 'none')}"
            ),
            "",
            _t(language, "extraction_cache"),
            f"- {_t(language, 'extraction_cache_ready_label')}: {extraction_status_counts['ready']}",
            f"- {_t(language, 'extraction_cache_pending_label')}: {extraction_status_counts['pending']}",
            f"- {_t(language, 'extraction_cache_skipped_label')}: {extraction_status_counts['skipped']}",
            f"- {_t(language, 'extraction_cache_failed_label')}: {extraction_status_counts['failed']}",
            (
                f"- {_t(language, 'extraction_cache_failed_reasons')}: "
                + ", ".join(
                    f"{error_code}={count}"
                    for error_code, count in sorted(extraction_error_counts.items())
                )
                if extraction_error_counts
                else f"- {_t(language, 'extraction_cache_failed_reasons')}: {_t(language, 'none')}"
            ),
            (
                f"- {_t(language, 'extraction_cache_repeated_failures')}: "
                + ", ".join(
                    f"{error_code}={count}"
                    for error_code, count in sorted(repeated_extraction_failures.items())
                )
                if repeated_extraction_failures
                else f"- {_t(language, 'extraction_cache_repeated_failures')}: {_t(language, 'none')}"
            ),
            "",
            _t(language, "attachment_troubleshooting"),
            f"- {_t(language, 'attachment_troubleshooting_unsupported_engine')}",
            f"- {_t(language, 'attachment_troubleshooting_stale_url')}",
            f"- {_t(language, 'attachment_troubleshooting_large_pdf')}",
            f"- {_t(language, 'attachment_troubleshooting_archive_large')}",
            f"- {_t(language, 'attachment_troubleshooting_office_parse')}",
            f"- {_t(language, 'attachment_troubleshooting_extractor_dependency')}",
            f"- {_t(language, 'attachment_troubleshooting_transcript')}",
            f"- {_t(language, 'attachment_troubleshooting_cache_corruption')}",
        ]
    )
    return "\n".join(lines)


def _build_status_report(context: LauncherContext) -> str:
    return asyncio.run(_build_status_report_async(context))


def build_platform_choices(existing: AppConfig | None = None) -> list[Choice]:
    selected = set(existing.connectors.keys()) if existing is not None else set()
    return [
        Choice(label=label, value=platform.value, checked=platform.value in selected)
        for platform, label in PLATFORM_LABELS.items()
    ]


def build_launcher_menu(
    status: DaemonStatus,
    language: LauncherLanguage | str | None = LauncherLanguage.en,
) -> list[MenuOption]:
    if status == DaemonStatus.RUNNING:
        return [
            MenuOption(_t(language, "restart_background"), "restart"),
            MenuOption(_t(language, "stop_background"), "stop"),
            MenuOption(_t(language, "reconnect"), "reconnect"),
            MenuOption(_t(language, "registration"), "show_credentials"),
            MenuOption(_t(language, "show_status"), "status"),
            MenuOption(_t(language, "change_language"), "change_language"),
            MenuOption(_t(language, "exit"), "exit"),
        ]
    return [
        MenuOption(_t(language, "start_background"), "start"),
        MenuOption(_t(language, "reconnect"), "reconnect"),
        MenuOption(_t(language, "registration"), "show_credentials"),
        MenuOption(_t(language, "show_status"), "status"),
        MenuOption(_t(language, "change_language"), "change_language"),
        MenuOption(_t(language, "exit"), "exit"),
    ]


def _secret_key_for(platform: Platform) -> str:
    return f"platform:{platform.value}:api_token"


def _collect_connector_config(
    *,
    ui: UIBackend,
    validator: ConnectorValidator,
    platform: Platform,
    existing: ConnectorConfig | None = None,
) -> tuple[ConnectorConfig, str]:
    base_url = ui.ask_text(
        f"{PLATFORM_LABELS[platform]} base URL",
        default=existing.base_url if existing else None,
    ).strip()
    secret = ui.ask_text(f"{PLATFORM_LABELS[platform]} API key/token", secret=True).strip()
    validation = validator.validate(platform, base_url, secret)
    return ConnectorConfig(base_url=base_url, secret_key=_secret_key_for(platform)), secret, validation


def _collect_workspace_dirs(
    *,
    ui: UIBackend,
    existing: list[str],
    language: LauncherLanguage | str | None,
) -> list[str]:
    import os

    if existing:
        ui.show_message(_t(language, "workspace_current", directories="\n".join(f"  {i + 1}. {d}" for i, d in enumerate(existing))))
    else:
        ui.show_message(_t(language, "workspace_setup"))
    keep = ui.ask_text(
        _t(language, "keep_workspace_dirs"),
        default="y" if existing else "n",
    ).strip().lower()
    dirs: list[str] = list(existing) if keep != "n" else []
    ui.show_message(_t(language, "workspace_list_prompt"))
    while True:
        raw = ui.ask_text(_t(language, "directory_prompt"), default="").strip()
        if not raw:
            break
        expanded = os.path.expanduser(raw)
        abs_path = os.path.abspath(expanded)
        if not os.path.isdir(abs_path):
            ui.show_message(_t(language, "directory_missing", path=abs_path))
        if abs_path not in dirs:
            dirs.append(abs_path)
            ui.show_message(_t(language, "directory_added", path=abs_path))
    return dirs


def _collect_codex_cli_settings(
    *,
    ui: UIBackend,
    language: LauncherLanguage | str | None,
    existing: CodexCliSettings | None = None,
) -> CodexCliSettings:
    current = existing or CodexCliSettings()
    command = ui.ask_text(_t(language, "codex_cli_command"), default=current.command).strip() or current.command
    model = _choose_model(
        ui=ui,
        language=language,
        prompt=_t(language, "codex_model"),
        suggested_models=get_engine_capability_metadata("codex_cli").suggested_models,
        current_model=current.model,
        custom_prompt=_t(language, "codex_model_custom"),
    )
    reasoning_effort = _choose_codex_reasoning_effort(
        ui=ui,
        language=language,
        current_reasoning_effort=current.reasoning_effort,
    )
    ui.show_message(_t(language, "switch_code_task_model"))
    model_code = _choose_model(
        ui=ui,
        language=language,
        prompt=_t(language, "codex_code_model"),
        suggested_models=get_engine_capability_metadata("codex_cli").suggested_models,
        current_model=current.model_code,
        custom_prompt=_t(language, "codex_code_model_custom"),
    )
    reasoning_effort_code = _choose_codex_reasoning_effort(
        ui=ui,
        language=language,
        current_reasoning_effort=current.reasoning_effort_code or "xhigh",
    )
    profile = ui.ask_text(_t(language, "codex_profile"), default=current.profile or "").strip() or None
    auth_mode_raw = ui.ask_text(_t(language, "codex_auth_mode"), default=current.auth_mode.value).strip() or current.auth_mode.value
    return CodexCliSettings(
        command=command,
        model=model,
        profile=profile,
        reasoningEffort=reasoning_effort,
        modelCode=model_code,
        reasoningEffortCode=reasoning_effort_code,
        authMode=auth_mode_raw,
    )


def _collect_copilot_cli_settings(
    *,
    ui: UIBackend,
    secrets: SecretStore,
    language: LauncherLanguage | str | None,
    existing: CopilotCliSettings | None = None,
) -> CopilotCliSettings:
    current = existing or CopilotCliSettings()
    command = ui.ask_text(_t(language, "copilot_cli_command"), default=current.command).strip() or current.command
    model = _choose_model(
        ui=ui,
        language=language,
        prompt=_t(language, "copilot_model"),
        suggested_models=COPILOT_MODEL_CHOICES,
        current_model=current.model,
        custom_prompt=_t(language, "copilot_model_custom"),
    )
    auth_mode_raw = ui.ask_text(_t(language, "copilot_auth_mode"), default=current.auth_mode.value).strip() or current.auth_mode.value
    if auth_mode_raw == "github_token":
        token = ui.ask_text(_t(language, "github_token"), secret=True).strip()
        if token:
            secrets.save(_copilot_secret_key(), token)
    return CopilotCliSettings(
        command=command,
        model=model,
        authMode=auth_mode_raw,
    )


def _collect_claude_cli_settings(
    *,
    ui: UIBackend,
    language: LauncherLanguage | str | None,
    existing: ClaudeCliSettings | None = None,
) -> ClaudeCliSettings:
    current = existing or ClaudeCliSettings()
    command = ui.ask_text(_t(language, "claude_cli_command"), default=current.command).strip() or current.command
    model = _choose_model(
        ui=ui,
        language=language,
        prompt=_t(language, "claude_model"),
        suggested_models=CLAUDE_CLI_MODEL_CHOICES,
        current_model=current.model,
        custom_prompt=_t(language, "claude_model_custom"),
    )
    return ClaudeCliSettings(command=command, model=model)


def _collect_gemini_cli_settings(
    *,
    ui: UIBackend,
    language: LauncherLanguage | str | None,
    existing: GeminiCliSettings | None = None,
) -> GeminiCliSettings:
    current = existing or GeminiCliSettings()
    command = ui.ask_text(_t(language, "gemini_cli_command"), default=current.command).strip() or current.command
    model = _choose_model(
        ui=ui,
        language=language,
        prompt=_t(language, "gemini_model"),
        suggested_models=GEMINI_CLI_MODEL_CHOICES,
        current_model=current.model,
        custom_prompt=_t(language, "gemini_model_custom"),
    )
    ui.show_message(_t(language, "gemini_auth_info"))
    return GeminiCliSettings(command=command, model=model)


def _collect_api_engine_settings(
    *,
    ui: UIBackend,
    secrets: SecretStore,
    engine_name: EngineName,
    language: LauncherLanguage | str | None,
    existing: ProviderApiSettings,
) -> ProviderApiSettings:
    suggested_models = {
        EngineName.openai_api: OPENAI_MODEL_CHOICES,
        EngineName.anthropic_api: ANTHROPIC_MODEL_CHOICES,
        EngineName.gemini_api: GEMINI_MODEL_CHOICES,
    }[engine_name]
    model = _choose_model(
        ui=ui,
        language=language,
        prompt=_t(language, "api_model", engine_label=ENGINE_LABELS[engine_name]),
        suggested_models=suggested_models,
        current_model=existing.model,
        custom_prompt=_t(language, "api_custom_model", engine_label=ENGINE_LABELS[engine_name]),
    ) or existing.model
    base_url = ui.ask_text(
        _t(language, "api_base_url", engine_label=ENGINE_LABELS[engine_name]),
        default=existing.base_url,
    ).strip() or existing.base_url
    api_key = ui.ask_text(_t(language, "api_key", engine_label=ENGINE_LABELS[engine_name]), secret=True).strip()
    if api_key:
        secrets.save(_api_secret_key(engine_name), api_key)
    return ProviderApiSettings(model=model, baseUrl=base_url)


def _choose_model(
    *,
    ui: UIBackend,
    language: LauncherLanguage | str | None,
    prompt: str,
    suggested_models: list[str],
    current_model: str | None,
    custom_prompt: str,
) -> str | None:
    options: list[MenuOption] = []
    if current_model and current_model not in suggested_models:
        options.append(MenuOption(_t(language, "current_value", value=current_model), current_model))
    options.extend(MenuOption(model_name, model_name) for model_name in suggested_models)
    options.append(MenuOption(_t(language, "use_default"), "__default__"))
    options.append(MenuOption(_t(language, "custom_input"), "__custom__"))
    selection = ui.choose_menu(prompt, options)
    if selection == "__default__":
        return None
    if selection == "__custom__":
        return ui.ask_text(custom_prompt, default=current_model or "").strip() or None
    return selection or current_model


def _choose_engine(
    *,
    ui: UIBackend,
    language: LauncherLanguage | str | None,
    current_engine: EngineName,
) -> EngineName:
    selection = ui.choose_menu(
        _t(language, "choose_engine"),
        [MenuOption(ENGINE_LABELS[item], item.value) for item in WIZARD_ENGINE_CHOICES],
    )
    return EngineName(selection or current_engine.value)


def _choose_codex_reasoning_effort(
    *,
    ui: UIBackend,
    language: LauncherLanguage | str | None,
    current_reasoning_effort: str | None,
) -> str:
    current = current_reasoning_effort or "medium"
    options: list[MenuOption] = []
    if current not in CODEX_REASONING_EFFORT_CHOICES:
        options.append(MenuOption(f"현재값 유지 ({current})", current))
    options.extend(
        MenuOption(
            f"{effort} (current)" if effort == current else effort,
            effort,
        )
        for effort in CODEX_REASONING_EFFORT_CHOICES
        if effort != current or current in CODEX_REASONING_EFFORT_CHOICES
    )
    selection = ui.choose_menu(_t(language, "codex_reasoning_effort"), options)
    return selection or current


def _api_secret_key(engine_name: EngineName) -> str:
    provider = engine_name.value.removesuffix("_api")
    return f"engine:{provider}:api_key"


def _copilot_secret_key() -> str:
    return "engine:copilot:github_token"


def _merge_engine_settings(
    *,
    existing: EngineSettings | None,
    default_engine: EngineName,
    codex_cli: CodexCliSettings | None = None,
    copilot_cli: CopilotCliSettings | None = None,
    claude_cli: ClaudeCliSettings | None = None,
    gemini_cli: GeminiCliSettings | None = None,
    openai_api: ProviderApiSettings | None = None,
    anthropic_api: ProviderApiSettings | None = None,
    gemini_api: ProviderApiSettings | None = None,
) -> EngineSettings:
    current = existing or EngineSettings()
    return EngineSettings(
        defaultEngine=default_engine.value,
        codexCli=(codex_cli or current.codex_cli).model_dump(mode="json", by_alias=True, exclude_none=True),
        copilotCli=(copilot_cli or current.copilot_cli).model_dump(mode="json", by_alias=True, exclude_none=True),
        claudeCli=(claude_cli or current.claude_cli).model_dump(mode="json", by_alias=True, exclude_none=True),
        geminiCli=(gemini_cli or current.gemini_cli).model_dump(mode="json", by_alias=True, exclude_none=True),
        openaiApi=(openai_api or current.openai_api).model_dump(mode="json", by_alias=True, exclude_none=True),
        anthropicApi=(anthropic_api or current.anthropic_api).model_dump(mode="json", by_alias=True, exclude_none=True),
        geminiApi=(gemini_api or current.gemini_api).model_dump(mode="json", by_alias=True, exclude_none=True),
    )


def _probe_codex_auth_status(command: str, *, home_dir: Path | None = None) -> tuple[str, str | None]:
    resolved_command = command.strip()
    if not resolved_command:
        return "command_missing", None
    command_path = shutil.which(resolved_command)
    if command_path is None:
        return "command_missing", None
    try:
        completed = subprocess.run(  # noqa: S603
            [command_path, "login", "status"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
            env=build_codex_env_overrides(home_dir) if home_dir is not None else None,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return "probe_failed", str(exc)

    detail = next(
        (
            line.strip()
            for line in [completed.stdout.strip(), completed.stderr.strip()]
            if line.strip()
        ),
        None,
    )
    if completed.returncode == 0:
        return "logged_in", detail
    if detail and "not logged in" in detail.lower():
        return "login_required", detail
    return "probe_failed", detail


def _probe_engine_auth_status(
    *,
    config: AppConfig,
    secrets: SecretStore,
    home_dir: Path | None = None,
) -> dict[str, str]:
    engine_name = config.engine.default_engine
    if engine_name is EngineName.codex_cli:
        codex_settings = config.engine.codex_cli
        status, detail = _probe_codex_auth_status(codex_settings.command, home_dir=home_dir)
        return {
            "engine": engine_name.value,
            "codex_command": codex_settings.command,
            "codex_model": codex_settings.model or "default",
            "codex_profile": codex_settings.profile or "default",
            "codex_auth_mode": codex_settings.auth_mode.value,
            "codex_auth_status": status,
            "codex_auth_detail": json.dumps(detail or ""),
        }
    if engine_name is EngineName.copilot_cli:
        settings = config.engine.copilot_cli
        auth_status = "configured" if (
            settings.auth_mode.value == "github_token" and secrets.get(_copilot_secret_key())
        ) else "external_login"
        return {
            "engine": engine_name.value,
            "copilot_command": settings.command,
            "copilot_model": settings.model or "default",
            "copilot_auth_mode": settings.auth_mode.value,
            "copilot_auth_status": auth_status,
        }
    if engine_name is EngineName.claude_cli:
        settings = config.engine.claude_cli
        return {
            "engine": engine_name.value,
            "claude_command": settings.command,
            "claude_model": settings.model or "default",
            "claude_auth_status": "available" if shutil.which(settings.command) else "command_missing",
        }
    if engine_name is EngineName.gemini_cli:
        settings = config.engine.gemini_cli
        return {
            "engine": engine_name.value,
            "gemini_command": settings.command,
            "gemini_model": settings.model or "default",
            "gemini_auth_status": "available" if shutil.which(settings.command) else "command_missing",
        }
    provider_settings = {
        EngineName.openai_api: ("openai", config.engine.openai_api),
        EngineName.anthropic_api: ("anthropic", config.engine.anthropic_api),
        EngineName.gemini_api: ("gemini", config.engine.gemini_api),
    }[engine_name]
    provider_name, settings = provider_settings
    auth_status = "configured" if secrets.get(_api_secret_key(engine_name)) else "missing"
    return {
        "engine": engine_name.value,
        f"{provider_name}_model": settings.model,
        f"{provider_name}_base_url": settings.base_url,
        f"{provider_name}_auth_status": auth_status,
    }


WATCH_SIGNAL_RULES: dict[Platform, dict[WatchProfilePreset, list[str]]] = {
    Platform.SLACK: {
        WatchProfilePreset.personal_inbox: ["dm", "mention", "thread_reply_to_me"],
        WatchProfilePreset.scoped_team_watch: ["selected_channel", "mention", "thread_reply_to_me"],
        WatchProfilePreset.custom: ["selected_channel"],
    },
    Platform.GITLAB: {
        WatchProfilePreset.personal_inbox: ["reviewer_request", "assignee", "mention"],
        WatchProfilePreset.scoped_team_watch: ["selected_project_or_group", "mention"],
        WatchProfilePreset.custom: ["selected_project_or_group"],
    },
    Platform.JIRA: {
        WatchProfilePreset.personal_inbox: ["assignee=me", "reporter=me", "watcher=me", "mentioned=me"],
        WatchProfilePreset.scoped_team_watch: ["selected_projects", "mentioned=me"],
        WatchProfilePreset.custom: ["selected_projects", "optional_jql"],
    },
    Platform.CONFLUENCE: {
        WatchProfilePreset.personal_inbox: ["recent_changes", "author", "title_keyword"],
        WatchProfilePreset.scoped_team_watch: ["selected_spaces", "label", "title_keyword"],
        WatchProfilePreset.custom: ["selected_spaces", "optional_cql"],
    },
}


def _default_watch_signals_for(platform: Platform, preset: WatchProfilePreset | str) -> list[str]:
    normalized_preset = preset if isinstance(preset, WatchProfilePreset) else WatchProfilePreset(str(preset))
    return list(WATCH_SIGNAL_RULES.get(platform, {}).get(normalized_preset, []))


def _collect_watch_profile(
    *,
    ui: UIBackend,
    platform: Platform,
    existing: WatchProfile | None = None,
    validation: ValidationResult | None = None,
) -> WatchProfile:
    preset_default = existing.preset.value if existing is not None else WatchProfilePreset.personal_inbox.value
    preset = WatchProfilePreset(
        ui.ask_text(
            f"{PLATFORM_LABELS[platform]} watch preset",
            default=preset_default,
        ).strip()
        or preset_default
    )
    scope_default = str((existing.scope or {}).get("raw") or "") if existing is not None else ""
    keywords_default = ",".join(existing.optional_keywords) if existing is not None else ""
    while True:
        scope_raw = ui.ask_text(
            f"{PLATFORM_LABELS[platform]} watch scope",
            default=scope_default,
        ).strip()
        keywords_raw = ui.ask_text(
            f"{PLATFORM_LABELS[platform]} optional keywords",
            default=keywords_default,
        ).strip()
        warning = _broad_scope_warning(platform, preset, scope_raw)
        if warning is None:
            break
        ui.show_message(warning)
        if ui.choose_menu(
            "범위가 넓습니다. 계속할까요?",
            [
                MenuOption("그대로 계속", "continue"),
                MenuOption("범위를 다시 입력", "revise"),
            ],
        ) == "continue":
            break
        scope_default = scope_raw
        keywords_default = keywords_raw
    keywords = [item.strip() for item in keywords_raw.split(",") if item.strip()]
    profile = WatchProfile(
        enabled=True,
        platform=platform,
        preset=preset,
        scope={"raw": scope_raw},
        personalSignals=_default_watch_signals_for(platform, preset),
        optionalKeywords=keywords,
    )
    ui.show_message(
        _build_watch_profile_preview(
            profile,
            identity_display=str((validation.metadata if validation is not None else {}).get("identityDisplay") or "").strip()
            or None,
        )
    )
    return profile


def _broad_scope_warning(
    platform: Platform,
    preset: WatchProfilePreset | str,
    scope_raw: str,
) -> str | None:
    resolved_preset = preset if isinstance(preset, WatchProfilePreset) else WatchProfilePreset(str(preset))
    if platform not in {Platform.JIRA, Platform.CONFLUENCE}:
        return None
    if resolved_preset == WatchProfilePreset.personal_inbox:
        return None
    normalized_scope = scope_raw.strip().lower()
    if normalized_scope and normalized_scope not in {"*", "all", "all_projects", "all_spaces"}:
        return None
    return (
        f"{PLATFORM_LABELS[platform]} watch scope is broad. "
        "It can create a large number of cases until you narrow selected projects/spaces or add a scoped filter."
    )


def _build_watch_profile_preview(
    profile_or_platform: WatchProfile | Platform,
    preset: WatchProfilePreset | str | None = None,
    *,
    scope_raw: str | None = None,
    optional_keywords: list[str] | None = None,
    identity_display: str | None = None,
) -> str:
    if isinstance(profile_or_platform, WatchProfile):
        platform = profile_or_platform.platform
        resolved_preset = profile_or_platform.preset
        resolved_scope_raw = str(profile_or_platform.scope.get("raw") or "").strip() or "default scope"
        resolved_keywords = list(profile_or_platform.optional_keywords)
    else:
        platform = profile_or_platform
        resolved_preset = preset if isinstance(preset, WatchProfilePreset) else WatchProfilePreset(str(preset))
        resolved_scope_raw = str(scope_raw or "").strip() or "default scope"
        resolved_keywords = list(optional_keywords or [])
    keywords_text = ", ".join(resolved_keywords) if resolved_keywords else "no keywords"
    signals_text = ", ".join(_default_watch_signals_for(platform, resolved_preset))
    identity_text = f", identity={identity_display}" if identity_display else ""
    return (
        f"Watch {PLATFORM_LABELS[platform]} with preset={resolved_preset.value}, "
        f"signals={signals_text}, scope={resolved_scope_raw}, keywords={keywords_text}{identity_text}."
    )


def _sync_config_metadata(context: LauncherContext, config: AppConfig) -> None:
    async def _run() -> None:
        engine, session_factory = create_engine_and_session_factory(context.store.paths)
        await initialize_database(engine)
        await sync_config_credentials_to_db(session_factory, config)
        await engine.dispose()

    asyncio.run(_run())


def run_wizard(context: LauncherContext) -> AppConfig:
    """Minimal initial setup: just create a default config. Everything else comes from nk304."""
    existing = context.store.load()
    existing_local = existing.local if existing is not None else LocalSettings()
    config = AppConfig(
        connectors={},
        watchProfiles={},
        engine=existing.engine if existing is not None else EngineSettings(),
        runtime=existing.runtime if existing is not None else AppConfig().runtime,
        slackSync=existing.slack_sync if existing is not None else AppConfig().slack_sync,
        gitlabSync=existing.gitlab_sync if existing is not None else AppConfig().gitlab_sync,
        review=existing.review if existing is not None else AppConfig().review,
        local=LocalSettings(
            workspaceDirs=list(existing_local.workspace_dirs),
            launcherLanguage=_coerce_launcher_language(existing_local.launcher_language).value,
        ),
    )
    context.store.save(config)
    _sync_config_metadata(context, config)
    return config


def _run_interactive_pairing(context: LauncherContext, language: LauncherLanguage | str | None) -> bool:
    """Interactive pairing flow: show installation ID, ask for pairing code, connect."""
    import httpx

    from workagent.config.env import get_supported_env_value
    from workagent.config.installation import agent_secret_file

    home_dir = context.store.paths.root_dir
    installation_id = ensure_installation_id(home_dir=home_dir)
    server_url = get_supported_env_value("WORKAGENT_REVIEW_BASE_URL") or "https://w10w225.uk"

    context.ui.show_message(_t(language, "pairing_intro", installation_id=installation_id))
    code = context.ui.ask_text(_t(language, "pairing_prompt")).strip().upper()
    if not code:
        return False

    try:
        response = httpx.post(
            f"{server_url}/api/v2/assistant/agent-pairing/complete",
            json={"pairingCode": code, "installationId": installation_id},
            timeout=15.0,
        )
        if response.status_code in {404, 410}:
            context.ui.show_message(_t(language, "pairing_failed", error="Invalid or expired code"))
            return False
        response.raise_for_status()
        data = response.json().get("data", response.json())
        agent_secret = data.get("agentSecret")
        if not agent_secret:
            context.ui.show_message(_t(language, "pairing_failed", error="No secret received"))
            return False
        secret_path = agent_secret_file(home_dir=home_dir)
        secret_path.parent.mkdir(parents=True, exist_ok=True)
        secret_path.write_text(f"{agent_secret}\n", encoding="utf-8")
        secret_path.chmod(0o600)

        # Save agents + skills received in pairing response
        agents = data.get("agents") or []
        if agents:
            from workagent.services.local_agent_store import LocalAgentStore
            agent_store = LocalAgentStore(agents_dir=home_dir / "agents")
            for agent_data in agents:
                agent_id = agent_data.get("agentId") or ""
                if not agent_id:
                    continue
                agent_store.save_agent(
                    agent_id=agent_id,
                    agent_prompt=agent_data.get("agentPrompt") or "",
                    skills=agent_data.get("skills") or [],
                    version=agent_data.get("version") or 1,
                    content_hash="",
                )

        context.ui.show_message(_t(language, "pairing_success"))
        return True
    except httpx.HTTPError as exc:
        context.ui.show_message(_t(language, "pairing_failed", error=str(exc)))
        return False


def run_launcher(context: LauncherContext) -> str:
    last_result = "exit"
    if not context.store.exists():
        run_wizard(context)
        last_result = "configured"

    # Check if pairing is needed (no agent-secret file)
    config = context.store.load() or AppConfig()
    language = _current_launcher_language(config)
    secret = load_agent_secret(home_dir=context.store.paths.root_dir)
    if not secret:
        _run_interactive_pairing(context, language)

    while True:
        config = context.store.load() or AppConfig()
        language = _current_launcher_language(config)
        selection = context.ui.choose_menu(
            _t(language, "choose_action"),
            build_launcher_menu(context.daemon.status(), language),
        )
        if selection == "start":
            context.daemon.start()
            context.ui.show_message(_t(language, "background_started"))
            last_result = "started"
            continue
        if selection == "restart":
            context.daemon.restart()
            context.ui.show_message(_t(language, "background_restarted"))
            last_result = "restarted"
            continue
        if selection == "stop":
            if context.daemon.stop():
                context.ui.show_message(_t(language, "background_stopped"))
                last_result = "stopped"
            else:
                context.ui.show_message(_t(language, "background_stop_failed"))
                last_result = context.daemon.status().value
            continue
        if selection == "reconnect":
            _run_interactive_pairing(context, language)
            last_result = "reconnected"
            continue
        if selection == "show_credentials":
            installation_id = ensure_installation_id(home_dir=context.store.paths.root_dir)
            agent_secret = ensure_agent_secret(home_dir=context.store.paths.root_dir)
            context.ui.show_message(
                _build_credentials_message(
                    language,
                    installation_id=installation_id,
                    agent_secret=agent_secret,
                )
            )
            last_result = "show_credentials"
            continue
        if selection == "status":
            status = context.daemon.status().value
            context.ui.show_message(_build_status_report(context))
            last_result = status
            continue
        if selection == "change_language":
            next_language = context.ui.choose_menu(
                _t(language, "choose_language"),
                [
                    MenuOption(_language_label(LauncherLanguage.en, display_language=language), LauncherLanguage.en.value),
                    MenuOption(_language_label(LauncherLanguage.ko, display_language=language), LauncherLanguage.ko.value),
                ],
            )
            resolved_language = _coerce_launcher_language(next_language)
            config.local.launcher_language = resolved_language
            context.store.save(config)
            context.ui.show_message(
                _t(
                    resolved_language,
                    "language_changed",
                    language_label=_language_label(resolved_language, display_language=resolved_language),
                )
            )
            last_result = "language_changed"
            continue
        return last_result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="w10w225")
    parser.add_argument(
        "--home",
        type=Path,
        help="Override the runtime home directory for config, logs, runs, and data.",
    )
    subparsers = parser.add_subparsers(dest="command")

    serve_parser = subparsers.add_parser("serve")
    serve_parser.add_argument("--foreground", action="store_true")
    serve_parser.add_argument("--background", action="store_true")

    subparsers.add_parser("stop")
    subparsers.add_parser("status")
    subparsers.add_parser("installation-id")
    reconnect_parser = subparsers.add_parser("reconnect", help="Re-pair with nk304 server (interactive)")
    reconnect_parser.add_argument("--server", default=None, help="Override nk304 server URL")

    config_parser = subparsers.add_parser("config")
    config_subparsers = config_parser.add_subparsers(dest="config_command")
    config_subparsers.add_parser("wizard")

    tokens_parser = subparsers.add_parser("tokens")
    tokens_subparsers = tokens_parser.add_subparsers(dest="tokens_command")
    add_parser = tokens_subparsers.add_parser("add")
    add_parser.add_argument("platform", choices=[item.value for item in Platform])
    disable_parser = tokens_subparsers.add_parser("disable")
    disable_parser.add_argument("platform", choices=[item.value for item in Platform])
    revoke_parser = tokens_subparsers.add_parser("revoke")
    revoke_parser.add_argument("platform", choices=[item.value for item in Platform])
    tokens_subparsers.add_parser("list")

    scheduler_parser = subparsers.add_parser("scheduler")
    scheduler_subparsers = scheduler_parser.add_subparsers(dest="scheduler_command")
    scheduler_subparsers.add_parser("run-due")

    sync_parser = subparsers.add_parser("sync")
    sync_subparsers = sync_parser.add_subparsers(dest="sync_command")
    sync_subparsers.add_parser("once")

    pair_parser = subparsers.add_parser("pair", help="Pair with nk304 server using a pairing code")
    pair_parser.add_argument("code", help="6-character pairing code from nk304")
    pair_parser.add_argument("--server", default=None, help="Override nk304 server URL")

    subparsers.add_parser("doctor")

    # External tool subcommands (w10w225 slack/jira/gitlab/...)
    from workagent.tools_cli import register_tool_subcommands
    register_tool_subcommands(subparsers)

    # nk304 internal platform subcommand (w10w225 nk304 chat/memo/ticket/...)
    from workagent.cli_tools.nk304_cli import register_nk304_subcommands
    register_nk304_subcommands(subparsers)

    return parser


def _build_context(home_dir: Path | None = None) -> LauncherContext:
    paths = default_config_paths(home_dir)
    return LauncherContext(
        store=ConfigStore(paths),
        secrets=build_default_secret_store(home_dir=paths.root_dir),
        ui=QuestionaryUI(),
        validator=HttpConnectorValidator(),
        daemon=DaemonController(paths),
    )


def _run_foreground_server(context: LauncherContext) -> int:
    config = context.store.load() or AppConfig()
    review_client = build_review_sync_client_from_env(home_dir=context.store.paths.root_dir)
    cleanup_runtime_log_files(home_dir=context.store.paths.root_dir)
    log_file = resolve_daily_log_file(prefix="serve", home_dir=context.store.paths.root_dir)
    app = create_app(
        paths=context.store.paths,
        runtime_bundle_factory=lambda session_factory: build_daemon_runtime_bundle(
            config=config,
            session_factory=session_factory,
            secret_store=context.secrets,
            review_client=review_client,
            home_dir=context.store.paths.root_dir,
        ),
    )
    uvicorn.run(
        app,
        host="127.0.0.1",
        port=8765,
        log_level="info",
        log_config=build_uvicorn_log_config(log_file),
    )
    return 0


def _apply_token_add(context: LauncherContext, platform: Platform, base_url: str, token: str) -> int:
    config = context.store.load() or AppConfig()
    connector_config = ConnectorConfig(base_url=base_url, secret_key=_secret_key_for(platform))
    context.validator.validate(platform, base_url, token)
    context.secrets.save(connector_config.secret_key, token)
    config.connectors[platform.value] = connector_config
    context.store.save(config)
    _sync_config_metadata(context, config)
    _record_audit_event(
        context,
        event_type="credential.token_added",
        entity_type="connector",
        entity_id=platform.value,
        payload={
            "connectorType": platform.value,
            "baseUrl": base_url,
            "secretKeyRef": connector_config.secret_key,
        },
    )
    return 0


def _run_scheduler_due(context: LauncherContext) -> int:
    async def _run() -> int:
        engine, session_factory = create_engine_and_session_factory(context.store.paths)
        await initialize_database(engine)
        runtime = SchedulerRuntime(SqlAlchemySchedulerJobRepository(session_factory))
        result = await runtime.run_once(datetime.now(UTC))
        await engine.dispose()
        print(f"runnable_jobs={len(result.runnable_jobs)}")
        return 0

    from datetime import UTC, datetime

    return asyncio.run(_run())


def _run_sync_once(context: LauncherContext) -> int:
    async def _run() -> int:
        engine, session_factory = create_engine_and_session_factory(context.store.paths)
        await initialize_database(engine)
        config = context.store.load() or AppConfig()
        bundle = build_daemon_runtime_bundle(
            config=config,
            session_factory=session_factory,
            secret_store=context.secrets,
            review_client=build_review_sync_client_from_env(home_dir=context.store.paths.root_dir),
            home_dir=context.store.paths.root_dir,
        )
        summary = await bundle.tick_runtime.run_once()
        await engine.dispose()
        print(
            f"runtime_cycle_executed={summary.runtime_cycle_executed} "
            f"pushed_case_count={summary.pushed_case_count}"
        )
        return 0

    return asyncio.run(_run())


def _disable_token(context: LauncherContext, platform: Platform) -> int:
    async def _run() -> int:
        engine, session_factory = create_engine_and_session_factory(context.store.paths)
        await initialize_database(engine)
        await set_connector_enabled(
            session_factory,
            connector_type=ConnectorType(platform.value),
            is_enabled=False,
        )
        await AuditService(session_factory).record(
            event_type="credential.disabled",
            entity_type="connector",
            entity_id=platform.value,
            payload={"connectorType": platform.value},
        )
        await engine.dispose()
        return 0

    from workagent.db.enums import ConnectorType

    return asyncio.run(_run())


def _revoke_token(context: LauncherContext, platform: Platform) -> int:
    config = context.store.load() or AppConfig()
    connector = config.connectors.pop(platform.value, None)
    if connector is not None and connector.secret_key:
        context.secrets.delete(connector.secret_key)
    context.store.save(config)
    _sync_config_metadata(context, config)
    _record_audit_event(
        context,
        event_type="credential.revoked",
        entity_type="connector",
        entity_id=platform.value,
        payload={
            "connectorType": platform.value,
            **({"baseUrl": connector.base_url} if connector is not None else {}),
            **({"secretKeyRef": connector.secret_key} if connector is not None else {}),
        },
    )
    return 0




def _run_pair(context: LauncherContext, code: str, server_override: str | None) -> int:
    import httpx

    from workagent.config.env import get_supported_env_value
    from workagent.config.installation import agent_secret_file

    home_dir = context.store.paths.root_dir
    installation_id = ensure_installation_id(home_dir=home_dir)

    server_url = server_override
    if not server_url:
        server_url = get_supported_env_value("WORKAGENT_REVIEW_BASE_URL") or "https://w10w225.uk"

    code = code.strip().upper()
    print(f"Pairing with {server_url}...")
    print(f"Installation ID: {installation_id}")
    print(f"Pairing code: {code}")

    try:
        response = httpx.post(
            f"{server_url}/api/v2/assistant/agent-pairing/complete",
            json={"pairingCode": code, "installationId": installation_id},
            timeout=15.0,
        )
        if response.status_code == 404:
            print("Error: Invalid pairing code. Check the code and try again.")
            return 1
        if response.status_code == 410:
            print("Error: Pairing code has expired. Generate a new one from nk304.")
            return 1
        response.raise_for_status()
        data = response.json().get("data", response.json())
        agent_secret = data.get("agentSecret")
        if not agent_secret:
            print("Error: No secret received from server.")
            return 1

        # Save the secret
        secret_path = agent_secret_file(home_dir=home_dir)
        secret_path.parent.mkdir(parents=True, exist_ok=True)
        secret_path.write_text(f"{agent_secret}\n", encoding="utf-8")
        secret_path.chmod(0o600)

        # Save agents + skills received in pairing response
        agents = data.get("agents") or []
        if agents:
            from workagent.services.local_agent_store import LocalAgentStore
            agent_store = LocalAgentStore(agents_dir=home_dir / "agents")
            for agent_data in agents:
                agent_id = agent_data.get("agentId") or ""
                if not agent_id:
                    continue
                agent_store.save_agent(
                    agent_id=agent_id,
                    agent_prompt=agent_data.get("agentPrompt") or "",
                    skills=agent_data.get("skills") or [],
                    version=agent_data.get("version") or 1,
                    content_hash="",
                )
            print(f"Saved {len(agents)} agent(s) with skills.")

        print("Pairing successful! You can now start the daemon with: w10w225 serve --background")
        return 0
    except httpx.HTTPError as exc:
        print(f"Error connecting to server: {exc}")
        return 1


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    context = _build_context(args.home)

    if args.command is None:
        run_launcher(context)
        return 0

    if args.command == "serve":
        if args.background:
            context.daemon.start()
            return 0
        return _run_foreground_server(context)

    if args.command == "stop":
        context.daemon.stop()
        return 0

    if args.command == "status":
        print(_build_status_report(context))
        return 0

    if args.command == "installation-id":
        config = context.store.load()
        language = _current_launcher_language(config)
        installation_id = ensure_installation_id(home_dir=context.store.paths.root_dir)
        agent_secret = ensure_agent_secret(home_dir=context.store.paths.root_dir)
        print(_build_credentials_message(language, installation_id=installation_id, agent_secret=agent_secret))
        return 0

    if args.command == "pair":
        return _run_pair(context, args.code, args.server)

    if args.command == "reconnect":
        config = context.store.load() or AppConfig()
        language = _current_launcher_language(config)
        _run_interactive_pairing(context, language)
        return 0

    if args.command == "config" and args.config_command == "wizard":
        run_wizard(context)
        return 0

    if args.command == "tokens" and args.tokens_command == "add":
        base_url = context.ui.ask_text(f"{PLATFORM_LABELS[Platform(args.platform)]} base URL").strip()
        token = context.ui.ask_text(f"{PLATFORM_LABELS[Platform(args.platform)]} API key/token", secret=True).strip()
        return _apply_token_add(
            context,
            Platform(args.platform),
            base_url=base_url,
            token=token,
        )
    if args.command == "tokens" and args.tokens_command == "list":
        config = context.store.load()
        if config is None:
            return 0
        for platform, connector in config.connector_items():
            print(f"{platform.value}\t{connector.base_url}")
        return 0
    if args.command == "tokens" and args.tokens_command == "disable":
        return _disable_token(context, Platform(args.platform))
    if args.command == "tokens" and args.tokens_command == "revoke":
        return _revoke_token(context, Platform(args.platform))

    if args.command == "scheduler" and args.scheduler_command == "run-due":
        return _run_scheduler_due(context)

    if args.command == "sync" and args.sync_command == "once":
        return _run_sync_once(context)


    # External tool commands (slack, jira, gitlab, ...)
    if hasattr(args, "platform") and args.platform:
        from workagent.tools_cli import run_tool_command
        return run_tool_command(args)

    # nk304 internal platform commands (w10w225 nk304 chat/memo/ticket/...)
    if args.command == "nk304":
        from workagent.cli_tools.nk304_cli import run_nk304_command
        return run_nk304_command(args)

    if args.command == "doctor":
        config = context.store.load() or AppConfig()
        installation_id = load_installation_id(home_dir=context.store.paths.root_dir) or "missing"
        agent_secret_status = "present" if load_agent_secret(home_dir=context.store.paths.root_dir) else "missing"
        engine_fields = _probe_engine_auth_status(
            config=config,
            secrets=context.secrets,
            home_dir=context.store.paths.root_dir,
        )
        print(
            f"config_exists={context.store.exists()} "
            f"daemon_status={context.daemon.status().value} "
            f"installation_id={installation_id} "
            f"agent_secret={agent_secret_status} "
            + " ".join(f"{key}={value}" for key, value in engine_fields.items())
        )
        return 0

    parser.print_help()
    return 1
