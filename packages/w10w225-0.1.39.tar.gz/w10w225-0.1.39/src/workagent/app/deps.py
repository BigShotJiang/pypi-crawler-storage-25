from __future__ import annotations

from collections.abc import AsyncIterator

from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker


def get_session_factory(app_or_request) -> async_sessionmaker[AsyncSession]:
    state = app_or_request.app.state if isinstance(app_or_request, Request) else app_or_request.state
    return state.session_factory


async def get_db_session(request: Request) -> AsyncIterator[AsyncSession]:
    session_factory = get_session_factory(request)
    async with session_factory() as session:
        yield session

