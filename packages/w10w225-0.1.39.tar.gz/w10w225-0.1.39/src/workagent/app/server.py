from __future__ import annotations

import asyncio
from collections.abc import Callable
from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from workagent.app.errors import register_error_handlers
from workagent.app.middleware import RequestContextMiddleware
from workagent.app.routes import router as internal_router
from workagent.config.store import ConfigPaths, default_config_paths
from workagent.db.session import create_engine_and_session_factory, initialize_database


def create_app(
    *,
    paths: ConfigPaths | None = None,
    daemon_loop=None,
    runtime_bundle_factory: Callable[[async_sessionmaker[AsyncSession]], object] | None = None,
) -> FastAPI:  # noqa: ANN001
    resolved_paths = paths or default_config_paths()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        engine, session_factory = create_engine_and_session_factory(resolved_paths)
        await initialize_database(engine)
        app.state.paths = resolved_paths
        app.state.engine = engine
        app.state.session_factory = session_factory
        runtime_bundle = runtime_bundle_factory(session_factory) if runtime_bundle_factory is not None else None
        active_daemon_loop = daemon_loop
        if runtime_bundle is not None:
            app.state.app_runtime = getattr(runtime_bundle, "app_runtime", None)
            app.state.runtime_loop = getattr(runtime_bundle, "runtime_loop", None)
            app.state.review_push_service = getattr(runtime_bundle, "review_push_service", None)
            app.state.outbound_processor = getattr(runtime_bundle, "outbound_processor", None)
            app.state.tick_runtime = getattr(runtime_bundle, "tick_runtime", None)
            app.state.queue = getattr(runtime_bundle, "queue", None)
            recover_startup = getattr(runtime_bundle, "recover_startup", None)
            if callable(recover_startup):
                await recover_startup()
            if active_daemon_loop is None:
                active_daemon_loop = getattr(runtime_bundle, "daemon_loop", None)
        daemon_task = None
        if active_daemon_loop is not None:
            daemon_task = asyncio.create_task(active_daemon_loop.run_forever())
            app.state.daemon_loop = active_daemon_loop
            app.state.daemon_task = daemon_task
        yield
        if active_daemon_loop is not None:
            active_daemon_loop.stop()
            if daemon_task is not None:
                await daemon_task
        await engine.dispose()

    app = FastAPI(title="personal-work-agent", lifespan=lifespan)
    app.add_middleware(RequestContextMiddleware)
    register_error_handlers(app)
    app.include_router(internal_router)

    @app.get("/healthz")
    async def healthz() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/readyz")
    async def readyz() -> dict[str, str]:
        return {"status": "ready"}

    return app


app = create_app()
