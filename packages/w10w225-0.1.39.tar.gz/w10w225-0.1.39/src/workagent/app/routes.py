from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request

from workagent.app.deps import get_session_factory
from workagent.services.admin import AdminQueryService

router = APIRouter(prefix="/internal", tags=["internal"])


@router.post("/runtime/run-once")
async def run_runtime_once(request: Request) -> dict:
    runtime_loop = getattr(request.app.state, "runtime_loop", None)
    if runtime_loop is None:
        raise HTTPException(status_code=503, detail="runtime loop unavailable")
    data = await runtime_loop.run_cycle()
    return {"data": data}


@router.post("/review/push-ready")
async def push_review_ready(request: Request) -> dict:
    service = getattr(request.app.state, "review_push_service", None)
    if service is None:
        raise HTTPException(status_code=503, detail="review push unavailable")
    pushed = await service.push_ready_cases()
    return {"data": {"pushed": len(pushed)}}


@router.post("/outbound/process")
async def process_outbound(request: Request) -> dict:
    processor = getattr(request.app.state, "outbound_processor", None)
    if processor is None:
        raise HTTPException(status_code=503, detail="outbound processor unavailable")
    outcomes = await processor.process_once()
    return {
        "data": {
            "sent": sum(1 for item in outcomes if item == "sent"),
            "failed": sum(1 for item in outcomes if item == "failed"),
            "manualRequired": sum(1 for item in outcomes if item == "manual_required"),
        }
    }


@router.get("/admin/status")
async def get_admin_status(request: Request) -> dict:
    session_factory = get_session_factory(request)
    service = AdminQueryService(session_factory)
    return {"data": await service.get_status_snapshot()}


@router.get("/cases/{case_id}/timeline")
async def get_case_timeline(case_id: str, request: Request) -> dict:
    session_factory = get_session_factory(request)
    service = AdminQueryService(session_factory)
    payload = await service.get_case_timeline(case_id)
    if payload is None:
        raise HTTPException(status_code=404, detail="case not found")
    return {"data": payload}


@router.get("/admin/metrics")
async def get_admin_metrics(request: Request) -> dict:
    session_factory = get_session_factory(request)
    service = AdminQueryService(session_factory)
    queue = getattr(request.app.state, "queue", None)
    return {
        "data": await service.get_metrics_snapshot(
            daemon_running=getattr(request.app.state, "daemon_loop", None) is not None,
            queue_depth=int(getattr(queue, "depth", 0) if queue is not None else 0),
        )
    }


@router.get("/admin/memory")
async def get_admin_memory(request: Request) -> dict:
    session_factory = get_session_factory(request)
    service = AdminQueryService(session_factory)
    return {"data": service.get_memory_snapshot()}


@router.get("/admin/agent-sync")
async def get_admin_agent_sync(request: Request) -> dict:
    session_factory = get_session_factory(request)
    service = AdminQueryService(session_factory)
    return {"data": await service.get_agent_sync_snapshot()}
