from workagent.app.server import create_app

__all__ = ["create_app"]

