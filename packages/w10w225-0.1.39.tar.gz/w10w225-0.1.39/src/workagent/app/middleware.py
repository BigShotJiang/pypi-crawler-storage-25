from __future__ import annotations

import logging
from time import perf_counter
from typing import Any
from uuid import uuid4

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

REDACTED_VALUE = "[REDACTED]"
_SENSITIVE_KEY_SUFFIXES = ("apikey", "authorization", "cookie", "password", "secret", "token")
_LOGGED_REQUEST_HEADERS = (
    "authorization",
    "user-agent",
    "x-api-key",
    "x-correlation-id",
    "x-internal-worker-secret",
    "x-request-id",
)

logger = logging.getLogger("workagent.http")
logger.propagate = True


def redact_payload(value: Any) -> Any:
    if isinstance(value, dict):
        redacted: dict[str, Any] = {}
        for key, child in value.items():
            redacted[key] = REDACTED_VALUE if _is_sensitive_key(key) else redact_payload(child)
        return redacted
    if isinstance(value, list):
        return [redact_payload(item) for item in value]
    if isinstance(value, tuple):
        return tuple(redact_payload(item) for item in value)
    return value


def _is_sensitive_key(key: str) -> bool:
    normalized = "".join(char for char in key.lower() if char.isalnum())
    return bool(normalized) and normalized.endswith(_SENSITIVE_KEY_SUFFIXES)


def _request_headers_for_logging(request: Request) -> dict[str, str]:
    headers = {key.lower(): value for key, value in request.headers.items() if key.lower() in _LOGGED_REQUEST_HEADERS}
    return redact_payload(headers)


def _query_params_for_logging(request: Request) -> dict[str, str]:
    return redact_payload(dict(request.query_params))


class RequestContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        started_at = perf_counter()
        request_id = request.headers.get("x-request-id") or str(uuid4())
        correlation_id = request.headers.get("x-correlation-id") or request_id
        request.state.request_id = request_id
        request.state.correlation_id = correlation_id
        response = await call_next(request)
        response.headers["x-request-id"] = request_id
        response.headers["x-correlation-id"] = correlation_id
        logger.info(
            "http request complete",
            extra={
                "request_id": request_id,
                "correlation_id": correlation_id,
                "method": request.method,
                "path": request.url.path,
                "status_code": response.status_code,
                "duration_ms": round((perf_counter() - started_at) * 1000, 2),
                "request_headers": _request_headers_for_logging(request),
                "query_params": _query_params_for_logging(request),
            },
        )
        return response
