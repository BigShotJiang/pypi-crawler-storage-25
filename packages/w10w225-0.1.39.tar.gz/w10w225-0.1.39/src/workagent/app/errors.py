from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse


def _error_payload(*, request: Request, code: str, message: str, status_code: int) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content={
            "error": {
                "code": code,
                "message": message,
                "details": None,
            },
            "meta": {
                "requestId": getattr(request.state, "request_id", None),
                "correlationId": getattr(request.state, "correlation_id", None),
            },
        },
    )


def register_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(Exception)
    async def _handle_unexpected_error(request: Request, exc: Exception) -> JSONResponse:
        return _error_payload(
            request=request,
            code="INTERNAL_ERROR",
            message=str(exc) or "internal error",
            status_code=500,
        )

