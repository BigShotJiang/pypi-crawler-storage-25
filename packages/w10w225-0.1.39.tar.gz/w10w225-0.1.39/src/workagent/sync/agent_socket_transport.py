from __future__ import annotations

import asyncio
import hashlib
import hmac
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

import socketio

from workagent.sync.models import AgentOnboardingItemRecord, AgentPendingItemRecord

logger = logging.getLogger(__name__)

PendingHandler = Callable[[AgentPendingItemRecord], Awaitable[None]]
OnboardingHandler = Callable[[AgentOnboardingItemRecord], Awaitable[None]]
AgentDefinitionPushHandler = Callable[[dict[str, Any]], Awaitable[None]]


@dataclass(frozen=True, slots=True)
class LocalAgentSocketAuthSigner:
    secret: str
    timestamp_provider: Callable[[], str] | None = None

    def build_auth(self, *, installation_id: str, method: str = "WEBSOCKET", path: str = "/agent-local") -> dict[str, str]:
        timestamp = self.timestamp_provider() if self.timestamp_provider else datetime.now(UTC).isoformat()
        payload = f"{installation_id}\n{timestamp}\n{method}\n{path}".encode()
        signature = hmac.new(self.secret.encode("utf-8"), payload, hashlib.sha256).hexdigest()
        return {
            "installationId": installation_id,
            "timestamp": timestamp,
            "signature": signature,
        }


class LocalAgentSocketTransport:
    def __init__(
        self,
        *,
        base_url: str,
        installation_id: str,
        secret: str,
        namespace: str = "/agent-local",
        client_factory: Callable[[], socketio.AsyncClient] | None = None,
        now_provider: Callable[[], datetime] | None = None,
        initial_retry_delay_seconds: float = 5.0,
        max_retry_delay_seconds: float = 60.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.installation_id = installation_id
        self.namespace = namespace
        self.auth_signer = LocalAgentSocketAuthSigner(secret=secret)
        self.client = client_factory() if client_factory is not None else socketio.AsyncClient(reconnection=False)
        self.pending_handler: PendingHandler | None = None
        self.onboarding_handler: OnboardingHandler | None = None
        self._agent_definition_push_handler: AgentDefinitionPushHandler | None = None
        self.last_event_at: datetime | None = None
        self.last_connected_at: datetime | None = None
        self._now_provider = now_provider or (lambda: datetime.now(UTC))
        self._initial_retry_delay_seconds = max(0.1, float(initial_retry_delay_seconds))
        self._max_retry_delay_seconds = max(self._initial_retry_delay_seconds, float(max_retry_delay_seconds))
        self._next_retry_delay_seconds = self._initial_retry_delay_seconds
        self._next_connect_attempt_at: datetime | None = None
        self._consecutive_failures = 0
        self._connect_lock = asyncio.Lock()
        self._register_handlers()

    @property
    def is_connected(self) -> bool:
        return self.client.connected and self.namespace in self.client.namespaces

    def set_pending_handler(self, handler: PendingHandler) -> None:
        self.pending_handler = handler

    def set_onboarding_handler(self, handler: OnboardingHandler) -> None:
        self.onboarding_handler = handler

    def set_agent_definition_push_handler(self, handler: AgentDefinitionPushHandler) -> None:
        self._agent_definition_push_handler = handler

    async def ensure_connected(self) -> bool:
        if self.is_connected:
            return True
        if self._connect_cooldown_active(self._now()):
            return False
        async with self._connect_lock:
            if self.is_connected:
                return True
            if self._connect_cooldown_active(self._now()):
                return False
            try:
                await self.client.connect(
                    self.base_url,
                    socketio_path="socket.io",
                    namespaces=[self.namespace],
                    transports=["websocket"],
                    auth=self.auth_signer.build_auth(installation_id=self.installation_id),
                )
                self.last_connected_at = self._now()
                self._reset_retry_state()
            except Exception as exc:  # noqa: BLE001
                self._record_connect_failure(exc)
        return self.is_connected

    def _now(self) -> datetime:
        return self._now_provider()

    def _connect_cooldown_active(self, now: datetime) -> bool:
        return self._next_connect_attempt_at is not None and now < self._next_connect_attempt_at

    def _reset_retry_state(self) -> None:
        self._next_retry_delay_seconds = self._initial_retry_delay_seconds
        self._next_connect_attempt_at = None
        self._consecutive_failures = 0

    def _record_connect_failure(self, exc: Exception) -> None:
        failed_at = self._now()
        retry_delay_seconds = self._next_retry_delay_seconds
        self._next_connect_attempt_at = failed_at + timedelta(seconds=retry_delay_seconds)
        self._next_retry_delay_seconds = min(self._next_retry_delay_seconds * 2, self._max_retry_delay_seconds)
        self._consecutive_failures += 1
        logger.warning(
            "local agent socket connect failed: %s; retry_in=%.1fs consecutive_failures=%d",
            exc,
            retry_delay_seconds,
            self._consecutive_failures,
        )

    def _register_handlers(self) -> None:
        @self.client.on("agent.pending_item", namespace=self.namespace)
        async def _on_pending_item(payload: dict[str, Any]) -> None:
            self.last_event_at = self._now()
            if self.pending_handler is None:
                return
            await self.pending_handler(AgentPendingItemRecord.model_validate(payload))

        @self.client.on("agent.onboarding_item", namespace=self.namespace)
        async def _on_onboarding_item(payload: dict[str, Any]) -> None:
            self.last_event_at = self._now()
            if self.onboarding_handler is None:
                return
            try:
                await self.onboarding_handler(AgentOnboardingItemRecord.model_validate(payload))
            except Exception:  # noqa: BLE001
                logger.exception("local agent onboarding handler failed")
                raise

        @self.client.on("agent.agent_definition.push", namespace=self.namespace)
        async def _on_agent_definition_push(data: dict[str, Any]) -> None:
            self.last_event_at = self._now()
            if self._agent_definition_push_handler:
                await self._agent_definition_push_handler(data)
            await self.client.emit(
                "agent.agent_definition.push.ack",
                {
                    "agentId": data.get("agentId"),
                    "contentHash": data.get("contentHash"),
                    "status": "saved",
                },
                namespace=self.namespace,
            )

    async def ack_agent_pending_item(self, item_id: str, payload) -> dict:  # noqa: ANN001
        response = await self.client.call(
            "agent.pending_item.ack",
            {"itemId": item_id, **payload.model_dump(mode="json", by_alias=True)},
            namespace=self.namespace,
        )
        return self._unwrap_response(response)

    async def push_agent_pending_item_result(self, item_id: str, payload) -> dict:  # noqa: ANN001
        response = await self.client.call(
            "agent.pending_item.result",
            {"itemId": item_id, **payload.model_dump(mode="json", by_alias=True)},
            namespace=self.namespace,
        )
        return self._unwrap_response(response)

    async def post_agent_session_message(self, session_id: str, payload) -> dict:  # noqa: ANN001
        response = await self.client.call(
            "agent.session_message.post",
            {"sessionId": session_id, **payload.model_dump(mode="json", by_alias=True)},
            namespace=self.namespace,
        )
        return self._unwrap_response(response)

    async def create_agent_write_draft(self, payload) -> dict:  # noqa: ANN001
        response = await self.client.call(
            "agent.write_draft.create",
            payload.model_dump(mode="json", by_alias=True),
            namespace=self.namespace,
        )
        return self._unwrap_response(response)

    async def push_project_workflow_stage_result(self, workflow_run_id: str, payload) -> dict:  # noqa: ANN001
        response = await self.client.call(
            "agent.project_workflow.result",
            {"runId": workflow_run_id, **payload.model_dump(mode="json", by_alias=True)},
            namespace=self.namespace,
        )
        return self._unwrap_response(response)

    async def update_agent_write_draft_status(self, draft_id: str, payload) -> dict:  # noqa: ANN001
        response = await self.client.call(
            "agent.write_draft.status",
            {"draftId": draft_id, **payload.model_dump(mode="json", by_alias=True)},
            namespace=self.namespace,
        )
        return self._unwrap_response(response)

    async def ack_agent_onboarding_item(self, item_id: str, payload) -> dict:  # noqa: ANN001
        response = await self.client.call(
            "agent.onboarding_item.ack",
            {"itemId": item_id, **payload.model_dump(mode="json", by_alias=True)},
            namespace=self.namespace,
        )
        return self._unwrap_response(response)

    async def push_agent_onboarding_item_result(self, item_id: str, payload) -> dict:  # noqa: ANN001
        response = await self.client.call(
            "agent.onboarding_item.result",
            {"itemId": item_id, **payload.model_dump(mode="json", by_alias=True)},
            namespace=self.namespace,
        )
        return self._unwrap_response(response)

    @staticmethod
    def _unwrap_response(response: Any) -> dict:
        if isinstance(response, dict) and isinstance(response.get("data"), dict):
            return response["data"]
        return response if isinstance(response, dict) else {}
