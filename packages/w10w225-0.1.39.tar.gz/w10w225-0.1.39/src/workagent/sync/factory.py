from __future__ import annotations

from pathlib import Path
from uuid import UUID

from workagent.config.env import get_supported_env_value
from workagent.config.installation import ensure_agent_secret, ensure_installation_id
from workagent.security.hmac import HmacSha256Signer
from workagent.sync.client import ReviewSyncClient

DEFAULT_REVIEW_BASE_URL = "https://w10w225.uk"


def _placeholder(value: str) -> bool:
    normalized = value.strip().lower()
    return normalized in {
        "",
        "replace-me",
        "https://reviews.example.com",
    }


def _default_dotenv_dir() -> Path:
    return Path(__file__).resolve().parents[3]


def _load_supported_env_value(name: str, *, cwd: Path | None = None) -> str | None:
    primary = get_supported_env_value(name, cwd=cwd)
    if primary:
        return primary
    fallback_cwd = _default_dotenv_dir()
    if cwd is not None and Path(cwd).resolve() == fallback_cwd:
        return None
    return get_supported_env_value(name, cwd=fallback_cwd)


def _is_valid_installation_id(value: str) -> bool:
    try:
        return str(UUID(value)) == value.lower()
    except (ValueError, AttributeError):
        return False


def _is_valid_agent_secret(value: str) -> bool:
    normalized = value.strip().lower()
    return len(normalized) == 64 and all(char in "0123456789abcdef" for char in normalized)


def build_review_sync_client_from_env(*, home_dir=None, cwd=None) -> ReviewSyncClient | None:
    base_url = _load_supported_env_value("WORKAGENT_REVIEW_BASE_URL", cwd=cwd) or DEFAULT_REVIEW_BASE_URL
    if _placeholder(base_url):
        return None
    target_installation_id = ensure_installation_id(home_dir=home_dir, cwd=cwd)
    if not _is_valid_installation_id(target_installation_id):
        return None
    # per_user_secret: unique per user, used for x-agent-signature (user-level auth).
    # nk304 server verifies this first; WORKAGENT_REVIEW_SHARED_SECRET is only a
    # server-side fallback and does not need to be set on the client side.
    per_user_secret = ensure_agent_secret(home_dir=home_dir, cwd=cwd)
    if not _is_valid_agent_secret(per_user_secret):
        return None
    # If a gateway secret is present, add service-level HMAC signing as an extra layer.
    gateway_secret = _load_supported_env_value("WORKAGENT_REVIEW_SHARED_SECRET", cwd=cwd) or ""
    signer = HmacSha256Signer(secret=gateway_secret) if not _placeholder(gateway_secret) else None
    return ReviewSyncClient(
        base_url=base_url,
        target_installation_id=target_installation_id,
        local_agent_secret=per_user_secret,
        signer=signer,
    )
