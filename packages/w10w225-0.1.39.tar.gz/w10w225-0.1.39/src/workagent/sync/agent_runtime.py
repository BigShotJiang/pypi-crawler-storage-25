from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from workagent.services.agent_onboarding_sync import SyncedOnboardingItemOutcome
from workagent.services.agent_pending_sync import SyncedPendingItemOutcome


class AgentPendingSyncServiceLike(Protocol):
    async def sync_once(self) -> list[SyncedPendingItemOutcome]: ...


class AgentOnboardingSyncServiceLike(Protocol):
    async def sync_once(self) -> list[SyncedOnboardingItemOutcome]: ...


class AgentSocketTransportLike(Protocol):
    async def ensure_connected(self) -> bool: ...

    @property
    def is_connected(self) -> bool: ...

    @property
    def last_event_at(self) -> datetime | None: ...

    @property
    def last_connected_at(self) -> datetime | None: ...


@dataclass(frozen=True, slots=True)
class AgentPendingSyncCycleSummary:
    total_items: int
    completed_items: int
    failed_items: int


@dataclass(frozen=True, slots=True)
class AgentOnboardingSyncCycleSummary:
    total_items: int
    completed_items: int
    failed_items: int


class AgentPendingSyncRuntime:
    def __init__(
        self,
        *,
        sync_service: AgentPendingSyncServiceLike,
        socket_transport: AgentSocketTransportLike | None = None,
    ) -> None:
        self.sync_service = sync_service
        self.socket_transport = socket_transport

    async def run_cycle(self) -> AgentPendingSyncCycleSummary:
        if self.socket_transport is not None:
            if await self.socket_transport.ensure_connected():
                return AgentPendingSyncCycleSummary(total_items=0, completed_items=0, failed_items=0)
        outcomes = await self.sync_service.sync_once()
        completed = sum(1 for item in outcomes if item.status == "completed")
        failed = sum(1 for item in outcomes if item.status == "failed")
        return AgentPendingSyncCycleSummary(
            total_items=len(outcomes),
            completed_items=completed,
            failed_items=failed,
        )


class AgentOnboardingSyncRuntime:
    def __init__(
        self,
        *,
        sync_service: AgentOnboardingSyncServiceLike,
        socket_transport: AgentSocketTransportLike | None = None,
    ) -> None:
        self.sync_service = sync_service
        self.socket_transport = socket_transport

    async def run_cycle(self) -> AgentOnboardingSyncCycleSummary:
        if self.socket_transport is not None:
            if await self.socket_transport.ensure_connected():
                return AgentOnboardingSyncCycleSummary(total_items=0, completed_items=0, failed_items=0)
        outcomes = await self.sync_service.sync_once()
        completed = sum(1 for item in outcomes if item.status == "completed")
        failed = sum(1 for item in outcomes if item.status == "failed")
        return AgentOnboardingSyncCycleSummary(
            total_items=len(outcomes),
            completed_items=completed,
            failed_items=failed,
        )
