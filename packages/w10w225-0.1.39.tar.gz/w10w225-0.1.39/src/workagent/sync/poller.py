from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from workagent.sync.models import ReviewCommand


class CursorStore(Protocol):
    async def load(self) -> str | None: ...

    async def save(self, cursor: str | None) -> None: ...


class ReviewCommandClient(Protocol):
    async def pull_review_commands(self, *, cursor: str | None = None, limit: int = 20): ...


@dataclass(frozen=True, slots=True)
class CommandBatch:
    commands: list[ReviewCommand]
    previous_cursor: str | None
    next_cursor: str | None


class ReviewCommandPoller:
    def __init__(self, *, client: ReviewCommandClient, cursor_store: CursorStore, limit: int = 20) -> None:
        self._client = client
        self._cursor_store = cursor_store
        self._limit = limit

    async def poll_once(self) -> CommandBatch:
        previous_cursor = await self._cursor_store.load()
        response = await self._client.pull_review_commands(cursor=previous_cursor, limit=self._limit)
        next_cursor = response.next_cursor if response.next_cursor is not None else previous_cursor
        return CommandBatch(
            commands=response.commands,
            previous_cursor=previous_cursor,
            next_cursor=next_cursor,
        )

    async def commit(self, batch: CommandBatch) -> None:
        await self._cursor_store.save(batch.next_cursor)
