from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from workagent.services.review_sync import SyncedCommandOutcome


class ReviewSyncServiceLike(Protocol):
    async def sync_once(self) -> list[SyncedCommandOutcome]: ...


@dataclass(frozen=True, slots=True)
class ReviewSyncCycleSummary:
    total_commands: int
    completed_commands: int
    failed_commands: int


class ReviewSyncRuntime:
    def __init__(self, *, sync_service: ReviewSyncServiceLike) -> None:
        self.sync_service = sync_service

    async def run_cycle(self) -> ReviewSyncCycleSummary:
        outcomes = await self.sync_service.sync_once()
        completed = sum(1 for item in outcomes if item.status == "completed")
        failed = sum(1 for item in outcomes if item.status == "failed")
        return ReviewSyncCycleSummary(
            total_commands=len(outcomes),
            completed_commands=completed,
            failed_commands=failed,
        )
