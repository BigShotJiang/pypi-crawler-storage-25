from __future__ import annotations

from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field, model_validator

from workagent.db.enums import AgentExecutionDecisionType, AgentPendingItemType


class ReviewCommandAction(StrEnum):
    approve_send = "approve_send"
    edit_and_send = "edit_and_send"
    request_followup = "request_followup"
    reject = "reject"


class ReviewThreadContext(BaseModel):
    thread_id: str | None = Field(default=None, alias="threadId")
    topic_session_id: str | None = Field(default=None, alias="topicSessionId")
    reply_mode: str | None = Field(default=None, alias="replyMode")

    model_config = {"populate_by_name": True}


class ReviewBotIdentity(BaseModel):
    sender_user_id: str = Field(alias="senderUserId")
    sender_user_nickname: str | None = Field(default=None, alias="senderUserNickname")

    model_config = {"populate_by_name": True}


class ReviewCasePushPayload(BaseModel):
    case_id: str = Field(alias="caseId")
    source: str
    status: str
    draft: str
    summary: str | None = None
    thread_id: str | None = Field(default=None, alias="threadId")
    thread_context: ReviewThreadContext | None = Field(default=None, alias="threadContext")
    bot_identity: ReviewBotIdentity | None = Field(default=None, alias="botIdentity")
    source_url: str | None = Field(default=None, alias="sourceUrl")
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class ReviewCommand(BaseModel):
    id: str
    case_id: str = Field(alias="caseId")
    action: ReviewCommandAction
    payload: dict[str, Any] = Field(default_factory=dict)
    thread_context: ReviewThreadContext | None = Field(default=None, alias="threadContext")
    bot_identity: ReviewBotIdentity | None = Field(default=None, alias="botIdentity")

    model_config = {"populate_by_name": True}


class ReviewCommandPullResponse(BaseModel):
    commands: list[ReviewCommand] = Field(default_factory=list)
    next_cursor: str | None = Field(default=None, alias="nextCursor")

    model_config = {"populate_by_name": True}


class ReviewCommandAckPayload(BaseModel):
    receipt_id: str = Field(alias="receiptId")
    status: str
    thread_context: ReviewThreadContext | None = Field(default=None, alias="threadContext")
    bot_identity: ReviewBotIdentity | None = Field(default=None, alias="botIdentity")
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class ReviewCommandResultPayload(BaseModel):
    status: str
    result: dict[str, Any] = Field(default_factory=dict)
    thread_context: ReviewThreadContext | None = Field(default=None, alias="threadContext")
    bot_identity: ReviewBotIdentity | None = Field(default=None, alias="botIdentity")
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class AgentPendingItemRecord(BaseModel):
    id: str
    session_id: str | None = Field(default=None, alias="sessionId")
    thread_id: str = Field(alias="threadId")
    message_id: str | None = Field(default=None, alias="messageId")
    item_type: str = Field(alias="itemType")
    payload: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}

    @model_validator(mode="after")
    def _validate_payload_shape(self) -> AgentPendingItemRecord:
        payload = self.payload if isinstance(self.payload, dict) else {}
        item_type = AgentPendingItemType(self.item_type)
        required_fields_by_type = {
            AgentPendingItemType.new_direct_request: {"requestText"},
            AgentPendingItemType.interactive_user_reply: {"replyText"},
            AgentPendingItemType.interactive_execution_decision: {"decisionType"},
            AgentPendingItemType.project_workflow_stage_execute: {"requestText"},
        }
        missing_fields = [
            field
            for field in required_fields_by_type[item_type]
            if payload.get(field) in {None, ""}
        ]
        if missing_fields:
            raise ValueError(
                f"agent pending item payload missing required fields for {item_type.value}: {', '.join(missing_fields)}"
            )
        if "threadId" in payload and str(payload.get("threadId") or "").strip() != self.thread_id:
            raise ValueError("agent pending item payload threadId must match record threadId")
        if "messageId" in payload and self.message_id and str(payload.get("messageId") or "").strip() != self.message_id:
            raise ValueError("agent pending item payload messageId must match record messageId")
        if "sessionId" in payload and self.session_id and str(payload.get("sessionId") or "").strip() not in {"", self.session_id}:
            raise ValueError("agent pending item payload sessionId must match record sessionId")
        message_artifacts_by_id = payload.get("messageArtifactsById")
        conversation_turns = payload.get("conversationTurns")
        artifact_ids = (
            {str(key).strip() for key in message_artifacts_by_id.keys() if str(key).strip()}
            if isinstance(message_artifacts_by_id, dict)
            else set()
        )
        for raw_turn in list(conversation_turns or []):
            if not isinstance(raw_turn, dict):
                continue
            artifact_refs = [str(item).strip() for item in list(raw_turn.get("artifactRefs") or []) if str(item).strip()]
            if not artifact_refs:
                continue
            message_id = str(raw_turn.get("messageId") or "").strip()
            if not message_id:
                raise ValueError("agent pending item payload artifactRefs require messageId on the conversation turn")
            missing_refs = [artifact_ref for artifact_ref in artifact_refs if artifact_ref not in artifact_ids]
            if missing_refs:
                raise ValueError("agent pending item payload artifactRefs must reference messageArtifactsById entries")
        if item_type is AgentPendingItemType.interactive_execution_decision:
            AgentExecutionDecisionType(str(payload["decisionType"]).strip().lower())
        return self


class AgentPendingItemPullResponse(BaseModel):
    items: list[AgentPendingItemRecord] = Field(default_factory=list)
    next_cursor: str | None = Field(default=None, alias="nextCursor")

    model_config = {"populate_by_name": True}


class AgentPendingItemAckPayload(BaseModel):
    receipt_id: str = Field(alias="receiptId")
    status: str
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class AgentPendingItemResultPayload(BaseModel):
    status: str
    result: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class AgentSessionMessagePayload(BaseModel):
    message_type: str = Field(alias="messageType")
    text: str
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class AgentWriteDraftCreatePayload(BaseModel):
    session_id: str = Field(alias="sessionId")
    draft_kind: str = Field(alias="draftKind")
    target_ref: dict[str, Any] = Field(default_factory=dict, alias="targetRef")
    draft_text: str = Field(alias="draftText")
    draft_payload: dict[str, Any] = Field(default_factory=dict, alias="draftPayload")
    proposed_by_message_id: str | None = Field(default=None, alias="proposedByMessageId")

    model_config = {"populate_by_name": True}


class AgentRoomMessagePayload(BaseModel):
    text: str
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class AgentWriteDraftStatusPayload(BaseModel):
    status: str
    execution_result: dict[str, Any] = Field(default_factory=dict, alias="executionResult")
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class AgentOnboardingItemRecord(BaseModel):
    id: str
    platform_id: str = Field(alias="platformId")
    item_type: str = Field(alias="itemType")
    payload: dict[str, Any] = Field(default_factory=dict)
    delivery_envelope: dict[str, Any] = Field(default_factory=dict, alias="deliveryEnvelope")

    model_config = {"populate_by_name": True}


class AgentOnboardingItemPullResponse(BaseModel):
    items: list[AgentOnboardingItemRecord] = Field(default_factory=list)
    next_cursor: str | None = Field(default=None, alias="nextCursor")

    model_config = {"populate_by_name": True}


class AgentOnboardingItemAckPayload(BaseModel):
    receipt_id: str = Field(alias="receiptId")
    status: str
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class AgentOnboardingItemResultPayload(BaseModel):
    status: str
    result: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"populate_by_name": True}


class AgentConnectedAccountStatusPayload(BaseModel):
    platform_id: str = Field(alias="platformId")
    provider_account_id: str = Field(alias="providerAccountId")
    status: str
    status_reason: str | None = Field(default=None, alias="statusReason")
    provider_account_label: str | None = Field(default=None, alias="providerAccountLabel")
    connection_name: str | None = Field(default=None, alias="connectionName")

    model_config = {"populate_by_name": True}


class ProjectWorkflowStageResultPayload(BaseModel):
    target_installation_id: str = Field(alias="targetInstallationId")
    board_id: str = Field(alias="boardId")
    stage_id: str = Field(alias="stageId")
    artifact_kind: str = Field(alias="artifactKind")
    content_text: str = Field(alias="contentText")
    requesting_user_id: str = Field(alias="requestingUserId")
    local_case_id: str | None = Field(default=None, alias="localCaseId")

    model_config = {"populate_by_name": True}


class ProjectAgentInstallationStatusPayload(BaseModel):
    target_installation_id: str = Field(alias="targetInstallationId")
    project_id: str = Field(alias="projectId")
    project_agent_id: str = Field(alias="projectAgentId")
    installed_version: int | None = Field(default=None, alias="installedVersion")
    install_status: str = Field(alias="installStatus")
    applied_prompt_hash: str | None = Field(default=None, alias="appliedPromptHash")
    applied_skill_set_hash: str | None = Field(default=None, alias="appliedSkillSetHash")
    last_error: str | None = Field(default=None, alias="lastError")

    model_config = {"populate_by_name": True}
