from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import JSON, DateTime, Enum, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from workagent.db.base import Base
from workagent.db.enums import (
    AgentConnectedAccountStatus,
    AgentOnboardingItemStatus,
    AgentOnboardingItemType,
    AgentPendingItemStatus,
    AgentPendingItemType,
    AgentSessionMode,
    AgentSessionStatus,
    AgentWriteDraftKind,
    AgentWriteDraftStatus,
    CaseSource,
    CaseStatus,
    ConnectorType,
    ExecutionEngine,
    ReviewCommandStatus,
    ReviewDecisionType,
)


def _utcnow() -> datetime:
    return datetime.now(UTC)


class Case(Base):
    __tablename__ = "cases"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    source: Mapped[CaseSource] = mapped_column(Enum(CaseSource), index=True)
    status: Mapped[CaseStatus] = mapped_column(Enum(CaseStatus), index=True)
    connector_type: Mapped[ConnectorType | None] = mapped_column(Enum(ConnectorType), index=True, nullable=True)
    title: Mapped[str] = mapped_column(String(500))
    summary: Mapped[str | None] = mapped_column(Text(), nullable=True)
    payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class CaseEvent(Base):
    __tablename__ = "case_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    case_id: Mapped[str] = mapped_column(ForeignKey("cases.id", ondelete="CASCADE"), index=True)
    event_type: Mapped[str] = mapped_column(String(100), index=True)
    payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class ExecutionRun(Base):
    __tablename__ = "execution_runs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    case_id: Mapped[str] = mapped_column(ForeignKey("cases.id", ondelete="CASCADE"), index=True)
    engine: Mapped[ExecutionEngine] = mapped_column(Enum(ExecutionEngine), index=True)
    status: Mapped[str] = mapped_column(String(50), index=True)
    thread_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    transcript_path: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    metadata_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class CredentialBindingMetadata(Base):
    __tablename__ = "credential_bindings_metadata"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    connector_type: Mapped[ConnectorType] = mapped_column(Enum(ConnectorType), index=True)
    base_url: Mapped[str] = mapped_column(String(500))
    secret_key: Mapped[str] = mapped_column(String(200))
    is_enabled: Mapped[bool] = mapped_column(default=True)
    last_validated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    metadata_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class ScheduledJob(Base):
    __tablename__ = "scheduled_jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(255), unique=True)
    cron_expression: Mapped[str] = mapped_column(String(100))
    is_enabled: Mapped[bool] = mapped_column(default=True)
    next_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class ReviewCommand(Base):
    __tablename__ = "review_commands"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    case_id: Mapped[str] = mapped_column(ForeignKey("cases.id", ondelete="CASCADE"), index=True)
    command_type: Mapped[ReviewDecisionType] = mapped_column(Enum(ReviewDecisionType), index=True)
    status: Mapped[ReviewCommandStatus] = mapped_column(Enum(ReviewCommandStatus), index=True)
    payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    claimed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class ReviewCommandReceipt(Base):
    __tablename__ = "review_command_receipts"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    command_id: Mapped[str] = mapped_column(ForeignKey("review_commands.id", ondelete="CASCADE"), index=True)
    receipt_type: Mapped[str] = mapped_column(String(50), index=True)
    idempotency_key: Mapped[str] = mapped_column(String(255), unique=True)
    payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class AgentSession(Base):
    __tablename__ = "agent_sessions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(String(255), index=True)
    room_id: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    thread_id: Mapped[str] = mapped_column(String(255), index=True)
    requesting_user_id: Mapped[str] = mapped_column(String(255), index=True)
    target_installation_id: Mapped[str] = mapped_column(String(255), index=True)
    local_case_id: Mapped[str | None] = mapped_column(ForeignKey("cases.id", ondelete="SET NULL"), nullable=True, index=True)
    mode: Mapped[AgentSessionMode] = mapped_column(Enum(AgentSessionMode), index=True)
    status: Mapped[AgentSessionStatus] = mapped_column(Enum(AgentSessionStatus), index=True)
    latest_user_message_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    latest_agent_message_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    current_write_draft_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    last_pending_item_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class AgentPendingItem(Base):
    __tablename__ = "agent_pending_items"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    session_id: Mapped[str | None] = mapped_column(ForeignKey("agent_sessions.id", ondelete="SET NULL"), nullable=True, index=True)
    workspace_id: Mapped[str] = mapped_column(String(255), index=True)
    target_installation_id: Mapped[str] = mapped_column(String(255), index=True)
    thread_id: Mapped[str] = mapped_column(String(255), index=True)
    message_id: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    item_type: Mapped[AgentPendingItemType] = mapped_column(Enum(AgentPendingItemType), index=True)
    status: Mapped[AgentPendingItemStatus] = mapped_column(Enum(AgentPendingItemStatus), index=True)
    payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    idempotency_key: Mapped[str] = mapped_column(String(255), unique=True)
    available_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)
    claimed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    acknowledged_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_by_user_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    error_code: Mapped[str | None] = mapped_column(String(100), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text(), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class AgentWriteDraft(Base):
    __tablename__ = "agent_write_drafts"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    session_id: Mapped[str] = mapped_column(ForeignKey("agent_sessions.id", ondelete="CASCADE"), index=True)
    draft_kind: Mapped[AgentWriteDraftKind] = mapped_column(Enum(AgentWriteDraftKind), index=True)
    target_ref_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    draft_text: Mapped[str] = mapped_column(Text())
    draft_payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    status: Mapped[AgentWriteDraftStatus] = mapped_column(Enum(AgentWriteDraftStatus), index=True)
    proposed_by_message_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    approved_by_user_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    approval_message_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    execution_result_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class AgentPendingItemReceipt(Base):
    __tablename__ = "agent_pending_item_receipts"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    pending_item_id: Mapped[str] = mapped_column(ForeignKey("agent_pending_items.id", ondelete="CASCADE"), index=True)
    target_installation_id: Mapped[str] = mapped_column(String(255), index=True)
    local_case_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    receipt_type: Mapped[str] = mapped_column(String(50), index=True)
    receipt_status: Mapped[str] = mapped_column(String(50), index=True)
    result_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class AgentOnboardingItem(Base):
    __tablename__ = "agent_onboarding_items"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(String(255), index=True)
    target_installation_id: Mapped[str] = mapped_column(String(255), index=True)
    item_type: Mapped[AgentOnboardingItemType] = mapped_column(Enum(AgentOnboardingItemType), index=True)
    status: Mapped[AgentOnboardingItemStatus] = mapped_column(Enum(AgentOnboardingItemStatus), index=True)
    payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    delivery_envelope_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    idempotency_key: Mapped[str] = mapped_column(String(255), unique=True)
    available_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)
    claimed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    acknowledged_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class AgentConnectedAccount(Base):
    __tablename__ = "agent_connected_accounts"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(String(255), index=True)
    target_installation_id: Mapped[str] = mapped_column(String(255), index=True)
    platform_id: Mapped[str] = mapped_column(String(100), index=True)
    provider_account_id: Mapped[str] = mapped_column(String(255), index=True)
    provider_account_label: Mapped[str | None] = mapped_column(String(255), nullable=True)
    connection_name: Mapped[str] = mapped_column(String(255))
    status: Mapped[AgentConnectedAccountStatus] = mapped_column(Enum(AgentConnectedAccountStatus), index=True)
    scope_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_delivered_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_validated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class SyncCursor(Base):
    __tablename__ = "sync_cursors"

    connector_type: Mapped[str] = mapped_column(String(50), primary_key=True)
    cursor_value: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    metadata_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class AuditEvent(Base):
    __tablename__ = "audit_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    event_type: Mapped[str] = mapped_column(String(100), index=True)
    entity_type: Mapped[str] = mapped_column(String(100), index=True)
    entity_id: Mapped[str] = mapped_column(String(100), index=True)
    payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class AppSetting(Base):
    __tablename__ = "app_settings"

    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class ProjectAgentDefinition(Base):
    __tablename__ = "project_agent_definitions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    workspace_id: Mapped[str] = mapped_column(String(255), index=True)
    target_installation_id: Mapped[str] = mapped_column(String(255), index=True)
    project_id: Mapped[str] = mapped_column(String(255), index=True)
    project_agent_id: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(100), index=True)
    execution_mode: Mapped[str] = mapped_column(String(100), index=True)
    shared_prompt_text: Mapped[str | None] = mapped_column(Text(), nullable=True)
    fixed_prompt_text: Mapped[str | None] = mapped_column(Text(), nullable=True)
    pinned_skill_ids_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    allowed_skill_ids_json: Mapped[list[str]] = mapped_column(JSON, default=list)
    desired_version: Mapped[int] = mapped_column(Integer, default=1)
    desired_prompt_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    desired_skill_set_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    observed_install_status: Mapped[str] = mapped_column(String(50), default="not_installed", index=True)
    observed_prompt_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    observed_skill_set_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text(), nullable=True)
    updated_by_onboarding_item_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)
