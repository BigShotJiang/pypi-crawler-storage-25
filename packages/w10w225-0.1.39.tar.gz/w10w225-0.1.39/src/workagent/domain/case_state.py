from __future__ import annotations

from dataclasses import dataclass

from workagent.db.enums import CaseStatus

CASE_ALLOWED_TRANSITIONS: dict[CaseStatus, set[CaseStatus]] = {
    CaseStatus.new: {
        CaseStatus.queued_for_local_run,
        CaseStatus.interactive_queued,
        CaseStatus.manual_required,
        CaseStatus.failed,
    },
    CaseStatus.queued_for_local_run: {CaseStatus.researching, CaseStatus.manual_required, CaseStatus.failed},
    CaseStatus.interactive_queued: {CaseStatus.interactive_running, CaseStatus.manual_required, CaseStatus.failed},
    CaseStatus.interactive_running: {
        CaseStatus.clarification_needed,
        CaseStatus.ready_to_execute,
        CaseStatus.manual_required,
        CaseStatus.failed,
    },
    CaseStatus.clarification_needed: {CaseStatus.waiting_user_reply, CaseStatus.manual_required, CaseStatus.failed},
    CaseStatus.waiting_user_reply: {
        CaseStatus.ready_to_execute,
        CaseStatus.expired,
        CaseStatus.manual_required,
        CaseStatus.failed,
    },
    CaseStatus.ready_to_execute: {CaseStatus.draft_ready, CaseStatus.manual_required, CaseStatus.failed},
    CaseStatus.researching: {CaseStatus.draft_ready, CaseStatus.manual_required, CaseStatus.failed},
    CaseStatus.draft_ready: {
        CaseStatus.awaiting_review,
        CaseStatus.awaiting_send_approval,
        CaseStatus.manual_required,
        CaseStatus.failed,
    },
    CaseStatus.awaiting_send_approval: {
        CaseStatus.ready_to_execute,
        CaseStatus.executing_approved_action,
        CaseStatus.rejected,
        CaseStatus.expired,
        CaseStatus.manual_required,
        CaseStatus.failed,
    },
    CaseStatus.executing_approved_action: {CaseStatus.completed, CaseStatus.manual_required, CaseStatus.failed},
    CaseStatus.awaiting_review: {
        CaseStatus.revising,
        CaseStatus.approved_to_send,
        CaseStatus.rejected,
        CaseStatus.manual_required,
        CaseStatus.failed,
    },
    CaseStatus.revising: {CaseStatus.researching, CaseStatus.awaiting_review, CaseStatus.manual_required, CaseStatus.failed},
    CaseStatus.approved_to_send: {CaseStatus.sending, CaseStatus.manual_required, CaseStatus.failed},
    CaseStatus.sending: {CaseStatus.sent, CaseStatus.manual_required, CaseStatus.failed},
    CaseStatus.sent: set(),
    CaseStatus.completed: set(),
    CaseStatus.rejected: set(),
    CaseStatus.expired: set(),
    CaseStatus.manual_required: {CaseStatus.queued_for_local_run, CaseStatus.rejected, CaseStatus.failed},
    CaseStatus.failed: {CaseStatus.queued_for_local_run, CaseStatus.manual_required},
}

TERMINAL_CASE_STATUSES: set[CaseStatus] = {
    CaseStatus.sent,
    CaseStatus.completed,
    CaseStatus.rejected,
    CaseStatus.expired,
}


@dataclass(frozen=True, slots=True)
class InvalidCaseTransitionError(ValueError):
    code: str
    from_status: CaseStatus
    to_status: CaseStatus

    def __str__(self) -> str:
        return f"{self.code}: {self.from_status.value} -> {self.to_status.value}"


def assert_case_transition_allowed(from_status: CaseStatus, to_status: CaseStatus) -> None:
    allowed = CASE_ALLOWED_TRANSITIONS.get(from_status, set())
    if to_status in allowed:
        return
    raise InvalidCaseTransitionError(
        code="INVALID_CASE_STATUS_TRANSITION",
        from_status=from_status,
        to_status=to_status,
    )


def is_terminal_case_status(status: CaseStatus) -> bool:
    return status in TERMINAL_CASE_STATUSES
