from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path

import tomli_w

from workagent.config.env import resolve_workagent_home
from workagent.config.models import AppConfig


@dataclass(frozen=True, slots=True)
class ConfigPaths:
    root_dir: Path
    config_file: Path
    runs_dir: Path
    logs_dir: Path
    data_dir: Path
    tmp_dir: Path
    artifacts_dir: Path
    pid_file: Path
    log_file: Path


def default_config_paths(home_dir: Path | None = None) -> ConfigPaths:
    root_dir = resolve_workagent_home(home_override=home_dir)
    runs_dir = root_dir / "runs"
    logs_dir = root_dir / "logs"
    data_dir = root_dir / "data"
    tmp_dir = root_dir / "tmp"
    artifacts_dir = root_dir / "artifacts"
    return ConfigPaths(
        root_dir=root_dir,
        config_file=root_dir / "config.toml",
        runs_dir=runs_dir,
        logs_dir=logs_dir,
        data_dir=data_dir,
        tmp_dir=tmp_dir,
        artifacts_dir=artifacts_dir,
        pid_file=runs_dir / "daemon.pid",
        log_file=logs_dir / "daemon.log",
    )


class ConfigStore:
    def __init__(self, paths: ConfigPaths):
        self.paths = paths

    def exists(self) -> bool:
        return self.paths.config_file.exists()

    def load(self) -> AppConfig | None:
        if not self.exists():
            return None
        with self.paths.config_file.open("rb") as handle:
            data = tomllib.load(handle)
        return AppConfig.model_validate(data)

    def save(self, config: AppConfig) -> None:
        self.paths.root_dir.mkdir(parents=True, exist_ok=True)
        self.paths.runs_dir.mkdir(parents=True, exist_ok=True)
        self.paths.logs_dir.mkdir(parents=True, exist_ok=True)
        self.paths.data_dir.mkdir(parents=True, exist_ok=True)
        self.paths.tmp_dir.mkdir(parents=True, exist_ok=True)
        self.paths.artifacts_dir.mkdir(parents=True, exist_ok=True)
        payload = config.model_dump(mode="json", exclude_none=True)
        self.paths.config_file.write_text(tomli_w.dumps(payload), encoding="utf-8")


class FileAppConfigStore(ConfigStore):
    def __init__(self, config_file: Path):
        root_dir = config_file.parent
        paths = ConfigPaths(
            root_dir=root_dir,
            config_file=config_file,
            runs_dir=root_dir / "runs",
            logs_dir=root_dir / "logs",
            data_dir=root_dir / "data",
            tmp_dir=root_dir / "tmp",
            artifacts_dir=root_dir / "artifacts",
            pid_file=(root_dir / "runs" / "daemon.pid"),
            log_file=(root_dir / "logs" / "daemon.log"),
        )
        super().__init__(paths)
