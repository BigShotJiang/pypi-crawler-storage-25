from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field, model_validator


class Platform(StrEnum):
    SLACK = "slack"
    JIRA = "jira"
    CONFLUENCE = "confluence"
    GITLAB = "gitlab"
    NOTION = "notion"
    LINEAR = "linear"
    GMAIL = "gmail"
    GOOGLE_CALENDAR = "google_calendar"
    GOOGLE_DRIVE = "google_drive"
    TRELLO = "trello"
    ASANA = "asana"
    DISCORD = "discord"
    MICROSOFT_TEAMS = "microsoft_teams"
    ZENDESK = "zendesk"


class ConnectorConfig(BaseModel):
    base_url: str = Field(min_length=1, alias="baseUrl")
    api_base_url: str | None = Field(default=None, alias="apiBaseUrl")
    secret_key: str = Field(default="", alias="secretKey")

    model_config = {"populate_by_name": True}


class SlackTargetMode(StrEnum):
    dms_only = "dms_only"
    dms_and_mentions = "dms_and_mentions"
    selected_channels = "selected_channels"


class EngineName(StrEnum):
    codex_cli = "codex_cli"
    copilot_cli = "copilot_cli"
    claude_cli = "claude_cli"
    gemini_cli = "gemini_cli"
    openai_api = "openai_api"
    anthropic_api = "anthropic_api"
    gemini_api = "gemini_api"


class CodexAuthMode(StrEnum):
    chatgpt = "chatgpt"
    api_key = "api_key"


class CopilotAuthMode(StrEnum):
    device_login = "device_login"
    github_token = "github_token"


class CodexCliSettings(BaseModel):
    command: str = Field(default="codex", min_length=1)
    model: str | None = None
    profile: str | None = None
    reasoning_effort: str = Field(default="medium", alias="reasoningEffort")
    auth_mode: CodexAuthMode = Field(default=CodexAuthMode.chatgpt, alias="authMode")
    model_code: str | None = Field(default=None, alias="modelCode")
    reasoning_effort_code: str | None = Field(default=None, alias="reasoningEffortCode")

    model_config = {"populate_by_name": True}


class CopilotCliSettings(BaseModel):
    command: str = Field(default="copilot", min_length=1)
    model: str | None = None
    auth_mode: CopilotAuthMode = Field(default=CopilotAuthMode.device_login, alias="authMode")
    model_code: str | None = Field(default=None, alias="modelCode")

    model_config = {"populate_by_name": True}


class ClaudeCliSettings(BaseModel):
    """Settings for the locally-installed Claude Code CLI (Anthropic)."""

    command: str = Field(default="claude", min_length=1)
    model: str | None = None
    model_code: str | None = Field(default=None, alias="modelCode")

    model_config = {"populate_by_name": True}


class GeminiCliSettings(BaseModel):
    """Settings for the locally-installed Google Gemini CLI."""

    command: str = Field(default="gemini", min_length=1)
    model: str | None = None
    model_code: str | None = Field(default=None, alias="modelCode")

    model_config = {"populate_by_name": True}


class ProviderApiSettings(BaseModel):
    model: str
    base_url: str = Field(alias="baseUrl", min_length=1)
    model_code: str | None = Field(default=None, alias="modelCode")

    model_config = {"populate_by_name": True}


class EngineSettings(BaseModel):
    default_engine: EngineName = Field(default=EngineName.codex_cli, alias="defaultEngine")
    codex_cli: CodexCliSettings = Field(default_factory=CodexCliSettings, alias="codexCli")
    copilot_cli: CopilotCliSettings = Field(default_factory=CopilotCliSettings, alias="copilotCli")
    claude_cli: ClaudeCliSettings = Field(default_factory=ClaudeCliSettings, alias="claudeCli")
    gemini_cli: GeminiCliSettings = Field(default_factory=GeminiCliSettings, alias="geminiCli")
    openai_api: ProviderApiSettings = Field(
        default_factory=lambda: ProviderApiSettings(model="gpt-5.4", baseUrl="https://api.openai.com/v1"),
        alias="openaiApi",
    )
    anthropic_api: ProviderApiSettings = Field(
        default_factory=lambda: ProviderApiSettings(model="claude-sonnet-4-6", baseUrl="https://api.anthropic.com"),
        alias="anthropicApi",
    )
    gemini_api: ProviderApiSettings = Field(
        default_factory=lambda: ProviderApiSettings(model="gemini-2.5-pro", baseUrl="https://generativelanguage.googleapis.com/v1beta"),
        alias="geminiApi",
    )

    model_config = {"populate_by_name": True}


class RuntimeSettings(BaseModel):
    daemon_interval_seconds: int = Field(default=5, alias="daemonIntervalSeconds", ge=1, le=3600)

    model_config = {"populate_by_name": True}


class SlackSyncSettings(BaseModel):
    poll_interval_seconds: int = Field(default=30, alias="pollIntervalSeconds", ge=5, le=3600)
    lookback_window_minutes: int = Field(default=60, alias="lookbackWindowMinutes", ge=1, le=24 * 60)
    target_mode: SlackTargetMode = Field(default=SlackTargetMode.dms_and_mentions, alias="targetMode")
    channel_ids: list[str] = Field(default_factory=list, alias="channelIds")
    history_limit: int = Field(default=50, alias="historyLimit", ge=1, le=200)

    model_config = {"populate_by_name": True}


class GitLabSyncSettings(BaseModel):
    poll_interval_seconds: int = Field(default=60, alias="pollIntervalSeconds", ge=5, le=3600)
    lookback_window_minutes: int = Field(default=120, alias="lookbackWindowMinutes", ge=1, le=24 * 60)
    activity_limit: int = Field(default=20, alias="activityLimit", ge=1, le=100)

    model_config = {"populate_by_name": True}


class ReviewSettings(BaseModel):
    bot_sender_user_id: str = Field(default="w10w225bot", alias="botSenderUserId", min_length=1)
    bot_sender_user_nickname: str = Field(default="w10w225bot", alias="botSenderUserNickname", min_length=1)
    topic_lookback_minutes: int = Field(default=7 * 24 * 60, alias="topicLookbackMinutes", ge=1, le=30 * 24 * 60)

    model_config = {"populate_by_name": True}


class WatchProfilePreset(StrEnum):
    personal_inbox = "personal_inbox"
    scoped_team_watch = "scoped_team_watch"
    custom = "custom"


class WatchProfile(BaseModel):
    enabled: bool = True
    platform: Platform
    preset: WatchProfilePreset
    scope: dict[str, object] = Field(default_factory=dict)
    personal_signals: list[str] = Field(default_factory=list, alias="personalSignals")
    optional_keywords: list[str] = Field(default_factory=list, alias="optionalKeywords")
    poll_interval: int = Field(default=60, alias="pollInterval", ge=5, le=24 * 60 * 60)
    lookback_window: int = Field(default=120, alias="lookbackWindow", ge=1, le=7 * 24 * 60)

    model_config = {"populate_by_name": True}


class LauncherLanguage(StrEnum):
    en = "en"
    ko = "ko"


class LocalSettings(BaseModel):
    """Settings for the agent's access to the local environment."""

    workspace_dirs: list[str] = Field(default_factory=list, alias="workspaceDirs")
    launcher_language: LauncherLanguage = Field(default=LauncherLanguage.en, alias="launcherLanguage")
    model_config = {"populate_by_name": True}


class AppConfig(BaseModel):
    version: int = 1
    connectors: dict[str, ConnectorConfig] = Field(default_factory=dict)
    runtime: RuntimeSettings = Field(default_factory=RuntimeSettings)
    engine: EngineSettings = Field(default_factory=EngineSettings)
    slack_sync: SlackSyncSettings = Field(default_factory=SlackSyncSettings, alias="slackSync")
    gitlab_sync: GitLabSyncSettings = Field(default_factory=GitLabSyncSettings, alias="gitlabSync")
    review: ReviewSettings = Field(default_factory=ReviewSettings)
    watch_profiles: dict[str, list[WatchProfile]] = Field(default_factory=dict, alias="watchProfiles")
    local: LocalSettings = Field(default_factory=LocalSettings)

    @property
    def workspace_dirs(self) -> list[str]:
        return self.local.workspace_dirs

    model_config = {"populate_by_name": True}

    @model_validator(mode="before")
    @classmethod
    def _normalize_platforms_input(cls, value: object) -> object:
        if not isinstance(value, dict):
            return value
        if "platforms" not in value or "connectors" in value:
            return value
        raw_platforms = value.get("platforms")
        if not isinstance(raw_platforms, dict):
            return value
        connectors: dict[str, dict[str, str]] = {}
        for raw_key, raw_config in raw_platforms.items():
            if isinstance(raw_key, Platform):
                key = raw_key.value
            else:
                key = Platform(raw_key).value
            if isinstance(raw_config, ConnectorConfig):
                connectors[key] = raw_config.model_dump(mode="json", by_alias=True)
            elif isinstance(raw_config, dict):
                payload = dict(raw_config)
                payload.setdefault("secretKey", "")
                connectors[key] = payload
        next_value = dict(value)
        next_value.pop("platforms", None)
        next_value["connectors"] = connectors
        return next_value

    def connector_items(self) -> list[tuple[Platform, ConnectorConfig]]:
        items: list[tuple[Platform, ConnectorConfig]] = []
        for raw_key, value in self.connectors.items():
            items.append((Platform(raw_key), value))
        return items

    @property
    def platforms(self) -> dict[Platform, ConnectorConfig]:
        return {platform: connector for platform, connector in self.connector_items()}


SupportedPlatform = Platform
PlatformConfig = ConnectorConfig

# Convenience aliases for code that prefers lowercase enum attribute access.
Platform.slack = Platform.SLACK  # type: ignore[attr-defined]
Platform.jira = Platform.JIRA  # type: ignore[attr-defined]
Platform.confluence = Platform.CONFLUENCE  # type: ignore[attr-defined]
Platform.gitlab = Platform.GITLAB  # type: ignore[attr-defined]
Platform.notion = Platform.NOTION  # type: ignore[attr-defined]
Platform.linear = Platform.LINEAR  # type: ignore[attr-defined]
Platform.gmail = Platform.GMAIL  # type: ignore[attr-defined]
Platform.google_calendar = Platform.GOOGLE_CALENDAR  # type: ignore[attr-defined]
Platform.google_drive = Platform.GOOGLE_DRIVE  # type: ignore[attr-defined]
Platform.trello = Platform.TRELLO  # type: ignore[attr-defined]
Platform.asana = Platform.ASANA  # type: ignore[attr-defined]
Platform.discord = Platform.DISCORD  # type: ignore[attr-defined]
Platform.microsoft_teams = Platform.MICROSOFT_TEAMS  # type: ignore[attr-defined]
Platform.zendesk = Platform.ZENDESK  # type: ignore[attr-defined]
