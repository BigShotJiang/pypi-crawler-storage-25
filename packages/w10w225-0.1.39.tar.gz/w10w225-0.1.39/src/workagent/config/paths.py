from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from workagent.config.env import resolve_workagent_home


@dataclass(frozen=True, slots=True)
class AppPaths:
    root: Path
    config_file: Path
    data_dir: Path
    logs_dir: Path
    runs_dir: Path
    tmp_dir: Path
    artifacts_dir: Path
    daemon_pid_file: Path


def resolve_app_paths(*, home_override: str | Path | None = None) -> AppPaths:
    root = resolve_workagent_home(home_override=home_override)
    return AppPaths(
        root=root,
        config_file=root / "config.toml",
        data_dir=root / "data",
        logs_dir=root / "logs",
        runs_dir=root / "runs",
        tmp_dir=root / "tmp",
        artifacts_dir=root / "artifacts",
        daemon_pid_file=root / "runs" / "daemon.pid",
    )


def ensure_app_directories(paths: AppPaths) -> None:
    for directory in (
        paths.root,
        paths.data_dir,
        paths.logs_dir,
        paths.runs_dir,
        paths.tmp_dir,
        paths.artifacts_dir,
    ):
        directory.mkdir(parents=True, exist_ok=True)
