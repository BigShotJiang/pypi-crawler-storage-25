from __future__ import annotations

import os
from pathlib import Path

SUPPORTED_ENV_KEYS = {
    "WORKAGENT_HOME",
    "WORKAGENT_REVIEW_BASE_URL",
    "WORKAGENT_REVIEW_SHARED_SECRET",
    "WORKAGENT_TARGET_INSTALLATION_ID",
    # Local environment settings
    "WORKAGENT_WORKSPACE_DIRS",   # colon-separated paths: /home/user/code/a:/home/user/code/b
    "WORKAGENT_ALLOWED_COMMANDS", # comma-separated command prefixes: git,python,pytest,npm
    "WORKAGENT_BLOCKED_COMMANDS", # comma-separated blocked patterns: sudo,rm ,mv
}


def _strip_wrapping_quotes(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        return value[1:-1]
    return value


def _default_dotenv_dir() -> Path:
    return Path(__file__).resolve().parents[3]


def load_dotenv_values(*, cwd: Path | None = None) -> dict[str, str]:
    base_dir = cwd or Path.cwd()
    env_file = base_dir / ".env"
    if not env_file.exists():
        return {}
    values: dict[str, str] = {}
    for raw_line in env_file.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key not in SUPPORTED_ENV_KEYS:
            continue
        values[key] = _strip_wrapping_quotes(value.strip())
    return values


def get_supported_env_value(name: str, *, cwd: Path | None = None) -> str | None:
    process_value = os.environ.get(name, "").strip()
    if process_value:
        return process_value
    dotenv_values = load_dotenv_values(cwd=cwd)
    dotenv_value = dotenv_values.get(name, "").strip()
    return dotenv_value or None


def _get_supported_env_value_with_fallback(name: str, *, cwd: Path | None = None) -> str | None:
    primary = get_supported_env_value(name, cwd=cwd)
    if primary:
        return primary
    fallback_cwd = _default_dotenv_dir()
    if cwd is not None and Path(cwd).resolve() == fallback_cwd:
        return None
    return get_supported_env_value(name, cwd=fallback_cwd)


def load_local_env_overrides(*, cwd: Path | None = None) -> dict[str, list[str]]:
    """Read WORKAGENT_WORKSPACE_DIRS from env or .env.

    Returns a dict with key 'workspace_dirs'.
    Value is an empty list if the env var is not set (meaning: no override).
    """
    raw_dirs = _get_supported_env_value_with_fallback("WORKAGENT_WORKSPACE_DIRS", cwd=cwd) or ""

    def _split_paths(raw: str) -> list[str]:
        parts = [p.strip() for p in raw.replace(",", ":").split(":") if p.strip()]
        return [str(Path(p).expanduser().resolve()) for p in parts if p]

    return {
        "workspace_dirs": _split_paths(raw_dirs),
    }


def resolve_workagent_home(*, home_override: str | Path | None = None, cwd: Path | None = None) -> Path:
    if home_override is not None:
        return Path(home_override).expanduser()

    root_raw = os.environ.get("WORKAGENT_HOME", "").strip()
    return Path(root_raw).expanduser() if root_raw else Path.home() / ".personal-work-agent"


def resolve_legacy_workagent_skills_home(*, home_override: str | Path | None = None, cwd: Path | None = None) -> Path:
    return resolve_workagent_home(home_override=home_override, cwd=cwd) / "skills"


def resolve_agents_skills_home() -> Path:
    return Path.home() / ".agents" / "skills"


def detect_legacy_workagent_skills_home(*, home_override: str | Path | None = None, cwd: Path | None = None) -> Path | None:
    legacy_root = resolve_legacy_workagent_skills_home(home_override=home_override, cwd=cwd)
    canonical_root = resolve_agents_skills_home()
    if legacy_root == canonical_root:
        return None
    if legacy_root.exists():
        return legacy_root
    return None
