from __future__ import annotations

import os
from pathlib import Path
from uuid import uuid4

from workagent.config.env import get_supported_env_value, resolve_workagent_home

INSTALLATION_ID_ENV_KEY = "WORKAGENT_TARGET_INSTALLATION_ID"
INSTALLATION_ID_FILENAME = "installation-id"

AGENT_SECRET_FILENAME = "agent-secret"


def installation_id_file(*, home_dir: str | Path | None = None, cwd: Path | None = None) -> Path:
    return resolve_workagent_home(home_override=home_dir, cwd=cwd) / INSTALLATION_ID_FILENAME


def load_installation_id(*, home_dir: str | Path | None = None, cwd: Path | None = None) -> str | None:
    configured = get_supported_env_value(INSTALLATION_ID_ENV_KEY, cwd=cwd)
    if configured:
        return configured
    path = installation_id_file(home_dir=home_dir, cwd=cwd)
    if not path.exists():
        return None
    value = path.read_text(encoding="utf-8").strip()
    return value or None


def ensure_installation_id(*, home_dir: str | Path | None = None, cwd: Path | None = None) -> str:
    existing = load_installation_id(home_dir=home_dir, cwd=cwd)
    if existing:
        return existing
    path = installation_id_file(home_dir=home_dir, cwd=cwd)
    path.parent.mkdir(parents=True, exist_ok=True)
    installation_id = str(uuid4())
    path.write_text(f"{installation_id}\n", encoding="utf-8")
    return installation_id


def agent_secret_file(*, home_dir: str | Path | None = None, cwd: Path | None = None) -> Path:
    return resolve_workagent_home(home_override=home_dir, cwd=cwd) / AGENT_SECRET_FILENAME


def load_agent_secret(*, home_dir: str | Path | None = None, cwd: Path | None = None) -> str | None:
    """Load the per-user agent secret from file. Returns None if not yet generated."""
    path = agent_secret_file(home_dir=home_dir, cwd=cwd)
    if not path.exists():
        return None
    value = path.read_text(encoding="utf-8").strip()
    return value or None


def ensure_agent_secret(*, home_dir: str | Path | None = None, cwd: Path | None = None) -> str:
    """Return existing secret or generate a new random one and persist it."""
    existing = load_agent_secret(home_dir=home_dir, cwd=cwd)
    if existing:
        agent_secret_file(home_dir=home_dir, cwd=cwd).chmod(0o600)
        return existing
    path = agent_secret_file(home_dir=home_dir, cwd=cwd)
    path.parent.mkdir(parents=True, exist_ok=True)
    secret = os.urandom(32).hex()  # 64-char hex, 256-bit entropy
    path.write_text(f"{secret}\n", encoding="utf-8")
    path.chmod(0o600)  # owner read/write only
    return secret
