from __future__ import annotations

import asyncio


class LocalRunQueue:
    def __init__(self) -> None:
        self._queue: asyncio.Queue[str] = asyncio.Queue()
        self._pending: set[str] = set()
        self._inflight: set[str] = set()

    @property
    def depth(self) -> int:
        return self._queue.qsize()

    async def enqueue(self, case_id: str) -> None:
        if case_id in self._pending or case_id in self._inflight:
            return
        self._pending.add(case_id)
        await self._queue.put(case_id)

    async def dequeue(self) -> str:
        case_id = await self._queue.get()
        self._pending.discard(case_id)
        self._inflight.add(case_id)
        return case_id

    async def complete(self, case_id: str) -> None:
        self._inflight.discard(case_id)
