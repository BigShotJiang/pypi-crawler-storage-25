from __future__ import annotations

import sys
from dataclasses import dataclass

import questionary


@dataclass(frozen=True, slots=True)
class Choice:
    label: str
    value: str
    checked: bool = False


@dataclass(frozen=True, slots=True)
class MenuOption:
    label: str
    value: str


class UIBackend:
    def choose_checkbox(self, prompt: str, choices: list[Choice]) -> list[str]:
        raise NotImplementedError

    def choose_menu(self, prompt: str, options: list[MenuOption]) -> str:
        raise NotImplementedError

    def ask_text(self, prompt: str, *, secret: bool = False, default: str | None = None) -> str:
        raise NotImplementedError

    def show_message(self, message: str) -> None:
        raise NotImplementedError


class QuestionaryUI(UIBackend):
    def choose_checkbox(self, prompt: str, choices: list[Choice]) -> list[str]:
        questionary_choices = [
            questionary.Choice(title=item.label, value=item.value, checked=item.checked)
            for item in choices
        ]
        return list(questionary.checkbox(prompt, choices=questionary_choices).ask() or [])

    def choose_menu(self, prompt: str, options: list[MenuOption]) -> str:
        questionary_choices = [questionary.Choice(title=item.label, value=item.value) for item in options]
        question = questionary.select(prompt, choices=questionary_choices)
        try:
            answer = question.unsafe_ask()
        except (KeyboardInterrupt, EOFError):
            return self._plain_choose_menu(prompt, options)
        if answer in (None, ""):
            return self._plain_choose_menu(prompt, options)
        return str(answer)

    def ask_text(self, prompt: str, *, secret: bool = False, default: str | None = None) -> str:
        if secret:
            return str(questionary.password(prompt).ask() or "")
        return str(questionary.text(prompt, default=default or "").ask() or "")

    def show_message(self, message: str) -> None:
        print(message)

    def _plain_choose_menu(self, prompt: str, options: list[MenuOption]) -> str:
        if not self._interactive_stdio_available():
            raise RuntimeError("Interactive terminal input is unavailable.")
        while True:
            print(prompt)
            for index, option in enumerate(options, start=1):
                print(f"{index}. {option.label}")
            try:
                raw = input("> ").strip()
            except (KeyboardInterrupt, EOFError) as exc:
                raise RuntimeError("Interactive prompt cancelled.") from exc
            if not raw:
                continue
            if raw.isdigit():
                selected_index = int(raw)
                if 1 <= selected_index <= len(options):
                    return options[selected_index - 1].value
            for option in options:
                if raw == option.value:
                    return option.value
            print("Invalid selection. Enter a number from the list.")

    def _interactive_stdio_available(self) -> bool:
        stdin_isatty = getattr(sys.stdin, "isatty", lambda: False)
        stdout_isatty = getattr(sys.stdout, "isatty", lambda: False)
        return bool(stdin_isatty() and stdout_isatty())


class FakeUI(UIBackend):
    def __init__(
        self,
        *,
        checkbox_answers: list[list[str]] | None = None,
        menu_answers: list[str] | None = None,
        text_answers: list[str] | None = None,
    ) -> None:
        self.checkbox_answers = checkbox_answers or []
        self.menu_answers = menu_answers or []
        self.text_answers = text_answers or []
        self.messages: list[str] = []

    def choose_checkbox(self, prompt: str, choices: list[Choice]) -> list[str]:
        return self.checkbox_answers.pop(0)

    def choose_menu(self, prompt: str, options: list[MenuOption]) -> str:
        return self.menu_answers.pop(0)

    def ask_text(self, prompt: str, *, secret: bool = False, default: str | None = None) -> str:
        return self.text_answers.pop(0)

    def show_message(self, message: str) -> None:
        self.messages.append(message)
