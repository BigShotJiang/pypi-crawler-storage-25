from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field

logger = logging.getLogger("workagent.daemon_loop")


@dataclass(slots=True)
class PeriodicDaemonLoop:
    tick_runtime: object
    interval_seconds: float = 5.0
    _stop_event: asyncio.Event = field(default_factory=asyncio.Event, init=False)

    @property
    def stopped(self) -> bool:
        return self._stop_event.is_set()

    def stop(self) -> None:
        self._stop_event.set()

    async def run_once(self) -> object:
        return await self.tick_runtime.run_once()

    async def run_forever(self) -> None:
        while not self._stop_event.is_set():
            try:
                await self.run_once()
            except Exception:  # noqa: BLE001
                logger.exception("daemon loop tick failed")
            try:
                await asyncio.wait_for(self._stop_event.wait(), timeout=self.interval_seconds)
            except TimeoutError:
                continue
