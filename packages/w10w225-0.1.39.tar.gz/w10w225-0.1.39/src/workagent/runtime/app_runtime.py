from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Protocol


class SlackLoopLike(Protocol):
    async def run_once(self): ...


class GitLabLoopLike(Protocol):
    async def run_once(self): ...


class JiraLoopLike(Protocol):
    async def run_once(self): ...


class ConfluenceLoopLike(Protocol):
    async def run_once(self): ...


class NotionLoopLike(Protocol):
    async def run_once(self): ...


class AsanaLoopLike(Protocol):
    async def run_once(self): ...


class LinearLoopLike(Protocol):
    async def run_once(self): ...


class GmailLoopLike(Protocol):
    async def run_once(self): ...


class GoogleCalendarLoopLike(Protocol):
    async def run_once(self): ...


class GoogleDriveLoopLike(Protocol):
    async def run_once(self): ...


class ZendeskLoopLike(Protocol):
    async def run_once(self): ...


class DiscordLoopLike(Protocol):
    async def run_once(self): ...


class MicrosoftTeamsLoopLike(Protocol):
    async def run_once(self): ...


class GenericPlatformLoopLike(Protocol):
    async def run_once(self): ...


class ReviewRuntimeLike(Protocol):
    async def run_cycle(self): ...


class SchedulerRuntimeLike(Protocol):
    async def run_once(self, now: datetime): ...


class WorkerRuntimeLike(Protocol):
    async def run_once(self, *, wait: bool = False): ...


class OutboundProcessorLike(Protocol):
    async def process_once(self): ...


class PendingRuntimeLike(Protocol):
    async def run_cycle(self): ...


class OnboardingRuntimeLike(Protocol):
    async def run_cycle(self): ...


@dataclass(frozen=True, slots=True)
class AppRuntimeSummary:
    slack_created_cases: int
    gitlab_created_cases: int
    jira_created_cases: int
    confluence_created_cases: int
    notion_created_cases: int
    asana_created_cases: int
    linear_created_cases: int
    review_completed_commands: int
    review_failed_commands: int
    runnable_jobs: int
    worker_processed_case_id: str | None
    outbound_sent: int
    outbound_failed: int
    pending_items_completed: int = 0
    pending_items_failed: int = 0
    onboarding_items_completed: int = 0
    onboarding_items_failed: int = 0
    gmail_created_cases: int = 0
    google_calendar_created_cases: int = 0
    google_drive_created_cases: int = 0
    zendesk_created_cases: int = 0
    discord_created_cases: int = 0
    microsoft_teams_created_cases: int = 0
    platform_created_cases: dict[str, int] = field(default_factory=dict)


class AppRuntime:
    def __init__(
        self,
        *,
        slack_loop: SlackLoopLike,
        gitlab_loop: GitLabLoopLike,
        jira_loop: JiraLoopLike,
        confluence_loop: ConfluenceLoopLike,
        review_runtime: ReviewRuntimeLike,
        scheduler_runtime: SchedulerRuntimeLike,
        worker_runtime: WorkerRuntimeLike,
        outbound_processor: OutboundProcessorLike,
        notion_loop: NotionLoopLike | None = None,
        asana_loop: AsanaLoopLike | None = None,
        linear_loop: LinearLoopLike | None = None,
        gmail_loop: GmailLoopLike | None = None,
        google_calendar_loop: GoogleCalendarLoopLike | None = None,
        google_drive_loop: GoogleDriveLoopLike | None = None,
        zendesk_loop: ZendeskLoopLike | None = None,
        discord_loop: DiscordLoopLike | None = None,
        microsoft_teams_loop: MicrosoftTeamsLoopLike | None = None,
        extra_platform_loops: dict[str, GenericPlatformLoopLike] | None = None,
        pending_runtime: PendingRuntimeLike | None = None,
        onboarding_runtime: OnboardingRuntimeLike | None = None,
    ) -> None:
        self.slack_loop = slack_loop
        self.gitlab_loop = gitlab_loop
        self.jira_loop = jira_loop
        self.confluence_loop = confluence_loop
        self.notion_loop = notion_loop
        self.asana_loop = asana_loop
        self.linear_loop = linear_loop
        self.gmail_loop = gmail_loop
        self.google_calendar_loop = google_calendar_loop
        self.google_drive_loop = google_drive_loop
        self.zendesk_loop = zendesk_loop
        self.discord_loop = discord_loop
        self.microsoft_teams_loop = microsoft_teams_loop
        self.extra_platform_loops = dict(extra_platform_loops or {})
        for platform_key, loop in self.extra_platform_loops.items():
            setattr(self, f"{platform_key}_loop", loop)
        self.review_runtime = review_runtime
        self.scheduler_runtime = scheduler_runtime
        self.worker_runtime = worker_runtime
        self.outbound_processor = outbound_processor
        self.pending_runtime = pending_runtime
        self.onboarding_runtime = onboarding_runtime

    async def run_once(self) -> AppRuntimeSummary:
        now = datetime.now(UTC)
        slack_summary = await self.slack_loop.run_once()
        gitlab_summary = await self.gitlab_loop.run_once()
        jira_summary = await self.jira_loop.run_once()
        confluence_summary = await self.confluence_loop.run_once()
        notion_summary = (
            await self.notion_loop.run_once()
            if self.notion_loop is not None
            else type("NotionSummary", (), {"created_cases": 0})()
        )
        asana_summary = (
            await self.asana_loop.run_once()
            if self.asana_loop is not None
            else type("AsanaSummary", (), {"created_cases": 0})()
        )
        linear_summary = (
            await self.linear_loop.run_once()
            if self.linear_loop is not None
            else type("LinearSummary", (), {"created_cases": 0})()
        )
        gmail_summary = (
            await self.gmail_loop.run_once()
            if self.gmail_loop is not None
            else type("GmailSummary", (), {"created_cases": 0})()
        )
        google_calendar_summary = (
            await self.google_calendar_loop.run_once()
            if self.google_calendar_loop is not None
            else type("GoogleCalendarSummary", (), {"created_cases": 0})()
        )
        google_drive_summary = (
            await self.google_drive_loop.run_once()
            if self.google_drive_loop is not None
            else type("GoogleDriveSummary", (), {"created_cases": 0})()
        )
        zendesk_summary = (
            await self.zendesk_loop.run_once()
            if self.zendesk_loop is not None
            else type("ZendeskSummary", (), {"created_cases": 0})()
        )
        discord_summary = (
            await self.discord_loop.run_once()
            if self.discord_loop is not None
            else type("DiscordSummary", (), {"created_cases": 0})()
        )
        microsoft_teams_summary = (
            await self.microsoft_teams_loop.run_once()
            if self.microsoft_teams_loop is not None
            else type("MicrosoftTeamsSummary", (), {"created_cases": 0})()
        )
        extra_platform_counts: dict[str, int] = {}
        for platform_key, loop in self.extra_platform_loops.items():
            extra_summary = await loop.run_once()
            extra_platform_counts[platform_key] = int(getattr(extra_summary, "created_cases", 0))
        review_summary = await self.review_runtime.run_cycle()
        pending_summary = (
            await self.pending_runtime.run_cycle()
            if self.pending_runtime is not None
            else type("PendingSummary", (), {"completed_items": 0, "failed_items": 0})()
        )
        onboarding_summary = (
            await self.onboarding_runtime.run_cycle()
            if self.onboarding_runtime is not None
            else type("OnboardingSummary", (), {"completed_items": 0, "failed_items": 0})()
        )
        scheduler_summary = await self.scheduler_runtime.run_once(now)
        worker_case = await self.worker_runtime.run_once(wait=False)
        outbound_results = await self.outbound_processor.process_once()

        return AppRuntimeSummary(
            slack_created_cases=int(slack_summary.created_cases),
            gitlab_created_cases=int(gitlab_summary.created_cases),
            jira_created_cases=int(jira_summary.created_cases),
            confluence_created_cases=int(confluence_summary.created_cases),
            notion_created_cases=int(notion_summary.created_cases),
            asana_created_cases=int(asana_summary.created_cases),
            linear_created_cases=int(linear_summary.created_cases),
            gmail_created_cases=int(gmail_summary.created_cases),
            google_calendar_created_cases=int(google_calendar_summary.created_cases),
            google_drive_created_cases=int(google_drive_summary.created_cases),
            zendesk_created_cases=int(zendesk_summary.created_cases),
            discord_created_cases=int(discord_summary.created_cases),
            microsoft_teams_created_cases=int(microsoft_teams_summary.created_cases),
            platform_created_cases={
                "slack": int(slack_summary.created_cases),
                "gitlab": int(gitlab_summary.created_cases),
                "jira": int(jira_summary.created_cases),
                "confluence": int(confluence_summary.created_cases),
                "notion": int(notion_summary.created_cases),
                "asana": int(asana_summary.created_cases),
                "linear": int(linear_summary.created_cases),
                "gmail": int(gmail_summary.created_cases),
                "google_calendar": int(google_calendar_summary.created_cases),
                "google_drive": int(google_drive_summary.created_cases),
                "zendesk": int(zendesk_summary.created_cases),
                "discord": int(discord_summary.created_cases),
                "microsoft_teams": int(microsoft_teams_summary.created_cases),
                **extra_platform_counts,
            },
            review_completed_commands=int(review_summary.completed_commands),
            review_failed_commands=int(review_summary.failed_commands),
            runnable_jobs=len(scheduler_summary.runnable_jobs),
            worker_processed_case_id=worker_case,
            outbound_sent=sum(1 for item in outbound_results if item == "sent"),
            outbound_failed=sum(1 for item in outbound_results if item == "failed"),
            pending_items_completed=int(pending_summary.completed_items),
            pending_items_failed=int(pending_summary.failed_items),
            onboarding_items_completed=int(onboarding_summary.completed_items),
            onboarding_items_failed=int(onboarding_summary.failed_items),
        )
