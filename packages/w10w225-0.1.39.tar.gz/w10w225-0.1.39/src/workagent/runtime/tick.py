from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path

logger = logging.getLogger("workagent.tick")

# WBS 8-3-1: rotate secret every 7 days
_SECRET_ROTATION_INTERVAL = timedelta(days=7)


@dataclass(frozen=True, slots=True)
class DaemonTickSummary:
    runtime_cycle_executed: bool
    pushed_case_count: int
    secret_rotated: bool = False


class SecretRotationService:
    """WBS 8-3-1, 8-3-2: Periodic agent secret rotation.

    Checks whether the current agent secret was rotated more than 7 days ago.
    If so, calls ``POST /api/v2/assistant/agent-pairing/rotate-secret`` to
    obtain a new secret and persists it locally.
    """

    def __init__(self, *, home_dir: Path | None = None) -> None:
        self._home_dir = home_dir or (Path.home() / ".personal-work-agent")
        self._last_check: datetime | None = None

    @property
    def _timestamp_file(self) -> Path:
        return self._home_dir / "secret-rotated-at"

    @property
    def _secret_file(self) -> Path:
        return self._home_dir / "agent-secret"

    def _read_last_rotation(self) -> datetime | None:
        path = self._timestamp_file
        if not path.exists():
            return None
        raw = path.read_text(encoding="utf-8").strip()
        if not raw:
            return None
        try:
            return datetime.fromisoformat(raw)
        except (ValueError, TypeError):
            return None

    def _write_last_rotation(self, ts: datetime) -> None:
        path = self._timestamp_file
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(ts.isoformat() + "\n", encoding="utf-8")

    def _write_secret(self, secret: str) -> None:
        import os

        path = self._secret_file
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(secret.strip() + "\n", encoding="utf-8")
        os.chmod(path, 0o600)

    def _needs_rotation(self) -> bool:
        last = self._read_last_rotation()
        if last is None:
            # No rotation timestamp -- seed it with current time and skip this cycle
            self._write_last_rotation(datetime.now(UTC))
            return False
        return datetime.now(UTC) - last > _SECRET_ROTATION_INTERVAL

    async def maybe_rotate(self) -> bool:
        """Check and rotate secret if due. Returns True if rotation occurred."""
        # Throttle checks: at most once per hour within the tick loop
        now = datetime.now(UTC)
        if self._last_check is not None and (now - self._last_check) < timedelta(hours=1):
            return False
        self._last_check = now

        if not self._needs_rotation():
            return False

        try:
            from workagent.cli_tools.nk304_api_client import Nk304ApiClient, Nk304TokenError

            client = Nk304ApiClient.from_env(home_dir=self._home_dir)
            result = await client.post_with_hmac("/api/v2/assistant/agent-pairing/rotate-secret")
            new_secret = str(result.get("new_secret") or result.get("secret") or result.get("newSecret") or "").strip()
            if not new_secret:
                logger.warning("secret rotation response missing secret field: %s", list(result.keys()))
                return False
            self._write_secret(new_secret)
            self._write_last_rotation(datetime.now(UTC))
            # Update the client's cached secret reference for future calls
            logger.info("agent secret rotated successfully")
            return True
        except Exception:
            logger.exception("agent secret rotation failed")
            return False


class DaemonTickRuntime:
    def __init__(
        self,
        *,
        runtime_loop,  # noqa: ANN001
        review_push_service,  # noqa: ANN001
        secret_rotation: SecretRotationService | None = None,
    ) -> None:
        self.runtime_loop = runtime_loop
        self.review_push_service = review_push_service
        self.secret_rotation = secret_rotation or SecretRotationService()

    async def run_once(self) -> DaemonTickSummary:
        await self.runtime_loop.run_cycle()
        pushed = await self.review_push_service.push_ready_cases()
        secret_rotated = await self.secret_rotation.maybe_rotate()
        return DaemonTickSummary(
            runtime_cycle_executed=True,
            pushed_case_count=len(pushed),
            secret_rotated=secret_rotated,
        )
