from __future__ import annotations

import asyncio
from typing import Protocol

from workagent.runtime.queue import LocalRunQueue


class CaseProcessor(Protocol):
    async def process(self, case_id: str) -> None: ...


class LocalWorkerRuntime:
    def __init__(
        self,
        *,
        queue: LocalRunQueue,
        processor: CaseProcessor,
        max_concurrency: int = 1,
    ) -> None:
        self.queue = queue
        self.processor = processor
        self.max_concurrency = max(1, int(max_concurrency))

    async def run_once(self, *, wait: bool = True) -> str | None:
        case_ids = await self._dequeue_batch(wait=wait)
        if not case_ids:
            return None

        results = await asyncio.gather(
            *(self._process_case(case_id) for case_id in case_ids),
            return_exceptions=True,
        )
        for result in results:
            if isinstance(result, Exception):
                raise result
        return case_ids[0]

    async def _dequeue_batch(self, *, wait: bool) -> list[str]:
        if not wait and self.queue.depth == 0:
            return []

        case_ids: list[str] = [await self.queue.dequeue()]
        while len(case_ids) < self.max_concurrency and self.queue.depth > 0:
            case_ids.append(await self.queue.dequeue())
        return case_ids

    async def _process_case(self, case_id: str) -> None:
        try:
            await self.processor.process(case_id)
        finally:
            await self.queue.complete(case_id)
