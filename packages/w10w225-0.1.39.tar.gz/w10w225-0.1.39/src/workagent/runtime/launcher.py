from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Protocol

from workagent.config.models import AppConfig, PlatformConfig, SupportedPlatform
from workagent.config.store import FileAppConfigStore, SecretStore


class LauncherMode(StrEnum):
    first_run = "first_run"
    daemon_running = "daemon_running"
    daemon_stopped = "daemon_stopped"


class LauncherAction(StrEnum):
    start_background = "start_background"
    restart_background = "restart_background"
    stop_background = "stop_background"
    reconfigure = "reconfigure"
    status = "status"
    exit = "exit"


class PromptAdapter(Protocol):
    def choose_platforms(self, options: list[SupportedPlatform], defaults: list[SupportedPlatform]) -> list[SupportedPlatform]:
        ...

    def ask_base_url(self, platform: SupportedPlatform, default: str | None = None) -> str: ...

    def ask_api_token(self, platform: SupportedPlatform) -> str: ...

    def choose_menu_action(self, daemon_running: bool) -> LauncherAction: ...

    def show_message(self, message: str) -> None: ...


class DaemonController(Protocol):
    def is_running(self) -> bool: ...

    def start_background(self) -> None: ...

    def stop(self) -> None: ...

    def restart_background(self) -> None: ...


class PlatformValidator(Protocol):
    def validate(self, platform: SupportedPlatform, base_url: str, token: str) -> None: ...


@dataclass(slots=True)
class NoopValidator:
    def validate(self, platform: SupportedPlatform, base_url: str, token: str) -> None:  # noqa: ARG002
        if not base_url.strip():
            raise ValueError(f"{platform.value} base URL is required")
        if not token.strip():
            raise ValueError(f"{platform.value} API key is required")


def resolve_launcher_mode(config_exists: bool, daemon_running: bool) -> LauncherMode:
    if not config_exists:
        return LauncherMode.first_run
    return LauncherMode.daemon_running if daemon_running else LauncherMode.daemon_stopped


def available_menu_actions(daemon_running: bool) -> list[LauncherAction]:
    if daemon_running:
        return [
            LauncherAction.restart_background,
            LauncherAction.stop_background,
            LauncherAction.reconfigure,
            LauncherAction.status,
            LauncherAction.exit,
        ]
    return [
        LauncherAction.start_background,
        LauncherAction.reconfigure,
        LauncherAction.status,
        LauncherAction.exit,
    ]


def run_first_time_setup(
    *,
    prompt: PromptAdapter,
    config_store: FileAppConfigStore,
    secret_store: SecretStore,
    validator: PlatformValidator,
    daemon: DaemonController,
    existing_config: AppConfig | None = None,
) -> AppConfig:
    defaults = list(existing_config.platforms.keys()) if existing_config is not None else []
    selected = prompt.choose_platforms(list(SupportedPlatform), defaults)
    platform_configs: dict[SupportedPlatform, PlatformConfig] = {}
    for platform in selected:
        current = existing_config.platforms.get(platform) if existing_config is not None else None
        base_url = prompt.ask_base_url(platform, current.base_url.unicode_string() if current else None)
        token = prompt.ask_api_token(platform)
        validator.validate(platform, base_url, token)
        platform_configs[platform] = PlatformConfig(baseUrl=base_url)
        secret_store.set_token(platform, token)
    config = AppConfig(platforms=platform_configs)
    config_store.save(config)
    daemon.start_background()
    prompt.show_message("Configuration saved. Background daemon started.")
    return config


def run_launcher(
    *,
    prompt: PromptAdapter,
    config_store: FileAppConfigStore,
    secret_store: SecretStore,
    validator: PlatformValidator,
    daemon: DaemonController,
) -> int:
    config = config_store.load()
    mode = resolve_launcher_mode(config_store.exists(), daemon.is_running())
    if mode == LauncherMode.first_run:
        run_first_time_setup(
            prompt=prompt,
            config_store=config_store,
            secret_store=secret_store,
            validator=validator,
            daemon=daemon,
        )
        return 0
    action = prompt.choose_menu_action(mode == LauncherMode.daemon_running)
    if action == LauncherAction.start_background:
        daemon.start_background()
    elif action == LauncherAction.restart_background:
        daemon.restart_background()
    elif action == LauncherAction.stop_background:
        daemon.stop()
    elif action == LauncherAction.reconfigure:
        run_first_time_setup(
            prompt=prompt,
            config_store=config_store,
            secret_store=secret_store,
            validator=validator,
            daemon=daemon,
            existing_config=config,
        )
    elif action == LauncherAction.status:
        prompt.show_message("running" if daemon.is_running() else "stopped")
    return 0

