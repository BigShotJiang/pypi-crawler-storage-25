from __future__ import annotations

import json
import os
import platform
from abc import ABC, abstractmethod
from pathlib import Path

import keyring


class SecretStore(ABC):
    @abstractmethod
    def save(self, key: str, value: str) -> None:
        raise NotImplementedError

    @abstractmethod
    def get(self, key: str) -> str | None:
        raise NotImplementedError

    @abstractmethod
    def delete(self, key: str) -> None:
        raise NotImplementedError


class KeyringSecretStore(SecretStore):
    def __init__(self, service_name: str = "personal-work-agent"):
        self.service_name = service_name

    def save(self, key: str, value: str) -> None:
        keyring.set_password(self.service_name, key, value)

    def get(self, key: str) -> str | None:
        return keyring.get_password(self.service_name, key)

    def delete(self, key: str) -> None:
        keyring.delete_password(self.service_name, key)


class FileSecretStore(SecretStore):
    def __init__(self, path: Path):
        self.path = path

    def _load(self) -> dict[str, str]:
        if not self.path.exists():
            return {}
        return json.loads(self.path.read_text(encoding="utf-8"))

    def _write(self, payload: dict[str, str]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(payload, sort_keys=True), encoding="utf-8")
        os.chmod(self.path, 0o600)

    def save(self, key: str, value: str) -> None:
        payload = self._load()
        payload[key] = value
        self._write(payload)

    def get(self, key: str) -> str | None:
        return self._load().get(key)

    def delete(self, key: str) -> None:
        payload = self._load()
        payload.pop(key, None)
        self._write(payload)


class MemorySecretStore(SecretStore):
    def __init__(self) -> None:
        self._values: dict[str, str] = {}

    def save(self, key: str, value: str) -> None:
        self._values[key] = value

    def get(self, key: str) -> str | None:
        return self._values.get(key)

    def delete(self, key: str) -> None:
        self._values.pop(key, None)


def _detect_secret_store_platform() -> str:
    return platform.system().lower()


def build_default_secret_store(*, home_dir: Path) -> SecretStore:
    platform_name = _detect_secret_store_platform()
    if platform_name == "darwin":
        return KeyringSecretStore()
    return FileSecretStore(home_dir / "secrets.json")
