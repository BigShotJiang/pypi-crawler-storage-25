from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RuntimeCycleSummary:
    pending_sync_total: int
    pending_sync_completed: int
    pending_sync_failed: int
    onboarding_sync_total: int
    onboarding_sync_completed: int
    onboarding_sync_failed: int
    routed_request: bool


class WorkAgentRuntimeLoop:
    def __init__(
        self,
        *,
        pending_sync,
        onboarding_sync,
        request_router,
    ) -> None:
        self.pending_sync = pending_sync
        self.onboarding_sync = onboarding_sync
        self.request_router = request_router

    async def run_cycle(self) -> RuntimeCycleSummary:
        pending_summary = await self.pending_sync.run_cycle()
        onboarding_summary = await self.onboarding_sync.run_cycle()
        routed = await self.request_router.process_next()
        return RuntimeCycleSummary(
            pending_sync_total=pending_summary.total_items,
            pending_sync_completed=pending_summary.completed_items,
            pending_sync_failed=pending_summary.failed_items,
            onboarding_sync_total=onboarding_summary.total_items,
            onboarding_sync_completed=onboarding_summary.completed_items,
            onboarding_sync_failed=onboarding_summary.failed_items,
            routed_request=routed,
        )
