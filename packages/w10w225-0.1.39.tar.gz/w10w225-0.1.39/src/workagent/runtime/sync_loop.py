from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from workagent.config.models import SlackTargetMode
from workagent.connectors.gitlab_sync import GitLabSyncBatch, GitLabSyncEvent
from workagent.connectors.slack_sync import SlackFetchResponse, SlackSyncEvent
from workagent.runtime.queue import LocalRunQueue


class SlackCursorStore(Protocol):
    async def load(self) -> str | None: ...

    async def save(self, cursor: str | None) -> None: ...


class SlackClientLike(Protocol):
    def list_conversations(self, *, token: str, limit: int = 100, types: str = "im,public_channel"): ...

    def fetch_recent(self, *, token: str, channel_id: str, cursor: str | None = None, limit: int = 50) -> SlackFetchResponse: ...


class SlackIngestLike(Protocol):
    async def ingest(self, events: list[SlackSyncEvent]) -> list[str]: ...


class GitLabSyncServiceLike(Protocol):
    async def sync_once(self) -> GitLabSyncBatch: ...

    async def commit(self, batch: GitLabSyncBatch) -> None: ...


class GitLabIngestLike(Protocol):
    async def ingest(self, events: list[GitLabSyncEvent]) -> list[str]: ...


@dataclass(frozen=True, slots=True)
class SlackSyncLoopSummary:
    polled_channels: int
    polled_events: int
    created_cases: int


@dataclass(frozen=True, slots=True)
class GitLabSyncLoopSummary:
    polled_events: int
    created_cases: int
    next_cursor: str | None


class SlackSyncLoop:
    def __init__(
        self,
        *,
        client: SlackClientLike,
        token: str,
        cursor_store_factory,
        ingest_service: SlackIngestLike,
        queue: LocalRunQueue,
        limit: int = 50,
        target_mode: SlackTargetMode = SlackTargetMode.dms_and_mentions,
        selected_channel_ids: list[str] | None = None,
        optional_keywords: list[str] | None = None,
    ) -> None:
        self.client = client
        self.token = token
        self.cursor_store_factory = cursor_store_factory
        self.ingest_service = ingest_service
        self.queue = queue
        self.limit = limit
        self.target_mode = target_mode
        self.selected_channel_ids = set(selected_channel_ids or [])
        self.optional_keywords = [item.strip().lower() for item in (optional_keywords or []) if item.strip()]

    async def run_once(self) -> SlackSyncLoopSummary:
        channels = self.client.list_conversations(token=self.token, types=self._conversation_types())
        channels = [channel for channel in channels if self._should_poll_channel(channel)]
        polled_events = 0
        created_cases = 0
        for channel in channels:
            channel_id = str(channel.get("id") or "").strip()
            if not channel_id:
                continue
            cursor_store = self.cursor_store_factory(channel_id)
            previous_cursor = await cursor_store.load()
            response = self.client.fetch_recent(
                token=self.token,
                channel_id=channel_id,
                cursor=previous_cursor,
                limit=self.limit,
            )
            events = [
                SlackSyncEvent(
                    event_type="thread_reply" if message.thread_ts else "message",
                    channel_id=message.channel_id,
                    message_ts=message.message_ts,
                    thread_ts=message.thread_ts,
                    user_id=message.user_id,
                    text=message.text,
                )
                for message in response.messages
                if self._should_process_message(
                    channel_id=message.channel_id,
                    text=message.text,
                    channel=channel,
                )
            ]
            polled_events += len(events)
            case_ids = await self.ingest_service.ingest(events)
            created_cases += len(case_ids)
            for case_id in case_ids:
                await self.queue.enqueue(case_id)
            await cursor_store.save(response.next_cursor if response.next_cursor is not None else previous_cursor)
        return SlackSyncLoopSummary(
            polled_channels=len(channels),
            polled_events=polled_events,
            created_cases=created_cases,
        )

    def _conversation_types(self) -> str:
        if self.target_mode == SlackTargetMode.dms_only:
            return "im"
        if self.target_mode == SlackTargetMode.selected_channels:
            return "public_channel"
        return "im,public_channel"

    def _should_poll_channel(self, channel: dict) -> bool:
        channel_id = str(channel.get("id") or "").strip()
        is_im = bool(channel.get("is_im")) or channel_id.startswith("D")
        if self.target_mode == SlackTargetMode.dms_only:
            return is_im
        if self.target_mode == SlackTargetMode.selected_channels:
            return channel_id in self.selected_channel_ids
        return True

    def _should_process_message(self, *, channel_id: str, text: str, channel: dict) -> bool:
        if self.optional_keywords:
            normalized_text = text.lower()
            if not any(keyword in normalized_text for keyword in self.optional_keywords):
                return False
        is_im = bool(channel.get("is_im")) or channel_id.startswith("D")
        if self.target_mode == SlackTargetMode.dms_only:
            return is_im
        if self.target_mode == SlackTargetMode.selected_channels:
            return channel_id in self.selected_channel_ids
        if is_im:
            return True
        return "<@" in text or "@" in text


class GitLabSyncLoop:
    def __init__(
        self,
        *,
        sync_service: GitLabSyncServiceLike,
        ingest_service: GitLabIngestLike,
        queue: LocalRunQueue,
    ) -> None:
        self.sync_service = sync_service
        self.ingest_service = ingest_service
        self.queue = queue

    async def run_once(self) -> GitLabSyncLoopSummary:
        batch = await self.sync_service.sync_once()
        case_ids = await self.ingest_service.ingest(batch.events)
        for case_id in case_ids:
            await self.queue.enqueue(case_id)
        await self.sync_service.commit(batch)
        return GitLabSyncLoopSummary(
            polled_events=len(batch.events),
            created_cases=len(case_ids),
            next_cursor=batch.next_cursor,
        )
