# External System Integration Skills

Each subdirectory contains a `SKILL.md` file that teaches the AI agent how to interact with that platform via the `w10w225` CLI.

## Available Platforms

| Platform | Directory | Description |
|----------|-----------|-------------|
| Slack | `slack/` | Messaging, channel management, search |
| Jira | `jira/` | Issue tracking, project management |
| GitLab | `gitlab/` | Source control, MRs, pipelines |
| Confluence | `confluence/` | Documentation, wiki pages |
| Notion | `notion/` | Pages, databases |
| Linear | `linear/` | Issue tracking |
| Gmail | `gmail/` | Email read, send, search |
| Discord | `discord/` | Messaging, channels |
| Google Calendar | `google-calendar/` | Events, scheduling |
| Google Drive | `google-drive/` | File management |
| Asana | `asana/` | Task management |
| Zendesk | `zendesk/` | Support tickets |
| Microsoft Teams | `microsoft-teams/` | Messaging, channels |
| Trello | `trello/` | Card management |

## Skill Activation

Skills are automatically pushed to local agents when a user connects the corresponding platform in nk304 AI Agent settings.
