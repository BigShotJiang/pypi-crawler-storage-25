# w10w225 Skills

Skills are instruction sets that teach the AI agent how to use tools and perform tasks.

## Directory Structure

```
skills/
├── README.md              ← This file
└── external/              ← External system integration skills
    ├── README.md           ← Platform list and overview
    ├── slack/SKILL.md
    ├── jira/SKILL.md
    ├── gitlab/SKILL.md
    └── ...
```

## How Skills Work

1. Admin registers skill content in nk304 Admin > AI Skills
2. When a user connects a platform, the corresponding skill is pushed to their local agent
3. Skills are stored at `~/.personal-work-agent/skills/external/{platform}/SKILL.md`
4. The AI agent reads the skill and uses `w10w225` CLI commands as described
