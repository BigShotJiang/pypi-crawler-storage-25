"""
OneX MCP Server

Model Context Protocol server that exposes OneX CLI commands as tools
for AI assistants to investigate issues, debug services, and manage the platform.

Usage:
    onex-mcp  # Runs stdio-based MCP server for Claude Desktop

Architecture:
    - Calls platform APIs directly via httpx (no subprocess overhead)
    - Works on Windows, macOS, and Linux without PATH issues
    - Async-native for non-blocking execution
    - Comprehensive error handling
    - Structured output for AI consumption
"""

import json
import sys
import socket
from pathlib import Path
from typing import Optional

try:
    import httpx
except ImportError:
    # httpx is already a dependency of onex-cli
    print("Error: httpx not installed", file=sys.stderr)
    sys.exit(1)

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    print("Error: MCP package not installed", file=sys.stderr)
    print("Install with: pip install -e '.[mcp]'", file=sys.stderr)
    sys.exit(1)


# Initialize MCP server
mcp = FastMCP("onex-platform")


# =============================================================================
# CONFIG HELPERS (inline to avoid import side effects)
# =============================================================================

def _get_onex_dir() -> Path:
    """Get ~/.onex directory"""
    return Path.home() / '.onex'


def get_active_environment() -> str:
    """Get active environment from ~/.onex/active-env, fallback to 'local'"""
    try:
        active_file = _get_onex_dir() / 'active-env'
        if active_file.exists():
            return active_file.read_text().strip()
    except Exception:
        pass
    return 'local'


def _load_environment_config(env: str) -> dict:
    """Load environment config from ~/.onex/environments.json"""
    try:
        env_file = _get_onex_dir() / 'environments.json'
        if env_file.exists():
            with env_file.open() as f:
                data = json.load(f)
            return data.get(env, {})
    except Exception:
        pass
    return {}


def _get_platform_url(env: str) -> str:
    """Get platform URL for environment"""
    env_data = _load_environment_config(env)
    if env_data.get('platform_url'):
        return env_data['platform_url']

    # Fallback defaults
    defaults = {
        'local': 'http://localhost:8000',
        'dev': 'http://10.0.0.1:8000',
        'staging': 'http://10.0.1.1:8000',
        'prod': 'http://10.0.2.1:8000',
    }
    return defaults.get(env, 'http://localhost:8000')


def _get_access_token(env: str) -> Optional[str]:
    """Get access token for environment"""
    env_data = _load_environment_config(env)
    return env_data.get('access_token')


def _get_credentials(env: str) -> dict:
    """Get service credentials for environment"""
    if env == 'local':
        return {
            'mongodb_uri': 'mongodb://admin:admin123@localhost:27017/onexeos-service?authSource=admin&directConnection=true',
            'redis_uri': 'redis://:redis_dev_password_123@localhost:6379',
            'nats_url': 'nats://localhost:4222',
            'elasticsearch_url': 'http://localhost:9200',
            'minio_endpoint': 'localhost:9000',
        }
    env_data = _load_environment_config(env)
    return env_data.get('credentials', {})


def _auth_headers(env: str) -> dict:
    """Get authorization headers for API calls"""
    token = _get_access_token(env)
    if token:
        return {'Authorization': f'Bearer {token}'}
    return {}


async def _auto_refresh_token(env: str) -> bool:
    """Automatically refresh expired token using stored credentials.

    Async equivalent of onex.utils.auth.auto_refresh_token().
    Decrypts stored credentials and re-authenticates against the auth service.

    Returns True if token was refreshed successfully.
    """
    env_data = _load_environment_config(env)
    if not env_data:
        return False

    encrypted_credentials = env_data.get('encrypted_credentials')
    if not encrypted_credentials:
        return False

    try:
        from onex.utils.crypto import decrypt_credentials
        email, password = decrypt_credentials(encrypted_credentials)
    except Exception:
        return False

    platform_url = env_data.get('platform_url')
    if not platform_url:
        return False

    # Determine auth URL
    from urllib.parse import urlparse
    creds = env_data.get('credentials', {})
    if creds.get('public_auth_url'):
        auth_url = creds['public_auth_url']
    elif creds.get('auth_url'):
        auth_url = creds['auth_url']
    else:
        parsed = urlparse(platform_url)
        auth_url = f"{parsed.scheme}://{parsed.hostname}:8100"

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                f"{auth_url}/auth/login",
                json={"email": email, "password": password}
            )

        if resp.status_code != 200:
            return False

        login_data = resp.json()
        access_token = login_data.get('AccessToken') or login_data.get('access_token')
        if not access_token:
            return False

        # Update environments.json with new token
        from datetime import datetime, timedelta
        expires_in = login_data.get('ExpiresIn', 28800)
        expires_at = datetime.utcnow() + timedelta(seconds=expires_in)

        env_file = _get_onex_dir() / 'environments.json'
        if env_file.exists():
            with env_file.open() as f:
                all_envs = json.load(f)
        else:
            all_envs = {}

        if env not in all_envs:
            all_envs[env] = {}

        all_envs[env]['access_token'] = access_token
        all_envs[env]['token_type'] = login_data.get('TokenType', 'bearer')
        all_envs[env]['expires_in'] = expires_in
        all_envs[env]['expires_at'] = expires_at.isoformat() + 'Z'
        all_envs[env]['last_updated'] = datetime.utcnow().isoformat() + 'Z'

        with env_file.open('w') as f:
            json.dump(all_envs, f, indent=2)

        return True

    except Exception:
        return False


async def _authenticated_request(
    method: str,
    url: str,
    env: str,
    *,
    headers: dict = None,
    params: dict = None,
    json_body: dict = None,
    timeout: int = 30
) -> httpx.Response:
    """Make an authenticated HTTP request with automatic token refresh on 401.

    If the first request returns 401 and env != 'local', attempts to refresh
    the token and retries once.
    """
    auth = _auth_headers(env)
    merged = {**auth, **(headers or {})}

    async with httpx.AsyncClient(timeout=timeout) as client:
        kwargs = {'headers': merged}
        if params:
            kwargs['params'] = params
        if json_body is not None:
            kwargs['json'] = json_body

        resp = await getattr(client, method)(url, **kwargs)

        if resp.status_code == 401 and env != 'local':
            if await _auto_refresh_token(env):
                auth = _auth_headers(env)
                kwargs['headers'] = {**auth, **(headers or {})}
                resp = await getattr(client, method)(url, **kwargs)

    return resp


# =============================================================================
# PLATFORM TOOLS
# =============================================================================

@mcp.tool()
async def onex_platform_check(env: str = None) -> str:
    """Check OneX platform infrastructure health.

    Verifies all core platform services are running and healthy:
    - MongoDB (database)
    - Redis (cache and queues)
    - NATS (message streaming)
    - Elasticsearch (search engine)
    - MinIO (object storage)
    - Gateway (API gateway)

    This is the FIRST tool to run when investigating any issue.
    If platform services are down, nothing will work.

    Args:
        env: Environment to check (local/dev/staging/prod). Default: active environment

    Returns:
        Formatted health status of all platform services with ✅/❌ indicators

    Examples:
        User: "Is my platform healthy?"
        → onex_platform_check()

        User: "Check dev environment"
        → onex_platform_check(env="dev")
    """
    if env is None:
        env = get_active_environment()

    credentials = _get_credentials(env)
    platform_url = _get_platform_url(env)
    results = []
    all_healthy = True

    results.append(f"🔍 Checking platform infrastructure ({env})...\n")

    # Check MongoDB
    mongodb_uri = credentials.get('mongodb_uri', '')
    if mongodb_uri:
        host_part = mongodb_uri.split('@')[1].split('/')[0] if '@' in mongodb_uri else 'unknown'
        try:
            from pymongo import MongoClient
            client = MongoClient(mongodb_uri, serverSelectionTimeoutMS=5000)
            client.admin.command('ping')
            client.close()
            results.append(f"  ✅ MongoDB       {host_part:<30} Connected")
        except Exception as e:
            all_healthy = False
            results.append(f"  ❌ MongoDB       {host_part:<30} Connection failed")

    # Check Redis
    redis_uri = credentials.get('redis_uri', '')
    if redis_uri:
        host_part = redis_uri.split('@')[1] if '@' in redis_uri else redis_uri.replace('redis://', '')
        try:
            import redis
            client = redis.from_url(redis_uri, socket_connect_timeout=5)
            client.ping()
            client.close()
            results.append(f"  ✅ Redis         {host_part:<30} Connected")
        except Exception as e:
            all_healthy = False
            results.append(f"  ❌ Redis         {host_part:<30} Connection refused")

    # Check NATS
    nats_url = credentials.get('nats_url', '')
    if nats_url:
        try:
            host_port = nats_url.replace('nats://', '').split(':')
            host = host_port[0]
            port = int(host_port[1]) if len(host_port) > 1 else 4222
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            result = sock.connect_ex((host, port))
            sock.close()
            endpoint = f"{host}:{port}"
            if result == 0:
                results.append(f"  ✅ NATS          {endpoint:<30} Connected")
            else:
                all_healthy = False
                results.append(f"  ❌ NATS          {endpoint:<30} Connection refused")
        except Exception as e:
            all_healthy = False
            results.append(f"  ❌ NATS          Connection failed: {e}")

    # Check Elasticsearch
    es_url = credentials.get('elasticsearch_url', '')
    if es_url:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(es_url)
            if resp.status_code == 200:
                results.append(f"  ✅ Elasticsearch {es_url:<30} Healthy")
            else:
                all_healthy = False
                results.append(f"  ❌ Elasticsearch {es_url:<30} HTTP {resp.status_code}")
        except Exception as e:
            all_healthy = False
            results.append(f"  ❌ Elasticsearch Connection failed: {e}")

    # Check MinIO
    minio_endpoint = credentials.get('minio_endpoint', '')
    if minio_endpoint:
        try:
            url = f"http://{minio_endpoint}/minio/health/live"
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(url)
            if resp.status_code == 200:
                results.append(f"  ✅ MinIO         {minio_endpoint:<30} Healthy")
            else:
                all_healthy = False
                results.append(f"  ❌ MinIO         {minio_endpoint:<30} HTTP {resp.status_code}")
        except Exception as e:
            all_healthy = False
            results.append(f"  ❌ MinIO         Connection failed: {e}")

    # Check Gateway
    if platform_url:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{platform_url}/health")
            if resp.status_code == 200:
                results.append(f"  ✅ Gateway       {platform_url:<30} Healthy")
            else:
                all_healthy = False
                results.append(f"  ❌ Gateway       {platform_url:<30} HTTP {resp.status_code}")
        except Exception as e:
            all_healthy = False
            results.append(f"  ❌ Gateway       Connection failed: {e}")

    # Summary
    results.append("")
    if all_healthy:
        results.append("Platform Status: ✅ All services healthy")
    else:
        results.append("Platform Status: ⚠️  Some services unavailable")

    return "\n".join(results)


# =============================================================================
# DEBUGGING TOOLS
# =============================================================================

@mcp.tool()
async def onex_trace(
    trace_id: str,
    env: str = None,
    follow: bool = False,
    json_output: bool = False
) -> str:
    """Track a request through the platform using trace_id.

    Shows complete request timeline across all services:
    - Gateway received request
    - Runtime forwarded to service
    - Service handler execution
    - Response path back to client

    Includes timestamps, durations, and error details.
    CRITICAL for debugging API failures and performance issues.

    Args:
        trace_id: Request trace ID from x-trace-id response header
        env: Environment (local/dev/staging/prod). Default: active environment
        follow: Follow trace in real-time (for long-running requests)
        json_output: Return JSON format instead of formatted text

    Returns:
        Complete request trace with timing information and errors

    Examples:
        User: "Why did this API call fail? trace_id: 550e8400-e29b-41d4-a716-446655440000"
        → onex_trace(trace_id="550e8400-e29b-41d4-a716-446655440000")

        User: "Trace this request in dev"
        → onex_trace(trace_id="...", env="dev")
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)

    try:
        # Query Loki directly — bypasses gateway auth and its internal Loki timeout
        from urllib.parse import urlparse
        parsed = urlparse(platform_url)
        loki_url = f"http://{parsed.hostname}:3100"

        from datetime import datetime, timedelta

        # Try multiple query strategies to find the trace:
        # 1. Grep across platform services (gateway, shared-runtime, triggers, etc.)
        # 2. Broader grep on container names as fallback
        # Note: trace_id is NOT a Loki label (high cardinality). It's in the log line.
        queries = [
            f'{{service=~"gateway|shared-runtime|trigger-scheduler|event-bridge|stream-trigger|s3-trigger|deployment-controller"}} |~ "{trace_id}" !~ "_internal/trace"',
            f'{{container=~".*gateway.*|.*shared-runtime.*|.*trigger.*"}} |~ "{trace_id}" !~ "_internal/trace"',
        ]

        resp = None
        now = datetime.now()
        start_ns = int((now - timedelta(hours=1)).timestamp() * 1e9)
        end_ns = int(now.timestamp() * 1e9)

        async with httpx.AsyncClient(timeout=30) as client:
            for query in queries:
                # Use query_range with 3h window (instant query misses older logs)
                resp = await client.get(
                    f"{loki_url}/loki/api/v1/query_range",
                    params={
                        'query': query,
                        'start': str(start_ns),
                        'end': str(end_ns),
                        'limit': 1000
                    }
                )
                if resp.status_code == 200:
                    peek = resp.json()
                    if peek.get('status') == 'success' and peek.get('data', {}).get('result', []):
                        break  # Found results

        if resp.status_code != 200:
            return f"Loki query failed: HTTP {resp.status_code}"

        loki_data = resp.json()
        if loki_data.get('status') != 'success':
            return f"Loki query failed: {loki_data}"

        # Parse Loki results into timeline format
        results = loki_data.get('data', {}).get('result', [])
        timeline = []
        seen = set()
        for result in results:
            stream = result.get('stream', {})
            for value in result.get('values', []):
                timestamp_ns, log_line = value
                # Deduplicate: same timestamp + log line = same log entry
                dedup_key = (timestamp_ns, log_line)
                if dedup_key in seen:
                    continue
                seen.add(dedup_key)
                try:
                    log_data = json.loads(log_line)
                except Exception:
                    log_data = {'message': log_line}

                component = stream.get('component') or stream.get('service') or log_data.get('service') or 'unknown'
                log_event = stream.get('log_event') or stream.get('event', '')
                method = stream.get('method', log_data.get('method', ''))
                path = stream.get('path', log_data.get('path', ''))
                message = log_data.get('message', log_line)
                status_code = log_data.get('status_code')
                duration_ms = log_data.get('duration_ms') or log_data.get('execution_time_ms')
                error = log_data.get('error')
                if not error and message and ' | ' in message:
                    error = message.split(' | ', 1)[1]

                timeline.append({
                    'timestamp': int(timestamp_ns) // 1000000,
                    'component': component,
                    'level': stream.get('level', log_data.get('level', 'INFO')).upper(),
                    'event': log_data.get('event', log_event),
                    'message': message,
                    'method': method,
                    'path': path,
                    'status_code': status_code,
                    'duration_ms': duration_ms,
                    'error': error,
                    'data': log_data,
                })

        timeline.sort(key=lambda x: x['timestamp'])
        total_logs = len(timeline)

        data = {'trace_id': trace_id, 'total_logs': total_logs, 'timeline': timeline}

        if json_output:
            return json.dumps(data, indent=2)

        if total_logs == 0:
            return (
                f"No logs found for trace_id: {trace_id}\n"
                "This could mean:\n"
                "  - Request hasn't been processed yet\n"
                "  - Trace_id is incorrect\n"
                "  - Logs have expired (older than 24 hours)"
            )

        # Extract request metadata from first/last logs
        req_method = ''
        req_path = ''
        req_status = ''
        req_status_code = None
        total_duration = ''
        services_seen = []

        for entry in timeline:
            m = entry.get('method', '')
            p = entry.get('path', '')
            if m and not req_method:
                req_method = m
            if p and not req_path:
                req_path = p
            sc = entry.get('status_code')
            if sc:
                req_status_code = int(sc)
            svc = entry.get('component', '') or entry.get('service', '')
            if svc and svc not in services_seen:
                services_seen.append(svc)
            dur = entry.get('duration_ms')
            if dur:
                total_duration = f"{dur}ms"

        # Format status with error classification
        if req_status_code:
            if req_status_code >= 500:
                req_status = f"{req_status_code} Server Error"
            elif req_status_code >= 400:
                req_status = f"{req_status_code} Client Error"
            else:
                req_status = f"{req_status_code} OK"
        else:
            # Fallback: check for ERROR level logs
            for entry in reversed(timeline):
                if entry.get('level', '').upper() == 'ERROR':
                    req_status = "Error"
                    break

        # Build rich header
        lines = [f"Trace: {trace_id}"]
        if req_method and req_path:
            lines.append(f"Request: {req_method} {req_path}")
        if req_status:
            lines.append(f"Status: {req_status}")
        if total_duration:
            lines.append(f"Duration: {total_duration}")
        if services_seen:
            lines.append(f"Services: {' -> '.join(services_seen)}")
        lines.append("")

        # Get first timestamp for relative offsets (millisecond integer)
        first_ts = timeline[0].get('timestamp', 0) if timeline else 0

        # Format timeline entries
        for entry in timeline:
            component = entry.get('component', '') or entry.get('service', '') or 'unknown'
            level = entry.get('level', 'INFO').upper()
            message = entry.get('message') or entry.get('event', '')
            status_code = entry.get('status_code', '')
            duration = entry.get('duration_ms', '')
            error_msg = entry.get('error', '')
            data = entry.get('data', {}) or {}
            error_type = data.get('error_type', '')
            import_error = data.get('import_error', '')
            traceback_info = data.get('traceback', '')
            fingerprint = data.get('error_fingerprint', '')
            exc_info = data.get('exception', '') or data.get('exc_info', '')

            # Calculate relative offset from millisecond timestamps
            offset_str = ''
            entry_ts = entry.get('timestamp', 0)
            if first_ts and entry_ts:
                offset_ms = entry_ts - first_ts
                if offset_ms >= 0:
                    offset_str = f"+{offset_ms}ms"

            # Format the line
            pad_offset = f"{offset_str:>8}" if offset_str else "        "
            pad_component = f"{component:<18}"
            detail = message
            if status_code and duration:
                detail += f" [{status_code}] ({duration}ms)"
            elif status_code:
                detail += f" [{status_code}]"

            lines.append(f"  {pad_offset} [{pad_component}] {level:5} {detail}")

            # Add error details on separate lines (for ERROR and WARNING levels)
            detail_indent = f"             {'':18}        "
            if error_type:
                if error_msg:
                    lines.append(f"{detail_indent}{error_type}: {error_msg}")
                else:
                    lines.append(f"{detail_indent}Type: {error_type}")
            elif error_msg and level in ('ERROR', 'WARNING'):
                lines.append(f"{detail_indent}Error: {error_msg}")
            # Show import_error detail (handler import failures from shared-runtime)
            if import_error:
                lines.append(f"{detail_indent}Detail: {import_error}")

            # Show exception/traceback — the most critical info for debugging
            if exc_info and isinstance(exc_info, str) and exc_info.strip():
                # Extract last few lines of the traceback (most useful part)
                exc_lines = exc_info.strip().splitlines()
                # Show last 5 lines (usually the raise + a few frames)
                for exc_line in exc_lines[-5:]:
                    lines.append(f"{detail_indent}{exc_line.strip()}")
            elif traceback_info:
                if isinstance(traceback_info, list):
                    for frame in traceback_info[-3:]:  # last 3 frames
                        f_file = frame.get('file', '')
                        f_func = frame.get('function', '')
                        f_line = frame.get('line', '')
                        f_code = frame.get('code', '')
                        loc = f"{f_file}:{f_line} in {f_func}()"
                        if f_code:
                            loc += f" → {f_code}"
                        lines.append(f"{detail_indent}{loc}")
                elif isinstance(traceback_info, str):
                    lines.append(f"{detail_indent}traceback: {traceback_info[:200]}")

            if fingerprint:
                lines.append(f"{detail_indent}fingerprint: {fingerprint}")

        return "\n".join(lines)

    except httpx.ConnectError:
        return f"Cannot connect to Loki at {loki_url}. Make sure observability stack is running."
    except httpx.TimeoutException:
        return f"Loki query timed out at {loki_url}. Loki may be overloaded."
    except Exception as e:
        return f"Error querying trace: {e}"


@mcp.tool()
async def onex_logs(
    service_name: str,
    env: str = None,
    lines: int = 100,
    level: str = None,
    trace_id: str = None,
    user_id: str = None,
    company_id: str = None,
    path: str = None,
    method: str = None,
    event: str = None,
    grep: str = None,
    last: str = None
) -> str:
    """View service logs from platform with powerful filtering.

    Fetches recent logs for a deployed service with advanced filtering options.
    Perfect for debugging specific issues, tracking user requests, and finding errors.

    Args:
        service_name: Name of the service (e.g., 'email-service', 'product', 'auth')
        env: Environment (local/dev/staging/prod). Default: active environment
        lines: Number of recent lines to show. Default: 100
        level: Filter by level (ERROR, WARNING, INFO, DEBUG) - comma-separated
        trace_id: Filter by trace ID to track specific request
        user_id: Filter by user ID to track specific user's activity
        company_id: Filter by company/tenant ID
        path: Filter by API path (e.g., "/auth/login")
        method: Filter by HTTP method (GET, POST, etc.)
        event: Filter by event type (service_ready, error, etc.)
        grep: Search message with regex pattern
        last: Time range (e.g., "1h", "30m", "24h")

    Returns:
        Recent log entries with timestamps and log levels, filtered by criteria

    Examples:
        User: "Show me auth errors from the last hour"
        → onex_logs(service_name="auth", level="ERROR", last="1h")

        User: "Find login attempts for user john@example.com"
        → onex_logs(service_name="auth", path="/auth/login", grep="john@example.com")

        User: "Debug this trace: abc-123-def"
        → onex_logs(service_name="auth", trace_id="abc-123-def", lines=500)

        User: "What errors happened after the 2pm deployment?"
        → onex_logs(service_name="product", level="ERROR", last="2h")

        User: "Show me all product service warnings and errors"
        → onex_logs(service_name="product", level="ERROR,WARNING", lines=200)

        User: "Track user123's activity in the last 6 hours"
        → onex_logs(service_name="auth", user_id="user123", last="6h")
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)

    try:
        # Query Loki directly for service logs (same approach as onex_trace)
        from urllib.parse import urlparse
        from datetime import datetime, timedelta
        parsed = urlparse(platform_url)
        loki_url = f"http://{parsed.hostname}:3100"

        # Build LogQL query with filters
        # trace_id is NOT a Loki label (high cardinality). Grep for it in log line.
        label_filters = []
        if trace_id:
            # Query across platform services, filter by trace_id in log line
            label_filters.append('service=~"gateway|shared-runtime|trigger-scheduler|event-bridge|stream-trigger|s3-trigger|deployment-controller"')
        else:
            # Use container label + path filter for service isolation
            label_filters.append('container="shared-runtime"')

        logql = '{' + ','.join(label_filters) + '}'

        # Add pipeline filters
        pipeline = []
        if trace_id:
            pipeline.append(f'|~ "{trace_id}"')
        # Filter by service name via path prefix (e.g. /product/... or /manufacturing/...)
        if not trace_id:
            pipeline.append(f'|~ "/{service_name}/"')
        if level:
            level_pattern = '|'.join(l.strip().lower() for l in level.split(','))
            pipeline.append(f'|~ "(?i)({level_pattern})"')
        if path:
            pipeline.append(f'|~ "{path}"')
        if method:
            pipeline.append(f'|~ "{method}"')
        if user_id:
            pipeline.append(f'|~ "{user_id}"')
        if company_id:
            pipeline.append(f'|~ "{company_id}"')
        if event:
            pipeline.append(f'|~ "{event}"')
        if grep:
            pipeline.append(f'|~ "{grep}"')

        if pipeline:
            logql += ' ' + ' '.join(pipeline)

        # Parse time range
        time_range = timedelta(hours=1)  # default 1h
        if last:
            amount = int(''.join(c for c in last if c.isdigit()) or '1')
            unit = ''.join(c for c in last if c.isalpha()).lower()
            if unit == 'h':
                time_range = timedelta(hours=amount)
            elif unit == 'm':
                time_range = timedelta(minutes=amount)
            elif unit == 'd':
                time_range = timedelta(days=amount)

        now = datetime.now()
        start_ns = int((now - time_range).timestamp() * 1e9)
        end_ns = int(now.timestamp() * 1e9)

        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                f"{loki_url}/loki/api/v1/query_range",
                params={
                    'query': logql,
                    'start': str(start_ns),
                    'end': str(end_ns),
                    'limit': lines,
                    'direction': 'backward',
                }
            )

        if resp.status_code != 200:
            return f"Loki query failed: HTTP {resp.status_code} - {resp.text[:200]}"

        loki_data = resp.json()
        if loki_data.get('status') != 'success':
            return f"Loki query failed: {loki_data}"

        # Parse and format log entries
        results = loki_data.get('data', {}).get('result', [])
        log_entries = []
        for result in results:
            for value in result.get('values', []):
                timestamp_ns, log_line = value
                try:
                    log_data = json.loads(log_line)
                except Exception:
                    log_data = {'message': log_line}
                log_entries.append({
                    'timestamp_ns': int(timestamp_ns),
                    'data': log_data,
                    'raw': log_line,
                })

        # Sort chronologically (oldest first)
        log_entries.sort(key=lambda x: x['timestamp_ns'])

        if not log_entries:
            return f"No logs found for {service_name} with the given filters."

        # Format output
        output_lines = [f"Logs for {service_name} ({env}): {len(log_entries)} entries\n"]
        for entry in log_entries:
            d = entry['data']
            ts = d.get('timestamp', '')
            if ts:
                # Trim to seconds
                ts = ts[:19]
            log_level = (d.get('level') or 'INFO').upper()
            message = d.get('message', entry['raw'][:200])
            method_str = d.get('method', '')
            path_str = d.get('path', '')
            status_code = d.get('status_code', '')
            duration = d.get('duration_ms', '')
            exc = d.get('exception', '')

            # Build concise line
            prefix = f"{ts} {log_level:5}"
            if method_str and path_str:
                detail = f"{method_str} {path_str}"
                if status_code:
                    detail += f" [{status_code}]"
                if duration:
                    detail += f" ({duration}ms)"
                output_lines.append(f"{prefix} {detail}")
            else:
                output_lines.append(f"{prefix} {message[:200]}")

            # Show exception traceback for ERROR entries
            if exc and log_level == 'ERROR':
                exc_lines = exc.strip().splitlines()
                for exc_line in exc_lines[-5:]:
                    output_lines.append(f"               {exc_line.strip()}")

        return "\n".join(output_lines)

    except httpx.ConnectError:
        return f"Cannot connect to Loki at {loki_url}. Make sure observability stack is running."
    except httpx.TimeoutException:
        return f"Loki query timed out. Try a narrower time range."
    except Exception as e:
        return f"Error fetching logs: {e}"


@mcp.tool()
async def onex_status(
    service_name: Optional[str] = None,
    env: str = None
) -> str:
    """Check service deployment status and health.

    Shows:
    - Service version and deployment time
    - Running/stopped status
    - HTTP routes registered
    - Request metrics (count, errors, latency)
    - Resource usage

    If no service_name provided, lists ALL deployed services.

    Args:
        service_name: Optional service name. If None, lists all services
        env: Environment (local/dev/staging/prod). Default: active environment

    Returns:
        Service status details or list of all services

    Examples:
        User: "What services are deployed?"
        → onex_status()

        User: "Is email-service running?"
        → onex_status(service_name="email-service")

        User: "Check product service health in dev"
        → onex_status(service_name="product", env="dev")
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)

    try:
        if service_name:
            # Check specific service
            resp = await _authenticated_request(
                'get',
                f"{platform_url}/_internal/services/{service_name}",
                env,
                timeout=10
            )

            if resp.status_code == 200:
                data = resp.json()
                lines = [
                    f"Service: {data.get('name')}",
                    f"Version: {data.get('version', 'N/A')}",
                    f"Status: {data.get('status', 'unknown')}",
                    f"Mode: {data.get('mode', 'shared')}",
                    "",
                    "Routes:",
                ]
                for route in data.get('routes', []):
                    m = route.get('method', 'GET')
                    p = route.get('path', '')
                    lines.append(f"  {m:6} {p}")

                lines.append("")
                lines.append("Metrics:")
                metrics = data.get('metrics', {})
                lines.append(f"  Requests: {metrics.get('total_requests', 0)}")
                lines.append(f"  Errors: {metrics.get('error_count', 0)}")
                lines.append(f"  Avg Response Time: {metrics.get('avg_response_time', 0):.2f}ms")
                lines.append(f"  Health: {data.get('health', 'unknown')}")

                return "\n".join(lines)

            elif resp.status_code == 401:
                return f"Authentication required. Run: onex login --env {env}"
            elif resp.status_code == 404:
                return f"Service '{service_name}' not found. Check deployed services with: onex status"
            else:
                return f"Failed to get status: HTTP {resp.status_code}"

        else:
            # List all services
            resp = await _authenticated_request(
                'get',
                f"{platform_url}/_internal/services",
                env,
                timeout=10
            )

            if resp.status_code == 200:
                data = resp.json()
                services = data.get('services', {})

                if not services:
                    return "No services deployed. Deploy a service with: onex deploy"

                lines = [f"Found {len(services)} service(s):", ""]
                lines.append(f"{'Service':<20} {'Version':<10} {'Mode':<12} {'Status':<10} {'Routes':<8}")
                lines.append("-" * 70)

                for svc_name, svc_data in services.items():
                    version = svc_data.get('version', 'N/A')
                    mode = svc_data.get('mode', 'shared')
                    status_val = svc_data.get('status', 'unknown')
                    route_count = len(svc_data.get('apis', []))
                    lines.append(f"{svc_name:<20} {version:<10} {mode:<12} {status_val:<10} {route_count:<8}")

                lines.append("")
                lines.append(f"Platform: {platform_url}")
                return "\n".join(lines)

            elif resp.status_code == 401:
                return f"Authentication required. Run: onex login --env {env}"
            else:
                return f"Failed to list services: HTTP {resp.status_code}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except httpx.TimeoutException:
        return f"Request timed out connecting to {platform_url}"
    except Exception as e:
        return f"Error checking status: {e}"


@mcp.tool()
async def onex_reload(
    service_name: str,
    env: str = None
) -> str:
    """Force reload a service in the shared runtime.

    Purges cached Python modules, reinstalls dependencies, and reloads the service.
    Use this when code changes aren't reflected after deployment, or when Python
    bytecode cache is stale.

    Args:
        service_name: Name of the service to reload (e.g. "pricing", "product")
        env: Environment (local/dev/staging/prod). Default: active environment

    Returns:
        Reload result with dependency and service load status

    Examples:
        User: "Pricing service code isn't updating after deploy"
        → onex_reload(service_name="pricing")

        User: "Force reload product service on dev"
        → onex_reload(service_name="product", env="dev")
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)

    try:
        resp = await _authenticated_request(
            'post',
            f"{platform_url}/_internal/reload/{service_name}",
            env,
            timeout=120
        )

        if resp.status_code == 200:
            data = resp.json()
            success = data.get('success', False)
            deps_installed = data.get('deps_installed', False)
            deps_details = data.get('deps_details', '')

            lines = []
            if success:
                lines.append(f"Service '{service_name}' reloaded successfully")
                lines.append(f"Dependencies: {'installed' if deps_installed else 'skipped'}")
            else:
                lines.append(f"Service '{service_name}' FAILED to reload")
                lines.append(f"Dependencies: {'installed' if deps_installed else 'failed'}")
                if deps_details:
                    lines.append(f"Details: {deps_details[:300]}")
                lines.append("Check logs: onex logs shared-runtime")

            return "\n".join(lines)

        elif resp.status_code == 401:
            return f"Authentication required. Run: onex login --env {env}"
        elif resp.status_code == 404:
            return f"Service '{service_name}' not found. Check deployed services with: onex status"
        elif resp.status_code == 500:
            detail = ''
            try:
                detail = resp.json().get('detail', resp.text[:300])
            except Exception:
                detail = resp.text[:300]
            return f"Reload failed: {detail}\nFix the issue and redeploy."
        else:
            return f"Unexpected response: HTTP {resp.status_code} - {resp.text[:200]}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except httpx.TimeoutException:
        return f"Reload timed out (120s). Service may still be reloading. Check: onex status {service_name}"
    except Exception as e:
        return f"Error reloading service: {e}"


# =============================================================================
# INVOCATION TOOLS
# =============================================================================

@mcp.tool()
async def onex_invoke(
    function_name: str,
    payload: str,
    env: str = None,
    is_async: bool = False,
    timeout: int = 60
) -> str:
    """Invoke a service handler directly with test data.

    Executes a Lambda-like function handler with provided payload.
    Useful for:
    - Testing handlers without HTTP requests
    - Debugging function logic
    - Running background tasks
    - Integration testing

    Args:
        function_name: Handler name in format 'service:handler' (e.g., 'order:processOrder')
        payload: JSON payload as string (e.g., '{"orderId": "123"}')
        env: Environment (local/dev/staging/prod). Default: active environment
        is_async: Run asynchronously (fire-and-forget). Default: False
        timeout: Timeout in seconds for sync invokes. Default: 60

    Returns:
        Handler execution result with timing or async job ID

    Examples:
        User: "Test the processOrder handler with order 123"
        → onex_invoke(
            function_name="order:processOrder",
            payload='{"orderId": "123"}'
          )

        User: "Send async email"
        → onex_invoke(
            function_name="email:sendEmail",
            payload='{"to": "user@example.com", "subject": "Test"}',
            is_async=True
          )
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)

    # Parse payload
    try:
        payload_data = json.loads(payload)
    except json.JSONDecodeError as e:
        return f"Invalid JSON payload: {e}"

    import uuid
    trace_id = str(uuid.uuid4())
    extra_headers = {'X-Trace-ID': trace_id}

    endpoint = f"{platform_url}/api/invoke/{'async' if is_async else 'sync'}"

    try:
        resp = await _authenticated_request(
            'post',
            endpoint,
            env,
            headers=extra_headers,
            json_body={
                'function_name': function_name,
                'payload': payload_data
            },
            timeout=timeout + 10
        )

        if is_async:
            if resp.status_code == 202:
                data = resp.json()
                return (
                    f"Async invoke accepted\n"
                    f"  NATS Subject: {data.get('subject', 'N/A')}\n"
                    f"  Message ID: {data.get('msg_id', 'N/A')}\n"
                    f"  Trace ID: {trace_id}\n"
                    f"\nMonitor: onex trace {trace_id} --env {env} --follow"
                )
            elif resp.status_code == 404:
                return f"Handler '{function_name}' not found. Use 'onex invoke --list' to see handlers."
            else:
                return f"Async invoke failed: HTTP {resp.status_code}\n{resp.text}"
        else:
            if resp.status_code == 200:
                data = resp.json()
                result = data.get('result')
                exec_time = data.get('execution_time_ms', 0)
                return (
                    f"Invoke successful\n"
                    f"  Handler: {function_name}\n"
                    f"  Execution time: {exec_time:.1f}ms\n"
                    f"  Trace ID: {trace_id}\n"
                    f"\nResult:\n{json.dumps(result, indent=2)}"
                )
            elif resp.status_code == 404:
                return f"Handler '{function_name}' not found. Use 'onex invoke --list' to see handlers."
            elif resp.status_code == 500:
                return f"Handler execution failed:\n{json.dumps(resp.json(), indent=2)}"
            else:
                return f"Invoke failed: HTTP {resp.status_code}\n{resp.text}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except httpx.TimeoutException:
        return f"Invoke timed out after {timeout} seconds. Use is_async=True for long-running tasks."
    except Exception as e:
        return f"Error invoking handler: {e}"


# =============================================================================
# ELASTICSEARCH TOOLS
# =============================================================================

@mcp.tool()
async def onex_es_status(
    service_name: Optional[str] = None,
    env: str = None,
) -> str:
    """View es_sync trigger status, ES index health, and execution stats.

    Shows all active MongoDB → Elasticsearch sync triggers with:
    - Trigger status (active/paused/error)
    - ES index document count and size
    - MongoDB source document count
    - Sync ratio (in sync, % synced)
    - Execution and failure counts
    - Last execution time and last error
    - Recent execution logs

    Args:
        service_name: Optional service name filter. If None, shows all services
        env: Environment (local/dev/staging/prod). Default: active environment

    Returns:
        Formatted es_sync status with per-trigger details

    Examples:
        User: "What es_sync triggers are running?"
        → onex_es_status()

        User: "Show me es_sync status for the CRM service"
        → onex_es_status(service_name="crm")

        User: "Are there any es_sync errors on dev?"
        → onex_es_status(env="dev")

        User: "Is Elasticsearch in sync with MongoDB?"
        → onex_es_status()
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)
    params = {}
    if service_name:
        params['service_name'] = service_name

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(
                f"{platform_url}/_internal/es-sync",
                params=params,
            )

        if resp.status_code == 200:
            data = resp.json()
            total = data.get('total', 0)
            summary = data.get('summary', {})

            if total == 0:
                msg = f"No es_sync triggers found"
                if service_name:
                    msg += f" for service '{service_name}'"
                return msg + ". Deploy a service with es_sync in service.yml to register triggers."

            lines = [f"ES Sync Status ({env})", ""]
            lines.append(
                f"Total: {total} trigger(s) | "
                f"{summary.get('active', 0)} active | "
                f"{summary.get('paused', 0)} paused | "
                f"{summary.get('error', 0)} error"
            )
            lines.append(
                f"Executions: {summary.get('total_executions', 0):,} total | "
                f"{summary.get('total_failures', 0):,} failures"
            )
            lines.append("")

            for svc in data.get('services', []):
                svc_name = svc.get('service_name', '?')
                triggers = svc.get('triggers', [])
                lines.append(f"Service: {svc_name} ({len(triggers)} trigger(s))")

                for t in triggers:
                    collection = t.get('collection', '?')
                    index = t.get('index', '?')
                    t_status = t.get('status', 'unknown').upper()
                    lines.append(f"  {collection} → {index} [{t_status}]")

                    es_info = t.get('es_index', {})
                    mongo_count = t.get('mongo_doc_count', 0)
                    es_count = es_info.get('doc_count', 0)
                    es_size = es_info.get('size', 'N/A')
                    es_exists = es_info.get('exists', False)

                    if es_exists:
                        sync_note = ''
                        if mongo_count > 0 and es_count > 0:
                            ratio = es_count / mongo_count * 100
                            if ratio >= 99:
                                sync_note = ' (in sync)'
                            else:
                                sync_note = f' ({ratio:.0f}% synced)'
                        lines.append(f"    MongoDB: {mongo_count:,} docs | ES: {es_count:,} docs ({es_size}){sync_note}")
                    else:
                        lines.append(f"    MongoDB: {mongo_count:,} docs | ES index MISSING")

                    exec_count = t.get('execution_count', 0)
                    fail_count = t.get('failure_count', 0)
                    last_exec = t.get('last_execution', 'never')
                    lines.append(f"    Executions: {exec_count:,} | Failures: {fail_count:,} | Last: {last_exec}")

                    last_error = t.get('last_error')
                    if last_error:
                        lines.append(f"    Last error: {last_error}")

                    ops = t.get('operations', [])
                    if ops:
                        lines.append(f"    Operations: {', '.join(ops)}")

                    fm = t.get('field_mapping')
                    if fm:
                        lines.append(f"    Field mapping: {json.dumps(fm)}")

                    recent = t.get('recent_logs', [])
                    if recent:
                        lines.append("    Recent logs:")
                        for log in recent[:3]:
                            ok = "OK" if log.get('success') else "FAIL"
                            op = log.get('operation', '?')
                            ms = log.get('execution_time_ms', 0)
                            err = log.get('error')
                            entry = f"      [{ok}] {op} ({ms}ms)"
                            if err:
                                entry += f" - {err}"
                            lines.append(entry)

                lines.append("")

            return "\n".join(lines)

        elif resp.status_code == 503:
            return "Stream Trigger Service unavailable. Make sure platform is running."
        else:
            return f"Failed to get es_sync status: HTTP {resp.status_code}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except httpx.TimeoutException:
        return f"Request timed out connecting to {platform_url}"
    except Exception as e:
        return f"Error getting es_sync status: {e}"


@mcp.tool()
async def onex_es_test(
    service_name: str,
    collection: Optional[str] = None,
    env: str = None,
) -> str:
    """Test es_sync by inserting a test document, verifying it syncs to ES, then cleaning up.

    For each es_sync trigger, this:
    1. Checks the ES index exists
    2. Inserts a test document into MongoDB
    3. Waits up to 10 seconds for it to appear in ES via change stream
    4. Cleans up the test document from both MongoDB and ES

    Use this to verify that MongoDB → Elasticsearch sync is working end-to-end.

    Args:
        service_name: Service name to test (e.g., 'crm', 'product')
        collection: Optional specific collection to test (all es_sync collections if omitted)
        env: Environment (local/dev/staging/prod). Default: active environment

    Returns:
        Test results with pass/fail per trigger and step details

    Examples:
        User: "Test if es_sync is working for CRM"
        → onex_es_test(service_name="crm")

        User: "Test es_sync for the adminService collection"
        → onex_es_test(service_name="crm", collection="adminService")

        User: "Verify ES sync on dev"
        → onex_es_test(service_name="crm", env="dev")
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)

    body = {'service_name': service_name}
    if collection:
        body['collection'] = collection

    try:
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(
                f"{platform_url}/_internal/es-sync/test",
                json=body,
            )

        if resp.status_code == 200:
            data = resp.json()
            results = data.get('results', [])
            summary = data.get('summary', {})
            error = data.get('error')

            if error and not results:
                return f"No es_sync triggers found: {error}"

            lines = [f"ES Sync Test Results for {service_name} ({env})", ""]

            for r in results:
                coll = r.get('collection', '?')
                index = r.get('index', '?')
                passed = r.get('passed', False)
                duration = r.get('duration_ms', 0)
                steps = r.get('steps', [])
                status_str = "PASSED" if passed else "FAILED"

                lines.append(f"  {coll} → {index}: {status_str} ({duration}ms)")
                for step in steps:
                    lines.append(f"    {step}")
                lines.append("")

            total = summary.get('total', 0)
            passed_count = summary.get('passed', 0)
            failed_count = summary.get('failed', 0)
            lines.append(f"Summary: {passed_count}/{total} passed, {failed_count} failed")

            return "\n".join(lines)

        elif resp.status_code == 503:
            return "Stream Trigger Service unavailable. Make sure platform is running."
        else:
            return f"ES sync test failed: HTTP {resp.status_code}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except httpx.TimeoutException:
        return f"ES sync test timed out (>2 minutes). Try testing one collection at a time."
    except Exception as e:
        return f"Error during ES sync test: {e}"


@mcp.tool()
async def onex_es_reindex(
    service_name: str,
    collection: Optional[str] = None,
    env: str = None,
) -> str:
    """Reindex Elasticsearch from MongoDB for a service.

    Bulk reads all documents from MongoDB collections with es_sync triggers
    and indexes them into Elasticsearch. Use when ES is out of sync with MongoDB.

    Args:
        service_name: Service name to reindex (e.g., 'crm', 'product')
        collection: Optional specific collection to reindex (all es_sync collections if omitted)
        env: Environment (local/dev/staging/prod). Default: active environment

    Returns:
        Reindex results with doc counts and timing per collection

    Examples:
        User: "Reindex ES for the CRM service"
        → onex_es_reindex(service_name="crm")

        User: "Reindex just the adminService collection"
        → onex_es_reindex(service_name="crm", collection="adminService")

        User: "Reindex product service on dev"
        → onex_es_reindex(service_name="product", env="dev")
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)

    body = {'service_name': service_name}
    if collection:
        body['collection'] = collection

    try:
        async with httpx.AsyncClient(timeout=300) as client:
            resp = await client.post(
                f"{platform_url}/_internal/reindex",
                json=body,
            )

        if resp.status_code == 200:
            data = resp.json()
            collections = data.get('collections', [])
            total = data.get('total_docs_synced', 0)

            if not collections:
                return f"No es_sync collections found for service '{service_name}'."

            lines = [f"Reindex results for {service_name}:", ""]
            for col in collections:
                name = col.get('collection', '?')
                index = col.get('index', '?')
                docs = col.get('docs_synced', 0)
                duration = col.get('duration_ms', 0)
                error = col.get('error')

                if error:
                    lines.append(f"  ❌ {name} → {index}: {error}")
                else:
                    lines.append(f"  ✅ {name} → {index}: {docs} docs ({duration}ms)")

            lines.append("")
            lines.append(f"Total: {total} docs synced across {len(collections)} collection(s)")
            return "\n".join(lines)

        elif resp.status_code == 404:
            detail = resp.json().get('detail', 'Not found')
            return f"No es_sync triggers found: {detail}"

        else:
            return f"Reindex failed: HTTP {resp.status_code}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except httpx.TimeoutException:
        return f"Reindex timed out (>5 minutes). Try reindexing one collection at a time."
    except Exception as e:
        return f"Error during reindex: {e}"


@mcp.tool()
async def onex_es_mapping(
    service_name: Optional[str] = None,
    env: str = None,
) -> str:
    """Check ES index mappings against model definitions.

    Compares actual Elasticsearch index mappings with the desired mappings
    stored during deployment. Highlights type mismatches and missing fields.
    Useful for diagnosing ES search issues caused by mapping drift.

    Args:
        service_name: Service name to check (e.g., 'user', 'crm'). All services if omitted.
        env: Environment (local/dev/staging/prod). Default: active environment

    Returns:
        Per-field comparison showing matches, mismatches, and missing fields

    Examples:
        User: "Check ES mappings for the user service"
        → onex_es_mapping(service_name="user")

        User: "Are there any ES mapping mismatches?"
        → onex_es_mapping()

        User: "Why is ES search returning 0 results for this service?"
        → onex_es_mapping(service_name="hr-employee")
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)

    params = {}
    if service_name:
        params['service_name'] = service_name

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(
                f"{platform_url}/_internal/es-sync/mapping",
                params=params,
            )

        if resp.status_code == 200:
            data = resp.json()
            indices = data.get('indices', [])
            error = data.get('error')

            if error and not indices:
                return error

            lines = []
            for idx_info in indices:
                svc = idx_info.get('service_name', '?')
                collection = idx_info.get('collection', '?')
                index = idx_info.get('index', '?')
                fields = idx_info.get('fields', [])
                idx_error = idx_info.get('error')
                mismatches = idx_info.get('mismatches', 0)
                missing = idx_info.get('missing_in_es', 0)

                lines.append(f"  {svc}: {collection} → {index}")

                if idx_error:
                    lines.append(f"    {idx_error}")
                elif not idx_info.get('has_stored_mappings'):
                    lines.append(f"    No es_mappings stored — redeploy service to populate")
                else:
                    for f in fields:
                        field = f.get('field', '?')
                        desired = f.get('desired', '?')
                        actual = f.get('actual')
                        status = f.get('status', '?')

                        if status == 'match':
                            lines.append(f"    {field}: {desired} ✓")
                        elif status == 'mismatch':
                            lines.append(f"    {field}: {desired} ✗ MISMATCH (ES: {actual})")
                        elif status == 'missing_in_es':
                            lines.append(f"    {field}: {desired} ? missing in ES")

                    if mismatches > 0:
                        lines.append(f"    ⚠ {mismatches} mismatch(es) — fix: onex es reindex {svc} --recreate")
                    elif missing > 0:
                        lines.append(f"    {missing} field(s) missing in ES")
                    else:
                        lines.append(f"    All fields match ✓")
                lines.append("")

            total_m = data.get('total_mismatches', 0)
            total_missing = data.get('total_missing', 0)
            if total_m == 0 and total_missing == 0:
                lines.append(f"All {len(indices)} index(es) have correct mappings")
            else:
                if total_m > 0:
                    lines.append(f"{total_m} field(s) with type mismatches")
                if total_missing > 0:
                    lines.append(f"{total_missing} field(s) missing in ES")

            return "\n".join(lines)

        elif resp.status_code == 503:
            return "Stream Trigger Service unavailable. Make sure platform is running."

        else:
            return f"Failed: HTTP {resp.status_code}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except Exception as e:
        return f"Error checking ES mappings: {e}"


# =============================================================================
# VALIDATION TOOLS
# =============================================================================

@mcp.tool()
async def onex_validate(service_dir: str = ".") -> str:
    """Validate service.yml schema without deploying.

    Checks service configuration for:
    - Required fields (name, runtime, handler)
    - Valid route definitions
    - Resource configurations
    - Trigger configurations
    - Schema compliance

    Run this BEFORE deploying to catch configuration errors early.

    Args:
        service_dir: Path to service directory. Default: current directory

    Returns:
        Validation result with specific errors or success message

    Examples:
        User: "Validate my service.yml"
        → onex_validate()

        User: "Check if product service config is valid"
        → onex_validate(service_dir="../services/product")
    """
    try:
        from onex.schema.validator import validate_service_yml
        result = validate_service_yml(service_dir)

        if result.get('valid'):
            service_name = result.get('name', 'unknown')
            return (
                f"✅ service.yml is valid\n"
                f"  Service: {service_name}\n"
                f"  Routes: {result.get('route_count', 0)}\n"
                f"  Invokes: {result.get('invoke_count', 0)}\n"
                f"  Triggers: {result.get('trigger_count', 0)}"
            )
        else:
            errors = result.get('errors', [])
            lines = ["❌ Validation failed:", ""]
            for error in errors:
                lines.append(f"  - {error}")
            return "\n".join(lines)

    except FileNotFoundError:
        return f"No service.yml found in {service_dir}"
    except ImportError:
        return "Validation module not available. Make sure onex-cli is properly installed."
    except Exception as e:
        return f"Validation error: {e}"


# =============================================================================
# SERVICE SCAFFOLDING TOOLS
# =============================================================================

@mcp.tool()
async def onex_create(
    name: str,
    template: str,
    description: Optional[str] = None,
    author: Optional[str] = "platform-team",
    output: Optional[str] = None,
    no_validate: bool = False
) -> str:
    """Create new service from template.

    Scaffolds a new service with production-ready structure.
    Reduces time-to-first-service from 2 hours to under 5 minutes.

    Available templates:
    - minimal: Single endpoint, quickest deployment
    - rest-api: Full CRUD operations with database
    - event-driven: Schedules + NATS event handlers
    - crud-service: Layered architecture (models, repos, services)

    Args:
        name: Service name in kebab-case (e.g., 'my-product-service')
        template: Template type (minimal/rest-api/event-driven/crud-service)
        description: Service description (optional)
        author: Author/team name (default: 'platform-team')
        output: Output directory (default: ./services/<name>)
        no_validate: Skip validation after creation

    Returns:
        Success message with created files and next steps

    Examples:
        User: "Create a REST API service called product-catalog"
        → onex_create(name="product-catalog", template="rest-api")

        User: "Scaffold a minimal service for health checks"
        → onex_create(name="health-check", template="minimal",
                      description="Health check endpoint")

        User: "Generate an event-driven service for notifications"
        → onex_create(name="notification-service", template="event-driven",
                      description="Email and SMS notifications", author="backend-team")
    """
    # Use Click's CliRunner to invoke the create command
    # This avoids reimplementing template logic
    try:
        from click.testing import CliRunner
        from onex.commands.init_service import create as create_cmd

        runner = CliRunner()
        args = ['--name', name, '--template', template]
        if description:
            args.extend(['--description', description])
        if author:
            args.extend(['--author', author])
        if output:
            args.extend(['--output', output])
        if no_validate:
            args.append('--no-validate')

        result = runner.invoke(create_cmd, args, catch_exceptions=False)
        return result.output or "Service created successfully."

    except ImportError:
        return "Create command not available. Make sure onex-cli is properly installed."
    except Exception as e:
        return f"Error creating service: {e}"


@mcp.tool()
async def onex_replay(
    trace_id: str,
    env: str = None,
) -> str:
    """Replay a previously captured request by trace_id.

    Loads the original request snapshot and re-sends it through the platform,
    generating a new trace_id for the replayed request. Useful for:
    - Verifying a bug fix by re-sending the exact request that failed
    - Reproducing intermittent issues
    - Testing after deployment

    Args:
        trace_id: The trace_id of the original request to replay
        env: Environment (local/dev/staging/prod). Default: active environment

    Returns:
        New trace_id and status of the replayed request

    Examples:
        User: "Replay the failed request abc-123"
        -> onex_replay(trace_id="abc-123")

        User: "Re-send that request on dev"
        -> onex_replay(trace_id="abc-123", env="dev")
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)

    try:
        resp = await _authenticated_request(
            'post',
            f"{platform_url}/_internal/replay/{trace_id}",
            env,
            timeout=30
        )

        if resp.status_code == 200:
            data = resp.json()
            method = data.get('method', '?')
            path = data.get('path', '?')
            status_code = data.get('status_code', '?')
            duration = data.get('duration_ms', '?')
            new_trace = data.get('new_trace_id', '?')

            return (
                f"Replayed: {method} {path}\n"
                f"Status: {status_code}\n"
                f"Duration: {duration}ms\n"
                f"New trace: {new_trace}\n"
                f"\nUse onex_trace(trace_id=\"{new_trace}\") to view the replayed request."
            )

        elif resp.status_code == 404:
            return (
                f"No replay snapshot found for trace_id: {trace_id}\n"
                "Snapshots expire after 24 hours."
            )
        elif resp.status_code == 401:
            return f"Authentication failed. Run: onex login --env {env}"
        else:
            return f"Replay failed: HTTP {resp.status_code}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except httpx.TimeoutException:
        return f"Request timed out connecting to {platform_url}"
    except Exception as e:
        return f"Error replaying request: {e}"


# =============================================================================
# E2E TESTING TOOLS
# =============================================================================

@mcp.tool()
async def onex_test(
    service_name: Optional[str] = None,
    env: Optional[str] = None,
    filter_expr: Optional[str] = None,
    maxfail: int = 5
) -> str:
    """Run E2E tests for a service against the platform.

    Executes pytest-based E2E tests that validate service CRUD endpoints.
    Tests run against a live platform environment.

    Args:
        service_name: Service to test (e.g., 'product', 'customer'). All if omitted.
        env: Environment (local/dev/staging/prod). Default: active environment.
        filter_expr: Pytest -k filter (e.g., 'test_create').
        maxfail: Stop after N failures. Default: 5.

    Returns:
        Test execution output with pass/fail summary

    Examples:
        User: "Run product E2E tests"
        -> onex_test(service_name="product")

        User: "Run all tests on staging"
        -> onex_test(env="staging")

        User: "Just run create tests for customer"
        -> onex_test(service_name="customer", filter_expr="test_01_create")
    """
    try:
        from click.testing import CliRunner
        from onex.commands.test import test as test_cmd

        runner = CliRunner()
        args = []
        if service_name:
            args.extend(['--service', service_name])
        if env:
            args.extend(['--env', env])
        if filter_expr:
            args.extend(['-k', filter_expr])
        if maxfail:
            args.extend(['--maxfail', str(maxfail)])

        result = runner.invoke(test_cmd, args, catch_exceptions=True)
        output = result.output or ""
        if result.exit_code != 0 and not output:
            output = f"Tests failed with exit code {result.exit_code}"
        return output

    except ImportError:
        return "Test command not available. Make sure onex-cli is properly installed."
    except Exception as e:
        return f"Error running tests: {e}"


@mcp.tool()
async def onex_create_e2e(
    service_name: str,
    entities: Optional[str] = None,
    services_dir: Optional[str] = None
) -> str:
    """Create E2E test scaffold for a service.

    Generates a test file (test_{service}_e2e.py) and data YAML (data/{service}.yml)
    with CRUD test cases for each entity. Auto-discovers entities from service.yml
    if available.

    Args:
        service_name: Service name (e.g., 'product', 'order')
        entities: Comma-separated entity names (auto-detected from service.yml if omitted)
        services_dir: Path to services repo (auto-detected if omitted)

    Returns:
        Success message with created files and next steps

    Examples:
        User: "Create E2E tests for the order service"
        -> onex_create_e2e(service_name="order")

        User: "Scaffold E2E tests for inventory with items and warehouses"
        -> onex_create_e2e(service_name="inventory", entities="item,warehouse")
    """
    try:
        from click.testing import CliRunner
        from onex.commands.create_e2e import create_e2e as create_e2e_cmd

        runner = CliRunner()
        args = ['--service', service_name]
        if entities:
            args.extend(['--entities', entities])
        if services_dir:
            args.extend(['--services-dir', services_dir])
        args.append('--force')

        result = runner.invoke(create_e2e_cmd, args, catch_exceptions=False)
        return result.output or "E2E tests scaffolded successfully."

    except ImportError:
        return "Create-e2e command not available. Make sure onex-cli is properly installed."
    except Exception as e:
        return f"Error creating E2E tests: {e}"


# =============================================================================
# S3 / MINIO TOOLS
# =============================================================================

def _get_minio_client(env: str):
    """Create MinIO client for environment."""
    from minio import Minio

    creds = _get_credentials(env)
    endpoint = creds.get('minio_endpoint', 'localhost:9000')

    if env == 'local':
        access_key = 'minioadmin'
        secret_key = 'minioadmin123'
    else:
        access_key = creds.get('minio_access_key', '')
        secret_key = creds.get('minio_secret_key', '')

    return Minio(
        endpoint,
        access_key=access_key,
        secret_key=secret_key,
        secure=False,
    )


def _format_size(size: int) -> str:
    """Format bytes to human readable."""
    if size is None:
        return 'N/A'
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if size < 1024:
            return f"{size:.1f} {unit}" if unit != 'B' else f"{size} B"
        size /= 1024
    return f"{size:.1f} PB"


@mcp.tool()
async def onex_s3_ls(
    path: Optional[str] = None,
    recursive: bool = False,
    env: Optional[str] = None
) -> str:
    """List S3/MinIO buckets or objects in a bucket.

    Without a path, lists all buckets. With a path like "bucket" or "bucket/prefix/",
    lists objects in that location.

    Args:
        path: Bucket name or bucket/prefix path. None to list buckets.
        recursive: List objects recursively (default: False)
        env: Environment (local/dev/staging/prod, defaults to active)

    Returns:
        Formatted list of buckets or objects with sizes and timestamps.

    Examples:
        User: "What S3 buckets do we have?"
        -> onex_s3_ls()

        User: "List files in the uploads bucket"
        -> onex_s3_ls(path="uploads")

        User: "Show all files under uploads/images/ recursively"
        -> onex_s3_ls(path="uploads/images/", recursive=True)
    """
    if env is None:
        env = get_active_environment()

    try:
        client = _get_minio_client(env)

        if path is None:
            buckets = list(client.list_buckets())
            if not buckets:
                return "No buckets found."

            lines = [f"Buckets ({env}):"]
            for b in buckets:
                created = b.creation_date.strftime('%Y-%m-%d %H:%M:%S') if b.creation_date else 'N/A'
                lines.append(f"  {b.name:<30} Created: {created}")
            lines.append(f"\n{len(buckets)} bucket(s)")
            return "\n".join(lines)

        parts = path.split('/', 1)
        bucket = parts[0]
        prefix = parts[1] if len(parts) > 1 else ''

        objects = list(client.list_objects(bucket, prefix=prefix or None, recursive=recursive))
        if not objects:
            return f"No objects found in {path}"

        lines = [f"Objects in {path} ({env}):"]
        dirs = 0
        files = 0
        total_size = 0

        for obj in objects:
            name = obj.object_name
            if obj.is_dir:
                dirs += 1
                lines.append(f"  [DIR] {name}")
            else:
                files += 1
                size = obj.size or 0
                total_size += size
                modified = obj.last_modified.strftime('%Y-%m-%d %H:%M:%S') if obj.last_modified else ''
                lines.append(f"  {name:<50} {_format_size(size):>10}  {modified}")

        lines.append(f"\n{files} file(s), {dirs} dir(s), {_format_size(total_size)} total")
        return "\n".join(lines)

    except Exception as e:
        return f"Error listing S3: {e}"


@mcp.tool()
async def onex_s3_search(
    bucket: str,
    prefix: str = "",
    pattern: Optional[str] = None,
    limit: int = 50,
    env: Optional[str] = None
) -> str:
    """Search for objects in an S3/MinIO bucket by prefix and filename pattern.

    Recursively searches through all objects in the bucket, optionally filtering
    by key prefix and/or filename glob pattern.

    Args:
        bucket: Bucket name to search in
        prefix: Key prefix to filter by (e.g., "images/")
        pattern: Filename glob pattern (e.g., "*.jpg", "report*")
        limit: Max results to return (default: 50)
        env: Environment (local/dev/staging/prod, defaults to active)

    Returns:
        List of matching objects with sizes and timestamps.

    Examples:
        User: "Find all JPG files in the uploads bucket"
        -> onex_s3_search(bucket="uploads", pattern="*.jpg")

        User: "Search for reports under documents/"
        -> onex_s3_search(bucket="documents", prefix="reports/", pattern="*.pdf")
    """
    import fnmatch

    if env is None:
        env = get_active_environment()

    try:
        client = _get_minio_client(env)
        objects = client.list_objects(bucket, prefix=prefix or None, recursive=True)

        results = []
        for obj in objects:
            if obj.is_dir:
                continue
            if pattern:
                filename = obj.object_name.rsplit('/', 1)[-1]
                if not fnmatch.fnmatch(filename, pattern):
                    continue
            results.append(obj)
            if len(results) >= limit:
                break

        if not results:
            return f"No objects found matching criteria in '{bucket}'"

        lines = [f"Search results in {bucket} ({env}):"]
        total_size = 0
        for obj in results:
            size = obj.size or 0
            total_size += size
            modified = obj.last_modified.strftime('%Y-%m-%d %H:%M:%S') if obj.last_modified else ''
            lines.append(f"  {obj.object_name:<50} {_format_size(size):>10}  {modified}")

        lines.append(f"\n{len(results)} object(s), {_format_size(total_size)} total")
        if len(results) >= limit:
            lines.append(f"(Results limited to {limit}. Increase limit to see more.)")
        return "\n".join(lines)

    except Exception as e:
        return f"Error searching S3: {e}"


@mcp.tool()
async def onex_s3_info(
    path: str,
    env: Optional[str] = None
) -> str:
    """Get detailed metadata for an S3/MinIO object.

    Returns size, content type, ETag, last modified date, and custom metadata.

    Args:
        path: Object path in format "bucket/key" (e.g., "uploads/images/photo.jpg")
        env: Environment (local/dev/staging/prod, defaults to active)

    Returns:
        Detailed object metadata as formatted text.

    Examples:
        User: "What's the size and type of uploads/report.pdf?"
        -> onex_s3_info(path="uploads/report.pdf")

        User: "Show me details for the image at uploads/images/logo.png"
        -> onex_s3_info(path="uploads/images/logo.png")
    """
    if env is None:
        env = get_active_environment()

    parts = path.split('/', 1)
    if len(parts) < 2 or not parts[1]:
        return "Error: Path must be in format bucket/key (e.g., uploads/images/photo.jpg)"

    bucket = parts[0]
    key = parts[1]

    try:
        client = _get_minio_client(env)
        stat = client.stat_object(bucket, key)

        lines = [
            f"Object Info ({env}):",
            f"  Bucket:         {bucket}",
            f"  Key:            {key}",
            f"  Size:           {_format_size(stat.size)} ({stat.size:,} bytes)",
            f"  Content-Type:   {stat.content_type or 'N/A'}",
            f"  ETag:           {stat.etag or 'N/A'}",
            f"  Last Modified:  {stat.last_modified.strftime('%Y-%m-%d %H:%M:%S') if stat.last_modified else 'N/A'}",
        ]

        if stat.metadata:
            lines.append("  Metadata:")
            for k, v in stat.metadata.items():
                lines.append(f"    {k}: {v}")

        return "\n".join(lines)

    except Exception as e:
        err_str = str(e)
        if 'NoSuchKey' in err_str or 'not found' in err_str.lower():
            return f"Object not found: {bucket}/{key}"
        if 'NoSuchBucket' in err_str:
            return f"Bucket '{bucket}' does not exist"
        return f"Error: {e}"


# =============================================================================
# SERVER MAIN
# =============================================================================

def main():
    """Main entry point for onex-mcp command."""
    # FastMCP will handle stdio transport automatically
    # No print statements allowed - will corrupt JSON-RPC messages
    try:
        mcp.run(transport="stdio")
    except KeyboardInterrupt:
        sys.exit(0)
    except Exception as e:
        print(f"Fatal error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
