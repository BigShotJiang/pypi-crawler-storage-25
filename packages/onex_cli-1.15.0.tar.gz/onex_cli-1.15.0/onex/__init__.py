# OneXEOS Services CLI
__version__ = "1.15.0"
