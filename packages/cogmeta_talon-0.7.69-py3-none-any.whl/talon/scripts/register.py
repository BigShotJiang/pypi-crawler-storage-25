"""talon-register — browser registration flow, runs as a single named command.

Starts `talon auth register` in the background (which runs the local HTTP callback
server and opens register.html), waits for it to write the login URL, prints the
URL, then exits.

The background server stays alive as an orphan process, waiting for the browser
callback. Once the user registers and authenticates, credentials are saved
automatically.
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

_URL_FILE = Path.home() / ".talon" / "login_url.txt"
_DONE_FILE = Path.home() / ".talon" / "login_done.txt"


def main() -> None:
    _URL_FILE.parent.mkdir(parents=True, exist_ok=True)
    _URL_FILE.unlink(missing_ok=True)
    _DONE_FILE.unlink(missing_ok=True)

    talon_bin = Path(sys.executable).parent / "talon"

    # Start the auth server in the background. It will stay alive after we exit.
    subprocess.Popen(
        [str(talon_bin), "auth", "register"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    # Wait up to 15s for the URL file
    for _ in range(30):
        time.sleep(0.5)
        if _URL_FILE.exists():
            break

    url = _URL_FILE.read_text().strip() if _URL_FILE.exists() else ""
    if not url:
        print("Error: registration server did not start.", file=sys.stderr)
        print("Try running:  talon auth register  directly to see errors.", file=sys.stderr)
        sys.exit(1)

    print()
    print("Open this URL in your browser to create your account:")
    print()
    print(f"  {url}")
    print()
    print("When done, run:  /talon auth  to confirm your session.")
