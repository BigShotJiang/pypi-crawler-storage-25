"""Three-layer in-memory source cache for the talon v5 architecture.

Provides O(1) line-range lookups and O(1) symbol location for the MCP
server, eliminating repeated file I/O during context assembly.

Layer 1: Line arrays   — dict[file_path, list[str]]  (~25 MB / 500K LOC)
Layer 2: Inverted index — dict[symbol_name, [(file, line), ...]]
Layer 3: AST trees      — (stub, reserved for Phase 3)

Implements: CACHE-001, CACHE-002
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Supported file extensions (mirrors indexer/parser.py)
# ---------------------------------------------------------------------------

SUPPORTED_EXTENSIONS: frozenset[str] = frozenset({".py", ".ts", ".tsx"})

# Simple regexes for lightweight symbol extraction (no tree-sitter needed).
# We only need top-level function/class names for the inverted index.
_PY_SYMBOL_RE = re.compile(
    r"^(?P<indent>[ \t]*)(?:async\s+)?(?P<type>def|class)\s+(?P<name>\w+)",
    re.MULTILINE,
)
_TS_SYMBOL_RE = re.compile(
    r"^(?P<indent>[ \t]*)(?:export\s+)?(?:async\s+)?(?P<type>function|class)\s+(?P<name>\w+)",
    re.MULTILINE,
)

_SYMBOL_REGEX_MAP: dict[str, re.Pattern[str]] = {
    ".py": _PY_SYMBOL_RE,
    ".ts": _TS_SYMBOL_RE,
    ".tsx": _TS_SYMBOL_RE,
}


# ---------------------------------------------------------------------------
# CacheStats
# ---------------------------------------------------------------------------


@dataclass
class CacheStats:
    """Hit/miss counters and timing telemetry for the memory store."""

    files_loaded: int = 0
    symbols_indexed: int = 0
    line_lookups: int = 0
    symbol_lookups: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    build_time_ms: float = 0
    last_invalidation: str | None = None
    # Per-layer latency tracking (microseconds)
    line_lookup_total_us: int = 0
    symbol_lookup_total_us: int = 0
    fuzzy_lookups: int = 0
    fuzzy_lookup_total_us: int = 0
    invalidations: int = 0
    refreshes: int = 0


# ---------------------------------------------------------------------------
# MemoryStore
# ---------------------------------------------------------------------------


class MemoryStore:
    """Three-layer in-memory source cache.

    Usage::

        store = MemoryStore()
        store.build(Path("/home/user/project"))

        lines = store.get_lines("src/auth.py", 45, 89)
        locs  = store.locate_symbol("validate_token")
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def __init__(self) -> None:
        self._lines: dict[str, list[str]] = {}                   # Layer 1
        self._index: dict[str, list[tuple[str, int]]] = {}       # Layer 2
        self._trees: dict[str, Any] = {}                         # Layer 3 (stub)
        self._hashes: dict[str, str] = {}                        # content hash per file
        self._file_symbols: dict[str, list[dict[str, Any]]] = {} # per-file symbol list
        self._stats: CacheStats = CacheStats()

    # ------------------------------------------------------------------
    # Build helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _content_hash(content: str) -> str:
        """SHA-256 hex digest of file content (first 16 chars)."""
        return hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]

    @staticmethod
    def _discover_files(project_path: Path) -> list[str]:
        """Walk *project_path* and return relative paths for supported files."""
        result: list[str] = []
        root = str(project_path)
        for dirpath, dirnames, filenames in os.walk(root):
            # Skip hidden dirs and common noise
            dirnames[:] = [
                d for d in dirnames
                if not d.startswith(".") and d not in {"node_modules", "__pycache__", ".git", "venv", ".venv", "dist", "build"}
            ]
            for fname in filenames:
                ext = os.path.splitext(fname)[1].lower()
                if ext in SUPPORTED_EXTENSIONS:
                    abs_path = os.path.join(dirpath, fname)
                    rel_path = os.path.relpath(abs_path, root).replace(os.sep, "/")
                    result.append(rel_path)
        return sorted(result)

    def _extract_symbols_regex(self, file_path: str, lines: list[str]) -> list[dict[str, Any]]:
        """Extract function/class/method symbols from *lines* using simple regex.

        Returns a list of dicts matching the symbol schema::

            {"name": str, "line_start": int, "line_end": int,
             "type": "function"|"class"|"method", "class_name": str|None}

        ``line_end`` is estimated as the last non-empty line before the next
        definition (or EOF).  This is intentionally approximate —
        the graph has the authoritative AST data.
        """
        ext = os.path.splitext(file_path)[1].lower()
        pattern = _SYMBOL_REGEX_MAP.get(ext)
        if pattern is None:
            return []

        content = "\n".join(lines)
        matches = list(pattern.finditer(content))
        symbols: list[dict[str, Any]] = []

        current_class: str | None = None
        class_indent: int = -1

        for i, m in enumerate(matches):
            # 1-indexed line number
            line_start = content[: m.start()].count("\n") + 1
            raw_indent = m.group("indent")
            indent = len(raw_indent.replace("\t", "    "))
            sym_type_raw = m.group("type")

            # Estimate line_end: start of next symbol or EOF
            if i + 1 < len(matches):
                next_start = content[: matches[i + 1].start()].count("\n") + 1
                line_end = max(next_start - 1, line_start)
            else:
                line_end = len(lines)

            # Determine type and class context
            class_name: str | None = None
            if sym_type_raw == "class":
                current_class = m.group("name")
                class_indent = indent
                sym_type = "class"
            elif sym_type_raw in ("def", "function"):
                if current_class is not None and indent > class_indent:
                    sym_type = "method"
                    class_name = current_class
                else:
                    sym_type = "function"
                    if indent <= class_indent:
                        current_class = None
                        class_indent = -1
            else:
                sym_type = "function"

            symbols.append({
                "name": m.group("name"),
                "line_start": line_start,
                "line_end": line_end,
                "type": sym_type,
                "class_name": class_name,
            })

        return symbols

    def _index_symbols(self, file_path: str, symbols: list[dict[str, Any]]) -> None:
        """Add *symbols* to the Layer 2 inverted index and per-file cache."""
        self._file_symbols[file_path] = symbols
        for sym in symbols:
            name: str = sym["name"]
            line_start: int = sym["line_start"]
            entries = self._index.setdefault(name, [])
            entries.append((file_path, line_start))
            self._stats.symbols_indexed += 1

    def _remove_from_index(self, file_path: str) -> None:
        """Remove all index entries for *file_path*."""
        # Remove from inverted index
        dead_keys: list[str] = []
        for sym_name, locations in self._index.items():
            self._index[sym_name] = [
                (fp, ln) for fp, ln in locations if fp != file_path
            ]
            if not self._index[sym_name]:
                dead_keys.append(sym_name)
        for k in dead_keys:
            del self._index[k]

        # Remove per-file symbol list
        self._file_symbols.pop(file_path, None)

    # ------------------------------------------------------------------
    # Public: build
    # ------------------------------------------------------------------

    @staticmethod
    def _load_priority_files(project_path: Path) -> list[str]:
        """Load priority file list from git miner cache.

        Returns paths sorted by priority_score descending, or empty list
        if no cache is available. Used to ensure hot files are indexed
        first so their symbols appear first in locate results.
        """
        cache_path = project_path / ".talon" / "git_miner_cache.json"
        if not cache_path.exists():
            return []
        try:
            data = json.loads(cache_path.read_text())
            return [f["path"] for f in data.get("top_files", [])]
        except (json.JSONDecodeError, OSError, KeyError):
            return []

    def build(self, project_path: Path, file_paths: list[str] | None = None) -> None:
        """Build Layer 1 + Layer 2 from project files.

        Reads all files, stores as line arrays, and extracts basic symbols
        (function/class definitions via simple regex).

        When a git miner cache exists at ``{project_path}/.talon/git_miner_cache.json``,
        hot files are loaded first so their symbols take priority in locate results.

        Args:
            project_path: Absolute path to the project root.
            file_paths: Explicit file list (relative to *project_path*).
                If ``None``, discover all supported files automatically.
        """
        t0 = time.monotonic()

        if file_paths is None:
            file_paths = self._discover_files(project_path)

        # Pre-warm: reorder so git-miner hot files are indexed first
        priority = self._load_priority_files(project_path)
        if priority:
            priority_set = set(priority)
            hot = [f for f in priority if f in set(file_paths)]
            cold = [f for f in file_paths if f not in priority_set]
            file_paths = hot + cold

        loaded = 0
        for rel_path in file_paths:
            abs_path = project_path / rel_path
            try:
                content = abs_path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                logger.warning("Cannot read file, skipping: %s", abs_path)
                continue

            lines = content.splitlines()
            self._lines[rel_path] = lines
            self._hashes[rel_path] = self._content_hash(content)

            # Layer 2: lightweight symbol extraction
            symbols = self._extract_symbols_regex(rel_path, lines)
            self._index_symbols(rel_path, symbols)
            loaded += 1

        self._stats.files_loaded = loaded
        self._stats.build_time_ms = (time.monotonic() - t0) * 1000

        logger.info(
            "MemoryStore.build: %d files, %d symbols in %.1f ms",
            loaded,
            self._stats.symbols_indexed,
            self._stats.build_time_ms,
        )

    # ------------------------------------------------------------------
    # Public: build from pre-extracted symbols
    # ------------------------------------------------------------------

    def build_from_symbols(self, symbols: dict[str, list[dict[str, Any]]]) -> None:
        """Build Layer 2 inverted index from pre-extracted symbols.

        This is used when the graph indexer has already parsed the AST and
        we just need to populate the inverted index from authoritative data.

        Args:
            symbols: Mapping of ``{file_path: [{name, line_start, line_end, type}, ...]}``.
        """
        t0 = time.monotonic()

        # Reset Layer 2 entirely
        self._index.clear()
        self._file_symbols.clear()
        old_count = self._stats.symbols_indexed
        self._stats.symbols_indexed = 0

        for file_path, sym_list in symbols.items():
            self._index_symbols(file_path, sym_list)

        elapsed = (time.monotonic() - t0) * 1000
        logger.info(
            "MemoryStore.build_from_symbols: %d files, %d symbols in %.1f ms (replaced %d)",
            len(symbols),
            self._stats.symbols_indexed,
            elapsed,
            old_count,
        )

    # ------------------------------------------------------------------
    # Public: seed file I/O
    # ------------------------------------------------------------------

    def load_from_seed(self, seed_path: Path) -> bool:
        """Load cache from a pre-built seed file (JSON).

        Seed format::

            {
                "version": 1,
                "project_path": "/path/to/project",
                "files": {
                    "src/auth.py": {
                        "hash": "abc123",
                        "symbols": [
                            {"name": "validate_token", "line_start": 45,
                             "line_end": 89, "type": "function"}
                        ]
                    }
                }
            }

        Returns:
            ``True`` if the seed was loaded successfully, ``False`` if the
            seed file is missing, corrupt, or has a version mismatch.
        """
        if not seed_path.exists():
            logger.debug("Seed file not found: %s", seed_path)
            return False

        try:
            data = json.loads(seed_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("Cannot read seed file %s: %s", seed_path, exc)
            return False

        if data.get("version") != 1:
            logger.warning(
                "Seed version mismatch: expected 1, got %s", data.get("version")
            )
            return False

        project_path = Path(data.get("project_path", ""))
        files: dict[str, Any] = data.get("files", {})
        if not files:
            logger.warning("Seed file has no files section")
            return False

        t0 = time.monotonic()
        loaded = 0
        stale = 0

        for rel_path, file_info in files.items():
            seed_hash: str = file_info.get("hash", "")
            abs_path = project_path / rel_path

            # Read the actual file to populate Layer 1
            try:
                content = abs_path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                logger.debug("Seed references missing file: %s", rel_path)
                stale += 1
                continue

            current_hash = self._content_hash(content)
            if seed_hash and current_hash != seed_hash:
                # File has changed since the seed was built — skip symbols
                # but still load lines (Layer 1 is always fresh from disk)
                logger.debug("Stale hash for %s, loading lines only", rel_path)
                stale += 1

            lines = content.splitlines()
            self._lines[rel_path] = lines
            self._hashes[rel_path] = current_hash

            # Use seed symbols only if hash matches
            if seed_hash and current_hash == seed_hash:
                symbols = file_info.get("symbols", [])
                self._index_symbols(rel_path, symbols)
            else:
                # Fall back to regex extraction for changed files
                symbols = self._extract_symbols_regex(rel_path, lines)
                self._index_symbols(rel_path, symbols)

            loaded += 1

        self._stats.files_loaded = loaded
        self._stats.build_time_ms = (time.monotonic() - t0) * 1000

        logger.info(
            "MemoryStore.load_from_seed: %d files loaded, %d stale, %d symbols in %.1f ms",
            loaded,
            stale,
            self._stats.symbols_indexed,
            self._stats.build_time_ms,
        )
        return True

    # ------------------------------------------------------------------
    # Layer 1: Line access
    # ------------------------------------------------------------------

    def get_lines(self, file_path: str, start: int, end: int) -> list[str]:
        """O(1) line-range retrieval from Layer 1.

        Args:
            file_path: Relative path (e.g. ``"src/talon/mcp/server.py"``).
            start: First line number (1-indexed, inclusive).
            end: Last line number (1-indexed, inclusive).

        Returns:
            List of line strings. Returns an empty list if the file is not
            cached or the range is out of bounds.
        """
        t0 = time.perf_counter_ns()
        self._stats.line_lookups += 1
        lines = self._lines.get(file_path)
        if lines is None:
            self._stats.cache_misses += 1
            self._stats.line_lookup_total_us += (time.perf_counter_ns() - t0) // 1000
            return []

        self._stats.cache_hits += 1
        # Clamp to valid range (1-indexed → 0-indexed)
        lo = max(start - 1, 0)
        hi = min(end, len(lines))
        result = lines[lo:hi]
        self._stats.line_lookup_total_us += (time.perf_counter_ns() - t0) // 1000
        return result

    def get_all_lines(self, file_path: str) -> list[str] | None:
        """Get all lines for a file, or ``None`` if not cached."""
        t0 = time.perf_counter_ns()
        self._stats.line_lookups += 1
        lines = self._lines.get(file_path)
        if lines is None:
            self._stats.cache_misses += 1
            self._stats.line_lookup_total_us += (time.perf_counter_ns() - t0) // 1000
            return None
        self._stats.cache_hits += 1
        self._stats.line_lookup_total_us += (time.perf_counter_ns() - t0) // 1000
        return lines

    def get_file_loc(self, file_path: str) -> int:
        """Return line count for a file, or 0 if not cached."""
        lines = self._lines.get(file_path)
        return len(lines) if lines is not None else 0

    # ------------------------------------------------------------------
    # Layer 2: Symbol lookup
    # ------------------------------------------------------------------

    def locate_symbol(self, name: str) -> list[tuple[str, int]]:
        """O(1) symbol lookup from the inverted index.

        Args:
            name: Symbol name (function or class).

        Returns:
            List of ``(file_path, line_number)`` tuples, or empty list.
        """
        t0 = time.perf_counter_ns()
        self._stats.symbol_lookups += 1
        result = self._index.get(name)
        if result is None:
            self._stats.cache_misses += 1
            self._stats.symbol_lookup_total_us += (time.perf_counter_ns() - t0) // 1000
            return []
        self._stats.cache_hits += 1
        out = list(result)
        self._stats.symbol_lookup_total_us += (time.perf_counter_ns() - t0) // 1000
        return out

    def get_file_symbols(self, file_path: str) -> list[dict[str, Any]]:
        """Get all symbols (functions/classes) for a file from the index.

        Returns:
            List of symbol dicts with keys: name, line_start, line_end, type.
            Empty list if the file is not indexed.
        """
        return list(self._file_symbols.get(file_path, []))

    def get_files_by_prefix(self, prefix: str) -> list[tuple[str, int, int]]:
        """Return files whose path starts with *prefix*.

        Args:
            prefix: Directory prefix (e.g. ``"src/talon/mcp"``).
                A trailing ``/`` is added automatically if missing.

        Returns:
            List of ``(path, loc, symbol_count)`` tuples sorted by path.
        """
        norm = prefix.rstrip("/") + "/"
        results: list[tuple[str, int, int]] = []
        for path, lines in self._lines.items():
            if path.startswith(norm):
                sym_count = len(self._file_symbols.get(path, []))
                results.append((path, len(lines), sym_count))
        return sorted(results, key=lambda x: x[0])

    def locate_symbol_fuzzy(
        self, query: str, *, max_results: int = 20
    ) -> list[tuple[str, int, str]]:
        """Fuzzy symbol lookup: exact → prefix → substring.

        Returns a ranked list of ``(file_path, line_number, match_kind)``
        tuples where ``match_kind`` is one of ``"exact"``, ``"prefix"``,
        or ``"substring"``.  Results are ordered: exact first, then prefix,
        then substring.

        Args:
            query: Symbol name (or fragment) to search for.
            max_results: Maximum results to return.
        """
        t0 = time.perf_counter_ns()
        self._stats.symbol_lookups += 1
        self._stats.fuzzy_lookups += 1
        results: list[tuple[str, int, str]] = []

        # 1. Exact match
        exact = self._index.get(query)
        if exact:
            self._stats.cache_hits += 1
            for fp, ln in exact:
                results.append((fp, ln, "exact"))
            if len(results) >= max_results:
                self._stats.fuzzy_lookup_total_us += (time.perf_counter_ns() - t0) // 1000
                self._stats.symbol_lookup_total_us += (time.perf_counter_ns() - t0) // 1000
                return results[:max_results]

        # 2. Case-insensitive exact match (if no exact)
        if not results:
            q_lower = query.lower()
            for sym_name, locations in self._index.items():
                if sym_name.lower() == q_lower:
                    for fp, ln in locations:
                        results.append((fp, ln, "exact"))

        # 3. Prefix match
        q_lower = query.lower()
        seen = {(fp, ln) for fp, ln, _ in results}
        for sym_name, locations in self._index.items():
            if sym_name.lower().startswith(q_lower) and sym_name != query:
                for fp, ln in locations:
                    if (fp, ln) not in seen:
                        results.append((fp, ln, "prefix"))
                        seen.add((fp, ln))

        if len(results) >= max_results:
            self._stats.fuzzy_lookup_total_us += (time.perf_counter_ns() - t0) // 1000
            self._stats.symbol_lookup_total_us += (time.perf_counter_ns() - t0) // 1000
            return results[:max_results]

        # 4. Substring match
        for sym_name, locations in self._index.items():
            if q_lower in sym_name.lower() and not sym_name.lower().startswith(q_lower):
                for fp, ln in locations:
                    if (fp, ln) not in seen:
                        results.append((fp, ln, "substring"))
                        seen.add((fp, ln))

        if results:
            self._stats.cache_hits += 1
        else:
            self._stats.cache_misses += 1

        elapsed_us = (time.perf_counter_ns() - t0) // 1000
        self._stats.fuzzy_lookup_total_us += elapsed_us
        self._stats.symbol_lookup_total_us += elapsed_us
        return results[:max_results]

    def search_content(
        self, pattern: str, file_filter: str | None = None, max_results: int = 20,
    ) -> list[tuple[str, int, str]]:
        """Search file contents by keyword/regex pattern via L1 cache.

        Args:
            pattern: Regex or plain keyword (case-insensitive).
            file_filter: Optional glob filter (e.g. "backends/*.py").
            max_results: Max matching lines returned.

        Returns:
            List of (file_path, line_number, line_text) tuples.
        """
        import fnmatch
        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except re.error:
            regex = re.compile(re.escape(pattern), re.IGNORECASE)

        results: list[tuple[str, int, str]] = []
        for fpath, lines in self._lines.items():
            if file_filter and not fnmatch.fnmatch(fpath, file_filter):
                continue
            for i, line in enumerate(lines, 1):
                if regex.search(line):
                    results.append((fpath, i, line.rstrip()))
                    if len(results) >= max_results:
                        return results
        return results

    def get_symbol_at(self, file_path: str, line: int) -> dict[str, Any] | None:
        """Get the symbol definition at or containing a specific line.

        Returns the symbol dict if found, None otherwise.
        """
        symbols = self._file_symbols.get(file_path, [])
        for sym in symbols:
            if sym["line_start"] <= line <= sym["line_end"]:
                return dict(sym)
        return None

    # ------------------------------------------------------------------
    # Invalidation / refresh
    # ------------------------------------------------------------------

    def invalidate(self, file_path: str) -> None:
        """Remove a file from all layers."""
        self._lines.pop(file_path, None)
        self._hashes.pop(file_path, None)
        self._trees.pop(file_path, None)
        self._remove_from_index(file_path)
        self._stats.last_invalidation = file_path
        self._stats.invalidations += 1

        if self._stats.files_loaded > 0:
            self._stats.files_loaded -= 1

        logger.debug("Invalidated: %s", file_path)

    def refresh_file(self, file_path: str, content: str) -> None:
        """Re-index a single file after edit.

        Replaces Layer 1 lines and rebuilds Layer 2 entries for this file.

        Args:
            file_path: Relative file path.
            content: New file content as a single string.
        """
        self._stats.refreshes += 1
        # Remove old entries
        was_present = file_path in self._lines
        self._remove_from_index(file_path)

        # Rebuild
        lines = content.splitlines()
        self._lines[file_path] = lines
        self._hashes[file_path] = self._content_hash(content)

        symbols = self._extract_symbols_regex(file_path, lines)
        self._index_symbols(file_path, symbols)

        if not was_present:
            self._stats.files_loaded += 1

        logger.debug(
            "Refreshed: %s (%d lines, %d symbols)", file_path, len(lines), len(symbols)
        )

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def cached_paths(self) -> set[str]:
        """Return the set of all file paths in the L1 cache."""
        return set(self._lines.keys())

    @property
    def file_count(self) -> int:
        """Number of files currently cached in Layer 1."""
        return len(self._lines)

    @property
    def symbol_count(self) -> int:
        """Total number of symbol entries across all files in Layer 2."""
        return sum(len(locs) for locs in self._index.values())

    @property
    def memory_estimate_mb(self) -> float:
        """Rough memory estimate in MB for the line arrays.

        Uses ``sys.getsizeof`` on each line string plus list overhead.
        This is intentionally approximate — it does not account for the
        inverted index or Python object overhead precisely.
        """
        total = 0
        for file_lines in self._lines.values():
            total += sys.getsizeof(file_lines)
            for line in file_lines:
                total += sys.getsizeof(line)
        return total / (1024 * 1024)

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def status(self) -> dict[str, Any]:
        """Return cache status dict for /status endpoint."""
        stats = asdict(self._stats)
        # Compute averages
        if self._stats.line_lookups > 0:
            stats["avg_line_lookup_us"] = round(
                self._stats.line_lookup_total_us / self._stats.line_lookups, 1
            )
        if self._stats.symbol_lookups > 0:
            stats["avg_symbol_lookup_us"] = round(
                self._stats.symbol_lookup_total_us / self._stats.symbol_lookups, 1
            )
        if self._stats.fuzzy_lookups > 0:
            stats["avg_fuzzy_lookup_us"] = round(
                self._stats.fuzzy_lookup_total_us / self._stats.fuzzy_lookups, 1
            )
        total_lookups = self._stats.line_lookups + self._stats.symbol_lookups
        if total_lookups > 0:
            stats["hit_rate_pct"] = round(
                self._stats.cache_hits / total_lookups * 100, 1
            )
        return {
            "file_count": self.file_count,
            "symbol_count": self.symbol_count,
            "memory_estimate_mb": round(self.memory_estimate_mb, 2),
            "stats": stats,
        }
