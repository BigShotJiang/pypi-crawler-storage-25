"""Indexer-only data models — shipped in the public wheel.

Contains only what the client-side parser needs to build the upload payload.
Full graph schema (collection names, edge types, AQL helpers) stays server-side.
"""
from __future__ import annotations

import hashlib
from typing import Any
from datetime import datetime

from pydantic import BaseModel, Field


def make_key(*parts: str) -> str:
    """Deterministic document key — SHA-256 truncated to 32 hex chars."""
    raw = ":".join(parts)
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


class BaseNode(BaseModel):
    key: str = Field(default="", alias="_key")
    project_id: str = ""
    created_at: str = ""
    updated_at: str = ""

    def to_db_dict(self) -> dict[str, Any]:
        data = self.model_dump(by_alias=True, exclude_none=True)
        if not data.get("created_at"):
            data["created_at"] = datetime.utcnow().isoformat()
        if not data.get("updated_at"):
            data["updated_at"] = datetime.utcnow().isoformat()
        return data


class FileNode(BaseNode):
    path: str = ""
    language: str = ""
    loc: int = 0
    hash: str = ""
    last_indexed: str = ""
    last_modified: str = ""


class ModuleNode(BaseNode):
    name: str = ""
    path: str = ""
    language: str = ""
    is_package: bool = False


class ClassNode(BaseNode):
    name: str = ""
    module: str = ""
    bases: list[str] = Field(default_factory=list)
    decorators: list[str] = Field(default_factory=list)
    docstring: str = ""
    line_start: int = 0
    line_end: int = 0


class FunctionNode(BaseNode):
    name: str = ""
    module: str = ""
    class_name: str | None = None
    params: list[str] = Field(default_factory=list)
    return_type: str | None = None
    is_async: bool = False
    is_method: bool = False
    is_static: bool = False
    is_classmethod: bool = False
    is_assignment: bool = False
    decorators: list[str] = Field(default_factory=list)
    docstring: str = ""
    line_start: int = 0
    line_end: int = 0
    complexity: int | None = None
    raises: list[str] = Field(default_factory=list)
    catches: list[str] = Field(default_factory=list)


class ImportNode(BaseNode):
    source_module: str = ""
    target_module: str = ""
    imported_names: list[str] = Field(default_factory=list)
    is_relative: bool = False
    line_number: int = 0
