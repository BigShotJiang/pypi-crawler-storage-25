"""Session reporter — parses the CC trace JSONL and submits to Talon Cloud.

Claude Code writes a complete JSONL transcript to:
    ~/.claude/projects/<cwd-as-path>/  <session-id>.jsonl

TraceWatcher runs as a daemon thread inside talon-proxy-wrapper. It tails
the JSONL as the session progresses, detects completed turns (assistant events
with stop_reason), and submits an upsert to the cloud API after each turn.
No hooks. No per-prompt cost. Just a file tail loop.
"""

from __future__ import annotations

import json
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Cost model (per million tokens, claude-sonnet)
# ---------------------------------------------------------------------------

_COST_RATES = {
    "input": 3.0,
    "output": 15.0,
    "cache_read": 0.30,
    "cache_create": 3.75,
}


def _calc_cost(
    input_tok: int,
    output_tok: int,
    cache_create: int,
    cache_read: int,
) -> float:
    return (
        input_tok * _COST_RATES["input"]
        + output_tok * _COST_RATES["output"]
        + cache_create * _COST_RATES["cache_create"]
        + cache_read * _COST_RATES["cache_read"]
    ) / 1_000_000


# ---------------------------------------------------------------------------
# Trace file location
# ---------------------------------------------------------------------------


def _project_traces_dir(cwd: str) -> Path:
    """Map a working directory path to CC's project traces directory.

    CC maps: /ai/projects/cogz → ~/.claude/projects/-ai-projects-cogz/
    The rule is simply cwd.replace('/', '-').
    """
    slug = cwd.replace("/", "-")
    return Path.home() / ".claude" / "projects" / slug


def find_trace_file(cwd: str, started_after: float | None = None) -> Path | None:
    """Return the most recently modified .jsonl trace file for this session.

    started_after: monotonic time — only consider files modified after this.
    """
    trace_dir = _project_traces_dir(cwd)
    if not trace_dir.exists():
        return None

    candidates = sorted(
        trace_dir.glob("*.jsonl"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if not candidates:
        return None

    if started_after is not None:
        import time
        wall_started = time.time() - (time.monotonic() - started_after)
        candidates = [p for p in candidates if p.stat().st_mtime >= wall_started - 5]

    return candidates[0] if candidates else None


def find_trace_by_session_id(session_id: str) -> Path | None:
    """Scan all CC project dirs for a trace file matching session_id.

    Used by the prompt hook which knows session_id but not cwd.
    """
    projects_dir = Path.home() / ".claude" / "projects"
    if not projects_dir.exists():
        return None
    candidate = None
    for p in projects_dir.rglob(f"{session_id}.jsonl"):
        candidate = p
        break
    return candidate


# ---------------------------------------------------------------------------
# Trace parser
# ---------------------------------------------------------------------------


def parse_trace(trace_path: Path) -> dict[str, Any]:
    """Parse a CC JSONL trace file into a dict suitable for TraceUploadPayload.

    Returns:
        {
            session_id, model, started_at, ended_at,
            total_input_tokens, total_output_tokens,
            total_cache_creation_tokens, total_cache_read_tokens,
            total_cost_usd, total_turns, total_tool_calls,
            steps: [ {step_num, tool_name, tool_input, input_tokens,
                       output_tokens, cache_creation_tokens, cache_read_tokens,
                       context_delta, cumulative_context, duration_ms} ]
        }
    """
    events: list[dict] = []
    try:
        for line in trace_path.read_text(errors="replace").splitlines():
            line = line.strip()
            if line:
                events.append(json.loads(line))
    except Exception:
        return {}

    if not events:
        return {}

    # Index tool_result events by tool_use_id for duration lookup
    # tool_result lives in user events: message.content[].type == "tool_result"
    tool_result_ts: dict[str, str] = {}  # tool_use_id → ISO timestamp
    for ev in events:
        if ev.get("type") != "user":
            continue
        for block in ev.get("message", {}).get("content", []):
            if isinstance(block, dict) and block.get("type") == "tool_result":
                tid = block.get("tool_use_id")
                if tid:
                    tool_result_ts[tid] = ev.get("timestamp", "")

    steps: list[dict] = []
    step_num = 0
    total_input = 0
    total_output = 0
    total_cache_create = 0
    total_cache_read = 0
    total_turns = 0
    total_tool_calls = 0
    compaction_count = 0
    started_at: str = ""
    ended_at: str = ""
    model: str = ""
    session_id: str = ""
    cumulative_context = 0

    for ev in events:
        ev_type = ev.get("type")

        # User prompt turns (text messages, not tool results)
        if ev_type == "system" and ev.get("subtype") == "compact_boundary":
            compaction_count += 1
            continue

        # Subsequent prompts in interactive sessions are recorded as queue-operations
        if ev_type == "queue-operation" and ev.get("operation") == "enqueue":
            text = (ev.get("content") or "").strip()[:3000]
            if text:
                step_num += 1
                steps.append({
                    "step_num": step_num,
                    "tool_name": "__prompt__",
                    "tool_input": {},
                    "text_content": text,
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "cache_creation_tokens": 0,
                    "cache_read_tokens": 0,
                    "context_delta": 0,
                    "cumulative_context": cumulative_context,
                    "duration_ms": 0.0,
                })
            continue

        if ev_type == "user":
            content = ev.get("message", {}).get("content", [])
            if isinstance(content, str):
                content = [{"type": "text", "text": content}]
            if isinstance(content, list):
                has_tool_results = any(
                    isinstance(b, dict) and b.get("type") == "tool_result"
                    for b in content
                )
                text_blocks = [
                    b for b in content
                    if isinstance(b, dict) and b.get("type") == "text"
                ]
                if text_blocks and not has_tool_results:
                    text = "\n".join(b.get("text", "") for b in text_blocks).strip()[:3000]
                    if text:
                        step_num += 1
                        steps.append({
                            "step_num": step_num,
                            "tool_name": "__prompt__",
                            "tool_input": {},
                            "text_content": text,
                            "input_tokens": 0,
                            "output_tokens": 0,
                            "cache_creation_tokens": 0,
                            "cache_read_tokens": 0,
                            "context_delta": 0,
                            "cumulative_context": cumulative_context,
                            "duration_ms": 0.0,
                        })
            continue

        if ev_type != "assistant":
            continue

        msg = ev.get("message", {})
        usage = msg.get("usage", {})
        stop_reason = msg.get("stop_reason")

        # Only process complete turns (with stop_reason)
        if not stop_reason:
            continue

        ev_ts = ev.get("timestamp", "")
        if not started_at:
            started_at = ev_ts
        ended_at = ev_ts
        if not model:
            model = msg.get("model", "")
        if not session_id:
            session_id = ev.get("sessionId", "")

        turn_input = usage.get("input_tokens", 0)
        turn_output = usage.get("output_tokens", 0)
        turn_cache_create = usage.get("cache_creation_input_tokens", 0)
        turn_cache_read = usage.get("cache_read_input_tokens", 0)
        turn_effective_ctx = turn_input + turn_cache_create + turn_cache_read

        total_input += turn_input
        total_output += turn_output
        total_cache_create += turn_cache_create
        total_cache_read += turn_cache_read
        total_turns += 1
        cumulative_context = turn_effective_ctx

        content = msg.get("content", [])
        text_blocks = [b for b in content if isinstance(b, dict) and b.get("type") == "text"]
        tool_blocks = [b for b in content if isinstance(b, dict) and b.get("type") == "tool_use"]
        thinking_blocks = [b for b in content if isinstance(b, dict) and b.get("type") == "thinking"]

        # Thinking blocks (extended thinking — captured separately, truncated at 5000 chars)
        if thinking_blocks:
            thinking_text = "\n\n".join(b.get("thinking", "") for b in thinking_blocks).strip()[:5000]
            if thinking_text:
                step_num += 1
                steps.append({
                    "step_num": step_num,
                    "tool_name": "__thinking__",
                    "tool_input": {},
                    "text_content": thinking_text,
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "cache_creation_tokens": 0,
                    "cache_read_tokens": 0,
                    "context_delta": 0,
                    "cumulative_context": cumulative_context,
                    "duration_ms": 0.0,
                })

        # Agent text / thinking turn
        if text_blocks:
            text = "\n".join(b.get("text", "") for b in text_blocks).strip()[:3000]
            if text:
                step_num += 1
                steps.append({
                    "step_num": step_num,
                    "tool_name": "__text__",
                    "tool_input": {},
                    "text_content": text,
                    # Attribute tokens to text step only when there are no tool calls
                    "input_tokens": turn_input if not tool_blocks else 0,
                    "output_tokens": turn_output if not tool_blocks else 0,
                    "cache_creation_tokens": turn_cache_create if not tool_blocks else 0,
                    "cache_read_tokens": turn_cache_read if not tool_blocks else 0,
                    "context_delta": turn_effective_ctx if not tool_blocks else 0,
                    "cumulative_context": cumulative_context,
                    "duration_ms": 0.0,
                })

        for i, block in enumerate(tool_blocks):
            step_num += 1
            total_tool_calls += 1
            tool_id = block.get("id", "")
            tool_name = block.get("name", "")
            tool_input = block.get("input", {})

            duration_ms = 0.0
            result_ts = tool_result_ts.get(tool_id, "")
            if ev_ts and result_ts:
                try:
                    t0 = datetime.fromisoformat(ev_ts.replace("Z", "+00:00"))
                    t1 = datetime.fromisoformat(result_ts.replace("Z", "+00:00"))
                    duration_ms = (t1 - t0).total_seconds() * 1000
                    if duration_ms < 0:
                        duration_ms = 0.0
                except Exception:
                    pass

            # Attribute turn tokens to first tool call (text step gets 0 when tools present)
            is_first = i == 0
            steps.append({
                "step_num": step_num,
                "tool_name": tool_name,
                "tool_input": tool_input,
                "input_tokens": turn_input if is_first else 0,
                "output_tokens": turn_output if is_first else 0,
                "cache_creation_tokens": turn_cache_create if is_first else 0,
                "cache_read_tokens": turn_cache_read if is_first else 0,
                "context_delta": turn_effective_ctx if is_first else 0,
                "cumulative_context": cumulative_context,
                "duration_ms": duration_ms,
            })

    total_cost = _calc_cost(total_input, total_output, total_cache_create, total_cache_read)

    return {
        "session_id": session_id,
        "model": model,
        "started_at": started_at,
        "ended_at": ended_at,
        "total_input_tokens": total_input,
        "total_output_tokens": total_output,
        "total_cache_creation_tokens": total_cache_create,
        "total_cache_read_tokens": total_cache_read,
        "total_cost_usd": total_cost,
        "total_turns": total_turns,
        "total_tool_calls": total_tool_calls,
        "compaction_count": compaction_count,
        "steps": steps,
    }


# ---------------------------------------------------------------------------
# SessionReporter
# ---------------------------------------------------------------------------


class SessionReporter:
    """Finds the CC trace file and submits the parsed trace to Talon Cloud."""

    def __init__(
        self,
        api_key: str = "",
        cloud_url: str = "https://api.cogmeta.ai",
        project_id: str = "",
        cwd: str | None = None,
        started_monotonic: float | None = None,
        session_id: str | None = None,
        run_id: str | None = None,
    ) -> None:
        self._api_key = api_key or os.environ.get("TALON_API_KEY", "")
        self._cloud_url = cloud_url.rstrip("/")
        self._project_id = project_id or os.environ.get("TALON_PROJECT_ID", "")
        self._cwd = cwd or os.getcwd()
        self._started_monotonic = started_monotonic
        self._session_id = session_id  # if set, find trace by session_id directly
        self._run_id = run_id or os.environ.get("TALON_RUN_ID") or None

    def submit(self) -> bool:
        """Parse the CC trace and POST it to the cloud API.

        Safe to call multiple times — backend upserts on client_session_id.
        """

        if not self._api_key:
            return False

        if self._session_id:
            trace_path = find_trace_by_session_id(self._session_id)
        else:
            trace_path = find_trace_file(self._cwd, self._started_monotonic)
        if not trace_path:
            return False

        parsed = parse_trace(trace_path)
        if not parsed or not parsed.get("steps") or parsed.get("total_turns", 0) == 0:
            return False

        mode = _get_telemetry_mode()
        steps = parsed.get("steps", [])
        if mode == "meta":
            # Meta mode: tool call stats only — no prompt/thinking text, no tool inputs
            steps = [
                {**s, "text_content": "", "tool_input": {}}
                for s in steps
                if s.get("tool_name") and not s["tool_name"].startswith("__")
            ]

        payload = {
            "project_id": self._project_id,
            "client_session_id": parsed.get("session_id", ""),
            "run_id": self._run_id,
            "started_at": parsed.get("started_at"),
            "ended_at": parsed.get("ended_at"),
            "total_cost_usd": parsed.get("total_cost_usd"),
            "total_input_tokens": parsed.get("total_input_tokens", 0),
            "total_output_tokens": parsed.get("total_output_tokens", 0),
            "total_cache_creation_tokens": parsed.get("total_cache_creation_tokens", 0),
            "total_cache_read_tokens": parsed.get("total_cache_read_tokens", 0),
            "total_turns": parsed.get("total_turns", 0),
            "total_tool_calls": parsed.get("total_tool_calls", 0),
            "compaction_count": parsed.get("compaction_count", 0),
            "model": parsed.get("model", ""),
            "talon_version": _get_version(),
            "steps": steps,
        }

        return self._post(payload)

    def _post(self, payload: dict) -> bool:
        try:
            import httpx
            resp = httpx.post(
                f"{self._cloud_url}/cloud/v1/talon/telemetry/trace",
                json=payload,
                headers={"X-API-Key": self._api_key},
                timeout=20.0,
            )
            return resp.status_code < 300
        except Exception:
            return False


def _get_version() -> str:
    try:
        from importlib.metadata import version
        return version("talon")
    except Exception:
        return ""


def _get_telemetry_mode() -> str:
    """Read telemetry.mode from ~/.talon/config.yaml. Returns 'full' or 'meta'."""
    try:
        import yaml
        cfg_path = Path.home() / ".talon" / "config.yaml"
        if cfg_path.exists():
            cfg = yaml.safe_load(cfg_path.read_text()) or {}
            mode = cfg.get("telemetry", {}).get("mode", "full")
            return mode if mode in ("full", "meta") else "full"
    except Exception:
        pass
    return "full"


# ---------------------------------------------------------------------------
# TraceWatcher — daemon thread that tails the JSONL and submits per turn
# ---------------------------------------------------------------------------

_POLL_INTERVAL = 8       # seconds between file reads
_DEBOUNCE_TURNS = 1      # submit after this many new complete turns
_FIND_FILE_RETRIES = 30  # wait up to 30×8s = 4 min for file to appear


class TraceWatcher:
    """Tails the CC JSONL transcript and upserts the trace after each turn.

    Started as a daemon thread by proxy_wrapper on session start.
    Stops automatically when stop() is called (proxy exits).
    """

    def __init__(self, reporter: SessionReporter) -> None:
        self._reporter = reporter
        self._stop_event = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True, name="trace-watcher")

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        """Signal the watcher to stop and do a final submit."""
        self._stop_event.set()

    def _run(self) -> None:
        trace_path = self._find_file()
        if trace_path is None:
            # File never appeared — still do a best-effort final submit
            self._reporter.submit()
            return

        offset = 0
        last_turn_count = 0

        while not self._stop_event.is_set():
            new_turns, offset = self._count_new_turns(trace_path, offset)
            if new_turns >= _DEBOUNCE_TURNS:
                last_turn_count += new_turns
                self._reporter.submit()
            self._stop_event.wait(timeout=_POLL_INTERVAL)

        # Final submit on stop (catches the last turn)
        self._reporter.submit()

    def _find_file(self) -> Path | None:
        """Wait for the trace file to appear, then return its path.

        Does NOT bail early when stop is set — completes the current search
        so short sessions (< 8s) still get their file found on the final submit.
        """
        for _ in range(_FIND_FILE_RETRIES):
            path = (
                find_trace_by_session_id(self._reporter._session_id)
                if self._reporter._session_id
                else find_trace_file(self._reporter._cwd, self._reporter._started_monotonic)
            )
            if path:
                return path
            if self._stop_event.is_set():
                # Stopped mid-search — one last try without the mtime gate
                return find_trace_file(self._reporter._cwd, started_after=None)
            self._stop_event.wait(timeout=_POLL_INTERVAL)
        return None

    @staticmethod
    def _count_new_turns(path: Path, offset: int) -> tuple[int, int]:
        """Read new bytes from path since offset. Return (new_complete_turns, new_offset)."""
        try:
            size = path.stat().st_size
            if size <= offset:
                return 0, offset
            with path.open("rb") as f:
                f.seek(offset)
                new_bytes = f.read(size - offset)
            new_offset = offset + len(new_bytes)
            turns = sum(
                1 for line in new_bytes.decode("utf-8", errors="replace").splitlines()
                if line.strip() and _is_complete_turn(line)
            )
            return turns, new_offset
        except Exception:
            return 0, offset


def _is_complete_turn(line: str) -> bool:
    """Return True if this JSONL line is an assistant event with stop_reason set."""
    try:
        obj = json.loads(line)
        return (
            obj.get("type") == "assistant"
            and bool(obj.get("message", {}).get("stop_reason"))
        )
    except Exception:
        return False
