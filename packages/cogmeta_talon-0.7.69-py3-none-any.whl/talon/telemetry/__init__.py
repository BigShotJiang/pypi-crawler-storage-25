"""Talon client-side telemetry: token proxy + session reporter."""
