"""Talon MCP server."""
