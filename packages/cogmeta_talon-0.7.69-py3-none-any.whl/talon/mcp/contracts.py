"""Response contract system for talon v5.

Contracts define what each intent+depth returns. They serve three purposes:
1. Tool description — embedded in MCP tool schema so the LLM knows what it gets
2. Response shaping — server uses them to build responses
3. Auto-refresh — regenerated when capabilities change
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

# Default contracts directory
CONTRACTS_DIR = Path(__file__).parent.parent / "contracts"

# Canonical intent list — the enum exposed in graph_query's inputSchema.
# Only a subset will have YAML contracts at any time; the rest are planned.
ALL_INTENTS = ["toc", "locate", "callers", "blast", "coverage", "flow", "sync", "scope", "cg", "cg_update", "search", "insert", "cochange", "hierarchy", "imports", "hotspots"]

# Canonical depth tiers
DEPTH_TIERS = ["shallow", "standard", "full", "edit"]

# Characters-per-token estimate used for budget validation
CHARS_PER_TOKEN = 4


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class DepthSpec:
    """Specification for a single depth tier within an intent contract."""

    token_budget: int
    fields: list[str]
    warnings: bool = False
    related: bool = False
    temporal: bool = False
    example: str = ""


@dataclass
class ContractDef:
    """Full contract for one intent, covering all depth tiers."""

    intent: str
    description: str
    depths: dict[str, DepthSpec]  # "shallow", "standard", "full"


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

def _parse_depth(raw: dict[str, Any]) -> DepthSpec:
    """Parse a single depth entry from YAML into a DepthSpec."""
    return DepthSpec(
        token_budget=int(raw["token_budget"]),
        fields=list(raw.get("fields", [])),
        warnings=bool(raw.get("warnings", False)),
        related=bool(raw.get("related", False)),
        temporal=bool(raw.get("temporal", False)),
        example=str(raw.get("example", "")),
    )


def load_contracts(contracts_dir: Path | None = None) -> dict[str, ContractDef]:
    """Load all intent contract YAML files from the contracts directory.

    Scans for ``*.yaml`` files, parses each into a :class:`ContractDef`, and
    returns a dict mapping intent name to its contract.

    Args:
        contracts_dir: Override directory.  Defaults to ``CONTRACTS_DIR``.

    Returns:
        Mapping of intent name to ``ContractDef``.
    """
    directory = contracts_dir or CONTRACTS_DIR
    contracts: dict[str, ContractDef] = {}

    if not directory.is_dir():
        logger.warning("Contracts directory does not exist: %s", directory)
        return contracts

    for yaml_path in sorted(directory.glob("*.yaml")):
        try:
            with open(yaml_path, "r", encoding="utf-8") as fh:
                raw = yaml.safe_load(fh)

            if not isinstance(raw, dict) or "intent" not in raw:
                logger.warning("Skipping invalid contract file: %s", yaml_path)
                continue

            intent_name: str = raw["intent"]
            depths: dict[str, DepthSpec] = {}
            for depth_name, depth_raw in raw.get("depths", {}).items():
                depths[depth_name] = _parse_depth(depth_raw)

            contract = ContractDef(
                intent=intent_name,
                description=str(raw.get("description", "")),
                depths=depths,
            )
            contracts[intent_name] = contract
            logger.debug("Loaded contract: %s (%d depths)", intent_name, len(depths))

        except Exception:
            logger.exception("Failed to load contract from %s", yaml_path)

    logger.info("Loaded %d contract(s) from %s", len(contracts), directory)
    return contracts


# ---------------------------------------------------------------------------
# Tool description generation
# ---------------------------------------------------------------------------

def build_tool_description(contracts: dict[str, ContractDef]) -> str:
    """Generate the ``graph_query`` tool description from contracts.

    This is the single source of truth for what the LLM sees.  Includes
    example return data for each intent so the LLM knows exactly what
    it gets back — not just a prose description.

    Args:
        contracts: Loaded contract definitions.

    Returns:
        Multi-line description string.
    """
    lines: list[str] = ["Query the code graph. Returns structured data you can act on directly."]
    lines.append("")
    lines.append("WHEN TO USE: Use this BEFORE Read/Grep/Glob when you need to understand code structure,")
    lines.append("find where symbols are defined/used, or trace call dependencies across files.")
    lines.append("A single graph_query replaces multiple exploratory file reads. Skip for tasks that")
    lines.append("don't involve navigating existing code (typo fixes, new file creation, etc.).")
    lines.append("")

    # --- Intents with examples ---
    for intent_name in ALL_INTENTS:
        if intent_name not in contracts:
            continue
        contract = contracts[intent_name]
        lines.append(f"{intent_name}: {contract.description}")
        # Show the shallow example — concise, shows return shape
        shallow = contract.depths.get("shallow")
        if shallow and shallow.example:
            for ex_line in shallow.example.strip().splitlines():
                lines.append(f"  {ex_line}")
        lines.append("")

    # --- Depth section ---
    shallow_budget = _representative_budget(contracts, "shallow", default=50)
    standard_budget = _representative_budget(contracts, "standard", default=200)
    full_budget = _representative_budget(contracts, "full", default=800)

    lines.append("Multi-hop: For callers/flow, set hops=2-5 to trace call chains through pipelines.")
    lines.append("")
    lines.append("Depth controls detail level:")
    lines.append(f"  shallow (~{shallow_budget} tok) -- names + file:line only")
    lines.append(f"  standard (~{standard_budget} tok) -- + warnings, related files, signatures")
    lines.append(f"  full (~{full_budget} tok) -- + complete source body, temporal history")
    lines.append("")
    lines.append("KEY PATTERN — locate(depth=full) returns the complete function body in ONE call.")
    lines.append("Use it whenever you know a symbol name, instead of calling toc then smart_read_batch:")
    lines.append("  graph_query(intent='locate', target='Blueprint.start', depth='full')  # 1 call")
    lines.append("  vs toc('bootsteps.py') + smart_read_batch('Blueprint.start')           # 2 calls")
    lines.append("Use toc only for DISCOVERY — when you don't know which symbols exist in a file.")

    return "\n".join(lines)


def _representative_budget(
    contracts: dict[str, ContractDef],
    depth: str,
    default: int,
) -> int:
    """Pick a representative token budget for a depth tier.

    Uses the median budget across loaded contracts, falling back to *default*.
    """
    budgets = [
        c.depths[depth].token_budget
        for c in contracts.values()
        if depth in c.depths
    ]
    if not budgets:
        return default
    budgets.sort()
    return budgets[len(budgets) // 2]


# ---------------------------------------------------------------------------
# MCP tool definition
# ---------------------------------------------------------------------------

def build_graph_query_tool(contracts: dict[str, ContractDef]) -> dict[str, Any]:
    """Build the full MCP tool definition dict for ``graph_query``.

    Returns the dict matching MCP Tool schema with:

    - ``name``: ``"graph_query"``
    - ``description``: built from contracts via :func:`build_tool_description`
    - ``inputSchema`` with ``intent`` enum, ``target``, ``depth``

    Args:
        contracts: Loaded contract definitions.

    Returns:
        Dict suitable for passing to ``mcp.types.Tool(**result)`` or
        serialising directly as JSON.
    """
    description = build_tool_description(contracts)

    return {
        "name": "graph_query",
        "description": description,
        "inputSchema": {
            "type": "object",
            "properties": {
                "intent": {
                    "type": "string",
                    "enum": ALL_INTENTS,
                    "description": "The kind of graph query to perform.",
                },
                "target": {
                    "type": "string",
                    "description": (
                        "File path, symbol name, or search term depending on intent."
                    ),
                },
                "depth": {
                    "type": "string",
                    "enum": DEPTH_TIERS,
                    "default": "standard",
                    "description": (
                        "How much detail to return.  shallow is cheapest, "
                        "full includes source snippets and temporal data. "
                        "edit returns function headers with 2-3 body lines "
                        "for crafting Edit old_string matches."
                    ),
                },
                "hops": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 5,
                    "description": (
                        "Multi-hop traversal depth for callers/flow intents. "
                        "Default: 1 (direct only). Set 2-5 for pipeline tracing."
                    ),
                },
            },
            "required": ["intent", "target"],
        },
    }


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_response(
    intent: str,
    depth: str,
    response: str,
    contracts: dict[str, ContractDef],
) -> bool:
    """Check response stays within token budget (estimated at ~4 chars per token).

    Args:
        intent:    The intent name (e.g. ``"toc"``).
        depth:     The depth tier (e.g. ``"standard"``).
        response:  The response text to validate.
        contracts: Loaded contract definitions.

    Returns:
        ``True`` if the response is within budget or no contract is defined
        for the given intent+depth.  ``False`` if the budget is exceeded.
    """
    contract = contracts.get(intent)
    if contract is None:
        logger.debug("No contract for intent=%s; skipping validation", intent)
        return True

    spec = contract.depths.get(depth)
    if spec is None:
        logger.debug("No depth spec for intent=%s depth=%s; skipping validation", intent, depth)
        return True

    estimated_tokens = len(response) / CHARS_PER_TOKEN
    if estimated_tokens > spec.token_budget:
        logger.warning(
            "Response exceeds budget: intent=%s depth=%s estimated=%.0f budget=%d",
            intent,
            depth,
            estimated_tokens,
            spec.token_budget,
        )
        return False

    return True
