#!/usr/bin/env python3
"""Direct MCP SSE proxy — no mcp-proxy dependency.

Bridges Claude Code stdio ↔ server SSE without any external binary.
On SSE disconnect: sends error responses for pending calls (CC retries),
reconnects automatically, replays the MCP handshake, resumes forwarding.
CC sees a single always-alive MCP server regardless of server restarts.

Usage in .mcp.json:
    {
        "mcpServers": {
            "talon": {
                "command": "talon-proxy-wrapper",
                "args": ["https://api.cogmeta.ai/talon/mcp/sse"],
                "env": {"TALON_API_KEY": "your-api-key"}
            }
        }
    }
"""

from __future__ import annotations

import json
import os
import queue
import signal
import ssl
import sys
import threading
import time
from pathlib import Path
from urllib.error import URLError
from urllib.parse import urlparse, urlunparse
from urllib.request import Request, urlopen

# Project root — used for local smart_read_batch
_PROJECT_ROOT = Path(os.getcwd())

from talon.mcp.session_scorer import SessionScorer

try:
    from talon.cache.memory_store import MemoryStore as _MemoryStore
except Exception:
    _MemoryStore = None  # type: ignore[assignment,misc]

try:
    from talon.telemetry.session_reporter import SessionReporter as _SessionReporter
    from talon.telemetry.session_reporter import TraceWatcher as _TraceWatcher
except Exception:
    _SessionReporter = None  # type: ignore[assignment,misc]
    _TraceWatcher = None     # type: ignore[assignment,misc]

try:
    from talon import __version__ as _VERSION
except Exception:
    _VERSION = "0"

# Looks like a real browser/app to Cloudflare — not a bot signature
_USER_AGENT = f"Talon/{_VERSION}"

MAX_RETRIES = 50
BACKOFF_BASE = 1.0
BACKOFF_MAX = 30.0
BACKOFF_MULTIPLIER = 1.5

SSE_CONNECT_TIMEOUT = 15     # seconds to establish SSE connection
SSE_READ_TIMEOUT = 120       # seconds between SSE events before considering dead
POST_TIMEOUT = 30            # seconds for each POST message
HEALTH_CHECK_INTERVAL = 30
HEALTH_CHECK_TIMEOUT = 5
HEALTH_WAIT_TIMEOUT = 60
HEALTH_WAIT_INTERVAL = 2


def _log(msg: str) -> None:
    print(f"[talon-proxy] {msg}", file=sys.stderr, flush=True)


def _load_credential_key() -> str:
    try:
        p = Path.home() / ".talon" / "credentials.json"
        return json.loads(p.read_text()).get("api_key", "")
    except Exception:
        return ""


def _make_ssl_ctx() -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    cert_file = os.environ.get("SSL_CERT_FILE")
    if cert_file:
        ctx.load_verify_locations(cert_file)
    return ctx


def _fetch_proxy_cfg(cloud_url: str, api_key: str) -> dict:
    """Fetch gate flags from GET /talon/mcp/config on the cloud server.

    Returns the named-config values relevant to the proxy (srb_gal_gate, etc.).
    On any failure returns an empty dict so the proxy operates with defaults.
    """
    try:
        url = cloud_url.rstrip("/") + "/talon/mcp/config"
        req = Request(url, headers={"X-API-Key": api_key}, method="GET")
        with urlopen(req, timeout=5, context=_make_ssl_ctx()) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        _log(f"proxy-config fetch failed (using defaults): {exc}")
        return {}



def _correct_path(path: str, store: "_MemoryStore | None" = None) -> str:  # type: ignore[valid-type]
    """Suffix-match an agent-sent file path against local MemoryStore.cached_paths.

    The cloud MCP server has no MemoryStore (source never leaves the client) so
    server-side path correction always fails. Resolve prefix drift here where the
    authoritative file list lives. Returns the canonical cached path when an
    unambiguous suffix match exists, else the original path.
    """
    if not path or "/" not in path or store is None:
        return path
    try:
        cached = store.cached_paths
    except Exception:
        return path
    if path in cached:
        return path
    needle = "/" + path
    matches = [p for p in cached if p.endswith(needle)]
    if not matches:
        stem = path.rsplit("/", 1)[-1]
        matches = [p for p in cached if p.endswith("/" + stem) or p == stem]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        matches.sort(key=len)
        return matches[0]
    return path


def _correct_tool_args(tool_name: str, args: dict, store: "_MemoryStore | None" = None) -> bool:  # type: ignore[valid-type]
    """Rewrite file paths in tool-call arguments in place. Returns True if anything changed."""
    if not isinstance(args, dict) or store is None:
        return False
    changed = False

    if tool_name in ("graph_ask_lite", "graph_ask"):
        exp = args.get("expected_files")
        if isinstance(exp, str):
            try:
                exp = json.loads(exp)
            except Exception:
                exp = None
        if isinstance(exp, list):
            new_exp = [_correct_path(p, store) if isinstance(p, str) else p for p in exp]
            if new_exp != exp:
                args["expected_files"] = new_exp
                changed = True

    elif tool_name == "graph_query":
        tgt = args.get("target")
        if isinstance(tgt, str):
            new_tgt = _correct_path(tgt, store)
            if new_tgt != tgt:
                args["target"] = new_tgt
                changed = True

    elif tool_name == "smart_read_batch":
        targets = args.get("targets") or args.get("reads")
        if isinstance(targets, str):
            try:
                targets = json.loads(targets)
            except Exception:
                targets = None
        if isinstance(targets, list):
            for t in targets:
                if isinstance(t, dict):
                    f = t.get("file")
                    if isinstance(f, str):
                        nf = _correct_path(f, store)
                        if nf != f:
                            t["file"] = nf
                            changed = True
            if changed:
                if "targets" in args:
                    args["targets"] = targets
                else:
                    args["reads"] = targets

    elif tool_name == "edit_batch":
        edits = args.get("edits")
        if isinstance(edits, str):
            try:
                edits = json.loads(edits)
            except Exception:
                edits = None
        if isinstance(edits, list):
            for e in edits:
                if isinstance(e, dict):
                    f = e.get("file_path")
                    if isinstance(f, str):
                        nf = _correct_path(f, store)
                        if nf != f:
                            e["file_path"] = nf
                            changed = True
            if changed:
                args["edits"] = edits

    return changed


def _srb_local(targets: list[dict], store: "_MemoryStore | None" = None) -> str | None:  # type: ignore[valid-type]
    """Handle smart_read_batch locally via MemoryStore (L1/L2) with disk fallback.

    - Line-range reads: MemoryStore.get_lines() → disk fallback if miss
    - Symbol lookups: MemoryStore.locate_symbol() + get_symbol_at() → None (cloud) if no store
    Returns None only when a symbol lookup is needed but store unavailable.
    """
    results = []
    for t in targets:
        file_path = t.get("file", "")
        lines_spec = t.get("lines", "")
        symbol = t.get("symbol", "")

        if symbol and not lines_spec:
            # Symbol lookup — requires MemoryStore L2
            if store is None:
                return None  # store not ready yet, forward to cloud
            locs = store.locate_symbol(symbol)
            if not locs:
                fuzzy = store.locate_symbol_fuzzy(symbol, max_results=1)
                locs = [(fuzzy[0][0], fuzzy[0][1])] if fuzzy else []
            if not locs:
                results.append(f"--- {file_path or symbol} — symbol not found in index")
                continue
            fp_rel, line_num = locs[0]
            sym_info = store.get_symbol_at(fp_rel, line_num)
            if sym_info:
                start_l, end_l = sym_info["line_start"], sym_info["line_end"]
            else:
                start_l = max(1, line_num - 2)
                end_l = line_num + 40
            chunk = store.get_lines(fp_rel, start_l, end_l)
            if not chunk:
                results.append(f"--- {fp_rel} — lines not in cache")
                continue
            numbered = "\n".join(f"{start_l + i}│{ln.rstrip()}" for i, ln in enumerate(chunk))
            results.append(f"--- {fp_rel} {start_l}-{end_l}\n{numbered}")
            continue

        if not file_path:
            results.append(f"--- ? — missing file path")
            continue

        if not lines_spec:
            # No line range = discovery not done yet. Redirect to toc/locate.
            results.append(
                f"[TALON] smart_read_batch requires a line range for '{file_path}'.\n"
                f"You must discover line ranges first:\n"
                f"  graph_query(intent='toc', target='{file_path}')         # list symbols + line numbers\n"
                f"  graph_query(intent='locate', target='ClassName')         # find exact line\n"
                f"Then call smart_read_batch with the specific lines."
            )
            continue

        try:
            parts = lines_spec.split("-")
            start_l = int(parts[0])
            end_l = int(parts[1]) if len(parts) > 1 else start_l
        except (ValueError, IndexError):
            results.append(f"--- {file_path} — invalid lines spec: {lines_spec}")
            continue

        # Try MemoryStore L1 first
        if store is not None:
            rel = file_path.lstrip("/")
            chunk = store.get_lines(rel, start_l, end_l)
            if chunk:
                numbered = "\n".join(f"{start_l + i}│{ln.rstrip()}" for i, ln in enumerate(chunk))
                results.append(f"--- {file_path} {lines_spec}\n{numbered}")
                continue

        # Disk fallback (store miss or not ready)
        fp = _PROJECT_ROOT / file_path.lstrip("/")
        if not fp.exists():
            results.append(f"--- {file_path} {lines_spec} — file not found")
            continue
        try:
            all_lines = fp.read_text(errors="replace").splitlines()
        except OSError as exc:
            results.append(f"--- {file_path} — read error: {exc}")
            continue
        sl = max(0, start_l - 1)
        el = min(len(all_lines), end_l)
        chunk = all_lines[sl:el]
        numbered = "\n".join(f"{sl + 1 + i}│{ln.rstrip()}" for i, ln in enumerate(chunk))
        results.append(f"--- {file_path} {lines_spec}\n{numbered}")

    return "\n\n".join(results)


def _edit_batch_local(edits: list[dict], project_root: Path) -> tuple[str, list[tuple[str, str]]]:
    """Apply edits locally and return (formatted_result, [(file_path, new_content), ...]).

    Replicates local_server edit_batch behaviour:
    - old_string → new_string replacement (unique match required)
    - empty old_string → create new file
    - Returns [OK]/[FAIL] lines, then runs pytest if TALON_EDIT_PYTEST=1
    """
    results: list[dict] = []
    refreshable: list[tuple[str, str]] = []  # (file_path, new_content) for successful edits

    for edit in edits[:20]:
        file_path = edit.get("file_path", "")
        old_string = edit.get("old_string", "")
        new_string = edit.get("new_string", "")

        if not file_path:
            results.append({"file": "(empty)", "status": "error", "detail": "missing file_path"})
            continue

        fp = Path(file_path)
        if not fp.is_absolute():
            fp = project_root / fp

        # New file creation
        if not old_string:
            if not new_string:
                results.append({"file": file_path, "status": "error", "detail": "empty old_string and new_string"})
                continue
            if fp.exists() and fp.read_text().strip():
                results.append({"file": file_path, "status": "error", "detail": "file exists — use old_string"})
                continue
            try:
                fp.parent.mkdir(parents=True, exist_ok=True)
                fp.write_text(new_string)
                results.append({"file": file_path, "status": "created", "detail": f"new file ({len(new_string)} chars)"})
                try:
                    rel = str(fp.relative_to(project_root))
                except ValueError:
                    rel = file_path
                refreshable.append((rel.replace("\\", "/"), new_string))
            except Exception as exc:
                results.append({"file": file_path, "status": "error", "detail": str(exc)})
            continue

        try:
            content = fp.read_text()
        except FileNotFoundError:
            results.append({"file": file_path, "status": "error", "detail": f"file not found: {fp}"})
            continue
        except Exception as exc:
            results.append({"file": file_path, "status": "error", "detail": str(exc)})
            continue

        count = content.count(old_string)
        if count == 0:
            # Find closest line + emit raw-source slice around it so the agent
            # can copy it verbatim as the corrected old_string — avoids a
            # wasteful smart_read_batch round-trip.
            content_lines = content.splitlines()
            first_line = next((ln.strip() for ln in old_string.splitlines() if ln.strip()), "")
            match_idx = -1
            if first_line:
                probe = first_line[:20]
                for i, ln in enumerate(content_lines):
                    if probe in ln:
                        match_idx = i
                        break
            hint = ""
            slice_block = ""
            if match_idx >= 0:
                hint = f" (closest L{match_idx + 1}: {content_lines[match_idx].strip()[:60]!r})"
                old_span = max(1, len(old_string.splitlines()))
                start = max(0, match_idx - 2)
                end = min(len(content_lines), match_idx + old_span + 3)
                raw_slice = "\n".join(content_lines[start:end])
                slice_block = (
                    "\n    Raw source L" + f"{start + 1}-{end} (use verbatim as old_string):\n"
                    "    ```\n"
                    + "\n".join(f"    {ln}" for ln in raw_slice.splitlines())
                    + "\n    ```"
                )
            detail = f"old_string not found{hint}{slice_block}"
            results.append({"file": file_path, "status": "error", "detail": detail})
            continue
        if count > 1:
            results.append({"file": file_path, "status": "error", "detail": f"old_string not unique ({count} matches)"})
            continue

        try:
            new_content = content.replace(old_string, new_string, 1)
            fp.write_text(new_content)
            results.append({"file": file_path, "status": "ok", "detail": f"applied ({len(old_string)}→{len(new_string)} chars)"})
            # Track for MemoryStore refresh — use relative path
            try:
                rel = str(fp.relative_to(project_root))
            except ValueError:
                rel = file_path
            refreshable.append((rel.replace("\\", "/"), new_content))
        except Exception as exc:
            results.append({"file": file_path, "status": "error", "detail": str(exc)})

    ok = sum(1 for r in results if r["status"] in ("ok", "created"))
    lines = [f"edit_batch: {ok}/{len(results)} applied"]
    for r in results:
        icon = "OK" if r["status"] in ("ok", "created") else "FAIL"
        lines.append(f"  [{icon}] {r['file']} — {r['detail']}")

    # TALON_EDIT_PYTEST=1 — run pytest on test files matching edited sources
    if os.environ.get("TALON_EDIT_PYTEST", "0") == "1" and ok > 0:
        edited = [r["file"] for r in results if r["status"] in ("ok", "created")]
        pytest_out = _run_pytest_for_edits(edited, project_root)
        if pytest_out:
            lines.append("")
            lines.extend(pytest_out.splitlines())

    return "\n".join(lines), refreshable


def _run_pytest_for_edits(edited_files: list[str], project_root: Path) -> str:
    """Discover and run pytest for files matching edited sources."""
    import subprocess

    test_targets: list[str] = []
    for ef in edited_files:
        base = Path(ef).stem
        if base.startswith("test_"):
            test_targets.append(ef)
            continue
        # Convention: foo.py → t/unit/.../test_foo.py or tests/test_foo.py
        for candidate in project_root.rglob(f"test_{base}.py"):
            test_targets.append(str(candidate.relative_to(project_root)))

    if not test_targets:
        return ""

    timeout = int(os.environ.get("TALON_EDIT_PYTEST_TIMEOUT", "30"))
    extra_args = os.environ.get("TALON_PYTEST_ARGS", "-x -q").split()
    cmd = ["python3", "-m", "pytest"] + extra_args + test_targets

    try:
        result = subprocess.run(
            cmd, cwd=str(project_root), capture_output=True, text=True, timeout=timeout
        )
        out = (result.stdout + result.stderr).strip()
        status = "PASS" if result.returncode == 0 else "FAIL"
        summary_line = next((ln for ln in reversed(out.splitlines()) if ln.strip()), "")
        return f"pytest [{status}] {summary_line}\n{out[-2000:]}" if out else f"pytest [{status}]"
    except subprocess.TimeoutExpired:
        return f"pytest [TIMEOUT] exceeded {timeout}s"
    except Exception as exc:
        return f"pytest [ERROR] {exc}"


def _derive_health_url(sse_url: str) -> str:
    p = urlparse(sse_url)
    path = p.path[:-4] + "/health" if p.path.endswith("/sse") else p.path.rstrip("/") + "/health"
    return urlunparse((p.scheme, p.netloc, path, "", "", ""))


def _derive_post_url(sse_url: str, session_id: str) -> str:
    p = urlparse(sse_url)
    path = p.path[:-4] + "/messages" if p.path.endswith("/sse") else p.path.rstrip("/") + "/messages"
    return urlunparse((p.scheme, p.netloc, path, "", f"session_id={session_id}", ""))


def _check_health(health_url: str, api_key: str) -> bool:
    try:
        req = Request(health_url, headers={
            "User-Agent": _USER_AGENT,
            "X-API-Key": api_key,
            "Authorization": f"Bearer {api_key}",
        })
        with urlopen(req, timeout=HEALTH_CHECK_TIMEOUT, context=_make_ssl_ctx()) as r:
            return r.status == 200
    except Exception:
        return False


def _wait_for_health(health_url: str, api_key: str) -> bool:
    deadline = time.monotonic() + HEALTH_WAIT_TIMEOUT
    attempts = 0
    while time.monotonic() < deadline:
        if _check_health(health_url, api_key):
            if attempts:
                _log(f"Server healthy after {attempts} checks.")
            return True
        attempts += 1
        time.sleep(HEALTH_WAIT_INTERVAL)
    _log("Timed out waiting for server health.")
    return False


# ---------------------------------------------------------------------------
# DirectSseProxy
# ---------------------------------------------------------------------------

class DirectSseProxy:
    """Stdio ↔ SSE bridge without mcp-proxy.

    - Reads JSON-RPC from CC stdin, POSTs to server
    - Reads SSE stream from server, writes JSON-RPC to CC stdout
    - On disconnect: errors pending calls, reconnects, replays handshake
    """

    def __init__(self, sse_url: str, api_key: str) -> None:
        self._sse_url = sse_url
        self._api_key = api_key
        self._health_url = _derive_health_url(sse_url)
        self._session_id: str | None = None
        self._post_url: str | None = None

        self._running = True
        self._session_ready = threading.Event()  # set when session_id known + handshake done
        self._outbound: queue.Queue[bytes] = queue.Queue()
        self._pending_calls: dict[int | str, str] = {}  # id → tool_name
        self._pending_lock = threading.Lock()

        self._init_msg: str | None = None
        self._init_id: int | str | None = None
        self._prompt_idx = 0

        # Per-prompt tracking for srb_gal_gate / l2_every_prompt
        self._pt_gal_called = False
        self._pt_gq_called = False
        self._pt_l2_injected = False
        self._pt_srb_count = 0  # per-prompt SRB counter for proxy-side hard cap
        self._pt_prompt_num = -1  # last seen prompt number from prompt_number.txt
        # AUTO-GAL enrichment: refreshed on prompt boundary from .claude/state/ and
        # forwarded to the cloud MCP via X-Talon-* headers on each POST. Gives the
        # server-side AUTO-GAL the real user prompt instead of synthesized hints.
        self._pt_prompt_task: str = ""
        self._pt_expected_files: list[str] = []

        # Named config fetched from server at startup; refreshed at prompt boundaries
        # Seed from env vars immediately so gate is active before async fetch completes.
        # The background fetch overrides these with server values (named config) once done.
        self._proxy_cfg: dict = {
            "srb_gal_gate":    int(os.environ.get("TALON_SRB_GAL_GATE", "0")),
            "l2_every_prompt": int(os.environ.get("TALON_L2_EVERY_PROMPT", "0")),
        }
        threading.Thread(target=self._refresh_proxy_cfg, daemon=True).start()

        # MemoryStore — built in background at startup; SRB serves from it once ready
        self._memory_store: "_MemoryStore | None" = None  # type: ignore[valid-type]
        self._store_ready = threading.Event()
        if _MemoryStore is not None:
            threading.Thread(target=self._build_store, daemon=True).start()
        else:
            self._store_ready.set()  # no store available, never block on it

        self._scorer = SessionScorer()
        self._session_start = time.monotonic()
        self._reporter: _SessionReporter | None = None
        self._watcher: _TraceWatcher | None = None
        if _SessionReporter is not None:
            try:
                import uuid as _uuid
                _run_id = os.environ.get("TALON_RUN_ID") or str(_uuid.uuid4())
                os.environ["TALON_RUN_ID"] = _run_id
                self._reporter = _SessionReporter(
                    api_key=api_key,
                    cloud_url=os.environ.get("TALON_CLOUD_URL", "https://api.cogmeta.ai"),
                    project_id=os.environ.get("TALON_PROJECT_ID", ""),
                    cwd=os.getcwd(),
                    started_monotonic=self._session_start,
                    run_id=_run_id,
                )
                if _TraceWatcher is not None and api_key:
                    self._watcher = _TraceWatcher(self._reporter)
                    self._watcher.start()
            except Exception:
                pass

    # ------------------------------------------------------------------ run

    def run(self) -> int:
        # CC reader starts immediately — queues messages while SSE is connecting
        threading.Thread(target=self._cc_reader, daemon=True).start()

        retries = 0
        backoff = BACKOFF_BASE
        is_first = True

        while self._running and retries < MAX_RETRIES:
            if not is_first:
                _log("Waiting for server before reconnect…")
                if not _wait_for_health(self._health_url, self._api_key):
                    retries += 1
                    time.sleep(min(backoff * BACKOFF_MULTIPLIER, BACKOFF_MAX))
                    continue

            session_id = self._connect_sse()
            if session_id is None:
                retries += 1
                time.sleep(backoff)
                backoff = min(backoff * BACKOFF_MULTIPLIER, BACKOFF_MAX)
                continue

            self._session_id = session_id
            self._post_url = _derive_post_url(self._sse_url, session_id)

            if not is_first:
                # Replay MCP initialize before unblocking the outbound writer
                if not self._replay_handshake():
                    _log("Handshake replay failed — retrying.")
                    retries += 1
                    time.sleep(backoff)
                    backoff = min(backoff * BACKOFF_MULTIPLIER, BACKOFF_MAX)
                    continue
                _log("Session recovered — forwarding resumes.")

            is_first = False
            self._session_ready.set()

            # Start outbound writer for this session
            writer = threading.Thread(target=self._outbound_writer, daemon=True)
            writer.start()

            # Block reading SSE until disconnect
            disconnect_reason = self._read_sse_forever()

            self._session_ready.clear()

            if not self._running:
                break

            # Unblock CC for any in-flight calls
            self._flush_pending_as_errors("MCP session disconnected — reconnecting automatically.")

            elapsed = time.monotonic() - self._session_start
            if elapsed > 60:
                backoff = BACKOFF_BASE
                retries = 0

            retries += 1
            _log(f"SSE disconnected ({disconnect_reason}). Reconnect {retries}/{MAX_RETRIES}…")
            time.sleep(backoff)
            backoff = min(backoff * BACKOFF_MULTIPLIER, BACKOFF_MAX)

        # Submit final score snapshot so all-time average includes this session
        final_snap = self._scorer.score()
        if final_snap.prompts >= 3:
            self._post_score(final_snap)
        self._submit_trace()
        return 0 if not self._running else 1

    # ------------------------------------------------------------------ named config

    def _refresh_proxy_cfg(self) -> None:
        """Fetch gate flags from GET /talon/mcp/config and update self._proxy_cfg."""
        cloud_url = os.environ.get("TALON_CLOUD_URL", "https://api.cogmeta.ai")
        api_key = self._api_key or os.environ.get("TALON_API_KEY", "")
        cfg = _fetch_proxy_cfg(cloud_url, api_key)
        if cfg:
            self._proxy_cfg = cfg
            _log(f"proxy-config loaded: {cfg}")

    # ------------------------------------------------------------------ MemoryStore

    def _build_store(self) -> None:
        """Build MemoryStore from project files in background at startup."""
        try:
            store = _MemoryStore()  # type: ignore[misc]
            store.build(_PROJECT_ROOT)
            self._memory_store = store
            _log(f"MemoryStore ready: {store.file_count} files, {store.symbol_count} symbols")
        except Exception as exc:
            _log(f"MemoryStore build failed: {exc} — SRB will use disk reads")
        finally:
            self._store_ready.set()

    def _refresh_store(self, edited: list[tuple[str, str]]) -> None:
        """Refresh MemoryStore entries after edit_batch (called from bg thread)."""
        store = self._memory_store
        if store is None or not edited:
            return
        for rel_path, new_content in edited:
            try:
                store.refresh_file(rel_path, new_content)
            except Exception as exc:
                _log(f"MemoryStore refresh failed for {rel_path}: {exc}")

    def _inject_gal_bodies(self, text: str) -> str:
        """Replace __TALON_REFS__ sentinel with actual function bodies from local MemoryStore."""
        marker = "\n\n__TALON_REFS__:"
        if marker not in text:
            return text
        base, refs_json = text.split(marker, 1)
        try:
            refs = json.loads(refs_json.strip())
        except json.JSONDecodeError:
            return base  # strip malformed refs

        store = self._memory_store
        if store is None:
            return base  # store not ready — drop refs, return base response

        injected: list[str] = []
        for ref in refs:
            fp = ref.get("f", "")
            ls = ref.get("ls", 0)
            le = ref.get("le", 0)
            if not fp or not ls:
                continue
            lines = store.get_lines(fp, ls, le)
            if not lines:
                continue
            numbered = "\n".join(f"{ls + i}│{ln.rstrip()}" for i, ln in enumerate(lines))
            injected.append(f"\n--- {fp} {ls}-{le}\n{numbered}")

        if injected:
            return base + "\n\n[bodies]\n" + "\n".join(injected)
        return base

    def _fire_sync(self, edited: list[tuple[str, str]]) -> None:
        """POST edited file contents to cloud /talon/mcp/sync (fire-and-forget)."""
        if not edited:
            return
        cloud_url = os.environ.get("TALON_CLOUD_URL", "https://api.cogmeta.ai").rstrip("/")
        project_id = os.environ.get("TALON_PROJECT_ID", "")
        files = [{"path": rel_path, "content": content} for rel_path, content in edited]
        payload = json.dumps({"files": files, "project_id": project_id}).encode("utf-8")
        try:
            req = Request(
                f"{cloud_url}/talon/mcp/sync",
                data=payload,
                headers={
                    "Content-Type": "application/json",
                    "X-API-Key": self._api_key,
                    "Authorization": f"Bearer {self._api_key}",
                    "User-Agent": _USER_AGENT,
                },
                method="POST",
            )
            with urlopen(req, timeout=10, context=_make_ssl_ctx()):
                pass
        except Exception as exc:
            _log(f"sync POST failed (non-critical): {exc}")

    @staticmethod
    def _extract_result_text(resp: dict) -> str:
        """Extract text from MCP tool call response content."""
        try:
            content = resp.get("result", {}).get("content", [])
            if content and isinstance(content[0], dict):
                return content[0].get("text", "")
        except Exception:
            pass
        return ""

    def _apply_edit_batch_response(self, payload_text: str) -> str:
        """Parse structured edit_batch payload from cloud, apply edits, refresh store, return [OK]."""
        # Server may append nudge/cap text after the JSON (e.g. "\n[eb-nudge] ...").
        # json.dumps() produces single-line JSON, so split on first newline to isolate it.
        suffix = ""
        try:
            payload = json.loads(payload_text)
        except json.JSONDecodeError:
            nl = payload_text.find("\n")
            if nl > 0:
                try:
                    payload = json.loads(payload_text[:nl])
                    suffix = payload_text[nl:]
                except json.JSONDecodeError:
                    return payload_text
            else:
                return payload_text
        if not payload.get("__talon_edit_batch__"):
            return payload_text

        edits = payload.get("edits", [])
        run_pytest = payload.get("run_pytest", False)

        result_str, edited_files = _edit_batch_local(edits, _PROJECT_ROOT)

        if edited_files:
            threading.Thread(target=self._refresh_store, args=(edited_files,), daemon=True).start()
            self._fire_sync(edited_files)

        if run_pytest:
            edited_paths = [f for f, _ in edited_files]
            pytest_out = _run_pytest_for_edits(edited_paths, _PROJECT_ROOT)
            if pytest_out:
                result_str += "\n" + pytest_out

        if suffix:
            result_str += suffix

        return result_str

    # ------------------------------------------------------------------ SSE connection

    def _connect_sse(self) -> str | None:
        """Open SSE connection, return session_id from endpoint event or None."""
        try:
            ctx = _make_ssl_ctx()
            _guidance_hdr: dict[str, str] = (
                {"X-Talon-Guidance": "1"}
                if os.environ.get("TALON_GUIDANCE") == "1"
                else {}
            )
            _named_cfg = os.environ.get("TALON_NAMED_CONFIG", "")
            _named_cfg_hdr: dict[str, str] = (
                {"X-Talon-Named-Config": _named_cfg} if _named_cfg else {}
            )
            req = Request(self._sse_url, headers={
                "Accept": "text/event-stream",
                "Cache-Control": "no-cache",
                "User-Agent": _USER_AGENT,
                "X-API-Key": self._api_key,
                "Authorization": f"Bearer {self._api_key}",
                **_guidance_hdr,
                **_named_cfg_hdr,
            })
            self._sse_resp = urlopen(req, timeout=SSE_CONNECT_TIMEOUT, context=ctx)
            _log(f"SSE connected to {self._sse_url}")

            # Read until we get the endpoint event with session_id
            deadline = time.monotonic() + SSE_CONNECT_TIMEOUT
            event_type = ""
            for raw in self._sse_resp:
                if time.monotonic() > deadline:
                    break
                line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
                if line.startswith("event:"):
                    event_type = line[6:].strip()
                elif line.startswith("data:"):
                    data = line[5:].strip()
                    if event_type == "endpoint":
                        # data is the POST path or full URL with ?session_id=
                        sid = self._extract_session_id(data)
                        if sid:
                            _log(f"Session ID: {sid}")
                            # Store the response object — SSE reader will use it
                            return sid
                elif line == "":
                    event_type = ""
        except Exception as exc:
            _log(f"SSE connect failed: {exc}")
        return None

    def _extract_session_id(self, endpoint_data: str) -> str | None:
        """Parse session_id from endpoint event data."""
        # Could be a path like /talon/mcp/messages?session_id=abc123
        # or a full URL
        try:
            from urllib.parse import parse_qs
            parsed = urlparse(endpoint_data if "://" in endpoint_data
                              else f"http://x{endpoint_data}")
            params = parse_qs(parsed.query)
            sid = params.get("session_id", [None])[0]
            if sid:
                return sid
        except Exception:
            pass
        return None

    # ------------------------------------------------------------------ SSE reader

    def _read_sse_forever(self) -> str:
        """Read SSE events, write JSON-RPC responses to CC stdout. Returns disconnect reason."""
        try:
            event_type = ""
            data_lines: list[str] = []
            last_event = time.monotonic()

            for raw in self._sse_resp:
                if not self._running:
                    return "shutdown"
                if time.monotonic() - last_event > SSE_READ_TIMEOUT:
                    return "read timeout"

                line = raw.decode("utf-8", errors="replace").rstrip("\r\n")

                if line.startswith("event:"):
                    event_type = line[6:].strip()
                elif line.startswith("data:"):
                    data_lines.append(line[5:].strip())
                elif line == "":
                    # Dispatch event
                    data = "\n".join(data_lines)
                    data_lines = []
                    last_event = time.monotonic()

                    if event_type in ("message", "") and data:
                        emit_data = data
                        try:
                            resp = json.loads(data)
                            resp_id = resp.get("id")
                            # Peek at pending tool name before popping
                            with self._pending_lock:
                                pending_tool = self._pending_calls.get(resp_id) if resp_id is not None else None
                            # Intercept GAL response — inject function bodies from local MemoryStore
                            if pending_tool in ("graph_ask_lite", "graph_ask"):
                                result_text = self._extract_result_text(resp)
                                if result_text and "__TALON_REFS__" in result_text:
                                    injected = self._inject_gal_bodies(result_text)
                                    rewritten = dict(resp)
                                    rewritten["result"] = {
                                        "content": [{"type": "text", "text": injected}],
                                        "isError": False,
                                    }
                                    emit_data = json.dumps(rewritten)
                            # Intercept edit_batch response — apply edits locally, rewrite to [OK]
                            if pending_tool == "edit_batch":
                                result_text = self._extract_result_text(resp)
                                if result_text and "__talon_edit_batch__" in result_text:
                                    ok_text = self._apply_edit_batch_response(result_text)
                                    rewritten = dict(resp)
                                    rewritten["result"] = {
                                        "content": [{"type": "text", "text": ok_text}],
                                        "isError": False,
                                    }
                                    emit_data = json.dumps(rewritten)
                            with self._pending_lock:
                                if resp_id is not None and resp_id in self._pending_calls:
                                    tool_name = self._pending_calls.pop(resp_id)
                                    snap = self._scorer.record_call(tool_name, self._prompt_idx)
                                    self._scorer.persist()
                                    if snap is not None:
                                        threading.Thread(
                                            target=self._post_score, args=(snap,), daemon=True
                                        ).start()
                        except (json.JSONDecodeError, KeyError):
                            pass
                        sys.stdout.buffer.write((emit_data + "\n").encode("utf-8"))
                        sys.stdout.buffer.flush()

                    event_type = ""

        except Exception as exc:
            return str(exc)
        return "stream ended"

    # ------------------------------------------------------------------ CC reader

    def _cc_reader(self) -> None:
        """Read JSON-RPC from CC stdin, queue for forwarding."""
        try:
            for raw_line in sys.stdin.buffer:
                if not self._running:
                    break
                try:
                    text = raw_line.decode("utf-8", errors="replace").strip()
                    if text:
                        msg = json.loads(text)
                        if msg.get("method") == "initialize":
                            self._init_msg = text
                            self._init_id = msg.get("id")
                        elif msg.get("method") == "tools/call":
                            params = msg.get("params", {})
                            tool_name = params.get("name", "")
                            msg_id = msg.get("id")
                            # Per-prompt state tracking via prompt_number.txt
                            _pnum_file = _PROJECT_ROOT / ".claude" / "state" / "prompt_number.txt"
                            try:
                                _cur_pnum = int(_pnum_file.read_text().strip())
                            except Exception:
                                _cur_pnum = self._pt_prompt_num
                            if _cur_pnum != self._pt_prompt_num:
                                self._pt_gal_called = False
                                self._pt_gq_called = False
                                self._pt_l2_injected = False
                                self._pt_srb_count = 0
                                # Compaction detection: prompt number jumped by >1
                                if (self._pt_prompt_num != -1
                                        and _cur_pnum > self._pt_prompt_num + 1):
                                    _log(
                                        f"compaction detected: prompt {self._pt_prompt_num}"
                                        f" → {_cur_pnum} (gap {_cur_pnum - self._pt_prompt_num})"
                                        " — full GAL bodies will re-inject naturally"
                                    )
                                self._pt_prompt_num = _cur_pnum
                                # Refresh named config from server at each prompt boundary
                                threading.Thread(target=self._refresh_proxy_cfg, daemon=True).start()
                                # Refresh AUTO-GAL enrichment from local state (written by
                                # the UserPromptSubmit hook). Sent as headers on each POST
                                # so server-side AUTO-GAL gets the real task text.
                                _state_dir = _PROJECT_ROOT / ".claude" / "state"
                                try:
                                    self._pt_prompt_task = (_state_dir / "gal_per_prompt_task.txt").read_text().strip()[:500]
                                except Exception:
                                    self._pt_prompt_task = ""
                                try:
                                    _ef_raw = (_state_dir / "task_expected_files.json").read_text()
                                    _ef = json.loads(_ef_raw)
                                    if isinstance(_ef, list):
                                        self._pt_expected_files = [str(f) for f in _ef if isinstance(f, str)][:8]
                                    elif isinstance(_ef, dict):
                                        _files = _ef.get("files") or _ef.get("expected_files") or []
                                        self._pt_expected_files = [str(f) for f in _files if isinstance(f, str)][:8]
                                    else:
                                        self._pt_expected_files = []
                                except Exception:
                                    self._pt_expected_files = []
                            if tool_name in ("graph_ask_lite", "graph_ask"):
                                self._pt_gal_called = True
                            elif tool_name == "graph_query":
                                self._pt_gq_called = True
                            # Path hygiene — rewrite agent-sent file paths to match the
                            # local workspace layout (e.g. "airflow/x.py" → "src/airflow/x.py").
                            # Cloud server has no MemoryStore so this must happen here.
                            _args_for_corr = params.get("arguments", {})
                            if _correct_tool_args(tool_name, _args_for_corr, self._memory_store):
                                params["arguments"] = _args_for_corr
                                raw_line = (json.dumps(msg) + "\n").encode("utf-8")
                            # Intercept smart_read_batch — serve from MemoryStore (with disk fallback)
                            if tool_name == "smart_read_batch" and msg_id is not None:
                                # srb_gal_gate: block SRB if GAL/GQ not called this prompt (gate from named config)
                                if (self._proxy_cfg.get("srb_gal_gate", 0)
                                        and not self._pt_gal_called
                                        and not self._pt_gq_called):
                                    gate_text = (
                                        "[TALON GATE] smart_read_batch blocked — call graph_ask_lite first.\n"
                                        "1. graph_ask_lite(task='<describe what you need>', expected_files=[<files>])\n"
                                        "2. Then proceed with smart_read_batch or edit_batch."
                                    )
                                    gate_resp = json.dumps({
                                        "jsonrpc": "2.0", "id": msg_id,
                                        "result": {"content": [{"type": "text", "text": gate_text}], "isError": False},
                                    }) + "\n"
                                    sys.stdout.buffer.write(gate_resp.encode("utf-8"))
                                    sys.stdout.buffer.flush()
                                    self._scorer.record_call(tool_name, self._prompt_idx)
                                    self._scorer.persist()
                                    self._prompt_idx += 1
                                    continue
                                # srb_hard_cap: block SRB once per-prompt count hits cap
                                _srb_cap = self._proxy_cfg.get("srb_hard_cap", 0)
                                if _srb_cap and self._pt_srb_count >= _srb_cap:
                                    cap_text = (
                                        f"[TALON GATE] smart_read_batch blocked — per-prompt cap ({_srb_cap}) reached.\n"
                                        "Use graph_ask_lite or graph_query to get context instead."
                                    )
                                    cap_resp = json.dumps({
                                        "jsonrpc": "2.0", "id": msg_id,
                                        "result": {"content": [{"type": "text", "text": cap_text}], "isError": False},
                                    }) + "\n"
                                    sys.stdout.buffer.write(cap_resp.encode("utf-8"))
                                    sys.stdout.buffer.flush()
                                    self._scorer.record_call(tool_name, self._prompt_idx)
                                    self._scorer.persist()
                                    self._prompt_idx += 1
                                    continue
                                self._pt_srb_count += 1
                                args = params.get("arguments", {})
                                targets = args.get("targets") or args.get("reads") or []
                                if isinstance(targets, str):
                                    try:
                                        targets = json.loads(targets)
                                    except Exception:
                                        targets = []
                                # Wait briefly for store if still building (first call only)
                                if not self._store_ready.is_set():
                                    self._store_ready.wait(timeout=5.0)
                                srb_result = _srb_local(targets, store=self._memory_store)
                                if srb_result is not None:
                                    resp = json.dumps({
                                        "jsonrpc": "2.0",
                                        "id": msg_id,
                                        "result": {
                                            "content": [{"type": "text", "text": srb_result}],
                                            "isError": False,
                                        },
                                    }) + "\n"
                                    sys.stdout.buffer.write(resp.encode("utf-8"))
                                    sys.stdout.buffer.flush()
                                    self._scorer.record_call(tool_name, self._prompt_idx)
                                    self._scorer.persist()
                                    self._prompt_idx += 1
                                    continue  # handled locally — don't forward to cloud
                                # srb_result is None: symbol lookup needed but store not ready — forward to cloud
                            if msg_id is not None and tool_name:
                                with self._pending_lock:
                                    self._pending_calls[msg_id] = tool_name
                            self._prompt_idx += 1
                except (json.JSONDecodeError, UnicodeDecodeError):
                    pass
                self._outbound.put(raw_line)
        except Exception:
            pass
        finally:
            self._running = False

    # ------------------------------------------------------------------ outbound writer

    def _outbound_writer(self) -> None:
        """Forward queued CC messages → server via POST."""
        self._session_ready.wait()
        while self._running and self._session_ready.is_set():
            try:
                raw_line = self._outbound.get(timeout=1)
            except queue.Empty:
                continue
            try:
                text = raw_line.decode("utf-8", errors="replace").strip()
                if not text:
                    continue
                self._post_message(text)
            except Exception as exc:
                _log(f"POST failed: {exc}")
                # Requeue so next session picks it up
                self._outbound.put(raw_line)
                break

    def _post_message(self, body: str) -> None:
        data = body.encode("utf-8")
        _hdrs = {
            "Content-Type": "application/json",
            "User-Agent": _USER_AGENT,
            "X-API-Key": self._api_key,
            "Authorization": f"Bearer {self._api_key}",
        }
        if self._pt_prompt_task:
            _hdrs["X-Talon-Prompt-Task"] = self._pt_prompt_task
        if self._pt_expected_files:
            _hdrs["X-Talon-Expected-Files"] = ",".join(self._pt_expected_files)
        if self._pt_prompt_num >= 0:
            _hdrs["X-Talon-Prompt-Num"] = str(self._pt_prompt_num)
        req = Request(
            self._post_url,
            data=data,
            headers=_hdrs,
            method="POST",
        )
        with urlopen(req, timeout=POST_TIMEOUT, context=_make_ssl_ctx()):
            pass  # 202 Accepted — response comes via SSE

    # ------------------------------------------------------------------ handshake replay

    def _replay_handshake(self) -> bool:
        if not self._init_msg:
            _log("No saved initialize — cannot replay.")
            return False
        try:
            self._post_message(self._init_msg)
            # The initialize response will come through the SSE stream naturally —
            # we don't need to intercept it; CC already processed the first one and
            # the server just needs to re-establish the session state.
            time.sleep(0.5)
            _log("Handshake replayed.")
            return True
        except Exception as exc:
            _log(f"Handshake replay error: {exc}")
            return False

    # ------------------------------------------------------------------ pending flush

    def _flush_pending_as_errors(self, message: str) -> None:
        with self._pending_lock:
            pending = dict(self._pending_calls)
            self._pending_calls.clear()
        if not pending:
            return
        for call_id, tool_name in pending.items():
            err = json.dumps({
                "jsonrpc": "2.0",
                "id": call_id,
                "error": {"code": -32000, "message": message,
                          "data": {"tool": tool_name, "recoverable": True}},
            }) + "\n"
            try:
                sys.stdout.buffer.write(err.encode("utf-8"))
                sys.stdout.buffer.flush()
            except Exception:
                pass
        _log(f"Sent error responses for {len(pending)} pending call(s). CC can retry.")

    # ------------------------------------------------------------------ trace

    def _post_score(self, snap: object) -> None:
        """POST a score snapshot to the cloud API (fire-and-forget from thread)."""
        try:
            import uuid as _uuid
            api_key = self._api_key
            if not api_key:
                return
            cloud_url = os.environ.get("TALON_CLOUD_URL", "https://api.cogmeta.ai").rstrip("/")
            run_id = os.environ.get("TALON_RUN_ID", "")
            project_id = os.environ.get("TALON_PROJECT_ID", "")
            payload = json.dumps({
                "session_id": run_id,
                "project_id": project_id,
                "score": snap.score,          # type: ignore[attr-defined]
                "band": snap.band,            # type: ignore[attr-defined]
                "est_reduction_pct": snap.est_reduction_pct,  # type: ignore[attr-defined]
                "spp": snap.spp,              # type: ignore[attr-defined]
                "go_pct": snap.go_pct,        # type: ignore[attr-defined]
                "cpp": snap.cpp,              # type: ignore[attr-defined]
                "sg_ratio": snap.sg_ratio,    # type: ignore[attr-defined]
                "prompts": snap.prompts,      # type: ignore[attr-defined]
                "total_steps": snap.total_steps,  # type: ignore[attr-defined]
                "total_tctx": snap.total_tctx,    # type: ignore[attr-defined]
            }).encode("utf-8")
            req = Request(
                f"{cloud_url}/cloud/v1/talon/telemetry/score",
                data=payload,
                headers={
                    "Content-Type": "application/json",
                    "X-API-Key": api_key,
                    "User-Agent": _USER_AGENT,
                },
                method="POST",
            )
            with urlopen(req, timeout=5, context=_make_ssl_ctx()):
                pass
        except Exception:
            pass

    def _submit_trace(self) -> None:
        if self._watcher is not None:
            try:
                self._watcher.stop()
            except Exception:
                pass
        if self._reporter is not None:
            try:
                self._reporter.submit()
            except Exception:
                pass

    def shutdown(self) -> None:
        self._running = False
        try:
            self._sse_resp.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# find_mcp_proxy kept for talon check backward compat — no longer used at runtime
# ---------------------------------------------------------------------------

def find_mcp_proxy() -> str | None:
    """Legacy: find mcp-proxy binary. No longer used — direct SSE mode active."""
    import shutil
    venv_candidate = str(Path(sys.executable).parent / "mcp-proxy")
    for candidate in [venv_candidate, shutil.which("mcp-proxy"),
                      os.path.expanduser("~/.local/bin/mcp-proxy"), "/usr/local/bin/mcp-proxy"]:
        if candidate and os.path.isfile(candidate):
            return candidate
    return None


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: talon-proxy-wrapper <SSE_URL>", file=sys.stderr)
        sys.exit(1)

    sse_url = sys.argv[1]
    api_key = os.environ.get("TALON_API_KEY", "").strip() or _load_credential_key()

    if not api_key:
        _log("WARNING: No API key found. Set TALON_API_KEY or run 'talon auth login'.")

    proxy = DirectSseProxy(sse_url, api_key)

    def handle_signal(signum, frame):
        proxy.shutdown()

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    sys.exit(proxy.run())


if __name__ == "__main__":
    main()
