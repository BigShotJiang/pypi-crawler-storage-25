"""Telemetry logger for talon v5 local MCP server.

Logs graph_query tool calls to the cloud REST API for dashboard tracking.
Fire-and-forget: telemetry failures never block tool responses.

Implements: v5 Phase 1 telemetry pipeline
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from collections import deque
from dataclasses import asdict, dataclass, field
from typing import Any

from pathlib import Path

import httpx

logger = logging.getLogger(__name__)


@dataclass
class ToolCallMetric:
    """A single graph_query tool call metric."""
    intent: str
    target: str
    depth: str = "shallow"
    response_tokens: int = 0
    latency_ms: int = 0
    cache_hit: bool = False
    warnings_count: int = 0
    session_id: str = ""
    layers_used: list[str] = field(default_factory=list)
    # Extra fields for signal evaluation
    is_error: bool = False
    context_tokens: int = 0
    confidence: float | None = None
    tool_name: str = ""  # raw tool name (e.g. "smart_read_batch", "Edit")


class TelemetryLogger:
    """Async HTTP telemetry logger.

    Sends tool call metrics to the talon cloud REST API.
    Non-blocking: schedules async tasks for fire-and-forget.
    Falls back to local JSONL file if API is unreachable.

    Also runs the SignalEvaluator on each tool call to detect
    behaviour spirals, tool abandonment, and context health issues.
    """

    def __init__(
        self,
        api_url: str | None = None,
        session_id: str | None = None,
        fallback_path: str | None = None,
        product: str = "talon",
        project_id: str = "",
        api_key: str | None = None,
    ) -> None:
        self._api_url = api_url or os.environ.get("TALON_API_URL", "")
        self._session_id = session_id or f"local-{int(time.time())}"
        self._product = product
        self._project_id = project_id
        self._api_key = api_key or os.environ.get("TALON_API_KEY", "")
        self._fallback_path = fallback_path  # Local JSONL fallback
        if fallback_path:
            Path(fallback_path).parent.mkdir(parents=True, exist_ok=True)
        # A5: Structured error log alongside observations.jsonl
        self._error_path = (
            str(Path(fallback_path).parent / "errors.jsonl") if fallback_path else None
        )
        self._client: httpx.AsyncClient | None = None
        self._queue: list[ToolCallMetric] = []
        self._failed_count: int = 0
        # Rolling window for session-type heuristic
        self._recent_intents: deque[str] = deque(maxlen=10)
        # Signal evaluator
        self._signal_evaluator: Any = None
        self._pending_signals: list[dict] = []
        if os.environ.get("TALON_SIGNALS", "1") != "0":
            try:
                from talon.cloud.signal_evaluator import SignalEvaluator
                self._signal_evaluator = SignalEvaluator(
                    session_id=self._session_id, product=product,
                )
            except Exception:
                pass

    async def _ensure_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=5.0)
        return self._client

    _HEARTBEAT_INTERVAL = 10   # send heartbeat every N tool calls
    _SIGNAL_FLUSH_INTERVAL = 20  # flush pending signals every N calls (crash safety)

    def _schedule(self, coro: Any) -> None:
        """Schedule a coroutine from sync or async context, fire-and-forget."""
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(coro)
        except RuntimeError:
            import threading
            threading.Thread(target=asyncio.run, args=(coro,), daemon=True).start()

    def log(self, metric: ToolCallMetric) -> None:
        """Log a tool call metric. Non-blocking. Also evaluates GA20 signals."""
        metric.session_id = self._session_id
        self._recent_intents.append(metric.intent)
        self._write_local(metric)
        self._schedule(self._send(metric))
        self._call_count = getattr(self, "_call_count", 0) + 1
        if self._call_count == 1 or self._call_count % self._HEARTBEAT_INTERVAL == 0:
            self._schedule(self._send_heartbeat())
        if self._call_count % self._SIGNAL_FLUSH_INTERVAL == 0 and self._pending_signals:
            self._schedule(self._flush_signals_partial())
        # Evaluate signals with full step data
        if self._signal_evaluator:
            try:
                signals = self._signal_evaluator.evaluate(
                    tool_name=metric.tool_name or metric.intent or "unknown",
                    is_error=metric.is_error,
                    context_tokens=metric.context_tokens or None,
                    output_tokens=metric.response_tokens,
                    confidence=metric.confidence,
                    detail=metric.target or "",
                )
                for sig in signals:
                    self._pending_signals.append(sig.to_dict())
            except Exception:
                pass

    def log_error(self, error_type: str, intent: str = "", target: str = "", message: str = "") -> None:
        """Log a structured error event to ~/.talon/errors.jsonl. Best-effort."""
        if not self._error_path:
            return
        try:
            import json
            from datetime import datetime, timezone
            payload = {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "session_id": self._session_id,
                "error_type": error_type,
                "intent": intent,
                "target": target,
                "message": message,
            }
            with open(self._error_path, "a") as f:
                f.write(json.dumps(payload) + "\n")
        except Exception:
            pass

    _MAX_JSONL_SIZE = 10 * 1024 * 1024  # 10 MB
    _MAX_JSONL_BACKUPS = 5

    def _rotate_if_needed(self) -> None:
        """Rotate observations.jsonl if it exceeds 10 MB (keep 5 backups)."""
        fpath = Path(self._fallback_path)
        if not fpath.exists() or fpath.stat().st_size <= self._MAX_JSONL_SIZE:
            return
        for i in range(self._MAX_JSONL_BACKUPS - 1, 0, -1):
            src = Path(f"{self._fallback_path}.{i}")
            dst = Path(f"{self._fallback_path}.{i + 1}")
            if src.exists():
                src.rename(dst)
        fpath.rename(f"{self._fallback_path}.1")

    def _write_local(self, metric: ToolCallMetric) -> None:
        """Always write to local JSONL file for observation tracking."""
        if not self._fallback_path:
            return
        try:
            import json
            from datetime import datetime, timezone

            self._rotate_if_needed()
            payload = asdict(metric)
            payload["timestamp"] = datetime.now(timezone.utc).isoformat()
            with open(self._fallback_path, "a") as f:
                f.write(json.dumps(payload) + "\n")
        except Exception:
            pass  # Best effort

    async def _send(self, metric: ToolCallMetric) -> None:
        """POST metric to API. Local write already handled by _write_local."""
        try:
            client = await self._ensure_client()
            payload = asdict(metric)
            r = await client.post(
                f"{self._api_url}/api/v1/talon/telemetry/tool_call",
                json=payload,
            )
            r.raise_for_status()
        except Exception:
            self._failed_count += 1

    async def _flush_signals_partial(self) -> None:
        """Flush accumulated signals mid-session (crash safety). Does NOT finalize."""
        if not self._pending_signals:
            return
        batch = list(self._pending_signals)
        self._pending_signals.clear()
        try:
            client = await self._ensure_client()
            cloud_url = os.environ.get("TALON_CLOUD_URL", "https://api.cogmeta.ai")
            await client.post(
                f"{cloud_url}/cloud/v1/talon/telemetry/signals",
                json={
                    "session_id": self._session_id,
                    "product": self._product,
                    "signals": batch,
                },
                headers={"X-API-Key": self._api_key},
            )
        except Exception:
            # Re-queue on failure so they aren't lost
            self._pending_signals[:0] = batch

    async def _send_heartbeat(self) -> None:
        """Upsert live session record so admin dashboard shows active sessions."""
        try:
            client = await self._ensure_client()
            cloud_url = os.environ.get("TALON_CLOUD_URL", "https://api.cogmeta.ai")
            await client.post(
                f"{cloud_url}/cloud/v1/talon/telemetry/heartbeat",
                json={
                    "session_id": self._session_id,
                    "product": self._product,
                    "tool_call_count": getattr(self, "_call_count", 0),
                },
                headers={"X-API-Key": self._api_key},
            )
        except Exception:
            pass
        # Piggyback: fetch unread support count and write to ~/.talon/inbox.json
        asyncio.create_task(self._sync_inbox())

    async def _sync_inbox(self) -> None:
        """Fetch unread support message count and cache to ~/.talon/inbox.json."""
        try:
            client = await self._ensure_client()
            cloud_url = os.environ.get("TALON_CLOUD_URL", "https://api.cogmeta.ai")
            if not self._api_key:
                return
            r = await client.get(
                f"{cloud_url}/cloud/v1/support/unread",
                headers={"X-API-Key": self._api_key},
            )
            if r.status_code == 200:
                data = r.json()
                inbox_path = Path.home() / ".talon" / "inbox.json"
                inbox_path.parent.mkdir(parents=True, exist_ok=True)
                import json as _json
                inbox_path.write_text(_json.dumps({
                    "unread": data.get("unread", 0),
                    "updated_at": time.time(),
                }))
        except Exception:
            pass

    async def flush_signals(self) -> None:
        """Flush pending GA20 signals to cloud API. Called at session end."""
        await self._send_heartbeat()  # final heartbeat before closing
        if not self._pending_signals or not self._signal_evaluator:
            return
        try:
            final_signals = self._signal_evaluator.finalize()
            for sig in final_signals:
                self._pending_signals.append(sig.to_dict())
            health_summary = self._signal_evaluator.get_health_summary()
            client = await self._ensure_client()
            cloud_url = os.environ.get("TALON_CLOUD_URL", "https://api.cogmeta.ai")
            await client.post(
                f"{cloud_url}/cloud/v1/talon/telemetry/signals",
                json={
                    "session_id": self._session_id,
                    "product": self._product,
                    "signals": self._pending_signals,
                    "health_summary": health_summary,
                },
                headers={"X-API-Key": self._api_key},
            )
            self._pending_signals.clear()
        except Exception:
            pass

    async def close(self) -> None:
        await self.flush_signals()
        if self._client:
            await self._client.aclose()
            self._client = None

    @property
    def session_id(self) -> str:
        return self._session_id

    @property
    def failed_count(self) -> int:
        return self._failed_count

    @property
    def session_mode(self) -> str:
        """Infer session type from recent intent pattern.

        Returns:
            "navigation" if >60% of recent intents are toc/locate
            "editing" if any sync calls appear in the window
            "mixed" otherwise (or if <3 calls recorded)
        """
        if len(self._recent_intents) < 3:
            return "mixed"
        total = len(self._recent_intents)
        nav_intents = sum(1 for i in self._recent_intents if i in ("toc", "locate"))
        has_sync = "sync" in self._recent_intents
        if has_sync:
            return "editing"
        if nav_intents / total > 0.6:
            return "navigation"
        return "mixed"

    @property
    def recent_intents(self) -> list[str]:
        """Return the recent intent window (for telemetry status)."""
        return list(self._recent_intents)
