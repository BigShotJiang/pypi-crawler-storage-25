#!/usr/bin/env python3
"""talon-prompt-hook — UserPromptSubmit hook (single combined hook).

1. Renews Talon API key if near expiry and patches .mcp.json (synchronous, first)
2. Fires prompt telemetry to cloud API (fire-and-forget thread)
3. Refreshes alltime score, inbox, graph health, PyPI update check (background threads)
4. Injects a brief reminder to use talon MCP tools on first coding prompt of session
"""

import datetime
import json
import os
import sys
import threading
import time
from pathlib import Path

_CREDS = Path.home() / ".talon" / "credentials.json"
_RENEWAL_STATE = Path.home() / ".talon" / "renewal_state.json"
_SESSION_FILE = Path.home() / ".talon" / "session_state.json"
_TTL_H = 6
_THRESH = 0.80


def _load_api_key() -> tuple[str, str]:
    try:
        creds = json.loads(_CREDS.read_text())
        return creds.get("api_key", ""), creds.get("cloud_url", "https://api.cogmeta.ai")
    except Exception:
        return "", "https://api.cogmeta.ai"


def _renew_api_key() -> None:
    """Silently renew API key if >80% through its 6h TTL. Patches credentials + .mcp.json."""
    if not _CREDS.exists():
        return
    try:
        creds = json.loads(_CREDS.read_text())
    except Exception:
        return

    saved_at = creds.get("saved_at", "")
    api_key = creds.get("api_key", "")
    cloud_url = creds.get("cloud_url", "https://api.cogmeta.ai").rstrip("/")
    if not saved_at or not api_key:
        return

    try:
        saved = datetime.datetime.fromisoformat(saved_at.replace("Z", "+00:00"))
        now = datetime.datetime.now(datetime.timezone.utc)
        if (now - saved).total_seconds() / (_TTL_H * 3600) < _THRESH:
            return
    except Exception:
        return

    try:
        if _RENEWAL_STATE.exists():
            st = json.loads(_RENEWAL_STATE.read_text())
            backoff = min(60 * (2 ** st.get("attempt_count", 0)), 3600)
            if time.time() - st.get("last_attempt", 0) < backoff:
                return
    except Exception:
        pass

    try:
        import ssl
        import urllib.request
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(
            f"{cloud_url}/cloud/v1/users/me/api-key",
            method="POST",
            headers={"X-API-Key": api_key},
        )
        with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
            data = json.loads(resp.read())
        new_key = data.get("api_key", "")
        if new_key:
            ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            tmp = _CREDS.parent / f".credentials.tmp.{os.getpid()}"
            tmp.write_text(json.dumps({**creds, "api_key": new_key, "saved_at": ts}, indent=2))
            tmp.chmod(0o600)
            tmp.rename(_CREDS)
            _RENEWAL_STATE.write_text(json.dumps({"last_attempt": time.time(), "attempt_count": 0}))
            for p in (Path.home() / ".mcp.json", Path.cwd() / ".mcp.json"):
                try:
                    if not p.exists():
                        continue
                    txt = p.read_text()
                    if api_key not in txt:
                        continue
                    cfg = json.loads(txt)
                    patched = False
                    for sv in cfg.get("mcpServers", {}).values():
                        env = sv.get("env", {})
                        if env.get("TALON_API_KEY") == api_key:
                            env["TALON_API_KEY"] = new_key
                            patched = True
                    if patched:
                        tmp2 = p.parent / f".mcp.json.tmp.{os.getpid()}"
                        tmp2.write_text(json.dumps(cfg, indent=2) + "\n")
                        tmp2.rename(p)
                except Exception:
                    pass
        return
    except Exception:
        pass

    try:
        st = json.loads(_RENEWAL_STATE.read_text()) if _RENEWAL_STATE.exists() else {}
        _RENEWAL_STATE.write_text(json.dumps({
            "last_attempt": time.time(),
            "attempt_count": st.get("attempt_count", 0) + 1,
        }))
    except Exception:
        pass


def _fire_telemetry(prompt_text: str, session_id: str) -> None:
    try:
        import ssl
        import urllib.request
        api_key, cloud_url = _load_api_key()
        telemetry_url = os.environ.get("TALON_TELEMETRY_URL") or f"{cloud_url.rstrip('/')}/cloud/v1/talon/telemetry/prompt_event"
        data = json.dumps({
            "session_id": session_id,
            "prompt_length": len(prompt_text),
            "timestamp": time.time(),
        }).encode()
        req = urllib.request.Request(
            telemetry_url,
            data=data,
            headers={"Content-Type": "application/json", "User-Agent": "talon-client/0.7.61"},
            method="POST",
        )
        env_key = os.environ.get("TALON_API_KEY", "") or api_key
        if env_key:
            req.add_header("X-API-Key", env_key)
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        urllib.request.urlopen(req, timeout=3, context=ctx)
    except Exception:
        pass


def _fetch_alltime_score() -> None:
    try:
        import ssl
        import urllib.request
        api_key, cloud_url = _load_api_key()
        if not api_key:
            return
        alltime_path = Path.home() / ".talon" / "score_alltime.json"
        if alltime_path.exists():
            age = time.time() - json.loads(alltime_path.read_text()).get("updated_at", 0)
            if age < 3600:
                return
        url = f"{cloud_url.rstrip('/')}/cloud/v1/talon/telemetry/score/summary"
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(url, headers={"X-API-Key": api_key, "User-Agent": "talon-client/0.7.61"})
        resp = urllib.request.urlopen(req, timeout=3, context=ctx)
        data = json.loads(resp.read())
        alltime_path.parent.mkdir(parents=True, exist_ok=True)
        alltime_path.write_text(json.dumps({
            "score": data.get("avg_score", 0.0),
            "sessions": data.get("total_sessions", 0),
            "updated_at": time.time(),
        }))
    except Exception:
        pass


def _fetch_inbox() -> None:
    try:
        import ssl
        import urllib.request
        api_key, cloud_url = _load_api_key()
        if not api_key:
            return
        inbox_path = Path.home() / ".talon" / "inbox.json"
        if inbox_path.exists():
            age = time.time() - json.loads(inbox_path.read_text()).get("updated_at", 0)
            if age < 300:
                return
        url = f"{cloud_url.rstrip('/')}/cloud/v1/support/unread"
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(url, headers={"X-API-Key": api_key, "User-Agent": "talon-client/0.7.61"})
        resp = urllib.request.urlopen(req, timeout=3, context=ctx)
        data = json.loads(resp.read())
        inbox_path.parent.mkdir(parents=True, exist_ok=True)
        inbox_path.write_text(json.dumps({
            "unread": data.get("unread", 0),
            "updated_at": time.time(),
        }))
    except Exception:
        pass


def _refresh_graph_health() -> None:
    try:
        import ssl
        import urllib.request

        health_path = Path.home() / ".talon" / "graph_health.json"
        if health_path.exists():
            age = time.time() - json.loads(health_path.read_text()).get("checked_at", 0)
            if age < 1800:
                return

        api_key, cloud_url = _load_api_key()
        if not api_key:
            return

        project_id = os.environ.get("TALON_PROJECT_ID", "")
        if not project_id:
            try:
                mcp_cfg = json.loads((Path.cwd() / ".mcp.json").read_text())
                project_id = (
                    mcp_cfg.get("mcpServers", {})
                    .get("talon", {})
                    .get("env", {})
                    .get("TALON_PROJECT_ID", "")
                )
            except Exception:
                pass
        if not project_id:
            return

        url = f"{cloud_url.rstrip('/')}/cloud/v1/projects/{project_id}/stats"
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(
            url, headers={"X-API-Key": api_key, "User-Agent": "talon-client/0.7.61"}
        )
        resp = urllib.request.urlopen(req, timeout=5, context=ctx)
        stats = json.loads(resp.read())

        files = stats.get("files", 0)
        functions = stats.get("functions", 0)

        health_path.parent.mkdir(parents=True, exist_ok=True)
        health_path.write_text(json.dumps({
            "project_id": project_id,
            "state_pct": 100 if (functions > 0 and files > 0) else 0,
            "files": files,
            "functions": functions,
            "classes": stats.get("classes", 0),
            "action": "" if (functions > 0 and files > 0) else "run talon index",
            "checked_at": time.time(),
        }))
    except Exception:
        pass


def _check_for_update() -> None:
    try:
        import ssl
        import urllib.request
        from talon import __version__ as current

        update_path = Path.home() / ".talon" / "update.json"
        if update_path.exists():
            cached = json.loads(update_path.read_text())
            if time.time() - cached.get("checked_at", 0) < 3600:
                return

        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(
            "https://pypi.org/pypi/cogmeta-talon/json",
            headers={"User-Agent": "talon-client/" + current, "Accept": "application/json"},
        )
        resp = urllib.request.urlopen(req, timeout=5, context=ctx)
        data = json.loads(resp.read())
        latest = data.get("info", {}).get("version", current)

        update_path.parent.mkdir(parents=True, exist_ok=True)
        update_path.write_text(json.dumps({
            "current": current,
            "latest": latest,
            "available": latest != current,
            "checked_at": time.time(),
        }))
    except Exception:
        pass


_HOOK_CONFIG_PATH = Path.home() / ".talon" / "hook_config.json"
_HOOK_CONFIG_TTL = 300

_CODING_TASK_PATTERN = None


def _is_coding_task(prompt: str) -> bool:
    global _CODING_TASK_PATTERN
    if _CODING_TASK_PATTERN is None:
        import re
        _CODING_TASK_PATTERN = re.compile(
            r"\b(fix|add|implement|refactor|migrate|update|change|create|write|debug|build|"
            r"edit|modify|remove|delete|rename|move|extract|test|deploy|install|configure|"
            r"import|export|parse|render|fetch|query|hook|route|endpoint|function|class|"
            r"method|module|file|script|bug|error|exception|fail|break|crash|regression|"
            r"performance|optimise|optimize|async|await|thread|process|pipeline)\b",
            re.IGNORECASE,
        )
    return bool(_CODING_TASK_PATTERN.search(prompt))


def _fetch_hook_config() -> None:
    try:
        import ssl
        import urllib.request
        api_key, cloud_url = _load_api_key()
        if not api_key:
            return
        if _HOOK_CONFIG_PATH.exists():
            age = time.time() - json.loads(_HOOK_CONFIG_PATH.read_text()).get("_updated_at", 0)
            if age < _HOOK_CONFIG_TTL:
                return
        url = f"{cloud_url.rstrip('/')}/cloud/v1/users/me/hook-config"
        ctx = ssl.create_default_context()
        cert_file = os.environ.get("SSL_CERT_FILE")
        if cert_file:
            ctx.load_verify_locations(cert_file)
        req = urllib.request.Request(url, headers={"X-API-Key": api_key, "User-Agent": "talon-client/0.7.61"})
        resp = urllib.request.urlopen(req, timeout=3, context=ctx)
        data = json.loads(resp.read())
        data["_updated_at"] = time.time()
        _HOOK_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        _HOOK_CONFIG_PATH.write_text(json.dumps(data))
    except Exception:
        pass


def _read_hook_config() -> dict:
    try:
        if _HOOK_CONFIG_PATH.exists():
            return json.loads(_HOOK_CONFIG_PATH.read_text())
    except Exception:
        pass
    return {}


def _is_first_prompt(session_id: str) -> bool:
    try:
        _SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
        if _SESSION_FILE.exists():
            state = json.loads(_SESSION_FILE.read_text())
            if state.get("session_id") == session_id:
                return False
        _SESSION_FILE.write_text(json.dumps({"session_id": session_id}))
        return True
    except Exception:
        return False


def main() -> None:
    try:
        raw = sys.stdin.read()
        event = json.loads(raw) if raw.strip() else {}
    except Exception:
        event = {}

    # Key renewal first — synchronous, so fresh key is used by all threads below
    _renew_api_key()

    session_id = event.get("session_id", "")
    prompt_text = ""
    content = event.get("message", {}).get("content", "")
    if isinstance(content, str):
        prompt_text = content
    elif isinstance(content, list):
        for c in content:
            if isinstance(c, dict) and c.get("text"):
                prompt_text = c["text"]
                break

    telemetry_enabled = os.environ.get("TALON_TELEMETRY_ENABLED", "1") != "0"

    threads = []
    if telemetry_enabled:
        threads.append(threading.Thread(target=_fire_telemetry, args=(prompt_text, session_id), daemon=True))
    threads.append(threading.Thread(target=_fetch_alltime_score, daemon=True))
    threads.append(threading.Thread(target=_fetch_inbox, daemon=True))
    threads.append(threading.Thread(target=_check_for_update, daemon=True))
    threads.append(threading.Thread(target=_refresh_graph_health, daemon=True))
    threads.append(threading.Thread(target=_fetch_hook_config, daemon=True))
    for t in threads:
        t.start()

    result: dict = {"continue": True}
    every_prompt = (
        os.environ.get("TALON_L2_EVERY_PROMPT") == "1"
        or _read_hook_config().get("l2_every_prompt", 0) == 1
    )
    if _is_coding_task(prompt_text) and (every_prompt or _is_first_prompt(session_id)):
        result["systemMessage"] = (
            "[Talon] Use graph_ask_lite first for code context, "
            "then edit_batch for changes. Run /talon score to check session efficiency."
        )

    json.dump(result, sys.stdout)
    sys.stdout.flush()

    for t in threads:
        t.join(timeout=1)


if __name__ == "__main__":
    main()
