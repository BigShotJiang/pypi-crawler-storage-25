"""Smoke tests — ensure the package imports, the Typer app builds, and core
commands can be invoked with --help on every supported platform.

Network-touching commands are tested with pytest-httpx in dedicated files.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest
from typer.testing import CliRunner

from enkindler_cli import __version__
from enkindler_cli.config import APP_NAME, Cluster, Config, config_dir
from enkindler_cli.main import app


def test_version() -> None:
    assert __version__ == "0.0.1"


def test_help_renders() -> None:
    result = CliRunner().invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "enkindler" in result.stdout.lower()
    for cmd in ("login", "logout", "whoami", "deployment", "config"):
        assert cmd in result.stdout


def test_deployment_help() -> None:
    result = CliRunner().invoke(app, ["deployment", "--help"])
    assert result.exit_code == 0
    assert "list" in result.stdout
    assert "get" in result.stdout


def test_config_help() -> None:
    result = CliRunner().invoke(app, ["config", "--help"])
    assert result.exit_code == 0
    for cmd in ("add", "list", "use", "remove", "show", "path"):
        assert cmd in result.stdout


def test_console_script_runs() -> None:
    """The installed `enkindler --version` script must work — catches script entry breakage."""
    out = subprocess.check_output([sys.executable, "-m", "enkindler_cli.main", "--version"], text=True)
    assert __version__ in out


def test_config_dir_is_per_platform() -> None:
    p = config_dir()
    assert APP_NAME in str(p).lower()


def test_config_roundtrip(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Save + load round-trips clusters and default through TOML."""
    monkeypatch.setattr("platformdirs.user_config_dir", lambda *_a, **_k: str(tmp_path))
    cfg = Config()
    cfg.add(Cluster(name="dev", url="https://dev.example.com", token="abc", user_email="u@x.com", instance_name="acme-dev"))
    cfg.add(Cluster(name="prod", url="https://prod.example.com"), make_default=True)
    cfg.save()

    loaded = Config.load()
    assert set(loaded.clusters.keys()) == {"dev", "prod"}
    assert loaded.default == "prod"
    assert loaded.clusters["dev"].token == "abc"
    assert loaded.clusters["dev"].user_email == "u@x.com"
    assert loaded.clusters["dev"].instance_name == "acme-dev"
    assert loaded.clusters["prod"].token is None


def test_resolve_picks_default(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("platformdirs.user_config_dir", lambda *_a, **_k: str(tmp_path))
    cfg = Config()
    cfg.add(Cluster(name="dev", url="https://dev.example.com"), make_default=True)
    cfg.add(Cluster(name="prod", url="https://prod.example.com"))
    assert cfg.resolve(None).name == "dev"
    assert cfg.resolve("prod").name == "prod"


def test_resolve_errors_when_empty(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from enkindler_cli.config import ConfigError
    monkeypatch.setattr("platformdirs.user_config_dir", lambda *_a, **_k: str(tmp_path))
    cfg = Config()
    with pytest.raises(ConfigError):
        cfg.resolve(None)
