"""`enkindler login` and `enkindler logout`.

`login` drives the Azure AD device-code flow against the resolved cluster's
backend (`/api/auth/device/start` and `/api/auth/device/poll`). On success
the JWT is written to the cluster's slot in the config file.
"""

from __future__ import annotations

import contextlib
import time
import webbrowser

import typer
from rich.console import Console

from ..client import APIError, Client
from ..config import Config, ConfigError, effective_url_override

console = Console()
err_console = Console(stderr=True)


def login(
    cluster: str | None = typer.Option(
        None, "--cluster", "-c", help="Cluster name (defaults to the configured default).",
    ),
    api_url: str | None = typer.Option(
        None, "--api-url", help="Override the cluster's URL (advanced).",
    ),
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Do not attempt to open the verification URL automatically.",
    ),
) -> None:
    """Sign in via Microsoft device-code flow."""
    cfg = Config.load()
    try:
        c = cfg.resolve(cluster)
    except ConfigError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1) from None

    base = api_url or effective_url_override() or c.url
    console.print(f"Signing in to [bold]{c.name}[/bold] ({base})")

    with Client(base_url=base) as client:
        try:
            start = client.post("/api/auth/device/start")
        except APIError as e:
            err_console.print(f"[red]Could not start device login:[/red] {e.message}")
            raise typer.Exit(code=1) from None

    user_code = start["user_code"]
    verification_uri = start["verification_uri"]
    interval = int(start.get("interval", 5))
    expires_in = int(start.get("expires_in", 900))
    device_code = start["device_code"]

    console.print()
    console.print(f"To sign in, open [bold cyan]{verification_uri}[/bold cyan]")
    console.print(f"and enter the code: [bold yellow]{user_code}[/bold yellow]")
    console.print()

    if not no_browser:
        with contextlib.suppress(webbrowser.Error):
            webbrowser.open(verification_uri)

    deadline = time.time() + expires_in
    with (
        Client(base_url=base) as client,
        console.status("Waiting for browser approval…", spinner="dots"),
    ):
        while time.time() < deadline:
            time.sleep(interval)
            try:
                poll = client.post("/api/auth/device/poll", json={"device_code": device_code})
            except APIError as e:
                err_console.print(f"[red]Login failed:[/red] {e.message}")
                raise typer.Exit(code=1) from None
            status = poll.get("status")
            if status == "pending":
                continue
            if status == "authorized":
                cfg.update_token(c.name, token=poll["token"], user_email=poll.get("user", {}).get("email"))
                cfg.save()
                console.print(
                    f"[green]✓ Signed in to[/green] [bold]{c.name}[/bold] as [bold]{c.user_email or 'user'}[/bold]",
                )
                return
            if status in ("expired", "denied"):
                err_console.print(f"[red]Login {status}:[/red] {poll.get('message', '')}")
                raise typer.Exit(code=1)
            err_console.print(f"[red]Unexpected status:[/red] {status}")
            raise typer.Exit(code=1)

    err_console.print("[red]Login timed out.[/red] Run `enkindler login` again.")
    raise typer.Exit(code=1)


def logout(
    cluster: str | None = typer.Option(None, "--cluster", "-c", help="Cluster to sign out of (defaults to the configured default)."),
) -> None:
    """Clear the locally cached token. Does not invalidate the JWT server-side."""
    cfg = Config.load()
    try:
        c = cfg.resolve(cluster)
    except ConfigError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1) from None
    if not c.token:
        console.print(f"Already signed out of [bold]{c.name}[/bold].")
        return
    cfg.clear_token(c.name)
    cfg.save()
    console.print(f"[green]✓ Signed out of[/green] [bold]{c.name}[/bold].")
