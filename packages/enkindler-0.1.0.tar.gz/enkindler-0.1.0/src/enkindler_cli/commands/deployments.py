"""`enkindler deployment ...` — list/get for now; create/delete to follow once
the auto-generated SDK lands.
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from ..client import Client, ConfigError
from ..config import Config

app = typer.Typer(no_args_is_help=True)
console = Console()
err_console = Console(stderr=True)


def _resolve(cluster: str | None, api_url: str | None) -> Client:
    cfg = Config.load()
    try:
        c = cfg.resolve(cluster)
    except ConfigError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1) from None
    return Client.from_cluster(c, api_url_override=api_url)


@app.command("list")
def list_deployments(
    cluster: str | None = typer.Option(None, "--cluster", "-c"),
    api_url: str | None = typer.Option(None, "--api-url"),
    mcp: bool = typer.Option(False, "--mcp", help="Only MCP-server deployments."),
) -> None:
    """List Enkindler-managed AKS deployments."""
    params = {"mcp": "true"} if mcp else None
    with _resolve(cluster, api_url) as c:
        rows = c.get("/api/deployments", params=params)

    if not rows:
        console.print("[dim]No deployments.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("ID", justify="right")
    table.add_column("Name")
    table.add_column("Namespace")
    table.add_column("Image", overflow="fold")
    table.add_column("Replicas", justify="right")
    table.add_column("Status")
    table.add_column("Owner")

    for d in rows:
        creator = d.get("creator") or {}
        owner = creator.get("name") or creator.get("email") or "—"
        image = f"{d.get('repository', '')}:{d.get('image_tag', '')}"
        table.add_row(
            str(d["id"]),
            d["name"],
            d["namespace"],
            image,
            str(d["replicas"]),
            d["status"],
            owner,
        )
    console.print(table)


@app.command("get")
def get_deployment(
    deployment_id: int = typer.Argument(..., help="Numeric deployment id."),
    cluster: str | None = typer.Option(None, "--cluster", "-c"),
    api_url: str | None = typer.Option(None, "--api-url"),
) -> None:
    """Show one deployment by id."""
    with _resolve(cluster, api_url) as c:
        d = c.get(f"/api/deployments/{deployment_id}")
    creator = d.get("creator") or {}
    console.print(f"[bold]{d['name']}[/bold]  ({d['namespace']})")
    console.print(f"  Status:    {d['status']}")
    console.print(f"  Image:     {d.get('repository')}:{d.get('image_tag')}")
    console.print(f"  Replicas:  {d['replicas']}")
    console.print(f"  App URL:   {d.get('app_url') or '—'}")
    console.print(f"  Owner:     {creator.get('name') or creator.get('email') or '—'}")
    if d.get("error_message"):
        console.print(f"  [red]Error:[/red] {d['error_message']}")
