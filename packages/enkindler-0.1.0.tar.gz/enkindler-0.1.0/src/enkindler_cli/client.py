"""Thin httpx wrapper that injects the cached JWT and raises typed errors.

Eventually most calls will go through the openapi-python-client generated SDK
in `_generated/`. This wrapper handles the bootstrap concerns:

  * the device-code login flow (no token yet)
  * sanity calls like /api/health and /api/instance that don't require auth
  * a uniform AuthError that the CLI can intercept with a "run `enkindler login`"
    hint instead of a stack trace

URL resolution is now driven by the multi-cluster Config — Client.from_cluster()
takes a resolved Cluster object. Per-command --api-url and ENKINDLER_API_URL
override the cluster's stored URL but reuse its token.
"""

from __future__ import annotations

from typing import Any

import httpx

from .config import Cluster, Config, ConfigError, effective_url_override

USER_AGENT = "enkindler-cli/0.0.1"


class APIError(Exception):
    """Backend returned a non-2xx status with an error envelope."""

    def __init__(self, status: int, message: str):
        super().__init__(f"{status}: {message}")
        self.status = status
        self.message = message


class AuthError(APIError):
    """401/403 — token missing, invalid, or insufficient privileges."""


def _raise(resp: httpx.Response) -> None:
    if resp.is_success:
        return
    try:
        body: dict[str, Any] = resp.json()
        msg = body.get("error") or body.get("message") or resp.text
    except (ValueError, httpx.DecodingError):
        msg = resp.text or resp.reason_phrase
    if resp.status_code in (401, 403):
        raise AuthError(resp.status_code, msg)
    raise APIError(resp.status_code, msg)


class Client:
    """Synchronous httpx client scoped to one Enkindler backend."""

    def __init__(self, base_url: str, token: str | None = None, timeout: float = 30.0):
        headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        self._http = httpx.Client(base_url=base_url, headers=headers, timeout=timeout)

    @classmethod
    def from_cluster(cls, cluster: Cluster, *, api_url_override: str | None = None) -> Client:
        url = api_url_override or effective_url_override() or cluster.url
        return cls(base_url=url, token=cluster.token)

    @classmethod
    def for_url(cls, url: str, *, token: str | None = None) -> Client:
        """Bare client for endpoints that don't have a configured cluster yet
        (e.g. `enkindler config add` verifying a fresh URL)."""
        return cls(base_url=url.rstrip("/"), token=token)

    @classmethod
    def from_default(cls, cluster_name: str | None = None, api_url_override: str | None = None) -> Client:
        """Convenience: resolve via Config.load() and the optional --cluster name.
        Raises ConfigError if no cluster is configured / resolvable."""
        cfg = Config.load()
        cluster = cfg.resolve(cluster_name)
        return cls.from_cluster(cluster, api_url_override=api_url_override)

    def get(self, path: str, **kwargs: Any) -> Any:
        r = self._http.get(path, **kwargs)
        _raise(r)
        return r.json()

    def post(self, path: str, json: Any | None = None, **kwargs: Any) -> Any:
        r = self._http.post(path, json=json, **kwargs)
        _raise(r)
        if r.status_code == 204 or not r.content:
            return None
        return r.json()

    def patch(self, path: str, json: Any | None = None, **kwargs: Any) -> Any:
        r = self._http.patch(path, json=json, **kwargs)
        _raise(r)
        return r.json()

    def delete(self, path: str, **kwargs: Any) -> Any:
        r = self._http.delete(path, **kwargs)
        _raise(r)
        return r.json() if r.content else None

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()


# Re-export for command modules.
__all__ = ["APIError", "AuthError", "Client", "Cluster", "Config", "ConfigError"]
