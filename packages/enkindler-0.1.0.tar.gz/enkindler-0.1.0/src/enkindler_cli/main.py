"""Top-level Typer app. Subcommands live under enkindler_cli.commands.*"""

from __future__ import annotations

import sys

import typer
from rich.console import Console

from . import __version__
from .client import APIError, AuthError
from .commands import auth as auth_cmds
from .commands import config as config_cmds
from .commands import deployments as deployment_cmds
from .commands import users as user_cmds

app = typer.Typer(
    name="enkindler",
    help="Command-line interface for the Enkindler AI operations dashboard.",
    no_args_is_help=True,
    add_completion=True,
)

# Register subcommands.
app.command("login")(auth_cmds.login)
app.command("logout")(auth_cmds.logout)
app.command("whoami")(user_cmds.whoami)
app.add_typer(deployment_cmds.app, name="deployment")
app.add_typer(config_cmds.app, name="config")


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"enkindler {__version__}")
        raise typer.Exit()


@app.callback()
def root(
    version: bool = typer.Option(
        False, "--version", "-V", callback=_version_callback, is_eager=True,
        help="Print version and exit.",
    ),
) -> None:
    """Global options."""


def _entry() -> None:
    """Wraps `app()` so AuthError / APIError become friendly messages instead of tracebacks."""
    err_console = Console(stderr=True)
    try:
        app()
    except AuthError as e:
        err_console.print(f"[red]Auth error ({e.status}):[/red] {e.message}")
        err_console.print("Run [bold]enkindler login[/bold] to refresh your session.")
        sys.exit(2)
    except APIError as e:
        err_console.print(f"[red]API error ({e.status}):[/red] {e.message}")
        sys.exit(1)


if __name__ == "__main__":
    _entry()
