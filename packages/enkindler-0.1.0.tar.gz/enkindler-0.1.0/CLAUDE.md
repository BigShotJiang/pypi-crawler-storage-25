# CLAUDE.md

Operating manual for Claude Code (and human contributors) working in this repo.

## Project Overview

`enkindler-cli` is the Python command-line client for the [Enkindler](https://enkindler.enkindl.com) AI operations dashboard. Distributed on PyPI as `pip install enkindler`. Patterned after `az` and `databricks`.

The CLI is **also exposed as a tool to AI agents**, so command behaviour, output, and error messages must be unambiguous and machine-parseable. When in doubt, optimize for "an LLM should be able to call this without trial and error."

The companion backend repo is at `../enkindler/` (sibling). The backend exposes an OpenAPI 3 spec at `/api/openapi.json`; the CLI consumes that spec to generate a typed SDK and surface commands.

## Repo layout

```
enkindler-cli/
├── Makefile                # Source of truth for all dev/build/release commands
├── pyproject.toml          # PEP 621 metadata; deps; ruff/pytest config
├── README.md               # End-user docs (install, basic usage)
├── CLAUDE.md               # ← this file
├── docs/                   # Long-form procedures (release, sdk-sync, etc.)
├── .github/workflows/ci.yml  # OS × Python matrix
├── src/enkindler_cli/
│   ├── __init__.py         # __version__
│   ├── main.py             # Typer app + global error handler (_entry)
│   ├── client.py           # httpx wrapper + AuthError/APIError
│   ├── config.py           # platformdirs-based TOML config
│   ├── commands/
│   │   ├── auth.py         # login (device-code), logout
│   │   ├── users.py        # whoami
│   │   └── deployments.py  # list, get, ...
│   └── _generated/         # ← gitignored; created by `make regen-sdk`
└── tests/
```

## Always use `make`

Every common task has a make target. Use them. Never invoke `pytest` / `ruff` / `python -m build` directly — CI uses make, so should you. This is the only way command lines stay in sync across humans, CI, and Claude.

```bash
make help          # list everything
make install       # set up venv + install with [dev] extras
make test          # run pytest
make lint          # ruff check (no fix)
make format        # ruff fix + format
make smoke         # `enkindler --version` + `--help` smoke check
make build         # sdist + wheel into ./dist
make regen-sdk     # pull /api/openapi.json from backend, regenerate _generated/
make publish       # twine upload to PyPI (needs TWINE_PASSWORD)
make clean         # rm caches and build artifacts
```

If you need a new shell command frequently, add it as a make target — don't put it in CLAUDE.md prose.

## Conventions

### Commands
- One file per noun under `src/enkindler_cli/commands/` (e.g. `deployments.py`, `helm.py`, `integrations.py`).
- A noun with subcommands (verbs) uses a Typer sub-app: see `commands/deployments.py` — exports `app = typer.Typer()` and uses `@app.command("list")`.
- A noun with one verb (`whoami`, `login`) is a plain function: see `commands/users.py` — register at the top level in `main.py`.
- All commands accept `--api-url` (override env / config). Resolution: flag > `ENKINDLER_API_URL` > config file > default. Use `effective_api_url()` from `config.py`.

### Errors
- Never `raise` raw `httpx.HTTPStatusError`. Use `Client` from `client.py` — it converts non-2xx to `AuthError` (401/403) or `APIError` (other). The top-level `_entry()` in `main.py` formats both as friendly red messages with a recovery hint.
- For business-logic exits, `raise typer.Exit(code=N)` — never `sys.exit()`.

### Output
- Human output → `rich.Console()` to stdout.
- Errors → `rich.Console(stderr=True)`.
- Tables are the default for list commands. Use `rich.table.Table`.
- Don't print debug info to stdout — that breaks `--output json` (when we add it).

### HTTP
- All HTTP via `Client` from `client.py`. Always use it as a context manager.
- One `Client` per command invocation. Don't share connection pools across commands.

### Config
- Use `platformdirs` for paths. Never hardcode `~/.enkindler` — Windows uses `%APPDATA%`.
- TOML, not JSON or YAML.
- Token cached in `config.toml` with 0o600 perms on POSIX. Don't put tokens in env vars or CLI args; the only sanctioned write path is `enkindler login` → `Config.save()`.

### Cross-platform
We support macOS, Linux, and Windows on Python 3.10–3.13. CI runs the full matrix. Avoid:
- `os.path.join('/etc/...')`, hardcoded slashes — use `pathlib`
- Shelling out to Unix-only tools (`curl`, `grep`, `sed`)
- `subprocess` with `shell=True` — pass an arg list
- Symlinks
- ANSI escape codes in non-TTY output (Rich handles this if you let it)

## Common Tasks

### Add a new command
1. Create or edit a file under `src/enkindler_cli/commands/`.
2. If it's a new noun, add a sub-`Typer` and register it in `main.py` via `app.add_typer(... name="noun")`.
3. Add a smoke test in `tests/test_smoke.py` that the new command appears in `--help`.
4. Run `make lint test` before committing.

### Add a new endpoint to call
Once the backend annotates a new route (see backend `CLAUDE.md` → "Annotating routes for OpenAPI/CLI"):
1. Run `make regen-sdk` (or `make regen-sdk OPENAPI_URL=http://localhost:5179/api/openapi.json` while iterating locally).
2. Use the generated client from `_generated/` in your command. Until the SDK lands, hand-call via `Client.get` / `.post`.

### Cut a release
See `docs/release.md` (TBD — write when we cut v0.1.0). Short version:
1. Bump `__version__` in `src/enkindler_cli/__init__.py` AND `version` in `pyproject.toml`.
2. `make clean build`
3. `make publish-test` → install from TestPyPI in a fresh venv, smoke-test
4. `make publish`
5. `git tag vX.Y.Z && git push --tags`

### Backend out of sync with CLI
If `make regen-sdk` fails or the generated SDK doesn't compile, the backend OpenAPI spec is malformed. Fix it in `../enkindler/backend/src/server.js` (the JSDoc `@openapi` block above the offending route) — see backend `CLAUDE.md` for the annotation pattern.

## Testing the CLI against a real backend

```bash
make install
make smoke                    # offline smoke
.venv/bin/enkindler login     # device-code flow against prod backend
.venv/bin/enkindler whoami
.venv/bin/enkindler deployment list
```

Override the backend for local dev:
```bash
ENKINDLER_API_URL=http://localhost:5179 .venv/bin/enkindler login
```

## What NOT to do

- Don't add a `requirements.txt`. Deps live in `pyproject.toml`.
- Don't pin sub-dependencies in `pyproject.toml` — only direct deps.
- Don't commit `src/enkindler_cli/_generated/` — gitignored, regenerated on demand.
- Don't add Click decorators directly. Use Typer (which wraps Click) — it gives us free `--help` from type hints.
- Don't break Python 3.10. We support it until end-of-life.
- Don't import optional deps at the top of a module — gate behind `if TYPE_CHECKING:` or import inside the function. Keeps `enkindler --help` snappy.

## Pointers to backend repo

- Backend endpoints, auth model, RBAC, deployment infrastructure → `../enkindler/CLAUDE.md`
- Backend OpenAPI annotation pattern → `../enkindler/CLAUDE.md` → "Annotating routes for OpenAPI/CLI"
- Device-code auth implementation → `../enkindler/backend/src/auth/deviceCode.js`
