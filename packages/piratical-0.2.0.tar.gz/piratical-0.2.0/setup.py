from setuptools import setup
from os import path

here = path.abspath(path.dirname(__file__))

# Get the long description from the README file
with open(path.join(here, 'README.rst'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='piratical',

    version='0.2.0',

    description='Plunder spectra from the JWST NIRSpec archive',

    long_description=long_description,

    url='https://bagpipes.readthedocs.io',

    author='Adam Carnall, Ho-Hin Leung',

    author_email='adamc@roe.ac.uk',

    packages=["piratical"],

    include_package_data=True,

    install_requires=["numpy<=2.2", "pandas", "astropy", "matplotlib>=2.2.2",
                      "scipy", "mastquery", "jwst"],

    project_urls={
        "GitHub": "https://github.com/ACCarnall/piratical_pipeline"
    }
)
