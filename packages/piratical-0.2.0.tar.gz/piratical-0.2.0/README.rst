NIRSpec Piratical Pipeline
--------------------------

Plunder spectra from the JWST archive.


FAQ/things to note
------------------

Q: I'm getting errors that say something about the CRDS server connection failing

A: To run the JWST pipeline you need to set some environment variables so the pipeline can download calibration files, details available here: `here <https://jwst-pipeline.readthedocs.io/en/latest/jwst/user_documentation/reference_files_crds.html#crds-servers>`_. Sometimes the CRDS server seems to go down and you might need to wait a few hours to be able to connect to it again.

Q: A step in the pipeline is failing, potentially saying something about missing ASDF?

A: You might have a partially downloaded rate or uncal file (depending on whether you're skipping the L1 pipeline or not). Look in the uncal_files or rate_files directory for one or more files that are smaller than the others, try deleting them and running again.