# PyTools

一个实用的Python工具库，提供各种数据处理、时间日期、字典列表操作等实用工具函数。

**注意**: 包在PyPI上的名称是 `liwancai-PyTools`，但导入时使用 `PyTools`

## 安装

```bash
pip install liwancai-PyTools
```

## 使用

```python
# 导入整个包的所有功能
from PyTools import *

# 使用字典工具
json_data = {"name": "John", "age": 30}
keys = DictGETKEY(json_data)
print(keys)  # ['name', 'age']

# 使用列表工具
my_list = [3, 1, 2, 1]
unique_list = SetList(my_list)
print(unique_list)  # [1, 2, 3]

# 使用时间工具
today_week = ToDayWeek()
print(f"今天是星期{today_week + 1}")

# 使用通用工具
progress = TqdmN(100)
for i in range(100):
    progress.update("处理中")
```

### 其他导入方式

```python
# 导入特定模块
from PyTools import Dict
keys = Dict.DictGETKEY({"a": 1})

# 导入特定函数
from PyTools.Dict import DictGETKEY
keys = DictGETKEY({"a": 1})
```

## 功能模块

- **Dict**: 字典操作工具
- **List**: 列表操作工具  
- **TimeDate**: 时间日期工具
- **Tools**: 通用工具函数

## 许可证

MIT License