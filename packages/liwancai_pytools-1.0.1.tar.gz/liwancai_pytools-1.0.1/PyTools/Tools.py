
from .Dict import DictGETKEY  # 包内模块间使用相对导入
from LOG import log
import pandas as pd
import time,math,random,re
from tqdm import tqdm
from datetime import datetime
import traceback
from functools import wraps

def Sleep(value, unit: str = "s"):
    """
    优雅倒计时休眠函数（支持秒、分、毫秒）
    :param value:  数字  如 5、0.5、10
    :param unit:   单位  s=秒 | m=分 | ms=毫秒
    """
    try:
        # 单位换算 → 统一转总秒数
        if unit == "ms":
            total_sec = value / 1000  # 毫秒
        elif unit == "m":
            total_sec = value * 60   # 分钟
        else:
            total_sec = value        # 秒（默认）
        # 小于 0.1 秒直接休眠，不显示倒计时
        if total_sec < 0.1:
            time.sleep(total_sec)
            return
        # 倒计时总秒数（向上取整，保证动画完整）
        total = int(total_sec) + 1
        start_time = time.time()
        for remain in range(total, -1, -1):
            elapsed = time.time() - start_time
            remain = max(0, total_sec - elapsed)
            if remain < 0:
                break
            # 格式化显示：分:秒
            m = int(remain // 60)
            s = int(remain % 60)
            timer = f"{m:02d}:{s:02d}" if m > 0 else f"{s} 秒"
            # 同一行刷新倒计时
            print(f"\r||休眠倒计时: {timer} ||", end="", flush=True)
            time.sleep(1)
        print()  # 结束后换行，不影响后续日志
    except Exception as err:
        log.Error(f"Sleep 异常: {err}")

class SetClass:
    """
    万能字典转对象
    支持：dict → 对象属性
    支持：嵌套字典（子对象自动转 SetClass）
    支持：对象 转 对象
    安全、无崩溃、无关键字冲突
    """
    def __init__(self, data=None):
        try:
            # 空值安全处理
            if data is None:return
            # 如果是字典 → 递归转对象
            if isinstance(data, dict):
                for key, value in data.items():
                    # 嵌套字典自动转 SetClass
                    if isinstance(value, dict):
                        self.__dict__[key] = SetClass(value)
                    # 列表里的字典也转
                    elif isinstance(value, list):
                        self.__dict__[key] = [SetClass(item) if isinstance(item, dict) else item for item in value]
                    else:
                        self.__dict__[key] = value
            # 如果是对象 → 复制它的 __dict__
            elif hasattr(data, "__dict__"): self.__dict__.update(data.__dict__)
            # 不支持的类型
            else: log.Error(f"SetClass 不支持的类型: {type(data)}")
        except Exception as e:
            log.Error(f"SetClass 初始化失败: {str(e)}")
    # 可选：让对象可以转字典，方便反向使用
    def to_dict(self):
        return self.__dict__.copy()

def RunTime(func):
    '''
    装饰器：统计函数运行耗时
    支持：普通函数、类方法、异步函数、多进程函数
    '''
    @wraps(func)  # 必须加！保留原函数信息
    def inner(*arg, **kwarg):
        s_time = time.time()
        res = func(*arg, **kwarg)
        e_time = time.time()
        cost = round(e_time - s_time, 3)
        log.Info(f'\n||【{func.__name__}】运行耗时: {cost} 秒||\n')
        return res
    return inner

def TryErrMsg(func):
    """
    通用异常捕获装饰器
    自动捕获异常 + 打印堆栈 + 记录错误函数名 + 不中断程序
    """
    @wraps(func)  # 关键：保留原函数信息（必须加）
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as err:
            # 错误堆栈（定位到哪一行）
            error_msg = traceback.format_exc()
            # 错误函数名 + 错误信息
            log.Error(f"【函数异常】{func.__name__} | 错误信息：{str(err)}")
            log.Error(f"【错误堆栈】\n{error_msg}")
            # 抛出异常 或 返回None 二选一
            # raise  # 如果你想中断程序，打开这个
            return None  # 如果你想忽略错误继续运行，返回None
    return wrapper

def DelInt(strold):  #
    '''字符串去数字'''
    return re.sub(r'[0-9]+', '', strold)
def DelAbc(strold):  #
    '''字符串去字母'''
    return re.sub(r"[A-Za-z]","",strold) 
def OnlyCHN(txt):
    '''只保留汉字'''
    return re.sub('[^\u4e00-\u9fa5]+','',txt)

def DelPunc(string: str, punc: str | list | None = "all"):
    """
    清除字符串中的标点、特殊符号
    :param string: 原始字符串
    :param punc: 要清除的符号
           - 'all' = 清除所有常见中英文标点符号（默认）
           - 可自定义字符串 如 ',.!?'
           - 可传列表 如 ['!', '@', '#']
    :return: 清理后的干净字符串
    """
    if not string:
        return ""
    # ===================== 【彻底修复】所有符号拆分编写，杜绝 # 变注释 =====================
    # 英文符号
    en_punc = r'"#$%&\'()*+,-./:;<=>?@[\]^_`{|}~' + '!'
    # 中文符号
    cn_punc = r'！？。＂＃＄％＆＇（）＊＋，－／：；＜＝＞＠［＼］＾＿｀｛｜｝～'
    # 扩展符号
    ex_punc = r'｢｣、〃「」『』【】〔〕〘〙〚〛〜〝〞〟〰–—‘’‛“”„‟…‧﹏·°²³'
    all_punctuation = en_punc + cn_punc + ex_punc
   
    if punc == "all":pattern = re.escape(all_punctuation) # 确定要替换的字符集
    elif isinstance(punc, (list, tuple)):pattern = "".join(re.escape(c) for c in punc)
    else:pattern = re.escape(punc)
    return re.sub(f"[{pattern}]+", "", string)# 执行替换

class TqdmN:  #
    '''进度条'''
    def __init__(self, arges):
        self.pbar  = tqdm(total=arges)  if isinstance(arges, int) else tqdm(total=len(arges)) 
        self.btime = time.strftime("%Y-%m-%d %H:%M:%S")
        self.stime = datetime.now()
        self.etime = time.strftime("%Y-%m-%d %H:%M:%S")
    def update(self,string=None):
        if not string:string="进度"
        ftime = datetime.now()
        rtime = (ftime - self.stime).seconds
        try:
            self.pbar.set_description('\n||■|%s|■||Time Span:%.1f s|■=>>'%(string,rtime))
            self.pbar.update()
        except KeyboardInterrupt:self.pbar.close()

def RoundDw(number, digit=1):
    """
    向下取整（直接截断，不四舍五入）
    示例：
    RoundDw(3.1415926, 2) → 3.14
    RoundDw(2.399, 1)    → 2.3
    RoundDw(5.999, 1)    → 5.9
    """
    return math.floor(number * (10 ** digit)) / (10 ** digit)

def RoundUp(number, digit=1):
    """
    向上取整（不管后面是几，都进一位）
    示例：
    RoundUp(3.1415926, 2) → 3.15
    RoundUp(2.311, 1)    → 2.4
    RoundUp(5.901, 1)    → 6.0
    """
    return math.ceil(number * (10 ** digit)) / (10 ** digit)

def RColor(Num=1):
    '''随机颜色'''
    ColorS, colorArr = [], ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F']
    for i in range(Num):
        color = ""
        for i in range(6): color += colorArr[random.randint(0, 14)]
        ColorS.append("#" + color)
    return ColorS

def DFToDict(df: pd.DataFrame, orient="records", force_ascii=False, index_field=None):
    '''
    DataFrame 转 字典/列表
    ✅ 自动处理 None / NaN，不报错
    ✅ 支持指定某一列作为索引 key (index_field)
    :param df: 传入的 DataFrame
    :param orient: records=列表集合 | index=索引字典
    :param force_ascii: 强制ASCII（False 支持中文）
    :param index_field: 当 orient="index" 时，指定哪一列作为字典的key
    :return: 列表 或 字典
    '''
    # 核心：处理 NaN/None，避免解析报错
    df = df.where(pd.notna(df), None)
    # ====================== 核心增强：指定字段作为索引 ======================
    if orient == "index" and index_field is not None:
        # 把指定列设为索引，再转字典
        return df.set_index(index_field).to_dict(orient="index")
    # 默认逻辑
    json_str = df.to_json(orient=orient, force_ascii=force_ascii, default_handler=str)
    return EVALI(json_str)

def SplitDF(data:pd.DataFrame,maxnum=8000,minnum=2000):
    '''
    将dataframe 分批次拆解
    :param data: 输入的dataframe
    :param maxnum: 每个列表的最大长度
    :param minnum: 每个列表的最小长度
    :return: 分割后的dataframe列表 
    '''
    Num,rst=len(data),[]
    if Num>maxnum:
        cutlists=[i for i in range(0,Num,Num//(Num//minnum))]
        for i in range(len(cutlists)): 
            if i >=(len(cutlists)-1):df=data[cutlists[i]:]
            else:df=data[cutlists[i]:cutlists[i+1]]
            rst.append(df)
        return rst
    else:return [data]
    
def DFToType(df:pd.DataFrame,keys:list,types=str):
    '''修改df 的列的数据格式'''
    try:
        for key in keys:
            try:df[key]=df[key].astype(types)
            except:continue
    except Exception as exception:
        log.Error(str(exception))

def EVALI(STData:str):
    '''
    字符串转换成json list
    格式化json list
    '''
    for i in ["[" , "]" , "{" , "}" ]:
        try:
            if i in STData:
                try:STData=eval(STData)
                except:pass
        except Exception as err: 
            log.Error(err)
            pass       
    return STData

def Str2Float(strs,err=None):
    '''字符串转换成浮点数'''
    try:return float(strs)
    except:return err  if isinstance(err,float) else strs

def Str2Int(strs,err=None):
    '''字符串转换成整数'''
    try:return int(strs)
    except:return err  if isinstance(err,int) else strs


def DictStr2Float(JSData:dict):
    '''批量json内容转float'''
    for key in DictGETKEY(JSData):
        JSData[key]=Str2Float(JSData[key])
    return JSData
