
def ReversedList(List:list):
    '''反转列表的顺序'''
    return list(reversed(List))
    
def SetList(List:list,Sort=True):
    """
    一个函数，接受一个列表，可选地对其进行排序和去重。

    """
    if Sort:return sorted(list(set(List)))#简易去重升序且不考虑顺序
    SetLS=[]
    for x in List:
        if x in SetLS:continue
        SetLS.append(x)
    return SetLS

def ListUniqueItems(List:list):
    '''
    返回list中独一无二的元素列表
    :param List: 输入的元素列表
    :return: 包含独一无二元素的列表
    '''
    d = {}
    for elem in List:
        if elem in d:
            d[elem] += 1
        else:
            d[elem] = 1
    return [k for k,v in d.items() if v == 1] 

def SplitList(data:list,maxnum=8000,minnum=2000):
    """
    将列表分割成多个列表，每个列表的长度不超过maxnum
    :param data: 输入的元素列表
    :param maxnum: 每个列表的最大长度
    :param minnum: 每个列表的最小长度
    :return: 分割后的列表列表 最后一个太少就添加到倒数第二个中 不单独成一个列表
    """
    Num = len(data)
    if Num>maxnum:
        indexall  =  Num//minnum
        rstlist = [data[i:i+int(Num//indexall)] for i in range(0,Num,int(Num//indexall))]
        if len(rstlist[-1])<minnum//10:## 最后一个太少就添加到倒数第二个中
            rstlist[-2]+= rstlist[-1]
            rstlist= rstlist[:-1]
        return rstlist
    else:return [data]
 
def DifEntSet(listA, listB):  
    '''取在A中不在B的list'''
    return list(set(listA).difference(set(listB)))
def InterSet(listA, listB):
    '''取两个列表的交集'''
    return list(set(listA).intersection(set(listB)))

def ListItemNum(List:list =[]):
    counts = {}
    for item in List:
        if item in counts:
            counts[item] += 1
        else:
            counts[item] = 1
    return counts

    