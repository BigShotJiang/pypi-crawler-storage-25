from LOG      import log
from datetime import datetime
from datetime import timedelta
import time, re

def ToDayWeek():
    '''
    0: 星期1 1: 星期2 2: 星期3 3: 星期4 4: 星期5 5: 星期6 6: 星期日
    '''
    return datetime.now().weekday()
###############################################################################
def StrDateSpan(start_date, end_date,format='%Y-%m-%d %H:%M:%S'):
    '''
    获取日期之间的时间间隔（以天为单位）
    :param start_date: 开始日期字符串
    :param end_date: 结束日期字符串
    :param format: 日期格式
    :return: 时间间隔（天）
    '''
    start_date = datetime.strptime(start_date,format) # 将日期字符串转换为日期对象
    end_date  = datetime.strptime(end_date, format) # 将日期字符串转换为日期对象
    time_delta = end_date - start_date# 计算时间差
    time_interval = time_delta.days# 提取出时间间隔（以天为单位）
    return time_interval

def Str2Timestamp(str_time, fmt='%Y-%m-%d %H:%M:%S', ms=False):
    """
    日期字符串 → 时间戳
    :param str_time: 时间字符串 如 '2023-01-01 12:34:56'
    :param fmt: 时间格式
    :param ms: True=毫秒级，False=秒级（默认）
    :return: int 时间戳
    """
    try:
        dt = datetime.strptime(str_time, fmt)
        ts = dt.timestamp()
        return int(ts * 1000) if ms else int(ts)
    except Exception as e:
        log.Error(f"字符串转时间戳失败：{str_time}，格式：{fmt}，错误：{str(e)}")
        return None

def Timestamp2Str(ts, fmt='%Y-%m-%d %H:%M:%S'):
    """
    时间戳 → 日期字符串（自动识别 秒/毫秒）
    :param ts: 时间戳 10位(秒) 或 13位(毫秒)
    :param fmt: 输出格式
    :return: 格式化时间字符串
    """
    try:
        ts = float(ts)
        # 自动识别毫秒级时间戳（长度13位）
        if ts > 1e12:
            ts = ts / 1000
        dt = datetime.fromtimestamp(ts)
        return dt.strftime(fmt)
    except Exception as e:
        log.Error(f"时间戳转字符串失败：{ts}，错误：{str(e)}")
        return None


def ModifyDateTime(date_str, days=0, hours=0, minutes=0, output_format=None):
    """
    增强版的日期时间加减函数
    
    参数:
        date_str: 日期时间字符串
        days: 加减天数
        hours: 加减小时  
        minutes: 加减分钟
        output_format: 输出格式，如果为None则保持输入格式
        
    返回:
        计算后的日期时间字符串
    """
    # 完整的格式模式列表，按优先级排序
    patterns = [
        # 带秒的完整时间格式
        (r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$', "%Y-%m-%d %H:%M:%S"),
        (r'^\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}$', "%Y/%m/%d %H:%M:%S"),
        (r'^\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2}$', "%Y.%m.%d %H:%M:%S"),
        (r'^\d{4}年\d{2}月\d{2}日 \d{2}时\d{2}分\d{2}秒$', "%Y年%m月%d日 %H时%M分%S秒"),
        # 紧凑格式（无分隔符）
        (r'^\d{14}$', "%Y%m%d%H%M%S"),  # YYYYMMDDHHMMSS
        (r'^\d{12}$', "%Y%m%d%H%M"),    # YYYYMMDDHHMM
        # 不带秒的时间格式
        (r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$', "%Y-%m-%d %H:%M"),
        (r'^\d{4}/\d{2}/\d{2} \d{2}:\d{2}$', "%Y/%m/%d %H:%M"),
        (r'^\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}$', "%Y.%m.%d %H:%M"),
        (r'^\d{4}年\d{2}月\d{2}日 \d{2}时\d{2}分$', "%Y年%m月%d日 %H时%M分"),
        # 带时间部分的紧凑格式
        (r'^\d{8} \d{2}:\d{2}:\d{2}$', "%Y%m%d %H:%M:%S"),
        (r'^\d{8} \d{2}:\d{2}$', "%Y%m%d %H:%M"),
        # 纯日期格式
        (r'^\d{4}-\d{2}-\d{2}$', "%Y-%m-%d"),
        (r'^\d{4}/\d{2}/\d{2}$', "%Y/%m/%d"),
        (r'^\d{4}\.\d{2}\.\d{2}$', "%Y.%m.%d"),
        (r'^\d{4}年\d{2}月\d{2}日$', "%Y年%m月%d日"),
        (r'^\d{8}$', "%Y%m%d"),  # 纯日期紧凑格式
    ]
    # 去除输入字符串两端的空格
    date_str = date_str.strip()
    dt = None
    detected_format = None
    # 尝试匹配各种格式
    for pattern, fmt in patterns:
        if re.match(pattern, date_str):
            try:
                dt = datetime.strptime(date_str, fmt)
                detected_format = fmt
                break
            except ValueError:
                continue
    if dt is None:
        # 如果以上格式都不匹配，尝试更灵活的解析
        flexible_formats = [
            "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d",
            "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M", "%Y/%m/%d", 
            "%Y%m%d%H%M%S", "%Y%m%d%H%M", "%Y%m%d",
            "%Y.%m.%d %H:%M:%S", "%Y.%m.%d %H:%M", "%Y.%m.%d",
            "%Y年%m月%d日 %H时%M分%S秒", "%Y年%m月%d日 %H时%M分", "%Y年%m月%d日"
        ]
        for fmt in flexible_formats:
            try:
                dt = datetime.strptime(date_str, fmt)
                detected_format = fmt
                break
            except ValueError:
                continue
    if dt is None:
        raise ValueError(f"无法识别的日期时间格式: {date_str}")
    # 计算新时间
    delta = timedelta(days=days, hours=hours, minutes=minutes)
    new_dt = dt + delta
    # 确定输出格式
    if output_format:
        return new_dt.strftime(output_format)
    else:
        return new_dt.strftime(detected_format)

   
def NowTime(Format='%Y-%m-%d %H:%M:%S'):
    '''返回当前时间'''
    return datetime.now().strftime(Format)
def ToDaydate(Format='%Y-%m-%d'):
    '''返回今日日期'''
    from datetime import date
    return (date.today()).strftime(Format)

def ToDayTime(time_str=None, ms: bool = False):
    """
    不传参：返回当前时间戳
    传时间字符串：返回【今天 + 该时间】的时间戳
    支持格式：
          HH:MM:SS   例：15:00:00
          HH:MM      例：09:31
          HHMMSS     例：150000
          HHMM       例：1030
          HH         例：14
          
    :param time_str: 时间字符串，不传则返回当前时间戳
    :param ms: 是否返回毫秒级时间戳，默认 False（秒级），True=毫秒
    :return: int 时间戳
    """
    today = datetime.now().date()
    
    # 不传参数 = 当前时间戳
    if time_str is None:
        ts = datetime.now().timestamp()
        return int(ts * 1000) if ms else int(ts)

    s = str(time_str).strip()
    dt = None

    try:
        # 匹配 HH:MM:SS
        if re.match(r'^\d{1,2}:\d{1,2}:\d{1,2}$', s):
            dt = datetime.combine(today, datetime.strptime(s, '%H:%M:%S').time())
        # 匹配 HH:MM
        elif re.match(r'^\d{1,2}:\d{1,2}$', s):
            dt = datetime.combine(today, datetime.strptime(s, '%H:%M').time())
        # 匹配 HHMMSS 6位
        elif re.match(r'^\d{6}$', s):
            dt = datetime.combine(today, datetime.strptime(s, '%H%M%S').time())
        # 匹配 HHMM 4位
        elif re.match(r'^\d{4}$', s):
            dt = datetime.combine(today, datetime.strptime(s, '%H%M').time())
        # 匹配 HH 2位
        elif re.match(r'^\d{2}$', s):
            dt = datetime.combine(today, datetime.strptime(s, '%H').time())
        else:
            log.Error(f'不支持的时间格式: {time_str}')
            ts = dt.timestamp()
            return int(ts * 1000) if ms else int(ts)
    except Exception as e:
        log.Error(f'时间解析失败: {time_str}, 错误: {str(e)}')
        ts = dt.timestamp()
        return int(ts * 1000) if ms else int(ts)

    ts = dt.timestamp()
    return int(ts * 1000) if ms else int(ts)