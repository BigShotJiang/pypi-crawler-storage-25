
#%% 基础函数
def LoadJS(strjs):
    '''
    json格式化
    :param strjs: json字符串
    :return: json对象
    '''
    import json
    try:return json.loads(strjs)
    except:return {}

def DictGETKEY(JSData:dict,Sort:str=None  ):
    '''
    获取Json的KEY 
    Sort:asc/desc
    默认不排序 返回KEY列表默认顺序
    '''
    try:
        if Sort=='asc':
            return sorted(list(JSData.keys()),reverse=False)
        elif Sort=='desc':
            return sorted(list(JSData.keys()),reverse=True) 
        else:
            return list(JSData.keys())
    except:return []

def DictRename(jsdt:dict,OLDname:str,NEWname:str):
    '''
    dict键值重命名
    '''
    try:jsdt[NEWname] = jsdt.pop(OLDname)
    except:pass
