from pydantic import BaseModel, computed_field


class SchedulerState(BaseModel):
    current_state: int

    @computed_field
    @property
    def state_names(self) -> dict[int, str]:
        return {
            0: "stopped",
            1: "running",
            2: "paused",
        }

    @computed_field
    @property
    def current_state_name(self) -> str:
        return self.state_names[self.current_state]

    @computed_field
    @property
    def is_stopped(self) -> bool:
        return self.current_state == 0

    @computed_field
    @property
    def is_running(self) -> bool:
        return self.current_state == 1

    @computed_field
    @property
    def is_paused(self) -> bool:
        return self.current_state == 2