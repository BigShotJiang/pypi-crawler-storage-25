import dominate

from dominate import tags
from dominate.util import raw
from fastapi import Request

from kicker.models import SchedulerState


def index_page(request: Request, scheduler_state: SchedulerState,
               running_jobs: set, job_runs_counter: dict[str, int],
               version:str, classless_css_framework_url: str) -> str:
    doc = dominate.document(title=f"kicker v{version}", lang="en")
    with doc.head:
        tags.meta(charset="utf-8")
        tags.meta(name="viewport", content="width=device-width, initial-scale=1")
        tags.meta(name="color-scheme", content="light dark")
        tags.link(
            rel="stylesheet",
            href="https://fonts.googleapis.com/css2?family=JetBrains+Mono&display=swap",
        )
        tags.link(
            rel="stylesheet",
            href=classless_css_framework_url,
        )
        # language=CSS
        tags.style().add_raw_string("""
body,
main {
    max-width: none;
    margin: 0;
    padding: 0.5rem;
}
table,
td,
th,
input,
button {font-size: 0.9rem;}
td,
th,
input,
button {padding: 0.25rem 0.5rem;}
li {padding: 0; margin: 0;}""")
        with tags.body(style="font-family: 'JetBrains Mono', monospace;"):
            main_ = tags.main()
            script_ = tags.script(type="text/javascript")

    jobs_execution_list = tags.ul()
    executions_count = 0
    for log in request.app.state.execution_log:
        executions_count += 1
        li_ = tags.li()
        with li_:
            tags.small(log)
        jobs_execution_list += li_

    jobs_table = tags.table()
    for job in request.app.state.scheduler.get_jobs():
        trow = tags.tr()
        with trow:
            tags.td(f"{job.name} ({job_runs_counter[job.id] if job.id in job_runs_counter else 0})")
            with tags.td():
                with tags.form(
                    action=request.url_for("run_job", job_id=job.id).path,
                    method="get",
                    style="display: inline;",
                ):
                    tags.input_(type="submit", value="run", disabled=scheduler_state.is_paused or job.id in running_jobs)
            with tags.td():
                with tags.form(
                    action=request.url_for("pause_job", job_id=job.id).path,
                    method="get",
                    style="display: inline;",
                ):
                    tags.input_(type="submit", value="pause", disabled=scheduler_state.is_paused or not job.next_run_time)
            with tags.td():
                with tags.form(
                    action=request.url_for("resume_job", job_id=job.id).path,
                    method="get",
                    style="display: inline;",
                ):
                    tags.input_(type="submit", value="resume", disabled=scheduler_state.is_paused or job.next_run_time)
            with tags.td(style="min-width: 100px;"):
                tags.small("running" if job.id in running_jobs else "idle")
            with tags.td():
                tags.small(f"next run: {job.next_run_time}")
        jobs_table += trow

    with main_:
        tags.h3(f"scheduler status: {scheduler_state.current_state_name}")
        with tags.form(
                action=request.url_for("start_scheduler").path,
                method="get",
                style="display: inline;"):
            tags.input_(type="submit", value="start scheduler", disabled=scheduler_state.is_running)
    main_ += jobs_table
    frm2 = tags.form(
                action=request.url_for("pause_scheduler").path,
                method="get",
                style="display: inline;")
    with frm2:
        tags.input_(type="submit", value="pause scheduler", disabled=scheduler_state.is_paused)
    main_ += frm2
    main_ += tags.h4(f"job executions ({executions_count})")
    main_ += jobs_execution_list

    with script_:
        # language=JavaScript
        raw(f"""
        setInterval(() => {{
            location.reload()
        }}, {request.app.state.ui_refresh_interval})
        """)
    return doc.render()