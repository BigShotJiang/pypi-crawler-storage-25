import asyncio
import inspect
import logging

from collections import deque
from datetime import datetime
from functools import partial, wraps
from importlib.metadata import version

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.schedulers.base import STATE_STOPPED, STATE_RUNNING, STATE_PAUSED
from apscheduler.events import (
    EVENT_JOB_EXECUTED,
    EVENT_JOB_ERROR,
    EVENT_JOB_SUBMITTED
)
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse

__version__ = version("kicker")

from kicker import html
from kicker.models import SchedulerState


def _wrap_job(func):
    logger = logging.getLogger("kicker")
    inject_logger = 'logger' in inspect.signature(func).parameters

    if inspect.iscoroutinefunction(func):
        if not inject_logger:
            return func
        @wraps(func)
        async def async_wrapper(*args):
            return await func(*args, logger=logger)
        return async_wrapper

    bound = partial(func, logger=logger) if inject_logger else func

    @wraps(func)
    async def wrapper(*args):
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, bound, *args)

    return wrapper

class ExecutionLogHandler(logging.Handler):
    def __init__(self, fast_api: FastAPI) -> None:
        super().__init__()
        self.app = fast_api

    # as far as `_wrap_job` runs sync jobs in a thread pool, `emit()` can be called from different threads.
    # `execution_log` (deque) is thread-safe for appends in CPython, but not guaranteed for all operations or future changes.
    def emit(self, record):
        msg = self.format(record)
        self.app.state.execution_log.appendleft(msg)

class Coworker:
    def __init__(self):
        self._jobs = []

    def kick(self, **schedule):
        def decorator(func):
            self._jobs.append((func, schedule))
            return func
        return decorator


class Kicker(Coworker, FastAPI):
    def __init__(self, root_path: str = "/kicker",
                 debug: bool = False, title: str= "kicker",
                 max_log_length: int = 100, ui_refresh_interval: int = 10000,
                 logger_fmt: str | None = None, **kwargs):
        self._running_jobs = set()
        self._job_runs_counter: dict[str, int] = {}
        Coworker.__init__(self)

        def setup_logging(debug: bool, fast_api: FastAPI):
            logger = logging.getLogger("kicker")
            logger.setLevel(logging.DEBUG if debug else logging.INFO)

            handler = ExecutionLogHandler(fast_api)
            formatter = logging.Formatter(logger_fmt)
            handler.setFormatter(formatter)

            if not any(isinstance(h, ExecutionLogHandler) for h in logger.handlers):
                logger.addHandler(handler)

        def listener(event):
            if event.code == EVENT_JOB_SUBMITTED:
                self._running_jobs.add(event.job_id)
            elif event.code in (EVENT_JOB_EXECUTED, EVENT_JOB_ERROR):
                self._running_jobs.discard(event.job_id)
                if event.code == EVENT_JOB_EXECUTED:
                    if event.job_id in self._job_runs_counter:
                        self._job_runs_counter[event.job_id] += 1
                    else:
                        self._job_runs_counter[event.job_id] = 1

        @asynccontextmanager
        async def lifespan(fast_api: FastAPI):
            fast_api.state.ui_refresh_interval = ui_refresh_interval
            fast_api.state.scheduler = AsyncIOScheduler()
            fast_api.state.scheduler.add_listener(
                listener,
                EVENT_JOB_SUBMITTED | EVENT_JOB_EXECUTED | EVENT_JOB_ERROR
            )
            fast_api.state.scheduler.start(paused=True)
            for func, schedule in self._jobs:
                fast_api.state.scheduler.add_job(_wrap_job(func), 'cron', **schedule, max_instances=1)

            fast_api.state.execution_log = deque(maxlen=max_log_length)
            setup_logging(debug, fast_api)
            yield
            fast_api.state.scheduler.shutdown(wait=False)

        FastAPI.__init__(
            self, debug=debug, title=title, version=__version__, lifespan=lifespan, root_path=root_path, **kwargs,
        )

        self._register_routes()

    def include_coworker(self, coworker: Coworker):
        self._jobs.extend(coworker._jobs)

    def _register_routes(self):
        @self.get("/", name="index", response_class=HTMLResponse)
        async def index(request: Request):
            scheduler = request.app.state.scheduler
            content = html.index_page(
                request,
                SchedulerState(current_state=scheduler.state),
                self._running_jobs,
                self._job_runs_counter,
                __version__,
                "https://cdn.jsdelivr.net/npm/holiday.css@0.11.5")
            return HTMLResponse(content=content, status_code=status.HTTP_200_OK)

        @self.get("/run/{job_id}", name="run_job")
        async def run_job(request: Request, job_id):
            scheduler = request.app.state.scheduler

            job = scheduler.get_job(job_id)
            if job:
                if job.next_run_time is None:
                    #await job.func()
                    scheduler.modify_job(job_id, next_run_time=datetime.now())
                else:
                    scheduler.modify_job(job_id, next_run_time=datetime.now())
            return RedirectResponse(
                url=request.url_for("index"), status_code=status.HTTP_302_FOUND
            )

        @self.get('/pause/{job_id}', name="pause_job")
        async def pause_job(request: Request, job_id):
            scheduler = request.app.state.scheduler

            scheduler.pause_job(job_id)
            return RedirectResponse(
                url=request.url_for("index"), status_code=status.HTTP_302_FOUND
            )

        @self.get('/resume/{job_id}', name="resume_job")
        async def resume_job(request: Request, job_id):
            scheduler = request.app.state.scheduler

            scheduler.resume_job(job_id)
            return RedirectResponse(
                url=request.url_for("index"), status_code=status.HTTP_302_FOUND
            )

        @self.get('/start_scheduler', name="start_scheduler")
        async def start_scheduler(request: Request):
            scheduler = request.app.state.scheduler

            if scheduler.state == STATE_STOPPED:
                scheduler.start()
            else:
                scheduler.resume()
            return RedirectResponse(
                url=request.url_for("index"), status_code=status.HTTP_302_FOUND
            )

        @self.get('/pause_scheduler', name="pause_scheduler")
        async def pause_scheduler(request: Request):
            scheduler = request.app.state.scheduler

            if scheduler.state == STATE_RUNNING:
                scheduler.pause()
            return RedirectResponse(
                url=request.url_for("index"), status_code=status.HTTP_302_FOUND
            )