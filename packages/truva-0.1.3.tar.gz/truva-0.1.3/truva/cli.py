"""Click-based CLI entry point for Truva."""

from __future__ import annotations

from pathlib import Path

import click
import numpy as np
from rich.console import Console

console = Console()


@click.group()
@click.version_option(package_name="truva")
def main() -> None:
    """Truva — Data curation engine for LLM fine-tuning."""


@main.command()
@click.argument("input_path")
@click.option("--provider", default="local", type=click.Choice(["local", "api"]), help="Embedding provider.")
@click.option("--model", default=None, help="Model name. Default: all-MiniLM-L6-v2 (local) or text-embedding-3-small (api).")
@click.option("--text-field", default=None, help="Column/field to embed. Auto-detected if not set.")
@click.option("--format", "input_format", default="auto", help="Input format: auto, jsonl, csv, hf.")
@click.option("--output", "-o", default="./embeddings.npy", help="Output path for embeddings (.npy).")
def embed(
    input_path: str,
    provider: str,
    model: str | None,
    text_field: str | None,
    input_format: str,
    output: str,
) -> None:
    """Compute embeddings for a dataset."""
    from truva.data.loader import load_dataset
    from truva.engines.embedder import compute_embeddings
    from truva.models.embedding import EmbeddingModel

    rows = load_dataset(input_path, format=input_format, text_column=text_field)

    emb_model = EmbeddingModel(provider=provider, model_name=model)
    embeddings = compute_embeddings(rows, model=emb_model, text_field=text_field)

    output_path = Path(output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    np.save(str(output_path), embeddings)

    console.print(f"[green]Saved embeddings[/green] ({embeddings.shape}) to {output_path}")


@main.command()
@click.argument("input_path")
@click.option("--threshold", default=0.95, type=float, help="Cosine similarity threshold (0.0–1.0).")
@click.option("--provider", default="local", type=click.Choice(["local", "api"]), help="Embedding provider.")
@click.option("--model", default=None, help="Embedding model name.")
@click.option("--text-field", default=None, help="Column/field to embed. Auto-detected if not set.")
@click.option("--format", "input_format", default="auto", help="Input format: auto, jsonl, csv, hf.")
@click.option("--output", "-o", default="./deduped.jsonl", help="Output path for deduplicated dataset.")
@click.option("--report", default=None, help="Output path for dedupe report JSON.")
def dedupe(
    input_path: str,
    threshold: float,
    provider: str,
    model: str | None,
    text_field: str | None,
    input_format: str,
    output: str,
    report: str | None,
) -> None:
    """Remove semantic duplicates from a dataset."""
    from truva.data.loader import load_dataset
    from truva.data.writer import write_json_report, write_jsonl
    from truva.engines.deduper import deduplicate
    from truva.engines.embedder import compute_embeddings
    from truva.models.embedding import EmbeddingModel

    rows = load_dataset(input_path, format=input_format, text_column=text_field)

    emb_model = EmbeddingModel(provider=provider, model_name=model)
    embeddings = compute_embeddings(rows, model=emb_model, text_field=text_field)

    result = deduplicate(embeddings, rows, threshold=threshold)

    kept_rows = [rows[i] for i in result.kept_indices]
    write_jsonl(kept_rows, output)

    pct = (1 - len(result.kept_indices) / len(rows)) * 100 if rows else 0
    console.print(
        f"[bold]Dedup:[/bold] {len(rows)} → {len(result.kept_indices)} rows "
        f"([red]-{pct:.1f}%[/red]), {len(result.clusters)} clusters"
    )

    if report:
        report_data = {
            "input_rows": len(rows),
            "kept_rows": len(result.kept_indices),
            "removed_rows": len(result.removed_indices),
            "reduction_pct": round(pct, 2),
            "threshold": threshold,
            "num_clusters": len(result.clusters),
            "clusters": [
                {
                    "representative_idx": c.representative_idx,
                    "size": len(c.member_indices),
                    "avg_similarity": round(c.avg_similarity, 4),
                }
                for c in result.clusters
            ],
        }
        write_json_report(report_data, report)


if __name__ == "__main__":
    main()
