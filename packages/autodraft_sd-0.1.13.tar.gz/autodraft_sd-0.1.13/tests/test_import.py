def test_import_autodraft():
    from autodraft import Autodraft  # noqa: F401


def test_autodraft_class_is_callable():
    from autodraft import Autodraft

    assert callable(Autodraft)


def test_import_does_not_pull_torch(monkeypatch):
    """``import autodraft`` must not transitively import torch."""
    import sys

    for mod in list(sys.modules):
        if mod == "torch" or mod.startswith("torch."):
            sys.modules.pop(mod, None)

    import autodraft  # noqa: F401

    assert "torch" not in sys.modules, (
        "autodraft.__init__ pulled in torch — keep heavy imports inside "
        "local_runner only."
    )


def test_serve_target_is_exported():
    from autodraft import serve_target

    assert callable(serve_target)


def test_serve_target_import_does_not_pull_runtime(monkeypatch):
    """``from autodraft import serve_target`` must stay import-light too."""
    import sys

    for mod in list(sys.modules):
        if (
            mod == "torch"
            or mod.startswith("torch.")
            or mod.startswith("evaluation")
        ):
            sys.modules.pop(mod, None)

    from autodraft import serve_target  # noqa: F401

    assert "torch" not in sys.modules
    assert "evaluation.eval_opt_classic_target" not in sys.modules
