"""Unit tests for autodraft.target_server (lazy-only API)."""

from __future__ import annotations

import sys
import types

import pytest


def _install_fake_target_runtime(monkeypatch, recorder):
    fake_pkg = types.ModuleType("evaluation")
    fake_pkg.__path__ = []
    fake_mod = types.ModuleType("evaluation.eval_opt_classic_target")

    def fake_set_seed(seed):
        recorder["seed"] = seed

    def fake_serve(
        host,
        port,
        base_model_path,
        temperature,
        quantization,
        int8_cpu_offload,
        device_map,
        enable_gpu_monitor=False,
        gpu_monitor_interval=0.1,
        output_file=None,
        fix_gpu_clock=False,
        graphics_clock=None,
        memory_clock=None,
        args=None,
        debug=False,
        model_family="llama2",
        draft_model_path=None,
        preload_model_on_start=False,
    ):
        import os as _os

        recorder["serve_args"] = dict(
            host=host,
            port=port,
            base_model_path=base_model_path,
            temperature=temperature,
            quantization=quantization,
            int8_cpu_offload=int8_cpu_offload,
            device_map=device_map,
            enable_gpu_monitor=enable_gpu_monitor,
            output_file=output_file,
            debug=debug,
            draft_model_path=draft_model_path,
            preload_model_on_start=preload_model_on_start,
        )
        recorder["args_ns_fields"] = vars(args) if args is not None else {}
        recorder["env_at_call"] = {
            "HF_TOKEN": _os.environ.get("HF_TOKEN"),
            "HUGGING_FACE_HUB_TOKEN": _os.environ.get("HUGGING_FACE_HUB_TOKEN"),
        }

    fake_mod.serve = fake_serve
    fake_mod.set_seed = fake_set_seed
    fake_pkg.eval_opt_classic_target = fake_mod
    monkeypatch.setitem(sys.modules, "evaluation", fake_pkg)
    monkeypatch.setitem(sys.modules, "evaluation.eval_opt_classic_target", fake_mod)


def test_serve_target_validates_port(monkeypatch):
    recorder: dict = {}
    _install_fake_target_runtime(monkeypatch, recorder)

    from autodraft import serve_target

    with pytest.raises(ValueError):
        serve_target(port="26001")  # type: ignore[arg-type]


def test_serve_target_lazy_load_passes_no_model(monkeypatch):
    """target_server runs in lazy mode only — base_model_path / draft_model_path
    must be empty/None and preload_model_on_start must be False so the server
    starts without loading anything until the draft sends ``reload_model``."""
    recorder: dict = {}
    _install_fake_target_runtime(monkeypatch, recorder)
    monkeypatch.delenv("HF_TOKEN", raising=False)
    monkeypatch.delenv("HUGGING_FACE_HUB_TOKEN", raising=False)

    from autodraft import serve_target

    serve_target(
        host="0.0.0.0",
        port=26010,
        server_name="autodraft",
        hf_token="hf_test_token",
    )

    serve_args = recorder["serve_args"]
    assert serve_args["host"] == "0.0.0.0"
    assert serve_args["port"] == 26010
    assert serve_args["base_model_path"] == ""
    assert serve_args["draft_model_path"] is None
    assert serve_args["preload_model_on_start"] is False

    assert recorder["env_at_call"]["HF_TOKEN"] == "hf_test_token"
    assert recorder["env_at_call"]["HUGGING_FACE_HUB_TOKEN"] == "hf_test_token"


def test_serve_target_namespace_covers_getattr_fields(monkeypatch):
    """The Namespace must include every field serve() reads via getattr."""
    recorder: dict = {}
    _install_fake_target_runtime(monkeypatch, recorder)

    from autodraft import serve_target

    serve_target(
        server_name="my-server",
        enable_auto_target_profile=False,
        enable_auto_server_draft_profile=False,
    )

    ns = recorder["args_ns_fields"]
    # Fields read via getattr inside serve() (see grep of args.X in eval_opt_classic_target.py).
    for required in [
        "server_name",
        "enable_auto_target_profile",
        "enable_auto_server_draft_profile",
        "base_model_path",
        "temperature",
        "quantization",
        "load_in_8bit",
        "load_in_4bit",
        "enable_gpu_monitor",
        "gpu_monitor_interval",
        "fix_gpu_clock",
        "graphics_clock",
        "memory_clock",
        "device_map",
        "seed",
        "deterministic",
        "debug",
    ]:
        assert required in ns, f"Namespace missing required field: {required}"

    assert ns["server_name"] == "my-server"
    assert ns["enable_auto_target_profile"] is False
    assert ns["enable_auto_server_draft_profile"] is False
    # Lazy mode: never preload, both quant flags off.
    assert ns["load_in_8bit"] is False
    assert ns["load_in_4bit"] is False
    assert ns["base_model_path"] == ""


def test_serve_target_seed_calls_set_seed(monkeypatch):
    recorder: dict = {}
    _install_fake_target_runtime(monkeypatch, recorder)

    from autodraft import serve_target

    serve_target(seed=99)
    assert recorder["seed"] == 99


def test_serve_target_unavailable_when_runtime_missing(monkeypatch):
    monkeypatch.delitem(sys.modules, "evaluation", raising=False)
    monkeypatch.delitem(sys.modules, "evaluation.eval_opt_classic_target", raising=False)

    import builtins

    real_import = builtins.__import__

    def blocking_import(name, *a, **kw):
        if name.startswith("evaluation"):
            raise ImportError("simulated missing target runtime")
        return real_import(name, *a, **kw)

    monkeypatch.setattr(builtins, "__import__", blocking_import)

    from autodraft import serve_target
    from autodraft.errors import LocalRuntimeUnavailableError

    with pytest.raises(LocalRuntimeUnavailableError):
        serve_target()


def test_serve_target_sets_default_data_dir(monkeypatch, tmp_path):
    """Default to ``./data`` (CWD-relative) so caches live with the user's
    project, not in their home directory."""
    recorder: dict = {}
    _install_fake_target_runtime(monkeypatch, recorder)
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("MOBITREE_DATA_DIR", raising=False)

    from autodraft import serve_target

    serve_target()

    expected = tmp_path / "data"
    import os as _os
    assert _os.environ["MOBITREE_DATA_DIR"] == str(expected)
    assert (expected / "profile").is_dir()


def test_serve_target_honors_existing_mobitree_data_dir(monkeypatch, tmp_path):
    recorder: dict = {}
    _install_fake_target_runtime(monkeypatch, recorder)
    custom = tmp_path / "custom-data"
    monkeypatch.setenv("MOBITREE_DATA_DIR", str(custom))

    from autodraft import serve_target

    serve_target()

    import os as _os
    assert _os.environ["MOBITREE_DATA_DIR"] == str(custom)
    assert (custom / "profile").is_dir()


def test_serve_target_extra_kwargs_land_on_namespace(monkeypatch):
    recorder: dict = {}
    _install_fake_target_runtime(monkeypatch, recorder)

    from autodraft import serve_target

    serve_target(new_future_flag="future-value")
    assert recorder["args_ns_fields"]["new_future_flag"] == "future-value"
