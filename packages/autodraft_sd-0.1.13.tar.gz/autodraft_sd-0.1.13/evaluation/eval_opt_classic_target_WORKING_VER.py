import argparse
import json
import os
import socket
import struct
import subprocess
import threading
import time
from datetime import datetime
from typing import List, Tuple
import importlib # added
import torch
from transformers import AutoTokenizer

from opt_classic.kv_cache import initialize_past_key_values
from opt_classic.utils import prepare_logits_processor, recv_json, send_json


def get_kv_llama_class(base_model_path: str):
    """모델 패밀리에 따라 KV 구현 클래스를 선택한다. (LLaMA2/3, Qwen2.5, Qwen3)"""
    model_path_l = (base_model_path or "").lower()
    is_qwen3 = ("qwen3" in model_path_l) or ("qwen-3" in model_path_l)
    is_qwen2 = (not is_qwen3) and (("qwen2" in model_path_l) or ("qwen-2" in model_path_l))
    if is_qwen3:
        module_name, class_name = "opt_classic.modeling_qwen3_kv", "Qwen3ForCausalLM"
    elif is_qwen2:
        module_name, class_name = "opt_classic.modeling_qwen2_kv", "Qwen2ForCausalLM"
    elif "Llama-3." in base_model_path or "llama-3" in model_path_l or "llama3" in model_path_l:
        module_name, class_name = "opt_classic.modeling_llama3_kv", "LlamaForCausalLM"
    else:
        module_name, class_name = "opt_classic.modeling_llama_kv", "LlamaForCausalLM"
    print(f'importing {module_name}.{class_name}')
    try:
        mod = importlib.import_module(module_name)
        return getattr(mod, class_name)
    except Exception as e:
        raise RuntimeError(f"Failed to import {module_name}.{class_name}: {e}")
    





def get_available_gpu_clocks():
    """사용 가능한 GPU 클럭 조합을 반환"""
    try:
        result = subprocess.run([
            'nvidia-smi', 
            '--query-supported-clocks=graphics,memory',
            '--format=csv,noheader,nounits'
        ], capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            clock_combinations = []
            for line in lines:
                if line.strip():
                    parts = line.split(', ')
                    if len(parts) >= 2:
                        graphics = int(parts[0])
                        memory = int(parts[1])
                        clock_combinations.append((graphics, memory))
            return clock_combinations
        else:
            print(f"GPU 클럭 조회 실패: {result.stderr}")
            return []
    except Exception as e:
        print(f"GPU 클럭 조회 중 오류: {e}")
        return []


class GPUMonitor:
    """NVIDIA GPU 메모리와 utilization을 모니터링하는 클래스"""
    
    def __init__(self, interval=0.1, fix_gpu_clock=False, graphics_clock=None, memory_clock=None, debug=False):
        self.interval = interval
        self.monitoring = False
        self.data = []
        self.monitor_thread = None
        self.fix_gpu_clock = fix_gpu_clock
        self.graphics_clock = graphics_clock
        self.memory_clock = memory_clock
        self.original_graphics_clock = None
        self.original_memory_clock = None
        self.debug = debug
        
        if self.fix_gpu_clock:
            self._set_gpu_clocks()
    
    def _set_gpu_clocks(self):
        """GPU 클럭을 고정 설정"""
        try:
            # 현재 클럭 상태 저장
            result = subprocess.run([
                'nvidia-smi', 
                '--query-gpu=clocks.current.graphics,clocks.current.memory',
                '--format=csv,noheader,nounits'
            ], capture_output=True, text=True, timeout=5)
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                if lines and lines[0].strip():
                    parts = lines[0].split(', ')
                    if len(parts) >= 2:
                        self.original_graphics_clock = int(parts[0])
                        self.original_memory_clock = int(parts[1])
                        if self.debug:
                            print(f"[target] 원본 GPU 클럭 저장: Graphics={self.original_graphics_clock}MHz, Memory={self.original_memory_clock}MHz")
            
            # GPU 클럭 설정
            cmd = ['nvidia-smi', '--applications-clocks=']
            if self.graphics_clock is not None:
                cmd[1] += f"{self.graphics_clock}"
            else:
                cmd[1] += "0"  # 기본값
            
            if self.memory_clock is not None:
                cmd[1] += f",{self.memory_clock}"
            else:
                cmd[1] += ",0"  # 기본값
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                if self.debug:
                    print(f"[target] GPU 클럭 고정 설정: Graphics={self.graphics_clock}MHz, Memory={self.memory_clock}MHz")
            else:
                    if self.debug:
                        print(f"[target] GPU 클럭 설정 실패: {result.stderr}")
                
        except Exception as e:
            if self.debug:
                print(f"[target] GPU 클럭 설정 중 오류: {e}")
    
    def _restore_gpu_clocks(self):
        """GPU 클럭을 원래 상태로 복원"""
        try:
            if self.original_graphics_clock is not None and self.original_memory_clock is not None:
                cmd = ['nvidia-smi', '--applications-clocks=default']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                
                if result.returncode == 0:
                    if self.debug:
                        print(f"[target] GPU 클럭 복원 완료")
                else:
                    if self.debug:
                        print(f"[target] GPU 클럭 복원 실패: {result.stderr}")
        except Exception as e:
            if self.debug:
                print(f"[target] GPU 클럭 복원 중 오류: {e}")
    
    def __del__(self):
        """소멸자에서 GPU 클럭 복원"""
        if self.fix_gpu_clock:
            self._restore_gpu_clocks()
        
    def get_gpu_info(self):
        """nvidia-smi를 사용하여 GPU 정보를 가져옵니다"""
        try:
            # nvidia-smi를 사용하여 GPU 정보 가져오기 (클럭 정보 및 파워 포함)
            result = subprocess.run([
                'nvidia-smi', 
                '--query-gpu=index,memory.used,memory.total,utilization.gpu,temperature.gpu,power.draw,power.limit,clocks.current.graphics,clocks.current.memory,clocks.max.graphics,clocks.max.memory',
                '--format=csv,noheader,nounits'
            ], capture_output=True, text=True, timeout=5)
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                gpu_info = []
                for line in lines:
                    if line.strip():
                        parts = line.split(', ')
                        if len(parts) >= 11:
                            gpu_info.append({
                                'gpu_id': int(parts[0]),
                                'memory_used_mb': int(parts[1]),
                                'memory_total_mb': int(parts[2]),
                                'utilization_percent': int(parts[3]),
                                'temperature_c': int(parts[4]),
                                'power_draw_w': float(parts[5]) if parts[5] != '[Not Supported]' and parts[5] != 'N/A' else None,
                                'power_limit_w': float(parts[6]) if parts[6] != '[Not Supported]' and parts[6] != 'N/A' else None,
                                'graphics_clock_mhz': int(parts[7]) if parts[7] != '[Not Supported]' else None,
                                'memory_clock_mhz': int(parts[8]) if parts[8] != '[Not Supported]' else None,
                                'max_graphics_clock_mhz': int(parts[9]) if parts[9] != '[Not Supported]' else None,
                                'max_memory_clock_mhz': int(parts[10]) if parts[10] != '[Not Supported]' else None,
                                'memory_used_percent': (int(parts[1]) / int(parts[2])) * 100 if int(parts[2]) > 0 else 0,
                                'power_usage_percent': (float(parts[5]) / float(parts[6])) * 100 if parts[5] != '[Not Supported]' and parts[6] != '[Not Supported]' and parts[5] != 'N/A' and parts[6] != 'N/A' and float(parts[6]) > 0 else None,
                                'timestamp': time.time()
                            })
                return gpu_info
            else:
                print(f"nvidia-smi 실행 실패: {result.stderr}")
                return self._get_default_gpu_info()
        except Exception as e:
            print(f"GPU 정보 가져오기 실패: {e}")
            return self._get_default_gpu_info()
    
    def _get_default_gpu_info(self):
        """기본 GPU 정보를 반환합니다"""
        return [{
            'gpu_id': 0,
            'memory_used_mb': 0,
            'memory_total_mb': 1,
            'utilization_percent': 0,
            'temperature_c': 0,
            'power_draw_w': None,
            'power_limit_w': None,
            'graphics_clock_mhz': None,
            'memory_clock_mhz': None,
            'max_graphics_clock_mhz': None,
            'max_memory_clock_mhz': None,
            'memory_used_percent': 0,
            'power_usage_percent': None,
            'timestamp': time.time()
        }]
    
    def monitor_loop(self):
        """모니터링 루프"""
        while self.monitoring:
            gpu_info = self.get_gpu_info()
            if gpu_info:
                timestamp = time.time()
                for i, gpu in enumerate(gpu_info):
                    self.data.append({
                        'timestamp': timestamp,
                        'gpu_id': i,
                        **gpu
                    })
            time.sleep(self.interval)
    
    def start_monitoring(self):
        """모니터링 시작"""
        if not self.monitoring:
            self.monitoring = True
            self.data = []
            self.monitor_thread = threading.Thread(target=self.monitor_loop)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()
            # print("[target] GPU 모니터링 시작")
    
    def stop_monitoring(self):
        """모니터링 중지"""
        if self.monitoring:
            self.monitoring = False
            if self.monitor_thread:
                self.monitor_thread.join()
            # print("[target] GPU 모니터링 중지")
    
    def get_stats(self):
        """통계 정보 반환"""
        if not self.data:
            return None
        
        # GPU별로 통계 계산
        gpu_stats = {}
        for entry in self.data:
            gpu_id = entry['gpu_id']
            if gpu_id not in gpu_stats:
                gpu_stats[gpu_id] = {
                    'memory_used_mb': [],
                    'memory_total_mb': [],
                    'utilization_percent': [],
                    'temperature_c': [],
                    'power_draw_w': [],
                    'power_limit_w': [],
                    'power_usage_percent': [],
                    'graphics_clock_mhz': [],
                    'memory_clock_mhz': [],
                    'max_graphics_clock_mhz': [],
                    'max_memory_clock_mhz': [],
                    'memory_used_percent': []
                }
            
            gpu_stats[gpu_id]['memory_used_mb'].append(entry['memory_used_mb'])
            gpu_stats[gpu_id]['memory_total_mb'].append(entry['memory_total_mb'])
            gpu_stats[gpu_id]['utilization_percent'].append(entry['utilization_percent'])
            gpu_stats[gpu_id]['temperature_c'].append(entry['temperature_c'])
            gpu_stats[gpu_id]['memory_used_percent'].append(entry['memory_used_percent'])
            
            # 파워 정보 추가 (None 값 제외)
            if entry['power_draw_w'] is not None:
                gpu_stats[gpu_id]['power_draw_w'].append(entry['power_draw_w'])
            if entry['power_limit_w'] is not None:
                gpu_stats[gpu_id]['power_limit_w'].append(entry['power_limit_w'])
            if entry['power_usage_percent'] is not None:
                gpu_stats[gpu_id]['power_usage_percent'].append(entry['power_usage_percent'])
            
            # 클럭 정보 추가 (None 값 제외)
            if entry['graphics_clock_mhz'] is not None:
                gpu_stats[gpu_id]['graphics_clock_mhz'].append(entry['graphics_clock_mhz'])
            if entry['memory_clock_mhz'] is not None:
                gpu_stats[gpu_id]['memory_clock_mhz'].append(entry['memory_clock_mhz'])
            if entry['max_graphics_clock_mhz'] is not None:
                gpu_stats[gpu_id]['max_graphics_clock_mhz'].append(entry['max_graphics_clock_mhz'])
            if entry['max_memory_clock_mhz'] is not None:
                gpu_stats[gpu_id]['max_memory_clock_mhz'].append(entry['max_memory_clock_mhz'])
        
        # 평균, 최대, 최소 계산
        stats = {}
        for gpu_id, data in gpu_stats.items():
            stats[f'gpu_{gpu_id}'] = {
                'memory_used_mb': {
                    'avg': sum(data['memory_used_mb']) / len(data['memory_used_mb']),
                    'max': max(data['memory_used_mb']),
                    'min': min(data['memory_used_mb'])
                },
                'memory_total_mb': data['memory_total_mb'][0] if data['memory_total_mb'] else 0,  # 총 메모리는 고정값
                'utilization_percent': {
                    'avg': sum(data['utilization_percent']) / len(data['utilization_percent']),
                    'max': max(data['utilization_percent']),
                    'min': min(data['utilization_percent'])
                },
                'temperature_c': {
                    'avg': sum(data['temperature_c']) / len(data['temperature_c']),
                    'max': max(data['temperature_c']),
                    'min': min(data['temperature_c'])
                },
                'memory_used_percent': {
                    'avg': sum(data['memory_used_percent']) / len(data['memory_used_percent']),
                    'max': max(data['memory_used_percent']),
                    'min': min(data['memory_used_percent'])
                }
            }
            
            # 파워 통계 추가 (데이터가 있는 경우만)
            if data['power_draw_w']:
                stats[f'gpu_{gpu_id}']['power_draw_w'] = {
                    'avg': sum(data['power_draw_w']) / len(data['power_draw_w']),
                    'max': max(data['power_draw_w']),
                    'min': min(data['power_draw_w'])
                }
            if data['power_limit_w']:
                stats[f'gpu_{gpu_id}']['power_limit_w'] = data['power_limit_w'][0]  # 파워 한계는 고정값
            if data['power_usage_percent']:
                stats[f'gpu_{gpu_id}']['power_usage_percent'] = {
                    'avg': sum(data['power_usage_percent']) / len(data['power_usage_percent']),
                    'max': max(data['power_usage_percent']),
                    'min': min(data['power_usage_percent'])
                }
            
            # 클럭 정보 통계 (데이터가 있는 경우만)
            if data['graphics_clock_mhz']:
                stats[f'gpu_{gpu_id}']['graphics_clock_mhz'] = {
                    'avg': sum(data['graphics_clock_mhz']) / len(data['graphics_clock_mhz']),
                    'max': max(data['graphics_clock_mhz']),
                    'min': min(data['graphics_clock_mhz'])
                }
            if data['memory_clock_mhz']:
                stats[f'gpu_{gpu_id}']['memory_clock_mhz'] = {
                    'avg': sum(data['memory_clock_mhz']) / len(data['memory_clock_mhz']),
                    'max': max(data['memory_clock_mhz']),
                    'min': min(data['memory_clock_mhz'])
                }
            if data['max_graphics_clock_mhz']:
                stats[f'gpu_{gpu_id}']['max_graphics_clock_mhz'] = data['max_graphics_clock_mhz'][0]  # 최대값은 고정
            if data['max_memory_clock_mhz']:
                stats[f'gpu_{gpu_id}']['max_memory_clock_mhz'] = data['max_memory_clock_mhz'][0]  # 최대값은 고정
        
        return stats
    
    def save_data(self, filename=None):
        """데이터를 JSON 파일로 저장"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"gpu_monitor_{timestamp}.json"
        
        with open(filename, 'w') as f:
            json.dump(self.data, f, indent=2)
        if self.debug:
            print(f"[target] GPU 모니터링 데이터 저장: {filename}")
        return filename


def save_performance_stats(timing_data, gpu_data, output_file, step_count, args=None, accept_lengths=None):
    """성능 통계를 JSON 파일로 저장"""
    if not output_file:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"target_performance_stats_{timestamp}.json"
    
    # 시간 통계 계산
    times = [data["total_time_seconds"] for data in timing_data]
    timing_stats = {
        "count": len(times),
        "min_time_seconds": min(times) if times else 0,
        "max_time_seconds": max(times) if times else 0,
        "avg_time_seconds": sum(times) / len(times) if times else 0,
        "total_time_seconds": sum(times),
        "num_steps": len(times),
        "times": times
    }
    
    # Accept length 통계 계산
    accept_stats = {}
    if accept_lengths:
        accept_stats = {
            "total_accepted_tokens": sum(accept_lengths),
            "avg_accept_length": sum(accept_lengths) / len(accept_lengths) if accept_lengths else 0,
            "min_accept_length": min(accept_lengths) if accept_lengths else 0,
            "max_accept_length": max(accept_lengths) if accept_lengths else 0,
            "num_steps": len(accept_lengths)
        }
    
    # GPU 통계 계산 (있는 경우)
    gpu_summary = {}
    if gpu_data:
        # 모든 GPU 통계를 합쳐서 요약 통계 생성
        all_gpu_stats = {}
        for step_data in gpu_data:
            for gpu_id, stats in step_data["gpu_stats"].items():
                if gpu_id not in all_gpu_stats:
                    all_gpu_stats[gpu_id] = {
                        'memory_used_mb': [],
                        'utilization_percent': [],
                        'temperature_c': [],
                        'memory_used_percent': [],
                        'power_draw_w': [],
                        'power_usage_percent': []
                    }
                
                all_gpu_stats[gpu_id]['memory_used_mb'].extend([stats['memory_used_mb']['avg']])
                all_gpu_stats[gpu_id]['utilization_percent'].extend([stats['utilization_percent']['avg']])
                all_gpu_stats[gpu_id]['temperature_c'].extend([stats['temperature_c']['avg']])
                all_gpu_stats[gpu_id]['memory_used_percent'].extend([stats['memory_used_percent']['avg']])
                
                # 파워 정보 추가 (있는 경우만)
                if 'power_draw_w' in stats:
                    all_gpu_stats[gpu_id]['power_draw_w'].extend([stats['power_draw_w']['avg']])
                if 'power_usage_percent' in stats:
                    all_gpu_stats[gpu_id]['power_usage_percent'].extend([stats['power_usage_percent']['avg']])
        
        # 요약 통계 생성
        for gpu_id, data in all_gpu_stats.items():
            gpu_summary[gpu_id] = {
                'memory_used_mb': {
                    'min': min(data['memory_used_mb']),
                    'max': max(data['memory_used_mb']),
                    'avg': sum(data['memory_used_mb']) / len(data['memory_used_mb'])
                },
                'utilization_percent': {
                    'min': min(data['utilization_percent']),
                    'max': max(data['utilization_percent']),
                    'avg': sum(data['utilization_percent']) / len(data['utilization_percent'])
                },
                'temperature_c': {
                    'min': min(data['temperature_c']),
                    'max': max(data['temperature_c']),
                    'avg': sum(data['temperature_c']) / len(data['temperature_c'])
                },
                'memory_used_percent': {
                    'min': min(data['memory_used_percent']),
                    'max': max(data['memory_used_percent']),
                    'avg': sum(data['memory_used_percent']) / len(data['memory_used_percent'])
                }
            }
            
            # 파워 통계 추가 (데이터가 있는 경우만)
            if data['power_draw_w']:
                gpu_summary[gpu_id]['power_draw_w'] = {
                    'min': min(data['power_draw_w']),
                    'max': max(data['power_draw_w']),
                    'avg': sum(data['power_draw_w']) / len(data['power_draw_w'])
                }
            if data['power_usage_percent']:
                gpu_summary[gpu_id]['power_usage_percent'] = {
                    'min': min(data['power_usage_percent']),
                    'max': max(data['power_usage_percent']),
                    'avg': sum(data['power_usage_percent']) / len(data['power_usage_percent'])
                }
    
    # Experiment info 구성
    experiment_info = {
        "timestamp": datetime.now().isoformat(),
        "total_steps": step_count,
        "description": "Target model verification performance statistics"
    }
    
    # args가 제공되면 추가 정보 포함
    if args:
        experiment_info.update({
            "base_model_path": getattr(args, 'base_model_path', None),
            "temperature": getattr(args, 'temperature', None),
            "quantization": getattr(args, 'quantization', None),
            "load_in_8bit": getattr(args, 'load_in_8bit', False),
            "load_in_4bit": getattr(args, 'load_in_4bit', False),
            "enable_gpu_monitor": getattr(args, 'enable_gpu_monitor', False),
            "gpu_monitor_interval": getattr(args, 'gpu_monitor_interval', 0.1),
            "fix_gpu_clock": getattr(args, 'fix_gpu_clock', False),
            "graphics_clock": getattr(args, 'graphics_clock', None),
            "memory_clock": getattr(args, 'memory_clock', None),
            "device_map": getattr(args, 'device_map', None),
        })
    
    # 최종 데이터 구성
    result_data = {
        "experiment_info": experiment_info,
        "timing_stats": timing_stats,
        "accept_stats": accept_stats if accept_stats else {},
        "gpu_summary": gpu_summary,
        "raw_timing_data": timing_data,
        "raw_gpu_data": gpu_data
    }
    
    # JSON 파일로 저장
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(result_data, f, indent=2, ensure_ascii=False)
    
    # 터미널에 상세 통계 출력 (debug 모드일 때만)
    if args and getattr(args, 'debug', False):
        print("\n" + "="*60)
        print("[target] === 성능 통계 요약 ===")
        print("="*60)
        print(f"총 처리 단계: {step_count}단계")
        print(f"총 처리 시간: {timing_stats['total_time_seconds']:.4f}초")
        print(f"평균 처리 시간: {timing_stats['avg_time_seconds']:.4f}초")
        print(f"최소 처리 시간: {timing_stats['min_time_seconds']:.4f}초")
        print(f"최대 처리 시간: {timing_stats['max_time_seconds']:.4f}초")
        
        # Accept length 통계 출력
        if accept_stats:
            print(f"\n--- Accept Length 통계 ---")
            print(f"총 Accept된 토큰 수: {accept_stats['total_accepted_tokens']}")
            print(f"평균 Accept Length: {accept_stats['avg_accept_length']:.2f}")
            print(f"최소 Accept Length: {accept_stats['min_accept_length']}")
            print(f"최대 Accept Length: {accept_stats['max_accept_length']}")
        
        # GPU 통계 출력 (있는 경우)
        if gpu_summary:
            print("\n--- GPU 사용 통계 ---")
            for gpu_id, stats in gpu_summary.items():
                print(f"{gpu_id}:")
                print(f"  메모리 사용량: {stats['memory_used_mb']['avg']:.1f}MB (평균), {stats['memory_used_mb']['min']:.1f}MB (최소), {stats['memory_used_mb']['max']:.1f}MB (최대)")
                print(f"  메모리 사용률: {stats['memory_used_percent']['avg']:.1f}% (평균), {stats['memory_used_percent']['min']:.1f}% (최소), {stats['memory_used_percent']['max']:.1f}% (최대)")
                print(f"  GPU 활용률: {stats['utilization_percent']['avg']:.1f}% (평균), {stats['utilization_percent']['min']:.1f}% (최소), {stats['utilization_percent']['max']:.1f}% (최대)")
                print(f"  온도: {stats['temperature_c']['avg']:.1f}°C (평균), {stats['temperature_c']['min']:.1f}°C (최소), {stats['temperature_c']['max']:.1f}°C (최대)")
                
                # 파워 정보 출력 (있는 경우만)
                if 'power_draw_w' in stats:
                    print(f"  파워 사용량: {stats['power_draw_w']['avg']:.1f}W (평균), {stats['power_draw_w']['min']:.1f}W (최소), {stats['power_draw_w']['max']:.1f}W (최대)")
                if 'power_limit_w' in stats:
                    print(f"  파워 한계: {stats['power_limit_w']:.1f}W")
                if 'power_usage_percent' in stats:
                    print(f"  파워 사용률: {stats['power_usage_percent']['avg']:.1f}% (평균), {stats['power_usage_percent']['min']:.1f}% (최소), {stats['power_usage_percent']['max']:.1f}% (최대)")
        else:
            print("\n--- GPU 모니터링 비활성화됨 ---")
        
        print("="*60)
        print(f"[target] 성능 통계 저장: {output_file}")
        print("="*60)


class TargetWorker:
    def __init__(self, base_model_path: str, temperature: float, quantization: str = "4bit", int8_cpu_offload: bool = False, device_map: str = "auto", enable_gpu_monitor: bool = False, gpu_monitor_interval: float = 0.1, fix_gpu_clock: bool = False, graphics_clock: int = None, memory_clock: int = None, debug: bool = False, model_family: str = "llama2"):
        # 메모리 분절 방지
        os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
        KVLlamaForCausalLM = get_kv_llama_class(base_model_path)

        self.temperature = temperature
        self.logits_processor = prepare_logits_processor(temperature=temperature) if temperature > 1e-5 else None
        self.enable_gpu_monitor = enable_gpu_monitor
        self.gpu_monitor = None
        self.debug = debug
        
        if self.enable_gpu_monitor:
            self.gpu_monitor = GPUMonitor(
                interval=gpu_monitor_interval,
                fix_gpu_clock=fix_gpu_clock,
                graphics_clock=graphics_clock,
                memory_clock=memory_clock,
                debug=debug
            )

        quantization_config = None
        if quantization == "8bit":
            from transformers import BitsAndBytesConfig
            quantization_config = BitsAndBytesConfig(
                load_in_8bit=True,
                llm_int8_threshold=6.0,
                llm_int8_skip_modules=["lm_head"],
                llm_int8_enable_fp32_cpu_offload=int8_cpu_offload,
            )
        elif quantization == "4bit":
            from transformers import BitsAndBytesConfig
            quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_use_double_quant=True,
            )

        self.base_model = KVLlamaForCausalLM.from_pretrained(
            base_model_path,
            torch_dtype=torch.float16,
            low_cpu_mem_usage=True,
            device_map=device_map,
            quantization_config=quantization_config,
            token="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",
            # token="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",
        )
        self.tokenizer = AutoTokenizer.from_pretrained(
            base_model_path,
            token="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",
            # token="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",
        )

        (
            self.past_key_values,
            self.past_key_values_data,
            self.current_length_data,
        ) = initialize_past_key_values(self.base_model)

    def reset_kv(self):
        self.current_length_data.zero_()

    @torch.inference_mode()
    def handle_init(self, input_ids: List[int]) -> int:
        self.reset_kv()
        ids = torch.tensor([input_ids]).to(self.base_model.lm_head.weight.device)
        outputs = self.base_model.model(
            input_ids=ids,
            past_key_values=self.past_key_values,
        )
        logits = self.base_model.lm_head(outputs[0])
        if self.logits_processor is not None:
            last_logits = logits[:, -1]
            last_logits = self.logits_processor(None, last_logits)
            probs = torch.nn.functional.softmax(last_logits, dim=1)
            next_token = torch.multinomial(probs, 1).item()
        else:
            next_token = torch.argmax(logits[:, -1]).item()
        return next_token

    def _compute_logits(self, draft: torch.Tensor, position_ids: torch.Tensor, tree_mask: torch.Tensor) -> torch.Tensor:
        outputs = self.base_model.model(
            input_ids=draft,
            tree_attention_mask=tree_mask,
            past_key_values=self.past_key_values,
            position_ids=position_ids,
        )
        logits = self.base_model.lm_head(outputs[0])
        return logits

    @torch.inference_mode()
    def handle_tree_step(
        self,
        draft_input_ids: List[int],
        draft_position_ids: List[int],
        tree_attention_mask: List[List[int]],
        parent: List[int],
    ) -> Tuple[List[int], int, int, bool, dict, dict, List[int], int, int]:
        device = self.base_model.lm_head.weight.device

        # 시간 측정 시작
        torch.cuda.synchronize()
        start_time = time.time()

        # GPU 모니터링 시작
        if self.gpu_monitor:
            self.gpu_monitor.start_monitoring()

        draft = torch.tensor([draft_input_ids], device=device, dtype=torch.long)
        position_ids = torch.tensor(draft_position_ids, device=device, dtype=torch.long)
        tree_mask = torch.tensor(tree_attention_mask, device=device, dtype=torch.int8)
        parent_t = torch.tensor(parent, device=device, dtype=torch.long)

        logits = self._compute_logits(draft, position_ids, tree_mask)

        # verify (without calling model.draft)
        if self.logits_processor is None:
            next_tok = torch.argmax(logits, dim=-1)
        else:
            proc_logits = self.logits_processor(None, logits)
            probabilities = torch.nn.functional.softmax(proc_logits, dim=-1)[0]
            next_tok = torch.multinomial(probabilities, 1).view(1, -1)
        next_tok = next_tok.to(draft.device)

        parent_work = torch.where(parent_t == torch.arange(parent_t.size(0), device=parent_t.device), -1, parent_t)
        parent_work = torch.cat([torch.tensor([0], device=parent_t.device), parent_work + 1], dim=-1).to(draft.device)

        correct = torch.where(draft[0] != next_tok[0][parent_work], 0, torch.ones(draft.size(1), device=draft.device))
        correct[0] = 1
        last_sum = torch.sum(correct)
        while True:
            correct = torch.where(correct[parent_work] == 0, 0, correct)
            if torch.sum(correct) == last_sum:
                break
            else:
                last_sum = torch.sum(correct)

        id_t_tensor = torch.argmax(correct * position_ids)
        id_t = int(id_t_tensor.item())
        best_candidate: List[int] = []
        best_ids: List[int] = []
        max_id = id_t
        parent_work[0] = -1
        while id_t != -1:
            token_val = int(draft[0][id_t].item())
            best_candidate.append(token_val)
            best_ids.append(id_t)
            id_t = int(parent_work[id_t].item())

        best_candidate.reverse()
        best_ids.reverse()
        next_token = int(next_tok[0][max_id].item())
        accept_length = len(best_candidate) - 1

        # KV cache 업데이트를 위한 시작 인덱스 계산 (업데이트 전 current_length_data 사용)
        start = int(self.current_length_data[0].item() - draft.size(1))
        base_input_len = int(self.current_length_data[0].item() - draft.size(1))  # 업데이트 전 input_ids 길이
        
        select_indices = (torch.tensor(best_ids, device=device) + start).to(device)

        for data in self.past_key_values_data:
            tgt = data[..., select_indices.to(data.device), :]
            dst = data[..., start: start + tgt.shape[-2], :]
            dst.copy_(tgt, non_blocking=True)
        self.current_length_data.fill_(start + tgt.shape[-2])

        eos_id = self.tokenizer.eos_token_id
        # 원본과 동일하게: best_candidate 전체에서 eos 확인
        # 원본 eval_opt_classic.py Line 766: tokenizer.eos_token_id in input_ids[0, input_len:].tolist()
        # best_candidate는 input_ids에 추가될 토큰들이므로, 전체에서 확인
        eos_reached = eos_id in best_candidate if len(best_candidate) > 0 else False

        # 시간 측정 완료
        torch.cuda.synchronize()
        end_time = time.time()
        total_time = end_time - start_time

        # GPU 모니터링 중지 및 통계 수집
        gpu_stats = None
        if self.gpu_monitor:
            self.gpu_monitor.stop_monitoring()
            gpu_stats = self.gpu_monitor.get_stats()

        # 시간 통계 생성
        timing_stats = {
            "total_time_seconds": total_time,
            "timestamp": datetime.now().isoformat()
        }

        return best_candidate, accept_length, next_token, eos_reached, gpu_stats, timing_stats, best_ids, start, base_input_len

def serve(host: str, port: int, base_model_path: str, temperature: float, quantization: str, int8_cpu_offload: bool, device_map: str, enable_gpu_monitor: bool = False, gpu_monitor_interval: float = 0.1, output_file: str = None, fix_gpu_clock: bool = False, graphics_clock: int = None, memory_clock: int = None, args=None, debug: bool = False, model_family: str = "llama2"):
    # quantization 정보를 args에 추가 (experiment_info에 포함하기 위해)
    if args:
        args.quantization = quantization
    worker = TargetWorker(
        base_model_path=base_model_path,
        temperature=temperature,
        quantization=quantization,
        int8_cpu_offload=int8_cpu_offload,
        device_map=device_map,
        enable_gpu_monitor=enable_gpu_monitor,
        gpu_monitor_interval=gpu_monitor_interval,
        fix_gpu_clock=fix_gpu_clock,
        graphics_clock=graphics_clock,
        memory_clock=memory_clock,
        debug=debug,
        model_family=model_family, # 
    )
    
    # 통계 수집을 위한 변수들
    timing_data = []
    gpu_data = []
    accept_lengths = []  # Accept length 수집
    step_count = 0

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
        s.listen(1)
        # if debug:
        print(f"[target] listening on {host}:{port}")
        conn, addr = s.accept()
        with conn:
            # if debug:
            print(f"[target] connection from {addr}")
            try:
                while True:
                    msg = recv_json(conn)
                    # Draft → Target 전송 시간 측정: Draft가 보낸 메시지를 다 받은 시점
                    target_recv_end_time = time.time()
                    mtype = msg.get("type")
                    if mtype == "init":
                        input_ids = msg["input_ids"]
                        next_token = worker.handle_init(input_ids)
                        target_send_start_time = time.time()
                        send_json(conn, {
                            "type": "init_ok", 
                            "next_token": next_token,
                            "target_recv_end_time": target_recv_end_time,
                            "target_send_start_time": target_send_start_time,
                        })
                    elif mtype == "tree_step":                        
                        best_candidate, accept_length, next_token, eos_reached, gpu_stats, timing_stats, best_ids, kv_start, base_input_len = worker.handle_tree_step(
                            msg["draft_input_ids"],
                            msg["draft_position_ids"],
                            msg["tree_attention_mask"],
                            msg["parent"],
                        )
                        
                        # 통계 데이터 수집
                        step_count += 1
                        timing_data.append(timing_stats)
                        accept_lengths.append(accept_length)  # Accept length 수집
                        if gpu_stats:
                            gpu_data.append({
                                "step": step_count,
                                "timestamp": timing_stats["timestamp"],
                                "gpu_stats": gpu_stats
                            })
                        
                        # Target → Draft 전송 시간 측정: Target이 보내기 시작하는 시점
                        target_send_start_time = time.time()
                        send_json(conn, {
                            "type": "verify_result",
                            "accepted_tokens": best_candidate,
                            "accept_length": accept_length,
                            "next_token": next_token,
                            "eos_reached": eos_reached,
                            "best_ids": best_ids,
                            "base_input_len": base_input_len,
                            "kv_start": kv_start,  # KV cache 업데이트를 위한 시작 인덱스 추가
                            "target_recv_end_time": target_recv_end_time,  # Target이 받은 종료 시간
                            "target_send_start_time": target_send_start_time,  # Target이 보내는 시작 시간
                        })
                    elif mtype == "shutdown":
                        # 통계 데이터 저장
                        if timing_data or gpu_data:
                            save_performance_stats(timing_data, gpu_data, output_file, step_count, args, accept_lengths)
                        send_json(conn, {"type": "bye"})
                        break
                    else:
                        send_json(conn, {"type": "error", "message": f"unknown type {mtype}"})
                        break
            except ConnectionError:
                if debug:
                    print("[target] client disconnected")
                if timing_data or gpu_data:
                    save_performance_stats(timing_data, gpu_data, output_file, step_count, args, accept_lengths)  


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", type=str, default="192.168.0.2")
    parser.add_argument("--port", type=int, default=26001)
    parser.add_argument("--base-model-path", type=str, required=True)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--load-in-8bit", action="store_true")
    parser.add_argument("--load-in-4bit", action="store_true")
    parser.add_argument("--int8-cpu-offload", action="store_true")
    parser.add_argument("--device-map", type=str, default="auto")
    parser.add_argument("--enable-gpu-monitor", action="store_true", default=False,
                       help="GPU 모니터링 활성화")
    parser.add_argument("--gpu-monitor-interval", type=float, default=0.1,
                       help="GPU 모니터링 간격 (초) (기본값: 0.1)")
    parser.add_argument("--output-file", type=str, default=None,
                       help="성능 통계 저장 파일명 (기본값: 자동 생성)")
    parser.add_argument("--fix-gpu-clock", action="store_true", default=False,
                       help="GPU 클럭 고정 활성화")
    parser.add_argument("--graphics-clock", type=int, default=None,
                       help="고정할 그래픽 클럭 (MHz)")
    parser.add_argument("--memory-clock", type=int, default=None,
                       help="고정할 메모리 클럭 (MHz)")
    parser.add_argument("--debug", action="store_true", default=False,
                       help="Enable debug output (TARGET-DEBUG messages)")

    args = parser.parse_args()
    
    # GPU 클럭 고정 옵션이 활성화된 경우 사용 가능한 클럭 조합 출력
    if args.fix_gpu_clock:
        print("=== 사용 가능한 GPU 클럭 조합 ===")
        available_clocks = get_available_gpu_clocks()
        if available_clocks:
            print("Graphics Clock (MHz) | Memory Clock (MHz)")
            print("-" * 40)
            for graphics, memory in available_clocks[:20]:  # 처음 20개만 표시
                print(f"{graphics:>18} | {memory:>15}")
            if len(available_clocks) > 20:
                print(f"... 및 {len(available_clocks) - 20}개 더")
            print("=" * 40)
        else:
            print("GPU 클럭 정보를 가져올 수 없습니다.")
            print("=" * 40)
    
    quantization = "none"
    if args.load_in_8bit:
        quantization = "8bit"
    elif args.load_in_4bit or not args.load_in_8bit:
        # 기본값: 4bit (메모리 절약)
        quantization = "4bit"

    serve(
        args.host,
        args.port,
        args.base_model_path,
        args.temperature,
        quantization,
        args.int8_cpu_offload,
        args.device_map,
        args.enable_gpu_monitor,
        args.gpu_monitor_interval,
        args.output_file,
        args.fix_gpu_clock,
        args.graphics_clock,
        args.memory_clock,
        args=args,  # args 전달하여 experiment_info에 더 많은 정보 포함
        debug=args.debug,
    )


