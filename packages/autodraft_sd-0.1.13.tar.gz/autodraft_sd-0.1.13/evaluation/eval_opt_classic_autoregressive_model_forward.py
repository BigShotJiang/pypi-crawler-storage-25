import argparse
import os
import time

import torch
from tqdm import tqdm

from evaluation import eval_opt_classic_autoregressive as base_ar


@torch.no_grad()
def autoregressive_forward_model(
    input_ids,
    model,
    tokenizer,
    args,
    logits_processor=None,
    max_steps=512,
    past_key_values=None,
):
    """
    model.generate() 대신 KV 모델의 model.model()을 직접 호출해 autoregressive 생성.
    """
    assert input_ids.shape[0] == 1, "Only support batch size 1 for now!!"

    device = input_ids.device
    input_len = input_ids.shape[1]
    max_new_tokens = int(min(max_steps, 1024))

    output_ids = input_ids.clone()

    token_pbar = tqdm(total=max_new_tokens, desc="토큰 생성(model.forward)", unit="token", leave=False)

    if device.type == "cuda":
        torch.cuda.synchronize()
    start_time = time.time()

    # 프롬프트 전체를 먼저 1회 통과시켜 KV 초기화
    seq_len = int(input_ids.shape[1])
    if seq_len <= 0:
        raise RuntimeError("Empty input_ids are not supported.")
    pos_ids = torch.arange(0, seq_len, device=device, dtype=torch.long)
    outputs = model.model(
        input_ids=input_ids,
        position_ids=pos_ids,
        past_key_values=past_key_values,
        return_kv=True,
        is_draft=True,
    )
    past_key_values = outputs[1]
    last_hidden = outputs[0][:, -1, :]
    logits = model.lm_head(last_hidden)

    new_token = 0
    for _ in range(max_new_tokens):
        if logits_processor is None:
            next_token = torch.argmax(logits, dim=-1, keepdim=True)
        else:
            processed_logits = logits_processor(None, logits)
            probs = torch.nn.functional.softmax(processed_logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)

        output_ids = torch.cat([output_ids, next_token.to(output_ids.device)], dim=-1)
        new_token += 1
        token_pbar.update(1)

        if tokenizer.eos_token_id is not None and int(next_token.item()) == int(tokenizer.eos_token_id):
            break

        # 직전 생성 토큰 1개만 넣고 KV를 이어서 계산
        pos_id = torch.tensor([input_len + new_token - 1], device=device, dtype=torch.long)
        outputs = model.model(
            input_ids=next_token.to(device),
            position_ids=pos_id,
            past_key_values=past_key_values,
            return_kv=True,
            is_draft=True,
        )
        past_key_values = outputs[1]
        last_hidden = outputs[0][:, -1, :]
        logits = model.lm_head(last_hidden)

    if device.type == "cuda":
        torch.cuda.synchronize()
    end_time = time.time()

    total_time = max(1e-9, end_time - start_time)
    tokens_per_sec = float(new_token) / total_time

    token_pbar.set_postfix(
        {
            "tokens": new_token,
            "total_length": int(output_ids.shape[1]),
            "tokens/sec": f"{tokens_per_sec:.2f}",
            "total_time": f"{total_time:.3f}s",
        }
    )
    token_pbar.close()

    return output_ids, new_token, new_token - 1, past_key_values


def main():
    # 기존 스크립트의 파이프라인/출력 포맷을 그대로 재사용하고,
    # forward 루프만 model.model 기반으로 치환한다.
    base_ar.autoregressive_forward = autoregressive_forward_model

    parser = argparse.ArgumentParser()
    parser.add_argument("--base-model-path", type=str, required=True, help="Path of target model.")
    parser.add_argument("--load-in-8bit", action="store_true", help="Use 8-bit quantization")
    parser.add_argument("--model-id", type=str, default="llama-2-chat")
    parser.add_argument(
        "--bench-name",
        type=str,
        choices=["mt_bench", "gsm8k"],
        help="The name of the benchmark question set.",
    )
    parser.add_argument("--question-begin", type=int, help="A debug option. The begin index of questions.")
    parser.add_argument("--question-end", type=int, help="A debug option. The end index of questions.")
    parser.add_argument("--answer-file", type=str, help="The output answer file.")
    parser.add_argument("--max-new-token", type=int, default=1024, help="The maximum number of new generated tokens.")
    parser.add_argument("--num-choices", type=int, default=1, help="How many completion choices to generate.")
    parser.add_argument("--num-gpus-per-model", type=int, default=1, help="The number of GPUs per model.")
    parser.add_argument("--num-gpus-total", type=int, default=1, help="The total number of GPUs.")
    parser.add_argument("--max-gpu-memory", type=str, help="Maxmum GPU memory used for model weights per GPU.")
    parser.add_argument("--temperature", type=float, default=0)

    # compatibility args (unused in autoregressive)
    parser.add_argument("--nodes", type=int, default=50, help="Not used in autoregressive mode.")
    parser.add_argument("--threshold", type=float, default=0.5, help="Not used in autoregressive mode.")
    parser.add_argument("--max_depth", type=int, default=10, help="Not used in autoregressive mode.")

    # GPU monitor options
    parser.add_argument("--enable-gpu-monitor", action="store_true", help="Enable GPU monitoring during evaluation")
    parser.add_argument("--gpu-monitor-interval", type=float, default=0.1, help="GPU monitoring interval in seconds")
    parser.add_argument("--output-file", type=str, help="Output file for performance statistics")
    parser.add_argument("--fix-gpu-clock", action="store_true", help="Fix GPU clock to specified values")
    parser.add_argument("--graphics-clock", type=int, help="Graphics clock frequency in MHz")
    parser.add_argument("--memory-clock", type=int, help="Memory clock frequency in MHz")

    args = parser.parse_args()
    print("[eval] using model.model-based autoregressive decoding (no generate())")

    if args.fix_gpu_clock:
        print("=" * 60)
        print("[eval] GPU 클럭 고정 모드")
        print("=" * 60)
        available_clocks = base_ar.get_available_gpu_clocks()
        if available_clocks:
            print("사용 가능한 GPU 클럭 조합 (처음 20개):")
            for i, clock in enumerate(available_clocks[:20]):
                print(f"  {i + 1:2d}. Graphics: {clock['graphics_clock']:4d}MHz, Memory: {clock['memory_clock']:4d}MHz")
            if len(available_clocks) > 20:
                print(f"  ... 총 {len(available_clocks)}개 조합")
        else:
            print("사용 가능한 GPU 클럭 조합을 찾을 수 없습니다.")
        print("=" * 60)

    args.model_id = args.model_id + "-temperature-" + str(args.temperature)
    if args.num_gpus_total // args.num_gpus_per_model > 1:
        if base_ar.ray is not None:
            base_ar.ray.init()
        else:
            print("Warning: Ray is not available. Running on single GPU.")

    if args.bench_name == "mt_bench":
        question_file = f"{base_ar.parent_dir}/data/mt_bench/question.jsonl"
    elif args.bench_name == "gsm8k":
        question_file = f"{base_ar.parent_dir}/data/gsm8k.jsonl"
    else:
        raise ValueError("Undefined bench_name")

    print(f"Output to {args.answer_file}")

    base_ar.run_eval(
        args.base_model_path,
        args.model_id,
        question_file,
        args.question_begin,
        args.question_end,
        args.answer_file,
        args.max_new_token,
        args.num_choices,
        args.num_gpus_per_model,
        args.num_gpus_total,
        args.max_gpu_memory,
        args.temperature,
        args,
        args.enable_gpu_monitor,
        args.gpu_monitor_interval,
        args.output_file,
        args.fix_gpu_clock,
        args.graphics_clock,
        args.memory_clock,
    )

    base_ar.reorg_answer_file(args.answer_file)


if __name__ == "__main__":
    main()

