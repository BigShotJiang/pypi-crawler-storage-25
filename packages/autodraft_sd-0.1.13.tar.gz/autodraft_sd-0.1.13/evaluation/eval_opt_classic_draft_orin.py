"""
Orin 전용 Draft 실행 래퍼.

최신 로직은 `evaluation.eval_opt_classic_draft`를 그대로 사용하고,
GPU 모니터만 Orin(jtop) 환경에 맞게 패치한다.
"""

import importlib
import os
import runpy
import sys
import threading
import time
from typing import Any, Dict, List

import opt_classic.utils as classic_utils


class OrinGPUMonitor(classic_utils.GPUMonitor):
    """Orin(jtop) 전용 GPU 모니터. 실패 시 fallback 없이 즉시 에러 처리."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._jtop_client = None
        self._jtop_class = None
        self._jtop_lock = threading.Lock()
        self._jtop_site_path = "/home/icnlagx/.local/share/jtop/lib/python3.12/site-packages"
        self._monitor_error = None
        self._jtop_last_error = None
        self._jtop_read_retries = 3
        self._jtop_retry_delay_sec = 0.2

    def __del__(self):
        try:
            self._close_jtop_client()
        except Exception:
            pass

    @staticmethod
    def _to_float(value):
        if value is None:
            return None
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            # 숫자/소수점/부호 외 문자 제거 (예: "23.5W", "1200 MHz")
            filtered = "".join(ch for ch in value if (ch.isdigit() or ch in ".-"))
            if not filtered or filtered in {".", "-", "-."}:
                return None
            try:
                return float(filtered)
            except Exception:
                return None
        return None

    @classmethod
    def _search_first_numeric(cls, obj, include_keywords: List[str], exclude_keywords: List[str] = None):
        """
        중첩 dict/list에서 key 이름 기준으로 첫 번째 수치 값을 찾는다.
        - include_keywords: key에 반드시 포함되어야 하는 문자열 후보(소문자 기준)
        - exclude_keywords: key에 포함되면 제외할 문자열 후보(소문자 기준)
        """
        if exclude_keywords is None:
            exclude_keywords = []

        def _walk(node):
            if isinstance(node, dict):
                for k, v in node.items():
                    kl = str(k).lower()
                    if any(ex in kl for ex in exclude_keywords):
                        continue
                    if any(inc in kl for inc in include_keywords):
                        parsed = cls._to_float(v)
                        if parsed is not None:
                            return parsed
                    found = _walk(v)
                    if found is not None:
                        return found
            elif isinstance(node, list):
                for item in node:
                    found = _walk(item)
                    if found is not None:
                        return found
            return None

        return _walk(obj)

    @classmethod
    def _search_max_numeric(cls, obj, include_keywords: List[str], exclude_keywords: List[str] = None):
        """중첩 구조에서 key 이름 조건에 맞는 수치 값의 최댓값을 찾는다."""
        if exclude_keywords is None:
            exclude_keywords = []
        values = []

        def _walk(node):
            if isinstance(node, dict):
                for k, v in node.items():
                    kl = str(k).lower()
                    if any(ex in kl for ex in exclude_keywords):                        continue
                    if any(inc in kl for inc in include_keywords):
                        parsed = cls._to_float(v)
                        if parsed is not None:
                            values.append(parsed)
                    _walk(v)
            elif isinstance(node, list):
                for item in node:
                    _walk(item)

        _walk(obj)
        if values:
            return max(values)
        return None

    @classmethod
    def _extract_power_from_rails(cls, power_obj):
        """
        jtop power.rail에서 GPU rail 전력(mW)과 제한값(mW)을 추출.
        우선순위: gpu/gr3d 포함 rail -> vdd_gpu_soc -> 기타 rail/tot.
        """
        if not isinstance(power_obj, dict):
            return None, None

        rail_map = power_obj.get("rail", {})
        selected_power = None
        selected_limit = None

        def _pick_from_rail(rail_data):
            if not isinstance(rail_data, dict):
                return None, None
            p = cls._to_float(rail_data.get("power"))
            if p is None:
                p = cls._to_float(rail_data.get("avg"))
            lim = cls._to_float(rail_data.get("warn"))
            if lim is None:
                lim = cls._to_float(rail_data.get("crit"))
            return p, lim

        # 1) GPU 관련 rail 우선
        if isinstance(rail_map, dict):
            for rail_name, rail_data in rail_map.items():
                name = str(rail_name).lower()
                if ("gpu" in name) or ("gr3d" in name):
                    p, lim = _pick_from_rail(rail_data)
                    if p is not None:
                        selected_power = p
                        selected_limit = lim
                        break

            # 2) GPU rail을 못 찾으면 SOC/VDD rail 중 최대 power 사용
            if selected_power is None:
                best_p = None
                best_lim = None
                for rail_name, rail_data in rail_map.items():
                    name = str(rail_name).lower()
                    if ("soc" in name) or ("vdd" in name):
                        p, lim = _pick_from_rail(rail_data)
                        if p is not None and (best_p is None or p > best_p):
                            best_p = p
                            best_lim = lim
                if best_p is not None:
                    selected_power = best_p
                    selected_limit = best_lim

            # 3) 그래도 없으면 rail 전체 최댓값
            if selected_power is None:
                best_p = None
                best_lim = None
                for _, rail_data in rail_map.items():
                    p, lim = _pick_from_rail(rail_data)
                    if p is not None and (best_p is None or p > best_p):
                        best_p = p
                        best_lim = lim
                if best_p is not None:
                    selected_power = best_p
                    selected_limit = best_lim

        # 4) 마지막 폴백: total power
        if selected_power is None:
            tot = power_obj.get("tot", {})
            if isinstance(tot, dict):
                selected_power = cls._to_float(tot.get("power"))
                if selected_limit is None:
                    selected_limit = cls._to_float(tot.get("warn")) or cls._to_float(tot.get("crit"))

        return selected_power, selected_limit

    def get_gpu_info(self):
        last_err_detail = None
        for attempt in range(1, int(self._jtop_read_retries) + 1):
            jtop_info = self._get_gpu_info_from_jtop()
            if jtop_info is not None:
                return jtop_info
            last_err_detail = self._jtop_last_error
            # 다음 시도는 client 재생성 경로로 유도
            self._close_jtop_client()
            if attempt < int(self._jtop_read_retries):
                time.sleep(float(self._jtop_retry_delay_sec))
        detail = f" Detail: {last_err_detail}" if last_err_detail else ""
        raise RuntimeError(
            "Orin GPUMonitor: jtop metric collection failed after retries. "
            "nvidia-smi fallback is disabled on Jetson Orin."
            + detail
        )

    @staticmethod
    def _purge_jtop_modules():
        remove_keys = [k for k in list(sys.modules.keys()) if k == "jtop" or k.startswith("jtop.")]
        for key in remove_keys:
            sys.modules.pop(key, None)

    def _import_jtop_class(self):
        import_candidates = [None]
        if os.path.isdir(self._jtop_site_path):
            import_candidates.append(self._jtop_site_path)

        for site_path in import_candidates:
            try:
                if site_path:
                    if site_path not in sys.path:
                        sys.path.insert(0, site_path)
                self._purge_jtop_modules()
                from jtop import jtop  # type: ignore
                return jtop
            except Exception:
                continue
        return None

    def _ensure_jtop_client(self):
        with self._jtop_lock:
            if self._jtop_client is not None:
                try:
                    if self._jtop_client.ok():
                        return True
                except Exception:
                    pass
                self._close_jtop_client_locked()

            if self._jtop_class is None:
                self._jtop_class = self._import_jtop_class()
                if self._jtop_class is None:
                    self._jtop_last_error = "failed to import jtop client module"
                    return False

            try:
                client = self._jtop_class()
                client.start()
                if not client.ok():
                    try:
                        client.close()
                    except Exception:
                        pass
                    self._jtop_last_error = "jtop client started but jetson.ok() is False"
                    return False
                self._jtop_client = client
                self._jtop_last_error = None
                return True
            except Exception as e:
                self._jtop_last_error = repr(e)
                return False

    def _close_jtop_client_locked(self):
        if self._jtop_client is not None:
            try:
                self._jtop_client.close()
            except Exception:
                pass
        self._jtop_client = None

    def _close_jtop_client(self):
        with self._jtop_lock:
            self._close_jtop_client_locked()

    def stop_monitoring(self):
        super().stop_monitoring()
        # step마다 start/stop이 호출되므로 client는 유지한다.
        # (실패 시 _ensure_jtop_client 경로에서 재연결)
        if self._monitor_error is not None:
            err = self._monitor_error
            self._monitor_error = None
            raise RuntimeError(
                "Orin GPUMonitor: jtop monitor loop failed. "
                "nvidia-smi fallback is disabled."
            ) from err

    def start_monitoring(self):
        self._monitor_error = None
        super().start_monitoring()

    def monitor_loop(self):
        """jtop 오류 발생 시 즉시 중단하고 상위 로직에서 종료 처리하도록 에러 저장."""
        while self.monitoring:
            try:
                gpu_info = self.get_gpu_info()
                if gpu_info:
                    timestamp = time.time()
                    for i, gpu in enumerate(gpu_info):
                        self.data.append({
                            "timestamp": timestamp,
                            "gpu_id": i,
                            **gpu,
                        })
                time.sleep(self.interval)
            except Exception as e:
                self._monitor_error = e
                self.monitoring = False
                break

    def _get_gpu_info_from_jtop(self):
        if not self._ensure_jtop_client():
            return None

        try:
            jetson = self._jtop_client
            if jetson is None or not jetson.ok():
                return None

            # RAM shared 값을 GPU 사용 메모리로 간주 (Orin 환경 관례)
            memory_info: Dict[str, Any] = jetson.memory.get("RAM", {})
            memory_used_mb = float(memory_info.get("shared", 0)) / 1000.0
            memory_total_mb = float(memory_info.get("tot", 1)) / 1000.0
            if memory_total_mb <= 0:
                memory_total_mb = 1.0

            gpu_root = jetson.gpu.get("gpu", {})
            gpu_status: Dict[str, Any] = gpu_root.get("status", {})
            gpu_freq: Dict[str, Any] = gpu_root.get("freq", {})
            util = float(gpu_status.get("load", 0))
            graphics_clock = float(gpu_freq.get("cur", 0)) / 1000.0
            max_graphics_clock = float(gpu_freq.get("max", 0)) / 1000.0
            # Orin에서는 memory clock이 별도 GPU 블록에 없을 수 있음
            memory_clock = self._to_float(gpu_freq.get("mem")) or self._to_float(gpu_freq.get("memory"))
            if memory_clock is not None and memory_clock > 20000:
                # Hz로 들어오는 경우를 MHz로 정규화
                memory_clock = memory_clock / 1_000_000.0
            max_memory_clock = self._to_float(gpu_freq.get("max_mem")) or self._to_float(gpu_freq.get("memory_max"))
            if max_memory_clock is not None and max_memory_clock > 20000:
                max_memory_clock = max_memory_clock / 1_000_000.0

            temp_obj = jetson.temperature.get("gpu", {})
            if isinstance(temp_obj, dict):
                temperature = float(temp_obj.get("temp", 0))
            else:
                temperature = float(temp_obj or 0)

            # jtop power 구조에서 GPU rail 관련 값을 최대한 추출
            # (버전별 key naming 차이를 감안해 키워드 기반 탐색)
            power_obj = getattr(jetson, "power", {}) or {}
            power_draw, power_limit = self._extract_power_from_rails(power_obj)

            # rail에서 못 얻은 값은 기존 키워드 탐색으로 보강
            if power_draw is None:
                power_draw = self._search_first_numeric(
                    power_obj,
                    include_keywords=["gpu", "gr3d", "cv", "vdd_gpu", "vdd", "rail"],
                    exclude_keywords=["limit", "cap", "max", "min", "avg"],
                )
            # 위 조건으로 못 찾은 경우, gpu/gr3d가 들어간 값을 우선적으로 다시 탐색
            if power_draw is None:
                power_draw = self._search_first_numeric(
                    power_obj,
                    include_keywords=["gpu", "gr3d"],
                )
            if power_limit is None:
                power_limit = self._search_first_numeric(
                    power_obj,
                    include_keywords=["limit", "cap", "warn", "crit"],
                )
            if power_limit is None:
                # 명시적 제한값이 없으면 power 관련 수치 중 최댓값을 한계값 후보로 사용
                power_limit = self._search_max_numeric(
                    power_obj,
                    include_keywords=["power", "w", "mw", "limit", "cap", "gpu", "gr3d"],
                )

            # mW 단위로 들어올 가능성이 있어 보정
            if power_draw is not None and power_draw > 1000:
                power_draw = power_draw / 1000.0
            if power_limit is not None and power_limit > 1000:
                power_limit = power_limit / 1000.0
            power_usage_percent = None
            if power_draw is not None and power_limit is not None and power_limit > 0:
                power_usage_percent = (power_draw / power_limit) * 100.0

            now = time.time()
            gpu_info: List[Dict[str, Any]] = [{
                "gpu_id": 0,
                "memory_used_mb": memory_used_mb,
                "memory_total_mb": memory_total_mb,
                "utilization_percent": util,
                "temperature_c": temperature,
                "power_draw_w": power_draw,
                "power_limit_w": power_limit,
                "graphics_clock_mhz": graphics_clock,
                "memory_clock_mhz": memory_clock,
                "max_graphics_clock_mhz": max_graphics_clock if max_graphics_clock > 0 else None,
                "max_memory_clock_mhz": max_memory_clock if (max_memory_clock is not None and max_memory_clock > 0) else None,
                "memory_used_percent": (memory_used_mb / memory_total_mb) * 100.0,
                "power_usage_percent": power_usage_percent,
                "timestamp": now,
            }]
            return gpu_info
        except Exception:
            self._jtop_last_error = "failed while reading jtop metrics"
            self._close_jtop_client()
            return None


def _patch_gpu_monitor():
    """최신 draft 모듈 import 전에 GPUMonitor를 Orin 버전으로 교체."""
    classic_utils.GPUMonitor = OrinGPUMonitor


_DRAFT_MODULE = None


def _get_draft_module():
    """draft 모듈 지연 로딩 (OrinGPUMonitor 단독 import를 가볍게 유지)."""
    global _DRAFT_MODULE
    if _DRAFT_MODULE is None:
        _patch_gpu_monitor()
        _DRAFT_MODULE = importlib.import_module("evaluation.eval_opt_classic_draft")
    return _DRAFT_MODULE


def __getattr__(name):
    """
    `from evaluation.eval_opt_classic_draft_orin import run_draft` 호환 유지.
    필요한 심볼 접근 시점에만 draft 모듈을 로딩한다.
    """
    if name.startswith("_"):
        raise AttributeError(name)
    draft_module = _get_draft_module()
    if hasattr(draft_module, name):
        value = getattr(draft_module, name)
        globals()[name] = value
        return value
    raise AttributeError(name)


def _expose_draft_symbols():
    """옵션: draft 모듈 심볼을 즉시 전개하고 싶을 때 사용."""
    _patch_gpu_monitor()
    draft_module = importlib.import_module("evaluation.eval_opt_classic_draft")
    for name in dir(draft_module):
        if name.startswith("_"):
            continue
        globals()[name] = getattr(draft_module, name)


if __name__ == "__main__":
    _patch_gpu_monitor()
    # 최신 draft 스크립트를 그대로 실행하되, GPUMonitor는 Orin 버전이 적용됨.
    runpy.run_module("evaluation.eval_opt_classic_draft", run_name="__main__")
