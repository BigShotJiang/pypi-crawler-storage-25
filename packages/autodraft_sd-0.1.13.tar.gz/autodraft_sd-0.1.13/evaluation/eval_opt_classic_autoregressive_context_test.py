'''
Context Test for Autoregressive Mode
1. infer with model a for mt_bench. then infer with model b
2. infer with model a for 1 token, then infer with model b for 1 token
3. Test modes:
   - single_model: Use one model continuously
   - alternating_models: Alternate between two models for each token
'''

import argparse
import importlib
import json
import os
script_dir = os.path.dirname(__file__)
parent_dir = os.path.dirname(script_dir)
# os.environ["CUDA_VISIBLE_DEVICES"] = "6,7"
import subprocess
import threading
import time
from datetime import datetime

import torch
import shortuuid
from fastchat.llm_judge.common import load_questions
from fastchat.model import get_conversation_template
from tqdm import tqdm

from transformers import AutoTokenizer
from opt_classic.utils import *

# Ray import 추가
try:
    import ray
except ImportError:
    ray = None


DEFAULT_CHAT_SYSTEM_PROMPT = (
    "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  "
    "Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. "
    "Please ensure that your responses are socially unbiased and positive in nature.\n\n"
    "If a question does not make any sense, or is not factually coherent, explain why instead of answering something not correct. "
    "If you don't know the answer to a question, please don't share false information."
)


def get_kv_llama_class(base_model_path: str):
    """Select KV model class by model family (LLaMA2/3, Qwen2.5, Qwen3)."""
    model_path_l = (base_model_path or "").lower()
    is_llama3_family = ("llama-3" in model_path_l) or ("llama3" in model_path_l)
    is_qwen3_family = ("qwen3" in model_path_l) or ("qwen-3" in model_path_l) or ("qwen/qwen3" in model_path_l)
    is_qwen2_family = (not is_qwen3_family) and (
        ("qwen2" in model_path_l) or ("qwen-2" in model_path_l) or ("qwen/qwen2" in model_path_l)
    )

    if is_qwen3_family:
        module_name = "opt_classic.modeling_qwen3_kv"
        class_name = "Qwen3ForCausalLM"
    elif is_qwen2_family:
        module_name = "opt_classic.modeling_qwen2_kv"
        class_name = "Qwen2ForCausalLM"
    elif is_llama3_family:
        module_name = "opt_classic.modeling_llama3_kv"
        class_name = "LlamaForCausalLM"
    else:
        module_name = "opt_classic.modeling_llama_kv"
        class_name = "LlamaForCausalLM"

    print(f"importing {module_name}.{class_name}")
    try:
        mod = importlib.import_module(module_name)
        return getattr(mod, class_name)
    except Exception as e:
        raise RuntimeError(f"Failed to import {module_name}.{class_name}: {e}")


def _build_conversation_template_for_model(model_path: str):
    model_path_l = str(model_path or "").lower()
    if "vicuna" in model_path_l:
        return get_conversation_template("vicuna")
    if ("llama-3" in model_path_l) or ("llama3" in model_path_l):
        for template_name in ("llama-3", "llama3"):
            try:
                return get_conversation_template(template_name)
            except Exception:
                pass
    if "qwen" in model_path_l:
        try:
            return get_conversation_template("chatml")
        except Exception:
            pass
        from fastchat.conversation import Conversation, SeparatorStyle
        return Conversation(
            name="qwen",
            system_template="<|im_start|>system\n{system_message}<|im_end|>",
            system_message="You are a helpful assistant.",
            roles=("<|im_start|>user", "<|im_start|>assistant"),
            sep_style=SeparatorStyle.CHATML,
            sep="<|im_end|>",
            stop_str="<|im_end|>",
        )

    conv = get_conversation_template("llama-2-chat")
    conv.system_message = DEFAULT_CHAT_SYSTEM_PROMPT
    return conv


class GPUMonitor:
    """NVIDIA GPU 메모리와 utilization을 모니터링하는 클래스"""
    
    def __init__(self, interval=0.1, fix_gpu_clock=False, graphics_clock=None, memory_clock=None):
        self.interval = interval
        self.monitoring = False
        self.data = []
        self.monitor_thread = None
        self.fix_gpu_clock = fix_gpu_clock
        self.graphics_clock = graphics_clock
        self.memory_clock = memory_clock
        self.original_graphics_clock = None
        self.original_memory_clock = None
        
        if self.fix_gpu_clock:
            self._set_gpu_clocks()
    
    def _set_gpu_clocks(self):
        """GPU 클럭을 고정 설정"""
        try:
            # 현재 클럭 상태 저장
            result = subprocess.run([
                'nvidia-smi', 
                '--query-gpu=clocks.current.graphics,clocks.current.memory',
                '--format=csv,noheader,nounits'
            ], capture_output=True, text=True, timeout=5)
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                if lines and lines[0].strip():
                    parts = lines[0].split(', ')
                    if len(parts) >= 2:
                        self.original_graphics_clock = int(parts[0])
                        self.original_memory_clock = int(parts[1])
                        print(f"[eval] 원본 GPU 클럭 저장: Graphics={self.original_graphics_clock}MHz, Memory={self.original_memory_clock}MHz")
            
            # GPU 클럭 설정
            cmd = ['nvidia-smi', '--applications-clocks=']
            if self.graphics_clock is not None:
                cmd[1] += f"{self.graphics_clock}"
            else:
                cmd[1] += "0"  # 기본값
            
            if self.memory_clock is not None:
                cmd[1] += f",{self.memory_clock}"
            else:
                cmd[1] += ",0"  # 기본값
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                print(f"[eval] GPU 클럭 고정 설정: Graphics={self.graphics_clock}MHz, Memory={self.memory_clock}MHz")
            else:
                print(f"[eval] GPU 클럭 설정 실패: {result.stderr}")
                
        except Exception as e:
            print(f"[eval] GPU 클럭 설정 중 오류: {e}")
    
    def _restore_gpu_clocks(self):
        """GPU 클럭을 원래 상태로 복원"""
        try:
            if self.original_graphics_clock is not None and self.original_memory_clock is not None:
                cmd = ['nvidia-smi', '--applications-clocks=default']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                
                if result.returncode == 0:
                    print(f"[eval] GPU 클럭 복원 완료")
                else:
                    print(f"[eval] GPU 클럭 복원 실패: {result.stderr}")
        except Exception as e:
            print(f"[eval] GPU 클럭 복원 중 오류: {e}")
    
    def __del__(self):
        """소멸자에서 GPU 클럭 복원"""
        if self.fix_gpu_clock:
            self._restore_gpu_clocks()
        
    def get_gpu_info(self):
        """nvidia-smi를 사용하여 GPU 정보를 가져옵니다"""
        try:
            # nvidia-smi를 사용하여 GPU 정보 가져오기 (클럭 정보 및 파워 포함)
            result = subprocess.run([
                'nvidia-smi', 
                '--query-gpu=index,memory.used,memory.total,utilization.gpu,temperature.gpu,power.draw,power.limit,clocks.current.graphics,clocks.current.memory,clocks.max.graphics,clocks.max.memory',
                '--format=csv,noheader,nounits'
            ], capture_output=True, text=True, timeout=5)
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                gpu_info = []
                for line in lines:
                    if line.strip():
                        parts = line.split(', ')
                        if len(parts) >= 11:
                            gpu_info.append({
                                'gpu_id': int(parts[0]),
                                'memory_used_mb': int(parts[1]),
                                'memory_total_mb': int(parts[2]),
                                'utilization_percent': int(parts[3]),
                                'temperature_c': int(parts[4]),
                                'power_draw_w': float(parts[5]) if parts[5] != '[Not Supported]' and parts[5] != 'N/A' else None,
                                'power_limit_w': float(parts[6]) if parts[6] != '[Not Supported]' and parts[6] != 'N/A' else None,
                                'graphics_clock_mhz': int(parts[7]) if parts[7] != '[Not Supported]' else None,
                                'memory_clock_mhz': int(parts[8]) if parts[8] != '[Not Supported]' else None,
                                'max_graphics_clock_mhz': int(parts[9]) if parts[9] != '[Not Supported]' else None,
                                'max_memory_clock_mhz': int(parts[10]) if parts[10] != '[Not Supported]' else None,
                                'memory_used_percent': (int(parts[1]) / int(parts[2])) * 100 if int(parts[2]) > 0 else 0,
                                'power_usage_percent': (float(parts[5]) / float(parts[6])) * 100 if parts[5] != '[Not Supported]' and parts[6] != '[Not Supported]' and parts[5] != 'N/A' and parts[6] != 'N/A' and float(parts[6]) > 0 else None,
                                'timestamp': time.time()
                            })
                return gpu_info
            else:
                print(f"nvidia-smi 실행 실패: {result.stderr}")
                return self._get_default_gpu_info()
        except Exception as e:
            print(f"GPU 정보 가져오기 실패: {e}")
            return self._get_default_gpu_info()
    
    def _get_default_gpu_info(self):
        """기본 GPU 정보를 반환합니다"""
        return [{
            'gpu_id': 0,
            'memory_used_mb': 0,
            'memory_total_mb': 1,
            'utilization_percent': 0,
            'temperature_c': 0,
            'power_draw_w': None,
            'power_limit_w': None,
            'graphics_clock_mhz': None,
            'memory_clock_mhz': None,
            'max_graphics_clock_mhz': None,
            'max_memory_clock_mhz': None,
            'memory_used_percent': 0,
            'power_usage_percent': None,
            'timestamp': time.time()
        }]
    
    def monitor_loop(self):
        """모니터링 루프"""
        while self.monitoring:
            gpu_info = self.get_gpu_info()
            if gpu_info:
                timestamp = time.time()
                for i, gpu in enumerate(gpu_info):
                    self.data.append({
                        'timestamp': timestamp,
                        'gpu_id': i,
                        **gpu
                    })
            time.sleep(self.interval)
    
    def start_monitoring(self):
        """모니터링 시작"""
        if not self.monitoring:
            self.monitoring = True
            self.data = []
            self.monitor_thread = threading.Thread(target=self.monitor_loop)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()
    
    def stop_monitoring(self):
        """모니터링 중지"""
        if self.monitoring:
            self.monitoring = False
            if self.monitor_thread:
                self.monitor_thread.join()
    
    def get_stats(self):
        """통계 정보 반환"""
        if not self.data:
            return None
        
        # GPU별로 통계 계산
        gpu_stats = {}
        for entry in self.data:
            gpu_id = entry['gpu_id']
            if gpu_id not in gpu_stats:
                gpu_stats[gpu_id] = {
                    'memory_used_mb': [],
                    'memory_total_mb': [],
                    'utilization_percent': [],
                    'temperature_c': [],
                    'power_draw_w': [],
                    'power_limit_w': [],
                    'power_usage_percent': [],
                    'graphics_clock_mhz': [],
                    'memory_clock_mhz': [],
                    'max_graphics_clock_mhz': [],
                    'max_memory_clock_mhz': [],
                    'memory_used_percent': []
                }
            
            gpu_stats[gpu_id]['memory_used_mb'].append(entry['memory_used_mb'])
            gpu_stats[gpu_id]['memory_total_mb'].append(entry['memory_total_mb'])
            gpu_stats[gpu_id]['utilization_percent'].append(entry['utilization_percent'])
            gpu_stats[gpu_id]['temperature_c'].append(entry['temperature_c'])
            gpu_stats[gpu_id]['memory_used_percent'].append(entry['memory_used_percent'])
            
            # 파워 정보 추가 (None 값 제외)
            if entry['power_draw_w'] is not None:
                gpu_stats[gpu_id]['power_draw_w'].append(entry['power_draw_w'])
            if entry['power_limit_w'] is not None:
                gpu_stats[gpu_id]['power_limit_w'].append(entry['power_limit_w'])
            if entry['power_usage_percent'] is not None:
                gpu_stats[gpu_id]['power_usage_percent'].append(entry['power_usage_percent'])
            
            # 클럭 정보 추가 (None 값 제외)
            if entry['graphics_clock_mhz'] is not None:
                gpu_stats[gpu_id]['graphics_clock_mhz'].append(entry['graphics_clock_mhz'])
            if entry['memory_clock_mhz'] is not None:
                gpu_stats[gpu_id]['memory_clock_mhz'].append(entry['memory_clock_mhz'])
            if entry['max_graphics_clock_mhz'] is not None:
                gpu_stats[gpu_id]['max_graphics_clock_mhz'].append(entry['max_graphics_clock_mhz'])
            if entry['max_memory_clock_mhz'] is not None:
                gpu_stats[gpu_id]['max_memory_clock_mhz'].append(entry['max_memory_clock_mhz'])
        
        # 평균, 최대, 최소 계산
        stats = {}
        for gpu_id, data in gpu_stats.items():
            stats[f'gpu_{gpu_id}'] = {
                'memory_used_mb': {
                    'avg': sum(data['memory_used_mb']) / len(data['memory_used_mb']),
                    'max': max(data['memory_used_mb']),
                    'min': min(data['memory_used_mb'])
                },
                'memory_total_mb': data['memory_total_mb'][0] if data['memory_total_mb'] else 0,  # 총 메모리는 고정값
                'utilization_percent': {
                    'avg': sum(data['utilization_percent']) / len(data['utilization_percent']),
                    'max': max(data['utilization_percent']),
                    'min': min(data['utilization_percent'])
                },
                'temperature_c': {
                    'avg': sum(data['temperature_c']) / len(data['temperature_c']),
                    'max': max(data['temperature_c']),
                    'min': min(data['temperature_c'])
                },
                'memory_used_percent': {
                    'avg': sum(data['memory_used_percent']) / len(data['memory_used_percent']),
                    'max': max(data['memory_used_percent']),
                    'min': min(data['memory_used_percent'])
                }
            }
            
            # 파워 통계 추가 (데이터가 있는 경우만)
            if data['power_draw_w']:
                stats[f'gpu_{gpu_id}']['power_draw_w'] = {
                    'avg': sum(data['power_draw_w']) / len(data['power_draw_w']),
                    'max': max(data['power_draw_w']),
                    'min': min(data['power_draw_w'])
                }
            if data['power_limit_w']:
                stats[f'gpu_{gpu_id}']['power_limit_w'] = data['power_limit_w'][0]  # 파워 한계는 고정값
            if data['power_usage_percent']:
                stats[f'gpu_{gpu_id}']['power_usage_percent'] = {
                    'avg': sum(data['power_usage_percent']) / len(data['power_usage_percent']),
                    'max': max(data['power_usage_percent']),
                    'min': min(data['power_usage_percent'])
                }
            
            # 클럭 정보 통계 (데이터가 있는 경우만)
            if data['graphics_clock_mhz']:
                stats[f'gpu_{gpu_id}']['graphics_clock_mhz'] = {
                    'avg': sum(data['graphics_clock_mhz']) / len(data['graphics_clock_mhz']),
                    'max': max(data['graphics_clock_mhz']),
                    'min': min(data['graphics_clock_mhz'])
                }
            if data['memory_clock_mhz']:
                stats[f'gpu_{gpu_id}']['memory_clock_mhz'] = {
                    'avg': sum(data['memory_clock_mhz']) / len(data['memory_clock_mhz']),
                    'max': max(data['memory_clock_mhz']),
                    'min': min(data['memory_clock_mhz'])
                }
            if data['max_graphics_clock_mhz']:
                stats[f'gpu_{gpu_id}']['max_graphics_clock_mhz'] = data['max_graphics_clock_mhz'][0]  # 최대값은 고정
            if data['max_memory_clock_mhz']:
                stats[f'gpu_{gpu_id}']['max_memory_clock_mhz'] = data['max_memory_clock_mhz'][0]  # 최대값은 고정
        
        return stats
    
    def save_data(self, filename=None):
        """데이터를 JSON 파일로 저장"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"gpu_monitor_{timestamp}.json"
        
        with open(filename, 'w') as f:
            json.dump(self.data, f, indent=2)
        print(f"[eval] GPU 모니터링 데이터 저장: {filename}")
        return filename


def extract_model_name(model_path):
    """모델 경로에서 모델 이름 추출 (예: meta-llama/Llama-2-70b-chat-hf -> Llama-2-70b-chat-hf)"""
    if model_path and "/" in model_path:
        return model_path.split("/")[-1]
    return model_path

def calculate_model_timing_stats(model_timing_data, model_name):
    """각 모델별 timing 통계 계산"""
    if model_timing_data:
        total_times = [step['total_time_seconds'] for step in model_timing_data]
        return {
            'model_name': model_name,
            'total_time_seconds': sum(total_times),
            'avg_time_seconds': sum(total_times) / len(total_times),
            'min_time_seconds': min(total_times),
            'max_time_seconds': max(total_times),
            'num_steps': len(total_times)
        }
    else:
        return {
            'model_name': model_name,
            'total_time_seconds': 0,
            'avg_time_seconds': 0,
            'min_time_seconds': 0,
            'max_time_seconds': 0,
            'num_steps': 0
        }

def save_performance_stats(timing_data, gpu_data, detailed_timing_data, output_file, args, total_steps=None, total_new_tokens=None, total_time=None, tokens_per_step=None, tokens_per_second=None, test_mode="single_model", model_usage_stats=None, model_a_timing_data=None, model_b_timing_data=None):
    """성능 통계를 계산하고 JSON 파일로 저장"""
    # 타이밍 통계 계산
    if timing_data:
        total_times = [step['total_time_seconds'] for step in timing_data]
        timing_stats = {
            'total_time_seconds': sum(total_times),
            'avg_time_seconds': sum(total_times) / len(total_times),
            'min_time_seconds': min(total_times),
            'max_time_seconds': max(total_times),
            'num_steps': len(total_times)
        }
    else:
        timing_stats = {
            'total_time_seconds': 0,
            'avg_time_seconds': 0,
            'min_time_seconds': 0,
            'max_time_seconds': 0,
            'num_steps': 0
        }
    
    # GPU 통계 계산 (있는 경우)
    gpu_summary = {}
    if gpu_data:
        # 모든 GPU 통계를 합쳐서 요약 통계 생성
        all_gpu_stats = {}
        for step_data in gpu_data:
            for gpu_id, stats in step_data["gpu_stats"].items():
                if gpu_id not in all_gpu_stats:
                    all_gpu_stats[gpu_id] = {
                        'memory_used_mb': [],
                        'utilization_percent': [],
                        'temperature_c': [],
                        'memory_used_percent': [],
                        'power_draw_w': [],
                        'power_usage_percent': []
                    }
                
                all_gpu_stats[gpu_id]['memory_used_mb'].extend([stats['memory_used_mb']['avg']])
                all_gpu_stats[gpu_id]['utilization_percent'].extend([stats['utilization_percent']['avg']])
                all_gpu_stats[gpu_id]['temperature_c'].extend([stats['temperature_c']['avg']])
                all_gpu_stats[gpu_id]['memory_used_percent'].extend([stats['memory_used_percent']['avg']])
                
                # 파워 정보 추가 (있는 경우만)
                if 'power_draw_w' in stats:
                    all_gpu_stats[gpu_id]['power_draw_w'].extend([stats['power_draw_w']['avg']])
                if 'power_usage_percent' in stats:
                    all_gpu_stats[gpu_id]['power_usage_percent'].extend([stats['power_usage_percent']['avg']])
        
        # 요약 통계 생성
        for gpu_id, data in all_gpu_stats.items():
            gpu_summary[gpu_id] = {
                'memory_used_mb': {
                    'min': min(data['memory_used_mb']),
                    'max': max(data['memory_used_mb']),
                    'avg': sum(data['memory_used_mb']) / len(data['memory_used_mb'])
                },
                'utilization_percent': {
                    'min': min(data['utilization_percent']),
                    'max': max(data['utilization_percent']),
                    'avg': sum(data['utilization_percent']) / len(data['utilization_percent'])
                },
                'temperature_c': {
                    'min': min(data['temperature_c']),
                    'max': max(data['temperature_c']),
                    'avg': sum(data['temperature_c']) / len(data['temperature_c'])
                },
                'memory_used_percent': {
                    'min': min(data['memory_used_percent']),
                    'max': max(data['memory_used_percent']),
                    'avg': sum(data['memory_used_percent']) / len(data['memory_used_percent'])
                }
            }
            
            # 파워 통계 추가 (데이터가 있는 경우만)
            if data['power_draw_w']:
                gpu_summary[gpu_id]['power_draw_w'] = {
                    'min': min(data['power_draw_w']),
                    'max': max(data['power_draw_w']),
                    'avg': sum(data['power_draw_w']) / len(data['power_draw_w'])
                }
            if data['power_usage_percent']:
                gpu_summary[gpu_id]['power_usage_percent'] = {
                    'min': min(data['power_usage_percent']),
                    'max': max(data['power_usage_percent']),
                    'avg': sum(data['power_usage_percent']) / len(data['power_usage_percent'])
                }
    
    # 상세 단계별 통계 계산
    detailed_stats = {}
    if detailed_timing_data:
        # 각 단계별로 시간과 GPU 통계 수집
        step_times = {
            'initialization': [],
            'tree_decoding': [],
            'best_candidate_search': [],
            'past_key_values_update': [],
            'model_draft': [],
            'tensor_cleanup': []
        }
        
        step_gpu_stats = {
            'tree_decoding': [],
            'best_candidate_search': [],
            'past_key_values_update': [],
            'model_draft': []
        }
        
        for data in detailed_timing_data:
            detailed_steps = data.get('detailed_steps', {})
            
            # 초기화 단계
            if 'initialization' in detailed_steps:
                step_times['initialization'].append(detailed_steps['initialization']['time_seconds'])
            
            # 각 스텝별 처리
            for step_key, step_data in detailed_steps.items():
                if step_key.startswith('step_'):
                    step_info = step_data
                    
                    # Tree decoding
                    if 'tree_decoding' in step_info:
                        step_times['tree_decoding'].append(step_info['tree_decoding']['time_seconds'])
                        if step_info['tree_decoding']['gpu_stats']:
                            step_gpu_stats['tree_decoding'].append(step_info['tree_decoding']['gpu_stats'])
                    
                    # Best candidate search
                    if 'best_candidate_search' in step_info:
                        step_times['best_candidate_search'].append(step_info['best_candidate_search']['time_seconds'])
                        if step_info['best_candidate_search']['gpu_stats']:
                            step_gpu_stats['best_candidate_search'].append(step_info['best_candidate_search']['gpu_stats'])
                    
                    # Past key values update
                    if 'past_key_values_update' in step_info:
                        step_times['past_key_values_update'].append(step_info['past_key_values_update']['time_seconds'])
                        if step_info['past_key_values_update']['gpu_stats']:
                            step_gpu_stats['past_key_values_update'].append(step_info['past_key_values_update']['gpu_stats'])
                    
                    # Model draft
                    if 'model_draft' in step_info:
                        step_times['model_draft'].append(step_info['model_draft']['time_seconds'])
                        if step_info['model_draft']['gpu_stats']:
                            step_gpu_stats['model_draft'].append(step_info['model_draft']['gpu_stats'])
                    
                    # Tensor cleanup
                    if 'tensor_cleanup' in step_info:
                        step_times['tensor_cleanup'].append(step_info['tensor_cleanup']['time_seconds'])
        
        # 각 단계별 통계 계산
        for step_name, times in step_times.items():
            if times:
                detailed_stats[step_name] = {
                    'total_time_seconds': sum(times),
                    'avg_time_seconds': sum(times) / len(times),
                    'min_time_seconds': min(times),
                    'max_time_seconds': max(times),
                    'num_calls': len(times)
                }
            else:
                detailed_stats[step_name] = {
                    'total_time_seconds': 0,
                    'avg_time_seconds': 0,
                    'min_time_seconds': 0,
                    'max_time_seconds': 0,
                    'num_calls': 0
                }
        
        # 각 단계별 GPU 통계 계산
        for step_name, gpu_data_list in step_gpu_stats.items():
            if gpu_data_list:
                # GPU 통계 집계 (간단한 평균)
                all_gpu_stats = {}
                for gpu_data in gpu_data_list:
                    for gpu_id, stats in gpu_data.items():
                        if gpu_id not in all_gpu_stats:
                            all_gpu_stats[gpu_id] = {
                                'memory_used_mb': [],
                                'utilization_percent': [],
                                'temperature_c': [],
                                'power_draw_w': [],
                                'power_usage_percent': []
                            }
                        
                        all_gpu_stats[gpu_id]['memory_used_mb'].append(stats['memory_used_mb']['avg'])
                        all_gpu_stats[gpu_id]['utilization_percent'].append(stats['utilization_percent']['avg'])
                        all_gpu_stats[gpu_id]['temperature_c'].append(stats['temperature_c']['avg'])
                        
                        if 'power_draw_w' in stats:
                            all_gpu_stats[gpu_id]['power_draw_w'].append(stats['power_draw_w']['avg'])
                        if 'power_usage_percent' in stats:
                            all_gpu_stats[gpu_id]['power_usage_percent'].append(stats['power_usage_percent']['avg'])
                
                # 평균 계산
                step_gpu_summary = {}
                for gpu_id, data in all_gpu_stats.items():
                    step_gpu_summary[gpu_id] = {
                        'memory_used_mb_avg': sum(data['memory_used_mb']) / len(data['memory_used_mb']),
                        'utilization_percent_avg': sum(data['utilization_percent']) / len(data['utilization_percent']),
                        'temperature_c_avg': sum(data['temperature_c']) / len(data['temperature_c'])
                    }
                    
                    if data['power_draw_w']:
                        step_gpu_summary[gpu_id]['power_draw_w_avg'] = sum(data['power_draw_w']) / len(data['power_draw_w'])
                    if data['power_usage_percent']:
                        step_gpu_summary[gpu_id]['power_usage_percent_avg'] = sum(data['power_usage_percent']) / len(data['power_usage_percent'])
                
                detailed_stats[f'{step_name}_gpu'] = step_gpu_summary


    # 최종 데이터 구성
    result_data = {
        "experiment_info": {
            "timestamp": datetime.now().isoformat(),
            "base_model_path": args.base_model_path,
            "base_model_name": extract_model_name(args.base_model_path),
            "second_model_path": getattr(args, 'second_model_path', None),
            "second_model_name": extract_model_name(getattr(args, 'second_model_path', None)),
            "draft_model_path": None,  # autoregressive 방식에서는 draft model 없음
            "model_id": args.model_id,
            "bench_name": args.bench_name,
            "test_mode": test_mode,
            "nodes": None,  # autoregressive 방식에서는 nodes 없음
            "threshold": None,  # autoregressive 방식에서는 threshold 없음
            "max_depth": None,  # autoregressive 방식에서는 max_depth 없음
            "temperature": args.temperature,
            "load_in_8bit": args.load_in_8bit,
            "enable_gpu_monitor": hasattr(args, 'enable_gpu_monitor') and args.enable_gpu_monitor,
            "gpu_monitor_interval": getattr(args, 'gpu_monitor_interval', 0.1),
            "fix_gpu_clock": getattr(args, 'fix_gpu_clock', False),
            "graphics_clock": getattr(args, 'graphics_clock', None),
            "memory_clock": getattr(args, 'memory_clock', None)
        },
        "timing_stats": timing_stats,
        "detailed_step_stats": detailed_stats,
        "gpu_summary": gpu_summary,
        "generation_stats": {
            "total_steps": total_steps,
            "total_new_tokens": total_new_tokens,
            "total_time_seconds": total_time,
            "tokens_per_step": tokens_per_step,
            "tokens_per_second": tokens_per_second
        },
        "raw_timing_data": timing_data,
        "raw_gpu_data": gpu_data,
        "raw_detailed_timing_data": detailed_timing_data,
        "model_usage_stats": model_usage_stats
    }
    
    # alternating 모드에서 각 모델별 통계 추가
    if test_mode == "alternating_models" and model_a_timing_data is not None and model_b_timing_data is not None:
        model_a_stats = calculate_model_timing_stats(model_a_timing_data, extract_model_name(args.base_model_path))
        model_b_stats = calculate_model_timing_stats(model_b_timing_data, extract_model_name(getattr(args, 'second_model_path', None)))
        
        result_data["model_a_timing_stats"] = model_a_stats
        result_data["model_b_timing_stats"] = model_b_stats
        result_data["raw_model_a_timing_data"] = model_a_timing_data
        result_data["raw_model_b_timing_data"] = model_b_timing_data
    
    # JSON 파일로 저장
    with open(output_file, 'w') as f:
        json.dump(result_data, f, indent=2)
    
    # 터미널에 통계 출력
    print("="*60)
    print("[eval] 성능 통계 요약")
    print("="*60)
    print(f"총 처리 시간: {timing_stats['total_time_seconds']:.4f}초")
    print(f"평균 처리 시간: {timing_stats['avg_time_seconds']:.4f}초")
    print(f"최소 처리 시간: {timing_stats['min_time_seconds']:.4f}초")
    print(f"최대 처리 시간: {timing_stats['max_time_seconds']:.4f}초")
    
    # 생성 통계 출력 (추가된 정보)
    if total_steps is not None and total_new_tokens is not None:
        print(f"총 스텝 수: {total_steps}")
        print(f"총 생성 토큰 수: {total_new_tokens}")
        print(f"스텝당 토큰 수: {tokens_per_step:.2f}")
        print(f"초당 토큰 수: {tokens_per_second:.2f}")
    
    # 모델 사용 통계 출력 (alternating 모드인 경우)
    if test_mode == "alternating_models" and model_usage_stats:
        print(f"\n--- 모델 사용 통계 ---")
        print(f"Model A 사용 횟수: {model_usage_stats['model_a_usage_count']}")
        print(f"Model B 사용 횟수: {model_usage_stats['model_b_usage_count']}")
        total_model_usage = model_usage_stats['model_a_usage_count'] + model_usage_stats['model_b_usage_count']
        
        # 각 모델별 timing 통계 출력
        if model_a_timing_data is not None and model_b_timing_data is not None:
            model_a_stats = calculate_model_timing_stats(model_a_timing_data, extract_model_name(args.base_model_path))
            model_b_stats = calculate_model_timing_stats(model_b_timing_data, extract_model_name(getattr(args, 'second_model_path', None)))
            
            print(f"\n--- {model_a_stats['model_name']} 통계 ---")
            print(f"총 처리 시간: {model_a_stats['total_time_seconds']:.4f}초")
            print(f"평균 처리 시간: {model_a_stats['avg_time_seconds']:.4f}초")
            print(f"최소 처리 시간: {model_a_stats['min_time_seconds']:.4f}초")
            print(f"최대 처리 시간: {model_a_stats['max_time_seconds']:.4f}초")
            print(f"처리 횟수: {model_a_stats['num_steps']}")
            
            print(f"\n--- {model_b_stats['model_name']} 통계 ---")
            print(f"총 처리 시간: {model_b_stats['total_time_seconds']:.4f}초")
            print(f"평균 처리 시간: {model_b_stats['avg_time_seconds']:.4f}초")
            print(f"최소 처리 시간: {model_b_stats['min_time_seconds']:.4f}초")
            print(f"최대 처리 시간: {model_b_stats['max_time_seconds']:.4f}초")
            print(f"처리 횟수: {model_b_stats['num_steps']}")
        if total_model_usage > 0:
            print(f"Model A 사용 비율: {model_usage_stats['model_a_usage_count'] / total_model_usage * 100:.1f}%")
            print(f"Model B 사용 비율: {model_usage_stats['model_b_usage_count'] / total_model_usage * 100:.1f}%")
    
    # 상세 단계별 통계 출력
    if detailed_stats:
        print("\n--- 상세 단계별 통계 ---")
        for step_name, stats in detailed_stats.items():
            if not step_name.endswith('_gpu') and stats['num_calls'] > 0:
                print(f"{step_name}:")
                print(f"  총 시간: {stats['total_time_seconds']:.4f}초")
                print(f"  평균 시간: {stats['avg_time_seconds']:.4f}초")
                print(f"  최소 시간: {stats['min_time_seconds']:.4f}초")
                print(f"  최대 시간: {stats['max_time_seconds']:.4f}초")
                print(f"  호출 횟수: {stats['num_calls']}")
                
                # 해당 단계의 GPU 통계 출력
                gpu_step_name = f"{step_name}_gpu"
                if gpu_step_name in detailed_stats:
                    gpu_stats = detailed_stats[gpu_step_name]
                    print(f"  GPU 사용량:")
                    for gpu_id, gpu_data in gpu_stats.items():
                        print(f"    {gpu_id}:")
                        print(f"      메모리: {gpu_data['memory_used_mb_avg']:.1f}MB")
                        print(f"      활용률: {gpu_data['utilization_percent_avg']:.1f}%")
                        print(f"      온도: {gpu_data['temperature_c_avg']:.1f}°C")
                        if 'power_draw_w_avg' in gpu_data:
                            print(f"      파워: {gpu_data['power_draw_w_avg']:.1f}W")
                        if 'power_usage_percent_avg' in gpu_data:
                            print(f"      파워 사용률: {gpu_data['power_usage_percent_avg']:.1f}%")
                print()
    
    # GPU 통계 출력 (있는 경우)
    if gpu_summary:
        print("\n--- GPU 사용 통계 ---")
        for gpu_id, stats in gpu_summary.items():
            print(f"{gpu_id}:")
            print(f"  메모리 사용량: {stats['memory_used_mb']['avg']:.1f}MB (평균), {stats['memory_used_mb']['min']:.1f}MB (최소), {stats['memory_used_mb']['max']:.1f}MB (최대)")
            print(f"  메모리 사용률: {stats['memory_used_percent']['avg']:.1f}% (평균), {stats['memory_used_percent']['min']:.1f}% (최소), {stats['memory_used_percent']['max']:.1f}% (최대)")
            print(f"  GPU 활용률: {stats['utilization_percent']['avg']:.1f}% (평균), {stats['utilization_percent']['min']:.1f}% (최소), {stats['utilization_percent']['max']:.1f}% (최대)")
            print(f"  온도: {stats['temperature_c']['avg']:.1f}°C (평균), {stats['temperature_c']['min']:.1f}°C (최소), {stats['temperature_c']['max']:.1f}°C (최대)")
            
            # 파워 정보 출력 (있는 경우만)
            if 'power_draw_w' in stats:
                print(f"  파워 사용량: {stats['power_draw_w']['avg']:.1f}W (평균), {stats['power_draw_w']['min']:.1f}W (최소), {stats['power_draw_w']['max']:.1f}W (최대)")
            if 'power_limit_w' in stats:
                print(f"  파워 한계: {stats['power_limit_w']:.1f}W")
            if 'power_usage_percent' in stats:
                print(f"  파워 사용률: {stats['power_usage_percent']['avg']:.1f}% (평균), {stats['power_usage_percent']['min']:.1f}% (최소), {stats['power_usage_percent']['max']:.1f}% (최대)")
    else:
        print("\n--- GPU 모니터링 비활성화됨 ---")
    
    print("="*60)
    print(f"[eval] 성능 통계 저장: {output_file}")
    print("="*60)


def get_available_gpu_clocks():
    """사용 가능한 GPU 클럭 조합을 반환"""
    try:
        result = subprocess.run([
            'nvidia-smi', 
            '--query-supported-clocks=graphics,memory',
            '--format=csv,noheader,nounits'
        ], capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            clock_combinations = []
            for line in lines:
                if line.strip():
                    parts = line.split(', ')
                    if len(parts) >= 2:
                        try:
                            graphics_clock = int(parts[0].strip())
                            memory_clock = int(parts[1].strip())
                            clock_combinations.append({
                                'graphics_clock': graphics_clock,
                                'memory_clock': memory_clock
                            })
                        except ValueError as ve:
                            print(f"클럭 값 파싱 오류: {line} - {ve}")
                            continue
            return clock_combinations
        else:
            print(f"GPU 클럭 조회 실패: {result.stderr}")
            return []
    except Exception as e:
        print(f"GPU 클럭 조회 중 오류: {e}")
        return []


def autoregressive_forward(input_ids, model, tokenizer, args, logits_processor=None, max_steps=None, past_key_values=None):
    """generate 함수를 사용한 간단한 autoregressive 생성"""
    assert input_ids.shape[0] == 1, "Only support batch size 1 for now!!"
    
    input_len = input_ids.shape[1]
    
    # max_steps가 지정되지 않은 경우 args.max_new_token 사용
    if max_steps is None:
        max_steps = args.max_new_token
    
    # Generate parameters 설정
    generation_kwargs = {
        'max_new_tokens': max_steps,  # args.max_new_token 값 사용
        'do_sample': args.temperature > 1e-5,  # temperature가 있으면 sampling
        'temperature': args.temperature if args.temperature > 1e-5 else 1.0,
        'top_k': 10 if args.temperature > 1e-5 else None,
        'top_p': 0.95 if args.temperature > 1e-5 else None,
        'num_return_sequences': 1,
        'eos_token_id': tokenizer.eos_token_id,
        'pad_token_id': tokenizer.pad_token_id if tokenizer.pad_token_id is not None else tokenizer.eos_token_id,
        'use_cache': True,
    }
    
    # Progress bar for generation
    token_pbar = tqdm(total=generation_kwargs['max_new_tokens'], desc="토큰 생성", unit="token", leave=False)
    
    torch.cuda.synchronize()
    start_time = time.time()
    
    # Generate using the model's generate function
    with torch.no_grad():
        output_ids = model.generate(
            input_ids,
            **generation_kwargs
        )
    
    torch.cuda.synchronize()
    end_time = time.time()
    
    # Calculate statistics
    new_token = output_ids.shape[1] - input_len
    total_time = end_time - start_time
    tokens_per_sec = new_token / total_time if total_time > 0 else 0
    
    # Update progress bar
    token_pbar.update(new_token)
    token_pbar.set_postfix({
        'tokens': new_token,
        'total_length': output_ids.shape[1],
        'tokens/sec': f'{tokens_per_sec:.2f}',
        'total_time': f'{total_time:.3f}s'
    })
    token_pbar.close()
    
    # Get past_key_values for potential future use (though not used in this simplified version)
    past_key_values = None
    
    return output_ids, new_token, new_token - 1, past_key_values


def alternating_autoregressive_forward(input_ids, current_model, model_a, model_b, tokenizer, args, logits_processor=None, max_steps=None):
    """매 질문마다 다른 모델을 사용하는 autoregressive 생성"""
    assert input_ids.shape[0] == 1, "Only support batch size 1 for now!!"
    
    input_len = input_ids.shape[1]
    
    # max_steps가 지정되지 않은 경우 args.max_new_token 사용
    if max_steps is None:
        max_steps = args.max_new_token
    
    # Generate parameters 설정
    generation_kwargs = {
        'max_new_tokens': max_steps,  # 전체 시퀀스를 한 번에 생성
        'do_sample': args.temperature > 1e-5,
        'temperature': args.temperature if args.temperature > 1e-5 else 1.0,
        'top_k': 10 if args.temperature > 1e-5 else None,
        'top_p': 0.95 if args.temperature > 1e-5 else None,
        'num_return_sequences': 1,
        'eos_token_id': tokenizer.eos_token_id,
        'pad_token_id': tokenizer.pad_token_id if tokenizer.pad_token_id is not None else tokenizer.eos_token_id,
        'use_cache': True,
    }
    
    # Progress bar for generation
    token_pbar = tqdm(total=max_steps, desc="토큰 생성", unit="token", leave=False)
    
    torch.cuda.synchronize()
    start_time = time.time()
    
    # 현재 모델로 전체 시퀀스 생성
    with torch.no_grad():
        output_ids = current_model.generate(
            input_ids,
            **generation_kwargs
        )
    
    torch.cuda.synchronize()
    end_time = time.time()
    
    # Calculate statistics
    new_token = output_ids.shape[1] - input_len
    total_time = end_time - start_time
    tokens_per_sec = new_token / total_time if total_time > 0 else 0
    
    # Update progress bar
    token_pbar.update(new_token)
    token_pbar.set_postfix({
        'tokens': new_token,
        'total_length': output_ids.shape[1],
        'tokens/sec': f'{tokens_per_sec:.2f}',
        'total_time': f'{total_time:.3f}s',
        'model': 'A' if current_model == model_a else 'B'
    })
    token_pbar.close()
    
    # 모델 사용 기록 (현재 모델 이름을 반환)
    model_name = "model_a" if current_model == model_a else "model_b"
    model_usage = {
        'model_a_usage_count': 1 if current_model == model_a else 0,
        'model_b_usage_count': 1 if current_model == model_b else 0,
        'model_a_total_time': total_time if current_model == model_a else 0.0,
        'model_b_total_time': total_time if current_model == model_b else 0.0
    }
    
    return output_ids, new_token, new_token - 1, model_usage


def run_eval(
        base_model_path,
        model_id,
        question_file,
        question_begin,
        question_end,
        answer_file,
        max_new_token,
        num_choices,
        num_gpus_per_model,
        num_gpus_total,
        max_gpu_memory,
        temperature,
        args,
        enable_gpu_monitor=False,
        gpu_monitor_interval=0.1,
        output_file=None,
        fix_gpu_clock=False,
        graphics_clock=None,
        memory_clock=None,
        test_mode="single_model",
        second_model_path=None,
):
    print("target model: ", base_model_path)
    questions = load_questions(question_file, question_begin, question_end)
    # random shuffle the questions to balance the loading
    # random.shuffle(questions)
    shuffled_ids = [q["question_id"] for q in questions]
    # with open(f"data/{args.bench_name}/model_ids/{args.model_id}.shuffled_ids", "w") as fout:
    #     json.dump(shuffled_ids, fout)

    # Split the question file into `num_gpus` files
    assert num_gpus_total % num_gpus_per_model == 0
    use_ray = num_gpus_total // num_gpus_per_model > 1

    if use_ray and ray is not None:
        get_answers_func = ray.remote(num_gpus=num_gpus_per_model)(
            get_model_answers
        ).remote
    else:
        get_answers_func = get_model_answers

    chunk_size = len(questions) // (num_gpus_total // num_gpus_per_model)  # // 2
    ans_handles = []
    for i in range(0, len(questions), chunk_size):
        ans_handles.append(
            get_answers_func(
                base_model_path,
                model_id,
                questions[i: i + chunk_size],
                answer_file,
                max_new_token,
                num_choices,
                num_gpus_per_model,
                max_gpu_memory,
                temperature,
                args,
                enable_gpu_monitor,
                gpu_monitor_interval,
                output_file,
                fix_gpu_clock,
                graphics_clock,
                memory_clock,
                test_mode,
                second_model_path,
            )
        )

    if use_ray and ray is not None:
        ray.get(ans_handles)


@torch.inference_mode()
def get_model_answers(
        base_model_path,
        model_id,
        questions,
        answer_file,
        max_new_token,
        num_choices,
        num_gpus_per_model,
        max_gpu_memory,
        temperature,
        args,
        enable_gpu_monitor=False,
        gpu_monitor_interval=0.1,
        output_file=None,
        fix_gpu_clock=False,
        graphics_clock=None,
        memory_clock=None,
        test_mode="single_model",
        second_model_path=None,
):
    print("temperature:",temperature)
    print("test_mode:", test_mode)

    # 8-bit quantization 설정 MODIFIED by PJ
    quantization_config = None
    if args.load_in_8bit:
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_8bit=True,
            llm_int8_threshold=6.0,
            llm_int8_skip_modules=["lm_head"],  # lm_head는 원본 precision 유지
        )
    
    # 첫 번째 모델 로드
    KVModelA = get_kv_llama_class(base_model_path)
    model_a = KVModelA.from_pretrained(
        base_model_path,
        torch_dtype=torch.float16,
        # low_cpu_mem_usage=True,
        device_map="auto",
        quantization_config=quantization_config,  # quantization 적용
        token="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"
    )

    # 두 번째 모델 로드 (alternating 모드인 경우)
    model_b = None
    if test_mode == "alternating_models" and second_model_path:
        print(f"Loading second model from: {second_model_path}")
        KVModelB = get_kv_llama_class(second_model_path)
        model_b = KVModelB.from_pretrained(
            second_model_path,
            torch_dtype=torch.float16,
            # low_cpu_mem_usage=True,
            device_map="auto",
            quantization_config=quantization_config,
            token="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"
        )

    tokenizer = AutoTokenizer.from_pretrained(
        base_model_path,
        token="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",
    )

    if temperature > 1e-5:
        logits_processor = prepare_logits_processor(temperature=temperature)
    else:
        logits_processor = None

    model_a.eval()
    print('Check model_a training state:', model_a.training)
    
    if model_b is not None:
        model_b.eval()
        print('Check model_b training state:', model_b.training)

    cuda_visible_devices = os.environ.get('CUDA_VISIBLE_DEVICES')
    print('CUDA VISIBLE DEVICES:', cuda_visible_devices)
    
    
    # 성능 데이터 수집용 변수들
    timing_data = []
    gpu_data = []
    detailed_timing_data = []  # 상세 단계별 타이밍 데이터

    question = questions[0]
    alternating_question_idx = 0

    # warmup
    for _ in range(3):
        torch.manual_seed(0)

        conv = _build_conversation_template_for_model(base_model_path)
        turns = []
        idxs = []
        new_tokens = []
        wall_time = []
        if args.bench_name=="gsm8k":
            question_turns=[question["question"]]
        else:
            question_turns=question["turns"]
        for j in range(len(question_turns)):
            qs = question_turns[j]
            conv.append_message(conv.roles[0], qs)
            conv.append_message(conv.roles[1], None)
            prompt = conv.get_prompt() + " "
            input_ids = tokenizer([prompt]).input_ids

            # try:
            torch.cuda.synchronize()
            start_time = time.time()

            if test_mode == "single_model":
                output_ids, new_token, idx, _ = autoregressive_forward(
                    torch.as_tensor(input_ids).cuda(),
                    model_a,
                    tokenizer,
                    args,
                    logits_processor
                )
            elif test_mode == "alternating_models" and model_b is not None:
                # 매 질문마다 다른 모델 사용 (짝수 질문은 model_a, 홀수 질문은 model_b)
                current_model = model_a if alternating_question_idx % 2 == 0 else model_b
                output_ids, new_token, idx, model_usage = alternating_autoregressive_forward(
                    torch.as_tensor(input_ids).cuda(),
                    current_model,  # 현재 질문에 사용할 모델
                    model_a,
                    model_b,
                    tokenizer,
                    args,
                    logits_processor
                )
                alternating_question_idx += 1
            else:
                raise ValueError(f"Invalid test_mode: {test_mode}")
                
            torch.cuda.synchronize()
            total_time = time.time() - start_time
            output_ids = output_ids[0][len(input_ids[0]):]
            # be consistent with the template's stop_token_ids
            if conv.stop_token_ids:
                stop_token_ids_index = [
                    i
                    for i, id in enumerate(output_ids)
                    if id in conv.stop_token_ids
                ]
                if len(stop_token_ids_index) > 0:
                    output_ids = output_ids[: stop_token_ids_index[0]]

            output = tokenizer.decode(
                output_ids,
                spaces_between_special_tokens=False,
            )
            conv.stop_str = "</s>"
            if conv.stop_str and output.find(conv.stop_str) > 0:
                output = output[: output.find(conv.stop_str)]
            for special_token in tokenizer.special_tokens_map.values():
                if isinstance(special_token, list):
                    for special_tok in special_token:
                        output = output.replace(special_tok, "")
                else:
                    output = output.replace(special_token, "")
            output = output.strip()

            if conv.name == "xgen" and output.startswith("Assistant:"):
                output = output.replace("Assistant:", "", 1).strip()

            turns.append(output)
            idxs.append(int(idx))
            new_tokens.append(int(new_token))
            wall_time.append(total_time)
            conv.messages[-1][-1] = output
    print('Warmup done')

    # GPU 모니터 초기화
    gpu_monitor = None
    if enable_gpu_monitor:
        gpu_monitor = GPUMonitor(
            interval=gpu_monitor_interval,
            fix_gpu_clock=fix_gpu_clock,
            graphics_clock=graphics_clock,
            memory_clock=memory_clock
        )
        gpu_monitor.start_monitoring()
        print(f"[eval] GPU 모니터링 시작 (간격: {gpu_monitor_interval}초)")


    # questions=questions[6:]
    total_steps = 0
    total_new_tokens=0
    all_time=0
    total_accept_length=0
    total_tree_length_sum=0
    c=0
    
    # 모델 사용 통계 (alternating 모드용)
    model_usage_stats = {
        "model_a_usage_count": 0,
        "model_b_usage_count": 0,
        "model_a_total_time": 0.0,
        "model_b_total_time": 0.0
    }
    
    # 각 모델별 timing 데이터 (alternating 모드용)
    model_a_timing_data = []
    model_b_timing_data = []
    for question_idx, question in enumerate(tqdm(questions)):

        choices = []
        for i in range(num_choices):
            torch.manual_seed(i)
            conv = _build_conversation_template_for_model(base_model_path)
            turns = []
            idxs = []
            new_tokens = []
            wall_time = []
            if args.bench_name == "gsm8k":
                question_turns = [question["question"]]
            else:
                question_turns = question["turns"]

            for j in range(len(question_turns)):
                qs = question_turns[j]
                conv.append_message(conv.roles[0], qs)
                conv.append_message(conv.roles[1], None)
                prompt = conv.get_prompt() + " "
                input_ids = tokenizer([prompt]).input_ids

                try:
                    torch.cuda.synchronize()
                    start_time = time.time()
                    
                    # 상세 타이밍 데이터 수집용 딕셔너리
                    detailed_timing = {}
                    
                    # 테스트 모드에 따른 추론 실행
                    used_model_name = None
                    if test_mode == "single_model":
                        output_ids, new_token, idx, _ = autoregressive_forward(
                            torch.as_tensor(input_ids).cuda(),
                            model_a,
                            tokenizer,
                            args,
                            logits_processor
                        )
                        used_model_name = extract_model_name(args.base_model_path)
                    elif test_mode == "alternating_models" and model_b is not None:
                        # 매 질문마다 다른 모델 사용 (짝수 질문은 model_a, 홀수 질문은 model_b)
                        current_model = model_a if question_idx % 2 == 0 else model_b
                        current_model_name = "model_a" if question_idx % 2 == 0 else "model_b"
                        
                        # 사용된 모델의 실제 이름 추출
                        if current_model_name == "model_a":
                            used_model_name = extract_model_name(args.base_model_path)
                        else:
                            used_model_name = extract_model_name(getattr(args, 'second_model_path', None))
                        
                        output_ids, new_token, idx, model_usage = alternating_autoregressive_forward(
                            torch.as_tensor(input_ids).cuda(),
                            current_model,
                            model_a,
                            model_b,
                            tokenizer,
                            args,
                            logits_processor
                        )
                        # 모델 사용 통계 수집
                        model_usage_stats["model_a_usage_count"] += model_usage['model_a_usage_count']
                        model_usage_stats["model_b_usage_count"] += model_usage['model_b_usage_count']
                        model_usage_stats["model_a_total_time"] += model_usage['model_a_total_time']
                        model_usage_stats["model_b_total_time"] += model_usage['model_b_total_time']
                    else:
                        raise ValueError(f"Invalid test_mode: {test_mode}")
                    c+=1
                    
                    torch.cuda.synchronize()
                    total_time = time.time() - start_time
                    
                    # 상세 타이밍 데이터 저장
                    detailed_timing_data.append({
                        "question_id": question["question_id"],
                        "choice_index": i,
                        "turn_index": j,
                        "total_time_seconds": total_time,
                        "detailed_steps": detailed_timing,
                        "timestamp": time.time()
                    })
                    
                    # 전체 GPU 통계 수집 (기존 방식 유지)
                    if gpu_monitor:
                        gpu_stats = gpu_monitor.get_stats()
                        if gpu_stats:
                            gpu_data.append({
                                "question_id": question["question_id"],
                                "choice_index": i,
                                "turn_index": j,
                                "gpu_stats": gpu_stats
                            })
                    
                    # 전체 타이밍 데이터 수집 (기존 방식 유지)
                    timing_data.append({
                        "question_id": question["question_id"],
                        "choice_index": i,
                        "turn_index": j,
                        "total_time_seconds": total_time,
                        "timestamp": time.time()
                    })
                    
                    # alternating 모드에서 각 모델별 timing 데이터 수집
                    if test_mode == "alternating_models" and model_b is not None:
                        model_timing_entry = {
                            "question_id": question["question_id"],
                            "choice_index": i,
                            "turn_index": j,
                            "total_time_seconds": total_time,
                            "timestamp": time.time(),
                            "used_model_name": used_model_name
                        }
                        
                        if used_model_name == extract_model_name(args.base_model_path):
                            model_a_timing_data.append(model_timing_entry)
                        else:
                            model_b_timing_data.append(model_timing_entry)
                    output_ids = output_ids[0][len(input_ids[0]):]

                    if conv.stop_token_ids:
                        stop_token_ids_index = [
                            i
                            for i, id in enumerate(output_ids)
                            if id in conv.stop_token_ids
                        ]
                        if len(stop_token_ids_index) > 0:
                            output_ids = output_ids[: stop_token_ids_index[0]]

                    output = tokenizer.decode(
                        output_ids,
                        spaces_between_special_tokens=False,
                    )
                    if conv.stop_str and output.find(conv.stop_str) > 0:
                        output = output[: output.find(conv.stop_str)]
                    for special_token in tokenizer.special_tokens_map.values():
                        if isinstance(special_token, list):
                            for special_tok in special_token:
                                output = output.replace(special_tok, "")
                        else:
                            output = output.replace(special_token, "")
                    output = output.strip()

                    if conv.name == "xgen" and output.startswith("Assistant:"):
                        output = output.replace("Assistant:", "", 1).strip()
                except RuntimeError as e:
                    print("ERROR question ID: ", question["question_id"])
                    output = "ERROR"

                turns.append(output)
                idxs.append(int(idx))
                total_steps+=int(idx)
                new_tokens.append(int(new_token))
                total_new_tokens+=int(new_token)
                wall_time.append(total_time)
                all_time+=total_time
                conv.messages[-1][-1] = output
            # torch.cuda.empty_cache()
            choices.append({"index": i, "turns": turns, "idxs": idxs, "new_tokens": new_tokens, "wall_time": wall_time})



        # Dump answers
        os.makedirs(os.path.dirname(answer_file), exist_ok=True)
        with open(os.path.expanduser(answer_file), "a") as fout:
            ans_json = {
                "question_id": question["question_id"],
                "answer_id": shortuuid.uuid(),
                "model_id": model_id,
                "used_model_name": used_model_name,  # 사용된 모델 이름 추가
                "choices": choices,
                "tstamp": time.time(),
            }
            fout.write(json.dumps(ans_json) + "\n")

    # 추가 통계 계산
    tokens_per_step = total_new_tokens / total_steps if total_steps > 0 else 0
    tokens_per_second = total_new_tokens / all_time if all_time > 0 else 0
    
    print("total_steps:",total_steps," | total_new_tokens:",total_new_tokens," | total_time:",round(all_time,2)," | tokens per step:",round(tokens_per_step,2)," | tokens per second:",round(tokens_per_second,2))
    
    # 성능 통계 저장
    if output_file:
        save_performance_stats(timing_data, gpu_data, detailed_timing_data, output_file, args, total_steps, total_new_tokens, all_time, tokens_per_step, tokens_per_second, test_mode, model_usage_stats, model_a_timing_data, model_b_timing_data)
    
    # GPU 모니터 정리
    if gpu_monitor:
        gpu_monitor.stop_monitoring()
        del gpu_monitor


def reorg_answer_file(answer_file):
    """Sort by question id and de-duplication"""
    answers = {}
    with open(answer_file, "r") as fin:
        for l in fin:
            qid = json.loads(l)["question_id"]
            answers[qid] = l

    qids = sorted(list(answers.keys()))
    with open(answer_file, "w") as fout:
        for qid in qids:
            fout.write(answers[qid])


if __name__ == "__main__":
    """Argument Parser + Run Evaluation"""
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-model-path", type=str, required=True,help="Path of target model.")
    parser.add_argument(
        "--load-in-8bit", action="store_true", help="Use 8-bit quantization"
    )
    parser.add_argument("--model-id", type=str, default="llama-2-chat")
    parser.add_argument(
        "--bench-name",
        type=str,
        choices=["mt_bench","gsm8k"],
        help="The name of the benchmark question set.",
    )
    parser.add_argument(
        "--question-begin",
        type=int,
        help="A debug option. The begin index of questions.",
    )
    parser.add_argument(
        "--question-end", type=int, help="A debug option. The end index of questions."
    )
    parser.add_argument("--answer-file", type=str, help="The output answer file.")
    parser.add_argument(
        "--max-new-token",
        type=int,
        default=10,
        help="The maximum number of new generated tokens.",
    )
    parser.add_argument(
        "--num-choices",
        type=int,
        default=1,
        help="How many completion choices to generate.",
    )
    parser.add_argument(
        "--num-gpus-per-model",
        type=int,
        default=1,
        help="The number of GPUs per model.",
    )
    parser.add_argument(
        "--num-gpus-total", type=int, default=1, help="The total number of GPUs."
    )
    parser.add_argument(
        "--max-gpu-memory",
        type=str,
        help="Maxmum GPU memory used for model weights per GPU.",
    )

    parser.add_argument(
        "--temperature",
        type=float,
        default=0,
    )

    # Autoregressive config (nodes, threshold, max_depth are not used in autoregressive mode)
    # These parameters are kept for compatibility with existing scripts but are ignored
    parser.add_argument(
        "--nodes", 
        type=int, 
        default=50,
        help="Number of nodes (not used in autoregressive mode).",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.5,
        help="Threshold (not used in autoregressive mode).",
    )
    parser.add_argument(
        "--max_depth",
        type=int,
        default=10,
        help="Max depth (not used in autoregressive mode).",
    )
    
    # GPU 모니터링 관련 인수들
    parser.add_argument(
        "--enable-gpu-monitor",
        action="store_true",
        help="Enable GPU monitoring during evaluation"
    )
    parser.add_argument(
        "--gpu-monitor-interval",
        type=float,
        default=0.1,
        help="GPU monitoring interval in seconds"
    )
    parser.add_argument(
        "--output-file",
        type=str,
        help="Output file for performance statistics"
    )
    parser.add_argument(
        "--fix-gpu-clock",
        action="store_true",
        help="Fix GPU clock to specified values"
    )
    parser.add_argument(
        "--graphics-clock",
        type=int,
        help="Graphics clock frequency in MHz"
    )
    parser.add_argument(
        "--memory-clock",
        type=int,
        help="Memory clock frequency in MHz"
    )
    
    # 테스트 모드 관련 인수들
    parser.add_argument(
        "--test-mode",
        type=str,
        choices=["single_model", "alternating_models"],
        default="single_model",
        help="Test mode: single_model (use one model continuously) or alternating_models (alternate between two models)"
    )
    parser.add_argument(
        "--second-model-path",
        type=str,
        help="Path to the second model (required for alternating_models mode)"
    )

    args = parser.parse_args()

    # 테스트 모드 검증
    if args.test_mode == "alternating_models" and not args.second_model_path:
        raise ValueError("--second-model-path is required when using alternating_models mode")

    # GPU 클럭 고정 옵션 표시
    if args.fix_gpu_clock:
        print("="*60)
        print("[eval] GPU 클럭 고정 모드")
        print("="*60)
        available_clocks = get_available_gpu_clocks()
        if available_clocks:
            print("사용 가능한 GPU 클럭 조합 (처음 20개):")
            for i, clock in enumerate(available_clocks[:20]):
                print(f"  {i+1:2d}. Graphics: {clock['graphics_clock']:4d}MHz, Memory: {clock['memory_clock']:4d}MHz")
            if len(available_clocks) > 20:
                print(f"  ... 총 {len(available_clocks)}개 조합")
        else:
            print("사용 가능한 GPU 클럭 조합을 찾을 수 없습니다.")
        print("="*60)

    args.model_id = args.model_id + "-temperature-" + str(args.temperature)
    if args.num_gpus_total // args.num_gpus_per_model > 1:
        if ray is not None:
            ray.init()
        else:
            print("Warning: Ray is not available. Running on single GPU.")
    if args.bench_name=="mt_bench":
        question_file = f"{parent_dir}/data/mt_bench/question.jsonl"
    elif args.bench_name=="gsm8k":
        question_file = f"{parent_dir}/data/gsm8k.jsonl"
    else:
        raise ValueError("Undefined bench_name")

    print(f"Output to {args.answer_file}")

    run_eval(
        args.base_model_path,
        args.model_id,
        question_file,
        args.question_begin,
        args.question_end,
        args.answer_file,
        args.max_new_token,
        args.num_choices,
        args.num_gpus_per_model,
        args.num_gpus_total,
        args.max_gpu_memory,
        args.temperature,
        args,
        args.enable_gpu_monitor,
        args.gpu_monitor_interval,
        args.output_file,
        args.fix_gpu_clock,
        args.graphics_clock,
        args.memory_clock,
        args.test_mode,
        args.second_model_path,
    )

    reorg_answer_file(args.answer_file)
