import argparse
import csv
import json
import os
import re
import time
from datetime import datetime
from typing import Dict, List, Optional

import torch
from fastchat.llm_judge.common import load_questions
from fastchat.model import get_conversation_template
from transformers import AutoTokenizer

from evaluation.eval_opt_classic_draft import get_kv_llama_class
from evaluation.eval_opt_classic_draft_orin import OrinGPUMonitor
from opt_classic.tree import Tree


def _is_lfs_pointer_file(path: str) -> bool:
    """Git LFS 포인터 파일인지 빠르게 판별."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            first = f.readline().strip()
            second = f.readline().strip()
        return first.startswith("version https://git-lfs.github.com/spec/v1") and second.startswith("oid sha256:")
    except Exception:
        return False


def infer_model_size_tag(model_path: str) -> str:
    """
    모델 경로/이름에서 68m, 1b, 7b 같은 사이즈 태그를 추출한다.
    실패 시 unknown 사용.
    """
    name = model_path.split("/")[-1].lower()
    match = re.search(r"(\d+(?:\.\d+)?)\s*([bm])", name)
    if not match:
        return "unknown"
    num = match.group(1).replace(".", "p")
    unit = match.group(2)
    return f"{num}{unit}"


def load_model_with_retry(model_cls, model_path: str, model_kwargs: Dict, max_retries: int = 4, retry_sleep_sec: float = 2.0):
    """허브 연결 불안정 시 from_pretrained를 재시도."""
    last_exc = None
    for attempt in range(1, max_retries + 1):
        try:
            return model_cls.from_pretrained(model_path, **model_kwargs)
        except Exception as e:
            last_exc = e
            if attempt >= max_retries:
                break
            print(
                f"[WARN] Model load failed ({attempt}/{max_retries}): {e}. "
                f"Retrying in {retry_sleep_sec:.1f}s..."
            )
            time.sleep(retry_sleep_sec)
    raise last_exc


def load_tokenizer_with_retry(tokenizer_path: str, max_retries: int = 4, retry_sleep_sec: float = 2.0):
    """토크나이저 로딩 재시도 + fast 실패 시 slow fallback."""
    last_exc = None
    for attempt in range(1, max_retries + 1):
        try:
            return AutoTokenizer.from_pretrained(tokenizer_path)
        except Exception as e:
            last_exc = e
            if attempt >= max_retries:
                break
            print(
                f"[WARN] Fast tokenizer load failed ({attempt}/{max_retries}): {e}. "
                f"Retrying in {retry_sleep_sec:.1f}s..."
            )
            time.sleep(retry_sleep_sec)

    # 마지막으로 slow tokenizer 시도
    print(f"[WARN] Falling back to slow tokenizer (use_fast=False): {last_exc}")
    return AutoTokenizer.from_pretrained(tokenizer_path, use_fast=False)


def process_tree_mask(tree_attention_mask: torch.Tensor, init_len: int) -> torch.Tensor:
    current_width = tree_attention_mask.size(0)
    attention_mask = torch.full((current_width, init_len), 0, device=tree_attention_mask.device)
    tree_mask = torch.where(tree_attention_mask == 0, torch.finfo(torch.float32).min, 0.0)
    attention_mask = torch.cat([attention_mask, tree_mask], dim=-1)
    return attention_mask[None, None, :, :]


def align_mask_cols(mask_4d: torch.Tensor, expected_cols: int) -> torch.Tensor:
    """Align attention-mask last dim to expected KV+current width."""
    cur_cols = int(mask_4d.size(-1))
    if cur_cols == expected_cols:
        return mask_4d
    if cur_cols > expected_cols:
        # Trim oldest left columns first.
        return mask_4d[..., cur_cols - expected_cols :]
    pad_cols = expected_cols - cur_cols
    pad = torch.zeros(
        mask_4d.size(0), mask_4d.size(1), mask_4d.size(2), pad_cols, device=mask_4d.device, dtype=mask_4d.dtype
    )
    return torch.cat([pad, mask_4d], dim=-1)


def build_prompt(model_path: str, bench_name: str, question_file: str) -> str:
    if _is_lfs_pointer_file(question_file):
        print(
            f"[WARN] Question file is a Git LFS pointer: {question_file}. "
            "Using built-in fallback prompt. (Install git-lfs + pull to use real benchmark questions)"
        )
        questions = []
    else:
        try:
            questions = load_questions(question_file, None, None)
        except Exception as e:
            print(
                f"[WARN] Failed to load question file ({question_file}): {e}. "
                "Using built-in fallback prompt."
            )
            questions = []

    if not questions:
        fallback_q = (
            "Write a concise explanation of speculative decoding and its trade-offs in large language models."
            if bench_name == "mt_bench"
            else "If a train travels 120 km in 2 hours, what is its average speed in km/h?"
        )
        q = {"question": fallback_q, "turns": [fallback_q]}
    else:
        q = questions[0]

    if "vicuna" in model_path:
        conv = get_conversation_template("vicuna")
    else:
        conv = get_conversation_template("llama-2-chat")
        conv.system_message = (
            "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe. "
            "Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. "
            "Please ensure that your responses are socially unbiased and positive in nature."
        )
    turns = [q["question"]] if bench_name == "gsm8k" else q["turns"]
    conv.append_message(conv.roles[0], turns[0])
    conv.append_message(conv.roles[1], None)
    return conv.get_prompt() + " "


def maybe_plot(output_prefix: str, summary_rows: List[Dict]) -> Optional[str]:
    try:
        import matplotlib.pyplot as plt
    except Exception:
        return None
    widths = [r["width"] for r in summary_rows]
    lat = [r["latency_avg_ms"] for r in summary_rows]
    util = [r["gpu_util_avg_percent"] for r in summary_rows]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    axes[0].plot(widths, lat, marker="o")
    axes[0].set_title("Width vs Model Call Latency")
    axes[0].set_xlabel("width")
    axes[0].set_ylabel("latency (ms)")
    axes[0].grid(True, alpha=0.3)
    axes[1].plot(widths, util, marker="o", color="tab:orange")
    axes[1].set_title("Width vs GPU Utilization")
    axes[1].set_xlabel("width")
    axes[1].set_ylabel("utilization (%)")
    axes[1].grid(True, alpha=0.3)
    fig.tight_layout()
    png_path = f"{output_prefix}_plot.png"
    fig.savefig(png_path, dpi=150)
    plt.close(fig)
    return png_path


def main():
    parser = argparse.ArgumentParser(description="Orin local draft profiling by width (no server needed)")
    parser.add_argument("--draft-model-path", type=str, required=True)
    parser.add_argument("--tokenizer-path", type=str, default=None, help="Optional tokenizer path (defaults to draft-model-path)")
    parser.add_argument("--bench-name", type=str, choices=["mt_bench", "gsm8k"], default="mt_bench")
    parser.add_argument("--question-file", type=str, default=None)
    parser.add_argument("--device-map", type=str, default="auto", help="auto | cuda:0 | cpu")
    parser.add_argument("--load-in-8bit", action="store_true")
    parser.add_argument("--load-in-4bit", action="store_true")
    parser.add_argument("--max-depth", type=int, default=12)
    parser.add_argument("--widths", type=str, default="5120")  # 10,20,40,80,160,320,640,1280,2560
    parser.add_argument("--runs-per-width", type=int, default=5)
    parser.add_argument("--gpu-monitor-interval", type=float, default=0.05)
    parser.add_argument("--output-dir", type=str, default="result/massive_draft_profiling")
    args = parser.parse_args()

    # 디바이스 결정: CUDA 미지원 torch에서 cuda:0 강제 시 초기화 단계에서 AssertionError 발생.
    torch_cuda_available = torch.cuda.is_available()
    requested_device_map = args.device_map
    if requested_device_map == "auto":
        effective_device_map = "cuda:0" if torch_cuda_available else "cpu"
    elif requested_device_map.startswith("cuda") and not torch_cuda_available:
        print(
            f"[WARN] Requested device-map '{requested_device_map}', "
            f"but torch CUDA is unavailable (torch={torch.__version__}, cuda={torch.version.cuda}). "
            "Falling back to CPU."
        )
        effective_device_map = "cpu"
    else:
        effective_device_map = requested_device_map

    print(
        f"[INFO] torch={torch.__version__} cuda_available={torch_cuda_available} "
        f"requested_device_map={requested_device_map} effective_device_map={effective_device_map}"
    )

    if args.question_file:
        question_file = args.question_file
    else:
        repo = os.path.dirname(os.path.dirname(__file__))
        question_file = (
            os.path.join(repo, "data", "mt_bench", "question.jsonl")
            if args.bench_name == "mt_bench"
            else os.path.join(repo, "data", "gsm8k.jsonl")
        )

    widths = [int(x.strip()) for x in args.widths.split(",") if x.strip()]
    widths = sorted(set([w for w in widths if w > 0]))
    if not widths:
        raise RuntimeError("No valid widths.")

    os.makedirs(args.output_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    model_name = args.draft_model_path.split("/")[-1] if "/" in args.draft_model_path else args.draft_model_path
    model_size_tag = infer_model_size_tag(args.draft_model_path)
    out_prefix = os.path.join(args.output_dir, f"profile_{args.bench_name}_orin_{model_size_tag}_{ts}")

    quantization_config = None
    if args.load_in_8bit:
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_8bit=True, llm_int8_threshold=6.0, llm_int8_skip_modules=["lm_head"]
        )
    elif args.load_in_4bit:
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
        )

    KVLlamaForCausalLM = get_kv_llama_class(args.draft_model_path)
    model = load_model_with_retry(
        KVLlamaForCausalLM,
        args.draft_model_path,
        model_kwargs={
            "torch_dtype": torch.float16,
            "low_cpu_mem_usage": True,
            "device_map": effective_device_map,
            "quantization_config": quantization_config,
        },
    )
    tokenizer_path = args.tokenizer_path if args.tokenizer_path else args.draft_model_path
    tokenizer = load_tokenizer_with_retry(tokenizer_path)
    prompt = build_prompt(tokenizer_path, args.bench_name, question_file)

    device = model.lm_head.weight.device
    input_ids = tokenizer([prompt]).input_ids
    input_ids_t = torch.as_tensor(input_ids).to(device)
    input_ids_for_profile = input_ids_t

    # Orin 전용 jtop 기반 GPU 모니터 (실패 시 즉시 종료)
    gpu_monitor = OrinGPUMonitor(interval=args.gpu_monitor_interval, debug=False)
    try:
        _ = gpu_monitor.get_gpu_info()
    except Exception as e:
        print(
            "[ERROR] jtop GPU 모니터 초기화 실패. "
            "Jetson Orin에서는 nvidia-smi fallback을 사용하지 않도록 설정되어 실험을 종료합니다."
        )
        raise SystemExit(1) from e
    results = []
    summary_rows = []

    with torch.no_grad():
        for width in widths:
            latency_ms_list = []
            util_list = []
            power_w_list = []
            for _ in range(args.runs_per_width):
                # fresh base forward per run
                draft_outputs = model.model(
                    input_ids=input_ids_for_profile,
                    position_ids=torch.arange(0, input_ids_for_profile.shape[1], device=device, dtype=torch.long),
                    return_kv=True,
                    is_draft=True,
                )
                fresh_last_hidden = draft_outputs[0][:, -1]
                fresh_last_headout = model.lm_head(fresh_last_hidden)
                past_key_values = draft_outputs[1]
                init_len = past_key_values[0][0].size(2)
                len_posi = input_ids_for_profile.shape[1] - 1

                tree = Tree(
                    width,
                    device,
                    args.max_depth + 1,
                    per_token_probability_bound=0.0,
                    per_path_probability_bound=0.0,
                    fixed_width=width,
                    fixed_nnodes=True,
                    fixed_depth=True,
                )
                headout_1d = fresh_last_headout[0] if fresh_last_headout.dim() == 2 else fresh_last_headout
                init_logits = torch.softmax(headout_1d.unsqueeze(0).unsqueeze(0), dim=-1, dtype=torch.float32)
                tree_output = tree.update(init_logits, print_tree=False, tokenizer=tokenizer)
                logits = fresh_last_headout.unsqueeze(0)
                draft_time = None

                for _depth in range(1, args.max_depth + 1):
                    logits_for_update = logits.unsqueeze(0) if logits.dim() == 2 else logits
                    tree_output = tree.update(
                        torch.softmax(logits_for_update.to(device), dim=-1, dtype=torch.float32),
                        print_tree=False,
                        tokenizer=tokenizer,
                        draft_time=draft_time,
                    )
                    if tree_output.get("is_final", False):
                        break
                    input_ids_step = tree_output["input_ids"].unsqueeze(0)
                    position_ids = tree_output["position_ids"] + len_posi

                    actual_past_length = past_key_values[0][0].shape[2] if past_key_values is not None else init_len
                    tree_attention_mask = tree_output["attention_mask"]
                    current_width = tree_attention_mask.size(0)
                    tree_mask_cols = tree_attention_mask.size(1)
                    past_cols = tree_mask_cols - current_width
                    init_len_for_mask = max(0, actual_past_length - past_cols)
                    tree_attention_mask_with_kv = process_tree_mask(tree_attention_mask, init_len_for_mask)
                    expected_cols = int(actual_past_length + current_width)
                    tree_attention_mask_with_kv = align_mask_cols(tree_attention_mask_with_kv, expected_cols)

                    gpu_monitor.start_monitoring()
                    if input_ids_step.is_cuda:
                        torch.cuda.synchronize()
                    start = time.time()
                    draft_outputs = model.model(
                        input_ids=input_ids_step,
                        position_ids=position_ids,
                        past_key_values=past_key_values,
                        tree_attention_mask=tree_attention_mask_with_kv,
                        return_kv=True,
                        is_draft=True,
                    )
                    if draft_outputs[0].is_cuda:
                        torch.cuda.synchronize()
                    draft_time = time.time() - start
                    try:
                        gpu_monitor.stop_monitoring()
                    except Exception as e:
                        print(
                            "[ERROR] jtop GPU 모니터링 실패. "
                            "Jetson Orin에서는 nvidia-smi fallback을 사용하지 않도록 설정되어 실험을 종료합니다."
                        )
                        raise SystemExit(1) from e
                    gpu_stats = gpu_monitor.get_stats()

                    latency_ms = draft_time * 1000.0
                    latency_ms_list.append(latency_ms)
                    if isinstance(gpu_stats, dict):
                        g0 = gpu_stats.get("gpu_0") or next(iter(gpu_stats.values()))
                        util_info = g0.get("utilization_percent", {}) if isinstance(g0, dict) else {}
                        util = util_info.get("avg")
                        if util is not None:
                            util_list.append(float(util))
                        power_info = g0.get("power_draw_w", {}) if isinstance(g0, dict) else {}
                        p = power_info.get("avg")
                        if p is not None:
                            power_w_list.append(float(p))

                    past_key_values = draft_outputs[1]
                    last_hidden = draft_outputs[0]
                    last_headout = model.lm_head(last_hidden)
                    logits = last_headout

            row = {
                "draft_model_path": args.draft_model_path,
                "draft_model_name": model_name,
                "draft_model_size_tag": model_size_tag,
                "width": width,
                "model_call_count": len(latency_ms_list),
                "latency_avg_ms": float(sum(latency_ms_list) / len(latency_ms_list)) if latency_ms_list else 0.0,
                "latency_min_ms": float(min(latency_ms_list)) if latency_ms_list else 0.0,
                "latency_max_ms": float(max(latency_ms_list)) if latency_ms_list else 0.0,
                "gpu_util_avg_percent": float(sum(util_list) / len(util_list)) if util_list else 0.0,
                "gpu_util_min_percent": float(min(util_list)) if util_list else 0.0,
                "gpu_util_max_percent": float(max(util_list)) if util_list else 0.0,
                "gpu_power_avg_w": float(sum(power_w_list) / len(power_w_list)) if power_w_list else 0.0,
            }
            summary_rows.append(row)
            results.append(
                {
                    "width": width,
                    "latency_ms_all": latency_ms_list,
                    "gpu_util_all": util_list,
                    "gpu_power_w_all": power_w_list,
                    "summary": row,
                }
            )
            print(
                f"width={width:>3} calls={row['model_call_count']:>4} "
                f"lat={row['latency_avg_ms']:.3f}ms util={row['gpu_util_avg_percent']:.2f}% "
                f"power={row['gpu_power_avg_w']:.2f}W"
            )

    summary_rows = sorted(summary_rows, key=lambda x: x["width"])
    payload = {
        "meta": {
            "timestamp": ts,
            "draft_model_path": args.draft_model_path,
            "draft_model_size_tag": model_size_tag,
            "tokenizer_path": tokenizer_path,
            "bench_name": args.bench_name,
            "question_file": question_file,
            "max_depth": args.max_depth,
            "runs_per_width": args.runs_per_width,
            "widths": widths,
            "gpu_monitor_interval": args.gpu_monitor_interval,
            "gpu_monitor_backend": "orin_jtop",
            "requested_device_map": requested_device_map,
            "effective_device_map": effective_device_map,
            "torch_cuda_available": torch_cuda_available,
        },
        "summary": summary_rows,
        "raw": results,
    }
    json_path = f"{out_prefix}.json"
    with open(json_path, "w") as f:
        json.dump(payload, f, indent=2)

    csv_path = f"{out_prefix}.csv"
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
        writer.writeheader()
        writer.writerows(summary_rows)

    plot_path = maybe_plot(out_prefix, summary_rows)
    print(f"Saved JSON: {json_path}")
    print(f"Saved CSV : {csv_path}")
    if plot_path:
        print(f"Saved PNG : {plot_path}")
    else:
        print("PNG skipped (matplotlib unavailable)")


if __name__ == "__main__":
    main()
