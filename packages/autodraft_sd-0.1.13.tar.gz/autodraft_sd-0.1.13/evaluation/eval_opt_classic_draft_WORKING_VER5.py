'''
일단 accept length는 잘 나옴. 
다만 target에서 받은 best_ids를 활용하여 draft_stable_kv를 업데이트하는 로직이 안되어 있음. 
향후 버전에서 추가할 것. 
++ code redundancy 제거. (update_kv_with_accepted 함수 제거 및 draft_stable_kv 관리 로직 수정 (tree 확장 후 포함 제거))
'''

import argparse
import json
import os
import socket
import time
from datetime import datetime
from typing import List, Tuple

import shortuuid
import torch
from fastchat.llm_judge.common import load_questions
from fastchat.model import get_conversation_template
from transformers import AutoTokenizer
from tqdm import tqdm
import importlib
from opt_classic.utils import prepare_logits_processor, recv_json, send_json, recv_json_with_size, send_json_with_size
from opt_classic.modeling_llama_kv import LlamaForCausalLM as KVLlamaForCausalLM
from opt_classic.tree import Tree
import numpy as np
np.set_printoptions(threshold=np.inf)

def get_kv_llama_class(base_model_path: str):

    model_path_l = (base_model_path or "").lower()
    is_qwen3 = ("qwen3" in model_path_l) or ("qwen-3" in model_path_l)
    is_qwen2 = (not is_qwen3) and (("qwen2" in model_path_l) or ("qwen-2" in model_path_l))
    if is_qwen3:
        module_name, class_name = "opt_classic.modeling_qwen3_kv", "Qwen3ForCausalLM"
    elif is_qwen2:
        module_name, class_name = "opt_classic.modeling_qwen2_kv", "Qwen2ForCausalLM"
    elif "Llama-3." in base_model_path or "llama-3" in model_path_l or "llama3" in model_path_l:
        module_name, class_name = "opt_classic.modeling_llama3_kv", "LlamaForCausalLM"
    else:
        module_name, class_name = "opt_classic.modeling_llama_kv", "LlamaForCausalLM"
    print(f'importing {module_name}.{class_name}')
    try:
        mod = importlib.import_module(module_name)
        return getattr(mod, class_name)
    except Exception as e:
        raise RuntimeError(f"Failed to import {module_name}.{class_name}: {e}")
    





class DraftRunner:
    def __init__(self, draft_model: torch.nn.Module, tokenizer: AutoTokenizer, debug: bool = False, profile_data: dict = None, draft_per_sec_cost: float = 0.0, target_per_sec_cost: float = 0.0, cost_sensitivity: float = 0.0):
        
        self.draft_model = draft_model
        self.tokenizer = tokenizer
        # Draft는 tree 확장 때문에 stable KV 방식 사용
        self.draft_stable_kv = None
        self.debug = debug
        # width별 add() 함수 실행 시간 통계 누적
        self.accumulated_width_times = {}  # {width: [time1, time2, ...]}
        # add() 함수에 사용된 시간의 총합 누적
        self.accumulated_add_total_time = 0.0
        # add() 함수에 사용된 예상 시간의 총합 누적
        self.accumulated_expected_add_total_time = 0.0
        # 프로파일링 데이터 (width별 avg_time_ms를 포함하는 딕셔너리)
        self.profile_data = profile_data  # {width: {"avg_time_ms": ...}, ...}
        # Target 프로파일링 데이터 (width_depth별 avg_time_ms를 포함하는 딕셔너리)
        self.target_profile_data = None  # {"width_X_depth_Y": {"avg_time_ms": ...}, ...}
        # 이전 tree의 정보 (전송 시간 계산용)
        # 초기값은 나중에 max_nnodes로 설정됨 (draft() 함수에서)
        self.prev_tree_final_width = None  # 이전 tree의 top_index 개수 (final_nnodes), 초기값은 None
        self.prev_tree_depth = 0  # 이전 tree의 depth
        self.prev_tree_total_target_time = 0.4  # 이전 tree의 토탈 시간 (target에서 받은 시간, 초 단위), 초기값 0.4초
        # 초당 비용 (시간당 비용을 초당 비용으로 변환)
        self.draft_per_sec_cost = draft_per_sec_cost
        self.target_per_sec_cost = target_per_sec_cost
        # Cost sensitivity (0 to infinity)
        self.cost_sensitivity = cost_sensitivity
        # Depth별 통계 누적 (모든 tree에서 수집)
        self.accumulated_depth_stats = {}  # {depth: {"prev_sum_expected_accepted_length": [...], "sum_expected_accepted_length": [...], "per_token_latency_diff": [...], "per_token_cost_diff": [...]}}
    
    def reset_kv(self):
        """KV cache 리셋"""
        self.draft_stable_kv = None
    
    def reset_timing_stats(self):
        """통계 리셋"""
        self.accumulated_width_times = {}
        self.accumulated_add_total_time = 0.0
        self.accumulated_expected_add_total_time = 0.0
    
    def print_timing_stats(self):
        """누적된 width별 add() 함수 평균 실행 시간 출력"""
        if not self.accumulated_width_times:
            return
        
        print("\n" + "="*80)
        print("Width별 add() 함수 실행 시간 통계 (질문 전체 누적)")
        print("="*80)
        print(f"{'Width':<10} {'실행 횟수':<12} {'총 시간 (ms)':<15} {'평균 시간 (ms)':<15} {'최소 시간 (ms)':<15} {'최대 시간 (ms)':<15}")
        print("-"*80)
        
        for width in sorted(self.accumulated_width_times.keys()):
            times = self.accumulated_width_times[width]
            count = len(times)
            total_time_ms = sum(times) * 1000
            avg_time_ms = (sum(times) / count) * 1000 if count > 0 else 0
            min_time_ms = min(times) * 1000
            max_time_ms = max(times) * 1000
            
            print(f"{width:<10} {count:<12} {total_time_ms:<15.3f} {avg_time_ms:<15.3f} {min_time_ms:<15.3f} {max_time_ms:<15.3f}")
        
        print("="*80)
        
        # add() 함수에 사용된 시간의 총합 출력
        print(f"\nadd() 함수 시간 총합:")
        print(f"  실제 측정 시간: {self.accumulated_add_total_time * 1000:.3f} ms")
        print(f"  예상 시간 (프로파일링): {self.accumulated_expected_add_total_time * 1000:.3f} ms")
        if self.accumulated_add_total_time > 0:
            diff_ms = (self.accumulated_expected_add_total_time - self.accumulated_add_total_time) * 1000
            diff_percent = (diff_ms / (self.accumulated_add_total_time * 1000)) * 100
            print(f"  차이: {diff_ms:+.3f} ms ({diff_percent:+.2f}%)")
        print("="*80 + "\n")

    def process_tree_mask(self, tree_attention_mask: torch.Tensor, init_len: int) -> torch.Tensor:
        attention_mask = torch.full((tree_attention_mask.size(0), init_len), 0, device=tree_attention_mask.device)  # [DH] attention mask는 0으로 초기화됨, (nnodes, init_len) 형태의 matrix
        tree_mask = torch.where(tree_attention_mask == 0, torch.finfo(torch.float32).min, 0)    # [DH] tree_attention_mask가 0인 부분은 -inf로 처리, (nnodes, nnodes) 형태의 matrix
        attention_mask = torch.cat([attention_mask, tree_mask], dim=-1)    # [DH] attention mask에 tree_mask를 추가 (0으로 이루어진 matrix + tree_mask가 0인 부분은 -inf로 처리된 matrix), (nnodes, init_len + nnodes) 형태의 matrix
        attention_mask = attention_mask[None, None, :, :]   # [DH] attention_mask를 [1, 1, nnodes, init_len + nnodes] 형태로 변환, (1, 1, nnodes, init_len + nnodes) 형태의 matrix
        return attention_mask

    @torch.no_grad()
    def draft(self, input_ids: torch.Tensor, nodes: int, threshold: float, max_depth: int, print_time: bool = False, print_tree: bool = False, tokenizer=None, per_token_probability_bound: float = 0.0, per_path_probability_bound: float = 0.0):
        # breakpoint()
        device = self.draft_model.lm_head.weight.device
        len_posi = input_ids.shape[1] - 1
        
        # Stable KV 방식: 이전 KV가 있으면 새 토큰만 계산
        if self.draft_stable_kv is not None:
            kv_len = self.draft_stable_kv[0][0].shape[2]  # 기존 draft_stable_kv의 KV 길이
            new_tokens = input_ids[:, kv_len:].to(device)  # accepted tokens + next_token
            seq_len = new_tokens.shape[1]
            if seq_len == 0:
                # 빈 슬라이스: 이전_next_token == 새_next_token인 경우 <= 그런 경우는 있으면 안되는거 아님? 항상 새로운 토큰이 들어옴. 
                # draft_stable_kv의 마지막 위치(이전_next_token)에서 hidden state를 재계산
                if self.debug:
                    print(f"[DRAFT-INFO] Empty new_tokens (prev_next_token == new_next_token). Recomputing last hidden state.")
                # draft_stable_kv에서 마지막 토큰(이전_next_token) 제외한 past_key_values 사용
                trimmed_kv = tuple(
                    (kv[0][:, :, :-1, :], kv[1][:, :, :-1, :]) 
                    for kv in self.draft_stable_kv
                )
                # 마지막 토큰의 hidden state를 얻기 위해 해당 토큰만 forward
                # 빈 슬라이스인 경우: 이전_next_token == 새_next_token
                # input_ids[-1] = 새_next_token = 이전_next_token
                last_token_id = input_ids[0, -1:].unsqueeze(0).to(device)
                draft_outputs = self.draft_model.model(
                    input_ids=last_token_id,
                    past_key_values=trimmed_kv,
                    position_ids=torch.tensor([[kv_len - 1]], device=device, dtype=torch.long),
                    return_kv=True,
                    is_draft=True,
                )
                # draft_stable_kv는 이미 올바른 상태이므로 업데이트하지 않음 (이전_next_token 포함)
                past_key_values = self.draft_stable_kv
            else:  # 위에는 지워도 될 것 같음. 
                pos_ids = torch.arange(kv_len, kv_len + seq_len, device=device, dtype=torch.long)
                draft_outputs = self.draft_model.model(
                    input_ids=new_tokens,
                    past_key_values=self.draft_stable_kv,
                    position_ids=pos_ids,
                    return_kv=True,
                    is_draft=True,
                )
        else:
            # 처음이거나 리셋 후
            full = input_ids.to(device)
            seq_len = full.shape[1]
            if seq_len == 0:
                raise RuntimeError("DraftRunner.draft received empty input_ids on initial call")
            pos_ids = torch.arange(0, seq_len, device=device, dtype=torch.long)
            draft_outputs = self.draft_model.model(
                input_ids=full,
                position_ids=pos_ids,
                return_kv=True,
                is_draft=True,
            )
        
        # Base KV 저장 (tree 확장 전)
        self.draft_stable_kv = draft_outputs[1]
        past_key_values = self.draft_stable_kv
        init_len = past_key_values[0][0].size(2)
        
        last_hidden = draft_outputs[0][:, -1]
        last_headout = self.draft_model.lm_head(last_hidden)

        # prev_tree_final_width가 None이면 초기값으로 max_nnodes 사용
        prev_tree_final_width = self.prev_tree_final_width if self.prev_tree_final_width is not None else nodes
        
        tree = Tree(
            nodes, 
            last_hidden.device, 
            threshold, 
            max_depth, 
            per_token_probability_bound=per_token_probability_bound, 
            per_path_probability_bound=per_path_probability_bound, 
            profile_data=self.profile_data,
            target_profile_data=self.target_profile_data,
            prev_tree_final_width=prev_tree_final_width,
            prev_tree_depth=self.prev_tree_depth,
            prev_tree_total_time=self.prev_tree_total_target_time,
            draft_per_sec_cost=self.draft_per_sec_cost,
            target_per_sec_cost=self.target_per_sec_cost,
            cost_sensitivity=self.cost_sensitivity
        )

        logits = last_headout.unsqueeze(0)
        end = False
        while not end:
            tree_output = tree.update(torch.softmax(logits.to(last_hidden.device), dim=-1, dtype=torch.float32), print_tree=print_tree, tokenizer=tokenizer)
            input_ids_step = tree_output["input_ids"].unsqueeze(0)
            position_ids = tree_output["position_ids"] + len_posi   # [DH] 상대적 index(트리에서 몇 번째 인지) -> 절대적 index로 변환 (전체 input_ids에서 몇 번째인지)
            if tree_output["is_final"]:
                break
            tree_attention_mask_with_kv = self.process_tree_mask(tree_output["attention_mask"], init_len)
            draft_outputs = self.draft_model.model(
                input_ids=input_ids_step,
                position_ids=position_ids,
                past_key_values=past_key_values,
                tree_attention_mask=tree_attention_mask_with_kv,
                return_kv=True,
                is_draft=True,
            )
            # Tree 확장 후 KV 업데이트 (local variable)
            past_key_values = draft_outputs[1]
            
            last_hidden = draft_outputs[0]
            last_headout = self.draft_model.lm_head(last_hidden)
            logits = last_headout

        # Tree의 통계를 누적 (실제 시간 리스트 사용)
        for width, times in tree.width_times.items():
            if width not in self.accumulated_width_times:
                self.accumulated_width_times[width] = []
            # 실제 측정된 시간들을 누적
            self.accumulated_width_times[width].extend(times)
        
        # add() 함수에 사용된 시간의 총합 누적
        self.accumulated_add_total_time += tree.add_total_time
        # add() 함수에 사용된 예상 시간의 총합 누적
        self.accumulated_expected_add_total_time += tree.expected_model_total_time
        
        # Depth별 통계 누적 (tree.depth_stats에서 수집)
        for depth, stats in tree.depth_stats.items():
            if depth not in self.accumulated_depth_stats:
                self.accumulated_depth_stats[depth] = {
                    "prev_sum_expected_accepted_length": [],
                    "sum_expected_accepted_length": [],
                    "per_token_latency_diff": [],
                    "per_token_cost_diff": []
                }
            for key in ["prev_sum_expected_accepted_length", "sum_expected_accepted_length", "per_token_latency_diff", "per_token_cost_diff"]:
                self.accumulated_depth_stats[depth][key].extend(stats[key])

        # Tree 확장 후 최종 KV를 draft_stable_kv에 저장 (update_kv_with_accepted에서 사용)
        # 원본과 동일하게: draft_stable_kv에는 tree 확장 후의 전체 KV가 포함되어야 함
        # self.draft_stable_kv = past_key_values  # 원래 verify 에서 해줘야함. 왜 여기? [PJ]
        
        # Tree KV는 반환하지 않음 (토큰만 전송)
        # final_nnodes는 add() 함수에서 계산된 final_nnodes
        final_nnodes = tree.current_width if tree.current_width > 0 else tree.depth_widths[-1] if len(tree.depth_widths) > 0 else 0
        return input_ids_step, position_ids, tree_output["attention_mask"], tree_output["parent_last"], tree.depth, final_nnodes


@torch.inference_mode()
def build_tree_with_next_token(
    runner: DraftRunner,
    input_ids: torch.Tensor,
    nodes: int,
    threshold: float,
    max_depth: int,
    next_token_id: int,
    tokenizer: AutoTokenizer,
    debug: bool = False,
    print_tree: bool = False,
    per_token_probability_bound: float = 0.0,
    per_path_probability_bound: float = 0.0,
):
    # tree 만들기     
    if runner.draft_stable_kv is not None:
        kv_len = runner.draft_stable_kv[0][0].shape[2]  # draft_stable_kv의 KV 길이
        input_ids_len = input_ids.shape[1]
        # 원본처럼: draft_stable_kv = 이전 input_ids + 이전 next_token
        # input_ids = 현재 input_ids (이미 accepted_tokens 포함)
        if kv_len > input_ids_len + 1:
            # draft_stable_kv가 input_ids + next_token보다 크면 불일치, 있으면 안되는 경우임. 
            if debug:
                print(f"[DRAFT-DEBUG] KV sync check failed: kv_len={kv_len} > input_ids_len+1={input_ids_len+1}, resetting")
            runner.draft_stable_kv = None
    
    next_token = torch.tensor([[next_token_id]], device=input_ids.device, dtype=torch.long)
    cat_input = torch.cat((input_ids, next_token), dim=1)
    # 동기화 점검 로그
    if runner.draft_stable_kv is not None:
        kv_len = runner.draft_stable_kv[0][0].shape[2]
        if debug:
            print(f"[DRAFT-DEBUG] KV sync check: kv_len={kv_len}, input_ids_len={input_ids.shape[1]}, cat_input_len={cat_input.shape[1]}")
        if kv_len > cat_input.shape[1]:
            if debug:
                print(f"[DRAFT-WARN] kv_len({kv_len}) > cat_input_len({cat_input.shape[1]}). This will cause empty new_tokens. Check update_kv_with_accepted/base_input_len.")
    
    # draft 함수 호출, input_ids + next_token을 사용해서 token tree 만들기. (원본 verify Line 226: model.draft(input_ids + next_token))
    draft_input_ids, draft_position_ids, tree_attention_mask, parent, tree_depth, final_nnodes = runner.draft(
        cat_input,
        nodes,
        threshold,
        max_depth,
        print_tree=print_tree,
        tokenizer=tokenizer,
        per_token_probability_bound=per_token_probability_bound,
        per_path_probability_bound=per_path_probability_bound,
    )
    
    # draft 함수 반환값에 next_token 추가 (원본 verify Line 249: next_draft = torch.cat([next_token, next_draft], dim=-1))
    next_token_tensor = torch.tensor([[next_token_id]], device=input_ids.device, dtype=torch.long)
    draft_input_ids = torch.cat([next_token_tensor, draft_input_ids], dim=-1)
    head_pos = torch.tensor([cat_input.shape[1]-1], device=draft_position_ids.device)
    draft_position_ids = torch.cat([head_pos, draft_position_ids], dim=-1)
    tree_attention_mask = torch.cat(
        [torch.zeros(1, tree_attention_mask.size(1), dtype=tree_attention_mask.dtype, device=tree_attention_mask.device), tree_attention_mask],
        dim=0,
    )
    tree_attention_mask = torch.cat(
        [torch.ones(tree_attention_mask.size(0), 1, dtype=tree_attention_mask.dtype, device=tree_attention_mask.device), tree_attention_mask],
        dim=1,
    )

    return draft_input_ids, draft_position_ids, tree_attention_mask, parent, tree_depth, final_nnodes


def profile_width_timing(
    runner: DraftRunner,
    tokenizer: AutoTokenizer,
    threshold: float,
    max_depth: int,
    draft_model_path: str,
    device_name: str,
    question_file: str,
    bench_name: str,
    width_list: List[int],
    num_runs_per_width: int = 10,
) -> dict:
    """
    width별 평균 처리시간을 프로파일링하고 JSON 파일로 저장
    Target과의 통신 없이 draft 모델만 실행하여 측정
    
    Args:
        runner: DraftRunner 인스턴스
        tokenizer: 토크나이저
        threshold: Tree threshold
        max_depth: 최대 depth
        draft_model_path: Draft 모델 경로
        device_name: 단말 이름 (예: rtx5080)
        question_file: 질문 파일 경로
        bench_name: 벤치마크 이름
        width_list: 프로파일링할 width 리스트 (예: [50, 60, 70, 80, 90, 100])
        num_runs_per_width: 각 width당 실행 횟수
    
    Returns:
        profile_data: 프로파일링 데이터 딕셔너리 (성공 시), None (스킵 시)
    """
    # 모델 이름 추출 (draft_model_path에서)
    # 예: "meta-llama/Llama-2-7b-chat-hf" -> "Llama-2-7b-chat-hf"
    model_name = draft_model_path.split("/")[-1] if "/" in draft_model_path else draft_model_path
    
    # 파일 경로 생성
    script_dir = os.path.dirname(__file__)
    parent_dir = os.path.dirname(script_dir)
    profile_dir = os.path.join(parent_dir, "data", "profile")
    os.makedirs(profile_dir, exist_ok=True)
    profile_file = os.path.join(profile_dir, f"{device_name}_{model_name}_{bench_name}_draft.json")
    
    # 파일이 이미 존재하면 스킵
    if os.path.exists(profile_file):
        print(f"프로파일링 파일이 이미 존재합니다: {profile_file}")
        print("프로파일링 단계를 스킵합니다.")
        return None
    
    print(f"\n{'='*80}")
    print("Width별 add() 함수 평균 처리시간 프로파일링 시작")
    print(f"프로파일링할 width: {width_list}")
    print(f"각 width당 실행 횟수: {num_runs_per_width}")
    print(f"{'='*80}")
    
    # 프로파일링용 질문 준비
    from fastchat.llm_judge.common import load_questions
    from fastchat.model import get_conversation_template
    
    questions = load_questions(question_file, None, None)
    if len(questions) == 0:
        print("프로파일링할 질문이 없습니다.")
        return None
    
    profile_q = questions[0]
    
    # 대화 템플릿 준비
    if "vicuna" in draft_model_path:
        conv = get_conversation_template("vicuna")
    else:
        conv = get_conversation_template("llama-2-chat")
        sys_p = (
            "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  "
            "Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. "
            "Please ensure that your responses are socially unbiased and positive in nature. If a question does not make any sense, "
            "or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, "
            "please don't share false information."
        )
        conv.system_message = sys_p
    
    # bench_name에 따라 질문 형식 결정
    profile_turns = [profile_q["question"]] if bench_name == "gsm8k" else profile_q["turns"]
    conv.append_message(conv.roles[0], profile_turns[0])
    conv.append_message(conv.roles[1], None)
    prompt = conv.get_prompt() + " "
    input_ids = tokenizer([prompt]).input_ids
    input_ids_t = torch.as_tensor(input_ids).to("cuda")
    
    device = runner.draft_model.lm_head.weight.device
    
    # 초기 input_ids로 모델 실행하여 첫 번째 hidden state 얻기 (한 번만)
    runner.reset_kv()
    input_ids_for_profile = input_ids_t.to(device)
    draft_outputs = runner.draft_model.model(
        input_ids=input_ids_for_profile,
        position_ids=torch.arange(0, input_ids_for_profile.shape[1], device=device, dtype=torch.long),
        return_kv=True,
        is_draft=True,
    )
    last_hidden = draft_outputs[0][:, -1]
    last_headout = runner.draft_model.lm_head(last_hidden)
    vocab_size = last_headout.shape[-1]
    
    # 프로파일링 데이터 저장용
    profile_data = {}
    
    # 각 width에 대해 프로파일링
    for width in width_list:
        print(f"\n프로파일링 중: width={width}")
        width_times = []
        
        # 각 width당 여러 번 실행
        for run_idx in range(num_runs_per_width):
            # Tree 객체 생성 및 초기화
            tree = Tree(width, device, threshold, max_depth, per_token_probability_bound=0.0, per_path_probability_bound=0.0)
            
            # initialize 실행 (시간 측정 포함)
            init_logits = torch.softmax(last_headout.unsqueeze(0), dim=-1, dtype=torch.float32)
            tree_output = tree.update(init_logits, print_tree=False, tokenizer=tokenizer)
            
            # add() 함수를 여러 depth에 대해 실행하여 시간 측정
            # tree.update() 내부에서 이미 시간 측정이 되므로, tree.width_times에서 가져오기
            # 하지만 각 run마다 새로운 Tree 객체를 생성하므로, run이 끝난 후 width_times를 확인
            
            # 더미 logits로 add() 함수 여러 번 실행
            for depth in range(1, max_depth + 1):
                if tree_output.get("is_final", False):
                    break
                
                # 더미 logits 생성 (현재 width에 맞춰서)
                # prev_width는 tree.current_width
                prev_width = tree.current_width
                dummy_logits = torch.softmax(torch.randn(1, prev_width, vocab_size, device=device), dim=-1)
                
                # add() 함수 실행 (시간은 tree.update() 내부에서 측정됨)
                tree_output = tree.update(dummy_logits, print_tree=False, tokenizer=tokenizer)
            
            # width별 시간 수집 (tree.width_times에서)
            if width in tree.width_times:
                width_times.extend(tree.width_times[width])
        
        # width별 통계 계산
        if len(width_times) > 0:
            profile_data[width] = {
                'count': len(width_times),
                'total_time_ms': sum(width_times) * 1000,
                'avg_time_ms': (sum(width_times) / len(width_times)) * 1000,
                'min_time_ms': min(width_times) * 1000,
                'max_time_ms': max(width_times) * 1000,
            }
            print(f"  width={width}: {len(width_times)}회 실행, 평균 {profile_data[width]['avg_time_ms']:.3f}ms")
        else:
            print(f"  width={width}: 데이터 수집 실패")
    
    # JSON 파일로 저장
    if profile_data:
        with open(profile_file, 'w') as f:
            json.dump(profile_data, f, indent=2)
        print(f"\n프로파일링 데이터 저장 완료: {profile_file}")
        print(f"수집된 width 개수: {len(profile_data)}")
    else:
        print("\n프로파일링 데이터가 없습니다.")
        return None
    
    return profile_data


def update_kv_with_accepted(runner: DraftRunner, best_ids: List[int], base_kv_len: int, next_token: int, debug: bool = False):
    """
    Accept된 경로의 KV만 추출하여 draft_stable_kv에 저장
    tree_kv 전송 없이 runner.draft_stable_kv에서 직접 추출
    
    원본 방식 분석:
    - verify 후: draft_stable_kv = input_ids + next_token 상태
    - verify 내부에서: input_ids = input_ids + best_candidate
    - model.draft(input_ids + next_token) 호출
    - draft 함수 내부: draft_stable_kv가 있으면 kv_len 이후만 처리
    - draft_stable_kv = draft_outputs[1]로 전체 업데이트
    
    핵심: draft_stable_kv는 항상 input_ids + next_token 상태와 동기화됨
    
    분리 버전에서:
    - draft() 호출 후 draft_stable_kv에는 전체 tree의 KV가 포함됨
    - best_ids를 사용해서 accept된 경로의 KV만 추출
    - update_kv_with_accepted 후: draft_stable_kv = input_ids (next_token 제외)
    
    Args:
        runner: DraftRunner (draft_stable_kv에 tree KV 포함)
        best_ids: Target이 계산한 accept된 경로의 tree 내 인덱스들 (draft_input_ids 기준)
        base_kv_len: input_ids_t.shape[1] (accept 전의 길이 = old_input_ids 길이)
        next_token: Target이 반환한 다음 토큰 ID
    """
    if len(best_ids) == 0:
        return
    
    if runner.draft_stable_kv is None:
        if debug:
            print("[DRAFT-DEBUG] draft_stable_kv is None, skipping update")
        return
    
    device = runner.draft_model.lm_head.weight.device
    
    # draft_stable_kv 구조 분석:
    # draft() 호출 후 draft_stable_kv = [이전 draft_stable_kv + 새로 처리한 토큰들]
    # 하지만 draft() 함수는 past_key_values를 받아서 새 토큰만 처리하므로:
    # - draft_stable_kv = [이전 draft_stable_kv (전체) + 새 토큰들 (tree_nodes)]
    #
    # 실제로 draft() 함수 내부를 보면:
    # - past_key_values = draft_stable_kv (이전 상태)
    # - input_ids[:, kv_len:] = 새 토큰들만 처리
    # - draft_outputs[1] = 전체 새로운 KV (past_key_values + 새 토큰들)
    #
    # 따라서 draft_stable_kv 구조:
    # - draft_stable_kv = [old_input_ids + next_token + tree_nodes] (전체)
    # - base_kv_len = input_ids_t.shape[1] (accept 전)
    # - base_kv_len은 old_input_ids 길이와 다를 수 있음!
    #
    # 해결: base_kv_len은 update_kv_with_accepted 호출 전 input_ids_t 길이
    # 하지만 draft_stable_kv는 이미 tree 확장 후 상태이므로,
    # base_kv_len보다 클 수 있음
    
    # draft_stable_kv 현재 길이
    tree_kv_len = runner.draft_stable_kv[0][0].shape[2]
    old_kv_len = tree_kv_len
    old_input_ids_len = base_kv_len
    
    # base_kv_len은 draft() 호출 전 input_ids 길이
    # draft_stable_kv 구조를 확인:
    # - draft_stable_kv는 draft() 호출 후 상태
    # - base_kv_len 이전 부분은 old_input_ids
    # - base_kv_len 위치부터는 새로 추가된 부분
    
    # best_ids는 draft_input_ids 기준 인덱스:
    # - draft_input_ids[0] = next_token
    # - draft_input_ids[1:] = tree_nodes
    # draft_stable_kv에서의 인덱스:
    # - next_token 위치 = base_kv_len (draft() 호출 시 추가된 위치)
    # - tree_nodes 위치 = base_kv_len + 1부터
    
    # 하지만 draft() 함수를 다시 확인하면:
    # - draft() 호출 시 input_ids = input_ids + next_token
    # - draft_stable_kv가 있으면 kv_len 이후만 처리
    # - 따라서 draft_stable_kv = [이전 draft_stable_kv + 새 토큰들]
    
    # 현재 draft_stable_kv에서 base_kv_len 위치 확인
    if base_kv_len >= tree_kv_len:
        if debug:
            print(f"ERROR: base_kv_len ({base_kv_len}) >= tree_kv_len ({tree_kv_len})")
            print(f"[DRAFT-DEBUG] KV sync failed, resetting draft_stable_kv")
        runner.draft_stable_kv = None
        return
    
    # best_ids를 draft_stable_kv 기준 인덱스로 변환
    # draft_input_ids[best_id]는 draft_stable_kv[base_kv_len + best_id]에 해당
    select_indices = torch.tensor(best_ids, device=device) + base_kv_len
    min_index = select_indices.min().item()
    max_index = select_indices.max().item()
    
    # 디버깅 로그
    if debug:
        print(f"[DRAFT-DEBUG] KV Update Info:")
        print(f"  best_ids: {best_ids}")
        print(f"  base_kv_len: {base_kv_len}")
        print(f"  select_indices: {select_indices.tolist()}")
        print(f"  tree_kv_len: {tree_kv_len}")
        print(f"  old_kv_len: {old_kv_len}")
        print(f"  index range: [{min_index}, {max_index}]")
    
    # 인덱스 범위 검증
    if min_index < base_kv_len or max_index >= tree_kv_len:
        if debug:
            print(f"ERROR: Index range [{min_index}, {max_index}] out of bounds [{base_kv_len}, {tree_kv_len})")
            print(f"[DRAFT-DEBUG] KV sync failed, resetting draft_stable_kv")
        runner.draft_stable_kv = None
        return
    
    # draft_stable_kv에서 accept된 토큰들의 KV 추출
    selected_kv = []
    for layer_kv in runner.draft_stable_kv:
        key, value = layer_kv
        selected_key = key[:, :, select_indices, :]
        selected_value = value[:, :, select_indices, :]
        selected_kv.append((selected_key, selected_value))
    
    # 원본 방식 분석:
    # verify 함수 (Line 225-226):
    #   1. input_ids = input_ids + best_candidate
    #   2. model.draft(input_ids + next_token) 호출
    #   → draft 함수 내부:
    #      - draft_stable_kv가 있으면 kv_len = draft_stable_kv[0][0].shape[2]
    #      - input_ids[:, kv_len:]만 처리 (새 토큰만)
    #      - draft_stable_kv = draft_outputs[1]로 전체 업데이트
    #
    # 분리 버전에서의 흐름:
    # 1. build_tree_with_next_token 호출 전:
    #    - input_ids_t = [old_input_ids] (accept 전)
    #    - draft_stable_kv = [old_input_ids + prev_next_token] (이전 스텝)
    # 
    # 2. build_tree_with_next_token:
    #    - cat_input = [old_input_ids + next_token]
    #    - draft() 호출:
    #      * draft_stable_kv가 있으면: kv_len = old_input_ids + prev_next_token
    #      * 하지만 cat_input = old_input_ids + next_token만 포함
    #      * draft_stable_kv의 prev_next_token과 next_token이 다를 수 있음!
    #    - 따라서 draft_stable_kv를 리셋하거나 동기화 필요
    #
    # 3. update_kv_with_accepted 호출 시:
    #    - base_kv_len = input_ids_t.shape[1] = old_input_ids 길이
    #    - tree_kv 구조: [old_input_ids + next_token + tree_nodes]
    #    - selected_kv = tree_kv[base_kv_len + best_ids] = [next_token + accepted_nodes]
    #
    # 원본과 동일하게 하려면:
    # draft_stable_kv = [old_input_ids + accepted_tokens]로 설정
    # 여기서 accepted_tokens = selected_kv에 해당 (next_token 포함)
    
        # 원본 동작 재확인:
        # verify 후 draft_stable_kv = input_ids + next_token
        # 하지만 draft 함수 호출 시 input_ids 전체를 전달하므로:
        # - draft_stable_kv는 draft 함수 내부에서 자동 업데이트됨
        #
        # 분리 버전에서:
        # - update_kv_with_accepted 후: draft_stable_kv = input_ids (next_token 제외)
        # - build_tree_with_next_token: input_ids + next_token으로 draft 호출
        # - draft 함수: kv_len = input_ids, input_ids[:, kv_len:] = next_token 처리
        # - draft_stable_kv = input_ids + next_token (자동 업데이트됨)
        #
        # 따라서 update_kv_with_accepted에서는 draft_stable_kv = input_ids로 설정
    
    if runner.draft_stable_kv is not None:
        old_kv_len = runner.draft_stable_kv[0][0].shape[2]
        old_input_ids_len = base_kv_len
        
        # 원본 불변식: verify 직후 draft_stable_kv = 이전 input_ids + 이전 next_token
        # 따라서 accepted_tokens는 포함하지 않고, base_kv_len까지만 유지 + next_token만 추가
        # (accepted_tokens는 이미 input_ids에 추가되었으므로 제외)
        
        # draft_stable_kv에서 next_token의 KV 추출 (항상 base_kv_len 위치)
        next_token_kv = []
        for layer_kv in runner.draft_stable_kv:
            key, value = layer_kv
            if base_kv_len < old_kv_len:
                # base_kv_len 위치의 next_token KV 추출
                next_token_key = key[:, :, base_kv_len:base_kv_len+1, :]
                next_token_value = value[:, :, base_kv_len:base_kv_len+1, :]
            else:
                # base_kv_len == old_kv_len인 경우 (첫 스텝이거나 리셋된 경우)
                # next_token은 이미 draft_stable_kv의 마지막에 있을 수 있음
                # 하지만 일반적으로는 없으므로 빈 텐서로 처리
                next_token_key = key[:, :, -1:, :] if old_kv_len > 0 else key[:, :, :0, :]
                next_token_value = value[:, :, -1:, :] if old_kv_len > 0 else value[:, :, :0, :]
            next_token_kv.append((next_token_key, next_token_value))
        
        if old_input_ids_len > 0:
            # 원본 불변식: draft_stable_kv = input_ids + next_token
            # 여기서 input_ids = old_input_ids + accepted_tokens (다음 스텝에서 업데이트될 값)
            # 하지만 update_kv_with_accepted 시점에는 input_ids가 아직 old_input_ids 상태
            # 따라서 draft_stable_kv = old_input_ids + 이전_next_token으로 설정
            # (accepted_tokens는 다음 스텝에서 input_ids에 추가되므로 draft_stable_kv에는 포함하지 않음)
            new_kv = []
            for i in range(len(runner.draft_stable_kv)):
                base_key = runner.draft_stable_kv[i][0]
                base_value = runner.draft_stable_kv[i][1]
                
                # old_input_ids 부분만 추출
                old_input_ids_key = base_key[:, :, :old_input_ids_len, :]
                old_input_ids_value = base_value[:, :, :old_input_ids_len, :]
                
                # 이전 next_token KV 추가 (accepted_tokens는 제외)
                next_key, next_value = next_token_kv[i]
                new_key = torch.cat([old_input_ids_key, next_key], dim=2)
                new_value = torch.cat([old_input_ids_value, next_value], dim=2)
                
                new_kv.append((new_key, new_value))
            
            runner.draft_stable_kv = tuple(new_kv)
            new_kv_len = runner.draft_stable_kv[0][0].shape[2]
            expected_len = old_input_ids_len + 1  # old_input_ids + 이전_next_token
            if debug:
                print(f"[DRAFT-DEBUG] KV updated. New length: {new_kv_len}, expected (old_input_ids+prev_next_token): {expected_len}")
            if new_kv_len != expected_len:
                if debug:
                    print(f"[DRAFT-WARN] KV length mismatch! Expected {expected_len}, got {new_kv_len}")
        else:
            # 첫 스텝: next_token만 유지
            runner.draft_stable_kv = tuple(next_token_kv)
            if debug:
                print(f"[DRAFT-DEBUG] KV updated (first step). New length: {runner.draft_stable_kv[0][0].shape[2]}")
    else:
        # draft_stable_kv가 None인 경우: selected_kv에서 next_token 추출 불가능
        # 이 경우는 초기화 단계이므로, selected_kv를 그대로 사용
        # 하지만 일반적으로는 draft_stable_kv가 있어야 함
        if debug:
            print(f"[DRAFT-WARN] draft_stable_kv is None, using selected_kv as fallback")
        runner.draft_stable_kv = tuple(selected_kv)
        if debug:
            print(f"[DRAFT-DEBUG] Initial KV set (fallback). Length: {runner.draft_stable_kv[0][0].shape[2]}")


def run_draft(
    host: str,
    port: int,
    base_model_path: str,
    draft_model_path: str,
    bench_name: str,
    question_file: str,
    limit: int,
    temperature: float,
    nodes: int,
    threshold: float,
    max_depth: int,
    device_map: str,
    load_in_4bit: bool,
    load_in_8bit: bool,
    answer_file: str = None,
    model_id: str = "llama-2-chat",
    num_choices: int = 1,
    debug: bool = False,
    print_tree: bool = False,
    per_token_probability_bound: float = 0.0,
    per_path_probability_bound: float = 0.0,
    device_name: str = None,
    draft_per_hour_cost: float = 0.0,
    target_per_hour_cost: float = 0.0,
    cost_sensitivity: float = 0.0,
    model_family: str = "llama2"
):
    # 드래프트 모델만 로드
    quantization_config = None
    if load_in_8bit:
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_8bit=True,
            llm_int8_threshold=6.0,
            llm_int8_skip_modules=["lm_head"],
        )
    elif load_in_4bit:
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
        )
    KVLlamaForCausalLM = get_kv_llama_class(base_model_path)
    draft_model = KVLlamaForCausalLM.from_pretrained(
        draft_model_path,
        torch_dtype=torch.float16,
        low_cpu_mem_usage=True,
        device_map=device_map,
        quantization_config=quantization_config,
        token="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",
        # token="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",
    )
    tokenizer = AutoTokenizer.from_pretrained(
        base_model_path,
        token="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",
        # token="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",
    )
    # 시간당 비용을 초당 비용으로 변환
    draft_per_sec_cost = draft_per_hour_cost / 3600.0
    target_per_sec_cost = target_per_hour_cost / 3600.0
    runner = DraftRunner(draft_model=draft_model, tokenizer=tokenizer, debug=debug, draft_per_sec_cost=draft_per_sec_cost, target_per_sec_cost=target_per_sec_cost, cost_sensitivity=cost_sensitivity)

    # 프로파일링 데이터 로드 (device_name이 제공된 경우)
    if device_name:
        script_dir = os.path.dirname(__file__)
        parent_dir = os.path.dirname(script_dir)
        profile_dir = os.path.join(parent_dir, "data", "profile")
        
        # 모델 이름 추출
        draft_model_name = draft_model_path.split("/")[-1] if "/" in draft_model_path else draft_model_path
        base_model_name = base_model_path.split("/")[-1] if "/" in base_model_path else base_model_path
        
        # 프로파일링 파일 경로
        draft_profile_file = os.path.join(profile_dir, f"{device_name}_{draft_model_name}_{bench_name}_draft.json")
        target_profile_file = os.path.join(profile_dir, f"{device_name}_{base_model_name}_{bench_name}_target.json")
        
        # 프로파일링 데이터 로드 (파일이 존재하면)
        profile_data = None
        if os.path.exists(draft_profile_file):
            try:
                with open(draft_profile_file, 'r') as f:
                    profile_data = json.load(f)
                if debug:
                    print(f"프로파일링 데이터를 로드했습니다: {draft_profile_file}")
            except Exception as e:
                if debug:
                    print(f"프로파일링 데이터 로드 실패: {e}")
                profile_data = None
        
        # Target 프로파일링 데이터 로드 (파일이 존재하면)
        target_profile_data = None
        if os.path.exists(target_profile_file):
            try:
                with open(target_profile_file, 'r') as f:
                    target_profile_data = json.load(f)
                if debug:
                    print(f"Target 프로파일링 데이터를 로드했습니다: {target_profile_file}")
            except Exception as e:
                if debug:
                    print(f"Target 프로파일링 데이터 로드 실패: {e}")
                target_profile_data = None
        
        # DraftRunner에 프로파일링 데이터 설정
        runner.profile_data = profile_data
        runner.target_profile_data = target_profile_data

    if temperature > 1e-5:
        logits_processor = prepare_logits_processor(temperature=temperature)
    else:
        logits_processor = None

    with socket.create_connection((host, port)) as sock:
        questions = load_questions(question_file, None, None)
        if limit and limit > 0:
            questions = questions[:limit]

        # Warmup (3회) - 첫 질문으로 파이프라인 예열
        for _ in range(3):
            torch.manual_seed(0)
            # Warmup마다 KV cache 리셋
            runner.reset_kv()
            warm_q = questions[0] # WIPWIPWIPWIP
            if "vicuna" in base_model_path:
                conv = get_conversation_template("vicuna")
            else:
                conv = get_conversation_template("llama-2-chat")
                sys_p = (
                    "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  "
                    "Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. "
                    "Please ensure that your responses are socially unbiased and positive in nature. If a question does not make any sense, "
                    "or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, "
                    "please don't share false information."
                )
                conv.system_message = sys_p
            # breakpoint()
            warm_turns = [warm_q["question"]] if bench_name == "gsm8k" else warm_q["turns"]
            conv.append_message(conv.roles[0], warm_turns[0])
            conv.append_message(conv.roles[1], None)
            prompt = conv.get_prompt() + " "
            input_ids = tokenizer([prompt]).input_ids
            input_ids_t = torch.as_tensor(input_ids).to("cuda")

            send_json_with_size(sock, {"type": "init", "input_ids": input_ids[0]})
            reply, _ = recv_json_with_size(sock)
            if reply.get("type") != "init_ok":
                break
            current_next_token = reply["next_token"]

            warm_steps = 0
            while True:
                draft_ids, draft_pos, tree_mask, parent, tree_depth, final_nnodes = build_tree_with_next_token(
                    runner, input_ids_t, nodes, threshold, max_depth, current_next_token, tokenizer, debug, print_tree=False, per_token_probability_bound=per_token_probability_bound, per_path_probability_bound=per_path_probability_bound
                )
                payload = {
                    "type": "tree_step",
                    "draft_input_ids": draft_ids[0].tolist(),
                    "draft_position_ids": draft_pos.tolist(),
                    "tree_attention_mask": tree_mask.tolist(),
                    "parent": parent.tolist(),
                }
                # Draft → Target 전송 시간 측정: Draft가 보내기 시작하는 시점
                send_start_time = time.time()
                send_json_with_size(sock, payload)
                
                # Target → Draft 전송 시간 측정: Draft가 Target의 응답을 다 받은 시점
                reply, _ = recv_json_with_size(sock)
                recv_end_time = time.time()
                if reply.get("type") != "verify_result":
                    break
                accepted_tokens: List[int] = reply["accepted_tokens"]
                current_next_token = reply["next_token"]
                eos_reached: bool = reply["eos_reached"]
                best_ids: List[int] = reply["best_ids"]
                base_input_len: int = reply.get("base_input_len", input_ids_t.shape[1])
                
                
                
                # TODO:Accept된 경로의 KV만 유지
                # base_kv_len은 draft() 호출 전 input_ids 길이 (old_input_ids)
                # 하지만 draft_stable_kv는 draft() 호출 후 상태이므로,
                # base_kv_len을 draft_stable_kv의 이전 길이로 추정해야 함
                # base_kv_len = base_input_len
                # update_kv_with_accepted(runner, best_ids, base_kv_len, current_next_token, debug)
                # print(runner.draft_stable_kv[0][0].shape[2])
                
                input_ids_t = torch.cat([
                    input_ids_t,
                    torch.tensor([accepted_tokens], device=input_ids_t.device, dtype=torch.long),
                ], dim=-1)
                
                # 이전 tree의 정보 저장 (warmup 루프에서도 업데이트)
                # timing_stats에서 total_time_seconds 추출, 없으면 네트워크 왕복 시간 사용
                timing_stats = reply.get("timing_stats", {})
                # total_time = timing_stats.get("total_time_seconds", None)
                # if total_time is None:
                # 전체 왕복 시간 계산 (Draft → Target → Draft)
                total_time = recv_end_time - send_start_time
                
                runner.prev_tree_final_width = final_nnodes
                runner.prev_tree_depth = tree_depth
                runner.prev_tree_total_target_time = total_time
                
                warm_steps += 1
                if eos_reached or warm_steps > 5 or input_ids_t.shape[1] > 512:
                    break

        # Warmup 종료 후 통계 리셋
        runner.reset_timing_stats()
        print("Warmup done")
        
        # 프로파일링: width별 평균 처리시간 측정
        if device_name:
            # 프로파일링 파일 경로 확인
            script_dir = os.path.dirname(__file__)
            parent_dir = os.path.dirname(script_dir)
            profile_dir = os.path.join(parent_dir, "data", "profile")
            
            # 모델 이름 추출
            draft_model_name = draft_model_path.split("/")[-1] if "/" in draft_model_path else draft_model_path
            base_model_name = base_model_path.split("/")[-1] if "/" in base_model_path else base_model_path
            
            # 프로파일링 파일 경로
            draft_profile_file = os.path.join(profile_dir, f"{device_name}_{draft_model_name}_{bench_name}_draft.json")
            target_profile_file = os.path.join(profile_dir, f"{device_name}_{base_model_name}_{bench_name}_target.json")
            
            # 두 파일이 모두 존재하는지 확인
            draft_exists = os.path.exists(draft_profile_file)
            target_exists = os.path.exists(target_profile_file)
            
            if draft_exists and target_exists:
                print(f"\n프로파일링 파일이 이미 존재합니다:")
                print(f"  Draft: {draft_profile_file}")
                print(f"  Target: {target_profile_file}")
                print("프로파일링 단계를 스킵하고 기존 데이터를 사용합니다.\n")
            else:
                # 프로파일링할 width 리스트 (실험에 사용할 width)
                width_list = [5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]  # 필요시 argparse로 받을 수 있도록 수정 가능
                
                if not draft_exists:
                    print(f"Draft 프로파일링 파일이 없습니다. 프로파일링을 시작합니다: {draft_profile_file}")
                    profile_data = profile_width_timing(
                        runner=runner,
                        tokenizer=tokenizer,
                        threshold=threshold,
                        max_depth=max_depth,
                        draft_model_path=draft_model_path,
                        device_name=device_name,
                        question_file=question_file,
                        bench_name=bench_name,
                        width_list=width_list,
                        num_runs_per_width=1000,  # 각 width당 실행 횟수
                    )
                    if profile_data:
                        print(f"Draft 프로파일링 완료: {len(profile_data)}개의 width에 대한 데이터 수집")
                else:
                    print(f"Draft 프로파일링 파일이 이미 존재합니다: {draft_profile_file}")
                
                if not target_exists:
                    print(f"Target 프로파일링 파일이 없습니다. Target 프로파일링은 별도로 실행해야 합니다: {target_profile_file}")
                else:
                    print(f"Target 프로파일링 파일이 이미 존재합니다: {target_profile_file}")

        
        grand_total_steps = 0
        grand_total_accepted = 0
        grand_total_draft_tokens = 0
        grand_total_new_tokens = 0
        run_start_time = time.time()

        # 네트워크/accept 통계 집계용
        network_latency_records = []
        global_draft_to_target_times = []
        global_target_to_draft_times = []
        global_accept_lengths = []
        global_t2d_per_accept_len = {}

        choices_list = []
        
        for question in tqdm(questions):
            # breakpoint()
            choices = []
            draft_to_target_time_per_question = []
            target_to_draft_time_per_question = []
            accept_length_per_question = []
            t2d_per_accept_len_per_question = {}
            # 전송/수신 데이터 크기 기록
            draft_to_target_bytes_per_question = []
            target_to_draft_bytes_per_question = []

            
            for i in range(num_choices):
                torch.manual_seed(i)
                # 각 question마다 KV cache 리셋
                runner.reset_kv()
                
                # 대화 템플릿 준비
                if "vicuna" in base_model_path:
                    conv = get_conversation_template("vicuna")
                else:
                    conv = get_conversation_template("llama-2-chat")
                    sys_p = (
                        "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  "
                        "Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. "
                        "Please ensure that your responses are socially unbiased and positive in nature. If a question does not make any sense, "
                        "or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, "
                        "please don't share false information."
                    )
                    conv.system_message = sys_p

                if bench_name == "gsm8k":
                    question_turns = [question["question"]]
                else:
                    question_turns = question["turns"]

                turns = []
                idxs = []
                new_tokens_list = []
                wall_time_list = []
                for j in range(len(question_turns)):
                    qs = question_turns[j]
                    conv.append_message(conv.roles[0], qs)
                    conv.append_message(conv.roles[1], None)
                    prompt = conv.get_prompt() + " "
                    input_ids = tokenizer([prompt]).input_ids
                    input_ids_t = torch.as_tensor(input_ids).to("cuda")


                    # 초기 base 토큰 1개는 target에게 요청
                    draft_send_start_time = time.time()
                    d2t_bytes = send_json_with_size(sock, {"type": "init", "input_ids": input_ids[0]})
                    reply, t2d_bytes = recv_json_with_size(sock)
                    draft_recv_end_time = time.time()
                    
                    # 전송/수신 크기 기록
                    draft_to_target_bytes_per_question.append(d2t_bytes)
                    target_to_draft_bytes_per_question.append(t2d_bytes)

                    # 전송 시간 계산
                    target_recv_end_time = reply.get("target_recv_end_time", None)
                    target_send_start_time = reply.get("target_send_start_time", None)
                    # Draft → Target 전송 시간
                    draft_to_target_time = None
                    if target_recv_end_time is not None :
                        draft_to_target_time = (target_recv_end_time - draft_send_start_time) * 1000.0  # ms
                        draft_to_target_time_per_question.append(draft_to_target_time)
    
                    # Target → Draft 전송 시간
                    target_to_draft_time = None
                    if target_send_start_time is not None:
                        target_to_draft_time = (draft_recv_end_time - target_send_start_time) * 1000.0  # ms
                        target_to_draft_time_per_question.append(target_to_draft_time)
                        if 1 not in t2d_per_accept_len_per_question:
                            t2d_per_accept_len_per_question[0] = []
                        t2d_per_accept_len_per_question[0].append(target_to_draft_time)
                    
                    accept_length_per_question.append(0)

                    
                    assert reply.get("type") == "init_ok"
                    current_next_token = reply["next_token"]

                    output_tokens: List[int] = []
                    new_token_count = 0
                    turn_steps = 0
                    
                    torch.cuda.synchronize()
                    turn_start_time = time.time()

                    while True:
                        # 드래프트 트리 생성 (타겟이 보낸 next_token을 사용)
                        # input_ids_t (이전 timeslot의 accepted tokens 포함) + next_token을 사용
                        draft_ids, draft_pos, tree_mask, parent, tree_depth, final_nnodes = build_tree_with_next_token(
                            runner, input_ids_t, nodes, threshold, max_depth, current_next_token, tokenizer, debug, print_tree, per_token_probability_bound=per_token_probability_bound, per_path_probability_bound=per_path_probability_bound
                        )
                        # target에게 검증 요청
                        payload = {
                            "type": "tree_step",
                            "draft_input_ids": draft_ids[0].tolist(),
                            "draft_position_ids": draft_pos.tolist(),
                            "tree_attention_mask": tree_mask.tolist(),
                            "parent": parent.tolist(),
                        }
                        # Draft → Target 전송 시간 측정: Draft가 보내기 시작하는 시점
                        draft_send_start_time = time.time()
                        d2t_bytes = send_json_with_size(sock, payload)

                        # Target → Draft 전송 시간 측정: Draft가 Target의 응답을 다 받은 시점
                        reply, t2d_bytes = recv_json_with_size(sock)
                        draft_recv_end_time = time.time()
                        
                        # 전송/수신 크기 기록
                        draft_to_target_bytes_per_question.append(d2t_bytes)
                        target_to_draft_bytes_per_question.append(t2d_bytes)
                        assert reply.get("type") == "verify_result"
                        accepted_tokens: List[int] = reply["accepted_tokens"]
                        accept_length: int = reply["accept_length"]
                        next_token: int = reply["next_token"]
                        eos_reached: bool = reply["eos_reached"]
                        best_ids: List[int] = reply["best_ids"]
                        
                        # 전송 시간 계산
                        target_recv_end_time = reply.get("target_recv_end_time", None)
                        target_send_start_time = reply.get("target_send_start_time", None)
                        
                        # Draft → Target 전송 시간
                        draft_to_target_time = None
                        if target_recv_end_time is not None :
                            draft_to_target_time = (target_recv_end_time - draft_send_start_time) * 1000.0  # ms
                            draft_to_target_time_per_question.append(draft_to_target_time)
                        
                        # Target → Draft 전송 시간
                        target_to_draft_time = None
                        if target_send_start_time is not None:
                            target_to_draft_time = (draft_recv_end_time - target_send_start_time) * 1000.0  # ms
                            target_to_draft_time_per_question.append(target_to_draft_time)
                            if accept_length not in t2d_per_accept_len_per_question:
                                t2d_per_accept_len_per_question[accept_length] = []
                            t2d_per_accept_len_per_question[accept_length].append(target_to_draft_time)
                        
                        # 디버그 출력 (선택사항)
                        if debug:
                            print(f"[DRAFT-DEBUG] Draft → Target 전송 시간: {draft_to_target_time:.3f}ms")
                            print(f"[DRAFT-DEBUG] Target → Draft 전송 시간: {target_to_draft_time:.3f}ms")
                            print(f"[DRAFT-DEBUG] Draft → Target 전송 크기: {d2t_bytes}bytes")
                            print(f"[DRAFT-DEBUG] Target → Draft 전송 크기: {t2d_bytes}bytes")
                        
                        # 이전 tree의 정보 저장 (다음 tree 생성 시 사용)
                        # timing_stats에서 total_time_seconds 추출, 없으면 네트워크 왕복 시간 사용
                        timing_stats = reply.get("timing_stats", {})
                        # total_time = timing_stats.get("total_time_seconds", None)
                        # if total_time is None:
                        # 전체 왕복 시간 계산 (Draft → Target → Draft)
                        total_time = target_recv_end_time - draft_send_start_time
                        
                        runner.prev_tree_final_width = final_nnodes
                        runner.prev_tree_depth = tree_depth
                        runner.prev_tree_total_target_time = total_time

                        # TODO:Accept된 경로의 KV만 유지
                        # base_kv_len = input_ids_t.shape[1]
                        # update_kv_with_accepted(runner, best_ids, base_kv_len, next_token, debug)

                        # 수락된 토큰들을 입력에 붙임. input_ids_t + accepted_tokens
                        input_ids_t = torch.cat([
                            input_ids_t,
                            torch.tensor([accepted_tokens], device=input_ids_t.device, dtype=torch.long),
                        ], dim=-1)

                        output_tokens.extend(accepted_tokens)
                        new_token_count += accept_length + 1
                        turn_steps += 1

                        # 통계 누적
                        grand_total_steps += 1
                        grand_total_accepted += accept_length
                        grand_total_draft_tokens += int(tree_depth)
                        # accept_length 누적
                        # accept_length_list.append(int(accept_length))
                        accept_length_per_question.append(int(accept_length))

                        # 다음 라운드를 위해 최신 next_token 저장
                        current_next_token = next_token

                        if eos_reached or new_token_count > 1024 or input_ids_t.shape[1] > 1960:
                            break
                    
                    torch.cuda.synchronize()
                    turn_end_time = time.time()
                    turn_wall_time = turn_end_time - turn_start_time
                    
                    # 질문이 끝났을 때 depth별 add() 함수 실행 시간 통계 출력
                    runner.print_timing_stats()
                    runner.reset_timing_stats()  # 다음 질문을 위해 통계 리셋

                    # Stop token 처리 (원본과 동일하게)
                    if conv.stop_token_ids:
                        stop_token_ids_index = [
                            idx
                            for idx, token_id in enumerate(output_tokens)
                            if token_id in conv.stop_token_ids
                        ]
                        if len(stop_token_ids_index) > 0:
                            output_tokens = output_tokens[:stop_token_ids_index[0]]
                    
                    # 디코딩
                    decoded = tokenizer.decode(output_tokens, spaces_between_special_tokens=False)
                    
                    # Stop string 처리
                    if conv.stop_str and decoded.find(conv.stop_str) > 0:
                        decoded = decoded[:decoded.find(conv.stop_str)]
                    
                    # Special token 제거
                    for special_token in tokenizer.special_tokens_map.values():
                        if isinstance(special_token, list):
                            for special_tok in special_token:
                                decoded = decoded.replace(special_tok, "")
                        else:
                            decoded = decoded.replace(special_token, "")
                    
                    decoded = decoded.strip()
                    
                    if conv.name == "xgen" and decoded.startswith("Assistant:"):
                        decoded = decoded.replace("Assistant:", "", 1).strip()

                    turns.append(decoded)
                    idxs.append(int(turn_steps))
                    new_tokens_list.append(int(new_token_count))
                    wall_time_list.append(turn_wall_time)
                    
                    conv.messages[-1][-1] = decoded

                # 질문별 시간 측정
                avg_draft_to_target = float(sum(draft_to_target_time_per_question) / len(draft_to_target_time_per_question)) if draft_to_target_time_per_question else None
                avg_target_to_draft = float(sum(target_to_draft_time_per_question) / len(target_to_draft_time_per_question)) if target_to_draft_time_per_question else None
                avg_accept_length = float(sum(accept_length_per_question) / len(accept_length_per_question)) if accept_length_per_question else None
                accept_len_bucket_stats = {}
                for length, times in t2d_per_accept_len_per_question.items():
                    if not times:
                        continue
                    accept_len_bucket_stats[int(length)] = {
                        "count": len(times),
                        "avg_target_to_draft_time_ms": float(sum(times) / len(times)),
                        "min_target_to_draft_time_ms": float(min(times)),
                        "max_target_to_draft_time_ms": float(max(times)),
                        "times_ms": [float(t) for t in times],
                    }
                

                choices.append({
                    "index": i, 
                    "turns": turns, 
                    "idxs": idxs, 
                    "new_tokens": new_tokens_list, 
                    "wall_time": wall_time_list,
                })

            # 질문별 네트워크/accept 통계 기록
            network_latency_records.append({
                "question_id": question["question_id"],
                "draft_to_target_time_ms": draft_to_target_time_per_question,
                "target_to_draft_time_ms": target_to_draft_time_per_question,
                "draft_to_target_bytes": draft_to_target_bytes_per_question,
                "target_to_draft_bytes": target_to_draft_bytes_per_question,
                "accept_length": accept_length_per_question,
                "avg_draft_to_target_time_ms": avg_draft_to_target,
                "avg_target_to_draft_time_ms": avg_target_to_draft,
                "avg_accept_length": avg_accept_length,
                "accept_length_bucket_stats": accept_len_bucket_stats,
            })

            global_draft_to_target_times.extend(draft_to_target_time_per_question)
            global_target_to_draft_times.extend(target_to_draft_time_per_question)
            global_accept_lengths.extend(accept_length_per_question)
            for length, times in t2d_per_accept_len_per_question.items():
                if length not in global_t2d_per_accept_len:
                    global_t2d_per_accept_len[length] = []
                global_t2d_per_accept_len[length].extend(times)
            
            # Dump answers
            if answer_file:
                os.makedirs(os.path.dirname(answer_file), exist_ok=True)
                with open(os.path.expanduser(answer_file), "a") as fout:
                    ans_json = {
                        "question_id": question["question_id"],
                        "answer_id": shortuuid.uuid(),
                        "model_id": model_id,
                        "choices": choices,
                        "tstamp": time.time(),
                    }
                    fout.write(json.dumps(ans_json) + "\n")

        # 전체 결과 요약 출력 (원본 포맷과 정렬)
        total_time = max(1e-6, time.time() - run_start_time)
        tokens_per_step = (grand_total_accepted + grand_total_steps) / max(1, grand_total_steps)  # (accept_length+1)의 평균
        tokens_per_second = (grand_total_accepted + grand_total_steps) / total_time
        avg_tree_depth = (grand_total_draft_tokens / max(1, grand_total_steps)) if grand_total_steps > 0 else 0.0
        avg_accept_length = (grand_total_accepted / max(1, grand_total_steps)) if grand_total_steps > 0 else 0.0

        print(
            "total_steps: {}  | total_new_tokens: {}  | total_time: {:.2f}  | tokens per step: {:.2f}  | tokens per second: {:.2f}  | avg_tree_depth: {:.2f}".format(
                grand_total_steps,
                grand_total_accepted + grand_total_steps,
                total_time,
                tokens_per_step,
                tokens_per_second,
                avg_tree_depth,
            )
        )
        # 추가 지표(참고): 평균 accept length도 함께 출력
        print(
            "avg_accept_length: {:.4f}  acceptance_ratio_avg: {:.4f}".format(
                avg_accept_length,  # next token 미포함
                (grand_total_accepted / max(1, grand_total_draft_tokens)) if grand_total_draft_tokens > 0 else 0.0,
            )
        )

        # 네트워크 레이턴시/accept 통계 파일 저장 (dictionary 형태)
        global_avg_draft = float(sum(global_draft_to_target_times) / len(global_draft_to_target_times)) if global_draft_to_target_times else None
        global_avg_target = float(sum(global_target_to_draft_times) / len(global_target_to_draft_times)) if global_target_to_draft_times else None
        global_avg_accept = float(sum(global_accept_lengths) / len(global_accept_lengths)) if global_accept_lengths else None
        global_accept_len_bucket_stats = {}
        for length, times in global_t2d_per_accept_len.items():
            if not times:
                continue
            global_accept_len_bucket_stats[int(length)] = {
                "count": len(times),
                "avg_target_to_draft_time_ms": float(sum(times) / len(times)),
                "min_target_to_draft_time_ms": float(min(times)),
                "max_target_to_draft_time_ms": float(max(times)),
            }
        

        latency_result = {
            "experiment_info": {
                "draft_model": draft_model_path,
                "base_model": base_model_path,
                "bench_name": bench_name,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "nodes": nodes,
                "threshold": threshold,
                "max_depth": max_depth,
                "temperature": temperature,
            },
            "global": {
                "avg_draft_to_target_time_ms": global_avg_draft,
                "avg_target_to_draft_time_ms": global_avg_target,
                "avg_accept_length": global_avg_accept,
                "total_steps": grand_total_steps,
                "accept_length_bucket_stats": global_accept_len_bucket_stats,
            },
            "questions": network_latency_records,
        }

        script_dir = os.path.dirname(__file__)
        parent_dir = os.path.dirname(script_dir)
        latency_dir = os.path.join(parent_dir, "result", "network_latency")
        os.makedirs(latency_dir, exist_ok=True)
        latency_file = os.path.join(latency_dir, f"draft_{bench_name}_network_latency_nodes{nodes}.json")
        with open(latency_file, "w") as f:
            json.dump(latency_result, f, indent=2)
        print(f"네트워크 지연 및 accept 통계를 저장했습니다: {latency_file}")
        
        # Depth별 통계를 JSON 파일로 저장
        if runner.accumulated_depth_stats:
            # 모델 이름 추출
            draft_model_name = draft_model_path.split("/")[-1] if "/" in draft_model_path else draft_model_path
            base_model_name = base_model_path.split("/")[-1] if "/" in base_model_path else base_model_path
            
            # 저장 디렉토리 생성
            script_dir = os.path.dirname(__file__)
            parent_dir = os.path.dirname(script_dir)
            output_dir = os.path.join(parent_dir, "result", "model_characteristic")
            os.makedirs(output_dir, exist_ok=True)
            
            # 파일 이름 생성: draft_model_name_device_name_bench_name_timestamp.json
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            if device_name:
                filename = f"{draft_model_name}_{device_name}_{bench_name}_{timestamp}.json"
            else:
                filename = f"{draft_model_name}_{bench_name}_{timestamp}.json"
            output_file = os.path.join(output_dir, filename)
            
            # Depth별 통계 계산 (최소, 최대, 평균)
            depth_statistics = {}
            depth_statistics_short = {}
            for depth, stats in runner.accumulated_depth_stats.items():
                depth_statistics[depth] = {}
                depth_statistics_short[depth] = {}
                for key, values in stats.items():
                    if len(values) > 0:
                        mean_value = float(sum(values) / len(values))
                        depth_statistics[depth][key] = {
                            "count": len(values),
                            "min": float(min(values)),
                            "max": float(max(values)),
                            "mean": mean_value,
                            "sum": float(sum(values)),
                            "all_values": [float(v) for v in values]  # 모든 값도 저장 (선택사항)
                        }
                        # short 버전에는 mean 값만 저장
                        depth_statistics_short[depth][key] = mean_value
                    else:
                        depth_statistics[depth][key] = {
                            "count": 0,
                            "min": None,
                            "max": None,
                            "mean": None,
                            "sum": 0.0,
                            "all_values": []
                        }
                        depth_statistics_short[depth][key] = None
            
            # JSON 파일로 저장
            output_data = {
                "experiment_info": {
                    "draft_model": draft_model_path,
                    "base_model": base_model_path,
                    "bench_name": bench_name,
                    "device_name": device_name,
                    "timestamp": timestamp,
                    "experiment_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "nodes": nodes,
                    "threshold": threshold,
                    "max_depth": max_depth,
                    "draft_per_sec_cost": draft_per_hour_cost / 3600.0 if draft_per_hour_cost else 0.0,
                    "target_per_sec_cost": target_per_hour_cost / 3600.0 if target_per_hour_cost else 0.0,
                    "cost_sensitivity": cost_sensitivity,
                },
                "depth_statistics": depth_statistics,
                "depth_statistics_short": depth_statistics_short
            }
            
            with open(output_file, 'w') as f:
                json.dump(output_data, f, indent=2)
            
            print(f"\nDepth별 통계가 저장되었습니다: {output_file}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", type=str, default="127.0.0.1")
    parser.add_argument("--port", type=int, default=26001)
    parser.add_argument("--base-model-path", type=str, required=True)
    parser.add_argument("--draft-model-path", type=str, required=True)
    parser.add_argument("--bench-name", type=str, choices=["mt_bench", "gsm8k"], required=True)
    parser.add_argument("--question-file", type=str, default=None)
    parser.add_argument("--limit", type=int, default=0, help="Limit number of questions")
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--nodes", type=int, default=50)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--max_depth", type=int, default=10)
    parser.add_argument("--device-map", type=str, default="cuda:0")
    parser.add_argument("--load-in-4bit", action="store_true")
    parser.add_argument("--load-in-8bit", action="store_true")
    parser.add_argument("--answer-file", type=str, default=None, help="Output answer file")
    parser.add_argument("--model-id", type=str, default="llama-2-chat", help="Model ID")
    parser.add_argument("--num-choices", type=int, default=1, help="Number of completion choices")
    parser.add_argument("--debug", action="store_true", default=False, help="Enable debug output (DRAFT-DEBUG messages)")
    parser.add_argument("--print-tree", action="store_true", default=False, help="Print tree structure during expansion")
    parser.add_argument("--per-token-probability-bound", type=float, default=0.0, help="Probability bound for each token (default: 0.0)")
    parser.add_argument("--per-path-probability-bound", type=float, default=0.0, help="Probability bound for each path (default: 0.0)")
    parser.add_argument("--device-name", type=str, default=None, help="Device name for profiling (e.g., rtx5080). If provided, profiles width timing after warmup.")
    parser.add_argument("--draft-per-hour-cost", type=float, default=0.0, help="Draft model cost per hour (default: 0.0)")
    parser.add_argument("--target-per-hour-cost", type=float, default=0.0, help="Target model cost per hour (default: 0.0)")
    parser.add_argument("--cost-sensitivity", type=float, default=0.0, help="Cost sensitivity factor (0 to infinity, default: 0.0)")
    args = parser.parse_args()

    if args.question_file:
        question_file = args.question_file
    else:
        if args.bench_name == "mt_bench":
            script_dir = os.path.dirname(__file__)
            parent_dir = os.path.dirname(script_dir)
            question_file = f"{parent_dir}/data/mt_bench/question.jsonl"
        elif args.bench_name == "gsm8k":
            script_dir = os.path.dirname(__file__)
            parent_dir = os.path.dirname(script_dir)
            question_file = f"{parent_dir}/data/gsm8k.jsonl"
        else:
            raise ValueError("Undefined bench_name")

    # answer_file이 제공되지 않으면 기본값 생성
    if args.answer_file is None:
        script_dir = os.path.dirname(__file__)
        parent_dir = os.path.dirname(script_dir)
        args.answer_file = f"{parent_dir}/result/draft_answers_{args.bench_name}.jsonl"
    
    # model_id에 temperature 추가 (원본과 동일)
    args.model_id = args.model_id + "-temperature-" + str(args.temperature)
    
    print(f"Output to {args.answer_file}")
    
    run_draft(
        host=args.host,
        port=args.port,
        base_model_path=args.base_model_path,
        draft_model_path=args.draft_model_path,
        bench_name=args.bench_name,
        question_file=question_file,
        draft_per_hour_cost=args.draft_per_hour_cost,
        target_per_hour_cost=args.target_per_hour_cost,
        cost_sensitivity=args.cost_sensitivity,
        limit=args.limit,
        temperature=args.temperature,
        nodes=args.nodes,
        threshold=args.threshold,
        max_depth=args.max_depth,
        device_map=args.device_map,
        load_in_4bit=args.load_in_4bit,
        load_in_8bit=args.load_in_8bit,
        answer_file=args.answer_file,
        model_id=args.model_id,
        num_choices=args.num_choices,
        debug=args.debug,
        print_tree=args.print_tree,
        per_token_probability_bound=args.per_token_probability_bound,
        per_path_probability_bound=args.per_path_probability_bound,
        device_name=args.device_name,
    )
    
    # answer_file 정리 (reorg_answer_file과 유사한 기능)
    if args.answer_file:
        def reorg_answer_file(answer_file):
            """Sort by question id and de-duplication"""
            answers = {}
            with open(answer_file, "r") as fin:
                for l in fin:
                    qid = json.loads(l)["question_id"]
                    answers[qid] = l

            qids = sorted(list(answers.keys()))
            with open(answer_file, "w") as fout:
                for qid in qids:
                    fout.write(answers[qid])
        
        reorg_answer_file(args.answer_file)


