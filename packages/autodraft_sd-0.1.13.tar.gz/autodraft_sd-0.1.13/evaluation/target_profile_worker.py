import argparse
import importlib
import json
import os
import random
import sys
import time
from pathlib import Path
from typing import Any, Dict, List

import torch
from fastchat.llm_judge.common import load_questions
from fastchat.model import get_conversation_template
from transformers import AutoTokenizer

from evaluation.eval_opt_classic_draft_target_profile import DraftRunner, build_tree_with_next_token

TARGET_PROFILE_FIXED_WIDTH = 50
TARGET_PROFILE_FIXED_DEPTH = 10


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    try:
        import numpy as np
        np.random.seed(seed)
    except ImportError:
        pass


def set_deterministic() -> None:
    torch.use_deterministic_algorithms(True, warn_only=True)
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")


def _read_json_line() -> Dict[str, Any]:
    line = sys.stdin.readline()
    if not line:
        raise RuntimeError("IPC stdin closed")
    return json.loads(line.strip())


def _write_json_line(payload: Dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(payload) + "\n")
    sys.stdout.flush()


def get_kv_llama_class(model_path: str):
    model_path_l = (model_path or "").lower()
    is_llama3_family = ("llama-3" in model_path_l) or ("llama3" in model_path_l)
    is_qwen3_family = ("qwen3" in model_path_l) or ("qwen-3" in model_path_l) or ("qwen/qwen3" in model_path_l)
    is_qwen2_family = (not is_qwen3_family) and (
        ("qwen2" in model_path_l) or ("qwen-2" in model_path_l) or ("qwen/qwen2" in model_path_l)
    )

    if is_qwen3_family:
        module_name, class_name = "opt_classic.modeling_qwen3_kv", "Qwen3ForCausalLM"
    elif is_qwen2_family:
        module_name, class_name = "opt_classic.modeling_qwen2_kv", "Qwen2ForCausalLM"
    elif is_llama3_family:
        module_name, class_name = "opt_classic.modeling_llama3_kv", "LlamaForCausalLM"
    else:
        module_name, class_name = "opt_classic.modeling_llama_kv", "LlamaForCausalLM"

    try:
        mod = importlib.import_module(module_name)
        return getattr(mod, class_name)
    except Exception as e:
        raise RuntimeError(f"Failed to import {module_name}.{class_name}: {e}")


def _parse_int_list(raw: str) -> List[int]:
    out: List[int] = []
    for tok in (raw or "").split(","):
        tok = tok.strip()
        if not tok:
            continue
        out.append(int(tok))
    return out


def _load_profile_question(bench_name: str, question_file: str) -> Dict[str, Any]:
    """Load one profiling question compatible with draft side benchmark semantics."""
    bench = str(bench_name or "").strip().lower()
    qf = str(question_file or "").strip()
    if qf and os.path.exists(qf):
        questions = load_questions(qf, None, None)
        if questions:
            return questions[0]
    repo_root = Path(__file__).resolve().parent.parent
    if bench == "mt_bench":
        resolved = repo_root / "data" / "mt_bench" / "question.jsonl"
        if not resolved.exists():
            raise RuntimeError(f"default question file missing on target: {resolved}")
        questions = load_questions(str(resolved), None, None)
        if not questions:
            raise RuntimeError("empty mt_bench question set")
        return questions[0]
    if bench == "gsm8k":
        resolved = repo_root / "data" / "gsm8k.jsonl"
        if not resolved.exists():
            raise RuntimeError(f"default question file missing on target: {resolved}")
        questions = load_questions(str(resolved), None, None)
        if not questions:
            raise RuntimeError("empty gsm8k question set")
        return questions[0]
    if bench == "humaneval":
        from datasets import load_dataset

        ds = load_dataset("openai_humaneval")["test"]
        if len(ds) == 0:
            raise RuntimeError("empty humaneval test split")
        ex = ds[0]
        return {"question_id": ex["task_id"], "question": ex["prompt"]}
    if bench == "cnn_dailymail":
        from datasets import load_dataset

        ds = load_dataset("abisee/cnn_dailymail", "1.0.0")["test"]
        if len(ds) == 0:
            raise RuntimeError("empty cnn_dailymail test split")
        ex = ds[0]
        return {"question_id": ex["id"], "question": ex["article"]}
    raise RuntimeError(f"unsupported bench_name: {bench_name}")


def _extract_turns(profile_q: Dict[str, Any], bench_name: str) -> List[str]:
    bench = str(bench_name or "").strip().lower()
    if bench in {"gsm8k", "humaneval", "cnn_dailymail"}:
        q = profile_q.get("question", "")
        return [q] if isinstance(q, str) and q else [str(q)]
    turns = profile_q.get("turns", [])
    if isinstance(turns, list) and turns:
        return turns
    q = profile_q.get("question", "")
    return [q] if isinstance(q, str) and q else [str(q)]


def _build_prompt(base_model_path: str, bench_name: str, question_file: str) -> str:
    profile_q = _load_profile_question(bench_name, question_file)
    if "vicuna" in base_model_path:
        conv = get_conversation_template("vicuna")
    else:
        conv = get_conversation_template("llama-2-chat")
        conv.system_message = (
            "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe. "
            "Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. "
            "Please ensure that your responses are socially unbiased and positive in nature. If a question does not make any sense, "
            "or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, "
            "please don't share false information."
        )
    turns = _extract_turns(profile_q, bench_name)
    if not turns:
        turns = ["Explain speculative decoding in one sentence."]
    conv.append_message(conv.roles[0], turns[0])
    conv.append_message(conv.roles[1], None)
    return conv.get_prompt() + " "


def _resolve_question_file(bench_name: str, question_file: str) -> str:
    bench = str(bench_name or "").strip().lower()
    if bench in {"humaneval", "cnn_dailymail"}:
        # HF dataset 기반 벤치는 파일 경로가 필수가 아니다.
        return ""
    if question_file:
        if os.path.exists(question_file):
            return question_file
        raise RuntimeError(f"question_file not found on target: {question_file}")

    script_dir = os.path.dirname(__file__)
    repo_root = os.path.dirname(script_dir)
    if bench == "mt_bench":
        resolved = os.path.join(repo_root, "data", "mt_bench", "question.jsonl")
    elif bench == "gsm8k":
        resolved = os.path.join(repo_root, "data", "gsm8k.jsonl")
    else:
        raise RuntimeError(f"unsupported bench_name for default question file: {bench_name}")

    if not os.path.exists(resolved):
        raise RuntimeError(f"default question file missing on target: {resolved}")
    return resolved


def _derive_tree_depth_from_parent(parent: List[int]) -> int:
    if not parent:
        return 0
    max_depth = 0
    for i in range(len(parent)):
        depth = 1
        cur = i
        seen = set()
        while True:
            if cur in seen:
                break
            seen.add(cur)
            p = int(parent[cur])
            if p == cur or p < 0 or p >= len(parent):
                break
            depth += 1
            cur = p
        if depth > max_depth:
            max_depth = depth
    return int(max_depth)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-model-path", type=str, required=True)
    parser.add_argument("--draft-model-path", type=str, required=True)
    parser.add_argument("--bench-name", type=str, default="mt_bench")
    parser.add_argument("--question-file", type=str, default="")
    parser.add_argument("--width-list", type=str, required=True)
    parser.add_argument("--depth-list", type=str, required=True)
    parser.add_argument("--node-list", type=str, required=True)
    parser.add_argument("--runs-per-combination", type=int, default=100)
    parser.add_argument("--device-map", type=str, default="cuda:0")
    parser.add_argument("--draft-quantization", type=str, default="none")
    parser.add_argument("--threshold", type=float, default=1.0)
    parser.add_argument("--profile-warmup-runs", type=int, default=2)
    parser.add_argument("--profile-burnin-runs", type=int, default=1)
    parser.add_argument("--deterministic", action="store_true")
    args = parser.parse_args()

    if args.deterministic:
        set_seed(4)
        set_deterministic()

    quantization_config = None
    draft_quantization = str(args.draft_quantization or "none").strip().lower()
    if draft_quantization == "8bit":
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_8bit=True,
            llm_int8_threshold=6.0,
            llm_int8_skip_modules=["lm_head"],
        )
    elif draft_quantization == "4bit":
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
        )

    KVLlamaForCausalLM = get_kv_llama_class(args.draft_model_path)
    draft_model = KVLlamaForCausalLM.from_pretrained(
        args.draft_model_path,
        torch_dtype=torch.float16,
        low_cpu_mem_usage=True,
        device_map=args.device_map,
        quantization_config=quantization_config,
        token="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",
    )
    tokenizer = AutoTokenizer.from_pretrained(
        args.base_model_path,
        token="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",
    )
    runner = DraftRunner(draft_model=draft_model, tokenizer=tokenizer, debug=False)
    node_list = _parse_int_list(args.node_list)
    resolved_question_file = _resolve_question_file(args.bench_name, args.question_file)
    prompt = _build_prompt(args.base_model_path, args.bench_name, resolved_question_file)
    input_ids = tokenizer([prompt]).input_ids
    input_ids_t = torch.as_tensor(input_ids).to(draft_model.lm_head.weight.device)

    max_nodes_cap = int(TARGET_PROFILE_FIXED_WIDTH * TARGET_PROFILE_FIXED_DEPTH)
    valid_nodes: List[int] = sorted({int(n) for n in node_list if int(n) > 0 and int(n) <= max_nodes_cap})
    if not valid_nodes:
        raise RuntimeError(
            f"no valid max_nnodes values for fixed tree (width={TARGET_PROFILE_FIXED_WIDTH}, depth={TARGET_PROFILE_FIXED_DEPTH})"
        )

    warmup_runs = max(0, int(args.profile_warmup_runs))
    burnin_runs = max(0, int(args.profile_burnin_runs))
    measure_runs = max(1, int(args.runs_per_combination))
    total_runs_per_combo = warmup_runs + burnin_runs + measure_runs

    cached_next_token: int = -1
    cached_base_tree: Dict[str, Any] = {}
    cached_trees_by_nodes: Dict[int, Dict[str, Any]] = {}

    for max_nnodes in valid_nodes:
        for run_idx in range(total_runs_per_combo):
            if run_idx < warmup_runs:
                profile_phase = "warmup"
            elif run_idx < (warmup_runs + burnin_runs):
                profile_phase = "burnin"
            else:
                profile_phase = "measure"
            runner.reset_kv()
            _write_json_line({"type": "request_init", "input_ids": input_ids[0]})
            init_reply = _read_json_line()
            if init_reply.get("type") != "init_ok":
                raise RuntimeError(f"unexpected init reply: {init_reply}")
            current_next_token = int(init_reply["next_token"])
            if current_next_token != cached_next_token:
                cached_base_tree = {}
                cached_trees_by_nodes = {}
                cached_next_token = current_next_token

            tree_cache = cached_trees_by_nodes.get(int(max_nnodes))
            if tree_cache is None:
                if not cached_base_tree:
                    draft_profile_start = time.monotonic()
                    base_nodes = int(max(valid_nodes))
                    draft_ids, draft_pos, tree_mask, parent, tree_depth = build_tree_with_next_token(
                        runner=runner,
                        input_ids=input_ids_t,
                        nodes=base_nodes,
                        threshold=float(args.threshold),
                        max_depth=TARGET_PROFILE_FIXED_DEPTH,
                        next_token_id=current_next_token,
                        tokenizer=tokenizer,
                        debug=False,
                        print_tree=False,
                        per_token_probability_bound=0.0,
                        per_path_probability_bound=0.0,
                        fixed_width=True,
                        fixed_depth=True,
                        fixed_nnodes=True,
                        fixed_width_value=TARGET_PROFILE_FIXED_WIDTH,
                    )
                    draft_profile_elapsed_sec = max(0.0, float(time.monotonic() - draft_profile_start))
                    base_parent = parent.tolist() if isinstance(parent, torch.Tensor) else parent
                    cached_base_tree = {
                        "base_nodes": int(base_nodes),
                        "draft_input_ids": draft_ids[0].tolist(),
                        "draft_position_ids": draft_pos.tolist(),
                        "tree_attention_mask": tree_mask.tolist(),
                        "parent": [int(x) for x in base_parent],
                        "tree_depth": int(tree_depth),
                        "draft_profile_time_sec": float(draft_profile_elapsed_sec),
                    }

                # base tree를 노드 수별로 잘라서 재사용 (head + first N nodes)
                desired_nodes = int(max_nnodes)
                base_draft_ids = cached_base_tree["draft_input_ids"]
                base_draft_pos = cached_base_tree["draft_position_ids"]
                base_mask = cached_base_tree["tree_attention_mask"]
                base_parent = cached_base_tree["parent"]
                keep = desired_nodes + 1

                sliced_parent = [int(x) for x in base_parent[:desired_nodes]]
                parent_valid = all(0 <= p < desired_nodes for p in sliced_parent)
                if parent_valid and len(base_draft_ids) >= keep and len(base_draft_pos) >= keep and len(base_mask) >= keep:
                    tree_cache = {
                        "draft_input_ids": base_draft_ids[:keep],
                        "draft_position_ids": base_draft_pos[:keep],
                        "tree_attention_mask": [row[:keep] for row in base_mask[:keep]],
                        "parent": sliced_parent,
                        "tree_depth": _derive_tree_depth_from_parent(sliced_parent),
                        "draft_profile_time_sec": float(cached_base_tree["draft_profile_time_sec"]),
                    }
                else:
                    # 드문 케이스: parent closure가 깨지면 해당 nnodes만 1회 fallback 생성
                    draft_profile_start = time.monotonic()
                    draft_ids, draft_pos, tree_mask, parent, tree_depth = build_tree_with_next_token(
                        runner=runner,
                        input_ids=input_ids_t,
                        nodes=desired_nodes,
                        threshold=float(args.threshold),
                        max_depth=TARGET_PROFILE_FIXED_DEPTH,
                        next_token_id=current_next_token,
                        tokenizer=tokenizer,
                        debug=False,
                        print_tree=False,
                        per_token_probability_bound=0.0,
                        per_path_probability_bound=0.0,
                        fixed_width=True,
                        fixed_depth=True,
                        fixed_nnodes=True,
                        fixed_width_value=TARGET_PROFILE_FIXED_WIDTH,
                    )
                    draft_profile_elapsed_sec = max(0.0, float(time.monotonic() - draft_profile_start))
                    fallback_parent = parent.tolist() if isinstance(parent, torch.Tensor) else parent
                    tree_cache = {
                        "draft_input_ids": draft_ids[0].tolist(),
                        "draft_position_ids": draft_pos.tolist(),
                        "tree_attention_mask": tree_mask.tolist(),
                        "parent": [int(x) for x in fallback_parent],
                        "tree_depth": int(tree_depth),
                        "draft_profile_time_sec": float(draft_profile_elapsed_sec),
                    }
                cached_trees_by_nodes[int(max_nnodes)] = tree_cache
            _write_json_line({
                "type": "tree_step",
                "profile_phase": profile_phase,
                "combo": {
                    "width": int(TARGET_PROFILE_FIXED_WIDTH),
                    "depth": int(TARGET_PROFILE_FIXED_DEPTH),
                    "max_nnodes": int(max_nnodes),
                },
                "draft_input_ids": tree_cache["draft_input_ids"],
                "draft_position_ids": tree_cache["draft_position_ids"],
                "tree_attention_mask": tree_cache["tree_attention_mask"],
                "parent": tree_cache["parent"],
                "tree_depth": int(tree_cache["tree_depth"]),
                "draft_profile_time_sec": float(tree_cache["draft_profile_time_sec"]),
            })
            verify_reply = _read_json_line()
            if verify_reply.get("type") != "verify_result":
                raise RuntimeError(f"unexpected verify reply: {verify_reply}")

    _write_json_line({"type": "done"})


if __name__ == "__main__":
    main()
