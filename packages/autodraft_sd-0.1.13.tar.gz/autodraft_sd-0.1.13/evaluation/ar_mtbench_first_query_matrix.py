import argparse
import csv
import gc
import json
import os
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


DRAFT_MODELS_DEFAULT = [
    "meta-llama/Llama-2-7b-chat-hf",
    "meta-llama/Llama-3.2-1B-Instruct",
    "meta-llama/Llama-3.2-3B-Instruct",
    "meta-llama/Llama-3.1-8B-Instruct",
    "Qwen/Qwen2.5-0.5B-Instruct",
    "Qwen/Qwen2.5-1.5B-Instruct",
    "Qwen/Qwen2.5-3B-Instruct",
    "Qwen/Qwen2.5-7B-Instruct",
    "Qwen/Qwen3-0.6B",
    "Qwen/Qwen3-1.7B",
]


def _sanitize(name: str) -> str:
    return (
        str(name)
        .strip()
        .replace("/", "__")
        .replace(":", "_")
        .replace(" ", "_")
        .replace(".", "_")
        .lower()
    )


def _read_mtbench_prompts(bench_file: Path, num_queries: int) -> List[str]:
    prompts: List[str] = []
    with bench_file.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            turns = row.get("turns", [])
            prompt = None
            if isinstance(turns, list) and turns:
                prompt = str(turns[0])
            elif row.get("question"):
                prompt = str(row.get("question"))
            if prompt:
                prompts.append(prompt)
            if len(prompts) >= int(num_queries):
                break
    if not prompts:
        raise RuntimeError(f"no prompts extracted from {bench_file}")
    return prompts


def _build_generation_kwargs(max_new_tokens: int, temperature: float, top_p: float) -> Dict[str, Any]:
    out: Dict[str, Any] = {
        "max_new_tokens": int(max_new_tokens),
        "use_cache": True,
        "pad_token_id": None,
    }
    if float(temperature) > 1e-8:
        out["do_sample"] = True
        out["temperature"] = float(temperature)
        out["top_p"] = float(top_p)
    else:
        out["do_sample"] = False
    return out


def _load_model(model_id: str, quantization: str, device_map: str, token: str = None):
    quantization = str(quantization).lower().strip()
    quant_cfg = None
    dtype = torch.float16 if torch.cuda.is_available() else torch.float32
    if quantization in {"8bit", "4bit"}:
        try:
            from transformers import BitsAndBytesConfig
        except Exception as e:
            raise RuntimeError(f"BitsAndBytesConfig import failed ({quantization} requested): {e}")
        if quantization == "8bit":
            quant_cfg = BitsAndBytesConfig(
                load_in_8bit=True,
                llm_int8_threshold=6.0,
                llm_int8_skip_modules=["lm_head"],
            )
        else:
            quant_cfg = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_use_double_quant=True,
            )

    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        dtype=dtype,
        low_cpu_mem_usage=True,
        device_map=device_map,
        quantization_config=quant_cfg,
        token=token,
        trust_remote_code=True,
    )
    try:
        tokenizer = AutoTokenizer.from_pretrained(
            model_id,
            token=token,
            trust_remote_code=True,
            use_fast=True,
        )
    except Exception as e:
        print(f"[WARN] fast tokenizer load failed for {model_id}: {e}")
        print("[WARN] retrying with slow tokenizer (use_fast=False)")
        tokenizer = AutoTokenizer.from_pretrained(
            model_id,
            token=token,
            trust_remote_code=True,
            use_fast=False,
        )
    if tokenizer.pad_token_id is None and tokenizer.eos_token_id is not None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    return model, tokenizer


def _eval_single_model(
    model_id: str,
    prompts: List[str],
    quantization: str,
    device_map: str,
    max_new_tokens: int,
    temperature: float,
    top_p: float,
) -> Dict[str, Any]:
    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN")
    started_at = time.time()
    record: Dict[str, Any] = {
        "model_id": model_id,
        "quantization": quantization,
        "device_map": device_map,
        "ok": False,
        "error": None,
        "num_queries": len(prompts),
        "max_new_tokens": int(max_new_tokens),
    }
    model = None
    tokenizer = None
    try:
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()

        model, tokenizer = _load_model(
            model_id=model_id,
            quantization=quantization,
            device_map=device_map,
            token=token,
        )
        model.eval()
        gen_kwargs = _build_generation_kwargs(max_new_tokens=max_new_tokens, temperature=temperature, top_p=top_p)
        gen_kwargs["pad_token_id"] = tokenizer.pad_token_id

        total_input_tokens = 0
        total_new_tokens = 0
        total_gen_sec = 0.0
        per_query: List[Dict[str, Any]] = []
        last_preview = ""

        target_device = model.device if hasattr(model, "device") else next(model.parameters()).device
        with torch.inference_mode():
            for i, prompt in enumerate(prompts, start=1):
                inputs = tokenizer([prompt], return_tensors="pt")
                inputs = {k: v.to(target_device) for k, v in inputs.items()}
                input_len = int(inputs["input_ids"].shape[1])
                if torch.cuda.is_available():
                    torch.cuda.synchronize()
                t0 = time.perf_counter()
                outputs = model.generate(**inputs, **gen_kwargs)
                if torch.cuda.is_available():
                    torch.cuda.synchronize()
                t1 = time.perf_counter()
                gen_sec = max(1e-9, float(t1 - t0))
                output_len = int(outputs.shape[1])
                new_tokens = max(0, output_len - input_len)
                last_preview = tokenizer.decode(outputs[0, input_len:], skip_special_tokens=True)[:500]

                total_input_tokens += input_len
                total_new_tokens += new_tokens
                total_gen_sec += gen_sec
                per_query.append(
                    {
                        "query_index": i,
                        "input_tokens": input_len,
                        "new_tokens": new_tokens,
                        "generation_time_sec": gen_sec,
                        "tokens_per_second": (float(new_tokens) / gen_sec) if gen_sec > 0 else 0.0,
                    }
                )

        peak_mem_mb = None
        if torch.cuda.is_available():
            peak_mem_mb = float(torch.cuda.max_memory_allocated() / (1024 ** 2))

        tps = float(total_new_tokens) / max(1e-9, float(total_gen_sec))
        record.update(
            {
                "ok": True,
                "input_tokens_total": int(total_input_tokens),
                "new_tokens_total": int(total_new_tokens),
                "generation_time_total_sec": float(total_gen_sec),
                "tokens_per_second": float(tps),
                "peak_cuda_memory_mb": peak_mem_mb,
                "generated_preview_last": last_preview,
                "per_query": per_query,
                "started_at": datetime.fromtimestamp(started_at).isoformat(),
                "finished_at": datetime.now().isoformat(),
            }
        )
        return record
    except Exception as e:
        record["error"] = str(e)
        record["started_at"] = datetime.fromtimestamp(started_at).isoformat()
        record["finished_at"] = datetime.now().isoformat()
        return record
    finally:
        try:
            del model
            del tokenizer
        except Exception:
            pass
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()


def _save_quant_results(quant_dir: Path, quant: str, rows: List[Dict[str, Any]], bench_file: Path, prompts: List[str], max_new_tokens: int):
    summary_jsonl = quant_dir / "summary.jsonl"
    with summary_jsonl.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

    summary_json = quant_dir / "summary.json"
    with summary_json.open("w", encoding="utf-8") as f:
        json.dump(
            {
                "created_at": datetime.now().isoformat(),
                "bench_file": str(bench_file),
                "num_queries": len(prompts),
                "prompt_preview_first": prompts[0][:300] if prompts else "",
                "num_models": len(rows),
                "quantization": quant,
                "max_new_tokens": int(max_new_tokens),
                "rows": rows,
            },
            f,
            indent=2,
            ensure_ascii=False,
        )

    summary_csv = quant_dir / "summary.csv"
    fieldnames = [
        "model_id",
        "ok",
        "error",
        "num_queries",
        "input_tokens_total",
        "new_tokens_total",
        "generation_time_total_sec",
        "tokens_per_second",
        "peak_cuda_memory_mb",
        "quantization",
        "device_map",
    ]
    with summary_csv.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k) for k in fieldnames})


def _save_comparison(run_dir: Path, all_rows: Dict[str, List[Dict[str, Any]]]):
    quants = ["none", "8bit", "4bit"]
    model_set = set()
    for q in quants:
        for r in all_rows.get(q, []):
            model_set.add(r.get("model_id"))
    models = sorted(model_set)

    by_q_model: Dict[str, Dict[str, Dict[str, Any]]] = {}
    for q in quants:
        by_q_model[q] = {r.get("model_id"): r for r in all_rows.get(q, [])}

    comp_csv = run_dir / "comparison.csv"
    with comp_csv.open("w", encoding="utf-8", newline="") as f:
        fieldnames = [
            "model_id",
            "none_tps",
            "8bit_tps",
            "4bit_tps",
            "none_ok",
            "8bit_ok",
            "4bit_ok",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for m in models:
            row = {"model_id": m}
            for q in quants:
                rec = by_q_model[q].get(m)
                row[f"{q}_ok"] = bool(rec.get("ok")) if rec else False
                if rec and rec.get("ok") and rec.get("tokens_per_second") is not None:
                    row[f"{q}_tps"] = float(rec.get("tokens_per_second"))
                else:
                    row[f"{q}_tps"] = None
            writer.writerow(row)

    print("\n=== Quantization Comparison (TPS) ===")
    print("| model | none | 8bit | 4bit |")
    print("|---|---:|---:|---:|")
    for m in models:
        vals = []
        for q in quants:
            rec = by_q_model[q].get(m)
            if not rec:
                vals.append("N/A")
            elif rec.get("ok") and rec.get("tokens_per_second") is not None:
                vals.append(f"{float(rec.get('tokens_per_second')):.3f}")
            else:
                vals.append("FAIL")
        print(f"| `{m}` | {vals[0]} | {vals[1]} | {vals[2]} |")
    print(f"\ncomparison_csv={comp_csv}")


def main() -> None:
    parser = argparse.ArgumentParser(description="AR benchmark over draft models on mt-bench first N queries.")
    parser.add_argument("--models-csv", type=str, default="", help="Optional comma-separated model ids.")
    parser.add_argument("--bench-file", type=str, default="data/mt_bench/question.jsonl", help="Path to mt_bench question.jsonl")
    parser.add_argument("--num-queries", type=int, default=10, help="Number of mt-bench prompts from start (default: 10)")
    parser.add_argument("--max-new-tokens", type=int, default=512, help="Generated tokens per query (default: 512)")
    parser.add_argument("--quantization", type=str, default="none", choices=["none", "8bit", "4bit"])
    parser.add_argument(
        "--quantization-seq",
        type=str,
        default="",
        help="Optional ordered quantization sweep, e.g. 'none,8bit,4bit'",
    )
    parser.add_argument("--device-map", type=str, default="auto")
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--top-p", type=float, default=1.0)
    parser.add_argument("--output-root", type=str, default="result/ar_mtbench_first_query")
    args = parser.parse_args()

    repo_root = Path(__file__).resolve().parent.parent
    bench_file = (repo_root / args.bench_file).resolve() if not Path(args.bench_file).is_absolute() else Path(args.bench_file)
    output_root = (repo_root / args.output_root).resolve() if not Path(args.output_root).is_absolute() else Path(args.output_root)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = output_root / f"ar_mtbench_q{int(args.num_queries)}_{ts}"
    run_dir.mkdir(parents=True, exist_ok=True)

    prompts = _read_mtbench_prompts(bench_file=bench_file, num_queries=max(1, int(args.num_queries)))
    if args.models_csv.strip():
        models = [m.strip() for m in args.models_csv.split(",") if m.strip()]
    else:
        models = list(DRAFT_MODELS_DEFAULT)

    if args.quantization_seq.strip():
        quant_seq = [q.strip().lower() for q in args.quantization_seq.split(",") if q.strip()]
    else:
        quant_seq = [str(args.quantization).lower().strip()]
    allowed = {"none", "8bit", "4bit"}
    quant_seq = [q for q in quant_seq if q in allowed]
    if not quant_seq:
        raise RuntimeError("no valid quantization selected")

    print("=== AR mt-bench benchmark ===")
    print(f"bench_file={bench_file}")
    print(f"num_queries={len(prompts)}")
    print(f"models={len(models)}")
    print(f"quantization_seq={','.join(quant_seq)}")
    print(f"max_new_tokens={args.max_new_tokens}")
    print(f"output={run_dir}")

    all_rows: Dict[str, List[Dict[str, Any]]] = {}
    for quant in quant_seq:
        print(f"\n========== quantization={quant} ==========")
        quant_dir = run_dir / f"quant_{quant}"
        per_model_dir = quant_dir / "per_model"
        per_model_dir.mkdir(parents=True, exist_ok=True)
        rows: List[Dict[str, Any]] = []
        for idx, model_id in enumerate(models, start=1):
            print(f"\n[{idx}/{len(models)}] {model_id}")
            row = _eval_single_model(
                model_id=model_id,
                prompts=prompts,
                quantization=quant,
                device_map=args.device_map,
                max_new_tokens=int(args.max_new_tokens),
                temperature=float(args.temperature),
                top_p=float(args.top_p),
            )
            rows.append(row)
            out_path = per_model_dir / f"{idx:02d}_{_sanitize(model_id)}.json"
            with out_path.open("w", encoding="utf-8") as f:
                json.dump(row, f, indent=2, ensure_ascii=False)
            if row.get("ok"):
                print(
                    "  ok: "
                    f"tps={float(row.get('tokens_per_second') or 0.0):.3f}, "
                    f"new_tokens_total={int(row.get('new_tokens_total') or 0)}, "
                    f"queries={int(row.get('num_queries') or 0)}"
                )
            else:
                print(f"  fail: {row.get('error')}")

        _save_quant_results(
            quant_dir=quant_dir,
            quant=quant,
            rows=rows,
            bench_file=bench_file,
            prompts=prompts,
            max_new_tokens=int(args.max_new_tokens),
        )
        all_rows[quant] = rows

    if len(quant_seq) > 1:
        _save_comparison(run_dir=run_dir, all_rows=all_rows)

    print("\n=== done ===")
    print(f"run_dir={run_dir}")
    print("per-quant summaries:")
    for quant in quant_seq:
        print(f"  - {quant}: {run_dir / f'quant_{quant}' / 'summary.csv'}")


if __name__ == "__main__":
    main()
