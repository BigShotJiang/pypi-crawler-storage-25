'''
일단 accept length는 잘 나옴. 
다만 target에서 받은 best_ids를 활용하여 draft_stable_kv를 업데이트하는 로직이 안되어 있음. 
향후 버전에서 추가할 것. 
'''

import argparse
import json
import os
import socket
import time
from typing import List, Tuple

import torch
from fastchat.llm_judge.common import load_questions
from fastchat.model import get_conversation_template
from transformers import AutoTokenizer
from tqdm import tqdm

from opt_classic.utils import prepare_logits_processor, recv_json, send_json
from opt_classic.modeling_llama_kv import LlamaForCausalLM as KVLlamaForCausalLM
from opt_classic.tree import Tree






class DraftRunner:
    def __init__(self, draft_model: KVLlamaForCausalLM, tokenizer: AutoTokenizer):
        self.draft_model = draft_model
        self.tokenizer = tokenizer
        # Draft는 tree 확장 때문에 stable KV 방식 사용
        self.draft_stable_kv = None
    
    def reset_kv(self):
        """KV cache 리셋"""
        self.draft_stable_kv = None

    def process_tree_mask(self, tree_attention_mask: torch.Tensor, init_len: int) -> torch.Tensor:
        attention_mask = torch.full((tree_attention_mask.size(0), init_len), 0, device=tree_attention_mask.device)
        tree_mask = torch.where(tree_attention_mask == 0, torch.finfo(torch.float32).min, 0)
        attention_mask = torch.cat([attention_mask, tree_mask], dim=-1)
        attention_mask = attention_mask[None, None, :, :]
        return attention_mask

    @torch.no_grad()
    def draft(self, input_ids: torch.Tensor, nodes: int, threshold: float, max_depth: int, print_time: bool = False, print_tree: bool = False):
        # breakpoint()
        device = self.draft_model.lm_head.weight.device
        len_posi = input_ids.shape[1] - 1
        
        # Stable KV 방식: 이전 KV가 있으면 새 토큰만 계산
        if self.draft_stable_kv is not None:
            kv_len = self.draft_stable_kv[0][0].shape[2]
            new_tokens = input_ids[:, kv_len:].to(device)  # [DH] 이전 라운드의 tree에서 accept된 토큰들 + 서버로 받은 new_token
            seq_len = new_tokens.shape[1]
            if seq_len == 0:    # [DH] seq_len이 0이다 == 이전 라운드의 tree에서 받은 토큰이 없음 + 서버로 부터 받은 next_token도 없다는 뜻인데, 이게 가능한가? 이 if문에 안 들어올 것 같은데
                # 빈 슬라이스: 이전_next_token == 새_next_token인 경우
                # draft_stable_kv의 마지막 위치(이전_next_token)에서 hidden state를 재계산
                print(f"[DRAFT-INFO] Empty new_tokens (prev_next_token == new_next_token). Recomputing last hidden state.")
                # draft_stable_kv에서 마지막 토큰(이전_next_token) 제외한 past_key_values 사용
                trimmed_kv = tuple(
                    (kv[0][:, :, :-1, :], kv[1][:, :, :-1, :]) 
                    for kv in self.draft_stable_kv
                )
                # 마지막 토큰의 hidden state를 얻기 위해 해당 토큰만 forward
                # 빈 슬라이스인 경우: 이전_next_token == 새_next_token
                # input_ids[-1] = 새_next_token = 이전_next_token
                last_token_id = input_ids[0, -1:].unsqueeze(0).to(device)
                draft_outputs = self.draft_model.model(
                    input_ids=last_token_id,
                    past_key_values=trimmed_kv,
                    position_ids=torch.tensor([[kv_len - 1]], device=device, dtype=torch.long),
                    return_kv=True,
                    is_draft=True,
                )
                # draft_stable_kv는 이미 올바른 상태이므로 업데이트하지 않음 (이전_next_token 포함)
                past_key_values = self.draft_stable_kv
            else:   # [DH] 이전 라운드의 tree에서 accept된 토큰들 + 이번에 서버로부터 받은 new_token에 대한 kv를 만드는 과정++ 다음 토큰에 대한 logits
                pos_ids = torch.arange(kv_len, kv_len + seq_len, device=device, dtype=torch.long)
                draft_outputs = self.draft_model.model(
                    input_ids=new_tokens,
                    past_key_values=self.draft_stable_kv,
                    position_ids=pos_ids,
                    return_kv=True,
                    is_draft=True,
                )
        else:
            # 처음이거나 리셋 후
            full = input_ids.to(device)
            seq_len = full.shape[1]
            if seq_len == 0:
                raise RuntimeError("DraftRunner.draft received empty input_ids on initial call")
            pos_ids = torch.arange(0, seq_len, device=device, dtype=torch.long)
            draft_outputs = self.draft_model.model(
                input_ids=full,
                position_ids=pos_ids,
                return_kv=True,
                is_draft=True,
            )
        
        # Base KV 저장 (tree 확장 전)
        self.draft_stable_kv = draft_outputs[1]
        past_key_values = self.draft_stable_kv
        init_len = past_key_values[0][0].size(2)
        
        last_hidden = draft_outputs[0][:, -1]
        last_headout = self.draft_model.lm_head(last_hidden)

        tree = Tree(nodes, last_hidden.device, threshold, max_depth)

        logits = last_headout.unsqueeze(0)
        end = False
        while not end:
            tree_output = tree.update(torch.softmax(logits.to(last_hidden.device), dim=-1, dtype=torch.float32))
            input_ids_step = tree_output["input_ids"].unsqueeze(0)
            position_ids = tree_output["position_ids"] + len_posi   # [DH] 상대적 index(트리에서 몇 번째 인지) -> 절대적 index로 변환 (전체 input_ids에서 몇 번째인지)
            if tree_output["is_final"]:
                break
            tree_attention_mask_with_kv = self.process_tree_mask(tree_output["attention_mask"], init_len)
            draft_outputs = self.draft_model.model(
                input_ids=input_ids_step,
                position_ids=position_ids,
                past_key_values=past_key_values,
                tree_attention_mask=tree_attention_mask_with_kv,
                return_kv=True,
                is_draft=True,
            )
            # Tree 확장 후 KV 업데이트 (local variable)
            past_key_values = draft_outputs[1]
            
            last_hidden = draft_outputs[0]
            last_headout = self.draft_model.lm_head(last_hidden)
            logits = last_headout

        # Tree 확장 후 최종 KV를 draft_stable_kv에 저장 (update_kv_with_accepted에서 사용)
        # 원본과 동일하게: draft_stable_kv에는 tree 확장 후의 전체 KV가 포함되어야 함
        self.draft_stable_kv = past_key_values  # 원래 verify 에서 해줘야함. 왜 여기? [PJ]
        
        # Tree KV는 반환하지 않음 (토큰만 전송)
        return input_ids_step, position_ids, tree_output["attention_mask"], tree_output["parent_last"], tree.depth


@torch.inference_mode()
def build_tree_with_next_token(
    runner: DraftRunner,
    input_ids: torch.Tensor,
    nodes: int,
    threshold: float,
    max_depth: int,
    next_token_id: int,
    tokenizer: AutoTokenizer,
):
    # KV cache 길이 체크 및 동기화
    # 원본 방식:
    # - verify 후: draft_stable_kv = input_ids + next_token
    # - 다음 verify 전: draft_stable_kv = input_ids + next_token (여전히)
    # - model.draft(input_ids + next_token) 호출 시:
    #   draft 함수 내부: draft_stable_kv가 있으면 kv_len 이후만 처리
    #
    # 분리 버전:
    # - update_kv_with_accepted 후: draft_stable_kv = input_ids + next_token
    # - build_tree_with_next_token 호출 시:
    #   input_ids = [old_input_ids + accepted_tokens] (아직 next_token 없음)
    #   draft_stable_kv = [old_input_ids + accepted_tokens + next_token] (이전 스텝의 next_token)
    #   → draft_stable_kv = input_ids + next_token 상태이므로, kv_len = input_ids + 1이어야 함
    #   → 하지만 이건 잘못된 접근
    #
    # 원본을 다시 확인: verify 내부에서 draft 호출 전에 input_ids가 업데이트됨
    # - verify Line 225: input_ids = input_ids + best_candidate
    # - verify Line 226: model.draft(input_ids + next_token)
    # - draft 함수: draft_stable_kv가 있으면 kv_len 이후만 처리
    #
    # 따라서 build_tree_with_next_token 호출 시:
    # - input_ids = [old_input_ids + accepted_tokens]
    # - draft_stable_kv = [old_input_ids + prev_accepted_tokens + prev_next_token]
    # - 하지만 원본과 달리 분리 버전에서는 update_kv_with_accepted 후 draft_stable_kv = input_ids + next_token
    # - 따라서 kv_len = input_ids + 1이어야 함
    # KV cache 길이 체크 및 동기화
    # 원본 방식:
    # - verify 후 draft_stable_kv = input_ids + next_token
    # - 다음 verify 내부에서:
    #   - input_ids = input_ids + best_candidate (업데이트)
    #   - model.draft(input_ids + next_token) 호출
    #   - draft 함수: kv_len = draft_stable_kv 길이 (이전 verify 후 = 이전 input_ids + 이전 next_token)
    #   - cat_input = input_ids + next_token (이미 best_candidate 포함)
    #   - cat_input[:, kv_len:] = 새 토큰들 처리
    #
    # 분리 버전 (원본과 동일하게):
    # - update_kv_with_accepted 후: draft_stable_kv = input_ids + next_token
    # - build_tree_with_next_token 호출 시:
    #   - input_ids = [old_input_ids + accepted_tokens] (이미 업데이트됨)
    #   - draft_stable_kv = [이전 input_ids + 이전 next_token] (이전 스텝)
    #   - 하지만 이전 input_ids는 old_input_ids보다 작을 수 있음!
    #   - cat_input = input_ids + next_token
    #   - draft 함수: kv_len = 이전 draft_stable_kv 길이
    #                 cat_input[:, kv_len:] = 새 토큰들 처리
    #
    # 핵심: draft_stable_kv는 이전 스텝의 input_ids + next_token 상태
    #       하지만 input_ids는 이미 현재 스텝으로 업데이트됨
    #       따라서 kv_len < input_ids 길이일 수 있음
    
    if runner.draft_stable_kv is not None:
        kv_len = runner.draft_stable_kv[0][0].shape[2]  # [DH] 이전 라운드에 받은 new_token까지만 있음 (이전 라운드의 tree에서 accept된 토큰들은 포함 안 됨)
        input_ids_len = input_ids.shape[1]  # [DH] 이전 라운드에 accept된 토큰들까지 있음
        # 원본처럼: draft_stable_kv = 이전 input_ids + 이전 next_token
        # input_ids = 현재 input_ids (이미 accepted_tokens 포함)
        # 따라서 kv_len <= input_ids_len일 수 있음 (이전 < 현재)
        if kv_len > input_ids_len + 1:  # [DH] line 218, 219 주석에 의해 이게 불가능한 경우임
            # draft_stable_kv가 input_ids + next_token보다 크면 불일치
            print(f"[DRAFT-DEBUG] KV sync check failed: kv_len={kv_len} > input_ids_len+1={input_ids_len+1}, resetting")
            runner.draft_stable_kv = None
    
    next_token = torch.tensor([[next_token_id]], device=input_ids.device, dtype=torch.long) #[DH] 여기서 말하는 next_token_id는 target model이 반환한 다음 토큰 ID (current_next_token)
    cat_input = torch.cat((input_ids, next_token), dim=1)
    # 동기화 점검 로그 (리셋은 수행하지 않음)
    if runner.draft_stable_kv is not None:
        kv_len = runner.draft_stable_kv[0][0].shape[2]
        print(f"[DRAFT-DEBUG] KV sync check: kv_len={kv_len}, input_ids_len={input_ids.shape[1]}, cat_input_len={cat_input.shape[1]}")
        if kv_len > cat_input.shape[1]:
            print(f"[DRAFT-WARN] kv_len({kv_len}) > cat_input_len({cat_input.shape[1]}). This will cause empty new_tokens. Check update_kv_with_accepted/base_input_len.")
    
    # draft 함수 호출 (원본 verify Line 226: model.draft(input_ids + next_token))
    draft_input_ids, draft_position_ids, tree_attention_mask, parent, tree_depth = runner.draft(
        cat_input,
        nodes,
        threshold,
        max_depth,
    )
    
    # draft 함수 반환값에 next_token 추가 (원본 verify Line 249: next_draft = torch.cat([next_token, next_draft], dim=-1))
    next_token_tensor = torch.tensor([[next_token_id]], device=input_ids.device, dtype=torch.long)
    draft_input_ids = torch.cat([next_token_tensor, draft_input_ids], dim=-1)
    head_pos = torch.tensor([cat_input.shape[1]-1], device=draft_position_ids.device)
    draft_position_ids = torch.cat([head_pos, draft_position_ids], dim=-1)
    tree_attention_mask = torch.cat(
        [torch.zeros(1, tree_attention_mask.size(1), dtype=tree_attention_mask.dtype, device=tree_attention_mask.device), tree_attention_mask],
        dim=0,
    )
    tree_attention_mask = torch.cat(
        [torch.ones(tree_attention_mask.size(0), 1, dtype=tree_attention_mask.dtype, device=tree_attention_mask.device), tree_attention_mask],
        dim=1,
    )

    return draft_input_ids, draft_position_ids, tree_attention_mask, parent, tree_depth


def update_kv_with_accepted(runner: DraftRunner, best_ids: List[int], base_kv_len: int, next_token: int):
    """
    Accept된 경로의 KV만 추출하여 draft_stable_kv에 저장
    tree_kv 전송 없이 runner.draft_stable_kv에서 직접 추출
    
    원본 방식 분석:
    - verify 후: draft_stable_kv = input_ids + next_token 상태
    - verify 내부에서: input_ids = input_ids + best_candidate
    - model.draft(input_ids + next_token) 호출
    - draft 함수 내부: draft_stable_kv가 있으면 kv_len 이후만 처리
    - draft_stable_kv = draft_outputs[1]로 전체 업데이트
    
    핵심: draft_stable_kv는 항상 input_ids + next_token 상태와 동기화됨
    
    분리 버전에서:
    - draft() 호출 후 draft_stable_kv에는 전체 tree의 KV가 포함됨
    - best_ids를 사용해서 accept된 경로의 KV만 추출
    - update_kv_with_accepted 후: draft_stable_kv = input_ids (next_token 제외)
    
    Args:
        runner: DraftRunner (draft_stable_kv에 tree KV 포함)
        best_ids: Target이 계산한 accept된 경로의 tree 내 인덱스들 (draft_input_ids 기준)
        base_kv_len: input_ids_t.shape[1] (accept 전의 길이 = old_input_ids 길이)
        next_token: Target이 반환한 다음 토큰 ID
    """
    if len(best_ids) == 0:
        return
    
    if runner.draft_stable_kv is None:
        print("[DRAFT-DEBUG] draft_stable_kv is None, skipping update")
        return
    
    device = runner.draft_model.lm_head.weight.device
    
    # draft_stable_kv 구조 분석:
    # draft() 호출 후 draft_stable_kv = [이전 draft_stable_kv + 새로 처리한 토큰들]
    # 하지만 draft() 함수는 past_key_values를 받아서 새 토큰만 처리하므로:
    # - draft_stable_kv = [이전 draft_stable_kv (전체) + 새 토큰들 (tree_nodes)]
    #
    # 실제로 draft() 함수 내부를 보면:
    # - past_key_values = draft_stable_kv (이전 상태)
    # - input_ids[:, kv_len:] = 새 토큰들만 처리
    # - draft_outputs[1] = 전체 새로운 KV (past_key_values + 새 토큰들)
    #
    # 따라서 draft_stable_kv 구조:
    # - draft_stable_kv = [old_input_ids + next_token + tree_nodes] (전체)
    # - base_kv_len = input_ids_t.shape[1] (accept 전)
    # - base_kv_len은 old_input_ids 길이와 다를 수 있음!
    #
    # 해결: base_kv_len은 update_kv_with_accepted 호출 전 input_ids_t 길이
    # 하지만 draft_stable_kv는 이미 tree 확장 후 상태이므로,
    # base_kv_len보다 클 수 있음
    
    # draft_stable_kv 현재 길이
    tree_kv_len = runner.draft_stable_kv[0][0].shape[2]
    old_kv_len = tree_kv_len
    old_input_ids_len = base_kv_len
    
    # base_kv_len은 draft() 호출 전 input_ids 길이
    # draft_stable_kv 구조를 확인:
    # - draft_stable_kv는 draft() 호출 후 상태
    # - base_kv_len 이전 부분은 old_input_ids
    # - base_kv_len 위치부터는 새로 추가된 부분
    
    # best_ids는 draft_input_ids 기준 인덱스:
    # - draft_input_ids[0] = next_token
    # - draft_input_ids[1:] = tree_nodes
    # draft_stable_kv에서의 인덱스:
    # - next_token 위치 = base_kv_len (draft() 호출 시 추가된 위치)
    # - tree_nodes 위치 = base_kv_len + 1부터
    
    # 하지만 draft() 함수를 다시 확인하면:
    # - draft() 호출 시 input_ids = input_ids + next_token
    # - draft_stable_kv가 있으면 kv_len 이후만 처리
    # - 따라서 draft_stable_kv = [이전 draft_stable_kv + 새 토큰들]
    
    # 현재 draft_stable_kv에서 base_kv_len 위치 확인
    if base_kv_len >= tree_kv_len:
        print(f"ERROR: base_kv_len ({base_kv_len}) >= tree_kv_len ({tree_kv_len})")
        print(f"[DRAFT-DEBUG] KV sync failed, resetting draft_stable_kv")
        runner.draft_stable_kv = None
        return
    
    # best_ids를 draft_stable_kv 기준 인덱스로 변환
    # draft_input_ids[best_id]는 draft_stable_kv[base_kv_len + best_id]에 해당
    select_indices = torch.tensor(best_ids, device=device) + base_kv_len
    min_index = select_indices.min().item()
    max_index = select_indices.max().item()
    
    # 디버깅 로그
    print(f"[DRAFT-DEBUG] KV Update Info:")
    print(f"  best_ids: {best_ids}")
    print(f"  base_kv_len: {base_kv_len}")
    print(f"  select_indices: {select_indices.tolist()}")
    print(f"  tree_kv_len: {tree_kv_len}")
    print(f"  old_kv_len: {old_kv_len}")
    print(f"  index range: [{min_index}, {max_index}]")
    
    # 인덱스 범위 검증
    if min_index < base_kv_len or max_index >= tree_kv_len:
        print(f"ERROR: Index range [{min_index}, {max_index}] out of bounds [{base_kv_len}, {tree_kv_len})")
        print(f"[DRAFT-DEBUG] KV sync failed, resetting draft_stable_kv")
        runner.draft_stable_kv = None
        return
    
    # draft_stable_kv에서 accept된 토큰들의 KV 추출
    selected_kv = []
    for layer_kv in runner.draft_stable_kv:
        key, value = layer_kv
        selected_key = key[:, :, select_indices, :]
        selected_value = value[:, :, select_indices, :]
        selected_kv.append((selected_key, selected_value))
    
    # 원본 방식 분석:
    # verify 함수 (Line 225-226):
    #   1. input_ids = input_ids + best_candidate
    #   2. model.draft(input_ids + next_token) 호출
    #   → draft 함수 내부:
    #      - draft_stable_kv가 있으면 kv_len = draft_stable_kv[0][0].shape[2]
    #      - input_ids[:, kv_len:]만 처리 (새 토큰만)
    #      - draft_stable_kv = draft_outputs[1]로 전체 업데이트
    #
    # 분리 버전에서의 흐름:
    # 1. build_tree_with_next_token 호출 전:
    #    - input_ids_t = [old_input_ids] (accept 전)
    #    - draft_stable_kv = [old_input_ids + prev_next_token] (이전 스텝)
    # 
    # 2. build_tree_with_next_token:
    #    - cat_input = [old_input_ids + next_token]
    #    - draft() 호출:
    #      * draft_stable_kv가 있으면: kv_len = old_input_ids + prev_next_token
    #      * 하지만 cat_input = old_input_ids + next_token만 포함
    #      * draft_stable_kv의 prev_next_token과 next_token이 다를 수 있음!
    #    - 따라서 draft_stable_kv를 리셋하거나 동기화 필요
    #
    # 3. update_kv_with_accepted 호출 시:
    #    - base_kv_len = input_ids_t.shape[1] = old_input_ids 길이
    #    - tree_kv 구조: [old_input_ids + next_token + tree_nodes]
    #    - selected_kv = tree_kv[base_kv_len + best_ids] = [next_token + accepted_nodes]
    #
    # 원본과 동일하게 하려면:
    # draft_stable_kv = [old_input_ids + accepted_tokens]로 설정
    # 여기서 accepted_tokens = selected_kv에 해당 (next_token 포함)
    
        # 원본 동작 재확인:
        # verify 후 draft_stable_kv = input_ids + next_token
        # 하지만 draft 함수 호출 시 input_ids 전체를 전달하므로:
        # - draft_stable_kv는 draft 함수 내부에서 자동 업데이트됨
        #
        # 분리 버전에서:
        # - update_kv_with_accepted 후: draft_stable_kv = input_ids (next_token 제외)
        # - build_tree_with_next_token: input_ids + next_token으로 draft 호출
        # - draft 함수: kv_len = input_ids, input_ids[:, kv_len:] = next_token 처리
        # - draft_stable_kv = input_ids + next_token (자동 업데이트됨)
        #
        # 따라서 update_kv_with_accepted에서는 draft_stable_kv = input_ids로 설정
    
    if runner.draft_stable_kv is not None:
        old_kv_len = runner.draft_stable_kv[0][0].shape[2]
        old_input_ids_len = base_kv_len
        
        # 원본 불변식: verify 직후 draft_stable_kv = 이전 input_ids + 이전 next_token
        # 따라서 accepted_tokens는 포함하지 않고, base_kv_len까지만 유지 + next_token만 추가
        # (accepted_tokens는 이미 input_ids에 추가되었으므로 제외)
        
        # draft_stable_kv에서 next_token의 KV 추출 (항상 base_kv_len 위치)
        next_token_kv = []
        for layer_kv in runner.draft_stable_kv:
            key, value = layer_kv
            if base_kv_len < old_kv_len:
                # base_kv_len 위치의 next_token KV 추출
                next_token_key = key[:, :, base_kv_len:base_kv_len+1, :]
                next_token_value = value[:, :, base_kv_len:base_kv_len+1, :]
            else:
                # base_kv_len == old_kv_len인 경우 (첫 스텝이거나 리셋된 경우)
                # next_token은 이미 draft_stable_kv의 마지막에 있을 수 있음
                # 하지만 일반적으로는 없으므로 빈 텐서로 처리
                next_token_key = key[:, :, -1:, :] if old_kv_len > 0 else key[:, :, :0, :]
                next_token_value = value[:, :, -1:, :] if old_kv_len > 0 else value[:, :, :0, :]
            next_token_kv.append((next_token_key, next_token_value))
        
        if old_input_ids_len > 0:
            # 원본 불변식: draft_stable_kv = input_ids + next_token
            # 여기서 input_ids = old_input_ids + accepted_tokens (다음 스텝에서 업데이트될 값)
            # 하지만 update_kv_with_accepted 시점에는 input_ids가 아직 old_input_ids 상태
            # 따라서 draft_stable_kv = old_input_ids + 이전_next_token으로 설정
            # (accepted_tokens는 다음 스텝에서 input_ids에 추가되므로 draft_stable_kv에는 포함하지 않음)
            new_kv = []
            for i in range(len(runner.draft_stable_kv)):
                base_key = runner.draft_stable_kv[i][0]
                base_value = runner.draft_stable_kv[i][1]
                
                # old_input_ids 부분만 추출
                old_input_ids_key = base_key[:, :, :old_input_ids_len, :]
                old_input_ids_value = base_value[:, :, :old_input_ids_len, :]
                
                # 이전 next_token KV 추가 (accepted_tokens는 제외)
                next_key, next_value = next_token_kv[i]
                new_key = torch.cat([old_input_ids_key, next_key], dim=2)
                new_value = torch.cat([old_input_ids_value, next_value], dim=2)
                
                new_kv.append((new_key, new_value))
            
            runner.draft_stable_kv = tuple(new_kv)
            new_kv_len = runner.draft_stable_kv[0][0].shape[2]
            expected_len = old_input_ids_len + 1  # old_input_ids + 이전_next_token
            print(f"[DRAFT-DEBUG] KV updated. New length: {new_kv_len}, expected (old_input_ids+prev_next_token): {expected_len}")
            if new_kv_len != expected_len:
                print(f"[DRAFT-WARN] KV length mismatch! Expected {expected_len}, got {new_kv_len}")
        else:
            # 첫 스텝: next_token만 유지
            runner.draft_stable_kv = tuple(next_token_kv)
            print(f"[DRAFT-DEBUG] KV updated (first step). New length: {runner.draft_stable_kv[0][0].shape[2]}")
    else:
        # draft_stable_kv가 None인 경우: selected_kv에서 next_token 추출 불가능
        # 이 경우는 초기화 단계이므로, selected_kv를 그대로 사용
        # 하지만 일반적으로는 draft_stable_kv가 있어야 함
        print(f"[DRAFT-WARN] draft_stable_kv is None, using selected_kv as fallback")
        runner.draft_stable_kv = tuple(selected_kv)
        print(f"[DRAFT-DEBUG] Initial KV set (fallback). Length: {runner.draft_stable_kv[0][0].shape[2]}")


def run_draft(
    host: str,
    port: int,
    base_model_path: str,
    draft_model_path: str,
    bench_name: str,
    question_file: str,
    limit: int,
    temperature: float,
    nodes: int,
    threshold: float,
    max_depth: int,
    device_map: str,
    load_in_4bit: bool,
    load_in_8bit: bool,
):
    # 드래프트 모델만 로드
    quantization_config = None
    if load_in_8bit:
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_8bit=True,
            llm_int8_threshold=6.0,
            llm_int8_skip_modules=["lm_head"],
        )
    elif load_in_4bit:
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
        )

    draft_model = KVLlamaForCausalLM.from_pretrained(
        draft_model_path,
        torch_dtype=torch.float16,
        low_cpu_mem_usage=True,
        device_map=device_map,
        quantization_config=quantization_config,
        token="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",
        # token="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",
    )
    tokenizer = AutoTokenizer.from_pretrained(base_model_path)
    runner = DraftRunner(draft_model=draft_model, tokenizer=tokenizer)

    if temperature > 1e-5:
        logits_processor = prepare_logits_processor(temperature=temperature)
    else:
        logits_processor = None

    with socket.create_connection((host, port)) as sock:
        questions = load_questions(question_file, None, None)
        if limit and limit > 0:
            questions = questions[:limit]

        # Warmup (3회) - 첫 질문으로 파이프라인 예열
        for _ in range(3):
            torch.manual_seed(0)
            # Warmup마다 KV cache 리셋
            runner.reset_kv()
            warm_q = questions[0]
            if "vicuna" in base_model_path:
                conv = get_conversation_template("vicuna")
            else:
                conv = get_conversation_template("llama-2-chat")
                sys_p = (
                    "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  "
                    "Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. "
                    "Please ensure that your responses are socially unbiased and positive in nature. If a question does not make any sense, "
                    "or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, "
                    "please don't share false information."
                )
                conv.system_message = sys_p
            # breakpoint()
            warm_turns = [warm_q["question"]] if bench_name == "gsm8k" else warm_q["turns"]
            conv.append_message(conv.roles[0], warm_turns[0])
            conv.append_message(conv.roles[1], None)
            prompt = conv.get_prompt() + " "
            input_ids = tokenizer([prompt]).input_ids
            input_ids_t = torch.as_tensor(input_ids).to("cuda")

            send_json(sock, {"type": "init", "input_ids": input_ids[0]})
            reply = recv_json(sock)
            if reply.get("type") != "init_ok":
                break
            current_next_token = reply["next_token"]

            warm_steps = 0
            while True:
                draft_ids, draft_pos, tree_mask, parent, tree_depth = build_tree_with_next_token(
                    runner, input_ids_t, nodes, threshold, max_depth, current_next_token, tokenizer
                )
                payload = {
                    "type": "tree_step",
                    "draft_input_ids": draft_ids[0].tolist(),
                    "draft_position_ids": draft_pos.tolist(),
                    "tree_attention_mask": tree_mask.tolist(),
                    "parent": parent.tolist(),
                }
                send_json(sock, payload)
                reply = recv_json(sock)
                if reply.get("type") != "verify_result":
                    break
                accepted_tokens: List[int] = reply["accepted_tokens"]
                current_next_token = reply["next_token"]
                eos_reached: bool = reply["eos_reached"]
                best_ids: List[int] = reply["best_ids"]
                base_input_len: int = reply.get("base_input_len", input_ids_t.shape[1])
                
                # Accept된 경로의 KV만 유지
                # base_kv_len은 draft() 호출 전 input_ids 길이 (old_input_ids)
                # 하지만 draft_stable_kv는 draft() 호출 후 상태이므로,
                # base_kv_len을 draft_stable_kv의 이전 길이로 추정해야 함
                base_kv_len = base_input_len
                update_kv_with_accepted(runner, best_ids, base_kv_len, current_next_token)
                # print(runner.draft_stable_kv[0][0].shape[2])
                
                input_ids_t = torch.cat([
                    input_ids_t,
                    torch.tensor([accepted_tokens], device=input_ids_t.device, dtype=torch.long),
                ], dim=-1)
                
                warm_steps += 1
                if eos_reached or warm_steps > 5 or input_ids_t.shape[1] > 512:
                    break

        print("Warmup done")

        grand_total_steps = 0
        grand_total_accepted = 0
        grand_total_draft_tokens = 0
        grand_total_new_tokens = 0
        run_start_time = time.time()

        for question in tqdm(questions):
            # 각 question마다 KV cache 리셋
            runner.reset_kv()
            
            # 대화 템플릿 준비
            if "vicuna" in base_model_path:
                conv = get_conversation_template("vicuna")
            else:
                conv = get_conversation_template("llama-2-chat")
                sys_p = (
                    "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  "
                    "Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. "
                    "Please ensure that your responses are socially unbiased and positive in nature. If a question does not make any sense, "
                    "or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, "
                    "please don't share false information."
                )
                conv.system_message = sys_p

            if bench_name == "gsm8k":
                question_turns = [question["question"]]
            else:
                question_turns = question["turns"]

            qs = question_turns[0]
            conv.append_message(conv.roles[0], qs)
            conv.append_message(conv.roles[1], None)
            prompt = conv.get_prompt() + " "
            input_ids = tokenizer([prompt]).input_ids
            input_ids_t = torch.as_tensor(input_ids).to("cuda")

            # 초기 base 토큰 1개는 target에게 요청
            send_json(sock, {"type": "init", "input_ids": input_ids[0]})
            reply = recv_json(sock)
            assert reply.get("type") == "init_ok"
            current_next_token = reply["next_token"]

            output_tokens: List[int] = []
            new_token_count = 0
            total_steps = 0

            while True:
                # 드래프트 트리 생성 (타겟이 보낸 next_token을 사용)
                draft_ids, draft_pos, tree_mask, parent, tree_depth = build_tree_with_next_token(
                    runner, input_ids_t, nodes, threshold, max_depth, current_next_token, tokenizer
                )
                # target에게 검증 요청
                payload = {
                    "type": "tree_step",
                    "draft_input_ids": draft_ids[0].tolist(),
                    "draft_position_ids": draft_pos.tolist(),
                    "tree_attention_mask": tree_mask.tolist(),
                    "parent": parent.tolist(),
                }
                send_json(sock, payload)

                reply = recv_json(sock)
                assert reply.get("type") == "verify_result"
                accepted_tokens: List[int] = reply["accepted_tokens"]
                accept_length: int = reply["accept_length"]
                next_token: int = reply["next_token"]
                eos_reached: bool = reply["eos_reached"]
                best_ids: List[int] = reply["best_ids"]

                # Accept된 경로의 KV만 유지
                base_kv_len = input_ids_t.shape[1]
                update_kv_with_accepted(runner, best_ids, base_kv_len, next_token)

                # 수락된 토큰들을 입력에 붙임
                input_ids_t = torch.cat([
                    input_ids_t,
                    torch.tensor([accepted_tokens], device=input_ids_t.device, dtype=torch.long),
                ], dim=-1)

                output_tokens.extend(accepted_tokens)
                new_token_count += accept_length + 1
                total_steps += 1

                # 통계 누적
                grand_total_steps += 1
                grand_total_accepted += accept_length
                grand_total_draft_tokens += int(tree_depth)

                # 다음 라운드를 위해 최신 next_token 저장
                current_next_token = next_token

                if eos_reached or new_token_count > 1024 or input_ids_t.shape[1] > 1960:
                    break

            decoded = tokenizer.decode(output_tokens, spaces_between_special_tokens=False)
            qid = question.get("question_id", None)
            if qid is not None:
                print(f"[question_id={qid}] {decoded}")
            else:
                print(decoded)

        # 전체 결과 요약 출력 (원본 포맷과 정렬)
        total_time = max(1e-6, time.time() - run_start_time)
        tokens_per_step = (grand_total_accepted + grand_total_steps) / max(1, grand_total_steps)  # (accept_length+1)의 평균
        tokens_per_second = (grand_total_accepted + grand_total_steps) / total_time
        avg_tree_depth = (grand_total_draft_tokens / max(1, grand_total_steps)) if grand_total_steps > 0 else 0.0
        avg_accept_length = (grand_total_accepted / max(1, grand_total_steps)) if grand_total_steps > 0 else 0.0

        print(
            "total_steps: {}  | total_new_tokens: {}  | total_time: {:.2f}  | tokens per step: {:.2f}  | tokens per second: {:.2f}  | avg_tree_depth: {:.2f}".format(
                grand_total_steps,
                grand_total_accepted + grand_total_steps,
                total_time,
                tokens_per_step,
                tokens_per_second,
                avg_tree_depth,
            )
        )
        # 추가 지표(참고): 평균 accept length도 함께 출력
        print(
            "avg_accept_length: {:.4f}  acceptance_ratio_avg: {:.4f}".format(
                avg_accept_length,
                (grand_total_accepted / max(1, grand_total_draft_tokens)) if grand_total_draft_tokens > 0 else 0.0,
            )
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", type=str, default="127.0.0.1")
    parser.add_argument("--port", type=int, default=26001)
    parser.add_argument("--base-model-path", type=str, required=True)
    parser.add_argument("--draft-model-path", type=str, required=True)
    parser.add_argument("--bench-name", type=str, choices=["mt_bench", "gsm8k"], required=True)
    parser.add_argument("--question-file", type=str, default=None)
    parser.add_argument("--limit", type=int, default=0, help="Limit number of questions")
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--nodes", type=int, default=50)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--max_depth", type=int, default=10)
    parser.add_argument("--device-map", type=str, default="cuda:0")
    parser.add_argument("--load-in-4bit", action="store_true")
    parser.add_argument("--load-in-8bit", action="store_true")
    args = parser.parse_args()

    if args.question_file:
        question_file = args.question_file
    else:
        if args.bench_name == "mt_bench":
            script_dir = os.path.dirname(__file__)
            parent_dir = os.path.dirname(script_dir)
            question_file = f"{parent_dir}/data/mt_bench/question.jsonl"
        elif args.bench_name == "gsm8k":
            script_dir = os.path.dirname(__file__)
            parent_dir = os.path.dirname(script_dir)
            question_file = f"{parent_dir}/data/gsm8k.jsonl"
        else:
            raise ValueError("Undefined bench_name")

    run_draft(
        host=args.host,
        port=args.port,
        base_model_path=args.base_model_path,
        draft_model_path=args.draft_model_path,
        bench_name=args.bench_name,
        question_file=question_file,
        limit=args.limit,
        temperature=args.temperature,
        nodes=args.nodes,
        threshold=args.threshold,
        max_depth=args.max_depth,
        device_map=args.device_map,
        load_in_4bit=args.load_in_4bit,
        load_in_8bit=args.load_in_8bit,
    )


