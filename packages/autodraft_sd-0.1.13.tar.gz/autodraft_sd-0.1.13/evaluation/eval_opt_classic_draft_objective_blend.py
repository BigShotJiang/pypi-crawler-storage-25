'''
일단 accept length는 잘 나옴. 
다만 target에서 받은 best_ids를 활용하여 draft_stable_kv를 업데이트하는 로직이 안되어 있음. 
향후 버전에서 추가할 것. 
++ code redundancy 제거. (update_kv_with_accepted 함수 제거 및 draft_stable_kv 관리 로직 수정 (tree 확장 후 포함 제거))
'''

import argparse
import hashlib
import json
import os
import random
import socket
import subprocess
import time
import threading
from datetime import datetime
from typing import List, Tuple

import shortuuid
import torch
from fastchat.llm_judge.common import load_questions
from fastchat.model import get_conversation_template
from transformers import AutoTokenizer
from tqdm import tqdm
import importlib
from opt_classic.utils import (
    CPUPowerMonitor,
    GPUMonitor,
    prepare_logits_processor,
    recv_json_with_size,
    send_json_with_size,
)
from opt_classic.modeling_llama_kv import LlamaForCausalLM as KVLlamaForCausalLM
from opt_classic.tree import Tree
import numpy as np
np.set_printoptions(threshold=np.inf)

# 네트워크 정보 수집을 위한 라이브러리 (선택적)
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False


def set_seed(seed: int):
    """재현을 위해 torch, random, numpy 시드 고정."""
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)


def set_deterministic():
    """GPU 연산까지 동일 결과를 위해 PyTorch 비결정적 알고리즘 비활성화 (일부 연산 느려질 수 있음)."""
    torch.use_deterministic_algorithms(True, warn_only=True)
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")


def get_kv_llama_class(base_model_path: str):

    model_path_l = (base_model_path or "").lower()
    is_llama3_family = ("llama-3" in model_path_l) or ("llama3" in model_path_l)
    is_qwen3_family = ("qwen3" in model_path_l) or ("qwen-3" in model_path_l) or ("qwen/qwen3" in model_path_l)
    is_qwen2_family = (not is_qwen3_family) and (
        ("qwen2" in model_path_l) or ("qwen-2" in model_path_l) or ("qwen/qwen2" in model_path_l)
    )

    if is_qwen3_family:
        module_name, class_name = "opt_classic.modeling_qwen3_kv", "Qwen3ForCausalLM"
    elif is_qwen2_family:
        module_name, class_name = "opt_classic.modeling_qwen2_kv", "Qwen2ForCausalLM"
    elif is_llama3_family:
        module_name, class_name = "opt_classic.modeling_llama3_kv", "LlamaForCausalLM"
    else:
        module_name, class_name = "opt_classic.modeling_llama_kv", "LlamaForCausalLM"

    print(f'importing {module_name}.{class_name}')
    try:
        mod = importlib.import_module(module_name)
        return getattr(mod, class_name)
    except Exception as e:
        raise RuntimeError(f"Failed to import {module_name}.{class_name}: {e}")
    

class DraftRunner:
    def __init__(self, draft_model: torch.nn.Module, tokenizer: AutoTokenizer, debug: bool = False, profile_data: dict = None, draft_per_sec_cost: float = 0.0, target_per_sec_cost: float = 0.0, communication_per_gb_cost: float = 0.0, cost_sensitivity: float = 0.0, enable_gpu_monitor: bool = False, gpu_monitor_interval: float = 0.1, enable_cpu_monitor: bool = False, opt_tree: bool = False, no_draft_cost: bool = False, objective_metric: str = "cost", accept_length_margin: float = 0.05):
        
        self.draft_model = draft_model
        self.tokenizer = tokenizer
        # Draft는 tree 확장 때문에 stable KV 방식 사용
        self.draft_stable_kv = None
        # Proactive drafting 전용 KV (기존 draft_stable_kv와 분리)
        self.proactive_kv = None
        self.debug = debug
        self.enable_gpu_monitor = enable_gpu_monitor
        self.gpu_monitor = None
        if self.enable_gpu_monitor:
            self.gpu_monitor = GPUMonitor(
                interval=gpu_monitor_interval,
                debug=debug
            )
        # CPU 전력 모니터링 (독립적으로 활성화 가능)
        self.enable_cpu_monitor = enable_cpu_monitor
        self.cpu_power_monitor = None
        if self.enable_cpu_monitor:  # CPU 모니터링이 활성화되면 CPU 전력 측정
            # CPU 전력 모니터는 최소 0.5초 interval 필요 (powerstat 요구사항)
            cpu_monitor_interval = max(0.5, gpu_monitor_interval)
            self.cpu_power_monitor = CPUPowerMonitor(
                interval=cpu_monitor_interval,
                debug=debug
            )
            if debug:
                print(f"[draft] CPU 전력 모니터 초기화 완료 (interval: {cpu_monitor_interval}, 요청: {gpu_monitor_interval})")
        else:
            if debug:
                print(f"[draft] CPU 전력 모니터 비활성화 (enable_cpu_monitor: {self.enable_cpu_monitor})")
        # width별 draft_model.model 호출 시간 통계 누적
        self.accumulated_width_times = {}  # {width: [time1, time2, ...]} - draft_model.model 호출 시간
        # model.model() 호출 시간의 총합 누적
        self.accumulated_model_total_time = 0.0
        # model.model() 호출 시간의 예상 시간의 총합 누적
        self.accumulated_expected_model_total_time = 0.0
        # 프로파일링 데이터 (width별 model_call_avg_time_ms를 포함하는 딕셔너리)
        self.profile_data = profile_data  # {width: {"model_call_avg_time_ms": ...}, ...}
        # Target 프로파일링 데이터 (width_depth_nnodes별 avg_time_ms를 포함하는 딕셔너리)
        self.target_profile_data = None  # {"width_X_depth_Y_nnodes_Z": {"width": X, "depth": Y, "max_nnodes": Z, "avg_time_ms": ...}, ...}
        # 이전 tree의 정보 (전송 시간 계산용)
        # 초기값은 나중에 max_nnodes로 설정됨 (draft() 함수에서)
        self.prev_tree_final_nnodes = None  # 이전 tree의 top_index 개수 (final_nnodes), 초기값은 None
        self.prev_tree_depth = 0  # 이전 tree의 depth
        self.prev_tree_total_target_time = 0.4  # 이전 tree의 토탈 시간 (target에서 받은 시간, 초 단위), 초기값 0.4초
        self.prev_tree_transfer_time = None  # 이전 tree의 실제 측정된 전송 시간 (초 단위, draft_to_target + target_to_draft)
        self.prev_tree_accept_length = 1.0  # 이전 tree의 수락 길이
        # 토큰별 전송 시간 (초 단위, 소수점 표현)
        self.per_token_draft_to_target_transfer_time = 0.0  # 토큰별 Draft → Target 전송 시간
        self.per_token_target_to_draft_transfer_time = 0.0  # 토큰별 Target → Draft 전송 시간
        self.per_token_draft_to_target_bytes = 0.0  # 토큰별 Draft -> Target 바이트
        self.per_token_target_to_draft_bytes = 0.0  # 토큰별 Target -> Draft 바이트
        self.communication_per_gb_cost = float(communication_per_gb_cost or 0.0)
        # 초당 비용 (시간당 비용을 초당 비용으로 변환)
        self.draft_per_sec_cost = draft_per_sec_cost
        self.target_per_sec_cost = target_per_sec_cost
        # Cost sensitivity weight (0~100)
        self.cost_sensitivity = cost_sensitivity
        # opt-tree 모드
        self.opt_tree = bool(opt_tree)
        # draft tree 비용 제외 옵션
        self.no_draft_cost = bool(no_draft_cost)
        # objective metric: cost | energy
        self.objective_metric = str(objective_metric).lower() if objective_metric is not None else "cost"
        # Tree 목적함수에 전달되는 draft의 초당 단위값
        # - cost 모드: 달러/초
        # - energy 모드: kWh/초 (GPU power_draw_w 기반)
        self.draft_objective_rate_per_sec = float(draft_per_sec_cost) if self.objective_metric == "cost" else 0.0
        # Warmup reference (정규화 objective 계산용)
        self.reference_tps = 1.0
        self.reference_cost_per_token = 1.0
        self.reference_objective_per_token = 1.0
        # Depth별 통계 누적 (모든 tree에서 수집)
        self.accumulated_depth_stats = {}  # {depth: {"prev_sum_expected_accepted_length": [...], "sum_expected_accepted_length": [...], "per_token_latency": [...], "per_token_cost": [...], "objective_value": [...]}}
        # 알고리즘 실행 시간 누적
        self.accumulated_width_algorithm_times = []  # width 선택 알고리즘 실행 시간 (초)
        self.accumulated_nnodes_algorithm_times = []  # final_nnodes 선택 알고리즘 실행 시간 (초)
        # 질문(또는 1회 생성) 단위 통계: print용/질문별 리셋용
        self.question_width_times = {}  # {width: [time1, time2, ...]}
        self.question_model_total_time = 0.0
        self.question_expected_model_total_time = 0.0
        self.question_width_algorithm_times = []
        self.question_nnodes_algorithm_times = []
        # 최신 tree(현재 step)의 expected accept length (tree.sum_expected_accepted_length)
        self.last_sum_expected_accepted_length = None
        # 최신 tree 생성 시점에 Tree로 전달한 accept_length_scale (scaled_expected 계산용)
        self.last_accept_length_scale_used = 1.0
        # profile_data/target_profile_data 보정용 오차율(실측/예측) 누적 평균
        # - draft_time_ratio = draft_time_ms / predicted_time_ms (width별)
        # - target_verification_ratio = target_verification_time_ms / predicted_time_ms (width/depth/nnodes별)
        self.draft_time_ratio_sum = 0.0
        self.draft_time_ratio_count = 0
        self.target_verification_ratio_sum = 0.0
        self.target_verification_ratio_count = 0
        # expected_accept_length 보정용 오차율(실측/예측) 누적 평균
        # - accept_length_ratio = actual_accept_length / expected_accept_length
        self.accept_length_ratio_sum = 0.0
        self.accept_length_ratio_count = 0
        # expected accept length 보수 마진 (기본 5%)
        self.accept_length_margin = max(0.0, min(0.99, float(accept_length_margin)))
        # target profile lookup 통계 누적
        self.target_profile_lookup_stats = {"direct_hit": 0, "nearest_hit": 0, "fallback": 0}

    def get_draft_objective_rate_per_sec(self) -> float:
        if self.no_draft_cost:
            return 0.0
        return float(self.draft_objective_rate_per_sec)

    def get_sensitivity_alpha(self) -> float:
        """cost-sensitivity(0~100) -> alpha(0~1)."""
        try:
            alpha = float(self.cost_sensitivity) / 100.0
        except Exception:
            alpha = 0.0
        return max(0.0, min(1.0, alpha))

    def get_reference_latency_per_token(self) -> float:
        return 1.0 / max(1e-9, float(self.reference_tps))

    def get_reference_objective_per_token(self) -> float:
        return max(1e-12, float(self.reference_objective_per_token))

    def update_draft_objective_rate_from_gpu(self, gpu_stats: dict):
        """energy 모드일 때 GPU power_draw 평균으로 draft objective rate(kWh/s)를 갱신."""
        if self.objective_metric != "energy":
            return
        if not isinstance(gpu_stats, dict) or not gpu_stats:
            return
        try:
            gpu_entry = gpu_stats.get("gpu_0")
            if gpu_entry is None:
                gpu_entry = next(iter(gpu_stats.values()))
            power_info = gpu_entry.get("power_draw_w", {}) if isinstance(gpu_entry, dict) else {}
            power_avg_w = power_info.get("avg") if isinstance(power_info, dict) else None
            if power_avg_w is None:
                return
            power_avg_w = float(power_avg_w)
            if power_avg_w <= 0:
                return
            measured_kwh_per_sec = power_avg_w / 3600000.0
            if self.draft_objective_rate_per_sec <= 0:
                self.draft_objective_rate_per_sec = measured_kwh_per_sec
            else:
                alpha = 0.2
                self.draft_objective_rate_per_sec = (
                    alpha * measured_kwh_per_sec + (1.0 - alpha) * self.draft_objective_rate_per_sec
                )
        except Exception:
            return

    def get_draft_time_ratio_mean(self):
        """draft_time_ms / predicted_time_ms의 누적 평균 (없으면 None)"""
        if self.draft_time_ratio_count <= 0:
            return None
        return float(self.draft_time_ratio_sum / self.draft_time_ratio_count)

    def get_target_verification_ratio_mean(self):
        """target_verification_time_ms / predicted_time_ms의 누적 평균 (없으면 None)"""
        if self.target_verification_ratio_count <= 0:
            return None
        return float(self.target_verification_ratio_sum / self.target_verification_ratio_count)

    def get_accept_length_ratio_mean(self):
        """actual_accept_length / expected_accept_length의 누적 평균 (없으면 None)"""
        if self.accept_length_ratio_count <= 0:
            return None
        return float(self.accept_length_ratio_sum / self.accept_length_ratio_count)
    
    def reset_kv(self):
        """KV cache 리셋"""
        self.draft_stable_kv = None

    def reset_proactive_kv(self):
        """Proactive KV cache 리셋"""
        self.proactive_kv = None
    
    def reset_timing_stats(self, reset_global: bool = False):
        """통계 리셋
        - reset_global=False: 질문(1개 question) 단위 통계만 리셋 (전체 run 누적값은 유지)
        - reset_global=True : 전체 run 누적값까지 리셋 (warmup 후 등)
        """
        # 질문 단위 통계는 항상 리셋
        self.question_width_times = {}
        self.question_model_total_time = 0.0
        self.question_expected_model_total_time = 0.0
        self.question_width_algorithm_times = []
        self.question_nnodes_algorithm_times = []

        if reset_global:
            self.accumulated_width_times = {}
            self.accumulated_model_total_time = 0.0
            self.accumulated_expected_model_total_time = 0.0
            self.accumulated_width_algorithm_times = []
            self.accumulated_nnodes_algorithm_times = []
            # warmup에서 측정된 보정 비율이 결과에 섞이지 않도록 함께 리셋
            self.draft_time_ratio_sum = 0.0
            self.draft_time_ratio_count = 0
            self.target_verification_ratio_sum = 0.0
            self.target_verification_ratio_count = 0
            self.accept_length_ratio_sum = 0.0
            self.accept_length_ratio_count = 0
            self.target_profile_lookup_stats = {"direct_hit": 0, "nearest_hit": 0, "fallback": 0}
    
    def print_timing_stats(self):
        """누적된 width별 draft_model.model 호출 평균 실행 시간 출력"""
        # 질문 단위 통계 출력 (질문 종료 시점 호출을 가정)
        if not self.question_width_times:
            return
        
        print("\n" + "="*80)
        print("Width별 draft_model.model 호출 실행 시간 통계 (질문 전체 누적)")
        print("="*80)
        print(f"{'Width':<10} {'실행 횟수':<12} {'총 시간 (ms)':<15} {'평균 시간 (ms)':<15} {'최소 시간 (ms)':<15} {'최대 시간 (ms)':<15}")
        print("-"*80)
        
        for width in sorted(self.question_width_times.keys()):
            times = self.question_width_times[width]
            count = len(times)
            total_time_ms = sum(times) * 1000
            avg_time_ms = (sum(times) / count) * 1000 if count > 0 else 0
            min_time_ms = min(times) * 1000
            max_time_ms = max(times) * 1000
            
            print(f"{width:<10} {count:<12} {total_time_ms:<15.3f} {avg_time_ms:<15.3f} {min_time_ms:<15.3f} {max_time_ms:<15.3f}")
        
        print("="*80)
        
        # 모델 호출에 사용된 시간의 총합 출력
        print(f"\n모델 호출 시간 총합:")
        print(f"  실제 측정 시간: {self.question_model_total_time * 1000:.3f} ms")
        print(f"  예상 시간 (프로파일링): {self.question_expected_model_total_time * 1000:.3f} ms")
        if self.question_model_total_time > 0:
            diff_ms = (self.question_expected_model_total_time - self.question_model_total_time) * 1000
            diff_percent = (diff_ms / (self.question_model_total_time * 1000)) * 100
            print(f"  차이: {diff_ms:+.3f} ms ({diff_percent:+.2f}%)")
        print("="*80 + "\n")

    def process_tree_mask(self, tree_attention_mask: torch.Tensor, init_len: int) -> torch.Tensor:
        # tree_attention_mask는 (current_width, past_cols + current_width) 형태
        # 여기서 past_cols는 이전 depth들의 노드 수
        # init_len은 초기 입력 길이
        # 결과는 (current_width, init_len + past_cols + current_width) 형태가 되어야 함
        
        current_width = tree_attention_mask.size(0)
        tree_mask_cols = tree_attention_mask.size(1)
        past_cols = tree_mask_cols - current_width
        
        # 초기 입력에 대한 mask 생성 (current_width, init_len)
        attention_mask = torch.full((current_width, init_len), 0, device=tree_attention_mask.device)
        
        # tree_attention_mask 변환: 0인 부분을 -inf로, 1인 부분을 0으로
        tree_mask = torch.where(tree_attention_mask == 0, torch.finfo(torch.float32).min, 0.0)
        
        # tree_attention_mask의 인덱스는 past_cols부터 시작하므로, init_len을 더해줘야 함
        # 하지만 tree_mask는 이미 올바른 상대 인덱스를 가지고 있으므로 그대로 사용
        # concat: (current_width, init_len) + (current_width, past_cols + current_width)
        attention_mask = torch.cat([attention_mask, tree_mask], dim=-1)
        
        # (1, 1, current_width, init_len + past_cols + current_width) 형태로 변환
        attention_mask = attention_mask[None, None, :, :]
        return attention_mask

    @torch.no_grad()
    def draft(self, input_ids: torch.Tensor, nodes: int, max_depth: int, print_time: bool = False, print_tree: bool = False, tokenizer=None, per_token_probability_bound: float = 0.0, per_path_probability_bound: float = 0.0, min_width: int = 1, fixed_width: bool = False, fixed_nnodes: bool = False, fixed_depth: bool = False, use_proactive_kv: bool = False, track_stats: bool = True, stop_flag: threading.Event = None, fixed_width_value: int = None):
        # breakpoint()
        device = self.draft_model.lm_head.weight.device
        len_posi = input_ids.shape[1] - 1
        kv_attr = "proactive_kv" if use_proactive_kv else "draft_stable_kv"
        kv_state = getattr(self, kv_attr)
        
        # Stable KV 방식: 이전 KV가 있으면 새 토큰만 계산
        if kv_state is not None:
            kv_len = kv_state[0][0].shape[2]  # 기존 KV 길이
            new_tokens = input_ids[:, kv_len:].to(device)  # accepted tokens + next_token
            seq_len = new_tokens.shape[1]
            if seq_len == 0:
                # 빈 슬라이스: 이전_next_token == 새_next_token인 경우 <= 그런 경우는 있으면 안되는거 아님? 항상 새로운 토큰이 들어옴. 
                # draft_stable_kv의 마지막 위치(이전_next_token)에서 hidden state를 재계산
                if self.debug:
                    print(f"[DRAFT-INFO] Empty new_tokens (prev_next_token == new_next_token). Recomputing last hidden state.")
                # draft_stable_kv에서 마지막 토큰(이전_next_token) 제외한 past_key_values 사용
                trimmed_kv = tuple(
                    (kv[0][:, :, :-1, :], kv[1][:, :, :-1, :]) 
                    for kv in kv_state
                )
                # 마지막 토큰의 hidden state를 얻기 위해 해당 토큰만 forward
                # 빈 슬라이스인 경우: 이전_next_token == 새_next_token
                # input_ids[-1] = 새_next_token = 이전_next_token
                last_token_id = input_ids[0, -1:].unsqueeze(0).to(device)
                draft_outputs = self.draft_model.model(
                    input_ids=last_token_id,
                    past_key_values=trimmed_kv,
                    position_ids=torch.tensor([[kv_len - 1]], device=device, dtype=torch.long),
                    return_kv=True,
                    is_draft=True,
                )
                # draft_stable_kv는 이미 올바른 상태이므로 업데이트하지 않음 (이전_next_token 포함)
                past_key_values = kv_state
            else:  # 위에는 지워도 될 것 같음. 
                pos_ids = torch.arange(kv_len, kv_len + seq_len, device=device, dtype=torch.long)
                draft_outputs = self.draft_model.model(
                    input_ids=new_tokens,
                    past_key_values=kv_state,
                    position_ids=pos_ids,
                    return_kv=True,
                    is_draft=True,
                )
        else:
            # 처음이거나 리셋 후
            full = input_ids.to(device)
            seq_len = full.shape[1]
            if seq_len == 0:
                raise RuntimeError("DraftRunner.draft received empty input_ids on initial call")
            pos_ids = torch.arange(0, seq_len, device=device, dtype=torch.long)
            draft_outputs = self.draft_model.model(
                input_ids=full,
                position_ids=pos_ids,
                return_kv=True,
                is_draft=True,
            )
        
        # Base KV 저장 (tree 확장 전)
        setattr(self, kv_attr, draft_outputs[1])
        past_key_values = getattr(self, kv_attr)
        init_len = past_key_values[0][0].size(2)
        
        last_hidden = draft_outputs[0][:, -1]
        last_headout = self.draft_model.lm_head(last_hidden)

        # prev_tree_final_width가 None이면 초기값으로 max_nnodes 사용
        prev_tree_final_width = self.prev_tree_final_nnodes if self.prev_tree_final_nnodes is not None else nodes
        
        accept_length_scale = self.get_accept_length_ratio_mean() if self.get_accept_length_ratio_mean() is not None else 1.0

        tree = Tree(
            nodes, 
            last_hidden.device, 
            max_depth, 
            per_token_probability_bound=per_token_probability_bound, 
            per_path_probability_bound=per_path_probability_bound, 
            fixed_width=fixed_width_value if fixed_width_value is not None else (nodes if fixed_width else None),
            fixed_nnodes=fixed_nnodes,
            fixed_depth=fixed_depth,
            profile_data=self.profile_data,
            target_profile_data=self.target_profile_data,
            target_time_scale=self.get_target_verification_ratio_mean() if self.get_target_verification_ratio_mean() is not None else 1.0,
            accept_length_scale=accept_length_scale,
            accept_length_margin=self.accept_length_margin,
            draft_per_sec_cost=self.get_draft_objective_rate_per_sec(),
            target_per_sec_cost=self.target_per_sec_cost,
            cost_sensitivity=self.cost_sensitivity,
            reference_tps=self.reference_tps,
            reference_objective_per_token=self.reference_objective_per_token,
            objective_metric=self.objective_metric,
            no_draft_cost=self.no_draft_cost,
            opt_tree=self.opt_tree,
            min_width=min_width,
            per_token_draft_to_target_transfer_time=self.per_token_draft_to_target_transfer_time,
            per_token_target_to_draft_transfer_time=self.per_token_target_to_draft_transfer_time,
            per_token_draft_to_target_bytes=self.per_token_draft_to_target_bytes,
            per_token_target_to_draft_bytes=self.per_token_target_to_draft_bytes,
            communication_per_gb_cost=self.communication_per_gb_cost,
            stop_flag=stop_flag,
        )

        logits = last_headout.unsqueeze(0)
        end = False
        draft_time = None  # 이전 draft model 호출 시간 (첫 번째 update에서는 None)
        while not end:  # tree 확장 조건 만족 안할 때까지 확장하고 draft tree 완성. 
            if stop_flag is not None and stop_flag.is_set():
                return None
            draft_time_scale = self.get_draft_time_ratio_mean() if self.get_draft_time_ratio_mean() is not None else 1.0
            tree_output = tree.update(
                torch.softmax(logits.to(last_hidden.device), dim=-1, dtype=torch.float32),
                print_tree=print_tree,
                tokenizer=tokenizer,
                draft_time=draft_time,
                draft_time_scale=draft_time_scale,
            )

            input_ids_step = tree_output["input_ids"].unsqueeze(0)
            position_ids = tree_output["position_ids"] + len_posi   # [DH] 상대적 index(트리에서 몇 번째 인지) -> 절대적 index로 변환 (전체 input_ids에서 몇 번째인지)
            if tree_output["is_final"]:
                break
            tree_attention_mask_with_kv = self.process_tree_mask(tree_output["attention_mask"], init_len)
            
            # draft_model.model 호출 시간 측정
            if isinstance(input_ids_step, torch.Tensor) and input_ids_step.is_cuda:
                torch.cuda.synchronize()
            model_start_time = time.time()
            draft_outputs = self.draft_model.model(
                input_ids=input_ids_step,
                position_ids=position_ids,
                past_key_values=past_key_values,
                tree_attention_mask=tree_attention_mask_with_kv,
                return_kv=True,
                is_draft=True,
            )
            # breakpoint()
            if isinstance(draft_outputs[0], torch.Tensor) and draft_outputs[0].is_cuda:
                torch.cuda.synchronize()
            draft_time = time.time() - model_start_time

            # draft_time(실측) / profile_data(예측) 오차율 업데이트 (다음 슬롯부터 예측시간 보정에 사용)
            # width는 이번 forward에서 처리한 토큰 수(=input_ids_step 폭)
            try:
                width_call = int(input_ids_step.shape[1])
            except Exception:
                width_call = None
            if track_stats and width_call is not None and self.profile_data is not None:
                width_str = str(width_call)
                predicted_ms = self.profile_data.get(width_str, {}).get("model_call_avg_time_ms", None)
                if predicted_ms is not None and predicted_ms > 0:
                    ratio = (float(draft_time) * 1000.0) / float(predicted_ms)
                    # 비정상 값 방지
                    if ratio == ratio and ratio > 0:  # NaN 체크 및 양수
                        self.draft_time_ratio_sum += float(ratio)
                        self.draft_time_ratio_count += 1
            # Tree 확장 후 KV 업데이트 (local variable)
            past_key_values = draft_outputs[1]
            
            last_hidden = draft_outputs[0]
            last_headout = self.draft_model.lm_head(last_hidden)
            logits = last_headout

        if track_stats:
            # Tree의 통계를 누적 (draft_model.model 호출 시간 리스트 사용)
            for width, times in tree.width_times.items():
                # 질문 단위
                if width not in self.question_width_times:
                    self.question_width_times[width] = []
                self.question_width_times[width].extend(times)
                # 전체(run) 단위
                if width not in self.accumulated_width_times:
                    self.accumulated_width_times[width] = []
                self.accumulated_width_times[width].extend(times)
            
            # 모델 호출에 사용된 시간의 총합 누적
            self.question_model_total_time += tree.draft_total_time
            self.accumulated_model_total_time += tree.draft_total_time
            # model.model() 호출 시간의 예상 시간의 총합 누적
            self.question_expected_model_total_time += tree.expected_draft_total_time
            self.accumulated_expected_model_total_time += tree.expected_draft_total_time
            
            # Depth별 통계 누적 (tree.depth_stats에서 수집)
            for depth, stats in tree.depth_stats.items():
                if depth not in self.accumulated_depth_stats:
                    self.accumulated_depth_stats[depth] = {
                        "prev_sum_expected_accepted_length": [],
                        "sum_expected_accepted_length": [],
                        "per_token_latency": [],
                        "per_token_cost": [],
                        "objective_value": []
                    }
                for key in ["prev_sum_expected_accepted_length", "sum_expected_accepted_length", "per_token_latency", "per_token_cost", "objective_value"]:
                    self.accumulated_depth_stats[depth][key].extend(stats[key])
            
            # 알고리즘 실행 시간 누적
            if hasattr(tree, 'width_algorithm_times') and tree.width_algorithm_times:
                self.question_width_algorithm_times.extend(tree.width_algorithm_times)
                self.accumulated_width_algorithm_times.extend(tree.width_algorithm_times)
            if hasattr(tree, 'nnodes_algorithm_times') and tree.nnodes_algorithm_times:
                self.question_nnodes_algorithm_times.extend(tree.nnodes_algorithm_times)
                self.accumulated_nnodes_algorithm_times.extend(tree.nnodes_algorithm_times)
            if hasattr(tree, "target_profile_lookup_stats"):
                for k, v in tree.target_profile_lookup_stats.items():
                    self.target_profile_lookup_stats[k] = self.target_profile_lookup_stats.get(k, 0) + int(v)

       
        # Tree KV는 반환하지 않음 (토큰만 전송)
        # final_nnodes는 model.model() 호출 시간에서 계산된 final_nnodes
        final_nnodes = tree.final_nnodes
        # 이번 tree의 expected accept length (caller에서 필요 시 저장/매칭)
        try:
            expected_accept_length = float(tree.sum_expected_accepted_length)
        except Exception:
            expected_accept_length = None
        # depth별 width 기록도 함께 반환
        depth_widths = list(tree.depth_widths)

        # proactive meta: node depth/col/path_prob (final 출력 기준)
        node_meta = None
        if isinstance(tree_output, dict) and tree_output.get("is_final"):
            rows = tree_output.get("rows", None)
            cols = tree_output.get("cols", None)
            if rows is not None and cols is not None:
                try:
                    path_probs = tree.weight_matrix[rows, cols].detach().to("cpu").tolist()
                except Exception:
                    path_probs = None
                node_meta = {
                    "rows": rows.detach().to("cpu").tolist() if isinstance(rows, torch.Tensor) else rows,
                    "cols": cols.detach().to("cpu").tolist() if isinstance(cols, torch.Tensor) else cols,
                    "path_probs": path_probs,
                }

        return (
            input_ids_step,
            position_ids,
            tree_output["attention_mask"],
            tree_output["parent_last"],
            tree.depth,
            final_nnodes,
            depth_widths,
            node_meta,
            expected_accept_length,
            float(accept_length_scale),
        )


@torch.inference_mode()
def build_tree_with_next_token(
    runner: DraftRunner,
    input_ids: torch.Tensor,
    nodes: int,
    max_depth: int,
    next_token_id: int,
    tokenizer: AutoTokenizer,
    debug: bool = False,
    print_tree: bool = False,
    per_token_probability_bound: float = 0.0,
    per_path_probability_bound: float = 0.0,
    min_width: int = 1,
    fixed_width: bool = False,
    fixed_width_value: int = None,
    fixed_nnodes: bool = False,
    fixed_depth: bool = False,
):
    # tree 만들기     
    if runner.draft_stable_kv is not None:
        kv_len = runner.draft_stable_kv[0][0].shape[2]  # draft_stable_kv의 KV 길이
        input_ids_len = input_ids.shape[1]
        # 원본처럼: draft_stable_kv = 이전 input_ids + 이전 next_token
        # input_ids = 현재 input_ids (이미 accepted_tokens 포함)
        if kv_len > input_ids_len + 1:
            # draft_stable_kv가 input_ids + next_token보다 크면 불일치, 있으면 안되는 경우임. 
            if debug:
                print(f"[DRAFT-DEBUG] KV sync check failed: kv_len={kv_len} > input_ids_len+1={input_ids_len+1}, resetting")
            runner.draft_stable_kv = None
    
    next_token = torch.tensor([[next_token_id]], device=input_ids.device, dtype=torch.long)
    cat_input = torch.cat((input_ids, next_token), dim=1)
    # 동기화 점검 로그
    if runner.draft_stable_kv is not None:
        kv_len = runner.draft_stable_kv[0][0].shape[2]
        if debug:
            print(f"[DRAFT-DEBUG] KV sync check: kv_len={kv_len}, input_ids_len={input_ids.shape[1]}, cat_input_len={cat_input.shape[1]}")
        if kv_len > cat_input.shape[1]:
            if debug:
                print(f"[DRAFT-WARN] kv_len({kv_len}) > cat_input_len({cat_input.shape[1]}). This will cause empty new_tokens. Check update_kv_with_accepted/base_input_len.")
    
    # draft 함수 호출, input_ids + next_token을 사용해서 token tree 만들기. (원본 verify Line 226: model.draft(input_ids + next_token))
    (
        draft_input_ids,
        draft_position_ids,
        tree_attention_mask,
        parent,
        tree_depth,
        final_nnodes,
        depth_widths,
        node_meta,
        expected_accept_length,
        accept_length_scale_used,
    ) = runner.draft(
        cat_input,
        nodes,
        max_depth,
        print_tree=print_tree,
        tokenizer=tokenizer,
        per_token_probability_bound=per_token_probability_bound,
        per_path_probability_bound=per_path_probability_bound,
        min_width=min_width,
        fixed_width=fixed_width,
        fixed_width_value=fixed_width_value,
        fixed_nnodes=fixed_nnodes,
        fixed_depth=fixed_depth,
    )
    # 실제 사용한 tree의 expected/scale을 저장 (target accept_length와 매칭)
    runner.last_sum_expected_accepted_length = expected_accept_length
    runner.last_accept_length_scale_used = float(accept_length_scale_used) if accept_length_scale_used is not None else 1.0
    
    # draft 함수 반환값에 next_token 추가 (원본 verify Line 249: next_draft = torch.cat([next_token, next_draft], dim=-1))
    next_token_tensor = torch.tensor([[next_token_id]], device=input_ids.device, dtype=torch.long)
    draft_input_ids = torch.cat([next_token_tensor, draft_input_ids], dim=-1)
    head_pos = torch.tensor([cat_input.shape[1]-1], device=draft_position_ids.device)
    draft_position_ids = torch.cat([head_pos, draft_position_ids], dim=-1)
    tree_attention_mask = torch.cat(
        [torch.zeros(1, tree_attention_mask.size(1), dtype=tree_attention_mask.dtype, device=tree_attention_mask.device), tree_attention_mask],
        dim=0,
    )
    tree_attention_mask = torch.cat(
        [torch.ones(tree_attention_mask.size(0), 1, dtype=tree_attention_mask.dtype, device=tree_attention_mask.device), tree_attention_mask],
        dim=1,
    )

    # draft_input_ids는 (head + current_width)만 전송하므로,
    # tree_attention_mask도 (N, N) 정사각으로 맞춰 target이 기대하는 형태로 보낸다.
    # 현재 tree_attention_mask가 (N, 1 + past_cols + (N-1))처럼 커질 수 있어 past_cols 부분을 제거한다.
    n = tree_attention_mask.size(0)
    if tree_attention_mask.size(1) != n and n > 1:
        # 첫 column(head) + 마지막 (n-1) columns만 유지
        tree_attention_mask = torch.cat([tree_attention_mask[:, :1], tree_attention_mask[:, -(n - 1):]], dim=1)

    return draft_input_ids, draft_position_ids, tree_attention_mask, parent, tree_depth, final_nnodes, depth_widths, node_meta


def _select_proactive_path(node_tokens, parent, node_meta):
    """가장 깊은 노드(동률 시 path_prob 최대) 경로 토큰 시퀀스와 path_prob 반환."""
    if not node_meta or not node_tokens or parent is None:
        return None, None
    rows = node_meta.get("rows")
    path_probs = node_meta.get("path_probs")
    if rows is None or path_probs is None:
        return None, None
    if len(rows) != len(node_tokens) or len(parent) != len(node_tokens):
        return None, None
    max_depth = max(rows) if rows else None
    if max_depth is None:
        return None, None
    candidate_indices = [i for i, r in enumerate(rows) if r == max_depth]
    if not candidate_indices:
        return None, None
    best_idx = max(candidate_indices, key=lambda i: path_probs[i] if path_probs is not None else 0.0)
    # 부모 인덱스를 따라 루트까지 경로 복원
    path_indices = []
    seen = set()
    idx = best_idx
    while True:
        if idx in seen:
            break
        seen.add(idx)
        path_indices.append(idx)
        p = parent[idx]
        if p == idx or p < 0 or p >= len(parent):
            break
        idx = p
    path_indices.reverse()
    best_prob = path_probs[best_idx] if path_probs is not None and best_idx is not None else None
    return [node_tokens[i] for i in path_indices], best_prob


@torch.no_grad()
def build_proactive_tree_from_path(
    runner: DraftRunner,
    base_input_ids: torch.Tensor,
    path_tokens: List[int],
    nodes: int,
    max_depth: int,
    tokenizer: AutoTokenizer,
    debug: bool = False,
    print_tree: bool = False,
    per_token_probability_bound: float = 0.0,
    per_path_probability_bound: float = 0.0,
    min_width: int = 1,
    fixed_width: bool = False,
    fixed_width_value: int = None,
    fixed_nnodes: bool = False,
    fixed_depth: bool = False,
    stop_flag: threading.Event = None,
    head_token_holder: dict = None,
):
    """proactive draft tree를 생성하고 head 토큰과 트리 정보를 반환."""
    if not path_tokens:
        return None
    if stop_flag is not None and stop_flag.is_set():
        return None
    device = runner.draft_model.lm_head.weight.device
    # base_input_ids + path_tokens
    path_tensor = torch.tensor([path_tokens], device=base_input_ids.device, dtype=torch.long)
    proactive_input = torch.cat([base_input_ids, path_tensor], dim=-1).to(device)

    # proactive KV 리셋 후 head 토큰 예측
    runner.reset_proactive_kv()
    outputs = None
    # 1) 가능하면 draft_stable_kv 재사용 (base_input_ids + current_next_token까지 이미 계산되어 있음)
    base_kv = runner.draft_stable_kv
    base_len = base_input_ids.shape[1]
    total_len = proactive_input.shape[1]
    if base_kv is not None:
        kv_len = base_kv[0][0].shape[2]
        # 안전 체크: base_kv는 최소한 base_input_ids + 1(current_next_token)까지 커버해야 함
        if kv_len >= base_len + 1 and kv_len <= total_len:
            new_tokens = proactive_input[:, kv_len:].to(device)
            if new_tokens.shape[1] == 0:
                # 새 토큰이 없는 경우: 마지막 토큰을 재계산하여 logits만 얻음
                last_token_id = proactive_input[:, -1:].to(device)
                trimmed_kv = tuple(
                    (kv[0][:, :, :-1, :], kv[1][:, :, :-1, :])
                    for kv in base_kv
                )
                pos_id = torch.tensor([[kv_len - 1]], device=device, dtype=torch.long)
                outputs = runner.draft_model.model(
                    input_ids=last_token_id,
                    past_key_values=trimmed_kv,
                    position_ids=pos_id,
                    return_kv=True,
                    is_draft=True,
                )
            else:
                pos_ids = torch.arange(kv_len, kv_len + new_tokens.shape[1], device=device, dtype=torch.long)
                outputs = runner.draft_model.model(
                    input_ids=new_tokens,
                    past_key_values=base_kv,
                    position_ids=pos_ids,
                    return_kv=True,
                    is_draft=True,
                )
    # 2) fallback: 전체 proactive_input 재계산
    if outputs is None:
        seq_len = proactive_input.shape[1]
        pos_ids = torch.arange(0, seq_len, device=device, dtype=torch.long)
        outputs = runner.draft_model.model(
            input_ids=proactive_input,
            position_ids=pos_ids,
            return_kv=True,
            is_draft=True,
        )
    runner.proactive_kv = outputs[1]
    last_hidden = outputs[0][:, -1]
    logits = runner.draft_model.lm_head(last_hidden)
    proactive_head = int(torch.argmax(logits, dim=-1).item())
    if head_token_holder is not None:
        head_token_holder["head_token"] = proactive_head

    if stop_flag is not None and stop_flag.is_set():
        return None

    # head를 포함해 proactive tree 생성
    cat_input = torch.cat(
        [proactive_input, torch.tensor([[proactive_head]], device=proactive_input.device, dtype=torch.long)], dim=1
    )
    draft_result = runner.draft(
        cat_input,
        nodes,
        max_depth,
        print_tree=print_tree,
        tokenizer=tokenizer,
        per_token_probability_bound=per_token_probability_bound,
        per_path_probability_bound=per_path_probability_bound,
        min_width=min_width,
        fixed_width=fixed_width,
        fixed_width_value=fixed_width_value,
        fixed_nnodes=fixed_nnodes,
        fixed_depth=fixed_depth,
        use_proactive_kv=True,
        track_stats=False,
        stop_flag=stop_flag,
    )
    if draft_result is None:
        return None
    (
        draft_ids,
        draft_pos,
        tree_mask,
        parent,
        tree_depth,
        final_nnodes,
        depth_widths,
        node_meta,
        expected_accept_length,
        accept_length_scale_used,
    ) = draft_result

    # draft 함수 반환값에 head 추가 (build_tree_with_next_token과 동일한 포맷)
    head_tensor = torch.tensor([[proactive_head]], device=draft_ids.device, dtype=torch.long)
    draft_ids = torch.cat([head_tensor, draft_ids], dim=-1)
    head_pos = torch.tensor([cat_input.shape[1]-1], device=draft_pos.device)
    draft_pos = torch.cat([head_pos, draft_pos], dim=-1)
    tree_mask = torch.cat(
        [torch.zeros(1, tree_mask.size(1), dtype=tree_mask.dtype, device=tree_mask.device), tree_mask],
        dim=0,
    )
    tree_mask = torch.cat(
        [torch.ones(tree_mask.size(0), 1, dtype=tree_mask.dtype, device=tree_mask.device), tree_mask],
        dim=1,
    )
    n = tree_mask.size(0)
    if tree_mask.size(1) != n and n > 1:
        tree_mask = torch.cat([tree_mask[:, :1], tree_mask[:, -(n - 1):]], dim=1)

    return {
        "draft_ids": draft_ids,
        "draft_pos": draft_pos,
        "tree_mask": tree_mask,
        "parent": parent,
        "tree_depth": tree_depth,
        "final_nnodes": final_nnodes,
        "depth_widths": depth_widths,
        "node_meta": node_meta,
        "head_token": proactive_head,
        "expected_accept_length": expected_accept_length,
        "accept_length_scale_used": float(accept_length_scale_used) if accept_length_scale_used is not None else 1.0,
    }


def profile_width_timing(
    runner: DraftRunner,
    tokenizer: AutoTokenizer,
    max_depth: int,
    draft_model_path: str,
    device_name: str,
    question_file: str,
    bench_name: str,
    width_list: List[int],
    num_runs_per_width: int = 10,
    fixed_depth: bool = False,
) -> dict:
    """
    width별 평균 처리시간을 프로파일링하고 JSON 파일로 저장
    Target과의 통신 없이 draft 모델만 실행하여 측정
    
    Args:
        runner: DraftRunner 인스턴스
        tokenizer: 토크나이저
        max_depth: 최대 depth
        draft_model_path: Draft 모델 경로
        device_name: 단말 이름 (예: rtx5080)
        question_file: 질문 파일 경로
        bench_name: 벤치마크 이름
        width_list: 프로파일링할 width 리스트 (예: [50, 60, 70, 80, 90, 100])
        num_runs_per_width: 각 width당 실행 횟수
    
    Returns:
        profile_data: 프로파일링 데이터 딕셔너리 (성공 시), None (스킵 시)
    """
    # 모델 이름 추출 (draft_model_path에서)
    # 예: "meta-llama/Llama-2-7b-chat-hf" -> "Llama-2-7b-chat-hf"
    model_name = draft_model_path.split("/")[-1] if "/" in draft_model_path else draft_model_path
    
    # 파일 경로 생성
    script_dir = os.path.dirname(__file__)
    parent_dir = os.path.dirname(script_dir)
    profile_dir = os.path.join(parent_dir, "data", "profile")
    os.makedirs(profile_dir, exist_ok=True)
    profile_file = os.path.join(profile_dir, f"{device_name}_{model_name}_draft.json")
    
    # 파일이 이미 존재하면 스킵
    if os.path.exists(profile_file):
        print(f"프로파일링 파일이 이미 존재합니다: {profile_file}")
        print("프로파일링 단계를 스킵합니다.")
        return None
    
    print(f"\n{'='*80}")
    print("Width별 model.model() 호출 평균 처리시간 프로파일링 시작")
    print(f"프로파일링할 width: {width_list}")
    print(f"각 width당 실행 횟수: {num_runs_per_width}")
    print(f"{'='*80}")
    
    # 프로파일링용 질문 준비
    from fastchat.llm_judge.common import load_questions
    from fastchat.model import get_conversation_template
    
    questions = load_questions(question_file, None, None)
    if len(questions) == 0:
        print("프로파일링할 질문이 없습니다.")
        return None
    
    profile_q = questions[0]
    
    # 대화 템플릿 준비
    if "vicuna" in draft_model_path:
        conv = get_conversation_template("vicuna")
    else:
        conv = get_conversation_template("llama-2-chat")
        sys_p = (
            "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  "
            "Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. "
            "Please ensure that your responses are socially unbiased and positive in nature. If a question does not make any sense, "
            "or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, "
            "please don't share false information."
        )
        conv.system_message = sys_p
    
    # bench_name에 따라 질문 형식 결정
    profile_turns = [profile_q["question"]] if bench_name == "gsm8k" else profile_q["turns"]
    conv.append_message(conv.roles[0], profile_turns[0])
    conv.append_message(conv.roles[1], None)
    prompt = conv.get_prompt() + " "
    input_ids = tokenizer([prompt]).input_ids
    input_ids_t = torch.as_tensor(input_ids).to("cuda")
    
    device = runner.draft_model.lm_head.weight.device
    
    # 초기 input_ids로 모델 실행하여 첫 번째 hidden state 얻기 (한 번만)
    runner.reset_kv()
    input_ids_for_profile = input_ids_t.to(device)
    draft_outputs = runner.draft_model.model(
        input_ids=input_ids_for_profile,
        position_ids=torch.arange(0, input_ids_for_profile.shape[1], device=device, dtype=torch.long),
        return_kv=True,
        is_draft=True,
    )
    last_hidden = draft_outputs[0][:, -1]
    last_headout = runner.draft_model.lm_head(last_hidden)
    vocab_size = last_headout.shape[-1]
    
    # 프로파일링 데이터 저장용
    profile_data = {}
    
    # 각 width에 대해 프로파일링
    with torch.no_grad():
        for width in width_list:
            print(f"\n프로파일링 중: width={width}")
            model_call_times = []     # 이 함수에서 직접 측정한 모델 호출 시간 모음
            
            # 각 width당 여러 번 실행
            for run_idx in range(num_runs_per_width):
                # 각 run마다 KV와 logits을 리셋해 KV 길이가 누적되지 않도록 함
                runner.reset_kv()
                fresh_outputs = runner.draft_model.model(
                    input_ids=input_ids_for_profile,
                    position_ids=torch.arange(0, input_ids_for_profile.shape[1], device=device, dtype=torch.long),
                    return_kv=True,
                    is_draft=True,
                )
                fresh_last_hidden = fresh_outputs[0][:, -1]
                fresh_last_headout = runner.draft_model.lm_head(fresh_last_hidden)
                
                # Tree 객체 생성 및 초기화 (fixed_width로 고정하여 원하는 width만 측정)
                tree = Tree(
                    width,
                    device,
                    max_depth,
                    per_token_probability_bound=0.0,
                    per_path_probability_bound=0.0,
                    fixed_width=width,
                    fixed_nnodes=False,
                    fixed_depth=fixed_depth,
                    accept_length_margin=self.accept_length_margin,
                )
                
                # initialize 실행 (시간 측정 포함)
                # initialize()는 logits[0][-1]을 사용하므로 (batch_size, seq_len, vocab_size) 형태가 필요함.
                # fresh_last_headout는 보통 (1, vocab_size) 형태이므로, 여기서 (1, 1, vocab_size)로 정규화한다.
                headout_1d = fresh_last_headout[0] if fresh_last_headout.dim() == 2 else fresh_last_headout  # (vocab_size,)
                init_logits = torch.softmax(headout_1d.unsqueeze(0).unsqueeze(0), dim=-1, dtype=torch.float32)  # (1, 1, vocab_size)
                tree_output = tree.update(init_logits, print_tree=False, tokenizer=tokenizer)
                
                # 더미 logits로 model.model() 호출 시간 여러 번 실행
                # KV cache 초기화 (프로파일링용)
                past_key_values = fresh_outputs[1]
                init_len = past_key_values[0][0].size(2)
                len_posi = input_ids_for_profile.shape[1] - 1
                logits = fresh_last_headout.unsqueeze(0)
                draft_time = None  # 첫 번째 update에서는 None
                
                for depth in range(1, max_depth + 1):
                    if tree_output.get("is_final", False):
                        break
                    
                    # update 함수 실행 (model_time 전달)
                    # model.model() 호출 시간은 logits[0]를 사용하므로 (batch_size, prev_width, vocab_size) 형태 필요
                    logits_for_update = logits.unsqueeze(0) if logits.dim() == 2 else logits  # (prev_width, vocab_size) -> (1, prev_width, vocab_size)
                    tree_output = tree.update(torch.softmax(logits_for_update.to(last_hidden.device), dim=-1, dtype=torch.float32), print_tree=False, tokenizer=tokenizer, draft_time=draft_time)
                    input_ids_step = tree_output["input_ids"].unsqueeze(0)
                    position_ids = tree_output["position_ids"] + len_posi   # [DH] 상대적 index(트리에서 몇 번째 인지) -> 절대적 index로 변환 (전체 input_ids에서 몇 번째인지)
                    if tree_output.get("is_final", False):
                        break
                    
                    # 현재 past_key_values의 길이 계산
                    if past_key_values is not None:
                        actual_past_length = past_key_values[0][0].shape[2]
                    else:
                        actual_past_length = init_len
                    
                    # tree_attention_mask에서 past_cols 계산
                    tree_attention_mask = tree_output["attention_mask"]
                    current_width = tree_attention_mask.size(0)
                    tree_mask_cols = tree_attention_mask.size(1)
                    past_cols = tree_mask_cols - current_width
                    
                    # process_tree_mask에 전달할 init_len 계산
                    # init_len + past_cols + current_width = actual_past_length + current_width
                    # 따라서: init_len = actual_past_length - past_cols
                    init_len_for_mask = actual_past_length - past_cols
                    init_len_for_mask = max(0, init_len_for_mask)  # 음수 방지
                    
                    tree_attention_mask_with_kv = runner.process_tree_mask(tree_output["attention_mask"], init_len_for_mask)
                    
                    # draft_model.model 호출 시간 측정
                    if isinstance(input_ids_step, torch.Tensor) and input_ids_step.is_cuda:
                        torch.cuda.synchronize()
                    model_start_time = time.time()
                    draft_outputs = runner.draft_model.model(
                        input_ids=input_ids_step,
                        position_ids=position_ids,
                        past_key_values=past_key_values,
                        tree_attention_mask=tree_attention_mask_with_kv,
                        return_kv=True,
                        is_draft=True,
                    )
                    if isinstance(draft_outputs[0], torch.Tensor) and draft_outputs[0].is_cuda:
                        torch.cuda.synchronize()
                    draft_time = time.time() - model_start_time
                    model_call_times.append(draft_time)
                    # Tree 확장 후 KV 업데이트 (local variable)
                    past_key_values = draft_outputs[1]
                    
                    last_hidden = draft_outputs[0]
                    last_headout = runner.draft_model.lm_head(last_hidden)
                    logits = last_headout
                
                # 메모리 단편화 방지용 정리 (존재하는 변수만 삭제)
                for _var in ["past_key_values", "draft_outputs", "tree_output", "logits_for_update", "tree_attention_mask_with_kv", "input_ids_step", "position_ids"]:
                    if _var in locals():
                        del locals()[_var]
                torch.cuda.empty_cache()
        
            # draft_model.model 호출 시간 (이 함수에서 직접 측정)
            count_call = len(model_call_times)
            total_ms_call = sum(model_call_times) * 1000 if count_call > 0 else 0.0
            avg_ms_call = (total_ms_call / count_call) if count_call > 0 else 0.0
            min_ms_call = (min(model_call_times) * 1000) if count_call > 0 else 0.0
            max_ms_call = (max(model_call_times) * 1000) if count_call > 0 else 0.0
            
            profile_data[width] = {
                'model_call_count': count_call,
                'model_call_total_time_ms': total_ms_call,
                'model_call_avg_time_ms': avg_ms_call,
                'model_call_min_time_ms': min_ms_call,
                'model_call_max_time_ms': max_ms_call,
            }
            print(
                f"  width={width}: model calls {count_call}회, 총 {total_ms_call:.3f}ms, "
                f"평균 {avg_ms_call:.3f}ms, 최소 {min_ms_call:.3f}ms, 최대 {max_ms_call:.3f}ms"
            )
    
    # JSON 파일로 저장
    if profile_data:
        with open(profile_file, 'w') as f:
            json.dump(profile_data, f, indent=2)
        print(f"\n프로파일링 데이터 저장 완료: {profile_file}")
        print(f"수집된 width 개수: {len(profile_data)}")
    else:
        print("\n프로파일링 데이터가 없습니다.")
        return None
    
    return profile_data


def run_warmup(
    sock,
    runner: DraftRunner,
    tokenizer: AutoTokenizer,
    questions: List[dict],
    base_model_path: str,
    bench_name: str,
    nodes: int,
    max_depth: int,
    per_token_probability_bound: float,
    per_path_probability_bound: float,
    min_width: int,
    fixed_width: bool,
    fixed_width_value: int,
    fixed_nnodes: bool,
    fixed_depth: bool,
    debug: bool,
    warmup_cost_sensitivity: float = None,
    warmup_rounds: int = 3,
    full_query: bool = False,
):
    """Warmup/reference 실행 공용 함수.
    - full_query=False: 짧은 warmup (기존과 동일한 조기 종료 조건)
    - full_query=True : 질문 1개를 가능한 끝까지 처리(reference 계산용)
    """
    if not questions:
        return {"token_per_second": 0.0, "cost_per_token": 0.0, "objective_per_token": 0.0}
    original_cost_sensitivity = runner.cost_sensitivity
    if warmup_cost_sensitivity is not None:
        runner.cost_sensitivity = float(warmup_cost_sensitivity)
    warmup_total_new_tokens = 0
    warmup_total_wall_time_sec = 0.0
    warmup_total_draft_time_sec = 0.0
    warmup_total_target_verification_time_sec = 0.0
    warmup_total_d2t_bytes = 0.0
    warmup_total_t2d_bytes = 0.0
    try:
        run_rounds = max(1, int(warmup_rounds))
        for _ in range(run_rounds):
            torch.manual_seed(0)
            # Warmup마다 KV cache 리셋
            runner.reset_kv()
            warm_q = questions[0]  # WIPWIPWIPWIP
            if "vicuna" in base_model_path:
                conv = get_conversation_template("vicuna")
            else:
                conv = get_conversation_template("llama-2-chat")
                sys_p = (
                    "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  "
                    "Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. "
                    "Please ensure that your responses are socially unbiased and positive in nature. If a question does not make any sense, "
                    "or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, "
                    "please don't share false information."
                )
                conv.system_message = sys_p
            warm_turns = [warm_q["question"]] if bench_name == "gsm8k" else warm_q["turns"]
            conv.append_message(conv.roles[0], warm_turns[0])
            conv.append_message(conv.roles[1], None)
            prompt = conv.get_prompt() + " "
            input_ids = tokenizer([prompt]).input_ids
            input_ids_t = torch.as_tensor(input_ids).to("cuda")
            turn_wall_start_time = time.time()

            send_json_with_size(sock, {"type": "init", "input_ids": input_ids[0]})
            reply, _ = recv_json_with_size(sock)
            if reply.get("type") != "init_ok":
                break
            current_next_token = reply["next_token"]

            warm_steps = 0
            while True:
                tree_build_start_time = time.time()
                if runner.gpu_monitor:
                    runner.gpu_monitor.start_monitoring()
                draft_ids, draft_pos, tree_mask, parent, tree_depth, final_nnodes, depth_widths, node_meta = build_tree_with_next_token(
                    runner, input_ids_t, nodes, max_depth, current_next_token, tokenizer, debug, print_tree=False, per_token_probability_bound=per_token_probability_bound, per_path_probability_bound=per_path_probability_bound, min_width=min_width, fixed_width=fixed_width, fixed_width_value=fixed_width_value, fixed_nnodes=fixed_nnodes, fixed_depth=fixed_depth
                )
                tree_build_end_time = time.time()
                payload = {
                    "type": "tree_step",
                    "draft_input_ids": draft_ids[0].tolist(),
                    "draft_position_ids": draft_pos.tolist(),
                    "tree_attention_mask": tree_mask.tolist(),
                    "parent": parent.tolist(),
                }
                # Draft → Target 전송 시간 측정: Draft가 보내기 시작하는 시점
                send_start_time = time.time()
                d2t_bytes = send_json_with_size(sock, payload)
                # 본 실험과 유사하게 트리 생성 + 전송 직후까지 GPU 모니터링
                if runner.gpu_monitor:
                    runner.gpu_monitor.stop_monitoring()
                    warmup_gpu_stats = runner.gpu_monitor.get_stats()
                    runner.update_draft_objective_rate_from_gpu(warmup_gpu_stats)

                # Target → Draft 전송 시간 측정: Draft가 Target의 응답을 다 받은 시점
                reply, t2d_bytes = recv_json_with_size(sock)
                recv_end_time = time.time()
                warmup_total_d2t_bytes += float(d2t_bytes)
                warmup_total_t2d_bytes += float(t2d_bytes)
                if reply.get("type") != "verify_result":
                    break
                accepted_tokens: List[int] = reply["accepted_tokens"]
                current_next_token = reply["next_token"]
                eos_reached: bool = reply["eos_reached"]
                best_ids: List[int] = reply["best_ids"]
                base_input_len: int = reply.get("base_input_len", input_ids_t.shape[1])
                target_verification_time = reply.get("target_verification_time_ms", None)
                if target_verification_time is not None:
                    warmup_total_target_verification_time_sec += max(0.0, float(target_verification_time) / 1000.0)

                # TODO:Accept된 경로의 KV만 유지
                # base_kv_len은 draft() 호출 전 input_ids 길이 (old_input_ids)
                # 하지만 draft_stable_kv는 draft() 호출 후 상태이므로,
                # base_kv_len을 draft_stable_kv의 이전 길이로 추정해야 함
                # base_kv_len = base_input_len
                # update_kv_with_accepted(runner, best_ids, base_kv_len, current_next_token, debug)
                # print(runner.draft_stable_kv[0][0].shape[2])

                input_ids_t = torch.cat([
                    input_ids_t,
                    torch.tensor([accepted_tokens], device=input_ids_t.device, dtype=torch.long),
                ], dim=-1)
                warmup_total_new_tokens += len(accepted_tokens) + 1  # accepted + next_token

                # 이전 tree의 정보 저장 (warmup 루프에서도 업데이트)
                # timing_stats에서 total_time_seconds 추출, 없으면 네트워크 왕복 시간 사용
                timing_stats = reply.get("timing_stats", {})
                # total_time = timing_stats.get("total_time_seconds", None)
                # if total_time is None:
                # 본 실험과 동일하게 E2E 시간으로 집계:
                # tree build + Draft→Target→Draft 왕복
                tree_build_time_sec = max(0.0, float(tree_build_end_time - tree_build_start_time))
                network_roundtrip_sec = max(0.0, float(recv_end_time - send_start_time))
                total_time = tree_build_time_sec + network_roundtrip_sec
                warmup_total_draft_time_sec += float(tree_build_time_sec)

                # 실제 측정된 전송 시간 계산 (warmup에서는 간단히 전체 시간 사용)
                # warmup에서는 상세한 전송 시간 측정이 없으므로 None으로 설정
                transfer_time = None
                draft_to_target_time = 0.0
                target_to_draft_time = 0.0
                target_recv_end_time = reply.get("target_recv_end_time", None)
                target_send_start_time = reply.get("target_send_start_time", None)
                if target_recv_end_time is not None and target_send_start_time is not None:
                    draft_to_target_time = max(0.05, (target_recv_end_time - send_start_time) * 1000.0)  # ms
                    target_to_draft_time = max(0.05, (recv_end_time - target_send_start_time) * 1000.0)  # ms
                    transfer_time = (draft_to_target_time + target_to_draft_time) / 1000.0  # 초로 변환

                runner.prev_tree_final_nnodes = final_nnodes
                runner.prev_tree_depth = tree_depth
                runner.prev_tree_total_target_time = total_time
                runner.prev_tree_transfer_time = transfer_time
                runner.prev_tree_accept_length = len(accepted_tokens)
                # 밀리초를 초로 변환하여 토큰별 전송 시간 계산 (소수점 표현)
                runner.per_token_draft_to_target_transfer_time = (draft_to_target_time / 1000.0) / final_nnodes if final_nnodes > 0 else 0.0
                runner.per_token_target_to_draft_transfer_time = (target_to_draft_time / 1000.0) / len(accepted_tokens) if len(accepted_tokens) > 0 else 0.0
                runner.per_token_draft_to_target_bytes = (float(d2t_bytes) / final_nnodes) if final_nnodes > 0 else 0.0
                runner.per_token_target_to_draft_bytes = (float(t2d_bytes) / len(accepted_tokens)) if len(accepted_tokens) > 0 else 0.0

                warm_steps += 1
                if full_query:
                    should_stop = eos_reached or input_ids_t.shape[1] > 4096
                else:
                    should_stop = eos_reached or warm_steps > 5 or input_ids_t.shape[1] > 512
                if should_stop:
                    break
            warmup_total_wall_time_sec += max(0.0, float(time.time() - turn_wall_start_time))

        # Warmup 종료 후 통계 리셋: warmup에서 누적된 값이 결과에 섞이지 않도록 전체(run) 통계까지 리셋
        runner.reset_timing_stats(reset_global=True)
        print("Warmup done")
        warmup_tps = (warmup_total_new_tokens / warmup_total_wall_time_sec) if warmup_total_wall_time_sec > 0 else 0.0
        bytes_per_gb = float(1024 ** 3)
        warmup_comm_cost = (
            ((warmup_total_d2t_bytes + warmup_total_t2d_bytes) / bytes_per_gb) * float(runner.communication_per_gb_cost)
            if bytes_per_gb > 0
            else 0.0
        )
        warmup_draft_cost = 0.0 if runner.no_draft_cost else (warmup_total_draft_time_sec * float(runner.draft_per_sec_cost))
        warmup_target_cost = warmup_total_target_verification_time_sec * float(runner.target_per_sec_cost)
        warmup_total_cost = warmup_draft_cost + warmup_target_cost + warmup_comm_cost
        warmup_cost_per_token = (warmup_total_cost / warmup_total_new_tokens) if warmup_total_new_tokens > 0 else 0.0
        if str(getattr(runner, "objective_metric", "cost")).lower() == "energy":
            warmup_objective_per_token = (
                runner.get_draft_objective_rate_per_sec() / warmup_tps
                if warmup_tps > 0
                else 0.0
            )
        else:
            warmup_objective_per_token = warmup_cost_per_token
        if warmup_objective_per_token <= 0 and warmup_tps > 0:
            # objective rate를 얻지 못한 경우 안전한 fallback
            warmup_objective_per_token = 1.0 / warmup_tps
        return {
            "token_per_second": float(warmup_tps),
            "cost_per_token": float(warmup_cost_per_token),
            "objective_per_token": float(warmup_objective_per_token),
            "draft_objective_rate_per_sec": float(runner.get_draft_objective_rate_per_sec()),
        }
    finally:
        if runner.gpu_monitor:
            try:
                runner.gpu_monitor.stop_monitoring()
            except Exception:
                pass
        runner.cost_sensitivity = original_cost_sensitivity


def _sanitize_key_component(value: str, max_len: int = 48) -> str:
    if value is None:
        value = "none"
    value = str(value).strip().lower()
    safe = []
    for ch in value:
        if ch.isalnum() or ch in ("-", "_", "."):
            safe.append(ch)
        else:
            safe.append("-")
    normalized = "".join(safe)
    while "--" in normalized:
        normalized = normalized.replace("--", "-")
    normalized = normalized.strip("-") or "none"
    return normalized[:max_len]


def _normalize_model_identifier(value: str) -> str:
    """모델 식별 문자열을 캐시 키용으로 정규화."""
    if value is None:
        return "unknown"
    normalized = str(value).strip().replace("\\", "/").rstrip("/")
    normalized = normalized.lower()
    return normalized or "unknown"


def _reference_cache_paths(
    base_model_path: str,
    draft_model_path: str,
    bench_name: str,
    objective_metric: str,
    server_name: str,
    device_name: str,
):
    script_dir = os.path.dirname(__file__)
    parent_dir = os.path.dirname(script_dir)
    reference_dir = os.path.join(parent_dir, "data", "reference")
    os.makedirs(reference_dir, exist_ok=True)

    normalized_target_model = _normalize_model_identifier(base_model_path)
    normalized_draft_model = _normalize_model_identifier(draft_model_path)
    key_payload = {
        "server_gpu": str(server_name) if server_name is not None else "unknown",
        "target_model": normalized_target_model,
        "user_gpu": str(device_name) if device_name is not None else "unknown",
        "draft_model": normalized_draft_model,
        "dataset": str(bench_name),
        "metric": str(objective_metric).lower(),
    }
    key_str = json.dumps(key_payload, sort_keys=True, ensure_ascii=True)
    key_hash = hashlib.sha256(key_str.encode("utf-8")).hexdigest()[:12]

    target_model_name = os.path.basename(normalized_target_model)
    draft_model_name = os.path.basename(normalized_draft_model)
    filename = (
        f"ref_{_sanitize_key_component(server_name)}_"
        f"{_sanitize_key_component(target_model_name)}_"
        f"{_sanitize_key_component(device_name or 'unknown')}_"
        f"{_sanitize_key_component(draft_model_name)}_"
        f"{_sanitize_key_component(bench_name)}_"
        f"{_sanitize_key_component(objective_metric)}_"
        f"{key_hash}.json"
    )
    cache_path = os.path.join(reference_dir, filename)
    return reference_dir, cache_path


def load_reference_cache(
    base_model_path: str,
    draft_model_path: str,
    bench_name: str,
    objective_metric: str,
    server_name: str,
    device_name: str,
):
    _, cache_path = _reference_cache_paths(
        base_model_path=base_model_path,
        draft_model_path=draft_model_path,
        bench_name=bench_name,
        objective_metric=objective_metric,
        server_name=server_name,
        device_name=device_name,
    )
    if not os.path.exists(cache_path):
        return None, cache_path
    try:
        with open(cache_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"[WARN] Failed to read reference cache ({cache_path}): {e}")
        return None, cache_path

    required = ["reference_tps", "reference_cost_per_token", "reference_objective_per_token"]
    if any(k not in data for k in required):
        print(f"[WARN] Invalid reference cache schema, ignoring: {cache_path}")
        return None, cache_path
    return data, cache_path


def save_reference_cache(
    cache_path: str,
    warmup_metrics: dict,
):
    payload = {
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "warmup_cost_sensitivity": 50.0,
        "reference_tps": float(warmup_metrics.get("token_per_second", 0.0)),
        "reference_cost_per_token": float(warmup_metrics.get("cost_per_token", 0.0)),
        "reference_objective_per_token": float(warmup_metrics.get("objective_per_token", 0.0)),
        "reference_draft_objective_rate_per_sec": float(
            warmup_metrics.get("draft_objective_rate_per_sec", 0.0)
        ),
    }
    try:
        with open(cache_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[WARN] Failed to write reference cache ({cache_path}): {e}")


def reset_gpu_monitor_after_reference(runner: "DraftRunner"):
    """reference 계산 후 GPU 모니터 내부 버퍼/카운터 초기화."""
    gpu_monitor = getattr(runner, "gpu_monitor", None)
    if gpu_monitor is None:
        return
    try:
        gpu_monitor.stop_monitoring()
    except Exception:
        pass
    try:
        gpu_monitor.data = []
        gpu_monitor.monitor_call_count = 0
    except Exception:
        pass


def load_server_only_baseline_metric(
    baseline_json: str,
    base_model_path: str,
    draft_model_path: str,
):
    """Server-only baseline tps/cost_per_token (cost_per_token derived from target_per_sec_cost at call site)."""
    if not baseline_json or not os.path.exists(baseline_json):
        print(f"[INFO] server-only disabled: baseline file not found ({baseline_json}).")
        return None
    try:
        with open(baseline_json, "r", encoding="utf-8") as f:
            data = json.load(f)
        key = f"{base_model_path}|{draft_model_path}"
        pair = data.get("model_pairs", {}).get(key)
        if not isinstance(pair, dict):
            print(f"[INFO] server-only disabled: no baseline for model pair '{key}'.")
            return None
        tps = pair.get("token_per_second", None)
        if tps is None:
            print(f"[INFO] server-only disabled: token_per_second missing for '{key}'.")
            return None
        tps = float(tps)
        if tps <= 0:
            print(f"[INFO] server-only disabled: invalid token_per_second={tps} for '{key}'.")
            return None
        return tps
    except Exception as e:
        print(f"[INFO] server-only disabled: failed to load baseline ({e}).")
        return None


def _get_profile_paths(
    draft_model_path: str,
    base_model_path: str,
    bench_name: str,
    device_name: str,
    server_name: str,
):
    script_dir = os.path.dirname(__file__)
    parent_dir = os.path.dirname(script_dir)
    profile_dir = os.path.join(parent_dir, "data", "profile")
    draft_model_name = draft_model_path.split("/")[-1] if "/" in draft_model_path else draft_model_path
    base_model_name = base_model_path.split("/")[-1] if "/" in base_model_path else base_model_path
    draft_profile_file = os.path.join(profile_dir, f"{device_name}_{draft_model_name}_draft.json")
    target_profile_file = os.path.join(profile_dir, f"{server_name}_{base_model_name}_target.json")
    return draft_profile_file, target_profile_file


def load_profile_data(
    runner: DraftRunner,
    tokenizer: AutoTokenizer,
    max_depth: int,
    draft_model_path: str,
    base_model_path: str,
    bench_name: str,
    device_name: str,
    server_name: str,
    question_file: str,
    fixed_depth: bool,
    debug: bool,
):
    """프로파일링 데이터 로드 (draft 누락 시 자동 생성)."""
    if not device_name:
        return
    draft_profile_file, target_profile_file = _get_profile_paths(
        draft_model_path=draft_model_path,
        base_model_path=base_model_path,
        bench_name=bench_name,
        device_name=device_name,
        server_name=server_name,
    )

    # Draft 프로파일링 데이터 로드 (없으면 생성)
    profile_data = None
    if os.path.exists(draft_profile_file):
        try:
            with open(draft_profile_file, 'r') as f:
                profile_data = json.load(f)
            if debug:
                print(f"프로파일링 데이터를 로드했습니다: {draft_profile_file}")
        except Exception as e:
            if debug:
                print(f"프로파일링 데이터 로드 실패: {e}")
            profile_data = None
    else:
            # 프로파일링할 width 리스트 (실험에 사용할 width)
        width_list = [3, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]  # 필요시 argparse로 받을 수 있도록 수정 가능
        print(f"Draft 프로파일링 파일이 없습니다. 프로파일링을 시작합니다: {draft_profile_file}")
        profile_data = profile_width_timing(
            runner=runner,
            tokenizer=tokenizer,
            max_depth=max_depth,
            draft_model_path=draft_model_path,
            device_name=device_name,
            question_file=question_file,
            bench_name=bench_name,
            width_list=width_list,
            num_runs_per_width=100,  # 각 width당 실행 횟수
            fixed_depth=fixed_depth,
        )
        if profile_data:
            print(f"Draft 프로파일링 완료: {len(profile_data)}개의 width에 대한 데이터 수집")


    # Target 프로파일링 데이터 로드 (파일이 존재하면)
    target_profile_data = None
    if os.path.exists(target_profile_file):
        try:
            with open(target_profile_file, 'r') as f:
                target_profile_data = json.load(f)
            if debug:
                print(f"Target 프로파일링 데이터를 로드했습니다: {target_profile_file}")
        except Exception as e:
            if debug:
                print(f"Target 프로파일링 데이터 로드 실패: {e}")
            target_profile_data = None
    else:
        print(f"Target 프로파일링 파일이 없습니다. Target 프로파일링은 별도로 실행해야 합니다: {target_profile_file}")

    # DraftRunner에 프로파일링 데이터 설정
    runner.profile_data = profile_data
    runner.target_profile_data = target_profile_data

def run_draft(
    host: str,
    port: int,
    base_model_path: str,
    draft_model_path: str,
    bench_name: str,
    question_file: str,
    limit: int,
    temperature: float,
    nodes: int,
    max_depth: int,
    device_map: str,
    load_in_4bit: bool,
    load_in_8bit: bool,
    answer_file: str = None,
    model_id: str = "llama-2-chat",
    num_choices: int = 1,
    debug: bool = False,
    print_tree: bool = False,
    per_token_probability_bound: float = 0.0,
    per_path_probability_bound: float = 0.0,
    device_name: str = None,
    draft_per_hour_cost: float = 0.0,
    target_per_hour_cost: float = 0.0,
    communication_per_gb_cost: float = (35.0 / 15.0),
    accept_length_margin: float = 0.05,
    cost_sensitivity: float = 0.0,
    opt_tree: bool = False,
    model_family: str = "llama2",
    min_width: int = 1,
    fixed_depth: bool = False,
    fixed_nnodes: bool = False,
    fixed_width: bool = False,
    fixed_width_value: int = None,
    server_name: str = "rtxproa6000",
    enable_gpu_monitor: bool = False,
    gpu_monitor_interval: float = 0.1,
    enable_cpu_monitor: bool = False,
    proactive_drafting: bool = True,
    proactive_threshold: float = 0.0,
    adaptive_proactive_threshold: bool = False,
    no_draft_cost: bool = False,
    objective_metric: str = "cost",
    server_only_baseline_json: str = None,
    disable_server_only: bool = False,
):
    objective_metric = str(objective_metric).lower()
    if objective_metric not in {"cost", "energy"}:
        raise ValueError(f"Unsupported objective_metric: {objective_metric}. Use 'cost' or 'energy'.")
    if objective_metric == "energy" and not enable_gpu_monitor:
        print("[INFO] objective_metric=energy -> enabling GPU monitor automatically.")
        enable_gpu_monitor = True
    accept_length_margin = max(0.0, min(0.99, float(accept_length_margin)))
    if not server_only_baseline_json:
        script_dir = os.path.dirname(__file__)
        parent_dir = os.path.dirname(script_dir)
        server_only_baseline_json = os.path.join(parent_dir, "data", "profile", "server_only_sd_baseline.json")
    # 드래프트 모델만 로드
    quantization_config = None
    if load_in_8bit:
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_8bit=True,
            llm_int8_threshold=6.0,
            llm_int8_skip_modules=["lm_head"],
        )
    elif load_in_4bit:
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
        )
    KVLlamaForCausalLM = get_kv_llama_class(base_model_path)
    draft_model = KVLlamaForCausalLM.from_pretrained(
        draft_model_path,
        torch_dtype=torch.float16,
        low_cpu_mem_usage=True,
        device_map=device_map,
        quantization_config=quantization_config,
        token="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",
        # token="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",
    )
    tokenizer = AutoTokenizer.from_pretrained(
        base_model_path,
        token="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",
        # token="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",
    )
    # 시간당 비용을 초당 비용으로 변환
    draft_per_sec_cost = draft_per_hour_cost / 3600.0
    target_per_sec_cost = target_per_hour_cost / 3600.0
    runner = DraftRunner(
        draft_model=draft_model,
        tokenizer=tokenizer,
        debug=debug,
        draft_per_sec_cost=draft_per_sec_cost,
        target_per_sec_cost=target_per_sec_cost,
        communication_per_gb_cost=communication_per_gb_cost,
        cost_sensitivity=cost_sensitivity,
        enable_gpu_monitor=enable_gpu_monitor,
        gpu_monitor_interval=gpu_monitor_interval,
        enable_cpu_monitor=enable_cpu_monitor,
        opt_tree=opt_tree,
        no_draft_cost=no_draft_cost,
        objective_metric=objective_metric,
        accept_length_margin=accept_length_margin,
    )

    # 프로파일링 데이터 로드 (device_name이 제공된 경우)
    load_profile_data(
        runner=runner,
        tokenizer=tokenizer,
        max_depth=max_depth,
        draft_model_path=draft_model_path,
        base_model_path=base_model_path,
        bench_name=bench_name,
        device_name=device_name,
        server_name=server_name,
        question_file=question_file,
        fixed_depth=fixed_depth,
        debug=debug,
    )

    with socket.create_connection((host, port)) as sock:
        questions = load_questions(question_file, None, None)
        if limit and limit > 0:
            questions = questions[:limit]

        reference_cache, reference_cache_path = load_reference_cache(
            base_model_path=base_model_path,
            draft_model_path=draft_model_path,
            bench_name=bench_name,
            objective_metric=objective_metric,
            server_name=server_name,
            device_name=device_name,
        )
        print("[Warmup] Running warmup (3 rounds)")
        run_warmup(
            sock=sock,
            runner=runner,
            tokenizer=tokenizer,
            questions=questions,
            base_model_path=base_model_path,
            bench_name=bench_name,
            nodes=nodes,
            max_depth=max_depth,
            per_token_probability_bound=per_token_probability_bound,
            per_path_probability_bound=per_path_probability_bound,
            min_width=min_width,
            fixed_width=fixed_width,
            fixed_width_value=fixed_width_value,
            fixed_nnodes=fixed_nnodes,
            fixed_depth=fixed_depth,
            debug=debug,
            warmup_cost_sensitivity=50.0,
            warmup_rounds=3,
            full_query=False,
        )
        if reference_cache is not None:
            runner.reference_tps = float(reference_cache.get("reference_tps", runner.reference_tps))
            runner.reference_cost_per_token = float(
                reference_cache.get("reference_cost_per_token", runner.reference_cost_per_token)
            )
            runner.reference_objective_per_token = float(
                reference_cache.get("reference_objective_per_token", runner.reference_objective_per_token)
            )
            if objective_metric == "energy":
                cached_rate = float(reference_cache.get("reference_draft_objective_rate_per_sec", 0.0) or 0.0)
                if cached_rate > 0:
                    runner.draft_objective_rate_per_sec = cached_rate
            print(f"[Reference] Loaded cached reference: {reference_cache_path}")
        else:
            print("[Reference] No cache found. Running live single-query reference (full query).")
            reference_metrics = run_warmup(
                sock=sock,
                runner=runner,
                tokenizer=tokenizer,
                questions=questions,
                base_model_path=base_model_path,
                bench_name=bench_name,
                nodes=nodes,
                max_depth=max_depth,
                per_token_probability_bound=per_token_probability_bound,
                per_path_probability_bound=per_path_probability_bound,
                min_width=min_width,
                fixed_width=fixed_width,
                fixed_width_value=fixed_width_value,
                fixed_nnodes=fixed_nnodes,
                fixed_depth=fixed_depth,
                debug=debug,
                warmup_cost_sensitivity=50.0,
                warmup_rounds=1,
                full_query=True,
            )
            reference_tps = float(reference_metrics.get("token_per_second", 0.0))
            reference_cost_per_token = float(reference_metrics.get("cost_per_token", 0.0))
            reference_obj_per_token = float(reference_metrics.get("objective_per_token", 0.0))
            reference_draft_objective_rate_per_sec = float(
                reference_metrics.get("draft_objective_rate_per_sec", 0.0)
            )
            if reference_tps > 0:
                runner.reference_tps = float(reference_tps)
            if reference_cost_per_token > 0:
                runner.reference_cost_per_token = float(reference_cost_per_token)
            if reference_obj_per_token > 0:
                runner.reference_objective_per_token = float(reference_obj_per_token)
            if objective_metric == "energy" and reference_draft_objective_rate_per_sec > 0:
                runner.draft_objective_rate_per_sec = float(reference_draft_objective_rate_per_sec)
            save_reference_cache(
                cache_path=reference_cache_path,
                warmup_metrics=reference_metrics,
            )
            print(f"[Reference] Saved reference cache: {reference_cache_path}")
        print(
            "[Warmup Reference] "
            f"reference_tps={runner.reference_tps:.6f}, "
            f"reference_cost_per_token={runner.reference_cost_per_token:.12f}, "
            f"reference_objective_per_token={runner.reference_objective_per_token:.12f}"
        )
        reset_gpu_monitor_after_reference(runner)
        server_only_mode = False
        server_only_tps = None
        if not disable_server_only:
            server_only_tps = load_server_only_baseline_metric(
                baseline_json=server_only_baseline_json,
                base_model_path=base_model_path,
                draft_model_path=draft_model_path,
            )
        else:
            print("[INFO] server-only disabled by --disable-server-only.")
        if server_only_tps is not None and server_only_tps > 0:
            alpha = runner.get_sensitivity_alpha()
            ref_tps = max(1e-9, runner.reference_tps)
            ref_obj = runner.get_reference_objective_per_token()
            warmup_score = 1.0  # reference 대비 자기 자신
            if objective_metric == "cost":
                server_only_obj_per_token = (target_per_sec_cost / server_only_tps) if server_only_tps > 0 else float("inf")
            else:
                # energy 모드: server-only의 draft objective는 0으로 간주
                server_only_obj_per_token = 0.0
            server_only_score = (
                alpha * (server_only_obj_per_token / ref_obj)
                + (1.0 - alpha) * (ref_tps / max(1e-9, server_only_tps))
            )
            if server_only_score < warmup_score:
                server_only_mode = True
                print("Entering server-only mode...")
            else:
                print("Staying in draft-target mode (server-only not beneficial by normalized objective).")

        grand_total_steps = 0
        grand_total_accepted = 0
        grand_total_draft_tokens = 0
        grand_total_new_tokens = 0
        proactive_draft_attempts = 0
        proactive_tree_used = 0
        proactive_used_path_prob_sum = 0.0
        proactive_used_path_prob_count = 0
        proactive_unused_path_prob_sum = 0.0
        proactive_unused_path_prob_count = 0
        proactive_used_tree_steps = 0
        proactive_used_tree_depth_sum = 0.0
        proactive_used_tree_width_sum = 0.0
        proactive_used_tree_final_nodes_sum = 0.0
        proactive_used_tree_accept_length_sum = 0.0
        proactive_used_tree_scaled_expected_sum = 0.0
        proactive_total_time_sec = 0.0
        server_only_total_session_time_sec = 0.0
        last_tree_build_ms = None
        last_target_verification_ms = None
        last_draft_to_target_ms = None
        last_target_to_draft_ms = None
        run_start_time = time.time()

        # 네트워크/accept 통계 집계용
        network_latency_records = []
        global_draft_to_target_times = []
        global_target_to_draft_times = []
        global_accept_lengths = []
        global_t2d_per_accept_len = {}
        global_d2t_per_final_nnodes = {}  # final_nnodes별 draft_to_target_time 수집용

        choices_list = []
        all_answers = []  # 모든 답변을 저장할 리스트
        tree_width_records = []  # 트리 생성 시 depth별 width 및 통계 기록
        
        # Latency 통계 수집용 리스트
        latency_data = []  # 각 step별 latency 데이터
        # run 전체 통신 바이트 누적 (통신비 계산용)
        run_draft_to_target_bytes = []
        run_target_to_draft_bytes = []
        
        # Accept length 수집용 (accept_stats 계산을 위해)
        all_accept_lengths = []  # 모든 step의 accept_length 수집
        # Expected accept length (sum_expected_accepted_length) 수집용: 실제 accept_length와 매칭하여 bucket 평균 계산
        all_expected_accept_lengths_per_step = []  # 모든 step의 expected accept length(원본) 수집 (tree.sum_expected_accepted_length)
        all_scaled_expected_accept_lengths_per_step = []  # 모든 step의 scaled expected accept length 수집 (expected * accept_length_scale_used)
        
        # Number of nodes 수집용 (avg_number_of_nodes 계산을 위해)
        all_final_nnodes = []  # 모든 step의 final_nnodes 수집
        
        # GPU 모니터링 데이터 수집용
        draft_gpu_data = []  # 각 step별 GPU 데이터
        draft_timing_data = []  # 각 step별 timing 데이터 (에너지 계산용)
        # CPU 전력 모니터링 데이터 수집용
        draft_cpu_power_data = []  # 각 step별 CPU 전력 데이터
        
        for question in tqdm(questions):
            # breakpoint()
            question_start_time = time.time()  # 질문 처리 시작 시간
            choices = []
            draft_to_target_time_per_question = []
            target_to_draft_time_per_question = []
            accept_length_per_question = []
            t2d_per_accept_len_per_question = {}
            d2t_per_final_nnodes_per_question = {}  # final_nnodes별 draft_to_target_time 수집용
            # 전송/수신 데이터 크기 기록
            draft_to_target_bytes_per_question = []
            target_to_draft_bytes_per_question = []

            
            for i in range(num_choices):
                torch.manual_seed(i)
                # 각 question마다 KV cache 리셋
                runner.reset_kv()
                
                # 대화 템플릿 준비
                if "vicuna" in base_model_path:
                    conv = get_conversation_template("vicuna")
                else:
                    conv = get_conversation_template("llama-2-chat")
                    sys_p = (
                        "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  "
                        "Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. "
                        "Please ensure that your responses are socially unbiased and positive in nature. If a question does not make any sense, "
                        "or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, "
                        "please don't share false information."
                    )
                    conv.system_message = sys_p

                if bench_name == "gsm8k":
                    question_turns = [question["question"]]
                else:
                    question_turns = question["turns"]

                turns = []
                idxs = []
                new_tokens_list = []
                wall_time_list = []
                for j in range(len(question_turns)):
                    qs = question_turns[j]
                    conv.append_message(conv.roles[0], qs)
                    conv.append_message(conv.roles[1], None)
                    prompt = conv.get_prompt() + " "
                    input_ids = tokenizer([prompt]).input_ids
                    input_ids_t = torch.as_tensor(input_ids).to("cuda")


                    if server_only_mode:
                        draft_send_start_time = time.time()
                        d2t_bytes = send_json_with_size(sock, {
                            "type": "server_only_init",
                            "input_ids": input_ids[0],
                            "nodes": int(nodes),
                            "max_depth": int(max_depth),
                            "per_token_probability_bound": float(per_token_probability_bound),
                            "per_path_probability_bound": float(per_path_probability_bound),
                            "min_width": int(min_width),
                            "fixed_width": bool(fixed_width),
                            "fixed_width_value": fixed_width_value,
                            "fixed_nnodes": bool(fixed_nnodes),
                            "fixed_depth": bool(fixed_depth),
                            "proactive_drafting": bool(proactive_drafting),
                            "proactive_threshold": float(proactive_threshold),
                            "adaptive_proactive_threshold": bool(adaptive_proactive_threshold),
                            "cost_sensitivity": float(cost_sensitivity),
                            "draft_per_sec_cost": float(draft_per_sec_cost),
                            "target_per_sec_cost": float(target_per_sec_cost),
                            "reference_tps": float(runner.reference_tps),
                            "reference_objective_per_token": float(runner.reference_objective_per_token),
                            "objective_metric": str(objective_metric),
                            "no_draft_cost": bool(no_draft_cost),
                        })
                        reply, t2d_bytes = recv_json_with_size(sock)
                        draft_recv_end_time = time.time()
                    else:
                        # 초기 base 토큰 1개는 target에게 요청
                        draft_send_start_time = time.time()
                        d2t_bytes = send_json_with_size(sock, {"type": "init", "input_ids": input_ids[0]})
                        reply, t2d_bytes = recv_json_with_size(sock)
                        draft_recv_end_time = time.time()
                    
                    # 전송/수신 크기 기록
                    draft_to_target_bytes_per_question.append(d2t_bytes)
                    target_to_draft_bytes_per_question.append(t2d_bytes)
                    run_draft_to_target_bytes.append(d2t_bytes)
                    run_target_to_draft_bytes.append(t2d_bytes)

                    # 전송 시간 계산
                    target_recv_end_time = reply.get("target_recv_end_time", None)
                    target_send_start_time = reply.get("target_send_start_time", None)
                    # Draft → Target 전송 시간
                    draft_to_target_time = None
                    if target_recv_end_time is not None :
                        draft_to_target_time = max(0.05, (target_recv_end_time - draft_send_start_time) * 1000.0)  # ms
                        draft_to_target_time_per_question.append(draft_to_target_time)
    
                    # Target → Draft 전송 시간
                    target_to_draft_time = None
                    if target_send_start_time is not None:
                        target_to_draft_time = max(0.05, (draft_recv_end_time - target_send_start_time) * 1000.0)  # ms
                        target_to_draft_time_per_question.append(target_to_draft_time)
                        if 1 not in t2d_per_accept_len_per_question:
                            t2d_per_accept_len_per_question[0] = []
                        t2d_per_accept_len_per_question[0].append(target_to_draft_time)
                    
                    accept_length_per_question.append(0)

                    
                    if server_only_mode:
                        reply_type = reply.get("type")
                        if reply_type != "server_only_ok":
                            raise RuntimeError(
                                "server_only_init failed: "
                                f"type={reply_type}, message={reply.get('message')}, reply={reply}"
                            )
                        current_next_token = None
                    else:
                        assert reply.get("type") == "init_ok"
                        current_next_token = reply["next_token"]

                    output_tokens: List[int] = []
                    new_token_count = 0
                    turn_steps = 0
                    pending_proactive = None
                    use_proactive_tree = False
                    proactive_tree = None
                    
                    torch.cuda.synchronize()
                    turn_start_time = time.time()

                    while True:
                        if server_only_mode:
                            reply, t2d_bytes = recv_json_with_size(sock)
                            draft_recv_end_time = time.time()
                            # server-only에서는 step마다 Target -> Draft 응답 바이트가 발생
                            target_to_draft_bytes_per_question.append(t2d_bytes)
                            run_target_to_draft_bytes.append(t2d_bytes)
                            if reply.get("type") == "server_only_done":
                                break
                            if reply.get("type") != "verify_result":
                                raise RuntimeError(
                                    "server-only step failed: "
                                    f"type={reply.get('type')}, message={reply.get('message')}, reply={reply}"
                                )
                            accepted_tokens: List[int] = reply["accepted_tokens"]
                            accept_length: int = reply["accept_length"]
                            next_token: int = reply["next_token"]
                            eos_reached: bool = reply["eos_reached"]
                            target_verification_time = reply.get("target_verification_time_ms", None)
                            tree_build_time = reply.get("tree_build_time_ms", 0.0)
                            draft_to_target_time = reply.get("draft_to_target_time_ms", None)
                            target_to_draft_time = reply.get("target_to_draft_time_ms", None)
                            if draft_to_target_time is not None:
                                draft_to_target_time = max(0.05, float(draft_to_target_time))
                            if target_to_draft_time is not None:
                                target_to_draft_time = max(0.05, float(target_to_draft_time))
                            final_nnodes = int(reply.get("final_nnodes", 0))
                            tree_depth = int(reply.get("tree_depth", 0))
                            depth_widths = reply.get("depth_widths", [])
                            if draft_to_target_time is not None:
                                draft_to_target_time_per_question.append(draft_to_target_time)
                            if target_to_draft_time is not None:
                                target_to_draft_time_per_question.append(target_to_draft_time)
                            accept_length_per_question.append(accept_length)
                            all_final_nnodes.append(final_nnodes)
                            if isinstance(depth_widths, list) and depth_widths:
                                avg_width = float(sum(depth_widths) / len(depth_widths))
                                tree_width_records.append({
                                    "question_id": question["question_id"],
                                    "choice_idx": i,
                                    "step": turn_steps,
                                    "depth_widths": [int(w) for w in depth_widths],
                                    "avg_width": avg_width,
                                    "final_nnodes": int(final_nnodes),
                                    "tree_depth": int(tree_depth),
                                })
                            if target_verification_time is not None:
                                last_target_verification_ms = float(target_verification_time)
                            if draft_to_target_time is not None:
                                last_draft_to_target_ms = float(draft_to_target_time)
                            if target_to_draft_time is not None:
                                last_target_to_draft_ms = float(target_to_draft_time)
                            last_tree_build_ms = float(tree_build_time)
                            step_latency = {
                                "tree_build_time_ms": tree_build_time,
                                "draft_to_target_time_ms": draft_to_target_time,
                                "target_verification_time_ms": target_verification_time,
                                "target_to_draft_time_ms": target_to_draft_time,
                                # server-only에서는 step 단위 draft->target payload가 없으므로 0으로 기록
                                "draft_to_target_bytes": 0,
                                "target_to_draft_bytes": t2d_bytes,
                                "total_time_ms": (tree_build_time or 0.0)
                                + (draft_to_target_time or 0.0)
                                + (target_verification_time or 0.0)
                                + (target_to_draft_time or 0.0),
                            }
                            latency_data.append(step_latency)
                            output_tokens.extend(accepted_tokens)
                            new_token_count += len(accepted_tokens)
                            turn_steps += 1
                            # server-only에서도 verify_result 단위로 step/token 통계를 집계한다.
                            grand_total_steps += 1
                            grand_total_accepted += int(accept_length)
                            grand_total_draft_tokens += int(tree_depth)
                            all_accept_lengths.append(int(accept_length))
                            if eos_reached or new_token_count >= 1024:
                                # server-only 프로토콜은 마지막 verify_result 뒤에
                                # server_only_done 메시지를 한 번 더 보내므로,
                                # 여기서 즉시 break하지 않고 done을 수신할 때까지 루프를 지속한다.
                                continue
                            continue
                        # GPU 모니터링 시작 (build_tree_with_next_token 전)
                        if runner.gpu_monitor:
                            runner.gpu_monitor.start_monitoring()
                        # CPU 전력 모니터링 시작 (GPU 모니터링과 동일한 타이밍)
                        if runner.cpu_power_monitor:
                            runner.cpu_power_monitor.start_monitoring()
                        
                        # 드래프트 트리 생성 시간 측정
                        torch.cuda.synchronize()
                        tree_build_start_time = time.time()
                        proactive_elapsed_sec = 0.0
                        current_tree_is_proactive = False
                        if use_proactive_tree and proactive_tree is not None:
                            draft_ids = proactive_tree["draft_ids"]
                            draft_pos = proactive_tree["draft_pos"]
                            tree_mask = proactive_tree["tree_mask"]
                            parent = proactive_tree["parent"]
                            tree_depth = proactive_tree["tree_depth"]
                            final_nnodes = proactive_tree["final_nnodes"]
                            depth_widths = proactive_tree["depth_widths"]
                            node_meta = proactive_tree.get("node_meta")
                            # proactive tree의 expected/scale을 매칭용으로 저장
                            runner.last_sum_expected_accepted_length = proactive_tree.get("expected_accept_length")
                            runner.last_accept_length_scale_used = float(
                                proactive_tree.get("accept_length_scale_used", 1.0)
                            )
                            use_proactive_tree = False
                            proactive_tree = None
                            current_tree_is_proactive = True
                        else:
                            # 드래프트 트리 생성 (타겟이 보낸 next_token을 사용)
                            # input_ids_t (이전 timeslot의 accepted tokens 포함) + next_token을 사용
                            draft_ids, draft_pos, tree_mask, parent, tree_depth, final_nnodes, depth_widths, node_meta = build_tree_with_next_token(
                                runner, input_ids_t, nodes, max_depth, current_next_token, tokenizer, debug, print_tree, per_token_probability_bound=per_token_probability_bound, per_path_probability_bound=per_path_probability_bound, min_width=min_width, fixed_width=fixed_width, fixed_width_value=fixed_width_value, fixed_nnodes=fixed_nnodes, fixed_depth=fixed_depth
                            )
                        torch.cuda.synchronize()
                        tree_build_end_time = time.time()
                        tree_build_time = (tree_build_end_time - tree_build_start_time) * 1000.0  # ms
                        # 트리 width 기록
                        avg_width = float(sum(depth_widths) / len(depth_widths)) if depth_widths else 0.0
                        tree_width_records.append({
                            "question_id": question["question_id"],
                            "choice_idx": i,
                            "step": turn_steps,
                            "depth_widths": [int(w) for w in depth_widths],
                            "avg_width": avg_width,
                            "final_nnodes": int(final_nnodes),
                            "tree_depth": int(tree_depth),
                        })
                        all_final_nnodes.append(final_nnodes)
                        
                        # target에게 검증 요청
                        payload = {
                            "type": "tree_step",
                            "draft_input_ids": draft_ids[0].tolist(),
                            "draft_position_ids": draft_pos.tolist(),
                            "tree_attention_mask": tree_mask.tolist(),
                            "parent": parent.tolist(),
                        }
                        # Draft → Target 전송 시간 측정: Draft가 보내기 시작하는 시점
                        draft_send_start_time = time.time()
                        d2t_bytes = send_json_with_size(sock, payload)

                        # proactive drafting: 전송한 트리에서 가장 깊은 노드 기반으로 미리 트리 생성 (백그라운드)
                        pending_proactive = None
                        proactive_thread = None
                        proactive_stop_flag = None
                        proactive_result = {"tree": None, "error": None, "elapsed_sec": None, "head_token": None}
                        if proactive_drafting:
                            proactive_stop_flag = threading.Event()
                            try:
                                node_tokens = draft_ids[0].tolist()[1:]  # head 제외
                                parent_list = parent.tolist() if isinstance(parent, torch.Tensor) else list(parent)
                                proactive_path, proactive_path_prob = _select_proactive_path(node_tokens, parent_list, node_meta)
                                should_start_proactive = False
                                if proactive_path and proactive_path_prob is not None:
                                    path_prob = float(proactive_path_prob)
                                    has_adaptive_stats = (
                                        last_target_verification_ms is not None
                                        and last_draft_to_target_ms is not None
                                        and last_target_to_draft_ms is not None
                                    )
                                    if adaptive_proactive_threshold and has_adaptive_stats:
                                        overlap_ms = min(
                                            float(tree_build_time),
                                            float(last_target_verification_ms)
                                            + float(last_draft_to_target_ms)
                                            + float(last_target_to_draft_ms),
                                        )
                                        overlap_sec = max(0.0, overlap_ms / 1000.0)
                                        expected_latency_gain_sec = path_prob * overlap_sec
                                        cost_per_sec = runner.get_draft_objective_rate_per_sec()
                                        expected_cost_loss = (1.0 - path_prob) * (overlap_sec * cost_per_sec)
                                        # normalized gain: (1-alpha)*latency_gain_norm - alpha*cost_loss_norm
                                        alpha = runner.get_sensitivity_alpha()
                                        latency_gain_norm = expected_latency_gain_sec / max(1e-9, runner.get_reference_latency_per_token())
                                        cost_loss_norm = expected_cost_loss / runner.get_reference_objective_per_token()
                                        if ((1.0 - alpha) * latency_gain_norm - alpha * cost_loss_norm) >= 0:
                                            should_start_proactive = True
                                    else:
                                        if path_prob >= float(proactive_threshold):
                                            should_start_proactive = True

                                if should_start_proactive:
                                    # current_next_token 포함한 경로로 proactive tree 생성
                                    proactive_path = [current_next_token] + proactive_path

                                    def _build_proactive_tree():
                                        start_time = time.time()
                                        try:
                                            proactive_result["tree"] = build_proactive_tree_from_path(
                                                runner=runner,
                                                base_input_ids=input_ids_t,
                                                path_tokens=proactive_path,
                                                nodes=nodes,
                                                max_depth=max_depth,
                                                tokenizer=tokenizer,
                                                debug=debug,
                                                print_tree=False,
                                                per_token_probability_bound=per_token_probability_bound,
                                                per_path_probability_bound=per_path_probability_bound,
                                                min_width=min_width,
                                                fixed_width=fixed_width,
                                                fixed_width_value=fixed_width_value,
                                                fixed_nnodes=fixed_nnodes,
                                                fixed_depth=fixed_depth,
                                                stop_flag=proactive_stop_flag,
                                                head_token_holder=proactive_result,
                                            )
                                        except Exception as e:
                                            proactive_result["error"] = e
                                        finally:
                                            proactive_result["elapsed_sec"] = time.time() - start_time

                                    proactive_thread = threading.Thread(target=_build_proactive_tree, daemon=True)
                                    proactive_thread.start()
                                    proactive_draft_attempts += 1
                            except Exception as e:
                                if debug:
                                    print(f"[DRAFT-DEBUG] proactive drafting failed: {e}")
                        
                        # GPU 모니터링 중지 및 통계 수집 (send_json_with_size() 후)
                        gpu_stats = None
                        if runner.gpu_monitor:
                            runner.gpu_monitor.stop_monitoring()
                            gpu_stats = runner.gpu_monitor.get_stats()
                        # CPU 전력 모니터링 중지 및 통계 수집
                        cpu_power_stats = None
                        if runner.cpu_power_monitor:
                            if debug:
                                print(f"[draft] CPU 전력 모니터 중지 전: monitor_call_count={runner.cpu_power_monitor.monitor_call_count}, data_count={len(runner.cpu_power_monitor.data)}")
                            runner.cpu_power_monitor.stop_monitoring()
                            cpu_power_stats = runner.cpu_power_monitor.get_stats()
                            if debug:
                                print(f"[draft] CPU 전력 통계 수집 결과: {cpu_power_stats}")
                        else:
                            if debug:
                                print(f"[draft] 경고: CPU 전력 모니터가 None입니다 (enable_cpu_monitor가 True인지 확인)")

                        # Target → Draft 전송 시간 측정: Draft가 Target의 응답을 다 받은 시점
                        reply, t2d_bytes = recv_json_with_size(sock)
                        draft_recv_end_time = time.time()
                        
                        # 전송/수신 크기 기록
                        draft_to_target_bytes_per_question.append(d2t_bytes)
                        target_to_draft_bytes_per_question.append(t2d_bytes)
                        run_draft_to_target_bytes.append(d2t_bytes)
                        run_target_to_draft_bytes.append(t2d_bytes)
                        assert reply.get("type") == "verify_result"
                        accepted_tokens: List[int] = reply["accepted_tokens"]
                        accept_length: int = reply["accept_length"]
                        next_token: int = reply["next_token"]
                        eos_reached: bool = reply["eos_reached"]
                        best_ids: List[int] = reply["best_ids"]

                        # proactive tree 사용 여부 결정
                        if proactive_drafting:
                            canceled = False
                            if proactive_thread is not None:
                                cancel_reason = None
                                if accept_length != tree_depth:
                                    cancel_reason = "accept_length_mismatch"
                                else:
                                    proactive_head = proactive_result.get("head_token")
                                    if proactive_head is None or next_token != proactive_head:
                                        cancel_reason = "head_mismatch"
                                if cancel_reason is not None:
                                    canceled = True
                                    proactive_stop_flag.set()
                                    runner.reset_proactive_kv()
                                    pending_proactive = None
                                else:
                                    proactive_thread.join()
                                    if proactive_result["error"] and debug:
                                        print(f"[DRAFT-DEBUG] proactive drafting failed: {proactive_result['error']}")
                                    pending_proactive = proactive_result["tree"]
                                    if proactive_result.get("elapsed_sec") is not None:
                                        proactive_elapsed_sec = float(proactive_result["elapsed_sec"])
                                        proactive_total_time_sec += proactive_elapsed_sec

                            if pending_proactive and accept_length == tree_depth and next_token == pending_proactive.get("head_token"):
                                use_proactive_tree = True
                                proactive_tree = pending_proactive
                                # proactive KV를 메인 KV로 승격
                                runner.draft_stable_kv = runner.proactive_kv
                                proactive_tree_used += 1
                                if proactive_path_prob is not None:
                                    proactive_used_path_prob_sum += float(proactive_path_prob)
                                    proactive_used_path_prob_count += 1
                            else:
                                if not canceled:
                                    if proactive_thread is not None:
                                        proactive_stop_flag.set()
                                    runner.reset_proactive_kv()
                                use_proactive_tree = False
                                proactive_tree = None
                                if proactive_path_prob is not None:
                                    proactive_unused_path_prob_sum += float(proactive_path_prob)
                                    proactive_unused_path_prob_count += 1
                        else:
                            runner.reset_proactive_kv()
                            use_proactive_tree = False
                            proactive_tree = None
                        # proactive 계산 시간도 tree_build_time에 포함 (미사용 트리 포함)
                        if proactive_elapsed_sec > 0:
                            tree_build_time += proactive_elapsed_sec * 1000.0
                        
                        # 전송 시간 계산
                        target_recv_end_time = reply.get("target_recv_end_time", None)
                        target_send_start_time = reply.get("target_send_start_time", None)
                        target_verification_time = reply.get("target_verification_time_ms", None)  # Target에서 계산된 검증 시간 (ms)
                        
                        # Draft → Target 전송 시간
                        draft_to_target_time = None
                        if target_recv_end_time is not None :
                            draft_to_target_time = max(0.05, (target_recv_end_time - draft_send_start_time) * 1000.0)  # ms
                            draft_to_target_time_per_question.append(draft_to_target_time)
                            # final_nnodes별 draft_to_target_time 수집
                            if final_nnodes not in d2t_per_final_nnodes_per_question:
                                d2t_per_final_nnodes_per_question[final_nnodes] = []
                            d2t_per_final_nnodes_per_question[final_nnodes].append(draft_to_target_time)
                        
                        # Target → Draft 전송 시간
                        target_to_draft_time = None
                        if target_send_start_time is not None:
                            target_to_draft_time = max(0.05, (draft_recv_end_time - target_send_start_time) * 1000.0)  # ms
                            target_to_draft_time_per_question.append(target_to_draft_time)
                            if accept_length not in t2d_per_accept_len_per_question:
                                t2d_per_accept_len_per_question[accept_length] = []
                            t2d_per_accept_len_per_question[accept_length].append(target_to_draft_time)
                        
                        # Latency 데이터 수집
                        step_latency = {
                            "tree_build_time_ms": tree_build_time,
                            "draft_to_target_time_ms": draft_to_target_time,
                            "target_verification_time_ms": target_verification_time,
                            "target_to_draft_time_ms": target_to_draft_time,
                            "draft_to_target_bytes": d2t_bytes,
                            "target_to_draft_bytes": t2d_bytes,
                            "accept_length": accept_length,
                            # Draft가 예측한 expected accept length (tree.sum_expected_accepted_length)
                            "expected_accept_length": runner.last_sum_expected_accepted_length,
                        }
                        latency_data.append(step_latency)
                        if tree_build_time is not None:
                            last_tree_build_ms = float(tree_build_time)
                        if target_verification_time is not None:
                            last_target_verification_ms = float(target_verification_time)
                        if draft_to_target_time is not None:
                            last_draft_to_target_ms = float(draft_to_target_time)
                        if target_to_draft_time is not None:
                            last_target_to_draft_ms = float(target_to_draft_time)

                        # accept_length(실측) / expected_accept_length(예측) 오차율 업데이트 (다음 슬롯부터 예측 보정에 사용)
                        # 예: accept_length=12, expected=10 -> scale=1.2
                        try:
                            exp_len = float(runner.last_sum_expected_accepted_length) if runner.last_sum_expected_accepted_length is not None else None
                        except Exception:
                            exp_len = None
                        if exp_len is not None and exp_len > 0 and accept_length is not None and int(accept_length) > 0:
                            ratio = float(int(accept_length)) / exp_len
                            if ratio == ratio and ratio > 0:  # NaN 체크 및 양수
                                runner.accept_length_ratio_sum += float(ratio)
                                runner.accept_length_ratio_count += 1
                        if current_tree_is_proactive:
                            proactive_used_tree_steps += 1
                            proactive_used_tree_depth_sum += float(tree_depth)
                            proactive_used_tree_width_sum += float(avg_width)
                            proactive_used_tree_final_nodes_sum += float(final_nnodes)
                            proactive_used_tree_accept_length_sum += float(accept_length)
                            if runner.last_sum_expected_accepted_length is not None:
                                try:
                                    proactive_used_tree_scaled_expected_sum += (
                                        float(runner.last_sum_expected_accepted_length)
                                        * float(getattr(runner, "last_accept_length_scale_used", 1.0))
                                    )
                                except Exception:
                                    pass

                        # target_verification_time(실측) / target_profile_data(예측) 오차율 업데이트 (다음 슬롯부터 예측시간 보정에 사용)
                        # key 형식은 Tree.get_objective_value에서 사용하는 것과 동일하게 유지: width_{current_width}_depth_{depth}_nnodes_{nnodes}
                        if target_verification_time is not None and runner.target_profile_data is not None:
                            try:
                                width_for_key = int(depth_widths[-1]) if depth_widths else int(final_nnodes)
                            except Exception:
                                width_for_key = None
                            try:
                                depth_for_key = int(tree_depth) if tree_depth is not None else None
                            except Exception:
                                depth_for_key = None
                            if width_for_key is not None and depth_for_key is not None:
                                profile_key = f"width_{width_for_key}_depth_{depth_for_key}_nnodes_{int(final_nnodes)}"
                                predicted_ms = runner.target_profile_data.get(profile_key, {}).get("avg_time_ms", None)
                                if predicted_ms is not None and predicted_ms > 0:
                                    ratio = float(target_verification_time) / float(predicted_ms)
                                    if ratio == ratio and ratio > 0:
                                        runner.target_verification_ratio_sum += float(ratio)
                                        runner.target_verification_ratio_count += 1
                        
                        # GPU 데이터 수집 (에너지 계산용)
                        if gpu_stats:
                            step_time = tree_build_time / 1000.0  # ms를 초로 변환
                            runner.update_draft_objective_rate_from_gpu(gpu_stats)
                            draft_gpu_data.append({
                                "step": turn_steps,
                                "timestamp": datetime.now().isoformat(),
                                "gpu_stats": gpu_stats,
                                "monitor_call_count": runner.gpu_monitor.monitor_call_count if runner.gpu_monitor else None
                            })
                            draft_timing_data.append({
                                "total_time_seconds": step_time,
                                "timestamp": datetime.now().isoformat(),
                            })
                        # CPU 전력 데이터 수집
                        if cpu_power_stats:
                            step_time = tree_build_time / 1000.0  # ms를 초로 변환
                            draft_cpu_power_data.append({
                                "step": turn_steps,
                                "timestamp": datetime.now().isoformat(),
                                "cpu_power_stats": cpu_power_stats,
                                "monitor_call_count": runner.cpu_power_monitor.monitor_call_count if runner.cpu_power_monitor else None
                            })
                            if debug:
                                print(f"[draft] CPU 전력 데이터 추가됨 (step: {turn_steps}, 총 수집 수: {len(draft_cpu_power_data)})")
                        else:
                            if debug:
                                print(f"[draft] 경고: CPU 전력 통계가 None입니다 (step: {turn_steps})")
                        
                        # 디버그 출력 (선택사항)
                        if debug:
                            print(f"[DRAFT-DEBUG] Draft → Target 전송 시간: {draft_to_target_time:.3f}ms")
                            print(f"[DRAFT-DEBUG] Target → Draft 전송 시간: {target_to_draft_time:.3f}ms")
                            print(f"[DRAFT-DEBUG] Draft → Target 전송 크기: {d2t_bytes}bytes")
                            print(f"[DRAFT-DEBUG] Target → Draft 전송 크기: {t2d_bytes}bytes")
                        
                        # 이전 tree의 정보 저장 (다음 tree 생성 시 사용)
                        # timing_stats에서 total_time_seconds 추출, 없으면 네트워크 왕복 시간 사용
                        timing_stats = reply.get("timing_stats", {})
                        # total_time = timing_stats.get("total_time_seconds", None)
                        # if total_time is None:
                        # 전체 왕복 시간 계산 (Draft → Target → Draft)
                        total_time = max(0.0, target_recv_end_time - draft_send_start_time)
                        
                        # 실제 측정된 전송 시간 계산 (초 단위)
                        transfer_time = None
                        if draft_to_target_time is not None and target_to_draft_time is not None:
                            transfer_time = (draft_to_target_time + target_to_draft_time) / 1000.0  # ms를 초로 변환
                        
                        runner.prev_tree_final_nnodes = final_nnodes
                        runner.prev_tree_depth = tree_depth
                        runner.prev_tree_total_target_time = total_time
                        runner.prev_tree_transfer_time = transfer_time
                        runner.prev_tree_accept_length = accept_length
                        # 밀리초를 초로 변환하여 토큰별 전송 시간 계산 (소수점 표현)
                        if draft_to_target_time is not None and final_nnodes > 0:
                            runner.per_token_draft_to_target_transfer_time = (draft_to_target_time / 1000.0) / final_nnodes
                            runner.per_token_draft_to_target_bytes = float(d2t_bytes) / final_nnodes
                        if target_to_draft_time is not None and accept_length > 0:
                            runner.per_token_target_to_draft_transfer_time = (target_to_draft_time / 1000.0) / accept_length
                            runner.per_token_target_to_draft_bytes = float(t2d_bytes) / accept_length

                        # TODO:Accept된 경로의 KV만 유지
                        # base_kv_len = input_ids_t.shape[1]
                        # update_kv_with_accepted(runner, best_ids, base_kv_len, next_token, debug)

                        # 수락된 토큰들을 입력에 붙임. input_ids_t + accepted_tokens
                        input_ids_t = torch.cat([
                            input_ids_t,
                            torch.tensor([accepted_tokens], device=input_ids_t.device, dtype=torch.long),
                        ], dim=-1)

                        output_tokens.extend(accepted_tokens)
                        new_token_count += accept_length + 1
                        turn_steps += 1

                        # 통계 누적
                        grand_total_steps += 1
                        grand_total_accepted += accept_length
                        grand_total_draft_tokens += int(tree_depth)
                        # accept_length 누적
                        # accept_length_list.append(int(accept_length))
                        accept_length_per_question.append(int(accept_length))
                        all_accept_lengths.append(int(accept_length))  # accept_stats 계산을 위해 전역 리스트에 추가
                        all_expected_accept_lengths_per_step.append(runner.last_sum_expected_accepted_length)
                        # scaled_expected = expected(원본) * (그 step에서 Tree에 전달된 accept_length_scale)
                        if runner.last_sum_expected_accepted_length is not None:
                            try:
                                all_scaled_expected_accept_lengths_per_step.append(
                                    float(runner.last_sum_expected_accepted_length) * float(getattr(runner, "last_accept_length_scale_used", 1.0))
                                )
                            except Exception:
                                pass

                        # 다음 라운드를 위해 최신 next_token 저장
                        current_next_token = next_token

                        if eos_reached or new_token_count > 1024 or input_ids_t.shape[1] > 1960:
                            break
                    
                    torch.cuda.synchronize()
                    turn_end_time = time.time()
                    turn_wall_time = turn_end_time - turn_start_time
                    if server_only_mode:
                        # server-only에서는 turn_wall_time을 서버 점유 시간으로 사용
                        server_only_total_session_time_sec += float(turn_wall_time)
                    
                    # 질문이 끝났을 때 width별 draft_model.model 호출 시간 통계 출력
                    # runner.print_timing_stats()
                    runner.reset_timing_stats()  # 다음 질문을 위해 통계 리셋

                    # Stop token 처리 (원본과 동일하게)
                    if conv.stop_token_ids:
                        stop_token_ids_index = [
                            idx
                            for idx, token_id in enumerate(output_tokens)
                            if token_id in conv.stop_token_ids
                        ]
                        if len(stop_token_ids_index) > 0:
                            output_tokens = output_tokens[:stop_token_ids_index[0]]
                    
                    # 디코딩
                    decoded = tokenizer.decode(output_tokens, spaces_between_special_tokens=False)
                    
                    # Stop string 처리
                    if conv.stop_str and decoded.find(conv.stop_str) > 0:
                        decoded = decoded[:decoded.find(conv.stop_str)]
                    
                    # Special token 제거
                    for special_token in tokenizer.special_tokens_map.values():
                        if isinstance(special_token, list):
                            for special_tok in special_token:
                                decoded = decoded.replace(special_tok, "")
                        else:
                            decoded = decoded.replace(special_token, "")
                    
                    decoded = decoded.strip()
                    
                    if conv.name == "xgen" and decoded.startswith("Assistant:"):
                        decoded = decoded.replace("Assistant:", "", 1).strip()

                    turns.append(decoded)
                    idxs.append(int(turn_steps))
                    new_tokens_list.append(int(new_token_count))
                    wall_time_list.append(turn_wall_time)
                    
                    conv.messages[-1][-1] = decoded

                # 질문별 시간 측정
                avg_draft_to_target = float(sum(draft_to_target_time_per_question) / len(draft_to_target_time_per_question)) if draft_to_target_time_per_question else None
                avg_target_to_draft = float(sum(target_to_draft_time_per_question) / len(target_to_draft_time_per_question)) if target_to_draft_time_per_question else None
                avg_accept_length = float(sum(accept_length_per_question) / len(accept_length_per_question)) if accept_length_per_question else None
                accept_len_bucket_stats = {}
                for length, times in t2d_per_accept_len_per_question.items():
                    if not times:
                        continue
                    accept_len_bucket_stats[int(length)] = {
                        "count": len(times),
                        "avg_target_to_draft_time_ms": float(sum(times) / len(times)),
                        "min_target_to_draft_time_ms": float(min(times)),
                        "max_target_to_draft_time_ms": float(max(times)),
                        "times_ms": [float(t) for t in times],
                    }
                # final_nnodes별 draft_to_target_time 통계 계산
                final_nnodes_bucket_stats = {}
                for nnodes, times in d2t_per_final_nnodes_per_question.items():
                    if not times:
                        continue
                    final_nnodes_bucket_stats[int(nnodes)] = {
                        "count": len(times),
                        "avg_draft_to_target_time_ms": float(sum(times) / len(times)),
                        "min_draft_to_target_time_ms": float(min(times)),
                        "max_draft_to_target_time_ms": float(max(times)),
                        "times_ms": [float(t) for t in times],
                    }
                

                choices.append({
                    "index": i, 
                    "turns": turns, 
                    "idxs": idxs, 
                    "new_tokens": new_tokens_list, 
                    "wall_time": wall_time_list,
                })

            # 질문별 네트워크/accept 통계 기록
            network_latency_records.append({
                "question_id": question["question_id"],
                "draft_to_target_time_ms": draft_to_target_time_per_question,
                "target_to_draft_time_ms": target_to_draft_time_per_question,
                "draft_to_target_bytes": draft_to_target_bytes_per_question,
                "target_to_draft_bytes": target_to_draft_bytes_per_question,
                "accept_length": accept_length_per_question,
                "avg_draft_to_target_time_ms": avg_draft_to_target,
                "avg_target_to_draft_time_ms": avg_target_to_draft,
                "avg_accept_length": avg_accept_length,
                "accept_length_bucket_stats": accept_len_bucket_stats,
                "final_nnodes_bucket_stats": final_nnodes_bucket_stats,
            })

            global_draft_to_target_times.extend(draft_to_target_time_per_question)
            global_target_to_draft_times.extend(target_to_draft_time_per_question)
            global_accept_lengths.extend(accept_length_per_question)
            for length, times in t2d_per_accept_len_per_question.items():
                if length not in global_t2d_per_accept_len:
                    global_t2d_per_accept_len[length] = []
                global_t2d_per_accept_len[length].extend(times)
            # final_nnodes별 draft_to_target_time 전역 통계 수집
            for nnodes, times in d2t_per_final_nnodes_per_question.items():
                if nnodes not in global_d2t_per_final_nnodes:
                    global_d2t_per_final_nnodes[nnodes] = []
                global_d2t_per_final_nnodes[nnodes].extend(times)
            
            # all_accept_lengths는 이미 위에서 추가됨 (각 step에서)
            
            # 답변 저장 (통합 파일에 저장하기 위해 리스트에 추가)
            question_elapsed_time = time.time() - question_start_time  # 질문 처리에 걸린 실제 시간 (초)
            ans_json = {
                "question_id": question["question_id"],
                "answer_id": shortuuid.uuid(),
                "model_id": model_id,
                "choices": choices,
                "tstamp": question_elapsed_time,
            }
            all_answers.append(ans_json)

        # 전체 결과 요약 출력 (원본 포맷과 정렬)
        total_time = max(1e-6, time.time() - run_start_time)
        tokens_per_step = (grand_total_accepted + grand_total_steps) / max(1, grand_total_steps)  # (accept_length+1)의 평균
        tokens_per_second = (grand_total_accepted + grand_total_steps) / total_time
        avg_tree_depth = (grand_total_draft_tokens / max(1, grand_total_steps)) if grand_total_steps > 0 else 0.0
        avg_accept_length = (grand_total_accepted / max(1, grand_total_steps)) if grand_total_steps > 0 else 0.0
        avg_tree_width = float(sum(r["avg_width"] for r in tree_width_records) / len(tree_width_records)) if tree_width_records else 0.0
        avg_final_nodes = float(sum(r["final_nnodes"] for r in tree_width_records) / len(tree_width_records)) if tree_width_records else 0.0
        # depth별 평균 width 계산
        depth_width_sum = {}
        depth_width_count = {}
        for rec in tree_width_records:
            for depth_idx, w in enumerate(rec.get("depth_widths", []), start=1):
                depth_width_sum[depth_idx] = depth_width_sum.get(depth_idx, 0.0) + w
                depth_width_count[depth_idx] = depth_width_count.get(depth_idx, 0) + 1
        depth_avg_widths = {
            depth: float(depth_width_sum[depth] / depth_width_count[depth])
            for depth in sorted(depth_width_sum.keys())
        } if depth_width_sum else {}
        
        # Accept stats 계산 (target과 동일한 형식)
        accept_stats = {}
        if all_accept_lengths:
            accept_stats = {
                "total_accepted_tokens": sum(all_accept_lengths),
                "avg_accept_length": float(sum(all_accept_lengths) / len(all_accept_lengths)),
                "min_accept_length": int(min(all_accept_lengths)),
                "max_accept_length": int(max(all_accept_lengths)),
                "num_steps": len(all_accept_lengths)
            }
        
        # Expected accept length 평균 계산 (매 step의 "최종 트리" sum_expected_accepted_length만 사용)
        # NOTE: runner.accumulated_depth_stats는 트리 확장 중간 단계(depth별) 값이 섞여 평균이 작아질 수 있음.
        if all_expected_accept_lengths_per_step:
            valid_lengths = []
            for v in all_expected_accept_lengths_per_step:
                if v is None:
                    continue
                if isinstance(v, (int, float)) and v == v:  # NaN 필터링: v==v는 NaN이 아닌 경우 True
                    valid_lengths.append(float(v))
            avg_expected_accept_length = float(sum(valid_lengths) / len(valid_lengths)) if valid_lengths else None
        else:
            avg_expected_accept_length = None

        # Scaled expected accept length 평균 계산 (실제 예측에 사용된 스케일 기반)
        if all_scaled_expected_accept_lengths_per_step:
            valid_scaled = []
            for v in all_scaled_expected_accept_lengths_per_step:
                if v is None:
                    continue
                if isinstance(v, (int, float)) and v == v:
                    valid_scaled.append(float(v))
            avg_scaled_expected_accept_length = float(sum(valid_scaled) / len(valid_scaled)) if valid_scaled else None
        else:
            avg_scaled_expected_accept_length = None

        # Expected accept length bucket별 실제 accept length 평균 계산
        # bins: [0~1), [1~2), ..., [9~10)
        avg_accept_length_per_expected = {}
        bucket_sum = {i: 0.0 for i in range(10)}
        bucket_cnt = {i: 0 for i in range(10)}
        out_sum = 0.0
        out_cnt = 0

        if all_expected_accept_lengths_per_step and all_accept_lengths and len(all_expected_accept_lengths_per_step) == len(all_accept_lengths):
            for exp_val, acc_len in zip(all_expected_accept_lengths_per_step, all_accept_lengths):
                if exp_val is None:
                    out_sum += float(acc_len)
                    out_cnt += 1
                    continue
                try:
                    exp_f = float(exp_val)
                except Exception:
                    out_sum += float(acc_len)
                    out_cnt += 1
                    continue

                if 0.0 <= exp_f < 10.0:
                    idx = int(exp_f)  # 0~9
                    bucket_sum[idx] += float(acc_len)
                    bucket_cnt[idx] += 1
                else:
                    out_sum += float(acc_len)
                    out_cnt += 1

        # avg_width_per_depth와 유사하게 문자열 키로 저장
        for i in range(10):
            key = f"{i}-{i+1}"
            if bucket_cnt[i] > 0:
                avg_accept_length_per_expected[key] = {
                    "count": int(bucket_cnt[i]),
                    "avg_accept_length": float(bucket_sum[i] / bucket_cnt[i]),
                }
            else:
                avg_accept_length_per_expected[key] = {
                    "count": 0,
                    "avg_accept_length": None,
                }
        # 범위를 벗어난 값(>=10, <0, None 등)도 함께 기록 (디버깅/해석용)
        avg_accept_length_per_expected["out_of_range"] = {
            "count": int(out_cnt),
            "avg_accept_length": float(out_sum / out_cnt) if out_cnt > 0 else None,
        }

        # 요약 출력은 cost_per_token 계산 후에 수행
        # 추가 지표(참고): 평균 accept length도 함께 출력
        print(
            "avg_accept_length: {:.4f}  acceptance_ratio_avg: {:.4f}".format(
                avg_accept_length,  # next token 미포함
                (grand_total_accepted / max(1, grand_total_draft_tokens)) if grand_total_draft_tokens > 0 else 0.0,
            )
        )
        # expected/ scaled expected 출력 추가 (보기 쉽게 avg_accept_length 뒤)
        try:
            _orig_exp = float(avg_expected_accept_length) if avg_expected_accept_length is not None else None
        except Exception:
            _orig_exp = None
        try:
            _scaled_exp = float(avg_scaled_expected_accept_length) if avg_scaled_expected_accept_length is not None else None
        except Exception:
            _scaled_exp = None
        print(
            "original_expected_accept_length: {}  scaled_expected_accept_length: {}".format(
                ("{:.4f}".format(_orig_exp) if _orig_exp is not None else "None"),
                ("{:.4f}".format(_scaled_exp) if _scaled_exp is not None else "None"),
            )
        )

        # 네트워크 레이턴시/accept 통계 파일 저장 (dictionary 형태)
        global_avg_draft = float(sum(global_draft_to_target_times) / len(global_draft_to_target_times)) if global_draft_to_target_times else None
        global_avg_target = float(sum(global_target_to_draft_times) / len(global_target_to_draft_times)) if global_target_to_draft_times else None
        global_avg_accept = float(sum(global_accept_lengths) / len(global_accept_lengths)) if global_accept_lengths else None
        global_accept_len_bucket_stats = {}
        for length, times in global_t2d_per_accept_len.items():
            if not times:
                continue
            global_accept_len_bucket_stats[int(length)] = {
                "count": len(times),
                "avg_target_to_draft_time_ms": float(sum(times) / len(times)),
                "min_target_to_draft_time_ms": float(min(times)),
                "max_target_to_draft_time_ms": float(max(times)),
            }
        # final_nnodes별 draft_to_target_time 전역 통계 계산
        global_final_nnodes_bucket_stats = {}
        for nnodes, times in global_d2t_per_final_nnodes.items():
            if not times:
                continue
            global_final_nnodes_bucket_stats[int(nnodes)] = {
                "count": len(times),
                "avg_draft_to_target_time_ms": float(sum(times) / len(times)),
                "min_draft_to_target_time_ms": float(min(times)),
                "max_draft_to_target_time_ms": float(max(times)),
            }
        

        # Depth별 통계 계산 (항상 기록, 없으면 빈 딕셔너리)
        depth_statistics = {}
        depth_statistics_short = {}
        if runner.accumulated_depth_stats:
            for depth, stats in runner.accumulated_depth_stats.items():
                depth_statistics[depth] = {}
                depth_statistics_short[depth] = {}
                for key, values in stats.items():
                    if len(values) > 0:
                        mean_value = float(sum(values) / len(values))
                        depth_statistics[depth][key] = {
                            "count": len(values),
                            "min": float(min(values)),
                            "max": float(max(values)),
                            "mean": mean_value,
                            "sum": float(sum(values)),
                            "all_values": [float(v) for v in values]  # 모든 값도 저장 (선택사항)
                        }
                        # short 버전에는 mean 값만 저장
                        depth_statistics_short[depth][key] = mean_value
                    else:
                        depth_statistics[depth][key] = {
                            "count": 0,
                            "min": None,
                            "max": None,
                            "mean": None,
                            "sum": 0.0,
                            "all_values": []
                        }
                        depth_statistics_short[depth][key] = None

        # Width별 model.model() 호출 시간 통계 계산 (print_timing_stats에서 출력하는 값들)
        width_timing_stats = {}
        if runner.accumulated_width_times:
            for width in sorted(runner.accumulated_width_times.keys()):
                times = runner.accumulated_width_times[width]
                count = len(times)
                total_time_ms = sum(times) * 1000
                avg_time_ms = (sum(times) / count) * 1000 if count > 0 else 0
                min_time_ms = min(times) * 1000
                max_time_ms = max(times) * 1000
                
                width_timing_stats[width] = {
                    "count": count,
                    "total_time_ms": float(total_time_ms),
                    "avg_time_ms": float(avg_time_ms),
                    "min_time_ms": float(min_time_ms),
                    "max_time_ms": float(max_time_ms),
                    "all_times_ms": [float(t * 1000) for t in times]
                }
        
        # Algorithm 통계 계산 (objective_value, per_token_latency, per_token_cost의 평균값)
        algorithm_stats = {}
        all_objective_values = []
        all_per_token_latency = []
        all_per_token_cost = []
        
        if runner.accumulated_depth_stats:
            for depth, stats in runner.accumulated_depth_stats.items():
                if "objective_value" in stats and len(stats["objective_value"]) > 0:
                    all_objective_values.extend(stats["objective_value"])
                if "per_token_latency" in stats and len(stats["per_token_latency"]) > 0:
                    all_per_token_latency.extend(stats["per_token_latency"])
                if "per_token_cost" in stats and len(stats["per_token_cost"]) > 0:
                    all_per_token_cost.extend(stats["per_token_cost"])
        
        if len(all_objective_values) > 0:
            algorithm_stats["avg_objective_value"] = float(sum(all_objective_values) / len(all_objective_values))
            algorithm_stats["min_objective_value"] = float(min(all_objective_values))
            algorithm_stats["max_objective_value"] = float(max(all_objective_values))
            algorithm_stats["count_objective_value"] = len(all_objective_values)
        else:
            algorithm_stats["avg_objective_value"] = None
            algorithm_stats["min_objective_value"] = None
            algorithm_stats["max_objective_value"] = None
            algorithm_stats["count_objective_value"] = 0
        
        if len(all_per_token_latency) > 0:
            algorithm_stats["avg_per_token_latency"] = float(sum(all_per_token_latency) / len(all_per_token_latency))
            algorithm_stats["min_per_token_latency"] = float(min(all_per_token_latency))
            algorithm_stats["max_per_token_latency"] = float(max(all_per_token_latency))
            algorithm_stats["count_per_token_latency"] = len(all_per_token_latency)
        else:
            algorithm_stats["avg_per_token_latency"] = None
            algorithm_stats["min_per_token_latency"] = None
            algorithm_stats["max_per_token_latency"] = None
            algorithm_stats["count_per_token_latency"] = 0
        
        if len(all_per_token_cost) > 0:
            algorithm_stats["avg_per_token_cost"] = float(sum(all_per_token_cost) / len(all_per_token_cost))
            algorithm_stats["min_per_token_cost"] = float(min(all_per_token_cost))
            algorithm_stats["max_per_token_cost"] = float(max(all_per_token_cost))
            algorithm_stats["count_per_token_cost"] = len(all_per_token_cost)
        else:
            algorithm_stats["avg_per_token_cost"] = None
            algorithm_stats["min_per_token_cost"] = None
            algorithm_stats["max_per_token_cost"] = None
            algorithm_stats["count_per_token_cost"] = 0
        
        # width 선택 알고리즘 실행 시간 통계
        if runner.accumulated_width_algorithm_times and len(runner.accumulated_width_algorithm_times) > 0:
            width_times = runner.accumulated_width_algorithm_times
            algorithm_stats["width_algorithm_time"] = {
                "total_seconds": float(sum(width_times)),
                "avg_seconds": float(sum(width_times) / len(width_times)),
                "min_seconds": float(min(width_times)),
                "max_seconds": float(max(width_times)),
                "count": len(width_times)
            }
        else:
            algorithm_stats["width_algorithm_time"] = {
                "total_seconds": 0.0,
                "avg_seconds": None,
                "min_seconds": None,
                "max_seconds": None,
                "count": 0
            }
        
        # final_nnodes 선택 알고리즘 실행 시간 통계
        if runner.accumulated_nnodes_algorithm_times and len(runner.accumulated_nnodes_algorithm_times) > 0:
            nnodes_times = runner.accumulated_nnodes_algorithm_times
            algorithm_stats["nnodes_algorithm_time"] = {
                "total_seconds": float(sum(nnodes_times)),
                "avg_seconds": float(sum(nnodes_times) / len(nnodes_times)),
                "min_seconds": float(min(nnodes_times)),
                "max_seconds": float(max(nnodes_times)),
                "count": len(nnodes_times)
            }
        else:
            algorithm_stats["nnodes_algorithm_time"] = {
                "total_seconds": 0.0,
                "avg_seconds": None,
                "min_seconds": None,
                "max_seconds": None,
                "count": 0
            }
        
        # total_algorithm_time 계산 (width_algorithm_time + nnodes_algorithm_time)
        width_total = algorithm_stats["width_algorithm_time"]["total_seconds"]
        nnodes_total = algorithm_stats["nnodes_algorithm_time"]["total_seconds"]
        total_algorithm_time = width_total + nnodes_total
        algorithm_stats["total_algorithm_time"] = float(total_algorithm_time)
        
        # 모델 호출 시간 총합 통계 (model_time 기준)
        model_function_timing = {
            "actual_total_time_ms": float(runner.accumulated_model_total_time * 1000),
            "expected_total_time_ms": float(runner.accumulated_expected_model_total_time * 1000),
        }
        if runner.accumulated_model_total_time > 0:
            diff_ms = (runner.accumulated_expected_model_total_time - runner.accumulated_model_total_time) * 1000
            diff_percent = (diff_ms / (runner.accumulated_model_total_time * 1000)) * 100
            model_function_timing["diff_ms"] = float(diff_ms)
            model_function_timing["diff_percent"] = float(diff_percent)
        else:
            model_function_timing["diff_ms"] = None
            model_function_timing["diff_percent"] = None

        # Latency 통계 계산 (raw 값과 통계값)
        latency_statistics = {}
        if latency_data:
            # 각 단계별 latency 수집
            tree_build_times = [d["tree_build_time_ms"] for d in latency_data if d["tree_build_time_ms"] is not None]
            draft_to_target_times = [d["draft_to_target_time_ms"] for d in latency_data if d["draft_to_target_time_ms"] is not None]
            target_verification_times = [d["target_verification_time_ms"] for d in latency_data if d["target_verification_time_ms"] is not None]
            target_to_draft_times = [d["target_to_draft_time_ms"] for d in latency_data if d["target_to_draft_time_ms"] is not None]
            
            # 통계값 계산 함수
            def calc_stats(values):
                if not values:
                    return {"min": None, "max": None, "mean": None, "count": 0}
                return {
                    "min": float(min(values)),
                    "max": float(max(values)),
                    "mean": float(sum(values) / len(values)),
                    "count": len(values)
                }
            
            latency_statistics = {
                "tree_build": {
                    "raw": tree_build_times,
                    "stats": calc_stats(tree_build_times)
                },
                "draft_to_target": {
                    "raw": draft_to_target_times,
                    "stats": calc_stats(draft_to_target_times)
                },
                "target_verification": {
                    "raw": target_verification_times,
                    "stats": calc_stats(target_verification_times)
                },
                "target_to_draft": {
                    "raw": target_to_draft_times,
                    "stats": calc_stats(target_to_draft_times)
                }
            }
        
        # Width별 draft latency 통계 (프로파일링 예측 vs 실제 측정)
        per_width_draft_latency = {}
        if runner.accumulated_width_times and runner.profile_data:
            for width in sorted(runner.accumulated_width_times.keys()):
                actual_times = runner.accumulated_width_times[width]  # 초 단위
                actual_times_ms = [t * 1000.0 for t in actual_times]  # 밀리초 단위로 변환
                
                # 실제 시간 통계
                if actual_times_ms:
                    actual_avg_ms = float(sum(actual_times_ms) / len(actual_times_ms))
                    actual_min_ms = float(min(actual_times_ms))
                    actual_max_ms = float(max(actual_times_ms))
                else:
                    actual_avg_ms = None
                    actual_min_ms = None
                    actual_max_ms = None
                
                # 프로파일링 예측 시간 (밀리초 단위)
                width_str = str(width)
                if width_str in runner.profile_data:
                    predicted_time_ms = runner.profile_data[width_str].get("model_call_avg_time_ms", None)
                else:
                    predicted_time_ms = None
                
                per_width_draft_latency[width_str] = {
                    "predicted_time_ms": predicted_time_ms,  # 프로파일링 예측 시간
                    "actual_avg_ms": actual_avg_ms,  # 실제 평균 시간
                    "actual_min_ms": actual_min_ms,  # 실제 최소 시간
                    "actual_max_ms": actual_max_ms,  # 실제 최대 시간
                    "count": len(actual_times)  # 측정 횟수
                }
        
        # per_width_draft_latency를 latency_statistics에 추가
        if per_width_draft_latency:
            latency_statistics["per_width_draft_latency"] = per_width_draft_latency
        
        # 데이터 전송량 통계 계산 (KByte 단위)
        data_transfer_stats = {}
        if latency_data:
            draft_to_target_bytes_list = [
                d.get("draft_to_target_bytes")
                for d in latency_data
                if d.get("draft_to_target_bytes") is not None
            ]
            target_to_draft_bytes_list = [
                d.get("target_to_draft_bytes")
                for d in latency_data
                if d.get("target_to_draft_bytes") is not None
            ]
            
            # Byte를 KByte로 변환
            draft_to_target_kbytes = [b / 1024.0 for b in draft_to_target_bytes_list]
            target_to_draft_kbytes = [b / 1024.0 for b in target_to_draft_bytes_list]
            
            def calc_transfer_stats(kbytes_list, bytes_list):
                if not kbytes_list:
                    return {
                        "total_kbytes": 0.0,
                        "avg_kbytes": None,
                        "min_kbytes": None,
                        "max_kbytes": None,
                        "count": 0,
                        "raw_kbytes": []
                    }
                return {
                    "total_kbytes": float(sum(kbytes_list)),
                    "avg_kbytes": float(sum(kbytes_list) / len(kbytes_list)),
                    "min_kbytes": float(min(kbytes_list)),
                    "max_kbytes": float(max(kbytes_list)),
                    "count": len(kbytes_list),
                    "raw_kbytes": [float(kb) for kb in kbytes_list]
                }
            
            data_transfer_stats = {
                "draft_to_target": calc_transfer_stats(draft_to_target_kbytes, draft_to_target_bytes_list),
                "target_to_draft": calc_transfer_stats(target_to_draft_kbytes, target_to_draft_bytes_list),
                "total_kbytes": float(sum(draft_to_target_kbytes) + sum(target_to_draft_kbytes)) if draft_to_target_kbytes and target_to_draft_kbytes else 0.0
            }

        # 모델 이름 추출
        draft_model_name = draft_model_path.split("/")[-1] if "/" in draft_model_path else draft_model_path
        base_model_name = base_model_path.split("/")[-1] if "/" in base_model_path else base_model_path
        
        # 통합 결과 파일 생성
        script_dir = os.path.dirname(__file__)
        parent_dir = os.path.dirname(script_dir)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # answer_file이 제공된 경우 그 디렉토리 사용, 아니면 기본 디렉토리 사용
        if answer_file:
            output_dir = os.path.dirname(os.path.expanduser(answer_file))
            # 파일명에서 확장자 제거하고 .json으로 변경 + 타임스탬프 부여
            base_filename = os.path.splitext(os.path.basename(answer_file))[0]
            output_file = os.path.join(output_dir, f"{base_filename}_results_{timestamp}.json")
        else:
            output_dir = os.path.join(parent_dir, "result", "experiments_draft")
            if device_name:
                output_file = os.path.join(output_dir, f"draft_{draft_model_name}_{device_name}_{bench_name}_nodes{nodes}_{timestamp}_results.json")
            else:
                output_file = os.path.join(output_dir, f"draft_{draft_model_name}_{bench_name}_nodes{nodes}_{timestamp}_results.json")
        
        os.makedirs(output_dir, exist_ok=True)
        
        # 네트워크 정보 수집
        network_info = {}
        try:
            if PSUTIL_AVAILABLE:
                # psutil을 사용하여 네트워크 인터페이스 정보 수집
                interfaces = psutil.net_if_addrs()
                stats = psutil.net_if_stats()
                active_interfaces = []
                for interface_name, addrs in interfaces.items():
                    if interface_name in stats and stats[interface_name].isup:
                        interface_type = "unknown"
                        # 인터페이스 이름으로 타입 추정
                        if "wlan" in interface_name.lower() or "wifi" in interface_name.lower() or "wireless" in interface_name.lower():
                            interface_type = "wifi"
                        elif "eth" in interface_name.lower() or "enp" in interface_name.lower() or "eno" in interface_name.lower():
                            interface_type = "ethernet"
                        elif "lo" in interface_name.lower():
                            interface_type = "loopback"
                        
                        active_interfaces.append({
                            "name": interface_name,
                            "type": interface_type,
                            "speed_mbps": stats[interface_name].speed if stats[interface_name].speed > 0 else None
                        })
                
                if active_interfaces:
                    # 가장 빠른 인터페이스 또는 첫 번째 활성 인터페이스 선택
                    primary_interface = max(active_interfaces, key=lambda x: x["speed_mbps"] if x["speed_mbps"] else 0) if active_interfaces else active_interfaces[0]
                    network_info = {
                        "primary_interface": primary_interface["name"],
                        "interface_type": primary_interface["type"],
                        "speed_mbps": primary_interface["speed_mbps"],
                        "all_active_interfaces": active_interfaces
                    }
        except Exception as e:
            network_info = {"error": str(e)}
        
        # GPU 정보 수집
        gpu_info = {}
        try:
            if torch.cuda.is_available():
                # PyTorch를 통한 기본 GPU 정보
                gpu_info["cuda_available"] = True
                gpu_info["gpu_count"] = torch.cuda.device_count()
                gpu_info["current_device"] = torch.cuda.current_device()
                gpu_info["device_name"] = torch.cuda.get_device_name(0) if torch.cuda.device_count() > 0 else None
                
                # nvidia-smi를 통한 상세 정보
                try:
                    result = subprocess.run(
                        ['nvidia-smi', '--query-gpu=name,memory.total,driver_version', '--format=csv,noheader,nounits'],
                        capture_output=True, text=True, timeout=5
                    )
                    if result.returncode == 0:
                        lines = result.stdout.strip().split('\n')
                        if lines and lines[0].strip():
                            parts = lines[0].split(', ')
                            if len(parts) >= 3:
                                gpu_info["gpu_name"] = parts[0].strip()
                                gpu_info["total_memory_mb"] = int(parts[1].strip()) if parts[1].strip().isdigit() else None
                                gpu_info["driver_version"] = parts[2].strip()
                except Exception:
                    pass
            else:
                gpu_info["cuda_available"] = False
        except Exception as e:
            gpu_info["error"] = str(e)
        
        # GPU 에너지 계산 (draft_gpu_data와 draft_timing_data가 있는 경우)
        draft_gpu_summary = {}
        if draft_gpu_data and draft_timing_data:
            # 모든 GPU 통계를 합쳐서 요약 통계 생성
            all_gpu_stats = {}
            for step_data in draft_gpu_data:
                for gpu_id, stats in step_data["gpu_stats"].items():
                    if gpu_id not in all_gpu_stats:
                        all_gpu_stats[gpu_id] = {
                            'memory_used_mb': [],
                            'utilization_percent': [],
                            'temperature_c': [],
                            'memory_used_percent': [],
                            'power_draw_w': [],
                            'power_limit_w': [],
                            'power_usage_percent': []
                        }
                    
                    all_gpu_stats[gpu_id]['memory_used_mb'].extend([stats['memory_used_mb']['avg']])
                    all_gpu_stats[gpu_id]['utilization_percent'].extend([stats['utilization_percent']['avg']])
                    all_gpu_stats[gpu_id]['temperature_c'].extend([stats['temperature_c']['avg']])
                    all_gpu_stats[gpu_id]['memory_used_percent'].extend([stats['memory_used_percent']['avg']])
                    
                    # 파워 정보 추가 (있는 경우만)
                    if 'power_draw_w' in stats:
                        all_gpu_stats[gpu_id]['power_draw_w'].extend([stats['power_draw_w']['avg']])
                    if 'power_limit_w' in stats:
                        all_gpu_stats[gpu_id]['power_limit_w'].extend([stats['power_limit_w']])
                    if 'power_usage_percent' in stats:
                        all_gpu_stats[gpu_id]['power_usage_percent'].extend([stats['power_usage_percent']['avg']])
            
            # 요약 통계 생성
            for gpu_id, data in all_gpu_stats.items():
                draft_gpu_summary[gpu_id] = {
                    'memory_used_mb': {
                        'min': min(data['memory_used_mb']),
                        'max': max(data['memory_used_mb']),
                        'avg': sum(data['memory_used_mb']) / len(data['memory_used_mb'])
                    },
                    'utilization_percent': {
                        'min': min(data['utilization_percent']),
                        'max': max(data['utilization_percent']),
                        'avg': sum(data['utilization_percent']) / len(data['utilization_percent'])
                    },
                    'temperature_c': {
                        'min': min(data['temperature_c']),
                        'max': max(data['temperature_c']),
                        'avg': sum(data['temperature_c']) / len(data['temperature_c'])
                    },
                    'memory_used_percent': {
                        'min': min(data['memory_used_percent']),
                        'max': max(data['memory_used_percent']),
                        'avg': sum(data['memory_used_percent']) / len(data['memory_used_percent'])
                    }
                }
                
                # 파워 통계 추가 (데이터가 있는 경우만)
                if data['power_draw_w']:
                    draft_gpu_summary[gpu_id]['power_draw_w'] = {
                        'min': min(data['power_draw_w']),
                        'max': max(data['power_draw_w']),
                        'avg': sum(data['power_draw_w']) / len(data['power_draw_w'])
                    }
                if data['power_limit_w']:
                    # power_limit_w는 고정값이므로 첫 번째 값만 저장
                    draft_gpu_summary[gpu_id]['power_limit_w'] = data['power_limit_w'][0]
                if data['power_usage_percent']:
                    draft_gpu_summary[gpu_id]['power_usage_percent'] = {
                        'min': min(data['power_usage_percent']),
                        'max': max(data['power_usage_percent']),
                        'avg': sum(data['power_usage_percent']) / len(data['power_usage_percent'])
                    }
                
                # GPU 에너지 계산 (파워 × 시간)
                if data['power_draw_w'] and draft_timing_data:
                    total_energy_joules = 0.0
                    step_energies = []
                    
                    # draft_gpu_data와 draft_timing_data를 매칭하여 각 step의 에너지 계산
                    for step_idx, step_data in enumerate(draft_gpu_data):
                        if step_idx < len(draft_timing_data):
                            # 해당 step의 GPU 통계에서 power_draw_w 평균값 가져오기
                            if gpu_id in step_data.get('gpu_stats', {}):
                                step_power_avg = step_data['gpu_stats'][gpu_id].get('power_draw_w', {}).get('avg', 0.0)
                                step_time = draft_timing_data[step_idx].get('total_time_seconds', 0.0)
                                step_energy = step_power_avg * step_time  # 와트 × 초 = 줄 (Joule)
                                step_energies.append(step_energy)
                                total_energy_joules += step_energy
                    
                    # start_monitoring() 호출 횟수 (draft call 횟수) 계산
                    draft_call_count = grand_total_steps  # 기본값: grand_total_steps
                    if draft_gpu_data:
                        last_step_data = draft_gpu_data[-1]
                        if last_step_data.get('monitor_call_count') is not None:
                            draft_call_count = last_step_data.get('monitor_call_count')
                    
                    # 에너지 통계 추가
                    if step_energies and draft_call_count > 0:
                        draft_gpu_summary[gpu_id]['energy'] = {
                            'total_energy_joules': float(total_energy_joules),
                            'total_energy_kwh': float(total_energy_joules / 3600000.0),  # 줄을 kWh로 변환 (1 kWh = 3,600,000 J)
                            'avg_energy_per_call_joules': float(total_energy_joules / draft_call_count),
                            'avg_energy_per_call_kwh': float((total_energy_joules / draft_call_count) / 3600000.0),
                            'min_energy_per_call_joules': float(min(step_energies)) if step_energies else 0.0,
                            'max_energy_per_call_joules': float(max(step_energies)) if step_energies else 0.0,
                            'num_calls': int(draft_call_count)  # start_monitoring() 호출 횟수
                        }
        
        # CPU 전력 통계 계산
        draft_cpu_power_summary = {}
        if draft_cpu_power_data and draft_timing_data:
            # 모든 CPU 전력 통계를 합쳐서 요약 통계 생성
            all_cpu_power_values = []
            for step_idx, step_data in enumerate(draft_cpu_power_data):
                if "cpu_power_stats" in step_data and step_data["cpu_power_stats"]:
                    cpu_stats = step_data["cpu_power_stats"]
                    if "cpu_power_w" in cpu_stats and "avg" in cpu_stats["cpu_power_w"]:
                        all_cpu_power_values.append(cpu_stats["cpu_power_w"]["avg"])

        
            
            if len(all_cpu_power_values) > 0:
                draft_cpu_power_summary = {
                    'cpu_power_w': {
                        'min': min(all_cpu_power_values),
                        'max': max(all_cpu_power_values),
                        'avg': sum(all_cpu_power_values) / len(all_cpu_power_values),
                        'count': len(all_cpu_power_values)
                    }
                }
                
                # CPU 에너지 계산 (파워 × 시간)
                total_cpu_energy_joules = 0.0
                step_cpu_energies = []
                
                # draft_cpu_power_data와 draft_timing_data를 매칭하여 각 step의 에너지 계산
                for step_idx, step_data in enumerate(draft_cpu_power_data):
                    if step_idx < len(draft_timing_data):
                        if "cpu_power_stats" in step_data and step_data["cpu_power_stats"]:
                            cpu_stats = step_data["cpu_power_stats"]
                            if "cpu_power_w" in cpu_stats and "avg" in cpu_stats["cpu_power_w"]:
                                step_power_avg = cpu_stats["cpu_power_w"]["avg"]
                                step_time = draft_timing_data[step_idx].get('total_time_seconds', 0.0)
                                step_energy = step_power_avg * step_time  # 와트 × 초 = 줄 (Joule)
                                step_cpu_energies.append(step_energy)
                                total_cpu_energy_joules += step_energy
                
                # start_monitoring() 호출 횟수 (draft call 횟수) 계산
                cpu_draft_call_count = grand_total_steps  # 기본값: grand_total_steps
                if draft_cpu_power_data:
                    last_step_data = draft_cpu_power_data[-1]
                    if last_step_data.get('monitor_call_count') is not None:
                        cpu_draft_call_count = last_step_data.get('monitor_call_count')
                
                # 에너지 통계 추가
                if step_cpu_energies and cpu_draft_call_count > 0:
                    draft_cpu_power_summary['energy'] = {
                        'total_energy_joules': float(total_cpu_energy_joules),
                        'total_energy_kwh': float(total_cpu_energy_joules / 3600000.0),  # 줄을 kWh로 변환 (1 kWh = 3,600,000 J)
                        'avg_energy_per_call_joules': float(total_cpu_energy_joules / cpu_draft_call_count),
                        'avg_energy_per_call_kwh': float((total_cpu_energy_joules / cpu_draft_call_count) / 3600000.0),
                        'min_energy_per_call_joules': float(min(step_cpu_energies)) if step_cpu_energies else 0.0,
                        'max_energy_per_call_joules': float(max(step_cpu_energies)) if step_cpu_energies else 0.0,
                        'num_calls': int(cpu_draft_call_count)  # start_monitoring() 호출 횟수
                    }
        
        
        # Draft 에너지 총량 집계 (GPU/CPU)
        total_draft_gpu_energy_kwh = 0.0
        for gpu_entry in draft_gpu_summary.values():
            energy_info = gpu_entry.get("energy", {}) if isinstance(gpu_entry, dict) else {}
            total_draft_gpu_energy_kwh += float(energy_info.get("total_energy_kwh", 0.0) or 0.0)
        gpu_monitor_enabled = bool(runner.gpu_monitor is not None)
        gpu_monitor_sample_count = len(draft_gpu_data) if isinstance(draft_gpu_data, list) else 0
        gpu_monitor_power_draw_available = any(
            isinstance(gpu_entry, dict)
            and isinstance(gpu_entry.get("power_draw_w", None), dict)
            and (gpu_entry["power_draw_w"].get("avg", None) is not None)
            for gpu_entry in (draft_gpu_summary.values() if isinstance(draft_gpu_summary, dict) else [])
        )
        if not gpu_monitor_enabled:
            gpu_monitor_status = "disabled"
        elif gpu_monitor_sample_count <= 0:
            gpu_monitor_status = "no_samples"
        elif gpu_monitor_power_draw_available:
            gpu_monitor_status = "ok"
        else:
            gpu_monitor_status = "no_power_draw"
        total_draft_cpu_energy_kwh = float(
            (draft_cpu_power_summary.get("energy", {}) or {}).get("total_energy_kwh", 0.0) or 0.0
        )
        total_draft_energy_kwh = float(total_draft_gpu_energy_kwh + total_draft_cpu_energy_kwh)

        # total_cost와 cost_per_token 계산
        total_new_tokens = grand_total_accepted + grand_total_steps
        draft_per_sec_cost = draft_per_hour_cost / 3600.0 if draft_per_hour_cost else 0.0
        target_per_sec_cost = target_per_hour_cost / 3600.0 if target_per_hour_cost else 0.0
        
        # tree_build 총 시간 계산 (밀리초를 초로 변환)
        total_tree_build_time_sec = 0.0
        if latency_statistics and "tree_build" in latency_statistics and "stats" in latency_statistics["tree_build"]:
            tree_build_stats = latency_statistics["tree_build"]["stats"]
            if tree_build_stats.get("mean") is not None and tree_build_stats.get("count", 0) > 0:
                total_tree_build_time_sec = (tree_build_stats["mean"] * tree_build_stats["count"]) / 1000.0
        
        # target_verification 총 시간 계산 (밀리초를 초로 변환)
        total_target_verification_time_sec = 0.0
        if latency_statistics and "target_verification" in latency_statistics and "stats" in latency_statistics["target_verification"]:
            target_verification_stats = latency_statistics["target_verification"]["stats"]
            if target_verification_stats.get("mean") is not None and target_verification_stats.get("count", 0) > 0:
                total_target_verification_time_sec = (target_verification_stats["mean"] * target_verification_stats["count"]) / 1000.0
        
        # total_cost 계산 (proactive 시간은 tree_build_time에 이미 반영됨)
        total_draft_time_sec = total_tree_build_time_sec
        proactive_draft_cost = 0.0 if no_draft_cost else (proactive_total_time_sec * draft_per_sec_cost)
        draft_cost = 0.0 if no_draft_cost else (total_draft_time_sec * draft_per_sec_cost)
        server_only_transfer_time_sec = (
            (sum(global_draft_to_target_times) + sum(global_target_to_draft_times)) / 1000.0
            if server_only_mode
            else 0.0
        )
        target_billed_time_sec = (
            max(0.0, float(server_only_total_session_time_sec) - float(server_only_transfer_time_sec))
            if server_only_mode and server_only_total_session_time_sec > 0
            else total_target_verification_time_sec
        )
        target_cost = target_billed_time_sec * target_per_sec_cost
        total_d2t_bytes = max(0.0, float(sum(run_draft_to_target_bytes))) if run_draft_to_target_bytes else 0.0
        total_t2d_bytes = max(0.0, float(sum(run_target_to_draft_bytes))) if run_target_to_draft_bytes else 0.0
        total_transfer_bytes = total_d2t_bytes + total_t2d_bytes
        bytes_per_gb = float(1024 ** 3)
        communication_cost = max(0.0, (
            (total_transfer_bytes / bytes_per_gb) * float(communication_per_gb_cost)
            if bytes_per_gb > 0
            else 0.0
        ))
        total_cost = draft_cost + target_cost + communication_cost
        
        # cost_per_token 계산
        cost_per_token = total_cost / total_new_tokens if total_new_tokens > 0 else 0.0
        draft_cost_per_token = draft_cost / total_new_tokens if total_new_tokens > 0 else 0.0
        target_cost_per_token = target_cost / total_new_tokens if total_new_tokens > 0 else 0.0
        communication_cost_per_token = communication_cost / total_new_tokens if total_new_tokens > 0 else 0.0
        proactive_draft_cost_per_token = proactive_draft_cost / total_new_tokens if total_new_tokens > 0 else 0.0

        # 1M 토큰 기준 비용 단위
        cost_per_1m_tokens = cost_per_token * 1_000_000.0
        draft_cost_per_1m_tokens = draft_cost_per_token * 1_000_000.0
        target_cost_per_1m_tokens = target_cost_per_token * 1_000_000.0
        communication_cost_per_1m_tokens = communication_cost_per_token * 1_000_000.0
        proactive_draft_cost_per_1m_tokens = proactive_draft_cost_per_token * 1_000_000.0

        # 1M 토큰 기준 에너지 단위 (kWh / 1M tokens)
        draft_energy_kwh_per_token = (total_draft_energy_kwh / total_new_tokens) if total_new_tokens > 0 else 0.0
        draft_energy_kwh_per_1m_tokens = draft_energy_kwh_per_token * 1_000_000.0

        print(
            "total_steps: {}  | total_new_tokens: {}  | total_time: {:.2f}  | tokens per step: {:.2f}  | cost per 1M token: {:.6f}  | tokens per second: {:.2f}  | avg_tree_depth: {:.2f}".format(
                grand_total_steps,
                total_new_tokens,
                total_time,
                tokens_per_step,
                cost_per_1m_tokens,
                tokens_per_second,
                avg_tree_depth,
            )
        )
        if total_draft_energy_kwh > 0:
            print(
                "draft energy total: {:.6f} kWh  |  draft energy per 1M token: {:.6f} kWh".format(
                    total_draft_energy_kwh,
                    draft_energy_kwh_per_1m_tokens,
                )
            )
        
        # total_algorithm_time과 total_algorithm_cost 계산
        # algorithm_stats에서 total_algorithm_time 가져오기 (이미 계산되어 있음)
        total_algorithm_time = algorithm_stats.get("total_algorithm_time", 0.0) if algorithm_stats else 0.0
        total_algorithm_cost = total_algorithm_time * draft_per_sec_cost
        
        # 통합 결과 데이터 구성
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        integrated_result = {
            "experiment_info": {
                "draft_model": draft_model_path,
                "base_model": base_model_path,
                "bench_name": bench_name,
                "device_name": device_name,
                "timestamp": timestamp,
                "experiment_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "nodes": nodes,
                "max_depth": max_depth,
                "temperature": temperature,
                "draft_per_sec_cost": draft_per_sec_cost,
                "target_per_sec_cost": target_per_sec_cost,
                "communication_per_gb_cost": float(communication_per_gb_cost),
                "accept_length_margin": float(accept_length_margin),
                "cost_sensitivity": cost_sensitivity,
                "objective_metric": objective_metric,
                "reference_tps": float(runner.reference_tps),
                "reference_cost_per_token": float(runner.reference_cost_per_token),
                "reference_objective_per_token": float(runner.reference_objective_per_token),
                "no_draft_cost": bool(no_draft_cost),
                "opt_tree": opt_tree,
                "fixed_width": fixed_width,
                "fixed_depth": fixed_depth,
                "fixed_nnodes": fixed_nnodes,
                "proactive_drafting": bool(proactive_drafting),
                "proactive_threshold": float(proactive_threshold),
                "adaptive_proactive_threshold": bool(adaptive_proactive_threshold),
                "server_only_mode": bool(server_only_mode),
                "disable_server_only": bool(disable_server_only),
                "gpu_monitor_enabled": gpu_monitor_enabled,
                "gpu_monitor_sample_count": int(gpu_monitor_sample_count),
                "gpu_monitor_power_draw_available": gpu_monitor_power_draw_available,
                "gpu_monitor_status": gpu_monitor_status,
                "seed": getattr(args, "seed", None),
                "deterministic": bool(getattr(args, "deterministic", False)),
                "network_info": network_info,
                "gpu_info": gpu_info,
            },
            "generation_stats": {
                "total_steps": grand_total_steps,
                "total_new_tokens": total_new_tokens,
                "total_time_seconds": total_time,
                "tokens_per_step": tokens_per_step,
                "tokens_per_second": tokens_per_second,
                "avg_tree_depth": avg_tree_depth,
                "avg_tree_width": avg_tree_width,
                "avg_final_nodes": avg_final_nodes,
                "avg_width_per_depth": depth_avg_widths,
                "avg_accept_length": avg_accept_length,
                "original_expected_accept_length": avg_expected_accept_length,
                "scaled_expected_accept_length": avg_scaled_expected_accept_length,
                "scaled_with_margin_expected_accept_length": (
                    float(avg_scaled_expected_accept_length * (1.0 - float(getattr(runner, "accept_length_margin", 0.05))))
                    if avg_scaled_expected_accept_length is not None
                    else None
                ),
                "avg_accept_length_scale": runner.get_accept_length_ratio_mean(),
                "avg_expected_accept_length": avg_expected_accept_length,
                "avg_accept_length_per_expected": avg_accept_length_per_expected,
                "proactive_draft_attempts": proactive_draft_attempts,
                "proactive_tree_used": proactive_tree_used,
                "proactive_used_path_prob_avg": (
                    float(proactive_used_path_prob_sum / proactive_used_path_prob_count)
                    if proactive_used_path_prob_count > 0 else None
                ),
                "proactive_unused_path_prob_avg": (
                    float(proactive_unused_path_prob_sum / proactive_unused_path_prob_count)
                    if proactive_unused_path_prob_count > 0 else None
                ),
                "proactive_used_path_prob_count": proactive_used_path_prob_count,
                "proactive_unused_path_prob_count": proactive_unused_path_prob_count,
                "proactive_used_avg_tree_depth": (
                    float(proactive_used_tree_depth_sum / proactive_used_tree_steps)
                    if proactive_used_tree_steps > 0 else None
                ),
                "proactive_used_avg_tree_width": (
                    float(proactive_used_tree_width_sum / proactive_used_tree_steps)
                    if proactive_used_tree_steps > 0 else None
                ),
                "proactive_used_avg_final_nodes": (
                    float(proactive_used_tree_final_nodes_sum / proactive_used_tree_steps)
                    if proactive_used_tree_steps > 0 else None
                ),
                "proactive_used_avg_accept_length": (
                    float(proactive_used_tree_accept_length_sum / proactive_used_tree_steps)
                    if proactive_used_tree_steps > 0 else None
                ),
                "proactive_used_avg_scaled_expected_accept_length": (
                    float(proactive_used_tree_scaled_expected_sum / proactive_used_tree_steps)
                    if proactive_used_tree_steps > 0 else None
                ),
                "proactive_used_steps": proactive_used_tree_steps,
                # 실측/예측 오차율 평균 (1에 가까울수록 profile과 일치)
                "avg_draft_time_ratio": runner.get_draft_time_ratio_mean(),
                "avg_target_verification_time_ratio": runner.get_target_verification_ratio_mean(),
                "acceptance_ratio_avg": (grand_total_accepted / max(1, grand_total_draft_tokens)) if grand_total_draft_tokens > 0 else 0.0,
                "total_cost": float(total_cost),
                "draft_cost": float(draft_cost),
                "target_cost": float(target_cost),
                "communication_cost": float(communication_cost),
                "total_transfer_bytes": float(total_transfer_bytes),
                "cost_per_1m_tokens": float(cost_per_1m_tokens),
                "draft_cost_per_1m_tokens": float(draft_cost_per_1m_tokens),
                "target_cost_per_1m_tokens": float(target_cost_per_1m_tokens),
                "communication_cost_per_1m_tokens": float(communication_cost_per_1m_tokens),
                "proactive_draft_cost_per_1m_tokens": float(proactive_draft_cost_per_1m_tokens),
                "server_only_total_session_time_seconds": float(server_only_total_session_time_sec),
                "server_only_transfer_time_seconds": float(server_only_transfer_time_sec),
                "target_billed_time_seconds": float(target_billed_time_sec),
                "total_draft_time_seconds": float(total_draft_time_sec),
                "proactive_draft_time_seconds": float(proactive_total_time_sec),
                "proactive_draft_cost": float(proactive_draft_cost),
                "total_draft_gpu_energy_kwh": float(total_draft_gpu_energy_kwh),
                "total_draft_cpu_energy_kwh": float(total_draft_cpu_energy_kwh),
                "total_draft_energy_kwh": float(total_draft_energy_kwh),
                "draft_energy_kwh_per_1m_tokens": float(draft_energy_kwh_per_1m_tokens),
                "cost_per_token": float(cost_per_token),
                "communication_cost_per_token": float(communication_cost_per_token),
                "target_profile_lookup_stats": dict(runner.target_profile_lookup_stats),
                "total_algorithm_time": float(total_algorithm_time),
                "total_algorithm_cost": float(total_algorithm_cost),
            },
            "network_latency": {
                "global": {
                    "avg_draft_to_target_time_ms": global_avg_draft,
                    "avg_target_to_draft_time_ms": global_avg_target,
                    "avg_accept_length": global_avg_accept,
                    "total_steps": grand_total_steps,
                    "accept_length_bucket_stats": global_accept_len_bucket_stats,
                    "final_nnodes_bucket_stats": global_final_nnodes_bucket_stats,
                },
                "questions": network_latency_records,
            },
            "depth_statistics": depth_statistics,
            "depth_statistics_short": depth_statistics_short,
            "algorithm_stats": algorithm_stats,  # Algorithm 통계 (objective_value, per_token_latency, per_token_cost 평균값)
            "width_timing_stats": width_timing_stats,  # Width별 draft_model.model 호출 시간 통계
            "model_function_timing": model_function_timing,  # model.model() 호출 시간 총합 통계
            "latency_statistics": latency_statistics,  # 각 단계별 latency 통계 (raw + stats)
            "data_transfer_stats": data_transfer_stats,  # 데이터 전송량 통계 (KByte 단위)
            "accept_stats": accept_stats,  # Accept length 통계 (target과 동일한 형식)
            "tree_width_records": tree_width_records,  # 각 트리의 depth별 width, 평균 width, final_nnodes 기록
            "draft_gpu_summary": draft_gpu_summary if draft_gpu_summary else {},  # Draft GPU 통계 및 에너지 정보
            "draft_cpu_power_summary": draft_cpu_power_summary if draft_cpu_power_summary else {},  # Draft CPU 전력 통계 및 에너지 정보
            "answers": all_answers,
        }
        
        # 통합 결과 파일 저장 (원본)
        with open(output_file, 'w') as f:
            json.dump(integrated_result, f, indent=2)
        
        # Trimmed 버전 생성 (raw 값 제거)
        def create_trimmed_version(data):
            """raw 값과 all_values 등을 제거한 trimmed 버전 생성"""
            import copy
            trimmed = copy.deepcopy(data)
            
            # latency_statistics에서 raw 제거
            if "latency_statistics" in trimmed:
                for key in ["tree_build", "draft_to_target", "target_verification", "target_to_draft"]:
                    if key in trimmed["latency_statistics"]:
                        if "raw" in trimmed["latency_statistics"][key]:
                            del trimmed["latency_statistics"][key]["raw"]
            
            # depth_statistics에서 all_values 제거
            if "depth_statistics" in trimmed:
                for depth, stats in trimmed["depth_statistics"].items():
                    for key in stats:
                        if isinstance(stats[key], dict) and "all_values" in stats[key]:
                            del stats[key]["all_values"]
            
            # width_timing_stats에서 all_times_ms 제거
            if "width_timing_stats" in trimmed:
                for width, stats in trimmed["width_timing_stats"].items():
                    if "all_times_ms" in stats:
                        del stats["all_times_ms"]
            
            # data_transfer_stats에서 raw_kbytes 제거
            if "data_transfer_stats" in trimmed:
                for key in ["draft_to_target", "target_to_draft"]:
                    if key in trimmed["data_transfer_stats"]:
                        if "raw_kbytes" in trimmed["data_transfer_stats"][key]:
                            del trimmed["data_transfer_stats"][key]["raw_kbytes"]
            
            # network_latency의 global accept_length_bucket_stats와 final_nnodes_bucket_stats에서 times_ms 제거
            if "network_latency" in trimmed and "global" in trimmed["network_latency"]:
                if "accept_length_bucket_stats" in trimmed["network_latency"]["global"]:
                    for length, stats in trimmed["network_latency"]["global"]["accept_length_bucket_stats"].items():
                        if "times_ms" in stats:
                            del stats["times_ms"]
                if "final_nnodes_bucket_stats" in trimmed["network_latency"]["global"]:
                    for nnodes, stats in trimmed["network_latency"]["global"]["final_nnodes_bucket_stats"].items():
                        if "times_ms" in stats:
                            del stats["times_ms"]
            
            # network_latency의 questions에서 accept_length_bucket_stats와 final_nnodes_bucket_stats의 times_ms 제거
            if "network_latency" in trimmed and "questions" in trimmed["network_latency"]:
                for question_record in trimmed["network_latency"]["questions"]:
                    if "accept_length_bucket_stats" in question_record:
                        for length, stats in question_record["accept_length_bucket_stats"].items():
                            if "times_ms" in stats:
                                del stats["times_ms"]
                    if "final_nnodes_bucket_stats" in question_record:
                        for nnodes, stats in question_record["final_nnodes_bucket_stats"].items():
                            if "times_ms" in stats:
                                del stats["times_ms"]
            
            return trimmed
        
        # Trimmed 버전 생성
        trimmed_result = create_trimmed_version(integrated_result)
        
        # Trimmed 파일명 생성 (확장자 앞에 _trimmed 추가)
        base_name = os.path.splitext(output_file)[0]
        file_ext = os.path.splitext(output_file)[1]
        trimmed_output_file = f"{base_name}_trimmed{file_ext}"
        
        # Trimmed 버전 저장
        with open(trimmed_output_file, 'w') as f:
            json.dump(trimmed_result, f, indent=2)
        
        print(f"\n통합 결과 파일이 저장되었습니다:")
        print(f"  - 원본: {output_file}")
        print(f"  - Trimmed: {trimmed_output_file}")
        print(f"  - 답변 수: {len(all_answers)}")
        print(f"  - 네트워크 지연 통계: {len(network_latency_records)}개 질문")
        print(f"  - Depth별 통계: {len(depth_statistics)}개 depth")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", type=str, default="127.0.0.1")
    parser.add_argument("--port", type=int, default=26001)
    parser.add_argument("--base-model-path", type=str, required=True)
    parser.add_argument("--draft-model-path", type=str, required=True)
    parser.add_argument("--bench-name", type=str, choices=["mt_bench", "gsm8k"], required=True)
    parser.add_argument("--question-file", type=str, default=None)
    parser.add_argument("--limit", type=int, default=0, help="Limit number of questions")
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--nodes", type=int, default=50)
    parser.add_argument("--max_depth", type=int, default=10)
    parser.add_argument("--device-map", type=str, default="cuda:0")
    parser.add_argument("--load-in-4bit", action="store_true")
    parser.add_argument("--load-in-8bit", action="store_true")
    parser.add_argument("--answer-file", type=str, default=None, help="Output answer file")
    parser.add_argument("--model-id", type=str, default="llama-2-chat", help="Model ID")
    parser.add_argument("--num-choices", type=int, default=1, help="Number of completion choices")
    parser.add_argument("--debug", action="store_true", default=False, help="Enable debug output (DRAFT-DEBUG messages)")
    parser.add_argument("--print-tree", action="store_true", default=False, help="Print tree structure during expansion")
    parser.add_argument("--per-token-probability-bound", type=float, default=0.0, help="Probability bound for each token (default: 0.0)")
    parser.add_argument("--per-path-probability-bound", type=float, default=0.0, help="Probability bound for each path (default: 0.0)")
    parser.add_argument("--device-name", type=str, default=None, help="Device name for profiling (e.g., rtx5080). If provided, profiles width timing after warmup.")
    parser.add_argument("--draft-per-hour-cost", type=float, default=0.0, help="Draft model cost per hour (default: 0.0)")
    parser.add_argument("--target-per-hour-cost", type=float, default=0.0, help="Target model cost per hour (default: 0.0)")
    parser.add_argument("--communication-per-gb-cost", type=float, default=(35.0 / 15.0), help="Network communication cost in $/GB (default: 35/15)")
    parser.add_argument("--accept-length-margin", type=float, default=0.05, help="Conservative margin for expected accept length (default: 0.05)")
    def parse_cost_sensitivity(value):
        """Parse cost sensitivity in [0, 100]."""
        try:
            v = float(value)
        except ValueError:
            raise argparse.ArgumentTypeError(f"Invalid cost sensitivity value: {value}. Use a number in [0, 100].")
        if v < 0.0 or v > 100.0:
            raise argparse.ArgumentTypeError(f"Invalid cost sensitivity value: {value}. Must be in [0, 100].")
        return v
    
    parser.add_argument("--cost-sensitivity", type=parse_cost_sensitivity, default=0.0, help="Cost sensitivity weight in [0, 100] (0: TPS-focused, 100: objective-cost-focused).")
    parser.add_argument("--min-width", type=int, default=1, help="Minimum width for next_width selection (default: 1)")
    parser.add_argument("--fixed-depth", action="store_true", default=False, help="If set, expand depth until max_depth ignoring latency/cost condition")
    parser.add_argument("--fixed-nnodes", action="store_true", default=False, help="If set, fix final_nnodes as nodes")
    parser.add_argument("--fixed-width", action="store_true", default=False, help="If set, always use max_nnodes as current_width")
    parser.add_argument("--fixed-width-value", type=int, default=None, help="Fixed width value (overrides --fixed-width if set)")
    parser.add_argument("--opt-tree", action="store_true", default=False, help="Use weight-sum-based expansion (opt-tree)")
    parser.add_argument("--server-name", type=str, default="rtxproa6000", help="Server name used for target profile file naming (default: rtxproa6000)")
    parser.add_argument("--enable-gpu-monitor", action="store_true", default=False, help="GPU 모니터링 활성화")
    parser.add_argument("--gpu-monitor-interval", type=float, default=0.1, help="GPU 모니터링 간격 (초) (기본값: 0.1)")
    parser.add_argument("--enable-cpu-monitor", action="store_true", default=False, help="CPU 전력 모니터링 활성화")
    parser.add_argument("--proactive-drafting", action="store_true", default=False, help="Enable proactive drafting (default: False)")
    parser.add_argument("--proactive-threshold", type=float, default=0.0, help="Path prob threshold to start proactive drafting (default: 0.0)")
    parser.add_argument("--adaptive-proactive-threshold", action="store_true", default=False, help="Enable adaptive proactive drafting decision based on expected gain/loss")
    parser.add_argument("--no-draft-cost", action="store_true", default=False, help="Ignore draft tree build cost in objective (latency still used)")
    parser.add_argument("--objective-metric", type=str, choices=["cost", "energy"], default="cost", help="Objective metric for tree/proactive decisions: cost or energy (draft GPU based)")
    parser.add_argument("--server-only-baseline-json", type=str, default=None, help="Server-only SD baseline metrics JSON path")
    parser.add_argument("--disable-server-only", action="store_true", default=False, help="Disable automatic server-only mode switching")
    parser.add_argument("--seed", type=int, default=None, help="재현용 시드 (지정 시 torch/random/numpy 시드 고정)")
    parser.add_argument("--deterministic", action="store_true", default=False, help="GPU 연산까지 동일 결과 보장 (PyTorch deterministic 모드, 일부 연산 느려질 수 있음)")
    args = parser.parse_args()

    if args.question_file:
        question_file = args.question_file
    else:
        if args.bench_name == "mt_bench":
            script_dir = os.path.dirname(__file__)
            parent_dir = os.path.dirname(script_dir)
            question_file = f"{parent_dir}/data/mt_bench/question.jsonl"
        elif args.bench_name == "gsm8k":
            script_dir = os.path.dirname(__file__)
            parent_dir = os.path.dirname(script_dir)
            question_file = f"{parent_dir}/data/gsm8k.jsonl"
        else:
            raise ValueError("Undefined bench_name")

    # answer_file이 제공되지 않으면 기본값 생성
    if args.answer_file is None:
        script_dir = os.path.dirname(__file__)
        parent_dir = os.path.dirname(script_dir)
        args.answer_file = f"{parent_dir}/result/draft_answers_{args.bench_name}.jsonl"
    
    # model_id에 temperature 추가 (원본과 동일)
    args.model_id = args.model_id + "-temperature-" + str(args.temperature)

    if args.fixed_width_value is not None:
        args.fixed_width_value = max(1, int(args.fixed_width_value))

    if args.seed is not None:
        set_seed(args.seed)
        print(f"[draft] seed fixed: {args.seed}")
    if args.deterministic:
        set_deterministic()
        print("[draft] deterministic mode enabled")
    
    print(f"Output to {args.answer_file}")
    
    run_draft(
        host=args.host,
        port=args.port,
        base_model_path=args.base_model_path,
        draft_model_path=args.draft_model_path,
        bench_name=args.bench_name,
        question_file=question_file,
        draft_per_hour_cost=args.draft_per_hour_cost,
        target_per_hour_cost=args.target_per_hour_cost,
        communication_per_gb_cost=args.communication_per_gb_cost,
        accept_length_margin=args.accept_length_margin,
        cost_sensitivity=args.cost_sensitivity,
        opt_tree=args.opt_tree,
        limit=args.limit,
        temperature=args.temperature,
        nodes=args.nodes,
        max_depth=args.max_depth,
        device_map=args.device_map,
        load_in_4bit=args.load_in_4bit,
        load_in_8bit=args.load_in_8bit,
        answer_file=args.answer_file,
        model_id=args.model_id,
        num_choices=args.num_choices,
        debug=args.debug,
        print_tree=args.print_tree,
        per_token_probability_bound=args.per_token_probability_bound,
        per_path_probability_bound=args.per_path_probability_bound,
        device_name=args.device_name,
        min_width=args.min_width,
        fixed_depth=args.fixed_depth,
        fixed_nnodes=args.fixed_nnodes,
        fixed_width=args.fixed_width,
        fixed_width_value=args.fixed_width_value,
        server_name=args.server_name,
        enable_gpu_monitor=args.enable_gpu_monitor,
        gpu_monitor_interval=args.gpu_monitor_interval,
        enable_cpu_monitor=args.enable_cpu_monitor,
        proactive_drafting=args.proactive_drafting,
        proactive_threshold=args.proactive_threshold,
        adaptive_proactive_threshold=args.adaptive_proactive_threshold,
        no_draft_cost=args.no_draft_cost,
        objective_metric=args.objective_metric,
        server_only_baseline_json=args.server_only_baseline_json,
        disable_server_only=args.disable_server_only,
    )
    
    # answer_file 정리 (reorg_answer_file과 유사한 기능)
    if args.answer_file and os.path.exists(args.answer_file):
        def reorg_answer_file(answer_file):
            """Sort by question id and de-duplication"""
            answers = {}
            with open(answer_file, "r") as fin:
                for l in fin:
                    qid = json.loads(l)["question_id"]
                    answers[qid] = l

            qids = sorted(list(answers.keys()))
            with open(answer_file, "w") as fout:
                for qid in qids:
                    fout.write(answers[qid])
        
        reorg_answer_file(args.answer_file)


