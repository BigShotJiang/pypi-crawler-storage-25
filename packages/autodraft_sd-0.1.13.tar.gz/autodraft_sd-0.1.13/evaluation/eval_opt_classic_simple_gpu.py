import argparse
import json
import os
script_dir = os.path.dirname(__file__)
parent_dir = os.path.dirname(script_dir)
# os.environ["CUDA_VISIBLE_DEVICES"] = "6,7"
import subprocess
import threading
import time
from datetime import datetime

import shortuuid
from fastchat.llm_judge.common import load_questions
from fastchat.model import get_conversation_template
from tqdm import tqdm

from opt_classic.model import SPModel
from opt_classic.kv_cache import initialize_past_key_values
from opt_classic.utils import *


class GPUMonitor:
    """NVIDIA GPU 메모리와 utilization을 모니터링하는 클래스"""
    
    def __init__(self, interval=0.1, fix_gpu_clock=False, graphics_clock=None, memory_clock=None):
        self.interval = interval
        self.monitoring = False
        self.data = []
        self.monitor_thread = None
        self.fix_gpu_clock = fix_gpu_clock
        self.graphics_clock = graphics_clock
        self.memory_clock = memory_clock
        self.original_graphics_clock = None
        self.original_memory_clock = None
        
        if self.fix_gpu_clock:
            self._set_gpu_clocks()
    
    def _set_gpu_clocks(self):
        """GPU 클럭을 고정 설정"""
        try:
            # 현재 클럭 상태 저장
            result = subprocess.run([
                'nvidia-smi', 
                '--query-gpu=clocks.current.graphics,clocks.current.memory',
                '--format=csv,noheader,nounits'
            ], capture_output=True, text=True, timeout=5)
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                if lines and lines[0].strip():
                    parts = lines[0].split(', ')
                    if len(parts) >= 2:
                        self.original_graphics_clock = int(parts[0])
                        self.original_memory_clock = int(parts[1])
                        print(f"[eval] 원본 GPU 클럭 저장: Graphics={self.original_graphics_clock}MHz, Memory={self.original_memory_clock}MHz")
            
            # GPU 클럭 설정
            cmd = ['nvidia-smi', '--applications-clocks=']
            if self.graphics_clock is not None:
                cmd[1] += f"{self.graphics_clock}"
            else:
                cmd[1] += "0"  # 기본값
            
            if self.memory_clock is not None:
                cmd[1] += f",{self.memory_clock}"
            else:
                cmd[1] += ",0"  # 기본값
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                print(f"[eval] GPU 클럭 고정 설정: Graphics={self.graphics_clock}MHz, Memory={self.memory_clock}MHz")
            else:
                print(f"[eval] GPU 클럭 설정 실패: {result.stderr}")
                
        except Exception as e:
            print(f"[eval] GPU 클럭 설정 중 오류: {e}")
    
    def _restore_gpu_clocks(self):
        """GPU 클럭을 원래 상태로 복원"""
        try:
            if self.original_graphics_clock is not None and self.original_memory_clock is not None:
                cmd = ['nvidia-smi', '--applications-clocks=default']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                
                if result.returncode == 0:
                    print(f"[eval] GPU 클럭 복원 완료")
                else:
                    print(f"[eval] GPU 클럭 복원 실패: {result.stderr}")
        except Exception as e:
            print(f"[eval] GPU 클럭 복원 중 오류: {e}")
    
    def __del__(self):
        """소멸자에서 GPU 클럭 복원"""
        if self.fix_gpu_clock:
            self._restore_gpu_clocks()
        
    def get_gpu_info(self):
        """nvidia-smi를 사용하여 GPU 정보를 가져옵니다"""
        try:
            # nvidia-smi를 사용하여 GPU 정보 가져오기 (클럭 정보 및 파워 포함)
            result = subprocess.run([
                'nvidia-smi', 
                '--query-gpu=index,memory.used,memory.total,utilization.gpu,temperature.gpu,power.draw,power.limit,clocks.current.graphics,clocks.current.memory,clocks.max.graphics,clocks.max.memory',
                '--format=csv,noheader,nounits'
            ], capture_output=True, text=True, timeout=5)
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                gpu_info = []
                for line in lines:
                    if line.strip():
                        parts = line.split(', ')
                        if len(parts) >= 11:
                            gpu_info.append({
                                'gpu_id': int(parts[0]),
                                'memory_used_mb': int(parts[1]),
                                'memory_total_mb': int(parts[2]),
                                'utilization_percent': int(parts[3]),
                                'temperature_c': int(parts[4]),
                                'power_draw_w': float(parts[5]) if parts[5] != '[Not Supported]' and parts[5] != 'N/A' else None,
                                'power_limit_w': float(parts[6]) if parts[6] != '[Not Supported]' and parts[6] != 'N/A' else None,
                                'graphics_clock_mhz': int(parts[7]) if parts[7] != '[Not Supported]' else None,
                                'memory_clock_mhz': int(parts[8]) if parts[8] != '[Not Supported]' else None,
                                'max_graphics_clock_mhz': int(parts[9]) if parts[9] != '[Not Supported]' else None,
                                'max_memory_clock_mhz': int(parts[10]) if parts[10] != '[Not Supported]' else None,
                                'memory_used_percent': (int(parts[1]) / int(parts[2])) * 100 if int(parts[2]) > 0 else 0,
                                'power_usage_percent': (float(parts[5]) / float(parts[6])) * 100 if parts[5] != '[Not Supported]' and parts[6] != '[Not Supported]' and parts[5] != 'N/A' and parts[6] != 'N/A' and float(parts[6]) > 0 else None,
                                'timestamp': time.time()
                            })
                return gpu_info
            else:
                print(f"nvidia-smi 실행 실패: {result.stderr}")
                return self._get_default_gpu_info()
        except Exception as e:
            print(f"GPU 정보 가져오기 실패: {e}")
            return self._get_default_gpu_info()
    
    def _get_default_gpu_info(self):
        """기본 GPU 정보를 반환합니다"""
        return [{
            'gpu_id': 0,
            'memory_used_mb': 0,
            'memory_total_mb': 1,
            'utilization_percent': 0,
            'temperature_c': 0,
            'power_draw_w': None,
            'power_limit_w': None,
            'graphics_clock_mhz': None,
            'memory_clock_mhz': None,
            'max_graphics_clock_mhz': None,
            'max_memory_clock_mhz': None,
            'memory_used_percent': 0,
            'power_usage_percent': None,
            'timestamp': time.time()
        }]
    
    def monitor_loop(self):
        """모니터링 루프"""
        while self.monitoring:
            gpu_info = self.get_gpu_info()
            if gpu_info:
                timestamp = time.time()
                for i, gpu in enumerate(gpu_info):
                    self.data.append({
                        'timestamp': timestamp,
                        'gpu_id': i,
                        **gpu
                    })
            time.sleep(self.interval)
    
    def start_monitoring(self):
        """모니터링 시작"""
        if not self.monitoring:
            self.monitoring = True
            self.data = []
            self.monitor_thread = threading.Thread(target=self.monitor_loop)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()
    
    def stop_monitoring(self):
        """모니터링 중지"""
        if self.monitoring:
            self.monitoring = False
            if self.monitor_thread:
                self.monitor_thread.join()
    
    def get_stats(self):
        """통계 정보 반환"""
        if not self.data:
            return None
        
        # GPU별로 통계 계산
        gpu_stats = {}
        for entry in self.data:
            gpu_id = entry['gpu_id']
            if gpu_id not in gpu_stats:
                gpu_stats[gpu_id] = {
                    'memory_used_mb': [],
                    'memory_total_mb': [],
                    'utilization_percent': [],
                    'temperature_c': [],
                    'power_draw_w': [],
                    'power_limit_w': [],
                    'power_usage_percent': [],
                    'graphics_clock_mhz': [],
                    'memory_clock_mhz': [],
                    'max_graphics_clock_mhz': [],
                    'max_memory_clock_mhz': [],
                    'memory_used_percent': []
                }
            
            gpu_stats[gpu_id]['memory_used_mb'].append(entry['memory_used_mb'])
            gpu_stats[gpu_id]['memory_total_mb'].append(entry['memory_total_mb'])
            gpu_stats[gpu_id]['utilization_percent'].append(entry['utilization_percent'])
            gpu_stats[gpu_id]['temperature_c'].append(entry['temperature_c'])
            gpu_stats[gpu_id]['memory_used_percent'].append(entry['memory_used_percent'])
            
            # 파워 정보 추가 (None 값 제외)
            if entry['power_draw_w'] is not None:
                gpu_stats[gpu_id]['power_draw_w'].append(entry['power_draw_w'])
            if entry['power_limit_w'] is not None:
                gpu_stats[gpu_id]['power_limit_w'].append(entry['power_limit_w'])
            if entry['power_usage_percent'] is not None:
                gpu_stats[gpu_id]['power_usage_percent'].append(entry['power_usage_percent'])
            
            # 클럭 정보 추가 (None 값 제외)
            if entry['graphics_clock_mhz'] is not None:
                gpu_stats[gpu_id]['graphics_clock_mhz'].append(entry['graphics_clock_mhz'])
            if entry['memory_clock_mhz'] is not None:
                gpu_stats[gpu_id]['memory_clock_mhz'].append(entry['memory_clock_mhz'])
            if entry['max_graphics_clock_mhz'] is not None:
                gpu_stats[gpu_id]['max_graphics_clock_mhz'].append(entry['max_graphics_clock_mhz'])
            if entry['max_memory_clock_mhz'] is not None:
                gpu_stats[gpu_id]['max_memory_clock_mhz'].append(entry['max_memory_clock_mhz'])
        
        # 평균, 최대, 최소 계산
        stats = {}
        for gpu_id, data in gpu_stats.items():
            stats[f'gpu_{gpu_id}'] = {
                'memory_used_mb': {
                    'avg': sum(data['memory_used_mb']) / len(data['memory_used_mb']),
                    'max': max(data['memory_used_mb']),
                    'min': min(data['memory_used_mb'])
                },
                'memory_total_mb': data['memory_total_mb'][0] if data['memory_total_mb'] else 0,  # 총 메모리는 고정값
                'utilization_percent': {
                    'avg': sum(data['utilization_percent']) / len(data['utilization_percent']),
                    'max': max(data['utilization_percent']),
                    'min': min(data['utilization_percent'])
                },
                'temperature_c': {
                    'avg': sum(data['temperature_c']) / len(data['temperature_c']),
                    'max': max(data['temperature_c']),
                    'min': min(data['temperature_c'])
                },
                'memory_used_percent': {
                    'avg': sum(data['memory_used_percent']) / len(data['memory_used_percent']),
                    'max': max(data['memory_used_percent']),
                    'min': min(data['memory_used_percent'])
                }
            }
            
            # 파워 통계 추가 (데이터가 있는 경우만)
            if data['power_draw_w']:
                stats[f'gpu_{gpu_id}']['power_draw_w'] = {
                    'avg': sum(data['power_draw_w']) / len(data['power_draw_w']),
                    'max': max(data['power_draw_w']),
                    'min': min(data['power_draw_w'])
                }
            if data['power_limit_w']:
                stats[f'gpu_{gpu_id}']['power_limit_w'] = data['power_limit_w'][0]  # 파워 한계는 고정값
            if data['power_usage_percent']:
                stats[f'gpu_{gpu_id}']['power_usage_percent'] = {
                    'avg': sum(data['power_usage_percent']) / len(data['power_usage_percent']),
                    'max': max(data['power_usage_percent']),
                    'min': min(data['power_usage_percent'])
                }
            
            # 클럭 정보 통계 (데이터가 있는 경우만)
            if data['graphics_clock_mhz']:
                stats[f'gpu_{gpu_id}']['graphics_clock_mhz'] = {
                    'avg': sum(data['graphics_clock_mhz']) / len(data['graphics_clock_mhz']),
                    'max': max(data['graphics_clock_mhz']),
                    'min': min(data['graphics_clock_mhz'])
                }
            if data['memory_clock_mhz']:
                stats[f'gpu_{gpu_id}']['memory_clock_mhz'] = {
                    'avg': sum(data['memory_clock_mhz']) / len(data['memory_clock_mhz']),
                    'max': max(data['memory_clock_mhz']),
                    'min': min(data['memory_clock_mhz'])
                }
            if data['max_graphics_clock_mhz']:
                stats[f'gpu_{gpu_id}']['max_graphics_clock_mhz'] = data['max_graphics_clock_mhz'][0]  # 최대값은 고정
            if data['max_memory_clock_mhz']:
                stats[f'gpu_{gpu_id}']['max_memory_clock_mhz'] = data['max_memory_clock_mhz'][0]  # 최대값은 고정
        
        return stats
    
    def save_data(self, filename=None):
        """데이터를 JSON 파일로 저장"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"gpu_monitor_{timestamp}.json"
        
        with open(filename, 'w') as f:
            json.dump(self.data, f, indent=2)
        print(f"[eval] GPU 모니터링 데이터 저장: {filename}")
        return filename


def save_performance_stats(timing_data, gpu_data, output_file, args):
    """간단한 성능 통계를 계산하고 JSON 파일로 저장"""
    # 타이밍 통계 계산
    if timing_data:
        total_times = [step['total_time_seconds'] for step in timing_data]
        timing_stats = {
            'total_time_seconds': sum(total_times),
            'avg_time_seconds': sum(total_times) / len(total_times),
            'min_time_seconds': min(total_times),
            'max_time_seconds': max(total_times),
            'num_questions': len(total_times)
        }
    else:
        timing_stats = {
            'total_time_seconds': 0,
            'avg_time_seconds': 0,
            'min_time_seconds': 0,
            'max_time_seconds': 0,
            'num_questions': 0
        }
    
    # GPU 통계 계산 (있는 경우)
    gpu_summary = {}
    if gpu_data:
        # 모든 GPU 통계를 합쳐서 요약 통계 생성
        all_gpu_stats = {}
        for step_data in gpu_data:
            for gpu_id, stats in step_data["gpu_stats"].items():
                if gpu_id not in all_gpu_stats:
                    all_gpu_stats[gpu_id] = {
                        'memory_used_mb': [],
                        'utilization_percent': [],
                        'temperature_c': [],
                        'memory_used_percent': [],
                        'power_draw_w': [],
                        'power_usage_percent': []
                    }
                
                all_gpu_stats[gpu_id]['memory_used_mb'].extend([stats['memory_used_mb']['avg']])
                all_gpu_stats[gpu_id]['utilization_percent'].extend([stats['utilization_percent']['avg']])
                all_gpu_stats[gpu_id]['temperature_c'].extend([stats['temperature_c']['avg']])
                all_gpu_stats[gpu_id]['memory_used_percent'].extend([stats['memory_used_percent']['avg']])
                
                # 파워 정보 추가 (있는 경우만)
                if 'power_draw_w' in stats:
                    all_gpu_stats[gpu_id]['power_draw_w'].extend([stats['power_draw_w']['avg']])
                if 'power_usage_percent' in stats:
                    all_gpu_stats[gpu_id]['power_usage_percent'].extend([stats['power_usage_percent']['avg']])
        
        # 요약 통계 생성
        for gpu_id, data in all_gpu_stats.items():
            gpu_summary[gpu_id] = {
                'memory_used_mb': {
                    'min': min(data['memory_used_mb']),
                    'max': max(data['memory_used_mb']),
                    'avg': sum(data['memory_used_mb']) / len(data['memory_used_mb'])
                },
                'utilization_percent': {
                    'min': min(data['utilization_percent']),
                    'max': max(data['utilization_percent']),
                    'avg': sum(data['utilization_percent']) / len(data['utilization_percent'])
                },
                'temperature_c': {
                    'min': min(data['temperature_c']),
                    'max': max(data['temperature_c']),
                    'avg': sum(data['temperature_c']) / len(data['temperature_c'])
                },
                'memory_used_percent': {
                    'min': min(data['memory_used_percent']),
                    'max': max(data['memory_used_percent']),
                    'avg': sum(data['memory_used_percent']) / len(data['memory_used_percent'])
                }
            }
            
            # 파워 통계 추가 (데이터가 있는 경우만)
            if data['power_draw_w']:
                gpu_summary[gpu_id]['power_draw_w'] = {
                    'min': min(data['power_draw_w']),
                    'max': max(data['power_draw_w']),
                    'avg': sum(data['power_draw_w']) / len(data['power_draw_w'])
                }
            if data['power_usage_percent']:
                gpu_summary[gpu_id]['power_usage_percent'] = {
                    'min': min(data['power_usage_percent']),
                    'max': max(data['power_usage_percent']),
                    'avg': sum(data['power_usage_percent']) / len(data['power_usage_percent'])
                }
    

    # 최종 데이터 구성
    result_data = {
        "experiment_info": {
            "timestamp": datetime.now().isoformat(),
            "base_model_path": args.base_model_path,
            "draft_model_path": args.draft_model_path,
            "model_id": args.model_id,
            "bench_name": args.bench_name,
            "nodes": args.nodes,
            "threshold": args.threshold,
            "max_depth": args.max_depth,
            "temperature": args.temperature,
            "load_in_8bit": args.load_in_8bit,
            "enable_gpu_monitor": hasattr(args, 'enable_gpu_monitor') and args.enable_gpu_monitor,
            "gpu_monitor_interval": getattr(args, 'gpu_monitor_interval', 0.1),
            "fix_gpu_clock": getattr(args, 'fix_gpu_clock', False),
            "graphics_clock": getattr(args, 'graphics_clock', None),
            "memory_clock": getattr(args, 'memory_clock', None)
        },
        "timing_stats": timing_stats,
        "gpu_summary": gpu_summary,
        "raw_timing_data": timing_data,
        "raw_gpu_data": gpu_data
    }
    
    # JSON 파일로 저장
    with open(output_file, 'w') as f:
        json.dump(result_data, f, indent=2)
    
    # 터미널에 통계 출력
    print("="*60)
    print("[eval] 간단한 성능 통계 요약")
    print("="*60)
    print(f"총 처리 시간: {timing_stats['total_time_seconds']:.4f}초")
    print(f"평균 처리 시간: {timing_stats['avg_time_seconds']:.4f}초")
    print(f"최소 처리 시간: {timing_stats['min_time_seconds']:.4f}초")
    print(f"최대 처리 시간: {timing_stats['max_time_seconds']:.4f}초")
    print(f"처리된 질문 수: {timing_stats['num_questions']}")
    
    # GPU 통계 출력 (있는 경우)
    if gpu_summary:
        print("\n--- GPU 사용 통계 ---")
        for gpu_id, stats in gpu_summary.items():
            print(f"{gpu_id}:")
            print(f"  메모리 사용량: {stats['memory_used_mb']['avg']:.1f}MB (평균), {stats['memory_used_mb']['min']:.1f}MB (최소), {stats['memory_used_mb']['max']:.1f}MB (최대)")
            print(f"  메모리 사용률: {stats['memory_used_percent']['avg']:.1f}% (평균), {stats['memory_used_percent']['min']:.1f}% (최소), {stats['memory_used_percent']['max']:.1f}% (최대)")
            print(f"  GPU 활용률: {stats['utilization_percent']['avg']:.1f}% (평균), {stats['utilization_percent']['min']:.1f}% (최소), {stats['utilization_percent']['max']:.1f}% (최대)")
            print(f"  온도: {stats['temperature_c']['avg']:.1f}°C (평균), {stats['temperature_c']['min']:.1f}°C (최소), {stats['temperature_c']['max']:.1f}°C (최대)")
    else:
        print("\n--- GPU 모니터링 비활성화됨 ---")
    
    print("="*60)
    print(f"[eval] 성능 통계 저장: {output_file}")
    print("="*60)


def get_available_gpu_clocks():
    """사용 가능한 GPU 클럭 조합을 반환"""
    try:
        result = subprocess.run([
            'nvidia-smi', 
            '--query-supported-clocks=graphics,memory',
            '--format=csv,noheader,nounits'
        ], capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            clock_combinations = []
            for line in lines:
                if line.strip():
                    parts = line.split(', ')
                    if len(parts) >= 2:
                        try:
                            graphics_clock = int(parts[0].strip())
                            memory_clock = int(parts[1].strip())
                            clock_combinations.append({
                                'graphics_clock': graphics_clock,
                                'memory_clock': memory_clock
                            })
                        except ValueError as ve:
                            print(f"클럭 값 파싱 오류: {line} - {ve}")
                            continue
            return clock_combinations
        else:
            print(f"GPU 클럭 조회 실패: {result.stderr}")
            return []
    except Exception as e:
        print(f"GPU 클럭 조회 중 오류: {e}")
        return []


def spforward(input_ids, model, tokenizer, args, logits_processor=None, max_steps=512, gpu_monitor=None, detailed_timing=None):
    assert input_ids.shape[0] == 1, "Only support batch size 1 for now!!"
    # Avoid modifying the input_ids in-place
    input_ids = input_ids.clone()
    model.draft_stable_kv = None

    # Initialize the past key and value states
    if hasattr(model, "past_key_values"):
        past_key_values = model.past_key_values
        past_key_values_data = model.past_key_values_data
        current_length_data = model.current_length_data
        # Reset the past key and value states
        current_length_data.zero_()
    else:
        (
            past_key_values,
            past_key_values_data,
            current_length_data,
        ) = initialize_past_key_values(model.base_model)
        model.past_key_values = past_key_values
        model.past_key_values_data = past_key_values_data
        model.current_length_data = current_length_data

    input_len = input_ids.shape[1]

    # 초기화 단계 (GPU 모니터링 없음)
    torch.cuda.synchronize()
    start_time = time.time()
    
    draft_input_ids, draft_position_ids, tree_attention_mask, last_token, parent, tree_depth = model(input_ids,
                                                                                        past_key_values=past_key_values,
                                                                                        output_orig=True, nodes=args.nodes,
                                                                                        threshold=args.threshold,
                                                                                        max_depth=args.max_depth,
                                                                                        logits_processor=logits_processor)  # initialize with base model [PJ]

    draft_input_ids = torch.cat([last_token.to(draft_input_ids.device), draft_input_ids], dim=-1)
    draft_position_ids = torch.cat([torch.tensor([draft_position_ids[0] - 1],device=draft_position_ids.device), draft_position_ids], dim=-1)
    tree_attention_mask = torch.cat(
        [torch.zeros(1, tree_attention_mask.size(1), dtype=tree_attention_mask.dtype,device=tree_attention_mask.device), tree_attention_mask],
        dim=0)
    tree_attention_mask = torch.cat(
        [torch.ones(tree_attention_mask.size(0), 1, dtype=tree_attention_mask.dtype,device=tree_attention_mask.device), tree_attention_mask],
        dim=1)
    
    torch.cuda.synchronize()
    end_time = time.time()
    
    # 초기화 단계 타이밍 저장
    if detailed_timing is not None:
        detailed_timing['initialization'] = {
            'time_seconds': end_time - start_time,
            'gpu_stats': None,
            'timestamp': time.time()
        }

    new_token = 0
    total_tree_length = 0

    for idx in range(max_steps):
        assert past_key_values[0][0].shape[2] == draft_position_ids[0]

        # Tree decoding 단계 (GPU 모니터링 없음)
        logits, hidden_state_new, outputs = tree_decoding(
            model,
            draft_input_ids,
            past_key_values,
            draft_position_ids,
            tree_attention_mask,
            gpu_monitor=None,  # GPU 모니터링 비활성화
            step_info=None
        )

        # Verify 단계 (GPU 모니터링 없음)
        input_ids, best_candidate, accept_length, draft_input_ids, draft_position_ids, tree_attention_mask, parent, next_tree_depth = verify(
            input_ids,
            logits,
            draft_input_ids,
            draft_position_ids,
            tree_attention_mask,
            past_key_values_data,
            current_length_data,
            parent,
            model,
            args.nodes,
            args.threshold,
            args.max_depth,
            logits_processor,
            gpu_monitor=None,  # GPU 모니터링 비활성화
            step_info=None
        )
        
        new_token += accept_length+1
        total_tree_length += next_tree_depth
        if tokenizer.eos_token_id in input_ids[0, input_len:].tolist():
            break
        if new_token > 1024:
            break
        if input_ids.shape[1] > 1960:
            break
    return input_ids, new_token, idx, accept_length, total_tree_length


def run_eval(
        base_model_path,
        draft_model_path,
        model_id,
        question_file,
        question_begin,
        question_end,
        answer_file,
        max_new_token,
        num_choices,
        num_gpus_per_model,
        num_gpus_total,
        max_gpu_memory,
        temperature,
        args,
        enable_gpu_monitor=False,
        gpu_monitor_interval=0.1,
        output_file=None,
        fix_gpu_clock=False,
        graphics_clock=None,
        memory_clock=None,
):
    print("target model: ", base_model_path)
    questions = load_questions(question_file, question_begin, question_end)
    # random shuffle the questions to balance the loading
    # random.shuffle(questions)
    shuffled_ids = [q["question_id"] for q in questions]
    # with open(f"data/{args.bench_name}/model_ids/{args.model_id}.shuffled_ids", "w") as fout:
    #     json.dump(shuffled_ids, fout)

    # Split the question file into `num_gpus` files
    assert num_gpus_total % num_gpus_per_model == 0
    use_ray = num_gpus_total // num_gpus_per_model > 1

    if use_ray:
        get_answers_func = ray.remote(num_gpus=num_gpus_per_model)(
            get_model_answers
        ).remote
    else:
        get_answers_func = get_model_answers

    chunk_size = len(questions) // (num_gpus_total // num_gpus_per_model)  # // 2
    ans_handles = []
    for i in range(0, len(questions), chunk_size):
        ans_handles.append(
            get_answers_func(
                base_model_path,
                draft_model_path,
                model_id,
                questions[i: i + chunk_size],
                answer_file,
                max_new_token,
                num_choices,
                num_gpus_per_model,
                max_gpu_memory,
                temperature,
                args,
                enable_gpu_monitor,
                gpu_monitor_interval,
                output_file,
                fix_gpu_clock,
                graphics_clock,
                memory_clock,
            )
        )

    if use_ray:
        ray.get(ans_handles)


@torch.inference_mode()
def get_model_answers(
        base_model_path,
        draft_model_path,
        model_id,
        questions,
        answer_file,
        max_new_token,
        num_choices,
        num_gpus_per_model,
        max_gpu_memory,
        temperature,
        args,
        enable_gpu_monitor=False,
        gpu_monitor_interval=0.1,
        output_file=None,
        fix_gpu_clock=False,
        graphics_clock=None,
        memory_clock=None,
):
    print("temperature:",temperature)

    # 8-bit quantization 설정 MODIFIED by PJ
    quantization_config = None
    if args.load_in_8bit:
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            llm_int8_threshold=6.0,
            llm_int8_skip_modules=["lm_head"],  # lm_head는 원본 precision 유지
        )
    
    model = SPModel.from_pretrained(
        base_model_path=base_model_path,
        draft_model_path=draft_model_path,
        torch_dtype=torch.float16,
        low_cpu_mem_usage=True,
        device_map="auto",
        quantization_config=quantization_config  # quantization 적용
    )

    tokenizer = model.get_tokenizer()

    if temperature > 1e-5:
        logits_processor = prepare_logits_processor(temperature=temperature)
    else:
        logits_processor = None

    model.eval()
    print('Check model training state:', model.training)

    cuda_visible_devices = os.environ.get('CUDA_VISIBLE_DEVICES')
    print('CUDA VISIBLE DEVICES:', cuda_visible_devices)
    
    
    # 성능 데이터 수집용 변수들
    timing_data = []
    gpu_data = []

    question = questions[0]

    # warmup
    for _ in range(3):
        torch.manual_seed(0)

        if "vicuna" in base_model_path:
            conv = get_conversation_template("vicuna")

        else:
            conv = get_conversation_template("llama-2-chat")
            sys_p = "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. Please ensure that your responses are socially unbiased and positive in nature.\n\nIf a question does not make any sense, or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, please don't share false information."
            conv.system_message = sys_p
        turns = []
        idxs = []
        new_tokens = []
        wall_time = []
        if args.bench_name=="gsm8k":
            question_turns=[question["question"]]
        else:
            question_turns=question["turns"]
        for j in range(len(question_turns)):
            qs = question_turns[j]
            conv.append_message(conv.roles[0], qs)
            conv.append_message(conv.roles[1], None)
            prompt = conv.get_prompt() + " "
            input_ids = tokenizer([prompt]).input_ids

            # try:
            torch.cuda.synchronize()
            start_time = time.time()

            output_ids, new_token, idx, accept_length, total_tree_length = spforward(
                torch.as_tensor(input_ids).cuda(),
                model,
                tokenizer,
                args,
                logits_processor,
            )
            torch.cuda.synchronize()
            total_time = time.time() - start_time
            output_ids = output_ids[0][len(input_ids[0]):]
            # be consistent with the template's stop_token_ids
            if conv.stop_token_ids:
                stop_token_ids_index = [
                    i
                    for i, id in enumerate(output_ids)
                    if id in conv.stop_token_ids
                ]
                if len(stop_token_ids_index) > 0:
                    output_ids = output_ids[: stop_token_ids_index[0]]

            output = tokenizer.decode(
                output_ids,
                spaces_between_special_tokens=False,
            )
            conv.stop_str = "</s>"
            if conv.stop_str and output.find(conv.stop_str) > 0:
                output = output[: output.find(conv.stop_str)]
            for special_token in tokenizer.special_tokens_map.values():
                if isinstance(special_token, list):
                    for special_tok in special_token:
                        output = output.replace(special_tok, "")
                else:
                    output = output.replace(special_token, "")
            output = output.strip()

            if conv.name == "xgen" and output.startswith("Assistant:"):
                output = output.replace("Assistant:", "", 1).strip()

            turns.append(output)
            idxs.append(int(idx))
            new_tokens.append(int(new_token))
            wall_time.append(total_time)
            conv.messages[-1][-1] = output
    print('Warmup done')

    # GPU 모니터 초기화
    gpu_monitor = None
    if enable_gpu_monitor:
        gpu_monitor = GPUMonitor(
            interval=gpu_monitor_interval,
            fix_gpu_clock=fix_gpu_clock,
            graphics_clock=graphics_clock,
            memory_clock=memory_clock
        )
        gpu_monitor.start_monitoring()
        print(f"[eval] GPU 모니터링 시작 (간격: {gpu_monitor_interval}초)")


    # questions=questions[6:]
    total_steps = 0
    total_new_tokens=0
    all_time=0
    total_accept_length=0
    total_tree_length_sum=0
    c=0
    for question in tqdm(questions):

        choices = []
        for i in range(num_choices):
            torch.manual_seed(i)
            if "vicuna" in base_model_path:
                conv = get_conversation_template("vicuna")
            else:
                conv = get_conversation_template("llama-2-chat")
                sys_p = "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. Please ensure that your responses are socially unbiased and positive in nature.\n\nIf a question does not make any sense, or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, please don't share false information."
                conv.system_message = sys_p
            turns = []
            idxs = []
            new_tokens = []
            wall_time = []
            if args.bench_name == "gsm8k":
                question_turns = [question["question"]]
            else:
                question_turns = question["turns"]

            for j in range(len(question_turns)):
                qs = question_turns[j]
                conv.append_message(conv.roles[0], qs)
                conv.append_message(conv.roles[1], None)
                prompt = conv.get_prompt() + " "
                input_ids = tokenizer([prompt]).input_ids

                try:
                    # spforward 시작 전 GPU 상태 측정
                    if gpu_monitor:
                        gpu_monitor.start_monitoring()
                    
                    torch.cuda.synchronize()
                    start_time = time.time()
                    
                    output_ids, new_token, idx, accept_length, total_tree_length = spforward(
                        torch.as_tensor(input_ids).cuda(),
                        model,
                        tokenizer,
                        args,
                        logits_processor,
                        gpu_monitor=None,  # 내부 GPU 모니터링 비활성화
                        detailed_timing=None
                    )
                    total_accept_length+=accept_length
                    total_tree_length_sum+=total_tree_length
                    c+=1
                    
                    torch.cuda.synchronize()
                    total_time = time.time() - start_time
                    
                    # spforward 완료 후 GPU 상태 측정
                    gpu_stats = None
                    if gpu_monitor:
                        gpu_monitor.stop_monitoring()
                        gpu_stats = gpu_monitor.get_stats()
                    
                    # 간단한 타이밍 데이터 저장
                    timing_data.append({
                        "question_id": question["question_id"],
                        "choice_index": i,
                        "turn_index": j,
                        "total_time_seconds": total_time,
                        "timestamp": time.time()
                    })
                    
                    # 간단한 GPU 데이터 저장
                    if gpu_stats:
                        gpu_data.append({
                            "question_id": question["question_id"],
                            "choice_index": i,
                            "turn_index": j,
                            "gpu_stats": gpu_stats
                        })
                    output_ids = output_ids[0][len(input_ids[0]):]

                    if conv.stop_token_ids:
                        stop_token_ids_index = [
                            i
                            for i, id in enumerate(output_ids)
                            if id in conv.stop_token_ids
                        ]
                        if len(stop_token_ids_index) > 0:
                            output_ids = output_ids[: stop_token_ids_index[0]]

                    output = tokenizer.decode(
                        output_ids,
                        spaces_between_special_tokens=False,
                    )
                    if conv.stop_str and output.find(conv.stop_str) > 0:
                        output = output[: output.find(conv.stop_str)]
                    for special_token in tokenizer.special_tokens_map.values():
                        if isinstance(special_token, list):
                            for special_tok in special_token:
                                output = output.replace(special_tok, "")
                        else:
                            output = output.replace(special_token, "")
                    output = output.strip()

                    if conv.name == "xgen" and output.startswith("Assistant:"):
                        output = output.replace("Assistant:", "", 1).strip()
                except RuntimeError as e:
                    print("ERROR question ID: ", question["question_id"])
                    output = "ERROR"

                turns.append(output)
                idxs.append(int(idx))
                total_steps+=int(idx)
                new_tokens.append(int(new_token))
                total_new_tokens+=int(new_token)
                wall_time.append(total_time)
                all_time+=total_time
                conv.messages[-1][-1] = output
            # torch.cuda.empty_cache()
            choices.append({"index": i, "turns": turns, "idxs": idxs, "new_tokens": new_tokens, "wall_time": wall_time})



        # Dump answers
        os.makedirs(os.path.dirname(answer_file), exist_ok=True)
        with open(os.path.expanduser(answer_file), "a") as fout:
            ans_json = {
                "question_id": question["question_id"],
                "answer_id": shortuuid.uuid(),
                "model_id": model_id,
                "choices": choices,
                "tstamp": time.time(),
            }
            fout.write(json.dumps(ans_json) + "\n")

    print("total_steps:",total_steps," | total_new_tokens:",total_new_tokens," | total_time:",round(all_time,2)," | tokens per step:",round(total_new_tokens/total_steps,2)," | tokens per second:",round(total_new_tokens/all_time,2)," | avg_tree_depth:",round(total_tree_length_sum/total_steps,2))
    
    # 성능 통계 저장
    if output_file:
        save_performance_stats(timing_data, gpu_data, output_file, args)
    
    # GPU 모니터 정리
    if gpu_monitor:
        gpu_monitor.stop_monitoring()
        del gpu_monitor


def reorg_answer_file(answer_file):
    """Sort by question id and de-duplication"""
    answers = {}
    with open(answer_file, "r") as fin:
        for l in fin:
            qid = json.loads(l)["question_id"]
            answers[qid] = l

    qids = sorted(list(answers.keys()))
    with open(answer_file, "w") as fout:
        for qid in qids:
            fout.write(answers[qid])


if __name__ == "__main__":
    """Argument Parser + Run Evaluation"""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--draft-model-path",
        type=str,
        required=True,
        help="Path of target model.",
    )
    parser.add_argument("--base-model-path", type=str, required=True,help="Path of target model.")
    parser.add_argument(
        "--load-in-8bit", action="store_true", help="Use 8-bit quantization"
    )
    parser.add_argument("--model-id", type=str, default="llama-2-chat")
    parser.add_argument(
        "--bench-name",
        type=str,
        choices=["mt_bench","gsm8k"],
        help="The name of the benchmark question set.",
    )
    parser.add_argument(
        "--question-begin",
        type=int,
        help="A debug option. The begin index of questions.",
    )
    parser.add_argument(
        "--question-end", type=int, help="A debug option. The end index of questions."
    )
    parser.add_argument("--answer-file", type=str, help="The output answer file.")
    parser.add_argument(
        "--max-new-token",
        type=int,
        default=1024,
        help="The maximum number of new generated tokens.",
    )
    parser.add_argument(
        "--num-choices",
        type=int,
        default=1,
        help="How many completion choices to generate.",
    )
    parser.add_argument(
        "--num-gpus-per-model",
        type=int,
        default=1,
        help="The number of GPUs per model.",
    )
    parser.add_argument(
        "--num-gpus-total", type=int, default=1, help="The total number of GPUs."
    )
    parser.add_argument(
        "--max-gpu-memory",
        type=str,
        help="Maxmum GPU memory used for model weights per GPU.",
    )

    parser.add_argument(
        "--temperature",
        type=float,
        default=0,
    )

    #Draft tree config
    parser.add_argument(
        "--nodes", 
        type=int, 
        default=50,
        help="Number of nodes in draft trees.",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.5,
        help="Threshold should be less than 1.",
    )
    parser.add_argument(
        "--max_depth",
        type=int,
        default=10,
        help="Max depth of draft trees.",
    )
    
    # GPU 모니터링 관련 인수들
    parser.add_argument(
        "--enable-gpu-monitor",
        action="store_true",
        help="Enable GPU monitoring during evaluation"
    )
    parser.add_argument(
        "--gpu-monitor-interval",
        type=float,
        default=0.1,
        help="GPU monitoring interval in seconds"
    )
    parser.add_argument(
        "--output-file",
        type=str,
        help="Output file for performance statistics"
    )
    parser.add_argument(
        "--fix-gpu-clock",
        action="store_true",
        help="Fix GPU clock to specified values"
    )
    parser.add_argument(
        "--graphics-clock",
        type=int,
        help="Graphics clock frequency in MHz"
    )
    parser.add_argument(
        "--memory-clock",
        type=int,
        help="Memory clock frequency in MHz"
    )

    args = parser.parse_args()

    # GPU 클럭 고정 옵션 표시
    if args.fix_gpu_clock:
        print("="*60)
        print("[eval] GPU 클럭 고정 모드")
        print("="*60)
        available_clocks = get_available_gpu_clocks()
        if available_clocks:
            print("사용 가능한 GPU 클럭 조합 (처음 20개):")
            for i, clock in enumerate(available_clocks[:20]):
                print(f"  {i+1:2d}. Graphics: {clock['graphics_clock']:4d}MHz, Memory: {clock['memory_clock']:4d}MHz")
            if len(available_clocks) > 20:
                print(f"  ... 총 {len(available_clocks)}개 조합")
        else:
            print("사용 가능한 GPU 클럭 조합을 찾을 수 없습니다.")
        print("="*60)

    args.model_id = args.model_id + "-temperature-" + str(args.temperature)
    if args.num_gpus_total // args.num_gpus_per_model > 1:
        import ray

        ray.init()
    if args.bench_name=="mt_bench":
        question_file = f"{parent_dir}/data/mt_bench/question.jsonl"
    elif args.bench_name=="gsm8k":
        question_file = f"{parent_dir}/data/gsm8k.jsonl"
    else:
        raise ValueError("Undefined bench_name")

    print(f"Output to {args.answer_file}")

    run_eval(
        args.base_model_path,
        args.draft_model_path,
        args.model_id,
        question_file,
        args.question_begin,
        args.question_end,
        args.answer_file,
        args.max_new_token,
        args.num_choices,
        args.num_gpus_per_model,
        args.num_gpus_total,
        args.max_gpu_memory,
        args.temperature,
        args,
        args.enable_gpu_monitor,
        args.gpu_monitor_interval,
        args.output_file,
        args.fix_gpu_clock,
        args.graphics_clock,
        args.memory_clock,
    )

    reorg_answer_file(args.answer_file)
