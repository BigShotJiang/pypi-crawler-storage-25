import argparse
import json
import os
import socket
import struct
import threading
import time
from typing import List, Tuple

import torch
from transformers import AutoTokenizer

from opt_classic.kv_cache import initialize_past_key_values
from opt_classic.modeling_llama_kv import LlamaForCausalLM as KVLlamaForCausalLM
from opt_classic.utils import prepare_logits_processor, recv_json, send_json






class TargetWorker:
    def __init__(self, base_model_path: str, temperature: float, quantization: str = "4bit", int8_cpu_offload: bool = False, device_map: str = "auto"):
        # 메모리 분절 방지
        os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

        self.temperature = temperature
        self.logits_processor = prepare_logits_processor(temperature=temperature) if temperature > 1e-5 else None

        quantization_config = None
        if quantization == "8bit":
            from transformers import BitsAndBytesConfig
            quantization_config = BitsAndBytesConfig(
                load_in_8bit=True,
                llm_int8_threshold=6.0,
                llm_int8_skip_modules=["lm_head"],
                llm_int8_enable_fp32_cpu_offload=int8_cpu_offload,
            )
        elif quantization == "4bit":
            from transformers import BitsAndBytesConfig
            quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_use_double_quant=True,
            )

        self.base_model = KVLlamaForCausalLM.from_pretrained(
            base_model_path,
            torch_dtype=torch.float16,
            low_cpu_mem_usage=True,
            device_map=device_map,
            quantization_config=quantization_config,
            token="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",
            # token="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",
        )
        self.tokenizer = AutoTokenizer.from_pretrained(
            base_model_path,
            token="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",
            # token="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",
        )

        (
            self.past_key_values,
            self.past_key_values_data,
            self.current_length_data,
        ) = initialize_past_key_values(self.base_model)

    def reset_kv(self):
        self.current_length_data.zero_()

    @torch.inference_mode()
    def handle_init(self, input_ids: List[int]) -> int:
        self.reset_kv()
        ids = torch.tensor([input_ids]).to(self.base_model.lm_head.weight.device)
        outputs = self.base_model.model(
            input_ids=ids,
            past_key_values=self.past_key_values,
        )
        logits = self.base_model.lm_head(outputs[0])
        if self.logits_processor is not None:
            last_logits = logits[:, -1]
            last_logits = self.logits_processor(None, last_logits)
            probs = torch.nn.functional.softmax(last_logits, dim=1)
            next_token = torch.multinomial(probs, 1).item()
        else:
            next_token = torch.argmax(logits[:, -1]).item()
        return next_token

    def _compute_logits(self, draft: torch.Tensor, position_ids: torch.Tensor, tree_mask: torch.Tensor) -> torch.Tensor:
        outputs = self.base_model.model(
            input_ids=draft,
            tree_attention_mask=tree_mask,
            past_key_values=self.past_key_values,
            position_ids=position_ids,
        )
        logits = self.base_model.lm_head(outputs[0])
        return logits

    @torch.inference_mode()
    def handle_tree_step(
        self,
        draft_input_ids: List[int],
        draft_position_ids: List[int],
        tree_attention_mask: List[List[int]],
        parent: List[int],
    ) -> Tuple[List[int], int, int, bool]:
        device = self.base_model.lm_head.weight.device

        draft = torch.tensor([draft_input_ids], device=device, dtype=torch.long)
        position_ids = torch.tensor(draft_position_ids, device=device, dtype=torch.long)
        tree_mask = torch.tensor(tree_attention_mask, device=device, dtype=torch.int8)
        parent_t = torch.tensor(parent, device=device, dtype=torch.long)

        logits = self._compute_logits(draft, position_ids, tree_mask)

        # verify (without calling model.draft)
        if self.logits_processor is None:
            next_tok = torch.argmax(logits, dim=-1)
        else:
            proc_logits = self.logits_processor(None, logits)
            probabilities = torch.nn.functional.softmax(proc_logits, dim=-1)[0]
            next_tok = torch.multinomial(probabilities, 1).view(1, -1)
        next_tok = next_tok.to(draft.device)

        parent_work = torch.where(parent_t == torch.arange(parent_t.size(0), device=parent_t.device), -1, parent_t)
        parent_work = torch.cat([torch.tensor([0], device=parent_t.device), parent_work + 1], dim=-1).to(draft.device)

        correct = torch.where(draft[0] != next_tok[0][parent_work], 0, torch.ones(draft.size(1), device=draft.device))
        correct[0] = 1
        last_sum = torch.sum(correct)
        while True:
            correct = torch.where(correct[parent_work] == 0, 0, correct)
            if torch.sum(correct) == last_sum:
                break
            else:
                last_sum = torch.sum(correct)

        id_t_tensor = torch.argmax(correct * position_ids)
        id_t = int(id_t_tensor.item())
        best_candidate: List[int] = []
        best_ids: List[int] = []
        max_id = id_t
        parent_work[0] = -1
        while id_t != -1:
            token_val = int(draft[0][id_t].item())
            best_candidate.append(token_val)
            best_ids.append(id_t)
            id_t = int(parent_work[id_t].item())

        best_candidate.reverse()
        best_ids.reverse()
        next_token = int(next_tok[0][max_id].item())
        accept_length = len(best_candidate) - 1

        start = int(self.current_length_data[0].item() - draft.size(1))
        select_indices = (torch.tensor(best_ids, device=device) + start).to(device)

        for data in self.past_key_values_data:
            tgt = data[..., select_indices.to(data.device), :]
            dst = data[..., start: start + tgt.shape[-2], :]
            dst.copy_(tgt, non_blocking=True)
        self.current_length_data.fill_(start + tgt.shape[-2])

        eos_id = self.tokenizer.eos_token_id
        eos_reached = eos_id in best_candidate[1:] if len(best_candidate) > 1 else False

        return best_candidate, accept_length, next_token, eos_reached, best_ids


def serve(host: str, port: int, base_model_path: str, temperature: float, quantization: str, int8_cpu_offload: bool, device_map: str):
    worker = TargetWorker(
        base_model_path=base_model_path,
        temperature=temperature,
        quantization=quantization,
        int8_cpu_offload=int8_cpu_offload,
        device_map=device_map,
    )

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
        s.listen(1)
        print(f"[target] listening on {host}:{port}")
        conn, addr = s.accept()
        with conn:
            print(f"[target] connection from {addr}")
            try:
                while True:
                    msg = recv_json(conn)
                    mtype = msg.get("type")
                    if mtype == "init":
                        input_ids = msg["input_ids"]
                        next_token = worker.handle_init(input_ids)
                        send_json(conn, {"type": "init_ok", "next_token": next_token})
                    elif mtype == "tree_step":
                        best_candidate, accept_length, next_token, eos_reached, best_ids = worker.handle_tree_step(
                            msg["draft_input_ids"],
                            msg["draft_position_ids"],
                            msg["tree_attention_mask"],
                            msg["parent"],
                        )
                        send_json(conn, {
                            "type": "verify_result",
                            "accepted_tokens": best_candidate,
                            "accept_length": accept_length,
                            "next_token": next_token,
                            "eos_reached": eos_reached,
                            "best_ids": best_ids,
                        })
                    elif mtype == "shutdown":
                        send_json(conn, {"type": "bye"})
                        break
                    else:
                        send_json(conn, {"type": "error", "message": f"unknown type {mtype}"})
                        break
            except ConnectionError:
                print("[target] client disconnected")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", type=str, default="127.0.0.1")
    parser.add_argument("--port", type=int, default=26001)
    parser.add_argument("--base-model-path", type=str, required=True)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--load-in-8bit", action="store_true")
    parser.add_argument("--load-in-4bit", action="store_true")
    parser.add_argument("--int8-cpu-offload", action="store_true")
    parser.add_argument("--device-map", type=str, default="auto")
    args = parser.parse_args()
    quantization = "none"
    if args.load_in_8bit:
        quantization = "8bit"
    elif args.load_in_4bit or not args.load_in_8bit:
        # 기본값: 4bit (메모리 절약)
        quantization = "4bit"

    serve(
        args.host,
        args.port,
        args.base_model_path,
        args.temperature,
        quantization,
        args.int8_cpu_offload,
        args.device_map,
    )