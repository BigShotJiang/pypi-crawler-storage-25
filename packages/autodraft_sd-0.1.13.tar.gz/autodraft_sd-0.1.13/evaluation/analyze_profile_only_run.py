#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from typing import Any, Dict, List

import matplotlib.pyplot as plt
import numpy as np


def _load_summary(summary_path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for line in summary_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        rows.append(json.loads(line))
    return rows


def _mono(values: List[float]) -> Any:
    valid = [v for v in values if np.isfinite(v)]
    if len(valid) < 2:
        return None
    return all(valid[i] <= valid[i + 1] for i in range(len(valid) - 1))


def _sanitize_key_component(component: str) -> str:
    return str(component).strip().lower().replace("/", "_").replace(" ", "_")


def _resolve_target_profile_path(report: Dict[str, Any], profile_dir: Path) -> Path:
    requested = Path(str(report.get("target_profile_file", "")))
    if str(requested) and requested.exists():
        return requested
    server_name = _sanitize_key_component(str(report.get("server_name", "target")))
    base_model = str(report.get("base_model_path", ""))
    model_name = base_model.split("/")[-1] if "/" in base_model else base_model
    model_key = _sanitize_key_component(model_name)
    candidates = sorted(
        profile_dir.glob(f"profile_target_{server_name}_{model_key}_tq-*.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if candidates:
        return candidates[0]
    return requested


def _plot_panel(records: List[Dict[str, Any]], key: str, ylabel: str, title: str, out_path: Path) -> None:
    fig, axes = plt.subplots(2, 5, figsize=(24, 9), constrained_layout=True)
    axes = axes.ravel()
    for i, rec in enumerate(records):
        ax = axes[i]
        short = rec["model"].split("/")[-1]
        if rec["return_code"] != 0:
            ax.text(0.5, 0.5, "FAILED RUN", ha="center", va="center", color="red", fontsize=11)
            ax.set_title(f"{short}\nrun failed", fontsize=9)
            ax.grid(True, alpha=0.2)
            ax.set_xlabel("width")
            ax.set_ylabel(ylabel)
            continue
        x = rec.get("widths", [])
        y = rec.get(key, [])
        if x and y:
            ax.plot(x, y, marker="o", linewidth=1.5)
            mono = rec.get(f"{key}_mono")
            mono_txt = "MONO" if mono is True else ("NON-MONO" if mono is False else "N/A")
            q = rec.get("quant", "unknown")
            ax.set_title(f"{short}\n{q}|{mono_txt}", fontsize=9)
            ax.grid(True, alpha=0.25)
        else:
            ax.text(0.5, 0.5, "NO PROFILE", ha="center", va="center", color="red", fontsize=11)
            ax.set_title(f"{short}\nmissing", fontsize=9)
            ax.grid(True, alpha=0.2)
        ax.set_xlabel("width")
        ax.set_ylabel(ylabel)
    fig.suptitle(title, fontsize=14)
    fig.savefig(out_path, dpi=180)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", required=True, type=str)
    parser.add_argument("--repo-root", default="/home/icnlpj/Desktop/MobiTree", type=str)
    args = parser.parse_args()

    repo = Path(args.repo_root)
    run_root = repo / "result/profile_only_ui_models" / f"profile_only_ui_models_{args.run_id}"
    summary_path = run_root / "summary.jsonl"
    reports_dir = run_root / "reports"
    profile_dir = repo / "data" / "profile"
    out_dir = repo / "result/monotonicity_plots"
    out_dir.mkdir(parents=True, exist_ok=True)

    rows = _load_summary(summary_path)
    row_by_model = {r["draft_model_path"]: r for r in rows}

    display_order = [
        "meta-llama/Llama-2-7b-chat-hf",
        "meta-llama/Llama-3.2-1B-Instruct",
        "meta-llama/Llama-3.2-3B-Instruct",
        "meta-llama/Llama-3.1-8B-Instruct",
        "Qwen/Qwen2.5-0.5B-Instruct",
        "Qwen/Qwen2.5-1.5B-Instruct",
        "Qwen/Qwen2.5-3B-Instruct",
        "Qwen/Qwen2.5-7B-Instruct",
        "Qwen/Qwen3-0.6B",
        "Qwen/Qwen3-1.7B",
    ]

    records: List[Dict[str, Any]] = []
    for model in display_order:
        rec: Dict[str, Any] = {
            "model": model,
            "return_code": 1,
            "widths": [],
            "lat": [],
            "energy": [],
            "util": [],
            "gclk": [],
            "mclk": [],
            "missing_summary": None,
            "quant": None,
        }
        row = row_by_model.get(model)
        if row is None:
            records.append(rec)
            continue
        rec["return_code"] = int(row.get("return_code", 1))
        report_path = Path(row.get("report_json", ""))
        if report_path.exists():
            report = json.loads(report_path.read_text(encoding="utf-8"))
            rec["quant"] = report.get("draft_quantization")
            rec["missing_summary"] = report.get("draft_gpu_metric_missing_summary")
            prof = report.get("draft_profile_file")
            if prof and Path(prof).exists() and rec["return_code"] == 0:
                pdata = json.loads(Path(prof).read_text(encoding="utf-8"))
                widths = sorted([int(k) for k in pdata.keys() if str(k).isdigit()])
                rec["widths"] = widths
                for w in widths:
                    row_w = pdata.get(str(w), {})
                    rec["lat"].append(float(row_w.get("model_call_avg_time_ms", float("nan"))))
                    rec["energy"].append(float(row_w.get("gpu_energy_per_call_kwh", float("nan"))))
                    rec["util"].append(float(row_w.get("gpu_util_avg_percent", float("nan"))))
                    rec["gclk"].append(float(row_w.get("gpu_graphics_clock_avg_mhz", float("nan"))))
                    rec["mclk"].append(float(row_w.get("gpu_memory_clock_avg_mhz", float("nan"))))
                rec["lat_mono"] = _mono(rec["lat"])
                rec["energy_mono"] = _mono(rec["energy"])
                rec["util_mono"] = _mono(rec["util"])
                rec["gclk_mono"] = _mono(rec["gclk"])
                rec["mclk_mono"] = _mono(rec["mclk"])
        records.append(rec)

    # Panel plots
    _plot_panel(
        records,
        "lat",
        "model_call_avg_time_ms",
        f"Latency vs width (run={args.run_id})",
        out_dir / f"draft_profile_width_latency_10panel_{args.run_id}.png",
    )
    _plot_panel(
        records,
        "energy",
        "gpu_energy_per_call_kwh",
        f"Energy vs width (run={args.run_id})",
        out_dir / f"draft_profile_width_energy_10panel_{args.run_id}.png",
    )
    _plot_panel(
        records,
        "util",
        "gpu_util_avg_percent",
        f"GPU utilization vs width (run={args.run_id})",
        out_dir / f"draft_profile_width_util_10panel_{args.run_id}.png",
    )
    _plot_panel(
        records,
        "gclk",
        "gpu_graphics_clock_avg_mhz",
        f"Graphics clock vs width (run={args.run_id})",
        out_dir / f"draft_profile_width_gclk_10panel_{args.run_id}.png",
    )
    _plot_panel(
        records,
        "mclk",
        "gpu_memory_clock_avg_mhz",
        f"Memory clock vs width (run={args.run_id})",
        out_dir / f"draft_profile_width_mclk_10panel_{args.run_id}.png",
    )

    # Missing ratio bar chart (0%도 보이도록 baseline/annotate)
    labels: List[str] = []
    pvals: List[float] = []
    uvals: List[float] = []
    gvals: List[float] = []
    mvals: List[float] = []
    for r in records:
        ms = r.get("missing_summary")
        if isinstance(ms, dict) and ms.get("available"):
            labels.append(r["model"].split("/")[-1][:18])
            pvals.append(float(ms.get("power_missing_percent", 0.0) or 0.0))
            uvals.append(float(ms.get("util_missing_percent", 0.0) or 0.0))
            gvals.append(float(ms.get("graphics_clock_missing_percent", 0.0) or 0.0))
            mvals.append(float(ms.get("memory_clock_missing_percent", 0.0) or 0.0))
    if labels:
        x = np.arange(len(labels))
        w = 0.2
        fig, ax = plt.subplots(figsize=(16, 5), constrained_layout=True)
        b1 = ax.bar(x - 1.5 * w, pvals, width=w, label="power")
        b2 = ax.bar(x - 0.5 * w, uvals, width=w, label="util")
        b3 = ax.bar(x + 0.5 * w, gvals, width=w, label="gclk")
        b4 = ax.bar(x + 1.5 * w, mvals, width=w, label="mclk")
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=25, ha="right")
        ax.set_ylabel("missing percent (%)")
        ax.set_ylim(0.0, max(1.0, max(pvals + uvals + gvals + mvals) + 0.5))
        ax.set_title(f"GPU metric missing percent by model (run={args.run_id})")
        ax.grid(True, axis="y", alpha=0.25)
        ax.legend()
        for bars in [b1, b2, b3, b4]:
            for bar in bars:
                h = bar.get_height()
                ax.annotate(f"{h:.1f}", (bar.get_x() + bar.get_width() / 2, h),
                            textcoords="offset points", xytext=(0, 3), ha="center", fontsize=7)
        fig.savefig(out_dir / f"draft_profile_gpu_missing_percent_{args.run_id}.png", dpi=180)
        plt.close(fig)

    # Dashboard
    succ = sum(1 for r in records if r.get("return_code") == 0)
    fail = sum(1 for r in records if r.get("return_code") != 0)
    lat_true = sum(1 for r in records if r.get("lat_mono") is True)
    lat_false = sum(1 for r in records if r.get("lat_mono") is False)
    eng_true = sum(1 for r in records if r.get("energy_mono") is True)
    eng_false = sum(1 for r in records if r.get("energy_mono") is False)
    util_true = sum(1 for r in records if r.get("util_mono") is True)
    util_false = sum(1 for r in records if r.get("util_mono") is False)
    gclk_true = sum(1 for r in records if r.get("gclk_mono") is True)
    mclk_true = sum(1 for r in records if r.get("mclk_mono") is True)

    fig, axes = plt.subplots(1, 3, figsize=(14, 4), constrained_layout=True)
    axes[0].bar(["success", "failed"], [succ, fail], color=["#2ca02c", "#d62728"])
    axes[0].set_title("Run success")
    axes[0].grid(True, axis="y", alpha=0.25)

    axes[1].bar(["lat_mono", "lat_non", "eng_mono", "eng_non"], [lat_true, lat_false, eng_true, eng_false])
    axes[1].set_title("Monotonicity count")
    axes[1].grid(True, axis="y", alpha=0.25)

    axes[2].bar(["util_mono", "util_non", "gclk_mono", "mclk_mono"], [util_true, util_false, gclk_true, mclk_true])
    axes[2].set_title("Util/Clock stability")
    axes[2].grid(True, axis="y", alpha=0.25)

    fig.savefig(out_dir / f"draft_profile_dashboard_{args.run_id}.png", dpi=180)
    plt.close(fig)

    out_json = out_dir / f"draft_profile_analysis_{args.run_id}.json"
    out_json.write_text(json.dumps({"run_id": args.run_id, "records": records}, indent=2), encoding="utf-8")
    print(str(out_json))

    # Target profile 7-panel (use fallback path if requested target_profile_file is missing)
    target_order = [
        "meta-llama/Llama-2-70b-chat-hf",
        "meta-llama/Llama-3.3-70B-Instruct",
        "Qwen/Qwen2.5-14B-Instruct",
        "Qwen/Qwen2.5-32B-Instruct",
        "Qwen/Qwen2.5-72B-Instruct",
        "Qwen/Qwen3-14B",
        "Qwen/Qwen3-32B",
    ]
    target_reports: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        report_path = Path(str(row.get("report_json", "")))
        if not report_path.exists():
            continue
        report = json.loads(report_path.read_text(encoding="utf-8"))
        target_key = str(report.get("base_model_path", ""))
        if target_key and target_key not in target_reports:
            target_reports[target_key] = report
    target_records: List[Dict[str, Any]] = []
    for target in target_order:
        rec: Dict[str, Any] = {
            "target": target,
            "target_profile_file": "",
            "exists": False,
            "nodes": [],
            "avg_verif_ms": [],
            "mono": None,
            "target_quantization": None,
        }
        report = target_reports.get(target)
        if report is not None:
            rec["target_quantization"] = report.get("target_quantization")
            resolved = _resolve_target_profile_path(report, profile_dir)
            rec["target_profile_file"] = str(resolved)
            if resolved.exists():
                pdata = json.loads(resolved.read_text(encoding="utf-8"))
                pairs: List[tuple[int, float]] = []
                for k, row_data in pdata.items():
                    if (not str(k).startswith("nnodes_")) or (not isinstance(row_data, dict)):
                        continue
                    try:
                        n = int(row_data.get("max_nnodes", str(k).split("_")[-1]))
                        t = float(row_data.get("avg_verification_time_ms", np.nan))
                    except Exception:
                        continue
                    if np.isfinite(t):
                        pairs.append((n, t))
                pairs = sorted(pairs, key=lambda x: x[0])
                if pairs:
                    rec["exists"] = True
                    rec["nodes"] = [x[0] for x in pairs]
                    rec["avg_verif_ms"] = [x[1] for x in pairs]
                    rec["mono"] = _mono(rec["avg_verif_ms"])
        target_records.append(rec)

    fig, axes = plt.subplots(2, 4, figsize=(22, 10), constrained_layout=True)
    axes = axes.ravel()
    for i, rec in enumerate(target_records):
        ax = axes[i]
        short = rec["target"].split("/")[-1]
        q = rec.get("target_quantization") or "unknown"
        if rec["exists"] and rec["nodes"]:
            ax.plot(rec["nodes"], rec["avg_verif_ms"], marker="o", linewidth=1.5)
            mono = rec.get("mono")
            mono_txt = "MONO" if mono is True else ("NON-MONO" if mono is False else "N/A")
            ax.set_title(f"{short}\nq={q}|{mono_txt}", fontsize=9)
        else:
            ax.text(0.5, 0.5, "NO TARGET PROFILE", ha="center", va="center", color="red", fontsize=11)
            ax.set_title(f"{short}\nq={q}|missing", fontsize=9)
        ax.set_xlabel("nnodes")
        ax.set_ylabel("avg_verification_time_ms")
        ax.grid(True, alpha=0.25)
    if len(target_records) < len(axes):
        for j in range(len(target_records), len(axes)):
            axes[j].axis("off")
    fig.suptitle(f"Target profile monotonicity (run={args.run_id})", fontsize=14)
    target_plot_path = out_dir / f"target_profile_nodes_monotonicity_expected_7panel_{args.run_id}.png"
    fig.savefig(target_plot_path, dpi=180)
    plt.close(fig)
    target_json = out_dir / f"target_profile_analysis_{args.run_id}.json"
    target_json.write_text(
        json.dumps({"run_id": args.run_id, "records": target_records}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(str(target_plot_path))
    print(str(target_json))


if __name__ == "__main__":
    main()

