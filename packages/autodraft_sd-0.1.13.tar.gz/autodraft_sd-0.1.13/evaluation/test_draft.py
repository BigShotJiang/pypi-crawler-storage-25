import argparse
import json
import os
import socket
import time
from typing import List, Tuple

import torch
from fastchat.llm_judge.common import load_questions
from fastchat.model import get_conversation_template
from transformers import AutoTokenizer
from tqdm import tqdm

from opt_classic.utils import prepare_logits_processor, recv_json, send_json
from opt_classic.modeling_llama_kv import LlamaForCausalLM as KVLlamaForCausalLM
from opt_classic.tree import Tree






class DraftRunner:
    def __init__(self, draft_model: KVLlamaForCausalLM, tokenizer: AutoTokenizer):
        self.draft_model = draft_model
        self.tokenizer = tokenizer
        # Draft는 tree 확장 때문에 stable KV 방식 사용
        self.draft_stable_kv = None
    
    def reset_kv(self):
        """KV cache 리셋"""
        self.draft_stable_kv = None

    def process_tree_mask(self, tree_attention_mask: torch.Tensor, init_len: int) -> torch.Tensor:
        attention_mask = torch.full((tree_attention_mask.size(0), init_len), 0, device=tree_attention_mask.device)
        tree_mask = torch.where(tree_attention_mask == 0, torch.finfo(torch.float32).min, 0)
        attention_mask = torch.cat([attention_mask, tree_mask], dim=-1)
        attention_mask = attention_mask[None, None, :, :]
        return attention_mask

    @torch.no_grad()
    def draft(self, input_ids: torch.Tensor, nodes: int, threshold: float, max_depth: int, print_time: bool = False, print_tree: bool = False):
        # breakpoint()
        device = self.draft_model.lm_head.weight.device
        len_posi = input_ids.shape[1] - 1
        
        # Stable KV 방식: 이전 KV가 있으면 새 토큰만 계산
        if self.draft_stable_kv is not None:
            kv_len = self.draft_stable_kv[0][0].shape[2]
            new_tokens = input_ids[:, kv_len:].to(device)
            seq_len = new_tokens.shape[1]
            if seq_len == 0:
                raise RuntimeError("DraftRunner.draft received empty new_tokens after KV slicing")
            pos_ids = torch.arange(kv_len, kv_len + seq_len, device=device, dtype=torch.long)
            draft_outputs = self.draft_model.model(
                input_ids=new_tokens,
                past_key_values=self.draft_stable_kv,
                position_ids=pos_ids,
                return_kv=True,
                is_draft=True,
            )
        else:
            # 처음이거나 리셋 후
            full = input_ids.to(device)
            seq_len = full.shape[1]
            if seq_len == 0:
                raise RuntimeError("DraftRunner.draft received empty input_ids on initial call")
            pos_ids = torch.arange(0, seq_len, device=device, dtype=torch.long)
            draft_outputs = self.draft_model.model(
                input_ids=full,
                position_ids=pos_ids,
                return_kv=True,
                is_draft=True,
            )
        
        # Base KV 저장 (tree 확장 전)
        self.draft_stable_kv = draft_outputs[1]
        past_key_values = self.draft_stable_kv
        init_len = past_key_values[0][0].size(2)
        
        last_hidden = draft_outputs[0][:, -1]
        last_headout = self.draft_model.lm_head(last_hidden)

        tree = Tree(nodes, last_hidden.device, threshold, max_depth)

        logits = last_headout.unsqueeze(0)
        end = False
        while not end:
            tree_output = tree.update(torch.softmax(logits.to(last_hidden.device), dim=-1, dtype=torch.float32))
            input_ids_step = tree_output["input_ids"].unsqueeze(0)
            position_ids = tree_output["position_ids"] + len_posi   # [DH] 상대적 index(트리에서 몇 번째 인지) -> 절대적 index로 변환 (전체 input_ids에서 몇 번째인지)
            if tree_output["is_final"]:
                break
            tree_attention_mask_with_kv = self.process_tree_mask(tree_output["attention_mask"], init_len)
            draft_outputs = self.draft_model.model(
                input_ids=input_ids_step,
                position_ids=position_ids,
                past_key_values=past_key_values,
                tree_attention_mask=tree_attention_mask_with_kv,
                return_kv=True,
                is_draft=True,
            )
            # Tree 확장 후 KV 업데이트 (local variable)
            past_key_values = draft_outputs[1]
            
            last_hidden = draft_outputs[0]
            last_headout = self.draft_model.lm_head(last_hidden)
            logits = last_headout

        # Tree KV 반환 (accept 처리용)
        return input_ids_step, position_ids, tree_output["attention_mask"], tree_output["parent_last"], tree.depth, past_key_values


@torch.inference_mode()
def build_tree_with_next_token(
    runner: DraftRunner,
    input_ids: torch.Tensor,
    nodes: int,
    threshold: float,
    max_depth: int,
    next_token_id: int,
    tokenizer: AutoTokenizer,
):
    # breakpoint()
    # KV cache 길이 체크 및 동기화
    if runner.draft_stable_kv is not None:
        kv_len = runner.draft_stable_kv[0][0].shape[2]
        if kv_len != input_ids.shape[1]:
            # 불일치 시 리셋하여 안전하게 처리
            runner.draft_stable_kv = None
    
    next_token = torch.tensor([[next_token_id]], device=input_ids.device, dtype=torch.long)
    cat_input = torch.cat((input_ids, next_token), dim=1)
    draft_input_ids, draft_position_ids, tree_attention_mask, parent, tree_depth, tree_kv = runner.draft(
        cat_input,
        nodes,
        threshold,
        max_depth,
    )

    draft_input_ids = torch.cat([next_token, draft_input_ids], dim=-1)
    head_pos = torch.tensor([cat_input.shape[1]-1], device=draft_position_ids.device)
    draft_position_ids = torch.cat([head_pos, draft_position_ids], dim=-1)
    tree_attention_mask = torch.cat(
        [torch.zeros(1, tree_attention_mask.size(1), dtype=tree_attention_mask.dtype, device=tree_attention_mask.device), tree_attention_mask],
        dim=0,
    )
    tree_attention_mask = torch.cat(
        [torch.ones(tree_attention_mask.size(0), 1, dtype=tree_attention_mask.dtype, device=tree_attention_mask.device), tree_attention_mask],
        dim=1,
    )

    return draft_input_ids, draft_position_ids, tree_attention_mask, parent, tree_depth, tree_kv


def update_kv_with_accepted(runner: DraftRunner, tree_kv, best_ids: List[int], base_kv_len: int):
    """
    Accept된 경로의 KV만 추출하여 draft_stable_kv에 저장
    
    Args:
        runner: DraftRunner
        tree_kv: Tree 확장 후의 전체 KV (튜플)
        best_ids: Target이 계산한 accept된 경로의 tree 내 인덱스들
        base_kv_len: Base KV 길이 (input_ids_t.shape[1])
    """
    if len(best_ids) == 0:
        return
    
    device = runner.draft_model.lm_head.weight.device
    
    # tree_kv의 구조:
    # draft() Line 89에서 self.draft_stable_kv = [old_input_ids + next_token]
    # tree_kv = [old_input_ids + next_token + tree_nodes]
    # 
    # best_ids는 draft_input_ids 내 인덱스 (0: next_token, 1~: tree nodes)
    # tree_kv 내 실제 인덱스 = base_kv_len + best_ids
    # 왜냐하면 tree_kv[:base_kv_len] = old_input_ids
    #           tree_kv[base_kv_len] = next_token
    #           tree_kv[base_kv_len+1:] = tree_nodes
    
    select_indices = torch.tensor(best_ids, device=device) + base_kv_len
    # breakpoint()
    
    # 인덱스 범위 검증
    min_index = select_indices.min().item()
    max_index = select_indices.max().item()
    tree_kv_len = tree_kv[0][0].shape[2]
    
    if min_index < 0 or max_index >= tree_kv_len:
        print(f"WARNING: Index range [{min_index}, {max_index}] out of bounds [0, {tree_kv_len}), resetting KV")
        runner.draft_stable_kv = None
        return
    
    # tree_kv에서 accept된 토큰들의 KV 추출
    selected_kv = []
    for layer_kv in tree_kv:
        key, value = layer_kv
        selected_key = key[:, :, select_indices, :]
        selected_value = value[:, :, select_indices, :]
        selected_kv.append((selected_key, selected_value))
    
    # runner.draft_stable_kv가 있으면 base와 결합
    # 주의: runner.draft_stable_kv는 Line 89에서 next_token을 포함하여 업데이트됨
    # 하지만 우리는 input_ids_t와 동기화를 위해 next_token을 제외하고 저장해야 함
    if runner.draft_stable_kv is not None:
        # runner.draft_stable_kv = [old_input_ids + next_token]
        # 우리가 저장할 것 = [old_input_ids + accepted_tokens (next_token 포함)]
        # 하지만 input_ids_t는 아직 accepted_tokens만 추가된 상태
        # 따라서 next_token을 제거해야 함
        
        new_kv = []
        for i, (selected_key, selected_value) in enumerate(selected_kv):
            base_key = runner.draft_stable_kv[i][0]
            base_value = runner.draft_stable_kv[i][1]
            
            # base의 마지막(next_token) 제거 후 selected와 결합
            # selected[0]이 next_token이므로, 최종적으로 next_token이 한 번만 포함됨
            base_key_without_last = base_key[:, :, :-1, :]
            base_value_without_last = base_value[:, :, :-1, :]
            
            new_key = torch.cat([base_key_without_last, selected_key], dim=2)
            new_value = torch.cat([base_value_without_last, selected_value], dim=2)
            new_kv.append((new_key, new_value))
        
        # 최종 저장: [old_input_ids + accepted_tokens (next_token 포함)]
        # 길이 = base_kv_len + len(accepted_tokens)
        runner.draft_stable_kv = tuple(new_kv)
    else:
        # 첫 라운드: selected_kv를 그대로 저장
        runner.draft_stable_kv = tuple(selected_kv)


def run_draft(
    host: str,
    port: int,
    base_model_path: str,
    draft_model_path: str,
    bench_name: str,
    question_file: str,
    temperature: float,
    nodes: int,
    threshold: float,
    max_depth: int,
    device_map: str,
    load_in_4bit: bool,
    load_in_8bit: bool,
):
    # 드래프트 모델만 로드
    quantization_config = None
    if load_in_8bit:
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_8bit=True,
            llm_int8_threshold=6.0,
            llm_int8_skip_modules=["lm_head"],
        )
    elif load_in_4bit:
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
        )

    draft_model = KVLlamaForCausalLM.from_pretrained(
        draft_model_path,
        torch_dtype=torch.float16,
        low_cpu_mem_usage=True,
        device_map=device_map,
        quantization_config=quantization_config,
        token="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",
        # token="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",
    )
    tokenizer = AutoTokenizer.from_pretrained(base_model_path)
    runner = DraftRunner(draft_model=draft_model, tokenizer=tokenizer)

    if temperature > 1e-5:
        logits_processor = prepare_logits_processor(temperature=temperature)
    else:
        logits_processor = None

    with socket.create_connection((host, port)) as sock:
        questions = load_questions(question_file, None, None)

        # Warmup (3회) - 첫 질문으로 파이프라인 예열
        for _ in range(3):
            torch.manual_seed(0)
            # Warmup마다 KV cache 리셋
            runner.reset_kv()
            warm_q = questions[0]
            if "vicuna" in base_model_path:
                conv = get_conversation_template("vicuna")
            else:
                conv = get_conversation_template("llama-2-chat")
                sys_p = (
                    "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  "
                    "Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. "
                    "Please ensure that your responses are socially unbiased and positive in nature. If a question does not make any sense, "
                    "or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, "
                    "please don't share false information."
                )
                conv.system_message = sys_p
            # breakpoint()
            warm_turns = [warm_q["question"]] if bench_name == "gsm8k" else warm_q["turns"]
            conv.append_message(conv.roles[0], warm_turns[0])
            conv.append_message(conv.roles[1], None)
            prompt = conv.get_prompt() + " "
            input_ids = tokenizer([prompt]).input_ids
            input_ids_t = torch.as_tensor(input_ids).to("cuda")

            send_json(sock, {"type": "init", "input_ids": input_ids[0]})
            reply = recv_json(sock)
            if reply.get("type") != "init_ok":
                break
            current_next_token = reply["next_token"]

            warm_steps = 0
            while True:
                draft_ids, draft_pos, tree_mask, parent, tree_depth, tree_kv = build_tree_with_next_token(
                    runner, input_ids_t, nodes, threshold, max_depth, current_next_token, tokenizer
                )
                payload = {
                    "type": "tree_step",
                    "draft_input_ids": draft_ids[0].tolist(),
                    "draft_position_ids": draft_pos.tolist(),
                    "tree_attention_mask": tree_mask.tolist(),
                    "parent": parent.tolist(),
                }
                send_json(sock, payload)
                reply = recv_json(sock)
                if reply.get("type") != "verify_result":
                    break
                accepted_tokens: List[int] = reply["accepted_tokens"]
                current_next_token = reply["next_token"]
                eos_reached: bool = reply["eos_reached"]
                best_ids: List[int] = reply["best_ids"]
                
                # Accept된 경로의 KV만 유지
                base_kv_len = input_ids_t.shape[1]
                update_kv_with_accepted(runner, tree_kv, best_ids, base_kv_len)
                # print(runner.draft_stable_kv[0][0].shape[2])
                
                input_ids_t = torch.cat([
                    input_ids_t,
                    torch.tensor([accepted_tokens], device=input_ids_t.device, dtype=torch.long),
                ], dim=-1)
                
                warm_steps += 1
                if eos_reached or warm_steps > 5 or input_ids_t.shape[1] > 512:
                    break

        print("Warmup done")

        grand_total_steps = 0
        grand_total_accepted = 0
        grand_total_draft_tokens = 0

        for question in tqdm(questions):
            # 각 question마다 KV cache 리셋
            runner.reset_kv()
            
            # 대화 템플릿 준비
            if "vicuna" in base_model_path:
                conv = get_conversation_template("vicuna")
            else:
                conv = get_conversation_template("llama-2-chat")
                sys_p = (
                    "You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  "
                    "Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. "
                    "Please ensure that your responses are socially unbiased and positive in nature. If a question does not make any sense, "
                    "or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, "
                    "please don't share false information."
                )
                conv.system_message = sys_p

            if bench_name == "gsm8k":
                question_turns = [question["question"]]
            else:
                question_turns = question["turns"]

            qs = question_turns[0]
            conv.append_message(conv.roles[0], qs)
            conv.append_message(conv.roles[1], None)
            prompt = conv.get_prompt() + " "
            input_ids = tokenizer([prompt]).input_ids
            input_ids_t = torch.as_tensor(input_ids).to("cuda")

            # 초기 base 토큰 1개는 target에게 요청
            send_json(sock, {"type": "init", "input_ids": input_ids[0]})
            reply = recv_json(sock)
            assert reply.get("type") == "init_ok"
            current_next_token = reply["next_token"]

            output_tokens: List[int] = []
            new_token_count = 0
            total_steps = 0

            while True:
                # 드래프트 트리 생성 (타겟이 보낸 next_token을 사용)
                draft_ids, draft_pos, tree_mask, parent, tree_depth, tree_kv = build_tree_with_next_token(
                    runner, input_ids_t, nodes, threshold, max_depth, current_next_token, tokenizer
                )
                # target에게 검증 요청
                payload = {
                    "type": "tree_step",
                    "draft_input_ids": draft_ids[0].tolist(),
                    "draft_position_ids": draft_pos.tolist(),
                    "tree_attention_mask": tree_mask.tolist(),
                    "parent": parent.tolist(),
                }
                send_json(sock, payload)

                reply = recv_json(sock)
                assert reply.get("type") == "verify_result"
                accepted_tokens: List[int] = reply["accepted_tokens"]
                accept_length: int = reply["accept_length"]
                next_token: int = reply["next_token"]
                eos_reached: bool = reply["eos_reached"]
                best_ids: List[int] = reply["best_ids"]

                # Accept된 경로의 KV만 유지
                base_kv_len = input_ids_t.shape[1]
                update_kv_with_accepted(runner, tree_kv, best_ids, base_kv_len)

                # 수락된 토큰들을 입력에 붙임
                input_ids_t = torch.cat([
                    input_ids_t,
                    torch.tensor([accepted_tokens], device=input_ids_t.device, dtype=torch.long),
                ], dim=-1)

                output_tokens.extend(accepted_tokens)
                new_token_count += accept_length + 1
                total_steps += 1

                # 통계 누적
                grand_total_steps += 1
                grand_total_accepted += accept_length
                grand_total_draft_tokens += int(tree_depth)

                # 다음 라운드를 위해 최신 next_token 저장
                current_next_token = next_token

                if eos_reached or new_token_count > 1024 or input_ids_t.shape[1] > 1960:
                    break

            decoded = tokenizer.decode(output_tokens, spaces_between_special_tokens=False)
            qid = question.get("question_id", None)
            if qid is not None:
                print(f"[question_id={qid}] {decoded}")
            else:
                print(decoded)

        # 전체 결과 요약 출력
        avg_acceptance_ratio = (grand_total_accepted / max(1, grand_total_draft_tokens)) if grand_total_draft_tokens > 0 else 0.0
        avg_tree_depth = (grand_total_draft_tokens / max(1, grand_total_steps)) if grand_total_steps > 0 else 0.0
        print(f"acceptance_ratio_avg={avg_acceptance_ratio:.4f}  avg_tree_depth={avg_tree_depth:.4f}  steps={grand_total_steps}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", type=str, default="127.0.0.1")
    parser.add_argument("--port", type=int, default=26001)
    parser.add_argument("--base-model-path", type=str, required=True)
    parser.add_argument("--draft-model-path", type=str, required=True)
    parser.add_argument("--bench-name", type=str, choices=["mt_bench", "gsm8k"], required=True)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--nodes", type=int, default=50)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--max_depth", type=int, default=10)
    parser.add_argument("--device-map", type=str, default="cuda:0")
    parser.add_argument("--load-in-4bit", action="store_true")
    parser.add_argument("--load-in-8bit", action="store_true")
    args = parser.parse_args()

    if args.bench_name == "mt_bench":
        script_dir = os.path.dirname(__file__)
        parent_dir = os.path.dirname(script_dir)
        question_file = f"{parent_dir}/data/mt_bench/question.jsonl"
    elif args.bench_name == "gsm8k":
        script_dir = os.path.dirname(__file__)
        parent_dir = os.path.dirname(script_dir)
        question_file = f"{parent_dir}/data/gsm8k.jsonl"
    else:
        raise ValueError("Undefined bench_name")

    run_draft(
        host=args.host,
        port=args.port,
        base_model_path=args.base_model_path,
        draft_model_path=args.draft_model_path,
        bench_name=args.bench_name,
        question_file=question_file,
        temperature=args.temperature,
        nodes=args.nodes,
        threshold=args.threshold,
        max_depth=args.max_depth,
        device_map=args.device_map,
        load_in_4bit=args.load_in_4bit,
        load_in_8bit=args.load_in_8bit,
    )