import argparse
import time

import torch
from transformers import AutoModelForCausalLM

from evaluation import eval_opt_classic_autoregressive as base_eval


def get_general_causal_lm_class(_base_model_path: str):
    """Always use the standard Hugging Face AutoModelForCausalLM class."""
    print("importing transformers.AutoModelForCausalLM")
    return AutoModelForCausalLM


@torch.inference_mode()
def autoregressive_forward_stepwise(
    input_ids,
    model,
    tokenizer,
    args,
    logits_processor=None,
    max_steps=512,
    past_key_values=None,
):
    """Step-wise autoregressive decoding without model.generate()."""
    assert input_ids.shape[0] == 1, "Only support batch size 1 for now!!"

    input_len = input_ids.shape[1]
    max_new_tokens = min(max_steps, 1024)
    eos_token_id = tokenizer.eos_token_id

    generated_ids = input_ids
    cur_input_ids = input_ids
    attention_mask = torch.ones_like(input_ids, device=input_ids.device)
    pkv = past_key_values

    token_pbar = base_eval.tqdm(total=max_new_tokens, desc="토큰 생성", unit="token", leave=False)

    torch.cuda.synchronize()
    start_time = time.time()

    for _ in range(max_new_tokens):
        outputs = model(
            input_ids=cur_input_ids,
            attention_mask=attention_mask,
            past_key_values=pkv,
            use_cache=True,
        )

        logits = outputs.logits if hasattr(outputs, "logits") else outputs[0]
        next_token_logits = logits[:, -1, :]

        if logits_processor is not None:
            # HF logits processors expect full generated ids + current step logits
            next_token_logits = logits_processor(generated_ids, next_token_logits)

        if args.temperature > 1e-5:
            probs = torch.softmax(next_token_logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
        else:
            next_token = torch.argmax(next_token_logits, dim=-1, keepdim=True)

        generated_ids = torch.cat([generated_ids, next_token], dim=-1)
        token_pbar.update(1)

        if eos_token_id is not None and int(next_token.item()) == int(eos_token_id):
            break

        # Next step consumes only last generated token with KV cache
        cur_input_ids = next_token
        pkv = outputs.past_key_values if hasattr(outputs, "past_key_values") else None
        attention_mask = torch.cat(
            [attention_mask, torch.ones((attention_mask.shape[0], 1), dtype=attention_mask.dtype, device=attention_mask.device)],
            dim=-1,
        )

    torch.cuda.synchronize()
    end_time = time.time()

    new_token = generated_ids.shape[1] - input_len
    total_time = end_time - start_time
    tokens_per_sec = new_token / total_time if total_time > 0 else 0

    token_pbar.set_postfix(
        {
            "tokens": new_token,
            "total_length": generated_ids.shape[1],
            "tokens/sec": f"{tokens_per_sec:.2f}",
            "total_time": f"{total_time:.3f}s",
        }
    )
    token_pbar.close()

    return generated_ids, new_token, new_token - 1, pkv


# Monkey-patch to use general class + stepwise decoding
base_eval.get_kv_llama_class = get_general_causal_lm_class
base_eval.autoregressive_forward = autoregressive_forward_stepwise


if __name__ == "__main__":
    """Argument Parser + Run Evaluation (same interface as base script)."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-model-path", type=str, required=True, help="Path of target model.")
    parser.add_argument("--load-in-8bit", action="store_true", help="Use 8-bit quantization")
    parser.add_argument("--model-id", type=str, default="llama-2-chat")
    parser.add_argument(
        "--bench-name",
        type=str,
        choices=["mt_bench", "gsm8k"],
        help="The name of the benchmark question set.",
    )
    parser.add_argument("--question-begin", type=int, help="A debug option. The begin index of questions.")
    parser.add_argument("--question-end", type=int, help="A debug option. The end index of questions.")
    parser.add_argument("--answer-file", type=str, help="The output answer file.")
    parser.add_argument("--max-new-token", type=int, default=1024, help="The maximum number of new generated tokens.")
    parser.add_argument("--num-choices", type=int, default=1, help="How many completion choices to generate.")
    parser.add_argument("--num-gpus-per-model", type=int, default=1, help="The number of GPUs per model.")
    parser.add_argument("--num-gpus-total", type=int, default=1, help="The total number of GPUs.")
    parser.add_argument("--max-gpu-memory", type=str, help="Maxmum GPU memory used for model weights per GPU.")
    parser.add_argument("--temperature", type=float, default=0)

    # kept for compatibility
    parser.add_argument("--nodes", type=int, default=50, help="Number of nodes (not used in autoregressive mode).")
    parser.add_argument("--threshold", type=float, default=0.5, help="Threshold (not used in autoregressive mode).")
    parser.add_argument("--max_depth", type=int, default=10, help="Max depth (not used in autoregressive mode).")

    # GPU monitoring args
    parser.add_argument("--enable-gpu-monitor", action="store_true", help="Enable GPU monitoring during evaluation")
    parser.add_argument("--gpu-monitor-interval", type=float, default=0.1, help="GPU monitoring interval in seconds")
    parser.add_argument("--output-file", type=str, help="Output file for performance statistics")
    parser.add_argument("--fix-gpu-clock", action="store_true", help="Fix GPU clock to specified values")
    parser.add_argument("--graphics-clock", type=int, help="Graphics clock frequency in MHz")
    parser.add_argument("--memory-clock", type=int, help="Memory clock frequency in MHz")

    args = parser.parse_args()

    if args.fix_gpu_clock:
        print("=" * 60)
        print("[eval] GPU 클럭 고정 모드")
        print("=" * 60)
        available_clocks = base_eval.get_available_gpu_clocks()
        if available_clocks:
            print("사용 가능한 GPU 클럭 조합 (처음 20개):")
            for i, clock in enumerate(available_clocks[:20]):
                print(f"  {i+1:2d}. Graphics: {clock['graphics_clock']:4d}MHz, Memory: {clock['memory_clock']:4d}MHz")
            if len(available_clocks) > 20:
                print(f"  ... 총 {len(available_clocks)}개 조합")
        else:
            print("사용 가능한 GPU 클럭 조합을 찾을 수 없습니다.")
        print("=" * 60)

    args.model_id = args.model_id + "-temperature-" + str(args.temperature)
    if args.num_gpus_total // args.num_gpus_per_model > 1:
        if base_eval.ray is not None:
            base_eval.ray.init()
        else:
            print("Warning: Ray is not available. Running on single GPU.")

    if args.bench_name == "mt_bench":
        question_file = f"{base_eval.parent_dir}/data/mt_bench/question.jsonl"
    elif args.bench_name == "gsm8k":
        question_file = f"{base_eval.parent_dir}/data/gsm8k.jsonl"
    else:
        raise ValueError("Undefined bench_name")

    print(f"Output to {args.answer_file}")

    base_eval.run_eval(
        args.base_model_path,
        args.model_id,
        question_file,
        args.question_begin,
        args.question_end,
        args.answer_file,
        args.max_new_token,
        args.num_choices,
        args.num_gpus_per_model,
        args.num_gpus_total,
        args.max_gpu_memory,
        args.temperature,
        args,
        args.enable_gpu_monitor,
        args.gpu_monitor_interval,
        args.output_file,
        args.fix_gpu_clock,
        args.graphics_clock,
        args.memory_clock,
    )

    base_eval.reorg_answer_file(args.answer_file)
