import torch
import random
import time
import json
import os

class Tree:
    def __init__(
        self,
        nnodes,
        device,
        threshold,
        max_depth,
        per_token_probability_bound=0.0,
        per_path_probability_bound=0.0,
        fixed_width=None,
        fixed_nnodes=None,
        fixed_depth=False,
        profile_data=None,
        target_profile_data=None,
        prev_tree_final_width=0,
        prev_tree_depth=0,
        prev_tree_total_time=0.4,
        draft_per_sec_cost=0.0,
        target_per_sec_cost=0.0,
        cost_sensitivity=0.0,
        min_width=1,
        prev_tree_transfer_time=None,
    ):
        self.max_nnodes = nnodes  # 최대 노드 수 (max_width)
        self.device = device
        self.threshold = threshold
        self.depth = 0
        self.weight = 0
        self.per_token_probability_bound = per_token_probability_bound  # 각 토큰의 확률이 이 값보다 작으면 버림
        self.per_path_probability_bound = per_path_probability_bound  # 각 경로의 확률이 이 값보다 작으면 버림
        self.max_depth = max_depth
        self.min_width = min_width  # next_width 선택 시 최소 width
        self.fixed_width = fixed_width  # 프로파일링용: 특정 width로 고정 (None이면 동적)
        self.fixed_nnodes = fixed_nnodes  # 최종 전송할 노드 수 고정 (None이면 자동)
        self.fixed_depth = fixed_depth  # depth 확장 조건 무시 여부
        # 프로파일링 데이터 (width별 avg_time_ms를 포함하는 딕셔너리)
        self.profile_data = profile_data  # {width: {"avg_time_ms": ...}, ...}
        # Target 프로파일링 데이터 (width_depth별 avg_time_ms를 포함하는 딕셔너리)
        self.target_profile_data = target_profile_data  # {"width_X_depth_Y": {"avg_time_ms": ...}, ...}
        # 이전 tree의 정보 (전송 시간 계산용)
        self.prev_tree_final_nnodes = prev_tree_final_width  # 이전 tree의 top_index 개수 (final_width)
        self.prev_tree_depth = prev_tree_depth  # 이전 tree의 depth
        self.prev_tree_total_target_time = prev_tree_total_time  # 이전 tree의 토탈 시간 (target에서 받은 시간, 초 단위)
        # 토큰별 전송 시간 (이전 tree의 정보로 계산)
        self.per_token_transfer_time = 0.0  # 토큰별 전송 시간 (초 단위)
        # 이전 tree의 실제 측정된 전송 시간 (초 단위, None이면 추정값 사용)
        self.prev_tree_transfer_time = prev_tree_transfer_time
        # 초당 비용
        self.draft_per_sec_cost = draft_per_sec_cost
        self.target_per_sec_cost = target_per_sec_cost
        # Cost sensitivity (0 to infinity)
        self.cost_sensitivity = cost_sensitivity
        # Depth별 통계 수집용 (JSON 저장용)
        self.depth_stats = {}  # {depth: {"prev_sum_expected_accepted_length": [...], "sum_expected_accepted_length": [...], "per_token_latency_diff": [...], "per_token_cost_diff": [...]}}
        # 매트릭스는 최대 크기로 할당
        self.weight_matrix = torch.zeros([max_depth, self.max_nnodes], device=self.device)
        self.input_ids_matrix = torch.zeros([max_depth, self.max_nnodes], dtype=torch.long, device=self.device)
        self.parents_matrix = torch.zeros([max_depth, self.max_nnodes], dtype=torch.long, device=self.device)
        # depth별 실제 width 저장
        self.depth_widths = []
        # 현재 depth의 width (동적으로 변경됨)
        self.current_width = 0
        # 이전 depth의 width (add() 함수에서 사용)
        self.prev_width = 0
        # width별 add() 함수 실행 시간 측정용
        self.width_times = {}  # {width: [time1, time2, ...]}
        # 이번 tree 생성 동안 add() 함수에 사용된 시간의 총합
        self.add_total_time = 0.0
        # 이전 add() 함수에 사용된 시간의 총합
        self.prev_add_total_time = 0.0
        # 이번 tree 생성 동안 add() 함수에 사용된 예상 시간의 총합
        self.expected_add_total_time = 0.0
        # 예상 accept length의 합
        self.sum_expected_accepted_length = 1.0
        # 이전 예상 accept length의 합
        self.prev_sum_expected_accepted_length = 1.0
        # breakpoint()

    def initialize(self, logits):
        # 이번 tree 생성 동안 add() 함수에 사용된 시간의 총합 초기화
        self.add_total_time = 0.0
        # 이번 tree 생성 동안 add() 함수에 사용된 예상 시간의 총합 초기화
        self.expected_add_total_time = 0.0
        # 이전 depth의 width 초기화 (첫 번째 depth이므로 이전 width가 없음)
        self.prev_width = 0
        # 예상 accept length의 합 초기화
        self.sum_expected_accepted_length = 1.0
        # 이전 예상 accept length의 합 초기화
        self.prev_sum_expected_accepted_length = 1.0
        # Depth별 통계 초기화 (새로운 tree 생성 시)
        self.depth_stats = {}
        
        # 첫 번째 depth의 width를 확률 바운드를 적용하여 결정
        # initialize의 경우 이전 depth가 없으므로 per_token_probability_bound만 적용
        single_logits = logits[0][-1]  # (vocab_size,)
        
        # 1. per_token_probability_bound보다 낮은 값을 0으로 변경
        probs = torch.softmax(single_logits, dim=-1)  # (vocab_size,)
        if self.per_token_probability_bound > 0.0:
            probs = torch.where(probs >= self.per_token_probability_bound, probs, torch.zeros_like(probs))
        
        # 2. 남아있는 노드 중 0이 아닌 것의 개수를 계산하여 current_width 설정
        # initialize에서는 경로 확률을 구할 수 없으므로 per_token만 확인
        if self.fixed_width is not None:
            # 프로파일링 모드: fixed_width로 고정
            self.current_width = min(self.fixed_width, self.max_nnodes)
        else:
            valid_mask = probs > 0
            valid_count = valid_mask.sum().item()
            min_w = max(int(self.min_width), 1)
            self.current_width = min(max(int(valid_count), min_w), self.max_nnodes)  # 최소 min_width, 최대 max_nnodes
        self.depth_widths.append(self.current_width)
        
        # 3. 토큰 확률이 높은 순서로 current_width개 선택
        top_logits, ids = torch.topk(probs, k=self.current_width, dim=-1)
        # 원본 logits에서 선택된 토큰들의 logits 값 가져오기
        selected_logits = single_logits[ids]
        self.weight_matrix[self.depth, :self.current_width].copy_(selected_logits)
        self.input_ids_matrix[self.depth, :self.current_width].copy_(ids)
        
        rows = torch.arange(self.current_width, device=self.device)
        self.parents_matrix[0, :self.current_width].copy_(rows)
        
        position_id = torch.zeros([self.current_width], dtype=torch.long, device=self.device)
        tri = torch.eye(self.current_width, dtype=torch.int8, device=self.device)
        
        # max_depth가 1이면 initialize 후 바로 종료
        is_final = (self.depth + 1 >= self.max_depth)
        
        output_dict = {
            "input_ids": ids,   # [DH] logits 중 선택된 상위 N개 토큰의 인덱스 (N은 랜덤)
            "position_ids": position_id + 1,   # [DH] 몇 번째 depth인지, initialize 시 1로 초기화됨
            "attention_mask": tri,  # [DH] attention mask is identity matrix로 초기화됨
            "parent_last": rows,
            "is_final": is_final
        }
        self.depth += 1
        return output_dict
    
    def add(self, logits):
        # logits shape: (1, prev_width, vocab_size)
        # WORKING_VER은 self.current_width를 사용했지만, 실제로는 입력 logits의 폭이 정답이므로 여기서 동기화한다.
        self.prev_width = logits.shape[1]
        
        # logits는 이미 확률로 변환된 상태 (softmax 적용됨)
        probs = logits[0]  # (self.prev_width, vocab_size)
        
        # 이하 width 결정 알고리즘 
        # 1. per_token_probability_bound보다 낮은 확률을 0으로 설정
        if self.per_token_probability_bound > 0.0:
            probs = torch.where(probs >= self.per_token_probability_bound, probs, torch.zeros_like(probs))
        
        # 2. 루트로부터의 경로 확률을 구하고, per_path_probability_bound보다 낮은 경우 0으로 변경
        last_layer_weights = self.weight_matrix[self.depth-1, :self.prev_width].unsqueeze(1)  # (self.prev_width, 1)
        path_probs = probs * last_layer_weights  # (self.prev_width, vocab_size) - 경로 확률 = 부모의 경로 확률 * 자식의 토큰 확률
        
        # per_path_probability_bound보다 낮은 경로 확률을 0으로 설정
        if self.per_path_probability_bound > 0.0:
            path_probs = torch.where(path_probs >= self.per_path_probability_bound, path_probs, torch.zeros_like(path_probs))
        
        # 3. flat_path_probs 계산 (항상 필요)
        flat_path_probs = path_probs.view(-1)  # (self.prev_width * vocab_size)
        
        # 4. 남아있는 노드 중 0이 아닌 것의 개수를 계산하여 current_width 설정 (WORKING_VER 방식)
        if self.fixed_width is not None:
            # 프로파일링 모드: fixed_width로 고정
            self.current_width = min(self.fixed_width, self.max_nnodes)
        else:
            valid_mask = flat_path_probs > 0
            valid_count = valid_mask.sum().item()
            min_w = max(int(self.min_width), 1)
            self.current_width = min(max(int(valid_count), min_w), self.max_nnodes)  # 최소 min_width, 최대 max_nnodes
        self.depth_widths.append(self.current_width)
        
        # 5. 경로 확률이 높은 순서로 current_width개 선택
        global_top_logits, global_top_idx = torch.topk(flat_path_probs, k=self.current_width, dim=-1)
        
        # global_top_idx를 (self.prev_width, vocab_size) 좌표로 변환
        vocab_size = probs.size(1)
        parents = global_top_idx // vocab_size  # 부모 인덱스
        input_ids = global_top_idx % vocab_size  # 토큰 ID
        
        # parents 인덱스가 self.prev_width 범위 내에 있는지 확인 및 클램핑
        parents = torch.clamp(parents, 0, self.prev_width - 1)
        
        self.parents_matrix[self.depth, :self.current_width].copy_(parents)
        self.weight_matrix[self.depth, :self.current_width].copy_(global_top_logits)
        self.input_ids_matrix[self.depth, :self.current_width].copy_(input_ids)
        
        rows = torch.arange(self.current_width, device=self.device)
        kv_cache_mask = torch.zeros([self.current_width, self.prev_width], dtype=torch.int8, device=self.device) 
        # [DH] (current_width, self.prev_width) 형태의 matrix. 현새 depth에서 선택된 토큰들의 부모가 몇 번째 parent인지를 나타냄. 
        # (첫 번째 토큰의 부모의 index가 3이면 (0, 3) 위치에 1로 체크됨)
        kv_cache_mask[rows, parents] = 1
        
        # kv_mask 업데이트
        if self.depth == 1:
            kv_mask = kv_cache_mask
        else:
            # 이전 kv_mask에서 parent에 해당하는 행만 선택
            prev_kv_mask = getattr(self, '_prev_kv_mask', torch.zeros([self.prev_width, 0], dtype=torch.int8, device=self.device))
            kv_mask = torch.cat([prev_kv_mask[parents], kv_cache_mask], dim=1)
        
        self._prev_kv_mask = kv_mask
        
        tri = torch.eye(self.current_width, dtype=torch.int8, device=self.device)
        attention_mask = torch.cat([kv_mask, tri], dim=1)    # [DH] 선택된 child들의 attention mask
        
        position_id = torch.zeros([self.current_width], dtype=torch.long, device=self.device)
        output_dict = {
            "input_ids": input_ids,  # [DH] self.prev_width개의 부모로부터 나온 자식 중 선택된 current_width개
            "position_ids": position_id + (self.depth + 1),  # [DH] 몇 번째 depth인지
            "attention_mask": attention_mask,
            "parent_last": parents,
            "is_final": False
        }
        self.depth += 1
        return output_dict
    
    def generate_attention_mask(self, parents, final_width):
        attention_mask = torch.eye(final_width, dtype=torch.int8, device=self.device)
        grandp = parents.clone()
        for _ in range(self.depth - 2):
            rows = torch.arange(final_width, device=self.device)
            attention_mask[rows, grandp] = 1
            grandp = grandp[parents]
        return attention_mask

    def update(self, logits, print_tree=False, tokenizer=None, model_time=None):
        if self.depth == 0:
            result = self.initialize(logits)
            if print_tree:
                self.print_tree_structure_hierarchical(tokenizer)
            return result
        

        
        # add() 함수 실행 시간 측정
        # GPU 동기화 (이전 CUDA 연산이 완료되도록 보장)
        if isinstance(logits, torch.Tensor) and logits.is_cuda:
            torch.cuda.synchronize()
        elif isinstance(logits, (list, tuple)) and len(logits) > 0 and isinstance(logits[0], torch.Tensor) and logits[0].is_cuda:
            torch.cuda.synchronize()
        
        # add() 호출 전 시간 측정 시작
        start_time = time.time()
        outputs = self.add(logits)
        
        # GPU 동기화 (add() 내부의 모든 CUDA 연산이 완료되도록 보장)
        # 이 synchronize()는 add() 내부 CUDA 연산의 완료를 기다리므로 측정 시간에 포함되어야 함
        if isinstance(logits, torch.Tensor) and logits.is_cuda:
            torch.cuda.synchronize()
        elif isinstance(logits, (list, tuple)) and len(logits) > 0 and isinstance(logits[0], torch.Tensor) and logits[0].is_cuda:
            torch.cuda.synchronize()
        
        # synchronize() 후 시간 측정 (add() 내부의 모든 CUDA 연산이 완료된 후)
        elapsed_time = time.time() - start_time
        
        # 이번 tree 생성 동안 add() 함수에 사용된 시간의 총합에 누적
        self.prev_add_total_time = self.add_total_time
        self.add_total_time += elapsed_time
        
        # width별 시간 기록 (add() 함수에서 self.current_width가 설정됨)
        current_width = self.current_width
        
        # 이번 tree 생성 동안 add() 함수에 사용된 예상 시간의 총합에 누적
        # 프로파일링 데이터에서 현재 width에 해당하는 avg_time_ms를 찾아서 더함
        if self.profile_data is not None:
            width_str = str(self.prev_width)
            if width_str in self.profile_data:
                avg_time_ms = self.profile_data[width_str].get("avg_time_ms", 0.0)
                # 밀리초를 초로 변환하여 더함
                self.expected_add_total_time += avg_time_ms / 1000.0
            else:
                # 프로파일링 데이터에 해당 width가 없으면 실제 측정 시간 사용
                self.expected_add_total_time += elapsed_time
        else:
            # 프로파일링 데이터가 없으면 실제 측정 시간 사용
            self.expected_add_total_time += elapsed_time
        # width_times는 기존처럼 기록하되, draft_model.model 호출 시간이 제공되면 그 값을 우선 기록
        if current_width not in self.width_times:
            self.width_times[current_width] = []
        self.width_times[current_width].append(model_time if model_time is not None else elapsed_time)
        
        if print_tree:
            self.print_tree_structure_hierarchical(tokenizer)
        
        # breakpoint()
        
        # 각 depth의 width가 다르므로, 전체 노드 수를 계산
        total_nodes = sum(self.depth_widths[:self.depth-1])
        

        
        # weight_matrix에서 유효한 값들만 선택
        valid_weights = []
        for d in range(self.depth - 1):
            valid_weights.append(self.weight_matrix[d, :self.depth_widths[d]])
        
        self.prev_sum_expected_accepted_length = self.sum_expected_accepted_length
        # 각 depth별 확률 합 계산
        depth_probs = [w.sum() for w in valid_weights]
        
        # 앞 레이어의 확률은 뒷 레이어를 뺀 값으로 재정의
        # 예: [1, 0.9, 0.58] → [1-0.9, 0.9-0.58, 0.58] = [0.1, 0.32, 0.58]
        adjusted_depth_probs = []
        for i in range(len(depth_probs)):
            if i == len(depth_probs) - 1:
                # 마지막 레이어는 그대로
                adjusted_depth_probs.append(depth_probs[i])
            else:
                # 앞 레이어에서 뒷 레이어를 뺌
                adjusted_depth_probs.append(depth_probs[i] - depth_probs[i + 1])
        
        # 각 레이어에 (depth+1)을 곱해서 합산
        # 예: 0.1*1 + 0.32*2 + 0.58*3
        self.sum_expected_accepted_length = sum(adj_prob * float(d + 1) for d, adj_prob in enumerate(adjusted_depth_probs))
        
        flat_weights = torch.cat(valid_weights)
        

        # 최종 선택할 노드 수 (WORKING_VER): 기본은 max_nnodes까지, fixed_nnodes가 있으면 그 값으로 고정
        final_nnodes = min(len(flat_weights), self.max_nnodes)
        if self.fixed_nnodes is not None:
            final_nnodes = min(final_nnodes, int(self.fixed_nnodes))

        top_weights, top_index = torch.topk(flat_weights, k=final_nnodes, dim=-1)
        weight = top_weights.sum()
        
        # 이하 depth 확장 여부 결정 알고리즘
        current_llm_time_sec = 0.2
        prev_llm_time_sec = 0.2
        # 이전 tree의 정보를 사용하여 전송 시간 계산
        if self.prev_tree_transfer_time is not None and self.prev_tree_final_nnodes > 0:
            # 실제 측정값이 있으면 그걸 우선 사용
            self.per_token_transfer_time = self.prev_tree_transfer_time / self.prev_tree_final_nnodes
        elif self.prev_tree_final_nnodes > 0 and self.prev_tree_total_target_time > 0 and self.target_profile_data is not None:
            # 이전 tree의 width와 depth로 프로파일링 키 생성
            # prev_tree_final_nnodes는 이전 tree의 final_nnodes (top_index 개수)
            # prev_tree_depth는 이전 tree의 depth (0인 경우 1로 변경)
            prev_tree_depth_for_key = self.prev_tree_depth if self.prev_tree_depth > 0 else 1
            prev_profile_key = f"width_{self.prev_tree_final_nnodes}_depth_{prev_tree_depth_for_key}"
            current_profile_key = f"width_{final_nnodes}_depth_{self.depth}"
            
            if prev_profile_key in self.target_profile_data and current_profile_key in self.target_profile_data:
                # LLM 연산 시간 추출 (밀리초 단위)
                prev_llm_time_ms = self.target_profile_data[prev_profile_key].get("avg_time_ms", 0.0)
                prev_llm_time_sec = prev_llm_time_ms / 1000.0
                current_llm_time_ms = self.target_profile_data[current_profile_key].get("avg_time_ms", 0.0)
                current_llm_time_sec = current_llm_time_ms / 1000.0
                
                # 전송 시간 계산: 토탈 시간 - LLM 연산 시간
                transfer_time = self.prev_tree_total_target_time - prev_llm_time_sec
                
                # 토큰별 전송 시간 계산: 전송 시간 / 이전 tree의 top_index 개수
                if self.prev_tree_final_nnodes > 0:
                    self.per_token_transfer_time = transfer_time / self.prev_tree_final_nnodes
                else:
                    self.per_token_transfer_time = 0.0
            else:
                # 프로파일링 데이터에 해당 조합이 없으면 0으로 설정
                self.per_token_transfer_time = 0.0
                # print(f"이전 정보가 없음. per token transfer time 0 및 target 연산 시간 0.2초로 설정, prev_profile_key: {prev_profile_key}, current_profile_key: {current_profile_key}")
        else:
            # 이전 tree 정보가 없으면 0으로 설정
            self.per_token_transfer_time = 0.0
            # print(f"이전 정보가 없음. per token transfer time 0 및 target 연산 시간 0.2초로 설정, prev_tree_final_nnodes: {self.prev_tree_final_nnodes}, prev_tree_total_target_time: {self.prev_tree_total_target_time}, target_profile_data is None: {self.target_profile_data is None}")
        
        # sum_expected_accepted_length는 이미 위에서 계산됨 (top_index와 무관하게 전체 depth에 대해 계산)
        # print(f"prev_sum_expected_accepted_length: {self.prev_sum_expected_accepted_length}, sum_expected_accepted_length: {self.sum_expected_accepted_length}")
        
        prev_per_token_latency = (self.prev_add_total_time+self.per_token_transfer_time*self.prev_tree_final_nnodes+prev_llm_time_sec)/self.prev_sum_expected_accepted_length 
        per_token_latency = (self.add_total_time+self.per_token_transfer_time*final_nnodes+current_llm_time_sec)/self.sum_expected_accepted_length
        per_token_latency_diff = per_token_latency - prev_per_token_latency

        prev_per_token_cost = (self.prev_add_total_time*self.draft_per_sec_cost + prev_llm_time_sec*self.target_per_sec_cost)/self.prev_sum_expected_accepted_length
        per_token_cost = (self.add_total_time*self.draft_per_sec_cost + current_llm_time_sec*self.target_per_sec_cost)/self.sum_expected_accepted_length
        per_token_cost_diff = per_token_cost - prev_per_token_cost

        # print(f"per token latency diff: {per_token_latency_diff}, per token cost diff: {per_token_cost_diff}")
        objective_value = per_token_latency_diff + self.cost_sensitivity * per_token_cost_diff
        
        # Depth별 통계 수집 (현재 depth에 대한 값 저장)
        current_depth = self.depth
        if current_depth not in self.depth_stats:
            self.depth_stats[current_depth] = {
                "prev_sum_expected_accepted_length": [],
                "sum_expected_accepted_length": [],
                "per_token_latency_diff": [],
                "per_token_cost_diff": []
            }
        
        self.depth_stats[current_depth]["prev_sum_expected_accepted_length"].append(float(self.prev_sum_expected_accepted_length))
        self.depth_stats[current_depth]["sum_expected_accepted_length"].append(float(self.sum_expected_accepted_length))
        self.depth_stats[current_depth]["per_token_latency_diff"].append(float(per_token_latency_diff))
        self.depth_stats[current_depth]["per_token_cost_diff"].append(float(per_token_cost_diff))

        # Depth 확장 조건
        # - fixed_depth=True: max_depth만 고려 (WORKING_VER의 기본 동작과 동일)
        # - fixed_depth=False: latency/cost 목적함수가 좋아질 때만 확장
        should_expand = False
        if self.fixed_depth:
            should_expand = (self.depth < self.max_depth)
        else:
            should_expand = (self.depth < self.max_depth) and (objective_value < 0)

        if should_expand:
            self.weight = weight
        else:   # [DH] 트리 depth 확장이 종료되는 경우.
            # breakpoint()
            # top_index를 depth와 column으로 변환
            rows = torch.zeros_like(top_index)
            cols = top_index.clone()
            cumsum = 0
            for d in range(self.depth - 1):
                mask = (top_index >= cumsum) & (top_index < cumsum + self.depth_widths[d])
                rows[mask] = d  # [DH] 각 토큰의 depth 인덱스
                cols[mask] = top_index[mask] - cumsum  # [DH] 각 토큰의 각 depth에서의 column 인덱스
                cumsum += self.depth_widths[d]
            # breakpoint()
            sorted_indices = torch.argsort(rows)
            rows = rows[sorted_indices]   # [DH] 부모 인덱스 기준 정렬
            cols = cols[sorted_indices]   # [DH] 부모 인덱스 기준 정렬
            
            # # index 계산 (각 depth의 width 고려)
            # index_list = []
            # cumsum = 0
            # for d in range(self.depth - 1):
            #     depth_indices = torch.arange(cumsum, cumsum + self.depth_widths[d], device=self.device)
            #     index_list.append(depth_indices)
            #     cumsum += self.depth_widths[d]
            
            input_ids = self.input_ids_matrix[rows, cols]
            position_ids = rows + 1
            parents = self.parents_matrix[rows, cols]
            
            # source_idx와 parent_idx 계산
            source_idx = torch.zeros_like(rows)
            parent_idx = torch.zeros_like(rows)
            for i, (r, c) in enumerate(zip(rows, cols)):
                r_item = r.item()
                c_item = c.item()
                # source_idx: 현재 노드의 전역 인덱스
                cumsum = sum(self.depth_widths[:r_item])
                source_idx[i] = cumsum + c_item
                
                # parent_idx: 부모 노드의 전역 인덱스
                if r_item > 0:
                    parent_depth = r_item - 1
                    parent_col = parents[i].item()
                    parent_cumsum = sum(self.depth_widths[:parent_depth])
                    parent_idx[i] = parent_cumsum + parent_col
                else:
                    parent_idx[i] = parents[i]
            # breakpoint()
            # parents_index 계산: 각 노드의 부모가 선택된 노드들 중 몇 번째인지 찾기
            # parent_idx[i]는 i번째 노드의 부모 노드의 전역 인덱스
            # source_idx[j]는 j번째 노드의 전역 인덱스
            # parent_idx[i] == source_idx[j]인 경우, i번째 노드의 부모가 j번째 노드임
            parents_index = torch.zeros(len(top_index), dtype=torch.long, device=self.device)
            for i in range(len(top_index)):
                # parent_idx[i]와 일치하는 source_idx의 인덱스 찾기
                matches = (source_idx == parent_idx[i]).nonzero(as_tuple=False)
                if len(matches) > 0:
                    parents_index[i] = matches[0].item()
                else:
                    # 매칭되지 않는 경우: depth 0이면 부모가 없으므로 0, 아니면 이전 노드의 인덱스 사용
                    if len(rows) > 0 and rows[i].item() == 0:
                        parents_index[i] = 0
                    else:
                        # 이전 노드 중에서 같은 depth의 노드를 부모로 사용
                        # 또는 가장 가까운 이전 노드 사용
                        parents_index[i] = max(0, i - 1) if i > 0 else 0
            
            # parents_index의 값이 유효한 범위 내에 있는지 확인
            parents_index = torch.clamp(parents_index, 0, len(top_index) - 1)
            
            # 검증: parents_index의 크기가 top_index와 일치해야 함
            if len(parents_index) != len(top_index):
                raise ValueError(f"parents_index size mismatch: {len(parents_index)} != {len(top_index)}")
            
            attention_mask = self.generate_attention_mask(parents_index, len(top_index))
            
            outputs = {
                "input_ids": input_ids,  # [DH] 선택된 노드들 (부모 인덱스 순으로 정렬됨)
                "position_ids": position_ids,  # [DH] 몇 번째 depth인지
                "attention_mask": attention_mask,
                "parent_last": parents_index,  # [DH] 선택된 노드들의 부모 인덱스 (상대적인 인덱스)
                "is_final": True
            }
        return outputs
    
    def get_width_timing_stats(self):
        """width별 add() 함수 실행 시간 통계를 딕셔너리로 반환"""
        if not self.width_times:
            return {}
        
        stats = {}
        for width in sorted(self.width_times.keys()):
            times = self.width_times[width]
            count = len(times)
            total_time_ms = sum(times) * 1000
            avg_time_ms = (sum(times) / count) * 1000
            min_time_ms = min(times) * 1000
            max_time_ms = max(times) * 1000
            
            stats[width] = {
                'count': count,
                'total_time_ms': total_time_ms,
                'avg_time_ms': avg_time_ms,
                'min_time_ms': min_time_ms,
                'max_time_ms': max_time_ms
            }
        
        return stats
    
    def print_width_timing_stats(self):
        """width별 add() 함수 평균 실행 시간 출력"""
        stats = self.get_width_timing_stats()
        if not stats:
            return
        
        print("\n" + "="*80)
        print("Width별 add() 함수 실행 시간 통계")
        print("="*80)
        print(f"{'Width':<10} {'실행 횟수':<12} {'총 시간 (ms)':<15} {'평균 시간 (ms)':<15} {'최소 시간 (ms)':<15} {'최대 시간 (ms)':<15}")
        print("-"*80)
        
        for width in sorted(stats.keys()):
            s = stats[width]
            print(f"{width:<10} {s['count']:<12} {s['total_time_ms']:<15.3f} {s['avg_time_ms']:<15.3f} {s['min_time_ms']:<15.3f} {s['max_time_ms']:<15.3f}")
        
        print("="*80 + "\n")

    def depth_algorithm(self):  # 여기다가 depth 관련 알고리즘 삽입 (depth 확장 조건)
        return True
    
    def print_tree_structure(self, tokenizer=None):
        """
        트리 구조를 시각적으로 출력하는 함수
        Args:
            tokenizer: 토큰 ID를 텍스트로 변환하기 위한 tokenizer (선택사항)
        """
        print("\n" + "="*80)
        print(f"Tree Structure (Current Depth: {self.depth}, Max Depth: {self.max_depth})")
        print("="*80)
        
        if self.depth == 0:
            print("Tree is empty (depth=0)")
            return
        
        # 각 depth별로 노드 정보 수집
        for d in range(self.depth):
            width = self.depth_widths[d] if d < len(self.depth_widths) else 0
            print(f"\nDepth {d} (width={width}):")
            print("-" * 80)
            
            for i in range(width):
                token_id = self.input_ids_matrix[d, i].item()
                weight = self.weight_matrix[d, i].item()
                parent_idx = self.parents_matrix[d, i].item() if d > 0 else -1
                
                # 토큰 텍스트 변환
                if tokenizer:
                    try:
                        token_text = tokenizer.decode([token_id])
                        token_text = repr(token_text)  # 특수문자 표시
                    except:
                        token_text = "<?>"
                else:
                    token_text = ""
                
                # 노드 정보 출력
                if d == 0:
                    print(f"  [{d},{i:2d}] token_id={token_id:5d} {token_text:20s} weight={weight:.6f}")
                else:
                    print(f"  [{d},{i:2d}] token_id={token_id:5d} {token_text:20s} weight={weight:.6f} <- parent=[{d-1},{parent_idx:2d}]")
        
        print("="*80 + "\n")
    
    def print_tree_structure_hierarchical(self, tokenizer=None):
        """
        트리 구조를 계층적으로 출력하는 함수 (트리 형태로 표현)
        Args:
            tokenizer: 토큰 ID를 텍스트로 변환하기 위한 tokenizer (선택사항)
        """
        print("\n" + "="*100)
        print(f"Tree Structure - Hierarchical View (Current Depth: {self.depth})")
        print("="*100)
        
        if self.depth == 0:
            print("Tree is empty (depth=0)")
            return
        
        # 각 depth별로 부모-자식 관계 구축
        children_map = {}  # {(depth, idx): [(child_depth, child_idx), ...]}
        
        for d in range(self.depth):
            width = self.depth_widths[d] if d < len(self.depth_widths) else 0
            for i in range(width):
                if d > 0:
                    parent_idx = self.parents_matrix[d, i].item()
                    parent_key = (d-1, parent_idx)
                    if parent_key not in children_map:
                        children_map[parent_key] = []
                    children_map[parent_key].append((d, i))
        
        # 재귀적으로 트리 출력
        def print_node(depth, idx, prefix="", is_last=True):
            width = self.depth_widths[depth] if depth < len(self.depth_widths) else 0
            if idx >= width:
                return
            
            token_id = self.input_ids_matrix[depth, idx].item()
            weight = self.weight_matrix[depth, idx].item()
            
            # 토큰 텍스트 변환
            if tokenizer:
                try:
                    token_text = tokenizer.decode([token_id])
                    token_text = repr(token_text)[:15]  # 길이 제한
                except:
                    token_text = "<?>"
            else:
                token_text = f"id={token_id}"
            
            # 현재 노드 출력
            connector = "└─" if is_last else "├─"
            print(f"{prefix}{connector} [{depth},{idx:2d}] {token_text:15s} (w={weight:.4f})")
            
            # 자식 노드들 출력
            node_key = (depth, idx)
            if node_key in children_map:
                children = children_map[node_key]
                extension = "   " if is_last else "│  "
                for i, child in enumerate(children):
                    is_last_child = (i == len(children) - 1)
                    print_node(child[0], child[1], prefix + extension, is_last_child)
        
        # Depth 0의 모든 노드부터 시작
        width_0 = self.depth_widths[0] if len(self.depth_widths) > 0 else 0
        for i in range(width_0):
            is_last = (i == width_0 - 1)
            print_node(0, i, "", is_last)
        
        print("="*100 + "\n")