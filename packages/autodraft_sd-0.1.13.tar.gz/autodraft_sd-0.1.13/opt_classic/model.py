import copy
import json
import time
import sys
import torch
import torch.nn as nn
from transformers import PreTrainedModel, PretrainedConfig,AutoConfig
from .modeling_llama_kv import LlamaForCausalLM as KVLlamaForCausalLM
from .utils import *
from .kv_cache import initialize_past_key_values
from transformers import AutoTokenizer
import os
from huggingface_hub import hf_hub_download
from .configs import EConfig

from .tree import Tree


class SPModel(nn.Module):

    def __init__(
            self,
            base_model,
            base_model_name_or_path,
            draft_model,
    ):

        super().__init__()
        self.base_model = base_model
        self.config = base_model.config
        self.hidden_size = base_model.lm_head.weight.shape[-1]
        self.vocab_size = base_model.lm_head.weight.shape[0]
        self.base_model_name_or_path = base_model_name_or_path
        self.tokenizer = AutoTokenizer.from_pretrained(self.base_model_name_or_path)
        self.draft_model = draft_model
        self.draft_stable_kv=None


    def get_tokenizer(self):
        return self.tokenizer

    @classmethod
    def from_pretrained(
            cls,
            Type="LLaMA",
            base_model_path=None,
            draft_model_path=None,
            **kwargs,
    ):
        base_model = KVLlamaForCausalLM.from_pretrained(
            base_model_path, **kwargs,
            token=os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN") or None
        )
        draft_model = KVLlamaForCausalLM.from_pretrained(
            draft_model_path, **kwargs,
            token=os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN") or None
        )

        model = cls(
            base_model,
            base_model_path,
            draft_model
        )
        
        return model

    def forward(
            self,
            input_ids=None,
            attention_mask=None,
            tree_attention_mask=None,
            labels=None,
            past_key_values=None,
            output_orig=False,
            position_ids=None,
            init=True,
            nodes=None,
            threshold=None,
            max_depth=None,
            logits_processor=None
    ):

        with torch.inference_mode():
            # Pass input through the base model
            outputs = self.base_model.model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                tree_attention_mask=tree_attention_mask,
                past_key_values=past_key_values,
                position_ids=position_ids,
            )
            if output_orig:
                orig = self.base_model.lm_head(outputs[0])
            hidden_states = outputs[0].clone()
        if init:
            if logits_processor is not None:
                logits = orig[:, -1]
                logits = logits_processor(None, logits)
                probabilities = torch.nn.functional.softmax(logits, dim=1)
                token = torch.multinomial(probabilities, 1)
            else:
                token = torch.argmax(orig[:, -1])
                token = token[None, None]
            input_ids = torch.cat((input_ids, token.to(input_ids.device)), dim=1)
            # Clone the output hidden states

            input_ids, position_ids, tree_attention_mask,parent,tree_depth=self.draft(input_ids,nodes,threshold,max_depth)


            return input_ids,position_ids,tree_attention_mask,token,parent,tree_depth
        else:

            return outputs, orig, hidden_states

    def process_tree_mask(self, tree_attention_mask, init_len):
        attention_mask=torch.full((tree_attention_mask.size(0), init_len), 0, device=tree_attention_mask.device)
        mask_dtype = tree_attention_mask.dtype if torch.is_floating_point(tree_attention_mask) else torch.float16
        mask_min = torch.tensor(torch.finfo(mask_dtype).min, dtype=mask_dtype, device=tree_attention_mask.device)
        zero_val = torch.tensor(0.0, dtype=mask_dtype, device=tree_attention_mask.device)
        tree_mask = torch.where(tree_attention_mask == 0, mask_min, zero_val)
        attention_mask=torch.cat([attention_mask,tree_mask],dim=-1)
        attention_mask = attention_mask[None, None, :, :]
        return attention_mask

    @torch.no_grad()
    def draft(self,input_ids,nodes,threshold,max_depth,print_time=False,print_tree=False):
        len_posi = input_ids.shape[1]-1

        if print_time:
            torch.cuda.synchronize()
            s = time.time()

        if hasattr(self, "draft_stable_kv") and self.draft_stable_kv is not None:
            kv_len = self.draft_stable_kv[0][0].shape[2]
            draft_outputs = self.draft_model.model(
                input_ids=input_ids[:, kv_len:].to(self.draft_model.model.embed_tokens.weight.device),
                past_key_values=self.draft_stable_kv,
                return_kv=True,
                is_draft=True
            )
        else:
            draft_outputs = self.draft_model.model(
                input_ids=input_ids.to(self.draft_model.model.embed_tokens.weight.device),
                return_kv=True,
                is_draft=True
            )

        self.draft_stable_kv=draft_outputs[1]
        past_key_values=self.draft_stable_kv

        init_len = past_key_values[0][0].size(2)

        last_hidden=draft_outputs[0][:,-1]
        last_headout = self.draft_model.lm_head(last_hidden)

        tree = Tree(nodes, last_hidden.device, threshold, max_depth)

        if print_tree:
            print(f"\n=== Tree Initialization ===")
            print(f"Nodes: {nodes}, Threshold: {threshold}, Max Depth: {max_depth}")
            print(f"Initial logits shape: {last_headout.shape}")

        logits = last_headout.unsqueeze(0)
        end = False
        step = 0
        while not end:
            if print_time:
                torch.cuda.synchronize()
                ss = time.time()

            if print_tree:
                print(f"\n--- Step {step} - Before tree.update ---")
                print(f"Current depth: {tree.depth}")
                print(f"Current weight: {tree.weight}")
                print(f"Logits shape: {logits.shape}")
                print(f"Logits sample (top 5): {torch.topk(logits[0], 5).values}")

            tree_output = tree.update(
                torch.softmax(logits.to(last_hidden.device), dim=-1, dtype=torch.float32))

            if print_tree:
                print(f"--- Step {step} - After tree.update ---")
                print(f"New depth: {tree.depth}")
                print(f"New weight: {tree.weight}")
                print(f"Is final: {tree_output['is_final']}")
                print(f"Input IDs shape: {tree_output['input_ids'].shape}")
                print(f"Position IDs: {tree_output['position_ids']}")
                print(f"Parent last shape: {tree_output['parent_last'].shape}")
                
                # Print tree structure
                if tree.depth > 0:
                    print(f"Tree structure:")
                    for d in range(min(tree.depth, 3)):  # Show first 3 levels
                        start_idx = d * nodes
                        end_idx = min((d + 1) * nodes, tree.input_ids_matrix[d].shape[0])
                        tokens = tree.input_ids_matrix[d][:end_idx]
                        weights = tree.weight_matrix[d][:end_idx]
                        print(f"  Level {d}: tokens={tokens.tolist()}, weights={weights.tolist()}")
                    if tree.depth > 3:
                        print(f"  ... (showing first 3 levels only)")

            if print_time:
                torch.cuda.synchronize()
                ue = time.time()
                print("tree update time", ue - ss)

            input_ids = tree_output["input_ids"].unsqueeze(0)
            position_ids = tree_output["position_ids"] + len_posi

            if tree_output["is_final"]:
                if print_tree:
                    print(f"\n=== Tree Finalization ===")
                    print(f"Final depth: {tree.depth}")
                    print(f"Final weight: {tree.weight}")
                    print(f"Total nodes: {tree.depth * nodes}")
                    print(f"Final input_ids: {tree_output['input_ids'].tolist()}")
                    print(f"Final position_ids: {tree_output['position_ids'].tolist()}")
                break
            tree_attention_mask_with_kv=self.process_tree_mask(tree_output["attention_mask"],init_len)
            if print_time:
                torch.cuda.synchronize()
                ds = time.time()

            draft_outputs = self.draft_model.model(
                input_ids=input_ids,
                position_ids=position_ids,
                past_key_values=past_key_values,
                tree_attention_mask=tree_attention_mask_with_kv,
                return_kv=True,
                is_draft=True
            )
            if print_time:
                torch.cuda.synchronize()
                de = time.time()
                print("draft forwar time", de - ds)

            past_key_values=draft_outputs[1]
            last_hidden = draft_outputs[0]
            last_headout = self.draft_model.lm_head(last_hidden)
            logits = last_headout
            if print_time:
                torch.cuda.synchronize()
                es = time.time()
                print("draft step time",es-ss)
            step += 1


        if print_time:
            torch.cuda.synchronize()
            e = time.time()
            print("total draft time",e-s)

        return input_ids, position_ids, tree_output["attention_mask"],tree_output["parent_last"], tree.depth

    @torch.no_grad()
    def draft_fixed_token_tree(self, input_ids, nodes, threshold, max_depth, print_time=False, print_tree=False):
        """
        고정된 토큰 트리를 생성하는 함수
        동적 트리 생성 대신 미리 정의된 고정된 구조로 토큰 트리를 생성
        """
        len_posi = input_ids.shape[1]-1

        if print_time:
            torch.cuda.synchronize()
            s = time.time()

        if hasattr(self, "draft_stable_kv") and self.draft_stable_kv is not None:
            kv_len = self.draft_stable_kv[0][0].shape[2]
            draft_outputs = self.draft_model.model(
                input_ids=input_ids[:, kv_len:].to(self.draft_model.model.embed_tokens.weight.device),
                past_key_values=self.draft_stable_kv,
                return_kv=True,
                is_draft=True
            )
        else:
            draft_outputs = self.draft_model.model(
                input_ids=input_ids.to(self.draft_model.model.embed_tokens.weight.device),
                return_kv=True,
                is_draft=True
            )

        self.draft_stable_kv=draft_outputs[1]
        past_key_values=self.draft_stable_kv

        init_len = past_key_values[0][0].size(2)
        last_hidden=draft_outputs[0][:,-1]
        last_headout = self.draft_model.lm_head(last_hidden)

        if print_tree:
            print(f"\n=== Fixed Token Tree Generation ===")
            print(f"Nodes: {nodes}, Threshold: {threshold}, Max Depth: {max_depth}")
            print(f"Initial logits shape: {last_headout.shape}")

        # 고정된 토큰 트리 생성 - 병렬 처리 방식
        # 각 레벨에서 nodes 개수만큼의 토큰을 병렬로 생성
        all_input_ids = []
        all_position_ids = []
        all_attention_masks = []
        all_parents = []
        
        current_input_ids = input_ids.clone()
        current_position = len_posi
        
        # 고정된 깊이만큼 반복
        for depth in range(max_depth):
            if print_tree:
                print(f"\n--- Fixed Tree Level {depth} (병렬 생성) ---")
            
            if print_time:
                torch.cuda.synchronize()
                level_start = time.time()
            
            if depth == 0:
                # 첫 번째 레벨: 기존 입력에서 직접 생성
                # 모든 노드가 같은 입력을 기반으로 생성
                level_input_ids = current_input_ids.repeat(nodes, 1)  # [nodes, seq_len]
                level_position_ids = torch.arange(
                    current_position + 1, 
                    current_position + 1 + nodes, 
                    device=input_ids.device
                )
                
                # 병렬로 모든 노드의 토큰 생성
                draft_outputs = self.draft_model.model(
                    input_ids=level_input_ids,
                    position_ids=level_position_ids,
                    past_key_values=past_key_values,
                    return_kv=True,
                    is_draft=True
                )
                
                # 모든 노드의 logits 추출
                level_logits = self.draft_model.lm_head(draft_outputs[0][:, -1])  # [nodes, vocab_size]
                
            else:
                # 두 번째 레벨 이후: 이전 레벨의 토큰들을 기반으로 생성
                # 이전 레벨의 첫 번째 토큰을 각 노드의 입력으로 사용
                prev_tokens = all_input_ids[depth-1][:1].repeat(nodes, 1)  # [nodes, 1]
                level_input_ids = torch.cat([current_input_ids.repeat(nodes, 1), prev_tokens], dim=1)
                level_position_ids = torch.arange(
                    current_position + depth + 1, 
                    current_position + depth + 1 + nodes, 
                    device=input_ids.device
                )
                
                # 병렬로 모든 노드의 토큰 생성
                draft_outputs = self.draft_model.model(
                    input_ids=level_input_ids,
                    position_ids=level_position_ids,
                    past_key_values=past_key_values,
                    return_kv=True,
                    is_draft=True
                )
                
                # 모든 노드의 logits 추출
                level_logits = self.draft_model.lm_head(draft_outputs[0][:, -1])  # [nodes, vocab_size]
            
            # 모든 노드의 토큰을 병렬로 선택
            if threshold > 0:
                # Threshold 기반 선택
                probs = torch.softmax(level_logits, dim=-1)
                top_probs, top_indices = torch.topk(probs, k=min(100, probs.size(-1)), dim=-1)
                
                # 각 노드별로 threshold를 만족하는 토큰 선택
                selected_tokens = []
                for i in range(nodes):
                    valid_indices = top_indices[i][top_probs[i] > threshold]
                    if len(valid_indices) > 0:
                        selected_tokens.append(valid_indices[0])
                    else:
                        selected_tokens.append(torch.argmax(probs[i], dim=-1))
                
                level_tokens = torch.stack(selected_tokens)
            else:
                # Greedy 선택 (병렬)
                level_tokens = torch.argmax(level_logits, dim=-1)  # [nodes]
            
            # 레벨별 결과 저장
            level_positions = torch.arange(
                current_position + depth + 1, 
                current_position + depth + 1 + nodes, 
                device=input_ids.device
            )
            level_attention = torch.ones(nodes, device=input_ids.device)
            level_parents = torch.zeros(nodes, device=input_ids.device) if depth == 0 else torch.arange(nodes, device=input_ids.device) % nodes
            
            all_input_ids.append(level_tokens)
            all_position_ids.append(level_positions)
            all_attention_masks.append(level_attention)
            all_parents.append(level_parents)
            
            if print_time:
                torch.cuda.synchronize()
                level_end = time.time()
                print(f"Level {depth} 병렬 생성 시간: {level_end - level_start:.4f}s")
            
            if print_tree:
                print(f"Level {depth} tokens: {level_tokens[:5].tolist()}...")  # 처음 5개만 출력
                print(f"Level {depth} positions: {level_positions[:5].tolist()}...")
        
        # 최종 결과 구성
        final_input_ids = torch.cat(all_input_ids).unsqueeze(0)
        final_position_ids = torch.cat(all_position_ids)
        final_attention_mask = torch.stack(all_attention_masks)
        final_parents = torch.cat(all_parents)
        
        if print_time:
            torch.cuda.synchronize()
            e = time.time()
            print(f"Total fixed tree generation time: {e-s:.4f}s")
        
        if print_tree:
            print(f"\n=== Fixed Tree Finalization ===")
            print(f"Total levels: {max_depth}")
            print(f"Total nodes: {max_depth * nodes}")
            print(f"Final input_ids shape: {final_input_ids.shape}")
            print(f"Final position_ids shape: {final_position_ids.shape}")
        
        return final_input_ids, final_position_ids, final_attention_mask, final_parents, max_depth

    @torch.no_grad()
    def spgenerate(
            self,
            input_ids,
            temperature=0.0,
            top_p=0.0,
            top_k=0.0,
            max_new_tokens=512,
            max_length=2048,
            nodes=50,
            threshold=0.5,
            max_depth=10,
            print_time=False,

    ):
        if temperature > 1e-5:
            logits_processor = prepare_logits_processor(temperature=temperature, top_p=top_p, top_k=top_k)
        else:
            logits_processor = None


        assert input_ids.shape[0] == 1, "Only support batch size 1 for now!!"
        # Avoid modifying the input_ids in-place
        input_ids = input_ids.clone()
        self.draft_stable_kv=None

        # Initialize the past key and value states
        if hasattr(self, "past_key_values"):
            past_key_values = self.past_key_values
            past_key_values_data = self.past_key_values_data
            current_length_data = self.current_length_data
            # Reset the past key and value states
            current_length_data.zero_()
        else:
            (
                past_key_values,
                past_key_values_data,
                current_length_data,
            ) = initialize_past_key_values(self.base_model)
            self.past_key_values = past_key_values
            self.past_key_values_data = past_key_values_data
            self.current_length_data = current_length_data

        input_len = input_ids.shape[1]
        draft_input_ids,draft_position_ids,tree_attention_mask,last_token,parent,tree_depth = self(
            input_ids=input_ids, past_key_values=past_key_values,  output_orig=True, nodes=nodes, threshold=threshold, max_depth=max_depth, logits_processor=logits_processor
        )

        draft_input_ids=torch.cat([last_token.to(draft_input_ids.device),draft_input_ids],dim=-1)
        draft_position_ids=torch.cat([torch.tensor([draft_position_ids[0]-1],device=draft_position_ids.device), draft_position_ids],dim=-1)
        tree_attention_mask=torch.cat([torch.zeros(1,tree_attention_mask.size(1),dtype=tree_attention_mask.dtype,device=tree_attention_mask.device),tree_attention_mask],dim=0)
        tree_attention_mask = torch.cat([torch.ones(tree_attention_mask.size(0), 1,dtype=tree_attention_mask.dtype,device=tree_attention_mask.device), tree_attention_mask],
                                        dim=1)

        new_token = 0

        for idx in range(max_length):
            if print_time:
                print(idx)
                torch.cuda.synchronize()
                s = time.time()

            assert past_key_values[0][0].shape[2]==draft_position_ids[0]



            logits, hidden_state_new, outputs = tree_decoding(
                self,
                draft_input_ids,
                past_key_values,
                draft_position_ids,
                tree_attention_mask
            )

            input_ids,best_candidate,accept_length,draft_input_ids,draft_position_ids,tree_attention_mask,parent,tree_depth=verify(input_ids,
                                                                      logits,
                                                                      draft_input_ids,
                                                                      draft_position_ids,
                                                                      tree_attention_mask,
                                                                      past_key_values_data,
                                                                      current_length_data,
                                                                      parent,
                                                                      self,
                                                                      nodes,
                                                                      threshold,
                                                                      max_depth,
                                                                      logits_processor)


            new_token+=accept_length+1
            if print_time:
                torch.cuda.synchronize()
                e = time.time()
                print("total step time:",e-s)

            if self.tokenizer.eos_token_id in input_ids[0, input_len:].tolist():
                break
            if new_token > max_new_tokens:
                break
            if input_ids.shape[1] > max_length:
                break
        print("total steps:",idx)
        print('new_token:',new_token)
        return input_ids
