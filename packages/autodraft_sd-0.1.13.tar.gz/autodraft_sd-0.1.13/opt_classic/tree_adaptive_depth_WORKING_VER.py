import torch
import random
import time
import json
import os

class Tree:
    def __init__(
        self,
        nnodes,
        device,
        max_depth,
        per_token_probability_bound=0.0,
        per_path_probability_bound=0.0,
        fixed_width=None,
        fixed_nnodes=False,
        fixed_depth=False,
        min_width=3,
        profile_data=None,
        target_profile_data=None,
        draft_per_sec_cost=0.0,
        target_per_sec_cost=0.0,
        cost_sensitivity=0.0,
        per_token_draft_to_target_transfer_time=0.0,
        per_token_target_to_draft_transfer_time=0.0,
    ):
        self.max_nnodes = nnodes  # 최대 노드 수 (max_width)
        self.device = device
        self.depth = 0
        self.weight = 0
        self.per_token_probability_bound = per_token_probability_bound  # 각 토큰의 확률이 이 값보다 작으면 버림
        self.per_path_probability_bound = per_path_probability_bound  # 각 경로의 확률이 이 값보다 작으면 버림
        self.max_depth = max_depth
        self.fixed_width = fixed_width  # 프로파일링용: 특정 width로 고정 (None이면 동적)
        self.fixed_nnodes = fixed_nnodes
        self.fixed_depth = fixed_depth
        self.min_width = min_width
        # 프로파일링 데이터 (width별 model_call_avg_time_ms를 포함하는 딕셔너리)
        self.profile_data = profile_data  # {width: {"model_call_avg_time_ms": ...}, ...}
        # Target 프로파일링 데이터 (width_depth_nnodes별 avg_time_ms를 포함하는 딕셔너리)
        self.target_profile_data = target_profile_data  # {"width_X_depth_Y_nnodes_Z": {"width": X, "depth": Y, "max_nnodes": Z, "avg_time_ms": ...}, ...}
        # 이전 tree (확장 이전)의 정보
        self.prev_final_nnodes = 0  # 이전 tree의 top_index 개수 (final_width)
        self.prev_depth = 0  # 이전 tree의 depth
        self.prev_width = 0  # 이전 tree의 width
        # 토큰별 전송 시간 (DraftRunner에서 업데이트된 값 사용)
        self.per_token_draft_to_target_transfer_time = per_token_draft_to_target_transfer_time  # 토큰별 Draft → Target 전송 시간 (초 단위)
        self.per_token_target_to_draft_transfer_time = per_token_target_to_draft_transfer_time  # 토큰별 Target → Draft 전송 시간 (초 단위)
        # 초당 비용
        self.draft_per_sec_cost = draft_per_sec_cost
        self.target_per_sec_cost = target_per_sec_cost
        # Cost sensitivity (0 to infinity)
        self.cost_sensitivity = cost_sensitivity
        # Depth별 통계 수집용 (JSON 저장용)
        self.depth_stats = {}  # {depth: {"prev_sum_expected_accepted_length": [...], "sum_expected_accepted_length": [...], "per_token_latency_diff": [...], "per_token_cost_diff": [...]}}
        # 매트릭스는 최대 크기로 할당
        self.weight_matrix = torch.zeros([max_depth, self.max_nnodes], device=self.device)
        self.input_ids_matrix = torch.zeros([max_depth, self.max_nnodes], dtype=torch.long, device=self.device)
        self.parents_matrix = torch.zeros([max_depth, self.max_nnodes], dtype=torch.long, device=self.device)
        # depth별 실제 width 저장
        self.depth_widths = []
        # 현재 depth의 width (동적으로 변경됨)
        self.current_width = 0
        # width별 model.model() 호출 시간 측정용
        self.width_times = {}  # {width: [time1, time2, ...]}
        # 이번 tree 생성 동안 draft 모델 호출에 사용된 시간의 총합
        self.draft_total_time = 0.0
        # 이전 draft 모델 호출에 사용된 시간의 총합
        self.prev_draft_total_time = 0.0
        # 이번 tree 생성 동안 draft 모델 호출에 사용된 예상 시간의 총합 (프로파일링 데이터는 draft_time 기준)
        self.expected_draft_total_time = 0.0
        # 예상 accept length의 합
        self.sum_expected_accepted_length = 1.0
        # 이전 예상 accept length의 합
        self.prev_sum_expected_accepted_length = 1.0
        # 이전 계산값 저장 (재사용을 위해)
        self.prev_target_time = 0.2  # 이전 target 시간 (초)
        self.prev_per_token_latency = None  # 이전 per_token_latency
        self.prev_per_token_cost = None  # 이전 per_token_cost
        # breakpoint()
        self.final_nnodes = 0  # 최종 전송할 노드 수

    def initialize(self, logits):
        # 이번 tree 생성 동안 draft 모델 호출에 사용된 시간의 총합 초기화
        self.draft_total_time = 0.0
        # 이번 tree 생성 동안 draft 모델 호출에 사용된 예상 시간의 총합 초기화 (프로파일링 데이터는 draft_time 기준)
        self.expected_draft_total_time = 0.0
        # 이전 depth의 width 초기화 (첫 번째 depth이므로 이전 width가 없음)
        self.prev_final_nnodes = 0  # 이전 tree의 top_index 개수 (final_width)
        self.prev_depth = 0  # 이전 tree의 depth
        self.prev_width = 0  # 이전 tree의 width
        # 예상 accept length의 합 초기화
        self.sum_expected_accepted_length = 1.0
        # 이전 예상 accept length의 합 초기화
        self.prev_sum_expected_accepted_length = 1.0
        # 이전 계산값 초기화
        self.prev_target_time = 0.2
        self.prev_per_token_latency = None
        self.prev_per_token_cost = None
        # Depth별 통계 초기화 (새로운 tree 생성 시)
        self.depth_stats = {}
        
        # 첫 번째 depth의 width를 확률 바운드를 적용하여 결정
        # initialize의 경우 이전 depth가 없으므로 per_token_probability_bound만 적용
        single_logits = logits[0][-1]  # (vocab_size,)
        
        # 1. per_token_probability_bound보다 낮은 값을 0으로 변경
        probs = torch.softmax(single_logits, dim=-1)  # (vocab_size,)
        if self.per_token_probability_bound > 0.0:
            probs = torch.where(probs >= self.per_token_probability_bound, probs, torch.zeros_like(probs))
        
        # 2. 남아있는 노드 중 0이 아닌 것의 개수를 계산하여 current_width 설정
        # initialize에서는 경로 확률을 구할 수 없으므로 per_token만 확인
        if self.fixed_width is not None:
            # 프로파일링 모드: fixed_width로 고정
            self.current_width = min(self.fixed_width, self.max_nnodes)
        else:
            valid_mask = probs > 0
            valid_count = valid_mask.sum().item()
            self.current_width = min(max(valid_count, 1), self.max_nnodes)  # 최소 1, 최대 max_nnodes
        self.depth_widths.append(self.current_width)
        
        # 3. 토큰 확률이 높은 순서로 current_width개 선택
        top_logits, ids = torch.topk(probs, k=self.current_width, dim=-1)
        # 원본 logits에서 선택된 토큰들의 logits 값 가져오기
        selected_logits = single_logits[ids]
        self.weight_matrix[self.depth, :self.current_width].copy_(selected_logits)
        self.input_ids_matrix[self.depth, :self.current_width].copy_(ids)
        
        rows = torch.arange(self.current_width, device=self.device)
        self.parents_matrix[0, :self.current_width].copy_(rows)
        
        position_id = torch.zeros([self.current_width], dtype=torch.long, device=self.device)
        tri = torch.eye(self.current_width, dtype=torch.int8, device=self.device)
        
        # max_depth가 1이면 initialize 후 바로 종료
        is_final = (self.depth + 1 >= self.max_depth)
        
        output_dict = {
            "input_ids": ids,   # [DH] logits 중 선택된 상위 N개 토큰의 인덱스 (N은 랜덤)
            "position_ids": position_id + 1,   # [DH] 몇 번째 depth인지, initialize 시 1로 초기화됨
            "attention_mask": tri,  # [DH] attention mask is identity matrix로 초기화됨
            "parent_last": rows,
            "is_final": is_final
        }
        self.depth += 1
        return output_dict
    
    def add(self, logits):
        self.prev_width = self.current_width  # 이전 depth의 width
        
        # logits는 이미 확률로 변환된 상태 (softmax 적용됨)
        probs = logits[0]  # (self.prev_width, vocab_size)
        
        # 이하 width 결정 알고리즘 
        # 1. per_token_probability_bound보다 낮은 확률을 0으로 설정
        if self.per_token_probability_bound > 0.0:
            probs = torch.where(probs >= self.per_token_probability_bound, probs, torch.zeros_like(probs))
        
        # 2. 루트로부터의 경로 확률을 구하고, per_path_probability_bound보다 낮은 경우 0으로 변경
        last_layer_weights = self.weight_matrix[self.depth-1, :self.prev_width].unsqueeze(1)  # (self.prev_width, 1)
        path_probs = probs * last_layer_weights  # (self.prev_width, vocab_size) - 경로 확률 = 부모의 경로 확률 * 자식의 토큰 확률
        
        # per_path_probability_bound보다 낮은 경로 확률을 0으로 설정
        if self.per_path_probability_bound > 0.0:
            path_probs = torch.where(path_probs >= self.per_path_probability_bound, path_probs, torch.zeros_like(path_probs))
        
        # 3. flat_path_probs 계산 (항상 필요)
        flat_path_probs = path_probs.view(-1)  # (self.prev_width * vocab_size)
        
        # 4. 남아있는 노드 중 0이 아닌 것의 개수를 계산하여 current_width 설정
        if self.fixed_width is not None:
            # 프로파일링 모드: fixed_width로 고정
            self.current_width = min(self.fixed_width, self.max_nnodes)
        else:
            valid_mask = flat_path_probs > 0
            valid_count = valid_mask.sum().item()
            self.current_width = min(max(valid_count, 1), self.max_nnodes)  # 최소 1, 최대 max_nnodes
        self.depth_widths.append(self.current_width)
        
        # 5. 경로 확률이 높은 순서로 current_width개 선택
        global_top_logits, global_top_idx = torch.topk(flat_path_probs, k=self.current_width, dim=-1)
        
        # global_top_idx를 (self.prev_width, vocab_size) 좌표로 변환
        vocab_size = probs.size(1)
        parents = global_top_idx // vocab_size  # 부모 인덱스
        input_ids = global_top_idx % vocab_size  # 토큰 ID
        
        # parents 인덱스가 self.prev_width 범위 내에 있는지 확인 및 클램핑
        parents = torch.clamp(parents, 0, self.prev_width - 1)
        
        self.parents_matrix[self.depth, :self.current_width].copy_(parents)
        self.weight_matrix[self.depth, :self.current_width].copy_(global_top_logits)
        self.input_ids_matrix[self.depth, :self.current_width].copy_(input_ids)
        
        rows = torch.arange(self.current_width, device=self.device)
        kv_cache_mask = torch.zeros([self.current_width, self.prev_width], dtype=torch.int8, device=self.device) 
        # [DH] (current_width, self.prev_width) 형태의 matrix. 현새 depth에서 선택된 토큰들의 부모가 몇 번째 parent인지를 나타냄. 
        # (첫 번째 토큰의 부모의 index가 3이면 (0, 3) 위치에 1로 체크됨)
        kv_cache_mask[rows, parents] = 1
        
        # kv_mask 업데이트
        if self.depth == 1:
            kv_mask = kv_cache_mask
        else:
            # 이전 kv_mask에서 parent에 해당하는 행만 선택
            prev_kv_mask = getattr(self, '_prev_kv_mask', torch.zeros([self.prev_width, 0], dtype=torch.int8, device=self.device))
            kv_mask = torch.cat([prev_kv_mask[parents], kv_cache_mask], dim=1)
        
        self._prev_kv_mask = kv_mask
        
        tri = torch.eye(self.current_width, dtype=torch.int8, device=self.device)
        attention_mask = torch.cat([kv_mask, tri], dim=1)    # [DH] 선택된 child들의 attention mask
        
        position_id = torch.zeros([self.current_width], dtype=torch.long, device=self.device)
        output_dict = {
            "input_ids": input_ids,  # [DH] self.prev_width개의 부모로부터 나온 자식 중 선택된 current_width개
            "position_ids": position_id + (self.depth + 1),  # [DH] 몇 번째 depth인지
            "attention_mask": attention_mask,
            "parent_last": parents,
            "is_final": False
        }
        self.depth += 1
        return output_dict
    
    def generate_attention_mask(self, parents, final_width):
        attention_mask = torch.eye(final_width, dtype=torch.int8, device=self.device)
        grandp = parents.clone()
        for _ in range(self.depth - 2):
            rows = torch.arange(final_width, device=self.device)
            attention_mask[rows, grandp] = 1
            grandp = grandp[parents]
        return attention_mask

    def get_objective_value(self, valid_weights):
        """
        objective_value를 최소화하는 final_nnodes를 찾는 함수
        
        Args:
            valid_weights: 각 depth별 weight 텐서 리스트
        
        Returns:
            tuple: (objective_value, top_index, weight, per_token_latency_diff, per_token_cost_diff, 
                    current_target_time, current_per_token_latency, current_per_token_cost)
        """
        flat_weights = torch.cat(valid_weights)
        max_available_nodes = len(flat_weights)
        
        # fixed_nnodes가 True이면 max_nnodes로 고정 (안전한 범위 내에서)
        if self.fixed_nnodes:
            # max_nnodes와 실제 사용 가능한 노드 수 중 작은 값 사용
            fixed_nnodes_val = min(self.max_nnodes, max_available_nodes) if max_available_nodes > 0 else 1
            candidate_nnodes = [fixed_nnodes_val]
        else:
            # final_nnodes 후보 리스트
            candidate_nnodes = [3, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
            # 실제 사용 가능한 노드 수를 초과하지 않도록 필터링
            candidate_nnodes = [n for n in candidate_nnodes if n <= max_available_nodes]
            if not candidate_nnodes:
                # 후보가 없으면 최대 사용 가능한 노드 수 사용
                candidate_nnodes = [max_available_nodes] if max_available_nodes > 0 else [1]
        
        # 이전 target 시간 재사용
        prev_target_time = self.prev_target_time
        
        # 이전 target 시간이 아직 계산되지 않은 경우에만 계산 (첫 번째 호출인 경우)
        if self.prev_final_nnodes > 0 and self.target_profile_data is not None and prev_target_time == 0.2:
            prev_tree_depth_for_key = self.prev_depth if self.prev_depth > 0 else 1
            prev_profile_key = f"width_{self.prev_final_nnodes}_depth_{prev_tree_depth_for_key}_nnodes_{self.prev_final_nnodes}"
            if prev_profile_key in self.target_profile_data:
                prev_target_time_ms = self.target_profile_data[prev_profile_key].get("avg_time_ms", 0.0)
                prev_target_time = prev_target_time_ms / 1000.0
                self.prev_target_time = prev_target_time
        
        # 이전 per_token_latency와 per_token_cost 재사용 (첫 번째 호출이 아니면)
        safe_prev_sum = max(1.0, self.prev_sum_expected_accepted_length) if self.prev_sum_expected_accepted_length > 0 else 1.0
        if self.prev_per_token_latency is not None:
            prev_per_token_latency = self.prev_per_token_latency
        else:
            prev_per_token_latency = (self.prev_draft_total_time+self.per_token_draft_to_target_transfer_time*self.prev_final_nnodes+prev_target_time)/safe_prev_sum
        
        if self.prev_per_token_cost is not None:
            prev_per_token_cost = self.prev_per_token_cost
        else:
            prev_per_token_cost = (self.prev_draft_total_time*self.draft_per_sec_cost + prev_target_time*self.target_per_sec_cost)/safe_prev_sum
        
        # 각 후보에 대해 objective_value 계산
        best_objective_value = float('inf')
        best_final_nnodes = candidate_nnodes[0]
        best_top_index = None
        best_weight = 0.0
        best_per_token_latency_diff = 0.0
        best_per_token_cost_diff = 0.0
        best_current_target_time = 0.2
        best_sum_expected_accepted_length = 1.0
        
        for candidate_nnodes_val in candidate_nnodes:
            # topk로 선택
            top_weights, top_index = torch.topk(flat_weights, k=candidate_nnodes_val, dim=-1)
            weight = top_weights.sum()
            
            # 선택된 top_index들에 대해서만 sum_expected_accepted_length 계산
            # top_index를 depth와 column으로 변환
            selected_depth_probs = []
            cumsum = 0
            for d in range(self.depth - 1):
                depth_width = self.depth_widths[d]
                # 이 depth에 속하는 top_index들 찾기
                depth_mask = (top_index >= cumsum) & (top_index < cumsum + depth_width)
                if depth_mask.any():
                    # 이 depth에서 선택된 노드들의 weight 합
                    depth_selected_indices = top_index[depth_mask] - cumsum
                    depth_weights = valid_weights[d][depth_selected_indices]
                    depth_prob_sum = depth_weights.sum()
                    if isinstance(depth_prob_sum, torch.Tensor):
                        prob_val = depth_prob_sum.item()
                    else:
                        prob_val = float(depth_prob_sum)
                    # NaN 및 유효하지 않은 값 필터링
                    if not (prob_val != prob_val or prob_val < 0 or prob_val > 1):
                        selected_depth_probs.append((d, prob_val))
                cumsum += depth_width
            
            # 선택된 노드들에 대한 adjusted_depth_probs 계산
            if selected_depth_probs:
                # depth별로 정렬
                selected_depth_probs.sort(key=lambda x: x[0])
                depth_probs_list = [prob for _, prob in selected_depth_probs]
                
                adjusted_depth_probs = []
                for i in range(len(depth_probs_list)):
                    if i == len(depth_probs_list) - 1:
                        adj_prob = depth_probs_list[i]
                    else:
                        adj_prob = max(0.0, depth_probs_list[i] - depth_probs_list[i + 1])
                    
                    if adj_prob != adj_prob or adj_prob < 0:
                        adj_prob = 0.0
                    adjusted_depth_probs.append(adj_prob)
                
                # 각 레이어에 (depth+1)을 곱해서 합산
                if adjusted_depth_probs:
                    expected_sum = sum(adj_prob * float(selected_depth_probs[i][0] + 1) for i, adj_prob in enumerate(adjusted_depth_probs))
                    if expected_sum != expected_sum or expected_sum <= 0:
                        sum_expected_accepted_length = 1.0
                    else:
                        sum_expected_accepted_length = float(expected_sum)
                else:
                    sum_expected_accepted_length = 1.0
            else:
                sum_expected_accepted_length = 1.0
            
            # 현재 tree의 target 시간 계산
            current_target_time = 0.2
            if self.target_profile_data is not None:
                current_profile_key = f"width_{self.current_width}_depth_{self.depth}_nnodes_{candidate_nnodes_val}"
                if current_profile_key in self.target_profile_data:
                    current_target_time_ms = self.target_profile_data[current_profile_key].get("avg_time_ms", 0.0)
                    current_target_time = current_target_time_ms / 1000.0
            
            # objective_value 계산
            safe_sum = max(1.0, sum_expected_accepted_length) if sum_expected_accepted_length > 0 else 1.0
            per_token_latency = (self.draft_total_time+self.per_token_draft_to_target_transfer_time*candidate_nnodes_val+current_target_time)/safe_sum
            per_token_latency_diff = per_token_latency - prev_per_token_latency
            
            per_token_cost = (self.draft_total_time*self.draft_per_sec_cost + current_target_time*self.target_per_sec_cost)/safe_sum
            per_token_cost_diff = per_token_cost - prev_per_token_cost
            
            objective_value = per_token_latency_diff + self.cost_sensitivity * per_token_cost_diff
            
            # 최소 objective_value 업데이트
            if objective_value < best_objective_value:
                best_objective_value = objective_value
                best_final_nnodes = candidate_nnodes_val
                best_top_index = top_index
                best_weight = weight
                best_per_token_latency_diff = per_token_latency_diff
                best_per_token_cost_diff = per_token_cost_diff
                best_current_target_time = current_target_time
                best_sum_expected_accepted_length = sum_expected_accepted_length
        
        # 최종 선택된 값들 설정
        self.final_nnodes = best_final_nnodes
        self.sum_expected_accepted_length = best_sum_expected_accepted_length
        
        # 현재 per_token_latency와 per_token_cost 계산 (다음 호출을 위해 저장)
        safe_sum = max(1.0, best_sum_expected_accepted_length) if best_sum_expected_accepted_length > 0 else 1.0
        current_per_token_latency = (self.draft_total_time+self.per_token_draft_to_target_transfer_time*self.final_nnodes+best_current_target_time)/safe_sum
        current_per_token_cost = (self.draft_total_time*self.draft_per_sec_cost + best_current_target_time*self.target_per_sec_cost)/safe_sum
        
        return best_objective_value, best_top_index, best_weight, best_per_token_latency_diff, best_per_token_cost_diff, best_current_target_time, current_per_token_latency, current_per_token_cost

    def update(self, logits, print_tree=False, tokenizer=None, draft_time=None):
        if self.depth == 0:
            result = self.initialize(logits)
            if print_tree:
                self.print_tree_structure_hierarchical(tokenizer)
            return result
        
        # add() 함수 실행 시간 측정 및 GPU 동기화 (이전 CUDA 연산이 완료되도록 보장)
        if isinstance(logits, torch.Tensor) and logits.is_cuda:
            torch.cuda.synchronize()
        elif isinstance(logits, (list, tuple)) and len(logits) > 0 and isinstance(logits[0], torch.Tensor) and logits[0].is_cuda:
            torch.cuda.synchronize()
        
        # add() 호출 전 시간 측정 시작
        start_time = time.time()
        outputs = self.add(logits)
        
        # GPU 동기화: synchronize()는 add() 내부 CUDA 연산의 완료를 기다리므로 측정 시간에 포함되어야 함
        if isinstance(logits, torch.Tensor) and logits.is_cuda:
            torch.cuda.synchronize()
        elif isinstance(logits, (list, tuple)) and len(logits) > 0 and isinstance(logits[0], torch.Tensor) and logits[0].is_cuda:
            torch.cuda.synchronize()
        
        # synchronize() 후 시간 측정 (add() 내부의 모든 CUDA 연산이 완료된 후)
        elapsed_time = time.time() - start_time
        
        # 이번 tree 생성 동안 draft 모델 호출에 사용된 시간의 총합에 누적
        self.prev_draft_total_time = self.draft_total_time
        # draft_time이 None이 아니면 사용하고, None이면 elapsed_time 사용 (첫 번째 호출인 경우)
        if draft_time is not None:
            self.draft_total_time += draft_time
        else:
            # 첫 번째 호출인 경우 elapsed_time 사용
            self.draft_total_time += elapsed_time
        
        # width별 시간 기록 (add() 함수에서 self.current_width가 설정됨)
        current_width = self.current_width
        
        # 이번 tree 생성 동안 draft 모델 호출에 사용된 예상 시간의 총합에 누적
        # 프로파일링 데이터에서 현재 width에 해당하는 model_call_avg_time_ms를 찾아서 더함 (draft_time 기준)
        if self.profile_data is not None:
            width_str = str(self.prev_width)
            if width_str in self.profile_data:
                avg_time_ms = self.profile_data[width_str].get("model_call_avg_time_ms", 0.0)
                # 밀리초를 초로 변환하여 더함 (프로파일링 데이터는 draft_time 기준)
                self.expected_draft_total_time += avg_time_ms / 1000.0
            else:
                # 프로파일링 데이터에 해당 width가 없으면 실제 측정 draft_time 사용
                if draft_time is not None:
                    self.expected_draft_total_time += draft_time
                else:
                    # 첫 번째 호출인 경우 elapsed_time 사용
                    self.expected_draft_total_time += elapsed_time
        else:
            # 프로파일링 데이터가 없으면 실제 측정 draft_time 사용
            if draft_time is not None:
                self.expected_draft_total_time += draft_time
            else:
                # 첫 번째 호출인 경우 elapsed_time 사용
                self.expected_draft_total_time += elapsed_time
        if current_width not in self.width_times:
            self.width_times[current_width] = []
        self.width_times[current_width].append(elapsed_time)
        
        if print_tree:
            self.print_tree_structure_hierarchical(tokenizer)
        
        # breakpoint()
        
        # 각 depth의 width가 다르므로, 전체 노드 수를 계산
        total_nodes = sum(self.depth_widths[:self.depth-1])
          
        # weight_matrix에서 유효한 값들만 선택
        valid_weights = []
        for d in range(self.depth - 1):
            valid_weights.append(self.weight_matrix[d, :self.depth_widths[d]])
        
        self.prev_sum_expected_accepted_length = self.sum_expected_accepted_length
        
        # objective_value 최소화 하는 알고리즘
        objective_value, top_index, weight, per_token_latency_diff, per_token_cost_diff, current_target_time, current_per_token_latency, current_per_token_cost = self.get_objective_value(valid_weights)
        # print(f"per token latency diff: {per_token_latency_diff}, per token cost diff: {per_token_cost_diff}, objective value: {objective_value}")
        
        # 다음 호출을 위해 현재 값을 이전 값으로 저장
        self.prev_target_time = current_target_time
        self.prev_per_token_latency = current_per_token_latency
        self.prev_per_token_cost = current_per_token_cost
        
        # Depth별 통계 수집 (현재 depth에 대한 값 저장)
        current_depth = self.depth
        if current_depth not in self.depth_stats:
            self.depth_stats[current_depth] = {
                "prev_sum_expected_accepted_length": [],
                "sum_expected_accepted_length": [],
                "per_token_latency_diff": [],
                "per_token_cost_diff": [],
                "objective_value": []
            }
        
        self.depth_stats[current_depth]["prev_sum_expected_accepted_length"].append(float(self.prev_sum_expected_accepted_length))
        self.depth_stats[current_depth]["sum_expected_accepted_length"].append(float(self.sum_expected_accepted_length))
        self.depth_stats[current_depth]["per_token_latency_diff"].append(float(per_token_latency_diff))
        self.depth_stats[current_depth]["per_token_cost_diff"].append(float(per_token_cost_diff))
        self.depth_stats[current_depth]["objective_value"].append(float(objective_value))

        # MobiTree: depth 확장 알고리즘
        if self.depth == 2 and self.depth < self.max_depth:  # depth=2인 경우 무조건 확장
            self.weight = weight
        elif self.fixed_depth and self.depth < self.max_depth:  # fixed_depth=True인 경우 max_depth만 고려
            self.weight = weight
        elif not self.fixed_depth and self.depth < self.max_depth and objective_value < 0:  # fixed_depth=False인 경우 latency/cost 목적함수가 좋아질 때만 확장
            self.weight = weight
        else:   # [DH] 트리 depth 확장이 종료되는 경우.
            # breakpoint()
            # top_index를 depth와 column으로 변환
            rows = torch.zeros_like(top_index)
            cols = top_index.clone()
            cumsum = 0
            for d in range(self.depth - 1):
                mask = (top_index >= cumsum) & (top_index < cumsum + self.depth_widths[d])
                rows[mask] = d  # [DH] 각 토큰의 depth 인덱스
                cols[mask] = top_index[mask] - cumsum  # [DH] 각 토큰의 각 depth에서의 column 인덱스
                cumsum += self.depth_widths[d]
            # breakpoint()
            sorted_indices = torch.argsort(rows)
            rows = rows[sorted_indices]   # [DH] 부모 인덱스 기준 정렬
            cols = cols[sorted_indices]   # [DH] 부모 인덱스 기준 정렬
            
            input_ids = self.input_ids_matrix[rows, cols]
            position_ids = rows + 1
            parents = self.parents_matrix[rows, cols]
            
            # source_idx와 parent_idx 계산
            source_idx = torch.zeros_like(rows)
            parent_idx = torch.zeros_like(rows)
            for i, (r, c) in enumerate(zip(rows, cols)):
                r_item = r.item()
                c_item = c.item()
                # source_idx: 현재 노드의 전역 인덱스
                cumsum = sum(self.depth_widths[:r_item])
                source_idx[i] = cumsum + c_item
                
                # parent_idx: 부모 노드의 전역 인덱스
                if r_item > 0:
                    parent_depth = r_item - 1
                    parent_col = parents[i].item()
                    parent_cumsum = sum(self.depth_widths[:parent_depth])
                    parent_idx[i] = parent_cumsum + parent_col
                else:
                    parent_idx[i] = parents[i]
            # breakpoint()
            # parents_index 계산: 각 노드의 부모가 선택된 노드들 중 몇 번째인지 찾기
            # parent_idx[i]는 i번째 노드의 부모 노드의 전역 인덱스
            # source_idx[j]는 j번째 노드의 전역 인덱스
            # parent_idx[i] == source_idx[j]인 경우, i번째 노드의 부모가 j번째 노드임
            parents_index = torch.zeros(len(top_index), dtype=torch.long, device=self.device)
            for i in range(len(top_index)):
                # parent_idx[i]와 일치하는 source_idx의 인덱스 찾기
                matches = (source_idx == parent_idx[i]).nonzero(as_tuple=False)
                if len(matches) > 0:
                    parents_index[i] = matches[0].item()
                else:
                    # 매칭되지 않는 경우: depth 0이면 부모가 없으므로 0, 아니면 이전 노드의 인덱스 사용
                    if len(rows) > 0 and rows[i].item() == 0:
                        parents_index[i] = 0
                    else:
                        # 이전 노드 중에서 같은 depth의 노드를 부모로 사용
                        # 또는 가장 가까운 이전 노드 사용
                        parents_index[i] = max(0, i - 1) if i > 0 else 0
            
            # parents_index의 값이 유효한 범위 내에 있는지 확인
            parents_index = torch.clamp(parents_index, 0, len(top_index) - 1)
            
            # 검증: parents_index의 크기가 top_index와 일치해야 함
            if len(parents_index) != len(top_index):
                raise ValueError(f"parents_index size mismatch: {len(parents_index)} != {len(top_index)}")
            
            attention_mask = self.generate_attention_mask(parents_index, len(top_index))
            
            outputs = {
                "input_ids": input_ids,  # [DH] 선택된 노드들 (부모 인덱스 순으로 정렬됨)
                "position_ids": position_ids,  # [DH] 몇 번째 depth인지
                "attention_mask": attention_mask,
                "parent_last": parents_index,  # [DH] 선택된 노드들의 부모 인덱스 (상대적인 인덱스)
                "is_final": True
            }
        
        # 다음 호출을 위해 현재 tree 정보를 이전 값으로 저장
        self.prev_final_nnodes = self.final_nnodes
        self.prev_depth = self.depth
        self.prev_width = self.current_width
        
        return outputs
    
    def get_width_timing_stats(self):
        """width별 model.model() 호출 시간 통계를 딕셔너리로 반환"""
        if not self.width_times:
            return {}
        
        stats = {}
        for width in sorted(self.width_times.keys()):
            times = self.width_times[width]
            count = len(times)
            total_time_ms = sum(times) * 1000
            avg_time_ms = (sum(times) / count) * 1000
            min_time_ms = min(times) * 1000
            max_time_ms = max(times) * 1000
            
            stats[width] = {
                'count': count,
                'total_time_ms': total_time_ms,
                'avg_time_ms': avg_time_ms,
                'min_time_ms': min_time_ms,
                'max_time_ms': max_time_ms
            }
        
        return stats
    
    def print_width_timing_stats(self):
        """width별 model.model() 호출 시간 평균 실행 시간 출력"""
        stats = self.get_width_timing_stats()
        if not stats:
            return
        
        print("\n" + "="*80)
        print("Width별 model.model() 호출 시간 통계")
        print("="*80)
        print(f"{'Width':<10} {'실행 횟수':<12} {'총 시간 (ms)':<15} {'평균 시간 (ms)':<15} {'최소 시간 (ms)':<15} {'최대 시간 (ms)':<15}")
        print("-"*80)
        
        for width in sorted(stats.keys()):
            s = stats[width]
            print(f"{width:<10} {s['count']:<12} {s['total_time_ms']:<15.3f} {s['avg_time_ms']:<15.3f} {s['min_time_ms']:<15.3f} {s['max_time_ms']:<15.3f}")
        
        print("="*80 + "\n")

    def depth_algorithm(self):  # 여기다가 depth 관련 알고리즘 삽입 (depth 확장 조건)
        return True
    
    def print_tree_structure(self, tokenizer=None):
        """
        트리 구조를 시각적으로 출력하는 함수
        Args:
            tokenizer: 토큰 ID를 텍스트로 변환하기 위한 tokenizer (선택사항)
        """
        print("\n" + "="*80)
        print(f"Tree Structure (Current Depth: {self.depth}, Max Depth: {self.max_depth})")
        print("="*80)
        
        if self.depth == 0:
            print("Tree is empty (depth=0)")
            return
        
        # 각 depth별로 노드 정보 수집
        for d in range(self.depth):
            width = self.depth_widths[d] if d < len(self.depth_widths) else 0
            print(f"\nDepth {d} (width={width}):")
            print("-" * 80)
            
            for i in range(width):
                token_id = self.input_ids_matrix[d, i].item()
                weight = self.weight_matrix[d, i].item()
                parent_idx = self.parents_matrix[d, i].item() if d > 0 else -1
                
                # 토큰 텍스트 변환
                if tokenizer:
                    try:
                        token_text = tokenizer.decode([token_id])
                        token_text = repr(token_text)  # 특수문자 표시
                    except:
                        token_text = "<?>"
                else:
                    token_text = ""
                
                # 노드 정보 출력
                if d == 0:
                    print(f"  [{d},{i:2d}] token_id={token_id:5d} {token_text:20s} weight={weight:.6f}")
                else:
                    print(f"  [{d},{i:2d}] token_id={token_id:5d} {token_text:20s} weight={weight:.6f} <- parent=[{d-1},{parent_idx:2d}]")
        
        print("="*80 + "\n")
    
    def print_tree_structure_hierarchical(self, tokenizer=None):
        """
        트리 구조를 계층적으로 출력하는 함수 (트리 형태로 표현)
        Args:
            tokenizer: 토큰 ID를 텍스트로 변환하기 위한 tokenizer (선택사항)
        """
        print("\n" + "="*100)
        print(f"Tree Structure - Hierarchical View (Current Depth: {self.depth})")
        print("="*100)
        
        if self.depth == 0:
            print("Tree is empty (depth=0)")
            return
        
        # 각 depth별로 부모-자식 관계 구축
        children_map = {}  # {(depth, idx): [(child_depth, child_idx), ...]}
        
        for d in range(self.depth):
            width = self.depth_widths[d] if d < len(self.depth_widths) else 0
            for i in range(width):
                if d > 0:
                    parent_idx = self.parents_matrix[d, i].item()
                    parent_key = (d-1, parent_idx)
                    if parent_key not in children_map:
                        children_map[parent_key] = []
                    children_map[parent_key].append((d, i))
        
        # 재귀적으로 트리 출력
        def print_node(depth, idx, prefix="", is_last=True):
            width = self.depth_widths[depth] if depth < len(self.depth_widths) else 0
            if idx >= width:
                return
            
            token_id = self.input_ids_matrix[depth, idx].item()
            weight = self.weight_matrix[depth, idx].item()
            
            # 토큰 텍스트 변환
            if tokenizer:
                try:
                    token_text = tokenizer.decode([token_id])
                    token_text = repr(token_text)[:15]  # 길이 제한
                except:
                    token_text = "<?>"
            else:
                token_text = f"id={token_id}"
            
            # 현재 노드 출력
            connector = "└─" if is_last else "├─"
            print(f"{prefix}{connector} [{depth},{idx:2d}] {token_text:15s} (w={weight:.4f})")
            
            # 자식 노드들 출력
            node_key = (depth, idx)
            if node_key in children_map:
                children = children_map[node_key]
                extension = "   " if is_last else "│  "
                for i, child in enumerate(children):
                    is_last_child = (i == len(children) - 1)
                    print_node(child[0], child[1], prefix + extension, is_last_child)
        
        # Depth 0의 모든 노드부터 시작
        width_0 = self.depth_widths[0] if len(self.depth_widths) > 0 else 0
        for i in range(width_0):
            is_last = (i == width_0 - 1)
            print_node(0, i, "", is_last)
        
        print("="*100 + "\n")