import copy
import bisect
import json
import random
import socket
import subprocess
import threading
from typing import List, Tuple
import time
import torch


from transformers.generation.logits_process import (
    LogitsProcessorList,
    RepetitionPenaltyLogitsProcessor,
    TemperatureLogitsWarper,
    TopKLogitsWarper,
    TopPLogitsWarper,
)


def timer(func):
    def wrapper(*args, **kwargs):
        torch.cuda.synchronize()
        start = time.perf_counter()

        result = func(*args, **kwargs)

        torch.cuda.synchronize()
        elapsed = time.perf_counter() - start
        print(f'{func.__name__} took {elapsed} seconds')
        return result

    return wrapper


def prepare_logits_processor(
        temperature: float = 0.0,
        repetition_penalty: float = 0.0,
        top_p: float = 0.0,
        top_k: int = 0
) -> LogitsProcessorList:
    processor_list = LogitsProcessorList()
    if temperature > 1e-5:
        if temperature >= 1e-5 and temperature != 1.0:
            processor_list.append(TemperatureLogitsWarper(temperature))
        if repetition_penalty > 1.0:
            processor_list.append(RepetitionPenaltyLogitsProcessor(repetition_penalty))
        if 1e-8 <= top_p < 1.0:
            processor_list.append(TopPLogitsWarper(top_p))
        if top_k > 0:
            processor_list.append(TopKLogitsWarper(top_k))
        return processor_list





def reset_past_key_values(passed_key_values: List[torch.Tensor]) -> List[torch.Tensor]:
    """
    Resets the current lengths in the passed key-values to zero.

    This function is designed to be used during the evaluation of a baseline model.
    It iterates through each layer's key-values and sets their current lengths to zero,
    effectively resetting their state.

    Args:
    - passed_key_values (list of torch.Tensor): Contains past hidden states and past attention values for each layer.

    Returns:
    - passed_key_values (list of torch.Tensor): Updated past hidden states and past attention values with reset lengths.
    """
    for i in range(len(passed_key_values)):
        for j in range(2):
            passed_key_values[i][j].current_length.fill_(0)
    return passed_key_values



def tree_decoding(
        model,
        draft_input_ids,
        past_key_values,
        draft_position_ids,
        tree_attention_mask,
        gpu_monitor=None,
        step_info=None,
):
    # GPU 모니터링 시작
    if gpu_monitor:
        gpu_monitor.start_monitoring()
    
    torch.cuda.synchronize()
    start_time = time.time()
    
    outputs, tree_logits, hidden_state = model(
        draft_input_ids,
        tree_attention_mask=tree_attention_mask,
        output_orig=True,
        past_key_values=past_key_values,
        position_ids=draft_position_ids,
        init=False,
    )
    
    torch.cuda.synchronize()
    end_time = time.time()
    
    # GPU 모니터링 중지 및 데이터 수집
    gpu_stats = None
    if gpu_monitor:
        gpu_monitor.stop_monitoring()
        gpu_stats = gpu_monitor.get_stats()
    
    # 단계별 타이밍 정보 저장
    if step_info is not None:
        step_info['tree_decoding'] = {
            'time_seconds': end_time - start_time,
            'gpu_stats': gpu_stats,
            'timestamp': time.time()
        }

    return tree_logits, hidden_state, outputs

def verify(input_ids,logits,draft,position_ids,tree_attention_mask,past_key_values_data,current_length_data,parent,model,nodes,threshold,max_depth,logits_processor,gpu_monitor=None,step_info=None):
    # 1단계: Best candidate 찾기
    if gpu_monitor:
        gpu_monitor.start_monitoring()
    
    torch.cuda.synchronize()
    start_time = time.time()
    
    if logits_processor is None:
        next = torch.argmax(logits, dim=-1)
    else:
        logits = logits_processor(None, logits)
        probabilities = torch.nn.functional.softmax(logits, dim=-1)[0]
        next = torch.multinomial(probabilities, 1).view(1, -1)
    next=next.to(draft.device)

    parent = torch.where(parent == torch.arange(parent.size(0),device=parent.device), -1, parent)
    parent = torch.cat([torch.tensor([0],device=parent.device), parent + 1], dim=-1).to(draft.device)

    correct = torch.where(draft[0] != next[0][parent], 0, torch.ones(draft.size(1), device=draft.device))
    correct[0] = 1
    last_sum = torch.sum(correct)
    while True:
        correct = torch.where(correct[parent] == 0, 0, correct)
        if torch.sum(correct) == last_sum:
            break
        else:
            last_sum = torch.sum(correct)

    id = torch.argmax(correct * position_ids)
    best_candidate = []
    best_candidate_id = []
    max_id = id
    parent[0] = -1
    while id != -1:
        best_candidate.append(draft[0][id].item())
        best_candidate_id.append(id)
        id = parent[id].item()

    best_candidate.reverse()
    best_candidate_id.reverse()
    next_token = next[0][max_id].unsqueeze(0).unsqueeze(0)
    accept_length=len(best_candidate)-1
    
    torch.cuda.synchronize()
    end_time = time.time()
    
    # 1단계 GPU 모니터링 중지 및 데이터 수집
    gpu_stats_1 = None
    if gpu_monitor:
        gpu_monitor.stop_monitoring()
        gpu_stats_1 = gpu_monitor.get_stats()
    
    # 1단계 타이밍 정보 저장
    if step_info is not None:
        step_info['best_candidate_search'] = {
            'time_seconds': end_time - start_time,
            'gpu_stats': gpu_stats_1, 
            'timestamp': time.time()
        }
    
    # 2단계: Past key values 업데이트
    if gpu_monitor:
        gpu_monitor.start_monitoring()
    
    torch.cuda.synchronize()
    start_time = time.time()
    
    start=current_length_data[0].item()-draft.size(1)
    select_indices=torch.tensor(best_candidate_id)+start

    for data in past_key_values_data:
        # select_indices=tensor([29, 30, 34, 44], device='cuda:0')
        tgt = data[..., select_indices.to(data.device), :]
        # Destination tensor where the relevant past information will be stored
        dst = data[..., start: start + tgt.shape[-2], :]
        # Copy relevant past information from the source to the destination
        dst.copy_(tgt, non_blocking=True)

    # Update the current length tensor (currently only support batch size is 1)
    current_length_data.fill_(start + tgt.shape[-2])
    
    torch.cuda.synchronize()
    end_time = time.time()
    
    # 2단계 GPU 모니터링 중지 및 데이터 수집
    gpu_stats_2 = None
    if gpu_monitor:
        gpu_monitor.stop_monitoring()
        gpu_stats_2 = gpu_monitor.get_stats()
    
    # 2단계 타이밍 정보 저장
    if step_info is not None:
        step_info['past_key_values_update'] = {
            'time_seconds': end_time - start_time,
            'gpu_stats': gpu_stats_2,
            'timestamp': time.time()
        }
    
    # 3단계: Model.draft 호출 (다음 토큰 트리 생성)
    if gpu_monitor:
        gpu_monitor.start_monitoring()
    
    torch.cuda.synchronize()
    start_time = time.time()
    
    input_ids=torch.cat([input_ids,torch.tensor(best_candidate,device=input_ids.device).unsqueeze(0)],dim=-1)
    next_draft, next_position_ids, next_tree_attention_mask,parent,next_tree_depth = model.draft(torch.cat((input_ids, next_token.to(input_ids.device)), dim=1),nodes,threshold,max_depth)
    
    torch.cuda.synchronize()
    end_time = time.time()
    
    # 3단계 GPU 모니터링 중지 및 데이터 수집
    gpu_stats_3 = None
    if gpu_monitor:
        gpu_monitor.stop_monitoring()
        gpu_stats_3 = gpu_monitor.get_stats()
    
    # 3단계 타이밍 정보 저장
    if step_info is not None:
        step_info['model_draft'] = {
            'time_seconds': end_time - start_time,
            'gpu_stats': gpu_stats_3,
            'timestamp': time.time()
        }
    
    # 4단계: 결과 텐서 정리 (GPU 모니터링 없음)
    torch.cuda.synchronize()
    start_time = time.time()
    
    next_draft=torch.cat([next_token, next_draft], dim=-1)
    next_position_ids = torch.cat([torch.tensor([next_position_ids[0] - 1],device=next_position_ids.device), next_position_ids], dim=-1)
    next_tree_attention_mask = torch.cat(
        [torch.zeros(1, next_tree_attention_mask.size(1), dtype=next_tree_attention_mask.dtype,device=next_tree_attention_mask.device), next_tree_attention_mask],
        dim=0)
    next_tree_attention_mask = torch.cat(
        [torch.ones(next_tree_attention_mask.size(0), 1, dtype=next_tree_attention_mask.dtype,device=next_tree_attention_mask.device), next_tree_attention_mask],
        dim=1)
    
    torch.cuda.synchronize()
    end_time = time.time()
    
    # 4단계 타이밍 정보 저장
    if step_info is not None:
        step_info['tensor_cleanup'] = {
            'time_seconds': end_time - start_time,
            'gpu_stats': None,
            'timestamp': time.time()
        }

    return input_ids,best_candidate,accept_length,next_draft, next_position_ids, next_tree_attention_mask,parent,next_tree_depth


class CPUPowerMonitor:
    """CPU 전력을 powerstat을 사용하여 모니터링하는 클래스"""

    def __init__(self, interval=0.1, debug=False):
        # powerstat은 최소 0.5초 sampling 주기가 필요함
        self.interval = max(0.5, interval)
        if interval < 0.5 and debug:
            print(f"[draft] CPU 전력 모니터링: 요청된 interval({interval})이 최소값(0.5)보다 작아서 0.5로 조정됨")
        self.monitoring = False
        self.data = []
        self.monitor_thread = None
        self.debug = debug
        self.monitor_call_count = 0  # start_monitoring() 호출 횟수 카운터
        self.powerstat_process = None

    def get_cpu_power_info(self):
        """powerstat을 사용하여 CPU 전력 정보를 가져옵니다"""
        try:
            # powerstat -d 0 -R {interval}: 지연 없이 interval마다 측정, RAPL 인터페이스 사용
            # 1회 측정만 수행 (timeout 사용)
            cmd = ['sudo', 'powerstat', '-d', '0', '-R', str(self.interval), '1']
            if self.debug:
                print(f"[draft] CPU 전력 측정 명령어 실행: {' '.join(cmd)}")

            result = subprocess.run(
                cmd,
                capture_output=True, text=True, timeout=self.interval + 2
            )

            if self.debug:
                print(f"[draft] powerstat 반환 코드: {result.returncode}")
                if result.stdout:
                    print(f"[draft] powerstat stdout (처음 500자): {result.stdout[:500]}")
                if result.stderr:
                    print(f"[draft] powerstat stderr: {result.stderr}")

            if result.returncode == 0:
                # powerstat 출력 파싱 (텍스트 테이블 형식)
                lines = result.stdout.strip().split('\n')
                if self.debug:
                    print(f"[draft] powerstat 출력 라인 수: {len(lines)}")

                for line in lines:
                    # 헤더 라인 건너뛰기
                    if not line.strip() or line.startswith('Time') or line.startswith('---'):
                        continue

                    # 공백으로 구분된 컬럼 파싱
                    parts = line.split()
                    if self.debug:
                        print(f"[draft] 파싱 시도 라인: {line}, 컬럼 수: {len(parts)}")

                    if len(parts) >= 10:  # 최소 컬럼 수 확인
                        try:
                            # AvgPower는 보통 마지막에서 두 번째 컬럼 (W 단위)
                            # 형식: "15.2W" 또는 "15.2"
                            avg_power_str = parts[-2] if len(parts) >= 2 else parts[-1]
                            # "W" 제거
                            avg_power_str = avg_power_str.rstrip('W')
                            avg_power_w = float(avg_power_str)

                            if self.debug:
                                print(f"[draft] CPU 전력 측정 성공: {avg_power_w}W")

                            return {
                                'cpu_power_w': avg_power_w,
                                'timestamp': time.time()
                            }
                        except (ValueError, IndexError) as e:
                            if self.debug:
                                print(f"[draft] powerstat 파싱 오류: {e}, line: {line}, parts: {parts}")
                            continue
                # 파싱 실패 시 기본값 반환
                if self.debug:
                    print(f"[draft] powerstat 파싱 실패: 유효한 데이터 라인을 찾을 수 없음")
                return self._get_default_cpu_power_info()
            if self.debug:
                print(f"[draft] powerstat 실행 실패 (반환 코드: {result.returncode}): {result.stderr}")
            return self._get_default_cpu_power_info()
        except subprocess.TimeoutExpired:
            if self.debug:
                print(f"[draft] powerstat 타임아웃 (interval: {self.interval})")
            return self._get_default_cpu_power_info()
        except Exception as e:
            if self.debug:
                print(f"[draft] CPU 전력 정보 가져오기 실패: {e}", exc_info=True)
            return self._get_default_cpu_power_info()

    def _get_default_cpu_power_info(self):
        """기본 CPU 전력 정보를 반환합니다"""
        return {
            'cpu_power_w': None,
            'timestamp': time.time()
        }

    def monitor_loop(self):
        """모니터링 루프"""
        loop_count = 0
        while self.monitoring:
            loop_count += 1
            if self.debug:
                print(f"[draft] CPU 전력 모니터링 루프 실행 중 (횟수: {loop_count})")

            cpu_power_info = self.get_cpu_power_info()
            if cpu_power_info:
                self.data.append(cpu_power_info)
                if self.debug:
                    print(f"[draft] CPU 전력 데이터 수집됨: {cpu_power_info}, 총 데이터 수: {len(self.data)}")
            else:
                if self.debug:
                    print(f"[draft] CPU 전력 데이터 수집 실패 (None 반환)")
            time.sleep(self.interval)

    def start_monitoring(self):
        """모니터링 시작"""
        self.monitor_call_count += 1  # 호출 횟수 증가
        if not self.monitoring:
            self.monitoring = True
            self.data = []
            self.monitor_thread = threading.Thread(target=self.monitor_loop)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()

    def stop_monitoring(self):
        """모니터링 중지"""
        if self.monitoring:
            self.monitoring = False
            if self.monitor_thread:
                self.monitor_thread.join()

    def get_stats(self):
        """통계 정보 반환"""
        if self.debug:
            print(f"[draft] CPU 전력 통계 요청 (데이터 수: {len(self.data)})")

        if not self.data:
            if self.debug:
                print(f"[draft] CPU 전력 통계: 데이터가 없어 None 반환")
            return None

        # CPU 전력 통계 계산
        cpu_power_values = [entry['cpu_power_w'] for entry in self.data if entry['cpu_power_w'] is not None]

        if self.debug:
            print(f"[draft] CPU 전력 통계: 유효한 값 수: {len(cpu_power_values)} / 전체 데이터 수: {len(self.data)}")
            if cpu_power_values:
                print(f"[draft] CPU 전력 값 범위: {min(cpu_power_values):.2f}W ~ {max(cpu_power_values):.2f}W")

        if not cpu_power_values:
            if self.debug:
                print(f"[draft] CPU 전력 통계: 유효한 값이 없어 None 반환")
            return None

        stats = {
            'cpu_power_w': {
                'avg': sum(cpu_power_values) / len(cpu_power_values),
                'max': max(cpu_power_values),
                'min': min(cpu_power_values),
                'count': len(cpu_power_values)
            }
        }

        if self.debug:
            print(f"[draft] CPU 전력 통계 계산 완료: {stats}")

        return stats


class GPUMonitor:
    """NVIDIA GPU 메모리와 utilization을 모니터링하는 클래스"""

    def __init__(self, interval=0.1, fix_gpu_clock=False, graphics_clock=None, memory_clock=None, debug=False):
        self.interval = interval
        self.monitoring = False
        self.data = []
        self._timestamps = []
        self._lock = threading.RLock()
        self.retention_seconds = max(60.0, float(interval) * 4096.0, 300.0)
        self.monitor_thread = None
        self.fix_gpu_clock = fix_gpu_clock
        self.graphics_clock = graphics_clock
        self.memory_clock = memory_clock
        self.original_graphics_clock = None
        self.original_memory_clock = None
        self.debug = debug
        self.monitor_call_count = 0  # start_monitoring() 호출 횟수 카운터
        self.backend = "nvidia-smi"
        self._nvml = None
        self._nvml_handles = []
        try:
            import pynvml
            pynvml.nvmlInit()
            self._nvml = pynvml
            device_count = pynvml.nvmlDeviceGetCount()
            self._nvml_handles = [
                pynvml.nvmlDeviceGetHandleByIndex(i)
                for i in range(device_count)
            ]
            if self._nvml_handles:
                self.backend = "nvml"
        except Exception as e:
            self._nvml = None
            self._nvml_handles = []
            if self.debug:
                print(f"[draft] NVML 초기화 실패, nvidia-smi fallback 사용: {e}")

        if self.fix_gpu_clock:
            self._set_gpu_clocks()

    def _set_gpu_clocks(self):
        """GPU 클럭을 고정 설정"""
        try:
            # 현재 클럭 상태 저장
            result = subprocess.run([
                'nvidia-smi',
                '--query-gpu=clocks.current.graphics,clocks.current.memory',
                '--format=csv,noheader,nounits'
            ], capture_output=True, text=True, timeout=5)

            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                if lines and lines[0].strip():
                    parts = lines[0].split(', ')
                    if len(parts) >= 2:
                        self.original_graphics_clock = int(parts[0])
                        self.original_memory_clock = int(parts[1])
                        if self.debug:
                            print(f"[draft] 원본 GPU 클럭 저장: Graphics={self.original_graphics_clock}MHz, Memory={self.original_memory_clock}MHz")

            # GPU 클럭 설정
            # nvidia-smi --applications-clocks 형식은 "memory,graphics" 순서다.
            target_graphics = self.graphics_clock
            target_memory = self.memory_clock
            if target_graphics is None or target_memory is None:
                max_result = subprocess.run([
                    'nvidia-smi',
                    '--query-gpu=clocks.max.graphics,clocks.max.memory',
                    '--format=csv,noheader,nounits'
                ], capture_output=True, text=True, timeout=5)
                if max_result.returncode == 0:
                    lines = max_result.stdout.strip().split('\n')
                    if lines and lines[0].strip():
                        parts = lines[0].split(', ')
                        if len(parts) >= 2:
                            try:
                                max_graphics = int(parts[0])
                            except Exception:
                                max_graphics = None
                            try:
                                max_memory = int(parts[1])
                            except Exception:
                                max_memory = None
                            if target_graphics is None:
                                target_graphics = max_graphics
                            if target_memory is None:
                                target_memory = max_memory

            if target_graphics is None or target_memory is None:
                if self.debug:
                    print("[draft] GPU 클럭 고정 건너뜀: target graphics/memory clock를 결정하지 못함")
                return

            cmd = ['nvidia-smi', f'--applications-clocks={target_memory},{target_graphics}']
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)

            if result.returncode == 0:
                if self.debug:
                    print(f"[draft] GPU 클럭 고정 설정: Graphics={target_graphics}MHz, Memory={target_memory}MHz")
            else:
                if self.debug:
                    print(f"[draft] GPU 클럭 설정 실패: {result.stderr}")
        except Exception as e:
            if self.debug:
                print(f"[draft] GPU 클럭 설정 중 오류: {e}")

    def _restore_gpu_clocks(self):
        """GPU 클럭을 원래 상태로 복원"""
        try:
            if self.original_graphics_clock is not None and self.original_memory_clock is not None:
                cmd = ['nvidia-smi', '--applications-clocks=default']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)

                if result.returncode == 0:
                    if self.debug:
                        print(f"[draft] GPU 클럭 복원 완료")
                else:
                    if self.debug:
                        print(f"[draft] GPU 클럭 복원 실패: {result.stderr}")
        except Exception as e:
            if self.debug:
                print(f"[draft] GPU 클럭 복원 중 오류: {e}")

    def __del__(self):
        """소멸자에서 GPU 클럭 복원"""
        if self.fix_gpu_clock:
            self._restore_gpu_clocks()

    def get_gpu_info(self):
        """nvidia-smi를 사용하여 GPU 정보를 가져옵니다"""
        if self._nvml is not None and self._nvml_handles:
            try:
                gpu_info = []
                for gpu_id, handle in enumerate(self._nvml_handles):
                    mem = self._nvml.nvmlDeviceGetMemoryInfo(handle)
                    util = self._nvml.nvmlDeviceGetUtilizationRates(handle)
                    try:
                        temperature_c = self._nvml.nvmlDeviceGetTemperature(
                            handle, self._nvml.NVML_TEMPERATURE_GPU
                        )
                    except Exception:
                        temperature_c = 0
                    try:
                        power_draw_w = self._nvml.nvmlDeviceGetPowerUsage(handle) / 1000.0
                    except Exception:
                        power_draw_w = None
                    try:
                        power_limit_w = self._nvml.nvmlDeviceGetEnforcedPowerLimit(handle) / 1000.0
                    except Exception:
                        power_limit_w = None
                    try:
                        graphics_clock_mhz = self._nvml.nvmlDeviceGetClockInfo(
                            handle, self._nvml.NVML_CLOCK_GRAPHICS
                        )
                    except Exception:
                        graphics_clock_mhz = None
                    try:
                        memory_clock_mhz = self._nvml.nvmlDeviceGetClockInfo(
                            handle, self._nvml.NVML_CLOCK_MEM
                        )
                    except Exception:
                        memory_clock_mhz = None
                    try:
                        max_graphics_clock_mhz = self._nvml.nvmlDeviceGetMaxClockInfo(
                            handle, self._nvml.NVML_CLOCK_GRAPHICS
                        )
                    except Exception:
                        max_graphics_clock_mhz = None
                    try:
                        max_memory_clock_mhz = self._nvml.nvmlDeviceGetMaxClockInfo(
                            handle, self._nvml.NVML_CLOCK_MEM
                        )
                    except Exception:
                        max_memory_clock_mhz = None
                    memory_total_mb = max(1, int(mem.total / (1024 * 1024)))
                    memory_used_mb = int(mem.used / (1024 * 1024))
                    power_usage_percent = None
                    if power_draw_w is not None and power_limit_w is not None and power_limit_w > 0:
                        power_usage_percent = (power_draw_w / power_limit_w) * 100.0
                    gpu_info.append({
                        'gpu_id': gpu_id,
                        'memory_used_mb': memory_used_mb,
                        'memory_total_mb': memory_total_mb,
                        'utilization_percent': int(util.gpu),
                        'temperature_c': int(temperature_c or 0),
                        'power_draw_w': power_draw_w,
                        'power_limit_w': power_limit_w,
                        'graphics_clock_mhz': graphics_clock_mhz,
                        'memory_clock_mhz': memory_clock_mhz,
                        'max_graphics_clock_mhz': max_graphics_clock_mhz,
                        'max_memory_clock_mhz': max_memory_clock_mhz,
                        'memory_used_percent': (memory_used_mb / memory_total_mb) * 100.0,
                        'power_usage_percent': power_usage_percent,
                        'timestamp': time.time()
                    })
                return gpu_info
            except Exception as e:
                if self.debug:
                    print(f"[draft] NVML GPU 정보 가져오기 실패, nvidia-smi fallback 사용: {e}")
        try:
            def _to_int(value):
                if value is None:
                    return None
                s = str(value).strip()
                if s in {"N/A", "[N/A]", "[Not Supported]", "Not Supported", ""}:
                    return None
                try:
                    return int(float(s))
                except Exception:
                    return None

            def _to_float(value):
                if value is None:
                    return None
                s = str(value).strip()
                if s in {"N/A", "[N/A]", "[Not Supported]", "Not Supported", ""}:
                    return None
                try:
                    return float(s)
                except Exception:
                    return None

            # nvidia-smi를 사용하여 GPU 정보 가져오기 (클럭 정보 및 파워 포함)
            result = subprocess.run([
                'nvidia-smi',
                '--query-gpu=index,memory.used,memory.total,utilization.gpu,temperature.gpu,power.draw,power.limit,clocks.current.graphics,clocks.current.memory,clocks.max.graphics,clocks.max.memory',
                '--format=csv,noheader,nounits'
            ], capture_output=True, text=True, timeout=5)

            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                gpu_info = []
                for line in lines:
                    if line.strip():
                        parts = line.split(', ')
                        if len(parts) >= 11:
                            gpu_id = _to_int(parts[0]) or 0
                            memory_used_mb = _to_int(parts[1]) or 0
                            memory_total_mb = _to_int(parts[2]) or 1
                            utilization_percent = _to_int(parts[3]) or 0
                            temperature_c = _to_int(parts[4]) or 0
                            power_draw_w = _to_float(parts[5])
                            power_limit_w = _to_float(parts[6])
                            graphics_clock_mhz = _to_int(parts[7])
                            memory_clock_mhz = _to_int(parts[8])
                            max_graphics_clock_mhz = _to_int(parts[9])
                            max_memory_clock_mhz = _to_int(parts[10])

                            memory_used_percent = (memory_used_mb / memory_total_mb) * 100 if memory_total_mb > 0 else 0
                            power_usage_percent = None
                            if power_draw_w is not None and power_limit_w is not None and power_limit_w > 0:
                                power_usage_percent = (power_draw_w / power_limit_w) * 100

                            gpu_info.append({
                                'gpu_id': gpu_id,
                                'memory_used_mb': memory_used_mb,
                                'memory_total_mb': memory_total_mb,
                                'utilization_percent': utilization_percent,
                                'temperature_c': temperature_c,
                                'power_draw_w': power_draw_w,
                                'power_limit_w': power_limit_w,
                                'graphics_clock_mhz': graphics_clock_mhz,
                                'memory_clock_mhz': memory_clock_mhz,
                                'max_graphics_clock_mhz': max_graphics_clock_mhz,
                                'max_memory_clock_mhz': max_memory_clock_mhz,
                                'memory_used_percent': memory_used_percent,
                                'power_usage_percent': power_usage_percent,
                                'timestamp': time.time()
                            })
                return gpu_info
            print(f"nvidia-smi 실행 실패: {result.stderr}")
            return self._get_default_gpu_info()
        except Exception as e:
            print(f"GPU 정보 가져오기 실패: {e}")
            return self._get_default_gpu_info()

    def _get_default_gpu_info(self):
        """기본 GPU 정보를 반환합니다"""
        return [{
            'gpu_id': 0,
            'memory_used_mb': 0,
            'memory_total_mb': 1,
            'utilization_percent': 0,
            'temperature_c': 0,
            'power_draw_w': None,
            'power_limit_w': None,
            'graphics_clock_mhz': None,
            'memory_clock_mhz': None,
            'max_graphics_clock_mhz': None,
            'max_memory_clock_mhz': None,
            'memory_used_percent': 0,
            'power_usage_percent': None,
            'timestamp': time.time()
        }]

    def monitor_loop(self):
        """모니터링 루프"""
        while self.monitoring:
            gpu_info = self.get_gpu_info()
            if gpu_info:
                timestamp = time.time()
                new_entries = []
                new_timestamps = []
                for i, gpu in enumerate(gpu_info):
                    new_entries.append({
                        'timestamp': timestamp,
                        'gpu_id': i,
                        **gpu
                    })
                    new_timestamps.append(timestamp)
                with self._lock:
                    self.data.extend(new_entries)
                    self._timestamps.extend(new_timestamps)
                    self._prune_locked(time.time() - self.retention_seconds)
            time.sleep(self.interval)

    def _prune_locked(self, min_timestamp):
        """self._lock 보유 상태에서 오래된 샘플을 제거한다."""
        if not self._timestamps:
            return
        idx = bisect.bisect_left(self._timestamps, float(min_timestamp))
        if idx > 0:
            del self._timestamps[:idx]
            del self.data[:idx]

    def reset_data(self):
        """누적 GPU 샘플을 비운다. long-running monitor thread는 유지한다."""
        with self._lock:
            self.data = []
            self._timestamps = []

    def start_monitoring(self):
        """모니터링 시작"""
        self.monitor_call_count += 1  # 호출 횟수 증가
        if not self.monitoring:
            self.monitoring = True
            self.reset_data()
            self.monitor_thread = threading.Thread(target=self.monitor_loop)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()

    def stop_monitoring(self):
        """모니터링 중지"""
        if self.monitoring:
            self.monitoring = False
            if self.monitor_thread:
                self.monitor_thread.join()

    def get_stats(self, start_time=None, end_time=None):
        """통계 정보 반환"""
        if start_time is not None or end_time is not None:
            start = float(start_time) if start_time is not None else float("-inf")
            end = float(end_time) if end_time is not None else float("inf")
            with self._lock:
                if not self.data:
                    return None
                left = 0 if start == float("-inf") else bisect.bisect_left(self._timestamps, start)
                right = len(self.data) if end == float("inf") else bisect.bisect_right(self._timestamps, end)
                entries = list(self.data[left:right])
                if not entries and end_time is not None:
                    # 짧은 interval(샘플 0개)에서는 end 이전 최신 샘플 하나를 사용한다.
                    prior_idx = bisect.bisect_right(self._timestamps, end) - 1
                    if prior_idx >= 0:
                        entries = [dict(self.data[prior_idx])]
            if not entries and end_time is not None:
                return None
        else:
            with self._lock:
                if not self.data:
                    return None
                entries = list(self.data)

        # GPU별로 통계 계산
        gpu_stats = {}
        for entry in entries:
            gpu_id = entry['gpu_id']
            if gpu_id not in gpu_stats:
                gpu_stats[gpu_id] = {
                    'memory_used_mb': [],
                    'memory_total_mb': [],
                    'utilization_percent': [],
                    'temperature_c': [],
                    'power_draw_w': [],
                    'power_limit_w': [],
                    'power_usage_percent': [],
                    'graphics_clock_mhz': [],
                    'memory_clock_mhz': [],
                    'max_graphics_clock_mhz': [],
                    'max_memory_clock_mhz': [],
                    'memory_used_percent': []
                }

            gpu_stats[gpu_id]['memory_used_mb'].append(entry['memory_used_mb'])
            gpu_stats[gpu_id]['memory_total_mb'].append(entry['memory_total_mb'])
            gpu_stats[gpu_id]['utilization_percent'].append(entry['utilization_percent'])
            gpu_stats[gpu_id]['temperature_c'].append(entry['temperature_c'])
            gpu_stats[gpu_id]['memory_used_percent'].append(entry['memory_used_percent'])

            # 파워 정보 추가 (None 값 제외)
            if entry['power_draw_w'] is not None:
                gpu_stats[gpu_id]['power_draw_w'].append(entry['power_draw_w'])
            if entry['power_limit_w'] is not None:
                gpu_stats[gpu_id]['power_limit_w'].append(entry['power_limit_w'])
            if entry['power_usage_percent'] is not None:
                gpu_stats[gpu_id]['power_usage_percent'].append(entry['power_usage_percent'])

            # 클럭 정보 추가 (None 값 제외)
            if entry['graphics_clock_mhz'] is not None:
                gpu_stats[gpu_id]['graphics_clock_mhz'].append(entry['graphics_clock_mhz'])
            if entry['memory_clock_mhz'] is not None:
                gpu_stats[gpu_id]['memory_clock_mhz'].append(entry['memory_clock_mhz'])
            if entry['max_graphics_clock_mhz'] is not None:
                gpu_stats[gpu_id]['max_graphics_clock_mhz'].append(entry['max_graphics_clock_mhz'])
            if entry['max_memory_clock_mhz'] is not None:
                gpu_stats[gpu_id]['max_memory_clock_mhz'].append(entry['max_memory_clock_mhz'])

        # 평균, 최대, 최소 계산
        stats = {}
        for gpu_id, data in gpu_stats.items():
            stats[f'gpu_{gpu_id}'] = {
                'memory_used_mb': {
                    'avg': sum(data['memory_used_mb']) / len(data['memory_used_mb']),
                    'max': max(data['memory_used_mb']),
                    'min': min(data['memory_used_mb'])
                },
                'memory_total_mb': data['memory_total_mb'][0] if data['memory_total_mb'] else 0,  # 총 메모리는 고정값
                'utilization_percent': {
                    'avg': sum(data['utilization_percent']) / len(data['utilization_percent']),
                    'max': max(data['utilization_percent']),
                    'min': min(data['utilization_percent'])
                },
                'temperature_c': {
                    'avg': sum(data['temperature_c']) / len(data['temperature_c']),
                    'max': max(data['temperature_c']),
                    'min': min(data['temperature_c'])
                },
                'memory_used_percent': {
                    'avg': sum(data['memory_used_percent']) / len(data['memory_used_percent']),
                    'max': max(data['memory_used_percent']),
                    'min': min(data['memory_used_percent'])
                }
            }

            # 파워 통계 추가 (데이터가 있는 경우만)
            if data['power_draw_w']:
                stats[f'gpu_{gpu_id}']['power_draw_w'] = {
                    'avg': sum(data['power_draw_w']) / len(data['power_draw_w']),
                    'max': max(data['power_draw_w']),
                    'min': min(data['power_draw_w'])
                }
            if data['power_limit_w']:
                stats[f'gpu_{gpu_id}']['power_limit_w'] = data['power_limit_w'][0]  # 파워 한계는 고정값
            if data['power_usage_percent']:
                stats[f'gpu_{gpu_id}']['power_usage_percent'] = {
                    'avg': sum(data['power_usage_percent']) / len(data['power_usage_percent']),
                    'max': max(data['power_usage_percent']),
                    'min': min(data['power_usage_percent'])
                }

            # 클럭 정보 통계 (데이터가 있는 경우만)
            if data['graphics_clock_mhz']:
                stats[f'gpu_{gpu_id}']['graphics_clock_mhz'] = {
                    'avg': sum(data['graphics_clock_mhz']) / len(data['graphics_clock_mhz']),
                    'max': max(data['graphics_clock_mhz']),
                    'min': min(data['graphics_clock_mhz'])
                }
            if data['memory_clock_mhz']:
                stats[f'gpu_{gpu_id}']['memory_clock_mhz'] = {
                    'avg': sum(data['memory_clock_mhz']) / len(data['memory_clock_mhz']),
                    'max': max(data['memory_clock_mhz']),
                    'min': min(data['memory_clock_mhz'])
                }
            if data['max_graphics_clock_mhz']:
                stats[f'gpu_{gpu_id}']['max_graphics_clock_mhz'] = data['max_graphics_clock_mhz'][0]  # 최대값은 고정
            if data['max_memory_clock_mhz']:
                stats[f'gpu_{gpu_id}']['max_memory_clock_mhz'] = data['max_memory_clock_mhz'][0]  # 최대값은 고정

        return stats

    def get_stats_between(self, start_time, end_time):
        """start_time~end_time 사이의 샘플만 집계한다."""
        return self.get_stats(start_time=start_time, end_time=end_time)


def send_json(sock: socket.socket, payload: dict) -> None:
    """JSON 데이터를 전송"""
    data = (json.dumps(payload) + "\n").encode("utf-8")
    sock.sendall(data)


def recv_json(sock: socket.socket) -> dict:
    """JSON 데이터를 수신"""
    buffer = b""
    while True:
        chunk = sock.recv(4096)
        if not chunk:
            raise ConnectionError("Socket closed by peer")
        buffer += chunk
        if b"\n" in buffer:
            line, buffer = buffer.split(b"\n", 1)
            return json.loads(line.decode("utf-8"))


def send_json_with_size(sock: socket.socket, payload: dict) -> int:
    """JSON 데이터를 전송하고 전송한 바이트 수를 반환"""
    data = (json.dumps(payload) + "\n").encode("utf-8")
    sock.sendall(data)
    return len(data)


def recv_json_with_size(sock: socket.socket) -> Tuple[dict, int]:
    """JSON 데이터를 수신하고 수신한 바이트 수를 반환"""
    buffer = b""
    total_bytes = 0
    while True:
        chunk = sock.recv(4096)
        if not chunk:
            raise ConnectionError("Socket closed by peer")
        buffer += chunk
        total_bytes += len(chunk)
        if b"\n" in buffer:
            line, buffer = buffer.split(b"\n", 1)
            return json.loads(line.decode("utf-8")), total_bytes

