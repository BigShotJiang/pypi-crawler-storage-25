import torch
import random

class Tree:
    def __init__(self, nnodes, device, threshold, max_depth):
        self.max_nnodes = nnodes  # 최대 노드 수 (max_width)
        self.device = device
        self.threshold = threshold
        self.depth = 0
        self.weight = 0
        self.max_depth = max_depth
        # 매트릭스는 최대 크기로 할당
        self.weight_matrix = torch.zeros([max_depth, self.max_nnodes], device=self.device)
        self.input_ids_matrix = torch.zeros([max_depth, self.max_nnodes], dtype=torch.long, device=self.device)
        self.parents_matrix = torch.zeros([max_depth, self.max_nnodes], dtype=torch.long, device=self.device)
        # depth별 실제 width 저장
        self.depth_widths = []
        # 현재 depth의 width (동적으로 변경됨)
        self.current_width = 0
        # breakpoint()

    def initialize(self, logits):
        # 첫 번째 depth의 width를 랜덤하게 결정
        self.current_width = self.tree_width_calculate(max_width=self.max_nnodes)
        self.depth_widths.append(self.current_width)
        
        logits, ids = torch.topk(logits[0][-1], k=self.current_width, dim=-1)
        self.weight_matrix[self.depth, :self.current_width].copy_(logits)
        self.input_ids_matrix[self.depth, :self.current_width].copy_(ids)
        
        rows = torch.arange(self.current_width, device=self.device)
        self.parents_matrix[0, :self.current_width].copy_(rows)
        
        position_id = torch.zeros([self.current_width], dtype=torch.long, device=self.device)
        tri = torch.eye(self.current_width, dtype=torch.int8, device=self.device)
        
        output_dict = {
            "input_ids": ids,   # [DH] logits 중 선택된 상위 N개 토큰의 인덱스 (N은 랜덤)
            "position_ids": position_id + 1,   # [DH] 몇 번째 depth인지, initialize 시 1로 초기화됨
            "attention_mask": tri,  # [DH] attention mask는 identity matrix로 초기화됨
            "parent_last": rows,
            "is_final": False
        }
        self.depth += 1
        return output_dict
    
    def add(self, logits):
        prev_width = self.current_width  # 이전 depth의 width
        # 새로운 depth의 width를 랜덤하게 결정
        self.current_width = self.tree_width_calculate(max_width=self.max_nnodes)
        self.depth_widths.append(self.current_width)
        
        # 각 노드마다 current_width개의 후보 선택
        logits, ids = torch.topk(logits[0], k=self.current_width, dim=-1)   # [DH] (prev_width x current_width)
        last_layer_weights = self.weight_matrix[self.depth-1, :prev_width].unsqueeze(1)  # [DH] (prev_width, 1)
        logits = logits * last_layer_weights    # [DH] 루트로부터 방금 들어온 logits까지의 경로의 확률을 구하기 위해 곱합. Broadcasting으로 각 부모의 weight가 해당 부모의 자식들에게 곱해짐
        
        flat_logits, flat_ids = logits.view(-1), ids.view(-1)  # [DH] (prev_width x current_width) -> (prev_width * current_width)
        global_top_logits, global_top_idx = torch.topk(flat_logits, k=self.current_width, dim=-1)   # [DH] prev_width개의 부모로부터 나온 확률 중 current_width개를 선택
        input_ids = flat_ids[global_top_idx]
        parents = global_top_idx // self.current_width  # [DH] 부모의 인덱스
        
        self.parents_matrix[self.depth, :self.current_width].copy_(parents)
        self.weight_matrix[self.depth, :self.current_width].copy_(global_top_logits)
        self.input_ids_matrix[self.depth, :self.current_width].copy_(input_ids)
        
        rows = torch.arange(self.current_width, device=self.device)
        kv_cache_mask = torch.zeros([self.current_width, prev_width], dtype=torch.int8, device=self.device) 
        # [DH] (current_width, prev_width) 형태의 matrix. 현새 depth에서 선택된 토큰들의 부모가 몇 번째 parent인지를 나타냄. 
        # (첫 번째 토큰의 부모의 index가 3이면 (0, 3) 위치에 1로 체크됨)
        kv_cache_mask[rows, parents] = 1
        
        # kv_mask 업데이트
        if self.depth == 1:
            kv_mask = kv_cache_mask
        else:
            # 이전 kv_mask에서 parent에 해당하는 행만 선택
            prev_kv_mask = getattr(self, '_prev_kv_mask', torch.zeros([prev_width, 0], dtype=torch.int8, device=self.device))
            kv_mask = torch.cat([prev_kv_mask[parents], kv_cache_mask], dim=1)
        
        self._prev_kv_mask = kv_mask
        
        tri = torch.eye(self.current_width, dtype=torch.int8, device=self.device)
        attention_mask = torch.cat([kv_mask, tri], dim=1)    # [DH] 선택된 child들의 attention mask
        
        position_id = torch.zeros([self.current_width], dtype=torch.long, device=self.device)
        output_dict = {
            "input_ids": input_ids,  # [DH] prev_width개의 부모로부터 나온 자식 중 선택된 current_width개
            "position_ids": position_id + (self.depth + 1),  # [DH] 몇 번째 depth인지
            "attention_mask": attention_mask,
            "parent_last": parents,
            "is_final": False
        }
        self.depth += 1
        return output_dict
    
    def generate_attention_mask(self, parents, final_width):
        attention_mask = torch.eye(final_width, dtype=torch.int8, device=self.device)
        grandp = parents.clone()
        for _ in range(self.depth - 2):
            rows = torch.arange(final_width, device=self.device)
            attention_mask[rows, grandp] = 1
            grandp = grandp[parents]
        return attention_mask

    def update(self, logits, print_tree=False, tokenizer=None):
        if self.depth == 0:
            result = self.initialize(logits)
            if print_tree:
                self.print_tree_structure_hierarchical(tokenizer)
            return result
        outputs = self.add(logits)
        if print_tree:
            self.print_tree_structure_hierarchical(tokenizer)
        
        # breakpoint()
        
        # 각 depth의 width가 다르므로, 전체 노드 수를 계산
        total_nodes = sum(self.depth_widths[:self.depth-1])
        
        # 최종 선택할 노드 수: 현재 depth의 width 사용 (add 함수에서 이미 결정됨)
        final_width = self.current_width  # 또는 self.depth_widths[-1]
        
        # weight_matrix에서 유효한 값들만 선택
        valid_weights = []
        for d in range(self.depth - 1):
            valid_weights.append(self.weight_matrix[d, :self.depth_widths[d]])
        flat_weights = torch.cat(valid_weights)
        
        top_weights, top_index = torch.topk(flat_weights, k=min(final_width, len(flat_weights), self.max_nnodes), dim=-1)
        weight = top_weights.sum()
        
        # [DH] 방금 만들어진 레이어에서 뽑은 child들의 확률의 합이 이전 레이어에서의 확률의 합보다 작다->굳이 볼 필요 없음 따라서 종료.
        # 만약 크다->더 탐색하기
        if weight - self.weight > self.threshold and self.depth < self.max_depth and self.depth_algorithm(): # 여기다가 depth 관련 알고리즘 삽입 (depth 확장 조건)
            self.weight = weight
        else:   # [DH] 트리 depth 확장이 종료되는 경우.
            # breakpoint()
            # top_index를 depth와 column으로 변환
            rows = torch.zeros_like(top_index)
            cols = top_index.clone()
            cumsum = 0
            for d in range(self.depth - 1):
                mask = (top_index >= cumsum) & (top_index < cumsum + self.depth_widths[d])
                rows[mask] = d  # [DH] 각 토큰의 depth 인덱스
                cols[mask] = top_index[mask] - cumsum  # [DH] 각 토큰의 각 depth에서의 column 인덱스
                cumsum += self.depth_widths[d]
            # breakpoint()
            sorted_indices = torch.argsort(rows)
            rows = rows[sorted_indices]   # [DH] 부모 인덱스 기준 정렬
            cols = cols[sorted_indices]   # [DH] 부모 인덱스 기준 정렬
            
            # # index 계산 (각 depth의 width 고려)
            # index_list = []
            # cumsum = 0
            # for d in range(self.depth - 1):
            #     depth_indices = torch.arange(cumsum, cumsum + self.depth_widths[d], device=self.device)
            #     index_list.append(depth_indices)
            #     cumsum += self.depth_widths[d]
            
            input_ids = self.input_ids_matrix[rows, cols]
            position_ids = rows + 1
            parents = self.parents_matrix[rows, cols]
            
            # source_idx와 parent_idx 계산
            source_idx = torch.zeros_like(rows)
            parent_idx = torch.zeros_like(rows)
            for i, (r, c) in enumerate(zip(rows, cols)):
                r_item = r.item()
                c_item = c.item()
                # source_idx: 현재 노드의 전역 인덱스
                cumsum = sum(self.depth_widths[:r_item])
                source_idx[i] = cumsum + c_item
                
                # parent_idx: 부모 노드의 전역 인덱스
                if r_item > 0:
                    parent_depth = r_item - 1
                    parent_col = parents[i].item()
                    parent_cumsum = sum(self.depth_widths[:parent_depth])
                    parent_idx[i] = parent_cumsum + parent_col
                else:
                    parent_idx[i] = parents[i]
            # breakpoint()
            parents_index = torch.nonzero(source_idx.unsqueeze(0) == parent_idx.unsqueeze(1))[:, 1]
            
            attention_mask = self.generate_attention_mask(parents_index, len(top_index))
            outputs = {
                "input_ids": input_ids,  # [DH] 선택된 노드들 (부모 인덱스 순으로 정렬됨)
                "position_ids": position_ids,  # [DH] 몇 번째 depth인지
                "attention_mask": attention_mask,
                "parent_last": parents_index,  # [DH] 선택된 노드들의 부모 인덱스 (상대적인 인덱스)
                "is_final": True
            }
        return outputs

    def depth_algorithm(self):  # 여기다가 depth 관련 알고리즘 삽입 (depth 확장 조건)
        return True

    def tree_width_calculate(self, max_width: int = 100):   # 여기다가 width 알고리즘 삽입
        # 50, 60, 70, 80, 90, 100 중에서 랜덤하게 선택
        return random.choice([50, 60, 70, 80, 90, 100])
    
    def print_tree_structure(self, tokenizer=None):
        """
        트리 구조를 시각적으로 출력하는 함수
        Args:
            tokenizer: 토큰 ID를 텍스트로 변환하기 위한 tokenizer (선택사항)
        """
        print("\n" + "="*80)
        print(f"Tree Structure (Current Depth: {self.depth}, Max Depth: {self.max_depth})")
        print("="*80)
        
        if self.depth == 0:
            print("Tree is empty (depth=0)")
            return
        
        # 각 depth별로 노드 정보 수집
        for d in range(self.depth):
            width = self.depth_widths[d] if d < len(self.depth_widths) else 0
            print(f"\nDepth {d} (width={width}):")
            print("-" * 80)
            
            for i in range(width):
                token_id = self.input_ids_matrix[d, i].item()
                weight = self.weight_matrix[d, i].item()
                parent_idx = self.parents_matrix[d, i].item() if d > 0 else -1
                
                # 토큰 텍스트 변환
                if tokenizer:
                    try:
                        token_text = tokenizer.decode([token_id])
                        token_text = repr(token_text)  # 특수문자 표시
                    except:
                        token_text = "<?>"
                else:
                    token_text = ""
                
                # 노드 정보 출력
                if d == 0:
                    print(f"  [{d},{i:2d}] token_id={token_id:5d} {token_text:20s} weight={weight:.6f}")
                else:
                    print(f"  [{d},{i:2d}] token_id={token_id:5d} {token_text:20s} weight={weight:.6f} <- parent=[{d-1},{parent_idx:2d}]")
        
        print("="*80 + "\n")
    
    def print_tree_structure_hierarchical(self, tokenizer=None):
        """
        트리 구조를 계층적으로 출력하는 함수 (트리 형태로 표현)
        Args:
            tokenizer: 토큰 ID를 텍스트로 변환하기 위한 tokenizer (선택사항)
        """
        print("\n" + "="*100)
        print(f"Tree Structure - Hierarchical View (Current Depth: {self.depth})")
        print("="*100)
        
        if self.depth == 0:
            print("Tree is empty (depth=0)")
            return
        
        # 각 depth별로 부모-자식 관계 구축
        children_map = {}  # {(depth, idx): [(child_depth, child_idx), ...]}
        
        for d in range(self.depth):
            width = self.depth_widths[d] if d < len(self.depth_widths) else 0
            for i in range(width):
                if d > 0:
                    parent_idx = self.parents_matrix[d, i].item()
                    parent_key = (d-1, parent_idx)
                    if parent_key not in children_map:
                        children_map[parent_key] = []
                    children_map[parent_key].append((d, i))
        
        # 재귀적으로 트리 출력
        def print_node(depth, idx, prefix="", is_last=True):
            width = self.depth_widths[depth] if depth < len(self.depth_widths) else 0
            if idx >= width:
                return
            
            token_id = self.input_ids_matrix[depth, idx].item()
            weight = self.weight_matrix[depth, idx].item()
            
            # 토큰 텍스트 변환
            if tokenizer:
                try:
                    token_text = tokenizer.decode([token_id])
                    token_text = repr(token_text)[:15]  # 길이 제한
                except:
                    token_text = "<?>"
            else:
                token_text = f"id={token_id}"
            
            # 현재 노드 출력
            connector = "└─" if is_last else "├─"
            print(f"{prefix}{connector} [{depth},{idx:2d}] {token_text:15s} (w={weight:.4f})")
            
            # 자식 노드들 출력
            node_key = (depth, idx)
            if node_key in children_map:
                children = children_map[node_key]
                extension = "   " if is_last else "│  "
                for i, child in enumerate(children):
                    is_last_child = (i == len(children) - 1)
                    print_node(child[0], child[1], prefix + extension, is_last_child)
        
        # Depth 0의 모든 노드부터 시작
        width_0 = self.depth_widths[0] if len(self.depth_widths) > 0 else 0
        for i in range(width_0):
            is_last = (i == width_0 - 1)
            print_node(0, i, "", is_last)
        
        print("="*100 + "\n")