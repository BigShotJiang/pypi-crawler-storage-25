import torch
import random
import time
import json
import os
import math

class Tree:
    def __init__(
        self,
        nnodes,
        device,
        max_depth,
        per_token_probability_bound=0.0,
        per_path_probability_bound=0.0,
        fixed_width=None,
        fixed_nnodes=False,
        fixed_depth=False,
        min_width=3,
        profile_data=None,
        target_profile_data=None,
        draft_per_sec_cost=0.0,
        target_per_sec_cost=0.0,
        cost_sensitivity=0.0,
        per_token_draft_to_target_transfer_time=0.0,
        per_token_target_to_draft_transfer_time=0.0,
        target_time_scale: float = 1.0,
        accept_length_scale: float = 1.0,
    ):
        self.max_nnodes = nnodes  # 최대 노드 수 (max_width)
        self.device = device
        self.depth = 0
        self.weight = 0
        self.per_token_probability_bound = per_token_probability_bound  # 각 토큰의 확률이 이 값보다 작으면 버림
        self.per_path_probability_bound = per_path_probability_bound  # 각 경로의 확률이 이 값보다 작으면 버림
        self.max_depth = max_depth
        self.fixed_width = fixed_width  # 프로파일링용: 특정 width로 고정 (None이면 동적)
        self.fixed_nnodes = fixed_nnodes
        self.fixed_depth = fixed_depth
        self.min_width = min_width
        # 프로파일링 데이터 (width별 model_call_avg_time_ms를 포함하는 딕셔너리)
        self.profile_data = profile_data  # {width: {"model_call_avg_time_ms": ...}, ...}
        # Target 프로파일링 데이터 (width_depth_nnodes별 avg_time_ms를 포함하는 딕셔너리)
        self.target_profile_data = target_profile_data  # {"width_X_depth_Y_nnodes_Z": {"width": X, "depth": Y, "max_nnodes": Z, "avg_time_ms": ...}, ...}
        # Target 프로파일링 시간 보정 스케일 (실측/예측 비율 평균값, 다음 슬롯에 적용)
        self.target_time_scale = float(target_time_scale) if target_time_scale is not None else 1.0
        # expected_accept_length 보정 스케일 (실측/예측 비율 평균값, 다음 슬롯부터 적용)
        self.accept_length_scale = float(accept_length_scale) if accept_length_scale is not None else 1.0
        # 이전 tree (확장 이전)의 정보
        self.prev_final_nnodes = 0  # 이전 tree의 top_index 개수 (final_width)
        self.prev_depth = 0  # 이전 tree의 depth
        self.prev_width = 0  # 이전 tree의 width
        # 토큰별 전송 시간 (DraftRunner에서 업데이트된 값 사용)
        self.per_token_draft_to_target_transfer_time = per_token_draft_to_target_transfer_time  # 토큰별 Draft → Target 전송 시간 (초 단위)
        self.per_token_target_to_draft_transfer_time = per_token_target_to_draft_transfer_time  # 토큰별 Target → Draft 전송 시간 (초 단위)
        # 초당 비용
        self.draft_per_sec_cost = draft_per_sec_cost
        self.target_per_sec_cost = target_per_sec_cost
        # Cost sensitivity (0 to infinity)
        self.cost_sensitivity = cost_sensitivity
        # Depth별 통계 수집용 (JSON 저장용)
        self.depth_stats = {}  # {depth: {"prev_sum_expected_accepted_length": [...], "sum_expected_accepted_length": [...], "per_token_latency_diff": [...], "per_token_cost_diff": [...]}}
        # 알고리즘 실행 시간 수집용
        self.width_algorithm_times = []  # width 선택 알고리즘 실행 시간 (초)
        self.nnodes_algorithm_times = []  # final_nnodes 선택 알고리즘 실행 시간 (초)
        # 매트릭스는 최대 크기로 할당
        self.weight_matrix = torch.zeros([max_depth, self.max_nnodes], device=self.device)
        self.input_ids_matrix = torch.zeros([max_depth, self.max_nnodes], dtype=torch.long, device=self.device)
        self.parents_matrix = torch.zeros([max_depth, self.max_nnodes], dtype=torch.long, device=self.device)
        # depth별 실제 width 저장
        self.depth_widths = []
        # 현재 depth의 width (동적으로 변경됨)
        self.current_width = 0
        # width별 model.model() 호출 시간 측정용
        self.width_times = {}  # {width: [time1, time2, ...]}
        # 이번 tree 생성 동안 draft 모델 호출에 사용된 시간의 총합
        self.draft_total_time = 0.0
        # 이전 draft 모델 호출에 사용된 시간의 총합
        self.prev_draft_total_time = 0.0
        # 이번 tree 생성 동안 draft 모델 호출에 사용된 예상 시간의 총합 (프로파일링 데이터는 draft_time 기준)
        self.expected_draft_total_time = 0.0
        # 예상 accept length의 합
        self.sum_expected_accepted_length = 1.0
        # 이전 예상 accept length의 합
        self.prev_sum_expected_accepted_length = 1.0
        # 이전 계산값 저장 (재사용을 위해)
        self.prev_target_time = 0.2  # 이전 target 시간 (초)
        self.prev_per_token_latency = None  # 이전 per_token_latency
        self.prev_per_token_cost = None  # 이전 per_token_cost
        # breakpoint()
        self.final_nnodes = 0  # 최종 전송할 노드 수

    def initialize(self, logits):
        # 이번 tree 생성 동안 draft 모델 호출에 사용된 시간의 총합 초기화
        self.draft_total_time = 0.0
        # 이번 tree 생성 동안 draft 모델 호출에 사용된 예상 시간의 총합 초기화 (프로파일링 데이터는 draft_time 기준)
        self.expected_draft_total_time = 0.0
        # 이전 depth의 width 초기화 (첫 번째 depth이므로 이전 width가 없음)
        self.prev_final_nnodes = 0  # 이전 tree의 top_index 개수 (final_width)
        self.prev_depth = 0  # 이전 tree의 depth
        self.prev_width = 0  # 이전 tree의 width
        # 예상 accept length의 합 초기화
        self.sum_expected_accepted_length = 1.0
        # 이전 예상 accept length의 합 초기화
        self.prev_sum_expected_accepted_length = 1.0
        # 이전 계산값 초기화
        self.prev_target_time = 0.2
        self.prev_per_token_latency = None
        self.prev_per_token_cost = None
        # Depth별 통계 초기화 (새로운 tree 생성 시)
        self.depth_stats = {}
        
        # 첫 번째 depth의 width를 확률 바운드를 적용하여 결정
        # initialize의 경우 이전 depth가 없으므로 per_token_probability_bound만 적용
        single_logits = logits[0][-1]  # (vocab_size,)
        
        # 1. per_token_probability_bound보다 낮은 값을 0으로 변경
        probs = torch.softmax(single_logits, dim=-1)  # (vocab_size,)
        if self.per_token_probability_bound > 0.0:
            probs = torch.where(probs >= self.per_token_probability_bound, probs, torch.zeros_like(probs))
        
        # 2. 남아있는 노드 중 0이 아닌 것의 개수를 계산하여 current_width 설정
        # initialize에서는 경로 확률을 구할 수 없으므로 per_token만 확인
        if self.fixed_width is not None:
            # 프로파일링 모드: fixed_width로 고정
            self.current_width = min(self.fixed_width, self.max_nnodes)
        else:
            valid_mask = probs > 0
            valid_count = valid_mask.sum().item()
            self.current_width = min(max(valid_count, 1), self.max_nnodes)  # 최소 1, 최대 max_nnodes
        self.depth_widths.append(self.current_width)
        
        # 3. 토큰 확률이 높은 순서로 current_width개 선택
        top_logits, ids = torch.topk(probs, k=self.current_width, dim=-1)
        # NOTE(원래 동작): weight_matrix에는 선택된 토큰의 "logits"를 저장
        selected_logits = single_logits[ids]
        self.weight_matrix[self.depth, :self.current_width].copy_(selected_logits)
        self.input_ids_matrix[self.depth, :self.current_width].copy_(ids)
        
        rows = torch.arange(self.current_width, device=self.device)
        self.parents_matrix[0, :self.current_width].copy_(rows)
        
        position_id = torch.zeros([self.current_width], dtype=torch.long, device=self.device)
        tri = torch.eye(self.current_width, dtype=torch.int8, device=self.device)
        
        # max_depth가 1이면 initialize 후 바로 종료
        is_final = (self.depth + 1 >= self.max_depth)
        
        output_dict = {
            "input_ids": ids,   # [DH] logits 중 선택된 상위 N개 토큰의 인덱스 (N은 랜덤)
            "position_ids": position_id + 1,   # [DH] 몇 번째 depth인지, initialize 시 1로 초기화됨
            "attention_mask": tri,  # [DH] attention mask is identity matrix로 초기화됨
            "parent_last": rows,
            "is_final": is_final
        }
        self.depth += 1
        return output_dict
    
    def add(self, logits):
        self.prev_width = self.current_width  # 이전 depth의 width
        
        # logits는 이미 확률로 변환된 상태 (softmax 적용됨)
        probs = logits[0]  # (self.prev_width, vocab_size)
        
        # 이하 width 결정 알고리즘 
        # 1. per_token_probability_bound보다 낮은 확률을 0으로 설정
        if self.per_token_probability_bound > 0.0:
            probs = torch.where(probs >= self.per_token_probability_bound, probs, torch.zeros_like(probs))
        
        # 2. 루트로부터의 경로 확률을 구하고, per_path_probability_bound보다 낮은 경우 0으로 변경
        last_layer_weights = self.weight_matrix[self.depth-1, :self.prev_width].unsqueeze(1)  # (self.prev_width, 1)
        path_probs = probs * last_layer_weights  # (self.prev_width, vocab_size) - 경로 확률 = 부모의 경로 확률 * 자식의 토큰 확률
        
        # per_path_probability_bound보다 낮은 경로 확률을 0으로 설정
        if self.per_path_probability_bound > 0.0:
            path_probs = torch.where(path_probs >= self.per_path_probability_bound, path_probs, torch.zeros_like(path_probs))
        
        # 3. flat_path_probs 계산 (항상 필요)
        flat_path_probs = path_probs.view(-1)  # (self.prev_width * vocab_size)
        
        # 4. 각 width 후보에 대해 목적 함수 계산하여 최적의 current_width 결정
        if self.fixed_width is not None:
            # 프로파일링 모드: fixed_width로 고정
            self.current_width = min(self.fixed_width, self.max_nnodes)
        else:
            # 선택 가능한 width: 3, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 (max_nnodes 이하만)
            candidate_widths = [3, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
            candidate_widths = [w for w in candidate_widths if w <= self.max_nnodes]
            
            # valid_count 확인
            valid_mask = flat_path_probs > 0
            valid_count = valid_mask.sum().item()
            
            # 최소 1개는 선택해야 함
            candidate_widths = [w for w in candidate_widths if w >= 1 and w <= valid_count]
            if not candidate_widths:
                # 후보가 없으면 최소 1개 선택
                candidate_widths = [min(max(valid_count, 1), self.max_nnodes)]
            
            best_width = candidate_widths[0] if candidate_widths else min(max(valid_count, 1), self.max_nnodes)
            best_objective = float('inf')
            
            # 현재까지의 latency와 cost
            current_latency = self.draft_total_time
            current_cost = self.draft_total_time * self.draft_per_sec_cost
            
            # width 선택 알고리즘 시간 측정 시작
            width_algorithm_start_time = time.time()

            # 최적화: 후보 width마다 torch.topk/대형 clone을 반복하지 않기 위해
            # (1) topk를 최대 width에 대해 1번만 수행하고 prefix sum으로 재사용
            # (2) depth별 확률 합(depth_probs)은 이전 depth들은 고정이므로 한 번만 계산
            prev_depth_probs = []
            for d in range(self.depth):
                w = self.weight_matrix[d, :self.depth_widths[d]]
                prob_sum = w.sum()
                prev_depth_probs.append(float(prob_sum.item()) if isinstance(prob_sum, torch.Tensor) else float(prob_sum))

            max_k = max(candidate_widths) if candidate_widths else 1
            # 안전: max_k는 flat_path_probs 길이를 넘을 수 없음
            max_k = min(int(max_k), int(flat_path_probs.numel()))
            # 후보들이 모두 0이 되는 경우 방지
            if max_k <= 0:
                max_k = 1

            topk_logits_all, topk_idx_all = torch.topk(flat_path_probs, k=max_k, dim=-1)
            topk_prefix_sum = torch.cumsum(topk_logits_all, dim=0)
            
            # 각 width 후보에 대해 목적 함수 계산
            for candidate_width in candidate_widths:
                # 후보 width의 새 depth 확률합은 topk prefix sum으로 즉시 계산 가능
                if candidate_width <= 0:
                    new_depth_prob = 0.0
                else:
                    new_depth_prob = float(topk_prefix_sum[int(candidate_width) - 1].item())

                # 이전 depth들은 고정이므로 prev_depth_probs를 재사용하고, 마지막에 새 depth 확률합만 추가
                temp_depth_probs = prev_depth_probs + [new_depth_prob]
                
                # 앞 레이어의 확률은 뒷 레이어를 뺀 값으로 재정의
                # 예: [1, 0.9, 0.58] → [1-0.9, 0.9-0.58, 0.58] = [0.1, 0.32, 0.58]
                temp_adjusted_depth_probs = []
                if temp_depth_probs:
                    for i in range(len(temp_depth_probs)):
                        if i == len(temp_depth_probs) - 1:
                            # 마지막 레이어는 그대로
                            adj_prob = temp_depth_probs[i]
                        else:
                            # 앞 레이어에서 뒷 레이어를 뺌 (음수 방지)
                            adj_prob = max(0.0, temp_depth_probs[i] - temp_depth_probs[i + 1])
                        
                        # NaN 체크 및 유효성 검사
                        if math.isnan(adj_prob) or adj_prob < 0:
                            adj_prob = 0.0
                        temp_adjusted_depth_probs.append(adj_prob)
                
                # 각 레이어에 (depth+1)을 곱해서 합산
                # 예: 0.1*1 + 0.32*2 + 0.58*3
                if temp_adjusted_depth_probs:
                    temp_sum_expected_accepted_length = sum(adj_prob * float(d + 1) for d, adj_prob in enumerate(temp_adjusted_depth_probs))
                    # NaN 체크 및 최소값 보장
                    if math.isnan(temp_sum_expected_accepted_length) or temp_sum_expected_accepted_length <= 0:
                        if os.environ.get("MOBITREE_DEBUG_EXPECTED_LEN", "0") == "1":
                            print(f"[WARNING] temp_sum_expected_accepted_length is invalid (NaN or <= 0): {temp_sum_expected_accepted_length}, setting to 1.0")
                        temp_sum_expected_accepted_length = 1.0
                else:
                    if os.environ.get("MOBITREE_DEBUG_EXPECTED_LEN", "0") == "1":
                        print(f"[WARNING] temp_adjusted_depth_probs is empty, setting temp_sum_expected_accepted_length to 1.0")
                    temp_sum_expected_accepted_length = 1.0
                
                # 다음 draft_model.model 호출에 필요한 예측 latency와 cost 계산
                # 프로파일링 데이터에서 현재 width(candidate_width)에 해당하는 draft_model.model 호출 예측 시간 사용
                if self.profile_data is not None:
                    width_str = str(candidate_width)
                    if width_str in self.profile_data:
                        # 프로파일링 데이터: model_call_avg_time_ms를 우선 사용
                        next_predicted_time_sec = (
                            self.profile_data[width_str].get("model_call_avg_time_ms", 0.0) / 1000.0
                        )
                    else:
                        # 프로파일링 데이터가 없으면 현재 측정된 draft_model.model 호출 시간 사용
                        if candidate_width in self.width_times and len(self.width_times[candidate_width]) > 0:
                            next_predicted_time_sec = sum(self.width_times[candidate_width]) / len(self.width_times[candidate_width])
                        else:
                            next_predicted_time_sec = 0.01  # 기본값 10ms
                else:
                    # 프로파일링 데이터가 없으면 현재 측정된 draft_model.model 호출 시간 사용
                    if candidate_width in self.width_times and len(self.width_times[candidate_width]) > 0:
                        next_predicted_time_sec = sum(self.width_times[candidate_width]) / len(self.width_times[candidate_width])
                    else:
                        next_predicted_time_sec = 0.01  # 기본값 10ms
                
                # draft_tree_latency = 현재 latency + 다음 draft_model.model 호출의 예측 latency
                draft_tree_latency = current_latency + next_predicted_time_sec
                
                # draft_cost = 현재 cost + 다음 draft_model.model 호출의 예측 cost
                next_predicted_cost = next_predicted_time_sec * self.draft_per_sec_cost
                draft_cost = current_cost + next_predicted_cost
                
                # 목적 함수: (draft_tree_latency - cost_sensitivity * draft_cost) / expected_accept_length
                # accept_length_scale을 적용해 expected_accept_length를 보정한다.
                denom_expected = float(temp_sum_expected_accepted_length) * float(self.accept_length_scale)
                if denom_expected > 0:
                    objective = (draft_tree_latency + self.cost_sensitivity * draft_cost) / (denom_expected + 1.0)
                else:
                    objective = float('inf')
                
                # 목적 함수를 최소화하는 width 선택
                if objective < best_objective:
                    best_objective = objective
                    best_width = candidate_width
            
            # width 선택 알고리즘 시간 측정 종료 및 저장
            width_algorithm_time = time.time() - width_algorithm_start_time
            self.width_algorithm_times.append(width_algorithm_time)
            
            self.current_width = best_width
        
        self.depth_widths.append(self.current_width)
        
        # 5. 경로 확률이 높은 순서로 current_width개 선택
        # 최적화: 위에서 이미 topk(max_k)를 구한 경우 prefix slice로 재사용
        if self.fixed_width is None and 'topk_logits_all' in locals() and topk_logits_all is not None and self.current_width <= int(topk_logits_all.numel()):
            global_top_logits = topk_logits_all[: self.current_width]
            global_top_idx = topk_idx_all[: self.current_width]
        else:
            global_top_logits, global_top_idx = torch.topk(flat_path_probs, k=self.current_width, dim=-1)
        
        # global_top_idx를 (self.prev_width, vocab_size) 좌표로 변환
        vocab_size = probs.size(1)
        parents = global_top_idx // vocab_size  # 부모 인덱스
        input_ids = global_top_idx % vocab_size  # 토큰 ID
        
        # parents 인덱스가 self.prev_width 범위 내에 있는지 확인 및 클램핑
        parents = torch.clamp(parents, 0, self.prev_width - 1)
        
        self.parents_matrix[self.depth, :self.current_width].copy_(parents)
        self.weight_matrix[self.depth, :self.current_width].copy_(global_top_logits)
        self.input_ids_matrix[self.depth, :self.current_width].copy_(input_ids)
        
        rows = torch.arange(self.current_width, device=self.device)
        kv_cache_mask = torch.zeros([self.current_width, self.prev_width], dtype=torch.int8, device=self.device) 
        # [DH] (current_width, self.prev_width) 형태의 matrix. 현새 depth에서 선택된 토큰들의 부모가 몇 번째 parent인지를 나타냄. 
        # (첫 번째 토큰의 부모의 index가 3이면 (0, 3) 위치에 1로 체크됨)
        kv_cache_mask[rows, parents] = 1
        
        # kv_mask 업데이트
        if self.depth == 1:
            kv_mask = kv_cache_mask
        else:
            # 이전 kv_mask에서 parent에 해당하는 행만 선택
            prev_kv_mask = getattr(self, '_prev_kv_mask', torch.zeros([self.prev_width, 0], dtype=torch.int8, device=self.device))
            kv_mask = torch.cat([prev_kv_mask[parents], kv_cache_mask], dim=1)
        
        self._prev_kv_mask = kv_mask
        
        tri = torch.eye(self.current_width, dtype=torch.int8, device=self.device)
        attention_mask = torch.cat([kv_mask, tri], dim=1)    # [DH] 선택된 child들의 attention mask
        
        position_id = torch.zeros([self.current_width], dtype=torch.long, device=self.device)
        output_dict = {
            "input_ids": input_ids,  # [DH] self.prev_width개의 부모로부터 나온 자식 중 선택된 current_width개
            "position_ids": position_id + (self.depth + 1),  # [DH] 몇 번째 depth인지
            "attention_mask": attention_mask,
            "parent_last": parents,
            "is_final": False
        }
        self.depth += 1
        return output_dict
    
    def generate_attention_mask(self, parents, final_width):
        attention_mask = torch.eye(final_width, dtype=torch.int8, device=self.device)
        grandp = parents.clone()
        for _ in range(self.depth - 2):
            rows = torch.arange(final_width, device=self.device)
            attention_mask[rows, grandp] = 1
            grandp = grandp[parents]
        return attention_mask

    def get_objective_value(self, valid_weights):
        """
        objective_value를 최소화하는 final_nnodes를 찾는 함수
        
        Args:
            valid_weights: 각 depth별 weight 텐서 리스트
        
        Returns:
            tuple: (objective_value, top_index, weight, per_token_latency_diff, per_token_cost_diff, 
                    current_target_time, current_per_token_latency, current_per_token_cost)
        """
        flat_weights = torch.cat(valid_weights)
        max_available_nodes = len(flat_weights)
        
        # fixed_nnodes가 True이면 max_nnodes로 고정 (안전한 범위 내에서)
        if self.fixed_nnodes:
            # max_nnodes와 실제 사용 가능한 노드 수 중 작은 값 사용
            fixed_nnodes_val = min(self.max_nnodes, max_available_nodes) if max_available_nodes > 0 else 1
            candidate_nnodes = [fixed_nnodes_val]
        else:
            # final_nnodes 후보 리스트
            candidate_nnodes = [3, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
            # 실제 사용 가능한 노드 수를 초과하지 않도록 필터링
            candidate_nnodes = [n for n in candidate_nnodes if n <= max_available_nodes]
            if not candidate_nnodes:
                # 후보가 없으면 최대 사용 가능한 노드 수 사용
                candidate_nnodes = [max_available_nodes] if max_available_nodes > 0 else [1]
        
        # 이전 target 시간 재사용
        prev_target_time = self.prev_target_time
        
        # 이전 target 시간이 아직 계산되지 않은 경우에만 계산 (첫 번째 호출인 경우)
        if self.prev_final_nnodes > 0 and self.target_profile_data is not None and prev_target_time == 0.2:
            prev_tree_depth_for_key = self.prev_depth if self.prev_depth > 0 else 1
            prev_profile_key = f"width_{self.prev_final_nnodes}_depth_{prev_tree_depth_for_key}_nnodes_{self.prev_final_nnodes}"
            if prev_profile_key in self.target_profile_data:
                prev_target_time_ms = self.target_profile_data[prev_profile_key].get("avg_time_ms", 0.0)
                prev_target_time = (prev_target_time_ms * self.target_time_scale) / 1000.0
                self.prev_target_time = prev_target_time
        
        # 이전 per_token_latency와 per_token_cost 재사용 (첫 번째 호출이 아니면)
        # accept_length_scale을 적용해 expected_accept_length(분모)를 보정한다.
        prev_scaled_sum = float(self.prev_sum_expected_accepted_length) * float(self.accept_length_scale)
        safe_prev_sum = max(1.0, prev_scaled_sum) if prev_scaled_sum > 0 else 1.0
        denom_prev_sum = safe_prev_sum + 1.0
        if self.prev_per_token_latency is not None:
            prev_per_token_latency = self.prev_per_token_latency
        else:
            prev_per_token_latency = (self.prev_draft_total_time+self.per_token_draft_to_target_transfer_time*self.prev_final_nnodes+prev_target_time)/denom_prev_sum
        
        if self.prev_per_token_cost is not None:
            prev_per_token_cost = self.prev_per_token_cost
        else:
            prev_per_token_cost = (self.prev_draft_total_time*self.draft_per_sec_cost + prev_target_time*self.target_per_sec_cost)/denom_prev_sum
        
        # final_nnodes 선택 알고리즘 시간 측정 시작
        nnodes_algorithm_start_time = time.time()
        
        # 각 후보에 대해 objective_value 계산
        best_objective_value = float('inf')
        best_final_nnodes = candidate_nnodes[0]
        best_top_index = None
        best_weight = 0.0
        best_per_token_latency_diff = 0.0
        best_per_token_cost_diff = 0.0
        best_current_target_time = 0.2
        best_sum_expected_accepted_length = 1.0
        
        # 최적화: 후보 nnodes마다 torch.topk/깊이별 마스크/인덱싱을 반복하지 않고,
        # (1) 최대 k에 대해 topk 1번
        # (2) topk 결과(rank 0..k-1)에 대해 "어떤 depth의 노드인지"를 1번 계산
        # (3) depth별 prefix sum을 만들어 각 후보 k에서 O(depth)로 sum_expected_accepted_length 계산
        max_k = max(candidate_nnodes) if candidate_nnodes else 1
        max_k = min(int(max_k), int(flat_weights.numel()))
        if max_k <= 0:
            max_k = 1
        top_weights_all, top_index_all = torch.topk(flat_weights, k=max_k, dim=-1)
        top_weight_prefix = torch.cumsum(top_weights_all, dim=0)

        # rank별 depth id 계산을 위한 경계(cumsum widths) 준비
        # boundaries: [w0, w0+w1, ...] (마지막 depth는 경계 불필요)
        if self.depth_widths and self.depth > 1:
            cum = 0
            boundaries_list = []
            for d in range(self.depth - 1):
                cum += int(self.depth_widths[d])
                boundaries_list.append(cum)
            boundaries = torch.tensor(boundaries_list, device=top_index_all.device, dtype=top_index_all.dtype)
            depth_ids = torch.bucketize(top_index_all, boundaries, right=False)  # 0..depth-1
        else:
            depth_ids = torch.zeros_like(top_index_all)

        # depth별 prefix sum (rank 축 기준) 미리 계산: prefix_by_depth[d][r] = 첫 r+1개 중 depth=d 가중치 합
        # depth는 작고(max_depth <= 10), max_k도 작아서(depth * max_k) 비용은 매우 작음
        top_weights_all_f = top_weights_all.to(dtype=torch.float32)
        prefix_by_depth = []
        for d in range(self.depth):
            mask = (depth_ids == d).to(dtype=torch.float32)
            prefix_by_depth.append(torch.cumsum(top_weights_all_f * mask, dim=0))

        for candidate_nnodes_val in candidate_nnodes:
            k = int(candidate_nnodes_val)
            top_index = top_index_all[:k]
            # weight는 선택된 top-k의 합
            weight = top_weight_prefix[k - 1]
            
            # 선택된 top-k에 대해서만 sum_expected_accepted_length 계산 (prefix_by_depth 재사용)
            selected_depth_probs = []
            eps = 1e-5
            for d in range(self.depth):
                prob_val = float(prefix_by_depth[d][k - 1].item()) if k > 0 else 0.0

                # NaN/미세 오차 클램프 (기존 동작 유지)
                if math.isnan(prob_val):
                    if os.environ.get("MOBITREE_DEBUG_PROB_FILTER", "0") == "1":
                        print(f"[DEBUG] prob_val filtered: {prob_val} (depth={d}, candidate_nnodes_val={candidate_nnodes_val})")
                    continue
                if -eps <= prob_val < 0:
                    prob_val = 0.0
                elif 1 < prob_val <= 1 + eps:
                    prob_val = 1.0
                # 해결책 2: prob_val > 0 필터를 제거해서 selected_depth_probs가 비는 케이스를 방지
                # (0인 depth도 포함해두면 이후 adjusted 계산에서 자연스럽게 영향이 0이 됨)
                if 0.0 <= prob_val <= 1.0:
                    selected_depth_probs.append((d, prob_val))
            
            # 선택된 노드들에 대한 adjusted_depth_probs 계산
            if selected_depth_probs:
                # depth별로 정렬
                selected_depth_probs.sort(key=lambda x: x[0])
                depth_probs_list = [prob for _, prob in selected_depth_probs]
                
                adjusted_depth_probs = []
                for i in range(len(depth_probs_list)):
                    if i == len(depth_probs_list) - 1:
                        adj_prob = depth_probs_list[i]
                    else:
                        adj_prob = max(0.0, depth_probs_list[i] - depth_probs_list[i + 1])
                    
                    if math.isnan(adj_prob) or adj_prob < 0:
                        adj_prob = 0.0
                    adjusted_depth_probs.append(adj_prob)
                
                # 각 레이어에 (depth+1)을 곱해서 합산
                if adjusted_depth_probs:
                    expected_sum = sum(adj_prob * float(selected_depth_probs[i][0] + 1) for i, adj_prob in enumerate(adjusted_depth_probs))
                    if math.isnan(expected_sum) or expected_sum <= 0:
                        if os.environ.get("MOBITREE_DEBUG_EXPECTED_LEN", "0") == "1":
                            print(f"[WARNING] expected_sum is invalid (NaN or <= 0): {expected_sum}, setting sum_expected_accepted_length to 1.0 (candidate_nnodes_val={candidate_nnodes_val})")
                        sum_expected_accepted_length = 1.0
                    else:
                        sum_expected_accepted_length = float(expected_sum)
                else:
                    if os.environ.get("MOBITREE_DEBUG_EXPECTED_LEN", "0") == "1":
                        print(f"[WARNING] adjusted_depth_probs is empty, setting sum_expected_accepted_length to 1.0 (candidate_nnodes_val={candidate_nnodes_val})")
                    sum_expected_accepted_length = 1.0
            else:
                # depth == 1인 경우는 정상 (이전 depth가 없음)
                if self.depth > 1 and os.environ.get("MOBITREE_DEBUG_EXPECTED_LEN", "0") == "1":
                    print(f"[WARNING] selected_depth_probs is empty, setting sum_expected_accepted_length to 1.0 (candidate_nnodes_val={candidate_nnodes_val}, depth={self.depth})")
                sum_expected_accepted_length = 1.0
            
            # 현재 tree의 target 시간 계산
            current_target_time = 0.2
            if self.target_profile_data is not None:
                current_profile_key = f"width_{self.current_width}_depth_{self.depth}_nnodes_{candidate_nnodes_val}"
                if current_profile_key in self.target_profile_data:
                    current_target_time_ms = self.target_profile_data[current_profile_key].get("avg_time_ms", 0.0)
                    current_target_time = (current_target_time_ms * self.target_time_scale) / 1000.0
            
            # objective_value 계산
            # accept_length_scale을 적용해 expected_accept_length(분모)를 보정한다.
            scaled_sum = float(sum_expected_accepted_length) * float(self.accept_length_scale)
            safe_sum = max(1.0, scaled_sum) if scaled_sum > 0 else 1.0
            denom_sum = safe_sum + 1.0
            per_token_latency = (self.draft_total_time+self.per_token_draft_to_target_transfer_time*candidate_nnodes_val+current_target_time)/denom_sum
            per_token_latency_diff = per_token_latency - prev_per_token_latency
            
            per_token_cost = (self.draft_total_time*self.draft_per_sec_cost + current_target_time*self.target_per_sec_cost)/denom_sum
            per_token_cost_diff = per_token_cost - prev_per_token_cost
            
            objective_value = per_token_latency_diff + self.cost_sensitivity * per_token_cost_diff
            
            # 최소 objective_value 업데이트
            if objective_value < best_objective_value:
                best_objective_value = objective_value
                best_final_nnodes = candidate_nnodes_val
                best_top_index = top_index
                best_weight = weight
                best_per_token_latency_diff = per_token_latency_diff
                best_per_token_cost_diff = per_token_cost_diff
                best_current_target_time = current_target_time
                best_sum_expected_accepted_length = sum_expected_accepted_length
        
        # final_nnodes 선택 알고리즘 시간 측정 종료 및 저장
        nnodes_algorithm_time = time.time() - nnodes_algorithm_start_time
        self.nnodes_algorithm_times.append(nnodes_algorithm_time)
        
        # best_top_index가 None인 경우 처리 (후보가 없거나 조건을 만족하지 않은 경우)
        if best_top_index is None:
            # 최소한 하나의 노드는 선택해야 하므로, 첫 번째 후보로 topk 실행
            if len(candidate_nnodes) > 0 and max_available_nodes > 0:
                final_nnodes_val = min(candidate_nnodes[0], max_available_nodes)
                # 위에서 구한 topk 결과가 있으면 재사용
                if 'top_index_all' in locals() and top_index_all is not None and final_nnodes_val <= int(top_index_all.numel()):
                    best_top_index = top_index_all[:final_nnodes_val]
                else:
                    _, best_top_index = torch.topk(flat_weights, k=final_nnodes_val, dim=-1)
                best_final_nnodes = final_nnodes_val
                best_weight = flat_weights[best_top_index].sum()
            else:
                # flat_weights가 비어있는 경우 빈 텐서 반환
                best_top_index = torch.tensor([], dtype=torch.long, device=flat_weights.device)
                best_final_nnodes = 1
                best_weight = 0.0
        
        # 최종 선택된 값들 설정
        self.final_nnodes = best_final_nnodes
        self.sum_expected_accepted_length = best_sum_expected_accepted_length
        
        # 현재 per_token_latency와 per_token_cost 계산 (다음 호출을 위해 저장)
        # NOTE: 다음 호출에서 prev_per_token_latency/prev_per_token_cost를 그대로 재사용하므로,
        # 여기서도 accept_length_scale이 반영된 분모를 사용해야 앞에서의 diff 계산과 일관됩니다.
        scaled_best_sum = float(best_sum_expected_accepted_length) * float(self.accept_length_scale)
        safe_sum = max(1.0, scaled_best_sum) if scaled_best_sum > 0 else 1.0
        denom_best_sum = safe_sum + 1.0
        current_per_token_latency = (self.draft_total_time+self.per_token_draft_to_target_transfer_time*self.final_nnodes+best_current_target_time)/denom_best_sum
        current_per_token_cost = (self.draft_total_time*self.draft_per_sec_cost + best_current_target_time*self.target_per_sec_cost)/denom_best_sum
        
        return best_objective_value, best_top_index, best_weight, best_per_token_latency_diff, best_per_token_cost_diff, best_current_target_time, current_per_token_latency, current_per_token_cost

    def update(self, logits, print_tree=False, tokenizer=None, draft_time=None, draft_time_scale: float = 1.0):
        if self.depth == 0:
            result = self.initialize(logits)
            if print_tree:
                self.print_tree_structure_hierarchical(tokenizer)
            return result
        
        # add() 함수 실행 시간 측정 및 GPU 동기화 (이전 CUDA 연산이 완료되도록 보장)
        if isinstance(logits, torch.Tensor) and logits.is_cuda:
            torch.cuda.synchronize()
        elif isinstance(logits, (list, tuple)) and len(logits) > 0 and isinstance(logits[0], torch.Tensor) and logits[0].is_cuda:
            torch.cuda.synchronize()
        
        # add() 호출 전 시간 측정 시작
        start_time = time.time()
        outputs = self.add(logits)
        
        # GPU 동기화: synchronize()는 add() 내부 CUDA 연산의 완료를 기다리므로 측정 시간에 포함되어야 함
        if isinstance(logits, torch.Tensor) and logits.is_cuda:
            torch.cuda.synchronize()
        elif isinstance(logits, (list, tuple)) and len(logits) > 0 and isinstance(logits[0], torch.Tensor) and logits[0].is_cuda:
            torch.cuda.synchronize()
        
        # synchronize() 후 시간 측정 (add() 내부의 모든 CUDA 연산이 완료된 후)
        elapsed_time = time.time() - start_time
        
        # 이번 tree 생성 동안 draft 모델 호출에 사용된 시간의 총합에 누적
        self.prev_draft_total_time = self.draft_total_time
        # draft_time이 None이 아니면 사용하고, None이면 elapsed_time 사용 (첫 번째 호출인 경우)
        if draft_time is not None:
            self.draft_total_time += draft_time
        else:
            # 첫 번째 호출인 경우 elapsed_time 사용
            self.draft_total_time += elapsed_time
        
        # width별 시간 기록
        # - 우리가 원하는 "draft_time"은 eval_opt_classic_draft.py에서 측정한 draft_model.model() forward 시간이며,
        #   이는 이번 update에서 처리하는 logits의 폭(=이전 depth의 width)과 대응됨.
        # - add()는 update 초반에 self.prev_width = self.current_width로 설정하므로,
        #   draft_time은 self.prev_width 키로 기록하는 것이 맞다.
        current_width = self.current_width
        
        # 이번 tree 생성 동안 draft 모델 호출에 사용된 예상 시간의 총합에 누적
        # 프로파일링 데이터에서 현재 width에 해당하는 model_call_avg_time_ms를 찾아서 더함 (draft_time 기준)
        if self.profile_data is not None:
            width_str = str(self.prev_width)
            if width_str in self.profile_data:
                avg_time_ms = self.profile_data[width_str].get("model_call_avg_time_ms", 0.0)
                # 실측/예측 비율(draft_time/predicted_time_ms)의 평균을 다음 슬롯부터 적용하기 위해,
                # 현재 슬롯에서는 전달받은 draft_time_scale을 곱해 보정된 예측 시간을 사용
                scale = float(draft_time_scale) if draft_time_scale is not None else 1.0
                self.expected_draft_total_time += (avg_time_ms * scale) / 1000.0
            else:
                # 프로파일링 데이터에 해당 width가 없으면 실제 측정 draft_time 사용
                if draft_time is not None:
                    self.expected_draft_total_time += draft_time
                else:
                    # 첫 번째 호출인 경우 elapsed_time 사용
                    self.expected_draft_total_time += elapsed_time
        else:
            # 프로파일링 데이터가 없으면 실제 측정 draft_time 사용
            if draft_time is not None:
                self.expected_draft_total_time += draft_time
            else:
                # 첫 번째 호출인 경우 elapsed_time 사용
                self.expected_draft_total_time += elapsed_time
        # width_times에는 add() 시간이 아니라 draft_model.model() 호출 시간을 기록
        # 첫 번째 update에서는 draft_time이 None일 수 있으므로 그 경우는 기록하지 않음.
        if draft_time is not None:
            width_key = int(self.prev_width)
            if width_key not in self.width_times:
                self.width_times[width_key] = []
            self.width_times[width_key].append(float(draft_time))
        
        if print_tree:
            self.print_tree_structure_hierarchical(tokenizer)
        
        # breakpoint()
        
        # 각 depth의 width가 다르므로, 전체 노드 수를 계산
        total_nodes = sum(self.depth_widths[:self.depth-1])
          
        # weight_matrix에서 유효한 값들만 선택
        # add()에서 self.depth += 1이 실행되었으므로, 현재 depth는 self.depth - 1입니다
        # 따라서 range(self.depth)로 순회해야 현재 depth까지 포함됩니다
        valid_weights = []
        for d in range(self.depth):
            valid_weights.append(self.weight_matrix[d, :self.depth_widths[d]])
        
        self.prev_sum_expected_accepted_length = self.sum_expected_accepted_length
        
        # objective_value 최소화 하는 알고리즘
        objective_value, top_index, weight, per_token_latency_diff, per_token_cost_diff, current_target_time, current_per_token_latency, current_per_token_cost = self.get_objective_value(valid_weights)
        
        # fixed-nnodes가 설정되고 모든 노드를 선택한 경우, tree_temp.py와 동일하게 모든 노드를 사용해서 sum_expected_accepted_length 재계산
        flat_weights = torch.cat(valid_weights)
        if self.fixed_nnodes and self.final_nnodes >= len(flat_weights):
            # tree_temp.py와 동일한 방식: 모든 노드를 사용
            depth_probs = [w.sum() for w in valid_weights]
            adjusted_depth_probs = []
            for i in range(len(depth_probs)):
                if i == len(depth_probs) - 1:
                    adjusted_depth_probs.append(depth_probs[i])
                else:
                    adjusted_depth_probs.append(max(0.0, depth_probs[i] - depth_probs[i + 1]))
            # 각 레이어에 (depth+1)을 곱해서 합산
            if adjusted_depth_probs:
                expected_sum = sum(adj_prob * float(d + 1) for d, adj_prob in enumerate(adjusted_depth_probs))
                if math.isnan(expected_sum) or expected_sum <= 0:
                    print(f"[WARNING] expected_sum is invalid (NaN or <= 0): {expected_sum}, setting self.sum_expected_accepted_length to 1.0 (depth={self.depth}, final_nnodes={self.final_nnodes})")
                    self.sum_expected_accepted_length = 1.0
                else:
                    self.sum_expected_accepted_length = float(expected_sum)
            else:
                print(f"[WARNING] adjusted_depth_probs is empty, setting self.sum_expected_accepted_length to 1.0 (depth={self.depth}, final_nnodes={self.final_nnodes})")
                self.sum_expected_accepted_length = 1.0
        # print(f"per token latency diff: {per_token_latency_diff}, per token cost diff: {per_token_cost_diff}, objective value: {objective_value}")
        
        # 다음 호출을 위해 현재 값을 이전 값으로 저장
        self.prev_target_time = current_target_time
        self.prev_per_token_latency = current_per_token_latency
        self.prev_per_token_cost = current_per_token_cost
        
        # Depth별 통계 수집 (현재 depth에 대한 값 저장)
        current_depth = self.depth
        if current_depth not in self.depth_stats:
            self.depth_stats[current_depth] = {
                "prev_sum_expected_accepted_length": [],
                "sum_expected_accepted_length": [],
                "per_token_latency_diff": [],
                "per_token_cost_diff": [],
                "objective_value": []
            }
        
        self.depth_stats[current_depth]["prev_sum_expected_accepted_length"].append(float(self.prev_sum_expected_accepted_length))
        self.depth_stats[current_depth]["sum_expected_accepted_length"].append(float(self.sum_expected_accepted_length))
        self.depth_stats[current_depth]["per_token_latency_diff"].append(float(per_token_latency_diff))
        self.depth_stats[current_depth]["per_token_cost_diff"].append(float(per_token_cost_diff))
        self.depth_stats[current_depth]["objective_value"].append(float(objective_value))

        # MobiTree: depth 확장 알고리즘
        if self.depth == 2 and self.depth < self.max_depth:  # depth=2인 경우 무조건 확장
            self.weight = weight
        elif self.fixed_depth and self.depth < self.max_depth:  # fixed_depth=True인 경우 max_depth만 고려
            self.weight = weight
        elif not self.fixed_depth and self.depth < self.max_depth and objective_value < 0:  # fixed_depth=False인 경우 latency/cost 목적함수가 좋아질 때만 확장
            self.weight = weight
        else:   # [DH] 트리 depth 확장이 종료되는 경우.
            # breakpoint()
            # top_index 유효성 검증
            total_nodes = sum(self.depth_widths[:self.depth])
            if len(top_index) > 0:
                max_valid_index = total_nodes - 1
                # top_index가 유효한 범위 내에 있는지 확인하고 클리핑
                top_index = torch.clamp(top_index, 0, max_valid_index)
            
            # top_index를 depth와 column으로 변환
            rows = torch.zeros_like(top_index)
            cols = top_index.clone()
            cumsum = 0
            for d in range(self.depth):
                if d < len(self.depth_widths):
                    mask = (top_index >= cumsum) & (top_index < cumsum + self.depth_widths[d])
                    rows[mask] = d  # [DH] 각 토큰의 depth 인덱스
                    cols[mask] = top_index[mask] - cumsum  # [DH] 각 토큰의 각 depth에서의 column 인덱스
                    cumsum += self.depth_widths[d]
                else:
                    break
            
            # 인덱스 범위 검증 및 클리핑
            # rows가 max_depth를 초과하지 않도록 보장
            rows = torch.clamp(rows, 0, min(self.max_depth - 1, len(self.depth_widths) - 1))
            # cols가 각 depth의 width를 초과하지 않도록 보장 (벡터화된 방식)
            max_cols = torch.tensor([self.depth_widths[d] if d < len(self.depth_widths) else self.max_nnodes 
                                     for d in range(self.max_depth)], device=self.device)
            # 각 row에 해당하는 max_col 가져오기
            row_max_cols = max_cols[rows]
            # row_max_cols가 0이 되면 max가 -1이 되어 인덱싱이 깨질 수 있으므로 최소 1 보장
            row_max_cols = torch.clamp(row_max_cols, min=1)
            max_per_row = row_max_cols - 1
            # torch.clamp는 (Tensor, Number, Tensor) 조합을 허용하지 않으므로 Tensor-기반 clamp로 처리
            cols = torch.maximum(cols, torch.zeros_like(cols))
            cols = torch.minimum(cols, max_per_row)
            # 최종적으로 max_nnodes도 초과하지 않도록 보장
            cols = torch.minimum(cols, torch.full_like(cols, self.max_nnodes - 1))
            
            # breakpoint()
            sorted_indices = torch.argsort(rows)
            rows = rows[sorted_indices]   # [DH] 부모 인덱스 기준 정렬
            cols = cols[sorted_indices]   # [DH] 부모 인덱스 기준 정렬
            
            # 최종 인덱스 범위 검증
            rows = torch.clamp(rows, 0, self.max_depth - 1)
            cols = torch.clamp(cols, 0, self.max_nnodes - 1)
            
            input_ids = self.input_ids_matrix[rows, cols]
            position_ids = rows + 1
            parents = self.parents_matrix[rows, cols]
            
            # source_idx와 parent_idx 계산
            source_idx = torch.zeros_like(rows)
            parent_idx = torch.zeros_like(rows)
            for i, (r, c) in enumerate(zip(rows, cols)):
                r_item = r.item()
                c_item = c.item()
                # source_idx: 현재 노드의 전역 인덱스
                cumsum = sum(self.depth_widths[:r_item])
                source_idx[i] = cumsum + c_item
                
                # parent_idx: 부모 노드의 전역 인덱스
                if r_item > 0:
                    parent_depth = r_item - 1
                    parent_col = parents[i].item()
                    parent_cumsum = sum(self.depth_widths[:parent_depth])
                    parent_idx[i] = parent_cumsum + parent_col
                else:
                    parent_idx[i] = parents[i]
            # breakpoint()
            # parents_index 계산: 각 노드의 부모가 선택된 노드들 중 몇 번째인지 찾기
            # parent_idx[i]는 i번째 노드의 부모 노드의 전역 인덱스
            # source_idx[j]는 j번째 노드의 전역 인덱스
            # parent_idx[i] == source_idx[j]인 경우, i번째 노드의 부모가 j번째 노드임
            parents_index = torch.zeros(len(top_index), dtype=torch.long, device=self.device)
            for i in range(len(top_index)):
                # parent_idx[i]와 일치하는 source_idx의 인덱스 찾기
                matches = (source_idx == parent_idx[i]).nonzero(as_tuple=False)
                if len(matches) > 0:
                    parents_index[i] = matches[0].item()
                else:
                    # 매칭되지 않는 경우: depth 0이면 부모가 없으므로 0, 아니면 이전 노드의 인덱스 사용
                    if len(rows) > 0 and rows[i].item() == 0:
                        parents_index[i] = 0
                    else:
                        # 이전 노드 중에서 같은 depth의 노드를 부모로 사용
                        # 또는 가장 가까운 이전 노드 사용
                        parents_index[i] = max(0, i - 1) if i > 0 else 0
            
            # parents_index의 값이 유효한 범위 내에 있는지 확인
            parents_index = torch.clamp(parents_index, 0, len(top_index) - 1)
            
            # 검증: parents_index의 크기가 top_index와 일치해야 함
            if len(parents_index) != len(top_index):
                raise ValueError(f"parents_index size mismatch: {len(parents_index)} != {len(top_index)}")
            
            attention_mask = self.generate_attention_mask(parents_index, len(top_index))
            
            outputs = {
                "input_ids": input_ids,  # [DH] 선택된 노드들 (부모 인덱스 순으로 정렬됨)
                "position_ids": position_ids,  # [DH] 몇 번째 depth인지
                "attention_mask": attention_mask,
                "parent_last": parents_index,  # [DH] 선택된 노드들의 부모 인덱스 (상대적인 인덱스)
                "is_final": True
            }
        
        # 다음 호출을 위해 현재 tree 정보를 이전 값으로 저장
        self.prev_final_nnodes = self.final_nnodes
        self.prev_depth = self.depth
        self.prev_width = self.current_width
        
        return outputs
    
    def get_width_timing_stats(self):
        """width별 model.model() 호출 시간 통계를 딕셔너리로 반환"""
        if not self.width_times:
            return {}
        
        stats = {}
        for width in sorted(self.width_times.keys()):
            times = self.width_times[width]
            count = len(times)
            total_time_ms = sum(times) * 1000
            avg_time_ms = (sum(times) / count) * 1000
            min_time_ms = min(times) * 1000
            max_time_ms = max(times) * 1000
            
            stats[width] = {
                'count': count,
                'total_time_ms': total_time_ms,
                'avg_time_ms': avg_time_ms,
                'min_time_ms': min_time_ms,
                'max_time_ms': max_time_ms
            }
        
        return stats
    
    def print_width_timing_stats(self):
        """width별 model.model() 호출 시간 평균 실행 시간 출력"""
        stats = self.get_width_timing_stats()
        if not stats:
            return
        
        print("\n" + "="*80)
        print("Width별 model.model() 호출 시간 통계")
        print("="*80)
        print(f"{'Width':<10} {'실행 횟수':<12} {'총 시간 (ms)':<15} {'평균 시간 (ms)':<15} {'최소 시간 (ms)':<15} {'최대 시간 (ms)':<15}")
        print("-"*80)
        
        for width in sorted(stats.keys()):
            s = stats[width]
            print(f"{width:<10} {s['count']:<12} {s['total_time_ms']:<15.3f} {s['avg_time_ms']:<15.3f} {s['min_time_ms']:<15.3f} {s['max_time_ms']:<15.3f}")
        
        print("="*80 + "\n")

    def depth_algorithm(self):  # 여기다가 depth 관련 알고리즘 삽입 (depth 확장 조건)
        return True
    
    def print_tree_structure(self, tokenizer=None):
        """
        트리 구조를 시각적으로 출력하는 함수
        Args:
            tokenizer: 토큰 ID를 텍스트로 변환하기 위한 tokenizer (선택사항)
        """
        print("\n" + "="*80)
        print(f"Tree Structure (Current Depth: {self.depth}, Max Depth: {self.max_depth})")
        print("="*80)
        
        if self.depth == 0:
            print("Tree is empty (depth=0)")
            return
        
        # 각 depth별로 노드 정보 수집
        for d in range(self.depth):
            width = self.depth_widths[d] if d < len(self.depth_widths) else 0
            print(f"\nDepth {d} (width={width}):")
            print("-" * 80)
            
            for i in range(width):
                token_id = self.input_ids_matrix[d, i].item()
                weight = self.weight_matrix[d, i].item()
                parent_idx = self.parents_matrix[d, i].item() if d > 0 else -1
                
                # 토큰 텍스트 변환
                if tokenizer:
                    try:
                        token_text = tokenizer.decode([token_id])
                        token_text = repr(token_text)  # 특수문자 표시
                    except:
                        token_text = "<?>"
                else:
                    token_text = ""
                
                # 노드 정보 출력
                if d == 0:
                    print(f"  [{d},{i:2d}] token_id={token_id:5d} {token_text:20s} weight={weight:.6f}")
                else:
                    print(f"  [{d},{i:2d}] token_id={token_id:5d} {token_text:20s} weight={weight:.6f} <- parent=[{d-1},{parent_idx:2d}]")
        
        print("="*80 + "\n")
    
    def print_tree_structure_hierarchical(self, tokenizer=None):
        """
        트리 구조를 계층적으로 출력하는 함수 (트리 형태로 표현)
        Args:
            tokenizer: 토큰 ID를 텍스트로 변환하기 위한 tokenizer (선택사항)
        """
        print("\n" + "="*100)
        print(f"Tree Structure - Hierarchical View (Current Depth: {self.depth})")
        print("="*100)
        
        if self.depth == 0:
            print("Tree is empty (depth=0)")
            return
        
        # 각 depth별로 부모-자식 관계 구축
        children_map = {}  # {(depth, idx): [(child_depth, child_idx), ...]}
        
        for d in range(self.depth):
            width = self.depth_widths[d] if d < len(self.depth_widths) else 0
            for i in range(width):
                if d > 0:
                    parent_idx = self.parents_matrix[d, i].item()
                    parent_key = (d-1, parent_idx)
                    if parent_key not in children_map:
                        children_map[parent_key] = []
                    children_map[parent_key].append((d, i))
        
        # 재귀적으로 트리 출력
        def print_node(depth, idx, prefix="", is_last=True):
            width = self.depth_widths[depth] if depth < len(self.depth_widths) else 0
            if idx >= width:
                return
            
            token_id = self.input_ids_matrix[depth, idx].item()
            weight = self.weight_matrix[depth, idx].item()
            
            # 토큰 텍스트 변환
            if tokenizer:
                try:
                    token_text = tokenizer.decode([token_id])
                    token_text = repr(token_text)[:15]  # 길이 제한
                except:
                    token_text = "<?>"
            else:
                token_text = f"id={token_id}"
            
            # 현재 노드 출력
            connector = "└─" if is_last else "├─"
            print(f"{prefix}{connector} [{depth},{idx:2d}] {token_text:15s} (w={weight:.4f})")
            
            # 자식 노드들 출력
            node_key = (depth, idx)
            if node_key in children_map:
                children = children_map[node_key]
                extension = "   " if is_last else "│  "
                for i, child in enumerate(children):
                    is_last_child = (i == len(children) - 1)
                    print_node(child[0], child[1], prefix + extension, is_last_child)
        
        # Depth 0의 모든 노드부터 시작
        width_0 = self.depth_widths[0] if len(self.depth_widths) > 0 else 0
        for i in range(width_0):
            is_last = (i == width_0 - 1)
            print_node(0, i, "", is_last)
        
        print("="*100 + "\n")