# Tawala

**Build and deploy Django apps with confidence.**

Tawala is the core framework and management utility designed to supercharge your Django development experience.

## Installation

Tawala is installed automatically when you scaffold a new project using `create-tawala-app`:

```bash
uvx create-tawala-app my-new-project
```

## Usage

Once installed, you can use the Tawala CLI to manage your projects:

```bash
tawala --help
# or use the short alias
twl --help
```
