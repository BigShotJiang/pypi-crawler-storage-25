"""Management Configurations."""

import builtins
import pathlib
from typing import Any, TypeAlias, cast

from tawala_validate import TAWALA

from .. import (
    DatabaseBackendOptions,
    DatabaseTomlKeys,
    InternationalizationTomlKeys,
    PresetOptions,
    PresetTomlKeys,
    RuncommandsTomlKeys,
    SecurityTomlKeys,
)

_ConfDefaultValueType: TypeAlias = str | bool | list[str] | pathlib.Path | int | None


class _ConfField:
    """Descriptor for a configuration field populated from env vars or TOML."""

    def __init__(
        self,
        type: type[str]
        | type[bool]
        | type[list[str]]
        | type[pathlib.Path]
        | type[int] = str,
        choices: list[str] | None = None,
        env: str | None = None,
        toml: str | None = None,
        default: _ConfDefaultValueType = None,
    ):
        """Set up field type, source mappings, and default value."""
        self.type = type
        self.choices = choices
        self.env = env
        self.toml = toml
        self.default = default
        self.field_name: str = ""

    # ============================================================================
    # Value Resolution
    # ============================================================================

    def _get_from_toml(self) -> Any:
        """Get value from TOML configuration."""
        if self.toml is None:
            return None
        current: Any = TAWALA.project_toml
        for k in self.toml.split("."):
            if isinstance(current, dict) and k in current:
                current = cast(dict[str, Any], current)[k]
            else:
                return None
        return current

    def _fetch_value(self) -> Any:
        """Fetch configuration value with fallback priority: ENV -> TOML -> default."""
        if self.env is not None and self.env in TAWALA.project_env:
            return TAWALA.project_env[self.env]
        toml_value = self._get_from_toml()
        if toml_value is not None:
            return toml_value
        return self.default

    # ============================================================================
    # Value Conversion
    # ============================================================================

    @staticmethod
    def convert_value(
        value: Any, target_type: Any, field_name: str | None = None
    ) -> _ConfDefaultValueType:
        """Convert a raw value to the target type."""
        from christianwhocodes import TypeConverter

        if value is None:
            match target_type:
                case builtins.str:
                    return ""
                case builtins.int:
                    return 0
                case builtins.list:
                    return []
                case _:
                    return None
        try:
            match target_type:
                case builtins.str:
                    return str(value)
                case builtins.int:
                    return int(value)
                case builtins.list:
                    return TypeConverter.to_list_of_str(value, str.strip)
                case builtins.bool:
                    return TypeConverter.to_bool(value)
                case pathlib.Path:
                    return TypeConverter.to_path(value)
                case _:
                    raise ValueError(
                        f"Unsupported target type or type not specified: {target_type}"
                    )
        except ValueError as e:
            field_info = f" for field '{field_name}'" if field_name else ""
            raise ValueError(f"Error converting config value{field_info}: {e}") from e

        raise ValueError(
            f"Unsupported target type or conversion failure for: {target_type}"
        )

    # ============================================================================
    # Descriptor Protocol
    # ============================================================================

    def __set_name__(self, owner: type, name: str) -> None:
        """Capture the attribute name when the descriptor is assigned to a class."""
        self.field_name = name

    def __get__(self, instance: Any, owner: type) -> Any:
        """Fetch, convert, and return the configuration value."""
        if instance is None:
            return self
        raw_value = self._fetch_value()
        return self.convert_value(raw_value, self.type, self.field_name)


class _Conf:
    """Base class for loading configuration from env vars and TOML."""

    verbose_name: str


# ============================================================================
# Presets & Storages
# ============================================================================


class _PresetsConf(_Conf):
    """Presets and Storages Configuration."""

    verbose_name = "Presets and Storages Configuration"
    backend = _ConfField(
        type=str,
        choices=[PresetOptions.DEFAULT, PresetOptions.VERCEL],
        env="PRESET_BACKEND",
        toml=f"{PresetTomlKeys.PRESET}.{PresetTomlKeys.BACKEND}",
        default=PresetOptions.DEFAULT,
    )
    token = _ConfField(
        type=str,
        env="BLOB_READ_WRITE_TOKEN",
        toml=f"{PresetTomlKeys.PRESET}.{PresetTomlKeys.BLOB_TOKEN}",
        default="",
    )


PRESETS_CONF = _PresetsConf()

# ============================================================================
# Security
# ============================================================================


class _SecurityConf(_Conf):
    """Security and Deployment Configuration."""

    verbose_name = "Security and Deployment Configuration"

    secret_key = _ConfField(
        type=str,
        env="SECRET_KEY",
        toml=SecurityTomlKeys.SECRET_KEY,
        default="django-insecure-change-me-in-production-via-env-variable",
    )
    debug = _ConfField(
        type=bool,
        env="DEBUG",
        toml=SecurityTomlKeys.DEBUG,
        default=True,
    )
    allowed_hosts = _ConfField(
        type=list,
        env="ALLOWED_HOSTS",
        toml=SecurityTomlKeys.ALLOWED_HOSTS,
        default=["localhost", "127.0.0.1"],
    )
    secure_ssl_redirect = _ConfField(
        type=bool,
        env="SECURE_SSL_REDIRECT",
        toml=SecurityTomlKeys.SECURE_SSL_REDIRECT,
        default=False,
    )
    session_cookie_secure = _ConfField(
        type=bool,
        env="SESSION_COOKIE_SECURE",
        toml=SecurityTomlKeys.SESSION_COOKIE_SECURE,
        default=False,
    )
    csrf_cookie_secure = _ConfField(
        type=bool,
        env="CSRF_COOKIE_SECURE",
        toml=SecurityTomlKeys.CSRF_COOKIE_SECURE,
        default=False,
    )
    secure_hsts_seconds = _ConfField(
        type=int,
        env="SECURE_HSTS_SECONDS",
        toml=SecurityTomlKeys.SECURE_HSTS_SECONDS,
        default=0,
    )
    work_in_progress = _ConfField(
        type=bool,
        env="WORK_IN_PROGRESS",
        toml=SecurityTomlKeys.WORK_IN_PROGRESS,
        default=False,
    )
    admin_enabled = _ConfField(
        type=bool,
        env="ADMIN_ENABLED",
        toml=SecurityTomlKeys.ADMIN_ENABLED,
        default=False,
    )


SECURITY_CONF = _SecurityConf()


# ============================================================================
# Databases
# ============================================================================


class _DatabasesConf(_Conf):
    """Database Configuration."""

    verbose_name = "Database Configuration"
    _is_vercel_preset = PRESETS_CONF.backend == PresetOptions.VERCEL

    backend = _ConfField(
        type=str,
        choices=[c for c in DatabaseBackendOptions],
        env="DB_BACKEND",
        toml=f"{DatabaseTomlKeys.DB}.{DatabaseTomlKeys.BACKEND}",
        default=(
            DatabaseBackendOptions.POSTGRESQL
            if _is_vercel_preset
            else DatabaseBackendOptions.SQLITE
        ),
    )
    # postgresql specific
    pg_use_vars = _ConfField(
        type=bool,
        env="DB_USE_VARS",
        toml=f"{DatabaseTomlKeys.DB}.{DatabaseTomlKeys.USE_VARS}",
        default=_is_vercel_preset,
    )
    pg_service = _ConfField(
        type=str,
        env="DB_PGSERVICE",
        toml=f"{DatabaseTomlKeys.DB}.{DatabaseTomlKeys.SERVICE}",
        default="",
    )
    pg_user = _ConfField(
        type=str,
        env="DB_PGUSER",
        toml=f"{DatabaseTomlKeys.DB}.{DatabaseTomlKeys.USER}",
        default="",
    )
    pg_password = _ConfField(
        type=str,
        env="DB_PGPASSWORD",
        toml=f"{DatabaseTomlKeys.DB}.{DatabaseTomlKeys.PASSWORD}",
        default="",
    )
    pg_database = _ConfField(
        type=str,
        env="DB_PGDATABASE",
        toml=f"{DatabaseTomlKeys.DB}.{DatabaseTomlKeys.NAME}",
        default="",
    )
    pg_host = _ConfField(
        type=str,
        env="DB_PGHOST",
        toml=f"{DatabaseTomlKeys.DB}.{DatabaseTomlKeys.HOST}",
        default="localhost",
    )
    pg_port = _ConfField(
        type=int,
        env="DB_PGPORT",
        toml=f"{DatabaseTomlKeys.DB}.{DatabaseTomlKeys.PORT}",
        default=5432,
    )
    pg_pool = _ConfField(
        type=bool,
        env="DB_PGPOOL",
        toml=f"{DatabaseTomlKeys.DB}.{DatabaseTomlKeys.POOL}",
        default=False,
    )
    pg_sslmode = _ConfField(
        type=str,
        choices=["prefer", "require", "disable", "allow", "verify-ca", "verify-full"],
        env="DB_PGSSLMODE",
        toml=f"{DatabaseTomlKeys.DB}.{DatabaseTomlKeys.SSLMODE}",
        default="prefer",
    )


DATABASES_CONF = _DatabasesConf()


# ============================================================================
# Internationalization
# ============================================================================


class _InternationalizationConf(_Conf):
    """Internationalization Configuration."""

    verbose_name = "Internationalization Configuration"

    language_code = _ConfField(
        type=str,
        env="LANGUAGE_CODE",
        toml=f"{InternationalizationTomlKeys.INTERNATIONALIZATION}.{InternationalizationTomlKeys.LANGUAGE_CODE}",
        default="en-us",
    )
    time_zone = _ConfField(
        type=str,
        env="TIMEZONE",
        toml=f"{InternationalizationTomlKeys.INTERNATIONALIZATION}.{InternationalizationTomlKeys.TIME_ZONE}",
        default="UTC",
    )
    use_i18n = _ConfField(
        type=bool,
        env="USE_I18N",
        toml=f"{InternationalizationTomlKeys.INTERNATIONALIZATION}.{InternationalizationTomlKeys.USE_I18N}",
        default=True,
    )
    use_tz = _ConfField(
        type=bool,
        env="USE_TZ",
        toml=f"{InternationalizationTomlKeys.INTERNATIONALIZATION}.{InternationalizationTomlKeys.USE_TZ}",
        default=True,
    )


INTERNATIONALIZATION_CONF = _InternationalizationConf()


# ============================================================================
# Runcommands
# ============================================================================


class _RunCommandsConf(_Conf):
    """Runcommands Configuration."""

    verbose_name = "Runcommands Configuration"

    install = _ConfField(
        type=list,
        env="RUNCOMMANDS_INSTALL",
        toml=f"{RuncommandsTomlKeys.RUNCOMMANDS}.{RuncommandsTomlKeys.INSTALL}",
        default=[],
    )
    build = _ConfField(
        type=list,
        env="RUNCOMMANDS_BUILD",
        toml=f"{RuncommandsTomlKeys.RUNCOMMANDS}.{RuncommandsTomlKeys.BUILD}",
        default=[
            "makemigrations",
            "migrate",
            "compilescss",
            "collectstatic --noinput --ignore=*.scss",
        ],
    )


RUNCOMMANDS_CONF = _RunCommandsConf()
