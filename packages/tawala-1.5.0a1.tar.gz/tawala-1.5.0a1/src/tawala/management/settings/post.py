"""Settings."""

from pathlib import Path
from typing import NotRequired, TypeAlias, TypedDict

from django.utils.csp import CSP  # pyright: ignore[reportMissingTypeStubs]
from tawala_validate import TAWALA

from .pre import (
    DATABASES_CONF,
    INTERNATIONALIZATION_CONF,
    PRESETS_CONF,
    RUNCOMMANDS_CONF,
    SECURITY_CONF,
)
from .. import DatabaseBackendOptions, ModuleLiterals, PresetOptions

# ============================================================================
# Base Directory
# ============================================================================

BASE_DIR = TAWALA.project_dir


# ============================================================================
# Security & Deployment
# https://docs.djangoproject.com/en/stable/howto/deployment/checklist/
# https://docs.djangoproject.com/en/stable/howto/csp/
# ============================================================================

SECRET_KEY = SECURITY_CONF.secret_key
DEBUG = SECURITY_CONF.debug
ALLOWED_HOSTS = SECURITY_CONF.allowed_hosts
SECURE_SSL_REDIRECT = SECURITY_CONF.secure_ssl_redirect
SESSION_COOKIE_SECURE = SECURITY_CONF.session_cookie_secure
CSRF_COOKIE_SECURE = SECURITY_CONF.csrf_cookie_secure
SECURE_HSTS_SECONDS = SECURITY_CONF.secure_hsts_seconds
WORK_IN_PROGRESS = SECURITY_CONF.work_in_progress
ADMIN_ENABLED = SECURITY_CONF.admin_enabled

SECURE_CSP: dict[str, list[str]] = {
    "default-src": [CSP.SELF],
    "script-src": [CSP.SELF, CSP.NONCE],
    "style-src": [
        CSP.SELF,
        CSP.NONCE,
        "https://fonts.googleapis.com",  # Google Fonts CSS
    ],
    "font-src": [
        CSP.SELF,
        "https://fonts.gstatic.com",  # Google Fonts font files
    ],
}


# ============================================================================
# Asgi, Wsgi & Root URLConf
# ============================================================================

ASGI_APPLICATION = f"{TAWALA.pkg_name}.{ModuleLiterals.API}.asgi.application"
WSGI_APPLICATION = f"{TAWALA.pkg_name}.{ModuleLiterals.API}.wsgi.application"
ROOT_URLCONF = f"{TAWALA.pkg_name}.{ModuleLiterals.APPS}.urls"

# ============================================================================
# Installed applications
# ============================================================================

MAIN_APP = "app"

INSTALLED_APPS = (
    [
        "django_browser_reload",
        "django_watchfiles",
        "django_minify_html",
        "django_http_compression",
        "sass_processor",
    ]
    + [MAIN_APP, f"{TAWALA.pkg_name}.{ModuleLiterals.APPS}", TAWALA.pkg_name]
    + [
        "django.contrib.admin",
        "django.contrib.auth",
        "django.contrib.contenttypes",
        "django.contrib.sessions",
        "django.contrib.messages",
        "django.contrib.staticfiles",
    ]
)


# ============================================================================
# Middleware
# ============================================================================

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "django.middleware.csp.ContentSecurityPolicyMiddleware",
    "django_http_compression.middleware.HttpCompressionMiddleware",  # Before any that modify html
    "django_minify_html.middleware.MinifyHtmlMiddleware",  # After http_compression, before HTML modifiers
    "django_browser_reload.middleware.BrowserReloadMiddleware",
]

# ============================================================================
# Templates
# ============================================================================


class _TemplateOptionsDict(TypedDict):
    """Template OPTIONS dict."""

    context_processors: list[str]
    builtins: NotRequired[list[str]]
    libraries: NotRequired[dict[str, str]]


class _TemplateDict(TypedDict):
    """Single TEMPLATES entry."""

    BACKEND: str
    DIRS: list[Path]
    APP_DIRS: bool
    OPTIONS: _TemplateOptionsDict


_TemplatesDict: TypeAlias = list[_TemplateDict]

TEMPLATES: _TemplatesDict = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "django.template.context_processors.csp",
            ]
        },
    }
]


# ============================================================================
# Staticfiles & Sass
# ============================================================================

STATICFILES_FINDERS = [
    "django.contrib.staticfiles.finders.FileSystemFinder",
    "django.contrib.staticfiles.finders.AppDirectoriesFinder",
    "sass_processor.finders.CssFinder",
]

SASS_PRECISION = 8


# ============================================================================
# Authentication
# ============================================================================

AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"
    },
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# ============================================================================
# Runcommands
# ============================================================================

RUNINSTALL = RUNCOMMANDS_CONF.install
RUNBUILD = RUNCOMMANDS_CONF.build


# ============================================================================
# Presets & Storages
# ============================================================================


class _StorageBackendDict(TypedDict):
    """Individual storage backend entry."""

    BACKEND: str


class _StoragesDict(TypedDict):
    """STORAGES setting dict."""

    staticfiles: _StorageBackendDict
    default: _StorageBackendDict


def get_storages_config(preset_backend_choice: str) -> _StoragesDict:
    """Build the STORAGES setting based on configured backend."""
    storage_backend: str

    match preset_backend_choice:
        case PresetOptions.DEFAULT:
            storage_backend = "django.core.files.storage.FileSystemStorage"
        case PresetOptions.VERCEL:
            storage_backend = f"{TAWALA.pkg_name}.{ModuleLiterals.MANAGEMENT}.backends.VercelBlobStorageBackend"
        case _:
            raise ValueError(f"Unsupported storage backend: {preset_backend_choice}")

    return {
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage"
        },
        "default": {"BACKEND": storage_backend},
    }


STORAGES = get_storages_config(PRESETS_CONF.backend)


# ============================================================================
# Databases
# https://docs.djangoproject.com/en/stable/ref/databases/#postgresql-notes
# https://www.postgresql.org/docs/current/libpq-pgservice.html
# https://www.postgresql.org/docs/current/libpq-pgpass.html
# ============================================================================


class _DatabaseOptionsDict(TypedDict, total=False):
    """Database OPTIONS dict."""

    service: str
    pool: bool
    sslmode: str


class _DatabaseDict(TypedDict):
    """Single database configuration entry."""

    ENGINE: str
    NAME: str | Path
    USER: NotRequired[str | None]
    PASSWORD: NotRequired[str | None]
    HOST: NotRequired[str | None]
    PORT: NotRequired[str | None]
    OPTIONS: NotRequired[_DatabaseOptionsDict]


class _DatabasesDict(TypedDict):
    """DATABASES setting dict."""

    default: _DatabaseDict


def _get_databases_config() -> _DatabasesDict:
    """Build the DATABASES setting based on configured backend."""
    backend: str = DATABASES_CONF.backend.lower()
    match backend:
        case DatabaseBackendOptions.SQLITE:
            return {
                "default": {
                    "ENGINE": "django.db.backends.sqlite3",
                    "NAME": BASE_DIR / "db.sqlite3",
                }
            }
        case DatabaseBackendOptions.POSTGRESQL:
            config: _DatabaseDict
            if DATABASES_CONF.pg_use_vars:
                config = {
                    "ENGINE": "django.db.backends.postgresql",
                    "NAME": DATABASES_CONF.pg_database,
                    "USER": DATABASES_CONF.pg_user,
                    "PASSWORD": DATABASES_CONF.pg_password,
                    "HOST": DATABASES_CONF.pg_host,
                    "PORT": str(DATABASES_CONF.pg_port),
                    "OPTIONS": {
                        "pool": DATABASES_CONF.pg_pool,
                        "sslmode": DATABASES_CONF.pg_sslmode,
                    },
                }
            else:
                config = {
                    "ENGINE": "django.db.backends.postgresql",
                    "NAME": DATABASES_CONF.pg_database,
                    "OPTIONS": {
                        "pool": DATABASES_CONF.pg_pool,
                        "sslmode": DATABASES_CONF.pg_sslmode,
                        "service": DATABASES_CONF.pg_service,
                    },
                }
            return {"default": config}
        case _:
            pass

    raise ValueError(f"Unsupported DB backend: {backend}")


DATABASES = _get_databases_config()


# ============================================================================
# Static & Media
# ============================================================================

_PUBLIC_DIR = BASE_DIR / "public"
STATIC_ROOT = _PUBLIC_DIR / "static"
MEDIA_ROOT = _PUBLIC_DIR / "media"
STATIC_URL = "static/"
MEDIA_URL = "media/"


# ============================================================================
# Internationalization
# https://docs.djangoproject.com/en/stable/topics/i18n/
# ============================================================================

LANGUAGE_CODE = INTERNATIONALIZATION_CONF.language_code
TIME_ZONE = INTERNATIONALIZATION_CONF.time_zone
USE_I18N = INTERNATIONALIZATION_CONF.use_i18n
USE_TZ = INTERNATIONALIZATION_CONF.use_tz
