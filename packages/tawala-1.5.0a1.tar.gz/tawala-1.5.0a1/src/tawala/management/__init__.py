"""Management constants."""

from enum import StrEnum

# ============================================================================
# Package
# ============================================================================


class ModuleLiterals(StrEnum):
    """Namings for various components."""

    API = "api"
    APPS = "apps"
    MANAGEMENT = "management"
    SETTINGS = "settings"


# ============================================================================
# Presets & Storages
# ============================================================================


class PresetOptions(StrEnum):
    """Available database backends."""

    DEFAULT = "default"
    VERCEL = "vercel"


class PresetTomlKeys(StrEnum):
    """Keys for preset configuration in pyproject.toml."""

    PRESET = "preset"
    BACKEND = "backend"
    BLOB_TOKEN = "blob-token"


class PresetFlags(StrEnum):
    """Flags used when setting up preset during initialization."""

    PRESET = f"--{PresetTomlKeys.PRESET}"

    @property
    def dest(self):  # noqa: D102
        return self.value.lstrip("-").replace("-", "_")


# ============================================================================
# Databases
# ============================================================================


class DatabaseTomlKeys(StrEnum):
    """Keys for database configuration in pyproject.toml."""

    DB = "db"
    BACKEND = "backend"
    USE_VARS = "pg-use-vars"
    SERVICE = "pg-service"
    USER = "pg-user"
    PASSWORD = "pg-password"
    NAME = "pg-database"
    HOST = "pg-host"
    PORT = "pg-port"
    POOL = "pg-pool"
    SSLMODE = "pg-sslmode"


class DatabaseBackendOptions(StrEnum):
    """Available database backends."""

    SQLITE = "sqlite"
    POSTGRESQL = "postgresql"


class DatabaseFlags(StrEnum):
    """Flags used when setting up database during initialization."""

    DB = f"--{DatabaseTomlKeys.DB}"
    PG_USE_VARS = f"--{DatabaseTomlKeys.USE_VARS}"

    @property
    def dest(self):  # noqa: D102
        return self.value.lstrip("-").replace("-", "_")


# ============================================================================
# Internationalization
# ============================================================================


class InternationalizationTomlKeys(StrEnum):
    """Keys for internationalization configuration in pyproject.toml."""

    INTERNATIONALIZATION = "internationalization"
    LANGUAGE_CODE = "language-code"
    TIME_ZONE = "time-zone"
    USE_I18N = "use-i18n"
    USE_TZ = "use-tz"


# ============================================================================
# Runcommands
# ============================================================================
class RuncommandsTomlKeys(StrEnum):
    """Keys for runcommands configuration in pyproject.toml."""

    RUNCOMMANDS = "runcommands"
    INSTALL = "install"
    BUILD = "build"


# ============================================================================
# Security
# ============================================================================
class SecurityTomlKeys(StrEnum):
    """Keys for security configuration in pyproject.toml."""

    SECRET_KEY = "secret-key"
    DEBUG = "debug"
    ALLOWED_HOSTS = "allowed-hosts"
    SECURE_SSL_REDIRECT = "secure-ssl-redirect"
    SESSION_COOKIE_SECURE = "session-cookie-secure"
    CSRF_COOKIE_SECURE = "csrf-cookie-secure"
    SECURE_HSTS_SECONDS = "secure-hsts-seconds"
    WORK_IN_PROGRESS = "work-in-progress"
    ADMIN_ENABLED = "admin-enabled"
