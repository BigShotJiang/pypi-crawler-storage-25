"""ASGI configuration.

https://docs.djangoproject.com/en/stable/howto/deployment/asgi
"""

from sys import exit

from christianwhocodes import ExitCode, InitAction, Text, cprint
from tawala_validate import TAWALA, TawalaValidationError

try:
    TAWALA.validate_project()
except TawalaValidationError as e:
    cprint(
        f"Is this a valid {TAWALA.pkg_display_name} project directory?\n{e}",
        Text.WARNING,
    )
    cprint(
        f"Assuming you have uv installed:\n"
        f"    - run: 'uvx {TAWALA.pkg_name} {InitAction.STARTPROJECT} <project_name>' to initialize a new project.\n"
        f"    - run: 'uvx {TAWALA.pkg_name} {InitAction.STARTPROJECT} -h' to see help on the command.",
        Text.INFO,
    )
    exit(ExitCode.ERROR)
except Exception as e:
    cprint(f"Unexpected error during project validation:\n{e}", Text.ERROR)
    exit(ExitCode.ERROR)
else:
    from os import environ

    from django.core.asgi import get_asgi_application

    from . import DJANGO_SETTINGS_MODULE

    environ.setdefault("DJANGO_SETTINGS_MODULE", DJANGO_SETTINGS_MODULE)

    application = get_asgi_application()
