"""CLI entry point."""

import sys

from christianwhocodes import ExitCode, Text, cprint
from tawala_validate import TAWALA


def main() -> None:
    """Execute the CLI."""
    if len(sys.argv) < 2:
        cprint("No arguments passed.", Text.ERROR)
        sys.exit(ExitCode.ERROR)
    match sys.argv[1]:
        case "-v" | "--ver" | "--version" | "version":
            from christianwhocodes import print_version

            sys.exit(print_version(TAWALA.pkg_name))
        case _:
            from tawala_validate import TawalaValidationError

            try:
                TAWALA.validate_project()
            except TawalaValidationError as e:
                cprint(
                    f"Is this a valid {TAWALA.pkg_display_name} project directory?\n{e}",
                    Text.WARNING,
                )
                cprint(
                    f"Assuming you have uv installed:\n"
                    f"    - run: 'uvx create-tawala-app <project_name>' to initialize a new project.\n"
                    f"    - run: 'uvx create-tawala-app -h' to see help on the command.",
                    Text.INFO,
                )
                sys.exit(ExitCode.ERROR)
            except Exception as e:
                cprint(f"Unexpected error during project validation:\n{e}", Text.ERROR)
                sys.exit(ExitCode.ERROR)
            else:
                from os import environ

                from django.core.management import ManagementUtility

                from . import DJANGO_SETTINGS_MODULE

                sys.path.insert(0, str(TAWALA.project_dir))
                environ.setdefault("DJANGO_SETTINGS_MODULE", DJANGO_SETTINGS_MODULE)
                utility = ManagementUtility(sys.argv)
                utility.prog_name = TAWALA.pkg_name
                utility.execute()


if __name__ == "__main__":
    main()
