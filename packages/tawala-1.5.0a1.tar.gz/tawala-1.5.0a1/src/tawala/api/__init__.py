"""API module."""

from tawala_validate import TAWALA

from ..management import ModuleLiterals

DJANGO_SETTINGS_MODULE = (
    f"{TAWALA.pkg_name}.{ModuleLiterals.MANAGEMENT}.{ModuleLiterals.SETTINGS}.post"
)
