"""template tags."""

from django.template import Library
from tawala_validate import TAWALA

register = Library()


@register.simple_tag
def pkg_display_name() -> str:
    """Return the configured display name for the package."""
    return TAWALA.pkg_display_name
