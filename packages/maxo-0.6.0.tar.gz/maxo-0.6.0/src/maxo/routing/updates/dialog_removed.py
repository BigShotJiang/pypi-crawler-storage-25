from maxo.enums.update_type import UpdateType
from maxo.errors import AttributeIsEmptyError
from maxo.omit import Omittable, Omitted, is_defined
from maxo.routing.updates.base import MaxUpdate
from maxo.routing.updates.mixins import ChatMethodsFacade
from maxo.types.user import User


class DialogRemoved(MaxUpdate, ChatMethodsFacade):
    """
    Вы получите это событие, как только пользователь удалит чат

    Args:
        chat_id: ID чата, где произошло событие
        type:
        user: Пользователь, который удалил чат
        user_locale: Текущий язык пользователя в формате IETF BCP 47
    """

    type = UpdateType.DIALOG_REMOVED

    chat_id: int
    """ID чата, где произошло событие"""
    user: User
    """Пользователь, который удалил чат"""

    user_locale: Omittable[str] = Omitted()
    """Текущий язык пользователя в формате IETF BCP 47"""

    @property
    def unsafe_user_locale(self) -> str:
        if is_defined(self.user_locale):
            return self.user_locale

        raise AttributeIsEmptyError(
            obj=self,
            attr="user_locale",
        )
