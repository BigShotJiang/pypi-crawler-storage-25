"""
Registry-based dataset downloader module.

This module provides clean dataset download functionality using lazy imports.
No model logic is executed, and no file loading happens at import time.
"""

from typing import Optional, Any
import sys
from .registry import get_registry, initialize_registry


class DownloadError(Exception):
    """Base exception for download operations."""
    pass


class DatasetNotFoundError(DownloadError):
    """Exception raised when dataset is not found in registry."""
    pass


class DownloadFailedError(DownloadError):
    """Exception raised when download operation fails."""
    pass


def get_item(name: str) -> Any:
    """
    Download a dataset or code file by name.

    Uses lazy imports to avoid executing model logic.
    Supports dl, nlp, and hpc datasets.

    Args:
        name: Name of the dataset to download (e.g., 'boston', 'nlp2', '1bfs')

    Returns:
        Result from the download function (usually file path)

    Raises:
        DatasetNotFoundError: If dataset is not found
        DownloadFailedError: If download fails
        Exception: For other import or execution errors
    """
    registry = get_registry()

    # Check if dataset exists
    if not registry.exists(name):
        available = list(registry.list_all().keys())
        raise DatasetNotFoundError(
            f"Dataset '{name}' not found. Available: {', '.join(sorted(available))}"
        )

    try:
        # Lazily get the download function
        download_func = registry.get(name)

        if download_func is None:
            raise DatasetNotFoundError(f"Dataset '{name}' not found in registry")

        # Call the download function
        result = download_func(name) if name.startswith(("1", "2", "3", "4", "5")) else download_func()
        return result

    except (ImportError, AttributeError) as e:
        raise DownloadFailedError(f"Failed to load dataset '{name}': {e}")
    except Exception as e:
        raise DownloadFailedError(f"Error downloading dataset '{name}': {e}")


def get_category_datasets(category: str) -> dict:
    """
    Get all datasets in a specific category.

    Args:
        category: Category name ('dl', 'nlp', 'hpc')

    Returns:
        Dictionary of datasets in the category
    """
    registry = get_registry()
    datasets = registry.list_by_category(category)
    return {
        name: info["description"]
        for name, info in datasets.items()
    }


def list_all_datasets() -> dict:
    """
    Get all registered datasets organized by category.

    Returns:
        Dictionary with categories as keys and datasets as values
    """
    registry = get_registry()
    all_datasets = registry.list_all()

    categories = {}
    for name, info in all_datasets.items():
        cat = info["category"]
        if cat not in categories:
            categories[cat] = {}
        categories[cat][name] = info["description"]

    return categories
