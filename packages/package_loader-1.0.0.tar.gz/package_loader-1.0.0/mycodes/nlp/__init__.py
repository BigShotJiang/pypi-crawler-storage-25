"""Natural Language Processing practicals

This module provides lazy-loaded access to NLP datasets.
Do NOT import models to avoid executing model logic at import time.
"""

__all__ = []
