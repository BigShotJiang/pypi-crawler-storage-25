"""
NLP3 Dataset downloader.

This module provides lazy-loaded dataset downloads without executing model logic.
No imports of heavy libraries happen at module level.
Supports multiple file types: CSV, pickle, etc.
"""

import os
import requests


DATASETS = {
    "cleaned_news_dataset": {
        "url": "https://github.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/raw/refs/heads/master/LP-VI/NLP/NLP3/cleaned_news_dataset.csv",
        "filename": "cleaned_news_dataset.csv"
    },
    "tfidf_features": {
        "url": "https://github.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/raw/refs/heads/master/LP-VI/NLP/NLP3/tfidf_features.csv",
        "filename": "tfidf_features.csv"
    },
    "news_dataset": {
        "url": "https://github.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/raw/refs/heads/master/LP-VI/NLP/NLP3/News_dataset.pickle",
        "filename": "News_dataset.pickle"
    }
}


def download_data(name=None, save_dir="data"):
    """
    Download NLP3 datasets.

    Args:
        name: Specific dataset name (if None, downloads cleaned_news_dataset)
        save_dir: Directory to save files (default: 'data')

    Returns:
        str: Path to the downloaded file

    Raises:
        ValueError: If dataset not found
        RuntimeError: If download fails
    """
    if name is None:
        # Default to cleaned_news_dataset
        name = "cleaned_news_dataset"

    if name not in DATASETS:
        raise ValueError(f"Dataset '{name}' not found. Available: {', '.join(DATASETS.keys())}")

    dataset = DATASETS[name]
    url = dataset["url"]
    filename = dataset["filename"]
    path = os.path.join(os.getcwd(), save_dir, filename)

    if os.path.exists(path):
        print(f"{name} already exists")
        return path

    os.makedirs(os.path.dirname(path), exist_ok=True)

    try:
        print(f"Downloading {name}...")
        r = requests.get(url)
        r.raise_for_status()
        with open(path, "wb") as f:
            f.write(r.content)
        print(f"Saved at: {path}")
        return path
    except requests.RequestException as e:
        raise RuntimeError(f"Failed to download dataset: {e}")