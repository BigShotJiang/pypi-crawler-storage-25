import pandas as pd
import numpy as np

from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from gensim.models import Word2Vec

import nltk
nltk.download('punkt')
from nltk.tokenize import word_tokenize
def run_model():
    import pandas as pd
    df = pd.read_csv("Car_Dataset.csv")
    print(df.head())   # make sure name matches

# =====================================
# 3. DATA PREPROCESSING (IMPORTANT)
# Convert structured data → text
# =====================================
df = df.fillna("")   # handle missing values

df['text'] = df.astype(str).agg(' '.join, axis=1)

print("\nSample Text Data:")
print(df['text'].head())

# =====================================
# 4. BAG OF WORDS (COUNT OCCURRENCE)
# =====================================
cv = CountVectorizer()

X_bow = cv.fit_transform(df['text'])

print("\nBoW Shape:", X_bow.shape)
print("Sample Features:", cv.get_feature_names_out()[:10])
# =====================================
# 5. NORMALIZED BAG OF WORDS
# =====================================
X_bow_array = X_bow.toarray()

# Normalize (avoid divide by zero)
row_sums = X_bow_array.sum(axis=1, keepdims=True)
row_sums[row_sums == 0] = 1

X_bow_norm = X_bow_array / row_sums

print("\nNormalized BoW (first row):")
print(X_bow_norm[0])
# =====================================
# 6. TF-IDF
# =====================================
tfidf = TfidfVectorizer()

X_tfidf = tfidf.fit_transform(df['text'])

print("\nTF-IDF Shape:", X_tfidf.shape)
print("Sample Features:", tfidf.get_feature_names_out()[:10])
# =====================================
# 7. WORD2VEC
# =====================================

# Tokenization
tokenized_data = [word_tokenize(text.lower()) for text in df['text']]

# Train model
w2v_model = Word2Vec(
    sentences=tokenized_data,
    vector_size=100,
    window=5,
    min_count=1,
    workers=4
)
# Example: word vector
print("\nWord2Vec Vector for 'bmw':")
print(w2v_model.wv['bmw'])
# Similar words
print("\nWords similar to 'bmw':")
print(w2v_model.wv.most_similar('bmw'))
# =====================================
# 8. DONE
# =====================================
print("\nAll tasks completed successfully ✅")
embeddings