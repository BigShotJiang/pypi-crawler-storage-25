"""
HPC Code Files downloader.

This module provides lazy-loaded downloads for HPC code files (C++, CUDA, Python).
No imports of heavy libraries happen at module level.
No file loading happens at import time.
"""

import os
import requests


# Registry of HPC code files - no execution happens at import time
CPP_FILES = {
    "1bfs": {
        "url": "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/HPC/1_BFS_DFS.cpp",
        "filename": "bfs_dfs.cpp"
    },
    "2bubblemerge": {
        "url": "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/HPC/2_parallel_bubble_merge.cpp",
        "filename": "parallel_bubble_merge.cpp"
    },
    "3parallelreduction": {
        "url": "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/HPC/3_parallel_reduction.cu",
        "filename": "reduction.cu"
    },
    "4matrixmultiplication": {
        "url": "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/HPC/4_matrix_multiplication.cu",
        "filename": "matrix_multiplication.cu"
    },
    "4vectoraddition": {
        "url": "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/HPC/4_vector_addition.cu",
        "filename": "vector_addition.cu"
    },
    "5mandelbrot": {
        "url": "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/HPC/5_mandelbrot_numba.py",
        "filename": "mandelbrot_numba.py"
    }
}


def download_cpp(name, save_dir="data"):
    """
    Download HPC code files.

    Args:
        name: Identifier of the HPC file (e.g., '1bfs', '2bubblemerge')
        save_dir: Directory to save the file (default: 'data')

    Returns:
        str: Path to the downloaded file

    Raises:
        ValueError: If file name is not found
        RuntimeError: If download fails
    """
    if name not in CPP_FILES:
        raise ValueError(f"File '{name}' not found. Available files: {', '.join(CPP_FILES.keys())}")

    file = CPP_FILES[name]
    path = os.path.join(os.getcwd(), save_dir, file["filename"])

    if os.path.exists(path):
        print("Already exists")
        return path

    os.makedirs(os.path.dirname(path), exist_ok=True)

    try:
        print(f"Downloading {file['filename']}...")
        r = requests.get(file["url"])
        r.raise_for_status()
        with open(path, "wb") as f:
            f.write(r.content)
        print(f"Saved at: {path}")
        return path
    except requests.RequestException as e:
        raise RuntimeError(f"Failed to download file: {e}")