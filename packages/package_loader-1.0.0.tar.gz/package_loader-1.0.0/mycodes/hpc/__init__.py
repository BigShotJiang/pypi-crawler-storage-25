"""High Performance Computing practicals

This module provides lazy-loaded access to HPC code files.
Do NOT import anything at module level to avoid side effects.
"""

__all__ = []