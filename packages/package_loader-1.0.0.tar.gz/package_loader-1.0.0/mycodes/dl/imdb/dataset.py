"""
IMDB Movie Reviews Dataset downloader.

This module provides lazy-loaded dataset downloads without executing model logic.
No imports of heavy libraries happen at module level.
"""

import os
import requests


URL = "https://github.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/raw/refs/heads/master/LP-V/DL/2.IMDB/IMDB_Dataset.csv"
PATH = os.path.join(os.getcwd(), "data", "imdb.csv")


def download_data():
    """
    Download IMDB Movie Reviews dataset.

    Returns:
        str: Path to the downloaded dataset file

    Raises:
        RuntimeError: If download fails
    """
    if os.path.exists(PATH):
        print("Already exists")
        return PATH

    os.makedirs(os.path.dirname(PATH), exist_ok=True)

    try:
        r = requests.get(URL)
        r.raise_for_status()
        with open(PATH, "wb") as f:
            f.write(r.content)
        print(f"Downloaded to {PATH}")
        return PATH
    except requests.RequestException as e:
        raise RuntimeError(f"Failed to download dataset: {e}")