"""Deep Learning practicals

This module provides lazy-loaded access to deep learning datasets.
Do NOT import models to avoid executing model logic at import time.
"""

__all__ = []
