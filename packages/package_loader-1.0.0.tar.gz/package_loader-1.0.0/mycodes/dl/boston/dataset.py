"""
Boston Housing Price Prediction Dataset downloader.

This module provides lazy-loaded dataset downloads without executing model logic.
No imports of heavy libraries happen at module level.
"""

import os
import requests


URL = "https://raw.githubusercontent.com/Vishwajeet-Londhe/SPPU-CSE-SEM8-Codes/refs/heads/master/LP-V/DL/1.Boston%20housing%20price/1_boston_housing.csv"
PATH = os.path.join(os.getcwd(), "data", "boston.csv")


def download_data():
    """
    Download Boston Housing Price dataset.

    Returns:
        str: Path to the downloaded dataset file

    Raises:
        RuntimeError: If download fails
    """
    if os.path.exists(PATH):
        print("Already exists")
        return PATH

    os.makedirs(os.path.dirname(PATH), exist_ok=True)

    try:
        r = requests.get(URL)
        r.raise_for_status()
        with open(PATH, "wb") as f:
            f.write(r.content)
        print(f"Downloaded to {PATH}")
        return PATH
    except requests.RequestException as e:
        raise RuntimeError(f"Failed to download dataset: {e}")