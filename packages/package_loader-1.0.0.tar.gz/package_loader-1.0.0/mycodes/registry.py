"""
Registry-based plugin architecture for dataset downloading.
Uses lazy imports to avoid executing model logic at import time.
"""

from typing import Callable, Dict, Any, Optional
import importlib


class DownloadRegistry:
    """
    Central registry for managing dataset downloads.
    Supports lazy imports and modular plugin architecture.
    """

    def __init__(self):
        self._registry: Dict[str, Dict[str, Any]] = {}

    def register(
        self,
        name: str,
        module_path: str,
        func_name: str = "download_data",
        category: str = "general",
        description: str = ""
    ) -> None:
        """
        Register a dataset download function.

        Args:
            name: Unique identifier for the dataset
            module_path: Full module path (e.g., 'mycodes.dl.boston.dataset')
            func_name: Name of the download function in the module
            category: Category (dl, nlp, hpc)
            description: Human-readable description
        """
        self._registry[name] = {
            "module_path": module_path,
            "func_name": func_name,
            "category": category,
            "description": description,
        }

    def get(self, name: str) -> Optional[Callable]:
        """
        Lazily load and return the download function for a given name.

        Args:
            name: Identifier of the dataset to download

        Returns:
            The download function or None if not found

        Raises:
            ImportError: If the module cannot be imported
            AttributeError: If the function doesn't exist in the module
        """
        if name not in self._registry:
            return None

        entry = self._registry[name]

        try:
            # Lazy import
            module = importlib.import_module(entry["module_path"])
            func = getattr(module, entry["func_name"])
            return func
        except ImportError as e:
            raise ImportError(
                f"Failed to import module '{entry['module_path']}': {e}"
            )
        except AttributeError as e:
            raise AttributeError(
                f"Function '{entry['func_name']}' not found in '{entry['module_path']}': {e}"
            )

    def list_all(self) -> Dict[str, Dict[str, Any]]:
        """Get all registered datasets."""
        return self._registry.copy()

    def list_by_category(self, category: str) -> Dict[str, Dict[str, Any]]:
        """Get all datasets in a specific category."""
        return {
            name: info
            for name, info in self._registry.items()
            if info["category"] == category
        }

    def exists(self, name: str) -> bool:
        """Check if a dataset is registered."""
        return name in self._registry


# Global registry instance
_global_registry = DownloadRegistry()


def get_registry() -> DownloadRegistry:
    """Get the global registry instance."""
    return _global_registry


def initialize_registry() -> None:
    """Initialize the registry with all available datasets."""
    registry = get_registry()

    # ========== DL Datasets ==========
    registry.register(
        name="boston",
        module_path="mycodes.dl.boston.dataset",
        func_name="download_data",
        category="dl",
        description="Boston Housing Price Prediction Dataset",
    )
    registry.register(
        name="imdb",
        module_path="mycodes.dl.imdb.dataset",
        func_name="download_data",
        category="dl",
        description="IMDB Movie Reviews Dataset",
    )
    registry.register(
        name="stock",
        module_path="mycodes.dl.stock.dataset",
        func_name="download_data",
        category="dl",
        description="Stock Market Data",
    )
    registry.register(
        name="plant_disease",
        module_path="mycodes.dl.plant_disease.dataset",
        func_name="download_data",
        category="dl",
        description="Plant Disease Classification Dataset",
    )

    # ========== NLP Datasets ==========
    registry.register(
        name="nlp1",
        module_path="mycodes.nlp.nlp1.dataset",
        func_name="download_data",
        category="nlp",
        description="NLP1 Dataset",
    )
    registry.register(
        name="nlp2",
        module_path="mycodes.nlp.nlp2.dataset",
        func_name="download_data",
        category="nlp",
        description="NLP2 Car Dataset",
    )
    registry.register(
        name="nlp3",
        module_path="mycodes.nlp.nlp3.dataset",
        func_name="download_data",
        category="nlp",
        description="NLP3 Dataset",
    )
    registry.register(
        name="nlp4",
        module_path="mycodes.nlp.nlp4.dataset",
        func_name="download_data",
        category="nlp",
        description="NLP4 Dataset",
    )

    # ========== HPC Datasets ==========
    registry.register(
        name="1bfs",
        module_path="mycodes.hpc.dataset",
        func_name="download_cpp",
        category="hpc",
        description="BFS/DFS Algorithm (C++)",
    )
    registry.register(
        name="2bubblemerge",
        module_path="mycodes.hpc.dataset",
        func_name="download_cpp",
        category="hpc",
        description="Parallel Bubble Sort & Merge (C++)",
    )
    registry.register(
        name="3parallelreduction",
        module_path="mycodes.hpc.dataset",
        func_name="download_cpp",
        category="hpc",
        description="Parallel Reduction (CUDA)",
    )
    registry.register(
        name="4matrixmultiplication",
        module_path="mycodes.hpc.dataset",
        func_name="download_cpp",
        category="hpc",
        description="Matrix Multiplication (CUDA)",
    )
    registry.register(
        name="4vectoraddition",
        module_path="mycodes.hpc.dataset",
        func_name="download_cpp",
        category="hpc",
        description="Vector Addition (CUDA)",
    )
    registry.register(
        name="5mandelbrot",
        module_path="mycodes.hpc.dataset",
        func_name="download_cpp",
        category="hpc",
        description="Mandelbrot Set (Python with Numba)",
    )
