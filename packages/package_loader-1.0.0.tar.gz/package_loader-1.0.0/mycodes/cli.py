# cli.py
"""
Command-line interface for dataset downloads.

Usage:
    mycodes get <dataset_name>        Download a specific dataset
    mycodes list                      List all available datasets
    mycodes list <category>           List datasets in a category (dl, nlp, hpc)
    mycodes help                      Show help message
"""

import sys
from .downloader import (
    get_item,
    list_all_datasets,
    get_category_datasets,
    DownloadError,
    DatasetNotFoundError,
    DownloadFailedError,
)
from .registry import initialize_registry


def show_help():
    """Display help information."""
    help_text = """
MyCode CLI - Download DL, NLP, and HPC datasets

USAGE:
    mycodes get <name>          Download a dataset
    mycodes list                List all datasets
    mycodes list <category>     List datasets in a category
    mycodes help                Show this help message

EXAMPLES:
    mycodes get boston          Download Boston housing dataset
    mycodes get nlp2            Download NLP2 car dataset
    mycodes get 1bfs            Download BFS/DFS HPC code
    
    mycodes list                Show all available datasets
    mycodes list dl             Show all deep learning datasets
    mycodes list nlp            Show all NLP datasets
    mycodes list hpc            Show all HPC datasets

CATEGORIES:
    dl                          Deep Learning datasets
    nlp                         Natural Language Processing datasets
    hpc                         High Performance Computing code files
    """
    print(help_text)


def show_list(category: str = None):
    """Display available datasets."""
    datasets = list_all_datasets()

    if category:
        if category not in datasets:
            print(f"Error: Unknown category '{category}'")
            print(f"Available categories: {', '.join(sorted(datasets.keys()))}")
            return False

        items = datasets[category]
        print(f"\n{category.upper()} Datasets:")
        print("-" * 60)
        for name, desc in sorted(items.items()):
            print(f"  {name:<20} - {desc}")
        return True

    # Show all categories
    for cat in sorted(datasets.keys()):
        items = datasets[cat]
        print(f"\n{cat.upper()} Datasets:")
        print("-" * 60)
        for name, desc in sorted(items.items()):
            print(f"  {name:<20} - {desc}")

    return True


def main():
    """Main CLI entry point."""
    # Initialize registry on first run
    initialize_registry()

    if len(sys.argv) < 2:
        print("Usage: mycodes <command> [args]")
        print("Try 'mycodes help' for more information")
        sys.exit(1)

    command = sys.argv[1].lower()

    try:
        if command == "get":
            if len(sys.argv) < 3:
                print("Error: 'get' command requires a dataset name")
                print("Usage: mycodes get <dataset_name>")
                print("Try 'mycodes list' to see available datasets")
                sys.exit(1)

            dataset_name = sys.argv[2]
            print(f"Downloading '{dataset_name}'...")

            try:
                result = get_item(dataset_name)
                print(f"✓ Success: Downloaded to {result}")
                sys.exit(0)
            except DatasetNotFoundError as e:
                print(f"✗ Error: {e}")
                sys.exit(1)
            except DownloadFailedError as e:
                print(f"✗ Download failed: {e}")
                sys.exit(1)

        elif command == "list":
            category = sys.argv[2].lower() if len(sys.argv) > 2 else None
            success = show_list(category)
            sys.exit(0 if success else 1)

        elif command == "help":
            show_help()
            sys.exit(0)

        else:
            print(f"Error: Unknown command '{command}'")
            print("Available commands: get, list, help")
            print("Try 'mycodes help' for more information")
            sys.exit(1)

    except DownloadError as e:
        print(f"Download Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
