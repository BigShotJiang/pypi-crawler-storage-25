"""Collector daemon entry point — cross-platform."""

from __future__ import annotations

import json
import logging
import os
import signal
import sys
import time

from .config import CollectorConfig, SYSTEM, _default_data_dir
from .queue import SyncQueue
from .sync_client import SyncClient
from .tools.antigravity import AntigravityTool
from .tools.claude_code import ClaudeCodeTool
from .tools.codex import CodexTool
from .tools.cursor import CursorTool
from .tools.obsidian import ObsidianTool
from .tools.openclaw import OpenClawTool
from .watcher import FileWatcher


def _load_saved_config() -> CollectorConfig:
    """Load config, merging saved setup wizard values if present."""
    config = CollectorConfig()
    saved_path = _default_data_dir() / "config.json"
    if saved_path.exists():
        try:
            saved = json.loads(saved_path.read_text())
            if saved.get("server_url"):
                os.environ.setdefault("DR_SERVER_URL", saved["server_url"])
            if saved.get("server_token"):
                os.environ.setdefault("DR_SERVER_TOKEN", saved["server_token"])
            if saved.get("obsidian_vault_path"):
                os.environ.setdefault("DR_OBSIDIAN_VAULT_PATH", saved["obsidian_vault_path"])
            # Reload with env vars set
            config = CollectorConfig()
        except Exception:
            pass
    return config


def _setup_logging(config: CollectorConfig) -> None:
    config.log_dir.mkdir(parents=True, exist_ok=True)
    log_file = config.log_dir / "collector.log"

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout),
        ],
    )


def main() -> None:
    config = _load_saved_config()
    config.ensure_dirs()
    _setup_logging(config)

    logger = logging.getLogger("collector")
    logger.info(
        "Starting Daily Report Collector [%s] on %s (%s)",
        config.device_id[:8], config.device_name, config.platform,
    )

    # Initialize tools
    tools = [
        ClaudeCodeTool(),
        OpenClawTool(),
        CodexTool(),
        AntigravityTool(),
        ObsidianTool(vault_path=config.obsidian_vault_path),
        CursorTool(),
    ]

    available = [t for t in tools if t.is_available()]
    logger.info(
        "Available tools (%d): %s",
        len(available),
        ", ".join(f"{t.display_name}" for t in available),
    )

    if not available:
        logger.warning("No AI tools found on this device!")

    # Initialize queue
    queue = SyncQueue(config.queue_db_path)

    # Initialize sync client
    sync_client = SyncClient(queue, config)

    # Initialize watcher
    watcher = FileWatcher(available, queue, config)

    # Graceful shutdown (SIGINT/SIGTERM on Unix, Ctrl+C on Windows)
    shutdown = False

    def _signal_handler(signum: int, frame: object) -> None:
        nonlocal shutdown
        logger.info("Received signal %s, shutting down...", signum)
        shutdown = True

    signal.signal(signal.SIGINT, _signal_handler)
    if SYSTEM != "Windows":
        signal.signal(signal.SIGTERM, _signal_handler)

    # Initial scan
    logger.info("Running initial scan...")
    count = watcher.initial_scan()
    logger.info("Initial scan complete: %d files queued", count)
    logger.info("Queue has %d pending items", queue.pending_count())

    # Start services
    watcher.start()
    sync_client.start()

    logger.info("Collector running. Press Ctrl+C to stop.")

    # Periodic tasks
    antigravity_tool = next((t for t in available if t.name == "antigravity"), None)
    last_ag_export = time.time()  # Skip first run (already done in initial_scan)
    AG_EXPORT_INTERVAL = 300  # 5 minutes

    # Main loop
    try:
        while not shutdown:
            time.sleep(1)

            # Periodic Antigravity conversation export
            if antigravity_tool and time.time() - last_ag_export > AG_EXPORT_INTERVAL:
                last_ag_export = time.time()
                try:
                    from .parsers.antigravity_export import export_conversations
                    from .sanitizer import sanitize_text
                    convos = export_conversations()
                    for conv in convos:
                        san = sanitize_text(conv["content"])
                        queue.enqueue(
                            tool_name="antigravity",
                            category="conversation",
                            content_type="markdown",
                            relative_path=f"conversations/{conv['title']}.md",
                            content=san.content,
                            content_hash=f"aghistory-{hash(conv['content']) & 0xFFFFFFFF:08x}",
                            file_size=len(san.content.encode("utf-8")),
                            sync_strategy="full",
                            metadata={"source": "aghistory", "doc_type": "full_conversation"},
                        )
                    if convos:
                        logger.info("Periodic: exported %d Antigravity conversations", len(convos))
                except Exception:
                    pass  # aghistory not installed or Antigravity not running

    except KeyboardInterrupt:
        pass
    finally:
        logger.info("Shutting down...")
        watcher.stop()
        sync_client.stop()
        queue.close()
        logger.info("Collector stopped.")


if __name__ == "__main__":
    main()
