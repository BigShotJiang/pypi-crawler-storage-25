import datetime
import warnings
from abc import ABC, abstractmethod
from enum import Enum
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Optional,
    Sequence,
    Union,
    final,
    get_args,
    get_origin,
)

import numpy as np
import numpy.typing as npt
import pandas as pd

import snowflake.snowpark.types as spt
from snowflake.ml._internal.exceptions import (
    error_codes,
    exceptions as snowml_exceptions,
)

if TYPE_CHECKING:
    import mlflow
    import torch

PandasExtensionTypes = Union[
    pd.Int8Dtype,
    pd.Int16Dtype,
    pd.Int32Dtype,
    pd.Int64Dtype,
    pd.UInt8Dtype,
    pd.UInt16Dtype,
    pd.UInt32Dtype,
    pd.UInt64Dtype,
    pd.Float32Dtype,
    pd.Float64Dtype,
    pd.BooleanDtype,
    pd.StringDtype,
]

_INDENT = "    "


class DataType(Enum):
    def __init__(self, value: str, snowpark_type: type[spt.DataType], numpy_type: npt.DTypeLike) -> None:
        self._value = value
        self._snowpark_type = snowpark_type
        self._numpy_type = numpy_type

    INT8 = ("int8", spt.ByteType, np.int8)
    INT16 = ("int16", spt.ShortType, np.int16)
    INT32 = ("int32", spt.IntegerType, np.int32)
    INT64 = ("int64", spt.LongType, np.int64)

    FLOAT = ("float", spt.FloatType, np.float32)
    DOUBLE = ("double", spt.DoubleType, np.float64)

    UINT8 = ("uint8", spt.ByteType, np.uint8)
    UINT16 = ("uint16", spt.ShortType, np.uint16)
    UINT32 = ("uint32", spt.IntegerType, np.uint32)
    UINT64 = ("uint64", spt.LongType, np.uint64)

    BOOL = ("bool", spt.BooleanType, np.bool_)
    STRING = ("string", spt.StringType, np.str_)
    BYTES = ("bytes", spt.BinaryType, np.bytes_)

    TIMESTAMP_NTZ = ("datetime64[ns]", spt.TimestampType, "datetime64[ns]")

    OBJECT = ("object", spt.MapType, np.object_)

    def as_snowpark_type(self) -> spt.DataType:
        """Convert to corresponding Snowpark Type.

        Returns:
            A Snowpark type.
        """
        if self == DataType.OBJECT:
            return spt.MapType(spt.StringType(), spt.VariantType())
        return self._snowpark_type()

    def __repr__(self) -> str:
        return f"DataType.{self.name}"

    @classmethod
    def from_numpy_type(cls, input_type: Union[npt.DTypeLike, PandasExtensionTypes]) -> "DataType":
        """Translate numpy dtype to DataType for signature definition.

        Args:
            input_type: The numpy dtype or Pandas Extension Dtype

        Raises:
            SnowflakeMLException: NotImplementedError: Raised when the given numpy type is not supported.

        Returns:
            Corresponding DataType.
        """
        # To support pandas extension dtype
        if isinstance(input_type, get_args(PandasExtensionTypes)):
            input_type = input_type.type

        np_to_snowml_type_mapping = {i._numpy_type: i for i in DataType}

        # Add datetime types:
        datetime_res = ["Y", "M", "W", "D", "h", "m", "s", "ms", "us", "ns"]

        for res in datetime_res:
            np_to_snowml_type_mapping[f"datetime64[{res}]"] = DataType.TIMESTAMP_NTZ

        for potential_type in np_to_snowml_type_mapping.keys():
            if np.can_cast(input_type, potential_type, casting="no"):
                # This is used since the same dtype might represented in different ways.
                return np_to_snowml_type_mapping[potential_type]
        raise snowml_exceptions.SnowflakeMLException(
            error_code=error_codes.NOT_IMPLEMENTED,
            original_exception=NotImplementedError(f"Type {input_type} is not supported as a DataType."),
        )

    @classmethod
    def from_torch_type(cls, torch_type: "torch.dtype") -> "DataType":
        import torch

        """Translate torch dtype to DataType for signature definition.

        Args:
            torch_type: The torch dtype.

        Returns:
            Corresponding DataType.
        """
        torch_dtype_to_numpy_dtype_mapping = {
            torch.uint8: np.uint8,
            torch.int8: np.int8,
            torch.int16: np.int16,
            torch.int32: np.int32,
            torch.int64: np.int64,
            torch.float32: np.float32,
            torch.float64: np.float64,
            torch.bool: np.bool_,
        }
        return cls.from_numpy_type(torch_dtype_to_numpy_dtype_mapping[torch_type])

    @classmethod
    def from_snowpark_type(cls, snowpark_type: spt.DataType) -> "DataType":
        """Translate snowpark type to DataType for signature definition.

        Args:
            snowpark_type: The snowpark type.

        Raises:
            SnowflakeMLException: NotImplementedError: Raised when the given numpy type is not supported.

        Returns:
            Corresponding DataType.
        """
        if isinstance(snowpark_type, spt.ArrayType):
            actual_sp_type = snowpark_type.element_type
        else:
            actual_sp_type = snowpark_type

        snowpark_to_snowml_type_mapping: dict[type[spt.DataType], DataType] = {
            i._snowpark_type: i
            for i in DataType
            # We by default infer as signed integer.
            if i not in [DataType.UINT8, DataType.UINT16, DataType.UINT32, DataType.UINT64, DataType.OBJECT]
        }
        for potential_type in snowpark_to_snowml_type_mapping.keys():
            if isinstance(actual_sp_type, potential_type):
                return snowpark_to_snowml_type_mapping[potential_type]
        # Fallback for decimal type.
        if isinstance(snowpark_type, spt.DecimalType):
            if snowpark_type.scale == 0:
                warnings.warn(
                    f"Warning: Type {snowpark_type}"
                    " is being automatically converted to INT64 in the Snowpark DataFrame. "
                    "This automatic conversion may lead to potential precision loss and rounding errors. "
                    "If you wish to prevent this conversion, you should manually perform "
                    "the necessary data type conversion.",
                    stacklevel=2,
                )
                return DataType.INT64
            else:
                warnings.warn(
                    f"Warning: Type {snowpark_type}"
                    " is being automatically converted to DOUBLE in the Snowpark DataFrame. "
                    "This automatic conversion may lead to potential precision loss and rounding errors. "
                    "If you wish to prevent this conversion, you should manually perform "
                    "the necessary data type conversion.",
                    stacklevel=2,
                )
                return DataType.DOUBLE
        raise snowml_exceptions.SnowflakeMLException(
            error_code=error_codes.NOT_IMPLEMENTED,
            original_exception=NotImplementedError(f"Type {snowpark_type} is not supported as a DataType."),
        )

    @classmethod
    def from_python_type(cls, python_type: type) -> "DataType":
        """Translate Python built-in type to DataType for signature definition.

        Args:
            python_type: A Python built-in type (int, float, str, bool, bytes, datetime.datetime),
                or a list type (e.g., list[str], list[list[int]]).

        Raises:
            SnowflakeMLException: ValueError: Raised when bare list type is provided without element type.
            SnowflakeMLException: NotImplementedError: Raised when the given Python type is not supported.

        Returns:
            Corresponding DataType. For list types, returns the DataType of the innermost element.
        """
        python_to_snowml_type_mapping: dict[type, "DataType"] = {
            int: DataType.INT64,
            float: DataType.DOUBLE,
            str: DataType.STRING,
            bool: DataType.BOOL,
            bytes: DataType.BYTES,
            datetime.datetime: DataType.TIMESTAMP_NTZ,
        }
        if python_type in python_to_snowml_type_mapping:
            return python_to_snowml_type_mapping[python_type]

        # Handle bare list without type args
        if python_type is list:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_DATA,
                original_exception=ValueError(
                    "Bare 'list' type is not supported. Please specify the element type, e.g., list[str]."
                ),
            )

        # Handle generic list types (e.g., list[str], list[list[int]])
        origin = get_origin(python_type)
        if origin is list:
            args = get_args(python_type)
            if args:
                # Recursively get the innermost element type
                return cls.from_python_type(args[0])

        raise snowml_exceptions.SnowflakeMLException(
            error_code=error_codes.NOT_IMPLEMENTED,
            original_exception=NotImplementedError(
                f"Python type {python_type} is not supported as a DataType. "
                f"Supported types are: {list(python_to_snowml_type_mapping.keys())}."
            ),
        )

    @classmethod
    def shape_from_python_type(cls, python_type: type) -> Optional[tuple[int, ...]]:
        """Get the shape for a Python type annotation.

        Args:
            python_type: A Python type annotation.

        Returns:
            None for scalar types, (-1,) for 1D list, (-1, -1) for 2D list, etc.
            -1 indicates variable length dimensions.
        """
        # Scalar types have no shape
        if python_type in {int, float, str, bool, bytes, datetime.datetime}:
            return None

        # Handle generic list types
        origin = get_origin(python_type)
        if origin is list:
            args = get_args(python_type)
            if args:
                inner_shape = cls.shape_from_python_type(args[0])
                if inner_shape is None:
                    # Inner type is scalar, so this is a 1D list
                    return (-1,)
                else:
                    # Inner type is also a list, prepend a dimension
                    return (-1,) + inner_shape
            # list without type args - treat as 1D
            return (-1,)

        # Bare list without origin
        if python_type is list:
            return (-1,)

        return None


class BaseFeatureSpec(ABC):
    """Abstract Class for specification of a feature."""

    def __init__(self, name: str, shape: Optional[tuple[int, ...]]) -> None:
        self._name = name

        if shape and not isinstance(shape, tuple):
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_TYPE,
                original_exception=TypeError("Shape should be a tuple if presented."),
            )
        self._shape = shape

    @final
    @property
    def name(self) -> str:
        """Name of the feature."""
        return self._name

    @abstractmethod
    def as_snowpark_type(self) -> spt.DataType:
        """Convert to corresponding Snowpark Type."""

    @abstractmethod
    def as_dtype(self, force_numpy_dtype: bool = False) -> Union[npt.DTypeLike, str, PandasExtensionTypes]:
        """Convert to corresponding local Type."""

    @abstractmethod
    def to_dict(self) -> dict[str, Any]:
        """Serialization"""

    @classmethod
    @abstractmethod
    def from_dict(self, input_dict: dict[str, Any]) -> "BaseFeatureSpec":
        """Deserialization"""


class FeatureSpec(BaseFeatureSpec):
    """Specification of a feature in Snowflake native model packaging."""

    def __init__(
        self,
        name: str,
        dtype: DataType,
        shape: Optional[tuple[int, ...]] = None,
        nullable: bool = True,
    ) -> None:
        """
        Initialize a feature.

        Args:
            name: Name of the feature.
            dtype: Type of the elements in the feature.
            nullable: Whether the feature is nullable. Defaults to True.
            shape: Used to represent scalar feature, 1-d feature list,
                or n-d tensor. Use -1 to represent variable length. Defaults to None.

                Examples:
                    - None: scalar
                    - (2,): 1d list with a fixed length of 2.
                    - (-1,): 1d list with variable length, used for ragged tensor representation.
                    - (d1, d2, d3): 3d tensor.
            nullable: Whether the feature is nullable. Defaults to True.

        Raises:
            SnowflakeMLException: TypeError: When the dtype input type is incorrect.
            SnowflakeMLException: TypeError: When the shape input type is incorrect.
        """
        super().__init__(name=name, shape=shape)

        if not isinstance(dtype, DataType):
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_TYPE,
                original_exception=TypeError("dtype should be a model signature datatype."),
            )
        self._dtype = dtype

        self._nullable = nullable

    def as_snowpark_type(self) -> spt.DataType:
        result_type = self._dtype.as_snowpark_type()
        if not self._shape:
            return result_type
        for _ in range(len(self._shape)):
            # e.g. (2,) -> ArrayType(base), (2,3) -> ArrayType(ArrayType(base))
            result_type = spt.ArrayType(result_type)
        return result_type

    def as_dtype(self, force_numpy_dtype: bool = False) -> Union[npt.DTypeLike, str, PandasExtensionTypes]:
        """Convert to corresponding local Type."""

        if not self._shape:
            # scalar dtype: use keys from `np.sctypeDict` to prevent unit-less dtype 'datetime64'
            if "datetime64" in self._dtype._value:
                return self._dtype._value

            np_type = self._dtype._numpy_type
            if self._nullable and not force_numpy_dtype:
                np_to_pd_dtype_mapping = {
                    np.int8: pd.Int8Dtype(),
                    np.int16: pd.Int16Dtype(),
                    np.int32: pd.Int32Dtype(),
                    np.int64: pd.Int64Dtype(),
                    np.uint8: pd.UInt8Dtype(),
                    np.uint16: pd.UInt16Dtype(),
                    np.uint32: pd.UInt32Dtype(),
                    np.uint64: pd.UInt64Dtype(),
                    np.float32: pd.Float32Dtype(),
                    np.float64: pd.Float64Dtype(),
                    np.bool_: pd.BooleanDtype(),
                    np.str_: pd.StringDtype(),
                }

                return np_to_pd_dtype_mapping.get(np_type, np_type)  # type: ignore[arg-type]

            return np_type
        return np.object_

    def __eq__(self, other: object) -> bool:
        if isinstance(other, FeatureSpec):
            return self._name == other._name and self._dtype == other._dtype and self._shape == other._shape
        else:
            return False

    def __repr__(self) -> str:
        return self._format_repr(num_indents=0)

    def _format_repr(self, num_indents: int = 0) -> str:
        shape_str = f", shape={self._shape!r}" if self._shape else ""
        return f"FeatureSpec(dtype={self._dtype!r}, name={self._name!r}{shape_str}, nullable={self._nullable!r})"

    def to_dict(self) -> dict[str, Any]:
        """Serialize the feature group into a dict.

        Returns:
            A dict that serializes the feature group.
        """
        base_dict: dict[str, Any] = {"type": self._dtype.name, "name": self._name, "nullable": self._nullable}
        if self._shape is not None:
            base_dict["shape"] = self._shape
        return base_dict

    @classmethod
    def from_dict(cls, input_dict: dict[str, Any]) -> "FeatureSpec":
        """Deserialize the feature specification from a dict.

        Args:
            input_dict: The dict containing information of the feature specification.

        Returns:
            A feature specification instance deserialized and created from the dict.
        """
        name = input_dict["name"]
        shape = input_dict.get("shape", None)
        if shape:
            shape = tuple(shape)
        type = DataType[input_dict["type"]]
        # If nullable is not provided, default to False for backward compatibility.
        nullable = input_dict.get("nullable", False)
        return FeatureSpec(name=name, dtype=type, shape=shape, nullable=nullable)

    @classmethod
    def from_mlflow_spec(
        cls, input_spec: Union["mlflow.types.ColSpec", "mlflow.types.TensorSpec"], feature_name: str
    ) -> BaseFeatureSpec:
        import mlflow

        if isinstance(input_spec, mlflow.types.ColSpec):
            name = input_spec.name
            if name is None:
                name = feature_name
            return _convert_mlflow_col_type(name, input_spec.type)
        elif isinstance(input_spec, mlflow.types.TensorSpec):
            if len(input_spec.shape) == 1:
                shape = None
            else:
                shape = tuple(input_spec.shape[1:])

            name = input_spec.name
            if name is None:
                name = feature_name
            return FeatureSpec(name=name, dtype=DataType.from_numpy_type(input_spec.type), shape=shape)
        else:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_IMPLEMENTED,
                original_exception=NotImplementedError(f"MLFlow schema type {type(input_spec)} is not supported."),
            )


class FeatureGroupSpec(BaseFeatureSpec):
    """Specification of a group of features in Snowflake native model packaging."""

    def __init__(self, name: str, specs: list[BaseFeatureSpec], shape: Optional[tuple[int, ...]] = None) -> None:
        """Initialize a feature group.

        Args:
            name: Name of the feature group.
            specs: A list of feature specifications that composes the group. All children feature specs have to have
                name. And all of them should have the same type.
            shape: Used to represent scalar feature, 1-d feature list,
                or n-d tensor. Use -1 to represent variable length. Defaults to None.

                Examples:
                    - None: scalar
                    - (2,): 1d list with a fixed length of 2.
                    - (-1,): 1d list with variable length, used for ragged tensor representation.
                    - (d1, d2, d3): 3d tensor.
        """
        super().__init__(name=name, shape=shape)
        self._specs = specs
        self._validate()

    def _validate(self) -> None:
        if len(self._specs) == 0:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT, original_exception=ValueError("No children feature specs.")
            )
        # each has to have name, and same type
        if not all(s._name is not None for s in self._specs):
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError("All children feature specs have to have name."),
            )

    def as_snowpark_type(self) -> spt.DataType:
        spt_type = spt.StructType(
            fields=[
                spt.StructField(
                    s._name, datatype=s.as_snowpark_type(), nullable=s._nullable if isinstance(s, FeatureSpec) else True
                )
                for s in self._specs
            ]
        )
        if not self._shape:
            return spt_type
        return spt.ArrayType(spt_type)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, FeatureGroupSpec):
            return self._name == other._name and self._specs == other._specs and self._shape == other._shape
        else:
            return False

    def __repr__(self) -> str:
        return self._format_repr(num_indents=0)

    def _format_repr(self, num_indents: int = 0) -> str:
        base_indent = _INDENT * num_indents
        child_indent = _INDENT * (num_indents + 1)
        spec_indent = _INDENT * (num_indents + 2)
        spec_strs = ",\n".join(
            spec_indent + (spec._format_repr(num_indents + 2) if hasattr(spec, "_format_repr") else repr(spec))
            for spec in self._specs
        )
        shape_str = f", shape={self._shape!r}" if self._shape else ""
        return (
            f"FeatureGroupSpec(\n"
            f"{child_indent}name={self._name!r},\n"
            f"{child_indent}specs=[\n{spec_strs}\n{child_indent}]{shape_str}\n"
            f"{base_indent})"
        )

    def as_dtype(self, force_numpy_dtype: bool = False) -> Union[npt.DTypeLike, str, PandasExtensionTypes]:
        return np.object_

    def to_dict(self) -> dict[str, Any]:
        """Serialize the feature group into a dict.

        Returns:
            A dict that serializes the feature group.
        """
        base_dict: dict[str, Any] = {"name": self._name, "specs": [s.to_dict() for s in self._specs]}
        if self._shape is not None:
            base_dict["shape"] = self._shape
        return base_dict

    @classmethod
    def from_dict(cls, input_dict: dict[str, Any]) -> "FeatureGroupSpec":
        """Deserialize the feature group from a dict.

        Args:
            input_dict: The dict containing information of the feature group.

        Returns:
            A feature group instance deserialized and created from the dict.
        """
        specs: list[BaseFeatureSpec] = []
        for e in input_dict["specs"]:
            spec = FeatureGroupSpec.from_dict(e) if "specs" in e else FeatureSpec.from_dict(e)
            specs.append(spec)
        shape = input_dict.get("shape", None)
        if shape:
            shape = tuple(shape)
        return FeatureGroupSpec(name=input_dict["name"], specs=specs, shape=shape)


def _convert_mlflow_col_type(
    name: str,
    mlflow_type: Any,
) -> BaseFeatureSpec:
    """Convert an MLflow column type to a Snowflake BaseFeatureSpec.

    Handles MLflow DataType (scalars), Array (nested lists/arrays), and Object (dicts).

    Args:
        name: The feature name.
        mlflow_type: The MLflow type from a ColSpec (DataType, Array, or Object).

    Returns:
        A FeatureSpec for scalar/array types, or FeatureGroupSpec for object types.

    Raises:
        SnowflakeMLException: If the MLflow column type is not supported.
    """
    import mlflow

    if isinstance(mlflow_type, mlflow.types.schema.DataType):
        return FeatureSpec(name=name, dtype=DataType.from_numpy_type(mlflow_type.to_numpy()))

    if isinstance(mlflow_type, mlflow.types.schema.Array):
        depth = 0
        inner = mlflow_type
        while isinstance(inner, mlflow.types.schema.Array):
            depth += 1
            inner = inner.dtype

        if isinstance(inner, mlflow.types.schema.Object):
            group = _convert_mlflow_object(name, inner)
            group._shape = (-1,) * depth
            return group

        return FeatureSpec(
            name=name,
            dtype=DataType.from_numpy_type(inner.to_numpy()),
            shape=(-1,) * depth,
        )

    if isinstance(mlflow_type, mlflow.types.schema.Object):
        return _convert_mlflow_object(name, mlflow_type)

    raise snowml_exceptions.SnowflakeMLException(
        error_code=error_codes.NOT_IMPLEMENTED,
        original_exception=NotImplementedError(f"MLflow column type {type(mlflow_type)} is not supported."),
    )


def _convert_mlflow_object(name: str, mlflow_obj: Any) -> FeatureGroupSpec:
    """Convert an MLflow Object type to a FeatureGroupSpec.

    Args:
        name: The feature name.
        mlflow_obj: An mlflow.types.schema.Object instance.

    Returns:
        A FeatureGroupSpec with child specs for each property.
    """
    specs: list[BaseFeatureSpec] = []
    for prop in mlflow_obj.properties:
        specs.append(_convert_mlflow_col_type(prop.name, prop.dtype))
    return FeatureGroupSpec(name=name, specs=specs)


class BaseParamSpec(ABC):
    """Abstract Class for specification of a parameter."""

    def __init__(self, name: str, shape: Optional[tuple[int, ...]] = None) -> None:
        self._name = name

        if shape is not None and not isinstance(shape, tuple):
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_TYPE,
                original_exception=TypeError("Shape should be a tuple if presented."),
            )
        self._shape = shape

    @final
    @property
    def name(self) -> str:
        """Name of the parameter."""
        return self._name

    @final
    @property
    def shape(self) -> Optional[tuple[int, ...]]:
        """Shape of the parameter. None means scalar."""
        return self._shape

    @property
    @abstractmethod
    def default_value(self) -> Any:
        """Default value of the parameter."""

    @abstractmethod
    def as_snowpark_type(self) -> spt.DataType:
        """Convert to corresponding Snowpark Type."""

    @abstractmethod
    def to_dict(self) -> dict[str, Any]:
        """Serialization"""

    @classmethod
    @abstractmethod
    def from_dict(cls, input_dict: dict[str, Any]) -> "BaseParamSpec":
        """Deserialization"""


_PARAM_INT_DTYPES = frozenset(
    {
        DataType.INT8,
        DataType.INT16,
        DataType.INT32,
        DataType.INT64,
        DataType.UINT8,
        DataType.UINT16,
        DataType.UINT32,
        DataType.UINT64,
    }
)

_PARAM_FLOAT_DTYPES = frozenset({DataType.FLOAT, DataType.DOUBLE})


def _get_leaf_values(value: Any) -> list[Any]:
    """Extract leaf values from potentially nested lists/tuples."""
    if isinstance(value, (list, tuple)):
        result: list[Any] = []
        for item in value:
            result.extend(_get_leaf_values(item))
        return result
    return [value]


def _validate_param_python_types(dtype: DataType, value: Any, is_array: bool) -> None:
    """Validate that Python types of value elements are compatible with dtype.

    Prevents silent type coercions (e.g. str->int, float->int) that numpy allows.

    Args:
        dtype: The expected DataType.
        value: The value to validate.
        is_array: Whether the value is an array (True) or scalar (False).

    Raises:
        SnowflakeMLException: ValueError when types are incompatible.
    """
    if is_array:
        elements = _get_leaf_values(value)
    else:
        # For scalar params, skip type check if value is a collection —
        # shape validation will catch the scalar-vs-array mismatch instead.
        if isinstance(value, (list, tuple)):
            return
        elements = [value]

    for elem in elements:
        if dtype in _PARAM_INT_DTYPES:
            if isinstance(elem, bool) or not isinstance(elem, (int, np.integer)):
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INVALID_ARGUMENT,
                    original_exception=ValueError(
                        f"Value {repr(elem)} (type: {type(elem).__name__}) is not compatible with "
                        f"dtype {dtype}. Expected int."
                    ),
                )
        elif dtype in _PARAM_FLOAT_DTYPES:
            if isinstance(elem, bool) or not isinstance(elem, (int, float, np.integer, np.floating)):
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.INVALID_ARGUMENT,
                    original_exception=ValueError(
                        f"Value {repr(elem)} (type: {type(elem).__name__}) is not compatible with "
                        f"dtype {dtype}. Expected int or float."
                    ),
                )


def coerce_param_value(param_spec: "ParamSpec", value: Any) -> Any:
    """Coerce a parameter value to match the param spec's dtype.

    Converts int values to float when dtype is FLOAT/DOUBLE to ensure
    resolved values have correct Python types.

    Args:
        param_spec: The parameter specification.
        value: The value to coerce.

    Returns:
        The coerced value.
    """
    if value is None:
        return None
    if param_spec.dtype in _PARAM_FLOAT_DTYPES:
        return _coerce_int_to_float(value)
    return value


def _coerce_int_to_float(value: Any) -> Any:
    """Recursively convert int values to float in nested structures."""
    if isinstance(value, list):
        return [_coerce_int_to_float(v) for v in value]
    if isinstance(value, tuple):
        return tuple(_coerce_int_to_float(v) for v in value)
    if isinstance(value, (int, np.integer)) and not isinstance(value, bool):
        return float(value)
    return value


class ParamSpec(BaseParamSpec):
    """Specification of a parameter in Snowflake native model packaging."""

    def __init__(
        self,
        name: str,
        dtype: DataType,
        default_value: Any,
        shape: Optional[tuple[int, ...]] = None,
    ) -> None:
        """Initialize a parameter.

        Args:
            name: Name of the parameter.
            dtype: Type of the parameter.
            default_value: Default value of the parameter.
            shape: Shape of the parameter. None means scalar, otherwise a tuple
                representing dimensions. Use -1 for variable length dimensions.
        """
        super().__init__(name=name, shape=shape)

        self._validate_default_value(dtype, default_value, shape)
        self._dtype = dtype
        self._default_value = default_value

    @staticmethod
    def _validate_default_value(dtype: DataType, default_value: Any, shape: Optional[tuple[int, ...]]) -> None:
        """Validate that default_value is compatible with dtype and shape.

        Args:
            dtype: The expected data type.
            default_value: The default value to validate. None is allowed and means no default.
            shape: The expected shape. None means scalar.

        Raises:
            SnowflakeMLException: ValueError: When the default_value is not compatible with dtype/shape.
        """
        if default_value is None:
            return

        _validate_param_python_types(dtype, default_value, is_array=shape is not None)

        try:
            arr = np.array(default_value, dtype=dtype._numpy_type)

            # Validate shape compatibility
            if shape is None:
                # Scalar expected
                if arr.ndim != 0:
                    raise snowml_exceptions.SnowflakeMLException(
                        error_code=error_codes.INVALID_ARGUMENT,
                        original_exception=ValueError(f"Expected scalar value, got array with shape {arr.shape}"),
                    )
            else:
                # Non-scalar expected
                if arr.ndim != len(shape):
                    raise snowml_exceptions.SnowflakeMLException(
                        error_code=error_codes.INVALID_ARGUMENT,
                        original_exception=ValueError(
                            f"Expected {len(shape)}-dimensional value, got {arr.ndim}-dimensional"
                        ),
                    )
                # Check each dimension (-1 means variable length)
                for i, (expected, actual) in enumerate(zip(shape, arr.shape)):
                    if expected != -1 and expected != actual:
                        raise snowml_exceptions.SnowflakeMLException(
                            error_code=error_codes.INVALID_ARGUMENT,
                            original_exception=ValueError(f"Dimension {i}: expected {expected}, got {actual}"),
                        )

        except (ValueError, TypeError, OverflowError) as e:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(
                    f"Default value {repr(default_value)} (type: {type(default_value).__name__}) "
                    f"is not compatible with dtype {dtype} and shape {shape}. {str(e)}"
                ),
            )

    @property
    def dtype(self) -> DataType:
        """Type of the parameter."""
        return self._dtype

    @property
    def default_value(self) -> Any:
        """Default value of the parameter."""
        return self._default_value

    def as_snowpark_type(self) -> spt.DataType:
        """Convert to corresponding Snowpark Type, accounting for shape.

        Returns:
            A Snowpark type. If shape is specified, wraps the base type in ArrayType.
        """
        result_type = self._dtype.as_snowpark_type()
        if not self._shape:
            return result_type
        for _ in range(len(self._shape)):
            # e.g. (2,) -> ArrayType(base), (2,3) -> ArrayType(ArrayType(base))
            result_type = spt.ArrayType(result_type)
        return result_type

    def to_dict(self) -> dict[str, Any]:
        """Serialize the parameter specification into a dict.

        Returns:
            A dict that serializes the parameter specification.
        """
        result: dict[str, Any] = {
            "name": self._name,
            "dtype": self._dtype.name,
            "default_value": self._default_value,
        }
        if self._shape is not None:
            result["shape"] = self._shape
        return result

    @classmethod
    def from_dict(cls, input_dict: dict[str, Any]) -> "ParamSpec":
        """Deserialize the parameter specification from a dict.

        Args:
            input_dict: The dict containing information of the parameter specification.

        Returns:
            ParamSpec: The deserialized parameter specification.
        """
        shape = input_dict.get("shape", None)
        if shape is not None:
            shape = tuple(shape)
        return ParamSpec(
            name=input_dict["name"],
            dtype=DataType[input_dict["dtype"]],
            default_value=input_dict["default_value"],
            shape=shape,
        )

    def __eq__(self, other: object) -> bool:
        if isinstance(other, ParamSpec):
            return (
                self._name == other._name
                and self._dtype == other._dtype
                and np.array_equal(self._default_value, other._default_value)
                and self._shape == other._shape
            )
        else:
            return False

    def __repr__(self) -> str:
        return self._format_repr(num_indents=0)

    def _format_repr(self, num_indents: int = 0) -> str:
        shape_str = f", shape={self._shape!r}" if self._shape else ""
        return (
            f"ParamSpec(name={self._name!r}, dtype={self._dtype!r}, default_value={self._default_value!r}{shape_str})"
        )

    @classmethod
    def from_mlflow_spec(cls, param_spec: "mlflow.types.ParamSpec") -> "ParamSpec":
        return ParamSpec(
            name=param_spec.name,
            dtype=DataType.from_numpy_type(param_spec.dtype.to_numpy()),
            default_value=param_spec.default,
            shape=param_spec.shape,
        )


class ParamGroupSpec(BaseParamSpec):
    """Specification of a group of parameters in Snowflake native model packaging."""

    def __init__(
        self,
        name: str,
        specs: list[BaseParamSpec],
        default_value: Any = None,
        shape: Optional[tuple[int, ...]] = None,
    ) -> None:
        """Initialize a parameter group.

        Args:
            name: Name of the parameter group.
            specs: A list of parameter specifications that composes the group.
            default_value: Explicit default value for the group. If None, the default
                is computed from child specs.
            shape: Shape of the parameter group. None means scalar, otherwise a tuple
                representing dimensions. Use -1 for variable length dimensions.
        """
        super().__init__(name=name, shape=shape)
        self._specs = specs
        self._default_value = default_value
        self._validate()

    def _validate(self) -> None:
        if len(self._specs) == 0:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT, original_exception=ValueError("No children param specs.")
            )

    @property
    def specs(self) -> list[BaseParamSpec]:
        """List of parameter specifications in the group."""
        return self._specs

    @property
    def dtype(self) -> DataType:
        """Type of the parameter group. Always OBJECT."""
        return DataType.OBJECT

    @staticmethod
    def _wrap_value_in_shape(value: Any, shape: tuple[int, ...]) -> Any:
        """Wrap a value in nested lists according to shape. Processes one dimension per call.

        Args:
            value: The base value to wrap.
            shape: The shape tuple. -1 means variable length (returns empty list).

        Returns:
            The value wrapped in nested lists, or empty list for variable dimensions.

        Examples:
            _wrap_value_in_shape({"x": 1}, (2,)) -> [{"x": 1}, {"x": 1}]
            _wrap_value_in_shape({"x": 1}, (-1,)) -> []
            _wrap_value_in_shape({"x": 1}, (2, -1)) -> [[], []]
        """
        if not shape:
            return value
        size = shape[0]
        if size == -1:
            return []
        return [ParamGroupSpec._wrap_value_in_shape(value, shape[1:]) for _ in range(size)]

    @property
    def default_value(self) -> Any:
        """Default value of the parameter group.

        If an explicit default was provided at construction, it is returned as-is.
        Otherwise, computes a default from child specs:
        - Without shape: returns a dict mapping parameter names to their default values.
        - With shape: returns a nested list structure where each leaf is the default dict.
        Variable-length dimensions (-1) result in empty arrays.
        Nested ParamGroupSpecs produce nested dicts (or arrays if they have shape).

        Returns:
            The explicit default value, or a computed dict/nested list of dicts.
        """
        if self._default_value is not None:
            return self._default_value

        base_dict: dict[str, Any] = {}
        for spec in self._specs:
            if isinstance(spec, ParamSpec):
                base_dict[spec.name] = spec.default_value
            elif isinstance(spec, ParamGroupSpec):
                base_dict[spec.name] = spec.default_value

        if not self._shape:
            return base_dict

        return self._wrap_value_in_shape(base_dict, self._shape)

    def as_snowpark_type(self) -> spt.DataType:
        """Convert to corresponding Snowpark Type, accounting for shape.

        Returns:
            A Snowpark MapType representing an OBJECT in Snowflake.
            If shape is specified, wraps the base type in ArrayType.
        """
        # MapType(StringType, VariantType) represents OBJECT in SQL.
        # VariantType allows heterogeneous value types, unlike FeatureGroupSpec's StructType.
        base_type: spt.DataType = spt.MapType(spt.StringType(), spt.VariantType())
        if not self._shape:
            return base_type
        for _ in range(len(self._shape)):
            # e.g. (2,) -> ArrayType(base), (2,3) -> ArrayType(ArrayType(base))
            base_type = spt.ArrayType(base_type)
        return base_type

    def __eq__(self, other: object) -> bool:
        if isinstance(other, ParamGroupSpec):
            return (
                self._name == other._name
                and self._specs == other._specs
                and self._shape == other._shape
                and self._default_value == other._default_value
            )
        return False

    def __repr__(self) -> str:
        return self._format_repr(num_indents=0)

    def _format_repr(self, num_indents: int = 0) -> str:
        base_indent = _INDENT * num_indents
        child_indent = _INDENT * (num_indents + 1)
        spec_indent = _INDENT * (num_indents + 2)
        spec_strs = ",\n".join(
            spec_indent + (spec._format_repr(num_indents + 2) if hasattr(spec, "_format_repr") else repr(spec))
            for spec in self._specs
        )
        shape_str = f", shape={self._shape!r}" if self._shape else ""
        return (
            f"ParamGroupSpec(\n"
            f"{child_indent}name={self._name!r},\n"
            f"{child_indent}specs=[\n{spec_strs}\n{child_indent}]{shape_str}\n"
            f"{base_indent})"
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize the parameter group into a dict.

        Returns:
            A dict that serializes the parameter group.
        """
        result: dict[str, Any] = {"name": self._name, "specs": [s.to_dict() for s in self._specs]}
        if self._shape is not None:
            result["shape"] = self._shape
        if self._default_value is not None:
            result["default_value"] = self._default_value
        return result

    @classmethod
    def from_dict(cls, input_dict: dict[str, Any]) -> "ParamGroupSpec":
        """Deserialize the parameter group from a dict.

        Args:
            input_dict: The dict containing information of the parameter group.

        Returns:
            A parameter group instance deserialized and created from the dict.
        """
        specs: list[BaseParamSpec] = []
        for e in input_dict["specs"]:
            spec: BaseParamSpec = ParamGroupSpec.from_dict(e) if "specs" in e else ParamSpec.from_dict(e)
            specs.append(spec)
        shape = input_dict.get("shape", None)
        if shape is not None:
            shape = tuple(shape)
        default_value = input_dict.get("default_value", None)
        return ParamGroupSpec(name=input_dict["name"], specs=specs, shape=shape, default_value=default_value)

    @classmethod
    def from_mlflow_spec(cls, param_spec: "mlflow.types.ParamSpec") -> "ParamGroupSpec":
        """Convert an MLflow ParamSpec with Object dtype to a ParamGroupSpec.

        Args:
            param_spec: An mlflow.types.ParamSpec whose dtype is mlflow.types.schema.Object.

        Returns:
            A ParamGroupSpec with child specs for each property.
        """
        specs = cls._convert_mlflow_properties(param_spec.dtype, param_spec.default)
        return cls(name=param_spec.name, specs=specs, shape=param_spec.shape, default_value=param_spec.default)

    @classmethod
    def _convert_mlflow_properties(cls, mlflow_obj: Any, default: Any) -> list[BaseParamSpec]:
        """Recursively convert MLflow Object properties to child param specs.

        Args:
            mlflow_obj: An mlflow.types.schema.Object instance.
            default: The default value dict for this level (or None).

        Returns:
            A list of child BaseParamSpec instances.

        Raises:
            SnowflakeMLException: If a property has an unsupported dtype.
        """
        import mlflow

        default_dict = default if isinstance(default, dict) else {}
        specs: list[BaseParamSpec] = []

        for prop in mlflow_obj.properties:
            child_default = default_dict.get(prop.name)
            if isinstance(prop.dtype, mlflow.types.schema.Object):
                child_specs = cls._convert_mlflow_properties(prop.dtype, child_default)
                specs.append(cls(name=prop.name, specs=child_specs))
            elif isinstance(prop.dtype, mlflow.types.schema.Array):
                specs.append(cls._convert_mlflow_array_property(prop.name, prop.dtype, child_default))
            elif isinstance(prop.dtype, mlflow.types.schema.DataType):
                specs.append(
                    ParamSpec(
                        name=prop.name,
                        dtype=DataType.from_numpy_type(prop.dtype.to_numpy()),
                        default_value=child_default,
                    )
                )
            else:
                raise snowml_exceptions.SnowflakeMLException(
                    error_code=error_codes.NOT_IMPLEMENTED,
                    original_exception=NotImplementedError(
                        f"MLflow param property dtype {type(prop.dtype)} is not supported "
                        f"for property '{prop.name}'."
                    ),
                )

        return specs

    @classmethod
    def _convert_mlflow_array_property(cls, name: str, mlflow_array: Any, default: Any) -> BaseParamSpec:
        """Convert an MLflow Array-typed property to a param spec.

        Args:
            name: The property name.
            mlflow_array: An mlflow.types.schema.Array instance.
            default: The default value for this property (typically a list, or None).

        Returns:
            A ParamSpec with shape for scalar arrays, or a ParamGroupSpec with shape for object arrays.

        Raises:
            SnowflakeMLException: If the innermost array element type is not supported.
        """
        import mlflow

        depth = 0
        inner = mlflow_array
        while isinstance(inner, mlflow.types.schema.Array):
            depth += 1
            inner = inner.dtype

        shape = (-1,) * depth

        if isinstance(inner, mlflow.types.schema.Object):
            child_specs = cls._convert_mlflow_properties(inner, default)
            return cls(name=name, specs=child_specs, shape=shape, default_value=default)
        elif isinstance(inner, mlflow.types.schema.DataType):
            return ParamSpec(
                name=name,
                dtype=DataType.from_numpy_type(inner.to_numpy()),
                default_value=default,
                shape=shape,
            )
        else:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.NOT_IMPLEMENTED,
                original_exception=NotImplementedError(
                    f"MLflow param property dtype {type(inner)} inside Array is not supported "
                    f"for property '{name}'."
                ),
            )


class ModelSignature:
    """Signature of a model that specifies the input and output of a model."""

    def __init__(
        self,
        inputs: Sequence[BaseFeatureSpec],
        outputs: Sequence[BaseFeatureSpec],
        params: Optional[Sequence[BaseParamSpec]] = None,
    ) -> None:
        """Initialize a model signature.

        Args:
            inputs: A sequence of feature specifications and feature group specifications that will compose
                the input of the model.
            outputs: A sequence of feature specifications and feature group specifications that will compose
                the output of the model.
            params: A sequence of parameter specifications and parameter group specifications that will compose
                the parameters of the model. Defaults to None.

        Raises:
            SnowflakeMLException: ValueError: When the parameters have duplicate names or the same
                names as input features.

        # noqa: DAR402
        """
        self._inputs = inputs
        self._outputs = outputs
        self._params = params or []
        self._name_validation()

    @property
    def inputs(self) -> Sequence[BaseFeatureSpec]:
        """Inputs of the model, containing a sequence of feature specifications and feature group specifications."""
        return self._inputs

    @property
    def outputs(self) -> Sequence[BaseFeatureSpec]:
        """Outputs of the model, containing a sequence of feature specifications and feature group specifications."""
        return self._outputs

    @property
    def params(self) -> Sequence[BaseParamSpec]:
        """Parameters of the model, containing a sequence of parameter specifications."""
        return self._params

    def __eq__(self, other: object) -> bool:
        if isinstance(other, ModelSignature):
            return (
                self._inputs == other._inputs
                and self._outputs == other._outputs
                and getattr(other, "_params", []) == self._params  # handles backward compatibility
            )
        else:
            return False

    def to_dict(self) -> dict[str, Any]:
        """Generate a dict to represent the whole signature.

        Returns:
            A dict that serializes the signature.
        """

        return {
            "inputs": [spec.to_dict() for spec in self._inputs],
            "outputs": [spec.to_dict() for spec in self._outputs],
            "params": [spec.to_dict() for spec in self._params],
        }

    @classmethod
    def from_dict(cls, loaded: dict[str, Any]) -> "ModelSignature":
        """Create a signature given the dict containing specifications of children features and feature groups.

        Args:
            loaded: The dict to be deserialized.

        Returns:
            A signature deserialized and created from the dict.
        """
        sig_outs = loaded["outputs"]
        sig_inputs = loaded["inputs"]
        # If parameters is not provided, default to empty list for backward compatibility.
        sig_params = loaded.get("params", [])

        deserialize_spec: Callable[[dict[str, Any]], BaseFeatureSpec] = lambda sig_spec: (
            FeatureGroupSpec.from_dict(sig_spec) if "specs" in sig_spec else FeatureSpec.from_dict(sig_spec)
        )
        deserialize_param: Callable[[dict[str, Any]], BaseParamSpec] = lambda sig_param: (
            ParamGroupSpec.from_dict(sig_param) if "specs" in sig_param else ParamSpec.from_dict(sig_param)
        )

        return ModelSignature(
            inputs=[deserialize_spec(s) for s in sig_inputs],
            outputs=[deserialize_spec(s) for s in sig_outs],
            params=[deserialize_param(s) for s in sig_params],
        )

    def __repr__(self) -> str:
        def format_spec_list(specs: Sequence[Union[BaseFeatureSpec, BaseParamSpec]], num_indents: int = 2) -> str:
            if not specs:
                return ""
            return ",\n".join(
                _INDENT * num_indents
                + (spec._format_repr(num_indents) if hasattr(spec, "_format_repr") else repr(spec))
                for spec in specs
            )

        inputs_spec_strs = format_spec_list(list(self._inputs))
        outputs_spec_strs = format_spec_list(list(self._outputs))
        params_spec_strs = format_spec_list(list(self._params))

        def format_array(name: str, content: str) -> str:
            if not content:
                return f"{_INDENT}{name}=[]"
            return f"{_INDENT}{name}=[\n{content}\n{_INDENT}]"

        return (
            f"ModelSignature(\n"
            f"{format_array('inputs', inputs_spec_strs)},\n"
            f"{format_array('outputs', outputs_spec_strs)},\n"
            f"{format_array('params', params_spec_strs)}\n"
            f")"
        )

    def _repr_html_(self) -> str:
        """Generate an HTML representation of the model signature.

        Returns:
            str: HTML string containing formatted signature details.
        """
        from snowflake.ml.utils import html_utils

        # Create collapsible sections for inputs and outputs
        inputs_content = html_utils.create_features_html(self.inputs, "Input")
        outputs_content = html_utils.create_features_html(self.outputs, "Output")
        params_content = html_utils.create_parameters_html(self.params)
        inputs_section = html_utils.create_collapsible_section("Inputs", inputs_content, open_by_default=True)
        outputs_section = html_utils.create_collapsible_section("Outputs", outputs_content, open_by_default=True)
        params_section = html_utils.create_collapsible_section("Parameters", params_content, open_by_default=True)

        content = f"""
            <div style="margin-top: 10px;">
                {inputs_section}
                {outputs_section}
                {params_section}
            </div>
        """

        return html_utils.create_base_container("Model Signature", content)

    def _name_validation(self) -> None:
        """Validate the names of the inputs and parameters.

        Names are compared case-insensitively (matches Snowflake identifier behavior).

        Raises:
            SnowflakeMLException: ValueError: When the parameters have duplicate names or the same
                names as input features.
        """
        input_names: set[str] = set()
        for input_spec in self._inputs:
            names = (
                [input_spec.name.upper() for spec in input_spec._specs]
                if isinstance(input_spec, FeatureGroupSpec)
                else [input_spec.name.upper()]
            )
            input_names.update(names)

        param_names: set[str] = set()
        dup_params: set[str] = set()
        collision_names: set[str] = set()

        for param in self._params:
            names = [spec.name for spec in param.specs] if isinstance(param, ParamGroupSpec) else [param.name]
            for name in names:
                if name.upper() in param_names:
                    dup_params.add(name)
                if name.upper() in input_names:
                    collision_names.add(name)
                param_names.add(name.upper())

        if dup_params:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(
                    f"Found duplicate parameter named resolved as {', '.join(sorted(dup_params))}."
                    " Parameters must have distinct names (case-insensitive)."
                ),
            )

        if collision_names:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(
                    f"Found parameter(s) with the same name as input feature(s): {', '.join(sorted(collision_names))}."
                    " Parameters and inputs must have distinct names (case-insensitive)."
                ),
            )

    @classmethod
    def from_mlflow_sig(cls, mlflow_sig: "mlflow.models.ModelSignature") -> "ModelSignature":
        inputs = [
            FeatureSpec.from_mlflow_spec(spec, f"input_feature_{idx}") for idx, spec in enumerate(mlflow_sig.inputs)
        ]
        outputs = [
            FeatureSpec.from_mlflow_spec(spec, f"output_feature_{idx}") for idx, spec in enumerate(mlflow_sig.outputs)
        ]

        if hasattr(mlflow_sig, "params") and mlflow_sig.params:
            import mlflow

            params: list[BaseParamSpec] = []
            for spec in mlflow_sig.params:
                if isinstance(spec.dtype, mlflow.types.schema.Object):
                    params.append(ParamGroupSpec.from_mlflow_spec(spec))
                elif isinstance(spec.dtype, mlflow.types.schema.DataType):
                    params.append(ParamSpec.from_mlflow_spec(spec))
                else:
                    raise snowml_exceptions.SnowflakeMLException(
                        error_code=error_codes.NOT_IMPLEMENTED,
                        original_exception=NotImplementedError(
                            f"MLflow param dtype {type(spec.dtype)} is not supported " f"for parameter '{spec.name}'."
                        ),
                    )
        else:
            params = []

        return ModelSignature(inputs=inputs, outputs=outputs, params=params)
