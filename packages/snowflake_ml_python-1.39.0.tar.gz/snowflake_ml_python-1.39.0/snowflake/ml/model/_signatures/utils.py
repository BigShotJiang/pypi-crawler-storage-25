import warnings
from typing import Any, Optional, Sequence

import numpy as np
import numpy.typing as npt
import pandas as pd

from snowflake.ml._internal.exceptions import (
    error_codes,
    exceptions as snowml_exceptions,
)
from snowflake.ml.model import openai_signatures
from snowflake.ml.model._signatures import core


def convert_list_to_ndarray(data: list[Any]) -> npt.NDArray[Any]:
    """Create a numpy array from list or nested list. Avoid ragged list and unaligned types.

    Args:
        data: List or nested list.

    Raises:
        SnowflakeMLException: ValueError: Raised when ragged nested list or list containing non-basic type confronted.

    Returns:
        The converted numpy array.
    """
    # VisibleDeprecationWarning was removed in numpy>2
    visible_deprecation_warning = getattr(np, "VisibleDeprecationWarning", None)
    exception_types = (ValueError,)

    if visible_deprecation_warning is not None:
        warnings.filterwarnings("error", category=visible_deprecation_warning)
        exception_types = (visible_deprecation_warning, ValueError)  # type: ignore[assignment]

    try:
        arr = np.array(data)
    except exception_types:
        # In recent version of numpy, this warning should be raised when bad list provided.
        raise snowml_exceptions.SnowflakeMLException(
            error_code=error_codes.INVALID_DATA,
            original_exception=ValueError(
                f"Unable to construct signature: Ragged nested or Unsupported list-like data {data} confronted."
            ),
        )
    finally:
        if visible_deprecation_warning is not None:
            warnings.filterwarnings("default", category=visible_deprecation_warning)

    if arr.dtype == object:
        # If not raised, then a array of object would be created.
        raise snowml_exceptions.SnowflakeMLException(
            error_code=error_codes.INVALID_DATA,
            original_exception=ValueError(
                f"Unable to construct signature: Ragged nested or Unsupported list-like data {data} confronted."
            ),
        )
    return arr


def rename_features(
    features: Sequence[core.BaseFeatureSpec], feature_names: Optional[list[str]] = None
) -> Sequence[core.BaseFeatureSpec]:
    """It renames the feature in features provided optional feature names.

    Args:
        features: A sequence of feature specifications and feature group specifications.
        feature_names: A list of names to assign to features and feature groups. Defaults to None.

    Raises:
        SnowflakeMLException: ValueError: Raised when provided feature_names does not match the data shape.

    Returns:
        A sequence of feature specifications and feature group specifications being renamed if names provided.
    """
    if feature_names:
        if len(feature_names) == len(features):
            for ft, ft_name in zip(features, feature_names):
                ft._name = ft_name
        else:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(
                    f"{len(feature_names)} feature names are provided, while there are {len(features)} features."
                ),
            )
    return features


def rename_pandas_df(data: pd.DataFrame, features: Sequence[core.BaseFeatureSpec]) -> pd.DataFrame:
    """It renames pandas dataframe that has non-object column index with provided features.

    Args:
        data: A pandas dataframe to be renamed.
        features: A sequence of feature specifications and feature group specifications to rename the dataframe.

    Raises:
        SnowflakeMLException: ValueError: Raised when the data does not have the same number of features as signature.

    Returns:
        A pandas dataframe with columns renamed.
    """
    df_cols = data.columns
    if df_cols.dtype in [np.int64, np.uint64, np.float64]:
        if len(features) != len(data.columns):
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(
                    "Data does not have the same number of features as signature. "
                    + f"Signature requires {len(features)} features, but have {len(data.columns)} in input data."
                ),
            )
        data.columns = pd.Index([feature.name for feature in features])
    return data


def huggingface_pipeline_signature_auto_infer(
    task: str,
    params: dict[str, Any],
    has_chat_template: Optional[bool] = True,
) -> Optional[core.ModelSignature]:
    # Text

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.TokenClassificationPipeline
    if task == "fill-mask":
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="inputs", dtype=core.DataType.STRING),
            ],
            outputs=[
                core.FeatureGroupSpec(
                    name="outputs",
                    specs=[
                        core.FeatureSpec(name="sequence", dtype=core.DataType.STRING),
                        core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
                        core.FeatureSpec(name="token", dtype=core.DataType.INT64),
                        core.FeatureSpec(name="token_str", dtype=core.DataType.STRING),
                    ],
                    shape=(-1,),
                ),
            ],
            params=[
                core.ParamSpec(name="targets", dtype=core.DataType.STRING, default_value=None, shape=(-1,)),
                core.ParamSpec(name="top_k", dtype=core.DataType.INT64, default_value=None),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.TokenClassificationPipeline
    if task == "ner" or task == "token-classification":
        return core.ModelSignature(
            inputs=[core.FeatureSpec(name="inputs", dtype=core.DataType.STRING)],
            outputs=[
                core.FeatureGroupSpec(
                    name="outputs",
                    specs=[
                        core.FeatureSpec(name="word", dtype=core.DataType.STRING),
                        core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
                        core.FeatureSpec(name="entity", dtype=core.DataType.STRING),
                        core.FeatureSpec(name="index", dtype=core.DataType.INT64),
                        core.FeatureSpec(name="start", dtype=core.DataType.INT64),
                        core.FeatureSpec(name="end", dtype=core.DataType.INT64),
                    ],
                    shape=(-1,),
                ),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.QuestionAnsweringPipeline
    if task == "question-answering":
        qa_params = [
            core.ParamSpec(name="top_k", dtype=core.DataType.INT64, default_value=1),
            core.ParamSpec(name="doc_stride", dtype=core.DataType.INT64, default_value=128),
            core.ParamSpec(name="max_answer_len", dtype=core.DataType.INT64, default_value=15),
            core.ParamSpec(name="max_seq_len", dtype=core.DataType.INT64, default_value=384),
            core.ParamSpec(name="max_question_len", dtype=core.DataType.INT64, default_value=64),
            core.ParamSpec(name="handle_impossible_answer", dtype=core.DataType.BOOL, default_value=False),
            core.ParamSpec(name="align_to_words", dtype=core.DataType.BOOL, default_value=True),
        ]
        # If top_k and topk is not set or set to 1, then the output is a dict per input, thus we could expand.
        if params.get("top_k", 1) == 1 and params.get("topk", 1) == 1:
            return core.ModelSignature(
                inputs=[
                    core.FeatureSpec(name="question", dtype=core.DataType.STRING),
                    core.FeatureSpec(name="context", dtype=core.DataType.STRING),
                ],
                outputs=[
                    core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
                    core.FeatureSpec(name="start", dtype=core.DataType.INT64),
                    core.FeatureSpec(name="end", dtype=core.DataType.INT64),
                    core.FeatureSpec(name="answer", dtype=core.DataType.STRING),
                ],
                params=qa_params,
            )
        # Else it is a list of dict per input.
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="question", dtype=core.DataType.STRING),
                core.FeatureSpec(name="context", dtype=core.DataType.STRING),
            ],
            outputs=[
                core.FeatureGroupSpec(
                    name="answers",
                    specs=[
                        core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
                        core.FeatureSpec(name="start", dtype=core.DataType.INT64),
                        core.FeatureSpec(name="end", dtype=core.DataType.INT64),
                        core.FeatureSpec(name="answer", dtype=core.DataType.STRING),
                    ],
                    shape=(-1,),
                ),
            ],
            params=qa_params,
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.SummarizationPipeline
    if task == "summarization":
        if params.get("return_tensors", False):
            raise NotImplementedError(
                f"Auto deployment for HuggingFace pipeline {task} "
                "when `return_tensors` set to `True` has not been supported yet."
            )
        # Always generate a dict per input
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="documents", dtype=core.DataType.STRING),
            ],
            outputs=[
                core.FeatureSpec(name="summary_text", dtype=core.DataType.STRING),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.TableQuestionAnsweringPipeline
    if task == "table-question-answering":
        # Always generate a dict per input
        # Table is a JSON serialized string
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="query", dtype=core.DataType.STRING),
                core.FeatureSpec(name="table", dtype=core.DataType.STRING),
            ],
            outputs=[
                core.FeatureSpec(name="answer", dtype=core.DataType.STRING),
                core.FeatureSpec(name="coordinates", dtype=core.DataType.INT64, shape=(-1,)),
                core.FeatureSpec(name="cells", dtype=core.DataType.STRING, shape=(-1,)),
                core.FeatureSpec(name="aggregator", dtype=core.DataType.STRING),
            ],
            params=[
                core.ParamSpec(name="sequential", dtype=core.DataType.BOOL, default_value=False),
                core.ParamSpec(name="padding", dtype=core.DataType.STRING, default_value=None),
                core.ParamSpec(name="truncation", dtype=core.DataType.STRING, default_value=None),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.TextClassificationPipeline
    if task == "text-classification" or task == "sentiment-analysis":
        text_cls_params = [
            core.ParamSpec(name="top_k", dtype=core.DataType.INT64, default_value=1),
            core.ParamSpec(name="function_to_apply", dtype=core.DataType.STRING, default_value=None),
        ]
        # If top_k is set, return a list of dict per input
        if params.get("top_k", None) is not None:
            return core.ModelSignature(
                inputs=[
                    core.FeatureSpec(name="text", dtype=core.DataType.STRING),
                ],
                outputs=[
                    core.FeatureGroupSpec(
                        name="labels",
                        specs=[
                            core.FeatureSpec(name="label", dtype=core.DataType.STRING),
                            core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
                        ],
                        shape=(-1,),
                    ),
                ],
                params=text_cls_params,
            )
        # Else, return a dict per input
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="text", dtype=core.DataType.STRING),
            ],
            outputs=[
                core.FeatureSpec(name="label", dtype=core.DataType.STRING),
                core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
            ],
            params=text_cls_params,
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.ImageClassificationPipeline
    if task == "image-classification":
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="images", dtype=core.DataType.BYTES),
            ],
            outputs=[
                core.FeatureGroupSpec(
                    name="labels",
                    specs=[
                        core.FeatureSpec(name="label", dtype=core.DataType.STRING),
                        core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
                    ],
                    shape=(-1,),
                ),
            ],
            params=[
                core.ParamSpec(name="top_k", dtype=core.DataType.INT64, default_value=5),
                core.ParamSpec(name="function_to_apply", dtype=core.DataType.STRING, default_value=None),
                core.ParamSpec(name="timeout", dtype=core.DataType.DOUBLE, default_value=None),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.AutomaticSpeechRecognitionPipeline
    if task == "automatic-speech-recognition":
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="audio", dtype=core.DataType.BYTES),
            ],
            outputs=[
                core.FeatureGroupSpec(
                    name="outputs",
                    specs=[
                        core.FeatureSpec(name="text", dtype=core.DataType.STRING),
                        core.FeatureGroupSpec(
                            name="chunks",
                            specs=[
                                core.FeatureSpec(name="timestamp", dtype=core.DataType.DOUBLE, shape=(2,)),
                                core.FeatureSpec(name="text", dtype=core.DataType.STRING),
                            ],
                            shape=(-1,),  # Variable length list of chunks
                        ),
                    ],
                )
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.VideoClassificationPipeline
    if task == "video-classification":
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="video", dtype=core.DataType.BYTES),
            ],
            outputs=[
                core.FeatureGroupSpec(
                    name="labels",
                    specs=[
                        core.FeatureSpec(name="label", dtype=core.DataType.STRING),
                        core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
                    ],
                    shape=(-1,),
                ),
            ],
            params=[
                core.ParamSpec(name="top_k", dtype=core.DataType.INT64, default_value=5),
                core.ParamSpec(name="num_frames", dtype=core.DataType.INT64, default_value=None),
                core.ParamSpec(name="frame_sampling_rate", dtype=core.DataType.INT64, default_value=1),
                core.ParamSpec(name="function_to_apply", dtype=core.DataType.STRING, default_value="softmax"),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.DocumentQuestionAnsweringPipeline
    if task == "document-question-answering":
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="image", dtype=core.DataType.BYTES),
                core.FeatureSpec(name="question", dtype=core.DataType.STRING),
            ],
            outputs=[
                core.FeatureGroupSpec(
                    name="answers",
                    specs=[
                        core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
                        core.FeatureSpec(name="start", dtype=core.DataType.INT64),
                        core.FeatureSpec(name="end", dtype=core.DataType.INT64),
                        core.FeatureSpec(name="answer", dtype=core.DataType.STRING),
                    ],
                    shape=(-1,),
                ),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.VisualQuestionAnsweringPipeline
    if task == "visual-question-answering":
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="image", dtype=core.DataType.BYTES),
                core.FeatureSpec(name="question", dtype=core.DataType.STRING),
            ],
            outputs=[
                core.FeatureGroupSpec(
                    name="answers",
                    specs=[
                        core.FeatureSpec(name="answer", dtype=core.DataType.STRING),
                        core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
                    ],
                    shape=(-1,),
                ),
            ],
            params=[
                core.ParamSpec(name="top_k", dtype=core.DataType.INT64, default_value=5),
                core.ParamSpec(name="timeout", dtype=core.DataType.DOUBLE, default_value=None),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.ImageFeatureExtractionPipeline
    if task == "image-feature-extraction":
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="images", dtype=core.DataType.BYTES),
            ],
            outputs=[
                core.FeatureSpec(name="feature_extraction", dtype=core.DataType.DOUBLE, shape=(-1,)),
            ],
            params=[
                core.ParamSpec(name="timeout", dtype=core.DataType.DOUBLE, default_value=None),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.ImageToTextPipeline
    if task == "image-to-text":
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="images", dtype=core.DataType.BYTES),
            ],
            outputs=[
                core.FeatureGroupSpec(
                    name="outputs",
                    specs=[
                        core.FeatureSpec(name="generated_text", dtype=core.DataType.STRING),
                    ],
                    shape=(-1,),
                ),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.ObjectDetectionPipeline
    if task == "object-detection":
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="images", dtype=core.DataType.BYTES),
            ],
            outputs=[
                core.FeatureGroupSpec(
                    name="detections",
                    specs=[
                        core.FeatureSpec(name="label", dtype=core.DataType.STRING),
                        core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
                        core.FeatureGroupSpec(
                            name="box",
                            specs=[
                                core.FeatureSpec(name="xmin", dtype=core.DataType.INT64),
                                core.FeatureSpec(name="ymin", dtype=core.DataType.INT64),
                                core.FeatureSpec(name="xmax", dtype=core.DataType.INT64),
                                core.FeatureSpec(name="ymax", dtype=core.DataType.INT64),
                            ],
                        ),
                    ],
                    shape=(-1,),
                ),
            ],
            params=[
                core.ParamSpec(name="threshold", dtype=core.DataType.DOUBLE, default_value=0.5),
                core.ParamSpec(name="timeout", dtype=core.DataType.DOUBLE, default_value=None),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.ZeroShotImageClassificationPipeline
    if task == "zero-shot-image-classification":
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="images", dtype=core.DataType.BYTES),
                core.FeatureSpec(name="candidate_labels", dtype=core.DataType.STRING, shape=(-1,)),
            ],
            outputs=[
                core.FeatureGroupSpec(
                    name="labels",
                    specs=[
                        core.FeatureSpec(name="label", dtype=core.DataType.STRING),
                        core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
                    ],
                    shape=(-1,),
                ),
            ],
            params=[
                core.ParamSpec(
                    name="hypothesis_template", dtype=core.DataType.STRING, default_value="This is a photo of {}."
                ),
                core.ParamSpec(name="timeout", dtype=core.DataType.DOUBLE, default_value=None),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.ZeroShotObjectDetectionPipeline
    if task == "zero-shot-object-detection":
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="images", dtype=core.DataType.BYTES),
                core.FeatureSpec(name="candidate_labels", dtype=core.DataType.STRING, shape=(-1,)),
            ],
            outputs=[
                core.FeatureGroupSpec(
                    name="detections",
                    specs=[
                        core.FeatureSpec(name="label", dtype=core.DataType.STRING),
                        core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
                        core.FeatureGroupSpec(
                            name="box",
                            specs=[
                                core.FeatureSpec(name="xmin", dtype=core.DataType.INT64),
                                core.FeatureSpec(name="ymin", dtype=core.DataType.INT64),
                                core.FeatureSpec(name="xmax", dtype=core.DataType.INT64),
                                core.FeatureSpec(name="ymax", dtype=core.DataType.INT64),
                            ],
                        ),
                    ],
                    shape=(-1,),
                ),
            ],
            params=[
                core.ParamSpec(name="threshold", dtype=core.DataType.DOUBLE, default_value=0.1),
                core.ParamSpec(name="top_k", dtype=core.DataType.INT64, default_value=None),
                core.ParamSpec(name="timeout", dtype=core.DataType.DOUBLE, default_value=None),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.TextGenerationPipeline
    if task == "text-generation" and has_chat_template:
        if params.get("return_tensors", False):
            raise NotImplementedError(
                f"Auto deployment for HuggingFace pipeline {task} "
                "when `return_tensors` set to `True` has not been supported yet."
            )
        return openai_signatures._OPENAI_CHAT_SIGNATURE_WITH_PARAMS_SPEC

    if task == "text-generation" and not has_chat_template:
        if params.get("return_tensors", False):
            raise NotImplementedError(
                f"Auto deployment for HuggingFace pipeline {task} "
                "when `return_tensors` set to `True` has not been supported yet."
            )
        # Always generate a list of dict per input
        return core.ModelSignature(
            inputs=[core.FeatureSpec(name="inputs", dtype=core.DataType.STRING)],
            outputs=[
                core.FeatureGroupSpec(
                    name="outputs",
                    specs=[core.FeatureSpec(name="generated_text", dtype=core.DataType.STRING)],
                    shape=(-1,),
                )
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.ImageTextToTextPipeline
    if task in [
        "image-text-to-text",
        "video-text-to-text",
        "audio-text-to-text",
    ]:
        if params.get("return_tensors", False):
            raise NotImplementedError(
                f"Auto deployment for HuggingFace pipeline {task} "
                "when `return_tensors` set to `True` has not been supported yet."
            )
        # Always generate a dict per input
        # defaulting to OPENAI_CHAT_SIGNATURE_WITH_PARAMS_SPEC for image-text-to-text,
        # video-text-to-text, and audio-text-to-text pipelines so inference controls
        # (temperature, max_completion_tokens, etc.) are exposed as params with defaults
        # rather than required input columns.
        return openai_signatures._OPENAI_CHAT_SIGNATURE_WITH_PARAMS_SPEC

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.Text2TextGenerationPipeline
    if task == "text2text-generation":
        if params.get("return_tensors", False):
            raise NotImplementedError(
                f"Auto deployment for HuggingFace pipeline {task} "
                "when `return_tensors` set to `True` has not been supported yet."
            )
        # Always generate a dict per input
        return core.ModelSignature(
            inputs=[core.FeatureSpec(name="inputs", dtype=core.DataType.STRING)],
            outputs=[
                core.FeatureSpec(name="generated_text", dtype=core.DataType.STRING),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.TranslationPipeline
    if task.startswith("translation"):
        if params.get("return_tensors", False):
            raise NotImplementedError(
                f"Auto deployment for HuggingFace pipeline {task} "
                "when `return_tensors` set to `True` has not been supported yet."
            )
        # Always generate a dict per input
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="inputs", dtype=core.DataType.STRING),
            ],
            outputs=[
                core.FeatureSpec(name="translation_text", dtype=core.DataType.STRING),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.ZeroShotClassificationPipeline
    if task == "zero-shot-classification":
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="sequences", dtype=core.DataType.STRING),
                core.FeatureSpec(name="candidate_labels", dtype=core.DataType.STRING, shape=(-1,)),
            ],
            outputs=[
                core.FeatureSpec(name="sequence", dtype=core.DataType.STRING),
                core.FeatureSpec(name="labels", dtype=core.DataType.STRING, shape=(-1,)),
                core.FeatureSpec(name="scores", dtype=core.DataType.DOUBLE, shape=(-1,)),
            ],
            params=[
                core.ParamSpec(
                    name="hypothesis_template", dtype=core.DataType.STRING, default_value="This example is {}."
                ),
                core.ParamSpec(name="multi_label", dtype=core.DataType.BOOL, default_value=False),
            ],
        )

    # https://huggingface.co/docs/transformers/en/main_classes/pipelines#transformers.ZeroShotAudioClassificationPipeline
    if task == "zero-shot-audio-classification":
        return core.ModelSignature(
            inputs=[
                core.FeatureSpec(name="audio", dtype=core.DataType.BYTES),
                core.FeatureSpec(name="candidate_labels", dtype=core.DataType.STRING, shape=(-1,)),
            ],
            outputs=[
                core.FeatureGroupSpec(
                    name="labels",
                    specs=[
                        core.FeatureSpec(name="label", dtype=core.DataType.STRING),
                        core.FeatureSpec(name="score", dtype=core.DataType.DOUBLE),
                    ],
                    shape=(-1,),
                ),
            ],
            params=[
                core.ParamSpec(
                    name="hypothesis_template", dtype=core.DataType.STRING, default_value="This is a sound of {}."
                ),
            ],
        )

    return None


def series_dropna(series: pd.Series, try_convert_dtypes: bool = True) -> pd.Series:
    """Drop NA values from a Series, optionally narrowing the dtype.

    Args:
        series: The input pandas Series.
        try_convert_dtypes: If True, call ``convert_dtypes()`` after dropping
            NAs, which may narrow ``float64`` to ``Int64`` when all remaining
            values are whole numbers. Set to False in signature *inference* to
            preserve the original pandas dtype and avoid position-dependent
            type inference. Keep True for *validation* so that INT64 features
            pass when the user supplies data containing None.

    Returns:
        A new Series with NA values removed and index reset.
    """
    result = series.dropna(inplace=False).reset_index(drop=True)
    if try_convert_dtypes:
        result = result.convert_dtypes()
    return result


def infer_param(name: str, value: Any) -> core.ParamSpec:
    """Infer a ParamSpec from a Python value.

    Scalar values produce a scalar ParamSpec (dtype via DataType.from_python_type).
    List/tuple values produce a shaped ParamSpec with (-1,) per nesting level,
    using the same numpy-based inference as feature lists (convert_list_to_ndarray).
    This allows numeric widening (e.g. [1, 0.7] -> DOUBLE).

    Args:
        name: Parameter name.
        value: A Python value to infer from.

    Raises:
        SnowflakeMLException: When value is None, an empty list, or
            contains unsupported or mixed types.

    Returns:
        A ParamSpec with dtype and shape inferred from the value.
    """
    if value is None:
        raise snowml_exceptions.SnowflakeMLException(
            error_code=error_codes.INVALID_ARGUMENT,
            original_exception=ValueError(
                f"Cannot infer ParamSpec dtype for parameter '{name}' from None value. "
                "Use an explicit ParamSpec to specify the dtype."
            ),
        )

    if isinstance(value, dict):
        raise snowml_exceptions.SnowflakeMLException(
            error_code=error_codes.INVALID_ARGUMENT,
            original_exception=ValueError(
                f"Dict values are not yet supported for parameter '{name}' in dict-based param inference."
            ),
        )

    if isinstance(value, (list, tuple)):
        if not value:
            raise snowml_exceptions.SnowflakeMLException(
                error_code=error_codes.INVALID_ARGUMENT,
                original_exception=ValueError(
                    f"Cannot infer ParamSpec dtype for parameter '{name}' from an empty list. "
                    "Use an explicit ParamSpec to specify the dtype and shape."
                ),
            )
        arr = convert_list_to_ndarray(list(value))
        dtype = core.DataType.from_numpy_type(arr.dtype)
        shape = tuple(-1 for _ in arr.shape)
        return core.ParamSpec(name=name, dtype=dtype, default_value=value, shape=shape)

    try:
        dtype = core.DataType.from_python_type(type(value))
    except snowml_exceptions.SnowflakeMLException:
        raise snowml_exceptions.SnowflakeMLException(
            error_code=error_codes.INVALID_ARGUMENT,
            original_exception=ValueError(
                f"Cannot infer ParamSpec dtype from value of type {type(value).__name__} " f"for parameter '{name}'."
            ),
        )

    return core.ParamSpec(name=name, dtype=dtype, default_value=value, shape=None)


def infer_list(name: str, data: list[Any]) -> core.BaseFeatureSpec:
    """Infer the feature specification from a list.

    Args:
        name: Feature name.
        data: A list.

    Raises:
        SnowflakeMLException: ValueError: Raised when empty list is provided.

    Returns:
        A feature specification.
    """
    if not data:
        raise snowml_exceptions.SnowflakeMLException(
            error_code=error_codes.INVALID_DATA,
            original_exception=ValueError("Data Validation Error: Empty list is found."),
        )

    if all(isinstance(value, dict) for value in data):
        ft = infer_dict(name, data[0])
        ft._name = name
        ft._shape = (-1,)
        return ft

    arr = convert_list_to_ndarray(data)
    arr_dtype = core.DataType.from_numpy_type(arr.dtype)

    return core.FeatureSpec(name=name, dtype=arr_dtype, shape=arr.shape)


def infer_dict(name: str, data: dict[str, Any]) -> core.FeatureGroupSpec:
    """Infer the feature specification from a dictionary.

    Args:
        name: Feature name.
        data: A dictionary.

    Raises:
        SnowflakeMLException: ValueError: Raised when empty dictionary is provided.
        SnowflakeMLException: ValueError: Raised when empty list is found in the dictionary.

    Returns:
        A feature group specification.
    """
    if not data:
        raise snowml_exceptions.SnowflakeMLException(
            error_code=error_codes.INVALID_DATA,
            original_exception=ValueError("Data Validation Error: Empty dictionary is found."),
        )

    specs = []
    for key, value in data.items():
        if isinstance(value, list):
            specs.append(infer_list(key, value))
        elif isinstance(value, dict):
            specs.append(infer_dict(key, value))
        else:
            specs.append(core.FeatureSpec(name=key, dtype=core.DataType.from_numpy_type(np.array(value).dtype)))

    return core.FeatureGroupSpec(name=name, specs=specs)


def check_if_series_is_empty(series: Optional[pd.Series]) -> bool:
    return series is None or series.empty
