"""
Tests for runtime module.
"""

from types import SimpleNamespace
from datetime import datetime
from datetime import timezone
import json

import pytest
from context import mtr2mqtt
from mtr2mqtt import runtime


def test_open_mqtt_connection_uses_callback_api_v2(monkeypatch):
    """
    MQTT client initialization opts in to the non-deprecated callback API.
    """
    captured = {}

    class FakeClient:
        def __init__(self, **kwargs):
            captured["kwargs"] = kwargs
            self.connected_flag = False

        def enable_logger(self):
            captured["enable_logger"] = True

        def reconnect_delay_set(self, min_delay, max_delay):
            captured["reconnect_delay_set"] = (min_delay, max_delay)

        def loop_start(self):
            captured["loop_start"] = True

        def connect(self, host, port):
            captured["connect"] = (host, port)
            self.connected_flag = True

    monkeypatch.setattr(runtime.mqtt, "Client", FakeClient)
    monkeypatch.setattr(
        runtime.mqtt,
        "CallbackAPIVersion",
        SimpleNamespace(VERSION2="version2"),
    )
    monkeypatch.setattr(runtime.time, "sleep", lambda _: None)

    args = SimpleNamespace(mqtt_host="mqtt.example", mqtt_port=1884)

    client = runtime.open_mqtt_connection(args)

    assert captured["kwargs"]["callback_api_version"] == "version2"
    assert captured["kwargs"]["client_id"] == "mtr2mqtt"
    assert captured["kwargs"]["protocol"] == runtime.mqtt.MQTTv311
    assert captured["kwargs"]["transport"] == "tcp"
    assert captured["connect"] == ("mqtt.example", 1884)
    assert captured["reconnect_delay_set"] == (1, 30)
    assert captured["enable_logger"] is True
    assert captured["loop_start"] is True
    assert client.on_connect is runtime.on_connect
    assert client.on_disconnect is runtime.on_disconnect


def test_open_mqtt_connection_raises_mqtt_error_on_connect_failure(monkeypatch):
    """
    MQTT startup failures are surfaced as runtime exceptions instead of exits.
    """

    class FakeClient:
        def __init__(self, **kwargs):
            self.connected_flag = False

        def enable_logger(self):
            return None

        def reconnect_delay_set(self, min_delay, max_delay):
            return None

        def loop_start(self):
            return None

        def loop_stop(self):
            return None

        def connect(self, host, port):
            raise runtime.mqtt.socket.error("boom")

    monkeypatch.setattr(runtime.mqtt, "Client", FakeClient)
    monkeypatch.setattr(runtime.time, "sleep", lambda _: None)

    args = SimpleNamespace(mqtt_host="mqtt.example", mqtt_port=1884)

    try:
        runtime.open_mqtt_connection(args)
    except runtime.MqttConnectionError as error:
        assert "Unable to connect to MQTT host mqtt.example:1884" == str(error)
    else:
        raise AssertionError("MqttConnectionError was not raised")


def test_open_mqtt_connection_raises_on_broker_rejection(monkeypatch):
    """
    MQTT broker rejections fail startup instead of hanging indefinitely.
    """

    class FakeClient:
        def __init__(self, **kwargs):
            self.connected_flag = False
            self.connect_error = None

        def enable_logger(self):
            return None

        def reconnect_delay_set(self, min_delay, max_delay):
            return None

        def loop_start(self):
            return None

        def loop_stop(self):
            return None

        def connect(self, host, port):
            runtime.on_connect(self, None, None, 5, None)

    monkeypatch.setattr(runtime.mqtt, "Client", FakeClient)
    monkeypatch.setattr(runtime.time, "sleep", lambda _: None)

    args = SimpleNamespace(mqtt_host="mqtt.example", mqtt_port=1884)

    with pytest.raises(runtime.MqttConnectionError) as error:
        runtime.open_mqtt_connection(args)

    assert "reason code 5" in str(error.value)


def test_open_mqtt_connection_raises_on_timeout(monkeypatch):
    """
    MQTT startup times out when the callback never reports success or failure.
    """
    monotonic_values = iter([0, 10, 20, 31])

    class FakeClient:
        def __init__(self, **kwargs):
            self.connected_flag = False
            self.connect_error = None

        def enable_logger(self):
            return None

        def reconnect_delay_set(self, min_delay, max_delay):
            return None

        def loop_start(self):
            return None

        def loop_stop(self):
            return None

        def connect(self, host, port):
            return None

    monkeypatch.setattr(runtime.mqtt, "Client", FakeClient)
    monkeypatch.setattr(runtime.time, "sleep", lambda _: None)
    monkeypatch.setattr(runtime.time, "monotonic", lambda: next(monotonic_values))

    args = SimpleNamespace(mqtt_host="mqtt.example", mqtt_port=1884)

    with pytest.raises(runtime.MqttConnectionError) as error:
        runtime.open_mqtt_connection(args)

    assert "Timed out waiting" in str(error.value)


def test_on_connect_logs_reason_code_objects_without_crashing(caplog):
    """
    Successful MQTT connects must tolerate ReasonCode-like callback objects.
    """

    class FakeReasonCode:
        def __eq__(self, other):
            return other == 0

        def __str__(self):
            return "Success"

    client = SimpleNamespace(connected_flag=False, connect_error="previous")

    with caplog.at_level("INFO"):
        runtime.on_connect(client, None, None, FakeReasonCode(), None)

    assert client.connected_flag is True
    assert client.connect_error is None
    assert caplog.records[0].event == "mqtt_connected"
    assert caplog.records[0].mqtt_reason_code == "Success"


def test_open_receiver_connection_rejects_incompatible_explicit_port(monkeypatch):
    """
    Explicit ports must still validate as compatible receivers.
    """

    class FakeSerial:
        def __init__(self):
            self.closed = False
            self.name = "/dev/cu.usbserial-test"

        def close(self):
            self.closed = True

    fake_serial = FakeSerial()
    args = SimpleNamespace(
        serial_port="/dev/cu.usbserial-test",
        baudrate=9600,
        bytesize=8,
        parity="N",
        stopbits=1,
        serial_timeout=1,
        scl_address=126,
    )

    monkeypatch.setattr(runtime, "_create_serial_handle", lambda *_args: fake_serial)
    monkeypatch.setattr(runtime.scl, "get_receiver_type", lambda *_args: None)

    receiver = runtime.open_receiver_connection(args)

    assert receiver is None
    assert fake_serial.closed is True


def test_open_receiver_connection_raises_receiver_error_for_open_failure(monkeypatch):
    """
    Explicit-port failures are surfaced as runtime exceptions instead of exits.
    """
    args = SimpleNamespace(
        serial_port="/dev/cu.usbserial-test",
        baudrate=9600,
        bytesize=8,
        parity="N",
        stopbits=1,
        serial_timeout=1,
        scl_address=126,
    )

    def raise_serial_error(*_args):
        raise runtime.serial.serialutil.SerialException("boom")

    monkeypatch.setattr(runtime, "_create_serial_handle", raise_serial_error)

    try:
        runtime.open_receiver_connection(args)
    except runtime.ReceiverConnectionError as error:
        assert "Unable to open serial port /dev/cu.usbserial-test" == str(error)
    else:
        raise AssertionError("ReceiverConnectionError was not raised")


def test_bridge_table_output_requires_tty(monkeypatch):
    """
    Table mode is rejected when stdout is not an interactive terminal.
    """
    monkeypatch.setattr(runtime.sys.stdout, "isatty", lambda: False)

    with pytest.raises(runtime.OutputModeError) as error:
        runtime.MtrBridge(SimpleNamespace(scl_address=126, output="table"))

    assert "interactive terminal" in str(error.value)


def test_recover_receiver_connection_rediscovery_finds_replugged_receiver(monkeypatch):
    """
    Autodetect mode rescans for a receiver when reopening the old port fails.
    """

    class ExistingSerial:
        def __init__(self):
            self.port = "/dev/cu.usbserial-old"
            self.closed = False

        def close(self):
            self.closed = True

    class ReopenAttempt:
        def __init__(self):
            self.port = None

        def apply_settings(self, _settings):
            pass

        def open(self):
            raise FileNotFoundError("device disappeared")

    rediscovered_receiver = runtime.ReceiverConnection(
        serial_handle=SimpleNamespace(port="/dev/cu.usbserial-new"),
        device_type="RTR970",
        receiver_serial_number="RTR970456",
        serial_config={"baudrate": 9600},
    )
    current_receiver = runtime.ReceiverConnection(
        serial_handle=ExistingSerial(),
        device_type="RTR970",
        receiver_serial_number="RTR970123",
        serial_config={"baudrate": 9600},
    )

    monkeypatch.setattr(runtime.serial, "Serial", ReopenAttempt)
    monkeypatch.setattr(
        runtime,
        "open_receiver_connection",
        lambda _args: rediscovered_receiver,
    )

    recovered = runtime.recover_receiver_connection(
        current_receiver,
        SimpleNamespace(serial_port=None, scl_address=126),
    )

    assert current_receiver.serial_handle.closed is True
    assert recovered is rediscovered_receiver


def test_publish_measurement_skips_while_mqtt_is_disconnected():
    """
    Measurements are skipped cleanly when MQTT is temporarily disconnected.
    """
    client = SimpleNamespace(connected_flag=False)

    result, mid = runtime.publish_measurement(
        client,
        "RTR970123",
        '{"id": "15006", "reading": 22.9}',
    )

    assert result == runtime.mqtt.MQTT_ERR_NO_CONN
    assert mid is None


def test_publish_measurement_publishes_discovery_first():
    """
    Measurement publishing keeps the normal state topic and publishes discovery first.
    """

    class FakeClient:
        def __init__(self):
            self.calls = []

        def publish(self, topic, **kwargs):
            self.calls.append((topic, kwargs))
            return (0, len(self.calls))

    client = FakeClient()
    publisher = runtime.homeassistant.DiscoveryPublisher("homeassistant", retain=True)
    measurement_json = (
        '{"id":"15006","type":"FT10","reading":22.9,"battery":2.6,"rsl":-69}'
    )

    result, mid = runtime.publish_measurement(
        client,
        "RTR970123",
        measurement_json,
        ha_discovery_publisher=publisher,
    )

    assert result == 0
    assert mid == 2
    assert client.calls[0][0] == "homeassistant/device/15006/config"
    assert client.calls[0][1]["qos"] == 1
    assert client.calls[0][1]["retain"] is True
    assert client.calls[1][0] == "measurements/RTR970123/15006"
    assert client.calls[1][1]["payload"] == measurement_json
    assert client.calls[1][1]["retain"] is False


def test_publish_measurement_rejects_invalid_json_payload():
    """
    Invalid measurement payloads are skipped instead of raising.
    """
    client = SimpleNamespace(connected_flag=True)

    result, mid = runtime.publish_measurement(client, "RTR970123", "{")

    assert result == runtime.mqtt.MQTT_ERR_INVAL
    assert mid is None


def test_publish_measurement_handles_publish_exceptions():
    """
    MQTT publish exceptions are converted to a failed publish result.
    """

    class FakeClient:
        connected_flag = True

        def publish(self, *args, **kwargs):
            raise RuntimeError("boom")

    result, mid = runtime.publish_measurement(
        FakeClient(),
        "RTR970123",
        '{"id": "15006", "reading": 22.9}',
    )

    assert result == runtime.mqtt.MQTT_ERR_NO_CONN
    assert mid is None


def test_publish_measurement_without_discovery_keeps_normal_publish_behavior():
    """
    Measurement publishing still works unchanged when discovery is disabled.
    """

    class FakeClient:
        def __init__(self):
            self.calls = []

        def publish(self, topic, **kwargs):
            self.calls.append((topic, kwargs))
            return (0, 1)

    client = FakeClient()
    measurement_json = (
        '{"id":"15006","type":"FT10","reading":22.9,"battery":2.6,"rsl":-69}'
    )

    result, mid = runtime.publish_measurement(
        client,
        "RTR970123",
        measurement_json,
        ha_discovery_publisher=None,
    )

    assert result == 0
    assert mid == 1
    assert client.calls == [
        (
            "measurements/RTR970123/15006",
            {"payload": measurement_json, "qos": 1, "retain": False},
        )
    ]


def test_publish_measurement_sanitizes_topic_fragments():
    """
    Crafted receiver or sensor ids cannot publish outside the measurement namespace.
    """

    class FakeClient:
        def __init__(self):
            self.calls = []

        def publish(self, topic, **kwargs):
            self.calls.append((topic, kwargs))
            return (0, 1)

    client = FakeClient()

    result, mid = runtime.publish_measurement(
        client,
        "RTR/970+#",
        '{"id":"15/006+#","type":"FT10","reading":22.9,"battery":2.6,"rsl":-69}',
        ha_discovery_publisher=None,
    )

    assert result == 0
    assert mid == 1
    assert client.calls[0][0] == "measurements/RTR_970/15_006"


def test_publish_status_uses_retained_status_topic_payload():
    """
    Status publishing is retained and separate from measurement publishing.
    """

    class FakeClient:
        def __init__(self):
            self.calls = []

        def publish(self, topic, **kwargs):
            self.calls.append((topic, kwargs))
            return (0, 1)

    client = FakeClient()
    payload = {
        "entity_type": "sensor",
        "receiver": "RTR970123",
        "sensor": "15006",
        "status": "online",
        "status_code": 1,
        "last_received_at": "2026-04-26T10:15:32Z",
        "last_publish_at": "2026-04-26T10:15:33Z",
        "error_count": 0,
    }

    result, mid = runtime.publish_status(
        client,
        "status/RTR970123/15006",
        payload,
    )

    assert result == 0
    assert mid == 1
    assert client.calls[0][0] == "status/RTR970123/15006"
    assert client.calls[0][1]["qos"] == 1
    assert client.calls[0][1]["retain"] is True
    assert json.loads(client.calls[0][1]["payload"]) == payload


def test_publish_summary_uses_retained_receiver_summary_topic():
    """
    Summary publishing is retained and separate from measurements and status.
    """

    class FakeClient:
        def __init__(self):
            self.calls = []

        def publish(self, topic, **kwargs):
            self.calls.append((topic, kwargs))
            return (0, 1)

    client = FakeClient()
    payload = {
        "receiver": "RTR970123",
        "updated_at": "2026-04-26T12:00:00Z",
        "transmitters": {
            "15006": {
                "value": 22.9,
                "battery": 2.6,
                "measured_at": "2026-04-26T10:15:32Z",
                "status": "online",
                "status_code": 1,
            },
        },
    }

    result, mid = runtime.publish_summary(client, "RTR970123", payload)

    assert result == 0
    assert mid == 1
    assert client.calls[0][0] == "summary/RTR970123"
    assert client.calls[0][1]["qos"] == 1
    assert client.calls[0][1]["retain"] is True
    assert json.loads(client.calls[0][1]["payload"]) == payload


def test_bridge_publishes_measurement_unchanged_and_retained_status(monkeypatch):
    """
    Bridge status publishing is additive and does not alter measurement payloads.
    """

    class FakeClient:
        def __init__(self):
            self.calls = []

        def publish(self, topic, **kwargs):
            self.calls.append((topic, kwargs))
            return (0, len(self.calls))

    observed_at = datetime(2026, 4, 26, 10, 15, 32, tzinfo=timezone.utc)
    published_at = datetime(2026, 4, 26, 10, 15, 33, tzinfo=timezone.utc)
    times = iter([observed_at, published_at, published_at])
    measurement_json = '{"id":"15006","reading":22.9}'
    bridge = runtime.MtrBridge(SimpleNamespace(scl_address=126, offline_timeout=1800))
    bridge.receiver = runtime.ReceiverConnection(
        serial_handle=SimpleNamespace(),
        device_type="RTR970",
        receiver_serial_number="RTR970123",
        serial_config={},
    )
    bridge.mqtt_client = FakeClient()

    monkeypatch.setattr(runtime.status, "utc_now", lambda: next(times))

    measurement = json.loads(measurement_json)
    receiver = bridge.receiver.receiver_serial_number
    bridge.status_tracker.record_observation(receiver, measurement["id"], observed_at)
    result, _mid = bridge.publish_measurement(measurement_json)
    if result == runtime.mqtt.MQTT_ERR_SUCCESS:
        bridge.status_tracker.record_publish_success(
            receiver,
            measurement["id"],
            published_at,
        )
    bridge.publish_status_changes()

    assert bridge.mqtt_client.calls[0] == (
        "measurements/RTR970123/15006",
        {"payload": measurement_json, "qos": 1, "retain": False},
    )
    status_topics = [topic for topic, _kwargs in bridge.mqtt_client.calls[1:]]
    assert status_topics == ["status/RTR970123", "status/RTR970123/15006"]
    for _topic, kwargs in bridge.mqtt_client.calls[1:]:
        assert kwargs["retain"] is True
        payload = json.loads(kwargs["payload"])
        assert payload["status"] == "online"
        assert payload["status_code"] == 1


def test_bridge_coalesces_summary_publish_without_changing_existing_topics():
    """
    Rapid measurement updates become one retained summary after debounce.
    """

    class FakeClient:
        def __init__(self):
            self.calls = []

        def publish(self, topic, **kwargs):
            self.calls.append((topic, kwargs))
            return (0, len(self.calls))

    measurement_one = {
        "id": "15006",
        "reading": 22.9,
        "battery": 2.6,
        "timestamp": "2026-04-26T10:15:32Z",
        "location": "Technical room",
        "description": "Floor heating input",
        "unit": "°C",
        "quantity": "Temperature",
        "zone": "Heating",
    }
    measurement_two = {
        "id": "15007",
        "reading": 48.1,
        "timestamp": "2026-04-26T10:15:33Z",
    }
    bridge = runtime.MtrBridge(
        SimpleNamespace(
            scl_address=126,
            offline_timeout=1800,
            summary_debounce_seconds=5,
        )
    )
    bridge.receiver = runtime.ReceiverConnection(
        serial_handle=SimpleNamespace(),
        device_type="RTR970",
        receiver_serial_number="RTR970123",
        serial_config={},
    )
    bridge.mqtt_client = FakeClient()
    receiver = bridge.receiver.receiver_serial_number

    bridge.summary_tracker._monotonic = lambda: 0
    for measurement in [measurement_one, measurement_two]:
        bridge.status_tracker.record_observation(
            receiver,
            measurement["id"],
            datetime(2026, 4, 26, 10, 15, 33, tzinfo=timezone.utc),
        )
        bridge.summary_tracker.record_measurement(
            receiver,
            measurement,
            bridge.status_tracker.sensor_payload(
                receiver,
                measurement["id"],
                datetime(2026, 4, 26, 10, 15, 33, tzinfo=timezone.utc),
            ),
        )
        bridge.publish_measurement(json.dumps(measurement))
        bridge.publish_due_summaries(
            datetime(2026, 4, 26, 10, 15, 34, tzinfo=timezone.utc),
        )

    assert [topic for topic, _kwargs in bridge.mqtt_client.calls] == [
        "measurements/RTR970123/15006",
        "measurements/RTR970123/15007",
    ]

    bridge.summary_tracker._monotonic = lambda: 5
    bridge.publish_due_summaries(
        datetime(2026, 4, 26, 10, 15, 38, tzinfo=timezone.utc),
    )

    assert [topic for topic, _kwargs in bridge.mqtt_client.calls] == [
        "measurements/RTR970123/15006",
        "measurements/RTR970123/15007",
        "summary/RTR970123",
    ]
    summary_payload = json.loads(bridge.mqtt_client.calls[-1][1]["payload"])
    assert bridge.mqtt_client.calls[-1][1]["retain"] is True
    assert set(summary_payload["transmitters"]) == {"15006", "15007"}
    assert summary_payload["transmitters"]["15006"]["value"] == 22.9
    assert summary_payload["transmitters"]["15006"]["battery"] == 2.6
    assert summary_payload["transmitters"]["15006"]["status"] == "online"
    assert summary_payload["transmitters"]["15006"]["status_code"] == 1
    assert summary_payload["transmitters"]["15006"]["location"] == "Technical room"


def test_bridge_summary_updates_status_to_offline_without_clearing_value():
    """
    Offline status transitions update summary availability only.
    """

    class FakeClient:
        def __init__(self):
            self.calls = []

        def publish(self, topic, **kwargs):
            self.calls.append((topic, kwargs))
            return (0, len(self.calls))

    bridge = runtime.MtrBridge(
        SimpleNamespace(
            scl_address=126,
            offline_timeout=60,
            summary_debounce_seconds=5,
        )
    )
    bridge.receiver = runtime.ReceiverConnection(
        serial_handle=SimpleNamespace(),
        device_type="RTR970",
        receiver_serial_number="RTR970123",
        serial_config={},
    )
    bridge.mqtt_client = FakeClient()
    receiver = bridge.receiver.receiver_serial_number
    observed_at = datetime(2026, 4, 26, 10, 15, 32, tzinfo=timezone.utc)
    offline_at = datetime(2026, 4, 26, 10, 16, 33, tzinfo=timezone.utc)

    bridge.summary_tracker._monotonic = lambda: 0
    bridge.status_tracker.record_observation(receiver, "15006", observed_at)
    bridge.summary_tracker.record_measurement(
        receiver,
        {
            "id": "15006",
            "reading": 22.9,
            "battery": 2.6,
            "timestamp": "2026-04-26T10:15:32Z",
        },
        bridge.status_tracker.sensor_payload(receiver, "15006", observed_at),
    )
    bridge.publish_status_changes(observed_at)
    bridge.summary_tracker._monotonic = lambda: 5
    bridge.publish_due_summaries(observed_at)

    bridge.summary_tracker._monotonic = lambda: 10
    bridge.publish_status_changes(offline_at)
    bridge.summary_tracker._monotonic = lambda: 15
    bridge.publish_due_summaries(offline_at)

    summary_payloads = [
        json.loads(kwargs["payload"])
        for topic, kwargs in bridge.mqtt_client.calls
        if topic == "summary/RTR970123"
    ]
    assert len(summary_payloads) == 2
    entry = summary_payloads[-1]["transmitters"]["15006"]
    assert entry["value"] == 22.9
    assert entry["battery"] == 2.6
    assert entry["measured_at"] == "2026-04-26T10:15:32Z"
    assert entry["status"] == "offline"
    assert entry["status_code"] == 0


def test_log_measurement_adds_structured_measurement_payload(caplog):
    """
    Measurement logs carry the parsed payload as structured data.
    """
    with caplog.at_level("INFO"):
        runtime.log_measurement('{"id":"15006","reading":22.9,"location":"Kids room"}')

    assert caplog.records[0].event == "measurement_received"
    assert caplog.records[0].measurement["id"] == "15006"
    assert caplog.records[0].measurement["location"] == "Kids room"


def test_build_receiver_connection_logs_structured_receiver_details(monkeypatch, caplog):
    """
    Receiver connection logs expose the device and serial identity as fields.
    """

    class FakeSerial:
        name = "/dev/cu.usbserial-test"

        def get_settings(self):
            return {"baudrate": 9600}

    monkeypatch.setattr(runtime, "_read_receiver_serial_number", lambda *_args: "A118636")

    with caplog.at_level("INFO"):
        receiver = runtime._build_receiver_connection(
            FakeSerial(),
            SimpleNamespace(scl_address=126),
            "RTR970 V3.0",
        )

    assert receiver.receiver_serial_number == "A118636"
    assert caplog.records[0].event == "receiver_connected"
    assert caplog.records[0].device_type == "RTR970 V3.0"
    assert caplog.records[0].serial_port == "/dev/cu.usbserial-test"


def test_bridge_recovers_and_uses_refreshed_receiver_serial_number(monkeypatch):
    """
    After serial recovery, publishes use the refreshed receiver serial number.
    """

    class BrokenSerial:
        port = "/dev/cu.usbserial-old"
        name = port

        def write(self, _command):
            raise OSError("Device not configured")

        def close(self):
            pass

    old_receiver = runtime.ReceiverConnection(
        serial_handle=BrokenSerial(),
        device_type="RTR970",
        receiver_serial_number="RTR970123",
        serial_config={"baudrate": 9600},
    )
    new_receiver = runtime.ReceiverConnection(
        serial_handle=SimpleNamespace(name="/dev/cu.usbserial-new"),
        device_type="RTR970",
        receiver_serial_number="RTR970456",
        serial_config={"baudrate": 9600},
    )
    args = SimpleNamespace(scl_address=126, serial_port="/dev/cu.usbserial-old")
    bridge = runtime.MtrBridge(args)
    bridge.receiver = old_receiver
    bridge.mqtt_client = object()

    captured = {}

    monkeypatch.setattr(runtime.time, "sleep", lambda _: None)
    monkeypatch.setattr(
        runtime,
        "recover_receiver_connection",
        lambda receiver, _args: new_receiver,
    )
    monkeypatch.setattr(
        runtime,
        "publish_measurement",
        lambda _client, receiver_serial_number, _json, ha_discovery_publisher=None: (
            captured.setdefault("receiver_serial_number", receiver_serial_number),
            None,
        ),
    )

    result = bridge.poll_once()

    assert result.state is runtime.BridgeState.RECOVERING
    assert result.measurement_json is None
    assert bridge.receiver is new_receiver
    assert bridge.state is runtime.BridgeState.READY

    bridge.publish_measurement('{"id":"15006","reading":22.9}')

    assert captured["receiver_serial_number"] == "RTR970456"


def test_poll_once_returns_waiting_state_when_no_receiver_is_available(monkeypatch):
    """
    Polling exposes the no-receiver case explicitly.
    """
    args = SimpleNamespace(scl_address=126, serial_port=None)
    bridge = runtime.MtrBridge(args)

    monkeypatch.setattr(runtime, "open_receiver_connection", lambda _args: None)

    result = bridge.poll_once()

    assert result.state is runtime.BridgeState.WAITING_FOR_RECEIVER
    assert result.measurement_json is None
    assert bridge.state is runtime.BridgeState.WAITING_FOR_RECEIVER


def test_poll_once_returns_idle_for_empty_ring_buffer(monkeypatch):
    """
    Polling exposes an empty receiver buffer as an idle cycle.
    """

    class FakeSerial:
        name = "/dev/cu.usbserial-test"

        def write(self, _command):
            return None

        def read_until(self, _end):
            return b"\x80#\x03"

        def read(self, _size):
            return runtime.scl.calc_bcc(b"\x80#\x03")

    args = SimpleNamespace(scl_address=126)
    bridge = runtime.MtrBridge(args)
    bridge.receiver = runtime.ReceiverConnection(
        serial_handle=FakeSerial(),
        device_type="RTR970",
        receiver_serial_number="RTR970123",
        serial_config={"baudrate": 9600},
    )

    result = bridge.poll_once()

    assert result.state is runtime.BridgeState.IDLE
    assert result.measurement_json is None
    assert bridge.state is runtime.BridgeState.IDLE


def test_poll_once_returns_measurement_payload_when_data_is_available(monkeypatch):
    """
    Polling exposes parsed measurements explicitly instead of overloading None.
    """

    class FakeSerial:
        name = "/dev/cu.usbserial-test"

        def write(self, _command):
            return None

        def read_until(self, _end):
            return b"\x800 90 58 15006 145 11\x03"

        def read(self, _size):
            return runtime.scl.calc_bcc(b"\x800 90 58 15006 145 11\x03")

    args = SimpleNamespace(scl_address=126)
    bridge = runtime.MtrBridge(args)
    bridge.receiver = runtime.ReceiverConnection(
        serial_handle=FakeSerial(),
        device_type="RTR970",
        receiver_serial_number="RTR970123",
        serial_config={"baudrate": 9600},
    )

    result = bridge.poll_once()

    assert result.state is runtime.BridgeState.READY
    assert result.measurement_json is not None
    assert '"id": "15006"' in result.measurement_json
    assert bridge.state is runtime.BridgeState.READY


def test_poll_once_skips_measurements_missing_from_metadata_when_enabled(caplog):
    """
    Metadata-only mode drops unmatched transmitters before any view or publish path.
    """

    class FakeSerial:
        name = "/dev/cu.usbserial-test"

        def write(self, _command):
            return None

        def read_until(self, _end):
            return b"\x800 90 58 15006 145 11\x03"

        def read(self, _size):
            return runtime.scl.calc_bcc(b"\x800 90 58 15006 145 11\x03")

    args = SimpleNamespace(
        scl_address=126,
        metadata_transmitters_only=True,
    )
    bridge = runtime.MtrBridge(
        args,
        transmitters_metadata=json.dumps([{"id": 99999, "location": "Elsewhere"}]),
    )
    bridge.receiver = runtime.ReceiverConnection(
        serial_handle=FakeSerial(),
        device_type="RTR970",
        receiver_serial_number="RTR970123",
        serial_config={"baudrate": 9600},
    )

    with caplog.at_level("DEBUG"):
        result = bridge.poll_once()

    assert result.state is runtime.BridgeState.READY
    assert result.measurement_json is None
    assert bridge.state is runtime.BridgeState.READY
    assert caplog.records[-1].event == "measurement_skipped_unconfigured"
    assert caplog.records[-1].measurement["id"] == "15006"


def test_bridge_start_raises_receiver_error_when_no_receiver_is_found(monkeypatch):
    """
    Bridge startup reports missing receivers as a runtime exception.
    """
    args = SimpleNamespace(scl_address=126)
    bridge = runtime.MtrBridge(args)

    monkeypatch.setattr(runtime, "open_receiver_connection", lambda _args: None)

    try:
        bridge.start()
    except runtime.ReceiverConnectionError as error:
        assert "Unable to find MTR receivers" == str(error)
    else:
        raise AssertionError("ReceiverConnectionError was not raised")
