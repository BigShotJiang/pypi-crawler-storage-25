"""Tests for IO module."""
