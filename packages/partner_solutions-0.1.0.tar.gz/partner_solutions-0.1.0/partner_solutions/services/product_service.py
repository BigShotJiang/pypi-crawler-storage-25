from __future__ import annotations

from decimal import Decimal
from typing import Any

from ..repositories.product_repository import ProductRepository


class ProductService:
    def __init__(self, repository: ProductRepository) -> None:
        self.repository = repository

    def get_products(self) -> list[dict[str, Any]]:
        return self.repository.fetch_products()

    def get_product(self, product_id: int) -> dict[str, Any] | None:
        return self.repository.fetch_product_by_id(product_id)

    @staticmethod
    def format_partner_price(value: Any) -> str:
        return f"{Decimal(str(value)):.2f}"
