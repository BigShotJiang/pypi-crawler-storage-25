from __future__ import annotations

from ..repositories.material_repository import MaterialRepository
from ..services.material_calculator import MaterialCalculator


class MaterialService:
    def __init__(self, repository: MaterialRepository) -> None:
        self.repository = repository

    def get_materials(self) -> list[dict]:
        return self.repository.fetch_materials()

    def get_material(self, material_id: int) -> dict | None:
        return self.repository.fetch_material_by_id(material_id)

    def calculate_material_need(
        self,
        *,
        product_type_coefficient: float,
        material_defect_rate: float,
        product_quantity: int,
        parameter_1: float,
        parameter_2: float,
    ) -> int:
        return MaterialCalculator.calculate_required_material(
            product_type_coefficient=product_type_coefficient,
            material_defect_rate=material_defect_rate,
            product_quantity=product_quantity,
            parameter_1=parameter_1,
            parameter_2=parameter_2,
        )
