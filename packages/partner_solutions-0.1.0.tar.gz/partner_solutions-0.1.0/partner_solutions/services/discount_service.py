class DiscountService:
    @staticmethod
    def calculate_discount_percent(total_sales_quantity: int) -> int:
        if total_sales_quantity < 0:
            raise ValueError("Total sales quantity cannot be negative.")

        if total_sales_quantity < 10_000:
            return 0
        if total_sales_quantity < 50_000:
            return 5
        if total_sales_quantity < 300_000:
            return 10
        return 15
