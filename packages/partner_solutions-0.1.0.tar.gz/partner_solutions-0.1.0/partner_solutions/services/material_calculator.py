from __future__ import annotations

from decimal import Decimal, ROUND_CEILING


class MaterialCalculator:
    @staticmethod
    def calculate_required_material(
        product_type_coefficient: float | Decimal,
        material_defect_rate: float | Decimal,
        product_quantity: int,
        parameter_1: float | Decimal,
        parameter_2: float | Decimal,
    ) -> int:
        if product_quantity <= 0:
            return -1

        coefficient = Decimal(str(product_type_coefficient))
        defect_rate = Decimal(str(material_defect_rate))
        param_1 = Decimal(str(parameter_1))
        param_2 = Decimal(str(parameter_2))

        if coefficient <= 0 or defect_rate < 0 or param_1 <= 0 or param_2 <= 0:
            return -1

        material_per_unit = param_1 * param_2 * coefficient
        total_material = material_per_unit * Decimal(product_quantity)
        total_with_defect = total_material * (Decimal("1") + defect_rate)

        return int(total_with_defect.quantize(Decimal("1"), rounding=ROUND_CEILING))
