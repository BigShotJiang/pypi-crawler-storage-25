from __future__ import annotations

from typing import Any

from ..repositories.partner_repository import PartnerRepository
from ..services.discount_service import DiscountService
from ..utils.validators import validate_inn, validate_rating


class PartnerService:
    def __init__(self, repository: PartnerRepository) -> None:
        self.repository = repository

    def get_partner_cards(self) -> list[dict[str, Any]]:
        partners = self.repository.fetch_partner_list()
        result: list[dict[str, Any]] = []

        for partner in partners:
            total_sales_quantity = int(partner["total_sales_quantity"])
            result.append(
                {
                    **partner,
                    "discount_percent": DiscountService.calculate_discount_percent(total_sales_quantity),
                }
            )

        return result

    def get_partner_sales_history(self, partner_id: int) -> list[dict[str, Any]]:
        return self.repository.fetch_partner_sales_history(partner_id)

    def create_partner(
        self,
        *,
        partner_type_id: int,
        name: str,
        director_name: str,
        email: str | None,
        phone: str | None,
        legal_address: str | None,
        inn: str,
        rating: int,
    ) -> int:
        validate_inn(inn)
        validate_rating(rating)
        return self.repository.insert_partner(
            partner_type_id=partner_type_id,
            name=name,
            director_name=director_name,
            email=email,
            phone=phone,
            legal_address=legal_address,
            inn=inn,
            rating=rating,
        )

    def update_partner(
        self,
        partner_id: int,
        *,
        partner_type_id: int,
        name: str,
        director_name: str,
        email: str | None,
        phone: str | None,
        legal_address: str | None,
        inn: str,
        rating: int,
    ) -> None:
        validate_inn(inn)
        validate_rating(rating)
        self.repository.update_partner(
            partner_id=partner_id,
            partner_type_id=partner_type_id,
            name=name,
            director_name=director_name,
            email=email,
            phone=phone,
            legal_address=legal_address,
            inn=inn,
            rating=rating,
        )
