from __future__ import annotations

from ..repositories.sale_repository import SaleRepository


class SaleService:
    def __init__(self, repository: SaleRepository) -> None:
        self.repository = repository

    def add_sale(self, partner_id: int, product_id: int, quantity: int, sale_date: str) -> int:
        if quantity <= 0:
            raise ValueError("Quantity must be greater than zero.")
        return self.repository.insert_sale(
            partner_id=partner_id,
            product_id=product_id,
            quantity=quantity,
            sale_date=sale_date,
        )
