from __future__ import annotations

from importlib.resources import files

from ..database import DatabaseManager


def bootstrap_database() -> None:
    database = DatabaseManager()
    schema_path = files("partner_solutions.sql").joinpath("schema.sql")
    seed_path = files("partner_solutions.sql").joinpath("seed.sql")

    database.execute_sql_file(schema_path, use_server_connection=True)
    database.execute_sql_file(seed_path, use_server_connection=False)
