from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal


@dataclass(slots=True)
class PartnerType:
    id: int | None
    name: str


@dataclass(slots=True)
class Partner:
    id: int | None
    partner_type_id: int
    name: str
    director_name: str
    email: str | None
    phone: str | None
    legal_address: str | None
    inn: str
    rating: int


@dataclass(slots=True)
class ProductType:
    id: int | None
    name: str
    type_coefficient: Decimal


@dataclass(slots=True)
class Product:
    id: int | None
    product_type_id: int
    name: str
    article: str
    min_partner_price: Decimal


@dataclass(slots=True)
class MaterialType:
    id: int | None
    name: str
    defect_rate: Decimal


@dataclass(slots=True)
class Material:
    id: int | None
    material_type_id: int
    name: str
    unit: str | None
    stock_quantity: Decimal
    min_quantity: Decimal
    price: Decimal | None
    description: str | None


@dataclass(slots=True)
class PartnerProductSale:
    id: int | None
    partner_id: int
    product_id: int
    quantity: int
    sale_date: date
