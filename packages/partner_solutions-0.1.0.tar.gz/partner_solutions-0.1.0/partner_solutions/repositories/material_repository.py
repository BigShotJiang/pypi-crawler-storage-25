from __future__ import annotations

from typing import Any


class MaterialRepository:
    def __init__(self, connection: Any) -> None:
        self.connection = connection

    def fetch_materials(self) -> list[dict[str, Any]]:
        query = """
        SELECT
            m.id,
            mt.name AS material_type,
            m.name,
            m.unit,
            m.stock_quantity,
            m.min_quantity,
            m.price,
            m.description,
            mt.defect_rate
        FROM materials m
        JOIN material_types mt ON mt.id = m.material_type_id
        ORDER BY m.name;
        """
        cursor = self.connection.cursor(dictionary=True)
        cursor.execute(query)
        rows = cursor.fetchall()
        cursor.close()
        return rows

    def fetch_material_by_id(self, material_id: int) -> dict[str, Any] | None:
        query = """
        SELECT
            m.id,
            m.material_type_id,
            mt.name AS material_type,
            m.name,
            m.unit,
            m.stock_quantity,
            m.min_quantity,
            m.price,
            m.description,
            mt.defect_rate
        FROM materials m
        JOIN material_types mt ON mt.id = m.material_type_id
        WHERE m.id = %s
        """
        cursor = self.connection.cursor(dictionary=True)
        cursor.execute(query, (material_id,))
        row = cursor.fetchone()
        cursor.close()
        return row
