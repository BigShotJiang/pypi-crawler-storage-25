from .material_repository import MaterialRepository
from .partner_repository import PartnerRepository
from .product_repository import ProductRepository
from .sale_repository import SaleRepository

__all__ = [
    "MaterialRepository",
    "PartnerRepository",
    "ProductRepository",
    "SaleRepository",
]
