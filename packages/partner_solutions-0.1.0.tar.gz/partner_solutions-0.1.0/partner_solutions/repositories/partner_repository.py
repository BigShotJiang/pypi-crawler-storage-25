from __future__ import annotations

from typing import Any


class PartnerRepository:
    def __init__(self, connection: Any) -> None:
        self.connection = connection

    def fetch_partner_list(self) -> list[dict[str, Any]]:
        query = """
        SELECT
            p.id,
            p.partner_type_id,
            pt.name AS partner_type,
            p.name,
            p.director_name,
            p.phone,
            p.email,
            p.legal_address,
            p.inn,
            p.rating,
            COALESCE(SUM(s.quantity), 0) AS total_sales_quantity
        FROM partners p
        JOIN partner_types pt ON pt.id = p.partner_type_id
        LEFT JOIN partner_product_sales s ON s.partner_id = p.id
        GROUP BY
            p.id,
            p.partner_type_id,
            pt.name,
            p.name,
            p.director_name,
            p.phone,
            p.email,
            p.legal_address,
            p.inn,
            p.rating
        ORDER BY p.name;
        """
        cursor = self.connection.cursor(dictionary=True)
        cursor.execute(query)
        rows = cursor.fetchall()
        cursor.close()
        return rows

    def fetch_partner_sales_history(self, partner_id: int) -> list[dict[str, Any]]:
        query = """
        SELECT
            s.id,
            pr.name AS product_name,
            s.quantity,
            s.sale_date
        FROM partner_product_sales s
        JOIN products pr ON pr.id = s.product_id
        WHERE s.partner_id = %s
        ORDER BY s.sale_date DESC, s.id DESC;
        """
        cursor = self.connection.cursor(dictionary=True)
        cursor.execute(query, (partner_id,))
        rows = cursor.fetchall()
        cursor.close()
        return rows

    def insert_partner(
        self,
        *,
        partner_type_id: int,
        name: str,
        director_name: str,
        email: str | None,
        phone: str | None,
        legal_address: str | None,
        inn: str,
        rating: int,
    ) -> int:
        query = """
        INSERT INTO partners (
            partner_type_id,
            name,
            director_name,
            email,
            phone,
            legal_address,
            inn,
            rating
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor = self.connection.cursor()
        cursor.execute(
            query,
            (partner_type_id, name, director_name, email, phone, legal_address, inn, rating),
        )
        self.connection.commit()
        partner_id = cursor.lastrowid
        cursor.close()
        return partner_id

    def update_partner(
        self,
        *,
        partner_id: int,
        partner_type_id: int,
        name: str,
        director_name: str,
        email: str | None,
        phone: str | None,
        legal_address: str | None,
        inn: str,
        rating: int,
    ) -> None:
        query = """
        UPDATE partners
        SET
            partner_type_id = %s,
            name = %s,
            director_name = %s,
            email = %s,
            phone = %s,
            legal_address = %s,
            inn = %s,
            rating = %s
        WHERE id = %s
        """
        cursor = self.connection.cursor()
        cursor.execute(
            query,
            (partner_type_id, name, director_name, email, phone, legal_address, inn, rating, partner_id),
        )
        self.connection.commit()
        cursor.close()
