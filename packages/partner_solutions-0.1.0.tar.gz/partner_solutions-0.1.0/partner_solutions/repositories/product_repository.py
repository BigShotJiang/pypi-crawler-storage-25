from __future__ import annotations

from typing import Any


class ProductRepository:
    def __init__(self, connection: Any) -> None:
        self.connection = connection

    def fetch_products(self) -> list[dict[str, Any]]:
        query = """
        SELECT
            p.id,
            pt.name AS product_type,
            p.name,
            p.article,
            p.min_partner_price
        FROM products p
        JOIN product_types pt ON pt.id = p.product_type_id
        ORDER BY p.name;
        """
        cursor = self.connection.cursor(dictionary=True)
        cursor.execute(query)
        rows = cursor.fetchall()
        cursor.close()
        return rows

    def fetch_product_by_id(self, product_id: int) -> dict[str, Any] | None:
        query = """
        SELECT
            p.id,
            p.product_type_id,
            pt.name AS product_type,
            p.name,
            p.article,
            p.min_partner_price
        FROM products p
        JOIN product_types pt ON pt.id = p.product_type_id
        WHERE p.id = %s
        """
        cursor = self.connection.cursor(dictionary=True)
        cursor.execute(query, (product_id,))
        row = cursor.fetchone()
        cursor.close()
        return row
