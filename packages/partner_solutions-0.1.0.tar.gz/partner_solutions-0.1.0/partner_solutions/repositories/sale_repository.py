from __future__ import annotations

from typing import Any


class SaleRepository:
    def __init__(self, connection: Any) -> None:
        self.connection = connection

    def insert_sale(self, partner_id: int, product_id: int, quantity: int, sale_date: str) -> int:
        query = """
        INSERT INTO partner_product_sales (
            partner_id,
            product_id,
            quantity,
            sale_date
        ) VALUES (%s, %s, %s, %s)
        """
        cursor = self.connection.cursor()
        cursor.execute(query, (partner_id, product_id, quantity, sale_date))
        self.connection.commit()
        sale_id = cursor.lastrowid
        cursor.close()
        return sale_id
