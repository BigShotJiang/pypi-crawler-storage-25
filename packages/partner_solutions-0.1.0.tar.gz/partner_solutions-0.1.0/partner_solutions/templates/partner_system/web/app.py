from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from partner_solutions import DatabaseManager
from partner_solutions.repositories import MaterialRepository, PartnerRepository, ProductRepository, SaleRepository
from partner_solutions.services import MaterialService, PartnerService, ProductService, SaleService


BASE_DIR = Path(__file__).resolve().parent
app = FastAPI(title="Partner Solutions")
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

ERROR_MESSAGES = {
    "partner_save_failed": "Не удалось сохранить партнера. Проверь данные и уникальность ИНН/названия.",
    "sale_save_failed": "Не удалось сохранить продажу. Проверь дату, количество и выбранные значения.",
    "material_calc_failed": "Не удалось выполнить расчет материала. Проверь входные параметры.",
}


def get_connection():
    return DatabaseManager().create_connection()


def build_context(request: Request, **kwargs):
    error_code = request.query_params.get("error")
    success = request.query_params.get("success")
    context = {
        "request": request,
        "error_message": ERROR_MESSAGES.get(error_code),
        "success_message": success,
    }
    context.update(kwargs)
    return context


def load_partner_types(connection):
    cursor = connection.cursor(dictionary=True)
    cursor.execute("SELECT id, name FROM partner_types ORDER BY name")
    rows = cursor.fetchall()
    cursor.close()
    return rows


def load_product_types(connection):
    cursor = connection.cursor(dictionary=True)
    cursor.execute("SELECT id, name, type_coefficient FROM product_types ORDER BY name")
    rows = cursor.fetchall()
    cursor.close()
    return rows


@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    connection = get_connection()
    try:
        partner_service = PartnerService(PartnerRepository(connection))
        partners = partner_service.get_partner_cards()
        return templates.TemplateResponse(
            request,
            "partners.html",
            build_context(request, partners=partners, page_title="Партнеры"),
        )
    finally:
        connection.close()


@app.get("/products", response_class=HTMLResponse)
def products_page(request: Request):
    connection = get_connection()
    try:
        product_service = ProductService(ProductRepository(connection))
        return templates.TemplateResponse(
            request,
            "products.html",
            build_context(request, page_title="Продукция", products=product_service.get_products()),
        )
    finally:
        connection.close()


@app.get("/materials", response_class=HTMLResponse)
def materials_page(request: Request):
    connection = get_connection()
    try:
        material_service = MaterialService(MaterialRepository(connection))
        return templates.TemplateResponse(
            request,
            "materials.html",
            build_context(request, page_title="Материалы", materials=material_service.get_materials()),
        )
    finally:
        connection.close()


@app.get("/partners/new", response_class=HTMLResponse)
def new_partner_page(request: Request):
    connection = get_connection()
    try:
        return templates.TemplateResponse(
            request,
            "partner_form.html",
            build_context(
                request,
                page_title="Добавление партнера",
                partner=None,
                partner_types=load_partner_types(connection),
                action="/partners/new",
            ),
        )
    finally:
        connection.close()


@app.post("/partners/new")
def create_partner(
    partner_type_id: int = Form(...),
    name: str = Form(...),
    director_name: str = Form(...),
    email: str = Form(""),
    phone: str = Form(""),
    legal_address: str = Form(""),
    inn: str = Form(...),
    rating: int = Form(...),
):
    connection = get_connection()
    try:
        service = PartnerService(PartnerRepository(connection))
        service.create_partner(
            partner_type_id=partner_type_id,
            name=name,
            director_name=director_name,
            email=email or None,
            phone=phone or None,
            legal_address=legal_address or None,
            inn=inn,
            rating=rating,
        )
    except Exception:
        return RedirectResponse(url="/partners/new?error=partner_save_failed", status_code=303)
    finally:
        connection.close()

    return RedirectResponse(url="/?success=Партнер успешно добавлен", status_code=303)


@app.get("/partners/{partner_id}/edit", response_class=HTMLResponse)
def edit_partner_page(partner_id: int, request: Request):
    connection = get_connection()
    try:
        partner_service = PartnerService(PartnerRepository(connection))
        partner = next((item for item in partner_service.get_partner_cards() if item["id"] == partner_id), None)
        return templates.TemplateResponse(
            request,
            "partner_form.html",
            build_context(
                request,
                page_title="Редактирование партнера",
                partner=partner,
                partner_types=load_partner_types(connection),
                action=f"/partners/{partner_id}/edit",
            ),
        )
    finally:
        connection.close()


@app.post("/partners/{partner_id}/edit")
def update_partner(
    partner_id: int,
    partner_type_id: int = Form(...),
    name: str = Form(...),
    director_name: str = Form(...),
    email: str = Form(""),
    phone: str = Form(""),
    legal_address: str = Form(""),
    inn: str = Form(...),
    rating: int = Form(...),
):
    connection = get_connection()
    try:
        service = PartnerService(PartnerRepository(connection))
        service.update_partner(
            partner_id=partner_id,
            partner_type_id=partner_type_id,
            name=name,
            director_name=director_name,
            email=email or None,
            phone=phone or None,
            legal_address=legal_address or None,
            inn=inn,
            rating=rating,
        )
    except Exception:
        return RedirectResponse(url=f"/partners/{partner_id}/edit?error=partner_save_failed", status_code=303)
    finally:
        connection.close()

    return RedirectResponse(url="/?success=Партнер успешно обновлен", status_code=303)


@app.get("/partners/{partner_id}/sales", response_class=HTMLResponse)
def partner_sales_history(partner_id: int, request: Request):
    connection = get_connection()
    try:
        partner_service = PartnerService(PartnerRepository(connection))
        partner = next((item for item in partner_service.get_partner_cards() if item["id"] == partner_id), None)
        history = partner_service.get_partner_sales_history(partner_id)
        return templates.TemplateResponse(
            request,
            "sales_history.html",
            build_context(request, page_title="История продаж", partner=partner, history=history),
        )
    finally:
        connection.close()


@app.get("/sales/new", response_class=HTMLResponse)
def new_sale_page(request: Request):
    connection = get_connection()
    try:
        partner_service = PartnerService(PartnerRepository(connection))
        product_service = ProductService(ProductRepository(connection))
        return templates.TemplateResponse(
            request,
            "sale_form.html",
            build_context(
                request,
                page_title="Добавление продажи",
                partners=partner_service.get_partner_cards(),
                products=product_service.get_products(),
            ),
        )
    finally:
        connection.close()


@app.post("/sales/new")
def create_sale(
    partner_id: int = Form(...),
    product_id: int = Form(...),
    quantity: int = Form(...),
    sale_date: str = Form(...),
):
    connection = get_connection()
    try:
        service = SaleService(SaleRepository(connection))
        service.add_sale(partner_id, product_id, quantity, sale_date)
    except Exception:
        return RedirectResponse(url="/sales/new?error=sale_save_failed", status_code=303)
    finally:
        connection.close()

    return RedirectResponse(url=f"/partners/{partner_id}/sales?success=Продажа успешно добавлена", status_code=303)


@app.get("/materials/calc", response_class=HTMLResponse)
def material_calc_page(request: Request):
    connection = get_connection()
    try:
        material_service = MaterialService(MaterialRepository(connection))
        return templates.TemplateResponse(
            request,
            "material_calc.html",
            build_context(
                request,
                page_title="Расчет материала",
                materials=material_service.get_materials(),
                product_types=load_product_types(connection),
                result=None,
            ),
        )
    finally:
        connection.close()


@app.post("/materials/calc", response_class=HTMLResponse)
def calculate_material(
    request: Request,
    product_type_coefficient: float = Form(...),
    material_defect_rate: float = Form(...),
    product_quantity: int = Form(...),
    parameter_1: float = Form(...),
    parameter_2: float = Form(...),
):
    connection = get_connection()
    try:
        material_service = MaterialService(MaterialRepository(connection))
        result = material_service.calculate_material_need(
            product_type_coefficient=product_type_coefficient,
            material_defect_rate=material_defect_rate,
            product_quantity=product_quantity,
            parameter_1=parameter_1,
            parameter_2=parameter_2,
        )
        return templates.TemplateResponse(
            request,
            "material_calc.html",
            build_context(
                request,
                page_title="Расчет материала",
                materials=material_service.get_materials(),
                product_types=load_product_types(connection),
                result=result,
                success="Расчет выполнен",
            ),
        )
    except Exception:
        return RedirectResponse(url="/materials/calc?error=material_calc_failed", status_code=303)
    finally:
        connection.close()
