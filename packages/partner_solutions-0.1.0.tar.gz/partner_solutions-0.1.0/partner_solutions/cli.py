from __future__ import annotations

import argparse
import json
from pathlib import Path

from . import DatabaseManager
from .repositories import MaterialRepository, PartnerRepository, ProductRepository, SaleRepository
from .scaffold import create_db_scaffold, create_partner_system_project, create_web_scaffold
from .services import MaterialService, PartnerService, ProductService, SaleService, bootstrap_database


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="olymp")
    subparsers = parser.add_subparsers(dest="command", required=True)

    create_parser = subparsers.add_parser("create")
    create_subparsers = create_parser.add_subparsers(dest="create_target", required=True)

    create_db = create_subparsers.add_parser("db")
    create_db.add_argument("--output", default="./db")
    create_db.add_argument("--template", default="partner-system")

    create_web = create_subparsers.add_parser("web")
    create_web.add_argument("--output", default="./web")
    create_web.add_argument("--template", default="partner-system")

    init_parser = subparsers.add_parser("init")
    init_parser.add_argument("template", choices=["partner-system"])
    init_parser.add_argument("--output", default="./partner-system")

    subparsers.add_parser("init-db")
    subparsers.add_parser("list-partners")
    subparsers.add_parser("list-products")
    subparsers.add_parser("list-materials")

    sales_history = subparsers.add_parser("partner-sales")
    sales_history.add_argument("partner_id", type=int)

    add_sale = subparsers.add_parser("add-sale")
    add_sale.add_argument("partner_id", type=int)
    add_sale.add_argument("product_id", type=int)
    add_sale.add_argument("quantity", type=int)
    add_sale.add_argument("sale_date")

    calculate_material = subparsers.add_parser("calc-material")
    calculate_material.add_argument("product_type_coefficient", type=float)
    calculate_material.add_argument("material_defect_rate", type=float)
    calculate_material.add_argument("product_quantity", type=int)
    calculate_material.add_argument("parameter_1", type=float)
    calculate_material.add_argument("parameter_2", type=float)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "create":
        output = Path(args.output)
        if args.template != "partner-system":
            raise SystemExit("Only template 'partner-system' is currently supported.")

        if args.create_target == "db":
            path = create_db_scaffold(output)
            print(json.dumps({"created": str(path), "type": "db", "template": args.template}, ensure_ascii=False, indent=2))
            return
        if args.create_target == "web":
            path = create_web_scaffold(output)
            print(json.dumps({"created": str(path), "type": "web", "template": args.template}, ensure_ascii=False, indent=2))
            return

    if args.command == "init":
        path = create_partner_system_project(args.output)
        print(json.dumps({"created": str(path), "type": "project", "template": args.template}, ensure_ascii=False, indent=2))
        return

    if args.command == "init-db":
        bootstrap_database()
        print("Database initialized.")
        return

    connection = DatabaseManager().create_connection()
    try:
        if args.command == "list-partners":
            service = PartnerService(PartnerRepository(connection))
            print(json.dumps(service.get_partner_cards(), ensure_ascii=False, default=str, indent=2))
            return

        if args.command == "list-products":
            service = ProductService(ProductRepository(connection))
            print(json.dumps(service.get_products(), ensure_ascii=False, default=str, indent=2))
            return

        if args.command == "list-materials":
            service = MaterialService(MaterialRepository(connection))
            print(json.dumps(service.get_materials(), ensure_ascii=False, default=str, indent=2))
            return

        if args.command == "partner-sales":
            service = PartnerService(PartnerRepository(connection))
            print(json.dumps(service.get_partner_sales_history(args.partner_id), ensure_ascii=False, default=str, indent=2))
            return

        if args.command == "add-sale":
            service = SaleService(SaleRepository(connection))
            sale_id = service.add_sale(args.partner_id, args.product_id, args.quantity, args.sale_date)
            print(json.dumps({"sale_id": sale_id}, ensure_ascii=False, indent=2))
            return

        if args.command == "calc-material":
            service = MaterialService(MaterialRepository(connection))
            result = service.calculate_material_need(
                product_type_coefficient=args.product_type_coefficient,
                material_defect_rate=args.material_defect_rate,
                product_quantity=args.product_quantity,
                parameter_1=args.parameter_1,
                parameter_2=args.parameter_2,
            )
            print(json.dumps({"required_material": result}, ensure_ascii=False, indent=2))
            return
    finally:
        connection.close()


if __name__ == "__main__":
    main()
