from __future__ import annotations

from pathlib import Path
from typing import Any

from .config import DatabaseConfig


class DatabaseError(RuntimeError):
    pass


class DatabaseManager:
    def __init__(self, config: DatabaseConfig | None = None) -> None:
        self.config = config or DatabaseConfig()
        self._driver = None

    def _load_driver(self):
        if self._driver is not None:
            return self._driver

        try:
            import mysql.connector as mysql_connector
        except ImportError as exc:
            raise DatabaseError(
                "mysql-connector-python is not installed. Install it with: pip install mysql-connector-python"
            ) from exc

        self._driver = mysql_connector
        return self._driver

    def create_connection(self) -> Any:
        driver = self._load_driver()
        return driver.connect(
            host=self.config.host,
            port=self.config.port,
            user=self.config.user,
            password=self.config.password,
            database=self.config.database,
        )

    def create_server_connection(self) -> Any:
        driver = self._load_driver()
        return driver.connect(
            host=self.config.host,
            port=self.config.port,
            user=self.config.user,
            password=self.config.password,
        )

    def execute_sql_file(self, sql_file_path: str | Path, *, use_server_connection: bool = False) -> None:
        connection = self.create_server_connection() if use_server_connection else self.create_connection()
        try:
            cursor = connection.cursor()
            sql_text = Path(sql_file_path).read_text(encoding="utf-8")
            for _ in cursor.execute(sql_text, multi=True):
                pass
            connection.commit()
            cursor.close()
        finally:
            connection.close()
