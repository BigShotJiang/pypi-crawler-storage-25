from __future__ import annotations

from pathlib import Path
import shutil


TEMPLATES_ROOT = Path(__file__).resolve().parent / "templates"


def _copy_tree(src: Path, dst: Path) -> Path:
    dst.mkdir(parents=True, exist_ok=True)
    for item in src.iterdir():
        target = dst / item.name
        if item.is_dir():
            if target.exists():
                shutil.rmtree(target)
            shutil.copytree(item, target)
        else:
            shutil.copy2(item, target)
    return dst


def create_db_scaffold(target_dir: str | Path) -> Path:
    template = TEMPLATES_ROOT / "partner_system" / "db"
    target = Path(target_dir)
    return _copy_tree(template, target)


def create_web_scaffold(target_dir: str | Path) -> Path:
    template = TEMPLATES_ROOT / "partner_system" / "web"
    target = Path(target_dir)
    return _copy_tree(template, target)


def create_partner_system_project(target_dir: str | Path) -> Path:
    target = Path(target_dir)
    target.mkdir(parents=True, exist_ok=True)

    create_db_scaffold(target / "db")
    create_web_scaffold(target / "web")

    (target / "README.md").write_text(
        "# partner-system\n\n"
        "Сгенерированный проект конкурсного решения.\n\n"
        "## Структура\n\n"
        "- `db/` — schema.sql и seed.sql\n"
        "- `web/` — FastAPI веб-приложение\n\n"
        "## Быстрый старт\n\n"
        "1. Создай БД из `db/schema.sql`\n"
        "2. Загрузи данные из `db/seed.sql`\n"
        "3. Перейди в `web/`\n"
        "4. Установи зависимости: `pip install -r requirements.txt`\n"
        "5. Запусти: `uvicorn app:app --reload`\n",
        encoding="utf-8",
    )

    return target
