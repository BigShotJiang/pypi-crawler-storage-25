from __future__ import annotations

from dataclasses import dataclass
import os


@dataclass(slots=True)
class DatabaseConfig:
    host: str = os.getenv("PARTNER_SOLUTIONS_DB_HOST", "localhost")
    port: int = int(os.getenv("PARTNER_SOLUTIONS_DB_PORT", "3306"))
    user: str = os.getenv("PARTNER_SOLUTIONS_DB_USER", "root")
    password: str = os.getenv("PARTNER_SOLUTIONS_DB_PASSWORD", "")
    database: str = os.getenv("PARTNER_SOLUTIONS_DB_NAME", "partner_solutions")
