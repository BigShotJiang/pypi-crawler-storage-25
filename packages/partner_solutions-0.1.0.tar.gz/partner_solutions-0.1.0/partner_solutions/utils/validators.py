def validate_rating(rating: int) -> None:
    if rating < 0:
        raise ValueError("Rating must be a non-negative integer.")


def validate_inn(inn: str) -> None:
    if not inn.isdigit() or len(inn) not in (10, 12):
        raise ValueError("INN must contain 10 or 12 digits.")
