# partner-solutions

Python-библиотека под задания из PDF и приложенных материалов.

## Что внутри

- доменные модели партнеров, продукции, материалов и продаж;
- сервис расчета скидки партнера;
- сервис расчета материала с учетом коэффициента типа продукции и процента брака;
- сервисы для партнеров и продаж;
- bootstrap БД из встроенных SQL-скриптов;
- простой слой доступа к MySQL;
- примеры использования.

## Структура

- `partner_solutions/domain` — модели данных
- `partner_solutions/services` — бизнес-логика
- `partner_solutions/repositories` — доступ к БД
- `partner_solutions/sql` — SQL-скрипты
- `examples` — примеры использования

## Установка

```bash
cd D:\tools\bibl\partner_solutions_lib
pip install -e .
```

## Настройка БД

Переменные окружения:

- `PARTNER_SOLUTIONS_DB_HOST`
- `PARTNER_SOLUTIONS_DB_PORT`
- `PARTNER_SOLUTIONS_DB_USER`
- `PARTNER_SOLUTIONS_DB_PASSWORD`
- `PARTNER_SOLUTIONS_DB_NAME`

## Инициализация БД

```bash
python examples/bootstrap_database.py
```

## Быстрый старт

```python
from partner_solutions import DatabaseManager
from partner_solutions.repositories import PartnerRepository
from partner_solutions.services import PartnerService

connection = DatabaseManager().create_connection()
try:
    service = PartnerService(PartnerRepository(connection))
    partners = service.get_partner_cards()
    for partner in partners:
        print(partner)
finally:
    connection.close()
```

## CLI

После установки доступны команды:

```bash
partner-solutions init-db
partner-solutions list-partners
partner-solutions list-products
partner-solutions list-materials
partner-solutions partner-sales 1
partner-solutions add-sale 1 1 500 2026-04-28
partner-solutions calc-material 2.35 0.001 100 2.0 3.0
```

И генератор именно под конкурсный `partner-system`:

```bash
olymp create db --template partner-system
olymp create web --template partner-system
olymp init partner-system
```

Примеры:

```bash
olymp create db --template partner-system --output ./db
olymp create web --template partner-system --output ./web
olymp init partner-system --output ./partner-system
```

Что делает:
- `olymp create db` — генерирует готовую БД под конкурсный partner-system
- `olymp create web` — генерирует готовую FastAPI-вебку под конкурсный partner-system
- `olymp init partner-system` — генерирует весь проект целиком (`db/` + `web/`)

## Примеры

- `examples/basic_usage.py` — чистая бизнес-логика
- `examples/db_usage.py` — работа через MySQL
- `examples/bootstrap_database.py` — создание схемы и тестовых данных

## SQL

Готовые скрипты лежат здесь:

- `partner_solutions/sql/schema.sql`
- `partner_solutions/sql/seed.sql`
