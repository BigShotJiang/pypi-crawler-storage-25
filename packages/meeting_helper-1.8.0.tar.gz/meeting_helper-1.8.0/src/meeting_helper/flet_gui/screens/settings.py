"""Settings screen — API keys, provider, transcriber, preferences."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING

import flet as ft

if TYPE_CHECKING:
    from meeting_helper.config import Config

TEAL = "#4ec9b0"
MUTED = "#8b949e"
SZ = 13


def _section(title: str) -> ft.Text:
    return ft.Text(title, size=12, weight=ft.FontWeight.W_600, color=MUTED)


_MODEL_SPEED_KEY = {
    "qwen2.5-coder:3b": "fastest",
    "qwen2.5-coder:7b": "fast",
    "qwen2.5-coder:14b": "balanced",
    "qwen2.5-coder:32b": "slow",
    "deepseek-coder-v2:16b": "balanced",
    "codellama:7b": "fast",
    "codellama:13b": "balanced",
}


def _model_speed(model: str) -> str:
    """Return a speed description for a model based on its size."""
    key = _MODEL_SPEED_KEY.get(model)
    if not key:
        import re
        m = re.search(r"(\d+)b", model.lower())
        if m:
            params = int(m.group(1))
            if params <= 3:
                key = "fastest"
            elif params <= 7:
                key = "fast"
            elif params <= 16:
                key = "balanced"
            else:
                key = "slow"
    return key or ""


class SettingsScreen(ft.Column):
    """API keys, AI provider, transcription, model selection, and other preferences."""

    def __init__(self, page: ft.Page, config: "Config"):
        super().__init__(
            expand=True,
            scroll=ft.ScrollMode.AUTO,
            spacing=20,
            horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
        )
        self._page = page
        self._config = config

        # --- API Keys ---
        self._anthropic_key = ft.TextField(
            label="Anthropic API Key", password=True, can_reveal_password=True,
            hint_text="sk-ant-...", value=config.anthropic_api_key,
            border_radius=8, text_size=SZ, expand=True, on_blur=lambda _: self._autosave(),
        )
        self._deepgram_key = ft.TextField(
            label="Deepgram API Key", password=True, can_reveal_password=True,
            hint_text="Optional — falls back to local Whisper",
            value=config.deepgram_api_key,
            border_radius=8, text_size=SZ, expand=True, on_blur=lambda _: self._autosave(),
        )

        api_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section("API Keys"),
                    self._anthropic_key,
                    self._deepgram_key,
                ], spacing=10),
                padding=20,
            ),
        )

        # --- AI Provider ---
        self._provider_dropdown = ft.Dropdown(
            label="AI Provider",
            value=config._data.get("preferred_provider", "") or "claude",
            options=[
                ft.dropdown.Option("local", "Ollama (Free)"),
                ft.dropdown.Option("claude", "Claude"),
            ],
            border_radius=8, text_size=SZ, expand=True,
            on_select=self._on_provider_change,
        )
        self._claude_model = ft.Dropdown(
            label="Claude Model",
            value=config._data.get("claude_model", "sonnet"),
            options=[ft.dropdown.Option(m) for m in ["sonnet", "opus", "haiku"]],
            border_radius=8, text_size=SZ, expand=True,
            on_select=lambda _: self._autosave(),
        )
        self._all_local_models = [
            "qwen2.5-coder:3b", "qwen2.5-coder:7b", "qwen2.5-coder:14b", "qwen2.5-coder:32b",
            "deepseek-coder-v2:16b", "codellama:7b", "codellama:13b",
        ]
        self._local_model = ft.Dropdown(
            label="Local Model",
            value=config._data.get("local_model", "qwen2.5-coder:3b"),
            options=[ft.dropdown.Option(key=m, text=f"{m} ({s})") if (s := _model_speed(m)) else ft.dropdown.Option(key=m, text=m) for m in self._all_local_models],
            border_radius=8, text_size=SZ, expand=True,
            on_select=self._on_local_model_change,
        )
        self._ollama_host = ft.TextField(
            label="Ollama Server",
            hint_text="http://localhost:11434 or http://<remote-ip>:11434",
            value=config._data.get("ollama_host", "http://localhost:11434"),
            border_radius=8, text_size=SZ, expand=True,
            on_blur=self._on_ollama_host_change,
        )
        self._download_btn = ft.OutlinedButton(
            "Download", icon=ft.Icons.DOWNLOAD,
            on_click=self._download_model,
        )
        self._download_status = ft.Text("", size=11, color=MUTED)
        self._ollama_status = ft.Text("", size=11, color=MUTED)
        self._model_row = ft.Row([self._provider_dropdown, self._claude_model, self._local_model, self._download_btn], spacing=12)
        self._ollama_host_row = ft.Row([self._ollama_host], spacing=12)
        self._installed_models: set[str] = set()
        self._downloading_model = None
        self._refresh_installed_models()
        self._check_active_downloads()
        self._update_model_visibility()
        self._check_ollama_connection()

        provider_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section("AI Provider"),
                    self._model_row,
                    self._ollama_host_row,
                    self._ollama_status,
                    self._download_status,
                ], spacing=10),
                padding=20,
            ),
        )

        # --- Transcription ---
        self._all_trans_langs = ["en", "es", "pt", "fr", "de", "it", "ja", "ko", "zh", "auto"]
        self._transcriber_dropdown = ft.Dropdown(
            label="Transcriber",
            value=config._data.get("preferred_transcriber", "whisper") or "whisper",
            options=[
                ft.dropdown.Option("whisper", "Whisper (Free)"),
                ft.dropdown.Option("deepgram", "Deepgram"),
            ],
            border_radius=8, text_size=SZ, expand=True,
            on_select=self._on_transcriber_change,
        )
        self._trans_lang_dropdown = ft.Dropdown(
            label="Transcription Language",
            value=config.transcription_language,
            options=[ft.dropdown.Option(lang) for lang in self._all_trans_langs],
            border_radius=8, text_size=SZ, expand=True,
            on_select=lambda _: self._autosave(),
        )
        self._whisper_host = ft.TextField(
            label="Whisper Server",
            hint_text="Empty = local, or http://<remote-ip>:8000",
            value=config._data.get("whisper_host", "") or "http://localhost:8000",
            border_radius=8, text_size=SZ, expand=True,
            on_blur=self._on_whisper_host_change,
        )
        self._whisper_host_row = ft.Row([self._whisper_host], spacing=12)
        self._whisper_status = ft.Text("", size=11, color=MUTED)
        self._update_trans_lang_options()
        self._update_whisper_host_visibility()
        self._check_whisper_connection()

        transcription_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section("Transcription"),
                    ft.Row([self._transcriber_dropdown, self._trans_lang_dropdown], spacing=12),
                    self._whisper_host_row,
                    self._whisper_status,
                ], spacing=10),
                padding=20,
            ),
        )

        # --- Preferences ---
        self._theme_dropdown = ft.Dropdown(
            label="Theme",
            value=config._data.get("gui_theme", "system"),
            options=[ft.dropdown.Option(t) for t in ["system", "dark", "light"]],
            border_radius=8, text_size=SZ, expand=True,
            on_select=self._on_theme_change,
        )

        self._sw_label = ft.Text(str(config.sentence_window), size=SZ, width=40)
        self._sw_slider = ft.Slider(
            min=1, max=10, divisions=9,
            value=config.sentence_window,
            label="{value}",
            active_color=TEAL,
            on_change=lambda e: self._update_slider_label(e, self._sw_label),
            width=250,
        )

        self._st_label = ft.Text(str(config.silence_timeout), size=SZ, width=40)
        self._st_slider = ft.Slider(
            min=10, max=120, divisions=22,
            value=config.silence_timeout,
            label="{value}",
            active_color=TEAL,
            on_change=lambda e: self._update_slider_label(e, self._st_label),
            width=250,
        )

        # File picker for recordings dir
        self._file_picker = ft.FilePicker()
        page.services.append(self._file_picker)

        self._rec_input = ft.TextField(
            label="Recordings Directory",
            value=str(config.recordings_dir),
            border_radius=8, text_size=SZ, expand=True,
            on_blur=lambda _: self._autosave(),
        )
        browse_btn = ft.OutlinedButton(
            "Browse", icon=ft.Icons.FOLDER_OPEN,
            on_click=self._browse_recordings,
        )

        prefs_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section("Preferences"),
                    ft.Row([self._theme_dropdown], spacing=12),
                    ft.Row([
                        ft.Text("Sentence Window", size=SZ, width=180),
                        self._sw_slider,
                        self._sw_label,
                    ], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                    ft.Row([
                        ft.Text("Silence Timeout (s)", size=SZ, width=180),
                        self._st_slider,
                        self._st_label,
                    ], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                    ft.Row([self._rec_input, browse_btn], spacing=10),
                ], spacing=14),
                padding=20,
            ),
        )

        # --- AI Behaviour ---
        self._proactive_check = ft.Checkbox(
            label="Proactive answers",
            value=config.proactive_answers,
            tooltip="Auto-answer questions detected in the transcript",
            on_change=lambda _: self._autosave(),
        )
        self._auto_ctx_check = ft.Checkbox(
            label="Auto-select context",
            value=config.auto_context_enabled,
            tooltip="Automatically load repos and knowledge based on discussion",
            on_change=lambda _: self._autosave(),
        )

        self._aci_label = ft.Text(str(config.auto_context_interval), size=SZ, width=40)
        self._aci_slider = ft.Slider(
            min=10, max=120, divisions=22,
            value=config.auto_context_interval,
            label="{value}",
            active_color=TEAL,
            on_change=lambda e: self._update_slider_label(e, self._aci_label, step=5),
            width=250,
        )

        ai_card = ft.Card(
            content=ft.Container(
                content=ft.Column([
                    _section("AI Behaviour"),
                    self._proactive_check,
                    ft.Text("Auto-answer questions detected in the transcript",
                            size=11, color=ft.Colors.ON_SURFACE_VARIANT),
                    self._auto_ctx_check,
                    ft.Text("Automatically load repos and knowledge based on what is being discussed",
                            size=11, color=ft.Colors.ON_SURFACE_VARIANT),
                    ft.Row([
                        ft.Text("Auto-Context Interval (s)", size=SZ, width=180),
                        self._aci_slider,
                        self._aci_label,
                    ], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                ], spacing=10),
                padding=20,
            ),
        )

        # --- Save ---
        self._save_status = ft.Text("", size=11, color=MUTED)

        self.controls = [
            ft.Container(
                content=ft.Column([
                    ft.Text("Settings", size=22, weight=ft.FontWeight.W_600),
                    api_card,
                    provider_card,
                    transcription_card,
                    prefs_card,
                    ai_card,
                    self._save_status,
                ], spacing=14, horizontal_alignment=ft.CrossAxisAlignment.STRETCH),
                padding=30,
            ),
        ]

    # ----- Provider visibility -----

    def _update_model_visibility(self):
        prov = self._provider_dropdown.value
        self._claude_model.visible = prov == "claude"
        self._local_model.visible = prov == "local"
        self._ollama_host_row.visible = prov == "local"
        self._ollama_status.visible = prov == "local"
        self._update_download_btn()

    def _on_provider_change(self, e):
        self._update_model_visibility()
        self._autosave()
        self._page.update()

    # ----- Ollama connection & models -----

    def _on_ollama_host_change(self, e):
        self._autosave()
        self._check_ollama_connection()
        self._refresh_installed_models()
        # Update dropdown options with models from the (possibly remote) server
        remote_models = list(self._installed_models)
        if remote_models:
            combined = list(dict.fromkeys(self._all_local_models + remote_models))
            self._local_model.options = [ft.dropdown.Option(key=m, text=f"{m} ({s})") if (s := _model_speed(m)) else ft.dropdown.Option(key=m, text=m) for m in combined]
        self._update_download_btn()
        self._page.update()

    def _check_ollama_connection(self):
        host = (self._ollama_host.value or "http://localhost:11434").strip()
        try:
            import urllib.request
            url = f"{host.rstrip('/')}/api/tags"
            urllib.request.urlopen(url, timeout=3)
            self._ollama_status.value = f"● Connected — {host}"
            self._ollama_status.color = TEAL
        except Exception:
            self._ollama_status.value = f"● Not reachable — {host}"
            self._ollama_status.color = "#f14c4c"

    def _refresh_installed_models(self):
        from meeting_helper.ai.ollama_utils import get_installed_models
        host = getattr(self, "_ollama_host", None)
        host_val = host.value if host else "http://localhost:11434"
        self._installed_models = set(get_installed_models(host=host_val))

    def _is_model_installed(self, model: str) -> bool:
        return model in self._installed_models

    def _is_remote_host(self) -> bool:
        host = (self._ollama_host.value or "").strip()
        return bool(host) and "localhost" not in host and "127.0.0.1" not in host and host != "http://localhost:11434"

    def _update_download_btn(self):
        model = self._local_model.value or ""
        # Don't overwrite if a download is in progress
        if self._downloading_model:
            self._download_btn.visible = False
            self._download_status.visible = self._local_model.visible
            return
        installed = self._is_model_installed(model)
        self._download_btn.visible = self._local_model.visible and not installed
        self._download_btn.disabled = False
        if installed:
            self._download_status.value = f"{model} — ready"
            self._download_status.color = TEAL
        else:
            self._download_status.value = f"{model} — not downloaded"
            self._download_status.color = "#d29922"
        self._download_status.visible = self._local_model.visible

    def _on_local_model_change(self, e):
        self._update_download_btn()
        self._autosave()
        self._page.update()

    def _check_active_downloads(self):
        """If an ollama pull is running, show status and start polling."""
        try:
            import subprocess as _sp
            r = _sp.run(["pgrep", "-af", "ollama pull"], capture_output=True, text=True, timeout=3)
            if r.returncode == 0 and r.stdout.strip():
                for line in r.stdout.strip().split("\n"):
                    parts = line.split("ollama pull ")
                    if len(parts) > 1:
                        downloading = parts[1].strip()
                        self._downloading_model = downloading
                        self._download_status.value = f"{downloading} — downloading..."
                        self._download_status.color = TEAL
                        self._download_status.visible = True
                        self._download_btn.visible = False
                        self._download_btn.disabled = True
                        self._page.run_thread(self._poll_download, downloading)
                        break
        except Exception:
            pass

    def _poll_download(self, model: str):
        """Poll until model appears in ollama list."""
        import subprocess as _sp
        import time
        for _ in range(360):
            time.sleep(3)
            try:
                r = _sp.run(["ollama", "list"], capture_output=True, text=True, timeout=5)
                if model in r.stdout:
                    self._downloading_model = None
                    self._refresh_installed_models()
                    self._update_download_btn()
                    try:
                        self._page.update()
                    except Exception:
                        pass
                    return
                r2 = _sp.run(["pgrep", "-f", f"ollama pull {model}"], capture_output=True, text=True)
                if r2.returncode != 0:
                    self._downloading_model = None
                    self._download_status.value = f"{model} — download failed"
                    self._download_status.color = "#f14c4c"
                    self._download_btn.disabled = False
                    try:
                        self._page.update()
                    except Exception:
                        pass
                    return
            except Exception:
                pass

    # ----- Model download -----

    def _download_model(self, e):
        model = self._local_model.value or "qwen2.5-coder:3b"
        self._download_btn.disabled = True
        self._download_status.value = f"Downloading {model}..."
        self._download_status.color = TEAL
        self._page.update()

        if self._is_remote_host():
            self._page.run_thread(lambda: self._do_download_remote(model))
        else:
            self._page.run_thread(lambda: self._do_download_local(model))

    def _do_download_remote(self, model: str):
        """Pull model on a remote Ollama server via POST /api/pull."""
        import json
        import urllib.request

        host = (self._ollama_host.value or "").strip().rstrip("/")
        try:
            body = json.dumps({"name": model, "stream": True}).encode()
            req = urllib.request.Request(
                f"{host}/api/pull", data=body,
                headers={"Content-Type": "application/json"},
            )
            self._downloading_model = model
            self._download_status.value = f"{model} — downloading..."
            self._download_btn.visible = False
            try:
                self._page.update()
            except Exception:
                pass

            with urllib.request.urlopen(req, timeout=1800) as resp:
                for line in resp:
                    if not line.strip():
                        continue
                    try:
                        chunk = json.loads(line)
                        status = chunk.get("status", "")
                        total = chunk.get("total", 0)
                        completed = chunk.get("completed", 0)
                        if total and completed:
                            pct = int(completed / total * 100)
                            self._download_status.value = f"{model} — {status} {pct}%"
                        elif status:
                            self._download_status.value = f"{model} — {status}"
                        try:
                            self._page.update()
                        except Exception:
                            pass
                    except json.JSONDecodeError:
                        pass

            self._downloading_model = None
            self._refresh_installed_models()
            self._update_download_btn()
            try:
                self._page.update()
            except Exception:
                pass

        except Exception as exc:
            self._downloading_model = None
            self._download_status.value = f"Error: {exc}"
            self._download_status.color = "#f14c4c"
            self._download_btn.disabled = False
            try:
                self._page.update()
            except Exception:
                pass

    def _do_download_local(self, model: str):
        """Pull model on local Ollama via subprocess."""
        import subprocess as _sp

        try:
            from meeting_helper.ai.ollama_utils import is_ollama_installed, start_ollama
            if not is_ollama_installed():
                self._download_status.value = "Ollama not installed. Run: brew install ollama"
                self._download_status.color = "#f14c4c"
                self._download_btn.disabled = False
                try:
                    self._page.update()
                except Exception:
                    pass
                return

            start_ollama()

            _sp.Popen(["ollama", "pull", model], start_new_session=True,
                       stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)

            self._downloading_model = model
            self._download_status.value = f"{model} — downloading..."
            self._download_btn.visible = False
            try:
                self._page.update()
            except Exception:
                pass

            self._poll_download(model)

        except Exception as exc:
            self._download_status.value = f"Error: {exc}"
            self._download_status.color = "#f14c4c"
            self._download_btn.disabled = False
            try:
                self._page.update()
            except Exception:
                pass

    # ----- Transcription -----

    def _update_trans_lang_options(self):
        """Hide 'auto' language when Deepgram is selected (requires explicit language)."""
        is_deepgram = self._transcriber_dropdown.value == "deepgram"
        langs = [l for l in self._all_trans_langs if l != "auto"] if is_deepgram else self._all_trans_langs
        self._trans_lang_dropdown.options = [ft.dropdown.Option(l) for l in langs]
        if is_deepgram and self._trans_lang_dropdown.value == "auto":
            self._trans_lang_dropdown.value = "en"

    def _on_transcriber_change(self, e):
        self._update_trans_lang_options()
        self._update_whisper_host_visibility()
        self._autosave()
        self._page.update()

    def _on_whisper_host_change(self, e):
        self._autosave()
        self._check_whisper_connection()
        self._page.update()

    def _update_whisper_host_visibility(self):
        """Show whisper host field only when Whisper is selected."""
        is_whisper = self._transcriber_dropdown.value == "whisper"
        self._whisper_host_row.visible = is_whisper
        self._whisper_status.visible = is_whisper

    def _check_whisper_connection(self):
        host = (self._whisper_host.value or "http://localhost:8000").strip()
        try:
            import urllib.request
            urllib.request.urlopen(f"{host.rstrip('/')}/health", timeout=3)
            self._whisper_status.value = f"● Connected — {host}"
            self._whisper_status.color = TEAL
        except Exception:
            self._whisper_status.value = f"● Not reachable — {host}"
            self._whisper_status.color = "#f14c4c"

    # ----- Theme / sliders / browse -----

    def _on_theme_change(self, e):
        theme_map = {"dark": ft.ThemeMode.DARK, "light": ft.ThemeMode.LIGHT, "system": ft.ThemeMode.SYSTEM}
        self._page.theme_mode = theme_map.get(e.control.value, ft.ThemeMode.SYSTEM)
        self._autosave()
        self._page.update()

    def _update_slider_label(self, e, label: ft.Text, step: int = 1):
        val = int(round(e.control.value / step) * step) if step > 1 else int(e.control.value)
        label.value = str(val)
        self._autosave()
        self._page.update()

    async def _browse_recordings(self, e):
        path = await self._file_picker.get_directory_path(
            dialog_title="Select Recordings Directory"
        )
        if path:
            self._rec_input.value = path
            self._autosave()
            self._page.update()

    # ----- Auto-save -----

    def _autosave(self):
        """Save all settings to config immediately."""
        self._config.anthropic_api_key = (self._anthropic_key.value or "").strip()
        self._config.deepgram_api_key = (self._deepgram_key.value or "").strip()
        self._config._data["gui_theme"] = self._theme_dropdown.value or "system"

        # AI Provider
        prov = self._provider_dropdown.value
        self._config.preferred_provider = prov if prov != "claude" else ""
        self._config.claude_model = self._claude_model.value or "sonnet"
        self._config.local_model = self._local_model.value or "qwen2.5-coder:3b"
        self._config.ollama_host = (self._ollama_host.value or "http://localhost:11434").strip()

        # Transcription
        trans = self._transcriber_dropdown.value
        self._config.preferred_transcriber = trans if trans != "auto" else ""
        self._config.whisper_host = (self._whisper_host.value or "").strip()
        self._config.transcription_language = self._trans_lang_dropdown.value or "auto"

        # Preferences
        self._config.sentence_window = int(self._sw_slider.value)
        self._config.silence_timeout = int(self._st_slider.value)
        self._config.recordings_dir = (self._rec_input.value or "").strip()

        # AI Behaviour
        self._config.proactive_answers = self._proactive_check.value
        self._config.auto_context_enabled = self._auto_ctx_check.value
        self._config.auto_context_interval = int(round(self._aci_slider.value / 5) * 5)

        self._config.setup_complete = True
        self._config.save()
        self._save_status.value = "Saved"
        try:
            self._page.update()
        except Exception:
            pass
