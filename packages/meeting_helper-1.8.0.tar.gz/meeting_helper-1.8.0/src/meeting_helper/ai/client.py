"""AI client: real-time queries (Claude or Ollama), post-meeting transcription & summarization."""

from __future__ import annotations

import asyncio
import json
import logging
import time
import urllib.request
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from meeting_helper.config import AppConfig
    from meeting_helper.state import AppState

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Message assembly
# ---------------------------------------------------------------------------

def _assemble_messages(state: "AppState", config: "AppConfig") -> list:
    """Build the messages list: conversation history + current transcript window."""
    transcript = ""
    if state.sentence_buffer is not None:
        transcript = state.sentence_buffer.get_last_n_as_text(config.sentence_window)

    if transcript:
        content = f"## Recent meeting conversation (last {config.sentence_window} sentences):\n\n{transcript}"
    else:
        content = "No transcript captured yet. The meeting may have just started."

    messages = list(state.conversation_history)
    messages.append({"role": "user", "content": content})
    return messages


# ---------------------------------------------------------------------------
# Claude (Anthropic) streaming
# ---------------------------------------------------------------------------

async def _stream_claude(state: "AppState", config: "AppConfig", messages: list, system_prompt: str) -> str:
    """Stream response from Claude. Returns full_text."""
    from meeting_helper.server.websocket import broadcast
    import anthropic
    import httpx

    if not config.anthropic_api_key:
        await broadcast({"type": "error", "message": "No Anthropic API key configured."})
        return ""

    client = anthropic.AsyncAnthropic(
        api_key=config.anthropic_api_key,
        http_client=httpx.AsyncClient(verify=False),
    )
    full_text = ""

    try:
        async with client.messages.stream(
            model=config.claude_model,
            max_tokens=config.max_tokens,
            system=system_prompt,
            messages=messages,
        ) as stream:
            async for text_delta in stream.text_stream:
                full_text += text_delta
                await broadcast({"type": "chunk", "text": text_delta})
        return full_text

    except anthropic.AuthenticationError:
        msg = "Invalid Anthropic API key. Check your configuration."
        logger.error(msg)
        await broadcast({"type": "error", "message": msg})
        return ""

    except anthropic.BadRequestError as exc:
        if "token" in str(exc).lower():
            # Context too long — trim history and retry
            trimmed = len(state.conversation_history)
            half = max(2, len(state.conversation_history) // 2)
            state.conversation_history = state.conversation_history[half:]
            logger.warning("Context too long (%d entries) — trimmed to %d, retrying",
                           trimmed, len(state.conversation_history))

            await broadcast({"type": "start"})
            messages_retry = list(state.conversation_history)
            messages_retry.append(messages[-1])  # re-append current user turn
            try:
                full_text = ""
                async with client.messages.stream(
                    model=config.claude_model,
                    max_tokens=config.max_tokens,
                    system=system_prompt,
                    messages=messages_retry,
                ) as stream:
                    async for text_delta in stream.text_stream:
                        full_text += text_delta
                        await broadcast({"type": "chunk", "text": text_delta})
                return full_text
            except Exception as retry_exc:
                logger.error("Retry after trim failed: %s", retry_exc)
                await broadcast({"type": "error", "message": f"Failed after trimming: {retry_exc}"})
                return ""
        else:
            logger.error("Bad request: %s", exc)
            await broadcast({"type": "error", "message": f"Bad request: {exc}"})
            return ""

    except anthropic.APIConnectionError as exc:
        logger.error("Connection error: %s", exc)
        await broadcast({"type": "error", "message": f"Connection error: {exc}"})
        return ""

    except Exception as exc:
        logger.error("Unexpected error: %s", exc)
        await broadcast({"type": "error", "message": f"Unexpected error: {exc}"})
        return ""


# ---------------------------------------------------------------------------
# Ollama (local) streaming
# ---------------------------------------------------------------------------

def _ensure_ollama(model: str, host: str = "http://localhost:11434") -> bool:
    """Ensure Ollama is running and the model is available. Returns True if ready."""
    from meeting_helper.ai.ollama_utils import (
        is_ollama_installed, start_ollama, get_installed_models, keep_alive, _is_remote,
    )

    remote = _is_remote(host)

    if not remote and not is_ollama_installed():
        logger.error("Ollama not installed")
        return False

    if not start_ollama(host):
        logger.error("Ollama server failed to start (host=%s)", host)
        return False

    if not remote:
        keep_alive()

    installed = get_installed_models(start_server=True, host=host)
    if model not in installed:
        logger.error("Model %s not available on %s. Download it from Settings.", model, host)
        return False

    return True


async def _stream_ollama(state: "AppState", config: "AppConfig", messages: list, system_prompt: str) -> str:
    """Stream response from Ollama. Returns full_text."""
    from meeting_helper.server.websocket import broadcast

    model = config.local_model
    host = config.ollama_host

    ready = await asyncio.get_event_loop().run_in_executor(None, _ensure_ollama, model, host)
    if not ready:
        await broadcast({"type": "error", "message": f"Ollama not reachable at {host}. Check server or install locally: brew install ollama"})
        return ""

    try:
        # Convert messages to OpenAI format (text only)
        ollama_messages = [{"role": "system", "content": system_prompt}]
        for msg in messages:
            role = msg["role"]
            content = msg.get("content", "")
            if isinstance(content, str):
                ollama_messages.append({"role": role, "content": content})
            elif isinstance(content, list):
                text_parts = [b["text"] for b in content if b.get("type") == "text"]
                if text_parts:
                    ollama_messages.append({"role": role, "content": "\n\n".join(text_parts)})

        full_text = ""

        def _stream_sync():
            nonlocal full_text
            body = json.dumps({
                "model": model,
                "messages": ollama_messages,
                "stream": True,
            }).encode()
            req = urllib.request.Request(
                f"{host.rstrip('/')}/api/chat",
                data=body,
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                for line in resp:
                    if not line.strip():
                        continue
                    try:
                        chunk = json.loads(line)
                        text = chunk.get("message", {}).get("content", "")
                        if text:
                            full_text += text
                    except json.JSONDecodeError:
                        pass

        loop = asyncio.get_event_loop()
        prev_len = 0
        task = loop.run_in_executor(None, _stream_sync)

        while not task.done():
            await asyncio.sleep(0.05)
            if len(full_text) > prev_len:
                await broadcast({"type": "chunk", "text": full_text[prev_len:]})
                prev_len = len(full_text)

        await task  # raise any exception

        # Flush remaining
        if len(full_text) > prev_len:
            await broadcast({"type": "chunk", "text": full_text[prev_len:]})

        return full_text

    except Exception as exc:
        logger.error("Ollama error: %s", exc, exc_info=True)
        await broadcast({"type": "error", "message": f"Local AI error: {exc}"})
        return ""


# ---------------------------------------------------------------------------
# Provider router
# ---------------------------------------------------------------------------

async def _stream_ai(state: "AppState", config: "AppConfig", messages: list, system_prompt: str) -> str:
    """Route to the configured AI provider. Returns full_text."""
    if config.preferred_provider == "local":
        return await _stream_ollama(state, config, messages, system_prompt)
    else:
        return await _stream_claude(state, config, messages, system_prompt)


# ---------------------------------------------------------------------------
# Real-time query (during meeting, hotkey-triggered)
# ---------------------------------------------------------------------------

async def handle_query(state: "AppState", config: "AppConfig") -> None:
    """Assemble context from transcript buffer and stream AI response via WebSocket."""
    from meeting_helper.server.websocket import broadcast

    # Cancel any in-progress streaming task
    prev = state.active_query
    if prev and not prev.done():
        logger.info("Cancelling in-progress query for new one")
        prev.cancel()
        try:
            await prev
        except (asyncio.CancelledError, Exception):
            pass

    state.active_query = asyncio.current_task()

    if state.proactive_monitor is not None:
        state.proactive_monitor.notify_manual_query()

    state.status = "processing"
    await broadcast({"type": "status", "value": "processing"})
    await broadcast({"type": "start"})

    messages = _assemble_messages(state, config)
    current_user_turn = messages[-1]
    system_prompt = state.system_prompt or config.system_prompt

    try:
        full_text = await _stream_ai(state, config, messages, system_prompt)

        if full_text:
            state.last_response = full_text
            state.conversation_history.append(current_user_turn)
            state.conversation_history.append({"role": "assistant", "content": full_text})

            max_entries = config.max_history_turns * 2
            if len(state.conversation_history) > max_entries:
                state.conversation_history = state.conversation_history[-max_entries:]

            await broadcast({"type": "done", "full_text": full_text})
            logger.info("Query complete (%d chars)", len(full_text))

    except asyncio.CancelledError:
        logger.info("Query cancelled")
        return

    finally:
        if state.active_query == asyncio.current_task():
            state.status = "listening" if state.audio_active else "idle"
            await broadcast({"type": "status", "value": state.status})


# ---------------------------------------------------------------------------
# Manual query (user-typed text during meeting)
# ---------------------------------------------------------------------------

async def handle_manual_query(state: "AppState", config: "AppConfig", user_text: str) -> None:
    """Send a user-typed question to AI, with transcript context appended."""
    from meeting_helper.server.websocket import broadcast

    # Cancel any in-progress streaming task
    prev = state.active_query
    if prev and not prev.done():
        logger.info("Cancelling in-progress query for new one")
        prev.cancel()
        try:
            await prev
        except (asyncio.CancelledError, Exception):
            pass

    state.active_query = asyncio.current_task()

    if state.proactive_monitor is not None:
        state.proactive_monitor.notify_manual_query()

    state.status = "processing"
    await broadcast({"type": "status", "value": "processing"})
    await broadcast({"type": "start"})

    transcript = ""
    if state.sentence_buffer is not None:
        transcript = state.sentence_buffer.get_last_n_as_text(config.sentence_window * 3)

    if transcript:
        content = f"{user_text}\n\n---\n## Recent meeting transcript (for context):\n{transcript}"
    else:
        content = user_text

    messages = list(state.conversation_history)
    messages.append({"role": "user", "content": content})
    current_user_turn = {"role": "user", "content": content}
    system_prompt = state.system_prompt or config.system_prompt

    try:
        full_text = await _stream_ai(state, config, messages, system_prompt)

        if full_text:
            state.last_response = full_text
            state.conversation_history.append(current_user_turn)
            state.conversation_history.append({"role": "assistant", "content": full_text})

            max_entries = config.max_history_turns * 2
            if len(state.conversation_history) > max_entries:
                state.conversation_history = state.conversation_history[-max_entries:]

            await broadcast({"type": "done", "full_text": full_text})
            logger.info("Manual query complete (%d chars)", len(full_text))

    except asyncio.CancelledError:
        logger.info("Manual query cancelled")
        return

    except Exception as exc:
        logger.error("Manual query error: %s", exc, exc_info=True)
        await broadcast({"type": "error", "message": f"Error: {exc}"})

    finally:
        if state.active_query == asyncio.current_task():
            state.status = "listening" if state.audio_active else "idle"
            await broadcast({"type": "status", "value": state.status})


# ---------------------------------------------------------------------------
# Proactive query (auto-triggered when a question is detected in transcript)
# ---------------------------------------------------------------------------

async def handle_proactive_query(state: "AppState", config: "AppConfig", question: str) -> None:
    """Auto-triggered query when a question is detected. Same as manual but labeled auto."""
    from meeting_helper.server.websocket import broadcast

    # Cancel any in-progress streaming task
    prev = state.active_query
    if prev and not prev.done():
        logger.info("Cancelling in-progress query for new one (proactive)")
        prev.cancel()
        try:
            await prev
        except (asyncio.CancelledError, Exception):
            pass

    state.active_query = asyncio.current_task()

    state.status = "processing"
    await broadcast({"type": "status", "value": "processing"})
    await broadcast({"type": "start", "proactive": True, "question": question})

    transcript = ""
    if state.sentence_buffer is not None:
        transcript = state.sentence_buffer.get_last_n_as_text(config.sentence_window * 2)

    if transcript:
        content = f"{question}\n\n---\n## Recent meeting transcript:\n{transcript}"
    else:
        content = question

    messages = list(state.conversation_history)
    messages.append({"role": "user", "content": content})
    current_user_turn = {"role": "user", "content": content}
    system_prompt = state.system_prompt or config.system_prompt

    try:
        full_text = await _stream_ai(state, config, messages, system_prompt)

        if full_text:
            state.last_response = full_text
            state.conversation_history.append(current_user_turn)
            state.conversation_history.append({"role": "assistant", "content": full_text})

            max_entries = config.max_history_turns * 2
            if len(state.conversation_history) > max_entries:
                state.conversation_history = state.conversation_history[-max_entries:]

            await broadcast({"type": "done", "full_text": full_text})
            logger.info("Proactive query complete (%d chars)", len(full_text))

    except asyncio.CancelledError:
        logger.info("Proactive query cancelled")
        return

    except Exception as exc:
        logger.error("Proactive query error: %s", exc)
        await broadcast({"type": "error", "message": f"Error: {exc}"})

    finally:
        if state.active_query == asyncio.current_task():
            state.status = "listening" if state.audio_active else "idle"
            await broadcast({"type": "status", "value": state.status})


# ---------------------------------------------------------------------------
# Post-meeting: transcribe MP3 with faster-whisper
# ---------------------------------------------------------------------------

def transcribe_audio_file(mp3_path: str, config: "AppConfig") -> str:
    """Transcribe an MP3 file using faster-whisper. Returns full transcript text.

    Runs synchronously — caller should wrap in asyncio.to_thread().
    """
    from faster_whisper import WhisperModel

    path = Path(mp3_path)
    if not path.exists():
        raise FileNotFoundError(f"Audio file not found: {mp3_path}")

    logger.info("Transcribing %s with faster-whisper...", path.name)
    t0 = time.monotonic()

    from meeting_helper.ssl_fix import patch_ssl
    patch_ssl()

    model = WhisperModel("medium", compute_type="int8")
    segments, info = model.transcribe(
        str(path),
        language=config.transcription_language if config.transcription_language != "auto" else None,
        beam_size=5,
        vad_filter=True,
        condition_on_previous_text=True,
    )

    lines: list[str] = []
    for segment in segments:
        start_m, start_s = divmod(int(segment.start), 60)
        end_m, end_s = divmod(int(segment.end), 60)
        timestamp = f"[{start_m:02d}:{start_s:02d} - {end_m:02d}:{end_s:02d}]"
        lines.append(f"{timestamp} {segment.text.strip()}")

    transcript = "\n".join(lines)
    elapsed = time.monotonic() - t0
    logger.info("Transcription complete: %d segments, %.1fs", len(lines), elapsed)

    # Save alongside the MP3
    out_path = path.with_suffix(".transcript.txt")
    out_path.write_text(transcript)
    logger.info("Transcript saved: %s", out_path.name)

    return transcript


# ---------------------------------------------------------------------------
# Auto-context: select relevant repos/knowledge from low-level index
# ---------------------------------------------------------------------------

async def _select_context(
    index: str, transcript: str, history: list, config: "AppConfig"
) -> dict:
    """Ask Claude Haiku which repos/knowledge are relevant. Returns {repos, knowledge}."""
    import re
    import anthropic
    import httpx
    from meeting_helper.ai.prompts import AUTO_CONTEXT_SELECTION_PROMPT

    if not index.strip() or not transcript.strip():
        return {"repos": [], "knowledge": []}

    history_text = "\n".join(
        f"{m['role'].title()}: {str(m.get('content', ''))[:200]}" for m in history[-4:]
    ) or "(none)"

    prompt = AUTO_CONTEXT_SELECTION_PROMPT.format(
        index=index,
        n=len(transcript.split("\n")),
        transcript=transcript[-3000:],
        history=history_text,
    )

    try:
        client = anthropic.AsyncAnthropic(
            api_key=config.anthropic_api_key,
            http_client=httpx.AsyncClient(verify=False),
        )
        msg = await client.messages.create(
            model="claude-haiku-4-5-20251001",
            max_tokens=256,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = msg.content[0].text.strip()
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if not match:
            return {"repos": [], "knowledge": []}
        result = json.loads(match.group())
        return {
            "repos": result.get("repos", []) if isinstance(result.get("repos"), list) else [],
            "knowledge": result.get("knowledge", []) if isinstance(result.get("knowledge"), list) else [],
        }
    except Exception as exc:
        logger.warning("_select_context error: %s", exc)
        return {"repos": [], "knowledge": []}


# ---------------------------------------------------------------------------
# Post-meeting: summarize transcript with Claude
# ---------------------------------------------------------------------------

async def summarize_transcript(transcript_path: str, config: "AppConfig") -> str:
    """Send a full transcript to Claude for structured summary. Returns summary text."""
    import anthropic
    from meeting_helper.ai.prompts import SUMMARIZE_SYSTEM_PROMPT

    path = Path(transcript_path)
    if not path.exists():
        raise FileNotFoundError(f"Transcript file not found: {transcript_path}")

    transcript = path.read_text()
    if not transcript.strip():
        raise ValueError("Transcript file is empty")

    if not config.anthropic_api_key:
        raise ValueError("No Anthropic API key configured")

    logger.info("Summarizing transcript (%d chars)...", len(transcript))
    t0 = time.monotonic()

    import httpx
    client = anthropic.AsyncAnthropic(
        api_key=config.anthropic_api_key,
        http_client=httpx.AsyncClient(verify=False),
    )

    message = await client.messages.create(
        model=config.claude_model,
        max_tokens=config.max_tokens,
        system=SUMMARIZE_SYSTEM_PROMPT,
        messages=[{"role": "user", "content": f"Please summarize this meeting transcript:\n\n{transcript}"}],
    )

    summary = message.content[0].text
    elapsed = time.monotonic() - t0
    logger.info("Summarization complete: %d chars, %.1fs", len(summary), elapsed)

    # Save alongside the transcript
    out_path = path.with_name(path.name.replace(".transcript.txt", ".summary.txt"))
    if out_path == path:
        out_path = path.with_suffix(".summary.txt")
    out_path.write_text(summary)
    logger.info("Summary saved: %s", out_path.name)

    return summary
