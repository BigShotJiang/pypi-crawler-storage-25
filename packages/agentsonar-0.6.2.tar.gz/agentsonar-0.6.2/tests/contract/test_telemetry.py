"""Telemetry module tests.

Covers the host-safety contract for `_telemetry.py`:
- Disable signals (env vars, persistent state, DNT) are honored in the
  documented priority order.
- The state file roundtrips cleanly and is robust to broken filesystems.
- session_start never raises for any input shape.
- HTTP failures, JSON failures, missing dirs, missing fields, and
  permission errors are all silent.
- The disclosure message prints exactly once across multiple sessions
  and re-prints after the state file is deleted.

These tests use a tmp state dir via monkeypatch so we never touch the
developer's real ~/.agentsonar/.
"""
from __future__ import annotations

import json
import os
import sys
import threading
import time
from pathlib import Path
from unittest.mock import patch

import pytest

from agentsonar import _telemetry


@pytest.fixture(autouse=True)
def _isolated_state(tmp_path, monkeypatch):
    """Redirect _state_path() to a tmp dir for every test in this file."""
    state_dir = tmp_path / ".agentsonar"

    def fake_state_path():
        return state_dir / "state.json"

    monkeypatch.setattr(_telemetry, "_state_path", fake_state_path)

    # Also clean any env vars that might leak from the dev's shell or
    # from conftest.py setting AGENTSONAR_TELEMETRY=off (which we want
    # to control per-test).
    for var in ("AGENTSONAR_TELEMETRY", "DO_NOT_TRACK", "AGENTSONAR_TELEMETRY_ENDPOINT"):
        monkeypatch.delenv(var, raising=False)

    yield


# ---------- is_disabled ----------

def test_default_is_enabled():
    assert _telemetry.is_disabled() is False


def test_agentsonar_telemetry_off_disables(monkeypatch):
    for val in ("off", "0", "false", "no", "disabled", "OFF"):
        monkeypatch.setenv("AGENTSONAR_TELEMETRY", val)
        assert _telemetry.is_disabled() is True, f"value {val!r} should disable"


def test_agentsonar_telemetry_on_enables(monkeypatch):
    for val in ("on", "1", "true", "yes", "enabled", "ON"):
        monkeypatch.setenv("AGENTSONAR_TELEMETRY", val)
        assert _telemetry.is_disabled() is False, f"value {val!r} should enable"


def test_dnt_always_wins(monkeypatch):
    """DO_NOT_TRACK=1 disables even if AGENTSONAR_TELEMETRY=on."""
    monkeypatch.setenv("DO_NOT_TRACK", "1")
    monkeypatch.setenv("AGENTSONAR_TELEMETRY", "on")
    assert _telemetry.is_disabled() is True, "DNT must win over AGENTSONAR_TELEMETRY=on"


def test_dnt_disables(monkeypatch):
    for val in ("1", "true", "yes", "on", "enabled"):
        monkeypatch.setenv("DO_NOT_TRACK", val)
        assert _telemetry.is_disabled() is True, f"DNT={val!r} should disable"


def test_dnt_zero_does_not_disable(monkeypatch):
    """DO_NOT_TRACK=0 (or any non-truthy value) should NOT disable."""
    for val in ("0", "false", "no", ""):
        monkeypatch.setenv("DO_NOT_TRACK", val)
        assert _telemetry.is_disabled() is False, f"DNT={val!r} should not disable"


def test_persistent_disable_in_state_file(monkeypatch):
    _telemetry.disable_persistently()
    assert _telemetry.is_disabled() is True


def test_env_re_enable_overrides_persistent_disable(monkeypatch):
    """User who set persistent disable should be able to re-enable via env."""
    _telemetry.disable_persistently()
    monkeypatch.setenv("AGENTSONAR_TELEMETRY", "on")
    assert _telemetry.is_disabled() is False


def test_env_off_beats_persistent_state(monkeypatch):
    """AGENTSONAR_TELEMETRY=off disables even if state would say enabled."""
    monkeypatch.setenv("AGENTSONAR_TELEMETRY", "off")
    # state file has nothing, but env should still disable
    assert _telemetry.is_disabled() is True


# ---------- state file roundtrip ----------

def test_state_roundtrip(tmp_path):
    _telemetry._save_state({"hello": "world", "n": 42})
    loaded = _telemetry._load_state()
    assert loaded == {"hello": "world", "n": 42}


def test_load_state_missing_file_returns_empty():
    # Fresh tmp dir, no file exists yet
    assert _telemetry._load_state() == {}


def test_load_state_corrupt_returns_empty(monkeypatch):
    """A corrupt state.json must not break anything; it gets treated as empty."""
    p = _telemetry._state_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("not-valid-json{", encoding="utf-8")
    assert _telemetry._load_state() == {}


@pytest.mark.parametrize("payload", [
    "null",                # JSON null
    '"just a string"',     # JSON string
    "42",                  # JSON number
    "[1, 2, 3]",           # JSON list
    "true",                # JSON boolean
])
def test_load_state_non_dict_content_returns_empty(payload):
    """If state.json parses but isn't a dict (null/list/str/etc.), treat as empty.

    Without this guard, callers that do `state.get(...)` would AttributeError
    on a non-dict value. The outer try/except in session_start would catch
    it, but it's cleaner to handle the bad shape at the load site.
    """
    p = _telemetry._state_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(payload, encoding="utf-8")

    result = _telemetry._load_state()
    assert isinstance(result, dict), f"_load_state must always return dict, got {type(result).__name__}"
    assert result == {}, f"non-dict payload {payload!r} should be treated as empty state"


def test_concurrent_save_state_does_not_corrupt(tmp_path, monkeypatch):
    """Many threads writing state.json concurrently must always leave a valid JSON dict.

    With a shared tmp filename, two threads' concurrent writes could interleave
    bytes and produce a corrupt file. The unique-tmp-per-thread design prevents
    this. Worst case: last writer wins, but the visible state.json is always
    a valid, complete dict.
    """
    state_dir = tmp_path / ".agentsonar"
    monkeypatch.setattr(_telemetry, "_state_path", lambda: state_dir / "state.json")

    errors = []

    def writer(idx):
        try:
            for i in range(20):
                _telemetry._save_state({"writer_idx": idx, "iteration": i, "install_id": f"id-{idx}-{i}"})
        except Exception as e:
            errors.append(e)

    threads = [threading.Thread(target=writer, args=(i,)) for i in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert errors == [], f"concurrent writes raised: {errors}"

    # Final state file must be valid JSON dict (last writer wins).
    final = _telemetry._load_state()
    assert isinstance(final, dict)
    assert "writer_idx" in final
    assert "install_id" in final

    # No stray .tmp files should remain after all writers finished.
    leftover = list(state_dir.glob("*.tmp*"))
    assert leftover == [], f"unexpected tmp files left over: {leftover}"


def test_save_state_creates_parent_dir(monkeypatch, tmp_path):
    """If ~/.agentsonar/ doesn't exist yet, _save_state creates it."""
    nested = tmp_path / "deep" / "nested" / "dir" / ".agentsonar"
    monkeypatch.setattr(_telemetry, "_state_path", lambda: nested / "state.json")
    _telemetry._save_state({"x": 1})
    assert (nested / "state.json").exists()


def test_save_state_silent_on_permission_error(monkeypatch):
    """If the filesystem refuses writes, _save_state is silent (no raise)."""
    def boom(*a, **kw):
        raise PermissionError("read-only filesystem")
    monkeypatch.setattr(Path, "write_text", boom)
    # Must not raise
    _telemetry._save_state({"x": 1})


# ---------- install_id ----------

def test_ensure_install_id_generates_uuid():
    state: dict = {}
    install_id = _telemetry._ensure_install_id(state)
    assert isinstance(install_id, str)
    assert len(install_id) == 36  # standard UUID
    assert state["install_id"] == install_id


def test_ensure_install_id_persists():
    state: dict = {}
    id1 = _telemetry._ensure_install_id(state)
    id2 = _telemetry._ensure_install_id(_telemetry._load_state())
    assert id1 == id2, "install_id must persist across loads"


# ---------- enable / disable persistently ----------

def test_disable_persistently():
    _telemetry.disable_persistently()
    state = _telemetry._load_state()
    assert state["telemetry_disabled"] is True


def test_enable_persistently_clears_flag():
    _telemetry.disable_persistently()
    _telemetry.enable_persistently()
    state = _telemetry._load_state()
    assert "telemetry_disabled" not in state


def test_enable_persistently_when_no_flag_is_noop():
    """Calling enable_persistently() on fresh state should not error."""
    _telemetry.enable_persistently()  # must not raise
    assert _telemetry._load_state() == {}


# ---------- session_start ----------

def test_session_start_default_fires_event(monkeypatch):
    captured = []
    monkeypatch.setattr(_telemetry, "_post_event", lambda payload: captured.append(payload))

    _telemetry.session_start(adapter="custom_python", version="0.4.0")

    assert len(captured) == 1
    p = captured[0]
    assert p["adapter"] == "custom_python"
    assert p["version"] == "0.4.0"
    assert "install_id" in p
    assert "session_id" in p
    assert p["python"] == f"{sys.version_info.major}.{sys.version_info.minor}"


def test_session_start_skips_when_disabled_via_env(monkeypatch):
    captured = []
    monkeypatch.setattr(_telemetry, "_post_event", lambda payload: captured.append(payload))
    monkeypatch.setenv("AGENTSONAR_TELEMETRY", "off")

    _telemetry.session_start(adapter="custom_python", version="0.4.0")
    assert captured == []


def test_session_start_config_false_persists_disable(monkeypatch):
    captured = []
    monkeypatch.setattr(_telemetry, "_post_event", lambda payload: captured.append(payload))

    _telemetry.session_start(adapter="custom_python", version="0.4.0", config_pref=False)

    assert captured == []
    state = _telemetry._load_state()
    assert state["telemetry_disabled"] is True

    # Subsequent session_start (with no config_pref) should also skip
    _telemetry.session_start(adapter="custom_python", version="0.4.0")
    assert captured == []


def test_session_start_config_true_clears_persistent_disable(monkeypatch):
    captured = []
    monkeypatch.setattr(_telemetry, "_post_event", lambda payload: captured.append(payload))

    _telemetry.disable_persistently()  # turn it off
    _telemetry.session_start(adapter="custom_python", version="0.4.0", config_pref=True)

    assert len(captured) == 1, "config_pref=True must re-enable + fire"
    assert "telemetry_disabled" not in _telemetry._load_state()


def test_session_start_never_raises_on_internal_failure(monkeypatch):
    """Even if everything internal explodes, session_start swallows it."""
    def boom(*a, **kw):
        raise RuntimeError("simulated total failure")

    monkeypatch.setattr(_telemetry, "_load_state", boom)
    # Must not raise
    _telemetry.session_start(adapter="custom_python", version="0.4.0")


def test_session_start_silent_when_post_throws(monkeypatch):
    """If the HTTP layer raises during request building, no exception leaks."""
    def boom(payload):
        raise ConnectionError("network down")
    monkeypatch.setattr(_telemetry, "_post_event", boom)

    # Must not raise
    _telemetry.session_start(adapter="custom_python", version="0.4.0")


# ---------- disclosure message ----------

def test_disclosure_shown_once(monkeypatch, capsys):
    monkeypatch.setattr(_telemetry, "_post_event", lambda p: None)

    _telemetry.session_start(adapter="custom_python", version="0.4.0")
    first = capsys.readouterr().err

    _telemetry.session_start(adapter="custom_python", version="0.4.0")
    second = capsys.readouterr().err

    assert "AgentSonar 0.4.0" in first, "disclosure should print on first run"
    assert "AGENTSONAR_TELEMETRY=off" in first
    assert second == "", "disclosure should not repeat on second run"


def test_disclosure_reprints_after_state_deleted(monkeypatch, capsys):
    monkeypatch.setattr(_telemetry, "_post_event", lambda p: None)

    _telemetry.session_start(adapter="custom_python", version="0.4.0")
    capsys.readouterr()  # discard first

    # Delete the state file (the documented "start fresh" path)
    p = _telemetry._state_path()
    if p.exists():
        p.unlink()

    _telemetry.session_start(adapter="custom_python", version="0.4.0")
    after_delete = capsys.readouterr().err
    assert "AgentSonar 0.4.0" in after_delete, "disclosure should print again after state delete"


# ---------- HTTP layer (smoke test) ----------

def test_post_event_uses_daemon_thread(monkeypatch):
    """The POST must run in a daemon thread so it never blocks process exit."""
    captured_threads = []
    real_thread_init = threading.Thread.__init__

    def spy_init(self, *args, **kwargs):
        real_thread_init(self, *args, **kwargs)
        captured_threads.append(self)

    monkeypatch.setattr(threading.Thread, "__init__", spy_init)

    # Stub urlopen with a silent no-op response so the test doesn't actually
    # hit the network and doesn't generate spurious thread-exception warnings.
    class _NoopResp:
        def __enter__(self):
            return self
        def __exit__(self, *a):
            return False
        def read(self, n=0):
            return b""

    monkeypatch.setattr(_telemetry._urlrequest, "urlopen", lambda *a, **kw: _NoopResp())

    _telemetry._post_event({"install_id": "x", "session_id": "y", "version": "z"})

    assert any(t.daemon for t in captured_threads), "POST thread must be daemon"


def test_post_event_swallows_network_errors(monkeypatch):
    """When the network is down, the daemon thread must not propagate the error."""
    def fail(*a, **kw):
        raise ConnectionError("DNS resolution failed")

    monkeypatch.setattr(_telemetry._urlrequest, "urlopen", fail)

    # Run synchronously by stubbing Thread.start to call _send directly
    real_thread = threading.Thread

    class _SyncThread:
        def __init__(self, target=None, **kwargs):
            self._target = target

        def start(self):
            if self._target:
                self._target()  # must NOT raise out

    monkeypatch.setattr(_telemetry.threading, "Thread", _SyncThread)

    # Must not raise
    _telemetry._post_event({"install_id": "x", "session_id": "y", "version": "z"})


# ---------- end-to-end host-safety ----------

def test_engine_construction_not_blocked_by_broken_telemetry_session_start(monkeypatch):
    """If session_start() raises, the engine must continue normally."""
    monkeypatch.setattr(
        _telemetry,
        "session_start",
        lambda *a, **kw: (_ for _ in ()).throw(RuntimeError("simulated session_start failure")),
    )

    from agentsonar._core.engine import DetectionEngine
    e = DetectionEngine(
        config={"file_output": False, "console_output": False},
        adapter="custom_python",
    )
    assert e._adapter == "custom_python"


def test_engine_construction_not_blocked_by_broken_telemetry_import():
    """The cardinal-rule test: if `from agentsonar import _telemetry` itself
    fails (the module disappears or has an import-time error), the engine
    must STILL construct.

    This is the strongest version of the host-safety guarantee: detection
    survives even if telemetry is completely unloadable.
    """
    import sys as _sys

    # Save the real module, then clobber it so the lazy `from agentsonar
    # import _telemetry` inside DetectionEngine.__init__ raises ImportError.
    saved = _sys.modules.get("agentsonar._telemetry")
    _sys.modules["agentsonar._telemetry"] = None  # poisons the import

    try:
        # Force-reload engine.py so its top-level imports re-evaluate.
        # (We only need __init__ to run with the poisoned module, so just
        # re-imp the engine module is enough.)
        from agentsonar._core.engine import DetectionEngine

        e = DetectionEngine(
            config={"file_output": False, "console_output": False},
            adapter="custom_python",
        )
        assert e._adapter == "custom_python"
        # Engine should still be a real DetectionEngine, not degraded
        assert hasattr(e, "ingest"), "engine should still expose its full API"
    finally:
        # Restore so other tests (and the test runner) still work
        if saved is not None:
            _sys.modules["agentsonar._telemetry"] = saved
        else:
            _sys.modules.pop("agentsonar._telemetry", None)


def test_session_start_payload_shape(monkeypatch):
    """Verify the exact payload shape that hits the wire.

    A regression here would mean either:
    - A missing field (Worker would reject as invalid)
    - A new field accidentally exposing user data
    - Wrong types (Worker would silently drop)
    """
    captured = []
    monkeypatch.setattr(_telemetry, "_post_event", lambda payload: captured.append(payload))

    _telemetry.session_start(adapter="langgraph", version="0.4.0")

    assert len(captured) == 1
    p = captured[0]

    # Required field set is exactly this — no more, no less
    expected_keys = {
        "install_id", "session_id", "version", "python", "os", "arch", "adapter", "timestamp"
    }
    assert set(p.keys()) == expected_keys, (
        f"payload keys mismatch. Expected {expected_keys}, got {set(p.keys())}"
    )

    # Type sanity
    assert isinstance(p["install_id"], str) and len(p["install_id"]) == 36
    assert isinstance(p["session_id"], str) and len(p["session_id"]) == 36
    assert isinstance(p["version"], str)
    assert isinstance(p["python"], str)
    assert isinstance(p["os"], str)
    assert isinstance(p["arch"], str)
    assert isinstance(p["adapter"], str)
    assert isinstance(p["timestamp"], (int, float))
    assert p["timestamp"] > 0

    # Adapter string must match what was passed
    assert p["adapter"] == "langgraph"
    assert p["version"] == "0.4.0"


def test_unknown_adapter_string_passes_through(monkeypatch):
    """Future adapters that don't exist yet should still work; the Worker
    bucket-fills them as 'unknown' but the SDK doesn't gate on a whitelist.
    """
    captured = []
    monkeypatch.setattr(_telemetry, "_post_event", lambda payload: captured.append(payload))

    _telemetry.session_start(adapter="some_future_adapter", version="0.4.0")
    assert captured[0]["adapter"] == "some_future_adapter"


def test_monitor_orchestrator_adapter_kwarg_overrides_default(monkeypatch):
    """The OMA sidecar (and any other embedded context) needs to override
    the telemetry attribution string so its sessions show up under their
    actual adapter name, not 'custom_python'.
    """
    captured = []
    monkeypatch.setattr(_telemetry, "_post_event", lambda payload: captured.append(payload))

    from agentsonar import monitor_orchestrator
    sonar = monitor_orchestrator(
        config={"file_output": False, "console_output": False},
        adapter="oma_sidecar",
    )
    sonar.shutdown()

    assert len(captured) == 1
    assert captured[0]["adapter"] == "oma_sidecar"


def test_monitor_orchestrator_default_adapter_is_custom_python(monkeypatch):
    """Existing behavior: monitor_orchestrator() with no adapter kwarg
    must continue to attribute as 'custom_python' (backward compatibility).
    """
    captured = []
    monkeypatch.setattr(_telemetry, "_post_event", lambda payload: captured.append(payload))

    from agentsonar import monitor_orchestrator
    sonar = monitor_orchestrator(config={"file_output": False, "console_output": False})
    sonar.shutdown()

    assert len(captured) == 1
    assert captured[0]["adapter"] == "custom_python"


# ---------- "telemetry off means truly off" — observability invariants ----------

def test_env_off_makes_zero_network_calls(monkeypatch):
    """When AGENTSONAR_TELEMETRY=off, urlopen must NEVER be called."""
    monkeypatch.setenv("AGENTSONAR_TELEMETRY", "off")
    network_calls = []

    def explode_if_called(*args, **kwargs):
        network_calls.append(args)
        raise AssertionError("urlopen called despite telemetry being disabled")

    monkeypatch.setattr(_telemetry._urlrequest, "urlopen", explode_if_called)

    _telemetry.session_start(adapter="custom_python", version="0.4.0")
    assert network_calls == []


def test_dnt_makes_zero_network_calls(monkeypatch):
    """DO_NOT_TRACK=1 must produce zero network calls."""
    monkeypatch.setenv("DO_NOT_TRACK", "1")

    def explode_if_called(*args, **kwargs):
        raise AssertionError("urlopen called despite DNT")

    monkeypatch.setattr(_telemetry._urlrequest, "urlopen", explode_if_called)

    _telemetry.session_start(adapter="custom_python", version="0.4.0")


def test_env_off_writes_no_state_file(monkeypatch, tmp_path):
    """When telemetry is off via env BEFORE any state exists, no state file
    should be created. This is the "true privacy mode" path: zero disk
    artifacts left behind on the user's machine.
    """
    state_dir = tmp_path / ".agentsonar"
    state_path = state_dir / "state.json"
    monkeypatch.setattr(_telemetry, "_state_path", lambda: state_path)
    monkeypatch.setenv("AGENTSONAR_TELEMETRY", "off")

    assert not state_path.exists(), "precondition: state file should not exist"

    _telemetry.session_start(adapter="custom_python", version="0.4.0")

    assert not state_path.exists(), "telemetry-off must not create state.json"
    assert not state_dir.exists(), "telemetry-off must not even create the .agentsonar dir"


def test_dnt_writes_no_state_file(monkeypatch, tmp_path):
    """DO_NOT_TRACK=1 must also produce zero disk artifacts."""
    state_dir = tmp_path / ".agentsonar"
    state_path = state_dir / "state.json"
    monkeypatch.setattr(_telemetry, "_state_path", lambda: state_path)
    monkeypatch.setenv("DO_NOT_TRACK", "1")

    _telemetry.session_start(adapter="custom_python", version="0.4.0")

    assert not state_path.exists()
    assert not state_dir.exists()


def test_env_off_does_not_print_disclosure(monkeypatch, capsys):
    """The first-run disclosure message must NOT print when telemetry is off."""
    monkeypatch.setenv("AGENTSONAR_TELEMETRY", "off")
    monkeypatch.setattr(_telemetry, "_post_event", lambda payload: None)

    _telemetry.session_start(adapter="custom_python", version="0.4.0")

    captured = capsys.readouterr()
    assert captured.err == "", f"disclosure should be silent when off, but got: {captured.err!r}"
    assert captured.out == ""


def test_dnt_does_not_print_disclosure(monkeypatch, capsys):
    """DO_NOT_TRACK=1 must also suppress the disclosure message."""
    monkeypatch.setenv("DO_NOT_TRACK", "1")
    monkeypatch.setattr(_telemetry, "_post_event", lambda payload: None)

    _telemetry.session_start(adapter="custom_python", version="0.4.0")

    captured = capsys.readouterr()
    assert captured.err == ""


def test_persistent_disable_makes_zero_network_calls(monkeypatch):
    """A previously-set persistent disable (state file flag) must continue
    to produce zero network calls on subsequent runs.
    """
    _telemetry.disable_persistently()  # set the persistent flag

    def explode_if_called(*args, **kwargs):
        raise AssertionError("urlopen called despite persistent disable")

    monkeypatch.setattr(_telemetry._urlrequest, "urlopen", explode_if_called)

    _telemetry.session_start(adapter="custom_python", version="0.4.0")


def test_engine_fully_functional_with_telemetry_off(monkeypatch):
    """The cardinal observer-effect test:

    With telemetry disabled, the engine must:
    - construct without errors
    - ingest events
    - detect cycles
    - emit alerts
    - return summaries

    Telemetry off is a USER PREFERENCE; it must not degrade detection at all.
    """
    monkeypatch.setenv("AGENTSONAR_TELEMETRY", "off")

    from agentsonar._core.engine import DetectionEngine
    from agentsonar._core.models import InteractionEvent

    engine = DetectionEngine(
        config={
            "file_output": False,
            "console_output": False,
            "warning_threshold": 2,
            "critical_threshold": 4,
        },
        adapter="custom_python",
    )

    # Construct a cycle by repeating reviewer <-> generator
    alerts_seen = []
    for i in range(8):
        a = engine.ingest(InteractionEvent(source_agent="reviewer", target_agent="generator", timestamp=1000.0 + i))
        b = engine.ingest(InteractionEvent(source_agent="generator", target_agent="reviewer", timestamp=1000.5 + i))
        alerts_seen.extend(a)
        alerts_seen.extend(b)

    # Detection must still work
    assert len(alerts_seen) > 0, "detection must work with telemetry off"

    # Summary must be reachable
    summary = engine.get_summary()
    assert isinstance(summary, dict)
    assert summary.get("alerts_raised", 0) > 0

    engine.shutdown()


def test_all_three_adapters_construct_with_telemetry_off(monkeypatch):
    """Each public adapter must construct cleanly with telemetry off.

    This is the user-facing surface of the SDK. If telemetry-off breaks
    any adapter constructor, users hit it on import-time.
    """
    monkeypatch.setenv("AGENTSONAR_TELEMETRY", "off")

    # Custom Python adapter
    from agentsonar import monitor_orchestrator
    sonar1 = monitor_orchestrator(config={"file_output": False, "console_output": False})
    assert sonar1.engine._adapter == "custom_python"
    sonar1.shutdown()

    # CrewAI listener (only if extra installed; no-op if not)
    try:
        from agentsonar import AgentSonarListener
        try:
            sonar2 = AgentSonarListener(config={"file_output": False, "console_output": False})
            sonar2.shutdown()
        except RuntimeError:
            # CrewAI not installed in test env. That's fine.
            pass
    except ImportError:
        pass

    # LangGraph callback (only if extra installed)
    try:
        from agentsonar import AgentSonarCallback
        try:
            sonar3 = AgentSonarCallback(config={"file_output": False, "console_output": False})
            sonar3.shutdown()
        except RuntimeError:
            # langchain-core not installed
            pass
    except ImportError:
        pass


def test_telemetry_off_via_config_does_not_print_disclosure(monkeypatch, capsys):
    """config={'telemetry': False} should also suppress the disclosure message
    on the very same run it's set (the disable + suppress are atomic from
    the user's perspective).
    """
    monkeypatch.setattr(_telemetry, "_post_event", lambda payload: None)

    _telemetry.session_start(
        adapter="custom_python", version="0.4.0", config_pref=False
    )

    captured = capsys.readouterr()
    assert captured.err == "", "disclosure should be suppressed when config disables telemetry"


def test_kill_switch_AGENTSONAR_DISABLED_skips_telemetry(monkeypatch):
    """AGENTSONAR_DISABLED=1 (the production kill switch) returns NoOpEngine
    without ever touching telemetry. No state file, no network, no nothing.
    """
    monkeypatch.setenv("AGENTSONAR_DISABLED", "1")

    network_calls = []
    monkeypatch.setattr(
        _telemetry._urlrequest,
        "urlopen",
        lambda *a, **kw: network_calls.append(a),
    )

    from agentsonar._integrations._safe_engine import build_engine_safely
    engine = build_engine_safely({}, adapter="custom_python")

    # Should be a NoOp engine
    assert "NoOp" in type(engine).__name__ or hasattr(engine, "_disabled_reason")
    # And should not have triggered any network call
    assert network_calls == []
