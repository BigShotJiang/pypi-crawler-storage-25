"""
Invariants + lifecycle tests.

This module exists because the 0.4.2 release shipped four real bugs
that the existing example-based unit tests did NOT catch — they only
surfaced during playground / consumer integration testing. Each test
class below is named for the kind of bug it would have caught had it
existed pre-0.4.3, so future contributors can see the gap an
example-based test would leave.

Best-practice categories (informed by:
  - Hitchhiker's Guide to Python "Testing Your Code"
  - Real Python "Getting Started With Testing in Python"
  - Hypothesis property-based testing docs
  - pythonspeed.com on resource-leak detection in pytest):

  1. **Behavior-based tests** — encode product *intent*, not the
     adapter's internal flow. The pre-0.4.3 LangGraph self-loop test
     pinned the bug as desired behavior; a behavior test ("AgentSonar
     catches single-agent retry loops") would have failed instead.

  2. **Lifecycle / resource-leak tests** — assert pre/during/post
     state explicitly. The handler-leak bug shipped because no test
     ever checked bus state AFTER `shutdown()`.

  3. **Cross-instance tests** — multiple listeners in one process.
     The handler-leak's user-visible symptom (double-counting events
     across listeners) needed a test that constructs more than one.

  4. **Configuration matrix / isolation tests** — combinations of
     "feature on" + "feature off". The threshold-isolation bug shipped
     because no test asked "if I disable cycle detection via the
     threshold, does edge_anomaly still fire?".

  5. **Race / scheduling tests** — read state immediately after a
     burst of writes, no implicit drain. The thread-pool race shipped
     because every test path ran through `crew.kickoff()`'s teardown,
     which incidentally drained the bus.

  6. **Property-based tests (Hypothesis)** — invariants that should
     hold for ANY valid input. Catches edge cases human test authors
     don't think of.

Imports of `crewai` / `langchain_core` are guarded — modules that
need them skip if missing. Tests that need only the engine + custom
adapter run on a minimal install.
"""
from __future__ import annotations

import os
import threading
import time
from typing import Any

import pytest
from hypothesis import given, settings, strategies as st, HealthCheck

from agentsonar import CustomAdapter, monitor_orchestrator, PreventError
from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import InteractionEvent
from agentsonar._core.noop_engine import _NoOpEngine

_BASE_CONFIG = {"file_output": False, "console_output": False}


# =====================================================================
# 1. Behavior-based tests — encode product intent, not implementation.
#
# Each test names the user-visible promise AgentSonar makes ("retry
# storms must produce alerts"). When the implementation drifts away
# from the promise, these tests fail. When the implementation changes
# but still keeps the promise, these tests stay green.
#
# This is the test style that would have caught Item 3 (LangGraph
# self-loop filter) immediately.
# =====================================================================

class TestProductPromises:
    """Tests that pin the AgentSonar product *promises*, not how the
    code happens to be wired together this week."""

    def test_promise_repeated_self_delegation_produces_alert(self):
        """Promise: an agent stuck calling itself in a tight loop fires
        an alert. (Layer 1 / Layer 2 / Layer 3 all qualify — we don't
        care WHICH layer fires, just that something does.)

        This is the literal pitch on the website; it MUST be true. If
        it isn't, the whole product proposition is broken.
        """
        engine = DetectionEngine({**_BASE_CONFIG, "per_edge_limit": 3, "window_size": 60})
        try:
            for i in range(10):
                engine.ingest(InteractionEvent("agent_a", "agent_a", 1_700_000_000.0 + i * 0.05))
            summary = engine.get_summary()
            assert summary["alerts_raised"] >= 1, (
                "Tight self-loop did not fire any alerts. AgentSonar's "
                "core promise is to catch retry storms; if this assertion "
                "fails, single-agent retry loops are silent."
            )
        finally:
            engine.shutdown()

    def test_promise_three_node_cycle_produces_cycle_alert(self):
        """Promise: A → B → C → A repeated produces a cycle alert."""
        engine = DetectionEngine({
            **_BASE_CONFIG,
            "warning_threshold": 2,
            "critical_threshold": 5,
            "per_edge_limit": 999,  # disable Layer 1 to focus on cycle
        })
        try:
            ts = 1_700_000_000.0
            for r in range(5):
                for src, tgt in [("a", "b"), ("b", "c"), ("c", "a")]:
                    engine.ingest(InteractionEvent(src, tgt, ts))
                    ts += 0.1
            events = engine.get_recent_events()
            cycle_events = [e for e in events if e.failure_class.value == "cyclic_delegation"]
            assert cycle_events, "3-node cycle did not produce a cycle alert"
        finally:
            engine.shutdown()

    def test_promise_clean_run_produces_zero_alerts(self):
        """Promise: a linear pipeline with no failure pattern fires no
        alerts. False positives erode trust; they're as bad as misses."""
        engine = DetectionEngine(_BASE_CONFIG)
        try:
            engine.ingest(InteractionEvent("alice", "bob", 1_700_000_000.0))
            engine.ingest(InteractionEvent("bob", "carol", 1_700_000_001.0))
            engine.ingest(InteractionEvent("carol", "dave", 1_700_000_002.0))
            assert engine.get_summary()["alerts_raised"] == 0
        finally:
            engine.shutdown()

    def test_promise_prevent_mode_propagates_only_prevent_error(self):
        """Promise: when Prevent Mode is configured, the user catches
        exactly ONE exception type — `PreventError`. Bad config, bad
        input, internal failures all stay swallowed."""
        sonar = monitor_orchestrator({
            **_BASE_CONFIG,
            "warning_threshold": 1,
            "critical_threshold": 3,
            "prevent": {"cyclic_delegation": {"max_rotations": 4}},
        })
        try:
            caught: PreventError | None = None
            with pytest.raises(PreventError) as exc_info:
                for _ in range(20):
                    sonar.delegation("a", "b")
                    sonar.delegation("b", "c")
                    sonar.delegation("c", "a")
            caught = exc_info.value
            assert isinstance(caught, PreventError)
            assert caught.failure_class == "cyclic_delegation"
        finally:
            sonar.shutdown()


# =====================================================================
# 2. Lifecycle / resource-leak tests.
#
# The handler-leak bug shipped because the existing test suite never
# checked engine / bus state AFTER `shutdown()`. These assertions are
# the ones that would have caught Item 1.
# =====================================================================

class TestLifecycleInvariants:
    """Pre / during / post state for the adapter's resources."""

    def test_engine_post_shutdown_returns_safe_summary(self):
        """After `shutdown()`, `get_summary()` must not raise — a
        host-safety contract. Returns whatever the engine has, even
        if internally degraded."""
        engine = DetectionEngine(_BASE_CONFIG)
        engine.shutdown()
        result = engine.get_summary()
        assert isinstance(result, dict)
        assert "total_events" in result

    def test_engine_post_shutdown_ingest_does_not_raise(self):
        """Late events arriving after shutdown (race, queued event,
        teardown order) must not crash the host. They may be silently
        dropped."""
        engine = DetectionEngine(_BASE_CONFIG)
        engine.shutdown()
        # Should not raise
        engine.ingest(InteractionEvent("a", "b", 1_700_000_000.0))

    def test_double_shutdown_idempotent(self):
        """Shutdown is the LAST call the host makes; a crash here
        turns a successful run into a confusing teardown traceback.
        Multiple calls must be safe."""
        engine = DetectionEngine(_BASE_CONFIG)
        engine.shutdown()
        engine.shutdown()  # must not raise
        engine.shutdown()  # nor this

    def test_shutdown_drains_in_flight_alerts(self):
        """Promise: anything that fired BEFORE shutdown() is reflected
        in the post-shutdown summary."""
        engine = DetectionEngine({**_BASE_CONFIG, "per_edge_limit": 2, "window_size": 60})
        try:
            for i in range(10):
                engine.ingest(InteractionEvent("a", "b", 1_700_000_000.0 + i * 0.05))
            pre_shutdown_alerts = engine.get_summary()["alerts_raised"]
            engine.shutdown()
            post_shutdown_alerts = engine.get_summary()["alerts_raised"]
            assert post_shutdown_alerts >= pre_shutdown_alerts
        except Exception:
            engine.shutdown()
            raise


# =====================================================================
# 3. Cross-instance tests.
#
# The handler-leak bug's *symptom* (double-counting events across
# multiple listeners) needs a test that constructs more than one
# listener / engine. The pre-0.4.3 suite never did.
# =====================================================================

class TestCrossInstanceIsolation:
    """Multiple listeners / engines in one process MUST NOT bleed state
    into each other."""

    def test_multiple_engines_are_independent(self):
        """Two engines see only their own events."""
        e1 = DetectionEngine(_BASE_CONFIG)
        e2 = DetectionEngine(_BASE_CONFIG)
        try:
            e1.ingest(InteractionEvent("a", "b", 1_700_000_000.0))
            e1.ingest(InteractionEvent("b", "c", 1_700_000_001.0))
            e2.ingest(InteractionEvent("x", "y", 1_700_000_002.0))

            assert e1.get_summary()["total_events"] == 2
            assert e2.get_summary()["total_events"] == 1
        finally:
            e1.shutdown()
            e2.shutdown()

    def test_shutdown_engine_is_isolated_from_live_engine(self):
        """A1 shut down → A2 created → ingests on A2 don't hit A1.
        This is the user-visible symptom of CrewAI handler leak (Item 1)
        — the assertion catches it at the engine layer too."""
        e1 = DetectionEngine(_BASE_CONFIG)
        e1.ingest(InteractionEvent("a", "b", 1_700_000_000.0))
        e1.shutdown()
        e1_count_before = e1.get_summary()["total_events"]

        e2 = DetectionEngine(_BASE_CONFIG)
        try:
            e2.ingest(InteractionEvent("a", "b", 1_700_000_001.0))
            # e1's count must not grow
            assert e1.get_summary()["total_events"] == e1_count_before
            assert e2.get_summary()["total_events"] == 1
        finally:
            e2.shutdown()

    def test_thousand_engines_no_resource_leak(self):
        """1000 engines created, used briefly, shut down. No assertion
        on memory directly — but if there's an unbounded resource
        leak, this test will OOM or take far too long. Acts as a
        canary for handler / file-handle / lock leaks."""
        for i in range(1000):
            e = DetectionEngine(_BASE_CONFIG)
            e.ingest(InteractionEvent("a", "b", 1_700_000_000.0 + i))
            e.shutdown()
        # If we got here without OOM or timeout, leak tests pass.
        assert True


# =====================================================================
# 4. Configuration matrix / isolation tests.
#
# The threshold-confusion bug (Item 2) shipped because no test set
# "feature A high, feature B low" and verified each independently.
# These tests would have caught it on day one.
# =====================================================================

class TestConfigurationIsolation:
    """User can disable / configure one detector independently of others."""

    def test_disabling_cycle_thresholds_does_not_disable_edge_anomaly(self):
        """Item 2 regression. A user who sets
        `cycle_warning_threshold=999` to silence cycles MUST still see
        edge_anomaly alerts at the generic warning_threshold."""
        engine = DetectionEngine({
            **_BASE_CONFIG,
            "warning_threshold": 2,
            "critical_threshold": 5,
            "cycle_warning_threshold": 999,
            "cycle_critical_threshold": 9999,
            "hard_weight_limit": 5.0,
            "per_edge_limit": 999,  # disable Layer 1 too for clarity
        })
        try:
            ts = 1_700_000_000.0
            for _ in range(15):
                engine.ingest(InteractionEvent("a", "b", ts))
                engine.ingest(InteractionEvent("b", "a", ts + 0.05))
                ts += 0.1
            events = engine.get_recent_events()
            cycle_events = [e for e in events if e.failure_class.value == "cyclic_delegation"]
            edge_events = [e for e in events if e.failure_class.value == "repetitive_delegation"]
            assert cycle_events == [], "cycle_warning_threshold=999 should suppress cycle"
            assert edge_events, "edge_anomaly must still fire at generic threshold"
        finally:
            engine.shutdown()

    def test_disabling_edge_anomaly_thresholds_does_not_disable_cycle(self):
        """Mirror: disabling edge_anomaly leaves cycle alerts firing."""
        engine = DetectionEngine({
            **_BASE_CONFIG,
            "warning_threshold": 2,
            "critical_threshold": 5,
            "edge_anomaly_warning_threshold": 9999,
            "edge_anomaly_critical_threshold": 99999,
            "hard_weight_limit": 5.0,
            "per_edge_limit": 999,
        })
        try:
            ts = 1_700_000_000.0
            for _ in range(15):
                engine.ingest(InteractionEvent("a", "b", ts))
                engine.ingest(InteractionEvent("b", "a", ts + 0.05))
                ts += 0.1
            events = engine.get_recent_events()
            cycle_events = [e for e in events if e.failure_class.value == "cyclic_delegation"]
            edge_events = [e for e in events if e.failure_class.value == "repetitive_delegation"]
            assert cycle_events, "cycle must still fire at generic threshold"
            assert edge_events == [], "edge_anomaly suppressed by override"
        finally:
            engine.shutdown()

    def test_per_pattern_thresholds_dont_affect_each_other(self):
        """Setting a per-pattern threshold for cycle MUST NOT bleed
        into edge_anomaly's resolution and vice versa."""
        engine = DetectionEngine({
            **_BASE_CONFIG,
            "warning_threshold": 5,
            "critical_threshold": 15,
            "cycle_warning_threshold": 1,
            "cycle_critical_threshold": 3,
            # edge_anomaly_*_threshold UNSET → falls back to generic
        })
        try:
            assert engine._cycle_warning_threshold == 1
            assert engine._cycle_critical_threshold == 3
            assert engine._edge_anomaly_warning_threshold == 5  # generic fallback
            assert engine._edge_anomaly_critical_threshold == 15
        finally:
            engine.shutdown()


# =====================================================================
# 5. Race / scheduling tests.
#
# The thread-pool race (Item 4) shipped because every existing test
# path implicitly drained the bus via `crew.kickoff()` teardown. Tests
# that read state IMMEDIATELY after writes — no implicit drain — would
# have caught it.
# =====================================================================

class TestImmediateReadAfterWrite:
    """`get_summary()` after a burst of `ingest()` must reflect the
    full count even on engines that schedule work asynchronously."""

    def test_summary_consistent_immediately_after_ingest(self):
        """No race: 100 ingests, immediate read, count is exactly 100.
        The engine's lock + sync ingest path makes this trivially true
        for the engine alone — but the same property MUST hold at the
        adapter layer too. Pin it here as documentation of the
        contract."""
        engine = DetectionEngine(_BASE_CONFIG)
        try:
            for i in range(100):
                engine.ingest(InteractionEvent(f"a{i % 5}", f"b{i % 5}", 1_700_000_000.0 + i))
            assert engine.get_summary()["total_events"] == 100
        finally:
            engine.shutdown()

    def test_summary_consistent_under_concurrent_ingest(self):
        """Threading stress: N threads × M ingests each. Total events
        equals N×M after all threads complete. No locks dropped, no
        events lost. (Engine uses a recursive lock with timeout; this
        verifies the lock is correct.)"""
        engine = DetectionEngine(_BASE_CONFIG)
        threads_n = 4
        per_thread = 50

        def worker(tid: int) -> None:
            for i in range(per_thread):
                engine.ingest(InteractionEvent(f"src_{tid}", f"tgt_{i % 3}", 1_700_000_000.0 + i))

        threads = [threading.Thread(target=worker, args=(t,)) for t in range(threads_n)]
        try:
            for t in threads:
                t.start()
            for t in threads:
                t.join(timeout=10)
                assert not t.is_alive(), "thread did not complete in 10s — possible deadlock"

            assert engine.get_summary()["total_events"] == threads_n * per_thread
        finally:
            engine.shutdown()


# =====================================================================
# 6. Property-based tests (Hypothesis).
#
# Express invariants that should hold for ANY valid input. Hypothesis
# generates random inputs and shrinks failures down to a minimal
# example. Catches edge cases human authors don't think of (the bugs
# we caught in the playground all fall into this category).
# =====================================================================

# Strategies for generating valid inputs.
_agent_name_st = st.text(
    alphabet=st.characters(min_codepoint=33, max_codepoint=126, blacklist_characters="<>\"'"),
    min_size=1,
    max_size=20,
)
_timestamp_st = st.floats(min_value=1_700_000_000.0, max_value=2_000_000_000.0, allow_nan=False, allow_infinity=False)


class TestPropertyBasedInvariants:
    """Properties that must hold for ALL valid inputs."""

    @given(
        events=st.lists(
            st.tuples(_agent_name_st, _agent_name_st, _timestamp_st),
            min_size=0,
            max_size=200,
        )
    )
    @settings(max_examples=50, deadline=None, suppress_health_check=[HealthCheck.too_slow])
    def test_invariant_engine_never_raises_to_caller(self, events):
        """For ANY valid sequence of events, ingest() never propagates
        an exception. This is the prime directive ("observability must
        never break the observed"). Hypothesis explores the input
        space; if any combination breaks the invariant, the test
        shrinks to a minimal failing example."""
        engine = DetectionEngine(_BASE_CONFIG)
        try:
            for src, tgt, ts in events:
                # Must not raise
                result = engine.ingest(InteractionEvent(src, tgt, ts))
                assert isinstance(result, list)
            # Final state must always be readable
            summary = engine.get_summary()
            assert isinstance(summary, dict)
            assert summary["total_events"] == len(events)
        finally:
            engine.shutdown()

    @given(
        warning=st.integers(min_value=1, max_value=100),
        critical=st.integers(min_value=1, max_value=100),
    )
    @settings(max_examples=30, deadline=None)
    def test_invariant_get_summary_always_returns_valid_dict(self, warning, critical):
        """For ANY threshold combination (including invalid ones like
        critical < warning), `get_summary()` returns a valid dict
        without raising. Edge case the existing tests didn't cover."""
        if critical < warning:
            critical = warning + 1  # AlertStateManager's invariant; bypass
        engine = DetectionEngine({
            **_BASE_CONFIG,
            "warning_threshold": warning,
            "critical_threshold": critical,
        })
        try:
            for i in range(20):
                engine.ingest(InteractionEvent("a", "b", 1_700_000_000.0 + i))
            summary = engine.get_summary()
            assert isinstance(summary, dict)
            assert summary["total_events"] == 20
            assert "alerts_raised" in summary
        finally:
            engine.shutdown()

    @given(
        bad_input=st.one_of(
            st.none(),
            st.integers(),
            st.floats(allow_nan=True, allow_infinity=True),
            st.text(max_size=10_000),
            st.lists(st.integers()),
            st.dictionaries(st.text(), st.integers()),
        )
    )
    @settings(max_examples=30, deadline=None)
    def test_invariant_garbage_inputs_never_crash_custom_adapter(self, bad_input):
        """For ANY garbage input as source / target, the adapter never
        raises. Covers the host-safety contract end-to-end."""
        sonar = monitor_orchestrator(_BASE_CONFIG)
        try:
            sonar.delegation(bad_input, "valid_target")
            sonar.delegation("valid_source", bad_input)
            sonar.delegation(bad_input, bad_input)
        except PreventError:
            # Expected if Prevent Mode is configured + tripped; not the
            # case here (no prevent config) so this branch shouldn't fire.
            raise
        finally:
            sonar.shutdown()

    @given(events=st.lists(st.tuples(_agent_name_st, _agent_name_st), min_size=1, max_size=50))
    @settings(max_examples=30, deadline=None)
    def test_invariant_total_events_equals_ingest_count(self, events):
        """For ANY event sequence, summary.total_events == number of
        successful ingests. No silent drops."""
        engine = DetectionEngine(_BASE_CONFIG)
        try:
            ts = 1_700_000_000.0
            for src, tgt in events:
                engine.ingest(InteractionEvent(src, tgt, ts))
                ts += 0.01
            assert engine.get_summary()["total_events"] == len(events)
        finally:
            engine.shutdown()


# =====================================================================
# 7. Kill-switch invariants.
#
# `AGENTSONAR_DISABLED=1` is the production safety valve; it MUST
# completely no-op the engine without breaking the host's code path.
# =====================================================================

class TestKillSwitchInvariants:

    def test_kill_switch_returns_noop_engine(self, monkeypatch):
        monkeypatch.setenv("AGENTSONAR_DISABLED", "1")
        sonar = monitor_orchestrator(_BASE_CONFIG)
        try:
            assert isinstance(sonar.engine, _NoOpEngine)
            # Health check reflects degraded state
            assert sonar.health_check()["degraded"] is True
            assert "AGENTSONAR_DISABLED" in sonar.health_check().get("reason", "")
        finally:
            sonar.shutdown()

    def test_kill_switch_swallows_all_delegations(self, monkeypatch):
        monkeypatch.setenv("AGENTSONAR_DISABLED", "1")
        sonar = monitor_orchestrator({
            **_BASE_CONFIG,
            "warning_threshold": 1,
            "critical_threshold": 2,
            "prevent": {"cyclic_delegation": {"max_rotations": 2}},
        })
        try:
            # In degraded mode, even cycle-forming delegations don't
            # raise PreventError (the engine is a NoOp).
            for _ in range(20):
                sonar.delegation("a", "b")
                sonar.delegation("b", "c")
                sonar.delegation("c", "a")
            # No alerts because the engine is a NoOp.
            assert sonar.get_summary()["alerts_raised"] == 0
        finally:
            sonar.shutdown()

    @given(garbage=st.one_of(st.none(), st.integers(), st.text(max_size=20)))
    @settings(
        max_examples=10,
        deadline=None,
        # `monkeypatch` is function-scoped; Hypothesis warns by default.
        # Safe to suppress here because we set the env var once and the
        # garbage input is what varies across examples — the fixture's
        # state is invariant across the whole test function.
        suppress_health_check=[HealthCheck.function_scoped_fixture],
    )
    def test_kill_switch_with_any_garbage_input_still_safe(self, monkeypatch, garbage):
        """Hypothesis: under kill switch + any garbage input, never crash."""
        monkeypatch.setenv("AGENTSONAR_DISABLED", "1")
        sonar = monitor_orchestrator(_BASE_CONFIG)
        try:
            sonar.delegation(garbage, "x")
            sonar.delegation("y", garbage)
        finally:
            sonar.shutdown()


# =====================================================================
# 8. CrewAI listener — handler-registry leak detection.
#
# This is THE bug Item 1 fixes. Skipped if crewai isn't installed.
# Pre-0.4.3 these would have caught the leak immediately.
# =====================================================================

crewai = pytest.importorskip("crewai", reason="CrewAI listener tests require crewai")
from crewai.events import crewai_event_bus  # noqa: E402
from crewai.events.event_types import ToolUsageStartedEvent  # noqa: E402

from agentsonar._integrations.crewai_listener import AgentSonarListener  # noqa: E402


@pytest.fixture(autouse=True)
def _clean_bus_between_tests():
    """Reset the bus between tests so a leftover handler from one test
    can't contaminate the next. This is the test-suite analog of the
    user-facing handler-unregister behavior we rely on."""
    crewai_event_bus._sync_handlers.clear()
    if hasattr(crewai_event_bus, "_async_handlers"):
        crewai_event_bus._async_handlers.clear()
    if hasattr(crewai_event_bus, "_shutting_down"):
        crewai_event_bus._shutting_down = False
    yield
    crewai_event_bus._sync_handlers.clear()
    if hasattr(crewai_event_bus, "_async_handlers"):
        crewai_event_bus._async_handlers.clear()
    if hasattr(crewai_event_bus, "_shutting_down"):
        crewai_event_bus._shutting_down = False


class TestCrewAIHandlerRegistryInvariants:
    """The bus's handler set is a finite resource; AgentSonarListener
    instances must add and remove themselves cleanly."""

    def test_handler_count_zero_before_any_listener(self):
        """Pre-condition for the rest of the tests in this class."""
        assert len(crewai_event_bus._sync_handlers.get(ToolUsageStartedEvent, set())) == 0

    def test_init_adds_exactly_one_handler(self):
        listener = AgentSonarListener(config=_BASE_CONFIG)
        try:
            count = len(crewai_event_bus._sync_handlers.get(ToolUsageStartedEvent, set()))
            assert count == 1
        finally:
            listener.shutdown()

    def test_shutdown_removes_handler(self):
        """Post-shutdown invariant: bus state matches pre-init state."""
        before = len(crewai_event_bus._sync_handlers.get(ToolUsageStartedEvent, set()))
        listener = AgentSonarListener(config=_BASE_CONFIG)
        listener.shutdown()
        after = len(crewai_event_bus._sync_handlers.get(ToolUsageStartedEvent, set()))
        assert after == before, (
            "Handler leaked: shutdown didn't unregister. This is the "
            "bug Item 1 fixes; the test fails on pre-0.4.3 code."
        )

    def test_n_listeners_each_register_and_clean_up(self):
        """Stress: 50 listener constructions + shutdowns. Final count
        must equal initial count (zero leak across many instances)."""
        before = len(crewai_event_bus._sync_handlers.get(ToolUsageStartedEvent, set()))
        for _ in range(50):
            listener = AgentSonarListener(config=_BASE_CONFIG)
            listener.shutdown()
        after = len(crewai_event_bus._sync_handlers.get(ToolUsageStartedEvent, set()))
        assert after == before, (
            f"Leaked {after - before} handlers across 50 instances. "
            "Indicates an unbounded-growth bug in the registry."
        )

    def test_two_listeners_in_sequence_dont_double_count(self):
        """Item 1's user-visible symptom. Listener A is shut down →
        listener B exists alone. Emit one event. B sees 1, not 2."""
        a = AgentSonarListener(config=_BASE_CONFIG)
        a.shutdown()

        b = AgentSonarListener(config=_BASE_CONFIG)
        try:
            event = ToolUsageStartedEvent(
                tool_name="delegate work",
                tool_args={"coworker": "b"},
                agent_role="a",
            )
            crewai_event_bus.emit(source=None, event=event)
            crewai_event_bus.flush()
            assert b.get_summary()["total_events"] == 1
        finally:
            b.shutdown()
