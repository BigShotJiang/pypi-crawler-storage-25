"""Pytest configuration shared across the AgentSonar test suite.

Two responsibilities:

1. Disable session-event telemetry for the entire test run. Pytest
   imports conftest.py before any test module, so by the time a test
   constructs a ``DetectionEngine``, the env var is already set and
   telemetry skips its work cleanly. Without this every test that
   constructs an engine would print the first-run disclosure message
   to stderr, create ``~/.agentsonar/state.json`` on the dev machine,
   and fire a fire-and-forget HTTP request that silently fails.

2. Strip every ``AGENTSONAR_*`` tuning env var from the pytest
   environment BEFORE any test runs. When a developer adds detection
   tuning to their own ``.claude/settings.json`` (which Claude Code
   then exports into the shell env for any child process), those env
   vars leak into pytest and override the threshold values the
   individual tests expect. Tests would pass on CI (where the env is
   clean) and fail locally for that developer alone — a frustrating
   reproducibility gap. We strip these once at conftest load, before
   any test imports the SDK, so test expectations are honored
   regardless of the dev's session config.

Set ``AGENTSONAR_TELEMETRY=on`` explicitly if you ever need to test
the telemetry path itself.
"""
from __future__ import annotations

import os

os.environ.setdefault("AGENTSONAR_TELEMETRY", "off")

# Strip detection-tuning env vars that the developer's .claude/settings.json
# might have set. Tests that need specific values use monkeypatch to set
# them per-test; that's properly isolated. The leak comes from env vars
# inherited at process start, which monkeypatch can't see and therefore
# can't restore — so we just remove them up front.
_TUNING_ENV_VARS = (
    "AGENTSONAR_REGULATED",
    "AGENTSONAR_WARNING_THRESHOLD",
    "AGENTSONAR_CRITICAL_THRESHOLD",
    "AGENTSONAR_CYCLE_WARNING_THRESHOLD",
    "AGENTSONAR_CYCLE_CRITICAL_THRESHOLD",
    "AGENTSONAR_EDGE_ANOMALY_WARNING_THRESHOLD",
    "AGENTSONAR_EDGE_ANOMALY_CRITICAL_THRESHOLD",
    "AGENTSONAR_HARD_WEIGHT_LIMIT",
    "AGENTSONAR_PER_EDGE_LIMIT",
    "AGENTSONAR_GLOBAL_LIMIT",
    "AGENTSONAR_RATE_WINDOW_SECONDS",
    "AGENTSONAR_RATE_RESET_RATIO",
    "AGENTSONAR_PREVENT_CYCLE_MAX_ROTATIONS",
    "AGENTSONAR_PREVENT_REPETITIVE_MAX_EVENTS",
    "AGENTSONAR_PREVENT_RATE_LIMIT",
    "AGENTSONAR_PREVENT_ALL",
    "AGENTSONAR_INACTIVITY_SECONDS",
    "AGENTSONAR_LOCK_TIMEOUT_SECONDS",
    "AGENTSONAR_ARCHIVE_RETENTION_DAYS",
)
for _var in _TUNING_ENV_VARS:
    os.environ.pop(_var, None)
