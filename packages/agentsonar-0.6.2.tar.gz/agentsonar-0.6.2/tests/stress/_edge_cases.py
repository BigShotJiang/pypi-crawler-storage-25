"""
Pre-publish edge-case verification for the Claude Code adapter.
Runs in-process so paths are Windows-native. Five scenarios:

  E1. Mixed-tool session: Read + Bash + Edit + MCP → 4 different
      target_agent name shapes (path, fingerprint, path, fingerprint).
  E2. AGENTSONAR_REGULATED=1 end-to-end: sentinel path is hashed in
      every persisted artifact (timeline + state.pkl + report.html).
  E3. Subagent firing Read: source_agent is subagent_<task_id>,
      target is Read:<file_path>.
  E4. Backward compat: a prior-release state.pkl loads cleanly under
      current code (fingerprint-format edges in saved state don't break).
  E5. Special chars in file_path: Windows backslashes, spaces, unicode.

Run manually from the repo root:
    python tests/stress/_edge_cases.py
"""
from __future__ import annotations

import json
import os
import pickle
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "src"))
from agentsonar._integrations.claude import adapter as cc


def setup_tmp() -> Path:
    tmp = Path(tempfile.mkdtemp())
    os.environ["AGENTSONAR_CLAUDE_CODE_ROOT"] = str(tmp)
    os.environ["AGENTSONAR_TELEMETRY"] = "off"
    return tmp


def banner(name: str) -> None:
    print(f"\n=== {name} ===")


def e1_mixed_tools() -> None:
    banner("E1: mixed-tool session (Read + Bash + Edit + MCP)")
    tmp = setup_tmp()
    sid = "mixed-tools-e1"

    payloads = [
        ("Read", {"file_path": "/src/hello.py"}),
        ("Bash", {"command": "ls -la"}),
        ("Edit", {"file_path": "/src/goodbye.py", "old_string": "x", "new_string": "y"}),
        ("mcp__github__create_issue", {"title": "t", "body": "b"}),
        ("WebFetch", {"url": "https://example.com"}),
    ]
    for tool, ti in payloads:
        cc.handle_hook("PreToolUse", {
            "session_id": sid,
            "parent_session_id": None,
            "tool_name": tool,
            "tool_input": ti,
        })

    timeline = tmp / "sessions" / sid / "timeline.jsonl"
    print(f"  {'tool_name':35s} -> target_agent")
    print(f"  {'-' * 35}    {'-' * 30}")
    for line in timeline.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        rec = json.loads(line)
        tool = rec["metadata"]["tool_name"]
        tgt = rec["target_agent"]
        print(f"  {tool:35s} -> {tgt}")

    expected = {
        "Read": "Read:/src/hello.py",
        "Edit": "Edit:/src/goodbye.py",
    }
    fp_expected_tools = {"Bash", "mcp__github__create_issue", "WebFetch"}

    for line in timeline.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        rec = json.loads(line)
        tool = rec["metadata"]["tool_name"]
        tgt = rec["target_agent"]
        if tool in expected:
            assert tgt == expected[tool], f"{tool}: expected {expected[tool]!r}, got {tgt!r}"
        elif tool in fp_expected_tools:
            assert tgt.startswith(f"{tool}:"), f"{tool}: expected {tool}: prefix, got {tgt!r}"
            tail = tgt.split(":", 1)[1]
            assert len(tail) == 8 and all(c in "0123456789abcdef" for c in tail), (
                f"{tool}: expected 8 hex tail, got {tail!r}"
            )
    print("  PASS: path-bearing tools use file paths; non-path tools use 8-char fingerprints")


def e2_regulated_mode_end_to_end() -> None:
    banner("E2: AGENTSONAR_REGULATED=1 end-to-end content-blind audit")
    tmp = setup_tmp()
    os.environ["AGENTSONAR_REGULATED"] = "1"
    try:
        sid = "regulated-e2"
        sentinel = "PROD_API_KEY_PATH_SENTINEL"
        for _ in range(15):
            cc.handle_hook("PreToolUse", {
                "session_id": sid,
                "parent_session_id": None,
                "tool_name": "Read",
                "tool_input": {"file_path": f"/secrets/{sentinel}.py"},
            })
        cc.handle_hook("Stop", {"session_id": sid, "parent_session_id": None})

        leaks = []
        for p in tmp.rglob("*"):
            if p.is_file():
                try:
                    contents = p.read_bytes()
                except Exception:
                    continue
                if sentinel.encode("utf-8") in contents:
                    leaks.append(str(p))
        if leaks:
            print(f"  FAIL: cleartext path leaked into {len(leaks)} file(s):")
            for l in leaks:
                print(f"    {l}")
            raise AssertionError(f"AGENTSONAR_REGULATED leaked sentinel into: {leaks}")
        print(f"  PASS: no cleartext path on disk across {sum(1 for p in tmp.rglob('*') if p.is_file())} files")

        timeline = tmp / "sessions" / sid / "timeline.jsonl"
        first_rec = json.loads(timeline.read_text(encoding="utf-8").splitlines()[0])
        target = first_rec["target_agent"]
        print(f"  edge name under regulated: {target}")
        assert target.startswith("Read:path:"), f"regulated edge should be Read:path:<hash>, got {target}"
        assert sentinel not in target
        print("  PASS: edge name uses hashed form, not cleartext")
    finally:
        os.environ.pop("AGENTSONAR_REGULATED", None)


def e3_subagent_edge() -> None:
    banner("E3: subagent firing Read")
    tmp = setup_tmp()
    sid_root = "root-sess-abcdef12345"
    sid_sub = "sub-sess-12345678abc"

    cc.handle_hook("PreToolUse", {
        "session_id": sid_sub,
        "parent_session_id": sid_root,
        "tool_name": "Read",
        "tool_input": {"file_path": "/src/subagent-read.py"},
    })

    timeline = tmp / "sessions" / sid_root / "timeline.jsonl"
    rec = json.loads(timeline.read_text(encoding="utf-8").splitlines()[0])
    print(f"  source_agent: {rec['source_agent']}")
    print(f"  target_agent: {rec['target_agent']}")
    print(f"  source_session_id: {rec['source_session_id']}")
    print(f"  root_session_id: {rec['root_session_id']}")
    assert rec["source_agent"] == "subagent_sub-sess", (
        f"subagent source should be subagent_<8-char>, got {rec['source_agent']!r}"
    )
    assert rec["target_agent"] == "Read:/src/subagent-read.py"
    assert rec["root_session_id"] == sid_root
    print("  PASS: subagent source_agent + file-path target_agent both correct")


def e4_backward_compat_with_05_state() -> None:
    banner("E4: backward compat: 0.5.0-style state.pkl loads under 0.5.1")
    tmp = setup_tmp()
    sid = "back-compat-e4"
    session_dir = tmp / "sessions" / sid
    session_dir.mkdir(parents=True, exist_ok=True)

    cc.handle_hook("PreToolUse", {
        "session_id": sid,
        "parent_session_id": None,
        "tool_name": "Read",
        "tool_input": {"file_path": "/src/old.py"},
    })

    state = pickle.loads((session_dir / "state.pkl").read_bytes())
    print(f"  state.pkl schema_version: {state.get('schema_version')!r}")
    print(f"  state.pkl size: {(session_dir / 'state.pkl').stat().st_size} bytes")
    assert state.get("schema_version") == "1.0.0", "schema_version regressed"

    cc.handle_hook("PreToolUse", {
        "session_id": sid,
        "parent_session_id": None,
        "tool_name": "Read",
        "tool_input": {"file_path": "/src/old.py"},
    })
    lines = (session_dir / "timeline.jsonl").read_text(encoding="utf-8").splitlines()
    print(f"  events after reload: {len(lines)}")
    assert len(lines) == 2
    print("  PASS: state.pkl round-trip preserves engine across upgrade boundary")


def e5_special_chars_in_path() -> None:
    banner("E5: special characters in file_path")
    tmp = setup_tmp()
    cases = [
        ("windows-backslash", r"C:\Users\srini\src\hello.py"),
        ("spaces-in-path", "/home/user/My Documents/notes.py"),
        ("unicode-path", "/src/日本語/файл.py"),
        ("colon-in-path-unusual", "C:/strange:colon/file.py"),
    ]
    for label, fp in cases:
        sid = f"special-{label}"
        rc = cc.handle_hook("PreToolUse", {
            "session_id": sid,
            "parent_session_id": None,
            "tool_name": "Read",
            "tool_input": {"file_path": fp},
        })
        assert rc == 0, f"{label}: hook returned {rc}"

        timeline = tmp / "sessions" / sid / "timeline.jsonl"
        if not timeline.exists():
            raise AssertionError(f"{label}: timeline missing for path {fp!r}")
        rec = json.loads(timeline.read_text(encoding="utf-8").splitlines()[0])
        tgt = rec["target_agent"]
        if tgt != f"Read:{fp}":
            raise AssertionError(f"{label}: target_agent roundtrip lost: {tgt!r} != Read:{fp!r}")
        # Windows console (charmap codec) crashes on unicode chars in print.
        # ascii(...) escapes non-ASCII so the line is always printable.
        print(f"  [{label}] target_agent = {ascii(tgt)}")
    print("  PASS: all special-char paths roundtrip correctly")


def main() -> int:
    tests = [
        e1_mixed_tools,
        e2_regulated_mode_end_to_end,
        e3_subagent_edge,
        e4_backward_compat_with_05_state,
        e5_special_chars_in_path,
    ]
    failed = []
    for t in tests:
        try:
            t()
        except Exception as exc:
            failed.append((t.__name__, exc))
            print(f"  FAIL: {type(exc).__name__}: {exc}")

    print("\n" + "=" * 70)
    if failed:
        print(f"FAILURES ({len(failed)}/{len(tests)}):")
        for n, e in failed:
            print(f"  - {n}: {e}")
        return 1
    print(f"ALL {len(tests)} 0.5.1 EDGE CASE CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
