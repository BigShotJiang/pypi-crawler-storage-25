"""
Tests for the round-5 audit fixes (0.4.4 follow-up).

Each test pins a defensive fix that the npm SDK shipped in 0.4.3 (port
to Python here) OR is new in both SDKs. Mutation discipline applies —
revert the corresponding source change and the matching test must fail
with a clear message.

The five fixes:

  1. B1 — rate-limiter clock-skew clamp
  2. B5 — z-score subnormal-std guard
  3. B4 — NaN/Infinity timestamp guard in ingest
  4. B6 — should_prevent skips RESOLVED entries
  5. NEW — AlertStateManager._tracked bounded LRU
"""
from __future__ import annotations

import math

import pytest

from agentsonar._core.detectors.alert_state import AlertStateManager
from agentsonar._core.detectors.rate_limiter import SlidingWindowLimiter
from agentsonar._core.detectors.repetitive_detector import ExponentialDecayDetector
from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import InteractionEvent

_BASE_CONFIG: dict = {"file_output": False, "console_output": False}


# =====================================================================
# Fix 1 (B1): Rate-limiter clock-skew clamp
# =====================================================================

class TestRateLimiterClockSkew:
    """When wall clock moves backwards (NTP step, VM pause/resume, manual
    reset), the rate limiter MUST NOT inflate its rate estimate via
    `(1 - fraction_elapsed) > 1` and fire spurious CRITICAL alerts."""

    def test_backward_clock_does_not_inflate_estimate(self):
        limiter = SlidingWindowLimiter(window_size=60.0, per_edge_limit=5)
        # Establish a window at t=1000.
        for _ in range(3):
            assert limiter.check("a", "b", 1000.0) is None
        # Clock jumps backwards by 50s (NTP step).
        result = limiter.check("a", "b", 950.0)
        # Pre-fix: elapsed = -50, fraction = -50/60 = -0.83,
        # (1 - (-0.83)) = 1.83, estimated = current_count * 1.83
        # could trip CRITICAL. Post-fix: elapsed clamped to 0.
        assert result is None, (
            "Backward clock jump should NOT trip rate-limit CRITICAL. "
            "Got: %s. Defensive clamp is missing." % result
        )


# =====================================================================
# Fix 2 (B5): Z-score subnormal-std guard
# =====================================================================

class TestZScoreSubnormalStd:
    """`std == 0.0` catches exact zero but a subnormal float (1e-300)
    slips through, producing z_score=inf and bogus edge_anomaly alerts."""

    def test_subnormal_std_does_not_fire_infinite_zscore(self):
        # Construct a detector. Record events through the public API
        # so the internal dict gets populated correctly, then reach in
        # and adjust the resulting weights to construct a subnormal-std
        # scenario.
        from agentsonar._core.detectors.repetitive_detector import _DecayEdge

        det = ExponentialDecayDetector(
            half_life_seconds=1e9,  # negligible decay over test window
            min_edges_for_zscore=2,
            min_total_events=2,
        )
        # Bootstrap two edges via the public API.
        det.record_event("a", "b", 0.0)
        det.record_event("c", "d", 0.0)

        # Replace the weights with near-identical values. The variance
        # of two values differing by 1e-160 is on the order of 1e-321
        # (subnormal range). `std` ends up around 1e-160 — well below
        # the 1e-10 floor the fix uses but above 0.
        det._edges[("a", "b")] = _DecayEdge(
            weight=1.0 + 1e-160, last_updated=0.0, event_count=10
        )
        det._edges[("c", "d")] = _DecayEdge(
            weight=1.0, last_updated=0.0, event_count=10
        )
        # Bump total_events past the warm-up gate.
        det._total_events = 20

        result = det.check_anomaly("a", "b", now=0.0)
        # Pre-fix: result['z_score'] = inf (or astronomical). Post-fix:
        # returns None because std is below the 1e-10 floor.
        if result is not None:
            assert math.isfinite(result["z_score"]), (
                "Subnormal-std bypass: z_score is %s (should be filtered)"
                % result["z_score"]
            )
            # Defense-in-depth: if z_score IS finite, it must be sane.
            assert abs(result["z_score"]) < 1e10, (
                "Subnormal-std bypass produced unreasonably large z_score: %s"
                % result["z_score"]
            )


# =====================================================================
# Fix 3 (B4): NaN / Infinity timestamp guard in ingest
# =====================================================================

class TestNaNInfinityTimestampGuard:
    """Non-finite timestamps poison every downstream detector
    (NaN comparisons return False; rate limiter computes NaN rate; etc.).
    Engine MUST drop these events silently without crashing AND without
    incrementing event_count."""

    def test_nan_timestamp_is_dropped_silently(self):
        engine = DetectionEngine(_BASE_CONFIG)
        try:
            # NaN timestamp should be dropped.
            alerts = engine.ingest(InteractionEvent("a", "b", float("nan")))
            assert alerts == []
            summary = engine.get_summary()
            assert summary["total_events"] == 0, (
                "NaN-timestamp event must NOT increment total_events"
            )
        finally:
            engine.shutdown()

    def test_positive_infinity_timestamp_is_dropped(self):
        engine = DetectionEngine(_BASE_CONFIG)
        try:
            alerts = engine.ingest(InteractionEvent("a", "b", float("inf")))
            assert alerts == []
            assert engine.get_summary()["total_events"] == 0
        finally:
            engine.shutdown()

    def test_negative_infinity_timestamp_is_dropped(self):
        engine = DetectionEngine(_BASE_CONFIG)
        try:
            alerts = engine.ingest(InteractionEvent("a", "b", float("-inf")))
            assert alerts == []
            assert engine.get_summary()["total_events"] == 0
        finally:
            engine.shutdown()

    def test_normal_timestamps_still_increment(self):
        """Sanity: the guard doesn't break the happy path."""
        engine = DetectionEngine(_BASE_CONFIG)
        try:
            engine.ingest(InteractionEvent("a", "b", 1000.0))
            engine.ingest(InteractionEvent("b", "c", 1001.0))
            assert engine.get_summary()["total_events"] == 2
        finally:
            engine.shutdown()


# =====================================================================
# Fix 4 (B6): should_prevent skips RESOLVED tracked entries
# =====================================================================

class TestShouldPreventSkipsResolved:
    """After a cycle is RESOLVED via recovery sweep, the original alert
    remains in _recent_alerts. If a host violates the Prevent contract
    (catches PreventError and keeps going), should_prevent MUST NOT
    re-fire on the stale RESOLVED tracked entry."""

    def test_should_prevent_returns_none_after_alert_resolved(self):
        engine = DetectionEngine({
            **_BASE_CONFIG,
            "warning_threshold": 2,
            "critical_threshold": 5,
            "resolve_after_seconds": 0.5,
            "prevent": {"cyclic_delegation": {"max_rotations": 3}},
            "per_edge_limit": 999,
        })
        try:
            ts = 1000.0
            # Build up rotations of an a→b→c cycle. Stop just before
            # the prevent trip; collect the WARNING alert.
            for r in range(2):
                for src, tgt in [("a", "b"), ("b", "c"), ("c", "a")]:
                    engine.ingest(InteractionEvent(src, tgt, ts))
                    ts += 0.1

            # Force recovery: advance time well past resolve_after_seconds
            # without any new events. checkPrevent's underlying
            # check_recoveries gets called on the next ingest at the
            # advanced timestamp.
            engine.ingest(InteractionEvent("x", "y", ts + 100.0))

            # Now look up the cycle fingerprint and verify it's RESOLVED.
            fp = tuple(sorted({"a", "b", "c"}))
            tracked = engine._alert_mgr._tracked.get(fp)
            assert tracked is not None, "cycle fingerprint should be tracked"
            assert tracked.state == "RESOLVED", (
                f"Expected RESOLVED after quiet period, got {tracked.state}. "
                f"Test setup is broken — adjust resolve_after_seconds or timing."
            )

            # should_prevent must NOT trip on the stale RESOLVED entry.
            result = engine.should_prevent()
            assert result is None, (
                f"should_prevent re-fired on a RESOLVED entry: {result}. "
                "Defense-in-depth guard is missing — host violating "
                "Prevent contract would see spurious re-trips."
            )
        finally:
            engine.shutdown()


# =====================================================================
# Fix 5: AlertStateManager._tracked LRU cap
# =====================================================================

class TestAlertStateManagerTrackedCap:
    """Long-running deployments with high fingerprint cardinality must
    not leak memory via unbounded _tracked dict growth."""

    def test_tracked_dict_stays_at_or_under_cap(self):
        mgr = AlertStateManager(
            warning_threshold=1,
            critical_threshold=10,
            max_tracked_fingerprints=10,
        )
        # Feed 50 distinct fingerprints, all at WARNING level.
        for i in range(50):
            mgr.process(
                fingerprint=("agent_%d" % i, "target"),
                rotations=2,
                pattern="cycle",
                now=float(i),
            )
        # Cap is 10; we should have at most 10 entries left.
        assert len(mgr._tracked) <= 10, (
            f"Tracked dict size {len(mgr._tracked)} exceeds cap 10. "
            "LRU eviction is missing."
        )

    def test_resolved_entries_evicted_first(self):
        """When over cap, RESOLVED entries should be evicted before
        ACTIVE/ESCALATED ones."""
        mgr = AlertStateManager(
            warning_threshold=1,
            critical_threshold=10,
            resolve_after_seconds=0.5,
            max_tracked_fingerprints=5,
        )
        # Create 5 entries that age into RESOLVED.
        for i in range(5):
            mgr.process(
                fingerprint=("resolved_%d" % i,),
                rotations=2,
                pattern="cycle",
                now=float(i),
            )
        # Drive recovery to mark them RESOLVED.
        mgr.check_recoveries(now=100.0)
        for k, v in mgr._tracked.items():
            assert v.state == "RESOLVED", k

        # Now add 3 fresh ACTIVE entries — these go OVER the cap.
        for i in range(3):
            mgr.process(
                fingerprint=("active_%d" % i,),
                rotations=2,
                pattern="cycle",
                now=200.0 + i,
            )

        # All 3 active entries must survive; resolved ones got evicted.
        survivors = list(mgr._tracked.values())
        assert len(survivors) == 5, f"Expected 5 entries, got {len(survivors)}"
        active = [v for v in survivors if v.state == "ACTIVE"]
        assert len(active) == 3, (
            f"All 3 fresh ACTIVE entries should survive eviction; "
            f"got {len(active)}. Eviction policy preferred wrong entries."
        )

    def test_default_cap_is_1000(self):
        """The default cap is documented as 1000; tests that don't pass
        a custom cap shouldn't be surprised by a smaller default."""
        mgr = AlertStateManager()
        # _max_tracked is the resolved-config field.
        assert mgr._max_tracked == 1000

    def test_bad_cap_falls_back_to_default(self):
        """Negative / zero / non-int caps are coerced to the default
        rather than disabling tracking entirely."""
        for bad in [0, -1, "10", None, float("nan")]:
            mgr = AlertStateManager(max_tracked_fingerprints=bad)  # type: ignore[arg-type]
            assert mgr._max_tracked == 1000, (
                f"Bad cap {bad!r} should fall back to default, got {mgr._max_tracked}"
            )
