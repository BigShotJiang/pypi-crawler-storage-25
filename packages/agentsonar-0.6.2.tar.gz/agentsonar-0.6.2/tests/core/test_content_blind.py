"""Tests for `_core/_content_blind` primitives."""
from __future__ import annotations

import pytest

from agentsonar._core._content_blind import (
    canonical_json,
    derive_status,
    fingerprint_input,
    hash_string,
    maybe_redact_path,
    safe_int,
    safe_size_bytes,
    safe_str,
    safe_str_or_none,
)


class TestCanonicalJson:

    def test_sorted_keys(self):
        assert canonical_json({"b": 1, "a": 2}) == '{"a":2,"b":1}'

    def test_compact_separators(self):
        out = canonical_json({"a": 1, "b": [2, 3]})
        assert ", " not in out
        assert ": " not in out

    def test_unserializable_returns_empty(self):
        class Unserializable:
            def __repr__(self):
                raise RuntimeError("nope")
        result = canonical_json(Unserializable())
        assert isinstance(result, str)


class TestFingerprint:

    def test_same_input_same_fingerprint(self):
        a = fingerprint_input({"file_path": "/x"})
        b = fingerprint_input({"file_path": "/x"})
        assert a == b

    def test_different_input_different_fingerprint(self):
        a = fingerprint_input({"file_path": "/x"})
        b = fingerprint_input({"file_path": "/y"})
        assert a != b

    def test_default_length_16(self):
        assert len(fingerprint_input({})) == 16

    def test_custom_length(self):
        assert len(fingerprint_input({"x": 1}, length=8)) == 8

    def test_none_returns_stable_hash(self):
        a = fingerprint_input(None)
        b = fingerprint_input(None)
        assert a == b
        assert len(a) == 16


class TestHashString:

    def test_same_string_same_hash(self):
        assert hash_string("hello") == hash_string("hello")

    def test_different_strings_different_hashes(self):
        assert hash_string("a") != hash_string("b")

    def test_empty_string_returns_zero_prefix(self):
        assert hash_string("") == "0" * 16

    def test_none_returns_zero_prefix(self):
        assert hash_string(None) == "0" * 16


class TestSafeSizeBytes:

    def test_zero_for_none(self):
        assert safe_size_bytes(None) == 0

    def test_nonzero_for_content(self):
        assert safe_size_bytes({"k": "v"}) > 0

    def test_larger_content_larger_size(self):
        small = safe_size_bytes({"x": "a"})
        large = safe_size_bytes({"x": "a" * 1000})
        assert large > small


class TestDeriveStatus:

    def test_none_returns_unknown(self):
        assert derive_status(None) == "unknown"

    def test_dict_with_error_key_returns_error(self):
        assert derive_status({"error": "boom"}) == "error"

    def test_dict_with_is_error_true_returns_error(self):
        assert derive_status({"is_error": True, "msg": "x"}) == "error"

    def test_dict_without_error_returns_success(self):
        assert derive_status({"result": "ok"}) == "success"

    def test_string_response_returns_success(self):
        assert derive_status("stdout output") == "success"


class TestMaybeRedactPath:

    def test_passthrough_when_not_regulated(self, monkeypatch):
        monkeypatch.delenv("AGENTSONAR_REGULATED", raising=False)
        assert maybe_redact_path("/src/hello.py") == "/src/hello.py"

    def test_redacts_when_regulated(self, monkeypatch):
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        result = maybe_redact_path("/src/secret.py")
        assert result is not None
        assert result.startswith("path:")
        assert "secret.py" not in result

    def test_same_path_same_hash_when_regulated(self, monkeypatch):
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        a = maybe_redact_path("/x.py")
        b = maybe_redact_path("/x.py")
        assert a == b

    def test_different_paths_different_hashes_when_regulated(self, monkeypatch):
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        a = maybe_redact_path("/x.py")
        b = maybe_redact_path("/y.py")
        assert a != b

    def test_none_returns_none(self):
        assert maybe_redact_path(None) is None


class TestSafeCoercion:

    def test_safe_str_none_returns_default(self):
        assert safe_str(None) == ""
        assert safe_str(None, default="N/A") == "N/A"

    def test_safe_str_number(self):
        assert safe_str(42) == "42"

    def test_safe_str_or_none_none(self):
        assert safe_str_or_none(None) is None

    def test_safe_str_or_none_number(self):
        assert safe_str_or_none(42) == "42"

    def test_safe_int_none_returns_default(self):
        assert safe_int(None) == 0
        assert safe_int(None, default=-1) == -1

    def test_safe_int_string(self):
        assert safe_int("42") == 42

    def test_safe_int_invalid_returns_default(self):
        assert safe_int("not a number") == 0

    def test_safe_str_broken_object_returns_default(self):
        class Broken:
            def __str__(self):
                raise RuntimeError("boom")
        assert safe_str(Broken()) == ""
