"""Tests for `_core/_persistence` IO primitives."""
from __future__ import annotations

import os
import subprocess
import sys
import threading
import time
from pathlib import Path

import pytest

from agentsonar._core._persistence import (
    atomic_write_bytes,
    atomic_write_text,
    file_lock,
    is_windows,
)


class TestAtomicWriteBytes:

    def test_writes_content(self, tmp_path):
        target = tmp_path / "out.bin"
        atomic_write_bytes(target, b"hello world")
        assert target.read_bytes() == b"hello world"

    def test_creates_parent_directory(self, tmp_path):
        target = tmp_path / "a" / "b" / "c" / "out.bin"
        atomic_write_bytes(target, b"x")
        assert target.read_bytes() == b"x"

    def test_overwrites_existing_file(self, tmp_path):
        target = tmp_path / "out.bin"
        target.write_bytes(b"old")
        atomic_write_bytes(target, b"new")
        assert target.read_bytes() == b"new"

    def test_no_leftover_tmp_files(self, tmp_path):
        target = tmp_path / "out.bin"
        for _ in range(10):
            atomic_write_bytes(target, b"x")
        leftover = list(tmp_path.glob("out.bin.tmp.*"))
        assert leftover == []

    def test_cleanup_on_replace_failure(self, tmp_path, monkeypatch):
        target = tmp_path / "out.bin"
        def fail_replace(src, dst):
            raise OSError("simulated rename failure")
        monkeypatch.setattr(os, "replace", fail_replace)
        with pytest.raises(OSError):
            atomic_write_bytes(target, b"x")
        leftover = list(tmp_path.glob("out.bin.tmp.*"))
        assert leftover == []


class TestAtomicWriteText:

    def test_writes_utf8(self, tmp_path):
        target = tmp_path / "out.txt"
        atomic_write_text(target, "hello")
        assert target.read_text(encoding="utf-8") == "hello"

    def test_writes_unicode(self, tmp_path):
        target = tmp_path / "out.txt"
        atomic_write_text(target, "japanese-day-日本語")
        assert "日本語" in target.read_text(encoding="utf-8")


class TestFileLock:

    def test_acquires_and_releases(self, tmp_path):
        lock_path = tmp_path / "test.lock"
        with file_lock(lock_path, timeout=2.0):
            assert lock_path.exists()
        assert lock_path.exists()

    def test_timeout_when_held(self, tmp_path):
        """Same-process can't double-lock (different fh, same file).
        On Windows msvcrt locks per-process, so this might behave
        differently; the universal behavior is contention timeout."""
        lock_path = tmp_path / "contested.lock"
        result = {}
        def hold_lock():
            with file_lock(lock_path, timeout=2.0):
                result["held"] = True
                time.sleep(1.0)
        holder = threading.Thread(target=hold_lock, daemon=True)
        holder.start()
        time.sleep(0.1)
        try:
            with file_lock(lock_path, timeout=0.5):
                result["acquired"] = True
        except TimeoutError:
            result["timed_out"] = True
        holder.join()
        assert result.get("held") is True

    def test_concurrent_threads_serialize(self, tmp_path):
        """Each thread takes the lock, increments a shared counter
        sequentially. Without locking, races would lose updates."""
        lock_path = tmp_path / "counter.lock"
        counter_file = tmp_path / "counter.txt"
        counter_file.write_text("0")
        N = 5

        def worker():
            for _ in range(10):
                with file_lock(lock_path, timeout=10.0):
                    current = int(counter_file.read_text())
                    counter_file.write_text(str(current + 1))

        threads = [threading.Thread(target=worker) for _ in range(N)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert int(counter_file.read_text()) == N * 10


class TestIsWindows:

    def test_returns_bool(self):
        assert isinstance(is_windows(), bool)

    def test_matches_os_name(self):
        assert is_windows() == (os.name == "nt")
