"""
Tests for per-pattern threshold overrides (added in 0.4.3).

Pre-0.4.3, the engine had only generic `warning_threshold` and
`critical_threshold` knobs that applied to every alert pattern (cycle,
edge_anomaly, scc_cycle). Setting one to a high value to "disable"
that pattern silently disabled all others — playground / integration
tests caught this.

0.4.3 adds these additive, non-breaking config keys:

    cycle_warning_threshold      | None = use generic
    cycle_critical_threshold     | None = use generic
    edge_anomaly_warning_threshold   | None = use generic
    edge_anomaly_critical_threshold  | None = use generic

When set, they OVERRIDE the generic threshold for that pattern only.
SCC cycles share the cycle thresholds (same failure class).
"""
from __future__ import annotations

import pytest

from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import InteractionEvent


_BASE = {"file_output": False, "console_output": False}


def _hammer_2_node(engine: DetectionEngine, n: int) -> None:
    """Emit `n` round-trips on edge a<->b. Triggers cycle (Layer 3) AND
    edge_anomaly (Layer 2) at the same time."""
    ts = 1_700_000_000.0
    for i in range(n):
        engine.ingest(InteractionEvent("a", "b", ts + i * 0.1))
        engine.ingest(InteractionEvent("b", "a", ts + i * 0.1 + 0.05))


# ---------------------------------------------------------------------
# Backwards compat: pre-0.4.3 code still works unchanged
# ---------------------------------------------------------------------

def test_generic_thresholds_still_apply_to_every_pattern():
    """Code that only sets `warning_threshold` / `critical_threshold`
    (the pre-0.4.3 surface) keeps the old uniform-threshold behavior.
    Both cycle AND edge_anomaly use the generic value."""
    engine = DetectionEngine({
        **_BASE,
        "warning_threshold": 2,
        "critical_threshold": 100,   # high so we only see WARNINGs
        "hard_weight_limit": 5.0,    # tight enough that Layer 2 fires
    })
    try:
        _hammer_2_node(engine, n=10)
        events = engine.get_recent_events()

        cycle_events = [
            e for e in events
            if e.failure_class.value == "cyclic_delegation"
        ]
        edge_events = [
            e for e in events
            if e.failure_class.value == "repetitive_delegation"
        ]
        # Both patterns fire under the same generic threshold.
        assert cycle_events, "expected at least one cycle event"
        assert edge_events, "expected at least one edge_anomaly event"
    finally:
        engine.shutdown()


# ---------------------------------------------------------------------
# Per-pattern overrides win when set
# ---------------------------------------------------------------------

def test_cycle_override_disables_only_cycle():
    """`cycle_warning_threshold=999` silences cycle alerts but
    edge_anomaly continues firing at the generic threshold."""
    engine = DetectionEngine({
        **_BASE,
        "warning_threshold": 2,         # generic stays low
        "critical_threshold": 5,
        "cycle_warning_threshold": 999,    # cycle effectively disabled
        "cycle_critical_threshold": 9999,
        "hard_weight_limit": 5.0,
    })
    try:
        _hammer_2_node(engine, n=10)
        events = engine.get_recent_events()

        cycle_events = [
            e for e in events
            if e.failure_class.value == "cyclic_delegation"
        ]
        edge_events = [
            e for e in events
            if e.failure_class.value == "repetitive_delegation"
        ]
        assert cycle_events == [], (
            f"cycle should be disabled by cycle_warning_threshold=999; "
            f"got: {cycle_events}"
        )
        assert edge_events, (
            "edge_anomaly should still fire at generic threshold"
        )
    finally:
        engine.shutdown()


def test_edge_anomaly_override_disables_only_edge_anomaly():
    """Mirror of the cycle test: disabling edge_anomaly leaves cycle alerts firing."""
    engine = DetectionEngine({
        **_BASE,
        "warning_threshold": 2,
        "critical_threshold": 5,
        "edge_anomaly_warning_threshold": 9999,    # edge_anomaly disabled
        "edge_anomaly_critical_threshold": 99999,
        "hard_weight_limit": 5.0,
    })
    try:
        _hammer_2_node(engine, n=10)
        events = engine.get_recent_events()

        cycle_events = [
            e for e in events
            if e.failure_class.value == "cyclic_delegation"
        ]
        edge_events = [
            e for e in events
            if e.failure_class.value == "repetitive_delegation"
        ]
        assert cycle_events, "cycle should still fire at generic threshold"
        assert edge_events == [], (
            f"edge_anomaly should be disabled by override; got: {edge_events}"
        )
    finally:
        engine.shutdown()


def test_per_pattern_override_lower_than_generic():
    """Per-pattern override can also be MORE aggressive than generic.
    `cycle_warning_threshold=2` with `warning_threshold=10` fires cycle
    early but leaves edge_anomaly firing only at 10."""
    engine = DetectionEngine({
        **_BASE,
        "warning_threshold": 10,        # generic is high
        "critical_threshold": 100,
        "cycle_warning_threshold": 2,    # cycle is aggressive
        "cycle_critical_threshold": 5,
        "hard_weight_limit": 100.0,     # disable Layer 2's hard-limit
    })
    try:
        _hammer_2_node(engine, n=4)     # ~4 cycle rotations
        events = engine.get_recent_events()
        cycle_events = [
            e for e in events
            if e.failure_class.value == "cyclic_delegation"
        ]
        # Cycle fires (rotations >= 2). With generic threshold of 10,
        # cycle wouldn't have fired yet — proving the override is
        # being applied.
        assert cycle_events, (
            "cycle should fire at the per-pattern threshold of 2 "
            "even though the generic threshold is 10"
        )
    finally:
        engine.shutdown()


# ---------------------------------------------------------------------
# Engine-attribute regression guards (the playground checked these
# attributes; future refactors must not silently rename them)
# ---------------------------------------------------------------------

def test_engine_exposes_per_pattern_threshold_attributes():
    """`_cycle_warning_threshold`, `_cycle_critical_threshold`,
    `_edge_anomaly_warning_threshold`,
    `_edge_anomaly_critical_threshold` are read by the event builders
    when constructing `Thresholds` blocks for CoordinationEvents.
    Pin the attribute names so tests + downstream code don't break on
    a rename."""
    engine = DetectionEngine({
        **_BASE,
        "warning_threshold": 5,
        "critical_threshold": 15,
        "cycle_warning_threshold": 2,
        "cycle_critical_threshold": 7,
        "edge_anomaly_warning_threshold": 3,
        "edge_anomaly_critical_threshold": 9,
    })
    try:
        assert engine._cycle_warning_threshold == 2
        assert engine._cycle_critical_threshold == 7
        assert engine._edge_anomaly_warning_threshold == 3
        assert engine._edge_anomaly_critical_threshold == 9
        # Generic stays as the user set it (per-pattern overrides
        # don't mutate the generic values).
        assert engine._warning_threshold == 5
        assert engine._critical_threshold == 15
    finally:
        engine.shutdown()


def test_unset_per_pattern_keys_fall_back_to_generic():
    """If only generic keys are set, per-pattern attributes resolve to
    the generic values. (No surprise None or zero defaults.)"""
    engine = DetectionEngine({
        **_BASE,
        "warning_threshold": 5,
        "critical_threshold": 15,
    })
    try:
        assert engine._cycle_warning_threshold == 5
        assert engine._cycle_critical_threshold == 15
        assert engine._edge_anomaly_warning_threshold == 5
        assert engine._edge_anomaly_critical_threshold == 15
    finally:
        engine.shutdown()


def test_thresholds_block_on_event_uses_pattern_specific_values():
    """The `Thresholds` block on a CoordinationEvent should reflect the
    THRESHOLDS THAT FIRED THE ALERT, not the generic ones. So a cycle
    event reports the cycle thresholds, not the generic ones."""
    engine = DetectionEngine({
        **_BASE,
        "warning_threshold": 5,
        "critical_threshold": 15,
        "cycle_warning_threshold": 2,
        "cycle_critical_threshold": 7,
        "hard_weight_limit": 100.0,    # quiet Layer 2 for this test
    })
    try:
        _hammer_2_node(engine, n=4)
        events = engine.get_recent_events()
        cycle_events = [
            e for e in events
            if e.failure_class.value == "cyclic_delegation"
        ]
        assert cycle_events, "expected cycle event"
        thr = cycle_events[0].thresholds
        assert thr is not None
        # Cycle event reports the CYCLE-SPECIFIC thresholds.
        assert thr.warning_at == 2
        assert thr.critical_at == 7
    finally:
        engine.shutdown()
