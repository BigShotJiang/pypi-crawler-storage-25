"""
Engine event builders populate the typed Topology fields correctly.

This is the integration test between `_core/_node_types.py` and the 5
event builders in `_core/engine.py`. It verifies that:

  1. Claude-Code-shaped inputs (prefixed names) populate the typed
     buckets correctly across ALL 5 builders.
  2. Multi-agent-adapter inputs (bare names) leave the typed buckets
     empty across ALL 5 builders : the regression guard for CrewAI,
     LangGraph, custom orchestrator.
  3. The `agents_involved` field continues to contain ALL nodes
     (backward-compat with pre-0.5.2 schema readers).
  4. `to_dict()` serializes the new fields without code changes.
"""
from __future__ import annotations

import pytest

from agentsonar._core._node_types import NodeType, classify_node
from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import InteractionEvent
from agentsonar._core.schema import FailureClass


def _build_engine(config=None) -> DetectionEngine:
    """Construct a DetectionEngine with file/console output disabled."""
    base = {
        "file_output": False,
        "console_output": False,
        "warning_threshold": 2,
        "critical_threshold": 4,
        "per_edge_limit": 5,
        "global_limit": 9999,
        "hard_weight_limit": 5.0,
        "min_total_events": 5,
        "min_edges_for_zscore": 5,
    }
    if config:
        base.update(config)
    return DetectionEngine(config=base, adapter="test_topology_buckets")


def _trip_cycle(engine: DetectionEngine, agents: list[str], rotations: int = 4) -> None:
    """Fire repeated cycle traversals to trip Layer 3 cycle detection."""
    ts = 1.0
    for _ in range(rotations):
        for i in range(len(agents)):
            src = agents[i]
            tgt = agents[(i + 1) % len(agents)]
            engine.ingest(InteractionEvent(src, tgt, ts, None))
            ts += 1.0


def _trip_repetitive(engine: DetectionEngine, src: str, tgt: str, count: int = 8) -> None:
    """Hammer one edge to trip Layer 2 repetitive detector."""
    ts = 1.0
    for _ in range(count):
        engine.ingest(InteractionEvent(src, tgt, ts, None))
        ts += 1.0


def _topology_of_first_event(engine, failure_class=None):
    """Return the Topology of the first matching CoordinationEvent."""
    for ev in engine.get_recent_events():
        if failure_class is None or ev.failure_class == failure_class:
            return ev.topology
    raise AssertionError(
        f"no event of class {failure_class} found in {engine.get_recent_events()}"
    )


# =====================================================================
# Cycle builder (Layer 3 + Layer 5 SCC)
# =====================================================================


class TestCycleEventTypedBuckets:

    def test_claude_code_cycle_classifies_correctly(self):
        """A 3-node cycle with main + 2 subagents has all-AGENT
        classification (no tools or MCP in the cycle path itself)."""
        engine = _build_engine()
        _trip_cycle(engine, ["main", "subagent_abc12345", "subagent_def67890"])
        topo = _topology_of_first_event(engine, FailureClass.CYCLIC_DELEGATION)
        assert topo.tool_count == 0
        assert topo.mcp_count == 0
        assert topo.task_spawn_count == 0
        assert topo.tools_involved == ()
        assert topo.mcp_calls_involved == ()
        assert topo.subagent_spawns_involved == ()
        assert len(topo.agents_involved) == 3
        assert topo.agent_count == 3

    def test_multi_agent_cycle_classifies_all_agents(self):
        """CrewAI / LangGraph cycle: bare names → all AGENT, no typed
        buckets populated. This is the cross-adapter regression guard."""
        engine = _build_engine()
        _trip_cycle(engine, ["planner", "researcher", "writer"])
        topo = _topology_of_first_event(engine, FailureClass.CYCLIC_DELEGATION)
        assert topo.tool_count == 0
        assert topo.mcp_count == 0
        assert topo.task_spawn_count == 0
        assert topo.tools_involved == ()
        assert topo.mcp_calls_involved == ()
        assert topo.subagent_spawns_involved == ()
        assert len(topo.agents_involved) == 3
        assert all(classify_node(a) == NodeType.AGENT for a in topo.agents_involved)


# =====================================================================
# Edge-anomaly builder (Layer 2 repetitive)
# =====================================================================


class TestEdgeAnomalyEventTypedBuckets:

    def test_claude_code_read_repeat_classifies_tool(self):
        """The canonical Claude-Code-on-Layer-2 case: main hammers
        Read:/path repeatedly. Typed buckets should show 1 tool."""
        engine = _build_engine()
        _trip_repetitive(engine, "main", "Read:/src/hello.py", count=15)
        topo = _topology_of_first_event(engine, FailureClass.REPETITIVE_DELEGATION)
        assert topo.tool_count == 1
        assert topo.tools_involved == ("Read:/src/hello.py",)
        assert topo.mcp_count == 0
        assert topo.task_spawn_count == 0

    def test_claude_code_mcp_repeat_classifies_mcp(self):
        """main hammering an MCP call goes into the mcp bucket, NOT tool."""
        engine = _build_engine()
        _trip_repetitive(engine, "main", "mcp__github__create_issue:fp", count=15)
        topo = _topology_of_first_event(engine, FailureClass.REPETITIVE_DELEGATION)
        assert topo.mcp_count == 1
        assert topo.mcp_calls_involved == ("mcp__github__create_issue:fp",)
        assert topo.tool_count == 0
        assert topo.task_spawn_count == 0

    def test_claude_code_task_spawn_repeat_classifies_task_spawn(self):
        """main hammering Task_spawn goes into the task_spawn bucket
        (the subagent-explosion failure mode)."""
        engine = _build_engine()
        _trip_repetitive(engine, "main", "Task_spawn:reviewer", count=15)
        topo = _topology_of_first_event(engine, FailureClass.REPETITIVE_DELEGATION)
        assert topo.task_spawn_count == 1
        assert topo.subagent_spawns_involved == ("Task_spawn:reviewer",)
        assert topo.tool_count == 0
        assert topo.mcp_count == 0

    def test_multi_agent_repeat_all_buckets_empty(self):
        """CrewAI / LangGraph repetition: planner -> researcher 15 times.
        All typed buckets remain empty."""
        engine = _build_engine()
        _trip_repetitive(engine, "planner", "researcher", count=15)
        topo = _topology_of_first_event(engine, FailureClass.REPETITIVE_DELEGATION)
        assert topo.tool_count == 0
        assert topo.mcp_count == 0
        assert topo.task_spawn_count == 0
        assert topo.tools_involved == ()
        assert topo.mcp_calls_involved == ()
        assert topo.subagent_spawns_involved == ()


# =====================================================================
# Rate-limit builder (Layer 1)
# =====================================================================


class TestRateLimitEventTypedBuckets:

    def test_claude_code_rate_limit_classifies_tool(self):
        """11+ Reads on the same path in a window trips Layer 1
        per-edge rate. The triggering edge target is Read:/path,
        so tools_involved is populated."""
        engine = _build_engine(config={"per_edge_limit": 5})
        ts = 1.0
        for _ in range(20):
            engine.ingest(InteractionEvent("main", "Read:/src/hello.py", ts, None))
            ts += 0.01  # within window
        topo = _topology_of_first_event(engine, FailureClass.RESOURCE_EXHAUSTION)
        assert topo.tool_count == 1
        assert topo.tools_involved == ("Read:/src/hello.py",)

    def test_multi_agent_rate_limit_all_buckets_empty(self):
        """Bare-name edge tripping rate limit: no tools, no MCP."""
        engine = _build_engine(config={"per_edge_limit": 5})
        ts = 1.0
        for _ in range(20):
            engine.ingest(InteractionEvent("planner", "researcher", ts, None))
            ts += 0.01
        topo = _topology_of_first_event(engine, FailureClass.RESOURCE_EXHAUSTION)
        assert topo.tool_count == 0
        assert topo.mcp_count == 0
        assert topo.task_spawn_count == 0


# =====================================================================
# Mixed classification : main + Read + MCP + Task_spawn in one cycle
# =====================================================================


class TestMixedClassification:

    def test_mixed_node_types_populate_each_bucket(self):
        """4-node cycle: main → Task_spawn → mcp call → Read → main.
        Each non-agent node lands in its respective typed bucket."""
        engine = _build_engine()
        nodes = [
            "main",
            "Task_spawn:reviewer",
            "mcp__github__create_issue:fp",
            "Read:/src/hello.py",
        ]
        _trip_cycle(engine, nodes, rotations=4)

        topo = _topology_of_first_event(engine, FailureClass.CYCLIC_DELEGATION)
        assert "main" in topo.agents_involved
        assert "Read:/src/hello.py" in topo.tools_involved
        assert "mcp__github__create_issue:fp" in topo.mcp_calls_involved
        assert "Task_spawn:reviewer" in topo.subagent_spawns_involved
        assert topo.tool_count == 1
        assert topo.mcp_count == 1
        assert topo.task_spawn_count == 1


# =====================================================================
# JSON shape backward compat
# =====================================================================


class TestJsonShapeBackwardCompat:

    def test_topology_to_dict_includes_new_fields(self):
        """The to_dict() round-trip should include new typed fields.
        Existing fields preserved unchanged."""
        engine = _build_engine()
        _trip_repetitive(engine, "main", "Read:/src/hello.py", count=15)
        ev = next(e for e in engine.get_recent_events()
                  if e.failure_class == FailureClass.REPETITIVE_DELEGATION)
        d = ev.to_dict()
        topo_d = d["topology"]

        # Old fields still present, unchanged in shape
        assert "agents_involved" in topo_d
        assert "interaction_pattern" in topo_d
        assert "agent_count" in topo_d
        assert "occurrence_count" in topo_d
        assert "edge_frequency" in topo_d

        # New fields present
        assert "tools_involved" in topo_d
        assert "mcp_calls_involved" in topo_d
        assert "subagent_spawns_involved" in topo_d
        assert "tool_count" in topo_d
        assert "mcp_count" in topo_d
        assert "task_spawn_count" in topo_d

        # New fields carry the classification
        assert topo_d["tools_involved"] == ["Read:/src/hello.py"]
        assert topo_d["tool_count"] == 1
        assert topo_d["mcp_count"] == 0
        assert topo_d["task_spawn_count"] == 0

    def test_topology_to_dict_for_multi_agent_event_empty_typed_lists(self):
        """Multi-agent (CrewAI/LangGraph/custom) events serialize with
        empty typed lists and zero counts. Backward-compat hot path."""
        engine = _build_engine()
        _trip_repetitive(engine, "planner", "researcher", count=15)
        ev = next(e for e in engine.get_recent_events()
                  if e.failure_class == FailureClass.REPETITIVE_DELEGATION)
        d = ev.to_dict()
        topo_d = d["topology"]
        assert topo_d["tools_involved"] == []
        assert topo_d["mcp_calls_involved"] == []
        assert topo_d["subagent_spawns_involved"] == []
        assert topo_d["tool_count"] == 0
        assert topo_d["mcp_count"] == 0
        assert topo_d["task_spawn_count"] == 0


# =====================================================================
# Cross-builder consistency
# =====================================================================


class TestCrossBuilderConsistency:
    """Every builder should produce the same classifier output for the
    same node names. Ensures the helper isn't accidentally bypassed in
    any builder."""

    @pytest.mark.parametrize("node_name,expected_field", [
        ("Read:/src/x.py", "tools_involved"),
        ("Edit:/src/x.py", "tools_involved"),
        ("Bash:abc123", "tools_involved"),
        ("mcp__github__create_issue:fp", "mcp_calls_involved"),
        ("Task_spawn:reviewer", "subagent_spawns_involved"),
    ])
    def test_layer2_repetitive_routes_correctly(self, node_name, expected_field):
        """Same node name fired 15 times on Layer 2 lands in the right
        bucket every time."""
        engine = _build_engine()
        _trip_repetitive(engine, "main", node_name, count=15)
        topo = _topology_of_first_event(engine, FailureClass.REPETITIVE_DELEGATION)
        assert node_name in getattr(topo, expected_field)
