# Tests

Mirrors `src/agentsonar/` where it makes sense; groups cross-cutting
concerns where it doesn't. Run the full suite with `pytest`; the
underscore-prefixed scripts under `stress/` are manual-only.

| Folder | Maps to | What it covers |
|---|---|---|
| `core/` | `src/agentsonar/_core/` | Engine, detectors, schema, node classification, content-blind + persistence primitives, prevent mode, patterns, thresholds |
| `integrations/` | `src/agentsonar/_integrations/` | Custom, CrewAI, LangGraph adapters + cross-adapter consistency |
| `integrations/claude/` | `src/agentsonar/_integrations/claude/` | Claude Code adapter + `install-claude-hooks` installer |
| `output/` | `src/agentsonar/_output/` | HTML report, JSON export, run activity view, FileLogger, slug generator, clean-run signals |
| `contract/` | (cross-cutting) | Host-safety golden rule, lifecycle invariants, public API surface, exports, demo, telemetry, cross-platform |
| `regression/` | (historical) | Pinned tests for audit rounds 2-5; do not delete, they're the regression net |
| `performance/` | (latency / stress in pytest) | Per-event latency budgets (marked `performance`), stress + edge cases |
| `stress/` | (manual-only, NOT pytest-collected) | High-signal scripts named `_*.py` so pytest skips them. Run by hand with `python tests/stress/<name>.py` before publishing. |

## Running

- Full suite (skips `performance` marker by default):
  `pytest`
- Performance suite:
  `pytest -m performance`
- One folder:
  `pytest tests/core/` or `pytest tests/integrations/claude/`
- Manual stress runs (these spawn subprocesses; expect ~30-60 s each):
  `python tests/stress/_sanity_check.py`
  `python tests/stress/_stress_sanity.py`
  `python tests/stress/_stress_round3.py`
  `python tests/stress/_edge_cases.py`
  `python tests/stress/_trace_race.py`

## Why the underscore prefix on `stress/_*.py`?

`pyproject.toml::python_files = ["test_*.py"]` tells pytest to collect
only `test_*` files. Stress scripts spawn subprocesses, take seconds
each, and are flaky on noisy CI runners. Keeping them underscore-
prefixed lets us run them by hand without polluting the main sweep.
