"""
Regression tests for the generic custom-orchestrator adapter
(`CustomAdapter` / `monitor_orchestrator`).

This is the third integration surface alongside `AgentSonarListener`
(CrewAI) and `AgentSonarCallback` / `monitor()` (LangGraph). It
exists so users with hand-rolled orchestrators — subprocess
pipelines, Celery workers, FastAPI coordinators, anything that
doesn't fit the two framework adapters — can still wire AgentSonar
in with a small explicit API.

The adapter is small by design: one method to record a delegation,
one method to shut down, an engine attribute for power users. These
tests pin the contract.

Covered:
  * Basic construction + public API surface
  * Delegation events land as real CoordinationEvents in the engine
  * Repetitive delegation on a hot edge fires edge_anomaly alerts
    (matching the canonical AgentSonar detection behavior)
  * Host-safety: garbage inputs never crash the caller
  * Host-safety: engine failures mid-run never escape
  * `AGENTSONAR_DISABLED=1` kill switch produces a silent no-op
  * Context-manager usage calls shutdown() on exit
  * `shutdown()` is idempotent
"""
from __future__ import annotations

import pytest

from agentsonar import CustomAdapter, monitor_orchestrator
from agentsonar._core.noop_engine import _NoOpEngine


# ---------------------------------------------------------------------------
# Public API surface
# ---------------------------------------------------------------------------

def test_monitor_orchestrator_returns_custom_adapter():
    adapter = monitor_orchestrator()
    try:
        assert isinstance(adapter, CustomAdapter)
        assert hasattr(adapter, "engine")
        assert hasattr(adapter, "delegation")
        assert hasattr(adapter, "get_summary")
        assert hasattr(adapter, "shutdown")
    finally:
        adapter.shutdown()


def test_monitor_orchestrator_accepts_config_dict():
    """Config should flow through to the underlying DetectionEngine
    the same way it does for the framework adapters."""
    adapter = monitor_orchestrator(config={
        "file_output": False,
        "console_output": False,
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })
    try:
        assert hasattr(adapter.engine, "ingest")
    finally:
        adapter.shutdown()


def test_context_manager_calls_shutdown_on_exit():
    """`with monitor_orchestrator() as sonar:` must shutdown cleanly
    even when the suite ends normally or by exception."""
    with monitor_orchestrator(config={"file_output": False, "console_output": False}) as sonar:
        sonar.delegation("a", "b")
    # After exit the engine should know it's been shut down
    assert sonar.engine._shutdown_requested is True


def test_context_manager_calls_shutdown_on_exception():
    adapter = None
    try:
        with monitor_orchestrator(config={"file_output": False, "console_output": False}) as sonar:
            adapter = sonar
            sonar.delegation("a", "b")
            raise ValueError("simulated orchestrator failure")
    except ValueError:
        pass
    assert adapter is not None
    assert adapter.engine._shutdown_requested is True


# ---------------------------------------------------------------------------
# Delegation events land in the engine
# ---------------------------------------------------------------------------

def test_delegation_records_into_recent_events():
    """A delegation call should produce an InteractionEvent that the
    engine ingests and makes visible on get_recent_events() once it
    crosses the alert threshold."""
    adapter = monitor_orchestrator(config={
        "file_output": False,
        "console_output": False,
        "warning_threshold": 3,
        "critical_threshold": 5,
        "per_edge_limit": 99999,
        "global_limit": 99999,
        "hard_weight_limit": 5,
    })
    try:
        # Drive 20 events on a hot edge — should trip the decay detector
        for i in range(20):
            adapter.delegation("orchestrator", "generator",
                               metadata={"iteration": i})
        events = adapter.engine.get_recent_events()
        # Expect at least one repetitive_delegation alert for the hot edge
        from agentsonar._core.schema import FailureClass
        repetitive = [
            e for e in events
            if e.failure_class == FailureClass.REPETITIVE_DELEGATION
        ]
        assert len(repetitive) > 0, (
            f"expected at least one repetitive_delegation alert after 20 "
            f"events on the same edge; got {len(events)} events total"
        )
        for e in repetitive:
            # Source/target strings round-trip correctly
            assert "orchestrator" in e.topology.agents_involved
            assert "generator" in e.topology.agents_involved
    finally:
        adapter.shutdown()


def test_delegation_fires_cyclic_alert_on_real_cycle():
    """Three-node cycle A→B→C→A should produce a cyclic_delegation
    alert the same way the CrewAI/LangGraph adapters do."""
    adapter = monitor_orchestrator(config={
        "file_output": False,
        "console_output": False,
        "warning_threshold": 3,
        "critical_threshold": 5,
        "per_edge_limit": 99999,
        "global_limit": 99999,
    })
    try:
        for _ in range(10):
            adapter.delegation("a", "b")
            adapter.delegation("b", "c")
            adapter.delegation("c", "a")
        from agentsonar._core.schema import FailureClass
        events = adapter.engine.get_recent_events()
        cycle_events = [
            e for e in events
            if e.failure_class == FailureClass.CYCLIC_DELEGATION
        ]
        assert len(cycle_events) > 0
    finally:
        adapter.shutdown()


def test_metadata_is_preserved():
    """Metadata passed to delegation() should survive through the
    engine and be attachable to the event record."""
    adapter = monitor_orchestrator(config={
        "file_output": False,
        "console_output": False,
    })
    try:
        adapter.delegation(
            "orchestrator", "generator",
            metadata={"iteration": 7, "artifact_type": "prd"},
        )
        # Just make sure no exception — metadata storage in the engine
        # is an internal concern.
    finally:
        adapter.shutdown()


def test_explicit_timestamp_is_honored():
    """Callers replaying historical events should be able to pass
    their own timestamps instead of using time.time()."""
    adapter = monitor_orchestrator(config={
        "file_output": False,
        "console_output": False,
        "warning_threshold": 3,
        "critical_threshold": 5,
        "per_edge_limit": 99999,
        "global_limit": 99999,
        "hard_weight_limit": 5,
    })
    try:
        # Stream 20 events with synthetic timestamps 1000.0, 1000.01, ...
        for i in range(20):
            adapter.delegation(
                "orchestrator", "generator",
                timestamp=1000.0 + i * 0.01,
            )
        events = adapter.engine.get_recent_events()
        assert len(events) > 0
        # Every event's timestamp should be in the synthetic range
        for e in events:
            assert 1000.0 <= e.timestamp < 1001.0
    finally:
        adapter.shutdown()


# ---------------------------------------------------------------------------
# Host-safety: garbage inputs
# ---------------------------------------------------------------------------

GARBAGE_INPUTS = [
    (None, None),
    (None, "target"),
    ("source", None),
    (42, "target"),
    ("source", 3.14),
    (object(), object()),
    ("", ""),
]


@pytest.mark.parametrize("source, target", GARBAGE_INPUTS)
def test_delegation_with_garbage_inputs_does_not_raise(source, target):
    """Defensive coercion: whatever garbage the caller passes for
    source/target, `delegation()` must never raise."""
    adapter = monitor_orchestrator(config={
        "file_output": False,
        "console_output": False,
    })
    try:
        adapter.delegation(source, target)
        # And a second call to verify the adapter is still healthy
        adapter.delegation("a", "b")
    finally:
        adapter.shutdown()


def test_delegation_with_non_dict_metadata_does_not_raise():
    adapter = monitor_orchestrator(config={
        "file_output": False,
        "console_output": False,
    })
    try:
        adapter.delegation("a", "b", metadata="bogus")  # type: ignore[arg-type]
        adapter.delegation("a", "b", metadata=[1, 2, 3])  # type: ignore[arg-type]
        adapter.delegation("a", "b", metadata=42)  # type: ignore[arg-type]
    finally:
        adapter.shutdown()


# ---------------------------------------------------------------------------
# Host-safety: engine failures mid-run
# ---------------------------------------------------------------------------

def test_delegation_swallows_engine_ingest_exception():
    """If the underlying engine.ingest() raises mid-run (platform
    failure, bug in a future detector, broken logger), delegation()
    must still return cleanly — the orchestrator's next line runs."""
    adapter = monitor_orchestrator(config={
        "file_output": False,
        "console_output": False,
    })
    try:
        def _boom(*a, **k):
            raise RuntimeError("simulated engine failure")

        adapter.engine.ingest = _boom  # type: ignore[assignment]

        # None of these should raise — the host orchestrator MUST
        # keep running even when AgentSonar is internally broken.
        for i in range(10):
            adapter.delegation("a", "b", metadata={"i": i})
    finally:
        # shutdown should also survive — even with the broken ingest
        adapter.shutdown()


def test_shutdown_swallows_engine_shutdown_exception():
    adapter = monitor_orchestrator(config={
        "file_output": False,
        "console_output": False,
    })

    def _boom(*a, **k):
        raise RuntimeError("simulated shutdown failure")

    adapter.engine.shutdown = _boom  # type: ignore[assignment]

    adapter.shutdown()  # Must not raise


def test_get_summary_returns_valid_dict_on_engine_failure():
    adapter = monitor_orchestrator(config={
        "file_output": False,
        "console_output": False,
    })
    try:
        def _boom(*a, **k):
            raise RuntimeError("simulated failure")

        adapter.engine.get_summary = _boom  # type: ignore[assignment]

        s = adapter.get_summary()
        assert isinstance(s, dict)
        # Well-known keys must exist so downstream dashboards don't trip
        assert "alerts_raised" in s
        assert "alerts" in s
        assert s.get("degraded") is True
    finally:
        adapter.shutdown()


# ---------------------------------------------------------------------------
# Host-safety: shutdown idempotency
# ---------------------------------------------------------------------------

def test_triple_shutdown_is_idempotent():
    adapter = monitor_orchestrator(config={
        "file_output": False,
        "console_output": False,
    })
    adapter.shutdown()
    adapter.shutdown()
    adapter.shutdown()


def test_delegation_after_shutdown_does_not_raise():
    """Post-shutdown delegation calls should drop silently without
    resurrecting the engine or raising to the caller."""
    adapter = monitor_orchestrator(config={
        "file_output": False,
        "console_output": False,
    })
    adapter.shutdown()
    adapter.delegation("a", "b")
    adapter.delegation("a", "b", metadata={"i": 1})


# ---------------------------------------------------------------------------
# Host-safety: AGENTSONAR_DISABLED kill switch
# ---------------------------------------------------------------------------

def test_disabled_env_var_produces_noop_adapter(monkeypatch):
    monkeypatch.setenv("AGENTSONAR_DISABLED", "1")
    adapter = monitor_orchestrator()
    try:
        assert isinstance(adapter.engine, _NoOpEngine)
        # The adapter should still be fully usable — it just
        # silently drops every event.
        for i in range(100):
            adapter.delegation("a", "b")
        summary = adapter.get_summary()
        assert summary.get("degraded") is True
    finally:
        adapter.shutdown()


def test_disabled_env_var_creates_no_session_directory(monkeypatch, tmp_path):
    """Kill switch should prevent I/O entirely — no session dir, no
    files written anywhere, regardless of log_dir config."""
    monkeypatch.setenv("AGENTSONAR_DISABLED", "1")
    adapter = monitor_orchestrator(config={"log_dir": str(tmp_path)})
    try:
        # NoOp engine's logger has run_dir = None
        assert adapter.engine.logger.run_dir is None
    finally:
        adapter.shutdown()


# ---------------------------------------------------------------------------
# Host-safety: bad engine config falls back to NoOp (doesn't raise)
# ---------------------------------------------------------------------------

def test_bad_config_falls_back_to_noop_engine():
    """Same host-safety contract as the framework adapters: bad
    config values must NOT raise to the caller — they degrade to a
    silent no-op engine."""
    adapter = monitor_orchestrator(config={"per_edge_limit": -1})
    try:
        assert isinstance(adapter.engine, _NoOpEngine)
        adapter.delegation("a", "b")
        summary = adapter.get_summary()
        assert summary.get("degraded") is True
    finally:
        adapter.shutdown()


# ---------------------------------------------------------------------------
# health_check — parity surface with the TypeScript SDK's `healthCheck()`.
# Returns a small dict snapshot of {reachable, version, adapter, degraded,
# reason?} that ops dashboards / readiness probes / cross-language tooling
# can introspect without having to touch the engine internals.
# ---------------------------------------------------------------------------

def test_health_check_returns_expected_shape_for_healthy_engine():
    """Healthy adapter reports degraded=False and omits the reason key.

    The shape is the public contract; pin every key here so adding a
    new field elsewhere doesn't accidentally break consumers.
    """
    from agentsonar._version import __version__

    adapter = monitor_orchestrator()
    try:
        result = adapter.health_check()
        assert result == {
            "reachable": True,
            "version": __version__,
            "adapter": "custom_python",
            "degraded": False,
        }
        # `reason` MUST NOT be present in the healthy case — its
        # absence is the signal that the engine is operating normally.
        assert "reason" not in result
    finally:
        adapter.shutdown()


def test_health_check_honors_explicit_adapter_label():
    """Embedded contexts (OMA sidecar, framework wrappers) override the
    default adapter label; health_check must reflect that exact label
    so telemetry / dashboards can attribute behavior correctly."""
    adapter = CustomAdapter(adapter="oma_sidecar")
    try:
        assert adapter.health_check()["adapter"] == "oma_sidecar"
    finally:
        adapter.shutdown()


def test_health_check_reports_degraded_with_reason_when_killed_by_env(monkeypatch):
    """`AGENTSONAR_DISABLED=1` short-circuits engine construction in
    `build_engine_safely`. health_check must surface that state with a
    human-readable reason so an ops dashboard can show "AgentSonar is
    DISABLED via env var" without engineers having to read source.
    """
    monkeypatch.setenv("AGENTSONAR_DISABLED", "1")
    adapter = monitor_orchestrator()
    try:
        result = adapter.health_check()
        assert result["reachable"] is True   # adapter object is alive
        assert result["degraded"] is True
        assert result["adapter"] == "custom_python"
        assert "reason" in result
        # The reason string is fixed in `build_engine_safely`; pinning
        # the substring lets us evolve the wording without breaking the
        # test on cosmetic edits.
        assert "AGENTSONAR_DISABLED" in result["reason"]
    finally:
        adapter.shutdown()


def test_health_check_reports_degraded_with_reason_on_bad_config():
    """Bad config (e.g. negative per_edge_limit) fails engine
    construction inside the safe-engine helper, which catches the
    exception and stamps `_reason` with the exception type + message.
    health_check must surface that — that's how a user investigating a
    silently-degraded run finds out WHY it degraded."""
    adapter = monitor_orchestrator(config={"per_edge_limit": -1})
    try:
        result = adapter.health_check()
        assert result["degraded"] is True
        assert isinstance(result.get("reason"), str)
        assert result["reason"]   # non-empty
    finally:
        adapter.shutdown()


def test_health_check_never_raises_even_with_broken_engine():
    """Host-safety contract: if the engine attribute is somehow a
    non-engine object (pathological edge from a buggy fixture), the
    helper falls through `engine.get_summary()` raising AttributeError
    and reports `degraded=True` — which is the right answer because a
    broken engine is, definitionally, degraded. The point of the test
    is `health_check` MUST NOT raise."""
    adapter = monitor_orchestrator()
    try:
        # Replace the engine with something that has no .get_summary().
        # `_health_check` should treat this as degraded, not crash.
        adapter.engine = object()  # type: ignore[assignment]
        result = adapter.health_check()
        assert result["reachable"] is True
        assert result["degraded"] is True
        assert isinstance(result.get("reason"), str)
    finally:
        # Restore a sane engine before shutdown so cleanup doesn't crash
        adapter.engine = _NoOpEngine(reason="test cleanup")
        adapter.shutdown()


def test_health_check_never_raises_even_with_pathological_reason():
    """A `_NoOpEngine._reason` with a broken `__str__` (some weird
    user-passed exception payload, or a proxy object from a third-party
    library) must not crash health_check. The helper str-coerces inside
    its own try/except so the worst case is a generic fallback reason."""

    class BadStr:
        def __str__(self) -> str:
            raise RuntimeError("__str__ is haunted")

    adapter = monitor_orchestrator()
    try:
        # Inject a degraded engine whose reason explodes on str().
        bad_noop = _NoOpEngine(reason="ok")
        bad_noop._reason = BadStr()  # type: ignore[assignment]
        # The helper actually reads the reason via engine.get_summary()
        # which calls str() inside the engine. Override the path the
        # helper takes by making get_summary itself return the bad value.
        bad_noop.get_summary = lambda: {  # type: ignore[method-assign]
            "degraded": True,
            "degraded_reason": BadStr(),
        }
        adapter.engine = bad_noop  # type: ignore[assignment]

        result = adapter.health_check()
        assert result["reachable"] is True
        assert result["degraded"] is True
        # Generic fallback — the BadStr.__str__ raised, so we don't
        # have a real reason, but `reason` is still present and non-empty.
        assert isinstance(result.get("reason"), str)
        assert result["reason"]
    finally:
        adapter.engine = _NoOpEngine(reason="test cleanup")
        adapter.shutdown()


def test_health_check_is_idempotent_and_returns_fresh_dict():
    """Each call returns a NEW dict — callers can mutate the returned
    result without poisoning subsequent calls. Pin this so future
    refactors don't accidentally cache the dict at instance level."""
    adapter = monitor_orchestrator()
    try:
        a = adapter.health_check()
        b = adapter.health_check()
        assert a == b
        assert a is not b   # different dict objects
        a["adapter"] = "mutated"
        assert adapter.health_check()["adapter"] == "custom_python"
    finally:
        adapter.shutdown()
