"""
Cross-adapter behavioral consistency tests.

The detection engine is one piece of code; the three adapters
(`CustomAdapter`, `AgentSonarListener`, `AgentSonarCallback`) are
three different ways to feed events into it. The same SCENARIO
should produce equivalent alerts through every adapter. If it
doesn't, an adapter-specific bug is hiding (filter, race, missing
glue code, etc.).

This is the kind of test that would have caught Item 3 (LangGraph
self-loop filter) on day one: a self-loop scenario that produces
N alerts in `CustomAdapter` should also produce N alerts in
`AgentSonarCallback`. Pre-0.4.3 it produced 0 in LangGraph.

Each scenario test runs the SAME logical input shape through each
available adapter and asserts equivalence on:
  * total event count
  * alerts_raised
  * which failure_class fired (set-equivalence, ordering may vary)
  * presence of each pattern type
"""
from __future__ import annotations

import pytest

from agentsonar import monitor_orchestrator
from agentsonar._core.engine import DetectionEngine
from agentsonar._core.models import InteractionEvent

_BASE_CONFIG = {"file_output": False, "console_output": False}


def _failure_classes(events) -> set[str]:
    """Project a list of CoordinationEvents to the set of failure_class strings."""
    return {e.failure_class.value for e in events}


# ---------------------------------------------------------------------
# Scenario A: tight self-loop (single agent retrying itself)
#
# Pre-0.4.3 LangGraph: CustomAdapter fires Layer 1, LangGraph fires
# nothing. Cross-adapter assertion catches the inconsistency.
# ---------------------------------------------------------------------

class TestSelfLoopAcrossAdapters:
    """Same self-loop scenario, three adapters → equivalent alerts."""

    _CONFIG = {**_BASE_CONFIG, "per_edge_limit": 3, "window_size": 60}

    def test_custom_adapter_self_loop_fires_layer_1(self):
        """Baseline. Custom adapter via direct delegation."""
        sonar = monitor_orchestrator(self._CONFIG)
        try:
            ts = 1_700_000_000.0
            for i in range(10):
                sonar.delegation("looper", "looper", timestamp=ts + i * 0.05)
            events = sonar.engine.get_recent_events()
            classes = _failure_classes(events)
            # Should fire RESOURCE_EXHAUSTION (Layer 1).
            assert "resource_exhaustion" in classes, (
                f"Custom adapter self-loop didn't fire Layer 1: {classes}"
            )
        finally:
            sonar.shutdown()

    def test_langgraph_self_loop_fires_layer_1(self):
        """Same scenario through the LangGraph callback. The pre-0.4.3
        bug was: LangGraph filtered self-loops, so this produced
        ZERO alerts. Now it should match the Custom adapter."""
        langchain_core = pytest.importorskip("langchain_core")
        from agentsonar._integrations.langgraph_callback import AgentSonarCallback

        cb = AgentSonarCallback(config=self._CONFIG)
        try:
            for step in range(10):
                cb.on_chain_start(
                    serialized={"name": "looper"},
                    inputs={},
                    metadata={"langgraph_node": "looper", "langgraph_step": step},
                )
            events = cb.engine.get_recent_events()
            classes = _failure_classes(events)
            assert "resource_exhaustion" in classes, (
                f"LangGraph self-loop didn't fire Layer 1: {classes}. "
                "Inconsistent with CustomAdapter behavior on the same input."
            )
        finally:
            cb.shutdown()


# ---------------------------------------------------------------------
# Scenario B: 3-node cycle
#
# All three adapters should fire `cyclic_delegation`. Tests the
# common-case agreement.
# ---------------------------------------------------------------------

class TestThreeNodeCycleAcrossAdapters:
    """A → B → C → A repeated should fire `cyclic_delegation` regardless
    of which adapter feeds the events."""

    _CONFIG = {
        **_BASE_CONFIG,
        "warning_threshold": 2,
        "critical_threshold": 5,
        "per_edge_limit": 999,  # disable Layer 1 so we focus on cycle
    }
    _NODES = [("a", "b"), ("b", "c"), ("c", "a")]

    def test_custom_adapter_three_node_cycle(self):
        sonar = monitor_orchestrator(self._CONFIG)
        try:
            ts = 1_700_000_000.0
            for _ in range(5):
                for src, tgt in self._NODES:
                    sonar.delegation(src, tgt, timestamp=ts)
                    ts += 0.1
            classes = _failure_classes(sonar.engine.get_recent_events())
            assert "cyclic_delegation" in classes
        finally:
            sonar.shutdown()

    def test_langgraph_three_node_cycle(self):
        langchain_core = pytest.importorskip("langchain_core")
        from agentsonar._integrations.langgraph_callback import AgentSonarCallback

        cb = AgentSonarCallback(config=self._CONFIG)
        try:
            # LangGraph callback needs ENOUGH transitions for the
            # cycle's min-edge-count to cross critical_threshold. With
            # 6 rotations through A→B→C→A, the closing edge `c→a`
            # fires 5 times (rotation 6 doesn't loop back).
            nodes = ["a", "b", "c"] * 6 + ["a"]
            for step, node in enumerate(nodes):
                cb.on_chain_start(
                    serialized={"name": node},
                    inputs={},
                    metadata={"langgraph_node": node, "langgraph_step": step},
                )
            classes = _failure_classes(cb.engine.get_recent_events())
            assert "cyclic_delegation" in classes
        finally:
            cb.shutdown()

    def test_engine_directly_three_node_cycle(self):
        """Same scenario fed straight into the engine — adapters are
        eliminated entirely. Establishes the ground truth that the
        adapter tests should match."""
        engine = DetectionEngine(self._CONFIG)
        try:
            ts = 1_700_000_000.0
            for _ in range(5):
                for src, tgt in self._NODES:
                    engine.ingest(InteractionEvent(src, tgt, ts))
                    ts += 0.1
            classes = _failure_classes(engine.get_recent_events())
            assert "cyclic_delegation" in classes
        finally:
            engine.shutdown()


# ---------------------------------------------------------------------
# Scenario C: clean run (linear pipeline) → ALL adapters silent
# ---------------------------------------------------------------------

class TestCleanRunAcrossAdapters:
    """Linear pipeline produces zero alerts in every adapter. Catches
    false-positive bugs that are adapter-specific (e.g. metadata
    wrapping that gets misinterpreted as a delegation)."""

    def test_custom_adapter_clean_run(self):
        sonar = monitor_orchestrator(_BASE_CONFIG)
        try:
            sonar.delegation("a", "b")
            sonar.delegation("b", "c")
            sonar.delegation("c", "d")
            assert sonar.get_summary()["alerts_raised"] == 0
        finally:
            sonar.shutdown()

    def test_langgraph_clean_run(self):
        langchain_core = pytest.importorskip("langchain_core")
        from agentsonar._integrations.langgraph_callback import AgentSonarCallback

        cb = AgentSonarCallback(config=_BASE_CONFIG)
        try:
            for step, node in enumerate(["a", "b", "c", "d"]):
                cb.on_chain_start(
                    serialized={"name": node},
                    inputs={},
                    metadata={"langgraph_node": node, "langgraph_step": step},
                )
            assert cb.get_summary()["alerts_raised"] == 0
        finally:
            cb.shutdown()


# ---------------------------------------------------------------------
# Scenario D: health_check shape consistency.
#
# All three adapters' `health_check()` must return the SAME dict shape.
# Cross-language tooling depends on this contract — TS and Python
# produce the same shape in different naming conventions, but within a
# language all adapters are identical.
# ---------------------------------------------------------------------

class TestHealthCheckShapeConsistency:
    """Every adapter's `health_check()` returns the same key set."""

    _EXPECTED_KEYS = {"reachable", "version", "adapter", "degraded"}

    def test_custom_adapter_health_check_shape(self):
        sonar = monitor_orchestrator(_BASE_CONFIG)
        try:
            assert set(sonar.health_check().keys()) >= self._EXPECTED_KEYS
        finally:
            sonar.shutdown()

    def test_crewai_listener_health_check_shape(self):
        crewai = pytest.importorskip("crewai")
        from agentsonar._integrations.crewai_listener import AgentSonarListener
        listener = AgentSonarListener(config=_BASE_CONFIG)
        try:
            assert set(listener.health_check().keys()) >= self._EXPECTED_KEYS
        finally:
            listener.shutdown()

    def test_langgraph_callback_health_check_shape(self):
        langchain_core = pytest.importorskip("langchain_core")
        from agentsonar._integrations.langgraph_callback import AgentSonarCallback
        cb = AgentSonarCallback(config=_BASE_CONFIG)
        try:
            assert set(cb.health_check().keys()) >= self._EXPECTED_KEYS
        finally:
            cb.shutdown()

    def test_health_check_adapter_label_per_integration(self):
        """`adapter` field is the integration's telemetry name. Pin
        each label so a future rename is a deliberate choice."""
        sonar = monitor_orchestrator(_BASE_CONFIG)
        try:
            assert sonar.health_check()["adapter"] == "custom_python"
        finally:
            sonar.shutdown()

        crewai = pytest.importorskip("crewai")
        from agentsonar._integrations.crewai_listener import AgentSonarListener
        listener = AgentSonarListener(config=_BASE_CONFIG)
        try:
            assert listener.health_check()["adapter"] == "crewai"
        finally:
            listener.shutdown()

        langchain_core = pytest.importorskip("langchain_core")
        from agentsonar._integrations.langgraph_callback import AgentSonarCallback
        cb = AgentSonarCallback(config=_BASE_CONFIG)
        try:
            assert cb.health_check()["adapter"] == "langgraph"
        finally:
            cb.shutdown()


# ---------------------------------------------------------------------
# Scenario D: topology classification stays clean for multi-agent
# adapters (0.5.2 regression guard for universal node classifier).
#
# The 0.5.2 change added typed Topology fields (tools_involved,
# mcp_calls_involved, subagent_spawns_involved + counts) populated by
# the universal classifier in `_core/_node_types`. Multi-agent adapter
# events emit bare agent names → all typed buckets MUST stay empty.
# This is the cross-adapter regression guard for that contract.
# ---------------------------------------------------------------------


class TestTopologyClassificationRegression:
    """Multi-agent adapter events MUST have empty typed Topology
    buckets. If this ever breaks, an adapter started emitting
    prefixed names that match the universal classifier's TOOL / MCP /
    TASK_SPAWN rules (which would be a regression in the adapter's
    contract).

    The 5 named multi-agent adapter contracts validated here:
      - CustomAdapter (custom orchestrator)
      - AgentSonarListener (CrewAI)
      - AgentSonarCallback (LangGraph)
    All three emit plain agent names. None of them should produce a
    Topology with tool_count / mcp_count / task_spawn_count > 0.
    """

    _CONFIG = {**_BASE_CONFIG, "warning_threshold": 2, "critical_threshold": 4,
               "per_edge_limit": 5, "hard_weight_limit": 5.0,
               "min_total_events": 5, "min_edges_for_zscore": 5}

    @staticmethod
    def _assert_all_topologies_have_empty_typed_buckets(events) -> None:
        """Every event in `events` must have empty typed Topology buckets
        and zero typed counts. Failure means an adapter accidentally
        emitted a tool-shaped node name."""
        for ev in events:
            t = ev.topology
            if t is None:
                continue
            assert t.tool_count == 0, (
                f"event {ev.failure_class.value} unexpectedly has "
                f"tool_count={t.tool_count}; tools_involved={t.tools_involved}"
            )
            assert t.mcp_count == 0, (
                f"event {ev.failure_class.value} unexpectedly has "
                f"mcp_count={t.mcp_count}; mcp_calls_involved={t.mcp_calls_involved}"
            )
            assert t.task_spawn_count == 0, (
                f"event {ev.failure_class.value} unexpectedly has "
                f"task_spawn_count={t.task_spawn_count}; "
                f"subagent_spawns_involved={t.subagent_spawns_involved}"
            )
            assert t.tools_involved == ()
            assert t.mcp_calls_involved == ()
            assert t.subagent_spawns_involved == ()

    def test_custom_adapter_topology_all_agents(self):
        """Custom orchestrator with bare agent names → all events have
        empty typed buckets across every failure class fired."""
        sonar = monitor_orchestrator(config=self._CONFIG)
        try:
            ts = 1.0
            # Trigger repetitive: planner → researcher many times
            for _ in range(15):
                sonar.delegation("planner", "researcher", timestamp=ts)
                ts += 0.01
            # Trigger cycle: planner → researcher → writer → planner
            for _ in range(4):
                for src, tgt in (("planner", "researcher"),
                                 ("researcher", "writer"),
                                 ("writer", "planner")):
                    sonar.delegation(src, tgt, timestamp=ts)
                    ts += 0.1
            events = sonar.engine.get_recent_events()
            assert len(events) > 0, "expected at least one detection event"
            self._assert_all_topologies_have_empty_typed_buckets(events)
        finally:
            sonar.shutdown()

    def test_direct_engine_topology_all_agents(self):
        """The same regression guard at the engine layer, fed bare
        names directly. Validates the engine's classifier path."""
        engine = DetectionEngine(config=self._CONFIG, adapter="test_xcheck_topology")
        try:
            ts = 1.0
            for _ in range(15):
                engine.ingest(InteractionEvent("manager", "worker", ts, None))
                ts += 0.01
            events = engine.get_recent_events()
            assert len(events) > 0
            TestTopologyClassificationRegression._assert_all_topologies_have_empty_typed_buckets(
                events
            )
        finally:
            engine.shutdown()

    def test_langgraph_adapter_topology_all_agents(self):
        """LangGraph adapter feeds the same engine. The contract is:
        plain node names → empty typed buckets."""
        langchain_core = pytest.importorskip("langchain_core")
        from agentsonar._integrations.langgraph_callback import AgentSonarCallback

        cb = AgentSonarCallback(config=self._CONFIG)
        try:
            # Simulate node transitions through the callback's
            # internal handler. Use the same `on_chain_start` shape
            # the real LangGraph callback uses.
            from langchain_core.callbacks.base import BaseCallbackHandler  # noqa
            from uuid import uuid4
            run_id = uuid4()

            # Fire enough transitions to trip detection
            nodes = ["plan_node", "research_step", "writer_node"]
            for _ in range(15):
                for n in nodes:
                    try:
                        cb.on_chain_start(
                            serialized=None,
                            inputs={},
                            run_id=run_id,
                            metadata={"langgraph_node": n},
                        )
                    except Exception:
                        # Defensive: callback might be stricter than
                        # we expect. Skip the test gracefully if so.
                        pytest.skip("LangGraph callback shape mismatch")

            events = cb.engine.get_recent_events()
            self._assert_all_topologies_have_empty_typed_buckets(events)
        finally:
            cb.shutdown()


class TestClaudeCodeAdapterTopologyClassifies:
    """The complement to TestTopologyClassificationRegression: when
    the Claude Code adapter emits prefixed names, the typed buckets
    DO populate correctly. Same engine, different node-name shape."""

    _CONFIG = {**_BASE_CONFIG, "warning_threshold": 2, "critical_threshold": 4,
               "per_edge_limit": 5, "hard_weight_limit": 5.0,
               "min_total_events": 5, "min_edges_for_zscore": 5}

    def test_claude_code_shaped_events_populate_tools(self):
        """Fire `main -> Read:/src/x.py` repeatedly through the engine
        directly. The event's typed buckets MUST show tool_count=1."""
        engine = DetectionEngine(config=self._CONFIG, adapter="test_xcheck_cc")
        try:
            ts = 1.0
            for _ in range(15):
                engine.ingest(InteractionEvent("main", "Read:/src/x.py", ts, None))
                ts += 0.01
            events = engine.get_recent_events()
            assert len(events) > 0
            # At least one event should have tool_count = 1
            found = [e for e in events
                     if e.topology and e.topology.tool_count == 1]
            assert found, (
                f"expected at least one event with tool_count=1, got: "
                f"{[(e.failure_class.value, e.topology.tool_count if e.topology else None) for e in events]}"
            )
            assert "Read:/src/x.py" in found[0].topology.tools_involved
        finally:
            engine.shutdown()

    def test_claude_code_mcp_events_populate_mcp_bucket(self):
        engine = DetectionEngine(config=self._CONFIG, adapter="test_xcheck_mcp")
        try:
            ts = 1.0
            for _ in range(15):
                engine.ingest(InteractionEvent(
                    "main",
                    "mcp__github__create_issue:abc12345",
                    ts,
                    None,
                ))
                ts += 0.01
            events = engine.get_recent_events()
            found = [e for e in events
                     if e.topology and e.topology.mcp_count == 1]
            assert found
            assert "mcp__github__create_issue:abc12345" in found[0].topology.mcp_calls_involved
        finally:
            engine.shutdown()
