"""
Health-check parity tests for the CrewAI integration adapter
(`AgentSonarListener`).

Mirrors the same set of cases we cover for `CustomAdapter` and
`AgentSonarCallback` so the three adapters' `health_check()` surfaces
stay consistent. Skipped if crewai isn't installed (the listener
inherits from `crewai.utilities.events.base_event_listener
.BaseEventListener` and can't even import without it).
"""
from __future__ import annotations

import pytest

# Skip the whole module if crewai isn't installed. The listener can't
# import without it, so collection itself would fail.
crewai = pytest.importorskip("crewai")

from agentsonar._integrations.crewai_listener import AgentSonarListener  # noqa: E402

# File / console output off so the run directory doesn't pile up on disk.
_TEST_CONFIG = {"file_output": False, "console_output": False}


def test_crewai_health_check_returns_expected_shape_for_healthy_engine():
    """Healthy CrewAI listener reports degraded=False, omits reason,
    and identifies itself with adapter='crewai'."""
    from agentsonar._version import __version__

    listener = AgentSonarListener(config=_TEST_CONFIG)
    try:
        result = listener.health_check()
        assert result == {
            "reachable": True,
            "version": __version__,
            "adapter": "crewai",
            "degraded": False,
        }
        # `reason` MUST NOT be present on a healthy run.
        assert "reason" not in result
    finally:
        listener.shutdown()


def test_crewai_health_check_reports_degraded_when_killed_by_env(monkeypatch):
    """`AGENTSONAR_DISABLED=1` short-circuits engine construction.
    health_check surfaces this so ops dashboards can show why
    monitoring is silent."""
    monkeypatch.setenv("AGENTSONAR_DISABLED", "1")
    listener = AgentSonarListener(config=_TEST_CONFIG)
    try:
        result = listener.health_check()
        assert result["reachable"] is True
        assert result["degraded"] is True
        assert result["adapter"] == "crewai"
        assert "AGENTSONAR_DISABLED" in result.get("reason", "")
    finally:
        listener.shutdown()


def test_crewai_health_check_never_raises():
    """Hard contract: the method must not propagate exceptions, no
    matter how broken the engine is. Worst case is a fixed-shape
    degraded dict."""
    listener = AgentSonarListener(config=_TEST_CONFIG)
    try:
        # Replace the engine with something that has no get_summary().
        listener.engine = object()  # type: ignore[assignment]
        result = listener.health_check()
        assert result["reachable"] is True
        assert result["degraded"] is True
    finally:
        # Restore something safe so cleanup doesn't crash.
        from agentsonar._core.noop_engine import _NoOpEngine
        listener.engine = _NoOpEngine(reason="test cleanup")
        listener.shutdown()


# ---------------------------------------------------------------------------
# Item 1 (0.4.3) — handler unregister on shutdown.
# Without this, every new AgentSonarListener stays attached to the global
# bus forever; events fire ALL prior listeners' handlers, double-counting
# edges and pumping into shut-down engines.
# ---------------------------------------------------------------------------

from crewai.events import crewai_event_bus  # noqa: E402
from crewai.events.event_types import ToolUsageStartedEvent  # noqa: E402


def _emit_one_delegation() -> None:
    """Fire one synthetic ToolUsageStartedEvent + drain the thread pool."""
    event = ToolUsageStartedEvent(
        tool_name="delegate work",
        tool_args={"coworker": "b"},
        agent_role="a",
    )
    crewai_event_bus.emit(source=None, event=event)
    crewai_event_bus.flush()


def test_shutdown_unregisters_handlers():
    """After shutdown, this listener's handler must be gone from the bus.

    Pin the count, not the identity — multiple instances may register
    in the same test session, so absolute counts depend on what came
    before. We verify that the count DECREASED by exactly the number
    of handlers this listener registered.
    """
    before = len(
        crewai_event_bus._sync_handlers.get(ToolUsageStartedEvent, set())
    )
    listener = AgentSonarListener(config=_TEST_CONFIG)
    after_init = len(
        crewai_event_bus._sync_handlers.get(ToolUsageStartedEvent, set())
    )
    assert after_init == before + 1, (
        f"listener init should add exactly one ToolUsageStartedEvent "
        f"handler (before={before}, after={after_init})"
    )

    listener.shutdown()
    after_shutdown = len(
        crewai_event_bus._sync_handlers.get(ToolUsageStartedEvent, set())
    )
    assert after_shutdown == before, (
        f"shutdown should remove exactly one handler "
        f"(before={before}, after_init={after_init}, "
        f"after_shutdown={after_shutdown})"
    )


def test_two_listeners_in_sequence_dont_double_count():
    """Listener A shut down → Listener B in fresh state.

    Emit one delegation. B sees exactly 1 event. A's handler is gone so
    its (shut-down) engine doesn't get hit. This is the core regression
    that motivated Item 1 — long-running test suites / notebooks /
    web servers create multiple listeners and would otherwise pump
    every emit into every prior engine.
    """
    a = AgentSonarListener(config=_TEST_CONFIG)
    a.shutdown()

    b = AgentSonarListener(config=_TEST_CONFIG)
    try:
        _emit_one_delegation()
        # B's engine sees exactly 1 event (would be 2 if A's
        # handler was still attached and double-firing).
        assert b.get_summary()["total_events"] == 1
    finally:
        b.shutdown()


def test_shutdown_handler_unregister_failure_is_swallowed(monkeypatch):
    """If `bus.off()` raises (CrewAI changes its API in a future
    version, broken bus state, etc.), shutdown must STILL complete
    and run engine.shutdown()."""
    listener = AgentSonarListener(config=_TEST_CONFIG)

    # Force `off` to raise. Each handler we try to unregister will hit
    # this; per-handler try/except in shutdown should swallow each one.
    def _boom(*_args, **_kwargs):
        raise RuntimeError("simulated bus.off() failure")

    monkeypatch.setattr(crewai_event_bus, "off", _boom)

    # Track whether engine.shutdown ran. We can't easily monkeypatch
    # the engine's shutdown without breaking other state, so just
    # verify the listener.shutdown() call doesn't raise.
    listener.shutdown()  # must not raise
    # Engine should have been shut down despite the unregister failure.
    assert listener.engine._shutdown_requested


# ---------------------------------------------------------------------------
# Item 4 (0.4.3) — auto-flush in get_summary() and health_check().
# CrewAI dispatches sync handlers to a thread-pool executor; reading
# engine state right after a burst of emits would race the handlers.
# `bus.flush()` blocks until the pool drains, so callers see consistent
# state. Both methods should call flush internally.
# ---------------------------------------------------------------------------


def test_get_summary_drains_pending_events():
    """A burst of emits followed by an IMMEDIATE get_summary() should
    show the full count — no race with the thread pool."""
    listener = AgentSonarListener(config=_TEST_CONFIG)
    try:
        # Emit a small burst WITHOUT calling flush ourselves.
        for _ in range(5):
            event = ToolUsageStartedEvent(
                tool_name="delegate work",
                tool_args={"coworker": "b"},
                agent_role="a",
            )
            crewai_event_bus.emit(source=None, event=event)
        # If get_summary() doesn't auto-flush, this can return 0..5
        # depending on thread-pool timing. With auto-flush it returns
        # exactly 5.
        assert listener.get_summary()["total_events"] == 5
    finally:
        listener.shutdown()


def test_get_summary_handles_flush_failure(monkeypatch):
    """If `bus.flush()` raises, get_summary() must still return a
    valid summary dict (possibly with stale counts). The flush is a
    UX nicety, not a correctness requirement."""
    listener = AgentSonarListener(config=_TEST_CONFIG)
    try:
        def _boom():
            raise RuntimeError("simulated flush failure")
        monkeypatch.setattr(crewai_event_bus, "flush", _boom)

        result = listener.get_summary()
        assert isinstance(result, dict)
        assert "total_events" in result
    finally:
        listener.shutdown()
