"""
Tests for `agentsonar install-claude-hooks` and the underlying
`claude.installer.install()` function.

Covers:
  - Fresh write (no existing settings.json)
  - Merge with existing settings.json (preserves user keys)
  - Idempotency (running twice produces the same result)
  - Re-install replaces previous AgentSonar entries without duplication
  - --dry-run writes nothing but prints the would-be JSON
  - --force overrides conflict refusal
  - Conflict without --force exits 1 with friendly error
  - Emitted command uses `python -m agentsonar` form
  - CLAUDE_CONFIG_DIR env var is honored when no --path given
  - JSON output is parseable and contains all 4 event types
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from agentsonar._integrations.claude.installer import (
    _build_hook_command,
    _is_agentsonar_command,
    install,
)


# =====================================================================
# Fresh write
# =====================================================================


class TestFreshWrite:

    def test_install_writes_settings_json_when_none_exists(self, tmp_path):
        target = tmp_path / ".claude" / "settings.json"
        rc = install(target_path=target)
        assert rc == 0
        assert target.exists()

    def test_settings_json_is_valid_json(self, tmp_path):
        target = tmp_path / ".claude" / "settings.json"
        install(target_path=target)
        data = json.loads(target.read_text(encoding="utf-8"))
        assert isinstance(data, dict)
        assert "hooks" in data

    def test_settings_json_has_all_four_events(self, tmp_path):
        target = tmp_path / ".claude" / "settings.json"
        install(target_path=target)
        hooks = json.loads(target.read_text(encoding="utf-8"))["hooks"]
        for event in ("PreToolUse", "PostToolUse", "Stop", "SubagentStop"):
            assert event in hooks, f"missing event {event}"
            assert isinstance(hooks[event], list)
            assert len(hooks[event]) >= 1

    def test_emitted_command_is_python_dash_m_form(self, tmp_path):
        target = tmp_path / ".claude" / "settings.json"
        install(target_path=target)
        hooks = json.loads(target.read_text(encoding="utf-8"))["hooks"]
        entry = hooks["PreToolUse"][0]
        cmd = entry["hooks"][0]["command"]
        assert cmd == "python -m agentsonar claude-code-hook PreToolUse"

    def test_pre_post_tool_use_have_wildcard_matcher(self, tmp_path):
        target = tmp_path / ".claude" / "settings.json"
        install(target_path=target)
        hooks = json.loads(target.read_text(encoding="utf-8"))["hooks"]
        for event in ("PreToolUse", "PostToolUse"):
            assert hooks[event][0]["matcher"] == "*"

    def test_stop_subagentstop_have_no_matcher(self, tmp_path):
        """Stop / SubagentStop fire on lifecycle events, not tool calls;
        no matcher per Claude Code's hook spec."""
        target = tmp_path / ".claude" / "settings.json"
        install(target_path=target)
        hooks = json.loads(target.read_text(encoding="utf-8"))["hooks"]
        for event in ("Stop", "SubagentStop"):
            assert "matcher" not in hooks[event][0]


# =====================================================================
# Merge with existing
# =====================================================================


class TestMergeWithExisting:

    def test_merge_preserves_non_hook_top_level_keys(self, tmp_path):
        target = tmp_path / ".claude" / "settings.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        existing = {
            "mcp": {"servers": {"github": {"command": "mcp-github"}}},
            "permissions": {"allow": ["Bash(ls)"]},
            "hooks": {},
        }
        target.write_text(json.dumps(existing), encoding="utf-8")

        rc = install(target_path=target)
        assert rc == 0
        data = json.loads(target.read_text(encoding="utf-8"))
        assert data["mcp"] == existing["mcp"]
        assert data["permissions"] == existing["permissions"]
        # And hooks now has the 4 events
        for event in ("PreToolUse", "PostToolUse", "Stop", "SubagentStop"):
            assert event in data["hooks"]

    def test_merge_preserves_user_hooks_on_different_events(self, tmp_path):
        target = tmp_path / ".claude" / "settings.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        existing = {
            "hooks": {
                "Notification": [{
                    "hooks": [{"type": "command", "command": "my-notification-hook"}]
                }],
            }
        }
        target.write_text(json.dumps(existing), encoding="utf-8")

        install(target_path=target)
        data = json.loads(target.read_text(encoding="utf-8"))
        # User's Notification hook preserved
        assert data["hooks"]["Notification"][0]["hooks"][0]["command"] == "my-notification-hook"
        # AgentSonar's 4 events added
        for event in ("PreToolUse", "PostToolUse", "Stop", "SubagentStop"):
            assert event in data["hooks"]

    def test_merge_preserves_user_hooks_on_same_event_with_different_matcher(
        self, tmp_path
    ):
        """User has a matcher-scoped hook on PreToolUse (e.g. matcher='Bash');
        AgentSonar's matcher='*' hook is appended alongside, not replacing it."""
        target = tmp_path / ".claude" / "settings.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        existing = {
            "hooks": {
                "PreToolUse": [{
                    "matcher": "Bash",
                    "hooks": [{"type": "command", "command": "user-bash-watcher"}],
                }],
            }
        }
        target.write_text(json.dumps(existing), encoding="utf-8")

        rc = install(target_path=target)
        assert rc == 0
        data = json.loads(target.read_text(encoding="utf-8"))
        entries = data["hooks"]["PreToolUse"]
        # User's Bash-only hook preserved
        user_entries = [e for e in entries if e.get("matcher") == "Bash"]
        assert len(user_entries) == 1
        assert user_entries[0]["hooks"][0]["command"] == "user-bash-watcher"
        # AgentSonar's wildcard hook added
        as_entries = [e for e in entries if e.get("matcher") == "*"]
        assert len(as_entries) == 1


# =====================================================================
# Idempotency
# =====================================================================


class TestIdempotency:

    def test_running_install_twice_is_idempotent(self, tmp_path):
        target = tmp_path / ".claude" / "settings.json"
        install(target_path=target)
        first = target.read_text(encoding="utf-8")
        install(target_path=target)
        second = target.read_text(encoding="utf-8")
        assert first == second, "second install should produce identical content"

    def test_reinstall_does_not_duplicate_agentsonar_entries(self, tmp_path):
        """Re-running install replaces previous AgentSonar entries; the
        result has exactly ONE AgentSonar hook per event."""
        target = tmp_path / ".claude" / "settings.json"
        install(target_path=target)
        install(target_path=target)
        install(target_path=target)
        data = json.loads(target.read_text(encoding="utf-8"))
        for event in ("PreToolUse", "PostToolUse", "Stop", "SubagentStop"):
            as_entries = [
                e for e in data["hooks"][event]
                if any(
                    _is_agentsonar_command(h.get("command", ""))
                    for h in e.get("hooks", [])
                )
            ]
            assert len(as_entries) == 1, (
                f"event {event} has {len(as_entries)} AgentSonar entries; "
                f"expected exactly 1"
            )


# =====================================================================
# Dry-run
# =====================================================================


class TestDryRun:

    def test_dry_run_writes_nothing(self, tmp_path, capsys):
        target = tmp_path / ".claude" / "settings.json"
        rc = install(target_path=target, dry_run=True)
        assert rc == 0
        assert not target.exists()

    def test_dry_run_prints_resulting_json(self, tmp_path, capsys):
        target = tmp_path / ".claude" / "settings.json"
        install(target_path=target, dry_run=True)
        captured = capsys.readouterr()
        # Should print the JSON between markers
        assert "dry-run" in captured.out
        assert "PreToolUse" in captured.out
        assert "python -m agentsonar claude-code-hook" in captured.out


# =====================================================================
# Force / conflict handling
# =====================================================================


class TestForceAndConflict:

    def test_no_conflict_clean_install(self, tmp_path):
        target = tmp_path / ".claude" / "settings.json"
        rc = install(target_path=target)
        assert rc == 0

    def test_conflict_without_force_returns_1(self, tmp_path, capsys):
        """A non-AgentSonar hook on PreToolUse with matcher '*' conflicts
        with what we want to register. Without --force, exit 1."""
        target = tmp_path / ".claude" / "settings.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        existing = {
            "hooks": {
                "PreToolUse": [{
                    "matcher": "*",
                    "hooks": [{"type": "command", "command": "user-pre-hook"}],
                }],
            }
        }
        target.write_text(json.dumps(existing), encoding="utf-8")

        rc = install(target_path=target)
        assert rc == 1
        captured = capsys.readouterr()
        assert "PreToolUse" in captured.err
        assert "force" in captured.err.lower()

    def test_conflict_with_force_overwrites(self, tmp_path):
        target = tmp_path / ".claude" / "settings.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        existing = {
            "hooks": {
                "PreToolUse": [{
                    "matcher": "*",
                    "hooks": [{"type": "command", "command": "user-pre-hook"}],
                }],
            }
        }
        target.write_text(json.dumps(existing), encoding="utf-8")

        rc = install(target_path=target, force=True)
        assert rc == 0
        # AgentSonar hook now present
        data = json.loads(target.read_text(encoding="utf-8"))
        cmds = [
            h.get("command")
            for entry in data["hooks"]["PreToolUse"]
            for h in entry.get("hooks", [])
        ]
        assert any("python -m agentsonar" in c for c in cmds if c)


# =====================================================================
# Target path resolution
# =====================================================================


class TestTargetPathResolution:

    def test_explicit_path_wins(self, tmp_path, monkeypatch):
        target = tmp_path / "explicit" / "settings.json"
        monkeypatch.setenv("CLAUDE_CONFIG_DIR", str(tmp_path / "env_dir"))
        install(target_path=target)
        assert target.exists()
        assert not (tmp_path / "env_dir" / "settings.json").exists()

    def test_claude_config_dir_env_var(self, tmp_path, monkeypatch):
        env_dir = tmp_path / "from_env"
        monkeypatch.setenv("CLAUDE_CONFIG_DIR", str(env_dir))
        monkeypatch.chdir(tmp_path)
        install()
        assert (env_dir / "settings.json").exists()

    def test_default_to_cwd_dot_claude(self, tmp_path, monkeypatch):
        monkeypatch.delenv("CLAUDE_CONFIG_DIR", raising=False)
        monkeypatch.chdir(tmp_path)
        install()
        assert (tmp_path / ".claude" / "settings.json").exists()


# =====================================================================
# Helper functions
# =====================================================================


class TestHelpers:

    def test_build_hook_command_matches_expected_form(self):
        assert _build_hook_command("PreToolUse") == "python -m agentsonar claude-code-hook PreToolUse"
        assert _build_hook_command("Stop") == "python -m agentsonar claude-code-hook Stop"

    def test_is_agentsonar_command_recognizes_new_form(self):
        assert _is_agentsonar_command("python -m agentsonar claude-code-hook PreToolUse")

    def test_is_agentsonar_command_recognizes_old_form(self):
        """Backward compat: detect older bare-script form too."""
        assert _is_agentsonar_command("agentsonar claude-code-hook PreToolUse")

    def test_is_agentsonar_command_recognizes_absolute_python_path(self):
        assert _is_agentsonar_command(
            "C:/Users/u/.venv/Scripts/python.exe -m agentsonar claude-code-hook PreToolUse"
        )

    def test_is_agentsonar_command_rejects_unrelated(self):
        assert not _is_agentsonar_command("my-custom-hook")
        assert not _is_agentsonar_command("python -m some_other_pkg run")
        assert not _is_agentsonar_command(None)
        assert not _is_agentsonar_command(42)


# =====================================================================
# Malformed input handling
# =====================================================================


class TestMalformedInputHandling:

    def test_non_json_existing_file_without_force_returns_2(self, tmp_path):
        target = tmp_path / ".claude" / "settings.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("this is not json {{{", encoding="utf-8")

        rc = install(target_path=target)
        assert rc == 2

    def test_non_json_existing_file_with_force_overwrites(self, tmp_path):
        target = tmp_path / ".claude" / "settings.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("not json {{{", encoding="utf-8")

        rc = install(target_path=target, force=True)
        assert rc == 0
        data = json.loads(target.read_text(encoding="utf-8"))
        assert "hooks" in data

    def test_existing_file_with_array_root_without_force_returns_2(self, tmp_path):
        target = tmp_path / ".claude" / "settings.json"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("[1, 2, 3]", encoding="utf-8")

        rc = install(target_path=target)
        assert rc == 2
