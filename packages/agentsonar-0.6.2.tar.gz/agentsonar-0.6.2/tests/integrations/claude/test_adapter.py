"""
Tests for the Claude Code adapter (`agentsonar._integrations.claude`).

Coverage groups:
  1. Hook payload parsing
  2. Content-blind extraction (load-bearing privacy claim)
  3. Edge translation (source_agent, target_agent, Task spawn shape)
  4. State persistence (load, save, corruption recovery, file lock)
  5. Exit codes (host-safety contract: only Prevent trip is non-zero)
  6. Cumulative report regeneration on Stop
  7. Session boundary detection (new session_id, inactivity sweep)
  8. Subagent type registry
  9. timeline.jsonl protocol commitments (schema, append-only)
 10. AGENTSONAR_REGULATED path redaction
 11. The CONTENT-BLIND SENTINEL AUDIT (THE most-load-bearing test)

The sentinel audit (section 11) is the privacy claim's enforcement
point. It runs payloads that include unique canary strings as tool
input / tool response content, then greps EVERY file the adapter
wrote on disk for the sentinel. The adapter's content-blind contract
fails the moment the sentinel appears anywhere on disk.

Test isolation:
  Every test routes the adapter's state directory through a per-test
  tmp_path via the AGENTSONAR_CLAUDE_CODE_ROOT env var. No test
  pollutes the developer's real ~/.agentsonar/.
"""
from __future__ import annotations

import json
import os
import pickle
import sys
import threading
import time
from pathlib import Path
from typing import Any

import pytest

from agentsonar._integrations.claude import adapter as cc
from agentsonar._integrations.claude import (
    derive_source_agent,
    derive_target_agent,
    extract_metadata,
    handle_hook,
    resolve_root_session_id,
    run_hook,
    TIMELINE_SCHEMA_VERSION,
)


# =====================================================================
# Fixtures
# =====================================================================

@pytest.fixture(autouse=True)
def _isolate_adapter_state(tmp_path, monkeypatch):
    """Route AGENTSONAR_CLAUDE_CODE_ROOT to a per-test tmpdir.

    Every test gets a fresh state directory. No test touches the
    developer's real `~/.agentsonar/`. Also disables telemetry.

    Clears every AGENTSONAR_* tuning env var so a developer running
    pytest from a session that has `.claude/settings.json` configured
    doesn't leak threshold / prevent settings into tests. Each test
    that needs a specific config sets its own via monkeypatch.
    """
    monkeypatch.setenv("AGENTSONAR_CLAUDE_CODE_ROOT", str(tmp_path))
    monkeypatch.setenv("AGENTSONAR_TELEMETRY", "off")
    # Clear every AGENTSONAR_* env that could shape detection
    # behavior. Required for cross-machine reproducibility when the
    # dev's own .claude/settings.json sets these for live sessions.
    _LEAKABLE_ENV_VARS = (
        "AGENTSONAR_REGULATED",
        "AGENTSONAR_WARNING_THRESHOLD",
        "AGENTSONAR_CRITICAL_THRESHOLD",
        "AGENTSONAR_CYCLE_WARNING_THRESHOLD",
        "AGENTSONAR_CYCLE_CRITICAL_THRESHOLD",
        "AGENTSONAR_EDGE_ANOMALY_WARNING_THRESHOLD",
        "AGENTSONAR_EDGE_ANOMALY_CRITICAL_THRESHOLD",
        "AGENTSONAR_HARD_WEIGHT_LIMIT",
        "AGENTSONAR_PER_EDGE_LIMIT",
        "AGENTSONAR_GLOBAL_LIMIT",
        "AGENTSONAR_RATE_WINDOW_SECONDS",
        "AGENTSONAR_RATE_RESET_RATIO",
        "AGENTSONAR_PREVENT_CYCLE_MAX_ROTATIONS",
        "AGENTSONAR_PREVENT_REPETITIVE_MAX_EVENTS",
        "AGENTSONAR_PREVENT_RATE_LIMIT",
        "AGENTSONAR_PREVENT_ALL",
        "AGENTSONAR_INACTIVITY_SECONDS",
        "AGENTSONAR_LOCK_TIMEOUT_SECONDS",
        "AGENTSONAR_ARCHIVE_RETENTION_DAYS",
    )
    for var in _LEAKABLE_ENV_VARS:
        monkeypatch.delenv(var, raising=False)
    yield tmp_path


def _payload(
    *,
    session_id: str = "session-root-1234",
    parent_session_id: str | None = None,
    tool_name: str = "Read",
    tool_input: Any | None = None,
    tool_response: Any | None = None,
    cwd: str = "/home/test",
    subagent_depth: int = 0,
) -> dict:
    """Build a Claude Code hook payload for tests."""
    if tool_input is None:
        tool_input = {"file_path": "/src/foo.py"}
    p: dict = {
        "session_id": session_id,
        "parent_session_id": parent_session_id,
        "tool_name": tool_name,
        "tool_input": tool_input,
        "cwd": cwd,
        "subagent_depth": subagent_depth,
    }
    if tool_response is not None:
        p["tool_response"] = tool_response
    return p


def _read_lines(path: Path) -> list[dict]:
    """Read all lines from `timeline.jsonl` and parse each as JSON."""
    if not path.exists():
        return []
    out: list[dict] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out


def _all_files_on_disk(root: Path) -> list[Path]:
    """Recursively list every file under `root`."""
    return [p for p in root.rglob("*") if p.is_file()]


# =====================================================================
# 1. Hook payload parsing
# =====================================================================

class TestHookPayloadParsing:

    def test_pretooluse_known_event_returns_0(self):
        rc = handle_hook("PreToolUse", _payload())
        assert rc == 0

    def test_posttooluse_known_event_returns_0(self):
        rc = handle_hook("PostToolUse", _payload(tool_response={"ok": True}))
        assert rc == 0

    def test_stop_known_event_returns_0(self):
        rc = handle_hook("Stop", _payload())
        assert rc == 0

    def test_subagentstop_known_event_returns_0(self):
        rc = handle_hook(
            "SubagentStop",
            _payload(
                session_id="subagent-aaaa",
                parent_session_id="root-1234",
            ),
        )
        assert rc == 0

    def test_unknown_event_name_returns_0_silently(self):
        rc = handle_hook("DefinitelyNotAHookEvent", _payload())
        assert rc == 0

    def test_userpromptsubmit_is_explicitly_ignored(self):
        rc = handle_hook("UserPromptSubmit", _payload())
        assert rc == 0
        # No state directory should be created for an ignored event.
        # (The session_id was set but we never reached session_dir.mkdir.)

    def test_notification_is_explicitly_ignored(self):
        rc = handle_hook("Notification", _payload())
        assert rc == 0

    def test_non_dict_payload_returns_0(self):
        rc = handle_hook("PreToolUse", "not a dict")
        assert rc == 0

    def test_run_hook_with_malformed_stdin_returns_0(self):
        import io
        bad_stdin = io.StringIO("{this is not json}")
        rc = run_hook("PreToolUse", stdin=bad_stdin)
        assert rc == 0

    def test_run_hook_with_empty_stdin_returns_0(self):
        import io
        rc = run_hook("PreToolUse", stdin=io.StringIO(""))
        assert rc == 0


# =====================================================================
# 2. Content-blind extraction
# =====================================================================

class TestContentBlindExtraction:

    def test_allowlist_fields_present(self):
        meta = extract_metadata(_payload(), hook_arrival_ts=1700000000.0)
        for key in (
            "tool_name", "input_fingerprint", "input_size_bytes",
            "output_size_bytes", "status", "session_id", "timestamp",
        ):
            assert key in meta, f"missing required key {key}"

    def test_fingerprint_stable_for_same_input(self):
        m1 = extract_metadata(
            _payload(tool_input={"file_path": "/x/y.py"}),
            hook_arrival_ts=1.0,
        )
        m2 = extract_metadata(
            _payload(tool_input={"file_path": "/x/y.py"}),
            hook_arrival_ts=2.0,
        )
        assert m1["input_fingerprint"] == m2["input_fingerprint"]

    def test_fingerprint_differs_for_different_input(self):
        m1 = extract_metadata(
            _payload(tool_input={"file_path": "/x/y.py"}),
            hook_arrival_ts=1.0,
        )
        m2 = extract_metadata(
            _payload(tool_input={"file_path": "/x/z.py"}),
            hook_arrival_ts=1.0,
        )
        assert m1["input_fingerprint"] != m2["input_fingerprint"]

    def test_subagent_type_is_cleartext(self):
        """0.6.1+: subagent_type is an IDENTIFIER, not content. Always
        cleartext, never hashed. AGENTSONAR_REGULATED affects paths only."""
        payload = _payload(
            tool_name="Task",
            tool_input={"subagent_type": "code-reviewer"},
        )
        meta = extract_metadata(payload, hook_arrival_ts=1.0)
        assert meta["subagent_type"] == "code-reviewer"

    def test_subagent_type_cleartext_under_regulated_mode(self, monkeypatch):
        """The privacy contract: AGENTSONAR_REGULATED redacts PATHS,
        not identifiers. Subagent types stay cleartext even in regulated
        mode (they are organizational labels, not user content)."""
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        payload = _payload(
            tool_name="Task",
            tool_input={"subagent_type": "code-reviewer"},
        )
        meta = extract_metadata(payload, hook_arrival_ts=1.0)
        assert meta["subagent_type"] == "code-reviewer"

    def test_subagent_type_same_label_same_value(self):
        """Same label produces the same metadata value across calls
        (deterministic). Cleartext compares trivially."""
        meta_a = extract_metadata(
            _payload(tool_name="Task", tool_input={"subagent_type": "code-reviewer"}),
            hook_arrival_ts=1.0,
        )
        meta_b = extract_metadata(
            _payload(tool_name="Task", tool_input={"subagent_type": "code-reviewer"}),
            hook_arrival_ts=1.0,
        )
        assert meta_a["subagent_type"] == meta_b["subagent_type"] == "code-reviewer"

    def test_target_path_extracted_for_path_bearing_tools(self):
        for tool in ("Read", "Edit", "Write", "MultiEdit", "NotebookEdit"):
            meta = extract_metadata(
                _payload(tool_name=tool, tool_input={"file_path": "/a/b.py"}),
                hook_arrival_ts=1.0,
            )
            assert meta.get("target_path") == "/a/b.py", f"{tool} missed target_path"

    def test_target_path_is_none_for_pathless_tools(self):
        """Pathless tools (Bash, Task, WebFetch) keep the target_path
        key on the record but set it to None. Stable-schema commitment
        for downstream consumers: keys are always present; absent
        values are explicit None."""
        for tool in ("Bash", "Task", "WebFetch"):
            meta = extract_metadata(
                _payload(tool_name=tool, tool_input={"command": "ls"}),
                hook_arrival_ts=1.0,
            )
            assert "target_path" in meta, f"{tool} missing target_path key"
            assert meta["target_path"] is None, (
                f"{tool} should have target_path=None, got {meta['target_path']}"
            )

    def test_mcp_tool_naming_convention_enriched(self):
        meta = extract_metadata(
            _payload(tool_name="mcp__github__create_issue", tool_input={"title": "x"}),
            hook_arrival_ts=1.0,
        )
        assert meta.get("mcp_server") == "github"

    def test_mcp_tool_segment_extracted_as_separate_metadata(self):
        """0.5.2: alongside mcp_server, the tool segment of
        mcp__<server>__<tool> is parsed into mcp_tool metadata. Both
        are content-blind (extracted from the tool_name string, which
        is already in the allowlist)."""
        meta = extract_metadata(
            _payload(tool_name="mcp__github__create_issue", tool_input={"title": "x"}),
            hook_arrival_ts=1.0,
        )
        assert meta.get("mcp_server") == "github"
        assert meta.get("mcp_tool") == "create_issue"

    def test_mcp_tool_segment_handles_underscores_in_tool_name(self):
        """The tool segment may itself contain underscores. The split
        is `mcp__<server>__<rest>` so the tool part can be multi-word."""
        meta = extract_metadata(
            _payload(
                tool_name="mcp__brand_new_server__do_a_thing_with_underscores",
                tool_input={},
            ),
            hook_arrival_ts=1.0,
        )
        assert meta.get("mcp_server") == "brand_new_server"
        assert meta.get("mcp_tool") == "do_a_thing_with_underscores"

    def test_non_mcp_tool_has_no_mcp_tool_field(self):
        meta = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/x"}),
            hook_arrival_ts=1.0,
        )
        assert "mcp_tool" not in meta
        assert "mcp_server" not in meta

    def test_non_mcp_tool_has_no_mcp_server_key(self):
        meta = extract_metadata(
            _payload(tool_name="Bash", tool_input={"command": "ls"}),
            hook_arrival_ts=1.0,
        )
        assert "mcp_server" not in meta

    def test_status_derived_from_response_shape(self):
        success = extract_metadata(
            _payload(tool_response={"result": "ok"}),
            hook_arrival_ts=1.0,
        )
        assert success["status"] == "success"
        error = extract_metadata(
            _payload(tool_response={"error": "boom"}),
            hook_arrival_ts=1.0,
        )
        assert error["status"] == "error"
        is_error = extract_metadata(
            _payload(tool_response={"is_error": True, "message": "x"}),
            hook_arrival_ts=1.0,
        )
        assert is_error["status"] == "error"

    def test_input_size_bytes_reflects_canonical_json_length(self):
        meta = extract_metadata(
            _payload(tool_input={"k": "v"}),
            hook_arrival_ts=1.0,
        )
        assert meta["input_size_bytes"] > 0

    def test_garbage_payload_does_not_raise(self):
        # Throw a kitchen sink of broken inputs at it.
        for bad in (None, "string", 42, [], {"tool_input": object()}):
            meta = extract_metadata(bad, hook_arrival_ts=1.0)  # type: ignore[arg-type]
            assert isinstance(meta, dict)


# =====================================================================
# 3. Edge translation
# =====================================================================

class TestEdgeTranslation:

    def test_root_session_source_is_main(self):
        assert derive_source_agent(_payload(parent_session_id=None)) == "main"

    def test_subagent_session_source_is_per_instance(self):
        p = _payload(
            session_id="abcdef1234567890",
            parent_session_id="root-xxx",
        )
        assert derive_source_agent(p) == "subagent_abcdef12"

    def test_two_subagents_same_type_have_distinct_source_agents(self):
        a = derive_source_agent(_payload(
            session_id="aaaaaaaa-1111",
            parent_session_id="root",
        ))
        b = derive_source_agent(_payload(
            session_id="bbbbbbbb-2222",
            parent_session_id="root",
        ))
        assert a != b

    def test_task_spawn_target_uses_cleartext_subagent_type(self):
        """0.6.1+: target_agent embeds the cleartext subagent_type
        (an identifier, never hashed). Same type -> same target."""
        meta = extract_metadata(
            _payload(tool_name="Task", tool_input={"subagent_type": "reviewer"}),
            hook_arrival_ts=1.0,
        )
        target = derive_target_agent("Task", meta)
        assert target == "Task_spawn:reviewer"

    def test_agent_tool_target_uses_cleartext_subagent_type(self):
        """0.6.1+: Anthropic renamed Task -> Agent. The new tool name
        produces `Agent_spawn:<cleartext>` with identical semantics."""
        meta = extract_metadata(
            _payload(tool_name="Agent", tool_input={"subagent_type": "researcher"}),
            hook_arrival_ts=1.0,
        )
        target = derive_target_agent("Agent", meta)
        assert target == "Agent_spawn:researcher"

    def test_multiple_agent_spawns_same_type_collapse_to_one_edge(self):
        """The whole point of cleartext: 5 spawns of the same subagent
        type produce the same target_agent so the repetitive detector
        can see them as one hot edge."""
        targets = set()
        for prompt in ("first task", "second task", "third"):
            meta = extract_metadata(
                _payload(
                    tool_name="Agent",
                    tool_input={"subagent_type": "researcher", "prompt": prompt},
                ),
                hook_arrival_ts=1.0,
            )
            targets.add(derive_target_agent("Agent", meta))
        assert targets == {"Agent_spawn:researcher"}

    def test_task_spawn_target_falls_back_to_input_fingerprint(self):
        meta = extract_metadata(
            _payload(tool_name="Task", tool_input={"description": "no subagent_type"}),
            hook_arrival_ts=1.0,
        )
        target = derive_target_agent("Task", meta)
        assert target.startswith("Task_spawn:")

    def test_agent_spawn_target_falls_back_to_input_fingerprint(self):
        meta = extract_metadata(
            _payload(tool_name="Agent", tool_input={"description": "no subagent_type"}),
            hook_arrival_ts=1.0,
        )
        target = derive_target_agent("Agent", meta)
        assert target.startswith("Agent_spawn:")

    def test_normal_tool_target_uses_input_fingerprint(self):
        meta = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/x"}),
            hook_arrival_ts=1.0,
        )
        target = derive_target_agent("Read", meta)
        assert target.startswith("Read:")

    def test_path_bearing_tool_target_uses_file_path_not_fingerprint(self):
        """Demo-readability: Read on /src/hello.py shows as
        'Read:/src/hello.py', not 'Read:<8-char-hex>'. Same path always
        produces the same edge so Layer 2 detection still works."""
        meta = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/hello.py"}),
            hook_arrival_ts=1.0,
        )
        target = derive_target_agent("Read", meta)
        assert target == "Read:/src/hello.py", (
            f"path-bearing target should be path-based; got {target!r}"
        )
        for tool in ("Edit", "Write", "Grep", "Glob", "MultiEdit"):
            meta = extract_metadata(
                _payload(tool_name=tool, tool_input={"file_path": "/src/x.py"}),
                hook_arrival_ts=1.0,
            )
            target = derive_target_agent(tool, meta)
            assert target == f"{tool}:/src/x.py", (
                f"{tool} target should be path-based; got {target!r}"
            )

    def test_path_bearing_target_honors_regulated_redaction(self, monkeypatch):
        """Under AGENTSONAR_REGULATED, target_path is hashed, and the
        edge name picks up the hashed form. Detection still works
        because hashes are deterministic."""
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        meta = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/secret.py"}),
            hook_arrival_ts=1.0,
        )
        target = derive_target_agent("Read", meta)
        assert target.startswith("Read:path:"), (
            f"regulated target should embed the hash form; got {target!r}"
        )
        assert "secret.py" not in target

    def test_non_path_tool_keeps_fingerprint_form(self):
        """Tools without target_path (Bash, MCP, WebFetch) still use
        the 8-char fingerprint tail. The fingerprint is the only stable
        structural identifier when no path is available, and we can't
        echo the command string (content-blind contract)."""
        for tool in ("Bash", "WebFetch", "mcp__github__create_issue"):
            meta = extract_metadata(
                _payload(tool_name=tool, tool_input={"command": "ls"}),
                hook_arrival_ts=1.0,
            )
            target = derive_target_agent(tool, meta)
            assert ":" in target
            tail = target.split(":", 1)[1]
            assert len(tail) == 8 and all(c in "0123456789abcdef" for c in tail), (
                f"{tool} target tail should be 8 hex chars; got {target!r}"
            )

    def test_resolve_root_session_id_returns_session_for_root(self):
        p = _payload(session_id="root-xyz", parent_session_id=None)
        assert resolve_root_session_id(p) == "root-xyz"

    def test_resolve_root_session_id_returns_parent_for_subagent(self):
        p = _payload(session_id="sub-xyz", parent_session_id="root-xyz")
        assert resolve_root_session_id(p) == "root-xyz"


# =====================================================================
# 4. State persistence
# =====================================================================

class TestStatePersistence:

    def test_first_hook_creates_session_dir(self, tmp_path):
        rc = handle_hook("PreToolUse", _payload(session_id="sid-new"))
        assert rc == 0
        assert (tmp_path / "sessions" / "sid-new" / "state.pkl").exists()
        assert (tmp_path / "sessions" / "sid-new" / "timeline.jsonl").exists()
        assert (tmp_path / "sessions" / "sid-new" / "last_hook_at").exists()

    def test_subsequent_hook_loads_existing_state(self, tmp_path):
        handle_hook("PreToolUse", _payload(session_id="sid-load"))
        state_path = tmp_path / "sessions" / "sid-load" / "state.pkl"
        first_mtime = state_path.stat().st_mtime
        time.sleep(0.05)
        handle_hook("PostToolUse", _payload(
            session_id="sid-load",
            tool_response={"ok": True},
        ))
        # state.pkl was rewritten.
        assert state_path.stat().st_mtime > first_mtime

    def test_corrupt_state_pkl_recovered(self, tmp_path):
        # Pre-populate with garbage.
        session_dir = tmp_path / "sessions" / "sid-corrupt"
        session_dir.mkdir(parents=True, exist_ok=True)
        (session_dir / "state.pkl").write_bytes(b"this is not a pickle")
        # Hook should still succeed.
        rc = handle_hook("PreToolUse", _payload(session_id="sid-corrupt"))
        assert rc == 0
        # State pkl was rewritten to a valid one.
        with open(session_dir / "state.pkl", "rb") as f:
            blob = pickle.load(f)
        assert isinstance(blob, dict)
        assert blob.get("schema_version") == TIMELINE_SCHEMA_VERSION

    def test_timeline_is_append_only(self, tmp_path):
        for _ in range(5):
            handle_hook("PreToolUse", _payload(session_id="sid-append"))
        timeline = tmp_path / "sessions" / "sid-append" / "timeline.jsonl"
        lines = _read_lines(timeline)
        assert len(lines) == 5
        for line in lines:
            assert line["schema_version"] == TIMELINE_SCHEMA_VERSION

    def test_state_pkl_atomic_rename_leaves_no_temp_files(self, tmp_path):
        for _ in range(10):
            handle_hook("PreToolUse", _payload(session_id="sid-atomic"))
        session_dir = tmp_path / "sessions" / "sid-atomic"
        leftover = list(session_dir.glob("state.pkl.tmp.*"))
        assert leftover == []

    def test_concurrent_hooks_do_not_corrupt_state(self, tmp_path):
        # Spawn N threads each firing K hooks. The shared state.pkl
        # must be parseable at the end and the timeline must have
        # exactly N*K lines.
        n_threads = 4
        per_thread = 10
        sid = "sid-concurrent"
        errors: list[Exception] = []

        def worker(idx: int):
            try:
                for j in range(per_thread):
                    handle_hook("PreToolUse", _payload(
                        session_id=sid,
                        tool_input={"file_path": f"/x/{idx}-{j}.py"},
                    ))
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(n_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == []
        # state.pkl must be parseable.
        state_path = tmp_path / "sessions" / sid / "state.pkl"
        with open(state_path, "rb") as f:
            blob = pickle.load(f)
        assert isinstance(blob, dict)
        # timeline.jsonl must have N*K lines.
        timeline = tmp_path / "sessions" / sid / "timeline.jsonl"
        lines = _read_lines(timeline)
        assert len(lines) == n_threads * per_thread


# =====================================================================
# 5. Exit codes (host-safety contract)
# =====================================================================

class TestExitCodes:

    def test_pretooluse_no_prevent_returns_0(self):
        rc = handle_hook("PreToolUse", _payload())
        assert rc == 0

    def test_posttooluse_always_returns_0(self):
        rc = handle_hook("PostToolUse", _payload(tool_response={"ok": True}))
        assert rc == 0

    def test_stop_returns_0(self):
        handle_hook("PreToolUse", _payload(session_id="sid-stop"))
        rc = handle_hook("Stop", _payload(session_id="sid-stop"))
        assert rc == 0

    def test_subagentstop_returns_0(self):
        rc = handle_hook(
            "SubagentStop",
            _payload(
                session_id="sub-end",
                parent_session_id="root-end",
            ),
        )
        assert rc == 0

    def test_internal_exception_returns_0_never_blocks(self, monkeypatch):
        """If an internal helper raises unexpectedly, the hook still
        returns 0. The host-safety contract is non-negotiable."""
        # Patch a load-bearing internal to raise.
        def boom(*args, **kwargs):
            raise RuntimeError("synthetic crash")
        monkeypatch.setattr(cc, "_load_or_build_engine", boom)
        rc = handle_hook("PreToolUse", _payload())
        assert rc == 0

    def test_pretooluse_with_prevent_trip_returns_2(self, tmp_path, monkeypatch):
        """When the user opts into Prevent Mode AND a tracked failure
        crosses the trip threshold, PreToolUse exits with code 2.
        Claude Code blocks the tool call."""
        # Override the default engine config to enable Prevent Mode
        # with a low rotation threshold so a 3-edge cycle trips
        # almost immediately.
        prevent_config = dict(cc._DEFAULT_ENGINE_CONFIG)
        prevent_config.update({
            "warning_threshold": 2,
            "critical_threshold": 4,
            "per_edge_limit": 999,
            "global_limit": 9999,
            "prevent": {"cyclic_delegation": {"max_rotations": 3}},
        })
        monkeypatch.setattr(cc, "_DEFAULT_ENGINE_CONFIG", prevent_config)

        sid = "sid-prevent"
        # Build a 3-agent cycle (main -> subA -> subB -> main repeated).
        # But Claude Code's edges are tool calls, not agents. To form
        # a true cycle in the engine we need distinct sources and
        # targets that close back. Simulate by firing the SAME
        # source_agent (subagent_<id>) hitting different tool
        # fingerprints repeatedly through the same root.
        #
        # The simplest reliable trip: use a real cycle by alternating
        # subagent_ids that all share a root. main -> sub_A,
        # sub_A -> Read:fp1, etc. is not a cycle. Instead, build
        # cross-subagent loop where the engine sees a cycle.
        #
        # For testability, do an end-to-end trip via the existing
        # Layer 2 repetition detector: same edge fires many times,
        # which trips the Prevent Mode on the cycle pattern after the
        # warning + critical thresholds are crossed. The cyclic
        # prevent specifically tracks cycles, so we need to actually
        # form one. Use the lower-level API: build interaction events
        # that form a 3-rotation cycle directly through the engine.
        from agentsonar._core.models import InteractionEvent
        engine = cc._load_or_build_engine(
            tmp_path / "sessions" / sid / "state.pkl",
            dict(prevent_config),
        )
        ts = 1.0
        # 3-rotation cycle: main->A->B->main, repeat 5x.
        for _ in range(5):
            for src, tgt in (("main", "A"), ("A", "B"), ("B", "main")):
                engine.ingest(InteractionEvent(src, tgt, ts, None))
                ts += 1.0
        # Persist this primed engine state so the hook loads it.
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        cc._save_engine_state(session_dir / "state.pkl", engine)
        # Now fire a PreToolUse; Prevent Mode should trip and return 2.
        rc = handle_hook("PreToolUse", _payload(session_id=sid))
        assert rc == 2

    def test_prevent_trip_recorded_in_timeline(self, tmp_path, monkeypatch):
        """When a Prevent trip happens, the timeline record carries
        `prevented: true` for that event."""
        prevent_config = dict(cc._DEFAULT_ENGINE_CONFIG)
        prevent_config.update({
            "warning_threshold": 2,
            "critical_threshold": 4,
            "per_edge_limit": 999,
            "global_limit": 9999,
            "prevent": {"cyclic_delegation": {"max_rotations": 3}},
        })
        monkeypatch.setattr(cc, "_DEFAULT_ENGINE_CONFIG", prevent_config)

        from agentsonar._core.models import InteractionEvent
        sid = "sid-prev-timeline"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        engine = cc._load_or_build_engine(
            session_dir / "state.pkl",
            dict(prevent_config),
        )
        ts = 1.0
        for _ in range(5):
            for src, tgt in (("main", "A"), ("A", "B"), ("B", "main")):
                engine.ingest(InteractionEvent(src, tgt, ts, None))
                ts += 1.0
        cc._save_engine_state(session_dir / "state.pkl", engine)
        handle_hook("PreToolUse", _payload(session_id=sid))

        lines = _read_lines(session_dir / "timeline.jsonl")
        assert lines, "timeline should have at least one record"
        # The most recent record (the one we just fired) should be marked.
        assert lines[-1]["prevented"] is True


# =====================================================================
# 6. Cumulative report regeneration
# =====================================================================

class TestCumulativeReportRegeneration:

    def test_stop_on_root_writes_report_html_json_alerts(self, tmp_path):
        sid = "sid-report"
        handle_hook("PreToolUse", _payload(session_id=sid))
        handle_hook("Stop", _payload(session_id=sid))
        reports_dir = tmp_path / "reports" / sid
        assert (reports_dir / "report.html").exists()
        assert (reports_dir / "report.json").exists()
        assert (reports_dir / "alerts.log").exists()

    def test_stop_on_subagent_does_not_regenerate_report(self, tmp_path):
        """SubagentStop and a Stop on a subagent session should NOT
        write a report. The report belongs to the root session."""
        sid_root = "sid-rootonly"
        sid_sub = "sid-subonly"
        handle_hook("PreToolUse", _payload(session_id=sid_root))
        handle_hook("Stop", _payload(
            session_id=sid_sub,
            parent_session_id=sid_root,
        ))
        # Reports for sid_sub should NOT exist as its own tree.
        assert not (tmp_path / "reports" / sid_sub).exists()

    def test_stop_updates_latest_pointer(self, tmp_path):
        sid = "sid-latest"
        handle_hook("PreToolUse", _payload(session_id=sid))
        handle_hook("Stop", _payload(session_id=sid))
        latest = tmp_path / "reports" / "latest"
        assert latest.exists()
        assert latest.read_text(encoding="utf-8").strip() == sid

    def test_stop_does_not_call_engine_shutdown(self, tmp_path):
        """Engine state must survive across turns. Stop regenerates
        the report but does NOT trigger a full shutdown."""
        sid = "sid-no-shutdown"
        for _ in range(3):
            handle_hook("PreToolUse", _payload(session_id=sid))
            handle_hook("PostToolUse", _payload(
                session_id=sid,
                tool_response={"ok": True},
            ))
        handle_hook("Stop", _payload(session_id=sid))
        # Engine state.pkl is intact and reusable after Stop.
        state_path = tmp_path / "sessions" / sid / "state.pkl"
        assert state_path.exists()
        # Another turn after Stop appends to the same timeline.
        handle_hook("PreToolUse", _payload(session_id=sid))
        timeline = tmp_path / "sessions" / sid / "timeline.jsonl"
        lines = _read_lines(timeline)
        # 3 Pre + 3 Post + 1 Stop + 1 new Pre = 8
        assert len(lines) == 8

    def test_report_html_is_non_empty(self, tmp_path):
        sid = "sid-htmlsize"
        handle_hook("PreToolUse", _payload(session_id=sid))
        handle_hook("Stop", _payload(session_id=sid))
        report = tmp_path / "reports" / sid / "report.html"
        contents = report.read_text(encoding="utf-8")
        assert len(contents) > 1000
        assert "<html" in contents

    def test_alerts_log_uses_clean_enum_names(self, tmp_path):
        """Regression for 0.5.1: alerts.log must NOT show
        'ALERTSEVERITY.CRITICAL' or 'FailureClass.RESOURCE_EXHAUSTION'.
        These are Python enum reprs leaking through; we use the enum's
        .value or .name instead."""
        sid = "sid-enum-labels"
        for i in range(20):
            handle_hook("PreToolUse", _payload(
                session_id=sid,
                tool_name="Read",
                tool_input={"file_path": "/src/same.py"},
            ))
        handle_hook("Stop", _payload(session_id=sid))
        alerts_log = tmp_path / "reports" / sid / "alerts.log"
        contents = alerts_log.read_text(encoding="utf-8")
        assert "ALERTSEVERITY." not in contents, (
            f"alerts.log shows raw enum repr; saw lines: {contents[:500]}"
        )
        assert "FailureClass." not in contents, (
            f"alerts.log shows raw enum class prefix; saw lines: {contents[:500]}"
        )

    def test_stop_summary_count_matches_real_alert_count(self, tmp_path, capsys):
        """Regression for 0.5.1: the stderr Stop summary said
        '0 coordination patterns detected' even when there were 2 alerts,
        because _safe_str(enum).upper() returned 'ALERTSEVERITY.WARNING'
        and never matched the 'WARNING'/'CRITICAL' check. Use
        _enum_display so the membership check works."""
        sid = "sid-stop-summary-count"
        for _ in range(20):
            handle_hook("PreToolUse", _payload(
                session_id=sid,
                tool_name="Read",
                tool_input={"file_path": "/src/hammered.py"},
            ))
        handle_hook("Stop", _payload(session_id=sid))
        captured = capsys.readouterr()
        # Stop summary should mention "1 coordination pattern" or
        # "2 coordination patterns", never "0".
        assert "0 coordination patterns" not in captured.err, (
            f"Stop summary undercounted alerts; stderr was: {captured.err!r}"
        )
        assert "AgentSonar: detected" in captured.err, (
            f"Stop summary missing or malformed; stderr was: {captured.err!r}"
        )

    def test_report_html_includes_session_log_panel(self, tmp_path):
        """Regression for 0.5.1: the Chronological Log panel must
        actually render. Earlier versions called a nonexistent
        engine._session_log_snapshot() method and silently skipped the
        panel."""
        sid = "sid-session-log-render"
        for i in range(5):
            handle_hook("PreToolUse", _payload(
                session_id=sid,
                tool_name="Read",
                tool_input={"file_path": f"/src/{i}.py"},
            ))
        handle_hook("Stop", _payload(session_id=sid))
        report = tmp_path / "reports" / sid / "report.html"
        contents = report.read_text(encoding="utf-8").lower()
        has_chronological = any(
            tok in contents
            for tok in ("chronological", "session log", "session_log", "session-log")
        )
        assert has_chronological, (
            "Chronological Log / Session Log panel missing from report.html"
        )


# =====================================================================
# 7. Session boundary detection
# =====================================================================

class TestSessionBoundaryDetection:

    def test_inactivity_sweep_archives_stale_session(self, tmp_path, monkeypatch):
        """A session_id whose last_hook_at is older than the threshold
        gets archived when a different session fires its next hook."""
        monkeypatch.setenv("AGENTSONAR_INACTIVITY_SECONDS", "1")
        sid_old = "sid-stale"
        sid_new = "sid-fresh"
        # Create the old session.
        handle_hook("PreToolUse", _payload(session_id=sid_old))
        # Make it stale (last_hook_at deep in the past).
        last_hook_at = tmp_path / "sessions" / sid_old / "last_hook_at"
        last_hook_at.write_text("100.0", encoding="utf-8")
        # Fire a hook on a different session; should sweep the stale one.
        handle_hook("PreToolUse", _payload(session_id=sid_new))
        # Old session moved under archived/.
        assert (tmp_path / "sessions" / "archived" / sid_old).exists()
        assert not (tmp_path / "sessions" / sid_old).exists()

    def test_inactivity_sweep_does_not_archive_current_session(self, tmp_path, monkeypatch):
        monkeypatch.setenv("AGENTSONAR_INACTIVITY_SECONDS", "1")
        sid = "sid-current"
        handle_hook("PreToolUse", _payload(session_id=sid))
        # Forge an ancient last_hook_at to test the protection logic.
        (tmp_path / "sessions" / sid / "last_hook_at").write_text(
            "100.0", encoding="utf-8"
        )
        # Fire the next hook on the SAME session; sweep should NOT touch it.
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_response={"ok": True},
        ))
        assert (tmp_path / "sessions" / sid).exists()
        assert not (tmp_path / "sessions" / "archived" / sid).exists()


# =====================================================================
# 8. Subagent type registry
# =====================================================================

class TestSubagentTypeRegistry:

    def test_task_posttooluse_registers_subagent_type(self, tmp_path):
        """When subagent-spawn PostToolUse fires with a tool_response
        containing a session_id, register the spawned subagent's
        session_id -> type_name mapping (cleartext per 0.6.1+)."""
        sid_root = "sid-task-root"
        payload = _payload(
            session_id=sid_root,
            tool_name="Task",
            tool_input={"subagent_type": "code-reviewer"},
            tool_response={"session_id": "spawned-sub-1234"},
        )
        handle_hook("PostToolUse", payload)
        types_path = tmp_path / "sessions" / sid_root / "subagent_types.json"
        assert types_path.exists()
        data = json.loads(types_path.read_text(encoding="utf-8"))
        assert data["spawned-sub-1234"] == "code-reviewer"

    def test_agent_posttooluse_also_registers(self, tmp_path):
        """The Agent tool (Anthropic renamed Task -> Agent) registers
        the same way Task does. Both names are accepted."""
        sid_root = "sid-agent-root"
        payload = _payload(
            session_id=sid_root,
            tool_name="Agent",
            tool_input={"subagent_type": "researcher"},
            tool_response={"session_id": "spawned-agent-9999"},
        )
        handle_hook("PostToolUse", payload)
        types_path = tmp_path / "sessions" / sid_root / "subagent_types.json"
        assert types_path.exists()
        data = json.loads(types_path.read_text(encoding="utf-8"))
        assert data["spawned-agent-9999"] == "researcher"

    def test_non_task_posttooluse_does_not_register(self, tmp_path):
        sid = "sid-noregister"
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Read",
            tool_response={"file_path": "/x.py"},
        ))
        types_path = tmp_path / "sessions" / sid / "subagent_types.json"
        assert not types_path.exists()

    def test_task_response_without_session_id_skipped_silently(self, tmp_path):
        sid = "sid-nositd"
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Task",
            tool_input={"subagent_type": "code-reviewer"},
            tool_response={"result": "no session_id here"},
        ))
        types_path = tmp_path / "sessions" / sid / "subagent_types.json"
        assert not types_path.exists()


# =====================================================================
# 9. timeline.jsonl protocol commitments
# =====================================================================

class TestTimelineProtocol:

    def test_schema_version_locked_at_1_0_0(self):
        """If you change TIMELINE_SCHEMA_VERSION without thinking
        carefully, this test reminds you of the protocol commitment."""
        assert TIMELINE_SCHEMA_VERSION == "1.0.0"

    def test_every_line_carries_schema_version(self, tmp_path):
        sid = "sid-schema"
        for event in ("PreToolUse", "PostToolUse"):
            handle_hook(event, _payload(
                session_id=sid,
                tool_response={"ok": True} if event == "PostToolUse" else None,
            ))
        lines = _read_lines(tmp_path / "sessions" / sid / "timeline.jsonl")
        assert len(lines) == 2
        for line in lines:
            assert line["schema_version"] == "1.0.0"

    def test_required_fields_on_every_line(self, tmp_path):
        sid = "sid-fields"
        handle_hook("PreToolUse", _payload(session_id=sid))
        line = _read_lines(tmp_path / "sessions" / sid / "timeline.jsonl")[0]
        for required in (
            "schema_version", "event_id", "event_name",
            "root_session_id", "source_session_id",
            "source_agent", "target_agent", "timestamp",
            "metadata", "alerts", "prevented",
        ):
            assert required in line, f"timeline line missing {required}"

    def test_timeline_only_grows_never_truncates(self, tmp_path):
        """The append-only contract: a Stop hook does NOT truncate
        or rewrite timeline.jsonl."""
        sid = "sid-grow"
        handle_hook("PreToolUse", _payload(session_id=sid))
        handle_hook("Stop", _payload(session_id=sid))
        first_line_count = len(_read_lines(
            tmp_path / "sessions" / sid / "timeline.jsonl"
        ))
        handle_hook("PreToolUse", _payload(session_id=sid))
        second_line_count = len(_read_lines(
            tmp_path / "sessions" / sid / "timeline.jsonl"
        ))
        assert second_line_count > first_line_count


# =====================================================================
# 10. AGENTSONAR_REGULATED path redaction
# =====================================================================

class TestRegulatedMode:

    def test_clear_path_in_metadata_by_default(self):
        meta = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/secret.py"}),
            hook_arrival_ts=1.0,
        )
        assert meta["target_path"] == "/src/secret.py"

    def test_regulated_redacts_path(self, monkeypatch):
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        meta = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/secret.py"}),
            hook_arrival_ts=1.0,
        )
        assert meta["target_path"] is not None
        assert meta["target_path"].startswith("path:")
        assert "secret.py" not in meta["target_path"]

    def test_regulated_same_path_same_hash(self, monkeypatch):
        """Detection still works on hashed paths because same path
        produces same hash (flap detection survives redaction)."""
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        m1 = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/x.py"}),
            hook_arrival_ts=1.0,
        )
        m2 = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/x.py"}),
            hook_arrival_ts=2.0,
        )
        assert m1["target_path"] == m2["target_path"]

    def test_regulated_different_paths_different_hashes(self, monkeypatch):
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        m1 = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/x.py"}),
            hook_arrival_ts=1.0,
        )
        m2 = extract_metadata(
            _payload(tool_name="Read", tool_input={"file_path": "/src/y.py"}),
            hook_arrival_ts=1.0,
        )
        assert m1["target_path"] != m2["target_path"]

    def test_regulated_path_absent_from_disk(self, tmp_path, monkeypatch):
        """End-to-end: with AGENTSONAR_REGULATED=1, the cleartext
        path must not appear in any file the adapter writes."""
        monkeypatch.setenv("AGENTSONAR_REGULATED", "1")
        sid = "sid-redacted"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Read",
            tool_input={"file_path": "/regulated/super-secret-path.py"},
        ))
        handle_hook("Stop", _payload(session_id=sid))
        for file in _all_files_on_disk(tmp_path):
            try:
                contents = file.read_bytes()
            except Exception:
                continue
            assert b"super-secret-path.py" not in contents, (
                f"redacted path leaked into {file}"
            )


# =====================================================================
# 11. THE CONTENT-BLIND SENTINEL AUDIT (the load-bearing privacy test)
# =====================================================================

# The single most important test in this file. The adapter's
# content-blind contract claims that tool input bodies, tool output
# bodies, user prompts, and file contents NEVER land on disk.
#
# This audit puts unique sentinel strings into each forbidden field,
# runs a full PreToolUse + PostToolUse + Stop sequence, and greps
# every file the adapter wrote for the sentinel. Each test fails the
# moment a sentinel appears anywhere on disk.
#
# The audit sweep covers every artifact the plan commits to:
#   - state.pkl
#   - timeline.jsonl
#   - report.html
#   - report.json
#   - alerts.log
#   - subagent_types.json
#   - last_hook_at
#   - any other file the adapter creates in the session tree

class TestContentBlindSentinelAudit:

    _SENTINEL_BASH = "SENTINEL-BASH-COMMAND-AGENTSONAR-CONTENT-LEAK-CANARY-A"
    _SENTINEL_EDIT_OLD = "SENTINEL-EDIT-OLD-AGENTSONAR-CONTENT-LEAK-CANARY-B"
    _SENTINEL_EDIT_NEW = "SENTINEL-EDIT-NEW-AGENTSONAR-CONTENT-LEAK-CANARY-C"
    _SENTINEL_GREP_PATTERN = "SENTINEL-GREP-PATTERN-AGENTSONAR-CONTENT-LEAK-CANARY-D"
    _SENTINEL_WRITE_CONTENT = "SENTINEL-WRITE-CONTENT-AGENTSONAR-CONTENT-LEAK-CANARY-E"
    _SENTINEL_RESPONSE = "SENTINEL-TOOL-RESPONSE-AGENTSONAR-CONTENT-LEAK-CANARY-F"
    _SENTINEL_USERPROMPT = "SENTINEL-USERPROMPT-AGENTSONAR-CONTENT-LEAK-CANARY-G"

    _ALL_SENTINELS = (
        _SENTINEL_BASH,
        _SENTINEL_EDIT_OLD,
        _SENTINEL_EDIT_NEW,
        _SENTINEL_GREP_PATTERN,
        _SENTINEL_WRITE_CONTENT,
        _SENTINEL_RESPONSE,
        _SENTINEL_USERPROMPT,
    )

    def _assert_no_sentinels(self, root: Path):
        """Grep every file under `root` for any sentinel string."""
        leaks: list[str] = []
        for file in _all_files_on_disk(root):
            try:
                contents = file.read_bytes()
            except Exception:
                continue
            for sentinel in self._ALL_SENTINELS:
                if sentinel.encode("utf-8") in contents:
                    leaks.append(f"{sentinel} in {file}")
        assert not leaks, "content leaks: " + "; ".join(leaks)

    def test_bash_command_string_never_persisted(self, tmp_path):
        sid = "sid-leak-bash"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Bash",
            tool_input={"command": self._SENTINEL_BASH},
        ))
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Bash",
            tool_input={"command": self._SENTINEL_BASH},
            tool_response={"stdout": self._SENTINEL_RESPONSE},
        ))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_edit_old_and_new_strings_never_persisted(self, tmp_path):
        sid = "sid-leak-edit"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Edit",
            tool_input={
                "file_path": "/src/x.py",
                "old_string": self._SENTINEL_EDIT_OLD,
                "new_string": self._SENTINEL_EDIT_NEW,
            },
        ))
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Edit",
            tool_input={
                "file_path": "/src/x.py",
                "old_string": self._SENTINEL_EDIT_OLD,
                "new_string": self._SENTINEL_EDIT_NEW,
            },
            tool_response={"result": self._SENTINEL_RESPONSE},
        ))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_grep_pattern_never_persisted(self, tmp_path):
        sid = "sid-leak-grep"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Grep",
            tool_input={
                "pattern": self._SENTINEL_GREP_PATTERN,
                "path": "/src",
            },
        ))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_write_content_never_persisted(self, tmp_path):
        sid = "sid-leak-write"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Write",
            tool_input={
                "file_path": "/src/x.py",
                "content": self._SENTINEL_WRITE_CONTENT,
            },
        ))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_read_response_body_never_persisted(self, tmp_path):
        """The most-likely leak vector. Read's tool_response IS the
        file contents."""
        sid = "sid-leak-read"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Read",
            tool_input={"file_path": "/src/x.py"},
        ))
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Read",
            tool_input={"file_path": "/src/x.py"},
            tool_response={
                "content": (
                    f"file body line 1\n"
                    f"second line with {self._SENTINEL_RESPONSE}\n"
                    f"third line"
                ),
            },
        ))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_user_prompt_text_never_persisted(self, tmp_path):
        sid = "sid-leak-userprompt"
        handle_hook("UserPromptSubmit", _payload(
            session_id=sid,
            tool_name="user-prompt",
            tool_input={"prompt": self._SENTINEL_USERPROMPT},
        ))
        handle_hook("PreToolUse", _payload(session_id=sid))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_kitchen_sink_all_sentinels_at_once(self, tmp_path):
        """Run every sentinel in a single end-to-end sequence."""
        sid = "sid-leak-kitchen-sink"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Bash",
            tool_input={"command": self._SENTINEL_BASH},
        ))
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Bash",
            tool_input={"command": self._SENTINEL_BASH},
            tool_response={
                "stdout": self._SENTINEL_RESPONSE,
                "extra": self._SENTINEL_WRITE_CONTENT,
            },
        ))
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Edit",
            tool_input={
                "file_path": "/src/x.py",
                "old_string": self._SENTINEL_EDIT_OLD,
                "new_string": self._SENTINEL_EDIT_NEW,
            },
        ))
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Grep",
            tool_input={"pattern": self._SENTINEL_GREP_PATTERN},
        ))
        handle_hook("UserPromptSubmit", _payload(
            session_id=sid,
            tool_input={"prompt": self._SENTINEL_USERPROMPT},
        ))
        handle_hook("Stop", _payload(session_id=sid))
        self._assert_no_sentinels(tmp_path)

    def test_audit_explicitly_inspects_each_artifact_by_name(self, tmp_path):
        """Belt-and-suspenders: prove the audit DOES open the canonical
        files by name (not just every file via rglob).

        Documents that the audit covers all five artifacts the plan
        commits to: state.pkl, timeline.jsonl, report.html, report.json,
        alerts.log.
        """
        sid = "sid-explicit-audit"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Bash",
            tool_input={"command": self._SENTINEL_BASH},
        ))
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Bash",
            tool_input={"command": self._SENTINEL_BASH},
            tool_response={"stdout": self._SENTINEL_RESPONSE},
        ))
        handle_hook("Stop", _payload(session_id=sid))

        # The five files must exist (so the test is genuinely auditing
        # them, not silently passing on missing files).
        artifacts = {
            tmp_path / "sessions" / sid / "state.pkl",
            tmp_path / "sessions" / sid / "timeline.jsonl",
            tmp_path / "reports" / sid / "report.html",
            tmp_path / "reports" / sid / "report.json",
            tmp_path / "reports" / sid / "alerts.log",
        }
        for art in artifacts:
            assert art.exists(), f"missing canonical artifact {art}"

        # Each one must be sentinel-free.
        for art in artifacts:
            contents = art.read_bytes()
            for sentinel in self._ALL_SENTINELS:
                assert sentinel.encode("utf-8") not in contents, (
                    f"{sentinel} leaked into {art}"
                )


# =====================================================================
# 12. Latency benchmark
# =====================================================================

class TestLatency:

    @pytest.mark.performance
    def test_p99_under_75ms_on_200_event_session(self, tmp_path):
        """200-event synthetic load, p99 budget <75ms per hook.

        The plan's 10ms aspirational target assumed Unix filesystem
        performance (sub-millisecond open() calls). On Windows NTFS
        each open() is ~4ms, and we do ~5 opens per hook (lock,
        state.pkl read, timeline append, state.pkl atomic rewrite,
        last_hook_at write), so ~25ms is the structural floor without
        deeper architectural changes (batched async I/O, custom
        lock-file reuse, etc., which are out of scope for Phase 1).

        75ms is the cross-platform realistic budget with headroom for
        filesystem-cache jitter on Windows. On Linux this test passes
        with significant margin (typically <15ms p99). Either way the
        hook latency is invisible next to the Python interpreter
        cold-start cost (~50-100ms per hook subprocess on Windows).

        Performance-marked: only runs with `pytest -m performance`.
        The default test invocation excludes this so noisy CI runners
        do not flake.
        """
        sid = "sid-perf"
        latencies: list[float] = []
        for i in range(200):
            payload = _payload(
                session_id=sid,
                tool_input={"file_path": f"/src/{i}.py"},
            )
            start = time.perf_counter()
            handle_hook("PreToolUse", payload)
            latencies.append(time.perf_counter() - start)

        latencies.sort()
        p99 = latencies[int(0.99 * len(latencies))]
        assert p99 < 0.075, f"p99 latency {p99 * 1000:.2f}ms exceeds 75ms budget"


# =====================================================================
# 13. Concurrent hooks (integration)
# =====================================================================

class TestConcurrentHooks:

    def test_5_parallel_subagent_hooks_share_state(self, tmp_path):
        """5 parallel subagents each fire 10 hooks against the same
        root session tree. The file lock and atomic rename guarantee
        no corruption. End-to-end aggregate event count must equal
        the sum of inputs."""
        sid_root = "sid-paralleltree"
        subagent_ids = [f"sub-{i:04d}-aaaa-bbbb" for i in range(5)]
        per_subagent = 10
        errors: list[Exception] = []

        def fire_subagent(sub_sid: str):
            try:
                for j in range(per_subagent):
                    handle_hook("PreToolUse", _payload(
                        session_id=sub_sid,
                        parent_session_id=sid_root,
                        tool_input={"file_path": f"/src/{sub_sid}-{j}.py"},
                    ))
            except Exception as exc:
                errors.append(exc)

        threads = [
            threading.Thread(target=fire_subagent, args=(s,))
            for s in subagent_ids
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert errors == []
        timeline = tmp_path / "sessions" / sid_root / "timeline.jsonl"
        lines = _read_lines(timeline)
        assert len(lines) == 5 * per_subagent
        # All lines should share the same root_session_id.
        for line in lines:
            assert line["root_session_id"] == sid_root


# =====================================================================
# 14. session_exit sentinel skip (0.5.3 fix)
# =====================================================================
#
# Every Stop / SubagentStop synthesizes a target_agent of "session_exit"
# so reports can show the session boundary. Before 0.5.3 this edge was
# fed to the engine, causing spurious repetitive_delegation alerts on
# long sessions where many Stops fire. The fix: skip engine.ingest for
# session_exit edges; keep writing them to timeline.jsonl.


class TestSessionExitSkippedFromDetector:

    def test_session_exit_does_not_appear_in_engine_recent_events(self, tmp_path):
        """Fire 20 Stops on the same session. The detector should never
        see a session_exit edge (so no repetitive_delegation alert can
        accumulate against it)."""
        sid = "skip-detection"
        for _ in range(20):
            rc = handle_hook("Stop", {
                "session_id": sid,
                "parent_session_id": None,
                "tool_name": "Stop",
            })
            assert rc == 0

        # Reload the engine from the saved state and inspect what edges
        # it actually recorded.
        state_path = tmp_path / "sessions" / sid / "state.pkl"
        engine = cc._load_or_build_engine(state_path, cc._build_engine_config())
        graph = getattr(engine, "coord_graph", None)
        if graph is None:
            return  # no graph means no edges; trivially passes
        # No edge whose target is "session_exit" should exist in the graph
        edges = list(graph.edges_data()) if hasattr(graph, "edges_data") else []
        for edge in edges:
            src = getattr(edge, "source", None) or (edge[0] if isinstance(edge, tuple) else None)
            tgt = getattr(edge, "target", None) or (edge[1] if isinstance(edge, tuple) else None)
            assert tgt != "session_exit", (
                f"session_exit edge leaked into engine: {src} -> {tgt}"
            )

    def test_session_exit_still_appears_in_timeline(self, tmp_path):
        """The Stop event should still be persisted to timeline.jsonl
        with target_agent='session_exit'. Only the engine.ingest is
        skipped; the canonical event record is unchanged."""
        sid = "still-in-timeline"
        rc = handle_hook("Stop", {
            "session_id": sid,
            "parent_session_id": None,
            "tool_name": "Stop",
        })
        assert rc == 0
        timeline = tmp_path / "sessions" / sid / "timeline.jsonl"
        lines = _read_lines(timeline)
        assert len(lines) == 1
        assert lines[0]["target_agent"] == "session_exit"
        assert lines[0]["event_name"] == "Stop"

    def test_session_exit_skip_does_not_break_root_report_regen(self, tmp_path):
        """Root-session Stop still regenerates report.html / report.json
        / alerts.log, even though the Stop itself is skipped from the
        engine."""
        sid = "root-report-still-regens"
        # Prime with a few Read tool calls so the report has content
        for i in range(3):
            handle_hook("PreToolUse", {
                "session_id": sid,
                "parent_session_id": None,
                "tool_name": "Read",
                "tool_input": {"file_path": f"/src/{i}.py"},
            })
        # Now the root Stop
        rc = handle_hook("Stop", {
            "session_id": sid,
            "parent_session_id": None,
            "tool_name": "Stop",
        })
        assert rc == 0
        reports_dir = tmp_path / "reports" / sid
        assert (reports_dir / "report.json").exists()
        assert (reports_dir / "report.html").exists()
        assert (reports_dir / "alerts.log").exists()

    def test_session_exit_skip_does_not_falsely_trip_repetitive(self, tmp_path):
        """The original bug: 20+ Stops on the same session used to make
        repetitive_delegation fire on main -> session_exit. With the
        fix, no alert should mention session_exit."""
        sid = "no-false-repetitive"
        for _ in range(25):
            handle_hook("Stop", {
                "session_id": sid,
                "parent_session_id": None,
                "tool_name": "Stop",
            })
        # Reload + inspect recent_events
        state_path = tmp_path / "sessions" / sid / "state.pkl"
        engine = cc._load_or_build_engine(state_path, cc._build_engine_config())
        try:
            events = list(engine.get_recent_events())
        except Exception:
            events = []
        for ev in events:
            topology = getattr(ev, "topology", None)
            if topology is None:
                continue
            agents = list(getattr(topology, "agents_involved", []) or [])
            assert "session_exit" not in agents, (
                f"alert leaked session_exit in agents_involved: {agents}"
            )


# =====================================================================
# 15. Env-var threshold configuration (0.5.3 feature)
# =====================================================================
#
# 7 new env vars for tuning detection thresholds at adapter level:
#   AGENTSONAR_WARNING_THRESHOLD, AGENTSONAR_CRITICAL_THRESHOLD
#   AGENTSONAR_CYCLE_WARNING_THRESHOLD, AGENTSONAR_CYCLE_CRITICAL_THRESHOLD
#   AGENTSONAR_EDGE_ANOMALY_WARNING_THRESHOLD, AGENTSONAR_EDGE_ANOMALY_CRITICAL_THRESHOLD
#   AGENTSONAR_PREVENT_CYCLE_MAX_ROTATIONS
#
# All defensive: garbage / negative / zero values fall back to the
# engine default (so a typo never crashes the host).


class TestEngineConfigFromEnv:

    def test_default_config_has_no_threshold_overrides(self, monkeypatch):
        """With no env vars set, _build_engine_config returns just the
        adapter defaults (console + file output off). The engine then
        uses its own internal defaults."""
        for env_name in (
            cc.ENV_WARNING_THRESHOLD,
            cc.ENV_CRITICAL_THRESHOLD,
            cc.ENV_CYCLE_WARNING_THRESHOLD,
            cc.ENV_CYCLE_CRITICAL_THRESHOLD,
            cc.ENV_EDGE_ANOMALY_WARNING_THRESHOLD,
            cc.ENV_EDGE_ANOMALY_CRITICAL_THRESHOLD,
            cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS,
        ):
            monkeypatch.delenv(env_name, raising=False)
        cfg = cc._build_engine_config()
        assert "warning_threshold" not in cfg
        assert "critical_threshold" not in cfg
        assert "cycle_warning_threshold" not in cfg
        assert "prevent" not in cfg

    def test_warning_threshold_env_var_lands_in_config(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "3")
        cfg = cc._build_engine_config()
        assert cfg.get("warning_threshold") == 3

    def test_critical_threshold_env_var_lands_in_config(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_CRITICAL_THRESHOLD, "10")
        cfg = cc._build_engine_config()
        assert cfg.get("critical_threshold") == 10

    def test_cycle_specific_thresholds_in_config(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_CYCLE_WARNING_THRESHOLD, "2")
        monkeypatch.setenv(cc.ENV_CYCLE_CRITICAL_THRESHOLD, "5")
        cfg = cc._build_engine_config()
        assert cfg.get("cycle_warning_threshold") == 2
        assert cfg.get("cycle_critical_threshold") == 5

    def test_edge_anomaly_specific_thresholds_in_config(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_EDGE_ANOMALY_WARNING_THRESHOLD, "4")
        monkeypatch.setenv(cc.ENV_EDGE_ANOMALY_CRITICAL_THRESHOLD, "8")
        cfg = cc._build_engine_config()
        assert cfg.get("edge_anomaly_warning_threshold") == 4
        assert cfg.get("edge_anomaly_critical_threshold") == 8

    def test_prevent_max_rotations_enables_prevent_block(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS, "3")
        cfg = cc._build_engine_config()
        assert cfg.get("prevent") == {"cyclic_delegation": {"max_rotations": 3}}

    def test_invalid_env_var_falls_back_to_default(self, monkeypatch):
        """Garbage values should NOT crash the adapter and should NOT
        end up in the config (host-safety: never break the user's
        process for a typo)."""
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "not-a-number")
        monkeypatch.setenv(cc.ENV_CYCLE_CRITICAL_THRESHOLD, "")
        monkeypatch.setenv(cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS, "garbage")
        cfg = cc._build_engine_config()
        assert "warning_threshold" not in cfg
        assert "cycle_critical_threshold" not in cfg
        assert "prevent" not in cfg

    def test_negative_value_falls_back_to_default(self, monkeypatch):
        """Negative thresholds aren't meaningful; treat as unset."""
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "-5")
        monkeypatch.setenv(cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS, "-1")
        cfg = cc._build_engine_config()
        assert "warning_threshold" not in cfg
        assert "prevent" not in cfg

    def test_zero_value_falls_back_to_default(self, monkeypatch):
        """Zero threshold would fire on every event, clearly not what
        a user means by setting the env var. Treat as unset."""
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "0")
        monkeypatch.setenv(cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS, "0")
        cfg = cc._build_engine_config()
        assert "warning_threshold" not in cfg
        assert "prevent" not in cfg

    def test_env_config_returns_fresh_dict(self, monkeypatch):
        """Mutating one call's result must not affect later calls."""
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "3")
        a = cc._build_engine_config()
        a["warning_threshold"] = 99
        a["console_output"] = "POISONED"
        b = cc._build_engine_config()
        assert b["warning_threshold"] == 3
        assert b["console_output"] is False

    def test_cycle_specific_overrides_generic(self, monkeypatch):
        """Both generic and cycle-specific set: cycle-specific wins
        for cycle detection (the engine looks up cycle_*_threshold
        first, falls back to generic only when unset)."""
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "10")
        monkeypatch.setenv(cc.ENV_CYCLE_WARNING_THRESHOLD, "3")
        cfg = cc._build_engine_config()
        assert cfg["warning_threshold"] == 10
        assert cfg["cycle_warning_threshold"] == 3


class TestEngineConfigEndToEnd:
    """End-to-end: env var settings actually reach the engine and
    change observable behavior."""

    def test_env_warning_threshold_lowers_cycle_alert_count(self, tmp_path, monkeypatch):
        """With warning_threshold=2, a 2-rotation cycle should produce
        an alert that wouldn't fire under the engine default of 5."""
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "2")
        sid = "low-threshold"
        # 2 rotations of a 3-node cycle: A->B->C->A->B->C->A
        for _ in range(2):
            handle_hook("PreToolUse", _payload(
                session_id=sid, tool_name="Read",
                tool_input={"file_path": "/A.py"},
            ))
            handle_hook("PreToolUse", _payload(
                session_id=sid, tool_name="Read",
                tool_input={"file_path": "/B.py"},
            ))
            handle_hook("PreToolUse", _payload(
                session_id=sid, tool_name="Read",
                tool_input={"file_path": "/C.py"},
            ))
        # Verify the engine actually saw the lowered threshold by
        # reading state.pkl back.
        state_path = tmp_path / "sessions" / sid / "state.pkl"
        engine = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert engine._warning_threshold == 2

    def test_env_prevent_actually_blocks_pretooluse(self, tmp_path, monkeypatch):
        """AGENTSONAR_PREVENT_CYCLE_MAX_ROTATIONS=3 must cause Prevent
        Mode to trip and return exit code 2 on a 3+-rotation cycle."""
        monkeypatch.setenv(cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS, "3")
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "2")
        monkeypatch.setenv(cc.ENV_CRITICAL_THRESHOLD, "3")

        sid = "prevent-via-env"
        from agentsonar._core.models import InteractionEvent

        # Prime state.pkl with a 4-rotation cycle so the next PreToolUse
        # trips Prevent.
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"
        engine = cc._load_or_build_engine(state_path, cc._build_engine_config())
        ts = 1.0
        for _ in range(5):
            for src, tgt in (("main", "A"), ("A", "B"), ("B", "main")):
                engine.ingest(InteractionEvent(src, tgt, ts, None))
                ts += 1.0
        cc._save_engine_state(state_path, engine)

        # Now fire a PreToolUse on the same cycle. Should return 2.
        rc = handle_hook("PreToolUse", {
            "session_id": sid,
            "parent_session_id": None,
            "tool_name": "Read",
            "tool_input": {"file_path": "/x.py"},
        })
        assert rc == 2, f"expected Prevent trip (rc=2), got rc={rc}"


# =====================================================================
# 16. Cross-session env-var refresh (bug-1 regression guard)
# =====================================================================
#
# `_load_or_build_engine` overlays state.pkl on top of the freshly-built
# engine. Before this fix, the overlay clobbered the fresh thresholds
# with the saved (old) ones, so users adding env vars between sessions
# saw no behavior change. The fix: skip threshold-related attrs from
# the overlay and force-refresh AlertStateManager's threshold fields
# from the fresh engine after the overlay.


class TestEnvThresholdAcrossStateReload:

    def test_env_warning_threshold_applies_after_state_pkl_exists(self, tmp_path, monkeypatch):
        """Day 1: no env var, save state.pkl. Day 2: set env var,
        reload engine. The reloaded engine MUST reflect the new
        threshold, not the stale value baked into state.pkl."""
        sid = "across-reload"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        # Day 1: no env var
        monkeypatch.delenv(cc.ENV_WARNING_THRESHOLD, raising=False)
        engine_d1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert engine_d1._warning_threshold == 5  # engine default
        cc._save_engine_state(state_path, engine_d1)

        # Day 2: set the env var
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "2")
        engine_d2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert engine_d2._warning_threshold == 2, (
            f"env-var change ignored on reload: got {engine_d2._warning_threshold}"
        )

    def test_env_cycle_threshold_applies_after_state_pkl_exists(self, tmp_path, monkeypatch):
        sid = "cycle-across-reload"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        monkeypatch.delenv(cc.ENV_CYCLE_WARNING_THRESHOLD, raising=False)
        e1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        cc._save_engine_state(state_path, e1)

        monkeypatch.setenv(cc.ENV_CYCLE_WARNING_THRESHOLD, "3")
        e2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert e2._cycle_warning_threshold == 3

    def test_env_prevent_can_be_added_mid_session(self, tmp_path, monkeypatch):
        """Day 1: Prevent off, build state.pkl. Day 2: turn Prevent on
        via env var. The reloaded engine MUST have Prevent enabled."""
        sid = "prevent-mid"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        monkeypatch.delenv(cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS, raising=False)
        e1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert "cyclic_delegation" not in e1._prevent_classes
        cc._save_engine_state(state_path, e1)

        monkeypatch.setenv(cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS, "3")
        e2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert "cyclic_delegation" in e2._prevent_classes
        assert e2._prevent_classes["cyclic_delegation"]["max_rotations"] == 3

    def test_env_prevent_can_be_disabled_mid_session(self, tmp_path, monkeypatch):
        """Symmetry test: removing the env var between hooks should
        turn Prevent off."""
        sid = "prevent-off"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        monkeypatch.setenv(cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS, "3")
        e1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert "cyclic_delegation" in e1._prevent_classes
        cc._save_engine_state(state_path, e1)

        monkeypatch.delenv(cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS, raising=False)
        e2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert "cyclic_delegation" not in e2._prevent_classes

    def test_alert_mgr_dedup_state_preserved_across_reload(self, tmp_path, monkeypatch):
        """Bug-1 fix regression guard: while we DON'T restore the
        AlertStateManager's threshold fields, we DO want its `_tracked`
        dedup state preserved so already-fired alerts don't re-fire
        on the next hook."""
        from agentsonar._core.models import InteractionEvent

        sid = "alert-dedup-preserved"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        # Prime with a cycle that fires a tracked alert
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "2")
        monkeypatch.setenv(cc.ENV_CRITICAL_THRESHOLD, "3")
        e1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        ts = 1.0
        for _ in range(5):
            for src, tgt in (("main", "A"), ("A", "B"), ("B", "main")):
                e1.ingest(InteractionEvent(src, tgt, ts, None))
                ts += 1.0
        tracked_before = dict(e1._alert_mgr._tracked)
        assert len(tracked_before) > 0, "Setup: expected at least one tracked alert"
        cc._save_engine_state(state_path, e1)

        # Reload (with same env vars) and confirm dedup state survives
        e2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        tracked_after = dict(e2._alert_mgr._tracked)
        assert set(tracked_after.keys()) == set(tracked_before.keys()), (
            "tracked alert state lost across reload"
        )

    def test_alert_mgr_threshold_refreshed_across_reload(self, tmp_path, monkeypatch):
        """The AlertStateManager carries its own threshold copy; the
        bug-1 fix forces a refresh on reload so a new env var actually
        changes alert firing."""
        sid = "alert-mgr-refresh"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        # Day 1: warning=5 (default)
        monkeypatch.delenv(cc.ENV_WARNING_THRESHOLD, raising=False)
        e1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert e1._alert_mgr.warning_threshold == 5
        cc._save_engine_state(state_path, e1)

        # Day 2: warning=2 via env
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "2")
        e2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert e2._alert_mgr.warning_threshold == 2, (
            f"AlertStateManager threshold not refreshed: {e2._alert_mgr.warning_threshold}"
        )

    def test_per_pattern_thresholds_refreshed_across_reload(self, tmp_path, monkeypatch):
        sid = "per-pattern-refresh"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        # Day 1: no per-pattern overrides
        monkeypatch.delenv(cc.ENV_CYCLE_WARNING_THRESHOLD, raising=False)
        e1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        cc._save_engine_state(state_path, e1)

        # Day 2: cycle-specific override added
        monkeypatch.setenv(cc.ENV_CYCLE_WARNING_THRESHOLD, "3")
        monkeypatch.setenv(cc.ENV_CYCLE_CRITICAL_THRESHOLD, "10")
        e2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert e2._cycle_warning_threshold == 3
        assert e2._cycle_critical_threshold == 10
        # AlertStateManager's per-pattern map should also reflect this
        pp = e2._alert_mgr._per_pattern_thresholds
        assert pp.get("cycle") == (3, 10), (
            f"AlertStateManager per-pattern map not refreshed: {pp}"
        )


# =====================================================================
# 17. Public surface contract (bug-2 regression guard)
# =====================================================================
#
# The 7 new ENV_* constants from 0.5.3 should be importable from the
# package __init__, listed in __all__, and discoverable for the same
# reasons the existing 5 are.


class TestPublicSurfaceExportsNewEnvVars:

    def test_new_env_vars_listed_in_adapter_all(self):
        new_vars = (
            "ENV_WARNING_THRESHOLD",
            "ENV_CRITICAL_THRESHOLD",
            "ENV_CYCLE_WARNING_THRESHOLD",
            "ENV_CYCLE_CRITICAL_THRESHOLD",
            "ENV_EDGE_ANOMALY_WARNING_THRESHOLD",
            "ENV_EDGE_ANOMALY_CRITICAL_THRESHOLD",
            "ENV_PREVENT_CYCLE_MAX_ROTATIONS",
        )
        for name in new_vars:
            assert name in cc.__all__, f"missing from adapter.__all__: {name}"

    def test_new_env_vars_importable_from_package_init(self):
        """`from agentsonar._integrations.claude import ENV_*` should
        resolve all 7 new constants alongside the existing 5."""
        from agentsonar._integrations import claude as pkg
        new_vars = (
            "ENV_WARNING_THRESHOLD",
            "ENV_CRITICAL_THRESHOLD",
            "ENV_CYCLE_WARNING_THRESHOLD",
            "ENV_CYCLE_CRITICAL_THRESHOLD",
            "ENV_EDGE_ANOMALY_WARNING_THRESHOLD",
            "ENV_EDGE_ANOMALY_CRITICAL_THRESHOLD",
            "ENV_PREVENT_CYCLE_MAX_ROTATIONS",
        )
        for name in new_vars:
            assert hasattr(pkg, name), f"missing from package surface: {name}"
            assert name in pkg.__all__, f"missing from package __all__: {name}"

    def test_env_var_string_values_match_documented_names(self):
        """Pin the actual string values so a typo in an env var name
        is caught by tests. Users grep their config for these literals."""
        assert cc.ENV_WARNING_THRESHOLD == "AGENTSONAR_WARNING_THRESHOLD"
        assert cc.ENV_CRITICAL_THRESHOLD == "AGENTSONAR_CRITICAL_THRESHOLD"
        assert cc.ENV_CYCLE_WARNING_THRESHOLD == "AGENTSONAR_CYCLE_WARNING_THRESHOLD"
        assert cc.ENV_CYCLE_CRITICAL_THRESHOLD == "AGENTSONAR_CYCLE_CRITICAL_THRESHOLD"
        assert cc.ENV_EDGE_ANOMALY_WARNING_THRESHOLD == "AGENTSONAR_EDGE_ANOMALY_WARNING_THRESHOLD"
        assert cc.ENV_EDGE_ANOMALY_CRITICAL_THRESHOLD == "AGENTSONAR_EDGE_ANOMALY_CRITICAL_THRESHOLD"
        assert cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS == "AGENTSONAR_PREVENT_CYCLE_MAX_ROTATIONS"


# =====================================================================
# 18. Universal Prevent Mode env vars (0.6.0)
# =====================================================================
#
# 4 env vars route into engine.config["prevent"]:
#   AGENTSONAR_PREVENT_CYCLE_MAX_ROTATIONS=N   (numeric)
#   AGENTSONAR_PREVENT_REPETITIVE_MAX_EVENTS=N (numeric)
#   AGENTSONAR_PREVENT_RATE_LIMIT=1            (boolean)
#   AGENTSONAR_PREVENT_ALL=1                   (master switch)


class TestEnvVarRepetitivePrevent:

    def test_repetitive_max_events_lands_in_config(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_PREVENT_REPETITIVE_MAX_EVENTS, "10")
        cfg = cc._build_engine_config()
        assert cfg["prevent"] == {
            "repetitive_delegation": {"max_events": 10},
        }

    def test_repetitive_garbage_falls_back_to_no_override(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_PREVENT_REPETITIVE_MAX_EVENTS, "garbage")
        cfg = cc._build_engine_config()
        assert "prevent" not in cfg

    def test_repetitive_negative_treated_as_unset(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_PREVENT_REPETITIVE_MAX_EVENTS, "-3")
        cfg = cc._build_engine_config()
        assert "prevent" not in cfg


class TestEnvVarRateLimitPrevent:

    def test_rate_limit_truthy_enables_resource_exhaustion(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_PREVENT_RATE_LIMIT, "1")
        cfg = cc._build_engine_config()
        assert cfg["prevent"] == {"resource_exhaustion": True}

    def test_rate_limit_various_truthy_values(self, monkeypatch):
        for val in ("1", "true", "True", "YES", "on", "enabled"):
            monkeypatch.setenv(cc.ENV_PREVENT_RATE_LIMIT, val)
            cfg = cc._build_engine_config()
            assert cfg.get("prevent", {}).get("resource_exhaustion") is True, (
                f"failed for value {val!r}"
            )

    def test_rate_limit_falsy_does_not_enable(self, monkeypatch):
        for val in ("0", "false", "no", "off", "disabled", "", "garbage"):
            monkeypatch.setenv(cc.ENV_PREVENT_RATE_LIMIT, val)
            cfg = cc._build_engine_config()
            assert "prevent" not in cfg, f"falsy value {val!r} unexpectedly enabled"


class TestEnvVarMasterSwitch:

    def test_master_switch_enables_all_three_in_default_mode(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_PREVENT_ALL, "1")
        for env in (
            cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS,
            cc.ENV_PREVENT_REPETITIVE_MAX_EVENTS,
            cc.ENV_PREVENT_RATE_LIMIT,
        ):
            monkeypatch.delenv(env, raising=False)
        cfg = cc._build_engine_config()
        prevent = cfg["prevent"]
        assert prevent["cyclic_delegation"] is True
        assert prevent["repetitive_delegation"] is True
        assert prevent["resource_exhaustion"] is True

    def test_per_class_numeric_env_overrides_master_switch(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_PREVENT_ALL, "1")
        monkeypatch.setenv(cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS, "3")
        monkeypatch.setenv(cc.ENV_PREVENT_REPETITIVE_MAX_EVENTS, "7")
        cfg = cc._build_engine_config()
        prevent = cfg["prevent"]
        # Numeric per-class wins over boolean master switch
        assert prevent["cyclic_delegation"] == {"max_rotations": 3}
        assert prevent["repetitive_delegation"] == {"max_events": 7}
        # rate_limit not numerically tunable; master switch still enables it
        assert prevent["resource_exhaustion"] is True

    def test_master_switch_garbage_disables_all(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_PREVENT_ALL, "not-truthy")
        for env in (
            cc.ENV_PREVENT_CYCLE_MAX_ROTATIONS,
            cc.ENV_PREVENT_REPETITIVE_MAX_EVENTS,
            cc.ENV_PREVENT_RATE_LIMIT,
        ):
            monkeypatch.delenv(env, raising=False)
        cfg = cc._build_engine_config()
        assert "prevent" not in cfg

    def test_master_switch_persists_across_state_reload(self, tmp_path, monkeypatch):
        """Bug-1 (0.5.3) regression guard: master switch must take
        effect on hook 2+ as well, not just the first hook."""
        sid = "master-switch-reload"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        # Day 1: master switch off
        monkeypatch.delenv(cc.ENV_PREVENT_ALL, raising=False)
        e1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert "cyclic_delegation" not in e1._prevent_classes
        cc._save_engine_state(state_path, e1)

        # Day 2: master switch on
        monkeypatch.setenv(cc.ENV_PREVENT_ALL, "1")
        e2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert "cyclic_delegation" in e2._prevent_classes
        assert "repetitive_delegation" in e2._prevent_classes
        assert "resource_exhaustion" in e2._prevent_classes


class TestPreventEnvVarsInPublicSurface:

    def test_new_prevent_env_vars_in_adapter_all(self):
        for name in (
            "ENV_PREVENT_REPETITIVE_MAX_EVENTS",
            "ENV_PREVENT_RATE_LIMIT",
            "ENV_PREVENT_ALL",
        ):
            assert name in cc.__all__, f"missing from adapter.__all__: {name}"

    def test_new_prevent_env_vars_in_package_init(self):
        from agentsonar._integrations import claude as pkg
        for name in (
            "ENV_PREVENT_REPETITIVE_MAX_EVENTS",
            "ENV_PREVENT_RATE_LIMIT",
            "ENV_PREVENT_ALL",
        ):
            assert hasattr(pkg, name)
            assert name in pkg.__all__

    def test_new_prevent_env_var_string_values(self):
        assert cc.ENV_PREVENT_REPETITIVE_MAX_EVENTS == "AGENTSONAR_PREVENT_REPETITIVE_MAX_EVENTS"
        assert cc.ENV_PREVENT_RATE_LIMIT == "AGENTSONAR_PREVENT_RATE_LIMIT"
        assert cc.ENV_PREVENT_ALL == "AGENTSONAR_PREVENT_ALL"


class TestPreventEndToEndViaHandleHook:
    """End-to-end: env var set → handle_hook actually trips Prevent
    and returns exit code 2."""

    def test_repetitive_env_var_trips_via_handle_hook(self, tmp_path, monkeypatch):
        monkeypatch.setenv(cc.ENV_PREVENT_REPETITIVE_MAX_EVENTS, "3")
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "2")
        monkeypatch.setenv(cc.ENV_CRITICAL_THRESHOLD, "10")
        sid = "rep-via-env"
        from agentsonar._core.models import InteractionEvent
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"
        engine = cc._load_or_build_engine(state_path, cc._build_engine_config())
        # Prime 25 same-edge events. Default hard_weight_limit=10.0
        # means the repetitive detector fires around event 11; with
        # event_count baked into the alert + max_events=3 auto-lowering
        # edge_anomaly_warning_threshold to 3, the next hook's
        # should_prevent() sees tracked.current_rotations >> 3 and trips.
        ts = 1.0
        for _ in range(25):
            engine.ingest(InteractionEvent("main", "Read:/x.py", ts, None))
            ts += 0.5
        cc._save_engine_state(state_path, engine)

        rc = handle_hook("PreToolUse", {
            "session_id": sid,
            "parent_session_id": None,
            "tool_name": "Read",
            "tool_input": {"file_path": "/x.py"},
        })
        assert rc == 2, f"expected Prevent trip (rc=2), got rc={rc}"

    def test_master_switch_trips_via_handle_hook(self, tmp_path, monkeypatch):
        monkeypatch.setenv(cc.ENV_PREVENT_ALL, "1")
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "2")
        monkeypatch.setenv(cc.ENV_CRITICAL_THRESHOLD, "3")
        sid = "all-via-env"
        from agentsonar._core.models import InteractionEvent
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"
        # Prime a cycle that reaches CRITICAL severity (3 rotations
        # of main->A->B->main)
        engine = cc._load_or_build_engine(state_path, cc._build_engine_config())
        ts = 1.0
        for _ in range(5):
            for src, tgt in (("main", "A"), ("A", "B"), ("B", "main")):
                engine.ingest(InteractionEvent(src, tgt, ts, None))
                ts += 1.0
        cc._save_engine_state(state_path, engine)

        rc = handle_hook("PreToolUse", {
            "session_id": sid,
            "parent_session_id": None,
            "tool_name": "Read",
            "tool_input": {"file_path": "/x.py"},
        })
        assert rc == 2


# =====================================================================
# 19. Detection sensitivity env vars (0.6.1)
# =====================================================================
#
# Three new knobs let users make detection fire on fewer events:
#   AGENTSONAR_HARD_WEIGHT_LIMIT   -> Layer 2 repetitive detector
#   AGENTSONAR_PER_EDGE_LIMIT      -> Layer 1 rate limiter (per-edge)
#   AGENTSONAR_GLOBAL_LIMIT        -> Layer 1 rate limiter (global)


class TestDetectionSensitivityEnvVars:

    def test_hard_weight_limit_lands_in_config(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_HARD_WEIGHT_LIMIT, "3.0")
        cfg = cc._build_engine_config()
        assert cfg.get("hard_weight_limit") == 3.0

    def test_per_edge_limit_lands_in_config(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_PER_EDGE_LIMIT, "5")
        cfg = cc._build_engine_config()
        assert cfg.get("per_edge_limit") == 5

    def test_global_limit_lands_in_config(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_GLOBAL_LIMIT, "50")
        cfg = cc._build_engine_config()
        assert cfg.get("global_limit") == 50

    def test_hard_weight_limit_garbage_falls_back(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_HARD_WEIGHT_LIMIT, "not-a-float")
        cfg = cc._build_engine_config()
        assert "hard_weight_limit" not in cfg

    def test_per_edge_limit_negative_falls_back(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_PER_EDGE_LIMIT, "-5")
        cfg = cc._build_engine_config()
        assert "per_edge_limit" not in cfg

    def test_hard_weight_limit_zero_falls_back(self, monkeypatch):
        """Zero hard_weight_limit would trip on every single event;
        treated as 'not set' so the host never sees nonsense behavior."""
        monkeypatch.setenv(cc.ENV_HARD_WEIGHT_LIMIT, "0.0")
        cfg = cc._build_engine_config()
        assert "hard_weight_limit" not in cfg

    def test_hard_weight_limit_actually_changes_detector_behavior(self, tmp_path, monkeypatch):
        """End-to-end: AGENTSONAR_HARD_WEIGHT_LIMIT=3 should make the
        Layer 2 repetitive detector fire much sooner than the default
        of 10.0. A 5-event same-edge burst should produce at least one
        alert at HWL=3.0 where it would produce zero at default."""
        monkeypatch.setenv(cc.ENV_HARD_WEIGHT_LIMIT, "3.0")
        monkeypatch.setenv(cc.ENV_EDGE_ANOMALY_WARNING_THRESHOLD, "2")
        sid = "hwl-trips-sooner"
        for _ in range(8):
            handle_hook("PreToolUse", _payload(
                session_id=sid,
                tool_name="Read",
                tool_input={"file_path": "/x.py"},
            ))
        state_path = tmp_path / "sessions" / sid / "state.pkl"
        engine = cc._load_or_build_engine(state_path, cc._build_engine_config())
        events = list(engine.get_recent_events())
        assert len(events) >= 1, "expected at least one alert with HWL=3.0"

    def test_new_env_vars_in_public_surface(self):
        from agentsonar._integrations import claude as pkg
        for name in (
            "ENV_HARD_WEIGHT_LIMIT",
            "ENV_PER_EDGE_LIMIT",
            "ENV_GLOBAL_LIMIT",
        ):
            assert name in cc.__all__
            assert hasattr(pkg, name)
            assert name in pkg.__all__

    def test_new_env_var_string_values(self):
        assert cc.ENV_HARD_WEIGHT_LIMIT == "AGENTSONAR_HARD_WEIGHT_LIMIT"
        assert cc.ENV_PER_EDGE_LIMIT == "AGENTSONAR_PER_EDGE_LIMIT"
        assert cc.ENV_GLOBAL_LIMIT == "AGENTSONAR_GLOBAL_LIMIT"

    def test_all_three_unset_means_no_keys_in_config(self, monkeypatch):
        """With none of the new env vars set, _build_engine_config
        does NOT include hard_weight_limit / per_edge_limit / global_limit.
        Engine defaults apply transparently."""
        for env in (cc.ENV_HARD_WEIGHT_LIMIT, cc.ENV_PER_EDGE_LIMIT, cc.ENV_GLOBAL_LIMIT):
            monkeypatch.delenv(env, raising=False)
        cfg = cc._build_engine_config()
        assert "hard_weight_limit" not in cfg
        assert "per_edge_limit" not in cfg
        assert "global_limit" not in cfg


class TestDetectorConfigRefreshAcrossReload:
    """Regression guard for the 0.6.1 bug: detector internals
    (`_decay`, `_limiter`) are pickled with their config bundled in,
    so env-var changes between sessions used to be silently ignored
    on hook 2+. Fix: capture fresh config before overlay, force-refresh
    after. Runtime state (windows, weights) still survives."""

    def test_hard_weight_limit_refreshes_across_reload(self, tmp_path, monkeypatch):
        sid = "hwl-across-reload"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        # Day 1: default
        monkeypatch.delenv(cc.ENV_HARD_WEIGHT_LIMIT, raising=False)
        e1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert e1._decay.hard_weight_limit == 10.0
        cc._save_engine_state(state_path, e1)

        # Day 2: env var lowers it
        monkeypatch.setenv(cc.ENV_HARD_WEIGHT_LIMIT, "3.0")
        e2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert e2._decay.hard_weight_limit == 3.0, (
            "detector config not refreshed across reload"
        )

    def test_per_edge_limit_refreshes_across_reload(self, tmp_path, monkeypatch):
        sid = "pel-across-reload"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        monkeypatch.delenv(cc.ENV_PER_EDGE_LIMIT, raising=False)
        e1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert e1._limiter.per_edge_limit == 10
        cc._save_engine_state(state_path, e1)

        monkeypatch.setenv(cc.ENV_PER_EDGE_LIMIT, "5")
        e2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert e2._limiter.per_edge_limit == 5

    def test_global_limit_refreshes_across_reload(self, tmp_path, monkeypatch):
        sid = "gl-across-reload"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        monkeypatch.delenv(cc.ENV_GLOBAL_LIMIT, raising=False)
        e1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        cc._save_engine_state(state_path, e1)

        monkeypatch.setenv(cc.ENV_GLOBAL_LIMIT, "50")
        e2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert e2._limiter.global_limit == 50

    def test_detector_runtime_state_preserved_across_reload(self, tmp_path, monkeypatch):
        """Critical regression guard: config refresh must NOT wipe the
        detector's runtime state. The rate limiter's edge windows and
        the decay detector's weight tally must survive the reload so
        detection works across hook boundaries."""
        from agentsonar._core.models import InteractionEvent

        sid = "runtime-state-preserved"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        # Prime _limiter with edge events
        e1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        ts = 1.0
        for _ in range(5):
            e1.ingest(InteractionEvent("main", "Read:/x.py", ts, None))
            ts += 0.1
        edges_count = len(e1._limiter._edges)
        assert edges_count > 0
        cc._save_engine_state(state_path, e1)

        # Reload with a NEW config (env var change)
        monkeypatch.setenv(cc.ENV_HARD_WEIGHT_LIMIT, "3.0")
        e2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        # Config refreshed
        assert e2._decay.hard_weight_limit == 3.0
        # Runtime state preserved
        assert len(e2._limiter._edges) == edges_count, (
            "edge windows lost during config refresh"
        )


# =====================================================================
# 20. Tier A polish (0.6.2)
# =====================================================================


class TestForgivingBooleanEnvVars:
    """0.6.2: _env_truthy now also accepts any positive integer string.
    Fixes the foot-gun where PREVENT_RATE_LIMIT=4 was silently false."""

    def test_legacy_strings_still_work(self, monkeypatch):
        for val in ("1", "true", "True", "YES", "on", "enabled"):
            monkeypatch.setenv(cc.ENV_PREVENT_RATE_LIMIT, val)
            assert cc._env_truthy(cc.ENV_PREVENT_RATE_LIMIT), f"failed for {val!r}"

    def test_positive_integer_strings_now_truthy(self, monkeypatch):
        for val in ("2", "4", "100", "999"):
            monkeypatch.setenv(cc.ENV_PREVENT_RATE_LIMIT, val)
            assert cc._env_truthy(cc.ENV_PREVENT_RATE_LIMIT), (
                f"positive integer {val!r} should be truthy in 0.6.2+"
            )

    def test_zero_and_negative_remain_false(self, monkeypatch):
        for val in ("0", "-3", "-100"):
            monkeypatch.setenv(cc.ENV_PREVENT_RATE_LIMIT, val)
            assert not cc._env_truthy(cc.ENV_PREVENT_RATE_LIMIT)

    def test_garbage_remains_false(self, monkeypatch):
        for val in ("garbage", "false", "no", "off", "disabled", ""):
            monkeypatch.setenv(cc.ENV_PREVENT_RATE_LIMIT, val)
            assert not cc._env_truthy(cc.ENV_PREVENT_RATE_LIMIT)

    def test_prevent_rate_limit_with_integer_value_enables_resource(self, monkeypatch):
        """End-to-end: PREVENT_RATE_LIMIT=4 (the foot-gun shape from
        the user's first test) now enables resource_exhaustion in the
        engine config (separately tuned by PER_EDGE_LIMIT)."""
        monkeypatch.setenv(cc.ENV_PREVENT_RATE_LIMIT, "4")
        cfg = cc._build_engine_config()
        assert cfg["prevent"]["resource_exhaustion"] is True


class TestRateWindowEnvVars:
    """0.6.2: AGENTSONAR_RATE_WINDOW_SECONDS and
    AGENTSONAR_RATE_RESET_RATIO tune the Layer 1 rate limiter window
    + circuit-breaker reset ratio."""

    def test_window_seconds_lands_in_config(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_RATE_WINDOW_SECONDS, "30.0")
        cfg = cc._build_engine_config()
        assert cfg.get("window_size") == 30.0

    def test_reset_ratio_lands_in_config(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_RATE_RESET_RATIO, "0.25")
        cfg = cc._build_engine_config()
        assert cfg.get("reset_ratio") == 0.25

    def test_window_seconds_garbage_falls_back(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_RATE_WINDOW_SECONDS, "not-a-float")
        cfg = cc._build_engine_config()
        assert "window_size" not in cfg

    def test_window_seconds_zero_falls_back(self, monkeypatch):
        monkeypatch.setenv(cc.ENV_RATE_WINDOW_SECONDS, "0.0")
        cfg = cc._build_engine_config()
        assert "window_size" not in cfg

    def test_window_refreshes_across_state_reload(self, tmp_path, monkeypatch):
        """The 0.5.3 detector-config-refresh fix carries forward to the
        new rate window knob: env-var changes apply on every load."""
        sid = "window-reload"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        monkeypatch.delenv(cc.ENV_RATE_WINDOW_SECONDS, raising=False)
        e1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        cc._save_engine_state(state_path, e1)

        monkeypatch.setenv(cc.ENV_RATE_WINDOW_SECONDS, "30.0")
        e2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert e2._limiter.window_size == 30.0


class TestStrongerPreventStderrMessage:
    """0.6.2: the Prevent block message is more imperative so natural-
    language prompts produce graceful stops instead of retry loops."""

    def test_message_says_BLOCKED_in_caps(self, capsys, tmp_path, monkeypatch):
        """The new stderr message must use 'BLOCKED' (caps) as the
        primary signal so models reading tool errors take it as a hard
        halt, not a soft retry."""
        monkeypatch.setenv(cc.ENV_PREVENT_REPETITIVE_MAX_EVENTS, "3")
        monkeypatch.setenv(cc.ENV_WARNING_THRESHOLD, "2")
        monkeypatch.setenv(cc.ENV_CRITICAL_THRESHOLD, "10")
        sid = "stronger-msg"
        session_dir = tmp_path / "sessions" / sid
        session_dir.mkdir(parents=True, exist_ok=True)
        state_path = session_dir / "state.pkl"

        from agentsonar._core.models import InteractionEvent
        engine = cc._load_or_build_engine(state_path, cc._build_engine_config())
        ts = 1.0
        for _ in range(25):
            engine.ingest(InteractionEvent("main", "Read:/x.py", ts, None))
            ts += 0.5
        cc._save_engine_state(state_path, engine)

        rc = handle_hook("PreToolUse", {
            "session_id": sid, "parent_session_id": None,
            "tool_name": "Read", "tool_input": {"file_path": "/x.py"},
        })
        assert rc == 2
        captured = capsys.readouterr()
        assert "BLOCKED" in captured.err, (
            "Expected the stronger BLOCKED phrasing in stderr"
        )
        assert "Do NOT retry" in captured.err, (
            "Expected explicit 'Do NOT retry' instruction"
        )
        assert "Do NOT route around" in captured.err, (
            "Expected the route-around-block warning"
        )


# =====================================================================
# 21. PostToolUse skip from engine.ingest (0.6.2, Option B)
# =====================================================================
#
# Before 0.6.2 both PreToolUse and PostToolUse fed through engine.ingest,
# inflating edge weights ~2x per tool call. 0.6.2 skips Post from ingest
# so one tool call = one engine event. Timeline.jsonl still records Post
# for audit / failure visibility.


class TestPostToolUseSkipsIngest:

    def test_pre_tool_use_still_ingests(self, tmp_path):
        """Regression guard: PreToolUse continues to ingest into the engine."""
        sid = "pre-still-ingests"
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Read",
            tool_input={"file_path": "/x.py"},
        ))
        state_path = tmp_path / "sessions" / sid / "state.pkl"
        engine = cc._load_or_build_engine(state_path, cc._build_engine_config())
        # Pre fired -> at least one edge tracked in coord graph
        assert engine.get_summary()["total_events"] >= 1

    def test_post_tool_use_does_not_ingest(self, tmp_path):
        """0.6.2: PostToolUse must NOT add an event to engine.coord_graph.
        Only Pre counts toward edge weight."""
        sid = "post-no-ingest"
        # Pre adds one event
        handle_hook("PreToolUse", _payload(
            session_id=sid,
            tool_name="Read",
            tool_input={"file_path": "/y.py"},
        ))
        state_path = tmp_path / "sessions" / sid / "state.pkl"
        engine1 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        events_after_pre = engine1.get_summary()["total_events"]

        # Post fires, should NOT increment edge count
        handle_hook("PostToolUse", _payload(
            session_id=sid,
            tool_name="Read",
            tool_input={"file_path": "/y.py"},
            tool_response={"content": "ok"},
        ))
        engine2 = cc._load_or_build_engine(state_path, cc._build_engine_config())
        assert engine2.get_summary()["total_events"] == events_after_pre, (
            "PostToolUse should not increment engine event count"
        )

    def test_post_tool_use_still_appears_in_timeline(self, tmp_path):
        """Audit trail preserved: PostToolUse records still land in
        timeline.jsonl even though they don't ingest into the engine."""
        import json as _json
        sid = "post-in-timeline"
        handle_hook("PreToolUse", _payload(
            session_id=sid, tool_name="Read",
            tool_input={"file_path": "/x.py"},
        ))
        handle_hook("PostToolUse", _payload(
            session_id=sid, tool_name="Read",
            tool_input={"file_path": "/x.py"},
            tool_response={"content": "ok"},
        ))
        timeline = tmp_path / "sessions" / sid / "timeline.jsonl"
        records = [_json.loads(l) for l in timeline.read_text(encoding="utf-8").splitlines() if l.strip()]
        pre = [r for r in records if r["event_name"] == "PreToolUse"]
        post = [r for r in records if r["event_name"] == "PostToolUse"]
        assert len(pre) == 1
        assert len(post) == 1, "PostToolUse must still write timeline record"

    def test_post_tool_use_failure_status_in_timeline(self, tmp_path):
        """Failure visibility: PostToolUse with an error response writes
        a timeline record with metadata.status='error'. Users grep
        timeline.jsonl for failed calls even though engine ingest skipped."""
        import json as _json
        sid = "post-failure"
        handle_hook("PostToolUse", _payload(
            session_id=sid, tool_name="Bash",
            tool_input={"command": "false"},
            tool_response={"is_error": True, "stderr": "exit 1"},
        ))
        timeline = tmp_path / "sessions" / sid / "timeline.jsonl"
        records = [_json.loads(l) for l in timeline.read_text(encoding="utf-8").splitlines() if l.strip()]
        assert any(
            r["event_name"] == "PostToolUse" and r["metadata"].get("status") == "error"
            for r in records
        ), "expected a PostToolUse record with status='error'"

    def test_pre_post_pair_counts_as_one_engine_event(self, tmp_path):
        """End-to-end: 5 (Pre + Post) pairs for the same Read should
        produce exactly 5 events in the engine (not 10). This is the
        whole motivation for the Option B change — edge weights now
        match real tool-call counts, so thresholds calibrate correctly."""
        sid = "pre-post-pair-counts-once"
        for _ in range(5):
            handle_hook("PreToolUse", _payload(
                session_id=sid, tool_name="Read",
                tool_input={"file_path": "/x.py"},
            ))
            handle_hook("PostToolUse", _payload(
                session_id=sid, tool_name="Read",
                tool_input={"file_path": "/x.py"},
                tool_response={"content": "ok"},
            ))
        state_path = tmp_path / "sessions" / sid / "state.pkl"
        engine = cc._load_or_build_engine(state_path, cc._build_engine_config())
        # 5 Pre + 5 Post = 5 engine events (Post skipped from ingest)
        assert engine.get_summary()["total_events"] == 5, (
            f"expected 5 events (one per tool call); got "
            f"{engine.get_summary()['total_events']}"
        )
