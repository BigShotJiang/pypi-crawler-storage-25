"""Tests for `agentsonar reset-session` (0.6.2)."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from agentsonar._integrations.claude.reset import reset_session


@pytest.fixture(autouse=True)
def _isolate_root(tmp_path, monkeypatch):
    """Route AGENTSONAR_CLAUDE_CODE_ROOT to a per-test tmpdir."""
    monkeypatch.setenv("AGENTSONAR_CLAUDE_CODE_ROOT", str(tmp_path))
    monkeypatch.setenv("AGENTSONAR_TELEMETRY", "off")
    return tmp_path


def _seed_session(root: Path, sid: str, *, with_state: bool = True) -> Path:
    """Create a session dir with the canonical files for testing."""
    session_dir = root / "sessions" / sid
    session_dir.mkdir(parents=True, exist_ok=True)
    if with_state:
        (session_dir / "state.pkl").write_bytes(b"\x00" * 16)
        (session_dir / "last_hook_at").write_text("123.0", encoding="utf-8")
    (session_dir / "timeline.jsonl").write_text(
        '{"x": 1}\n', encoding="utf-8"
    )
    return session_dir


class TestResetSessionBasic:

    def test_returns_zero_when_no_sessions_dir(self, tmp_path, capsys):
        """If the sessions directory doesn't exist at all, reset_session
        prints a friendly note and exits 0."""
        # No sessions/ subdir under root
        rc = reset_session()
        assert rc == 0
        captured = capsys.readouterr()
        assert "no sessions directory" in captured.err

    def test_returns_zero_when_no_active_sessions(self, tmp_path, capsys):
        """sessions/ exists but is empty (or only archived)."""
        (tmp_path / "sessions").mkdir()
        (tmp_path / "sessions" / "archived").mkdir()
        rc = reset_session()
        assert rc == 0


class TestResetSessionSpecific:

    def test_reset_specific_session_removes_state(self, tmp_path):
        sid = "sid-target"
        session_dir = _seed_session(tmp_path, sid)
        assert (session_dir / "state.pkl").exists()
        rc = reset_session(session_id=sid)
        assert rc == 0
        assert not (session_dir / "state.pkl").exists()
        assert not (session_dir / "last_hook_at").exists()

    def test_specific_session_preserves_timeline(self, tmp_path):
        sid = "sid-preserve-timeline"
        session_dir = _seed_session(tmp_path, sid)
        timeline = session_dir / "timeline.jsonl"
        assert timeline.exists()
        reset_session(session_id=sid)
        assert timeline.exists(), "timeline.jsonl must be preserved"

    def test_missing_session_returns_1(self, tmp_path, capsys):
        (tmp_path / "sessions").mkdir()
        rc = reset_session(session_id="does-not-exist")
        assert rc == 1
        captured = capsys.readouterr()
        assert "session not found" in captured.err


class TestResetSessionAll:

    def test_reset_all_clears_every_session(self, tmp_path):
        sids = ["sid-1", "sid-2", "sid-3"]
        for sid in sids:
            _seed_session(tmp_path, sid)
        rc = reset_session(reset_all=True)
        assert rc == 0
        for sid in sids:
            assert not (tmp_path / "sessions" / sid / "state.pkl").exists()
            # Timelines still there
            assert (tmp_path / "sessions" / sid / "timeline.jsonl").exists()

    def test_reset_all_skips_archived(self, tmp_path):
        _seed_session(tmp_path, "sid-active")
        archived_dir = tmp_path / "sessions" / "archived" / "sid-old"
        archived_dir.mkdir(parents=True)
        (archived_dir / "state.pkl").write_bytes(b"\x00")
        reset_session(reset_all=True)
        # Active cleared, archived left alone
        assert not (tmp_path / "sessions" / "sid-active" / "state.pkl").exists()
        assert (archived_dir / "state.pkl").exists()


class TestResetSessionDryRun:

    def test_dry_run_writes_nothing(self, tmp_path, capsys):
        sid = "sid-dry"
        session_dir = _seed_session(tmp_path, sid)
        rc = reset_session(session_id=sid, dry_run=True)
        assert rc == 0
        assert (session_dir / "state.pkl").exists(), "dry-run must not delete"
        captured = capsys.readouterr()
        assert "would clear" in captured.out


class TestResetSessionDefault:

    def test_default_targets_most_recent_session(self, tmp_path):
        """Without --session or --all, the most recently modified session
        is reset. Setup creates two sessions and touches the newer one's
        state.pkl after the older's."""
        import os, time
        older = _seed_session(tmp_path, "older")
        time.sleep(0.05)
        newer = _seed_session(tmp_path, "newer")

        rc = reset_session()
        assert rc == 0
        # Newer cleared, older preserved
        assert not (newer / "state.pkl").exists()
        assert (older / "state.pkl").exists()
