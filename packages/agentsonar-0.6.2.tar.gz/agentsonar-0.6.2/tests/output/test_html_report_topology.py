"""
HTML report Topology section renderer tests.

Covers:
  - Multi-agent events (typed buckets empty) → legacy single-list view
    (regression guard for CrewAI / LangGraph / custom adapters)
  - Claude Code events with mixed node types → grouped view with
    separate rows for agents / tool calls / MCP calls / subagent spawns
  - The "agents" row in the grouped view excludes nodes that landed in
    typed buckets (so a Claude Code event with main + Read:/path shows
    "agents: main" + "tool calls: Read:/path", NOT "agents: main, Read:/path")
  - Each typed row carries its count
  - HTML output is well-formed (no broken tags)
"""
from __future__ import annotations

import re

from agentsonar._core.schema import Topology
from agentsonar._output.html_report import _render_topology


def _topology(
    agents_involved: tuple[str, ...],
    *,
    tools=(),
    mcps=(),
    spawns=(),
) -> Topology:
    """Helper to build a Topology with explicit typed buckets."""
    return Topology(
        agents_involved=agents_involved,
        interaction_pattern="circular",
        agent_count=len(agents_involved),
        occurrence_count=3,
        edge_frequency={"a->b": 3},
        tools_involved=tools,
        mcp_calls_involved=mcps,
        subagent_spawns_involved=spawns,
        tool_count=len(tools),
        mcp_count=len(mcps),
        task_spawn_count=len(spawns),
    )


# =====================================================================
# Legacy view (backward-compat for multi-agent adapters)
# =====================================================================


class TestLegacyView:

    def test_multi_agent_event_renders_legacy_view(self):
        """CrewAI / LangGraph / custom event: bare agent names, all typed
        buckets empty → legacy single-list view, zero visual change."""
        t = _topology(("planner", "researcher", "writer"))
        html_out = _render_topology(t)
        # Legacy view has the bare "agents" line with ALL nodes
        assert "agents</div><div class=\"v\">planner, researcher, writer</div>" in html_out
        # Legacy view also has "agent count"
        assert "agent count</div><div class=\"v\">3</div>" in html_out
        # Legacy view does NOT have typed rows
        assert "tool calls" not in html_out
        assert "MCP calls" not in html_out
        assert "subagent spawns" not in html_out

    def test_event_with_zero_typed_counts_renders_legacy_view(self):
        """Explicit zero counts still trigger the legacy view."""
        t = _topology(("agent_a", "agent_b"), tools=(), mcps=(), spawns=())
        html_out = _render_topology(t)
        assert "agent count" in html_out
        assert "tool calls" not in html_out


# =====================================================================
# Grouped view (Claude Code-style events)
# =====================================================================


class TestGroupedView:

    def test_main_plus_read_renders_grouped_view(self):
        """main → Read:/path: agents row has 'main' only; tool calls row
        has the Read path. The conflation bug ('agent count: 2' for
        main + Read) is fixed."""
        t = _topology(
            ("main", "Read:/src/hello.py"),
            tools=("Read:/src/hello.py",),
        )
        html_out = _render_topology(t)
        # "Agents" row contains main only, with count 1
        assert "agents</div>" in html_out
        # find the agents row's value
        m = re.search(r'<div class="k">agents</div><div class="v">([^<]+)</div>', html_out)
        assert m is not None, f"could not find agents row in: {html_out[:500]}"
        agents_value = m.group(1)
        assert "main" in agents_value
        assert "Read" not in agents_value  # Read is in tool calls, not agents
        assert "(1)" in agents_value  # count

        # "tool calls" row contains the Read path
        assert "tool calls" in html_out
        m = re.search(r'<div class="k">tool calls</div><div class="v">([^<]+)</div>', html_out)
        assert m is not None
        tools_value = m.group(1)
        assert "Read:/src/hello.py" in tools_value
        assert "(1)" in tools_value

    def test_main_plus_mcp_renders_mcp_row(self):
        t = _topology(
            ("main", "mcp__github__create_issue:fp"),
            mcps=("mcp__github__create_issue:fp",),
        )
        html_out = _render_topology(t)
        assert "MCP calls" in html_out
        m = re.search(r'<div class="k">MCP calls</div><div class="v">([^<]+)</div>', html_out)
        assert m is not None
        assert "mcp__github__create_issue:fp" in m.group(1)
        assert "(1)" in m.group(1)
        # No tool calls or subagent spawns rows
        assert "tool calls" not in html_out
        assert "subagent spawns" not in html_out

    def test_main_plus_task_spawn_renders_spawn_row(self):
        t = _topology(
            ("main", "Task_spawn:reviewer"),
            spawns=("Task_spawn:reviewer",),
        )
        html_out = _render_topology(t)
        assert "subagent spawns" in html_out
        m = re.search(r'<div class="k">subagent spawns</div><div class="v">([^<]+)</div>', html_out)
        assert m is not None
        assert "Task_spawn:reviewer" in m.group(1)
        assert "(1)" in m.group(1)

    def test_full_mixed_event_renders_all_rows(self):
        """main + Read + MCP + Task_spawn: all four rows render with
        correct nodes and counts."""
        t = _topology(
            ("main", "Read:/src/x.py", "mcp__github__get:fp", "Task_spawn:reviewer"),
            tools=("Read:/src/x.py",),
            mcps=("mcp__github__get:fp",),
            spawns=("Task_spawn:reviewer",),
        )
        html_out = _render_topology(t)
        assert "agents</div><div class=\"v\">main" in html_out
        assert "tool calls</div><div class=\"v\">Read:/src/x.py" in html_out
        assert "MCP calls</div><div class=\"v\">mcp__github__get:fp" in html_out
        assert "subagent spawns</div><div class=\"v\">Task_spawn:reviewer" in html_out
        # Each row carries its count
        assert "(1)" in html_out  # at least one count


# =====================================================================
# Agents-only row computation (set diff)
# =====================================================================


class TestAgentsRowSetDiff:

    def test_agents_row_excludes_tool_nodes(self):
        """The 'agents' row in grouped view excludes nodes that landed
        in typed buckets. Otherwise we'd be back to the conflation bug."""
        t = _topology(
            ("main", "Read:/x.py", "Edit:/y.py"),
            tools=("Read:/x.py", "Edit:/y.py"),
        )
        html_out = _render_topology(t)
        m = re.search(r'<div class="k">agents</div><div class="v">([^<]+)</div>', html_out)
        assert m is not None
        agents_value = m.group(1)
        assert "main" in agents_value
        assert "Read" not in agents_value
        assert "Edit" not in agents_value

    def test_no_agents_row_when_all_nodes_typed(self):
        """Pathological edge case: an event with only tool nodes (no
        agents). The agents row should not render at all."""
        t = _topology(
            ("Read:/x.py", "Edit:/y.py"),
            tools=("Read:/x.py", "Edit:/y.py"),
        )
        html_out = _render_topology(t)
        # No agents row
        assert "<div class=\"k\">agents</div>" not in html_out
        # But tool calls row IS there
        assert "tool calls" in html_out


# =====================================================================
# Defensive rendering
# =====================================================================


class TestDefensiveRendering:

    def test_render_does_not_crash_without_typed_fields(self):
        """Topology constructed via getattr fallback path should not crash."""
        class TopologyMissingFields:
            """Mock Topology missing the new typed fields (simulating
            pre-0.5.2 event read in by post-0.5.2 renderer)."""
            agents_involved = ("a", "b")
            interaction_pattern = "circular"
            agent_count = 2
            occurrence_count = 1
            edge_frequency = {"a->b": 1}

        html_out = _render_topology(TopologyMissingFields())
        # Should render the legacy view
        assert "agents</div>" in html_out
        assert "agent count" in html_out

    def test_html_escaping_in_grouped_view(self):
        """Node names with HTML-special chars are escaped."""
        t = _topology(
            ("main", "Read:<script>alert(1)</script>"),
            tools=("Read:<script>alert(1)</script>",),
        )
        html_out = _render_topology(t)
        # Raw script tag should not appear
        assert "<script>alert(1)</script>" not in html_out
        # Escaped form should appear
        assert "&lt;script&gt;" in html_out
