"""Anonymous session-event telemetry.

Sends ONE event per AgentSonar session start to a stats endpoint. The data
is minimal: install_id, version, Python version, OS, adapter name. No
agent names, no prompts, no log content, no project paths.

Disable via either:
    AGENTSONAR_TELEMETRY=off       (or 0, false, no)
    DO_NOT_TRACK=1                 (or true, yes; the universal opt-out signal)

The first time AgentSonar runs on a machine, a one-time disclosure message
is printed to stderr explaining what's collected and how to disable.
Subsequent runs are silent.

Design invariants:
- Never blocks the main thread (fire-and-forget HTTP in a daemon thread).
- Never raises into user code (all exceptions swallowed silently).
- Never logs identifying user data (no IPs, no agent names, no paths).
- Never delays the engine startup by more than a few microseconds.
"""
from __future__ import annotations

import json
import os
import platform
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Any
from urllib import request as _urlrequest

# Endpoint defaults to the production telemetry collector. Override only
# for local development or self-hosted deployments via the env var below.
_DEFAULT_ENDPOINT = "https://t.agent-sonar.com/event"
_ENV_ENDPOINT = "AGENTSONAR_TELEMETRY_ENDPOINT"

_ENV_DISABLE = "AGENTSONAR_TELEMETRY"
_ENV_DNT = "DO_NOT_TRACK"

_DISABLED_VALUES = {"0", "false", "no", "off", "disabled"}
_ENABLED_VALUES = {"1", "true", "yes", "on", "enabled"}

_HTTP_TIMEOUT_SECONDS = 2.0

# Persistent state lives in ~/.agentsonar/state.json. Survives across
# Python interpreters / virtual envs / CI runs that share a home dir.
_STATE_DIR_NAME = ".agentsonar"
_STATE_FILE_NAME = "state.json"


def _state_path() -> Path:
    """Return the canonical path to the state file."""
    return Path.home() / _STATE_DIR_NAME / _STATE_FILE_NAME


def _load_state() -> dict[str, Any]:
    """Load state file. Return empty dict on any error or non-dict content.

    JSON `null`, lists, strings, and numbers all produce non-dict values that
    would AttributeError when callers do `state.get(...)`. Validate that the
    loaded content is actually a dict before returning, otherwise treat the
    file as "no useful state" and start fresh.
    """
    try:
        p = _state_path()
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {}


def _save_state(state: dict[str, Any]) -> None:
    """Write state file atomically. Silent on error.

    Uses a per-thread temp filename so two threads writing concurrently
    don't trample each other's tmp file. The final `replace` is atomic
    on POSIX and Windows, so the visible state.json is never half-written.
    Last writer wins, which is fine for our content (anyone's full state
    is valid).
    """
    try:
        p = _state_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        # Atomic write: write to a UNIQUE temp file, then rename.
        # Unique = pid + thread id, so concurrent writers don't corrupt
        # each other's tmp file before the rename.
        tmp = p.parent / f"{p.name}.tmp.{os.getpid()}.{threading.get_ident()}"
        tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
        tmp.replace(p)
    except Exception:
        # Best-effort cleanup of stranded tmp on failure. Wrapped in its
        # own try/except so a missing tmp doesn't double-fault.
        try:
            if 'tmp' in locals() and tmp.exists():
                tmp.unlink()
        except Exception:
            pass


def _ensure_install_id(state: dict[str, Any]) -> str:
    """Return install_id, generating and persisting a new one if missing."""
    install_id = state.get("install_id")
    if not install_id:
        install_id = str(uuid.uuid4())
        state["install_id"] = install_id
        _save_state(state)
    return install_id


def is_disabled() -> bool:
    """True if telemetry should be skipped for this run.

    Priority order (first matching rule wins):
      1. DO_NOT_TRACK=1 (universal opt-out, always wins)
      2. AGENTSONAR_TELEMETRY=off / 0 / false / no  -> disabled
      3. AGENTSONAR_TELEMETRY=on / 1 / true / yes   -> enabled (overrides
         any prior persistent disable; lets users re-enable from env)
      4. Persistent state file (telemetry_disabled=true)  -> disabled
      5. Default                                          -> enabled

    Wrapped in a top-level try/except so a broken filesystem or weird
    platform never raises into user code.
    """
    try:
        # 1. Universal opt-out: DNT always wins, nothing overrides it.
        dnt = os.environ.get(_ENV_DNT, "").strip().lower()
        if dnt in _ENABLED_VALUES:
            return True

        # 2 & 3. AgentSonar-specific env var (off OR explicit on)
        val = os.environ.get(_ENV_DISABLE, "").strip().lower()
        if val in _DISABLED_VALUES:
            return True
        if val in _ENABLED_VALUES:
            # Explicit re-enable from env overrides persistent state.
            return False

        # 4. Persistent disable set by a previous opt-out
        state = _load_state()
        if state.get("telemetry_disabled") is True:
            return True

        # 5. Default: enabled
        return False
    except Exception:
        # If ANYTHING in the disable check raises, default to enabled.
        # The rest of session_start has its own try/except, so this is
        # the conservative choice ("send the event") which is
        # consistent with our "opt-out" stance.
        return False


def _show_disclosure_once(state: dict[str, Any], version: str) -> None:
    """Print the first-run disclosure message to stderr exactly once.

    Tracked via state.json -> disclosure_shown=true. Best-effort: any
    exception writing the state file means we'll show it again next time,
    which is acceptable.
    """
    if state.get("disclosure_shown") is True:
        return

    msg = (
        f"\n"
        f"  AgentSonar {version}\n"
        f"  Anonymous telemetry is on by default to help us improve the SDK.\n"
        f"\n"
        f"    What we send:    install_id, version, Python version, OS, adapter name\n"
        f"    What we don't:   agent names, prompts, log content, project paths\n"
        f"\n"
        f"  Disable any time:  set AGENTSONAR_TELEMETRY=off  (or DO_NOT_TRACK=1)\n"
        f"  In code:           pass config={{'telemetry': False}} to your adapter\n"
        f"  Read more:         https://www.agent-sonar.com/telemetry\n"
        f"\n"
    )
    try:
        sys.stderr.write(msg)
        sys.stderr.flush()
    except Exception:
        pass

    state["disclosure_shown"] = True
    _save_state(state)


def disable_persistently() -> None:
    """Mark telemetry as disabled in the state file. Future sessions skip it.

    Used when a user passes config={'telemetry': False} so the choice
    persists across runs without needing the env var every time.
    """
    try:
        state = _load_state()
        state["telemetry_disabled"] = True
        _save_state(state)
    except Exception:
        pass


def enable_persistently() -> None:
    """Clear any persistent disable in the state file.

    Used when a user passes config={'telemetry': True} after previously
    opting out. Symmetric with disable_persistently() so users can
    re-enable from code without manually deleting the state file.
    """
    try:
        state = _load_state()
        if "telemetry_disabled" in state:
            del state["telemetry_disabled"]
            _save_state(state)
    except Exception:
        pass


def _post_event(payload: dict[str, Any]) -> None:
    """Fire-and-forget POST to the telemetry endpoint.

    Runs in a daemon thread so the main thread never blocks. All exceptions
    are swallowed; telemetry must never break user code.
    """
    endpoint = os.environ.get(_ENV_ENDPOINT, _DEFAULT_ENDPOINT)

    def _send() -> None:
        try:
            data = json.dumps(payload).encode("utf-8")
            req = _urlrequest.Request(
                endpoint,
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": f"agentsonar/{payload.get('version', 'unknown')}",
                },
                method="POST",
            )
            # _urlrequest.urlopen with a timeout. We don't read the body;
            # we don't care about the response, only that the post fired.
            with _urlrequest.urlopen(req, timeout=_HTTP_TIMEOUT_SECONDS) as resp:
                resp.read(0)
        except Exception:
            # All errors are silent. Telemetry is not allowed to fail loudly.
            pass

    t = threading.Thread(target=_send, daemon=True, name="agentsonar-telemetry")
    t.start()


def session_start(
    adapter: str,
    version: str,
    config_pref: bool | None = None,
) -> None:
    """Record a session-start event. Safe to call multiple times.

    Parameters
    ----------
    adapter : str
        One of "custom_python", "crewai", "langgraph", "oma_sidecar".
    version : str
        AgentSonar version string (from agentsonar.__version__).
    config_pref : bool | None
        Tri-state from `config.get("telemetry")`:
        - None  -> no preference, follow env vars + persistent state
        - True  -> explicit opt-in from code; clears any persistent disable
        - False -> explicit opt-out from code; persists across sessions

    This function is fire-and-forget. It never raises, never blocks more
    than the few microseconds needed to spawn a daemon thread.
    """
    try:
        if config_pref is False:
            disable_persistently()
            return

        if config_pref is True:
            # Symmetric re-enable from code: clear any prior persistent
            # disable so the rest of this function can fire normally
            # (subject only to env var disables, which still win).
            enable_persistently()

        if is_disabled():
            return

        state = _load_state()
        install_id = _ensure_install_id(state)
        _show_disclosure_once(state, version)

        payload = {
            "install_id": install_id,
            "session_id": str(uuid.uuid4()),
            "version": version,
            "python": f"{sys.version_info.major}.{sys.version_info.minor}",
            "os": sys.platform,
            "arch": platform.machine().lower() or "unknown",
            "adapter": adapter,
            "timestamp": time.time(),
        }
        _post_event(payload)
    except Exception:
        # Last-resort guard. Telemetry must never break user code.
        pass
