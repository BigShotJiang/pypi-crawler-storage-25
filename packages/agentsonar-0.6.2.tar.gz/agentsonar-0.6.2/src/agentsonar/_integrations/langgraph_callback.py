"""
LangGraph adapter — translates LangGraph callback events into generic
InteractionEvents for the framework-agnostic detection engine.

Hooks into LangGraph's callback system via
langchain_core.callbacks.BaseCallbackHandler. Only on_chain_start carries
reliable metadata (langgraph_node, langgraph_step).

The langchain-core dependency is OPTIONAL. If it isn't installed, the
class is still importable (so `from agentsonar import AgentSonarCallback`
never breaks) but passing the callback into LangChain/LangGraph will not
work until the framework is installed. To get a clear error at setup
time, instantiation raises RuntimeError when langchain-core is missing.

Usage (with langchain-core installed):
    from agentsonar import AgentSonarCallback
    result = graph.invoke(input, config={"callbacks": [AgentSonarCallback()]})
"""
from __future__ import annotations

import logging
import sys
import time
from typing import Any

from agentsonar._core.models import InteractionEvent, PreventError
from agentsonar._integrations._health import _health_check
from agentsonar._integrations._safe_engine import build_engine_safely

logger = logging.getLogger(__name__)

# Try to import BaseCallbackHandler; if langchain isn't installed,
# fall back to a plain object base so the class can still be defined.
try:
    from langchain_core.callbacks import BaseCallbackHandler

    _HAS_LANGCHAIN = True
except ImportError:
    BaseCallbackHandler = object  # type: ignore[assignment,misc]
    _HAS_LANGCHAIN = False


class AgentSonarCallback(BaseCallbackHandler):  # type: ignore[misc]
    """LangGraph / LangChain callback handler for AgentSonar coordination detection.

    Detects coordination failures (infinite loops, repetitive interactions,
    cycles) by observing node-to-node transitions in a LangGraph execution.

    Usage:
        from agentsonar import AgentSonarCallback

        sonar = AgentSonarCallback()
        result = graph.invoke(input, config={"callbacks": [sonar]})

        # After execution:
        sonar.get_summary()   # detection results dict
        sonar.shutdown()      # close log file

    Requires the `langgraph` extra:
        pip install agentsonar[langgraph]
    """

    def __init__(self, config: dict | None = None):
        if not _HAS_LANGCHAIN:
            raise RuntimeError(
                "AgentSonarCallback requires langchain-core to be installed. "
                "Install it with:\n"
                "    pip install agentsonar[langgraph]\n"
                "or\n"
                "    pip install langchain-core"
            )
        # super().__init__() from langchain_core's BaseCallbackHandler
        # should not raise — but we wrap it defensively anyway so a
        # future langchain version that validates subclass state can't
        # crash the user's `graph = monitor(...)` line.
        try:
            super().__init__()
        except Exception:
            logger.debug(
                "AgentSonar: BaseCallbackHandler.__init__ raised; continuing",
                exc_info=True,
            )
        # Host-safety seam: build_engine_safely NEVER raises. On any
        # construction failure (bad user config, permission error,
        # platform quirks, disk full, etc.) it logs a warning and
        # returns a silent `_NoOpEngine`. The host application
        # continues normally; AgentSonar just stops detecting for
        # this run. This is the "observer must never crash the
        # observed system" prime directive in one line.
        # Telemetry/health-check label. Hardcoded for the framework
        # adapter — `health_check()` reads it back so dashboards know
        # which adapter is reporting.
        self._adapter_label = "langgraph"
        self.engine = build_engine_safely(config, adapter=self._adapter_label)
        self._previous_node: str | None = None
        self._current_step: int | None = None
        # Tracks the root run_id of the current invocation. Used in
        # `on_chain_start` to detect a new invoke by comparing the
        # incoming root run_id to what we last saw. See the docstring
        # in `on_chain_start` for the full rationale.
        self._current_root_run_id: Any = None

        # Prevent Mode opt-in: when the user configured `prevent={...}`
        # we flip LangChain's `raise_error` flag so PreventError actually
        # escapes to graph.invoke() rather than being swallowed by the
        # CallbackManager (which catches all handler exceptions by default).
        # We do NOT flip this when prevent is disabled — keeping the
        # default swallow-everything behavior preserves the host-safety
        # contract for plain detection-mode users.
        # NOTE: with raise_error=True, ANY exception from our handlers
        # would propagate. The handler bodies below carve out PreventError
        # explicitly and keep all other exceptions caught at DEBUG, so
        # only PreventError can ever reach graph.invoke().
        if getattr(self.engine, "_prevent_classes", None):
            self.raise_error = True

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: Any,
        *,
        run_id: Any = None,
        parent_run_id: Any = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when a chain/graph node starts execution.

        Only processes events where langgraph_node is present in metadata.
        Builds edges from sequential node transitions (previous_node → current_node).

        New-invocation detection:
          We need to reset `_previous_node` between `graph.invoke()` calls
          so no phantom edge forms from the last node of invoke N to the
          first node of invoke N+1 (users commonly reuse a single callback
          across many invokes). TWO signals are used:

          1. A metadata-less chain_start event — LangGraph USED to emit
             this at the top of every invoke, but some versions/modes
             skip it. Can't rely on it alone.
          2. A chain_start with `parent_run_id=None` — this IS guaranteed:
             every invoke() creates a new root run, and the root run's
             `parent_run_id` is None. Watching for a NEW root run_id
             (different from the one we last saw) is the canonical way
             to detect a new invocation.

          We use BOTH signals for defense in depth.
        """
        if sys.is_finalizing():
            return
        try:
            # Signal 1: a metadata-less event. If LangGraph emits one,
            # trust it as an invocation boundary.
            node = (metadata or {}).get("langgraph_node")
            if node is None:
                self._previous_node = None
                self._current_root_run_id = None
                return

            # Signal 2: a NEW root run_id. If this chain_start has no
            # parent_run_id AND its run_id differs from the last root
            # we saw, it's a fresh invocation — reset state.
            #
            # Both `run_id` AND `parent_run_id` being None is
            # ambiguous: it could mean "fresh invoke with no
            # tracking" OR "mid-invoke event where the harness
            # didn't populate run_ids". We CANNOT distinguish these
            # cases from a single event, so we rely on Signal 1
            # (metadata=None) alone for that path — that's what real
            # LangChain emits at invoke boundaries. Test fixtures
            # that want to simulate multiple invokes should either
            # pass distinct run_ids OR insert a metadata-less
            # `chain_start` between invokes (our
            # `_chain_start_no_meta` helper).
            if parent_run_id is None and run_id is not None:
                if run_id != self._current_root_run_id:
                    self._previous_node = None
                    self._current_root_run_id = run_id

            step = (metadata or {}).get("langgraph_step")
            self._current_step = step

            # Build edge from previous node to this node.
            #
            # NOTE on self-loops (`previous_node == node`): these ARE
            # captured. A LangGraph node that conditionally routes
            # back to itself is the textbook "single agent stuck in a
            # retry loop" pattern AgentSonar's pitch claims to catch.
            # Filtering self-transitions out here would silence Layer
            # 1 (rate limiter) and Layer 2 (edge anomaly) for that
            # exact pattern, leaving the user's runaway invisible.
            #
            # Layer 3 (cycle detector) does NOT fire on self-loops —
            # `cycle.py` filters `src == dst` at line 45 because a
            # one-node loop isn't a coordination cycle in the
            # multi-agent sense. So removing the filter here only
            # enables the two layers that SHOULD see retry storms.
            #
            # Behavior change vs. <= 0.4.2: users with explicit
            # `node -> node` graph edges will start seeing
            # edge_anomaly + rate_limit alerts where they previously
            # saw nothing. This is intentional. Users running
            # one-shot single-node graphs (no looping) are unaffected
            # because no `on_chain_start` for the same node fires
            # twice in a non-looping graph.
            if self._previous_node is not None:
                event = InteractionEvent(
                    source_agent=self._previous_node,
                    target_agent=node,
                    timestamp=time.time(),
                    metadata={"langgraph_step": step} if step is not None else None,
                )
                self.engine.ingest(event)

                # Prevent Mode hook (opt-in). MUST run AFTER ingest()
                # so the most recent alert is in _recent_alerts.
                # PreventError is the ONE exception type intentionally
                # allowed to escape — every other exception remains
                # caught below to preserve host safety.
                check = getattr(self.engine, "check_prevent", None)
                if check is not None:
                    check()  # raises PreventError if a tracked failure tripped

            self._previous_node = node
        except PreventError:
            # Re-raise so LangChain's CallbackManager (which wraps our
            # handler call site in try/except) sees it. With
            # raise_error=True set in __init__ when Prevent Mode is on,
            # the manager re-raises and the exception bubbles out of
            # graph.invoke() into the user's try/except PreventError.
            raise
        except Exception:
            logger.debug("AgentSonar callback failed in on_chain_start", exc_info=True)

    def on_chain_end(
        self,
        outputs: Any,
        *,
        run_id: Any = None,
        parent_run_id: Any = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """No-op — metadata is unreliable on end events."""
        pass

    def get_summary(self) -> dict:
        """Return the detection engine summary. Never raises."""
        try:
            return self.engine.get_summary()
        except Exception:
            logger.debug(
                "AgentSonar: engine.get_summary() raised; returning empty",
                exc_info=True,
            )
            return {
                "total_events": 0, "iteration_count": 0, "edge_counts": {},
                "total_estimated_token_waste": 0, "alerts_raised": 0,
                "alerts": [], "degraded": True,
            }

    def health_check(self) -> dict:
        """Return a small health snapshot of this callback. Never raises.

        Mirrors `CustomAdapter.health_check()` and the TypeScript SDK's
        `AgentSonar.healthCheck()`. See
        `agentsonar._integrations._health._health_check` for the full
        output schema and host-safety guarantees.

        Useful for ops dashboards or readiness probes that need to
        verify whether AgentSonar is monitoring the LangGraph run, or
        running silently in degraded mode (kill switch set, real
        engine failed to construct, etc.).
        """
        # `getattr` fallback covers the hypothetical case where __init__
        # didn't reach the line that sets `_adapter_label` (e.g. a
        # subclass overrode __init__ without calling super). Defensive
        # but cheap.
        return _health_check(self.engine, getattr(self, "_adapter_label", "langgraph"))

    def shutdown(self) -> None:
        """Log session end and close the logger. Safe to call multiple times.

        Never raises. Shutdown runs at process exit / crew teardown
        time, where an exception would be the worst possible moment
        to surprise the host application — users are trying to clean
        up and walk away.
        """
        try:
            self.engine.shutdown()
        except Exception:
            logger.debug(
                "AgentSonar: engine.shutdown() raised; swallowing",
                exc_info=True,
            )


def monitor(graph: Any, config: dict | None = None) -> Any:
    """Wrap a LangGraph CompiledGraph to auto-inject AgentSonar monitoring.

    Returns a wrapper that merges an AgentSonarCallback into the callbacks
    list on every invoke/stream/ainvoke/astream call, PRESERVING any
    existing user callbacks rather than replacing them.

    This is the recommended integration path for users who already pass
    their own callbacks to `graph.invoke(...)` — `monitor()` guarantees
    you never have to remember to merge AgentSonar into your callback
    list manually, so your existing observability stays intact.

    Usage:
        from agentsonar import monitor

        graph = monitor(graph)
        # Any existing callbacks the user passes are preserved and
        # AgentSonar is added alongside them — no overrides.
        result = graph.invoke(input)
        result = graph.invoke(input, config={"callbacks": [my_cb]})
        # Both callbacks fire: [my_cb, AgentSonarCallback()]

    Access the sonar callback via: `graph.sonar`

    Host-safety guarantees:
      * If `AgentSonarCallback(config)` raises for any reason, the
        exception is swallowed, a warning is logged, and `monitor()`
        returns a pass-through wrapper that still exposes the same
        `.invoke`/`.stream`/`.shutdown`/`.sonar` surface. The host
        graph continues to work — it simply runs WITHOUT AgentSonar
        monitoring for the rest of the session.
      * On every `.invoke(...)` call, if merging the sonar callback
        into the user's config fails, the merge is silently dropped
        and the original user config is passed through verbatim.
        Detection degrades; execution never does.

    Alternative: pass `AgentSonarCallback()` directly in your own
    `config={"callbacks": [...]}` list. That gives you full control
    over callback ordering at the cost of having to remember the merge.
    """
    # `AgentSonarCallback.__init__` already uses `build_engine_safely`
    # so bad config won't raise there. The outer try/except is belt
    # and suspenders: if something else in the constructor (the
    # langchain BaseCallbackHandler super-init, a future field, a
    # platform-specific import inside langchain itself) raises, we
    # STILL hand the user back a working graph — just one without
    # AgentSonar wired up.
    try:
        sonar: Any = AgentSonarCallback(config)
    except Exception as exc:
        logger.warning(
            "AgentSonar: monitor() failed to attach callback (%s: %s). "
            "Returning an unmonitored pass-through wrapper so your graph "
            "keeps working. Your application is NOT affected.",
            type(exc).__name__, exc,
        )
        logger.debug("monitor() construction traceback:", exc_info=True)
        sonar = None
    return _MonitoredGraph(graph, sonar)


class _MonitoredGraph:
    """Thin wrapper that injects AgentSonarCallback into every call.

    Host-safety contract: every public method below MUST either
    succeed or delegate directly to the wrapped graph. A failure in
    AgentSonar's code path (merge, callback construction, shutdown)
    must never propagate into the host application.
    """

    def __init__(self, graph: Any, sonar: Any):
        self._graph = graph
        # `sonar` may be None if `monitor()` caught an exception
        # during AgentSonarCallback construction. We keep the
        # wrapper around anyway so the user's `graph.sonar.xxx`
        # calls still hit a predictable attribute, but the invoke
        # path becomes a pure pass-through.
        self.sonar = sonar

    def _merge_config(self, config: dict | None) -> dict | None:
        """Merge sonar callback into config, preserving existing callbacks.

        Never raises. The merge is conservative: we only modify the
        config's `callbacks` slot if it's already shaped like
        something we can safely extend (a list, a tuple, or missing).
        If the user passed something exotic — a single handler, a
        dict, a string — we leave the config alone and let LangGraph
        surface whatever error it would normally surface. The
        alternative (wrapping the exotic value in a list) would
        mask the user's real bug behind AgentSonar, which is worse
        than degrading detection silently for this one call.
        """
        if self.sonar is None:
            return config
        try:
            merged = dict(config) if config else {}
            existing = merged.get("callbacks")
            if existing is None:
                merged["callbacks"] = [self.sonar]
                return merged
            if isinstance(existing, (list, tuple)):
                merged["callbacks"] = list(existing) + [self.sonar]
                return merged
            # Exotic callbacks value — don't touch it. The host's
            # original config flows through verbatim; LangGraph
            # raises its own, clearer error about the user's
            # actual input. AgentSonar just doesn't attach for
            # this call.
            logger.debug(
                "AgentSonar: unexpected callbacks type (%s); "
                "passing user config through without AgentSonar attached",
                type(existing).__name__,
            )
            return config
        except Exception:
            logger.debug(
                "AgentSonar: _merge_config failed; passing through user "
                "config without AgentSonar callback attached",
                exc_info=True,
            )
            return config

    def _safe_merge(self, config: dict | None) -> dict | None:
        """Belt-and-suspenders wrapper around `_merge_config`.

        `_merge_config` already has an internal try/except. This
        outer wrapper guarantees host safety even if the helper
        method itself is broken (monkey-patched, subclass override
        that raises, future refactor bug). If the merge call
        raises for ANY reason, we pass the user's original config
        through untouched — the graph still runs, just without
        AgentSonar attached for this one call.

        Every invoke/stream/ainvoke/astream path funnels through
        this wrapper so there's a single choke point for mid-run
        merge failures.
        """
        try:
            return self._merge_config(config)
        except Exception:
            try:
                logger.debug(
                    "AgentSonar: _merge_config raised unexpectedly; "
                    "passing user config through without AgentSonar attached",
                    exc_info=True,
                )
            except Exception:
                pass
            return config

    def invoke(self, input: Any, config: dict | None = None, **kwargs: Any) -> Any:
        return self._graph.invoke(
            input, config=self._safe_merge(config), **kwargs
        )

    def stream(self, input: Any, config: dict | None = None, **kwargs: Any) -> Any:
        return self._graph.stream(
            input, config=self._safe_merge(config), **kwargs
        )

    async def ainvoke(self, input: Any, config: dict | None = None, **kwargs: Any) -> Any:
        return await self._graph.ainvoke(
            input, config=self._safe_merge(config), **kwargs
        )

    def astream(self, input: Any, config: dict | None = None, **kwargs: Any) -> Any:
        # Not async def — astream is an async generator factory in
        # LangGraph, so we return it directly without awaiting.
        return self._graph.astream(
            input, config=self._safe_merge(config), **kwargs
        )

    def get_summary(self) -> dict:
        """Never raises — returns an empty-but-valid summary if the
        underlying callback is missing or degraded."""
        if self.sonar is None:
            return {
                "total_events": 0, "iteration_count": 0, "edge_counts": {},
                "total_estimated_token_waste": 0, "alerts_raised": 0,
                "alerts": [], "degraded": True,
            }
        try:
            return self.sonar.get_summary()
        except Exception:
            logger.debug(
                "AgentSonar: get_summary raised; returning empty",
                exc_info=True,
            )
            return {
                "total_events": 0, "iteration_count": 0, "edge_counts": {},
                "total_estimated_token_waste": 0, "alerts_raised": 0,
                "alerts": [], "degraded": True,
            }

    def shutdown(self) -> None:
        """Never raises. Shutdown is the worst place to surprise the host."""
        if self.sonar is None:
            return
        try:
            self.sonar.shutdown()
        except Exception:
            logger.debug(
                "AgentSonar: shutdown raised; swallowing",
                exc_info=True,
            )

    def __getattr__(self, name: str) -> Any:
        """Proxy all other attributes to the wrapped graph."""
        return getattr(self._graph, name)
