"""
Shared health-check implementation for every AgentSonar adapter.

`AgentSonarListener` (CrewAI), `AgentSonarCallback` (LangGraph), and
`CustomAdapter` (custom orchestrators) all expose a tiny
`health_check()` method that returns the same canonical dict shape.
This module owns the implementation. Each adapter's `health_check()`
is a one-line delegation here so the safety contract lives in exactly
one place.

Host-safety contract
====================

`_health_check()` NEVER raises. Period. Every internal step that
touches an external object — the engine, the adapter label, the
package version, the engine's summary, a reason string with a
potentially-broken `__str__` — is wrapped in its own try/except.
The whole function is also wrapped in an outer try/except as a
final backstop. The worst case is a fixed-shape "everything is
degraded, reason=internal failure" dict.

Why fail-soft and not fail-hard
-------------------------------

`health_check()` exists for **ops dashboards, readiness probes, and
tests** — places where a thrown exception is far worse than a stale
or partial result. A user calling `sonar.health_check()` from a
Kubernetes liveness handler or an HTTP `/health` endpoint expects a
dict back; a traceback breaks the host. Same prime directive as
`get_summary()` and `shutdown()`: the observer must never crash the
observed.

Output shape
============

Returned dict (snake_case keys, mirroring the TypeScript SDK's
`healthCheck()` shape with TS's camelCase converted to Python style):

  reachable : bool   — always True. Reserved for future remote
                       transports that can flip it to False on
                       connection loss without changing schema.
  version   : str    — installed `agentsonar` version (e.g. "0.4.3").
                       "unknown" only on a catastrophic internal
                       failure.
  adapter   : str    — the adapter label this instance was constructed
                       with ("crewai" / "langgraph" / "custom_python" /
                       custom embedded labels like "oma_sidecar").
  degraded  : bool   — True when the engine is a `_NoOpEngine` /
                       `_LastResortEngine` / anything else that
                       reports `degraded=True` via `get_summary()`.
                       False on a healthy real `DetectionEngine`.
  reason    : str    — ONLY present when `degraded` is True. Human-
                       readable explanation. Sourced from the engine's
                       `degraded_reason` summary field; falls back to
                       a generic message when the engine doesn't
                       provide one.
"""
from __future__ import annotations

from typing import Any

from agentsonar._version import __version__


def _health_check(engine: Any, adapter_label: Any) -> dict:
    """Return the canonical health-snapshot dict for an adapter.

    See module docstring for the output shape. NEVER raises — every
    operation that could fail is wrapped, and the entire body is
    wrapped in a final outer try/except as a backstop.

    Args:
        engine: The adapter's underlying engine. Real `DetectionEngine`,
            `_NoOpEngine`, `_LastResortEngine`, or any object — even a
            broken one. We use duck typing on `.get_summary()` and don't
            care about the concrete class.
        adapter_label: The adapter telemetry string ("crewai", "langgraph",
            "custom_python", etc.). Coerced to a string defensively;
            None or unstringifiable values fall back to "unknown".

    Returns:
        Dict with keys reachable / version / adapter / degraded
        (always present) and reason (only when degraded). See module
        docstring for full schema.
    """
    try:
        # ----- Step 1: package version (string-coerce defensively) -----
        # __version__ is a plain string at module load, but a future
        # PEP-440 dev-version generator or a monkeypatched test fixture
        # could in principle put a non-string here. Guard anyway.
        try:
            version_str = str(__version__)
        except Exception:
            version_str = "unknown"

        # ----- Step 2: adapter label (string-coerce defensively) -----
        # str() on a value with a broken __str__ raises here; we catch
        # and fall back. Same defense for `None` (legitimate input,
        # expressed as "unknown" in the snapshot).
        try:
            if adapter_label is None:
                adapter_str = "unknown"
            else:
                adapter_str = str(adapter_label)
        except Exception:
            adapter_str = "unknown"

        # ----- Step 3: degraded flag + reason (via engine.get_summary) -----
        # Asking the engine for its summary is the universal way to
        # detect degradation: `_NoOpEngine` and `_LastResortEngine` both
        # set `degraded=True` + `degraded_reason=...`; the real
        # `DetectionEngine` omits the keys. Works for any future
        # degraded variant too without modifying this helper.
        is_degraded = False
        reason: str | None = None
        try:
            summary = engine.get_summary()

            # Bool-coerce defensively. summary.get could return a
            # truthy non-bool that bool() handles fine, but a property
            # that raises on __getitem__ would have been caught above.
            try:
                is_degraded = bool(summary.get("degraded", False))
            except Exception:
                # A summary dict whose .get() raises is bizarre but not
                # impossible (proxy-dict subclasses). Treat as degraded.
                is_degraded = True

            # Reason — `str()` is the load-bearing line: a malicious or
            # broken `__str__` on whatever the engine put in
            # `degraded_reason` could raise. Wrap independently so the
            # `degraded` bool is preserved even if the reason coercion
            # fails.
            try:
                raw_reason = summary.get("degraded_reason")
                if raw_reason is not None:
                    reason = str(raw_reason)
            except Exception:
                reason = None
        except Exception:
            # The engine itself failed on `.get_summary()`. That IS a
            # degraded condition by definition — a healthy engine
            # responds. Fall through with `is_degraded=True`.
            is_degraded = True

        result: dict = {
            "reachable": True,
            "version": version_str,
            "adapter": adapter_str,
            "degraded": is_degraded,
        }
        if is_degraded:
            # Always emit a reason key when degraded so consumers don't
            # have to do `result.get("reason", "<unknown>")`. Empty /
            # missing engine reasons get a generic fallback.
            result["reason"] = reason or "engine running in degraded (no-op) mode"
        return result

    except Exception:
        # Outer backstop: somehow an exception escaped every interior
        # guard (shouldn't be possible, but the prime directive is
        # "never raises", not "almost never raises"). Return a literal
        # safe dict with no engine touches.
        return {
            "reachable": True,
            "version": "unknown",
            "adapter": "unknown",
            "degraded": True,
            "reason": "health_check internal failure",
        }
