"""
CrewAI adapter — translates CrewAI events into generic InteractionEvents
for the framework-agnostic detection engine.

The CrewAI dependency is OPTIONAL. If crewai isn't installed, the class
is still importable (so `from agentsonar import AgentSonarListener` never
breaks) but instantiation raises a clear RuntimeError telling the user
to `pip install agentsonar[crewai]`.

Alert output is handled by SonarLogger (JSONL file + stderr). This
listener only translates CrewAI events and feeds them to the engine.

Usage (with crewai installed):
    from agentsonar import AgentSonarListener
    sonar = AgentSonarListener()
    # ...run your crew normally. Detection happens automatically.
"""
from __future__ import annotations

import json
import logging
import sys
import time
from typing import Any

from agentsonar._core.models import InteractionEvent
from agentsonar._integrations._health import _health_check
from agentsonar._integrations._safe_engine import build_engine_safely

logger = logging.getLogger(__name__)

# Try to import CrewAI's BaseEventListener. If it isn't installed, fall
# back to a placeholder base class so importing this module doesn't
# raise — we raise a nice error at instantiation time instead.
try:
    from crewai.events.base_event_listener import BaseEventListener
    from crewai.events.event_types import (
        CrewKickoffCompletedEvent,
        ToolUsageStartedEvent,
    )

    _HAS_CREWAI = True
except ImportError:
    BaseEventListener = object  # type: ignore[assignment,misc]
    CrewKickoffCompletedEvent = None  # type: ignore[assignment]
    ToolUsageStartedEvent = None  # type: ignore[assignment]
    _HAS_CREWAI = False


class AgentSonarListener(BaseEventListener):  # type: ignore[misc]
    """CrewAI event listener for AgentSonar coordination detection.

    Hooks into CrewAI's event bus to observe delegation events and feed
    them into the framework-agnostic DetectionEngine. Detection happens
    automatically as your crew runs — no configuration required.

    Two lines to use:
        from agentsonar import AgentSonarListener
        sonar = AgentSonarListener()
        # ...crew runs normally. Alerts stream to stderr and to disk.

    Requires the `crewai` extra:
        pip install agentsonar[crewai]
    """

    def __init__(self, config: dict | None = None):
        if not _HAS_CREWAI:
            raise RuntimeError(
                "AgentSonarListener requires CrewAI to be installed. "
                "Install it with:\n"
                "    pip install agentsonar[crewai]\n"
                "or\n"
                "    pip install crewai"
            )
        # Guard against duplicate listener registration (bug 20). If
        # CrewAI or a test harness calls `setup_listeners` twice on
        # the same instance, we'd end up with two handlers firing on
        # every event — `engine.ingest` would see each event twice,
        # double-counting edges.
        self._listeners_registered = False
        # Track every (event_type, handler) we register on the bus so
        # `shutdown()` can unregister them. Required for hosts that
        # construct multiple AgentSonarListeners over the lifetime of
        # the process (long-running web servers, test suites,
        # notebooks): without unregistration, the previous listener's
        # closed-over engine continues receiving events from the bus,
        # double-counting edges and pumping into shut-down loggers.
        self._registered_handlers: list[tuple[type, Any]] = []
        # Construct the detection engine first. This ordering is
        # FORCED by CrewAI's API: `super().__init__()` may itself
        # call `self.setup_listeners(bus)` synchronously, which
        # references `self.engine` — so the engine must exist
        # before super runs. If we swapped the order, super's
        # setup_listeners would hit `AttributeError: no attribute
        # 'engine'`.
        #
        # Host-safety seam: `build_engine_safely` never raises. If
        # the real `DetectionEngine` constructor fails (bad user
        # config, disk/permission errors, platform quirks), we get
        # back a silent `_NoOpEngine` and continue. The user's
        # `sonar = AgentSonarListener()` line always succeeds, and
        # their crew still runs — AgentSonar just stops detecting
        # coordination failures for this session. A warning is
        # logged at the `agentsonar` logger.
        # Telemetry/health-check label. Hardcoded for the framework
        # adapter — `health_check()` reads it back so dashboards know
        # which adapter is reporting.
        self._adapter_label = "crewai"
        self.engine = build_engine_safely(config, adapter=self._adapter_label)
        try:
            super().__init__()
        except Exception:
            # super().__init__() is crewai's BaseEventListener
            # constructor — it calls self.setup_listeners(bus) as
            # a side-effect. If it raises, we're in a weird state
            # where listeners MAY have been registered against a
            # half-built engine. We cannot let this raise into the
            # user's `sonar = AgentSonarListener()` line — that
            # would crash the host crew at construction time.
            #
            # Rollback: close the engine so its SonarLogger releases
            # file handles. Stale handlers stay registered but are
            # safe — `build_engine_safely` always returns an engine
            # whose `ingest()` is a no-op after shutdown(), and
            # every handler below wraps `self.engine.ingest(...)`
            # in a try/except at the handler level.
            logger.warning(
                "AgentSonar: CrewAI BaseEventListener super().__init__ "
                "raised during AgentSonarListener setup. The detection "
                "engine has been closed — your crew will continue "
                "normally but AgentSonar will not detect coordination "
                "failures for this session.",
                exc_info=True,
            )
            try:
                self.engine.shutdown()
            except Exception:
                pass
            # Do NOT re-raise: the whole point of this block is to
            # keep the host crew alive even when our integration
            # layer trips. We have already logged the degradation;
            # the listener instance is now a silent-observer stub
            # that will no-op on every event.
            from agentsonar._core.noop_engine import _NoOpEngine
            self.engine = _NoOpEngine(
                reason="CrewAI BaseEventListener setup failed",
            )

    def setup_listeners(self, crewai_event_bus: Any) -> None:
        """Wire up CrewAI event handlers. Called automatically by CrewAI."""
        # Bug 20 guard: if already registered on a bus, don't register
        # again. CrewAI's event bus treats handlers as ordinary
        # callbacks — every registration adds another firing, which
        # would double-count events on every ingest.
        if self._listeners_registered:
            return
        self._listeners_registered = True

        # Save the bus reference so post-init methods (`shutdown`,
        # `_drain_bus_safely`) can interact with it. CrewAI passes the
        # bus into `setup_listeners` and nowhere else; without this,
        # those methods would have to import the global singleton
        # again from `agentsonar.events`, creating an opportunity for
        # the user to swap buses behind our back.
        self._bus = crewai_event_bus

        # Defensively ensure `_registered_handlers` exists. Normal
        # construction via `AgentSonarListener.__init__` initializes
        # this on line 89, but tests / subclassers occasionally call
        # `setup_listeners` on an object that bypassed __init__.
        # Without this guard, the `.append()` calls below would
        # AttributeError.
        if not hasattr(self, "_registered_handlers"):
            self._registered_handlers = []

        @crewai_event_bus.on(ToolUsageStartedEvent)
        def on_tool_start(source: Any, event: Any) -> None:
            # Guard: ignore events arriving during Python interpreter shutdown
            if sys.is_finalizing():
                return
            try:
                tool_name = getattr(event, "tool_name", "") or ""
                if "delegate" not in tool_name.lower():
                    return

                args = getattr(event, "tool_args", {}) or {}
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except (json.JSONDecodeError, TypeError):
                        args = {}

                source_agent = (getattr(event, "agent_role", "unknown") or "unknown").lower()
                target_agent = (args.get("coworker", "unknown") or "unknown").lower()

                interaction = InteractionEvent(
                    source_agent=source_agent,
                    target_agent=target_agent,
                    timestamp=time.time(),
                )

                # Engine handles detection + logging via SonarLogger
                self.engine.ingest(interaction)
            except Exception:
                logger.debug("AgentSonar failed during tool event processing", exc_info=True)

        # Track for shutdown unregistration. The decorator returns the
        # unmodified handler (event_bus.py:270 `return handler`), so we
        # can capture it from the local scope after `@bus.on(...)` runs.
        self._registered_handlers.append((ToolUsageStartedEvent, on_tool_start))

        @crewai_event_bus.on(CrewKickoffCompletedEvent)
        def on_crew_end(source: Any, event: Any) -> None:
            # Guard: ignore events arriving during Python interpreter shutdown
            if sys.is_finalizing():
                return
            try:
                self.engine.increment_iteration()
                # shutdown() logs the summary banner and closes the log file
                self.engine.shutdown()
            except Exception:
                logger.debug("AgentSonar failed during crew completion summary", exc_info=True)

        self._registered_handlers.append((CrewKickoffCompletedEvent, on_crew_end))

    def _drain_bus_safely(self) -> None:
        """Block until CrewAI's bus thread-pool finishes pending handlers.

        `crewai_event_bus.emit()` dispatches sync handlers to a
        ThreadPoolExecutor and returns a Future immediately. Reading
        engine state right after a burst of emits races those handlers
        — playground / test code that introspects the listener
        between emits sees stale counts. `flush()` blocks until the
        pool drains, so any caller that reads `get_summary()` /
        `health_check()` gets a consistent snapshot.

        In production-shaped CrewAI runs this rarely matters because
        emits happen between LLM calls (slow) and `crew.kickoff()`'s
        teardown invokes flush implicitly. The auto-drain matters for
        readiness probes, tests, and tight introspection loops.

        Never raises: flush failure is a UX nicety, not a correctness
        requirement; we'd rather return possibly-stale counts than
        propagate an exception out of a `get_summary()` call.
        """
        bus = getattr(self, "_bus", None)
        if bus is None:
            return
        try:
            bus.flush()
        except Exception:
            logger.debug(
                "AgentSonar: bus.flush() raised; reading possibly-stale state",
                exc_info=True,
            )

    def get_summary(self) -> dict:
        """Return the detection engine summary. Never raises.

        Auto-drains the CrewAI bus first so callers see the engine's
        view AFTER all pending sync handlers have processed. See
        `_drain_bus_safely` for context.
        """
        self._drain_bus_safely()
        try:
            return self.engine.get_summary()
        except Exception:
            logger.debug(
                "AgentSonar: listener get_summary raised; returning empty",
                exc_info=True,
            )
            return {
                "total_events": 0, "iteration_count": 0, "edge_counts": {},
                "total_estimated_token_waste": 0, "alerts_raised": 0,
                "alerts": [], "degraded": True,
            }

    def health_check(self) -> dict:
        """Return a small health snapshot of this listener. Never raises.

        Auto-drains the CrewAI bus before reading engine state for the
        same reason `get_summary` does — readiness probes deserve a
        consistent snapshot.

        Mirrors `CustomAdapter.health_check()` and the TypeScript SDK's
        `AgentSonar.healthCheck()`. See
        `agentsonar._integrations._health._health_check` for the full
        output schema and host-safety guarantees.
        """
        self._drain_bus_safely()
        # `getattr` fallback covers a hypothetical case where __init__
        # didn't reach the line that sets `_adapter_label` (e.g. a
        # subclass overrode __init__ without calling super). Defensive
        # but cheap.
        return _health_check(self.engine, getattr(self, "_adapter_label", "crewai"))

    def shutdown(self) -> None:
        """Log session end, close the logger, and detach from the bus.

        Safe to call multiple times. Never raises — shutdown() is the
        last thing the host calls, and a crash here would turn a
        successful crew run into a confusing traceback at teardown.

        Order of operations:

          1. Unregister this listener's handlers from the CrewAI event
             bus. Without this, hosts that construct multiple
             `AgentSonarListener` instances over the lifetime of a
             process (test suites, notebooks, long-running web servers)
             would have every old listener's handler keep firing on
             every emit — pumping events into shut-down engines and
             double-counting edges in the active listener.

             Each handler's removal is wrapped individually so a single
             failure (e.g. CrewAI changes its `off()` API in a future
             version) doesn't prevent the others from being unregistered.

          2. `engine.shutdown()` to flush reports and close the logger.
        """
        # 1. Detach from the bus.
        bus = getattr(self, "_bus", None)
        registered = getattr(self, "_registered_handlers", None)
        if bus is not None and registered:
            for evt_type, handler in registered:
                try:
                    bus.off(evt_type, handler)
                except Exception:
                    logger.debug(
                        "AgentSonar: failed to unregister %s handler from "
                        "CrewAI bus during shutdown",
                        getattr(evt_type, "__name__", evt_type),
                        exc_info=True,
                    )
            try:
                registered.clear()
            except Exception:
                pass
            # Reset the registered flag so a future `setup_listeners`
            # call (e.g. if the same instance is reattached, rare but
            # possible in test harnesses) re-registers cleanly.
            self._listeners_registered = False

        # 2. Flush reports + close logger. Always runs even if step 1
        #    failed — engine cleanup is the more important of the two.
        try:
            self.engine.shutdown()
        except Exception:
            logger.debug(
                "AgentSonar: listener shutdown raised; swallowing",
                exc_info=True,
            )
