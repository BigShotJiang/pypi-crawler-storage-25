"""
`agentsonar reset-session` implementation.

Clears state.pkl (and last_hook_at) for one or all Claude Code session
trees. The timeline.jsonl audit trail is preserved.

Use cases:
    - Rate-limit circuit-breaker is stuck open from earlier activity;
      reset to start with a clean window.
    - Iterating on config; want to retest from scratch without the
      stale state.pkl restoring old detector internals.
    - General hygiene after long-running test sessions.

Files cleared per session:
    state.pkl              (the bounded detection buffer)
    last_hook_at           (the inactivity-sweep marker)

Files preserved:
    timeline.jsonl         (canonical event record; append-only audit)
    subagent_types.json    (registry; doesn't affect detection)
    telemetry_fired        (telemetry one-shot marker; OK to keep)
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from agentsonar._integrations.claude.adapter import ENV_ROOT_DIR, _DEFAULT_ROOT_DIR


_STATE_FILES = ("state.pkl", "last_hook_at")


def _root_dir() -> Path:
    try:
        override = os.environ.get(ENV_ROOT_DIR)
        if override and override.strip():
            return Path(override.strip())
    except Exception:
        pass
    return _DEFAULT_ROOT_DIR


def _list_session_dirs(sessions_root: Path) -> list[Path]:
    """Return non-archived session directories, newest first."""
    if not sessions_root.exists():
        return []
    out = []
    try:
        for entry in sessions_root.iterdir():
            if entry.is_dir() and entry.name != "archived":
                out.append(entry)
    except Exception:
        return []
    try:
        out.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    except Exception:
        pass
    return out


def _clear_session(session_dir: Path, dry_run: bool) -> tuple[int, int]:
    """Remove derived state files from `session_dir`. Returns
    (cleared_count, skipped_count). Defensive: missing files are
    treated as already-cleared; permission errors print + skip."""
    cleared = 0
    skipped = 0
    for name in _STATE_FILES:
        p = session_dir / name
        if not p.exists():
            continue
        if dry_run:
            print(f"  would clear: {p}")
            cleared += 1
            continue
        try:
            p.unlink()
            print(f"  cleared: {p}")
            cleared += 1
        except Exception as exc:
            print(f"  skip {p}: {type(exc).__name__}: {exc}", file=sys.stderr)
            skipped += 1
    return cleared, skipped


def reset_session(
    session_id: str | None = None,
    reset_all: bool = False,
    dry_run: bool = False,
) -> int:
    """Reset one or all session trees. Returns 0 on success, 1 on
    user error (e.g. no sessions found), 2 on I/O failure."""
    root = _root_dir()
    sessions_root = root / "sessions"

    if not sessions_root.exists():
        print(
            f"agentsonar: no sessions directory at {sessions_root} (nothing to reset)",
            file=sys.stderr,
        )
        return 0

    targets: list[Path]
    if session_id:
        target = sessions_root / session_id
        if not target.exists():
            print(
                f"agentsonar: session not found: {target}",
                file=sys.stderr,
            )
            return 1
        targets = [target]
    elif reset_all:
        targets = _list_session_dirs(sessions_root)
        if not targets:
            print("agentsonar: no active sessions found.")
            return 0
    else:
        # Default: most recent session
        all_sessions = _list_session_dirs(sessions_root)
        if not all_sessions:
            print("agentsonar: no active sessions found.")
            return 0
        targets = [all_sessions[0]]

    label = "would clear" if dry_run else "clearing"
    print(f"agentsonar: {label} {len(targets)} session(s) under {sessions_root}")
    total_cleared = 0
    total_skipped = 0
    for session_dir in targets:
        print(f"\nSession: {session_dir.name}")
        c, s = _clear_session(session_dir, dry_run)
        total_cleared += c
        total_skipped += s

    print(f"\nagentsonar: {total_cleared} file(s) {'would be ' if dry_run else ''}cleared, "
          f"{total_skipped} skipped due to errors")
    return 1 if total_skipped > 0 and not dry_run else 0


__all__ = ["reset_session"]
