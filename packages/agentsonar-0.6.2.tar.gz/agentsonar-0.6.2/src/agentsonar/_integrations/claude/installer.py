"""
`.claude/settings.json` installer for the Claude Code adapter.

Hand-editing JSON by users is brittle on Windows (Git Bash + PowerShell
PATH differences, venv activation gotchas, settings template that may
or may not pick up `agentsonar` on PATH). This module writes the right
settings.json in one command, merge-safe.

Public surface:
    install(target_path, *, force, dry_run) -> int

Driven by the `agentsonar install-claude-hooks` CLI subcommand.

The emitted command is `python -m agentsonar claude-code-hook <event>`
NOT the absolute `sys.executable` path. The install machine's venv
interpreter path will not match the user's runtime venv; `python` on
PATH at hook-fire time is the most portable form. On Windows, Git
Bash finds `python` if Python is installed at all.

Merge semantics:
  - AgentSonar entries (command substring `agentsonar claude-code-hook`
    OR `-m agentsonar claude-code-hook`) are REPLACED with the fresh
    command.
  - Non-AgentSonar entries are PRESERVED.
  - Top-level non-hook keys (e.g. `mcp`, `customServers`) are PRESERVED.
  - Without --force, the install aborts with exit 1 if a non-AgentSonar
    entry has the same event/matcher/type combination as the new one.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any


# Stop / SubagentStop hooks are tagged with no matcher (they fire on
# assistant turn / subagent end); PreToolUse / PostToolUse use matcher
# "*" to fire on every tool call.
_AGENTSONAR_HOOK_EVENTS_WITH_MATCHER: tuple[str, ...] = (
    "PreToolUse",
    "PostToolUse",
)
_AGENTSONAR_HOOK_EVENTS_NO_MATCHER: tuple[str, ...] = (
    "Stop",
    "SubagentStop",
)

_HOOK_TIMEOUT_MS = 5000

# Tags identifying a command as an AgentSonar hook for merge detection.
# Recognized in both old (`agentsonar claude-code-hook`) and new
# (`python -m agentsonar claude-code-hook`) forms.
_AGENTSONAR_TAGS: tuple[str, ...] = (
    "agentsonar claude-code-hook",
    "-m agentsonar claude-code-hook",
)


def _build_hook_command(event: str) -> str:
    """Build the command string for a Claude Code hook event.

    Always emits `python -m agentsonar` form for cross-shell portability:
      - The install machine's venv may not match the user's runtime
      - Git Bash on Windows finds `python` on PATH cross-shell
      - boxd / OEM Docker images put `python` on PATH automatically
    """
    return f"python -m agentsonar claude-code-hook {event}"


def _build_agentsonar_hooks_block() -> dict:
    block: dict[str, list[dict]] = {}
    for event in _AGENTSONAR_HOOK_EVENTS_WITH_MATCHER:
        block[event] = [{
            "matcher": "*",
            "hooks": [{
                "type": "command",
                "command": _build_hook_command(event),
                "timeout": _HOOK_TIMEOUT_MS,
            }],
        }]
    for event in _AGENTSONAR_HOOK_EVENTS_NO_MATCHER:
        block[event] = [{
            "hooks": [{
                "type": "command",
                "command": _build_hook_command(event),
                "timeout": _HOOK_TIMEOUT_MS,
            }],
        }]
    return block


def _is_agentsonar_command(cmd) -> bool:
    """Detect whether a command string is an AgentSonar hook (any form)."""
    if not isinstance(cmd, str):
        return False
    return any(tag in cmd for tag in _AGENTSONAR_TAGS)


def _has_conflict(existing_entries: list, event: str) -> bool:
    """A conflict exists when a non-AgentSonar entry on the same event
    uses matcher '*' (same scope as us). User-registered matcher-scoped
    hooks on different patterns don't collide with AgentSonar."""
    for entry in existing_entries:
        if not isinstance(entry, dict):
            continue
        inner = entry.get("hooks", [])
        if not isinstance(inner, list):
            continue
        for inner_hook in inner:
            if not isinstance(inner_hook, dict):
                continue
            cmd = inner_hook.get("command")
            if isinstance(cmd, str) and not _is_agentsonar_command(cmd):
                matcher = entry.get("matcher")
                if matcher == "*" or matcher is None:
                    return True
    return False


def _merge_hooks(existing: dict | None, new_block: dict) -> dict:
    """Merge AgentSonar's hooks into an existing settings dict.

    Preserves every non-hooks top-level key. For each event in
    `new_block`: removes existing AgentSonar entries (no double-register
    on repeat installs), appends the new ones. Events outside
    `new_block` pass through verbatim.

    Returns a fresh dict (does not mutate input).
    """
    out: dict[str, Any] = {}
    if isinstance(existing, dict):
        for k, v in existing.items():
            out[k] = v
    existing_hooks = out.get("hooks")
    if not isinstance(existing_hooks, dict):
        existing_hooks = {}
    merged_hooks = dict(existing_hooks)

    for event, new_entries in new_block.items():
        existing_entries = merged_hooks.get(event, [])
        if not isinstance(existing_entries, list):
            existing_entries = []
        kept: list[dict] = []
        for entry in existing_entries:
            if not isinstance(entry, dict):
                continue
            inner = entry.get("hooks", [])
            if not isinstance(inner, list):
                kept.append(entry)
                continue
            non_as_inner = [
                h for h in inner
                if isinstance(h, dict)
                and not _is_agentsonar_command(h.get("command"))
            ]
            if non_as_inner:
                entry_copy = dict(entry)
                entry_copy["hooks"] = non_as_inner
                kept.append(entry_copy)
        kept.extend(new_entries)
        merged_hooks[event] = kept

    out["hooks"] = merged_hooks
    return out


def _resolve_target_path(target_path) -> Path:
    """Resolve where to write `.claude/settings.json`.

    Order:
      1. Explicit `--path` argument.
      2. $CLAUDE_CONFIG_DIR/settings.json.
      3. ./.claude/settings.json.
    """
    if target_path:
        return Path(str(target_path)).expanduser().resolve()
    try:
        env_dir = os.environ.get("CLAUDE_CONFIG_DIR")
        if env_dir and env_dir.strip():
            return Path(env_dir.strip()).expanduser().resolve() / "settings.json"
    except Exception:
        pass
    return (Path.cwd() / ".claude" / "settings.json").resolve()


def _atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_fd, tmp_name = tempfile.mkstemp(
        dir=str(path.parent), prefix=path.name + ".", suffix=".tmp"
    )
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp_name, path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except Exception:
            pass
        raise


def install(
    target_path=None,
    *,
    force: bool = False,
    dry_run: bool = False,
) -> int:
    """Write or merge AgentSonar hooks into `.claude/settings.json`.

    Returns:
        0 on success (or dry-run preview).
        1 on conflict-without-force.
        2 on I/O or JSON parse failure.

    Never raises. Prints status / preview to stdout.
    """
    target = _resolve_target_path(target_path)

    existing: dict | None = None
    if target.exists():
        try:
            raw = target.read_text(encoding="utf-8")
            existing = json.loads(raw) if raw.strip() else {}
            if not isinstance(existing, dict):
                print(
                    f"agentsonar: existing settings at {target} is not a "
                    f"JSON object (got {type(existing).__name__}); aborting. "
                    f"Use --force to overwrite.",
                    file=sys.stderr,
                )
                if not force:
                    return 2
                existing = {}
        except Exception as exc:
            print(
                f"agentsonar: could not parse {target}: {type(exc).__name__}: {exc}",
                file=sys.stderr,
            )
            if not force:
                print(
                    "Use --force to discard the existing file and write fresh hooks.",
                    file=sys.stderr,
                )
                return 2
            existing = {}

    new_block = _build_agentsonar_hooks_block()

    if not force and isinstance(existing, dict):
        existing_hooks = existing.get("hooks")
        if isinstance(existing_hooks, dict):
            for event in new_block:
                event_entries = existing_hooks.get(event, [])
                if isinstance(event_entries, list) and _has_conflict(event_entries, event):
                    print(
                        f"agentsonar: existing non-AgentSonar hook on "
                        f"event '{event}' with matcher '*' at {target}.\n"
                        f"  Re-run with --force to overwrite, or hand-edit "
                        f"the file to use a more specific matcher.",
                        file=sys.stderr,
                    )
                    return 1

    merged = _merge_hooks(existing, new_block)
    rendered = json.dumps(merged, indent=2, sort_keys=False) + "\n"

    if dry_run:
        print(f"agentsonar: dry-run; would write to {target}")
        print("---")
        print(rendered.rstrip())
        print("---")
        return 0

    try:
        _atomic_write_text(target, rendered)
    except Exception as exc:
        print(
            f"agentsonar: could not write {target}: {type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        return 2

    print(f"agentsonar: installed Claude Code hooks at {target}")
    print(f"  command form: {_build_hook_command('PreToolUse')!r}")
    return 0


__all__ = ["install"]
