"""
Cross-platform persistence primitives: file lock + atomic write.

Used by adapters that need to coordinate cross-process state (Claude
Code today, future hook-driven adapters tomorrow). Universal: zero
adapter knowledge in this module.
"""
from __future__ import annotations

import contextlib
import os
import tempfile
import time
import uuid
from pathlib import Path


def is_windows() -> bool:
    return os.name == "nt"


@contextlib.contextmanager
def file_lock(lock_path: Path, timeout: float):
    """Acquire an exclusive cross-process file lock with timeout.

    fcntl.flock on POSIX, msvcrt.locking on Windows. Both release the
    lock automatically when the holding process exits.

    Raises TimeoutError if the lock can't be acquired within `timeout`
    seconds. Callers catch and degrade gracefully.
    """
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    fh = open(lock_path, "a+b")
    deadline = time.time() + max(0.0, timeout)

    try:
        if is_windows():
            import msvcrt
            while True:
                try:
                    msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    if time.time() >= deadline:
                        raise TimeoutError(
                            f"could not acquire lock {lock_path} within {timeout:.2f}s"
                        )
                    time.sleep(0.025)
        else:
            import fcntl
            while True:
                try:
                    fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except OSError:
                    if time.time() >= deadline:
                        raise TimeoutError(
                            f"could not acquire lock {lock_path} within {timeout:.2f}s"
                        )
                    time.sleep(0.025)
        try:
            yield fh
        finally:
            try:
                if is_windows():
                    import msvcrt
                    try:
                        fh.seek(0)
                    except Exception:
                        pass
                    try:
                        msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
                    except Exception:
                        pass
                else:
                    import fcntl
                    try:
                        fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
                    except Exception:
                        pass
            except Exception:
                pass
    finally:
        try:
            fh.close()
        except Exception:
            pass


def atomic_write_bytes(path: Path, payload: bytes) -> None:
    """Write via temp file + os.replace. Atomic rename guarantees
    readers see old-or-new, never half-written. No fsync (the rename
    is the safety; fsync would add ~2-3ms on Windows for no benefit).

    Windows note: os.replace uses MoveFileEx which is "usually
    atomic" on the same NTFS volume; for ~5KB-1MB files on local
    disk the failure window is negligible.
    """
    parent = path.parent
    if not parent.exists():
        parent.mkdir(parents=True, exist_ok=True)
    tmp_suffix = f".tmp.{os.getpid()}.{uuid.uuid4().hex[:8]}"
    tmp_path = path.with_name(path.name + tmp_suffix)
    try:
        with open(tmp_path, "wb") as f:
            f.write(payload)
        os.replace(tmp_path, path)
    except Exception:
        try:
            tmp_path.unlink()
        except Exception:
            pass
        raise


def atomic_write_text(path: Path, text: str) -> None:
    atomic_write_bytes(path, text.encode("utf-8"))


__all__ = [
    "is_windows",
    "file_lock",
    "atomic_write_bytes",
    "atomic_write_text",
]
