"""
Universal node-type classification for coordination graph nodes.

The detection engine consumes opaque source_agent / target_agent
strings from every adapter (CrewAI, LangGraph, custom orchestrator,
Claude Code, anything future). For the report to render meaningfully,
each node needs a type: is it an agent, a tool call, an MCP call,
a subagent-spawn signal, or a terminal sentinel?

This module owns the classification. It's universal: every adapter
gets the same answer from the same function, no duplication.

Convention-based, not list-based
================================

The TOOL classification recognizes a STRUCTURAL pattern, not a list
of specific tool names. The contract:

    <CapitalizedAlnumName>:<identifier>     -> TOOL

Examples that match automatically (no code change required):
    Read:/src/foo.py            (Claude Code, shipped)
    TodoWrite:fp123             (Claude Code, shipped, never explicitly
                                 added to any list)
    BashOutput:fp456            (same)
    NewToolAnthropicShipsLater  (future, works automatically)
    LangChainSpecificTool:fp    (future LangGraph + tool callbacks)

The five literal/prefix matches (rules 1-5 below) are AgentSonar's
universal naming contract with adapters. They're locked by upstream
specs and won't change month-to-month.

The classifier is pure (no side effects), defensive (never raises),
and dependency-free (no imports outside the standard library).
"""
from __future__ import annotations

from enum import Enum
from typing import Iterable


class NodeType(str, Enum):
    """Discrete classification of every node that lands in the
    coordination graph.

    String-enum so the value serializes as a JSON string for free,
    matching the existing FailureClass / AlertSeverity pattern in
    schema.py.
    """

    AGENT = "agent"
    TOOL = "tool"
    MCP = "mcp"
    TASK_SPAWN = "task_spawn"
    SENTINEL = "sentinel"


# Sentinel and agent literals: hardcoded because they ARE the protocol.
# A future change here is a schema-level change, not a tool-list edit.
_SENTINEL_LITERALS: frozenset[str] = frozenset({"session_exit"})
_AGENT_LITERALS: frozenset[str] = frozenset({"main"})
_AGENT_PREFIXES: tuple[str, ...] = ("subagent_",)

# Adapter contract prefixes: stable, locked by upstream specs.
_MCP_PREFIX: str = "mcp__"
# Anthropic renamed the subagent spawn tool from `Task` to `Agent` in
# late 2025. Both prefixes are recognized so adapters built against
# either generation produce the same classification.
_TASK_SPAWN_PREFIXES: tuple[str, ...] = ("Task_spawn:", "Agent_spawn:")


def classify_node(name) -> NodeType:
    """Classify a graph node by structural name pattern.

    Rules in order (first match wins):

      1. ``session_exit`` literal              -> SENTINEL
      2. ``main`` literal                      -> AGENT
      3. ``subagent_<id>`` prefix              -> AGENT
      4. ``mcp__<server>__<tool>[:<id>]``      -> MCP
      5. ``Task_spawn:<id>`` or ``Agent_spawn:<id>`` -> TASK_SPAWN
         (Anthropic renamed Task -> Agent; both prefixes are accepted.)
      6. ``<CapitalizedAlnumName>:<id>``       -> TOOL
      7. Anything else (bare names, etc.)      -> AGENT (default)

    Rule 6 is the load-bearing one: convention-based, not a list.
    Any adapter that emits a node name shaped like
    ``CapitalizedName:identifier`` classifies as TOOL automatically.
    No hardcoded tool inventory to maintain. New Claude Code tools,
    future MCP servers, future LangGraph tool-callback edges all
    work without touching this function.

    Trade-off: a multi-agent adapter that emits a capitalized agent
    name with a colon (e.g. ``PlannerAgent:task-123``) would falsely
    classify as TOOL. Mitigation: adapters that want AGENT
    classification should use plain names without colons. No
    shipped adapter today does the colon-in-agent-name thing, so
    no regression.

    Args:
        name: The node name string. Defensive against None,
            non-strings, empty strings, and other malformed inputs;
            all degrade to AGENT.

    Returns:
        The classified ``NodeType``. Never raises.
    """
    if not isinstance(name, str) or not name:
        return NodeType.AGENT

    if name in _SENTINEL_LITERALS:
        return NodeType.SENTINEL

    if name in _AGENT_LITERALS:
        return NodeType.AGENT

    for prefix in _AGENT_PREFIXES:
        if name.startswith(prefix):
            return NodeType.AGENT

    if name.startswith(_MCP_PREFIX):
        return NodeType.MCP

    for prefix in _TASK_SPAWN_PREFIXES:
        if name.startswith(prefix):
            return NodeType.TASK_SPAWN

    # Rule 6: generic tool-call convention. A capitalized alphanumeric
    # head followed by a colon classifies as TOOL.
    if ":" in name:
        head = name.split(":", 1)[0]
        if (
            head
            and head[0].isalpha()
            and head[0].isupper()
            and all(ch.isalnum() or ch == "_" for ch in head)
        ):
            return NodeType.TOOL

    return NodeType.AGENT


def partition_nodes(names: Iterable) -> dict[NodeType, tuple[str, ...]]:
    """Group node names by NodeType.

    Preserves first-seen order within each bucket. Deduplicates per
    bucket (a node appearing twice in ``names`` lands once in its
    bucket). Returns a dict; missing keys mean empty buckets so
    callers should use ``.get(NodeType.TOOL, ())`` rather than
    raw ``[NodeType.TOOL]`` indexing.

    Used by the engine's event builders to populate the typed
    ``Topology`` fields without each builder repeating the
    classification logic.

    Defensive: non-iterable input returns an empty dict; bad
    individual entries (non-strings) degrade to AGENT via
    ``classify_node``.
    """
    out: dict[NodeType, list[str]] = {}
    seen: dict[NodeType, set[str]] = {}
    try:
        iterator = iter(names)
    except Exception:
        return {}

    for raw in iterator:
        try:
            node_type = classify_node(raw)
            key = raw if isinstance(raw, str) else ""
            bucket = out.setdefault(node_type, [])
            seen_for_type = seen.setdefault(node_type, set())
            if key not in seen_for_type:
                seen_for_type.add(key)
                bucket.append(key)
        except Exception:
            continue

    return {t: tuple(items) for t, items in out.items()}


__all__ = ["NodeType", "classify_node", "partition_nodes"]
