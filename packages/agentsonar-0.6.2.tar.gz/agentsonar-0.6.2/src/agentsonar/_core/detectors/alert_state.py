"""
Layer 4: AlertStateManager — O(1) alert dedup / state machine.

Progressive alert lifecycle with hysteresis recovery. Separated from the
PeriodicSCCAnalyzer (Layer 5) because they have nothing to do with each
other — one manages alert state, the other runs backup SCC sweeps.
"""
from __future__ import annotations

from dataclasses import dataclass

from agentsonar._core.models import Alert


@dataclass
class _TrackedAlert:
    fingerprint: tuple
    state: str                      # "ACTIVE", "ESCALATED", "RESOLVED"
    pattern: str                    # "cycle", "edge_anomaly", "scc_cycle"
    current_rotations: int = 0
    last_alert_rotations: int = 0
    last_alert_time: float = 0.0
    last_activity_time: float = 0.0
    created_at: float = 0.0
    alert_count: int = 0


class AlertStateManager:
    """Progressive alert state machine with hysteresis recovery.

    Tracks each detected anomaly by fingerprint and manages transitions:
      (new) → ACTIVE (WARNING) → ESCALATED (CRITICAL) → RESOLVED (INFO)
                                         ↑ re-alerts every N rotations
      RESOLVED → ACTIVE on regression

    Fast-path CRITICAL on first detection:
      If the FIRST time a fingerprint is seen the rotation count is
      already at or past `critical_threshold`, the state machine skips
      the WARNING-then-CRITICAL ratchet and emits CRITICAL directly,
      transitioning straight to ESCALATED. This handles batch / static-
      graph scenarios (OMA dependsOn DAGs, CrewAI hierarchical with many
      delegations in one go) where the cycle is detected only ONCE —
      without the fast path, those scenarios would never reach CRITICAL
      because there's no second ingest later for the state machine to
      escalate on.

    Threshold semantics (read carefully — common source of off-by-one
    confusion):

      `warning_threshold=5` means WARNING fires AT rotation 5 — i.e. when
      the rotation count REACHES 5, not after 5 rotations have completed
      and a 6th is starting. Code is `rotations >= warning_threshold`.
      So `=5` triggers ON the 5th rotation. Same applies to
      `critical_threshold`.

      Mental model: the threshold IS the trigger value, not the number
      of rotations you tolerate before the next one trips. If you want
      to allow 5 rotations to pass cleanly and trip on the 6th, set
      the threshold to 6.

      This matches LangGraph's own `recursion_limit` semantics ("at
      this count, raise") and the standard `>=` convention used by
      Sentry, Datadog, and other monitoring tools.

    Args:
        warning_threshold: Rotation count AT which first WARNING fires
            (default 5). Inclusive — `>=`. Rotation 4 is still clean,
            rotation 5 fires.
        critical_threshold: Rotation count AT which CRITICAL fires
            (default 15). Inclusive — `>=`. Rotation 14 is still
            WARNING, rotation 15 escalates to CRITICAL.
        re_alert_interval: After CRITICAL, re-alert every N additional
            rotations (default 30). Re-alerts use the same `>=`
            comparison.
        resolve_after_seconds: Quiet period before marking RESOLVED
            (default 60).
    """

    # Bound on the number of distinct fingerprints we keep state for.
    # Long-running processes (web servers, notebooks, fuzz suites) with
    # high fingerprint cardinality (new agent IDs each request, churn
    # in SCC structure) would otherwise leak this dict forever. When
    # the cap is exceeded we evict the oldest entries by
    # `last_activity_time`, preferring RESOLVED entries first.
    #
    # 1000 is enough for realistic agent topologies (a few hundred
    # active fingerprints at peak); set higher via the
    # `max_tracked_fingerprints` constructor arg if your workload
    # legitimately needs more state retention.
    _DEFAULT_MAX_TRACKED = 1000

    def __init__(
        self,
        warning_threshold: int = 5,
        critical_threshold: int = 15,
        re_alert_interval: int = 30,
        resolve_after_seconds: float = 60.0,
        per_pattern_thresholds: dict[str, tuple[int, int]] | None = None,
        max_tracked_fingerprints: int = _DEFAULT_MAX_TRACKED,
    ):
        """
        Args:
            warning_threshold: Default WARNING-fire rotation count for any
                pattern that doesn't have a per-pattern override. Generic
                fallback retained for backwards compatibility — pre-0.4.3
                code that constructed AlertStateManager without
                `per_pattern_thresholds` keeps working unchanged.
            critical_threshold: Default CRITICAL-fire rotation count.
                Same fallback semantics as above.
            re_alert_interval: Rotations between re-fires while in
                ESCALATED state. Not pattern-specific.
            resolve_after_seconds: Quiet-time before a tracked alert
                transitions to RESOLVED. Not pattern-specific.
            per_pattern_thresholds: Optional dict mapping pattern names
                ("cycle", "scc_cycle", "edge_anomaly") to
                (warning, critical) tuples. When `process()` receives a
                pattern that's in this dict, the per-pattern values
                override the generic ones. Patterns not in the dict use
                `warning_threshold` / `critical_threshold` as before.

                Use this to disable detection for one pattern without
                disabling all of them. Example:
                    `per_pattern_thresholds={"cycle": (999, 9999)}`
                effectively disables cycle alerts while leaving
                edge_anomaly alerts firing at the generic thresholds.
        """
        self.warning_threshold = warning_threshold
        self.critical_threshold = critical_threshold
        self.re_alert_interval = re_alert_interval
        self.resolve_after_seconds = resolve_after_seconds
        # Materialize a private copy so the caller's dict can't be
        # mutated underneath us mid-run.
        self._per_pattern_thresholds: dict[str, tuple[int, int]] = (
            dict(per_pattern_thresholds) if per_pattern_thresholds else {}
        )
        self._tracked: dict[tuple, _TrackedAlert] = {}
        # Clamp the cap to a sensible minimum. <1 would disable
        # tracking entirely (every new fingerprint immediately evicted
        # before anything could re-alert against it). Treat as "use
        # the default" — defensive against negative / zero values from
        # buggy callers.
        self._max_tracked = (
            max_tracked_fingerprints
            if isinstance(max_tracked_fingerprints, int) and max_tracked_fingerprints >= 1
            else self._DEFAULT_MAX_TRACKED
        )

    def _thresholds_for(self, pattern: str) -> tuple[int, int]:
        """Resolve (warning, critical) for `pattern`.

        Pattern-specific overrides win when present. Otherwise falls
        back to the generic `warning_threshold` / `critical_threshold`
        passed to the constructor — which preserves pre-0.4.3 behavior
        for callers that don't use the new dict.
        """
        override = self._per_pattern_thresholds.get(pattern)
        if override is not None:
            return override
        return (self.warning_threshold, self.critical_threshold)

    def process(
        self,
        fingerprint: tuple,
        rotations: int,
        pattern: str,
        now: float,
        extra_details: dict | None = None,
    ) -> Alert | None:
        """Feed a detection result into the state machine.

        Returns an Alert if one should be emitted, None otherwise.
        """
        details = dict(extra_details or {})
        details["fingerprint"] = fingerprint
        details["rotations"] = rotations

        # Resolve thresholds for THIS pattern. Without per-pattern
        # config this returns the generic (warning_threshold,
        # critical_threshold) — same as pre-0.4.3 behavior.
        warning_threshold, critical_threshold = self._thresholds_for(pattern)

        tracked = self._tracked.get(fingerprint)

        # --- New fingerprint ---
        # Threshold semantics: `>=` means "the threshold IS the trigger
        # value". `warning_threshold=5` fires AT rotation 5, not after.
        # Don't change to `>` without updating ALL downstream docstrings,
        # `prevention_event` summaries, demo expectations, and the public
        # CLAUDE.md / website FAQ. See class docstring above.
        if tracked is None:
            # Fast-path CRITICAL on first detection. If the very first time
            # we see this fingerprint the rotation count is ALREADY at or
            # past `critical_threshold`, fire CRITICAL directly and start
            # tracking in the ESCALATED state — skip the WARNING-then-
            # CRITICAL ratchet.
            #
            # Why this matters: in batch / static-graph scenarios (OMA's
            # dependsOn DAG, CrewAI hierarchical with many delegations
            # in one go), the cycle is often detected only ONCE — there's
            # no "second ingest later" for the state machine to escalate
            # on. Without this fast path, setting `critical_threshold=1`
            # would only ever fire WARNING on a static-graph scenario,
            # because the WARNING-first ratchet locks in ACTIVE state
            # until a later ingest crosses CRITICAL — but that later
            # ingest never comes. Long-streaming scenarios (CrewAI long
            # runs, LangGraph live graphs) are unaffected because cycle
            # rotations naturally accumulate over many ingests, so
            # `warning << critical` puts the WARNING fire well before
            # the eventual CRITICAL — same behavior as before.
            if rotations >= critical_threshold:
                tracked = _TrackedAlert(
                    fingerprint=fingerprint,
                    state="ESCALATED",
                    pattern=pattern,
                    current_rotations=rotations,
                    last_alert_rotations=rotations,
                    last_alert_time=now,
                    last_activity_time=now,
                    created_at=now,
                    alert_count=1,
                )
                self._tracked[fingerprint] = tracked
                self._evict_if_over_cap()
                return Alert(
                    pattern=pattern,
                    severity="CRITICAL",
                    details=details,
                    timestamp=now,
                )
            if rotations >= warning_threshold:
                tracked = _TrackedAlert(
                    fingerprint=fingerprint,
                    state="ACTIVE",
                    pattern=pattern,
                    current_rotations=rotations,
                    last_alert_rotations=rotations,
                    last_alert_time=now,
                    last_activity_time=now,
                    created_at=now,
                    alert_count=1,
                )
                self._tracked[fingerprint] = tracked
                self._evict_if_over_cap()
                return Alert(
                    pattern=pattern,
                    severity="WARNING",
                    details=details,
                    timestamp=now,
                )
            return None

        # --- Existing fingerprint ---
        # NOTE: do NOT mutate `tracked.current_rotations` or
        # `last_activity_time` unconditionally at the top. The old
        # implementation wrote both of these BEFORE the state
        # dispatch decided whether to emit an alert, which meant a
        # no-op call (returning None) still silently corrupted
        # state — e.g. a spurious rotations=4 event after rotations=5
        # would ratchet the count DOWN and refresh the activity
        # time, masking the real rotation count from subsequent
        # recovery checks. Mutations now happen ONLY on paths that
        # actually fire an alert OR represent real progress (see
        # the monotonic-update block below each state branch).
        previous_rotations = tracked.current_rotations

        if tracked.state == "ACTIVE":
            if rotations >= critical_threshold:
                tracked.state = "ESCALATED"
                tracked.current_rotations = rotations
                tracked.last_activity_time = now
                tracked.last_alert_rotations = rotations
                tracked.last_alert_time = now
                tracked.alert_count += 1
                return Alert(
                    pattern=pattern,
                    severity="CRITICAL",
                    details=details,
                    timestamp=now,
                )
            # No alert fires, but rotations may still be increasing
            # toward the critical threshold — ratchet forward ONLY
            # if the new count is >= the old one. This preserves
            # monotonic progress without ever decreasing.
            if rotations >= previous_rotations:
                tracked.current_rotations = rotations
                tracked.last_activity_time = now
            return None

        if tracked.state == "ESCALATED":
            if rotations >= tracked.last_alert_rotations + self.re_alert_interval:
                tracked.current_rotations = rotations
                tracked.last_activity_time = now
                tracked.last_alert_rotations = rotations
                tracked.last_alert_time = now
                tracked.alert_count += 1
                return Alert(
                    pattern=pattern,
                    severity="CRITICAL",
                    details=details,
                    timestamp=now,
                )
            # No re-alert fires — same monotonic guard as ACTIVE.
            if rotations >= previous_rotations:
                tracked.current_rotations = rotations
                tracked.last_activity_time = now
            return None

        if tracked.state == "RESOLVED":
            if rotations > previous_rotations or rotations > tracked.last_alert_rotations:
                tracked.state = "ACTIVE"
                tracked.current_rotations = rotations
                tracked.last_activity_time = now
                tracked.last_alert_time = now
                # CRITICAL round-3 fix: update `last_alert_rotations`
                # on the regression path. Without this, a future
                # ESCALATED re-alert fires at `OLD_last_alert_rotations
                # + re_alert_interval` instead of the correct
                # `rotations + re_alert_interval`, firing one
                # cycle earlier than designed.
                tracked.last_alert_rotations = rotations
                tracked.alert_count += 1
                details["regression"] = True
                return Alert(
                    pattern=pattern,
                    severity="WARNING",
                    details=details,
                    timestamp=now,
                )
            return None

        return None

    def _evict_if_over_cap(self) -> None:
        """Enforce the `_max_tracked` cap by evicting oldest entries.

        Called from EVERY site that adds a new fingerprint to
        ``_tracked``. The eviction policy:

          1. If size <= cap, do nothing (hot path; the typical case).
          2. If over cap, prefer evicting RESOLVED entries first
             (they're terminal; re-firing on the same fingerprint
             creates a fresh entry via the regression path).
          3. If still over cap (rare — only when most entries are
             ACTIVE / ESCALATED), evict the oldest by
             ``last_activity_time`` until back at cap.

        Without this cap, long-running deployments (web servers,
        notebooks, fuzz suites) with high fingerprint cardinality
        accumulate ``_tracked`` entries forever — slow memory growth
        eventually OOMs the host. The cap is configurable via the
        ``max_tracked_fingerprints`` constructor arg.
        """
        if len(self._tracked) <= self._max_tracked:
            return

        # Step 1: evict RESOLVED entries first, oldest first by
        # last_activity_time. Sort + take the lowest N.
        resolved_keys = sorted(
            (k for k, v in self._tracked.items() if v.state == "RESOLVED"),
            key=lambda k: self._tracked[k].last_activity_time,
        )
        for key in resolved_keys:
            if len(self._tracked) <= self._max_tracked:
                return
            del self._tracked[key]

        # Step 2: if still over cap, evict oldest ACTIVE/ESCALATED
        # entries by last_activity_time. This only happens under
        # severe pressure — typical workloads have plenty of RESOLVED
        # entries to drain first.
        if len(self._tracked) > self._max_tracked:
            remaining_keys = sorted(
                self._tracked.keys(),
                key=lambda k: self._tracked[k].last_activity_time,
            )
            # How many to drop:
            over = len(self._tracked) - self._max_tracked
            for key in remaining_keys[:over]:
                del self._tracked[key]

    def check_recoveries(self, now: float) -> list[Alert]:
        """Check all tracked alerts for recovery (quiet period elapsed).

        Returns list of INFO alerts for newly resolved anomalies.
        """
        resolved: list[Alert] = []
        for tracked in self._tracked.values():
            if tracked.state in ("ACTIVE", "ESCALATED"):
                if now - tracked.last_activity_time >= self.resolve_after_seconds:
                    tracked.state = "RESOLVED"
                    resolved.append(Alert(
                        pattern=tracked.pattern,
                        severity="INFO",
                        details={
                            "fingerprint": tracked.fingerprint,
                            "rotations": tracked.current_rotations,
                            "message": "resolved after quiet period",
                        },
                        timestamp=now,
                    ))
        return resolved

    def reset(self) -> None:
        """Clear all tracked alerts."""
        self._tracked.clear()
