"""
Layer 1: SlidingWindowLimiter — O(1) circuit breaker.

Dumb circuit breaker. If any single edge or the whole system exceeds a
hard delegation rate, fire immediate CRITICAL. No scoring, no analysis.

Includes anti-flap hysteresis (half-open circuit breaker pattern): once
an edge fires, further fires are suppressed until the estimated rate
cools below `trip_limit * reset_ratio` (default 0.7). Without this,
every single event over the threshold produced a fresh CRITICAL alert —
the "machine-gun" anti-pattern called out in Prometheus and Datadog's
alert-fatigue guidance.
"""
from __future__ import annotations

from dataclasses import dataclass

from agentsonar._core.models import Alert

# Default reset ratio for the half-open circuit-breaker pattern.
# After the limiter fires at `limit`, it re-arms for the next fire
# only when the estimated rate drops below `limit * RESET_RATIO`.
# Value of 0.7 picked as a balance: low enough that brief spikes
# don't re-arm immediately, high enough that real cooldown does.
# Configurable via the `reset_ratio` constructor arg.
_DEFAULT_RESET_RATIO = 0.7


@dataclass
class _EdgeWindow:
    current_count: int = 0
    previous_count: int = 0
    window_start: float = 0.0

    # Anti-flap state — set when the limiter fires on this window.
    # Cleared when the estimated rate drops below the reset threshold.
    # Multiple fires while `tripped` stays True are suppressed.
    tripped: bool = False


class SlidingWindowLimiter:
    """Hard rate-limit circuit breaker with hysteresis.

    Uses a two-counter sliding window approximation per edge plus one
    global counter. When the estimated rate in the current window first
    crosses the limit, an immediate CRITICAL alert is returned and the
    window is latched into the "tripped" state. Subsequent events on
    the same window DO NOT re-fire until the estimated rate has cooled
    below `trip_limit * reset_ratio` — the classic circuit-breaker
    half-open pattern.

    Args:
        window_size: Window duration in seconds (default 60).
        per_edge_limit: Max delegations per single edge per window (default 50).
        global_limit: Max total delegations across ALL edges per window (default 200).
        reset_ratio: Hysteresis threshold as a fraction of the trip limit.
            After a fire, the limiter re-arms for the next fire only when
            the estimated rate drops below `limit * reset_ratio`. Default
            0.7 — lower values (0.5) re-arm more eagerly; higher values
            (0.9) require deeper cooldown. Must satisfy 0 < ratio < 1.
    """

    def __init__(
        self,
        window_size: float = 60.0,
        per_edge_limit: int = 50,
        global_limit: int = 200,
        reset_ratio: float = _DEFAULT_RESET_RATIO,
    ):
        # Defensive validation — every knob has a range where the
        # math makes sense, and outside that range the detector
        # produces nonsense instead of raising. A surprised user
        # who typed `window_size=-60` by accident would see alerts
        # fire or suppress based on negative rate estimates. Reject
        # at construction time with a clear error message.
        if not 0.0 < reset_ratio < 1.0:
            raise ValueError(
                f"reset_ratio must be between 0 and 1 exclusive, got {reset_ratio}"
            )
        if not isinstance(window_size, (int, float)) or window_size <= 0:
            raise ValueError(
                f"window_size must be a positive number, got {window_size}"
            )
        import math as _math
        if not _math.isfinite(float(window_size)):
            raise ValueError(
                f"window_size must be finite (not NaN or Infinity), got {window_size}"
            )
        if not isinstance(per_edge_limit, int) or per_edge_limit < 1:
            raise ValueError(
                f"per_edge_limit must be a positive integer, got {per_edge_limit}"
            )
        if not isinstance(global_limit, int) or global_limit < 1:
            raise ValueError(
                f"global_limit must be a positive integer, got {global_limit}"
            )
        self.window_size = float(window_size)
        self.per_edge_limit = per_edge_limit
        self.global_limit = global_limit
        self.reset_ratio = reset_ratio
        self._edges: dict[tuple[str, str], _EdgeWindow] = {}
        self._global = _EdgeWindow()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _peek_estimate(self, window: _EdgeWindow, now: float) -> float:
        """Return the current estimated rate for `window` WITHOUT
        incrementing its counter.

        Used on the suppressed-per-edge-event path so the global
        window's counter isn't polluted by events the per-edge
        gate already rejected. We still roll the window if it's
        overdue — the rollover is just time bookkeeping and must
        happen regardless of whether we count this event.
        """
        # Roll the window if it's expired (same bookkeeping as
        # _roll_and_increment, minus the counter bump).
        if window.window_start == 0.0:
            window.window_start = now
        # Clock-skew defense: when wall clock moves backwards (NTP
        # step, VM pause/resume, container migration, manual reset),
        # `now - window_start` goes negative. Without this clamp,
        # `fraction_elapsed` < 0 inflates the estimate via
        # `(1.0 - fraction_elapsed) > 1.0`, producing spurious CRITICAL
        # `rate_limit_exceeded` alerts. Port of npm SDK 0.4.3 fix B1.
        elapsed = max(now - window.window_start, 0.0)
        if elapsed >= self.window_size:
            window.previous_count = window.current_count
            window.current_count = 0
            window.window_start = now
            elapsed = 0.0
            window.tripped = False

        fraction_elapsed = elapsed / self.window_size if self.window_size > 0 else 1.0
        estimated = window.current_count + window.previous_count * (1.0 - fraction_elapsed)
        return estimated

    def _roll_and_increment(self, window: _EdgeWindow, now: float) -> float:
        """Roll over the window if needed, increment, return estimated count.

        Window rollover also clears the `tripped` latch — rolling into a
        fresh window is a natural re-arm point, so the next breach fires
        a new alert rather than being suppressed by the old window's
        hysteresis state.
        """
        if window.window_start == 0.0:
            window.window_start = now

        # Same clock-skew clamp as `_peek_estimate`. Both paths must
        # behave consistently — without this guard, a backward jump
        # between calls in this method and the peek path produces
        # divergent rate estimates that confuse downstream logic.
        elapsed = max(now - window.window_start, 0.0)
        if elapsed >= self.window_size:
            window.previous_count = window.current_count
            window.current_count = 0
            window.window_start = now
            elapsed = 0.0
            # Fresh window — re-arm the circuit breaker. Any latched
            # trip state from the previous window is stale.
            window.tripped = False

        window.current_count += 1

        fraction_elapsed = elapsed / self.window_size if self.window_size > 0 else 1.0
        estimated = window.current_count + window.previous_count * (1.0 - fraction_elapsed)
        return estimated

    def _try_fire(
        self,
        window: _EdgeWindow,
        estimated: float,
        trip_limit: int,
    ) -> bool:
        """Half-open circuit-breaker logic.

        Returns True if the caller should FIRE an alert for this event;
        False if the alert should be suppressed (already firing or
        below the trip threshold).

        State transitions:
          * Not tripped + estimated > limit       → trip + fire (True)
          * Not tripped + estimated <= limit      → quiet (False)
          * Tripped + estimated < limit * ratio   → reset, quiet (False)
          * Tripped + estimated >= limit * ratio  → suppressed (False)
        """
        reset_threshold = trip_limit * self.reset_ratio

        if window.tripped:
            # Already firing on this window. Only clear the latch when
            # the rate has genuinely cooled.
            if estimated < reset_threshold:
                window.tripped = False
            # Either way, do not fire a second alert from the tripped
            # state — the user was already told about the problem.
            return False

        if estimated > trip_limit:
            window.tripped = True
            return True

        return False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def check(self, src: str, dst: str, now: float) -> Alert | None:
        """Check rate limits for a delegation event.

        Returns CRITICAL Alert if the per-edge or global limit is
        newly exceeded (first breach of the current window). Returns
        None if the limit is not exceeded OR if the limiter is already
        in the tripped state for this window.

        Global counter policy: we only count events toward the global
        window when the per-edge window would have let them through.
        Without this, a single runaway edge spews events at the global
        counter long after its per-edge alert has fired and subsequent
        events were suppressed — eventually tripping the global
        limit with a "triggering edge" that isn't actually the
        culprit. The user sees a misleading `global_rate_exceeded`
        attributed to the next benign edge that happened to push the
        global counter past the threshold.

        By skipping the global increment when per-edge is already
        tripped, "global rate" means "events the per-edge gate let
        through", which matches user intuition about what each alert
        represents.
        """
        # Per-edge check
        key = (src, dst)
        if key not in self._edges:
            self._edges[key] = _EdgeWindow()
        edge_window = self._edges[key]
        edge_est = self._roll_and_increment(edge_window, now)

        # Per-edge first — gating against a single runaway edge is
        # usually more actionable than global saturation. Evaluate
        # before touching the global counter so we know whether this
        # event should count toward the global window.
        edge_fires = self._try_fire(edge_window, edge_est, self.per_edge_limit)

        # Decide whether the event counts toward the global window.
        #
        # Count IF:
        #   a) the per-edge window is not tripped at ALL (normal flow), OR
        #   b) the per-edge window is tripped AND this event fired the
        #      alert (the event that initially breached the limit is
        #      legitimate throughput and should be globally counted)
        #
        # Skip IF:
        #   c) the per-edge window is already latched tripped and this
        #      event is being suppressed (the suppressed events should
        #      NOT pollute the global counter)
        #
        # Concretely: if `edge_fires` is True, count globally. If
        # `edge_fires` is False AND `edge_window.tripped` is True,
        # skip. Otherwise (edge untripped, no fire) count normally.
        event_counts_globally = edge_fires or not edge_window.tripped

        if event_counts_globally:
            global_est = self._roll_and_increment(self._global, now)
        else:
            # Still update the window rollover for time tracking, but
            # without incrementing the counter. This is a no-op on
            # the counter side; the window start still rolls when
            # elapsed > window_size.
            global_est = self._peek_estimate(self._global, now)

        if edge_fires:
            return Alert(
                pattern="rate_limit_exceeded",
                severity="CRITICAL",
                details={
                    "source": src,
                    "target": dst,
                    "estimated_rate": round(edge_est, 1),
                    "limit": self.per_edge_limit,
                    "window_size": self.window_size,
                    "reset_ratio": self.reset_ratio,
                },
                timestamp=now,
            )

        # Global check — only reached if the per-edge check did NOT fire
        if self._try_fire(self._global, global_est, self.global_limit):
            return Alert(
                pattern="global_rate_exceeded",
                severity="CRITICAL",
                details={
                    "estimated_rate": round(global_est, 1),
                    "limit": self.global_limit,
                    "window_size": self.window_size,
                    "reset_ratio": self.reset_ratio,
                },
                timestamp=now,
            )

        return None

    def reset(self) -> None:
        """Clear all rate-limit state (including hysteresis latches)."""
        self._edges.clear()
        self._global = _EdgeWindow()
