"""
Layer 2: ExponentialDecayDetector — O(1) update, O(E) anomaly scan.

Detects non-cyclic pathological repetition. Agent A hammering Agent B in
one direction.  Uses exponential decay so old events fade naturally.
"""
from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class _DecayEdge:
    weight: float = 0.0
    last_updated: float = 0.0
    event_count: int = 0


class ExponentialDecayDetector:
    """Decay-weighted edge anomaly detector.

    Each edge carries an exponentially-decaying weight.  Events on a "hot"
    edge accumulate weight faster than it decays, causing it to stand out.
    An edge is flagged when its z-score across all edges exceeds a threshold,
    OR when its absolute weight exceeds a hard limit (for small graphs where
    z-score is unreliable).

    **Z-score warm-up**: z-score-based anomaly detection is the #1 source of
    false positives in homegrown detectors because tiny samples produce
    meaningless statistics. Two warm-up gates prevent this:

      * `min_edges_for_zscore` — minimum number of DISTINCT edges before
        computing z-scores. Defaults to 10 (was 3 pre-v0.1.0, raised after
        the Apache Beam convention that 20-50 samples is the research
        norm for streaming anomaly detection).
      * `min_total_events` — minimum cumulative event count across all
        edges before computing z-scores. Defaults to 20. Protects against
        the "10 distinct edges, 1 event each" degenerate case where
        `min_edges_for_zscore` is satisfied but every edge has weight≈1
        so the variance is trivially zero.

    The `hard_weight_limit` trigger runs regardless of warm-up — it's a
    per-edge absolute threshold and doesn't depend on cross-edge statistics.

    Args:
        half_life_seconds: Time for an edge's weight to decay by 50% (default 60).
        z_score_threshold: Standard deviations above mean to flag (default 3.0).
        hard_weight_limit: Absolute weight that always triggers (default 10.0).
        min_edges_for_zscore: Minimum distinct edges before z-score is
            meaningful (default 10). Raised from the pre-v0.1.0 default of 3
            which produced unreliable early-session z-scores.
        min_total_events: Minimum total events across all edges before the
            z-score path activates (default 20). Prevents meaningless
            statistics on tiny samples.
    """

    def __init__(
        self,
        half_life_seconds: float = 60.0,
        z_score_threshold: float = 3.0,
        hard_weight_limit: float = 10.0,
        min_edges_for_zscore: int = 10,
        min_total_events: int = 20,
    ):
        self.lambda_: float = math.log(2) / half_life_seconds if half_life_seconds > 0 else 0.0
        self.z_score_threshold = z_score_threshold
        self.hard_weight_limit = hard_weight_limit
        self.min_edges_for_zscore = min_edges_for_zscore
        self.min_total_events = min_total_events
        self._edges: dict[tuple[str, str], _DecayEdge] = {}
        # Running total of events across all edges. Used for the warm-up
        # gate that protects the z-score path from tiny-sample false
        # positives. Kept as a dedicated counter so we don't have to
        # sum `event_count` across every edge on every check.
        self._total_events: int = 0

    def record_event(self, src: str, dst: str, now: float) -> None:
        """Update the decayed weight for this edge. Call on every delegation event."""
        self._total_events += 1
        key = (src, dst)
        if key not in self._edges:
            self._edges[key] = _DecayEdge(weight=1.0, last_updated=now, event_count=1)
            return

        edge = self._edges[key]
        time_elapsed = max(now - edge.last_updated, 0.0)
        decay_factor = math.exp(-self.lambda_ * time_elapsed)
        edge.weight = edge.weight * decay_factor + 1.0
        edge.last_updated = now
        edge.event_count += 1

    def get_current_weight(self, src: str, dst: str, now: float) -> float:
        """Read the current decayed weight without adding an event (decay-on-read)."""
        key = (src, dst)
        if key not in self._edges:
            return 0.0
        edge = self._edges[key]
        time_elapsed = max(now - edge.last_updated, 0.0)
        decay_factor = math.exp(-self.lambda_ * time_elapsed)
        return edge.weight * decay_factor

    def check_anomaly(self, src: str, dst: str, now: float) -> dict | None:
        """After recording an event, check if this edge is anomalous.

        Returns a dict with z_score, weight, event_count etc. if anomalous,
        or None if the edge looks normal.
        """
        key = (src, dst)
        if key not in self._edges:
            return None

        this_weight = self.get_current_weight(src, dst, now)

        # Gather all current weights (decay-on-read for each)
        all_weights = []
        for ekey, edge in self._edges.items():
            time_elapsed = max(now - edge.last_updated, 0.0)
            w = edge.weight * math.exp(-self.lambda_ * time_elapsed)
            all_weights.append(w)

        # Hard limit always applies — it's per-edge, so it doesn't
        # depend on cross-edge statistics and is safe to trigger at
        # any sample size. This is the PRIMARY trigger for small
        # graphs where z-score is warming up.
        if this_weight > self.hard_weight_limit:
            return {
                "source": src,
                "target": dst,
                "weight": round(this_weight, 3),
                "event_count": self._edges[key].event_count,
                "trigger": "hard_limit",
                "hard_weight_limit": self.hard_weight_limit,
            }

        # Z-score warm-up gates — both must be satisfied before the
        # z-score path activates. Skipping either produces the
        # classic "10 distinct edges, 1 event each → bogus anomaly
        # because variance is trivially zero" failure mode.
        if len(all_weights) < self.min_edges_for_zscore:
            return None
        if self._total_events < self.min_total_events:
            return None

        mean = sum(all_weights) / len(all_weights)
        variance = sum((w - mean) ** 2 for w in all_weights) / len(all_weights)
        std = math.sqrt(variance) if variance > 0 else 0.0

        # Subnormal-std defense: `std == 0.0` catches the exact-zero
        # case but a subnormal float like 1e-300 slips through. Then
        # `(this_weight - mean) / 1e-300` produces ±Infinity, fires a
        # bogus edge_anomaly alert with z_score=inf. Use a small
        # finite floor (1e-10) and also reject NaN std. Port of npm
        # SDK 0.4.3 fix B5.
        if not (std > 1e-10):
            return None

        z_score = (this_weight - mean) / std

        if z_score > self.z_score_threshold:
            return {
                "source": src,
                "target": dst,
                "weight": round(this_weight, 3),
                "z_score": round(z_score, 3),
                "event_count": self._edges[key].event_count,
                "trigger": "z_score",
                "mean": round(mean, 3),
                "std": round(std, 3),
            }

        return None

    def reset(self) -> None:
        """Clear all decay state."""
        self._edges.clear()
        self._total_events = 0
