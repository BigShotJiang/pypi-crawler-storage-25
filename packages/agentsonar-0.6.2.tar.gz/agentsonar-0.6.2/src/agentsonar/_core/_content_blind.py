"""
Content-blind primitives: hashing, canonical encoding, safe coercion,
redaction, status derivation.

Every adapter that supports the SDK's privacy contract (read structural
metadata only, never user content) uses these. Pure functions, no
state, no I/O.
"""
from __future__ import annotations

import hashlib
import json
import os
from typing import Any


ENV_REGULATED = "AGENTSONAR_REGULATED"

_TRUTHY = frozenset({"1", "true", "yes", "on", "enabled"})


def _is_truthy_env(name: str) -> bool:
    try:
        return os.environ.get(name, "").strip().lower() in _TRUTHY
    except Exception:
        return False


def canonical_json(obj: Any) -> str:
    """Sorted-key, compact, ASCII-safe JSON. Stable per input across
    Python versions and platforms. Returns empty string for
    unserializable input."""
    try:
        return json.dumps(
            obj,
            sort_keys=True,
            separators=(",", ":"),
            default=str,
            ensure_ascii=True,
        )
    except Exception:
        return ""


def hash_string(s: Any, length: int = 16) -> str:
    """SHA-256 hex prefix of the string form of `s`. Returns a fixed
    zero-prefix on any failure so the output is always a stable
    length."""
    if s is None:
        return "0" * length
    try:
        text = str(s)
        if not text:
            return "0" * length
        return hashlib.sha256(text.encode("utf-8")).hexdigest()[:length]
    except Exception:
        return "0" * length


def fingerprint_input(value: Any, length: int = 16) -> str:
    """SHA-256 hex prefix of the canonical-JSON encoding of `value`.
    Same input always produces the same fingerprint; cross-platform
    stable; cannot be reversed without brute-force."""
    payload = canonical_json(value)
    if not payload:
        return "0" * length
    try:
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:length]
    except Exception:
        return "0" * length


def safe_size_bytes(value: Any) -> int:
    """Byte length of the canonical-JSON encoding of `value`. Returns
    0 on any failure. Used for size-based cost proxies that must not
    leak the content itself."""
    if value is None:
        return 0
    try:
        return len(canonical_json(value).encode("utf-8"))
    except Exception:
        return 0


def derive_status(response: Any) -> str:
    """Shape-only success/error inference. Inspects the structure of
    `response` (dict keys, type) but never the message body. Returns
    'success', 'error', or 'unknown'."""
    if response is None:
        return "unknown"
    if isinstance(response, dict):
        if response.get("is_error") is True:
            return "error"
        if "error" in response:
            return "error"
        return "success"
    return "success"


def maybe_redact_path(path: Any) -> str | None:
    """Pass through the path verbatim unless AGENTSONAR_REGULATED is
    set. In regulated mode, returns `path:<8-hex>` so the same path
    still produces the same identifier (deterministic) without
    exposing the cleartext."""
    if path is None:
        return None
    if not _is_truthy_env(ENV_REGULATED):
        try:
            return str(path)
        except Exception:
            return None
    try:
        digest = hashlib.sha256(str(path).encode("utf-8")).hexdigest()
        return f"path:{digest[:8]}"
    except Exception:
        return None


def safe_str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    try:
        return str(value)
    except Exception:
        return default


def safe_str_or_none(value: Any) -> str | None:
    if value is None:
        return None
    try:
        return str(value)
    except Exception:
        return None


def safe_int(value: Any, default: int = 0) -> int:
    if value is None:
        return default
    try:
        return int(value)
    except Exception:
        return default


__all__ = [
    "ENV_REGULATED",
    "canonical_json",
    "hash_string",
    "fingerprint_input",
    "safe_size_bytes",
    "derive_status",
    "maybe_redact_path",
    "safe_str",
    "safe_str_or_none",
    "safe_int",
]
