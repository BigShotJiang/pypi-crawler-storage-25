"""
The `agentsonar demo` command — bundled hello-world for the SDK.

Ships inside the package so users can verify their install works with
ONE command after `pip install agentsonar`. No external dependencies,
no API keys, no config required. Three agents loop forever; Prevent
Mode trips and the demo catches it.

Scenario (mirrored byte-for-byte by `agentsonar-npm/src/cli/demo.ts`):

    Researcher → Writer → Reviewer → Researcher → ...
    (the Reviewer never approves)

Designed for cross-language parity. Fixed event timestamps + fixed
scenario means the alert sequence and detection counts are
byte-identical between this Python demo and its npm counterpart. The
session id / slug / wall-clock prevention timestamp differ per-run as
expected.

Public API surface:
    run_demo(output_dir=None) -> int

    Returns the process exit code. 0 = expected (Prevent Mode tripped
    and we caught it). 1 = unexpected (config drift; the loop ran to
    completion without prevention).

Invocation (after `pip install agentsonar`):
    agentsonar demo            # via console_scripts entry point
    python -m agentsonar demo  # equivalent
"""
from __future__ import annotations

import os
import sys

from agentsonar import monitor_orchestrator, PreventError

# ---------------------------------------------------------------------------
# Cross-language parity constants. The npm demo (src/cli/demo.ts) MUST keep
# these in sync — same scenario, same alert sequence, same human-readable
# stdout text. The 10K differential fuzz harness covers the engine; this
# block is the CLI-level equivalent.
# ---------------------------------------------------------------------------

# Deterministic start timestamp: 2025-01-01 00:00:00 UTC. Each delegation
# event advances by one second. Locks the alert sequence to a fully
# reproducible timeline regardless of wall clock.
_DEMO_START_TS: float = 1735689600.0
_DEMO_TICK_SECONDS: float = 1.0

# The canonical three-agent loop from the public examples. Reviewer →
# Researcher closes the cycle on every rotation; Reviewer never approves
# so the loop never terminates.
_DEMO_AGENTS: tuple[str, ...] = ("researcher", "writer", "reviewer")

# Detection config. Tight thresholds so the demo finishes in under a
# second, but warning_threshold < max_rotations < critical_threshold so
# the user sees: (1) WARNING fires at rotation 3, (2) Prevent Mode trips
# at rotation 5 before CRITICAL would have fired at rotation 10.
_DEMO_CONFIG: dict = {
    "warning_threshold": 3,
    "critical_threshold": 10,
    # Layer 1 (rate limiter) tuned out — the demo events fire faster than
    # any real LLM workload and would trip resource_exhaustion before the
    # cycle layer sees enough rotations to be interesting.
    "per_edge_limit": 999,
    "global_limit": 9999,
    "prevent": {"cyclic_delegation": {"max_rotations": 5}},
    # Suppress the engine's own colored stderr stream. The demo prints
    # its own clean lines and we don't want two voices mid-run.
    "console_output": False,
}

# Belt-and-suspenders: cap the loop at this many rotations in case
# Prevent Mode doesn't fire for some future config-drift reason. 30
# rotations × 3 events = 90 delegation events, still under a second.
_DEMO_MAX_ITERATIONS: int = 30

# Exact stdout lines. Both languages emit byte-identical text here.
_HEADER_LINES: tuple[str, ...] = (
    "AgentSonar demo: a silent loop between three agents",
    "  researcher → writer → reviewer → researcher → ...",
    "  (the Reviewer never approves)",
    "",
)


def run_demo(output_dir: str | None = None, scenario: str = "cycle") -> int:
    """Run the AgentSonar demo. Returns the process exit code.

    Args:
        output_dir: Override the parent directory the SonarLogger writes
            into. Defaults to ``None``, which lets the SDK use its
            normal output location: ``./agentsonar_logs/`` in the
            current working directory. This matches what the framework
            adapters do — users running ``agentsonar demo`` from their
            project root see the report land right next to their code,
            easy to ``cat`` / ``open`` / ``Invoke-Item`` directly.
            Tests pass an explicit path so they can assert on the
            written files without polluting cwd.
        scenario: Which detection path to demonstrate. Default
            ``"cycle"`` runs the cross-language-parity 3-agent cycle.
            ``"hot-edge"`` runs a single-edge repetitive pattern that
            trips repetitive_delegation. ``"rate-burst"`` runs a tight
            same-edge burst that trips the rate limiter
            (resource_exhaustion). Both new scenarios also trip
            Prevent Mode for their respective failure class.

    Exit codes:
        0  — Prevent Mode tripped and the demo caught the PreventError.
        1  — Demo loop completed without prevention (unexpected; would
             indicate a regression in Prevent Mode's threshold handling).

    Side effects:
        Prints 7-8 lines to stderr describing what happened. Writes
        ``timeline.jsonl``, ``alerts.log``, ``report.json``, and
        ``report.html`` into ``<output_dir or cwd>/agentsonar_logs/run-.../``.
    """

    # Force UTF-8 on stderr so the Unicode arrows and em-dash in the
    # output render correctly even when the user redirects to a file or
    # pipe (`agentsonar demo > log.txt 2>&1`) on Windows, where stderr
    # defaults to cp1252 in non-TTY contexts. `errors="replace"` is the
    # safety net — if a future copy edit lands a character UTF-8 itself
    # can't handle, we degrade to '?' rather than raising mid-print.
    # Best-effort: pytest's capsys / tests using mock streams may have
    # a stderr that doesn't expose reconfigure; ignore the AttributeError
    # silently so test paths stay clean.
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
    except (AttributeError, Exception):
        pass

    # Route non-default scenarios off to their own implementations so
    # the canonical "cycle" path stays byte-identical with the npm demo
    # (cross-language differential fuzz keeps locking that contract).
    scenario_norm = (scenario or "cycle").lower().strip()
    if scenario_norm == "hot-edge":
        return _run_hot_edge_demo(output_dir)
    if scenario_norm == "rate-burst":
        return _run_rate_burst_demo(output_dir)
    if scenario_norm != "cycle":
        print(
            f"Unknown scenario {scenario_norm!r}. Valid: cycle, hot-edge, rate-burst.",
            file=sys.stderr,
        )
        return 1

    for line in _HEADER_LINES:
        print(line, file=sys.stderr)
    print("Running...", file=sys.stderr, end=" ", flush=True)

    # Build the engine config. Pass `log_dir` ONLY when the caller
    # supplied one — otherwise let SonarLogger fall back to its
    # default (cwd), so reports land at ``./agentsonar_logs/run-.../``
    # in the user's terminal, matching the framework adapters.
    config = dict(_DEMO_CONFIG)
    if output_dir is not None:
        config["log_dir"] = output_dir

    sonar = monitor_orchestrator(config=config)

    ts = _DEMO_START_TS
    completed_rotations = 0
    prevented = False
    rotations_at_trip = 0
    try:
        for iteration in range(_DEMO_MAX_ITERATIONS):
            for i, src in enumerate(_DEMO_AGENTS):
                tgt = _DEMO_AGENTS[(i + 1) % len(_DEMO_AGENTS)]
                sonar.delegation(source=src, target=tgt, timestamp=ts)
                ts += _DEMO_TICK_SECONDS
            completed_rotations = iteration + 1
    except PreventError as e:
        prevented = True
        rotations_at_trip = e.rotations

    sonar.shutdown()

    if prevented:
        print(
            f"caught the loop at rotation {rotations_at_trip}",
            file=sys.stderr,
        )
        print(
            "  PreventError fired — your orchestrator would have stopped here",
            file=sys.stderr,
        )
        print("", file=sys.stderr)
    else:
        # Defensive — should be unreachable with the locked-in config above.
        # If a future engine change drifts the threshold semantics this
        # branch surfaces the regression loudly.
        print(
            f"completed {completed_rotations} rotations without prevention",
            file=sys.stderr,
        )
        print(
            "  Demo expected PreventError at rotation 5 but didn't get one.",
            file=sys.stderr,
        )
        print("  This is a regression — please open an issue.", file=sys.stderr)
        return 1

    # Resolve where SonarLogger wrote the run directory.
    # Python's `log_dir` is the PARENT of `agentsonar_logs/`, so the
    # actual logs root sits at `<log_dir or cwd>/agentsonar_logs/`.
    # `abspath` resolves the default "." to an absolute path so the
    # "Report written:" line the user sees is copy-pasteable — they
    # can paste it straight into a browser address bar / `Invoke-Item`
    # / `open` rather than having to know their cwd context.
    logs_root = os.path.abspath(
        os.path.join(output_dir or ".", "agentsonar_logs")
    )
    report_path = _find_report_path(logs_root)
    if report_path is not None and os.path.exists(report_path):
        print(f"Report written: {report_path}", file=sys.stderr)
        print(
            "  Open it in a browser to see the full breakdown.",
            file=sys.stderr,
        )
    else:
        # Filesystem issue (permissions, disk full, etc.). Detection
        # worked — we caught the loop — so exit clean but warn.
        print(
            "(report file unavailable — check filesystem permissions)",
            file=sys.stderr,
        )
    return 0


def _find_report_path(logs_root: str) -> str | None:
    """Resolve the path to the run's ``report.html`` under ``logs_root``.

    ``logs_root`` is the ``agentsonar_logs/`` directory itself — the one
    that contains the ``latest`` pointer file and the per-run
    ``run-DATE-slug/`` subdirectories.

    We read the pointer; if it's missing or broken we fall back to the
    lexicographically last ``run-*`` directory (the most recent by
    ISO-timestamp prefix).
    """
    if not os.path.isdir(logs_root):
        return None
    latest = os.path.join(logs_root, "latest")
    if os.path.exists(latest):
        try:
            with open(latest, "r", encoding="utf-8") as f:
                run_name = f.read().strip()
        except OSError:
            run_name = ""
        if run_name:
            candidate = os.path.join(logs_root, run_name, "report.html")
            if os.path.exists(candidate):
                return candidate
    # Fallback: pick the lexicographically last run-* dir.
    try:
        runs = sorted(
            d for d in os.listdir(logs_root)
            if d.startswith("run-")
            and os.path.isdir(os.path.join(logs_root, d))
        )
    except OSError:
        return None
    if runs:
        return os.path.join(logs_root, runs[-1], "report.html")
    return None


# ---------------------------------------------------------------------------
# Alternative scenarios (0.6.2+) — repetitive_delegation and resource_exhaustion
# ---------------------------------------------------------------------------
#
# These exercise the other two detector + Prevent paths without involving
# Claude Code or LangGraph. Useful for first-run validation of detection
# config and for screenshotting the report layout for each failure class.


def _run_hot_edge_demo(output_dir: str | None) -> int:
    """Drive a single hot edge (main -> Read:/x.py) repeatedly until
    Prevent Mode trips the repetitive_delegation path. Mirrors the
    custom/02 + custom/05 playground scenarios."""
    config: dict = {
        "console_output": False,
        "warning_threshold": 2,
        "critical_threshold": 10,
        "hard_weight_limit": 1.0,
        "edge_anomaly_warning_threshold": 3,
        "edge_anomaly_critical_threshold": 6,
        "per_edge_limit": 9999,
        "global_limit": 99999,
        "prevent": {"repetitive_delegation": {"max_events": 4}},
    }
    if output_dir is not None:
        config["log_dir"] = output_dir

    print("AgentSonar demo: one hot edge fires until Prevent trips", file=sys.stderr)
    print("  main -> Read:/x.py (same edge, again and again)", file=sys.stderr)
    print("", file=sys.stderr)
    print("Running...", file=sys.stderr, end=" ", flush=True)

    sonar = monitor_orchestrator(config=config)
    events_fired = 0
    prevented = False
    rotations_at_trip = 0
    try:
        for i in range(20):
            sonar.delegation(source="main", target="Read:/x.py")
            events_fired += 1
    except PreventError as e:
        prevented = True
        rotations_at_trip = e.rotations
    sonar.shutdown()

    if prevented:
        print(
            f"caught the hot edge at {rotations_at_trip} events",
            file=sys.stderr,
        )
        print(
            "  PreventError (repetitive_delegation) fired",
            file=sys.stderr,
        )
        print("", file=sys.stderr)
    else:
        print(
            f"completed {events_fired} events without prevention",
            file=sys.stderr,
        )
        print("  Expected PreventError at ~4 events. Regression?", file=sys.stderr)
        return 1

    return _print_report_location_and_exit(output_dir)


def _run_rate_burst_demo(output_dir: str | None) -> int:
    """Drive a tight burst on one edge to trip the Layer 1 rate
    limiter (resource_exhaustion). Mirrors custom/03 + custom/06."""
    config: dict = {
        "console_output": False,
        "per_edge_limit": 3,
        "window_size": 60.0,
        "global_limit": 9999,
        "hard_weight_limit": 9999.0,
        "z_score_threshold": 99.0,
        "prevent": {"resource_exhaustion": True},
    }
    if output_dir is not None:
        config["log_dir"] = output_dir

    print("AgentSonar demo: rate-limit burst on one edge", file=sys.stderr)
    print("  main -> Bash:cmd (fired rapidly, per_edge_limit=3)", file=sys.stderr)
    print("", file=sys.stderr)
    print("Running...", file=sys.stderr, end=" ", flush=True)

    sonar = monitor_orchestrator(config=config)
    events_fired = 0
    prevented = False
    rate_at_trip = 0
    try:
        for i in range(15):
            sonar.delegation(source="main", target="Bash:cmd")
            events_fired += 1
    except PreventError as e:
        prevented = True
        rate_at_trip = e.rotations
    sonar.shutdown()

    if prevented:
        print(
            f"caught the rate burst at ~{rate_at_trip}/s",
            file=sys.stderr,
        )
        print(
            "  PreventError (resource_exhaustion) fired",
            file=sys.stderr,
        )
        print("", file=sys.stderr)
    else:
        print(
            f"completed {events_fired} events without prevention",
            file=sys.stderr,
        )
        print(
            "  Expected PreventError on first rate-limit alert. Regression?",
            file=sys.stderr,
        )
        return 1

    return _print_report_location_and_exit(output_dir)


def _print_report_location_and_exit(output_dir: str | None) -> int:
    """Shared report-location footer for hot-edge and rate-burst demos."""
    logs_root = os.path.abspath(
        os.path.join(output_dir or ".", "agentsonar_logs")
    )
    report_path = _find_report_path(logs_root)
    if report_path is not None and os.path.exists(report_path):
        print(f"Report written: {report_path}", file=sys.stderr)
        print(
            "  Open it in a browser to see the full breakdown.",
            file=sys.stderr,
        )
    else:
        print(
            "(report file unavailable — check filesystem permissions)",
            file=sys.stderr,
        )
    return 0
