"""
CLI entry point — ``python -m agentsonar`` and the ``agentsonar`` console
script (declared in pyproject.toml's [project.scripts]) both land here.

One subcommand today (``demo``) plus the standard ``--version`` flag.
Designed with room for future subcommands (``doctor``, ``health``,
``replay``) without breaking the shape callers grep for.

Host-safety contract: subcommand failures NEVER raise into the user's
terminal as tracebacks. argparse usage errors print a clean error +
usage line and exit nonzero. Subcommand-level exceptions are caught
inside the subcommand (see ``_demo.py`` for the canonical pattern) so
the CLI surface stays clean.
"""
from __future__ import annotations

import argparse
import os
import sys
from typing import Sequence

from agentsonar._version import __version__


def _build_parser() -> argparse.ArgumentParser:
    """Construct the top-level argparse parser.

    The CLI is sub-command shaped (``agentsonar <subcommand>``) so we
    can add ``doctor``, ``health``, etc. later without breaking the
    surface users learn now.
    """
    parser = argparse.ArgumentParser(
        prog="agentsonar",
        description=(
            "AgentSonar CLI — coordination intelligence for AI agents."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"agentsonar {__version__}",
    )

    subparsers = parser.add_subparsers(
        dest="command",
        metavar="<command>",
        # required=True would force a subcommand on every invocation,
        # which conflicts with the bare `agentsonar --version` flag
        # path. Leaving it optional + handling the no-command branch
        # below keeps both paths working.
    )

    demo_parser = subparsers.add_parser(
        "demo",
        help="Run the bundled hello-world demo (catches a silent loop).",
        description=(
            "Run the bundled AgentSonar demo. Three agents loop forever "
            "and Prevent Mode trips at rotation 5; the demo catches the "
            "PreventError and writes a self-contained HTML report you can "
            "open in your browser."
        ),
    )
    demo_parser.add_argument(
        "--output-dir",
        metavar="DIR",
        default=None,
        help=(
            "Override where the demo writes its logs and report. Defaults "
            "to a fresh system tmpdir named agentsonar-demo-XXXXX."
        ),
    )
    demo_parser.add_argument(
        "--scenario",
        choices=["cycle", "hot-edge", "rate-burst"],
        default="cycle",
        help=(
            "Which detection path to demonstrate. cycle (default) "
            "runs the 3-agent cyclic_delegation demo. hot-edge "
            "trips repetitive_delegation on a single edge. "
            "rate-burst trips resource_exhaustion via the Layer 1 "
            "rate limiter. All three end with PreventError."
        ),
    )

    # Claude Code adapter hook subcommand. Users wire this into their
    # .claude/settings.json hooks block. The dispatcher reads the JSON
    # payload from stdin, extracts content-blind metadata, feeds the
    # detection engine, and exits 0 (proceed) or 2 (Prevent Mode
    # trip; Claude Code blocks the tool call). Any internal failure
    # also exits 0 per the host-safety contract: AgentSonar must
    # never crash Claude Code.
    claude_code_parser = subparsers.add_parser(
        "claude-code-hook",
        help="Claude Code lifecycle hook handler (reads payload on stdin).",
        description=(
            "Hook handler invoked by Claude Code via .claude/settings.json. "
            "Reads the lifecycle event payload from stdin (JSON), records a "
            "content-blind event into the per-session coordination state, "
            "and exits with code 0 (proceed) or 2 (Prevent Mode trip; "
            "Claude Code blocks the tool call). On Stop events for the "
            "root session, regenerates the cumulative report under "
            "~/.agentsonar/reports/<session_id>/."
        ),
    )
    claude_code_parser.add_argument(
        "event",
        choices=[
            "PreToolUse",
            "PostToolUse",
            "Stop",
            "SubagentStop",
            "UserPromptSubmit",
            "Notification",
        ],
        help="Claude Code lifecycle event name (matches the hook event type).",
    )

    # `agentsonar install-claude-hooks` writes / merges .claude/settings.json
    # so users don't need to hand-edit JSON or worry about PATH gotchas
    # (Windows Git Bash vs PowerShell venv activation, etc.). The emitted
    # command is `python -m agentsonar claude-code-hook <event>` for
    # cross-shell portability.
    install_parser = subparsers.add_parser(
        "install-claude-hooks",
        help="Write / merge .claude/settings.json with the AgentSonar hooks.",
        description=(
            "Writes or merges the AgentSonar Claude Code hooks into a "
            ".claude/settings.json file. The emitted command form is "
            "`python -m agentsonar claude-code-hook <event>` so it works "
            "regardless of which venv activates `agentsonar` on PATH. "
            "Without --force, refuses to overwrite a non-AgentSonar hook "
            "registered against a wildcard matcher on the same event. "
            "Merge-safe: existing user hooks and non-hook top-level keys "
            "are preserved."
        ),
    )
    install_parser.add_argument(
        "--path",
        metavar="PATH",
        default=None,
        help=(
            "Explicit settings.json path. Defaults to "
            "$CLAUDE_CONFIG_DIR/settings.json if set, otherwise "
            "./.claude/settings.json in the current directory."
        ),
    )
    install_parser.add_argument(
        "--force",
        action="store_true",
        help=(
            "Overwrite even if an existing non-AgentSonar hook conflicts "
            "with the AgentSonar registration. Last-resort flag; use "
            "when an old hook command shape needs replacement."
        ),
    )
    install_parser.add_argument(
        "--dry-run",
        action="store_true",
        help=(
            "Preview the resulting settings.json on stdout without "
            "writing anything. Useful for safe inspection before "
            "committing the change to disk."
        ),
    )

    # `agentsonar reset-session` clears state.pkl for one or all
    # Claude Code session trees. Useful when iterating on config or
    # recovering from a stale circuit-breaker trip. timeline.jsonl is
    # left intact (canonical audit trail); only the derived state cache
    # is cleared.
    reset_parser = subparsers.add_parser(
        "reset-session",
        help="Clear state.pkl for one or all Claude Code session trees.",
        description=(
            "Clears state.pkl (and last_hook_at) for the specified "
            "session(s). Useful when a rate-limit circuit-breaker is "
            "stuck open or you want to restart detection from a clean "
            "slate. timeline.jsonl is preserved. Defaults to the most-"
            "recent session under ~/.agentsonar/sessions/."
        ),
    )
    reset_parser.add_argument(
        "--session",
        metavar="ID",
        default=None,
        help="Specific session id to reset.",
    )
    reset_parser.add_argument(
        "--all",
        action="store_true",
        help="Reset every non-archived session.",
    )
    reset_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be cleared without modifying anything.",
    )

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entry point. Returns the process exit code.

    Args:
        argv: Optional override for ``sys.argv[1:]``. Useful for tests.

    Host-safety contract: this function NEVER lets a stray exception
    bubble out as a raw traceback to the user's terminal. The subcommand
    dispatch is wrapped in try/except so disk-full errors, Ctrl-C, OOM,
    or any other catastrophic failure produces a clean one-line error
    message + nonzero exit code instead of a 30-line stack trace. The
    npm CLI (`cli/index.ts`) has the equivalent safety net; this brings
    Python to parity.

    KeyboardInterrupt (Ctrl-C) is caught specifically so the message
    is friendlier than the generic "Unexpected error". Standard CLI
    convention: print "interrupted" and exit 130 (128 + SIGINT).
    """
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command is None:
        # Bare `agentsonar` — print usage and exit nonzero (matches the
        # standard argparse convention; users learn the subcommand
        # surface from the help text).
        parser.print_help(sys.stderr)
        return 2

    try:
        if args.command == "demo":
            # Lazy import to keep `agentsonar --version` cheap. _demo imports
            # the full engine via `from agentsonar import monitor_orchestrator`,
            # which we don't want on the version path.
            from agentsonar._demo import run_demo

            return run_demo(
                output_dir=args.output_dir,
                scenario=args.scenario,
            )

        if args.command == "claude-code-hook":
            # Lazy import (same reason as `demo`: keeps `--version` cheap).
            # The Claude Code adapter pulls in pickle, fcntl/msvcrt, the
            # full engine, and the html_report renderer, none of which
            # should land on the version-flag path.
            from agentsonar._integrations.claude import run_hook

            return run_hook(args.event)

        if args.command == "install-claude-hooks":
            # Lazy import — keeps the version-flag path light.
            from agentsonar._integrations.claude import install

            return install(
                target_path=args.path,
                force=args.force,
                dry_run=args.dry_run,
            )

        if args.command == "reset-session":
            # Lazy import.
            from agentsonar._integrations.claude.reset import reset_session

            return reset_session(
                session_id=args.session,
                reset_all=args.all,
                dry_run=args.dry_run,
            )

        # argparse rejects unknown subcommands before reaching here; this is
        # belt-and-suspenders for future refactors.
        parser.print_help(sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        return 130  # 128 + SIGINT, standard Unix convention
    except SystemExit:
        # argparse exits via SystemExit (--version, --help). Let those
        # propagate naturally rather than catching them as errors.
        raise
    except BaseException as exc:
        # BaseException (not just Exception) so we also catch
        # SystemExit-like things that aren't user-driven AND MemoryError.
        # Print a clean error rather than the raw traceback. Stack trace
        # is available via the AGENTSONAR_DEBUG env var for diagnostics.
        print(f"\nUnexpected error: {type(exc).__name__}: {exc}", file=sys.stderr)
        if os.environ.get("AGENTSONAR_DEBUG", "").strip().lower() in {
            "1", "true", "yes", "on"
        }:
            import traceback
            traceback.print_exc(file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
