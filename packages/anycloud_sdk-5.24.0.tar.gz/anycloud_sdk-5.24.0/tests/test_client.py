"""Tests for Client.submit() and Job interactions using httpx mock transport."""

import json
import os
from unittest.mock import patch, MagicMock

import httpx
import pytest

from anycloud import Client, Image, Job, JobGroup, Bucket
from anycloud.errors import (
    APIError,
    ConflictError,
    JobFailedError,
    JobGroupError,
    NotFoundError,
    TimeoutError,
)
from anycloud.storage import _get_fs
from anycloud.types import (
    AWSCredentials,
    AzureCredentials,
    CloudConfig,
    DeploymentState,
    GCPCredentials,
    StatusResponse,
)


def _mock_transport(routes: dict[str, tuple[int, dict | list]]) -> httpx.MockTransport:
    """Create a mock transport that returns canned responses by path."""

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if path in routes:
            status, body = routes[path]
            return httpx.Response(status, json=body)
        return httpx.Response(404, json={"error": "not found"})

    return httpx.MockTransport(handler)


def _status_response(state: str, *, logs: str | None = None) -> dict:
    metadata = {"logs": logs} if logs is not None else None
    return {
        "events": [
            {"id": 1, "deploymentId": "j1", "state": state, "metadata": metadata, "createdAt": 1000}
        ],
        "status": "up" if state == "running" else "down",
    }


def _aws_config(**overrides) -> CloudConfig:
    """Build a minimal AWS CloudConfig for tests."""
    defaults = dict(
        cloudProvider="AWS",
        credentials=AWSCredentials(accessKeyId="fake", secretAccessKey="fake"),
    )
    defaults.update(overrides)
    return CloudConfig(**defaults)


class TestSubmit:
    def test_submit_returns_job(self):
        transport = _mock_transport({
            "/v1/new": (200, {"id": "test-123"}),
        })
        with Client() as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = ac.submit("my-image:latest", cloud_config=_aws_config())
            assert isinstance(job, Job)
            assert job.id == "test-123"

    def test_submit_with_all_options(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "full-opts"})

        cc = _aws_config(region="us-east-1", spot=True)
        with Client() as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.submit(
                "train:latest",
                cloud_config=cc,
                gpu="h100:8",
                env={"LR": "0.001"},
                command=["python", "train.py"],
                persist=True,
            )

        body = captured["body"]
        assert body["image"] == "train:latest"
        assert body["gpuType"] == "h100:8"
        assert body["env"] == {"LR": "0.001"}
        assert body["command"] == ["python", "train.py"]
        assert body["persist"] is True
        assert body["deploymentType"] == "job"
        assert body["cloudConfig"]["region"] == "us-east-1"
        assert body["cloudConfig"]["spot"] is True

    def test_submit_conflict_raises(self):
        transport = _mock_transport({
            "/v1/new": (409, {"error": "exists"}),
        })
        with Client() as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            with pytest.raises(ConflictError):
                ac.submit("img:latest", cloud_config=_aws_config())

    def test_submit_not_found_raises(self):
        transport = _mock_transport({
            "/v1/new": (404, {"error": "not found"}),
        })
        with Client() as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            with pytest.raises(NotFoundError):
                ac.submit("img:latest", cloud_config=_aws_config())

    def test_submit_api_error_raises(self):
        transport = _mock_transport({
            "/v1/new": (500, {"error": "internal"}),
        })
        with Client() as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            with pytest.raises(APIError) as exc_info:
                ac.submit("img:latest", cloud_config=_aws_config())
            assert exc_info.value.status_code == 500



class TestJobStatus:
    def test_status_returns_full_response_and_updates_state(self):
        transport = _mock_transport({
            "/v1/status": (200, _status_response("running")),
        })
        with Client() as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            resp = job.status()
            assert isinstance(resp, StatusResponse)
            assert len(resp.events) == 1
            assert resp.events[0].state == DeploymentState.Running



class TestWait:
    def test_wait_returns_self_on_success(self):
        transport = _mock_transport({
            "/v1/status": (200, _status_response("completed")),
        })
        with Client() as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            result = job.wait()
            assert result is job

    def test_wait_timeout_raises(self):
        transport = _mock_transport({
            "/v1/status": (200, _status_response("running")),
        })
        with Client() as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            with pytest.raises(TimeoutError, match="did not complete"):
                job.wait(timeout=0.05, poll_interval=0.01)

    def test_wait_failure_includes_logs(self):
        """JobFailedError should include container logs from event metadata."""
        transport = _mock_transport({
            "/v1/status": (200, _status_response("errored", logs="CUDA OOM at step 42")),
        })
        with Client() as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            with pytest.raises(JobFailedError) as exc_info:
                job.wait()
            assert exc_info.value.logs == "CUDA OOM at step 42"
            assert "CUDA OOM" in str(exc_info.value)


class TestTerminate:
    def test_terminate(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json={"message": "ok"})

        with Client() as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            job = Job(ac, "j1")
            job.terminate()
            assert "/v1/terminate" in calls


class TestList:
    def test_list_deployments(self):
        transport = _mock_transport({
            "/v1/list": (200, [
                {
                    "id": "d1",
                    "userId": "u1",
                    "deploymentType": "job",
                    "image": "img:latest",
                    "cloudProvider": "AWS",
                    "spot": False,
                    "persist": False,
                    "state": "completed",
                    "startedAt": 1000,
                    "dockerCommand": "docker run img:latest",
                    "vmCount": 1,
                    "sshPrivateKey": "key",
                    "credentialId": "cred-1",
                },
            ]),
        })
        with Client() as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            deployments = ac.list()
            assert len(deployments) == 1
            assert deployments[0].id == "d1"
            assert deployments[0].state == DeploymentState.Completed


class TestGet:
    def test_get_returns_job(self):
        with Client() as ac:
            job = ac.get("existing-id")
            assert isinstance(job, Job)
            assert job.id == "existing-id"


class TestResubmit:
    def test_resubmit(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json={"message": "ok"})

        with Client() as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            job = Job(ac, "j1")
            new_job = job.resubmit()
            assert isinstance(new_job, Job)
            assert new_job.id == "j1"
            assert "/v1/resubmit" in calls


class TestLogs:
    def test_logs_returns_container_logs(self):
        status_data = {
            "events": [
                {"id": 1, "deploymentId": "j1", "state": "running", "metadata": None, "createdAt": 1000}
            ],
            "status": "up",
            "vmStatuses": [
                {"container": {"state": "running", "logs": "epoch 1/10 loss=0.5\n"}}
            ],
        }
        transport = _mock_transport({"/v1/status": (200, status_data)})
        with Client() as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            assert job.logs() == "epoch 1/10 loss=0.5\n"

    def test_logs_returns_none_when_empty(self):
        transport = _mock_transport({"/v1/status": (200, _status_response("running"))})
        with Client() as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            assert job.logs() is None


class TestCloudConfig:
    def test_submit_without_cloud_raises(self):
        with Client() as ac:
            with pytest.raises(ValueError, match="cloud config is required"):
                ac.submit("img:latest")

    def test_cloud_config_fields_sent(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        cc = _aws_config(
            region="us-west-2",
            vmType="p4d.24xlarge",
            spot=True,
            inputBucket="my-input",
            outputBucket="my-output",
            diskSizeGb=200,
        )
        with Client() as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.submit("img:latest", cloud_config=cc)

        cc_body = captured["body"]["cloudConfig"]
        assert cc_body["region"] == "us-west-2"
        assert cc_body["vmType"] == "p4d.24xlarge"
        assert cc_body["spot"] is True
        assert cc_body["inputBucket"] == "my-input"
        assert cc_body["outputBucket"] == "my-output"
        assert cc_body["diskSizeGb"] == 200

    def test_default_cloud_config(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        cc = _aws_config(region="us-east-1")
        with Client(cloud_config=cc) as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.submit("img:latest")

        assert captured["body"]["cloudConfig"]["region"] == "us-east-1"


class TestBuild:
    def test_build_submits_builder_image(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "build-123"})

        cc = _aws_config(vmType="c5.xlarge")
        img = Image("alpine:latest").run_commands("echo hello")
        with Client() as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            job = ac.build(
                img,
                target_image="ghcr.io/user/repo:v1",
                cloud_config=cc,
            )

        assert isinstance(job, Job)
        assert job.id == "build-123"
        body = captured["body"]
        assert body["image"] == "ghcr.io/anycloud-sh/builder"
        assert body["env"]["DOCKERFILE"] == img.to_dockerfile()
        assert body["env"]["TARGET_IMAGE"] == "ghcr.io/user/repo:v1"
        assert body["dockerOptions"]["binds"] == ["/var/run/docker.sock:/var/run/docker.sock"]

    def test_build_applies_defaults_when_no_vmtype(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "build-456"})

        cc = _aws_config()  # no vmType
        img = Image("alpine:latest")
        with Client() as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.build(
                img,
                target_image="ghcr.io/user/repo:v1",
                cloud_config=cc,
            )

        cc_body = captured["body"]["cloudConfig"]
        assert cc_body["vmType"] == "c5.xlarge"  # AWS build default

    def test_build_without_cloud_config_raises(self):
        img = Image("alpine:latest")
        with Client() as ac:
            with pytest.raises(ValueError, match="cloud config is required"):
                ac.build(
                    img,
                    target_image="ghcr.io/user/repo:v1",
                )


class TestClientInit:
    def test_env_var_fallbacks(self, tmp_path):
        with patch.dict("os.environ", {
            "GITHUB_TOKEN": "gh-token",
            "API_URL": "http://custom:9090",
            "ANYCLOUD_DIR": str(tmp_path),  # no .token file here
        }):
            with Client() as ac:
                assert ac._access_token == "gh-token"
                assert ac._base_url == "http://custom:9090"

    def test_token_file_fallback(self, tmp_path):
        token_file = tmp_path / ".token"
        token_file.write_text("file-token\n")
        with patch.dict("os.environ", {"ANYCLOUD_DIR": str(tmp_path)}, clear=True):
            os.environ.pop("GITHUB_TOKEN", None)
            with Client() as ac:
                assert ac._access_token == "file-token"

    def test_token_file_takes_priority_over_env(self, tmp_path):
        token_file = tmp_path / ".token"
        token_file.write_text("file-token\n")
        with patch.dict("os.environ", {
            "ANYCLOUD_DIR": str(tmp_path),
            "GITHUB_TOKEN": "env-token",
        }):
            with Client() as ac:
                assert ac._access_token == "file-token"

    def test_missing_access_token_raises(self, tmp_path):
        with patch.dict("os.environ", {"ANYCLOUD_DIR": str(tmp_path)}, clear=True):
            os.environ.pop("GITHUB_TOKEN", None)
            with pytest.raises(ValueError, match="No authentication token found"):
                Client()


def _cred_transport(
    cred_list: list[dict],
    full_creds: dict[str, dict] | None = None,
    submit_capture: dict | None = None,
) -> httpx.MockTransport:
    """Mock transport that serves credential API + optional submit."""
    full_creds = full_creds or {}

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if path == "/v1/credentials" and request.method == "GET":
            return httpx.Response(200, json=cred_list)
        if path.startswith("/v1/credentials/") and path.endswith("/full"):
            name = path.split("/v1/credentials/")[1].rsplit("/full", 1)[0]
            if name in full_creds:
                return httpx.Response(200, json=full_creds[name])
            return httpx.Response(404, text=f'Credential "{name}" not found')
        if path == "/v1/new":
            if submit_capture is not None:
                submit_capture["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})
        return httpx.Response(404, text="not found")

    return httpx.MockTransport(handler)


def _client_with_transport(transport: httpx.MockTransport, **kwargs) -> Client:
    """Create a Client whose httpx.Client uses the given mock transport."""
    real_httpx_client = httpx.Client.__init__

    def patched_init(self, **kw):
        kw["transport"] = transport
        real_httpx_client(self, **kw)

    with patch.object(httpx.Client, "__init__", patched_init):
        return Client(**kwargs)


class TestCredentialAutoLoading:
    def test_single_credential_auto_loaded(self):
        captured = {}
        transport = _cred_transport(
            cred_list=[{"name": "my-aws", "cloudProvider": "AWS"}],
            full_creds={
                "my-aws": {
                    "name": "my-aws",
                    "cloudProvider": "AWS",
                    "accessKeyId": "AKIA...",
                    "secretAccessKey": "secret",
                }
            },
            submit_capture=captured,
        )
        with _client_with_transport(transport) as ac:
            ac.submit("img:latest")

        cc = captured["body"]["cloudConfig"]
        assert cc["cloudProvider"] == "AWS"
        assert cc["credentials"]["accessKeyId"] == "AKIA..."

    def test_named_credential_selected(self):
        captured = {}
        transport = _cred_transport(
            cred_list=[
                {"name": "aws-prod", "cloudProvider": "AWS"},
                {"name": "gcp-dev", "cloudProvider": "GCP"},
            ],
            full_creds={
                "gcp-dev": {
                    "name": "gcp-dev",
                    "cloudProvider": "GCP",
                    "projectId": "my-proj",
                    "privateKey": "key",
                    "clientEmail": "email@test.com",
                }
            },
            submit_capture=captured,
        )
        with _client_with_transport(transport, credentials="gcp-dev") as ac:
            ac.submit("img:latest")

        cc = captured["body"]["cloudConfig"]
        assert cc["cloudProvider"] == "GCP"
        assert cc["credentials"]["projectId"] == "my-proj"

    def test_missing_named_credential_raises(self):
        transport = _cred_transport(
            cred_list=[{"name": "aws-prod", "cloudProvider": "AWS"}],
        )
        with pytest.raises(ValueError, match="not found"):
            _client_with_transport(transport, credentials="nonexistent")

    def test_multiple_credentials_no_name_requires_explicit(self):
        transport = _cred_transport(
            cred_list=[
                {"name": "a", "cloudProvider": "AWS"},
                {"name": "b", "cloudProvider": "GCP"},
            ],
            submit_capture={},
        )
        with _client_with_transport(transport) as ac:
            # No default cloud config → must pass per-submit
            with pytest.raises(ValueError, match="cloud config is required"):
                ac.submit("img:latest")

    def test_explicit_cloud_config_overrides_credentials(self):
        captured = {}
        transport = _cred_transport(
            cred_list=[{"name": "my-aws", "cloudProvider": "AWS"}],
            full_creds={
                "my-aws": {
                    "name": "my-aws",
                    "cloudProvider": "AWS",
                    "accessKeyId": "api-key",
                    "secretAccessKey": "api-secret",
                }
            },
            submit_capture=captured,
        )
        cc = _aws_config(region="eu-west-1")
        with _client_with_transport(transport, cloud_config=cc) as ac:
            ac.submit("img:latest")

        # Should use explicit config, not API credential
        assert captured["body"]["cloudConfig"]["region"] == "eu-west-1"
        assert captured["body"]["cloudConfig"]["credentials"]["accessKeyId"] == "fake"


class TestJobGroup:
    def test_wait_all_success(self):
        transport = _mock_transport({
            "/v1/status": (200, _status_response("completed")),
        })
        with Client() as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            jobs = JobGroup([Job(ac, f"j{i}") for i in range(3)])
            result = jobs.wait_all()
            assert result is jobs

    def test_wait_all_partial_failure(self):
        """If some jobs fail, JobGroupError is raised with all failures."""
        call_count = 0

        def handler(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            body = json.loads(request.content)
            dep_id = body.get("id", "")
            verbose = body.get("verbose", False)
            # j0 completes, j1 errors
            if "j0" in dep_id:
                return httpx.Response(200, json=_status_response("completed"))
            if verbose:
                return httpx.Response(
                    200, json=_status_response("errored", logs="OOM")
                )
            return httpx.Response(200, json=_status_response("errored"))

        with Client() as ac:
            ac._http = httpx.Client(
                transport=httpx.MockTransport(handler), base_url="http://test"
            )
            jobs = JobGroup([Job(ac, "j0"), Job(ac, "j1")])
            with pytest.raises(JobGroupError) as exc_info:
                jobs.wait_all()
            assert len(exc_info.value.errors) == 1
            assert exc_info.value.errors[0][0] == "j1"

    def test_terminate_all(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json={"message": "ok"})

        with Client() as ac:
            ac._http = httpx.Client(
                transport=httpx.MockTransport(handler), base_url="http://test"
            )
            jobs = JobGroup([Job(ac, "j0"), Job(ac, "j1")])
            jobs.terminate_all()
            assert calls.count("/v1/terminate") == 2

    def test_sequence_protocol(self):
        with Client() as ac:
            jobs = JobGroup([Job(ac, "j0"), Job(ac, "j1"), Job(ac, "j2")])
            assert len(jobs) == 3
            assert jobs[1].id == "j1"
            assert [j.id for j in jobs] == ["j0", "j1", "j2"]
            assert jobs.ids == ["j0", "j1", "j2"]


class TestState:
    def test_state_fetches_from_api(self):
        transport = _mock_transport({
            "/v1/status": (200, _status_response("running")),
        })
        with Client() as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            assert job.state() == DeploymentState.Running

    def test_state_is_method_not_property(self):
        with Client() as ac:
            job = Job(ac, "j1")
            assert callable(job.state)


# ======================================================================
# Bucket tests
# ======================================================================

def _gcp_config(**overrides) -> CloudConfig:
    defaults = dict(
        cloudProvider="GCP",
        credentials=GCPCredentials(
            projectId="test-proj",
            privateKey="key",
            clientEmail="test@test.iam.gserviceaccount.com",
        ),
    )
    defaults.update(overrides)
    return CloudConfig(**defaults)


def _azure_config(**overrides) -> CloudConfig:
    defaults = dict(
        cloudProvider="Azure",
        credentials=AzureCredentials(
            subscriptionId="aaaa-bbbb-cccc-dddd",
            directoryId="dir-id",
            applicationId="app-id",
            secret="s3cret",
        ),
    )
    defaults.update(overrides)
    return CloudConfig(**defaults)


class TestBucket:
    def test_repr(self):
        s = Bucket("my-bucket", _aws_config())
        assert repr(s) == "Bucket('my-bucket')"

    def test_equality(self):
        s1 = Bucket("bucket-a", _aws_config())
        s2 = Bucket("bucket-a", _gcp_config())
        s3 = Bucket("bucket-b", _aws_config())
        assert s1 == s2
        assert s1 != s3

    def test_hash(self):
        s1 = Bucket("bucket-a", _aws_config())
        s2 = Bucket("bucket-a", _gcp_config())
        assert hash(s1) == hash(s2)

    def test_name(self):
        s = Bucket("my-bucket", _aws_config())
        assert s.name == "my-bucket"

    def test_cloud_config(self):
        cc = _aws_config()
        s = Bucket("my-bucket", cc)
        assert s.cloud_config is cc


class TestBucket:
    def test_bucket_returns_storage(self):
        with Client(cloud_config=_aws_config()) as ac:
            storage = ac.bucket("existing-bucket")
        assert isinstance(storage, Bucket)
        assert storage.name == "existing-bucket"

    def test_bucket_no_cloud_config_raises(self):
        with Client() as ac:
            ac._default_cloud_config = None
            with pytest.raises(ValueError, match="cloud_config is required"):
                ac.bucket("test-bucket")


class TestBucketUploadDownload:
    @patch("anycloud.storage._get_fs")
    def test_upload_auto_creates_bucket(self, mock_get_fs):
        mock_fs = MagicMock()
        mock_get_fs.return_value = mock_fs
        s = Bucket("my-bucket", _aws_config())
        s.upload("/tmp/data")
        mock_fs.mkdir.assert_called_once_with("my-bucket")
        mock_fs.put.assert_called_once_with("/tmp/data", "my-bucket", recursive=True)

    @patch("anycloud.storage._get_fs")
    def test_upload_with_remote_path(self, mock_get_fs):
        mock_fs = MagicMock()
        mock_get_fs.return_value = mock_fs
        s = Bucket("my-bucket", _aws_config())
        s.upload("/tmp/data", remote_path="subdir")
        mock_fs.mkdir.assert_called_once_with("my-bucket")
        mock_fs.put.assert_called_once_with("/tmp/data", "my-bucket/subdir", recursive=True)

    @patch("anycloud.storage._get_fs")
    def test_download(self, mock_get_fs):
        mock_fs = MagicMock()
        mock_get_fs.return_value = mock_fs
        s = Bucket("my-bucket", _aws_config())
        s.download("/tmp/output")
        mock_fs.get.assert_called_once_with("my-bucket", "/tmp/output", recursive=True)


class TestSubmitWithBucket:
    def test_input_and_output_set_bucket_names(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        cc = _aws_config()
        inp = Bucket("inp-bucket", cc)
        out = Bucket("out-bucket", cc)
        with Client() as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            job = ac.submit("img:latest", cloud_config=cc, input=inp, output=out)

        cc_body = captured["body"]["cloudConfig"]
        assert cc_body["inputBucket"] == "inp-bucket"
        assert cc_body["outputBucket"] == "out-bucket"

    def test_only_input(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        cc = _aws_config()
        inp = Bucket("inp-bucket", cc)
        with Client() as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.submit("img:latest", cloud_config=cc, input=inp)

        cc_body = captured["body"]["cloudConfig"]
        assert cc_body["inputBucket"] == "inp-bucket"
        assert "outputBucket" not in cc_body

    def test_input_conflict_with_cloud_config_raises(self):
        cc = _aws_config(inputBucket="existing")
        inp = Bucket("new-bucket", cc)
        with Client() as ac:
            with pytest.raises(ValueError, match="Cannot set both"):
                ac.submit("img:latest", cloud_config=cc, input=inp)

    def test_output_conflict_with_cloud_config_raises(self):
        cc = _aws_config(outputBucket="existing")
        out = Bucket("new-bucket", cc)
        with Client() as ac:
            with pytest.raises(ValueError, match="Cannot set both"):
                ac.submit("img:latest", cloud_config=cc, output=out)

class TestCrossCloudBucket:
    def test_cross_cloud_sets_storage_credentials(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        compute_cc = _gcp_config()
        storage_cc = _aws_config(region="us-west-2")
        inp = Bucket("s3-bucket", storage_cc)
        with Client() as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.submit("img:latest", cloud_config=compute_cc, input=inp)

        cc_body = captured["body"]["cloudConfig"]
        assert cc_body["inputBucket"] == "s3-bucket"
        assert "storageCredentials" in cc_body
        assert cc_body["storageCredentials"]["accessKeyId"] == "fake"
        assert cc_body["storageRegion"] == "us-west-2"

    def test_same_cloud_no_storage_credentials(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        cc = _aws_config()
        inp = Bucket("my-bucket", cc)
        with Client() as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.submit("img:latest", cloud_config=cc, input=inp)

        cc_body = captured["body"]["cloudConfig"]
        assert "storageCredentials" not in cc_body

    def test_cross_cloud_input_output_same_cloud_ok(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        compute_cc = _gcp_config()
        storage_cc = _aws_config()
        inp = Bucket("s3-in", storage_cc)
        out = Bucket("s3-out", storage_cc)
        with Client() as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.submit("img:latest", cloud_config=compute_cc, input=inp, output=out)

        cc_body = captured["body"]["cloudConfig"]
        assert cc_body["inputBucket"] == "s3-in"
        assert cc_body["outputBucket"] == "s3-out"
        assert "storageCredentials" in cc_body

    def test_cross_cloud_input_output_different_clouds_raises(self):
        compute_cc = _aws_config()
        gcp_storage = Bucket("gcs-bucket", _gcp_config())
        azure_storage = Bucket("az-bucket", _azure_config())
        with Client() as ac:
            with pytest.raises(ValueError, match="must be on the same cloud"):
                ac.submit("img:latest", cloud_config=compute_cc, input=gcp_storage, output=azure_storage)


class TestGetFs:
    def test_aws_missing_import(self):
        with patch.dict("sys.modules", {"s3fs": None}):
            with pytest.raises(ImportError, match="pip install anycloud-sdk\\[aws\\]"):
                _get_fs(_aws_config())

    def test_gcp_missing_import(self):
        with patch.dict("sys.modules", {"gcsfs": None}):
            with pytest.raises(ImportError, match="pip install anycloud-sdk\\[gcp\\]"):
                _get_fs(_gcp_config())

    def test_azure_account_name_derivation(self):
        cc = _azure_config()
        with patch.dict("sys.modules", {"adlfs": MagicMock()}):
            import sys
            mock_adlfs = sys.modules["adlfs"]
            _get_fs(cc)
            call_kwargs = mock_adlfs.AzureBlobFileSystem.call_args[1]
            # subscription_id "aaaa-bbbb-cccc-dddd" → "aaaabbbb" (first 8 chars without dashes)
            assert call_kwargs["account_name"] == "anycloudaaaabbbb"

    def test_unsupported_provider(self):
        cc = _aws_config()
        # Hack the provider to something unsupported
        cc_dict = cc.model_dump(by_alias=True)
        cc_dict["cloudProvider"] = "Lambda"
        cc_dict["credentials"] = {"apiKey": "fake"}
        from anycloud.types import LambdaCredentials
        bad_cc = CloudConfig(
            cloudProvider="Lambda",
            credentials=LambdaCredentials(apiKey="fake"),
        )
        with pytest.raises(ValueError, match="not supported"):
            _get_fs(bad_cc)
