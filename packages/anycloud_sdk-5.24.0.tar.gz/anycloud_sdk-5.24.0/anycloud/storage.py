"""Bucket — a handle to a cloud bucket with upload/download methods."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from anycloud.types import CloudConfig

AZURE_RESOURCE_GROUP_BASE = "anycloud"


def _get_fs(cloud_config: CloudConfig) -> Any:
    """Create an fsspec filesystem from CloudConfig credentials.

    Uses ``storage_credentials`` if set, otherwise falls back to
    ``credentials``.  The cloud provider is determined from the
    credentials object (which always carries a ``cloud_provider`` field).
    """
    creds = cloud_config.storage_credentials or cloud_config.credentials
    provider = cloud_config.cloud_provider

    if provider == "AWS":
        try:
            import s3fs
        except ImportError:
            raise ImportError(
                "s3fs is required for bucket operations on AWS. "
                "Install with: pip install anycloud-sdk[aws]"
            )
        kwargs: dict[str, Any] = {
            "key": creds.access_key_id,
            "secret": creds.secret_access_key,
        }
        region = cloud_config.storage_region or cloud_config.region
        if region:
            kwargs["client_kwargs"] = {"region_name": region}
        return s3fs.S3FileSystem(**kwargs)

    elif provider == "GCP":
        try:
            import gcsfs
        except ImportError:
            raise ImportError(
                "gcsfs is required for bucket operations on GCP. "
                "Install with: pip install anycloud-sdk[gcp]"
            )
        return gcsfs.GCSFileSystem(token={
            "type": "service_account",
            "project_id": creds.project_id,
            "private_key": creds.private_key,
            "client_email": creds.client_email,
        })

    elif provider == "Azure":
        try:
            import adlfs
        except ImportError:
            raise ImportError(
                "adlfs is required for bucket operations on Azure. "
                "Install with: pip install anycloud-sdk[azure]"
            )
        # Derive storage account name — same logic as conductor
        # (src/api/services/gateways/azure.ts:162-167)
        sub_prefix = creds.subscription_id.replace("-", "")[:8]
        account_name = (AZURE_RESOURCE_GROUP_BASE + sub_prefix)[:24]
        return adlfs.AzureBlobFileSystem(
            account_name=account_name,
            tenant_id=creds.directory_id,
            client_id=creds.application_id,
            client_secret=creds.secret,
        )

    else:
        raise ValueError(f"Bucket operations not supported for provider: {provider}")


class Bucket:
    """A handle to a cloud bucket.

    Returned by :meth:`Client.bucket`.  Carries the bucket name and
    the cloud configuration so that upload/download and cross-cloud
    wiring work automatically.

    Usage::

        data = ac.bucket("training-data")
        data.upload("~/datasets/imagenet")   # auto-creates bucket
        data.download("~/local/copy")
    """

    def __init__(self, name: str, cloud_config: CloudConfig):
        self._name = name
        self._cc = cloud_config

    @property
    def name(self) -> str:
        """Bucket name."""
        return self._name

    @property
    def cloud_config(self) -> CloudConfig:
        """The cloud configuration this bucket belongs to."""
        return self._cc

    def upload(self, local_path: str, remote_path: str = "") -> None:
        """Upload local files or a directory to this bucket.

        Creates the bucket if it doesn't already exist.

        Args:
            local_path: Local file or directory (``~`` is expanded).
            remote_path: Optional sub-path inside the bucket.
        """
        fs = _get_fs(self._cc)
        fs.mkdir(self._name)
        local = os.path.expanduser(local_path)
        dest = f"{self._name}/{remote_path}" if remote_path else self._name
        fs.put(local, dest, recursive=True)

    def download(self, local_path: str, remote_path: str = "") -> None:
        """Download bucket contents to a local path.

        Args:
            local_path: Local destination directory (``~`` is expanded).
            remote_path: Optional sub-path inside the bucket.
        """
        fs = _get_fs(self._cc)
        local = os.path.expanduser(local_path)
        src = f"{self._name}/{remote_path}" if remote_path else self._name
        fs.get(src, local, recursive=True)

    def __repr__(self) -> str:
        return f"Bucket({self._name!r})"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Bucket) and self._name == other._name

    def __hash__(self) -> int:
        return hash(self._name)
