# Changelog

All notable changes to `pisama-core` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.5.0] — 2026-04-18

Follow-up calibration sprint. One major pisama-core detector fix
(critic_quality) plus infra and backend-side fixes (sampling drift,
grounding LLM judge rewire, loop detector). Mean F1 0.832 → 0.842
across 57 detectors.

### Changed

- **critic_quality** — F1 0.686 → 0.966 (+0.280). Precision held at
  1.000; recall 0.522 → 0.935. Four deterministic pattern groups:
  expanded `_APPROVAL_PATTERNS` (clean/simple, well-organized,
  professional, follows-conventions variants); new `_PRODUCER_RED_FLAGS`
  (bubble sort, divide-by-len() without guard, plaintext password
  compare, Scanner without try-with-resources, CREATE TABLE without
  constraints, fetch().json() without error handling, stub bodies with
  placeholder comments, multi-key dict access without `.get()`);
  cosmetic-only critique detection gated on red flags; question-only
  and substanceless-critique detection.

### Notes

- Public API is unchanged. Backend-side wins for grounding (LLM judge
  gray-zone rewire, 7 new tests), loop (bookkeeping-aware progress
  checks), and OpenClaw token/cost passthrough live in the backend repo.
- Calibration sampling is now deterministic (`cap_per_type` sorts inputs
  before `random.sample`), so sprint-over-sprint F1 deltas are honest.
- Calibration report at `backend/data/calibration_report.json`
  (mean F1 0.842 across 57 detectors as of 2026-04-18).
- Registry: 48 tested — 32 production, 16 beta, 0 experimental,
  2 untested (up from 30/17/1/2).

## [1.4.0] — 2026-04-17

Detector calibration sprint. Five detectors significantly improved, two promoted
toward production tier.

### Changed

- **task_starvation** — F1 0.667 → 0.980. Fixed `_extract_executed_tasks` to
  accept `SpanKind.TASK` spans (prior bug produced TN=0 on task-only traces).
  Added planner-span exclusion, substring task matching, and a small
  Porter-lite stemmer so "summarising" matches "summarize" etc.
- **critic_quality** — recall 0.33 → 0.52. Added reviewer/approver role
  detection and softened the requirement for an explicit approve/reject
  verdict when structured feedback is present.
- **mcp_protocol** — recall 0.26 → 0.98. Broadened the tool-call shape
  matcher to cover both `tool_calls` (OpenAI-style) and `tool_use` (Anthropic)
  payloads, and to treat inline `<tool_use>…</tool_use>` XML the same as
  structured blocks.
- **citation** — F1 0.557 → 0.677 (P 0.800→0.827, R 0.427→0.573). Added a
  numeric-fact unsupported-claim check (percentages, currency, integer+unit)
  gated by approximation markers so paraphrases are not flagged.
- **entity_confusion** — F1 0.607 → 0.823 (P 0.537→1.000). Scoped the
  attribute-proximity heuristic to sentence boundaries via `_attribute_closer_to`
  and added `_entity_referenced` word-boundary matching (surname / given-name,
  role prefix ignored).

### Notes

- Public API is unchanged. All changes are internal to detector implementations
  and corresponding test fixtures.
- Calibration report at `backend/data/calibration_report.json` (mean F1 0.825
  across 57 detectors as of 2026-04-17).

## [1.3.0] — prior release

Baseline prior to the 2026-04-17 calibration sprint.
