"""PISAMA Core test suite."""
