"""Persistent config.json and state.json IO for the cloudagent daemon.

Both models support:
  .load(path)         — parse JSON file into model (raises FileNotFoundError if missing)
  .save(path)         — atomic write: tempfile → fsync → os.replace, mode 0o600
  .default_path()     — ~/.cloudagent/daemon/{config|state}.json
  .load_default()     — convenience wrapper
  .save_default()     — convenience wrapper
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Self

from pydantic import BaseModel

from .paths import (
    DEFAULT_PROFILE,
    profile_config_path,
    profile_state_path,
)

_LRU_CAP = 1024


def _atomic_write_json(path: Path, data: dict) -> None:
    """Write *data* as JSON to *path* atomically with fsync and mode 0o600."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=path.parent)
    try:
        with os.fdopen(fd, "w") as fh:
            json.dump(data, fh, indent=2)
            fh.flush()
            os.fsync(fh.fileno())
    except Exception:
        os.unlink(tmp_name)
        raise
    os.replace(tmp_name, path)
    os.chmod(path, 0o600)


class DaemonConfig(BaseModel):
    """Stored at ``~/.cloudagent/daemon/config.json`` (default profile) or
    ``~/.cloudagent/daemon/profiles/<name>/config.json`` (named profile).
    """

    server_url: str
    machine_api_key: str
    host_id: str

    # ------------------------------------------------------------------
    # Path helpers
    # ------------------------------------------------------------------

    @classmethod
    def default_path(cls, profile: str | None = None) -> Path:
        # Resolve only when profile is given. Tests monkeypatch this
        # classmethod with a no-arg lambda; preserving the no-arg call
        # path keeps that pattern working.
        return profile_config_path(profile) if profile else profile_config_path(DEFAULT_PROFILE)

    # ------------------------------------------------------------------
    # IO
    # ------------------------------------------------------------------

    @classmethod
    def load(cls, path: Path) -> Self:
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        return cls.model_validate(json.loads(path.read_text()))

    @classmethod
    def load_default(cls, profile: str | None = None) -> Self:
        # Default profile → call no-arg ``default_path()`` so test stubs
        # that monkeypatch the classmethod with a (cls)-only signature
        # keep working byte-for-byte.
        path = (
            cls.default_path()
            if not profile or profile == DEFAULT_PROFILE
            else cls.default_path(profile)
        )
        return cls.load(path)

    def save(self, path: Path) -> None:
        _atomic_write_json(path, self.model_dump())

    def save_default(self, profile: str | None = None) -> None:
        path = (
            self.default_path()
            if not profile or profile == DEFAULT_PROFILE
            else self.default_path(profile)
        )
        self.save(path)


class DaemonState(BaseModel):
    """Stored at ``~/.cloudagent/daemon/state.json`` (default profile) or
    ``~/.cloudagent/daemon/profiles/<name>/state.json`` (named profile).
    """

    last_seq: int = 0
    processed_message_ids: list[str] = []
    # Task #113 (2026-05-12) — last ``--workspace-root`` the user passed.
    # Persisted so subsequent ``cloudagent-daemon start`` invocations
    # without the flag still pick it up (avoid forcing the user to
    # type the path on every reboot / launchctl restart).
    workspace_root: str | None = None
    # 2026-05-15 — host_id this seq/dedupe state belongs to. Compared on
    # /ready (or WS hello) so switching ``--server-url`` (or otherwise
    # landing on a fresh host_machine row) discards stale ``last_seq`` /
    # ``processed_message_ids``. Without this, the SSE client kept
    # sending ``Last-Event-ID=<old-cluster-seq>`` on the new cluster and
    # every fresh frame whose seq <= the stale value got deduped server-
    # side — chat looked silently broken.
    host_id: str | None = None

    # ------------------------------------------------------------------
    # Path helpers
    # ------------------------------------------------------------------

    @classmethod
    def default_path(cls, profile: str | None = None) -> Path:
        # Test stubs may monkeypatch this with a (cls)-only lambda; the
        # call sites in ``load_default`` / ``save_default`` invoke us
        # without args for the default profile to preserve that.
        return profile_state_path(profile) if profile else profile_state_path(DEFAULT_PROFILE)

    # ------------------------------------------------------------------
    # LRU helpers
    # ------------------------------------------------------------------

    def add_processed(self, msg_id: str) -> None:
        """Append msg_id and enforce the LRU cap of 1024 (drop oldest)."""
        self.processed_message_ids.append(msg_id)
        if len(self.processed_message_ids) > _LRU_CAP:
            self.processed_message_ids = self.processed_message_ids[-_LRU_CAP:]

    def has_processed(self, msg_id: str) -> bool:
        return msg_id in self.processed_message_ids

    # ------------------------------------------------------------------
    # Host fingerprint
    # ------------------------------------------------------------------

    def adopt_host_id(self, host_id: str) -> str | None:
        """Adopt host_id, resetting seq/dedupe state on mismatch.

        Returns the previous ``host_id`` if a reset happened, else
        ``None``. ``None`` covers three cases: empty input (caller hasn't
        learned the id yet), first-ever adoption (state predates this
        field — keep existing seq), or no-op (id matches current).
        """
        if not host_id:
            return None
        if self.host_id is None:
            self.host_id = host_id
            return None
        if self.host_id == host_id:
            return None
        prev = self.host_id
        self.host_id = host_id
        self.last_seq = 0
        self.processed_message_ids = []
        return prev

    # ------------------------------------------------------------------
    # IO
    # ------------------------------------------------------------------

    @classmethod
    def load(cls, path: Path) -> Self:
        if not path.exists():
            raise FileNotFoundError(f"State file not found: {path}")
        return cls.model_validate(json.loads(path.read_text()))

    @classmethod
    def load_default(cls, profile: str | None = None) -> Self:
        path = (
            cls.default_path()
            if not profile or profile == DEFAULT_PROFILE
            else cls.default_path(profile)
        )
        return cls.load(path)

    def save(self, path: Path) -> None:
        _atomic_write_json(path, self.model_dump())

    def save_default(self, profile: str | None = None) -> None:
        path = (
            self.default_path()
            if not profile or profile == DEFAULT_PROFILE
            else self.default_path(profile)
        )
        self.save(path)
