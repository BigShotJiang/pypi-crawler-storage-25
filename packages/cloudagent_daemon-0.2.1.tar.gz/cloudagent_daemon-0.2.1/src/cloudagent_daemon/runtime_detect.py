"""Detect AI coding runtimes installed on the user's machine.

Two-stage scan:
  1. ``shutil.which`` against the daemon process PATH (set by the service
     wrapper to include ~/.local/bin, /opt/homebrew/bin, etc.).
  2. Well-known per-user directories that no static PATH can cover —
     primarily Node-version-manager dirs (nvm, fnm, volta) where the
     version segment is dynamic.

Captures version via ``<binary> --version`` (or equivalent) and returns a
list of ``DetectedRuntime`` objects for the WS ``ready`` frame.

Spec: docs/superpowers/specs/2026-05-08-local-daemon-runtime-design.md §4.3
"""
from __future__ import annotations

import glob
import os
import shutil
import subprocess
from dataclasses import dataclass, asdict


@dataclass(frozen=True)
class DetectedRuntime:
    name: str
    version: str
    binary: str

    def to_payload(self) -> dict:
        return asdict(self)


# (canonical_name, [binary candidates in priority order], [version-args])
_PROBES: list[tuple[str, list[str], list[str]]] = [
    ("claude_code",  ["claude", "claude-code"],     ["--version"]),
    ("codex",        ["codex"],                     ["--version"]),
    ("opencode",     ["opencode", "open-code"],     ["version"]),
    ("aider",        ["aider"],                     ["--version"]),
    ("cursor_agent", ["cursor-agent"],              ["--version"]),
    ("gemini_cli",   ["gemini"],                    ["--version"]),
    ("gh_copilot",   ["gh"],                        ["copilot", "--version"]),
]


# Stable user-local bin directories. Plist/systemd PATH covers the common
# cases (~/.local/bin etc.), but listing them here too means we still find
# tools when the user installed the daemon before this PATH change shipped.
_EXTRA_DIRS: list[str] = [
    "~/.local/bin",
    "~/bin",
    "~/.npm-global/bin",
    "~/.volta/bin",
    "~/.bun/bin",
    "~/.yarn/bin",
    "~/.local/share/pnpm",
    "~/.pnpm-global/bin",
    "~/Library/pnpm",
]

# Dynamic per-version dirs that no static PATH can express. Globs are
# expanded at scan time; missing dirs are silently skipped.
_EXTRA_GLOBS: list[str] = [
    "~/.nvm/versions/node/*/bin",
    "~/.fnm/node-versions/*/installation/bin",
    "~/.local/share/fnm/node-versions/*/installation/bin",
    "~/Library/Application Support/fnm/node-versions/*/installation/bin",
    "~/.asdf/installs/nodejs/*/bin",
]


def _expand_search_dirs() -> list[str]:
    """Resolve _EXTRA_DIRS + _EXTRA_GLOBS to absolute, existing dir paths.

    Order matters — earlier entries win in case the same binary appears
    in multiple locations. _EXTRA_DIRS comes before glob expansions so
    user-stable installs beat version-manager fallbacks; within glob
    expansions, ``sorted`` puts the highest version last so we pick it.
    """
    found: list[str] = []
    for d in _EXTRA_DIRS:
        p = os.path.expanduser(d)
        if os.path.isdir(p):
            found.append(p)
    for pattern in _EXTRA_GLOBS:
        expanded = os.path.expanduser(pattern)
        for p in sorted(glob.glob(expanded)):
            if os.path.isdir(p):
                found.append(p)
    return found


def _find_in_extra_dirs(binary_name: str, search_dirs: list[str]) -> str | None:
    """Return absolute path of ``binary_name`` if found in any search_dir."""
    for d in search_dirs:
        candidate = os.path.join(d, binary_name)
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _capture_version(binary: str, args: list[str], timeout: float) -> str:
    try:
        r = subprocess.run(
            [binary, *args],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        return "unknown"
    out = (r.stdout or "") + (r.stderr or "")
    first_line = out.strip().splitlines()[0] if out.strip() else ""
    return first_line[:64] if first_line else "unknown"


def detect_runtimes(timeout: float = 5.0) -> list[DetectedRuntime]:
    """Scan PATH + well-known dirs for each known runtime; return all detected.

    First binary candidate per name wins (alias resolution). Probes that fail
    to produce a version string still register the runtime with version="unknown".
    """
    extra_dirs = _expand_search_dirs()
    found: list[DetectedRuntime] = []
    for name, candidates, version_args in _PROBES:
        for binary_name in candidates:
            path = shutil.which(binary_name) or _find_in_extra_dirs(
                binary_name, extra_dirs
            )
            if path:
                version = _capture_version(path, version_args, timeout)
                found.append(DetectedRuntime(name=name, version=version, binary=path))
                break  # first candidate wins per name
    return found
