"""Login verification logic for cloudagent-daemon.

Separated from cli.py for testability.
"""
from __future__ import annotations


async def verify_and_capture_host_id(
    server_url: str,
    api_key: str,
    *,
    insecure: bool = False,
) -> str:
    """Open a quick WS connection to verify key, capture host_id, then close.

    Raises AuthFailed if 401/403; raises RuntimeError on other connect failures.

    ``insecure=True`` skips TLS certificate verification — only use for known
    self-signed dev/staging hosts (e.g. fr pre-Wave-7).
    """
    from .ws_client import WSClient

    async with WSClient(server_url, api_key, insecure=insecure) as ws:
        return ws.host_id


def normalize_server_url(url: str) -> str:
    """Trim trailing /, strip /v1 suffix if present, validate http(s) scheme."""
    url = url.rstrip("/")
    if url.endswith("/v1"):
        url = url[:-3]
    if not url.startswith(("http://", "https://")):
        raise ValueError(f"server URL must start with http:// or https://: {url!r}")
    return url
