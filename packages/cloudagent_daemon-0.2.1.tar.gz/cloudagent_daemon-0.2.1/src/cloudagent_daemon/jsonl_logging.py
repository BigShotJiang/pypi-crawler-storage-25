"""Wave C #3 — opt-in JSONL log formatter.

Default off (preserves the grep-based ops flow over launchd.err.log).
When ``CLOUDAGENT_DAEMON_JSON_LOG=1`` is exported BEFORE the daemon
starts, every log record is rendered as a single-line JSON object —
key tokens (``msg`` / ``level`` / ``name``) still appear so existing
``grep frame_dispatch`` -style searches keep working.

Schema (one object per line)::

  {"ts": "2026-05-12T10:31:53Z", "level": "INFO",
   "name": "cloudagent_daemon.main_loop",
   "msg": "daemon ready: host_id=...", "pid": 51624,
   "thread": "MainThread"}

If a log record carries ``extra={"event": ...}`` style fields, those
are merged into the top-level object (e.g. structured spawn events).
"""
from __future__ import annotations

import json
import logging
import os
import threading
from datetime import UTC, datetime


_ENV_VAR = "CLOUDAGENT_DAEMON_JSON_LOG"


class JsonlFormatter(logging.Formatter):
    """One-line JSON per record."""

    def format(self, record: logging.LogRecord) -> str:
        # Parity with :class:`logging.Formatter.format` — set
        # ``record.message`` so downstream tooling (pytest's caplog,
        # third-party Sentry hooks) that reads the attribute keeps
        # working after the formatter runs.
        record.message = record.getMessage()
        # Build the canonical envelope first so the order is stable
        # across records — easier on humans tailing the log.
        out: dict = {
            "ts": datetime.now(UTC).isoformat(),
            "level": record.levelname,
            "name": record.name,
            "msg": record.message,
            "pid": os.getpid(),
            "thread": threading.current_thread().name,
        }
        if record.exc_info:
            out["exc"] = self.formatException(record.exc_info)
        # Merge any structured extras carried on the record. ``record.__dict__``
        # contains a fixed set of LogRecord fields + whatever ``extra=``
        # caller passed; we keep only the latter.
        reserved = {
            "name", "msg", "args", "levelname", "levelno", "pathname",
            "filename", "module", "exc_info", "exc_text", "stack_info",
            "lineno", "funcName", "created", "msecs", "relativeCreated",
            "thread", "threadName", "processName", "process", "message",
        }
        for key, value in record.__dict__.items():
            if key in reserved or key in out:
                continue
            try:
                json.dumps(value)
                out[key] = value
            except (TypeError, ValueError):
                # Non-JSON-able extras get a string repr — never drop
                # them silently, an operator may need that hint.
                out[key] = repr(value)
        return json.dumps(out, ensure_ascii=False)


def jsonl_logging_enabled() -> bool:
    """Return True when the env switch is set."""
    return os.environ.get(_ENV_VAR, "").lower() in ("1", "true", "yes")


def configure_logging() -> None:
    """Apply :class:`JsonlFormatter` to the root logger if env enables it.

    Called from ``cli.start`` AFTER ``logging.basicConfig`` so we can
    safely overwrite the default formatter on the root logger's
    first (and only) handler.
    """
    if not jsonl_logging_enabled():
        return
    root = logging.getLogger()
    fmt = JsonlFormatter()
    for h in root.handlers:
        h.setFormatter(fmt)


__all__ = [
    "JsonlFormatter",
    "configure_logging",
    "jsonl_logging_enabled",
]
