"""WebSocket frame schemas — vendored from backend/src/cloudagent/services/daemon_protocol.py.

Spec: docs/superpowers/specs/2026-05-08-local-daemon-runtime-design.md §4

Vendored (not imported from backend) so daemon_cli can be installed
independently. If a schema changes on the backend, update this file
in lock-step. A bigger Phase 2 refactor moves these to a shared package.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel

# ---- Payload models ----

class HelloAgentEntry(BaseModel):
    agent_id: str
    claude_session_id: str | None = None
    runtime_config: dict[str, Any] | None = None


class HelloPayload(BaseModel):
    host_id: str
    agents: list[HelloAgentEntry]


class ReadyPayload(BaseModel):
    daemon_ver: str
    runtimes: list[dict[str, Any]]
    hostname: str
    os: str


class AssignPayload(BaseModel):
    agent_id: str
    claude_session_id: str | None = None


class UnassignPayload(BaseModel):
    agent_id: str
    reason: str


class DeliverPayload(BaseModel):
    agent_id: str
    session_id: str
    message_id: str
    kind: str
    body: str
    sender: str
    target: str


class DeliveryAckPayload(BaseModel):
    seq: int
    message_id: str
    status: Literal["received", "started", "failed", "queue_full"]
    retry_after_ms: int | None = None


class ToolCallPayload(BaseModel):
    request_id: str
    agent_id: str
    session_id: str | None = None
    tool_name: str
    args: dict[str, Any]


class ToolResultPayload(BaseModel):
    request_id: str
    ok: bool
    data: dict[str, Any] | None = None
    error: dict[str, Any] | None = None


class AgentSessionStartPayload(BaseModel):
    agent_id: str
    claude_session_id: str
    workdir_path: str | None = None


class AgentStatusPayload(BaseModel):
    agent_id: str
    status: Literal["running", "idle", "crashed", "quarantined", "backpressure_dropped"]
    exit_code: int | None = None
    error: str | None = None


class PingPayload(BaseModel):
    pass  # empty payload


class PongPayload(BaseModel):
    pass


class ByePayload(BaseModel):
    reason: str


# ---- Frame envelope ----

FrameType = Literal[
    "hello", "ready", "assign", "unassign",
    "deliver", "delivery_ack",
    "tool_call", "tool_result",
    "agent_session_start", "agent_status",
    "ping", "pong", "bye",
]

_PAYLOAD_TYPES = {
    "hello": HelloPayload, "ready": ReadyPayload,
    "assign": AssignPayload, "unassign": UnassignPayload,
    "deliver": DeliverPayload, "delivery_ack": DeliveryAckPayload,
    "tool_call": ToolCallPayload, "tool_result": ToolResultPayload,
    "agent_session_start": AgentSessionStartPayload,
    "agent_status": AgentStatusPayload,
    "ping": PingPayload, "pong": PongPayload, "bye": ByePayload,
}


class Frame(BaseModel):
    v: Literal[1]
    type: FrameType
    id: str
    ts: datetime
    seq: int | None = None
    payload: Any  # validated post-init

    def model_post_init(self, _ctx: Any) -> None:
        cls = _PAYLOAD_TYPES.get(self.type)
        if cls is None:
            raise ValueError(f"unknown frame type: {self.type}")
        if not isinstance(self.payload, cls):
            self.payload = cls.model_validate(self.payload)


def parse_frame(raw: dict[str, Any]) -> Frame:
    return Frame.model_validate(raw)
