"""Wave C #3 — minimal unix-socket HTTP server exposing ``/metrics``.

Why unix socket instead of TCP HTTP:
  * No port allocation surprises on user machines (laptops behind
    pf/firewall rules can't reliably open arbitrary listening ports).
  * Permissioned by filesystem (``0o600``) — only the daemon-owning
    user can scrape. No need for a separate auth scheme.
  * Prometheus 2.x supports unix socket scraping natively
    (``-target=unix:///path/to/sock``) and ``curl --unix-socket`` is
    a one-liner for ad-hoc operator inspection.

Why we don't reuse ``bridge.sock``:
  * That socket speaks line-delimited JSON to mcp_bridge subprocesses.
    Mixing protocols invites bugs; a second socket is cheap.
  * Decoupling lets us shut down ``bridge.sock`` independently if a
    future refactor moves the mcp bridge into its own process tree.

Wire format (server response):

::

  HTTP/1.1 200 OK\r\n
  Content-Type: text/plain; version=0.0.4; charset=utf-8\r\n
  Content-Length: <n>\r\n
  Connection: close\r\n
  \r\n
  <prometheus text>

Request parsing is intentionally permissive: we ignore the path and
respond to ANY connection with the metrics body. This keeps the server
3 dozen lines and avoids re-implementing HTTP. A caller that opens the
socket and immediately reads (e.g. ``curl --unix-socket sock http://x/``)
gets a valid HTTP response either way.
"""
from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path

from cloudagent_daemon.metrics import MetricsRegistry

logger = logging.getLogger(__name__)

# Default location. The daemon's pid + state live in the same dir so
# operators inspecting one usually want the other.
DEFAULT_METRICS_SOCKET_PATH = (
    Path.home() / ".cloudagent" / "daemon" / "metrics.sock"
)


class MetricsServer:
    """Unix-socket HTTP-ish responder serving Prometheus text format."""

    def __init__(
        self,
        registry: MetricsRegistry,
        *,
        socket_path: Path | None = None,
    ) -> None:
        self._registry = registry
        self._socket_path = Path(socket_path or DEFAULT_METRICS_SOCKET_PATH)
        self._server: asyncio.base_events.Server | None = None

    @property
    def socket_path(self) -> Path:
        return self._socket_path

    async def start(self) -> None:
        if self._socket_path.exists():
            # Stale socket from a crashed process.
            try:
                self._socket_path.unlink()
            except OSError:  # pragma: no cover — race with another daemon
                logger.warning(
                    "metrics_server: could not unlink stale socket %s",
                    self._socket_path,
                )
        self._socket_path.parent.mkdir(parents=True, exist_ok=True)
        self._server = await asyncio.start_unix_server(
            self._handle_connection, path=str(self._socket_path)
        )
        try:
            os.chmod(self._socket_path, 0o600)
        except OSError:  # pragma: no cover — exotic filesystems
            logger.warning(
                "metrics_server: chmod 0o600 failed on %s",
                self._socket_path,
            )

    async def stop(self) -> None:
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
        try:
            if self._socket_path.exists():
                self._socket_path.unlink()
        except OSError:  # pragma: no cover
            pass

    async def _handle_connection(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        try:
            # Drain the request lines until \r\n\r\n. We don't actually
            # parse anything; we just need to consume the request before
            # writing the response so the client doesn't see a half-open
            # write.
            try:
                while True:
                    line = await asyncio.wait_for(
                        reader.readuntil(b"\r\n"),
                        timeout=2.0,
                    )
                    if line in (b"\r\n", b""):
                        break
            except asyncio.TimeoutError:
                logger.debug("metrics_server: request read timeout — serving anyway")
            except asyncio.IncompleteReadError:
                pass  # client hung up; that's fine, write response anyway

            body = self._registry.render_prometheus_text().encode("utf-8")
            response = (
                b"HTTP/1.1 200 OK\r\n"
                b"Content-Type: text/plain; version=0.0.4; charset=utf-8\r\n"
                b"Content-Length: " + str(len(body)).encode("ascii") + b"\r\n"
                b"Connection: close\r\n"
                b"\r\n"
            ) + body
            writer.write(response)
            try:
                await writer.drain()
            except (ConnectionResetError, BrokenPipeError):
                # Scraper hung up before we finished — common with
                # ``curl --unix-socket`` short-lived connections.
                pass
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:  # noqa: BLE001
                pass


__all__ = ["MetricsServer", "DEFAULT_METRICS_SOCKET_PATH"]
