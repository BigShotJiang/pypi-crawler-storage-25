"""Outbound frame queue for the cloudagent daemon.

Serializes all outgoing daemon→server sends through a lock (concurrent
spawn supervisors may call simultaneously — must avoid interleaved JSON
on the wire). Also provides high-level helpers for each outbound frame
type. The actual wire (WebSocket vs HTTP-POST) is hidden behind a
``Transport`` protocol — see ``transport.py``.

Spec §4.2 / §4.3.

Design note on pending_tool_calls ownership
-------------------------------------------
OutboundQueue creates and owns ``pending_tool_calls``.  FrameDispatcher
accepts it via its ``tool_result_pending`` constructor parameter so that
incoming ``tool_result`` frames resolve the same futures that
``send_tool_call`` is awaiting.  Caller wires them together::

    oq = OutboundQueue(transport)
    dispatcher = FrameDispatcher(..., tool_result_pending=oq.pending_tool_calls)
"""
from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING
from uuid import uuid4

if TYPE_CHECKING:
    from cloudagent_daemon.transport import Transport

logger = logging.getLogger(__name__)


def _new_frame_id() -> str:
    return f"frm_{uuid4().hex[:16]}"


def _new_request_id() -> str:
    return f"req_{uuid4().hex}"


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


class OutboundQueue:
    """Serialize outbound frames and provide frame-type helpers.

    Parameters
    ----------
    transport:
        A ``Transport`` (WS or HTTP) — anything with
        ``async send_frame(frame: dict)``. ``None`` is allowed for
        construction-before-connect; sends will raise until ``transport``
        is rebound. Tests may pass a fake with a ``send`` method via the
        legacy positional ``ws=`` keyword for back-compat (deprecated;
        prefer ``transport=``).
    default_tool_call_timeout:
        Seconds to wait for a ``tool_result`` before returning a synthetic
        ``SERVER_TIMEOUT`` response.
    """

    def __init__(
        self,
        transport: "Transport | None" = None,
        *,
        ws: object = None,  # legacy alias — accepts old WSClient or test
                            # FakeWS objects with .send(frame)
        default_tool_call_timeout: float = 30.0,
        pending_tool_calls: dict[str, asyncio.Future] | None = None,
    ) -> None:
        # Back-compat: pre-1j call-sites and unit tests pass a WSClient or
        # FakeWS as the first positional arg. Detect that shape (has
        # ``send`` but no ``send_frame``) and wrap it with the legacy
        # adapter so existing tests keep passing without edits.
        if transport is not None and not hasattr(transport, "send_frame"):
            if hasattr(transport, "send"):
                transport = _LegacyWSAdapter(transport)
            else:
                # Anything else is a programming error — let it fail loudly
                # downstream rather than silently produce a broken queue.
                pass
        if transport is None and ws is not None:
            transport = _LegacyWSAdapter(ws)
        self.transport: "Transport | None" = transport
        self.default_tool_call_timeout = default_tool_call_timeout
        self._send_lock = asyncio.Lock()
        # Shared with FrameDispatcher — see module docstring. Accepting it as
        # a constructor parameter lets ``main_loop.run_daemon`` build the dict
        # once and pass the same instance to both the dispatcher and the
        # outbound queue, avoiding a "rebind on connect" dance for the dict.
        self.pending_tool_calls: dict[str, asyncio.Future] = (
            pending_tool_calls if pending_tool_calls is not None else {}
        )

    @property
    def ws(self) -> object:
        """Legacy alias kept for ``main_loop._on_connect`` compatibility.

        Reads return the underlying WSClient when running on the legacy
        WS transport; ``None`` for HTTP/SSE or before connect. Writes
        rebind the transport via ``_LegacyWSAdapter`` so existing
        ``outbound.ws = client`` call-sites keep working unchanged.
        """
        if isinstance(self.transport, _LegacyWSAdapter):
            return self.transport._ws
        return None

    @ws.setter
    def ws(self, value: object) -> None:
        if value is None:
            self.transport = None
            return
        # If the caller hands us something that already looks like a
        # Transport (has ``send_frame``), use it directly. Otherwise
        # adapt a WSClient-shaped object.
        if hasattr(value, "send_frame"):
            self.transport = value  # type: ignore[assignment]
        else:
            self.transport = _LegacyWSAdapter(value)

    # ------------------------------------------------------------------
    # High-level helpers
    # ------------------------------------------------------------------

    async def send_ack(
        self,
        seq: int | None,
        message_id: str,
        status: str,
        retry_after_ms: int | None = None,
    ) -> None:
        """Send a ``delivery_ack`` frame.

        *seq=None* for non-deliver acks; the field is omitted from the
        payload in that case (backend accepts missing seq).
        """
        payload: dict = {"message_id": message_id, "status": status}
        if seq is not None:
            payload["seq"] = seq
        if retry_after_ms is not None:
            payload["retry_after_ms"] = retry_after_ms

        await self.send_raw({
            "v": 1,
            "type": "delivery_ack",
            "id": _new_frame_id(),
            "ts": _now_iso(),
            "payload": payload,
        })

    async def send_agent_status(
        self,
        agent_id: str,
        status: str,
        exit_code: int | None = None,
    ) -> None:
        """Send an ``agent_status`` frame."""
        payload: dict = {"agent_id": agent_id, "status": status}
        if exit_code is not None:
            payload["exit_code"] = exit_code

        await self.send_raw({
            "v": 1,
            "type": "agent_status",
            "id": _new_frame_id(),
            "ts": _now_iso(),
            "payload": payload,
        })

    async def send_agent_session_start(
        self,
        agent_id: str,
        claude_session_id: str,
        workdir_path: str | None = None,
    ) -> None:
        """Send an ``agent_session_start`` frame."""
        payload: dict = {"agent_id": agent_id, "claude_session_id": claude_session_id}
        if workdir_path:
            payload["workdir_path"] = workdir_path

        await self.send_raw({
            "v": 1,
            "type": "agent_session_start",
            "id": _new_frame_id(),
            "ts": _now_iso(),
            "payload": payload,
        })

    async def send_tool_call(
        self,
        agent_id: str,
        session_id: str | None,
        tool_name: str,
        args: dict,
        *,
        timeout: float | None = None,
    ) -> dict:
        """Send a ``tool_call`` frame and await the matching ``tool_result``.

        Returns the tool_result payload dict on success.
        On timeout returns a synthetic error::

            {"request_id": rid, "ok": False, "error": {"code": "SERVER_TIMEOUT"}}
        """
        effective_timeout = timeout if timeout is not None else self.default_tool_call_timeout
        rid = _new_request_id()

        loop = asyncio.get_running_loop()
        fut: asyncio.Future = loop.create_future()
        self.pending_tool_calls[rid] = fut

        # 1k #55 — fine-grained observability for the multi-tool wake bug.
        # Logs at every state transition let us reconstruct timing of
        # concurrent calls (rid is unique so log lines are unambiguous).
        logger.info(
            "outbound_queue: send_tool_call ENTER tool=%s agent=%s rid=%s "
            "pending_count=%d",
            tool_name, agent_id, rid, len(self.pending_tool_calls),
        )

        await self.send_raw({
            "v": 1,
            "type": "tool_call",
            "id": _new_frame_id(),
            "ts": _now_iso(),
            "payload": {
                "request_id": rid,
                "agent_id": agent_id,
                "session_id": session_id,
                "tool_name": tool_name,
                "args": args,
            },
        })
        logger.info(
            "outbound_queue: send_tool_call SENT rid=%s — awaiting tool_result",
            rid,
        )

        try:
            result = await asyncio.wait_for(fut, timeout=effective_timeout)
            self.pending_tool_calls.pop(rid, None)
            logger.info(
                "outbound_queue: send_tool_call RESOLVED rid=%s ok=%s "
                "pending_count=%d",
                rid, result.get("ok"), len(self.pending_tool_calls),
            )
            return result
        except asyncio.TimeoutError:
            self.pending_tool_calls.pop(rid, None)
            logger.warning(
                "outbound_queue: send_tool_call TIMEOUT rid=%s after %.1fs "
                "pending_count=%d",
                rid, effective_timeout, len(self.pending_tool_calls),
            )
            return {
                "request_id": rid,
                "ok": False,
                "error": {"code": "SERVER_TIMEOUT"},
            }

    async def send_raw(self, frame: dict) -> None:
        """Lock-protected raw send. All other helpers call this."""
        async with self._send_lock:
            if self.transport is None:
                # Daemon constructed the outbound queue but is not yet
                # connected (or just disconnected). Surface a clear error
                # rather than ``AttributeError`` on .send.
                raise RuntimeError("OutboundQueue.transport is not bound")
            await self.transport.send_frame(frame)


class _LegacyWSAdapter:
    """Adapt a WSClient (or test fake with ``async send(frame)``) to Transport.

    This keeps the unit tests in ``test_outbound_queue.py`` and the legacy
    ``main_loop`` WS path running while new code uses Transport directly.
    """

    def __init__(self, ws: object) -> None:
        self._ws = ws

    async def send_frame(self, frame: dict) -> None:
        await self._ws.send(frame)  # type: ignore[attr-defined]

    async def close(self) -> None:
        # Lifecycle owned elsewhere — see ``WSTransport.close`` rationale.
        return
