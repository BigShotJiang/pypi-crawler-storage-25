"""Install/uninstall daemon as a system service.

macOS: launchd User Agent (~/Library/LaunchAgents/chat.cloudagent.daemon.plist)
Linux: systemd user service (~/.config/systemd/user/cloudagent-daemon.service)

Both configured with KeepAlive/Restart=always so the daemon auto-restarts
on crash, and starts automatically at user login.

Per 1k #61 — Phase 1 commitment: "the daemon never self-exits unless the
user actively stops it." The OS supervisor (launchd / systemd) is the
ultimate safety net; if our async loop ever crashes, the OS brings the
process back within seconds.
"""
from __future__ import annotations

import os
import platform
import shutil
import subprocess
from pathlib import Path

from .paths import (
    DEFAULT_PROFILE,
    ENV_VAR,
    profile_launchd_label,
    profile_log_dir,
    profile_systemd_unit_name,
    resolve_profile,
)

# Default-profile identifiers — preserved as module-level constants so
# existing tests / external callers (`grep -rn "LAUNCHD_LABEL"`) keep
# working. ``profile_launchd_label("fr")`` etc. produce the per-profile
# variants.
LAUNCHD_LABEL = profile_launchd_label(DEFAULT_PROFILE)
SYSTEMD_NAME = profile_systemd_unit_name(DEFAULT_PROFILE)


def detect_platform() -> str:
    """Return ``"macos"`` or ``"linux"``; raise on unsupported OS."""
    s = platform.system().lower()
    if s == "darwin":
        return "macos"
    if s == "linux":
        return "linux"
    raise RuntimeError(f"Unsupported platform for service install: {s}")


def _binary_path() -> str:
    """Locate the cloudagent-daemon binary on PATH.

    Both launchd and systemd require an absolute path — they don't see the
    user's interactive shell PATH. We fail loudly here rather than write a
    broken unit file that silently no-ops on every restart.
    """
    p = shutil.which("cloudagent-daemon")
    if p is None:
        raise RuntimeError(
            "cloudagent-daemon not found on PATH. Install first: "
            "uv tool install cloudagent-daemon"
        )
    return p


# ---------- macOS launchd ----------


def _launchd_plist_path(profile: str | None = None) -> Path:
    label = profile_launchd_label(profile)
    return Path.home() / "Library" / "LaunchAgents" / f"{label}.plist"


def _launchd_plist_content(
    server_url: str | None,
    api_key: str | None,
    insecure: bool,
    workspace_root: str | None = None,
    profile: str | None = None,
) -> str:
    """Render the plist XML.

    If ``server_url`` + ``api_key`` are passed they go on the command line
    (one-shot mode). Otherwise the plist relies on the per-profile
    ``config.json`` having been populated via ``cloudagent-daemon login``.

    Task #115 (2026-05-12) — ``workspace_root`` (when supplied) lands as
    ``--workspace-root <abs path>`` so users can ``install-service
    --workspace-root ~/projects/myapp`` in one go instead of the prior
    uninstall→start→Ctrl-C→install dance.

    M6 multi-profile (2026-05-18) — *profile* (when non-default) is
    baked into ProgramArguments as ``--profile <name>`` and exposed to
    the spawned process via the ``CLOUDAGENT_DAEMON_PROFILE`` env so
    children (mcp_bridge subprocess) inherit the active profile. The
    default profile produces a plist byte-for-byte identical to the
    pre-multi-profile output — that is the zero-migration guarantee.
    """
    profile_name = resolve_profile(profile)
    label = profile_launchd_label(profile_name)
    binary = _binary_path()
    args: list[str] = [binary, "start"]
    if server_url and api_key:
        args += ["--server-url", server_url, "--api-key", api_key]
    if insecure:
        args += ["--insecure"]
    if workspace_root:
        args += ["--workspace-root", workspace_root]
    if profile_name != DEFAULT_PROFILE:
        args += ["--profile", profile_name]

    args_xml = "\n".join(f"        <string>{a}</string>" for a in args)
    home = str(Path.home())
    log_dir = str(profile_log_dir(profile_name))

    profile_env = ""
    if profile_name != DEFAULT_PROFILE:
        profile_env = (
            f"        <key>{ENV_VAR}</key>\n"
            f"        <string>{profile_name}</string>\n"
        )

    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTD/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{label}</string>
    <key>ProgramArguments</key>
    <array>
{args_xml}
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log_dir}/launchd.out.log</string>
    <key>StandardErrorPath</key>
    <string>{log_dir}/launchd.err.log</string>
    <key>WorkingDirectory</key>
    <string>{home}</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>{home}/.local/bin:{home}/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin</string>
        <key>NO_PROXY</key>
        <string>*</string>
        <!-- Python defaults to block-buffered stdout when not a tty (launchd
             redirects to a file → not a tty). Setting this forces line-buffered
             stdout/stderr so ``typer.echo("Detected runtimes:...")`` and other
             single-line status messages land in launchd.out.log immediately
             instead of sitting in an 8 KB buffer until the process exits. -->
        <key>PYTHONUNBUFFERED</key>
        <string>1</string>
{profile_env}    </dict>
</dict>
</plist>
"""


def install_macos(
    server_url: str | None,
    api_key: str | None,
    insecure: bool,
    workspace_root: str | None = None,
    profile: str | None = None,
) -> Path:
    """Install + load + start the launchd user agent for *profile*."""
    profile_name = resolve_profile(profile)
    label = profile_launchd_label(profile_name)
    plist_path = _launchd_plist_path(profile_name)
    plist_path.parent.mkdir(parents=True, exist_ok=True)
    log_dir = profile_log_dir(profile_name)
    log_dir.mkdir(parents=True, exist_ok=True)

    content = _launchd_plist_content(
        server_url, api_key, insecure, workspace_root, profile=profile_name
    )
    plist_path.write_text(content)
    plist_path.chmod(0o600)

    uid = os.getuid()
    # Bootstrap into launchd (modern API). ``check=False`` because the
    # service may already be loaded — bootout/kickstart below will recover.
    subprocess.run(
        ["launchctl", "bootstrap", f"gui/{uid}", str(plist_path)],
        check=False,
    )
    # Kickstart -k forces an immediate (re)start.
    subprocess.run(
        ["launchctl", "kickstart", "-k", f"gui/{uid}/{label}"],
        check=False,
    )
    return plist_path


def uninstall_macos(profile: str | None = None) -> bool:
    """Stop + bootout + remove plist. Returns True if removed, False if not present."""
    profile_name = resolve_profile(profile)
    label = profile_launchd_label(profile_name)
    plist_path = _launchd_plist_path(profile_name)
    if not plist_path.exists():
        return False
    subprocess.run(
        ["launchctl", "bootout", f"gui/{os.getuid()}/{label}"],
        check=False,
    )
    plist_path.unlink(missing_ok=True)
    return True


# ---------- Linux systemd ----------


def _systemd_unit_path(profile: str | None = None) -> Path:
    name = profile_systemd_unit_name(profile)
    return Path.home() / ".config" / "systemd" / "user" / name


def _systemd_unit_content(
    server_url: str | None,
    api_key: str | None,
    insecure: bool,
    workspace_root: str | None = None,
    profile: str | None = None,
) -> str:
    profile_name = resolve_profile(profile)
    binary = _binary_path()
    cmd: list[str] = [binary, "start"]
    if server_url and api_key:
        cmd += ["--server-url", server_url, "--api-key", api_key]
    if insecure:
        cmd += ["--insecure"]
    if workspace_root:
        # Task #115 — mirror the launchd plist's --workspace-root surface.
        cmd += ["--workspace-root", workspace_root]
    if profile_name != DEFAULT_PROFILE:
        cmd += ["--profile", profile_name]

    home = str(Path.home())
    # Mirror the macOS plist PATH so systemd-managed daemons can shutil.which()
    # CLIs installed via uv/pipx (~/.local/bin), ~/bin user scripts, distro
    # /usr/local/bin, and standard system dirs. systemd doesn't expand
    # ~ in unit files — substitute the absolute home path at install time.
    daemon_path = (
        f"{home}/.local/bin:{home}/bin:/usr/local/bin:/usr/bin:/bin"
    )

    profile_env_line = (
        f"Environment={ENV_VAR}={profile_name}\n"
        if profile_name != DEFAULT_PROFILE
        else ""
    )

    return f"""[Unit]
Description=cloudagent local daemon
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={" ".join(cmd)}
Restart=always
RestartSec=5
Environment=NO_PROXY=*
Environment=PATH={daemon_path}
# Force line-buffered stdout — see launchd plist comment for rationale.
Environment=PYTHONUNBUFFERED=1
{profile_env_line}
[Install]
WantedBy=default.target
"""


def install_linux(
    server_url: str | None,
    api_key: str | None,
    insecure: bool,
    workspace_root: str | None = None,
    profile: str | None = None,
) -> Path:
    profile_name = resolve_profile(profile)
    unit_name = profile_systemd_unit_name(profile_name)
    unit_path = _systemd_unit_path(profile_name)
    unit_path.parent.mkdir(parents=True, exist_ok=True)
    unit_path.write_text(
        _systemd_unit_content(
            server_url, api_key, insecure, workspace_root, profile=profile_name
        )
    )
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
    subprocess.run(
        ["systemctl", "--user", "enable", "--now", unit_name],
        check=False,
    )
    return unit_path


def uninstall_linux(profile: str | None = None) -> bool:
    profile_name = resolve_profile(profile)
    unit_name = profile_systemd_unit_name(profile_name)
    unit_path = _systemd_unit_path(profile_name)
    if not unit_path.exists():
        return False
    subprocess.run(
        ["systemctl", "--user", "disable", "--now", unit_name],
        check=False,
    )
    unit_path.unlink(missing_ok=True)
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
    return True


# ---------- Cross-platform dispatchers ----------


def install_service(
    server_url: str | None = None,
    api_key: str | None = None,
    insecure: bool = False,
    workspace_root: str | None = None,
    profile: str | None = None,
) -> Path:
    plat = detect_platform()
    if plat == "macos":
        return install_macos(
            server_url, api_key, insecure, workspace_root, profile=profile
        )
    return install_linux(
        server_url, api_key, insecure, workspace_root, profile=profile
    )


def uninstall_service(profile: str | None = None) -> bool:
    plat = detect_platform()
    if plat == "macos":
        return uninstall_macos(profile=profile)
    return uninstall_linux(profile=profile)


__all__ = [
    "LAUNCHD_LABEL",
    "SYSTEMD_NAME",
    "detect_platform",
    "install_service",
    "uninstall_service",
    "install_macos",
    "install_linux",
    "uninstall_macos",
    "uninstall_linux",
    "_launchd_plist_content",
    "_systemd_unit_content",
    "_launchd_plist_path",
    "_systemd_unit_path",
]
