"""SpawnQueue: per-agent FIFO + global concurrency cap.

Implements spec §5 L4 (per-agent cap) and L5 (global concurrency cap).

Design
------
* One ``asyncio.Queue`` per agent_id, bounded by ``max_per_agent``.
* One drain task per agent — created on the first enqueue; exits when the
  agent queue empties; re-created if a new message arrives later.
* A single ``asyncio.Semaphore(max_concurrent)`` gates all concurrent
  ``runner.run_one`` calls across all agents.
"""
from __future__ import annotations

import asyncio
import logging
import math
import os
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cloudagent_daemon.spawn_outbox import SpawnOutbox

logger = logging.getLogger(__name__)


def _default_max_concurrent() -> int:
    return min(8, math.ceil((os.cpu_count() or 4) / 2))


class SpawnQueue:
    """Per-agent FIFO queue with a global concurrency cap.

    Parameters
    ----------
    runner:
        Any object with ``async def run_one(agent_id: str, payload: dict)``.
        The real implementation is ``ClaudeRunner`` (Task 9); tests use a fake.
    max_per_agent:
        Spec §5 L4 — maximum queued items per agent (default 100).
    max_concurrent:
        Spec §5 L5 — global concurrency cap. ``None`` defaults to
        ``min(8, ceil(cpu_count / 2))``.
    queue_full_callback:
        Called with ``(agent_id, message_id)`` when a per-agent queue is full
        so the daemon can ack the deliver as ``queue_full``.
    spawn_outbox:
        Optional; Bug 4 durable journal. When provided, every drained
        payload triggers :meth:`SpawnOutbox.record_done` after the
        runner returns (success or error) so the boot-replay path can
        tell the spawn finished. See ``spawn_outbox.py``.
    """

    def __init__(
        self,
        runner,
        *,
        max_per_agent: int = 100,
        max_concurrent: int | None = None,
        queue_full_callback: Callable[[str, str], Awaitable[None]] | None = None,
        spawn_outbox: "SpawnOutbox | None" = None,
    ) -> None:
        self.runner = runner
        self.max_per_agent = max_per_agent
        self.max_concurrent: int = max_concurrent or _default_max_concurrent()
        self.queue_full_callback = queue_full_callback
        self.spawn_outbox = spawn_outbox

        self._semaphore = asyncio.Semaphore(self.max_concurrent)
        # agent_id → asyncio.Queue
        self._queues: dict[str, asyncio.Queue] = {}
        # agent_id → running drain Task
        self._tasks: dict[str, asyncio.Task] = {}
        self._shutdown = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def enqueue(self, deliver_payload: dict) -> bool:
        """Queue a deliver payload for the agent.

        Returns
        -------
        True
            Item was accepted into the queue.
        False
            Per-agent queue is full; item was dropped (callback fired if set).
        """
        if self._shutdown:
            return False

        agent_id: str = deliver_payload["agent_id"]
        message_id: str = deliver_payload["message_id"]

        # Lazily create a per-agent queue.
        if agent_id not in self._queues:
            self._queues[agent_id] = asyncio.Queue(maxsize=self.max_per_agent)

        queue = self._queues[agent_id]

        try:
            queue.put_nowait(deliver_payload)
        except asyncio.QueueFull:
            logger.warning(
                "SpawnQueue: agent=%s queue full (cap=%d), dropping message=%s",
                agent_id,
                self.max_per_agent,
                message_id,
            )
            if self.queue_full_callback is not None:
                await self.queue_full_callback(agent_id, message_id)
            return False

        # 1i Bug C — Phase 1 demo visibility.
        logger.info(
            "spawn_queue: enqueued agent=%s msg=%s queue_depth=%d",
            agent_id,
            message_id,
            queue.qsize(),
        )

        # Ensure a drain task is running for this agent.
        existing = self._tasks.get(agent_id)
        if existing is None or existing.done():
            task = asyncio.create_task(
                self._drain(agent_id), name=f"drain-{agent_id}"
            )
            self._tasks[agent_id] = task

        return True

    async def shutdown(self) -> None:
        """Signal shutdown and wait for all in-flight drain tasks to finish."""
        self._shutdown = True
        tasks = list(self._tasks.values())
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def cancel_all(self) -> None:
        """Cancel all drain tasks immediately (used on SIGTERM for fast exit).

        Unlike ``shutdown()``, this does not wait for in-flight ``run_one``
        calls to complete — it cancels them. Use when a fast, clean exit is
        required (e.g., SIGTERM handling in the daemon start command).
        """
        self._shutdown = True
        tasks = list(self._tasks.values())
        for t in tasks:
            t.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _drain(self, agent_id: str) -> None:
        """Drain the per-agent queue until it is empty."""
        queue = self._queues[agent_id]
        while True:
            try:
                payload = queue.get_nowait()
            except asyncio.QueueEmpty:
                break

            msg_id = str(payload.get("message_id") or "")
            ok = True
            async with self._semaphore:
                try:
                    await self.runner.run_one(agent_id, payload)
                except Exception:
                    ok = False
                    logger.exception(
                        "SpawnQueue: runner.run_one raised for agent=%s", agent_id
                    )
                finally:
                    queue.task_done()
                    # Bug 4 — mark the spawn done in the outbox (regardless
                    # of runner outcome) so the boot replay path stops
                    # considering it pending. Failure to write the done
                    # marker is logged but non-fatal — next compact + next
                    # boot will re-enqueue, runner has its own dedupe.
                    if self.spawn_outbox is not None and msg_id:
                        try:
                            await self.spawn_outbox.record_done(
                                agent_id, msg_id, ok=ok
                            )
                        except Exception:
                            logger.exception(
                                "SpawnQueue: spawn_outbox.record_done failed "
                                "agent=%s msg=%s",
                                agent_id,
                                msg_id,
                            )

        # Remove self from the task registry so the next enqueue can
        # re-create a fresh drain task.
        self._tasks.pop(agent_id, None)
