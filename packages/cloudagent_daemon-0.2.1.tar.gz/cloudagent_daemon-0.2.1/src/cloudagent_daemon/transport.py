"""Transport abstraction for daemon→server frames.

Sub-plan 1j replaces the WebSocket with an SSE stream (server→daemon)
plus per-frame-type POST endpoints (daemon→server). Outbound senders
(``OutboundQueue``, ``ClaudeRunner``) shouldn't care which wire is used —
they call ``transport.send_frame(frame_dict)`` and let the implementation
route.

Two concrete transports today:
  * ``HTTPTransport`` — routes each frame ``type`` to the matching POST
    endpoint. Used in production with the SSE stream.
  * ``WSTransport`` — wraps a connected ``WSClient`` so the legacy
    ``--transport ws`` path still works through the same OutboundQueue.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from .http_outbound import HTTPOutbound
    from .ws_client import WSClient

logger = logging.getLogger(__name__)


class Transport(Protocol):
    """Sends daemon→server frames.

    Implementations decide whether the frame goes over WS as JSON or
    over HTTP as a POST to a per-type endpoint.
    """

    async def send_frame(self, frame: dict) -> None: ...

    async def close(self) -> None: ...


# Frame ``type`` → POST path. ``None`` means the SSE path doesn't have a
# corresponding POST (the WS-only frame is silently dropped). We list all
# the daemon→server frame types from spec §4.2 explicitly so future frame
# types fail loudly (logged) rather than getting silently sent to ``None``.
_HTTP_PATHS: dict[str, str | None] = {
    "delivery_ack": "/v1/daemon/delivery-ack",
    "agent_status": "/v1/daemon/agent-status",
    "agent_session_start": "/v1/daemon/agent-session-start",
    "tool_call": "/v1/daemon/tool-call",
    # SSE provides server-side ``:hb`` heartbeat; the daemon doesn't need
    # to pong (and the server has no /pong endpoint). The legacy WS still
    # uses pong via WSTransport.
    "pong": None,
    # Resume happens implicitly via the ``Last-Event-ID`` header on the
    # SSE GET; no POST equivalent.
    "resume": None,
    # Ready is sent ONCE during /v1/daemon/ready (handled by main_loop
    # before the OutboundQueue is wired up); no need to re-send.
    "ready": None,
}


class HTTPTransport:
    """Transport implementation that routes by frame type to POST endpoints."""

    def __init__(self, http: HTTPOutbound) -> None:
        self._http = http

    async def send_frame(self, frame: dict) -> None:
        ftype = frame.get("type")
        if ftype not in _HTTP_PATHS:
            logger.warning(
                "http_transport: unknown frame type %r — dropping", ftype
            )
            return
        path = _HTTP_PATHS[ftype]
        if path is None:
            # Intentionally not POSTed — see _HTTP_PATHS comments above.
            logger.debug(
                "http_transport: frame type %r has no POST path — skipping",
                ftype,
            )
            return
        payload = frame.get("payload") or {}
        # tool_call and delivery_ack include the request_id / message_id
        # inside payload already; the backend POST schemas mirror those
        # fields, so passing the inner payload as the JSON body is enough.
        await self._http.post(path, payload)

    async def close(self) -> None:
        await self._http.close()


class WSTransport:
    """Transport wrapping a connected ``WSClient`` for the legacy path."""

    def __init__(self, ws: "WSClient") -> None:
        self._ws = ws

    async def send_frame(self, frame: dict) -> None:
        await self._ws.send(frame)

    async def close(self) -> None:
        # WSClient is owned (entered/exited) by ``run_forever`` in the
        # legacy path; closing here would race with the supervisor. Keep
        # this a no-op so the supervisor stays in charge of the lifecycle.
        return
