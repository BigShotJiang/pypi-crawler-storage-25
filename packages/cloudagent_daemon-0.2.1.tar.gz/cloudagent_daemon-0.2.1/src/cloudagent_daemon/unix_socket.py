"""Unix-socket IPC between daemon-main and mcp_bridge subprocesses.

The bridge process (one per claude subprocess) cannot talk to the backend
directly — only daemon-main owns the WebSocket. Bridges therefore tunnel
their tool calls over a unix socket to the daemon main process, which
dispatches the request (typically into ``OutboundQueue.send_tool_call``)
and returns a result.

Wire format: line-delimited JSON, one message per ``\\n``.

Request:
    {"request_id": "ipc_...", "op": "tool_call", "args": {...}}

Response:
    {"request_id": "ipc_...", "result": {...}}
    {"request_id": "ipc_...", "error": {"code": "...", "message": "..."}}

The IPC layer is op-agnostic — the bridge picks the op (e.g. ``tool_call``)
and the daemon-main installs a handler that routes by ``op``.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from collections.abc import Awaitable, Callable
from pathlib import Path

logger = logging.getLogger(__name__)

def default_socket_path(profile: str | None = None) -> Path:
    """Profile-aware accessor: ``bridge.sock`` under the per-profile root.

    Default profile keeps the legacy ``~/.cloudagent/daemon/bridge.sock``
    so existing installs and downstream tools (desktop daemon-mcp, FE
    setup) keep working byte-for-byte. Pass an explicit name (e.g.
    ``"fr"``) to land at ``~/.cloudagent/daemon/profiles/fr/bridge.sock``.
    """
    # Lazy import: ``paths`` lives in the same package and importing at
    # module top would couple bottom-of-graph IPC code to a sibling we
    # would otherwise be free to refactor.
    from .paths import profile_socket_path

    return profile_socket_path(profile)


# Backward-compatible module-level constant — pre-multi-profile callers
# (and tests) read this directly. Always points at the default-profile
# socket; named profiles must use ``default_socket_path("...")``.
DEFAULT_SOCKET_PATH = default_socket_path()

# Generous bound on a single line so a runaway producer can't OOM us.
_MAX_LINE_BYTES = 4 * 1024 * 1024  # 4 MiB


Handler = Callable[[dict], Awaitable[dict]]


class UnixSocketServer:
    """Daemon-main side: accepts multiple bridge connections concurrently.

    Each accepted connection is read line-by-line. For every line, the
    handler is invoked with the parsed dict; whatever the handler returns
    (a dict containing ``result`` or ``error``) is echoed back with the
    same ``request_id``.
    """

    def __init__(self, socket_path: Path, handler: Handler) -> None:
        self._socket_path = Path(socket_path)
        self._handler = handler
        self._server: asyncio.base_events.Server | None = None
        self._tasks: set[asyncio.Task] = set()

    @property
    def socket_path(self) -> Path:
        return self._socket_path

    async def start(self) -> None:
        # Remove a stale socket file if present — start_unix_server will
        # fail with EADDRINUSE otherwise.
        if self._socket_path.exists():
            self._socket_path.unlink()
        self._socket_path.parent.mkdir(parents=True, exist_ok=True)
        self._server = await asyncio.start_unix_server(
            self._handle_connection, path=str(self._socket_path)
        )
        # Lock down permissions: only the owning user may connect.
        os.chmod(self._socket_path, 0o600)

    async def stop(self) -> None:
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
        # Cancel any in-flight connection handlers.
        for task in list(self._tasks):
            if not task.done():
                task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
            self._tasks.clear()
        # Best-effort cleanup of the socket file.
        try:
            if self._socket_path.exists():
                self._socket_path.unlink()
        except OSError:
            pass

    async def _handle_connection(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        # 1k #55 — give each accepted connection a short id so we can
        # correlate request/response lines across concurrent clients.
        conn_id = uuid.uuid4().hex[:8]
        task = asyncio.current_task()
        if task is not None:
            self._tasks.add(task)
        logger.info("unix_socket: connection ACCEPTED conn=%s", conn_id)
        try:
            while True:
                try:
                    line = await reader.readuntil(b"\n")
                except asyncio.IncompleteReadError:
                    logger.info(
                        "unix_socket: connection EOF conn=%s — client closed",
                        conn_id,
                    )
                    return
                except asyncio.LimitOverrunError:
                    # Drain & abort: can't recover frame alignment.
                    logger.warning(
                        "unix_socket: limit overrun conn=%s — aborting",
                        conn_id,
                    )
                    return
                except (ConnectionResetError, BrokenPipeError, OSError) as exc:
                    # 1k #55 — surface unexpected socket errors that
                    # previously propagated silently out of the handler
                    # task and were lost. Log & return so the connection
                    # is cleanly closed (and the client gets a fresh
                    # opportunity on the next ``UnixSocketClient``).
                    logger.warning(
                        "unix_socket: read error conn=%s err=%r — closing",
                        conn_id, exc,
                    )
                    return
                if not line:
                    return
                if len(line) > _MAX_LINE_BYTES:
                    logger.warning(
                        "unix_socket: oversized line conn=%s bytes=%d — closing",
                        conn_id, len(line),
                    )
                    return
                try:
                    msg = json.loads(line.decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    # Malformed line — skip; protocol violation but no
                    # request_id to respond against.
                    logger.warning(
                        "unix_socket: malformed line conn=%s — skipping",
                        conn_id,
                    )
                    continue
                request_id = msg.get("request_id")
                logger.info(
                    "unix_socket: REQUEST conn=%s rid=%s op=%s",
                    conn_id, request_id, msg.get("op"),
                )
                try:
                    response = await self._handler(msg)
                except Exception as exc:  # noqa: BLE001
                    logger.exception(
                        "unix_socket: handler raised conn=%s rid=%s",
                        conn_id, request_id,
                    )
                    response = {
                        "error": {
                            "code": "HANDLER_EXCEPTION",
                            "message": f"{type(exc).__name__}: {exc}",
                        }
                    }
                payload: dict = {"request_id": request_id, **response}
                try:
                    writer.write(
                        (json.dumps(payload, separators=(",", ":")) + "\n").encode(
                            "utf-8"
                        )
                    )
                    await writer.drain()
                except (ConnectionResetError, BrokenPipeError) as exc:
                    logger.warning(
                        "unix_socket: write error conn=%s rid=%s err=%r — closing",
                        conn_id, request_id, exc,
                    )
                    return
                logger.info(
                    "unix_socket: RESPONSE conn=%s rid=%s sent=%d bytes",
                    conn_id, request_id, len(payload),
                )
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:  # noqa: BLE001
                pass
            if task is not None:
                self._tasks.discard(task)
            logger.info("unix_socket: connection CLOSED conn=%s", conn_id)


class UnixSocketClient:
    """Bridge side: connects, sends one request, awaits the matching response.

    Used as an async context manager so the connection always closes
    cleanly. Multiple sequential ``call`` invocations on the same client
    are allowed (and used by long-running bridges that issue many tool
    calls), but the wire is strictly request/response — no pipelining.
    """

    def __init__(self, socket_path: Path) -> None:
        self._socket_path = Path(socket_path)
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None

    async def __aenter__(self) -> "UnixSocketClient":
        self._reader, self._writer = await asyncio.open_unix_connection(
            path=str(self._socket_path)
        )
        return self

    async def __aexit__(self, *args: object) -> None:
        if self._writer is not None:
            try:
                self._writer.close()
                await self._writer.wait_closed()
            except Exception:  # noqa: BLE001
                pass
        self._reader = None
        self._writer = None

    async def call(
        self, op: str, args: dict, timeout: float = 30.0
    ) -> dict:
        if self._reader is None or self._writer is None:
            raise RuntimeError("UnixSocketClient is not connected")
        request_id = f"ipc_{uuid.uuid4().hex[:12]}"
        payload = {"request_id": request_id, "op": op, "args": args}
        line = (json.dumps(payload, separators=(",", ":")) + "\n").encode("utf-8")
        self._writer.write(line)
        await self._writer.drain()

        try:
            response_line = await asyncio.wait_for(
                self._reader.readuntil(b"\n"), timeout=timeout
            )
        except asyncio.IncompleteReadError as exc:
            raise RuntimeError("IPC connection closed before response") from exc
        except TimeoutError as exc:
            raise RuntimeError(f"IPC call timed out after {timeout}s") from exc
        try:
            response = json.loads(response_line.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"Malformed IPC response: {response_line!r}") from exc

        if response.get("request_id") != request_id:
            raise RuntimeError(
                f"IPC response request_id mismatch: "
                f"sent {request_id}, got {response.get('request_id')}"
            )
        if "error" in response:
            err = response["error"] or {}
            code = err.get("code", "UNKNOWN")
            message = err.get("message", "")
            raise RuntimeError(f"IPC error {code}: {message}".rstrip(": "))
        return response.get("result", {})
