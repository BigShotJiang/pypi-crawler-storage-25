"""Per-profile path resolution for the cloudagent daemon.

A *profile* lets one host nurse multiple cloudagent backends in parallel
(prod, fr, staging, …) by namespacing every persistent resource the
daemon owns. The ``"default"`` profile keeps the legacy paths
byte-for-byte unchanged — that is the foundation of our zero-migration
guarantee for users already running the daemon.

Layout (M6 multi-profile proposal 2026-05-18):

  default profile                       named profile "fr"
  ─────────────────                     ─────────────────
  ~/.cloudagent/daemon/                 ~/.cloudagent/daemon/profiles/fr/
    ├── config.json                       ├── config.json
    ├── state.json                        ├── state.json
    ├── bridge.sock                       ├── bridge.sock
    ├── daemon.lock                       ├── daemon.lock
    └── logs/                             └── logs/

  ~/.cloudagent/agents/                 ~/.cloudagent/agents-fr/

  launchd label:                        launchd label:
    chat.cloudagent.daemon                chat.cloudagent.daemon.fr
  systemd unit:                         systemd unit:
    cloudagent-daemon.service             cloudagent-daemon-fr.service
"""
from __future__ import annotations

import os
import re
from pathlib import Path

DEFAULT_PROFILE = "default"

# kebab-case, first char alnum, total length 1..31. Disallow ``.``, ``/``,
# ``..``, whitespace, uppercase, underscores. Constraints come from:
#  - launchd label segments (RFC-1035-ish, no dots / colons in the suffix)
#  - filesystem safety (no path traversal)
#  - cross-platform sanity (no case-sensitivity surprises on macOS HFS+)
_PROFILE_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,30}$")

# Env var name daemon spawns surface to subprocesses (mcp_bridge, future
# helpers). Keeps the active profile pinned across exec boundaries even
# when the parent never gets a chance to pass an explicit ``--profile``
# flag. ``cli.py`` reads it as fallback for ``agent register`` /
# ``agent unregister`` etc.
ENV_VAR = "CLOUDAGENT_DAEMON_PROFILE"


def validate_profile_name(name: str) -> str:
    """Return *name* if it is safe to use; raise ``ValueError`` otherwise.

    ``"default"`` is reserved and always valid (treated as the legacy /
    unnamed profile). Anything else must match ``[a-z0-9][a-z0-9-]{0,30}``.
    """
    if name == DEFAULT_PROFILE:
        return name
    if not isinstance(name, str) or not _PROFILE_NAME_RE.fullmatch(name):
        raise ValueError(
            f"invalid profile name: {name!r} — must match "
            f"[a-z0-9][a-z0-9-]{{0,30}} (e.g. 'fr', 'prod', 'staging-eu')"
        )
    return name


def resolve_profile(name: str | None) -> str:
    """Resolve the effective profile name.

    Order: explicit *name* > ``CLOUDAGENT_DAEMON_PROFILE`` env > default.
    Always validated. Empty string / ``None`` collapse to default.
    """
    if name:
        return validate_profile_name(name)
    env = os.environ.get(ENV_VAR, "").strip()
    if env:
        return validate_profile_name(env)
    return DEFAULT_PROFILE


# ---------- Filesystem layout ----------


def _home() -> Path:
    """Return ``$HOME``. Indirection so tests can monkeypatch ``HOME``."""
    return Path.home()


def profile_base_dir(profile: str | None = None) -> Path:
    """Per-profile root: ``~/.cloudagent/daemon`` (default) or
    ``~/.cloudagent/daemon/profiles/<name>`` (named)."""
    p = resolve_profile(profile)
    base = _home() / ".cloudagent" / "daemon"
    if p == DEFAULT_PROFILE:
        return base
    return base / "profiles" / p


def profile_config_path(profile: str | None = None) -> Path:
    return profile_base_dir(profile) / "config.json"


def profile_state_path(profile: str | None = None) -> Path:
    return profile_base_dir(profile) / "state.json"


def profile_socket_path(profile: str | None = None) -> Path:
    return profile_base_dir(profile) / "bridge.sock"


def profile_lock_path(profile: str | None = None) -> Path:
    return profile_base_dir(profile) / "daemon.lock"


def profile_pid_path(profile: str | None = None) -> Path:
    return profile_base_dir(profile) / "daemon.pid"


def profile_log_dir(profile: str | None = None) -> Path:
    return profile_base_dir(profile) / "logs"


def profile_workspace_root(profile: str | None = None) -> Path:
    """Default agent workspace root.

    The default profile keeps the legacy ``~/.cloudagent/agents``;
    named profiles get a sibling ``~/.cloudagent/agents-<name>`` so
    file managers / terminals visually group them next to the
    original tree rather than burying them under another nesting
    level. Callers who want a fully-custom path keep using
    ``--workspace-root`` exactly as before.
    """
    p = resolve_profile(profile)
    if p == DEFAULT_PROFILE:
        return _home() / ".cloudagent" / "agents"
    return _home() / ".cloudagent" / f"agents-{p}"


# ---------- Service identifiers ----------


def profile_launchd_label(profile: str | None = None) -> str:
    """launchd Label. Default profile keeps the legacy ``chat.cloudagent.daemon``;
    named profiles append ``.<name>`` so multiple plists coexist."""
    p = resolve_profile(profile)
    base = "chat.cloudagent.daemon"
    return base if p == DEFAULT_PROFILE else f"{base}.{p}"


def profile_systemd_unit_name(profile: str | None = None) -> str:
    """systemd unit filename. Default keeps legacy ``cloudagent-daemon.service``;
    named profiles use a literal ``cloudagent-daemon-<name>.service``."""
    p = resolve_profile(profile)
    return (
        "cloudagent-daemon.service"
        if p == DEFAULT_PROFILE
        else f"cloudagent-daemon-{p}.service"
    )


# ---------- Discovery ----------


def list_installed_profiles() -> list[str]:
    """Enumerate profiles that have a ``config.json`` on disk.

    Default is included whenever its config exists; named profiles
    show up under ``~/.cloudagent/daemon/profiles/<name>/``. Returns
    a sorted list with ``default`` first (when present) so output
    order is stable for ``list-profiles``.
    """
    found: list[str] = []
    if profile_config_path(DEFAULT_PROFILE).exists():
        found.append(DEFAULT_PROFILE)
    profiles_dir = _home() / ".cloudagent" / "daemon" / "profiles"
    if profiles_dir.is_dir():
        for child in sorted(profiles_dir.iterdir()):
            if not child.is_dir():
                continue
            try:
                validate_profile_name(child.name)
            except ValueError:
                continue
            if (child / "config.json").exists():
                found.append(child.name)
    return found


__all__ = [
    "DEFAULT_PROFILE",
    "ENV_VAR",
    "validate_profile_name",
    "resolve_profile",
    "profile_base_dir",
    "profile_config_path",
    "profile_state_path",
    "profile_socket_path",
    "profile_lock_path",
    "profile_pid_path",
    "profile_log_dir",
    "profile_workspace_root",
    "profile_launchd_label",
    "profile_systemd_unit_name",
    "list_installed_profiles",
]
