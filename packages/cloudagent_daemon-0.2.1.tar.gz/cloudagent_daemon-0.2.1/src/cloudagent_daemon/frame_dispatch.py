"""Inbound frame dispatcher for the cloudagent daemon.

Routes WebSocket frames received from the server to the appropriate
handler/callback. Actual spawn logic (Task 8), outbound queue (Task 7),
and workspace management (Task 11) are injected via callbacks so this
module stays dependency-free beyond DaemonState and stdlib.
"""
from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import TYPE_CHECKING

from cloudagent_daemon.config import DaemonState

if TYPE_CHECKING:
    from cloudagent_daemon.spawn_outbox import SpawnOutbox

logger = logging.getLogger(__name__)


class FrameDispatcher:
    """Route inbound frames to registered callbacks.

    Parameters
    ----------
    state:
        Live DaemonState; mutated on accepted deliver frames.
    state_path:
        Path passed to ``state.save()`` after each accepted deliver.
    ack_callback:
        Called as ``ack_callback(seq, message_id, status)`` immediately
        after a deliver frame passes the idempotency check.
    spawn_callback:
        Called with the deliver payload dict for new (non-duplicate) frames.
    tool_result_pending:
        Shared dict mapping ``request_id`` → ``asyncio.Future``.  The
        dispatcher pops and resolves futures as ``tool_result`` frames arrive.
    workspace_assign_callback:
        Optional; called with the assign payload dict.
    workspace_unassign_callback:
        Optional; called with the unassign payload dict.
    bye_callback:
        Optional; called with the bye payload dict to trigger shutdown.
    spawn_outbox:
        Optional; durable journal of accepted deliver frames. When
        provided, every new (non-duplicate) frame is persisted via
        :meth:`SpawnOutbox.record_received` BEFORE the server-side ack
        so a daemon crash between ack and spawn doesn't silently lose
        the frame. See ``spawn_outbox.py`` for details (Bug 4).
    """

    def __init__(
        self,
        *,
        state: DaemonState,
        state_path: Path,
        ack_callback: Callable[[int, str, str], Awaitable[None]],
        spawn_callback: Callable[[dict], Awaitable[None]],
        tool_result_pending: dict[str, asyncio.Future],
        workspace_assign_callback: Callable[[dict], Awaitable[None]] | None = None,
        workspace_unassign_callback: Callable[[dict], Awaitable[None]] | None = None,
        bye_callback: Callable[[dict], Awaitable[None]] | None = None,
        spawn_outbox: "SpawnOutbox | None" = None,
    ) -> None:
        self.state = state
        self.state_path = state_path
        self.ack_callback = ack_callback
        self.spawn_callback = spawn_callback
        self.tool_result_pending = tool_result_pending
        self.workspace_assign_callback = workspace_assign_callback
        self.workspace_unassign_callback = workspace_unassign_callback
        self.bye_callback = bye_callback
        self.spawn_outbox = spawn_outbox

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    async def dispatch(self, frame: dict) -> None:
        """Dispatch *frame* to the appropriate handler."""
        t = frame.get("type")
        if t == "deliver":
            await self._on_deliver(frame)
        elif t == "tool_result":
            self._on_tool_result(frame)
        elif t == "assign":
            await self._on_assign(frame)
        elif t == "unassign":
            await self._on_unassign(frame)
        elif t == "bye":
            await self._on_bye(frame)
        elif t == "hello":
            pass  # WSClient already consumed this in __aenter__
        else:
            logger.warning("unknown frame type: %s", t)

    # ------------------------------------------------------------------
    # Handlers
    # ------------------------------------------------------------------

    async def _on_deliver(self, frame: dict) -> None:
        seq = frame["seq"]
        payload = frame["payload"]
        msg_id = payload["message_id"]
        # K1 §护栏 9 — server-stamped wake idempotency key. When set, dedupe
        # by wake_id in addition to message_id so reconnect-catchup of a
        # frame whose wake was already handled lands as ack-only. Frames
        # without ``wake_id`` (test-chat / direct task creation) keep the
        # legacy message_id-only path.
        wake_id = payload.get("wake_id") if isinstance(payload, dict) else None

        # Idempotency: already processed (by either key) → ack-only, skip spawn
        if self.state.has_processed(msg_id):
            logger.info(
                "frame_dispatch: deliver duplicate (msg_id already processed) "
                "agent=%s msg=%s seq=%d",
                payload.get("agent_id"),
                msg_id,
                seq,
            )
            await self.ack_callback(seq, msg_id, "received")
            return
        if wake_id and self.state.has_processed(wake_id):
            logger.info(
                "frame_dispatch: deliver duplicate (wake_id already processed) "
                "agent=%s msg=%s wake=%s seq=%d",
                payload.get("agent_id"),
                msg_id,
                wake_id,
                seq,
            )
            # Still record the message_id so further re-deliveries of the
            # same row hit the cheap msg_id branch above.
            self.state.add_processed(msg_id)
            self.state.last_seq = max(self.state.last_seq, seq)
            self.state.save(self.state_path)
            await self.ack_callback(seq, msg_id, "received")
            return

        # 1i Bug C — Phase 1 demo visibility for the spawn pipeline.
        logger.info(
            "frame_dispatch: dispatching deliver agent=%s msg=%s wake=%s seq=%d body_len=%d",
            payload.get("agent_id"),
            msg_id,
            wake_id,
            seq,
            len(payload.get("body") or ""),
        )

        # Bug 4 (2026-05-12) — persist the frame BEFORE the ack so a
        # crash between ack and spawn doesn't silently lose it. The
        # outbox is the authoritative replay source on next boot.
        # If the outbox write fails we deliberately do NOT ack —
        # server will redeliver on reconnect and we'll try again.
        if self.spawn_outbox is not None:
            try:
                await self.spawn_outbox.record_received(payload)
            except Exception:
                logger.exception(
                    "frame_dispatch: spawn_outbox.record_received failed "
                    "agent=%s msg=%s — skipping ack, server will redeliver",
                    payload.get("agent_id"),
                    msg_id,
                )
                return

        self.state.add_processed(msg_id)
        if wake_id:
            self.state.add_processed(wake_id)
        self.state.last_seq = max(self.state.last_seq, seq)
        self.state.save(self.state_path)

        await self.ack_callback(seq, msg_id, "received")
        await self.spawn_callback(payload)

    def _on_tool_result(self, frame: dict) -> None:
        payload = frame["payload"]
        rid = payload["request_id"]
        fut = self.tool_result_pending.pop(rid, None)
        # 1k #55 — observability for the multi-tool wake bug. Without this
        # we cannot tell whether a tool_result reached the dispatcher at
        # all, whether it matched a pending future, or whether it was a
        # late arrival (future already done).
        if fut is None:
            logger.warning(
                "frame_dispatch: tool_result rid=%s — NO PENDING FUTURE "
                "(late arrival, duplicate, or unknown rid)",
                rid,
            )
            return
        if fut.done():
            logger.warning(
                "frame_dispatch: tool_result rid=%s — future ALREADY DONE",
                rid,
            )
            return
        logger.info(
            "frame_dispatch: tool_result rid=%s ok=%s — resolving future",
            rid, payload.get("ok"),
        )
        fut.set_result(payload)

    async def _on_assign(self, frame: dict) -> None:
        if self.workspace_assign_callback:
            await self.workspace_assign_callback(frame["payload"])

    async def _on_unassign(self, frame: dict) -> None:
        if self.workspace_unassign_callback:
            await self.workspace_unassign_callback(frame["payload"])

    async def _on_bye(self, frame: dict) -> None:
        if self.bye_callback:
            await self.bye_callback(frame["payload"])
