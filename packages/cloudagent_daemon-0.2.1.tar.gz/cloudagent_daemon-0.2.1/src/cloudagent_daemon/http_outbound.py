"""HTTP POST sender for daemon→server frames.

The SSE transport replaces the WebSocket's bidirectionality with an SSE
stream (server→daemon) plus per-frame-type POST endpoints (daemon→server).
``HTTPOutbound`` owns the shared httpx.AsyncClient and is reused across all
POST calls so connection pooling, HTTP/2 multiplexing, and TLS sessions
amortise.
"""
from __future__ import annotations

import logging
import ssl

import httpx

logger = logging.getLogger(__name__)

# Outbound POST timeout. Tight enough that a hung server doesn't block
# the daemon's SpawnQueue serialise; loose enough that a slow but healthy
# server (cold-start container, GC pause) doesn't get spuriously aborted.
_POST_TIMEOUT_SECONDS = 10.0


class HTTPOutbound:
    """Authorised POST sender backed by a single httpx.AsyncClient.

    All POSTs share:
      * Bearer authorisation (set as a default header).
      * The same TLS verification policy (``insecure=True`` disables cert
        validation — used for dev environments with self-signed certs).
      * The base URL (``server_url``) so callers pass relative paths.
    """

    def __init__(
        self,
        server_url: str,
        api_key: str,
        *,
        insecure: bool = False,
    ) -> None:
        self._server_url = server_url.rstrip("/")
        self._api_key = api_key
        self._insecure = insecure

        verify: ssl.SSLContext | bool = not insecure
        self._client = httpx.AsyncClient(
            base_url=self._server_url,
            verify=verify,
            timeout=httpx.Timeout(_POST_TIMEOUT_SECONDS),
            headers={"Authorization": f"Bearer {api_key}"},
            trust_env=True,
        )

    async def post(self, path: str, json_body: dict) -> dict:
        """POST ``json_body`` to ``path``; return parsed JSON or ``{}``.

        Raises ``httpx.HTTPStatusError`` for any 4xx/5xx response so
        the caller (Transport) can surface auth failures vs. transient.
        """
        r = await self._client.post(path, json=json_body)
        r.raise_for_status()
        # Some endpoints reply 204 No Content (e.g. heartbeat tolerates it
        # in testing fakes); handle that without choking on empty bodies.
        if r.status_code == 204 or not r.content:
            return {}
        try:
            return r.json()
        except ValueError:
            # Non-JSON 200 body — treat as empty rather than crash. Real
            # backend always returns JSON; this is defensive for proxies
            # that inject HTML error pages.
            logger.warning(
                "http_outbound: non-JSON 2xx body for %s (%d bytes)",
                path,
                len(r.content),
            )
            return {}

    async def close(self) -> None:
        await self._client.aclose()
