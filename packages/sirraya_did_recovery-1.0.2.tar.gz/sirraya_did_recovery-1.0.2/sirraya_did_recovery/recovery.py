"""
Sirraya DID Recovery SDK - Main Recovery Module
Developer-friendly API for DID recovery management

Author: Sirraya Labs
License: Apache 2.0
Version: 1.0.2

Quick Start:
    from sirraya_did_recovery import RecoveryClient

    client = RecoveryClient()

    result = client.setup_social_recovery(
        did="did:key:abc",
        guardians=["did:key:alice", "did:key:bob", "did:key:carol"],
        threshold=3
    )

    status = client.get_status("did:key:abc")
    client.refresh("did:key:abc")
"""

import os
import json
import hashlib
from typing import List, Dict, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum

from .core import FeldmanVSS, DIDOperations, Crypto, VSSGroup
from .storage import SecureStorage, secure_storage


# ============================================================================
# Data Models
# ============================================================================

class RecoveryType(str, Enum):
    SOCIAL = "RecoveryMethodZKPSocial"
    DETERMINISTIC = "RecoveryMethodDeterministic"
    MPC = "RecoveryMethodMPC"


@dataclass
class Guardian:
    """Guardian information for social recovery"""
    did: str
    endpoint: str = ""
    public_key: str = ""
    encrypted_share: Optional[str] = None

    @classmethod
    def create(cls, did: str, index: int) -> 'Guardian':
        endpoint = f"https://{did.replace(':', '-').replace('/', '_')}.recovery.example.com"
        return cls(did=did, endpoint=endpoint)

    def to_dict(self) -> Dict:
        return {
            'id': self.did,
            'endpoint': self.endpoint,
            'public_key': self.public_key,
            'guardian_type': 'person' if self.did.startswith('did:key') else 'institution',
            'commitment_index': 0,
        }


@dataclass
class RecoveryConfig:
    """Recovery configuration for a DID"""
    did: str
    recovery_type: RecoveryType
    current_epoch: int
    created_at: datetime
    last_refresh: Optional[datetime]
    auto_refresh_days: int
    parameters: Dict


@dataclass
class RecoveryStatus:
    """Status of recovery for a DID"""
    did: str
    recovery_type: str
    status: str
    current_epoch: int
    guardian_count: int
    refresh_count: int
    created_at: str
    last_refresh: Optional[str]
    recent_activity: List[Dict]


# ============================================================================
# Main Recovery Client
# ============================================================================

class RecoveryClient:
    """
    Main client for DID recovery operations.

    Features:
        - Social recovery (Feldman VSS with guardians)
        - Deterministic recovery (seed phrase)
        - Proactive refresh (rotate shares without changing the secret)
        - Audit logging
        - Encrypted storage
    """

    def __init__(self, db_path: str = "recovery.db", encryption_key: bytes = None):
        """
        Initialize recovery client.

        Args:
            db_path: Path to SQLite database file
            encryption_key: 32-byte AES key (auto-generated if not provided)
        """
        self._storage = SecureStorage(db_path, encryption_key)
        self._cache: Dict[str, Any] = {}

    # --------------------------------------------------------------------------
    # Social Recovery (Type A)
    # --------------------------------------------------------------------------

    def setup_social_recovery(self, did: str, guardians: List[str],
                              threshold: int = 3, auto_refresh_days: int = 30) -> Dict:
        """
        Setup social recovery with guardians.

        Uses Feldman VSS to split a recovery secret among guardians.
        Any 'threshold' guardians can recover the DID.

        Args:
            did: DID to protect
            guardians: List of guardian DIDs (must have >= threshold entries)
            threshold: Number of guardians needed for recovery (default: 3)
            auto_refresh_days: Days between automatic refreshes (default: 30)

        Returns:
            Dict with recovery_id, method_id, commitments, guardian_count, etc.
        """
        if not DIDOperations.validate_did(did):
            raise ValueError(f"Invalid DID: {did}")

        if len(guardians) < threshold:
            raise ValueError(f"Need at least {threshold} guardians, got {len(guardians)}")

        for g in guardians:
            if not DIDOperations.validate_did(g):
                raise ValueError(f"Invalid guardian DID: {g}")

        guardian_objs = [Guardian.create(g, i) for i, g in enumerate(guardians)]

        secret = os.urandom(32)
        vss = FeldmanVSS(threshold, len(guardians))
        shares, commitments = vss.generate_shares(secret)

        # Encrypt each share.  AAD = "{did}:{guardian_did}:epoch{n}" binds the
        # ciphertext to the DID, the specific guardian, and the epoch so that
        # a share cannot be replayed across guardians or epochs.
        for i, (guardian, share) in enumerate(zip(guardian_objs, shares)):
            aad = f"{did}:{guardian.did}:epoch1".encode()
            encrypted = Crypto.encrypt(
                self._storage.encryption_key,
                str(share).encode(),
                aad
            )
            self._storage.store_share(
                did, guardian.did, 1, encrypted, commitments,
                signature=hashlib.sha256(f"{guardian.did}:{share}".encode()).hexdigest()
            )
            guardian.encrypted_share = encrypted

        # Persist share_index alongside each guardian so refresh can use the
        # correct VSS evaluation point without relying on storage row order.
        recovery_params = {
            'threshold': threshold,
            'total_guardians': len(guardians),
            'commitments': [str(c) for c in commitments],
            'guardians': [
                {**g.to_dict(), 'share_index': idx}
                for idx, g in enumerate(guardian_objs)
            ],
            'auto_refresh_days': auto_refresh_days,
            'created_at': datetime.now(timezone.utc).isoformat(),
        }

        method_id = self._storage.store_recovery_method(
            did, RecoveryType.SOCIAL.value, recovery_params, auto_refresh_days
        )

        return {
            'success': True,
            'recovery_id': f"{did}#recovery-social",
            'method_id': method_id,
            'commitments': [str(c)[:16] + '...' for c in commitments],
            'guardian_count': len(guardians),
            'current_epoch': 1,
            'auto_refresh_days': auto_refresh_days,
        }

    def refresh(self, did: str) -> Dict:
        """
        Proactive refresh — rotate shares without changing the secret.

        Old shares become cryptographically useless after this call.
        Run periodically (e.g., monthly) to limit exposure from leaked shares.

        Args:
            did: DID to refresh

        Returns:
            Dict with previous_epoch, new_epoch, guardians_refreshed, etc.
        """
        recovery = self._storage.get_recovery_method(did)
        if not recovery:
            raise ValueError(f"No recovery method found for {did}")

        if recovery['recovery_type'] != RecoveryType.SOCIAL.value:
            raise ValueError("Refresh only supported for social recovery")

        params = recovery['parameters']
        current_epoch = recovery['current_epoch']
        guardians = params['guardians']
        threshold = params['threshold']

        current_shares = self._storage.get_shares(did, current_epoch)
        if len(current_shares) != len(guardians):
            raise ValueError(
                f"Share count mismatch: have {len(current_shares)}, need {len(guardians)}"
            )

        # Key fix: look up shares by guardian_id (the column name used in
        # storage.py's get_shares), never by list position.
        share_map: Dict[str, Any] = {s['guardian_id']: s for s in current_shares}

        first_share = next(iter(share_map.values()))
        old_commitments = [int(c) for c in first_share['commitments']]

        vss = FeldmanVSS(threshold, len(guardians))
        _, refresh_deltas, refresh_comms = vss.create_refresh_package(old_commitments)

        new_epoch = current_epoch + 1

        for guardian in guardians:
            guardian_id = guardian['id']
            # share_index is stored at setup time; fall back gracefully for
            # databases created before this field was introduced.
            share_index = guardian.get('share_index', guardians.index(guardian))

            cur_share = share_map.get(guardian_id)
            if cur_share is None:
                raise ValueError(f"No share found in storage for guardian {guardian_id}")

            # Decrypt with the AAD that was used when this share was encrypted.
            aad = f"{did}:{guardian_id}:epoch{current_epoch}".encode()
            share_bytes = Crypto.decrypt(
                self._storage.encryption_key,
                cur_share['encrypted_share'],
                aad
            )
            old_value = int(share_bytes.decode())

            if not vss.verify_share(old_value, share_index, old_commitments):
                raise ValueError(f"Share verification failed for {guardian_id}")

            delta = refresh_deltas[share_index]
            new_value = vss.apply_refresh(old_value, delta)

            if not vss.verify_refresh(new_value, share_index, old_commitments, refresh_comms):
                raise ValueError(f"Refresh verification failed for {guardian_id}")

            new_aad = f"{did}:{guardian_id}:epoch{new_epoch}".encode()
            new_encrypted = Crypto.encrypt(
                self._storage.encryption_key,
                str(new_value).encode(),
                new_aad
            )
            self._storage.store_share(
                did, guardian_id, new_epoch, new_encrypted, refresh_comms
            )

        # Commit epoch only after every share is safely written.
        self._storage.update_epoch(did, new_epoch)
        self._storage.record_refresh(did, current_epoch, new_epoch, refresh_comms)

        # Explicit audit entry so get_audit_log reflects this operation.
        # store_recovery_method already writes one entry at setup; refresh must
        # write its own because storage helpers don't auto-audit every call.
        self._storage.audit(
            did,
            action="refresh",
            status="success",
            details=f"Rotated shares epoch {current_epoch} → {new_epoch}",
            epoch=new_epoch,
        )

        return {
            'success': True,
            'did': did,
            'previous_epoch': current_epoch,
            'new_epoch': new_epoch,
            'guardians_refreshed': len(guardians),
            'timestamp': datetime.now(timezone.utc).isoformat(),
        }

    # --------------------------------------------------------------------------
    # Deterministic Recovery (Type B)
    # --------------------------------------------------------------------------

    def setup_deterministic_recovery(self, did: str, seed_phrase: List[str]) -> Dict:
        """
        Setup deterministic recovery using a seed phrase.

        Args:
            did: DID to protect
            seed_phrase: List of BIP39-style words

        Returns:
            Dict with recovery_id and seed_hash
        """
        if not DIDOperations.validate_did(did):
            raise ValueError(f"Invalid DID: {did}")

        seed = ' '.join(seed_phrase).encode()
        salt = f"did-kr-salt:{did}".encode()
        master_seed = hashlib.pbkdf2_hmac('sha256', seed, salt, 100000, 32)

        params = {
            'derivation_path': "m/44'/0'/0'/0/0",
            'seed_hash': hashlib.sha256(master_seed).hexdigest(),
            'created_at': datetime.now(timezone.utc).isoformat(),
        }

        method_id = self._storage.store_recovery_method(
            did, RecoveryType.DETERMINISTIC.value, params
        )

        return {
            'success': True,
            'recovery_id': f"{did}#recovery-seedling",
            'method_id': method_id,
            'seed_hash': params['seed_hash'][:16] + '...',
        }

    def recover_deterministic(self, did: str, seed_phrase: List[str]) -> Dict:
        """
        Recover a DID using a seed phrase.

        Args:
            did: DID to recover
            seed_phrase: Original seed phrase used in setup

        Returns:
            Dict with recovered key information
        """
        recovery = self._storage.get_recovery_method(did)
        if not recovery:
            raise ValueError(f"No recovery method found for {did}")

        seed = ' '.join(seed_phrase).encode()
        salt = f"did-kr-salt:{did}".encode()
        master_seed = hashlib.pbkdf2_hmac('sha256', seed, salt, 100000, 32)
        seed_hash = hashlib.sha256(master_seed).hexdigest()

        if seed_hash != recovery['parameters']['seed_hash']:
            raise ValueError("Invalid seed phrase")

        return {
            'success': True,
            'did': did,
            'recovered_key': master_seed.hex()[:64] + '...',
            'timestamp': datetime.now(timezone.utc).isoformat(),
        }

    # --------------------------------------------------------------------------
    # Status & Information
    # --------------------------------------------------------------------------

    def get_status(self, did: str) -> RecoveryStatus:
        """Get recovery status for a DID."""
        recovery = self._storage.get_recovery_method(did)
        if not recovery:
            return RecoveryStatus(
                did=did, recovery_type="", status="not_found",
                current_epoch=0, guardian_count=0, refresh_count=0,
                created_at="", last_refresh=None, recent_activity=[]
            )

        audit = self._storage.get_audit_log(did, limit=10)
        refresh_history = self._storage.get_refresh_history(did)
        current_shares = self._storage.get_shares(did, recovery['current_epoch'])

        return RecoveryStatus(
            did=did,
            recovery_type=recovery['recovery_type'],
            status="active",
            current_epoch=recovery['current_epoch'],
            guardian_count=len(current_shares),
            refresh_count=len(refresh_history),
            created_at=recovery['created_at'],
            last_refresh=recovery['last_refresh'],
            recent_activity=audit[:5],
        )

    def list_dids(self) -> List[str]:
        """List all DIDs with recovery configured."""
        return self._storage.list_dids()

    def get_audit_log(self, did: str = None, limit: int = 100) -> List[Dict]:
        """Get audit log entries, optionally filtered by DID."""
        return self._storage.get_audit_log(did, limit)

    def get_refresh_history(self, did: str) -> List[Dict]:
        """Get refresh history for a DID."""
        return self._storage.get_refresh_history(did)

    def validate_graph(self, did: str, visited: set = None) -> bool:
        """
        Validate recovery graph for cycles.

        Returns True if the graph is acyclic (valid).
        """
        if visited is None:
            visited = set()

        if did in visited:
            return False

        visited.add(did)
        recovery = self._storage.get_recovery_method(did)

        if recovery and recovery['recovery_type'] == RecoveryType.SOCIAL.value:
            for guardian in recovery['parameters'].get('guardians', []):
                guardian_did = guardian.get('id', '')
                if guardian_did.startswith('did:'):
                    if not self.validate_graph(guardian_did, visited):
                        return False

        return True

    def export(self, output_dir: str) -> Dict:
        """Export all data for backup."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        os.makedirs(output_dir, exist_ok=True)

        dids_file = os.path.join(output_dir, f"dids_{timestamp}.json")
        with open(dids_file, 'w') as f:
            json.dump(self.list_dids(), f, indent=2)

        audit_file = os.path.join(output_dir, f"audit_{timestamp}.json")
        with open(audit_file, 'w') as f:
            json.dump(self.get_audit_log(limit=1000), f, indent=2, default=str)

        return {
            'success': True,
            'export_dir': output_dir,
            'dids_file': dids_file,
            'audit_file': audit_file,
            'timestamp': timestamp,
        }

    def close(self):
        """Close database connection."""
        self._storage.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# ============================================================================
# Convenience Functions
# ============================================================================

def generate_did() -> Tuple[str, str, str]:
    """
    Generate a new DID.

    Returns:
        Tuple of (did_string, private_key_hex, public_key_hex)
    """
    did, priv, pub = DIDOperations.generate_did_key()
    return did, priv.hex(), pub.hex()


def validate_did(did: str) -> bool:
    """Validate a DID string."""
    return DIDOperations.validate_did(did)


# ============================================================================
# Module exports
# ============================================================================

__all__ = [
    'RecoveryClient',
    'RecoveryStatus',
    'RecoveryType',
    'Guardian',
    'generate_did',
    'validate_did',
    'secure_storage',
]