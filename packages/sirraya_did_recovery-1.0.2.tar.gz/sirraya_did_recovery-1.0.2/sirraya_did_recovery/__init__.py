"""
Sirraya DID Recovery SDK
Enterprise-grade Decentralized Identifier recovery with social, deterministic, and MPC support

Author: Sirraya Labs
License: Apache 2.0
Version: 1.0.0

Quick Start:
    from sirraya_did_recovery import RecoveryClient, generate_did
    
    # Generate a DID
    did, priv, pub = generate_did()
    
    # Setup recovery
    client = RecoveryClient()
    client.setup_social_recovery(
        did=did,
        guardians=["did:key:alice", "did:key:bob", "did:key:carol"]
    )
    
    # Check status
    status = client.get_status(did)
    print(f"Epoch: {status.current_epoch}")
"""

from .recovery import (
    RecoveryClient,
    RecoveryStatus,
    RecoveryType,
    Guardian,
    generate_did,
    validate_did,
)

from .storage import SecureStorage, secure_storage

from .core import (
    FeldmanVSS,
    VSSGroup,
    Crypto,
    DIDOperations,
)

__version__ = "1.0.1"
__all__ = [
    'RecoveryClient',
    'RecoveryStatus', 
    'RecoveryType',
    'Guardian',
    'SecureStorage',
    'FeldmanVSS',
    'VSSGroup',
    'Crypto',
    'DIDOperations',
    'generate_did',
    'validate_did',
    'secure_storage',
]