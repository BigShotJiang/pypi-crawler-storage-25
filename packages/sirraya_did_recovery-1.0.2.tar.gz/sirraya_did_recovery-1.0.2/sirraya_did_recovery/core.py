"""
Sirraya DID Recovery SDK - Core Module
Cryptographic primitives and Feldman VSS implementation

Author: Sirraya Labs
License: Apache 2.0
Version: 1.0.0
"""

import os
import secrets
import hashlib
import base64
from typing import Tuple, List, Optional, Dict, Any
from dataclasses import dataclass
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidTag


# ============================================================================
# VSS Group Parameters (256-bit Safe Prime)
# ============================================================================

class VSSGroup:
    """
    Feldman VSS group parameters using 256-bit safe prime p = 2q+1.
    
    Properties:
        p: Safe prime (modulus for commitments)
        q: Subgroup prime order (modulus for shares)
        g: Generator of order q
    """
    
    # 256-bit safe prime p = 2q+1
    P = 0x50179e4375e428b3af8fe52af1f2a50e5100b916d0d1c1bbedc304c3d35f3217
    Q = 0x280bcf21baf21459d7c7f29578f9528728805c8b6868e0ddf6e18261e9af990b
    G = 4
    
    @classmethod
    def random_scalar(cls) -> int:
        """Generate random element in Z_q"""
        return secrets.randbelow(cls.Q)
    
    @classmethod
    def commit(cls, x: int) -> int:
        """Pedersen commitment: g^x mod p"""
        return pow(cls.G, x % cls.Q, cls.P)
    
    @classmethod
    def mod_inv(cls, a: int) -> int:
        """Modular inverse in Z_q (Fermat's little theorem)"""
        if a == 0:
            raise ValueError("Cannot invert zero")
        return pow(a, cls.Q - 2, cls.Q)
    
    @classmethod
    def from_bytes(cls, data: bytes) -> int:
        """Convert bytes to scalar in Z_q"""
        return int.from_bytes(data, 'big') % cls.Q
    
    @classmethod
    def to_bytes(cls, x: int) -> bytes:
        """Convert scalar to 32-byte representation"""
        return (x % cls.Q).to_bytes(32, 'big')


# ============================================================================
# AES-256-GCM Encryption
# ============================================================================

class Crypto:
    """AES-256-GCM authenticated encryption"""
    
    KEY_SIZE = 32
    NONCE_SIZE = 12
    
    @classmethod
    def generate_key(cls) -> bytes:
        """Generate random encryption key"""
        return os.urandom(cls.KEY_SIZE)
    
    @classmethod
    def encrypt(cls, key: bytes, data: bytes, aad: bytes = None) -> str:
        """Encrypt with AES-256-GCM, returns base64 encoded"""
        if len(key) != cls.KEY_SIZE:
            raise ValueError(f"Key must be {cls.KEY_SIZE} bytes")
        
        aesgcm = AESGCM(key)
        nonce = os.urandom(cls.NONCE_SIZE)
        ciphertext = aesgcm.encrypt(nonce, data, aad or b'')
        return base64.b64encode(nonce + ciphertext).decode('ascii')
    
    @classmethod
    def decrypt(cls, key: bytes, encrypted: str, aad: bytes = None) -> bytes:
        """Decrypt AES-256-GCM ciphertext"""
        if len(key) != cls.KEY_SIZE:
            raise ValueError(f"Key must be {cls.KEY_SIZE} bytes")
        
        try:
            combined = base64.b64decode(encrypted)
            if len(combined) < cls.NONCE_SIZE + 16:
                raise ValueError("Invalid encrypted data")
            
            nonce = combined[:cls.NONCE_SIZE]
            ciphertext = combined[cls.NONCE_SIZE:]
            return AESGCM(key).decrypt(nonce, ciphertext, aad or b'')
        except InvalidTag:
            raise ValueError("Authentication failed - data may be tampered")
    
    @classmethod
    def derive_key(cls, password: str, salt: bytes = None, iterations: int = 100000) -> Tuple[bytes, bytes]:
        """Derive encryption key from password using PBKDF2"""
        if salt is None:
            salt = os.urandom(16)
        
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=cls.KEY_SIZE,
            salt=salt,
            iterations=iterations,
        )
        return kdf.derive(password.encode()), salt


# ============================================================================
# Feldman Verifiable Secret Sharing
# ============================================================================

class FeldmanVSS:
    """
    Verifiable Secret Sharing (Feldman 1987)
    
    Features:
        - Generate verifiable shares from a secret
        - Verify individual shares
        - Recover secret from threshold shares
        - Proactive refresh without changing secret
    
    Example:
        vss = FeldmanVSS(threshold=3, total_shares=5)
        shares, commitments = vss.generate_shares(secret)
        
        # Verify a share
        assert vss.verify_share(shares[0], 0, commitments)
        
        # Recover secret
        recovered = vss.recover_secret([(0, shares[0]), (1, shares[1]), (2, shares[2])])
    """
    
    def __init__(self, threshold: int, total_shares: int):
        """
        Initialize VSS scheme
        
        Args:
            threshold: Minimum shares needed for recovery (≥2)
            total_shares: Total number of shares to generate
        """
        if threshold < 2:
            raise ValueError("Threshold must be at least 2")
        if threshold > total_shares:
            raise ValueError("Threshold cannot exceed total_shares")
        
        self.threshold = threshold
        self.total_shares = total_shares
    
    def generate_shares(self, secret: bytes) -> Tuple[List[int], List[int]]:
        """
        Split secret into verifiable shares
        
        Args:
            secret: 32-byte secret to split
            
        Returns:
            shares: List of share values (in Z_q)
            commitments: List of commitment values (in Z_p)
        """
        secret_int = VSSGroup.from_bytes(secret)
        
        # Build polynomial: constant term = secret, higher terms random
        coeffs = [secret_int] + [VSSGroup.random_scalar() for _ in range(1, self.threshold)]
        
        # Generate shares: P(1), P(2), ..., P(n)
        shares = [self._eval_poly(coeffs, i) for i in range(1, self.total_shares + 1)]
        
        # Generate commitments: g^{a_0}, g^{a_1}, ..., g^{a_{t-1}}
        commitments = [VSSGroup.commit(c) for c in coeffs]
        
        # Self-verification
        for i, share in enumerate(shares):
            if not self.verify_share(share, i, commitments):
                raise ValueError(f"Internal error: share {i+1} failed verification")
        
        return shares, commitments
    
    def verify_share(self, share: int, index: int, commitments: List[int]) -> bool:
        """
        Verify a share against commitments
        
        Equation: g^{share} ≡ ∏ C_j^{(index+1)^j} (mod p)
        """
        left = pow(VSSGroup.G, share % VSSGroup.Q, VSSGroup.P)
        right = self._compute_rhs(index + 1, commitments)
        return left == right
    
    def recover_secret(self, shares: List[Tuple[int, int]]) -> int:
        """
        Recover secret using Lagrange interpolation
        
        Args:
            shares: List of (0-based_index, share_value) pairs
            
        Returns:
            Recovered secret as integer in Z_q
        """
        if len(shares) < self.threshold:
            raise ValueError(f"Need {self.threshold} shares, got {len(shares)}")
        
        q = VSSGroup.Q
        points = [(idx + 1, val) for idx, val in shares]
        
        secret = 0
        for j, (xj, yj) in enumerate(points):
            num = den = 1
            for m, (xm, _) in enumerate(points):
                if m != j:
                    num = (num * (-xm)) % q
                    den = (den * (xj - xm)) % q
            basis = (num * VSSGroup.mod_inv(den)) % q
            secret = (secret + yj * basis) % q
        
        return secret
    
    def create_refresh_package(self, old_commitments: List[int]) -> Tuple[List[int], List[int], List[int]]:
        """
        Create proactive refresh package (R(0)=0)
        
        Returns:
            coeffs: Refresh polynomial coefficients
            deltas: Share deltas for each participant
            commitments: New commitments
        """
        coeffs = [0] + [VSSGroup.random_scalar() for _ in range(1, self.threshold)]
        
        deltas = [self._eval_poly(coeffs, i) for i in range(1, self.total_shares + 1)]
        commitments = [VSSGroup.commit(c) for c in coeffs]
        
        return coeffs, deltas, commitments
    
    def apply_refresh(self, old_share: int, delta: int) -> int:
        """Apply refresh delta to existing share"""
        return (old_share + delta) % VSSGroup.Q
    
    def verify_refresh(self, new_share: int, index: int,
                       old_commitments: List[int],
                       refresh_commitments: List[int]) -> bool:
        """Verify refreshed share against combined commitments"""
        combined = [(o * r) % VSSGroup.P for o, r in zip(old_commitments, refresh_commitments)]
        return self.verify_share(new_share, index, combined)
    
    # --------------------------------------------------------------------------
    # Private methods
    # --------------------------------------------------------------------------
    
    def _eval_poly(self, coeffs: List[int], x: int) -> int:
        """Evaluate polynomial at x using Horner's method"""
        result = 0
        for c in reversed(coeffs):
            result = (result * x + c) % VSSGroup.Q
        return result
    
    def _compute_rhs(self, participant: int, commitments: List[int]) -> int:
        """Compute right-hand side of verification equation"""
        result = 1
        x_pow = 1
        for j, Cj in enumerate(commitments):
            exp = x_pow % VSSGroup.Q
            result = (result * pow(Cj, exp, VSSGroup.P)) % VSSGroup.P
            if j < len(commitments) - 1:
                x_pow = (x_pow * participant) % VSSGroup.Q
        return result


# ============================================================================
# DID Operations
# ============================================================================

class DIDOperations:
    """DID generation and validation utilities"""
    
    @staticmethod
    def generate_did_key() -> Tuple[str, bytes, bytes]:
        """
        Generate a did:key (Ed25519)
        
        Returns:
            Tuple of (did_string, private_key_bytes, public_key_bytes)
        """
        private_key = ed25519.Ed25519PrivateKey.generate()
        public_key = private_key.public_key()
        
        private_bytes = private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption()
        )
        public_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )
        
        pub_b64 = base64.urlsafe_b64encode(public_bytes).decode('ascii').rstrip('=')
        did = f"did:key:z6Mk{pub_b64[:44]}"
        
        return did, private_bytes, public_bytes
    
    @staticmethod
    def validate_did(did: str) -> bool:
        """Validate DID format"""
        if not did or not did.startswith('did:'):
            return False
        
        parts = did.split(':')
        if len(parts) < 3:
            return False
        
        method = parts[1]
        identifier = ':'.join(parts[2:])
        
        if method == 'key':
            return len(identifier) >= 10 and 'z6Mk' in identifier
        elif method == 'ethr':
            return identifier.startswith('0x') and len(identifier) == 42
        elif method == 'web':
            import re
            return bool(re.match(r'^[a-zA-Z0-9.-]+$', identifier))
        
        return len(identifier) > 0