"""
Sirraya DID Recovery SDK - Storage Module
Encrypted persistence layer with SQLite

Author: Sirraya Labs
License: Apache 2.0
Version: 1.0.1
"""

import json
import sqlite3
import threading
import uuid
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
from contextlib import contextmanager

from .core import Crypto


class SecureStorage:
    """
    Encrypted SQLite storage for DID recovery data.

    Features:
        - AES-256-GCM encrypted at rest
        - WAL mode for concurrent access
        - Automatic schema migration
        - Audit logging
        - Thread-safe

    Example:
        storage = SecureStorage("recovery.db", master_key)

        method_id = storage.store_recovery_method(
            did="did:key:abc",
            recovery_type="social",
            parameters={"threshold": 3}
        )

        method = storage.get_recovery_method("did:key:abc")
    """

    def __init__(self, db_path: str = "recovery.db", encryption_key: bytes = None):
        """
        Initialize secure storage.

        Args:
            db_path: Path to SQLite database file
            encryption_key: 32-byte AES key (generated if not provided)
        """
        self.db_path = db_path
        self.encryption_key = encryption_key or Crypto.generate_key()
        self._local = threading.local()
        self._init_db()

    # --------------------------------------------------------------------------
    # Public API
    # --------------------------------------------------------------------------

    def store_recovery_method(self, did: str, recovery_type: str,
                              parameters: Dict, auto_refresh_days: int = 30) -> str:
        """
        Store or update a recovery method.

        Args:
            did: DID to store recovery for
            recovery_type: Type of recovery (social, deterministic, mpc)
            parameters: Recovery parameters (will be encrypted)
            auto_refresh_days: Days between automatic refreshes

        Returns:
            method_id: Unique identifier for this recovery method
        """
        conn = self._get_conn()
        method_id = str(uuid.uuid4())

        encrypted = Crypto.encrypt(
            self.encryption_key,
            json.dumps(parameters).encode(),
            aad=f"recovery_method:{did}".encode()
        )

        existing = conn.execute(
            "SELECT id FROM recovery_methods WHERE did = ?", (did,)
        ).fetchone()

        if existing:
            conn.execute("""
                UPDATE recovery_methods
                SET recovery_type=?, parameters=?, last_used=CURRENT_TIMESTAMP,
                    auto_refresh_days=?
                WHERE did=?
            """, (recovery_type, encrypted, auto_refresh_days, did))
            method_id = existing['id']
        else:
            conn.execute("""
                INSERT INTO recovery_methods
                    (id, did, recovery_type, parameters, auto_refresh_days)
                VALUES (?, ?, ?, ?, ?)
            """, (method_id, did, recovery_type, encrypted, auto_refresh_days))

        self._audit(conn, did, "store_recovery", "success",
                    f"Stored {recovery_type}", request_id=method_id)
        conn.commit()

        return method_id

    def get_recovery_method(self, did: str) -> Optional[Dict]:
        """
        Retrieve a recovery method by DID.

        Returns the recovery method dictionary, or None if not found /
        if the stored ciphertext cannot be decrypted with the current key.
        """
        conn = self._get_conn()
        row = conn.execute(
            "SELECT * FROM recovery_methods WHERE did = ? AND status = 'active'",
            (did,)
        ).fetchone()

        if not row:
            return None

        try:
            decrypted = Crypto.decrypt(
                self.encryption_key, row['parameters'],
                aad=f"recovery_method:{did}".encode()
            )
            return {
                'id': row['id'],
                'did': row['did'],
                'recovery_type': row['recovery_type'],
                'parameters': json.loads(decrypted.decode()),
                'current_epoch': row['current_epoch'],
                'created_at': row['created_at'],
                'last_refresh': row['last_refresh'],
                'auto_refresh_days': row['auto_refresh_days'],
            }
        except Exception:
            return None

    def store_share(self, did: str, guardian_id: str, epoch: int,
                    encrypted_share: str, commitments: List[int],
                    signature: str = None) -> None:
        """Store an encrypted share for a guardian."""
        conn = self._get_conn()
        conn.execute("""
            INSERT OR REPLACE INTO guardian_shares
                (id, did, guardian_id, epoch, encrypted_share, commitments, signature)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (str(uuid.uuid4()), did, guardian_id, epoch, encrypted_share,
              json.dumps([str(c) for c in commitments]), signature))
        conn.commit()

    def get_shares(self, did: str, epoch: int) -> List[Dict]:
        """
        Get all shares for a given DID and epoch.

        Each returned dict contains:
            guardian_id, encrypted_share, commitments, signature
        """
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT * FROM guardian_shares WHERE did=? AND epoch=? ORDER BY created_at",
            (did, epoch)
        ).fetchall()

        result = []
        for row in rows:
            result.append({
                'id': row['id'],
                'guardian_id': row['guardian_id'],   # key used by recovery.py
                'encrypted_share': row['encrypted_share'],
                'commitments': json.loads(row['commitments']),
                'signature': row['signature'],
            })
        return result

    def update_epoch(self, did: str, new_epoch: int) -> None:
        """Update the current epoch for a DID."""
        conn = self._get_conn()
        conn.execute(
            "UPDATE recovery_methods SET current_epoch=?, last_refresh=CURRENT_TIMESTAMP WHERE did=?",
            (new_epoch, did)
        )
        conn.commit()

    def record_refresh(self, did: str, from_epoch: int, to_epoch: int,
                       refresh_commitments: List[int], verified_by: str = "system") -> None:
        """Record a proactive refresh event."""
        conn = self._get_conn()
        conn.execute("""
            INSERT INTO refresh_history
                (id, did, from_epoch, to_epoch, refresh_commitments, verified_by)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (str(uuid.uuid4()), did, from_epoch, to_epoch,
              json.dumps([str(c) for c in refresh_commitments]), verified_by))
        conn.commit()

    def get_audit_log(self, did: str = None, limit: int = 100) -> List[Dict]:
        """Get audit log entries, optionally filtered by DID."""
        conn = self._get_conn()

        if did:
            rows = conn.execute("""
                SELECT action, status, details, epoch, timestamp, request_id
                FROM audit_log WHERE did=? ORDER BY timestamp DESC LIMIT ?
            """, (did, limit)).fetchall()
        else:
            rows = conn.execute("""
                SELECT did, action, status, details, epoch, timestamp, request_id
                FROM audit_log ORDER BY timestamp DESC LIMIT ?
            """, (limit,)).fetchall()

        return [dict(r) for r in rows]

    def get_refresh_history(self, did: str) -> List[Dict]:
        """Get refresh history for a DID."""
        conn = self._get_conn()
        rows = conn.execute("""
            SELECT from_epoch, to_epoch, refresh_commitments, performed_at, verified_by
            FROM refresh_history WHERE did=? ORDER BY performed_at DESC
        """, (did,)).fetchall()

        result = []
        for row in rows:
            r = dict(row)
            r['refresh_commitments'] = json.loads(r['refresh_commitments'])
            result.append(r)
        return result

    def list_dids(self) -> List[str]:
        """List all DIDs with active recovery configured."""
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT DISTINCT did FROM recovery_methods WHERE status = 'active'"
        ).fetchall()
        return [row['did'] for row in rows]

    def audit(self, did: str, action: str, status: str,
              details: str = None, epoch: int = None,
              request_id: str = None) -> None:
        """
        Public method to write an audit log entry.

        Called by RecoveryClient for operations (e.g. refresh) that are not
        performed inside storage helpers and therefore need to log explicitly.
        """
        conn = self._get_conn()
        self._audit(conn, did, action, status, details, epoch, request_id)
        conn.commit()

    def close(self):
        """Close the thread-local database connection."""
        if hasattr(self._local, 'conn'):
            self._local.conn.close()
            del self._local.conn

    # --------------------------------------------------------------------------
    # Private methods
    # --------------------------------------------------------------------------

    def _get_conn(self) -> sqlite3.Connection:
        """Get (or create) a thread-local database connection."""
        if not hasattr(self._local, 'conn'):
            conn = sqlite3.connect(self.db_path, timeout=30)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA busy_timeout=5000")
            conn.execute("PRAGMA foreign_keys=ON")
            self._local.conn = conn
        return self._local.conn

    def _init_db(self):
        """Initialize database schema."""
        conn = self._get_conn()

        conn.execute("""
            CREATE TABLE IF NOT EXISTS recovery_methods (
                id TEXT PRIMARY KEY,
                did TEXT UNIQUE NOT NULL,
                recovery_type TEXT NOT NULL,
                parameters TEXT NOT NULL,
                current_epoch INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_used TIMESTAMP,
                last_refresh TIMESTAMP,
                auto_refresh_days INTEGER DEFAULT 30,
                status TEXT DEFAULT 'active',
                metadata TEXT
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS guardian_shares (
                id TEXT PRIMARY KEY,
                did TEXT NOT NULL,
                guardian_id TEXT NOT NULL,
                epoch INTEGER NOT NULL,
                encrypted_share TEXT NOT NULL,
                commitments TEXT NOT NULL,
                signature TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                verified_at TIMESTAMP,
                UNIQUE(did, guardian_id, epoch)
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                id TEXT PRIMARY KEY,
                did TEXT NOT NULL,
                action TEXT NOT NULL,
                status TEXT NOT NULL,
                details TEXT,
                epoch INTEGER,
                ip_address TEXT,
                user_agent TEXT,
                request_id TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS refresh_history (
                id TEXT PRIMARY KEY,
                did TEXT NOT NULL,
                from_epoch INTEGER NOT NULL,
                to_epoch INTEGER NOT NULL,
                refresh_commitments TEXT NOT NULL,
                performed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                verified_by TEXT
            )
        """)

        conn.commit()

    def _audit(self, conn: sqlite3.Connection, did: str, action: str,
               status: str, details: str = None, epoch: int = None,
               request_id: str = None) -> None:
        """
        Internal helper — inserts an audit row using the provided connection.

        Does NOT commit; the caller is responsible for committing so that
        the audit entry and the associated data change land in the same
        transaction.
        """
        conn.execute("""
            INSERT INTO audit_log (id, did, action, status, details, epoch, request_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (str(uuid.uuid4()), did, action, status, details, epoch, request_id))


# --------------------------------------------------------------------------
# Context manager for easy use
# --------------------------------------------------------------------------

@contextmanager
def secure_storage(db_path: str = "recovery.db", encryption_key: bytes = None):
    """Context manager for SecureStorage."""
    storage = SecureStorage(db_path, encryption_key)
    try:
        yield storage
    finally:
        storage.close()