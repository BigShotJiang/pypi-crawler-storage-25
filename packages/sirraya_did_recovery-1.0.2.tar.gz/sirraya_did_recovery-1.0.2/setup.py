"""
Setup script for Sirraya DID Recovery SDK
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="sirraya_did_recovery",
    version="1.0.2",
    author="Sirraya Labs",
    author_email="amir@sirraya.org",
    description="Enterprise-grade DID recovery with social, deterministic, and MPC support",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/sirraya-labs/did-recovery",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Security :: Cryptography",
        "Topic :: Internet :: WWW/HTTP",
    ],
    python_requires=">=3.8",
    install_requires=[
        "cryptography>=41.0.0",
    ],
    extras_require={
        "api": ["flask>=2.0.0", "flask-cors>=4.0.0"],
        "eth": ["eth-account>=0.10.0", "web3>=6.0.0"],
        "dev": ["pytest>=7.0.0", "black", "mypy"],
    },
    project_urls={
        "Bug Reports": "https://github.com/sirraya-labs/did-recovery/issues",
        "Source": "https://github.com/sirraya-labs/did-recovery",
        "Documentation": "https://docs.sirraya.org/did-recovery",
    },
)