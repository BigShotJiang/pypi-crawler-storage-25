"""Top-level install/uninstall orchestration for MCP clients."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from memboot.clients import ClientAdapter, all_adapters, get_adapter
from memboot.clients.base import build_server_entry, entries_equivalent


@dataclass
class InstallResult:
    """Outcome of a single install or uninstall operation on one client."""

    client: str
    display_name: str
    config_path: Path
    # Possible values: installed, updated, unchanged, removed, absent, dry-run, skipped.
    status: str
    backup_path: Path | None = None
    detail: str = ""


@dataclass
class InstallPlan:
    """What would happen if you ran a given install/uninstall call."""

    results: list[InstallResult] = field(default_factory=list)

    def add(self, result: InstallResult) -> None:
        self.results.append(result)

    def any_changed(self) -> bool:
        return any(r.status in {"installed", "updated", "removed"} for r in self.results)


def install(
    clients: list[str] | None = None,
    *,
    server_name: str = "memboot",
    project: Path | None = None,
    all_detected: bool = False,
    all_known: bool = False,
    dry_run: bool = False,
    force: bool = False,
    backup: bool = True,
    backups_keep: int = 5,
) -> InstallPlan:
    """Install the memboot MCP server entry into one or more clients.

    Exactly one of `clients`, `all_detected`, or `all_known` must be specified.

    Args:
        clients: Explicit list of client names (from `memboot.clients.REGISTRY`).
        server_name: Name to register in the client config (default: "memboot").
        project: If given, `--project <path>` is baked into the server args.
        all_detected: Install into every client whose is_installed() returns True.
        all_known: Install into every registered client, creating missing configs.
        dry_run: Produce the plan without writing any files.
        force: Overwrite an existing memboot entry even if its contents differ.
        backup: Back up the previous config before overwriting.
        backups_keep: Retain at most this many timestamped backups per config.
    """
    adapters = _select_adapters(
        clients=clients,
        all_detected=all_detected,
        all_known=all_known,
    )
    entry = build_server_entry(project=project)
    plan = InstallPlan()

    for adapter in adapters:
        result = _install_one(
            adapter,
            server_name=server_name,
            entry=entry,
            dry_run=dry_run,
            force=force,
            backup=backup,
            backups_keep=backups_keep,
        )
        plan.add(result)

    return plan


def uninstall(
    clients: list[str] | None = None,
    *,
    server_name: str = "memboot",
    all_detected: bool = False,
    all_known: bool = False,
    dry_run: bool = False,
    backup: bool = True,
    backups_keep: int = 5,
) -> InstallPlan:
    """Remove the memboot MCP server entry from one or more clients."""
    adapters = _select_adapters(
        clients=clients,
        all_detected=all_detected,
        all_known=all_known,
    )
    plan = InstallPlan()

    for adapter in adapters:
        result = _uninstall_one(
            adapter,
            server_name=server_name,
            dry_run=dry_run,
            backup=backup,
            backups_keep=backups_keep,
        )
        plan.add(result)

    return plan


def installed_status(
    *,
    server_name: str = "memboot",
) -> list[InstallResult]:
    """Report which registered clients currently have memboot wired up."""
    results: list[InstallResult] = []
    for adapter in all_adapters():
        path = adapter.config_path()
        try:
            config = adapter.read_config()
        except Exception as exc:
            results.append(
                InstallResult(
                    client=adapter.name,
                    display_name=adapter.display_name,
                    config_path=path,
                    status="absent",
                    detail=f"config unreadable: {exc}",
                )
            )
            continue

        if adapter.has_server(config, server_name):
            results.append(
                InstallResult(
                    client=adapter.name,
                    display_name=adapter.display_name,
                    config_path=path,
                    status="installed",
                )
            )
        else:
            detail = "not installed"
            if not adapter.is_installed():
                detail = "client not detected"
            results.append(
                InstallResult(
                    client=adapter.name,
                    display_name=adapter.display_name,
                    config_path=path,
                    status="absent",
                    detail=detail,
                )
            )
    return results


def _select_adapters(
    *,
    clients: list[str] | None,
    all_detected: bool,
    all_known: bool,
) -> list[ClientAdapter]:
    selectors_used = sum(bool(x) for x in (clients, all_detected, all_known))
    if selectors_used != 1:
        raise ValueError("Specify exactly one of: clients, all_detected, all_known")
    if clients:
        return [get_adapter(name) for name in clients]
    if all_known:
        return all_adapters()
    return [a for a in all_adapters() if a.is_installed()]


def _install_one(
    adapter: ClientAdapter,
    *,
    server_name: str,
    entry: dict[str, Any],
    dry_run: bool,
    force: bool,
    backup: bool,
    backups_keep: int,
) -> InstallResult:
    path = adapter.config_path()
    config = adapter.read_config()
    already_there = adapter.has_server(config, server_name)

    if already_there:
        existing = (
            config["mcpServers"][server_name]
            if isinstance(config.get("mcpServers"), dict)
            else config.get("context_servers", {}).get(server_name, {})
        )
        if entries_equivalent(existing, entry):
            return InstallResult(
                client=adapter.name,
                display_name=adapter.display_name,
                config_path=path,
                status="unchanged",
                detail="already installed with matching config",
            )
        if not force:
            return InstallResult(
                client=adapter.name,
                display_name=adapter.display_name,
                config_path=path,
                status="skipped",
                detail="existing entry differs — pass force=True to overwrite",
            )

    new_config = adapter.inject_server(config, server_name, entry)

    if dry_run:
        return InstallResult(
            client=adapter.name,
            display_name=adapter.display_name,
            config_path=path,
            status="dry-run",
            detail="updated" if already_there else "new install",
        )

    backup_path = adapter.write_config(
        new_config,
        backup=backup,
        backups_keep=backups_keep,
    )

    return InstallResult(
        client=adapter.name,
        display_name=adapter.display_name,
        config_path=path,
        status="updated" if already_there else "installed",
        backup_path=backup_path,
    )


def _uninstall_one(
    adapter: ClientAdapter,
    *,
    server_name: str,
    dry_run: bool,
    backup: bool,
    backups_keep: int,
) -> InstallResult:
    path = adapter.config_path()
    config = adapter.read_config()

    if not adapter.has_server(config, server_name):
        return InstallResult(
            client=adapter.name,
            display_name=adapter.display_name,
            config_path=path,
            status="absent",
            detail="memboot was not registered in this client",
        )

    new_config = adapter.remove_server(config, server_name)

    if dry_run:
        return InstallResult(
            client=adapter.name,
            display_name=adapter.display_name,
            config_path=path,
            status="dry-run",
            detail="would remove memboot entry",
        )

    backup_path = adapter.write_config(
        new_config,
        backup=backup,
        backups_keep=backups_keep,
    )

    return InstallResult(
        client=adapter.name,
        display_name=adapter.display_name,
        config_path=path,
        status="removed",
        backup_path=backup_path,
    )
