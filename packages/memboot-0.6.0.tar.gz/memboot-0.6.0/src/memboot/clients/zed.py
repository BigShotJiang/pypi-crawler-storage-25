"""Zed editor adapter.

Zed stores MCP server entries under `context_servers` in its `settings.json`,
not under `mcpServers`. Everything else about the install flow is identical,
so we override just the injection methods.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import memboot.clients.base as base


class ZedAdapter(base.ClientAdapter):
    """Zed editor — ~/.config/zed/settings.json."""

    name = "zed"
    display_name = "Zed"

    def config_path(self) -> Path:
        if base._is_windows():
            return base._appdata() / "Zed" / "settings.json"
        return base._home() / ".config" / "zed" / "settings.json"

    def inject_server(
        self, config: dict[str, Any], server_name: str, entry: dict[str, Any]
    ) -> dict[str, Any]:
        new = dict(config)
        servers = dict(new.get("context_servers") or {})
        # Zed uses the same inner shape (command/args/env); harmless if schema evolves.
        servers[server_name] = entry
        new["context_servers"] = servers
        return new

    def remove_server(self, config: dict[str, Any], server_name: str) -> dict[str, Any]:
        new = dict(config)
        servers = dict(new.get("context_servers") or {})
        servers.pop(server_name, None)
        new["context_servers"] = servers
        return new

    def has_server(self, config: dict[str, Any], server_name: str) -> bool:
        servers = config.get("context_servers") or {}
        return server_name in servers
