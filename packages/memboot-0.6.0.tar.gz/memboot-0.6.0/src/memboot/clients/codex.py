"""OpenAI Codex CLI adapter.

Codex stores MCP server entries in TOML (not JSON) under the
`[mcp_servers.<name>]` table convention. Config lives at
`~/.codex/config.toml` and is shared between the Codex CLI and IDE extension.

Reference: https://developers.openai.com/codex/mcp
"""

from __future__ import annotations

import os
import tempfile
import tomllib
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import memboot.clients.base as base
from memboot.exceptions import ConfigParseError


class CodexAdapter(base.ClientAdapter):
    """OpenAI Codex CLI — ~/.codex/config.toml."""

    name = "codex"
    display_name = "OpenAI Codex CLI"

    def config_path(self) -> Path:
        return base._home() / ".codex" / "config.toml"

    def read_config(self) -> dict[str, Any]:
        """Parse the TOML config. Returns {} if file is missing or empty."""
        path = self.config_path()
        if not path.exists():
            return {}
        try:
            text = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise ConfigParseError(f"Cannot read {path}: {exc}") from exc
        if not text.strip():
            return {}
        try:
            data = tomllib.loads(text)
        except tomllib.TOMLDecodeError as exc:
            raise ConfigParseError(f"{path} is not valid TOML: {exc}") from exc
        return data

    def write_config(
        self,
        config: dict[str, Any],
        *,
        backup: bool = True,
        backups_keep: int = 5,
    ) -> Path | None:
        """Atomically write TOML config, optionally backing up prior version."""
        try:
            import tomli_w
        except ImportError as exc:
            raise ConfigParseError(
                "Writing Codex config requires `tomli-w`. "
                "Reinstall memboot or run `pip install tomli-w`."
            ) from exc

        path = self.config_path()
        path.parent.mkdir(parents=True, exist_ok=True)

        backup_path: Path | None = None
        if backup and path.exists():
            timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
            backup_path = path.parent / f"{path.name}.memboot-backup-{timestamp}"
            backup_path.write_bytes(path.read_bytes())
            self._prune_backups(path, keep=backups_keep)

        payload = tomli_w.dumps(config)
        with tempfile.NamedTemporaryFile(
            "w",
            dir=path.parent,
            prefix=f".{path.name}.tmp",
            suffix=".toml",
            delete=False,
            encoding="utf-8",
        ) as tmp:
            tmp.write(payload)
            tmp_path = Path(tmp.name)
        os.replace(tmp_path, path)
        return backup_path

    def inject_server(
        self, config: dict[str, Any], server_name: str, entry: dict[str, Any]
    ) -> dict[str, Any]:
        new = dict(config)
        servers = dict(new.get("mcp_servers") or {})
        servers[server_name] = entry
        new["mcp_servers"] = servers
        return new

    def remove_server(self, config: dict[str, Any], server_name: str) -> dict[str, Any]:
        new = dict(config)
        servers = dict(new.get("mcp_servers") or {})
        servers.pop(server_name, None)
        new["mcp_servers"] = servers
        return new

    def has_server(self, config: dict[str, Any], server_name: str) -> bool:
        servers = config.get("mcp_servers") or {}
        return server_name in servers
