"""ollmcp adapter (jonigl/mcp-client-for-ollama).

ollmcp reads MCP server entries from `~/.config/ollmcp/config.json` using
the standard `mcpServers` key — same shape as Claude Desktop, Cursor,
Windsurf.

Reference: https://github.com/jonigl/mcp-client-for-ollama
"""

from __future__ import annotations

from pathlib import Path

import memboot.clients.base as base


class OllmcpAdapter(base.StandardMcpAdapter):
    """ollmcp — ~/.config/ollmcp/config.json (JSON, mcpServers)."""

    name = "ollmcp"
    display_name = "ollmcp (Ollama MCP client)"

    def config_path(self) -> Path:
        return base._home() / ".config" / "ollmcp" / "config.json"
