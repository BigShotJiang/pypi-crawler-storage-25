"""Claude Desktop app adapter."""

from __future__ import annotations

from pathlib import Path

import memboot.clients.base as base


class ClaudeDesktopAdapter(base.StandardMcpAdapter):
    """Anthropic's desktop app. Config path varies by OS."""

    name = "claude-desktop"
    display_name = "Claude Desktop"

    def config_path(self) -> Path:
        if base._is_macos():
            return (
                base._home()
                / "Library"
                / "Application Support"
                / "Claude"
                / "claude_desktop_config.json"
            )
        if base._is_windows():
            return base._appdata() / "Claude" / "claude_desktop_config.json"
        # Linux / other: follow the macOS-style naming under XDG config.
        return base._home() / ".config" / "Claude" / "claude_desktop_config.json"
