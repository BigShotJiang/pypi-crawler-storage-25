"""LibreChat adapter (self-hosted multi-model chat UI with MCP support).

LibreChat reads `librechat.yaml` for its full configuration — endpoints,
models, and MCP servers under the top-level `mcpServers` key. The shape of
each server entry matches the JSON-based clients (command, args, env), only
the on-disk format is YAML.

Because LibreChat is deployed via Docker / git-clone (no pip install), it
has no canonical home for the YAML file. memboot defaults to
`~/.config/librechat/librechat.yaml` and honors the
`MEMBOOT_LIBRECHAT_CONFIG` environment variable as an explicit override
for users whose `librechat.yaml` lives elsewhere (e.g.
`~/LibreChat/librechat.yaml` for the standard self-host clone).

Reference: https://www.librechat.ai/docs/features/mcp
"""

from __future__ import annotations

import os
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml

import memboot.clients.base as base
from memboot.exceptions import ConfigParseError


class LibreChatAdapter(base.ClientAdapter):
    """LibreChat — librechat.yaml (YAML, mcpServers)."""

    name = "librechat"
    display_name = "LibreChat"

    def config_path(self) -> Path:
        env = os.environ.get("MEMBOOT_LIBRECHAT_CONFIG")
        if env:
            return Path(env).expanduser()
        return base._home() / ".config" / "librechat" / "librechat.yaml"

    def read_config(self) -> dict[str, Any]:
        path = self.config_path()
        if not path.exists():
            return {}
        try:
            text = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise ConfigParseError(f"Cannot read {path}: {exc}") from exc
        if not text.strip():
            return {}
        try:
            data = yaml.safe_load(text)
        except yaml.YAMLError as exc:
            raise ConfigParseError(f"{path} is not valid YAML: {exc}") from exc
        if data is None:
            return {}
        if not isinstance(data, dict):
            raise ConfigParseError(f"{path} root must be a YAML mapping, got {type(data).__name__}")
        return data

    def write_config(
        self,
        config: dict[str, Any],
        *,
        backup: bool = True,
        backups_keep: int = 5,
    ) -> Path | None:
        path = self.config_path()
        path.parent.mkdir(parents=True, exist_ok=True)

        backup_path: Path | None = None
        if backup and path.exists():
            timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
            backup_path = path.parent / f"{path.name}.memboot-backup-{timestamp}"
            backup_path.write_bytes(path.read_bytes())
            self._prune_backups(path, keep=backups_keep)

        payload = yaml.safe_dump(config, sort_keys=False, default_flow_style=False)
        with tempfile.NamedTemporaryFile(
            "w",
            dir=path.parent,
            prefix=f".{path.name}.tmp",
            suffix=".yaml",
            delete=False,
            encoding="utf-8",
        ) as tmp:
            tmp.write(payload)
            tmp_path = Path(tmp.name)
        os.replace(tmp_path, path)
        return backup_path

    def inject_server(
        self, config: dict[str, Any], server_name: str, entry: dict[str, Any]
    ) -> dict[str, Any]:
        new = dict(config)
        servers = dict(new.get("mcpServers") or {})
        servers[server_name] = entry
        new["mcpServers"] = servers
        return new

    def remove_server(self, config: dict[str, Any], server_name: str) -> dict[str, Any]:
        new = dict(config)
        servers = dict(new.get("mcpServers") or {})
        servers.pop(server_name, None)
        new["mcpServers"] = servers
        return new

    def has_server(self, config: dict[str, Any], server_name: str) -> bool:
        servers = config.get("mcpServers") or {}
        return server_name in servers
