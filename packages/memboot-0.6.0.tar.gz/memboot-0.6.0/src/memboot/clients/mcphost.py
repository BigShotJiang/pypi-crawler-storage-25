"""mcphost adapter (mark3labs/mcphost — Ollama-friendly MCP host CLI).

mcphost looks up `~/.mcphost.json` (or `~/.mcphost.yml`) for its server
registry. memboot writes the JSON variant. If a user already has a YAML
config, they should rename it to `.mcphost.json` or merge memboot's entry
manually — the JSON file is what `memboot install mcphost` will create.

Reference: https://github.com/mark3labs/mcphost
"""

from __future__ import annotations

import shutil
from pathlib import Path

import memboot.clients.base as base


class MCPHostAdapter(base.StandardMcpAdapter):
    """mcphost CLI — ~/.mcphost.json (JSON, mcpServers)."""

    name = "mcphost"
    display_name = "mcphost (Ollama MCP host)"

    def config_path(self) -> Path:
        return base._home() / ".mcphost.json"

    def is_installed(self) -> bool:
        """Default check (parent dir exists) is too lax — parent is $HOME.

        Treat mcphost as installed if any of:
          - JSON config exists
          - YAML config exists (sibling format mcphost also reads)
          - mcphost binary is on PATH
        """
        if self.config_path().exists():
            return True
        if (base._home() / ".mcphost.yml").exists():
            return True
        return shutil.which("mcphost") is not None
