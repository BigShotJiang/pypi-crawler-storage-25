"""Base adapter for MCP clients."""

from __future__ import annotations

import contextlib
import json
import os
import sys
import tempfile
from abc import ABC, abstractmethod
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from memboot.exceptions import ConfigParseError


def _home() -> Path:
    """Resolve the user's home directory. Extracted for test override."""
    return Path.home()


def _appdata() -> Path:
    """Windows: %APPDATA%. Fall back to ~/.config on other platforms."""
    env = os.environ.get("APPDATA")
    if env:
        return Path(env)
    return _home() / ".config"


def _is_windows() -> bool:
    return sys.platform == "win32"


def _is_macos() -> bool:
    return sys.platform == "darwin"


def build_server_entry(
    project: Path | None = None,
    extra_args: list[str] | None = None,
) -> dict[str, Any]:
    """Produce the standard memboot MCP server entry.

    Args:
        project: If set, the server is bound to this project via `--project`.
        extra_args: Additional args appended after the base `serve` command.

    Returns:
        A dict in MCP server spec shape: {"command": ..., "args": [...], "env": {...}}
    """
    args = ["serve"]
    if project is not None:
        args.extend(["--project", str(project)])
    if extra_args:
        args.extend(extra_args)
    return {"command": "memboot", "args": args, "env": {}}


def entries_equivalent(a: dict[str, Any], b: dict[str, Any]) -> bool:
    """Structural equality on MCP server entries — tolerates ordering differences."""
    if a.keys() != b.keys():
        return False
    for key in a:
        if key == "args":
            if list(a[key]) != list(b[key]):
                return False
        elif a[key] != b[key]:
            return False
    return True


class ClientAdapter(ABC):
    """Abstract base for every MCP client integration.

    Concrete subclasses must set `name` and `display_name` and implement
    `config_path`, `inject_server`, `remove_server`, `has_server`.
    """

    name: str = ""
    display_name: str = ""

    @abstractmethod
    def config_path(self) -> Path:
        """Resolve the OS-specific config path for this client."""

    def is_installed(self) -> bool:
        """Return True if the client appears present on this machine.

        Default: config file exists, or its parent directory exists.
        Override if a client needs a smarter check.
        """
        path = self.config_path()
        return path.exists() or path.parent.exists()

    def read_config(self) -> dict[str, Any]:
        """Load the current config as a dict.

        Returns an empty dict if the file does not exist. Raises ConfigParseError
        if the file exists but is not valid JSON.
        """
        path = self.config_path()
        if not path.exists():
            return {}
        try:
            text = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise ConfigParseError(f"Cannot read {path}: {exc}") from exc
        if not text.strip():
            return {}
        try:
            data = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ConfigParseError(
                f"{path} is not valid JSON: {exc.msg} (line {exc.lineno}, col {exc.colno})"
            ) from exc
        if not isinstance(data, dict):
            raise ConfigParseError(f"{path} root must be a JSON object, got {type(data).__name__}")
        return data

    @abstractmethod
    def inject_server(
        self, config: dict[str, Any], server_name: str, entry: dict[str, Any]
    ) -> dict[str, Any]:
        """Return a new config with the server entry added or updated."""

    @abstractmethod
    def remove_server(self, config: dict[str, Any], server_name: str) -> dict[str, Any]:
        """Return a new config with the server entry removed (no-op if absent)."""

    @abstractmethod
    def has_server(self, config: dict[str, Any], server_name: str) -> bool:
        """Return True if the named server is currently registered."""

    def write_config(
        self,
        config: dict[str, Any],
        *,
        backup: bool = True,
        backups_keep: int = 5,
    ) -> Path | None:
        """Atomically write config, optionally backing up the prior version.

        Returns the backup path if one was written, else None.
        """
        path = self.config_path()
        path.parent.mkdir(parents=True, exist_ok=True)

        backup_path: Path | None = None
        if backup and path.exists():
            timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
            backup_path = path.parent / f"{path.name}.memboot-backup-{timestamp}"
            backup_path.write_bytes(path.read_bytes())
            self._prune_backups(path, keep=backups_keep)

        payload = json.dumps(config, indent=2, sort_keys=False) + "\n"
        with tempfile.NamedTemporaryFile(
            "w",
            dir=path.parent,
            prefix=f".{path.name}.tmp",
            suffix=".json",
            delete=False,
            encoding="utf-8",
        ) as tmp:
            tmp.write(payload)
            tmp_path = Path(tmp.name)
        os.replace(tmp_path, path)
        return backup_path

    def _prune_backups(self, path: Path, *, keep: int) -> None:
        """Keep only the N most recent `.memboot-backup-*` files for this config."""
        if keep < 0:
            return
        pattern = f"{path.name}.memboot-backup-*"
        backups = sorted(
            path.parent.glob(pattern),
            key=lambda p: p.name,
            reverse=True,
        )
        for stale in backups[keep:]:
            # Stale backup cleanup is best-effort; a failure here is not fatal.
            with contextlib.suppress(OSError):
                stale.unlink()


class StandardMcpAdapter(ClientAdapter):
    """Shared implementation for clients that use the `mcpServers.<name>` convention.

    Covers Claude Code, Claude Desktop, Cursor, Windsurf.
    """

    def inject_server(
        self, config: dict[str, Any], server_name: str, entry: dict[str, Any]
    ) -> dict[str, Any]:
        new = dict(config)
        servers = dict(new.get("mcpServers") or {})
        servers[server_name] = entry
        new["mcpServers"] = servers
        return new

    def remove_server(self, config: dict[str, Any], server_name: str) -> dict[str, Any]:
        new = dict(config)
        servers = dict(new.get("mcpServers") or {})
        servers.pop(server_name, None)
        new["mcpServers"] = servers
        return new

    def has_server(self, config: dict[str, Any], server_name: str) -> bool:
        servers = config.get("mcpServers") or {}
        return server_name in servers
