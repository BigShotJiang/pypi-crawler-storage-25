"""Windsurf (Codeium) adapter."""

from __future__ import annotations

from pathlib import Path

import memboot.clients.base as base


class WindsurfAdapter(base.StandardMcpAdapter):
    """Codeium's Windsurf IDE — ~/.codeium/windsurf/mcp_config.json."""

    name = "windsurf"
    display_name = "Windsurf"

    def config_path(self) -> Path:
        return base._home() / ".codeium" / "windsurf" / "mcp_config.json"
