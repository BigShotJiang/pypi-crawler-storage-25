"""Cursor adapter."""

from __future__ import annotations

from pathlib import Path

import memboot.clients.base as base


class CursorAdapter(base.StandardMcpAdapter):
    """Cursor IDE — global config at ~/.cursor/mcp.json."""

    name = "cursor"
    display_name = "Cursor"

    def config_path(self) -> Path:
        return base._home() / ".cursor" / "mcp.json"
