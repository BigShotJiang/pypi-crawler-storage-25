"""MCP client adapters for `memboot install` / `memboot uninstall`."""

from __future__ import annotations

from memboot.clients.base import ClientAdapter
from memboot.clients.claude_code import ClaudeCodeAdapter
from memboot.clients.claude_desktop import ClaudeDesktopAdapter
from memboot.clients.codex import CodexAdapter
from memboot.clients.cursor import CursorAdapter
from memboot.clients.librechat import LibreChatAdapter
from memboot.clients.mcphost import MCPHostAdapter
from memboot.clients.ollmcp import OllmcpAdapter
from memboot.clients.windsurf import WindsurfAdapter
from memboot.clients.zed import ZedAdapter

REGISTRY: dict[str, type[ClientAdapter]] = {
    ClaudeCodeAdapter.name: ClaudeCodeAdapter,
    ClaudeDesktopAdapter.name: ClaudeDesktopAdapter,
    CodexAdapter.name: CodexAdapter,
    CursorAdapter.name: CursorAdapter,
    LibreChatAdapter.name: LibreChatAdapter,
    MCPHostAdapter.name: MCPHostAdapter,
    OllmcpAdapter.name: OllmcpAdapter,
    WindsurfAdapter.name: WindsurfAdapter,
    ZedAdapter.name: ZedAdapter,
}


def all_adapters() -> list[ClientAdapter]:
    """Instantiate every registered adapter."""
    return [cls() for cls in REGISTRY.values()]


def get_adapter(name: str) -> ClientAdapter:
    """Look up an adapter by name. Raises KeyError with a helpful message."""
    try:
        return REGISTRY[name]()
    except KeyError as exc:
        known = ", ".join(sorted(REGISTRY))
        raise KeyError(f"Unknown client '{name}'. Known clients: {known}") from exc


__all__ = [
    "REGISTRY",
    "ClaudeCodeAdapter",
    "ClaudeDesktopAdapter",
    "ClientAdapter",
    "CodexAdapter",
    "CursorAdapter",
    "LibreChatAdapter",
    "MCPHostAdapter",
    "OllmcpAdapter",
    "WindsurfAdapter",
    "ZedAdapter",
    "all_adapters",
    "get_adapter",
]
