"""Claude Code CLI adapter."""

from __future__ import annotations

from pathlib import Path

import memboot.clients.base as base


class ClaudeCodeAdapter(base.StandardMcpAdapter):
    """Anthropic's Claude Code CLI — ~/.claude/mcp.json."""

    name = "claude-code"
    display_name = "Claude Code"

    def config_path(self) -> Path:
        return base._home() / ".claude" / "mcp.json"
