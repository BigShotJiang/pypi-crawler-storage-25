"""CLI entry point for memboot."""

from __future__ import annotations

import json as json_mod
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from memboot import __version__
from memboot.exceptions import MembootError
from memboot.licensing import (
    TIER_DEFINITIONS,
    get_license_info,
    get_upgrade_message,
    has_feature,
)
from memboot.telemetry import track_command, track_pro_gate

app = typer.Typer(
    name="memboot",
    help="Zero-infrastructure persistent memory for any LLM.",
)
console = Console()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """Zero-infrastructure persistent memory for any LLM."""
    if version:
        console.print(f"memboot {__version__}")
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        console.print(ctx.get_help())
        raise typer.Exit()


@app.command()
def status() -> None:
    """Show license status and available features."""
    track_command("status")
    info = get_license_info()
    tier_config = TIER_DEFINITIONS[info.tier]

    console.print(f"\n[bold]memboot {__version__}[/bold]")
    console.print(f"[bold]Tier:[/bold] {tier_config.name} ({tier_config.price_label})")

    if info.license_key:
        masked = info.license_key[:9] + "****-****"
        console.print(f"[bold]Key:[/bold] {masked}")
        valid_str = "[green]valid[/green]" if info.valid else "[red]invalid[/red]"
        console.print(f"[bold]Valid:[/bold] {valid_str}")

    console.print(f"\n[bold]Features:[/bold] {', '.join(tier_config.features)}")
    console.print()


@app.command(name="init")
def init_cmd(
    project_dir: Path = typer.Argument(".", help="Project directory to index."),
    force: bool = typer.Option(False, "--force", "-f", help="Force full reindex."),
    backend: str = typer.Option("tfidf", "--backend", "-b", help="Embedding backend."),
) -> None:
    """Scan, chunk, embed, and index a project."""
    track_command("init")
    from memboot.indexer import index_project
    from memboot.models import MembootConfig

    try:
        config = MembootConfig(embedding_backend=backend)
        info = index_project(project_dir.resolve(), config=config, force=force)
        meta = info.metadata
        if meta:
            new_chunks = meta.get("new_chunks", info.chunk_count)
            changed = meta.get("changed_files", 0)
            new_f = meta.get("new_files", 0)
            unchanged = meta.get("unchanged_files", 0)
            deleted = meta.get("deleted_files", 0)
            parts = []
            if changed:
                parts.append(f"{changed} changed")
            if new_f:
                parts.append(f"{new_f} new")
            if unchanged:
                parts.append(f"{unchanged} unchanged")
            if deleted:
                parts.append(f"{deleted} deleted")
            file_summary = ", ".join(parts)
            console.print(
                f"\n[green]Indexed {new_chunks} new chunks[/green] ({info.chunk_count} total)"
            )
            if file_summary:
                console.print(f"[dim]Files: {file_summary}[/dim]")
        else:
            console.print(f"\n[green]Indexed {info.chunk_count} chunks[/green]")
        console.print(f"[dim]DB: {info.db_path}[/dim]")
        console.print(f"[dim]Backend: {info.embedding_backend}, dim: {info.embedding_dim}[/dim]")
        console.print()
    except MembootError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1) from exc


@app.command()
def query(
    text: str = typer.Argument(..., help="Search query."),
    project_dir: Path = typer.Option(".", "--project", "-p", help="Project directory."),
    top_k: int = typer.Option(5, "--top-k", "-k", help="Number of results."),
    json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Search project memory."""
    track_command("query")
    from memboot.query import search

    try:
        results = search(text, project_dir.resolve(), top_k=top_k)
    except MembootError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1) from exc

    if json:
        data = [r.model_dump(exclude_none=True) for r in results]
        console.print_json(json_mod.dumps(data, indent=2))
        return

    if not results:
        console.print("[dim]No results found.[/dim]")
        return

    table = Table(title=f"Results for: {text}")
    table.add_column("Source", style="cyan")
    table.add_column("Score", style="green", justify="right")
    table.add_column("Content", max_width=60)

    for r in results:
        source = r.source
        if r.start_line is not None:
            source += f":{r.start_line}"
        content_preview = r.content[:100].replace("\n", " ")
        if len(r.content) > 100:
            content_preview += "..."
        table.add_row(source, f"{r.score:.3f}", content_preview)

    console.print(table)


@app.command()
def remember(
    content: str = typer.Argument(..., help="Content to remember."),
    memory_type: str = typer.Option("note", "--type", "-t", help="Memory type."),
    project_dir: Path = typer.Option(".", "--project", "-p", help="Project directory."),
    tags: list[str] | None = typer.Option(None, "--tag", help="Tags (repeatable)."),
) -> None:
    """Store an episodic memory."""
    track_command("remember")
    from memboot.memory import remember as remember_fn
    from memboot.models import MemoryType

    try:
        mem_type = MemoryType(memory_type)
    except ValueError:
        console.print(f"[red]Unknown memory type:[/red] {memory_type}")
        console.print(f"[dim]Valid types: {', '.join(t.value for t in MemoryType)}[/dim]")
        raise typer.Exit(1) from None

    try:
        memory = remember_fn(content, mem_type, project_dir.resolve(), tags=tags)
        console.print(f"[green]Remembered:[/green] {memory.content[:80]}")
        console.print(f"[dim]ID: {memory.id}[/dim]")
    except MembootError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1) from exc


@app.command()
def context(
    query_text: str = typer.Argument(..., help="Query for context."),
    project_dir: Path = typer.Option(".", "--project", "-p", help="Project directory."),
    max_tokens: int = typer.Option(4000, "--max-tokens", help="Token budget."),
    top_k: int = typer.Option(10, "--top-k", "-k", help="Max results to consider."),
) -> None:
    """Export formatted context block."""
    track_command("context")
    from memboot.context import build_context

    try:
        ctx = build_context(query_text, project_dir.resolve(), max_tokens=max_tokens, top_k=top_k)
        console.print(ctx)
    except MembootError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1) from exc


@app.command()
def reset(
    project_dir: Path = typer.Option(".", "--project", "-p", help="Project directory."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Clear all indexed data and memories."""
    track_command("reset")
    from memboot.indexer import get_db_path

    db_path = get_db_path(project_dir.resolve())
    if not db_path.exists():
        console.print("[dim]No index found. Nothing to reset.[/dim]")
        return

    if not yes:
        confirm = typer.confirm("This will delete all indexed data and memories. Continue?")
        if not confirm:
            raise typer.Abort()

    from memboot.store import MembootStore

    store = MembootStore(db_path)
    store.reset()
    store.close()
    console.print("[green]Memory reset.[/green]")


@app.command()
def ingest(
    source: str = typer.Argument(..., help="File path or URL to ingest."),
    project_dir: Path = typer.Option(".", "--project", "-p", help="Project directory."),
) -> None:
    """Ingest an external file into project memory."""
    track_command("ingest")
    if source.startswith(("http://", "https://")):
        if not has_feature("ingest_web"):
            track_pro_gate("ingest_web")
            console.print(f"[yellow]{get_upgrade_message('ingest_web')}[/yellow]")
            raise typer.Exit(1)
        from memboot.ingest.web import ingest_url

        try:
            chunks = ingest_url(source, project_dir.resolve())
            console.print(f"[green]Ingested {len(chunks)} chunks from URL.[/green]")
        except MembootError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(1) from exc
    elif source.lower().endswith(".pdf"):
        if not has_feature("ingest_pdf"):
            track_pro_gate("ingest_pdf")
            console.print(f"[yellow]{get_upgrade_message('ingest_pdf')}[/yellow]")
            raise typer.Exit(1)
        from memboot.ingest.pdf import ingest_pdf

        try:
            chunks = ingest_pdf(Path(source), project_dir.resolve())
            console.print(f"[green]Ingested {len(chunks)} chunks from PDF.[/green]")
        except MembootError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(1) from exc
    else:
        from memboot.ingest.files import ingest_file

        try:
            chunks = ingest_file(Path(source), project_dir.resolve())
            console.print(f"[green]Ingested {len(chunks)} chunks from {source}.[/green]")
        except MembootError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(1) from exc


@app.command()
def watch(
    project_dir: Path = typer.Argument(".", help="Project directory to watch."),
    debounce: float = typer.Option(2.0, "--debounce", "-d", help="Seconds to wait after changes."),
    backend: str = typer.Option("tfidf", "--backend", "-b", help="Embedding backend."),
) -> None:
    """Watch project directory and auto-reindex on changes."""
    track_command("watch")
    from memboot.models import MembootConfig

    config = MembootConfig(embedding_backend=backend)

    def _on_reindex(info):
        meta = info.metadata
        new_chunks = meta.get("new_chunks", 0) if meta else 0
        console.print(
            f"[green]Reindexed:[/green] {new_chunks} new chunks ({info.chunk_count} total)"
        )

    def _on_watch_error(exc: Exception):
        console.print(f"[red]Watch error:[/red] {exc}")

    console.print(f"[bold]Watching[/bold] {project_dir.resolve()}")
    console.print(f"[dim]Debounce: {debounce}s | Backend: {backend}[/dim]")
    console.print("[dim]Press Ctrl+C to stop.[/dim]\n")

    try:
        from memboot.watcher import watch_project

        watch_project(
            project_dir.resolve(),
            config=config,
            debounce=debounce,
            on_reindex=_on_reindex,
            on_error=_on_watch_error,
        )
    except MembootError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1) from exc


@app.command()
def serve(
    project_dir: Path = typer.Option(".", "--project", "-p", help="Project directory."),
) -> None:
    """Start MCP stdio server."""
    track_command("serve")

    import asyncio

    from memboot.mcp_server import run_server

    try:
        asyncio.run(run_server(project_dir.resolve()))
    except MembootError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1) from exc


def _render_install_plan(plan_results: list, action: str) -> None:
    """Print the result of install/uninstall as a rich table."""
    table = Table(title=f"memboot {action}")
    table.add_column("Client", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Config", style="dim")
    table.add_column("Detail", style="dim")

    status_styles = {
        "installed": "green",
        "updated": "yellow",
        "unchanged": "dim",
        "removed": "red",
        "absent": "dim",
        "dry-run": "magenta",
        "skipped": "yellow",
    }

    for result in plan_results:
        status = f"[{status_styles.get(result.status, 'white')}]{result.status}[/]"
        table.add_row(
            result.display_name,
            status,
            str(result.config_path),
            result.detail,
        )

    console.print(table)


@app.command(name="install")
def install_cmd(
    client: str | None = typer.Option(
        None,
        "--client",
        help="Install into a single client (e.g. claude-code, cursor, windsurf).",
    ),
    all_detected: bool = typer.Option(
        False,
        "--all-detected",
        help="Install into every client whose config path already exists.",
    ),
    all_known: bool = typer.Option(
        False,
        "--all",
        help="Install into every registered client, creating configs as needed.",
    ),
    project: Path | None = typer.Option(
        None,
        "--project",
        "-p",
        help="Bind the server to a specific project path.",
    ),
    server_name: str = typer.Option(
        "memboot",
        "--server-name",
        help="Name for the MCP server entry (default: memboot).",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Show what would change without writing any files.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Overwrite an existing entry even if its contents differ.",
    ),
    no_backup: bool = typer.Option(
        False,
        "--no-backup",
        help="Skip writing a timestamped backup of the prior config.",
    ),
) -> None:
    """Install memboot as an MCP server for your AI coding agent(s)."""
    track_command("install")
    from memboot.installer import install as run_install

    clients = [client] if client else None
    try:
        plan = run_install(
            clients=clients,
            server_name=server_name,
            project=project.resolve() if project else None,
            all_detected=all_detected,
            all_known=all_known,
            dry_run=dry_run,
            force=force,
            backup=not no_backup,
        )
    except (ValueError, KeyError) as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1) from exc

    _render_install_plan(plan.results, "install" + (" (dry-run)" if dry_run else ""))


@app.command(name="uninstall")
def uninstall_cmd(
    client: str | None = typer.Option(None, "--client", help="Uninstall from a single client."),
    all_detected: bool = typer.Option(
        False,
        "--all-detected",
        help="Uninstall from every client whose config path exists.",
    ),
    all_known: bool = typer.Option(
        False,
        "--all",
        help="Uninstall from every registered client.",
    ),
    server_name: str = typer.Option(
        "memboot",
        "--server-name",
        help="Name of the server entry to remove (default: memboot).",
    ),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would change."),
    no_backup: bool = typer.Option(False, "--no-backup", help="Skip config backup."),
) -> None:
    """Remove memboot's MCP server entry from your AI coding agent(s)."""
    track_command("uninstall")
    from memboot.installer import uninstall as run_uninstall

    clients = [client] if client else None
    try:
        plan = run_uninstall(
            clients=clients,
            server_name=server_name,
            all_detected=all_detected,
            all_known=all_known,
            dry_run=dry_run,
            backup=not no_backup,
        )
    except (ValueError, KeyError) as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1) from exc

    _render_install_plan(plan.results, "uninstall" + (" (dry-run)" if dry_run else ""))


@app.command(name="installed")
def installed_cmd(
    server_name: str = typer.Option(
        "memboot",
        "--server-name",
        help="Server entry name to check for (default: memboot).",
    ),
) -> None:
    """List which MCP clients currently have memboot registered."""
    track_command("installed")
    from memboot.installer import installed_status

    results = installed_status(server_name=server_name)
    _render_install_plan(results, "installed status")


@app.command()
def stats(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show local usage telemetry (requires MEMBOOT_TELEMETRY=1)."""
    from memboot.telemetry import TelemetryStore, _telemetry_dir, is_enabled

    track_command("stats")

    if not is_enabled():
        console.print(
            "[dim]Telemetry is disabled. "
            "Set MEMBOOT_TELEMETRY=1 to enable local usage tracking.[/dim]"
        )
        return

    db_file = _telemetry_dir() / "telemetry.db"
    if not db_file.exists():
        console.print("[dim]No telemetry data yet.[/dim]")
        return

    ts = TelemetryStore(db_file)
    try:
        commands = ts.get_command_counts()
        pro_gates = ts.get_pro_gate_counts()
        total = ts.get_total_events()
        first = ts.get_first_event_time()
        last = ts.get_last_event_time()
        activity = ts.get_daily_activity()

        if json_output:
            data = {
                "total_events": total,
                "first_event": first,
                "last_event": last,
                "commands": commands,
                "pro_gate_hits": pro_gates,
                "daily_activity": [{"date": d, "count": c} for d, c in activity],
            }
            console.print(json_mod.dumps(data, indent=2))
        else:
            overview = Table(title="Telemetry Overview")
            overview.add_column("Metric", style="cyan")
            overview.add_column("Value", style="green")
            overview.add_row("Total Events", str(total))
            overview.add_row("First Event", first or "n/a")
            overview.add_row("Last Event", last or "n/a")
            console.print(overview)

            if commands:
                cmd_table = Table(title="Command Usage")
                cmd_table.add_column("Command", style="cyan")
                cmd_table.add_column("Count", style="green", justify="right")
                for name, count in commands.items():
                    cmd_table.add_row(name, str(count))
                console.print(cmd_table)

            if pro_gates:
                gate_table = Table(title="Pro Feature Gate Hits")
                gate_table.add_column("Feature", style="cyan")
                gate_table.add_column("Attempts", style="yellow", justify="right")
                for name, count in pro_gates.items():
                    gate_table.add_row(name, str(count))
                console.print(gate_table)

            if activity:
                act_table = Table(title="Daily Activity (Last 7 Days)")
                act_table.add_column("Date", style="cyan")
                act_table.add_column("Events", style="green", justify="right")
                for day, count in activity:
                    act_table.add_row(day, str(count))
                console.print(act_table)
    finally:
        ts.close()
