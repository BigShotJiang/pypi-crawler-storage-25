# Integrations — wiring memboot into your AI coding agent

Memboot works with any MCP-compatible client. Nine are supported out of the box:

- **Claude Code** (Anthropic's CLI)
- **Claude Desktop** (Anthropic's desktop app)
- **Cursor**
- **Windsurf** (Codeium)
- **Zed**
- **OpenAI Codex CLI**
- **mcphost** (Ollama-friendly MCP host CLI by mark3labs)
- **ollmcp** (Ollama MCP client by jonigl)
- **LibreChat** (self-hosted multi-model chat UI)

Because all nine read the same `memboot serve --project <path>` server entry against the same per-project SQLite store, you can run Codex, Qwen via mcphost, and Claude Code against the same project and they share one memory layer — query in one, see results in another.

You don't need to edit any config files yourself. The `memboot install` command detects each client, writes the correct MCP server entry, and leaves a timestamped backup of any prior config.

---

## Quick start — install everywhere at once

```bash
pip install memboot
memboot init .                     # index the current project
memboot install --all-detected     # add memboot to every client you have
```

That's it. Restart your AI coding agent. Memboot's tools (`query_memory`, `remember`, `get_context`) appear in the tool list, bound to the project you just indexed.

**Expected output:**

```
                                memboot install
┏━━━━━━━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━┓
┃ Client         ┃ Status    ┃ Config                                 ┃ Detail ┃
┡━━━━━━━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━┩
│ Claude Code    │ installed │ /home/you/.claude/mcp.json             │        │
│ Claude Desktop │ installed │ …/Claude/claude_desktop_config.json    │        │
│ Cursor         │ installed │ /home/you/.cursor/mcp.json             │        │
│ Windsurf       │ installed │ /home/you/.codeium/windsurf/…          │        │
│ Zed            │ installed │ /home/you/.config/zed/settings.json    │        │
│ Codex          │ installed │ /home/you/.codex/config.toml           │        │
└────────────────┴───────────┴────────────────────────────────────────┴────────┘
```

Want to install into only the clients you already have set up? Use `--all-detected` (the default recommendation). Want to install into every known client whether or not it's present? Use `--all`. Want to target one? `--client <name>`.

---

## Per-client details

### Claude Code (Anthropic CLI)

| | |
|---|---|
| **Config file** | `~/.claude/mcp.json` |
| **Schema** | `mcpServers.<name> = {command, args, env}` |
| **Install** | `memboot install --client claude-code` |
| **Verify** | Open any project with Claude Code and ask: *"Do you have any memboot tools?"* |

Claude Code reads `mcp.json` at launch. If you install while Claude Code is running, restart it.

### Claude Desktop (macOS / Windows / Linux)

| | |
|---|---|
| **Config file (macOS)** | `~/Library/Application Support/Claude/claude_desktop_config.json` |
| **Config file (Windows)** | `%APPDATA%\Claude\claude_desktop_config.json` |
| **Config file (Linux)** | `~/.config/Claude/claude_desktop_config.json` |
| **Schema** | `mcpServers.<name> = {command, args, env}` |
| **Install** | `memboot install --client claude-desktop` |
| **Verify** | Claude Desktop → Settings → Developer → MCP Servers. `memboot` should appear with "Running". |

Claude Desktop requires a full app restart (quit from the menu, not just close window) to pick up MCP config changes.

### Cursor

| | |
|---|---|
| **Config file** | `~/.cursor/mcp.json` (global) |
| **Schema** | `mcpServers.<name> = {command, args, env}` |
| **Install** | `memboot install --client cursor` |
| **Verify** | Cursor Settings → MCP → memboot should show "Available tools: 3" |

To install Memboot for a single project only, edit that project's `.cursor/mcp.json` instead (not currently automated — use the global install and `--project` to scope, or hand-edit).

### Windsurf (Codeium)

| | |
|---|---|
| **Config file** | `~/.codeium/windsurf/mcp_config.json` |
| **Schema** | `mcpServers.<name> = {command, args, env}` |
| **Install** | `memboot install --client windsurf` |
| **Verify** | Windsurf → Cascade → Tools panel. `memboot.*` tools appear in the list. |

### Zed

| | |
|---|---|
| **Config file (Linux/macOS)** | `~/.config/zed/settings.json` |
| **Config file (Windows)** | `%APPDATA%\Zed\settings.json` |
| **Schema** | `context_servers.<name> = {command, args, env}` (note: Zed uses `context_servers`, not `mcpServers`) |
| **Install** | `memboot install --client zed` |
| **Verify** | Zed's Assistant panel; memboot's tools appear as context servers. |

### OpenAI Codex CLI

| | |
|---|---|
| **Config file** | `~/.codex/config.toml` (global) |
| **Format** | TOML (every other client in this doc uses JSON) |
| **Schema** | `[mcp_servers.<name>]` tables — note `mcp_servers` with an underscore, not `mcpServers` |
| **Install** | `memboot install --client codex` |
| **Verify** | Inside Codex, run the `/mcp` TUI command — `memboot` appears in the server list. Or inspect `~/.codex/config.toml` directly. |
| **Reference** | [developers.openai.com/codex/mcp](https://developers.openai.com/codex/mcp) |

`memboot install --client codex` writes the following block into `~/.codex/config.toml` (merging with any existing content and leaving a timestamped backup):

```toml
[mcp_servers.memboot]
command = "memboot"
args = ["serve"]

[mcp_servers.memboot.env]
```

The same `~/.codex/config.toml` is shared between the Codex CLI and the Codex VS Code / IDE extension — one install covers both surfaces.

### mcphost (Ollama MCP host)

| | |
|---|---|
| **Config file** | `~/.mcphost.json` |
| **Schema** | `mcpServers.<name> = {command, args, env}` |
| **Install** | `memboot install --client mcphost` |
| **Verify** | `mcphost` lists registered servers at startup; memboot should appear. Or inspect `~/.mcphost.json` directly. |
| **Reference** | [github.com/mark3labs/mcphost](https://github.com/mark3labs/mcphost) |

mcphost also reads `~/.mcphost.yml` (YAML variant). memboot writes the JSON file. If you currently use the YAML variant, either rename it to `.mcphost.json` first, or merge memboot's entry into your YAML by hand (the `mcpServers.<name>` shape is identical).

mcphost is the recommended way to use memboot with **local Ollama models** (Qwen, Llama, Mistral, etc.) — it's a CLI that connects any Ollama model to MCP servers.

### ollmcp (Ollama MCP client)

| | |
|---|---|
| **Config file** | `~/.config/ollmcp/config.json` |
| **Schema** | `mcpServers.<name> = {command, args, env}` |
| **Install** | `memboot install --client ollmcp` |
| **Verify** | Launch `ollmcp`; memboot's tools appear in the agent's tool list. |
| **Reference** | [github.com/jonigl/mcp-client-for-ollama](https://github.com/jonigl/mcp-client-for-ollama) |

ollmcp is a terminal-based Ollama MCP client with an interactive TUI — alternative to mcphost if you prefer an interactive workflow over a one-shot CLI.

### LibreChat

| | |
|---|---|
| **Config file (default)** | `~/.config/librechat/librechat.yaml` |
| **Config file (override)** | Set `MEMBOOT_LIBRECHAT_CONFIG=/path/to/librechat.yaml` for non-standard locations (e.g. `~/LibreChat/librechat.yaml` for the standard self-host clone) |
| **Format** | YAML (the only YAML-based client memboot supports) |
| **Schema** | `mcpServers.<name>: {command, args, env}` |
| **Install** | `memboot install --client librechat` |
| **Verify** | LibreChat → Settings → MCP servers panel; memboot appears. Or grep `librechat.yaml` for `memboot:` under `mcpServers:`. |
| **Reference** | [librechat.ai/docs/features/mcp](https://www.librechat.ai/docs/features/mcp) |

Because LibreChat is deployed via Docker / git-clone (no pip install), there's no canonical filesystem path for `librechat.yaml`. memboot defaults to `~/.config/librechat/librechat.yaml`. If your file lives elsewhere, set `MEMBOOT_LIBRECHAT_CONFIG` in your shell rc:

```bash
export MEMBOOT_LIBRECHAT_CONFIG=~/LibreChat/librechat.yaml
memboot install --client librechat
```

LibreChat's `librechat.yaml` holds endpoints, models, caching, and other settings alongside `mcpServers`. memboot only touches the `mcpServers` section; everything else is preserved verbatim.

---

## Binding memboot to a specific project

By default, `memboot serve` reads the project at whatever working directory the agent launches from. To hard-bind the install to one project:

```bash
memboot install --all-detected --project ~/code/my-app
```

This bakes `--project ~/code/my-app` into the server entry's `args`, so memboot always reads from that one index regardless of which directory the agent runs in.

You can install memboot under multiple names to support multiple projects simultaneously:

```bash
memboot install --client cursor --project ~/code/app-a --server-name memboot-a
memboot install --client cursor --project ~/code/app-b --server-name memboot-b
```

Each entry runs its own `memboot serve` process with its own index.

---

## Check where memboot is installed

```bash
memboot installed
```

Reports the status of every registered client — `installed`, `absent`, or `client not detected`. Run this if you're not sure whether a prior install landed.

---

## Uninstall

```bash
memboot uninstall --client claude-code    # single client
memboot uninstall --all-detected          # every client where memboot is present
```

Uninstall removes only the memboot entry. Other MCP servers (`filesystem`, `github`, `postgres`, whatever you have configured) are preserved. As with install, a timestamped backup is written before any change.

---

## Safety and idempotency

Every write is preceded by a backup at `<config>.memboot-backup-<ISO8601>`. The last 5 backups per config are kept; older ones are pruned. Opt out with `--no-backup` (not recommended).

Installs are idempotent. Running `memboot install --client claude-code` twice produces no changes on the second call:

```
│ Claude Code  │ unchanged │ /home/you/.claude/mcp.json │ already installed … │
```

If you have an existing memboot entry that doesn't match what memboot would write (e.g., you customized it), the second install is a no-op by default:

```
│ Claude Code  │ skipped   │ /home/you/.claude/mcp.json │ existing entry differs — pass force=True to overwrite │
```

Pass `--force` to overwrite. Your prior entry is preserved in the timestamped backup.

---

## Dry run

Want to see what would happen without touching disk?

```bash
memboot install --all-detected --dry-run
```

Produces the same table with all statuses as `dry-run`, no writes, no backups.

---

## Troubleshooting

### `memboot: command not found` from the agent

Your AI tool launches the MCP server by running `memboot serve`. If `memboot` isn't on the `PATH` that the agent inherits, the server fails to start.

- **Verify from your shell first:** `which memboot` — this should print a path. If not, `memboot` is not installed into the Python environment your shell uses. Run `pip install memboot` in the environment your shell sees.
- **Your shell PATH and your GUI PATH may differ.** Claude Desktop on macOS, for example, doesn't inherit your shell PATH. Fix by installing memboot globally (`pipx install memboot`) or by using an absolute path in the config (`"command": "/full/path/to/memboot"`).
- **Rewrite the entry with an absolute path:**
  ```bash
  memboot uninstall --client claude-desktop
  # edit ~/Library/Application Support/Claude/claude_desktop_config.json
  # set "command": "/usr/local/bin/memboot" or wherever `which memboot` reported
  ```

### Config file has syntax error

If memboot refuses to install with a `ConfigParseError`, your client's config file is not valid JSON (or, for Codex, not valid TOML; for LibreChat, not valid YAML). Memboot won't touch a broken file — fix the syntax first.

- Find the config path the error mentioned.
- Run it through `python -m json.tool < path/to/config.json` — the error message will tell you the exact line and column.
- If you're not sure how it got broken, restore from the nearest `*.memboot-backup-*` file next to the config, or check your agent's own backup system (Claude Code, for example, keeps backups under `~/.claude/backups/`).

### MCP tools not appearing in Claude Code / Cursor / etc.

1. Confirm memboot is registered: `memboot installed`.
2. Restart the client fully. Claude Desktop in particular needs a menu-quit, not just a window close.
3. Check the agent's developer logs. Each client has a "view MCP logs" option buried in its settings. Look for `memboot` in the output — if you see the server failing to start, the issue is usually PATH or a missing project index.
4. Did you run `memboot init .`? An empty index will still serve tools, but the tools will return no results, which can look like "nothing is happening."

### "Pro required" messages

You shouldn't see these for `install`, `uninstall`, or `serve` — all are free as of v0.4.1. If you do, you have an older version installed. Check with `memboot --version` and upgrade: `pip install --upgrade memboot`.

### Backup files cluttering my config directory

Memboot keeps the last 5 backups per config file and auto-prunes older ones. If you want a different retention, set `MEMBOOT_BACKUPS_KEEP=N` in your shell rc or pass `--backups-keep N` explicitly.

To nuke all backups manually:

```bash
find ~/.claude ~/.cursor ~/.codeium ~/.config/zed ~/.codex ~/.config/ollmcp ~/.config/librechat ~/Library -name "*.memboot-backup-*" -delete 2>/dev/null
find ~ -maxdepth 1 -name ".mcphost.json.memboot-backup-*" -delete 2>/dev/null
```

### I edited the config by hand; memboot now says "skipped"

That's working as designed. Memboot detected that the existing memboot entry no longer matches what it would write (because you customized it). Two options:

- Keep your edits: do nothing. Memboot will leave your entry alone.
- Revert to memboot's defaults: `memboot install --client X --force` overwrites your entry. The backup preserves what you had.

---

## Manual config (for power users)

If you want to wire memboot into a tool that memboot doesn't ship an adapter for, the MCP server entry looks like this:

```json
{
  "mcpServers": {
    "memboot": {
      "command": "memboot",
      "args": ["serve"],
      "env": {}
    }
  }
}
```

To bind to a specific project:

```json
{
  "mcpServers": {
    "memboot": {
      "command": "memboot",
      "args": ["serve", "--project", "/absolute/path/to/project"],
      "env": {}
    }
  }
}
```

Drop that into whatever MCP config file your tool reads. If it's a standard `mcpServers` / `context_servers` schema, it'll work.

---

## MCP tools exposed by memboot

When an agent talks to `memboot serve`, it sees three tools:

| Tool | Purpose |
|---|---|
| `query_memory` | Semantic search over chunks + episodic memories |
| `remember` | Store a new episodic memory (decision, note, pattern, observation) |
| `get_context` | Emit a token-budgeted markdown block ready to drop into a prompt |

The agent's system prompt typically hints it should call `query_memory` before answering questions about the codebase, and `remember` when the user states a durable decision. You don't need to manage this manually — it's the agent's responsibility to use the tools.

---

## Further reading

- **Memboot CLI reference:** see `README.md` in this repo
- **MCP specification:** [modelcontextprotocol.io](https://modelcontextprotocol.io/) — the protocol every client in this document speaks
- **Client docs:**
  - Claude Code: [docs.anthropic.com/en/docs/claude-code/mcp](https://docs.anthropic.com/en/docs/claude-code/mcp)
  - Claude Desktop: [modelcontextprotocol.io/quickstart/user](https://modelcontextprotocol.io/quickstart/user)
  - Cursor: [docs.cursor.com/context/model-context-protocol](https://docs.cursor.com/context/model-context-protocol)
  - Windsurf: [docs.codeium.com/windsurf/mcp](https://docs.codeium.com/windsurf/mcp)
  - Zed: [zed.dev/docs/assistant/context-servers](https://zed.dev/docs/assistant/context-servers)
  - OpenAI Codex CLI: [developers.openai.com/codex/mcp](https://developers.openai.com/codex/mcp)

Issues with the install flow? Open one at [github.com/AreteDriver/memboot/issues](https://github.com/AreteDriver/memboot/issues).
