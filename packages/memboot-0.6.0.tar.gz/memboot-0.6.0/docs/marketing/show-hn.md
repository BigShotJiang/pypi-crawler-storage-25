# Show HN Post Draft — memboot

**Target launch:** ~30 days after anchormd launch (space out same-account submissions).

**Title:** Show HN: Memboot – Offline-first persistent memory for LLMs (SQLite + TF-IDF)

**URL:** https://github.com/AreteDriver/memboot

**Text field:** Leave blank. Submit with URL only. Post body as first comment.

---

**First comment (paste immediately after submit):**

Author here. Memboot is a persistent memory layer for LLM tooling that doesn't require a managed API, an HTTP server, or even a network connection. It's SQLite + TF-IDF on your local disk — `~/.memboot/{project-hash}.db`, one file per project. Works on an airplane, works in CI, works without exposing your codebase to a third party.

The shape:

```
$ memboot init .
  Indexed 142 files, 1,847 chunks

$ memboot query "authentication flow"
  src/auth/jwt.py:create_token     0.89  "Creates signed JWT with user claims..."
  src/auth/middleware.py:verify    0.84  "Extracts and validates bearer token..."

$ memboot remember "Use JWT for API auth, sessions for web" --type decision
  Stored decision #14

$ memboot context "auth" --max-tokens 4000
  # formatted markdown block ready to paste into a prompt
```

What's in the box that I think is interesting:

- **AST-aware chunking for Python** (function/class boundaries, not sliding windows). Markdown splits on headings; YAML/JSON split at key level; everything else falls back to windowed text.
- **TF-IDF by default, not managed embeddings.** Unpopular choice but deliberate — TF-IDF is excellent for exact recall against your own code (variable names, function names, error strings) and requires zero external deps. Sentence-transformers available as an opt-in extra for semantic search.
- **Per-project SQLite databases** with numpy float32 BLOB serialization for the embeddings. One file, rsync-able, no migration story.
- **Episodic memory alongside code chunks** — decisions, patterns, observations stored with the same embedding index, so "why did we pick X" is recall-able the same way function bodies are.
- **One-command install across five agents:** `memboot install --all-detected` writes the MCP entry into Claude Code, Claude Desktop, Cursor, Windsurf, and Zed configs simultaneously. Idempotent, with automatic timestamped backups.

How it differs from neighbors:

| | Offline | No API keys | No server | CLI-native |
|---|:---:|:---:|:---:|:---:|
| **memboot** | ✓ | ✓ | ✓ | ✓ |
| Mem0 | — | — | — | — |
| Memori | — | — | — | — |
| OpenMemory | — | — | — | partial |

Install:

```
pip install memboot
pip install memboot[embed]   # add sentence-transformers
pip install memboot[mcp]     # add MCP server
pip install memboot[pdf]     # add PDF ingestion
```

MIT, ~380 tests, 91% coverage. Free tier covers everything single-user: indexing, query, episodic memory, the MCP server, and the one-command install across all five major agents. Pro ($8/mo) is reserved for PDF/web ingestion and auto-reindex watching. Offline-validated license keys (HMAC checksum, no phone-home).

Happy to talk about the TF-IDF-vs-embeddings tradeoff, why I went with SQLite over a real vector DB for single-user workloads, or the AST chunker (which was the most satisfying part to build).

Source: https://github.com/AreteDriver/memboot
PyPI: https://pypi.org/project/memboot/

---

## Notes to self (don't paste)

**Why this post works on HN:**
- Privacy-first + offline-first hit two HN hot buttons simultaneously
- The comparison table is concrete and falsifiable — invites Mem0/Letta/etc. maintainers into the thread, which drives engagement
- AST-aware chunking is a real technical detail, not marketing fluff
- TF-IDF default is contrarian enough to generate debate (good for front page)
- MIT + 92% coverage are credibility signals, not flex

**Expected objections + have-ready answers:**

1. **"TF-IDF? Why not real embeddings?"**
   → Fine for exact recall against code (names, identifiers, error strings). Semantic search is opt-in extra. Zero external deps matters for CI + airplane + privacy. Real embeddings add weight; 90% of queries against a codebase don't need them.

2. **"SQLite won't scale."**
   → It's intentionally single-user, single-machine, single-project. If you need distributed, use Pinecone. memboot is for the local-dev use case and owns that niche.

3. **"How is this different from [Mem0 / Letta / OpenMemory / Memori]?"**
   → Comparison table is the answer. None of them are offline. Most require an API key or managed service. The architectural choice matters — memboot is a *primitive*, not a framework.

4. **"What about accuracy vs semantic search?"**
   → Bench on your own data. For code recall (variable names, function names, error strings, imports), TF-IDF is often higher precision than embeddings. For fuzzy concept search, use the `[embed]` extra. Honest about tradeoffs.

5. **"Why not just use `grep`?"**
   → Grep doesn't chunk by AST boundaries. Grep doesn't score. Grep doesn't keep episodic memories alongside code. Grep doesn't produce token-budgeted context blocks. Grep is a line search; memboot is a memory system.

6. **"Pricing feels weird for a local tool."**
   → Free tier is fully useful (every core command). Pro gates only `memboot serve` and advanced ingest paths. Reasonable line: CLI memory is free, persistent MCP integration is a product. HN will either respect this or won't; don't get defensive.

**Launch day checklist:**
- [ ] PyPI latest version matches what README says
- [ ] CI badges green on GitHub
- [ ] No open "does not install" issues
- [ ] Run `pip install memboot && memboot --version` in a fresh venv — make sure the golden-path install works
- [ ] README top paragraph matches the HN post's one-line pitch (so visitors arriving from HN see consistent messaging)
- [ ] Be online 2-3 hours after submit

**Timing:** At least 4 weeks after the anchormd HN post. Same account. Different product. HN has memory; pacing matters.

**Alt titles if main doesn't land:**
- "Show HN: Memboot – Local persistent memory for LLMs, no cloud"
- "Show HN: Offline LLM memory with SQLite and TF-IDF"
- "Show HN: A CLI for persistent LLM memory that runs fully offline"
