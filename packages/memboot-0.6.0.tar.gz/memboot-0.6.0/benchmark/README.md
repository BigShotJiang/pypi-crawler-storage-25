# memboot-benchmark

A reproducible retrieval benchmark for LLM memory tools. The goal is to make competitive claims falsifiable. If memboot is better than Mem0 / Letta / OpenMemory for developer-use-case retrieval, the numbers should show it. If it isn't, we should know.

**Status:** design / scaffolding. Not yet implemented.

---

## Why this exists

The LLM memory category is crowded. Every tool claims to have "state-of-the-art" retrieval. None of them publish numbers against the same queries on the same corpora. This benchmark proposes a shared harness — anyone can submit an adapter for their tool, run it against the same fixtures, and see where they stand.

This is the strategic move: **turn competitive positioning into a measurable engineering problem, published on memboot's terms**. When the comparison is specific, offline-first retrieval on developer codebases, memboot is in a strong position to win on most metrics. Publishing the harness forces competitors to engage on our question, not theirs.

---

## Methodology

### Corpora (starting set)

Three codebases, chosen for size variety and genre spread:

| Repo | Language | Size | Why |
|---|---|---|---|
| `pallets/flask` | Python | ~30k LOC | Mature web framework, idiomatic Python, heavy comment/docstring density |
| `facebook/react` | JavaScript | ~150k LOC | Large, multi-module, JS ecosystem |
| `rust-lang/rust-analyzer` | Rust | ~500k LOC | Complex, type-heavy, stress test for scale |

Fixtures ship as git submodules pinned to specific commits. Reproducibility depends on the corpus being byte-identical across runs.

### Queries

100 queries per codebase, hand-labeled. Each query has 1-5 "correct" chunks (file path + line range) chosen by a human reviewer with the codebase open. Stored as YAML:

```yaml
- id: flask-001
  query: "request context initialization"
  expected:
    - path: src/flask/ctx.py
      lines: [100, 160]
    - path: src/flask/app.py
      lines: [1400, 1450]
  type: concept
  difficulty: medium
```

Query types (balanced distribution):

- **Exact identifier** — function name, class name, variable name (~25%)
- **Concept** — "error handling in middleware", "how requests are routed" (~25%)
- **Domain term** — "JWT", "session", "middleware", "CORS" (~20%)
- **Negation** — "request parsing that isn't JSON" (~10%)
- **Multi-hop** — "tests for the function that validates user input" (~10%)
- **Ambient** — "the main loop", "the entry point" (~10%)

### Metrics

Core retrieval quality:
- **Recall@K** for K ∈ {1, 5, 10} — fraction of queries where at least one relevant chunk is in top-K
- **MRR** — mean reciprocal rank of the first relevant result
- **nDCG@10** — discounted cumulative gain, handles multi-relevance cases

Operational quality:
- **Index time** — wall-clock seconds to build the index from scratch
- **Query latency** — p50 and p95, measured over the full 100-query set
- **Storage size** — on-disk bytes after indexing
- **External dependencies** — count of network calls, API keys required, server processes spawned (0 is memboot's target; non-zero is where competitors lose)

Reported as a single JSON blob per tool per run, committed to `results/<date>-<tool>.json`. Human-readable summary auto-generated to `results/latest.md`.

---

## Adapter contract

Every tool implements a common Python adapter:

```python
from benchmark.adapters.base import ToolAdapter
from pathlib import Path

class MemoryTool(ToolAdapter):
    name: str = "tool-name"

    def setup(self, corpus_path: Path, workdir: Path) -> None:
        """One-time setup: install, configure, authenticate. Called once before any queries."""

    def index(self, corpus_path: Path) -> IndexReport:
        """Build the index over the corpus. Return timing + size stats."""

    def query(self, text: str, k: int = 10) -> list[QueryHit]:
        """Execute one query, return ranked results."""

    def teardown(self) -> None:
        """Clean up any external state (containers, accounts, temp files)."""
```

`QueryHit` is a dataclass: `path: str, line_start: int, line_end: int, score: float, snippet: str`.

The harness (`benchmark/runner.py`) handles:
- Calling setup/index/query/teardown in the right order
- Timing each phase
- Scoring results against ground truth YAML
- Emitting per-tool results JSON
- Generating the human-readable summary

Adapters planned for initial release:

- `memboot.py` — obvious (written first to validate the harness)
- `memboot-embed.py` — memboot with the `[embed]` extra (sentence-transformers hybrid retrieval)
- `mem0.py` — Mem0 cloud SDK (requires API key, provided via CI secrets)
- `letta.py` — Letta self-hosted (runs in Docker container; container startup included in index-time metric)
- `openmemory.py` — OpenMemory self-hosted
- `baseline-grep.py` — ripgrep-based retrieval as a floor: shows what naïve string search scores

`baseline-grep` is important: it's the honest floor. Any tool that doesn't clearly beat ripgrep on concept queries has failed.

---

## Ship sequence

**Phase 1 — Memboot vs. ripgrep on Flask (1 week of work)**
- Build the harness runner
- Ship the memboot and ripgrep adapters
- Hand-label 100 Flask queries
- Publish first results
- Goal: prove the harness works end-to-end and memboot beats ripgrep on concept queries

**Phase 2 — Add a cloud competitor (1-2 weeks)**
- Add Mem0 adapter
- Run against Flask
- Publish the delta
- This is the HN-worthy moment: first apples-to-apples comparison in the category

**Phase 3 — Expand corpus + competitors (ongoing)**
- Add React codebase + queries
- Add Letta, OpenMemory adapters
- Nightly CI runs, leaderboard auto-updates
- Invite PRs from tool authors to update their own adapters

**Phase 4 — Make it a standard (aspirational)**
- Submit the methodology to a relevant venue (workshop paper, conference demo)
- Reach out to tool authors for endorsement / collaboration
- Eventually: decouple the benchmark from memboot's repo, make it its own project with neutral governance

---

## Publishing

Results live in `benchmark/results/` as JSON files, one per tool per run. A GitHub Pages site under `aretedriver.github.io/memboot-benchmark/` (or similar) renders the leaderboard with:
- Tool × metric matrix
- Query-type breakdowns
- Time-series graphs as tools improve
- Per-query drill-down (which tools got which query wrong)

No unilateral moderation. Any tool with a passing adapter + non-zero Recall@10 on all three corpora gets a leaderboard row. If someone's tool scores poorly, that's useful public information for them; if they think the harness is unfair, they can submit a PR to fix it.

---

## Risks and mitigations

**Risk: memboot is worse than cloud tools on semantic queries.**
Mitigation: this is possible and okay. The harness separates metrics so "worse on concept recall, better on latency + privacy + exact-ID recall" is a legitimate story. The numbers should tell the truth.

**Risk: ground-truth labels are biased toward memboot's strengths.**
Mitigation: have at least one non-memboot-author review the query set before publication. Accept PRs that add queries regardless of who authored them.

**Risk: competitors refuse to engage.**
Mitigation: run their adapters ourselves based on their published SDKs. Publish results regardless. If they object, they can submit a PR with a better adapter.

**Risk: corpus fixtures go stale as upstream repos change.**
Mitigation: pin submodules to specific commits. A corpus refresh is a deliberate act, versioned.

**Risk: this becomes a full-time project.**
Mitigation: the harness is the MVP. After Phase 2, only accept PRs that add tools or queries. Don't chase the infinite "also benchmark against…" list.

---

## Scope budget (initial phase)

- **LOC:** ~600 harness + scoring, ~100 per adapter
- **Time:** 1 week of focused work for Phase 1, 1-2 weeks for Phase 2
- **Dependencies:** pytest (harness as a test-like runner), PyYAML (queries), requests (for cloud adapters)
- **Hosting:** GitHub Pages for the leaderboard, CI for nightly runs

---

## File layout (proposed)

```
benchmark/
├── README.md                    # this file
├── runner.py                    # orchestrator
├── scoring.py                   # metrics calculation
├── corpora/                     # git submodules for fixture repos
│   ├── flask/
│   ├── react/
│   └── rust-analyzer/
├── queries/                     # hand-labeled query sets
│   ├── flask.yaml
│   ├── react.yaml
│   └── rust-analyzer.yaml
├── adapters/
│   ├── base.py                  # ToolAdapter ABC, dataclasses
│   ├── memboot.py
│   ├── memboot_embed.py
│   ├── mem0.py
│   ├── letta.py
│   ├── openmemory.py
│   └── baseline_grep.py
├── results/
│   └── 2026-05-XX-memboot.json  # per-run output
└── site/                        # GitHub Pages leaderboard (Hugo or plain HTML)
```

---

## Open questions

- Should the benchmark repo be a subdirectory of memboot or its own top-level repo? Lean toward its own repo once Phase 2 ships; subdirectory during Phase 1 for speed.
- Licensing: MIT for the harness, but the query-label YAML is subjective curation — clarify that adapter authors can propose label changes via PR but the harness author has final merge authority during Phase 1.
- How to handle tools that require a paid account? Document that CI runs require the account-holder to provide secrets; individual reproduction requires the user to provide their own key. This is a one-time friction that only affects cloud tools.
