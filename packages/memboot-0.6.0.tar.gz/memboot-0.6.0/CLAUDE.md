# memboot

## Project Overview

Zero-infrastructure persistent memory for any LLM. SQLite + TF-IDF vector search with no external services.

- **Version**: 0.6.0
- **Python**: >=3.11
- **Package layout**: `src/memboot/` (setuptools, `src` layout)
- **Tests**: 304 tests, 92% coverage (fail_under=90)
- **License**: MIT
- **Distribution**: PyPI (`memboot`)

---

## Architecture

```
memboot/
├── src/memboot/
│   ├── __init__.py          # Version
│   ├── __main__.py          # Entry point
│   ├── cli.py               # Typer CLI
│   ├── models.py            # Pydantic models (Chunk, Memory, SearchResult, ProjectInfo, MembootConfig)
│   ├── exceptions.py        # MembootError hierarchy (7 subclasses)
│   ├── store.py             # SQLite WAL store (chunks/memories/meta, numpy BLOB serialization)
│   ├── embedder.py          # TfidfEmbedder (numpy-only) + optional SentenceTransformerEmbedder
│   ├── chunker.py           # AST-based Python chunking + markdown/yaml/json/window strategies
│   ├── indexer.py           # Full pipeline: discover → chunk → embed → store
│   ├── query.py             # Cosine similarity search over chunks + memories
│   ├── memory.py            # CRUD for persistent memories
│   ├── context.py           # Formatted markdown context builder with token budget
│   ├── licensing.py         # MMBT license keys, HMAC checksum, Free/Pro tiers
│   ├── gates.py             # @require_pro decorator
│   ├── watcher.py           # Filesystem watcher (watchdog, debounced auto-reindex)
│   ├── mcp_server.py        # MCP server (3 tools: query_memory, remember, get_context)
│   ├── clients/             # Per-client MCP install adapters (9 clients)
│   │   ├── base.py          # Shared adapter interface + JSON config helpers
│   │   ├── claude_code.py   # ~/.claude/mcp.json (JSON, mcpServers)
│   │   ├── claude_desktop.py # Claude Desktop config (JSON, mcpServers)
│   │   ├── cursor.py        # ~/.cursor/mcp.json (JSON, mcpServers)
│   │   ├── windsurf.py      # ~/.codeium/windsurf/mcp_config.json (JSON, mcpServers)
│   │   ├── zed.py           # ~/.config/zed/settings.json (JSON, context_servers)
│   │   ├── codex.py         # ~/.codex/config.toml (TOML, [mcp_servers.<name>]) — first TOML adapter
│   │   ├── mcphost.py       # ~/.mcphost.json (JSON, mcpServers) — Ollama MCP host
│   │   ├── ollmcp.py        # ~/.config/ollmcp/config.json (JSON, mcpServers) — Ollama MCP client
│   │   └── librechat.py     # librechat.yaml (YAML, mcpServers) — first YAML adapter, env-overridable path
│   └── ingest/
│       ├── files.py         # File ingestion (chunk + embed + store)
│       ├── pdf.py           # PDF ingestion (pdfplumber, optional)
│       └── web.py           # Web ingestion (trafilatura, optional)
├── tests/                   # pytest suite
└── pyproject.toml
```

### Key Design

- **Zero infrastructure**: no server, no vector DB — SQLite + numpy-only TF-IDF
- **Per-project DB**: `~/.memboot/{sha256(project_path)[:12]}.db` — one DB per project, auto-created on `init`
- **Lazy imports**: CLI commands import at function level. Optional deps (mcp, pdfplumber, trafilatura, sentence-transformers) use try/except ImportError
- **Numpy float32 BLOB serialization** for embedding storage
- **TF-IDF state** saved to store meta as JSON, restored on query/ingest
- **Licensing**: MMBT prefix, `memboot-v1` salt, SHA256 checksum. Key via `MEMBOOT_LICENSE` env var or `~/.memboot-license` file
- **Client adapters**: 9 MCP clients supported (Claude Code, Claude Desktop, Cursor, Windsurf, Zed, OpenAI Codex CLI, mcphost, ollmcp, LibreChat). Six use JSON configs; Codex is TOML; LibreChat is YAML. The mcphost adapter overrides `is_installed` because its config sits at `~/.mcphost.json` (parent is `$HOME`, which always exists) — it falls back to detecting a `.mcphost.yml` sibling or the binary on PATH. The LibreChat adapter honors `MEMBOOT_LIBRECHAT_CONFIG` for users whose `librechat.yaml` lives outside the default `~/.config/librechat/` location. New adapters should extend `clients/base.py`; TOML adapters use `tomllib`+`tomli_w`, YAML adapters use `pyyaml` (`safe_load` / `safe_dump`)

---

## Common Commands

### Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

### CLI Usage

```bash
memboot --version
memboot init <project-path>
memboot query "search terms" --project <path>
memboot remember "important fact" --type note --project <path>
memboot context "query" --project <path>
memboot status
memboot reset --project <path> --yes
memboot ingest <file-or-url> --project <path>
memboot serve                    # Pro only — MCP server
```

### Testing

```bash
# Full suite (coverage enforced at 90% via pyproject)
pytest tests/ -v

# Single module
pytest tests/test_store.py -v
```

### Lint + Format

```bash
# Always run BOTH
ruff check src/ tests/
ruff format src/ tests/

# CI verification
ruff check src/ tests/ && ruff format --check src/ tests/
```

Rules enabled: `E, F, W, I, N, UP, B, A, SIM`. `B008` ignored for `cli.py` (typer defaults).

### Build + Publish

```bash
# Build wheel + sdist
python3 -m build

# Publish to PyPI (CI via OIDC trusted publisher; manual fallback: twine upload dist/*)
```

---

## Coding Standards

- **Python**: 3.11+, type hints throughout (mypy strict)
- **`from __future__ import annotations`** in test files (complex forward refs)
- **Models**: Pydantic v2 with `StrEnum` for enums
- **Errors**: `MembootError` hierarchy — catch specific subclasses, never bare `except`
- **Path handling**: `pathlib.Path` everywhere
- **Imports**: absolute, stdlib → third-party → local
- **Testing patch targets**: patch at **source** modules (`memboot.indexer.index_project`), not `memboot.cli.xxx` — CLI uses lazy imports
- **SQLite**: WAL mode, `check_same_thread=False` when used across threads
- **Embeddings**: always serialize as numpy `float32` BLOB

---

## Anti-Patterns

- **Patching the wrong module** — CLI commands do lazy imports; patch the real source (`memboot.indexer.index_project`), not `memboot.cli.index_project`
  ```python
  # BAD — patches a local binding CLI never reads
  @patch("memboot.cli.index_project")
  # GOOD — patches the source the CLI calls lazily
  @patch("memboot.indexer.index_project")
  ```
- **Using `os.path`** — `pathlib.Path` everywhere
- **Bare `except:`** — catch specific exceptions from `exceptions.py`
- **Embedding dimension mismatch** — always re-train TF-IDF on full corpus after schema changes; don't append embeddings of different shape
- **Forgetting optional-dep guards** — `import pdfplumber` must be in try/except; code must work without it
- **Storing plaintext license keys** — SHA-256 hash only
- **Committing `.memboot/` DBs** — each DB is per-machine; must stay gitignored

---

## Dependencies

### Core (required)
- `typer` — CLI framework
- `rich` — terminal output
- `pydantic>=2` — models
- `numpy` — TF-IDF and BLOB serialization
- `watchdog` — filesystem events (auto-reindex)

### Optional Extras
```bash
pip install memboot[mcp]      # MCP server support
pip install memboot[pdf]      # PDF ingestion (pdfplumber)
pip install memboot[web]      # Web ingestion (trafilatura)
pip install memboot[embed]    # sentence-transformers embeddings
```

### Dev
- `pytest`, `pytest-cov`
- `ruff`, `mypy`

---

## Git Conventions

- **Commit style**: conventional commits (`feat:`, `fix:`, `docs:`, `chore:`, `test:`, `refactor:`)
- **Branch**: work on `main` for small changes; feature branches for multi-commit work
- **Release**: bump `version` in both `pyproject.toml` and `src/memboot/__init__.py` → tag `v{version}` → CI publishes via OIDC trusted publisher
- **No secrets**: gitleaks in CI; `.memboot/` and `.venv/` stay gitignored

---

## Domain Context

### What memboot Is
A drop-in persistent memory layer for any LLM tooling. Point it at a project directory, let it chunk + embed, then query it back as context. No Pinecone, no Chroma, no external service — SQLite + numpy is enough for most single-user workflows.

### What It's NOT
- Not a distributed vector DB (one user, one machine, one DB file per project)
- Not a RAG framework (that's the consumer's job; memboot is the storage + retrieval primitive)
- Not a fine-tuning target (embeddings are TF-IDF by default — fine for exact recall, not semantic generalization)
- Not an MCP-only tool — MCP is one surface; CLI and library use are equally supported

### Free vs Pro
- **Free**: all core commands (init, query, remember, context, status, reset, ingest)
- **Pro**: `memboot serve` (MCP server), advanced ingestion formats, multi-project dashboards
- **License format**: `MMBT-XXXX-XXXX-XXXX`
- **Validation**: offline HMAC checksum; no network required

### Use Cases
- Claude Code session memory across runs
- Personal knowledge base over local notes / PDFs / web pages
- Per-project "remember this" stash for code agents

---

## Security

- Per-project DBs live in `~/.memboot/` — verify this dir is `0o700` on sensitive systems
- License key storage: SHA-256 hash only, never plaintext
- Web ingestion (trafilatura) respects robots.txt by default — do not override without user intent
- File ingestion does NOT follow symlinks out of the project dir — prevents accidental exfiltration via watcher
