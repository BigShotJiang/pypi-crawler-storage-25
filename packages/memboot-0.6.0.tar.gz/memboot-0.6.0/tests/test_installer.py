"""Tests for the top-level install/uninstall orchestration."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from memboot.clients import REGISTRY
from memboot.clients.base import build_server_entry
from memboot.installer import install, installed_status, uninstall

# `fake_home` is an autouse fixture in tests/conftest.py — every test here is
# already isolated from the real filesystem.


def _claude_code_config(home: Path) -> Path:
    return home / ".claude" / "mcp.json"


def _cursor_config(home: Path) -> Path:
    return home / ".cursor" / "mcp.json"


# ---------- selector validation ----------


def test_install_requires_exactly_one_selector() -> None:
    with pytest.raises(ValueError, match="exactly one of"):
        install()
    with pytest.raises(ValueError, match="exactly one of"):
        install(clients=["claude-code"], all_detected=True)
    with pytest.raises(ValueError, match="exactly one of"):
        install(all_detected=True, all_known=True)


def test_install_single_unknown_client_surfaces_error(fake_home: Path) -> None:
    with pytest.raises(KeyError, match="Unknown client"):
        install(clients=["not-a-real-client"])


# ---------- single-client install ----------


def test_install_single_client_writes_entry(fake_home: Path) -> None:
    plan = install(clients=["claude-code"])

    assert len(plan.results) == 1
    result = plan.results[0]
    assert result.status == "installed"
    assert result.client == "claude-code"

    written = json.loads(_claude_code_config(fake_home).read_text())
    assert written["mcpServers"]["memboot"] == build_server_entry()


def test_install_is_idempotent_second_run_is_unchanged(fake_home: Path) -> None:
    install(clients=["claude-code"])
    plan = install(clients=["claude-code"])
    assert plan.results[0].status == "unchanged"


def test_install_preserves_other_mcp_servers(fake_home: Path) -> None:
    cfg = _claude_code_config(fake_home)
    cfg.parent.mkdir(parents=True)
    cfg.write_text(json.dumps({"mcpServers": {"other": {"command": "other"}}}))

    install(clients=["claude-code"])

    written = json.loads(cfg.read_text())
    assert written["mcpServers"]["other"] == {"command": "other"}
    assert "memboot" in written["mcpServers"]


def test_install_with_different_entry_skipped_without_force(fake_home: Path) -> None:
    cfg = _claude_code_config(fake_home)
    cfg.parent.mkdir(parents=True)
    cfg.write_text(
        json.dumps(
            {"mcpServers": {"memboot": {"command": "memboot", "args": ["serve", "--old-flag"]}}}
        )
    )

    plan = install(clients=["claude-code"])
    assert plan.results[0].status == "skipped"

    # File on disk is unchanged.
    written = json.loads(cfg.read_text())
    assert written["mcpServers"]["memboot"]["args"] == ["serve", "--old-flag"]


def test_install_with_force_overwrites_different_entry(fake_home: Path) -> None:
    cfg = _claude_code_config(fake_home)
    cfg.parent.mkdir(parents=True)
    cfg.write_text(
        json.dumps(
            {"mcpServers": {"memboot": {"command": "memboot", "args": ["serve", "--old-flag"]}}}
        )
    )

    plan = install(clients=["claude-code"], force=True)
    assert plan.results[0].status == "updated"

    written = json.loads(cfg.read_text())
    assert written["mcpServers"]["memboot"] == build_server_entry()


def test_install_with_project_bakes_path_into_args(fake_home: Path, tmp_path: Path) -> None:
    project = tmp_path / "myproj"
    project.mkdir()

    install(clients=["claude-code"], project=project)

    written = json.loads(_claude_code_config(fake_home).read_text())
    assert written["mcpServers"]["memboot"]["args"] == [
        "serve",
        "--project",
        str(project),
    ]


def test_install_dry_run_writes_nothing(fake_home: Path) -> None:
    plan = install(clients=["claude-code"], dry_run=True)
    assert plan.results[0].status == "dry-run"
    assert not _claude_code_config(fake_home).exists()


def test_install_creates_backup_when_file_exists(fake_home: Path) -> None:
    cfg = _claude_code_config(fake_home)
    cfg.parent.mkdir(parents=True)
    cfg.write_text('{"original": true}')

    plan = install(clients=["claude-code"], force=True)
    result = plan.results[0]

    assert result.backup_path is not None
    assert result.backup_path.exists()
    assert json.loads(result.backup_path.read_text()) == {"original": True}


def test_install_no_backup_when_requested(fake_home: Path) -> None:
    cfg = _claude_code_config(fake_home)
    cfg.parent.mkdir(parents=True)
    cfg.write_text('{"original": true}')

    plan = install(clients=["claude-code"], force=True, backup=False)
    assert plan.results[0].backup_path is None


# ---------- all-detected / all-known ----------


def test_install_all_detected_skips_clients_not_present(fake_home: Path) -> None:
    # Create only the .claude directory; everything else is absent.
    (fake_home / ".claude").mkdir()

    plan = install(all_detected=True)

    installed = [r for r in plan.results if r.status == "installed"]
    assert {r.client for r in installed} == {"claude-code"}

    assert _claude_code_config(fake_home).exists()
    assert not _cursor_config(fake_home).exists()


def test_install_all_known_writes_to_every_client(fake_home: Path) -> None:
    plan = install(all_known=True)

    installed_results = [r for r in plan.results if r.status == "installed"]
    assert len(installed_results) == len(REGISTRY)

    assert _claude_code_config(fake_home).exists()
    assert _cursor_config(fake_home).exists()
    assert (fake_home / ".codex" / "config.toml").exists()


# ---------- uninstall ----------


def test_uninstall_removes_entry(fake_home: Path) -> None:
    install(clients=["claude-code"])
    plan = uninstall(clients=["claude-code"])

    assert plan.results[0].status == "removed"
    written = json.loads(_claude_code_config(fake_home).read_text())
    assert "memboot" not in written["mcpServers"]


def test_uninstall_preserves_other_servers(fake_home: Path) -> None:
    cfg = _claude_code_config(fake_home)
    cfg.parent.mkdir(parents=True)
    cfg.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "memboot": build_server_entry(),
                    "other": {"command": "other"},
                }
            }
        )
    )

    uninstall(clients=["claude-code"])

    written = json.loads(cfg.read_text())
    assert "memboot" not in written["mcpServers"]
    assert written["mcpServers"]["other"] == {"command": "other"}


def test_uninstall_absent_is_noop(fake_home: Path) -> None:
    plan = uninstall(clients=["claude-code"])
    assert plan.results[0].status == "absent"


def test_uninstall_dry_run_writes_nothing(fake_home: Path) -> None:
    install(clients=["claude-code"])
    before = _claude_code_config(fake_home).read_text()

    plan = uninstall(clients=["claude-code"], dry_run=True)
    assert plan.results[0].status == "dry-run"

    after = _claude_code_config(fake_home).read_text()
    assert before == after


# ---------- installed_status ----------


def test_installed_status_reports_every_client(fake_home: Path) -> None:
    install(clients=["claude-code"])

    statuses = installed_status()
    by_name = {r.client: r for r in statuses}

    assert by_name["claude-code"].status == "installed"
    assert by_name["cursor"].status == "absent"
    assert by_name["codex"].status == "absent"
    # Every registered client appears in the status report.
    assert len(statuses) == len(REGISTRY)


# ---------- round-trip ----------


# ---------- regression: every adapter must resolve paths under the fake home ----------


def test_every_adapter_routes_through_patched_home(fake_home: Path) -> None:
    """Regression guard against the 2026-04-18 leak incident.

    The original bug: client modules imported `_home` by name at the top of
    each file (`from memboot.clients.base import _home`), which created a
    module-local binding that `monkeypatch.setattr("memboot.clients.base._home", ...)`
    could not reach. Tests wrote to real user configs under ~/.

    Fix: adapters now call `base._home()` dynamically. This test proves every
    adapter honors the patch — installing into all six clients must land
    every config under `fake_home`, never the real user home.

    If someone reintroduces the name-import pattern on any adapter, this
    test will fail because that adapter's config_path will escape fake_home.
    """
    plan = install(all_known=True)

    assert len(plan.results) == len(REGISTRY), "must exercise every registered adapter"

    for result in plan.results:
        # Every resolved config path must live under the isolated tmp home,
        # including the Windows %APPDATA% branches (which we pointed inside
        # fake_home/AppData via the autouse fixture).
        assert fake_home in result.config_path.parents, (
            f"{result.client}: config_path {result.config_path} escaped "
            f"the fake_home sandbox {fake_home}. This indicates a name-import "
            f"of _home in the adapter module — refactor to call base._home() "
            f"dynamically."
        )
        assert result.config_path.exists(), (
            f"{result.client}: install reported success but config was not written"
        )


def test_install_then_uninstall_preserves_untouched_config_keys(fake_home: Path) -> None:
    cfg = _claude_code_config(fake_home)
    cfg.parent.mkdir(parents=True)
    original = {
        "mcpServers": {"other": {"command": "other", "args": []}},
        "unrelated": "preserved",
    }
    cfg.write_text(json.dumps(original))

    install(clients=["claude-code"])
    uninstall(clients=["claude-code"])

    written = json.loads(cfg.read_text())
    assert written["unrelated"] == "preserved"
    assert written["mcpServers"]["other"] == {"command": "other", "args": []}
    assert "memboot" not in written["mcpServers"]
