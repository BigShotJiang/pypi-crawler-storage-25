"""Tests for client adapters and shared MCP behavior."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from memboot.clients import (
    REGISTRY,
    ClaudeCodeAdapter,
    ClaudeDesktopAdapter,
    CursorAdapter,
    MCPHostAdapter,
    OllmcpAdapter,
    WindsurfAdapter,
    ZedAdapter,
    all_adapters,
    get_adapter,
)

# CodexAdapter (TOML) and LibreChatAdapter (YAML) have dedicated test suites
# (tests/test_codex.py and tests/test_librechat.py respectively) because they
# use non-JSON config formats. They are not included in the parametrized
# STANDARD_CLIENTS matrix below.
from memboot.clients.base import (
    build_server_entry,
    entries_equivalent,
)
from memboot.exceptions import ConfigParseError

# `fake_home` is an autouse fixture in tests/conftest.py — every test here is
# already isolated from the real filesystem. Tests that want the tmp path
# declare `fake_home: Path` as a parameter.


STANDARD_CLIENTS = [
    ClaudeCodeAdapter,
    ClaudeDesktopAdapter,
    CursorAdapter,
    MCPHostAdapter,
    OllmcpAdapter,
    WindsurfAdapter,
]


# ---------- registry ----------


def test_registry_contains_all_known_clients() -> None:
    assert set(REGISTRY) == {
        "claude-code",
        "claude-desktop",
        "codex",
        "cursor",
        "librechat",
        "mcphost",
        "ollmcp",
        "windsurf",
        "zed",
    }


def test_all_adapters_instantiates_each_once() -> None:
    instances = all_adapters()
    assert len(instances) == 9
    assert {a.name for a in instances} == set(REGISTRY)


def test_get_adapter_by_name_returns_instance() -> None:
    adapter = get_adapter("claude-code")
    assert isinstance(adapter, ClaudeCodeAdapter)


def test_get_adapter_unknown_name_raises_with_hint() -> None:
    with pytest.raises(KeyError, match="Unknown client 'nope'"):
        get_adapter("nope")


# ---------- build_server_entry ----------


def test_build_server_entry_default() -> None:
    entry = build_server_entry()
    assert entry == {"command": "memboot", "args": ["serve"], "env": {}}


def test_build_server_entry_with_project(tmp_path: Path) -> None:
    entry = build_server_entry(project=tmp_path)
    assert entry["args"] == ["serve", "--project", str(tmp_path)]


def test_build_server_entry_with_extra_args() -> None:
    entry = build_server_entry(extra_args=["--verbose"])
    assert entry["args"] == ["serve", "--verbose"]


# ---------- entries_equivalent ----------


def test_entries_equivalent_identical() -> None:
    a = {"command": "memboot", "args": ["serve"], "env": {}}
    b = {"command": "memboot", "args": ["serve"], "env": {}}
    assert entries_equivalent(a, b)


def test_entries_equivalent_different_args() -> None:
    a = {"command": "memboot", "args": ["serve"], "env": {}}
    b = {"command": "memboot", "args": ["serve", "--verbose"], "env": {}}
    assert not entries_equivalent(a, b)


def test_entries_equivalent_different_keys() -> None:
    a = {"command": "memboot", "args": ["serve"], "env": {}}
    b = {"command": "memboot", "args": ["serve"]}
    assert not entries_equivalent(a, b)


# ---------- standard clients: config paths ----------


def test_claude_code_config_path(fake_home: Path) -> None:
    adapter = ClaudeCodeAdapter()
    assert adapter.config_path() == fake_home / ".claude" / "mcp.json"


def test_cursor_config_path(fake_home: Path) -> None:
    assert CursorAdapter().config_path() == fake_home / ".cursor" / "mcp.json"


def test_windsurf_config_path(fake_home: Path) -> None:
    assert (
        WindsurfAdapter().config_path() == fake_home / ".codeium" / "windsurf" / "mcp_config.json"
    )


def test_zed_config_path_posix(fake_home: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("memboot.clients.base._is_windows", lambda: False)
    assert ZedAdapter().config_path() == fake_home / ".config" / "zed" / "settings.json"


def test_mcphost_config_path(fake_home: Path) -> None:
    assert MCPHostAdapter().config_path() == fake_home / ".mcphost.json"


def test_ollmcp_config_path(fake_home: Path) -> None:
    assert OllmcpAdapter().config_path() == fake_home / ".config" / "ollmcp" / "config.json"


# ---------- mcphost is_installed (overrides default — parent is $HOME) ----------


def test_mcphost_is_installed_false_when_nothing_there(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr("memboot.clients.mcphost.shutil.which", lambda _: None)
    assert not MCPHostAdapter().is_installed()


def test_mcphost_is_installed_true_when_json_config_exists(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr("memboot.clients.mcphost.shutil.which", lambda _: None)
    (fake_home / ".mcphost.json").write_text("{}")
    assert MCPHostAdapter().is_installed()


def test_mcphost_is_installed_true_when_yaml_sibling_config_exists(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """User has the YAML variant — memboot will write the JSON one, but should
    still recognize that mcphost is present."""
    monkeypatch.setattr("memboot.clients.mcphost.shutil.which", lambda _: None)
    (fake_home / ".mcphost.yml").write_text("mcpServers: {}\n")
    assert MCPHostAdapter().is_installed()


def test_mcphost_is_installed_true_when_binary_on_path(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr("memboot.clients.mcphost.shutil.which", lambda _: "/usr/local/bin/mcphost")
    assert MCPHostAdapter().is_installed()


def test_claude_desktop_path_macos(fake_home: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("memboot.clients.base._is_macos", lambda: True)
    monkeypatch.setattr("memboot.clients.base._is_windows", lambda: False)
    expected = (
        fake_home / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
    )
    assert ClaudeDesktopAdapter().config_path() == expected


def test_claude_desktop_path_linux(fake_home: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("memboot.clients.base._is_macos", lambda: False)
    monkeypatch.setattr("memboot.clients.base._is_windows", lambda: False)
    expected = fake_home / ".config" / "Claude" / "claude_desktop_config.json"
    assert ClaudeDesktopAdapter().config_path() == expected


def test_claude_desktop_path_windows(fake_home: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("memboot.clients.base._is_macos", lambda: False)
    monkeypatch.setattr("memboot.clients.base._is_windows", lambda: True)
    expected = fake_home / "AppData" / "Claude" / "claude_desktop_config.json"
    assert ClaudeDesktopAdapter().config_path() == expected


# ---------- is_installed detection ----------


def test_is_installed_false_when_nothing_there(fake_home: Path) -> None:
    assert not ClaudeCodeAdapter().is_installed()


def test_is_installed_true_when_parent_dir_exists(fake_home: Path) -> None:
    (fake_home / ".claude").mkdir()
    assert ClaudeCodeAdapter().is_installed()


def test_is_installed_true_when_config_file_exists(fake_home: Path) -> None:
    cfg = fake_home / ".cursor" / "mcp.json"
    cfg.parent.mkdir()
    cfg.write_text("{}")
    assert CursorAdapter().is_installed()


# ---------- read_config ----------


def test_read_config_missing_file_returns_empty(fake_home: Path) -> None:
    assert ClaudeCodeAdapter().read_config() == {}


def test_read_config_empty_file_returns_empty(fake_home: Path) -> None:
    cfg = fake_home / ".claude" / "mcp.json"
    cfg.parent.mkdir()
    cfg.write_text("")
    assert ClaudeCodeAdapter().read_config() == {}


def test_read_config_bad_json_raises(fake_home: Path) -> None:
    cfg = fake_home / ".claude" / "mcp.json"
    cfg.parent.mkdir()
    cfg.write_text("{not: valid}")
    with pytest.raises(ConfigParseError, match="not valid JSON"):
        ClaudeCodeAdapter().read_config()


def test_read_config_non_object_raises(fake_home: Path) -> None:
    cfg = fake_home / ".claude" / "mcp.json"
    cfg.parent.mkdir()
    cfg.write_text("[]")
    with pytest.raises(ConfigParseError, match="must be a JSON object"):
        ClaudeCodeAdapter().read_config()


# ---------- inject/remove/has (standard clients) ----------


@pytest.mark.parametrize("cls", STANDARD_CLIENTS)
def test_standard_inject_preserves_other_servers(cls) -> None:
    adapter = cls()
    config = {"mcpServers": {"other": {"command": "other"}}}
    entry = build_server_entry()
    new = adapter.inject_server(config, "memboot", entry)
    assert new["mcpServers"]["other"] == {"command": "other"}
    assert new["mcpServers"]["memboot"] == entry


@pytest.mark.parametrize("cls", STANDARD_CLIENTS)
def test_standard_inject_is_idempotent(cls) -> None:
    adapter = cls()
    entry = build_server_entry()
    a = adapter.inject_server({}, "memboot", entry)
    b = adapter.inject_server(a, "memboot", entry)
    assert a == b


@pytest.mark.parametrize("cls", STANDARD_CLIENTS)
def test_standard_remove_preserves_other_servers(cls) -> None:
    adapter = cls()
    entry = build_server_entry()
    config = {"mcpServers": {"other": {"command": "other"}, "memboot": entry}}
    new = adapter.remove_server(config, "memboot")
    assert "memboot" not in new["mcpServers"]
    assert new["mcpServers"]["other"] == {"command": "other"}


@pytest.mark.parametrize("cls", STANDARD_CLIENTS)
def test_standard_remove_absent_is_noop(cls) -> None:
    adapter = cls()
    config = {"mcpServers": {"other": {"command": "other"}}}
    new = adapter.remove_server(config, "memboot")
    assert new == config


@pytest.mark.parametrize("cls", STANDARD_CLIENTS)
def test_standard_has_server(cls) -> None:
    adapter = cls()
    entry = build_server_entry()
    assert not adapter.has_server({}, "memboot")
    assert not adapter.has_server({"mcpServers": {}}, "memboot")
    assert adapter.has_server({"mcpServers": {"memboot": entry}}, "memboot")


@pytest.mark.parametrize("cls", STANDARD_CLIENTS)
def test_standard_inject_creates_mcp_servers_key(cls) -> None:
    adapter = cls()
    entry = build_server_entry()
    new = adapter.inject_server({"otherKey": "preserved"}, "memboot", entry)
    assert new["otherKey"] == "preserved"
    assert new["mcpServers"] == {"memboot": entry}


# ---------- zed uses context_servers ----------


def test_zed_inject_uses_context_servers() -> None:
    entry = build_server_entry()
    new = ZedAdapter().inject_server({}, "memboot", entry)
    assert "mcpServers" not in new
    assert new["context_servers"] == {"memboot": entry}


def test_zed_preserves_unrelated_settings() -> None:
    existing = {"theme": "dark", "context_servers": {"other": {"command": "x"}}}
    new = ZedAdapter().inject_server(existing, "memboot", build_server_entry())
    assert new["theme"] == "dark"
    assert new["context_servers"]["other"] == {"command": "x"}
    assert "memboot" in new["context_servers"]


def test_zed_has_server_uses_context_servers() -> None:
    entry = build_server_entry()
    assert ZedAdapter().has_server({"context_servers": {"memboot": entry}}, "memboot")
    assert not ZedAdapter().has_server({"mcpServers": {"memboot": entry}}, "memboot")


# ---------- write_config atomic + backup ----------


def test_write_config_writes_atomically(fake_home: Path) -> None:
    adapter = ClaudeCodeAdapter()
    config = {"mcpServers": {"memboot": build_server_entry()}}
    adapter.write_config(config)

    written = json.loads((fake_home / ".claude" / "mcp.json").read_text())
    assert written == config


def test_write_config_creates_parent_dirs(fake_home: Path) -> None:
    adapter = WindsurfAdapter()
    adapter.write_config({"mcpServers": {}})
    assert (fake_home / ".codeium" / "windsurf" / "mcp_config.json").exists()


def test_write_config_creates_backup_when_file_exists(fake_home: Path) -> None:
    adapter = ClaudeCodeAdapter()
    cfg = adapter.config_path()
    cfg.parent.mkdir(parents=True)
    cfg.write_text('{"existing": true}')

    backup_path = adapter.write_config({"new": True})

    assert backup_path is not None
    assert backup_path.exists()
    assert json.loads(backup_path.read_text()) == {"existing": True}


def test_write_config_skips_backup_when_requested(fake_home: Path) -> None:
    adapter = ClaudeCodeAdapter()
    cfg = adapter.config_path()
    cfg.parent.mkdir(parents=True)
    cfg.write_text('{"existing": true}')

    backup_path = adapter.write_config({"new": True}, backup=False)

    assert backup_path is None


def test_write_config_no_backup_when_file_absent(fake_home: Path) -> None:
    adapter = ClaudeCodeAdapter()
    backup_path = adapter.write_config({"new": True})
    assert backup_path is None


def test_write_config_prunes_old_backups(fake_home: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Writing 7 times with keep=3 should leave only the 3 most recent backups."""
    import itertools

    counter = itertools.count(1)

    class _FakeDT:
        @staticmethod
        def now(tz=None):  # type: ignore[no-untyped-def]
            class _D:
                def strftime(self, fmt):  # type: ignore[no-untyped-def]
                    return f"2026010{next(counter)}T000000Z"

            return _D()

    monkeypatch.setattr("memboot.clients.base.datetime", _FakeDT)

    adapter = ClaudeCodeAdapter()
    cfg = adapter.config_path()
    cfg.parent.mkdir(parents=True)
    cfg.write_text('{"start": true}')

    for i in range(7):
        adapter.write_config({"iteration": i}, backups_keep=3)

    backups = sorted(cfg.parent.glob(f"{cfg.name}.memboot-backup-*"))
    assert len(backups) == 3
