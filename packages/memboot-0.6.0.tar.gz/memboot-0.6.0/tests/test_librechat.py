"""Tests for the LibreChat adapter.

LibreChat is the only YAML-based adapter (Codex is TOML, the other 7 use
JSON), so these tests focus on YAML round-tripping, the
`MEMBOOT_LIBRECHAT_CONFIG` env override, and shared backup/atomic-write
semantics.
"""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from memboot.clients import LibreChatAdapter
from memboot.clients.base import build_server_entry
from memboot.exceptions import ConfigParseError

# conftest.py autouses `fake_home` to isolate every test from the real
# filesystem; tests here can declare `fake_home: Path` to read the tmp path.


# ---------- config path ----------


def test_librechat_default_config_path(fake_home: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    expected = fake_home / ".config" / "librechat" / "librechat.yaml"
    assert LibreChatAdapter().config_path() == expected


def test_librechat_env_override_config_path(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    custom = fake_home / "LibreChat" / "librechat.yaml"
    monkeypatch.setenv("MEMBOOT_LIBRECHAT_CONFIG", str(custom))
    assert LibreChatAdapter().config_path() == custom


def test_librechat_env_override_expands_user(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Env override should honor `~` expansion."""
    monkeypatch.setenv("HOME", str(fake_home))
    monkeypatch.setenv("MEMBOOT_LIBRECHAT_CONFIG", "~/my-librechat.yaml")
    assert LibreChatAdapter().config_path() == fake_home / "my-librechat.yaml"


# ---------- is_installed detection ----------


def test_librechat_is_installed_false_when_nothing_there(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    assert not LibreChatAdapter().is_installed()


def test_librechat_is_installed_true_when_parent_dir_exists(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    (fake_home / ".config" / "librechat").mkdir(parents=True)
    assert LibreChatAdapter().is_installed()


def test_librechat_is_installed_true_when_config_file_exists(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    cfg = fake_home / ".config" / "librechat" / "librechat.yaml"
    cfg.parent.mkdir(parents=True)
    cfg.write_text("")
    assert LibreChatAdapter().is_installed()


# ---------- read_config ----------


def test_librechat_read_config_missing_file_returns_empty(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    assert LibreChatAdapter().read_config() == {}


def test_librechat_read_config_empty_file_returns_empty(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    cfg = fake_home / ".config" / "librechat" / "librechat.yaml"
    cfg.parent.mkdir(parents=True)
    cfg.write_text("")
    assert LibreChatAdapter().read_config() == {}


def test_librechat_read_config_whitespace_only_returns_empty(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    cfg = fake_home / ".config" / "librechat" / "librechat.yaml"
    cfg.parent.mkdir(parents=True)
    cfg.write_text("   \n\n\t\n")
    assert LibreChatAdapter().read_config() == {}


def test_librechat_read_config_null_yaml_returns_empty(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A YAML file containing only comments parses to None — treat as empty."""
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    cfg = fake_home / ".config" / "librechat" / "librechat.yaml"
    cfg.parent.mkdir(parents=True)
    cfg.write_text("# just a comment\n")
    assert LibreChatAdapter().read_config() == {}


def test_librechat_read_config_valid_yaml_parses(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    cfg = fake_home / ".config" / "librechat" / "librechat.yaml"
    cfg.parent.mkdir(parents=True)
    cfg.write_text(
        "mcpServers:\n  memboot:\n    command: memboot\n    args:\n      - serve\n    env: {}\n"
    )
    data = LibreChatAdapter().read_config()
    assert data == {
        "mcpServers": {
            "memboot": {
                "command": "memboot",
                "args": ["serve"],
                "env": {},
            }
        }
    }


def test_librechat_read_config_bad_yaml_raises(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    cfg = fake_home / ".config" / "librechat" / "librechat.yaml"
    cfg.parent.mkdir(parents=True)
    cfg.write_text("foo: [unclosed\n  bar: also bad")
    with pytest.raises(ConfigParseError, match="not valid YAML"):
        LibreChatAdapter().read_config()


def test_librechat_read_config_non_mapping_raises(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A YAML list at the root is invalid for librechat.yaml."""
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    cfg = fake_home / ".config" / "librechat" / "librechat.yaml"
    cfg.parent.mkdir(parents=True)
    cfg.write_text("- one\n- two\n")
    with pytest.raises(ConfigParseError, match="must be a YAML mapping"):
        LibreChatAdapter().read_config()


def test_librechat_read_config_preserves_unrelated_sections(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A real librechat.yaml will have endpoints, models, etc. alongside mcpServers."""
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    cfg = fake_home / ".config" / "librechat" / "librechat.yaml"
    cfg.parent.mkdir(parents=True)
    cfg.write_text(
        "version: 1.0.5\n"
        "cache: true\n"
        "endpoints:\n"
        "  custom:\n"
        "    - name: ollama\n"
        "      baseURL: http://localhost:11434/v1\n"
        "mcpServers:\n"
        "  other:\n"
        "    command: node\n"
        "    args:\n"
        "      - some-server.js\n"
    )
    data = LibreChatAdapter().read_config()
    assert data["version"] == "1.0.5"
    assert data["cache"] is True
    assert data["endpoints"]["custom"][0]["name"] == "ollama"
    assert "other" in data["mcpServers"]


# ---------- inject_server (mcpServers, same key as JSON adapters) ----------


def test_librechat_inject_uses_mcp_servers_camelcase_key() -> None:
    adapter = LibreChatAdapter()
    entry = build_server_entry()
    new = adapter.inject_server({}, "memboot", entry)
    # LibreChat uses mcpServers (camelCase), same as Claude/Cursor/Windsurf
    assert "mcp_servers" not in new
    assert new["mcpServers"] == {"memboot": entry}


def test_librechat_inject_preserves_other_servers() -> None:
    adapter = LibreChatAdapter()
    config = {"mcpServers": {"other": {"command": "node", "args": ["s.js"]}}}
    entry = build_server_entry()
    new = adapter.inject_server(config, "memboot", entry)
    assert new["mcpServers"]["other"] == {"command": "node", "args": ["s.js"]}
    assert new["mcpServers"]["memboot"] == entry


def test_librechat_inject_is_idempotent() -> None:
    adapter = LibreChatAdapter()
    entry = build_server_entry()
    a = adapter.inject_server({}, "memboot", entry)
    b = adapter.inject_server(a, "memboot", entry)
    assert a == b


def test_librechat_inject_preserves_unrelated_top_level_settings() -> None:
    """Real librechat.yaml has version, cache, endpoints, etc. that must survive."""
    adapter = LibreChatAdapter()
    entry = build_server_entry()
    existing = {
        "version": "1.0.5",
        "cache": True,
        "endpoints": {"custom": [{"name": "ollama"}]},
        "mcpServers": {"other": {"command": "x"}},
    }
    new = adapter.inject_server(existing, "memboot", entry)
    assert new["version"] == "1.0.5"
    assert new["cache"] is True
    assert new["endpoints"] == {"custom": [{"name": "ollama"}]}
    assert new["mcpServers"]["other"] == {"command": "x"}
    assert new["mcpServers"]["memboot"] == entry


def test_librechat_inject_creates_mcp_servers_key_if_absent() -> None:
    adapter = LibreChatAdapter()
    entry = build_server_entry()
    new = adapter.inject_server({"version": "1.0.5"}, "memboot", entry)
    assert new["version"] == "1.0.5"
    assert new["mcpServers"] == {"memboot": entry}


# ---------- remove_server ----------


def test_librechat_remove_preserves_other_servers() -> None:
    adapter = LibreChatAdapter()
    entry = build_server_entry()
    config = {"mcpServers": {"other": {"command": "other"}, "memboot": entry}}
    new = adapter.remove_server(config, "memboot")
    assert "memboot" not in new["mcpServers"]
    assert new["mcpServers"]["other"] == {"command": "other"}


def test_librechat_remove_absent_is_noop() -> None:
    adapter = LibreChatAdapter()
    config = {"mcpServers": {"other": {"command": "other"}}}
    new = adapter.remove_server(config, "memboot")
    assert new == config


# ---------- has_server ----------


def test_librechat_has_server() -> None:
    adapter = LibreChatAdapter()
    entry = build_server_entry()
    assert not adapter.has_server({}, "memboot")
    assert not adapter.has_server({"mcpServers": {}}, "memboot")
    assert adapter.has_server({"mcpServers": {"memboot": entry}}, "memboot")


# ---------- write_config: YAML serialization ----------


def test_librechat_write_config_produces_valid_yaml(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    adapter = LibreChatAdapter()
    entry = build_server_entry()
    config = adapter.inject_server({}, "memboot", entry)
    adapter.write_config(config)

    written = (fake_home / ".config" / "librechat" / "librechat.yaml").read_text()
    parsed = yaml.safe_load(written)
    assert parsed == config


def test_librechat_write_config_round_trips(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    adapter = LibreChatAdapter()
    entry = build_server_entry()
    config = adapter.inject_server({"version": "1.0.5"}, "memboot", entry)
    adapter.write_config(config)
    read_back = adapter.read_config()
    assert read_back == config


def test_librechat_write_config_creates_parent_dirs(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    adapter = LibreChatAdapter()
    adapter.write_config({"mcpServers": {}})
    assert (fake_home / ".config" / "librechat" / "librechat.yaml").exists()


def test_librechat_write_config_creates_backup_when_file_exists(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    adapter = LibreChatAdapter()
    cfg = adapter.config_path()
    cfg.parent.mkdir(parents=True)
    cfg.write_text("version: 1.0.4\n")

    backup_path = adapter.write_config({"version": "1.0.5"})

    assert backup_path is not None
    assert backup_path.exists()
    assert backup_path.read_text() == "version: 1.0.4\n"


def test_librechat_write_config_skips_backup_when_requested(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    adapter = LibreChatAdapter()
    cfg = adapter.config_path()
    cfg.parent.mkdir(parents=True)
    cfg.write_text("version: 1.0.4\n")

    backup_path = adapter.write_config({"version": "1.0.5"}, backup=False)
    assert backup_path is None


def test_librechat_write_config_no_backup_when_file_absent(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    adapter = LibreChatAdapter()
    backup_path = adapter.write_config({"mcpServers": {}})
    assert backup_path is None


def test_librechat_write_config_uses_env_override_path(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Setting MEMBOOT_LIBRECHAT_CONFIG redirects writes to the chosen path."""
    custom = fake_home / "custom" / "librechat.yaml"
    monkeypatch.setenv("MEMBOOT_LIBRECHAT_CONFIG", str(custom))

    adapter = LibreChatAdapter()
    adapter.write_config({"mcpServers": {}})
    assert custom.exists()
    # Default location must NOT have been written
    default = fake_home / ".config" / "librechat" / "librechat.yaml"
    assert not default.exists()


# ---------- end-to-end install flow ----------


def test_librechat_full_install_flow_writes_expected_yaml(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Simulate `memboot install librechat` end-to-end."""
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    adapter = LibreChatAdapter()

    # No config yet
    config = adapter.read_config()
    assert config == {}

    # Inject memboot
    entry = build_server_entry()
    config = adapter.inject_server(config, "memboot", entry)
    adapter.write_config(config)

    # Verify: file exists, parses, has expected structure
    written = (fake_home / ".config" / "librechat" / "librechat.yaml").read_text()
    parsed = yaml.safe_load(written)
    assert parsed["mcpServers"]["memboot"]["command"] == "memboot"
    assert parsed["mcpServers"]["memboot"]["args"] == ["serve"]

    # has_server contract
    assert adapter.has_server(parsed, "memboot")


def test_librechat_install_alongside_existing_config(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """User has a real librechat.yaml with endpoints already configured;
    adding memboot should not disturb anything."""
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    adapter = LibreChatAdapter()
    cfg = adapter.config_path()
    cfg.parent.mkdir(parents=True)
    cfg.write_text(
        "version: 1.0.5\n"
        "cache: true\n"
        "endpoints:\n"
        "  custom:\n"
        "    - name: ollama\n"
        "      baseURL: http://localhost:11434/v1\n"
        "      models:\n"
        "        default:\n"
        "          - qwen2.5:14b\n"
        "mcpServers:\n"
        "  filesystem:\n"
        "    command: npx\n"
        "    args:\n"
        "      - -y\n"
        "      - '@modelcontextprotocol/server-filesystem'\n"
    )

    config = adapter.read_config()
    config = adapter.inject_server(config, "memboot", build_server_entry())
    adapter.write_config(config)

    final = adapter.read_config()
    assert final["version"] == "1.0.5"
    assert final["cache"] is True
    assert final["endpoints"]["custom"][0]["models"]["default"] == ["qwen2.5:14b"]
    assert final["mcpServers"]["filesystem"]["command"] == "npx"
    assert final["mcpServers"]["memboot"]["command"] == "memboot"


def test_librechat_uninstall_preserves_other_servers(
    fake_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Uninstall removes memboot without touching siblings or other sections."""
    monkeypatch.delenv("MEMBOOT_LIBRECHAT_CONFIG", raising=False)
    adapter = LibreChatAdapter()
    cfg = adapter.config_path()
    cfg.parent.mkdir(parents=True)
    cfg.write_text(
        "version: 1.0.5\n"
        "mcpServers:\n"
        "  memboot:\n"
        "    command: memboot\n"
        "    args:\n"
        "      - serve\n"
        "  filesystem:\n"
        "    command: npx\n"
        "    args:\n"
        "      - -y\n"
        "      - '@modelcontextprotocol/server-filesystem'\n"
    )

    config = adapter.read_config()
    config = adapter.remove_server(config, "memboot")
    adapter.write_config(config)

    final = adapter.read_config()
    assert final["version"] == "1.0.5"
    assert "memboot" not in final["mcpServers"]
    assert final["mcpServers"]["filesystem"]["command"] == "npx"
