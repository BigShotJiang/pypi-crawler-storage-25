"""Tests for the OpenAI Codex CLI adapter.

Codex is the first TOML-based adapter (all other 5 clients use JSON),
so these tests focus on TOML round-tripping, the `mcp_servers` (underscore)
key convention, and shared backup/atomic-write semantics.
"""

from __future__ import annotations

import tomllib
from pathlib import Path

import pytest

from memboot.clients import CodexAdapter
from memboot.clients.base import build_server_entry
from memboot.exceptions import ConfigParseError

# conftest.py autouses `fake_home` to isolate every test from the real
# filesystem; tests here can declare `fake_home: Path` to read the tmp path.


# ---------- config path ----------


def test_codex_config_path(fake_home: Path) -> None:
    assert CodexAdapter().config_path() == fake_home / ".codex" / "config.toml"


# ---------- is_installed detection ----------


def test_codex_is_installed_false_when_nothing_there(fake_home: Path) -> None:
    assert not CodexAdapter().is_installed()


def test_codex_is_installed_true_when_parent_dir_exists(fake_home: Path) -> None:
    (fake_home / ".codex").mkdir()
    assert CodexAdapter().is_installed()


def test_codex_is_installed_true_when_config_file_exists(fake_home: Path) -> None:
    cfg = fake_home / ".codex" / "config.toml"
    cfg.parent.mkdir()
    cfg.write_text("")
    assert CodexAdapter().is_installed()


# ---------- read_config ----------


def test_codex_read_config_missing_file_returns_empty(fake_home: Path) -> None:
    assert CodexAdapter().read_config() == {}


def test_codex_read_config_empty_file_returns_empty(fake_home: Path) -> None:
    cfg = fake_home / ".codex" / "config.toml"
    cfg.parent.mkdir()
    cfg.write_text("")
    assert CodexAdapter().read_config() == {}


def test_codex_read_config_whitespace_only_returns_empty(fake_home: Path) -> None:
    cfg = fake_home / ".codex" / "config.toml"
    cfg.parent.mkdir()
    cfg.write_text("   \n\n\t\n")
    assert CodexAdapter().read_config() == {}


def test_codex_read_config_valid_toml_parses(fake_home: Path) -> None:
    cfg = fake_home / ".codex" / "config.toml"
    cfg.parent.mkdir()
    cfg.write_text(
        '[mcp_servers.memboot]\ncommand = "memboot"\nargs = ["serve"]\n\n'
        "[mcp_servers.memboot.env]\n"
    )
    data = CodexAdapter().read_config()
    assert data == {
        "mcp_servers": {
            "memboot": {
                "command": "memboot",
                "args": ["serve"],
                "env": {},
            }
        }
    }


def test_codex_read_config_bad_toml_raises(fake_home: Path) -> None:
    cfg = fake_home / ".codex" / "config.toml"
    cfg.parent.mkdir()
    cfg.write_text("[broken\nunclosed = table")
    with pytest.raises(ConfigParseError, match="not valid TOML"):
        CodexAdapter().read_config()


def test_codex_read_config_preserves_unrelated_sections(fake_home: Path) -> None:
    """A real ~/.codex/config.toml will have Codex's own settings alongside mcp_servers."""
    cfg = fake_home / ".codex" / "config.toml"
    cfg.parent.mkdir()
    cfg.write_text(
        'model = "gpt-5"\n'
        'approval_policy = "untrusted"\n\n'
        "[mcp_servers.other]\n"
        'command = "node"\n'
        'args = ["some-server.js"]\n'
    )
    data = CodexAdapter().read_config()
    assert data["model"] == "gpt-5"
    assert data["approval_policy"] == "untrusted"
    assert "other" in data["mcp_servers"]


# ---------- inject_server (mcp_servers with underscore) ----------


def test_codex_inject_uses_mcp_servers_underscore_key() -> None:
    adapter = CodexAdapter()
    entry = build_server_entry()
    new = adapter.inject_server({}, "memboot", entry)
    # Codex uses mcp_servers (underscore), NOT mcpServers (camelCase)
    assert "mcpServers" not in new
    assert new["mcp_servers"] == {"memboot": entry}


def test_codex_inject_preserves_other_servers() -> None:
    adapter = CodexAdapter()
    config = {
        "mcp_servers": {"context7": {"command": "npx", "args": ["-y", "@upstash/context7-mcp"]}}
    }
    entry = build_server_entry()
    new = adapter.inject_server(config, "memboot", entry)
    assert new["mcp_servers"]["context7"] == {
        "command": "npx",
        "args": ["-y", "@upstash/context7-mcp"],
    }
    assert new["mcp_servers"]["memboot"] == entry


def test_codex_inject_is_idempotent() -> None:
    adapter = CodexAdapter()
    entry = build_server_entry()
    a = adapter.inject_server({}, "memboot", entry)
    b = adapter.inject_server(a, "memboot", entry)
    assert a == b


def test_codex_inject_preserves_unrelated_top_level_settings() -> None:
    """Real Codex config has top-level settings that must survive our injection."""
    adapter = CodexAdapter()
    entry = build_server_entry()
    existing = {
        "model": "gpt-5",
        "approval_policy": "untrusted",
        "mcp_servers": {"other": {"command": "x"}},
    }
    new = adapter.inject_server(existing, "memboot", entry)
    assert new["model"] == "gpt-5"
    assert new["approval_policy"] == "untrusted"
    assert new["mcp_servers"]["other"] == {"command": "x"}
    assert new["mcp_servers"]["memboot"] == entry


def test_codex_inject_creates_mcp_servers_key_if_absent() -> None:
    adapter = CodexAdapter()
    entry = build_server_entry()
    new = adapter.inject_server({"model": "gpt-5"}, "memboot", entry)
    assert new["model"] == "gpt-5"
    assert new["mcp_servers"] == {"memboot": entry}


# ---------- remove_server ----------


def test_codex_remove_preserves_other_servers() -> None:
    adapter = CodexAdapter()
    entry = build_server_entry()
    config = {
        "mcp_servers": {
            "other": {"command": "other"},
            "memboot": entry,
        }
    }
    new = adapter.remove_server(config, "memboot")
    assert "memboot" not in new["mcp_servers"]
    assert new["mcp_servers"]["other"] == {"command": "other"}


def test_codex_remove_absent_is_noop() -> None:
    adapter = CodexAdapter()
    config = {"mcp_servers": {"other": {"command": "other"}}}
    new = adapter.remove_server(config, "memboot")
    assert new == config


# ---------- has_server ----------


def test_codex_has_server() -> None:
    adapter = CodexAdapter()
    entry = build_server_entry()
    assert not adapter.has_server({}, "memboot")
    assert not adapter.has_server({"mcp_servers": {}}, "memboot")
    assert adapter.has_server({"mcp_servers": {"memboot": entry}}, "memboot")


def test_codex_has_server_ignores_json_convention() -> None:
    """Guard against accidental use of the JSON-style `mcpServers` key."""
    adapter = CodexAdapter()
    entry = build_server_entry()
    # A config with the JSON-style key should NOT be recognized by Codex
    assert not adapter.has_server({"mcpServers": {"memboot": entry}}, "memboot")


# ---------- write_config: TOML serialization ----------


def test_codex_write_config_produces_valid_toml(fake_home: Path) -> None:
    adapter = CodexAdapter()
    entry = build_server_entry()
    config = adapter.inject_server({}, "memboot", entry)
    adapter.write_config(config)

    written = (fake_home / ".codex" / "config.toml").read_text()
    # Should be parseable TOML
    parsed = tomllib.loads(written)
    assert parsed == config


def test_codex_write_config_round_trips(fake_home: Path) -> None:
    """Write, then read back, should produce the same dict."""
    adapter = CodexAdapter()
    entry = build_server_entry()
    config = adapter.inject_server({"model": "gpt-5"}, "memboot", entry)
    adapter.write_config(config)
    read_back = adapter.read_config()
    assert read_back == config


def test_codex_write_config_creates_parent_dirs(fake_home: Path) -> None:
    adapter = CodexAdapter()
    adapter.write_config({"mcp_servers": {}})
    assert (fake_home / ".codex" / "config.toml").exists()


def test_codex_write_config_creates_backup_when_file_exists(fake_home: Path) -> None:
    adapter = CodexAdapter()
    cfg = adapter.config_path()
    cfg.parent.mkdir(parents=True)
    cfg.write_text('model = "gpt-4"\n')

    backup_path = adapter.write_config({"model": "gpt-5"})

    assert backup_path is not None
    assert backup_path.exists()
    # Backup preserves original TOML verbatim (bytes-for-bytes copy)
    assert backup_path.read_text() == 'model = "gpt-4"\n'


def test_codex_write_config_skips_backup_when_requested(fake_home: Path) -> None:
    adapter = CodexAdapter()
    cfg = adapter.config_path()
    cfg.parent.mkdir(parents=True)
    cfg.write_text('model = "gpt-4"\n')

    backup_path = adapter.write_config({"model": "gpt-5"}, backup=False)

    assert backup_path is None


def test_codex_write_config_no_backup_when_file_absent(fake_home: Path) -> None:
    adapter = CodexAdapter()
    backup_path = adapter.write_config({"mcp_servers": {}})
    assert backup_path is None


# ---------- end-to-end install flow ----------


def test_codex_full_install_flow_writes_expected_toml(fake_home: Path) -> None:
    """Simulate the full install flow a user would see from `memboot install codex`."""
    adapter = CodexAdapter()

    # No config yet
    config = adapter.read_config()
    assert config == {}

    # Inject memboot
    entry = build_server_entry()
    config = adapter.inject_server(config, "memboot", entry)
    adapter.write_config(config)

    # Verify: the TOML file exists, is parseable, and has the expected structure
    written = (fake_home / ".codex" / "config.toml").read_text()
    parsed = tomllib.loads(written)
    assert parsed["mcp_servers"]["memboot"]["command"] == "memboot"
    assert parsed["mcp_servers"]["memboot"]["args"] == ["serve"]

    # Verify `/mcp` in Codex TUI would see memboot (has_server contract)
    assert adapter.has_server(parsed, "memboot")


def test_codex_install_alongside_existing_mcp_server(fake_home: Path) -> None:
    """User already has another MCP server in Codex (e.g. context7); adding
    memboot should not disturb it."""
    adapter = CodexAdapter()
    cfg = adapter.config_path()
    cfg.parent.mkdir(parents=True)
    cfg.write_text(
        'model = "gpt-5"\n\n'
        "[mcp_servers.context7]\n"
        'command = "npx"\n'
        'args = ["-y", "@upstash/context7-mcp"]\n'
    )

    config = adapter.read_config()
    config = adapter.inject_server(config, "memboot", build_server_entry())
    adapter.write_config(config)

    final = adapter.read_config()
    assert final["model"] == "gpt-5"
    assert final["mcp_servers"]["context7"]["command"] == "npx"
    assert final["mcp_servers"]["memboot"]["command"] == "memboot"


def test_codex_uninstall_preserves_other_mcp_servers(fake_home: Path) -> None:
    """Uninstall removes memboot without disturbing sibling servers or top-level settings."""
    adapter = CodexAdapter()
    cfg = adapter.config_path()
    cfg.parent.mkdir(parents=True)
    cfg.write_text(
        'model = "gpt-5"\n\n'
        "[mcp_servers.memboot]\n"
        'command = "memboot"\n'
        'args = ["serve"]\n\n'
        "[mcp_servers.context7]\n"
        'command = "npx"\n'
        'args = ["-y", "@upstash/context7-mcp"]\n'
    )

    config = adapter.read_config()
    config = adapter.remove_server(config, "memboot")
    adapter.write_config(config)

    final = adapter.read_config()
    assert final["model"] == "gpt-5"
    assert "memboot" not in final["mcp_servers"]
    assert final["mcp_servers"]["context7"]["command"] == "npx"
