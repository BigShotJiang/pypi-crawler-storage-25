# campaign_analytic_engine/__init__.py
# This package provides reusable analytics functions for the Campaign Management System.
# It is designed as a standalone, importable Python package so it can be reused
# across different parts of the project or even in other projects.

from .analytics import (
    calculate_total_leads,
    calculate_converted_leads,
    calculate_conversion_rate,
    calculate_campaign_success_score,
)

__all__ = [
    "calculate_total_leads",
    "calculate_converted_leads",
    "calculate_conversion_rate",
    "calculate_campaign_success_score",
]
