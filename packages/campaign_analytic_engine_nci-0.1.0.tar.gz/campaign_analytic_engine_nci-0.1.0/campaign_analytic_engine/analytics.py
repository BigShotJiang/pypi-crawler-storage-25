# campaign_analytic_engine/analytics.py
#
# Reusable analytics functions for Campaign Management.
# These functions accept Django QuerySets or plain integers so they remain
# decoupled from any specific view or model implementation.


def calculate_total_leads(lead_queryset):
    """
    Return the total number of leads in the given queryset.

    Args:
        lead_queryset: A Django QuerySet of Lead objects (or any iterable).

    Returns:
        int: Total number of leads.
    """
    return lead_queryset.count()


def calculate_converted_leads(lead_queryset):
    """
    Return the number of leads with status 'Converted'.

    Args:
        lead_queryset: A Django QuerySet of Lead objects filtered to a campaign
                       or to all leads.

    Returns:
        int: Number of converted leads.
    """
    return lead_queryset.filter(status="Converted").count()


def calculate_conversion_rate(total_leads, converted_leads):
    """
    Calculate the percentage of leads that were converted.

    Args:
        total_leads (int): Total number of leads.
        converted_leads (int): Number of leads with status 'Converted'.

    Returns:
        float: Conversion rate as a percentage (0.0 – 100.0).
               Returns 0.0 if there are no leads to avoid division by zero.
    """
    if total_leads == 0:
        return 0.0
    rate = (converted_leads / total_leads) * 100
    return round(rate, 2)


def calculate_campaign_success_score(campaign, lead_queryset):
    """
    Produce a simple 0–100 success score for a single campaign.

    The score combines:
      - Conversion rate  (weighted 60 %)
      - Budget utilisation placeholder  (weighted 40 %)
        (Currently returns 100 if a budget is set, 50 otherwise –
         extend this once actual spend tracking is added.)

    Args:
        campaign: A Campaign model instance.
        lead_queryset: A QuerySet of Lead objects belonging to this campaign.

    Returns:
        float: A score between 0 and 100.
    """
    total = calculate_total_leads(lead_queryset)
    converted = calculate_converted_leads(lead_queryset)
    conv_rate = calculate_conversion_rate(total, converted)

    # Budget utilisation component (simple placeholder logic)
    if campaign.budget and campaign.budget > 0:
        budget_score = 100.0
    else:
        budget_score = 50.0

    score = (conv_rate * 0.6) + (budget_score * 0.4)
    return round(score, 2)
