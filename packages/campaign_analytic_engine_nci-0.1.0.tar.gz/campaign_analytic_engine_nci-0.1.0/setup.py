from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="campaign_analytic_engine_nci", # Using a unique name to avoid PyPI conflicts
    version="0.1.0",
    author="Muthu_pypy",
    author_email="ssmuthukumar12@gmail.com",
    description="A cloud-native analytics engine for campaign and lead tracking.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Muthu_pypy/campaign_analytic_engine",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)
