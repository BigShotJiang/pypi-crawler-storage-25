# Campaign Analytic Engine

The `campaign_analytic_engine` is a standalone, object-oriented Python library designed to calculate key performance indicators (KPIs) for marketing campaigns and lead tracking systems.

It is decoupled from any specific web framework (e.g. Django) so it can be utilized in serverless cloud environments like AWS Lambda.

## Features
- Calculates Conversion Rates
- Calculates Campaign Success Scores based on budget and lead conversions
- Clean, reusable, object-oriented API

## Usage Example

```python
from campaign_analytic_engine.analytics import CampaignAnalyzer

analyzer = CampaignAnalyzer(
    campaign_id=1,
    total_leads=150,
    converted_leads=25,
    budget=500.00
)

results = analyzer.generate_report()
print(results)
```
