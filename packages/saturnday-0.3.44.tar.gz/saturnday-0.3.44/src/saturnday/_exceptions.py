"""Exception hierarchy for saturnday.

Every exception inherits from ``CloudCoreError`` so callers can catch the
entire family with a single handler when needed.
"""

from __future__ import annotations


class CloudCoreError(Exception):
    """Base exception for all saturnday errors."""


class PlanValidationError(CloudCoreError):
    """Raised when a project plan fails validation.

    Attributes:
        errors: Individual validation failure descriptions.
    """

    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        joined = "; ".join(errors)
        super().__init__(f"Plan validation failed: {joined}")


class CoderAPIError(CloudCoreError):
    """Raised when a coder backend call fails.

    Attributes:
        http_status: HTTP status code, if available.
        raw_body: Truncated response body for diagnostics.
    """

    def __init__(
        self,
        message: str,
        *,
        http_status: int | None = None,
        raw_body: str = "",
    ) -> None:
        super().__init__(message)
        self.http_status = http_status
        self.raw_body = raw_body


class PatchExtractionError(CloudCoreError):
    """Raised when no valid code patch can be extracted from a coder response."""


class PatchApplicationError(CloudCoreError):
    """Raised when a patch cannot be applied to the repository."""


class GovernanceError(CloudCoreError):
    """Raised when governance check execution itself fails (not a FAIL disposition)."""


class TicketFailedError(CloudCoreError):
    """Raised when a ticket exhausts all repair attempts.

    Attributes:
        ticket_id: The failing ticket identifier.
        attempt: Final attempt number when the ticket was abandoned.
    """

    def __init__(self, ticket_id: str, attempt: int) -> None:
        self.ticket_id = ticket_id
        self.attempt = attempt
        super().__init__(
            f"Ticket {ticket_id!r} failed after {attempt} attempt(s)"
        )
