"""Frozen dataclasses used across saturnday.

All types are immutable (``frozen=True``) so they can be safely shared
between modules without risk of accidental mutation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


# ---------------------------------------------------------------------------
# Coder configuration
# ---------------------------------------------------------------------------

BackendName = Literal["codex-cli", "claude-cli", "openai", "anthropic"]


@dataclass(frozen=True, slots=True)
class CoderConfig:
    """Configuration for the AI coder backend.

    Attributes:
        backend: Which backend to use for code generation.
        base_url: API base URL (only for ``openai`` / ``anthropic`` backends).
        api_key: API key (only for ``openai`` / ``anthropic`` backends).
        model: Model identifier for API backends.
        temperature: Sampling temperature.
        max_tokens: Maximum tokens in the coder response.
        timeout_s: Request timeout in seconds.
    """

    backend: BackendName
    base_url: str = ""
    api_key: str = ""
    model: str = ""
    temperature: float = 0.0
    max_tokens: int = 16384
    timeout_s: int = 1200


# ---------------------------------------------------------------------------
# Ticket specification
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class TicketScope:
    """File-scope constraints for a single ticket.

    Attributes:
        allowed_globs: Glob patterns the coder may touch.
        forbidden_globs: Glob patterns the coder must not touch.
        max_files_changed: Budget cap on number of files changed.
        max_total_diff_lines: Budget cap on total diff lines.
        max_per_file_diff_lines: Budget cap on diff lines per file.
    """

    allowed_globs: tuple[str, ...] = ("**",)
    forbidden_globs: tuple[str, ...] = ()
    max_files_changed: int = 20
    max_total_diff_lines: int = 2000
    max_per_file_diff_lines: int = 500


@dataclass(frozen=True, slots=True)
class TicketSpec:
    """Specification for a single coding ticket.

    Attributes:
        ticket_id: Unique identifier (e.g. ``T001``).
        goal: Natural-language description of what to build.
        scope: File-scope and budget constraints.
        verify_cmd: Shell command to verify the ticket (e.g. ``pytest tests/test_foo.py``).
        acceptance_criteria: Human-readable acceptance criteria lines.
        dependencies: Ticket IDs that must complete before this one.
        out_of_scope: Explicit list of things the ticket must NOT do.
        evidence_required: Artifacts that must exist after the ticket completes.
        failure_mode: Expected failure type if the ticket fails
            (``coder_error``, ``spec_ambiguity``, ``dependency_missing``,
            ``governance_block``).
        if_blocked: Operator guidance for when the ticket fails all retries.
    """

    ticket_id: str
    goal: str
    scope: TicketScope = TicketScope()
    verify_cmd: str = ""
    acceptance_criteria: tuple[str, ...] = ()
    dependencies: tuple[str, ...] = ()
    out_of_scope: tuple[str, ...] = ()
    evidence_required: tuple[str, ...] = ()
    failure_mode: str = ""
    if_blocked: str = ""


# ---------------------------------------------------------------------------
# Phase definition
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class PhaseDef:
    """Definition of a plan execution phase.

    Attributes:
        phase_id: Unique identifier for the phase.
        name: Human-readable phase name.
        ticket_ids: Ticket IDs belonging to this phase.
    """

    phase_id: str
    name: str = ""
    ticket_ids: tuple[str, ...] = ()


# ---------------------------------------------------------------------------
# Project plan
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class ProjectPlan:
    """A validated, dependency-sorted project plan.

    Attributes:
        version: Plan schema version.
        project_id: Identifier for the project being built.
        notes: Free-form notes injected into every coder prompt.
        tickets: Ordered sequence of tickets (dependency-sorted).
        definition_of_done: Markers that must be satisfied for the run to succeed.
        stop_conditions: Normalized markers that abort the run when matched.
        max_project_tickets: Maximum tickets to execute (``None`` = no limit).
        phases: Execution phases grouping tickets.
        mode: Plan mode (``generation`` or ``remediation``).
        default_timeout_seconds: Default per-ticket timeout.
        default_retry_limit: Default per-ticket retry limit.
    """

    version: int
    project_id: str
    notes: str = ""
    tickets: tuple[TicketSpec, ...] = ()
    definition_of_done: tuple[str, ...] = ("all_tickets_passed",)
    stop_conditions: tuple[str, ...] = ()
    max_project_tickets: int | None = None
    phases: tuple[PhaseDef, ...] = ()
    mode: str = "generation"
    default_timeout_seconds: int = 300
    default_retry_limit: int = 2


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class TicketResult:
    """Outcome of a single ticket execution.

    Attributes:
        ticket_id: The ticket identifier.
        disposition: Final outcome (``PASS``, ``FAIL``, ``SKIP``, or ``CODED_UNGOVERNED``).
        attempts: Number of attempts made.
        changed_files: Files modified by the ticket.
        governance_disposition: Governance check result (``PASS`` or ``FAIL``).
        governance_evidence_path: Filesystem path to the raw governance
            evidence JSON produced by ``run_governance_check``. Empty string
            when governance did not run or produced no path.
        error: Error message if the ticket failed.
    """

    ticket_id: str
    disposition: Literal["PASS", "FAIL", "SKIP", "CODED_UNGOVERNED"]
    attempts: int = 0
    changed_files: tuple[str, ...] = ()
    governance_disposition: str = ""
    governance_evidence_path: str = ""
    error: str = ""
    failure_category: str = ""
    governance_findings: tuple[dict, ...] = ()


@dataclass(frozen=True, slots=True)
class RunResult:
    """Summary of an entire plan execution.

    Attributes:
        project_id: The project identifier from the plan.
        total_tickets: Total number of tickets in the plan.
        passed: Number of tickets that passed.
        failed: Number of tickets that failed.
        skipped: Number of tickets that were skipped.
        ticket_results: Per-ticket outcomes.
    """

    project_id: str
    total_tickets: int = 0
    passed: int = 0
    failed: int = 0
    skipped: int = 0
    coded_ungoverned: int = 0
    ticket_results: tuple[TicketResult, ...] = ()
    definition_of_done_met: bool = False
    stop_reason: str = ""
