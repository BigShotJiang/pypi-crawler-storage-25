"""Role-mode orchestration for Saturnday.

Loads role-specific prompt files and invokes the coder backend
in distinct controlled modes (repo_analyst, coder, governance_judge,
evidence_gate, repair, definition_of_done).
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Callable

from saturnday._exceptions import CoderAPIError

logger = logging.getLogger(__name__)

ROLE_MODES_DIR = Path(__file__).parent / "prompts" / "role_modes"

KNOWN_ROLES: frozenset[str] = frozenset({
    "coder", "repo_analyst", "governance_judge",
    "evidence_gate", "repair", "definition_of_done",
    "security_triage", "code_reviewer",
})

# Canonical classification of each role's runtime implementation path.
# prompt_pass: invoked via invoke_role() with .md prompt, produces RoleResult
# native_runtime: implemented by a dedicated subsystem, not via invoke_role()
# hybrid: prompt loaded via load_role_prompt() but invoked through native call_coder(), not invoke_role()
ROLE_CLASSIFICATIONS: dict[str, dict[str, str]] = {
    "repo_analyst": {
        "type": "prompt_pass",
        "path": "invoke_role → ticket_runner.py pre-run",
        "run": "automatic_pre_run",
        "repair": "not_used",
    },
    "coder": {
        "type": "native_runtime",
        "path": "context_assembler.build_system_prompt → call_coder",
        "run": "automatic_per_ticket",
        "repair": "not_used",
        "note": "coder.md exists as auxiliary role persona but primary execution uses context_assembler",
    },
    "governance_judge": {
        "type": "hybrid",
        "path": "run_governance_check (deterministic, per-ticket in run) + invoke_role (LLM advisory, post-repair)",
        "run": "automatic_per_ticket_deterministic",
        "repair": "automatic_post_repair_llm",
    },
    "definition_of_done": {
        "type": "prompt_pass",
        "path": "run_dod_check → invoke_role → ticket_runner.py post-run",
        "run": "automatic_post_run",
        "repair": "not_used",
    },
    "evidence_gate": {
        "type": "prompt_pass",
        "path": "invoke_role → ticket_runner.py post-run + repair_runner.py post-repair",
        "run": "automatic_post_run",
        "repair": "automatic_post_repair",
    },
    "repair": {
        "type": "hybrid",
        "path": "load_role_prompt('repair') as system prompt → call_coder (not via invoke_role)",
        "run": "not_used",
        "repair": "automatic_execution",
        "note": "Prompt loaded via role_modes loader but bypasses invoke_role pipeline",
    },
    "security_triage": {
        "type": "prompt_pass",
        "path": "invoke_role → security_triage.py post-governance",
        "run": "automatic_post_governance",
        "repair": "automatic_pre_repair",
        "note": "LLM-based false positive filter for security findings. Runs after pattern matching, before disposition.",
    },
    "code_reviewer": {
        "type": "prompt_pass",
        "path": "invoke_role → ticket_runner.py post-post-checks pre-contract",
        "run": "automatic_post_post_checks_warning",
        "repair": "not_used",
        "note": "LLM semantic review of code against ticket goal. WARNING only — does not block commits.",
    },
}

_OPERATOR_PREFS_FILE = "operator_preferences.md"


@lru_cache(maxsize=8)
def load_role_prompt(role: str) -> str:
    """Load operator_preferences.md + role-specific prompt.

    Args:
        role: One of the known role names.

    Returns:
        Combined prompt string (operator prefs + role prompt).

    Raises:
        ValueError: If ``role`` is not in :data:`KNOWN_ROLES`.
        FileNotFoundError: If operator preferences or role prompt file is missing.
    """
    if role not in KNOWN_ROLES:
        raise ValueError(f"Unknown role: {role!r}. Known roles: {sorted(KNOWN_ROLES)}")
    prefs_path = ROLE_MODES_DIR / _OPERATOR_PREFS_FILE
    role_path = ROLE_MODES_DIR / f"{role}.md"
    if not prefs_path.is_file():
        raise FileNotFoundError(f"Operator preferences not found: {prefs_path}")
    if not role_path.is_file():
        raise FileNotFoundError(f"Role prompt not found: {role_path}")
    prefs = prefs_path.read_text(encoding="utf-8")
    role_prompt = role_path.read_text(encoding="utf-8")
    return f"{prefs}\n\n---\n\n{role_prompt}"


def available_roles() -> list[str]:
    """List roles whose .md files exist on disk.

    Returns:
        Sorted list of role name strings.
    """
    return sorted(r for r in KNOWN_ROLES if (ROLE_MODES_DIR / f"{r}.md").is_file())


def missing_roles() -> list[str]:
    """List expected roles without prompt files.

    Returns:
        Sorted list of role name strings that have no matching .md file.
    """
    return sorted(r for r in KNOWN_ROLES if not (ROLE_MODES_DIR / f"{r}.md").is_file())


@dataclass
class RoleResult:
    """Result from a single role pass.

    Attributes:
        role: Name of the role that was invoked.
        task: Task payload that was sent to the role.
        output: Raw text output from the coder backend.
        success: ``True`` if the backend call succeeded without error.
        error: Error message string if the call failed, otherwise ``None``.
    """

    role: str
    task: str
    output: str
    success: bool
    error: str | None = None


def invoke_role(
    role: str,
    task: str,
    *,
    coder_config: Any,
    repo_path: Path,
    context: dict[str, Any] | None = None,
) -> RoleResult:
    """Run a single role pass against the coder backend.

    Args:
        role: Role name — must be in :data:`KNOWN_ROLES`.
        task: User-facing task payload text.
        coder_config: Coder backend configuration (passed through to
            :func:`~saturnday.coder_adapter.call_coder`).
        repo_path: Repository root directory (used as cwd by CLI backends).
        context: Optional dict appended to the task payload as JSON.

    Returns:
        :class:`RoleResult` with ``success=True`` on a clean backend call,
        ``success=False`` on any exception.
    """
    prompt = load_role_prompt(role)
    user_content = task
    if context:
        context_block = "\n\n## Context\n" + json.dumps(context, indent=2, default=str)
        user_content = task + context_block

    messages = [
        {"role": "system", "content": prompt},
        {"role": "user", "content": user_content},
    ]

    logger.info("Role pass: %s", role)
    try:
        from saturnday.coder_adapter import call_coder  # lazy import

        output = call_coder(coder_config, messages, repo_path)
        logger.info("Role pass complete: %s (%d chars)", role, len(output))
        return RoleResult(role=role, task=task, output=output, success=True)
    except (CoderAPIError, Exception) as exc:  # noqa: BLE001
        logger.warning("Role pass failed: %s -- %s", role, exc)
        return RoleResult(role=role, task=task, output="", success=False, error=str(exc))


def run_role_sequence(
    roles: list[tuple[str, str]],
    *,
    coder_config: Any,
    repo_path: Path,
    on_role_start: Callable[[str, str], None] | None = None,
    on_role_complete: Callable[[str, RoleResult], None] | None = None,
    stop_on_failure: bool = False,
) -> list[RoleResult]:
    """Run multiple role passes in sequence.

    Args:
        roles: List of ``(role_name, task_payload)`` tuples to execute in order.
        coder_config: Coder backend configuration forwarded to each
            :func:`invoke_role` call.
        repo_path: Repository root directory forwarded to each
            :func:`invoke_role` call.
        on_role_start: Optional callback invoked before each role with
            ``(role_name, task_payload)``.
        on_role_complete: Optional callback invoked after each role with
            ``(role_name, result)``.
        stop_on_failure: If ``True``, abort after the first failed role result.

    Returns:
        List of :class:`RoleResult` instances, one per role executed.
    """
    results: list[RoleResult] = []
    for role_name, task_payload in roles:
        if on_role_start:
            on_role_start(role_name, task_payload)
        result = invoke_role(
            role_name, task_payload,
            coder_config=coder_config,
            repo_path=repo_path,
        )
        results.append(result)
        if on_role_complete:
            on_role_complete(role_name, result)
        if stop_on_failure and not result.success:
            break
    return results


def run_dod_check(
    plan_path: Path,
    evidence_dir: Path,
    repo_path: Path,
    *,
    coder_config: Any,
) -> RoleResult:
    """Run the Definition of Done evaluation pass.

    Loads plan JSON, ledger, and run summary from disk, constructs a
    structured task description, then invokes the ``definition_of_done`` role.

    Args:
        plan_path: Path to the plan JSON file.
        evidence_dir: Root directory for evidence output (contains
            ``evidence/run/ledger.json`` and ``run-summary.json``).
        repo_path: Repository root directory.
        coder_config: Coder backend configuration.

    Returns:
        :class:`RoleResult` from the ``definition_of_done`` role.
    """
    # Load plan
    plan_data: dict[str, Any] = {}
    if plan_path.is_file():
        try:
            plan_data = json.loads(plan_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass

    # Load ledger
    ledger_data: dict[str, Any] = {}
    ledger_path = evidence_dir / "evidence" / "run" / "ledger.json"
    if ledger_path.is_file():
        try:
            ledger_data = json.loads(ledger_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass

    # Load run summary
    summary_data: dict[str, Any] = {}
    summary_path = evidence_dir / "run-summary.json"
    if summary_path.is_file():
        try:
            summary_data = json.loads(summary_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass

    # Build structured task
    tickets = plan_data.get("tickets", [])
    dod_markers = plan_data.get("definition_of_done", ["all_tickets_passed"])
    ticket_results = summary_data.get("ticket_results", [])

    # Include the original brief so DoD can verify brief-level completeness
    brief = plan_data.get("notes", "")
    brief_section = f"\n## Original Brief\n{brief[:500]}\n" if brief else ""

    # Include standards digest so DoD can judge code quality
    from saturnday.standards_digest import STANDARDS_DIGEST

    task_parts = [
        f"## {STANDARDS_DIGEST}",
        "## Plan Summary",
        f"Project: {plan_data.get('project_id', 'unknown')}",
        f"Total tickets: {len(tickets)}",
        f"DoD markers: {', '.join(dod_markers)}",
        brief_section,
        "## Ticket Dispositions",
    ]
    for tr in ticket_results:
        tid = tr.get("ticket_id", "?")
        disp = tr.get("disposition", "?")
        task_parts.append(f"  {tid}: {disp}")

    task_parts.append("")
    task_parts.append("## Acceptance Criteria")
    for t in tickets:
        tid = t.get("ticket_id", "?")
        criteria = t.get("acceptance_criteria", [])
        if criteria:
            task_parts.append(f"  {tid}: {'; '.join(criteria)}")

    if not ledger_data:
        task_parts.append("\n## Note: Ledger not found -- assessment based on summary only.")
    if not summary_data:
        task_parts.append("\n## Note: Run summary not found -- assessment based on plan only.")

    task_parts.append("\n## Task")
    task_parts.append("Evaluate whether the Definition of Done is met.")
    task_parts.append(
        "Classify each ticket as: COMPLETE, PARTIAL, FAILED, UNVERIFIABLE, or BLOCKED."
    )
    task_parts.append(
        "Classify overall DoD as: DOD_MET, DOD_PARTIAL, or DOD_NOT_MET."
    )

    task = "\n".join(task_parts)
    return invoke_role(
        "definition_of_done",
        task,
        coder_config=coder_config,
        repo_path=repo_path,
    )


def extract_classification(output: str, candidates: list[str]) -> str:
    """Extract the first matching classification string from LLM output.

    Scans ``output`` for the first occurrence of any string in
    ``candidates`` and returns it.  Falls back to a truncated first line
    if no candidate matches.

    Args:
        output: Raw text output from a role pass.
        candidates: Ordered list of classification strings to search for.

    Returns:
        Matched candidate string, or a truncated summary of ``output``.
    """
    for candidate in candidates:
        if candidate in output:
            return candidate
    # Fallback: first 80 chars of cleaned output
    clean = output.strip().replace("\n", " ")
    return clean[:80] + ("..." if len(clean) > 80 else "")
