"""Runtime ticket splitting: analyze complex tickets and break them down.

Before coding, the coder is asked to analyze the ticket's complexity.
If it estimates >80 lines of implementation, >2 files, or the goal
contains multiple distinct deliverables, it produces sub-tickets that
are executed sequentially in place of the original.

This follows the Saturnday dossier rules:
- Tickets >80 lines must be split
- Max 2 files per ticket (source + test)
- Each sub-ticket does ONE thing
- Integration tickets must be thin (imports/wiring only)
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path

from saturnday._exceptions import CoderAPIError
from saturnday._types import CoderConfig, TicketScope, TicketSpec
from saturnday.coder_adapter import call_coder, is_cli_backend

logger = logging.getLogger(__name__)

# Tickets with goals shorter than this are never split
_MIN_GOAL_LENGTH_FOR_SPLIT = 50

# Max sub-tickets from a single split
_MAX_SUB_TICKETS = 10

_SPLIT_ANALYSIS_PROMPT = """\
You are a senior software architect. Analyze this ticket and decide if it \
should be split into smaller sub-tickets.

SPLITTING RULES — be aggressive, prefer many small tickets over few large ones:
- If the ticket would produce >40 lines of implementation code, SPLIT IT.
- Max 1 source file per sub-ticket (plus its test file).
- Each sub-ticket does ONE thing. If you can describe it with "and", split it.
- Integration tickets (app.py, cli.py) must be thin: imports + wiring only.
- Max 2 endpoints per sub-ticket for FastAPI.
- Large modules: groups of 3-5 functions per sub-ticket.
- One file = one sub-ticket owner. Never split a file across sub-tickets.

TICKET TO ANALYZE:
{goal}

SCOPE: {scope_summary}

Respond with ONLY valid JSON. No markdown, no explanation.

If the ticket is small enough (<=80 lines, <=2 files, one concern), respond:
{{"split": false}}

If it should be split, respond:
{{"split": true, "sub_tickets": [
  {{"id": "a", "goal": "...", "files": ["path1.py", "test_path1.py"]}},
  {{"id": "b", "goal": "...", "files": ["path2.py", "test_path2.py"], "depends_on": ["a"]}}
]}}

Keep sub-ticket goals detailed and explicit. Include exact function signatures \
and return types. Max {max_sub} sub-tickets."""


def should_split(ticket: TicketSpec) -> bool:
    """Heuristic check: does this ticket look complex enough to split?

    Args:
        ticket: The ticket to evaluate.

    Returns:
        True if the ticket should be analyzed for splitting.
    """
    goal = ticket.goal

    # Short goals are fine
    if len(goal) < _MIN_GOAL_LENGTH_FOR_SPLIT:
        return False

    # Multiple files mentioned in the goal
    file_mentions = re.findall(r'(?:File|FILE|src/|tests/)\S+\.py', goal)
    if len(file_mentions) > 2:
        return True

    # Goal contains "and" joining distinct deliverables
    if re.search(r'\band\b.*\band\b', goal, re.IGNORECASE):
        return True

    # Multiple "must" or "MUST" clauses suggest complexity
    must_count = len(re.findall(r'\bMUST\b|\bmust\b', goal))
    if must_count > 4:
        return True

    # Large scope budget suggests complex ticket
    if ticket.scope.max_files_changed > 3:
        return True

    return False


def analyze_and_split(
    ticket: TicketSpec,
    config: CoderConfig,
    repo_path: Path,
    plan_notes: str,
) -> list[TicketSpec]:
    """Ask the coder to analyze a ticket and split if needed.

    Args:
        ticket: The original ticket.
        config: Coder backend configuration.
        repo_path: Repository path.
        plan_notes: Plan notes for context.

    Returns:
        List of sub-tickets if split, or [ticket] unchanged if not.
    """
    if not should_split(ticket):
        logger.debug("Ticket %s: no split needed (simple)", ticket.ticket_id)
        return [ticket]

    logger.info("Ticket %s: analyzing for split (goal=%d chars)", ticket.ticket_id, len(ticket.goal))

    scope_summary = f"allowed={list(ticket.scope.allowed_globs)}, max_files={ticket.scope.max_files_changed}"

    prompt = _SPLIT_ANALYSIS_PROMPT.format(
        goal=ticket.goal,
        scope_summary=scope_summary,
        max_sub=_MAX_SUB_TICKETS,
    )

    messages = [
        {"role": "system", "content": "You are a software architect. Respond ONLY with valid JSON."},
        {"role": "user", "content": prompt},
    ]

    try:
        if is_cli_backend(config):
            # For CLI backends, use a simple prompt that just returns JSON
            from saturnday.coder_adapter import _call_claude_cli, _call_codex_cli, _messages_to_text
            text = _messages_to_text(messages)
            if config.backend == "claude-cli":
                response = _call_claude_cli(config, text, repo_path)
            else:
                response = _call_codex_cli(config, text, repo_path)
        else:
            response = call_coder(config, messages, repo_path)
    except CoderAPIError as exc:
        logger.warning("Split analysis failed for %s: %s — running unsplit", ticket.ticket_id, exc)
        return [ticket]

    # Parse JSON from response
    sub_tickets = _parse_split_response(response, ticket)
    if sub_tickets is None:
        logger.info("Ticket %s: coder says no split needed", ticket.ticket_id)
        return [ticket]

    logger.info(
        "Ticket %s: split into %d sub-tickets: %s",
        ticket.ticket_id,
        len(sub_tickets),
        [s.ticket_id for s in sub_tickets],
    )
    return sub_tickets


def _parse_split_response(
    response: str,
    original: TicketSpec,
) -> list[TicketSpec] | None:
    """Parse the split analysis JSON response.

    Returns:
        List of sub-tickets, or None if no split.
    """
    # Extract JSON from response (might have surrounding text)
    json_match = re.search(r'\{.*\}', response, re.DOTALL)
    if not json_match:
        logger.warning("No JSON found in split response")
        return None

    try:
        data = json.loads(json_match.group())
    except json.JSONDecodeError:
        logger.warning("Invalid JSON in split response")
        return None

    if not data.get("split", False):
        return None

    raw_subs = data.get("sub_tickets", [])
    if not raw_subs or len(raw_subs) < 2:
        return None
    if len(raw_subs) > _MAX_SUB_TICKETS:
        raw_subs = raw_subs[:_MAX_SUB_TICKETS]

    sub_tickets: list[TicketSpec] = []
    completed_sub_ids: list[str] = []

    for raw in raw_subs:
        sub_id = f"{original.ticket_id}.{raw.get('id', str(len(sub_tickets) + 1))}"
        goal = raw.get("goal", "")
        if not goal:
            continue

        files = raw.get("files", [])
        allowed_globs = tuple(files) if files else original.scope.allowed_globs

        # Sub-ticket dependencies: original's deps + any prior sub-tickets it depends on
        raw_deps = raw.get("depends_on", [])
        sub_deps = list(original.dependencies)
        for dep_id in raw_deps:
            full_dep = f"{original.ticket_id}.{dep_id}"
            if full_dep in completed_sub_ids:
                sub_deps.append(full_dep)

        scope = TicketScope(
            allowed_globs=allowed_globs,
            forbidden_globs=original.scope.forbidden_globs,
            max_files_changed=len(files) + 1 if files else original.scope.max_files_changed,
            max_total_diff_lines=original.scope.max_total_diff_lines,
            max_per_file_diff_lines=original.scope.max_per_file_diff_lines,
        )

        sub_tickets.append(TicketSpec(
            ticket_id=sub_id,
            goal=goal,
            scope=scope,
            verify_cmd=original.verify_cmd,
            acceptance_criteria=original.acceptance_criteria,
            dependencies=tuple(sub_deps),
        ))
        completed_sub_ids.append(sub_id)

    if len(sub_tickets) < 2:
        return None

    return sub_tickets
