"""Main orchestrator: execute a project plan ticket by ticket.

For each ticket (in dependency order):
1. Skip if dependencies not all completed.
2. Build system prompt (standards + coder personality) — cached.
3. Build ticket prompt (goal + scope + project state + plan notes).
4. Call the coder backend.
5. Detect changed files (git status for CLI, FILE blocks for API).
6. Stage only the current ticket's changed files.
7. Run saturnday governance on staged changes.
8. Filter governance findings to only current ticket's files (ignore pre-existing).
9. If PASS → git commit, update project state, record evidence.
10. If FAIL → git reset, retry with governance findings (max 2 retries).
11. If exhausted → skip ticket, record failure.
"""

from __future__ import annotations

import logging
import os
import sqlite3
import subprocess
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path

from saturnday.run.safe_shell import ShellPolicyViolation, safe_subprocess_run

from saturnday._exceptions import (
    CloudCoreError,
    CoderAPIError,
    GovernanceError,
    PatchApplicationError,
    PatchExtractionError,
)
from saturnday._types import CoderConfig, RunResult, TicketResult, TicketSpec
from saturnday.coder_adapter import call_coder, is_cli_backend
from saturnday.shared.backend_auth import capability_matrix, detect_auth_mode
from saturnday.context_assembler import (
    assemble_messages,
    build_system_prompt,
    build_ticket_prompt,
)
from saturnday.run.evidence import (
    TicketEvidence,
    compute_run_analytics,
    write_analytics,
    write_phase_summary,
    write_run_metadata,
    write_run_summary,
    write_ticket_evidence,
)
from saturnday.run.run_ledger import (
    RunLedger,
    create_ledger_from_plan,
    write_ledger_snapshot,
)
from saturnday.patch_extractor import (
    apply_file_blocks,
    apply_unified_diff,
    extract_changes,
)
from saturnday.post_checks import run_post_checks
from saturnday.run.lessons import (
    Lesson,
    format_lessons_for_prompt,
    init_db,
    load_lessons,
    store_lesson,
)
from saturnday.project_state import (
    ProjectState,
    generate_context_summary,
    load_state,
    save_state,
    update_state,
)

logger = logging.getLogger(__name__)

MAX_REPAIR_ATTEMPTS = 2

# Module-level progress log path — set by run_plan(), used by _log_progress()
_progress_log_path: Path | None = None


def _log_progress(msg: str) -> None:
    """Write a progress message to both logger and the progress log file."""
    logger.info(">> %s", msg)
    _path = _progress_log_path  # snapshot the global
    if _path and msg:
        try:
            with open(str(_path), "a", encoding="utf-8") as f:
                ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
                f.write(f"[{ts}] {msg}\n")
                f.flush()
        except Exception as exc:
            logger.debug("Progress log write failed: %s", exc)


_PROGRESS_SYSTEM_PROMPT = (
    "You write brief progress messages for Saturnday, a governance tool that "
    "runs 50+ checks on AI-generated code. These checks catch things that a "
    "direct Claude Code, Codex, or Cursor session would NOT catch:\n\n"
    "SECURITY (19 Python + 19 TypeScript checks): SQL injection, auth bypass, "
    "CSRF, XSS, hardcoded secrets (AWS keys, OpenAI keys, GitHub tokens, "
    "private keys), WebSocket auth, OAuth flow integrity, token handling "
    "(expiry, revocation, weak randomness), rate limiting, IDOR, user "
    "enumeration, cookie security, frontend secret exposure.\n\n"
    "AI-SPECIFIC: Hallucinated imports (packages that don't exist on npm/PyPI), "
    "no-assert tests, tautological assertions, dead code (cross-file), "
    "placeholder stubs, dependency declaration verification.\n\n"
    "QUALITY: Syntax validation, import resolution, Python version compatibility, "
    "typosquat detection, project hygiene (README/LICENSE), blast radius.\n\n"
    "Rules:\n"
    "- Frame messages as: 'An AI coder without Saturnday would have...' then "
    "explain what the ungoverned AI coder typically does wrong in this situation.\n"
    "- One to two sentences, max 400 characters.\n"
    "- Be specific to the project. Reference actual files, functionality, and "
    "the ticket goal. Generic messages are useless.\n"
    "- No markdown formatting.\n"
    "- Vary your style. Sometimes lead with the consequence, sometimes with "
    "the contrast, sometimes with what was prevented.\n"
    "- Real-world consequences to reference when relevant: exposed API keys "
    "causing financial loss, SQL injection enabling data theft, missing auth "
    "allowing account takeover, fake tests giving false confidence, "
    "hallucinated imports crashing on deploy.\n"
    "- The user is waiting for a governed build. These messages should make "
    "the wait feel worth it."
)


def _generate_progress_message(
    coder_config,
    repo_path: Path,
    prompt: str,
) -> str:
    """Generate a contextual progress message via LLM.

    Returns empty string on any failure — never blocks the workflow.
    CLI backends are skipped entirely: spawning a full agent process
    for a cosmetic message is too expensive and wastes API quota.
    """
    if coder_config.backend in ("codex-cli", "cursor-cli"):
        return ""
    try:
        from saturnday.coder_adapter import call_coder
        messages = [
            {"role": "system", "content": _PROGRESS_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ]
        response = call_coder(coder_config, messages, repo_path)
        return response.strip()[:500]
    except Exception as exc:
        logger.debug("Progress message generation failed: %s", exc)
        return ""


def _detect_project_languages(repo_path: Path) -> frozenset[str]:
    """Detect programming languages in the project from file extensions.

    Returns a frozenset of language names (e.g. ``{"python", "typescript"}``).
    Used to filter language-specific standards.
    """
    langs: set[str] = set()
    _LANG_MAP = {
        ".py": "python", ".pyi": "python",
        ".ts": "typescript", ".tsx": "typescript",
        ".js": "javascript", ".jsx": "javascript",
        ".mjs": "javascript", ".cjs": "javascript",
        ".sh": "shell", ".bash": "shell",
    }
    try:
        result = subprocess.run(
            ["git", "ls-files"],
            cwd=str(repo_path),
            capture_output=True, text=True, check=False, timeout=5,
        )
        if result.returncode == 0:
            for f in result.stdout.strip().splitlines():
                ext = Path(f).suffix.lower()
                if ext in _LANG_MAP:
                    langs.add(_LANG_MAP[ext])
    except Exception:
        pass
    # Also check for pyproject.toml, package.json, tsconfig.json
    if (repo_path / "pyproject.toml").is_file() or (repo_path / "setup.py").is_file():
        langs.add("python")
    if (repo_path / "package.json").is_file():
        langs.add("javascript")
    if (repo_path / "tsconfig.json").is_file():
        langs.add("typescript")
    logger.debug("Detected project languages: %s", langs)
    return frozenset(langs)


def _list_repo_files(repo_path: Path, limit: int = 50) -> list[str]:
    """List repo files via git ls-files or os.walk fallback.

    Args:
        repo_path: Path to the repository root.
        limit: Maximum number of file paths to return.

    Returns:
        List of relative file path strings, capped at ``limit``.
    """
    try:
        r = subprocess.run(
            ["git", "-C", str(repo_path), "ls-files"],
            capture_output=True, text=True, timeout=5,
        )
        if r.returncode == 0:
            files = [f for f in r.stdout.strip().split("\n") if f]
            return files[:limit]
    except (subprocess.SubprocessError, OSError):
        pass
    # Fallback: walk directory tree
    result: list[str] = []
    for root, _, files in os.walk(repo_path):
        for f in files:
            if len(result) >= limit:
                return result
            rel = os.path.relpath(os.path.join(root, f), repo_path)
            if not rel.startswith("."):
                result.append(rel)
    return result


def run_plan(
    plan_path: str | Path,
    repo_path: str | Path,
    coder_config: CoderConfig,
    standards_dir: str | Path,
    output_dir: str | Path | None = None,
    skip_tickets: frozenset[str] | None = None,
    auto_repair: bool = False,
    lessons_db: str | Path | None = None,
    progress_callback: Callable[[str, str, int, str], None] | None = None,
    role_passes: bool = True,
) -> RunResult:
    """Execute a project plan end to end.

    Args:
        plan_path: Path to the plan JSON file.
        repo_path: Path to the target repository.
        coder_config: Backend configuration for the AI coder.
        standards_dir: Path to the engineering standards directory.
        output_dir: Directory for evidence output (default: ``<repo>/.saturnday/``).
        skip_tickets: Ticket IDs to treat as pre-completed (used by resume and
            rerun-failed).  Skipped tickets are added to the ``completed`` set
            so that downstream dependency resolution still works.
        auto_repair: If ``True``, attempt one repair pass after all retries
            for a ticket are exhausted.  The repair reuses the final governance
            findings as context for one additional coder attempt, then
            re-runs governance.  If that attempt passes, the ticket is
            committed as PASS.  No effect when a ticket passes normally.
        lessons_db: Path to the SQLite lessons database.  When provided,
            lessons from past failures are loaded and injected into the
            coder prompt before each ticket, and new lessons are recorded
            when a ticket exhausts all retries.  When ``None`` (the default),
            the lessons subsystem is not activated.
        progress_callback: Optional callable invoked at each ticket state
            transition.  Signature:
            ``(ticket_id: str, phase_name: str, attempt: int, status: str) -> None``
            where ``status`` is one of ``RUNNING``, ``PASS``, ``FAIL``,
            ``SKIP``, ``RETRY``.  ``attempt`` is 0 for the initial
            RUNNING/SKIP notification and the attempt number (1-based) for
            final dispositions.
        role_passes: If ``True`` and ``output_dir`` is set, run a DoD
            evaluation pass and an evidence-gate pass after the run
            completes.  Results are written as ``role-pass-dod.json`` and
            ``role-pass-evidence-gate.json`` inside ``output_dir``.
            Failures are logged as warnings and never raise.

    Returns:
        A ``RunResult`` summarizing the full execution.
    """
    from saturnday.plan_parser import load_plan

    repo_path = Path(repo_path).resolve()
    standards_dir = Path(standards_dir).resolve()
    plan = load_plan(plan_path)

    if output_dir is None:
        # Evidence goes INSIDE the repo under .saturnday/run/ — never outside.
        # Previously used repo_path.parent which caused cross-project collisions
        # when different projects generated the same project_id.
        output_dir = repo_path / ".saturnday" / "run"
    else:
        output_dir = Path(output_dir).resolve()

    # Write .gitignore to the repo before first ticket (not auto-committed)
    _ensure_gitignore(repo_path)

    # Create project venv if none exists — isolates pip install from system python
    _ensure_project_venv(repo_path)

    # Load or initialize project state
    state = load_state(repo_path) or ProjectState(project_id=plan.project_id)
    state.project_id = plan.project_id

    # Detect project languages for language-aware standards loading
    _project_langs = _detect_project_languages(Path(repo_path))

    # Build system prompt once (cached, language-filtered)
    system_prompt = build_system_prompt(str(standards_dir), project_languages=_project_langs)

    # For CLI backends: write full standards to .saturnday/standards.md and
    # return a compact prompt that references the file.  API backends keep the
    # full inline prompt unchanged.
    if is_cli_backend(coder_config):
        from saturnday.context_assembler import write_standards_file
        _sd = repo_path / ".saturnday"
        _sd.mkdir(parents=True, exist_ok=True)
        system_prompt = write_standards_file(
            str(standards_dir),
            _sd / "standards.md",
            project_languages=_project_langs,
        )

    # Create run ledger from plan fields
    all_ticket_ids = tuple(t.ticket_id for t in plan.tickets)
    ledger = create_ledger_from_plan(
        definition_of_done=plan.definition_of_done,
        stop_conditions=plan.stop_conditions,
        max_project_tickets=plan.max_project_tickets,
        phases=plan.phases,
        ticket_ids=all_ticket_ids,
    )

    # Backup prior ledger and auto-resume if same plan
    if output_dir:
        _prior_ledger = Path(output_dir) / "evidence" / "run" / "ledger.json"
        if _prior_ledger.is_file():
            try:
                import json as _json_lr
                _prior_data = _json_lr.loads(_prior_ledger.read_text(encoding="utf-8"))

                # Auto-resume: skip tickets that already passed in the prior run
                if skip_tickets is None:
                    _prior_passed = frozenset(
                        tid for tid, ts in _prior_data.get("ticket_statuses", {}).items()
                        if ts.get("disposition") in ("PASS", "CODED_UNGOVERNED")
                    )
                    if _prior_passed:
                        skip_tickets = _prior_passed
                        logger.info(
                            "Auto-resume: %d tickets already completed, skipping them",
                            len(_prior_passed),
                        )

                # Backup the prior ledger
                _backup = _prior_ledger.with_suffix(".json.bak")
                _prior_ledger.rename(_backup)
                logger.info("Backed up prior ledger to %s", _backup)
            except Exception:
                pass

    # Write run-level metadata before first ticket executes
    _auth_mode = detect_auth_mode(coder_config)
    _backend_caps = capability_matrix(coder_config.backend)
    write_run_metadata(
        coder_config,
        plan_path,
        output_dir,
        auth_mode=_auth_mode,
        backend_capabilities=_backend_caps,
    )

    # Pre-run: repo analyst pass
    if role_passes and output_dir:
        try:
            from saturnday.role_modes import invoke_role
            import json as _json

            logger.info("--- stage: repo analysis ---")
            repo_files = _list_repo_files(Path(repo_path), limit=50)
            analyst_task = (
                f"Repository: {repo_path}\n"
                f"Project: {plan.project_id}\n"
                f"Tickets: {len(plan.tickets)}\n"
                f"Files ({len(repo_files)}):\n"
                + "\n".join(f"  {f}" for f in repo_files)
                + "\n\nAnalyse this repository and produce a concise summary covering:\n"
                  "1. Architecture and module boundaries (key packages, layers, entry points)\n"
                  "2. Local code style and idioms (naming conventions, patterns in use)\n"
                  "3. Existing test patterns (test framework, fixture approach, coverage style)\n"
                  "4. Dependencies already in use (runtime and dev deps, versions where notable)\n"
                  "This output will guide the coder for all subsequent tickets."
            )
            analyst_result = invoke_role(
                "repo_analyst",
                analyst_task,
                coder_config=coder_config,
                repo_path=Path(repo_path),
            )
            analyst_path = Path(output_dir) / "role-pass-repo-analyst.json"
            analyst_path.parent.mkdir(parents=True, exist_ok=True)
            analyst_path.write_text(
                _json.dumps(
                    {
                        "role": analyst_result.role,
                        "success": analyst_result.success,
                        "output": analyst_result.output,
                        "error": analyst_result.error,
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Pre-run repo_analyst pass failed: %s", exc)

    # Open the lessons DB if opt-in was requested
    _lessons_conn: sqlite3.Connection | None = None
    if lessons_db is not None:
        try:
            _lessons_conn = init_db(Path(lessons_db))
            logger.info("Lessons DB active: %s", lessons_db)
        except Exception as _exc:  # pragma: no cover
            logger.warning(
                "Failed to open lessons DB %s: %s — continuing without lessons",
                lessons_db, _exc,
            )
            _lessons_conn = None

    # Contract verification pre-flight
    try:
        from saturnday.run.contract_checker import extract_contracts, verify_contracts
        all_criteria: tuple[str, ...] = tuple(
            c for t in plan.tickets for c in t.acceptance_criteria
        )
        if all_criteria:
            contracts = extract_contracts(all_criteria)
            if contracts:
                results = verify_contracts(contracts, repo_path)
                failed_results = [r for r in results if not r.verified]
                if failed_results:
                    logger.warning(
                        "Contract verification found %d issue(s) before execution:",
                        len(failed_results),
                    )
                    for r in failed_results:
                        logger.warning("  - %s", r.detail)
                else:
                    logger.info(
                        "Contract pre-flight: %d contract(s) verified OK", len(results),
                    )
    except ImportError:
        pass
    except Exception as exc:
        logger.warning("Contract verification failed: %s", exc)

    completed: set[str] = set()
    ticket_results: list[TicketResult] = []

    logger.info(
        "Starting plan execution: %s (%d tickets)",
        plan.project_id, len(plan.tickets),
    )

    # Set up progress log file for live monitoring
    global _progress_log_path
    _progress_log_path = Path(repo_path) / "saturnday-progress.log"
    try:
        if _progress_log_path.exists():
            with open(_progress_log_path, "a", encoding="utf-8") as _pf:
                _pf.write(f"\n{'=' * 60}\n")
                _pf.write(f"Resumed: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}\n")
                _pf.write(f"{'=' * 60}\n\n")
        else:
            _progress_log_path.write_text(
                f"Saturnday governed build: {plan.project_id}\n"
                f"Tickets: {len(plan.tickets)}\n"
                f"Started: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}\n"
                f"{'=' * 60}\n\n",
                encoding="utf-8",
            )
        logger.info(
            "\n"
            "  To see live governance insights, open another terminal and run:\n"
            "    cd %s && tail -f saturnday-progress.log\n"
            "\n"
            "  This shows what an AI coder without Saturnday would have done wrong.\n",
            repo_path,
        )
    except Exception as _log_exc:
        logger.warning("Failed to set up progress log: %s", _log_exc)
        _progress_log_path = None  # type: ignore[assignment]

    # Progress message: run start
    _start_msg = _generate_progress_message(
        coder_config, Path(repo_path),
        f"Project '{plan.project_id}' starting with {len(plan.tickets)} tickets. "
        f"Brief: {plan.notes[:200] if plan.notes else 'not provided'}. "
        f"An AI coder without Saturnday would build this in one shot with no checks. "
        f"Write one sentence about what typically goes wrong when this type of project is built ungoverned.",
    )
    if _start_msg:
        _log_progress(_start_msg)

    for ticket in plan.tickets:
        # Pre-completed skip (resume / rerun-failed native filtering)
        if skip_tickets and ticket.ticket_id in skip_tickets:
            completed.add(ticket.ticket_id)
            logger.info(
                "Skipping %s (pre-completed via resume filter)", ticket.ticket_id,
            )
            continue

        # Ledger-level skip check (max tickets, prior stop condition)
        skip, skip_reason = ledger.should_skip_ticket(ticket.ticket_id)
        if skip:
            logger.info("Skipping %s: %s", ticket.ticket_id, skip_reason)
            ledger.record_ticket_result(ticket.ticket_id, "SKIP")
            ticket_results.append(TicketResult(
                ticket_id=ticket.ticket_id,
                disposition="SKIP",
                error=skip_reason,
            ))
            if progress_callback:
                progress_callback(ticket.ticket_id, "", 0, "SKIP")
            write_ledger_snapshot(ledger, output_dir)
            continue

        # Check dependencies
        unmet = [d for d in ticket.dependencies if d not in completed]
        if unmet:
            logger.warning(
                "Skipping %s: unmet dependencies %s",
                ticket.ticket_id, unmet,
            )
            ledger.record_ticket_result(ticket.ticket_id, "SKIP")
            ticket_results.append(TicketResult(
                ticket_id=ticket.ticket_id,
                disposition="SKIP",
                error=f"Unmet dependencies: {', '.join(unmet)}",
            ))
            if progress_callback:
                progress_callback(ticket.ticket_id, "", 0, "SKIP")
            write_ledger_snapshot(ledger, output_dir)
            continue

        # Analyze ticket complexity and split if needed
        from saturnday.ticket_splitter import analyze_and_split
        sub_tickets = analyze_and_split(
            ticket, coder_config, repo_path, plan.notes,
        )

        all_subs_passed = True
        for sub in sub_tickets:
            # Resolve phase name for progress reporting
            _phase_name = ""
            for _phase in plan.phases:
                if sub.ticket_id in _phase.ticket_ids:
                    _phase_name = _phase.name
                    break

            # Ledger-level skip check for sub-tickets
            skip, skip_reason = ledger.should_skip_ticket(sub.ticket_id)
            if skip:
                logger.info("Skipping %s: %s", sub.ticket_id, skip_reason)
                ledger.record_ticket_result(sub.ticket_id, "SKIP")
                ticket_results.append(TicketResult(
                    ticket_id=sub.ticket_id,
                    disposition="SKIP",
                    error=skip_reason,
                ))
                if progress_callback:
                    progress_callback(sub.ticket_id, _phase_name, 0, "SKIP")
                all_subs_passed = False
                write_ledger_snapshot(ledger, output_dir)
                continue

            # Check sub-ticket dependencies (prior subs in this split)
            sub_unmet = [d for d in sub.dependencies if d not in completed]
            if sub_unmet:
                logger.warning("Skipping %s: unmet deps %s", sub.ticket_id, sub_unmet)
                ledger.record_ticket_result(sub.ticket_id, "SKIP")
                ticket_results.append(TicketResult(
                    ticket_id=sub.ticket_id,
                    disposition="SKIP",
                    error=f"Unmet dependencies: {', '.join(sub_unmet)}",
                ))
                if progress_callback:
                    progress_callback(sub.ticket_id, _phase_name, 0, "SKIP")
                all_subs_passed = False
                write_ledger_snapshot(ledger, output_dir)
                continue

            if progress_callback:
                progress_callback(sub.ticket_id, _phase_name, 0, "RUNNING")

            try:
                result = _run_ticket_with_retries(
                    ticket=sub,
                    repo_path=repo_path,
                    coder_config=coder_config,
                    system_prompt=system_prompt,
                    state=state,
                    plan_notes=plan.notes,
                    output_dir=output_dir,
                    max_retries=plan.default_retry_limit,
                    auto_repair=auto_repair,
                    lessons_conn=_lessons_conn,
                    project_id=plan.project_id,
                )
            except KeyboardInterrupt:
                logger.info("Run interrupted by user (Ctrl+C) during %s", sub.ticket_id)
                _log_progress(f"✗ Run interrupted by user during {sub.ticket_id}")
                _git_reset_changes(repo_path)
                write_ledger_snapshot(ledger, output_dir)
                # Save partial summary so progress isn't lost
                _int_passed = sum(1 for r in ticket_results if r.disposition == "PASS")
                _int_failed = sum(1 for r in ticket_results if r.disposition == "FAIL")
                _int_skipped = sum(1 for r in ticket_results if r.disposition == "SKIP")
                _int_ungoverned = sum(1 for r in ticket_results if r.disposition == "CODED_UNGOVERNED")
                try:
                    write_run_summary(RunResult(
                        project_id=plan.project_id,
                        total_tickets=len(ticket_results),
                        passed=_int_passed, failed=_int_failed,
                        skipped=_int_skipped, coded_ungoverned=_int_ungoverned,
                        ticket_results=tuple(ticket_results),
                        stop_reason="interrupted",
                    ), output_dir)
                except Exception:
                    pass
                raise

            ticket_results.append(result)

            # Record in ledger and persist
            ledger.record_ticket_result(
                sub.ticket_id,
                result.disposition,
                failure_category=result.failure_category,
            )
            ledger.update_phase_status(sub.ticket_id)
            write_ledger_snapshot(ledger, output_dir)

            # Write partial run summary after every ticket — if the process
            # crashes, the summary reflects all completed work up to this point.
            _partial_passed = sum(1 for r in ticket_results if r.disposition == "PASS")
            _partial_failed = sum(1 for r in ticket_results if r.disposition == "FAIL")
            _partial_skipped = sum(1 for r in ticket_results if r.disposition == "SKIP")
            _partial_ungoverned = sum(1 for r in ticket_results if r.disposition == "CODED_UNGOVERNED")
            _partial_result = RunResult(
                project_id=plan.project_id,
                total_tickets=len(ticket_results),
                passed=_partial_passed,
                failed=_partial_failed,
                skipped=_partial_skipped,
                coded_ungoverned=_partial_ungoverned,
                ticket_results=tuple(ticket_results),
            )
            try:
                write_run_summary(_partial_result, output_dir)
            except Exception:
                logger.debug("Partial run summary write failed")

            if progress_callback:
                progress_callback(sub.ticket_id, _phase_name, result.attempts, result.disposition)

            if result.disposition == "PASS":
                completed.add(sub.ticket_id)
                state = update_state(
                    state, sub.ticket_id, list(result.changed_files), repo_path,
                )
                save_state(state, repo_path)
                logger.info("Ticket %s PASSED", sub.ticket_id)
                # Progress message on first pass and every 2nd pass after
                _pass_count = sum(1 for _r in ticket_results if _r.disposition == "PASS") + 1
                if _pass_count == 1 or _pass_count % 2 == 0:
                    _pass_msg = _generate_progress_message(
                        coder_config, Path(repo_path),
                        f"Ticket {sub.ticket_id} passed governance. "
                        f"Goal: {sub.goal[:150] if sub.goal else 'N/A'}. "
                        f"Files: {', '.join(result.changed_files[:5])}. "
                        f"Project brief: {plan.notes[:100] if plan.notes else 'N/A'}. "
                        f"Write one sentence starting with 'An AI coder without Saturnday would have...' "
                        f"explaining what typically goes wrong with this type of code when ungoverned.",
                    )
                    if _pass_msg:
                        _log_progress(_pass_msg)
            else:
                logger.warning(
                    "Ticket %s %s: %s",
                    sub.ticket_id, result.disposition, result.error,
                )
                all_subs_passed = False

            # Check stop conditions after each ticket
            should_stop, stop_reason = ledger.check_stop_conditions(
                ticket_id=sub.ticket_id,
            )
            if should_stop:
                logger.warning("Stopping run: %s", stop_reason)
                write_ledger_snapshot(ledger, output_dir)
                break

        # Break outer loop if ledger says stop
        if ledger.stopped:
            break

        # Mark the original ticket as completed if all subs passed
        if all_subs_passed:
            completed.add(ticket.ticket_id)
            if len(sub_tickets) > 1:
                logger.info(
                    "Ticket %s PASSED (split into %d sub-tickets, all passed)",
                    ticket.ticket_id, len(sub_tickets),
                )

    # Auto-repair failed and ungoverned tickets before DoD evaluation
    repair_candidates = sum(1 for r in ticket_results if r.disposition in ("FAIL", "CODED_UNGOVERNED"))
    if repair_candidates > 0:
        logger.info("--- stage: auto-repair %d ticket(s) (failed + ungoverned) ---", repair_candidates)
        try:
            from saturnday.interactive import _scan_for_repair
            from saturnday.repair.repair_tickets import generate_repair_tickets
            from saturnday.repair.repair_runner import run_repair_batch

            findings, _ = _scan_for_repair(Path(repo_path))
            if findings:
                # Filter out policy exemptions
                policy_path = Path(repo_path) / ".saturnday-policy.yaml"
                exempt_kinds: set[str] = set()
                if policy_path.is_file():
                    try:
                        import yaml
                        pd = yaml.safe_load(policy_path.read_text(encoding="utf-8"))
                        exempt_kinds = set(pd.get("expected_findings", []))
                    except Exception:
                        pass
                _ENV_KINDS = {"declared_not_installed", "package_not_importable"}
                code_findings = [
                    f for f in findings
                    if f.kind not in _ENV_KINDS and f.kind not in exempt_kinds
                ]
                if code_findings:
                    repair_tickets = generate_repair_tickets(code_findings)
                    logger.info("Auto-repair: %d tickets from %d findings", len(repair_tickets), len(code_findings))

                    cli_mode = is_cli_backend(coder_config)
                    def _auto_repair_coder_fn(prompt: str, file_path: str, rp: Path) -> str:
                        return call_coder(coder_config, [
                            {"role": "user", "content": f"Fix this issue in {file_path}:\n{prompt}\nEdit the file directly."}
                        ], rp, agent_mode=True if cli_mode else False)

                    def _auto_repair_scan_fn(path: Path) -> list:
                        f2, _ = _scan_for_repair(path)
                        return f2

                    repair_result = run_repair_batch(
                        repair_tickets, Path(repo_path), _auto_repair_coder_fn,
                        scan_fn=_auto_repair_scan_fn,
                        cli_mode=cli_mode,
                    )
                    logger.info(
                        "Auto-repair: fixed=%d partial=%d failed=%d",
                        repair_result.fixed, repair_result.partial, repair_result.failed,
                    )
        except Exception as exc:
            logger.warning("Auto-repair failed: %s", exc)

    # Evaluate definition of done
    dod_met = ledger.evaluate_definition_of_done()

    # Compute totals — use len(ticket_results) as denominator so sub-tickets
    # are counted consistently in both numerator and denominator.
    passed = sum(1 for r in ticket_results if r.disposition == "PASS")
    failed = sum(1 for r in ticket_results if r.disposition == "FAIL")
    skipped = sum(1 for r in ticket_results if r.disposition == "SKIP")
    coded_ungoverned = sum(1 for r in ticket_results if r.disposition == "CODED_UNGOVERNED")
    actual_total = len(ticket_results)

    run_result = RunResult(
        project_id=plan.project_id,
        total_tickets=actual_total,
        passed=passed,
        failed=failed,
        skipped=skipped,
        coded_ungoverned=coded_ungoverned,
        ticket_results=tuple(ticket_results),
        definition_of_done_met=dod_met,
        stop_reason=ledger.stop_reason,
    )

    write_phase_summary(ledger, output_dir)
    write_run_summary(run_result, output_dir)
    write_ledger_snapshot(ledger, output_dir)

    analytics = compute_run_analytics(run_result)
    analytics["backend"] = coder_config.backend
    write_analytics(analytics, output_dir)
    logger.info(
        "RUN ANALYTICS | acceptance_rate=%.2f | avg_retries=%.2f | quality=%s | dod_met=%s",
        analytics["acceptance_rate"],
        analytics["avg_retries"],
        analytics["senior_quality_verdict"]["quality_level"],
        analytics["definition_of_done_met"],
    )

    logger.info(
        "Plan complete: %d passed, %d failed, %d skipped | DoD met: %s | stop_reason: %s",
        passed, failed, skipped, dod_met, ledger.stop_reason or "none",
    )

    # Progress message: run complete
    _finding_kinds_seen = set()
    for _tr in ticket_results:
        for _f in (_tr.governance_findings or ()):
            _finding_kinds_seen.add(_f.get("kind", _f.get("message", "")))
    _complete_msg = _generate_progress_message(
        coder_config, Path(repo_path),
        f"Project '{plan.project_id}' complete. {passed} passed governance, "
        f"{coded_ungoverned} need review, {failed} failed. "
        f"Brief: {plan.notes[:150] if plan.notes else 'N/A'}. "
        f"Governance caught these kinds: {', '.join(sorted(_finding_kinds_seen)) if _finding_kinds_seen else 'none'}. "
        f"Write one sentence about what this project would look like if an AI coder had built it without any governance.",
    )
    if _complete_msg:
        _log_progress(_complete_msg)

    if role_passes and output_dir:
        try:
            from saturnday.role_modes import run_dod_check, invoke_role
            import json as _json

            logger.info("Running post-run role passes...")

            # DoD pass
            dod_result = run_dod_check(
                plan_path=Path(plan_path),
                evidence_dir=Path(output_dir),
                repo_path=Path(repo_path),
                coder_config=coder_config,
            )
            dod_path = Path(output_dir) / "role-pass-dod.json"
            dod_path.write_text(
                _json.dumps(
                    {
                        "role": dod_result.role,
                        "success": dod_result.success,
                        "output": dod_result.output,
                        "error": dod_result.error,
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )

            # If LLM says DOD_MET or DOD_PARTIAL, upgrade the mechanical
            # assessment.  DOD_PARTIAL means functional goals are met even
            # though a ticket failed (e.g. T001 failed but T002 solved the
            # same problem).  The mechanical gate is too blunt for this.
            from saturnday.role_modes import extract_classification
            dod_classification = extract_classification(
                dod_result.output,
                ["DOD_MET", "DOD_PARTIAL", "DOD_NOT_MET", "DOD_BLOCKED_BY_MISSING_EVIDENCE"],
            )
            if dod_classification in ("DOD_MET", "DOD_PARTIAL") and not dod_met:
                logger.info(
                    "LLM DoD says %s — upgrading mechanical gate (was NOT MET)",
                    dod_classification,
                )
                dod_met = True
                from dataclasses import replace as _replace
                run_result = _replace(run_result, definition_of_done_met=True)
                write_run_summary(run_result, output_dir)

            # DoD enforcement — only trigger repair for DOD_NOT_MET.
            # DOD_PARTIAL means the functional goals are met but a ticket
            # failed (e.g. T001 failed, T002 solved same problem).  Repairing
            # in that case chases governance false positives like blast_radius.
            if dod_classification == "DOD_NOT_MET":
                logger.info("DoD is %s — triggering repair to address gaps", dod_classification)
                try:
                    from saturnday.interactive import _scan_for_repair
                    from saturnday.repair.repair_tickets import generate_repair_tickets
                    from saturnday.repair.repair_runner import run_repair_batch

                    dod_findings, _ = _scan_for_repair(Path(repo_path))
                    if dod_findings:
                        _ENV_KINDS_DOD = {"declared_not_installed", "package_not_importable"}
                        _BLAST_KINDS = {"excessive_blast_radius"}
                        dod_code_findings = [
                            f for f in dod_findings
                            if f.kind not in _ENV_KINDS_DOD and f.kind not in _BLAST_KINDS
                        ]
                        if dod_code_findings:
                            dod_repair_tickets = generate_repair_tickets(dod_code_findings)
                            logger.info("DoD repair: %d tickets from %d findings", len(dod_repair_tickets), len(dod_code_findings))
                            cli_mode_dod = is_cli_backend(coder_config)
                            def _dod_repair_fn(prompt, file_path, rp):
                                return call_coder(coder_config, [
                                    {"role": "user", "content": f"Fix this issue in {file_path}:\n{prompt}\nFollow governance rules. Edit directly."}
                                ], rp, agent_mode=True if cli_mode_dod else False)
                            def _dod_scan_fn(path):
                                f2, _ = _scan_for_repair(path)
                                return f2
                            dod_repair_result = run_repair_batch(
                                dod_repair_tickets, Path(repo_path), _dod_repair_fn,
                                scan_fn=_dod_scan_fn, cli_mode=cli_mode_dod,
                            )
                            logger.info("DoD repair: fixed=%d failed=%d", dod_repair_result.fixed, dod_repair_result.failed)
                except Exception as exc:
                    logger.warning("DoD enforcement repair failed: %s", exc)
            elif dod_classification and dod_classification != "DOD_MET":
                logger.info("DoD is %s — not triggering repair (functional goals likely met)", dod_classification)

            # Evidence gate pass
            evidence_files = [
                str(p.relative_to(output_dir))
                for p in Path(output_dir).rglob("*.json")
            ]
            eg_task = (
                f"Evidence directory: {output_dir}\n"
                f"Files present: {', '.join(evidence_files[:20])}\n"
                f"Run passed: {run_result.passed},"
                f" failed: {run_result.failed},"
                f" skipped: {run_result.skipped}\n"
                f"DoD met: {run_result.definition_of_done_met}\n\n"
                f"Assess whether evidence is sufficient for this run. "
                f"Also check: do README.md and SKILL.md accurately describe what the code actually does? "
                f"Flag any mismatch between documented behaviour and actual code behaviour."
            )
            eg_result = invoke_role(
                "evidence_gate",
                eg_task,
                coder_config=coder_config,
                repo_path=Path(repo_path),
            )
            eg_path = Path(output_dir) / "role-pass-evidence-gate.json"
            eg_path.write_text(
                _json.dumps(
                    {
                        "role": eg_result.role,
                        "success": eg_result.success,
                        "output": eg_result.output,
                        "error": eg_result.error,
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )

        except Exception as exc:  # noqa: BLE001
            logger.warning("Post-run role passes failed: %s", exc)

    # Simplifier pass
    try:
        if is_cli_backend(coder_config):
            logger.info("--- stage: simplifier pass ---")
            from saturnday.standards_digest import STANDARDS_DIGEST
            simplify_prompt = (
                "You are a senior code reviewer. Review all changes made in this session.\n\n"
                f"## {STANDARDS_DIGEST}\n\n"
                "CRITICAL CONSTRAINTS — read these first:\n"
                "- NEVER delete entire files. Only edit code WITHIN existing source files.\n"
                "- NEVER touch: README.md, LICENSE, .md files, .yaml/.yml files, "
                ".json config files, log files, .gitignore, Dockerfile, CI configs.\n"
                "- NEVER delete test files. You may simplify test code but not remove test files.\n"
                "- Only modify .py, .js, .ts, .jsx, .tsx, .sh source files.\n\n"
                "SIMPLIFICATION (within source files only):\n"
                "1. Inline helper functions used only once.\n"
                "2. Remove comments that describe WHAT (noise). Keep only WHY comments.\n"
                "3. Inline premature abstractions.\n"
                "4. Prefer small edits over full rewrites.\n\n"
                "CONSTRAINT COMPLIANCE:\n"
                "5. Are tests distributed UNEVENLY? (many for risky logic, few for trivial) "
                "If tests are evenly spread, simplify the trivial ones.\n"
                "6. Were unnecessary dependencies, classes, or abstractions introduced? "
                "Simplify them within their files.\n"
                "7. Do trade-off comments exist for non-obvious design choices? "
                "If missing, add a brief WHY comment at the key decision point.\n\n"
                "Make the code simpler and more senior. Only inline or tighten within files. "
                "Add brief WHY comments at key design decisions if missing."
            )
            call_coder(coder_config, [
                {"role": "user", "content": simplify_prompt}
            ], Path(repo_path), agent_mode=True)
            logger.info("Simplifier pass complete.")
    except Exception as exc:
        logger.warning("Simplifier pass failed: %s", exc)

    # Post-completion governance re-scan
    post_pack = None
    try:
        from saturnday.governance import run_full_repo_review
        logger.info("--- stage: final governance scan ---")
        post_pack, _ = run_full_repo_review(Path(repo_path))
        logger.info("Final governance: %s", post_pack.disposition)
    except Exception as exc:
        logger.warning("Post-completion governance scan failed: %s", exc)

    # Generate run report
    try:
        from saturnday.reporting import generate_run_report
        import json as _json_report
        plan_data = _json_report.loads(Path(plan_path).read_text(encoding="utf-8"))
        report_path = generate_run_report(
            result=run_result,
            plan_data=plan_data,
            post_pack=post_pack,
            evidence_dir=Path(output_dir),
            repo_path=Path(repo_path),
        )
        logger.info("Run report: %s", report_path)
    except Exception as exc:
        logger.warning("Failed to generate run report: %s", exc)

    # Generate review report and fix prompts for ungoverned tickets
    if coded_ungoverned > 0 and output_dir:
        try:
            from saturnday.reporting import generate_review_report, generate_fix_prompts
            review_path = generate_review_report(
                ticket_results=run_result.ticket_results,
                evidence_dir=Path(output_dir),
                dod_met=run_result.definition_of_done_met,
            )
            if review_path:
                logger.info("Review report: %s", review_path)
            prompt_paths = generate_fix_prompts(
                ticket_results=run_result.ticket_results,
                evidence_dir=Path(output_dir),
            )
            if prompt_paths:
                logger.info("Fix prompts: %s", prompt_paths[0].parent)
        except Exception as exc:
            logger.warning("Failed to generate review report/prompts: %s", exc)

    return run_result


def _run_ticket_with_retries(
    ticket: TicketSpec,
    repo_path: Path,
    coder_config: CoderConfig,
    system_prompt: str,
    state: ProjectState,
    plan_notes: str,
    output_dir: Path,
    max_retries: int = MAX_REPAIR_ATTEMPTS,
    auto_repair: bool = False,
    lessons_conn: "sqlite3.Connection | None" = None,
    project_id: str = "",
) -> TicketResult:
    """Execute a single ticket with repair retries.

    Args:
        ticket: The ticket specification to execute.
        repo_path: Path to the target repository.
        coder_config: Backend configuration for the AI coder.
        system_prompt: Pre-built system prompt for the coder.
        state: Current project state.
        plan_notes: Free-form notes injected into every coder prompt.
        output_dir: Directory for evidence output.
        max_retries: Maximum number of repair attempts (default: ``MAX_REPAIR_ATTEMPTS``).
            Pass ``plan.default_retry_limit`` to respect per-plan configuration.
        auto_repair: If ``True``, attempt one additional repair pass after all
            retries are exhausted before returning FAIL.  The last governance
            findings are used as repair context.
        lessons_conn: Open SQLite connection from :func:`init_db`, or ``None``
            to skip the lessons subsystem.  When provided, past failure lessons
            are prepended to the coder prompt before the first attempt, and a
            new lesson is recorded if the ticket exhausts all retries.
        project_id: Project identifier used as the lessons deduplication key.
            Ignored when ``lessons_conn`` is ``None``.
    """
    repair_context: str | None = None
    # Per-ticket observability: track gate outcomes across attempts
    _last_governance: str = ""
    _last_post_check: str = ""
    _post_checks_fired: list[str] = []

    # Load lessons for this project and inject into plan_notes for the first attempt
    _lessons_prefix = ""
    if lessons_conn is not None:
        try:
            _past_lessons = load_lessons(lessons_conn, project_id=project_id, min_confidence=1)
            _lessons_prefix = format_lessons_for_prompt(_past_lessons)
            if _lessons_prefix:
                logger.debug(
                    "Injecting %d lesson(s) into coder prompt for %s",
                    len(_past_lessons), ticket.ticket_id,
                )
        except Exception as _exc:  # pragma: no cover
            logger.warning("Failed to load lessons: %s — continuing without lesson context", _exc)
            _lessons_prefix = ""

    # Prepend lessons to plan_notes so they appear in every prompt
    _plan_notes_with_lessons = (
        f"{_lessons_prefix}\n\n{plan_notes}".strip() if _lessons_prefix else plan_notes
    )

    _log_progress(f"▶ {ticket.ticket_id}: {ticket.goal[:120] if ticket.goal else 'no goal'}")

    # Snapshot project-level checks BEFORE the coder runs.
    # Used for regression check: only block if this ticket made things worse.
    _pre_ticket_state = _snapshot_project_checks(repo_path)

    for attempt in range(1, max_retries + 2):
        logger.info(
            "Ticket %s attempt %d/%d",
            ticket.ticket_id, attempt, max_retries + 1,
        )

        try:
            response, changed_files = _execute_ticket(
                ticket=ticket,
                repo_path=repo_path,
                coder_config=coder_config,
                system_prompt=system_prompt,
                state=state,
                plan_notes=_plan_notes_with_lessons,
                repair_context=repair_context,
            )
        except CloudCoreError as exc:
            logger.error("Ticket %s attempt %d failed: %s", ticket.ticket_id, attempt, exc)
            write_ticket_evidence(
                TicketEvidence(
                    ticket_id=ticket.ticket_id,
                    attempt=attempt,
                    governance_evidence_path="",
                    error=str(exc),
                ),
                output_dir,
            )
            if attempt > max_retries:
                _log_ticket_summary(ticket.ticket_id, attempt, "ERROR", "", [], "FAIL")
                if auto_repair:
                    repair_result = _attempt_auto_repair(
                        ticket=ticket,
                        repo_path=repo_path,
                        coder_config=coder_config,
                        system_prompt=system_prompt,
                        state=state,
                        plan_notes=plan_notes,
                        output_dir=output_dir,
                        repair_context=f"Previous attempt error: {exc}",
                        attempt_number=attempt + 1,
                    )
                    if repair_result is not None:
                        return repair_result
                return TicketResult(
                    ticket_id=ticket.ticket_id,
                    disposition="FAIL",
                    attempts=attempt,
                    error=str(exc),
                )
            repair_context = f"Error: {exc}"
            continue

        # Stage ONLY the current ticket's changed files
        _git_add(repo_path, changed_files)

        # Auto-install deps if coder modified dependency files
        _auto_install_deps(repo_path, changed_files)

        # Run governance
        try:
            disposition, findings, gov_evidence_path = _run_governance(
                repo_path, run_mode=True, pre_ticket_state=_pre_ticket_state,
            )
            # Security triage: LLM-based false positive filtering
            try:
                from saturnday.security_triage import triage_security_findings
                findings = triage_security_findings(findings, repo_path, coder_config)
            except Exception as _triage_exc:
                logger.debug("Security triage skipped: %s", _triage_exc)
        except GovernanceError as exc:
            logger.error("Governance error for %s: %s", ticket.ticket_id, exc)
            _git_reset_changes(repo_path)
            write_ticket_evidence(
                TicketEvidence(
                    ticket_id=ticket.ticket_id,
                    attempt=attempt,
                    coder_response=response,
                    changed_files=changed_files,
                    governance_evidence_path="",
                    error=f"Governance error: {exc}",
                ),
                output_dir,
            )
            if attempt > max_retries:
                _log_ticket_summary(ticket.ticket_id, attempt, "ERROR", "", [], "FAIL")
                return TicketResult(
                    ticket_id=ticket.ticket_id,
                    disposition="FAIL",
                    attempts=attempt,
                    error=f"Governance error: {exc}",
                )
            repair_context = f"Governance error: {exc}"
            continue

        # Filter findings to only current ticket's files.
        # Pre-existing lint issues in previously committed files should not
        # block the current ticket.
        relevant_findings = _filter_findings_to_files(findings, changed_files)
        effective_disposition = disposition
        _last_governance = effective_disposition
        if disposition == "FAIL" and not relevant_findings:
            logger.info(
                "Ticket %s: governance FAIL but no findings in current ticket's files — treating as PASS",
                ticket.ticket_id,
            )
            effective_disposition = "PASS"

        # Record evidence
        write_ticket_evidence(
            TicketEvidence(
                ticket_id=ticket.ticket_id,
                attempt=attempt,
                coder_response=response,
                changed_files=changed_files,
                governance_disposition=effective_disposition,
                governance_findings=relevant_findings,
                governance_evidence_path=gov_evidence_path,
            ),
            output_dir,
        )

        if effective_disposition == "PASS":
            # Run post-governance senior-judgment checks
            post_findings = run_post_checks(repo_path, changed_files)
            _post_checks_fired = sorted({f.get("message", "").split(":")[0] for f in post_findings if f.get("message")})
            if post_findings:
                _last_post_check = "FAIL"
                logger.warning(
                    "Ticket %s: post-checks found %d issue(s)",
                    ticket.ticket_id, len(post_findings),
                )
                # Record evidence with post-check findings
                write_ticket_evidence(
                    TicketEvidence(
                        ticket_id=ticket.ticket_id,
                        attempt=attempt,
                        coder_response=response,
                        changed_files=changed_files,
                        governance_disposition="FAIL",
                        governance_findings=post_findings,
                        governance_evidence_path=gov_evidence_path,
                    ),
                    output_dir,
                )
                # Treat as FAIL — reset and retry (unless last attempt)
                if attempt > max_retries:
                    findings_text = _format_findings(post_findings)
                    _record_failure_lesson(
                        lessons_conn,
                        ticket_id=ticket.ticket_id,
                        project_id=project_id,
                        failure_type="post_check_fail",
                        rule=post_findings[0].get("message", "post_check_fail").split(":")[0] if post_findings else "post_check_fail",
                        description=findings_text[:500],
                    )
                    # Commit as ungoverned — code is still staged
                    _git_commit(
                        repo_path, ticket.ticket_id, changed_files,
                        suffix="[GOVERNANCE: review required]",
                    )
                    _log_ticket_summary(ticket.ticket_id, attempt, _last_governance, _last_post_check, _post_checks_fired, "CODED_UNGOVERNED")
                    return TicketResult(
                        ticket_id=ticket.ticket_id,
                        disposition="CODED_UNGOVERNED",
                        attempts=attempt,
                        changed_files=tuple(changed_files),
                        governance_disposition="FAIL",
                        governance_evidence_path=gov_evidence_path,
                        error=f"Post-checks failed after {attempt} attempts — committed for review.",
                        governance_findings=tuple(post_findings),
                    )
                _git_reset_changes(repo_path)
                repair_context = _format_findings(post_findings)
                continue

            _last_post_check = "PASS"

            # Semantic review: LLM checks code against ticket goal (WARNING only).
            # Runs after post-checks pass, before contract verification.
            # Never blocks, never resets git state, never triggers retry.
            try:
                from saturnday.role_modes import invoke_role as _invoke_role

                _review_parts = [
                    f"## Ticket Goal\n{ticket.goal}\n",
                    "## Acceptance Criteria\n"
                    + "\n".join(f"- {c}" for c in ticket.acceptance_criteria),
                    "\n## Changed Files",
                ]
                for _cf in changed_files:
                    _cf_path = repo_path / _cf
                    if _cf_path.is_file():
                        _file_content = _cf_path.read_text(
                            encoding="utf-8", errors="replace"
                        )[:3000]
                        _review_parts.append(
                            f"\n### {_cf}\n```\n{_file_content}\n```"
                        )
                _review_task = "\n".join(_review_parts)
                _review_result = _invoke_role(
                    "code_reviewer",
                    _review_task,
                    coder_config=coder_config,
                    repo_path=repo_path,
                )
                if _review_result.success and '"CONCERNS"' in _review_result.output:
                    logger.warning(
                        "Ticket %s: semantic review found concerns: %s",
                        ticket.ticket_id,
                        _review_result.output[:500],
                    )
                    # WARNING only — do NOT reset, retry, or alter disposition.
                    # Future: promote to blocking once false-positive rate is known.
            except Exception as _review_exc:  # noqa: BLE001
                logger.debug("Semantic review skipped: %s", _review_exc)

            # Contract verification: check acceptance criteria are satisfied
            # in the repo before committing.  Failures are treated the same as
            # post-check failures — reset and retry with context.
            contract_context = _check_contracts(ticket, repo_path)
            if contract_context:
                logger.warning(
                    "Ticket %s: contract verification failed",
                    ticket.ticket_id,
                )
                if attempt > max_retries:
                    # Commit as ungoverned — code was written and governance
                    # passed, only contract check failed. Don't lose the work.
                    _git_commit(
                        repo_path, ticket.ticket_id, changed_files,
                        suffix="[GOVERNANCE: review required — contract check failed]",
                    )
                    _log_ticket_summary(ticket.ticket_id, attempt, _last_governance, _last_post_check, _post_checks_fired, "CODED_UNGOVERNED")
                    return TicketResult(
                        ticket_id=ticket.ticket_id,
                        disposition="CODED_UNGOVERNED",
                        attempts=attempt,
                        changed_files=tuple(changed_files),
                        governance_disposition=effective_disposition,
                        governance_evidence_path=gov_evidence_path,
                        error=f"Contract check failed after {attempt} attempts — committed for review: {contract_context[:500]}",
                    )
                _git_reset_changes(repo_path)
                repair_context = contract_context
                continue

            # Execute verify_cmd if specified — the mechanical proof the ticket works
            if ticket.verify_cmd:
                verify_failure = _run_verify_cmd(ticket.verify_cmd, repo_path)
                if verify_failure:
                    logger.warning(
                        "Ticket %s: verify_cmd failed: %s",
                        ticket.ticket_id, verify_failure[:200],
                    )
                    if attempt > max_retries:
                        # Commit as ungoverned — code was written and governance
                        # passed, only verify_cmd failed.  Don't lose the work.
                        _git_commit(
                            repo_path, ticket.ticket_id, changed_files,
                            suffix="[GOVERNANCE: review required — verify_cmd failed]",
                        )
                        _log_ticket_summary(ticket.ticket_id, attempt, _last_governance, _last_post_check, _post_checks_fired, "CODED_UNGOVERNED")
                        return TicketResult(
                            ticket_id=ticket.ticket_id,
                            disposition="CODED_UNGOVERNED",
                            attempts=attempt,
                            changed_files=tuple(changed_files),
                            governance_disposition=effective_disposition,
                            governance_evidence_path=gov_evidence_path,
                            error=f"verify_cmd failed after {attempt} attempts — committed for review: {verify_failure[:500]}",
                        )
                    _git_reset_changes(repo_path)
                    repair_context = f"verify_cmd '{ticket.verify_cmd}' failed:\n{verify_failure}"
                    continue

            _log_ticket_summary(ticket.ticket_id, attempt, _last_governance, _last_post_check, _post_checks_fired, "PASS")
            _git_commit(repo_path, ticket.ticket_id, changed_files)
            return TicketResult(
                ticket_id=ticket.ticket_id,
                disposition="PASS",
                attempts=attempt,
                changed_files=tuple(changed_files),
                governance_disposition=effective_disposition,
                governance_evidence_path=gov_evidence_path,
            )

        # FAIL — check if this is the last attempt
        logger.warning(
            "Ticket %s governance FAIL (attempt %d)", ticket.ticket_id, attempt,
        )

        # Progress message: governance caught something
        _finding_kinds = sorted({f.get("kind", "") for f in relevant_findings if f.get("kind")})
        _why_parts = []
        try:
            from saturnday.remediation_guidance import get_guidance
            for _fk in _finding_kinds[:3]:
                _g = get_guidance(_fk)
                if _g:
                    _why_parts.append(f"{_fk}: {_g.why_it_matters[:80]}")
        except Exception:
            pass
        _retry_msg = _generate_progress_message(
            coder_config, Path(repo_path),
            f"Ticket {ticket.ticket_id} attempt {attempt}: governance caught {len(relevant_findings)} issue(s): "
            f"{', '.join(_finding_kinds[:5])}. "
            f"Goal: {ticket.goal[:100] if ticket.goal else 'N/A'}. "
            f"{'Why it matters: ' + '; '.join(_why_parts) + '. ' if _why_parts else ''}"
            f"Write one sentence: what real-world consequence would this cause if an AI coder shipped this without governance?",
        )
        if _retry_msg:
            _log_progress(_retry_msg)

        if attempt > max_retries:
            findings_text = _format_findings(relevant_findings)
            _record_failure_lesson(
                lessons_conn,
                ticket_id=ticket.ticket_id,
                project_id=project_id,
                failure_type="governance_fail",
                rule=relevant_findings[0].get("message", "governance_fail").split(":")[0] if relevant_findings else "governance_fail",
                description=findings_text[:500],
            )
            if auto_repair:
                # Revert before auto-repair so it starts clean
                _git_reset_changes(repo_path)
                repair_result = _attempt_auto_repair(
                    ticket=ticket,
                    repo_path=repo_path,
                    coder_config=coder_config,
                    system_prompt=system_prompt,
                    state=state,
                    plan_notes=plan_notes,
                    output_dir=output_dir,
                    repair_context=findings_text,
                    attempt_number=attempt + 1,
                )
                if repair_result is not None:
                    return repair_result
                # Auto-repair also failed — re-execute one last time for
                # the ungoverned commit (repair reverted changes).
                try:
                    _response_final, changed_files_final = _execute_ticket(
                        ticket=ticket,
                        repo_path=repo_path,
                        coder_config=coder_config,
                        system_prompt=system_prompt,
                        state=state,
                        plan_notes=_plan_notes_with_lessons,
                        repair_context=findings_text,
                    )
                    if changed_files_final:
                        _git_add(repo_path, changed_files_final)
                        _git_commit(
                            repo_path, ticket.ticket_id, changed_files_final,
                            suffix="[GOVERNANCE: review required]",
                        )
                        _log_ticket_summary(ticket.ticket_id, attempt, _last_governance, _last_post_check, _post_checks_fired, "CODED_UNGOVERNED")
                        return TicketResult(
                            ticket_id=ticket.ticket_id,
                            disposition="CODED_UNGOVERNED",
                            attempts=attempt,
                            changed_files=tuple(changed_files_final),
                            governance_disposition=disposition,
                            governance_evidence_path=gov_evidence_path,
                            error=f"Governance failed after {attempt} attempts — committed for review.",
                            governance_findings=tuple(relevant_findings),
                        )
                except Exception as exc_final:
                    logger.warning("Final coder call for ungoverned commit failed: %s", exc_final)
            else:
                # No auto-repair — commit the current code as ungoverned.
                # Changes are still staged from the last attempt.
                _git_commit(
                    repo_path, ticket.ticket_id, changed_files,
                    suffix="[GOVERNANCE: review required]",
                )
                _log_ticket_summary(ticket.ticket_id, attempt, _last_governance, _last_post_check, _post_checks_fired, "CODED_UNGOVERNED")
                return TicketResult(
                    ticket_id=ticket.ticket_id,
                    disposition="CODED_UNGOVERNED",
                    attempts=attempt,
                    changed_files=tuple(changed_files),
                    governance_disposition=disposition,
                    governance_evidence_path=gov_evidence_path,
                    error=f"Governance failed after {attempt} attempts — committed for review.",
                    governance_findings=tuple(relevant_findings),
                )

            # If we get here, everything failed — true FAIL
            _log_ticket_summary(ticket.ticket_id, attempt, _last_governance, _last_post_check, _post_checks_fired, "FAIL")
            return TicketResult(
                ticket_id=ticket.ticket_id,
                disposition="FAIL",
                attempts=attempt,
                governance_disposition=disposition,
                error=f"Governance and ungoverned commit both failed.",
            )

        # Not the last attempt — revert and retry
        _git_reset_changes(repo_path)

        repair_context = _format_findings(relevant_findings)

    _log_ticket_summary(ticket.ticket_id, max_retries + 1, _last_governance, _last_post_check, _post_checks_fired, "FAIL")
    return TicketResult(
        ticket_id=ticket.ticket_id,
        disposition="FAIL",
        attempts=max_retries + 1,
        error="Exhausted all attempts",
    )


def _execute_ticket(
    ticket: TicketSpec,
    repo_path: Path,
    coder_config: CoderConfig,
    system_prompt: str,
    state: ProjectState,
    plan_notes: str,
    repair_context: str | None = None,
) -> tuple[str, list[str]]:
    """Single attempt: call coder, get changed files.

    For CLI backends (claude-cli, codex-cli): the agent writes files directly
    to the repo, then we check ``git status`` for what changed.

    For API backends (openai, anthropic): parse FILE blocks from the response
    and write them to the repo.

    Returns:
        Tuple of (raw_response, changed_files).
    """
    cli_mode = is_cli_backend(coder_config)
    if cli_mode:
        from saturnday.project_state import write_context_file
        _ctx_path = repo_path / ".saturnday" / "context.md"
        _ctx_path.parent.mkdir(parents=True, exist_ok=True)
        write_context_file(state, _ctx_path, relevant_globs=ticket.scope.allowed_globs)
        state_summary = (
            "CRITICAL — DO NOT SKIP: Read .saturnday/context.md for the current project state "
            "(modules, functions, tests, dependencies) BEFORE writing any code. "
            "If you do NOT read this file, you will duplicate existing code, break existing "
            "interfaces, or contradict the project structure — causing governance failure and "
            "wasted retries. Do not contradict or remove anything described there unless "
            "this ticket explicitly says to."
        )
    else:
        state_summary = generate_context_summary(
            state,
            relevant_globs=ticket.scope.allowed_globs,
            max_chars=8000,
        )
    user_prompt = build_ticket_prompt(
        ticket, state_summary, plan_notes, cli_mode=cli_mode,
    )
    messages = assemble_messages(system_prompt, user_prompt, repair_context)

    # Record HEAD before coder runs — CLI backends may commit directly
    head_before = _git_head_sha(repo_path) if cli_mode else ""

    # codex-cli and cursor-cli need agent_mode: they write files to disk
    # and their non-zero exit codes / empty stdout would incorrectly kill
    # the ticket without it.  claude-cli works correctly without it
    # (uses --print for non-interactive captured execution).
    _agent = coder_config.backend in ("codex-cli", "cursor-cli")
    response = call_coder(coder_config, messages, repo_path, agent_mode=_agent)

    if cli_mode:
        changed_files = _git_changed_files(repo_path, head_before=head_before)
    else:
        changes = extract_changes(response)
        if "__unified_diff__" in changes:
            changed_files = apply_unified_diff(repo_path, changes["__unified_diff__"])
        else:
            changed_files = apply_file_blocks(
                repo_path,
                changes,
                ticket.scope.allowed_globs,
                ticket.scope.forbidden_globs,
            )

    if not changed_files:
        raise PatchExtractionError(
            f"Coder produced response but no files were changed for {ticket.ticket_id}"
        )

    return response, changed_files


def _git_head_sha(repo_path: Path) -> str:
    """Return the current HEAD sha, or empty string if no commits."""
    result = safe_subprocess_run(
        ["git", "rev-parse", "HEAD"],
        cwd=str(repo_path),
        capture_output=True,
        text=True,
        check=False,
    )
    return result.stdout.strip() if result.returncode == 0 else ""


def _git_changed_files(repo_path: Path, head_before: str = "") -> list[str]:
    """Detect new and modified files via ``git status`` and new commits.

    Checks both unstaged/staged changes (git status) AND files changed
    in commits made since ``head_before``.  This handles CLI backends
    like Claude Code that commit directly during execution.

    Excludes saturnday state/evidence files from the changed list.
    """
    # Paths to ignore (our own state files, not coder output)
    _IGNORE_PREFIXES = (
        ".saturnday/",
        "saturnday-state.json",
        ".pytest_cache/",
        ".ruff_cache/",
        "__pycache__/",
    )

    changed: set[str] = set()

    # 1. Check unstaged/staged changes (git status)
    result = safe_subprocess_run(
        ["git", "status", "--porcelain"],
        cwd=str(repo_path),
        capture_output=True,
        text=True,
        check=False,
    )
    for line in result.stdout.splitlines():
        if len(line) < 4:
            continue
        rel_path = line[3:].strip()
        if not rel_path:
            continue
        if any(rel_path.startswith(p) for p in _IGNORE_PREFIXES):
            continue
        changed.add(rel_path)

    # 2. Check files in new commits since head_before
    if head_before:
        head_now = _git_head_sha(repo_path)
        if head_now and head_now != head_before:
            diff_result = safe_subprocess_run(
                ["git", "diff", "--name-only", f"{head_before}..{head_now}"],
                cwd=str(repo_path),
                capture_output=True,
                text=True,
                check=False,
            )
            for line in diff_result.stdout.splitlines():
                rel_path = line.strip()
                if not rel_path:
                    continue
                if any(rel_path.startswith(p) for p in _IGNORE_PREFIXES):
                    continue
                changed.add(rel_path)

    return sorted(changed)


def _snapshot_project_checks(repo_path: Path) -> dict[str, str]:
    """Snapshot project-level check statuses BEFORE the coder runs.

    Returns a dict like ``{"license": "PASS", "tests_pass": "FAIL", ...}``.
    Used by the regression check: only block if the coder made it worse.
    """
    from saturnday.review import (
        _check_license, _check_readme, _check_tests_pass,
        _check_project_runnable,
    )
    snapshot: dict[str, str] = {}
    # Use empty changed_files — we just want project-level status
    dummy_files = [f.name for f in repo_path.rglob("*.py") if ".venv" not in f.parts][:5]
    if not dummy_files:
        dummy_files = [f.name for f in repo_path.rglob("*.ts") if "node_modules" not in f.parts][:5]
    for check_fn, name in [
        (_check_license, "license"),
        (_check_readme, "readme"),
        (_check_tests_pass, "tests_pass"),
        (_check_project_runnable, "project_runnable"),
    ]:
        try:
            result = check_fn(repo_path, dummy_files)
            snapshot[name] = result.get("status", "UNKNOWN")
        except Exception:
            snapshot[name] = "UNKNOWN"
    logger.debug("Project check snapshot: %s", snapshot)
    return snapshot


def _run_governance(repo_path: Path, *, run_mode: bool = False, pre_ticket_state: dict[str, str] | None = None) -> tuple[str, list[dict], str]:
    """Run saturnday governance on staged changes.

    Args:
        repo_path: Path to the repository root.
        run_mode: If True, suppress ``excessive_blast_radius`` findings
            and apply regression filtering for project-level checks.
        pre_ticket_state: Snapshot from ``_snapshot_project_checks`` taken
            BEFORE the coder ran.  When provided, project-level findings
            that were already failing before this ticket are removed —
            only regressions (PASS→FAIL) block the ticket.

    Returns:
        Tuple of (disposition, findings_list, evidence_path) where
        ``evidence_path`` is the filesystem path to the raw governance
        evidence JSON produced by ``run_governance_check``.

    Raises:
        GovernanceError: If governance itself fails to run.
    """
    try:
        from saturnday.governance import run_governance_check
    except ImportError as exc:
        raise GovernanceError(
            "saturnday package not installed. "
            "Install it with: pip install saturnday"
        ) from exc

    # Auto-detect .saturnday-policy.yaml so exemptions apply during ticket governance
    _policy_file = repo_path / ".saturnday-policy.yaml"
    _policy_arg = _policy_file if _policy_file.is_file() else None

    try:
        pack, evidence_path = run_governance_check(
            repo_path=repo_path,
            diff_range="HEAD",
            staged=True,
            policy_path=_policy_arg,
        )
    except Exception as exc:
        raise GovernanceError(f"Governance check failed: {exc}") from exc

    disposition = pack.disposition
    findings: list[dict] = []
    for check in pack.check_results:
        if check.findings:
            findings.extend(check.findings)

    # In run mode, suppress blast_radius — building a project from scratch
    # is expected to touch all files.
    if run_mode:
        findings = [f for f in findings if f.get("kind") != "excessive_blast_radius"]

        # Regression check: if we have a pre-ticket snapshot, remove
        # project-level findings that were ALREADY failing before this ticket.
        # Only regressions (PASS→FAIL) should block.
        _PROJECT_LEVEL_CHECKS = frozenset({
            "license", "readme", "tests_pass", "project_runnable",
        })
        _PROJECT_LEVEL_KINDS = frozenset({
            "missing_license", "missing_readme", "readme_missing_section",
            "tests_failing", "tests_timeout",
            "project_no_entrypoint", "missing_project_config",
        })
        if pre_ticket_state:
            for check in pack.check_results:
                if check.name not in _PROJECT_LEVEL_CHECKS:
                    continue
                was_before = pre_ticket_state.get(check.name, "UNKNOWN")
                if was_before in ("FAIL", "UNKNOWN") and check.status == "FAIL":
                    # Pre-existing failure — not a regression. Clear findings.
                    logger.debug(
                        "Regression check: %s was %s before, still FAIL — not blocking",
                        check.name, was_before,
                    )
                    check.findings = []
                    check.status = "PASS"
            # Remove project-level finding kinds that are pre-existing
            findings = [
                f for f in findings
                if f.get("kind") not in _PROJECT_LEVEL_KINDS
                or pre_ticket_state.get(
                    {  # map kind → check name for lookup
                        "missing_license": "license",
                        "missing_readme": "readme",
                        "readme_missing_section": "readme",
                        "tests_failing": "tests_pass",
                        "tests_timeout": "tests_pass",
                        "project_no_entrypoint": "project_runnable",
                        "missing_project_config": "project_runnable",
                    }.get(f.get("kind", ""), ""),
                    "PASS",
                ) == "PASS"  # only keep if it was PASS before (regression)
            ]

        # Recalculate disposition after all filtering
        non_issue_checks = [
            c for c in pack.check_results
            if c.status in ("FAIL", "WARN") and c.name != "blast_radius"
        ]
        if disposition in ("FAIL", "WARN") and not non_issue_checks:
            disposition = "PASS"

    return disposition, findings, str(evidence_path)


def _filter_findings_to_files(
    findings: list[dict],
    changed_files: list[str],
) -> list[dict]:
    """Filter governance findings to only those in the current ticket's files.

    Findings without a ``path`` field are kept (conservative — assume relevant).
    Findings with a ``path`` that doesn't match any changed file are dropped.
    This prevents pre-existing lint issues from blocking unrelated tickets.
    """
    if not findings or not changed_files:
        return findings

    changed_set = set(changed_files)
    relevant: list[dict] = []

    for f in findings:
        finding_path = f.get("path", "")
        if not finding_path:
            # No path info — keep it (conservative)
            relevant.append(f)
            continue
        # Check if the finding's file is one the current ticket changed
        if finding_path in changed_set:
            relevant.append(f)
        else:
            logger.debug(
                "Filtering out pre-existing finding in %s: %s",
                finding_path, f.get("message", ""),
            )

    return relevant


_DEP_FILES = frozenset({
    "pyproject.toml", "setup.py", "setup.cfg",
    "requirements.txt", "requirements-dev.txt", "requirements-test.txt",
    "package.json",
})


def _ensure_project_venv(repo_path: Path) -> None:
    """Create a .venv in the project directory if one doesn't exist."""
    venv_path = repo_path / ".venv"
    if venv_path.is_dir():
        return
    logger.info("Creating project venv at %s", venv_path)
    try:
        import sys
        subprocess.run(
            [sys.executable, "-m", "venv", str(venv_path)],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
    except Exception as exc:
        logger.warning("Failed to create project venv: %s", exc)


def _venv_python(repo_path: Path) -> str:
    """Return the path to the project venv python, or 'python' as fallback."""
    venv_py = repo_path / ".venv" / "bin" / "python"
    if venv_py.is_file():
        return str(venv_py)
    return "python"


def _auto_install_deps(repo_path: Path, changed_files: list[str]) -> None:
    """Install dependencies if the coder modified dependency files.

    Creates a venv if none exists, then runs ``pip install -e .`` for Python
    projects or ``npm install`` for Node projects.  Failures are non-fatal —
    governance will catch missing imports and the ticket can retry.
    """
    changed_basenames = {Path(f).name for f in changed_files}
    python_dep_changed = bool(changed_basenames & {"pyproject.toml", "setup.py", "setup.cfg",
                                                    "requirements.txt", "requirements-dev.txt",
                                                    "requirements-test.txt"})
    node_dep_changed = "package.json" in changed_basenames

    if python_dep_changed:
        # Use the project venv pip (created at run_plan start)
        venv_pip = repo_path / ".venv" / "bin" / "pip"
        pip_cmd = str(venv_pip) if venv_pip.is_file() else "pip"

        logger.info("Dependency file changed — running pip install -e .")
        try:
            _pip_result = subprocess.run(
                [pip_cmd, "install", "-e", ".", "-q"],
                cwd=str(repo_path),
                capture_output=True,
                text=True,
                timeout=120,
                check=False,
            )
            if _pip_result.returncode != 0:
                logger.warning(
                    "pip install -e . failed (exit %d): %s",
                    _pip_result.returncode,
                    (_pip_result.stderr or "")[:300],
                )
            # Also install dev/test requirements if present
            for req_file in ("requirements-dev.txt", "requirements-test.txt", "requirements.txt"):
                req_path = repo_path / req_file
                if req_path.is_file():
                    subprocess.run(
                        [pip_cmd, "install", "-r", str(req_path), "-q"],
                        cwd=str(repo_path),
                        capture_output=True,
                        text=True,
                        timeout=120,
                        check=False,
                    )
        except Exception as exc:
            logger.debug("Auto pip install failed: %s", exc)

    if node_dep_changed and (repo_path / "package.json").is_file():
        logger.info("package.json changed — running npm install")
        try:
            subprocess.run(
                ["npm", "install", "--silent"],
                cwd=str(repo_path),
                capture_output=True,
                text=True,
                timeout=120,
                check=False,
            )
        except Exception as exc:
            logger.debug("Auto npm install failed: %s", exc)


def _git_add(repo_path: Path, changed_files: list[str]) -> None:
    """Stage specific files with ``git add``."""
    if not changed_files:
        return
    cmd = ["git", "add"] + changed_files
    try:
        result = safe_subprocess_run(
            cmd, cwd=str(repo_path), capture_output=True, text=True, check=False,
        )
    except ShellPolicyViolation as exc:
        logger.error("git add blocked by shell policy: %s", exc)
        return
    if result.returncode != 0:
        logger.warning("git add failed: %s", result.stderr.strip())


def _git_commit(
    repo_path: Path, ticket_id: str, changed_files: list[str],
    *, suffix: str = "",
) -> None:
    """Commit staged changes with a ticket-tagged message."""
    label = f"[{ticket_id}] Apply ticket changes"
    if suffix:
        label = f"{label} {suffix}"
    msg = f"{label}\n\nFiles: {', '.join(changed_files)}"
    try:
        result = safe_subprocess_run(
            ["git", "commit", "-m", msg],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=False,
        )
    except ShellPolicyViolation as exc:
        logger.error("git commit blocked by shell policy: %s", exc)
        return
    if result.returncode != 0:
        logger.warning("git commit failed: %s", result.stderr.strip())
    else:
        logger.info("Committed %s: %d files", ticket_id, len(changed_files))


def _git_reset_changes(repo_path: Path) -> None:
    """Reset staged and working-tree changes on failure.

    Order matters: unstage first, then revert tracked files, then clean untracked.
    """
    # 1. Unstage everything
    try:
        safe_subprocess_run(
            ["git", "reset", "HEAD"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=False,
        )
    except ShellPolicyViolation as exc:
        logger.error("git reset blocked by shell policy: %s", exc)
    # 2. Revert modifications to tracked files
    try:
        safe_subprocess_run(
            ["git", "checkout", "--", "."],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=False,
        )
    except ShellPolicyViolation as exc:
        logger.error("git checkout blocked by shell policy: %s", exc)
    # 3. Remove untracked files and directories (preserve Saturnday state)
    try:
        safe_subprocess_run(
            [
                "git", "clean", "-fd",
                "-e", "saturnday-progress.log",
                "-e", ".saturnday",
                "-e", ".saturnday-policy.yaml",
            ],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=False,
        )
    except ShellPolicyViolation as exc:
        logger.error("git clean blocked by shell policy: %s", exc)


_GITIGNORE_CONTENT = """\
# Python
__pycache__/
*.pyc
*.pyo
*.egg-info/
dist/
build/

# Tools
.pytest_cache/
.ruff_cache/
.mypy_cache/

# Environment
.env
.venv/
venv/

# Agent artifacts
.saturnday/
.saturnday-*/
saturnday-state.json
"""


_SATURNDAY_GITIGNORE_ENTRIES = """\
# Saturnday evidence and state
.saturnday/
.saturnday-*/
saturnday-state.json
"""


def _ensure_gitignore(repo_path: Path) -> None:
    """Ensure ``.gitignore`` exists and includes Saturnday entries.

    If no ``.gitignore`` exists, writes the full template.
    If one exists but lacks Saturnday entries, appends them.
    """
    gitignore = repo_path / ".gitignore"
    if gitignore.exists():
        try:
            content = gitignore.read_text(encoding="utf-8")
            if ".saturnday/" not in content:
                gitignore.write_text(
                    content.rstrip() + "\n\n" + _SATURNDAY_GITIGNORE_ENTRIES,
                    encoding="utf-8",
                )
                logger.info("Appended Saturnday entries to .gitignore")
        except OSError as exc:
            logger.warning("Failed to update .gitignore: %s", exc)
        return
    try:
        gitignore.write_text(_GITIGNORE_CONTENT, encoding="utf-8")
        logger.info("Wrote .gitignore to %s", repo_path)
    except OSError as exc:
        logger.warning("Failed to write .gitignore: %s", exc)


def _log_ticket_summary(
    ticket_id: str,
    attempts: int,
    governance: str,
    post_check: str,
    post_checks_fired: list[str],
    final_disposition: str,
) -> None:
    """Emit a structured per-ticket summary at INFO level and progress log."""
    fired = ", ".join(post_checks_fired) if post_checks_fired else "none"
    logger.info(
        "TICKET SUMMARY | %s | governance=%s | post_check=%s | fired=[%s] | retries=%d | disposition=%s",
        ticket_id,
        governance or "N/A",
        post_check or "N/A",
        fired,
        attempts - 1,
        final_disposition,
    )
    # Also write to progress log file so tail -f users see outcomes
    icon = {"PASS": "✓", "FAIL": "✗", "CODED_UNGOVERNED": "⚠"}.get(final_disposition, "?")
    summary = f"{icon} {ticket_id} → {final_disposition}"
    if attempts > 1:
        summary += f" ({attempts - 1} retries)"
    if post_checks_fired:
        summary += f" [findings: {fired}]"
    _log_progress(summary)


def _record_failure_lesson(
    lessons_conn: "sqlite3.Connection | None",
    ticket_id: str,
    project_id: str,
    failure_type: str,
    rule: str,
    description: str,
) -> None:
    """Record a lesson from a final ticket failure, swallowing all errors.

    Lessons are advisory; a storage failure must never block execution.

    Args:
        lessons_conn: Open lessons DB connection, or ``None`` to skip.
        ticket_id: The failing ticket.
        project_id: The project identifier.
        failure_type: One of governance_fail, post_check_fail, coder_error,
            contract_fail.
        rule: Stable rule identifier (check name or pattern label).
        description: Human-readable description of the failure.
    """
    if lessons_conn is None:
        return
    try:
        store_lesson(
            lessons_conn,
            Lesson(
                project_id=project_id,
                ticket_id=ticket_id,
                failure_type=failure_type,
                rule=rule,
                description=description,
            ),
        )
        logger.debug(
            "Lesson recorded: ticket=%s failure_type=%s rule=%s",
            ticket_id, failure_type, rule,
        )
    except Exception as exc:  # pragma: no cover
        logger.warning("Failed to record lesson for %s: %s", ticket_id, exc)


def _format_findings(findings: list[dict]) -> str:
    """Format governance findings into text for repair context."""
    if not findings:
        return "No specific findings."
    lines: list[str] = []
    for f in findings:
        path = f.get("path", "")
        msg = f.get("message", str(f))
        if path:
            lines.append(f"- {path}: {msg}")
        else:
            lines.append(f"- {msg}")
    return "\n".join(lines)


def _run_verify_cmd(verify_cmd: str, repo_path: Path) -> str:
    """Execute a ticket's verify_cmd and return failure details or empty string.

    Uses regular ``subprocess.run`` (not safe_subprocess_run) because
    verify_cmd is planner-generated, not untrusted input.  The shell policy
    allowlist would block legitimate commands like ``python -c "from X import Y"``.

    Activates the project venv if it exists so ``python`` and ``pytest``
    resolve to the venv, not the system install.
    """
    logger.info("Running verify_cmd: %s", verify_cmd)
    # Prepend venv activation so python/pytest use the project venv
    venv_activate = repo_path / ".venv" / "bin" / "activate"
    if venv_activate.is_file():
        verify_cmd = f"source {venv_activate} && {verify_cmd}"
    try:
        result = subprocess.run(
            ["bash", "-c", verify_cmd],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
        if result.returncode == 0:
            return ""
        output = (result.stdout + result.stderr)[-500:]
        return f"Exit code {result.returncode}: {output}"
    except subprocess.TimeoutExpired:
        return "verify_cmd timed out after 120 seconds"
    except Exception as exc:
        return f"verify_cmd error: {exc}"
    except Exception as exc:
        return f"verify_cmd error: {exc}"


def _check_contracts(ticket: TicketSpec, repo_path: Path) -> str:
    """Verify ticket acceptance criteria contracts against the repo.

    Parses acceptance criteria for verifiable patterns (function/class/file/test
    existence) and checks each against the current repo state.

    Args:
        ticket: The ticket whose ``acceptance_criteria`` to verify.
        repo_path: Absolute path to the repository root.

    Returns:
        An empty string if all contracts pass (or there are none).
        A non-empty human-readable failure summary if any contract fails;
        this is suitable for use as ``repair_context`` on the next attempt.
    """
    if not ticket.acceptance_criteria:
        return ""

    from saturnday.run.contract_checker import (
        extract_contracts,
        format_contract_results,
        verify_contracts,
    )

    contracts = extract_contracts(ticket.acceptance_criteria)
    if not contracts:
        # No verifiable patterns found — nothing to check
        return ""

    results = verify_contracts(contracts, repo_path)
    failed_blocking = [r for r in results if not r.verified and r.severity == "error"]
    failed_advisory = [r for r in results if not r.verified and r.severity == "warning"]

    if failed_advisory:
        logger.info(
            "Contract verification: %d advisory warning(s) for %s",
            len(failed_advisory), ticket.ticket_id,
        )
        advisory_lines = format_contract_results(failed_advisory)
        logger.info("Advisory contract warnings:\n%s", advisory_lines)

    if not failed_blocking:
        logger.debug(
            "Contract verification: all blocking contract(s) passed for %s",
            ticket.ticket_id,
        )
        return ""

    logger.warning(
        "Contract verification: %d/%d blocking contract(s) FAILED for %s",
        len(failed_blocking), len(results), ticket.ticket_id,
    )
    failure_lines = format_contract_results(failed_blocking)
    return (
        f"Acceptance criteria not satisfied ({len(failed_blocking)} contract(s) failed):\n"
        + failure_lines
    )


def _attempt_auto_repair(
    ticket: TicketSpec,
    repo_path: Path,
    coder_config: CoderConfig,
    system_prompt: str,
    state: ProjectState,
    plan_notes: str,
    output_dir: Path,
    repair_context: str,
    attempt_number: int,
) -> TicketResult | None:
    """Attempt a single auto-repair pass after retry exhaustion.

    This is a one-shot extra attempt that uses a repair-framed context derived
    from the final governance findings.  It is not a loop — if governance still
    fails after this attempt, the ticket stays FAIL.

    Args:
        ticket: The ticket being repaired.
        repo_path: Path to the target repository.
        coder_config: Backend configuration for the AI coder.
        system_prompt: Pre-built system prompt for the coder.
        state: Current project state.
        plan_notes: Free-form notes injected into every coder prompt.
        output_dir: Directory for evidence output.
        repair_context: Formatted findings text from the last failed attempt.
        attempt_number: The attempt number for logging and evidence.

    Returns:
        A passing ``TicketResult`` if the repair attempt succeeds, or
        ``None`` if the repair attempt also fails (caller should return FAIL).
    """
    logger.info(
        "Ticket %s: auto-repair attempt (attempt %d) starting",
        ticket.ticket_id, attempt_number,
    )

    # Wrap repair_context with explicit repair framing
    repair_prompt = (
        "AUTO-REPAIR PASS: The previous attempts failed governance. "
        "Carefully fix ONLY the issues listed below:\n"
        + repair_context
    )

    try:
        response, changed_files = _execute_ticket(
            ticket=ticket,
            repo_path=repo_path,
            coder_config=coder_config,
            system_prompt=system_prompt,
            state=state,
            plan_notes=plan_notes,
            repair_context=repair_prompt,
        )
    except CloudCoreError as exc:
        logger.warning(
            "Ticket %s auto-repair attempt failed during execution: %s",
            ticket.ticket_id, exc,
        )
        write_ticket_evidence(
            TicketEvidence(
                ticket_id=ticket.ticket_id,
                attempt=attempt_number,
                governance_evidence_path="",
                error=f"Auto-repair execution error: {exc}",
            ),
            output_dir,
        )
        return None

    _git_add(repo_path, changed_files)

    try:
        disposition, findings, gov_evidence_path = _run_governance(repo_path, run_mode=True)
    except GovernanceError as exc:
        logger.warning(
            "Ticket %s auto-repair governance check failed: %s",
            ticket.ticket_id, exc,
        )
        _git_reset_changes(repo_path)
        write_ticket_evidence(
            TicketEvidence(
                ticket_id=ticket.ticket_id,
                attempt=attempt_number,
                coder_response=response,
                changed_files=changed_files,
                governance_evidence_path="",
                error=f"Auto-repair governance error: {exc}",
            ),
            output_dir,
        )
        return None

    relevant_findings = _filter_findings_to_files(findings, changed_files)
    effective_disposition = disposition
    if disposition == "FAIL" and not relevant_findings:
        effective_disposition = "PASS"

    write_ticket_evidence(
        TicketEvidence(
            ticket_id=ticket.ticket_id,
            attempt=attempt_number,
            coder_response=response,
            changed_files=changed_files,
            governance_disposition=effective_disposition,
            governance_findings=relevant_findings,
            governance_evidence_path=gov_evidence_path,
        ),
        output_dir,
    )

    if effective_disposition == "PASS":
        # Run post-checks on the repair result
        post_findings = run_post_checks(repo_path, changed_files)
        if post_findings:
            logger.warning(
                "Ticket %s auto-repair passed governance but failed post-checks (%d issue(s))",
                ticket.ticket_id, len(post_findings),
            )
            _git_reset_changes(repo_path)
            return None

        _git_commit(repo_path, ticket.ticket_id, changed_files)
        logger.info(
            "Ticket %s auto-repair PASSED (attempt %d)",
            ticket.ticket_id, attempt_number,
        )
        return TicketResult(
            ticket_id=ticket.ticket_id,
            disposition="PASS",
            attempts=attempt_number,
            changed_files=tuple(changed_files),
            governance_disposition=effective_disposition,
            governance_evidence_path=gov_evidence_path,
        )

    # Repair also failed governance
    _git_reset_changes(repo_path)
    logger.warning(
        "Ticket %s auto-repair attempt also failed governance",
        ticket.ticket_id,
    )
    return None
