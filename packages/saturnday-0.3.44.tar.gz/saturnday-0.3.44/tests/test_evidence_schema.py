"""Tests for shared evidence schema constants (U8)."""

from __future__ import annotations


def test_schema_version_is_string() -> None:
    """SCHEMA_VERSION must be a non-empty string."""
    from saturnday.shared.evidence_schema import SCHEMA_VERSION

    assert isinstance(SCHEMA_VERSION, str)
    assert SCHEMA_VERSION


def test_schema_version_matches_guard_evidence() -> None:
    """Guard evidence module must expose the same SCHEMA_VERSION as the shared schema."""
    from saturnday.shared.evidence_schema import SCHEMA_VERSION as shared_version
    from saturnday.evidence import SCHEMA_VERSION as guard_version

    assert guard_version == shared_version


def test_schema_version_matches_run_evidence() -> None:
    """Run evidence module must import SCHEMA_VERSION from the shared schema."""
    from saturnday.shared.evidence_schema import SCHEMA_VERSION as shared_version
    from saturnday.run.evidence import SCHEMA_VERSION as run_version

    assert run_version == shared_version


def test_evidence_dir_constants_are_strings() -> None:
    """Evidence directory constants must be non-empty strings."""
    from saturnday.shared.evidence_schema import (
        EVIDENCE_DIR_GUARD,
        EVIDENCE_DIR_REPAIR,
        EVIDENCE_DIR_RUN,
    )

    for constant in (EVIDENCE_DIR_GUARD, EVIDENCE_DIR_RUN, EVIDENCE_DIR_REPAIR):
        assert isinstance(constant, str)
        assert constant


def test_evidence_dir_constants_are_distinct() -> None:
    """Each evidence directory constant must be a unique path."""
    from saturnday.shared.evidence_schema import (
        EVIDENCE_DIR_GUARD,
        EVIDENCE_DIR_REPAIR,
        EVIDENCE_DIR_RUN,
    )

    dirs = {EVIDENCE_DIR_GUARD, EVIDENCE_DIR_RUN, EVIDENCE_DIR_REPAIR}
    assert len(dirs) == 3, "Evidence directory constants must be distinct"


def test_guard_evidence_schema_version_in_evidence_pack(tmp_path: object) -> None:
    """EvidencePack.schema_version written by Guard must match shared SCHEMA_VERSION."""
    from saturnday.shared.evidence_schema import SCHEMA_VERSION
    from saturnday.evidence import EvidencePack

    pack = EvidencePack(
        schema_version=SCHEMA_VERSION,
        run_id="run-001",
        mode="check",
        repo_path="/tmp/repo",
        diff_range="HEAD~1..HEAD",
        saturnday_version="0.1.0",
        created_utc="2026-03-19T00:00:00Z",
    )
    assert pack.schema_version == SCHEMA_VERSION
