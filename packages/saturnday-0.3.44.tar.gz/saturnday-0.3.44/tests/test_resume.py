"""Tests for saturnday.run.resume and run_plan skip_tickets integration.

Covers:
- resume_plan passes PASS tickets as skip_tickets to run_plan
- rerun_failed passes non-FAIL tickets as skip_tickets to run_plan
- Tickets in skip_tickets are added to the completed set so that downstream
  dependency resolution works correctly
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from saturnday._types import (
    CoderConfig,
    RunResult,
    TicketResult,
    TicketSpec,
)
from saturnday.run.resume import rerun_failed, resume_plan


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_plan(plan_data: dict, dir_path: Path) -> Path:
    """Write a plan dict to a temp JSON file."""
    path = dir_path / "plan.json"
    path.write_text(json.dumps(plan_data), encoding="utf-8")
    return path


def _write_ledger(ledger_data: dict, evidence_dir: Path) -> Path:
    """Write a ledger dict to the canonical ledger path."""
    ledger_dir = evidence_dir / "evidence" / "run"
    ledger_dir.mkdir(parents=True, exist_ok=True)
    ledger_path = ledger_dir / "ledger.json"
    ledger_path.write_text(json.dumps(ledger_data), encoding="utf-8")
    return ledger_path


def _make_coder_config() -> CoderConfig:
    return CoderConfig(backend="openai", api_key="test-key", model="gpt-4")


def _fake_run_result() -> RunResult:
    return RunResult(project_id="test-project", passed=1)


# ---------------------------------------------------------------------------
# Test: resume_plan passes PASS tickets as skip_tickets
# ---------------------------------------------------------------------------

class TestResumePlanSkipsPassed:
    def test_resume_skips_passed_tickets(self, tmp_path: Path) -> None:
        """resume_plan must pass the set of PASS tickets as skip_tickets to run_plan."""
        plan_data = {
            "version": 1,
            "project_id": "test-project",
            "tickets": [
                {"ticket_id": "T001", "goal": "First"},
                {"ticket_id": "T002", "goal": "Second"},
                {"ticket_id": "T003", "goal": "Third"},
            ],
        }
        plan_path = _write_plan(plan_data, tmp_path)

        ledger_data = {
            "ticket_statuses": {
                "T001": {"disposition": "PASS"},
                "T002": {"disposition": "FAIL"},
                "T003": {"disposition": "PENDING"},
            }
        }
        evidence_dir = tmp_path / "evidence-out"
        _write_ledger(ledger_data, evidence_dir)

        captured: dict = {}

        def fake_run_plan(**kwargs: object) -> RunResult:
            captured["skip_tickets"] = kwargs.get("skip_tickets")
            return _fake_run_result()

        with patch(
            "saturnday.ticket_runner.run_plan",
            side_effect=fake_run_plan,
        ):
            resume_plan(
                evidence_dir=evidence_dir,
                plan_path=plan_path,
                repo_path=tmp_path,
                coder_config=_make_coder_config(),
                standards_dir=tmp_path,
            )

        skip = captured.get("skip_tickets")
        assert skip is not None, "skip_tickets was not passed to run_plan"
        assert "T001" in skip, "T001 (PASS) must be in skip_tickets"
        assert "T002" not in skip, "T002 (FAIL) must NOT be in skip_tickets"
        assert "T003" not in skip, "T003 (PENDING) must NOT be in skip_tickets"


# ---------------------------------------------------------------------------
# Test: rerun_failed passes non-FAIL tickets as skip_tickets
# ---------------------------------------------------------------------------

class TestRerunFailedSkipsNonFailed:
    def test_rerun_only_executes_failed(self, tmp_path: Path) -> None:
        """rerun_failed must skip PASS and PENDING tickets; only FAIL re-executes."""
        plan_data = {
            "version": 1,
            "project_id": "test-project",
            "tickets": [
                {"ticket_id": "T001", "goal": "First"},
                {"ticket_id": "T002", "goal": "Second"},
                {"ticket_id": "T003", "goal": "Third"},
            ],
        }
        plan_path = _write_plan(plan_data, tmp_path)

        ledger_data = {
            "ticket_statuses": {
                "T001": {"disposition": "PASS"},
                "T002": {"disposition": "FAIL"},
                "T003": {"disposition": "PASS"},
            }
        }
        evidence_dir = tmp_path / "evidence-out"
        _write_ledger(ledger_data, evidence_dir)

        captured: dict = {}

        def fake_run_plan(**kwargs: object) -> RunResult:
            captured["skip_tickets"] = kwargs.get("skip_tickets")
            return _fake_run_result()

        with patch(
            "saturnday.ticket_runner.run_plan",
            side_effect=fake_run_plan,
        ):
            rerun_failed(
                evidence_dir=evidence_dir,
                plan_path=plan_path,
                repo_path=tmp_path,
                coder_config=_make_coder_config(),
                standards_dir=tmp_path,
            )

        skip = captured.get("skip_tickets")
        assert skip is not None, "skip_tickets was not passed to run_plan"
        assert "T001" in skip, "T001 (PASS) must be in skip_tickets"
        assert "T003" in skip, "T003 (PASS) must be in skip_tickets"
        assert "T002" not in skip, "T002 (FAIL) must NOT be in skip_tickets — it should re-execute"


# ---------------------------------------------------------------------------
# Test: skipped tickets satisfy downstream dependencies
# ---------------------------------------------------------------------------

class TestSkippedTicketsSatisfyDependencies:
    def test_skipped_tickets_satisfy_dependencies(self, tmp_path: Path) -> None:
        """A ticket in skip_tickets must be added to completed so dependent tickets run.

        Plan: T002 depends on T001. T001 is in skip_tickets.
        Expected: T002 is NOT skipped due to an unmet dependency — it should
        be attempted (or at least reach _run_ticket_with_retries).
        """
        plan_data = {
            "version": 1,
            "project_id": "dep-test",
            "tickets": [
                {"ticket_id": "T001", "goal": "Scaffold"},
                {"ticket_id": "T002", "goal": "Build on scaffold", "dependencies": ["T001"]},
            ],
        }
        plan_path = _write_plan(plan_data, tmp_path)

        # Track which tickets reached _run_ticket_with_retries
        attempted: list[str] = []

        def fake_run_ticket(ticket: TicketSpec, **kwargs: object) -> TicketResult:
            attempted.append(ticket.ticket_id)
            return TicketResult(
                ticket_id=ticket.ticket_id,
                disposition="PASS",
                changed_files=(),
            )

        # Also mock analyze_and_split to return the ticket unchanged (no splitting)
        def fake_analyze_and_split(
            ticket: TicketSpec, *args: object, **kwargs: object
        ) -> list[TicketSpec]:
            return [ticket]

        # Mock write_ledger_snapshot and write_run_summary to avoid FS writes.
        # analyze_and_split is imported locally inside the ticket loop, so it must
        # be patched on its source module (ticket_splitter), not on ticket_runner.
        with (
            patch(
                "saturnday.ticket_runner._run_ticket_with_retries",
                side_effect=fake_run_ticket,
            ),
            patch(
                "saturnday.ticket_splitter.analyze_and_split",
                side_effect=fake_analyze_and_split,
            ),
            patch("saturnday.ticket_runner.write_ledger_snapshot"),
            patch("saturnday.ticket_runner.write_run_summary"),
            patch("saturnday.ticket_runner.load_state", return_value=None),
            patch("saturnday.ticket_runner.save_state"),
            patch("saturnday.ticket_runner.update_state", return_value=MagicMock()),
            patch("saturnday.ticket_runner._ensure_gitignore"),
            patch("saturnday.ticket_runner.build_system_prompt", return_value="sys"),
        ):
            from saturnday.ticket_runner import run_plan

            result = run_plan(
                plan_path=plan_path,
                repo_path=tmp_path,
                coder_config=_make_coder_config(),
                standards_dir=tmp_path,
                output_dir=tmp_path / "out",
                skip_tickets=frozenset({"T001"}),
            )

        # T001 was pre-completed — it must NOT have been attempted via the coder
        assert "T001" not in attempted, (
            "T001 is in skip_tickets; it must not reach _run_ticket_with_retries"
        )

        # T002 depends on T001; since T001 is pre-completed, T002 must be attempted
        assert "T002" in attempted, (
            "T002 depends on T001 which was pre-completed; T002 must be attempted"
        )
