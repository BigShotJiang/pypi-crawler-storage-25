# ado - get_tools

**Toolkit**: `ado`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `AzureDevOpsPlansToolkit`

---

## Method Implementation

```python
    def get_tools(self):
        return self.tools
```
