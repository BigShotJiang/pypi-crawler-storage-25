# carrier - create_test

**Toolkit**: `carrier`
**Method**: `create_test`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def create_test(self, data: dict):
        return self._client.create_test(data)
```
