# carrier - get_engagements_list

**Toolkit**: `carrier`
**Method**: `get_engagements_list`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def get_engagements_list(self) -> List[Dict[str, Any]]:
        return self._client.get_engagements_list()
```
