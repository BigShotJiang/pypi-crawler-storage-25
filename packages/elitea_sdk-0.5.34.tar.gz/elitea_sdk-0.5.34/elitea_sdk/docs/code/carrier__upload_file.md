# carrier - upload_file

**Toolkit**: `carrier`
**Method**: `upload_file`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def upload_file(self, bucket_name: str, file_name: str):
        return self._client.upload_file(bucket_name, file_name)
```
