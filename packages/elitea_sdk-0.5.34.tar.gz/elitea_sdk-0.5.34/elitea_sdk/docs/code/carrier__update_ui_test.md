# carrier - update_ui_test

**Toolkit**: `carrier`
**Method**: `update_ui_test`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def update_ui_test(self, test_id: str, json_body) -> Dict[str, Any]:
        """Update UI test configuration and schedule."""
        return self._client.update_ui_test(test_id, json_body)
```
