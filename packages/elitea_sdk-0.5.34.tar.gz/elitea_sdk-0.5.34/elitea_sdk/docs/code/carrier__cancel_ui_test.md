# carrier - cancel_ui_test

**Toolkit**: `carrier`
**Method**: `cancel_ui_test`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def cancel_ui_test(self, test_id: str) -> Dict[str, Any]:
        """Cancel a UI test by setting its status to Canceled."""
        return self._client.cancel_ui_test(test_id)
```
