# carrier - get_reports_list

**Toolkit**: `carrier`
**Method**: `get_reports_list`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def get_reports_list(self) -> List[Dict[str, Any]]:
        return self._client.get_reports_list()
```
