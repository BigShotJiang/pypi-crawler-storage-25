# carrier - get_integrations

**Toolkit**: `carrier`
**Method**: `get_integrations`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def get_integrations(self, name: str):
        return self._client.get_integrations(name)
```
