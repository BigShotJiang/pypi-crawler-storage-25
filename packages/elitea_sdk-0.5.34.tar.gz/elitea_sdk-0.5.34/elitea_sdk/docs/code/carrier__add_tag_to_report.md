# carrier - add_tag_to_report

**Toolkit**: `carrier`
**Method**: `add_tag_to_report`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def add_tag_to_report(self, report_id, tag_name):
        return self._client.add_tag_to_report(report_id, tag_name)
```
