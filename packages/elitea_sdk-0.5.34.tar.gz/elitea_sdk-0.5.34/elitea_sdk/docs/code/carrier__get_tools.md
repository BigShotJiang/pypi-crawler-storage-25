# carrier - get_tools

**Toolkit**: `carrier`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `EliteACarrierToolkit`

---

## Method Implementation

```python
    def get_tools(self) -> List[BaseTool]:
        logger.info(f"[EliteACarrierToolkit] Retrieving {len(self.tools)} initialized tools")
        return self.tools
```
