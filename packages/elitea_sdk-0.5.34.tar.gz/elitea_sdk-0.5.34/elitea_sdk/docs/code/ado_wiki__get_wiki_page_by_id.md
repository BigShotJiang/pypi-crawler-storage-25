# ado_wiki - get_wiki_page_by_id

**Toolkit**: `ado_wiki`
**Method**: `get_wiki_page_by_id`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def get_wiki_page_by_id(self, wiki_identified: Optional[str] = None, page_id: int = None, image_description_prompt=None, process_images: bool = True):
        """Extract ADO wiki page content."""
        try:
            wiki_id = self._resolve_wiki_identifier(wiki_identified)
            content = self._client.get_page_by_id(project=self.project, wiki_identifier=wiki_id, id=page_id,
                                                   include_content=True).page.content
            if process_images:
                return self._process_images(content, image_description_prompt=image_description_prompt, wiki_identified=wiki_id)
            return content
        except Exception as e:
            logger.error(f"Error during the attempt to extract wiki page: {str(e)}")
            return ToolException(f"Error during the attempt to extract wiki page: {str(e)}")
```
