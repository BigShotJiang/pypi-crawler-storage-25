# carrier - fetch_tickets

**Toolkit**: `carrier`
**Method**: `fetch_tickets`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def fetch_tickets(self, board_id: str) -> List[Dict[str, Any]]:
        return self._client.fetch_tickets(board_id)
```
