# carrier - get_ui_test_details

**Toolkit**: `carrier`
**Method**: `get_ui_test_details`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def get_ui_test_details(self, test_id: str) -> Dict[str, Any]:
        """Get detailed UI test configuration by test ID."""
        return self._client.get_ui_test_details(test_id)
```
