# carrier - run_ui_test

**Toolkit**: `carrier`
**Method**: `run_ui_test`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def run_ui_test(self, test_id: str, json_body):
        """Run a UI test with the given test ID and JSON body."""
        return self._client.run_ui_test(test_id, json_body)
```
