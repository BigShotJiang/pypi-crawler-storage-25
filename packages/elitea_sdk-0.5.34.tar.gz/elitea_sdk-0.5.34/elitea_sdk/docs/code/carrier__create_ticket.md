# carrier - create_ticket

**Toolkit**: `carrier`
**Method**: `create_ticket`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def create_ticket(self, ticket_payload: TicketPayload) -> bool:
        try:
            json_response = self._client.create_ticket(ticket_payload)
            # Log it
            logger.info(f"Ticket successfully created: {json_response}")
            return json_response
        except CarrierAPIError as e:
            logger.error(f"Carrier API error creating ticket: {e}")
            return {}
```
