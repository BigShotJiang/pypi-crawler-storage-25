# ado - get_file_content

**Toolkit**: `ado`
**Method**: `get_file_content`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def get_file_content(self, commit_id, path):
        cache_key = (path, commit_id)
        cached = self._file_content_cache.get(cache_key)
        if cached is not None:
            return cached

        version_descriptor = GitVersionDescriptor(
            version=commit_id, version_type="commit"
        )
        try:
            content_generator = self._client.get_item_text(
                repository_id=self.repository_id,
                project=self.project,
                path=path,
                version_descriptor=version_descriptor,
            )
            content = get_content_from_generator(content_generator)
        except Exception as e:
            msg = f"Failed to get item text. Error: {str(e)}"
            logger.error(msg)
            return ToolException(msg)

        self._file_content_cache[cache_key] = content
        return content
```
