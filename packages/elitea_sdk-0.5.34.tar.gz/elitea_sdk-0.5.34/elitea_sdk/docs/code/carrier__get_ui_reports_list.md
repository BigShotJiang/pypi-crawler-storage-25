# carrier - get_ui_reports_list

**Toolkit**: `carrier`
**Method**: `get_ui_reports_list`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def get_ui_reports_list(self) -> List[Dict[str, Any]]:
        """Get list of UI test reports from the Carrier platform."""
        return self._client.get_ui_reports_list()
```
