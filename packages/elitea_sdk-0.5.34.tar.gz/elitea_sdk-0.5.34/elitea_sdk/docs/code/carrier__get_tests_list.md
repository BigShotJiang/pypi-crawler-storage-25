# carrier - get_tests_list

**Toolkit**: `carrier`
**Method**: `get_tests_list`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def get_tests_list(self) -> List[Dict[str, Any]]:
        return self._client.get_tests_list()
```
