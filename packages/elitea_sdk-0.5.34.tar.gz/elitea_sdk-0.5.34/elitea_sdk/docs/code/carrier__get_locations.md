# carrier - get_locations

**Toolkit**: `carrier`
**Method**: `get_locations`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def get_locations(self) -> Dict[str, Any]:
        """Get list of available locations/cloud settings from the Carrier platform."""
        return self._client.get_locations()
```
