# carrier - create_ui_test

**Toolkit**: `carrier`
**Method**: `create_ui_test`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def create_ui_test(self, json_body: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new UI test."""
        return self._client.create_ui_test(json_body)
```
