# carrier - run_test

**Toolkit**: `carrier`
**Method**: `run_test`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def run_test(self, test_id: str, json_body):
        return self._client.run_test(test_id, json_body)
```
