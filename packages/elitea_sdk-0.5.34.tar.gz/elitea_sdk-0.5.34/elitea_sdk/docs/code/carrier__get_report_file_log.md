# carrier - get_report_file_log

**Toolkit**: `carrier`
**Method**: `get_report_file_log`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def get_report_file_log(self, bucket: str, file_name: str):
        return self._client.get_report_file_log(bucket, file_name)
```
