# carrier - get_available_locations

**Toolkit**: `carrier`
**Method**: `get_available_locations`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def get_available_locations(self):
        return self._client.get_available_locations()
```
