# carrier - get_ui_tests_list

**Toolkit**: `carrier`
**Method**: `get_ui_tests_list`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def get_ui_tests_list(self) -> List[Dict[str, Any]]:
        """Get list of UI tests from the Carrier platform."""
        return self._client.get_ui_tests_list()
```
