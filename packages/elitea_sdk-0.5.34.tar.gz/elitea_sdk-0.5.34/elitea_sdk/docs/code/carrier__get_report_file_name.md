# carrier - get_report_file_name

**Toolkit**: `carrier`
**Method**: `get_report_file_name`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def get_report_file_name(self, report_id: str, extract_to: str = "/tmp"):
        return self._client.get_report_file_name(report_id, extract_to)
```
