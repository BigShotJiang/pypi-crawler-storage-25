# carrier - get_toolkit

**Toolkit**: `carrier`
**Method**: `get_toolkit`
**Source File**: `__init__.py`
**Class**: `EliteACarrierToolkit`

---

## Method Implementation

```python
    def get_toolkit(
            cls,
            selected_tools: Optional[List[str]] = None,
            toolkit_name: Optional[str] = None,
            **kwargs
    ) -> 'EliteACarrierToolkit':
        selected_tools = selected_tools or []
        logger.info(f"[EliteACarrierToolkit] Initializing toolkit with selected tools: {selected_tools}")

        wrapper_payload = {
            **kwargs,
            **kwargs.get('carrier_configuration', {}),
        }

        try:
            carrier_api_wrapper = CarrierAPIWrapper(**wrapper_payload)
            logger.info(
                f"[EliteACarrierToolkit] CarrierAPIWrapper initialized successfully with URL: {wrapper_payload.get('url')}")
        except Exception as e:
            logger.exception(f"[EliteACarrierToolkit] Error initializing CarrierAPIWrapper: {e}")
            raise ValueError(f"CarrierAPIWrapper initialization error: {e}")

        tools = []
        for tool_def in __all__:
            if selected_tools and tool_def['name'] not in selected_tools:
                continue
            try:
                tool_instance = tool_def['tool'](api_wrapper=carrier_api_wrapper)
                if toolkit_name:
                    tool_instance.description = f"{tool_instance.description}\nToolkit: {toolkit_name}"
                    tool_instance.description = tool_instance.description[:1000]
                    tool_instance.metadata = {"toolkit_name": toolkit_name, "toolkit_type": name}
                tools.append(tool_instance)
                logger.info(f"[EliteACarrierToolkit] Successfully initialized tool '{tool_instance.name}'")
            except Exception as e:
                logger.warning(f"[EliteACarrierToolkit] Could not initialize tool '{tool_def['name']}': {e}")

        logger.info(f"[EliteACarrierToolkit] Total tools initialized: {len(tools)}")
        return cls(tools=tools)
```
