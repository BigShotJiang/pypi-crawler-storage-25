# custom_open_api - get_toolkit

**Toolkit**: `custom_open_api`
**Method**: `get_toolkit`
**Source File**: `__init__.py`
**Class**: `OpenApiToolkit`

---

## Method Implementation

```python
    def get_toolkit(cls, selected_tools: list[str] | None = None, toolkit_name: Optional[str] = None, **kwargs):
        if selected_tools is None:
            selected_tools = []
        openapi_api_wrapper = OpenApiWrapper(**kwargs)
        available_tools = openapi_api_wrapper.get_available_tools()
        tools = []
        # Use clean toolkit name for context (max 1000 chars in description)
        toolkit_context = f" [Toolkit: {clean_string(toolkit_name)}]" if toolkit_name else ''
        for tool in available_tools:
            if selected_tools and tool["name"] not in selected_tools:
                continue
            # Add toolkit context to description with character limit
            description = tool["description"]
            if toolkit_context and len(description + toolkit_context) <= 1000:
                description = description + toolkit_context
            tools.append(BaseAction(
                api_wrapper=openapi_api_wrapper,
                name=tool["name"],
                description=description,
                args_schema=tool["args_schema"],
                metadata={TOOLKIT_NAME_META: toolkit_name, TOOLKIT_TYPE_META: name, TOOL_NAME_META: tool["name"]} if toolkit_name else {TOOL_NAME_META: tool["name"]}
            ))
        return cls(tools=tools)
```
