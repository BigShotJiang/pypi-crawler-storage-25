# torchhe

This library exposes two main classes:

- `DSTL`
- `PL`

Example:

```python
from torchhe import DSTL, PL

dstl = DSTL()
pl = PL()

dstl.listing()
dstl.time_series.show()
dstl.mongodb.instructions()

pl.listing()
pl.activation_functions.top()
pl.activation_functions.basic_activation_function_visualizer()
pl.cloudsim.instructions()
pl.cloudsim.priority_based_cloudlet_scheduling()
pl.cloud_apps.employee_record_management_system()
```

## Structure

- `DSTL`
  - `pyspark`
  - `time_series`
  - `mongodb`
- `PL`
  - `activation_functions`
  - `neural_networks`
  - `fuzzy_logic`
  - `cloud_computing`
  - `cloud_apps`
  - `cloudsim`
  - `cloudlet`
  - `apex`

Each PL topic has:

- `top()` to print the related problem statements from `PROBLEM STATEMENT.pdf`
- topic-specific methods to print the matching code/content from `Programming Lab Practice Programs.pdf`

Extra helpers:

- `listing()` prints available groups or methods
- `instructions()` prints setup or run instructions where available

Notes:

- The library publishes as `torchhe` and supports `from torchhe import DSTL, PL`.
- Internally the packaged content is still sourced from the `pysparke` module tree.
- The library prints the extracted text as stored in the repo.
- Some PL content comes from OCR text extracted from PDF, so spacing/formatting may look imperfect.
