def __getattr__(name):
    _desktop_exports = {
        "Wysebee": ".desktop.wysebee",
        "WysebeeWebView": ".desktop.wysebee_webview",
        "WysebeeWebEnginePage": ".desktop.wysebee_webengine_page",
        "WysebeeBackend": ".desktop.wysebee_backend",
        "singleton": ".desktop.singleton",
        "TempFileHelper": ".desktop.temp_helper",
        "WysebeeWebPopup": ".desktop.wysebee_webpopup",
        "WysebeeAppMenu": ".desktop.wysebee_app_menu",
    }
    if name in _desktop_exports:
        import importlib
        module = importlib.import_module(_desktop_exports[name], __package__)
        attr = getattr(module, name)
        globals()[name] = attr
        return attr
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def _init_filesystem():
    from .desktop.filesystem import __all__ as _fs_all, __dict__ as _fs_dict
    for _name in _fs_all:
        globals()[_name] = _fs_dict[_name]


_init_filesystem()
del _init_filesystem