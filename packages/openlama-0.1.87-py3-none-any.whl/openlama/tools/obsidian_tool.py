"""Tool: obsidian – Obsidian vault management via obsidian-cli."""

import asyncio
import shutil

from openlama.config import get_config_int
from openlama.tools.registry import register_tool


def _find_obsidian_cli() -> str | None:
    """Find obsidian-cli binary, checking common paths if not in PATH."""
    found = shutil.which("obsidian-cli")
    if found:
        return found
    # Common install locations not always in daemon PATH
    import sys
    extra_paths = ["/opt/homebrew/bin/obsidian-cli", "/usr/local/bin/obsidian-cli"]
    if sys.platform == "win32":
        import os
        gopath = os.environ.get("GOPATH", str(__import__("pathlib").Path.home() / "go"))
        extra_paths.append(f"{gopath}\\bin\\obsidian-cli.exe")
    else:
        import os
        gopath = os.environ.get("GOPATH", str(__import__("pathlib").Path.home() / "go"))
        extra_paths.append(f"{gopath}/bin/obsidian-cli")
    for p in extra_paths:
        if __import__("os").path.isfile(p):
            return p
    return None


async def _run_obsidian(args: list[str], timeout: int = None) -> str:
    """Run an obsidian-cli command and return output."""
    if timeout is None:
        timeout = get_config_int("code_execution_timeout", 30)
    cli_bin = _find_obsidian_cli()
    if not cli_bin:
        return (
            "obsidian-cli is not installed. Install with:\n"
            "  macOS/Linux: brew tap yakitrak/yakitrak && brew install obsidian-cli\n"
            "  Go:          go install github.com/Yakitrak/obsidian-cli@latest\n"
            "  Or run:      openlama config obsidian install"
        )
    cmd = [cli_bin] + args
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return f"Execution timed out ({timeout}s)"

        out = stdout.decode("utf-8", errors="replace")[:8000]
        err = stderr.decode("utf-8", errors="replace")[:2000]

        parts = []
        if out:
            parts.append(out)
        if err and proc.returncode != 0:
            parts.append(f"[Error] {err.strip()}")
            # Provide guidance for common errors
            if "Failed to access vault directory" in err:
                parts.append(
                    "[Hint] The path does not exist. "
                    "Run 'list' on the parent path first to verify exact folder/file names."
                )
            elif "path traversal" in err:
                parts.append("[Hint] Specify the folder name directly instead of '/'.")
        if proc.returncode != 0 and not parts:
            parts.append(f"[exit code: {proc.returncode}]")
        return "\n".join(parts) if parts else "(empty result)"

    except FileNotFoundError:
        return (
            "obsidian-cli is not installed. Install with:\n"
            "  macOS/Linux: brew tap yakitrak/yakitrak && brew install obsidian-cli\n"
            "  Go:          go install github.com/Yakitrak/obsidian-cli@latest\n"
            "  Or run:      openlama config obsidian install"
        )
    except Exception as e:
        return f"Obsidian CLI execution error: {e}"


_EXPAND_THRESHOLD = 20  # Expand subdirectory if it has ≤ this many items


async def _list_tree(vault_args: list[str], path: str, indent: int = 1, max_depth: int = 4) -> list[str]:
    """Recursively list directory tree with smart summarization.

    - If a subdirectory has ≤ _EXPAND_THRESHOLD items: expand fully.
    - If a subdirectory has > _EXPAND_THRESHOLD items: show summary "(N files, M folders)".
    - The model can drill into summarized folders with a separate list call.
    """
    if indent > max_depth:
        return []

    cmd = ["list"] + vault_args + [path]
    result = await _run_obsidian(cmd)
    if not result or result.startswith("[Error]") or result.startswith("obsidian-cli"):
        return []

    lines = [l.strip().lstrip("• ") for l in result.strip().split("\n") if l.strip()]
    prefix = "  " * indent
    output = []

    for line in lines:
        if line.endswith("/"):
            # Peek into subdirectory to decide expand vs summarize
            sub_path = path.rstrip("/") + "/" + line.rstrip("/")
            sub_cmd = ["list"] + vault_args + [sub_path]
            sub_result = await _run_obsidian(sub_cmd)
            if not sub_result or sub_result.startswith("[Error]"):
                output.append(f"{prefix}• {line}")
                continue

            sub_items = [l.strip().lstrip("• ") for l in sub_result.strip().split("\n") if l.strip()]
            n_files = sum(1 for s in sub_items if not s.endswith("/"))
            n_dirs = sum(1 for s in sub_items if s.endswith("/"))

            if len(sub_items) <= _EXPAND_THRESHOLD:
                # Small enough — expand fully
                output.append(f"{prefix}• {line}")
                output.extend(await _list_tree(vault_args, sub_path, indent + 1, max_depth))
            else:
                # Too many items — summarize
                summary_parts = []
                if n_files:
                    summary_parts.append(f"{n_files} files")
                if n_dirs:
                    summary_parts.append(f"{n_dirs} folders")
                summary = ", ".join(summary_parts)
                output.append(f"{prefix}• {line} ({summary}) — use list_recursive on this path for details")
        else:
            output.append(f"{prefix}• {line}")

    return output


async def _execute(args: dict) -> str:
    action = args.get("action", "").strip()
    vault = args.get("vault", "").strip() or None
    note = args.get("note", "").strip() or None
    content = args.get("content", "").strip() or None
    destination = args.get("destination", "").strip() or None
    query = args.get("query", "").strip() or None
    key = args.get("key", "").strip() or None
    value = args.get("value", "").strip() or None

    if not action:
        return (
            "Please specify an action:\n"
            "list, read, create, append, delete, move, search, "
            "search_content, daily, frontmatter_get, frontmatter_set, frontmatter_delete"
        )

    vault_args = ["-v", vault] if vault else []

    # ── List files/folders ──
    if action in ("list", "list_recursive"):
        recursive = action == "list_recursive" or args.get("recursive", False)
        cmd = ["list"] + vault_args
        if note and note not in ("/", ".", "./", "root"):
            cmd.append(note)
        result = await _run_obsidian(cmd)

        if not recursive:
            return result

        # Recursive: smart tree with auto-summarization
        lines = [l.strip().lstrip("• ") for l in result.strip().split("\n") if l.strip()]
        has_dirs = any(l.endswith("/") for l in lines)
        if not has_dirs:
            return result

        base = note.rstrip("/") + "/" if note and note not in ("/", ".", "./", "root") else ""
        all_lines = []
        for line in lines:
            if line.endswith("/"):
                sub_path = base + line.rstrip("/")
                all_lines.append(f"• {line}")
                all_lines.extend(await _list_tree(vault_args, sub_path, indent=1, max_depth=4))
            else:
                all_lines.append(f"• {line}")

        return "\n".join(all_lines) if all_lines else result

    # ── Read note ──
    if action == "read":
        if not note:
            return "Please specify the note parameter."
        cmd = ["print"] + vault_args + [note]
        return await _run_obsidian(cmd)

    # ── Create note ──
    if action == "create":
        if not note:
            return "Please specify the note parameter (e.g., 'folder/note_name')."
        cmd = ["create"] + vault_args + [note]
        if content:
            cmd += ["-c", content]
        return await _run_obsidian(cmd)

    # ── Append to note ──
    if action == "append":
        if not note:
            return "Please specify the note parameter."
        if not content:
            return "Please specify the content parameter."
        cmd = ["create", "-a"] + vault_args + [note, "-c", content]
        return await _run_obsidian(cmd)

    # ── Delete note ──
    if action == "delete":
        if not note:
            return "Please specify the note parameter."
        cmd = ["delete"] + vault_args + [note]
        return await _run_obsidian(cmd)

    # ── Move/rename note ──
    if action == "move":
        if not note:
            return "Please specify the note parameter (source note)."
        if not destination:
            return "Please specify the destination parameter (target path/name)."
        cmd = ["move"] + vault_args + [note, destination]
        return await _run_obsidian(cmd)

    # ── Fuzzy search by name ──
    if action == "search":
        if not query:
            return "Please specify the query parameter."
        cmd = ["search"] + vault_args + [query]
        return await _run_obsidian(cmd)

    # ── Search by content ──
    if action == "search_content":
        if not query:
            return "Please specify the query parameter."
        cmd = ["search-content"] + vault_args + [query]
        return await _run_obsidian(cmd)

    # ── Daily note ──
    if action == "daily":
        cmd = ["daily"] + vault_args
        return await _run_obsidian(cmd)

    # ── Frontmatter get ──
    if action == "frontmatter_get":
        if not note:
            return "Please specify the note parameter."
        cmd = ["frontmatter", "--print"] + vault_args + [note]
        return await _run_obsidian(cmd)

    # ── Frontmatter set ──
    if action == "frontmatter_set":
        if not note:
            return "Please specify the note parameter."
        if not key:
            return "Please specify the key parameter."
        if value is None:
            return "Please specify the value parameter."
        cmd = ["frontmatter", "--edit", "-k", key, "--value", value] + vault_args + [note]
        return await _run_obsidian(cmd)

    # ── Frontmatter delete ──
    if action == "frontmatter_delete":
        if not note:
            return "Please specify the note parameter."
        if not key:
            return "Please specify the key parameter."
        cmd = ["frontmatter", "--delete", "-k", key] + vault_args + [note]
        return await _run_obsidian(cmd)

    return f"Unknown action: {action}"


register_tool(
    name="obsidian",
    description=(
        "Obsidian note management tool. List, read, create, edit, delete, move, and search notes in a vault. "
        "Also supports frontmatter (YAML) viewing/editing and daily note creation."
    ),
    parameters={
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "description": (
                    "Action to perform: list (file list — current level only), "
                    "list_recursive (file list — includes all subdirectories and files), "
                    "read (read note), create (create note), "
                    "append (append to note), delete (delete note), move (move/rename note), "
                    "search (fuzzy search by name), search_content (search by content), daily (daily note), "
                    "frontmatter_get (view frontmatter), frontmatter_set (edit frontmatter), "
                    "frontmatter_delete (delete frontmatter key). "
                    "Use list_recursive when user asks for full directory structure or all files in a folder."
                ),
            },
            "note": {
                "type": "string",
                "description": "Note name or path (e.g., '000_INBOX/memo', 'MY_NOTE'). Used as folder path for list/list_recursive action",
            },
            "content": {
                "type": "string",
                "description": "Note content (used for create, append). Supports markdown",
            },
            "destination": {
                "type": "string",
                "description": "Destination path (used for move, e.g., '400_ARCHIVE/old_note')",
            },
            "query": {
                "type": "string",
                "description": "Search query (used for search, search_content)",
            },
            "vault": {
                "type": "string",
                "description": "Vault name (uses default vault if not specified)",
            },
            "key": {
                "type": "string",
                "description": "Frontmatter key (used for frontmatter_set, frontmatter_delete)",
            },
            "value": {
                "type": "string",
                "description": "Frontmatter value (used for frontmatter_set)",
            },
        },
        "required": ["action"],
    },
    execute=_execute,
    admin_only=True,
)
