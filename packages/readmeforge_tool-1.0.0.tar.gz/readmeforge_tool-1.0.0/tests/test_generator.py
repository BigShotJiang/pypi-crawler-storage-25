"""Tests for the ReadmeGenerator."""

from __future__ import annotations

from pathlib import Path

import pytest

from readmeforge.analyzer import ClassInfo, FunctionInfo, ProjectMetadata
from readmeforge.generator import ReadmeGenerator


def make_metadata(**kwargs) -> ProjectMetadata:
    defaults = dict(
        name="my-tool",
        description="A useful tool",
        version="1.0.0",
        author="Dev",
        license_type="MIT",
        language="Python",
        dependencies=["requests"],
        dev_dependencies=["pytest"],
        functions=[],
        classes=[],
        has_tests=True,
        has_cli=True,
        has_dockerfile=False,
        has_ci=True,
        entry_points=["my-tool"],
        project_root=Path("."),
    )
    defaults.update(kwargs)
    return ProjectMetadata(**defaults)


class TestReadmeGenerator:
    def test_generates_string(self):
        meta = make_metadata()
        content = ReadmeGenerator(meta).generate()
        assert isinstance(content, str)
        assert len(content) > 100

    def test_title_in_output(self):
        meta = make_metadata(name="super-tool")
        content = ReadmeGenerator(meta).generate()
        assert "Super Tool" in content

    def test_description_in_output(self):
        meta = make_metadata(description="Does amazing things")
        content = ReadmeGenerator(meta).generate()
        assert "Does amazing things" in content

    def test_badges_present(self):
        meta = make_metadata()
        content = ReadmeGenerator(meta).generate()
        assert "![" in content  # at least one badge

    def test_installation_section_python(self):
        meta = make_metadata(language="Python", entry_points=["my-tool"])
        content = ReadmeGenerator(meta).generate()
        assert "pip install" in content

    def test_installation_section_node(self):
        meta = make_metadata(language="JavaScript", entry_points=[])
        content = ReadmeGenerator(meta).generate()
        assert "npm install" in content

    def test_testing_section_present_when_tests(self):
        meta = make_metadata(has_tests=True)
        content = ReadmeGenerator(meta).generate()
        assert "pytest" in content or "npm test" in content

    def test_no_testing_section_without_tests(self):
        meta = make_metadata(has_tests=False)
        content = ReadmeGenerator(meta).generate()
        assert "## Testing" not in content

    def test_api_section_with_classes(self):
        meta = make_metadata(
            classes=[ClassInfo("MyClass", "Does stuff.", ["run", "stop"])]
        )
        content = ReadmeGenerator(meta).generate()
        assert "MyClass" in content
        assert "API Reference" in content

    def test_api_section_with_functions(self):
        meta = make_metadata(
            functions=[FunctionInfo("do_thing", "Does a thing.", ["path"], True)]
        )
        content = ReadmeGenerator(meta).generate()
        assert "do_thing" in content

    def test_contributing_section_always_present(self):
        meta = make_metadata()
        content = ReadmeGenerator(meta).generate()
        assert "Contributing" in content

    def test_license_section(self):
        meta = make_metadata(license_type="Apache-2.0", author="Alice")
        content = ReadmeGenerator(meta).generate()
        assert "Apache-2.0" in content
        assert "Alice" in content

    def test_unknown_template_falls_back_to_default(self):
        meta = make_metadata()
        gen = ReadmeGenerator(meta, template="nonexistent")
        assert gen.template == "default"

    def test_save_writes_file(self, tmp_path: Path):
        meta = make_metadata(project_root=tmp_path)
        gen = ReadmeGenerator(meta)
        out = gen.save()
        assert out.exists()
        assert out.read_text(encoding="utf-8") == gen.generate()
