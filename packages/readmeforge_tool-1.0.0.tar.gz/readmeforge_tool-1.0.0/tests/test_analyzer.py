"""Tests for the ProjectAnalyzer."""

from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest

from readmeforge.analyzer import ProjectAnalyzer


@pytest.fixture
def tmp_python_project(tmp_path: Path) -> Path:
    """Create a minimal Python project structure."""
    # pyproject.toml
    (tmp_path / "pyproject.toml").write_text(
        textwrap.dedent("""\
            [project]
            name = "myproject"
            version = "2.0.0"
            description = "A test project"
            authors = [{name = "Test Author"}]
            license = {text = "Apache-2.0"}
            dependencies = ["requests", "click"]
        """),
        encoding="utf-8",
    )

    # Source file
    src = tmp_path / "myproject"
    src.mkdir()
    (src / "__init__.py").write_text('__version__ = "2.0.0"')
    (src / "core.py").write_text(
        textwrap.dedent("""\
            class DataProcessor:
                \"\"\"Processes data.\"\"\"

                def process(self, data):
                    \"\"\"Process the data.\"\"\"
                    return data

                def _private(self):
                    pass

            def helper(path: str) -> str:
                \"\"\"Helper function.\"\"\"
                return path
        """)
    )

    # Tests directory
    tests = tmp_path / "tests"
    tests.mkdir()
    (tests / "test_core.py").write_text("def test_placeholder(): pass")

    # Dockerfile
    (tmp_path / "Dockerfile").write_text("FROM python:3.11-slim")

    # GitHub Actions
    gh = tmp_path / ".github" / "workflows"
    gh.mkdir(parents=True)
    (gh / "ci.yml").write_text("name: CI")

    return tmp_path


@pytest.fixture
def tmp_node_project(tmp_path: Path) -> Path:
    """Create a minimal Node.js project structure."""
    pkg = {
        "name": "my-node-app",
        "version": "1.2.3",
        "description": "A Node.js app",
        "author": "Node Dev",
        "license": "ISC",
        "dependencies": {"express": "^4.18.0", "axios": "^1.4.0"},
        "devDependencies": {"jest": "^29.0.0"},
    }
    (tmp_path / "package.json").write_text(json.dumps(pkg), encoding="utf-8")
    (tmp_path / "tsconfig.json").write_text("{}")
    return tmp_path


class TestProjectAnalyzer:
    def test_detects_python_language(self, tmp_python_project: Path):
        meta = ProjectAnalyzer(tmp_python_project).analyze()
        assert meta.language == "Python"

    def test_detects_typescript_language(self, tmp_node_project: Path):
        meta = ProjectAnalyzer(tmp_node_project).analyze()
        assert meta.language == "TypeScript"

    def test_extracts_python_metadata(self, tmp_python_project: Path):
        meta = ProjectAnalyzer(tmp_python_project).analyze()
        assert meta.name == "myproject"
        assert meta.version == "2.0.0"
        assert meta.description == "A test project"
        assert meta.author == "Test Author"
        assert meta.license_type == "Apache-2.0"
        assert "requests" in meta.dependencies
        assert "click" in meta.dependencies

    def test_extracts_node_metadata(self, tmp_node_project: Path):
        meta = ProjectAnalyzer(tmp_node_project).analyze()
        assert meta.name == "my-node-app"
        assert meta.version == "1.2.3"
        assert meta.author == "Node Dev"
        assert "express" in meta.dependencies
        assert "jest" in meta.dev_dependencies

    def test_detects_tests(self, tmp_python_project: Path):
        meta = ProjectAnalyzer(tmp_python_project).analyze()
        assert meta.has_tests is True

    def test_detects_dockerfile(self, tmp_python_project: Path):
        meta = ProjectAnalyzer(tmp_python_project).analyze()
        assert meta.has_dockerfile is True

    def test_detects_ci(self, tmp_python_project: Path):
        meta = ProjectAnalyzer(tmp_python_project).analyze()
        assert meta.has_ci is True

    def test_extracts_classes(self, tmp_python_project: Path):
        meta = ProjectAnalyzer(tmp_python_project).analyze()
        class_names = [c.name for c in meta.classes]
        assert "DataProcessor" in class_names

    def test_extracts_functions(self, tmp_python_project: Path):
        meta = ProjectAnalyzer(tmp_python_project).analyze()
        fn_names = [f.name for f in meta.functions]
        assert "helper" in fn_names

    def test_public_vs_private_functions(self, tmp_python_project: Path):
        meta = ProjectAnalyzer(tmp_python_project).analyze()
        private_fns = [f for f in meta.functions if not f.is_public]
        # _private method should not appear as top-level function
        private_names = [f.name for f in private_fns]
        assert "helper" not in private_names

    def test_raises_on_missing_path(self):
        with pytest.raises(FileNotFoundError):
            ProjectAnalyzer("/nonexistent/path/xyz").analyze()

    def test_no_tests_project(self, tmp_path: Path):
        (tmp_path / "pyproject.toml").write_text(
            "[project]\nname = 'bare'\nversion = '0.1.0'\n"
        )
        meta = ProjectAnalyzer(tmp_path).analyze()
        assert meta.has_tests is False

    def test_no_dockerfile(self, tmp_path: Path):
        (tmp_path / "pyproject.toml").write_text(
            "[project]\nname = 'bare'\nversion = '0.1.0'\n"
        )
        meta = ProjectAnalyzer(tmp_path).analyze()
        assert meta.has_dockerfile is False
