"""ReadmeForge — Auto-generate professional README files from your codebase."""

__version__ = "1.0.0"
__author__ = "NEXUS-DEV"
__license__ = "MIT"
