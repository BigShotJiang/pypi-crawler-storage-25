"""README generator — converts ProjectMetadata into a polished Markdown README."""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

from .analyzer import ProjectMetadata

# Badge templates
BADGE_LICENSE = "![License](https://img.shields.io/badge/license-{license}-blue.svg)"
BADGE_PYTHON = "![Python](https://img.shields.io/badge/python-3.10%2B-brightgreen.svg)"
BADGE_VERSION = "![Version](https://img.shields.io/badge/version-{version}-orange.svg)"
BADGE_TESTS = "![Tests](https://img.shields.io/badge/tests-passing-brightgreen.svg)"


class ReadmeGenerator:
    """Generates a professional README.md from ProjectMetadata."""

    TEMPLATES = {
        "default": "default",
        "cli": "cli",
        "library": "library",
        "saas": "saas",
        "marketplace": "marketplace",
    }

    def __init__(self, metadata: ProjectMetadata, template: str = "default") -> None:
        self.meta = metadata
        self.template = template if template in self.TEMPLATES else "default"

    def generate(self) -> str:
        """Generate the full README content as a string."""
        sections = [
            self._header(),
            self._badges(),
            self._description(),
            self._why_section(),
            self._features_section(),
            self._installation_section(),
            self._usage_section(),
            self._api_section(),
            self._testing_section(),
            self._contributing_section(),
            self._license_section(),
        ]
        return "\n\n".join(s for s in sections if s.strip())

    def save(self, output_path: str | Path | None = None) -> Path:
        """Write the README to disk. Defaults to project root/README.md."""
        if output_path is None:
            output_path = self.meta.project_root / "README.md"
        path = Path(output_path)
        path.write_text(self.generate(), encoding="utf-8")
        return path

    # ------------------------------------------------------------------ #
    # Section builders
    # ------------------------------------------------------------------ #

    def _header(self) -> str:
        name = self._title_case(self.meta.name)
        if self.meta.description:
            return f"# {name}\n\n> {self.meta.description}"
        return f"# {name}"

    def _badges(self) -> str:
        badges = []
        if self.meta.license_type:
            badges.append(
                BADGE_LICENSE.format(license=self.meta.license_type.replace(" ", "%20"))
            )
        if self.meta.version:
            badges.append(BADGE_VERSION.format(version=self.meta.version))
        if self.meta.language == "Python":
            badges.append(BADGE_PYTHON)
        if self.meta.has_tests:
            badges.append(BADGE_TESTS)
        return " ".join(badges) if badges else ""

    def _description(self) -> str:
        if not self.meta.description:
            return ""
        return dedent(f"""\
            ## What is {self._title_case(self.meta.name)}?

            {self.meta.description}
        """)

    def _why_section(self) -> str:
        name = self._title_case(self.meta.name)
        return dedent(f"""\
            ## Why {name}?

            - **Save time**: Automates repetitive tasks so you can focus on what matters.
            - **Zero config**: Works out of the box with sensible defaults.
            - **Production-ready**: Battle-tested and actively maintained.
        """)

    def _features_section(self) -> str:
        lines = ["## Features\n"]
        if self.meta.has_cli:
            lines.append("- Command-line interface (CLI) with intuitive commands")
        if self.meta.has_dockerfile:
            lines.append("- Docker support — containerize with a single command")
        if self.meta.has_tests:
            lines.append("- Full test suite included")
        if self.meta.has_ci:
            lines.append("- CI/CD pipeline configured out of the box")
        if self.meta.dependencies:
            lines.append(
                f"- Built with {', '.join(self.meta.dependencies[:5])}"
                + (" and more" if len(self.meta.dependencies) > 5 else "")
            )

        # Add features from public functions
        for fn in self.meta.functions:
            if fn.is_public and fn.docstring:
                first_line = fn.docstring.split("\n")[0].strip()
                lines.append(f"- **`{fn.name}`**: {first_line}")

        if len(lines) == 1:
            lines.append("- Core functionality ready to use")

        return "\n".join(lines)

    def _installation_section(self) -> str:
        name = self.meta.name
        lang = self.meta.language

        if lang == "Python":
            if self.meta.entry_points:
                return dedent(f"""\
                    ## Installation

                    ### Via pip (recommended)

                    ```bash
                    pip install {name}
                    ```

                    ### From source

                    ```bash
                    git clone https://github.com/yourusername/{name}.git
                    cd {name}
                    pip install -e .
                    ```

                    **Requirements:** Python 3.10+
                """)
            return dedent(f"""\
                ## Installation

                ```bash
                pip install {name}
                ```

                **Requirements:** Python 3.10+
            """)

        elif lang in ("JavaScript", "TypeScript"):
            return dedent(f"""\
                ## Installation

                ```bash
                npm install {name}
                # or
                yarn add {name}
                ```
            """)

        return dedent(f"""\
            ## Installation

            ```bash
            # Clone the repository
            git clone https://github.com/yourusername/{name}.git
            cd {name}
            ```
        """)

    def _usage_section(self) -> str:
        name = self.meta.name
        lang = self.meta.language
        sections = ["## Usage\n"]

        if self.meta.has_cli and self.meta.entry_points:
            entry = self.meta.entry_points[0]
            sections.append(dedent(f"""\
                ### Command-line

                ```bash
                # Basic usage
                {entry} --help

                # Run on current directory
                {entry} .

                # Specify output file
                {entry} . --output README.md
                ```
            """))

        if self.meta.classes:
            cls = self.meta.classes[0]
            if lang == "Python":
                method_examples = "\n".join(
                    f"    result = obj.{m}()" for m in cls.methods[:3]
                )
                sections.append(dedent(f"""\
                    ### Programmatic API

                    ```python
                    from {name} import {cls.name}

                    obj = {cls.name}("/path/to/project")
                    {method_examples}
                    print(result)
                    ```
                """))
        elif self.meta.functions:
            fn = next((f for f in self.meta.functions if f.is_public), None)
            if fn and lang == "Python":
                args_str = ", ".join(f'"{a}"' for a in fn.args[:2])
                sections.append(dedent(f"""\
                    ### Programmatic API

                    ```python
                    from {name} import {fn.name}

                    result = {fn.name}({args_str})
                    print(result)
                    ```
                """))

        return "\n".join(sections) if len(sections) > 1 else "## Usage\n\nSee documentation for usage examples."

    def _api_section(self) -> str:
        if not self.meta.classes and not self.meta.functions:
            return ""

        lines = ["## API Reference\n"]

        for cls in self.meta.classes[:5]:
            lines.append(f"### `{cls.name}`\n")
            if cls.docstring:
                lines.append(f"{cls.docstring}\n")
            if cls.methods:
                lines.append("**Methods:**")
                for m in cls.methods[:5]:
                    lines.append(f"- `{m}()`")
            lines.append("")

        for fn in self.meta.functions[:10]:
            if fn.is_public:
                args_str = ", ".join(fn.args)
                lines.append(f"### `{fn.name}({args_str})`\n")
                if fn.docstring:
                    lines.append(f"{fn.docstring}\n")

        return "\n".join(lines)

    def _testing_section(self) -> str:
        if not self.meta.has_tests:
            return ""
        lang = self.meta.language
        if lang == "Python":
            return dedent("""\
                ## Testing

                ```bash
                pip install pytest
                pytest tests/ -v
                ```
            """)
        elif lang in ("JavaScript", "TypeScript"):
            return dedent("""\
                ## Testing

                ```bash
                npm test
                ```
            """)
        return ""

    def _contributing_section(self) -> str:
        return dedent("""\
            ## Contributing

            Contributions are welcome! Please:

            1. Fork the repository
            2. Create a feature branch (`git checkout -b feature/amazing-feature`)
            3. Commit your changes (`git commit -m 'feat: add amazing feature'`)
            4. Push to the branch (`git push origin feature/amazing-feature`)
            5. Open a Pull Request
        """)

    def _license_section(self) -> str:
        license_type = self.meta.license_type or "MIT"
        author = self.meta.author or "the authors"
        return f"## License\n\n[{license_type}](LICENSE) © {author}"

    # ------------------------------------------------------------------ #
    # Utilities
    # ------------------------------------------------------------------ #

    @staticmethod
    def _title_case(name: str) -> str:
        """Convert snake-case or kebab-case to Title Case."""
        return name.replace("-", " ").replace("_", " ").title()
