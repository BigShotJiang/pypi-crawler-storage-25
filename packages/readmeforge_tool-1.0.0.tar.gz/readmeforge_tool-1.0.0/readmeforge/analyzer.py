"""Project analyzer — inspects source code and extracts metadata."""

from __future__ import annotations

import ast
import json
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class FunctionInfo:
    name: str
    docstring: str
    args: list[str]
    is_public: bool


@dataclass
class ClassInfo:
    name: str
    docstring: str
    methods: list[str]


@dataclass
class ProjectMetadata:
    name: str
    description: str
    version: str
    author: str
    license_type: str
    language: str
    dependencies: list[str]
    dev_dependencies: list[str]
    functions: list[FunctionInfo]
    classes: list[ClassInfo]
    has_tests: bool
    has_cli: bool
    has_dockerfile: bool
    has_ci: bool
    entry_points: list[str]
    project_root: Path


class ProjectAnalyzer:
    """Analyzes a project directory and extracts structured metadata."""

    IGNORE_DIRS = {
        ".git", "__pycache__", "node_modules", ".venv", "venv",
        "env", ".env", "dist", "build", ".mypy_cache", ".pytest_cache",
        "site-packages", ".tox",
    }

    def __init__(self, project_path: str | Path) -> None:
        self.root = Path(project_path).resolve()
        if not self.root.exists():
            raise FileNotFoundError(f"Project path not found: {self.root}")

    def analyze(self) -> ProjectMetadata:
        """Run full project analysis and return structured metadata."""
        language = self._detect_language()
        name, description, version, author, license_type, deps, dev_deps = (
            self._extract_package_info(language)
        )
        functions, classes = self._extract_code_symbols(language)
        entry_points = self._detect_entry_points(language)

        return ProjectMetadata(
            name=name,
            description=description,
            version=version,
            author=author,
            license_type=license_type,
            language=language,
            dependencies=deps,
            dev_dependencies=dev_deps,
            functions=functions,
            classes=classes,
            has_tests=self._has_tests(),
            has_cli=self._has_cli(entry_points),
            has_dockerfile=(self.root / "Dockerfile").exists(),
            has_ci=self._has_ci(),
            entry_points=entry_points,
            project_root=self.root,
        )

    # ------------------------------------------------------------------ #
    # Language detection
    # ------------------------------------------------------------------ #

    def _detect_language(self) -> str:
        """Return the primary language of the project."""
        indicators = {
            "Python": ["setup.py", "pyproject.toml", "requirements.txt", "setup.cfg"],
            "TypeScript": ["tsconfig.json"],
            "JavaScript": ["package.json"],
            "Rust": ["Cargo.toml"],
            "Go": ["go.mod"],
        }
        for lang, files in indicators.items():
            if any((self.root / f).exists() for f in files):
                return lang
        return "Unknown"

    # ------------------------------------------------------------------ #
    # Package metadata
    # ------------------------------------------------------------------ #

    def _extract_package_info(
        self, language: str
    ) -> tuple[str, str, str, str, str, list[str], list[str]]:
        """Extract name, description, version, author, license, deps from manifest."""
        name = self.root.name
        description = ""
        version = "0.1.0"
        author = ""
        license_type = "MIT"
        deps: list[str] = []
        dev_deps: list[str] = []

        if language == "Python":
            name, description, version, author, license_type, deps, dev_deps = (
                self._parse_python_package()
            )
        elif language in ("JavaScript", "TypeScript"):
            name, description, version, author, license_type, deps, dev_deps = (
                self._parse_node_package()
            )

        return name, description, version, author, license_type, deps, dev_deps

    def _parse_python_package(self) -> tuple:
        """Parse pyproject.toml or setup.py."""
        pyproject = self.root / "pyproject.toml"
        setup_py = self.root / "setup.py"
        requirements = self.root / "requirements.txt"

        name = self.root.name
        description = ""
        version = "0.1.0"
        author = ""
        license_type = "MIT"
        deps: list[str] = []
        dev_deps: list[str] = []

        if pyproject.exists():
            try:
                import tomllib  # Python 3.11+
            except ImportError:
                try:
                    import tomli as tomllib  # type: ignore[no-redef]
                except ImportError:
                    tomllib = None  # type: ignore[assignment]

            if tomllib:
                with open(pyproject, "rb") as f:
                    data = tomllib.load(f)
                project = data.get("project", {})
                name = project.get("name", name)
                description = project.get("description", "")
                version = project.get("version", version)
                authors = project.get("authors", [])
                if authors:
                    author = authors[0].get("name", "")
                license_info = project.get("license", {})
                if isinstance(license_info, dict):
                    license_type = license_info.get("text", license_type)
                deps = [str(d) for d in project.get("dependencies", [])]

        elif setup_py.exists():
            content = setup_py.read_text(encoding="utf-8")
            name = self._extract_setup_field(content, "name") or name
            description = self._extract_setup_field(content, "description") or ""
            version = self._extract_setup_field(content, "version") or version

        if requirements.exists():
            lines = requirements.read_text(encoding="utf-8").splitlines()
            deps = [l.strip() for l in lines if l.strip() and not l.startswith("#")]

        return name, description, version, author, license_type, deps, dev_deps

    def _parse_node_package(self) -> tuple:
        """Parse package.json."""
        pkg = self.root / "package.json"
        name = self.root.name
        description = ""
        version = "0.1.0"
        author = ""
        license_type = "MIT"
        deps: list[str] = []
        dev_deps: list[str] = []

        if pkg.exists():
            data = json.loads(pkg.read_text(encoding="utf-8"))
            name = data.get("name", name)
            description = data.get("description", "")
            version = data.get("version", version)
            author_raw = data.get("author", "")
            author = author_raw if isinstance(author_raw, str) else author_raw.get("name", "")
            license_type = data.get("license", license_type)
            deps = list(data.get("dependencies", {}).keys())
            dev_deps = list(data.get("devDependencies", {}).keys())

        return name, description, version, author, license_type, deps, dev_deps

    @staticmethod
    def _extract_setup_field(content: str, field: str) -> str | None:
        pattern = rf'{field}\s*=\s*["\']([^"\']+)["\']'
        match = re.search(pattern, content)
        return match.group(1) if match else None

    # ------------------------------------------------------------------ #
    # Code symbol extraction
    # ------------------------------------------------------------------ #

    def _extract_code_symbols(
        self, language: str
    ) -> tuple[list[FunctionInfo], list[ClassInfo]]:
        """Extract top-level functions and classes from source files."""
        functions: list[FunctionInfo] = []
        classes: list[ClassInfo] = []

        if language == "Python":
            for py_file in self._iter_source_files("*.py"):
                f, c = self._parse_python_file(py_file)
                functions.extend(f)
                classes.extend(c)

        # Limit to first 20 of each to avoid bloated output
        return functions[:20], classes[:20]

    def _parse_python_file(
        self, path: Path
    ) -> tuple[list[FunctionInfo], list[ClassInfo]]:
        """Use AST to extract functions and classes from a Python file."""
        functions: list[FunctionInfo] = []
        classes: list[ClassInfo] = []

        try:
            source = path.read_text(encoding="utf-8")
            tree = ast.parse(source)
        except (SyntaxError, UnicodeDecodeError):
            return functions, classes

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and not isinstance(
                node, ast.AsyncFunctionDef
            ):
                docstring = ast.get_docstring(node) or ""
                args = [a.arg for a in node.args.args if a.arg != "self"]
                functions.append(
                    FunctionInfo(
                        name=node.name,
                        docstring=docstring,
                        args=args,
                        is_public=not node.name.startswith("_"),
                    )
                )
            elif isinstance(node, ast.ClassDef):
                docstring = ast.get_docstring(node) or ""
                methods = [
                    n.name
                    for n in ast.walk(node)
                    if isinstance(n, ast.FunctionDef) and not n.name.startswith("_")
                ]
                classes.append(
                    ClassInfo(name=node.name, docstring=docstring, methods=methods)
                )

        return functions, classes

    # ------------------------------------------------------------------ #
    # Feature detection
    # ------------------------------------------------------------------ #

    def _has_tests(self) -> bool:
        test_indicators = ["tests/", "test/", "spec/", "pytest.ini", "tox.ini"]
        return any(
            (self.root / ind).exists() for ind in test_indicators
        ) or bool(list(self.root.rglob("test_*.py")))

    def _has_cli(self, entry_points: list[str]) -> bool:
        return bool(entry_points)

    def _has_ci(self) -> bool:
        ci_paths = [
            ".github/workflows",
            ".gitlab-ci.yml",
            ".circleci/config.yml",
            "Jenkinsfile",
        ]
        return any((self.root / p).exists() for p in ci_paths)

    def _detect_entry_points(self, language: str) -> list[str]:
        """Detect CLI entry points."""
        entry_points: list[str] = []

        if language == "Python":
            pyproject = self.root / "pyproject.toml"
            if pyproject.exists():
                content = pyproject.read_text(encoding="utf-8")
                # Find [project.scripts] section entries
                matches = re.findall(r'(\w[\w-]*)\s*=\s*"[\w.]+:[\w.]+"', content)
                entry_points.extend(matches)

        return entry_points

    # ------------------------------------------------------------------ #
    # File iteration
    # ------------------------------------------------------------------ #

    def _iter_source_files(self, pattern: str):
        """Yield source files matching pattern, excluding ignored directories."""
        for path in self.root.rglob(pattern):
            if not any(part in self.IGNORE_DIRS for part in path.parts):
                yield path
