"""ReadmeForge CLI — Command-line interface."""

from __future__ import annotations

import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.syntax import Syntax
from rich.table import Table

from .analyzer import ProjectAnalyzer
from .generator import ReadmeGenerator

app = typer.Typer(
    name="readmeforge",
    help="Generate professional README files from your codebase in seconds.",
    add_completion=False,
)
console = Console()


@app.command()
def generate(
    project_path: str = typer.Argument(
        ".",
        help="Path to the project directory to analyze.",
    ),
    output: str = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file path. Defaults to <project>/README.md",
    ),
    template: str = typer.Option(
        "default",
        "--template",
        "-t",
        help="README template: default | cli | library | saas | marketplace",
    ),
    preview: bool = typer.Option(
        False,
        "--preview",
        "-p",
        help="Preview the generated README without saving.",
    ),
    overwrite: bool = typer.Option(
        False,
        "--overwrite",
        "-f",
        help="Overwrite existing README.md without confirmation.",
    ),
) -> None:
    """Generate a professional README.md for your project.

    Examples:

        readmeforge .

        readmeforge /path/to/project --template cli

        readmeforge . --preview

        readmeforge . -o docs/README.md --overwrite
    """
    path = Path(project_path).resolve()

    if not path.exists():
        console.print(f"[red]Error:[/red] Path does not exist: {path}")
        raise typer.Exit(code=1)

    console.print(
        Panel.fit(
            "[bold cyan]ReadmeForge[/bold cyan] — Professional README Generator",
            border_style="cyan",
        )
    )

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("Analyzing project...", total=None)
        try:
            analyzer = ProjectAnalyzer(path)
            metadata = analyzer.analyze()
        except Exception as e:
            console.print(f"[red]Analysis failed:[/red] {e}")
            raise typer.Exit(code=1)

        progress.update(task, description="Generating README...")
        generator = ReadmeGenerator(metadata, template=template)
        content = generator.generate()

    # Show summary table
    table = Table(title="Project Analysis Summary", show_header=True)
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="white")
    table.add_row("Name", metadata.name)
    table.add_row("Language", metadata.language)
    table.add_row("Version", metadata.version)
    table.add_row("Author", metadata.author or "—")
    table.add_row("License", metadata.license_type)
    table.add_row("Functions found", str(len(metadata.functions)))
    table.add_row("Classes found", str(len(metadata.classes)))
    table.add_row("Has tests", "Yes" if metadata.has_tests else "No")
    table.add_row("Has CLI", "Yes" if metadata.has_cli else "No")
    table.add_row("Has Dockerfile", "Yes" if metadata.has_dockerfile else "No")
    table.add_row("Has CI/CD", "Yes" if metadata.has_ci else "No")
    console.print(table)
    console.print()

    if preview:
        # Show preview in terminal
        console.print(Panel("[bold]README Preview[/bold]", border_style="green"))
        syntax = Syntax(content, "markdown", theme="monokai", word_wrap=True)
        console.print(syntax)
        return

    # Determine output path
    out_path = Path(output) if output else path / "README.md"

    if out_path.exists() and not overwrite:
        confirm = typer.confirm(
            f"[yellow]{out_path}[/yellow] already exists. Overwrite?",
            default=False,
        )
        if not confirm:
            console.print("[yellow]Aborted.[/yellow]")
            raise typer.Exit(code=0)

    out_path.write_text(content, encoding="utf-8")
    console.print(f"[green]README generated:[/green] {out_path}")
    console.print(
        f"[dim]({len(content)} characters, "
        f"~{len(content.split()) } words)[/dim]"
    )


@app.command()
def analyze(
    project_path: str = typer.Argument(".", help="Path to analyze."),
) -> None:
    """Analyze a project and display extracted metadata (no README generated)."""
    path = Path(project_path).resolve()

    try:
        metadata = ProjectAnalyzer(path).analyze()
    except FileNotFoundError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=1)

    console.print(Panel.fit(f"Analysis: [bold]{metadata.name}[/bold]"))

    if metadata.functions:
        console.print("\n[bold cyan]Public Functions:[/bold cyan]")
        for fn in metadata.functions:
            if fn.is_public:
                args = ", ".join(fn.args)
                doc = fn.docstring.split("\n")[0] if fn.docstring else "No docstring"
                console.print(f"  [green]{fn.name}[/green]({args}) — {doc}")

    if metadata.classes:
        console.print("\n[bold cyan]Classes:[/bold cyan]")
        for cls in metadata.classes:
            doc = cls.docstring.split("\n")[0] if cls.docstring else "No docstring"
            console.print(f"  [blue]{cls.name}[/blue] — {doc}")
            for m in cls.methods[:5]:
                console.print(f"    • {m}()")


@app.command()
def version() -> None:
    """Show ReadmeForge version."""
    from . import __version__
    console.print(f"ReadmeForge v{__version__}")


def main() -> None:
    """Entry point."""
    app()


if __name__ == "__main__":
    main()
