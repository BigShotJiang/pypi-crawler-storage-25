# ReadmeForge CLI

> Auto-generate professional README files from your codebase in 30 seconds.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Version](https://img.shields.io/badge/version-1.0.0-orange.svg)
![Python](https://img.shields.io/badge/python-3.10%2B-brightgreen.svg)
![Tests](https://img.shields.io/badge/tests-passing-brightgreen.svg)

---

## The Problem

Every developer knows the pain: you build something great, then spend 2+ hours writing a README. Or you skip it entirely, and nobody uses your project.

**ReadmeForge solves this.** Point it at any project directory, and it generates a professional, structured README in seconds.

---

## What ReadmeForge Does

- Analyzes your project structure automatically
- Detects language (Python, JavaScript/TypeScript, Rust, Go)
- Extracts functions, classes, and their docstrings
- Reads package metadata (name, version, author, license, dependencies)
- Detects features: CLI, tests, Docker, CI/CD
- Generates a complete README with: badges, installation, usage, API docs, contributing guide

---

## Installation

### Via pip

```bash
pip install readmeforge
```

### From source

```bash
git clone https://github.com/nexusdev/readmeforge.git
cd readmeforge
pip install -e .
```

**Requirements:** Python 3.10+

---

## Usage

### Generate a README for the current directory

```bash
readmeforge .
```

### Preview without saving

```bash
readmeforge . --preview
```

### Specify output path

```bash
readmeforge /path/to/project --output docs/README.md
```

### Choose a template

```bash
readmeforge . --template cli        # For CLI tools
readmeforge . --template library    # For Python libraries
readmeforge . --template saas       # For SaaS projects
readmeforge . --template marketplace # For products sold on Gumroad/LemonSqueezy
```

### Analyze without generating

```bash
readmeforge analyze /path/to/project
```

---

## Example Output

Given a Python project with:
- `pyproject.toml` with name, version, description
- A class `DataProcessor` with methods and docstrings
- A `tests/` directory
- A `Dockerfile`
- `.github/workflows/ci.yml`

ReadmeForge generates a README with:
- Project title and description
- Badges (license, version, Python version, tests passing)
- Installation instructions with pip command
- Usage examples showing the API
- API Reference with all public classes and functions
- Testing section with pytest command
- Contributing guide
- License section

---

## Options

| Option | Short | Default | Description |
|--------|-------|---------|-------------|
| `--output` | `-o` | `<project>/README.md` | Output file path |
| `--template` | `-t` | `default` | README template style |
| `--preview` | `-p` | `False` | Preview without saving |
| `--overwrite` | `-f` | `False` | Overwrite without confirmation |

---

## Supported Languages

| Language | Package Detection | Code Analysis |
|----------|------------------|---------------|
| Python | `pyproject.toml`, `setup.py`, `requirements.txt` | Full AST analysis |
| JavaScript | `package.json` | Package metadata |
| TypeScript | `tsconfig.json` + `package.json` | Package metadata |
| Rust | `Cargo.toml` | Package metadata |
| Go | `go.mod` | Package metadata |

---

## Testing

```bash
pip install pytest pytest-cov
pytest tests/ -v
```

---

## Changelog

### v1.0.0 (March 2026)
- Initial release
- Python, JavaScript, TypeScript, Rust, Go support
- 5 README templates
- Rich terminal output with progress indicator
- Full test suite

---

## License

[MIT](LICENSE) © NEXUS-DEV

---

## Links

- [Gumroad (buy)](https://gumroad.com/l/readmeforge)
- [GitHub](https://github.com/nexusdev/readmeforge)
- [Issues](https://github.com/nexusdev/readmeforge/issues)
