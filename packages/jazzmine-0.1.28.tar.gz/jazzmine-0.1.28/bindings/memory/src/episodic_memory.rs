
#![allow(deprecated, non_local_definitions, unsafe_op_in_unsafe_fn, unused_variables)]

use pyo3::prelude::*;
use pyo3::types::PyDict;
use pyo3_asyncio::tokio::future_into_py;
use qdrant_client::qdrant::{
    Condition, Filter, SearchPoints, ScoredPoint, Value as QdrantValue,
    with_payload_selector::SelectorOptions, WithPayloadSelector, Vector, DenseVector, Vectors,
    PointStruct, SparseVector,
};
use qdrant_client::qdrant::vector;
use std::collections::HashMap;
use std::sync::Arc;
use uuid::Uuid;

use crate::embed::{Embedder, LocalConfig, RemoteConfig};
use crate::init::QdrantManager;
use crate::provider_utils::resolve_remote_provider_config;

#[pyclass]
pub struct EpisodicMemory {
    client: Arc<qdrant_client::Qdrant>,
    embedder: Arc<Embedder>,
    collection_name: String,
}

#[derive(Debug, Clone)]
struct RankedEpisode {
    point_id: String,
    score: f32,
    payload: HashMap<String, QdrantValue>,
}

#[allow(non_local_definitions)]
#[pymethods]
impl EpisodicMemory {
    #[new]
    #[pyo3(signature = (
        qdrant_manager,
        tokenizer_path,
        // Option 1: Local
        model_dir=None,
        quantized=false,
        // Option 2: Remote (Universal)
        api_key=None,
        base_url=None,
        model_name=None,
        provider="openai".to_string(), // Default to openai as it covers vLLM/Ollama
        // Common
        hidden_size=384,
        max_batch=8
    ))]
    pub fn new(
        qdrant_manager: Py<QdrantManager>,
        tokenizer_path: String,
        // Local args
        model_dir: Option<String>,
        quantized: bool,
        // Remote args
        api_key: Option<String>,
        base_url: Option<String>,
        model_name: Option<String>,
        provider: Option<String>,
        // Common args
        hidden_size: usize,
        max_batch: usize,
    ) -> PyResult<Self> {
        Python::with_gil(|py| {
            let qdrant_ref = qdrant_manager.borrow(py);
            let client = qdrant_ref.client();
            let collection_name = qdrant_ref.conversation_summaries_collection_name();

            let embedder = Arc::new(
                Embedder::new(tokenizer_path, hidden_size, max_batch)
                    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))?,
            );

            // Logic to choose backend
            if let Some(dir) = model_dir {
                // Case 1: Local ONNX
                let config = LocalConfig {
                    model_dir: dir,
                    quantized,
                };
                embedder.setup_local(config)
                    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!("Local setup failed: {}", e)))?;

            } else if let Some(key) = api_key {
                // Case 2: Remote API (Universal)
                let (prov_enum, url, model) =
                    resolve_remote_provider_config(provider, base_url, model_name);

                let config = RemoteConfig {
                    provider: prov_enum,
                    api_key: key,
                    base_url: url,
                    model_name: model,
                };
                
                embedder.setup_remote(config)
                    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!("Remote setup failed: {}", e)))?;
                
            } else {
                return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                    "Must provide either 'model_dir' (Local) or 'api_key' (Remote)."
                ));
            }

            Ok(EpisodicMemory {
                client,
                embedder,
                collection_name,
            })
        })
    }

    #[pyo3(signature = (
        short_summary,
        long_summary,
        start_index,
        end_index,
        user_id,
        agent_id,
        conversation_id,
        overlap,
        flows_activated,
        tools_invoked,
        timestamp_begin,
        timestamp_end,
        average_user_sentiment,
        user_sentiment_variance
    ))]
    pub fn memorize<'py>(
        &self,
        py: Python<'py>,
        short_summary: String,
        long_summary: String,
        start_index: i64,
        end_index: i64,
        user_id: String,
        agent_id: String,
        conversation_id: String,
        overlap: i64,
        flows_activated: Vec<String>,
        tools_invoked: Vec<String>,
        timestamp_begin: i64,
        timestamp_end: i64,
        average_user_sentiment: f64,
        user_sentiment_variance: f64,
    ) -> PyResult<&'py PyAny> {
        let embedder = Arc::clone(&self.embedder);
        let client = Arc::clone(&self.client);
        let collection_name = self.collection_name.clone();

        future_into_py(py, async move {
            let bm25_text = format!("{} {}", short_summary, long_summary);
            
            // Generate dense embeddings concurrently
            let (short_result, long_result) = tokio::join!(
                embedder.embed_high_priority(&short_summary),
                embedder.embed_high_priority(&long_summary)
            );

            let short_embedding = short_result.map_err(|e| {
                PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!("Failed to embed short summary: {}", e))
            })?;

            let long_embedding = long_result.map_err(|e| {
                PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!("Failed to embed long summary: {}", e))
            })?;

            // Generate sparse embedding (BM25)
            let (bm25_indices, bm25_values) = embedder.compute_sparse_vector(&bm25_text).map_err(|e| {
                PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!("Failed to generate sparse vector: {}", e))
            })?;

            let point_id = Uuid::new_v4().to_string();

            let mut vectors_map = HashMap::new();
            vectors_map.insert(
                "short_summary".to_string(),
                Vector {
                    data: Vec::new(),
                    indices: None,
                    vectors_count: None,
                    vector: Some(vector::Vector::Dense(DenseVector {
                        data: short_embedding,
                    })),
                },
            );
            vectors_map.insert(
                "long_summary".to_string(),
                Vector {
                    data: Vec::new(),
                    indices: None,
                    vectors_count: None,
                    vector: Some(vector::Vector::Dense(DenseVector {
                        data: long_embedding,
                    })),
                },
            );
            vectors_map.insert(
                "bm25".to_string(),
                Vector {
                    data: Vec::new(),
                    indices: None,
                    vectors_count: None,
                    vector: Some(vector::Vector::Sparse(SparseVector {
                        indices: bm25_indices,
                        values: bm25_values,
                    })),
                },
            );

            let mut payload = HashMap::new();
            payload.insert("short_summary_text".to_string(), QdrantValue::from(short_summary));
            payload.insert("long_summary_text".to_string(), QdrantValue::from(long_summary));
            payload.insert("start_index".to_string(), QdrantValue::from(start_index));
            payload.insert("end_index".to_string(), QdrantValue::from(end_index));
            payload.insert("user_id".to_string(), QdrantValue::from(user_id));
            payload.insert("agent_id".to_string(), QdrantValue::from(agent_id));
            payload.insert("conversation_id".to_string(), QdrantValue::from(conversation_id));
            payload.insert("overlap".to_string(), QdrantValue::from(overlap));
            payload.insert(
                "flows_activated".to_string(),
                QdrantValue::from(flows_activated.into_iter().map(QdrantValue::from).collect::<Vec<_>>()),
            );
            payload.insert(
                "tools_invoked".to_string(),
                QdrantValue::from(tools_invoked.into_iter().map(QdrantValue::from).collect::<Vec<_>>()),
            );
            payload.insert("timestamp_begin".to_string(), QdrantValue::from(timestamp_begin));
            payload.insert("timestamp_end".to_string(), QdrantValue::from(timestamp_end));
            payload.insert("average_user_sentiment".to_string(), QdrantValue::from(average_user_sentiment));
            payload.insert("user_sentiment_variance".to_string(), QdrantValue::from(user_sentiment_variance));

            let point = PointStruct {
                id: Some(qdrant_client::qdrant::PointId {
                    point_id_options: Some(qdrant_client::qdrant::point_id::PointIdOptions::Uuid(
                        point_id.clone(),
                    )),
                }),
                vectors: Some(Vectors {
                    vectors_options: Some(qdrant_client::qdrant::vectors::VectorsOptions::Vectors(
                        qdrant_client::qdrant::NamedVectors {
                            vectors: vectors_map,
                        },
                    )),
                }),
                payload,
            };

            client
                .upsert_points(qdrant_client::qdrant::UpsertPointsBuilder::new(
                    collection_name,
                    vec![point],
                ))
                .await
                .map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!("Upsert failed: {}", e))
                })?;

            Ok(point_id)
        })
    }

    #[pyo3(signature = (
        user_id,
        agent_id,
        conversation_id,
        query,
        previous_conversation_limit=10,
        same_conversation_limit=5,
        short_weight=0.2, 
        long_weight=0.3, 
        bm25_weight=0.5, 
        stage1_limit=100, // Cast wider net for RRF
        rrf_k=10      
    ))]
    pub fn recall<'py>(
        &self,
        py: Python<'py>,
        user_id: String,
        agent_id: String,
        conversation_id: String,
        query: String,
        previous_conversation_limit: usize,
        same_conversation_limit: usize,
        short_weight: f32,
        long_weight: f32,
        bm25_weight: f32,
        stage1_limit: u64,
        rrf_k: u64,
    ) -> PyResult<&'py PyAny> {
        let embedder = Arc::clone(&self.embedder);
        let client = Arc::clone(&self.client);
        let collection_name = self.collection_name.clone();

        future_into_py(py, async move {
            // Stage 1a: Embed query
            let query_embedding = embedder.embed_high_priority(&query).await.map_err(|e| {
                PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!("Embed query failed: {}", e))
            })?;

            // Stage 1b: Sparse query
            let (bm25_indices, bm25_values) = embedder.compute_sparse_vector(&query).map_err(|e| {
                PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!("Sparse query failed: {}", e))
            })?;
            
            // Stage 2: Filter construction
            let filter = Filter {
                must: vec![
                    Condition {
                        condition_one_of: Some(qdrant_client::qdrant::condition::ConditionOneOf::Field(
                            qdrant_client::qdrant::FieldCondition {
                                key: "user_id".to_string(),
                                r#match: Some(qdrant_client::qdrant::Match {
                                    match_value: Some(qdrant_client::qdrant::r#match::MatchValue::Keyword(
                                        user_id.clone(),
                                    )),
                                }),
                                ..Default::default()
                            },
                        )),
                    },
                    Condition {
                        condition_one_of: Some(qdrant_client::qdrant::condition::ConditionOneOf::Field(
                            qdrant_client::qdrant::FieldCondition {
                                key: "agent_id".to_string(),
                                r#match: Some(qdrant_client::qdrant::Match {
                                    match_value: Some(qdrant_client::qdrant::r#match::MatchValue::Keyword(
                                        agent_id.clone(),
                                    )),
                                }),
                                ..Default::default()
                            },
                        )),
                    },
                ],
                ..Default::default()
            };

            // Stage 3: Construct Search Requests
            let short_search = SearchPoints {
                collection_name: collection_name.clone(),
                vector: query_embedding.clone(),
                vector_name: Some("short_summary".to_string()),
                filter: Some(filter.clone()),
                limit: stage1_limit,
                with_payload: Some(WithPayloadSelector {
                    selector_options: Some(SelectorOptions::Enable(true)),
                }),
                ..Default::default()
            };

            let long_search = SearchPoints {
                collection_name: collection_name.clone(),
                vector: query_embedding.clone(),
                vector_name: Some("long_summary".to_string()),
                filter: Some(filter.clone()),
                limit: stage1_limit,
                with_payload: Some(WithPayloadSelector {
                    selector_options: Some(SelectorOptions::Enable(true)),
                }),
                ..Default::default()
            };

            let bm25_search = SearchPoints {
                collection_name: collection_name.clone(),
                sparse_indices: Some(qdrant_client::qdrant::SparseIndices { data: bm25_indices }),
                vector: bm25_values,
                vector_name: Some("bm25".to_string()),
                filter: Some(filter),
                limit: stage1_limit,
                with_payload: Some(WithPayloadSelector {
                    selector_options: Some(SelectorOptions::Enable(true)),
                }),
                ..Default::default()
            };

            // Stage 4: Execute Searches
            let (short_results, long_results, bm25_results) = tokio::try_join!(
                client.search_points(short_search),
                client.search_points(long_search),
                client.search_points(bm25_search)
            ).map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!("Search failed: {}", e)))?;

            // Stage 5: Reciprocal Rank Fusion (RRF)
            let mut score_map: HashMap<String, (f32, HashMap<String, QdrantValue>)> = HashMap::new();
            let rrf_constant = rrf_k as f32;

            // Process Short Summary Results
            for (rank_idx, point) in short_results.result.into_iter().enumerate() {
                if let Some(id) = Self::extract_point_id(&point) {
                    let rank = (rank_idx + 1) as f32;
                    let rrf_score = short_weight * (1.0 / (rrf_constant + rank));
                    score_map
                        .entry(id)
                        .and_modify(|(v, _)| *v += rrf_score)
                        .or_insert((rrf_score, point.payload));
                }
            }

            // Process Long Summary Results
            for (rank_idx, point) in long_results.result.into_iter().enumerate() {
                if let Some(id) = Self::extract_point_id(&point) {
                    let rank = (rank_idx + 1) as f32;
                    let rrf_score = long_weight * (1.0 / (rrf_constant + rank));
                    score_map
                        .entry(id)
                        .and_modify(|(v, _)| *v += rrf_score)
                        .or_insert((rrf_score, point.payload));
                }
            }

            // Process BM25 Results
            for (rank_idx, point) in bm25_results.result.into_iter().enumerate() {
                if let Some(id) = Self::extract_point_id(&point) {
                    let rank = (rank_idx + 1) as f32;
                    let rrf_score = bm25_weight * (1.0 / (rrf_constant + rank));
                    score_map
                        .entry(id)
                        .and_modify(|(v, _)| *v += rrf_score)
                        .or_insert((rrf_score, point.payload));
                }
            }

            // Stage 6: Sort and Filter by Conversation ID
            let episodes: Vec<RankedEpisode> = score_map
                .into_iter()
                .map(|(id, (score, payload))| RankedEpisode {
                    point_id: id,
                    score,
                    payload,
                })
                .collect();

            let mut same_conv = Vec::new();
            let mut prev_conv = Vec::new();

            for episode in episodes {
                let is_same = episode
                    .payload
                    .get("conversation_id")
                    .and_then(|v| {
                        if let Some(qdrant_client::qdrant::value::Kind::StringValue(s)) = &v.kind {
                            Some(s == &conversation_id)
                        } else {
                            None
                        }
                    })
                    .unwrap_or(false);

                if is_same {
                    same_conv.push(episode);
                } else {
                    prev_conv.push(episode);
                }
            }

            // Stage 7: Sort descending by RRF score
            same_conv.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap());
            same_conv.truncate(same_conversation_limit);

            prev_conv.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap());
            prev_conv.truncate(previous_conversation_limit);

            // Stage 8: Convert to Python Dicts
            Python::with_gil(|py| {
                let result_dict = PyDict::new(py);
                
                let same_conv_py = same_conv
                    .iter()
                    .map(|ep| Self::episode_to_pydict(py, ep))
                    .collect::<PyResult<Vec<_>>>()?;
                
                let prev_conv_py = prev_conv
                    .iter()
                    .map(|ep| Self::episode_to_pydict(py, ep))
                    .collect::<PyResult<Vec<_>>>()?;

                result_dict.set_item("same_conversation", same_conv_py)?;
                result_dict.set_item("previous_conversations", prev_conv_py)?;

                Ok::<PyObject, PyErr>(result_dict.into_py(py))
            })
        })
    }

}

impl EpisodicMemory {
    fn extract_point_id(point: &ScoredPoint) -> Option<String> {
        point.id.as_ref().and_then(|id| {
            id.point_id_options.as_ref().and_then(|opts| match opts {
                qdrant_client::qdrant::point_id::PointIdOptions::Uuid(u) => Some(u.clone()),
                qdrant_client::qdrant::point_id::PointIdOptions::Num(n) => Some(n.to_string()),
            })
        })
    }

    fn episode_to_pydict<'py>(py: Python<'py>, episode: &RankedEpisode) -> PyResult<&'py PyDict> {
        let dict = PyDict::new(py);
        dict.set_item("point_id", &episode.point_id)?;
        dict.set_item("score", episode.score)?;

        for (key, value) in &episode.payload {
            let py_val = Self::qdrant_value_to_py(py, value)?;
            dict.set_item(key.as_str(), py_val)?;
        }
        Ok(dict)
    }

    fn qdrant_value_to_py(py: Python, value: &QdrantValue) -> PyResult<PyObject> {
        match &value.kind {
            Some(qdrant_client::qdrant::value::Kind::StringValue(s)) => Ok(s.to_object(py)),
            Some(qdrant_client::qdrant::value::Kind::IntegerValue(i)) => Ok(i.to_object(py)),
            Some(qdrant_client::qdrant::value::Kind::DoubleValue(d)) => Ok(d.to_object(py)),
            Some(qdrant_client::qdrant::value::Kind::BoolValue(b)) => Ok(b.to_object(py)),
            Some(qdrant_client::qdrant::value::Kind::ListValue(l)) => {
                let list: Vec<PyObject> = l
                    .values
                    .iter()
                    .map(|v| Self::qdrant_value_to_py(py, v))
                    .collect::<PyResult<Vec<_>>>()?;
                Ok(list.to_object(py))
            }
            _ => Ok(py.None()),
        }
    }
}