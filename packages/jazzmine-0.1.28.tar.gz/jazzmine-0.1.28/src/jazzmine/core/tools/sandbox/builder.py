"""
sandbox_builder.py
──────────────────
Builds Docker images for sandbox environments and manages the proxy sidecar.

Responsibilities:
  - Generate a minimal, hardened Dockerfile from a SandboxConfig
  - Write tool source files into a build context
  - Build (or skip if up-to-date) the sandbox image via the Docker SDK
  - Start/stop the proxy sidecar container
  - Create isolated Docker networks per sandbox
  - Connect the proxy to each sandbox network so sandbox containers can reach it

Image rebuild is triggered only when the sandbox checksum changes
(any tool source or dependency changed). Unchanged images are reused,
making repeated agent restarts nearly instantaneous.

Image naming: jazzmine-sandbox-<sandbox_name>:<checksum>
              jazzmine-proxy:<checksum>

Proxy image:  python:3.11-slim with just the proxy_server.py copied in.

DooD note (Docker-out-of-Docker)
─────────────────────────────────
docker.from_env() and all Docker API calls work identically whether the agent
runs on the host or inside a container, AS LONG AS the Docker socket is
mounted into the agent container:

    docker run -v /var/run/docker.sock:/var/run/docker.sock \
               --group-add $(stat -c '%g' /var/run/docker.sock) \
               your-agent-image

SandboxBuilder.__init__ performs an early connectivity check and raises a
clear error with instructions if the socket is missing or unreadable.
"""

from __future__ import annotations

import asyncio
import hashlib
import io
import logging
import os
import tarfile
import tempfile
from pathlib import Path
from typing import Dict, Optional

import docker  # docker-py
import docker.errors

from jazzmine.core.tools.sandbox.config import SandboxConfig
from jazzmine.core.tools.registry import ToolRegistry

log = logging.getLogger(__name__)

# Path to this directory (to locate container/ files for COPY)
_HERE = Path(__file__).parent

PROXY_IMAGE_NAME     = "jazzmine-proxy"
SANDBOX_IMAGE_PREFIX = "jazzmine-sandbox"
NETWORK_PREFIX       = "jazzmine-net"


# ── Dockerfile templates ───────────────────────────────────────────────────────

_SANDBOX_DOCKERFILE = """\
FROM python:{python_version}-slim

# ── Security hardening ───────────────────────────────────────────────────────
# Run as non-root. All capabilities dropped at container run time via --cap-drop.
RUN groupadd --force --gid 1001 sandbox && \
    id -u sandbox >/dev/null 2>&1 || useradd --uid 1001 --gid sandbox --no-create-home --shell /bin/false sandbox

# Remove tools commonly used for exfiltration or privilege escalation
RUN apt-get update -qq && \\
    apt-get purge -y --auto-remove \\
        wget curl netcat-openbsd nmap gcc g++ make \\
    && rm -rf /var/lib/apt/lists/*

# ── Install Python dependencies ───────────────────────────────────────────────
WORKDIR /build
COPY requirements.txt .
RUN pip install --no-cache-dir --quiet -r requirements.txt

# ── Copy tool source files ────────────────────────────────────────────────────
RUN mkdir -p /tools
COPY tools/ /tools/

# ── Copy executor harness ─────────────────────────────────────────────────────
COPY executor_harness.py /executor_harness.py

# ── Runtime directories ───────────────────────────────────────────────────────
# /workspace — writable tmpfs mounted at run time (scratch space)
# /data      — read-only bind mounts for declared file resources
RUN mkdir -p /workspace /data && \\
    chown sandbox:sandbox /workspace

USER sandbox
WORKDIR /workspace

# stdin → executor harness → stdout (event stream)
ENTRYPOINT ["python", "-u", "/executor_harness.py"]
"""

_PROXY_DOCKERFILE = """\
FROM python:3.11-slim

RUN groupadd --force --gid 1002 proxy && \
    id -u proxy >/dev/null 2>&1 || useradd --uid 1002 --gid proxy --no-create-home --shell /bin/false proxy
    
COPY proxy_server.py /proxy_server.py

USER proxy
EXPOSE 8888
ENTRYPOINT ["python", "-u", "/proxy_server.py"]
"""


# ── Build context helpers ──────────────────────────────────────────────────────

def _build_tar(files: Dict[str, bytes]) -> io.BytesIO:
    """
    Create an in-memory tar archive suitable for docker-py's build() method.
    files: mapping of archive path → file content bytes.
    """
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w") as tar:
        for arcname, content in files.items():
            info       = tarfile.TarInfo(name=arcname)
            info.size  = len(content)
            tar.addfile(info, io.BytesIO(content))
    buf.seek(0)
    return buf


# ── SandboxBuilder ─────────────────────────────────────────────────────────────

class SandboxBuilder:
    """
    Builds Docker images and manages network/proxy infrastructure for sandboxes.

    Usage:
        builder = SandboxBuilder(registry)
        await builder.ensure_sandbox("default")          # build image if stale
        await builder.ensure_proxy("jazzmine-net-default") # start proxy sidecar

    The builder is stateful — it tracks which images have already been built
    in this process lifetime to avoid redundant Docker API calls.

    DooD usage:
        Works without any changes to this class. Mount the Docker socket and
        match the group ID as described in the module docstring.
    """

    def __init__(self, registry: ToolRegistry) -> None:
        self._registry      = registry
        self._docker        = self._connect_docker()
        self._built_images: Dict[str, str]  = {}   # sandbox_name → image_tag
        self._proxy_cid:    Optional[str]   = None  # proxy container ID
        self._networks:     Dict[str, str]  = {}   # sandbox_name → network_id

    # ── Docker client initialisation ───────────────────────────────────────────

    @staticmethod
    def _connect_docker() -> docker.DockerClient:
        """
        Connect to the Docker daemon via docker.from_env() and verify
        reachability with a ping.

        Raises a clear RuntimeError when the socket is missing (the most common
        DooD misconfiguration) so operators get an actionable message instead of
        a raw DockerException.
        """
        sock = "/var/run/docker.sock"
        try:
            client = docker.from_env()
            client.ping()
            return client
        except docker.errors.DockerException as exc:
            if not os.path.exists(sock):
                raise RuntimeError(
                    "Docker socket not found. If the agent is running inside a "
                    "container (DooD mode), mount the socket and match its group:\n\n"
                    "    docker run \\\n"
                    f"        -v {sock}:{sock} \\\n"
                    f"        --group-add $(stat -c '%g' {sock}) \\\n"
                    "        your-agent-image\n\n"
                    "Or bake the docker group into your agent Dockerfile:\n\n"
                    "    ARG DOCKER_GID=999\n"
                    "    RUN groupadd -g ${DOCKER_GID} docker \\\n"
                    "     && usermod -aG docker your_agent_user\n"
                ) from exc
            if os.path.exists(sock) and not os.access(sock, os.R_OK | os.W_OK):
                raise RuntimeError(
                    f"Docker socket exists at {sock} but is not readable/writable "
                    "by the current process. Add the socket's group to the agent "
                    "user or run with --group-add as shown above."
                ) from exc
            raise

    # ── Public API ─────────────────────────────────────────────────────────────

    async def ensure_sandbox(self, sandbox_name: str) -> str:
        """
        Build the sandbox image if it doesn't exist or is stale.
        Returns the image tag (used by SandboxPool to start containers).
        """
        config = self._registry.get_sandbox(sandbox_name)
        if config is None:
            raise ValueError(f"No sandbox registered with name '{sandbox_name}'")

        checksum  = self._registry.sandbox_checksum(sandbox_name)
        image_tag = f"{SANDBOX_IMAGE_PREFIX}-{sandbox_name}:{checksum}"

        # Already built this run
        if self._built_images.get(sandbox_name) == image_tag:
            return image_tag

        # Check if the image exists in Docker
        if await self._image_exists(image_tag):
            log.info(f"Sandbox image up-to-date: {image_tag}")
            self._built_images[sandbox_name] = image_tag
            return image_tag

        log.info(f"Building sandbox image: {image_tag}")
        await asyncio.get_event_loop().run_in_executor(
            None, self._build_sandbox_image, config, sandbox_name, image_tag
        )
        self._built_images[sandbox_name] = image_tag
        log.info(f"Sandbox image built: {image_tag}")
        return image_tag

    async def ensure_proxy(self, network_name: Optional[str] = None) -> str:
        """
        Ensure the proxy sidecar image exists and a proxy container is running.

        If network_name is provided the proxy container is connected to that
        network so sandbox containers on the same network can reach it.  The IP
        returned is always the one on network_name (if given), which is the only
        address reachable by sandbox containers.

        Without network_name the method falls back to returning any IP — useful
        for bare-host setups where cross-bridge routing is unrestricted.
        """
        proxy_tag = f"{PROXY_IMAGE_NAME}:latest"

        if not await self._image_exists(proxy_tag):
            log.info("Building proxy image")
            await asyncio.get_event_loop().run_in_executor(
                None, self._build_proxy_image, proxy_tag
            )

        if not (self._proxy_cid and await self._container_running(self._proxy_cid)):
            cid = await asyncio.get_event_loop().run_in_executor(
                None, self._start_proxy_container, proxy_tag
            )
            self._proxy_cid = cid
            log.info(f"Proxy container started: {cid[:12]}")

        if network_name:
            await self._connect_to_network(self._proxy_cid, network_name)
            return await self._container_ip(self._proxy_cid, network_name)

        return await self._container_ip(self._proxy_cid)

    async def ensure_network(self, sandbox_name: str) -> str:
        """
        Create (or return existing) isolated Docker network for a sandbox.
        The tool container and proxy container both attach to this network.
        """
        net_name = f"{NETWORK_PREFIX}-{sandbox_name}"
        if sandbox_name in self._networks:
            return net_name

        existing = await asyncio.get_event_loop().run_in_executor(
            None, lambda: self._docker.networks.list(names=[net_name])
        )
        if existing:
            self._networks[sandbox_name] = existing[0].id
            return net_name

        net = await asyncio.get_event_loop().run_in_executor(
            None,
            lambda: self._docker.networks.create(
                net_name,
                driver  = "bridge",
                options = {"com.docker.network.bridge.enable_ip_masquerade": "false"},
            )
        )
        self._networks[sandbox_name] = net.id
        log.info(f"Created network: {net_name}")
        return net_name

    async def stop_proxy(self) -> None:
        if self._proxy_cid:
            await asyncio.get_event_loop().run_in_executor(
                None, self._remove_container, self._proxy_cid
            )
            self._proxy_cid = None

    # ── Private: image build ───────────────────────────────────────────────────

    def _build_sandbox_image(
        self,
        config:       SandboxConfig,
        sandbox_name: str,
        image_tag:    str,
    ) -> None:
        deps  = self._registry.aggregate_dependencies(sandbox_name)
        tools = self._registry.tools_for_sandbox(sandbox_name)

        files: Dict[str, bytes] = {}

        files["Dockerfile"] = _SANDBOX_DOCKERFILE.format(
            python_version=config.python_version
        ).encode()

        reqs = "\n".join(deps)
        files["requirements.txt"] = reqs.encode()

        for registered in tools:
            filename = f"tools/{registered.tool.name}.py"
            files[filename] = registered.source.encode()

        harness_path = _HERE / "executor_harness.py"
        files["executor_harness.py"] = harness_path.read_bytes()

        build_ctx = _build_tar(files)
        self._docker.images.build(
            fileobj        = build_ctx,
            custom_context = True,
            tag            = image_tag,
            rm             = True,
            forcerm        = True,
        )

    def _build_proxy_image(self, tag: str) -> None:
        proxy_src = (_HERE / "proxy_server.py").read_bytes()
        files: Dict[str, bytes] = {
            "Dockerfile":      _PROXY_DOCKERFILE.encode(),
            "proxy_server.py": proxy_src,
        }
        build_ctx = _build_tar(files)
        self._docker.images.build(
            fileobj        = build_ctx,
            custom_context = True,
            tag            = tag,
            rm             = True,
        )

    # ── Private: container management ─────────────────────────────────────────

    def _start_proxy_container(self, image_tag: str) -> str:
        container = self._docker.containers.run(
            image  = image_tag,
            detach = True,
            remove = False,
            name   = f"{PROXY_IMAGE_NAME}-{os.getpid()}",
            # Proxy gets no resource limits — it's trusted infrastructure
        )
        return container.id

    def _remove_container(self, cid: str) -> None:
        try:
            c = self._docker.containers.get(cid)
            c.stop(timeout=5)
            c.remove()
        except docker.errors.NotFound:
            pass

    # ── Private: network helpers ───────────────────────────────────────────────

    async def _connect_to_network(self, container_id: str, network_name: str) -> None:
        """
        Connect the proxy container to a sandbox network if not already connected.

        This is what makes the proxy reachable from sandbox containers.  Docker's
        default iptables rules block traffic between user-defined bridge networks,
        so the proxy must be explicitly connected to each sandbox network rather
        than relying on cross-bridge routing.

        The call is idempotent — connecting an already-connected container raises
        an APIError with "already exists" in the message, which is silently ignored.
        """
        loop = asyncio.get_event_loop()
        try:
            network = await loop.run_in_executor(
                None, lambda: self._docker.networks.get(network_name)
            )
            await loop.run_in_executor(
                None, lambda: network.connect(container_id)
            )
            log.info(f"Connected proxy {container_id[:12]} to {network_name}")
        except docker.errors.APIError as exc:
            msg = str(exc).lower()
            if "already exists" in msg or "already" in msg or "endpoint with name" in msg:
                log.debug(f"Proxy already connected to {network_name} — skipping")
            else:
                log.warning(f"Could not connect proxy to {network_name}: {exc}")

    # ── Private: query helpers ─────────────────────────────────────────────────

    async def _image_exists(self, tag: str) -> bool:
        try:
            await asyncio.get_event_loop().run_in_executor(
                None, lambda: self._docker.images.get(tag)
            )
            return True
        except docker.errors.ImageNotFound:
            return False

    async def _container_running(self, cid: str) -> bool:
        try:
            c = await asyncio.get_event_loop().run_in_executor(
                None, lambda: self._docker.containers.get(cid)
            )
            return c.status == "running"
        except docker.errors.NotFound:
            return False

    async def _container_ip(
        self,
        cid:          str,
        network_name: Optional[str] = None,
    ) -> str:
        """
        Return the container's IP address.

        When network_name is given, return the IP on THAT network.  This is
        required when the proxy is connected to multiple networks (its original
        default bridge plus each sandbox network): iterating NetworkSettings
        without a target name is non-deterministic and typically returns the
        default-bridge IP, which is unreachable from sandbox containers that are
        on an isolated user-defined bridge.

        Falls back to any available IP when network_name is not given or when the
        container hasn't yet received an address on the requested network.
        """
        loop = asyncio.get_event_loop()
        c = await loop.run_in_executor(
            None, lambda: self._docker.containers.get(cid)
        )
        c.reload()
        nets = c.attrs.get("NetworkSettings", {}).get("Networks", {})

        # Prefer the IP on the explicitly requested network
        if network_name and network_name in nets:
            ip = nets[network_name].get("IPAddress", "")
            if ip:
                return ip
            log.warning(
                f"Proxy {cid[:12]} has no IP on network '{network_name}' yet — "
                "falling back to first available IP"
            )

        # Fallback: any IP (bare-host usage or race condition)
        for net_info in nets.values():
            ip = net_info.get("IPAddress", "")
            if ip:
                return ip

        return "127.0.0.1"