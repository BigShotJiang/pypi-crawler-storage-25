import os
import torch
from transformers import AutoTokenizer, AutoModel
from onnxruntime.quantization import (
    quantize_static,
    CalibrationDataReader,
    QuantType,
    QuantFormat,
)

class EmbeddingService:
    def __init__(self, model_id: str = "BAAI/bge-small-en-v1.5"):
        self.model_id = model_id
        self.tokenizer = None
        self.model = None

    def _model_id_for_filename(self) -> str:
        return self.model_id.replace("/", "-")

    def _load_tokenizer(self):
        if self.tokenizer is None:
            print(f"Loading tokenizer from {self.model_id}...")
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_id)

    def _load_model(self):
        if self.model is None:
            print(f"Loading model from {self.model_id}...")
            self.model = AutoModel.from_pretrained(self.model_id)
            self.model.eval()

    def export_tokenizer_only(self, output_dir: str) -> str:
        """
        Exports only the tokenizer files.
        Use this when using a Remote API (OpenAI/Cohere/vLLM) but need 
        local BM25 sparse vector support.
        """
        os.makedirs(output_dir, exist_ok=True)
        self._load_tokenizer()
        
        self.tokenizer.save_pretrained(output_dir)
        print(f"Tokenizer saved to: {output_dir}")
        return output_dir

    def export_onnx_model(self, output_dir: str, quantized: bool = True, opset: int = 17) -> str:
        """
        Exports the full ONNX model and tokenizer for fully local embedding inference.
        """
        os.makedirs(output_dir, exist_ok=True)
        self._load_tokenizer()
        self._load_model()

        # 1. Save Tokenizer
        self.tokenizer.save_pretrained(output_dir)

        # 2. Prepare Dummy Input
        dummy_text = ["Test sentence."]
        inputs = self.tokenizer(
            dummy_text, return_tensors="pt", padding=True, truncation=True
        )

        # 3. Export FP32
        fp32_filename = f"{self._model_id_for_filename()}_fp32.onnx"
        fp32_path = os.path.join(output_dir, fp32_filename)
        
        print("Exporting model to ONNX FP32...")
        torch.onnx.export(
            self.model,
            (inputs["input_ids"], inputs["attention_mask"]),
            fp32_path,
            input_names=["input_ids", "attention_mask"],
            output_names=["last_hidden_state"],
            dynamic_axes={
                "input_ids": {0: "batch", 1: "seq"},
                "attention_mask": {0: "batch", 1: "seq"},
                "last_hidden_state": {0: "batch", 1: "seq"},
            },
            opset_version=opset,
        )

        if not quantized:
            print(f"FP32 Model saved to {fp32_path}")
            return fp32_path

        # 4. Quantize to INT8
        int8_filename = f"{self._model_id_for_filename()}_int8_qdq.onnx"
        int8_path = os.path.join(output_dir, int8_filename)
        
        print("Quantizing model to INT8...")
        self._quantize(fp32_path, int8_path)
        
        os.remove(fp32_path)
        
        print(f"Quantized Model saved to {int8_path}")
        return int8_path

    def _quantize(self, fp32_path, int8_path):
        class TextCalibrationDataReader(CalibrationDataReader):
            def __init__(self, tokenizer):
                self.tokenizer = tokenizer
                # Minimal calibration data
                self.texts = [
                    "The quick brown fox jumps over the lazy dog",
                    "Artificial intelligence is transforming the world",
                    "Vector databases are essential for RAG applications",
                    "Rust is a systems programming language",
                ] * 10 
                self.index = 0

            def get_next(self):
                if self.index >= len(self.texts):
                    return None
                batch = self.tokenizer(
                    [self.texts[self.index]],
                    return_tensors="np",
                    padding="max_length",
                    truncation=True,
                    max_length=128,
                )
                self.index += 1
                return {
                    "input_ids": batch["input_ids"],
                    "attention_mask": batch["attention_mask"],
                }

        cal_reader = TextCalibrationDataReader(self.tokenizer)
        quantize_static(
            model_input=fp32_path,
            model_output=int8_path,
            calibration_data_reader=cal_reader,
            quant_format=QuantFormat.QDQ,
            weight_type=QuantType.QInt8,
            activation_type=QuantType.QInt8,
        )