"""
server.py
─────────
FastAPI / uvicorn HTTP server for Jazzmine agents.

AgentBuilder wires this automatically when .server(ServerConfig(...)) is
called. You do not need to instantiate AgentServer directly in normal use.

Endpoints
──────────
  POST {chat_endpoint}         Send a message, receive a full turn result.
  POST {chat_endpoint}/stream  Same, but streamed as Server-Sent Events.
  GET  {health_endpoint}       Liveness probe — always returns 200 OK.
  GET  {info_endpoint}         Agent metadata (name, version, capabilities).
  GET  /                       Redirects to docs_url or /info if docs disabled.

Authentication
──────────────
When ServerConfig.api_key is set every request must include:

    Authorization: Bearer <api_key>

Unauthenticated requests receive 401 Unauthorized. Requests with a
wrong key receive 403 Forbidden.

Server-Sent Events (streaming)
───────────────────────────────
POST {chat_endpoint}/stream returns an SSE stream. The client reads
events with Content-Type: text/event-stream. Three event types are emitted:

  event: intermediate
  data: {"type": "tool_call", "content": "...", "tool": "..."}

  event: done
  data: {"response": "...", "message_id": "...", ...full AgentTurnResult...}

  event: error
  data: {"error": "...", "detail": "..."}

Lifecycle
──────────
AgentServer.start()  launches uvicorn in a background asyncio Task and
                     waits until the server reports "started" before returning.
AgentServer.stop()   signals uvicorn to exit and awaits the task — safe to
                     call from a Teardown callback.

AgentBuilder registers stop() as a Teardown callback automatically.
"""

import asyncio
import json
import logging
import time
from typing import TYPE_CHECKING, Any, AsyncIterator

if TYPE_CHECKING:
    from fastapi import Request as FastAPIRequest
    from fastapi import Response as FastAPIResponse
    from fastapi.security import HTTPAuthorizationCredentials as FastAPICredentials
else:
    FastAPIRequest = Any
    FastAPIResponse = Any
    FastAPICredentials = Any

log = logging.getLogger(__name__)

# ── Lazy imports — only resolved when the server is actually started ──────────
# This avoids hard-wiring fastapi/uvicorn as mandatory dependencies for
# users who never call .server().

def _require_fastapi() -> Any:
    try:
        import fastapi
        return fastapi
    except ImportError as exc:
        raise ImportError(
            "FastAPI is required to use AgentBuilder.server(). "
            "Install it with: pip install 'fastapi[standard]'"
        ) from exc


def _require_uvicorn() -> Any:
    try:
        import uvicorn
        return uvicorn
    except ImportError as exc:
        raise ImportError(
            "uvicorn is required to use AgentBuilder.server(). "
            "Install it with: pip install 'uvicorn[standard]'"
        ) from exc


# ══════════════════════════════════════════════════════════════════════════════
# Pydantic request / response schemas
# (defined lazily inside _build_app so Pydantic isn't imported at module load)
# ══════════════════════════════════════════════════════════════════════════════

def _build_app(agent: Any, cfg: Any, agent_version: str) -> Any:
    """
    Construct and return the FastAPI application.

    Parameters
    ──────────
    agent          The fully built Jazzmine Agent instance.
    cfg            A ServerConfig dataclass instance.
    agent_version  Version string from AgentBuilder.version() — shown in /info.
    """
    fastapi = _require_fastapi()
    FastAPI          = fastapi.FastAPI
    Response         = fastapi.Response
    HTTPException    = fastapi.HTTPException
    Depends          = fastapi.Depends
    status           = fastapi.status

    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse, RedirectResponse, StreamingResponse
    from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

    try:
        from pydantic import BaseModel, Field, field_validator
    except ImportError as exc:
        raise ImportError(
            "Pydantic v2 is required to use AgentBuilder.server(). "
            "Install it with: pip install pydantic"
        ) from exc

    # ── Pydantic schemas ──────────────────────────────────────────────────────

    class ChatRequest(BaseModel):
        """
        Payload for POST {chat_endpoint} and POST {chat_endpoint}/stream.

        message             The user's message text.
        conversation_id     Opaque ID scoping the session.
                            Auto-generated server-side when empty.
        user_id             Caller identity — used for memory scoping.
        explicit_context    Optional list of text snippets injected into the
                            prompt context (e.g. retrieved documents).
        metadata            Arbitrary key-value bag — logged but not forwarded
                            to the agent. Useful for client-side correlation.
        """
        message:          str             = Field(..., min_length=1)
        conversation_id:  str             = Field(default="")
        user_id:          str             = Field(default="user")
        explicit_context: list[str] | None = Field(default=None)
        metadata:         dict[str, Any]  = Field(default_factory=dict)

        @field_validator("message")
        @classmethod
        def _message_not_empty(cls, v: str) -> str:
            v = v.strip()
            if not v:
                raise ValueError("message cannot be blank.")
            max_len = cfg.max_message_length
            if len(v) > max_len:
                raise ValueError(
                    f"message exceeds maximum length of {max_len} characters "
                    f"(received {len(v)})."
                )
            return v

    class ChatResponse(BaseModel):
        """
        Full turn result returned by POST {chat_endpoint}.

        response        The agent's reply text.
        message_id      Unique ID for this assistant message (UUID).
        trace_id        Correlation ID linking all log events for this turn.
        conversation_id The conversation scope — echoed from the request.
        user_id         The user scope — echoed from the request.
        invoked_flows   Flow names that ran this turn (may be empty).
        invoked_tools   Tool names that ran this turn (may be empty).
        errors          Non-fatal errors encountered (e.g. memory recall hiccup).
        turn_number     Sequential turn index within this conversation.
        is_blocked      True when the response was blocked by SecurityGuard.
        latency_ms      Server-side wall time from request receipt to response.
        """
        response:        str
        message_id:      str
        trace_id:        str
        conversation_id: str
        user_id:         str
        invoked_flows:   list[str]
        invoked_tools:   list[str]
        errors:          list[str]
        turn_number:     int
        is_blocked:      bool
        latency_ms:      int

    class HealthResponse(BaseModel):
        status:     str = "ok"
        agent_name: str
        uptime_s:   float

    class InfoResponse(BaseModel):
        agent_name:   str
        agent_id:     str
        version:      str
        api_version:  str
        has_tools:    bool
        has_memory:   bool
        endpoints:    dict[str, str]

    class ErrorResponse(BaseModel):
        error:  str
        detail: str = ""

    # ── FastAPI app ───────────────────────────────────────────────────────────

    app = FastAPI(
        title       = cfg.title,
        description = cfg.description or (
            f"HTTP API for the **{agent.config.name}** Jazzmine agent."
        ),
        version     = cfg.api_version,
        docs_url    = cfg.docs_url,
        redoc_url   = cfg.redoc_url,
    )

    # ── CORS middleware ───────────────────────────────────────────────────────

    cors = cfg.cors
    app.add_middleware(
        CORSMiddleware,
        allow_origins        = cors.origins,
        allow_credentials    = cors.allow_credentials,
        allow_methods        = cors.allow_methods,
        allow_headers        = cors.allow_headers,
        expose_headers       = cors.expose_headers,
        max_age              = cors.max_age,
    )

    # ── Server-wide state ─────────────────────────────────────────────────────

    _startup_time: float = time.monotonic()

    # ── Auth dependency ───────────────────────────────────────────────────────

    _bearer_scheme = HTTPBearer(auto_error=False)

    async def _require_auth(
        credentials: FastAPICredentials | None = Depends(_bearer_scheme),
    ) -> None:
        """FastAPI dependency — raises 401/403 when auth is configured and invalid."""
        if cfg.api_key is None:
            return   # auth disabled — allow all

        if credentials is None:
            raise HTTPException(
                status_code = status.HTTP_401_UNAUTHORIZED,
                detail      = "Missing Authorization header. "
                              "Expected: Authorization: Bearer <api_key>",
                headers     = {"WWW-Authenticate": "Bearer"},
            )

        if credentials.credentials != cfg.api_key:
            raise HTTPException(
                status_code = status.HTTP_403_FORBIDDEN,
                detail      = "Invalid API key.",
            )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _ensure_conversation_id(value: str) -> str:
        """Return value as-is, or generate a UUID if blank."""
        import uuid
        return value.strip() or str(uuid.uuid4())

    async def _run_chat_turn(req: ChatRequest) -> tuple[Any, int]:
        """
        Call agent.chat() with a request-scoped timeout.
        Returns (AgentTurnResult, latency_ms).
        """
        t0 = time.monotonic()
        try:
            result = await asyncio.wait_for(
                agent.chat(
                    user_id          = req.user_id,
                    conversation_id  = req.conversation_id,
                    content          = req.message,
                    explicit_context = req.explicit_context,
                ),
                timeout = cfg.request_timeout,
            )
        except asyncio.TimeoutError:
            raise HTTPException(
                status_code = status.HTTP_504_GATEWAY_TIMEOUT,
                detail      = (
                    f"Agent did not respond within {cfg.request_timeout}s. "
                    "Try a shorter message or increase ServerConfig.request_timeout."
                ),
            )
        latency_ms = int((time.monotonic() - t0) * 1000)
        return result, latency_ms

    # ── Root redirect ─────────────────────────────────────────────────────────

    @app.get("/", include_in_schema=False)
    async def _root() -> FastAPIResponse:
        target = cfg.docs_url or cfg.info_endpoint
        return RedirectResponse(url=target)

    # ── Health ────────────────────────────────────────────────────────────────

    @app.get(
        cfg.health_endpoint,
        response_model    = HealthResponse,
        summary           = "Health check",
        description       = (
            "Liveness probe. Returns 200 OK and a JSON body as long as the "
            "server process is alive. Does not check downstream dependencies "
            "(LLM API, databases). For a deeper readiness check use GET /info."
        ),
        tags              = ["Observability"],
    )
    async def _health() -> HealthResponse:
        return HealthResponse(
            status     = "ok",
            agent_name = agent.config.name,
            uptime_s   = round(time.monotonic() - _startup_time, 2),
        )

    # ── Info ──────────────────────────────────────────────────────────────────

    @app.get(
        cfg.info_endpoint,
        response_model = InfoResponse,
        summary        = "Agent metadata",
        description    = (
            "Returns static metadata about the running agent: name, ID, "
            "capabilities, and the URL paths of all registered endpoints."
        ),
        tags           = ["Observability"],
    )
    async def _info() -> InfoResponse:
        from jazzmine.core.agent.memory_stubs import (   # type: ignore[import]
            _NoopEpisodicMemory,
        )
        has_memory = not isinstance(agent.episodic_memory, _NoopEpisodicMemory)

        scheme   = "https" if cfg.ssl_certfile else "http"
        base_url = f"{scheme}://{cfg.host}:{cfg.port}"

        endpoints: dict[str, str] = {
            "chat":    f"POST  {base_url}{cfg.chat_endpoint}",
            "stream":  f"POST  {base_url}{cfg.chat_endpoint}/stream",
            "health":  f"GET   {base_url}{cfg.health_endpoint}",
            "info":    f"GET   {base_url}{cfg.info_endpoint}",
        }
        if cfg.docs_url:
            endpoints["docs"] = f"GET   {base_url}{cfg.docs_url}"
        if cfg.redoc_url:
            endpoints["redoc"] = f"GET   {base_url}{cfg.redoc_url}"

        return InfoResponse(
            agent_name  = agent.config.name,
            agent_id    = agent.config.agent_id,
            version     = agent_version,
            api_version = cfg.api_version,
            has_tools   = agent.config.has_tools,
            has_memory  = has_memory,
            endpoints   = endpoints,
        )

    # ── Chat (full response) ──────────────────────────────────────────────────

    @app.post(
        cfg.chat_endpoint,
        response_model = ChatResponse,
        summary        = "Send a message",
        description    = (
            "Send a user message and receive the full turn result once the agent "
            "has finished processing. For token-by-token streaming use "
            f"`POST {cfg.chat_endpoint}/stream`."
        ),
        tags           = ["Chat"],
        dependencies   = [Depends(_require_auth)],
    )
    async def _chat(req: ChatRequest) -> ChatResponse:
        req.conversation_id = _ensure_conversation_id(req.conversation_id)

        log.debug(
            "chat  conv=%s user=%s len=%d",
            req.conversation_id, req.user_id, len(req.message),
        )

        result, latency_ms = await _run_chat_turn(req)

        return ChatResponse(
            response        = result.response,
            message_id      = result.message_id,
            trace_id        = result.trace_id,
            conversation_id = req.conversation_id,
            user_id         = req.user_id,
            invoked_flows   = result.invoked_flows,
            invoked_tools   = result.invoked_tools,
            errors          = result.errors,
            turn_number     = result.turn_number,
            is_blocked      = result.is_blocked,
            latency_ms      = latency_ms,
        )

    # ── Chat (SSE streaming) ──────────────────────────────────────────────────

    @app.post(
        f"{cfg.chat_endpoint}/stream",
        summary     = "Send a message (streamed)",
        description = (
            "Send a user message and receive the response as a Server-Sent Events "
            "stream. Set `Accept: text/event-stream` on the request.\n\n"
            "Three SSE event types are emitted:\n\n"
            "- `intermediate` — tool-call or thinking step (may appear multiple times)\n"
            "- `done` — final `ChatResponse` JSON payload\n"
            "- `error` — fatal error, stream ends immediately after this event\n"
        ),
        tags        = ["Chat"],
        dependencies = [Depends(_require_auth)],
        response_class = StreamingResponse,
    )
    async def _chat_stream(req: ChatRequest) -> StreamingResponse:
        req.conversation_id = _ensure_conversation_id(req.conversation_id)

        log.debug(
            "stream conv=%s user=%s len=%d",
            req.conversation_id, req.user_id, len(req.message),
        )

        intermediates: asyncio.Queue[dict | None] = asyncio.Queue()

        def _on_intermediate(event: dict) -> None:
            """
            Callback wired into AgentBuilder.on_intermediate() — receives
            structured intermediate events from the ToolOrchestrator.
            Each dict is forwarded directly as an SSE "intermediate" event.
            """
            intermediates.put_nowait(event)

        async def _sse_generator() -> AsyncIterator[str]:
            def _sse(event: str, data: Any) -> str:
                payload = json.dumps(data, ensure_ascii=False)
                return f"event: {event}\ndata: {payload}\n\n"

            # ── Run the chat turn in a background task ────────────────────────
            # We need it running concurrently so we can forward intermediate
            # events to the SSE generator while the turn is in progress.
            t0 = time.monotonic()
            chat_task: asyncio.Task = asyncio.create_task(
                asyncio.wait_for(
                    agent.chat(
                        user_id          = req.user_id,
                        conversation_id  = req.conversation_id,
                        content          = req.message,
                        explicit_context = req.explicit_context,
                    ),
                    timeout = cfg.request_timeout,
                )
            )

            # ── Drain intermediate queue while the turn runs ───────────────────
            try:
                while not chat_task.done():
                    try:
                        event_data = intermediates.get_nowait()
                        if event_data is not None:
                            yield _sse("intermediate", event_data)
                    except asyncio.QueueEmpty:
                        await asyncio.sleep(0.02)

                # Flush any remaining intermediate events that arrived just
                # before the task completed.
                while not intermediates.empty():
                    event_data = intermediates.get_nowait()
                    if event_data is not None:
                        yield _sse("intermediate", event_data)

                result = chat_task.result()

            except asyncio.TimeoutError:
                yield _sse("error", {
                    "error":  "timeout",
                    "detail": (
                        f"Agent did not respond within {cfg.request_timeout}s."
                    ),
                })
                return

            except Exception as exc:
                log.exception("Unhandled error in streaming chat turn.")
                yield _sse("error", {
                    "error":  type(exc).__name__,
                    "detail": str(exc),
                })
                return

            latency_ms = int((time.monotonic() - t0) * 1000)

            # ── Emit the final done event ─────────────────────────────────────
            yield _sse("done", {
                "response":        result.response,
                "message_id":      result.message_id,
                "trace_id":        result.trace_id,
                "conversation_id": req.conversation_id,
                "user_id":         req.user_id,
                "invoked_flows":   result.invoked_flows,
                "invoked_tools":   result.invoked_tools,
                "errors":          result.errors,
                "turn_number":     result.turn_number,
                "is_blocked":      result.is_blocked,
                "latency_ms":      latency_ms,
            })

        return StreamingResponse(
            _sse_generator(),
            media_type = "text/event-stream",
            headers    = {
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",   # disable nginx buffering
            },
        )

    # ── Global exception handler ──────────────────────────────────────────────

    @app.exception_handler(Exception)
    async def _unhandled_exception(request: FastAPIRequest, exc: Exception) -> JSONResponse:
        log.exception("Unhandled server error on %s %s", request.method, request.url)
        return JSONResponse(
            status_code = status.HTTP_500_INTERNAL_SERVER_ERROR,
            content     = ErrorResponse(
                error  = type(exc).__name__,
                detail = str(exc),
            ).model_dump(),
        )

    return app


# ══════════════════════════════════════════════════════════════════════════════
# AgentServer
# ══════════════════════════════════════════════════════════════════════════════

class AgentServer:
    """
    Wraps a FastAPI application in a uvicorn server that runs as an asyncio Task.

    AgentBuilder constructs and starts this automatically when .server() is
    called. Typical user code never touches AgentServer directly.

    If you need a reference to the running server (e.g. for testing or dynamic
    port inspection) it is available as:

        builder = AgentBuilder(...)
        agent, td = await builder.server(ServerConfig(...)).build()
        server = builder.agent_server       # → AgentServer
        port   = server.effective_port      # → int (useful when port=0)
    """

    def __init__(
        self,
        agent:         Any,
        config:        Any,          # ServerConfig
        agent_version: str = "",
    ) -> None:
        self._agent   = agent
        self._cfg     = config
        self._version = agent_version

        self._app:    Any | None = None
        self._server: Any | None = None  # uvicorn.Server
        self._task:   asyncio.Task | None = None
        self._started = asyncio.Event()

    # ── Public properties ──────────────────────────────────────────────────────

    @property
    def app(self) -> Any:
        """The FastAPI application (available after start())."""
        if self._app is None:
            raise RuntimeError("AgentServer has not been started yet.")
        return self._app

    @property
    def is_running(self) -> bool:
        return self._server is not None and self._server.started

    @property
    def effective_port(self) -> int:
        """
        The port the server is actually bound to.
        Useful when ServerConfig.port=0 (OS-assigned ephemeral port).
        """
        if self._server is None:
            return self._cfg.port
        # uvicorn.Server exposes servers on .servers[0].sockets[0]
        try:
            sock = self._server.servers[0].sockets[0]
            return sock.getsockname()[1]
        except (IndexError, AttributeError, OSError):
            return self._cfg.port

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def start(self) -> None:
        """
        Build the FastAPI app, start uvicorn in a background asyncio Task,
        and wait until the server reports that it has bound to the port.

        Raises RuntimeError if called more than once.
        """
        if self._task is not None:
            raise RuntimeError("AgentServer is already running.")

        uvicorn = _require_uvicorn()

        self._app = _build_app(self._agent, self._cfg, self._version)

        cfg = self._cfg

        # ── Silence uvicorn's own lifecycle log lines ─────────────────────────
        # Uvicorn emits INFO lines like:
        #   "Started server process [pid]"
        #   "Waiting for application startup."
        #   "Application startup complete."
        #   "Uvicorn running on http://... (Press CTRL+C to quit)"
        #   "Shutting down"
        #   "Finished server process [pid]"
        #
        # These duplicate Jazzmine's branded StartupDisplay events and clash
        # visually. We replace uvicorn's log_config with one that:
        #   • Sends uvicorn.error to WARNING — kills all INFO lifecycle messages
        #     while keeping real errors visible.
        #   • Silences uvicorn.access unless the caller asked for debug/trace.
        #   • Leaves every other logger untouched (disable_existing_loggers=False).
        _access_level = "DEBUG" if cfg.log_level in ("debug", "trace") else "CRITICAL"
        _uvicorn_log_config: dict[str, Any] = {
            "version":                  1,
            "disable_existing_loggers": False,
            "formatters": {
                "default": {
                    "()":         "uvicorn.logging.DefaultFormatter",
                    "fmt":        "%(levelprefix)s %(message)s",
                    "use_colors": None,
                },
                "access": {
                    "()":  "uvicorn.logging.AccessFormatter",
                    "fmt": '%(levelprefix)s %(client_addr)s - "%(request_line)s" %(status_code)s',
                },
            },
            "handlers": {
                "default": {
                    "formatter": "default",
                    "class":     "logging.StreamHandler",
                    "stream":    "ext://sys.stderr",
                },
                "access": {
                    "formatter": "access",
                    "class":     "logging.StreamHandler",
                    "stream":    "ext://sys.stdout",
                },
            },
            "loggers": {
                # Raise uvicorn.error to WARNING — this is the logger that emits
                # every "Started server process / Waiting / Running on" line.
                "uvicorn.error": {
                    "handlers":  ["default"],
                    "level":     "WARNING",
                    "propagate": False,
                },
                # Access logs only at debug/trace.
                "uvicorn.access": {
                    "handlers":  ["access"] if _access_level == "DEBUG" else [],
                    "level":     _access_level,
                    "propagate": False,
                },
            },
        }

        uvicorn_config = uvicorn.Config(
            app                = self._app,
            host               = cfg.host,
            port               = cfg.port,
            log_config         = _uvicorn_log_config,
            ssl_certfile       = cfg.ssl_certfile,
            ssl_keyfile        = cfg.ssl_keyfile,
            backlog            = cfg.backlog,
            limit_concurrency  = cfg.limit_concurrency,
            timeout_keep_alive = cfg.timeout_keep_alive,
        )
        self._server = uvicorn.Server(uvicorn_config)

        # Override uvicorn's signal handlers so it doesn't swallow SIGINT —
        # the outer asyncio event loop handles those via AgentBuilder's teardown.
        self._server.install_signal_handlers = lambda: None

        self._task = asyncio.create_task(
            self._server.serve(),
            name=f"jazzmine-server-{cfg.port}",
        )

        # Wait for uvicorn to bind the port (polls every 50ms, 20 s max).
        deadline = time.monotonic() + 20.0
        while not self._server.started:
            if self._task.done():
                exc = self._task.exception()
                raise RuntimeError(
                    f"uvicorn failed to start on {cfg.host}:{cfg.port}: {exc}"
                ) from exc
            if time.monotonic() > deadline:
                raise RuntimeError(
                    f"uvicorn did not start within 20 s on {cfg.host}:{cfg.port}."
                )
            await asyncio.sleep(0.05)

        self._started.set()
        log.info(
            "AgentServer listening on %s://%s:%d",
            "https" if cfg.ssl_certfile else "http",
            cfg.host,
            self.effective_port,
        )

    async def stop(self) -> None:
        """
        Gracefully stop the server. Signals uvicorn to exit and awaits the task.
        Idempotent — safe to call if the server was never started.
        """
        if self._server is not None:
            self._server.should_exit = True

        if self._task is not None and not self._task.done():
            try:
                await asyncio.wait_for(asyncio.shield(self._task), timeout=10.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._task.cancel()

        log.info("AgentServer stopped.")