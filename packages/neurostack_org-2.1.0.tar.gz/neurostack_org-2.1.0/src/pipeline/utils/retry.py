"""
Retry utilities with exponential backoff.

Provides configurable retry logic for handling transient failures
in connectors, storage, and other pipeline components.

Features:
- Exponential backoff with jitter
- Configurable retry strategies
- Integration with exception hierarchy
- Retry budget tracking
- Detailed logging
"""

import time
import random
import functools
from typing import Callable, TypeVar, Optional, Type, Tuple, Any
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from .exceptions import (
    PipelineError,
    is_retryable,
    ConnectorRateLimitError,
    RateLimitExceededError
)


# Type variable for generic functions
T = TypeVar('T')


# ============================================================================
# RETRY STRATEGY
# ============================================================================

@dataclass
class RetryStrategy:
    """
    Retry strategy configuration.
    
    Defines how retries should be executed.
    """
    max_retries: int = 3                    # Maximum number of retry attempts
    base_delay: float = 1.0                 # Base delay in seconds
    max_delay: float = 60.0                 # Maximum delay in seconds
    exponential_base: float = 2.0           # Exponential backoff base (2 = double each time)
    jitter: bool = True                     # Add random jitter to prevent thundering herd
    jitter_factor: float = 0.1              # Jitter as fraction of delay (0.1 = ±10%)
    
    # Retry budget (prevents infinite retries across multiple calls)
    budget_enabled: bool = False            # Enable retry budget tracking
    budget_max_retries: int = 100           # Max retries across all calls
    budget_window_seconds: int = 3600       # Budget window (1 hour default)
    
    def __post_init__(self):
        """Validate strategy parameters"""
        if self.max_retries < 0:
            raise ValueError("max_retries must be >= 0")
        if self.base_delay <= 0:
            raise ValueError("base_delay must be > 0")
        if self.max_delay < self.base_delay:
            raise ValueError("max_delay must be >= base_delay")
        if self.exponential_base < 1:
            raise ValueError("exponential_base must be >= 1")
        if not 0 <= self.jitter_factor <= 1:
            raise ValueError("jitter_factor must be between 0 and 1")


# Predefined strategies for common use cases

AGGRESSIVE_RETRY = RetryStrategy(
    max_retries=5,
    base_delay=0.5,
    max_delay=30.0,
    exponential_base=2.0
)

STANDARD_RETRY = RetryStrategy(
    max_retries=3,
    base_delay=1.0,
    max_delay=60.0,
    exponential_base=2.0
)

CONSERVATIVE_RETRY = RetryStrategy(
    max_retries=2,
    base_delay=2.0,
    max_delay=120.0,
    exponential_base=3.0
)

NO_RETRY = RetryStrategy(
    max_retries=0
)


# ============================================================================
# RETRY BUDGET TRACKER
# ============================================================================

class RetryBudget:
    """
    Tracks retry budget to prevent excessive retries.
    
    Prevents scenarios where many requests all retry simultaneously,
    overwhelming a recovering service.
    """
    
    def __init__(
        self,
        max_retries: int,
        window_seconds: int
    ):
        """
        Initialize retry budget.
        
        Args:
            max_retries: Maximum retries allowed in window
            window_seconds: Time window in seconds
        """
        self.max_retries = max_retries
        self.window_seconds = window_seconds
        
        # Track retry timestamps
        self.retry_timestamps: list[datetime] = []
    
    def can_retry(self) -> bool:
        """
        Check if retry is allowed within budget.
        
        Returns:
            True if retry is allowed
        """
        # Clean old entries outside window
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=self.window_seconds)
        self.retry_timestamps = [
            ts for ts in self.retry_timestamps
            if ts > cutoff
        ]
        
        # Check if under budget
        return len(self.retry_timestamps) < self.max_retries
    
    def record_retry(self) -> None:
        """Record a retry attempt"""
        self.retry_timestamps.append(datetime.now(timezone.utc))
    
    def get_remaining_budget(self) -> int:
        """Get remaining retry budget"""
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=self.window_seconds)
        recent_retries = sum(1 for ts in self.retry_timestamps if ts > cutoff)
        return max(0, self.max_retries - recent_retries)


# ============================================================================
# BACKOFF CALCULATION
# ============================================================================

def exponential_backoff(
    attempt: int,
    base_delay: float,
    exponential_base: float,
    max_delay: float,
    jitter: bool = True,
    jitter_factor: float = 0.1
) -> float:
    """
    Calculate exponential backoff delay.
    
    Formula: delay = min(base_delay * (exponential_base ^ attempt), max_delay)
    With optional jitter: delay * (1 ± jitter_factor)
    
    Args:
        attempt: Retry attempt number (0-indexed)
        base_delay: Base delay in seconds
        exponential_base: Exponential base (typically 2)
        max_delay: Maximum delay cap
        jitter: Whether to add random jitter
        jitter_factor: Jitter as fraction of delay
        
    Returns:
        Delay in seconds
    """
    # Calculate exponential delay
    delay = base_delay * (exponential_base ** attempt)
    
    # Cap at max delay
    delay = min(delay, max_delay)
    
    # Add jitter if enabled
    if jitter:
        jitter_amount = delay * jitter_factor
        delay += random.uniform(-jitter_amount, jitter_amount)
    
    # Ensure non-negative
    return max(0, delay)


def linear_backoff(
    attempt: int,
    base_delay: float,
    max_delay: float,
    increment: float = 1.0,
    jitter: bool = True,
    jitter_factor: float = 0.1
) -> float:
    """
    Calculate linear backoff delay.
    
    Formula: delay = min(base_delay + (attempt * increment), max_delay)
    
    Args:
        attempt: Retry attempt number (0-indexed)
        base_delay: Base delay in seconds
        max_delay: Maximum delay cap
        increment: Delay increment per attempt
        jitter: Whether to add random jitter
        jitter_factor: Jitter as fraction of delay
        
    Returns:
        Delay in seconds
    """
    delay = base_delay + (attempt * increment)
    delay = min(delay, max_delay)
    
    if jitter:
        jitter_amount = delay * jitter_factor
        delay += random.uniform(-jitter_amount, jitter_amount)
    
    return max(0, delay)


# ============================================================================
# RETRY DECORATOR
# ============================================================================

def retry(
    strategy: Optional[RetryStrategy] = None,
    retry_on: Optional[Tuple[Type[Exception], ...]] = None,
    exclude_on: Optional[Tuple[Type[Exception], ...]] = None,
    before_retry: Optional[Callable[[Exception, int], None]] = None,
    logger: Optional[Any] = None
):
    """
    Decorator for automatic retry with exponential backoff.
    
    Usage:
        @retry(strategy=STANDARD_RETRY)
        def fetch_data():
            # ... code that may fail
            pass
        
        @retry(strategy=AGGRESSIVE_RETRY, retry_on=(requests.RequestException,))
        def api_call():
            # ... code
            pass
    
    Args:
        strategy: RetryStrategy to use (default: STANDARD_RETRY)
        retry_on: Tuple of exception types to retry (default: all retryable)
        exclude_on: Tuple of exception types to never retry
        before_retry: Callback before each retry: fn(exception, attempt)
        logger: Optional logger for retry attempts
        
    Returns:
        Decorated function
    """
    if strategy is None:
        strategy = STANDARD_RETRY
    
    # Initialize retry budget if enabled
    budget = None
    if strategy.budget_enabled:
        budget = RetryBudget(
            strategy.budget_max_retries,
            strategy.budget_window_seconds
        )
    
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> T:
            last_exception = None
            
            for attempt in range(strategy.max_retries + 1):
                try:
                    # Execute function
                    result = func(*args, **kwargs)
                    
                    # Success - reset any tracking
                    return result
                
                except Exception as e:
                    last_exception = e
                    
                    # Check if should retry this exception
                    if not _should_retry_exception(
                        e,
                        retry_on,
                        exclude_on,
                        attempt,
                        strategy.max_retries
                    ):
                        raise
                    
                    # Check retry budget
                    if budget and not budget.can_retry():
                        if logger:
                            logger.warning(
                                f"Retry budget exhausted. Remaining: {budget.get_remaining_budget()}"
                            )
                        raise
                    
                    # Calculate delay
                    delay = exponential_backoff(
                        attempt=attempt,
                        base_delay=strategy.base_delay,
                        exponential_base=strategy.exponential_base,
                        max_delay=strategy.max_delay,
                        jitter=strategy.jitter,
                        jitter_factor=strategy.jitter_factor
                    )
                    
                    # Handle rate limit errors specially
                    if isinstance(e, (ConnectorRateLimitError, RateLimitExceededError)):
                        if hasattr(e, 'retry_after_seconds') and e.retry_after_seconds:
                            delay = max(delay, e.retry_after_seconds)
                    
                    # Log retry attempt
                    if logger:
                        logger.warning(
                            f"Retry attempt {attempt + 1}/{strategy.max_retries} "
                            f"after {delay:.2f}s due to: {e}"
                        )
                    
                    # Callback before retry
                    if before_retry:
                        before_retry(e, attempt)
                    
                    # Record in budget
                    if budget:
                        budget.record_retry()
                    
                    # Wait before retry
                    time.sleep(delay)
            
            # All retries exhausted
            if logger:
                logger.error(
                    f"All {strategy.max_retries} retries exhausted for {func.__name__}"
                )
            
            raise last_exception
        
        return wrapper
    
    return decorator


def _should_retry_exception(
    exception: Exception,
    retry_on: Optional[Tuple[Type[Exception], ...]],
    exclude_on: Optional[Tuple[Type[Exception], ...]],
    attempt: int,
    max_retries: int
) -> bool:
    """
    Determine if exception should be retried.
    
    Args:
        exception: Exception that was raised
        retry_on: Tuple of exception types to retry
        exclude_on: Tuple of exception types to never retry
        attempt: Current attempt number
        max_retries: Maximum retries allowed
        
    Returns:
        True if should retry
    """
    # No more retries available
    if attempt >= max_retries:
        return False
    
    # Check explicit exclusions first
    if exclude_on and isinstance(exception, exclude_on):
        return False
    
    # Check explicit retry types
    if retry_on:
        if isinstance(exception, retry_on):
            return True
        else:
            return False
    
    # Use default retryability logic from exceptions module
    return is_retryable(exception)


# ============================================================================
# FUNCTIONAL RETRY (non-decorator)
# ============================================================================

def retry_with_backoff(
    func: Callable[..., T],
    *args,
    strategy: Optional[RetryStrategy] = None,
    retry_on: Optional[Tuple[Type[Exception], ...]] = None,
    exclude_on: Optional[Tuple[Type[Exception], ...]] = None,
    logger: Optional[Any] = None,
    **kwargs
) -> T:
    """
    Retry function with exponential backoff (functional style).
    
    Alternative to decorator when you can't modify function signature.
    
    Usage:
        result = retry_with_backoff(
            api_client.fetch_data,
            user_id="123",
            strategy=AGGRESSIVE_RETRY
        )
    
    Args:
        func: Function to call
        *args: Positional arguments for func
        strategy: RetryStrategy to use
        retry_on: Exception types to retry
        exclude_on: Exception types to never retry
        logger: Optional logger
        **kwargs: Keyword arguments for func
        
    Returns:
        Result from func
        
    Raises:
        Exception from func after all retries exhausted
    """
    if strategy is None:
        strategy = STANDARD_RETRY
    
    last_exception = None
    
    for attempt in range(strategy.max_retries + 1):
        try:
            return func(*args, **kwargs)
        
        except Exception as e:
            last_exception = e
            
            if not _should_retry_exception(
                e,
                retry_on,
                exclude_on,
                attempt,
                strategy.max_retries
            ):
                raise
            
            delay = exponential_backoff(
                attempt=attempt,
                base_delay=strategy.base_delay,
                exponential_base=strategy.exponential_base,
                max_delay=strategy.max_delay,
                jitter=strategy.jitter,
                jitter_factor=strategy.jitter_factor
            )
            
            if isinstance(e, (ConnectorRateLimitError, RateLimitExceededError)):
                if hasattr(e, 'retry_after_seconds') and e.retry_after_seconds:
                    delay = max(delay, e.retry_after_seconds)
            
            if logger:
                logger.warning(
                    f"Retry attempt {attempt + 1}/{strategy.max_retries} "
                    f"after {delay:.2f}s due to: {e}"
                )
            
            time.sleep(delay)
    
    raise last_exception


# ============================================================================
# RETRY CONTEXT MANAGER
# ============================================================================

class RetryContext:
    """
    Context manager for retry logic.
    
    Usage:
        with RetryContext(strategy=STANDARD_RETRY) as retry_ctx:
            for attempt in retry_ctx:
                try:
                    result = do_something()
                    break  # Success
                except Exception as e:
                    retry_ctx.handle_error(e)
    """
    
    def __init__(
        self,
        strategy: Optional[RetryStrategy] = None,
        logger: Optional[Any] = None
    ):
        """
        Initialize retry context.
        
        Args:
            strategy: RetryStrategy to use
            logger: Optional logger
        """
        self.strategy = strategy or STANDARD_RETRY
        self.logger = logger
        self.attempt = 0
        self.last_error = None
    
    def __enter__(self):
        """Enter context"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context"""
        # Suppress exceptions if we haven't exhausted retries
        return False
    
    def __iter__(self):
        """Iterate through retry attempts"""
        for attempt in range(self.strategy.max_retries + 1):
            self.attempt = attempt
            yield attempt
    
    def handle_error(self, exception: Exception) -> None:
        """
        Handle error during retry attempt.
        
        Args:
            exception: Exception that occurred
            
        Raises:
            Exception if should not retry
        """
        self.last_error = exception
        
        # Check if should retry
        if not is_retryable(exception):
            raise exception
        
        # Check if retries exhausted
        if self.attempt >= self.strategy.max_retries:
            raise exception
        
        # Calculate delay
        delay = exponential_backoff(
            attempt=self.attempt,
            base_delay=self.strategy.base_delay,
            exponential_base=self.strategy.exponential_base,
            max_delay=self.strategy.max_delay,
            jitter=self.strategy.jitter,
            jitter_factor=self.strategy.jitter_factor
        )
        
        if isinstance(exception, (ConnectorRateLimitError, RateLimitExceededError)):
            if hasattr(exception, 'retry_after_seconds') and exception.retry_after_seconds:
                delay = max(delay, exception.retry_after_seconds)
        
        if self.logger:
            self.logger.warning(
                f"Retry attempt {self.attempt + 1}/{self.strategy.max_retries} "
                f"after {delay:.2f}s due to: {exception}"
            )
        
        time.sleep(delay)


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def calculate_total_retry_time(strategy: RetryStrategy) -> float:
    """
    Calculate maximum total time spent in retries.
    
    Useful for setting timeouts.
    
    Args:
        strategy: RetryStrategy
        
    Returns:
        Maximum total retry time in seconds
    """
    total = 0.0
    
    for attempt in range(strategy.max_retries):
        delay = exponential_backoff(
            attempt=attempt,
            base_delay=strategy.base_delay,
            exponential_base=strategy.exponential_base,
            max_delay=strategy.max_delay,
            jitter=False  # Use max (no jitter)
        )
        total += delay
    
    return total


def get_retry_stats(strategy: RetryStrategy) -> dict:
    """
    Get statistics about retry strategy.
    
    Args:
        strategy: RetryStrategy
        
    Returns:
        Dictionary with retry stats
    """
    delays = []
    for attempt in range(strategy.max_retries):
        delay = exponential_backoff(
            attempt=attempt,
            base_delay=strategy.base_delay,
            exponential_base=strategy.exponential_base,
            max_delay=strategy.max_delay,
            jitter=False
        )
        delays.append(delay)
    
    return {
        "max_retries": strategy.max_retries,
        "total_max_time": sum(delays),
        "delays_per_attempt": delays,
        "first_retry_delay": delays[0] if delays else 0,
        "last_retry_delay": delays[-1] if delays else 0
    }