"""
Universal ingestion interface for Neurostack SDK.

Provides a simple, unified API for ingesting knowledge from any source:
- Files (PDF, Word, Excel, images, text)
- Plain text (manual entry with auto-classification)
- Audio (voice notes, meeting recordings via Whisper)
- Webhooks (structured JSON from any system)
- Meeting transcripts (with decision/action extraction)

Usage:
    from pipeline.ingest.universal import UniversalIngestor

    ingestor = UniversalIngestor(tenant_id="my_company")

    # Ingest a file
    result = ingestor.ingest_file("report.pdf", scope="public")

    # Ingest plain text
    result = ingestor.ingest_text(
        "We decided to switch to vendor B. Approved by Rahul on March 15.",
        scope="team",
        teams=["procurement"],
    )

    # Ingest audio
    result = ingestor.ingest_audio("meeting_recording.mp3")

    # Ingest webhook payload
    result = ingestor.ingest_webhook({
        "content": "New patient admitted: Room 302",
        "type": "event",
        "source": "hospital_ehr",
    })

    # Ingest meeting transcript
    result = ingestor.ingest_meeting_transcript(
        transcript="Alice: Let's go with option A. Bob: Agreed.",
        title="Sprint Planning",
        participants=["alice@co.com", "bob@co.com"],
    )
"""

import uuid
import logging
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger("neurostack.pipeline.ingest.universal")


@dataclass
class IngestionResult:
    """Result of an ingestion operation."""
    success: bool
    items_created: int
    item_ids: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


class UniversalIngestor:
    """
    Unified ingestion interface for all data sources.

    This is the main entry point for SDK users to ingest knowledge.
    """

    def __init__(
        self,
        tenant_id: str,
        storage_backend=None,
        openai_api_key: Optional[str] = None,
    ):
        """
        Initialize ingestor.

        Args:
            tenant_id: Tenant ID for data isolation
            storage_backend: Optional storage backend for persisting items
            openai_api_key: Optional OpenAI key for audio transcription
        """
        self.tenant_id = tenant_id
        self.storage = storage_backend
        self.openai_api_key = openai_api_key
        self._items: List[Dict[str, Any]] = []  # In-memory store if no backend

    def ingest_file(
        self,
        file_path: str,
        scope: str = "public",
        teams: Optional[List[str]] = None,
        user_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> IngestionResult:
        """
        Ingest a file (PDF, Word, Excel, image, text).

        Args:
            file_path: Path to the file
            scope: Visibility scope ("public", "team", "private")
            teams: Team IDs for team-scoped items
            user_id: Owner user ID for private items
            metadata: Additional metadata

        Returns:
            IngestionResult
        """
        from ..processors.file_processor import file_processor
        from ..processors.text_classifier import text_classifier

        try:
            extracted = file_processor.process_file(file_path)
        except Exception as e:
            return IngestionResult(
                success=False,
                items_created=0,
                errors=[f"Failed to process file: {str(e)}"],
            )

        # Chunk if content is long
        chunks = self._chunk_text(extracted.text, max_chars=2000)
        items_created = []

        for i, chunk in enumerate(chunks):
            classification = text_classifier.classify(chunk)
            item_id = f"file_{uuid.uuid4().hex[:8]}"

            item = {
                "id": item_id,
                "content": chunk,
                "type": classification.knowledge_type,
                "source": f"file:{Path(file_path).name}",
                "tenant_id": self.tenant_id,
                "scope": scope,
                "user_ids": [user_id] if user_id else [],
                "team_ids": teams or [],
                "metadata": {
                    **(metadata or {}),
                    **extracted.metadata,
                    "chunk_index": i,
                    "total_chunks": len(chunks),
                    "classification_confidence": classification.confidence,
                    "classification_reason": classification.reason,
                    "entities": classification.extracted_entities,
                    "ingested_at": datetime.now(timezone.utc).isoformat(),
                },
            }
            self._store_item(item)
            items_created.append(item_id)

        logger.info(f"Ingested file '{Path(file_path).name}': {len(items_created)} items")

        return IngestionResult(
            success=True,
            items_created=len(items_created),
            item_ids=items_created,
            metadata={"filename": Path(file_path).name, "format": extracted.metadata.get("format")},
        )

    def ingest_text(
        self,
        text: str,
        scope: str = "public",
        teams: Optional[List[str]] = None,
        user_id: Optional[str] = None,
        knowledge_type: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> IngestionResult:
        """
        Ingest plain text with auto-classification.

        Args:
            text: Plain text content
            scope: Visibility scope
            teams: Team IDs
            user_id: Owner user ID
            knowledge_type: Override auto-classification
            metadata: Additional metadata

        Returns:
            IngestionResult
        """
        from ..processors.text_classifier import text_classifier

        if not text or not text.strip():
            return IngestionResult(success=False, items_created=0, errors=["Empty text"])

        classification = text_classifier.classify(text)
        final_type = knowledge_type or classification.knowledge_type

        item_id = f"manual_{uuid.uuid4().hex[:8]}"
        item = {
            "id": item_id,
            "content": text.strip(),
            "type": final_type,
            "source": "manual_entry",
            "tenant_id": self.tenant_id,
            "scope": scope,
            "user_ids": [user_id] if user_id else [],
            "team_ids": teams or [],
            "metadata": {
                **(metadata or {}),
                "auto_classified_as": classification.knowledge_type,
                "classification_confidence": classification.confidence,
                "classification_reason": classification.reason,
                "entities": classification.extracted_entities,
                "ingested_at": datetime.now(timezone.utc).isoformat(),
            },
        }
        self._store_item(item)

        logger.info(f"Ingested text: type={final_type}, confidence={classification.confidence:.2f}")

        return IngestionResult(
            success=True,
            items_created=1,
            item_ids=[item_id],
            metadata={
                "classified_as": final_type,
                "confidence": classification.confidence,
                "entities": classification.extracted_entities,
            },
        )

    def ingest_audio(
        self,
        file_path: str,
        scope: str = "team",
        teams: Optional[List[str]] = None,
        language: Optional[str] = None,
        extract_decisions: bool = True,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> IngestionResult:
        """
        Ingest audio file (transcribe + extract knowledge).

        Args:
            file_path: Path to audio file
            scope: Visibility scope
            teams: Team IDs
            language: Language hint (ISO 639-1)
            extract_decisions: Whether to extract decisions/actions from transcript
            metadata: Additional metadata

        Returns:
            IngestionResult
        """
        from ..processors.audio_processor import get_audio_processor

        processor = get_audio_processor(api_key=self.openai_api_key)

        try:
            result = processor.transcribe_file(file_path, language=language)
        except Exception as e:
            return IngestionResult(
                success=False,
                items_created=0,
                errors=[f"Transcription failed: {str(e)}"],
            )

        items_created = []

        # Store full transcript
        transcript_id = f"audio_{uuid.uuid4().hex[:8]}"
        item = {
            "id": transcript_id,
            "content": result.text,
            "type": "meeting",
            "source": f"audio:{Path(file_path).name}",
            "tenant_id": self.tenant_id,
            "scope": scope,
            "user_ids": [],
            "team_ids": teams or [],
            "metadata": {
                **(metadata or {}),
                **result.metadata,
                "duration_seconds": result.duration_seconds,
                "language": result.language,
                "ingested_at": datetime.now(timezone.utc).isoformat(),
            },
        }
        self._store_item(item)
        items_created.append(transcript_id)

        # Extract decisions and actions if requested
        if extract_decisions and result.text:
            import re

            # Simple decision/action extraction
            decision_patterns = [
                r"(?:decided|agreed|approved|concluded|resolved)\s*(?:to|that)\s+([^.!?\n]+[.!?]?)",
                r"decision:\s*([^.\n]+\.?)",
            ]

            for pattern in decision_patterns:
                for match in re.findall(pattern, result.text, re.IGNORECASE):
                    text_content = match if isinstance(match, str) else match[0]
                    if len(text_content.strip()) > 10:
                        dec_id = f"decision_{uuid.uuid4().hex[:8]}"
                        self._store_item({
                            "id": dec_id,
                            "content": f"Decision: {text_content.strip()}",
                            "type": "decision",
                            "source": f"audio:{Path(file_path).name}",
                            "tenant_id": self.tenant_id,
                            "scope": scope,
                            "user_ids": [],
                            "team_ids": teams or [],
                            "metadata": {"extracted_from": transcript_id, "ingested_at": datetime.now(timezone.utc).isoformat()},
                        })
                        items_created.append(dec_id)

        logger.info(f"Ingested audio '{Path(file_path).name}': {len(items_created)} items")

        return IngestionResult(
            success=True,
            items_created=len(items_created),
            item_ids=items_created,
            metadata={
                "duration_seconds": result.duration_seconds,
                "transcript_length": len(result.text),
                "language": result.language,
            },
        )

    def ingest_webhook(
        self,
        payload: Dict[str, Any],
        scope: str = "public",
        teams: Optional[List[str]] = None,
    ) -> IngestionResult:
        """
        Ingest structured data from a webhook.

        Args:
            payload: Webhook payload with at least "content" field.
                     Optional: "type", "source", "metadata", "scope", "teams"
            scope: Default visibility scope
            teams: Default team IDs

        Returns:
            IngestionResult
        """
        from ..processors.text_classifier import text_classifier

        content = payload.get("content")
        if not content:
            return IngestionResult(success=False, items_created=0, errors=["payload.content is required"])

        # Handle batch (list of items)
        if isinstance(content, list):
            total = 0
            all_ids = []
            all_errors = []
            for item_payload in content:
                if isinstance(item_payload, dict):
                    r = self.ingest_webhook(item_payload, scope=scope, teams=teams)
                elif isinstance(item_payload, str):
                    r = self.ingest_text(item_payload, scope=scope, teams=teams)
                else:
                    all_errors.append(f"Invalid batch item type: {type(item_payload)}")
                    continue
                total += r.items_created
                all_ids.extend(r.item_ids)
                all_errors.extend(r.errors)
            return IngestionResult(
                success=total > 0,
                items_created=total,
                item_ids=all_ids,
                errors=all_errors,
                metadata={"batch_size": len(content)},
            )

        # Single item
        item_type = payload.get("type")
        if not item_type:
            classification = text_classifier.classify(str(content))
            item_type = classification.knowledge_type

        item_id = f"webhook_{uuid.uuid4().hex[:8]}"
        item = {
            "id": item_id,
            "content": str(content),
            "type": item_type,
            "source": payload.get("source", "webhook"),
            "tenant_id": self.tenant_id,
            "scope": payload.get("scope", scope),
            "user_ids": payload.get("user_ids", []),
            "team_ids": payload.get("teams", teams or []),
            "metadata": {
                **payload.get("metadata", {}),
                "webhook": True,
                "ingested_at": datetime.now(timezone.utc).isoformat(),
            },
        }
        self._store_item(item)

        return IngestionResult(
            success=True,
            items_created=1,
            item_ids=[item_id],
            metadata={"type": item_type, "source": payload.get("source", "webhook")},
        )

    def ingest_meeting_transcript(
        self,
        transcript: str,
        title: str = "Untitled Meeting",
        participants: Optional[List[str]] = None,
        teams: Optional[List[str]] = None,
        meeting_date: Optional[str] = None,
        scope: str = "team",
    ) -> IngestionResult:
        """
        Ingest a meeting transcript with decision/action extraction.

        Args:
            transcript: Meeting transcript text
            title: Meeting title
            participants: List of participant names/emails
            teams: Team IDs
            meeting_date: ISO date string
            scope: Visibility scope

        Returns:
            IngestionResult
        """
        if not transcript or not transcript.strip():
            return IngestionResult(success=False, items_created=0, errors=["Empty transcript"])

        import re
        items_created = []
        timestamp = meeting_date or datetime.now(timezone.utc).isoformat()

        # Full meeting record
        meeting_id = f"meeting_{uuid.uuid4().hex[:8]}"
        self._store_item({
            "id": meeting_id,
            "content": f"Meeting: {title}\nParticipants: {', '.join(participants or ['Unknown'])}\n\n{transcript[:3000]}",
            "type": "meeting",
            "source": "meeting_transcript",
            "tenant_id": self.tenant_id,
            "scope": scope,
            "user_ids": participants or [],
            "team_ids": teams or [],
            "metadata": {
                "title": title,
                "date": timestamp,
                "participants": participants or [],
                "ingested_at": datetime.now(timezone.utc).isoformat(),
            },
        })
        items_created.append(meeting_id)

        # Extract decisions
        decision_patterns = [
            r"(?:decided|agreed|approved|concluded|resolved)\s*(?:to|that)\s+([^.!?\n]+[.!?]?)",
            r"decision:\s*([^.\n]+\.?)",
            r"(?:we(?:'ll| will)|let(?:'s))\s+(?:go with|proceed with|move forward with)\s+([^.!?\n]+[.!?]?)",
        ]
        decisions = set()
        for pattern in decision_patterns:
            for match in re.findall(pattern, transcript, re.IGNORECASE):
                if len(match.strip()) > 10:
                    decisions.add(match.strip())

        for decision in list(decisions)[:10]:
            dec_id = f"decision_{uuid.uuid4().hex[:8]}"
            self._store_item({
                "id": dec_id,
                "content": f"Decision from '{title}': {decision}",
                "type": "decision",
                "source": "meeting_transcript",
                "tenant_id": self.tenant_id,
                "scope": scope,
                "user_ids": participants or [],
                "team_ids": teams or [],
                "metadata": {"meeting_title": title, "date": timestamp, "ingested_at": datetime.now(timezone.utc).isoformat()},
            })
            items_created.append(dec_id)

        # Extract action items
        action_patterns = [
            r"(?:action item|todo|task|AI):\s*(?:(\w+)\s*(?:will|to|should))?\s*([^.\n]+\.?)",
            r"(\w+)\s+(?:will|should|needs to|is going to)\s+([^.!?\n]+[.!?]?)",
        ]
        actions = []
        for pattern in action_patterns:
            for match in re.findall(pattern, transcript, re.IGNORECASE):
                if len(match) == 2 and len(match[1].strip()) > 10:
                    actions.append({"assignee": match[0].strip(), "task": match[1].strip()})

        for action in actions[:10]:
            act_id = f"action_{uuid.uuid4().hex[:8]}"
            self._store_item({
                "id": act_id,
                "content": f"Action item from '{title}': {action['task']}",
                "type": "task",
                "source": "meeting_transcript",
                "tenant_id": self.tenant_id,
                "scope": scope,
                "user_ids": [action["assignee"]] if action.get("assignee") else [],
                "team_ids": teams or [],
                "metadata": {
                    "meeting_title": title,
                    "date": timestamp,
                    "assignee": action.get("assignee"),
                    "status": "todo",
                    "ingested_at": datetime.now(timezone.utc).isoformat(),
                },
            })
            items_created.append(act_id)

        logger.info(
            f"Ingested transcript '{title}': {len(items_created)} items "
            f"({len(decisions)} decisions, {len(actions)} actions)"
        )

        return IngestionResult(
            success=True,
            items_created=len(items_created),
            item_ids=items_created,
            metadata={
                "decisions_found": len(decisions),
                "actions_found": len(actions),
                "meeting_id": meeting_id,
            },
        )

    # --- Internal helpers ---

    def _store_item(self, item: Dict[str, Any]) -> None:
        """Store item to backend or in-memory list."""
        if self.storage:
            self.storage.store(item)
        self._items.append(item)

    def _chunk_text(self, text: str, max_chars: int = 2000, overlap: int = 200) -> List[str]:
        """Split text into chunks with overlap."""
        if len(text) <= max_chars:
            return [text]

        chunks = []
        start = 0
        while start < len(text):
            end = start + max_chars
            # Try to break at paragraph or sentence boundary
            if end < len(text):
                # Look for paragraph break
                para_break = text.rfind("\n\n", start + max_chars // 2, end)
                if para_break > start:
                    end = para_break + 2
                else:
                    # Look for sentence break
                    sentence_break = text.rfind(". ", start + max_chars // 2, end)
                    if sentence_break > start:
                        end = sentence_break + 2

            chunks.append(text[start:end].strip())
            start = end - overlap if end < len(text) else len(text)

        return [c for c in chunks if c]  # Filter empty

    def get_items(self) -> List[Dict[str, Any]]:
        """Get all ingested items (useful for testing/inspection)."""
        return self._items.copy()

    def clear_items(self) -> None:
        """Clear in-memory items."""
        self._items.clear()
