"""initial_schema

Revision ID: f2816fb07a30
Revises: 
Create Date: 2026-03-01 00:45:57.107802

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'f2816fb07a30'
down_revision: Union[str, Sequence[str], None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Extensions
    op.execute('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"')
    op.execute('CREATE EXTENSION IF NOT EXISTS "pg_trgm"')

    # 1. knowledge_items
    op.create_table(
        'knowledge_items',
        sa.Column('content_id', sa.String(length=255), primary_key=True),
        sa.Column('tenant_id', sa.String(length=100), nullable=False),
        sa.Column('knowledge_type', sa.String(length=50), nullable=False),
        sa.Column('content', sa.Text(), nullable=False),
        sa.Column('metadata', postgresql.JSONB(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        sa.CheckConstraint(
            "knowledge_type IN ('document', 'task', 'meeting', 'decision', 'metric', 'event', 'fact')",
            name='chk_knowledge_type'
        )
    )
    op.create_index('idx_knowledge_tenant', 'knowledge_items', ['tenant_id'])
    op.create_index('idx_knowledge_type', 'knowledge_items', ['tenant_id', 'knowledge_type'])
    op.create_index('idx_knowledge_updated', 'knowledge_items', [sa.text('updated_at DESC')])
    op.create_index('idx_knowledge_source', 'knowledge_items', ['tenant_id', sa.text("((metadata->>'source'))")])
    op.create_index('idx_knowledge_metadata_gin', 'knowledge_items', ['metadata'], postgresql_using='gin')
    op.create_index('idx_knowledge_content_fts', 'knowledge_items', [sa.text("to_tsvector('english', content)")], postgresql_using='gin')

    # 2. permissions
    op.create_table(
        'permissions',
        sa.Column('permission_id', sa.String(length=255), primary_key=True),
        sa.Column('content_id', sa.String(length=255), nullable=False, unique=True),
        sa.Column('tenant_id', sa.String(length=100), nullable=False),
        sa.Column('raw', postgresql.JSONB(), nullable=False),
        sa.Column('indexed', postgresql.JSONB(), nullable=False),
        sa.Column('version', sa.Integer(), server_default='1', nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        sa.ForeignKeyConstraint(['content_id'], ['knowledge_items.content_id'], ondelete='CASCADE')
    )
    op.create_index('idx_permission_tenant', 'permissions', ['tenant_id'])
    op.create_index('idx_permission_content', 'permissions', ['content_id'])
    op.create_index('idx_permission_user_ids', 'permissions', [sa.text("((indexed->'user_ids'))")], postgresql_using='gin')
    op.create_index('idx_permission_team_ids', 'permissions', [sa.text("((indexed->'team_ids'))")], postgresql_using='gin')
    op.create_index('idx_permission_scope', 'permissions', [sa.text("((indexed->>'scope'))")])
    op.create_index('idx_permission_tenant_scope', 'permissions', ['tenant_id', sa.text("((indexed->>'scope'))")])

    # 3. knowledge_versions
    op.create_table(
        'knowledge_versions',
        sa.Column('version_id', sa.String(length=255), primary_key=True),
        sa.Column('content_id', sa.String(length=255), nullable=False),
        sa.Column('version_number', sa.Integer(), nullable=False),
        sa.Column('knowledge_type', sa.String(length=50), nullable=False),
        sa.Column('content', sa.Text(), nullable=False),
        sa.Column('metadata', postgresql.JSONB(), nullable=False),
        sa.Column('is_active', sa.Boolean(), server_default='false', nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        sa.ForeignKeyConstraint(['content_id'], ['knowledge_items.content_id'], ondelete='CASCADE'),
        sa.UniqueConstraint('content_id', 'version_number', name='uq_version_number')
    )
    op.create_index('idx_version_content', 'knowledge_versions', ['content_id'])
    op.create_index('idx_version_active', 'knowledge_versions', ['content_id', 'is_active'])
    op.create_index('idx_version_number', 'knowledge_versions', ['content_id', sa.text('version_number DESC')])

    # 4. ingestion_logs
    op.create_table(
        'ingestion_logs',
        sa.Column('log_id', sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column('job_id', sa.String(length=255), nullable=False),
        sa.Column('content_id', sa.String(length=255), nullable=False),
        sa.Column('source_type', sa.String(length=100), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False),
        sa.Column('metadata', postgresql.JSONB(), nullable=True),
        sa.Column('timestamp', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        sa.CheckConstraint("status IN ('success', 'failed', 'skipped')", name='chk_ingestion_status')
    )
    op.create_index('idx_ingestion_job', 'ingestion_logs', ['job_id'])
    op.create_index('idx_ingestion_content', 'ingestion_logs', ['content_id'])
    op.create_index('idx_ingestion_timestamp', 'ingestion_logs', [sa.text('timestamp DESC')])
    op.create_index('idx_ingestion_status', 'ingestion_logs', ['job_id', 'status'])

    # 5. connector_checkpoints
    op.create_table(
        'connector_checkpoints',
        sa.Column('connector_id', sa.String(length=255), primary_key=True),
        sa.Column('checkpoint_data', postgresql.JSONB(), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False)
    )
    op.create_index('idx_checkpoint_updated', 'connector_checkpoints', [sa.text('updated_at DESC')])

    # 6. permission_change_events
    op.create_table(
        'permission_change_events',
        sa.Column('event_id', sa.String(length=255), primary_key=True),
        sa.Column('content_id', sa.String(length=255), nullable=False),
        sa.Column('change_type', sa.String(length=20), nullable=False),
        sa.Column('affected_user_ids', postgresql.ARRAY(sa.Text()), nullable=True),
        sa.Column('affected_team_ids', postgresql.ARRAY(sa.Text()), nullable=True),
        sa.Column('source_type', sa.String(length=100), nullable=True),
        sa.Column('reason', sa.Text(), nullable=True),
        sa.Column('timestamp', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        sa.CheckConstraint("change_type IN ('granted', 'revoked', 'updated')", name='chk_permission_change_type')
    )
    op.create_index('idx_perm_change_content', 'permission_change_events', ['content_id'])
    op.create_index('idx_perm_change_timestamp', 'permission_change_events', [sa.text('timestamp DESC')])
    op.create_index('idx_perm_change_type', 'permission_change_events', ['change_type'])

    # 7. permission_sync_jobs
    op.create_table(
        'permission_sync_jobs',
        sa.Column('job_id', sa.String(length=255), primary_key=True),
        sa.Column('tenant_id', sa.String(length=100), nullable=False),
        sa.Column('source_type', sa.String(length=100), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False),
        sa.Column('started_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('completed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('items_checked', sa.Integer(), server_default='0', nullable=True),
        sa.Column('permissions_updated', sa.Integer(), server_default='0', nullable=True),
        sa.Column('permissions_revoked', sa.Integer(), server_default='0', nullable=True),
        sa.Column('errors', sa.Integer(), server_default='0', nullable=True),
        sa.Column('last_cursor', sa.Text(), nullable=True),
        sa.Column('error_messages', postgresql.ARRAY(sa.Text()), nullable=True),
        sa.CheckConstraint("status IN ('pending', 'running', 'completed', 'failed', 'cancelled')", name='chk_sync_status')
    )
    op.create_index('idx_sync_tenant', 'permission_sync_jobs', ['tenant_id'])
    op.create_index('idx_sync_status', 'permission_sync_jobs', ['status'])
    op.create_index('idx_sync_started', 'permission_sync_jobs', [sa.text('started_at DESC')])

    # Triggers for updated_at
    op.execute("""
        CREATE OR REPLACE FUNCTION update_updated_at_column()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = CURRENT_TIMESTAMP;
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
    """)
    op.execute("""
        CREATE TRIGGER trg_knowledge_updated_at
        BEFORE UPDATE ON knowledge_items
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
    """)
    op.execute("""
        CREATE TRIGGER trg_permission_updated_at
        BEFORE UPDATE ON permissions
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
    """)
    op.execute("""
        CREATE TRIGGER trg_checkpoint_updated_at
        BEFORE UPDATE ON connector_checkpoints
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
    """)


def downgrade() -> None:
    op.execute('DROP TRIGGER IF EXISTS trg_checkpoint_updated_at ON connector_checkpoints')
    op.execute('DROP TRIGGER IF EXISTS trg_permission_updated_at ON permissions')
    op.execute('DROP TRIGGER IF EXISTS trg_knowledge_updated_at ON knowledge_items')
    op.execute('DROP FUNCTION IF EXISTS update_updated_at_column')
    op.drop_table('permission_sync_jobs')
    op.drop_table('permission_change_events')
    op.drop_table('connector_checkpoints')
    op.drop_table('ingestion_logs')
    op.drop_table('knowledge_versions')
    op.drop_table('permissions')
    op.drop_table('knowledge_items')
    op.execute('DROP EXTENSION IF EXISTS "pg_trgm"')
    op.execute('DROP EXTENSION IF EXISTS "uuid-ossp"')
