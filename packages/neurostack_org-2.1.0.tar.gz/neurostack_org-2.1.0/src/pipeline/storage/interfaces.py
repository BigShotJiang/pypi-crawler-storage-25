"""
Storage interface protocols.

These are abstract interfaces (Python Protocols) that define the contract
for all storage backends. Pipeline code depends on these interfaces,
never on concrete implementations.

This enables:
- Pluggable storage (swap Postgres → MongoDB)
- Testing with mocks
- No vendor lock-in
"""

from typing import Protocol, List, Optional, Dict, Any
from datetime import datetime

from neurostack.models import (Knowledge, KnowledgeType, PermissionRecord, IndexedVisibility, PermissionQuery, PermissionChangeEvent, PermissionSyncJob)


# ============================================================================
# METADATA STORE INTERFACE
# ============================================================================

class MetadataStore(Protocol):
    """
    Abstract interface for metadata storage.
    
    Stores:
    - Knowledge items (content, metadata)
    - Permissions (raw + indexed)
    - Versions (document history)
    - Ingestion logs (audit trail)
    - Connector state (checkpoints)
    
    Recommended implementation: SQL database (Postgres)
    Alternative: Document DB with schema enforcement (MongoDB)
    """
    
    # -------------------------
    # Knowledge Operations
    # -------------------------
    
    def write_knowledge(
        self,
        knowledge: Knowledge,
        permission: PermissionRecord,
        replace_if_exists: bool = False
    ) -> str:
        """
        Write knowledge item with permissions.
        
        Args:
            knowledge: Knowledge object to store
            permission: Permission record (raw + indexed)
            replace_if_exists: If True, replace existing item with same ID
            
        Returns:
            Stored content_id
            
        Raises:
            StorageDuplicateError: If item exists and replace_if_exists=False
            StorageWriteError: If write fails
        """
        ...
    
    def get_knowledge_by_id(
        self,
        content_id: str,
        user_id: Optional[str] = None,
        user_teams: Optional[List[str]] = None
    ) -> Optional[Knowledge]:
        """
        Retrieve knowledge item by ID.
        
        If user_id provided, enforces permission filtering.
        
        Args:
            content_id: Content identifier
            user_id: Optional user ID for permission check
            user_teams: Optional user teams for permission check
            
        Returns:
            Knowledge object or None if not found/not authorized
        """
        ...
    
    def query_knowledge(
        self,
        query: PermissionQuery,
        filters: Optional[Dict[str, Any]] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[Knowledge]:
        """
        Query knowledge items with permission filtering.
        
        Args:
            query: Permission query (user, teams, filters)
            filters: Additional filters (source_type, knowledge_type, date range)
            limit: Maximum results to return
            offset: Pagination offset
            
        Returns:
            List of knowledge items visible to user
        """
        ...
    
    def delete_knowledge(self, content_id: str) -> bool:
        """
        Delete knowledge item (hard delete).
        
        Use with caution. Consider soft delete (mark inactive) instead.
        
        Args:
            content_id: Content identifier
            
        Returns:
            True if deleted, False if not found
        """
        ...
    
    def mark_inactive(self, content_id: str, reason: str = "") -> bool:
        """
        Soft delete: mark knowledge as inactive (not deleted).
        
        Preferred over hard delete for audit compliance.
        
        Args:
            content_id: Content identifier
            reason: Reason for inactivation
            
        Returns:
            True if marked, False if not found
        """
        ...
    
    # -------------------------
    # Permission Operations
    # -------------------------
    
    def write_permission(self, permission: PermissionRecord) -> str:
        """
        Write or update permission record.
        
        Args:
            permission: Permission record
            
        Returns:
            Permission record ID
        """
        ...
    
    def get_permission(self, content_id: str) -> Optional[PermissionRecord]:
        """
        Get permission record for content.
        
        Args:
            content_id: Content identifier
            
        Returns:
            Permission record or None
        """
        ...
    
    def update_indexed_visibility(
        self,
        content_id: str,
        indexed: IndexedVisibility
    ) -> bool:
        """
        Update indexed visibility (fast path for permission changes).
        
        Args:
            content_id: Content identifier
            indexed: New indexed visibility
            
        Returns:
            True if updated
        """
        ...
    
    def log_permission_change(self, event: PermissionChangeEvent) -> None:
        """
        Log permission change event (audit trail).
        
        Args:
            event: Permission change event
        """
        ...
    
    def get_permission_changes(
        self,
        content_id: Optional[str] = None,
        since: Optional[datetime] = None,
        limit: int = 100
    ) -> List[PermissionChangeEvent]:
        """
        Query permission change history.
        
        Args:
            content_id: Optional filter by content
            since: Optional filter by timestamp
            limit: Maximum results
            
        Returns:
            List of permission change events
        """
        ...
    
    # -------------------------
    # Versioning Operations
    # -------------------------
    
    def write_version(
        self,
        content_id: str,
        version: int,
        knowledge: Knowledge,
        is_active: bool = True
    ) -> str:
        """
        Write document version.
        
        Args:
            content_id: Content identifier
            version: Version number
            knowledge: Knowledge object for this version
            is_active: Whether this is the active version
            
        Returns:
            Version ID
        """
        ...
    
    def get_versions(
        self,
        content_id: str,
        limit: int = 10
    ) -> List[tuple[int, Knowledge, datetime]]:
        """
        Get version history for content.
        
        Args:
            content_id: Content identifier
            limit: Maximum versions to return
            
        Returns:
            List of (version_number, knowledge, timestamp) tuples
        """
        ...
    
    def get_active_version(self, content_id: str) -> Optional[Knowledge]:
        """
        Get currently active version.
        
        Args:
            content_id: Content identifier
            
        Returns:
            Active knowledge version or None
        """
        ...
    
    # -------------------------
    # Ingestion Logs (Audit)
    # -------------------------
    
    def log_ingestion(
        self,
        job_id: str,
        content_id: str,
        source_type: str,
        status: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log item ingestion (audit trail).
        
        Args:
            job_id: Ingestion job identifier
            content_id: Content identifier
            source_type: Source connector type
            status: "success" | "failed" | "skipped"
            metadata: Optional additional context
        """
        ...
    
    def get_ingestion_logs(
        self,
        job_id: Optional[str] = None,
        since: Optional[datetime] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        Query ingestion logs.
        
        Args:
            job_id: Optional filter by job
            since: Optional filter by timestamp
            limit: Maximum results
            
        Returns:
            List of ingestion log records
        """
        ...
    
    # -------------------------
    # Connector State
    # -------------------------
    
    def save_connector_checkpoint(
        self,
        connector_id: str,
        checkpoint_data: Dict[str, Any]
    ) -> None:
        """
        Save connector checkpoint (for resume).
        
        Args:
            connector_id: Connector identifier
            checkpoint_data: Checkpoint state (cursor, last_id, etc.)
        """
        ...
    
    def get_connector_checkpoint(
        self,
        connector_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Load connector checkpoint.
        
        Args:
            connector_id: Connector identifier
            
        Returns:
            Checkpoint data or None if no checkpoint exists
        """
        ...
    
    def save_permission_sync_job(self, job: PermissionSyncJob) -> None:
        """
        Save permission sync job state.
        
        Args:
            job: Permission sync job
        """
        ...
    
    def get_permission_sync_job(self, job_id: str) -> Optional[PermissionSyncJob]:
        """
        Load permission sync job state.
        
        Args:
            job_id: Job identifier
            
        Returns:
            Job state or None
        """
        ...
    
    # -------------------------
    # Utilities
    # -------------------------
    
    def health_check(self) -> bool:
        """
        Check if metadata store is healthy.
        
        Returns:
            True if accessible and operational
        """
        ...
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get storage statistics.
        
        Returns:
            Dictionary with stats (total_items, total_permissions, storage_size, etc.)
        """
        ...


# ============================================================================
# SEMANTIC STORE INTERFACE
# ============================================================================

class SemanticStore(Protocol):
    """
    Abstract interface for semantic/vector storage.
    
    Stores:
    - Embeddings (vector representations)
    - Metadata for filtering
    
    Implementations: Pinecone, Weaviate, Qdrant, Milvus, or mock
    
    Optional: Pipeline can run without semantic store (structured search only)
    """
    
    def write_embedding(
        self,
        content_id: str,
        vector: List[float],
        metadata: Dict[str, Any]
    ) -> None:
        """
        Write embedding vector with metadata.
        
        Metadata should include:
        - tenant_id (for isolation)
        - source_type
        - knowledge_type
        - Permission pointers (user_ids, team_ids for pre-filtering)
        
        Args:
            content_id: Content identifier (links to metadata store)
            vector: Embedding vector
            metadata: Metadata for filtering
            
        Raises:
            StorageWriteError: If write fails
        """
        ...
    
    def search(
        self,
        query_vector: List[float],
        filters: Dict[str, Any],
        top_k: int = 10
    ) -> List[tuple[str, float, Dict[str, Any]]]:
        """
        Semantic search by vector similarity.
        
        Filters should include permission filters (user_ids, team_ids).
        
        Args:
            query_vector: Query embedding
            filters: Metadata filters (tenant_id, user_ids, etc.)
            top_k: Number of results
            
        Returns:
            List of (content_id, score, metadata) tuples, sorted by score descending
        """
        ...
    
    def delete_embedding(self, content_id: str) -> bool:
        """
        Delete embedding by content ID.
        
        Args:
            content_id: Content identifier
            
        Returns:
            True if deleted, False if not found
        """
        ...
    
    def update_metadata(
        self,
        content_id: str,
        metadata: Dict[str, Any]
    ) -> bool:
        """
        Update metadata for existing embedding.
        
        Used when permissions change (no need to re-embed).
        
        Args:
            content_id: Content identifier
            metadata: New metadata
            
        Returns:
            True if updated
        """
        ...
    
    def batch_write(
        self,
        embeddings: List[tuple[str, List[float], Dict[str, Any]]]
    ) -> int:
        """
        Batch write embeddings (performance optimization).
        
        Args:
            embeddings: List of (content_id, vector, metadata) tuples
            
        Returns:
            Number of embeddings written
        """
        ...
    
    def health_check(self) -> bool:
        """
        Check if semantic store is healthy.
        
        Returns:
            True if accessible
        """
        ...
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get storage statistics.
        
        Returns:
            Dictionary with stats (total_vectors, dimension, index_size, etc.)
        """
        ...


# ============================================================================
# GRAPH STORE INTERFACE
# ============================================================================

class GraphStore(Protocol):
    """
    Abstract interface for graph storage (optional).
    
    Stores:
    - Relationships between knowledge items
    - Organizational graph (teams, reporting)
    
    Implementations: Neo4j, or mock
    
    Optional: Can defer to post-MVP
    """
    
    def write_node(
        self,
        node_id: str,
        node_type: str,
        properties: Dict[str, Any]
    ) -> None:
        """
        Write graph node.
        
        Args:
            node_id: Node identifier
            node_type: Type (e.g., "knowledge", "user", "team")
            properties: Node properties
        """
        ...
    
    def write_relationship(
        self,
        from_id: str,
        to_id: str,
        relationship_type: str,
        properties: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Write relationship between nodes.
        
        Examples:
        - task "blocks" task
        - document "cites" document
        - user "member_of" team
        
        Args:
            from_id: Source node ID
            to_id: Target node ID
            relationship_type: Type of relationship
            properties: Optional relationship properties
        """
        ...
    
    def query_graph(
        self,
        cypher_query: str,
        parameters: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        Execute graph query (Cypher-style).
        
        Args:
            cypher_query: Graph query
            parameters: Query parameters
            
        Returns:
            Query results
        """
        ...
    
    def get_relationships(
        self,
        node_id: str,
        relationship_type: Optional[str] = None,
        direction: str = "both"
    ) -> List[tuple[str, str, Dict[str, Any]]]:
        """
        Get relationships for a node.
        
        Args:
            node_id: Node identifier
            relationship_type: Optional filter by type
            direction: "incoming" | "outgoing" | "both"
            
        Returns:
            List of (from_id, to_id, properties) tuples
        """
        ...
    
    def health_check(self) -> bool:
        """Check if graph store is healthy."""
        ...


# ============================================================================
# STORAGE EXCEPTIONS
# ============================================================================

class StorageError(Exception):
    """Base exception for storage errors"""
    pass


class StorageWriteError(StorageError):
    """Failed to write to storage"""
    pass


class StorageReadError(StorageError):
    """Failed to read from storage"""
    pass


class StorageDuplicateError(StorageError):
    """Attempted to write duplicate content"""
    pass


class StorageConnectionError(StorageError):
    """Failed to connect to storage backend"""
    pass


class StorageConfigError(StorageError):
    """Invalid storage configuration"""
    pass


# ============================================================================
# STORAGE FACTORY (for initialization)
# ============================================================================

class StorageBackend:
    """
    Storage backend configuration.
    
    Used by factory to initialize storage implementations.
    """
    def __init__(
        self,
        metadata_store: MetadataStore,
        semantic_store: Optional[SemanticStore] = None,
        graph_store: Optional[GraphStore] = None
    ):
        self.metadata = metadata_store
        self.semantic = semantic_store
        self.graph = graph_store
    
    def health_check(self) -> Dict[str, bool]:
        """
        Check health of all stores.
        
        Returns:
            Dictionary with health status of each store
        """
        health = {
            "metadata": self.metadata.health_check()
        }
        
        if self.semantic:
            health["semantic"] = self.semantic.health_check()
        
        if self.graph:
            health["graph"] = self.graph.health_check()
        
        return health
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get statistics from all stores.
        
        Returns:
            Combined statistics dictionary
        """
        stats = {
            "metadata": self.metadata.get_stats()
        }
        
        if self.semantic:
            stats["semantic"] = self.semantic.get_stats()
        
        if self.graph:
            stats["graph"] = self.graph.get_stats()
        
        return stats