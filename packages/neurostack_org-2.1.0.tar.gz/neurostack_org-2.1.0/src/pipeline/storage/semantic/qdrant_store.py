"""
Qdrant vector store implementation.

Implements the SemanticStore protocol using Qdrant as the backend.
Qdrant is an open-source vector database optimized for similarity search
with rich metadata filtering.

Features:
- Self-hosted or Qdrant Cloud deployment
- Native metadata filtering (pre-filter strategy)
- Payload-based permission enforcement
- Collection-based multi-tenancy
- Batch upsert for performance
- gRPC and REST API support

Documentation: https://qdrant.tech/documentation/

Design:
- One collection per deployment (all tenants)
- tenant_id in payload for isolation
- Permission metadata (user_ids, team_ids, scope) stored in payload
- Pre-filter strategy: metadata filter applied during vector search
"""

import logging
import uuid
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timezone

try:
    from qdrant_client import QdrantClient
    from qdrant_client.models import (
        Distance,
        VectorParams,
        PointStruct,
        Filter,
        FieldCondition,
        MatchValue,
        MatchAny,
        PayloadSchemaType,
    )
    QDRANT_AVAILABLE = True
except ImportError:
    QDRANT_AVAILABLE = False

from ..interfaces import SemanticStore, StorageError, StorageWriteError, StorageReadError


# ============================================================================
# LOGGING
# ============================================================================

logger = logging.getLogger("neurostack.pipeline.storage.semantic.qdrant")


# ============================================================================
# QDRANT CONFIGURATION
# ============================================================================

@dataclass
class QdrantConfig:
    """
    Qdrant configuration.

    Supports local (in-memory/disk), self-hosted, and Qdrant Cloud.
    """
    # Connection
    host: str = "localhost"
    port: int = 6333
    grpc_port: int = 6334
    api_key: Optional[str] = None        # For Qdrant Cloud
    url: Optional[str] = None            # Full URL (overrides host/port)
    prefer_grpc: bool = True             # gRPC is faster than REST

    # Collection
    collection_name: str = "neurostack"
    dimension: int = 1536                # Must match embedding model
    distance: str = "cosine"             # "cosine", "euclid", or "dot"

    # Performance
    batch_size: int = 100                # Points per batch upsert
    max_retries: int = 3
    timeout: int = 30                    # Request timeout (seconds)

    # On-disk settings
    on_disk_payload: bool = True         # Store payloads on disk (saves RAM)

    # Local mode (for testing/development)
    local_path: Optional[str] = None     # Path for local persistent storage
    in_memory: bool = False              # In-memory mode (no persistence)


# ============================================================================
# QDRANT STORE
# ============================================================================

class QdrantStore:
    """
    Qdrant implementation of SemanticStore.

    Stores vector embeddings with permission-aware metadata for
    similarity search with pre-filter access control.

    Payload structure per point:
    - content_id: Content identifier
    - tenant_id: Tenant identifier
    - source_type: Source connector type
    - knowledge_type: Type of knowledge
    - timestamp: ISO format timestamp
    - scope: Visibility scope (public/team/private/restricted)
    - user_ids: List of allowed user IDs
    - team_ids: List of allowed team IDs
    - chunk_id: Chunk identifier (for multi-chunk documents)

    Usage:
        config = QdrantConfig(host="localhost", port=6333, dimension=1536)
        store = QdrantStore(config)

        # Write embedding with permission metadata
        store.write_embedding(
            content_id="doc_123",
            vector=[0.1, 0.2, ...],
            metadata={
                "tenant_id": "acme",
                "source_type": "jira",
                "scope": "team",
                "user_ids": ["alice", "bob"],
                "team_ids": ["engineering"],
            }
        )

        # Permission-filtered search
        results = store.search(
            query_vector=[0.1, 0.2, ...],
            filters={
                "tenant_id": "acme",
                "user_id": "alice",
                "team_ids": ["engineering"],
            },
            top_k=10
        )
    """

    def __init__(self, config: QdrantConfig):
        """
        Initialize Qdrant store.

        Args:
            config: Qdrant configuration

        Raises:
            ImportError: If qdrant-client not installed
            StorageError: If connection fails
        """
        if not QDRANT_AVAILABLE:
            raise ImportError(
                "qdrant-client not installed. Install with: pip install qdrant-client"
            )

        self.config = config

        # Initialize Qdrant client
        try:
            if config.in_memory:
                self.client = QdrantClient(location=":memory:")
            elif config.local_path:
                self.client = QdrantClient(path=config.local_path)
            elif config.url:
                self.client = QdrantClient(
                    url=config.url,
                    api_key=config.api_key,
                    prefer_grpc=config.prefer_grpc,
                    timeout=config.timeout,
                )
            else:
                self.client = QdrantClient(
                    host=config.host,
                    port=config.port,
                    grpc_port=config.grpc_port,
                    api_key=config.api_key,
                    prefer_grpc=config.prefer_grpc,
                    timeout=config.timeout,
                )
        except Exception as e:
            raise StorageError(f"Failed to initialize Qdrant client: {e}") from e

        # Ensure collection exists
        self._ensure_collection()

        # Stats
        self.writes = 0
        self.reads = 0
        self.errors = 0

        logger.info(f"Connected to collection: {config.collection_name}")

    # -------------------------
    # COLLECTION MANAGEMENT
    # -------------------------

    def _ensure_collection(self) -> None:
        """Create collection if it doesn't exist."""
        collection_name = self.config.collection_name

        try:
            collections = self.client.get_collections().collections
            existing_names = [c.name for c in collections]

            if collection_name in existing_names:
                logger.info(f"Using existing collection: {collection_name}")
                return

            # Map distance metric
            distance_map = {
                "cosine": Distance.COSINE,
                "euclid": Distance.EUCLID,
                "dot": Distance.DOT,
            }
            distance = distance_map.get(self.config.distance, Distance.COSINE)

            # Create collection
            self.client.create_collection(
                collection_name=collection_name,
                vectors_config=VectorParams(
                    size=self.config.dimension,
                    distance=distance,
                    on_disk=self.config.on_disk_payload,
                ),
            )

            # Create payload indexes for fast filtering
            self._create_payload_indexes()

            logger.info(f"Created collection: {collection_name}")

        except Exception as e:
            raise StorageError(f"Failed to ensure collection: {e}") from e

    def _create_payload_indexes(self) -> None:
        """Create payload indexes for permission filtering."""
        collection = self.config.collection_name

        index_fields = {
            "tenant_id": PayloadSchemaType.KEYWORD,
            "content_id": PayloadSchemaType.KEYWORD,
            "source_type": PayloadSchemaType.KEYWORD,
            "knowledge_type": PayloadSchemaType.KEYWORD,
            "scope": PayloadSchemaType.KEYWORD,
            "user_ids": PayloadSchemaType.KEYWORD,
            "team_ids": PayloadSchemaType.KEYWORD,
        }

        for field_name, schema_type in index_fields.items():
            try:
                self.client.create_payload_index(
                    collection_name=collection,
                    field_name=field_name,
                    field_schema=schema_type,
                )
            except Exception as e:
                # Index may already exist
                logger.debug(f"Payload index creation for {field_name}: {e}")

    # -------------------------
    # WRITE OPERATIONS
    # -------------------------

    def write_embedding(
        self,
        content_id: str,
        vector: List[float],
        metadata: Dict[str, Any],
    ) -> None:
        """
        Write embedding vector with metadata.

        Args:
            content_id: Content identifier
            vector: Embedding vector
            metadata: Metadata including permission fields

        Raises:
            StorageWriteError: If write fails
        """
        try:
            point_id = self._generate_point_id(content_id, metadata)

            # Ensure content_id is in payload
            payload = dict(metadata)
            payload["content_id"] = content_id

            point = PointStruct(
                id=point_id,
                vector=vector,
                payload=payload,
            )

            self.client.upsert(
                collection_name=self.config.collection_name,
                points=[point],
            )

            self.writes += 1

        except Exception as e:
            self.errors += 1
            raise StorageWriteError(f"Failed to write embedding: {e}") from e

    def batch_write(
        self,
        embeddings: List[Tuple[str, List[float], Dict[str, Any]]],
    ) -> int:
        """
        Batch write embeddings.

        Args:
            embeddings: List of (content_id, vector, metadata) tuples

        Returns:
            Number of embeddings written
        """
        if not embeddings:
            return 0

        try:
            points = []
            for content_id, vector, metadata in embeddings:
                point_id = self._generate_point_id(content_id, metadata)

                payload = dict(metadata)
                payload["content_id"] = content_id

                points.append(PointStruct(
                    id=point_id,
                    vector=vector,
                    payload=payload,
                ))

            # Upsert in batches
            total_written = 0
            batch_size = self.config.batch_size

            for i in range(0, len(points), batch_size):
                batch = points[i:i + batch_size]

                self.client.upsert(
                    collection_name=self.config.collection_name,
                    points=batch,
                )

                total_written += len(batch)
                self.writes += len(batch)

            return total_written

        except Exception as e:
            self.errors += 1
            raise StorageWriteError(f"Failed to batch write embeddings: {e}") from e

    # -------------------------
    # SEARCH OPERATIONS
    # -------------------------

    def search(
        self,
        query_vector: List[float],
        filters: Dict[str, Any],
        top_k: int = 10,
    ) -> List[Tuple[str, float, Dict[str, Any]]]:
        """
        Permission-aware semantic search.

        Builds a Qdrant filter that enforces:
        1. Tenant isolation (tenant_id must match)
        2. Access control: scope=public OR user in user_ids OR team in team_ids

        Args:
            query_vector: Query embedding
            filters: Must include tenant_id; may include user_id, team_ids
            top_k: Number of results

        Returns:
            List of (content_id, score, metadata) tuples
        """
        try:
            qdrant_filter = self._build_permission_filter(filters)

            results = self.client.search(
                collection_name=self.config.collection_name,
                query_vector=query_vector,
                query_filter=qdrant_filter,
                limit=top_k,
                with_payload=True,
            )

            self.reads += 1

            parsed = []
            for scored_point in results:
                payload = scored_point.payload or {}
                content_id = payload.get("content_id", str(scored_point.id))
                parsed.append((content_id, scored_point.score, payload))

            return parsed

        except Exception as e:
            self.errors += 1
            raise StorageReadError(f"Failed to search: {e}") from e

    # -------------------------
    # DELETE OPERATIONS
    # -------------------------

    def delete_embedding(self, content_id: str) -> bool:
        """
        Delete all embeddings for a content_id.

        Args:
            content_id: Content identifier

        Returns:
            True if any points deleted
        """
        try:
            self.client.delete(
                collection_name=self.config.collection_name,
                points_selector=Filter(
                    must=[
                        FieldCondition(
                            key="content_id",
                            match=MatchValue(value=content_id),
                        )
                    ]
                ),
            )
            return True

        except Exception as e:
            self.errors += 1
            logger.error(f"Failed to delete embedding: {e}")
            return False

    # -------------------------
    # UPDATE OPERATIONS
    # -------------------------

    def update_metadata(
        self,
        content_id: str,
        metadata: Dict[str, Any],
    ) -> bool:
        """
        Update payload metadata for existing embedding.

        Useful for permission changes without re-embedding.

        Args:
            content_id: Content identifier
            metadata: New metadata fields to set

        Returns:
            True if updated
        """
        try:
            self.client.set_payload(
                collection_name=self.config.collection_name,
                payload=metadata,
                points=Filter(
                    must=[
                        FieldCondition(
                            key="content_id",
                            match=MatchValue(value=content_id),
                        )
                    ]
                ),
            )
            return True

        except Exception as e:
            self.errors += 1
            logger.error(f"Failed to update metadata: {e}")
            return False

    # -------------------------
    # FILTER BUILDING
    # -------------------------

    def _build_permission_filter(self, filters: Dict[str, Any]) -> Optional[Filter]:
        """
        Build Qdrant filter with permission enforcement.

        Strategy (pre-filter):
        - MUST match tenant_id
        - SHOULD match at least one of:
          * scope == "public"
          * user_id in user_ids
          * any of user's team_ids in team_ids

        Args:
            filters: Filter dict with tenant_id, user_id, team_ids, etc.

        Returns:
            Qdrant Filter object
        """
        must_conditions = []

        # Tenant isolation (always required)
        tenant_id = filters.get("tenant_id")
        if tenant_id:
            must_conditions.append(
                FieldCondition(
                    key="tenant_id",
                    match=MatchValue(value=tenant_id),
                )
            )

        # Permission filter: public OR user-visible OR team-visible
        user_id = filters.get("user_id")
        user_team_ids = filters.get("team_ids", [])

        if user_id or user_team_ids:
            # Build OR conditions for access control
            should_conditions = []

            # Public content is always visible
            should_conditions.append(
                FieldCondition(
                    key="scope",
                    match=MatchValue(value="public"),
                )
            )

            # Content where user is explicitly listed
            if user_id:
                should_conditions.append(
                    FieldCondition(
                        key="user_ids",
                        match=MatchValue(value=user_id),
                    )
                )

            # Content visible to user's teams
            for team_id in user_team_ids:
                should_conditions.append(
                    FieldCondition(
                        key="team_ids",
                        match=MatchValue(value=team_id),
                    )
                )

            # At least one should condition must match
            must_conditions.append(
                Filter(should=should_conditions)
            )

        # Additional non-permission filters
        for key in ["source_type", "knowledge_type"]:
            if key in filters:
                must_conditions.append(
                    FieldCondition(
                        key=key,
                        match=MatchValue(value=filters[key]),
                    )
                )

        if not must_conditions:
            return None

        return Filter(must=must_conditions)

    # -------------------------
    # ID MANAGEMENT
    # -------------------------

    def _generate_point_id(
        self,
        content_id: str,
        metadata: Dict[str, Any],
    ) -> str:
        """
        Generate unique point ID.

        Qdrant supports string or integer IDs.
        We use UUID-based string IDs for uniqueness.

        Args:
            content_id: Content identifier
            metadata: Metadata (may contain chunk_id)

        Returns:
            Point ID string
        """
        chunk_id = metadata.get("chunk_id", "")

        if chunk_id:
            # Deterministic ID for chunk-level deduplication
            raw = f"{content_id}_{chunk_id}"
            return str(uuid.uuid5(uuid.NAMESPACE_URL, raw))
        else:
            return str(uuid.uuid5(uuid.NAMESPACE_URL, content_id))

    # -------------------------
    # HEALTH & STATS
    # -------------------------

    def health_check(self) -> bool:
        """
        Check if Qdrant store is healthy.

        Returns:
            True if accessible
        """
        try:
            collections = self.client.get_collections()
            return collections is not None
        except Exception:
            return False

    def get_stats(self) -> Dict[str, Any]:
        """
        Get storage statistics.

        Returns:
            Dictionary with stats
        """
        try:
            info = self.client.get_collection(self.config.collection_name)

            return {
                "collection_name": self.config.collection_name,
                "dimension": self.config.dimension,
                "distance": self.config.distance,
                "total_vectors": info.points_count,
                "indexed_vectors": info.indexed_vectors_count,
                "status": info.status.value if info.status else "unknown",
                "writes": self.writes,
                "reads": self.reads,
                "errors": self.errors,
            }

        except Exception as e:
            return {
                "error": str(e),
                "writes": self.writes,
                "reads": self.reads,
                "errors": self.errors,
            }

    def delete_collection(self) -> bool:
        """
        Delete the entire collection.

        WARNING: Destructive and irreversible!

        Returns:
            True if deleted
        """
        try:
            self.client.delete_collection(self.config.collection_name)
            logger.info(f"Deleted collection: {self.config.collection_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete collection: {e}")
            return False


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def create_qdrant_store(
    host: str = "localhost",
    port: int = 6333,
    collection_name: str = "neurostack",
    dimension: int = 1536,
    **kwargs,
) -> QdrantStore:
    """
    Helper to create Qdrant store.

    Args:
        host: Qdrant host
        port: Qdrant REST port
        collection_name: Collection name
        dimension: Vector dimension
        **kwargs: Additional QdrantConfig parameters

    Returns:
        QdrantStore instance
    """
    config = QdrantConfig(
        host=host,
        port=port,
        collection_name=collection_name,
        dimension=dimension,
        **kwargs,
    )

    return QdrantStore(config)


def create_qdrant_store_local(
    path: Optional[str] = None,
    in_memory: bool = True,
    collection_name: str = "neurostack",
    dimension: int = 1536,
) -> QdrantStore:
    """
    Create local Qdrant store for development/testing.

    Args:
        path: Local storage path (None for in-memory)
        in_memory: Use in-memory storage
        collection_name: Collection name
        dimension: Vector dimension

    Returns:
        QdrantStore instance
    """
    config = QdrantConfig(
        collection_name=collection_name,
        dimension=dimension,
        local_path=path,
        in_memory=in_memory,
    )

    return QdrantStore(config)
