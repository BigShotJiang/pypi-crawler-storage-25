"""Semantic (vector) storage implementations."""
