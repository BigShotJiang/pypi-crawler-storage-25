"""
Abstract connector interface.

All data source connectors (Jira, Slack, Google Workspace, etc.) must
implement this interface. This enables pluggable, isolated connector
implementations.

Connectors are responsible for:
1. Authentication (OAuth, API keys)
2. Data extraction from source
3. Permission mapping (source permissions → standard format)
4. Incremental updates (cursors, timestamps)
5. Error handling and retries
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional, Dict, Any, Iterator


# ============================================================================
# CONNECTOR ENUMS
# ============================================================================

class ConnectorType(Enum):
    """Connector execution type"""
    BATCH = "batch"              # Scheduled batch ingestion (docs, historical data)
    STREAMING = "streaming"      # Real-time streaming (webhooks)
    LIVE = "live"                # On-demand live data (calendar availability)
    HYBRID = "hybrid"            # Supports both batch and streaming


class ConnectorAuthType(Enum):
    """Authentication method"""
    OAUTH_USER = "oauth_user"           # User OAuth (personal data)
    OAUTH_ADMIN = "oauth_admin"         # Admin/service account OAuth (shared data)
    API_KEY = "api_key"                 # API key authentication
    SERVICE_ACCOUNT = "service_account" # Service account credentials
    HYBRID = "hybrid"                   # Supports multiple auth types


class ConnectorStatus(Enum):
    """Connector execution status"""
    IDLE = "idle"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    RATE_LIMITED = "rate_limited"
    AUTH_FAILED = "auth_failed"


class IncrementalMode(Enum):
    """How connector handles incremental updates"""
    FULL = "full"                  # Always full re-ingestion
    TIMESTAMP = "timestamp"        # Use timestamp-based filtering
    CURSOR = "cursor"              # Use cursor/pagination token
    WEBHOOK = "webhook"            # Event-driven updates
    NOT_SUPPORTED = "not_supported"


# ============================================================================
# CONNECTOR DATA MODELS
# ============================================================================

@dataclass
class ConnectorConfig:
    """
    Connector configuration.
    
    Passed to connector during initialization.
    """
    connector_id: str              # Unique connector instance ID
    connector_type: str            # "jira", "slack", "google_docs", etc.
    tenant_id: str                 # Tenant isolation
    
    # Authentication
    auth_type: ConnectorAuthType
    credentials: Dict[str, Any]    # Auth credentials (tokens, keys, etc.)
    
    # Execution settings
    batch_size: int = 100          # Items per batch
    rate_limit_per_minute: int = 60
    timeout_seconds: int = 300
    
    # Incremental settings
    incremental_mode: IncrementalMode = IncrementalMode.TIMESTAMP
    last_sync_timestamp: Optional[datetime] = None
    last_cursor: Optional[str] = None
    
    # Connector-specific settings
    custom_config: Dict[str, Any] = field(default_factory=dict)
    
    # Filtering (optional)
    include_filters: Dict[str, Any] = field(default_factory=dict)  # e.g., {"project_ids": ["PROJ-1"]}
    exclude_filters: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RawItem:
    """
    Raw item extracted from source system.
    
    This is the unprocessed data from the source API.
    Pipeline will normalize this into Knowledge objects.
    """
    source_id: str                 # Original ID from source system
    source_type: str               # "jira_issue", "slack_message", etc.
    raw_data: Dict[str, Any]       # Complete raw response from API
    
    # Extraction metadata
    extracted_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    extractor_version: str = "1.0"
    
    # Optional
    source_url: Optional[str] = None       # Link back to source
    parent_id: Optional[str] = None        # For hierarchical data (comment → issue)


@dataclass
class PermissionMetadata:
    """
    Permission metadata extracted from source.
    
    Connector extracts this. Permission engine will convert to standard format.
    """
    source_id: str                 # Links to RawItem
    raw_permissions: Dict[str, Any]  # Source-specific permission data
    
    # Hints for permission engine (optional pre-processing)
    suggested_scope: Optional[str] = None       # "public" | "team" | "private"
    suggested_user_ids: List[str] = field(default_factory=list)
    suggested_team_ids: List[str] = field(default_factory=list)


@dataclass
class ExtractionBatch:
    """
    Batch of items extracted from source.
    
    Returned by connector's extract() method.
    """
    items: List[RawItem]
    permissions: List[PermissionMetadata]
    
    # Pagination
    next_cursor: Optional[str] = None
    has_more: bool = False
    
    # Metadata
    batch_number: int = 1
    total_items_in_batch: int = 0
    
    def __post_init__(self):
        self.total_items_in_batch = len(self.items)


@dataclass
class ConnectorResult:
    """
    Result of connector execution.
    
    Returned after connector completes (or fails).
    """
    connector_id: str
    status: ConnectorStatus
    
    # Execution metadata
    started_at: datetime
    completed_at: Optional[datetime] = None
    
    # Stats
    items_extracted: int = 0
    items_failed: int = 0
    batches_processed: int = 0
    
    # State for resume
    last_cursor: Optional[str] = None
    last_timestamp: Optional[datetime] = None
    
    # Errors
    error_message: Optional[str] = None
    error_details: List[str] = field(default_factory=list)
    
    # Rate limiting
    rate_limited_at: Optional[datetime] = None
    retry_after_seconds: Optional[int] = None


# ============================================================================
# ABSTRACT CONNECTOR BASE CLASS
# ============================================================================

class Connector(ABC):
    """
    Abstract base class for all connectors.
    
    All connectors (Jira, Slack, Google Workspace, etc.) must inherit
    from this class and implement all abstract methods.
    
    Lifecycle:
    1. __init__(config)
    2. authenticate()
    3. validate_config()
    4. extract_batch() (called repeatedly)
    5. cleanup()
    """
    
    def __init__(self, config: ConnectorConfig):
        """
        Initialize connector with configuration.
        
        Args:
            config: Connector configuration
        """
        self.config = config
        self.connector_id = config.connector_id
        self.tenant_id = config.tenant_id
        
        # Internal state
        self._authenticated = False
        self._current_cursor: Optional[str] = config.last_cursor
        self._items_extracted = 0
        self._errors: List[str] = []
    
    # -------------------------
    # ABSTRACT METHODS (must implement)
    # -------------------------
    
    @abstractmethod
    def authenticate(self) -> bool:
        """
        Authenticate with source system.
        
        This method should:
        - Validate credentials
        - Obtain access tokens (if OAuth)
        - Test connectivity
        - Set self._authenticated = True on success
        
        Returns:
            True if authentication successful
            
        Raises:
            ConnectorAuthError: If authentication fails
        """
        pass
    
    @abstractmethod
    def validate_config(self) -> bool:
        """
        Validate connector configuration.
        
        Check:
        - Required config fields present
        - Credentials format valid
        - Custom config valid
        
        Returns:
            True if configuration valid
            
        Raises:
            ConnectorConfigError: If config invalid
        """
        pass
    
    @abstractmethod
    def extract_batch(
        self,
        cursor: Optional[str] = None,
        batch_size: Optional[int] = None
    ) -> ExtractionBatch:
        """
        Extract one batch of items from source.
        
        This is called repeatedly by orchestrator until has_more=False.
        
        Must be idempotent: same cursor → same results.
        
        Args:
            cursor: Pagination cursor (None = start from beginning)
            batch_size: Override default batch size
            
        Returns:
            ExtractionBatch with items and permissions
            
        Raises:
            ConnectorExtractionError: If extraction fails
        """
        pass
    
    @abstractmethod
    def extract_permissions(self, item: RawItem) -> PermissionMetadata:
        """
        Extract permission metadata from raw item.
        
        This is source-specific logic to determine who can access the item.
        
        Examples:
        - Slack: Parse channel members
        - Jira: Parse project permissions
        - Google Docs: Parse sharing settings
        
        Args:
            item: Raw item extracted from source
            
        Returns:
            Permission metadata
        """
        pass
    
    @abstractmethod
    def supports_incremental(self) -> bool:
        """
        Check if connector supports incremental updates.
        
        Returns:
            True if incremental mode supported
        """
        pass
    
    @abstractmethod
    def get_incremental_mode(self) -> IncrementalMode:
        """
        Get supported incremental update mode.
        
        Returns:
            IncrementalMode enum value
        """
        pass
    
    # -------------------------
    # OPTIONAL METHODS (can override)
    # -------------------------
    
    def test_connection(self) -> bool:
        """
        Test connectivity to source system.
        
        Called during connector registration to verify setup.
        
        Returns:
            True if connection successful
        """
        try:
            return self.authenticate()
        except Exception:
            return False
    
    def get_supported_auth_types(self) -> List[ConnectorAuthType]:
        """
        Get supported authentication types.
        
        Override if connector supports multiple auth types.
        
        Returns:
            List of supported auth types
        """
        return [self.config.auth_type]
    
    def estimate_total_items(self) -> Optional[int]:
        """
        Estimate total number of items to extract.
        
        Used for progress tracking. Optional.
        
        Returns:
            Estimated total items, or None if unknown
        """
        return None
    
    def get_rate_limit_info(self) -> Dict[str, Any]:
        """
        Get current rate limit status.
        
        Override to return source-specific rate limit info.
        
        Returns:
            Dictionary with rate limit info (requests_remaining, reset_at, etc.)
        """
        return {
            "requests_remaining": None,
            "reset_at": None,
            "limit_per_minute": self.config.rate_limit_per_minute
        }
    
    def supports_webhooks(self) -> bool:
        """
        Check if connector supports webhook-based updates.
        
        Returns:
            True if webhooks supported
        """
        return False
    
    def register_webhook(self, callback_url: str) -> bool:
        """
        Register webhook with source system.
        
        Only called if supports_webhooks() returns True.
        
        Args:
            callback_url: URL for webhook callbacks
            
        Returns:
            True if registration successful
        """
        return False
    
    def cleanup(self) -> None:
        """
        Cleanup resources after extraction completes.
        
        Override to close connections, release resources, etc.
        """
        pass
    
    # -------------------------
    # HELPER METHODS (built-in)
    # -------------------------
    
    def is_authenticated(self) -> bool:
        """Check if connector is authenticated"""
        return self._authenticated
    
    def get_current_cursor(self) -> Optional[str]:
        """Get current pagination cursor"""
        return self._current_cursor
    
    def set_current_cursor(self, cursor: Optional[str]) -> None:
        """Update current pagination cursor"""
        self._current_cursor = cursor
    
    def log_error(self, error: str) -> None:
        """Log error message"""
        self._errors.append(error)
    
    def get_errors(self) -> List[str]:
        """Get all logged errors"""
        return self._errors.copy()
    
    def reset_state(self) -> None:
        """Reset internal state (for re-running connector)"""
        self._current_cursor = None
        self._items_extracted = 0
        self._errors.clear()
    
    # -------------------------
    # METADATA (override in subclass)
    # -------------------------
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Connector display name (e.g., "Jira Cloud")"""
        pass
    
    @property
    @abstractmethod
    def version(self) -> str:
        """Connector version (e.g., "1.0.0")"""
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """Connector description"""
        pass


# ============================================================================
# LIVE DATA CONNECTOR (special case)
# ============================================================================

class LiveDataConnector(Connector):
    """
    Special connector for live data that should NOT be stored.
    
    Examples:
    - Calendar availability
    - Current on-call status
    - Real-time system metrics
    
    These connectors fetch data on-demand, return it immediately,
    and do NOT write to storage.
    """
    
    @abstractmethod
    def fetch_live_data(
        self,
        query_params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Fetch live data on-demand.
        
        Args:
            query_params: Query parameters (user_id, date_range, etc.)
            
        Returns:
            Live data dictionary
            
        Raises:
            ConnectorExtractionError: If fetch fails
        """
        pass
    
    def extract_batch(
        self,
        cursor: Optional[str] = None,
        batch_size: Optional[int] = None
    ) -> ExtractionBatch:
        """
        Live data connectors don't support batch extraction.
        
        Raises NotImplementedError.
        """
        raise NotImplementedError("Live data connectors use fetch_live_data() instead")


# ============================================================================
# CONNECTOR EXCEPTIONS
# ============================================================================

class ConnectorError(Exception):
    """Base exception for connector errors"""
    pass


class ConnectorAuthError(ConnectorError):
    """Authentication failed"""
    pass


class ConnectorConfigError(ConnectorError):
    """Invalid configuration"""
    pass


class ConnectorExtractionError(ConnectorError):
    """Data extraction failed"""
    pass


class ConnectorRateLimitError(ConnectorError):
    """Rate limit exceeded"""
    def __init__(self, message: str, retry_after_seconds: Optional[int] = None):
        super().__init__(message)
        self.retry_after_seconds = retry_after_seconds


class ConnectorConnectionError(ConnectorError):
    """Failed to connect to source"""
    pass


class ConnectorPermissionError(ConnectorError):
    """Insufficient permissions to access data"""
    pass


# ============================================================================
# CONNECTOR METADATA (for registry)
# ============================================================================

@dataclass
class ConnectorMetadata:
    """
    Metadata about a connector implementation.
    
    Used by connector registry for discovery and management.
    """
    connector_type: str            # "jira", "slack", etc.
    name: str                      # Display name
    version: str                   # Version
    description: str               # Description
    
    # Capabilities
    supports_incremental: bool
    supports_webhooks: bool
    incremental_modes: List[IncrementalMode]
    auth_types: List[ConnectorAuthType]
    execution_type: ConnectorType
    
    # Implementation
    class_path: str                # Python class path (e.g., "pipeline.connectors.jira.JiraConnector")
    config_schema: Dict[str, Any]  # JSON schema for custom_config
    
    # Documentation
    setup_instructions_url: Optional[str] = None
    example_config: Optional[Dict[str, Any]] = None


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def create_connector_config(
    connector_id: str,
    connector_type: str,
    tenant_id: str,
    auth_type: ConnectorAuthType,
    credentials: Dict[str, Any],
    **kwargs
) -> ConnectorConfig:
    """
    Helper to create ConnectorConfig with defaults.
    
    Args:
        connector_id: Unique connector instance ID
        connector_type: Type of connector
        tenant_id: Tenant ID
        auth_type: Authentication type
        credentials: Credentials dictionary
        **kwargs: Additional config parameters
        
    Returns:
        ConnectorConfig instance
    """
    return ConnectorConfig(
        connector_id=connector_id,
        connector_type=connector_type,
        tenant_id=tenant_id,
        auth_type=auth_type,
        credentials=credentials,
        **kwargs
    )


def validate_credentials(
    auth_type: ConnectorAuthType,
    credentials: Dict[str, Any]
) -> bool:
    """
    Validate credentials format based on auth type.
    
    Args:
        auth_type: Authentication type
        credentials: Credentials dictionary
        
    Returns:
        True if valid
        
    Raises:
        ConnectorConfigError: If credentials invalid
    """
    if auth_type == ConnectorAuthType.API_KEY:
        if "api_key" not in credentials:
            raise ConnectorConfigError("api_key required for API_KEY auth")
    
    elif auth_type in [ConnectorAuthType.OAUTH_USER, ConnectorAuthType.OAUTH_ADMIN]:
        if "access_token" not in credentials:
            raise ConnectorConfigError("access_token required for OAuth")
    
    elif auth_type == ConnectorAuthType.SERVICE_ACCOUNT:
        if "service_account_key" not in credentials:
            raise ConnectorConfigError("service_account_key required")
    
    return True