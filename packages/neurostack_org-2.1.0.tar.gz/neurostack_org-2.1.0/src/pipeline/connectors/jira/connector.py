"""
Jira connector implementation.

Extracts issues (tasks) from Jira Cloud or Jira Server.
Supports both API key and OAuth authentication.

Jira API documentation: https://developer.atlassian.com/cloud/jira/platform/rest/v3/
"""

from datetime import datetime, timedelta, timezone
from typing import List, Optional, Dict, Any
import requests
from requests.auth import HTTPBasicAuth
import logging

from ..base import (
    Connector,
    ConnectorConfig,
    ConnectorAuthType,
    ConnectorStatus,
    ConnectorError,
    ConnectorAuthError,
    ConnectorExtractionError,
    ConnectorRateLimitError,
    RawItem,
    PermissionMetadata,
    ExtractionBatch,
    IncrementalMode
)


# ============================================================================
# LOGGING
# ============================================================================

logger = logging.getLogger("neurostack.pipeline.connectors.jira")


# ============================================================================
# JIRA CONNECTOR
# ============================================================================

class JiraConnector(Connector):
    """
    Jira connector for extracting issues.
    
    Supported features:
    - Jira Cloud and Jira Server
    - API key (email + token) authentication
    - Incremental sync (timestamp-based)
    - JQL filtering
    - Pagination (startAt/maxResults)
    - Permission extraction (project members, issue visibility)
    
    Configuration:
        credentials:
            - email: User email (for API key auth)
            - api_token: Jira API token
            - domain: Jira domain (e.g., "company.atlassian.net")
        
        custom_config:
            - jql_filter: Optional JQL query (e.g., "project = ENG")
            - include_comments: Whether to include comments (default: True)
            - include_attachments: Whether to include attachment metadata (default: False)
    
    Example config:
        {
            "connector_id": "jira_main",
            "connector_type": "jira",
            "tenant_id": "company_a",
            "auth_type": "api_key",
            "credentials": {
                "email": "user@company.com",
                "api_token": "xxx",
                "domain": "company.atlassian.net"
            },
            "custom_config": {
                "jql_filter": "project = ENG AND type != Epic",
                "include_comments": true
            }
        }
    """
    
    # Jira API endpoints
    API_BASE = "https://{domain}/rest/api/3"
    SEARCH_ENDPOINT = "/search"
    MYSELF_ENDPOINT = "/myself"
    
    # Pagination settings
    DEFAULT_PAGE_SIZE = 50
    MAX_PAGE_SIZE = 100
    
    def __init__(self, config: ConnectorConfig):
        """Initialize Jira connector"""
        super().__init__(config)
        
        # Extract Jira-specific config
        self.domain = config.credentials.get("domain")
        self.email = config.credentials.get("email")
        self.api_token = config.credentials.get("api_token")
        
        # Custom config
        self.jql_filter = config.custom_config.get("jql_filter", "")
        self.include_comments = config.custom_config.get("include_comments", True)
        self.include_attachments = config.custom_config.get("include_attachments", False)
        
        # API client
        self.base_url = self.API_BASE.format(domain=self.domain)
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(self.email, self.api_token)
        self.session.headers.update({
            "Accept": "application/json",
            "Content-Type": "application/json"
        })
        
        # Rate limiting tracking
        self._requests_made = 0
        self._last_request_time = None
        
        logger.info(f"Initialized for domain: {self.domain}")
    
    # -------------------------
    # METADATA
    # -------------------------
    
    @property
    def name(self) -> str:
        return "Jira Cloud/Server"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    @property
    def description(self) -> str:
        return "Extracts issues (tasks, bugs, stories) from Jira"
    
    # -------------------------
    # AUTHENTICATION
    # -------------------------
    
    def authenticate(self) -> bool:
        """
        Authenticate with Jira API.
        
        Tests credentials by calling /myself endpoint.
        
        Returns:
            True if authenticated successfully
            
        Raises:
            ConnectorAuthError: If authentication fails
        """
        try:
            # Test authentication with /myself endpoint
            response = self._make_request("GET", self.MYSELF_ENDPOINT)
            
            if response.status_code == 200:
                user_data = response.json()
                logger.info(f"Authenticated as: {user_data.get('displayName', 'Unknown')}")
                self._authenticated = True
                return True
            
            elif response.status_code == 401:
                raise ConnectorAuthError("Invalid credentials")
            
            elif response.status_code == 403:
                raise ConnectorAuthError("Insufficient permissions")
            
            else:
                raise ConnectorAuthError(f"Authentication failed: {response.status_code}")
        
        except requests.exceptions.RequestException as e:
            raise ConnectorAuthError(f"Failed to connect to Jira: {e}") from e
    
    def validate_config(self) -> bool:
        """
        Validate connector configuration.
        
        Returns:
            True if configuration valid
            
        Raises:
            ConnectorConfigError: If configuration invalid
        """
        from ..base import ConnectorConfigError
        
        # Check required credentials
        if not self.domain:
            raise ConnectorConfigError("Missing 'domain' in credentials")
        
        if not self.email:
            raise ConnectorConfigError("Missing 'email' in credentials")
        
        if not self.api_token:
            raise ConnectorConfigError("Missing 'api_token' in credentials")
        
        # Validate domain format
        if not self._is_valid_domain(self.domain):
            raise ConnectorConfigError(f"Invalid domain format: {self.domain}")
        
        return True
    
    def _is_valid_domain(self, domain: str) -> bool:
        """Validate Jira domain format"""
        # Should be like "company.atlassian.net" or "jira.company.com"
        if not domain or len(domain) < 5:
            return False
        if " " in domain:
            return False
        return True
    
    # -------------------------
    # EXTRACTION
    # -------------------------
    
    def extract_batch(
        self,
        cursor: Optional[str] = None,
        batch_size: Optional[int] = None
    ) -> ExtractionBatch:
        """
        Extract one batch of Jira issues.
        
        Uses Jira's /search endpoint with pagination.
        
        Args:
            cursor: Pagination cursor (startAt index as string)
            batch_size: Override default batch size
            
        Returns:
            ExtractionBatch with issues and permissions
            
        Raises:
            ConnectorExtractionError: If extraction fails
            ConnectorRateLimitError: If rate limited
        """
        # Parse cursor (Jira uses numeric startAt)
        start_at = int(cursor) if cursor else 0
        page_size = min(batch_size or self.config.batch_size, self.MAX_PAGE_SIZE)
        
        logger.info(f"Extracting batch (startAt={start_at}, maxResults={page_size})")
        
        try:
            # Build JQL query
            jql = self._build_jql_query()
            
            # Build fields to fetch
            fields = self._get_fields_to_fetch()
            
            # Make API request
            params = {
                "jql": jql,
                "startAt": start_at,
                "maxResults": page_size,
                "fields": ",".join(fields),
                "expand": "names"
            }
            
            response = self._make_request(
                "GET",
                self.SEARCH_ENDPOINT,
                params=params
            )
            
            # Check for rate limiting
            if response.status_code == 429:
                retry_after = int(response.headers.get("Retry-After", 60))
                raise ConnectorRateLimitError(
                    "Jira rate limit exceeded",
                    retry_after_seconds=retry_after
                )
            
            # Check for errors
            if response.status_code != 200:
                raise ConnectorExtractionError(
                    f"Jira API error: {response.status_code} - {response.text}"
                )
            
            # Parse response
            data = response.json()
            issues = data.get("issues", [])
            total = data.get("total", 0)
            
            # Convert to RawItem
            raw_items = []
            permissions = []
            
            for issue in issues:
                raw_item = self._issue_to_raw_item(issue)
                raw_items.append(raw_item)
                
                permission = self.extract_permissions(raw_item)
                permissions.append(permission)
            
            # Determine if more batches
            next_start_at = start_at + len(issues)
            has_more = next_start_at < total
            next_cursor = str(next_start_at) if has_more else None
            
            logger.info(f"Extracted {len(issues)} issues ({next_start_at}/{total})")
            
            return ExtractionBatch(
                items=raw_items,
                permissions=permissions,
                next_cursor=next_cursor,
                has_more=has_more,
                batch_number=start_at // page_size + 1,
                total_items_in_batch=len(raw_items)
            )
        
        except ConnectorRateLimitError:
            raise
        
        except requests.exceptions.RequestException as e:
            raise ConnectorExtractionError(f"Failed to fetch issues: {e}") from e
        
        except Exception as e:
            raise ConnectorExtractionError(f"Unexpected error: {e}") from e
    
    def _build_jql_query(self) -> str:
        """
        Build JQL query with incremental sync support.
        
        Returns:
            JQL query string
        """
        jql_parts = []
        
        # Custom JQL filter
        if self.jql_filter:
            jql_parts.append(f"({self.jql_filter})")
        
        # Incremental sync (timestamp-based)
        if self.config.last_sync_timestamp:
            # Jira uses format: "2024-01-01 00:00"
            timestamp_str = self.config.last_sync_timestamp.strftime("%Y-%m-%d %H:%M")
            jql_parts.append(f'updated >= "{timestamp_str}"')
        
        # Order by updated (for consistent pagination)
        jql = " AND ".join(jql_parts) if jql_parts else "order by updated DESC"
        
        if "order by" not in jql.lower():
            jql += " ORDER BY updated DESC"
        
        return jql
    
    def _get_fields_to_fetch(self) -> List[str]:
        """Get list of fields to fetch from Jira"""
        fields = [
            "summary",
            "description",
            "status",
            "priority",
            "assignee",
            "reporter",
            "created",
            "updated",
            "issuetype",
            "project",
            "labels",
            "components"
        ]
        
        if self.include_comments:
            fields.append("comment")
        
        if self.include_attachments:
            fields.append("attachment")
        
        return fields
    
    def _issue_to_raw_item(self, issue: Dict[str, Any]) -> RawItem:
        """
        Convert Jira issue JSON to RawItem.
        
        Args:
            issue: Jira issue JSON from API
            
        Returns:
            RawItem object
        """
        issue_key = issue.get("key", "")
        issue_id = issue.get("id", "")
        
        # Build source URL
        source_url = f"https://{self.domain}/browse/{issue_key}"
        
        return RawItem(
            source_id=issue_key,
            source_type="jira_issue",
            raw_data=issue,
            extracted_at=datetime.now(timezone.utc),
            extractor_version=self.version,
            source_url=source_url
        )
    
    # -------------------------
    # PERMISSION EXTRACTION
    # -------------------------
    
    def extract_permissions(self, item: RawItem) -> PermissionMetadata:
        """
        Extract permission metadata from Jira issue.
        
        Jira permissions are complex (project-level, issue-level, security levels).
        For MVP, we use project membership as proxy.
        
        Args:
            item: Raw Jira issue
            
        Returns:
            PermissionMetadata
        """
        raw_data = item.raw_data
        fields = raw_data.get("fields", {})
        
        # Extract project info
        project = fields.get("project", {})
        project_key = project.get("key", "")
        project_id = project.get("id", "")
        
        # Extract reporter and assignee (guaranteed visibility)
        reporter = fields.get("reporter", {})
        assignee = fields.get("assignee", {})
        
        user_ids = []
        
        # Reporter always has access
        if reporter:
            reporter_id = reporter.get("accountId") or reporter.get("emailAddress")
            if reporter_id:
                user_ids.append(reporter_id)
        
        # Assignee always has access
        if assignee:
            assignee_id = assignee.get("accountId") or assignee.get("emailAddress")
            if assignee_id:
                user_ids.append(assignee_id)
        
        # Determine visibility scope
        # For Jira, most issues are project-level visible
        suggested_scope = "team"  # Project team
        
        # Check for restricted issues (security level)
        security = fields.get("security")
        if security:
            # Issue has security level = more restricted
            suggested_scope = "private"
        
        return PermissionMetadata(
            source_id=item.source_id,
            raw_permissions={
                "project_key": project_key,
                "project_id": project_id,
                "reporter": reporter,
                "assignee": assignee,
                "security_level": security,
                "issue_type": fields.get("issuetype", {}).get("name", "")
            },
            suggested_scope=suggested_scope,
            suggested_user_ids=list(set(user_ids)),  # Deduplicate
            suggested_team_ids=[project_key] if project_key else []
        )
    
    # -------------------------
    # INCREMENTAL SUPPORT
    # -------------------------
    
    def supports_incremental(self) -> bool:
        """Jira supports timestamp-based incremental sync"""
        return True
    
    def get_incremental_mode(self) -> IncrementalMode:
        """Jira uses timestamp-based incremental sync"""
        return IncrementalMode.TIMESTAMP
    
    # -------------------------
    # RATE LIMITING
    # -------------------------
    
    def get_rate_limit_info(self) -> Dict[str, Any]:
        """
        Get Jira rate limit info.
        
        Jira Cloud rate limits:
        - Free: ~150 requests/minute
        - Standard: ~300 requests/minute
        - Premium: Higher limits
        
        Returns:
            Rate limit info dictionary
        """
        return {
            "requests_made": self._requests_made,
            "limit_per_minute": self.config.rate_limit_per_minute,
            "last_request_time": self._last_request_time.isoformat() if self._last_request_time else None,
            "note": "Jira Cloud has dynamic rate limits based on plan"
        }
    
    # -------------------------
    # HTTP CLIENT
    # -------------------------
    
    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None
    ) -> requests.Response:
        """
        Make HTTP request to Jira API.
        
        Handles rate limiting tracking and retries.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            params: Query parameters
            json_data: JSON body
            
        Returns:
            Response object
            
        Raises:
            requests.exceptions.RequestException: If request fails
        """
        url = self.base_url + endpoint
        
        # Track request for rate limiting
        self._requests_made += 1
        self._last_request_time = datetime.now(timezone.utc)
        
        # Make request with timeout
        response = self.session.request(
            method=method,
            url=url,
            params=params,
            json=json_data,
            timeout=self.config.timeout_seconds
        )
        
        return response
    
    # -------------------------
    # CLEANUP
    # -------------------------
    
    def cleanup(self) -> None:
        """Cleanup resources"""
        if self.session:
            self.session.close()
        
        logger.info("Cleanup complete")
    
    # -------------------------
    # OPTIONAL: WEBHOOKS (not implemented for MVP)
    # -------------------------
    
    def supports_webhooks(self) -> bool:
        """Jira supports webhooks but not implemented in MVP"""
        return False


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def create_jira_config(
    connector_id: str,
    tenant_id: str,
    email: str,
    api_token: str,
    domain: str,
    jql_filter: Optional[str] = None,
    **kwargs
) -> ConnectorConfig:
    """
    Helper to create Jira connector config.
    
    Args:
        connector_id: Unique connector ID
        tenant_id: Tenant ID
        email: Jira user email
        api_token: Jira API token
        domain: Jira domain (e.g., "company.atlassian.net")
        jql_filter: Optional JQL filter
        **kwargs: Additional config parameters
        
    Returns:
        ConnectorConfig for Jira
    """
    custom_config = {}
    if jql_filter:
        custom_config["jql_filter"] = jql_filter
    
    custom_config.update(kwargs.get("custom_config", {}))
    
    return ConnectorConfig(
        connector_id=connector_id,
        connector_type="jira",
        tenant_id=tenant_id,
        auth_type=ConnectorAuthType.API_KEY,
        credentials={
            "email": email,
            "api_token": api_token,
            "domain": domain
        },
        custom_config=custom_config,
        **{k: v for k, v in kwargs.items() if k != "custom_config"}
    )