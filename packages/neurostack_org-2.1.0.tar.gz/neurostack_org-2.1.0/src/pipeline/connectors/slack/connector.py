"""
Slack connector implementation.

Extracts messages, threads, and files from Slack workspaces.
Handles both public/private channels and direct messages.

Slack is a HYBRID connector:
- Shared data: Public channels, shared private channels
- Personal data: DMs, private channels (user-specific)

This requires careful permission handling to avoid duplicate ingestion
of public channels accessed by multiple users.

Slack API documentation: https://api.slack.com/docs
"""

import time
from datetime import datetime, timedelta, timezone
from typing import List, Optional, Dict, Any, Set
import requests
import logging

from ..base import (
    Connector,
    ConnectorConfig,
    ConnectorAuthType,
    ConnectorStatus,
    ConnectorError,
    ConnectorAuthError,
    ConnectorExtractionError,
    ConnectorRateLimitError,
    RawItem,
    PermissionMetadata,
    ExtractionBatch,
    IncrementalMode
)


# ============================================================================
# LOGGING
# ============================================================================

logger = logging.getLogger("neurostack.pipeline.connectors.slack")


# ============================================================================
# SLACK CONNECTOR
# ============================================================================

class SlackConnector(Connector):
    """
    Slack connector for extracting messages and threads.
    
    Supported features:
    - Public channels
    - Private channels
    - Direct messages
    - Threaded conversations
    - File metadata (not file content for MVP)
    - Incremental sync (timestamp-based)
    - Deduplication of shared channels
    
    Authentication:
    - User OAuth token (for personal data: DMs, private channels)
    - Bot token (for shared data: public channels)
    
    Configuration:
        credentials:
            - user_token: User OAuth token (xoxp-...)
            - bot_token: Bot OAuth token (xoxb-...) [optional]
            - workspace_id: Slack workspace ID
        
        custom_config:
            - include_public_channels: Whether to fetch public channels (default: True)
            - include_private_channels: Whether to fetch private channels (default: True)
            - include_dms: Whether to fetch direct messages (default: True)
            - include_threads: Whether to fetch thread replies (default: True)
            - include_files: Whether to include file metadata (default: True)
            - max_messages_per_channel: Limit per channel (default: 1000)
    
    Example config:
        {
            "connector_id": "slack_main",
            "connector_type": "slack",
            "tenant_id": "company_a",
            "auth_type": "oauth_user",
            "credentials": {
                "user_token": "xoxp-...",
                "workspace_id": "T123456"
            },
            "custom_config": {
                "include_public_channels": true,
                "include_private_channels": true,
                "include_dms": true,
                "include_threads": true
            }
        }
    """
    
    # Slack API endpoints
    API_BASE = "https://slack.com/api"
    
    # Methods
    CONVERSATIONS_LIST = "/conversations.list"
    CONVERSATIONS_HISTORY = "/conversations.history"
    CONVERSATIONS_REPLIES = "/conversations.replies"
    CONVERSATIONS_MEMBERS = "/conversations.members"
    USERS_INFO = "/users.info"
    AUTH_TEST = "/auth.test"
    
    # Rate limits (Tier 3: 50+ requests/minute)
    # https://api.slack.com/docs/rate-limits
    RATE_LIMIT_PER_MINUTE = 50
    
    # Pagination
    DEFAULT_PAGE_SIZE = 100  # Messages per request
    MAX_PAGE_SIZE = 200
    
    def __init__(self, config: ConnectorConfig):
        """Initialize Slack connector"""
        super().__init__(config)
        
        # Extract Slack-specific config
        self.user_token = config.credentials.get("user_token")
        self.bot_token = config.credentials.get("bot_token")  # Optional
        self.workspace_id = config.credentials.get("workspace_id")
        
        # Custom config
        self.include_public_channels = config.custom_config.get("include_public_channels", True)
        self.include_private_channels = config.custom_config.get("include_private_channels", True)
        self.include_dms = config.custom_config.get("include_dms", True)
        self.include_threads = config.custom_config.get("include_threads", True)
        self.include_files = config.custom_config.get("include_files", True)
        self.max_messages_per_channel = config.custom_config.get("max_messages_per_channel", 1000)
        
        # API client
        self.session = requests.Session()
        
        # Cache
        self._user_cache: Dict[str, Dict[str, Any]] = {}  # user_id -> user_info
        self._channel_cache: Dict[str, Dict[str, Any]] = {}  # channel_id -> channel_info
        self._processed_channels: Set[str] = set()  # For deduplication
        
        # Rate limiting tracking
        self._requests_made = 0
        self._last_request_time = None
        self._minute_start = datetime.now(timezone.utc)
        
        logger.info(f"Initialized for workspace: {self.workspace_id}")
    
    # -------------------------
    # METADATA
    # -------------------------
    
    @property
    def name(self) -> str:
        return "Slack"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    @property
    def description(self) -> str:
        return "Extracts messages, threads, and files from Slack workspaces"
    
    # -------------------------
    # AUTHENTICATION
    # -------------------------
    
    def authenticate(self) -> bool:
        """
        Authenticate with Slack API.
        
        Tests user token (and optionally bot token) by calling auth.test.
        
        Returns:
            True if authenticated successfully
            
        Raises:
            ConnectorAuthError: If authentication fails
        """
        try:
            # Test user token
            response = self._make_request(
                "GET",
                self.AUTH_TEST,
                use_user_token=True
            )
            
            if not response.get("ok"):
                error = response.get("error", "Unknown error")
                raise ConnectorAuthError(f"User token authentication failed: {error}")
            
            # Store user info
            user_id = response.get("user_id")
            team_id = response.get("team_id")
            
            logger.info(f"Authenticated as user: {user_id} in team: {team_id}")
            
            # Test bot token if provided
            if self.bot_token:
                bot_response = self._make_request(
                    "GET",
                    self.AUTH_TEST,
                    use_user_token=False
                )
                
                if not bot_response.get("ok"):
                    logger.warning("Bot token invalid, will use user token only")
                    self.bot_token = None
                else:
                    logger.info("Bot token validated")
            
            self._authenticated = True
            return True
        
        except requests.exceptions.RequestException as e:
            raise ConnectorAuthError(f"Failed to connect to Slack: {e}") from e
    
    def validate_config(self) -> bool:
        """
        Validate connector configuration.
        
        Returns:
            True if configuration valid
            
        Raises:
            ConnectorConfigError: If configuration invalid
        """
        from ..base import ConnectorConfigError
        
        # Check required credentials
        if not self.user_token:
            raise ConnectorConfigError("Missing 'user_token' in credentials")
        
        if not self.workspace_id:
            raise ConnectorConfigError("Missing 'workspace_id' in credentials")
        
        # Validate token format
        if not self.user_token.startswith("xoxp-"):
            raise ConnectorConfigError("Invalid user_token format (should start with 'xoxp-')")
        
        if self.bot_token and not self.bot_token.startswith("xoxb-"):
            raise ConnectorConfigError("Invalid bot_token format (should start with 'xoxb-')")
        
        return True
    
    # -------------------------
    # EXTRACTION
    # -------------------------
    
    def extract_batch(
        self,
        cursor: Optional[str] = None,
        batch_size: Optional[int] = None
    ) -> ExtractionBatch:
        """
        Extract one batch of Slack messages.
        
        Slack extraction is complex because we need to:
        1. List all channels (conversations.list)
        2. For each channel, fetch messages (conversations.history)
        3. For each message, optionally fetch thread replies
        
        We use cursor to track: "channel_id:message_cursor"
        
        Args:
            cursor: Pagination cursor (format: "channel_idx:msg_cursor")
            batch_size: Override default batch size
            
        Returns:
            ExtractionBatch with messages and permissions
            
        Raises:
            ConnectorExtractionError: If extraction fails
            ConnectorRateLimitError: If rate limited
        """
        logger.info(f"Extracting batch (cursor={cursor})")
        
        try:
            # Parse cursor
            channel_idx, msg_cursor = self._parse_cursor(cursor)
            
            # Get channels (cached across batches)
            if not self._channel_cache:
                self._fetch_all_channels()
            
            channels = list(self._channel_cache.values())
            
            if channel_idx >= len(channels):
                # No more channels to process
                logger.info("All channels processed")
                return ExtractionBatch(
                    items=[],
                    permissions=[],
                    next_cursor=None,
                    has_more=False,
                    batch_number=1
                )
            
            # Get current channel
            channel = channels[channel_idx]
            channel_id = channel["id"]
            
            # Skip if already processed (deduplication)
            if channel_id in self._processed_channels:
                # Move to next channel
                next_cursor = self._build_cursor(channel_idx + 1, None)
                return self.extract_batch(cursor=next_cursor, batch_size=batch_size)
            
            logger.info(f"Processing channel: {channel.get('name', channel_id)} ({channel_idx + 1}/{len(channels)})")
            
            # Fetch messages from this channel
            messages_data = self._fetch_channel_messages(
                channel_id,
                cursor=msg_cursor,
                limit=batch_size or self.config.batch_size
            )
            
            messages = messages_data["messages"]
            next_msg_cursor = messages_data.get("next_cursor")
            has_more_in_channel = messages_data.get("has_more", False)
            
            # Convert to RawItem
            raw_items = []
            permissions = []
            
            for message in messages:
                # Skip bot messages (optional)
                if message.get("subtype") == "bot_message":
                    continue
                
                # Create raw item
                raw_item = self._message_to_raw_item(message, channel)
                raw_items.append(raw_item)
                
                # Extract permissions
                permission = self.extract_permissions(raw_item)
                permissions.append(permission)
                
                # Fetch thread replies if enabled
                if self.include_threads and message.get("thread_ts"):
                    thread_items, thread_perms = self._fetch_thread_replies(
                        channel_id,
                        message["thread_ts"],
                        channel
                    )
                    raw_items.extend(thread_items)
                    permissions.extend(thread_perms)
            
            # Determine next cursor
            if has_more_in_channel and next_msg_cursor:
                # More messages in this channel
                next_cursor = self._build_cursor(channel_idx, next_msg_cursor)
                has_more = True
            else:
                # Move to next channel
                self._processed_channels.add(channel_id)
                
                if channel_idx + 1 < len(channels):
                    next_cursor = self._build_cursor(channel_idx + 1, None)
                    has_more = True
                else:
                    next_cursor = None
                    has_more = False
            
            logger.info(f"Extracted {len(raw_items)} messages from channel")
            
            return ExtractionBatch(
                items=raw_items,
                permissions=permissions,
                next_cursor=next_cursor,
                has_more=has_more,
                batch_number=channel_idx + 1
            )
        
        except ConnectorRateLimitError:
            raise
        
        except requests.exceptions.RequestException as e:
            raise ConnectorExtractionError(f"Failed to fetch messages: {e}") from e
        
        except Exception as e:
            raise ConnectorExtractionError(f"Unexpected error: {e}") from e
    
    # -------------------------
    # CHANNEL OPERATIONS
    # -------------------------
    
    def _fetch_all_channels(self) -> None:
        """
        Fetch all channels (conversations.list).
        
        Populates self._channel_cache.
        """
        logger.info("Fetching all channels...")
        
        channels = []
        cursor = None
        
        while True:
            # Build request params
            params = {
                "limit": 200,
                "exclude_archived": True,
                "types": self._get_channel_types()
            }
            
            if cursor:
                params["cursor"] = cursor
            
            # Make request
            response = self._make_request(
                "GET",
                self.CONVERSATIONS_LIST,
                params=params,
                use_user_token=True
            )
            
            if not response.get("ok"):
                error = response.get("error", "Unknown error")
                raise ConnectorExtractionError(f"Failed to list channels: {error}")
            
            # Extract channels
            batch = response.get("channels", [])
            channels.extend(batch)
            
            # Check pagination
            cursor = response.get("response_metadata", {}).get("next_cursor")
            if not cursor:
                break
        
        # Cache channels
        for channel in channels:
            self._channel_cache[channel["id"]] = channel
        
        logger.info(f"Fetched {len(channels)} channels")
    
    def _get_channel_types(self) -> str:
        """
        Get channel types to include based on config.
        
        Returns:
            Comma-separated channel types
        """
        types = []
        
        if self.include_public_channels:
            types.append("public_channel")
        
        if self.include_private_channels:
            types.append("private_channel")
        
        if self.include_dms:
            types.append("im")  # Direct messages
            types.append("mpim")  # Multi-person DMs
        
        return ",".join(types) if types else "public_channel"
    
    def _fetch_channel_messages(
        self,
        channel_id: str,
        cursor: Optional[str] = None,
        limit: int = 100
    ) -> Dict[str, Any]:
        """
        Fetch messages from channel.
        
        Args:
            channel_id: Channel ID
            cursor: Pagination cursor
            limit: Messages per page
            
        Returns:
            Dictionary with messages and pagination info
        """
        # Build request params
        params = {
            "channel": channel_id,
            "limit": min(limit, self.MAX_PAGE_SIZE)
        }
        
        # Incremental sync: only fetch new messages
        if self.config.last_sync_timestamp and not cursor:
            # Convert to Unix timestamp
            oldest = self.config.last_sync_timestamp.timestamp()
            params["oldest"] = oldest
        
        if cursor:
            params["cursor"] = cursor
        
        # Make request
        response = self._make_request(
            "GET",
            self.CONVERSATIONS_HISTORY,
            params=params,
            use_user_token=True
        )
        
        if not response.get("ok"):
            error = response.get("error", "Unknown error")
            
            # Handle specific errors
            if error == "channel_not_found":
                logger.warning(f"Channel not found: {channel_id}")
                return {"messages": [], "has_more": False}
            
            raise ConnectorExtractionError(f"Failed to fetch messages: {error}")
        
        # Extract messages
        messages = response.get("messages", [])
        
        # Pagination
        has_more = response.get("has_more", False)
        next_cursor = response.get("response_metadata", {}).get("next_cursor")
        
        return {
            "messages": messages,
            "has_more": has_more,
            "next_cursor": next_cursor
        }
    
    def _fetch_thread_replies(
        self,
        channel_id: str,
        thread_ts: str,
        channel: Dict[str, Any]
    ) -> tuple[List[RawItem], List[PermissionMetadata]]:
        """
        Fetch thread replies for a message.
        
        Args:
            channel_id: Channel ID
            thread_ts: Thread timestamp
            channel: Channel info
            
        Returns:
            (raw_items, permissions) tuple
        """
        params = {
            "channel": channel_id,
            "ts": thread_ts,
            "limit": 100
        }
        
        response = self._make_request(
            "GET",
            self.CONVERSATIONS_REPLIES,
            params=params,
            use_user_token=True
        )
        
        if not response.get("ok"):
            # Thread fetch failed, skip
            return [], []
        
        # Extract replies (skip first message which is parent)
        messages = response.get("messages", [])[1:]
        
        raw_items = []
        permissions = []
        
        for message in messages:
            raw_item = self._message_to_raw_item(message, channel, is_thread_reply=True)
            raw_items.append(raw_item)
            
            permission = self.extract_permissions(raw_item)
            permissions.append(permission)
        
        return raw_items, permissions
    
    # -------------------------
    # MESSAGE CONVERSION
    # -------------------------
    
    def _message_to_raw_item(
        self,
        message: Dict[str, Any],
        channel: Dict[str, Any],
        is_thread_reply: bool = False
    ) -> RawItem:
        """
        Convert Slack message to RawItem.
        
        Args:
            message: Slack message JSON
            channel: Channel info
            is_thread_reply: Whether this is a thread reply
            
        Returns:
            RawItem object
        """
        message_ts = message.get("ts", "")
        channel_id = channel.get("id", "")
        
        # Generate unique source ID
        source_id = f"{channel_id}_{message_ts}"
        
        # Build source URL
        workspace_url = f"https://app.slack.com/client/{self.workspace_id}"
        source_url = f"{workspace_url}/{channel_id}/p{message_ts.replace('.', '')}"
        
        # Enrich message with channel info
        enriched_message = message.copy()
        enriched_message["channel_info"] = {
            "id": channel_id,
            "name": channel.get("name"),
            "is_private": channel.get("is_private", False),
            "is_channel": channel.get("is_channel", False),
            "is_im": channel.get("is_im", False)
        }
        
        # Add thread context
        if is_thread_reply:
            enriched_message["is_thread_reply"] = True
        
        return RawItem(
            source_id=source_id,
            source_type="slack_message",
            raw_data=enriched_message,
            extracted_at=datetime.now(timezone.utc),
            extractor_version=self.version,
            source_url=source_url,
            parent_id=message.get("thread_ts") if is_thread_reply else None
        )
    
    # -------------------------
    # PERMISSION EXTRACTION
    # -------------------------
    
    def extract_permissions(self, item: RawItem) -> PermissionMetadata:
        """
        Extract permission metadata from Slack message.
        
        Slack permissions are channel-based:
        - Public channels: visible to all workspace members
        - Private channels: visible to channel members only
        - DMs: visible to participants only
        
        Args:
            item: Raw Slack message
            
        Returns:
            PermissionMetadata
        """
        raw_data = item.raw_data
        channel_info = raw_data.get("channel_info", {})
        
        channel_id = channel_info.get("id")
        is_private = channel_info.get("is_private", False)
        is_im = channel_info.get("is_im", False)
        
        # Determine visibility scope
        if is_im:
            # Direct message: private to participants
            suggested_scope = "private"
            
            # Extract participants (user who sent + recipients)
            user_ids = [raw_data.get("user", "")]
            
            # For DMs, get other participant(s)
            # This requires additional API call (conversations.members)
            if channel_id:
                members = self._get_channel_members(channel_id)
                user_ids.extend(members)
            
            user_ids = [u for u in user_ids if u]  # Remove empty
            team_ids = []
        
        elif is_private:
            # Private channel: team-level visibility (channel members)
            suggested_scope = "team"
            
            # Get channel members
            user_ids = []
            if channel_id:
                user_ids = self._get_channel_members(channel_id)
            
            team_ids = [channel_id]  # Use channel_id as team_id
        
        else:
            # Public channel: workspace-wide visibility
            suggested_scope = "public"
            user_ids = []
            team_ids = [self.workspace_id]
        
        return PermissionMetadata(
            source_id=item.source_id,
            raw_permissions={
                "channel_id": channel_id,
                "channel_name": channel_info.get("name"),
                "is_private": is_private,
                "is_im": is_im,
                "message_user": raw_data.get("user"),
                "workspace_id": self.workspace_id
            },
            suggested_scope=suggested_scope,
            suggested_user_ids=list(set(user_ids)),  # Deduplicate
            suggested_team_ids=team_ids
        )
    
    def _get_channel_members(self, channel_id: str) -> List[str]:
        """
        Get channel member user IDs.
        
        Args:
            channel_id: Channel ID
            
        Returns:
            List of user IDs
        """
        # Check cache first
        cache_key = f"members_{channel_id}"
        if cache_key in self._user_cache:
            return self._user_cache[cache_key]
        
        try:
            params = {
                "channel": channel_id,
                "limit": 200
            }
            
            response = self._make_request(
                "GET",
                self.CONVERSATIONS_MEMBERS,
                params=params,
                use_user_token=True
            )
            
            if not response.get("ok"):
                return []
            
            members = response.get("members", [])
            
            # Cache
            self._user_cache[cache_key] = members
            
            return members
        
        except Exception as e:
            logger.error(f"Failed to get channel members: {e}")
            return []
    
    # -------------------------
    # INCREMENTAL SUPPORT
    # -------------------------
    
    def supports_incremental(self) -> bool:
        """Slack supports timestamp-based incremental sync"""
        return True
    
    def get_incremental_mode(self) -> IncrementalMode:
        """Slack uses timestamp-based incremental sync"""
        return IncrementalMode.TIMESTAMP
    
    # -------------------------
    # CURSOR MANAGEMENT
    # -------------------------
    
    def _parse_cursor(self, cursor: Optional[str]) -> tuple[int, Optional[str]]:
        """
        Parse cursor into (channel_index, message_cursor).
        
        Format: "channel_idx:msg_cursor" or "channel_idx" or None
        
        Args:
            cursor: Cursor string
            
        Returns:
            (channel_index, message_cursor) tuple
        """
        if not cursor:
            return 0, None
        
        parts = cursor.split(":", 1)
        
        channel_idx = int(parts[0])
        msg_cursor = parts[1] if len(parts) > 1 else None
        
        return channel_idx, msg_cursor
    
    def _build_cursor(self, channel_idx: int, msg_cursor: Optional[str]) -> str:
        """
        Build cursor string.
        
        Args:
            channel_idx: Channel index
            msg_cursor: Message cursor
            
        Returns:
            Cursor string
        """
        if msg_cursor:
            return f"{channel_idx}:{msg_cursor}"
        else:
            return str(channel_idx)
    
    # -------------------------
    # RATE LIMITING
    # -------------------------
    
    def get_rate_limit_info(self) -> Dict[str, Any]:
        """
        Get Slack rate limit info.
        
        Slack uses Tier-based rate limiting:
        - Tier 3 (most methods): 50+ requests/minute
        - Tier 2 (posting): 20+ requests/minute
        - Tier 1 (aggressive): varies
        
        Returns:
            Rate limit info dictionary
        """
        return {
            "requests_made": self._requests_made,
            "limit_per_minute": self.RATE_LIMIT_PER_MINUTE,
            "last_request_time": self._last_request_time.isoformat() if self._last_request_time else None,
            "note": "Slack uses tier-based rate limiting (Tier 3: 50+ req/min)"
        }
    
    def _wait_for_rate_limit(self) -> None:
        """Wait if approaching rate limit"""
        now = datetime.now(timezone.utc)
        
        # Reset counter if new minute
        if (now - self._minute_start).total_seconds() >= 60:
            self._requests_made = 0
            self._minute_start = now
        
        # Check if approaching limit
        if self._requests_made >= self.RATE_LIMIT_PER_MINUTE - 5:  # Leave buffer
            elapsed = (now - self._minute_start).total_seconds()
            wait_time = 60 - elapsed
            
            if wait_time > 0:
                logger.warning(f"Rate limit approaching. Waiting {wait_time:.1f}s")
                time.sleep(wait_time)
                self._requests_made = 0
                self._minute_start = datetime.now(timezone.utc)
    
    # -------------------------
    # HTTP CLIENT
    # -------------------------
    
    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None,
        use_user_token: bool = True
    ) -> Dict[str, Any]:
        """
        Make HTTP request to Slack API.
        
        Args:
            method: HTTP method
            endpoint: API endpoint path
            params: Query parameters
            json_data: JSON body
            use_user_token: Whether to use user token (vs bot token)
            
        Returns:
            Response JSON
            
        Raises:
            ConnectorRateLimitError: If rate limited
            requests.exceptions.RequestException: If request fails
        """
        url = self.API_BASE + endpoint
        
        # Wait for rate limit
        self._wait_for_rate_limit()
        
        # Select token
        token = self.user_token if use_user_token else (self.bot_token or self.user_token)
        
        # Headers
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        
        # Make request
        response = self.session.request(
            method=method,
            url=url,
            params=params,
            json=json_data,
            headers=headers,
            timeout=self.config.timeout_seconds
        )
        
        # Track request
        self._requests_made += 1
        self._last_request_time = datetime.now(timezone.utc)
        
        # Check for rate limiting
        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", 60))
            raise ConnectorRateLimitError(
                "Slack rate limit exceeded",
                retry_after_seconds=retry_after
            )
        
        # Parse response
        try:
            data = response.json()
        except ValueError:
            raise ConnectorExtractionError(f"Invalid JSON response: {response.text}")
        
        # Check for API-level rate limiting
        if not data.get("ok") and data.get("error") == "rate_limited":
            raise ConnectorRateLimitError("Slack rate limit exceeded (API level)")
        
        return data
    
    # -------------------------
    # CLEANUP
    # -------------------------
    
    def cleanup(self) -> None:
        """Cleanup resources"""
        if self.session:
            self.session.close()
        
        # Clear caches
        self._user_cache.clear()
        self._channel_cache.clear()
        self._processed_channels.clear()
        
        logger.info("Cleanup complete")
    
    # -------------------------
    # DEDUPLICATION
    # -------------------------
    
    def reset_deduplication(self) -> None:
        """
        Reset deduplication tracking.
        
        Call this between different ingestion runs if needed.
        """
        self._processed_channels.clear()
        logger.info("Deduplication state reset")
    
    def get_processed_channels(self) -> List[str]:
        """
        Get list of processed channel IDs.
        
        Returns:
            List of channel IDs
        """
        return list(self._processed_channels)


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def create_slack_config(
    connector_id: str,
    tenant_id: str,
    user_token: str,
    workspace_id: str,
    bot_token: Optional[str] = None,
    **kwargs
) -> ConnectorConfig:
    """
    Helper to create Slack connector config.
    
    Args:
        connector_id: Unique connector ID
        tenant_id: Tenant ID
        user_token: Slack user OAuth token (xoxp-...)
        workspace_id: Slack workspace ID
        bot_token: Optional bot token (xoxb-...)
        **kwargs: Additional config parameters
        
    Returns:
        ConnectorConfig for Slack
    """
    credentials = {
        "user_token": user_token,
        "workspace_id": workspace_id
    }
    
    if bot_token:
        credentials["bot_token"] = bot_token
    
    return ConnectorConfig(
        connector_id=connector_id,
        connector_type="slack",
        tenant_id=tenant_id,
        auth_type=ConnectorAuthType.OAUTH_USER,
        credentials=credentials,
        custom_config=kwargs.get("custom_config", {}),
        **{k: v for k, v in kwargs.items() if k != "custom_config"}
    )


def format_slack_message_for_display(message: Dict[str, Any]) -> str:
    """
    Format Slack message for human-readable display.
    
    Handles Slack's mrkdwn format, user mentions, etc.
    
    Args:
        message: Slack message JSON
        
    Returns:
        Formatted text
    """
    text = message.get("text", "")
    
    # Replace user mentions (e.g., <@U123456> -> @username)
    # In production, would look up usernames
    import re
    text = re.sub(r'<@([A-Z0-9]+)>', r'@user_\1', text)
    
    # Replace channel mentions
    text = re.sub(r'<#([A-Z0-9]+)\|([^>]+)>', r'#\2', text)
    
    # Replace links
    text = re.sub(r'<(https?://[^|>]+)(\|([^>]+))?>', r'\3 (\1)' if r'\3' else r'\1', text)
    
    return text