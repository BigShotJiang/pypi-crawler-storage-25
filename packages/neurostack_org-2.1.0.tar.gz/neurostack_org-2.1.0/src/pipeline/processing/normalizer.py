"""
Data normalizer.

Converts raw connector data (RawItem) into standardized Knowledge objects.
This is the bridge between connector-specific formats and the pipeline's
universal data model.

Every connector returns different JSON structures. The normalizer's job is
to extract the essential fields and create consistent Knowledge objects.
"""

import logging
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List
from enum import Enum

from neurostack.models import (Knowledge, KnowledgeType, KnowledgeMetadata, Authority, Visibility, RawPermission, IndexedVisibility, VisibilityScope)
from ..connectors.base import RawItem, PermissionMetadata
from ..utils.validation import ValidationError
from ..utils.exceptions import NormalizationError


# ============================================================================
# LOGGING
# ============================================================================

logger = logging.getLogger("neurostack.pipeline.processing.normalizer")


# ============================================================================
# NORMALIZER CONFIGURATION
# ============================================================================

class NormalizationStrategy(Enum):
    """Strategy for handling normalization errors"""
    STRICT = "strict"        # Fail on any error
    LENIENT = "lenient"      # Use defaults for missing fields
    SKIP = "skip"            # Skip invalid items


class NormalizerConfig:
    """
    Normalizer configuration.
    
    Controls how normalization behaves.
    """
    def __init__(
        self,
        strategy: NormalizationStrategy = NormalizationStrategy.LENIENT,
        default_authority: Authority = Authority.MEDIUM,
        default_visibility: Visibility = Visibility.PUBLIC,
        max_content_length: int = 1_000_000,  # 1MB
        truncate_long_content: bool = True
    ):
        self.strategy = strategy
        self.default_authority = default_authority
        self.default_visibility = default_visibility
        self.max_content_length = max_content_length
        self.truncate_long_content = truncate_long_content


# ============================================================================
# NORMALIZER
# ============================================================================

class DataNormalizer:
    """
    Normalizes raw connector data into Knowledge objects.
    
    This is the central transformation layer that:
    1. Extracts essential fields from connector-specific JSON
    2. Maps to standardized Knowledge format
    3. Validates data quality
    4. Handles missing/invalid fields
    5. Applies defaults where appropriate
    
    Usage:
        normalizer = DataNormalizer(config)
        knowledge = normalizer.normalize(raw_item, permission_metadata, tenant_id)
    """
    
    def __init__(self, config: Optional[NormalizerConfig] = None):
        """
        Initialize normalizer.
        
        Args:
            config: Normalizer configuration (default if None)
        """
        self.config = config or NormalizerConfig()
        self._normalization_errors: List[str] = []
    
    # -------------------------
    # MAIN NORMALIZATION
    # -------------------------
    
    def normalize(
        self,
        raw_item: RawItem,
        permission_metadata: PermissionMetadata,
        tenant_id: str
    ) -> Knowledge:
        """
        Normalize raw item into Knowledge object.
        
        This is the main entry point. Delegates to connector-specific
        normalizers based on source_type.
        
        Args:
            raw_item: Raw item from connector
            permission_metadata: Permission metadata extracted by connector
            tenant_id: Tenant identifier
            
        Returns:
            Normalized Knowledge object
            
        Raises:
            NormalizationError: If normalization fails (STRICT mode)
        """
        try:
            # Determine knowledge type from source type
            knowledge_type = self._infer_knowledge_type(raw_item.source_type)
            
            # Extract content (connector-specific logic)
            content = self._extract_content(raw_item, knowledge_type)
            
            # Validate content length
            if len(content) > self.config.max_content_length:
                if self.config.truncate_long_content:
                    content = content[:self.config.max_content_length] + "... [truncated]"
                else:
                    raise NormalizationError(
                        f"Content exceeds max length: {len(content)} > {self.config.max_content_length}"
                    )
            
            # Extract metadata
            metadata = self._extract_metadata(
                raw_item,
                permission_metadata,
                tenant_id,
                knowledge_type
            )
            
            # Create Knowledge object
            knowledge = Knowledge(
                id=self._generate_content_id(raw_item, tenant_id),
                type=knowledge_type,
                content=content,
                metadata=metadata
            )
            
            return knowledge
        
        except Exception as e:
            if self.config.strategy == NormalizationStrategy.STRICT:
                raise NormalizationError(f"Normalization failed: {e}") from e
            elif self.config.strategy == NormalizationStrategy.SKIP:
                raise NormalizationError(f"Skipping invalid item: {e}") from e
            else:  # LENIENT
                # Log error and return best-effort Knowledge
                self._normalization_errors.append(f"Item {raw_item.source_id}: {e}")
                return self._create_fallback_knowledge(raw_item, tenant_id, str(e))
    
    def normalize_batch(
        self,
        raw_items: List[RawItem],
        permissions: List[PermissionMetadata],
        tenant_id: str
    ) -> List[Knowledge]:
        """
        Normalize batch of items.
        
        Args:
            raw_items: List of raw items
            permissions: List of permission metadata (same order as items)
            tenant_id: Tenant identifier
            
        Returns:
            List of normalized Knowledge objects
        """
        if len(raw_items) != len(permissions):
            raise ValueError("raw_items and permissions must have same length")
        
        normalized = []
        
        for raw_item, perm in zip(raw_items, permissions):
            try:
                knowledge = self.normalize(raw_item, perm, tenant_id)
                normalized.append(knowledge)
            except NormalizationError as e:
                if self.config.strategy != NormalizationStrategy.SKIP:
                    raise
                # Skip this item, continue with rest
                logger.warning(f"Skipped item {raw_item.source_id}: {e}")
        
        return normalized
    
    # -------------------------
    # KNOWLEDGE TYPE INFERENCE
    # -------------------------
    
    def _infer_knowledge_type(self, source_type: str) -> KnowledgeType:
        """
        Infer KnowledgeType from source_type.
        
        Maps connector-specific types to standard KnowledgeType enum.
        
        Args:
            source_type: Source type from connector (e.g., "jira_issue", "slack_message")
            
        Returns:
            KnowledgeType enum value
        """
        # Normalize source_type
        source_type_lower = source_type.lower()
        
        # Mapping rules
        if any(t in source_type_lower for t in ["issue", "ticket", "task", "story", "bug"]):
            return KnowledgeType.TASK
        
        elif any(t in source_type_lower for t in ["message", "chat", "comment"]):
            return KnowledgeType.MEETING  # Slack/Teams messages treated as meeting notes
        
        elif any(t in source_type_lower for t in ["doc", "document", "pdf", "file", "page"]):
            return KnowledgeType.DOCUMENT
        
        elif any(t in source_type_lower for t in ["meeting", "call", "summary"]):
            return KnowledgeType.MEETING
        
        elif any(t in source_type_lower for t in ["decision", "approval"]):
            return KnowledgeType.DECISION
        
        elif any(t in source_type_lower for t in ["metric", "kpi", "analytics"]):
            return KnowledgeType.METRIC
        
        elif any(t in source_type_lower for t in ["event", "notification", "alert"]):
            return KnowledgeType.EVENT
        
        elif any(t in source_type_lower for t in ["fact", "snippet"]):
            return KnowledgeType.FACT
        
        else:
            # Default to DOCUMENT
            return KnowledgeType.DOCUMENT
    
    # -------------------------
    # CONTENT EXTRACTION
    # -------------------------
    
    def _extract_content(self, raw_item: RawItem, knowledge_type: KnowledgeType) -> str:
        """
        Extract semantic content from raw item.
        
        This is connector-specific logic. Each connector returns different
        JSON structures, so we need to know where to look for content.
        
        Args:
            raw_item: Raw item
            knowledge_type: Knowledge type
            
        Returns:
            Extracted content string
        """
        raw_data = raw_item.raw_data
        source_type = raw_item.source_type.lower()
        
        # --- JIRA ---
        if "jira" in source_type:
            return self._extract_jira_content(raw_data, knowledge_type)
        
        # --- SLACK ---
        elif "slack" in source_type:
            return self._extract_slack_content(raw_data)
        
        # --- GOOGLE DOCS ---
        elif "google_doc" in source_type or "gdoc" in source_type:
            return self._extract_google_docs_content(raw_data)
        
        # --- GOOGLE CALENDAR ---
        elif "calendar" in source_type or "event" in source_type:
            return self._extract_calendar_content(raw_data)
        
        # --- CSV METRICS ---
        elif "csv" in source_type or "metric" in source_type:
            return self._extract_metric_content(raw_data)
        
        # --- GENERIC FALLBACK ---
        else:
            return self._extract_generic_content(raw_data)
    
    def _extract_jira_content(self, raw_data: Dict[str, Any], knowledge_type: KnowledgeType) -> str:
        """
        Extract content from Jira issue.
        
        Jira JSON structure:
        {
            "key": "PROJ-123",
            "fields": {
                "summary": "...",
                "description": "...",
                "comment": {
                    "comments": [...]
                }
            }
        }
        """
        fields = raw_data.get("fields", {})
        
        # Build content from multiple fields
        parts = []
        
        # Title
        summary = fields.get("summary", "")
        if summary:
            parts.append(f"Title: {summary}")
        
        # Description
        description = fields.get("description", "")
        if description:
            # Handle Atlassian Document Format (ADF)
            if isinstance(description, dict):
                description = self._parse_adf(description)
            parts.append(f"Description: {description}")
        
        # Status
        status = fields.get("status", {})
        if isinstance(status, dict):
            status_name = status.get("name", "")
            if status_name:
                parts.append(f"Status: {status_name}")
        
        # Assignee
        assignee = fields.get("assignee", {})
        if isinstance(assignee, dict):
            assignee_name = assignee.get("displayName", "")
            if assignee_name:
                parts.append(f"Assignee: {assignee_name}")
        
        # Comments (if present)
        comments = fields.get("comment", {}).get("comments", [])
        if comments:
            recent_comments = comments[-3:]  # Last 3 comments
            comment_texts = []
            for comment in recent_comments:
                body = comment.get("body", "")
                if isinstance(body, dict):
                    body = self._parse_adf(body)
                if body:
                    comment_texts.append(body)
            
            if comment_texts:
                parts.append("Recent comments:\n" + "\n".join(comment_texts))
        
        return "\n\n".join(parts)
    
    def _extract_slack_content(self, raw_data: Dict[str, Any]) -> str:
        """
        Extract content from Slack message.
        
        Slack JSON structure:
        {
            "text": "message text",
            "user": "U123",
            "ts": "1234567890.123456",
            "thread_ts": "...",
            "reactions": [...]
        }
        """
        text = raw_data.get("text", "")
        
        # Handle threaded messages
        thread_ts = raw_data.get("thread_ts")
        if thread_ts and "thread_replies" in raw_data:
            replies = raw_data.get("thread_replies", [])
            if replies:
                reply_texts = [r.get("text", "") for r in replies[:5]]  # First 5 replies
                text += "\n\nThread replies:\n" + "\n".join(reply_texts)
        
        # Handle files/attachments
        files = raw_data.get("files", [])
        if files:
            file_names = [f.get("name", "unknown") for f in files]
            text += f"\n\nAttachments: {', '.join(file_names)}"
        
        return text
    
    def _extract_google_docs_content(self, raw_data: Dict[str, Any]) -> str:
        """
        Extract content from Google Docs.
        
        Google Docs API structure:
        {
            "title": "...",
            "body": {
                "content": [...]
            }
        }
        """
        title = raw_data.get("title", "")
        
        # Extract text from body content
        body = raw_data.get("body", {})
        content_elements = body.get("content", [])
        
        text_parts = []
        for element in content_elements:
            if "paragraph" in element:
                paragraph = element["paragraph"]
                elements = paragraph.get("elements", [])
                for elem in elements:
                    text_run = elem.get("textRun", {})
                    content = text_run.get("content", "")
                    if content.strip():
                        text_parts.append(content)
        
        full_text = "".join(text_parts)
        
        if title:
            return f"Title: {title}\n\n{full_text}"
        else:
            return full_text
    
    def _extract_calendar_content(self, raw_data: Dict[str, Any]) -> str:
        """
        Extract content from calendar event.
        
        Google Calendar API structure:
        {
            "summary": "Meeting title",
            "description": "...",
            "start": {"dateTime": "..."},
            "attendees": [...]
        }
        """
        summary = raw_data.get("summary", "")
        description = raw_data.get("description", "")
        
        parts = []
        
        if summary:
            parts.append(f"Event: {summary}")
        
        if description:
            parts.append(f"Description: {description}")
        
        # Start/end times
        start = raw_data.get("start", {})
        end = raw_data.get("end", {})
        
        start_time = start.get("dateTime") or start.get("date")
        end_time = end.get("dateTime") or end.get("date")
        
        if start_time:
            parts.append(f"Start: {start_time}")
        if end_time:
            parts.append(f"End: {end_time}")
        
        # Attendees
        attendees = raw_data.get("attendees", [])
        if attendees:
            attendee_emails = [a.get("email", "") for a in attendees if a.get("email")]
            if attendee_emails:
                parts.append(f"Attendees: {', '.join(attendee_emails[:10])}")  # First 10
        
        return "\n".join(parts)
    
    def _extract_metric_content(self, raw_data: Dict[str, Any]) -> str:
        """
        Extract content from metric/CSV data.
        
        Structure:
        {
            "metric_name": "...",
            "value": 123,
            "unit": "...",
            "dimensions": {...}
        }
        """
        metric_name = raw_data.get("metric_name", "Unknown metric")
        value = raw_data.get("value", "N/A")
        unit = raw_data.get("unit", "")
        
        content = f"Metric: {metric_name}\nValue: {value}"
        
        if unit:
            content += f" {unit}"
        
        # Add dimensions if present
        dimensions = raw_data.get("dimensions", {})
        if dimensions:
            dim_str = ", ".join(f"{k}={v}" for k, v in dimensions.items())
            content += f"\nDimensions: {dim_str}"
        
        return content
    
    def _extract_generic_content(self, raw_data: Dict[str, Any]) -> str:
        """
        Generic content extraction for unknown source types.
        
        Tries common field names.
        """
        # Try common content fields
        for field in ["content", "text", "body", "description", "message", "summary"]:
            if field in raw_data:
                value = raw_data[field]
                if isinstance(value, str):
                    return value
                elif isinstance(value, dict):
                    # Try to extract text from nested structure
                    return self._extract_text_recursive(value)
        
        # Fallback: JSON dump
        import json
        return json.dumps(raw_data, indent=2)
    
    def _extract_text_recursive(self, obj: Any, max_depth: int = 3) -> str:
        """Recursively extract text from nested structures"""
        if max_depth <= 0:
            return ""
        
        if isinstance(obj, str):
            return obj
        elif isinstance(obj, dict):
            parts = []
            for value in obj.values():
                text = self._extract_text_recursive(value, max_depth - 1)
                if text:
                    parts.append(text)
            return " ".join(parts)
        elif isinstance(obj, list):
            parts = []
            for item in obj:
                text = self._extract_text_recursive(item, max_depth - 1)
                if text:
                    parts.append(text)
            return " ".join(parts)
        else:
            return str(obj)
    
    def _parse_adf(self, adf: Dict[str, Any]) -> str:
        """
        Parse Atlassian Document Format (ADF) to plain text.
        
        ADF is Jira's rich text format. We convert to plain text.
        """
        if not isinstance(adf, dict):
            return str(adf)
        
        if "content" in adf:
            parts = []
            for node in adf["content"]:
                text = self._parse_adf_node(node)
                if text:
                    parts.append(text)
            return "\n".join(parts)
        
        return ""
    
    def _parse_adf_node(self, node: Dict[str, Any]) -> str:
        """Parse single ADF node"""
        node_type = node.get("type", "")
        
        if node_type == "text":
            return node.get("text", "")
        
        elif node_type == "paragraph":
            content = node.get("content", [])
            texts = [self._parse_adf_node(n) for n in content]
            return " ".join(t for t in texts if t)
        
        elif "content" in node:
            content = node["content"]
            texts = [self._parse_adf_node(n) for n in content]
            return " ".join(t for t in texts if t)
        
        return ""
    
    # -------------------------
    # METADATA EXTRACTION
    # -------------------------
    
    def _extract_metadata(
        self,
        raw_item: RawItem,
        permission_metadata: PermissionMetadata,
        tenant_id: str,
        knowledge_type: KnowledgeType
    ) -> KnowledgeMetadata:
        """
        Extract metadata from raw item.
        
        Args:
            raw_item: Raw item
            permission_metadata: Permission metadata
            tenant_id: Tenant identifier
            knowledge_type: Knowledge type
            
        Returns:
            KnowledgeMetadata object
        """
        raw_data = raw_item.raw_data
        
        # Extract timestamp
        timestamp = self._extract_timestamp(raw_data, raw_item.extracted_at)
        
        # Extract source description
        source = self._extract_source_description(raw_item, raw_data)
        
        # Determine authority
        authority = self._determine_authority(raw_item, knowledge_type, raw_data)
        
        # Determine visibility
        visibility = self._determine_visibility(permission_metadata)
        
        # Extract owner
        owner = self._extract_owner(raw_data)
        
        # Extract team ID
        team_id = self._extract_team_id(raw_data, permission_metadata)
        
        return KnowledgeMetadata(
            timestamp=timestamp,
            source=source,
            tenant_id=tenant_id,
            authority=authority,
            visibility=visibility,
            owner=owner,
            team_id=team_id
        )
    
    def _extract_timestamp(self, raw_data: Dict[str, Any], fallback: datetime) -> datetime:
        """Extract timestamp from raw data"""
        # Try common timestamp fields
        for field in ["created", "createdAt", "created_at", "timestamp", "ts", "date", "updated", "updatedAt"]:
            if field in raw_data:
                value = raw_data[field]
                
                # Handle different formats
                if isinstance(value, str):
                    try:
                        # ISO 8601
                        return datetime.fromisoformat(value.replace('Z', '+00:00'))
                    except:
                        pass
                
                elif isinstance(value, (int, float)):
                    try:
                        # Unix timestamp
                        return datetime.fromtimestamp(value, tz=timezone.utc)
                    except:
                        pass
        
        # Fallback to extraction time
        return fallback
    
    def _extract_source_description(self, raw_item: RawItem, raw_data: Dict[str, Any]) -> str:
        """Extract human-readable source description"""
        source_type = raw_item.source_type
        
        # Try to include key identifier
        if "jira" in source_type.lower():
            key = raw_data.get("key", "")
            return f"Jira {key}" if key else "Jira"
        
        elif "slack" in source_type.lower():
            channel = raw_data.get("channel", "")
            return f"Slack #{channel}" if channel else "Slack"
        
        elif "google" in source_type.lower():
            title = raw_data.get("title", "")
            return f"Google Docs: {title}" if title else "Google Docs"
        
        else:
            return source_type.replace("_", " ").title()
    
    def _determine_authority(
        self,
        raw_item: RawItem,
        knowledge_type: KnowledgeType,
        raw_data: Dict[str, Any]
    ) -> Authority:
        """
        Determine authority level of knowledge.
        
        Rules:
        - Decisions, documents = HIGH
        - Tasks, meetings = MEDIUM
        - Messages, events = LOW
        """
        # Document type heuristics
        if knowledge_type == KnowledgeType.DECISION:
            return Authority.HIGH
        
        elif knowledge_type == KnowledgeType.DOCUMENT:
            # Check if official document
            source = raw_item.source_type.lower()
            if any(marker in source for marker in ["policy", "sop", "manual", "guide"]):
                return Authority.HIGH
            else:
                return Authority.MEDIUM
        
        elif knowledge_type in [KnowledgeType.TASK, KnowledgeType.MEETING]:
            return Authority.MEDIUM
        
        elif knowledge_type in [KnowledgeType.METRIC]:
            return Authority.MEDIUM
        
        else:
            return Authority.LOW
    
    def _determine_visibility(self, permission_metadata: PermissionMetadata) -> Visibility:
        """Determine visibility from permission metadata"""
        suggested_scope = permission_metadata.suggested_scope
        
        if suggested_scope:
            if suggested_scope == "public":
                return Visibility.PUBLIC
            elif suggested_scope == "team":
                return Visibility.TEAM
            elif suggested_scope == "private":
                return Visibility.PRIVATE
        
        # Fallback based on user/team lists
        if permission_metadata.suggested_user_ids and not permission_metadata.suggested_team_ids:
            # Only specific users
            return Visibility.PRIVATE
        elif permission_metadata.suggested_team_ids:
            return Visibility.TEAM
        else:
            return Visibility.PUBLIC
    
    def _extract_owner(self, raw_data: Dict[str, Any]) -> Optional[str]:
        """Extract owner/creator"""
        # Try common owner fields
        for field in ["owner", "creator", "author", "user", "assignee"]:
            if field in raw_data:
                value = raw_data[field]
                
                if isinstance(value, str):
                    return value
                elif isinstance(value, dict):
                    # Extract from nested object
                    return value.get("email") or value.get("id") or value.get("name")
        
        return None
    
    def _extract_team_id(
        self,
        raw_data: Dict[str, Any],
        permission_metadata: PermissionMetadata
    ) -> Optional[str]:
        """Extract team ID"""
        # First check permission metadata
        if permission_metadata.suggested_team_ids:
            return permission_metadata.suggested_team_ids[0]  # Use first team
        
        # Try common team fields
        for field in ["team", "team_id", "project", "project_id"]:
            if field in raw_data:
                value = raw_data[field]
                if isinstance(value, str):
                    return value
                elif isinstance(value, dict):
                    return value.get("id") or value.get("key")
        
        return None
    
    # -------------------------
    # CONTENT ID GENERATION
    # -------------------------
    
    def _generate_content_id(self, raw_item: RawItem, tenant_id: str) -> str:
        """
        Generate unique content ID.
        
        Format: {tenant_id}_{source_type}_{source_id}
        
        Args:
            raw_item: Raw item
            tenant_id: Tenant identifier
            
        Returns:
            Unique content ID
        """
        source_type = raw_item.source_type.replace(" ", "_").lower()
        source_id = raw_item.source_id.replace(" ", "_")
        
        return f"{tenant_id}_{source_type}_{source_id}"
    
    # -------------------------
    # FALLBACK HANDLING
    # -------------------------
    
    def _create_fallback_knowledge(
        self,
        raw_item: RawItem,
        tenant_id: str,
        error_message: str
    ) -> Knowledge:
        """
        Create fallback Knowledge when normalization fails.
        
        Used in LENIENT mode.
        """
        import json
        
        # Create minimal valid Knowledge
        content = f"[Normalization failed: {error_message}]\n\nRaw data:\n{json.dumps(raw_item.raw_data, indent=2)}"
        
        metadata = KnowledgeMetadata(
            timestamp=raw_item.extracted_at,
            source=raw_item.source_type,
            tenant_id=tenant_id,
            authority=self.config.default_authority,
            visibility=self.config.default_visibility
        )
        
        return Knowledge(
            id=self._generate_content_id(raw_item, tenant_id),
            type=KnowledgeType.DOCUMENT,
            content=content,
            metadata=metadata
        )
    
    # -------------------------
    # ERROR TRACKING
    # -------------------------
    
    def get_errors(self) -> List[str]:
        """Get normalization errors (LENIENT mode)"""
        return self._normalization_errors.copy()
    
    def clear_errors(self) -> None:
        """Clear error log"""
        self._normalization_errors.clear()