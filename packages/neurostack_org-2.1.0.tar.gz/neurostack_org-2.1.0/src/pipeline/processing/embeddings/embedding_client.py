"""
Embedding client abstraction.

Provides a unified interface for generating embeddings from different providers.
Supports both synchronous and async embedding generation with batching,
caching, and error handling.

Supported providers:
- OpenAI (text-embedding-3-small, text-embedding-3-large, ada-002)
- Mock/Local (for testing)
- Future: Cohere, Anthropic, HuggingFace, etc.

Design principles:
- Provider-agnostic interface
- Automatic batching for efficiency
- Token counting and validation
- Caching for duplicate content
- Rate limiting integration
- Retry logic for transient failures
"""

import hashlib
import logging
import time
from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta, timezone

from ...utils.retry import retry, RetryStrategy, STANDARD_RETRY
from ...utils.exceptions import (
    PipelineError,
    EmbeddingError,
    RateLimitExceededError
)

logger = logging.getLogger("neurostack.pipeline.processing.embeddings")


# ============================================================================
# EMBEDDING ENUMS
# ============================================================================

class EmbeddingProvider(Enum):
    """Embedding provider"""
    OPENAI = "openai"
    MOCK = "mock"
    COHERE = "cohere"          # Future
    ANTHROPIC = "anthropic"    # Future
    HUGGINGFACE = "huggingface"  # Future


class EmbeddingModel(Enum):
    """Embedding model specifications"""
    # OpenAI models
    OPENAI_SMALL = "text-embedding-3-small"      # 1536 dims, cheap
    OPENAI_LARGE = "text-embedding-3-large"      # 3072 dims, expensive
    OPENAI_ADA_002 = "text-embedding-ada-002"    # 1536 dims, legacy
    
    # Mock
    MOCK = "mock"
    
    def get_dimensions(self) -> int:
        """Get embedding dimensions for model"""
        dimensions = {
            self.OPENAI_SMALL: 1536,
            self.OPENAI_LARGE: 3072,
            self.OPENAI_ADA_002: 1536,
            self.MOCK: 384  # Smaller for testing
        }
        return dimensions.get(self, 1536)
    
    def get_max_tokens(self) -> int:
        """Get maximum token limit for model"""
        max_tokens = {
            self.OPENAI_SMALL: 8191,
            self.OPENAI_LARGE: 8191,
            self.OPENAI_ADA_002: 8191,
            self.MOCK: 512
        }
        return max_tokens.get(self, 8191)
    
    def get_cost_per_1k_tokens(self) -> float:
        """Get cost per 1k tokens (USD)"""
        costs = {
            self.OPENAI_SMALL: 0.00002,   # $0.02 per 1M tokens
            self.OPENAI_LARGE: 0.00013,   # $0.13 per 1M tokens
            self.OPENAI_ADA_002: 0.0001,  # $0.10 per 1M tokens
            self.MOCK: 0.0
        }
        return costs.get(self, 0.0)


# ============================================================================
# EMBEDDING CONFIGURATION
# ============================================================================

@dataclass
class EmbeddingConfig:
    """
    Embedding client configuration.
    """
    # Provider & model
    provider: EmbeddingProvider
    model: EmbeddingModel
    
    # API credentials
    api_key: Optional[str] = None
    api_base: Optional[str] = None  # Custom endpoint
    
    # Batching
    batch_size: int = 100              # Embeddings per batch
    max_concurrent_batches: int = 5    # Parallel batch requests
    
    # Performance
    enable_caching: bool = True        # Cache embeddings by content hash
    cache_ttl_hours: int = 24          # Cache expiry
    
    # Retry & rate limiting
    retry_strategy: RetryStrategy = field(default_factory=lambda: STANDARD_RETRY)
    rate_limit_per_minute: int = 3000  # Tokens per minute
    
    # Validation
    validate_dimensions: bool = True   # Verify embedding dimensions
    truncate_long_texts: bool = True   # Auto-truncate if too long
    
    # Metadata
    include_model_version: bool = True  # Track which model version generated embedding
    
    def __post_init__(self):
        """Validate configuration"""
        if self.provider == EmbeddingProvider.OPENAI and not self.api_key:
            raise ValueError("OpenAI provider requires api_key")
        
        if self.batch_size < 1:
            raise ValueError("batch_size must be >= 1")


# ============================================================================
# EMBEDDING RESULT
# ============================================================================

@dataclass
class EmbeddingResult:
    """
    Result from embedding generation.
    """
    text: str                          # Original text
    vector: List[float]                # Embedding vector
    
    # Metadata
    model: str                         # Model used
    dimensions: int                    # Vector dimensions
    tokens_used: int = 0               # Tokens consumed
    
    # Timing
    generated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    generation_time_ms: float = 0.0
    
    # Caching
    from_cache: bool = False
    cache_key: Optional[str] = None
    
    def __post_init__(self):
        """Validate result"""
        if len(self.vector) != self.dimensions:
            raise ValueError(
                f"Vector length {len(self.vector)} doesn't match "
                f"expected dimensions {self.dimensions}"
            )


@dataclass
class BatchEmbeddingResult:
    """
    Result from batch embedding generation.
    """
    embeddings: List[EmbeddingResult]
    
    # Aggregate stats
    total_texts: int
    total_tokens: int
    total_cost: float = 0.0
    
    # Timing
    batch_time_ms: float = 0.0
    cache_hits: int = 0
    
    # Errors
    errors: List[str] = field(default_factory=list)


# ============================================================================
# ABSTRACT EMBEDDING CLIENT
# ============================================================================

class EmbeddingClient(ABC):
    """
    Abstract base class for embedding clients.
    
    All embedding providers must implement this interface.
    
    Usage:
        client = OpenAIEmbeddingClient(config)
        
        # Single embedding
        result = client.embed("Hello world")
        
        # Batch embeddings
        batch_result = client.embed_batch(["text1", "text2", "text3"])
    """
    
    def __init__(self, config: EmbeddingConfig):
        """
        Initialize embedding client.
        
        Args:
            config: Embedding configuration
        """
        self.config = config
        
        # Embedding cache: content_hash -> (vector, timestamp)
        self._cache: Dict[str, Tuple[List[float], datetime]] = {}
        
        # Rate limiting
        self._tokens_used_this_minute = 0
        self._minute_start = datetime.now(timezone.utc)
        
        # Stats
        self.total_embeddings_generated = 0
        self.total_tokens_used = 0
        self.total_cost = 0.0
        self.cache_hits = 0
        self.cache_misses = 0
    
    # -------------------------
    # ABSTRACT METHODS (must implement)
    # -------------------------
    
    @abstractmethod
    def _generate_embedding(self, text: str) -> List[float]:
        """
        Generate embedding for single text (provider-specific).
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector
            
        Raises:
            EmbeddingError: If generation fails
        """
        pass
    
    @abstractmethod
    def _generate_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for batch of texts (provider-specific).
        
        Most providers have optimized batch endpoints.
        
        Args:
            texts: List of texts to embed
            
        Returns:
            List of embedding vectors (same order as input)
            
        Raises:
            EmbeddingError: If generation fails
        """
        pass
    
    @abstractmethod
    def count_tokens(self, text: str) -> int:
        """
        Count tokens in text (provider-specific tokenization).
        
        Args:
            text: Text to tokenize
            
        Returns:
            Token count
        """
        pass
    
    # -------------------------
    # PUBLIC API
    # -------------------------
    
    def embed(
        self,
        text: str,
        use_cache: bool = True
    ) -> EmbeddingResult:
        """
        Generate embedding for single text.
        
        Args:
            text: Text to embed
            use_cache: Whether to use cache
            
        Returns:
            EmbeddingResult
            
        Raises:
            EmbeddingError: If generation fails
        """
        start_time = time.time()
        
        # Validate and preprocess
        text = self._preprocess_text(text)
        
        # Check token limit
        token_count = self.count_tokens(text)
        max_tokens = self.config.model.get_max_tokens()
        
        if token_count > max_tokens:
            if self.config.truncate_long_texts:
                text = self._truncate_text(text, max_tokens)
                token_count = self.count_tokens(text)
            else:
                raise EmbeddingError(
                    f"Text exceeds token limit: {token_count} > {max_tokens}"
                )
        
        # Check cache
        cache_key = None
        from_cache = False
        
        if use_cache and self.config.enable_caching:
            cache_key = self._compute_cache_key(text)
            cached_vector = self._get_from_cache(cache_key)
            
            if cached_vector is not None:
                from_cache = True
                vector = cached_vector
                self.cache_hits += 1
            else:
                self.cache_misses += 1
                vector = self._generate_with_rate_limit(text)
                self._store_in_cache(cache_key, vector)
        else:
            vector = self._generate_with_rate_limit(text)
        
        # Update stats
        if not from_cache:
            self.total_embeddings_generated += 1
            self.total_tokens_used += token_count
            self.total_cost += self._calculate_cost(token_count)
        
        # Build result
        generation_time_ms = (time.time() - start_time) * 1000
        
        return EmbeddingResult(
            text=text,
            vector=vector,
            model=self.config.model.value,
            dimensions=self.config.model.get_dimensions(),
            tokens_used=token_count,
            generation_time_ms=generation_time_ms,
            from_cache=from_cache,
            cache_key=cache_key
        )
    
    def embed_batch(
        self,
        texts: List[str],
        use_cache: bool = True,
        show_progress: bool = False
    ) -> BatchEmbeddingResult:
        """
        Generate embeddings for batch of texts.
        
        Automatically handles:
        - Caching
        - Batching (splits into smaller batches if needed)
        - Rate limiting
        - Error handling
        
        Args:
            texts: List of texts to embed
            use_cache: Whether to use cache
            show_progress: Whether to print progress
            
        Returns:
            BatchEmbeddingResult
        """
        start_time = time.time()
        
        if not texts:
            return BatchEmbeddingResult(
                embeddings=[],
                total_texts=0,
                total_tokens=0,
                batch_time_ms=0
            )
        
        embeddings = []
        total_tokens = 0
        total_cost = 0.0
        cache_hits = 0
        errors = []
        
        # Process in batches
        batch_size = self.config.batch_size
        num_batches = (len(texts) + batch_size - 1) // batch_size
        
        for batch_idx in range(num_batches):
            start_idx = batch_idx * batch_size
            end_idx = min(start_idx + batch_size, len(texts))
            batch_texts = texts[start_idx:end_idx]
            
            if show_progress:
                logger.info(f"Processing batch {batch_idx + 1}/{num_batches} "
                            f"({len(batch_texts)} texts)")
            
            try:
                # Separate cached and uncached
                cached_results = []
                uncached_texts = []
                uncached_indices = []
                
                for i, text in enumerate(batch_texts):
                    text = self._preprocess_text(text)
                    
                    # Token validation
                    token_count = self.count_tokens(text)
                    max_tokens = self.config.model.get_max_tokens()
                    
                    if token_count > max_tokens:
                        if self.config.truncate_long_texts:
                            text = self._truncate_text(text, max_tokens)
                        else:
                            errors.append(f"Text {start_idx + i} exceeds token limit")
                            continue
                    
                    # Check cache
                    if use_cache and self.config.enable_caching:
                        cache_key = self._compute_cache_key(text)
                        cached_vector = self._get_from_cache(cache_key)
                        
                        if cached_vector is not None:
                            cached_results.append((i, text, cached_vector, True))
                            cache_hits += 1
                            continue
                    
                    uncached_texts.append(text)
                    uncached_indices.append(i)
                
                # Generate embeddings for uncached texts
                if uncached_texts:
                    vectors = self._generate_batch_with_rate_limit(uncached_texts)
                    
                    # Cache new embeddings
                    if self.config.enable_caching:
                        for text, vector in zip(uncached_texts, vectors):
                            cache_key = self._compute_cache_key(text)
                            self._store_in_cache(cache_key, vector)
                    
                    # Combine with cached results
                    for idx, text, vector in zip(uncached_indices, uncached_texts, vectors):
                        cached_results.append((idx, text, vector, False))
                
                # Sort by original index
                cached_results.sort(key=lambda x: x[0])
                
                # Build results
                for _, text, vector, from_cache in cached_results:
                    token_count = self.count_tokens(text)
                    
                    result = EmbeddingResult(
                        text=text,
                        vector=vector,
                        model=self.config.model.value,
                        dimensions=self.config.model.get_dimensions(),
                        tokens_used=token_count,
                        from_cache=from_cache
                    )
                    
                    embeddings.append(result)
                    total_tokens += token_count
                    
                    if not from_cache:
                        total_cost += self._calculate_cost(token_count)
            
            except Exception as e:
                error_msg = f"Batch {batch_idx + 1} failed: {e}"
                errors.append(error_msg)
                logger.error(error_msg)
        
        # Update stats
        self.total_embeddings_generated += len(embeddings)
        self.total_tokens_used += total_tokens
        self.total_cost += total_cost
        
        batch_time_ms = (time.time() - start_time) * 1000
        
        return BatchEmbeddingResult(
            embeddings=embeddings,
            total_texts=len(texts),
            total_tokens=total_tokens,
            total_cost=total_cost,
            batch_time_ms=batch_time_ms,
            cache_hits=cache_hits,
            errors=errors
        )
    
    # -------------------------
    # RATE LIMITING
    # -------------------------
    
    def _generate_with_rate_limit(self, text: str) -> List[float]:
        """Generate embedding with rate limiting"""
        token_count = self.count_tokens(text)
        self._wait_for_rate_limit(token_count)
        
        vector = self._generate_embedding(text)
        
        if self.config.validate_dimensions:
            self._validate_dimensions(vector)
        
        return vector
    
    def _generate_batch_with_rate_limit(self, texts: List[str]) -> List[List[float]]:
        """Generate batch embeddings with rate limiting"""
        total_tokens = sum(self.count_tokens(t) for t in texts)
        self._wait_for_rate_limit(total_tokens)
        
        vectors = self._generate_embeddings_batch(texts)
        
        if self.config.validate_dimensions:
            for vector in vectors:
                self._validate_dimensions(vector)
        
        return vectors
    
    def _wait_for_rate_limit(self, tokens_needed: int) -> None:
        """
        Wait if rate limit would be exceeded.
        
        Args:
            tokens_needed: Tokens about to be used
            
        Raises:
            RateLimitExceededError: If rate limit exceeded
        """
        # Reset counter if new minute
        now = datetime.now(timezone.utc)
        if (now - self._minute_start).total_seconds() >= 60:
            self._tokens_used_this_minute = 0
            self._minute_start = now
        
        # Check if would exceed limit
        if self._tokens_used_this_minute + tokens_needed > self.config.rate_limit_per_minute:
            # Wait until next minute
            elapsed = (now - self._minute_start).total_seconds()
            wait_time = 60 - elapsed
            
            if wait_time > 0:
                logger.warning(f"Rate limit reached. Waiting {wait_time:.1f}s")
                time.sleep(wait_time)
                
                # Reset counter
                self._tokens_used_this_minute = 0
                self._minute_start = datetime.now(timezone.utc)
        
        # Update counter
        self._tokens_used_this_minute += tokens_needed
    
    # -------------------------
    # CACHING
    # -------------------------
    
    def _compute_cache_key(self, text: str) -> str:
        """Compute cache key from text"""
        # Use MD5 hash of text + model name
        content = f"{text}|{self.config.model.value}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def _get_from_cache(self, cache_key: str) -> Optional[List[float]]:
        """Get embedding from cache"""
        if cache_key not in self._cache:
            return None
        
        vector, timestamp = self._cache[cache_key]
        
        # Check TTL
        if self.config.cache_ttl_hours > 0:
            age_hours = (datetime.now(timezone.utc) - timestamp).total_seconds() / 3600
            if age_hours > self.config.cache_ttl_hours:
                del self._cache[cache_key]
                return None
        
        return vector
    
    def _store_in_cache(self, cache_key: str, vector: List[float]) -> None:
        """Store embedding in cache"""
        self._cache[cache_key] = (vector, datetime.now(timezone.utc))
    
    def clear_cache(self) -> None:
        """Clear embedding cache"""
        self._cache.clear()
        logger.info("Cache cleared")
    
    # -------------------------
    # VALIDATION & PREPROCESSING
    # -------------------------
    
    def _preprocess_text(self, text: str) -> str:
        """Preprocess text before embedding"""
        # Strip whitespace
        text = text.strip()
        
        # Remove excessive whitespace
        text = " ".join(text.split())
        
        # Validate
        if not text:
            raise EmbeddingError("Empty text cannot be embedded")
        
        return text
    
    def _truncate_text(self, text: str, max_tokens: int) -> str:
        """
        Truncate text to fit token limit.
        
        Simple character-based truncation (approximate).
        Production would use actual tokenizer.
        """
        # Rough estimate: 4 chars per token
        max_chars = max_tokens * 4
        
        if len(text) <= max_chars:
            return text
        
        return text[:max_chars]
    
    def _validate_dimensions(self, vector: List[float]) -> None:
        """Validate embedding dimensions"""
        expected_dims = self.config.model.get_dimensions()
        
        if len(vector) != expected_dims:
            raise EmbeddingError(
                f"Invalid embedding dimensions: expected {expected_dims}, got {len(vector)}"
            )
    
    # -------------------------
    # COST CALCULATION
    # -------------------------
    
    def _calculate_cost(self, token_count: int) -> float:
        """Calculate cost for token usage"""
        cost_per_1k = self.config.model.get_cost_per_1k_tokens()
        return (token_count / 1000) * cost_per_1k
    
    # -------------------------
    # STATS
    # -------------------------
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get client statistics.
        
        Returns:
            Dictionary with stats
        """
        cache_hit_rate = (
            self.cache_hits / (self.cache_hits + self.cache_misses)
            if (self.cache_hits + self.cache_misses) > 0
            else 0
        )
        
        return {
            "total_embeddings_generated": self.total_embeddings_generated,
            "total_tokens_used": self.total_tokens_used,
            "total_cost_usd": round(self.total_cost, 4),
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "cache_hit_rate": round(cache_hit_rate, 3),
            "cache_size": len(self._cache),
            "model": self.config.model.value,
            "dimensions": self.config.model.get_dimensions()
        }
    
    def reset_stats(self) -> None:
        """Reset statistics"""
        self.total_embeddings_generated = 0
        self.total_tokens_used = 0
        self.total_cost = 0.0
        self.cache_hits = 0
        self.cache_misses = 0


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def create_embedding_client(
    provider: str = "openai",
    model: str = "text-embedding-3-small",
    api_key: Optional[str] = None,
    **kwargs
) -> EmbeddingClient:
    """
    Factory function to create embedding client.
    
    Args:
        provider: Provider name ("openai", "mock")
        model: Model name
        api_key: API key (if required)
        **kwargs: Additional config parameters
        
    Returns:
        EmbeddingClient instance
        
    Raises:
        ValueError: If provider not supported
    """
    provider_enum = EmbeddingProvider(provider.lower())
    model_enum = EmbeddingModel(model)
    
    config = EmbeddingConfig(
        provider=provider_enum,
        model=model_enum,
        api_key=api_key,
        **kwargs
    )
    
    if provider_enum == EmbeddingProvider.OPENAI:
        from .openai_embeddings import OpenAIEmbeddingClient
        return OpenAIEmbeddingClient(config)
    
    elif provider_enum == EmbeddingProvider.MOCK:
        from .mock_embeddings import MockEmbeddingClient
        return MockEmbeddingClient(config)
    
    else:
        raise ValueError(f"Unsupported provider: {provider}")


def estimate_embedding_cost(
    texts: List[str],
    model: str = "text-embedding-3-small",
    chars_per_token: float = 4.0
) -> Dict[str, Any]:
    """
    Estimate cost for embedding batch of texts.
    
    Args:
        texts: List of texts to embed
        model: Model name
        chars_per_token: Characters per token ratio
        
    Returns:
        Dictionary with cost estimate
    """
    model_enum = EmbeddingModel(model)
    
    # Estimate tokens
    total_chars = sum(len(t) for t in texts)
    estimated_tokens = int(total_chars / chars_per_token)
    
    # Calculate cost
    cost_per_1k = model_enum.get_cost_per_1k_tokens()
    estimated_cost = (estimated_tokens / 1000) * cost_per_1k
    
    return {
        "num_texts": len(texts),
        "total_chars": total_chars,
        "estimated_tokens": estimated_tokens,
        "estimated_cost_usd": round(estimated_cost, 4),
        "model": model,
        "dimensions": model_enum.get_dimensions()
    }