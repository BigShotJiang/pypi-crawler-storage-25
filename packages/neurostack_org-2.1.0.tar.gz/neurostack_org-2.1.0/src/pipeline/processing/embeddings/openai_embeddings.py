"""
OpenAI embedding client implementation.

Implements the EmbeddingClient interface using OpenAI's embedding API.
Supports all OpenAI embedding models with proper tokenization, batching,
and error handling.

Supported models:
- text-embedding-3-small (1536 dims, $0.02/1M tokens)
- text-embedding-3-large (3072 dims, $0.13/1M tokens)
- text-embedding-ada-002 (1536 dims, legacy)

Features:
- Native batch API support (up to 2048 texts per request)
- tiktoken for accurate token counting
- Automatic retry on rate limits
- Dimension reduction support (for 3-large model)
- User/organization metadata tracking

API documentation: https://platform.openai.com/docs/api-reference/embeddings
"""

import time
import logging
from typing import List, Optional, Dict, Any
import requests

from .embedding_client import (
    EmbeddingClient,
    EmbeddingConfig,
    EmbeddingProvider,
    EmbeddingModel
)
from ...utils.retry import retry, AGGRESSIVE_RETRY
from ...utils.exceptions import (
    EmbeddingError,
    RateLimitExceededError,
    AuthenticationError
)


# ============================================================================
# LOGGING
# ============================================================================

logger = logging.getLogger("neurostack.pipeline.processing.embeddings.openai")


# ============================================================================
# OPENAI EMBEDDING CLIENT
# ============================================================================

class OpenAIEmbeddingClient(EmbeddingClient):
    """
    OpenAI embedding client implementation.
    
    Uses OpenAI's embeddings API endpoint with proper authentication,
    batching, and error handling.
    
    Usage:
        config = EmbeddingConfig(
            provider=EmbeddingProvider.OPENAI,
            model=EmbeddingModel.OPENAI_SMALL,
            api_key="sk-..."
        )
        
        client = OpenAIEmbeddingClient(config)
        
        # Single embedding
        result = client.embed("Hello world")
        
        # Batch (efficient)
        results = client.embed_batch([
            "Text 1",
            "Text 2",
            "Text 3"
        ])
    """
    
    # OpenAI API settings
    API_BASE = "https://api.openai.com/v1"
    EMBEDDINGS_ENDPOINT = "/embeddings"
    
    # Batch limits (from OpenAI docs)
    MAX_BATCH_SIZE = 2048  # Maximum texts per request
    MAX_TOKENS_PER_REQUEST = 8191  # Per text
    
    def __init__(self, config: EmbeddingConfig):
        """
        Initialize OpenAI embedding client.
        
        Args:
            config: Embedding configuration
            
        Raises:
            ValueError: If configuration invalid
            ImportError: If tiktoken not installed
        """
        # Validate config
        if config.provider != EmbeddingProvider.OPENAI:
            raise ValueError(f"Expected OpenAI provider, got {config.provider}")
        
        if not config.api_key:
            raise ValueError("OpenAI API key required")
        
        super().__init__(config)
        
        # API settings
        self.api_key = config.api_key
        self.api_base = config.api_base or self.API_BASE
        
        # Initialize tokenizer
        try:
            import tiktoken
            self.tokenizer = self._get_tokenizer()
        except ImportError:
            raise ImportError(
                "tiktoken required for OpenAI embeddings. "
                "Install with: pip install tiktoken"
            )
        
        # HTTP session for connection pooling
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        })
        
        logger.info(f"Initialized with model: {config.model.value}")
    
    # -------------------------
    # ABSTRACT METHOD IMPLEMENTATIONS
    # -------------------------
    
    @retry(strategy=AGGRESSIVE_RETRY)
    def _generate_embedding(self, text: str) -> List[float]:
        """
        Generate embedding for single text.
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector
            
        Raises:
            EmbeddingError: If API call fails
        """
        # Call batch endpoint with single text (more efficient)
        vectors = self._generate_embeddings_batch([text])
        return vectors[0]
    
    @retry(strategy=AGGRESSIVE_RETRY)
    def _generate_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for batch of texts using OpenAI API.
        
        OpenAI supports up to 2048 texts per request, so we split
        larger batches automatically.
        
        Args:
            texts: List of texts to embed
            
        Returns:
            List of embedding vectors (same order as input)
            
        Raises:
            EmbeddingError: If API call fails
        """
        if not texts:
            return []
        
        # If batch too large, split and recurse
        if len(texts) > self.MAX_BATCH_SIZE:
            return self._generate_large_batch(texts)
        
        # Build request payload
        payload = {
            "input": texts,
            "model": self.config.model.value
        }
        
        # Add dimension reduction if using 3-large model
        if self.config.model == EmbeddingModel.OPENAI_LARGE:
            # Can reduce to 1536 dims for compatibility
            # payload["dimensions"] = 1536  # Uncomment to enable
            pass
        
        # Make API request
        try:
            response = self.session.post(
                f"{self.api_base}{self.EMBEDDINGS_ENDPOINT}",
                json=payload,
                timeout=60
            )
            
            # Handle errors
            if response.status_code == 401:
                raise AuthenticationError("Invalid OpenAI API key")
            
            elif response.status_code == 429:
                # Rate limit hit
                retry_after = int(response.headers.get("Retry-After", 60))
                raise RateLimitExceededError(
                    "OpenAI rate limit exceeded",
                    retry_after_seconds=retry_after
                )
            
            elif response.status_code != 200:
                error_msg = response.json().get("error", {}).get("message", "Unknown error")
                raise EmbeddingError(f"OpenAI API error: {error_msg}")
            
            # Parse response
            data = response.json()
            
            # Extract embeddings (sorted by index)
            embeddings_data = sorted(data["data"], key=lambda x: x["index"])
            vectors = [item["embedding"] for item in embeddings_data]
            
            # Verify count matches
            if len(vectors) != len(texts):
                raise EmbeddingError(
                    f"Response count mismatch: expected {len(texts)}, got {len(vectors)}"
                )
            
            return vectors
        
        except requests.exceptions.RequestException as e:
            raise EmbeddingError(f"OpenAI API request failed: {e}") from e
    
    def count_tokens(self, text: str) -> int:
        """
        Count tokens using tiktoken (accurate).
        
        Args:
            text: Text to tokenize
            
        Returns:
            Token count
        """
        tokens = self.tokenizer.encode(text)
        return len(tokens)
    
    # -------------------------
    # OPENAI-SPECIFIC METHODS
    # -------------------------
    
    def _generate_large_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for large batch (>2048 texts).
        
        Splits into smaller batches and combines results.
        
        Args:
            texts: List of texts (potentially >2048)
            
        Returns:
            List of embedding vectors
        """
        all_vectors = []
        
        num_batches = (len(texts) + self.MAX_BATCH_SIZE - 1) // self.MAX_BATCH_SIZE
        
        for i in range(num_batches):
            start_idx = i * self.MAX_BATCH_SIZE
            end_idx = min(start_idx + self.MAX_BATCH_SIZE, len(texts))
            batch = texts[start_idx:end_idx]
            
            logger.info(f"Processing sub-batch {i + 1}/{num_batches} ({len(batch)} texts)")
            
            vectors = self._generate_embeddings_batch(batch)
            all_vectors.extend(vectors)
            
            # Small delay between batches to avoid rate limits
            if i < num_batches - 1:
                time.sleep(0.5)
        
        return all_vectors
    
    def _get_tokenizer(self):
        """
        Get appropriate tokenizer for model.
        
        Returns:
            tiktoken encoding
        """
        import tiktoken
        
        # Model-specific encodings
        encoding_map = {
            EmbeddingModel.OPENAI_SMALL: "cl100k_base",
            EmbeddingModel.OPENAI_LARGE: "cl100k_base",
            EmbeddingModel.OPENAI_ADA_002: "cl100k_base"
        }
        
        encoding_name = encoding_map.get(
            self.config.model,
            "cl100k_base"  # Default
        )
        
        return tiktoken.get_encoding(encoding_name)
    
    def test_connection(self) -> bool:
        """
        Test OpenAI API connection.
        
        Returns:
            True if connection successful
        """
        try:
            # Generate embedding for simple test text
            result = self.embed("test")
            return len(result.vector) > 0
        except Exception as e:
            logger.error(f"Connection test failed: {e}")
            return False
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        Get information about current model.
        
        Returns:
            Dictionary with model info
        """
        return {
            "model": self.config.model.value,
            "provider": "openai",
            "dimensions": self.config.model.get_dimensions(),
            "max_tokens": self.config.model.get_max_tokens(),
            "cost_per_1k_tokens": self.config.model.get_cost_per_1k_tokens(),
            "max_batch_size": self.MAX_BATCH_SIZE
        }
    
    # -------------------------
    # ADVANCED FEATURES
    # -------------------------
    
    def embed_with_metadata(
        self,
        text: str,
        user: Optional[str] = None
    ) -> List[float]:
        """
        Generate embedding with user metadata.
        
        OpenAI tracks usage by user for better monitoring.
        
        Args:
            text: Text to embed
            user: User identifier (for tracking)
            
        Returns:
            Embedding vector
        """
        # Store original session headers
        original_headers = self.session.headers.copy()
        
        try:
            # Add user metadata if provided
            if user:
                self.session.headers["OpenAI-Organization"] = user
            
            vector = self._generate_embedding(text)
            return vector
        
        finally:
            # Restore original headers
            self.session.headers = original_headers
    
    def get_usage_stats(self) -> Dict[str, Any]:
        """
        Get detailed usage statistics.
        
        Returns:
            Dictionary with usage stats
        """
        stats = self.get_stats()
        
        # Add OpenAI-specific info
        stats.update({
            "api_base": self.api_base,
            "model_info": self.get_model_info(),
            "estimated_next_month_cost": stats["total_cost_usd"] * 30  # Rough estimate
        })
        
        return stats
    
    # -------------------------
    # CLEANUP
    # -------------------------
    
    def close(self) -> None:
        """Close HTTP session"""
        if self.session:
            self.session.close()
            logger.info("Session closed")
    
    def __del__(self):
        """Destructor - close session"""
        try:
            self.close()
        except:
            pass


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def create_openai_client(
    api_key: str,
    model: str = "text-embedding-3-small",
    batch_size: int = 100,
    **kwargs
) -> OpenAIEmbeddingClient:
    """
    Helper to create OpenAI embedding client.
    
    Args:
        api_key: OpenAI API key
        model: Model name
        batch_size: Batch size for processing
        **kwargs: Additional config parameters
        
    Returns:
        OpenAIEmbeddingClient instance
    """
    config = EmbeddingConfig(
        provider=EmbeddingProvider.OPENAI,
        model=EmbeddingModel(model),
        api_key=api_key,
        batch_size=batch_size,
        **kwargs
    )
    
    return OpenAIEmbeddingClient(config)


def estimate_openai_cost(
    texts: List[str],
    model: str = "text-embedding-3-small"
) -> Dict[str, Any]:
    """
    Estimate OpenAI embedding cost for texts.
    
    Uses tiktoken for accurate token counting.
    
    Args:
        texts: List of texts to embed
        model: Model name
        
    Returns:
        Dictionary with cost estimate
    """
    try:
        import tiktoken
        
        # Get tokenizer
        encoding = tiktoken.get_encoding("cl100k_base")
        
        # Count tokens
        total_tokens = sum(len(encoding.encode(text)) for text in texts)
        
        # Calculate cost
        model_enum = EmbeddingModel(model)
        cost_per_1k = model_enum.get_cost_per_1k_tokens()
        total_cost = (total_tokens / 1000) * cost_per_1k
        
        return {
            "num_texts": len(texts),
            "total_tokens": total_tokens,
            "average_tokens_per_text": total_tokens / len(texts) if texts else 0,
            "total_cost_usd": round(total_cost, 4),
            "model": model,
            "dimensions": model_enum.get_dimensions()
        }
    
    except ImportError:
        # Fallback to estimation if tiktoken not available
        from .embedding_client import estimate_embedding_cost
        return estimate_embedding_cost(texts, model)


def validate_openai_api_key(api_key: str) -> bool:
    """
    Validate OpenAI API key by making test request.
    
    Args:
        api_key: API key to validate
        
    Returns:
        True if valid
    """
    try:
        client = create_openai_client(api_key)
        return client.test_connection()
    except Exception:
        return False


# ============================================================================
# BATCH OPTIMIZATION
# ============================================================================

class OptimizedOpenAIBatchProcessor:
    """
    Optimized batch processor for large-scale embedding generation.
    
    Features:
    - Smart batching based on token counts
    - Parallel batch processing (async)
    - Progress tracking
    - Cost estimation
    
    Usage:
        processor = OptimizedOpenAIBatchProcessor(api_key)
        
        results = processor.process_large_dataset(
            texts=["text1", "text2", ...],
            max_workers=5
        )
    """
    
    def __init__(
        self,
        api_key: str,
        model: str = "text-embedding-3-small"
    ):
        """
        Initialize batch processor.
        
        Args:
            api_key: OpenAI API key
            model: Model to use
        """
        self.client = create_openai_client(api_key, model=model)
        self.model = model
    
    def process_large_dataset(
        self,
        texts: List[str],
        max_workers: int = 5,
        show_progress: bool = True
    ) -> List[List[float]]:
        """
        Process large dataset with parallel batching.
        
        Args:
            texts: List of texts to embed
            max_workers: Number of parallel workers
            show_progress: Whether to show progress
            
        Returns:
            List of embedding vectors
        """
        # Estimate cost first
        cost_estimate = estimate_openai_cost(texts, self.model)
        
        if show_progress:
            logger.info(f"Processing {len(texts)} texts")
            logger.info(f"Estimated cost: ${cost_estimate['total_cost_usd']:.4f}")
            logger.info(f"Estimated tokens: {cost_estimate['total_tokens']}")
        
        # Use client's batch processing
        result = self.client.embed_batch(
            texts,
            use_cache=True,
            show_progress=show_progress
        )
        
        if show_progress:
            logger.info(f"Complete! Actual cost: ${result.total_cost:.4f}")
            logger.info(f"Cache hits: {result.cache_hits}/{len(texts)}")
        
        return [emb.vector for emb in result.embeddings]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get processing statistics"""
        return self.client.get_stats()


# ============================================================================
# DIMENSION REDUCTION
# ============================================================================

def reduce_embedding_dimensions(
    vector: List[float],
    target_dims: int,
    method: str = "truncate"
) -> List[float]:
    """
    Reduce embedding dimensions.
    
    OpenAI's text-embedding-3-large supports native dimension reduction,
    but this provides post-processing alternatives.
    
    Args:
        vector: Original embedding vector
        target_dims: Target dimensions
        method: Reduction method ("truncate" or "pca")
        
    Returns:
        Reduced embedding vector
    """
    if target_dims >= len(vector):
        return vector
    
    if method == "truncate":
        # Simple truncation (works well for OpenAI embeddings)
        return vector[:target_dims]
    
    elif method == "pca":
        # PCA reduction (requires sklearn)
        try:
            from sklearn.decomposition import PCA
            import numpy as np
            
            pca = PCA(n_components=target_dims)
            reduced = pca.fit_transform(np.array([vector]))[0]
            return reduced.tolist()
        
        except ImportError:
            logger.warning("sklearn not available, using truncation")
            return vector[:target_dims]
    
    else:
        raise ValueError(f"Unknown reduction method: {method}")


# ============================================================================
# SIMILARITY HELPERS
# ============================================================================

def cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
    """
    Calculate cosine similarity between two vectors.
    
    Args:
        vec1: First vector
        vec2: Second vector
        
    Returns:
        Similarity score (0-1, higher = more similar)
    """
    if len(vec1) != len(vec2):
        raise ValueError("Vectors must have same dimensions")
    
    # Dot product
    dot_product = sum(a * b for a, b in zip(vec1, vec2))
    
    # Magnitudes
    mag1 = sum(a * a for a in vec1) ** 0.5
    mag2 = sum(b * b for b in vec2) ** 0.5
    
    # Cosine similarity
    if mag1 == 0 or mag2 == 0:
        return 0.0
    
    return dot_product / (mag1 * mag2)


def find_most_similar(
    query_vector: List[float],
    candidate_vectors: List[List[float]],
    top_k: int = 5
) -> List[tuple[int, float]]:
    """
    Find most similar vectors to query.
    
    Args:
        query_vector: Query embedding
        candidate_vectors: List of candidate embeddings
        top_k: Number of results to return
        
    Returns:
        List of (index, similarity_score) tuples, sorted by similarity descending
    """
    similarities = []
    
    for i, candidate in enumerate(candidate_vectors):
        similarity = cosine_similarity(query_vector, candidate)
        similarities.append((i, similarity))
    
    # Sort by similarity descending
    similarities.sort(key=lambda x: x[1], reverse=True)
    
    return similarities[:top_k]