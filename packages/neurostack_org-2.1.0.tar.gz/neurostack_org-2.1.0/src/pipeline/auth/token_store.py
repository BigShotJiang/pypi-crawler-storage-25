"""
Credential encryption at rest for the Neurostack Pipeline.

Provides Fernet symmetric encryption for connector credentials so that
plaintext secrets are never persisted in Postgres or any other store.

Architecture
------------
- **CredentialProvider** — a Protocol that SDK customers can implement to
  back credentials with any secrets manager (HashiCorp Vault, AWS SSM,
  Azure Key Vault, etc.).
- **FernetCredentialProvider** — default, in-memory implementation that
  encrypts/decrypts with ``cryptography.fernet.Fernet``.
- **EncryptedCredentialStore** — high-level API consumed by the pipeline
  to encrypt ``ConnectorConfig.credentials`` before storage and decrypt
  them at runtime.

Master key
----------
The master key is read from the ``NEUROSTACK_MASTER_KEY`` environment
variable.  It can be either:

* A valid URL-safe base64-encoded 32-byte Fernet key (as produced by
  ``generate_master_key()``), **or**
* An arbitrary passphrase — in which case PBKDF2-HMAC-SHA256 is used to
  derive a Fernet key from it.

Custom providers
----------------
SDK customers who want to store credentials in an external vault can
implement the ``CredentialProvider`` protocol::

    from neurostack.pipeline.auth.token_store import CredentialProvider

    class VaultCredentialProvider:
        \"\"\"Example: store credentials in HashiCorp Vault.\"\"\"

        def store(self, connector_id: str, tenant_id: str, credentials: dict) -> None:
            vault_client.write(f"secret/neurostack/{tenant_id}/{connector_id}", credentials)

        def retrieve(self, connector_id: str, tenant_id: str) -> dict | None:
            secret = vault_client.read(f"secret/neurostack/{tenant_id}/{connector_id}")
            return secret.get("data") if secret else None

        def delete(self, connector_id: str, tenant_id: str) -> bool:
            vault_client.delete(f"secret/neurostack/{tenant_id}/{connector_id}")
            return True

        def rotate_key(self, new_key: str | None = None) -> None:
            ...  # Vault handles rotation natively

        def health_check(self) -> bool:
            return vault_client.is_authenticated()
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
from typing import Any, Dict, Optional, Protocol, runtime_checkable

# ---------------------------------------------------------------------------
# Guarded import for ``cryptography``
# ---------------------------------------------------------------------------
try:
    from cryptography.fernet import Fernet, InvalidToken
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes

    _HAS_CRYPTOGRAPHY = True
except ImportError:  # pragma: no cover
    _HAS_CRYPTOGRAPHY = False
    Fernet = None  # type: ignore[assignment,misc]
    InvalidToken = Exception  # type: ignore[assignment,misc]

logger = logging.getLogger("neurostack.pipeline.auth.token_store")

# Fixed PBKDF2 salt — deterministic key derivation from passphrase.
# In production you may want to store a per-deployment random salt alongside
# the encrypted data; for the default in-memory provider a fixed salt is
# acceptable because the derived key never leaves memory.
_PBKDF2_SALT = b"neurostack-credential-store-v1"
_PBKDF2_ITERATIONS = 480_000


# ============================================================================
# CREDENTIAL PROVIDER PROTOCOL
# ============================================================================

@runtime_checkable
class CredentialProvider(Protocol):
    """
    Abstract interface for credential storage backends.

    SDK customers implement this protocol to integrate with their preferred
    secrets manager.  The default ``FernetCredentialProvider`` keeps
    encrypted credentials in memory and is suitable for single-process
    deployments or testing.

    Every method receives ``connector_id`` and ``tenant_id`` so that the
    provider can scope secrets per tenant and connector.

    Example — AWS SSM Parameter Store::

        class SSMCredentialProvider:
            def store(self, connector_id: str, tenant_id: str, credentials: dict) -> None:
                ssm.put_parameter(
                    Name=f"/neurostack/{tenant_id}/{connector_id}",
                    Value=json.dumps(credentials),
                    Type="SecureString",
                    Overwrite=True,
                )

            def retrieve(self, connector_id: str, tenant_id: str) -> dict | None:
                resp = ssm.get_parameter(
                    Name=f"/neurostack/{tenant_id}/{connector_id}",
                    WithDecryption=True,
                )
                return json.loads(resp["Parameter"]["Value"])

            def delete(self, connector_id: str, tenant_id: str) -> bool:
                ssm.delete_parameter(Name=f"/neurostack/{tenant_id}/{connector_id}")
                return True

            def rotate_key(self, new_key: str | None = None) -> None:
                ...  # SSM handles envelope encryption via KMS

            def health_check(self) -> bool:
                try:
                    ssm.describe_parameters(MaxResults=1)
                    return True
                except Exception:
                    return False
    """

    def store(self, connector_id: str, tenant_id: str, credentials: dict) -> None:
        """Encrypt and persist *credentials* for the given connector/tenant."""
        ...

    def retrieve(self, connector_id: str, tenant_id: str) -> Optional[dict]:
        """Return decrypted credentials, or ``None`` if not found."""
        ...

    def delete(self, connector_id: str, tenant_id: str) -> bool:
        """Remove credentials. Return ``True`` if they existed."""
        ...

    def rotate_key(self, new_key: Optional[str] = None) -> None:
        """Re-encrypt all stored credentials with a new key."""
        ...

    def health_check(self) -> bool:
        """Return ``True`` if the backend is healthy and reachable."""
        ...


# ============================================================================
# HELPERS — KEY DERIVATION
# ============================================================================

def _ensure_cryptography() -> None:
    """Raise a clear error if ``cryptography`` is not installed."""
    if not _HAS_CRYPTOGRAPHY:
        raise ImportError(
            "The 'cryptography' package is required for credential encryption. "
            "Install it with:  pip install cryptography"
        )


def _is_valid_fernet_key(key: str) -> bool:
    """Return ``True`` if *key* is a valid 32-byte URL-safe-base64 Fernet key."""
    try:
        decoded = base64.urlsafe_b64decode(key)
        return len(decoded) == 32
    except Exception:
        return False


def _derive_fernet_key(passphrase: str) -> bytes:
    """
    Derive a Fernet key from an arbitrary passphrase using PBKDF2.

    Returns URL-safe base64-encoded 32-byte key suitable for
    ``Fernet(key)``.
    """
    _ensure_cryptography()
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=_PBKDF2_SALT,
        iterations=_PBKDF2_ITERATIONS,
    )
    raw_key = kdf.derive(passphrase.encode("utf-8"))
    return base64.urlsafe_b64encode(raw_key)


def _build_fernet(master_key: str) -> "Fernet":
    """
    Build a ``Fernet`` instance from *master_key*.

    If *master_key* is already a valid Fernet key it is used directly;
    otherwise it is treated as a passphrase and a key is derived via
    PBKDF2.
    """
    _ensure_cryptography()

    if _is_valid_fernet_key(master_key):
        logger.debug("Master key is a valid Fernet key; using directly")
        return Fernet(master_key.encode("utf-8"))

    logger.debug("Master key is not a raw Fernet key; deriving via PBKDF2")
    derived = _derive_fernet_key(master_key)
    return Fernet(derived)


# ============================================================================
# FERNET CREDENTIAL PROVIDER  (default, in-memory)
# ============================================================================

class FernetCredentialProvider:
    """
    Default credential provider using Fernet symmetric encryption.

    Encrypted credentials are held in an in-memory dictionary keyed by
    ``(tenant_id, connector_id)``.  This is suitable for single-process
    deployments, CLI usage, and tests.  For multi-process / production
    use, back the store with Postgres (via ``EncryptedCredentialStore``)
    or implement a custom ``CredentialProvider`` that talks to your
    secrets manager.

    Parameters
    ----------
    master_key:
        A Fernet key or passphrase.  If ``None``, the value of the
        ``NEUROSTACK_MASTER_KEY`` environment variable is used.

    Raises
    ------
    ValueError
        If no master key is available.
    ImportError
        If ``cryptography`` is not installed.
    """

    def __init__(self, master_key: Optional[str] = None) -> None:
        _ensure_cryptography()

        resolved_key = master_key or os.environ.get("NEUROSTACK_MASTER_KEY")
        if not resolved_key:
            raise ValueError(
                "A master key is required. Either pass master_key= or set "
                "the NEUROSTACK_MASTER_KEY environment variable."
            )

        self._master_key_raw: str = resolved_key
        self._fernet: Fernet = _build_fernet(resolved_key)

        # In-memory encrypted store: (tenant_id, connector_id) -> bytes
        self._store: Dict[tuple, bytes] = {}

        logger.info(
            "FernetCredentialProvider initialised",
            extra={"key_source": "env" if master_key is None else "explicit"},
        )

    # ------------------------------------------------------------------
    # CredentialProvider interface
    # ------------------------------------------------------------------

    def store(self, connector_id: str, tenant_id: str, credentials: dict) -> None:
        """Encrypt *credentials* and persist them in memory."""
        plaintext = json.dumps(credentials, separators=(",", ":"), sort_keys=True)
        ciphertext = self._fernet.encrypt(plaintext.encode("utf-8"))
        self._store[(tenant_id, connector_id)] = ciphertext
        logger.info(
            "Credentials stored",
            extra={"connector_id": connector_id, "tenant_id": tenant_id},
        )

    def retrieve(self, connector_id: str, tenant_id: str) -> Optional[dict]:
        """Decrypt and return credentials, or ``None`` if not found."""
        ciphertext = self._store.get((tenant_id, connector_id))
        if ciphertext is None:
            logger.debug(
                "No credentials found",
                extra={"connector_id": connector_id, "tenant_id": tenant_id},
            )
            return None

        try:
            plaintext = self._fernet.decrypt(ciphertext)
            return json.loads(plaintext.decode("utf-8"))
        except InvalidToken:
            logger.error(
                "Failed to decrypt credentials (invalid key or corrupted data)",
                extra={"connector_id": connector_id, "tenant_id": tenant_id},
            )
            raise ValueError(
                f"Cannot decrypt credentials for connector={connector_id}, "
                f"tenant={tenant_id}. The master key may have changed."
            )

    def delete(self, connector_id: str, tenant_id: str) -> bool:
        """Remove credentials. Return ``True`` if they existed."""
        key = (tenant_id, connector_id)
        if key in self._store:
            del self._store[key]
            logger.info(
                "Credentials deleted",
                extra={"connector_id": connector_id, "tenant_id": tenant_id},
            )
            return True
        return False

    def rotate_key(self, new_key: Optional[str] = None) -> None:
        """
        Re-encrypt every stored credential with *new_key*.

        If *new_key* is ``None``, a fresh Fernet key is generated
        automatically.

        Parameters
        ----------
        new_key:
            A Fernet key or passphrase.  ``None`` to auto-generate.
        """
        if new_key is None:
            new_key = generate_master_key()
            logger.info("Auto-generated new master key for rotation")

        new_fernet = _build_fernet(new_key)

        re_encrypted: Dict[tuple, bytes] = {}
        for compound_key, ciphertext in self._store.items():
            # Decrypt with old key
            plaintext = self._fernet.decrypt(ciphertext)
            # Re-encrypt with new key
            re_encrypted[compound_key] = new_fernet.encrypt(plaintext)

        # Atomic swap
        self._store = re_encrypted
        self._fernet = new_fernet
        self._master_key_raw = new_key

        logger.info(
            "Key rotation complete",
            extra={"credentials_rotated": len(re_encrypted)},
        )

    def health_check(self) -> bool:
        """Return ``True`` — the in-memory store is always reachable."""
        try:
            # Round-trip a canary value to verify the Fernet key works.
            token = self._fernet.encrypt(b"healthcheck")
            self._fernet.decrypt(token)
            return True
        except Exception:
            logger.warning("Health check failed: Fernet round-trip error")
            return False

    # ------------------------------------------------------------------
    # Low-level encrypt / decrypt (used by EncryptedCredentialStore)
    # ------------------------------------------------------------------

    def encrypt_bytes(self, data: bytes) -> bytes:
        """Encrypt raw bytes and return the Fernet token."""
        return self._fernet.encrypt(data)

    def decrypt_bytes(self, token: bytes) -> bytes:
        """Decrypt a Fernet token and return the plaintext bytes."""
        try:
            return self._fernet.decrypt(token)
        except InvalidToken as exc:
            raise ValueError("Decryption failed — invalid key or corrupted data") from exc


# ============================================================================
# ENCRYPTED CREDENTIAL STORE  (high-level pipeline API)
# ============================================================================

class EncryptedCredentialStore:
    """
    High-level API used by the pipeline to encrypt and decrypt
    ``ConnectorConfig.credentials`` before they hit persistent storage.

    The store delegates actual encryption to a ``CredentialProvider``.
    The default provider is ``FernetCredentialProvider`` (in-memory),
    but SDK customers can inject any provider that satisfies the
    ``CredentialProvider`` protocol.

    Usage::

        store = create_credential_store()  # reads NEUROSTACK_MASTER_KEY

        # Before persisting to Postgres
        encrypted = store.encrypt_config_credentials({
            "client_id": "abc",
            "client_secret": "super-secret",
        })
        # encrypted is a base64 string safe for a TEXT column

        # At runtime, when loading from Postgres
        creds = store.decrypt_config_credentials(encrypted)
        assert creds == {"client_id": "abc", "client_secret": "super-secret"}

    Parameters
    ----------
    provider:
        Any object that satisfies the ``CredentialProvider`` protocol.
    """

    def __init__(self, provider: CredentialProvider) -> None:  # type: ignore[type-arg]
        if not isinstance(provider, CredentialProvider):
            raise TypeError(
                f"provider must satisfy the CredentialProvider protocol, "
                f"got {type(provider).__name__}"
            )
        self._provider = provider
        logger.info(
            "EncryptedCredentialStore initialised",
            extra={"provider": type(provider).__name__},
        )

    # ------------------------------------------------------------------
    # Main encryption API  (for ConnectorConfig.credentials)
    # ------------------------------------------------------------------

    def encrypt_config_credentials(self, config: dict) -> str:
        """
        Serialize and encrypt a credentials dict.

        Returns a URL-safe base64 string that can be stored in a
        Postgres ``TEXT`` column.

        Parameters
        ----------
        config:
            The credentials dictionary to encrypt.

        Returns
        -------
        str
            Encrypted, base64-encoded string.
        """
        if not isinstance(config, dict):
            raise TypeError(f"config must be a dict, got {type(config).__name__}")

        plaintext = json.dumps(config, separators=(",", ":"), sort_keys=True).encode("utf-8")

        # Use low-level encrypt if available (FernetCredentialProvider),
        # otherwise fall back to store/retrieve round-trip.
        if hasattr(self._provider, "encrypt_bytes"):
            token = self._provider.encrypt_bytes(plaintext)
        else:
            # Fallback: store under a synthetic key, read back the ciphertext.
            # This path is for custom providers that only expose the protocol.
            import uuid as _uuid

            tmp_id = f"_encrypt_tmp_{_uuid.uuid4().hex}"
            self._provider.store(tmp_id, "_system", config)
            # We cannot get the raw ciphertext from an opaque provider,
            # so we must encrypt ourselves.
            _ensure_cryptography()
            raise NotImplementedError(
                "encrypt_config_credentials requires a provider that exposes "
                "encrypt_bytes() or is a FernetCredentialProvider."
            )

        # Return as a plain string (the Fernet token is already URL-safe
        # base64, but we decode from bytes to str for Postgres TEXT).
        return token.decode("utf-8") if isinstance(token, bytes) else token

    def decrypt_config_credentials(self, encrypted: str) -> dict:
        """
        Decrypt a base64-encoded encrypted string back to a credentials
        dict.

        Parameters
        ----------
        encrypted:
            The string produced by ``encrypt_config_credentials``.

        Returns
        -------
        dict
            The original credentials dictionary.

        Raises
        ------
        ValueError
            If decryption fails (wrong key, corrupted data).
        """
        if not isinstance(encrypted, str):
            raise TypeError(f"encrypted must be a str, got {type(encrypted).__name__}")

        token = encrypted.encode("utf-8") if isinstance(encrypted, str) else encrypted

        if hasattr(self._provider, "decrypt_bytes"):
            plaintext = self._provider.decrypt_bytes(token)
        else:
            raise NotImplementedError(
                "decrypt_config_credentials requires a provider that exposes "
                "decrypt_bytes() or is a FernetCredentialProvider."
            )

        return json.loads(plaintext.decode("utf-8"))

    # ------------------------------------------------------------------
    # Delegate convenience methods to the provider
    # ------------------------------------------------------------------

    def store(self, connector_id: str, tenant_id: str, credentials: dict) -> None:
        """Store credentials for a connector (encrypted at rest)."""
        self._provider.store(connector_id, tenant_id, credentials)

    def retrieve(self, connector_id: str, tenant_id: str) -> Optional[dict]:
        """Retrieve and decrypt credentials for a connector."""
        return self._provider.retrieve(connector_id, tenant_id)

    def delete(self, connector_id: str, tenant_id: str) -> bool:
        """Delete credentials for a connector."""
        return self._provider.delete(connector_id, tenant_id)

    def rotate_key(self, new_key: Optional[str] = None) -> None:
        """Rotate the encryption key, re-encrypting all stored credentials."""
        self._provider.rotate_key(new_key)

    def health_check(self) -> bool:
        """Check that the credential backend is healthy."""
        return self._provider.health_check()


# ============================================================================
# FACTORY & UTILITY FUNCTIONS
# ============================================================================

def generate_master_key() -> str:
    """
    Generate a new, random Fernet master key.

    Returns a URL-safe base64-encoded 32-byte key string suitable for
    the ``NEUROSTACK_MASTER_KEY`` environment variable.

    Returns
    -------
    str
        A fresh Fernet key.

    Example::

        >>> from neurostack.pipeline.auth.token_store import generate_master_key
        >>> key = generate_master_key()
        >>> print(key)  # e.g. "ZmVybmV0LWtleS0xMjM0NTY3ODkwYWJjZGVm..."
    """
    _ensure_cryptography()
    return Fernet.generate_key().decode("utf-8")


def create_credential_store(
    master_key: Optional[str] = None,
    provider: Optional[CredentialProvider] = None,
) -> EncryptedCredentialStore:
    """
    Factory that creates a ready-to-use ``EncryptedCredentialStore``.

    Parameters
    ----------
    master_key:
        Fernet key or passphrase.  Ignored when *provider* is given.
        Falls back to ``NEUROSTACK_MASTER_KEY`` env var.
    provider:
        An optional custom ``CredentialProvider`` implementation.
        If ``None``, a ``FernetCredentialProvider`` is created with
        *master_key*.

    Returns
    -------
    EncryptedCredentialStore

    Example::

        # Simplest usage — reads NEUROSTACK_MASTER_KEY from env
        store = create_credential_store()

        # Explicit key
        store = create_credential_store(master_key="my-secret-passphrase")

        # Custom provider (e.g. Vault)
        store = create_credential_store(provider=my_vault_provider)
    """
    if provider is not None:
        logger.info(
            "Creating EncryptedCredentialStore with custom provider",
            extra={"provider": type(provider).__name__},
        )
        return EncryptedCredentialStore(provider=provider)

    fernet_provider = FernetCredentialProvider(master_key=master_key)
    return EncryptedCredentialStore(provider=fernet_provider)
