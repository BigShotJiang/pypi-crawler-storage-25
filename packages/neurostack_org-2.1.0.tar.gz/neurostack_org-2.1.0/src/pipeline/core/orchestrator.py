"""
Pipeline orchestrator.

Central coordinator for the ingestion pipeline. Manages connector execution,
rate limiting, failure handling, checkpointing, and coordination between
all pipeline stages.

This is the main entry point for data ingestion.
"""

import time
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import logging

from ..connectors.base import (
    Connector,
    ConnectorConfig,
    ConnectorResult,
    ConnectorStatus,
    ConnectorError,
    ConnectorRateLimitError,
    ConnectorAuthError,
    ExtractionBatch
)
from ..connectors.registry import ConnectorRegistry
from ..storage.interfaces import MetadataStore, StorageBackend
from .ingestion_engine import IngestionEngine
from ..utils.retry import RetryStrategy, exponential_backoff
from ..utils.exceptions import (
    PipelineError,
    OrchestrationError,
    RateLimitExceededError
)
from ..audit.logger import AuditLogger


# ============================================================================
# LOGGING
# ============================================================================

logger = logging.getLogger("neurostack.pipeline.orchestrator")


# ============================================================================
# ORCHESTRATOR ENUMS
# ============================================================================

class JobStatus(Enum):
    """Ingestion job status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    PAUSED = "paused"
    CANCELLED = "cancelled"


class JobPriority(Enum):
    """Job execution priority"""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


# ============================================================================
# JOB MODELS
# ============================================================================

@dataclass
class IngestionJob:
    """
    Ingestion job specification.
    
    Represents a single connector execution run.
    """
    job_id: str
    connector_config: ConnectorConfig
    
    # Scheduling
    priority: JobPriority = JobPriority.NORMAL
    scheduled_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    
    # Execution state
    status: JobStatus = JobStatus.PENDING
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    # Stats
    items_processed: int = 0
    items_failed: int = 0
    batches_completed: int = 0
    
    # Checkpoint (for resume)
    last_cursor: Optional[str] = None
    last_checkpoint_at: Optional[datetime] = None
    
    # Errors
    error_message: Optional[str] = None
    error_count: int = 0
    
    # Metadata
    created_by: str = "orchestrator"
    retry_count: int = 0
    max_retries: int = 3


@dataclass
class OrchestratorConfig:
    """
    Orchestrator configuration.
    
    Global settings for pipeline orchestration.
    """
    # Rate limiting (global)
    global_rate_limit_per_minute: int = 1000
    global_rate_limit_per_hour: int = 50000
    
    # Concurrency
    max_concurrent_connectors: int = 5
    max_concurrent_jobs: int = 10
    
    # Retry settings
    default_retry_strategy: RetryStrategy = field(
        default_factory=lambda: RetryStrategy(
            max_retries=3,
            base_delay=5.0,
            max_delay=300.0,
            exponential_base=2.0
        )
    )
    
    # Checkpointing
    checkpoint_interval_batches: int = 10  # Save checkpoint every N batches
    checkpoint_interval_seconds: int = 300  # Or every N seconds
    
    # Timeouts
    connector_timeout_seconds: int = 3600  # 1 hour max per connector
    batch_timeout_seconds: int = 300       # 5 minutes max per batch
    
    # Failure handling
    max_consecutive_failures: int = 5      # Pause connector after N failures
    failure_backoff_seconds: int = 60
    
    # Audit
    enable_detailed_logging: bool = True


@dataclass
class OrchestratorStats:
    """
    Orchestrator execution statistics.
    """
    jobs_queued: int = 0
    jobs_running: int = 0
    jobs_completed: int = 0
    jobs_failed: int = 0
    
    total_items_processed: int = 0
    total_items_failed: int = 0
    total_batches_processed: int = 0
    
    connectors_active: int = 0
    connectors_paused: int = 0
    
    rate_limit_hits: int = 0
    auth_failures: int = 0
    
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_activity_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ============================================================================
# RATE LIMITER
# ============================================================================

class RateLimiter:
    """
    Token bucket rate limiter.
    
    Enforces global and per-connector rate limits.
    """
    
    def __init__(
        self,
        rate_per_minute: int,
        rate_per_hour: int
    ):
        """
        Initialize rate limiter.
        
        Args:
            rate_per_minute: Requests per minute limit
            rate_per_hour: Requests per hour limit
        """
        self.rate_per_minute = rate_per_minute
        self.rate_per_hour = rate_per_hour
        
        # Token buckets
        self.minute_tokens = rate_per_minute
        self.hour_tokens = rate_per_hour
        
        # Refill tracking
        self.last_minute_refill = datetime.now(timezone.utc)
        self.last_hour_refill = datetime.now(timezone.utc)
        
        # Stats
        self.requests_made = 0
        self.requests_blocked = 0
    
    def acquire(self, tokens: int = 1) -> bool:
        """
        Acquire tokens from rate limiter.
        
        Args:
            tokens: Number of tokens to acquire
            
        Returns:
            True if tokens acquired, False if rate limited
        """
        # Refill buckets
        self._refill()
        
        # Check if enough tokens
        if self.minute_tokens >= tokens and self.hour_tokens >= tokens:
            self.minute_tokens -= tokens
            self.hour_tokens -= tokens
            self.requests_made += tokens
            return True
        else:
            self.requests_blocked += tokens
            return False
    
    def wait_time(self) -> float:
        """
        Calculate wait time until tokens available.
        
        Returns:
            Seconds to wait
        """
        self._refill()
        
        if self.minute_tokens < 1:
            # Wait until next minute refill
            elapsed = (datetime.now(timezone.utc) - self.last_minute_refill).total_seconds()
            return max(0, 60 - elapsed)
        
        if self.hour_tokens < 1:
            # Wait until next hour refill
            elapsed = (datetime.now(timezone.utc) - self.last_hour_refill).total_seconds()
            return max(0, 3600 - elapsed)
        
        return 0
    
    def _refill(self) -> None:
        """Refill token buckets based on elapsed time"""
        now = datetime.now(timezone.utc)
        
        # Refill minute bucket
        minute_elapsed = (now - self.last_minute_refill).total_seconds()
        if minute_elapsed >= 60:
            self.minute_tokens = self.rate_per_minute
            self.last_minute_refill = now
        
        # Refill hour bucket
        hour_elapsed = (now - self.last_hour_refill).total_seconds()
        if hour_elapsed >= 3600:
            self.hour_tokens = self.rate_per_hour
            self.last_hour_refill = now


# ============================================================================
# PIPELINE ORCHESTRATOR
# ============================================================================

class PipelineOrchestrator:
    """
    Central orchestrator for ingestion pipeline.
    
    Responsibilities:
    - Schedule and execute ingestion jobs
    - Manage connector lifecycle
    - Enforce rate limits
    - Handle failures and retries
    - Save checkpoints for resume
    - Coordinate with storage and audit
    
    Usage:
        orchestrator = PipelineOrchestrator(storage_backend, config)
        
        # Queue job
        job = orchestrator.create_job(connector_config)
        
        # Execute
        result = orchestrator.execute_job(job)
    """
    
    def __init__(
        self,
        storage_backend: StorageBackend,
        connector_registry: ConnectorRegistry,
        config: Optional[OrchestratorConfig] = None,
        audit_logger: Optional[AuditLogger] = None
    ):
        """
        Initialize orchestrator.
        
        Args:
            storage_backend: Storage backend for persistence
            connector_registry: Connector registry
            config: Orchestrator configuration (default if None)
            audit_logger: Audit logger (created if None)
        """
        self.storage = storage_backend
        self.config = config or OrchestratorConfig()
        self.registry = connector_registry
        self.audit_logger = audit_logger or AuditLogger(storage_backend.metadata)
        
        # Initialize ingestion engine
        self.ingestion_engine = IngestionEngine(storage_backend, self.audit_logger)
        
        # Rate limiters
        self.global_rate_limiter = RateLimiter(
            self.config.global_rate_limit_per_minute,
            self.config.global_rate_limit_per_hour
        )
        self.connector_rate_limiters: Dict[str, RateLimiter] = {}
        
        # Job tracking
        self.jobs: Dict[str, IngestionJob] = {}
        self.active_connectors: Dict[str, Connector] = {}
        
        # Stats
        self.stats = OrchestratorStats()
        
        # Paused connectors (due to repeated failures)
        self.paused_connectors: Dict[str, datetime] = {}
        
        logger.info("Initialized")
    
    # -------------------------
    # JOB MANAGEMENT
    # -------------------------
    
    def create_job(
        self,
        connector_config: ConnectorConfig,
        priority: JobPriority = JobPriority.NORMAL
    ) -> IngestionJob:
        """
        Create ingestion job.
        
        Args:
            connector_config: Connector configuration
            priority: Job priority
            
        Returns:
            Created job
        """
        job_id = self._generate_job_id(connector_config)
        
        # Load checkpoint if exists
        checkpoint = self.storage.metadata.get_connector_checkpoint(
            connector_config.connector_id
        )
        
        last_cursor = None
        if checkpoint:
            last_cursor = checkpoint.get("last_cursor")
            connector_config.last_cursor = last_cursor
        
        job = IngestionJob(
            job_id=job_id,
            connector_config=connector_config,
            priority=priority,
            last_cursor=last_cursor
        )
        
        self.jobs[job_id] = job
        self.stats.jobs_queued += 1
        
        logger.info(f"Created job: {job_id} (connector: {connector_config.connector_type})")
        
        return job
    
    def execute_job(
        self,
        job: IngestionJob,
        resume_from_checkpoint: bool = True
    ) -> ConnectorResult:
        """
        Execute ingestion job synchronously.
        
        This is the main execution path. Handles full lifecycle:
        1. Validate job
        2. Create connector
        3. Authenticate
        4. Extract batches (with rate limiting, retries, checkpoints)
        5. Process each batch through ingestion engine
        6. Handle failures
        7. Cleanup
        
        Args:
            job: Job to execute
            resume_from_checkpoint: Whether to resume from saved checkpoint
            
        Returns:
            ConnectorResult with execution details
            
        Raises:
            OrchestrationError: If execution fails
        """
        job_id = job.job_id
        connector_type = job.connector_config.connector_type
        
        logger.info(f"Executing job: {job_id}")
        
        # Update job status
        job.status = JobStatus.RUNNING
        job.started_at = datetime.now(timezone.utc)
        self.stats.jobs_running += 1
        
        # Check if connector is paused
        if self._is_connector_paused(job.connector_config.connector_id):
            job.status = JobStatus.PAUSED
            job.error_message = "Connector paused due to repeated failures"
            self.stats.jobs_failed += 1
            return self._create_error_result(job, job.error_message)
        
        connector: Optional[Connector] = None
        result: Optional[ConnectorResult] = None
        
        try:
            # Step 1: Create connector
            connector = self._create_connector(job.connector_config)
            self.active_connectors[job.connector_config.connector_id] = connector
            self.stats.connectors_active += 1
            
            # Step 2: Authenticate
            if not self._authenticate_connector(connector, job):
                job.status = JobStatus.FAILED
                self.stats.jobs_failed += 1
                self.stats.auth_failures += 1
                return self._create_error_result(job, "Authentication failed")
            
            # Step 3: Validate config
            if not connector.validate_config():
                job.status = JobStatus.FAILED
                self.stats.jobs_failed += 1
                return self._create_error_result(job, "Invalid configuration")
            
            # Step 4: Extract and process batches
            result = self._extract_all_batches(connector, job, resume_from_checkpoint)
            
            # Step 5: Update job status
            if result.status == ConnectorStatus.COMPLETED:
                job.status = JobStatus.COMPLETED
                job.completed_at = datetime.now(timezone.utc)
                self.stats.jobs_completed += 1
                logger.info(f"Job completed: {job_id} ({result.items_extracted} items)")
            else:
                job.status = JobStatus.FAILED
                job.error_message = result.error_message
                self.stats.jobs_failed += 1
                
                # Check if should pause connector
                self._check_failure_threshold(job)
            
            # Update stats
            self.stats.total_items_processed += result.items_extracted
            self.stats.total_items_failed += result.items_failed
            self.stats.total_batches_processed += result.batches_processed
            self.stats.last_activity_at = datetime.now(timezone.utc)
            
            return result
        
        except ConnectorRateLimitError as e:
            logger.warning(f"Rate limit hit for job {job_id}: {e}")
            self.stats.rate_limit_hits += 1
            
            # Pause and schedule retry
            job.status = JobStatus.PAUSED
            return self._create_error_result(
                job,
                f"Rate limited. Retry after {e.retry_after_seconds}s"
            )
        
        except Exception as e:
            logger.error(f"Job failed: {job_id} - {e}")
            job.status = JobStatus.FAILED
            job.error_message = str(e)
            job.error_count += 1
            self.stats.jobs_failed += 1
            
            return self._create_error_result(job, str(e))
        
        finally:
            # Cleanup
            if connector:
                try:
                    connector.cleanup()
                except Exception as e:
                    logger.error(f"Cleanup failed for {job_id}: {e}")
                
                # Remove from active
                if job.connector_config.connector_id in self.active_connectors:
                    del self.active_connectors[job.connector_config.connector_id]
                    self.stats.connectors_active -= 1
            
            self.stats.jobs_running -= 1
    
    def cancel_job(self, job_id: str) -> bool:
        """
        Cancel running job.
        
        Args:
            job_id: Job identifier
            
        Returns:
            True if cancelled
        """
        if job_id not in self.jobs:
            return False
        
        job = self.jobs[job_id]
        
        if job.status == JobStatus.RUNNING:
            job.status = JobStatus.CANCELLED
            job.error_message = "Cancelled by user"
            logger.info(f"Job cancelled: {job_id}")
            return True
        
        return False
    
    # -------------------------
    # BATCH EXTRACTION
    # -------------------------
    
    def _extract_all_batches(
        self,
        connector: Connector,
        job: IngestionJob,
        resume_from_checkpoint: bool
    ) -> ConnectorResult:
        """
        Extract all batches from connector.
        
        Main extraction loop with rate limiting, retries, checkpointing.
        
        Args:
            connector: Connector instance
            job: Job being executed
            resume_from_checkpoint: Whether to resume from checkpoint
            
        Returns:
            ConnectorResult
        """
        result = ConnectorResult(
            connector_id=job.connector_config.connector_id,
            status=ConnectorStatus.RUNNING,
            started_at=datetime.now(timezone.utc)
        )
        
        # Determine starting cursor
        cursor = job.last_cursor if resume_from_checkpoint else None
        batch_number = 0
        consecutive_failures = 0
        last_checkpoint_time = datetime.now(timezone.utc)
        
        logger.info(f"Starting extraction (resume={resume_from_checkpoint}, cursor={cursor})")
        
        while True:
            # Check if job cancelled
            if job.status == JobStatus.CANCELLED:
                result.status = ConnectorStatus.FAILED
                result.error_message = "Job cancelled"
                break
            
            # Check timeout
            if self._is_timed_out(job):
                result.status = ConnectorStatus.FAILED
                result.error_message = "Job timed out"
                break
            
            # Apply rate limiting
            if not self._acquire_rate_limit(job.connector_config):
                wait_time = self.global_rate_limiter.wait_time()
                logger.warning(f"Rate limited. Waiting {wait_time:.0f}s")
                time.sleep(wait_time)
                continue
            
            # Extract batch with retry
            try:
                batch = self._extract_batch_with_retry(connector, cursor, job)
                batch_number += 1
                
                # Process batch through ingestion engine
                batch_result = self.ingestion_engine.process_batch(
                    batch=batch,
                    connector=connector,
                    job_id=job.job_id
                )
                
                # Update stats
                result.items_extracted += batch_result["items_processed"]
                result.items_failed += batch_result["items_failed"]
                result.batches_processed += 1
                
                job.items_processed += batch_result["items_processed"]
                job.items_failed += batch_result["items_failed"]
                job.batches_completed += 1
                
                # Reset failure counter on success
                consecutive_failures = 0
                
                # Save checkpoint periodically
                if self._should_checkpoint(job, last_checkpoint_time):
                    self._save_checkpoint(job, batch.next_cursor)
                    last_checkpoint_time = datetime.now(timezone.utc)
                
                # Update cursor
                cursor = batch.next_cursor
                result.last_cursor = cursor
                job.last_cursor = cursor
                
                # Check if more batches
                if not batch.has_more:
                    logger.info(f"Extraction complete ({batch_number} batches)")
                    result.status = ConnectorStatus.COMPLETED
                    break
            
            except ConnectorRateLimitError as e:
                # Rate limit from connector (not global)
                logger.warning(f"Connector rate limited: {e}")
                result.status = ConnectorStatus.RATE_LIMITED
                result.rate_limited_at = datetime.now(timezone.utc)
                result.retry_after_seconds = e.retry_after_seconds
                break
            
            except Exception as e:
                consecutive_failures += 1
                logger.error(f"Batch {batch_number} failed: {e}")
                
                if consecutive_failures >= self.config.max_consecutive_failures:
                    logger.error("Max consecutive failures reached")
                    result.status = ConnectorStatus.FAILED
                    result.error_message = f"Max consecutive failures: {e}"
                    break
                
                # Wait before retry
                time.sleep(self.config.failure_backoff_seconds)
        
        # Final checkpoint
        if result.last_cursor:
            self._save_checkpoint(job, result.last_cursor)
        
        result.completed_at = datetime.now(timezone.utc)
        return result
    
    def _extract_batch_with_retry(
        self,
        connector: Connector,
        cursor: Optional[str],
        job: IngestionJob
    ) -> ExtractionBatch:
        """
        Extract batch with exponential backoff retry.
        
        Args:
            connector: Connector instance
            cursor: Pagination cursor
            job: Job being executed
            
        Returns:
            ExtractionBatch
            
        Raises:
            Exception: If all retries exhausted
        """
        strategy = self.config.default_retry_strategy
        
        for attempt in range(strategy.max_retries + 1):
            try:
                batch = connector.extract_batch(
                    cursor=cursor,
                    batch_size=job.connector_config.batch_size
                )
                return batch
            
            except ConnectorRateLimitError:
                # Don't retry rate limit errors
                raise
            
            except Exception as e:
                if attempt < strategy.max_retries:
                    delay = exponential_backoff(
                        attempt,
                        strategy.base_delay,
                        strategy.exponential_base,
                        strategy.max_delay
                    )
                    logger.warning(f"Batch extraction failed (attempt {attempt + 1}). Retrying in {delay:.1f}s")
                    time.sleep(delay)
                else:
                    # All retries exhausted
                    raise
    
    # -------------------------
    # CONNECTOR MANAGEMENT
    # -------------------------
    
    def _create_connector(self, config: ConnectorConfig) -> Connector:
        """Create connector instance from config"""
        try:
            return self.registry.create_connector(config)
        except Exception as e:
            raise OrchestrationError(f"Failed to create connector: {e}") from e
    
    def _authenticate_connector(self, connector: Connector, job: IngestionJob) -> bool:
        """
        Authenticate connector with retry.
        
        Args:
            connector: Connector instance
            job: Job being executed
            
        Returns:
            True if authenticated
        """
        strategy = self.config.default_retry_strategy
        
        for attempt in range(strategy.max_retries + 1):
            try:
                if connector.authenticate():
                    logger.info("Authentication successful")
                    return True
                else:
                    logger.warning(f"Authentication failed (attempt {attempt + 1})")
            
            except ConnectorAuthError as e:
                logger.error(f"Auth error: {e}")
                if attempt < strategy.max_retries:
                    delay = exponential_backoff(attempt, 2.0, 2.0, 30.0)
                    time.sleep(delay)
                else:
                    return False
        
        return False
    
    # -------------------------
    # RATE LIMITING
    # -------------------------
    
    def _acquire_rate_limit(self, config: ConnectorConfig) -> bool:
        """
        Acquire rate limit tokens (global + per-connector).
        
        Args:
            config: Connector config
            
        Returns:
            True if tokens acquired
        """
        # Global rate limit
        if not self.global_rate_limiter.acquire():
            return False
        
        # Per-connector rate limit
        connector_id = config.connector_id
        if connector_id not in self.connector_rate_limiters:
            self.connector_rate_limiters[connector_id] = RateLimiter(
                config.rate_limit_per_minute,
                config.rate_limit_per_minute * 60  # Approximate hourly
            )
        
        connector_limiter = self.connector_rate_limiters[connector_id]
        if not connector_limiter.acquire():
            return False
        
        return True
    
    # -------------------------
    # CHECKPOINTING
    # -------------------------
    
    def _should_checkpoint(self, job: IngestionJob, last_checkpoint_time: datetime) -> bool:
        """Check if should save checkpoint"""
        # Checkpoint every N batches
        if job.batches_completed % self.config.checkpoint_interval_batches == 0:
            return True
        
        # Checkpoint every N seconds
        elapsed = (datetime.now(timezone.utc) - last_checkpoint_time).total_seconds()
        if elapsed >= self.config.checkpoint_interval_seconds:
            return True
        
        return False
    
    def _save_checkpoint(self, job: IngestionJob, cursor: Optional[str]) -> None:
        """Save checkpoint to storage"""
        checkpoint_data = {
            "job_id": job.job_id,
            "last_cursor": cursor,
            "items_processed": job.items_processed,
            "batches_completed": job.batches_completed,
            "checkpoint_at": datetime.now(timezone.utc).isoformat()
        }
        
        self.storage.metadata.save_connector_checkpoint(
            job.connector_config.connector_id,
            checkpoint_data
        )
        
        job.last_checkpoint_at = datetime.now(timezone.utc)
        logger.info(f"Checkpoint saved (cursor={cursor})")
    
    # -------------------------
    # FAILURE HANDLING
    # -------------------------
    
    def _check_failure_threshold(self, job: IngestionJob) -> None:
        """Check if connector should be paused due to failures"""
        job.error_count += 1
        
        if job.error_count >= self.config.max_consecutive_failures:
            # Pause connector
            connector_id = job.connector_config.connector_id
            pause_until = datetime.now(timezone.utc) + timedelta(hours=1)
            self.paused_connectors[connector_id] = pause_until
            self.stats.connectors_paused += 1
            
            logger.warning(f"Connector paused: {connector_id} (too many failures)")
    
    def _is_connector_paused(self, connector_id: str) -> bool:
        """Check if connector is paused"""
        if connector_id in self.paused_connectors:
            pause_until = self.paused_connectors[connector_id]
            if datetime.now(timezone.utc) < pause_until:
                return True
            else:
                # Unpause
                del self.paused_connectors[connector_id]
                self.stats.connectors_paused -= 1
        
        return False
    
    def unpause_connector(self, connector_id: str) -> bool:
        """Manually unpause connector"""
        if connector_id in self.paused_connectors:
            del self.paused_connectors[connector_id]
            self.stats.connectors_paused -= 1
            logger.info(f"Connector unpaused: {connector_id}")
            return True
        return False
    
    # -------------------------
    # HELPERS
    # -------------------------
    
    def _is_timed_out(self, job: IngestionJob) -> bool:
        """Check if job has timed out"""
        if not job.started_at:
            return False
        
        elapsed = (datetime.now(timezone.utc) - job.started_at).total_seconds()
        return elapsed >= self.config.connector_timeout_seconds
    
    def _generate_job_id(self, config: ConnectorConfig) -> str:
        """Generate unique job ID"""
        import uuid
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        return f"{config.connector_type}_{timestamp}_{uuid.uuid4().hex[:8]}"
    
    def _create_error_result(self, job: IngestionJob, error_message: str) -> ConnectorResult:
        """Create error result"""
        return ConnectorResult(
            connector_id=job.connector_config.connector_id,
            status=ConnectorStatus.FAILED,
            started_at=job.started_at or datetime.now(timezone.utc),
            completed_at=datetime.now(timezone.utc),
            items_extracted=job.items_processed,
            items_failed=job.items_failed,
            batches_processed=job.batches_completed,
            error_message=error_message
        )
    
    # -------------------------
    # QUERIES
    # -------------------------
    
    def get_job(self, job_id: str) -> Optional[IngestionJob]:
        """Get job by ID"""
        return self.jobs.get(job_id)
    
    def list_jobs(
        self,
        status: Optional[JobStatus] = None
    ) -> List[IngestionJob]:
        """List jobs, optionally filtered by status"""
        jobs = list(self.jobs.values())
        
        if status:
            jobs = [j for j in jobs if j.status == status]
        
        return sorted(jobs, key=lambda j: j.scheduled_at, reverse=True)
    
    def get_stats(self) -> OrchestratorStats:
        """Get orchestrator statistics"""
        return self.stats
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check orchestrator health.
        
        Returns:
            Health status dictionary
        """
        storage_health = self.storage.health_check()
        
        return {
            "orchestrator": "healthy",
            "storage": storage_health,
            "stats": {
                "jobs_running": self.stats.jobs_running,
                "connectors_active": self.stats.connectors_active,
                "connectors_paused": self.stats.connectors_paused,
                "total_items_processed": self.stats.total_items_processed
            },
            "rate_limiting": {
                "global_requests_made": self.global_rate_limiter.requests_made,
                "global_requests_blocked": self.global_rate_limiter.requests_blocked
            }
        }