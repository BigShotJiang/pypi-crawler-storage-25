"""Neurostack CLI - main entry point."""

import os
import subprocess

import click
import yaml

VERSION = "2.0.0"


def _numbered_menu(title, options, default=1):
    """Display a numbered menu and return the selected option.

    Args:
        title: Menu title shown above options.
        options: List of dicts with 'label' and 'value' keys,
                 and optional 'hint' for description text.
        default: 1-based default selection number.

    Returns:
        The 'value' of the selected option.
    """
    click.echo(click.style(f"\n  {title}", fg="cyan", bold=True))
    click.echo()
    for i, opt in enumerate(options, 1):
        marker = click.style(f"  [{i}]", fg="white", bold=True)
        label = click.style(opt["label"], bold=(i == default))
        hint = f'  {click.style(opt.get("hint", ""), fg="bright_black")}' if opt.get("hint") else ""
        default_tag = click.style(" (default)", fg="green") if i == default else ""
        click.echo(f"  {marker} {label}{default_tag}{hint}")

    click.echo()
    while True:
        raw = click.prompt(
            f"  Select an option",
            default=str(default),
            show_default=False,
        )
        try:
            idx = int(raw)
            if 1 <= idx <= len(options):
                selected = options[idx - 1]
                click.echo(f'  -> {click.style(selected["label"], fg="green")}')
                return selected["value"]
        except ValueError:
            pass
        click.echo(click.style(f"  Please enter a number between 1 and {len(options)}", fg="yellow"))


@click.group()
@click.version_option(version=VERSION, prog_name="neurostack")
def cli():
    """Neurostack - Enterprise AI Intelligence Brain."""
    pass


@cli.command()
def migrate():
    """Run database migrations (Alembic)."""
    click.echo("Running database migrations...")
    click.echo("  -> alembic upgrade head")
    try:
        from alembic.config import Config
        from alembic import command

        alembic_cfg = Config("alembic.ini")
        command.upgrade(alembic_cfg, "head")
        click.echo("Migrations completed successfully.")
    except Exception as e:
        click.echo(f"Migration failed: {e}", err=True)
        raise SystemExit(1)


@cli.command()
@click.argument("connector_type")
@click.option("--full", is_flag=True, help="Run full sync instead of incremental.")
def ingest(connector_type: str, full: bool):
    """Run ingestion for a specific connector type (e.g. jira, slack, google)."""
    mode = "full" if full else "incremental"
    click.echo(f"Starting {mode} ingestion for connector: {connector_type}")
    try:
        from pipeline.connectors.registry import get_connector

        connector = get_connector(connector_type)
        connector.sync(full=full)
        click.echo(f"Ingestion for '{connector_type}' completed.")
    except ImportError:
        click.echo(f"Connector '{connector_type}' is not available. Check installation.", err=True)
        raise SystemExit(1)
    except Exception as e:
        click.echo(f"Ingestion failed: {e}", err=True)
        raise SystemExit(1)


@cli.command()
def test():
    """Run health checks on all subsystems."""
    click.echo(click.style("\n  Neurostack Health Checks\n", fg="cyan", bold=True))
    checks = {
        "Configuration": _check_config,
        "Database": _check_database,
        "Vector Store": _check_vector_store,
        "LLM": _check_llm,
    }
    all_ok = True
    for name, check_fn in checks.items():
        try:
            check_fn()
            click.echo(f'  {click.style("[OK]", fg="green", bold=True)}   {name}')
        except Exception as e:
            click.echo(f'  {click.style("[FAIL]", fg="red", bold=True)} {name}: {e}')
            all_ok = False

    click.echo()
    if all_ok:
        click.echo(click.style("  All health checks passed.\n", fg="green", bold=True))
    else:
        click.echo(click.style("  Some health checks failed.\n", fg="red"))
        raise SystemExit(1)


@cli.group()
def config():
    """Configuration management commands."""
    pass


@config.command("validate")
@click.option("--path", default="neurostack.yaml", help="Path to config file.")
def config_validate(path: str):
    """Validate the neurostack.yaml configuration file."""
    click.echo(f"Validating configuration: {path}")
    try:
        from pipeline.config.loader import load_config

        cfg = load_config(path)
        click.echo(click.style("  Configuration is valid.\n", fg="green"))
        click.echo(f"  LLM provider:     {cfg.llm.provider}")
        click.echo(f"  Vector store:     {cfg.vector_store.provider}")
        click.echo(f"  Database URL set:  {'yes' if cfg.database.url else 'no'}")
        click.echo(f"  Connectors:       {len(cfg.connectors)}")
    except FileNotFoundError:
        click.echo(click.style(f"  Config file not found: {path}", fg="red"), err=True)
        raise SystemExit(1)
    except Exception as e:
        click.echo(click.style(f"  Validation failed: {e}", fg="red"), err=True)
        raise SystemExit(1)


@config.command("show")
@click.option("--path", default="neurostack.yaml", help="Path to config file.")
def config_show(path: str):
    """Show the current configuration (secrets redacted)."""
    click.echo(f"Loading configuration from: {path}\n")
    try:
        from pipeline.config.loader import load_config

        cfg = load_config(path)
        _print_config(cfg)
    except FileNotFoundError:
        click.echo(click.style(f"  Config file not found: {path}", fg="red"), err=True)
        raise SystemExit(1)
    except Exception as e:
        click.echo(click.style(f"  Failed to load config: {e}", fg="red"), err=True)
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# Docker helper (supports both `docker compose` and `docker-compose`)
# ---------------------------------------------------------------------------

def _run_docker_compose(*args):
    """Run docker compose command, trying both modern and legacy syntax."""
    # Try modern syntax first: `docker compose ...`
    try:
        result = subprocess.run(
            ["docker", "compose"] + list(args),
            capture_output=True, text=True,
        )
        if result.returncode == 0 or "not found" not in result.stderr.lower():
            return result
    except FileNotFoundError:
        pass

    # Fallback to legacy: `docker-compose ...`
    try:
        return subprocess.run(
            ["docker-compose"] + list(args),
            capture_output=True, text=True,
        )
    except FileNotFoundError:
        # Neither found
        class FakeResult:
            returncode = 1
            stderr = "Docker not found. Install Docker Desktop: https://docker.com/get-started"
        return FakeResult()


# ---------------------------------------------------------------------------
# Health-check helpers
# ---------------------------------------------------------------------------

def _check_config():
    from pipeline.config.loader import load_config

    load_config("neurostack.yaml")


def _check_database():
    from pipeline.config.loader import load_config

    cfg = load_config("neurostack.yaml")
    if not cfg.database.url:
        raise RuntimeError("database.url is not configured")


def _check_vector_store():
    from pipeline.config.loader import load_config

    cfg = load_config("neurostack.yaml")
    if not cfg.vector_store.provider:
        raise RuntimeError("vector_store.provider is not configured")


def _check_llm():
    import os
    from pipeline.config.loader import load_config

    cfg = load_config("neurostack.yaml")
    env_var = cfg.llm.api_key_env
    if env_var and not os.environ.get(env_var):
        raise RuntimeError(f"Environment variable '{env_var}' is not set")


def _print_config(cfg):
    """Pretty-print configuration with secrets redacted."""
    click.echo("llm:")
    click.echo(f"  provider:    {cfg.llm.provider}")
    click.echo(f"  model:       {cfg.llm.model}")
    click.echo(f"  api_key_env: {cfg.llm.api_key_env}")

    click.echo("vector_store:")
    click.echo(f"  provider:   {cfg.vector_store.provider}")
    click.echo(f"  host:       {cfg.vector_store.host}")
    click.echo(f"  port:       {cfg.vector_store.port}")
    click.echo(f"  collection: {cfg.vector_store.collection}")

    click.echo("database:")
    url = cfg.database.url
    if url and "@" in url:
        # Redact password in connection string
        redacted = url.split("@")[-1]
        click.echo(f"  url: ***@{redacted}")
    else:
        click.echo(f"  url: {url}")

    click.echo("connectors:")
    for c in cfg.connectors:
        click.echo(f"  - type: {c.type}, enabled: {c.enabled}")

    click.echo("sync:")
    click.echo(f"  default_interval_minutes: {cfg.sync.default_interval_minutes}")
    click.echo(f"  max_concurrent:           {cfg.sync.max_concurrent}")


# ---------------------------------------------------------------------------
# Setup wizard
# ---------------------------------------------------------------------------

@cli.command()
def setup():
    """Interactive first-run setup wizard."""
    click.echo()
    click.echo(click.style("  ================================================", fg="cyan"))
    click.echo(click.style("       Neurostack Setup Wizard  v" + VERSION, fg="cyan", bold=True))
    click.echo(click.style("  ================================================", fg="cyan"))
    click.echo()
    click.echo("  This wizard will walk you through setting up Neurostack.")
    click.echo("  Just pick the numbered options -press Enter for defaults.")

    config = {}

    # -- Step 1: LLM Provider ----------------------------------------------
    click.echo(click.style("\n  -- Step 1 of 5: Choose Your AI Provider --", fg="white", bold=True))
    click.echo(click.style("  (Pick a provider to power your AI brain)", fg="bright_black"))

    provider = _numbered_menu("FREE Providers (no cost to start)", [
        {"label": "Groq",      "value": "groq",    "hint": "Llama 3.3 70B -fastest free, 30 req/min"},
        {"label": "Gemini",    "value": "gemini",   "hint": "Google Gemini 2.0 Flash -15 req/min"},
        {"label": "NVIDIA",    "value": "nvidia",   "hint": "160+ models via NVIDIA NIM -1000 req/day"},
        {"label": "Ollama",    "value": "ollama",   "hint": "Run locally -no API key, unlimited"},
        {"label": "OpenRouter", "value": "openrouter", "hint": "200+ models -some free"},
    ], default=1)

    # If user didn't pick free, also offer paid
    if provider == "__paid__":
        pass  # handled below

    # Check if user wants paid instead
    if provider in ("groq", "gemini", "nvidia", "ollama", "openrouter"):
        if click.confirm(click.style("\n  Want to see paid providers instead?", fg="bright_black"), default=False):
            provider = _numbered_menu("PAID Providers (higher quality)", [
                {"label": "Anthropic", "value": "anthropic", "hint": "Claude Sonnet -best quality"},
                {"label": "OpenAI",    "value": "openai",    "hint": "GPT-4o"},
                {"label": "Azure",     "value": "azure",     "hint": "Azure OpenAI"},
            ], default=1)

    # Provider-specific model choices
    provider_models = {
        "groq": [
            {"label": "Llama 3.3 70B",       "value": "llama-3.3-70b-versatile",  "hint": "Best quality (default)"},
            {"label": "Llama 3.1 8B Instant", "value": "llama-3.1-8b-instant",     "hint": "Fastest responses"},
            {"label": "Mixtral 8x7B",         "value": "mixtral-8x7b-32768",       "hint": "Good for long context"},
            {"label": "Gemma 2 9B",           "value": "gemma2-9b-it",             "hint": "Google's model on Groq"},
        ],
        "gemini": [
            {"label": "Gemini 2.0 Flash",     "value": "gemini-2.0-flash",         "hint": "Fast & free (default)"},
            {"label": "Gemini 1.5 Pro",        "value": "gemini-1.5-pro",           "hint": "Best quality, slower"},
            {"label": "Gemini 1.5 Flash",      "value": "gemini-1.5-flash",         "hint": "Balanced"},
        ],
        "nvidia": [
            {"label": "Llama 3.1 70B",        "value": "meta/llama-3.1-70b-instruct",    "hint": "Best quality (default)"},
            {"label": "Llama 3.1 8B",          "value": "meta/llama-3.1-8b-instruct",     "hint": "Faster"},
            {"label": "Mistral Large 2",       "value": "mistralai/mistral-large-2-instruct", "hint": "Mistral's best"},
            {"label": "Phi-3 Medium 128K",     "value": "microsoft/phi-3-medium-128k-instruct", "hint": "Microsoft, long context"},
        ],
        "ollama": [
            {"label": "Llama 3.2 (3B)",       "value": "llama3.2",                 "hint": "Fast & lightweight (default)"},
            {"label": "Llama 3.1 (8B)",        "value": "llama3.1",                 "hint": "Better quality"},
            {"label": "Mistral (7B)",          "value": "mistral",                  "hint": "Good all-around"},
            {"label": "Phi-3 (3.8B)",          "value": "phi3",                     "hint": "Microsoft, very fast"},
            {"label": "Qwen 2.5 (7B)",         "value": "qwen2.5",                  "hint": "Alibaba"},
        ],
        "openrouter": [
            {"label": "Llama 3.3 70B (free)",  "value": "meta-llama/llama-3.3-70b-instruct:free", "hint": "Best free model (default)"},
            {"label": "Gemma 2 9B (free)",      "value": "google/gemma-2-9b-it:free",              "hint": "Google's model"},
            {"label": "Mistral 7B (free)",      "value": "mistralai/mistral-7b-instruct:free",     "hint": "Fast"},
        ],
        "anthropic": [
            {"label": "Claude Sonnet 4",       "value": "claude-sonnet-4-20250514", "hint": "Best balance (default)"},
            {"label": "Claude Haiku 3.5",      "value": "claude-haiku-4-5-20251001",  "hint": "Fastest, cheapest"},
        ],
        "openai": [
            {"label": "GPT-4o Mini",           "value": "gpt-4o-mini",              "hint": "Fast & cheap (default)"},
            {"label": "GPT-4o",                "value": "gpt-4o",                   "hint": "Best quality"},
        ],
        "azure": [
            {"label": "GPT-4o",               "value": "gpt-4o",                   "hint": "Default deployment"},
            {"label": "GPT-4o Mini",           "value": "gpt-4o-mini",              "hint": "Faster & cheaper"},
        ],
    }

    provider_env = {
        "groq": "GROQ_API_KEY",
        "gemini": "GEMINI_API_KEY",
        "nvidia": "NVIDIA_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
        "openai": "OPENAI_API_KEY",
        "azure": "AZURE_OPENAI_API_KEY",
        "openrouter": "OPENROUTER_API_KEY",
        "ollama": None,
    }

    provider_key_urls = {
        "groq": "https://console.groq.com/keys",
        "gemini": "https://aistudio.google.com/apikey",
        "nvidia": "https://build.nvidia.com",
        "anthropic": "https://console.anthropic.com/settings/keys",
        "openai": "https://platform.openai.com/api-keys",
        "azure": "https://portal.azure.com",
        "openrouter": "https://openrouter.ai/keys",
    }

    # Model selection
    models = provider_models.get(provider, [])
    if models:
        model = _numbered_menu("Choose a model", models, default=1)
    else:
        model = click.prompt("  Enter model name")

    api_key_env = provider_env.get(provider)

    if provider == "ollama":
        click.echo(click.style("\n  No API key needed -Ollama runs locally.", fg="green"))
        click.echo(f"  Make sure Ollama is running: https://ollama.com")
        click.echo(f"  Pull your model: ollama pull {model}")
    else:
        key_url = provider_key_urls.get(provider, "")
        click.echo(f"\n  Get your API key: {click.style(key_url, fg='bright_blue', underline=True)}")
        existing_key = os.environ.get(api_key_env, "")
        if existing_key:
            click.echo(click.style(f"  {api_key_env} is already set in your environment.", fg="green"))
            if not click.confirm("  Use existing key?", default=True):
                api_key = click.prompt("  Enter API key", hide_input=True)
                os.environ[api_key_env] = api_key
        else:
            api_key = click.prompt(f"  Enter your {api_key_env}", hide_input=True)
            os.environ[api_key_env] = api_key

    config["llm"] = {
        "provider": provider,
        "model": model,
        "api_key_env": api_key_env or "",
    }

    click.echo(click.style(f"\n  Provider: {provider} | Model: {model}", fg="green", bold=True))

    # -- Step 2: Database --------------------------------------------------
    click.echo(click.style("\n  -- Step 2 of 5: Database --", fg="white", bold=True))
    click.echo(click.style("  (Neurostack needs PostgreSQL to store data)", fg="bright_black"))

    db_choice = _numbered_menu("How to set up PostgreSQL?", [
        {"label": "Docker (automatic)",  "value": "docker",   "hint": "We'll start a container for you"},
        {"label": "I have my own",       "value": "existing", "hint": "Provide a connection URL"},
    ], default=1)

    if db_choice == "docker":
        click.echo("\n  Starting local PostgreSQL via Docker...")
        result = _run_docker_compose("up", "-d", "postgres")
        if result.returncode != 0:
            click.echo(click.style(f"  Docker error: {result.stderr.strip()}", fg="red"))
            click.echo(click.style("  You can start it manually later with: docker compose up -d postgres", fg="yellow"))
        else:
            click.echo(click.style("  PostgreSQL container started.", fg="green"))
        db_url = "postgresql://neurostack:neurostack@localhost:5432/neurostack"
    else:
        click.echo(click.style("\n  Example: postgresql://user:pass@localhost:5432/mydb", fg="bright_black"))
        db_url = click.prompt("  PostgreSQL connection URL")

    config["database"] = {"url": db_url}

    # -- Step 3: Vector Store ----------------------------------------------
    click.echo(click.style("\n  -- Step 3 of 5: Vector Store --", fg="white", bold=True))
    click.echo(click.style("  (Used for semantic search over your documents)", fg="bright_black"))

    vs_choice = _numbered_menu("How to set up Qdrant vector store?", [
        {"label": "Docker (automatic)",  "value": "docker",   "hint": "We'll start a container for you"},
        {"label": "I have my own",       "value": "existing", "hint": "Provide host and port"},
    ], default=1)

    if vs_choice == "docker":
        click.echo("\n  Starting local Qdrant via Docker...")
        result = _run_docker_compose("up", "-d", "qdrant")
        if result.returncode != 0:
            click.echo(click.style(f"  Docker error: {result.stderr.strip()}", fg="red"))
            click.echo(click.style("  You can start it manually later with: docker compose up -d qdrant", fg="yellow"))
        else:
            click.echo(click.style("  Qdrant container started.", fg="green"))
        vs_host = "localhost"
        vs_port = 6333
    else:
        vs_host = click.prompt("  Qdrant host", default="localhost")
        vs_port = click.prompt("  Qdrant port", default=6333, type=int)

    config["vector_store"] = {
        "provider": "qdrant",
        "host": vs_host,
        "port": vs_port,
        "collection": "neurostack",
    }

    # -- Step 4: First Data Source -----------------------------------------
    click.echo(click.style("\n  -- Step 4 of 5: Connect Your Data --", fg="white", bold=True))
    click.echo(click.style("  (Choose where to pull knowledge from)", fg="bright_black"))

    source = _numbered_menu("Choose a data source to connect", [
        {"label": "CSV File",     "value": "csv",         "hint": "Upload a local CSV file"},
        {"label": "Jira",         "value": "jira",        "hint": "Connect to Jira Cloud"},
        {"label": "Slack",        "value": "slack",       "hint": "Index Slack messages"},
        {"label": "Google Docs",  "value": "google_docs", "hint": "Index Google Drive documents"},
        {"label": "Skip for now", "value": "skip",        "hint": "Set up data sources later"},
    ], default=1)

    connector = {"type": source, "enabled": True}

    if source == "csv":
        click.echo(click.style("\n  Example: ./data/knowledge.csv", fg="bright_black"))
        csv_path = click.prompt("  Path to CSV file")
        connector["path"] = csv_path
    elif source == "jira":
        click.echo()
        connector["email"] = click.prompt("  Jira email")
        connector["api_token"] = click.prompt("  Jira API token", hide_input=True)
        click.echo(click.style("  Example: myteam.atlassian.net", fg="bright_black"))
        connector["domain"] = click.prompt("  Jira domain")
    elif source == "slack":
        click.echo()
        connector["bot_token"] = click.prompt("  Slack bot token (xoxb-...)", hide_input=True)
    elif source == "google_docs":
        click.echo(click.style("\n  Example: ./credentials/google-service-account.json", fg="bright_black"))
        connector["credentials_path"] = click.prompt("  Path to Google credentials JSON")
    elif source == "skip":
        connector = None

    if connector:
        config["connectors"] = [connector]
    else:
        config["connectors"] = []

    # -- Step 5: Save config & summary -------------------------------------
    click.echo(click.style("\n  -- Step 5 of 5: Save & Finish --", fg="white", bold=True))

    config["sync"] = {
        "default_interval_minutes": 60,
        "max_concurrent": 2,
    }

    config_path = "neurostack.yaml"
    with open(config_path, "w") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    # Summary
    click.echo(click.style("\n  ================================================", fg="green"))
    click.echo(click.style("       Setup Complete!", fg="green", bold=True))
    click.echo(click.style("  ================================================\n", fg="green"))

    click.echo(f"  Config saved to: {click.style(config_path, bold=True)}")
    click.echo()
    click.echo(click.style("  Your configuration:", fg="cyan"))
    click.echo(f"    AI Provider:   {provider} ({model})")
    click.echo(f"    Database:      {'Docker (auto)' if db_choice == 'docker' else db_url}")
    click.echo(f"    Vector Store:  {'Docker (auto)' if vs_choice == 'docker' else f'{vs_host}:{vs_port}'}")
    if connector:
        click.echo(f"    Data Source:   {source}")
    else:
        click.echo(f"    Data Source:   (none yet)")

    click.echo(click.style("\n  What to do next:", fg="cyan", bold=True))
    click.echo()
    click.echo("    1. Run database migrations:")
    click.echo(click.style("       neurostack migrate", fg="white", bold=True))
    click.echo()
    if connector:
        click.echo("    2. Ingest your data:")
        click.echo(click.style(f"       neurostack ingest {source}", fg="white", bold=True))
        click.echo()
        click.echo("    3. Start asking questions:")
    else:
        click.echo("    2. Connect a data source and ingest:")
        click.echo(click.style("       neurostack ingest csv", fg="white", bold=True))
        click.echo()
        click.echo("    3. Start asking questions:")
    click.echo(click.style("       neurostack ask", fg="white", bold=True))
    click.echo()


# ---------------------------------------------------------------------------
# Ask (query the brain)
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("question", required=False, default=None)
def ask(question: str):
    """Query the Neurostack brain.

    Pass a QUESTION argument for single-shot mode, or omit it to enter
    an interactive REPL.

    \b
    Examples:
      neurostack ask "What projects are behind schedule?"
      neurostack ask                           # interactive mode
    """
    brain = _init_brain_or_none()

    if question:
        _process_question(brain, question)
    else:
        click.echo()
        click.echo(click.style("  Neurostack Interactive Mode", fg="cyan", bold=True))
        click.echo(click.style("  ------------------------------", fg="cyan"))
        click.echo("  Type your question and press Enter.")
        click.echo(click.style("  Commands: 'exit' or 'quit' to leave, Ctrl+C to cancel\n", fg="bright_black"))
        while True:
            try:
                q = click.prompt(click.style("  ask", fg="cyan", bold=True), prompt_suffix="> ")
            except (EOFError, KeyboardInterrupt):
                click.echo(click.style("\n  Goodbye!", fg="cyan"))
                break
            if q.strip().lower() in ("exit", "quit"):
                click.echo(click.style("  Goodbye!", fg="cyan"))
                break
            if not q.strip():
                continue
            _process_question(brain, q)
            click.echo()


def _init_brain_or_none():
    """Try to initialise the Brain; return None on failure."""
    try:
        from pipeline.config.loader import load_config

        cfg = load_config("neurostack.yaml")
    except Exception:
        click.echo(click.style(
            "Warning: could not load neurostack.yaml. "
            "Run 'neurostack setup' first.",
            fg="yellow",
        ))
        return None

    try:
        from brain.factory import BrainFactory
        from brain.config.brain_config import BrainConfig

        # Build real clients from pipeline config
        llm_client = _build_llm_client(cfg)
        vector_store = _build_vector_store(cfg)
        embedding_client = _build_embedding_client(cfg)

        brain_config = BrainConfig.default()
        brain = BrainFactory.create_brain(
            llm_client=llm_client,
            vector_store=vector_store,
            embedding_client=embedding_client,
            config=brain_config,
        )
        return brain
    except Exception as exc:
        click.echo(click.style(
            f"Warning: Brain could not be initialised ({exc}). "
            "Falling back to offline mode.",
            fg="yellow",
        ))
        return None


def _build_llm_client(cfg):
    """Build an LLM client from pipeline config (import at call-time)."""
    provider = cfg.llm.provider
    api_key = os.environ.get(cfg.llm.api_key_env or "", "")
    model = cfg.llm.model

    try:
        if provider == "anthropic":
            from clients.anthropic_llm import AnthropicLLMClient
            return AnthropicLLMClient(api_key=api_key, model=model)

        if provider == "groq":
            from clients.openai_compatible_llm import create_groq_client
            return create_groq_client(api_key=api_key, model=model)

        if provider == "gemini":
            from clients.openai_compatible_llm import create_gemini_client
            return create_gemini_client(api_key=api_key, model=model)

        if provider == "nvidia":
            from clients.openai_compatible_llm import create_nvidia_client
            return create_nvidia_client(api_key=api_key, model=model)

        if provider == "ollama":
            from clients.openai_compatible_llm import create_ollama_client
            return create_ollama_client(model=model)

        if provider == "openrouter":
            from clients.openai_compatible_llm import create_openrouter_client
            return create_openrouter_client(api_key=api_key, model=model)

        if provider in ("openai", "azure_openai", "azure"):
            from clients.openai_compatible_llm import OpenAICompatibleClient
            base_url = "https://api.openai.com/v1"
            if provider in ("azure_openai", "azure"):
                base_url = os.environ.get("AZURE_OPENAI_ENDPOINT", "https://api.openai.com/v1")
            return OpenAICompatibleClient(
                api_key=api_key, base_url=base_url, model=model,
            )
    except ImportError as e:
        raise RuntimeError(
            f"Missing dependency for provider '{provider}'. "
            f"Install with: pip install neurostack-org\n  Detail: {e}"
        )

    raise RuntimeError(
        f"Unknown LLM provider '{provider}'. "
        "Supported: groq, gemini, nvidia, ollama, openrouter, anthropic, openai, azure"
    )


def _build_vector_store(cfg):
    """Build a vector-store client from pipeline config."""
    try:
        from pipeline.vectorstore.qdrant_client import QdrantVectorStore
        return QdrantVectorStore(
            host=cfg.vector_store.host,
            port=cfg.vector_store.port,
            collection=cfg.vector_store.collection,
        )
    except ImportError:
        pass

    raise RuntimeError(
        "No vector-store client available. Check that qdrant-client is installed."
    )


def _build_embedding_client(cfg):
    """Build an embedding client from pipeline config."""
    try:
        from pipeline.embedding.client import EmbeddingClientImpl
        return EmbeddingClientImpl()
    except ImportError:
        pass

    raise RuntimeError(
        "No embedding client available. Check installation."
    )


def _process_question(brain, question: str):
    """Send a question to the brain and print the result."""
    if brain is None:
        click.echo(click.style(
            "Brain is not initialised. Run 'neurostack setup' to configure.",
            fg="red",
        ))
        return

    try:
        from datetime import datetime, timezone

        raw_request = {
            "query": {"user_input": question, "query_id": "cli", "timestamp": datetime.now(timezone.utc).isoformat()},
            "context": {"tenant_id": "default", "persona": "IC", "user_id": "cli-user"},
        }
        response = brain.process(raw_request)

        # Print answer
        if response.answer:
            click.echo(click.style(response.answer.content, fg="green"))
            click.echo(click.style(
                f"  Confidence: {response.answer.confidence.value}",
                fg="yellow",
            ))
        elif response.message:
            click.echo(click.style(response.message, fg="green"))

        # Print sources
        if response.sources:
            click.echo(click.style("  Sources:", fg="cyan"))
            for src in response.sources:
                click.echo(click.style(f"    - {src.title} ({src.knowledge_type})", fg="cyan"))

        # Print warnings
        for w in response.warnings:
            click.echo(click.style(f"  Warning: {w}", fg="yellow"))

    except Exception as exc:
        click.echo(click.style(f"Error processing query: {exc}", fg="red"))


# ---------------------------------------------------------------------------
# Bot launcher
# ---------------------------------------------------------------------------

@cli.group()
def bot():
    """Bot launcher commands."""
    pass


@bot.command("slack")
def bot_slack():
    """Launch / configure the Slack bot."""
    click.echo(click.style("Slack Bot Setup", fg="cyan", bold=True))
    click.echo(
        "\nTo connect Neurostack to Slack:\n"
        "  1. Create a Slack App at https://api.slack.com/apps\n"
        "  2. Add Bot Token Scopes: chat:write, app_mentions:read, channels:history\n"
        "  3. Install the app to your workspace\n"
        "  4. Copy the Bot User OAuth Token\n"
        "  5. Set the environment variable:\n"
        "       export SLACK_BOT_TOKEN=xoxb-...\n"
        "  6. Run:  neurostack bot slack --start  (coming soon)\n"
    )


@bot.command("telegram")
def bot_telegram():
    """Launch / configure the Telegram bot."""
    click.echo(click.style("Telegram Bot Setup", fg="cyan", bold=True))
    click.echo(
        "\nTo connect Neurostack to Telegram:\n"
        "  1. Talk to @BotFather on Telegram and create a new bot\n"
        "  2. Copy the HTTP API token\n"
        "  3. Set the environment variable:\n"
        "       export TELEGRAM_BOT_TOKEN=123456:ABC-...\n"
        "  4. Run:  neurostack start telegram\n"
    )


# ---------------------------------------------------------------------------
# neurostack init (one-command setup)
# ---------------------------------------------------------------------------

@cli.command()
def init():
    """One-command setup: configure, connect data, and start your brain.

    This runs the full setup wizard and then immediately starts the brain
    so you can begin asking questions.

    \b
    Usage:
      pip install neurostack-org
      neurostack init
    """
    # Run setup first
    ctx = click.get_current_context()
    ctx.invoke(setup)

    # Load the config we just created
    try:
        cfg_path = "neurostack.yaml"
        with open(cfg_path) as f:
            cfg = yaml.safe_load(f)
    except Exception:
        click.echo(click.style("  Config saved. Run 'neurostack ask' to start querying.", fg="green"))
        return

    # Check if we have connectors to ingest
    connectors = cfg.get("connectors", [])
    if connectors:
        for conn in connectors:
            conn_type = conn.get("type", "")
            if conn_type and conn_type != "skip":
                click.echo(click.style(f"\n  Ingesting data from {conn_type}...", fg="cyan"))
                try:
                    ctx.invoke(ingest, connector_type=conn_type, full=False)
                except Exception as e:
                    click.echo(click.style(f"  Ingestion skipped: {e}", fg="yellow"))

    # Ask if user wants to deploy as a bot
    click.echo(click.style("\n  -- Deploy as Bot --", fg="white", bold=True))

    deploy = _numbered_menu("Where should the brain be accessible?", [
        {"label": "Terminal only",  "value": "terminal",  "hint": "Ask questions via 'neurostack ask'"},
        {"label": "Slack bot",      "value": "slack",     "hint": "Answers questions in your Slack workspace"},
        {"label": "Telegram bot",   "value": "telegram",  "hint": "Answers questions via Telegram"},
        {"label": "REST API",       "value": "api",       "hint": "Run as HTTP API server"},
    ], default=1)

    if deploy == "slack":
        token = os.environ.get("SLACK_BOT_TOKEN", "")
        if not token:
            click.echo(click.style("\n  Create a Slack app: https://api.slack.com/apps", fg="bright_blue"))
            click.echo("  Scopes needed: chat:write, app_mentions:read, channels:history, channels:read")
            token = click.prompt("  Enter Slack Bot Token (xoxb-...)", hide_input=True)
            os.environ["SLACK_BOT_TOKEN"] = token

        # Save to config
        cfg["bot"] = {"type": "slack", "token_env": "SLACK_BOT_TOKEN"}
        with open(cfg_path, "w") as f:
            yaml.dump(cfg, f, default_flow_style=False, sort_keys=False)

        click.echo(click.style("\n  Starting Slack bot...", fg="green"))
        ctx.invoke(start, target="slack")

    elif deploy == "telegram":
        token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
        if not token:
            click.echo(click.style("\n  Create a bot: talk to @BotFather on Telegram", fg="bright_blue"))
            token = click.prompt("  Enter Telegram Bot Token", hide_input=True)
            os.environ["TELEGRAM_BOT_TOKEN"] = token

        cfg["bot"] = {"type": "telegram", "token_env": "TELEGRAM_BOT_TOKEN"}
        with open(cfg_path, "w") as f:
            yaml.dump(cfg, f, default_flow_style=False, sort_keys=False)

        click.echo(click.style("\n  Starting Telegram bot...", fg="green"))
        ctx.invoke(start, target="telegram")

    elif deploy == "api":
        click.echo(click.style("\n  Starting API server on http://localhost:8000 ...", fg="green"))
        ctx.invoke(start, target="api")

    else:
        click.echo(click.style("\n  Setup complete! Run 'neurostack ask' to start querying.", fg="green"))
        click.echo(click.style("  Run 'neurostack start slack' later to deploy as a Slack bot.\n", fg="bright_black"))


# ---------------------------------------------------------------------------
# neurostack start (run bot or API server)
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("target", required=False, default=None)
def start(target: str):
    """Start the brain as a bot or API server.

    \b
    Targets:
      slack     - Run as a Slack bot
      telegram  - Run as a Telegram bot
      api       - Run as a REST API server (FastAPI)
      ask       - Interactive terminal mode (default)

    \b
    Examples:
      neurostack start slack
      neurostack start telegram
      neurostack start api
      neurostack start        # interactive terminal
    """
    if not target:
        # Check config for default
        try:
            with open("neurostack.yaml") as f:
                cfg = yaml.safe_load(f)
            bot_cfg = cfg.get("bot", {})
            target = bot_cfg.get("type", "ask")
        except Exception:
            target = "ask"

    if target == "ask":
        click.get_current_context().invoke(ask)
        return

    brain = _init_brain_or_none()
    if brain is None:
        click.echo(click.style("  Cannot start: brain initialization failed.", fg="red"))
        click.echo(click.style("  Run 'neurostack init' first.", fg="yellow"))
        return

    if target == "slack":
        _start_slack_bot(brain)
    elif target == "telegram":
        _start_telegram_bot(brain)
    elif target == "api":
        _start_api_server()
    else:
        click.echo(click.style(f"  Unknown target: {target}", fg="red"))
        click.echo("  Valid targets: slack, telegram, api, ask")


def _start_slack_bot(brain):
    """Start the Slack bot."""
    token = os.environ.get("SLACK_BOT_TOKEN", "")
    if not token:
        click.echo(click.style("  SLACK_BOT_TOKEN not set.", fg="red"))
        click.echo("  Set it with: export SLACK_BOT_TOKEN=xoxb-...")
        return

    try:
        from neurostack.integrations.slack.bot import SlackBot

        click.echo(click.style("  Neurostack Slack bot starting...", fg="green", bold=True))
        click.echo(click.style("  Mention @Neurostack in any channel to ask questions.", fg="bright_black"))
        click.echo(click.style("  Press Ctrl+C to stop.\n", fg="bright_black"))

        bot = SlackBot(token=token, brain=brain, tenant_id="default")
        bot.start()
    except ImportError:
        click.echo(click.style("  Slack SDK not installed.", fg="red"))
        click.echo("  Install with: pip install neurostack-org[slack]")
    except Exception as e:
        click.echo(click.style(f"  Slack bot error: {e}", fg="red"))


def _start_telegram_bot(brain):
    """Start the Telegram bot."""
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    if not token:
        click.echo(click.style("  TELEGRAM_BOT_TOKEN not set.", fg="red"))
        click.echo("  Set it with: export TELEGRAM_BOT_TOKEN=...")
        return

    try:
        from neurostack.integrations.telegram.bot import TelegramBot

        click.echo(click.style("  Neurostack Telegram bot starting...", fg="green", bold=True))
        click.echo(click.style("  Message your bot on Telegram to ask questions.", fg="bright_black"))
        click.echo(click.style("  Press Ctrl+C to stop.\n", fg="bright_black"))

        bot = TelegramBot(token=token, brain=brain, tenant_id="default")
        bot.start()
    except ImportError:
        click.echo(click.style("  Telegram SDK not installed.", fg="red"))
        click.echo("  Install with: pip install neurostack-org[telegram]")
    except Exception as e:
        click.echo(click.style(f"  Telegram bot error: {e}", fg="red"))


def _start_api_server():
    """Start the FastAPI API server."""
    try:
        import uvicorn

        click.echo(click.style("  Starting API server...", fg="green", bold=True))
        click.echo(click.style("  API docs: http://localhost:8000/docs", fg="bright_black"))
        click.echo(click.style("  Press Ctrl+C to stop.\n", fg="bright_black"))

        # Import from backend
        import sys
        backend_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), "backend")
        if os.path.exists(backend_path):
            sys.path.insert(0, backend_path)

        uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=False)
    except ImportError:
        click.echo(click.style("  uvicorn not installed.", fg="red"))
        click.echo("  Install with: pip install uvicorn")
    except Exception as e:
        click.echo(click.style(f"  API server error: {e}", fg="red"))


# ---------------------------------------------------------------------------
# neurostack connect (add data source)
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("source", required=False, default=None)
def connect(source: str):
    """Connect a new data source.

    \b
    Sources:
      csv, jira, slack, notion, confluence, github, email,
      teams, google, tally, classroom, moodle

    \b
    Examples:
      neurostack connect slack
      neurostack connect github
      neurostack connect         # interactive picker
    """
    sources = [
        {"label": "CSV / Excel",         "value": "csv",         "hint": "Upload local files"},
        {"label": "Slack",               "value": "slack",       "hint": "Index messages and threads"},
        {"label": "Jira",                "value": "jira",        "hint": "Import issues and projects"},
        {"label": "Notion",              "value": "notion",      "hint": "Sync pages and databases"},
        {"label": "GitHub",              "value": "github",      "hint": "Issues, PRs, and READMEs"},
        {"label": "Confluence",          "value": "confluence",  "hint": "Wiki pages and blog posts"},
        {"label": "Google Workspace",    "value": "google",      "hint": "Docs, Sheets, Drive"},
        {"label": "Microsoft Teams",     "value": "teams",       "hint": "Messages and channels"},
        {"label": "Email (IMAP)",        "value": "email",       "hint": "Gmail, Outlook, any IMAP"},
        {"label": "Tally",               "value": "tally",       "hint": "Accounting data (India)"},
        {"label": "Google Classroom",    "value": "classroom",   "hint": "Courses and assignments"},
        {"label": "Moodle",              "value": "moodle",      "hint": "LMS courses and forums"},
    ]

    if not source:
        source = _numbered_menu("Choose a data source to connect", sources, default=1)

    click.echo(click.style(f"\n  Connecting: {source}", fg="cyan", bold=True))

    # Source-specific configuration
    connector_config = {"type": source, "enabled": True}

    if source == "csv":
        path = click.prompt("  Path to CSV/Excel file")
        connector_config["path"] = path
    elif source == "slack":
        click.echo("  Create a Slack app: https://api.slack.com/apps")
        click.echo("  Scopes: channels:history, channels:read, users:read")
        token = click.prompt("  Slack Bot Token (xoxb-...)", hide_input=True)
        connector_config["bot_token"] = token
    elif source == "jira":
        connector_config["domain"] = click.prompt("  Jira domain (e.g., myteam.atlassian.net)")
        connector_config["email"] = click.prompt("  Jira email")
        connector_config["api_token"] = click.prompt("  Jira API token", hide_input=True)
    elif source == "notion":
        click.echo("  Create integration: https://www.notion.so/my-integrations")
        connector_config["api_key"] = click.prompt("  Notion Integration Token", hide_input=True)
    elif source == "github":
        click.echo("  Create token: https://github.com/settings/tokens")
        connector_config["token"] = click.prompt("  GitHub Personal Access Token", hide_input=True)
        connector_config["repos"] = click.prompt("  Repos to sync (comma-separated, e.g., org/repo1,org/repo2)")
    elif source == "confluence":
        connector_config["base_url"] = click.prompt("  Confluence URL (e.g., https://myteam.atlassian.net/wiki)")
        connector_config["email"] = click.prompt("  Email")
        connector_config["api_token"] = click.prompt("  API token", hide_input=True)
    elif source == "google":
        click.echo("  Set up Google Cloud credentials: https://console.cloud.google.com")
        connector_config["credentials_path"] = click.prompt("  Path to credentials JSON")
    elif source == "teams":
        click.echo("  Register Azure AD app: https://portal.azure.com")
        connector_config["client_id"] = click.prompt("  Azure Client ID")
        connector_config["client_secret"] = click.prompt("  Azure Client Secret", hide_input=True)
        connector_config["tenant_id"] = click.prompt("  Azure Tenant ID")
    elif source == "email":
        connector_config["imap_host"] = click.prompt("  IMAP host", default="imap.gmail.com")
        connector_config["email"] = click.prompt("  Email address")
        connector_config["password"] = click.prompt("  App password", hide_input=True)
    elif source == "tally":
        connector_config["export_path"] = click.prompt("  Path to Tally export folder")
    elif source == "classroom":
        connector_config["credentials_path"] = click.prompt("  Path to Google credentials JSON")
    elif source == "moodle":
        connector_config["base_url"] = click.prompt("  Moodle URL (e.g., https://moodle.school.edu)")
        connector_config["token"] = click.prompt("  Moodle Web Service Token", hide_input=True)

    # Save to config
    try:
        with open("neurostack.yaml") as f:
            cfg = yaml.safe_load(f) or {}

        if "connectors" not in cfg:
            cfg["connectors"] = []
        cfg["connectors"].append(connector_config)

        with open("neurostack.yaml", "w") as f:
            yaml.dump(cfg, f, default_flow_style=False, sort_keys=False)

        click.echo(click.style(f"\n  {source} connected and saved to neurostack.yaml", fg="green"))
        click.echo(f"  Run 'neurostack ingest {source}' to start syncing data.")
    except Exception as e:
        click.echo(click.style(f"  Error saving config: {e}", fg="red"))


# ---------------------------------------------------------------------------
# neurostack status
# ---------------------------------------------------------------------------

@cli.command()
def status():
    """Show the current system status.

    \b
    Displays:
      - Configuration status
      - Connected data sources
      - Brain status
      - Bot status
      - Knowledge stats
    """
    click.echo()
    click.echo(click.style("  Neurostack Status", fg="cyan", bold=True))
    click.echo(click.style("  " + "=" * 40, fg="cyan"))
    click.echo()

    # Config
    try:
        with open("neurostack.yaml") as f:
            cfg = yaml.safe_load(f)
        click.echo(click.style("  Configuration", fg="white", bold=True))
        llm = cfg.get("llm", {})
        click.echo(f"    LLM Provider:  {llm.get('provider', 'not set')}")
        click.echo(f"    Model:         {llm.get('model', 'not set')}")

        api_key_env = llm.get("api_key_env", "")
        if api_key_env:
            has_key = bool(os.environ.get(api_key_env))
            status_str = click.style("SET", fg="green") if has_key else click.style("NOT SET", fg="red")
            click.echo(f"    API Key:       {api_key_env} [{status_str}]")

        db = cfg.get("database", {})
        db_url = db.get("url", "")
        if db_url:
            # Redact password
            if "@" in db_url:
                click.echo(f"    Database:      ***@{db_url.split('@')[-1]}")
            else:
                click.echo(f"    Database:      {db_url}")
        else:
            click.echo(f"    Database:      {click.style('not configured', fg='yellow')}")

        vs = cfg.get("vector_store", {})
        click.echo(f"    Vector Store:  {vs.get('provider', 'not set')} ({vs.get('host', '')}:{vs.get('port', '')})")
        click.echo()

        # Connectors
        connectors = cfg.get("connectors", [])
        click.echo(click.style("  Connected Sources", fg="white", bold=True))
        if connectors:
            for c in connectors:
                c_type = c.get("type", "unknown")
                enabled = c.get("enabled", True)
                status_str = click.style("active", fg="green") if enabled else click.style("disabled", fg="yellow")
                click.echo(f"    {c_type:20s} [{status_str}]")
        else:
            click.echo(f"    {click.style('No data sources connected', fg='yellow')}")
            click.echo(f"    Run 'neurostack connect' to add one.")
        click.echo()

        # Bot
        bot_cfg = cfg.get("bot", {})
        click.echo(click.style("  Bot Status", fg="white", bold=True))
        if bot_cfg:
            bot_type = bot_cfg.get("type", "none")
            token_env = bot_cfg.get("token_env", "")
            has_token = bool(os.environ.get(token_env)) if token_env else False
            token_status = click.style("ready", fg="green") if has_token else click.style("token not set", fg="red")
            click.echo(f"    Type:   {bot_type}")
            click.echo(f"    Status: [{token_status}]")
            if not has_token and token_env:
                click.echo(f"    Set:    export {token_env}=...")
        else:
            click.echo(f"    {click.style('No bot configured', fg='bright_black')}")
            click.echo(f"    Run 'neurostack start slack' or 'neurostack start telegram'")
        click.echo()

    except FileNotFoundError:
        click.echo(click.style("  No neurostack.yaml found.", fg="red"))
        click.echo(click.style("  Run 'neurostack init' to get started.\n", fg="yellow"))
    except Exception as e:
        click.echo(click.style(f"  Error reading config: {e}", fg="red"))

    # Brain
    click.echo(click.style("  Brain", fg="white", bold=True))
    brain = _init_brain_or_none()
    if brain:
        click.echo(f"    Status: {click.style('operational', fg='green')}")
    else:
        click.echo(f"    Status: {click.style('not initialized', fg='yellow')}")
    click.echo()

    click.echo(click.style("  Quick Commands", fg="white", bold=True))
    click.echo("    neurostack ask             - Ask questions interactively")
    click.echo("    neurostack connect          - Add a data source")
    click.echo("    neurostack start slack      - Start Slack bot")
    click.echo("    neurostack start telegram   - Start Telegram bot")
    click.echo("    neurostack start api        - Start REST API server")
    click.echo()


if __name__ == "__main__":
    cli()
