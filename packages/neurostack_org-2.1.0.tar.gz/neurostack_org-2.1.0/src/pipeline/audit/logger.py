"""
Audit logging for pipeline operations.

Provides comprehensive, tamper-proof audit trail for:
- Data ingestion (what was ingested, when, by whom)
- Permission changes (who gained/lost access)
- System operations (connector runs, jobs)
- Errors and failures
- Security events

Design principles:
- Write-once (never modify audit logs)
- Structured data (JSON-friendly)
- Full context (who, what, when, why, how)
- Performance (async writes, batching)
- Compliance-ready (retention, immutability)
"""

import json
from datetime import datetime, timedelta, timezone
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from enum import Enum
import uuid
import logging

from ..storage.interfaces import MetadataStore
from ..utils.exceptions import AuditError


# ============================================================================
# AUDIT EVENT TYPES
# ============================================================================

class AuditEventType(Enum):
    """Types of audit events"""
    
    # Ingestion events
    INGESTION_STARTED = "ingestion_started"
    INGESTION_COMPLETED = "ingestion_completed"
    INGESTION_FAILED = "ingestion_failed"
    ITEM_INGESTED = "item_ingested"
    ITEM_FAILED = "item_failed"
    ITEM_SKIPPED = "item_skipped"
    
    # Permission events
    PERMISSION_CREATED = "permission_created"
    PERMISSION_UPDATED = "permission_updated"
    PERMISSION_REVOKED = "permission_revoked"
    PERMISSION_SYNC_STARTED = "permission_sync_started"
    PERMISSION_SYNC_COMPLETED = "permission_sync_completed"
    
    # Connector events
    CONNECTOR_AUTHENTICATED = "connector_authenticated"
    CONNECTOR_AUTH_FAILED = "connector_auth_failed"
    CONNECTOR_RATE_LIMITED = "connector_rate_limited"
    CONNECTOR_ERROR = "connector_error"
    
    # Storage events
    STORAGE_WRITE = "storage_write"
    STORAGE_READ = "storage_read"
    STORAGE_DELETE = "storage_delete"
    STORAGE_ERROR = "storage_error"
    
    # Job events
    JOB_CREATED = "job_created"
    JOB_STARTED = "job_started"
    JOB_COMPLETED = "job_completed"
    JOB_FAILED = "job_failed"
    JOB_CANCELLED = "job_cancelled"
    
    # System events
    PIPELINE_STARTED = "pipeline_started"
    PIPELINE_STOPPED = "pipeline_stopped"
    CONFIGURATION_CHANGED = "configuration_changed"
    
    # Security events
    ACCESS_DENIED = "access_denied"
    AUTHENTICATION_FAILED = "authentication_failed"
    SUSPICIOUS_ACTIVITY = "suspicious_activity"


class AuditSeverity(Enum):
    """Severity levels for audit events"""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


# ============================================================================
# LOGGING
# ============================================================================

logger = logging.getLogger("neurostack.pipeline.audit")


# ============================================================================
# AUDIT EVENT MODEL
# ============================================================================

@dataclass
class AuditEvent:
    """
    Single audit event.
    
    Immutable record of a pipeline operation.
    """
    event_id: str                           # Unique event ID
    event_type: AuditEventType              # Type of event
    timestamp: datetime                     # When event occurred
    
    # Context
    tenant_id: str                          # Tenant isolation
    actor: str = "system"                   # Who performed action (user_id or "system")
    severity: AuditSeverity = AuditSeverity.INFO
    
    # Event details
    resource_type: Optional[str] = None     # What was affected (e.g., "knowledge", "permission")
    resource_id: Optional[str] = None       # Specific resource ID
    
    # Additional context
    job_id: Optional[str] = None
    connector_id: Optional[str] = None
    connector_type: Optional[str] = None
    
    # Event data (flexible, JSON-serializable)
    data: Dict[str, Any] = field(default_factory=dict)
    
    # Outcome
    success: bool = True
    error_message: Optional[str] = None
    
    # Metadata
    source_ip: Optional[str] = None         # For API calls
    user_agent: Optional[str] = None        # For API calls
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to dictionary for storage/serialization.
        
        Returns:
            Dictionary representation
        """
        return {
            "event_id": self.event_id,
            "event_type": self.event_type.value,
            "timestamp": self.timestamp.isoformat(),
            "tenant_id": self.tenant_id,
            "actor": self.actor,
            "severity": self.severity.value,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "job_id": self.job_id,
            "connector_id": self.connector_id,
            "connector_type": self.connector_type,
            "data": self.data,
            "success": self.success,
            "error_message": self.error_message,
            "source_ip": self.source_ip,
            "user_agent": self.user_agent
        }
    
    def to_json(self) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict(), default=str)


# ============================================================================
# AUDIT LOGGER
# ============================================================================

class AuditLogger:
    """
    Audit logger for pipeline operations.
    
    Responsibilities:
    - Log all critical pipeline events
    - Store logs in metadata store (immutable)
    - Provide query interface for audit trail
    - Support batch logging for performance
    - Handle logging failures gracefully (never crash pipeline)
    
    Usage:
        audit_logger = AuditLogger(metadata_store)
        
        # Log single event
        audit_logger.log_ingestion(
            job_id="job_123",
            content_id="content_456",
            status="success"
        )
        
        # Log with full context
        audit_logger.log_event(
            event_type=AuditEventType.ITEM_INGESTED,
            tenant_id="company_a",
            resource_id="content_456",
            data={"source": "jira", "size": 1024}
        )
    """
    
    def __init__(
        self,
        metadata_store: MetadataStore,
        batch_size: int = 100,
        batch_interval_seconds: int = 5,
        fail_silently: bool = True  # Don't crash pipeline on audit failure
    ):
        """
        Initialize audit logger.
        
        Args:
            metadata_store: Metadata store for persistence
            batch_size: Batch events for performance (flush every N events)
            batch_interval_seconds: Max time before flushing batch
            fail_silently: If True, log audit errors but don't raise exceptions
        """
        self.metadata_store = metadata_store
        self.batch_size = batch_size
        self.batch_interval_seconds = batch_interval_seconds
        self.fail_silently = fail_silently
        
        # Batch buffer
        self._batch_buffer: List[AuditEvent] = []
        self._last_flush_time = datetime.now(timezone.utc)
        
        # Stats
        self.events_logged = 0
        self.events_failed = 0
        self.batches_flushed = 0
        
        logger.info("Initialized")
    
    # -------------------------
    # MAIN API
    # -------------------------
    
    def log_event(
        self,
        event_type: AuditEventType,
        tenant_id: str,
        actor: str = "system",
        severity: AuditSeverity = AuditSeverity.INFO,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        job_id: Optional[str] = None,
        connector_id: Optional[str] = None,
        connector_type: Optional[str] = None,
        data: Optional[Dict[str, Any]] = None,
        success: bool = True,
        error_message: Optional[str] = None,
        **kwargs
    ) -> None:
        """
        Log audit event (generic method).
        
        Args:
            event_type: Type of event
            tenant_id: Tenant identifier
            actor: Who performed action
            severity: Event severity
            resource_type: Type of resource affected
            resource_id: Specific resource ID
            job_id: Optional job ID
            connector_id: Optional connector ID
            connector_type: Optional connector type
            data: Additional event data
            success: Whether operation succeeded
            error_message: Error message if failed
            **kwargs: Additional fields (source_ip, user_agent, etc.)
        """
        event = AuditEvent(
            event_id=self._generate_event_id(),
            event_type=event_type,
            timestamp=datetime.now(timezone.utc),
            tenant_id=tenant_id,
            actor=actor,
            severity=severity,
            resource_type=resource_type,
            resource_id=resource_id,
            job_id=job_id,
            connector_id=connector_id,
            connector_type=connector_type,
            data=data or {},
            success=success,
            error_message=error_message,
            source_ip=kwargs.get("source_ip"),
            user_agent=kwargs.get("user_agent")
        )
        
        self._write_event(event)
    
    # -------------------------
    # INGESTION EVENTS
    # -------------------------
    
    def log_ingestion(
        self,
        job_id: str,
        content_id: str,
        source_type: str,
        status: str,
        tenant_id: str = "default",
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Log item ingestion.
        
        Args:
            job_id: Job identifier
            content_id: Content identifier
            source_type: Source connector type
            status: "success" | "failed" | "skipped"
            tenant_id: Tenant identifier
            metadata: Additional metadata
        """
        event_type_map = {
            "success": AuditEventType.ITEM_INGESTED,
            "failed": AuditEventType.ITEM_FAILED,
            "skipped": AuditEventType.ITEM_SKIPPED
        }
        
        self.log_event(
            event_type=event_type_map.get(status, AuditEventType.ITEM_INGESTED),
            tenant_id=tenant_id,
            resource_type="knowledge",
            resource_id=content_id,
            job_id=job_id,
            connector_type=source_type,
            data=metadata or {},
            success=(status == "success")
        )
    
    def log_job_started(
        self,
        job_id: str,
        connector_id: str,
        connector_type: str,
        tenant_id: str
    ) -> None:
        """Log ingestion job started"""
        self.log_event(
            event_type=AuditEventType.JOB_STARTED,
            tenant_id=tenant_id,
            job_id=job_id,
            connector_id=connector_id,
            connector_type=connector_type,
            data={"status": "started"}
        )
    
    def log_job_completed(
        self,
        job_id: str,
        tenant_id: str,
        items_processed: int,
        items_failed: int,
        duration_seconds: float
    ) -> None:
        """Log ingestion job completed"""
        self.log_event(
            event_type=AuditEventType.JOB_COMPLETED,
            tenant_id=tenant_id,
            job_id=job_id,
            data={
                "items_processed": items_processed,
                "items_failed": items_failed,
                "duration_seconds": duration_seconds
            }
        )
    
    def log_job_failed(
        self,
        job_id: str,
        tenant_id: str,
        error_message: str
    ) -> None:
        """Log ingestion job failed"""
        self.log_event(
            event_type=AuditEventType.JOB_FAILED,
            tenant_id=tenant_id,
            job_id=job_id,
            severity=AuditSeverity.ERROR,
            success=False,
            error_message=error_message
        )
    
    # -------------------------
    # PERMISSION EVENTS
    # -------------------------
    
    def log_permission_change(
        self,
        event_type: AuditEventType,
        content_id: str,
        tenant_id: str,
        affected_users: Optional[List[str]] = None,
        affected_teams: Optional[List[str]] = None,
        reason: str = ""
    ) -> None:
        """
        Log permission change event.
        
        Args:
            event_type: PERMISSION_CREATED | PERMISSION_UPDATED | PERMISSION_REVOKED
            content_id: Content identifier
            tenant_id: Tenant identifier
            affected_users: List of affected user IDs
            affected_teams: List of affected team IDs
            reason: Reason for change
        """
        self.log_event(
            event_type=event_type,
            tenant_id=tenant_id,
            resource_type="permission",
            resource_id=content_id,
            severity=AuditSeverity.WARNING,  # Permission changes are important
            data={
                "affected_users": affected_users or [],
                "affected_teams": affected_teams or [],
                "reason": reason
            }
        )
    
    # -------------------------
    # CONNECTOR EVENTS
    # -------------------------
    
    def log_connector_auth(
        self,
        connector_id: str,
        connector_type: str,
        tenant_id: str,
        success: bool,
        error_message: Optional[str] = None
    ) -> None:
        """Log connector authentication attempt"""
        self.log_event(
            event_type=(
                AuditEventType.CONNECTOR_AUTHENTICATED if success
                else AuditEventType.CONNECTOR_AUTH_FAILED
            ),
            tenant_id=tenant_id,
            connector_id=connector_id,
            connector_type=connector_type,
            severity=AuditSeverity.WARNING if not success else AuditSeverity.INFO,
            success=success,
            error_message=error_message
        )
    
    def log_connector_error(
        self,
        connector_id: str,
        connector_type: str,
        tenant_id: str,
        error_type: str,
        error_message: str
    ) -> None:
        """Log connector error"""
        self.log_event(
            event_type=AuditEventType.CONNECTOR_ERROR,
            tenant_id=tenant_id,
            connector_id=connector_id,
            connector_type=connector_type,
            severity=AuditSeverity.ERROR,
            success=False,
            error_message=error_message,
            data={"error_type": error_type}
        )
    
    # -------------------------
    # STORAGE EVENTS
    # -------------------------
    
    def log_storage_write(
        self,
        content_id: str,
        tenant_id: str,
        storage_type: str,
        size_bytes: Optional[int] = None
    ) -> None:
        """Log storage write operation"""
        self.log_event(
            event_type=AuditEventType.STORAGE_WRITE,
            tenant_id=tenant_id,
            resource_type="storage",
            resource_id=content_id,
            data={
                "storage_type": storage_type,
                "size_bytes": size_bytes
            }
        )
    
    def log_storage_error(
        self,
        tenant_id: str,
        storage_type: str,
        error_message: str,
        operation: str = "unknown"
    ) -> None:
        """Log storage error"""
        self.log_event(
            event_type=AuditEventType.STORAGE_ERROR,
            tenant_id=tenant_id,
            severity=AuditSeverity.ERROR,
            success=False,
            error_message=error_message,
            data={
                "storage_type": storage_type,
                "operation": operation
            }
        )
    
    # -------------------------
    # SECURITY EVENTS
    # -------------------------
    
    def log_access_denied(
        self,
        tenant_id: str,
        actor: str,
        resource_type: str,
        resource_id: str,
        reason: str
    ) -> None:
        """Log access denial (security event)"""
        self.log_event(
            event_type=AuditEventType.ACCESS_DENIED,
            tenant_id=tenant_id,
            actor=actor,
            resource_type=resource_type,
            resource_id=resource_id,
            severity=AuditSeverity.WARNING,
            success=False,
            data={"reason": reason}
        )
    
    # -------------------------
    # ERROR LOGGING
    # -------------------------
    
    def log_error(
        self,
        error_type: str,
        error_data: Dict[str, Any],
        tenant_id: str = "system",
        severity: AuditSeverity = AuditSeverity.ERROR
    ) -> None:
        """
        Log error event.
        
        Args:
            error_type: Type of error
            error_data: Error details (from exception.to_dict())
            tenant_id: Tenant identifier
            severity: Error severity
        """
        self.log_event(
            event_type=AuditEventType.CONNECTOR_ERROR,  # Generic error type
            tenant_id=tenant_id,
            severity=severity,
            success=False,
            error_message=error_data.get("message", "Unknown error"),
            data={
                "error_type": error_type,
                "error_details": error_data
            }
        )
    
    # -------------------------
    # BATCH MANAGEMENT
    # -------------------------
    
    def _write_event(self, event: AuditEvent) -> None:
        """
        Write event to storage (with batching).
        
        Args:
            event: Audit event to write
        """
        try:
            # Add to batch buffer
            self._batch_buffer.append(event)
            
            # Check if should flush
            should_flush = (
                len(self._batch_buffer) >= self.batch_size or
                (datetime.now(timezone.utc) - self._last_flush_time).total_seconds() >= self.batch_interval_seconds
            )
            
            if should_flush:
                self._flush_batch()
        
        except Exception as e:
            self.events_failed += 1
            
            if self.fail_silently:
                # Log error but don't raise (don't crash pipeline)
                logger.error(f"Failed to write event: {e}")
            else:
                raise AuditError(
                    f"Failed to write audit event: {e}",
                    event_type=event.event_type.value
                ) from e
    
    def _flush_batch(self) -> None:
        """Flush buffered events to storage"""
        if not self._batch_buffer:
            return
        
        try:
            # Write batch to metadata store
            for event in self._batch_buffer:
                self.metadata_store.log_ingestion(
                    job_id=event.job_id or "system",
                    content_id=event.resource_id or event.event_id,
                    source_type=event.connector_type or "system",
                    status="success" if event.success else "failed",
                    metadata=event.to_dict()
                )
            
            self.events_logged += len(self._batch_buffer)
            self.batches_flushed += 1
            
            # Clear buffer
            self._batch_buffer.clear()
            self._last_flush_time = datetime.now(timezone.utc)
        
        except Exception as e:
            self.events_failed += len(self._batch_buffer)
            
            if self.fail_silently:
                logger.error(f"Failed to flush batch: {e}")
                self._batch_buffer.clear()  # Clear buffer to prevent memory leak
            else:
                raise AuditError(f"Failed to flush audit batch: {e}") from e
    
    def flush(self) -> None:
        """
        Manually flush pending events.
        
        Call this before shutdown to ensure all events are written.
        """
        self._flush_batch()
    
    # -------------------------
    # QUERY INTERFACE
    # -------------------------
    
    def get_logs(
        self,
        tenant_id: Optional[str] = None,
        job_id: Optional[str] = None,
        event_type: Optional[AuditEventType] = None,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        Query audit logs.
        
        Args:
            tenant_id: Filter by tenant
            job_id: Filter by job
            event_type: Filter by event type
            since: Filter by start time
            until: Filter by end time
            limit: Maximum results
            
        Returns:
            List of audit log entries
        """
        # Flush pending events first
        self.flush()
        
        # Query metadata store
        return self.metadata_store.get_ingestion_logs(
            job_id=job_id,
            since=since,
            limit=limit
        )
    
    # -------------------------
    # UTILITIES
    # -------------------------
    
    def _generate_event_id(self) -> str:
        """Generate unique event ID"""
        return f"audit_{uuid.uuid4().hex[:16]}"
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get audit logger statistics.
        
        Returns:
            Dictionary with stats
        """
        return {
            "events_logged": self.events_logged,
            "events_failed": self.events_failed,
            "batches_flushed": self.batches_flushed,
            "pending_events": len(self._batch_buffer),
            "failure_rate": (
                self.events_failed / (self.events_logged + self.events_failed)
                if (self.events_logged + self.events_failed) > 0
                else 0
            )
        }
    
    def __del__(self):
        """Destructor - flush pending events"""
        try:
            self.flush()
        except:
            pass  # Best effort


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def create_audit_context(
    tenant_id: str,
    job_id: Optional[str] = None,
    connector_id: Optional[str] = None,
    actor: str = "system"
) -> Dict[str, str]:
    """
    Create standard audit context dictionary.
    
    Helper for passing audit context between components.
    
    Args:
        tenant_id: Tenant identifier
        job_id: Optional job ID
        connector_id: Optional connector ID
        actor: Actor performing action
        
    Returns:
        Context dictionary
    """
    context = {
        "tenant_id": tenant_id,
        "actor": actor
    }
    
    if job_id:
        context["job_id"] = job_id
    if connector_id:
        context["connector_id"] = connector_id
    
    return context