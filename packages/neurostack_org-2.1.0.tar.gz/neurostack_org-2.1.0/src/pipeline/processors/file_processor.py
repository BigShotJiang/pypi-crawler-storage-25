"""
Universal file processor for extracting text from various formats.

Supports: .txt, .md, .csv, .xlsx, .pdf, .docx, .png, .jpg (OCR)
Dependencies are lazy-imported so the SDK works without all of them installed.
"""

import os
import re
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass

logger = logging.getLogger("neurostack.pipeline.processors.file")


@dataclass
class ExtractedContent:
    """Content extracted from a file."""
    text: str
    metadata: Dict[str, Any]
    pages: int = 1  # For multi-page docs
    format: str = "text"


class FileProcessor:
    """Extract text content from various file formats."""

    SUPPORTED_FORMATS = {
        ".txt": "text",
        ".md": "markdown",
        ".csv": "csv",
        ".xlsx": "excel",
        ".xls": "excel",
        ".pdf": "pdf",
        ".docx": "word",
        ".doc": "word",
        ".png": "image",
        ".jpg": "image",
        ".jpeg": "image",
    }

    def process_file(self, file_path: str) -> ExtractedContent:
        """
        Process a file and extract text content.

        Args:
            file_path: Path to the file

        Returns:
            ExtractedContent with text and metadata

        Raises:
            ValueError: If file format not supported
            FileNotFoundError: If file doesn't exist
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        ext = path.suffix.lower()
        if ext not in self.SUPPORTED_FORMATS:
            raise ValueError(f"Unsupported format: {ext}. Supported: {list(self.SUPPORTED_FORMATS.keys())}")

        format_type = self.SUPPORTED_FORMATS[ext]
        file_size = path.stat().st_size

        if file_size > 20 * 1024 * 1024:  # 20MB limit
            raise ValueError(f"File too large: {file_size / 1024 / 1024:.1f}MB (max 20MB)")

        metadata = {
            "filename": path.name,
            "format": format_type,
            "extension": ext,
            "size_bytes": file_size,
        }

        if format_type == "text" or format_type == "markdown":
            return self._process_text(path, metadata)
        elif format_type == "csv":
            return self._process_csv(path, metadata)
        elif format_type == "excel":
            return self._process_excel(path, metadata)
        elif format_type == "pdf":
            return self._process_pdf(path, metadata)
        elif format_type == "word":
            return self._process_word(path, metadata)
        elif format_type == "image":
            return self._process_image(path, metadata)
        else:
            raise ValueError(f"No processor for format: {format_type}")

    def process_bytes(self, data: bytes, filename: str) -> ExtractedContent:
        """
        Process file from bytes (for API uploads).

        Writes to temp file, processes, then cleans up.
        """
        import tempfile
        ext = Path(filename).suffix.lower()
        with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp:
            tmp.write(data)
            tmp_path = tmp.name
        try:
            return self.process_file(tmp_path)
        finally:
            os.unlink(tmp_path)

    def _process_text(self, path: Path, metadata: dict) -> ExtractedContent:
        """Process plain text / markdown files."""
        text = path.read_text(encoding="utf-8", errors="replace")
        return ExtractedContent(text=text.strip(), metadata=metadata)

    def _process_csv(self, path: Path, metadata: dict) -> ExtractedContent:
        """Process CSV files into structured text."""
        import csv
        rows = []
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            reader = csv.reader(f)
            headers = next(reader, None)
            if headers:
                rows.append(" | ".join(headers))
                rows.append("-" * 40)
                row_count = 0
                for row in reader:
                    rows.append(" | ".join(row))
                    row_count += 1
                metadata["row_count"] = row_count
                metadata["columns"] = headers
        text = "\n".join(rows)
        return ExtractedContent(text=text, metadata=metadata)

    def _process_excel(self, path: Path, metadata: dict) -> ExtractedContent:
        """Process Excel files."""
        try:
            import openpyxl
        except ImportError:
            raise ImportError("Install openpyxl to process Excel files: pip install openpyxl")

        wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
        sheets_text = []
        total_rows = 0

        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows = []
            for row in ws.iter_rows(values_only=True):
                cells = [str(c) if c is not None else "" for c in row]
                if any(cells):  # Skip empty rows
                    rows.append(" | ".join(cells))
                    total_rows += 1
            if rows:
                sheets_text.append(f"--- Sheet: {sheet_name} ---\n" + "\n".join(rows))

        wb.close()
        metadata["sheets"] = wb.sheetnames
        metadata["total_rows"] = total_rows
        text = "\n\n".join(sheets_text)
        return ExtractedContent(text=text, metadata=metadata)

    def _process_pdf(self, path: Path, metadata: dict) -> ExtractedContent:
        """Process PDF files using PyMuPDF."""
        try:
            import fitz  # PyMuPDF
        except ImportError:
            raise ImportError("Install PyMuPDF to process PDF files: pip install PyMuPDF")

        doc = fitz.open(str(path))
        pages_text = []
        for page_num, page in enumerate(doc, 1):
            text = page.get_text("text")
            if text.strip():
                pages_text.append(f"--- Page {page_num} ---\n{text.strip()}")

        metadata["page_count"] = len(doc)
        doc.close()
        text = "\n\n".join(pages_text)
        return ExtractedContent(text=text, metadata=metadata, pages=metadata["page_count"])

    def _process_word(self, path: Path, metadata: dict) -> ExtractedContent:
        """Process Word documents."""
        try:
            from docx import Document
        except ImportError:
            raise ImportError("Install python-docx to process Word files: pip install python-docx")

        doc = Document(str(path))
        paragraphs = []
        for para in doc.paragraphs:
            if para.text.strip():
                paragraphs.append(para.text.strip())

        # Also extract tables
        for table in doc.tables:
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells]
                if any(cells):
                    paragraphs.append(" | ".join(cells))

        metadata["paragraph_count"] = len(doc.paragraphs)
        metadata["table_count"] = len(doc.tables)
        text = "\n\n".join(paragraphs)
        return ExtractedContent(text=text, metadata=metadata)

    def _process_image(self, path: Path, metadata: dict) -> ExtractedContent:
        """Process images using OCR (Tesseract)."""
        try:
            from PIL import Image
            import pytesseract
        except ImportError:
            raise ImportError("Install Pillow and pytesseract for image OCR: pip install Pillow pytesseract")

        img = Image.open(str(path))
        metadata["image_size"] = f"{img.width}x{img.height}"

        text = pytesseract.image_to_string(img)
        if not text.strip():
            text = "(No text detected in image)"
            metadata["ocr_empty"] = True

        return ExtractedContent(text=text.strip(), metadata=metadata)


# Global instance
file_processor = FileProcessor()
