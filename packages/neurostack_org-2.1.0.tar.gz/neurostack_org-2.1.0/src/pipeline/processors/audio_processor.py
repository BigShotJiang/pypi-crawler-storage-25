"""
Audio processor using OpenAI Whisper API.

Transcribes audio files (voice notes, meeting recordings, phone calls)
into text, then optionally extracts decisions and action items.

Supports: .mp3, .wav, .ogg, .m4a, .webm
Max duration: 30 minutes (Whisper API limit is ~25MB)
"""

import os
import logging
from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass

logger = logging.getLogger("neurostack.pipeline.processors.audio")


SUPPORTED_AUDIO_FORMATS = {".mp3", ".wav", ".ogg", ".m4a", ".webm", ".mp4", ".mpeg", ".mpga"}
MAX_FILE_SIZE_MB = 25  # Whisper API limit


@dataclass
class TranscriptionResult:
    """Result of audio transcription."""
    text: str
    duration_seconds: Optional[float] = None
    language: Optional[str] = None
    metadata: Dict[str, Any] = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class AudioProcessor:
    """Transcribe audio files using OpenAI Whisper API."""

    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize with OpenAI API key.

        Args:
            api_key: OpenAI API key. If None, reads from OPENAI_API_KEY env var.
        """
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not self.api_key:
            logger.warning("No OpenAI API key provided. Audio transcription will fail.")

    def transcribe_file(
        self,
        file_path: str,
        language: Optional[str] = None,
        prompt: Optional[str] = None,
    ) -> TranscriptionResult:
        """
        Transcribe an audio file using Whisper API.

        Args:
            file_path: Path to audio file
            language: Optional language hint (ISO 639-1, e.g., "en", "hi")
            prompt: Optional prompt to guide transcription

        Returns:
            TranscriptionResult with transcribed text
        """
        path = Path(file_path)

        if not path.exists():
            raise FileNotFoundError(f"Audio file not found: {file_path}")

        ext = path.suffix.lower()
        if ext not in SUPPORTED_AUDIO_FORMATS:
            raise ValueError(f"Unsupported audio format: {ext}. Supported: {SUPPORTED_AUDIO_FORMATS}")

        file_size_mb = path.stat().st_size / (1024 * 1024)
        if file_size_mb > MAX_FILE_SIZE_MB:
            raise ValueError(f"File too large: {file_size_mb:.1f}MB (max {MAX_FILE_SIZE_MB}MB)")

        if not self.api_key:
            raise RuntimeError("OpenAI API key required for audio transcription. Set OPENAI_API_KEY or pass api_key to AudioProcessor.")

        try:
            import openai
        except ImportError:
            raise ImportError("Install openai to use audio transcription: pip install openai")

        client = openai.OpenAI(api_key=self.api_key)

        logger.info(f"Transcribing: {path.name} ({file_size_mb:.1f}MB)")

        with open(file_path, "rb") as audio_file:
            kwargs = {"model": "whisper-1", "file": audio_file, "response_format": "verbose_json"}
            if language:
                kwargs["language"] = language
            if prompt:
                kwargs["prompt"] = prompt

            response = client.audio.transcriptions.create(**kwargs)

        text = response.text if hasattr(response, "text") else str(response)
        duration = getattr(response, "duration", None)
        detected_lang = getattr(response, "language", language)

        logger.info(f"Transcription complete: {len(text)} chars, {duration}s")

        return TranscriptionResult(
            text=text,
            duration_seconds=duration,
            language=detected_lang,
            metadata={
                "filename": path.name,
                "file_size_mb": round(file_size_mb, 2),
                "model": "whisper-1",
            },
        )

    def transcribe_bytes(
        self,
        data: bytes,
        filename: str,
        language: Optional[str] = None,
        prompt: Optional[str] = None,
    ) -> TranscriptionResult:
        """
        Transcribe audio from bytes (for API uploads).
        """
        import tempfile
        ext = Path(filename).suffix.lower()
        with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp:
            tmp.write(data)
            tmp_path = tmp.name
        try:
            return self.transcribe_file(tmp_path, language=language, prompt=prompt)
        finally:
            os.unlink(tmp_path)


# Global instance (lazy — only initialized when needed)
def get_audio_processor(api_key: Optional[str] = None) -> AudioProcessor:
    """Get or create audio processor instance."""
    return AudioProcessor(api_key=api_key)
