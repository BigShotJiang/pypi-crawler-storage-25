"""
Auto-classify text into knowledge types.

Uses keyword/pattern matching to determine if text represents a decision,
task, metric, event, meeting note, or general document/fact.

No ML dependencies — pure regex + keyword matching.
"""

import re
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from datetime import datetime


@dataclass
class ClassificationResult:
    """Result of text classification."""
    knowledge_type: str  # document, task, meeting, decision, metric, event, fact
    confidence: float    # 0.0 to 1.0
    extracted_entities: Dict[str, any]  # dates, people, teams, etc.
    reason: str          # Why this classification


class TextClassifier:
    """Classify text into knowledge types using pattern matching."""

    # Pattern definitions: (regex, weight)
    DECISION_PATTERNS = [
        (r"\b(?:decided|agreed|approved|concluded|resolved)\s+(?:to|that)\b", 1.0),
        (r"\bdecision\s*:\s*", 1.0),
        (r"\b(?:we(?:'ll| will)|let(?:'s))\s+(?:go with|proceed with|move forward with)\b", 0.9),
        (r"\bapproved\b", 0.7),
        (r"\bfinalized\b", 0.8),
        (r"\bsigned off\b", 0.8),
    ]

    TASK_PATTERNS = [
        (r"\b(?:todo|to-do|action item|task)\s*:", 1.0),
        (r"\b(?:assign(?:ed)?|delegate(?:d)?)\s+to\b", 0.9),
        (r"\b(?:will|should|needs? to|must|has to)\s+(?:complete|finish|do|implement|fix|update|create|build|write|prepare|review|submit)\b", 0.8),
        (r"\bdeadline\s*:", 0.8),
        (r"\bdue\s+(?:by|on|date)\b", 0.7),
        (r"\b(?:blocked|blocking|dependency)\b", 0.6),
    ]

    METRIC_PATTERNS = [
        (r"\b\d+\.?\d*\s*%", 0.7),
        (r"\b(?:KPI|metric|velocity|throughput|rate|score|ratio)\b", 0.9),
        (r"\b(?:increased|decreased|grew|dropped|improved|declined)\s+(?:by|to)\s+\d", 0.8),
        (r"\b(?:revenue|cost|budget|spend|profit|margin|MRR|ARR|churn)\b", 0.8),
        (r"\$\s*[\d,]+", 0.7),
        (r"\b(?:Rs|INR|USD)\s*\.?\s*[\d,]+", 0.7),
    ]

    EVENT_PATTERNS = [
        (r"\b(?:incident|outage|downtime|alert|escalation|crashed|crash|failure|restored)\b", 0.9),
        (r"\b(?:deployed|released|launched|shipped|went live|rolled back)\b", 0.8),
        (r"\b(?:hired|fired|resigned|joined|left)\b", 0.7),
        (r"\b(?:merged|acquired|partnership|contract signed)\b", 0.8),
        (r"\b(?:emergency|urgent|critical|P0|P1|sev1|sev2)\b", 0.7),
    ]

    MEETING_PATTERNS = [
        (r"\bmeeting\s+(?:notes|minutes|summary|recap)\b", 1.0),
        (r"\b(?:attendees|participants|present)\s*:", 0.9),
        (r"\bagenda\s*:", 0.8),
        (r"\b(?:standup|retro|retrospective|sprint review|planning|sync|1:1|one-on-one)\b", 0.7),
        (r"\bnext steps\s*:", 0.8),
    ]

    # Entity extraction patterns
    DATE_PATTERN = re.compile(
        r"\b(?:\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}[/-]\d{1,2}[/-]\d{1,2}|"
        r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2}(?:,?\s+\d{4})?|"
        r"(?:today|tomorrow|yesterday|next week|last week|this week|next month|last month))\b",
        re.IGNORECASE,
    )

    PERSON_PATTERN = re.compile(
        r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s+(?:will|should|to|from|by)\b"
    )

    EMAIL_PATTERN = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b")

    TEAM_PATTERN = re.compile(
        r"\b(?:engineering|product|design|sales|marketing|HR|finance|ops|operations|"
        r"backend|frontend|infra|platform|data|QA|DevOps|support|legal|security)\s*team\b",
        re.IGNORECASE,
    )

    def classify(self, text: str) -> ClassificationResult:
        """
        Classify text into a knowledge type.

        Args:
            text: Plain text to classify

        Returns:
            ClassificationResult with type, confidence, and extracted entities
        """
        if not text or len(text.strip()) < 5:
            return ClassificationResult(
                knowledge_type="fact",
                confidence=0.1,
                extracted_entities={},
                reason="Text too short to classify",
            )

        # Score each type
        scores = {
            "decision": self._score_patterns(text, self.DECISION_PATTERNS),
            "task": self._score_patterns(text, self.TASK_PATTERNS),
            "metric": self._score_patterns(text, self.METRIC_PATTERNS),
            "event": self._score_patterns(text, self.EVENT_PATTERNS),
            "meeting": self._score_patterns(text, self.MEETING_PATTERNS),
        }

        # Find best match
        best_type = max(scores, key=scores.get)
        best_score = scores[best_type]

        # If no patterns match well, default to document (long text) or fact (short)
        if best_score < 0.3:
            if len(text) > 500:
                best_type = "document"
                best_score = 0.5
                reason = "Long text without specific patterns, classified as document"
            else:
                best_type = "fact"
                best_score = 0.4
                reason = "Short text without specific patterns, classified as fact"
        else:
            reason = f"Matched {best_type} patterns with score {best_score:.2f}"

        # Extract entities
        entities = self._extract_entities(text)

        return ClassificationResult(
            knowledge_type=best_type,
            confidence=min(best_score, 1.0),
            extracted_entities=entities,
            reason=reason,
        )

    def _score_patterns(self, text: str, patterns: list) -> float:
        """Score text against a list of patterns."""
        total_score = 0.0
        matches = 0
        for pattern_str, weight in patterns:
            if re.search(pattern_str, text, re.IGNORECASE):
                total_score += weight
                matches += 1
        if matches == 0:
            return 0.0
        # Normalize: average score, capped at 1.0
        return min(total_score / max(matches, 1), 1.0)

    def _extract_entities(self, text: str) -> Dict[str, any]:
        """Extract entities from text."""
        entities = {}

        dates = self.DATE_PATTERN.findall(text)
        if dates:
            entities["dates"] = dates[:5]

        people = self.PERSON_PATTERN.findall(text)
        if people:
            entities["people"] = list(set(people))[:10]

        emails = self.EMAIL_PATTERN.findall(text)
        if emails:
            entities["emails"] = list(set(emails))[:10]

        teams = self.TEAM_PATTERN.findall(text)
        if teams:
            entities["teams"] = list(set(t.lower() for t in teams))[:5]

        return entities


# Global instance
text_classifier = TextClassifier()
