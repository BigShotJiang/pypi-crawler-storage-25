"""
Abstract embedding client interface.
"""

from typing import Protocol, List


class EmbeddingClient(Protocol):
    """
    Abstract interface for embedding clients.
    """
    
    def embed(self, text: str) -> List[float]:
        """
        Generate embedding vector for text.
        
        Args:
            text: Input text
        
        Returns:
            Embedding vector (typically 768 or 1536 dimensions)
        
        Raises:
            Exception if embedding fails
        """
        ...
    
    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple texts (batch).
        
        Args:
            texts: List of input texts
        
        Returns:
            List of embedding vectors
        """
        ...