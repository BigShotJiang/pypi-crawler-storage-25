"""
Validation utilities.

Pure functions for schema and data validation.
"""

from typing import Any, Dict, List, Optional
from datetime import datetime, timezone


class ValidationError(Exception):
    """Raised when validation fails"""
    pass


def validate_required_fields(data: dict, required: List[str]) -> None:
    """
    Validate that required fields are present.
    
    Args:
        data: Data dictionary
        required: List of required field names
    
    Raises:
        ValidationError if any required field is missing
    """
    missing = [field for field in required if field not in data]
    if missing:
        raise ValidationError(f"Missing required fields: {', '.join(missing)}")


def validate_timestamp(value: Any) -> datetime:
    """
    Validate and normalize timestamp.
    
    Args:
        value: Timestamp value (string ISO 8601 or datetime)
    
    Returns:
        Normalized datetime object
    
    Raises:
        ValidationError if timestamp is invalid
    """
    if isinstance(value, datetime):
        return value
    
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace('Z', '+00:00'))
        except ValueError as e:
            raise ValidationError(f"Invalid timestamp format: {value}") from e
    
    raise ValidationError(f"Timestamp must be string or datetime, got {type(value)}")


def validate_enum_value(value: str, enum_class) -> Any:
    """
    Validate enum value.
    
    Args:
        value: String value
        enum_class: Enum class to validate against
    
    Returns:
        Enum member
    
    Raises:
        ValidationError if value is not valid enum member
    """
    try:
        return enum_class(value)
    except ValueError:
        valid_values = [e.value for e in enum_class]
        raise ValidationError(
            f"Invalid {enum_class.__name__} value: {value}. "
            f"Valid values: {', '.join(valid_values)}"
        )


def validate_confidence_score(score: float) -> None:
    """
    Validate confidence score is in valid range.
    
    Args:
        score: Confidence score
    
    Raises:
        ValidationError if score is out of range [0.0, 1.0]
    """
    if not isinstance(score, (int, float)):
        raise ValidationError(f"Confidence score must be numeric, got {type(score)}")
    
    if not 0.0 <= score <= 1.0:
        raise ValidationError(f"Confidence score must be in [0.0, 1.0], got {score}")


def validate_top_k(top_k: int, max_allowed: int) -> int:
    """
    Validate and clamp top_k value.
    
    Args:
        top_k: Requested top_k
        max_allowed: Maximum allowed value
    
    Returns:
        Clamped top_k value
    
    Raises:
        ValidationError if top_k is invalid
    """
    if not isinstance(top_k, int):
        raise ValidationError(f"top_k must be integer, got {type(top_k)}")
    
    if top_k < 1:
        raise ValidationError(f"top_k must be >= 1, got {top_k}")
    
    # Clamp to max
    return min(top_k, max_allowed)


def normalize_conversation_history(
    history: List[Dict[str, Any]],
    max_turns: int
) -> List:
    """
    Normalize and truncate conversation history.
    
    Args:
        history: Raw conversation history
        max_turns: Maximum number of turns to keep
    
    Returns:
        Normalized and truncated history (most recent N turns)
    """
    from ..models.request import Message
    
    normalized = []
    
    for msg in history:
        # Validate required fields
        if 'role' not in msg or 'content' not in msg:
            continue  # Skip invalid messages
        
        # Validate role
        if msg['role'] not in ['user', 'assistant']:
            continue
        
        # Parse timestamp
        timestamp = msg.get('timestamp')
        if timestamp:
            try:
                timestamp = validate_timestamp(timestamp)
            except ValidationError:
                timestamp = datetime.now(timezone.utc)
        else:
            timestamp = datetime.now(timezone.utc)
        
        normalized.append(Message(
            role=msg['role'],
            content=msg['content'],
            timestamp=timestamp
        ))
    
    # Keep only last N turns
    return normalized[-max_turns:]