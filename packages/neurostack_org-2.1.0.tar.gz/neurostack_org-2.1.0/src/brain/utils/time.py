"""
Time-aware reasoning utilities.

Pure functions for recency scoring and staleness detection.
"""

from datetime import datetime, timedelta, timezone
import math
from typing import Dict

from neurostack.models import KnowledgeType


def calculate_recency_score(
    timestamp: datetime,
    knowledge_type: KnowledgeType,
    decay_rates: Dict[KnowledgeType, float]
) -> float:
    """
    Calculate recency score (0.0 to 1.0).
    
    Uses exponential decay based on age and knowledge type.
    
    Args:
        timestamp: When knowledge was created
        knowledge_type: Type of knowledge
        decay_rates: Decay rate per knowledge type (days^-1)
    
    Returns:
        Recency score between 0.0 (very old) and 1.0 (current)
    """
    now = datetime.now(timezone.utc)
    age_days = (now - timestamp).days
    
    # Get decay rate for this knowledge type
    decay_rate = decay_rates.get(knowledge_type, 0.01)  # Default slow decay
    
    # Exponential decay: score = e^(-rate * age)
    score = math.exp(-decay_rate * age_days)
    
    return max(0.0, min(1.0, score))


def is_stale(
    timestamp: datetime,
    knowledge_type: KnowledgeType,
    staleness_thresholds: Dict[KnowledgeType, timedelta]
) -> bool:
    """
    Check if knowledge is stale (outdated).
    
    Thresholds are configurable per knowledge type.
    
    Args:
        timestamp: When knowledge was created
        knowledge_type: Type of knowledge
        staleness_thresholds: Staleness threshold per type
    
    Returns:
        True if knowledge is stale, False otherwise
    """
    now = datetime.now(timezone.utc)
    age = now - timestamp
    
    # Get threshold for this knowledge type
    threshold = staleness_thresholds.get(
        knowledge_type,
        timedelta(days=180)  # Default 6 months
    )
    
    return age > threshold


def get_default_decay_rates() -> Dict[KnowledgeType, float]:
    """
    Default decay rates for knowledge types.
    
    Higher rate = faster decay (less relevant over time).
    Rate is in days^-1.
    
    Returns:
        Dictionary mapping knowledge type to decay rate
    """
    return {
        KnowledgeType.METRIC: 0.1,      # Metrics stale quickly (10 days half-life)
        KnowledgeType.EVENT: 0.05,       # Events moderately fast (20 days)
        KnowledgeType.MEETING: 0.02,     # Meetings decay slowly (50 days)
        KnowledgeType.TASK: 0.03,        # Tasks moderate decay (33 days)
        KnowledgeType.DECISION: 0.01,    # Decisions decay very slowly (100 days)
        KnowledgeType.DOCUMENT: 0.005,   # Documents very stable (200 days)
        KnowledgeType.FACT: 0.002,       # Facts extremely stable (500 days)
    }


def get_default_staleness_thresholds() -> Dict[KnowledgeType, timedelta]:
    """
    Default staleness thresholds for knowledge types.
    
    After this age, knowledge is flagged as "stale".
    
    Returns:
        Dictionary mapping knowledge type to staleness threshold
    """
    return {
        KnowledgeType.METRIC: timedelta(days=30),      # 1 month
        KnowledgeType.EVENT: timedelta(days=60),       # 2 months
        KnowledgeType.MEETING: timedelta(days=90),     # 3 months
        KnowledgeType.TASK: timedelta(days=90),        # 3 months
        KnowledgeType.DECISION: timedelta(days=180),   # 6 months
        KnowledgeType.DOCUMENT: timedelta(days=365),   # 1 year
        KnowledgeType.FACT: timedelta(days=730),       # 2 years
    }


def format_age_human_readable(timestamp: datetime) -> str:
    """
    Format age as human-readable string.
    
    Examples: "2 hours ago", "3 days ago", "5 months ago"
    
    Args:
        timestamp: Timestamp to format
    
    Returns:
        Human-readable age string
    """
    now = datetime.now(timezone.utc)
    delta = now - timestamp
    
    seconds = delta.total_seconds()
    
    if seconds < 60:
        return "just now"
    elif seconds < 3600:
        minutes = int(seconds / 60)
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    elif seconds < 86400:
        hours = int(seconds / 3600)
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    elif seconds < 2592000:  # 30 days
        days = int(seconds / 86400)
        return f"{days} day{'s' if days != 1 else ''} ago"
    elif seconds < 31536000:  # 365 days
        months = int(seconds / 2592000)
        return f"{months} month{'s' if months != 1 else ''} ago"
    else:
        years = int(seconds / 31536000)
        return f"{years} year{'s' if years != 1 else ''} ago"