"""
Confidence assessment utilities.

Pure functions for evaluating confidence levels.
"""

from typing import List, Optional

from ..models.confidence import RetrievalConfidence, AnswerConfidence
from neurostack.models import Authority
from ..models.retrieval import RankedSource


def assess_retrieval_confidence(
    results: List[RankedSource],
    strong_threshold: float,
    acceptable_threshold: float,
    dominance_gap: float
) -> RetrievalConfidence:
    """
    Assess retrieval confidence based on score distribution.
    
    Uses relative scoring (gap between top results), not absolute thresholds.
    
    Args:
        results: Retrieved and ranked sources
        strong_threshold: Minimum score for strong match
        acceptable_threshold: Minimum score for acceptable match
        dominance_gap: Minimum gap between top and second result
    
    Returns:
        Retrieval confidence level
    """
    if len(results) == 0:
        return RetrievalConfidence.LOW
    
    top_score = results[0].score
    second_score = results[1].score if len(results) > 1 else 0.0
    
    gap = top_score - second_score
    
    # High: top result is strong AND clearly dominates
    if top_score > strong_threshold and gap > dominance_gap:
        return RetrievalConfidence.HIGH
    
    # Medium: top result is acceptable
    elif top_score > acceptable_threshold:
        return RetrievalConfidence.MEDIUM
    
    # Low: all results are weak
    else:
        return RetrievalConfidence.LOW


def assess_answer_confidence(
    retrieval_confidence: RetrievalConfidence,
    sources_authority: List[Authority],
    has_conflicts: bool,
    has_stale_data: bool
) -> AnswerConfidence:
    """
    Assess answer confidence based on multiple factors.
    
    Decision matrix:
    - High retrieval confidence + high authority + no conflicts → Certain
    - High retrieval confidence + medium authority + no conflicts → Likely
    - Medium retrieval confidence → Likely
    - Any conflicts → Uncertain (capped)
    - Low retrieval confidence → Uncertain
    - No sources → Unknown
    
    Args:
        retrieval_confidence: Confidence in retrieval quality
        sources_authority: Authority levels of all sources used
        has_conflicts: Whether conflicting sources were detected
        has_stale_data: Whether sources contain stale data
    
    Returns:
        Answer confidence level
    """
    # No sources → cannot answer
    if len(sources_authority) == 0:
        return AnswerConfidence.UNKNOWN
    
    # Conflicts always cap at Uncertain
    if has_conflicts:
        return AnswerConfidence.UNCERTAIN
    
    # Low retrieval confidence → Uncertain
    if retrieval_confidence == RetrievalConfidence.LOW:
        return AnswerConfidence.UNCERTAIN
    
    # Check authority levels
    has_high_authority = Authority.HIGH in sources_authority
    has_only_low_authority = all(a == Authority.LOW for a in sources_authority)
    
    # High retrieval + high authority + no conflicts → Certain
    if (retrieval_confidence == RetrievalConfidence.HIGH and 
        has_high_authority and 
        not has_stale_data):
        return AnswerConfidence.CERTAIN
    
    # Multiple low-authority sources cap at Likely (never Certain)
    if has_only_low_authority:
        return AnswerConfidence.LIKELY
    
    # High retrieval + medium/low authority → Likely
    if retrieval_confidence == RetrievalConfidence.HIGH:
        return AnswerConfidence.LIKELY
    
    # Medium retrieval → Likely (default safe answer)
    if retrieval_confidence == RetrievalConfidence.MEDIUM:
        return AnswerConfidence.LIKELY
    
    # Fallback to Uncertain
    return AnswerConfidence.UNCERTAIN


def can_upgrade_confidence(
    current_confidence: AnswerConfidence,
    max_upgrade_levels: int
) -> bool:
    """
    Check if confidence can be upgraded by user clarification.
    
    Rules:
    - Can only upgrade one level (configurable)
    - Cannot upgrade from Unknown
    - Must be supported by sources
    
    Args:
        current_confidence: Current confidence level
        max_upgrade_levels: Maximum levels to upgrade
    
    Returns:
        True if upgrade is allowed
    """
    if current_confidence == AnswerConfidence.UNKNOWN:
        return False
    
    if max_upgrade_levels == 0:
        return False
    
    return True


def upgrade_confidence(
    current_confidence: AnswerConfidence,
    levels: int = 1
) -> AnswerConfidence:
    """
    Upgrade confidence by N levels.
    
    Args:
        current_confidence: Current confidence level
        levels: Number of levels to upgrade
    
    Returns:
        Upgraded confidence level
    """
    # Define upgrade ladder
    ladder = [
        AnswerConfidence.UNKNOWN,
        AnswerConfidence.UNCERTAIN,
        AnswerConfidence.LIKELY,
        AnswerConfidence.CERTAIN
    ]
    
    try:
        current_index = ladder.index(current_confidence)
        new_index = min(current_index + levels, len(ladder) - 1)
        return ladder[new_index]
    except ValueError:
        return current_confidence


def calculate_action_confidence(
    entity_match_score: float,
    parameters_complete: bool,
    query_ambiguity: float  # 0.0 = clear, 1.0 = very ambiguous
) -> float:
    """
    Calculate action confidence (0.0 to 1.0).
    
    Factors:
    - Entity matching quality (e.g., "TASK-421" vs "that task")
    - Parameter completeness (all required params present?)
    - Query ambiguity (how clear was the user's intent?)
    
    Args:
        entity_match_score: Score for entity matching (0.0 to 1.0)
        parameters_complete: Whether all required params are present
        query_ambiguity: Ambiguity score (0.0 = clear, 1.0 = ambiguous)
    
    Returns:
        Action confidence score (0.0 to 1.0)
    """
    # Start with entity match score
    confidence = entity_match_score
    
    # Penalize if parameters incomplete
    if not parameters_complete:
        confidence *= 0.7
    
    # Penalize for ambiguity
    confidence *= (1.0 - query_ambiguity * 0.5)
    
    return max(0.0, min(1.0, confidence))