"""
Brain factory for production-ready initialization.

Handles dependency injection and component wiring.
"""

from typing import Optional
import logging

from .core import (
    InputValidator,
    IntentClassifier,
    KnowledgeRetriever,
    ReasoningEngine,
    ResponseFormatter,
    BrainOrchestrator
)
from .config.brain_config import BrainConfig
from .interfaces.llm import LLMClient
from .interfaces.embedding import EmbeddingClient
from .interfaces.vector_store import VectorStoreClient
from .logging.logger import get_logger, configure_logger


class BrainFactory:
    """
    Factory for creating properly wired Brain instances.
    
    Handles all dependency injection and validation.
    """
    
    @staticmethod
    def create_brain(
        llm_client: LLMClient,
        vector_store: VectorStoreClient,
        embedding_client: EmbeddingClient,
        config: Optional[BrainConfig] = None,
        log_level: int = logging.INFO
    ) -> BrainOrchestrator:
        """
        Create a fully wired Brain orchestrator.
        
        Args:
            llm_client: LLM client implementation
            vector_store: Vector store client implementation
            embedding_client: Embedding client implementation
            config: Brain configuration (uses defaults if None)
            log_level: Logging level
        
        Returns:
            Configured BrainOrchestrator ready for use
        
        Raises:
            ValueError: If configuration is invalid
        """
        # Configure logging
        configure_logger(log_level)
        logger = get_logger()
        
        logger.info("Initializing Neurostack Brain")
        
        # Use default config if none provided
        if config is None:
            config = BrainConfig.default()
            logger.info("Using default configuration")
        
        # Validate configuration
        BrainFactory._validate_config(config)
        
        # Create components in dependency order
        logger.debug("Creating InputValidator")
        input_validator = InputValidator(
            max_history_turns=config.conversation.max_history_turns
        )
        
        logger.debug("Creating IntentClassifier")
        intent_classifier = IntentClassifier(
            llm_client=llm_client,
            persona_config=config.persona
        )
        
        logger.debug("Creating KnowledgeRetriever")
        knowledge_retriever = KnowledgeRetriever(
            vector_store=vector_store,
            embedding_client=embedding_client,
            config=config.retrieval
        )
        
        logger.debug("Creating ReasoningEngine")
        reasoning_engine = ReasoningEngine(
            llm_client=llm_client,
            max_tokens=config.llm.max_tokens,
            temperature=config.llm.temperature
        )
        
        logger.debug("Creating ResponseFormatter")
        response_formatter = ResponseFormatter()
        
        # Create orchestrator
        logger.debug("Creating BrainOrchestrator")
        orchestrator = BrainOrchestrator(
            input_validator=input_validator,
            intent_classifier=intent_classifier,
            knowledge_retriever=knowledge_retriever,
            reasoning_engine=reasoning_engine,
            response_formatter=response_formatter
        )
        
        logger.info(
            "Brain initialized successfully",
            context={
                "config": type(config).__name__
            }
        )
        
        return orchestrator
    
    @staticmethod
    def _validate_config(config: BrainConfig) -> None:
        """
        Validate configuration.
        
        Args:
            config: Brain configuration
        
        Raises:
            ValueError: If configuration is invalid
        """
        # Validate LLM settings
        if config.llm.max_tokens < 100:
            raise ValueError("llm.max_tokens must be at least 100")
        
        if not 0.0 <= config.llm.temperature <= 1.0:
            raise ValueError("llm.temperature must be between 0.0 and 1.0")
        
        # Validate retrieval settings
        if config.retrieval.default_top_k < 1:
            raise ValueError("retrieval.default_top_k must be at least 1")
        
        if config.retrieval.max_top_k < config.retrieval.default_top_k:
            raise ValueError("retrieval.max_top_k must be >= default_top_k")
        
        # Validate confidence thresholds
        if not 0.0 <= config.retrieval.strong_threshold <= 1.0:
            raise ValueError("retrieval.strong_threshold must be between 0.0 and 1.0")
        
        if config.retrieval.acceptable_threshold >= config.retrieval.strong_threshold:
            raise ValueError("retrieval.acceptable_threshold must be < strong_threshold")
        
        # All validations passed
        get_logger().debug("Configuration validated successfully")