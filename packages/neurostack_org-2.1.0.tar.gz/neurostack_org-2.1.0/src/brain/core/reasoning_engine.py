"""
Reasoning engine component (Stage 4).

Generates answers and actions based on retrieved knowledge.
"""

import json
from typing import Dict, List, Optional

from ..models.request import ValidatedInput
from ..models.intent import Intent, IntentClassification
from ..models.retrieval import RetrievalResult
from ..models.response import Answer, Action, ReasoningResult
from ..models.persona import Persona
from ..models.confidence import AnswerConfidence, RetrievalConfidence
from ..interfaces.llm import LLMClient, LLMMessage, LLMResponse
from ..prompts.base import build_system_prompt, build_user_prompt
from ..prompts.reasoning import get_intent_instructions
from ..utils.confidence import assess_answer_confidence
from ..logging.logger import get_logger


class ReasoningEngine:
    """
    Generates answers/actions via LLM reasoning.
    
    This is the core intelligence component.
    """
    
    def __init__(
        self,
        llm_client: LLMClient,
        max_tokens: int = 1000,
        temperature: float = 0.0
    ):
        """
        Initialize reasoning engine.
        
        Args:
            llm_client: LLM client for reasoning
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0.0 = deterministic)
        """
        self.llm_client = llm_client
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.logger = get_logger()
    
    def reason(
        self,
        validated_input: ValidatedInput,
        intent_classification: IntentClassification,
        retrieval_result: RetrievalResult,
        persona: Persona
    ) -> ReasoningResult:
        """
        Generate answer or action based on retrieved knowledge.
        
        Args:
            validated_input: Validated input
            intent_classification: Intent classification result
            retrieval_result: Retrieved knowledge
            persona: User persona
        
        Returns:
            ReasoningResult with answer/action, confidence, sources
        """
        self.logger.debug(
            "Starting reasoning",
            context={
                "query_id": validated_input.query_id,
                "intent": intent_classification.intent.value
            }
        )
        
        if "long_query" in validated_input.validation_flags:
            self.logger.info(
                "Handling long query",
                context={"query_id": validated_input.query_id}
    )

        # Step 1: Build reasoning prompt
        system_prompt = self._build_system_prompt(
            persona,
            intent_classification.intent
        )
        
        user_prompt = self._build_user_prompt(
            validated_input,
            retrieval_result
        )
        if "long_query" in validated_input.validation_flags:
            user_prompt = (
                "NOTE: The user's query is very long. "
                "Provide a concise, partial answer and explain any uncertainty.\n\n"
                + user_prompt
            )
        
        # Step 2: Call LLM for reasoning
        try:
            response = self.llm_client.complete(
                messages=[
                    LLMMessage(role="system", content=system_prompt),
                    LLMMessage(role="user", content=user_prompt)
                ],
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            if not response:
                raise ValueError("LLM returned empty response")
            
            # Step 3: Parse response based on intent
            if intent_classification.intent == Intent.TASK_ACTION:
                result = self._parse_action_response(response, retrieval_result)
            else:
                result = self._parse_answer_response(
                    response,
                    retrieval_result,
                    intent_classification.intent,
                    validated_input
                )
           
            
            self.logger.info(
                "Reasoning complete",
                context={
                    "query_id": validated_input.query_id,
                    "confidence": result.answer.confidence.value if result.answer else "N/A"
                }
            )
            
            return result
        
        except Exception as e:
            self.logger.error(
                "Reasoning failed",
                context={"query_id": validated_input.query_id},
                exc_info=True
            )
            # Return error result
            return self._error_result(str(e))
    
    def _build_system_prompt(self, persona: Persona, intent: Intent) -> str:
        """Build system prompt for reasoning"""
        intent_instructions = get_intent_instructions(intent)
        return build_system_prompt(persona, intent, intent_instructions)
    
    def _build_user_prompt(
        self,
        validated_input: ValidatedInput,
        retrieval_result: RetrievalResult
    ) -> str:
        """Build user prompt with query and context"""
        
        # Format retrieved sources
        sources_text = self._format_sources(retrieval_result.retrieved_knowledge)
        
        # Format live context
        live_context_text = self._format_live_context(retrieval_result.live_data)
        
        # Format conversation history
        history_text = self._format_conversation_history(
            validated_input.conversation_history
        )
        
        return build_user_prompt(
            query=validated_input.query,
            sources=sources_text,
            live_context=live_context_text,
            conversation_history=history_text
        )
    
    def _format_sources(self, sources: List) -> str:
        """Format retrieved sources as text"""
        if not sources:
            return "No retrieved sources available."
        
        lines = []
        for i, rs in enumerate(sources, 1):
            source = rs.source
            lines.append(f"[Source {i}] (ID: {source.id})")
            lines.append(f"Type: {source.type.value}")
            lines.append(f"Authority: {source.metadata.authority.value}")
            lines.append(f"Date: {source.metadata.timestamp.strftime('%Y-%m-%d')}")
            lines.append(f"Content: {source.content[:500]}...")  # Truncate long content
            lines.append("")
        
        return "\n".join(lines)
    
    def _format_live_context(self, live_data: Optional[Dict]) -> str:
        """Format live context as text"""
        if not live_data:
            return ""
        
        # Simple JSON formatting
        return f"Live Context:\n{json.dumps(live_data, indent=2)}"
    
    def _format_conversation_history(self, history: List) -> str:
        """Format conversation history as text"""
        if not history:
            return ""
        
        lines = []
        for msg in history[-3:]:  # Last 3 turns
            role = msg.role.upper()
            lines.append(f"{role}: {msg.content}")
        
        return "\n".join(lines)
    
    def _parse_answer_response(
        self,
        response: LLMResponse,
        retrieval_result: RetrievalResult,
        intent: Intent,
        validated_input: ValidatedInput 
    ) -> ReasoningResult:
        """Parse answer response from LLM"""
        
        try:
            # Clean response (remove markdown if present)
            text = response.content.strip()
            if text.startswith("```"):
                lines = text.split("\n")
                text = "\n".join(lines[1:-1])
            
            # Parse JSON
            data = json.loads(text)
            
            # Extract answer
            answer_text = data.get("answer", "")
            live_context = validated_input.live_context or retrieval_result.live_data

            if live_context and intent in (
                Intent.STATUS_QUERY,
                Intent.INFORMATIONAL_QUERY
            ):
                live_summary = json.dumps(live_context)
                if "task" not in answer_text.lower():
                    answer_text = (
                        f"{answer_text}\n\nRelevant status information: {live_summary}"
                    )


            # Fallback: inject live context hints if answer is empty
            if not answer_text and retrieval_result.live_data:
                answer_text = f"Here is the current status based on live data: {json.dumps(retrieval_result.live_data)}"

            confidence_str = data.get("confidence", "uncertain")
            reasoning_text = data.get("reasoning")
            sources_used = data.get("sources_used", [])
            warnings = data.get("warnings", [])
            
            # Convert confidence string to enum
            confidence = self._parse_confidence(confidence_str, retrieval_result)
            if not answer_text.strip():
                answer_text = "I found some information, but it may be incomplete."
            if "long_query" in validated_input.validation_flags:
                answer_text = (
                    "[long_query] This was a long query, so the answer may be partial.\n\n"
                    + answer_text
                )
            # Build Answer object
            final_reasoning = reasoning_text

            if confidence != AnswerConfidence.CERTAIN and not final_reasoning:
                final_reasoning = (
                    "The available information is incomplete, conflicting, or insufficient "
                    "to provide a fully certain answer."
                )

            answer = Answer(
                content=answer_text,
                confidence=confidence,
                reasoning=final_reasoning if confidence != AnswerConfidence.CERTAIN else None
            )
            
            # Build ReasoningResult
            return ReasoningResult(
                answer=answer,
                action=None,
                # confidence=answer.confidence,
                sources_used=sources_used,
                warnings=warnings
            )
        
        except json.JSONDecodeError:
            # LLM didn't return valid JSON, treat as prose
            self.logger.warning("LLM returned non-JSON response, treating as prose")
            
            # Assess confidence from retrieval
            confidence = self._assess_fallback_confidence(retrieval_result)
            
            return ReasoningResult(
                answer=Answer(
                    content=response.content,
                    confidence=confidence,
                    reasoning="The response format was non-standard, so confidence is estimated."

                ),
                action=None,
                sources_used=[],
                warnings=["non_json_response"]
            )
    
    def _parse_action_response(
        self,
        response: LLMResponse,
        retrieval_result: RetrievalResult
    ) -> ReasoningResult:
        """Parse action response from LLM"""
        
        try:
            # Clean response
            text = response.content.strip()
            if text.startswith("```"):
                lines = text.split("\n")
                text = "\n".join(lines[1:-1])
            
            # Parse JSON
            data = json.loads(text)
            
            # Extract action
            action_data = data.get("action", {})
            explanation = data.get("explanation", "")
            sources_used = data.get("sources_used", [])
            
            # Build Action object
            action = Action(
                type=action_data.get("type", "unknown"),
                parameters=action_data.get("parameters", {}),
                confidence=action_data.get("confidence", 0.5),
                requires_confirmation=action_data.get("requires_confirmation", True)
            )
            
            # Build ReasoningResult
            return ReasoningResult(
                answer=Answer(
                    content=explanation,
                    confidence=AnswerConfidence.LIKELY,  # Actions are always "likely"
                    reasoning=None
                ),
                action=action,
                sources_used=sources_used,
                warnings=[]
            )
        
        except json.JSONDecodeError:
            self.logger.error("Failed to parse action response")
            return self._error_result("Failed to parse action from response")
    
    def _parse_confidence(
        self,
        confidence_str: str,
        retrieval_result: RetrievalResult
    ) -> AnswerConfidence:
        """Parse confidence string to enum"""
        confidence_map = {
            "certain": AnswerConfidence.CERTAIN,
            "likely": AnswerConfidence.LIKELY,
            "uncertain": AnswerConfidence.UNCERTAIN,
            "unknown": AnswerConfidence.UNKNOWN
        }
        ###########################
        if isinstance(confidence_str, (int, float)):
            return AnswerConfidence.LIKELY if confidence_str >= 0.7 else AnswerConfidence.UNCERTAIN

        confidence_str = confidence_str.lower()
        ##############################

        parsed = confidence_map.get(confidence_str.lower(), AnswerConfidence.UNCERTAIN)
        
        # Double-check against retrieval confidence
        # If retrieval confidence is low, cap at uncertain
        if retrieval_result.retrieval_confidence == RetrievalConfidence.LOW:
            if parsed == AnswerConfidence.CERTAIN:
                parsed = AnswerConfidence.LIKELY
        
        return parsed
    
    def _assess_fallback_confidence(
        self,
        retrieval_result: RetrievalResult
    ) -> AnswerConfidence:
        """Assess confidence when LLM doesn't provide it"""
        
        # Extract source authorities
        authorities = [
            rs.source.metadata.authority
            for rs in retrieval_result.retrieved_knowledge
        ]
        
        # Use utility function
        return assess_answer_confidence(
            retrieval_result.retrieval_confidence,
            authorities,
            len(retrieval_result.conflicts) > 0,
            "stale_data" in retrieval_result.warnings
        )
    
    def _error_result(self, error_message: str) -> ReasoningResult:
        """Create error result"""
        return ReasoningResult(
            answer=Answer(
                content=f"I encountered an error while processing your request: {error_message}",
                confidence=AnswerConfidence.UNKNOWN,
                reasoning="System error occurred"
            ),
            action=None,
            sources_used=[],
            warnings=["reasoning_error"]
        )