"""
Input validation component (Stage 1).

Validates and normalizes incoming requests.
"""

from typing import Dict, Any
from pydantic import BaseModel, Field, validator
from datetime import datetime, timezone

from ..models.request import ValidatedInput, RequestOptions, Message
from ..models.persona import Persona
from ..utils.validation import (
    validate_timestamp,
    validate_enum_value,
    normalize_conversation_history,
    ValidationError
)
from ..logging.logger import get_logger


class RawRequestSchema(BaseModel):
    """Pydantic schema for external request validation"""
    query: Dict[str, Any]
    context: Dict[str, Any]
    conversation_history: list = Field(default_factory=list)
    live_context: Dict[str, Any] = Field(default_factory=dict)
    options: Dict[str, Any] = Field(default_factory=dict)


class InputValidator:
    """
    Validates and normalizes input requests.
    
    This is the boundary between external input and internal brain models.
    Uses Pydantic for external validation, pure dataclasses internally.
    """
    
    def __init__(self, max_history_turns: int = 5):
        """
        Initialize validator.
        
        Args:
            max_history_turns: Maximum conversation turns to keep
        """
        self.max_history_turns = max_history_turns
        self.logger = get_logger()
    
    def validate(self, raw_request: dict) -> ValidatedInput:
        """
        Validate and normalize raw request.
        
        Args:
            raw_request: Raw request dictionary from external caller
        
        Returns:
            ValidatedInput with normalized data
        
        Raises:
            ValidationError if request is invalid
        """
        self.logger.debug("Validating input request")
        
        try:
            # Step 1: Pydantic validation (external boundary)
            schema = RawRequestSchema(**raw_request)
            
            # Step 2: Extract and validate query
            query_data = schema.query
            if "user_input" not in query_data:
                raise ValidationError("Missing required field: query.user_input")
            
            user_input = query_data["user_input"].strip()
            if not user_input:
                raise ValidationError("query.user_input cannot be empty")
            
            query_id = query_data.get("query_id", self._generate_query_id())
            
            query_timestamp = query_data.get("timestamp")
            if query_timestamp:
                query_timestamp = validate_timestamp(query_timestamp)
            else:
                query_timestamp = datetime.now(timezone.utc)
            
            # Step 3: Extract and validate context
            context_data = schema.context
            if "tenant_id" not in context_data:
                raise ValidationError("Missing required field: context.tenant_id")
            if "persona" not in context_data:
                raise ValidationError("Missing required field: context.persona")
            if "user_id" not in context_data:
                raise ValidationError("Missing required field: context.user_id")
            
            tenant_id = context_data["tenant_id"]
            user_id = context_data["user_id"]
            persona = validate_enum_value(context_data["persona"], Persona)
            
            # Step 4: Normalize conversation history
            conversation_history = normalize_conversation_history(
                schema.conversation_history,
                self.max_history_turns
            )
            
            # Step 5: Validate live context (if present)
            live_context = schema.live_context if schema.live_context else None
            
            # Step 6: Parse options
            options_data = schema.options
            options = RequestOptions(
                mode=options_data.get("mode", "sync"),
                max_retrieval_depth=options_data.get("max_retrieval_depth"),
                require_sources=options_data.get("require_sources", False)
            )
            
            # Validate mode
            if options.mode not in ["sync", "async"]:
                raise ValidationError(f"Invalid mode: {options.mode}")
            
            # Step 7: Collect validation flags
            validation_flags = []
            
            if len(user_input) > 500:
                validation_flags.append("long_query")
            
            if live_context and len(live_context) > 0:
                validation_flags.append("has_live_context")
            
            if len(conversation_history) > 0:
                validation_flags.append("has_conversation_history")
            
            # Step 8: Create ValidatedInput
            validated = ValidatedInput(
                query=user_input,
                query_id=query_id,
                timestamp=query_timestamp,
                persona=persona,
                user_id=user_id,
                tenant_id=tenant_id,
                conversation_history=conversation_history,
                live_context=live_context,
                options=options,
                validation_flags=validation_flags
            )
            
            self.logger.info(
                "Input validated successfully",
                context={
                    "query_id": query_id,
                    "persona": persona.value,
                    "flags": ",".join(validation_flags)
                }
            )
            
            return validated
        
        except ValidationError:
            raise
        except Exception as e:
            raise ValidationError(f"Input validation failed: {str(e)}") from e
    
    def _generate_query_id(self) -> str:
        """Generate unique query ID"""
        import uuid
        return f"query_{uuid.uuid4().hex[:16]}"