"""
Intent classification component (Stage 2).

Classifies user intent and determines retrieval strategy.
"""

import json
from typing import Tuple

from ..models.request import ValidatedInput
from ..models.intent import (
    Intent,
    IntentClassification,
    RetrievalStrategy,
    ResponseMode
)
from ..models.persona import Persona, ScopeCheck, QueryScope, UserContext
from ..interfaces.llm import LLMClient, LLMMessage, LLMResponse
from ..prompts.intent_classifier import build_intent_classification_prompt
from ..config.persona_config import PersonaConfig
from ..logging.logger import get_logger


class IntentClassifier:
    """
    Classifies intent and checks persona scope.
    
    Uses LLM for intent classification.
    """
    
    def __init__(
        self,
        llm_client: LLMClient,
        persona_config: PersonaConfig
    ):
        """
        Initialize classifier.
        
        Args:
            llm_client: LLM client for classification
            persona_config: Persona rules configuration
        """
        self.llm_client = llm_client
        self.persona_config = persona_config
        self.logger = get_logger()
    
    def classify(
        self,
        validated_input: ValidatedInput,
        user_context: UserContext
    ) -> IntentClassification:
        """
        Classify intent and check persona scope.
        
        Args:
            validated_input: Validated input
            user_context: User context (teams, etc.)
        
        Returns:
            IntentClassification with intent, scope check, retrieval strategy
        """
        self.logger.debug(
            "Classifying intent",
            context={"query_id": validated_input.query_id}
        )
        
        # Step 1: Build classification prompt
        system_prompt, user_prompt = self._build_classification_prompt(
            validated_input.query,
            validated_input.persona
        )
        
        # Step 2: Call LLM for classification
        try:
            response = self.llm_client.complete(
                messages=[
                    LLMMessage(role="system", content=system_prompt),
                    LLMMessage(role="user", content=user_prompt)
                ],
                max_tokens=500,
                temperature=0.0
            )
            if not response:
                raise ValueError("LLM returned empty response during intent classification")
            
            # Parse JSON response
            classification_data = self._parse_classification_response(response)
            
        except Exception as e:
            self.logger.error(
                "Intent classification failed",
                context={"query_id": validated_input.query_id},
                exc_info=True
            )
            # Fallback to clarification required
            return self._fallback_classification(validated_input)
        
        # Step 3: Extract intent and query scope
        intent = Intent(classification_data["intent"])
        query_scope = QueryScope(
            level=classification_data["query_scope"]["level"],
            mentions_users=classification_data["query_scope"].get("mentions_users", []),
            mentions_teams=classification_data["query_scope"].get("mentions_teams", []),
            requires_analytics=classification_data["query_scope"].get("requires_analytics", False)
        )
        confidence = classification_data.get("confidence", 0.5)
        
        # Step 4: Check persona scope
        persona_check = self._check_persona_scope(
            validated_input.persona,
            intent,
            query_scope
        )
        
        # Step 5: Determine retrieval strategy
        retrieval_strategy = self._determine_retrieval_strategy(intent, query_scope)
        
        # Step 6: Determine response mode (sync vs async)
        response_mode = self._determine_response_mode(intent, validated_input.options.mode)
        
        # Step 7: Build classification result
        classification = IntentClassification(
            intent=intent if persona_check == ScopeCheck.ALLOWED else Intent.OUT_OF_SCOPE,
            retrieval_strategy=retrieval_strategy,
            response_mode=response_mode,
            persona_check=persona_check,
            classification_confidence=confidence,
            query_scope=query_scope,
            refusal_reason=self._get_refusal_reason(persona_check, validated_input.persona, query_scope)
        )
        
        self.logger.info(
            "Intent classified",
            context={
                "query_id": validated_input.query_id,
                "intent": classification.intent.value,
                "confidence": confidence,
                "persona_check": persona_check.value
            }
        )
        
        return classification
    
    def _build_classification_prompt(
        self,
        query: str,
        persona: Persona
    ) -> Tuple[str, str]:
        """Build classification prompts"""
        allowed_scope = self._get_allowed_scope_description(persona)
        return build_intent_classification_prompt(query, persona.value, allowed_scope)
    
    def _get_allowed_scope_description(self, persona: Persona) -> str:
        """Get human-readable allowed scope for persona"""
        if persona == Persona.EMPLOYEE:
            return "personal tasks, public information"
        else:
            return "personal tasks, team analytics, public information"
    
    def _parse_classification_response(self, response: LLMResponse) -> dict:
        """Parse JSON response from LLM"""
        # Remove markdown code blocks if present
        text = response.content.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            text = "\n".join(lines[1:-1])
        
        return json.loads(text)
    
    def _check_persona_scope(
        self,
        persona: Persona,
        intent: Intent,
        query_scope: QueryScope
    ) -> ScopeCheck:
        """Check if intent and scope are allowed for persona"""
        
        # Employee restrictions
        if persona == Persona.EMPLOYEE:
            # Cannot access team-level analytics
            if query_scope.level == "team" and query_scope.requires_analytics:
                return ScopeCheck.OUT_OF_SCOPE

            # Cannot access multi-team queries (cross-team comparisons)
            if query_scope.level == "multi_team":
                return ScopeCheck.OUT_OF_SCOPE

            # Company-level: allow informational/status queries (policies, SOPs, general info)
            # but block analytics/planning at company level
            if query_scope.level == "company":
                if intent in [Intent.METRICS_QUERY, Intent.PLANNING_REQUEST]:
                    return ScopeCheck.OUT_OF_SCOPE

            # Forbidden intents for employees at non-personal scope
            if intent in [Intent.METRICS_QUERY, Intent.PLANNING_REQUEST]:
                if query_scope.level not in ["personal", "company"]:
                    return ScopeCheck.OUT_OF_SCOPE
        
        return ScopeCheck.ALLOWED
    
    def _determine_retrieval_strategy(
        self,
        intent: Intent,
        query_scope: QueryScope
    ) -> RetrievalStrategy:
        """Determine retrieval strategy based on intent"""
        
        # Status queries prefer live context
        if intent == Intent.STATUS_QUERY:
            return RetrievalStrategy.HYBRID  # Live + RAG for context
        
        # Metrics queries need live data
        if intent == Intent.METRICS_QUERY:
            return RetrievalStrategy.HYBRID
        
        # Historical queries (decisions, summaries) need RAG
        if intent in [Intent.DECISION_RECALL, Intent.SUMMARY_REQUEST]:
            return RetrievalStrategy.RAG_ONLY
        
        # Informational queries need RAG
        if intent == Intent.INFORMATIONAL_QUERY:
            return RetrievalStrategy.RAG_ONLY
        
        # Planning needs both
        if intent == Intent.PLANNING_REQUEST:
            return RetrievalStrategy.HYBRID
        
        # Task actions need live context
        if intent == Intent.TASK_ACTION:
            return RetrievalStrategy.LIVE_ONLY
        
        # Default to RAG
        return RetrievalStrategy.RAG_ONLY
    
    def _determine_response_mode(self, intent: Intent, requested_mode: str) -> ResponseMode:
        """Determine if query should be async"""
        
        # Planning requests can be async if requested
        if intent == Intent.PLANNING_REQUEST and requested_mode == "async":
            return ResponseMode.ASYNC
        
        # Summary requests can be async for large summaries
        if intent == Intent.SUMMARY_REQUEST and requested_mode == "async":
            return ResponseMode.ASYNC
        
        # Everything else is sync
        return ResponseMode.SYNC
    
    def _get_refusal_reason(
        self,
        persona_check: ScopeCheck,
        persona: Persona,
        query_scope: QueryScope
    ) -> str:
        """Get human-readable refusal reason"""
        if persona_check == ScopeCheck.OUT_OF_SCOPE:
            if persona == Persona.EMPLOYEE:
                if query_scope.level == "team":
                    return "Team-level analytics require manager access"
                else:
                    return "This query exceeds your current access level"
        return None
    
    def _fallback_classification(self, validated_input: ValidatedInput) -> IntentClassification:
        """Fallback classification when LLM fails"""
        return IntentClassification(
            intent=Intent.CLARIFICATION_REQUIRED,
            retrieval_strategy=RetrievalStrategy.NONE,
            response_mode=ResponseMode.SYNC,
            persona_check=ScopeCheck.ALLOWED,
            classification_confidence=0.0,
            query_scope=QueryScope(
                level="personal",
                mentions_users=[],
                mentions_teams=[],
                requires_analytics=False
            ),
            refusal_reason="Unable to understand query. Please rephrase."
        )