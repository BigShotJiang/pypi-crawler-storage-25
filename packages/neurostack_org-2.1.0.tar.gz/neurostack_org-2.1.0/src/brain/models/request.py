"""
Request models (input to brain).
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Dict, Any

from .persona import Persona


@dataclass
class Message:
    """Single message in conversation history"""
    role: str  # "user" | "assistant"
    content: str
    timestamp: datetime


@dataclass
class RequestOptions:
    """Optional request parameters"""
    mode: str = "sync"  # "sync" | "async"
    max_retrieval_depth: Optional[int] = None  # Soft hint
    require_sources: bool = False


@dataclass
class QueryInput:
    """User query details"""
    user_input: str
    query_id: str
    timestamp: datetime


@dataclass
class ContextInput:
    """Request context"""
    tenant_id: str
    persona: Persona
    user_id: str


@dataclass
class ValidatedInput:
    """
    Validated and normalized input.
    
    Output of InputValidator component.
    """
    query: str
    query_id: str
    timestamp: datetime
    persona: Persona
    user_id: str
    tenant_id: str
    conversation_history: List[Message]
    live_context: Optional[Dict[str, Any]]
    options: RequestOptions
    validation_flags: List[str] = field(default_factory=list)