"""
Confidence models.
"""

from enum import Enum


class RetrievalConfidence(Enum):
    """Confidence in retrieval quality"""
    HIGH = "high"      # Top result clearly dominates
    MEDIUM = "medium"  # Multiple good matches
    LOW = "low"        # Weak matches or no results


class AnswerConfidence(Enum):
    """Confidence in answer correctness"""
    CERTAIN = "certain"        # Grounded in strong sources
    LIKELY = "likely"          # Reasonable inference
    UNCERTAIN = "uncertain"    # Weak sources or conflicts
    UNKNOWN = "unknown"        # Cannot answer