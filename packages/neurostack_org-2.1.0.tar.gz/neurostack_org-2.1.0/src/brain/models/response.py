"""
Response models (output from brain).
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Dict, Any
from .retrieval import RankedSource
from .intent import Intent
from .confidence import AnswerConfidence
from .request import RequestOptions


@dataclass
class Source:
    """Reference to a knowledge source"""
    knowledge_type: str
    id: str
    title: str
    timestamp: datetime
    authority: str
    relevance_note: Optional[str] = None


@dataclass
class Conflict:
    """Detected conflict between sources"""
    description: str
    resolution: str  # How conflict was resolved


@dataclass
class Answer:
    """Answer for informational queries"""
    content: str
    confidence: AnswerConfidence
    reasoning: Optional[str] = None  # Included when confidence < certain


@dataclass
class Action:
    """Structured action for task actions"""
    type: str  # "assign_task" | "update_status" | etc.
    parameters: Dict[str, Any]
    confidence: float  # 0.0 to 1.0
    requires_confirmation: bool


@dataclass
class AsyncJob:
    """Async job reference"""
    job_id: str
    estimated_duration: str
    status_endpoint: str  # Abstract reference


class ResponseType(str):
    """Response type literals"""
    PROSE = "prose"
    ACTION = "action"
    REFUSAL = "refusal"
    CLARIFICATION = "clarification"
    ASYNC_JOB = "async_job"


@dataclass
class BrainResponse:
    """
    Final brain output (follows I/O contract).
    """
    query_id: str
    intent: Intent
    response_type: str  # ResponseType
    
    # For prose responses
    answer: Optional[Answer] = None
    # For action responses
    action: Optional[Action] = None
    explanation: Optional[str] = None
    
    # For refusals/clarifications
    message: Optional[str] = None
    reason: Optional[str] = None
    
    # For async jobs
    job: Optional[AsyncJob] = None
    
    # Common fields
    sources: List[Source] = field(default_factory=list)
    conflicts: List[Conflict] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)

    options: Optional[RequestOptions] = None
    
@dataclass
class ReasoningResult:
    """
    Internal output of the ReasoningEngine.
    """
    answer: Optional[Answer] = None
    action: Optional[Action] = None
    # confidence: AnswerConfidence = AnswerConfidence.UNKNOWN

    sources_used: List[str] = field(default_factory=list)


    # reasoning: Optional[str] = None
    warnings: List[str] = field(default_factory=list)
    errors: Optional[str] = None
    
