"""
Retrieval models.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

from neurostack.models import Knowledge
from .confidence import RetrievalConfidence


@dataclass
class RankedSource:
    """Retrieved knowledge with ranking metadata"""
    source: Knowledge
    score: float  # Similarity score
    rank: int
    reason_selected: str  # "high_authority" | "recent" | "relevant"


@dataclass
class RetrievalResult:
    """
    Result of knowledge retrieval.
    
    Output of KnowledgeRetriever component.
    """
    retrieved_knowledge: List[RankedSource]
    live_data: Optional[Dict[str, Any]]
    retrieval_confidence: RetrievalConfidence
    conflicts: List[Dict[str, str]] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)