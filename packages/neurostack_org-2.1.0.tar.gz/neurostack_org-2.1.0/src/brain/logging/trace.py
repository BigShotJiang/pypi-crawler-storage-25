"""
Tracing utilities for brain operations.

Provides audit trail for reasoning pipeline.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
from enum import Enum


class TraceLevel(Enum):
    """Trace detail level"""
    STAGE = "stage"          # High-level stage transitions
    COMPONENT = "component"  # Component-level operations
    DETAIL = "detail"        # Detailed internal operations


@dataclass
class TraceEvent:
    """Single trace event"""
    timestamp: datetime
    level: TraceLevel
    stage: str  # "parse" | "classify" | "retrieve" | "reason" | "format"
    component: str  # Component name
    event: str  # Event description
    data: Optional[Dict[str, Any]] = None
    duration_ms: Optional[float] = None


@dataclass
class QueryTrace:
    """
    Complete trace for a query execution.
    
    Used for audit, debugging, and performance analysis.
    """
    query_id: str
    tenant_id: str
    user_id: str
    persona: str
    start_time: datetime
    events: List[TraceEvent] = field(default_factory=list)
    end_time: Optional[datetime] = None
    total_duration_ms: Optional[float] = None
    
    def add_event(
        self,
        level: TraceLevel,
        stage: str,
        component: str,
        event: str,
        data: Optional[Dict[str, Any]] = None,
        duration_ms: Optional[float] = None
    ) -> None:
        """Add trace event"""
        self.events.append(TraceEvent(
            timestamp=datetime.now(timezone.utc),
            level=level,
            stage=stage,
            component=component,
            event=event,
            data=data,
            duration_ms=duration_ms
        ))
    
    def finalize(self) -> None:
        """Mark trace as complete"""
        self.end_time = datetime.now(timezone.utc)
        if self.start_time and self.end_time:
            delta = self.end_time - self.start_time
            self.total_duration_ms = delta.total_seconds() * 1000
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging/storage"""
        return {
            "query_id": self.query_id,
            "tenant_id": self.tenant_id,
            "user_id": self.user_id,
            "persona": self.persona,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "total_duration_ms": self.total_duration_ms,
            "events": [
                {
                    "timestamp": e.timestamp.isoformat(),
                    "level": e.level.value,
                    "stage": e.stage,
                    "component": e.component,
                    "event": e.event,
                    "data": e.data,
                    "duration_ms": e.duration_ms
                }
                for e in self.events
            ]
        }