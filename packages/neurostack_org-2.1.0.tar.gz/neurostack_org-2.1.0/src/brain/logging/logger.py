"""
Centralized logging for the brain.

All components log through this module, never directly.
"""

import logging
import sys
from typing import Optional, Dict, Any
from datetime import datetime


class BrainLogger:
    """
    Centralized logger for brain components.
    
    Provides structured logging with consistent format.
    """
    
    def __init__(self, name: str = "neurostack.brain", level: int = logging.INFO):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(level)
        
        # Prevent duplicate handlers
        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setLevel(level)
            
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            handler.setFormatter(formatter)
            
            self.logger.addHandler(handler)
    
    def _log_with_context(
        self,
        level: int,
        message: str,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """Internal method to log with structured context"""
        if context:
            context_str = " | ".join(f"{k}={v}" for k, v in context.items())
            full_message = f"{message} | {context_str}"
        else:
            full_message = message
        
        self.logger.log(level, full_message)
    
    def info(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log info level message"""
        self._log_with_context(logging.INFO, message, context)
    
    def warning(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log warning level message"""
        self._log_with_context(logging.WARNING, message, context)
    
    def error(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        exc_info: bool = False
    ) -> None:
        """Log error level message"""
        self._log_with_context(logging.ERROR, message, context)
        if exc_info:
            self.logger.exception(message)
    
    def debug(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Log debug level message"""
        self._log_with_context(logging.DEBUG, message, context)


# Global logger instance
_global_logger: Optional[BrainLogger] = None


def get_logger() -> BrainLogger:
    """Get global brain logger instance"""
    global _global_logger
    if _global_logger is None:
        _global_logger = BrainLogger()
    return _global_logger


def configure_logger(level: int = logging.INFO) -> None:
    """Configure global logger"""
    global _global_logger
    _global_logger = BrainLogger(level=level)