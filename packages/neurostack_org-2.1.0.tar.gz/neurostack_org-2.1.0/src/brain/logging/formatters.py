"""
Log formatters for different output formats.
"""

import json
from typing import Dict, Any


class JSONFormatter:
    """Format logs as JSON (for structured logging systems)"""
    
    @staticmethod
    def format(record: Dict[str, Any]) -> str:
        """Format log record as JSON string"""
        return json.dumps(record, default=str)


class HumanReadableFormatter:
    """Format logs for human reading"""
    
    @staticmethod
    def format(record: Dict[str, Any]) -> str:
        """Format log record as human-readable string"""
        timestamp = record.get('timestamp', '')
        level = record.get('level', 'INFO')
        message = record.get('message', '')
        context = record.get('context', {})
        
        base = f"[{timestamp}] {level}: {message}"
        
        if context:
            context_str = " | ".join(f"{k}={v}" for k, v in context.items())
            return f"{base} | {context_str}"
        
        return base