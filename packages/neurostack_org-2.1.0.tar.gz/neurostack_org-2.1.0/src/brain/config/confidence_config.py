"""
Confidence assessment configuration.
"""

from dataclasses import dataclass, field
from typing import Dict


@dataclass
class ActionConfidenceThresholds:
    """Confidence thresholds per action type (risk-adjusted)"""
    
    # Low risk actions (can execute without confirmation)
    low_risk_threshold: float = 0.85
    low_risk_actions: list = field(default_factory=lambda: [
        "assign_task",
        "add_comment",
        "update_description"
    ])
    
    # Medium risk actions (require confirmation)
    medium_risk_threshold: float = 0.90
    medium_risk_actions: list = field(default_factory=lambda: [
        "update_status",
        "change_priority",
        "reassign_task"
    ])
    
    # High risk actions (require strong confirmation)
    high_risk_threshold: float = 0.95
    high_risk_actions: list = field(default_factory=lambda: [
        "delete_task",
        "archive_project",
        "remove_user"
    ])
    
    def get_threshold(self, action_type: str) -> float:
        """Get threshold for specific action type"""
        if action_type in self.low_risk_actions:
            return self.low_risk_threshold
        elif action_type in self.medium_risk_actions:
            return self.medium_risk_threshold
        elif action_type in self.high_risk_actions:
            return self.high_risk_threshold
        else:
            return self.medium_risk_threshold  # Default to medium


@dataclass
class ConfidenceConfig:
    """Configuration for confidence assessment"""
    
    # Retrieval confidence thresholds
    retrieval_strong_threshold: float = 0.75
    retrieval_acceptable_threshold: float = 0.60
    retrieval_dominance_gap: float = 0.15
    
    # Answer confidence rules
    # (These are used in decision matrix logic, not hardcoded thresholds)
    
    # Confidence upgrade limits
    max_upgrade_from_clarification: int = 1  # Max levels to upgrade
    
    # Action confidence
    action_thresholds: ActionConfidenceThresholds = field(
        default_factory=ActionConfidenceThresholds
    )
    
    # Conflict handling
    conflict_always_caps_at_uncertain: bool = True
    
    @classmethod
    def from_dict(cls, data: dict) -> "ConfidenceConfig":
        """Create from dictionary"""
        action_data = data.pop('action_thresholds', {})
        return cls(
            action_thresholds=ActionConfidenceThresholds(**action_data),
            **data
        )