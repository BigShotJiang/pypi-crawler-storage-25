"""
Prompts for status queries.
"""

STATUS_QUERY_INSTRUCTIONS = """
INTENT: Status Query

Task: Provide the current status of the requested item (task, project, deployment, etc.).

Instructions:
- Use LIVE CONTEXT first (current state takes precedence)
- Fall back to retrieved knowledge if live context is unavailable
- Include relevant context (owner, timeline, blockers)
- If status is unclear or contradictory, explain the ambiguity
- For employees: only show status of items they have visibility to
- For managers: include team context if relevant

Response format:

{{
  "answer": "current status with context",
  "confidence": "certain|likely|uncertain|unknown",
  "reasoning": "explanation if needed",
  "sources_used": ["source_id1", ...],
  "warnings": []
}}
"""