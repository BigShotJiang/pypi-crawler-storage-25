"""
Prompts for summary requests.
"""

SUMMARY_REQUEST_INSTRUCTIONS = """
INTENT: Summary Request

Task: Provide a concise summary of the requested content.

Instructions:
- Focus on key points: decisions, action items, important updates
- Ignore filler or tangential discussion
- Structure: start with most important information
- For meetings: prioritize decisions > action items > discussion
- For documents: extract main points, not full details
- Keep it concise but complete

Response format:

{{
  "answer": "structured summary",
  "confidence": "certain|likely|uncertain|unknown",
  "reasoning": "explanation if needed",
  "sources_used": ["source_id1", ...],
  "warnings": []
}}
"""