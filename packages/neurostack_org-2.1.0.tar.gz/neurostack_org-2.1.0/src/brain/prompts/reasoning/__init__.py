"""
Intent-specific reasoning prompts.
"""

from ...models.intent import Intent
from .informational import INFORMATIONAL_QUERY_INSTRUCTIONS
from .status import STATUS_QUERY_INSTRUCTIONS
from .metrics import METRICS_QUERY_INSTRUCTIONS
from .planning import PLANNING_REQUEST_INSTRUCTIONS
from .action import TASK_ACTION_INSTRUCTIONS
from .decision_recall import DECISION_RECALL_INSTRUCTIONS
from .summary import SUMMARY_REQUEST_INSTRUCTIONS


def get_intent_instructions(intent: Intent) -> str:
    """
    Get intent-specific instructions.
    
    Args:
        intent: Classified intent
    
    Returns:
        Intent-specific instruction string
    """
    mapping = {
        Intent.INFORMATIONAL_QUERY: INFORMATIONAL_QUERY_INSTRUCTIONS,
        Intent.STATUS_QUERY: STATUS_QUERY_INSTRUCTIONS,
        Intent.METRICS_QUERY: METRICS_QUERY_INSTRUCTIONS,
        Intent.SUMMARY_REQUEST: SUMMARY_REQUEST_INSTRUCTIONS,
        Intent.PLANNING_REQUEST: PLANNING_REQUEST_INSTRUCTIONS,
        Intent.TASK_ACTION: TASK_ACTION_INSTRUCTIONS,
        Intent.DECISION_RECALL: DECISION_RECALL_INSTRUCTIONS,
    }
    
    return mapping.get(intent, INFORMATIONAL_QUERY_INSTRUCTIONS)