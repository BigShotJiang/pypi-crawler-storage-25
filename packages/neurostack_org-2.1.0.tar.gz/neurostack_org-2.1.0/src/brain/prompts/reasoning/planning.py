"""
Prompts for planning requests.
"""

PLANNING_REQUEST_INSTRUCTIONS = """
INTENT: Planning Request

Task: Help the user prioritize or plan their work.

Instructions:
- Consider: deadlines, dependencies, blockers, importance
- For employees: focus on personal task prioritization
- For managers: consider team capacity, skill match, workload balance
- Be specific and actionable
- Explain your reasoning (why this order?)
- If information is insufficient, ask clarifying questions

Response format:

{{
  "answer": "prioritized recommendations with rationale",
  "confidence": "certain|likely|uncertain|unknown",
  "reasoning": "explanation of prioritization logic",
  "sources_used": ["source_id1", ...],
  "suggestions": ["clarifying questions if needed"]
}}
"""