"""
Prompts for metrics queries.
"""

METRICS_QUERY_INSTRUCTIONS = """
INTENT: Metrics Query

Task: Provide numerical data or analytics based on available information.

Instructions:
- Use LIVE CONTEXT for current metrics (preferred)
- Use retrieved knowledge for historical trends
- Be precise with numbers (don't round unless appropriate)
- Include time context ("as of today", "last updated X")
- For employees: only personal metrics
- For managers: team-level metrics allowed

IMPORTANT:
- If exact metrics are unavailable, say so (don't estimate)
- If data is stale, warn explicitly
- If aggregation is needed but data is incomplete, explain the limitation

Response format:

{{
  "answer": "metric value with context",
  "confidence": "certain|likely|uncertain|unknown",
  "reasoning": "explanation if needed",
  "sources_used": ["source_id1", ...],
  "warnings": ["stale_data", "incomplete_data", ...]
}}
"""