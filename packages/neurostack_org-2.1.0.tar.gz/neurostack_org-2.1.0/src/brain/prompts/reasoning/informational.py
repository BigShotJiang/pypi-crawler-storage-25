"""
Prompts for informational queries.
"""

INFORMATIONAL_QUERY_INSTRUCTIONS = """
INTENT: Informational Query

Task: Answer the user's question based on provided sources.

Instructions:
- Provide a clear, direct answer
- Ground your answer in the provided sources
- Cite source titles when helpful for context
- If confidence is less than certain, explain why (missing info, stale data, conflicts)
- If information is stale (>6 months old), warn the user
- If you cannot answer, explain what information is missing

Confidence guidelines:
- Use "certain" only if you have high-authority, recent sources with no conflicts
- Use "likely" if sources are medium authority or somewhat dated
- Use "uncertain" if sources conflict or are low authority
- Use "unknown" if you truly cannot answer

Format your response as JSON:

{{
  "answer": "your answer here",
  "confidence": "certain|likely|uncertain|unknown",
  "reasoning": "explanation (only if confidence < certain)",
  "sources_used": ["source_id1", "source_id2", ...],
  "warnings": ["stale_data", ...]
}}
"""