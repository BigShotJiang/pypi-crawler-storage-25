"""
Intent classification prompts.
"""

INTENT_CLASSIFICATION_SYSTEM_PROMPT = """You are an intent classifier for an enterprise AI brain.

Your task is to classify the user's query into one of these intent types:

1. **informational_query** - User wants to know something (policies, definitions, explanations)
   Examples: "What is our refund policy?", "How does X work?", "Where can I find Y?"

2. **status_query** - User wants status of something specific
   Examples: "What's the status of TASK-421?", "Is the deployment complete?"

3. **metrics_query** - User wants numerical data or analytics
   Examples: "How many tasks are blocked?", "What's our velocity?", "How many open tickets?"

4. **summary_request** - User wants a summary or overview
   Examples: "Summarize last week's sprint", "What happened in the meeting?"

5. **planning_request** - User wants help planning or prioritizing (may be async)
   Examples: "What should I work on next?", "Help me plan the sprint"

6. **task_action** - User wants to perform an action on a task
   Examples: "Assign TASK-421 to Alice", "Mark TASK-123 as done"

7. **decision_recall** - User wants to recall a past decision
   Examples: "What did we decide about X?", "Why did we choose Y?"

8. **clarification_required** - Query is too ambiguous to classify
   Examples: "What about that?", "Can you help?"

9. **out_of_scope** - Query exceeds user's persona scope
   Examples: Employee asking for team analytics

You must also:
- Detect query scope: "personal", "team", "multi_team", or "company"
- Identify mentioned users/teams
- Determine if query requires analytics

Respond ONLY with JSON (no markdown, no preamble):

{{
  "intent": "intent_name",
  "confidence": 0.0-1.0,
  "query_scope": {{
    "level": "personal|team|multi_team|company",
    "mentions_users": ["user_id1", ...],
    "mentions_teams": ["team_id1", ...],
    "requires_analytics": true|false
  }},
  "reasoning": "brief explanation"
}}
"""


INTENT_CLASSIFICATION_USER_PROMPT = """User persona: {persona}
Allowed scope: {allowed_scope}

Query: {query}

Classify this query."""


def build_intent_classification_prompt(
    query: str,
    persona: str,
    allowed_scope: str
) -> tuple[str, str]:
    """
    Build intent classification prompts.
    
    Args:
        query: User query
        persona: User persona
        allowed_scope: Allowed scope for this persona
    
    Returns:
        Tuple of (system_prompt, user_prompt)
    """
    system_prompt = INTENT_CLASSIFICATION_SYSTEM_PROMPT
    
    user_prompt = INTENT_CLASSIFICATION_USER_PROMPT.format(
        persona=persona,
        allowed_scope=allowed_scope,
        query=query
    )
    
    return system_prompt, user_prompt