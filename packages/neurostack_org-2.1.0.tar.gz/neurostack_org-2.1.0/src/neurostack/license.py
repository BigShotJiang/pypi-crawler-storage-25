"""
Neurostack License Key System.

How it works:
- ENFORCE_LICENSE = False (default) → everything works, no key needed (testing/community mode)
- ENFORCE_LICENSE = True → premium features require a valid license key
- Set key via: NEUROSTACK_LICENSE_KEY environment variable or neurostack.yaml

When you're ready to monetize, flip ENFORCE_LICENSE to True and
premium features will require a key. Free-tier features always work.

License key format: NS-XXXX-XXXX-XXXX (validated via checksum)
"""

import os
import hashlib
import logging
from enum import Enum
from typing import Optional
from functools import wraps

logger = logging.getLogger("neurostack.license")

# ============================================================================
# CONFIGURATION — Flip this to True when ready to monetize
# ============================================================================

ENFORCE_LICENSE = False

# ============================================================================
# LICENSE TIERS
# ============================================================================

class LicenseTier(Enum):
    """License tiers."""
    COMMUNITY = "community"      # Free — core Brain + CSV connector
    PRO = "pro"                  # Paid — all connectors + encryption + sync
    ENTERPRISE = "enterprise"    # Paid — unlimited + priority support


# Features gated by tier
TIER_FEATURES = {
    LicenseTier.COMMUNITY: {
        "brain", "csv_connector", "mock_vector_store", "basic_permissions",
    },
    LicenseTier.PRO: {
        "brain", "csv_connector", "mock_vector_store", "basic_permissions",
        "jira_connector", "slack_connector", "google_connector",
        "qdrant_store", "pinecone_store", "credential_encryption",
        "permission_sync", "real_embeddings",
    },
    LicenseTier.ENTERPRISE: {
        "*",  # Everything
    },
}


# ============================================================================
# LICENSE STATE
# ============================================================================

_current_license: Optional[dict] = None


def _load_license() -> Optional[dict]:
    """Load and validate license key from environment."""
    global _current_license

    if _current_license is not None:
        return _current_license

    key = os.environ.get("NEUROSTACK_LICENSE_KEY", "")

    if not key:
        _current_license = {
            "valid": True,
            "tier": LicenseTier.COMMUNITY,
            "key": None,
        }
        return _current_license

    # Validate key format: NS-XXXX-XXXX-XXXX
    tier = _validate_key(key)

    if tier:
        _current_license = {
            "valid": True,
            "tier": tier,
            "key": key,
        }
        logger.info(f"License activated: {tier.value}")
    else:
        _current_license = {
            "valid": False,
            "tier": LicenseTier.COMMUNITY,
            "key": key,
        }
        logger.warning("Invalid license key — running in community mode")

    return _current_license


def _validate_key(key: str) -> Optional[LicenseTier]:
    """
    Validate license key format and checksum.

    Format: NS-{TIER}-{HASH8}-{CHECK4}
    - TIER: PRO or ENT
    - HASH8: 8 hex chars (unique identifier)
    - CHECK4: 4 hex chars (checksum of TIER+HASH8)
    """
    try:
        parts = key.strip().split("-")
        if len(parts) != 4 or parts[0] != "NS":
            return None

        prefix, tier_code, unique_id, checksum = parts

        # Determine tier
        tier_map = {"PRO": LicenseTier.PRO, "ENT": LicenseTier.ENTERPRISE}
        tier = tier_map.get(tier_code.upper())
        if not tier:
            return None

        # Verify checksum
        payload = f"{tier_code}{unique_id}"
        expected_checksum = hashlib.sha256(payload.encode()).hexdigest()[:4]

        if checksum.lower() != expected_checksum.lower():
            return None

        return tier

    except Exception:
        return None


# ============================================================================
# PUBLIC API
# ============================================================================

def get_license() -> dict:
    """Get current license info."""
    return _load_license()


def get_tier() -> LicenseTier:
    """Get current license tier."""
    lic = _load_license()
    return lic["tier"]


def is_feature_available(feature: str) -> bool:
    """
    Check if a feature is available under the current license.

    When ENFORCE_LICENSE is False, everything is available.
    """
    if not ENFORCE_LICENSE:
        return True

    lic = _load_license()
    tier = lic["tier"]
    allowed = TIER_FEATURES.get(tier, set())

    return "*" in allowed or feature in allowed


def require_feature(feature: str):
    """
    Decorator that gates a class or function behind a license feature.

    Usage:
        @require_feature("jira_connector")
        class JiraConnector(Connector):
            ...
    """
    def decorator(cls_or_func):
        @wraps(cls_or_func)
        def wrapper(*args, **kwargs):
            if not is_feature_available(feature):
                tier = get_tier()
                raise LicenseError(
                    f"'{feature}' requires a Neurostack Pro license. "
                    f"Current tier: {tier.value}. "
                    f"Get a license at https://neurostack.dev/pricing"
                )
            return cls_or_func(*args, **kwargs)
        return wrapper
    return decorator


def generate_license_key(tier: LicenseTier) -> str:
    """
    Generate a license key (for your admin panel / Stripe webhook).

    Args:
        tier: License tier (PRO or ENTERPRISE)

    Returns:
        License key string: NS-{TIER}-{HASH8}-{CHECK4}
    """
    import secrets

    tier_code = "PRO" if tier == LicenseTier.PRO else "ENT"
    unique_id = secrets.token_hex(4)  # 8 hex chars
    payload = f"{tier_code}{unique_id}"
    checksum = hashlib.sha256(payload.encode()).hexdigest()[:4]

    return f"NS-{tier_code}-{unique_id}-{checksum}"


# ============================================================================
# EXCEPTIONS
# ============================================================================

class LicenseError(Exception):
    """Raised when a feature requires a higher license tier."""
    pass


# ============================================================================
# QUICK TEST
# ============================================================================

if __name__ == "__main__":
    # Generate sample keys
    pro_key = generate_license_key(LicenseTier.PRO)
    ent_key = generate_license_key(LicenseTier.ENTERPRISE)

    print(f"Sample PRO key:        {pro_key}")
    print(f"Sample ENTERPRISE key: {ent_key}")
    print(f"PRO validates:         {_validate_key(pro_key)}")
    print(f"ENT validates:         {_validate_key(ent_key)}")
    print(f"Fake validates:        {_validate_key('NS-PRO-00000000-0000')}")
    print(f"ENFORCE_LICENSE:       {ENFORCE_LICENSE}")
    print(f"All features available: {is_feature_available('jira_connector')}")
