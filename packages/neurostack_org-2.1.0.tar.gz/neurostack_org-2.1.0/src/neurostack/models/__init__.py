"""
Shared models used by both Brain and Pipeline.

These are the canonical type definitions. Brain and Pipeline
both import from here. No duplicates.
"""

from .knowledge import (
    Knowledge,
    KnowledgeType,
    KnowledgeMetadata,
    Authority,
    Visibility,
)
from .permission import (
    VisibilityScope,
    PermissionChangeType,
    RawPermission,
    IndexedVisibility,
    PermissionRecord,
    PermissionQuery,
    PermissionChangeEvent,
    PermissionSyncJob,
)
from .context import (
    TenantContext,
    QueryRequest,
    QueryResponse,
)

__all__ = [
    # Knowledge
    "Knowledge", "KnowledgeType", "KnowledgeMetadata", "Authority", "Visibility",
    # Permissions
    "VisibilityScope", "PermissionChangeType", "RawPermission",
    "IndexedVisibility", "PermissionRecord", "PermissionQuery",
    "PermissionChangeEvent", "PermissionSyncJob",
    # Context
    "TenantContext", "QueryRequest", "QueryResponse",
]