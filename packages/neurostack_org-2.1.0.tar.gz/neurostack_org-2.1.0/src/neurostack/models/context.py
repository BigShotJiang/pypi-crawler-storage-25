"""
Context models for SDK integration.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any


@dataclass
class TenantContext:
    tenant_id: str
    user_id: str
    user_teams: List[str] = field(default_factory=list)
    persona: str = "employee"


@dataclass
class QueryRequest:
    query: str
    tenant_context: TenantContext
    conversation_history: List[Dict[str, str]] = field(default_factory=list)
    live_context: Optional[Dict[str, Any]] = None
    options: Dict[str, Any] = field(default_factory=dict)


@dataclass
class QueryResponse:
    answer: str
    confidence: str
    sources: List[Dict[str, Any]] = field(default_factory=list)
    reasoning: Optional[str] = None
    intent: Optional[str] = None
    trace_id: Optional[str] = None