"""
Telegram message formatters for Neurostack responses.

Handles MarkdownV2 escaping and consistent message layout.
"""

import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

# Characters that must be escaped in Telegram MarkdownV2
_MARKDOWNV2_SPECIAL = r"_*[]()~`>#+-=|{}.!"


class TelegramFormatter:
    """Formats BrainResponse objects into Telegram-friendly MarkdownV2 strings."""

    # Confidence → emoji mapping
    _CONFIDENCE_EMOJI = {
        "high": "\u2705",       # green check
        "medium": "\U0001F7E1",  # yellow circle
        "low": "\u26A0\uFE0F",  # warning sign
    }

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    @staticmethod
    def escape_markdown(text: str) -> str:
        """Escape special characters for Telegram MarkdownV2."""
        result = []
        for ch in text:
            if ch in _MARKDOWNV2_SPECIAL:
                result.append("\\")
            result.append(ch)
        return "".join(result)

    # ------------------------------------------------------------------
    # Response formatters
    # ------------------------------------------------------------------

    def format_answer(self, brain_response: Any) -> str:
        """
        Format a BrainResponse into a Telegram MarkdownV2 message.

        Includes: answer text, confidence indicator, source list,
        and reasoning (collapsed as a quote block).
        """
        parts: list[str] = []

        # --- answer content ---
        answer = getattr(brain_response, "answer", None)
        if answer is not None:
            content = getattr(answer, "content", "")
            confidence_val = getattr(answer, "confidence", None)
            confidence_str = confidence_val.value if hasattr(confidence_val, "value") else str(confidence_val or "")
            emoji = self._CONFIDENCE_EMOJI.get(confidence_str, "")

            parts.append(self.escape_markdown(content))

            if confidence_str:
                parts.append("")
                parts.append(
                    f"{emoji} *Confidence:* {self.escape_markdown(confidence_str)}"
                )

            # --- reasoning (collapsed as blockquote) ---
            reasoning = getattr(answer, "reasoning", None)
            if reasoning:
                parts.append("")
                parts.append("*Reasoning:*")
                for line in reasoning.splitlines():
                    parts.append(f"> {self.escape_markdown(line)}")
        elif hasattr(brain_response, "message") and brain_response.message:
            parts.append(self.escape_markdown(brain_response.message))

        # --- sources ---
        sources = getattr(brain_response, "sources", [])
        if sources:
            parts.append("")
            parts.append("*Sources:*")
            for src in sources:
                title = getattr(src, "title", "Unknown")
                relevance = getattr(src, "relevance_note", "")
                bullet = f"\\- {self.escape_markdown(title)}"
                if relevance:
                    bullet += f" \\({self.escape_markdown(relevance)}\\)"
                parts.append(bullet)

        # --- warnings ---
        warnings = getattr(brain_response, "warnings", [])
        if warnings:
            parts.append("")
            parts.append("\u26A0\uFE0F *Warnings:*")
            for w in warnings:
                parts.append(f"\\- {self.escape_markdown(w)}")

        # --- suggestions ---
        suggestions = getattr(brain_response, "suggestions", [])
        if suggestions:
            parts.append("")
            parts.append("\U0001F4A1 *Suggestions:*")
            for s in suggestions:
                parts.append(f"\\- {self.escape_markdown(s)}")

        if not parts:
            parts.append(self.escape_markdown("No response generated."))

        return "\n".join(parts)

    def format_error(self, error_message: str) -> str:
        """Format an error message for Telegram."""
        escaped = self.escape_markdown(error_message)
        return f"\u274C *Error:* {escaped}"

    def format_welcome(self) -> str:
        """Format the /start welcome message."""
        lines = [
            "*Welcome to Neurostack\\!*",
            "",
            "I\\'m your AI\\-powered knowledge assistant\\.",
            "Ask me anything about your team\\'s projects, policies, or engineering tasks\\.",
            "",
            "*Quick start:*",
            "\\- Just type a question in plain text",
            "\\- Use /ask \\<question\\> for explicit queries",
            "\\- Use /help to see all commands",
        ]
        return "\n".join(lines)

    def format_help(self) -> str:
        """Format the /help command list."""
        lines = [
            "*Available Commands:*",
            "",
            "/start \\- Welcome message and setup",
            "/help \\- Show this command list",
            "/ask \\<question\\> \\- Ask a question explicitly",
            "/status \\- Show knowledge base statistics",
            "",
            "Or simply type your question as a message\\!",
        ]
        return "\n".join(lines)
