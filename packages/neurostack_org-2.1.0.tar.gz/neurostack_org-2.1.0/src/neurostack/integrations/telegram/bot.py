"""
Telegram bot integration for Neurostack.

Uses python-telegram-bot v21+ to handle user messages
and route them through Brain.process().
"""

import logging
from typing import Callable, Dict, Any, Optional

try:
    from telegram import Update
    from telegram.ext import (
        Application,
        CommandHandler,
        MessageHandler,
        ContextTypes,
        filters,
    )
except ImportError:
    raise ImportError(
        "python-telegram-bot is required for Telegram integration. "
        "Install it with: pip install 'python-telegram-bot>=21.0'"
    )

from neurostack.integrations.telegram.formatters import TelegramFormatter

logger = logging.getLogger(__name__)


class TelegramBot:
    """
    Telegram bot that forwards messages to Neurostack Brain
    and returns formatted responses.
    """

    def __init__(
        self,
        token: str,
        brain_process_fn: Callable[[dict], Any],
    ) -> None:
        """
        Args:
            token: Telegram bot API token from @BotFather.
            brain_process_fn: Callable that accepts a raw_request dict
                              and returns a BrainResponse.
        """
        self.token = token
        self.brain_process_fn = brain_process_fn
        self.formatter = TelegramFormatter()

        # In-memory mapping: telegram_user_id -> neurostack user info
        self._user_map: Dict[int, dict] = {}

        self._application: Optional[Application] = None
        logger.info("TelegramBot instance created")

    # ------------------------------------------------------------------
    # User mapping
    # ------------------------------------------------------------------

    def _resolve_user(self, telegram_user_id: int, username: str | None = None) -> dict:
        """
        Resolve a Telegram user to a Neurostack user context.

        On first contact a default mapping is created with
        tenant_id='default' and persona='employee'.
        """
        if telegram_user_id not in self._user_map:
            user_entry = {
                "telegram_user_id": telegram_user_id,
                "username": username or str(telegram_user_id),
                "user_id": f"tg_{telegram_user_id}",
                "tenant_id": "default",
                "persona": "employee",
            }
            self._user_map[telegram_user_id] = user_entry
            logger.info(
                "New Telegram user mapped: telegram_id=%s user_id=%s",
                telegram_user_id,
                user_entry["user_id"],
            )
        return self._user_map[telegram_user_id]

    # ------------------------------------------------------------------
    # Raw request builder
    # ------------------------------------------------------------------

    def _build_raw_request(self, user_input: str, user_info: dict) -> dict:
        """Build a raw_request dict compatible with Brain.process()."""
        return {
            "query": {
                "user_input": user_input,
                "query_id": None,
                "timestamp": None,
            },
            "context": {
                "tenant_id": user_info["tenant_id"],
                "persona": user_info["persona"],
                "user_id": user_info["user_id"],
            },
            "conversation_history": [],
            "live_context": {},
            "options": {
                "mode": "answer",
                "max_retrieval_depth": None,
                "require_sources": True,
            },
        }

    # ------------------------------------------------------------------
    # Handlers
    # ------------------------------------------------------------------

    async def _cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /start command."""
        logger.info("Received /start from user %s", update.effective_user.id)
        self._resolve_user(update.effective_user.id, update.effective_user.username)
        await update.message.reply_text(
            self.formatter.format_welcome(),
            parse_mode="MarkdownV2",
        )

    async def _cmd_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /help command."""
        logger.info("Received /help from user %s", update.effective_user.id)
        await update.message.reply_text(
            self.formatter.format_help(),
            parse_mode="MarkdownV2",
        )

    async def _cmd_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /status command — show knowledge base stats (placeholder)."""
        logger.info("Received /status from user %s", update.effective_user.id)
        text = (
            "*Knowledge Base Status*\n\n"
            "Documents indexed: _coming soon_\n"
            "Last updated: _coming soon_\n"
            "Active tenants: _coming soon_"
        )
        await update.message.reply_text(
            TelegramFormatter.escape_markdown(text),
            parse_mode="MarkdownV2",
        )

    async def _cmd_ask(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /ask <question> command."""
        question = " ".join(context.args) if context.args else ""
        if not question:
            await update.message.reply_text(
                TelegramFormatter.escape_markdown("Usage: /ask <your question>"),
                parse_mode="MarkdownV2",
            )
            return
        logger.info("Received /ask from user %s: %s", update.effective_user.id, question[:80])
        await self._process_and_reply(update, question)

    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle free-text messages."""
        text = update.message.text
        if not text:
            return
        logger.info("Received message from user %s: %s", update.effective_user.id, text[:80])
        await self._process_and_reply(update, text)

    # ------------------------------------------------------------------
    # Core processing
    # ------------------------------------------------------------------

    async def _process_and_reply(self, update: Update, user_input: str) -> None:
        """Resolve user, call brain, format and send response."""
        user_info = self._resolve_user(
            update.effective_user.id,
            update.effective_user.username,
        )
        raw_request = self._build_raw_request(user_input, user_info)

        try:
            brain_response = self.brain_process_fn(raw_request)
            reply = self.formatter.format_answer(brain_response)
        except Exception:
            logger.exception(
                "Brain processing failed for user %s", update.effective_user.id
            )
            reply = self.formatter.format_error("Something went wrong while processing your request.")

        await update.message.reply_text(reply, parse_mode="MarkdownV2")

    # ------------------------------------------------------------------
    # Application lifecycle
    # ------------------------------------------------------------------

    def _build_application(self) -> Application:
        """Create and configure the telegram Application."""
        app = Application.builder().token(self.token).build()

        app.add_handler(CommandHandler("start", self._cmd_start))
        app.add_handler(CommandHandler("help", self._cmd_help))
        app.add_handler(CommandHandler("status", self._cmd_status))
        app.add_handler(CommandHandler("ask", self._cmd_ask))
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))

        logger.info("Telegram application built with all handlers registered")
        return app

    def get_application(self) -> Application:
        """Return (and lazily build) the underlying telegram Application."""
        if self._application is None:
            self._application = self._build_application()
        return self._application

    def run(self) -> None:
        """Start the bot in long-polling mode (blocks)."""
        logger.info("Starting Telegram bot in polling mode")
        app = self.get_application()
        app.run_polling()
