"""
Abstract base class for bot integrations (Slack, Teams, Discord, etc.).
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional

import logging

logger = logging.getLogger("neurostack.integrations")


@dataclass
class BotResponse:
    """Platform-agnostic bot response."""

    text: str
    blocks: Optional[list[dict[str, Any]]] = field(default_factory=list)
    thread_id: Optional[str] = None


class BotIntegration(ABC):
    """
    Abstract base for all chat-platform integrations.

    Subclasses implement platform-specific message handling, user resolution,
    and response formatting while delegating all intelligence to the Brain.
    """

    @abstractmethod
    async def handle_message(
        self,
        platform_user_id: str,
        message_text: str,
        channel_id: Optional[str] = None,
        thread_id: Optional[str] = None,
    ) -> BotResponse:
        """
        Process an incoming message from a chat platform.

        Args:
            platform_user_id: The user's ID on the source platform.
            message_text: Raw message text.
            channel_id: Channel/conversation the message arrived in.
            thread_id: Thread ID for threaded replies.

        Returns:
            BotResponse ready for the platform.
        """

    @abstractmethod
    def format_response(self, brain_response: Any) -> dict:
        """
        Convert a BrainResponse into the platform's native format.

        Args:
            brain_response: The BrainResponse object from brain_manager.process().

        Returns:
            Dict suitable for the platform's send API.
        """

    @abstractmethod
    def resolve_user(self, platform_user_id: str) -> dict:
        """
        Map a platform user ID to a Neurostack identity.

        Returns:
            Dict with keys: user_id, tenant_id, teams, persona.
        """
