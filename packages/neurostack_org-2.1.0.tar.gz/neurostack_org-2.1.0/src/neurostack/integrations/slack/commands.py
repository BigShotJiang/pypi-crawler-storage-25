"""
Slash-command handlers for the /neurostack command in Slack.

Each handler follows the Bolt (ack, command, say) signature with
additional injected dependencies (brain_manager, slack_bot).
"""

import logging
from typing import Any

from .formatters import SlackFormatter

logger = logging.getLogger("neurostack.integrations.slack.commands")


def handle_ask(
    ack: Any,
    command: dict,
    say: Any,
    brain_manager: Any,
    slack_bot: Any,
) -> None:
    """
    /neurostack ask <question>

    Parses the question from the command text, resolves the calling user,
    sends the query to the Brain, and posts a formatted answer.
    """
    ack()

    full_text = (command.get("text") or "").strip()
    # Strip the "ask" prefix
    question = full_text[3:].strip() if full_text.lower().startswith("ask") else full_text

    if not question:
        say(
            blocks=SlackFormatter.format_error("Please provide a question. Usage: `/neurostack ask <question>`"),
            text="Missing question",
        )
        return

    slack_user_id = command.get("user_id", "")
    channel_id = command.get("channel_id", "")

    logger.info(
        "Slash command: ask",
        extra={"slack_user_id": slack_user_id, "question_length": len(question)},
    )

    try:
        user_info = slack_bot.resolve_user(slack_user_id)

        raw_request = {
            "query": {
                "user_input": question,
                "query_id": None,
                "timestamp": None,
            },
            "context": {
                "tenant_id": user_info["tenant_id"],
                "persona": user_info["persona"],
                "user_id": user_info["user_id"],
            },
            "conversation_history": [],
            "live_context": {},
            "options": {
                "mode": "answer",
                "max_retrieval_depth": None,
                "require_sources": True,
            },
        }

        brain_response = brain_manager.process(raw_request)
        blocks = SlackFormatter.format_answer(brain_response)
        answer = getattr(brain_response, "answer", None)
        fallback_text = answer.content if answer else "No answer available."

        say(blocks=blocks, text=fallback_text)

    except Exception:
        logger.exception("Error handling /neurostack ask")
        say(
            blocks=SlackFormatter.format_error("Failed to process your question."),
            text="Error processing question",
        )


def handle_status(
    ack: Any,
    command: dict,
    say: Any,
    brain_manager: Any,
) -> None:
    """
    /neurostack status

    Reports current system health and readiness.
    """
    ack()

    logger.info("Slash command: status", extra={"slack_user_id": command.get("user_id", "")})

    try:
        stats = {
            "brain_ready": brain_manager.brain is not None,
            "version": "1.0.0",
        }
        blocks = SlackFormatter.format_status(stats)
        say(blocks=blocks, text="Neurostack status")

    except Exception:
        logger.exception("Error handling /neurostack status")
        say(
            blocks=SlackFormatter.format_error("Failed to retrieve status."),
            text="Error retrieving status",
        )


def handle_help(
    ack: Any,
    command: dict,
    say: Any,
) -> None:
    """
    /neurostack help

    Displays available commands and usage instructions.
    """
    ack()

    logger.info("Slash command: help", extra={"slack_user_id": command.get("user_id", "")})

    help_blocks = [
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": (
                    "*Neurostack Bot Commands*\n\n"
                    "`/neurostack ask <question>` — Ask a question and get an AI-powered answer with sources.\n"
                    "`/neurostack status` — Check system health and readiness.\n"
                    "`/neurostack help` — Show this help message.\n\n"
                    "You can also *DM the bot* or *@mention* it in a channel to ask questions directly."
                ),
            },
        },
    ]

    say(blocks=help_blocks, text="Neurostack help")
