"""
Slack Block Kit formatters for BrainResponse objects.
"""

import logging
from typing import Any

logger = logging.getLogger("neurostack.integrations.slack.formatters")


class SlackFormatter:
    """Converts BrainResponse data into Slack Block Kit structures."""

    # Confidence -> emoji mapping
    CONFIDENCE_BADGES = {
        "high": ":large_green_circle: High confidence",
        "medium": ":large_yellow_circle: Medium confidence",
        "low": ":red_circle: Low confidence",
    }

    @classmethod
    def format_answer(cls, brain_response: Any) -> list[dict]:
        """
        Build Slack Block Kit blocks from a BrainResponse.

        Args:
            brain_response: BrainResponse from brain_manager.process().

        Returns:
            List of Slack Block Kit block dicts.
        """
        blocks: list[dict] = []

        # --- Main answer ---
        answer = getattr(brain_response, "answer", None)
        if answer and answer.content:
            blocks.append({
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": answer.content,
                },
            })

            # Confidence badge
            confidence_value = (
                answer.confidence.value
                if hasattr(answer.confidence, "value")
                else str(answer.confidence)
            )
            badge = cls.CONFIDENCE_BADGES.get(
                confidence_value, f":white_circle: {confidence_value}"
            )
            blocks.append({
                "type": "context",
                "elements": [
                    {"type": "mrkdwn", "text": badge},
                ],
            })

            # Reasoning (collapsible-ish — Slack has no native collapse,
            # so we put it in a context block that is visually lighter)
            if answer.reasoning:
                blocks.append({"type": "divider"})
                blocks.append({
                    "type": "context",
                    "elements": [
                        {
                            "type": "mrkdwn",
                            "text": f":thought_balloon: *Reasoning:* {answer.reasoning}",
                        }
                    ],
                })

        # --- Sources ---
        sources = getattr(brain_response, "sources", [])
        if sources:
            blocks.append({"type": "divider"})
            source_lines = []
            for idx, src in enumerate(sources[:5], start=1):
                title = getattr(src, "title", "Untitled")
                knowledge_type = getattr(src, "knowledge_type", "unknown")
                relevance = getattr(src, "relevance_note", "")
                line = f"{idx}. *{title}* ({knowledge_type})"
                if relevance:
                    line += f" — _{relevance}_"
                source_lines.append(line)
            blocks.append({
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "*Sources:*\n" + "\n".join(source_lines),
                },
            })

        # --- Conflicts ---
        conflicts = getattr(brain_response, "conflicts", [])
        if conflicts:
            conflict_lines = [
                f":warning: {c.description} — _{c.resolution}_" for c in conflicts
            ]
            blocks.append({
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "*Conflicts detected:*\n" + "\n".join(conflict_lines),
                },
            })

        # --- Warnings ---
        warnings = getattr(brain_response, "warnings", [])
        if warnings:
            blocks.append({
                "type": "context",
                "elements": [
                    {"type": "mrkdwn", "text": ":exclamation: " + " | ".join(warnings)}
                ],
            })

        # --- Suggestions ---
        suggestions = getattr(brain_response, "suggestions", [])
        if suggestions:
            suggestion_text = "\n".join(f"• {s}" for s in suggestions)
            blocks.append({
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": f":bulb: *Suggested follow-ups:*\n{suggestion_text}",
                    }
                ],
            })

        return blocks

    @classmethod
    def format_error(cls, error_message: str) -> list[dict]:
        """
        Format an error for display in Slack.

        Args:
            error_message: Human-readable error description.

        Returns:
            List of Slack Block Kit blocks.
        """
        return [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f":x: *Error:* {error_message}",
                },
            },
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": "If this persists, contact your Neurostack admin.",
                    }
                ],
            },
        ]

    @classmethod
    def format_status(cls, stats: dict) -> list[dict]:
        """
        Format system status for the /neurostack status command.

        Args:
            stats: Dict with status fields (e.g. brain_ready, version, uptime).

        Returns:
            List of Slack Block Kit blocks.
        """
        status_emoji = ":large_green_circle:" if stats.get("brain_ready") else ":red_circle:"
        lines = [
            f"*Neurostack Status* {status_emoji}",
            f"• Brain ready: `{stats.get('brain_ready', 'unknown')}`",
            f"• Version: `{stats.get('version', 'unknown')}`",
        ]
        if "uptime" in stats:
            lines.append(f"• Uptime: `{stats['uptime']}`")
        if "knowledge_sources" in stats:
            lines.append(f"• Knowledge sources loaded: `{stats['knowledge_sources']}`")

        return [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "\n".join(lines),
                },
            }
        ]
