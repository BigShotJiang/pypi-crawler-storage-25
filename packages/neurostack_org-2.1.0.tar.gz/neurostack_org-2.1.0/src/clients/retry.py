"""
Retry utilities for LLM clients.

Implements exponential backoff with jitter for transient errors.
"""

import time
import random
import logging
from typing import Callable, TypeVar, Set

logger = logging.getLogger(__name__)

T = TypeVar("T")

# HTTP status codes that should be retried
RETRYABLE_STATUS_CODES: Set[int] = {429, 500, 502, 503, 504}

# Exceptions that indicate transient errors
RETRYABLE_EXCEPTIONS = (
    ConnectionError,
    TimeoutError,
    OSError,
)


def retry_with_backoff(
    func: Callable[..., T],
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    retryable_exceptions: tuple = RETRYABLE_EXCEPTIONS,
) -> T:
    """
    Execute a function with exponential backoff retry.

    Args:
        func: Callable to execute
        max_retries: Maximum number of retries (default: 3)
        base_delay: Initial delay in seconds (default: 1.0)
        max_delay: Maximum delay cap (default: 30.0)
        retryable_exceptions: Tuple of exception types to retry on

    Returns:
        The return value of func

    Raises:
        The last exception if all retries are exhausted
    """
    last_exception = None

    for attempt in range(max_retries + 1):
        try:
            return func()
        except Exception as e:
            last_exception = e

            # Check if this is a retryable error
            is_retryable = isinstance(e, retryable_exceptions)

            # Check for HTTP status code errors (varies by SDK)
            error_str = str(e).lower()
            if "429" in error_str or "rate limit" in error_str:
                is_retryable = True
            elif any(str(code) in error_str for code in [500, 502, 503, 504]):
                is_retryable = True

            if not is_retryable or attempt >= max_retries:
                raise

            # Calculate delay with jitter
            delay = min(base_delay * (2 ** attempt) + random.uniform(0, 1), max_delay)

            logger.warning(
                f"Retry {attempt + 1}/{max_retries} after {delay:.1f}s "
                f"(error: {type(e).__name__}: {e})"
            )
            time.sleep(delay)

    raise last_exception


class CircuitBreaker:
    """
    Circuit breaker pattern for LLM providers.

    States:
    - CLOSED: Normal operation, requests pass through
    - OPEN: Provider is down, fail fast without calling
    - HALF_OPEN: Testing if provider has recovered
    """

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
        name: str = "default",
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.name = name

        self._state = self.CLOSED
        self._failure_count = 0
        self._last_failure_time = 0.0
        self._success_count = 0

    @property
    def state(self) -> str:
        if self._state == self.OPEN:
            # Check if recovery timeout has passed
            if time.time() - self._last_failure_time >= self.recovery_timeout:
                self._state = self.HALF_OPEN
                logger.info(f"Circuit breaker [{self.name}]: OPEN -> HALF_OPEN")
        return self._state

    def can_execute(self) -> bool:
        """Check if a request can be executed."""
        state = self.state
        if state == self.CLOSED:
            return True
        if state == self.HALF_OPEN:
            return True  # Allow one test request
        return False  # OPEN — fail fast

    def record_success(self):
        """Record a successful call."""
        if self._state == self.HALF_OPEN:
            self._state = self.CLOSED
            self._failure_count = 0
            logger.info(f"Circuit breaker [{self.name}]: HALF_OPEN -> CLOSED")
        self._failure_count = 0

    def record_failure(self):
        """Record a failed call."""
        self._failure_count += 1
        self._last_failure_time = time.time()

        if self._failure_count >= self.failure_threshold:
            self._state = self.OPEN
            logger.warning(
                f"Circuit breaker [{self.name}]: CLOSED -> OPEN "
                f"(failures: {self._failure_count})"
            )

    def __repr__(self):
        return f"CircuitBreaker(name={self.name}, state={self.state}, failures={self._failure_count})"
