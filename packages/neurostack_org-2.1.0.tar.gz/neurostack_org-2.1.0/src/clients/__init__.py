"""
Reference client implementations.

These are minimal working implementations for testing and development.
Production systems should use production-grade clients with proper
error handling, retries, rate limiting, etc.
"""

from .anthropic_llm import AnthropicLLMClient
from .openai_compatible_llm import (
    OpenAICompatibleClient,
    create_groq_client,
    create_nvidia_client,
    create_gemini_client,
    create_ollama_client,
    create_openrouter_client,
)
from .mock_embedding import MockEmbeddingClient, SimpleEmbeddingClient
from .mock_vector_store import MockVectorStore

__all__ = [
    'AnthropicLLMClient',
    'OpenAICompatibleClient',
    'create_groq_client',
    'create_nvidia_client',
    'create_gemini_client',
    'create_ollama_client',
    'create_openrouter_client',
    'MockEmbeddingClient',
    'SimpleEmbeddingClient',
    'MockVectorStore',
]