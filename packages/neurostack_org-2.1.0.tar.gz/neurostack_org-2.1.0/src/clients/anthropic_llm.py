"""
Reference implementation: Anthropic Claude LLM client.

Includes retry with exponential backoff and circuit breaker
for production reliability.
"""

import logging
from typing import List, Optional
import anthropic

from brain.interfaces.llm import LLMClient, LLMMessage, LLMResponse
from clients.retry import retry_with_backoff, CircuitBreaker

logger = logging.getLogger(__name__)


class AnthropicLLMClient:
    """
    Claude LLM client using Anthropic API.

    Implements LLMClient protocol with retry and circuit breaker.
    """

    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-20250514",
        timeout: int = 30,
        max_retries: int = 3,
    ):
        """
        Initialize Anthropic client.

        Args:
            api_key: Anthropic API key
            model: Model identifier
            timeout: Request timeout in seconds
            max_retries: Maximum retry attempts for transient errors
        """
        self.client = anthropic.Anthropic(
            api_key=api_key,
            timeout=timeout
        )
        self.model = model
        self.max_retries = max_retries
        self._circuit_breaker = CircuitBreaker(
            failure_threshold=5,
            recovery_timeout=60.0,
            name="anthropic",
        )

    def complete(
        self,
        messages: List[LLMMessage],
        max_tokens: int = 1000,
        temperature: float = 0.0
    ) -> LLMResponse:
        """
        Generate completion from messages.

        Wraps API call with retry logic and circuit breaker.

        Args:
            messages: Conversation messages
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0.0 = deterministic)

        Returns:
            LLM response

        Raises:
            Exception if API call fails after retries or circuit is open
        """
        # Check circuit breaker
        if not self._circuit_breaker.can_execute():
            raise Exception(
                f"Anthropic circuit breaker is OPEN — provider appears down. "
                f"Will retry after recovery timeout."
            )

        # Convert messages to Anthropic format
        anthropic_messages = []
        system_message = None

        for msg in messages:
            if msg.role == "system":
                system_message = msg.content
            else:
                anthropic_messages.append({
                    "role": msg.role,
                    "content": msg.content
                })

        def _make_api_call() -> LLMResponse:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                temperature=temperature,
                system=system_message if system_message else anthropic.NOT_GIVEN,
                messages=anthropic_messages
            )

            content = response.content[0].text

            return LLMResponse(
                content=content,
                tokens_used=response.usage.input_tokens + response.usage.output_tokens,
                model=self.model
            )

        try:
            result = retry_with_backoff(
                func=_make_api_call,
                max_retries=self.max_retries,
                base_delay=1.0,
                max_delay=30.0,
            )
            self._circuit_breaker.record_success()
            return result
        except Exception as e:
            self._circuit_breaker.record_failure()
            error_str = str(e)
            if isinstance(e, anthropic.APIError):
                raise Exception(f"Anthropic API error: {error_str}") from e
            raise Exception(f"LLM completion failed: {error_str}") from e