"""
OpenAI Embedding Client — production embedding using text-embedding-3-small.
"""

import logging
from typing import List
import httpx

from brain.interfaces.embedding import EmbeddingClient

logger = logging.getLogger(__name__)


class OpenAIEmbeddingClient:
    """OpenAI embedding client using text-embedding-3-small."""

    def __init__(self, api_key: str, model: str = "text-embedding-3-small", dimension: int = 1536):
        self.api_key = api_key
        self.model = model
        self.dimension = dimension
        self._client = httpx.Client(
            base_url="https://api.openai.com/v1",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0,
        )

    def embed(self, text: str) -> List[float]:
        """Embed a single text."""
        response = self._client.post(
            "/embeddings",
            json={"input": text, "model": self.model},
        )
        response.raise_for_status()
        data = response.json()
        return data["data"][0]["embedding"]

    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Embed multiple texts in one call."""
        if not texts:
            return []
        # OpenAI supports batch embedding
        response = self._client.post(
            "/embeddings",
            json={"input": texts, "model": self.model},
        )
        response.raise_for_status()
        data = response.json()
        # Sort by index to maintain order
        sorted_data = sorted(data["data"], key=lambda x: x["index"])
        return [item["embedding"] for item in sorted_data]
