__version__ = "2.2.0.dev20260507"
import os as _os
import sys as _sys

if _sys.platform == "win32" and hasattr(_os, "add_dll_directory"):
    # Collect DLL dirs and register them two ways:
    #   1) os.add_dll_directory  -> honored by LoadLibraryExA(LOAD_LIBRARY_*).
    #   2) prepend to PATH       -> honored by plain LoadLibraryA.
    # Both are needed because LiteRT's C++ shared-library loader falls back to
    # LoadLibraryA when LoadLibraryExA rejects the flag combination used with
    # absolute paths; that fallback only consults PATH, not add_dll_directory.
    _dll_dirs = []
    _pkg_dir = _os.path.dirname(_os.path.abspath(__file__))
    if _os.path.isdir(_pkg_dir):
        _dll_dirs.append(_pkg_dir)
    try:
        import openvino as _ov
        _ov_libs = _os.path.join(_os.path.dirname(_ov.__file__), "libs")
        if _os.path.isdir(_ov_libs):
            _dll_dirs.append(_ov_libs)
    except ImportError:
        pass
    # Register vendor SDK data dirs so in-process dispatch DLLs can resolve
    # vendor-shipped dependencies (e.g. openvino_intel_npu_compiler.dll).
    # The SDK packages also self-register on import; this loop covers the
    # case where the user imports ai_edge_litert before the SDK.
    for _sdk_mod in ("ai_edge_litert_sdk_intel",):
        try:
            _sdk = __import__(_sdk_mod)
        except ImportError:
            continue
        try:
            _sdk_dir = _sdk.path_to_sdk_libs()
        except AttributeError:
            continue
        if _sdk_dir and _os.path.isdir(str(_sdk_dir)):
            _dll_dirs.append(str(_sdk_dir))
    _seen = set()
    for _d in _dll_dirs:
        if _d in _seen:
            continue
        _seen.add(_d)
        try:
            _os.add_dll_directory(_d)
        except OSError:
            pass
    if _dll_dirs:
        _cur_path = _os.environ.get("PATH", "")
        _path_parts = _cur_path.split(_os.pathsep) if _cur_path else []
        _path_lower = {p.lower() for p in _path_parts}
        _new_prefix = [d for d in _dll_dirs if d.lower() not in _path_lower]
        if _new_prefix:
            _os.environ["PATH"] = _os.pathsep.join(_new_prefix + _path_parts)
else:
    _pkg_dir = _os.path.dirname(_os.path.abspath(__file__))
    _litert_so = _os.path.join(_pkg_dir, "libLiteRt.so")
    if _os.path.isfile(_litert_so):
        import ctypes as _ctypes
        _ctypes.CDLL(_litert_so, mode=_os.RTLD_LAZY | _ctypes.RTLD_GLOBAL)
    # Import vendor SDKs so their __init__.py runs (which on Linux copies
    # bundled libraries like libopenvino_intel_npu_compiler.so into their
    # expected locations under openvino/libs/). Silent on ImportError since
    # the SDK packages are optional extras.
    for _sdk_mod in ("ai_edge_litert_sdk_intel",):
        try:
            __import__(_sdk_mod)
        except ImportError:
            pass
