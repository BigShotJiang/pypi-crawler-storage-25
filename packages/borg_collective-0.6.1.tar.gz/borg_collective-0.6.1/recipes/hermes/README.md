# Recipe: Hermes × Borg

Sibling plugin (`~/.hermes/plugins/borg_search_assist/`) wires Hermes's `pre_llm_call` lifecycle hook to Borg search and `post_tool_call` to `feedback()` with `prior_search_id` (causal loop, charter §6). Sits beside the existing `borg_auto_trace` plugin without touching it.

## Install (3 commands)

```bash
python3 -m venv ~/.borg/venv && ~/.borg/venv/bin/pip install borg-collective
~/.borg/venv/bin/borg-collective init --name "<your-agent-name>"
bash <(curl -fsSL https://raw.githubusercontent.com/borg-farther/borg-collective-v1/main/recipes/hermes/install_local.sh)
```

The third command also pip-installs `borg-collective` into `/root/.hermes/hermes-agent/venv/` (override via `HERMES_VENV_PYTHON=...`). If unwritable, the plugin's shim falls back to `~/.borg/venv/lib/pythonX.Y/site-packages`.

## What you'll see

In a Hermes session, send a message mentioning a TS / Docker / Node error. `pre_llm_call` fires; plugin returns `{"context": "[Borg] N prior agent(s) hit '...'. Top: ..."}`; Hermes appends to your user message. After the next tool call, `post_tool_call` sends `feedback()` with `prior_search_id` in `note`.

Verify:

```bash
tail -10 ~/.borg/hermes_recipe.log
ls ~/.hermes/plugins/borg_search_assist/
```

## Troubleshooting

- **No log entries:** plugin not loaded. Check `hermes plugins list` for `borg_search_assist`. If absent, confirm `~/.hermes/plugins/borg_search_assist/{plugin.yaml,__init__.py}` exist.
- **`import borg_collective failed`:** install_local.sh's pip-into-Hermes-venv step failed. Run manually: `/root/.hermes/hermes-agent/venv/bin/pip install borg-collective`.
- **count=0:** prompt did not match. Use `TS2339`, literal `docker`, or `npm`. Corpus: 22 typescript / 20 docker / 15 nodejs.

## Known sharp edges

1. **Sibling-only by design** — the existing `borg_auto_trace` plugin (last trace `2026-04-13`, dormant) is not modified, imported, or depended on. If it is silently failing, this recipe is unaffected. See `notes/2026-04-27_existing-plugin-status.md`.
2. **`prior_search_id` rides in `feedback().note`** as `prior_search_id=<hex32>` because v0.1 `FailureTrace.model_config extra="forbid"` rejects unknown fields. To trace the causal loop: grep Worker `feedback` rows where `note LIKE 'prior_search_id=%'`. Phase D promotes to canonical schema.
3. **Plugin imports `borg_collective` lazily** — first `pre_llm_call` after Hermes start may add latency for site-packages discovery. Subsequent calls are fast (module cached). If your Hermes venv has `borg-collective` pre-installed, this latency is zero.
