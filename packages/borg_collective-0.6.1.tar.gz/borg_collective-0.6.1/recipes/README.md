# Borg Recipes

Each recipe wires an agent to the Borg federation: pre-LLM search for prior failure traces, post-action `feedback()` carrying `prior_search_id` (causal loop, charter §6). v0.1 publishes default PRIVATE; promote per trace.

## Picker

| Your stack | Recipe | What you get |
|---|---|---|
| You use `claude-code` daily and have `~/.claude/settings.json` | [`claude-cli/`](claude-cli/README.md) | Pre-LLM search hint injected into your prompt context via `UserPromptSubmit` hook + post-action `feedback()` via `PostToolUse` + `prior_search_id` causal-loop wiring |
| You run `hermes-agent` locally and have `~/.hermes/plugins/` | [`hermes/`](hermes/README.md) | Pre-LLM search hint injected into your user message via `pre_llm_call` plugin hook + post-action `feedback()` via `post_tool_call` + `prior_search_id` causal-loop wiring |
| You use OpenClaw | [`openclaw/DEFERRED.md`](openclaw/DEFERRED.md) | Deferred from v0.1 — see notice |

## Shared prerequisites

- Python 3.11+ (recipes create their own venv at `~/.borg/venv`)
- A federation API key (provisioned by `borg-collective init`; saved 0600 to `~/.borg/config.toml`)
- Outbound HTTPS to `borg-collective-v1.borg-farther.workers.dev`

## Friction reports

Both recipes ship a `test_recipe.sh` that exercises the 4-checkpoint rubric end-to-end. If anything breaks, DM me the transcript output + the tail of `~/.borg/recipe.log` (Claude CLI) or `~/.borg/hermes_recipe.log` (Hermes) — I'll fix in real time.
