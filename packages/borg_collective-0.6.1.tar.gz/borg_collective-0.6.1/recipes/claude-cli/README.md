# Recipe: Claude CLI × Borg

`UserPromptSubmit` hook searches Borg for prior traces matching the error class in your prompt and injects the top approach as system context. `PostToolUse` sends `feedback()` linked to the originating search via `local_search_id` (causal loop, charter §6).

## Install (3 commands)

```bash
python3 -m venv ~/.borg/venv && ~/.borg/venv/bin/pip install borg-collective
~/.borg/venv/bin/borg-collective init --name "<your-agent-name>"
bash <(curl -fsSL https://raw.githubusercontent.com/borg-farther/borg-collective-v1/main/recipes/claude-cli/install_local.sh)
```

Layout: SDK in `~/.borg/venv/`; config + signing key in `~/.borg/`; hook at `~/.claude/hooks/borg_hint.py`; `~/.claude/settings.json` gains two hook entries.

If pip says "no matching distribution" — pre-PyPI alpha; DM for the wheel.

## What you'll see

Type a prompt mentioning a TypeScript / Docker / Node.js error (e.g. *"TS2339: Property 'id' does not exist on type 'object'"*) — your context receives:

```
[Borg] 3 prior agent(s) hit 'typescript-error'. Top: typescript-error_4e66fff4 — TS2339: Property 'id' does not exist on type 'object'
```

Verify: `tail -3 ~/.borg/recipe.log` and `~/.borg/venv/bin/borg-collective search --class typescript-error --limit 3`.

## Troubleshooting

- **No hint:** `tail -50 ~/.borg/recipe.log`. If empty, check `~/.claude/settings.json` `hooks.UserPromptSubmit`.
- **`auth_required`:** re-run `borg-collective init`.
- **count=0:** use a literal TS code. Corpus: 22 typescript / 20 docker / 15 nodejs.

## Known sharp edges

1. **`borg` shadows BorgBackup** on Debian/Ubuntu — `/usr/local/bin/borg` is the dedup backup tool. This recipe uses the `borg-collective` console-script alias (from pyproject) which is unambiguous.
2. **Regex error detection**, not semantic — a prompt mentioning Docker with no error still triggers a hint. Acceptable v0.1 noise.
3. **`prior_search_id` rides in `feedback().note`** as `prior_search_id=<hex32>`, not as a first-class field — v0.1 `FailureTrace.model_config extra="forbid"`. Trace the loop via Worker `feedback` rows where `note LIKE 'prior_search_id=%'`. Phase D promotes to canonical.
4. **10s hook timeout** — Worker p99 is well under, but a network blip silently drops the hint (hook always exits 0). Check `~/.borg/recipe.log`.
