"""Tests for :class:`borg_collective.OfflineQueue`.

Coverage matrix:

* enqueue → peek → delete round-trip; FIFO ordering across many rows.
* peek with attempt_count secondary sort: deferred rows drift to end.
* mark_attempted increments count + records error (truncated to 500 chars).
* size() before / after enqueue / delete; per-agent filter.
* multi-agent queues coexist; per-agent peek filters.
* max_size cap raises OfflineQueueFull with current_size + max_size set.
* close() is idempotent; further ops on closed queue raise RuntimeError.
* persistence: re-open the same path → same rows still present.
* concurrent enqueue from threads is safe (per-instance lock).
* parent dir is created on first open.
* WAL journal mode is set on connect.
* hex-only firewall: payloads with 64-char signer_pubkey + 128-char
  signature round-trip byte-identical.
* fsync() doesn't raise on a healthy queue, no-ops on a closed one.
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, Any

import pytest

if TYPE_CHECKING:
    from collections.abc import Generator
    from pathlib import Path

from borg_collective._offline import (
    DrainReport,
    OfflineQueue,
)
from borg_collective.exceptions import OfflineError, OfflineQueueFull

HEX_64 = "a" * 64
HEX_128 = "f" * 128


def _payload(error_text: str = "boom", **extras: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "error_text": error_text,
        "task_description": "td",
        "approach_summary": "as",
        "root_cause": "rc",
        "outcome": "resolved",
    }
    base.update(extras)
    return base


@pytest.fixture()
def queue(tmp_path: Path) -> Generator[OfflineQueue, None, None]:
    q = OfflineQueue(tmp_path / "queue.sqlite")
    yield q
    q.close()


# ---------------------------------------------------------------------------
# Round-trip + FIFO
# ---------------------------------------------------------------------------


class TestRoundTrip:
    def test_enqueue_returns_id(self, queue: OfflineQueue) -> None:
        qid = queue.enqueue("agent-1", _payload())
        assert isinstance(qid, int)
        assert qid >= 1

    def test_enqueue_then_peek_returns_payload_intact(self, queue: OfflineQueue) -> None:
        qid = queue.enqueue("agent-1", _payload(error_text="zeta"))
        items = queue.peek()
        assert len(items) == 1
        item = items[0]
        assert item.id == qid
        assert item.agent_id == "agent-1"
        assert item.payload["error_text"] == "zeta"
        assert item.attempt_count == 0
        assert item.last_attempt_at is None
        assert item.last_error is None

    def test_delete_removes_row(self, queue: OfflineQueue) -> None:
        qid = queue.enqueue("agent-1", _payload())
        queue.delete(qid)
        assert queue.peek() == []

    def test_delete_unknown_id_is_noop(self, queue: OfflineQueue) -> None:
        # No row matches; SQLite UPDATE/DELETE silently affects zero rows.
        # The queue should not raise — caller may be racing two drains.
        queue.delete(99999)
        assert queue.peek() == []

    def test_fifo_ordering(self, queue: OfflineQueue) -> None:
        for i in range(5):
            queue.enqueue("agent-1", _payload(error_text=f"e{i}"))
        items = queue.peek(limit=10)
        assert [i.payload["error_text"] for i in items] == [f"e{i}" for i in range(5)]

    def test_peek_limit_caps_results(self, queue: OfflineQueue) -> None:
        for _ in range(5):
            queue.enqueue("agent-1", _payload())
        assert len(queue.peek(limit=3)) == 3

    def test_peek_limit_zero_rejected(self, queue: OfflineQueue) -> None:
        with pytest.raises(ValueError, match="limit"):
            queue.peek(limit=0)


# ---------------------------------------------------------------------------
# attempt_count semantics — deferred rows drift to end
# ---------------------------------------------------------------------------


class TestAttemptCount:
    def test_mark_attempted_increments_count(self, queue: OfflineQueue) -> None:
        qid = queue.enqueue("a", _payload())
        queue.mark_attempted(qid)
        item = queue.peek()[0]
        assert item.attempt_count == 1

    def test_mark_attempted_records_error(self, queue: OfflineQueue) -> None:
        qid = queue.enqueue("a", _payload())
        queue.mark_attempted(qid, error="upstream 503")
        item = queue.peek()[0]
        assert item.last_error == "upstream 503"
        assert item.last_attempt_at is not None
        assert item.last_attempt_at > 0

    def test_mark_attempted_truncates_long_error(self, queue: OfflineQueue) -> None:
        qid = queue.enqueue("a", _payload())
        long_err = "x" * 1000
        queue.mark_attempted(qid, error=long_err)
        item = queue.peek()[0]
        assert item.last_error is not None
        assert len(item.last_error) == 500

    def test_mark_attempted_none_error_clears(self, queue: OfflineQueue) -> None:
        qid = queue.enqueue("a", _payload())
        queue.mark_attempted(qid, error="first")
        queue.mark_attempted(qid, error=None)
        item = queue.peek()[0]
        assert item.last_error is None
        assert item.attempt_count == 2

    def test_deferred_rows_drift_to_end(self, queue: OfflineQueue) -> None:
        """attempt_count is the primary sort key — deferred rows lose
        head-of-line priority to fresh rows."""
        first = queue.enqueue("a", _payload(error_text="first"))
        queue.mark_attempted(first)
        # Fresh row enters with attempt_count=0; should peek before
        # the row that has attempt_count=1.
        queue.enqueue("a", _payload(error_text="fresh"))
        items = queue.peek()
        assert items[0].payload["error_text"] == "fresh"
        assert items[1].payload["error_text"] == "first"


# ---------------------------------------------------------------------------
# size() and per-agent filter
# ---------------------------------------------------------------------------


class TestSize:
    def test_size_zero_on_fresh(self, queue: OfflineQueue) -> None:
        assert queue.size() == 0

    def test_size_grows_with_enqueue(self, queue: OfflineQueue) -> None:
        queue.enqueue("a", _payload())
        queue.enqueue("a", _payload())
        assert queue.size() == 2

    def test_size_shrinks_with_delete(self, queue: OfflineQueue) -> None:
        qid = queue.enqueue("a", _payload())
        queue.enqueue("a", _payload())
        queue.delete(qid)
        assert queue.size() == 1

    def test_size_per_agent_filter(self, queue: OfflineQueue) -> None:
        queue.enqueue("a", _payload())
        queue.enqueue("a", _payload())
        queue.enqueue("b", _payload())
        assert queue.size(agent_id="a") == 2
        assert queue.size(agent_id="b") == 1
        assert queue.size() == 3


class TestMultiAgent:
    def test_peek_filters_by_agent_id(self, queue: OfflineQueue) -> None:
        queue.enqueue("a", _payload(error_text="from-a"))
        queue.enqueue("b", _payload(error_text="from-b"))
        items_a = queue.peek(agent_id="a")
        assert len(items_a) == 1
        assert items_a[0].payload["error_text"] == "from-a"

    def test_unfiltered_peek_returns_all_agents(self, queue: OfflineQueue) -> None:
        queue.enqueue("a", _payload())
        queue.enqueue("b", _payload())
        assert len(queue.peek()) == 2


# ---------------------------------------------------------------------------
# max_size cap
# ---------------------------------------------------------------------------


class TestMaxSize:
    def test_max_size_must_be_positive(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="max_size"):
            OfflineQueue(tmp_path / "q.sqlite", max_size=0)

    def test_enqueue_at_cap_raises(self, tmp_path: Path) -> None:
        q = OfflineQueue(tmp_path / "q.sqlite", max_size=2)
        try:
            q.enqueue("a", _payload())
            q.enqueue("a", _payload())
            with pytest.raises(OfflineQueueFull) as excinfo:
                q.enqueue("a", _payload())
            assert excinfo.value.max_size == 2
            assert excinfo.value.current_size == 2
        finally:
            q.close()

    def test_offline_queue_full_is_offline_error(self, tmp_path: Path) -> None:
        # Subclass relationship — single except OfflineError catches both.
        q = OfflineQueue(tmp_path / "q.sqlite", max_size=1)
        try:
            q.enqueue("a", _payload())
            with pytest.raises(OfflineError):
                q.enqueue("a", _payload())
        finally:
            q.close()

    def test_delete_then_enqueue_after_full_succeeds(self, tmp_path: Path) -> None:
        q = OfflineQueue(tmp_path / "q.sqlite", max_size=1)
        try:
            qid = q.enqueue("a", _payload())
            with pytest.raises(OfflineQueueFull):
                q.enqueue("a", _payload())
            q.delete(qid)
            q.enqueue("a", _payload())  # under cap again, OK
        finally:
            q.close()


# ---------------------------------------------------------------------------
# Lifecycle / close / persistence
# ---------------------------------------------------------------------------


class TestLifecycle:
    def test_close_idempotent(self, tmp_path: Path) -> None:
        q = OfflineQueue(tmp_path / "q.sqlite")
        q.close()
        q.close()  # second close must not raise

    def test_ops_after_close_raise(self, tmp_path: Path) -> None:
        q = OfflineQueue(tmp_path / "q.sqlite")
        q.close()
        with pytest.raises(RuntimeError):
            q.enqueue("a", _payload())
        with pytest.raises(RuntimeError):
            q.peek()
        with pytest.raises(RuntimeError):
            q.size()
        with pytest.raises(RuntimeError):
            q.mark_attempted(1)
        with pytest.raises(RuntimeError):
            q.delete(1)

    def test_context_manager_closes(self, tmp_path: Path) -> None:
        with OfflineQueue(tmp_path / "q.sqlite") as q:
            q.enqueue("a", _payload())
        # Outside the with block, ops must fail.
        with pytest.raises(RuntimeError):
            q.size()

    def test_persistence_across_reopen(self, tmp_path: Path) -> None:
        path = tmp_path / "q.sqlite"
        q1 = OfflineQueue(path)
        q1.enqueue("a", _payload(error_text="persisted"))
        q1.close()

        q2 = OfflineQueue(path)
        try:
            items = q2.peek()
            assert len(items) == 1
            assert items[0].payload["error_text"] == "persisted"
        finally:
            q2.close()

    def test_parent_dir_created_on_first_open(self, tmp_path: Path) -> None:
        path = tmp_path / "deep" / "nested" / "queue.sqlite"
        # Parent doesn't exist.
        assert not path.parent.exists()
        q = OfflineQueue(path)
        try:
            assert path.parent.is_dir()
        finally:
            q.close()


# ---------------------------------------------------------------------------
# WAL mode
# ---------------------------------------------------------------------------


class TestWALMode:
    def test_journal_mode_is_wal(self, tmp_path: Path) -> None:
        q = OfflineQueue(tmp_path / "q.sqlite")
        try:
            # Direct SQLite check; the underlying connection is private
            # but accessing it for verification is the same posture as
            # the rest of the test module.
            cur = q._conn.execute("PRAGMA journal_mode")
            mode = cur.fetchone()[0]
            assert mode.lower() == "wal"
        finally:
            q.close()

    def test_concurrent_enqueue_from_threads_is_safe(self, tmp_path: Path) -> None:
        """Per-instance lock + WAL mode → no SQLite locking errors."""
        q = OfflineQueue(tmp_path / "q.sqlite")
        try:
            errors: list[BaseException] = []

            def worker(n: int) -> None:
                try:
                    for i in range(20):
                        q.enqueue(f"agent-{n}", _payload(error_text=f"{n}-{i}"))
                except BaseException as exc:  # noqa: BLE001
                    errors.append(exc)

            threads = [threading.Thread(target=worker, args=(n,)) for n in range(4)]
            for t in threads:
                t.start()
            for t in threads:
                t.join()
            assert errors == []
            assert q.size() == 80
        finally:
            q.close()


# ---------------------------------------------------------------------------
# Hex-only firewall
# ---------------------------------------------------------------------------


class TestHexPayload:
    def test_payload_with_hex_signature_round_trips_unchanged(self, queue: OfflineQueue) -> None:
        payload = _payload(
            error_signature=HEX_64,
            signer_pubkey=HEX_64,
            signature=HEX_128,
        )
        queue.enqueue("a", payload)
        item = queue.peek()[0]
        assert item.payload["error_signature"] == HEX_64
        assert item.payload["signer_pubkey"] == HEX_64
        assert item.payload["signature"] == HEX_128

    def test_unicode_payload_round_trips(self, queue: OfflineQueue) -> None:
        # ensure_ascii=False on the writer; readback should be identical.
        payload = _payload(error_text="ImportError: module 'café' not found")
        queue.enqueue("a", payload)
        item = queue.peek()[0]
        assert item.payload["error_text"] == "ImportError: module 'café' not found"


# ---------------------------------------------------------------------------
# DrainReport, QueuedItem, fsync
# ---------------------------------------------------------------------------


class TestDrainReport:
    def test_record_error_increments(self) -> None:
        r = DrainReport()
        r.record_error("auth_required")
        r.record_error("auth_required")
        r.record_error(None)
        assert r.errors_by_signature == {"auth_required": 2, "unknown": 1}

    def test_default_counts_zero(self) -> None:
        r = DrainReport()
        assert r.drained == 0
        assert r.failed == 0
        assert r.deferred == 0
        assert r.stopped_early is False


class TestQueuedItemFrozen:
    def test_queued_item_is_frozen(self, queue: OfflineQueue) -> None:
        queue.enqueue("a", _payload())
        item = queue.peek()[0]
        with pytest.raises((AttributeError, TypeError)):
            item.id = 999  # type: ignore[misc]


class TestFsync:
    def test_fsync_on_open_queue_does_not_raise(self, queue: OfflineQueue) -> None:
        queue.enqueue("a", _payload())
        queue.fsync()  # smoke; on a real FS this issues a checkpoint

    def test_fsync_on_closed_queue_is_noop(self, tmp_path: Path) -> None:
        q = OfflineQueue(tmp_path / "q.sqlite")
        q.close()
        q.fsync()  # must not raise


# ---------------------------------------------------------------------------
# Repr never leaks payloads
# ---------------------------------------------------------------------------


class TestRepr:
    def test_repr_does_not_contain_payload_data(self, queue: OfflineQueue) -> None:
        sentinel = "SECRET-PAYLOAD-SENTINEL-XYZ"
        queue.enqueue("a", _payload(error_text=sentinel))
        r = repr(queue)
        assert sentinel not in r
        assert "OfflineQueue" in r
