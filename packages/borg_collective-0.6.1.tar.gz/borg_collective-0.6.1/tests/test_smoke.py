"""Smoke test — proves the package imports and the public surface lock holds.

Tiny by design. Real coverage lands with each subsequent commit. This
file's job is to keep CI honest: an empty test suite is
indistinguishable from a broken one, and a divergent ``__init__.py`` /
``__init__.pyi`` is one of the easiest ways to ship a broken release.
"""

from __future__ import annotations

import borg_collective


def test_version_is_set() -> None:
    assert borg_collective.__version__ == "0.6.1"


def test_public_api_lock() -> None:
    # The "lock" test for __init__.py and __init__.pyi: any expansion of
    # the public surface must update both this expected list and the
    # .pyi stub. Catches a forgotten re-export at CI time.
    expected = [
        "Agent",
        "AgentInfo",
        "AgentPubkey",
        "Amendment",
        "AmendmentCreated",
        "AmendmentInput",
        "AmendmentKind",
        "AsyncClient",
        "AuthError",
        "AutoPublishConfig",
        "BorgError",
        "Client",
        "ConfigError",
        "Counters",
        "DrainReport",
        "DrainResult",
        "FailureTrace",
        "FeedbackAck",
        "FeedbackOutcome",
        "FeedbackRequest",
        "MatchMode",
        "NetworkError",
        "OfflineError",
        "OfflineQueue",
        "OfflineQueueFull",
        "Outcome",
        "Provenance",
        "PublishResult",
        "PublishedTrace",
        "RateLimitError",
        "SearchRequest",
        "SearchResult",
        "SearchResults",
        "ServerError",
        "SignatureError",
        "SigningKeyPair",
        "Trace",
        "TraceDetail",
        "TrustLevel",
        "ValidationError",
        "Visibility",
        "__version__",
        "drain_queue",
        "load_auto_publish_config",
        "load_borg_config",
        "publish_to_federation",
    ]
    assert borg_collective.__all__ == expected


def test_testing_module_importable() -> None:
    """The testing helpers live at borg_collective.testing — opt-in import.

    Not re-exported from the top-level ``__init__`` because most SDK
    consumers don't need the fakes in production. The submodule path
    makes the import intent obvious.
    """
    from borg_collective import testing

    assert hasattr(testing, "FakeClient")
    assert hasattr(testing, "FakeAsyncClient")
    assert hasattr(testing, "RecordedCall")
    assert hasattr(testing, "ClientLike")
    assert hasattr(testing, "AsyncClientLike")
