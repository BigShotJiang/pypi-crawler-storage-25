"""Tests for :mod:`borg_collective.testing` — the SDK's public test doubles.

Coverage matrix:

* FakeClient default responses for every mirrored method.
* FakeClient set_next_response queues and pops in FIFO order.
* FakeClient set_next_exception causes the next call to raise.
* Exception queue takes priority over response queue per call.
* fake.calls reflects every method invocation in order with kwargs.
* fake.calls_for(method) filters correctly.
* set_next_response on an unknown method raises ValueError (typo guard).
* set_next_exception on an unknown method raises ValueError.
* reset() clears calls + queues.
* Context manager + close().
* Structural compatibility: FakeClient passes isinstance(ClientLike).
* AsyncClient mirror: FakeAsyncClient awaitable methods, async context.
* drain() recorded with max_items kwarg.
* AsyncClient structural check: passes isinstance(AsyncClientLike).
"""

from __future__ import annotations

import pytest

from borg_collective import (
    Agent,
    AgentInfo,
    AgentPubkey,
    AmendmentCreated,
    AuthError,
    DrainReport,
    FailureTrace,
    FeedbackAck,
    Outcome,
    PublishedTrace,
    SearchResults,
    TraceDetail,
    ValidationError,
)
from borg_collective.testing import (
    AsyncClientLike,
    ClientLike,
    FakeAsyncClient,
    FakeClient,
    RecordedCall,
)

HEX_64 = "a" * 64


def _trace() -> FailureTrace:
    return FailureTrace(
        error_text="boom",
        task_description="t",
        approach_summary="a",
        root_cause="r",
        outcome=Outcome.RESOLVED,
    )


# ---------------------------------------------------------------------------
# FakeClient — default responses
# ---------------------------------------------------------------------------


class TestDefaultResponses:
    def test_register_agent_default_returns_agent(self) -> None:
        fake = FakeClient()
        agent = fake.register_agent()
        assert isinstance(agent, Agent)

    def test_whoami_default_returns_agent_info(self) -> None:
        fake = FakeClient()
        info = fake.whoami()
        assert isinstance(info, AgentInfo)

    def test_publish_default_returns_published_trace(self) -> None:
        fake = FakeClient()
        published = fake.publish(_trace())
        assert isinstance(published, PublishedTrace)
        assert published.warning == "fake_default"

    def test_get_default_returns_trace_detail(self) -> None:
        fake = FakeClient()
        detail = fake.get("t")
        assert isinstance(detail, TraceDetail)

    def test_search_default_returns_empty_results(self) -> None:
        fake = FakeClient()
        results = fake.search(query="x")
        assert isinstance(results, SearchResults)
        assert results.count == 0

    def test_feedback_default_returns_ack(self) -> None:
        fake = FakeClient()
        ack = fake.feedback("t")
        assert isinstance(ack, FeedbackAck)
        assert ack.recorded is True

    def test_add_amendment_default_returns_created(self) -> None:
        fake = FakeClient()
        amend = fake.add_amendment("t", content="x")
        assert isinstance(amend, AmendmentCreated)

    def test_rotate_pubkey_default_returns_pubkey(self) -> None:
        fake = FakeClient()
        ack = fake.rotate_pubkey(HEX_64)
        assert isinstance(ack, AgentPubkey)

    def test_drain_default_returns_zero_report(self) -> None:
        fake = FakeClient()
        report = fake.drain()
        assert isinstance(report, DrainReport)
        assert report.drained == 0


# ---------------------------------------------------------------------------
# FakeClient — set_next_response
# ---------------------------------------------------------------------------


class TestNextResponseQueue:
    def test_queued_response_returned(self) -> None:
        fake = FakeClient()
        custom = PublishedTrace(trace_id="custom-id", signed=True, error_signature=HEX_64)
        fake.set_next_response("publish", custom)
        published = fake.publish(_trace())
        assert published.trace_id == "custom-id"

    def test_queue_is_fifo(self) -> None:
        fake = FakeClient()
        first = PublishedTrace(trace_id="first", signed=False, error_signature=HEX_64)
        second = PublishedTrace(trace_id="second", signed=False, error_signature=HEX_64)
        fake.set_next_response("publish", first)
        fake.set_next_response("publish", second)
        assert fake.publish(_trace()).trace_id == "first"
        assert fake.publish(_trace()).trace_id == "second"

    def test_queue_exhaustion_falls_back_to_default(self) -> None:
        fake = FakeClient()
        custom = PublishedTrace(trace_id="only", signed=False, error_signature=HEX_64)
        fake.set_next_response("publish", custom)
        assert fake.publish(_trace()).trace_id == "only"
        # Second call has no queued response → default.
        assert fake.publish(_trace()).trace_id == "fake-trace-id"

    def test_unknown_method_in_set_next_response_raises(self) -> None:
        fake = FakeClient()
        with pytest.raises(ValueError, match="unknown method"):
            fake.set_next_response("not_a_method", "anything")

    def test_unknown_method_in_set_next_exception_raises(self) -> None:
        fake = FakeClient()
        with pytest.raises(ValueError, match="unknown method"):
            fake.set_next_exception("not_a_method", AuthError("x", status=401))

    def test_each_method_has_its_own_queue(self) -> None:
        fake = FakeClient()
        publish_resp = PublishedTrace(trace_id="p", signed=False, error_signature=HEX_64)
        fake.set_next_response("publish", publish_resp)
        # Calling whoami() should NOT consume the publish queue.
        fake.whoami()
        assert fake.publish(_trace()).trace_id == "p"


# ---------------------------------------------------------------------------
# FakeClient — set_next_exception
# ---------------------------------------------------------------------------


class TestNextExceptionQueue:
    def test_queued_exception_raised(self) -> None:
        fake = FakeClient()
        fake.set_next_exception("publish", AuthError("nope", status=403))
        with pytest.raises(AuthError):
            fake.publish(_trace())

    def test_exception_takes_priority_over_response(self) -> None:
        fake = FakeClient()
        fake.set_next_response(
            "publish",
            PublishedTrace(trace_id="x", signed=False, error_signature=HEX_64),
        )
        fake.set_next_exception("publish", ValidationError("bad", status=400))
        with pytest.raises(ValidationError):
            fake.publish(_trace())
        # Response is still queued for the next call.
        assert fake.publish(_trace()).trace_id == "x"

    def test_exception_only_raises_once(self) -> None:
        fake = FakeClient()
        fake.set_next_exception("publish", AuthError("x", status=403))
        with pytest.raises(AuthError):
            fake.publish(_trace())
        # Second call uses the default response.
        published = fake.publish(_trace())
        assert published.trace_id == "fake-trace-id"


# ---------------------------------------------------------------------------
# FakeClient — calls log
# ---------------------------------------------------------------------------


class TestCallLog:
    def test_calls_records_method_name(self) -> None:
        fake = FakeClient()
        fake.whoami()
        fake.publish(_trace())
        assert [c.method for c in fake.calls] == ["whoami", "publish"]

    def test_calls_records_kwargs(self) -> None:
        fake = FakeClient()
        fake.search(query="ImportError", limit=25)
        call = fake.calls[0]
        assert isinstance(call, RecordedCall)
        assert call.method == "search"
        assert call.kwargs["query"] == "ImportError"
        assert call.kwargs["limit"] == 25

    def test_calls_for_filters_by_method(self) -> None:
        fake = FakeClient()
        fake.whoami()
        fake.publish(_trace())
        fake.whoami()
        whoami_calls = fake.calls_for("whoami")
        assert len(whoami_calls) == 2
        assert all(c.method == "whoami" for c in whoami_calls)

    def test_call_kwargs_normalised_for_publish(self) -> None:
        fake = FakeClient()
        fake.publish(_trace())
        call = fake.calls_for("publish")[0]
        assert "trace" in call.kwargs
        assert "signing_key" in call.kwargs

    def test_call_kwargs_for_get(self) -> None:
        fake = FakeClient()
        fake.get("trace-xyz")
        call = fake.calls_for("get")[0]
        assert call.kwargs == {"trace_id": "trace-xyz"}

    def test_call_kwargs_for_drain(self) -> None:
        fake = FakeClient()
        fake.drain(max_items=50)
        call = fake.calls_for("drain")[0]
        assert call.kwargs == {"max_items": 50}

    def test_reset_clears_calls_and_queues(self) -> None:
        fake = FakeClient()
        fake.whoami()
        fake.set_next_response(
            "publish",
            PublishedTrace(trace_id="x", signed=False, error_signature=HEX_64),
        )
        fake.reset()
        assert fake.calls == []
        # Queued response is gone — call returns default.
        assert fake.publish(_trace()).trace_id == "fake-trace-id"


# ---------------------------------------------------------------------------
# FakeClient — lifecycle + structural typing
# ---------------------------------------------------------------------------


class TestLifecycle:
    def test_close_marks_closed(self) -> None:
        fake = FakeClient()
        fake.close()
        # No public assertion path other than: no exception. Close is a
        # no-op for the fake (no resources). The recorder is still
        # accessible — by design, so post-test asserts can read calls.
        assert fake.calls == []

    def test_context_manager(self) -> None:
        with FakeClient() as fake:
            fake.whoami()
        assert len(fake.calls) == 1


class TestStructuralTyping:
    def test_fake_client_is_client_like(self) -> None:
        fake = FakeClient()
        assert isinstance(fake, ClientLike)

    def test_fake_client_passes_in_function_typed_against_protocol(self) -> None:
        # The function below is typed against ClientLike (the public
        # Protocol). This test actually runs it with a FakeClient —
        # demonstrating that the fake is a structural drop-in for
        # consumer code.
        def use_client(c: ClientLike) -> AgentInfo:
            return c.whoami()

        fake = FakeClient()
        info = use_client(fake)
        assert isinstance(info, AgentInfo)


# ---------------------------------------------------------------------------
# FakeAsyncClient mirror
# ---------------------------------------------------------------------------


class TestFakeAsyncClient:
    async def test_default_publish_returns_published(self) -> None:
        fake = FakeAsyncClient()
        published = await fake.publish(_trace())
        assert isinstance(published, PublishedTrace)

    async def test_set_next_response_queue(self) -> None:
        fake = FakeAsyncClient()
        custom = PublishedTrace(trace_id="async-x", signed=False, error_signature=HEX_64)
        fake.set_next_response("publish", custom)
        published = await fake.publish(_trace())
        assert published.trace_id == "async-x"

    async def test_set_next_exception(self) -> None:
        fake = FakeAsyncClient()
        fake.set_next_exception("publish", AuthError("nope", status=403))
        with pytest.raises(AuthError):
            await fake.publish(_trace())

    async def test_calls_recorded(self) -> None:
        fake = FakeAsyncClient()
        await fake.whoami()
        await fake.publish(_trace())
        assert [c.method for c in fake.calls] == ["whoami", "publish"]

    async def test_async_context_manager(self) -> None:
        async with FakeAsyncClient() as fake:
            await fake.whoami()
        assert len(fake.calls) == 1

    async def test_aclose_idempotent(self) -> None:
        fake = FakeAsyncClient()
        await fake.aclose()
        await fake.aclose()  # second close must not raise

    async def test_reset_clears_calls(self) -> None:
        fake = FakeAsyncClient()
        await fake.whoami()
        fake.reset()
        assert fake.calls == []

    def test_fake_async_client_is_async_client_like(self) -> None:
        fake = FakeAsyncClient()
        assert isinstance(fake, AsyncClientLike)


# ---------------------------------------------------------------------------
# Method-coverage parity between fake and real client
# ---------------------------------------------------------------------------


class TestMethodParity:
    def test_fake_client_has_every_real_client_method(self) -> None:
        # Defensive: if a future commit adds a Client method but
        # forgets to add it to FakeClient, this test trips.
        from borg_collective import Client

        # The trailing "drain" + "rotate_pubkey" + offline_queue
        # accessor are SDK-only; both fake and real client expose them.
        expected = {
            "register_agent",
            "whoami",
            "publish",
            "get",
            "search",
            "feedback",
            "add_amendment",
            "rotate_pubkey",
            "drain",
            "close",
        }
        for method in expected:
            assert hasattr(Client, method), f"Client lacks {method}"
            assert hasattr(FakeClient, method), f"FakeClient lacks {method}"
