"""Integration-suite-only fixtures: closure-test agent pair.

The closure test needs two agents each with a known Ed25519 keypair.
A's signed publishes are verified locally by B against A's
verify-key hex (held in the keypair we generated for this run);
likewise B holds its own keypair so a future v0.x extension where B
also signs round-trips trivially.

Cached registration
-------------------

Closure-test agents are cached separately from the generic
``BORG_TEST_AGENT_*`` pair used by ``tests/test_integration.py``.
Two reasons:

* The closure test requires signed federation — so each cached agent
  must have a pubkey enrolled. The generic agents in the existing
  integration suite are unsigned (soft-trust, used to exercise the
  ``warning="unsigned_trace"`` path).
* The closure test runs at a different cadence (daily heartbeat vs.
  per-PR integration) and a separate pair lets either be rotated
  without disturbing the other.

Pin a stable pair via::

    BORG_CLOSURE_AGENT_A_ID=<uuid>
    BORG_CLOSURE_AGENT_A_KEY=<64-char hex>
    BORG_CLOSURE_AGENT_B_ID=<uuid>
    BORG_CLOSURE_AGENT_B_KEY=<64-char hex>

When unset, the fixture registers fresh agents (one round-trip per
agent) and emits the env-var lines on stderr so the user can capture
them into their shell rc / CI secrets.
"""

from __future__ import annotations

import os
import sys
from typing import TYPE_CHECKING

import pytest

from borg_collective import Client
from borg_collective._signing import SigningKeyPair

if TYPE_CHECKING:
    from collections.abc import Generator

# Env-var names — kept here as constants so a misspelling at one of
# the four lookup sites is a NameError, not a silent fallback.
_ENV_A_ID = "BORG_CLOSURE_AGENT_A_ID"
_ENV_A_KEY = "BORG_CLOSURE_AGENT_A_KEY"
_ENV_B_ID = "BORG_CLOSURE_AGENT_B_ID"
_ENV_B_KEY = "BORG_CLOSURE_AGENT_B_KEY"


def _cached_or_register(
    *,
    base_url: str,
    env_id: str,
    env_key: str,
    display_name: str,
) -> tuple[str, str, bool]:
    """Return ``(agent_id, api_key, was_registered_fresh)``.

    Honours both env vars when they are present and non-empty;
    otherwise registers a fresh agent against ``base_url``.
    """
    cached_id = os.environ.get(env_id)
    cached_key = os.environ.get(env_key)
    if cached_id and cached_key:
        return cached_id, cached_key, False
    with Client(base_url=base_url) as bootstrap:
        agent = bootstrap.register_agent(display_name=display_name)
    return agent.agent_id, agent.api_key, True


def _enroll_pubkey(*, base_url: str, api_key: str, kp: SigningKeyPair) -> None:
    """Push ``kp.verify_key_hex`` to the Worker for this agent.

    Idempotent server-side (UPDATE … SET pubkey = ?) so calling on
    every run is safe whether the agent is fresh or cached.
    """
    with Client(api_key=api_key, base_url=base_url) as c:
        c.rotate_pubkey(kp.verify_key_hex)


@pytest.fixture(scope="session")
def closure_client_pair(
    integration_base_url: str,
) -> Generator[
    tuple[Client, Client, SigningKeyPair, SigningKeyPair, str, str],
    None,
    None,
]:
    """Return a six-tuple of ``(client_a, client_b, kp_a, kp_b, agent_a_id, agent_b_id)``.

    Both clients are constructed against ``integration_base_url`` and
    have their pubkeys enrolled this session (one extra HTTP call per
    agent — kept out of the per-trial loop to avoid burning the
    pubkey-rotation rate budget). Closes the underlying transports at
    session teardown.
    """
    agent_a_id, api_key_a, fresh_a = _cached_or_register(
        base_url=integration_base_url,
        env_id=_ENV_A_ID,
        env_key=_ENV_A_KEY,
        display_name="closure-a",
    )
    agent_b_id, api_key_b, fresh_b = _cached_or_register(
        base_url=integration_base_url,
        env_id=_ENV_B_ID,
        env_key=_ENV_B_KEY,
        display_name="closure-b",
    )

    if fresh_a or fresh_b:
        # Surface the credentials once on stderr so a CI run can
        # capture them and re-pin without burning a fresh register
        # next time. Do NOT log to stdout (which pytest captures and
        # reports on success) — stderr survives -q.
        print(  # noqa: T201  intentional stderr emit for credential capture
            "\n[closure] freshly registered agents — pin these envs to avoid re-registration:",
            file=sys.stderr,
        )
        if fresh_a:
            print(f"export {_ENV_A_ID}={agent_a_id}", file=sys.stderr)  # noqa: T201
            print(f"export {_ENV_A_KEY}={api_key_a}", file=sys.stderr)  # noqa: T201
        if fresh_b:
            print(f"export {_ENV_B_ID}={agent_b_id}", file=sys.stderr)  # noqa: T201
            print(f"export {_ENV_B_KEY}={api_key_b}", file=sys.stderr)  # noqa: T201

    kp_a = SigningKeyPair.generate()
    kp_b = SigningKeyPair.generate()
    _enroll_pubkey(base_url=integration_base_url, api_key=api_key_a, kp=kp_a)
    _enroll_pubkey(base_url=integration_base_url, api_key=api_key_b, kp=kp_b)

    client_a = Client(api_key=api_key_a, base_url=integration_base_url)
    client_b = Client(api_key=api_key_b, base_url=integration_base_url)
    try:
        yield client_a, client_b, kp_a, kp_b, agent_a_id, agent_b_id
    finally:
        client_a.close()
        client_b.close()
