"""Closure-rate test against the live Borg federation.

The v1 done-gate (see ``docs/closure-test.md``). One assertion:
closure_rate >= 0.95 over N >= 20 trials. A regression below this
threshold is a Sev-1 federation incident — the test must hold against
every shipped Worker version.

Skipped by default. Two opt-in paths:

* ``BORG_CLOSURE_TEST=1 pytest tests/integration/test_closure.py``
* ``pytest -m closure --trials=20``

Override the trial count via ``--trials`` (default 20). The result
artifact is written to ``tests/integration/closure_results.json`` and
committed in v0.1.3 as the first measured run.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import pytest

from borg_collective._closure import run_closure, write_results

if TYPE_CHECKING:
    from borg_collective import Client
    from borg_collective._signing import SigningKeyPair

pytestmark = [pytest.mark.integration, pytest.mark.closure]

# The artifact path is relative to the repo root so the on-disk file
# is checkable into git and discoverable from CI's upload-artifact
# step. Computed once here so test failures and CI both reference the
# same location.
_RESULTS_PATH = Path(__file__).parent / "closure_results.json"

# Headline threshold from spec. Matches docs/closure-test.md §10.
_CLOSURE_RATE_THRESHOLD = 0.95


def test_closure_rate_meets_threshold(
    closure_client_pair: tuple[
        Client,
        Client,
        SigningKeyPair,
        SigningKeyPair,
        str,
        str,
    ],
    integration_base_url: str,
    request: pytest.FixtureRequest,
) -> None:
    """Run N trials and assert closure_rate >= 95% on the live federation."""
    n_trials = int(request.config.getoption("--trials"))
    client_a, client_b, kp_a, kp_b, agent_a_id, agent_b_id = closure_client_pair

    results = run_closure(
        client_a,
        client_b,
        signing_key_a=kp_a,
        signing_key_b=kp_b,
        agent_a_id=agent_a_id,
        agent_b_id=agent_b_id,
        n_trials=n_trials,
        base_url=integration_base_url,
    )

    # Persist before asserting — a failure should leave a forensic
    # artifact behind for diagnosis.
    write_results(results, _RESULTS_PATH)

    assert results.closure_rate >= _CLOSURE_RATE_THRESHOLD, (
        f"closure_rate={results.closure_rate:.2%} below "
        f"{_CLOSURE_RATE_THRESHOLD:.0%} threshold; "
        f"see {_RESULTS_PATH} for trial-by-trial breakdown"
    )
    if results.signature_verification_rate is not None:
        assert results.signature_verification_rate == 1.0, (
            "signature verification must be 100% on signed traces; "
            f"got {results.signature_verification_rate:.2%}"
        )
    assert results.feedback_acceptance_rate == 1.0, (
        "feedback acceptance must be 100%; " f"got {results.feedback_acceptance_rate:.2%}"
    )
