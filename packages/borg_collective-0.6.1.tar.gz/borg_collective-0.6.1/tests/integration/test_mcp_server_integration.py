"""Integration test for the federation MCP server (E1.1).

Hits the live Borg Collective Worker via :class:`AsyncClient`. Skipped
by default — see ``tests/conftest.py``. Opt-in via::

    BORG_INTEGRATION_TEST=1 pytest -m integration tests/integration/test_mcp_server_integration.py

The single end-to-end test:

  1. ``suggest_traces`` against a query that should hit the seed corpus
     (looking for a trace that exists; not asserting *which* one — the
     corpus evolves across sessions).
  2. ``record_failure`` (private visibility, default safety floor).
  3. ``list_my_traces`` finds the freshly-recorded trace_id.
  4. ``delete_trace`` removes it.

This is one test, not a sweep — the goal is "the MCP server's tools
round-trip against prod" not "every behavior under every condition".
Per-tool unit tests live in ``tests/test_mcp_server.py``.
"""

from __future__ import annotations

import os

import pytest

from borg_collective import AsyncClient
from borg_collective.mcp_server import (
    DeleteTraceArgs,
    ListMyTracesArgs,
    RecordFailureArgs,
    SuggestTracesArgs,
    _delete_trace,
    _list_my_traces,
    _record_failure,
    _suggest_traces,
)


@pytest.mark.integration()
@pytest.mark.asyncio()
async def test_mcp_round_trip_against_prod(integration_base_url: str) -> None:
    """suggest_traces, record_failure, list_my_traces, delete_trace E2E."""
    api_key = os.environ.get("BORG_API_KEY")
    if not api_key:
        pytest.skip("BORG_API_KEY not set")

    async with AsyncClient(api_key=api_key, base_url=integration_base_url) as client:
        # 1. suggest_traces — should not error against prod even when the
        #    corpus has zero matches. Empty `suggestions` is a valid result.
        suggested = await _suggest_traces(
            SuggestTracesArgs(task="python module not found ImportError"),
            client,
        )
        assert "suggestions" in suggested
        assert isinstance(suggested["suggestions"], list)

        # 2. record_failure — private (default).
        recorded = await _record_failure(
            RecordFailureArgs(
                trace={
                    "error_text": "MCP-INTEGRATION-PROBE: ModuleNotFoundError",
                    "task_description": "E1.1 integration probe",
                    "approach_summary": "Synthetic trace for the MCP integration test",
                    "root_cause": "Test fixture, not a real failure",
                    "outcome": "resolved",
                    "error_class": "mcp-integration-probe",
                    "tags": ["e1.1", "integration", "ephemeral"],
                },
            ),
            client,
        )
        assert "trace_id" in recorded, recorded
        new_trace_id = recorded["trace_id"]
        assert recorded["visibility"] == "private"

        # 3. list_my_traces — find the freshly-recorded trace.
        listed = await _list_my_traces(
            ListMyTracesArgs(visibility="private", limit=20),
            client,
        )
        ids = [t["trace_id"] for t in listed["traces"]]
        assert new_trace_id in ids, f"{new_trace_id!r} not in {ids!r}"

        # 4. delete_trace — clean up the probe.
        deleted = await _delete_trace(DeleteTraceArgs(trace_id=new_trace_id), client)
        assert deleted["ack"] is True
        # idempotent: a second delete reports already_deleted
        again = await _delete_trace(DeleteTraceArgs(trace_id=new_trace_id), client)
        assert again["ack"] is True
        assert again["already_deleted"] is True
