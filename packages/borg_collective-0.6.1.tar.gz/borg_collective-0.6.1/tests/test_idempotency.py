"""Tests for ``borg_collective._idempotency``.

Asserts:
  - 26 chars, uppercase Crockford alphabet.
  - Time-ordered: ULIDs minted 1 ms apart sort lexically.
  - 10 000 generations are unique (cryptographic randomness).
  - Output contains only Crockford chars — no special characters
    (``+``, ``/``, ``=``, ``-``, ``_``) ever appear, which is the
    firewall-adjacent guard against alternate-encoding leakage.
"""

from __future__ import annotations

import re
from collections import Counter

import pytest

from borg_collective._idempotency import CROCKFORD_ALPHABET, new_ulid

CROCKFORD_RE = re.compile(r"^[0-9A-HJKMNP-TV-Z]{26}$")


def test_ulid_length() -> None:
    assert len(new_ulid()) == 26


def test_ulid_uses_crockford_alphabet_only() -> None:
    u = new_ulid()
    assert CROCKFORD_RE.match(u) is not None
    assert all(c in CROCKFORD_ALPHABET for c in u)


def test_crockford_alphabet_excludes_ambiguous_chars() -> None:
    # Defensive — if someone changes the alphabet, this catches it.
    for forbidden in ("I", "L", "O", "U"):
        assert forbidden not in CROCKFORD_ALPHABET


def test_crockford_alphabet_excludes_alternate_encoding_special_chars() -> None:
    # Firewall-adjacent guard: if any of these special characters sneak
    # into the alphabet, we've been breached at the encoding level, not
    # just at the import level.
    for forbidden in ("+", "/", "=", "-", "_"):
        assert forbidden not in CROCKFORD_ALPHABET


def test_ulids_are_unique_across_10k_generations() -> None:
    seen = {new_ulid() for _ in range(10_000)}
    assert len(seen) == 10_000


def test_ulids_time_ordered_when_minted_at_increasing_timestamps() -> None:
    fixed_rnd = b"\x00" * 10
    earlier = new_ulid(now_ms=1, randomness=fixed_rnd)
    later = new_ulid(now_ms=2, randomness=fixed_rnd)
    assert earlier < later


def test_ulids_time_ordered_at_millisecond_resolution() -> None:
    # Same randomness, 1ms apart — pure ts ordering.
    rnd = b"\xff" * 10
    a = new_ulid(now_ms=1_700_000_000_000, randomness=rnd)
    b = new_ulid(now_ms=1_700_000_000_001, randomness=rnd)
    assert a < b


def test_ulid_is_deterministic_with_injected_inputs() -> None:
    a = new_ulid(now_ms=1, randomness=b"\x00" * 10)
    b = new_ulid(now_ms=1, randomness=b"\x00" * 10)
    assert a == b


def test_ulid_zero_inputs_produce_all_zero_string() -> None:
    # The whole timestamp + randomness is 0 → all-Crockford-zero output.
    # This exercises the encoder with the single corner case where every
    # 5-bit chunk lands on alphabet index 0.
    assert new_ulid(now_ms=0, randomness=b"\x00" * 10) == "0" * 26


def test_ulid_with_max_timestamp_does_not_overflow() -> None:
    # 2^48 - 1 ms — far past Year 10889. Must encode cleanly to 10 chars.
    max_ts = (1 << 48) - 1
    u = new_ulid(now_ms=max_ts, randomness=b"\x00" * 10)
    assert len(u) == 26
    assert CROCKFORD_RE.match(u) is not None


def test_ulid_rejects_negative_timestamp() -> None:
    with pytest.raises(ValueError, match="48-bit range"):
        new_ulid(now_ms=-1, randomness=b"\x00" * 10)


def test_ulid_rejects_overflowing_timestamp() -> None:
    with pytest.raises(ValueError, match="48-bit range"):
        new_ulid(now_ms=1 << 48, randomness=b"\x00" * 10)


def test_ulid_rejects_wrong_length_randomness() -> None:
    with pytest.raises(ValueError, match="exactly 10 bytes"):
        new_ulid(now_ms=0, randomness=b"\x00" * 9)
    with pytest.raises(ValueError, match="exactly 10 bytes"):
        new_ulid(now_ms=0, randomness=b"\x00" * 11)


def test_alphabet_distribution_over_many_generations() -> None:
    # Cheap sanity: across 1000 ULIDs the timestamp prefix is mostly
    # constant, but the 16-char randomness suffix should hit a wide
    # range of Crockford chars. We assert at least 20 distinct chars
    # appear in the suffix population.
    suffixes = "".join(new_ulid()[10:] for _ in range(1000))
    distinct = len(Counter(suffixes))
    assert distinct >= 20
