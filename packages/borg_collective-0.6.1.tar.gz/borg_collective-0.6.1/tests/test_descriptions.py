"""Tests for ADD-3 dual-description machinery in :mod:`mcp_server`.

Covers all three ``BORG_MCP_DESCRIPTIONS`` modes (base / enhanced / both),
graceful fallback when ``tools.enhanced.md`` is missing, and per-tool
fallback when a section is missing from an otherwise-valid file. The
canonical ``_DESCRIPTIONS`` dict in :mod:`mcp_server` stays the single
source of truth for the base text — these tests never write to it.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import pytest

from borg_collective import mcp_server
from borg_collective.mcp_server import (
    _DESCRIPTIONS,
    RecordFailureArgs,
    SuggestTracesArgs,
    _build_tool,
)

if TYPE_CHECKING:
    from pathlib import Path

_FIXTURE_SUGGEST = "FIXTURE_ENHANCED_TEXT_FOR_SUGGEST"
_FIXTURE_RECORD = "FIXTURE_ENHANCED_TEXT_FOR_RECORD"


@pytest.fixture(autouse=True)
def _reset_enhanced_cache(monkeypatch: pytest.MonkeyPatch) -> None:
    """Every test starts with no env var and a cleared enhanced-cache."""
    monkeypatch.delenv("BORG_MCP_DESCRIPTIONS", raising=False)
    monkeypatch.setattr(mcp_server, "_ENHANCED_CACHE", None)


def test_base_mode_default_is_byte_identical() -> None:
    """No env var = canonical _DESCRIPTIONS, byte-for-byte."""
    tool = _build_tool("suggest_traces", SuggestTracesArgs)
    assert tool.description == _DESCRIPTIONS["suggest_traces"]


def test_enhanced_mode_reads_fixture_md(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """BORG_MCP_DESCRIPTIONS=enhanced returns the fixture section text."""
    fixture = tmp_path / "tools.enhanced.md"
    fixture.write_text(
        f"## suggest_traces\n\n{_FIXTURE_SUGGEST}\n\n"
        f"## record_failure\n\n{_FIXTURE_RECORD}\n",
        encoding="utf-8",
    )
    monkeypatch.setenv("BORG_MCP_DESCRIPTIONS", "enhanced")
    monkeypatch.setattr(mcp_server, "_ENHANCED_MD_PATH", fixture)
    monkeypatch.setattr(mcp_server, "_ENHANCED_CACHE", None)

    tool = _build_tool("suggest_traces", SuggestTracesArgs)
    assert tool.description == _FIXTURE_SUGGEST


def test_missing_md_warns_and_falls_back(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Enhanced mode + missing file → WARNING + base description."""
    monkeypatch.setenv("BORG_MCP_DESCRIPTIONS", "enhanced")
    monkeypatch.setattr(
        mcp_server, "_ENHANCED_MD_PATH", tmp_path / "does_not_exist.md",
    )
    monkeypatch.setattr(mcp_server, "_ENHANCED_CACHE", None)

    with caplog.at_level(logging.WARNING, logger="borg_collective.mcp_server"):
        tool = _build_tool("suggest_traces", SuggestTracesArgs)

    assert tool.description == _DESCRIPTIONS["suggest_traces"]
    assert any(
        "tools.enhanced.md" in record.message for record in caplog.records
    ), "expected a warning mentioning tools.enhanced.md"


def test_both_mode_concatenates_base_and_enhanced(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """BORG_MCP_DESCRIPTIONS=both joins base + separator + enhanced."""
    fixture = tmp_path / "tools.enhanced.md"
    fixture.write_text(
        f"## suggest_traces\n\n{_FIXTURE_SUGGEST}\n\n"
        f"## record_failure\n\n{_FIXTURE_RECORD}\n",
        encoding="utf-8",
    )
    monkeypatch.setenv("BORG_MCP_DESCRIPTIONS", "both")
    monkeypatch.setattr(mcp_server, "_ENHANCED_MD_PATH", fixture)
    monkeypatch.setattr(mcp_server, "_ENHANCED_CACHE", None)

    tool = _build_tool("suggest_traces", SuggestTracesArgs)
    expected = (
        _DESCRIPTIONS["suggest_traces"] + "\n\n---\n\n" + _FIXTURE_SUGGEST
    )
    assert tool.description == expected


def test_per_tool_fallback_when_section_missing(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Tool absent from .md → that tool falls back to base; others still enhanced."""
    fixture = tmp_path / "tools.enhanced.md"
    # Only record_failure has a section; suggest_traces is intentionally absent.
    fixture.write_text(
        f"## record_failure\n\n{_FIXTURE_RECORD}\n", encoding="utf-8",
    )
    monkeypatch.setenv("BORG_MCP_DESCRIPTIONS", "enhanced")
    monkeypatch.setattr(mcp_server, "_ENHANCED_MD_PATH", fixture)
    monkeypatch.setattr(mcp_server, "_ENHANCED_CACHE", None)

    suggest = _build_tool("suggest_traces", SuggestTracesArgs)
    record = _build_tool("record_failure", RecordFailureArgs)

    assert suggest.description == _DESCRIPTIONS["suggest_traces"]
    assert record.description == _FIXTURE_RECORD
