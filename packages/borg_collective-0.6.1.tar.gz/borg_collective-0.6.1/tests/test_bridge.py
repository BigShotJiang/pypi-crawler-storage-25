"""Tests for borg_collective._bridge — the E0.7 federation bridge.

Coverage matrix:

* config loader: file-missing, section-missing, default mode, valid
  modes, invalid mode raise.
* publish: false=no-op, success path, validation failure, network
  failure routes to queue, HTTP error routes to queue, visibility
  forced PRIVATE even if caller passes PUBLIC, review mode tags
  needs_review.
* drain: empty queue, single-line success, single-line failure
  (line preserved), partial drain (some succeed some fail).
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest
import respx

from borg_collective import (
    AutoPublishConfig,
    DrainResult,
    PublishResult,
    Visibility,
    drain_queue,
    load_auto_publish_config,
    publish_to_federation,
)

BASE_URL = "https://test.invalid"
API_KEY = "a" * 64
HEX_64 = "a" * 64


def _valid_trace_dict(**overrides):
    base = {
        "error_text": "ENOENT: no such file",
        "task_description": "Launch the MCP server",
        "approach_summary": "spawn python failed",
        "root_cause": "missing python alias on Ubuntu 24.04",
        "outcome": "abandoned",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# load_auto_publish_config
# ---------------------------------------------------------------------------


def test_load_config_file_missing_returns_default(tmp_path: Path) -> None:
    cfg = load_auto_publish_config(tmp_path / "nonexistent.toml")
    assert cfg.mode == "prompt"


def test_load_config_section_missing_returns_default(tmp_path: Path) -> None:
    p = tmp_path / "config.toml"
    p.write_text('api_key = "x"\n', encoding="utf-8")
    cfg = load_auto_publish_config(p)
    assert cfg.mode == "prompt"


@pytest.mark.parametrize("mode", ["false", "prompt", "private", "review"])
def test_load_config_accepts_valid_modes(tmp_path: Path, mode: str) -> None:
    p = tmp_path / "config.toml"
    p.write_text(
        f'[plugin.auto_trace]\nauto_publish = "{mode}"\n',
        encoding="utf-8",
    )
    cfg = load_auto_publish_config(p)
    assert cfg.mode == mode


def test_load_config_rejects_invalid_mode(tmp_path: Path) -> None:
    p = tmp_path / "config.toml"
    p.write_text(
        '[plugin.auto_trace]\nauto_publish = "yolo"\n',
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="auto_publish must be one of"):
        load_auto_publish_config(p)


# ---------------------------------------------------------------------------
# publish_to_federation
# ---------------------------------------------------------------------------


def test_publish_mode_false_is_noop(tmp_path: Path) -> None:
    result = publish_to_federation(
        trace_dict=_valid_trace_dict(),
        config=AutoPublishConfig(mode="false"),
        api_key=API_KEY,
        base_url=BASE_URL,
        queue_path=tmp_path / "q.jsonl",
    )
    assert result.published is False
    assert result.queued is False
    assert not (tmp_path / "q.jsonl").exists()


@respx.mock
def test_publish_success_returns_trace_id(tmp_path: Path) -> None:
    respx.post(f"{BASE_URL}/api/v1/traces").mock(
        return_value=httpx.Response(
            201,
            json={
                "trace_id": "tid_xyz",
                "signed": False,
                "error_signature": HEX_64,
            },
        )
    )
    result = publish_to_federation(
        trace_dict=_valid_trace_dict(),
        config=AutoPublishConfig(mode="private"),
        api_key=API_KEY,
        base_url=BASE_URL,
        queue_path=tmp_path / "q.jsonl",
    )
    assert result.published is True
    assert result.trace_id == "tid_xyz"
    assert result.queued is False


@respx.mock
def test_publish_forces_private_even_when_caller_passes_public(tmp_path: Path) -> None:
    """Defense-in-depth: bridge never publishes public regardless of input."""
    route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
        return_value=httpx.Response(
            201,
            json={
                "trace_id": "tid_xyz",
                "signed": False,
                "error_signature": HEX_64,
            },
        )
    )
    publish_to_federation(
        trace_dict=_valid_trace_dict(visibility=Visibility.PUBLIC.value),
        config=AutoPublishConfig(mode="private"),
        api_key=API_KEY,
        base_url=BASE_URL,
        queue_path=tmp_path / "q.jsonl",
    )
    body = route.calls.last.request.content
    assert b'"visibility": "private"' in body
    assert b'"visibility": "public"' not in body


@respx.mock
def test_publish_review_mode_appends_needs_review_tag(tmp_path: Path) -> None:
    route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
        return_value=httpx.Response(
            201,
            json={
                "trace_id": "tid_xyz",
                "signed": False,
                "error_signature": HEX_64,
            },
        )
    )
    publish_to_federation(
        trace_dict=_valid_trace_dict(tags=["hermes-auto"]),
        config=AutoPublishConfig(mode="review"),
        api_key=API_KEY,
        base_url=BASE_URL,
        queue_path=tmp_path / "q.jsonl",
    )
    body = route.calls.last.request.content
    assert b'"needs_review"' in body
    assert b'"hermes-auto"' in body  # original tag preserved


def test_publish_validation_error_returns_structured_result(tmp_path: Path) -> None:
    """Trace_dict that can't validate as FailureTrace returns
    queued=False with error set — don't queue garbage that will 400 on
    drain.
    """
    bad = {"error_text": "x"}  # missing required fields
    result = publish_to_federation(
        trace_dict=bad,
        config=AutoPublishConfig(mode="private"),
        api_key=API_KEY,
        base_url=BASE_URL,
        queue_path=tmp_path / "q.jsonl",
    )
    assert result.published is False
    assert result.queued is False
    assert result.error is not None
    assert "validation" in result.error
    assert not (tmp_path / "q.jsonl").exists()


@respx.mock
def test_publish_network_error_routes_to_queue(tmp_path: Path) -> None:
    respx.post(f"{BASE_URL}/api/v1/traces").mock(
        side_effect=httpx.ConnectError("connection refused")
    )
    qpath = tmp_path / "q.jsonl"
    result = publish_to_federation(
        trace_dict=_valid_trace_dict(),
        config=AutoPublishConfig(mode="private"),
        api_key=API_KEY,
        base_url=BASE_URL,
        queue_path=qpath,
    )
    assert result.published is False
    assert result.queued is True
    assert qpath.exists()
    line = qpath.read_text(encoding="utf-8").strip()
    body = json.loads(line)
    assert body["error_text"] == "ENOENT: no such file"
    assert body["visibility"] == "private"


@respx.mock
def test_publish_http_5xx_routes_to_queue(tmp_path: Path) -> None:
    respx.post(f"{BASE_URL}/api/v1/traces").mock(
        return_value=httpx.Response(503, json={"error": "unavailable"})
    )
    qpath = tmp_path / "q.jsonl"
    result = publish_to_federation(
        trace_dict=_valid_trace_dict(),
        config=AutoPublishConfig(mode="private"),
        api_key=API_KEY,
        base_url=BASE_URL,
        queue_path=qpath,
    )
    assert result.queued is True
    assert qpath.exists()


# ---------------------------------------------------------------------------
# drain_queue
# ---------------------------------------------------------------------------


def test_drain_empty_queue_returns_zeros(tmp_path: Path) -> None:
    result = drain_queue(
        api_key=API_KEY,
        base_url=BASE_URL,
        queue_path=tmp_path / "q.jsonl",
    )
    assert result == DrainResult(total=0, published=0, still_queued=0)


@respx.mock
def test_drain_single_line_success_removes_file(tmp_path: Path) -> None:
    qpath = tmp_path / "q.jsonl"
    body = {**_valid_trace_dict(), "visibility": "private"}
    qpath.write_text(json.dumps(body) + "\n", encoding="utf-8")
    respx.post(f"{BASE_URL}/api/v1/traces").mock(
        return_value=httpx.Response(
            201,
            json={
                "trace_id": "drained_1",
                "signed": False,
                "error_signature": HEX_64,
            },
        )
    )
    result = drain_queue(
        api_key=API_KEY,
        base_url=BASE_URL,
        queue_path=qpath,
    )
    assert result == DrainResult(total=1, published=1, still_queued=0)
    assert not qpath.exists()


@respx.mock
def test_drain_single_line_failure_keeps_file(tmp_path: Path) -> None:
    qpath = tmp_path / "q.jsonl"
    body = {**_valid_trace_dict(), "visibility": "private"}
    qpath.write_text(json.dumps(body) + "\n", encoding="utf-8")
    respx.post(f"{BASE_URL}/api/v1/traces").mock(
        side_effect=httpx.ConnectError("still down")
    )
    result = drain_queue(
        api_key=API_KEY,
        base_url=BASE_URL,
        queue_path=qpath,
    )
    assert result == DrainResult(total=1, published=0, still_queued=1)
    assert qpath.exists()
