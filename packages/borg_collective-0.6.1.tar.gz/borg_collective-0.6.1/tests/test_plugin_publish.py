"""Tests for the borg_auto_trace plugin's federation publish path.

Strategy: import the plugin module via sys.path manipulation
(``~/.hermes/plugins/borg_auto_trace/``), construct a fake session
with messages containing FAILURE tokens, call ``on_session_end``,
assert that ``publish_to_federation`` was called with the right
visibility/shape. No Hermes harness needed.
"""

from __future__ import annotations

import importlib
import sys
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

PLUGIN_DIR = Path("/root/.hermes/plugins/borg_auto_trace")


@pytest.fixture
def plugin():
    """Import the borg_auto_trace plugin fresh, isolated per test."""
    sys.path.insert(0, str(PLUGIN_DIR.parent))
    if "borg_auto_trace" in sys.modules:
        del sys.modules["borg_auto_trace"]
    mod = importlib.import_module("borg_auto_trace")
    yield mod
    sys.modules.pop("borg_auto_trace", None)
    if str(PLUGIN_DIR.parent) in sys.path:
        sys.path.remove(str(PLUGIN_DIR.parent))


def _seed_failure_session(plugin) -> None:
    """Populate plugin's _auto_state with 3 tool calls ending in FAILURE."""
    plugin._auto_state.reset()
    plugin._auto_state.task_desc = "Launch the MCP server on Ubuntu 24.04"
    plugin._auto_state.tool_calls = [
        {"name": "Bash", "args": {"command": "python --version"}, "result": "/usr/bin/python: not found", "started_at": 0, "completed_at": 1},
        {"name": "Read", "args": {"path": "/etc/os-release"}, "result": "Ubuntu 24.04", "started_at": 1, "completed_at": 2},
        {"name": "Bash", "args": {"command": "spawn python"}, "result": "ENOENT: traceback ImportError", "started_at": 2, "completed_at": 3},
    ]


def _seed_success_session(plugin) -> None:
    plugin._auto_state.reset()
    plugin._auto_state.task_desc = "Run the test suite"
    plugin._auto_state.tool_calls = [
        {"name": "Bash", "args": {"command": "pytest"}, "result": "10 passed", "started_at": 0, "completed_at": 1},
        {"name": "Read", "args": {"path": "/log"}, "result": "ok", "started_at": 1, "completed_at": 2},
        {"name": "Bash", "args": {"command": "echo done"}, "result": "completed successfully", "started_at": 2, "completed_at": 3},
    ]


def test_session_end_with_failure_calls_publish(plugin) -> None:
    """A session ending in FAILURE triggers publish_to_federation."""
    _seed_failure_session(plugin)
    fake_publish = MagicMock(return_value=plugin.PublishResult(
        published=True, trace_id="published_xyz",
    ) if hasattr(plugin, "PublishResult") else None)
    # Patch the bridge symbol the plugin imported.
    with patch.object(plugin, "publish_to_federation", fake_publish), \
         patch.object(plugin, "_FEDERATION_AVAILABLE", True), \
         patch.object(plugin, "_read_borg_credentials", return_value=("test_key", "https://test.invalid")), \
         patch.object(plugin, "_trace_save", MagicMock(return_value="local_abc")), \
         patch.object(plugin, "_borg_initialized", True):
        plugin.on_session_end("test-session", messages=[])
    assert fake_publish.called, "publish_to_federation must fire on FAILURE"
    call_kwargs = fake_publish.call_args.kwargs
    assert "trace_dict" in call_kwargs
    assert call_kwargs["api_key"] == "test_key"
    assert call_kwargs["base_url"] == "https://test.invalid"


def test_session_end_with_success_does_not_publish(plugin) -> None:
    """A success session writes locally but never federates."""
    _seed_success_session(plugin)
    fake_publish = MagicMock()
    with patch.object(plugin, "publish_to_federation", fake_publish), \
         patch.object(plugin, "_FEDERATION_AVAILABLE", True), \
         patch.object(plugin, "_read_borg_credentials", return_value=("test_key", "https://test.invalid")), \
         patch.object(plugin, "_trace_save", MagicMock(return_value="local_abc")), \
         patch.object(plugin, "_borg_initialized", True):
        plugin.on_session_end("test-session", messages=[])
    assert not fake_publish.called, "success session must not publish"


def test_session_end_publish_uses_private_visibility_always(plugin) -> None:
    """The plugin's federation trace dict must NOT carry PUBLIC visibility.

    The bridge module also forces PRIVATE, but defense-in-depth: the
    plugin's own dict construction never declares public.
    """
    _seed_failure_session(plugin)
    fake_publish = MagicMock(return_value=plugin.PublishResult(
        published=True, trace_id="x",
    ))
    with patch.object(plugin, "publish_to_federation", fake_publish), \
         patch.object(plugin, "_FEDERATION_AVAILABLE", True), \
         patch.object(plugin, "_read_borg_credentials", return_value=("k", "u")), \
         patch.object(plugin, "_trace_save", MagicMock(return_value="local_abc")), \
         patch.object(plugin, "_borg_initialized", True):
        plugin.on_session_end("s", messages=[])
    call_kwargs = fake_publish.call_args.kwargs
    trace = call_kwargs["trace_dict"]
    assert trace.get("visibility") in (None, "private"), trace.get("visibility")


def test_session_end_local_save_happens_before_federation_post(plugin) -> None:
    """save_trace is called BEFORE publish_to_federation. Local-first."""
    _seed_failure_session(plugin)
    call_order: list[str] = []
    save_mock = MagicMock(side_effect=lambda *a, **kw: call_order.append("save") or "local_id")
    publish_mock = MagicMock(side_effect=lambda *a, **kw: call_order.append("publish") or plugin.PublishResult(published=True, trace_id="x"))
    with patch.object(plugin, "publish_to_federation", publish_mock), \
         patch.object(plugin, "_FEDERATION_AVAILABLE", True), \
         patch.object(plugin, "_read_borg_credentials", return_value=("k", "u")), \
         patch.object(plugin, "_trace_save", save_mock), \
         patch.object(plugin, "_borg_initialized", True):
        plugin.on_session_end("s", messages=[])
    assert call_order == ["save", "publish"]


def test_session_end_local_save_succeeds_even_if_federation_fails(plugin) -> None:
    """Federation publish failure must not abort the local save path.

    The plugin should not raise. _auto_state.reset() runs in finally.
    """
    _seed_failure_session(plugin)
    save_mock = MagicMock(return_value="local_id")
    # publish_to_federation should never raise (bridge contract), but
    # if it does, the plugin's wrapper catches it.
    publish_mock = MagicMock(side_effect=RuntimeError("bridge bug"))
    with patch.object(plugin, "publish_to_federation", publish_mock), \
         patch.object(plugin, "_FEDERATION_AVAILABLE", True), \
         patch.object(plugin, "_read_borg_credentials", return_value=("k", "u")), \
         patch.object(plugin, "_trace_save", save_mock), \
         patch.object(plugin, "_borg_initialized", True):
        plugin.on_session_end("s", messages=[])
    assert save_mock.called, "local save still happens"
    # State reset (finally clause).
    assert plugin._auto_state.tool_calls == []


def test_plugin_loads_when_borg_collective_unavailable(plugin) -> None:
    """If borg_collective is missing, plugin still loads in local-only mode."""
    # The plugin already imported successfully under the test fixture,
    # which proves it loads. Simulate missing federation:
    with patch.object(plugin, "_FEDERATION_AVAILABLE", False):
        _seed_failure_session(plugin)
        save_mock = MagicMock(return_value="local_id")
        with patch.object(plugin, "_trace_save", save_mock), \
             patch.object(plugin, "_borg_initialized", True):
            # No exception expected even with publish bridge unavailable.
            plugin.on_session_end("s", messages=[])
    assert save_mock.called
