"""Tests for :mod:`borg_collective._transport`.

Coverage matrix (kept here as a comment for the next reader):

* Status → exception mapping for 400, 401, 403, 422 (signature),
  422 (other), 429, 408, 5xx, plus 2xx success.
* 429 retry-after / bucket parsing edge cases.
* Retry budget for transient transport exceptions and 502/503/504.
* No-retry for 4xx and signature errors.
* ConfigError raised before any network call when api_key absent.
* Auth header / User-Agent on every request.
* Repr never leaks api_key.
* Body never logged.
* AsyncTransport mirrors Transport (status map + retry).

Tests use respx so nothing hits the network. The base_url is a stable
fake (``https://test.invalid``) — keeps respx route patterns short and
makes it obvious in tracebacks that we are not pointing at the live
Worker.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

import httpx
import pytest
import respx

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator, Generator

from borg_collective._transport import (
    AUTH_HEADER,
    USER_AGENT,
    AsyncTransport,
    Transport,
    _backoff_delay,
)
from borg_collective.exceptions import (
    AuthError,
    ConfigError,
    NetworkError,
    RateLimitError,
    ServerError,
    SignatureError,
    ValidationError,
)

BASE_URL = "https://test.invalid"
TEST_API_KEY = "a" * 64  # shape doesn't matter to the transport itself


# ---------------------------------------------------------------------------
# Fixtures.
# ---------------------------------------------------------------------------


@pytest.fixture()
def transport() -> Generator[Transport, None, None]:
    """A Transport with retries + backoff dialed down for tests.

    ``backoff_base_s=0`` means retry tests don't actually sleep — keeps
    the suite fast without mocking ``time.sleep``.
    """
    t = Transport(
        api_key=TEST_API_KEY,
        base_url=BASE_URL,
        backoff_base_s=0.0,
    )
    yield t
    t.close()


@pytest.fixture()
def unauth_transport() -> Generator[Transport, None, None]:
    """Transport with no api_key, for ConfigError + unauth-call tests."""
    t = Transport(api_key=None, base_url=BASE_URL, backoff_base_s=0.0)
    yield t
    t.close()


def _err_envelope(error_code: str, **extras: Any) -> dict[str, Any]:
    return {"error": error_code, "request_id": "req_test", **extras}


# ---------------------------------------------------------------------------
# Status-code → exception mapping.
# ---------------------------------------------------------------------------


class TestStatusMapping:
    @respx.mock
    def test_2xx_returns_parsed_body(self, transport: Transport) -> None:
        respx.get(f"{BASE_URL}/health").mock(
            return_value=httpx.Response(200, json={"ok": True, "status": "ok"})
        )
        result = transport.request("GET", "/health", auth_required=False)
        assert result == {"ok": True, "status": "ok"}

    @respx.mock
    def test_201_returns_parsed_body(self, transport: Transport) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(201, json={"trace_id": "tid_xyz", "signed": False})
        )
        result = transport.request("POST", "/api/v1/traces", json={"x": 1})
        assert result["trace_id"] == "tid_xyz"

    @respx.mock
    def test_400_raises_validation_error(self, transport: Transport) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                400, json=_err_envelope("missing_field", field="error_text")
            )
        )
        with pytest.raises(ValidationError) as exc_info:
            transport.request("POST", "/api/v1/traces", json={})
        exc = exc_info.value
        assert exc.status == 400
        assert exc.error_code == "missing_field"
        assert exc.details == {"field": "error_text"}

    @respx.mock
    def test_401_raises_auth_error(self, transport: Transport) -> None:
        respx.get(f"{BASE_URL}/api/v1/traces/x").mock(
            return_value=httpx.Response(401, json=_err_envelope("auth_required"))
        )
        with pytest.raises(AuthError) as exc_info:
            transport.request("GET", "/api/v1/traces/x")
        assert exc_info.value.status == 401
        assert exc_info.value.error_code == "auth_required"

    @respx.mock
    def test_403_raises_auth_error(self, transport: Transport) -> None:
        respx.get(f"{BASE_URL}/api/v1/traces/x").mock(
            return_value=httpx.Response(403, json=_err_envelope("invalid_key"))
        )
        with pytest.raises(AuthError) as exc_info:
            transport.request("GET", "/api/v1/traces/x")
        assert exc_info.value.status == 403
        assert exc_info.value.error_code == "invalid_key"

    @respx.mock
    def test_422_bad_signature_raises_signature_error(self, transport: Transport) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(422, json=_err_envelope("bad_signature"))
        )
        with pytest.raises(SignatureError) as exc_info:
            transport.request("POST", "/api/v1/traces", json={})
        exc = exc_info.value
        # SignatureError IS a ValidationError subclass — both isinstance
        # checks must hold so callers can branch either way.
        assert isinstance(exc, ValidationError)
        assert exc.status == 422
        assert exc.error_code == "bad_signature"

    @respx.mock
    def test_422_non_signature_raises_validation_error(self, transport: Transport) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(422, json=_err_envelope("some_other_422_code"))
        )
        with pytest.raises(ValidationError) as exc_info:
            transport.request("POST", "/api/v1/traces", json={})
        # Specifically NOT a SignatureError.
        assert not isinstance(exc_info.value, SignatureError)
        assert exc_info.value.status == 422
        assert exc_info.value.error_code == "some_other_422_code"

    @respx.mock
    def test_500_raises_server_error(self, transport: Transport) -> None:
        respx.get(f"{BASE_URL}/api/v1/traces/x").mock(
            return_value=httpx.Response(500, json=_err_envelope("internal"))
        )
        with pytest.raises(ServerError) as exc_info:
            transport.request("GET", "/api/v1/traces/x")
        assert exc_info.value.status == 500
        assert exc_info.value.error_code == "internal"

    @respx.mock
    def test_408_raises_network_error_no_retry(self, transport: Transport) -> None:
        # 408 maps to NetworkError per spec but is NOT retried.
        route = respx.get(f"{BASE_URL}/api/v1/traces/x").mock(return_value=httpx.Response(408))
        with pytest.raises(NetworkError):
            transport.request("GET", "/api/v1/traces/x")
        assert route.call_count == 1

    @respx.mock
    def test_unexpected_3xx_or_unknown_4xx_raises_server_error(self, transport: Transport) -> None:
        # follow_redirects defaults to False on httpx.Client, so a 3xx
        # surfaces directly. We classify it as ServerError (typed surface)
        # rather than letting an opaque RuntimeError out.
        respx.get(f"{BASE_URL}/api/v1/traces/x").mock(
            return_value=httpx.Response(307, headers={"Location": "/elsewhere"})
        )
        with pytest.raises(ServerError) as exc_info:
            transport.request("GET", "/api/v1/traces/x")
        assert exc_info.value.status == 307


# ---------------------------------------------------------------------------
# Rate limit handling.
# ---------------------------------------------------------------------------


class TestRateLimit:
    @respx.mock
    def test_429_with_retry_after_header(self, transport: Transport) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                429,
                headers={"Retry-After": "37"},
                json=_err_envelope("rate_limit_exceeded", bucket="publish", retry_after_s=37),
            )
        )
        with pytest.raises(RateLimitError) as exc_info:
            transport.request("POST", "/api/v1/traces", json={})
        exc = exc_info.value
        assert exc.retry_after_s == 37
        assert exc.bucket == "publish"
        assert exc.status == 429

    @respx.mock
    def test_429_bucket_from_body_overrides_header(self, transport: Transport) -> None:
        # Worker emits bucket in body. If both are present, body wins
        # (it's the canonical Worker contract).
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                429,
                headers={
                    "Retry-After": "10",
                    "X-RateLimit-Bucket": "header-bucket",
                },
                json=_err_envelope("rate_limit_exceeded", bucket="body-bucket", retry_after_s=10),
            )
        )
        with pytest.raises(RateLimitError) as exc_info:
            transport.request("POST", "/api/v1/traces", json={})
        assert exc_info.value.bucket == "body-bucket"

    @respx.mock
    def test_429_bucket_falls_back_to_header_then_unknown(self, transport: Transport) -> None:
        # No body bucket → check header.
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                429,
                headers={"Retry-After": "5", "X-RateLimit-Bucket": "from-header"},
                json={"error": "rate_limit_exceeded", "request_id": "r"},
            )
        )
        with pytest.raises(RateLimitError) as exc_info:
            transport.request("POST", "/api/v1/traces", json={})
        assert exc_info.value.bucket == "from-header"

    @respx.mock
    def test_429_bucket_unknown_when_neither_present(self, transport: Transport) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                429,
                headers={"Retry-After": "5"},
                json={"error": "rate_limit_exceeded", "request_id": "r"},
            )
        )
        with pytest.raises(RateLimitError) as exc_info:
            transport.request("POST", "/api/v1/traces", json={})
        assert exc_info.value.bucket == "unknown"

    @respx.mock
    def test_429_retry_after_falls_back_to_body(self, transport: Transport) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                429,
                json=_err_envelope("rate_limit_exceeded", bucket="publish", retry_after_s=42),
            )
        )
        with pytest.raises(RateLimitError) as exc_info:
            transport.request("POST", "/api/v1/traces", json={})
        assert exc_info.value.retry_after_s == 42

    @respx.mock
    def test_429_retry_after_unparseable_falls_back_to_zero(self, transport: Transport) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                429,
                headers={"Retry-After": "Tue, 01 Jan 2030 00:00:00 GMT"},
                json={
                    "error": "rate_limit_exceeded",
                    "bucket": "publish",
                    "request_id": "r",
                },
            )
        )
        with pytest.raises(RateLimitError) as exc_info:
            transport.request("POST", "/api/v1/traces", json={})
        # HTTP-date is unparseable; no retry_after_s in body either.
        assert exc_info.value.retry_after_s == 0

    @respx.mock
    def test_429_not_retried(self, transport: Transport) -> None:
        # 429 is a definitive answer ("you exceeded the bucket"); the
        # SDK does not auto-sleep + retry — that's caller policy.
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                429,
                headers={"Retry-After": "1"},
                json=_err_envelope("rate_limit_exceeded", bucket="publish", retry_after_s=1),
            )
        )
        with pytest.raises(RateLimitError):
            transport.request("POST", "/api/v1/traces", json={})
        assert route.call_count == 1


# ---------------------------------------------------------------------------
# Retry behaviour.
# ---------------------------------------------------------------------------


class TestRetry:
    @respx.mock
    def test_503_503_200_succeeds_on_third_attempt(self, transport: Transport) -> None:
        route = respx.get(f"{BASE_URL}/api/v1/x").mock(
            side_effect=[
                httpx.Response(503, json=_err_envelope("upstream_down")),
                httpx.Response(503, json=_err_envelope("upstream_down")),
                httpx.Response(200, json={"ok": True}),
            ]
        )
        result = transport.request("GET", "/api/v1/x")
        assert result == {"ok": True}
        assert route.call_count == 3

    @respx.mock
    def test_503_503_503_raises_after_three_attempts(self, transport: Transport) -> None:
        route = respx.get(f"{BASE_URL}/api/v1/x").mock(
            return_value=httpx.Response(503, json=_err_envelope("upstream_down"))
        )
        with pytest.raises(ServerError) as exc_info:
            transport.request("GET", "/api/v1/x")
        assert exc_info.value.status == 503
        assert route.call_count == 3

    @respx.mock
    def test_502_504_treated_as_retryable(self, transport: Transport) -> None:
        route = respx.get(f"{BASE_URL}/api/v1/x").mock(
            side_effect=[
                httpx.Response(502, json=_err_envelope("bad_gateway")),
                httpx.Response(504, json=_err_envelope("gateway_timeout")),
                httpx.Response(200, json={"ok": True}),
            ]
        )
        result = transport.request("GET", "/api/v1/x")
        assert result == {"ok": True}
        assert route.call_count == 3

    @respx.mock
    def test_400_not_retried(self, transport: Transport) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                400, json=_err_envelope("missing_field", field="error_text")
            )
        )
        with pytest.raises(ValidationError):
            transport.request("POST", "/api/v1/traces", json={})
        assert route.call_count == 1

    @respx.mock
    def test_401_not_retried(self, transport: Transport) -> None:
        route = respx.get(f"{BASE_URL}/api/v1/traces/x").mock(
            return_value=httpx.Response(401, json=_err_envelope("auth_required"))
        )
        with pytest.raises(AuthError):
            transport.request("GET", "/api/v1/traces/x")
        assert route.call_count == 1

    @respx.mock
    def test_signature_error_not_retried(self, transport: Transport) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(422, json=_err_envelope("bad_signature"))
        )
        with pytest.raises(SignatureError):
            transport.request("POST", "/api/v1/traces", json={})
        assert route.call_count == 1

    @respx.mock
    def test_500_not_retried(self, transport: Transport) -> None:
        # 500 is "internal error", treated as definitive (not 502/503/504).
        route = respx.get(f"{BASE_URL}/api/v1/x").mock(
            return_value=httpx.Response(500, json=_err_envelope("internal"))
        )
        with pytest.raises(ServerError):
            transport.request("GET", "/api/v1/x")
        assert route.call_count == 1

    @respx.mock
    def test_connect_error_retries_then_raises_network_error(self, transport: Transport) -> None:
        route = respx.get(f"{BASE_URL}/api/v1/x").mock(
            side_effect=httpx.ConnectError("dns failure")
        )
        with pytest.raises(NetworkError) as exc_info:
            transport.request("GET", "/api/v1/x")
        assert isinstance(exc_info.value.cause, httpx.ConnectError)
        assert route.call_count == 3

    @respx.mock
    def test_read_timeout_retries_then_raises_network_error(self, transport: Transport) -> None:
        route = respx.get(f"{BASE_URL}/api/v1/x").mock(
            side_effect=httpx.ReadTimeout("read timed out")
        )
        with pytest.raises(NetworkError) as exc_info:
            transport.request("GET", "/api/v1/x")
        assert isinstance(exc_info.value.cause, httpx.ReadTimeout)
        assert route.call_count == 3

    @respx.mock
    def test_transient_then_success(self, transport: Transport) -> None:
        route = respx.get(f"{BASE_URL}/api/v1/x").mock(
            side_effect=[
                httpx.ConnectError("transient"),
                httpx.Response(200, json={"ok": True}),
            ]
        )
        assert transport.request("GET", "/api/v1/x") == {"ok": True}
        assert route.call_count == 2

    def test_invalid_url_not_retried(self) -> None:
        # InvalidURL is a RequestError but NOT a TransportError. Surface
        # immediately as NetworkError without retry. No respx because
        # there's no httpx request — the URL fails to parse client-side.
        bad = Transport(
            api_key=TEST_API_KEY,
            base_url="not-a-url",
            backoff_base_s=0.0,
        )
        try:
            with pytest.raises(NetworkError):
                bad.request("GET", "/health", auth_required=False)
        finally:
            bad.close()


# ---------------------------------------------------------------------------
# Auth / config.
# ---------------------------------------------------------------------------


class TestAuth:
    def test_config_error_when_no_api_key_on_authed_call(self, unauth_transport: Transport) -> None:
        # No httpx mock — ConfigError MUST be raised before any network
        # call. respx.mock would error on an unmocked call, which is
        # itself a useful guard.
        with pytest.raises(ConfigError):
            unauth_transport.request("POST", "/api/v1/traces", json={})

    @respx.mock
    def test_no_config_error_when_auth_not_required(self, unauth_transport: Transport) -> None:
        respx.get(f"{BASE_URL}/health").mock(return_value=httpx.Response(200, json={"ok": True}))
        # Should NOT raise — health is auth-exempt.
        result = unauth_transport.request("GET", "/health", auth_required=False)
        assert result == {"ok": True}

    @respx.mock
    def test_auth_header_added_on_every_request(self, transport: Transport) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(201, json={"trace_id": "t"})
        )
        transport.request("POST", "/api/v1/traces", json={"x": 1})
        transport.request("POST", "/api/v1/traces", json={"x": 2})
        for call in route.calls:
            assert call.request.headers[AUTH_HEADER] == TEST_API_KEY

    @respx.mock
    def test_no_auth_header_when_unauth_transport(self, unauth_transport: Transport) -> None:
        route = respx.get(f"{BASE_URL}/health").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        unauth_transport.request("GET", "/health", auth_required=False)
        assert AUTH_HEADER not in route.calls.last.request.headers

    @respx.mock
    def test_user_agent_on_every_request(self, transport: Transport) -> None:
        route = respx.get(f"{BASE_URL}/health").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        transport.request("GET", "/health", auth_required=False)
        assert route.calls.last.request.headers["User-Agent"] == USER_AGENT

    @respx.mock
    def test_caller_headers_merged(self, transport: Transport) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(201, json={"trace_id": "t"})
        )
        transport.request(
            "POST",
            "/api/v1/traces",
            json={"x": 1},
            headers={"X-Idempotency-Key": "ik_abc"},
        )
        assert route.calls.last.request.headers["X-Idempotency-Key"] == "ik_abc"
        # Auth header still injected.
        assert route.calls.last.request.headers[AUTH_HEADER] == TEST_API_KEY


# ---------------------------------------------------------------------------
# Repr safety + body-not-logged.
# ---------------------------------------------------------------------------


class TestSafety:
    def test_repr_does_not_contain_api_key(self) -> None:
        t = Transport(api_key="super-secret-key-xyz", base_url=BASE_URL)
        try:
            r = repr(t)
            assert "super-secret-key-xyz" not in r
            # And not the prefix either, in case someone truncates.
            assert "super-secret" not in r
            assert "set" in r  # informative without leaking.
        finally:
            t.close()

    def test_repr_when_api_key_none(self) -> None:
        t = Transport(api_key=None, base_url=BASE_URL)
        try:
            assert "unset" in repr(t)
        finally:
            t.close()

    @respx.mock
    def test_request_body_not_logged_at_debug(
        self, transport: Transport, caplog: pytest.LogCaptureFixture
    ) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(201, json={"trace_id": "t"})
        )
        # Sentinel string the test searches for in every log record's
        # message + __dict__. Not a real credential — the variable name
        # would otherwise trip ruff S105.
        sentinel = "SENTINEL-payload-that-must-never-appear-in-logs"
        with caplog.at_level(logging.DEBUG, logger="borg_collective.transport"):
            transport.request(
                "POST",
                "/api/v1/traces",
                json={"error_text": sentinel},
            )
        for record in caplog.records:
            assert sentinel not in record.getMessage()
            for value in record.__dict__.values():
                assert sentinel not in str(value)

    @respx.mock
    def test_request_body_not_logged_on_failure(
        self, transport: Transport, caplog: pytest.LogCaptureFixture
    ) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(400, json=_err_envelope("missing_field"))
        )
        sentinel = "SENTINEL-on-failure-path"
        with (
            caplog.at_level(logging.WARNING, logger="borg_collective.transport"),
            pytest.raises(ValidationError),
        ):
            transport.request(
                "POST",
                "/api/v1/traces",
                json={"error_text": sentinel},
            )
        for record in caplog.records:
            assert sentinel not in record.getMessage()
            for value in record.__dict__.values():
                assert sentinel not in str(value)


# ---------------------------------------------------------------------------
# Body parsing edge cases.
# ---------------------------------------------------------------------------


class TestBodyParsing:
    @respx.mock
    def test_non_json_4xx_body_falls_back(self, transport: Transport) -> None:
        respx.get(f"{BASE_URL}/api/v1/x").mock(
            return_value=httpx.Response(
                400, content=b"<html>bad</html>", headers={"Content-Type": "text/html"}
            )
        )
        with pytest.raises(ValidationError) as exc_info:
            transport.request("GET", "/api/v1/x")
        assert exc_info.value.error_code is None
        assert "<html>" in exc_info.value.message

    @respx.mock
    def test_non_json_4xx_body_truncated_to_200(self, transport: Transport) -> None:
        big = "x" * 1000
        respx.get(f"{BASE_URL}/api/v1/x").mock(
            return_value=httpx.Response(400, content=big.encode())
        )
        with pytest.raises(ValidationError) as exc_info:
            transport.request("GET", "/api/v1/x")
        assert len(exc_info.value.message) == 200

    @respx.mock
    def test_2xx_empty_body_returns_empty_dict(self, transport: Transport) -> None:
        respx.delete(f"{BASE_URL}/api/v1/x").mock(return_value=httpx.Response(204))
        result = transport.request("DELETE", "/api/v1/x")
        assert result == {}

    @respx.mock
    def test_2xx_non_json_body_raises_server_error(self, transport: Transport) -> None:
        respx.get(f"{BASE_URL}/api/v1/x").mock(
            return_value=httpx.Response(
                200, content=b"plain text", headers={"Content-Type": "text/plain"}
            )
        )
        with pytest.raises(ServerError):
            transport.request("GET", "/api/v1/x")

    @respx.mock
    def test_2xx_non_object_body_raises_server_error(self, transport: Transport) -> None:
        respx.get(f"{BASE_URL}/api/v1/x").mock(return_value=httpx.Response(200, json=[1, 2, 3]))
        with pytest.raises(ServerError):
            transport.request("GET", "/api/v1/x")


# ---------------------------------------------------------------------------
# Backoff helper.
# ---------------------------------------------------------------------------


class TestBackoff:
    def test_backoff_schedule(self) -> None:
        # Spec calls for 0.5s then 1.5s before the second + third
        # attempts (zero before the first). Geometric base*3**n.
        assert _backoff_delay(0, 0.5) == pytest.approx(0.5)
        assert _backoff_delay(1, 0.5) == pytest.approx(1.5)
        assert _backoff_delay(2, 0.5) == pytest.approx(4.5)


# ---------------------------------------------------------------------------
# Constructor validation.
# ---------------------------------------------------------------------------


class TestConstructor:
    def test_max_retries_must_be_positive(self) -> None:
        with pytest.raises(ValueError, match="max_retries"):
            Transport(api_key=TEST_API_KEY, base_url=BASE_URL, max_retries=0)

    def test_backoff_base_must_be_non_negative(self) -> None:
        with pytest.raises(ValueError, match="backoff_base_s"):
            Transport(
                api_key=TEST_API_KEY,
                base_url=BASE_URL,
                backoff_base_s=-0.1,
            )

    def test_base_url_trailing_slash_stripped(self) -> None:
        t = Transport(
            api_key=TEST_API_KEY,
            base_url=BASE_URL + "/",
            backoff_base_s=0.0,
        )
        try:
            with respx.mock:
                respx.get(f"{BASE_URL}/health").mock(
                    return_value=httpx.Response(200, json={"ok": True})
                )
                # If trailing slash weren't stripped we'd hit
                # BASE_URL + "//health" and respx would 404.
                assert t.request("GET", "/health", auth_required=False) == {"ok": True}
        finally:
            t.close()


# ---------------------------------------------------------------------------
# Async transport — mirrors sync behaviour.
# ---------------------------------------------------------------------------


@pytest.fixture()
async def async_transport() -> AsyncGenerator[AsyncTransport, None]:
    t = AsyncTransport(
        api_key=TEST_API_KEY,
        base_url=BASE_URL,
        backoff_base_s=0.0,
    )
    yield t
    await t.aclose()


class TestAsyncTransport:
    @respx.mock
    async def test_2xx_returns_parsed_body(self, async_transport: AsyncTransport) -> None:
        respx.get(f"{BASE_URL}/health").mock(return_value=httpx.Response(200, json={"ok": True}))
        result = await async_transport.request("GET", "/health", auth_required=False)
        assert result == {"ok": True}

    @respx.mock
    async def test_400_raises_validation_error(self, async_transport: AsyncTransport) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(400, json=_err_envelope("missing_field"))
        )
        with pytest.raises(ValidationError):
            await async_transport.request("POST", "/api/v1/traces", json={})

    @respx.mock
    async def test_422_bad_signature_raises_signature_error(
        self, async_transport: AsyncTransport
    ) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(422, json=_err_envelope("bad_signature"))
        )
        with pytest.raises(SignatureError):
            await async_transport.request("POST", "/api/v1/traces", json={})

    @respx.mock
    async def test_429_rate_limit(self, async_transport: AsyncTransport) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                429,
                headers={"Retry-After": "5"},
                json=_err_envelope("rate_limit_exceeded", bucket="publish", retry_after_s=5),
            )
        )
        with pytest.raises(RateLimitError) as exc_info:
            await async_transport.request("POST", "/api/v1/traces", json={})
        assert exc_info.value.retry_after_s == 5
        assert exc_info.value.bucket == "publish"

    @respx.mock
    async def test_503_retried_then_success(self, async_transport: AsyncTransport) -> None:
        route = respx.get(f"{BASE_URL}/api/v1/x").mock(
            side_effect=[
                httpx.Response(503, json=_err_envelope("upstream_down")),
                httpx.Response(503, json=_err_envelope("upstream_down")),
                httpx.Response(200, json={"ok": True}),
            ]
        )
        assert await async_transport.request("GET", "/api/v1/x") == {"ok": True}
        assert route.call_count == 3

    @respx.mock
    async def test_503_retried_then_raises_after_three(
        self, async_transport: AsyncTransport
    ) -> None:
        respx.get(f"{BASE_URL}/api/v1/x").mock(
            return_value=httpx.Response(503, json=_err_envelope("upstream_down"))
        )
        with pytest.raises(ServerError):
            await async_transport.request("GET", "/api/v1/x")

    @respx.mock
    async def test_connect_error_retried_then_network_error(
        self, async_transport: AsyncTransport
    ) -> None:
        respx.get(f"{BASE_URL}/api/v1/x").mock(side_effect=httpx.ConnectError("boom"))
        with pytest.raises(NetworkError) as exc_info:
            await async_transport.request("GET", "/api/v1/x")
        assert isinstance(exc_info.value.cause, httpx.ConnectError)

    async def test_config_error_when_no_api_key(self) -> None:
        t = AsyncTransport(api_key=None, base_url=BASE_URL, backoff_base_s=0.0)
        try:
            with pytest.raises(ConfigError):
                await t.request("POST", "/api/v1/traces", json={})
        finally:
            await t.aclose()

    @respx.mock
    async def test_auth_header_added(self, async_transport: AsyncTransport) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(201, json={"trace_id": "t"})
        )
        await async_transport.request("POST", "/api/v1/traces", json={"x": 1})
        assert route.calls.last.request.headers[AUTH_HEADER] == TEST_API_KEY

    @respx.mock
    async def test_user_agent(self, async_transport: AsyncTransport) -> None:
        route = respx.get(f"{BASE_URL}/health").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        await async_transport.request("GET", "/health", auth_required=False)
        assert route.calls.last.request.headers["User-Agent"] == USER_AGENT

    def test_repr_does_not_contain_api_key(self) -> None:
        t = AsyncTransport(api_key="super-secret-async-key", base_url=BASE_URL)
        r = repr(t)
        assert "super-secret-async-key" not in r
        assert "AsyncTransport" in r
