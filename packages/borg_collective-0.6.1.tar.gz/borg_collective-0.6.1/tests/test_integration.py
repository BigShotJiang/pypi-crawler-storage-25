"""Integration tests against the live Borg Collective Worker.

Skipped by default. Run with::

    BORG_INTEGRATION_TEST=1 pytest tests/test_integration.py -v

Override the Worker URL via ``BORG_TEST_BASE_URL`` to point at
``wrangler dev`` or a staging deploy.

Rate-limit budget
-----------------

The Worker enforces ``5 register attempts / 3600 s`` per source IP
(spec §D-4 ``register:ip:<ip>``). Naively, this entire suite would
need 17+ fresh agents — a guaranteed 429 cascade. We share 3
session-scoped fixtures across all tests:

* ``agent_a`` — primary publisher / requester (most tests).
* ``agent_b`` — second-agent role for trust-boundary + amendment-
  by-non-owner tests.
* ``fresh_rate_limit_agent`` — function-scope, used only by the
  rate-limit test which deliberately exhausts the publish bucket.

Cross-run credential cache
~~~~~~~~~~~~~~~~~~~~~~~~~~

Even 3 fresh registers per run is brittle if the suite is re-run
within ~12 min after a failed run (5/3600s sliding window means
slots refill one at a time). Solution: ``agent_a`` and ``agent_b``
read api_keys from env vars when present, falling back to a fresh
register otherwise. Pin a stable pair via::

    BORG_TEST_AGENT_A_KEY=<64-char hex>
    BORG_TEST_AGENT_A_ID=<uuid>
    BORG_TEST_AGENT_B_KEY=<64-char hex>
    BORG_TEST_AGENT_B_ID=<uuid>

The rate-limit test always uses a fresh register — its bucket
exhaustion would corrupt any cached agent.

Each test aims for ≤30 s wall-clock; ``test_rate_limit_*`` may run
110 publishes and so takes longer.
"""

from __future__ import annotations

import os
import re
import threading
import time
from typing import TYPE_CHECKING, Any

import pytest

if TYPE_CHECKING:
    from pathlib import Path

from borg_collective import (
    Client,
    FailureTrace,
    NetworkError,
    OfflineQueue,
    Outcome,
    RateLimitError,
    ValidationError,
    Visibility,
)
from borg_collective._signing import SigningKeyPair
from borg_collective.models import AmendmentKind, FeedbackOutcome, SearchRequest

HEX_64_RE = re.compile(r"^[0-9a-f]{64}$")
HEX_128_RE = re.compile(r"^[0-9a-f]{128}$")

pytestmark = pytest.mark.integration


def _trace(**overrides: Any) -> FailureTrace:
    base: dict[str, Any] = {
        "error_text": "IntegrationError: round-trip test",
        "task_description": "exercise the wire contract",
        "approach_summary": "publish then retrieve",
        "root_cause": "the suite is doing its job",
        "outcome": Outcome.RESOLVED,
        "error_class": "IntegrationError",
        "tags": ["integration"],
        "visibility": Visibility.PRIVATE,
    }
    base.update(overrides)
    return FailureTrace(**base)


# ---------------------------------------------------------------------------
# Session-scoped fixtures (3 registers total).
# ---------------------------------------------------------------------------


def _agent_from_env_or_register(
    *,
    base_url: str,
    env_id: str,
    env_key: str,
    display_name: str,
) -> tuple[str, str]:
    """Honour ``$env_id`` + ``$env_key`` if both set, else register fresh."""
    cached_id = os.environ.get(env_id)
    cached_key = os.environ.get(env_key)
    if cached_id and cached_key:
        return cached_id, cached_key
    with Client(base_url=base_url) as bootstrap:
        agent = bootstrap.register_agent(display_name=display_name)
    return agent.agent_id, agent.api_key


@pytest.fixture(scope="session")
def agent_a(integration_base_url: str) -> tuple[str, str]:
    """Pre-registered agent A — primary publisher / requester.

    Honours ``BORG_TEST_AGENT_A_ID`` + ``BORG_TEST_AGENT_A_KEY`` so
    re-runs against a recently-rate-limited IP work without burning
    a fresh register slot.
    """
    return _agent_from_env_or_register(
        base_url=integration_base_url,
        env_id="BORG_TEST_AGENT_A_ID",
        env_key="BORG_TEST_AGENT_A_KEY",
        display_name="integration-a",
    )


@pytest.fixture(scope="session")
def agent_b(integration_base_url: str) -> tuple[str, str]:
    """Pre-registered agent B — second-agent role.

    Honours ``BORG_TEST_AGENT_B_ID`` + ``BORG_TEST_AGENT_B_KEY``.
    """
    return _agent_from_env_or_register(
        base_url=integration_base_url,
        env_id="BORG_TEST_AGENT_B_ID",
        env_key="BORG_TEST_AGENT_B_KEY",
        display_name="integration-b",
    )


@pytest.fixture()
def fresh_rate_limit_agent(integration_base_url: str) -> tuple[str, str]:
    """Fresh agent for the rate-limit test only — needs a full publish bucket."""
    with Client(base_url=integration_base_url) as bootstrap:
        agent = bootstrap.register_agent(display_name=f"rl-{int(time.time())}")
    return agent.agent_id, agent.api_key


# ---------------------------------------------------------------------------
# 1. Full round-trip
# ---------------------------------------------------------------------------


def test_full_round_trip_signed(
    agent_a: tuple[str, str],
    integration_base_url: str,
) -> None:
    """register → whoami → publish (signed) → get → search → feedback
    → amend → get-with-amendment."""
    agent_id, api_key = agent_a
    kp = SigningKeyPair.generate()

    with Client(api_key=api_key, base_url=integration_base_url) as c:
        me = c.whoami()
        assert me.agent_id == agent_id
        assert me.trust_level == "soft"

        c.rotate_pubkey(kp.verify_key_hex)
        published = c.publish(
            _trace(
                error_text=f"round-trip signed {time.time_ns()}",
                tags=["integration", "round-trip"],
            ),
            signing_key=kp,
        )
        assert published.signed is True
        assert HEX_64_RE.fullmatch(published.error_signature)

        detail = c.get(published.trace_id)
        assert detail.trace.trace_id == published.trace_id
        assert detail.trace.signed is True
        assert detail.trace.signature is not None
        assert HEX_128_RE.fullmatch(detail.trace.signature)
        assert detail.counters.retrieved == 1

        results = c.search(error_signature=published.error_signature)
        assert results.count >= 1
        assert any(r.trace_id == published.trace_id for r in results.results)

        ack = c.feedback(
            published.trace_id,
            retrieved=True,
            read=True,
            applied=True,
            outcome=FeedbackOutcome.HELPED,
        )
        assert ack.recorded is True
        assert ack.counters_updated is True

        amended = c.add_amendment(
            published.trace_id,
            content="this is the right approach",
            kind=AmendmentKind.RESOLUTION,
        )
        assert amended.kind is AmendmentKind.RESOLUTION

        post_amend = c.get(published.trace_id)
        assert any(a.amendment_id == amended.amendment_id for a in post_amend.amendments)


# ---------------------------------------------------------------------------
# 2. Concurrent publishes from one agent (D1 race coverage)
# ---------------------------------------------------------------------------


def test_concurrent_publishes_one_agent(
    agent_a: tuple[str, str],
    integration_base_url: str,
) -> None:
    """5 threads x 2 publishes each → all 10 retrievable via search.

    Originally specced as 5 fresh agents in parallel; that hit the
    Worker's IP-register cap (5/3600). One agent with concurrent
    publishes still exercises D1 row-races, which is the point.
    """
    _, api_key = agent_a
    n_threads = 5
    per_thread = 2
    tag = f"concurrent-pub-{int(time.time())}"
    published_ids: list[str] = []
    lock = threading.Lock()

    def _do_one(thread_idx: int) -> None:
        with Client(api_key=api_key, base_url=integration_base_url) as c:
            for j in range(per_thread):
                pub = c.publish(
                    _trace(
                        error_text=f"concurrent t{thread_idx} {j} {time.time_ns()}",
                        tags=["integration", tag],
                        visibility=Visibility.PUBLIC,
                    )
                )
                with lock:
                    published_ids.append(pub.trace_id)

    threads = [threading.Thread(target=_do_one, args=(i,)) for i in range(n_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert len(published_ids) == n_threads * per_thread
    assert len(set(published_ids)) == n_threads * per_thread, "duplicate trace_ids"

    with Client(api_key=api_key, base_url=integration_base_url) as c:
        results = c.search(tags=[tag], limit=50)
    found = {r.trace_id for r in results.results}
    missing = set(published_ids) - found
    assert not missing, f"missing {missing} from search by tag {tag!r}"


# ---------------------------------------------------------------------------
# 3. Offline-then-online drain
# ---------------------------------------------------------------------------


def test_offline_then_online_drain(
    agent_a: tuple[str, str],
    integration_base_url: str,
    tmp_path: Path,
) -> None:
    """Publish 10 in offline_mode → drain online → all 10 retrievable."""
    _, api_key = agent_a
    queue_path = tmp_path / "drain.sqlite"
    drain_tag = f"offline-drain-{int(time.time())}"

    with Client(
        api_key=api_key,
        base_url=integration_base_url,
        offline_mode=True,
        offline_queue_path=queue_path,
    ) as offline:
        for i in range(10):
            pub = offline.publish(
                _trace(
                    error_text=f"offline trace {i} {time.time_ns()}",
                    tags=["integration", drain_tag],
                    visibility=Visibility.PRIVATE,
                )
            )
            assert pub.trace_id.startswith("local:")
        assert offline.offline_queue is not None
        assert offline.offline_queue.size() == 10

    with Client(
        api_key=api_key,
        base_url=integration_base_url,
        offline_queue_path=queue_path,
    ) as online:
        report = online.drain()
        assert report.drained == 10
        assert report.failed == 0
        assert report.deferred == 0
        assert online.offline_queue is not None
        assert online.offline_queue.size() == 0
        results = online.search(tags=[drain_tag], limit=20)
    assert results.count >= 10


# ---------------------------------------------------------------------------
# 4. Pubkey rotation
# ---------------------------------------------------------------------------


def test_pubkey_rotation(
    agent_a: tuple[str, str],
    integration_base_url: str,
) -> None:
    """key A → publish A → rotate to key B → publish B; both verify."""
    _, api_key = agent_a
    kp_a = SigningKeyPair.generate()
    kp_b = SigningKeyPair.generate()

    with Client(api_key=api_key, base_url=integration_base_url) as c:
        c.rotate_pubkey(kp_a.verify_key_hex)
        pub_a = c.publish(
            _trace(error_text=f"signed by key A {time.time_ns()}"),
            signing_key=kp_a,
        )
        assert pub_a.signed is True

        c.rotate_pubkey(kp_b.verify_key_hex)
        me = c.whoami()
        assert me.pubkey == kp_b.verify_key_hex

        pub_b = c.publish(
            _trace(error_text=f"signed by key B {time.time_ns()}"),
            signing_key=kp_b,
        )
        assert pub_b.signed is True

        detail_a = c.get(pub_a.trace_id)
        detail_b = c.get(pub_b.trace_id)
    assert detail_a.trace.signer_pubkey == kp_a.verify_key_hex
    assert detail_b.trace.signer_pubkey == kp_b.verify_key_hex


# ---------------------------------------------------------------------------
# 5 + 6. Trust boundaries
# ---------------------------------------------------------------------------


def test_private_trace_not_visible_to_other_agent(
    agent_a: tuple[str, str],
    agent_b: tuple[str, str],
    integration_base_url: str,
) -> None:
    """A publishes PRIVATE; B GETs → 404 (per spec §7 Q5)."""
    _, api_key_a = agent_a
    _, api_key_b = agent_b

    with Client(api_key=api_key_a, base_url=integration_base_url) as ca:
        published = ca.publish(_trace(visibility=Visibility.PRIVATE))
        assert ca.get(published.trace_id).trace.trace_id == published.trace_id

    with (
        Client(api_key=api_key_b, base_url=integration_base_url) as cb,
        pytest.raises(ValidationError) as excinfo,
    ):
        cb.get(published.trace_id)
    assert excinfo.value.status == 404
    assert excinfo.value.error_code == "not_found"


def test_public_trace_visible_to_other_agent(
    agent_a: tuple[str, str],
    agent_b: tuple[str, str],
    integration_base_url: str,
) -> None:
    """A publishes PUBLIC; B GETs → 200; B searches → finds it."""
    _, api_key_a = agent_a
    _, api_key_b = agent_b
    public_tag = f"public-trust-{int(time.time())}"

    with Client(api_key=api_key_a, base_url=integration_base_url) as ca:
        published = ca.publish(
            _trace(
                visibility=Visibility.PUBLIC,
                tags=["integration", public_tag],
                error_text=f"public boundary {time.time_ns()}",
            )
        )

    with Client(api_key=api_key_b, base_url=integration_base_url) as cb:
        detail = cb.get(published.trace_id)
        assert detail.trace.trace_id == published.trace_id
        results = cb.search(tags=[public_tag])
        assert any(r.trace_id == published.trace_id for r in results.results)


# ---------------------------------------------------------------------------
# 7. Rate-limit recovery
# ---------------------------------------------------------------------------


def test_rate_limit_eventually_observed(
    fresh_rate_limit_agent: tuple[str, str],
    integration_base_url: str,
) -> None:
    """Hammer publish until we see a 429.

    Worker bucket: 100 / 3600 s per agent. SDK does NOT auto-retry —
    surfaces RateLimitError with retry_after_s + bucket.
    """
    _, api_key = fresh_rate_limit_agent
    seen_rate_limit: list[RateLimitError] = []

    with Client(
        api_key=api_key,
        base_url=integration_base_url,
        backoff_base_s=0.0,
    ) as c:
        for i in range(110):
            try:
                c.publish(_trace(error_text=f"rate-limit probe {i} {time.time_ns()}"))
            except RateLimitError as exc:
                seen_rate_limit.append(exc)
                break
            except (NetworkError, ValidationError):
                continue

    assert seen_rate_limit, "expected a 429 within 110 publishes; bucket may be wider than expected"
    rl = seen_rate_limit[0]
    assert rl.bucket == "publish"
    assert rl.retry_after_s >= 0
    assert rl.status == 429


# ---------------------------------------------------------------------------
# 8 + 9. Search variants
# ---------------------------------------------------------------------------


def test_search_by_error_signature(
    agent_a: tuple[str, str],
    integration_base_url: str,
) -> None:
    """Compute error_signature locally, publish, search by it → exact match."""
    from borg_collective._error_signature import compute_error_signature

    _, api_key = agent_a
    error_text = f"unique error text {time.time_ns()}"
    sig = compute_error_signature(error_text=error_text, error_class="UniqueError")
    assert HEX_64_RE.fullmatch(sig)

    with Client(api_key=api_key, base_url=integration_base_url) as c:
        published = c.publish(
            _trace(
                error_text=error_text,
                error_class="UniqueError",
                visibility=Visibility.PUBLIC,
            )
        )
        assert published.error_signature == sig
        results = c.search(error_signature=sig)
    assert any(r.trace_id == published.trace_id for r in results.results)


def test_search_by_tag(
    agent_a: tuple[str, str],
    integration_base_url: str,
) -> None:
    """Publish with a unique tag; search finds it."""
    _, api_key = agent_a
    tag = f"tag-search-{int(time.time())}-{time.time_ns()}"

    with Client(api_key=api_key, base_url=integration_base_url) as c:
        published = c.publish(
            _trace(
                tags=["integration", tag],
                visibility=Visibility.PUBLIC,
                error_text=f"tag search {time.time_ns()}",
            )
        )
        results = c.search(tags=[tag])
    assert any(r.trace_id == published.trace_id for r in results.results)


# ---------------------------------------------------------------------------
# 10 + 11. Feedback
# ---------------------------------------------------------------------------


def test_feedback_full_funnel_increments_counters(
    agent_a: tuple[str, str],
    integration_base_url: str,
) -> None:
    """retrieved/read/applied=True + outcome=helped → counters bump."""
    _, api_key = agent_a
    with Client(api_key=api_key, base_url=integration_base_url) as c:
        published = c.publish(
            _trace(visibility=Visibility.PUBLIC, error_text=f"fb funnel {time.time_ns()}")
        )
        before = c.get(published.trace_id).counters
        ack = c.feedback(
            published.trace_id,
            retrieved=True,
            read=True,
            applied=True,
            outcome=FeedbackOutcome.HELPED,
        )
        assert ack.recorded is True
        assert ack.counters_updated is True
        after = c.get(published.trace_id).counters
    assert after.read >= before.read + 1
    assert after.applied >= before.applied + 1
    assert after.helped >= before.helped + 1


def test_feedback_funnel_violation_via_handcraft(
    agent_a: tuple[str, str],
    integration_base_url: str,
) -> None:
    """Hand-crafted httpx call bypasses the local validator → Worker
    returns 400 ``funnel_violation``."""
    import httpx

    _, api_key = agent_a
    with Client(api_key=api_key, base_url=integration_base_url) as c:
        published = c.publish(
            _trace(visibility=Visibility.PUBLIC, error_text=f"fb violation {time.time_ns()}")
        )

    response = httpx.post(
        f"{integration_base_url}/api/v1/feedback",
        headers={"X-API-Key": api_key, "Content-Type": "application/json"},
        json={
            "trace_id": published.trace_id,
            "retrieved": True,
            "read": False,
            "applied": True,
        },
    )
    assert response.status_code == 400
    body = response.json()
    assert body["error"] == "funnel_violation"


# ---------------------------------------------------------------------------
# 12. Amendment by non-owner
# ---------------------------------------------------------------------------


def test_amendment_by_non_owner(
    agent_a: tuple[str, str],
    agent_b: tuple[str, str],
    integration_base_url: str,
) -> None:
    """A's PUBLIC trace → B amends → GET shows both, author=B."""
    agent_a_id, api_key_a = agent_a
    agent_b_id, api_key_b = agent_b

    with Client(api_key=api_key_a, base_url=integration_base_url) as ca:
        published = ca.publish(
            _trace(visibility=Visibility.PUBLIC, error_text=f"amend test {time.time_ns()}")
        )
    with Client(api_key=api_key_b, base_url=integration_base_url) as cb:
        amended = cb.add_amendment(
            published.trace_id,
            content="amendment by non-owner",
            kind=AmendmentKind.CLARIFICATION,
        )
        detail = cb.get(published.trace_id)
    assert detail.trace.agent_id == agent_a_id
    assert any(
        am.amendment_id == amended.amendment_id and am.author_agent_id == agent_b_id
        for am in detail.amendments
    )


# ---------------------------------------------------------------------------
# 13. Local search validator (no network)
# ---------------------------------------------------------------------------


def test_search_no_criteria_rejected_locally() -> None:
    """SearchRequest() with zero criteria raises before any network call."""
    from pydantic import ValidationError as PydanticValidationError

    with pytest.raises(PydanticValidationError):
        SearchRequest()


# ---------------------------------------------------------------------------
# 14. Network resilience (no Worker contact)
# ---------------------------------------------------------------------------


def test_bogus_base_url_raises_network_error() -> None:
    """No D1 state created when the SDK can't reach a Worker."""
    with (
        Client(
            api_key="a" * 64,
            base_url="https://invalid-host-that-does-not-exist.invalid",
            backoff_base_s=0.0,
        ) as c,
        pytest.raises(NetworkError),
    ):
        c.publish(_trace())


# ---------------------------------------------------------------------------
# 15. Hex-only firewall round-trip
# ---------------------------------------------------------------------------


def test_hex_only_round_trip(
    agent_a: tuple[str, str],
    integration_base_url: str,
) -> None:
    """Every signature/pubkey/error_signature on the wire is the
    expected lowercase hex shape."""
    _, api_key = agent_a
    kp = SigningKeyPair.generate()
    with Client(api_key=api_key, base_url=integration_base_url) as c:
        c.rotate_pubkey(kp.verify_key_hex)
        published = c.publish(_trace(error_text=f"hex round-trip {time.time_ns()}"), signing_key=kp)
        detail = c.get(published.trace_id)

    assert HEX_64_RE.fullmatch(published.error_signature)
    assert detail.trace.signed is True
    assert detail.trace.signature is not None
    assert HEX_128_RE.fullmatch(detail.trace.signature)
    assert detail.trace.signer_pubkey is not None
    assert HEX_64_RE.fullmatch(detail.trace.signer_pubkey)
    assert HEX_64_RE.fullmatch(detail.trace.error_signature)


# ---------------------------------------------------------------------------
# 16. Threaded queue + drain (SDK-level + one drain to Worker)
# ---------------------------------------------------------------------------


def test_offline_queue_threaded_enqueue_drain(
    agent_a: tuple[str, str],
    integration_base_url: str,
    tmp_path: Path,
) -> None:
    """N threads enqueue concurrently; drain pulls them all in one
    pass and the Worker accepts each."""
    agent_a_id, api_key = agent_a
    queue_path = tmp_path / "thread-q.sqlite"
    n_threads = 4
    per_thread = 5

    def _enq(thread_id: int, queue: OfflineQueue) -> None:
        for i in range(per_thread):
            queue.enqueue(
                agent_a_id,
                {
                    "error_text": f"thread {thread_id} item {i} {time.time_ns()}",
                    "task_description": "td",
                    "approach_summary": "as",
                    "root_cause": "rc",
                    "outcome": "resolved",
                    "tags": ["integration", "threaded-queue"],
                    "visibility": "private",
                },
            )

    with OfflineQueue(queue_path) as queue:
        threads = [threading.Thread(target=_enq, args=(t, queue)) for t in range(n_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert queue.size() == n_threads * per_thread

    with Client(
        api_key=api_key,
        base_url=integration_base_url,
        offline_queue_path=queue_path,
    ) as c:
        report = c.drain(max_items=n_threads * per_thread + 5)
    assert report.drained == n_threads * per_thread
    assert report.failed == 0
    assert report.deferred == 0
