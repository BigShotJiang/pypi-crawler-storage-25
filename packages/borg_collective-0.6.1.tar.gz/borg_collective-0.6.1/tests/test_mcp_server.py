"""Unit tests for the federation MCP server (E1.1).

Coverage matrix:

  * 8 schema tests  — one per tool — valid input parses, invalid raises
  * 8 happy-path tests — one per tool — handler returns expected shape
  * 4 error-handling tests — auth, rate-limit, network, unknown-trace
  * 1 stdio-protocol test — server registers all 8 tools at startup

The handlers take an :class:`AsyncClient`-shaped object; we use a small
hand-rolled async fake so the test file is self-contained (the SDK's
:class:`FakeAsyncClient` covers the original 8 client methods but
predates ``list_my_traces`` / ``update_trace`` / ``delete_trace`` —
extending it is out of scope for E1.1).
"""

from __future__ import annotations

from typing import Any

import pytest
from pydantic import ValidationError as PydValidationError

from borg_collective import (
    AuthError,
    Counters,
    FeedbackAck,
    MatchMode,
    NetworkError,
    Outcome,
    PublishedTrace,
    RateLimitError,
    SearchResult,
    SearchResults,
    Trace,
    TraceDetail,
    ValidationError,
    Visibility,
)
from borg_collective.mcp_server import (
    DeleteTraceArgs,
    ListMyTracesArgs,
    PromoteArgs,
    RecordFailureArgs,
    ReportOutcomeArgs,
    ShowTraceArgs,
    SuggestTracesArgs,
    UpdateTraceArgs,
    _build_server,
    _delete_trace,
    _error_envelope,
    _list_my_traces,
    _promote,
    _record_failure,
    _report_outcome,
    _show_trace,
    _suggest_traces,
    _tools,
    _update_trace,
)
from borg_collective.models import MyTraceListItem, MyTracesResponse

# ---------------------------------------------------------------------------
# Hand-rolled async fake covering the methods the MCP server calls.
# Keeps the test file self-contained — see module docstring.
# ---------------------------------------------------------------------------


_FAKE_SIG = "a" * 64
_FAKE_AGENT = "fake-agent-id"


class _FakeAsync:
    """Minimal async fake — record calls, return queued responses."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, dict[str, Any]]] = []
        self._returns: dict[str, Any] = {}
        self._raises: dict[str, BaseException] = {}

    def queue(self, method: str, value: Any) -> None:
        self._returns[method] = value

    def raise_on(self, method: str, exc: BaseException) -> None:
        self._raises[method] = exc

    async def _resolve(self, method: str, kwargs: dict[str, Any]) -> Any:
        self.calls.append((method, kwargs))
        if method in self._raises:
            raise self._raises[method]
        if method not in self._returns:
            msg = f"_FakeAsync: no response queued for {method!r}"
            raise AssertionError(msg)
        return self._returns[method]

    async def search(self, **kw: Any) -> Any:
        return await self._resolve("search", kw)

    async def get(self, trace_id: str) -> Any:
        return await self._resolve("get", {"trace_id": trace_id})

    async def publish(self, trace: Any, **kw: Any) -> Any:
        return await self._resolve("publish", {"trace": trace, **kw})

    async def feedback(self, trace_id: str, **kw: Any) -> Any:
        return await self._resolve("feedback", {"trace_id": trace_id, **kw})

    async def list_my_traces(self, **kw: Any) -> Any:
        return await self._resolve("list_my_traces", kw)

    async def update_trace(self, trace_id: str, **kw: Any) -> Any:
        return await self._resolve("update_trace", {"trace_id": trace_id, **kw})

    async def delete_trace(self, trace_id: str) -> Any:
        return await self._resolve("delete_trace", {"trace_id": trace_id})


def _trace(trace_id: str = "t-1", **overrides: Any) -> Trace:
    base: dict[str, Any] = {
        "trace_id": trace_id,
        "agent_id": _FAKE_AGENT,
        "error_signature": _FAKE_SIG,
        "error_class": "import-error",
        "error_text": "ModuleNotFoundError: No module named 'foo'",
        "task_description": "import foo",
        "approach_summary": "pip install foo and re-run",
        "root_cause": "missing dependency in venv",
        "outcome": Outcome.RESOLVED,
        "technology": "python",
        "tags": [],
        "context_snapshot": {},
        "visibility": Visibility.PRIVATE,
        "signed": False,
        "signature": None,
        "signer_pubkey": None,
        "created_at": 0,
    }
    base.update(overrides)
    return Trace(**base)


def _detail(trace_id: str = "t-1", **trace_overrides: Any) -> TraceDetail:
    return TraceDetail(
        trace=_trace(trace_id, **trace_overrides),
        amendments=[],
        counters=Counters(retrieved=1, read=1, applied=1, helped=2, didnt_help=0),
    )


def _search_result(
    trace_id: str = "t-1",
    helped: int = 2,
    didnt_help: int = 0,
    error_class: str | None = "import-error",
) -> SearchResult:
    return SearchResult(
        trace_id=trace_id,
        error_signature=_FAKE_SIG,
        error_class=error_class,
        outcome=Outcome.RESOLVED,
        signed=False,
        created_at=0,
        preview="ModuleNotFoundError: No module named 'foo'",
        counters=Counters(
            retrieved=1, read=1, applied=1, helped=helped, didnt_help=didnt_help,
        ),
    )


# ===========================================================================
# 1. Schema tests — 8, one per tool. Valid + invalid input.
# ===========================================================================


class TestSchemas:
    def test_suggest_traces_schema(self) -> None:
        SuggestTracesArgs.model_validate({"task": "fix import"})
        with pytest.raises(PydValidationError):
            SuggestTracesArgs.model_validate({"task": ""})  # min_length=1
        with pytest.raises(PydValidationError):
            SuggestTracesArgs.model_validate({"task": "x", "limit": 0})  # ge=1

    def test_record_failure_schema(self) -> None:
        ok = RecordFailureArgs.model_validate({"trace": {"error_text": "x"}})
        assert ok.visibility == "private"
        assert ok.force_public is False
        with pytest.raises(PydValidationError):
            RecordFailureArgs.model_validate({})  # trace is required

    def test_report_outcome_schema(self) -> None:
        ReportOutcomeArgs.model_validate({"trace_id": "t-1", "outcome": "helpful"})
        with pytest.raises(PydValidationError):
            ReportOutcomeArgs.model_validate({"outcome": "helpful"})  # missing trace_id
        with pytest.raises(PydValidationError):
            ReportOutcomeArgs.model_validate(
                {"trace_id": "t-1", "outcome": "x", "time_saved_minutes": -1},
            )  # ge=0

    def test_list_my_traces_schema(self) -> None:
        ok = ListMyTracesArgs.model_validate({})
        assert ok.limit == 20
        with pytest.raises(PydValidationError):
            ListMyTracesArgs.model_validate({"limit": 0})  # ge=1
        with pytest.raises(PydValidationError):
            ListMyTracesArgs.model_validate({"limit": 101})  # le=100

    def test_show_trace_schema(self) -> None:
        ShowTraceArgs.model_validate({"trace_id": "t-1"})
        with pytest.raises(PydValidationError):
            ShowTraceArgs.model_validate({"trace_id": ""})

    def test_promote_schema(self) -> None:
        ok = PromoteArgs.model_validate({"trace_id": "t-1"})
        assert ok.force_public is False
        with pytest.raises(PydValidationError):
            PromoteArgs.model_validate({})

    def test_update_trace_schema(self) -> None:
        UpdateTraceArgs.model_validate({"trace_id": "t-1", "fields": {"error_class": "x"}})
        with pytest.raises(PydValidationError):
            UpdateTraceArgs.model_validate({"trace_id": "t-1"})  # fields required

    def test_delete_trace_schema(self) -> None:
        DeleteTraceArgs.model_validate({"trace_id": "t-1"})
        with pytest.raises(PydValidationError):
            DeleteTraceArgs.model_validate({"trace_id": ""})


# ===========================================================================
# 2. Happy-path tests — 8, one per tool.
# ===========================================================================


class TestHappyPaths:
    @pytest.mark.asyncio()
    async def test_suggest_traces(self) -> None:
        client = _FakeAsync()
        client.queue(
            "search",
            SearchResults(
                results=[
                    _search_result("t-best", helped=5, didnt_help=1),
                    _search_result("t-middle", helped=2, didnt_help=0),
                    _search_result("t-low", helped=0, didnt_help=3),
                ],
                count=3,
                match_mode=MatchMode.QUERY,
            ),
        )
        # _suggest_traces calls get() once per top-K (limit=3 here, so 3 GETs).
        client.queue("get", _detail("t-detail"))
        # Reuse the same detail for all three GETs — the helper resolves
        # each call to the queued return.
        out = await _suggest_traces(SuggestTracesArgs(task="fix x"), client)  # type: ignore[arg-type]
        assert "suggestions" in out
        assert len(out["suggestions"]) == 3
        # Sorted by score desc: t-best (4), t-middle (2), t-low (-3).
        assert out["suggestions"][0]["trace_id"] == "t-best"
        assert out["suggestions"][0]["score"] == 4
        assert "score_breakdown" in out["suggestions"][0]
        assert "fix" in out["suggestions"][0]
        # L4 cold-start fields present on every suggestion.
        for s in out["suggestions"]:
            assert "cold_start" in s
            assert "usage_count" in s
        # All three traces have feedback (helped or didnt_help > 0) →
        # none are cold-start, no inline note added.
        assert all(s["cold_start"] is False for s in out["suggestions"])
        assert "note" not in out
        assert "cold_start_results" not in out

    @pytest.mark.asyncio()
    async def test_suggest_traces_cold_start_note(self) -> None:
        """L4: when results contain cold_start: true entries, the response
        gains a `note` field surfacing the count inline so the LLM
        reading the response interprets score=null correctly."""

        # Build a cold-start SearchResult directly — the _search_result
        # helper defaults applied/retrieved/read to 1, which would make
        # any result post-cold even with helped=0/didnt_help=0.
        def cold(trace_id: str) -> SearchResult:
            return SearchResult(
                trace_id=trace_id,
                error_signature=_FAKE_SIG,
                error_class="import-error",
                outcome=Outcome.RESOLVED,
                signed=False,
                created_at=0,
                preview="brand new trace, no feedback yet",
                counters=Counters(
                    retrieved=0, read=0, applied=0, helped=0, didnt_help=0,
                ),
            )

        client = _FakeAsync()
        client.queue(
            "search",
            SearchResults(
                results=[
                    # warm — has feedback
                    _search_result("t-warm", helped=3, didnt_help=1),
                    # cold — no feedback at all
                    cold("t-cold-1"),
                    cold("t-cold-2"),
                ],
                count=3,
                match_mode=MatchMode.QUERY,
            ),
        )
        client.queue("get", _detail("t-detail"))
        out = await _suggest_traces(SuggestTracesArgs(task="fix y"), client)  # type: ignore[arg-type]
        # Sorted by score desc: warm (2), then ties broken by created_at DESC.
        warm = next(s for s in out["suggestions"] if s["trace_id"] == "t-warm")
        cold1 = next(s for s in out["suggestions"] if s["trace_id"] == "t-cold-1")
        assert warm["cold_start"] is False
        assert warm["score"] == 2
        # usage_count = helped + didnt_help + applied >= the score signal.
        assert warm["usage_count"] >= warm["score_breakdown"]["helped"] + warm["score_breakdown"]["didnt_help"]
        assert cold1["cold_start"] is True
        # Cold-start: score is None, not 0, so the LLM doesn't read it
        # as "tested and rejected".
        assert cold1["score"] is None
        assert cold1["usage_count"] == 0
        # Inline summary count + human-readable note.
        assert out["cold_start_results"] == 2
        assert out["total_results"] == 3
        assert "newly seeded" in out["note"]

    @pytest.mark.asyncio()
    async def test_record_failure(self) -> None:
        client = _FakeAsync()
        client.queue(
            "publish",
            PublishedTrace(
                trace_id="t-new", signed=False, error_signature=_FAKE_SIG, warning=None,
            ),
        )
        out = await _record_failure(
            RecordFailureArgs(
                trace={
                    "error_text": "boom",
                    "task_description": "task",
                    "approach_summary": "approach",
                    "root_cause": "rc",
                    "outcome": "resolved",
                },
            ),
            client,  # type: ignore[arg-type]
        )
        assert out["trace_id"] == "t-new"
        assert out["visibility"] == "private"

    @pytest.mark.asyncio()
    async def test_report_outcome(self) -> None:
        client = _FakeAsync()
        client.queue(
            "feedback",
            FeedbackAck(recorded=True, trace_id="t-1", counters_updated=True, note=None),
        )
        out = await _report_outcome(
            ReportOutcomeArgs(trace_id="t-1", outcome="helpful", time_saved_minutes=15),
            client,  # type: ignore[arg-type]
        )
        assert out["ack"] is True
        # Verify the funnel was filled in correctly + note carries time_saved.
        fb_call = next(c for c in client.calls if c[0] == "feedback")
        assert fb_call[1]["outcome"] == "helped"
        assert fb_call[1]["applied"] is True
        assert "time_saved=15m" in (fb_call[1]["note"] or "")

    @pytest.mark.asyncio()
    async def test_list_my_traces(self) -> None:
        client = _FakeAsync()
        item = MyTraceListItem(
            trace_id="t-1",
            error_class="x",
            visibility=Visibility.PRIVATE,
            error_preview="...",
            created_at=0,
        )
        client.queue(
            "list_my_traces",
            MyTracesResponse(traces=[item], count=1, next_before=None),
        )
        out = await _list_my_traces(
            ListMyTracesArgs(visibility="private", limit=20),
            client,  # type: ignore[arg-type]
        )
        assert out["count"] == 1
        assert out["traces"][0]["trace_id"] == "t-1"

    @pytest.mark.asyncio()
    async def test_show_trace(self) -> None:
        client = _FakeAsync()
        client.queue("get", _detail("t-1"))
        out = await _show_trace(ShowTraceArgs(trace_id="t-1"), client)  # type: ignore[arg-type]
        assert out["trace"]["trace_id"] == "t-1"
        assert out["counters"]["helped"] == 2

    @pytest.mark.asyncio()
    async def test_promote_requires_force_public(self) -> None:
        client = _FakeAsync()
        # Without force_public: refused locally, no client call.
        out = await _promote(PromoteArgs(trace_id="t-1"), client)  # type: ignore[arg-type]
        assert out["error"] == "force_public_required"
        assert client.calls == []

    @pytest.mark.asyncio()
    async def test_promote_with_force_public(self) -> None:
        client = _FakeAsync()
        client.queue("update_trace", {"updated_fields": ["visibility"]})
        out = await _promote(
            PromoteArgs(trace_id="t-1", force_public=True),
            client,  # type: ignore[arg-type]
        )
        assert out["ack"] is True
        assert out["new_visibility"] == "public"
        # Verify the client was called with force_public=True.
        ut = next(c for c in client.calls if c[0] == "update_trace")
        assert ut[1]["force_public"] is True

    @pytest.mark.asyncio()
    async def test_update_trace(self) -> None:
        client = _FakeAsync()
        client.queue(
            "update_trace",
            {"trace_id": "t-1", "updated_fields": ["error_class"]},
        )
        out = await _update_trace(
            UpdateTraceArgs(trace_id="t-1", fields={"error_class": "import-error"}),
            client,  # type: ignore[arg-type]
        )
        assert out["ack"] is True
        assert out["updated_fields"] == ["error_class"]

    @pytest.mark.asyncio()
    async def test_delete_trace(self) -> None:
        client = _FakeAsync()
        client.queue("delete_trace", {"trace_id": "t-1", "deleted_at": 1234})
        out = await _delete_trace(DeleteTraceArgs(trace_id="t-1"), client)  # type: ignore[arg-type]
        assert out["ack"] is True
        assert out["deleted_at"] == 1234


# ===========================================================================
# 3. Error-handling tests — 4, covering the exception envelope.
# ===========================================================================


class TestErrorHandling:
    """Verify _error_envelope maps SDK exceptions to structured dicts."""

    def test_auth_error(self) -> None:
        out = _error_envelope(
            AuthError("denied", status=403, error_code="invalid_key"),
        )
        assert out["error"] == "auth_error"
        assert out["status"] == 403
        assert "BORG_API_KEY" in out["hint"]

    def test_rate_limit_error(self) -> None:
        out = _error_envelope(
            RateLimitError("slow", retry_after_s=12, bucket="auth_write"),
        )
        assert out["error"] == "rate_limit"
        assert out["bucket"] == "auth_write"
        assert out["retry_after_s"] == 12

    def test_network_error(self) -> None:
        out = _error_envelope(NetworkError("down"))
        assert out["error"] == "network_error"

    def test_validation_error_unknown_trace(self) -> None:
        # The Worker returns 404 + error_code='not_found' for an unknown
        # (or owner-only) trace_id. Verify the envelope preserves both.
        out = _error_envelope(
            ValidationError("not_found", status=404, error_code="not_found"),
        )
        assert out["error"] == "validation_error"
        assert out["status"] == 404
        assert out["error_code"] == "not_found"


# ===========================================================================
# 4. Stdio-protocol test — server registers all 8 tools at startup.
# ===========================================================================


class TestStdioProtocol:
    @pytest.mark.asyncio()
    async def test_list_tools_returns_all_eight(self) -> None:
        # Build the server with a (no-op) fake; register list_tools
        # handler runs without any client calls.
        client = _FakeAsync()
        server = _build_server(client)  # type: ignore[arg-type]

        # Server.list_tools_handler is the registered async callable;
        # invoking it returns the same Tool list.
        # The mcp SDK wires the decorator to a private handler attribute;
        # the public surface is the list of tool names from _tools().
        names = [t.name for t in _tools()]
        assert sorted(names) == sorted(
            [
                "suggest_traces",
                "record_failure",
                "report_outcome",
                "list_my_traces",
                "show_trace",
                "promote",
                "update_trace",
                "delete_trace",
            ],
        )
        # Server name and version are wired via _build_server. The
        # internal handler registration is verified indirectly: every
        # tool resolves to a (model, handler) pair in the dispatcher.
        from borg_collective.mcp_server import _HANDLERS

        for name in names:
            assert name in _HANDLERS, f"{name} not wired in _HANDLERS"
        # Server identifier is "borg-federation".
        assert server.name == "borg-federation"
