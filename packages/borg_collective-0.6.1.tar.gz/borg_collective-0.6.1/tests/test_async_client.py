"""Tests for :class:`borg_collective.AsyncClient`.

Mirrors ``test_client.py`` — same matrix, awaitable methods,
``respx`` for HTTP mocking. The contract guarantee is "AsyncClient is
the awaitable mirror of Client", and the mirror only holds if the same
test surface passes against both.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import httpx
import pytest
import respx

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

from borg_collective import (
    Agent,
    AgentInfo,
    AgentPubkey,
    AmendmentCreated,
    AmendmentKind,
    AsyncClient,
    AuthError,
    ConfigError,
    FailureTrace,
    FeedbackAck,
    FeedbackOutcome,
    Outcome,
    PublishedTrace,
    SearchResults,
    SignatureError,
    TraceDetail,
    TrustLevel,
    ValidationError,
    Visibility,
)
from borg_collective._signing import SigningKeyPair
from borg_collective._transport import AUTH_HEADER, AsyncTransport

BASE_URL = "https://test.invalid"
TEST_API_KEY = "a" * 64

HEX_64_A = "a" * 64
HEX_64_B = "b" * 64
HEX_64_C = "c" * 64

UUID_AGENT = "00000000-0000-4000-8000-000000000001"


# ---------------------------------------------------------------------------
# Fixtures.
# ---------------------------------------------------------------------------


@pytest.fixture()
async def client() -> AsyncGenerator[AsyncClient, None]:
    c = AsyncClient(api_key=TEST_API_KEY, base_url=BASE_URL, backoff_base_s=0.0)
    yield c
    await c.aclose()


@pytest.fixture()
async def unauth_client() -> AsyncGenerator[AsyncClient, None]:
    c = AsyncClient(api_key=None, base_url=BASE_URL, backoff_base_s=0.0)
    yield c
    await c.aclose()


def _err_envelope(error_code: str, **extras: Any) -> dict[str, Any]:
    return {"error": error_code, "request_id": "req_test", **extras}


def _trace_kwargs(**overrides: Any) -> dict[str, Any]:
    base = {
        "error_text": "ImportError: no module named foo",
        "task_description": "import the foo module",
        "approach_summary": "naive import",
        "root_cause": "module not installed",
        "outcome": Outcome.RESOLVED,
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Constructor + lifecycle.
# ---------------------------------------------------------------------------


class TestConstructor:
    async def test_api_key_passed_through_to_transport(self) -> None:
        c = AsyncClient(api_key=TEST_API_KEY, base_url=BASE_URL)
        try:
            assert c._transport._api_key == TEST_API_KEY
        finally:
            await c.aclose()

    async def test_no_api_key_allowed(self) -> None:
        c = AsyncClient(api_key=None, base_url=BASE_URL)
        try:
            assert c._transport._api_key is None
        finally:
            await c.aclose()

    async def test_base_url_passed_through(self) -> None:
        c = AsyncClient(api_key=TEST_API_KEY, base_url="https://example.invalid")
        try:
            assert c._transport._base_url == "https://example.invalid"
        finally:
            await c.aclose()

    async def test_repr_does_not_leak_api_key(self) -> None:
        c = AsyncClient(api_key="super-secret-async", base_url=BASE_URL)
        try:
            r = repr(c)
            assert "super-secret-async" not in r
            assert "AsyncClient" in r
        finally:
            await c.aclose()

    async def test_async_context_manager(self) -> None:
        async with AsyncClient(api_key=TEST_API_KEY, base_url=BASE_URL) as c:
            assert c._owns_transport is True

    async def test_aclose_idempotent(self) -> None:
        c = AsyncClient(api_key=TEST_API_KEY, base_url=BASE_URL)
        await c.aclose()
        await c.aclose()  # second close must not raise

    async def test_injected_transport_not_closed(self) -> None:
        injected = AsyncTransport(api_key=TEST_API_KEY, base_url=BASE_URL, backoff_base_s=0.0)
        try:
            c = AsyncClient(transport=injected)
            assert c._owns_transport is False
            await c.aclose()  # should NOT close injected
        finally:
            await injected.aclose()


# ---------------------------------------------------------------------------
# register_agent
# ---------------------------------------------------------------------------


class TestRegisterAgent:
    @respx.mock
    async def test_register_with_no_args(self, unauth_client: AsyncClient) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/agents").mock(
            return_value=httpx.Response(
                201,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "agent-00000000",
                    "api_key": HEX_64_A,
                    "trust_level": "soft",
                    "created_at": 1,
                },
            )
        )
        agent = await unauth_client.register_agent()
        assert isinstance(agent, Agent)
        assert agent.agent_id == UUID_AGENT
        assert route.calls.last.request.content == b"{}"

    @respx.mock
    async def test_register_with_display_name_and_pubkey(self, unauth_client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/agents").mock(
            return_value=httpx.Response(
                201,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "alice",
                    "api_key": HEX_64_A,
                    "trust_level": "soft",
                    "created_at": 1,
                },
            )
        )
        agent = await unauth_client.register_agent(display_name="alice", pubkey=HEX_64_B)
        assert agent.display_name == "alice"

    @respx.mock
    async def test_register_does_not_require_api_key(self, unauth_client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/agents").mock(
            return_value=httpx.Response(
                201,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "x",
                    "api_key": HEX_64_A,
                    "trust_level": "soft",
                    "created_at": 1,
                },
            )
        )
        await unauth_client.register_agent()

    @respx.mock
    async def test_register_400_invalid_pubkey(self, unauth_client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/agents").mock(
            return_value=httpx.Response(400, json=_err_envelope("invalid_pubkey"))
        )
        with pytest.raises(ValidationError):
            await unauth_client.register_agent(pubkey="not-hex")


# ---------------------------------------------------------------------------
# whoami
# ---------------------------------------------------------------------------


class TestWhoami:
    @respx.mock
    async def test_whoami_200_returns_agent_info(self, client: AsyncClient) -> None:
        respx.get(f"{BASE_URL}/api/v1/agents/me").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "alice",
                    "trust_level": "soft",
                    "pubkey": None,
                    "created_at": 1,
                },
            )
        )
        me = await client.whoami()
        assert isinstance(me, AgentInfo)
        assert me.trust_level is TrustLevel.SOFT
        assert me.pubkey is None

    @respx.mock
    async def test_whoami_pubkey_set(self, client: AsyncClient) -> None:
        respx.get(f"{BASE_URL}/api/v1/agents/me").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "alice",
                    "trust_level": "soft",
                    "pubkey": HEX_64_C,
                    "created_at": 1,
                },
            )
        )
        me = await client.whoami()
        assert me.pubkey == HEX_64_C

    @respx.mock
    async def test_whoami_uses_auth_header(self, client: AsyncClient) -> None:
        route = respx.get(f"{BASE_URL}/api/v1/agents/me").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "x",
                    "trust_level": "soft",
                    "pubkey": None,
                    "created_at": 1,
                },
            )
        )
        await client.whoami()
        assert route.calls.last.request.headers[AUTH_HEADER] == TEST_API_KEY

    async def test_whoami_config_error_without_api_key(self, unauth_client: AsyncClient) -> None:
        with pytest.raises(ConfigError):
            await unauth_client.whoami()

    @respx.mock
    async def test_whoami_401_raises_auth(self, client: AsyncClient) -> None:
        respx.get(f"{BASE_URL}/api/v1/agents/me").mock(
            return_value=httpx.Response(401, json=_err_envelope("auth_required"))
        )
        with pytest.raises(AuthError):
            await client.whoami()

    @respx.mock
    async def test_whoami_403_raises_auth(self, client: AsyncClient) -> None:
        respx.get(f"{BASE_URL}/api/v1/agents/me").mock(
            return_value=httpx.Response(403, json=_err_envelope("invalid_key"))
        )
        with pytest.raises(AuthError):
            await client.whoami()


# ---------------------------------------------------------------------------
# publish
# ---------------------------------------------------------------------------


class TestPublishUnsigned:
    @respx.mock
    async def test_publish_failure_trace_object(self, client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={
                    "trace_id": "t",
                    "signed": False,
                    "error_signature": HEX_64_A,
                    "warning": "unsigned_trace",
                },
            )
        )
        published = await client.publish(FailureTrace(**_trace_kwargs()))
        assert isinstance(published, PublishedTrace)
        assert published.warning == "unsigned_trace"

    @respx.mock
    async def test_publish_dict_input(self, client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={
                    "trace_id": "t",
                    "signed": False,
                    "error_signature": HEX_64_A,
                    "warning": "unsigned_trace",
                },
            )
        )
        published = await client.publish(_trace_kwargs(visibility=Visibility.PRIVATE))
        assert published.trace_id == "t"

    @respx.mock
    async def test_publish_omits_none_optional_fields(self, client: AsyncClient) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={
                    "trace_id": "t",
                    "signed": False,
                    "error_signature": HEX_64_A,
                    "warning": "unsigned_trace",
                },
            )
        )
        await client.publish(FailureTrace(**_trace_kwargs()))
        body = route.calls.last.request.content
        assert b'"signature"' not in body
        assert b'"signer_pubkey"' not in body

    @respx.mock
    async def test_publish_422_bad_signature(self, client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(422, json=_err_envelope("bad_signature"))
        )
        with pytest.raises(SignatureError):
            await client.publish(FailureTrace(**_trace_kwargs()))

    async def test_publish_config_error_without_api_key(self, unauth_client: AsyncClient) -> None:
        with pytest.raises(ConfigError):
            await unauth_client.publish(FailureTrace(**_trace_kwargs()))


class TestPublishSigned:
    @respx.mock
    async def test_publish_with_signing_key_stamps_fields(self, client: AsyncClient) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={"trace_id": "t", "signed": True, "error_signature": HEX_64_A},
            )
        )
        kp = SigningKeyPair.generate()
        await client.publish(FailureTrace(**_trace_kwargs()), signing_key=kp)
        body = route.calls.last.request.content
        assert f'"signer_pubkey": "{kp.verify_key_hex}"'.encode() in body
        assert b'"signature": "' in body
        assert b'"error_signature": "' in body

    @respx.mock
    async def test_publish_signed_does_not_overwrite_explicit_error_signature(
        self, client: AsyncClient
    ) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={"trace_id": "t", "signed": True, "error_signature": HEX_64_C},
            )
        )
        kp = SigningKeyPair.generate()
        ft = FailureTrace(**_trace_kwargs(error_signature=HEX_64_C))
        await client.publish(ft, signing_key=kp)
        assert f'"error_signature": "{HEX_64_C}"'.encode() in route.calls.last.request.content

    @respx.mock
    async def test_publish_signed_signature_verifies(self, client: AsyncClient) -> None:
        import json

        from borg_collective._canonical import canonical_bytes_for_trace
        from borg_collective._signing import verify

        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={"trace_id": "t", "signed": True, "error_signature": HEX_64_A},
            )
        )
        kp = SigningKeyPair.generate()
        ft = FailureTrace(**_trace_kwargs(tags=["a", "b"]))
        await client.publish(ft, signing_key=kp)
        body = json.loads(route.calls.last.request.content)
        sig = body.pop("signature")
        signer_pk = body.pop("signer_pubkey")
        canonical = canonical_bytes_for_trace(body)
        assert verify(signer_pk, canonical, sig) is True


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


def _trace_response() -> dict[str, Any]:
    return {
        "trace": {
            "trace_id": "t1",
            "agent_id": "a1",
            "error_signature": HEX_64_A,
            "error_class": None,
            "error_text": "boom",
            "task_description": "t",
            "approach_summary": "a",
            "root_cause": "r",
            "outcome": "resolved",
            "technology": None,
            "tags": [],
            "context_snapshot": {},
            "visibility": "private",
            "signed": False,
            "signature": None,
            "signer_pubkey": None,
            "created_at": 1,
        },
        "amendments": [],
        "counters": {
            "retrieved": 1,
            "read": 0,
            "applied": 0,
            "helped": 0,
            "didnt_help": 0,
        },
    }


class TestGet:
    @respx.mock
    async def test_get_200_returns_trace_detail(self, client: AsyncClient) -> None:
        respx.get(f"{BASE_URL}/api/v1/traces/t1").mock(
            return_value=httpx.Response(200, json=_trace_response())
        )
        detail = await client.get("t1")
        assert isinstance(detail, TraceDetail)
        assert detail.trace.trace_id == "t1"

    @respx.mock
    async def test_get_404(self, client: AsyncClient) -> None:
        respx.get(f"{BASE_URL}/api/v1/traces/missing").mock(
            return_value=httpx.Response(404, json=_err_envelope("not_found", trace_id="missing"))
        )
        with pytest.raises(ValidationError) as excinfo:
            await client.get("missing")
        assert excinfo.value.status == 404

    async def test_get_config_error(self, unauth_client: AsyncClient) -> None:
        with pytest.raises(ConfigError):
            await unauth_client.get("t1")


# ---------------------------------------------------------------------------
# add_amendment
# ---------------------------------------------------------------------------


class TestAddAmendment:
    @respx.mock
    async def test_default_kind(self, client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces/t1/amendments").mock(
            return_value=httpx.Response(
                201,
                json={
                    "amendment_id": "x",
                    "trace_id": "t1",
                    "kind": "clarification",
                    "created_at": 1,
                },
            )
        )
        amended = await client.add_amendment("t1", content="more context")
        assert isinstance(amended, AmendmentCreated)
        assert amended.kind is AmendmentKind.CLARIFICATION

    @respx.mock
    async def test_explicit_kind(self, client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces/t1/amendments").mock(
            return_value=httpx.Response(
                201,
                json={
                    "amendment_id": "x",
                    "trace_id": "t1",
                    "kind": "resolution",
                    "created_at": 1,
                },
            )
        )
        amended = await client.add_amendment("t1", content="fixed", kind=AmendmentKind.RESOLUTION)
        assert amended.kind is AmendmentKind.RESOLUTION

    @respx.mock
    async def test_404_trace_not_found(self, client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces/missing/amendments").mock(
            return_value=httpx.Response(
                404, json=_err_envelope("trace_not_found", trace_id="missing")
            )
        )
        with pytest.raises(ValidationError) as excinfo:
            await client.add_amendment("missing", content="x")
        assert excinfo.value.status == 404

    async def test_empty_content_rejected_locally(self, client: AsyncClient) -> None:
        from pydantic import ValidationError as PydanticValidationError

        with pytest.raises(PydanticValidationError):
            await client.add_amendment("t1", content="")


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------


def _search_response() -> dict[str, Any]:
    return {
        "results": [
            {
                "trace_id": "t1",
                "error_signature": HEX_64_A,
                "error_class": None,
                "outcome": "resolved",
                "signed": False,
                "created_at": 1,
                "preview": "boom",
                "counters": {
                    "retrieved": 1,
                    "read": 0,
                    "applied": 0,
                    "helped": 0,
                    "didnt_help": 0,
                },
            }
        ],
        "count": 1,
        "match_mode": "filter",
    }


class TestSearch:
    @respx.mock
    async def test_search_by_error_signature(self, client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/search").mock(
            return_value=httpx.Response(200, json=_search_response())
        )
        results = await client.search(error_signature=HEX_64_A)
        assert isinstance(results, SearchResults)
        assert results.count == 1

    @respx.mock
    async def test_search_by_query(self, client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/search").mock(
            return_value=httpx.Response(200, json=_search_response())
        )
        results = await client.search(query="ImportError")
        assert results.count == 1

    @respx.mock
    async def test_search_by_tags(self, client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/search").mock(
            return_value=httpx.Response(200, json=_search_response())
        )
        results = await client.search(tags=["python"])
        assert results.count == 1

    @respx.mock
    async def test_search_by_error_class(self, client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/search").mock(
            return_value=httpx.Response(200, json=_search_response())
        )
        results = await client.search(error_class="ImportError")
        assert results.count == 1

    async def test_search_no_criteria_rejected_locally(self, client: AsyncClient) -> None:
        from pydantic import ValidationError as PydanticValidationError

        with pytest.raises(PydanticValidationError):
            await client.search()

    async def test_search_empty_tags_rejected_locally(self, client: AsyncClient) -> None:
        from pydantic import ValidationError as PydanticValidationError

        with pytest.raises(PydanticValidationError):
            await client.search(tags=[])

    @respx.mock
    async def test_search_limit_passed_through(self, client: AsyncClient) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/search").mock(
            return_value=httpx.Response(200, json=_search_response())
        )
        await client.search(query="x", limit=25)
        assert b'"limit": 25' in route.calls.last.request.content


# ---------------------------------------------------------------------------
# feedback
# ---------------------------------------------------------------------------


class TestFeedback:
    @respx.mock
    async def test_minimal_claim(self, client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/feedback").mock(
            return_value=httpx.Response(
                200,
                json={"recorded": True, "trace_id": "t1", "counters_updated": True},
            )
        )
        ack = await client.feedback("t1")
        assert isinstance(ack, FeedbackAck)
        assert ack.recorded is True

    @respx.mock
    async def test_full_funnel(self, client: AsyncClient) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/feedback").mock(
            return_value=httpx.Response(
                200,
                json={"recorded": True, "trace_id": "t1", "counters_updated": True},
            )
        )
        await client.feedback(
            "t1",
            retrieved=True,
            read=True,
            applied=True,
            outcome=FeedbackOutcome.HELPED,
            note="thanks",
        )
        body = route.calls.last.request.content
        assert b'"outcome": "helped"' in body
        assert b'"note": "thanks"' in body

    async def test_funnel_violation_rejected_locally(self, client: AsyncClient) -> None:
        from pydantic import ValidationError as PydanticValidationError

        with pytest.raises(PydanticValidationError):
            await client.feedback("t1", read=True)

    @respx.mock
    async def test_feedback_counters_not_updated_path(self, client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/feedback").mock(
            return_value=httpx.Response(
                200,
                json={
                    "recorded": True,
                    "trace_id": "missing",
                    "counters_updated": False,
                    "note": "trace_not_found_but_judgment_recorded",
                },
            )
        )
        ack = await client.feedback("missing", retrieved=True)
        assert ack.counters_updated is False
        assert ack.note == "trace_not_found_but_judgment_recorded"


# ---------------------------------------------------------------------------
# rotate_pubkey
# ---------------------------------------------------------------------------


class TestRotatePubkey:
    @respx.mock
    async def test_rotate_returns_agent_pubkey(self, client: AsyncClient) -> None:
        respx.post(f"{BASE_URL}/api/v1/agents/me/pubkey").mock(
            return_value=httpx.Response(
                200,
                json={"agent_id": UUID_AGENT, "pubkey": HEX_64_B, "updated_at": 1},
            )
        )
        ack = await client.rotate_pubkey(HEX_64_B)
        assert isinstance(ack, AgentPubkey)
        assert ack.pubkey == HEX_64_B

    async def test_rotate_config_error_without_api_key(self, unauth_client: AsyncClient) -> None:
        with pytest.raises(ConfigError):
            await unauth_client.rotate_pubkey(HEX_64_B)
