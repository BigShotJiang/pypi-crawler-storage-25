"""Shared pytest configuration for the SDK test suite.

Three responsibilities:

1. Skip integration tests by default. They hit the live Worker, create
   real D1 rows, and exercise rate limits — fine for the CI gate
   ``BORG_INTEGRATION_TEST=1``, terrible for local-dev pytest watch.
2. Skip the closure test by default. It is a stricter subset of
   integration: 20+ signed traces, 20+ feedbacks, ~minute of wall
   time. Opt-in via ``BORG_CLOSURE_TEST=1`` or explicit ``-m closure``.
3. Provide session-scoped fixtures that integration tests share — a
   base URL, and one bootstrapped agent for tests that don't care
   which agent they run as.
"""

from __future__ import annotations

import os

import pytest

# The default base URL is the production-ish Worker that 4b/4c smoke
# tests already validated. Override via BORG_TEST_BASE_URL when running
# against ``wrangler dev`` or a staging Worker.
DEFAULT_INTEGRATION_BASE_URL = "https://borg-collective-v1.borg-farther.workers.dev"


def pytest_addoption(parser: pytest.Parser) -> None:
    """Closure-test-only knob: how many trials to run.

    Registered in the rootdir conftest so ``--trials`` resolves cleanly
    whether the user invokes ``pytest tests/integration/test_closure.py``
    or ``pytest -m closure``. Default of 20 is the v1 ship gate's
    minimum sample (see docs/closure-test.md).
    """
    parser.addoption(
        "--trials",
        action="store",
        type=int,
        default=20,
        help="Closure-test trial count (default: 20). Used only by `-m closure` tests.",
    )


def _explicitly_selecting_marker(config: pytest.Config, marker: str) -> bool:
    """Did the user pass ``-m <marker>`` (or an expression naming it)?

    Used to honour explicit ``-m closure`` even when the env gate is
    unset — the marker name gives intent. ``markexpr`` is the parsed
    string of the ``-m`` argument; substring match is sufficient for
    our two-marker namespace.
    """
    expr = config.getoption("markexpr") or ""
    return marker in expr


def pytest_collection_modifyitems(
    config: pytest.Config,
    items: list[pytest.Item],
) -> None:
    """Skip ``integration`` and ``closure`` markers unless explicitly enabled.

    Two independent gates:

    * ``integration`` is enabled by ``BORG_INTEGRATION_TEST=1`` or
      ``-m integration``.
    * ``closure`` is enabled by ``BORG_CLOSURE_TEST=1`` or
      ``-m closure``. ``closure`` is NOT enabled by the integration
      flag — it is strictly more expensive.

    Marker registration lives in ``pyproject.toml`` so ``--strict-markers``
    accepts both names; the env-gated skip is enforced here so a
    developer can iterate on the unit suite without burning Worker
    cycles.
    """
    integration_enabled = os.environ.get(
        "BORG_INTEGRATION_TEST"
    ) == "1" or _explicitly_selecting_marker(config, "integration")
    closure_enabled = os.environ.get("BORG_CLOSURE_TEST") == "1" or _explicitly_selecting_marker(
        config, "closure"
    )

    integration_skipper = pytest.mark.skip(
        reason="integration tests skipped — set BORG_INTEGRATION_TEST=1 or -m integration",
    )
    closure_skipper = pytest.mark.skip(
        reason="closure tests skipped — set BORG_CLOSURE_TEST=1 or -m closure",
    )
    for item in items:
        is_closure = "closure" in item.keywords
        is_integration = "integration" in item.keywords
        if is_closure:
            # Closure is a strict subset of integration — enabling
            # closure implies the live federation is OK to hit. Skip
            # only if closure itself is not enabled.
            if not closure_enabled:
                item.add_marker(closure_skipper)
            continue
        if is_integration and not integration_enabled:
            item.add_marker(integration_skipper)


# ---------------------------------------------------------------------------
# Integration-only fixtures (session-scoped — one Worker round-trip per
# fixture per session)
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def integration_base_url() -> str:
    """Worker base URL for integration tests.

    Override via the ``BORG_TEST_BASE_URL`` env var. Used by tests that
    construct their own :class:`Client` (e.g. trust-boundary tests
    that want fresh agents).
    """
    return os.environ.get("BORG_TEST_BASE_URL", DEFAULT_INTEGRATION_BASE_URL)


@pytest.fixture(scope="session")
def shared_agent_credentials(integration_base_url: str) -> tuple[str, str]:
    """Register one fresh agent per test session and yield (id, api_key).

    Most integration tests need *some* authenticated agent but don't
    care which. Sharing one across the session keeps the suite to ~10
    register calls instead of ~50, easing rate-limit pressure on
    repeated runs.

    Tests that need their own fresh agent (trust-boundary, concurrent
    agents) construct one themselves rather than using this fixture.
    """
    # Local import so an unrelated import error in the SDK doesn't trip
    # collection of the entire test suite.
    from borg_collective import Client

    with Client(base_url=integration_base_url) as bootstrap:
        agent = bootstrap.register_agent(display_name="integration-shared")
    return agent.agent_id, agent.api_key
