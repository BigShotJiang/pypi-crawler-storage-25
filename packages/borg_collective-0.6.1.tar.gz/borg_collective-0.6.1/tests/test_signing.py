"""Tests for ``borg_collective._signing``.

Covers:
  - Keypair generation: 32+32 raw bytes, hex shapes correct.
  - Sign + verify round-trip for empty / short / 1 KiB messages.
  - RFC 8032 §7.1 test 1 hardcoded vector (locked in fixture).
  - Tamper detection on message and signature.
  - Wrong-pubkey rejection.
  - Malformed-input rejection (verify never raises).
  - Full pipeline: trace dict → canonical_bytes_for_trace → sign → verify.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from borg_collective._canonical import canonical_bytes_for_trace
from borg_collective._signing import (
    SigningKeyPair,
    generate_keypair,
    sign,
    sign_trace,
    signing_key_from_hex,
    verify,
    verify_key_from_hex,
    verify_trace,
)

FIXTURE_PATH = Path(__file__).parent / "fixtures" / "error_signature_pairs.json"


@pytest.fixture(scope="module")
def rfc_vector() -> dict[str, str]:
    payload: dict[str, Any] = json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))
    vector: dict[str, str] = payload["rfc_8032_test_1"]
    return vector


# ---------------------------------------------------------------------------
# Keypair shape.
# ---------------------------------------------------------------------------


def test_generate_keypair_produces_64_hex_chars_each() -> None:
    kp = generate_keypair()
    assert len(kp.signing_key_hex) == 64
    assert len(kp.verify_key_hex) == 64
    assert all(c in "0123456789abcdef" for c in kp.signing_key_hex)
    assert all(c in "0123456789abcdef" for c in kp.verify_key_hex)


def test_keypairs_are_distinct() -> None:
    a = generate_keypair()
    b = generate_keypair()
    assert a.signing_key_hex != b.signing_key_hex
    assert a.verify_key_hex != b.verify_key_hex


def test_signing_key_from_hex_round_trip() -> None:
    a = generate_keypair()
    b = signing_key_from_hex(a.signing_key_hex)
    assert b.signing_key_hex == a.signing_key_hex
    assert b.verify_key_hex == a.verify_key_hex


def test_verify_key_from_hex_round_trip() -> None:
    a = generate_keypair()
    vk = verify_key_from_hex(a.verify_key_hex)
    # Round-trip the public bytes.
    assert bytes(vk).hex() == a.verify_key_hex


def test_signing_key_repr_redacts_secret() -> None:
    kp = generate_keypair()
    r = repr(kp)
    assert kp.signing_key_hex not in r
    assert "verify_key_hex" in r


def test_signing_key_from_hex_rejects_uppercase() -> None:
    with pytest.raises(ValueError, match="lowercase hex"):
        signing_key_from_hex("A" * 64)


def test_signing_key_from_hex_rejects_wrong_length() -> None:
    with pytest.raises(ValueError, match="lowercase hex"):
        signing_key_from_hex("0" * 63)


def test_verify_key_from_hex_rejects_uppercase() -> None:
    with pytest.raises(ValueError, match="lowercase hex"):
        verify_key_from_hex("A" * 64)


# ---------------------------------------------------------------------------
# Round-trip sign + verify.
# ---------------------------------------------------------------------------


def test_round_trip_empty_message() -> None:
    kp = generate_keypair()
    sig = sign(kp.signing_key_hex, b"")
    assert len(sig) == 128
    assert verify(kp.verify_key_hex, b"", sig) is True


def test_round_trip_short_message() -> None:
    kp = generate_keypair()
    msg = b"hello, world"
    sig = sign(kp.signing_key_hex, msg)
    assert len(sig) == 128
    assert all(c in "0123456789abcdef" for c in sig)
    assert verify(kp.verify_key_hex, msg, sig) is True


def test_round_trip_one_kib_message() -> None:
    kp = generate_keypair()
    msg = b"a" * 1024
    sig = sign(kp.signing_key_hex, msg)
    assert verify(kp.verify_key_hex, msg, sig) is True


def test_round_trip_unicode_message() -> None:
    kp = generate_keypair()
    msg = "café naïve 日本 🚀".encode()
    sig = sign(kp.signing_key_hex, msg)
    assert verify(kp.verify_key_hex, msg, sig) is True


def test_keypair_sign_bytes_method() -> None:
    kp = generate_keypair()
    msg = b"x"
    sig_method = kp.sign_bytes(msg)
    sig_func = sign(kp.signing_key_hex, msg)
    assert sig_method == sig_func


# ---------------------------------------------------------------------------
# RFC 8032 §7.1 test 1 — locked vector.
# ---------------------------------------------------------------------------


def test_rfc_8032_test_1_pubkey(rfc_vector: dict[str, str]) -> None:
    kp = signing_key_from_hex(rfc_vector["seed_hex"])
    assert kp.verify_key_hex == rfc_vector["expected_verify_key_hex"]


def test_rfc_8032_test_1_signature(rfc_vector: dict[str, str]) -> None:
    msg = bytes.fromhex(rfc_vector["message_hex"])
    sig = sign(rfc_vector["seed_hex"], msg)
    assert sig == rfc_vector["expected_signature_hex"]


def test_rfc_8032_test_1_verify(rfc_vector: dict[str, str]) -> None:
    msg = bytes.fromhex(rfc_vector["message_hex"])
    assert (
        verify(
            rfc_vector["expected_verify_key_hex"],
            msg,
            rfc_vector["expected_signature_hex"],
        )
        is True
    )


# ---------------------------------------------------------------------------
# Tamper detection.
# ---------------------------------------------------------------------------


def test_tampered_message_returns_false() -> None:
    kp = generate_keypair()
    sig = sign(kp.signing_key_hex, b"hello, world")
    assert verify(kp.verify_key_hex, b"hello, worlD", sig) is False


def test_tampered_signature_returns_false() -> None:
    kp = generate_keypair()
    msg = b"hello, world"
    sig = sign(kp.signing_key_hex, msg)
    flipped = sig[:10] + ("b" if sig[10] == "a" else "a") + sig[11:]
    assert verify(kp.verify_key_hex, msg, flipped) is False


def test_wrong_pubkey_returns_false() -> None:
    a = generate_keypair()
    b = generate_keypair()
    msg = b"hello, world"
    sig = sign(a.signing_key_hex, msg)
    assert verify(b.verify_key_hex, msg, sig) is False


# ---------------------------------------------------------------------------
# Malformed input — verify is a pure predicate, never raises.
# ---------------------------------------------------------------------------


VALID_PUB = "0" * 64
VALID_SIG = "0" * 128


@pytest.mark.parametrize("bad_pub", ["0" * 63, "0" * 65, "A" * 64, "g" * 64, "", "not-hex"])
def test_verify_returns_false_on_bad_pubkey(bad_pub: str) -> None:
    assert verify(bad_pub, b"x", VALID_SIG) is False


@pytest.mark.parametrize("bad_sig", ["0" * 127, "0" * 129, "A" * 128, "z" * 128, "", "deadbeef"])
def test_verify_returns_false_on_bad_signature(bad_sig: str) -> None:
    assert verify(VALID_PUB, b"x", bad_sig) is False


def test_verify_does_not_raise_on_well_shaped_garbage() -> None:
    # 32 zero bytes is a degenerate point; some Ed25519 impls accept it,
    # some reject. The wrapper's contract is "returns a bool", not a
    # specific outcome — that's the assertion.
    result = verify(VALID_PUB, b"x", VALID_SIG)
    assert isinstance(result, bool)


def test_sign_raises_on_bad_seed() -> None:
    # Signing is privileged: bad input should fail loudly upstream rather
    # than silently produce a wrong signature.
    with pytest.raises(ValueError, match="lowercase hex"):
        sign("not-hex", b"x")


# ---------------------------------------------------------------------------
# Full pipeline: trace dict → canonical_bytes_for_trace → sign → verify.
# ---------------------------------------------------------------------------


def _example_trace_body() -> dict[str, Any]:
    return {
        "error_signature": "abc",
        "error_text": "ModuleNotFoundError: nonexistent_pkg",
        "task_description": "run the test suite",
        "approach_summary": "pip install nonexistent_pkg",
        "root_cause": "missing dependency",
        "outcome": "resolved",
        "error_class": "python-import-error",
        "technology": "python",
        "tags": ["python", "import"],
        "context_snapshot": {"runtime": "cpython-3.11"},
        "visibility": "public",
    }


def test_full_pipeline_round_trip() -> None:
    kp = generate_keypair()
    body = _example_trace_body()
    sig = sign_trace(kp.signing_key_hex, body)
    assert verify_trace(kp.verify_key_hex, body, sig) is True


def test_full_pipeline_keypair_method_round_trip() -> None:
    kp = generate_keypair()
    body = _example_trace_body()
    sig = kp.sign_trace(body)
    canonical = canonical_bytes_for_trace(body)
    # Method ↔ free function symmetry.
    assert sig == sign(kp.signing_key_hex, canonical)
    assert verify(kp.verify_key_hex, canonical, sig) is True


def test_full_pipeline_signature_strips_top_level_sig_fields() -> None:
    # Body with stray signature/signer_pubkey fields signs the SAME bytes
    # as the body without them — that's the whole point of the top-level
    # drop, and it lets a client sign their own filled-in body without
    # zeroing the fields first.
    kp = generate_keypair()
    body = _example_trace_body()
    body_with_sig = {**body, "signature": "deadbeef" * 16, "signer_pubkey": "ca" * 32}
    a = sign_trace(kp.signing_key_hex, body)
    b = sign_trace(kp.signing_key_hex, body_with_sig)
    assert a == b


def test_full_pipeline_tamper_after_sign() -> None:
    kp = generate_keypair()
    body = _example_trace_body()
    sig = sign_trace(kp.signing_key_hex, body)
    tampered = {**body, "approach_summary": "pip install something_else"}
    assert verify_trace(kp.verify_key_hex, tampered, sig) is False


def test_verify_trace_returns_false_on_bad_body() -> None:
    # A body containing a non-serializable value should make verify_trace
    # return False (canonical_bytes_for_trace would raise; we swallow).
    kp = generate_keypair()
    body: dict[str, Any] = {"weird": object()}
    assert verify_trace(kp.verify_key_hex, body, "0" * 128) is False


def test_signing_key_pair_constructible_from_hex_class_method() -> None:
    seed = "0" * 64
    kp = SigningKeyPair.from_hex(seed)
    assert kp.signing_key_hex == seed
