"""Tests for the ``borg closure-test`` CLI subcommand.

These run in the default gate. They patch :class:`borg_collective.cli.Client`
and the ``run_closure`` entry point so no live HTTP happens — the CLI's
own logic (flag parsing, exit codes, output formatting, infra-error
handling) is what we exercise.

Coverage:

* Default trial count is 20.
* ``--trials 5`` round-trips through ``run_closure``.
* ``--output FILE`` writes a JSON file; absence streams JSON to stdout.
* ``--verbose`` instantiates a Rich progress bar.
* Exit code 0 when closure_rate=1.0; exit 1 when below threshold.
* Exit 2 when registration fails (infrastructure error).
* ``--base-url`` overrides the default URL.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any
from unittest.mock import MagicMock

import pytest
from click.testing import CliRunner

if TYPE_CHECKING:
    from pathlib import Path

from borg_collective import (
    Agent,
    AgentPubkey,
)
from borg_collective import cli as cli_module
from borg_collective._closure import ClosureResults, TrialResult
from borg_collective.cli import (
    EXIT_CLOSURE_BELOW_THRESHOLD,
    EXIT_CLOSURE_INFRASTRUCTURE,
    EXIT_OK,
    main,
)
from borg_collective.exceptions import NetworkError

_TEST_AGENT_A_ID = "11111111-1111-4111-8111-111111111111"
_TEST_AGENT_B_ID = "22222222-2222-4222-8222-222222222222"
_TEST_KEY_A = "aa" * 32
_TEST_KEY_B = "bb" * 32
_HEX_64 = "ab" * 32


def _trial(idx: int, *, success: bool = True) -> TrialResult:
    return TrialResult(
        trial_index=idx,
        trial_uuid=f"t-{idx}",
        agent_a_id=_TEST_AGENT_A_ID,
        agent_b_id=_TEST_AGENT_B_ID,
        trace_id=f"trace-{idx}",
        signed=True,
        signature_verified=success,
        feedback_published=success,
        counter_updated=success,
        outcome="success" if success else "verify_failed",
        duration_ms=1000,
        phases_ms={
            "publish": 100,
            "propagate": 300,
            "search": 50,
            "fetch": 80,
            "verify": 1,
            "feedback": 90,
            "counter_confirm": 379,
        },
        error=None if success else "fake verify failure",
    )


def _results(*, n: int, closure_rate: float) -> ClosureResults:
    n_success = int(round(n * closure_rate))
    trials = [_trial(i, success=(i < n_success)) for i in range(n)]
    return ClosureResults(
        version="1",
        timestamp_utc="2026-04-26T00:00:00+00:00",
        sdk_version="0.1.3",
        base_url="http://fake.test",
        n_trials=n,
        run_uuid="r-uuid",
        agent_a_id=_TEST_AGENT_A_ID,
        agent_b_id=_TEST_AGENT_B_ID,
        closure_rate=closure_rate,
        signature_verification_rate=1.0 if closure_rate > 0 else None,
        feedback_acceptance_rate=1.0,
        time_to_closure_ms={
            "mean": 1000.0,
            "median": 1000.0,
            "p95": 1000.0,
            "p99": 1000.0,
            "min": 1000.0,
            "max": 1000.0,
        },
        trials=trials,
    )


@pytest.fixture()
def runner() -> CliRunner:
    return CliRunner(mix_stderr=False)


@pytest.fixture()
def patched_setup(monkeypatch: pytest.MonkeyPatch) -> MagicMock:
    """Patch the agent-pair setup to skip live HTTP.

    Returns a MagicMock standing in for ``run_closure`` so tests can
    assert call args (most notably the ``n_trials`` value).
    """
    # Patch the bootstrap registration helper to short-circuit.
    fake_agent_a = Agent(
        agent_id=_TEST_AGENT_A_ID,
        display_name="closure-a",
        trust_level="soft",
        created_at=0,
        api_key=_TEST_KEY_A,
    )
    fake_agent_b = Agent(
        agent_id=_TEST_AGENT_B_ID,
        display_name="closure-b",
        trust_level="soft",
        created_at=0,
        api_key=_TEST_KEY_B,
    )

    # The closure subcommand calls Client(...) directly four times:
    # (1) bootstrap register A, (2) bootstrap register B,
    # (3) rotate_pubkey A, (4) rotate_pubkey B,
    # (5+6) the two long-lived clients passed into run_closure.
    # Rather than enumerate, patch Client to a MagicMock factory.
    fake_client_factory = MagicMock(name="ClientFactory")

    def _make_instance() -> MagicMock:
        instance = MagicMock(name="ClientInstance")
        instance.__enter__.return_value = instance
        instance.__exit__.return_value = False
        # Alternate between the two agents so the first register
        # returns A and the second returns B.
        return instance

    # Each Client() call yields a fresh MagicMock; configure registration
    # on each via a side_effect cycle.
    register_seq = [fake_agent_a, fake_agent_b]

    def _client_init(*args: Any, **kwargs: Any) -> MagicMock:  # noqa: ARG001
        instance = _make_instance()
        if register_seq:
            instance.register_agent.return_value = register_seq.pop(0)
        instance.rotate_pubkey.return_value = AgentPubkey(
            agent_id=_TEST_AGENT_A_ID, pubkey=_HEX_64, updated_at=0
        )
        return instance

    fake_client_factory.side_effect = _client_init
    monkeypatch.setattr(cli_module, "Client", fake_client_factory)

    fake_run_closure = MagicMock(name="run_closure")
    fake_run_closure.return_value = _results(n=20, closure_rate=1.0)
    monkeypatch.setattr(cli_module, "run_closure", fake_run_closure)

    monkeypatch.delenv("BORG_CLOSURE_AGENT_A_ID", raising=False)
    monkeypatch.delenv("BORG_CLOSURE_AGENT_A_KEY", raising=False)
    monkeypatch.delenv("BORG_CLOSURE_AGENT_B_ID", raising=False)
    monkeypatch.delenv("BORG_CLOSURE_AGENT_B_KEY", raising=False)
    monkeypatch.delenv("BORG_BASE_URL", raising=False)

    return fake_run_closure


# ---------------------------------------------------------------------------
# Default trial count + happy path (exit 0)
# ---------------------------------------------------------------------------


def test_default_trials_is_20(runner: CliRunner, patched_setup: MagicMock) -> None:
    """No --trials flag → run_closure called with n_trials=20."""
    result = runner.invoke(main, ["closure-test"])
    assert result.exit_code == EXIT_OK, result.output
    call = patched_setup.call_args
    assert call.kwargs["n_trials"] == 20


def test_trials_flag_passes_through(runner: CliRunner, patched_setup: MagicMock) -> None:
    """--trials 5 → run_closure called with n_trials=5."""
    patched_setup.return_value = _results(n=5, closure_rate=1.0)
    result = runner.invoke(main, ["closure-test", "--trials", "5"])
    assert result.exit_code == EXIT_OK, result.output
    assert patched_setup.call_args.kwargs["n_trials"] == 5


# ---------------------------------------------------------------------------
# Output: stdout JSON vs. --output FILE
# ---------------------------------------------------------------------------


def test_default_output_streams_json_to_stdout(
    runner: CliRunner,
    patched_setup: MagicMock,  # noqa: ARG001
) -> None:
    """No --output → JSON on stdout, no file written."""
    result = runner.invoke(main, ["closure-test"])
    assert result.exit_code == EXIT_OK, result.output
    payload = json.loads(result.stdout)
    assert payload["closure_rate"] == 1.0
    assert payload["n_trials"] == 20
    assert payload["version"] == "1"


def test_output_path_writes_file(
    runner: CliRunner,
    patched_setup: MagicMock,  # noqa: ARG001
    tmp_path: Path,
) -> None:
    """--output FILE writes JSON; stdout shows summary table not JSON."""
    out_path = tmp_path / "results.json"
    result = runner.invoke(main, ["closure-test", "--output", str(out_path)])
    assert result.exit_code == EXIT_OK, result.output
    assert out_path.exists()
    payload = json.loads(out_path.read_text(encoding="utf-8"))
    assert payload["closure_rate"] == 1.0
    # stdout is the summary table, not raw JSON.
    assert "closure_rate" in result.stdout
    assert "100.00%" in result.stdout


# ---------------------------------------------------------------------------
# --base-url override
# ---------------------------------------------------------------------------


def test_base_url_flag_overrides(runner: CliRunner, patched_setup: MagicMock) -> None:
    """--base-url X → run_closure receives base_url=X."""
    result = runner.invoke(main, ["closure-test", "--base-url", "http://override.test"])
    assert result.exit_code == EXIT_OK, result.output
    assert patched_setup.call_args.kwargs["base_url"] == "http://override.test"


# ---------------------------------------------------------------------------
# Exit codes
# ---------------------------------------------------------------------------


def test_exit_zero_when_above_threshold(runner: CliRunner, patched_setup: MagicMock) -> None:
    """closure_rate=1.0 → exit 0."""
    patched_setup.return_value = _results(n=20, closure_rate=1.0)
    result = runner.invoke(main, ["closure-test"])
    assert result.exit_code == EXIT_OK


def test_exit_one_when_below_threshold(runner: CliRunner, patched_setup: MagicMock) -> None:
    """closure_rate=0.5 → exit 1."""
    patched_setup.return_value = _results(n=20, closure_rate=0.5)
    result = runner.invoke(main, ["closure-test"])
    assert result.exit_code == EXIT_CLOSURE_BELOW_THRESHOLD
    assert "below 95% threshold" in result.stderr


def test_exit_two_on_registration_failure(
    runner: CliRunner,  # noqa: ARG001  unused but reserved for parity with other tests
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Bootstrap register raises NetworkError → exit 2 (infrastructure)."""
    monkeypatch.delenv("BORG_CLOSURE_AGENT_A_ID", raising=False)
    monkeypatch.delenv("BORG_CLOSURE_AGENT_A_KEY", raising=False)
    monkeypatch.delenv("BORG_CLOSURE_AGENT_B_ID", raising=False)
    monkeypatch.delenv("BORG_CLOSURE_AGENT_B_KEY", raising=False)
    monkeypatch.delenv("BORG_BASE_URL", raising=False)

    fake_client_factory = MagicMock(name="ClientFactory")

    def _client_init(*args: Any, **kwargs: Any) -> MagicMock:  # noqa: ARG001
        instance = MagicMock(name="ClientInstance")
        instance.__enter__.return_value = instance
        instance.__exit__.return_value = False
        instance.register_agent.side_effect = NetworkError("connect failed")
        return instance

    fake_client_factory.side_effect = _client_init
    monkeypatch.setattr(cli_module, "Client", fake_client_factory)

    runner_local = CliRunner(mix_stderr=False)
    result = runner_local.invoke(main, ["closure-test"])
    assert result.exit_code == EXIT_CLOSURE_INFRASTRUCTURE
    assert "setup failed" in result.stderr


# ---------------------------------------------------------------------------
# --verbose enables progress bar
# ---------------------------------------------------------------------------


def test_verbose_starts_progress_bar(
    runner: CliRunner,
    patched_setup: MagicMock,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """--verbose instantiates rich.progress.Progress (lazy import).

    We can't grep stdout for the bar (Rich detects the test runner's
    non-tty stdout and renders nothing). Instead, patch Progress at
    its import site and assert it was instantiated and started.
    """
    progress_started = []

    class _FakeProgress:
        def __init__(self, *args: Any, **kwargs: Any) -> None:  # noqa: ARG002
            progress_started.append("init")

        def start(self) -> None:
            progress_started.append("start")

        def stop(self) -> None:
            progress_started.append("stop")

        def add_task(self, *args: Any, **kwargs: Any) -> int:  # noqa: ARG002
            return 0

        def update(self, *args: Any, **kwargs: Any) -> None:  # noqa: ARG002
            return None

    import rich.progress as rp

    monkeypatch.setattr(rp, "Progress", _FakeProgress)
    patched_setup.return_value = _results(n=2, closure_rate=1.0)
    result = runner.invoke(main, ["closure-test", "--trials", "2", "--verbose"])
    assert result.exit_code == EXIT_OK, result.output
    assert "init" in progress_started
    assert "start" in progress_started
    assert "stop" in progress_started
