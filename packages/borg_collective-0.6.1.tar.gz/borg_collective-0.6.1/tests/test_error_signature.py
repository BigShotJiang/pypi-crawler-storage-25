"""Tests for ``borg_collective._error_signature``.

Covers:
  - Each normalization rule individually (mirrors the Worker's
    ``test/error-signature.test.ts`` cases).
  - The locked-pairs fixture at
    ``tests/fixtures/error_signature_pairs.json`` — generated once from
    the spec-faithful implementation and committed as a regression
    bound. Any change to canonicalization or normalization breaks it
    by design.
  - Determinism over 1000 iterations.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from borg_collective._error_signature import compute_error_signature, normalize_error_text

FIXTURE_PATH = Path(__file__).parent / "fixtures" / "error_signature_pairs.json"


@pytest.fixture(scope="module")
def fixture() -> dict[str, Any]:
    data: dict[str, Any] = json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))
    return data


# ---------------------------------------------------------------------------
# Per-rule normalization (mirrors Worker's test/error-signature.test.ts).
# ---------------------------------------------------------------------------


def test_lowercases() -> None:
    assert normalize_error_text("FooBar") == "foobar"


def test_collapses_at_line_n() -> None:
    assert normalize_error_text("at line 42") == "at line n"
    assert normalize_error_text("File.py at line 42 failed") == normalize_error_text(
        "File.py at line 57 failed",
    )


def test_collapses_bare_line_n() -> None:
    assert normalize_error_text("SyntaxError line 3") == "syntaxerror line n"


def test_collapses_file_lc_coordinates() -> None:
    assert normalize_error_text("at foo.ts:42:7") == "at foo.ts:lc"


def test_collapses_memory_addresses() -> None:
    assert normalize_error_text("segfault at 0xdeadbeef") == "segfault at 0xaddr"
    # Uppercase hex in the source: lowercased first, then matched.
    assert normalize_error_text("segfault at 0xDEADBEEF") == "segfault at 0xaddr"


def test_collapses_iso_timestamps() -> None:
    assert normalize_error_text("failed at 2026-04-24T15:30:45Z") == "failed at iso-ts"
    assert normalize_error_text("failed at 2026-04-24T15:30:45.123456") == "failed at iso-ts"


def test_iso_rule_runs_before_lc_rule() -> None:
    # If :L:C runs first, "T15:30:45.123" would have its ":30:45" eaten,
    # leaving the ISO regex nothing to match. A fixture pair locks this
    # explicitly; here we assert the resulting text is the canonical form
    # rather than the broken intermediate.
    assert normalize_error_text("boom at 2026-04-24T15:30:45.123Z") == "boom at iso-ts"


def test_collapses_long_digit_runs() -> None:
    assert normalize_error_text("pid 1234567890 died") == "pid n died"


def test_short_digit_runs_untouched() -> None:
    # 3 digits — could be HTTP status, semver patch, count. Don't collapse.
    assert normalize_error_text("HTTP 500") == "http 500"


def test_collapses_whitespace_and_trims() -> None:
    assert normalize_error_text("  foo\n\n  bar   baz  ") == "foo bar baz"


# ---------------------------------------------------------------------------
# compute_error_signature shape + invariance.
# ---------------------------------------------------------------------------


def test_signature_is_64_lowercase_hex() -> None:
    sig = compute_error_signature(
        error_class="python-import-error",
        error_text="NameError: foo",
        technology="python",
    )
    assert len(sig) == 64
    assert all(c in "0123456789abcdef" for c in sig)


def test_signature_is_deterministic_across_calls() -> None:
    a = compute_error_signature(error_class="x", error_text="y", technology="z")
    b = compute_error_signature(error_class="x", error_text="y", technology="z")
    assert a == b


def test_signature_invariant_to_line_numbers() -> None:
    a = compute_error_signature(
        error_class="x",
        error_text="at main.py at line 42: NameError",
        technology="python",
    )
    b = compute_error_signature(
        error_class="x",
        error_text="at main.py at line 57: NameError",
        technology="python",
    )
    assert a == b


def test_signature_invariant_to_memory_addresses() -> None:
    a = compute_error_signature(error_class="crash", error_text="segfault at 0xdeadbeef")
    b = compute_error_signature(error_class="crash", error_text="segfault at 0x00000001")
    assert a == b


def test_signature_invariant_to_timestamps() -> None:
    a = compute_error_signature(error_class="io", error_text="failed at 2026-04-24T15:30:45Z")
    b = compute_error_signature(error_class="io", error_text="failed at 2019-01-01T00:00:00Z")
    assert a == b


def test_signature_invariant_to_class_and_tech_case() -> None:
    a = compute_error_signature(
        error_class="Python-Import-Error",
        error_text="err",
        technology="Python",
    )
    b = compute_error_signature(
        error_class="python-import-error",
        error_text="err",
        technology="python",
    )
    assert a == b


def test_different_error_class_different_signature() -> None:
    a = compute_error_signature(error_class="python-import-error", error_text="err")
    b = compute_error_signature(error_class="generic-error", error_text="err")
    assert a != b


def test_handles_none_class_and_tech() -> None:
    a = compute_error_signature(error_text="x")
    b = compute_error_signature(error_text="x", error_class=None, technology=None)
    assert a == b


def test_handles_empty_error_text() -> None:
    sig = compute_error_signature(error_text="")
    assert len(sig) == 64
    assert all(c in "0123456789abcdef" for c in sig)


# ---------------------------------------------------------------------------
# Locked-pairs fixture — regression bound on canonicalization + normalization.
# ---------------------------------------------------------------------------


def test_fixture_pairs_match(fixture: dict[str, Any]) -> None:
    for pair in fixture["pairs"]:
        got_norm = normalize_error_text(pair["input"]["error_text"])
        assert got_norm == pair["normalized_text"], (
            f"normalize drift on {pair['label']!r}: "
            f"got {got_norm!r}, expected {pair['normalized_text']!r}"
        )
        got_sig = compute_error_signature(**pair["input"])
        assert got_sig == pair["signature"], (
            f"signature drift on {pair['label']!r}: " f"got {got_sig}, expected {pair['signature']}"
        )


def test_fixture_invariants_hold(fixture: dict[str, Any]) -> None:
    by_label = {p["label"]: p["signature"] for p in fixture["pairs"]}
    for left, right in fixture["invariants_must_match"]:
        assert (
            by_label[left] == by_label[right]
        ), f"invariance broken between {left!r} and {right!r}"


# ---------------------------------------------------------------------------
# Determinism property — 1000 iterations of the same input.
# ---------------------------------------------------------------------------


@given(
    text=st.text(min_size=0, max_size=128),
    cls=st.one_of(st.none(), st.text(min_size=0, max_size=32)),
    tech=st.one_of(st.none(), st.text(min_size=0, max_size=32)),
)
@settings(max_examples=1000, deadline=None)
def test_signature_is_deterministic_property(
    text: str,
    cls: str | None,
    tech: str | None,
) -> None:
    a = compute_error_signature(error_text=text, error_class=cls, technology=tech)
    b = compute_error_signature(error_text=text, error_class=cls, technology=tech)
    assert a == b
    assert len(a) == 64
    assert all(c in "0123456789abcdef" for c in a)
