"""Integration tests for offline-mode :class:`Client` + :class:`AsyncClient`.

Coverage matrix:

* offline_mode=True publish() enqueues without hitting the network and
  returns a stub PublishedTrace with trace_id="local:{queue_id}".
* offline_mode=True {whoami, get, search, feedback, add_amendment,
  rotate_pubkey, register_agent} all raise OfflineError.
* drain() against respx-mocked transport: 3 enqueued items become 3
  publish calls; all 200 → all rows deleted; report counts match.
* drain() with intermittent 503: failing item is mark_attempted'd
  and stays in queue; report counts deferred=1.
* drain() AuthError on item 1 → stops early, marks item 1, report
  has stopped_early=True and the rest stay in the queue.
* drain() ValidationError on item → counts failed, row remains.
* drain() with no offline_queue raises OfflineError.
* offline_mode=False + offline_queue_path + NetworkError → trace is
  enqueued as fallback AND NetworkError is re-raised.
* offline_queue property surfaces the configured queue.
* AsyncClient mirror of all the above (subset that proves the pattern).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import httpx
import pytest
import respx

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator, Generator
    from pathlib import Path

from borg_collective import (
    AsyncClient,
    Client,
    DrainReport,
    FailureTrace,
    OfflineError,
    OfflineQueue,
    Outcome,
)

BASE_URL = "https://test.invalid"
TEST_API_KEY = "a" * 64

HEX_64 = "a" * 64


def _trace_kwargs(**overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "error_text": "ImportError: foo",
        "task_description": "td",
        "approach_summary": "as",
        "root_cause": "rc",
        "outcome": Outcome.RESOLVED,
    }
    base.update(overrides)
    return base


def _err_envelope(error_code: str, **extras: Any) -> dict[str, Any]:
    return {"error": error_code, "request_id": "req_test", **extras}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def queue_path(tmp_path: Path) -> Path:
    return tmp_path / "queue.sqlite"


@pytest.fixture()
def offline_client(queue_path: Path) -> Generator[Client, None, None]:
    c = Client(
        api_key=TEST_API_KEY,
        base_url=BASE_URL,
        backoff_base_s=0.0,
        offline_mode=True,
        offline_queue_path=queue_path,
    )
    yield c
    c.close()


@pytest.fixture()
def online_client_with_queue(queue_path: Path) -> Generator[Client, None, None]:
    """An online Client that also has a queue wired for fallback."""
    c = Client(
        api_key=TEST_API_KEY,
        base_url=BASE_URL,
        backoff_base_s=0.0,
        offline_queue_path=queue_path,
    )
    yield c
    c.close()


@pytest.fixture()
async def offline_async_client(queue_path: Path) -> AsyncGenerator[AsyncClient, None]:
    c = AsyncClient(
        api_key=TEST_API_KEY,
        base_url=BASE_URL,
        backoff_base_s=0.0,
        offline_mode=True,
        offline_queue_path=queue_path,
    )
    yield c
    await c.aclose()


# ---------------------------------------------------------------------------
# Sync — offline_mode publish enqueues
# ---------------------------------------------------------------------------


class TestOfflineModePublish:
    def test_publish_enqueues_and_returns_stub(self, offline_client: Client) -> None:
        published = offline_client.publish(FailureTrace(**_trace_kwargs()))
        assert published.trace_id.startswith("local:")
        assert published.signed is False
        assert published.warning == "offline_enqueued"
        assert offline_client.offline_queue is not None
        assert offline_client.offline_queue.size() == 1

    def test_publish_does_not_hit_network_in_offline_mode(self, offline_client: Client) -> None:
        # respx.mock is NOT active here — if any HTTP request leaked
        # out we would see a real DNS lookup + connection error. The
        # absence of those is the assertion.
        for _ in range(3):
            offline_client.publish(FailureTrace(**_trace_kwargs()))
        assert offline_client.offline_queue is not None
        assert offline_client.offline_queue.size() == 3

    def test_publish_signed_in_offline_mode_records_signature(self, offline_client: Client) -> None:
        from borg_collective._signing import SigningKeyPair

        kp = SigningKeyPair.generate()
        published = offline_client.publish(FailureTrace(**_trace_kwargs()), signing_key=kp)
        assert published.signed is True
        # Body in queue carries signature + signer_pubkey + error_signature.
        assert offline_client.offline_queue is not None
        item = offline_client.offline_queue.peek()[0]
        assert item.payload["signer_pubkey"] == kp.verify_key_hex
        assert "signature" in item.payload
        assert "error_signature" in item.payload

    def test_publish_returns_distinct_trace_ids(self, offline_client: Client) -> None:
        ids = {offline_client.publish(FailureTrace(**_trace_kwargs())).trace_id for _ in range(3)}
        assert len(ids) == 3


# ---------------------------------------------------------------------------
# Sync — offline_mode rejects read paths
# ---------------------------------------------------------------------------


class TestOfflineModeRejectsReads:
    def test_whoami_raises_offline_error(self, offline_client: Client) -> None:
        with pytest.raises(OfflineError):
            offline_client.whoami()

    def test_get_raises_offline_error(self, offline_client: Client) -> None:
        with pytest.raises(OfflineError):
            offline_client.get("trace-id")

    def test_search_raises_offline_error(self, offline_client: Client) -> None:
        with pytest.raises(OfflineError):
            offline_client.search(query="x")

    def test_feedback_raises_offline_error(self, offline_client: Client) -> None:
        with pytest.raises(OfflineError):
            offline_client.feedback("trace-id", retrieved=True)

    def test_add_amendment_raises_offline_error(self, offline_client: Client) -> None:
        with pytest.raises(OfflineError):
            offline_client.add_amendment("trace-id", content="x")

    def test_rotate_pubkey_raises_offline_error(self, offline_client: Client) -> None:
        with pytest.raises(OfflineError):
            offline_client.rotate_pubkey(HEX_64)


# ---------------------------------------------------------------------------
# Sync — drain()
# ---------------------------------------------------------------------------


class TestDrain:
    @respx.mock
    def test_drain_three_items_all_succeed(self, offline_client: Client, queue_path: Path) -> None:
        # We need a NON-offline-mode client to actually drain — the
        # offline_mode=True client never hits the network, including
        # in drain(). Construct the drain client sharing the same
        # queue path; when both Clients hold the queue, only the one
        # that owns it should close it (it's path-shared, not
        # instance-shared, here — we're sharing via the file).
        for _ in range(3):
            offline_client.publish(FailureTrace(**_trace_kwargs()))
        assert offline_client.offline_queue is not None
        assert offline_client.offline_queue.size() == 3
        # Close the offline client's connection so the drain client
        # opens a fresh one against the same file.
        offline_client.offline_queue.close()

        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={"trace_id": "tid", "signed": False, "error_signature": HEX_64},
            )
        )
        drain_client = Client(
            api_key=TEST_API_KEY,
            base_url=BASE_URL,
            backoff_base_s=0.0,
            offline_queue_path=queue_path,
        )
        try:
            report = drain_client.drain()
        finally:
            drain_client.close()
        assert isinstance(report, DrainReport)
        assert report.drained == 3
        assert report.deferred == 0
        assert report.failed == 0
        assert report.stopped_early is False
        assert route.call_count == 3

    @respx.mock
    def test_drain_503_defers(self, queue_path: Path) -> None:
        q = OfflineQueue(queue_path)
        try:
            q.enqueue("a", _trace_kwargs(error_text="will-fail"))
            q.enqueue("a", _trace_kwargs(error_text="will-also-fail"))
        finally:
            q.close()

        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(503, json=_err_envelope("upstream_down"))
        )
        c = Client(
            api_key=TEST_API_KEY,
            base_url=BASE_URL,
            backoff_base_s=0.0,
            offline_queue_path=queue_path,
        )
        try:
            report = c.drain()
            assert report.drained == 0
            assert report.deferred == 2
            assert report.failed == 0
            # Rows still in queue, attempt_count incremented.
            assert c.offline_queue is not None
            items = c.offline_queue.peek()
            assert len(items) == 2
            assert all(item.attempt_count == 1 for item in items)
        finally:
            c.close()

    @respx.mock
    def test_drain_auth_error_stops_early(self, queue_path: Path) -> None:
        q = OfflineQueue(queue_path)
        try:
            for _ in range(3):
                q.enqueue("a", _trace_kwargs())
        finally:
            q.close()

        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(403, json=_err_envelope("invalid_key"))
        )
        c = Client(
            api_key=TEST_API_KEY,
            base_url=BASE_URL,
            backoff_base_s=0.0,
            offline_queue_path=queue_path,
        )
        try:
            report = c.drain()
            assert report.stopped_early is True
            assert report.deferred == 1
            assert report.drained == 0
            assert report.failed == 0
            # Only one HTTP call was issued — the rest of the drain stopped.
            assert route.call_count == 1
            # Three rows remain in queue.
            assert c.offline_queue is not None
            assert c.offline_queue.size() == 3
        finally:
            c.close()

    @respx.mock
    def test_drain_validation_error_marks_failed(self, queue_path: Path) -> None:
        q = OfflineQueue(queue_path)
        try:
            q.enqueue("a", _trace_kwargs())
            q.enqueue("a", _trace_kwargs())
        finally:
            q.close()

        # First call 400, second 201 — drain continues past failures.
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            side_effect=[
                httpx.Response(400, json=_err_envelope("bad_outcome")),
                httpx.Response(
                    201,
                    json={"trace_id": "t", "signed": False, "error_signature": HEX_64},
                ),
            ]
        )
        c = Client(
            api_key=TEST_API_KEY,
            base_url=BASE_URL,
            backoff_base_s=0.0,
            offline_queue_path=queue_path,
        )
        try:
            report = c.drain()
            assert report.failed == 1
            assert report.drained == 1
            assert report.deferred == 0
            # Failed row still in queue (with mark_attempted bump).
            assert c.offline_queue is not None
            assert c.offline_queue.size() == 1
            assert route.call_count == 2
        finally:
            c.close()

    def test_drain_without_queue_raises_offline_error(self) -> None:
        c = Client(api_key=TEST_API_KEY, base_url=BASE_URL, backoff_base_s=0.0)
        try:
            with pytest.raises(OfflineError):
                c.drain()
        finally:
            c.close()

    def test_drain_max_items_must_be_positive(self, queue_path: Path) -> None:
        c = Client(
            api_key=TEST_API_KEY,
            base_url=BASE_URL,
            backoff_base_s=0.0,
            offline_queue_path=queue_path,
        )
        try:
            with pytest.raises(ValueError, match="max_items"):
                c.drain(max_items=0)
        finally:
            c.close()


# ---------------------------------------------------------------------------
# Sync — fallback queue on NetworkError
# ---------------------------------------------------------------------------


class TestNetworkErrorFallback:
    @respx.mock
    def test_network_error_enqueues_and_re_raises(self, online_client_with_queue: Client) -> None:
        from borg_collective.exceptions import NetworkError

        respx.post(f"{BASE_URL}/api/v1/traces").mock(side_effect=httpx.ConnectError("dns fail"))
        with pytest.raises(NetworkError):
            online_client_with_queue.publish(FailureTrace(**_trace_kwargs()))
        # The exception still raises, AND the trace is now queued.
        assert online_client_with_queue.offline_queue is not None
        assert online_client_with_queue.offline_queue.size() == 1

    @respx.mock
    def test_network_error_without_queue_just_raises(self) -> None:
        from borg_collective.exceptions import NetworkError

        respx.post(f"{BASE_URL}/api/v1/traces").mock(side_effect=httpx.ConnectError("dns fail"))
        c = Client(api_key=TEST_API_KEY, base_url=BASE_URL, backoff_base_s=0.0)
        try:
            with pytest.raises(NetworkError):
                c.publish(FailureTrace(**_trace_kwargs()))
        finally:
            c.close()


# ---------------------------------------------------------------------------
# Sync — offline_queue property + injection
# ---------------------------------------------------------------------------


class TestQueueWiring:
    def test_offline_queue_property_when_unset_is_none(self) -> None:
        c = Client(api_key=TEST_API_KEY, base_url=BASE_URL, backoff_base_s=0.0)
        try:
            assert c.offline_queue is None
        finally:
            c.close()

    def test_injected_queue_not_closed_by_client(self, queue_path: Path) -> None:
        injected = OfflineQueue(queue_path)
        try:
            c = Client(
                api_key=TEST_API_KEY,
                base_url=BASE_URL,
                backoff_base_s=0.0,
                offline_queue=injected,
            )
            c.close()  # should NOT close injected
            # Still usable.
            injected.size()
        finally:
            injected.close()

    def test_offline_mode_default_path_used_when_no_path_given(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        # Redirect the default path so the test doesn't write to the
        # user's actual ~/.borg directory.
        from borg_collective import _offline as offline_mod
        from borg_collective import client as client_mod

        custom = tmp_path / ".borg" / "offline_queue.sqlite"
        monkeypatch.setattr(offline_mod, "DEFAULT_OFFLINE_QUEUE_PATH", custom)
        monkeypatch.setattr(client_mod, "DEFAULT_OFFLINE_QUEUE_PATH", custom)

        c = Client(
            api_key=TEST_API_KEY,
            base_url=BASE_URL,
            backoff_base_s=0.0,
            offline_mode=True,
        )
        try:
            assert c.offline_queue is not None
            assert c.offline_queue.path == custom
        finally:
            c.close()


# ---------------------------------------------------------------------------
# Async mirror — abridged (the pattern is identical to sync)
# ---------------------------------------------------------------------------


class TestAsyncOfflineMode:
    async def test_publish_enqueues_and_returns_stub(
        self, offline_async_client: AsyncClient
    ) -> None:
        published = await offline_async_client.publish(FailureTrace(**_trace_kwargs()))
        assert published.trace_id.startswith("local:")
        assert offline_async_client.offline_queue is not None
        assert offline_async_client.offline_queue.size() == 1

    async def test_whoami_raises_offline_error(self, offline_async_client: AsyncClient) -> None:
        with pytest.raises(OfflineError):
            await offline_async_client.whoami()

    async def test_get_raises_offline_error(self, offline_async_client: AsyncClient) -> None:
        with pytest.raises(OfflineError):
            await offline_async_client.get("t")

    async def test_search_raises_offline_error(self, offline_async_client: AsyncClient) -> None:
        with pytest.raises(OfflineError):
            await offline_async_client.search(query="x")

    @respx.mock
    async def test_drain_succeeds_against_mock_worker(self, queue_path: Path) -> None:
        q = OfflineQueue(queue_path)
        try:
            for _ in range(2):
                q.enqueue("a", _trace_kwargs())
        finally:
            q.close()

        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={"trace_id": "t", "signed": False, "error_signature": HEX_64},
            )
        )
        c = AsyncClient(
            api_key=TEST_API_KEY,
            base_url=BASE_URL,
            backoff_base_s=0.0,
            offline_queue_path=queue_path,
        )
        try:
            report = await c.drain()
            assert report.drained == 2
            assert route.call_count == 2
        finally:
            await c.aclose()

    async def test_drain_without_queue_raises(self) -> None:
        c = AsyncClient(api_key=TEST_API_KEY, base_url=BASE_URL, backoff_base_s=0.0)
        try:
            with pytest.raises(OfflineError):
                await c.drain()
        finally:
            await c.aclose()
