"""Tests for ``borg_collective.exceptions``.

Covers:
  * BorgError hierarchy — every subclass is catchable as BorgError.
  * Context fields (status, error_code, retry_after_s, bucket, cause).
  * Defense-in-depth: no exception's __repr__ leaks an api_key, even one
    that has been illegally attached as an attribute.
  * SignatureError surfaces the canonical-drift hint in __repr__.
"""

from __future__ import annotations

import pytest

from borg_collective.exceptions import (
    AuthError,
    BorgError,
    ConfigError,
    NetworkError,
    OfflineError,
    RateLimitError,
    ServerError,
    SignatureError,
    ValidationError,
)

# ---------------------------------------------------------------------------
# Hierarchy
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "exc",
    [
        ConfigError("boom"),
        AuthError("nope", status=401),
        ValidationError("bad", status=400, error_code="missing_field"),
        SignatureError(),
        RateLimitError("slow down", retry_after_s=42, bucket="publish"),
        NetworkError("connect failed"),
        ServerError("internal", status=500, error_code="internal"),
        OfflineError("offline"),
    ],
)
def test_every_exception_inherits_borgerror(exc: BorgError) -> None:
    assert isinstance(exc, BorgError)
    assert isinstance(exc, Exception)


def test_signature_error_is_a_validation_error() -> None:
    exc = SignatureError()
    assert isinstance(exc, ValidationError)
    assert isinstance(exc, BorgError)


def test_borg_error_carries_message() -> None:
    exc = BorgError("hello")
    assert exc.message == "hello"
    assert str(exc) == "hello"


# ---------------------------------------------------------------------------
# Context fields
# ---------------------------------------------------------------------------


def test_auth_error_carries_status_and_code() -> None:
    exc = AuthError("bad credential", status=403, error_code="invalid_key")
    assert exc.status == 403
    assert exc.error_code == "invalid_key"


def test_validation_error_carries_status_code_details() -> None:
    exc = ValidationError(
        "missing field",
        status=400,
        error_code="missing_field",
        details={"field": "outcome"},
    )
    assert exc.status == 400
    assert exc.error_code == "missing_field"
    assert exc.details == {"field": "outcome"}


def test_validation_error_details_default_to_empty_dict() -> None:
    exc = ValidationError("x", status=400)
    assert exc.details == {}


def test_signature_error_defaults_match_worker() -> None:
    exc = SignatureError()
    assert exc.status == 422
    assert exc.error_code == "bad_signature"


def test_rate_limit_error_carries_retry_after_and_bucket() -> None:
    exc = RateLimitError("slow", retry_after_s=120, bucket="publish")
    assert exc.retry_after_s == 120
    assert exc.bucket == "publish"
    assert exc.status == 429


def test_network_error_carries_optional_cause() -> None:
    inner = TimeoutError("read timeout")
    exc = NetworkError("upstream timeout", cause=inner)
    assert exc.cause is inner

    bare = NetworkError("no cause")
    assert bare.cause is None


def test_server_error_carries_status_and_code() -> None:
    exc = ServerError("collision", status=500, error_code="id_collision")
    assert exc.status == 500
    assert exc.error_code == "id_collision"


# ---------------------------------------------------------------------------
# Defense in depth — no api_key leak via __repr__
# ---------------------------------------------------------------------------


SECRET_HEX = "f" * 64


@pytest.mark.parametrize(
    "exc",
    [
        BorgError("oops"),
        ConfigError("missing key"),
        AuthError("bad credential", status=403, error_code="invalid_key"),
        ValidationError("bad", status=400, error_code="missing_field"),
        SignatureError(),
        RateLimitError("slow", retry_after_s=10, bucket="publish"),
        NetworkError("upstream timeout", cause=TimeoutError("t")),
        ServerError("internal", status=500, error_code="internal"),
        OfflineError("offline"),
    ],
)
def test_repr_never_leaks_api_key_even_if_smuggled(exc: BorgError) -> None:
    """If something attaches an api_key to the exception by mistake, the
    repr/str surfaces still must not leak it. The exceptions explicitly
    do not store api_keys; the test confirms that adding one as a stray
    attribute does not bleed into the structured repr the SDK ships.
    """
    exc.api_key = SECRET_HEX  # type: ignore[attr-defined]
    rendered = repr(exc) + " " + str(exc)
    assert SECRET_HEX not in rendered


def test_repr_uses_class_name() -> None:
    exc = ValidationError("bad", status=400, error_code="missing_field")
    rendered = repr(exc)
    assert "ValidationError" in rendered
    assert "missing_field" in rendered
    assert "400" in rendered


def test_signature_error_repr_contains_canonical_drift_hint() -> None:
    rendered = repr(SignatureError())
    assert "canonical-form drift" in rendered
    assert "bad_signature" in rendered


def test_rate_limit_error_repr_contains_bucket_and_retry() -> None:
    rendered = repr(RateLimitError("slow", retry_after_s=42, bucket="publish"))
    assert "publish" in rendered
    assert "42" in rendered
