"""Tests for ``borg_collective._canonical``.

The single non-negotiable assertion is the byte-identical fixture
round-trip — ``tests/fixtures/canonical-v1.json`` is the wire contract,
copied verbatim from the Worker's ``test/fixtures/canonical-v1.json``.
Any drift breaks signing across every peer simultaneously.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from borg_collective._canonical import canonical_bytes, canonical_bytes_for_trace

FIXTURE_PATH = Path(__file__).parent / "fixtures" / "canonical-v1.json"


@pytest.fixture(scope="module")
def fixture() -> dict[str, Any]:
    data: dict[str, Any] = json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))
    return data


# ---------------------------------------------------------------------------
# THE contract test — byte-identical with the Worker's TS implementation.
# ---------------------------------------------------------------------------


def test_fixture_byte_identical(fixture: dict[str, Any]) -> None:
    got = canonical_bytes_for_trace(fixture["input"]).decode("utf-8")
    assert got == fixture["expected_canonical_json"]


def test_fixture_byte_identical_as_bytes(fixture: dict[str, Any]) -> None:
    got = canonical_bytes_for_trace(fixture["input"])
    expected = fixture["expected_canonical_json"].encode("utf-8")
    assert got == expected


# ---------------------------------------------------------------------------
# Determinism + key-order independence.
# ---------------------------------------------------------------------------


def test_same_input_same_output(fixture: dict[str, Any]) -> None:
    a = canonical_bytes_for_trace(fixture["input"])
    b = canonical_bytes_for_trace(fixture["input"])
    assert a == b


def test_input_key_order_irrelevant() -> None:
    a = canonical_bytes_for_trace(
        {
            "error_signature": "x",
            "error_text": "y",
            "task_description": "t",
            "approach_summary": "a",
            "root_cause": "r",
            "outcome": "resolved",
        },
    )
    b = canonical_bytes_for_trace(
        {
            "outcome": "resolved",
            "root_cause": "r",
            "approach_summary": "a",
            "task_description": "t",
            "error_text": "y",
            "error_signature": "x",
        },
    )
    assert a == b


# ---------------------------------------------------------------------------
# Structural rules.
# ---------------------------------------------------------------------------


def test_top_level_keys_sorted_lexically(fixture: dict[str, Any]) -> None:
    out = canonical_bytes_for_trace(fixture["input"]).decode("utf-8")
    expected_keys = [
        "approach_summary",
        "context_snapshot",
        "error_class",
        "error_signature",
        "error_text",
        "outcome",
        "root_cause",
        "tags",
        "task_description",
        "technology",
        "visibility",
    ]
    last_pos = -1
    for k in expected_keys:
        pos = out.find(f'"{k}":')
        assert pos > last_pos, f"key {k!r} appeared out of order"
        last_pos = pos


def test_nested_objects_sorted_recursively() -> None:
    out = canonical_bytes_for_trace(
        {"context_snapshot": {"zeta": 1, "alpha": {"b": 2, "a": 1}}},
    ).decode("utf-8")
    assert '"context_snapshot":{"alpha":{"a":1,"b":2},"zeta":1}' in out


def test_array_order_preserved() -> None:
    out = canonical_bytes_for_trace({"tags": ["zulu", "alpha", "mike"]}).decode("utf-8")
    assert '"tags":["zulu","alpha","mike"]' in out


def test_unicode_preserved_literally() -> None:
    out = canonical_bytes_for_trace({"error_text": "café naïve 日本 🚀"}).decode("utf-8")
    assert '"error_text":"café naïve 日本 🚀"' in out
    # And as bytes the multi-byte chars are real UTF-8, not \\u escapes.
    raw = canonical_bytes_for_trace({"error_text": "café"})
    assert b"caf\xc3\xa9" in raw  # 'é' is c3 a9 in UTF-8


def test_combining_marks_round_trip() -> None:
    # 'é' as 'e' + combining acute U+0301 — distinct bytes, must survive.
    text = "é"
    out = canonical_bytes_for_trace({"error_text": text}).decode("utf-8")
    assert text in out


def test_signature_and_signer_pubkey_stripped_top_level() -> None:
    out = canonical_bytes_for_trace(
        {
            "error_signature": "abc",
            "signature": "SHOULD_NOT_APPEAR",
            "signer_pubkey": "ALSO_GONE",
        },
    ).decode("utf-8")
    # Substring "signature" legitimately appears in error_signature; assert
    # the *keys* are absent and the values never make it through.
    assert '"signature":' not in out
    assert '"signer_pubkey":' not in out
    assert "SHOULD_NOT_APPEAR" not in out
    assert "ALSO_GONE" not in out


def test_nested_signature_keys_are_not_stripped() -> None:
    # The drop-set applies only at the top level. A user-controlled nested
    # object that happens to have a 'signature' key keeps it.
    out = canonical_bytes_for_trace(
        {"context_snapshot": {"signature": "kept", "signer_pubkey": "also kept"}},
    ).decode("utf-8")
    assert '"signature":"kept"' in out
    assert '"signer_pubkey":"also kept"' in out


def test_no_whitespace_in_output(fixture: dict[str, Any]) -> None:
    out = canonical_bytes_for_trace(fixture["input"]).decode("utf-8")
    # A space in "Run the script" or "Added missing import" is fine — those
    # are inside string values. Outside of strings the serializer must emit
    # nothing — assert ": " (space after colon) and ", " never appear.
    assert ": " not in out.replace('": "', "")  # rough but specific enough
    # Easier bullet-proof checks:
    assert '", "' not in out  # "key", "value" pattern from indented dump
    assert ":\n" not in out
    assert ",\n" not in out


# ---------------------------------------------------------------------------
# Edge values.
# ---------------------------------------------------------------------------


def test_empty_dict() -> None:
    assert canonical_bytes_for_trace({}) == b"{}"


def test_empty_list() -> None:
    assert canonical_bytes({"tags": []}) == b'{"tags":[]}'


def test_none_values_serialize_as_null() -> None:
    assert canonical_bytes({"error_class": None}) == b'{"error_class":null}'


def test_bool_values() -> None:
    assert canonical_bytes({"a": True, "b": False}) == b'{"a":true,"b":false}'


def test_int_and_float() -> None:
    # Python ints and floats both become JSON numbers. We don't use floats on
    # the wire, but the canonicalizer is content-agnostic and must not blow up.
    assert canonical_bytes({"a": 1, "b": 1.5}) == b'{"a":1,"b":1.5}'


def test_tuples_normalized_to_lists() -> None:
    # A caller passing a tuple should get the same bytes as if they passed
    # a list — JSON has no tuple, and we want canonical form to be input
    # representation-independent.
    assert canonical_bytes({"tags": ("a", "b")}) == canonical_bytes({"tags": ["a", "b"]})


# ---------------------------------------------------------------------------
# Non-serializable input — must raise, must not silently emit empty bytes.
# ---------------------------------------------------------------------------


def test_throws_on_function() -> None:
    with pytest.raises(TypeError, match="not JSON-serializable"):
        canonical_bytes(lambda: 1)


def test_throws_on_object() -> None:
    class Opaque:
        pass

    with pytest.raises(TypeError, match="not JSON-serializable"):
        canonical_bytes(Opaque())


def test_throws_on_set() -> None:
    with pytest.raises(TypeError, match="not JSON-serializable"):
        canonical_bytes({"tags": {"a", "b"}})


def test_throws_on_circular_reference() -> None:
    a: dict[str, Any] = {}
    a["self"] = a
    # Either RecursionError or our wrapped TypeError — both prove we don't
    # silently emit empty output.
    with pytest.raises((RecursionError, TypeError, ValueError)):
        canonical_bytes(a)


# ---------------------------------------------------------------------------
# Property-based: random trace dicts canonicalize deterministically.
# ---------------------------------------------------------------------------


_simple_value = (
    st.text(min_size=0, max_size=20)
    | st.integers(min_value=-(2**31), max_value=2**31)
    | st.booleans()
    | st.none()
)
_nested = st.recursive(
    _simple_value,
    lambda children: (
        st.lists(children, max_size=4)
        | st.dictionaries(st.text(min_size=1, max_size=10), children, max_size=4)
    ),
    max_leaves=10,
)


@given(payload=st.dictionaries(st.text(min_size=1, max_size=15), _nested, max_size=6))
@settings(max_examples=100, deadline=None)
def test_canonicalization_is_deterministic_property(payload: dict[str, Any]) -> None:
    # Running twice on the same dict must produce identical bytes, no matter
    # what the random shape looks like.
    a = canonical_bytes(payload)
    b = canonical_bytes(payload)
    assert a == b
