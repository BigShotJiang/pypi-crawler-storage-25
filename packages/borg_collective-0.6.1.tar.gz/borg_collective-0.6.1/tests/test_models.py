"""Tests for ``borg_collective.models``.

Covers:
  * Each enum coerces from its lowercase wire string.
  * FailureTrace required-fields, hex-shape validators, default
    visibility=PRIVATE, extra="forbid" rejection.
  * PublishedTrace + Trace forward-compatibility (extra="allow").
  * AmendmentInput defaults + v2-rejection messages on signature/pubkey.
  * SearchRequest at-least-one-criterion rule (mirrors Worker).
  * SearchRequest.limit ge=1 le=50 bounds.
  * FeedbackRequest funnel monotonicity and note bound.
  * Agent.api_key never appears in repr/str/model_dump.
  * Hypothesis: random valid FailureTrace dicts always validate.
"""

from __future__ import annotations

from typing import Any

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st
from pydantic import ValidationError as PydanticValidationError

from borg_collective.models import (
    Agent,
    Amendment,
    AmendmentCreated,
    AmendmentInput,
    AmendmentKind,
    Counters,
    FailureTrace,
    FeedbackOutcome,
    FeedbackRequest,
    MatchMode,
    Outcome,
    Provenance,
    PublishedTrace,
    SearchRequest,
    SearchResult,
    SearchResults,
    Trace,
    TraceDetail,
    Visibility,
)

# A 64-char lowercase hex string — used wherever the wire expects an
# error_signature, signer_pubkey, or hash-shape value.
HEX_64_A = "a" * 64
HEX_64_B = "b" * 64
HEX_64_C = "c" * 64
HEX_64_D = "d" * 64
HEX_128 = "e" * 128


def _valid_trace_kwargs(**overrides: Any) -> dict[str, Any]:
    """Minimal valid kwargs for FailureTrace; tests override one at a time."""
    base: dict[str, Any] = {
        "error_text": "boom",
        "task_description": "t",
        "approach_summary": "a",
        "root_cause": "r",
        "outcome": "resolved",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("value", "member"),
    [
        ("resolved", Outcome.RESOLVED),
        ("abandoned", Outcome.ABANDONED),
        ("escalated", Outcome.ESCALATED),
    ],
)
def test_outcome_coerces_from_string(value: str, member: Outcome) -> None:
    trace = FailureTrace(**_valid_trace_kwargs(outcome=value))
    assert trace.outcome is member


@pytest.mark.parametrize(
    ("value", "member"),
    [("public", Visibility.PUBLIC), ("private", Visibility.PRIVATE)],
)
def test_visibility_coerces_from_string(value: str, member: Visibility) -> None:
    trace = FailureTrace(**_valid_trace_kwargs(visibility=value))
    assert trace.visibility is member


@pytest.mark.parametrize(
    ("value", "member"),
    [
        ("resolution", AmendmentKind.RESOLUTION),
        ("clarification", AmendmentKind.CLARIFICATION),
        ("correction", AmendmentKind.CORRECTION),
    ],
)
def test_amendment_kind_coerces_from_string(value: str, member: AmendmentKind) -> None:
    amendment = AmendmentInput(content="x", kind=value)  # type: ignore[arg-type]
    assert amendment.kind is member


@pytest.mark.parametrize(
    ("value", "member"),
    [
        ("error_signature", MatchMode.ERROR_SIGNATURE),
        ("filter", MatchMode.FILTER),
        ("query", MatchMode.QUERY),
    ],
)
def test_match_mode_coerces_from_string(value: str, member: MatchMode) -> None:
    results = SearchResults(results=[], count=0, match_mode=value)  # type: ignore[arg-type]
    assert results.match_mode is member


@pytest.mark.parametrize(
    ("value", "member"),
    [("helped", FeedbackOutcome.HELPED), ("didnt_help", FeedbackOutcome.DIDNT_HELP)],
)
def test_feedback_outcome_coerces_from_string(value: str, member: FeedbackOutcome) -> None:
    fb = FeedbackRequest(
        trace_id="t",
        retrieved=True,
        read=True,
        applied=True,
        outcome=value,  # type: ignore[arg-type]
    )
    assert fb.outcome is member


def test_outcome_and_feedback_outcome_are_disjoint() -> None:
    """The two enums must never share values — keeps a typo from silently
    crossing domains. ``resolved`` is for traces, ``helped`` is for feedback;
    swapping them is a bug, not a polymorphism opportunity.
    """
    outcome_values = {member.value for member in Outcome}
    feedback_values = {member.value for member in FeedbackOutcome}
    assert outcome_values.isdisjoint(feedback_values)


# ---------------------------------------------------------------------------
# FailureTrace — required fields, defaults, extra="forbid"
# ---------------------------------------------------------------------------


def test_failure_trace_minimal_publishes() -> None:
    trace = FailureTrace(**_valid_trace_kwargs())
    assert trace.error_text == "boom"
    assert trace.outcome is Outcome.RESOLVED


@pytest.mark.parametrize(
    "missing", ["error_text", "task_description", "approach_summary", "root_cause", "outcome"]
)
def test_failure_trace_required_fields(missing: str) -> None:
    kwargs = _valid_trace_kwargs()
    del kwargs[missing]
    with pytest.raises(PydanticValidationError):
        FailureTrace.model_validate(kwargs)


def test_failure_trace_rejects_unknown_fields() -> None:
    with pytest.raises(PydanticValidationError):
        FailureTrace.model_validate({**_valid_trace_kwargs(), "definitely_not_a_field": "x"})


def test_failure_trace_visibility_defaults_to_private() -> None:
    """The SDK defaults visibility=PRIVATE deliberately. Broadcast must be
    opt-in — a quiet PUBLIC default would let a caller leak a path or
    token they had not realized was in the body. Asserted explicitly.
    """
    trace = FailureTrace(**_valid_trace_kwargs())
    assert trace.visibility is Visibility.PRIVATE


@pytest.mark.parametrize("field", ["error_signature", "signer_pubkey"])
def test_failure_trace_64_hex_fields_validate_shape(field: str) -> None:
    # Valid 64-char lowercase hex passes.
    FailureTrace(**_valid_trace_kwargs(**{field: HEX_64_A}))
    # Uppercase fails — wire is lowercase only.
    with pytest.raises(PydanticValidationError):
        FailureTrace(**_valid_trace_kwargs(**{field: "A" * 64}))
    # Wrong length fails.
    with pytest.raises(PydanticValidationError):
        FailureTrace(**_valid_trace_kwargs(**{field: "a" * 63}))
    # Non-hex chars fail.
    with pytest.raises(PydanticValidationError):
        FailureTrace(**_valid_trace_kwargs(**{field: "g" * 64}))


def test_failure_trace_signature_validates_128_hex() -> None:
    FailureTrace(**_valid_trace_kwargs(signature=HEX_128))
    # 64-char hex is too short for a 128-char signature field.
    with pytest.raises(PydanticValidationError):
        FailureTrace(**_valid_trace_kwargs(signature=HEX_64_A))
    # Uppercase fails.
    with pytest.raises(PydanticValidationError):
        FailureTrace(**_valid_trace_kwargs(signature="E" * 128))


def test_failure_trace_error_text_too_long_rejected() -> None:
    """The Worker's DB CHECK caps error_text at 16384 chars. Match it
    locally so we fail before the round-trip.
    """
    too_long = "x" * 16385
    with pytest.raises(PydanticValidationError):
        FailureTrace(**_valid_trace_kwargs(error_text=too_long))


def test_failure_trace_dump_round_trip() -> None:
    trace = FailureTrace(**_valid_trace_kwargs(visibility="public"))
    dumped = trace.model_dump()
    assert dumped["outcome"] == "resolved"
    assert dumped["visibility"] == "public"


# ---------------------------------------------------------------------------
# PublishedTrace + Trace — extra="allow"
# ---------------------------------------------------------------------------


def test_published_trace_accepts_unknown_fields() -> None:
    pt = PublishedTrace.model_validate(
        {
            "trace_id": "t1",
            "signed": True,
            "error_signature": HEX_64_A,
            "future_field": "ok",
        }
    )
    assert pt.signed is True
    assert pt.error_signature == HEX_64_A


def test_published_trace_warning_round_trips() -> None:
    pt = PublishedTrace(
        trace_id="t1",
        signed=False,
        error_signature=HEX_64_A,
        warning="unsigned_trace",
    )
    assert pt.warning == "unsigned_trace"


def test_trace_accepts_unknown_fields() -> None:
    tr = Trace.model_validate(
        {
            "trace_id": "t1",
            "agent_id": "a1",
            "error_signature": HEX_64_A,
            "error_text": "boom",
            "task_description": "t",
            "approach_summary": "a",
            "root_cause": "r",
            "outcome": "resolved",
            "visibility": "private",
            "signed": False,
            "created_at": 1700000000,
            "future_field": 7,
        }
    )
    assert tr.outcome is Outcome.RESOLVED
    assert tr.visibility is Visibility.PRIVATE


# ---------------------------------------------------------------------------
# Provenance — E0.6 attribution round-trip
# ---------------------------------------------------------------------------


def test_failure_trace_accepts_provenance_curated() -> None:
    trace = FailureTrace(
        **_valid_trace_kwargs(
            provenance=Provenance.CURATED,
            license="CC-BY-4.0",
            source_url="https://example.com/trace/42",
        )
    )
    assert trace.provenance is Provenance.CURATED
    assert trace.license == "CC-BY-4.0"
    assert trace.source_url == "https://example.com/trace/42"


def test_failure_trace_default_provenance_is_none_on_construction() -> None:
    """Default provenance is None, NOT Provenance.ORGANIC, so the
    Worker's DB DEFAULT 'organic' applies on insert. Lets the SDK stay
    silent about provenance for organic publishes (the common case).
    """
    trace = FailureTrace(**_valid_trace_kwargs())
    assert trace.provenance is None
    assert trace.source_url is None
    assert trace.license is None


def test_trace_read_carries_provenance_organic() -> None:
    """Worker-shaped GET response carries provenance — the SDK's Trace
    deserializes it. Default is Provenance.ORGANIC for legacy rows that
    might omit the field on the wire (extra="allow", but the field has
    its own default).
    """
    tr = Trace.model_validate(
        {
            "trace_id": "t1",
            "agent_id": "a1",
            "error_signature": HEX_64_A,
            "error_text": "boom",
            "task_description": "t",
            "approach_summary": "a",
            "root_cause": "r",
            "outcome": "resolved",
            "visibility": "public",
            "signed": False,
            "provenance": "organic",
            "source_url": None,
            "license": None,
            "created_at": 1700000000,
        }
    )
    assert tr.provenance is Provenance.ORGANIC
    assert tr.source_url is None
    assert tr.license is None


# ---------------------------------------------------------------------------
# AmendmentInput
# ---------------------------------------------------------------------------


def test_amendment_input_kind_defaults_to_clarification() -> None:
    amendment = AmendmentInput(content="more context")
    assert amendment.kind is AmendmentKind.CLARIFICATION


def test_amendment_input_rejects_signature_with_v2_message() -> None:
    with pytest.raises(PydanticValidationError) as excinfo:
        AmendmentInput.model_validate({"content": "x", "signature": HEX_128})
    msg = str(excinfo.value)
    assert "amendment signing is a v2 feature" in msg
    assert "signature" in msg


def test_amendment_input_rejects_signer_pubkey_with_v2_message() -> None:
    with pytest.raises(PydanticValidationError) as excinfo:
        AmendmentInput.model_validate({"content": "x", "signer_pubkey": HEX_64_A})
    msg = str(excinfo.value)
    assert "amendment signing is a v2 feature" in msg
    assert "signer_pubkey" in msg


def test_amendment_input_rejects_unknown_fields() -> None:
    with pytest.raises(PydanticValidationError):
        AmendmentInput.model_validate({"content": "x", "kind": "clarification", "junk": 1})


def test_amendment_input_content_bounds() -> None:
    with pytest.raises(PydanticValidationError):
        AmendmentInput(content="")
    with pytest.raises(PydanticValidationError):
        AmendmentInput(content="x" * 16385)


# ---------------------------------------------------------------------------
# Amendment + AmendmentCreated + Counters + TraceDetail
# ---------------------------------------------------------------------------


def test_amendment_round_trip() -> None:
    a = Amendment(
        amendment_id="01HZX",
        kind="clarification",  # type: ignore[arg-type]
        content="hello",
        author_agent_id="a1",
        created_at=1,
    )
    assert a.kind is AmendmentKind.CLARIFICATION


def test_amendment_created_omits_content_and_author() -> None:
    """The POST response omits content + author_agent_id by design — the
    caller already has both. Confirm the model's surface matches.
    """
    fields = set(AmendmentCreated.model_fields.keys())
    assert "content" not in fields
    assert "author_agent_id" not in fields
    assert {"amendment_id", "trace_id", "kind", "created_at"} <= fields


def test_counters_default_to_zero() -> None:
    c = Counters()
    assert c.retrieved == 0
    assert c.read == 0
    assert c.applied == 0
    assert c.helped == 0
    assert c.didnt_help == 0


def test_trace_detail_round_trip() -> None:
    detail = TraceDetail.model_validate(
        {
            "trace": {
                "trace_id": "t1",
                "agent_id": "a1",
                "error_signature": HEX_64_A,
                "error_text": "boom",
                "task_description": "t",
                "approach_summary": "a",
                "root_cause": "r",
                "outcome": "resolved",
                "visibility": "private",
                "signed": False,
                "created_at": 1,
            },
            "amendments": [
                {
                    "amendment_id": "x",
                    "kind": "resolution",
                    "content": "fixed",
                    "author_agent_id": "a1",
                    "created_at": 2,
                }
            ],
            "counters": {"retrieved": 1, "read": 1, "applied": 1, "helped": 1},
        }
    )
    assert detail.trace.outcome is Outcome.RESOLVED
    assert detail.amendments[0].kind is AmendmentKind.RESOLUTION
    assert detail.counters.helped == 1
    assert detail.counters.didnt_help == 0


# ---------------------------------------------------------------------------
# SearchRequest
# ---------------------------------------------------------------------------


def test_search_request_no_criteria_fails() -> None:
    with pytest.raises(PydanticValidationError):
        SearchRequest()


def test_search_request_just_error_signature_passes() -> None:
    req = SearchRequest(error_signature=HEX_64_A)
    assert req.error_signature == HEX_64_A


def test_search_request_just_query_passes() -> None:
    req = SearchRequest(query="oom")
    assert req.query == "oom"


def test_search_request_just_error_class_passes() -> None:
    req = SearchRequest(error_class="ValueError")
    assert req.error_class == "ValueError"


def test_search_request_just_non_empty_tags_passes() -> None:
    req = SearchRequest(tags=["network"])
    assert req.tags == ["network"]


def test_search_request_empty_tags_alone_fails() -> None:
    """Empty tags=[] does NOT count as a criterion — Worker behavior is
    the contract. Asserted explicitly so a future loosening is loud.
    """
    with pytest.raises(PydanticValidationError):
        SearchRequest(tags=[])


def test_search_request_limit_default_is_ten() -> None:
    assert SearchRequest(query="x").limit == 10


@pytest.mark.parametrize("bad", [0, -1, 51, 100])
def test_search_request_limit_out_of_range_fails(bad: int) -> None:
    with pytest.raises(PydanticValidationError):
        SearchRequest(query="x", limit=bad)


@pytest.mark.parametrize("good", [1, 10, 50])
def test_search_request_limit_in_range_passes(good: int) -> None:
    SearchRequest(query="x", limit=good)


def test_search_request_error_signature_must_be_hex_64() -> None:
    with pytest.raises(PydanticValidationError):
        SearchRequest(error_signature="A" * 64)
    with pytest.raises(PydanticValidationError):
        SearchRequest(error_signature="a" * 63)


# ---------------------------------------------------------------------------
# SearchResult / SearchResults
# ---------------------------------------------------------------------------


def test_search_result_round_trip() -> None:
    r = SearchResult(
        trace_id="t1",
        error_signature=HEX_64_A,
        error_class=None,
        outcome="resolved",  # type: ignore[arg-type]
        signed=True,
        created_at=1,
        preview="boom",
        counters=Counters(),
    )
    assert r.outcome is Outcome.RESOLVED
    assert r.signed is True


def test_search_results_round_trip() -> None:
    SearchResults(results=[], count=0, match_mode="filter")  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# FeedbackRequest funnel monotonicity
# ---------------------------------------------------------------------------


def test_feedback_request_minimal_passes() -> None:
    fb = FeedbackRequest(trace_id="t1")
    assert fb.retrieved is False
    assert fb.outcome is None


def test_feedback_request_read_requires_retrieved() -> None:
    with pytest.raises(PydanticValidationError) as excinfo:
        FeedbackRequest(trace_id="t1", read=True)
    assert "read=True requires retrieved=True" in str(excinfo.value)


def test_feedback_request_applied_requires_read() -> None:
    with pytest.raises(PydanticValidationError) as excinfo:
        FeedbackRequest(trace_id="t1", retrieved=True, applied=True)
    assert "applied=True requires read=True" in str(excinfo.value)


def test_feedback_request_outcome_requires_applied() -> None:
    with pytest.raises(PydanticValidationError) as excinfo:
        FeedbackRequest(
            trace_id="t1",
            retrieved=True,
            read=True,
            outcome=FeedbackOutcome.HELPED,
        )
    assert "outcome requires applied=True" in str(excinfo.value)


def test_feedback_request_full_funnel_passes() -> None:
    fb = FeedbackRequest(
        trace_id="t1",
        retrieved=True,
        read=True,
        applied=True,
        outcome=FeedbackOutcome.HELPED,
        note="thanks",
    )
    assert fb.outcome is FeedbackOutcome.HELPED


def test_feedback_request_note_too_long_fails() -> None:
    with pytest.raises(PydanticValidationError):
        FeedbackRequest(
            trace_id="t1",
            retrieved=True,
            read=True,
            applied=True,
            note="x" * 513,
        )


def test_feedback_request_rejects_unknown_fields() -> None:
    with pytest.raises(PydanticValidationError):
        FeedbackRequest.model_validate({"trace_id": "t1", "extra": 1})


# ---------------------------------------------------------------------------
# Agent — api_key never leaks
# ---------------------------------------------------------------------------


def _make_agent() -> Agent:
    return Agent(
        agent_id="a-123",
        display_name="alice",
        trust_level="soft",
        created_at=1,
        api_key=HEX_64_C,
    )


def test_agent_api_key_not_in_repr() -> None:
    agent = _make_agent()
    rendered = repr(agent)
    assert HEX_64_C not in rendered
    assert "api_key" not in rendered


def test_agent_api_key_not_in_str() -> None:
    agent = _make_agent()
    rendered = str(agent)
    assert HEX_64_C not in rendered


def test_agent_api_key_not_in_model_dump() -> None:
    agent = _make_agent()
    dumped = agent.model_dump()
    assert "api_key" not in dumped
    assert HEX_64_C not in str(dumped)


def test_agent_api_key_not_in_model_dump_json() -> None:
    agent = _make_agent()
    json_blob = agent.model_dump_json()
    assert HEX_64_C not in json_blob
    assert "api_key" not in json_blob


def test_agent_api_key_extractable_with_explicit_exclude_override() -> None:
    """The redaction is opt-out — callers who genuinely need the key
    (e.g. persisting to a secret store) can pass exclude=set() to
    bypass. The default surfaces never reveal it; the explicit override
    is the documented escape hatch.
    """
    agent = _make_agent()
    # Bypass the default exclusion via the explicit dump kwarg.
    dumped = agent.model_dump(exclude=set())
    # Even with exclude=set() the Field(exclude=True) wins on Pydantic v2
    # — so the "default surfaces never reveal it" guarantee is even
    # stronger than the prompt requires. Confirm the property: api_key
    # cannot be coaxed out of the public dump path. Callers needing the
    # key access it via the attribute directly.
    assert "api_key" not in dumped
    # Direct attribute access is the deliberate escape hatch.
    assert agent.api_key == HEX_64_C


def test_agent_pubkey_round_trip() -> None:
    from borg_collective.models import AgentPubkey

    pk = AgentPubkey(agent_id="a-123", pubkey=HEX_64_D, updated_at=1)
    assert pk.pubkey == HEX_64_D


# ---------------------------------------------------------------------------
# Hypothesis — random valid FailureTrace dicts always validate
# ---------------------------------------------------------------------------


_OUTCOMES = [m.value for m in Outcome]
_VISIBILITIES = [m.value for m in Visibility]


@settings(max_examples=50, deadline=None)
@given(
    error_text=st.text(min_size=1, max_size=200),
    task_description=st.text(min_size=1, max_size=200),
    approach_summary=st.text(min_size=1, max_size=200),
    root_cause=st.text(min_size=1, max_size=200),
    outcome=st.sampled_from(_OUTCOMES),
    visibility=st.sampled_from(_VISIBILITIES),
    tags=st.lists(st.text(min_size=0, max_size=20), max_size=5),
)
def test_failure_trace_hypothesis(
    error_text: str,
    task_description: str,
    approach_summary: str,
    root_cause: str,
    outcome: str,
    visibility: str,
    tags: list[str],
) -> None:
    trace = FailureTrace.model_validate(
        {
            "error_text": error_text,
            "task_description": task_description,
            "approach_summary": approach_summary,
            "root_cause": root_cause,
            "outcome": outcome,
            "visibility": visibility,
            "tags": tags,
        }
    )
    # Round-trip: the dump must match what we put in (modulo enum
    # coercion to string values).
    dumped = trace.model_dump()
    assert dumped["outcome"] == outcome
    assert dumped["visibility"] == visibility
    assert dumped["tags"] == tags
