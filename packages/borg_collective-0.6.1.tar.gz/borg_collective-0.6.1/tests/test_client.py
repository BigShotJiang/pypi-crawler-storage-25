"""Tests for :class:`borg_collective.Client`.

Coverage matrix:

* Constructor: api_key set/unset, base_url override, transport
  injection, ownership semantics, repr never leaks api_key, context
  manager closes deterministically.
* register_agent: minimal call (no kwargs), with display_name, with
  pubkey, with both, returns typed Agent, api_key returned once,
  uses ``auth_required=False``.
* whoami: 200 → AgentInfo with all 5 fields, pubkey null path, pubkey
  set path, ConfigError when no api_key, 401 + 403 → AuthError,
  trust_level coerces to TrustLevel.
* publish (unsigned): FailureTrace input, dict input, response with
  warning, response without warning (signed echo), 422 bad_signature
  → SignatureError, ConfigError without api_key.
* publish (signed): signature/signer_pubkey/error_signature stamped,
  pre-set error_signature is not overwritten, signed request body is
  byte-stable.
* get: 200 → TraceDetail, 404 → ValidationError(status=404).
* add_amendment: default kind, explicit kind enum, explicit kind
  string, signature/signer_pubkey rejected locally with v2 message,
  404 trace_not_found.
* search: at-least-one-criterion enforced locally, each individual
  criterion accepted, response → SearchResults.
* feedback: minimal claim, full funnel, funnel monotonicity rejected
  locally, response → FeedbackAck (counters_updated true and false).
* rotate_pubkey: hex-shape validated locally, response → AgentPubkey.

Tests use respx so nothing hits the network. Live-Worker assertions
live in ``scripts/smoke_4b.py`` (deleted before commit).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import httpx
import pytest
import respx

if TYPE_CHECKING:
    from collections.abc import Generator

from borg_collective import (
    Agent,
    AgentInfo,
    AgentPubkey,
    AmendmentCreated,
    AmendmentKind,
    AuthError,
    Client,
    ConfigError,
    FailureTrace,
    FeedbackAck,
    FeedbackOutcome,
    Outcome,
    Provenance,
    PublishedTrace,
    SearchResults,
    SignatureError,
    TraceDetail,
    TrustLevel,
    ValidationError,
    Visibility,
)
from borg_collective._signing import SigningKeyPair
from borg_collective._transport import AUTH_HEADER, Transport

BASE_URL = "https://test.invalid"
TEST_API_KEY = "a" * 64

HEX_64_A = "a" * 64
HEX_64_B = "b" * 64
HEX_64_C = "c" * 64

UUID_AGENT = "00000000-0000-4000-8000-000000000001"


# ---------------------------------------------------------------------------
# Fixtures.
# ---------------------------------------------------------------------------


@pytest.fixture()
def client() -> Generator[Client, None, None]:
    c = Client(api_key=TEST_API_KEY, base_url=BASE_URL, backoff_base_s=0.0)
    yield c
    c.close()


@pytest.fixture()
def unauth_client() -> Generator[Client, None, None]:
    c = Client(api_key=None, base_url=BASE_URL, backoff_base_s=0.0)
    yield c
    c.close()


def _err_envelope(error_code: str, **extras: Any) -> dict[str, Any]:
    return {"error": error_code, "request_id": "req_test", **extras}


def _trace_kwargs(**overrides: Any) -> dict[str, Any]:
    base = {
        "error_text": "ImportError: no module named foo",
        "task_description": "import the foo module",
        "approach_summary": "naive import",
        "root_cause": "module not installed",
        "outcome": Outcome.RESOLVED,
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# Constructor + lifecycle.
# ---------------------------------------------------------------------------


class TestConstructor:
    def test_api_key_passed_through_to_transport(self) -> None:
        c = Client(api_key=TEST_API_KEY, base_url=BASE_URL)
        try:
            assert c._transport._api_key == TEST_API_KEY
        finally:
            c.close()

    def test_no_api_key_allowed(self) -> None:
        c = Client(api_key=None, base_url=BASE_URL)
        try:
            assert c._transport._api_key is None
        finally:
            c.close()

    def test_base_url_passed_through(self) -> None:
        c = Client(api_key=TEST_API_KEY, base_url="https://example.invalid")
        try:
            assert c._transport._base_url == "https://example.invalid"
        finally:
            c.close()

    def test_repr_does_not_leak_api_key(self) -> None:
        c = Client(api_key="super-secret-xyz", base_url=BASE_URL)
        try:
            r = repr(c)
            assert "super-secret-xyz" not in r
            assert "set" in r
        finally:
            c.close()

    def test_context_manager_closes_owned_transport(self) -> None:
        with Client(api_key=TEST_API_KEY, base_url=BASE_URL) as c:
            tr = c._transport
        # After the with block, the underlying client is closed.
        # httpx.Client raises if used after close — observable proxy.
        assert tr._owns_client

    def test_close_idempotent(self) -> None:
        c = Client(api_key=TEST_API_KEY, base_url=BASE_URL)
        c.close()
        # Second close must not raise.
        c.close()

    def test_injected_transport_not_closed(self) -> None:
        injected = Transport(api_key=TEST_API_KEY, base_url=BASE_URL, backoff_base_s=0.0)
        try:
            c = Client(transport=injected)
            assert c._owns_transport is False
            c.close()  # should NOT close the injected transport
        finally:
            injected.close()


# ---------------------------------------------------------------------------
# register_agent
# ---------------------------------------------------------------------------


class TestRegisterAgent:
    @respx.mock
    def test_register_with_no_args(self, unauth_client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/agents").mock(
            return_value=httpx.Response(
                201,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "agent-00000000",
                    "api_key": HEX_64_A,
                    "trust_level": "soft",
                    "created_at": 1700000000,
                },
            )
        )
        agent = unauth_client.register_agent()
        assert isinstance(agent, Agent)
        assert agent.agent_id == UUID_AGENT
        assert agent.api_key == HEX_64_A
        assert agent.trust_level == "soft"
        # Body sent: empty JSON object (no display_name, no pubkey).
        sent_body = route.calls.last.request.content
        assert sent_body == b"{}"

    @respx.mock
    def test_register_with_display_name(self, unauth_client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/agents").mock(
            return_value=httpx.Response(
                201,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "alice",
                    "api_key": HEX_64_A,
                    "trust_level": "soft",
                    "created_at": 1,
                },
            )
        )
        agent = unauth_client.register_agent(display_name="alice")
        assert agent.display_name == "alice"
        assert b'"display_name": "alice"' in route.calls.last.request.content

    @respx.mock
    def test_register_with_pubkey(self, unauth_client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/agents").mock(
            return_value=httpx.Response(
                201,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "x",
                    "api_key": HEX_64_A,
                    "trust_level": "soft",
                    "created_at": 1,
                },
            )
        )
        unauth_client.register_agent(pubkey=HEX_64_B)
        assert f'"pubkey": "{HEX_64_B}"'.encode() in route.calls.last.request.content

    @respx.mock
    def test_register_with_display_name_and_pubkey(self, unauth_client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/agents").mock(
            return_value=httpx.Response(
                201,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "alice",
                    "api_key": HEX_64_A,
                    "trust_level": "soft",
                    "created_at": 1,
                },
            )
        )
        agent = unauth_client.register_agent(display_name="alice", pubkey=HEX_64_B)
        assert agent.display_name == "alice"
        assert agent.api_key == HEX_64_A

    @respx.mock
    def test_register_does_not_require_api_key(self, unauth_client: Client) -> None:
        # Must NOT raise ConfigError — register is auth-exempt.
        respx.post(f"{BASE_URL}/api/v1/agents").mock(
            return_value=httpx.Response(
                201,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "x",
                    "api_key": HEX_64_A,
                    "trust_level": "soft",
                    "created_at": 1,
                },
            )
        )
        unauth_client.register_agent()  # no exception

    @respx.mock
    def test_register_400_invalid_pubkey_raises_validation(self, unauth_client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/agents").mock(
            return_value=httpx.Response(
                400,
                json=_err_envelope("invalid_pubkey", expected="lowercase-hex-64"),
            )
        )
        with pytest.raises(ValidationError) as excinfo:
            unauth_client.register_agent(pubkey="not-hex")
        assert excinfo.value.error_code == "invalid_pubkey"


# ---------------------------------------------------------------------------
# whoami
# ---------------------------------------------------------------------------


class TestWhoami:
    @respx.mock
    def test_whoami_200_returns_agent_info(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/api/v1/agents/me").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "alice",
                    "trust_level": "soft",
                    "pubkey": None,
                    "created_at": 1700000000,
                },
            )
        )
        me = client.whoami()
        assert isinstance(me, AgentInfo)
        assert me.agent_id == UUID_AGENT
        assert me.display_name == "alice"
        assert me.trust_level is TrustLevel.SOFT
        assert me.pubkey is None
        assert me.created_at == 1700000000

    @respx.mock
    def test_whoami_pubkey_set_path(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/api/v1/agents/me").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "alice",
                    "trust_level": "soft",
                    "pubkey": HEX_64_C,
                    "created_at": 1,
                },
            )
        )
        me = client.whoami()
        assert me.pubkey == HEX_64_C

    @respx.mock
    def test_whoami_uses_auth_header(self, client: Client) -> None:
        route = respx.get(f"{BASE_URL}/api/v1/agents/me").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "x",
                    "trust_level": "soft",
                    "pubkey": None,
                    "created_at": 1,
                },
            )
        )
        client.whoami()
        assert route.calls.last.request.headers[AUTH_HEADER] == TEST_API_KEY

    def test_whoami_config_error_without_api_key(self, unauth_client: Client) -> None:
        with pytest.raises(ConfigError):
            unauth_client.whoami()

    @respx.mock
    def test_whoami_401_raises_auth_error(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/api/v1/agents/me").mock(
            return_value=httpx.Response(401, json=_err_envelope("auth_required"))
        )
        with pytest.raises(AuthError) as excinfo:
            client.whoami()
        assert excinfo.value.status == 401

    @respx.mock
    def test_whoami_403_raises_auth_error(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/api/v1/agents/me").mock(
            return_value=httpx.Response(403, json=_err_envelope("invalid_key"))
        )
        with pytest.raises(AuthError) as excinfo:
            client.whoami()
        assert excinfo.value.status == 403

    @respx.mock
    def test_whoami_extra_fields_tolerated(self, client: Client) -> None:
        # extra="allow" on AgentInfo — future Worker fields land cleanly.
        respx.get(f"{BASE_URL}/api/v1/agents/me").mock(
            return_value=httpx.Response(
                200,
                json={
                    "agent_id": UUID_AGENT,
                    "display_name": "x",
                    "trust_level": "soft",
                    "pubkey": None,
                    "created_at": 1,
                    "future_field": 99,
                },
            )
        )
        me = client.whoami()
        assert me.agent_id == UUID_AGENT


# ---------------------------------------------------------------------------
# publish — unsigned + signed
# ---------------------------------------------------------------------------


class TestPublishUnsigned:
    @respx.mock
    def test_publish_failure_trace_object(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={
                    "trace_id": "tid_xyz",
                    "signed": False,
                    "error_signature": HEX_64_A,
                    "warning": "unsigned_trace",
                },
            )
        )
        ft = FailureTrace(**_trace_kwargs(visibility=Visibility.PRIVATE))
        published = client.publish(ft)
        assert isinstance(published, PublishedTrace)
        assert published.trace_id == "tid_xyz"
        assert published.signed is False
        assert published.warning == "unsigned_trace"

    @respx.mock
    def test_publish_dict_input(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={
                    "trace_id": "tid_xyz",
                    "signed": False,
                    "error_signature": HEX_64_A,
                    "warning": "unsigned_trace",
                },
            )
        )
        published = client.publish(_trace_kwargs(outcome="resolved"))
        assert published.trace_id == "tid_xyz"

    @respx.mock
    def test_publish_sends_enum_as_string(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={
                    "trace_id": "t",
                    "signed": False,
                    "error_signature": HEX_64_A,
                    "warning": "unsigned_trace",
                },
            )
        )
        ft = FailureTrace(**_trace_kwargs(outcome=Outcome.ABANDONED))
        client.publish(ft)
        body = route.calls.last.request.content
        assert b'"outcome": "abandoned"' in body
        # private is the default, must be on the wire as string.
        assert b'"visibility": "private"' in body

    @respx.mock
    def test_publish_wire_body_carries_provenance_when_set(self, client: Client) -> None:
        """When the caller sets provenance=CURATED on the FailureTrace,
        the wire body carries it as a string. Confirms the seed-corpus
        ingest path no longer needs the raw-httpx bypass.
        """
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={
                    "trace_id": "t",
                    "signed": False,
                    "error_signature": HEX_64_A,
                    "warning": "unsigned_trace",
                },
            )
        )
        ft = FailureTrace(
            **_trace_kwargs(
                provenance=Provenance.CURATED,
                license="CC-BY-4.0",
                source_url="https://example.com/trace/42",
                visibility=Visibility.PUBLIC,
            )
        )
        client.publish(ft, force_public=True)
        body = route.calls.last.request.content
        assert b'"provenance": "curated"' in body
        assert b'"license": "CC-BY-4.0"' in body
        assert b'"source_url": "https://example.com/trace/42"' in body

    @respx.mock
    def test_publish_wire_body_omits_provenance_when_none(self, client: Client) -> None:
        """Default provenance is None on FailureTrace — exclude_none drops
        it from the wire body so the Worker's DB DEFAULT 'organic' applies.
        """
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={
                    "trace_id": "t",
                    "signed": False,
                    "error_signature": HEX_64_A,
                    "warning": "unsigned_trace",
                },
            )
        )
        client.publish(FailureTrace(**_trace_kwargs()))
        body = route.calls.last.request.content
        assert b'"provenance"' not in body
        assert b'"license"' not in body
        assert b'"source_url"' not in body

    @respx.mock
    def test_publish_omits_none_optional_fields(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={
                    "trace_id": "t",
                    "signed": False,
                    "error_signature": HEX_64_A,
                    "warning": "unsigned_trace",
                },
            )
        )
        client.publish(FailureTrace(**_trace_kwargs()))
        body = route.calls.last.request.content
        # Optional fields not set should not appear at all.
        assert b'"signature"' not in body
        assert b'"signer_pubkey"' not in body
        assert b'"error_signature"' not in body  # SDK doesn't compute on unsigned
        assert b'"technology"' not in body

    @respx.mock
    def test_publish_422_bad_signature_raises_signature_error(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(422, json=_err_envelope("bad_signature"))
        )
        with pytest.raises(SignatureError):
            client.publish(FailureTrace(**_trace_kwargs()))

    def test_publish_config_error_without_api_key(self, unauth_client: Client) -> None:
        with pytest.raises(ConfigError):
            unauth_client.publish(FailureTrace(**_trace_kwargs()))

    @respx.mock
    def test_publish_400_missing_field_raises_validation(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                400, json=_err_envelope("missing_field", field="error_text")
            )
        )
        with pytest.raises(ValidationError) as excinfo:
            client.publish(FailureTrace(**_trace_kwargs()))
        assert excinfo.value.error_code == "missing_field"


class TestPublishForcePublic:
    """E0.5 safety-floor: PRIVATE-by-default + opt-in force_public."""

    @respx.mock
    def test_publish_does_not_promote_private_to_public(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={
                    "trace_id": "t",
                    "signed": False,
                    "error_signature": HEX_64_A,
                    "warning": "unsigned_trace",
                },
            )
        )
        ft = FailureTrace(**_trace_kwargs())  # default visibility = PRIVATE
        client.publish(ft)
        body = route.calls.last.request.content
        assert b'"visibility": "private"' in body
        assert b'"visibility": "public"' not in body

    def test_publish_public_trace_without_force_public_raises(self, client: Client) -> None:
        ft = FailureTrace(**_trace_kwargs(visibility=Visibility.PUBLIC))
        with pytest.raises(ValueError, match="force_public=True"):
            client.publish(ft)

    @respx.mock
    def test_publish_force_public_overrides_private_construction(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={
                    "trace_id": "t",
                    "signed": False,
                    "error_signature": HEX_64_A,
                    "warning": "unsigned_trace",
                },
            )
        )
        ft = FailureTrace(**_trace_kwargs())  # default visibility = PRIVATE
        client.publish(ft, force_public=True)
        body = route.calls.last.request.content
        assert b'"visibility": "public"' in body

    @respx.mock
    def test_publish_force_public_with_public_construction_succeeds(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={
                    "trace_id": "t",
                    "signed": False,
                    "error_signature": HEX_64_A,
                    "warning": "unsigned_trace",
                },
            )
        )
        ft = FailureTrace(**_trace_kwargs(visibility=Visibility.PUBLIC))
        client.publish(ft, force_public=True)
        body = route.calls.last.request.content
        assert b'"visibility": "public"' in body


class TestPublishSigned:
    @respx.mock
    def test_publish_with_signing_key_stamps_all_three_fields(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={"trace_id": "t", "signed": True, "error_signature": HEX_64_A},
            )
        )
        kp = SigningKeyPair.generate()
        ft = FailureTrace(**_trace_kwargs())
        client.publish(ft, signing_key=kp)
        body = route.calls.last.request.content
        assert f'"signer_pubkey": "{kp.verify_key_hex}"'.encode() in body
        assert b'"signature": "' in body
        assert b'"error_signature": "' in body

    @respx.mock
    def test_publish_signed_does_not_overwrite_explicit_error_signature(
        self, client: Client
    ) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={"trace_id": "t", "signed": True, "error_signature": HEX_64_C},
            )
        )
        kp = SigningKeyPair.generate()
        ft = FailureTrace(**_trace_kwargs(error_signature=HEX_64_C))
        client.publish(ft, signing_key=kp)
        body = route.calls.last.request.content
        # The pre-set error_signature must round-trip verbatim.
        assert f'"error_signature": "{HEX_64_C}"'.encode() in body

    @respx.mock
    def test_publish_signed_signature_verifies_against_canonical_bytes(
        self, client: Client
    ) -> None:
        # Capture the body sent, then re-verify the signature locally
        # against the same canonical bytes the client signed. If this
        # passes, the SDK and the verifier agree byte-for-byte, which
        # is the property bad_signature would surface a violation of.
        import json

        from borg_collective._canonical import canonical_bytes_for_trace
        from borg_collective._signing import verify

        route = respx.post(f"{BASE_URL}/api/v1/traces").mock(
            return_value=httpx.Response(
                201,
                json={"trace_id": "t", "signed": True, "error_signature": HEX_64_A},
            )
        )
        kp = SigningKeyPair.generate()
        ft = FailureTrace(**_trace_kwargs(tags=["a", "b"]))
        client.publish(ft, signing_key=kp)
        body = json.loads(route.calls.last.request.content)
        sig = body.pop("signature")
        signer_pk = body.pop("signer_pubkey")
        canonical = canonical_bytes_for_trace(body)
        assert verify(signer_pk, canonical, sig) is True


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


def _trace_response(**overrides: Any) -> dict[str, Any]:
    base = {
        "trace": {
            "trace_id": "t1",
            "agent_id": "a1",
            "error_signature": HEX_64_A,
            "error_class": None,
            "error_text": "boom",
            "task_description": "t",
            "approach_summary": "a",
            "root_cause": "r",
            "outcome": "resolved",
            "technology": None,
            "tags": [],
            "context_snapshot": {},
            "visibility": "private",
            "signed": False,
            "signature": None,
            "signer_pubkey": None,
            "created_at": 1,
        },
        "amendments": [],
        "counters": {
            "retrieved": 1,
            "read": 0,
            "applied": 0,
            "helped": 0,
            "didnt_help": 0,
        },
    }
    base.update(overrides)
    return base


class TestGet:
    @respx.mock
    def test_get_200_returns_trace_detail(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/api/v1/traces/t1").mock(
            return_value=httpx.Response(200, json=_trace_response())
        )
        detail = client.get("t1")
        assert isinstance(detail, TraceDetail)
        assert detail.trace.trace_id == "t1"
        assert detail.trace.outcome is Outcome.RESOLVED
        assert detail.counters.retrieved == 1

    @respx.mock
    def test_get_404_raises_validation_error_with_status_404(self, client: Client) -> None:
        respx.get(f"{BASE_URL}/api/v1/traces/missing").mock(
            return_value=httpx.Response(
                404,
                json=_err_envelope("not_found", trace_id="missing"),
            )
        )
        with pytest.raises(ValidationError) as excinfo:
            client.get("missing")
        assert excinfo.value.status == 404
        assert excinfo.value.error_code == "not_found"

    def test_get_config_error_without_api_key(self, unauth_client: Client) -> None:
        with pytest.raises(ConfigError):
            unauth_client.get("t1")


# ---------------------------------------------------------------------------
# add_amendment
# ---------------------------------------------------------------------------


class TestAddAmendment:
    @respx.mock
    def test_default_kind_is_clarification(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces/t1/amendments").mock(
            return_value=httpx.Response(
                201,
                json={
                    "amendment_id": "01HZX",
                    "trace_id": "t1",
                    "kind": "clarification",
                    "created_at": 1,
                },
            )
        )
        amended = client.add_amendment("t1", content="more context")
        assert isinstance(amended, AmendmentCreated)
        assert amended.kind is AmendmentKind.CLARIFICATION
        assert b'"kind": "clarification"' in route.calls.last.request.content

    @respx.mock
    def test_explicit_kind_enum(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/traces/t1/amendments").mock(
            return_value=httpx.Response(
                201,
                json={
                    "amendment_id": "x",
                    "trace_id": "t1",
                    "kind": "resolution",
                    "created_at": 1,
                },
            )
        )
        amended = client.add_amendment("t1", content="fixed it", kind=AmendmentKind.RESOLUTION)
        assert amended.kind is AmendmentKind.RESOLUTION
        assert b'"kind": "resolution"' in route.calls.last.request.content

    @respx.mock
    def test_explicit_kind_string(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces/t1/amendments").mock(
            return_value=httpx.Response(
                201,
                json={
                    "amendment_id": "x",
                    "trace_id": "t1",
                    "kind": "correction",
                    "created_at": 1,
                },
            )
        )
        amended = client.add_amendment("t1", content="actually...", kind="correction")
        assert amended.kind is AmendmentKind.CORRECTION

    @respx.mock
    def test_404_trace_not_found(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/traces/missing/amendments").mock(
            return_value=httpx.Response(
                404,
                json=_err_envelope("trace_not_found", trace_id="missing"),
            )
        )
        with pytest.raises(ValidationError) as excinfo:
            client.add_amendment("missing", content="x")
        assert excinfo.value.status == 404
        assert excinfo.value.error_code == "trace_not_found"

    def test_empty_content_rejected_locally(self, client: Client) -> None:
        # AmendmentInput rejects empty content via Pydantic min_length.
        from pydantic import ValidationError as PydanticValidationError

        with pytest.raises(PydanticValidationError):
            client.add_amendment("t1", content="")


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------


def _search_response() -> dict[str, Any]:
    return {
        "results": [
            {
                "trace_id": "t1",
                "error_signature": HEX_64_A,
                "error_class": None,
                "outcome": "resolved",
                "signed": False,
                "created_at": 1,
                "preview": "boom",
                "counters": {
                    "retrieved": 1,
                    "read": 0,
                    "applied": 0,
                    "helped": 0,
                    "didnt_help": 0,
                },
            }
        ],
        "count": 1,
        "match_mode": "filter",
    }


class TestSearch:
    @respx.mock
    def test_search_by_error_signature(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/search").mock(
            return_value=httpx.Response(200, json=_search_response())
        )
        results = client.search(error_signature=HEX_64_A)
        assert isinstance(results, SearchResults)
        assert results.count == 1
        assert f'"error_signature": "{HEX_64_A}"'.encode() in route.calls.last.request.content

    @respx.mock
    def test_search_by_query(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/search").mock(
            return_value=httpx.Response(200, json=_search_response())
        )
        results = client.search(query="ImportError")
        assert results.count == 1

    @respx.mock
    def test_search_by_tags(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/search").mock(
            return_value=httpx.Response(200, json=_search_response())
        )
        results = client.search(tags=["python"])
        assert results.count == 1

    @respx.mock
    def test_search_by_error_class(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/search").mock(
            return_value=httpx.Response(200, json=_search_response())
        )
        results = client.search(error_class="ImportError")
        assert results.count == 1

    def test_search_no_criteria_rejected_locally(self, client: Client) -> None:
        from pydantic import ValidationError as PydanticValidationError

        with pytest.raises(PydanticValidationError):
            client.search()

    def test_search_empty_tags_alone_rejected_locally(self, client: Client) -> None:
        from pydantic import ValidationError as PydanticValidationError

        with pytest.raises(PydanticValidationError):
            client.search(tags=[])

    @respx.mock
    def test_search_limit_passed_through(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/search").mock(
            return_value=httpx.Response(200, json=_search_response())
        )
        client.search(query="x", limit=25)
        assert b'"limit": 25' in route.calls.last.request.content

    def test_search_limit_out_of_range_rejected_locally(self, client: Client) -> None:
        from pydantic import ValidationError as PydanticValidationError

        with pytest.raises(PydanticValidationError):
            client.search(query="x", limit=51)


# ---------------------------------------------------------------------------
# feedback
# ---------------------------------------------------------------------------


class TestFeedback:
    @respx.mock
    def test_minimal_claim(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/feedback").mock(
            return_value=httpx.Response(
                200,
                json={"recorded": True, "trace_id": "t1", "counters_updated": True},
            )
        )
        ack = client.feedback("t1")
        assert isinstance(ack, FeedbackAck)
        assert ack.recorded is True
        assert ack.counters_updated is True
        assert ack.note is None

    @respx.mock
    def test_full_funnel(self, client: Client) -> None:
        route = respx.post(f"{BASE_URL}/api/v1/feedback").mock(
            return_value=httpx.Response(
                200,
                json={"recorded": True, "trace_id": "t1", "counters_updated": True},
            )
        )
        ack = client.feedback(
            "t1",
            retrieved=True,
            read=True,
            applied=True,
            outcome=FeedbackOutcome.HELPED,
            note="thanks",
        )
        assert ack.recorded is True
        body = route.calls.last.request.content
        assert b'"retrieved": true' in body
        assert b'"read": true' in body
        assert b'"applied": true' in body
        assert b'"outcome": "helped"' in body

    @respx.mock
    def test_feedback_outcome_string_accepted(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/feedback").mock(
            return_value=httpx.Response(
                200,
                json={"recorded": True, "trace_id": "t1", "counters_updated": True},
            )
        )
        ack = client.feedback("t1", retrieved=True, read=True, applied=True, outcome="didnt_help")
        assert ack.recorded is True

    def test_feedback_funnel_violation_rejected_locally(self, client: Client) -> None:
        from pydantic import ValidationError as PydanticValidationError

        with pytest.raises(PydanticValidationError):
            client.feedback("t1", read=True)  # read without retrieved
        with pytest.raises(PydanticValidationError):
            client.feedback("t1", retrieved=True, applied=True)  # applied without read

    def test_feedback_outcome_without_applied_rejected(self, client: Client) -> None:
        from pydantic import ValidationError as PydanticValidationError

        with pytest.raises(PydanticValidationError):
            client.feedback(
                "t1",
                retrieved=True,
                read=True,
                outcome=FeedbackOutcome.HELPED,
            )

    @respx.mock
    def test_feedback_counters_not_updated_path(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/feedback").mock(
            return_value=httpx.Response(
                200,
                json={
                    "recorded": True,
                    "trace_id": "missing",
                    "counters_updated": False,
                    "note": "trace_not_found_but_judgment_recorded",
                },
            )
        )
        ack = client.feedback("missing", retrieved=True)
        assert ack.counters_updated is False
        assert ack.note == "trace_not_found_but_judgment_recorded"


# ---------------------------------------------------------------------------
# rotate_pubkey
# ---------------------------------------------------------------------------


class TestRotatePubkey:
    @respx.mock
    def test_rotate_returns_agent_pubkey(self, client: Client) -> None:
        respx.post(f"{BASE_URL}/api/v1/agents/me/pubkey").mock(
            return_value=httpx.Response(
                200,
                json={"agent_id": UUID_AGENT, "pubkey": HEX_64_B, "updated_at": 1},
            )
        )
        ack = client.rotate_pubkey(HEX_64_B)
        assert isinstance(ack, AgentPubkey)
        assert ack.pubkey == HEX_64_B

    def test_rotate_config_error_without_api_key(self, unauth_client: Client) -> None:
        with pytest.raises(ConfigError):
            unauth_client.rotate_pubkey(HEX_64_B)

    @respx.mock
    def test_rotate_400_invalid_pubkey(self, client: Client) -> None:
        # Worker rejects malformed hex — 400 invalid_pubkey. The SDK
        # passes the value through; the model that validates locally
        # is AgentPubkey, which is the *response* model. The request
        # path takes a raw string, so Worker wins on shape here.
        respx.post(f"{BASE_URL}/api/v1/agents/me/pubkey").mock(
            return_value=httpx.Response(400, json=_err_envelope("invalid_pubkey"))
        )
        with pytest.raises(ValidationError):
            client.rotate_pubkey("not-hex")
