"""Tests for the ``borg`` CLI.

Coverage matrix:

* ``borg version`` prints __version__, exit 0.
* ``borg --version`` is wired to the same value (Click flag).
* Each command happy path: ``register``, ``whoami``, ``publish``,
  ``get``, ``search``, ``feedback``, ``amend``, ``drain``, ``init``.
* ``--json`` flag flips output to parseable JSON for every command.
* Missing api_key prints actionable error + exit 1 (NOT a stack trace).
* Bad config (malformed TOML, wrong types) → useful error + exit 1.
* AuthError → exit 2; NetworkError → exit 2; ServerError → exit 3.
* api_key is masked everywhere on stdout. Regex check against a
  64-char-hex sentinel.
* ``register --overwrite`` replaces a configured key; without it the
  command refuses.
* ``init`` is idempotent — second invocation reports
  ``status="already_initialised"`` instead of registering again.
* ``init --no-register`` writes a config skeleton without calling the
  Worker.
* ``publish --sign`` reads / writes the on-disk keypair, calls
  ``rotate_pubkey`` and ``publish(signing_key=...)``.
* ``drain`` invokes Client.drain with the right queue path and prints
  the report.
* Unknown command prints Click's usage error.

Tests substitute the SDK Client at the CLI module's import boundary
via ``monkeypatch.setattr(cli, "Client", FakeClient)`` — so no HTTP,
no respx, no transport mocks. The CLI's own logic (config merging,
exit codes, output formatting, masking) is what we're testing.
"""

from __future__ import annotations

import json as json_module
import re
from typing import TYPE_CHECKING, Any
from unittest.mock import MagicMock

import pytest
from click.testing import CliRunner

if TYPE_CHECKING:
    from collections.abc import Generator
    from pathlib import Path

from borg_collective import (
    Agent,
    AgentInfo,
    AgentPubkey,
    AmendmentCreated,
    AmendmentKind,
    AuthError,
    Counters,
    DrainReport,
    FeedbackAck,
    MatchMode,
    NetworkError,
    Outcome,
    Provenance,
    PublishedTrace,
    SearchResult,
    SearchResults,
    ServerError,
    Trace,
    TraceDetail,
    TrustLevel,
    Visibility,
)
from borg_collective.models import MyTraceListItem, MyTracesResponse
from borg_collective import cli as cli_module
from borg_collective._transport import DEFAULT_BASE_URL
from borg_collective._version import __version__
from borg_collective.cli import EXIT_NETWORK, EXIT_OK, EXIT_SERVER, EXIT_USER, main

# 64-char hex sentinel — the test "api_key". Distinct prefix so we can
# regex against the full string and assert it never lands in stdout.
TEST_API_KEY = "deadbeef" + "0" * 56
TEST_AGENT_ID = "11111111-1111-4111-8111-111111111111"
HEX_64 = "a" * 64


def _agent_response() -> Agent:
    return Agent(
        agent_id=TEST_AGENT_ID,
        display_name="cli-test",
        trust_level="soft",
        created_at=1700000000,
        api_key=TEST_API_KEY,
    )


def _agent_info() -> AgentInfo:
    return AgentInfo(
        agent_id=TEST_AGENT_ID,
        display_name="cli-test",
        trust_level=TrustLevel.SOFT,
        pubkey=None,
        created_at=1700000000,
    )


def _published() -> PublishedTrace:
    return PublishedTrace(
        trace_id="cli-trace-1",
        signed=False,
        error_signature=HEX_64,
        warning="unsigned_trace",
    )


def _trace_detail() -> TraceDetail:
    trace = Trace(
        trace_id="cli-trace-1",
        agent_id=TEST_AGENT_ID,
        error_signature=HEX_64,
        error_class=None,
        error_text="boom",
        task_description="t",
        approach_summary="a",
        root_cause="r",
        outcome=Outcome.RESOLVED,
        technology=None,
        tags=[],
        context_snapshot={},
        visibility=Visibility.PRIVATE,
        signed=False,
        signature=None,
        signer_pubkey=None,
        created_at=1,
    )
    return TraceDetail(trace=trace, amendments=[], counters=Counters())


def _search_results() -> SearchResults:
    return SearchResults(results=[], count=0, match_mode=MatchMode.FILTER)


def _feedback_ack() -> FeedbackAck:
    return FeedbackAck(recorded=True, trace_id="cli-trace-1", counters_updated=True)


def _amendment_created() -> AmendmentCreated:
    return AmendmentCreated(
        amendment_id="amend-1",
        trace_id="cli-trace-1",
        kind=AmendmentKind.CLARIFICATION,
        created_at=1,
    )


def _drain_report() -> DrainReport:
    return DrainReport(drained=3, failed=0, deferred=0)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def runner() -> CliRunner:
    return CliRunner(mix_stderr=False)


@pytest.fixture()
def borg_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect ~/.borg/ to a tmp dir for every test.

    Without this, CLI tests would either pollute the developer's home
    directory or read a real api_key from there. Setting BORG_HOME in
    the environment causes :func:`cli._borg_home` to use the tmp path.
    """
    monkeypatch.setenv("BORG_HOME", str(tmp_path / "borg-home"))
    monkeypatch.delenv("BORG_API_KEY", raising=False)
    monkeypatch.delenv("BORG_BASE_URL", raising=False)
    return tmp_path / "borg-home"


@pytest.fixture()
def fake_client(monkeypatch: pytest.MonkeyPatch) -> Generator[MagicMock, None, None]:
    """Patch :class:`borg_collective.client.Client` at the CLI's import site.

    The CLI module did ``from borg_collective.client import Client``;
    the patch target is therefore ``cli_module.Client``. Returns the
    mock so tests can configure return values (``mock.return_value
    .__enter__.return_value.publish.return_value = ...``).
    """
    mock = MagicMock(name="Client")
    instance = MagicMock(name="ClientInstance")
    mock.return_value.__enter__.return_value = instance
    mock.return_value.__exit__.return_value = False
    # Default return values so unconfigured tests still execute.
    instance.register_agent.return_value = _agent_response()
    instance.whoami.return_value = _agent_info()
    instance.publish.return_value = _published()
    instance.get.return_value = _trace_detail()
    instance.search.return_value = _search_results()
    instance.feedback.return_value = _feedback_ack()
    instance.add_amendment.return_value = _amendment_created()
    instance.rotate_pubkey.return_value = AgentPubkey(
        agent_id=TEST_AGENT_ID, pubkey=HEX_64, updated_at=1
    )
    instance.drain.return_value = _drain_report()
    monkeypatch.setattr(cli_module, "Client", mock)
    return mock


def _write_config(borg_home_path: Path, **fields: Any) -> None:
    """Write a config.toml with the given fields. Used by tests that
    need a pre-populated config."""
    borg_home_path.mkdir(mode=0o700, parents=True, exist_ok=True)
    lines = []
    for k, v in fields.items():
        lines.append(f'{k} = "{v}"')
    (borg_home_path / "config.toml").write_text("\n".join(lines) + "\n", encoding="utf-8")


def _no_full_api_key(text: str) -> bool:
    """Assert the full TEST_API_KEY never appears in ``text``."""
    return TEST_API_KEY not in text


# ---------------------------------------------------------------------------
# version + --version
# ---------------------------------------------------------------------------


class TestVersion:
    def test_version_subcommand(self, runner: CliRunner) -> None:
        result = runner.invoke(main, ["version"])
        assert result.exit_code == EXIT_OK
        assert __version__ in result.stdout

    def test_version_flag(self, runner: CliRunner) -> None:
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == EXIT_OK
        assert __version__ in result.stdout

    def test_help_lists_all_commands(self, runner: CliRunner) -> None:
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == EXIT_OK
        for cmd in [
            "amend",
            "drain",
            "feedback",
            "get",
            "init",
            "publish",
            "register",
            "search",
            "version",
            "whoami",
        ]:
            assert cmd in result.stdout

    def test_unknown_command_prints_usage_error(self, runner: CliRunner) -> None:
        result = runner.invoke(main, ["not-a-real-command"])
        assert result.exit_code != EXIT_OK


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


class TestInit:
    def test_init_registers_and_writes_config(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        result = runner.invoke(main, ["init", "--name", "alice"])
        assert result.exit_code == EXIT_OK, result.output
        # Config file was written with mode 0600.
        cfg = borg_home / "config.toml"
        assert cfg.exists()
        # Mode check is best-effort: tmpfs may not preserve perms
        # everywhere, but the local ext4 fixture does.
        assert (cfg.stat().st_mode & 0o777) == 0o600
        # Output is masked.
        assert _no_full_api_key(result.stdout)
        assert "deadbeef…" in result.stdout
        # The mock was called.
        fake_client.return_value.__enter__.return_value.register_agent.assert_called_once_with(
            display_name="alice"
        )

    def test_init_is_idempotent_when_config_exists(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        _write_config(
            borg_home,
            api_key=TEST_API_KEY,
            agent_id=TEST_AGENT_ID,
            base_url="https://x.invalid",
        )
        result = runner.invoke(main, ["init"])
        assert result.exit_code == EXIT_OK, result.output
        assert "already_initialised" in result.stdout
        assert _no_full_api_key(result.stdout)

    def test_init_no_register_writes_skeleton(
        self,
        runner: CliRunner,
        borg_home: Path,  # noqa: ARG002
        fake_client: MagicMock,
    ) -> None:
        result = runner.invoke(main, ["init", "--no-register"])
        assert result.exit_code == EXIT_OK, result.output
        # Worker was NOT called.
        fake_client.return_value.__enter__.return_value.register_agent.assert_not_called()
        assert "skeleton_only" in result.stdout

    def test_init_json_output_is_parseable(
        self,
        runner: CliRunner,
        borg_home: Path,  # noqa: ARG002
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        result = runner.invoke(main, ["init", "--json"])
        assert result.exit_code == EXIT_OK, result.output
        payload = json_module.loads(result.stdout)
        assert payload["agent_id"] == TEST_AGENT_ID
        assert payload["api_key"] == "deadbeef…"

    def test_init_first_run_prints_welcome_banner(
        self,
        runner: CliRunner,
        borg_home: Path,  # noqa: ARG002
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        result = runner.invoke(main, ["init", "--name", "alice"])
        assert result.exit_code == EXIT_OK, result.output
        # The welcome banner surfaces the safety floor on first init.
        assert "PRIVATE" in result.stdout
        assert __version__ in result.stdout
        assert "force_public=True" in result.stdout

    def test_init_idempotent_shows_force_hint(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        _write_config(
            borg_home,
            api_key=TEST_API_KEY,
            agent_id=TEST_AGENT_ID,
            base_url="https://x.invalid",
        )
        result = runner.invoke(main, ["init"])
        assert result.exit_code == EXIT_OK, result.output
        assert "already_initialised" in result.stdout
        # The hint surfaces the re-register path without --help.
        assert "--force" in result.stdout

    def test_init_force_yes_overwrites_without_prompt(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        # Existing config with one agent_id. --force --yes should
        # re-register and overwrite without prompting.
        old_agent_id = "22222222-2222-4222-8222-222222222222"
        _write_config(
            borg_home,
            api_key=TEST_API_KEY,
            agent_id=old_agent_id,
            base_url="https://x.invalid",
        )
        result = runner.invoke(main, ["init", "--force", "--yes", "--name", "alice"])
        assert result.exit_code == EXIT_OK, result.output
        # Worker WAS called — re-registration happened.
        fake_client.return_value.__enter__.return_value.register_agent.assert_called_once_with(
            display_name="alice"
        )
        # New agent_id is on disk.
        cfg_text = (borg_home / "config.toml").read_text(encoding="utf-8")
        assert TEST_AGENT_ID in cfg_text  # the mock returns TEST_AGENT_ID
        assert old_agent_id not in cfg_text

    def test_init_json_mode_does_not_print_welcome_banner(
        self,
        runner: CliRunner,
        borg_home: Path,  # noqa: ARG002
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        result = runner.invoke(main, ["init", "--json"])
        assert result.exit_code == EXIT_OK, result.output
        # JSON mode is for scripts; the banner would break parseability.
        assert "PRIVATE" not in result.stdout
        # stdout must be a single JSON object.
        json_module.loads(result.stdout)


class TestWelcomeBanner:
    def test_welcome_banner_six_lines_with_private_first(
        self, runner: CliRunner, borg_home: Path, fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        # Invoke through the runner so we exercise the real CLI path.
        result = runner.invoke(main, ["init", "--name", "alice"])
        assert result.exit_code == EXIT_OK, result.output
        # Pull the six banner lines out of stdout. They precede the
        # rendered table; the first banner line is the agent_id header.
        lines = [line for line in result.stdout.splitlines() if line.strip()]
        banner_start = next(
            i for i, line in enumerate(lines) if line.startswith("Borg Collective v")
        )
        banner = lines[banner_start : banner_start + 6]
        assert len(banner) == 6
        # Banner top-line names the version.
        assert __version__ in banner[0]
        # PRIVATE is the second line (the safety floor headline).
        assert "PRIVATE" in banner[1]
        # The third line is the explicit force_public=True opt-in.
        assert "force_public=True" in banner[2]


# ---------------------------------------------------------------------------
# register
# ---------------------------------------------------------------------------


class TestRegister:
    def test_register_writes_key(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        result = runner.invoke(main, ["register", "--name", "alice"])
        assert result.exit_code == EXIT_OK, result.output
        assert (borg_home / "config.toml").exists()
        assert _no_full_api_key(result.stdout)

    def test_register_refuses_overwrite_by_default(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        result = runner.invoke(main, ["register"])
        assert result.exit_code == EXIT_USER
        assert "already configured" in result.stderr

    def test_register_overwrite_replaces(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key="old-key", base_url="https://x.invalid")
        result = runner.invoke(main, ["register", "--overwrite"])
        assert result.exit_code == EXIT_OK, result.output
        # Worker was called.
        fake_client.return_value.__enter__.return_value.register_agent.assert_called_once()


# ---------------------------------------------------------------------------
# whoami
# ---------------------------------------------------------------------------


class TestWhoami:
    def test_whoami_prints_table(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        result = runner.invoke(main, ["whoami"])
        assert result.exit_code == EXIT_OK, result.output
        assert TEST_AGENT_ID in result.stdout
        assert _no_full_api_key(result.stdout)

    def test_whoami_json_output(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        result = runner.invoke(main, ["whoami", "--json"])
        assert result.exit_code == EXIT_OK, result.output
        payload = json_module.loads(result.stdout)
        assert payload["agent_id"] == TEST_AGENT_ID

    def test_whoami_missing_key_prints_actionable_error(
        self,
        runner: CliRunner,
        borg_home: Path,  # noqa: ARG002
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        result = runner.invoke(main, ["whoami"])
        assert result.exit_code == EXIT_USER
        assert "no api_key" in result.stderr
        assert "borg init" in result.stderr or "borg register" in result.stderr
        # No stack trace leak.
        assert "Traceback" not in result.stderr

    def test_whoami_auth_error_exit_2(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        fake_client.return_value.__enter__.return_value.whoami.side_effect = AuthError(
            "invalid key", status=403, error_code="invalid_key"
        )
        result = runner.invoke(main, ["whoami"])
        assert result.exit_code == EXIT_NETWORK
        assert "error:" in result.stderr.lower()
        assert "Traceback" not in result.stderr

    def test_whoami_network_error_exit_2(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        fake_client.return_value.__enter__.return_value.whoami.side_effect = NetworkError(
            "dns failed",
        )
        result = runner.invoke(main, ["whoami"])
        assert result.exit_code == EXIT_NETWORK

    def test_whoami_server_error_exit_3(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        fake_client.return_value.__enter__.return_value.whoami.side_effect = ServerError(
            "internal", status=500, error_code="internal"
        )
        result = runner.invoke(main, ["whoami"])
        assert result.exit_code == EXIT_SERVER


# ---------------------------------------------------------------------------
# config / api_key resolution
# ---------------------------------------------------------------------------


class TestConfigPrecedence:
    def test_flag_beats_env(
        self,
        runner: CliRunner,
        borg_home: Path,  # noqa: ARG002
        fake_client: MagicMock,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("BORG_API_KEY", "from-env")
        result = runner.invoke(main, ["whoami", "--api-key", TEST_API_KEY])
        assert result.exit_code == EXIT_OK, result.output
        # The Client was called with the flag value.
        fake_client.assert_called_with(api_key=TEST_API_KEY, base_url=DEFAULT_BASE_URL)

    def test_env_beats_file(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        _write_config(borg_home, api_key="from-file", base_url="https://x.invalid")
        monkeypatch.setenv("BORG_API_KEY", TEST_API_KEY)
        result = runner.invoke(main, ["whoami"])
        assert result.exit_code == EXIT_OK, result.output
        fake_client.assert_called_with(api_key=TEST_API_KEY, base_url="https://x.invalid")

    def test_malformed_config_exits_user_error(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        borg_home.mkdir(mode=0o700, parents=True, exist_ok=True)
        # Not valid TOML.
        (borg_home / "config.toml").write_text("[oops\nthis = is = broken\n", encoding="utf-8")
        result = runner.invoke(main, ["whoami"])
        assert result.exit_code == EXIT_USER
        assert "malformed TOML" in result.stderr

    def test_wrong_type_in_config_exits_user_error(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        borg_home.mkdir(mode=0o700, parents=True, exist_ok=True)
        (borg_home / "config.toml").write_text("api_key = 42\n", encoding="utf-8")
        result = runner.invoke(main, ["whoami"])
        assert result.exit_code == EXIT_USER
        assert "must be a string" in result.stderr


# ---------------------------------------------------------------------------
# publish
# ---------------------------------------------------------------------------


class TestPublish:
    @staticmethod
    def _trace_file(tmp_path: Path) -> Path:
        path = tmp_path / "trace.json"
        path.write_text(
            json_module.dumps(
                {
                    "error_text": "boom",
                    "task_description": "t",
                    "approach_summary": "a",
                    "root_cause": "r",
                    "outcome": "resolved",
                }
            ),
            encoding="utf-8",
        )
        return path

    def test_publish_unsigned(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
        tmp_path: Path,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        path = self._trace_file(tmp_path)
        result = runner.invoke(main, ["publish", str(path)])
        assert result.exit_code == EXIT_OK, result.output
        assert "cli-trace-1" in result.stdout
        # Default: signing_key=None.
        kwargs = fake_client.return_value.__enter__.return_value.publish.call_args.kwargs
        assert kwargs.get("signing_key") is None

    def test_publish_signed_uses_keyfile(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
        tmp_path: Path,
    ) -> None:
        _write_config(
            borg_home,
            api_key=TEST_API_KEY,
            agent_id=TEST_AGENT_ID,
            base_url="https://x.invalid",
        )
        path = self._trace_file(tmp_path)
        result = runner.invoke(main, ["publish", str(path), "--sign"])
        assert result.exit_code == EXIT_OK, result.output
        # rotate_pubkey was called before publish.
        instance = fake_client.return_value.__enter__.return_value
        assert instance.rotate_pubkey.called
        # signing_key was passed to publish.
        publish_kwargs = instance.publish.call_args.kwargs
        assert publish_kwargs["signing_key"] is not None
        # Keypair file persists.
        keyfile = borg_home / "keys" / f"{TEST_AGENT_ID}.hex"
        assert keyfile.exists()
        seed = keyfile.read_text(encoding="utf-8").strip()
        # Hex-only firewall.
        assert re.fullmatch(r"[0-9a-f]{64}", seed) is not None

    def test_publish_sign_without_agent_id_errors(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,  # noqa: ARG002
        tmp_path: Path,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        path = self._trace_file(tmp_path)
        result = runner.invoke(main, ["publish", str(path), "--sign"])
        assert result.exit_code == EXIT_USER
        assert "agent_id" in result.stderr

    def test_publish_bad_json_file(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,  # noqa: ARG002
        tmp_path: Path,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        path = tmp_path / "trace.json"
        path.write_text("not json", encoding="utf-8")
        result = runner.invoke(main, ["publish", str(path)])
        assert result.exit_code == EXIT_USER
        assert "could not read" in result.stderr or "invalid" in result.stderr.lower()

    def test_publish_invalid_failure_trace(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,  # noqa: ARG002
        tmp_path: Path,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        path = tmp_path / "trace.json"
        # Missing required fields.
        path.write_text(json_module.dumps({"error_text": "x"}), encoding="utf-8")
        result = runner.invoke(main, ["publish", str(path)])
        assert result.exit_code == EXIT_USER
        assert "not a valid FailureTrace" in result.stderr

    def test_publish_default_force_public_is_false(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
        tmp_path: Path,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        path = self._trace_file(tmp_path)
        result = runner.invoke(main, ["publish", str(path)])
        assert result.exit_code == EXIT_OK, result.output
        kwargs = fake_client.return_value.__enter__.return_value.publish.call_args.kwargs
        assert kwargs.get("force_public") is False

    def test_publish_force_public_flag_passes_through(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
        tmp_path: Path,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        path = self._trace_file(tmp_path)
        result = runner.invoke(main, ["publish", str(path), "--force-public"])
        assert result.exit_code == EXIT_OK, result.output
        kwargs = fake_client.return_value.__enter__.return_value.publish.call_args.kwargs
        assert kwargs.get("force_public") is True


# ---------------------------------------------------------------------------
# get / search / feedback / amend / drain
# ---------------------------------------------------------------------------


class TestGet:
    def test_get_prints_trace(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        result = runner.invoke(main, ["get", "cli-trace-1"])
        assert result.exit_code == EXIT_OK, result.output
        assert "cli-trace-1" in result.stdout

    def test_get_json(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        result = runner.invoke(main, ["get", "cli-trace-1", "--json"])
        assert result.exit_code == EXIT_OK, result.output
        payload = json_module.loads(result.stdout)
        assert payload["trace"]["trace_id"] == "cli-trace-1"


class TestSearch:
    def test_search_by_query(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        result = runner.invoke(main, ["search", "--query", "ImportError"])
        assert result.exit_code == EXIT_OK, result.output
        kwargs = fake_client.return_value.__enter__.return_value.search.call_args.kwargs
        assert kwargs["query"] == "ImportError"

    def test_search_by_tag_repeated(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        result = runner.invoke(
            main,
            ["search", "--tag", "python", "--tag", "import"],
        )
        assert result.exit_code == EXIT_OK, result.output
        kwargs = fake_client.return_value.__enter__.return_value.search.call_args.kwargs
        assert kwargs["tags"] == ["python", "import"]

    def test_search_limit_passed_through(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        result = runner.invoke(main, ["search", "--query", "x", "--limit", "25"])
        assert result.exit_code == EXIT_OK, result.output
        kwargs = fake_client.return_value.__enter__.return_value.search.call_args.kwargs
        assert kwargs["limit"] == 25


class TestFeedback:
    def test_feedback_full_funnel(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        result = runner.invoke(
            main,
            [
                "feedback",
                "cli-trace-1",
                "--retrieved",
                "--read",
                "--applied",
                "--outcome",
                "helped",
                "--note",
                "thanks",
            ],
        )
        assert result.exit_code == EXIT_OK, result.output
        kwargs = fake_client.return_value.__enter__.return_value.feedback.call_args.kwargs
        assert kwargs["retrieved"] is True
        assert kwargs["read"] is True
        assert kwargs["applied"] is True

    def test_feedback_minimal(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        result = runner.invoke(main, ["feedback", "cli-trace-1"])
        assert result.exit_code == EXIT_OK, result.output
        kwargs = fake_client.return_value.__enter__.return_value.feedback.call_args.kwargs
        assert kwargs["retrieved"] is False
        assert kwargs["outcome"] is None


class TestAmend:
    def test_amend_default_kind(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        result = runner.invoke(main, ["amend", "cli-trace-1", "--content", "more context"])
        assert result.exit_code == EXIT_OK, result.output
        kwargs = fake_client.return_value.__enter__.return_value.add_amendment.call_args.kwargs
        assert kwargs["kind"] is AmendmentKind.CLARIFICATION


class TestDrain:
    def test_drain_default_path(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        result = runner.invoke(main, ["drain"])
        assert result.exit_code == EXIT_OK, result.output
        # Client was constructed with offline_queue_path=<borg_home>/offline_queue.sqlite.
        client_kwargs = fake_client.call_args.kwargs
        assert client_kwargs["offline_queue_path"] == borg_home / "offline_queue.sqlite"

    def test_drain_max_items(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, base_url="https://x.invalid")
        result = runner.invoke(main, ["drain", "--max-items", "50"])
        assert result.exit_code == EXIT_OK, result.output
        kwargs = fake_client.return_value.__enter__.return_value.drain.call_args.kwargs
        assert kwargs["max_items"] == 50


# ---------------------------------------------------------------------------
# Cross-cutting masking
# ---------------------------------------------------------------------------


class TestApiKeyMasking:
    def test_api_key_never_in_register_stdout(
        self,
        runner: CliRunner,
        borg_home: Path,  # noqa: ARG002
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        result = runner.invoke(main, ["register", "--name", "alice"])
        assert result.exit_code == EXIT_OK, result.output
        assert _no_full_api_key(result.stdout)

    def test_api_key_never_in_init_stdout(
        self,
        runner: CliRunner,
        borg_home: Path,  # noqa: ARG002
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        result = runner.invoke(main, ["init"])
        assert result.exit_code == EXIT_OK, result.output
        assert _no_full_api_key(result.stdout)

    def test_api_key_never_in_init_json(
        self,
        runner: CliRunner,
        borg_home: Path,  # noqa: ARG002
        fake_client: MagicMock,  # noqa: ARG002
    ) -> None:
        result = runner.invoke(main, ["init", "--json"])
        assert result.exit_code == EXIT_OK, result.output
        # Even the JSON payload only carries the masked form.
        assert _no_full_api_key(result.stdout)


# ---------------------------------------------------------------------------
# demo
# ---------------------------------------------------------------------------


def _demo_search_match() -> SearchResults:
    """A SearchResults shaped like the live federation's T1 response.

    Distinguishing strings (trace_id, error_class, preview) are unique
    enough that the `calls_search_against_real_endpoint` test can prove
    the demo wired the response into stdout rather than a hardcoded
    literal.
    """
    return SearchResults(
        results=[
            SearchResult(
                trace_id="module-not-found_demo1234",
                error_signature="a" * 64,
                error_class="module-not-found",
                outcome=Outcome.RESOLVED,
                signed=False,
                created_at=1777300000,
                preview="ENOENT: no such file or directory, posix_spawnp 'python'",
                counters=Counters(),
            )
        ],
        count=1,
        match_mode=MatchMode.QUERY,
    )


def _demo_trace_detail(
    provenance: Provenance = Provenance.CURATED,
) -> TraceDetail:
    """TraceDetail for the matched T1 trace, with a recognisable fix.

    Defaults to ``provenance=CURATED`` because the demo's flagship hit
    is a seed-corpus trace. Pass ``Provenance.ORGANIC`` to exercise the
    organic-rendering path.
    """
    trace = Trace(
        trace_id="module-not-found_demo1234",
        agent_id=TEST_AGENT_ID,
        error_signature="a" * 64,
        error_class="module-not-found",
        error_text="ENOENT: no such file or directory, posix_spawnp 'python'",
        task_description="Launch the Hermes MCP server.",
        approach_summary="ubuntu unaliased python.",
        root_cause="Ubuntu 24.04 does not symlink python.",
        outcome=Outcome.RESOLVED,
        technology="python",
        tags=["hermes", "mcp"],
        context_snapshot={
            "fix": "Edit mcp_config.json: change 'python' to 'python3'.",
        },
        visibility=Visibility.PUBLIC,
        signed=False,
        signature=None,
        signer_pubkey=None,
        provenance=provenance,
        source_url=None,
        license="CC-BY-4.0" if provenance is Provenance.CURATED else None,
        created_at=1777300000,
    )
    return TraceDetail(trace=trace, amendments=[], counters=Counters())


class TestDemo:
    def test_demo_completes_under_90s(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(
            borg_home,
            api_key=TEST_API_KEY,
            agent_id=TEST_AGENT_ID,
            base_url="https://x.invalid",
        )
        instance = fake_client.return_value.__enter__.return_value
        instance.search.return_value = _demo_search_match()
        instance.get.return_value = _demo_trace_detail()

        import time as _time

        t0 = _time.time()
        result = runner.invoke(main, ["demo"])
        elapsed = _time.time() - t0

        assert result.exit_code == EXIT_OK, result.output
        # 90s is the contract, but with a mocked Client and ~1s of
        # legibility sleeps the actual run should finish in <5s.
        assert elapsed < 90.0
        assert "Demo complete" in result.stdout

    def test_demo_calls_search_against_real_endpoint(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        # The demo MUST wire the search response into stdout — no canned
        # strings. Mock returns a recognisable trace_id and fix; assert
        # both surface verbatim in the demo's output.
        _write_config(
            borg_home,
            api_key=TEST_API_KEY,
            agent_id=TEST_AGENT_ID,
            base_url="https://x.invalid",
        )
        instance = fake_client.return_value.__enter__.return_value
        instance.search.return_value = _demo_search_match()
        instance.get.return_value = _demo_trace_detail()

        result = runner.invoke(main, ["demo"])
        assert result.exit_code == EXIT_OK, result.output
        # The trace_id from the mocked search is in the output.
        assert "module-not-found_demo1234" in result.stdout
        # The fix from the mocked TraceDetail.context_snapshot is in the
        # output, not a hardcoded literal — proves the demo reads from
        # the live response.
        assert (
            "Edit mcp_config.json: change 'python' to 'python3'." in result.stdout
        )
        # The provenance label comes from TraceDetail.trace.provenance.value,
        # not a hardcoded "(curated)" — proves the v0.4 attribution
        # round-trip is wired end-to-end.
        assert "(curated)" in result.stdout
        # And the search call happened with the expected substring.
        instance.search.assert_called_once()
        kwargs = instance.search.call_args.kwargs
        assert "query" in kwargs
        assert kwargs["query"] == "posix_spawnp"

    def test_demo_renders_provenance_organic_when_match_is_organic(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        """When the matched trace is organic (not curated), the demo's
        step-2 line renders "(organic)" — the label is sourced from
        the live trace's provenance, not a hardcoded literal.
        """
        _write_config(
            borg_home,
            api_key=TEST_API_KEY,
            agent_id=TEST_AGENT_ID,
            base_url="https://x.invalid",
        )
        instance = fake_client.return_value.__enter__.return_value
        instance.search.return_value = _demo_search_match()
        instance.get.return_value = _demo_trace_detail(provenance=Provenance.ORGANIC)

        result = runner.invoke(main, ["demo"])
        assert result.exit_code == EXIT_OK, result.output
        assert "(organic)" in result.stdout
        assert "(curated)" not in result.stdout

    def test_demo_publishes_follow_up_with_parent_trace_id(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        """Demo step 4: a follow-up FailureTrace with parent_trace_id
        set to the matched trace lands in the publish call."""
        _write_config(
            borg_home,
            api_key=TEST_API_KEY,
            agent_id=TEST_AGENT_ID,
            base_url="https://x.invalid",
        )
        instance = fake_client.return_value.__enter__.return_value
        instance.search.return_value = _demo_search_match()
        instance.get.return_value = _demo_trace_detail()
        instance.publish.return_value = PublishedTrace(
            trace_id="follow-up_xyz",
            signed=False,
            error_signature="a" * 64,
        )
        result = runner.invoke(main, ["demo"])
        assert result.exit_code == EXIT_OK, result.output
        instance.publish.assert_called_once()
        published_arg = instance.publish.call_args.args[0]
        assert published_arg.parent_trace_id == "module-not-found_demo1234"
        assert "follow-up_xyz" in result.stdout

    def test_demo_follow_up_outcome_is_resolved(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(
            borg_home,
            api_key=TEST_API_KEY,
            agent_id=TEST_AGENT_ID,
            base_url="https://x.invalid",
        )
        instance = fake_client.return_value.__enter__.return_value
        instance.search.return_value = _demo_search_match()
        instance.get.return_value = _demo_trace_detail()
        instance.publish.return_value = PublishedTrace(
            trace_id="t", signed=False, error_signature="a" * 64,
        )
        result = runner.invoke(main, ["demo"])
        assert result.exit_code == EXIT_OK, result.output
        published_arg = instance.publish.call_args.args[0]
        assert published_arg.outcome == Outcome.RESOLVED
        assert published_arg.visibility == Visibility.PRIVATE
        assert "follow-up" in published_arg.tags

    def test_demo_prints_review_hint(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(
            borg_home,
            api_key=TEST_API_KEY,
            agent_id=TEST_AGENT_ID,
            base_url="https://x.invalid",
        )
        instance = fake_client.return_value.__enter__.return_value
        instance.search.return_value = _demo_search_match()
        instance.get.return_value = _demo_trace_detail()
        instance.publish.return_value = PublishedTrace(
            trace_id="follow-up_review", signed=False, error_signature="a" * 64,
        )
        result = runner.invoke(main, ["demo"])
        assert "Run `borg review`" in result.stdout
        assert "private" in result.stdout

    def test_demo_falls_back_cleanly_on_empty_results(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(
            borg_home,
            api_key=TEST_API_KEY,
            agent_id=TEST_AGENT_ID,
            base_url="https://x.invalid",
        )
        instance = fake_client.return_value.__enter__.return_value
        instance.search.return_value = SearchResults(
            results=[], count=0, match_mode=MatchMode.QUERY
        )

        result = runner.invoke(main, ["demo"])
        assert result.exit_code == 1
        assert "no match" in result.stdout
        assert "demo aborted" in result.stdout
        # get() must NOT be called when search returned no results.
        instance.get.assert_not_called()


# ---------------------------------------------------------------------------
# E0.7 — `borg review` group
# ---------------------------------------------------------------------------


def _list_response_with(*items: MyTraceListItem) -> MyTracesResponse:
    return MyTracesResponse(
        traces=list(items),
        count=len(items),
        next_before=None,
    )


def _trace_list_item(trace_id: str = "tid_1", **overrides) -> MyTraceListItem:
    base = {
        "trace_id": trace_id,
        "error_class": "module-not-found",
        "visibility": Visibility.PRIVATE,
        "provenance": Provenance.ORGANIC,
        "parent_trace_id": None,
        "error_preview": "ENOENT: no such file or directory",
        "created_at": 1700000000,
    }
    base.update(overrides)
    return MyTraceListItem(**base)


class TestReview:
    def test_review_list_shows_recent_private(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, agent_id=TEST_AGENT_ID, base_url="https://x.invalid")
        instance = fake_client.return_value.__enter__.return_value
        instance.list_my_traces.return_value = _list_response_with(
            _trace_list_item(trace_id="tid_recent"),
        )
        result = runner.invoke(main, ["review", "list"])
        assert result.exit_code == EXIT_OK, result.output
        # Check that the trace_id was rendered (last 23 chars of "tid_recent" → "tid_recent")
        assert "tid_recent" in result.stdout
        instance.list_my_traces.assert_called_once()

    def test_review_promote_prompts_confirmation(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, agent_id=TEST_AGENT_ID, base_url="https://x.invalid")
        instance = fake_client.return_value.__enter__.return_value
        instance.get.return_value = _trace_detail()
        # Type "n" at the prompt → cancelled, no PATCH call.
        result = runner.invoke(main, ["review", "promote", "tid_x"], input="n\n")
        assert result.exit_code == EXIT_OK, result.output
        assert "Cancelled" in result.stdout
        instance.update_trace.assert_not_called()

    def test_review_promote_yes_flag_skips_prompt(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, agent_id=TEST_AGENT_ID, base_url="https://x.invalid")
        instance = fake_client.return_value.__enter__.return_value
        instance.get.return_value = _trace_detail()
        instance.update_trace.return_value = {"trace_id": "tid_x", "updated_fields": ["visibility"]}
        result = runner.invoke(main, ["review", "promote", "tid_x", "--yes"])
        assert result.exit_code == EXIT_OK, result.output
        instance.update_trace.assert_called_once()
        kwargs = instance.update_trace.call_args.kwargs
        assert kwargs["force_public"] is True
        assert kwargs["visibility"] == Visibility.PUBLIC

    def test_review_promote_warns_about_visibility(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, agent_id=TEST_AGENT_ID, base_url="https://x.invalid")
        instance = fake_client.return_value.__enter__.return_value
        instance.get.return_value = _trace_detail()
        result = runner.invoke(main, ["review", "promote", "tid_x"], input="n\n")
        assert "PUBLIC" in result.stdout
        assert "error_text" in result.stdout
        assert "anyone who has already" in result.stdout

    def test_review_delete_requires_confirmation(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, agent_id=TEST_AGENT_ID, base_url="https://x.invalid")
        instance = fake_client.return_value.__enter__.return_value
        # Cancel.
        result = runner.invoke(main, ["review", "delete", "tid_x"], input="n\n")
        assert "Cancelled" in result.stdout
        instance.delete_trace.assert_not_called()
        # Confirm with --yes.
        instance.delete_trace.return_value = {"trace_id": "tid_x", "deleted_at": 1700000001}
        result2 = runner.invoke(main, ["review", "delete", "tid_x", "--yes"])
        assert result2.exit_code == EXIT_OK, result2.output
        instance.delete_trace.assert_called_once_with("tid_x")

    def test_review_show_displays_parent(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, agent_id=TEST_AGENT_ID, base_url="https://x.invalid")
        instance = fake_client.return_value.__enter__.return_value
        # Build a TraceDetail with a parent_trace_id set.
        parent_trace = Trace(
            trace_id="parent_xyz",
            agent_id=TEST_AGENT_ID,
            error_signature=HEX_64,
            error_class="parent-class",
            error_text="parent error",
            task_description="parent task",
            approach_summary="parent approach",
            root_cause="parent rc",
            outcome=Outcome.RESOLVED,
            visibility=Visibility.PUBLIC,
            signed=False,
            created_at=1,
        )
        child = _trace_detail()
        child.trace.parent_trace_id = "parent_xyz"
        instance.get.side_effect = [
            child,
            TraceDetail(trace=parent_trace, amendments=[], counters=Counters()),
        ]
        result = runner.invoke(main, ["review", "show", "child_xyz"])
        assert result.exit_code == EXIT_OK, result.output
        assert "parent_xyz" in result.stdout
        assert "parent-class" in result.stdout

    def test_review_edit_opens_editor_diffs_posts(
        self,
        runner: CliRunner,
        borg_home: Path,
        fake_client: MagicMock,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        _write_config(borg_home, api_key=TEST_API_KEY, agent_id=TEST_AGENT_ID, base_url="https://x.invalid")
        instance = fake_client.return_value.__enter__.return_value
        instance.get.return_value = _trace_detail()

        # Monkey-patch click.edit so the test simulates the user
        # editing one field and saving.
        def fake_edit(text: str) -> str:
            obj = json_module.loads(text)
            obj["root_cause"] = "edited root cause"
            return json_module.dumps(obj, indent=2)

        monkeypatch.setattr("borg_collective.cli.click.edit", fake_edit)
        instance.update_trace.return_value = {"trace_id": "t", "updated_fields": ["root_cause"]}
        result = runner.invoke(main, ["review", "edit", "tid_x"])
        assert result.exit_code == EXIT_OK, result.output
        instance.update_trace.assert_called_once()
        kwargs = instance.update_trace.call_args.kwargs
        assert kwargs["root_cause"] == "edited root cause"
