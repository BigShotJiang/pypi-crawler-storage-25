"""Unit tests for ``borg_collective._closure`` — FakeClient-driven.

The live integration suite (``tests/integration/test_closure.py``) is
expensive: it publishes signed traces, polls search, and confirms
counter rollups against the production Worker. These unit tests
exercise the per-trial logic, the failure-mode classification, and
the aggregation math against :class:`borg_collective.testing.FakeClient`
so a logic bug surfaces in milliseconds, not after a live cap-burning
run.

Coverage:

* The success path (publish → search hit → fetch → verify → feedback
  → counter confirmed).
* Each of the seven failure outcomes: ``publish_failed``,
  ``search_timeout``, ``fetch_failed``, ``verify_failed``,
  ``feedback_failed``, ``counter_timeout``.
* Aggregation: closure_rate, signature_verification_rate,
  feedback_acceptance_rate, percentile math, schema versioning.
* :func:`write_results` round-trips JSON with the expected shape.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from borg_collective import (
    Counters,
    FailureTrace,
    FeedbackAck,
    MatchMode,
    Outcome,
    PublishedTrace,
    SearchResult,
    SearchResults,
    SigningKeyPair,
    Trace,
    TraceDetail,
    Visibility,
)
from borg_collective._closure import (
    ClosureResults,
    TrialResult,
    _percentile,
    _verify_signature,
    run_closure,
    write_results,
)
from borg_collective._signing import sign_trace
from borg_collective.testing import FakeClient

if TYPE_CHECKING:
    from pathlib import Path

# Speed knob: the production poll intervals (200ms search, 500ms
# counter) make sub-second unit tests impossible. Patch the module
# constants to near-zero in fixtures that exercise full trials.
import borg_collective._closure as closure_module


def _stub_signed_trace(
    *,
    pubkey: str,
    sig_hex: str,
    trace_id: str = "fake-trace-id",
    error_class: str = "ClosureTestError_xxx",
    error_text: str = "closure test trial",
) -> Trace:
    """Build a Trace as if returned by GET /traces/:id for a signed publish.

    Mirrors the wire shape: error_signature is 64-hex, signature is
    128-hex, signer_pubkey is 64-hex, plus the four server-added fields
    (trace_id, agent_id, signed, created_at).
    """
    return Trace(
        trace_id=trace_id,
        agent_id="agent-a-id",
        error_signature="ab" * 32,
        error_class=error_class,
        error_text=error_text,
        task_description="closure test trial 1",
        approach_summary="closure test",
        root_cause="closure test",
        outcome=Outcome.RESOLVED,
        tags=["closure-test"],
        context_snapshot={},
        visibility=Visibility.PUBLIC,
        signed=True,
        signature=sig_hex,
        signer_pubkey=pubkey,
        created_at=0,
    )


def _real_signed_trace_for_kp(kp: SigningKeyPair) -> Trace:
    """Build a Trace whose signature actually verifies under ``kp``.

    Constructs the body the same way Client.publish does — sign over
    the FailureTrace dict (with error_signature/signer_pubkey added),
    then wrap it as a fetched Trace with server-added fields.
    """
    ft = FailureTrace(
        error_class="ClosureTestError_unit",
        error_text="closure test trial 1 of 1",
        task_description="closure test trial 1",
        approach_summary="closure test",
        root_cause="closure test",
        outcome=Outcome.RESOLVED,
        tags=["closure-test"],
        visibility=Visibility.PUBLIC,
    )
    body: dict[str, Any] = ft.model_dump(exclude_none=True, mode="json")
    # Deterministic 64-hex sentinel; the exact value does not matter
    # as long as it round-trips intact through canonicalization.
    body["error_signature"] = "cd" * 32
    body["signer_pubkey"] = kp.verify_key_hex
    sig_hex = sign_trace(kp.signing_key_hex, body)
    return Trace(
        trace_id="real-trace-id",
        agent_id="agent-a-id",
        error_signature=body["error_signature"],
        error_class=body["error_class"],
        error_text=body["error_text"],
        task_description=body["task_description"],
        approach_summary=body["approach_summary"],
        root_cause=body["root_cause"],
        outcome=Outcome(body["outcome"]),
        tags=body["tags"],
        context_snapshot=body.get("context_snapshot", {}),
        visibility=Visibility(body["visibility"]),
        signed=True,
        signature=sig_hex,
        signer_pubkey=kp.verify_key_hex,
        created_at=0,
    )


# ---------------------------------------------------------------------------
# _verify_signature — the field-stripping guard
# ---------------------------------------------------------------------------


def test_verify_signature_valid() -> None:
    """A real Ed25519 signature verifies after stripping server fields."""
    kp = SigningKeyPair.generate()
    trace = _real_signed_trace_for_kp(kp)
    assert _verify_signature(trace, expected_pubkey=kp.verify_key_hex) is True


def test_verify_signature_wrong_expected_pubkey() -> None:
    """Mismatched expected_pubkey fails fast — even if on-trace pubkey is correct."""
    kp = SigningKeyPair.generate()
    other_kp = SigningKeyPair.generate()
    trace = _real_signed_trace_for_kp(kp)
    assert _verify_signature(trace, expected_pubkey=other_kp.verify_key_hex) is False


def test_verify_signature_unsigned_trace() -> None:
    """An unsigned trace returns False (never raises)."""
    trace = Trace(
        trace_id="t",
        agent_id="a",
        error_signature="ab" * 32,
        error_class=None,
        error_text="x",
        task_description="x",
        approach_summary="x",
        root_cause="x",
        outcome=Outcome.RESOLVED,
        tags=[],
        context_snapshot={},
        visibility=Visibility.PUBLIC,
        signed=False,
        signature=None,
        signer_pubkey=None,
        created_at=0,
    )
    assert _verify_signature(trace, expected_pubkey="ab" * 32) is False


def test_verify_signature_tampered_field() -> None:
    """Mutating a body field after signing breaks verification."""
    kp = SigningKeyPair.generate()
    trace = _real_signed_trace_for_kp(kp)
    tampered = trace.model_copy(update={"error_text": "tampered"})
    assert _verify_signature(tampered, expected_pubkey=kp.verify_key_hex) is False


# ---------------------------------------------------------------------------
# Full-trial flow — FakeClient-driven success path
# ---------------------------------------------------------------------------


def _patch_short_polls(monkeypatch: Any) -> None:
    """Shrink the poll budgets so unit tests finish in milliseconds."""
    monkeypatch.setattr(closure_module, "_SEARCH_POLL_INTERVAL_S", 0.0)
    monkeypatch.setattr(closure_module, "_SEARCH_POLL_TIMEOUT_S", 0.05)
    monkeypatch.setattr(closure_module, "_COUNTER_POLL_INTERVAL_S", 0.0)
    monkeypatch.setattr(closure_module, "_COUNTER_POLL_TIMEOUT_S", 0.05)


def _wire_success_trial(
    *,
    fake_a: FakeClient,
    fake_b: FakeClient,
    kp_a: SigningKeyPair,
) -> Trace:
    """Queue responses on the two fakes for one fully-successful trial."""
    real_trace = _real_signed_trace_for_kp(kp_a)
    fake_a.set_next_response(
        "publish",
        PublishedTrace(
            trace_id=real_trace.trace_id,
            signed=True,
            error_signature=real_trace.error_signature,
        ),
    )
    fake_b.set_next_response(
        "search",
        SearchResults(
            results=[
                SearchResult(
                    trace_id=real_trace.trace_id,
                    error_signature=real_trace.error_signature,
                    error_class=real_trace.error_class,
                    outcome=Outcome.RESOLVED,
                    signed=True,
                    created_at=0,
                    preview=real_trace.error_text[:100],
                    counters=Counters(),
                )
            ],
            count=1,
            match_mode=MatchMode.FILTER,
        ),
    )
    fake_b.set_next_response(
        "get",
        TraceDetail(trace=real_trace, amendments=[], counters=Counters()),
    )
    fake_b.set_next_response(
        "feedback",
        FeedbackAck(
            recorded=True,
            trace_id=real_trace.trace_id,
            counters_updated=True,
            note=None,
        ),
    )
    bumped = real_trace.model_copy()  # same trace, with helped=1 in counters
    fake_a.set_next_response(
        "get",
        TraceDetail(trace=bumped, amendments=[], counters=Counters(helped=1)),
    )
    return real_trace


def test_run_closure_full_success_path(monkeypatch: Any) -> None:
    """One trial, all six steps succeed → outcome='success', sigverify True."""
    _patch_short_polls(monkeypatch)
    kp_a = SigningKeyPair.generate()
    kp_b = SigningKeyPair.generate()
    fake_a = FakeClient()
    fake_b = FakeClient()
    _wire_success_trial(fake_a=fake_a, fake_b=fake_b, kp_a=kp_a)

    results = run_closure(
        fake_a,  # type: ignore[arg-type]  # FakeClient is structurally a Client
        fake_b,  # type: ignore[arg-type]
        signing_key_a=kp_a,
        signing_key_b=kp_b,
        agent_a_id="agent-a-id",
        agent_b_id="agent-b-id",
        n_trials=1,
        base_url="http://fake.test",
    )

    assert isinstance(results, ClosureResults)
    assert results.n_trials == 1
    assert results.closure_rate == 1.0
    assert results.signature_verification_rate == 1.0
    assert results.feedback_acceptance_rate == 1.0
    assert results.version == "1"
    assert results.base_url == "http://fake.test"
    assert len(results.trials) == 1
    trial = results.trials[0]
    assert trial.outcome == "success"
    assert trial.signature_verified is True
    assert trial.feedback_published is True
    assert trial.counter_updated is True
    assert trial.duration_ms >= 0
    assert set(trial.phases_ms) == {
        "publish",
        "propagate",
        "search",
        "fetch",
        "verify",
        "feedback",
        "counter_confirm",
    }


# ---------------------------------------------------------------------------
# Failure-mode coverage
# ---------------------------------------------------------------------------


def test_run_closure_publish_exception(monkeypatch: Any) -> None:
    """publish() raises → outcome='publish_failed', no downstream calls."""
    _patch_short_polls(monkeypatch)
    kp_a = SigningKeyPair.generate()
    kp_b = SigningKeyPair.generate()
    fake_a = FakeClient()
    fake_b = FakeClient()
    fake_a.set_next_exception("publish", RuntimeError("connection reset"))

    results = run_closure(
        fake_a,  # type: ignore[arg-type]
        fake_b,  # type: ignore[arg-type]
        signing_key_a=kp_a,
        signing_key_b=kp_b,
        agent_a_id="agent-a-id",
        agent_b_id="agent-b-id",
        n_trials=1,
    )
    assert results.closure_rate == 0.0
    trial = results.trials[0]
    assert trial.outcome == "publish_failed"
    assert trial.error is not None
    assert "RuntimeError" in trial.error
    # No search call should have been issued.
    assert len(fake_b.calls_for("search")) == 0


def test_run_closure_publish_unsigned_response(monkeypatch: Any) -> None:
    """Worker accepts but signed=false → outcome='publish_failed'."""
    _patch_short_polls(monkeypatch)
    kp_a = SigningKeyPair.generate()
    kp_b = SigningKeyPair.generate()
    fake_a = FakeClient()
    fake_b = FakeClient()
    fake_a.set_next_response(
        "publish",
        PublishedTrace(trace_id="tid", signed=False, error_signature="ab" * 32),
    )
    results = run_closure(
        fake_a,  # type: ignore[arg-type]
        fake_b,  # type: ignore[arg-type]
        signing_key_a=kp_a,
        signing_key_b=kp_b,
        agent_a_id="agent-a-id",
        agent_b_id="agent-b-id",
        n_trials=1,
    )
    assert results.trials[0].outcome == "publish_failed"


def test_run_closure_search_timeout(monkeypatch: Any) -> None:
    """Search never returns the trace → outcome='search_timeout'."""
    _patch_short_polls(monkeypatch)
    kp_a = SigningKeyPair.generate()
    kp_b = SigningKeyPair.generate()
    fake_a = FakeClient()
    fake_b = FakeClient()
    fake_a.set_next_response(
        "publish",
        PublishedTrace(trace_id="tid", signed=True, error_signature="ab" * 32),
    )
    # Default search response has no results — the poll loop will spin
    # until the timeout patched above (50 ms) elapses.
    results = run_closure(
        fake_a,  # type: ignore[arg-type]
        fake_b,  # type: ignore[arg-type]
        signing_key_a=kp_a,
        signing_key_b=kp_b,
        agent_a_id="agent-a-id",
        agent_b_id="agent-b-id",
        n_trials=1,
    )
    assert results.trials[0].outcome == "search_timeout"


def test_run_closure_verify_failed(monkeypatch: Any) -> None:
    """Trace fetched but signature is invalid → outcome='verify_failed'."""
    _patch_short_polls(monkeypatch)
    kp_a = SigningKeyPair.generate()
    other_kp = SigningKeyPair.generate()
    kp_b = SigningKeyPair.generate()
    fake_a = FakeClient()
    fake_b = FakeClient()
    # Trace claims A's pubkey but is signed by other_kp — verify must fail.
    bad_trace = _real_signed_trace_for_kp(other_kp).model_copy(
        update={"signer_pubkey": kp_a.verify_key_hex}
    )
    fake_a.set_next_response(
        "publish",
        PublishedTrace(
            trace_id=bad_trace.trace_id, signed=True, error_signature=bad_trace.error_signature
        ),
    )
    fake_b.set_next_response(
        "search",
        SearchResults(
            results=[
                SearchResult(
                    trace_id=bad_trace.trace_id,
                    error_signature=bad_trace.error_signature,
                    error_class=bad_trace.error_class,
                    outcome=Outcome.RESOLVED,
                    signed=True,
                    created_at=0,
                    preview="x",
                    counters=Counters(),
                )
            ],
            count=1,
            match_mode=MatchMode.FILTER,
        ),
    )
    fake_b.set_next_response(
        "get", TraceDetail(trace=bad_trace, amendments=[], counters=Counters())
    )

    results = run_closure(
        fake_a,  # type: ignore[arg-type]
        fake_b,  # type: ignore[arg-type]
        signing_key_a=kp_a,
        signing_key_b=kp_b,
        agent_a_id="agent-a-id",
        agent_b_id="agent-b-id",
        n_trials=1,
    )
    trial = results.trials[0]
    assert trial.outcome == "verify_failed"
    assert trial.signature_verified is False
    # Feedback must NOT have been issued after verify failure.
    assert len(fake_b.calls_for("feedback")) == 0


def test_run_closure_counter_timeout(monkeypatch: Any) -> None:
    """Feedback succeeds but A's get never sees helped++ → counter_timeout."""
    _patch_short_polls(monkeypatch)
    kp_a = SigningKeyPair.generate()
    kp_b = SigningKeyPair.generate()
    fake_a = FakeClient()
    fake_b = FakeClient()
    real_trace = _wire_success_trial(fake_a=fake_a, fake_b=fake_b, kp_a=kp_a)
    # Override A's get response to one with helped still 0 — never advances.
    fake_a.reset()
    fake_a.set_next_response(
        "publish",
        PublishedTrace(
            trace_id=real_trace.trace_id, signed=True, error_signature=real_trace.error_signature
        ),
    )

    results = run_closure(
        fake_a,  # type: ignore[arg-type]
        fake_b,  # type: ignore[arg-type]
        signing_key_a=kp_a,
        signing_key_b=kp_b,
        agent_a_id="agent-a-id",
        agent_b_id="agent-b-id",
        n_trials=1,
    )
    trial = results.trials[0]
    assert trial.outcome == "counter_timeout"
    assert trial.feedback_published is True
    assert trial.signature_verified is True


# ---------------------------------------------------------------------------
# Aggregation math
# ---------------------------------------------------------------------------


def test_percentile_basics() -> None:
    """Linear-interpolation percentile across small samples."""
    assert _percentile([10, 20, 30, 40, 50], 50) == 30.0
    assert _percentile([10, 20, 30, 40, 50], 100) == 50.0
    assert _percentile([10, 20, 30, 40, 50], 0) == 10.0
    assert _percentile([], 95) == 0.0
    assert _percentile([42], 95) == 42.0


def test_aggregation_mixed_outcomes(monkeypatch: Any) -> None:
    """3 trials: 2 success, 1 publish_failed → closure_rate=2/3, sigverify_rate=1.0."""
    _patch_short_polls(monkeypatch)
    kp_a = SigningKeyPair.generate()
    kp_b = SigningKeyPair.generate()
    fake_a = FakeClient()
    fake_b = FakeClient()
    # Wire one full success → one publish-fail → one full success.
    _wire_success_trial(fake_a=fake_a, fake_b=fake_b, kp_a=kp_a)
    fake_a.set_next_exception("publish", RuntimeError("transient"))
    _wire_success_trial(fake_a=fake_a, fake_b=fake_b, kp_a=kp_a)

    results = run_closure(
        fake_a,  # type: ignore[arg-type]
        fake_b,  # type: ignore[arg-type]
        signing_key_a=kp_a,
        signing_key_b=kp_b,
        agent_a_id="agent-a-id",
        agent_b_id="agent-b-id",
        n_trials=3,
    )
    assert results.closure_rate == 2 / 3
    # Two successful sigverifies, zero attempts on the publish-failed
    # trial. Rate = 2 / 2 = 1.0.
    assert results.signature_verification_rate == 1.0
    # Two feedbacks attempted (both succeeded), one trial skipped feedback.
    assert results.feedback_acceptance_rate == 1.0


# ---------------------------------------------------------------------------
# write_results
# ---------------------------------------------------------------------------


def test_write_results_round_trip(tmp_path: Path) -> None:
    """write_results emits valid JSON matching the dataclass shape."""
    trial = TrialResult(
        trial_index=0,
        trial_uuid="t-uuid",
        agent_a_id="a",
        agent_b_id="b",
        trace_id="tid",
        signed=True,
        signature_verified=True,
        feedback_published=True,
        counter_updated=True,
        outcome="success",
        duration_ms=1234,
        phases_ms={
            "publish": 10,
            "propagate": 100,
            "search": 50,
            "fetch": 20,
            "verify": 1,
            "feedback": 30,
            "counter_confirm": 1000,
        },
        error=None,
    )
    results = ClosureResults(
        version="1",
        timestamp_utc="2026-04-26T00:00:00+00:00",
        sdk_version="0.1.3",
        base_url="http://fake.test",
        n_trials=1,
        run_uuid="r-uuid",
        agent_a_id="a",
        agent_b_id="b",
        closure_rate=1.0,
        signature_verification_rate=1.0,
        feedback_acceptance_rate=1.0,
        time_to_closure_ms={
            "mean": 1234.0,
            "median": 1234.0,
            "p95": 1234.0,
            "p99": 1234.0,
            "min": 1234.0,
            "max": 1234.0,
        },
        trials=[trial],
    )
    out_path = tmp_path / "closure.json"
    write_results(results, out_path)

    raw = json.loads(out_path.read_text(encoding="utf-8"))
    assert raw["version"] == "1"
    assert raw["closure_rate"] == 1.0
    assert raw["base_url"] == "http://fake.test"
    assert len(raw["trials"]) == 1
    assert raw["trials"][0]["outcome"] == "success"
    assert raw["trials"][0]["phases_ms"]["publish"] == 10
