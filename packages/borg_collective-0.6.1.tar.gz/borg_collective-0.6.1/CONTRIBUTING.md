# Contributing

Thanks for your interest in contributing. This SDK ships with a strict
quality bar — please read this file before opening a PR.

## Development setup

```bash
git clone https://github.com/borg-farther/borg-collective-py.git
cd borg-collective-py
uv venv
source .venv/bin/activate
uv pip install -e ".[dev,cli]"
```

## Pre-commit checks

All four must pass before a PR is reviewable:

```bash
ruff format --check .
ruff check .
mypy
pytest
```

`pytest -m integration` runs against the live Worker; it is **not**
required in CI by default, but contributors who change transport or
signing code should run it before opening a PR.

## Coding rules

1. **Hex-only encoding for all key material.** Every pubkey, signature,
   API key, and hash on the wire is lowercase hex (`^[0-9a-f]{64}$` for
   32-byte values, `^[0-9a-f]{128}$` for 64-byte signatures). No
   alternate encodings — see the forbidden-token regex in
   `.github/workflows/ci.yml` for the canonical list. The pre-merge gate
   greps `src/`, `tests/`, `examples/`, and `docs/` for that regex and
   must return zero matches (fixtures that explicitly test rejection
   live elsewhere).
2. **Wire contract is sacred.** Canonical form is locked by
   `tests/fixtures/canonical-v1.json`. Don't change canonicalization
   without a coordinated v2 server release.
3. **Strict typing.** `mypy --strict` clean. New public API must have
   complete type annotations. Internal helpers must have annotations
   on all parameters and return types.
4. **No new runtime dependencies without discussion.** `httpx`,
   `pydantic`, `pynacl` are the runtime trio; everything else lives
   under `[cli]` or `[dev]`.
5. **Tests-first for new endpoints.** Every endpoint wrapper lands
   with a respx-mocked happy path, validation failure, and at least
   one error-status-code branch.

## Pull-request checklist

- [ ] `ruff format --check . && ruff check .` clean
- [ ] `mypy` clean
- [ ] `pytest` green (unit; integration optional)
- [ ] CHANGELOG.md updated under `[Unreleased]`
- [ ] Public API changes reflected in `src/borg_collective/__init__.pyi`
- [ ] Hex-firewall grep returns zero matches

## Releasing

Maintainer-only. See `.github/workflows/release.yml` (currently
disabled — PyPI Trusted Publishing setup happens before the first
release is cut).
