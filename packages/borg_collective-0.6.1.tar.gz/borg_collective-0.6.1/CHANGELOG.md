# Changelog

All notable changes to this project are recorded here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); versions follow
[SemVer](https://semver.org/spec/v2.0.0.html).

## [0.6.1] — 2026-04-30

L4 — cold-start awareness in `suggest_traces`. The federation just
shipped a `cold_start: true` flag on search results that have no usage
feedback yet (the alpha-1 corpus is brand new — every trace looks "score
0" on day one, which reads as "tested and rejected" without context).
The MCP layer now propagates that flag through to the suggestion shape
and adds an inline summary so the LLM consuming the response interprets
score=null correctly.

### Changed
- `suggest_traces` response: each suggestion gains `cold_start: bool`
  and `usage_count: int` (helped + didnt_help + applied). Cold-start
  suggestions report `score: None` instead of a numeric score that
  reads as "rejected" when in fact no one has tested the fix yet.
- When any suggestion is cold-start, the response payload adds
  `cold_start_results`, `total_results`, and a human-readable `note`
  the LLM surfaces inline: "(N of M results are newly seeded — no
  usage data yet. Score=null on those means 'untested', not
  'rejected'. Apply the fix and call report_outcome to feed back.)"

### Why
The honest signal beats the misleading numeric. A primary skimming
suggest_traces results today sees "score: 0" on every result and reads
the corpus as broken. After 0.6.1 the same primary sees "score: null
+ cold_start: true" with a note explaining it's brand-new content,
not bad content. Day-one experience improves without the corpus
needing to mature.

## [0.6.0] — 2026-04-30

L3 alpha-launch — MCP tool description audit + rewrite. The single
highest-leverage change before primaries onboard tomorrow morning: if
the LLM in their Cursor/Claude/Cline doesn't WANT to call `suggest_traces`
on every error, none of the rest matters. Descriptions now lead with
explicit when-to-use and when-NOT-to-use guidance, frame the tool as
"check Borg before debugging" rather than "Borg has features," and give
the LLM concrete positive/negative examples for the `task` parameter so
it learns to extract identifying tokens (error class, library, version)
rather than passing vague restatements.

### Changed
- `suggest_traces` description rewritten with CALL THIS BEFORE / USE
  PROACTIVELY framing, typical-trigger checklist, explicit SKIP-for
  list, and a note about how `no_relevant_results: true` invites the
  publish-after-fix flow.
- `record_failure` description rewritten with the typical workflow
  sequence (suggest_traces → fix → record_failure), the quality gate
  rules inline, and a "don't pad with filler" admonition for
  rejected publishes.
- `task` parameter description gains good/bad examples showing the
  shape of identifying tokens to include.
- `limit` parameter description shifts from "default 3" boilerplate
  to actionable guidance ("top-1 is usually the answer").

### Bumped
- Package version 0.5.1 → 0.6.0. Tool-description rewrites change LLM
  tool-selection behavior — treated as a feature change, not a patch.

### Tagged
- `v0.6.0-rc1` pushed to origin. PyPI publish deferred to tomorrow
  morning manual; F7 stays open until then.

## [0.5.1] — 2026-04-28

Phase E1.4 — MCP tool description engineering. Front-loads concrete
trigger phrases (Python ModuleNotFoundError, npm install errors,
Docker build failures, MCP config errors, post-cutoff library APIs,
etc.) so an agent reading the tool list sees an obvious lexical match
between user-pasted error text and the tool's stated purpose. Closes
the Outcome-B autonomy gap observed in prior session: Claude
answered ModuleNotFoundError from training rather than calling
suggest_traces.

### Changed

- `suggest_traces` description rewritten with bulleted concrete
  triggers up-front; explicit "does NOT need to be called for"
  list at the end.
- Companion eval harness lives in `borg-collective-v1/eval/` and
  measures TCR/TCP autonomy improvement and top-1 relevance.

## [0.5.0] — 2026-04-28

Phase E0.7 — local→federation bridge + `borg review` + demo step 4.

### Added

- `borg_collective._bridge` module exposing `AutoPublishConfig`,
  `PublishResult`, `DrainResult`, `load_auto_publish_config`,
  `publish_to_federation`, `drain_queue`. The bridge is what the
  Hermes plugin calls from `on_session_end` after the local SQLite
  save, when the inferred outcome is FAILURE. Visibility is forced
  to `private` regardless of input — promotion to public requires a
  user-initiated `borg review promote`.
- `borg review` CLI command group with five subcommands:
  - `borg review list` — paginated table of recent traces (default
    filter: `--visibility=private`)
  - `borg review show <id>` — full trace + parent if any
  - `borg review promote <id> [--yes]` — flips private → public
    after a confirmation prompt that displays the visible content
  - `borg review delete <id> [--yes]` — soft delete (`deleted_at`)
  - `borg review edit <id>` — opens `$EDITOR` on the trace JSON;
    diffs and PATCHes any changes on save
- `Client.list_my_traces`, `Client.update_trace`, `Client.delete_trace`
  for programmatic review.
- `parent_trace_id` field on `FailureTrace` and `Trace`. Used by
  `borg demo` step 4 (publish-back loop), `borg review show`
  (parent surfacing), and any future follow-up flow.
- `borg demo` step 4 publishes a follow-up `FailureTrace` with
  `parent_trace_id=matched.trace_id`, `outcome=resolved`,
  `visibility=private`. The demo now closes the loop end-to-end.
- Plugin federation bridge is documented at `docs/PLUGIN_BRIDGE.md`;
  promotion workflow at `docs/REVIEW_WORKFLOW.md`.

### Changed

- The borg_auto_trace plugin (at `~/.hermes/plugins/borg_auto_trace/`)
  now POSTs FAILURE captures to the federation as private, after the
  existing local SQLite save. Local-first: the federation publish
  cannot lose the trace if the network is down — failures route to
  `~/.borg/publish_queue.jsonl`, drained by `borg drain`. **Note:**
  the plugin's federation hook fires from `on_session_end` (after
  3+ tool calls in a session) on FAILURE outcomes — there is no
  discrete `on_failure` hook; one was never part of the Hermes plugin
  API. **The plugin source was reconstructed from `__init__.cpython-311.pyc`
  during this session** (no decompiler exists for Python 3.11; we
  used `dis.dis` + line-numbered disassembly). The reconstruction
  preserves the public hook surface (`pre_llm_call`, `pre_tool_call`,
  `post_tool_call`, `on_session_end`, `register`) and the observable
  behaviour. The `_borg_sdk_patch` (anthropic SDK monkey-patch) is a
  no-op stub pending Phase E1 review of whether SDK-level guidance
  injection is the right home for that feature.
- New config section `[plugin.auto_trace]` in `~/.borg/config.toml`
  with `auto_publish` key (`"false"` / `"prompt"` / `"private"` /
  `"review"`); default `prompt`.

### Migrations

- `0005_parent_trace.sql` — `parent_trace_id TEXT` (nullable) on
  `failure_traces`. Indexed.
- `0006_soft_delete.sql` — `deleted_at INTEGER` (nullable unix
  timestamp). Partial index on NOT NULL rows. `/api/v1/search` and
  `/api/v1/stats` filter `WHERE deleted_at IS NULL`. Owner can still
  GET a soft-deleted trace during the grace period; non-owners 404.

### Worker

- `GET /api/v1/agents/me/traces?visibility=&limit=&before=` lists the
  caller's own traces, newest-first, with backwards pagination via
  `created_at` cursor. Soft-deleted rows are excluded.
- `PATCH /api/v1/traces/:id` — owner-only field updates plus
  visibility flip. Promote (private → public) requires
  `?force_public=true`.
- `DELETE /api/v1/traces/:id` — owner-only soft delete; idempotent.

## [0.4.0] — 2026-04-27

Phase E0.6 — provenance attribution round-trip.

### Added

- `Provenance` enum (`organic` / `curated` / `test`) re-exported from
  the top-level package. Mirrors the Worker's CHECK constraint at
  migration 0004.
- `FailureTrace` carries optional `provenance` / `source_url` /
  `license` fields. Default `provenance=None` lets the Worker's
  DB DEFAULT `'organic'` apply on insert; set `Provenance.CURATED`
  explicitly for seed-corpus ingest.
- `Trace` (the read-side model) carries the same three fields. Default
  `provenance=Provenance.ORGANIC` covers legacy rows that round-trip
  without an explicit value on the wire.

### Changed

- `scripts/ingest_seed_corpus.py` now publishes via `Client.publish`.
  The earlier raw-httpx bypass that split attribution out before
  validation is gone — the SDK carries every needed field natively.
- `borg demo` reads the matched trace's provenance from the live
  response (`detail.trace.provenance.value`) and renders it as
  `(curated)` or `(organic)`. Previously the label was hardcoded.
  Closes `friction_journal/2026-Q2-demo-curated-label-hardcoded.md`.
- `_closure._SERVER_ADDED_FIELDS` now strips `provenance`,
  `source_url`, `license` before recomputing canonical bytes for
  signature verification — these are server-materialised on read
  and were not part of the original signed body.

## [0.3.0] — 2026-04-27

Phase E0.5 — `borg demo` value-loop showcase.

### Added

- `borg demo` subcommand: 90-second end-to-end demonstration of the
  Borg federation loop. Simulates an agent failure (Hermes MCP
  python-vs-python3 on Ubuntu 24.04), performs a real
  `/api/v1/search` call against the live federation, surfaces the
  matched fix from the curated corpus. No canned response strings —
  the fix text is whatever the federation returns. Total wall clock
  is typically 2-3 seconds; the lookup itself is sub-second.

  This is the demo a new SDK user runs immediately after `borg init`
  to see what Borg actually does for an agent.

## [0.2.0] — 2026-04-27

Phase E0.5 — alpha-1 safety floor.

### BREAKING

- `Client.publish()` now requires `force_public=True` to publish a
  trace whose `visibility` is `Visibility.PUBLIC`. Default is
  `force_public=False`. A trace constructed with the default
  `Visibility.PRIVATE` continues to publish unchanged.
  This guards against accidental public publication of stack traces
  that may carry proprietary code, paths, or business logic — the
  safety floor for the alpha-1 federation.
- Migration: every site that intentionally publishes a public trace
  must add `force_public=True` to the `client.publish(...)` call.
  Recipes shipped in v0.1.4 use `visibility="private"` and are
  unaffected.

### Added

- `borg init` is idempotent in the strong sense: a second run without
  `--force` surfaces the existing `agent_id`, prints "Use --force to
  re-register (creates new agent_id).", and exits 0. With `--force`
  alone, prompts for confirmation; with `--force --yes` (CI path)
  overwrites without prompt.
- Welcome banner on first registration. Six lines, displayed only on
  fresh registrations (not on idempotent re-runs, not on `--json`).
  Surfaces the PRIVATE-by-default contract and the `force_public=True`
  opt-in path before the user constructs their first trace.
- `borg publish --force-public` flag mirrors the SDK signature so a
  user with a `visibility="public"` trace JSON can opt in at the CLI.

### Changed

- `_print_welcome_banner(agent_id)` is the canonical six-line banner;
  exposed as a module-private helper inside `borg_collective.cli`.

## [0.1.4] — 2026-04-27

### Added

- Phase C recipes shipped (`claude-cli`, `hermes` integration recipes for
  the failure-trace federation). First PyPI publish of `borg-collective`.
  No SDK behavior changes from 0.1.3 — this release is the version-bumped
  wheel that will land on PyPI alongside the recipes.

## [0.1.3] — 2026-04-26

### Added

- `tests/integration/test_closure.py`: closure-rate test, the v1
  done-gate. Two cached agents A and B, N trials of
  sign → publish → propagate → search → fetch → verify → feedback →
  counter-confirm, threshold 95%. Excluded from default `pytest -x`;
  runs only on `pytest -m closure` or `BORG_CLOSURE_TEST=1 pytest`.
- `src/borg_collective/_closure.py`: shared logic between the
  integration test and the CLI subcommand. Signature verification
  reconstructs the canonical bytes A signed by stripping the four
  server-added fields (`trace_id`, `agent_id`, `signed`, `created_at`)
  before recomputing.
- `borg closure-test` CLI subcommand: `--trials N`, `--output FILE`,
  `--base-url URL`, `--verbose`. Exit code 0 if closure_rate >= 95%,
  1 if below, 2 on infrastructure error.
- `.github/workflows/closure.yml`: daily 06:00 UTC heartbeat against
  the live federation, 90-day artifact retention. Does NOT block PRs.
- `docs/closure-test.md`: rigorous spec for the closure test, its
  methodology, JSON schema, and the v1 done-gate invariant.
- `tests/integration/closure_results.json`: first-run results,
  committed for transparency. Replaces no prior file.
- `closure` pytest marker registered in `pyproject.toml`. The
  rootdir conftest skips it unless `BORG_CLOSURE_TEST=1` or
  `-m closure` is explicit, mirroring the existing `integration`
  marker idiom.

### Notes — closure test results (first measured run, 2026-04-26)

Against `borg-collective-v1.borg-farther.workers.dev` from a
single-region runner:

- N trials: 20
- run_uuid: `e8a913d0-a9b6-45ec-a0c5-cf783bde1e43`
- **closure_rate: 100%** (20/20)
- median time-to-closure: 759 ms
- p95: 851 ms · p99: 871 ms · min: 729 ms · max: 876 ms
- signature_verification_rate: 100%
- feedback_acceptance_rate: 100%

The artifact (`tests/integration/closure_results.json`) records
`sdk_version: "0.1.2"` because the live run executed before the
0.1.3 version-constant bump (per spec ordering: live run, then
bump). The closure-test code in this commit is unchanged between
the run and the release; the recorded version is honest about what
binary executed at measurement time.

These numbers will be re-measured against the production domain at
v1.0 ship. The spec invariant (closure_rate >= 95%) is locked in
`docs/closure-test.md` §10.

## [0.1.2] — 2026-04-26

### Fixed

- SDK `__version__` constant aligned to release tag. v0.1.0 and v0.1.1
  both shipped with `__version__ = "0.1.0"` due to a missed bump on
  the v0.1.1 docs-only retag; v0.1.2 corrects this in
  `_version.py`, `pyproject.toml`, and the `tests/test_smoke.py`
  assertion.
- `examples/05_hermes_adapter.py`: removed an unused `noqa: BLE001`
  directive that ruff 0.5.5+ flags as RUF100. The except block was
  already exempt from BLE001 (re-raises at end of block); the noqa
  was dead code carried forward from an earlier ruff version.

### Notes — federation corpus state

v0.1.0 and v0.1.1 ran against a development federation
(`borg-collective-v1.borg-farther.workers.dev`) populated with CI
fixture traces from integration test runs. The corpus is not a
representation of real-world failure traces and should not be read as
such by external consumers. v1.0 will ship against a fresh corpus on a
stable production domain (currently provisioning a custom Cloudflare
Workers domain — final URL announced in v1.0). The wire contract,
signing primitives, and SDK behaviour are stable across versions; only
the back-end data is in flux.

## [0.1.0] — 2026-04-25

Initial release. Wraps the Borg Collective v1 Worker
(`https://borg-collective-v1.borg-farther.workers.dev`). Five gates green;
460 unit tests + 16 live-Worker integration tests pass.

### Added

- **Sync `Client` and async `AsyncClient`** with the full v1 method
  surface: `register_agent`, `whoami`, `rotate_pubkey`, `publish`, `get`,
  `add_amendment`, `search`, `feedback`, `drain`. `Client.from_config()`
  and `AsyncClient.from_config()` factories read `BORG_API_KEY` /
  `~/.borg/config.toml` so scripts don't have to plumb credentials.
- **Wire models** (Pydantic v2): `FailureTrace`, `PublishedTrace`,
  `Trace`, `TraceDetail`, `Amendment`, `AmendmentInput`,
  `AmendmentCreated`, `SearchRequest`, `SearchResult`, `SearchResults`,
  `FeedbackRequest`, `FeedbackAck`, `Counters`, `Agent`, `AgentInfo`,
  `AgentPubkey`. `extra="forbid"` on inputs (typos die locally),
  `extra="allow"` on responses (forward-compat reads). Funnel
  monotonicity enforced before the network in `FeedbackRequest`.
- **Ed25519 signing** via PyNaCl, **lowercase-hex I/O** end-to-end —
  no base64 anywhere in the SDK. Canonical-form module byte-identical to
  the Worker's `canonical.ts`, locked by a shared fixture.
  `error_signature` normalisation is identical to the Worker's
  `error-signature.ts`.
- **Offline queue** (`OfflineQueue`) — SQLite-WAL persistent FIFO.
  `Client(offline_mode=True)` always enqueues; `Client(offline_queue_path=…)`
  on a regular online client enqueues as a fallback when the Worker is
  unreachable. `Client.drain()` returns a `DrainReport`
  (drained / deferred / failed / stopped_early). Subclassed
  `OfflineQueueFull` raised at `max_size` cap.
- **Public testing module** (`borg_collective.testing.FakeClient` /
  `FakeAsyncClient`) — drop-in replacements for tests that consume the
  SDK; record calls, queue responses, no HTTP. `ClientLike` /
  `AsyncClientLike` runtime-checkable Protocols for static-typed
  consumer code.
- **`borg` CLI** (Click + Rich, core deps): `init`, `register`,
  `whoami`, `publish`, `get`, `search`, `feedback`, `amend`, `drain`,
  `version`. `--json` on every command. Config at
  `~/.borg/config.toml` (mode 0600); keypairs at
  `~/.borg/keys/<agent_id>.hex` (mode 0600); api_keys masked to first
  8 chars on every output path. Exit codes:
  `0` success, `1` user error, `2` network/auth, `3` server error.
- **Typed exception hierarchy** with actionable `__str__`: `BorgError`,
  `AuthError`, `ValidationError`, `SignatureError` (with
  canonical-form-drift hint), `RateLimitError`, `NetworkError`,
  `ServerError`, `ConfigError`, `OfflineError`, `OfflineQueueFull`.
- **Examples** (`examples/01..06`): publish unsigned, publish signed,
  search + get, feedback funnel, Hermes adapter pattern, offline drain.
  Each runs to exit 0 against `FakeClient` with no env vars.
- **Cookbook**: real Hermes adapter integration; skeletons for Claude
  Code MCP and Cursor that document the integration shape.
- **mkdocs-material docs site** with `mkdocstrings` API reference.
- MIT license.

### Notes — known limitations in v0.1.0

The release is honest about what is and isn't here.

- **`whoami` requires Worker route added 2026-04-25.** The CLI and SDK
  call `GET /api/v1/agents/me`. The federation Worker has shipped this
  route (commit `8058e15` on `borg-collective-v1`); older Worker forks
  without it will return 404 for `whoami` and the CLI's `borg whoami`
  command. Pin to a Worker at or after that revision.
- **Pubkey rotation works but enrolment-at-register is the recommended
  path.** `Client.register_agent(pubkey=...)` writes the pubkey in one
  request; `Client.rotate_pubkey()` works but burns an extra API call
  per agent setup.
- **Trust level is always `"soft"` in v0.1.0.** The Worker hardcodes
  `trust_level='soft'` on every `INSERT` into `agents`. The
  `TrustLevel.HARD` enum value exists in the SDK as forward-compat for
  the proof-gate sandbox (spec §5.1), but no Worker today returns it.
- **Closure test (two-agent, one-trace) is not yet automated.** The
  spec §3.3 token-overlap closure test runs manually as part of the
  v0.1.0 done-gate. The SDK ships the primitives (publish, search by
  signature, feedback) needed to mechanise it; a Day-10 harness lands
  in a follow-up release.
- **Amendments are unsigned by design (v1, spec §2 #7).** `signature` /
  `signer_pubkey` on `AmendmentInput` are rejected locally with a
  v2-feature message; the Worker also returns `400 amendments_signing_v2`.
- **Rate-limit auto-retry is NOT in v0.1.0.** The SDK surfaces
  `RateLimitError` with `retry_after_s` + `bucket`; the caller decides
  whether to sleep + retry. This is deliberate — the publish bucket is
  per-agent and the auth-fail bucket is per-IP, so generic auto-sleep
  would back off the wrong key.

### Wire contract

The SDK targets v1 of the wire spec (`/api/v1`). Canonicalisation,
`error_signature` normalisation, and signature verification are locked
by spec §1.1 and the `canonical-v1` fixture; changing them is a
v3-level decision.

### Upgrade pin

Worker compatibility: `borg-collective-v1` `>= 8058e15` (the
`GET /agents/me` route landing). Earlier Worker forks lose `whoami` —
the rest of the surface still works.
