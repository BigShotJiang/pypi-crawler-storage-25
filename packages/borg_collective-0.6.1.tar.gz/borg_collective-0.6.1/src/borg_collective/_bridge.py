"""E0.7 federation bridge — local-capture → federation publish path.

The Hermes plugin (``~/.hermes/plugins/borg_auto_trace/``) captures
every multi-tool session locally to ``~/.borg/traces.db``. Until E0.7
those captures never reached the federation. This module is the bridge:

  capture in plugin -> save to local SQLite -> if FAILURE,
  ``publish_to_federation`` POSTs as ``visibility=private`` -> the user
  reviews via ``borg review`` and promotes to public when ready.

Public API (re-exported from the package root):

* :class:`AutoPublishConfig` — opt-in config from
  ``~/.borg/config.toml [plugin.auto_trace]``.
* :class:`PublishResult` — the structured outcome of one publish attempt.
* :class:`DrainResult` — the structured outcome of one ``drain_queue`` call.
* :func:`load_auto_publish_config` — TOML loader, defaults to ``mode="prompt"``.
* :func:`publish_to_federation` — best-effort POST with dead-letter fallback.
* :func:`drain_queue` — atomic line-by-line drain of the dead-letter queue.

Two safety floors live here:

1. ``visibility`` is FORCED to ``private`` regardless of what the caller
   passes. The bridge is for silent capture; promotion to ``public``
   requires a user-initiated ``borg review promote``.
2. Network/HTTP/timeout errors NEVER raise — they always route to the
   dead-letter queue at ``~/.borg/publish_queue.jsonl``. The plugin
   layer cannot afford to bubble exceptions out of an on_session_end
   hook because Hermes sees that as a plugin failure.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from borg_collective.exceptions import BorgError, NetworkError
from borg_collective.models import FailureTrace, Visibility

__all__ = [
    "AutoPublishConfig",
    "DrainResult",
    "PublishResult",
    "drain_queue",
    "load_auto_publish_config",
    "publish_to_federation",
]

# ---------------------------------------------------------------------------
# Result shapes
# ---------------------------------------------------------------------------

AutoPublishMode = Literal["false", "prompt", "private", "review"]
_VALID_MODES: frozenset[str] = frozenset({"false", "prompt", "private", "review"})


@dataclass(frozen=True)
class AutoPublishConfig:
    """User-facing config from ``[plugin.auto_trace]`` in ``~/.borg/config.toml``.

    ``mode`` is one of:

    * ``"false"`` — the bridge is disabled. Local SQLite only. Legacy
      pre-E0.7 behaviour.
    * ``"prompt"`` — POST as private; print a one-line stderr note on
      capture so the user knows it happened. Default.
    * ``"private"`` — POST as private silently.
    * ``"review"`` — POST as private and tag with ``needs_review``.
    """

    mode: AutoPublishMode = "prompt"


@dataclass(frozen=True)
class PublishResult:
    """Outcome of one ``publish_to_federation`` call.

    Exactly one of ``published`` and ``queued`` is True; both are False
    only when ``mode="false"`` (the bridge is disabled).
    """

    published: bool = False
    trace_id: str | None = None
    queued: bool = False
    error: str | None = None


@dataclass(frozen=True)
class DrainResult:
    """Outcome of one ``drain_queue`` call.

    ``total`` is the queue depth at start. ``published`` is the count
    that drained successfully. ``still_queued`` is what remained
    (failed publishes; the file still contains them).
    """

    total: int = 0
    published: int = 0
    still_queued: int = 0


# ---------------------------------------------------------------------------
# Config loader
# ---------------------------------------------------------------------------


def load_auto_publish_config(config_path: Path) -> AutoPublishConfig:
    """Read ``[plugin.auto_trace]`` from ``~/.borg/config.toml``.

    Default ``mode="prompt"`` if the file is missing, the section is
    missing, or ``auto_publish`` is unset. Invalid mode values raise
    ``ValueError`` with a clear message.
    """
    if not config_path.exists():
        return AutoPublishConfig()
    try:
        import tomllib  # py3.11+
    except ImportError:  # pragma: no cover — fallback for 3.10 install
        import tomli as tomllib  # type: ignore[import-not-found]
    with config_path.open("rb") as fh:
        data = tomllib.load(fh)
    section = data.get("plugin", {}).get("auto_trace", {})
    raw_mode = section.get("auto_publish", "prompt")
    if raw_mode not in _VALID_MODES:
        msg = (
            f"[plugin.auto_trace] auto_publish must be one of "
            f"{sorted(_VALID_MODES)!r}; got {raw_mode!r}"
        )
        raise ValueError(msg)
    return AutoPublishConfig(mode=raw_mode)


# ---------------------------------------------------------------------------
# Dead-letter queue
# ---------------------------------------------------------------------------

_DEFAULT_QUEUE_PATH = Path.home() / ".borg" / "publish_queue.jsonl"


def _append_to_queue(queue_path: Path, body: dict) -> None:
    """Append one JSON line to the dead-letter queue. Creates parents."""
    queue_path.parent.mkdir(parents=True, exist_ok=True)
    with queue_path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(body, separators=(",", ":")) + "\n")


# ---------------------------------------------------------------------------
# publish_to_federation
# ---------------------------------------------------------------------------


def publish_to_federation(
    *,
    trace_dict: dict,
    config: AutoPublishConfig,
    api_key: str,
    base_url: str,
    queue_path: Path | None = None,
) -> PublishResult:
    """Publish a captured trace to the federation as PRIVATE.

    Behaviour matrix:

    * ``config.mode == "false"`` → no-op, returns
      ``PublishResult(published=False, queued=False)``.
    * Any other mode → validates ``trace_dict`` against
      :class:`FailureTrace`, FORCES ``visibility=private``, attempts
      POST via :class:`borg_collective.Client`. On success returns
      ``PublishResult(published=True, trace_id=...)``. On
      ``NetworkError`` or any other failure, appends the wire body to
      the dead-letter queue and returns
      ``PublishResult(queued=True, error=str(exc))``.

    The ``review`` mode appends a ``needs_review`` tag before publish so
    ``borg review list`` can highlight it.

    NEVER raises. The plugin path that calls this cannot afford
    exceptions.
    """
    qpath = queue_path or _DEFAULT_QUEUE_PATH

    if config.mode == "false":
        return PublishResult(published=False, queued=False)

    # Validate + force PRIVATE. The Worker would reject a PUBLIC publish
    # from this path anyway (visibility is owner-set), but defense-in-depth
    # — never let an auto-capture leak.
    try:
        ft = FailureTrace.model_validate(trace_dict)
    except Exception as exc:  # pydantic ValidationError + anything else
        # If the trace can't validate, queueing it would just produce a
        # 400 on drain. Surface as queued=False, error set, so the
        # caller can decide whether to drop or fix-and-retry.
        return PublishResult(
            published=False,
            queued=False,
            error=f"validation: {exc}",
        )

    if config.mode == "review":
        ft = ft.model_copy(update={"tags": [*ft.tags, "needs_review"]})

    # Force PRIVATE regardless of what the caller passed.
    ft = ft.model_copy(update={"visibility": Visibility.PRIVATE})

    # Build the wire body via the SDK's normal publish path so the
    # bridge benefits from every guard FailureTrace.model_dump applies.
    from borg_collective import Client  # local import: keep top-level light

    try:
        with Client(api_key=api_key, base_url=base_url) as c:
            published = c.publish(ft)
    except NetworkError as exc:
        body = ft.model_dump(exclude_none=True, mode="json")
        _append_to_queue(qpath, body)
        return PublishResult(published=False, queued=True, error=str(exc))
    except BorgError as exc:
        # 4xx / 5xx — queue for drain too. Some of these are transient
        # (5xx) and worth retrying; some (4xx) are permanent and the
        # user will spot them on drain. Erring on the side of "don't
        # lose the trace."
        body = ft.model_dump(exclude_none=True, mode="json")
        _append_to_queue(qpath, body)
        return PublishResult(published=False, queued=True, error=str(exc))
    except Exception as exc:  # noqa: BLE001 — the plugin path must never raise
        body = ft.model_dump(exclude_none=True, mode="json")
        _append_to_queue(qpath, body)
        return PublishResult(published=False, queued=True, error=str(exc))

    return PublishResult(published=True, trace_id=published.trace_id)


# ---------------------------------------------------------------------------
# drain_queue
# ---------------------------------------------------------------------------


def drain_queue(
    *,
    api_key: str,
    base_url: str,
    queue_path: Path | None = None,
) -> DrainResult:
    """Drain the dead-letter queue at ``~/.borg/publish_queue.jsonl``.

    Reads every line, attempts POST, removes successes from the file,
    keeps failures. Atomic on success: writes the surviving lines to a
    sibling tempfile and renames in place.
    """
    qpath = queue_path or _DEFAULT_QUEUE_PATH
    if not qpath.exists():
        return DrainResult(total=0, published=0, still_queued=0)

    lines = [
        line for line in qpath.read_text(encoding="utf-8").splitlines() if line.strip()
    ]
    total = len(lines)
    if total == 0:
        return DrainResult(total=0, published=0, still_queued=0)

    survivors: list[str] = []
    published = 0

    from borg_collective import Client  # local import

    with Client(api_key=api_key, base_url=base_url) as c:
        for line in lines:
            try:
                body = json.loads(line)
                ft = FailureTrace.model_validate(body)
                # Force PRIVATE on drain too — defense in depth.
                ft = ft.model_copy(update={"visibility": Visibility.PRIVATE})
                c.publish(ft)
                published += 1
            except (NetworkError, BorgError):
                survivors.append(line)
            except Exception:  # noqa: BLE001
                survivors.append(line)

    if survivors:
        # Rewrite atomically: tempfile + rename.
        tmp = qpath.with_suffix(qpath.suffix + ".tmp")
        tmp.write_text("\n".join(survivors) + "\n", encoding="utf-8")
        tmp.replace(qpath)
    else:
        qpath.unlink()

    return DrainResult(
        total=total,
        published=published,
        still_queued=len(survivors),
    )
