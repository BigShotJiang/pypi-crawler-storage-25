"""HTTP transport layer for the Borg Collective SDK.

Internal module — public API is :mod:`borg_collective.client`. This
module owns the contract between the SDK and the live Worker:

* HTTPS to ``https://borg-collective-v1.borg-farther.workers.dev`` by
  default (override via ``base_url``).
* ``X-API-Key: <api_key>`` for every authenticated request. Header name
  is verified against the Worker's auth middleware
  (``borg-collective-v1/src/middleware/auth.ts`` constant ``HEADER``).
* Worker error envelopes parsed into the typed exceptions in
  :mod:`borg_collective.exceptions`. The Worker's envelope shape is
  ``{"error": "<code>", ...extras, "request_id": "..."}``; there is
  no central ``message`` field, so the SDK synthesises a human message
  from the ``error`` code when needed.
* Retry on transient failures (connection errors, read timeouts, 502,
  503, 504): up to three attempts total with 0.5s / 1.5s backoff.
* Auth-required calls fail fast with :class:`ConfigError` when no
  api_key is configured — the request never leaves the SDK.

Sync and async are exposed as two separate classes
(:class:`Transport`, :class:`AsyncTransport`) rather than one
mixed-mode class. Two classes keep the typed surface clean — every
public method's return type is unambiguous about whether it is
awaitable, mypy can check that without overload heroics, and tests
can pin one path without pulling in an event loop they do not need.

Both classes share the same retry policy, status→exception mapping,
header logic, and logging via the helpers below; only the call into
``httpx.Client.send`` / ``httpx.AsyncClient.send`` differs.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Final, Self

import httpx

from ._version import __version__
from .exceptions import (
    AuthError,
    ConfigError,
    NetworkError,
    RateLimitError,
    ServerError,
    SignatureError,
    ValidationError,
)

__all__ = [
    "AUTH_HEADER",
    "DEFAULT_BACKOFF_BASE_S",
    "DEFAULT_BASE_URL",
    "DEFAULT_MAX_RETRIES",
    "DEFAULT_TIMEOUT",
    "USER_AGENT",
    "AsyncTransport",
    "Transport",
]

logger = logging.getLogger("borg_collective.transport")

DEFAULT_BASE_URL: Final[str] = "https://borg-collective-v1.borg-farther.workers.dev"

# Auth header name — verified against the Worker
# (borg-collective-v1/src/middleware/auth.ts: const HEADER = 'X-API-Key').
AUTH_HEADER: Final[str] = "X-API-Key"

USER_AGENT: Final[str] = f"borg-collective-py/{__version__}"

# Spec defaults: connect=5s, read=30s, total budget covered by httpx Timeout
# (write/pool default to read for parity).
DEFAULT_TIMEOUT: Final[httpx.Timeout] = httpx.Timeout(
    connect=5.0,
    read=30.0,
    write=30.0,
    pool=30.0,
)

DEFAULT_MAX_RETRIES: Final[int] = 3
DEFAULT_BACKOFF_BASE_S: Final[float] = 0.5

# 502/503/504 are the transient HTTP statuses the SDK retries.
# 408 maps to NetworkError but is NOT retried (spec contract).
_RETRYABLE_STATUSES: Final[frozenset[int]] = frozenset({502, 503, 504})

# Outcomes from response classification. Sentinels (str) keep tuples
# self-describing without bringing in a tiny Enum.
_SUCCESS: Final[str] = "success"
_RAISE: Final[str] = "raise"
_RETRY: Final[str] = "retry"


# ---------------------------------------------------------------------------
# Helpers — pure functions, shared by sync and async.
# ---------------------------------------------------------------------------


def _parse_error_envelope(
    response: httpx.Response,
) -> tuple[str | None, str, dict[str, Any]]:
    """Extract ``(error_code, message, details)`` from a Worker error response.

    Worker error envelopes follow the shape::

        {"error": "<code>", ...extras, "request_id": "<id>"}

    There is no ``message`` field in the Worker contract; we synthesise
    one from the ``error`` code so the exception's ``__str__`` is still
    informative. ``details`` is the rest of the body (everything except
    ``error``, ``message`` if present, and ``request_id``).

    On a non-JSON body, ``error_code`` is ``None`` and ``message`` is
    the first 200 chars of the raw text — enough to identify the
    failure without flooding logs with HTML error pages.
    """
    try:
        data = response.json()
    except (ValueError, httpx.DecodingError):
        raw = response.text
        return None, raw[:200], {}
    if not isinstance(data, dict):
        return None, str(data)[:200], {}

    error_code_raw = data.get("error")
    error_code = error_code_raw if isinstance(error_code_raw, str) else None
    message_raw = data.get("message")
    message = (
        message_raw
        if isinstance(message_raw, str) and message_raw
        else (error_code or f"HTTP {response.status_code}")
    )

    details = {k: v for k, v in data.items() if k not in {"error", "message", "request_id"}}
    return error_code, message, details


def _parse_retry_after(
    response: httpx.Response,
    details: dict[str, Any],
) -> int:
    """Parse ``Retry-After`` (seconds) from a 429 response.

    Worker emits ``Retry-After`` as an integer-seconds string. If the
    header is absent or unparseable, fall back to the body's
    ``retry_after_s`` field. Last resort: ``0`` (caller policy).

    The HTTP spec also allows ``Retry-After: <HTTP-date>`` but Worker
    never emits that form; we surface it as 0 with a warning rather
    than dragging in a date parser.
    """
    header = response.headers.get("Retry-After")
    if header is not None:
        try:
            return max(0, int(header.strip()))
        except ValueError:
            logger.warning(
                "retry_after_unparseable",
                extra={"header_value": header},
            )

    body_value = details.get("retry_after_s")
    if isinstance(body_value, int):
        return max(0, body_value)
    if isinstance(body_value, float):
        return max(0, int(body_value))

    return 0


def _classify_2xx(response: httpx.Response) -> tuple[str, Any]:
    """Decode a 2xx response body. Pulled out of :func:`_classify_response`
    so that function's branch count stays inside ruff's PLR0912 limit."""
    status = response.status_code
    if not response.content:
        return _SUCCESS, {}
    try:
        body = response.json()
    except (ValueError, httpx.DecodingError):
        # 2xx with non-JSON body shouldn't happen on this Worker; if it
        # does, surface as ServerError rather than silently returning a
        # string and confusing the caller's typed flow.
        return _RAISE, ServerError(
            f"non-JSON 2xx body (status={status})",
            status=status,
            error_code=None,
        )
    if not isinstance(body, dict):
        return _RAISE, ServerError(
            f"non-object 2xx body (status={status})",
            status=status,
            error_code=None,
        )
    return _SUCCESS, body


def _classify_429(
    response: httpx.Response,
    message: str,
    details: dict[str, Any],
) -> tuple[str, Any]:
    """Build a RateLimitError from a 429 response."""
    retry_after_s = _parse_retry_after(response, details)
    # Worker emits the bucket name in the JSON body (not as an
    # X-RateLimit-Bucket header — that header isn't part of the Worker
    # contract). Read body first; fall back to header for forward-compat
    # with any header convention added later; final fallback is "unknown".
    bucket_raw = details.get("bucket")
    if isinstance(bucket_raw, str) and bucket_raw:
        bucket = bucket_raw
    else:
        bucket = response.headers.get("X-RateLimit-Bucket") or "unknown"
    return _RAISE, RateLimitError(
        message,
        retry_after_s=retry_after_s,
        bucket=bucket,
        status=429,
    )


def _classify_response(response: httpx.Response) -> tuple[str, Any]:  # noqa: PLR0911, C901
    """Map an httpx.Response to one of three outcomes.

    Returns one of:

    * ``(_SUCCESS, parsed_body)`` — 2xx; body parsed as JSON
      (or ``{}`` for empty bodies).
    * ``(_RAISE, exception)``     — permanent failure, raise immediately.
    * ``(_RETRY, exception)``     — transient failure (502/503/504);
      caller retries and only raises ``exception`` if the retry budget
      is exhausted.

    PLR0911 noqa: the function is a flat dispatch over HTTP status
    classes (2xx / 401-403 / 400 / 422 / 429 / 408 / 502-504 / 5xx /
    other). One ``return`` per branch is the clearest layout — collapsing
    to a dict-of-handlers would add indirection without saving lines.
    """
    status = response.status_code
    if 200 <= status < 300:
        return _classify_2xx(response)

    error_code, message, details = _parse_error_envelope(response)

    if status in {401, 403}:
        return _RAISE, AuthError(message, status=status, error_code=error_code)
    if status == 400:
        return _RAISE, ValidationError(message, status=400, error_code=error_code, details=details)
    if status == 404:
        # Worker uses 404 for trace lookups that don't resolve (real
        # absence, or private-by-non-owner — see spec §7 Open Q5). The
        # request was well-formed; surface as ValidationError so callers
        # can branch on error_code == "not_found" or "trace_not_found".
        return _RAISE, ValidationError(message, status=404, error_code=error_code, details=details)
    if status == 422:
        if error_code == "bad_signature":
            return _RAISE, SignatureError(
                message=message or "signature did not verify",
                status=422,
                error_code="bad_signature",
                details=details,
            )
        return _RAISE, ValidationError(message, status=422, error_code=error_code, details=details)
    if status == 429:
        return _classify_429(response, message, details)
    if status == 408:
        # Map to NetworkError per spec. NOT retried — only the explicit
        # transient set (502/503/504 + httpx transport exceptions) is.
        return _RAISE, NetworkError(message or "request timeout", cause=None)
    if status in _RETRYABLE_STATUSES:
        return _RETRY, ServerError(message, status=status, error_code=error_code)
    if 500 <= status < 600:
        return _RAISE, ServerError(message, status=status, error_code=error_code)

    # Unexpected status (e.g. a 3xx that follow_redirects didn't resolve,
    # or any other non-listed status). Surface as ServerError so the
    # caller still gets typed access to status/error_code.
    return _RAISE, ServerError(
        f"unexpected HTTP status {status}",
        status=status,
        error_code=error_code,
    )


def _backoff_delay(retry_index: int, base_s: float) -> float:
    """Return the seconds to sleep before retry number ``retry_index`` (0-based).

    Spec calls for 0.5s then 1.5s — a base*3**n geometric series with
    ``base=0.5``. ``retry_index=0`` → 0.5, ``retry_index=1`` → 1.5,
    ``retry_index=2`` → 4.5 (only relevant if a caller sets
    ``max_retries`` higher than the default 3).
    """
    return base_s * (3.0**retry_index)


# ---------------------------------------------------------------------------
# Base class — shared init, request building, repr.
# ---------------------------------------------------------------------------


class _BaseTransport:
    """Shared state and behaviour for sync and async transports.

    Holds configuration but not the underlying httpx client — sync vs
    async subclasses pick the right client type. Public methods on the
    subclasses (``request`` / ``request`` async) call back into the
    helpers above, which are pure and stateless.
    """

    def __init__(
        self,
        *,
        api_key: str | None,
        base_url: str,
        timeout: httpx.Timeout,
        max_retries: int,
        backoff_base_s: float,
    ) -> None:
        if max_retries < 1:
            msg = "max_retries must be >= 1"
            raise ValueError(msg)
        if backoff_base_s < 0:
            msg = "backoff_base_s must be >= 0"
            raise ValueError(msg)
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._backoff_base_s = backoff_base_s

    def __repr__(self) -> str:
        # NEVER include api_key, even truncated. The hex firewall is
        # binary; this is the last line of defence if a key somehow
        # ended up here.
        return (
            f"{type(self).__name__}("
            f"base_url={self._base_url!r}, "
            f"max_retries={self._max_retries}, "
            f"backoff_base_s={self._backoff_base_s}, "
            f"api_key={'set' if self._api_key else 'unset'})"
        )

    def _build_request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None,
        headers: dict[str, str] | None,
        auth_required: bool,
    ) -> httpx.Request:
        """Build the httpx.Request, validating auth config up front.

        Raises :class:`ConfigError` synchronously when the call needs an
        api_key and none is configured — the request never leaves the
        SDK, so the Worker doesn't see a guaranteed-401 from us.
        """
        if auth_required and not self._api_key:
            msg = (
                "api_key required for "
                f"{method.upper()} {path} but Transport was constructed without one"
            )
            raise ConfigError(msg)

        url = f"{self._base_url}{path}" if path.startswith("/") else f"{self._base_url}/{path}"

        merged_headers: dict[str, str] = {
            "User-Agent": USER_AGENT,
            "Accept": "application/json",
        }
        if json is not None:
            merged_headers["Content-Type"] = "application/json"
        if self._api_key:
            merged_headers[AUTH_HEADER] = self._api_key
        if headers:
            for k, v in headers.items():
                # Caller-supplied headers can override defaults — but
                # we never let them clear the api_key by passing the
                # header with an empty value.
                if k.lower() == AUTH_HEADER.lower() and not v:
                    continue
                merged_headers[k] = v

        # Construct via httpx's API so JSON encoding is consistent with
        # what the Worker expects (UTF-8, no whitespace, no BOM).
        return httpx.Request(method, url, json=json, headers=merged_headers)

    @staticmethod
    def _is_retryable_transport_exc(exc: BaseException) -> bool:
        """True iff ``exc`` represents a transient transport-layer failure.

        Covers connect errors, read/write/connect timeouts, network
        errors, and remote protocol errors. We deliberately don't
        retry InvalidURL/UnsupportedProtocol/CookieConflict — those
        are caller bugs, not transient.
        """
        return isinstance(
            exc,
            httpx.ConnectError
            | httpx.ConnectTimeout
            | httpx.ReadTimeout
            | httpx.WriteTimeout
            | httpx.PoolTimeout
            | httpx.ReadError
            | httpx.WriteError
            | httpx.NetworkError
            | httpx.RemoteProtocolError,
        )


# ---------------------------------------------------------------------------
# Sync transport.
# ---------------------------------------------------------------------------


class Transport(_BaseTransport):
    """Synchronous HTTP transport against the Borg Collective Worker.

    Hold one Transport per process where possible — the underlying
    ``httpx.Client`` keeps a connection pool. Closes via ``close()`` or
    a ``with`` block.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: httpx.Timeout = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        backoff_base_s: float = DEFAULT_BACKOFF_BASE_S,
        client: httpx.Client | None = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            backoff_base_s=backoff_base_s,
        )
        self._client = client if client is not None else httpx.Client(timeout=timeout)
        self._owns_client = client is None

    def close(self) -> None:
        """Close the underlying client, if owned by this Transport."""
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        headers: dict[str, str] | None = None,
        auth_required: bool = True,
    ) -> dict[str, Any]:
        """Execute a single request, applying retry + status mapping.

        Returns the parsed JSON response body on success. Raises one of
        the typed exceptions in :mod:`borg_collective.exceptions` on
        any failure — the caller never gets a raw httpx exception.
        """
        request = self._build_request(
            method,
            path,
            json=json,
            headers=headers,
            auth_required=auth_required,
        )

        # DEBUG: method+path only. NEVER log the body — bodies may
        # contain api_keys (from /agents responses) or signed traces.
        logger.debug(
            "transport_request",
            extra={"method": request.method, "path": path},
        )

        last_exc: BaseException | None = None
        for attempt in range(self._max_retries):
            response: httpx.Response | None = None
            try:
                response = self._client.send(request)
            except httpx.TransportError as exc:
                if not self._is_retryable_transport_exc(exc):
                    raise NetworkError(
                        str(exc) or type(exc).__name__,
                        cause=exc,
                    ) from exc
                last_exc = NetworkError(
                    str(exc) or type(exc).__name__,
                    cause=exc,
                )
                if attempt < self._max_retries - 1:
                    time.sleep(_backoff_delay(attempt, self._backoff_base_s))
                    continue
                raise last_exc from exc
            except httpx.RequestError as exc:
                # Non-transport RequestError (InvalidURL, etc.). Not
                # retryable; surface as NetworkError so the caller has
                # one exception type to catch for "didn't reach Worker".
                raise NetworkError(
                    str(exc) or type(exc).__name__,
                    cause=exc,
                ) from exc

            decision, payload = _classify_response(response)
            if decision == _SUCCESS:
                return payload  # type: ignore[no-any-return]
            if decision == _RETRY:
                logger.warning(
                    "transport_retry",
                    extra={
                        "method": request.method,
                        "path": path,
                        "status": response.status_code,
                        "attempt": attempt + 1,
                    },
                )
                last_exc = payload
                if attempt < self._max_retries - 1:
                    time.sleep(_backoff_delay(attempt, self._backoff_base_s))
                    continue
                raise payload
            # Permanent failure path: log and raise immediately.
            logger.warning(
                "transport_failure",
                extra={
                    "method": request.method,
                    "path": path,
                    "status": response.status_code,
                    "exc_type": type(payload).__name__,
                },
            )
            raise payload

        # Loop falls out only via early-return or raise; this is for
        # completeness so type checkers see every path covered.
        if last_exc is not None:
            raise last_exc
        msg = "transport request loop exited without raising or returning"
        raise RuntimeError(msg)  # pragma: no cover


# ---------------------------------------------------------------------------
# Async transport.
# ---------------------------------------------------------------------------


class AsyncTransport(_BaseTransport):
    """Asynchronous HTTP transport against the Borg Collective Worker.

    Mirrors :class:`Transport` exactly in semantics — same status
    mapping, same retry policy, same exception types, same logging.
    Only the underlying client is async.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: httpx.Timeout = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        backoff_base_s: float = DEFAULT_BACKOFF_BASE_S,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            backoff_base_s=backoff_base_s,
        )
        self._client = client if client is not None else httpx.AsyncClient(timeout=timeout)
        self._owns_client = client is None

    async def aclose(self) -> None:
        """Close the underlying async client, if owned by this Transport."""
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.aclose()

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        headers: dict[str, str] | None = None,
        auth_required: bool = True,
    ) -> dict[str, Any]:
        """Async counterpart of :meth:`Transport.request`."""
        request = self._build_request(
            method,
            path,
            json=json,
            headers=headers,
            auth_required=auth_required,
        )

        logger.debug(
            "transport_request",
            extra={"method": request.method, "path": path},
        )

        last_exc: BaseException | None = None
        for attempt in range(self._max_retries):
            response: httpx.Response | None = None
            try:
                response = await self._client.send(request)
            except httpx.TransportError as exc:
                if not self._is_retryable_transport_exc(exc):
                    raise NetworkError(
                        str(exc) or type(exc).__name__,
                        cause=exc,
                    ) from exc
                last_exc = NetworkError(
                    str(exc) or type(exc).__name__,
                    cause=exc,
                )
                if attempt < self._max_retries - 1:
                    await asyncio.sleep(_backoff_delay(attempt, self._backoff_base_s))
                    continue
                raise last_exc from exc
            except httpx.RequestError as exc:
                raise NetworkError(
                    str(exc) or type(exc).__name__,
                    cause=exc,
                ) from exc

            decision, payload = _classify_response(response)
            if decision == _SUCCESS:
                return payload  # type: ignore[no-any-return]
            if decision == _RETRY:
                logger.warning(
                    "transport_retry",
                    extra={
                        "method": request.method,
                        "path": path,
                        "status": response.status_code,
                        "attempt": attempt + 1,
                    },
                )
                last_exc = payload
                if attempt < self._max_retries - 1:
                    await asyncio.sleep(_backoff_delay(attempt, self._backoff_base_s))
                    continue
                raise payload
            logger.warning(
                "transport_failure",
                extra={
                    "method": request.method,
                    "path": path,
                    "status": response.status_code,
                    "exc_type": type(payload).__name__,
                },
            )
            raise payload

        if last_exc is not None:
            raise last_exc
        msg = "transport request loop exited without raising or returning"
        raise RuntimeError(msg)  # pragma: no cover
