"""Closure-rate measurement — the v1 done-gate logic.

Closure tests one assertion: a signed failure trace published by agent A
round-trips through the federation and visibly affects agent B's view
within a bounded time window. This module is the shared brain behind
both the integration test (``tests/integration/test_closure.py``) and
the ``borg closure-test`` CLI subcommand. They differ only in their
caller surface; the trial logic, the timing harness, and the result
schema live here.

Per-trial flow (one closure trial — the unit of measurement)
------------------------------------------------------------

1. A signs and publishes a trace tagged with a per-trial unique
   ``error_class``. The Worker assigns ``trace_id``.
2. B polls ``POST /search`` filtered by that ``error_class`` until the
   trace surfaces (D1 propagation latency).
3. B fetches the full trace via ``GET /traces/:id``.
4. B verifies A's Ed25519 signature locally — canonical bytes must be
   reconstructed from the fetched trace minus the four server-added
   fields (``trace_id``, ``agent_id``, ``signed``, ``created_at``)
   that were not present when A signed. ``signature`` and
   ``signer_pubkey`` are dropped by the canonical form itself.
5. B reports HELPED feedback on the trace.
6. A polls ``GET /traces/:id`` until ``counters.helped`` reaches
   ``initial_helped + 1``, confirming the bidirectional signal landed.

A trial is ``"success"`` only when all six steps complete; any phase
failure or timeout produces a non-success outcome and downstream
phases are skipped. The aggregate ``ClosureResults`` over N trials is
the headline number — closure_rate >= 0.95 is the v1 ship gate (see
``docs/closure-test.md``).

Pubkey availability
-------------------

v0.1.3 verifies signatures against locally-known pubkeys. The closure
fixture caches both A's and B's :class:`SigningKeyPair` instances, so
A's verify-key hex is available without round-tripping the Worker.
A future SDK release that adds a public ``get_agent(id)`` method will
allow Worker-side pubkey lookup for arbitrary agents; the schema
field ``signature_verification_rate`` is already shaped for that
extension.
"""

from __future__ import annotations

import json
import statistics
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Final, Literal

from borg_collective._signing import verify_trace
from borg_collective._version import __version__
from borg_collective.models import (
    FailureTrace,
    FeedbackOutcome,
    Outcome,
    Trace,
    Visibility,
)

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from borg_collective._signing import SigningKeyPair
    from borg_collective.client import Client

__all__ = [
    "ClosureResults",
    "TrialResult",
    "run_closure",
    "write_results",
]

# Schema version of the closure_results.json artifact. Bump on any
# breaking change to the on-disk shape so consumers (CI alerting,
# trend dashboards) can branch safely.
_SCHEMA_VERSION: Final[Literal["1"]] = "1"

# Phase budgets — match the documented thresholds in docs/closure-test.md.
# Search-propagation budget tracks the existing integration suite's
# tolerance (5 s); counter-confirm doubles it because feedback writes
# go through a separate Worker counter-rollup path.
_SEARCH_POLL_INTERVAL_S: Final[float] = 0.2
_SEARCH_POLL_TIMEOUT_S: Final[float] = 5.0
_COUNTER_POLL_INTERVAL_S: Final[float] = 0.5
_COUNTER_POLL_TIMEOUT_S: Final[float] = 10.0

# Server-added fields on a fetched ``Trace`` that were NOT in the body
# A signed. Stripping these before recomputing canonical bytes is what
# makes signature verification possible against a round-tripped trace.
# ``signature`` / ``signer_pubkey`` are dropped by the canonical form
# itself (see _canonical.canonical_bytes_for_trace) and so are not
# re-listed here.
_SERVER_ADDED_FIELDS: Final[frozenset[str]] = frozenset(
    {
        "trace_id",
        "agent_id",
        "signed",
        "created_at",
        # E0.6: provenance fields are server-side too — the wire body
        # at signing time may have omitted them (None → exclude_none),
        # but the read-side Trace materializes provenance="organic" as
        # the DB default. Strip before recomputing canonical bytes.
        "provenance",
        "source_url",
        "license",
    }
)


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------

# Single source of truth for the trial outcome vocabulary. Consumers
# parsing closure_results.json branch on these strings; bump
# _SCHEMA_VERSION if the set ever changes.
TrialOutcome = Literal[
    "success",
    "publish_failed",
    "search_timeout",
    "fetch_failed",
    "verify_failed",
    "feedback_failed",
    "counter_timeout",
    "exception",
]


@dataclass(frozen=True)
class TrialResult:
    """Outcome of a single closure trial.

    ``signed`` records whether A's publish was signed (always ``True``
    in this harness — closure asserts the signed federation path).
    ``signature_verified`` is ``True`` iff B's local verification of
    A's signature succeeded; ``None`` when the trial did not reach the
    verify phase. ``feedback_published`` and ``counter_updated`` mirror
    the two halves of the feedback loop — feedback was POSTed, and the
    counter increment was confirmed via A's poll.

    ``phases_ms`` carries seven non-cumulative measurements:

    ============== ================================================
    publish        A's POST /traces wall time
    propagate      Wall clock from publish-done to first search hit
                   (sleeps + search HTTP calls)
    search         Cumulative HTTP time of search calls (subset of
                   propagate; useful for diagnosing high latency)
    fetch          B's GET /traces/:id wall time
    verify         Local Ed25519 verification wall time
    feedback       B's POST /feedback wall time
    counter_confirm Wall clock from feedback-done to A's get()
                   sees helped >= initial+1
    ============== ================================================

    ``duration_ms`` is wall-clock total of the trial (T_start to
    T_done) — not the sum of phases, because ``search`` overlaps
    ``propagate`` and the sleep/HTTP partitioning is informational.
    """

    trial_index: int
    trial_uuid: str
    agent_a_id: str
    agent_b_id: str
    trace_id: str | None
    signed: bool
    signature_verified: bool | None
    feedback_published: bool
    counter_updated: bool
    outcome: TrialOutcome
    duration_ms: int
    phases_ms: dict[str, int]
    error: str | None


@dataclass(frozen=True)
class ClosureResults:
    """Aggregate results of one closure run.

    The full ``trials`` list is preserved so failure-mode analysis
    after the fact does not require re-running. Aggregates
    (``closure_rate``, ``time_to_closure_ms``, etc.) are computed only
    over trials whose outcome is ``"success"`` — a failed trial's
    timing is meaningless for latency baselining.

    Schema is versioned by ``version: "1"`` so consumers (CI alerting,
    dashboards) can branch on a future v2 shape without ambiguity.
    """

    version: Literal["1"]
    timestamp_utc: str
    sdk_version: str
    base_url: str
    n_trials: int
    run_uuid: str
    agent_a_id: str
    agent_b_id: str
    closure_rate: float
    signature_verification_rate: float | None
    feedback_acceptance_rate: float
    time_to_closure_ms: dict[str, float]
    trials: list[TrialResult] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def run_closure(
    client_a: Client,
    client_b: Client,
    *,
    signing_key_a: SigningKeyPair,
    signing_key_b: SigningKeyPair,  # noqa: ARG001  reserved for future B-signed traces
    agent_a_id: str,
    agent_b_id: str,
    n_trials: int = 20,
    progress_cb: Callable[[int, int, TrialResult], None] | None = None,
    base_url: str | None = None,
) -> ClosureResults:
    """Run ``n_trials`` closure trials and return aggregated results.

    Synchronous and sequential: trial ``i+1`` does not start until
    trial ``i`` returns. Concurrency would muddy the per-trial latency
    metrics and is not the v1 question — closure measures the unit
    behavior, not the parallel one.

    ``client_a`` and ``client_b`` must already be authenticated and
    have their pubkeys enrolled with the Worker (signed publish
    requires the pubkey to be known server-side; see
    ``Client.rotate_pubkey``). The fixture or CLI caller is
    responsible for that setup — it is not idempotent and we do not
    want to repeat it ``n_trials`` times.

    ``progress_cb`` is invoked once per trial after the trial
    completes, with ``(trial_index, n_trials, trial_result)``. Used
    by the CLI to drive a Rich progress bar; tests pass ``None``.

    ``base_url`` is recorded in the result artifact for provenance.
    Pass the same URL the clients are configured against (the SDK
    does not expose it on the Client surface; the caller knows it).
    """
    if n_trials < 1:
        msg = f"n_trials must be >= 1, got {n_trials}"
        raise ValueError(msg)

    run_uuid = str(uuid.uuid4())
    trials: list[TrialResult] = []
    for i in range(n_trials):
        trial = _run_one_trial(
            client_a=client_a,
            client_b=client_b,
            signing_key_a=signing_key_a,
            agent_a_id=agent_a_id,
            agent_b_id=agent_b_id,
            run_uuid=run_uuid,
            trial_index=i,
            n_trials=n_trials,
        )
        trials.append(trial)
        if progress_cb is not None:
            progress_cb(i, n_trials, trial)

    return _aggregate(
        trials=trials,
        run_uuid=run_uuid,
        agent_a_id=agent_a_id,
        agent_b_id=agent_b_id,
        base_url=base_url or "(unknown)",
    )


def write_results(results: ClosureResults, path: Path) -> None:
    """Write ``results`` to ``path`` as pretty-printed JSON.

    ``path`` is overwritten if it exists. The on-disk shape mirrors
    :class:`ClosureResults` 1:1 via :func:`dataclasses.asdict`.
    """
    payload = asdict(results)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# Trial machinery
# ---------------------------------------------------------------------------


def _run_one_trial(  # noqa: C901, PLR0911, PLR0912, PLR0915
    *,
    client_a: Client,
    client_b: Client,
    signing_key_a: SigningKeyPair,
    agent_a_id: str,
    agent_b_id: str,
    run_uuid: str,
    trial_index: int,
    n_trials: int,
) -> TrialResult:
    # The trial logic is a linear six-step pipeline (publish → search →
    # fetch → verify → feedback → counter-confirm). Splitting it into
    # helpers obscures the timing harness — every step measures phase_ms
    # against the shared monotonic clock, and the early-return failure
    # handling is per-step in the caller's frame. The complexity warnings
    # are intentional and the function is exercised by tests/test_closure_unit.py.
    trial_uuid = str(uuid.uuid4())
    error_class = f"ClosureTestError_{run_uuid[:8]}_{trial_uuid[:8]}"
    error_text = (
        f"Closure test trial {trial_index + 1} of {n_trials}, "
        f"run {run_uuid}, trial {trial_uuid}"
    )

    phases: dict[str, int] = {
        "publish": 0,
        "propagate": 0,
        "search": 0,
        "fetch": 0,
        "verify": 0,
        "feedback": 0,
        "counter_confirm": 0,
    }
    t_start = time.monotonic_ns()

    # ---- 1. A publishes a signed trace -----------------------------------
    try:
        ft = FailureTrace(
            error_class=error_class,
            error_text=error_text,
            task_description=f"closure test trial {trial_index + 1}",
            approach_summary="closure test",
            root_cause="closure test",
            outcome=Outcome.RESOLVED,
            tags=["closure-test", run_uuid[:8]],
            visibility=Visibility.PUBLIC,
        )
        t_pub_start = time.monotonic_ns()
        published = client_a.publish(ft, signing_key=signing_key_a)
        t_pub_done = time.monotonic_ns()
        phases["publish"] = (t_pub_done - t_pub_start) // 1_000_000
    except Exception as exc:  # noqa: BLE001  classify all failures uniformly
        return _trial_failure(
            trial_index=trial_index,
            trial_uuid=trial_uuid,
            agent_a_id=agent_a_id,
            agent_b_id=agent_b_id,
            trace_id=None,
            outcome="publish_failed",
            phases=phases,
            t_start=t_start,
            error=f"{type(exc).__name__}: {exc}",
        )

    if not published.signed:
        # Worker accepted the trace but did not mark it signed. Treat
        # as publish failure — closure cannot verify an unsigned trace.
        return _trial_failure(
            trial_index=trial_index,
            trial_uuid=trial_uuid,
            agent_a_id=agent_a_id,
            agent_b_id=agent_b_id,
            trace_id=published.trace_id,
            outcome="publish_failed",
            phases=phases,
            t_start=t_start,
            error="publish accepted but signed=false",
        )

    # ---- 2. B polls search until the trace surfaces ----------------------
    t_search_start = time.monotonic_ns()
    deadline_ns = t_search_start + int(_SEARCH_POLL_TIMEOUT_S * 1_000_000_000)
    search_http_ms = 0
    search_hit_trace_id: str | None = None
    while time.monotonic_ns() < deadline_ns:
        t_one = time.monotonic_ns()
        try:
            results = client_b.search(error_class=error_class, limit=10)
        except Exception:  # noqa: BLE001  treat any search failure as miss
            search_http_ms += (time.monotonic_ns() - t_one) // 1_000_000
            time.sleep(_SEARCH_POLL_INTERVAL_S)
            continue
        search_http_ms += (time.monotonic_ns() - t_one) // 1_000_000
        for r in results.results:
            if r.trace_id == published.trace_id:
                search_hit_trace_id = r.trace_id
                break
        if search_hit_trace_id is not None:
            break
        time.sleep(_SEARCH_POLL_INTERVAL_S)

    phases["propagate"] = (time.monotonic_ns() - t_search_start) // 1_000_000
    phases["search"] = search_http_ms

    if search_hit_trace_id is None:
        return _trial_failure(
            trial_index=trial_index,
            trial_uuid=trial_uuid,
            agent_a_id=agent_a_id,
            agent_b_id=agent_b_id,
            trace_id=published.trace_id,
            outcome="search_timeout",
            phases=phases,
            t_start=t_start,
            error=f"trace_id {published.trace_id} not found in search "
            f"by error_class within {_SEARCH_POLL_TIMEOUT_S}s",
        )

    # ---- 3. B fetches the full trace -------------------------------------
    try:
        t_fetch_start = time.monotonic_ns()
        detail = client_b.get(search_hit_trace_id)
        t_fetch_done = time.monotonic_ns()
        phases["fetch"] = (t_fetch_done - t_fetch_start) // 1_000_000
    except Exception as exc:  # noqa: BLE001
        return _trial_failure(
            trial_index=trial_index,
            trial_uuid=trial_uuid,
            agent_a_id=agent_a_id,
            agent_b_id=agent_b_id,
            trace_id=search_hit_trace_id,
            outcome="fetch_failed",
            phases=phases,
            t_start=t_start,
            error=f"{type(exc).__name__}: {exc}",
        )

    # ---- 4. B verifies A's signature locally ----------------------------
    t_verify_start = time.monotonic_ns()
    sig_ok = _verify_signature(
        trace=detail.trace,
        expected_pubkey=signing_key_a.verify_key_hex,
    )
    phases["verify"] = (time.monotonic_ns() - t_verify_start) // 1_000_000
    if not sig_ok:
        return _trial_failure(
            trial_index=trial_index,
            trial_uuid=trial_uuid,
            agent_a_id=agent_a_id,
            agent_b_id=agent_b_id,
            trace_id=search_hit_trace_id,
            outcome="verify_failed",
            phases=phases,
            t_start=t_start,
            signature_verified=False,
            error="signature verification failed against locally-known A pubkey",
        )

    # ---- 5. B publishes feedback -----------------------------------------
    try:
        t_fb_start = time.monotonic_ns()
        ack = client_b.feedback(
            search_hit_trace_id,
            retrieved=True,
            read=True,
            applied=True,
            outcome=FeedbackOutcome.HELPED,
        )
        t_fb_done = time.monotonic_ns()
        phases["feedback"] = (t_fb_done - t_fb_start) // 1_000_000
        if not ack.recorded or not ack.counters_updated:
            return _trial_failure(
                trial_index=trial_index,
                trial_uuid=trial_uuid,
                agent_a_id=agent_a_id,
                agent_b_id=agent_b_id,
                trace_id=search_hit_trace_id,
                outcome="feedback_failed",
                phases=phases,
                t_start=t_start,
                signature_verified=True,
                error=f"feedback ack: recorded={ack.recorded} "
                f"counters_updated={ack.counters_updated}",
            )
    except Exception as exc:  # noqa: BLE001
        return _trial_failure(
            trial_index=trial_index,
            trial_uuid=trial_uuid,
            agent_a_id=agent_a_id,
            agent_b_id=agent_b_id,
            trace_id=search_hit_trace_id,
            outcome="feedback_failed",
            phases=phases,
            t_start=t_start,
            signature_verified=True,
            error=f"{type(exc).__name__}: {exc}",
        )

    # ---- 6. A confirms the helped counter incremented --------------------
    initial_helped = detail.counters.helped  # B's get already bumped retrieved; helped untouched
    t_cc_start = time.monotonic_ns()
    deadline_ns = t_cc_start + int(_COUNTER_POLL_TIMEOUT_S * 1_000_000_000)
    counter_confirmed = False
    while time.monotonic_ns() < deadline_ns:
        try:
            a_view = client_a.get(search_hit_trace_id)
        except Exception:  # noqa: BLE001  treat as transient miss
            time.sleep(_COUNTER_POLL_INTERVAL_S)
            continue
        if a_view.counters.helped >= initial_helped + 1:
            counter_confirmed = True
            break
        time.sleep(_COUNTER_POLL_INTERVAL_S)
    phases["counter_confirm"] = (time.monotonic_ns() - t_cc_start) // 1_000_000

    if not counter_confirmed:
        return _trial_failure(
            trial_index=trial_index,
            trial_uuid=trial_uuid,
            agent_a_id=agent_a_id,
            agent_b_id=agent_b_id,
            trace_id=search_hit_trace_id,
            outcome="counter_timeout",
            phases=phases,
            t_start=t_start,
            signature_verified=True,
            feedback_published=True,
            error=f"helped counter did not reach {initial_helped + 1} "
            f"within {_COUNTER_POLL_TIMEOUT_S}s",
        )

    duration_ms = (time.monotonic_ns() - t_start) // 1_000_000
    return TrialResult(
        trial_index=trial_index,
        trial_uuid=trial_uuid,
        agent_a_id=agent_a_id,
        agent_b_id=agent_b_id,
        trace_id=search_hit_trace_id,
        signed=True,
        signature_verified=True,
        feedback_published=True,
        counter_updated=True,
        outcome="success",
        duration_ms=duration_ms,
        phases_ms=phases,
        error=None,
    )


def _verify_signature(trace: Trace, expected_pubkey: str) -> bool:
    """Verify ``trace.signature`` against the canonical body, with the
    server-added fields stripped.

    A signed the wire body before the Worker assigned ``trace_id``,
    ``agent_id``, ``signed``, and ``created_at``. To recompute the
    canonical bytes A signed, we must remove those four fields.
    ``signature`` and ``signer_pubkey`` are removed by
    :func:`canonical_bytes_for_trace` itself.

    Returns ``False`` (never raises) when the trace is unsigned, the
    signature is malformed, or the pubkey on the trace disagrees with
    ``expected_pubkey``. The defensive predicate matches the Worker's
    ``verifySignature`` contract.
    """
    if trace.signature is None or trace.signer_pubkey is None:
        return False
    if trace.signer_pubkey != expected_pubkey:
        # Trace was signed by a different key than we expected for A.
        # This is a verification failure even if the bytes would
        # otherwise pass with the on-trace pubkey.
        return False
    body = trace.model_dump(mode="json", exclude_none=True)
    for k in _SERVER_ADDED_FIELDS:
        body.pop(k, None)
    return verify_trace(expected_pubkey, body, trace.signature)


def _trial_failure(
    *,
    trial_index: int,
    trial_uuid: str,
    agent_a_id: str,
    agent_b_id: str,
    trace_id: str | None,
    outcome: TrialOutcome,
    phases: dict[str, int],
    t_start: int,
    error: str,
    signature_verified: bool | None = None,
    feedback_published: bool = False,
) -> TrialResult:
    return TrialResult(
        trial_index=trial_index,
        trial_uuid=trial_uuid,
        agent_a_id=agent_a_id,
        agent_b_id=agent_b_id,
        trace_id=trace_id,
        signed=outcome != "publish_failed",
        signature_verified=signature_verified,
        feedback_published=feedback_published,
        counter_updated=False,
        outcome=outcome,
        duration_ms=(time.monotonic_ns() - t_start) // 1_000_000,
        phases_ms=phases,
        error=error,
    )


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------


def _aggregate(
    *,
    trials: list[TrialResult],
    run_uuid: str,
    agent_a_id: str,
    agent_b_id: str,
    base_url: str,
) -> ClosureResults:
    n = len(trials)
    successes = [t for t in trials if t.outcome == "success"]

    closure_rate = len(successes) / n if n else 0.0

    sigverify_attempted = [t for t in trials if t.signature_verified is not None]
    sigverify_success = [t for t in sigverify_attempted if t.signature_verified]
    sigverify_rate: float | None = (
        len(sigverify_success) / len(sigverify_attempted) if sigverify_attempted else None
    )

    fb_attempted = [
        t
        for t in trials
        if t.outcome not in {"publish_failed", "search_timeout", "fetch_failed", "verify_failed"}
    ]
    fb_success = [t for t in fb_attempted if t.feedback_published]
    fb_rate = len(fb_success) / len(fb_attempted) if fb_attempted else 0.0

    durations = [t.duration_ms for t in successes]
    time_to_closure_ms: dict[str, float] = {
        "mean": float(statistics.mean(durations)) if durations else 0.0,
        "median": float(statistics.median(durations)) if durations else 0.0,
        "p95": float(_percentile(durations, 95)) if durations else 0.0,
        "p99": float(_percentile(durations, 99)) if durations else 0.0,
        "min": float(min(durations)) if durations else 0.0,
        "max": float(max(durations)) if durations else 0.0,
    }

    return ClosureResults(
        version=_SCHEMA_VERSION,
        timestamp_utc=datetime.now(UTC).isoformat(),
        sdk_version=__version__,
        base_url=base_url,
        n_trials=n,
        run_uuid=run_uuid,
        agent_a_id=agent_a_id,
        agent_b_id=agent_b_id,
        closure_rate=closure_rate,
        signature_verification_rate=sigverify_rate,
        feedback_acceptance_rate=fb_rate,
        time_to_closure_ms=time_to_closure_ms,
        trials=trials,
    )


def _percentile(values: list[int], pct: float) -> float:
    """Return the ``pct``-th percentile via linear interpolation.

    Implemented locally because :func:`statistics.quantiles` produces
    boundaries-only output that is awkward for an arbitrary single
    percentile, and ``numpy`` is not a dependency.
    """
    if not values:
        return 0.0
    sorted_values = sorted(values)
    if len(sorted_values) == 1:
        return float(sorted_values[0])
    rank = (pct / 100.0) * (len(sorted_values) - 1)
    lo = int(rank)
    hi = min(lo + 1, len(sorted_values) - 1)
    frac = rank - lo
    return float(sorted_values[lo] + frac * (sorted_values[hi] - sorted_values[lo]))
