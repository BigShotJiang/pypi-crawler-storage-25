"""Public test doubles for SDK consumers.

This module is the SDK's ``respx``-equivalent — but at the SDK
surface, not the HTTP surface. SDK consumers writing their own tests
import ``borg_collective.testing.FakeClient`` (or
``FakeAsyncClient``) and use it as a drop-in replacement for
``borg_collective.Client``. No HTTP knowledge required; no respx
fixtures, no httpx mocks, no transport plumbing.

Surface
-------

* :class:`FakeClient` — drop-in for :class:`borg_collective.Client`.
* :class:`FakeAsyncClient` — drop-in for :class:`borg_collective.AsyncClient`.
* :class:`RecordedCall` — one entry in the call log.

Both fakes mirror the public method surface of the real clients —
``register_agent``, ``whoami``, ``publish``, ``get``, ``search``,
``feedback``, ``add_amendment``, ``rotate_pubkey``, ``drain``,
``close`` (or ``aclose``), and the (async-)context-manager protocol.

Recording
~~~~~~~~~

Every public-method call is appended to ``fake.calls`` as a
:class:`RecordedCall` with the method name, the kwargs (positional
args are normalised to kwargs by name), and a monotonic timestamp.
``fake.calls_for("publish")`` filters to one method.

Configuring responses
~~~~~~~~~~~~~~~~~~~~~

Per-method response queues:

    fake = FakeClient()
    fake.set_next_response("publish", PublishedTrace(...))
    fake.set_next_response("publish", PublishedTrace(...))  # second call
    actual_1 = fake.publish(...)  # returns the first
    actual_2 = fake.publish(...)  # returns the second
    actual_3 = fake.publish(...)  # falls back to default

Per-method exception queues:

    fake.set_next_exception("publish", AuthError("bad", status=403))

The exception queue takes priority over the response queue for the
same method. Exhaustion semantics: when both queues are empty the
fake returns a sensible default (see _DEFAULT_RESPONSES).

Type-checking
~~~~~~~~~~~~~

:class:`FakeClient` and :class:`Client` are structurally compatible
under :class:`ClientLike` (a runtime-checkable Protocol). Code typed
against ``ClientLike`` accepts either; tests can substitute the fake
without ``cast`` or ``# type: ignore``.
"""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol, Self, runtime_checkable

from ._offline import DrainReport
from .models import (
    Agent,
    AgentInfo,
    AgentPubkey,
    AmendmentCreated,
    AmendmentKind,
    Counters,
    FailureTrace,
    FeedbackAck,
    FeedbackOutcome,
    MatchMode,
    Outcome,
    PublishedTrace,
    SearchResults,
    Trace,
    TraceDetail,
    TrustLevel,
    Visibility,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable

    from ._signing import SigningKeyPair

__all__ = [
    "AsyncClientLike",
    "ClientLike",
    "FakeAsyncClient",
    "FakeClient",
    "RecordedCall",
]

# 64-char hex sentinel used in default responses where a model needs
# an error_signature. Distinct prefix ("fade") so callers can grep
# for it in their own tests if they see one leak into a real
# assertion. Must be valid lowercase hex — model validators enforce
# the shape on construction.
_FAKE_ERROR_SIG = "fade" + "0" * 60  # 64 chars
_FAKE_PUBKEY = "00" * 32
_FAKE_AGENT_ID = "fake-agent-00000000-0000-0000-0000-000000000000"


@dataclass(frozen=True)
class RecordedCall:
    """One entry in :class:`FakeClient.calls`.

    ``kwargs`` is always a dict — positional args are normalised to
    kwargs by parameter name when the fake records them. ``ts`` is a
    monotonic counter (``time.monotonic_ns``); compare relative not
    absolute.
    """

    method: str
    kwargs: dict[str, Any]
    ts: int


# ---------------------------------------------------------------------------
# Protocols — what tests can type against.
# ---------------------------------------------------------------------------


@runtime_checkable
class ClientLike(Protocol):
    """Structural type for things that look like :class:`Client`.

    ``isinstance(obj, ClientLike)`` works at runtime; mypy --strict
    accepts both :class:`Client` and :class:`FakeClient` for
    parameters typed ``ClientLike``.
    """

    def register_agent(
        self,
        *,
        display_name: str | None = ...,
        pubkey: str | None = ...,
    ) -> Agent: ...

    def whoami(self) -> AgentInfo: ...

    def publish(
        self,
        trace: FailureTrace | dict[str, Any],
        *,
        signing_key: SigningKeyPair | None = ...,
    ) -> PublishedTrace: ...

    def get(self, trace_id: str) -> TraceDetail: ...

    def search(
        self,
        *,
        error_signature: str | None = ...,
        query: str | None = ...,
        error_class: str | None = ...,
        tags: list[str] | None = ...,
        limit: int = ...,
    ) -> SearchResults: ...

    def feedback(
        self,
        trace_id: str,
        *,
        retrieved: bool = ...,
        read: bool = ...,
        applied: bool = ...,
        outcome: FeedbackOutcome | str | None = ...,
        note: str | None = ...,
    ) -> FeedbackAck: ...

    def add_amendment(
        self,
        trace_id: str,
        *,
        content: str,
        kind: AmendmentKind | str = ...,
    ) -> AmendmentCreated: ...

    def close(self) -> None: ...


@runtime_checkable
class AsyncClientLike(Protocol):
    """Structural type for things that look like :class:`AsyncClient`."""

    def register_agent(
        self,
        *,
        display_name: str | None = ...,
        pubkey: str | None = ...,
    ) -> Awaitable[Agent]: ...

    def whoami(self) -> Awaitable[AgentInfo]: ...

    def publish(
        self,
        trace: FailureTrace | dict[str, Any],
        *,
        signing_key: SigningKeyPair | None = ...,
    ) -> Awaitable[PublishedTrace]: ...

    def get(self, trace_id: str) -> Awaitable[TraceDetail]: ...

    def search(
        self,
        *,
        error_signature: str | None = ...,
        query: str | None = ...,
        error_class: str | None = ...,
        tags: list[str] | None = ...,
        limit: int = ...,
    ) -> Awaitable[SearchResults]: ...

    def feedback(
        self,
        trace_id: str,
        *,
        retrieved: bool = ...,
        read: bool = ...,
        applied: bool = ...,
        outcome: FeedbackOutcome | str | None = ...,
        note: str | None = ...,
    ) -> Awaitable[FeedbackAck]: ...

    def add_amendment(
        self,
        trace_id: str,
        *,
        content: str,
        kind: AmendmentKind | str = ...,
    ) -> Awaitable[AmendmentCreated]: ...

    def aclose(self) -> Awaitable[None]: ...


# ---------------------------------------------------------------------------
# Default responses — used when no response/exception is queued.
# ---------------------------------------------------------------------------


def _default_agent() -> Agent:
    return Agent(
        agent_id=_FAKE_AGENT_ID,
        display_name="fake-agent",
        trust_level="soft",
        created_at=0,
        api_key="fa" * 32,  # 64-char hex sentinel
    )


def _default_agent_info() -> AgentInfo:
    return AgentInfo(
        agent_id=_FAKE_AGENT_ID,
        display_name="fake-agent",
        trust_level=TrustLevel.SOFT,
        pubkey=None,
        created_at=0,
    )


def _default_agent_pubkey() -> AgentPubkey:
    return AgentPubkey(agent_id=_FAKE_AGENT_ID, pubkey=_FAKE_PUBKEY, updated_at=0)


def _default_published() -> PublishedTrace:
    return PublishedTrace(
        trace_id="fake-trace-id",
        signed=False,
        error_signature=_FAKE_ERROR_SIG,
        warning="fake_default",
    )


def _default_trace_detail() -> TraceDetail:
    trace = Trace(
        trace_id="fake-trace-id",
        agent_id=_FAKE_AGENT_ID,
        error_signature=_FAKE_ERROR_SIG,
        error_class=None,
        error_text="(fake)",
        task_description="(fake)",
        approach_summary="(fake)",
        root_cause="(fake)",
        outcome=Outcome.RESOLVED,
        technology=None,
        tags=[],
        context_snapshot={},
        visibility=Visibility.PRIVATE,
        signed=False,
        signature=None,
        signer_pubkey=None,
        created_at=0,
    )
    return TraceDetail(trace=trace, amendments=[], counters=Counters())


def _default_amendment_created() -> AmendmentCreated:
    return AmendmentCreated(
        amendment_id="fake-amendment-id",
        trace_id="fake-trace-id",
        kind=AmendmentKind.CLARIFICATION,
        created_at=0,
    )


def _default_search_results() -> SearchResults:
    return SearchResults(results=[], count=0, match_mode=MatchMode.FILTER)


def _default_feedback_ack() -> FeedbackAck:
    return FeedbackAck(
        recorded=True,
        trace_id="fake-trace-id",
        counters_updated=False,
        note=None,
    )


# Registry mapping method name → default factory. New fake methods
# add a row here; a missing entry trips a KeyError so we can't ship a
# fake that silently returns None for an unmapped method.
_DEFAULT_RESPONSES: dict[str, Any] = {
    "register_agent": _default_agent,
    "whoami": _default_agent_info,
    "rotate_pubkey": _default_agent_pubkey,
    "publish": _default_published,
    "get": _default_trace_detail,
    "add_amendment": _default_amendment_created,
    "search": _default_search_results,
    "feedback": _default_feedback_ack,
    "drain": DrainReport,  # zero-counts default report
}


# ---------------------------------------------------------------------------
# Recorder — shared between sync and async fakes.
# ---------------------------------------------------------------------------


class _Recorder:
    """Per-fake-instance call log + per-method response/exception queues."""

    def __init__(self) -> None:
        self.calls: list[RecordedCall] = []
        self._responses: dict[str, deque[Any]] = {}
        self._exceptions: dict[str, deque[BaseException]] = {}

    def record(self, method: str, kwargs: dict[str, Any]) -> None:
        self.calls.append(RecordedCall(method=method, kwargs=dict(kwargs), ts=time.monotonic_ns()))

    def calls_for(self, method: str) -> list[RecordedCall]:
        return [c for c in self.calls if c.method == method]

    def queue_response(self, method: str, response: Any) -> None:
        self._responses.setdefault(method, deque()).append(response)

    def queue_exception(self, method: str, exc: BaseException) -> None:
        self._exceptions.setdefault(method, deque()).append(exc)

    def next_for(self, method: str) -> Any:
        """Pop a queued exception (raises) or response, else default."""
        exc_q = self._exceptions.get(method)
        if exc_q:
            raise exc_q.popleft()
        resp_q = self._responses.get(method)
        if resp_q:
            return resp_q.popleft()
        factory = _DEFAULT_RESPONSES[method]
        return factory()

    def reset(self) -> None:
        """Clear calls + queued responses/exceptions. Useful between tests."""
        self.calls.clear()
        self._responses.clear()
        self._exceptions.clear()


# ---------------------------------------------------------------------------
# Sync fake
# ---------------------------------------------------------------------------


class FakeClient:
    """Drop-in replacement for :class:`borg_collective.Client`.

    See module docstring for usage. Does not perform any network IO;
    does not own a transport; does not own an offline queue. Just
    records calls and returns configurable responses.
    """

    def __init__(self) -> None:
        self._recorder = _Recorder()
        self._closed = False

    # ---------- introspection ----------

    @property
    def calls(self) -> list[RecordedCall]:
        return self._recorder.calls

    def calls_for(self, method: str) -> list[RecordedCall]:
        return self._recorder.calls_for(method)

    def set_next_response(self, method: str, response: Any) -> None:
        """Queue ``response`` to be returned by the next call to ``method``."""
        if method not in _DEFAULT_RESPONSES:
            msg = f"unknown method {method!r}; must be one of {sorted(_DEFAULT_RESPONSES)}"
            raise ValueError(msg)
        self._recorder.queue_response(method, response)

    def set_next_exception(self, method: str, exc: BaseException) -> None:
        """Queue ``exc`` to be raised by the next call to ``method``."""
        if method not in _DEFAULT_RESPONSES:
            msg = f"unknown method {method!r}; must be one of {sorted(_DEFAULT_RESPONSES)}"
            raise ValueError(msg)
        self._recorder.queue_exception(method, exc)

    def reset(self) -> None:
        """Clear calls + queued responses/exceptions."""
        self._recorder.reset()

    # ---------- lifecycle ----------

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()

    def close(self) -> None:
        self._closed = True

    # ---------- mirrored surface ----------

    def register_agent(
        self,
        *,
        display_name: str | None = None,
        pubkey: str | None = None,
    ) -> Agent:
        self._recorder.record(
            "register_agent",
            {"display_name": display_name, "pubkey": pubkey},
        )
        return self._recorder.next_for("register_agent")  # type: ignore[no-any-return]

    def whoami(self) -> AgentInfo:
        self._recorder.record("whoami", {})
        return self._recorder.next_for("whoami")  # type: ignore[no-any-return]

    def rotate_pubkey(self, pubkey: str) -> AgentPubkey:
        self._recorder.record("rotate_pubkey", {"pubkey": pubkey})
        return self._recorder.next_for("rotate_pubkey")  # type: ignore[no-any-return]

    def publish(
        self,
        trace: FailureTrace | dict[str, Any],
        *,
        signing_key: SigningKeyPair | None = None,
    ) -> PublishedTrace:
        self._recorder.record(
            "publish",
            {"trace": trace, "signing_key": signing_key},
        )
        return self._recorder.next_for("publish")  # type: ignore[no-any-return]

    def get(self, trace_id: str) -> TraceDetail:
        self._recorder.record("get", {"trace_id": trace_id})
        return self._recorder.next_for("get")  # type: ignore[no-any-return]

    def add_amendment(
        self,
        trace_id: str,
        *,
        content: str,
        kind: AmendmentKind | str = AmendmentKind.CLARIFICATION,
    ) -> AmendmentCreated:
        self._recorder.record(
            "add_amendment",
            {"trace_id": trace_id, "content": content, "kind": kind},
        )
        return self._recorder.next_for("add_amendment")  # type: ignore[no-any-return]

    def search(
        self,
        *,
        error_signature: str | None = None,
        query: str | None = None,
        error_class: str | None = None,
        tags: list[str] | None = None,
        limit: int = 10,
    ) -> SearchResults:
        self._recorder.record(
            "search",
            {
                "error_signature": error_signature,
                "query": query,
                "error_class": error_class,
                "tags": tags,
                "limit": limit,
            },
        )
        return self._recorder.next_for("search")  # type: ignore[no-any-return]

    def feedback(
        self,
        trace_id: str,
        *,
        retrieved: bool = False,
        read: bool = False,
        applied: bool = False,
        outcome: FeedbackOutcome | str | None = None,
        note: str | None = None,
    ) -> FeedbackAck:
        self._recorder.record(
            "feedback",
            {
                "trace_id": trace_id,
                "retrieved": retrieved,
                "read": read,
                "applied": applied,
                "outcome": outcome,
                "note": note,
            },
        )
        return self._recorder.next_for("feedback")  # type: ignore[no-any-return]

    def drain(self, *, max_items: int = 100) -> DrainReport:
        self._recorder.record("drain", {"max_items": max_items})
        return self._recorder.next_for("drain")  # type: ignore[no-any-return]


# ---------------------------------------------------------------------------
# Async fake
# ---------------------------------------------------------------------------


class FakeAsyncClient:
    """Drop-in replacement for :class:`borg_collective.AsyncClient`.

    Async mirror of :class:`FakeClient`. Same recorder, same response
    + exception queues, same defaults — only the methods are
    awaitable. Construct one per test; reset between tests via
    :meth:`reset` if you reuse it.
    """

    def __init__(self) -> None:
        self._recorder = _Recorder()
        self._closed = False

    @property
    def calls(self) -> list[RecordedCall]:
        return self._recorder.calls

    def calls_for(self, method: str) -> list[RecordedCall]:
        return self._recorder.calls_for(method)

    def set_next_response(self, method: str, response: Any) -> None:
        if method not in _DEFAULT_RESPONSES:
            msg = f"unknown method {method!r}; must be one of {sorted(_DEFAULT_RESPONSES)}"
            raise ValueError(msg)
        self._recorder.queue_response(method, response)

    def set_next_exception(self, method: str, exc: BaseException) -> None:
        if method not in _DEFAULT_RESPONSES:
            msg = f"unknown method {method!r}; must be one of {sorted(_DEFAULT_RESPONSES)}"
            raise ValueError(msg)
        self._recorder.queue_exception(method, exc)

    def reset(self) -> None:
        self._recorder.reset()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        self._closed = True

    async def register_agent(
        self,
        *,
        display_name: str | None = None,
        pubkey: str | None = None,
    ) -> Agent:
        self._recorder.record(
            "register_agent",
            {"display_name": display_name, "pubkey": pubkey},
        )
        return self._recorder.next_for("register_agent")  # type: ignore[no-any-return]

    async def whoami(self) -> AgentInfo:
        self._recorder.record("whoami", {})
        return self._recorder.next_for("whoami")  # type: ignore[no-any-return]

    async def rotate_pubkey(self, pubkey: str) -> AgentPubkey:
        self._recorder.record("rotate_pubkey", {"pubkey": pubkey})
        return self._recorder.next_for("rotate_pubkey")  # type: ignore[no-any-return]

    async def publish(
        self,
        trace: FailureTrace | dict[str, Any],
        *,
        signing_key: SigningKeyPair | None = None,
    ) -> PublishedTrace:
        self._recorder.record(
            "publish",
            {"trace": trace, "signing_key": signing_key},
        )
        return self._recorder.next_for("publish")  # type: ignore[no-any-return]

    async def get(self, trace_id: str) -> TraceDetail:
        self._recorder.record("get", {"trace_id": trace_id})
        return self._recorder.next_for("get")  # type: ignore[no-any-return]

    async def add_amendment(
        self,
        trace_id: str,
        *,
        content: str,
        kind: AmendmentKind | str = AmendmentKind.CLARIFICATION,
    ) -> AmendmentCreated:
        self._recorder.record(
            "add_amendment",
            {"trace_id": trace_id, "content": content, "kind": kind},
        )
        return self._recorder.next_for("add_amendment")  # type: ignore[no-any-return]

    async def search(
        self,
        *,
        error_signature: str | None = None,
        query: str | None = None,
        error_class: str | None = None,
        tags: list[str] | None = None,
        limit: int = 10,
    ) -> SearchResults:
        self._recorder.record(
            "search",
            {
                "error_signature": error_signature,
                "query": query,
                "error_class": error_class,
                "tags": tags,
                "limit": limit,
            },
        )
        return self._recorder.next_for("search")  # type: ignore[no-any-return]

    async def feedback(
        self,
        trace_id: str,
        *,
        retrieved: bool = False,
        read: bool = False,
        applied: bool = False,
        outcome: FeedbackOutcome | str | None = None,
        note: str | None = None,
    ) -> FeedbackAck:
        self._recorder.record(
            "feedback",
            {
                "trace_id": trace_id,
                "retrieved": retrieved,
                "read": read,
                "applied": applied,
                "outcome": outcome,
                "note": note,
            },
        )
        return self._recorder.next_for("feedback")  # type: ignore[no-any-return]

    async def drain(self, *, max_items: int = 100) -> DrainReport:
        self._recorder.record("drain", {"max_items": max_items})
        return self._recorder.next_for("drain")  # type: ignore[no-any-return]
