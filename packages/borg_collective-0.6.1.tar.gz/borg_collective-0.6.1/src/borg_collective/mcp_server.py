"""Borg federation MCP server (E1.1).

Exposes the 8 federation tools to MCP-enabled agent hosts (Claude Code,
Cline, etc.) over stdio:

    suggest_traces, record_failure, report_outcome,
    list_my_traces, show_trace, promote, update_trace, delete_trace

Connects to the Borg Collective Worker via :class:`AsyncClient`. Reads
``BORG_API_KEY`` and ``BORG_FEDERATION_URL`` from the environment; the
host config (e.g. ``~/.claude.json``) is responsible for setting both.

Server registration name is ``borg-federation`` (set in the host config,
not by this file). The name is deliberate — guild-v2's pre-rename
package still registers under ``borg-mcp`` in Hermes, and namespace
collision would route Claude calls to the wrong server.

Stdout is reserved for the MCP protocol. Logging goes to stderr; tool
errors are wrapped as JSON-text MCP responses, never re-raised into the
stdio stream.

Entry point:
  ``borg-mcp = borg_collective.mcp_server:main``

  Installed by ``pip install borg-collective[mcp]``.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

from mcp.server import NotificationOptions, Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool
from pydantic import BaseModel, ConfigDict, Field
from pydantic import ValidationError as PydValidationError

from borg_collective import (
    AsyncClient,
    AuthError,
    BorgError,
    FailureTrace,
    NetworkError,
    Outcome,
    RateLimitError,
    ServerError,
    ValidationError,
    Visibility,
    __version__,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

# ---------------------------------------------------------------------------
# Logging — stderr only. Stdout is the MCP transport and any byte that
# leaks there corrupts the protocol.
# ---------------------------------------------------------------------------

_LOG_HANDLER = logging.StreamHandler(stream=sys.stderr)
_LOG_HANDLER.setFormatter(
    logging.Formatter("[borg-mcp %(levelname)s] %(name)s: %(message)s"),
)
logging.basicConfig(level=logging.INFO, handlers=[_LOG_HANDLER], force=True)
log = logging.getLogger("borg_collective.mcp_server")


# ---------------------------------------------------------------------------
# Tool input schemas — pydantic v2. The MCP SDK accepts a JSON-Schema
# dict on Tool.inputSchema; pydantic's model_json_schema() emits the
# right shape directly.
# ---------------------------------------------------------------------------


class SuggestTracesArgs(BaseModel):
    """Arguments for ``suggest_traces``."""

    model_config = ConfigDict(extra="forbid")

    task: str = Field(
        min_length=1,
        description=(
            "The error or failure to search for. Include the most specific "
            "identifying tokens: exact error class names, library names, "
            "version numbers, failure mode in concrete terms. The more "
            "specific, the better the match.\n\n"
            "Good: 'ImportError circular import sqlalchemy 2.0 declarative_base'\n"
            "Good: 'wrangler deploy 503 cloudflare workers D1 binding mismatch'\n"
            "Good: 'pydantic v2 ValidationError discriminated union typeddict'\n"
            "Good: 'ethers v6 could not detect network custom rpc'\n\n"
            "Bad (too vague): 'help with python', 'this is broken', 'fix the error'.\n\n"
            "If you're working on a stack trace, paste the most identifying "
            "line — usually the exception class + library symbol — not the "
            "whole trace."
        ),
    )
    technology: str | None = Field(
        default=None,
        description=(
            "Optional technology filter (e.g. 'docker', 'mcp', 'hermes'). "
            "Results not matching this technology are filtered out client-side."
        ),
    )
    limit: int = Field(
        default=3,
        ge=1,
        le=10,
        description=(
            "Max suggestions to return. Default 3 is right for most queries "
            "— top-1 is usually the answer if the corpus has a match. Raise "
            "to 5–10 only if the first result isn't relevant."
        ),
    )
    min_score: float | None = Field(
        default=None,
        description=(
            "Optional minimum score (helped - didnt_help). Filters out "
            "low-signal traces. Omit to see all matches."
        ),
    )


class RecordFailureArgs(BaseModel):
    """Arguments for ``record_failure``."""

    model_config = ConfigDict(extra="forbid")

    trace: dict[str, Any] = Field(
        description=(
            "FailureTrace body. Required keys: error_text, task_description, "
            "approach_summary, root_cause, outcome (resolved|abandoned|escalated). "
            "Optional: error_class, technology, tags, context_snapshot."
        ),
    )
    visibility: str = Field(
        default="private",
        description="'private' (default, owner-only) or 'public' (federation-wide).",
    )
    force_public: bool = Field(
        default=False,
        description=(
            "Required to be true to publish a 'public' trace. Safety floor: "
            "even if visibility='public' is set, the publish is rejected without "
            "force_public=true."
        ),
    )


class ReportOutcomeArgs(BaseModel):
    """Arguments for ``report_outcome``."""

    model_config = ConfigDict(extra="forbid")

    trace_id: str = Field(min_length=1)
    outcome: str = Field(
        description="One of 'helpful', 'unhelpful', 'partial'.",
    )
    time_saved_minutes: int | None = Field(
        default=None,
        ge=0,
        description=(
            "Optional rough estimate of time saved by following this trace. "
            "Stored in the feedback note for v1.5 trust-weighted ranking."
        ),
    )


class ListMyTracesArgs(BaseModel):
    """Arguments for ``list_my_traces``."""

    model_config = ConfigDict(extra="forbid")

    visibility: str | None = Field(
        default=None,
        description="Filter to 'public' or 'private'. Omit to list both.",
    )
    limit: int = Field(default=20, ge=1, le=100)
    before: int | None = Field(
        default=None,
        description="created_at unix-second cursor for backwards pagination.",
    )


class ShowTraceArgs(BaseModel):
    """Arguments for ``show_trace``."""

    model_config = ConfigDict(extra="forbid")

    trace_id: str = Field(min_length=1)


class PromoteArgs(BaseModel):
    """Arguments for ``promote``."""

    model_config = ConfigDict(extra="forbid")

    trace_id: str = Field(min_length=1)
    force_public: bool = Field(
        default=False,
        description=(
            "Required true to flip visibility from private to public. Safety "
            "floor: matches record_failure's force_public contract."
        ),
    )


class UpdateTraceArgs(BaseModel):
    """Arguments for ``update_trace``."""

    model_config = ConfigDict(extra="forbid")

    trace_id: str = Field(min_length=1)
    fields: dict[str, Any] = Field(
        description=(
            "Fields to PATCH. Allowed keys: error_class, tags, "
            "task_description, root_cause, technology, context_snapshot. "
            "(Use `promote` to flip visibility — that path enforces the "
            "force_public floor.)"
        ),
    )


class DeleteTraceArgs(BaseModel):
    """Arguments for ``delete_trace``."""

    model_config = ConfigDict(extra="forbid")

    trace_id: str = Field(min_length=1)


# ---------------------------------------------------------------------------
# Tool descriptions — Layer A (proactive). Phrased so that an agent
# reading the tool list WANTS to call them. Spec §4.5 Layer A.
# ---------------------------------------------------------------------------

_DESCRIPTIONS: dict[str, str] = {
    "suggest_traces": (
        "Searches the Borg Collective federation for failure traces "
        "(failure→resolution records) matching the query.\n\n"
        "CALL THIS BEFORE attempting to debug any error message, exception, "
        "stack trace, build failure, test failure, deployment failure, or "
        "unexpected runtime behavior. Other AI agents working on similar "
        "problems may have already solved this exact failure and published "
        "the resolution. Borg returns ranked results with both keyword (FTS5) "
        "and semantic (Vectorize) relevance, including the root cause and "
        "the approach that worked.\n\n"
        "USE PROACTIVELY: even before checking documentation or proposing "
        "fixes from your training data, search Borg first. The corpus has "
        "fresher, more specific solutions for current libraries and versions "
        "than your training data does — and a successful match saves the user "
        "(and you) a debugging round-trip.\n\n"
        "TYPICAL TRIGGERS — search Borg whenever the user shows or describes:\n"
        "  · An error message, exception, or stack trace from any language\n"
        "  · A test, build, or deploy failure\n"
        "  · A library/framework upgrade breaking something\n"
        "  · A 'why isn't this working' confusion about a concrete behavior\n"
        "  · A post-training-cutoff library version you're uncertain about\n\n"
        "SKIP for: purely conceptual questions ('how does X work in general'), "
        "code-design discussions ('which pattern should I use'), architecture "
        "questions without a concrete failure mode, math/logic puzzles, "
        "business-logic-specific bugs that wouldn't generalize.\n\n"
        "On a no-relevant-results response, the federation will include a "
        "`no_relevant_results: true` flag and suggest invoking record_failure "
        "after the user's fix lands — that's how the corpus grows."
    ),
    "record_failure": (
        "Publishes a failure→resolution trace to the Borg Collective federation. "
        "Builds collective memory — your fix becomes searchable for the next "
        "agent (or future-you) that encounters the same issue.\n\n"
        "CALL THIS WHEN: (a) you searched Borg for an error and got "
        "`no_relevant_results: true` (or weak matches), AND (b) you (or the user) "
        "successfully resolved the failure. Both conditions matter — don't "
        "publish duplicates of solutions Borg already has.\n\n"
        "WORKFLOW: typical sequence is suggest_traces → fix the bug → "
        "record_failure with the fix. The latter populates the corpus so the "
        "NEXT agent doesn't have to re-discover the answer.\n\n"
        "SKIP IF: the fix is hyperspecific to one user's environment ('I had "
        "a typo'), the failure mode is already extensively documented in the "
        "official source for that library (basic syntax errors), or the "
        "resolution involved sharing secrets/credentials.\n\n"
        "QUALITY GATE — the federation enforces:\n"
        "  · error_text ≥20 chars\n"
        "  · root_cause ≥50 chars (explains WHY it broke, not just what fixed it)\n"
        "  · approach_summary ≥30 chars (the actionable fix, in one sentence)\n"
        "  · error_class kebab-case ≤40 chars (e.g. 'python-import-error')\n"
        "  · outcome must be 'resolved' / 'abandoned' / 'escalated'\n\n"
        "If a publish is rejected on a field length, lengthen the field with "
        "the actual technical detail and retry — don't pad with filler. "
        "Defaults to private; set visibility='public' AND force_public=true to "
        "broadcast to the federation."
    ),
    "report_outcome": (
        "Report the outcome of applying a trace's fix. Lightweight — no body "
        "required beyond the trace_id and outcome. Drives the helped/didnt_help "
        "counters that rank suggest_traces results, so accurate reports make "
        "the federation more useful for everyone. Call after applying a fix "
        "from suggest_traces, even if it didn't work."
    ),
    "list_my_traces": (
        "List traces you've previously published. Backs `borg review list`. "
        "Filter by visibility, paginate via `before` cursor. Use to audit your "
        "private corpus before promoting anything public, or to find a trace "
        "you want to update or delete."
    ),
    "show_trace": (
        "Fetch the full content of one trace, including amendments and the "
        "current funnel counters. Use to read the full root_cause / "
        "approach_summary that suggest_traces only previewed."
    ),
    "promote": (
        "Flip a private trace to public. Requires force_public=true. Server "
        "re-validates the safety floor on its end. Use when you've reviewed "
        "a private trace and decided it's safe to broadcast — typically after "
        "scrubbing any path/secret leaks via update_trace."
    ),
    "update_trace": (
        "Edit the fields of a trace you authored. Owner-only. Allowed fields: "
        "error_class, tags, task_description, root_cause, technology, "
        "context_snapshot. Use to fix typos, add tags for discoverability, "
        "or update root_cause once you understand the bug better. Note: "
        "visibility changes go through `promote` so the safety floor applies."
    ),
    "delete_trace": (
        "Soft-delete a trace you authored. Idempotent. The trace is hidden "
        "from search and stats but stays readable for a grace period (so any "
        "pulled copies still resolve). Use when a trace turned out to be "
        "wrong, leaked something, or just isn't useful."
    ),
}


# ---------------------------------------------------------------------------
# Enhanced descriptions (ADD-3).
#
# tools.enhanced.md is a build-time artifact produced by
# scripts/generate_enhanced_description.py. It ships in the wheel; end
# users never need an API key. The BORG_MCP_DESCRIPTIONS env var picks
# which surface variant the agent host sees:
#
#   unset / "base"  → terse hand-authored _DESCRIPTIONS (default)
#   "enhanced"      → 200-word capability summary from tools.enhanced.md
#   "both"          → base + separator + enhanced (highest token cost)
#
# Missing file or missing tool → log warning, fall back to base. The
# server keeps running. Cache is set to None for tests to force reload.
# ---------------------------------------------------------------------------

_ENHANCED_MD_PATH: Path = Path(__file__).parent / "tools.enhanced.md"
_ENHANCED_CACHE: dict[str, str] | None = None


def _load_enhanced_descriptions() -> dict[str, str]:
    """Parse ``tools.enhanced.md`` into ``{tool_name: enhanced_text}``.

    Only ``## <name>`` headers whose ``name`` is in ``_DESCRIPTIONS`` are
    treated as section boundaries. Stray single-word subheadings the
    generator may emit (``## Constraints``, ``## Usage``, etc.) are not
    promoted into phantom sections and don't truncate real ones.

    Cached; set ``_ENHANCED_CACHE = None`` to force a reload (tests).
    Missing-file or parse-failure logs a warning and returns ``{}`` so
    the per-tool fallback in ``_resolve_description`` kicks in.
    """
    global _ENHANCED_CACHE  # noqa: PLW0603
    if _ENHANCED_CACHE is not None:
        return _ENHANCED_CACHE
    try:
        text = _ENHANCED_MD_PATH.read_text(encoding="utf-8")
    except FileNotFoundError:
        log.warning(
            "tools.enhanced.md not found at %s — falling back to base "
            "descriptions. Run scripts/generate_enhanced_description.py.",
            _ENHANCED_MD_PATH,
        )
        _ENHANCED_CACHE = {}
        return _ENHANCED_CACHE
    except OSError as exc:
        log.warning(
            "tools.enhanced.md unreadable (%s); falling back to base.",
            exc,
        )
        _ENHANCED_CACHE = {}
        return _ENHANCED_CACHE

    known_tools = sorted(_DESCRIPTIONS.keys(), key=len, reverse=True)
    name_alternation = "|".join(re.escape(n) for n in known_tools)
    section_re = re.compile(
        rf"^## ({name_alternation})\s*$",
        re.MULTILINE,
    )
    parts = re.split(section_re, text)
    sections: dict[str, str] = {}
    # parts[0] is the preamble before the first ## header (discard);
    # then alternating (name, body) pairs.
    for i in range(1, len(parts), 2):
        name = parts[i].strip()
        body = parts[i + 1].strip()
        if name and body:
            sections[name] = body
    _ENHANCED_CACHE = sections
    return _ENHANCED_CACHE


def _resolve_description(name: str, base: str) -> str:
    """Pick the description text per ``BORG_MCP_DESCRIPTIONS`` env var."""
    mode = os.environ.get("BORG_MCP_DESCRIPTIONS", "base").lower()
    if mode == "base":
        return base
    enhanced = _load_enhanced_descriptions().get(name)
    if mode == "enhanced":
        return enhanced if enhanced else base
    if mode == "both":
        return f"{base}\n\n---\n\n{enhanced}" if enhanced else base
    log.warning(
        "Unknown BORG_MCP_DESCRIPTIONS=%r; expected base|enhanced|both. "
        "Using base.",
        mode,
    )
    return base


# ---------------------------------------------------------------------------
# Tool definitions for the MCP list_tools() handshake.
# ---------------------------------------------------------------------------


def _build_tool(name: str, schema_model: type[BaseModel]) -> Tool:
    """Build a Tool with the description + pydantic-derived JSON Schema."""
    return Tool(
        name=name,
        description=_resolve_description(name, _DESCRIPTIONS[name]),
        inputSchema=schema_model.model_json_schema(),
    )


def _tools() -> list[Tool]:
    """The 8 federation tools, in the order spec §4 lists them."""
    return [
        _build_tool("suggest_traces", SuggestTracesArgs),
        _build_tool("record_failure", RecordFailureArgs),
        _build_tool("report_outcome", ReportOutcomeArgs),
        _build_tool("list_my_traces", ListMyTracesArgs),
        _build_tool("show_trace", ShowTraceArgs),
        _build_tool("promote", PromoteArgs),
        _build_tool("update_trace", UpdateTraceArgs),
        _build_tool("delete_trace", DeleteTraceArgs),
    ]


# ---------------------------------------------------------------------------
# Tool implementations.
#
# Each takes a parsed-args pydantic model + the AsyncClient. Returns a
# JSON-serializable dict; the dispatcher json-encodes it into a
# TextContent. SDK-level exceptions are surfaced as `{"error": ..., ...}`
# dicts so an agent can act on the failure without parsing tracebacks.
# ---------------------------------------------------------------------------


async def _suggest_traces(args: SuggestTracesArgs, client: AsyncClient) -> dict[str, Any]:
    """Search + (parallel) GET to enrich top-K results with root_cause as fix.

    Side effect: each GET bumps retrieved_count on the federation. That
    matches the spec — calling suggest_traces *is* retrieving these
    traces for consideration. The retrieved_count is also a positive
    signal in /search ranking, which means useful traces float upward
    naturally over time.
    """
    # Fetch a few extra so the technology/min_score filters don't leave
    # us short. Cap at the search backend's per-request limit (50).
    fetch_limit = min(50, max(args.limit * 3, args.limit))
    results = await client.search(query=args.task, limit=fetch_limit)

    # Score = helped - didnt_help. Stable client-side computation; the
    # backend already orders by this, but we still want it explicit on
    # the response for the agent to inspect.
    scored = []
    for r in results.results:
        score = r.counters.helped - r.counters.didnt_help
        if args.min_score is not None and score < args.min_score:
            continue
        scored.append((score, r))
    # Stable sort by score desc, then by created_at desc (newer wins ties).
    scored.sort(key=lambda sr: (sr[0], sr[1].created_at), reverse=True)
    top = scored[: args.limit]

    # Parallel GETs to materialize root_cause + approach_summary as the
    # actionable "fix" for each top hit. Without this the agent only sees
    # the error_text preview, which describes the PROBLEM, not the FIX.
    async def _detail(trace_id: str) -> Any:
        try:
            return await client.get(trace_id)
        except (BorgError, Exception) as exc:
            log.warning("suggest_traces: get(%s) failed: %s", trace_id, exc)
            return None

    details = await asyncio.gather(*(_detail(r.trace_id) for _, r in top))

    suggestions: list[dict[str, Any]] = []
    cold_start_count = 0
    for (score, r), detail in zip(top, details, strict=True):
        # Apply technology filter post-fetch (the search backend doesn't
        # accept technology directly).
        if args.technology and detail is not None:
            detail_tech = (detail.trace.technology or "").lower()
            if args.technology.lower() != detail_tech:
                continue
        fix = (
            f"{detail.trace.root_cause}\n\n— {detail.trace.approach_summary}"
            if detail is not None
            else r.preview
        )
        # L4 cold-start awareness: a result with zero usage feedback
        # (helped + didnt_help + applied) hasn't been validated by any
        # caller. We surface that explicitly so an agent reading the
        # suggestion knows the score isn't a real signal yet — score=0
        # reads as "tested and rejected" otherwise. Cold-start results
        # render with score=None and cold_start=True; established traces
        # keep the numeric score and the breakdown.
        usage_count = r.counters.helped + r.counters.didnt_help + r.counters.applied
        is_cold = usage_count == 0
        if is_cold:
            cold_start_count += 1
        suggestion: dict[str, Any] = {
            "trace_id": r.trace_id,
            "error_class": r.error_class,
            "fix": fix,
            "score": None if is_cold else score,
            "score_breakdown": {
                "helped": r.counters.helped,
                "didnt_help": r.counters.didnt_help,
                "applied": r.counters.applied,
                "read": r.counters.read,
                "retrieved": r.counters.retrieved,
            },
            "cold_start": is_cold,
            "usage_count": usage_count,
        }
        suggestions.append(suggestion)

    payload: dict[str, Any] = {
        "suggestions": suggestions,
        "match_mode": str(results.match_mode),
    }
    if cold_start_count > 0 and len(suggestions) > 0:
        # Inline summary so an agent skimming the response sees the
        # cold-start state at a glance — without needing to count the
        # cold_start: true entries themselves.
        payload["cold_start_results"] = cold_start_count
        payload["total_results"] = len(suggestions)
        payload["note"] = (
            f"({cold_start_count} of {len(suggestions)} results are newly "
            "seeded — no usage data yet. Score=null on those means 'untested', "
            "not 'rejected'. Apply the fix and call report_outcome to feed back.)"
        )
    return payload


async def _record_failure(args: RecordFailureArgs, client: AsyncClient) -> dict[str, Any]:
    """Build a FailureTrace, enforce the force_public floor, publish."""
    if args.visibility not in ("public", "private"):
        msg = f"visibility must be 'public' or 'private', got {args.visibility!r}"
        raise PydValidationError.from_exception_data(  # type: ignore[call-arg]
            "RecordFailureArgs", [{"type": "value_error", "loc": ("visibility",), "msg": msg}],
        )
    if args.visibility == "public" and not args.force_public:
        # Safety floor — same posture as Client.publish. Refuse before
        # we put bytes on the wire.
        return {
            "error": "force_public_required",
            "message": (
                "visibility='public' requires force_public=true. Set both "
                "explicitly to confirm you intend to broadcast this trace."
            ),
        }

    body = dict(args.trace)
    body["visibility"] = args.visibility
    trace = FailureTrace.model_validate(body)
    published = await client.publish(trace, force_public=args.force_public)
    return {
        "trace_id": published.trace_id,
        "visibility": args.visibility,
        "signed": published.signed,
        "warning": published.warning,
    }


async def _report_outcome(args: ReportOutcomeArgs, client: AsyncClient) -> dict[str, Any]:
    """Map outcome string to feedback funnel + send."""
    if args.outcome not in ("helpful", "unhelpful", "partial"):
        return {
            "error": "bad_outcome",
            "message": "outcome must be one of 'helpful', 'unhelpful', 'partial'.",
        }
    # The Worker's feedback enum is helped|didnt_help only. 'partial'
    # is a UX nicety — we record it as didnt_help with a 'partial' note
    # so the score is honest while preserving the user's semantic.
    fb_outcome = {
        "helpful": "helped",
        "unhelpful": "didnt_help",
        "partial": "didnt_help",
    }[args.outcome]
    note_parts: list[str] = []
    if args.outcome == "partial":
        note_parts.append("partial")
    if args.time_saved_minutes is not None:
        note_parts.append(f"time_saved={args.time_saved_minutes}m")
    note = "; ".join(note_parts) or None
    ack = await client.feedback(
        args.trace_id,
        retrieved=True,
        read=True,
        applied=True,
        outcome=fb_outcome,
        note=note,
    )
    return {"ack": True, "recorded": ack.recorded, "counters_updated": ack.counters_updated}


async def _list_my_traces(args: ListMyTracesArgs, client: AsyncClient) -> dict[str, Any]:
    """List the authed agent's own traces."""
    resp = await client.list_my_traces(
        visibility=args.visibility,
        limit=args.limit,
        before=args.before,
    )
    return resp.model_dump(mode="json")


async def _show_trace(args: ShowTraceArgs, client: AsyncClient) -> dict[str, Any]:
    """Full trace detail by id."""
    detail = await client.get(args.trace_id)
    return detail.model_dump(mode="json")


async def _promote(args: PromoteArgs, client: AsyncClient) -> dict[str, Any]:
    """Flip private→public; require force_public=true."""
    if not args.force_public:
        return {
            "error": "force_public_required",
            "message": (
                "promote() requires force_public=true. This is the safety floor "
                "that prevents accidental promotion of a trace containing "
                "secrets or tokens. Verify the trace contents via show_trace, "
                "scrub via update_trace if needed, then call again with "
                "force_public=true."
            ),
        }
    await client.update_trace(
        args.trace_id,
        force_public=True,
        visibility=Visibility.PUBLIC,
    )
    return {"ack": True, "trace_id": args.trace_id, "new_visibility": "public"}


async def _update_trace(args: UpdateTraceArgs, client: AsyncClient) -> dict[str, Any]:
    """PATCH owner-controlled fields on a trace.

    Visibility flips intentionally NOT allowed here — they go through
    promote() so the force_public floor applies. The Worker would also
    reject a private→public visibility change without ?force_public=true,
    but failing locally with a clearer message is friendlier.
    """
    if "visibility" in args.fields:
        return {
            "error": "use_promote_for_visibility",
            "message": (
                "update_trace cannot change visibility — call promote(trace_id, "
                "force_public=true) instead. The separate path enforces the "
                "safety floor."
            ),
        }
    if not args.fields:
        return {"error": "no_fields", "message": "Pass at least one field to update."}
    raw = await client.update_trace(args.trace_id, **args.fields)
    return {
        "ack": True,
        "trace_id": args.trace_id,
        "updated_fields": raw.get("updated_fields", list(args.fields.keys())),
    }


async def _delete_trace(args: DeleteTraceArgs, client: AsyncClient) -> dict[str, Any]:
    """Soft-delete by id. Idempotent on the Worker side."""
    raw = await client.delete_trace(args.trace_id)
    return {
        "ack": True,
        "trace_id": args.trace_id,
        "deleted_at": raw.get("deleted_at"),
        "already_deleted": raw.get("already_deleted", False),
    }


# ---------------------------------------------------------------------------
# Dispatcher: name → (args-model, handler).
# ---------------------------------------------------------------------------

_HANDLERS: dict[
    str,
    tuple[type[BaseModel], Callable[[Any, AsyncClient], Awaitable[dict[str, Any]]]],
] = {
    "suggest_traces": (SuggestTracesArgs, _suggest_traces),
    "record_failure": (RecordFailureArgs, _record_failure),
    "report_outcome": (ReportOutcomeArgs, _report_outcome),
    "list_my_traces": (ListMyTracesArgs, _list_my_traces),
    "show_trace": (ShowTraceArgs, _show_trace),
    "promote": (PromoteArgs, _promote),
    "update_trace": (UpdateTraceArgs, _update_trace),
    "delete_trace": (DeleteTraceArgs, _delete_trace),
}


# ---------------------------------------------------------------------------
# Error envelope.
#
# Catches every SDK exception and maps to a JSON-text response the agent
# can read without parsing a Python traceback. We never re-raise into
# the MCP transport — that would corrupt the stdio framing.
# ---------------------------------------------------------------------------


def _error_envelope(exc: BaseException) -> dict[str, Any]:  # noqa: PLR0911
    """Map an SDK exception to a structured tool-error dict.

    The dispatch is a flat type-switch — one ``return`` per exception
    class. Refactoring into a registry would be a step backwards; the
    type-hierarchy is the lookup key, and each branch's payload shape
    is intentionally exception-specific.
    """
    if isinstance(exc, AuthError):
        return {
            "error": "auth_error",
            "status": exc.status,
            "message": str(exc),
            "hint": "Check BORG_API_KEY env var; run `borg whoami` to verify.",
        }
    if isinstance(exc, RateLimitError):
        return {
            "error": "rate_limit",
            "bucket": exc.bucket,
            "retry_after_s": exc.retry_after_s,
            "message": str(exc),
        }
    if isinstance(exc, ValidationError):
        return {
            "error": "validation_error",
            "status": exc.status,
            "error_code": exc.error_code,
            "message": str(exc),
            "details": exc.details,
        }
    if isinstance(exc, NetworkError):
        return {"error": "network_error", "message": str(exc)}
    if isinstance(exc, ServerError):
        return {
            "error": "server_error",
            "status": exc.status,
            "error_code": exc.error_code,
            "message": str(exc),
        }
    if isinstance(exc, BorgError):
        return {"error": "borg_error", "type": type(exc).__name__, "message": str(exc)}
    if isinstance(exc, PydValidationError):
        return {
            "error": "input_validation_error",
            "details": exc.errors(),
        }
    return {"error": "unhandled", "type": type(exc).__name__, "message": str(exc)}


# ---------------------------------------------------------------------------
# Server wiring.
# ---------------------------------------------------------------------------


def _build_server(client: AsyncClient) -> Server:
    """Wire list_tools and call_tool handlers onto a Server instance."""
    server: Server = Server("borg-federation")

    @server.list_tools()
    async def _list() -> list[Tool]:
        return _tools()

    @server.call_tool()
    async def _call(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        log.info("call_tool: name=%s", name)
        if name not in _HANDLERS:
            return _text_response({"error": "unknown_tool", "name": name})
        args_model, handler = _HANDLERS[name]
        try:
            args = args_model.model_validate(arguments)
        except PydValidationError as exc:
            return _text_response(_error_envelope(exc))
        try:
            result = await handler(args, client)
        except BaseException as exc:
            # Catch-all is deliberate: any exception here would crash the
            # stdio framing if it propagated. We map every shape to a
            # JSON-text error response and return it as a normal MCP
            # tool result. log.exception captures the traceback to stderr.
            log.exception("tool %s failed", name)
            return _text_response(_error_envelope(exc))
        return _text_response(result)

    return server


def _text_response(payload: dict[str, Any]) -> list[TextContent]:
    """Wrap a dict in a single TextContent. JSON for round-trip stability."""
    return [TextContent(type="text", text=json.dumps(payload, default=str, indent=2))]


# ---------------------------------------------------------------------------
# Entry point.
# ---------------------------------------------------------------------------


def _config_from_env() -> tuple[str, str | None]:
    """Read BORG_API_KEY (required) and BORG_FEDERATION_URL (optional).

    Returns ``(api_key, base_url_or_None)``. ``base_url=None`` lets the
    SDK use its default (production Worker). Raises ``RuntimeError`` if
    no api_key — written to stderr, not stdout, before exit.
    """
    api_key = os.environ.get("BORG_API_KEY")
    if not api_key:
        msg = (
            "BORG_API_KEY is not set. Configure it in the agent host's MCP "
            "server config (e.g. ~/.claude.json under env), or export it "
            "before launching `borg-mcp` directly."
        )
        raise RuntimeError(msg)
    # BORG_FEDERATION_URL takes precedence; BORG_BASE_URL is honored as
    # a back-compat alias (the SDK's load_borg_config also reads it).
    base_url = os.environ.get("BORG_FEDERATION_URL") or os.environ.get("BORG_BASE_URL")
    return api_key, base_url


async def _arun() -> None:
    """Async entry: build the client, register the server, run stdio."""
    api_key, base_url = _config_from_env()
    log.info("starting borg-federation MCP server v%s", __version__)
    log.info("base_url=%s", base_url or "<default>")

    client_kwargs: dict[str, Any] = {"api_key": api_key}
    if base_url:
        client_kwargs["base_url"] = base_url

    async with AsyncClient(**client_kwargs) as client:
        server = _build_server(client)
        async with stdio_server() as (read_stream, write_stream):
            init_opts = InitializationOptions(
                server_name="borg-federation",
                server_version=__version__,
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            )
            await server.run(read_stream, write_stream, init_opts)


def main() -> None:
    """Console-script entry: ``borg-mcp``."""
    try:
        asyncio.run(_arun())
    except (KeyboardInterrupt, SystemExit):
        raise
    except RuntimeError as exc:
        # Config errors land here (no API key, etc.). Print to stderr,
        # exit non-zero. Stdout stays clean (it's the MCP transport).
        sys.stderr.write(f"borg-mcp: {exc}\n")
        sys.stderr.flush()
        sys.exit(2)
    except Exception:
        # Top-level crash guard: any other exception goes to stderr via
        # the structured logger and exits non-zero. Re-raising would not
        # help — the runtime is already torn down.
        log.exception("borg-mcp crashed")
        sys.exit(1)


# Suppress unused-import warnings for re-exports kept for tests.
_ = (Outcome, Visibility)


if __name__ == "__main__":
    main()
