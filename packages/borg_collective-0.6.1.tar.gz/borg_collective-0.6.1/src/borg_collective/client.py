"""Synchronous high-level client for the Borg Collective Worker.

:class:`Client` is the SDK's public entry point for callers writing
synchronous code. It wraps :class:`borg_collective._transport.Transport`
with typed Pydantic-model returns, handles signed-publish ergonomics
(canonical bytes + signature + signer_pubkey wired automatically when
a :class:`SigningKeyPair` is passed), and pre-empts the auth and funnel
contracts that the Worker also enforces — so a malformed call dies
locally instead of round-tripping a 400.

Method surface (commit 4b, in spec §2 order):

================ ========================== =================================
Method           Worker route               Returns
================ ========================== =================================
register_agent   POST /api/v1/agents        :class:`~borg_collective.models.Agent`
whoami           GET  /api/v1/agents/me     :class:`~borg_collective.models.AgentInfo`
publish          POST /api/v1/traces        :class:`~borg_collective.models.PublishedTrace`
get              GET  /api/v1/traces/:id    :class:`~borg_collective.models.TraceDetail`
search           POST /api/v1/search        :class:`~borg_collective.models.SearchResults`
feedback         POST /api/v1/feedback      :class:`~borg_collective.models.FeedbackAck`
add_amendment    POST /api/v1/traces/:id/amendments  →  AmendmentCreated
================ ========================== =================================

Construction:

    >>> from borg_collective import Client
    >>> with Client(api_key="...") as c:
    ...     me = c.whoami()
    ...     print(me.agent_id, me.trust_level)

The async mirror is :class:`borg_collective.AsyncClient` — same surface,
awaitable methods.
"""

from __future__ import annotations

import os
import tomllib
from pathlib import Path
from typing import TYPE_CHECKING, Any, Self

from ._error_signature import compute_error_signature
from ._offline import DEFAULT_OFFLINE_QUEUE_PATH, DrainReport, OfflineQueue
from ._transport import (
    DEFAULT_BACKOFF_BASE_S,
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    Transport,
)
from .exceptions import (
    AuthError,
    ConfigError,
    NetworkError,
    OfflineError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .models import (
    Agent,
    AgentInfo,
    AgentPubkey,
    AmendmentCreated,
    AmendmentInput,
    AmendmentKind,
    FailureTrace,
    FeedbackAck,
    FeedbackOutcome,
    FeedbackRequest,
    MyTracesResponse,
    PublishedTrace,
    SearchRequest,
    SearchResults,
    TraceDetail,
    Visibility,
)

if TYPE_CHECKING:
    import httpx

    from ._signing import SigningKeyPair

__all__ = ["Client", "load_borg_config", "prepare_signed_body"]


# ---------------------------------------------------------------------------
# Config loader — shared with the CLI so `Client.from_config()` and
# `borg <command>` use identical resolution rules.
# ---------------------------------------------------------------------------

# Default config dir matches the CLI. Override with $BORG_HOME.
_DEFAULT_BORG_HOME: Path = Path.home() / ".borg"


def load_borg_config() -> dict[str, Any]:
    """Resolve api_key + base_url from env vars and ``~/.borg/config.toml``.

    Precedence (highest wins):

    1. ``BORG_API_KEY`` / ``BORG_BASE_URL`` env vars.
    2. ``~/.borg/config.toml`` (or ``$BORG_HOME/config.toml``).

    Returns a dict with at least ``api_key`` and ``base_url`` keys, plus
    whatever else the file holds (typically ``agent_id``). Missing
    api_key is allowed — the caller decides whether that's an error.

    Used by :meth:`Client.from_config` and the ``borg`` CLI; documented
    so callers writing their own scripts can drop into the same
    config file without fighting the SDK.
    """
    home = Path(os.environ["BORG_HOME"]) if os.environ.get("BORG_HOME") else _DEFAULT_BORG_HOME
    on_disk: dict[str, Any] = {}
    config_path = home / "config.toml"
    if config_path.exists():
        with config_path.open("rb") as f:
            on_disk = tomllib.load(f)

    api_key_env = os.environ.get("BORG_API_KEY")
    base_url_env = os.environ.get("BORG_BASE_URL")
    return {
        "api_key": api_key_env or on_disk.get("api_key"),
        "base_url": base_url_env or on_disk.get("base_url") or DEFAULT_BASE_URL,
        "agent_id": on_disk.get("agent_id"),
    }


# Sentinel agent_id used when the caller publishes in offline mode
# without ever calling whoami first. We can't know the agent_id until
# the api_key is exchanged for one — so we fall back to a placeholder
# that drain() will treat as "any agent the configured api_key
# belongs to". Lowercase, no whitespace; stored in the agent_id
# column literally.
_OFFLINE_AGENT_PLACEHOLDER = "offline:unknown"


def _stub_published_for_queue(
    body: dict[str, Any],
    queue_id: int,
) -> PublishedTrace:
    """Synthesise a PublishedTrace for an offline-enqueued publish.

    The trace has not actually been published — there is no real
    ``trace_id``. We surface a sentinel ``"local:{queue_id}"`` so the
    caller can log a deterministic identifier and correlate it with
    the row that drain() will eventually publish. ``signed`` echoes
    the body's ``signature`` field; ``error_signature`` echoes the
    body's value when set, else the SDK computes it (the Worker
    would compute it server-side on a real publish).
    """
    error_signature = body.get("error_signature")
    if not isinstance(error_signature, str):
        error_signature = compute_error_signature(
            error_text=body["error_text"],
            error_class=body.get("error_class"),
            technology=body.get("technology"),
        )
    return PublishedTrace(
        trace_id=f"local:{queue_id}",
        signed=bool(body.get("signature")),
        error_signature=error_signature,
        warning="offline_enqueued",
    )


def prepare_signed_body(
    body: dict[str, Any],
    signing_key: SigningKeyPair,
) -> dict[str, Any]:
    """Stamp ``error_signature``, ``signer_pubkey``, ``signature`` onto ``body``.

    Module-level so the sync and async clients (and tests) share one
    signing implementation. Returns a new dict — does not mutate the
    input. Computes ``error_signature`` only when absent; the Worker
    requires it on signed publishes (see ``traces.ts`` evaluateSignature),
    and recomputing a pre-set value would break a caller that signed
    over different bytes.
    """
    out = dict(body)
    if "error_signature" not in out:
        out["error_signature"] = compute_error_signature(
            error_text=out["error_text"],
            error_class=out.get("error_class"),
            technology=out.get("technology"),
        )
    out["signer_pubkey"] = signing_key.verify_key_hex
    # sign_trace canonicalises the body (dropping signature +
    # signer_pubkey at the top level — see _canonical.py) and returns
    # 128-char hex. The Worker's verifier reconstructs the same
    # canonical bytes from the submitted body, so the signature
    # lines up only if the body is byte-stable.
    out["signature"] = signing_key.sign_trace(out)
    return out


class Client:
    """Synchronous client for the Borg Collective Worker.

    Holds one :class:`Transport` instance for connection-pool reuse.
    Supports the context-manager protocol so callers can write
    ``with Client(api_key=...) as c: ...`` and have the underlying
    httpx pool closed deterministically.

    The api_key is treated as secret end-to-end: it is never logged
    (transport DEBUG only emits method+path), never appears in
    ``__repr__``, and is excluded from ``Agent.model_dump()`` by the
    :class:`Agent` model's redaction (see ``models.py``).

    ``base_url`` defaults to the production Worker
    (``https://borg-collective-v1.borg-farther.workers.dev``); override
    via the ``base_url`` kwarg for local development against
    ``wrangler dev``.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: httpx.Timeout = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        backoff_base_s: float = DEFAULT_BACKOFF_BASE_S,
        transport: Transport | None = None,
        offline_mode: bool = False,
        offline_queue_path: Path | str | None = None,
        offline_queue: OfflineQueue | None = None,
    ) -> None:
        if transport is not None:
            # Caller-supplied transport: respect it verbatim. We do not
            # reach into its config — they own its lifecycle.
            self._transport = transport
            self._owns_transport = False
        else:
            self._transport = Transport(
                api_key=api_key,
                base_url=base_url,
                timeout=timeout,
                max_retries=max_retries,
                backoff_base_s=backoff_base_s,
            )
            self._owns_transport = True

        self._offline_mode = offline_mode
        # Offline queue resolution:
        #   - injected queue wins (caller manages its lifecycle).
        #   - else: open at offline_queue_path if supplied, OR default
        #     when offline_mode=True (callers nearly always want a
        #     queue in offline mode and the default is convenient).
        #   - else: no queue (online-only client; NetworkError won't
        #     fall back to enqueue).
        if offline_queue is not None:
            self._offline_queue: OfflineQueue | None = offline_queue
            self._owns_queue = False
        elif offline_queue_path is not None:
            self._offline_queue = OfflineQueue(offline_queue_path)
            self._owns_queue = True
        elif offline_mode:
            self._offline_queue = OfflineQueue(DEFAULT_OFFLINE_QUEUE_PATH)
            self._owns_queue = True
        else:
            self._offline_queue = None
            self._owns_queue = False

    @classmethod
    def from_config(cls, **overrides: Any) -> Self:
        """Construct a Client from ``BORG_API_KEY`` env or ``~/.borg/config.toml``.

        Drop-in for callers who don't want to plumb config explicitly:

            with Client.from_config() as c:
                me = c.whoami()

        Resolution rules match the ``borg`` CLI exactly — see
        :func:`load_borg_config`. ``**overrides`` go through to the
        regular constructor (e.g. ``Client.from_config(offline_mode=True)``);
        an explicit ``api_key=`` or ``base_url=`` override wins over the
        resolved config.

        Raises :class:`ConfigError` if no api_key is found in env or on
        disk — running ``borg register`` once writes the config and
        unblocks subsequent calls.
        """
        cfg = load_borg_config()
        if "api_key" not in overrides:
            overrides["api_key"] = cfg["api_key"]
        if "base_url" not in overrides:
            overrides["base_url"] = cfg["base_url"]
        if overrides["api_key"] is None:
            msg = (
                "no api_key found in $BORG_API_KEY or ~/.borg/config.toml. "
                "Run `borg register` once, or set BORG_API_KEY."
            )
            raise ConfigError(msg)
        return cls(**overrides)

    # ------------------------------------------------------------------
    # Context manager + lifecycle
    # ------------------------------------------------------------------

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying transport + offline queue, if owned.

        Idempotent — calling close twice is safe.
        """
        if self._owns_transport:
            self._transport.close()
        if self._owns_queue and self._offline_queue is not None:
            self._offline_queue.close()

    def __repr__(self) -> str:
        # Delegates to Transport.__repr__ which already redacts api_key.
        return f"Client(transport={self._transport!r})"

    # ------------------------------------------------------------------
    # Agent identity
    # ------------------------------------------------------------------

    def register_agent(
        self,
        *,
        display_name: str | None = None,
        pubkey: str | None = None,
    ) -> Agent:
        """Register a new agent. Returns the :class:`Agent` with api_key.

        The api_key is returned **once** by the Worker and is treated
        as secret. It is exposed via ``Agent.api_key`` but excluded from
        repr/str/model_dump for defense-in-depth (see ``models.Agent``).

        Auth is not required for this call — POST /agents is the only
        auth-exempt v1 endpoint (besides /health).

        Worker contract:
          * ``display_name`` — optional. When omitted, the Worker
            generates ``agent-<first-8-of-uuid>`` from the new agent_id.
          * ``pubkey`` — optional. 64-char lowercase hex (Ed25519 verify
            key). Can be added later via ``rotate_pubkey`` (commit 4c).
        """
        body: dict[str, Any] = {}
        if display_name is not None:
            body["display_name"] = display_name
        if pubkey is not None:
            body["pubkey"] = pubkey

        raw = self._transport.request(
            "POST",
            "/api/v1/agents",
            json=body,
            auth_required=False,
        )
        return Agent.model_validate(raw)

    def whoami(self) -> AgentInfo:
        """Identity probe: who am I, given the configured api_key?

        Returns :class:`AgentInfo` with ``agent_id``, ``display_name``,
        ``trust_level``, ``pubkey`` (or ``None``), and ``created_at``.
        Raises :class:`~borg_collective.AuthError` on 401/403 (no key
        or invalid key) — a 401 specifically signals the SDK has no
        valid api_key configured.

        Raises :class:`OfflineError` in offline mode: whoami is a
        live-server query and cannot be satisfied from a queue.
        """
        self._reject_in_offline_mode("whoami")
        raw = self._transport.request("GET", "/api/v1/agents/me")
        return AgentInfo.model_validate(raw)

    def rotate_pubkey(self, pubkey: str) -> AgentPubkey:
        """Enroll or rotate the agent's pubkey (64-char lowercase hex).

        Included in 4b for completeness — the publish-with-signing
        flow requires the Worker to know the agent's pubkey. The
        ``pubkey`` argument validates locally against
        :class:`AgentPubkey`'s hex shape.

        Raises :class:`OfflineError` in offline mode — rotation is a
        privileged identity action and we don't queue it.
        """
        self._reject_in_offline_mode("rotate_pubkey")
        raw = self._transport.request(
            "POST",
            "/api/v1/agents/me/pubkey",
            json={"pubkey": pubkey},
        )
        return AgentPubkey.model_validate(raw)

    # ------------------------------------------------------------------
    # Trace publish + retrieve
    # ------------------------------------------------------------------

    def publish(
        self,
        trace: FailureTrace | dict[str, Any],
        *,
        signing_key: SigningKeyPair | None = None,
        force_public: bool = False,
    ) -> PublishedTrace:
        """Publish a failure trace.

        ``trace`` may be a :class:`FailureTrace` (preferred — local
        validation) or a raw dict (the SDK will round-trip it through
        :class:`FailureTrace` to validate before sending).

        ``force_public`` is the explicit opt-in to broadcast publicly.
        Default ``False`` is a safety floor (E0.5): a trace whose
        ``visibility`` is :attr:`Visibility.PUBLIC` is rejected with
        :class:`ValueError` unless ``force_public=True`` is also passed.
        Conversely, ``force_public=True`` on a trace constructed with
        the default ``Visibility.PRIVATE`` is the explicit override
        path — the SDK sends ``visibility=public`` on the wire.

        When ``signing_key`` is provided:
          * ``error_signature`` is computed locally if not already set
            (the Worker requires it on signed publishes).
          * ``signer_pubkey`` is set to ``signing_key.verify_key_hex``.
          * The trace's canonical bytes are signed; ``signature`` is
            populated with the resulting 128-char lowercase hex.

        When ``signing_key`` is ``None``, the trace is sent as-is. The
        Worker computes ``error_signature`` server-side (spec §2 #3),
        stores ``signed=False``, and includes
        ``warning="unsigned_trace"`` in the response.

        Raises :class:`~borg_collective.SignatureError` on 422
        ``bad_signature`` — see that exception's docstring for the
        canonical-form-drift diagnostic.
        """
        ft = trace if isinstance(trace, FailureTrace) else FailureTrace.model_validate(trace)

        if ft.visibility == Visibility.PUBLIC and not force_public:
            msg = (
                "Trace constructed with Visibility.PUBLIC requires force_public=True "
                "to publish. This safeguard prevents accidental public publishes. "
                "If intentional, call: client.publish(trace, force_public=True)"
            )
            raise ValueError(msg)

        # model_dump(exclude_none=True) keeps the wire body small and
        # avoids sending None for optional fields the Worker doesn't
        # accept as null. mode="json" serialises StrEnums to their
        # wire-string values (use_enum_values is False on the model).
        body = ft.model_dump(exclude_none=True, mode="json")

        # Explicit override: PRIVATE-constructed trace + force_public=True
        # promotes the wire visibility to public. The model itself stays
        # PRIVATE so the local copy is unsurprising; only the wire flips.
        if force_public and ft.visibility == Visibility.PRIVATE:
            body["visibility"] = Visibility.PUBLIC.value

        if signing_key is not None:
            body = prepare_signed_body(body, signing_key)

        # Offline-mode publish: enqueue and return a sentinel.
        if self._offline_mode:
            assert self._offline_queue is not None  # invariant from __init__
            queue_id = self._offline_queue.enqueue(_OFFLINE_AGENT_PLACEHOLDER, body)
            return _stub_published_for_queue(body, queue_id)

        # Online publish, possibly with NetworkError → enqueue fallback.
        try:
            raw = self._transport.request("POST", "/api/v1/traces", json=body)
        except NetworkError:
            if self._offline_queue is not None:
                # Best-effort fallback. Re-raise so the caller knows the
                # request didn't reach the Worker; the queue is the
                # safety net, not a silent silencer.
                self._offline_queue.enqueue(_OFFLINE_AGENT_PLACEHOLDER, body)
            raise
        return PublishedTrace.model_validate(raw)

    # ------------------------------------------------------------------
    # Drain (offline → online)
    # ------------------------------------------------------------------

    def drain(self, *, max_items: int = 100) -> DrainReport:
        """Drain pending publish items from the offline queue.

        Pulls up to ``max_items`` rows in :meth:`OfflineQueue.peek`
        order (FIFO, deferred-rows-last). For each item:

        * On success → ``OfflineQueue.delete``; counted as ``drained``.
        * On transient failure (NetworkError, RateLimitError, 5xx
          ServerError) → ``OfflineQueue.mark_attempted``; counted as
          ``deferred``. Drain continues with the next item.
        * On permanent failure (ValidationError, SignatureError) →
          row stays; counted as ``failed``.
        * On AuthError → drain **stops immediately**. The api_key is
          broken or revoked; continuing would just mark every other
          row as failed. ``stopped_early=True`` on the report.

        Returns a :class:`DrainReport` summarising the run. Raises
        :class:`OfflineError` if no offline queue is configured (a
        client without a queue path has nothing to drain).
        """
        if self._offline_queue is None:
            msg = "drain() requires an offline_queue_path or offline_mode=True"
            raise OfflineError(msg)
        if max_items < 1:
            msg = f"max_items must be >= 1, got {max_items}"
            raise ValueError(msg)

        report = DrainReport()
        items = self._offline_queue.peek(limit=max_items)
        for item in items:
            try:
                self._transport.request("POST", "/api/v1/traces", json=item.payload)
            except AuthError as exc:
                # Systemic. No point continuing — every other item will
                # 401/403 too. Mark this one and stop.
                self._offline_queue.mark_attempted(item.id, error=str(exc))
                report.deferred += 1
                report.record_error(exc.error_code)
                report.stopped_early = True
                break
            except (NetworkError, RateLimitError, ServerError) as exc:
                # Transient: try again next drain.
                self._offline_queue.mark_attempted(item.id, error=str(exc))
                report.deferred += 1
                code = getattr(exc, "error_code", None)
                if isinstance(exc, NetworkError):
                    report.record_error("network_error")
                else:
                    report.record_error(code)
            except ValidationError as exc:
                # Permanent: the body itself is wrong (or signature is
                # bad). Mark + leave in place so the caller can inspect
                # via peek() and decide whether to delete or fix.
                self._offline_queue.mark_attempted(item.id, error=str(exc))
                report.failed += 1
                report.record_error(exc.error_code)
            else:
                self._offline_queue.delete(item.id)
                report.drained += 1
        return report

    @property
    def offline_queue(self) -> OfflineQueue | None:
        """The configured queue, or ``None`` if this client has no queue.

        Public read-only — useful for tests and for callers who want
        to inspect ``size()`` or ``peek()`` for diagnostics.
        """
        return self._offline_queue

    def _reject_in_offline_mode(self, op: str) -> None:
        """Raise :class:`OfflineError` if the client is in offline mode.

        Centralises the "this op needs a live Worker" gate so every
        non-publish method gets the same message and can branch on the
        same exception.
        """
        if self._offline_mode:
            msg = (
                f"{op}() cannot be served from the offline queue; "
                "construct a Client without offline_mode=True for read paths"
            )
            raise OfflineError(msg)

    def get(self, trace_id: str) -> TraceDetail:
        """Retrieve a trace + its amendments + counters by trace_id.

        The Worker bumps ``retrieved_count`` atomically on each call —
        this is the only path that does so (spec §2.3). Calling get()
        repeatedly is what surfaces a trace as "popular" in /search
        ranking via the helped/didnt_help differential.

        Raises :class:`~borg_collective.ValidationError` with
        ``status=404`` if the trace does not exist (or is private and
        the caller is not the owner — the Worker does not distinguish
        the two by design). Raises :class:`OfflineError` in offline
        mode (the queue can't serve fresh server state).
        """
        self._reject_in_offline_mode("get")
        raw = self._transport.request("GET", f"/api/v1/traces/{trace_id}")
        return TraceDetail.model_validate(raw)

    def add_amendment(
        self,
        trace_id: str,
        *,
        content: str,
        kind: AmendmentKind | str = AmendmentKind.CLARIFICATION,
    ) -> AmendmentCreated:
        """Append an amendment to an existing trace.

        v1 amendments are unsigned by design (spec §2 #7); the SDK's
        :class:`AmendmentInput` model rejects ``signature`` /
        ``signer_pubkey`` locally with a v2-feature message. This
        method takes ``content`` + ``kind`` only, mirroring that.

        Raises :class:`ValidationError` with ``status=404``
        ``error_code="trace_not_found"`` if the parent trace doesn't
        exist. Raises :class:`OfflineError` in offline mode —
        amendments target a server-side trace_id, which the offline
        client doesn't have.
        """
        self._reject_in_offline_mode("add_amendment")
        ai = AmendmentInput(content=content, kind=AmendmentKind(kind))
        raw = self._transport.request(
            "POST",
            f"/api/v1/traces/{trace_id}/amendments",
            json=ai.model_dump(mode="json"),
        )
        return AmendmentCreated.model_validate(raw)

    # ------------------------------------------------------------------
    # Search + feedback
    # ------------------------------------------------------------------

    def search(
        self,
        *,
        error_signature: str | None = None,
        query: str | None = None,
        error_class: str | None = None,
        tags: list[str] | None = None,
        limit: int = 10,
    ) -> SearchResults:
        """Search the federation for matching traces.

        At least one of ``error_signature``, ``query``, ``error_class``,
        or a non-empty ``tags`` list must be provided — empty
        ``tags=[]`` does NOT count, mirroring the Worker's
        ``no_query_provided`` guard (spec §2.2).

        Validation is performed locally via :class:`SearchRequest`
        before the request leaves the SDK; a malformed call raises
        ``pydantic.ValidationError`` synchronously. Raises
        :class:`OfflineError` in offline mode (no cached corpus).
        """
        self._reject_in_offline_mode("search")
        req = SearchRequest(
            error_signature=error_signature,
            query=query,
            error_class=error_class,
            tags=list(tags) if tags else [],
            limit=limit,
        )
        raw = self._transport.request(
            "POST",
            "/api/v1/search",
            json=req.model_dump(exclude_none=True, mode="json"),
        )
        return SearchResults.model_validate(raw)

    def feedback(
        self,
        trace_id: str,
        *,
        retrieved: bool = False,
        read: bool = False,
        applied: bool = False,
        outcome: FeedbackOutcome | str | None = None,
        note: str | None = None,
    ) -> FeedbackAck:
        """Record a feedback claim on a trace.

        Funnel monotonicity is enforced locally (spec §2.3):
        ``read=True`` requires ``retrieved=True``; ``applied=True``
        requires ``read=True``; ``outcome`` requires ``applied=True``.
        Violations raise ``pydantic.ValidationError`` before any
        network call.

        The Worker does NOT verify the claim — it stores the agent's
        attestation. Token-overlap verification is a Day 10 closure-
        test concern (spec §3.3), not this method's concern. Raises
        :class:`OfflineError` in offline mode — feedback's funnel
        guards depend on prior reads the queue cannot see.
        """
        self._reject_in_offline_mode("feedback")
        outcome_enum = FeedbackOutcome(outcome) if isinstance(outcome, str) else outcome
        req = FeedbackRequest(
            trace_id=trace_id,
            retrieved=retrieved,
            read=read,
            applied=applied,
            outcome=outcome_enum,
            note=note,
        )
        raw = self._transport.request(
            "POST",
            "/api/v1/feedback",
            json=req.model_dump(exclude_none=True, mode="json"),
        )
        return FeedbackAck.model_validate(raw)

    # ------------------------------------------------------------------
    # E0.7 review surface — list / patch / delete the caller's own traces
    # ------------------------------------------------------------------

    def list_my_traces(
        self,
        *,
        visibility: Visibility | str | None = None,
        limit: int = 20,
        before: int | None = None,
    ) -> MyTracesResponse:
        """List the caller's own traces (newest first).

        Backs ``borg review list``. ``visibility`` filters to public OR
        private; ``before`` is a ``created_at`` cursor for backwards
        pagination — use ``MyTracesResponse.next_before`` from the
        previous page. Soft-deleted traces are excluded server-side.
        """
        self._reject_in_offline_mode("list_my_traces")
        from urllib.parse import urlencode

        params: dict[str, str | int] = {"limit": limit}
        if visibility is not None:
            params["visibility"] = (
                visibility.value if isinstance(visibility, Visibility) else visibility
            )
        if before is not None:
            params["before"] = before
        qs = urlencode(params)
        raw = self._transport.request(
            "GET",
            f"/api/v1/agents/me/traces?{qs}",
        )
        return MyTracesResponse.model_validate(raw)

    def update_trace(
        self,
        trace_id: str,
        *,
        force_public: bool = False,
        **fields: Any,
    ) -> dict[str, Any]:
        """PATCH owner-only fields on a trace.

        Allowed fields: ``visibility``, ``error_class``, ``tags``,
        ``task_description``, ``root_cause``, ``technology``,
        ``context_snapshot``. The Worker rejects anything else as
        ``unexpected_field``.

        Promoting private → public requires ``force_public=True`` —
        this mirrors :meth:`publish` and is enforced server-side via
        the ``?force_public=true`` query parameter.
        """
        self._reject_in_offline_mode("update_trace")
        if not fields:
            msg = "update_trace() requires at least one field to update"
            raise ValueError(msg)
        url = f"/api/v1/traces/{trace_id}"
        if force_public:
            url += "?force_public=true"
        # Coerce enum values on the way out so Visibility.PUBLIC → "public".
        body: dict[str, Any] = {}
        for k, v in fields.items():
            body[k] = v.value if isinstance(v, Visibility) else v
        raw = self._transport.request("PATCH", url, json=body)
        return raw

    def delete_trace(self, trace_id: str) -> dict[str, Any]:
        """Soft-delete a trace. Idempotent: deleting twice is a no-op.

        Server sets ``deleted_at = unixepoch()`` and removes the row
        from search/stats. ``GET /traces/:id`` still resolves for the
        owner during the grace period; non-owners 404.
        """
        self._reject_in_offline_mode("delete_trace")
        raw = self._transport.request("DELETE", f"/api/v1/traces/{trace_id}")
        return raw
