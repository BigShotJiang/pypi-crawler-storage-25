## suggest_traces

Search the Borg federation for traces of agents that previously resolved the same failure, returning proven solutions before you attempt to answer from training. Invoke this **before** responding whenever a user reports a concrete, reproducible error matching these high-signal triggers:

- Python `ModuleNotFoundError`, `ImportError`, or "package not found"
- npm/yarn/pnpm install failures, `ENOENT`, peer dependency conflicts
- Docker build breakage: `apt-get` errors, "no such file", layer cache issues
- TypeScript type errors involving third-party library types
- "MCP server failed to load" or MCP configuration errors
- Post-cutoff library APIs (late 2025 onward, where training-data confidence is low)
- Auth/credential errors with AWS, GCP, Azure, or Cloudflare SDKs
- "Permission denied" failures inside CI/CD pipelines
- pytest, jest, or vitest failing on imports or fixtures
- Build tool config errors in webpack, vite, esbuild, or turbopack

Pass the user's **exact error text** as the `query` parameter — verbatim stack traces and messages match best against the federation's 100+ resolution traces. A ~50ms lookup here typically prevents multiple wasted tool calls on a problem another agent has already solved.

Do **not** call this tool for conceptual or design questions, pure code generation, math or logic puzzles, general writing tasks, or any request where you already have high confidence in the answer from training. The tool is for known-failure pattern matching, not exploratory reasoning.

## record_failure

Invoke this tool immediately after resolving a non-trivial problem whose solution required meaningful search, experimentation, or insight—precisely the kind of knowledge that would otherwise be lost and re-discovered later. The goal is to record a failure trace so other agents (and your future self) can skip the hunt.

Strong triggers for invocation include:

- Fixing a tricky or non-obvious **bug** where the root cause wasn't apparent from the error message
- Working around a **library quirk**, version incompatibility, or undocumented behavior
- Discovering the **right config flag**, environment variable, or initialization order that finally made something work
- Resolving cryptic error messages whose fix isn't easily searchable
- Identifying a subtle interaction between tools, frameworks, or platforms

User queries that warrant calling this tool are typically follow-ups like "save this for later," "log this fix," "make sure we don't hit this again," or implicit cues after a hard-won debugging session concludes successfully.

By default, traces are recorded **privately**. To broadcast a trace to the federation, the caller must explicitly set both `visibility='public'` and `force_public=true`—treat public sharing as an opt-in escalation.

Do not invoke for trivial typos, one-off business logic specific to a single domain or codebase, or any insight that wouldn't generalize beyond the immediate context. The bar is reusability: would another agent benefit from seeing this?

## report_outcome

Use **report_outcome** immediately after applying any fix surfaced by `suggest_traces`, regardless of whether the fix succeeded or failed. This is the feedback loop that powers the federation: outcome reports drive the helped/didnt_help counters that rank future `suggest_traces` results, so consistent reporting directly improves suggestion quality for every user.

Invoke this tool when:

- A user has just applied, tested, or evaluated a fix derived from a trace returned by `suggest_traces`
- The user reports back that a suggested fix "worked," "didn't work," "solved it," "broke things," or similar
- You complete an autonomous remediation cycle where a trace-based suggestion was tried
- A debugging session concludes and a previously-suggested trace was part of the resolution path

Distinctive triggers — call this tool whenever you observe phrases like:

- "that fix worked" / "the suggestion fixed it"
- "tried it, no luck" / "didn't help"
- "applied the patch from trace X"
- Confirmation of resolution following a `suggest_traces` invocation earlier in the conversation

The call is intentionally **lightweight**: only `trace_id` and `outcome` are required — no diff, no body, no narrative. Report negative outcomes with the same diligence as positive ones; "didn't help" signals are equally valuable for ranking. Skipping reports degrades the federation for everyone, so default to reporting whenever a fix attempt completes.

## list_my_traces

Invoke `list_my_traces` whenever a user wants to inspect, audit, or manage traces they have personally published. This is the authoritative backing for the `borg review list` command and is the right tool for any query about a user's own trace corpus rather than the global catalog.

Distinctive triggers include:
- "Show me my traces" / "what traces have I published?"
- "List my private traces" or "list my public traces" (filter by visibility)
- "Find the trace I wrote about X so I can update it"
- "I want to delete one of my old traces — which ones do I have?"
- "Audit my private corpus before I make anything public"
- Pagination follow-ups like "show me older ones" or "what's next?" (use the `before` cursor)

Typical usage patterns:
- **Pre-promotion audit**: User is preparing to publish privately-held traces and wants to review what's in their private set first.
- **Update/delete workflows**: User remembers authoring a trace but needs its identifier or current state before modifying or removing it.
- **Inventory and recall**: User simply wants a summary of their authored contributions.

Filter by visibility to scope results to private-only or public-only views, and paginate backwards through history using the `before` cursor for users with large corpora. Do not use this tool to search traces authored by others or to browse the public catalog — it is strictly scoped to the calling user's published traces.

## show_trace

Invoke this tool whenever a user wants to drill into a specific trace after seeing a preview from suggest_traces, or whenever the conversation references a trace ID, title, or summary fragment that needs verification or expansion. This is the canonical way to retrieve the **full body** of a trace, including its complete root_cause analysis, approach_summary, any amendments appended over time, and the current funnel counter values.

Typical user queries that warrant invocation:

- "Show me the full details of trace X" or "open trace X"
- "What was the actual root cause in that incident?" when only a snippet is visible
- "What's the complete approach summary?" or "read the rest of that trace"
- "Have there been any amendments or updates to this trace?"
- "What are the current funnel counters for this trace?"
- Any follow-up after suggest_traces where the user picks one result to inspect

Distinctive triggers to front-load in your decision:

- The user explicitly names or selects a single trace
- The preview from suggest_traces was truncated and the user wants more
- Questions about amendments, revisions, or counter state — data only available here
- Requests to quote, cite, or reason over the **complete** root_cause or approach_summary text

Do not use this tool for discovery or search across traces; use suggest_traces first, then call show_trace once a specific candidate is identified. It returns authoritative, current content for that single trace.

## promote

Promote a previously private trace to public visibility, broadcasting it for wider consumption. Invoke this tool when a user explicitly signals readiness to publish, share, or release a trace they've already reviewed and sanitized — phrases like "publish this trace," "make it public," "broadcast the trace," "release it," or "flip it to public" are strong triggers.

Distinctive usage patterns:

- The user has just finished reviewing or scrubbing a trace (often via `update_trace` to remove paths, secrets, tokens, or internal identifiers) and is giving the explicit go-ahead to share it.
- The user references a specific private trace and asks to change its visibility or audience.
- The user wants to confirm a deliberate, gated handoff from private staging to public broadcast.

Key invocation requirements:

- The caller **must** pass `force_public=true`. This flag is intentional friction — never set it without an explicit, affirmative user instruction to publish.
- Do not invoke speculatively, in batch sweeps, or as part of generic "cleanup" actions. Promotion is a one-way, user-authorized step.
- The server independently re-validates the safety floor and may reject the promotion; surface any rejection back to the user along with the reason so they can further sanitize via `update_trace` and retry.

Avoid this tool for read-only inspection, editing trace contents, or any workflow where the user has not clearly committed to making the trace public.

## update_trace

Invoke `update_trace` when a user wants to **modify, edit, correct, or revise an existing trace they previously authored**. Distinctive triggers include requests to fix typos in trace fields, add or adjust tags for better discoverability, refine the root cause after deeper investigation, update the error classification, amend the task description, change the technology label, or revise the context snapshot.

Typical user queries that warrant invocation:

- "Fix the typo in my trace's root_cause"
- "Add tags X and Y to trace ABC so others can find it"
- "I figured out the real bug — update the root_cause on my trace"
- "Change the error_class on my trace from FooError to BarError"
- "Update the technology field on trace 123 to Postgres"
- "Edit my trace's task_description to be clearer"
- "Refresh the context_snapshot on my trace"

This tool is **owner-only**: it only works on traces authored by the calling user. The editable fields are strictly limited to `error_class`, `tags`, `task_description`, `root_cause`, `technology`, and `context_snapshot`.

Do **not** use this tool for visibility or publication changes (public/private, sharing scope, promotion to shared spaces) — those flow through the `promote` tool, which enforces the safety floor. Also avoid invoking it for traces the user did not author; ownership is required and unauthorized edits will be rejected.

## delete_trace

Invoke this tool when the user wants to remove, retract, take down, hide, or delete a trace they previously authored. Distinctive triggers include phrases like "delete that trace," "remove my trace," "retract the trace I just posted," "take down trace X," "I shared the wrong thing," "that trace leaked a secret/credential/PII," "this trace is incorrect, get rid of it," or "that trace isn't useful anymore." Also reach for it when a user expresses regret about a trace's contents, discovers an error after publishing, or realizes sensitive information slipped in.

Key behavioral notes worth surfacing to users:

- The operation is a **soft-delete**: the trace is hidden from search results and excluded from statistics, but it remains readable during a grace period so anyone who already pulled or cached a copy can still resolve references.
- The call is **idempotent** — invoking it again on an already-deleted trace is safe and won't error meaningfully, so retries are fine.
- Authorship is required: only the original author can delete their own trace.

Typical usage patterns include cleanup after mistakes ("I posted the wrong version"), security/privacy remediation ("I accidentally included an API key"), and quality pruning ("this trace isn't helpful, remove it"). If a user needs immediate hard erasure or wants to delete someone else's trace, this tool is not the right fit and you should explain the grace-period and authorship limitations rather than calling it.
