"""Error signature — deterministic fingerprint of an error class.

Behavior-identical port of the Worker's `src/lib/error-signature.ts`.
Spec §1.1 says ``error_signature`` is the sha256 of *normalized*
``error_text``; we hash a struct (``error_class`` + normalized
``error_text`` + ``technology``) so two errors with identical text but
different ``error_class`` (e.g. ``python-import-error`` vs
``generic-error``) bucket separately.

Hash input — all three fields go through :func:`canonical_bytes` before
SHA-256:

* ``error_class``: lowercased string (None → '').
* ``error_text``: normalized (see below) — already lowercased.
* ``technology``: lowercased string (None → '').

Normalization order (matters):

1. Lowercase the whole string.
2. ``at line N`` → ``at line n``.
3. Bare ``line N`` → ``line n``.
4. ISO-8601 timestamp → ``iso-ts``  **(BEFORE :L:C)**.
5. ``:N:N`` (file-coord) → ``:lc``.
6. ``0x<hex>`` (memory addresses) → ``0xaddr``.
7. Bare digit run of length ≥ 10 → ``n``.
8. Whitespace runs collapse → single space, then strip.

The ISO rule must run **before** ``:L:C`` because an ISO like
``T15:30:45.123`` would otherwise have its ``:30:45`` chunk eaten by
the file-coord rule first, leaving the ISO regex nothing to match.

Changing this normalization invalidates every stored ``error_signature``
on every peer simultaneously — spec §5.4 calls it a v3-level decision.
"""

from __future__ import annotations

import hashlib
import re
from typing import Final

from borg_collective._canonical import canonical_bytes

__all__ = ["compute_error_signature", "normalize_error_text"]

# Compile-once regexes. Order is locked by the module docstring.
_RE_AT_LINE: Final[re.Pattern[str]] = re.compile(r"\bat line \d+\b")
_RE_LINE: Final[re.Pattern[str]] = re.compile(r"\bline \d+\b")
_RE_ISO: Final[re.Pattern[str]] = re.compile(r"\b\d{4}-\d{2}-\d{2}t\d{2}:\d{2}:\d{2}(?:\.\d+)?z?\b")
_RE_LC: Final[re.Pattern[str]] = re.compile(r":\d+:\d+\b")
_RE_HEX_ADDR: Final[re.Pattern[str]] = re.compile(r"\b0x[0-9a-f]+\b")
_RE_LONG_DIGITS: Final[re.Pattern[str]] = re.compile(r"\b\d{10,}\b")
_RE_WS: Final[re.Pattern[str]] = re.compile(r"\s+")


def normalize_error_text(text: str) -> str:
    """Apply the §1.1 normalization rules to ``text``.

    Exposed separately so tests can pin the normalization contract
    without going through the hash (which makes failures harder to
    read).
    """
    t = text.lower()
    t = _RE_AT_LINE.sub("at line n", t)
    t = _RE_LINE.sub("line n", t)
    t = _RE_ISO.sub("iso-ts", t)
    t = _RE_LC.sub(":lc", t)
    t = _RE_HEX_ADDR.sub("0xaddr", t)
    t = _RE_LONG_DIGITS.sub("n", t)
    return _RE_WS.sub(" ", t).strip()


def compute_error_signature(
    *,
    error_text: str,
    error_class: str | None = None,
    technology: str | None = None,
) -> str:
    """Return the 64-char lowercase hex error signature.

    Deterministic across identical normalized inputs regardless of
    caller-side casing on ``error_class``/``technology``.
    """
    payload = {
        "error_class": (error_class or "").lower(),
        "error_text": normalize_error_text(error_text),
        "technology": (technology or "").lower(),
    }
    return hashlib.sha256(canonical_bytes(payload)).hexdigest()
