"""Public exception hierarchy for the Borg Collective SDK.

Every exception inherits from :class:`BorgError`, so a single
``except BorgError`` clause catches all SDK-raised failures. Each subclass
carries the wire-level context a caller is likely to want to inspect
programmatically — HTTP status, Worker error code, retry hints — without
forcing them to parse messages.

Each ``__str__`` is engineered to be the message the developer sees in
their terminal when something goes wrong. The pattern is::

    <what happened> — <what to do next>

so a CLI traceback or a logger.exception line tells the developer which
side of the wire failed and points to the fix. Programmatic callers can
still inspect ``status``, ``error_code``, ``bucket``, ``retry_after_s``,
etc. directly.

Defense in depth: no exception in this module ever stores or repr()s an
``api_key``. The hex-only firewall and the model-level redaction
(``Agent.api_key``) are the primary protections; this module is the
last-line "even if a key somehow ended up here, it would not leak".

Status-code mapping to the Worker contract
------------------------------------------

* ``AuthError``       — HTTP 401 ``auth_required``, 403 ``invalid_key``.
* ``ValidationError`` — HTTP 400 (most caller-side errors: malformed body,
  missing/wrong-type fields, bad enums), HTTP 404 (``not_found``,
  ``trace_not_found``), and HTTP 422 (``bad_signature`` —
  surfaced as :class:`SignatureError`).
* ``RateLimitError``  — HTTP 429 ``rate_limit_exceeded`` (any bucket).
* ``NetworkError``    — transport-layer failures (timeouts, connection
  errors, DNS, HTTP 408).
* ``ServerError``     — HTTP 5xx.
* ``ConfigError``     — local: missing/invalid configuration before a
  request can be made (e.g. no api_key on a non-register call).
* ``OfflineError``    — local: a network operation was attempted while
  the SDK is in offline mode and the operation cannot be queued.
"""

from __future__ import annotations

from typing import Any, Final

# Worker error_code → human remediation hint. Keep this list short and
# focused on the codes a developer is most likely to hit during
# normal operation. The full code list lives in the Worker source;
# anything missing here surfaces as a generic message — still useful,
# just less hand-holding.
_VALIDATION_HINTS: Final[dict[str, str]] = {
    "missing_field": "the Worker rejected the request because a required field was absent",
    "empty_display_name": (
        "display_name must be a non-empty string " "(or omit it to get a generated default)"
    ),
    "display_name_too_long": "display_name exceeds the 64-char cap",
    "invalid_pubkey": "pubkey must be 64 lowercase hex chars (Ed25519 verify key)",
    "invalid_signature_hex": "signature must be 128 lowercase hex chars (Ed25519, 64 bytes)",
    "invalid_error_signature": "error_signature must be 64 lowercase hex chars",
    "bad_outcome": "outcome must be one of resolved, abandoned, escalated",
    "bad_visibility": "visibility must be public or private",
    "bad_kind": "amendment kind must be one of resolution, clarification, correction",
    "no_query_provided": (
        "search needs at least one of error_signature, query, error_class, " "or non-empty tags"
    ),
    "funnel_violation": (
        "feedback monotonicity violated: read requires retrieved; " "applied requires read"
    ),
    "outcome_requires_applied": "feedback outcome only applies after applied=True",
    "unexpected_field": "the request body had a field the Worker doesn't accept",
    "amendments_signing_v2": "amendment signing is a v2 feature; v1 amendments are unsigned",
    "signed_trace_requires_error_signature": (
        "signed publishes must include error_signature in the body so the Worker "
        "verifies the same canonical bytes the SDK signed"
    ),
    "signature_fields_incomplete": (
        "signature and signer_pubkey must both be present, or both absent"
    ),
    "not_found": "the trace_id does not exist (or is private and you are not the owner)",
    "trace_not_found": "the parent trace_id does not exist",
    "registration_collision": (
        "Worker hit a 1-in-2^256 api_key hash collision — retry once and tell us "
        "if it happens again, you found a bug or a cosmic ray"
    ),
    "id_collision": "Worker hit a trace_id collision — retry the publish",
}

__all__ = [
    "AuthError",
    "BorgError",
    "ConfigError",
    "NetworkError",
    "OfflineError",
    "OfflineQueueFull",
    "RateLimitError",
    "ServerError",
    "SignatureError",
    "ValidationError",
]


class BorgError(Exception):
    """Base class for every exception raised by the Borg Collective SDK.

    Catching :class:`BorgError` catches everything the SDK can raise on
    its own behalf. Subclasses add structured context fields (status,
    error_code, retry_after_s, …) for callers that branch on failure
    type.
    """

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self.message!r})"


class ConfigError(BorgError):
    """Local configuration is missing or invalid before any request runs.

    Raised, for example, when a request requires an api_key but none is
    configured on the client. Never reaches the network — by design,
    the SDK fails fast on missing config rather than letting the Worker
    return a 401/403.
    """


class AuthError(BorgError):
    """The Worker rejected the credential.

    Maps to HTTP 401 (``auth_required`` — header missing) or 403
    (``invalid_key`` — header present but does not resolve to an agent).
    The SDK does not distinguish the two beyond the ``status`` field;
    the Worker deliberately collapses malformed-shape and unknown-key
    onto 403 to avoid confirming whether a candidate key is well-formed.
    """

    def __init__(
        self,
        message: str,
        *,
        status: int,
        error_code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.error_code = error_code

    def __str__(self) -> str:
        if self.status == 401:
            return (
                f"{self.message} — X-API-Key header missing or empty. "
                "Pass api_key=... to Client(), set BORG_API_KEY in the env, "
                "or run `borg register` to mint one."
            )
        if self.status == 403:
            return (
                f"{self.message} — the Worker rejected the api_key. "
                "Check `borg whoami`, or re-run `borg register` to mint a fresh one."
            )
        return self.message

    def __repr__(self) -> str:
        return (
            f"AuthError(status={self.status}, error_code={self.error_code!r}, "
            f"message={self.message!r})"
        )


class ValidationError(BorgError):
    """The Worker rejected the request body or parameters.

    Covers HTTP 400 (malformed body, missing field, wrong type, bad
    enum, ``unexpected_field``, ``no_query_provided``,
    ``funnel_violation``, …) and HTTP 422 (``bad_signature`` — see
    :class:`SignatureError`). Both are "your request did not satisfy the
    Worker's contract"; the SDK uses one class because the caller's
    response is almost always identical (read the message, fix the
    request, retry) and the structured ``error_code`` field gives
    programmatic discriminability where needed.

    ``error_code`` is the Worker's machine-readable code from the
    response body (e.g. ``"missing_field"``, ``"bad_outcome"``,
    ``"bad_signature"``). May be ``None`` if the body could not be
    parsed.
    """

    def __init__(
        self,
        message: str,
        *,
        status: int,
        error_code: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.error_code = error_code
        self.details: dict[str, Any] = dict(details) if details else {}

    def __str__(self) -> str:
        hint = _VALIDATION_HINTS.get(self.error_code or "")
        # Surface the offending field if the Worker named one. Common
        # for missing_field, non_string_*, etc.
        field = self.details.get("field")
        field_part = f" (field: {field!r})" if isinstance(field, str) else ""
        if hint:
            return f"{self.message}{field_part} — {hint}"
        return f"{self.message}{field_part}"

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}(status={self.status}, "
            f"error_code={self.error_code!r}, message={self.message!r})"
        )


class SignatureError(ValidationError):
    """The Worker rejected a signed trace because the signature did not verify.

    Specifically maps to HTTP 422 with Worker code ``"bad_signature"``.

    By the time the request reaches this path the signature was hex-
    well-formed (the Worker's ``invalid_signature_hex`` 400 path catches
    shape failures); the cryptographic verify was the step that failed.
    The almost-always cause is **canonical-form drift**: the bytes the
    SDK signed differ from the bytes the Worker reconstructs from the
    submitted body. Common triggers are non-canonical key ordering
    upstream of the SDK's signer, mismatched tag/array element order,
    or a field that was mutated between signing and publish.

    The diagnostic hint is exposed in ``__repr__`` so it shows up in
    logs and tracebacks without callers having to know to ask.
    """

    HINT = "likely canonical-form drift between signed bytes and submitted body"

    def __init__(
        self,
        message: str = "signature did not verify",
        *,
        status: int = 422,
        error_code: str = "bad_signature",
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(
            message,
            status=status,
            error_code=error_code,
            details=details,
        )

    def __str__(self) -> str:
        return (
            f"{self.message} — {self.HINT}. "
            "Check that signing_key.verify_key_hex matches the agent's "
            "registered pubkey, and that no field was mutated between "
            "signing and publish."
        )

    def __repr__(self) -> str:
        return (
            f"SignatureError(status={self.status}, "
            f"error_code={self.error_code!r}, "
            f"message={self.message!r}, hint={self.HINT!r})"
        )


class RateLimitError(BorgError):
    """The Worker rate-limited the request.

    Maps to HTTP 429 ``rate_limit_exceeded``. Carries the Worker's
    ``Retry-After`` value (in seconds) and the bucket name so callers
    can implement bucket-aware backoff (the publish bucket is per-agent
    while the auth-fail bucket is per-IP — backing off the wrong key
    is wasted wait).
    """

    def __init__(
        self,
        message: str,
        *,
        retry_after_s: int,
        bucket: str,
        status: int = 429,
    ) -> None:
        super().__init__(message)
        self.retry_after_s = retry_after_s
        self.bucket = bucket
        self.status = status

    def __str__(self) -> str:
        return (
            f"{self.message} — bucket={self.bucket!r}, retry_after={self.retry_after_s}s. "
            "The SDK does not auto-retry 429s; sleep then retry, or back off "
            "the agent that hit the cap."
        )

    def __repr__(self) -> str:
        return (
            f"RateLimitError(bucket={self.bucket!r}, "
            f"retry_after_s={self.retry_after_s}, "
            f"status={self.status}, message={self.message!r})"
        )


class NetworkError(BorgError):
    """The request could not reach the Worker, or the response was unreadable.

    Covers connection errors, DNS failures, TLS failures, read
    timeouts, and HTTP 408. ``cause`` carries the underlying exception
    if one is available, for callers that want the gory details.
    """

    def __init__(
        self,
        message: str,
        *,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.cause = cause

    def __str__(self) -> str:
        return (
            f"{self.message} — the SDK could not reach the Worker. "
            "Check base_url (default: borg-collective-v1.borg-farther.workers.dev), "
            "your network, or wait if the host is briefly unreachable."
        )

    def __repr__(self) -> str:
        cause_name = type(self.cause).__name__ if self.cause is not None else None
        return f"NetworkError(message={self.message!r}, cause={cause_name})"


class ServerError(BorgError):
    """The Worker returned a 5xx.

    The SDK classifies 5xx as "the Worker had a problem" and does not
    retry automatically — callers can decide retry policy based on the
    operation's idempotency. ``error_code`` is the Worker's code if the
    body parsed (e.g. ``"id_collision"``, ``"internal"``).
    """

    def __init__(
        self,
        message: str,
        *,
        status: int,
        error_code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.error_code = error_code

    def __str__(self) -> str:
        return (
            f"{self.message} — Worker returned {self.status}. "
            "Not auto-retried; safe-to-retry depends on the operation's idempotency "
            "(publish + amendment are NOT idempotent)."
        )

    def __repr__(self) -> str:
        return (
            f"ServerError(status={self.status}, "
            f"error_code={self.error_code!r}, message={self.message!r})"
        )


class OfflineError(BorgError):
    """The SDK is in offline mode and the operation cannot be queued.

    Raised when ``offline_mode=True`` on a client and the caller
    invokes an operation the offline queue does not support (e.g. a
    GET that needs a fresh server response). Operations the queue
    does support (publish) are silently enqueued instead of raising.
    """


class OfflineQueueFull(OfflineError):  # noqa: N818
    """The offline queue is at its configured ``max_size`` cap.

    Raised by :meth:`borg_collective._offline.OfflineQueue.enqueue`
    when the queue would exceed ``max_size``. Carries the configured
    cap and the current size so callers can decide between dropping
    the trace, blocking, or rotating to a fresh queue file.

    Subclass of :class:`OfflineError` so a single
    ``except OfflineError`` clause catches both "offline mode rejects
    this op" and "queue is full" — the caller's response is usually
    identical (back off, surface to the user).
    """

    def __init__(self, message: str, *, max_size: int, current_size: int) -> None:
        super().__init__(message)
        self.max_size = max_size
        self.current_size = current_size

    def __repr__(self) -> str:
        return (
            f"OfflineQueueFull(max_size={self.max_size}, "
            f"current_size={self.current_size}, message={self.message!r})"
        )
