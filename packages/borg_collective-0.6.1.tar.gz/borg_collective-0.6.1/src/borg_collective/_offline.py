"""Persistent offline queue for pending publish operations.

Internal module — public surface is the :class:`OfflineQueue` class
plus the :class:`QueuedItem` and :class:`DrainReport` value types.
The :class:`borg_collective.Client` constructor wires this up via
``offline_mode=True`` (always-enqueue) or via ``offline_queue_path``
(enqueue-on-NetworkError fallback).

Storage model
-------------

Single SQLite file in WAL journal mode. One table, ``pending_traces``:

* ``id``                INTEGER PRIMARY KEY AUTOINCREMENT
* ``agent_id``          TEXT NOT NULL
* ``payload``           TEXT NOT NULL  (JSON-encoded publish body)
* ``created_at``        INTEGER NOT NULL  (unix epoch seconds)
* ``attempt_count``     INTEGER NOT NULL DEFAULT 0
* ``last_attempt_at``   INTEGER  (nullable)
* ``last_error``        TEXT  (nullable; truncated to 500 chars)

WAL mode is non-negotiable:

* readers (``peek``) don't block the writer (``enqueue``);
* a crashed process leaves a recoverable journal — SQLite cleans up on
  the next open;
* multiple Client instances in the same process can share one queue
  file safely, because we ``check_same_thread=False`` and serialise
  with a per-instance threading.Lock.

Hex-only firewall
-----------------

The queue is content-agnostic. Payloads contain whatever the caller
gave us — including 64-char ``signer_pubkey`` and 128-char
``signature`` hex strings. We never decode, re-encode, or reformat
them; ``json.dumps(payload, separators=(",", ":"))`` is the only
serialization step. Anything that round-trips through SQLite as TEXT
comes back byte-identical.
"""

from __future__ import annotations

import contextlib
import json
import os
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Final, Self

from .exceptions import OfflineQueueFull

__all__ = [
    "DEFAULT_OFFLINE_QUEUE_PATH",
    "DrainReport",
    "OfflineQueue",
    "QueuedItem",
]

# Default location for the offline queue. ``~/.borg/offline_queue.sqlite``
# matches the spec preamble; the directory is created on first use.
DEFAULT_OFFLINE_QUEUE_PATH: Final[Path] = Path.home() / ".borg" / "offline_queue.sqlite"

# 500-char cap on stored error messages. Rationale: the queue is a
# debugging aid, not an audit log; full stack traces belong elsewhere.
_LAST_ERROR_MAX: Final[int] = 500

# DDL is in one place so opening twice always converges. No ALTER TABLE
# in v0.1.0 — schema migrations are a v2 surface.
_SCHEMA_DDL: Final[str] = """
CREATE TABLE IF NOT EXISTS pending_traces (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id        TEXT NOT NULL,
    payload         TEXT NOT NULL,
    created_at      INTEGER NOT NULL,
    attempt_count   INTEGER NOT NULL DEFAULT 0,
    last_attempt_at INTEGER,
    last_error      TEXT
);

CREATE INDEX IF NOT EXISTS idx_pending_attempt_id
    ON pending_traces (attempt_count ASC, id ASC);
"""


@dataclass(frozen=True)
class QueuedItem:
    """One row from the offline queue, immutable post-fetch.

    ``id`` is the autoincrement queue id (NOT a wire field — never
    surface it as a trace_id; Client.publish in offline mode hands the
    caller a sentinel ``"local:{id}"`` instead).
    """

    id: int
    agent_id: str
    payload: dict[str, Any]
    created_at: int
    attempt_count: int
    last_attempt_at: int | None
    last_error: str | None


@dataclass
class DrainReport:
    """Result of :meth:`borg_collective.Client.drain`.

    * ``drained``          — items that successfully published.
    * ``failed``            — items that hit a permanent failure
      (4xx other than 429); they remain in the queue so the caller can
      inspect ``OfflineQueue.peek()`` and decide what to do.
    * ``deferred``          — items that hit a transient failure (5xx,
      429, NetworkError); ``mark_attempted`` was called so the next
      drain re-tries them.
    * ``errors_by_signature`` — mapping ``error_code`` → count, useful
      for surfacing "all our drains failed because the api_key is
      wrong" rather than reporting one error 47 times.
    * ``stopped_early`` — True if the drain aborted because of a
      systemic failure (auth error). Caller should inspect and fix.
    """

    drained: int = 0
    failed: int = 0
    deferred: int = 0
    errors_by_signature: dict[str, int] = field(default_factory=dict)
    stopped_early: bool = False

    def record_error(self, error_code: str | None) -> None:
        """Bump the count for ``error_code`` (or ``"unknown"``)."""
        key = error_code or "unknown"
        self.errors_by_signature[key] = self.errors_by_signature.get(key, 0) + 1


class OfflineQueue:
    """A persistent FIFO queue of pending publish operations.

    Construction:

        >>> from pathlib import Path
        >>> q = OfflineQueue(Path("/tmp/queue.sqlite"))
        >>> q.enqueue("agent-x", {"error_text": "..."})  # doctest: +SKIP
        >>> for item in q.peek(10):  # doctest: +SKIP
        ...     ...

    Thread-safe: a single :class:`OfflineQueue` instance can be used
    from multiple threads concurrently. Across processes, SQLite's
    WAL mode handles concurrency at the file level — but each process
    should construct its own ``OfflineQueue`` rather than sharing a
    Python instance.
    """

    def __init__(
        self,
        path: Path | str,
        *,
        max_size: int = 10_000,
    ) -> None:
        if max_size < 1:
            msg = f"max_size must be >= 1, got {max_size}"
            raise ValueError(msg)
        self._path = Path(path)
        self._max_size = max_size
        # Create the parent directory if missing. Idempotent. We touch
        # the dir not the file — SQLite creates the file on first
        # connect and would error on a missing directory.
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._closed = False
        # check_same_thread=False because callers may .enqueue from
        # one thread and .drain from another. We serialise with the
        # lock above; SQLite itself is fine cross-thread when we own
        # the access path.
        self._conn = sqlite3.connect(
            str(self._path),
            check_same_thread=False,
            isolation_level=None,  # autocommit; we manage transactions explicitly
        )
        try:
            self._conn.executescript("PRAGMA journal_mode=WAL;")
            # foreign_keys is off by default; we have no FKs here, so
            # leave it off to avoid surprises.
            self._conn.executescript(_SCHEMA_DDL)
        except sqlite3.Error:
            self._conn.close()
            raise

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()

    def close(self) -> None:
        """Close the SQLite connection. Idempotent."""
        with self._lock:
            if self._closed:
                return
            self._closed = True
            # Already closed by SQLite itself, or transient close race —
            # either way nothing useful to do.
            with contextlib.suppress(sqlite3.Error):
                self._conn.close()

    @property
    def path(self) -> Path:
        return self._path

    @property
    def max_size(self) -> int:
        return self._max_size

    # ------------------------------------------------------------------
    # Core operations
    # ------------------------------------------------------------------

    def enqueue(self, agent_id: str, payload: dict[str, Any]) -> int:
        """Enqueue a publish payload. Returns the new queue id.

        Raises :class:`OfflineQueueFull` if the queue is already at
        ``max_size``. The check + insert is atomic under the
        per-instance lock, so two concurrent callers cannot both win
        the last slot.
        """
        if self._closed:
            msg = "OfflineQueue is closed"
            raise RuntimeError(msg)
        body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
        now = int(time.time())
        with self._lock:
            cur = self._conn.execute("SELECT COUNT(*) FROM pending_traces")
            current = int(cur.fetchone()[0])
            if current >= self._max_size:
                msg = (
                    f"offline queue is full ({current} of {self._max_size}); "
                    "drain or rotate before enqueueing"
                )
                raise OfflineQueueFull(msg, max_size=self._max_size, current_size=current)
            cur = self._conn.execute(
                "INSERT INTO pending_traces " "(agent_id, payload, created_at) VALUES (?, ?, ?)",
                (agent_id, body, now),
            )
            new_id = cur.lastrowid
            assert new_id is not None  # autoincrement always returns
            return new_id

    def peek(
        self,
        limit: int = 10,
        *,
        agent_id: str | None = None,
    ) -> list[QueuedItem]:
        """Return up to ``limit`` items in drain order.

        Drain order is ``(attempt_count ASC, id ASC)`` — fresh items
        first, then anything previously deferred (so a poison row
        doesn't head-of-line-block fresh traffic forever).

        ``agent_id``, when supplied, filters to that agent only — used
        by :meth:`Client.drain` to drain only what the configured
        api_key can authenticate as.
        """
        if self._closed:
            msg = "OfflineQueue is closed"
            raise RuntimeError(msg)
        if limit < 1:
            msg = f"limit must be >= 1, got {limit}"
            raise ValueError(msg)
        with self._lock:
            if agent_id is None:
                cur = self._conn.execute(
                    "SELECT id, agent_id, payload, created_at, attempt_count, "
                    "last_attempt_at, last_error "
                    "FROM pending_traces "
                    "ORDER BY attempt_count ASC, id ASC "
                    "LIMIT ?",
                    (limit,),
                )
            else:
                cur = self._conn.execute(
                    "SELECT id, agent_id, payload, created_at, attempt_count, "
                    "last_attempt_at, last_error "
                    "FROM pending_traces "
                    "WHERE agent_id = ? "
                    "ORDER BY attempt_count ASC, id ASC "
                    "LIMIT ?",
                    (agent_id, limit),
                )
            rows = cur.fetchall()
        out: list[QueuedItem] = []
        for row in rows:
            payload_obj: Any = json.loads(row[2])
            if not isinstance(payload_obj, dict):
                # Defensive: payload column is always written as a JSON
                # object. If somehow it isn't, skip rather than crash —
                # the caller's drain loop continues.
                continue
            out.append(
                QueuedItem(
                    id=int(row[0]),
                    agent_id=str(row[1]),
                    payload=payload_obj,
                    created_at=int(row[3]),
                    attempt_count=int(row[4]),
                    last_attempt_at=int(row[5]) if row[5] is not None else None,
                    last_error=row[6] if row[6] is not None else None,
                )
            )
        return out

    def mark_attempted(
        self,
        queue_id: int,
        error: str | None = None,
    ) -> None:
        """Increment ``attempt_count`` and record the latest error.

        Called by :meth:`Client.drain` after a transient failure
        (5xx / 429 / NetworkError). The row stays in the queue and
        will be retried on the next drain — but ``attempt_count`` is
        the secondary sort key in :meth:`peek`, so heavily-failed rows
        drift to the end of the line behind fresh traffic.
        """
        if self._closed:
            msg = "OfflineQueue is closed"
            raise RuntimeError(msg)
        truncated_error = error[:_LAST_ERROR_MAX] if error else None
        now = int(time.time())
        with self._lock:
            self._conn.execute(
                "UPDATE pending_traces "
                "SET attempt_count = attempt_count + 1, "
                "    last_attempt_at = ?, "
                "    last_error = ? "
                "WHERE id = ?",
                (now, truncated_error, queue_id),
            )

    def delete(self, queue_id: int) -> None:
        """Remove a row from the queue. Used after a successful publish."""
        if self._closed:
            msg = "OfflineQueue is closed"
            raise RuntimeError(msg)
        with self._lock:
            self._conn.execute(
                "DELETE FROM pending_traces WHERE id = ?",
                (queue_id,),
            )

    def size(self, *, agent_id: str | None = None) -> int:
        """Return the number of pending rows, optionally per-agent."""
        if self._closed:
            msg = "OfflineQueue is closed"
            raise RuntimeError(msg)
        with self._lock:
            if agent_id is None:
                cur = self._conn.execute("SELECT COUNT(*) FROM pending_traces")
            else:
                cur = self._conn.execute(
                    "SELECT COUNT(*) FROM pending_traces WHERE agent_id = ?",
                    (agent_id,),
                )
            return int(cur.fetchone()[0])

    def fsync(self) -> None:
        """Force fsync on the underlying SQLite WAL.

        Public for callers that need a hard durability barrier — e.g.
        just before a process exit. Internal callers don't need this;
        SQLite WAL syncs on commit boundaries already. Idempotent on a
        closed queue (no-op).
        """
        if self._closed:
            return
        # SQLite's "PRAGMA wal_checkpoint(FULL)" forces the WAL
        # contents back into the main DB file and fsyncs.
        with self._lock:
            self._conn.execute("PRAGMA wal_checkpoint(FULL)")
            # And one more fsync at the FS level for paranoia. The WAL
            # checkpoint already issued one but this covers any FS that
            # buffers metadata separately. fsync mid-flight on SQLite
            # can fail on some filesystems — that's acceptable; the
            # WAL checkpoint is the primary durability barrier.
            with contextlib.suppress(OSError):
                fd = os.open(str(self._path), os.O_RDONLY)
                try:
                    os.fsync(fd)
                finally:
                    os.close(fd)

    def __repr__(self) -> str:
        return (
            f"OfflineQueue(path={str(self._path)!r}, "
            f"max_size={self._max_size}, "
            f"closed={self._closed})"
        )
