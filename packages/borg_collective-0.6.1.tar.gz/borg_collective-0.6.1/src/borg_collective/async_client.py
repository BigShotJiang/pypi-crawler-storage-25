"""Asynchronous high-level client for the Borg Collective Worker.

:class:`AsyncClient` mirrors :class:`borg_collective.client.Client`
exactly in behaviour and surface — same method names, same signatures,
same return types, same exceptions. The only difference is that every
method is awaitable and the underlying transport is
:class:`borg_collective._transport.AsyncTransport`.

Construction:

    >>> import asyncio
    >>> from borg_collective import AsyncClient
    >>> async def main() -> None:
    ...     async with AsyncClient(api_key="...") as c:
    ...         me = await c.whoami()
    ...         print(me.agent_id, me.trust_level)
    >>> asyncio.run(main())

Where the docstring on a sync method explains *why* (rate-limit
posture, signing flow, funnel monotonicity, offline gate), this
module's docstrings are intentionally terse — the contract is
identical and split docs rot fast. Read ``client.py`` for the prose;
this module is the awaitable mirror.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Self

from ._offline import DEFAULT_OFFLINE_QUEUE_PATH, DrainReport, OfflineQueue
from ._transport import (
    DEFAULT_BACKOFF_BASE_S,
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    AsyncTransport,
)
from .client import _stub_published_for_queue, load_borg_config, prepare_signed_body
from .exceptions import (
    AuthError,
    ConfigError,
    NetworkError,
    OfflineError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .models import (
    Agent,
    AgentInfo,
    AgentPubkey,
    AmendmentCreated,
    AmendmentInput,
    AmendmentKind,
    FailureTrace,
    FeedbackAck,
    FeedbackOutcome,
    FeedbackRequest,
    MyTracesResponse,
    PublishedTrace,
    SearchRequest,
    SearchResults,
    TraceDetail,
    Visibility,
)

if TYPE_CHECKING:
    from pathlib import Path

    import httpx

    from ._signing import SigningKeyPair

__all__ = ["AsyncClient"]

_OFFLINE_AGENT_PLACEHOLDER = "offline:unknown"


class AsyncClient:
    """Asynchronous mirror of :class:`Client`. See ``client.py``."""

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: httpx.Timeout = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        backoff_base_s: float = DEFAULT_BACKOFF_BASE_S,
        transport: AsyncTransport | None = None,
        offline_mode: bool = False,
        offline_queue_path: Path | str | None = None,
        offline_queue: OfflineQueue | None = None,
    ) -> None:
        if transport is not None:
            self._transport = transport
            self._owns_transport = False
        else:
            self._transport = AsyncTransport(
                api_key=api_key,
                base_url=base_url,
                timeout=timeout,
                max_retries=max_retries,
                backoff_base_s=backoff_base_s,
            )
            self._owns_transport = True

        self._offline_mode = offline_mode
        if offline_queue is not None:
            self._offline_queue: OfflineQueue | None = offline_queue
            self._owns_queue = False
        elif offline_queue_path is not None:
            self._offline_queue = OfflineQueue(offline_queue_path)
            self._owns_queue = True
        elif offline_mode:
            self._offline_queue = OfflineQueue(DEFAULT_OFFLINE_QUEUE_PATH)
            self._owns_queue = True
        else:
            self._offline_queue = None
            self._owns_queue = False

    @classmethod
    def from_config(cls, **overrides: Any) -> Self:
        """Async mirror of :meth:`Client.from_config`. See ``client.py``."""
        cfg = load_borg_config()
        if "api_key" not in overrides:
            overrides["api_key"] = cfg["api_key"]
        if "base_url" not in overrides:
            overrides["base_url"] = cfg["base_url"]
        if overrides["api_key"] is None:
            msg = (
                "no api_key found in $BORG_API_KEY or ~/.borg/config.toml. "
                "Run `borg register` once, or set BORG_API_KEY."
            )
            raise ConfigError(msg)
        return cls(**overrides)

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        """Close the underlying async transport + queue, if owned."""
        if self._owns_transport:
            await self._transport.aclose()
        if self._owns_queue and self._offline_queue is not None:
            self._offline_queue.close()

    def __repr__(self) -> str:
        return f"AsyncClient(transport={self._transport!r})"

    @property
    def offline_queue(self) -> OfflineQueue | None:
        """The configured offline queue, or ``None`` if no queue is wired."""
        return self._offline_queue

    def _reject_in_offline_mode(self, op: str) -> None:
        """Raise :class:`OfflineError` if the client is in offline mode."""
        if self._offline_mode:
            msg = (
                f"{op}() cannot be served from the offline queue; "
                "construct an AsyncClient without offline_mode=True for read paths"
            )
            raise OfflineError(msg)

    # ------------------------------------------------------------------
    # Agent identity
    # ------------------------------------------------------------------

    async def register_agent(
        self,
        *,
        display_name: str | None = None,
        pubkey: str | None = None,
    ) -> Agent:
        """Register a new agent. Async mirror of :meth:`Client.register_agent`."""
        self._reject_in_offline_mode("register_agent")
        body: dict[str, Any] = {}
        if display_name is not None:
            body["display_name"] = display_name
        if pubkey is not None:
            body["pubkey"] = pubkey
        raw = await self._transport.request(
            "POST",
            "/api/v1/agents",
            json=body,
            auth_required=False,
        )
        return Agent.model_validate(raw)

    async def whoami(self) -> AgentInfo:
        """Async mirror of :meth:`Client.whoami`."""
        self._reject_in_offline_mode("whoami")
        raw = await self._transport.request("GET", "/api/v1/agents/me")
        return AgentInfo.model_validate(raw)

    async def rotate_pubkey(self, pubkey: str) -> AgentPubkey:
        """Async mirror of :meth:`Client.rotate_pubkey`."""
        self._reject_in_offline_mode("rotate_pubkey")
        raw = await self._transport.request(
            "POST",
            "/api/v1/agents/me/pubkey",
            json={"pubkey": pubkey},
        )
        return AgentPubkey.model_validate(raw)

    # ------------------------------------------------------------------
    # Trace publish + retrieve
    # ------------------------------------------------------------------

    async def publish(
        self,
        trace: FailureTrace | dict[str, Any],
        *,
        signing_key: SigningKeyPair | None = None,
        force_public: bool = False,
    ) -> PublishedTrace:
        """Async mirror of :meth:`Client.publish`. Honours offline mode.

        Mirrors the sync ``force_public`` safety floor (E0.5): a trace
        constructed with ``Visibility.PUBLIC`` is rejected unless
        ``force_public=True`` is also passed; a private-default trace
        with ``force_public=True`` flips on the wire.
        """
        ft = trace if isinstance(trace, FailureTrace) else FailureTrace.model_validate(trace)
        if ft.visibility == Visibility.PUBLIC and not force_public:
            msg = (
                "Trace constructed with Visibility.PUBLIC requires force_public=True "
                "to publish. This safeguard prevents accidental public publishes. "
                "If intentional, call: client.publish(trace, force_public=True)"
            )
            raise ValueError(msg)
        body = ft.model_dump(exclude_none=True, mode="json")
        if force_public and ft.visibility == Visibility.PRIVATE:
            body["visibility"] = Visibility.PUBLIC.value
        if signing_key is not None:
            body = prepare_signed_body(body, signing_key)

        if self._offline_mode:
            assert self._offline_queue is not None  # invariant from __init__
            queue_id = self._offline_queue.enqueue(_OFFLINE_AGENT_PLACEHOLDER, body)
            return _stub_published_for_queue(body, queue_id)

        try:
            raw = await self._transport.request("POST", "/api/v1/traces", json=body)
        except NetworkError:
            if self._offline_queue is not None:
                self._offline_queue.enqueue(_OFFLINE_AGENT_PLACEHOLDER, body)
            raise
        return PublishedTrace.model_validate(raw)

    async def drain(self, *, max_items: int = 100) -> DrainReport:
        """Async mirror of :meth:`Client.drain`.

        Identical semantics — see ``client.py`` for the prose. AuthError
        stops the drain immediately; transient failures defer; permanent
        failures count as failed.
        """
        if self._offline_queue is None:
            msg = "drain() requires an offline_queue_path or offline_mode=True"
            raise OfflineError(msg)
        if max_items < 1:
            msg = f"max_items must be >= 1, got {max_items}"
            raise ValueError(msg)

        report = DrainReport()
        items = self._offline_queue.peek(limit=max_items)
        for item in items:
            try:
                await self._transport.request("POST", "/api/v1/traces", json=item.payload)
            except AuthError as exc:
                self._offline_queue.mark_attempted(item.id, error=str(exc))
                report.deferred += 1
                report.record_error(exc.error_code)
                report.stopped_early = True
                break
            except (NetworkError, RateLimitError, ServerError) as exc:
                self._offline_queue.mark_attempted(item.id, error=str(exc))
                report.deferred += 1
                code = getattr(exc, "error_code", None)
                if isinstance(exc, NetworkError):
                    report.record_error("network_error")
                else:
                    report.record_error(code)
            except ValidationError as exc:
                self._offline_queue.mark_attempted(item.id, error=str(exc))
                report.failed += 1
                report.record_error(exc.error_code)
            else:
                self._offline_queue.delete(item.id)
                report.drained += 1
        return report

    async def get(self, trace_id: str) -> TraceDetail:
        """Async mirror of :meth:`Client.get`."""
        self._reject_in_offline_mode("get")
        raw = await self._transport.request("GET", f"/api/v1/traces/{trace_id}")
        return TraceDetail.model_validate(raw)

    async def add_amendment(
        self,
        trace_id: str,
        *,
        content: str,
        kind: AmendmentKind | str = AmendmentKind.CLARIFICATION,
    ) -> AmendmentCreated:
        """Async mirror of :meth:`Client.add_amendment`."""
        self._reject_in_offline_mode("add_amendment")
        ai = AmendmentInput(content=content, kind=AmendmentKind(kind))
        raw = await self._transport.request(
            "POST",
            f"/api/v1/traces/{trace_id}/amendments",
            json=ai.model_dump(mode="json"),
        )
        return AmendmentCreated.model_validate(raw)

    # ------------------------------------------------------------------
    # Search + feedback
    # ------------------------------------------------------------------

    async def search(
        self,
        *,
        error_signature: str | None = None,
        query: str | None = None,
        error_class: str | None = None,
        tags: list[str] | None = None,
        limit: int = 10,
    ) -> SearchResults:
        """Async mirror of :meth:`Client.search`."""
        self._reject_in_offline_mode("search")
        req = SearchRequest(
            error_signature=error_signature,
            query=query,
            error_class=error_class,
            tags=list(tags) if tags else [],
            limit=limit,
        )
        raw = await self._transport.request(
            "POST",
            "/api/v1/search",
            json=req.model_dump(exclude_none=True, mode="json"),
        )
        return SearchResults.model_validate(raw)

    async def feedback(
        self,
        trace_id: str,
        *,
        retrieved: bool = False,
        read: bool = False,
        applied: bool = False,
        outcome: FeedbackOutcome | str | None = None,
        note: str | None = None,
    ) -> FeedbackAck:
        """Async mirror of :meth:`Client.feedback`."""
        self._reject_in_offline_mode("feedback")
        outcome_enum = FeedbackOutcome(outcome) if isinstance(outcome, str) else outcome
        req = FeedbackRequest(
            trace_id=trace_id,
            retrieved=retrieved,
            read=read,
            applied=applied,
            outcome=outcome_enum,
            note=note,
        )
        raw = await self._transport.request(
            "POST",
            "/api/v1/feedback",
            json=req.model_dump(exclude_none=True, mode="json"),
        )
        return FeedbackAck.model_validate(raw)

    # ------------------------------------------------------------------
    # E0.7 review surface — mirrored from sync Client (E1.1 port).
    # ------------------------------------------------------------------

    async def list_my_traces(
        self,
        *,
        visibility: Visibility | str | None = None,
        limit: int = 20,
        before: int | None = None,
    ) -> MyTracesResponse:
        """Async mirror of :meth:`Client.list_my_traces`."""
        self._reject_in_offline_mode("list_my_traces")
        from urllib.parse import urlencode

        params: dict[str, str | int] = {"limit": limit}
        if visibility is not None:
            params["visibility"] = (
                visibility.value if isinstance(visibility, Visibility) else visibility
            )
        if before is not None:
            params["before"] = before
        qs = urlencode(params)
        raw = await self._transport.request(
            "GET",
            f"/api/v1/agents/me/traces?{qs}",
        )
        return MyTracesResponse.model_validate(raw)

    async def update_trace(
        self,
        trace_id: str,
        *,
        force_public: bool = False,
        **fields: Any,
    ) -> dict[str, Any]:
        """Async mirror of :meth:`Client.update_trace`."""
        self._reject_in_offline_mode("update_trace")
        if not fields:
            msg = "update_trace() requires at least one field to update"
            raise ValueError(msg)
        url = f"/api/v1/traces/{trace_id}"
        if force_public:
            url += "?force_public=true"
        body: dict[str, Any] = {}
        for k, v in fields.items():
            body[k] = v.value if isinstance(v, Visibility) else v
        return await self._transport.request("PATCH", url, json=body)  # type: ignore[no-any-return]

    async def delete_trace(self, trace_id: str) -> dict[str, Any]:
        """Async mirror of :meth:`Client.delete_trace`. Soft-delete; idempotent."""
        self._reject_in_offline_mode("delete_trace")
        return await self._transport.request("DELETE", f"/api/v1/traces/{trace_id}")  # type: ignore[no-any-return]
