"""Python SDK for the Borg Collective failure-trace federation registry.

Public API surface — only names re-exported here are stable. Anything
imported through underscore-prefixed modules (``_canonical``, ``_signing``,
``_transport``, ``_idempotency``, ``_offline``) is internal and may
change without notice.

Commit 4c expands the surface with the offline queue (DrainReport,
OfflineQueue, OfflineQueueFull) and the public testing module
(borg_collective.testing — FakeClient, FakeAsyncClient).
"""

from __future__ import annotations

from borg_collective._bridge import (
    AutoPublishConfig,
    DrainResult,
    PublishResult,
    drain_queue,
    load_auto_publish_config,
    publish_to_federation,
)
from borg_collective._offline import DrainReport, OfflineQueue
from borg_collective._signing import SigningKeyPair
from borg_collective._version import __version__
from borg_collective.async_client import AsyncClient
from borg_collective.client import Client, load_borg_config
from borg_collective.exceptions import (
    AuthError,
    BorgError,
    ConfigError,
    NetworkError,
    OfflineError,
    OfflineQueueFull,
    RateLimitError,
    ServerError,
    SignatureError,
    ValidationError,
)
from borg_collective.models import (
    Agent,
    AgentInfo,
    AgentPubkey,
    Amendment,
    AmendmentCreated,
    AmendmentInput,
    AmendmentKind,
    Counters,
    FailureTrace,
    FeedbackAck,
    FeedbackOutcome,
    FeedbackRequest,
    MatchMode,
    Outcome,
    Provenance,
    PublishedTrace,
    SearchRequest,
    SearchResult,
    SearchResults,
    Trace,
    TraceDetail,
    TrustLevel,
    Visibility,
)

__all__ = [
    "Agent",
    "AgentInfo",
    "AgentPubkey",
    "Amendment",
    "AmendmentCreated",
    "AmendmentInput",
    "AmendmentKind",
    "AsyncClient",
    "AuthError",
    "AutoPublishConfig",
    "BorgError",
    "Client",
    "ConfigError",
    "Counters",
    "DrainReport",
    "DrainResult",
    "FailureTrace",
    "FeedbackAck",
    "FeedbackOutcome",
    "FeedbackRequest",
    "MatchMode",
    "NetworkError",
    "OfflineError",
    "OfflineQueue",
    "OfflineQueueFull",
    "Outcome",
    "Provenance",
    "PublishResult",
    "PublishedTrace",
    "RateLimitError",
    "SearchRequest",
    "SearchResult",
    "SearchResults",
    "ServerError",
    "SignatureError",
    "SigningKeyPair",
    "Trace",
    "TraceDetail",
    "TrustLevel",
    "ValidationError",
    "Visibility",
    "__version__",
    "drain_queue",
    "load_auto_publish_config",
    "load_borg_config",
    "publish_to_federation",
]
