"""Single source of truth for the package version.

Kept as a tiny module so `pyproject.toml` build hooks, the package
itself, and any future scripts can all read one line. Update on every
release; CI's release workflow asserts this matches the git tag.
"""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.6.1"
