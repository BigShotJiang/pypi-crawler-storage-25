"""``borg`` CLI — first-interaction surface for the SDK.

Goal: pip install → ``borg init`` → ``borg register`` → ``borg publish``
in under a minute. The CLI is a thin Click wrapper over :class:`Client`;
all wire logic, validation, and signing live in the SDK.

Configuration precedence (highest wins):

  1. Per-command flag (``--api-key``, ``--base-url``)
  2. Environment variable (``BORG_API_KEY``, ``BORG_BASE_URL``)
  3. ``~/.borg/config.toml`` (mode 0600)

The config file and key files are stored under ``~/.borg/`` with mode
0700 on the directory; key files are 0600. We never print an api_key
in full — masked as ``<first 8 chars>…`` in stdout.

Exit codes:

  0  success
  1  user error (bad input, validation failure, missing config)
  2  network / auth failure (didn't reach Worker; AuthError; NetworkError)
  3  server error (5xx from Worker)
"""

from __future__ import annotations

import json as json_module
import os
import sys
import time
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Final

import click
from rich.console import Console
from rich.table import Table

from borg_collective._closure import (
    ClosureResults,
    TrialResult,
    run_closure,
    write_results,
)
from borg_collective._signing import SigningKeyPair, signing_key_from_hex
from borg_collective._transport import DEFAULT_BASE_URL
from borg_collective._version import __version__
from borg_collective.client import Client
from borg_collective.exceptions import (
    AuthError,
    BorgError,
    ConfigError,
    NetworkError,
    ServerError,
    ValidationError,
)
from borg_collective.models import (
    AmendmentKind,
    FailureTrace,
    FeedbackOutcome,
    Outcome,
    Provenance,
    Visibility,
)

# stdout (info/results) and stderr (errors). Two consoles so --json on
# stdout stays clean while a side error message lands on stderr.
_OUT = Console(highlight=False)
_ERR = Console(stderr=True, highlight=False)

# Exit codes — kept here so tests can assert against named constants.
EXIT_OK: Final[int] = 0
EXIT_USER: Final[int] = 1
EXIT_NETWORK: Final[int] = 2
EXIT_SERVER: Final[int] = 3

# Closure test — separate exit-code semantics from the other commands.
# The closure subcommand asserts a federation health invariant; a
# below-threshold result is a measured failure (not a user error or
# server error), and a registration/network failure during setup is an
# infrastructure error distinct from a measured low rate.
EXIT_CLOSURE_BELOW_THRESHOLD: Final[int] = 1
EXIT_CLOSURE_INFRASTRUCTURE: Final[int] = 2

# v1 ship gate. Kept as a CLI-local constant so tests can monkeypatch
# it; the canonical statement of the threshold lives in
# docs/closure-test.md and tests/integration/test_closure.py.
_CLOSURE_RATE_THRESHOLD: Final[float] = 0.95

# Closure-agent env-var names — mirror tests/integration/conftest.py.
# Same pair so a developer running ``borg closure-test`` after a
# ``pytest -m closure`` round-trip reuses the same cached agents.
_ENV_CLOSURE_A_ID: Final[str] = "BORG_CLOSURE_AGENT_A_ID"
_ENV_CLOSURE_A_KEY: Final[str] = "BORG_CLOSURE_AGENT_A_KEY"
_ENV_CLOSURE_B_ID: Final[str] = "BORG_CLOSURE_AGENT_B_ID"
_ENV_CLOSURE_B_KEY: Final[str] = "BORG_CLOSURE_AGENT_B_KEY"

# Filesystem layout. The default config dir is ``~/.borg/`` but tests
# (and power users) override via ``BORG_HOME`` so the dotfile doesn't
# leak into the user's actual home directory.
_DEFAULT_BORG_HOME: Final[Path] = Path.home() / ".borg"
_CONFIG_FILENAME: Final[str] = "config.toml"
_KEYS_DIRNAME: Final[str] = "keys"

# Length of the api_key prefix shown in stdout. 8 chars is enough to
# correlate two CLI invocations against the same agent without giving
# anyone enough material to guess the rest of a 64-char key.
_API_KEY_PREFIX_CHARS: Final[int] = 8


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CliConfig:
    """Resolved configuration for a single CLI invocation.

    Built once at the top of every command. Merges ``--api-key`` /
    ``--base-url`` flags, ``BORG_API_KEY`` / ``BORG_BASE_URL`` env vars,
    and the persisted ``config.toml`` — flag wins over env wins over
    file. Saving back to disk goes through :func:`_save_config`, which
    only writes the persisted fields (api_key + base_url + agent_id).
    """

    api_key: str | None
    base_url: str
    agent_id: str | None
    borg_home: Path

    @property
    def config_path(self) -> Path:
        return self.borg_home / _CONFIG_FILENAME

    @property
    def keys_dir(self) -> Path:
        return self.borg_home / _KEYS_DIRNAME


def _borg_home() -> Path:
    """Where to put config + keys. Tests override via ``BORG_HOME`` env."""
    override = os.environ.get("BORG_HOME")
    if override:
        return Path(override)
    return _DEFAULT_BORG_HOME


def _load_config_file(path: Path) -> dict[str, Any]:
    """Load ``config.toml`` from ``path``. Returns ``{}`` if missing.

    Raises :class:`click.ClickException` (caught by Click → exit 1) if
    the file exists but is not parseable. Don't propagate the raw
    tomllib error; user gets a useful pointer to the bad path.
    """
    if not path.exists():
        return {}
    try:
        with path.open("rb") as f:
            data = tomllib.load(f)
    except tomllib.TOMLDecodeError as exc:
        msg = (
            f"config file {path} is malformed TOML: {exc}. "
            "Fix the file by hand, or delete it and re-run `borg register` "
            "to start fresh."
        )
        raise click.ClickException(msg) from exc
    return data


def _save_config(config: CliConfig) -> None:
    """Persist the config to ``config.toml`` with mode 0600.

    The TOML is written by hand (no `tomli_w` dep) — three keys, one
    table. Easier to hand-edit if a user wants to.
    """
    config.borg_home.mkdir(mode=0o700, parents=True, exist_ok=True)
    lines = ["# borg-collective CLI config — created automatically.", ""]
    if config.api_key is not None:
        lines.append(f'api_key = "{config.api_key}"')
    if config.agent_id is not None:
        lines.append(f'agent_id = "{config.agent_id}"')
    lines.append(f'base_url = "{config.base_url}"')
    body = "\n".join(lines) + "\n"
    config.config_path.write_text(body, encoding="utf-8")
    config.config_path.chmod(0o600)


def _resolve_config(
    *,
    api_key_flag: str | None,
    base_url_flag: str | None,
) -> CliConfig:
    """Merge flag → env → file precedence into a :class:`CliConfig`."""
    home = _borg_home()
    on_disk = _load_config_file(home / _CONFIG_FILENAME)

    api_key = api_key_flag or os.environ.get("BORG_API_KEY") or on_disk.get("api_key")
    base_url = (
        base_url_flag
        or os.environ.get("BORG_BASE_URL")
        or on_disk.get("base_url")
        or DEFAULT_BASE_URL
    )
    agent_id = on_disk.get("agent_id")

    cfg_path = home / _CONFIG_FILENAME
    if api_key is not None and not isinstance(api_key, str):
        msg = (
            f"config error: api_key in {cfg_path} must be a string. "
            "Edit the file or delete it and re-run `borg register`."
        )
        raise click.ClickException(msg)
    if not isinstance(base_url, str):
        msg = (
            f"config error: base_url in {cfg_path} must be a string. "
            "Edit the file or delete it and re-run `borg register`."
        )
        raise click.ClickException(msg)
    if agent_id is not None and not isinstance(agent_id, str):
        msg = (
            f"config error: agent_id in {cfg_path} must be a string. "
            "Edit the file or delete it and re-run `borg register`."
        )
        raise click.ClickException(msg)

    return CliConfig(api_key=api_key, base_url=base_url, agent_id=agent_id, borg_home=home)


def _require_api_key(config: CliConfig) -> str:
    """Return the configured api_key or raise a useful error.

    Common authoring mistake: running an authed command without a key.
    The error message names the exact remediation paths so the user
    doesn't have to read the docs to recover.
    """
    if config.api_key is None:
        msg = (
            "no api_key configured. Run `borg init` or `borg register`, or set "
            "BORG_API_KEY, or pass --api-key."
        )
        raise click.ClickException(msg)
    return config.api_key


def _mask_api_key(api_key: str) -> str:
    """Format ``api_key`` for stdout. NEVER print the full value."""
    if len(api_key) <= _API_KEY_PREFIX_CHARS:
        # Pathological — never happens with real 64-char keys but
        # defensive: avoid leaking what little we have.
        return "…"
    return f"{api_key[:_API_KEY_PREFIX_CHARS]}…"


# ---------------------------------------------------------------------------
# Error → exit-code mapping
# ---------------------------------------------------------------------------


def _exit_for(exc: BaseException) -> int:
    """Map an SDK exception to the CLI's exit-code contract."""
    if isinstance(exc, AuthError | NetworkError):
        return EXIT_NETWORK
    if isinstance(exc, ServerError):
        return EXIT_SERVER
    if isinstance(exc, ValidationError | ConfigError | BorgError):
        return EXIT_USER
    return EXIT_USER


def _print_error_and_exit(exc: BaseException) -> None:
    """Print a red ``error: …`` line and exit with the appropriate code.

    Stack traces are deliberately suppressed unless ``--verbose`` was
    passed — a CLI consumer wants the message and an exit code, not
    Python internals.
    """
    code = _exit_for(exc)
    msg = str(exc) or type(exc).__name__
    _ERR.print(f"[red]error:[/red] {msg}")
    sys.exit(code)


# ---------------------------------------------------------------------------
# JSON / Table renderers
# ---------------------------------------------------------------------------


def _render_table(title: str, rows: list[tuple[str, Any]]) -> None:
    table = Table(title=title, title_justify="left", show_header=False, box=None)
    table.add_column("field", style="bold")
    table.add_column("value")
    for k, v in rows:
        table.add_row(k, str(v))
    _OUT.print(table)


def _render(payload: dict[str, Any], title: str, *, as_json: bool) -> None:
    if as_json:
        _OUT.print_json(json_module.dumps(payload))
    else:
        _render_table(title, list(payload.items()))


def _print_welcome_banner(agent_id: str) -> None:
    """Print the post-registration welcome banner.

    Six lines, deliberate. Surfaces the PRIVATE-by-default safety floor
    and the explicit ``force_public=True`` opt-in path immediately, so
    a user who runs ``borg init`` for the first time learns the
    publication contract before they construct their first trace.
    """
    lines = [
        f"Borg Collective v{__version__} — agent_id {agent_id[:8]}... registered.",
        "✓ Default visibility: PRIVATE. No traces leave your machine without your call.",
        "✓ To publish a trace publicly, use: client.publish(ft, force_public=True)",
        "✓ To check what's published: borg debug-export --public  (coming in v0.3)",
        "✓ To see federation health: borg stats  (coming in v0.3)",
        "Docs: https://borg-collective-v1.borg-farther.workers.dev/",
    ]
    for line in lines:
        click.echo(line)


# ---------------------------------------------------------------------------
# Click root group + decorators for shared options
# ---------------------------------------------------------------------------


def _common_options(f: Any) -> Any:
    """Attach the four cross-cutting flags to a Click command.

    Centralised so adding a new flag (--debug-thing) doesn't mean
    editing every command function below.
    """
    f = click.option(
        "--base-url", default=None, help=f"Worker base URL (default: {DEFAULT_BASE_URL})"
    )(f)
    f = click.option("--api-key", default=None, help="Override api_key from config/env.")(f)
    f = click.option(
        "--json", "as_json", is_flag=True, default=False, help="Machine-readable JSON output."
    )(f)
    f = click.option(
        "--quiet", "-q", is_flag=True, default=False, help="Suppress non-error stdout."
    )(f)
    return click.option(
        "--verbose", "-v", is_flag=True, default=False, help="DEBUG-level transport logging."
    )(f)


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(__version__, prog_name="borg")
def main() -> None:
    """borg — Borg Collective failure-trace federation CLI."""


# ---------------------------------------------------------------------------
# version (also exposed via --version, but a subcommand is more scriptable)
# ---------------------------------------------------------------------------


@main.command()
def version() -> None:
    """Print the installed SDK version. No network."""
    _OUT.print(__version__)


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


@main.command()
@_common_options
@click.option("--name", default=None, help="Display name for the new agent.")
@click.option(
    "--no-register",
    is_flag=True,
    default=False,
    help="Set up config/dirs only; don't call POST /agents.",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Re-register: overwrite the existing agent_id with a new identity.",
)
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    default=False,
    help="Skip the confirmation prompt on --force (CI path).",
)
def init(
    *,
    base_url: str | None,
    api_key: str | None,
    as_json: bool,
    quiet: bool,  # noqa: ARG001
    verbose: bool,  # noqa: ARG001
    name: str | None,
    no_register: bool,
    force: bool,
    yes: bool,
) -> None:
    """Interactive setup. Creates ~/.borg/, registers, saves config.

    Idempotent — running it again with an existing config surfaces the
    existing agent_id and exits 0. Pass ``--force`` to re-register
    (creates a new agent_id); ``--force --yes`` skips the prompt.
    """
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    config.borg_home.mkdir(mode=0o700, parents=True, exist_ok=True)
    config.keys_dir.mkdir(mode=0o700, parents=True, exist_ok=True)

    if config.api_key is not None and not force:
        # Already initialised. Print the current state and stop.
        # The --force hint is surfaced in human-readable mode so a user
        # who wanted to re-register learns the path without --help.
        payload: dict[str, Any] = {
            "borg_home": str(config.borg_home),
            "config_path": str(config.config_path),
            "agent_id": config.agent_id,
            "api_key": _mask_api_key(config.api_key),
            "base_url": config.base_url,
            "status": "already_initialised",
        }
        _render(payload, "borg init", as_json=as_json)
        if not as_json:
            click.echo("Use --force to re-register (creates new agent_id).")
        return

    if config.api_key is not None and force and not yes:
        # Confirm before overwriting an existing identity. The agent_id
        # is the on-disk root for the keypair file; overwriting orphans
        # the prior key (still on disk under keys/<old_agent_id>.hex)
        # but every future signed publish will use the new identity.
        confirmed = click.confirm(
            f"This will overwrite agent_id {config.agent_id} with a new identity. Continue?",
            default=False,
        )
        if not confirmed:
            click.echo("Cancelled.")
            return

    if no_register:
        # Just write the directories + a config skeleton with no api_key.
        _save_config(config)
        payload = {
            "borg_home": str(config.borg_home),
            "config_path": str(config.config_path),
            "status": "skeleton_only",
        }
        _render(payload, "borg init", as_json=as_json)
        return

    try:
        with Client(base_url=config.base_url) as bootstrap:
            agent = bootstrap.register_agent(display_name=name)
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover

    new_config = CliConfig(
        api_key=agent.api_key,
        base_url=config.base_url,
        agent_id=agent.agent_id,
        borg_home=config.borg_home,
    )
    _save_config(new_config)

    if not as_json:
        _print_welcome_banner(agent.agent_id)

    payload = {
        "agent_id": agent.agent_id,
        "display_name": agent.display_name,
        "trust_level": agent.trust_level,
        "api_key": _mask_api_key(agent.api_key),
        "config_path": str(new_config.config_path),
        "status": "registered",
    }
    _render(payload, "borg init", as_json=as_json)


# ---------------------------------------------------------------------------
# register
# ---------------------------------------------------------------------------


@main.command()
@_common_options
@click.option("--name", default=None, help="Display name for the new agent.")
@click.option(
    "--overwrite",
    is_flag=True,
    default=False,
    help="Replace any existing api_key in config.",
)
def register(
    *,
    base_url: str | None,
    api_key: str | None,
    as_json: bool,
    quiet: bool,  # noqa: ARG001
    verbose: bool,  # noqa: ARG001
    name: str | None,
    overwrite: bool,
) -> None:
    """Register a new agent and save the api_key locally."""
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    if config.api_key is not None and not overwrite:
        msg = (
            "api_key already configured. Pass --overwrite to replace, or use "
            "`borg whoami` to see who you are."
        )
        raise click.ClickException(msg)

    try:
        with Client(base_url=config.base_url) as c:
            agent = c.register_agent(display_name=name)
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover

    new_config = CliConfig(
        api_key=agent.api_key,
        base_url=config.base_url,
        agent_id=agent.agent_id,
        borg_home=config.borg_home,
    )
    _save_config(new_config)
    payload = {
        "agent_id": agent.agent_id,
        "display_name": agent.display_name,
        "trust_level": agent.trust_level,
        "api_key": _mask_api_key(agent.api_key),
        "config_path": str(new_config.config_path),
    }
    _render(payload, "registered", as_json=as_json)


# ---------------------------------------------------------------------------
# whoami
# ---------------------------------------------------------------------------


@main.command()
@_common_options
def whoami(
    *,
    base_url: str | None,
    api_key: str | None,
    as_json: bool,
    quiet: bool,  # noqa: ARG001
    verbose: bool,  # noqa: ARG001
) -> None:
    """Print the authenticated agent's identity."""
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    key = _require_api_key(config)
    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            me = c.whoami()
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover

    payload = {
        "agent_id": me.agent_id,
        "display_name": me.display_name,
        "trust_level": str(me.trust_level),
        "pubkey": me.pubkey if me.pubkey else "(unset)",
        "created_at": me.created_at,
    }
    _render(payload, "whoami", as_json=as_json)


# ---------------------------------------------------------------------------
# publish
# ---------------------------------------------------------------------------


def _load_keypair_for(config: CliConfig, agent_id: str) -> SigningKeyPair:
    """Return the on-disk keypair for ``agent_id``, generating if absent.

    Stored at ``~/.borg/keys/<agent_id>.hex`` mode 0600. Hex-only;
    the file is exactly 64 characters.
    """
    config.keys_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    key_path = config.keys_dir / f"{agent_id}.hex"
    if key_path.exists():
        seed_hex = key_path.read_text(encoding="utf-8").strip()
        return signing_key_from_hex(seed_hex)
    kp = SigningKeyPair.generate()
    key_path.write_text(kp.signing_key_hex, encoding="utf-8")
    key_path.chmod(0o600)
    return kp


@main.command()
@_common_options
@click.argument("trace_file", type=click.Path(exists=True, dir_okay=False, readable=True))
@click.option("--sign", is_flag=True, default=False, help="Sign with the on-disk Ed25519 key.")
@click.option(
    "--force-public",
    is_flag=True,
    default=False,
    help="Allow visibility=public on the wire (E0.5 safety floor opt-in).",
)
def publish(
    *,
    base_url: str | None,
    api_key: str | None,
    as_json: bool,
    quiet: bool,  # noqa: ARG001
    verbose: bool,  # noqa: ARG001
    trace_file: str,
    sign: bool,
    force_public: bool,
) -> None:
    """Publish a failure trace from a JSON file."""
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    key = _require_api_key(config)

    try:
        body = json_module.loads(Path(trace_file).read_text(encoding="utf-8"))
    except (OSError, json_module.JSONDecodeError) as exc:
        msg = (
            f"borg publish: could not read trace file {trace_file}: {exc}. "
            "The file must be a JSON object with the FailureTrace fields "
            "(error_text, task_description, approach_summary, root_cause, outcome)."
        )
        raise click.ClickException(msg) from exc
    if not isinstance(body, dict):
        msg = (
            f"borg publish: {trace_file} must contain a JSON object, not " f"{type(body).__name__}."
        )
        raise click.ClickException(msg)

    try:
        ft = FailureTrace.model_validate(body)
    except Exception as exc:
        # Pydantic ValidationError, etc. Surface as user error.
        msg = (
            f"borg publish: {trace_file} is not a valid FailureTrace: {exc}. "
            "See `borg publish --help` for the required fields."
        )
        raise click.ClickException(msg) from exc

    signing_key: SigningKeyPair | None = None
    if sign:
        if config.agent_id is None:
            msg = (
                "borg publish --sign: no agent_id in config. "
                "The keypair file is named after the agent_id, so we need one. "
                "Run `borg init` or `borg register` first."
            )
            raise click.ClickException(msg)
        signing_key = _load_keypair_for(config, config.agent_id)
        # Make sure the Worker knows our pubkey before we publish a
        # signed trace. rotate_pubkey is idempotent server-side
        # (UPDATE … SET pubkey = ?).
        try:
            with Client(api_key=key, base_url=config.base_url) as c:
                c.rotate_pubkey(signing_key.verify_key_hex)
        except BorgError as exc:
            _print_error_and_exit(exc)
            return  # pragma: no cover

    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            published = c.publish(ft, signing_key=signing_key, force_public=force_public)
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover
    except ValueError as exc:
        # The SDK raises ValueError when a PUBLIC trace is published
        # without force_public=True. Surface as a click error so the
        # CLI exits with status 1 and a clean message.
        raise click.ClickException(str(exc)) from exc

    payload = {
        "trace_id": published.trace_id,
        "signed": published.signed,
        "error_signature": published.error_signature,
        "warning": published.warning if published.warning else None,
    }
    _render(payload, "published", as_json=as_json)


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


@main.command(name="get")
@_common_options
@click.argument("trace_id")
def get_cmd(
    *,
    base_url: str | None,
    api_key: str | None,
    as_json: bool,
    quiet: bool,  # noqa: ARG001
    verbose: bool,  # noqa: ARG001
    trace_id: str,
) -> None:
    """Retrieve a trace + amendments + counters."""
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    key = _require_api_key(config)
    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            detail = c.get(trace_id)
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover

    if as_json:
        _OUT.print_json(detail.model_dump_json())
        return

    _render_table(
        f"trace {detail.trace.trace_id}",
        [
            ("agent_id", detail.trace.agent_id),
            ("outcome", detail.trace.outcome),
            ("visibility", detail.trace.visibility),
            ("signed", detail.trace.signed),
            ("error_signature", detail.trace.error_signature),
            ("created_at", detail.trace.created_at),
            ("retrieved", detail.counters.retrieved),
            ("read", detail.counters.read),
            ("applied", detail.counters.applied),
            ("helped", detail.counters.helped),
            ("didnt_help", detail.counters.didnt_help),
            ("amendments", len(detail.amendments)),
        ],
    )


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------


@main.command()
@_common_options
@click.option("--sig", "error_signature", default=None, help="Search by error_signature.")
@click.option("--query", default=None, help="Substring search on error_text.")
@click.option("--class", "error_class", default=None, help="Filter by error_class.")
@click.option("--tag", "tags", multiple=True, help="Filter by tag (repeat for AND).")
@click.option("--limit", default=10, type=int, help="Max results (1..50).")
def search(
    *,
    base_url: str | None,
    api_key: str | None,
    as_json: bool,
    quiet: bool,  # noqa: ARG001
    verbose: bool,  # noqa: ARG001
    error_signature: str | None,
    query: str | None,
    error_class: str | None,
    tags: tuple[str, ...],
    limit: int,
) -> None:
    """Search the federation for matching traces."""
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    key = _require_api_key(config)
    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            results = c.search(
                error_signature=error_signature,
                query=query,
                error_class=error_class,
                tags=list(tags) if tags else None,
                limit=limit,
            )
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover

    if as_json:
        _OUT.print_json(results.model_dump_json())
        return

    table = Table(title=f"search ({results.match_mode})", show_header=True, box=None)
    table.add_column("trace_id", style="bold")
    table.add_column("outcome")
    table.add_column("signed")
    table.add_column("preview", max_width=60)
    for r in results.results:
        table.add_row(r.trace_id, str(r.outcome), str(r.signed), r.preview)
    _OUT.print(table)
    _OUT.print(f"[dim]{results.count} result(s)[/dim]")


# ---------------------------------------------------------------------------
# feedback
# ---------------------------------------------------------------------------


@main.command()
@_common_options
@click.argument("trace_id")
@click.option("--retrieved/--no-retrieved", default=False)
@click.option("--read/--no-read", default=False)
@click.option("--applied/--no-applied", default=False)
@click.option(
    "--outcome",
    type=click.Choice(["helped", "didnt_help"]),
    default=None,
)
@click.option("--note", default=None, help="Free-text note (≤512 chars).")
def feedback(
    *,
    base_url: str | None,
    api_key: str | None,
    as_json: bool,
    quiet: bool,  # noqa: ARG001
    verbose: bool,  # noqa: ARG001
    trace_id: str,
    retrieved: bool,
    read: bool,
    applied: bool,
    outcome: str | None,
    note: str | None,
) -> None:
    """Send feedback on a trace.

    Funnel monotonicity is enforced locally before the network: read
    requires retrieved; applied requires read; outcome requires
    applied. The Worker re-validates so a hand-crafted JSON would
    still get a 400.
    """
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    key = _require_api_key(config)
    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            ack = c.feedback(
                trace_id,
                retrieved=retrieved,
                read=read,
                applied=applied,
                outcome=FeedbackOutcome(outcome) if outcome else None,
                note=note,
            )
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover

    payload = {
        "recorded": ack.recorded,
        "trace_id": ack.trace_id,
        "counters_updated": ack.counters_updated,
        "note": ack.note if ack.note else None,
    }
    _render(payload, "feedback", as_json=as_json)


# ---------------------------------------------------------------------------
# amend
# ---------------------------------------------------------------------------


@main.command()
@_common_options
@click.argument("trace_id")
@click.option("--content", required=True, help="Amendment body (≤16384 chars).")
@click.option(
    "--kind",
    type=click.Choice(["resolution", "clarification", "correction"]),
    default="clarification",
)
def amend(
    *,
    base_url: str | None,
    api_key: str | None,
    as_json: bool,
    quiet: bool,  # noqa: ARG001
    verbose: bool,  # noqa: ARG001
    trace_id: str,
    content: str,
    kind: str,
) -> None:
    """Append an amendment to an existing trace."""
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    key = _require_api_key(config)
    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            created = c.add_amendment(trace_id, content=content, kind=AmendmentKind(kind))
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover
    payload = {
        "amendment_id": created.amendment_id,
        "trace_id": created.trace_id,
        "kind": str(created.kind),
        "created_at": created.created_at,
    }
    _render(payload, "amended", as_json=as_json)


# ---------------------------------------------------------------------------
# drain
# ---------------------------------------------------------------------------


@main.command()
@_common_options
@click.option(
    "--queue-path",
    default=None,
    help="Override offline queue path (default: ~/.borg/offline_queue.sqlite).",
)
@click.option("--max-items", default=100, type=int)
def drain(
    *,
    base_url: str | None,
    api_key: str | None,
    as_json: bool,
    quiet: bool,  # noqa: ARG001
    verbose: bool,  # noqa: ARG001
    queue_path: str | None,
    max_items: int,
) -> None:
    """Drain the offline queue against the live Worker."""
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    key = _require_api_key(config)
    qpath = Path(queue_path) if queue_path else (config.borg_home / "offline_queue.sqlite")
    try:
        with Client(api_key=key, base_url=config.base_url, offline_queue_path=qpath) as c:
            report = c.drain(max_items=max_items)
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover
    payload = {
        "drained": report.drained,
        "deferred": report.deferred,
        "failed": report.failed,
        "stopped_early": report.stopped_early,
        "errors_by_signature": report.errors_by_signature,
    }
    _render(payload, "drain", as_json=as_json)


# ---------------------------------------------------------------------------
# demo — 90-second value-loop showcase
# ---------------------------------------------------------------------------


# T1 demo scenario: Hermes MCP python-vs-python3 mismatch on Ubuntu 24.04.
# The error_text snippet is the distinguishing substring of the seeded T1
# trace's error_text — search() does a LIKE on error_text, so a unique
# substring reliably picks the curated trace as the top hit.
_DEMO_QUERY = "posix_spawnp"
_DEMO_FAILURE_LINES = (
    "[step 1] Running: python /opt/hermes/mcp_server.py",
    "[step 1] Error: ENOENT: no such file or directory, posix_spawnp 'python'",
)
_DEMO_LEGIBILITY_PAUSE_S = 0.5


@main.command()
@_common_options
def demo(
    *,
    base_url: str | None,
    api_key: str | None,
    as_json: bool,  # noqa: ARG001 — demo is human-readable; JSON mode would defeat the purpose
    quiet: bool,  # noqa: ARG001
    verbose: bool,  # noqa: ARG001
) -> None:
    """Run the 90-second Borg value-loop showcase.

    Simulates an agent failure (Hermes MCP python/python3 on Ubuntu
    24.04), performs a real /api/v1/search call against the live
    federation, surfaces the matched fix from the curated corpus.
    No canned strings — the fix text is whatever the federation returns.
    """
    demo_start = time.time()
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    key = _require_api_key(config)

    click.echo(
        "Borg demo: simulating an agent failure → Borg lookup → fix → publish."
    )
    # The publish-back loop ("(4) publish a follow-up trace") lives in
    # v0.4 — see friction_journal/2026-Q2-demo-curated-label-hardcoded.md
    # for the v0.4 attribution round-trip plan. Today's demo is the
    # three-step lookup path: failure → search → fix.
    click.echo(
        "Scenario: Hermes MCP server fails to start on Ubuntu 24.04. The agent "
        "will: (1) hit the error, (2) query Borg, (3) apply the suggested fix."
    )
    click.echo("")

    # Step 1 — simulated failure.
    for line in _DEMO_FAILURE_LINES:
        click.echo(line)
    time.sleep(_DEMO_LEGIBILITY_PAUSE_S)

    # Step 2 — real Borg lookup against the live federation. Two calls:
    # search() to find the top match, then get() to pull the full trace
    # so we can read context_snapshot.fix (search results carry only a
    # 200-char preview).
    click.echo("[step 2] Looking up error in Borg...")
    t0 = time.time()
    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            results = c.search(query=_DEMO_QUERY, limit=1)
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover
    lookup_ms = int((time.time() - t0) * 1000)

    if not results.results:
        click.echo(
            "[step 2] Borg lookup: no match (this would normally surface a fix); "
            "demo aborted."
        )
        sys.exit(1)

    top = results.results[0]

    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            detail = c.get(top.trace_id)
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover

    click.echo(
        f"[step 2] Found: {top.trace_id} ({detail.trace.provenance.value}) in {lookup_ms}ms — "
        f"'{top.error_class or '(no error_class)'}'"
    )
    fix_text = str(detail.trace.context_snapshot.get("fix", "(no fix in trace)"))
    click.echo(f"[step 2] Suggested fix: {fix_text}")

    # Step 3 — simulated apply.
    click.echo("[step 3] Applying fix... done.")
    time.sleep(_DEMO_LEGIBILITY_PAUSE_S)

    # Step 4 — simulated success + publish a follow-up trace.
    # E0.7 closes the loop: the agent demonstrates that it found the
    # fix, applied it, and is now publishing its own confirmation trace
    # back to the federation as PRIVATE (the user reviews via
    # `borg review` before promoting).
    click.echo("[step 4] Server started. MCP tools available.")
    follow_up = FailureTrace(
        error_text=f"(resolved by trace {top.trace_id})",
        error_class="follow-up",
        outcome=Outcome.RESOLVED,
        parent_trace_id=top.trace_id,
        task_description=f"Demo follow-up: confirming fix from {top.error_class or 'parent'}",
        approach_summary=f"Applied fix: {fix_text[:200]}",
        root_cause=f"Same as parent: {detail.trace.root_cause[:200]}",
        visibility=Visibility.PRIVATE,
        provenance=Provenance.ORGANIC,
        tags=["demo", "follow-up", "v0.5"],
    )
    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            published = c.publish(follow_up)
    except BorgError as exc:
        click.echo(f"[step 4] follow-up publish failed: {exc}")
        published = None

    if published is not None:
        click.echo(
            f"[step 4] Published follow-up {published.trace_id} (private; "
            f"parent={top.trace_id[:16]}...). Run `borg review` to promote."
        )

    wall_clock_s = time.time() - demo_start
    click.echo("")
    click.echo(
        f"Demo complete in {wall_clock_s:.1f}s. The lookup took {lookup_ms}ms."
    )
    click.echo(
        "This loop is what every agent runtime gets when it imports "
        "borg_collective."
    )


# ---------------------------------------------------------------------------
# closure-test
# ---------------------------------------------------------------------------


def _closure_agent_pair(
    *,
    base_url: str,
) -> tuple[Client, Client, SigningKeyPair, SigningKeyPair, str, str]:
    """Return (client_a, client_b, kp_a, kp_b, agent_a_id, agent_b_id).

    Reuses the BORG_CLOSURE_AGENT_*_ID/KEY env pair when set; otherwise
    registers fresh agents and writes the env-var lines to stderr so
    the user can re-pin. Each agent has its pubkey enrolled before
    return — closure asserts the signed federation path.

    Raises :class:`BorgError` on any step that fails — the CLI maps
    those to exit ``EXIT_CLOSURE_INFRASTRUCTURE`` (2).
    """

    def _resolve_or_register(env_id: str, env_key: str, name: str) -> tuple[str, str, bool]:
        cached_id = os.environ.get(env_id)
        cached_key = os.environ.get(env_key)
        if cached_id and cached_key:
            return cached_id, cached_key, False
        with Client(base_url=base_url) as bootstrap:
            agent = bootstrap.register_agent(display_name=name)
        return agent.agent_id, agent.api_key, True

    agent_a_id, key_a, fresh_a = _resolve_or_register(
        _ENV_CLOSURE_A_ID, _ENV_CLOSURE_A_KEY, "closure-a"
    )
    agent_b_id, key_b, fresh_b = _resolve_or_register(
        _ENV_CLOSURE_B_ID, _ENV_CLOSURE_B_KEY, "closure-b"
    )

    if fresh_a or fresh_b:
        _ERR.print(
            "[dim]freshly registered closure agents — pin to avoid "
            "re-registration on the next run:[/dim]"
        )
        if fresh_a:
            _ERR.print(f"[dim]export {_ENV_CLOSURE_A_ID}={agent_a_id}[/dim]")
            _ERR.print(f"[dim]export {_ENV_CLOSURE_A_KEY}={key_a}[/dim]")
        if fresh_b:
            _ERR.print(f"[dim]export {_ENV_CLOSURE_B_ID}={agent_b_id}[/dim]")
            _ERR.print(f"[dim]export {_ENV_CLOSURE_B_KEY}={key_b}[/dim]")

    kp_a = SigningKeyPair.generate()
    kp_b = SigningKeyPair.generate()
    with Client(api_key=key_a, base_url=base_url) as ca:
        ca.rotate_pubkey(kp_a.verify_key_hex)
    with Client(api_key=key_b, base_url=base_url) as cb:
        cb.rotate_pubkey(kp_b.verify_key_hex)

    return (
        Client(api_key=key_a, base_url=base_url),
        Client(api_key=key_b, base_url=base_url),
        kp_a,
        kp_b,
        agent_a_id,
        agent_b_id,
    )


def _summarise_results_table(results: ClosureResults) -> Table:
    """Render the headline aggregates as a Rich Table for stdout."""
    table = Table(title="closure-test", title_justify="left", show_header=False, box=None)
    table.add_column("field", style="bold")
    table.add_column("value")
    table.add_row("trials", str(results.n_trials))
    table.add_row("closure_rate", f"{results.closure_rate:.2%}")
    sigverify = results.signature_verification_rate
    table.add_row(
        "signature_verification_rate",
        f"{sigverify:.2%}" if sigverify is not None else "(n/a)",
    )
    table.add_row("feedback_acceptance_rate", f"{results.feedback_acceptance_rate:.2%}")
    table.add_row("median_ms", f"{results.time_to_closure_ms['median']:.0f}")
    table.add_row("p95_ms", f"{results.time_to_closure_ms['p95']:.0f}")
    table.add_row("p99_ms", f"{results.time_to_closure_ms['p99']:.0f}")
    table.add_row("base_url", results.base_url)
    table.add_row("run_uuid", results.run_uuid)
    return table


@main.command(name="closure-test")
@click.option(
    "--trials",
    "trials",
    default=20,
    type=click.IntRange(min=1),
    help="Number of trials to run (default 20).",
)
@click.option(
    "--output",
    "output_path",
    type=click.Path(dir_okay=False, writable=True),
    default=None,
    help="Write closure_results.json to PATH (default: stdout).",
)
@click.option(
    "--base-url",
    "base_url",
    default=None,
    help=f"Worker base URL (default: {DEFAULT_BASE_URL}).",
)
@click.option("--verbose", "-v", is_flag=True, default=False, help="Show per-trial progress bar.")
def closure_test(
    *,
    trials: int,
    output_path: str | None,
    base_url: str | None,
    verbose: bool,
) -> None:
    """Run the closure-rate test against the live federation.

    Runs ``--trials`` end-to-end trials of the v1 closure flow
    (publish → search → fetch → verify → feedback → counter-confirm)
    using two ephemeral or cached agents, and reports the aggregate
    closure rate. Exits 0 if closure_rate >= 95%, 1 if below the
    threshold, 2 on infrastructure error (registration / network).

    The full result schema is documented in ``docs/closure-test.md``.
    """
    resolved_base_url = base_url or os.environ.get("BORG_BASE_URL") or DEFAULT_BASE_URL

    # Set up the agent pair. Any failure here is infrastructure
    # (registration cap, network, auth) — distinct exit code from a
    # below-threshold measured rate.
    try:
        client_a, client_b, kp_a, kp_b, agent_a_id, agent_b_id = _closure_agent_pair(
            base_url=resolved_base_url,
        )
    except BorgError as exc:
        _ERR.print(f"[red]error:[/red] closure-test setup failed: {exc}")
        sys.exit(EXIT_CLOSURE_INFRASTRUCTURE)

    progress_cb = None
    progress_handle = None
    if verbose:
        from rich.progress import (
            BarColumn,
            Progress,
            TaskProgressColumn,
            TextColumn,
            TimeElapsedColumn,
            TimeRemainingColumn,
        )

        progress_handle = Progress(
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TextColumn("•"),
            TimeElapsedColumn(),
            TextColumn("•"),
            TimeRemainingColumn(),
            console=_ERR,
        )
        progress_handle.start()
        task_id = progress_handle.add_task("closure trials", total=trials)

        def _cb(_idx: int, _total: int, trial: TrialResult) -> None:
            assert progress_handle is not None
            outcome = trial.outcome
            tag = "[green]ok[/green]" if outcome == "success" else f"[red]{outcome}[/red]"
            progress_handle.update(
                task_id,
                advance=1,
                description=f"closure trials ({tag} {trial.duration_ms} ms)",
            )

        progress_cb = _cb

    try:
        with client_a, client_b:
            results = run_closure(
                client_a,
                client_b,
                signing_key_a=kp_a,
                signing_key_b=kp_b,
                agent_a_id=agent_a_id,
                agent_b_id=agent_b_id,
                n_trials=trials,
                progress_cb=progress_cb,
                base_url=resolved_base_url,
            )
    except BorgError as exc:
        if progress_handle is not None:
            progress_handle.stop()
        _ERR.print(f"[red]error:[/red] closure-test runtime failure: {exc}")
        sys.exit(EXIT_CLOSURE_INFRASTRUCTURE)
    finally:
        if progress_handle is not None:
            progress_handle.stop()

    if output_path is not None:
        write_results(results, Path(output_path))
        _OUT.print(_summarise_results_table(results))
        _OUT.print(f"[dim]results written to {output_path}[/dim]")
    else:
        _OUT.print_json(json_module.dumps(_dump_results(results)))

    if results.closure_rate < _CLOSURE_RATE_THRESHOLD:
        _ERR.print(
            f"[red]error:[/red] closure_rate={results.closure_rate:.2%} "
            f"below {_CLOSURE_RATE_THRESHOLD:.0%} threshold"
        )
        sys.exit(EXIT_CLOSURE_BELOW_THRESHOLD)
    sys.exit(EXIT_OK)


def _dump_results(results: ClosureResults) -> dict[str, Any]:
    """Convert :class:`ClosureResults` to a JSON-serialisable dict.

    ``dataclasses.asdict`` handles the nested :class:`TrialResult`
    list; we go through it rather than ``model_dump`` because
    ClosureResults is a dataclass, not a Pydantic model.
    """
    from dataclasses import asdict

    return asdict(results)


# ---------------------------------------------------------------------------
# E0.7 — `borg review` group: list / show / promote / delete / edit
# ---------------------------------------------------------------------------


@main.group(name="review")
def review() -> None:
    """Manage the caller's own private traces.

    Subcommands:
      list      — paginated listing of recent private traces
      show      — full trace + parent if any
      promote   — flip private → public (with confirmation)
      delete    — soft delete
      edit      — open $EDITOR on the trace JSON, PATCH on save

    Captures from the borg_auto_trace plugin land here as private. Run
    ``borg review`` weekly to triage them.
    """


@review.command(name="list")
@click.option(
    "--visibility",
    type=click.Choice(["public", "private"], case_sensitive=False),
    default="private",
    help="Filter by visibility (default: private — the review queue).",
)
@click.option("--limit", type=click.IntRange(min=1, max=100), default=20)
@click.option("--before", type=int, default=None, help="created_at cursor for pagination.")
@_common_options
def review_list(
    *,
    visibility: str,
    limit: int,
    before: int | None,
    api_key: str | None,
    base_url: str | None,
    as_json: bool = False,
    quiet: bool = False,
    verbose: bool = False,
) -> None:
    """List recent traces. Default filter: private (the review queue)."""
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    key = _require_api_key(config)
    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            resp = c.list_my_traces(visibility=visibility, limit=limit, before=before)
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover

    if resp.count == 0:
        click.echo(f"(no {visibility} traces)")
        return

    now = int(time.time())
    click.echo(f"{'age':>6}  {'trace_id':<24}  {'error_class':<28}  preview")
    click.echo("-" * 90)
    for t in resp.traces:
        age_s = max(0, now - t.created_at)
        if age_s < 3600:
            age = f"{age_s // 60}m"
        elif age_s < 86400:
            age = f"{age_s // 3600}h"
        else:
            age = f"{age_s // 86400}d"
        # Show last 24 chars of trace_id (full ids are too long for an 80-col line).
        tid_short = t.trace_id if len(t.trace_id) <= 24 else "…" + t.trace_id[-23:]
        click.echo(
            f"{age:>6}  {tid_short:<24}  "
            f"{(t.error_class or '(none)')[:28]:<28}  {t.error_preview[:60]}"
        )
    if resp.next_before is not None:
        click.echo(f"\n(more results — pass --before {resp.next_before} to page back)")


@review.command(name="show")
@click.argument("trace_id")
@_common_options
def review_show(
    *,
    trace_id: str,
    api_key: str | None,
    base_url: str | None,
    as_json: bool = False,
    quiet: bool = False,
    verbose: bool = False,
) -> None:
    """Show the full trace, its amendments, and the parent (if any)."""
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    key = _require_api_key(config)
    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            detail = c.get(trace_id)
            parent_detail = None
            if detail.trace.parent_trace_id:
                try:
                    parent_detail = c.get(detail.trace.parent_trace_id)
                except BorgError:
                    pass  # parent may have been deleted
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover

    t = detail.trace
    click.echo(f"trace_id:     {t.trace_id}")
    click.echo(f"visibility:   {t.visibility.value}")
    click.echo(f"provenance:   {t.provenance.value}")
    click.echo(f"error_class:  {t.error_class or '(none)'}")
    click.echo(f"created_at:   {t.created_at}")
    if t.parent_trace_id:
        click.echo(f"parent:       {t.parent_trace_id}")
        if parent_detail is not None:
            click.echo(f"  parent error_class: {parent_detail.trace.error_class or '(none)'}")
    click.echo("")
    click.echo("--- task_description ---")
    click.echo(t.task_description)
    click.echo("--- error_text ---")
    click.echo(t.error_text)
    click.echo("--- approach_summary ---")
    click.echo(t.approach_summary)
    click.echo("--- root_cause ---")
    click.echo(t.root_cause)
    if t.context_snapshot:
        click.echo("--- context_snapshot ---")
        click.echo(json_module.dumps(t.context_snapshot, indent=2))
    if detail.amendments:
        click.echo(f"\n--- amendments ({len(detail.amendments)}) ---")
        for a in detail.amendments:
            click.echo(f"[{a.kind.value}] {a.amendment_id}: {a.content[:200]}")


@review.command(name="promote")
@click.argument("trace_id")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@_common_options
def review_promote(
    *,
    trace_id: str,
    yes: bool,
    api_key: str | None,
    base_url: str | None,
    as_json: bool = False,
    quiet: bool = False,
    verbose: bool = False,
) -> None:
    """Flip a private trace to public. PROMPTS FOR CONFIRMATION."""
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    key = _require_api_key(config)
    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            detail = c.get(trace_id)
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover

    t = detail.trace
    if t.visibility == Visibility.PUBLIC:
        click.echo(f"trace {trace_id} is already public; nothing to do.")
        return

    if not yes:
        click.echo(
            "This trace will be PUBLIC. Anyone querying the federation will see:\n"
            f"  error_text:       {t.error_text[:200]}\n"
            f"  task_description: {t.task_description[:200]}\n"
            f"  root_cause:       {t.root_cause[:200]}\n"
            f"  fix:              {str(t.context_snapshot.get('fix', '(none)'))[:200]}\n"
            "\nOnce promoted you can still delete it but anyone who has already\n"
            "pulled it retains their copy.\n"
        )
        if not click.confirm("Promote?", default=False):
            click.echo("Cancelled.")
            return

    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            c.update_trace(trace_id, force_public=True, visibility=Visibility.PUBLIC)
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover
    click.echo(f"✓ promoted {trace_id} to public.")


@review.command(name="delete")
@click.argument("trace_id")
@click.option("--yes", "-y", is_flag=True, default=False)
@_common_options
def review_delete(
    *,
    trace_id: str,
    yes: bool,
    api_key: str | None,
    base_url: str | None,
    as_json: bool = False,
    quiet: bool = False,
    verbose: bool = False,
) -> None:
    """Soft-delete a trace. Confirms first."""
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    key = _require_api_key(config)
    if not yes:
        if not click.confirm(f"Delete trace {trace_id}?", default=False):
            click.echo("Cancelled.")
            return
    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            c.delete_trace(trace_id)
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover
    click.echo(f"✓ deleted {trace_id}.")


@review.command(name="edit")
@click.argument("trace_id")
@_common_options
def review_edit(
    *,
    trace_id: str,
    api_key: str | None,
    base_url: str | None,
    as_json: bool = False,
    quiet: bool = False,
    verbose: bool = False,
) -> None:
    """Open the trace JSON in $EDITOR; PATCH any changes on save."""
    config = _resolve_config(api_key_flag=api_key, base_url_flag=base_url)
    key = _require_api_key(config)
    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            detail = c.get(trace_id)
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover

    editable = {
        "error_class": detail.trace.error_class,
        "task_description": detail.trace.task_description,
        "root_cause": detail.trace.root_cause,
        "technology": detail.trace.technology,
        "tags": list(detail.trace.tags),
        "context_snapshot": detail.trace.context_snapshot,
    }
    edited = click.edit(json_module.dumps(editable, indent=2))
    if edited is None:
        click.echo("(no changes)")
        return
    try:
        new_fields = json_module.loads(edited)
    except json_module.JSONDecodeError as exc:
        click.echo(f"invalid JSON: {exc}", err=True)
        sys.exit(EXIT_USER)

    diff = {k: v for k, v in new_fields.items() if editable.get(k) != v}
    if not diff:
        click.echo("(no changes)")
        return

    try:
        with Client(api_key=key, base_url=config.base_url) as c:
            c.update_trace(trace_id, **diff)
    except BorgError as exc:
        _print_error_and_exit(exc)
        return  # pragma: no cover
    click.echo(f"✓ updated {len(diff)} field(s) on {trace_id}.")


# ---------------------------------------------------------------------------
# Re-export Outcome / Visibility for tests that want named constants.
# ---------------------------------------------------------------------------

__all__ = [
    "EXIT_CLOSURE_BELOW_THRESHOLD",
    "EXIT_CLOSURE_INFRASTRUCTURE",
    "EXIT_NETWORK",
    "EXIT_OK",
    "EXIT_SERVER",
    "EXIT_USER",
    "Outcome",
    "Visibility",
    "main",
]
