"""ULID generation for idempotency keys.

ULIDs are 128-bit identifiers encoded as 26 uppercase Crockford
chars: 48 bits of millisecond timestamp followed by 80 bits of
cryptographically-random bytes. They sort lexically by creation time
at millisecond resolution, which is the property we want for
idempotency keys and request ids.

The Crockford alphabet (``0-9`` + ``A-Z`` minus ``I``, ``L``, ``O``,
``U``) deliberately omits visually-ambiguous characters and contains
no special characters at all — a useful guarantee that ULID output
cannot collide with the SDK's hex-only firewall by accident.

Reference: https://github.com/ulid/spec
"""

from __future__ import annotations

import os
import time
from typing import Final

__all__ = ["CROCKFORD_ALPHABET", "new_ulid"]

# Crockford base32: 0-9, then A-Z minus I, L, O, U.
CROCKFORD_ALPHABET: Final[str] = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"

_TS_LEN: Final[int] = 10  # 48-bit timestamp → 10 base32 chars (50 bits, top is 0).
_RND_LEN: Final[int] = 16  # 80-bit randomness → 16 base32 chars exactly.
_RND_BYTES: Final[int] = 10
_TS_MAX: Final[int] = (1 << 48) - 1


def new_ulid(
    *,
    now_ms: int | None = None,
    randomness: bytes | None = None,
) -> str:
    """Generate a new ULID.

    Returns a 26-char uppercase Crockford-base32 string. Sortable by
    creation time at millisecond resolution; the trailing 80 bits are
    cryptographically random by default.

    ``now_ms`` and ``randomness`` are injected for deterministic tests
    only — production callers should use the defaults.
    """
    if now_ms is None:
        now_ms = int(time.time() * 1000)
    if now_ms < 0 or now_ms > _TS_MAX:
        raise ValueError(f"now_ms out of 48-bit range: {now_ms}")
    if randomness is None:
        randomness = os.urandom(_RND_BYTES)
    if len(randomness) != _RND_BYTES:
        raise ValueError(f"randomness must be exactly {_RND_BYTES} bytes")

    ts = _encode_int(now_ms, _TS_LEN)
    rnd = _encode_int(int.from_bytes(randomness, "big"), _RND_LEN)
    return ts + rnd


def _encode_int(value: int, length: int) -> str:
    out = [""] * length
    for i in range(length - 1, -1, -1):
        out[i] = CROCKFORD_ALPHABET[value & 0x1F]
        value >>= 5
    return "".join(out)
