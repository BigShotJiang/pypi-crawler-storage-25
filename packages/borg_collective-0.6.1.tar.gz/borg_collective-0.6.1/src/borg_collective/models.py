"""Pydantic v2 wire models for the Borg Collective SDK.

These models are the SDK's typed mirror of the Worker contract — every
shape that crosses the network is declared here. Inputs use
``extra="forbid"`` so a typo dies locally before a 400 round-trips;
responses use ``extra="allow"`` so a future Worker field doesn't break
old SDK builds (forward-compatible reads, strict writes).

Hex-only firewall — every signature, pubkey, and signature-derived
identifier on the wire is 64- or 128-character lowercase hex. The
field validators enforce that shape locally so a malformed value
fails at construction time rather than at the Worker boundary.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Any, Final, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

__all__ = [
    "Agent",
    "AgentInfo",
    "AgentPubkey",
    "Amendment",
    "AmendmentCreated",
    "AmendmentInput",
    "AmendmentKind",
    "Counters",
    "FailureTrace",
    "FeedbackAck",
    "FeedbackOutcome",
    "FeedbackRequest",
    "MatchMode",
    "MyTraceListItem",
    "MyTracesResponse",
    "Outcome",
    "Provenance",
    "PublishedTrace",
    "SearchRequest",
    "SearchResult",
    "SearchResults",
    "Trace",
    "TraceDetail",
    "TrustLevel",
    "Visibility",
]

# ---------------------------------------------------------------------------
# Hex-shape constants
# ---------------------------------------------------------------------------
# Lowercase hex of length 64 (32 raw bytes) — error_signature, signer_pubkey,
# and the seed in `_signing`. 128 (64 raw bytes) is an Ed25519 signature.
_HEX_64: Final[str] = r"^[0-9a-f]{64}$"
_HEX_128: Final[str] = r"^[0-9a-f]{128}$"


# ---------------------------------------------------------------------------
# Enums — values are the wire strings the Worker validates against.
# ---------------------------------------------------------------------------


class Outcome(StrEnum):
    """Resolution outcome of a failure trace.

    Mirrors the Worker's enum at ``src/routes/traces.ts`` (validateBody
    line ~541). Lowercase wire values; the SDK exposes the StrEnum so
    callers get type-safe constants while still serializing as strings.
    """

    RESOLVED = "resolved"
    ABANDONED = "abandoned"
    ESCALATED = "escalated"


class Visibility(StrEnum):
    """Trace visibility scope.

    ``PRIVATE`` is owner-only; ``PUBLIC`` is broadcast to the federation.
    The SDK defaults :attr:`FailureTrace.visibility` to ``PRIVATE`` —
    pass ``Visibility.PUBLIC`` explicitly to broadcast.
    """

    PUBLIC = "public"
    PRIVATE = "private"


class AmendmentKind(StrEnum):
    """Amendment classification.

    ``RESOLUTION`` is "this is what worked"; ``CLARIFICATION`` is "more
    context"; ``CORRECTION`` is "the original was wrong". The Worker
    accepts all three; the SDK defaults to ``CLARIFICATION`` because it
    is the safest read on a bare amendment without a stated intent.
    """

    RESOLUTION = "resolution"
    CLARIFICATION = "clarification"
    CORRECTION = "correction"


class MatchMode(StrEnum):
    """Search match mode the Worker reports back on a /search response.

    See ``src/routes/search.ts`` (lines ~151-155). ``ERROR_SIGNATURE`` is
    the strongest match (exact 64-hex match); ``QUERY`` is a substring
    LIKE on error_text; ``FILTER`` is any combination of error_class
    and tags filtering.
    """

    ERROR_SIGNATURE = "error_signature"
    FILTER = "filter"
    QUERY = "query"


class TrustLevel(StrEnum):
    """Trust level the Worker assigns to an agent.

    v1 issues every agent ``"soft"`` on registration; ``"hard"`` is a
    v2 surface (spec §5.1) that arrives once pubkey enrollment becomes
    mandatory. Modelled as a StrEnum so the SDK forward-compatibly
    accepts a future ``"hard"`` value without an SDK rev — and so
    callers branching on trust get a typed constant rather than a
    bare string.
    """

    SOFT = "soft"
    HARD = "hard"


class Provenance(StrEnum):
    """Trace provenance — how the trace entered the federation.

    Mirrors the Worker's CHECK constraint at migration 0004:
    ``provenance IN ('organic', 'curated', 'test')``. ``ORGANIC`` is the
    DB default — every pre-E0.5 row backfills here. ``CURATED`` is for
    seed-corpus rows ingested from external sources (with a license).
    ``TEST`` is reserved for closure-test fixtures.
    """

    ORGANIC = "organic"
    CURATED = "curated"
    TEST = "test"


class FeedbackOutcome(StrEnum):
    """Outcome a caller reports for a trace they applied.

    Disjoint vocabulary from :class:`Outcome` (which is the publishing
    agent's resolution status) — the two enums never share values, so
    a typo is caught locally rather than silently mapping across
    domains. Only used by :class:`FeedbackRequest.outcome`.
    """

    HELPED = "helped"
    DIDNT_HELP = "didnt_help"


# ---------------------------------------------------------------------------
# Trace publishing — input + response
# ---------------------------------------------------------------------------


class FailureTrace(BaseModel):
    """Body for ``POST /traces`` — the publishable failure trace.

    Required fields (Worker enforces presence at the 400 boundary):
    ``error_text``, ``task_description``, ``approach_summary``,
    ``root_cause``, ``outcome``.

    Visibility defaults to :attr:`Visibility.PRIVATE`. Pass
    ``visibility=Visibility.PUBLIC`` explicitly to broadcast — making
    the broadcast posture opt-in is deliberate; a quiet PUBLIC default
    would let a caller leak a path or token they had not realized was
    in the body.

    ``error_signature`` is optional for unsigned publishes (the Worker
    computes it server-side). For signed publishes the Worker requires
    it in the body — the SDK does not auto-fill there because the
    server cannot recompute an identical value and still match the
    canonical bytes the client signed.

    The model is ``extra="forbid"`` — typos die locally, not at the
    400-boundary 30 ms later.
    """

    model_config = ConfigDict(extra="forbid", use_enum_values=False)

    error_signature: str | None = Field(default=None, pattern=_HEX_64)
    error_class: str | None = None
    error_text: str = Field(min_length=1, max_length=16384)
    task_description: str = Field(min_length=1)
    approach_summary: str = Field(min_length=1)
    root_cause: str = Field(min_length=1)
    outcome: Outcome
    technology: str | None = None
    tags: list[str] = Field(default_factory=list)
    context_snapshot: dict[str, Any] = Field(default_factory=dict)
    # E0.5: PRIVATE is the literal default. Explicit force_public=True
    # required at the publish() call site to make a trace public.
    visibility: Visibility = Visibility.PRIVATE
    signature: str | None = Field(default=None, pattern=_HEX_128)
    signer_pubkey: str | None = Field(default=None, pattern=_HEX_64)
    # E0.6: provenance attribution. None on construction means "let the
    # Worker apply its DEFAULT 'organic'". Set explicitly to CURATED on
    # seed-corpus ingest; source_url + license carry the attribution.
    provenance: Provenance | None = None
    source_url: str | None = None
    license: str | None = None
    # E0.7: link a follow-up trace to its parent. Used by `borg demo`
    # step 4 ("this is the resolution of trace X") and any future
    # follow-up flow. Nullable; legacy traces backfill NULL via
    # migration 0005.
    parent_trace_id: str | None = None


class PublishedTrace(BaseModel):
    """Response from ``POST /traces`` — minimal acknowledgement.

    Contains the ``trace_id`` the Worker assigned, whether the trace was
    accepted as signed, the ``error_signature`` (server-computed if the
    publish was unsigned), and an optional ``warning`` — currently
    ``"unsigned_trace"`` for soft-trust unsigned publishes (spec §2.1).

    ``extra="allow"`` so future server fields land without breaking old
    SDK builds.
    """

    model_config = ConfigDict(extra="allow")

    trace_id: str
    signed: bool
    error_signature: str = Field(pattern=_HEX_64)
    warning: str | None = None


class Trace(BaseModel):
    """Full trace as returned inside a ``GET /traces/:id`` response.

    Carries every wire field the Worker materializes — input fields
    plus the server-side ``trace_id``, ``agent_id``, ``signed``,
    ``signature``, ``signer_pubkey``, and ``created_at``.

    ``extra="allow"`` so future server-side fields surface as raw
    attributes without forcing an SDK upgrade.
    """

    model_config = ConfigDict(extra="allow", use_enum_values=False)

    trace_id: str
    agent_id: str
    error_signature: str = Field(pattern=_HEX_64)
    error_class: str | None = None
    error_text: str
    task_description: str
    approach_summary: str
    root_cause: str
    outcome: Outcome
    technology: str | None = None
    tags: list[str] = Field(default_factory=list)
    context_snapshot: dict[str, Any] = Field(default_factory=dict)
    visibility: Visibility
    signed: bool
    signature: str | None = Field(default=None, pattern=_HEX_128)
    signer_pubkey: str | None = Field(default=None, pattern=_HEX_64)
    # E0.6: provenance round-trips on read. Default ORGANIC matches the
    # Worker's DB default for pre-E0.5 rows.
    provenance: Provenance = Provenance.ORGANIC
    source_url: str | None = None
    license: str | None = None
    # E0.7: parent linkage on read. NULL for top-level traces.
    parent_trace_id: str | None = None
    created_at: int


# ---------------------------------------------------------------------------
# Counters + amendments
# ---------------------------------------------------------------------------


class Counters(BaseModel):
    """Funnel counters for a trace — the visible portion of the §2.3 funnel.

    All five start at 0 on a fresh trace. ``retrieved`` bumps on
    ``GET /traces/:id``; ``read``/``applied``/``helped``/``didnt_help``
    bump on ``POST /feedback`` claims (the Worker does not verify the
    claim — see ``src/routes/feedback.ts`` preamble).
    """

    model_config = ConfigDict(extra="allow")

    retrieved: int = 0
    read: int = 0
    applied: int = 0
    helped: int = 0
    didnt_help: int = 0


class Amendment(BaseModel):
    """One amendment on a trace, as returned inside ``GET /traces/:id``.

    v1 amendments are unsigned (spec §2 #7) — the parent trace's trust
    context is inherited. v2 will introduce signed amendments; until
    then the input model rejects ``signature``/``signer_pubkey``
    explicitly with a clear message.
    """

    model_config = ConfigDict(extra="allow", use_enum_values=False)

    amendment_id: str
    kind: AmendmentKind
    content: str
    author_agent_id: str
    created_at: int


class AmendmentInput(BaseModel):
    """Body for ``POST /traces/:id/amendments`` — append-only amendment input.

    ``kind`` defaults to :attr:`AmendmentKind.CLARIFICATION` so the wire
    payload always carries the field (server defaults can drift; an
    explicit field is the durable contract).

    The Worker rejects ``signature`` and ``signer_pubkey`` with a
    dedicated 400 ``amendments_signing_v2`` code — the SDK pre-empts
    that round-trip with a clear local error so callers porting from
    a future v2 client see *why*, not just *which field*.
    """

    model_config = ConfigDict(extra="forbid", use_enum_values=False)

    content: str = Field(min_length=1, max_length=16384)
    kind: AmendmentKind = AmendmentKind.CLARIFICATION

    @model_validator(mode="before")
    @classmethod
    def _reject_v2_signing_fields(cls, data: Any) -> Any:
        """Reject signature/signer_pubkey with a clear v2 message.

        ``extra="forbid"`` would catch these as generic "extra forbidden"
        errors; this validator runs first so the error tells the caller
        the field is reserved for v2, not that it is unknown.
        """
        if isinstance(data, dict):
            for key in ("signature", "signer_pubkey"):
                if key in data:
                    raise ValueError(
                        f"{key!r}: amendment signing is a v2 feature; v1 "
                        "amendments inherit the parent trace's trust context"
                    )
        return data


class AmendmentCreated(BaseModel):
    """Response from ``POST /traces/:id/amendments`` — minimal ack.

    Distinct from :class:`Amendment` (the GET-shape with content +
    author): the POST response intentionally omits ``content`` and
    ``author_agent_id`` because the caller already has both.
    """

    model_config = ConfigDict(extra="allow", use_enum_values=False)

    amendment_id: str
    trace_id: str
    kind: AmendmentKind
    created_at: int


class MyTraceListItem(BaseModel):
    """One row in :class:`MyTracesResponse` — abbreviated trace surface.

    Returned by ``GET /api/v1/agents/me/traces`` (E0.7) — the listing
    endpoint that backs ``borg review list``. Only carries enough to
    render a one-line summary; full content lives behind a
    ``GET /traces/:id`` (which ``borg review show`` issues).
    """

    model_config = ConfigDict(extra="allow", use_enum_values=False)

    trace_id: str
    error_class: str | None = None
    visibility: Visibility
    provenance: Provenance = Provenance.ORGANIC
    parent_trace_id: str | None = None
    error_preview: str
    created_at: int


class MyTracesResponse(BaseModel):
    """Response from ``GET /api/v1/agents/me/traces`` (E0.7).

    ``next_before`` is a ``created_at`` cursor for backwards pagination —
    pass it as ``before=`` on the next call. ``None`` means the page is
    the last one (fewer results than ``limit``).
    """

    model_config = ConfigDict(extra="allow")

    traces: list[MyTraceListItem]
    count: int
    next_before: int | None = None


class TraceDetail(BaseModel):
    """Full ``GET /traces/:id`` response.

    Bundles the trace, its amendments (oldest-first), and rolled-up
    counters. The Worker assembles this in one DB round-trip — see
    ``src/routes/traces.ts`` lines ~317-354.
    """

    model_config = ConfigDict(extra="allow")

    trace: Trace
    amendments: list[Amendment] = Field(default_factory=list)
    counters: Counters


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


class SearchRequest(BaseModel):
    """Body for ``POST /search``.

    Mirrors the Worker's "at least one criterion" rule (search.ts ~142):
    one of ``error_signature``, ``query``, ``error_class``, or a
    non-empty ``tags`` list must be provided. An empty ``tags=[]`` does
    NOT count — the SDK fails locally with the same posture as the
    Worker's 400 ``no_query_provided``.

    ``limit`` is a local convenience (the wire spec is silent but the
    Worker accepts 1..50); the SDK clamps at construction time.
    """

    model_config = ConfigDict(extra="forbid")

    error_signature: str | None = Field(default=None, pattern=_HEX_64)
    query: str | None = Field(default=None, min_length=1, max_length=256)
    error_class: str | None = None
    tags: list[str] = Field(default_factory=list)
    limit: int = Field(default=10, ge=1, le=50)

    @model_validator(mode="after")
    def _require_at_least_one_criterion(self) -> Self:
        """Mirror the Worker's no_query_provided guard.

        Empty ``tags`` does not count as a criterion — match the Worker
        behavior exactly so a local validation pass implies a server
        validation pass (modulo Worker-only state like rate limits).
        """
        if (
            self.error_signature is None
            and self.query is None
            and self.error_class is None
            and len(self.tags) == 0
        ):
            raise ValueError(
                "search requires at least one of error_signature, query, "
                "error_class, or non-empty tags"
            )
        return self


class SearchResult(BaseModel):
    """One row in a ``POST /search`` response.

    Counters are rolled up; ``preview`` is the first 200 chars of
    ``error_text``. ``extra="allow"`` so a future Worker field (e.g.
    similarity score) lands without an SDK rev.
    """

    model_config = ConfigDict(extra="allow", use_enum_values=False)

    trace_id: str
    error_signature: str = Field(pattern=_HEX_64)
    error_class: str | None = None
    outcome: Outcome
    signed: bool
    created_at: int
    preview: str
    counters: Counters


class SearchResults(BaseModel):
    """Wrapper for the ``POST /search`` response body."""

    model_config = ConfigDict(extra="allow", use_enum_values=False)

    results: list[SearchResult]
    count: int
    match_mode: MatchMode


# ---------------------------------------------------------------------------
# Feedback
# ---------------------------------------------------------------------------


class FeedbackRequest(BaseModel):
    """Body for ``POST /feedback``.

    Funnel monotonicity (spec §2.3, mirrored in ``src/routes/feedback.ts``):

    * ``read=True`` requires ``retrieved=True``
    * ``applied=True`` requires ``read=True``
    * ``outcome`` (helped/didnt_help) requires ``applied=True``

    Validated locally so a violation never round-trips. The Worker
    returns 400 ``funnel_violation``; the SDK raises before the
    network call.

    ``note`` is bounded to 512 chars to match the Worker's
    ``note_too_long`` ceiling.
    """

    model_config = ConfigDict(extra="forbid", use_enum_values=False)

    trace_id: str = Field(min_length=1)
    retrieved: bool = False
    read: bool = False
    applied: bool = False
    outcome: FeedbackOutcome | None = None
    note: str | None = Field(default=None, max_length=512)

    @model_validator(mode="after")
    def _enforce_funnel_monotonicity(self) -> Self:
        """Mirror the Worker's three-stage funnel guards.

        Validation order matches the Worker's: read→retrieved first,
        then applied→read, then outcome→applied. Each violation raises
        with a hint the caller can match against the Worker's
        ``funnel_violation`` / ``outcome_requires_applied`` codes.
        """
        if self.read and not self.retrieved:
            raise ValueError("funnel violation: read=True requires retrieved=True")
        if self.applied and not self.read:
            raise ValueError("funnel violation: applied=True requires read=True")
        if self.outcome is not None and not self.applied:
            raise ValueError("outcome requires applied=True")
        return self


class FeedbackAck(BaseModel):
    """Response from ``POST /api/v1/feedback`` — feedback acknowledgement.

    Worker shape: ``{recorded, trace_id, counters_updated, note?}``.
    ``counters_updated`` is ``False`` when the trace did not exist at
    feedback time (trace_judgments has no FK on trace_id, so the
    judgment row is still recorded — see ``feedback.ts`` preamble);
    the optional ``note`` field carries
    ``"trace_not_found_but_judgment_recorded"`` in that case.

    ``extra="allow"`` keeps the response forward-compatible.
    """

    model_config = ConfigDict(extra="allow")

    recorded: bool
    trace_id: str
    counters_updated: bool
    note: str | None = None


# ---------------------------------------------------------------------------
# Agent identity
# ---------------------------------------------------------------------------


class Agent(BaseModel):
    """Local representation of an agent identity.

    ``api_key`` is uniquely sensitive: it is the credential, not a
    handle. The default surfaces — ``model_dump()``, ``model_dump_json()``,
    ``repr()``, ``str()`` — never reveal it. To extract the key
    deliberately (e.g. when persisting to a secret store), pass
    ``exclude=set()`` to ``model_dump`` explicitly.

    Defense in depth: ``Field(repr=False, exclude=True)`` plus a
    custom ``__repr__`` and ``__str__`` that build the string by hand.
    Even a Pydantic regression would not regress the redaction.
    """

    model_config = ConfigDict(extra="allow", use_enum_values=False)

    agent_id: str
    display_name: str
    trust_level: str = "soft"
    created_at: int | None = None
    api_key: str = Field(repr=False, exclude=True)

    def __repr__(self) -> str:
        return (
            f"Agent(agent_id={self.agent_id!r}, "
            f"display_name={self.display_name!r}, "
            f"trust_level={self.trust_level!r})"
        )

    def __str__(self) -> str:
        return self.__repr__()


class AgentPubkey(BaseModel):
    """Response from ``POST /agents/me/pubkey`` — pubkey rotation ack.

    The Worker returns ``{agent_id, pubkey, updated_at}``. ``extra="allow"``
    keeps forward compatibility.
    """

    model_config = ConfigDict(extra="allow")

    agent_id: str
    pubkey: str = Field(pattern=_HEX_64)
    updated_at: int


class AgentInfo(BaseModel):
    """Response from ``GET /api/v1/agents/me`` — SDK whoami() probe.

    Returned shape (per the shipped Worker handler): ``agent_id``,
    ``display_name``, ``trust_level``, ``pubkey``, ``created_at``.
    Distinct from :class:`Agent` because :class:`Agent` carries the
    secret ``api_key`` (never on the wire after registration);
    :class:`AgentInfo` is the safe-to-display public profile.

    ``trust_level`` is typed as :class:`TrustLevel` so callers branch
    on a constant rather than a string. ``pubkey`` is JSON ``null``
    when the agent never enrolled or rotated to one — modelled as
    ``Optional[str]`` with the lowercase-hex shape enforced when
    present.

    ``extra="allow"`` keeps the response forward-compatible: a future
    Worker field (e.g. last_seen_at) lands without breaking old SDK
    builds.
    """

    model_config = ConfigDict(extra="allow", use_enum_values=False)

    agent_id: str
    display_name: str | None = None
    trust_level: TrustLevel = TrustLevel.SOFT
    pubkey: str | None = Field(default=None, pattern=_HEX_64)
    created_at: int
