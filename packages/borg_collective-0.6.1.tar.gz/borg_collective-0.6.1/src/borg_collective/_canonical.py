"""Canonical byte form for signing — spec §1.1.

Byte-for-byte parity with the Worker's `src/lib/canonical.ts`. Locked
by the shared fixture at `tests/fixtures/canonical-v1.json` — any drift
breaks that test by design (canonical form is a wire contract; changing
it invalidates every previously-signed trace across every peer
simultaneously, which is a v3-level decision per spec §5.4).

Rules:
  1. Recursively sort dict keys lexically.
  2. Arrays preserve element order (semantically ordered).
  3. Drop `signature` and `signer_pubkey` at the **top level only**.
     Deeper nested objects are not stripped — defense lives at the
     wire boundary, not arbitrarily deep in user-controlled data.
  4. UTF-8 byte output, compact JSON: no spaces, no newlines.
  5. Unicode is preserved literally — never `\\u`-escaped.
  6. Non-serializable input → ``TypeError``. No silent empty-bytes.

This module is intentionally content-agnostic: it does not validate
trace structure. The SDK's Pydantic models (``borg_collective.models``)
do that upstream.
"""

from __future__ import annotations

import json
from typing import Any, Final

__all__ = [
    "canonical_bytes",
    "canonical_bytes_for_trace",
]

_DROP_AT_TOP: Final[frozenset[str]] = frozenset({"signature", "signer_pubkey"})
_EMPTY: Final[frozenset[str]] = frozenset()


def canonical_bytes_for_trace(trace: dict[str, Any]) -> bytes:
    """Produce the canonical UTF-8 byte form of a trace for signing/verifying.

    The trace shape is documented in spec §1.1. This helper drops
    ``signature`` and ``signer_pubkey`` at the top level even if the
    caller forgot to — defense against accidentally double-including
    them in the signing input.
    """
    return canonical_bytes(trace, drop_top_keys=_DROP_AT_TOP)


def canonical_bytes(
    value: Any,
    *,
    drop_top_keys: frozenset[str] = _EMPTY,
) -> bytes:
    """Lower-level canonicalizer.

    Useful when the signing input shape differs from a trace — e.g. the
    ``error_signature`` computation in :mod:`borg_collective._error_signature`.

    ``drop_top_keys`` applies only at the top level; nested objects are
    sorted as-is. Mirrors the Worker's ``dropTopKeys`` semantics.
    """
    sorted_value = _sort_recursively(value, drop_top_keys)
    try:
        text = json.dumps(
            sorted_value,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=False,  # already sorted manually; keep behavior explicit
            allow_nan=False,
        )
    except (TypeError, ValueError) as exc:
        # Match the TS wrapper: any failure → TypeError with a clear msg.
        # We never want canonical_bytes to silently emit empty/partial output.
        raise TypeError(f"canonical_bytes: value is not JSON-serializable: {exc}") from exc
    return text.encode("utf-8")


def _sort_recursively(
    value: Any,
    drop_top_keys: frozenset[str],
) -> Any:
    if isinstance(value, dict):
        # Use sorted(value) which sorts by key ascending (str comparison) —
        # equivalent to TS `Object.keys(obj).sort()`. Filter drop set first
        # so we never touch dropped keys' values (they may be None, which
        # is harmless, but cleanest to skip).
        out: dict[str, Any] = {}
        for k in sorted(value):
            if k in drop_top_keys:
                continue
            out[k] = _sort_recursively(value[k], _EMPTY)
        return out
    if isinstance(value, list | tuple):
        # Tuples flatten to lists in JSON anyway; normalize here so the
        # output is byte-identical regardless of which the caller passed.
        return [_sort_recursively(v, _EMPTY) for v in value]
    return value
