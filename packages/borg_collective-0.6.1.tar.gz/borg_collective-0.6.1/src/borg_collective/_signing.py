"""Ed25519 signing — hex in, hex out. PyNaCl-backed.

The SDK's signing surface mirrors the Worker's ``verifySignature``
contract (hex in, ``bool`` out, never raises) and adds the
keypair-generation and signing helpers a publishing client needs.

All key material is **lowercase hex** on the wire:

* signing seed / verify key: 64 chars (32 raw bytes).
* signature: 128 chars (64 raw bytes).

This module is the **only** signing surface exposed to public callers.
The hex-only firewall (see CI) enforces that no alternate encoding
ever leaks into the SDK's transport boundary.
"""

from __future__ import annotations

import re
from typing import Any, Final

from nacl.exceptions import BadSignatureError
from nacl.signing import SigningKey, VerifyKey

from borg_collective._canonical import canonical_bytes_for_trace

__all__ = [
    "SigningKeyPair",
    "generate_keypair",
    "sign",
    "sign_trace",
    "signing_key_from_hex",
    "verify",
    "verify_key_from_hex",
    "verify_trace",
]

_HEX_64_RE: Final[re.Pattern[str]] = re.compile(r"^[0-9a-f]{64}$")
_HEX_128_RE: Final[re.Pattern[str]] = re.compile(r"^[0-9a-f]{128}$")


class SigningKeyPair:
    """An Ed25519 keypair carrying its public component as lowercase hex.

    Holds the raw 32-byte signing seed and exposes both the seed and
    verify-key hex. ``__repr__`` redacts the seed so the keypair can
    appear in logs without leaking secrets.
    """

    __slots__ = ("_signing_key",)

    def __init__(self, signing_key: SigningKey) -> None:
        self._signing_key = signing_key

    @classmethod
    def generate(cls) -> SigningKeyPair:
        """Generate a fresh random keypair."""
        return cls(SigningKey.generate())

    @classmethod
    def from_hex(cls, signing_key_hex: str) -> SigningKeyPair:
        """Construct from a 64-lowercase-hex seed (32 raw bytes)."""
        if not _HEX_64_RE.match(signing_key_hex):
            raise ValueError("signing_key_hex must be 64 lowercase hex chars")
        return cls(SigningKey(bytes.fromhex(signing_key_hex)))

    @property
    def signing_key_hex(self) -> str:
        """64-char lowercase hex of the 32-byte signing seed.

        Treat as secret. Never log; never include in error messages.
        """
        return bytes(self._signing_key).hex()

    @property
    def verify_key_hex(self) -> str:
        """64-char lowercase hex of the 32-byte verify (public) key."""
        return bytes(self._signing_key.verify_key).hex()

    def sign_bytes(self, message: bytes) -> str:
        """Sign ``message`` with this keypair. Returns 128-char hex."""
        return self._signing_key.sign(message).signature.hex()

    def sign_trace(self, trace_body: dict[str, Any]) -> str:
        """Canonicalize ``trace_body`` and sign it. Returns 128-char hex.

        Equivalent to ``self.sign_bytes(canonical_bytes_for_trace(body))``;
        kept as a method so the publish flow is a one-liner.
        """
        return self.sign_bytes(canonical_bytes_for_trace(trace_body))

    def __repr__(self) -> str:
        # Never leak the secret seed in repr.
        return f"SigningKeyPair(verify_key_hex={self.verify_key_hex!r})"


def generate_keypair() -> SigningKeyPair:
    """Return a fresh random :class:`SigningKeyPair`."""
    return SigningKeyPair.generate()


def signing_key_from_hex(signing_key_hex: str) -> SigningKeyPair:
    """Reconstruct a :class:`SigningKeyPair` from a 64-hex seed."""
    return SigningKeyPair.from_hex(signing_key_hex)


def verify_key_from_hex(verify_key_hex: str) -> VerifyKey:
    """Reconstruct a PyNaCl :class:`VerifyKey` from 64-hex public bytes."""
    if not _HEX_64_RE.match(verify_key_hex):
        raise ValueError("verify_key_hex must be 64 lowercase hex chars")
    return VerifyKey(bytes.fromhex(verify_key_hex))


def sign(signing_key_hex: str, message: bytes) -> str:
    """Sign ``message`` with the seed at ``signing_key_hex``.

    Returns the 128-char lowercase-hex Ed25519 signature. Raises
    ``ValueError`` if the seed is not 64 lowercase hex chars — sign is
    a privileged-input path; we want loud failures upstream, not a
    silent ``False`` (which is :func:`verify`'s job).
    """
    if not _HEX_64_RE.match(signing_key_hex):
        raise ValueError("signing_key_hex must be 64 lowercase hex chars")
    sk = SigningKey(bytes.fromhex(signing_key_hex))
    return sk.sign(message).signature.hex()


def sign_trace(signing_key_hex: str, trace_body: dict[str, Any]) -> str:
    """Canonicalize ``trace_body`` and sign it. Returns 128-char hex."""
    return sign(signing_key_hex, canonical_bytes_for_trace(trace_body))


def verify(verify_key_hex: str, message: bytes, signature_hex: str) -> bool:
    """Verify an Ed25519 signature. Returns ``True`` iff valid; never raises.

    Mirrors the Worker's ``verifySignature`` contract: every malformed
    input (wrong length, uppercase hex, non-hex chars, tampered bytes)
    collapses to ``False``. Callers that need a reason should validate
    upstream — verify is the defensive last line, intentionally a pure
    predicate.
    """
    if not isinstance(verify_key_hex, str) or not _HEX_64_RE.match(verify_key_hex):
        return False
    if not isinstance(signature_hex, str) or not _HEX_128_RE.match(signature_hex):
        return False
    try:
        vk = VerifyKey(bytes.fromhex(verify_key_hex))
        vk.verify(message, bytes.fromhex(signature_hex))
    except (BadSignatureError, ValueError, TypeError):
        return False
    return True


def verify_trace(
    verify_key_hex: str,
    trace_body: dict[str, Any],
    signature_hex: str,
) -> bool:
    """Canonicalize ``trace_body`` and verify ``signature_hex`` against it.

    Returns ``True`` iff the canonical bytes verify under the given
    pubkey. Never raises.
    """
    try:
        message = canonical_bytes_for_trace(trace_body)
    except (TypeError, ValueError):
        return False
    return verify(verify_key_hex, message, signature_hex)
