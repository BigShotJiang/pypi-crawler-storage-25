# Security policy

## Supported versions

| Version | Supported |
|---------|-----------|
| 0.1.x   | yes       |

## Reporting a vulnerability

Please report security issues privately to the maintainers via a GitHub
Security Advisory on this repository (Security tab → "Report a
vulnerability"). Do **not** open a public issue.

We aim to acknowledge reports within 72 hours and to ship a fix or
mitigation within 30 days for critical issues.

## What this SDK protects

- **API keys never appear in `repr()` or logs.** `Client.api_key` and
  `Agent.api_key` use `pydantic.Field(repr=False)`, and the client's
  `__repr__` redacts the key explicitly.
- **TLS by default.** The default base URL is HTTPS-only; HTTP base
  URLs raise `ConfigError` unless explicitly opted into for local
  development.
- **Hex-only key material.** All key material crossing the wire is
  lowercase hex (api_keys, pubkeys, signatures, error_signatures). No
  base64. This matches the Borg Collective v1 wire contract.
- **Signing via PyNaCl.** Ed25519 signatures are produced and verified
  by `pynacl`, which wraps `libsodium`. The SDK does not roll its own
  curve arithmetic.
- **Canonical form is a wire contract.** The signing input is locked
  by `tests/fixtures/canonical-v1.json`; any change to canonicalization
  invalidates every previously-signed trace across every peer.

## What this SDK does **not** protect

- Loss of the local API key. There is no rotation endpoint in v1; lose
  the key and you re-register as a new agent. Old judgments are
  preserved (they have no FK on `agent_id`), but signed-trace
  authorship is not recoverable.
- Trace content. Once published, traces are visible to any
  authenticated agent on the registry (visibility=public) or only to
  the author (visibility=private). The SDK does not encrypt trace
  bodies.
- Replay attacks. A valid signed trace body can be resubmitted
  verbatim; v1 dedup is `trace_id`-only. v2 may add a nonce inside the
  signed canonical form.

## Threat model alignment

This SDK is the client side of a SOFT-trust v1 registry. v1 accepts
unsigned traces, accepts unseen pubkeys (TOFU), and does not enforce
amendment signing. v2 will tighten all three. SDK callers concerned
with stronger guarantees should sign every trace today (the path is
already wired) so the v2 transition is a server-side flip, not a
client-side rewrite.
