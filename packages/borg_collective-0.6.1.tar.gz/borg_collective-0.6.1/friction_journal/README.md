# Borg Friction Journal

A running record of friction observed running Borg in real environments — bugs with reproductions, schema gaps, integration pain, telemetry holes, design questions surfaced by use. This is distinct from the issue tracker: the issue tracker is for things to fix; the journal is for *what we've actually seen*, including resolved entries kept for institutional memory and known-but-deferred state we don't want to forget.

## What goes here

- Production bugs with reproduction steps (e.g. `2026-Q2-search-500-on-long-no-match.md`)
- Schema gaps where the `FailureTrace` shape doesn't fit a real case
- Integration friction in specific hosts (Claude Code, Hermes, OpenClaw, …)
- Telemetry / observability gaps that bit us during debugging
- Open design questions where the answer affects future work
- Resolved issues kept for the record so we don't relitigate them

If the entry would only ever matter inside one PR, it belongs in that PR. If it would matter the next time someone hits the same wall, it belongs here.

## Schema

Each entry is a Markdown file with YAML frontmatter:

```yaml
---
version: 0.1
status: open | locked
severity: low | medium | high   # optional; required for `open` bug entries
last_updated: YYYY-MM-DD
---
```

- `version` — schema version, currently `0.1`. Bump if the frontmatter contract changes incompatibly.
- `status` — `open` for active issues, `locked` for resolved or accepted-as-is entries that shouldn't be edited further.
- `severity` — only meaningful while `status: open`. Use `high` for prod-affecting, `medium` for surprising-but-bounded, `low` for cosmetic / design-debt.
- `last_updated` — ISO date of the most recent edit.

Body skeleton (adjust sections to fit the entry; not every entry needs every section):

```markdown
# <one-line title in sentence case>

**Date:** YYYY-MM-DD (or "Date discovered:" for ongoing bugs)
**Scope:** <file/module/endpoint affected>  — or **Repo:** + **Endpoint:** for service bugs
**Status:** <short prose status if frontmatter `locked` doesn't capture it>

## What happened          <!-- post-mortem framing, or "## What happens" for ongoing -->

Plain-prose narrative of the friction. What you tried, what failed, what surprised you.

## Reproduction           <!-- when applicable -->

Concrete steps. Curl invocations, shell commands, code snippets — whatever a future
reader needs to confirm the entry still describes reality.

## Implications           <!-- or "Why it matters", "Next steps", "Resolution" -->

What changes because of this. Linked PRs / commits / issues if any.
```

The body is intentionally not rigid — entries have varied between post-mortems, reproductions, and design notes. Match the section names already used by adjacent entries when in doubt.

## Filename convention

`<YYYY-Qn>-<kebab-case-summary>.md`

Examples:
- `2026-Q2-search-500-on-long-no-match.md`
- `2026-Q2-seed-corpus-provenance.md`

The quarter prefix lets `ls` order entries chronologically without invading the filesystem with a date hierarchy.

## How to file (alpha users)

Open a PR against `borg-collective-py` adding a new file under `friction_journal/`, or send the markdown directly to the maintainer (Telegram, email, GitHub issue) and we'll land it for you. Don't worry about polish — practical entries that name the failure and how to reproduce it are far more useful than well-formatted entries that don't.

If you can attach a `FailureTrace` JSON or a federation `trace_id`, do — friction entries that link to a published trace are the highest-signal contributions we get.
