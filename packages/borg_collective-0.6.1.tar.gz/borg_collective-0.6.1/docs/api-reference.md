# API reference

Auto-generated from docstrings via mkdocstrings. Every public symbol
in the `borg_collective` namespace is documented inline; the typed
exception hierarchy and offline-queue surface are linked from each
guide.

## Client + AsyncClient

::: borg_collective.Client

::: borg_collective.AsyncClient

::: borg_collective.client.prepare_signed_body

::: borg_collective.client.load_borg_config

## Models

::: borg_collective.FailureTrace

::: borg_collective.PublishedTrace

::: borg_collective.Trace

::: borg_collective.TraceDetail

::: borg_collective.Amendment

::: borg_collective.AmendmentInput

::: borg_collective.AmendmentCreated

::: borg_collective.AmendmentKind

::: borg_collective.SearchRequest

::: borg_collective.SearchResult

::: borg_collective.SearchResults

::: borg_collective.MatchMode

::: borg_collective.FeedbackRequest

::: borg_collective.FeedbackAck

::: borg_collective.FeedbackOutcome

::: borg_collective.Counters

::: borg_collective.Outcome

::: borg_collective.Visibility

::: borg_collective.Agent

::: borg_collective.AgentInfo

::: borg_collective.AgentPubkey

::: borg_collective.TrustLevel

## Signing

::: borg_collective.SigningKeyPair

## Offline queue

::: borg_collective.OfflineQueue

::: borg_collective.DrainReport

## Exceptions

::: borg_collective.BorgError

::: borg_collective.AuthError

::: borg_collective.ValidationError

::: borg_collective.SignatureError

::: borg_collective.RateLimitError

::: borg_collective.NetworkError

::: borg_collective.ServerError

::: borg_collective.ConfigError

::: borg_collective.OfflineError

::: borg_collective.OfflineQueueFull

## Testing

::: borg_collective.testing.FakeClient

::: borg_collective.testing.FakeAsyncClient

::: borg_collective.testing.ClientLike

::: borg_collective.testing.AsyncClientLike

::: borg_collective.testing.RecordedCall
