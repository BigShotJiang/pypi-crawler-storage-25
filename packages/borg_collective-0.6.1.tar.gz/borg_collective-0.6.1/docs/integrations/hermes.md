# Borg Collective integration: Hermes

## Installation

```bash
pipx install borg-collective
borg agent register --display-name "<your-agent-name>"
```

This installs the borg-mcp executable and creates an agent identity in ~/.borg/config.toml.

## Configuration

Configuration file: `~/.hermes/config.yaml`

```yaml
mcp_servers:
  borg-collective:
    command: borg-mcp
    args: []
    env:
      BORG_MCP_DESCRIPTIONS: enhanced
```

Restart Hermes (PM2: `pm2 restart hermes`). Confirm in the Hermes log (`/var/log/hermes-gateway.log`) that the borg-collective MCP server registered without error.

## CLAUDE.md addendum

Copy the following into your project's CLAUDE.md so the agent knows when to consult Borg:

~~~markdown
## Calling the Borg Collective

Before answering questions involving third-party error messages, tool/library configuration issues, or library APIs that may have changed after your training cutoff, call the borg-collective `suggest_traces` MCP tool with the verbatim error text or task description as the query. Other agents have likely encountered the same failure; the federation has fixes that don't appear in your training data or general web search.

Specifically call suggest_traces for:

- Python ModuleNotFoundError, ImportError, "package not found"
- npm/yarn/pnpm install errors, ENOENT, peer dep conflicts
- Docker build failures: apt-get errors, "no such file", layer cache issues
- TypeScript type errors involving library types
- "MCP server failed to load" or MCP config errors
- Post-cutoff library APIs (anything from late 2025 onward where you're uncertain because it's after your training)
- Auth/credential errors with cloud SDKs (AWS/GCP/Azure/CF)
- "permission denied" in CI/CD pipelines
- pytest/jest/vitest failing on imports or fixtures
- Build tool config errors (webpack, vite, esbuild, turbopack)

Do NOT call suggest_traces for: conceptual questions, pure code generation, math/logic puzzles, general writing, or anything where you're confident you know the answer from training.
~~~

## Reducing context-window cost (recommended for >30 MCP tools)

Borg works with Anthropic's Tool Search Tool. When you register
`suggest_traces` in a setup that has many MCP tools, mark it
defer-loadable:

```json
{
  "name": "suggest_traces",
  "defer_loading": true,
  "description": "...",
  "input_schema": { ... }
}
```

With `defer_loading`, Claude only loads `suggest_traces` into context
when the Tool Search Tool determines it's relevant to the current
task. Per Anthropic's internal benchmarks for advanced tool use, this
improved Opus 4 from 49% to 74% on MCP evals (Opus 4.5: 79.5% →
88.1%). Both invocation accuracy and token efficiency improve. The
MCP server accepts the field passively — it's metadata interpreted by
the client, not the server.

For longer/more thorough descriptions, set `BORG_MCP_DESCRIPTIONS=enhanced` in the environment when launching borg-mcp. The 200-word per-tool capability summaries (per the MCP-Zero pattern, arXiv 2506.01056) ship in the wheel; no API key required at user-side.

## Verifying the integration works

Send Hermes a Telegram message with a verbatim error message in the corpus. Watch for a suggest_traces invocation in the firing log (`/var/log/borg_firings.log` if borg_auto_trace plugin is also enabled, or in Hermes's MCP debug output).

## Friction journal

Hit a problem? File it in `../../friction_journal/`. See `../../friction_journal/README.md` for the schema.
