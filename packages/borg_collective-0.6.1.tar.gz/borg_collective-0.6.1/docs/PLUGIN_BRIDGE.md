# Plugin federation bridge — `borg_auto_trace` → federation

Phase E0.7 closes the gap between the local `borg_auto_trace` plugin
(which writes Hermes session traces to `~/.borg/traces.db`) and the
federation registry. Configure once via `~/.borg/config.toml`; the
bridge fires automatically on FAILURE captures.

## How it fires

The plugin's `on_session_end` hook runs after each Hermes session
that had ≥ 3 tool calls. It infers an outcome from the last tool
result via `_infer_outcome`:

- `success` (success tokens like "completed", "ok", "passed")
- `failure` (failure tokens like "error", "exception", "traceback")
- `unknown`

**Only FAILURE sessions trigger the federation publish.** Success
sessions still go to local SQLite — the federation stays focused on
failures-with-fixes.

```
Hermes session end (≥ 3 tool calls)
    ↓
_infer_outcome
    ↓
local SQLite save_trace ← always happens
    ↓
outcome == "failure"?
    ↓ yes
_maybe_publish_failure_to_federation
    ↓
load_auto_publish_config(~/.borg/config.toml)
    ↓
mode != "false"?
    ↓ yes
publish_to_federation
    ↓
forces visibility=PRIVATE
    ↓
POST /api/v1/traces  → success → log to stderr (mode=prompt)
                    → failure → append to ~/.borg/publish_queue.jsonl
```

## Config

`~/.borg/config.toml` gets a new section. It defaults to `prompt`
during `borg init` (or after the E0.7 upgrade migration runs) — no
action needed unless you want a different mode.

```toml
[plugin.auto_trace]
auto_publish = "prompt"  # default
```

Allowed values:

| mode      | behaviour                                                                |
| --------- | ------------------------------------------------------------------------ |
| `false`   | Local SQLite only. Legacy pre-E0.7 behaviour. The plugin captures normally; nothing reaches the federation. |
| `prompt`  | POST as private. Logs `[borg] Captured failure published privately as <trace_id>` to stderr on each capture so you know it happened. **Default.** |
| `private` | POST as private silently. Same as `prompt` minus the stderr line.        |
| `review`  | POST as private + tag with `needs_review`. `borg review list` highlights these for triage. |

## Failure modes

### Federation unreachable

The publish call goes through `httpx`. If the network is down (or
the Worker returns a 5xx), the wire body is appended to
`~/.borg/publish_queue.jsonl` and a `[borg] Federation unreachable;
trace queued at ~/.borg/publish_queue.jsonl. Run \`borg drain\` when
network recovers.` line goes to stderr.

The plugin **never raises** — Hermes cannot afford a plugin
exception during session teardown. Even a `RuntimeError` from a
bridge bug routes to the dead-letter queue.

### Drain recovery

```sh
borg drain
```

reads every line of the queue, attempts the POST, and removes
successes. Failures stay in the queue for the next attempt. Atomic:
the queue file is rewritten via tempfile + rename so an interrupted
drain doesn't lose entries.

### borg_collective unavailable

If the SDK isn't importable (e.g. installed in a different venv from
Hermes), the plugin still loads — the bridge is gated behind
`_FEDERATION_AVAILABLE = False`. Local SQLite captures continue;
publishes are skipped. A one-line stderr warning is emitted on
plugin import.

## What gets published

Only the federation-shaped subset of the local trace, with these
mappings:

| federation field         | source                                                  |
| ------------------------ | ------------------------------------------------------- |
| `error_class`            | `_extract_error_class(last_result)` (regex match)      |
| `error_text`             | `last_result[:16000]`                                   |
| `task_description`       | `_auto_state.task_desc[:1000]`                          |
| `approach_summary`       | "Hermes session: N tool calls. Last result: ..."        |
| `root_cause`             | "(inferred from session — needs review)"                |
| `outcome`                | always `abandoned` (FAILURE sessions; tag for review)   |
| `tags`                   | `["hermes-auto", "v0.5"]` (+ `"needs_review"` if mode=review) |
| `context_snapshot`       | `{local_trace_id, tool_call_count, tool_names: [...]}` |
| `visibility`             | always `private` (defense-in-depth at bridge layer)     |

The mapping is intentionally lossy: only enough goes to the
federation to make the trace reviewable + searchable later. The
rich captured detail (file paths, exact tool args, full result
text) stays local and is recovered on `borg review show` only if
you copy from the local SQLite.

## What does NOT get published

- Success sessions (only failures fire the bridge)
- Sessions with < 3 tool calls (plugin threshold)
- File contents from `Read` tool calls
- Exact CLI args from `Bash` tool calls
- LLM message content (the plugin's `_borg_sdk_patch` for guidance
  injection is a no-op in the v0.5 reconstruction; even if it
  weren't, the patched messages stay client-side)

## Smoke test

To exercise the bridge directly without waiting for a Hermes session:

```python
import sys, unittest.mock as um
sys.path.insert(0, '/root/.hermes/plugins')
import borg_auto_trace as plugin

plugin._auto_state.reset()
plugin._auto_state.task_desc = "smoke"
plugin._auto_state.tool_calls = [
    {"name": "Bash", "args": {}, "result": "ok", "started_at": 0, "completed_at": 1},
    {"name": "Read", "args": {}, "result": "ok", "started_at": 1, "completed_at": 2},
    {"name": "Bash", "args": {}, "result": "Traceback ImportError", "started_at": 2, "completed_at": 3},
]
with um.patch.object(plugin, '_trace_save', um.MagicMock(return_value='smoke')), \
     um.patch.object(plugin, '_borg_initialized', True):
    plugin.on_session_end("smoke", messages=[])
```

You should see `[borg] Captured failure published privately as
&lt;trace_id&gt;.` on stderr if `auto_publish` is `prompt` (default).
The trace will land in your federation private queue;
`borg review list` will show it.
