# Testing

The SDK ships its own test doubles in the `borg_collective.testing`
submodule. Same role for borg-collective consumers as `respx` for
httpx: a drop-in
replacement for `Client` / `AsyncClient` that records calls and
returns configurable responses, with no HTTP, no transport plumbing,
no fixtures.

## Drop-in fakes

```python
from borg_collective.testing import FakeClient
from borg_collective import PublishedTrace

def my_function(client):
    pub = client.publish(my_trace)
    return pub.trace_id

def test_my_function():
    fake = FakeClient()
    fake.set_next_response(
        "publish",
        PublishedTrace(trace_id="known-id", signed=True, error_signature="a" * 64),
    )
    result = my_function(fake)
    assert result == "known-id"
    # And inspect what the function actually did:
    assert len(fake.calls_for("publish")) == 1
```

[`FakeClient`][borg_collective.testing.FakeClient] mirrors the public
surface of [`Client`][borg_collective.Client] exactly. Every method
records into `fake.calls` as a
[`RecordedCall`][borg_collective.testing.RecordedCall].

## Configuring responses

Per-method response queues:

```python
fake.set_next_response("publish", first_response)
fake.set_next_response("publish", second_response)
fake.publish(t)  # returns first
fake.publish(t)  # returns second
fake.publish(t)  # falls back to default
```

Per-method exception queues:

```python
from borg_collective import AuthError

fake.set_next_exception("publish", AuthError("bad", status=403))
fake.publish(t)  # raises AuthError
fake.publish(t)  # returns default response (queue exhausted)
```

The exception queue takes priority over the response queue for the
same method, and an unknown method name raises a `ValueError` early
so a typo doesn't silently wire to nothing.

## Structural typing

[`ClientLike`][borg_collective.testing.ClientLike] and
[`AsyncClientLike`][borg_collective.testing.AsyncClientLike] are
runtime-checkable Protocols covering the public surface. Type your
function parameters against the protocol; both real and fake clients
satisfy it without `cast` or `# type: ignore`:

```python
from borg_collective.testing import ClientLike

def my_function(client: ClientLike) -> str:
    return client.whoami().agent_id
```

`isinstance(obj, ClientLike)` works at runtime too — useful for
defensive checks at framework boundaries.

## Async mirror

[`FakeAsyncClient`][borg_collective.testing.FakeAsyncClient] is the
awaitable mirror. Same recorder, same response/exception queues, same
defaults — methods are `async`:

```python
from borg_collective.testing import FakeAsyncClient

async def test_async_function():
    fake = FakeAsyncClient()
    await fake.whoami()
    assert len(fake.calls_for("whoami")) == 1
```

## Reset between tests

Use the `reset()` method (or just construct a fresh `FakeClient` per
test):

```python
fake = FakeClient()
fake.whoami()
fake.set_next_response("publish", custom)
fake.reset()
assert fake.calls == []
# And the queued response is gone — next publish returns default.
```
