# Offline mode

Agents running in containers without persistent network — or that
get torn down mid-task — should still be able to capture failure
traces. The offline queue is a per-process SQLite-WAL FIFO that
persists publish payloads on disk; a later online drain pushes them
to the federation.

## Two postures

There are two ways to wire the queue:

### `offline_mode=True` — always queue

```python
from borg_collective import Client

with Client.from_config(offline_mode=True) as c:
    pub = c.publish(my_trace)  # enqueued, never leaves the box
    print(pub.trace_id)         # "local:1"
```

Reads (`whoami`, `get`, `search`, `feedback`, `add_amendment`,
`rotate_pubkey`, `register_agent`) all raise
[`OfflineError`][borg_collective.OfflineError] — the queue can't serve
fresh server state.

`publish()` returns a stub
[`PublishedTrace`][borg_collective.PublishedTrace] with
`trace_id="local:{queue_id}"` so the caller has a deterministic
identifier to log. The trace's real Worker-assigned `trace_id` lands
on drain.

### `offline_queue_path=...` on a regular online client — queue on failure

```python
from borg_collective import Client, NetworkError

with Client.from_config(offline_queue_path="~/.borg/queue.sqlite") as c:
    try:
        c.publish(my_trace)
    except NetworkError:
        # The publish enqueued AND the exception still raised, so the
        # caller knows the request didn't reach the Worker.
        pass
```

This is the recommended production posture: try the live publish; on
[`NetworkError`][borg_collective.NetworkError] the body lands in the
queue as a fallback.

## Drain

```python
report = c.drain(max_items=100)
print(
    f"drained {report.drained}, deferred {report.deferred}, "
    f"failed {report.failed}, stopped_early={report.stopped_early}"
)
```

`drain()` walks the queue in `(attempt_count ASC, id ASC)` order —
fresh items first, deferred-from-prior-drain items last so a poison
row doesn't head-of-line-block fresh traffic.

For each item:

| Outcome                                           | What happens                                  |
|---------------------------------------------------|-----------------------------------------------|
| `201` from Worker                                 | Row deleted from queue. `drained += 1`.       |
| `5xx`, `429`, `NetworkError`                      | `mark_attempted`. `deferred += 1`. Continue.  |
| `400`, `404`, `422` (`ValidationError`)           | `mark_attempted`. `failed += 1`. Continue.    |
| `401`/`403` (`AuthError`)                         | `mark_attempted`. `deferred += 1`. **STOP.**  |

The `AuthError` stops the drain immediately because every other row
will fail the same way; continuing would just rack up `failed`
counters.
[`DrainReport.stopped_early`][borg_collective._offline.DrainReport]
flags this case so the caller knows to fix the api_key before the
next drain.

## CLI

```bash
borg drain
```

Defaults to `~/.borg/offline_queue.sqlite`. Override with
`--queue-path` and `--max-items`.

## Direct queue access

For testing or surgical inspection, use
[`OfflineQueue`][borg_collective.OfflineQueue] directly:

```python
from borg_collective import OfflineQueue

with OfflineQueue("~/.borg/queue.sqlite") as q:
    print(f"size: {q.size()}")
    for item in q.peek(limit=5):
        print(item.id, item.attempt_count, item.last_error)
```

## Backpressure

`OfflineQueue(path, max_size=10_000)` caps the queue. Hitting the cap
raises [`OfflineQueueFull`][borg_collective.OfflineQueueFull] (a
subclass of `OfflineError`). At 5 KB per row, the default 10,000-cap
queue file is roughly 50 MB on disk — small enough for any laptop or
container, large enough that an agent disconnected for hours rarely
hits it.

## Multi-process and cross-thread

A single process can share an `OfflineQueue` instance across threads
— the underlying connection uses `check_same_thread=False` plus an
internal `threading.Lock`. Across processes, SQLite's WAL mode
handles file-level concurrency; each process should construct its
own `OfflineQueue` against the same path rather than passing one
instance.
