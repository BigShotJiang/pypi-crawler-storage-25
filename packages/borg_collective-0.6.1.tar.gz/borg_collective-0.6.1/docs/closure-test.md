# Closure test

The **closure test** is the v1 done-gate for the Borg Collective
federation. One assertion: a signed failure trace published by agent
A round-trips through the federation and visibly affects agent B's
view within a bounded time window. Below 95% closure over N >= 20
trials is a Sev-1 federation regression that requires rollback.

This page documents the methodology, the result schema, and the
failure modes. It is the canonical reference for the test; the
implementation lives at `src/borg_collective/_closure.py` and is
exercised by `tests/integration/test_closure.py` and the
`borg closure-test` CLI subcommand.

---

## 1. What is closure?

Closure is the operational definition of "the federation works": a
trace published by one agent reaches another agent, is verified, and
produces a measurable bidirectional signal. A single trial walks the
following six transitions:

```
T0 ──publish──> T1 ──propagate──> T2 ──fetch──> T3 ──verify──> T4 ──feedback──> T5 ──counter_confirm──> T6
```

| Transition         | Phase name in `closure_results.json` | Description |
|--------------------|--------------------------------------|-------------|
| T0 → T1            | `publish`                            | A signs the trace and POSTs it; Worker assigns `trace_id`. |
| T1 → T2            | `propagate`                          | B polls `/search` filtered by a per-trial `error_class` until the trace surfaces. |
| (overlap)          | `search`                             | Cumulative HTTP time of the search calls executed during `propagate` (informational subset). |
| T2 → T3            | `fetch`                              | B retrieves the full trace via `GET /traces/:id`. |
| T3 → T4            | `verify`                             | B reconstructs the canonical bytes A signed (server-added fields stripped) and verifies the Ed25519 signature locally. |
| T4 → T5            | `feedback`                           | B POSTs `/feedback` with `applied=true, outcome=helped`. |
| T5 → T6            | `counter_confirm`                    | A polls `GET /traces/:id` until `counters.helped` reaches `initial + 1`. |

A trial is `"success"` only when all six transitions complete.

---

## 2. Why closure is the v1 done-gate

Three properties any working federation must have. Closure tests all
three in one trial:

1. **Durable transmission.** A's publish reaches D1 and survives long
   enough for B to retrieve it.
2. **Trust verification.** B reconstructs the signed bytes and the
   Ed25519 signature verifies under A's pubkey. The federation
   carries trust, not just bytes.
3. **Bidirectional signaling.** B's `/feedback` writes to a counter
   that A can observe. The federation is not write-only — A's view of
   the trace changes because of what B saw.

A federation that fails any one of these is not v1-ready, regardless
of how clean the unit tests look. Closure is the integration that
asserts the contract end to end against the live Worker.

---

## 3. What this test does NOT measure

Be honest about scope:

- **Cross-IP federation.** A and B share the runner IP. The
  per-IP register cap is unexercised; multi-region routing is
  unexercised.
- **Cross-region performance.** D1 is a single-region database; the
  measured `time_to_closure_ms` reflects single-region propagation,
  not edge-routed. Latency baselines from this test do not predict
  multi-region performance.
- **Arbitrary agent onboarding.** The test uses a cached pair to
  avoid burning the Worker's per-IP register cap. First-time agent
  onboarding is exercised by the existing integration suite, not here.
- **Worker-side pubkey publication.** v0.1.3 verifies signatures
  against locally-known A pubkeys (the test fixture caches the
  `SigningKeyPair` instances). A future SDK release that adds a
  public `get_agent(id)` method will allow Worker-side pubkey lookup
  for arbitrary agents; the result schema's
  `signature_verification_rate` field is already shaped for that
  extension.
- **Closure under load.** Trials run sequentially. Concurrent
  publishes (existing integration suite, `test_concurrent_publishes_one_agent`)
  exercise D1 row races; closure does not.
- **Negative-path verification.** Tampered traces, version skew, and
  bad signatures are out of scope; future v0.2 work.

---

## 4. Test methodology

### Per-trial pseudocode

```python
trial_uuid = uuid4()
error_class = f"ClosureTestError_{run_uuid[:8]}_{trial_uuid[:8]}"

# 1. A publishes signed
published = client_a.publish(
    FailureTrace(
        error_class=error_class,
        error_text=f"Closure test trial {i+1} of {n_trials}, run={run_uuid}",
        outcome=Outcome.RESOLVED,
        visibility=Visibility.PUBLIC,
        ...
    ),
    signing_key=kp_a,
)

# 2. B polls search
deadline = monotonic() + 5.0
while monotonic() < deadline:
    results = client_b.search(error_class=error_class, limit=10)
    if any(r.trace_id == published.trace_id for r in results.results):
        break
    sleep(0.2)

# 3. B fetches the full trace
detail = client_b.get(published.trace_id)

# 4. B verifies A's signature against locally-known A pubkey
body = detail.trace.model_dump(mode="json", exclude_none=True)
for k in ("trace_id", "agent_id", "signed", "created_at"):
    body.pop(k, None)
sig_ok = verify_trace(kp_a.verify_key_hex, body, detail.trace.signature)

# 5. B publishes feedback
client_b.feedback(
    published.trace_id,
    retrieved=True, read=True, applied=True,
    outcome=FeedbackOutcome.HELPED,
)

# 6. A confirms helped++
deadline = monotonic() + 10.0
while monotonic() < deadline:
    a_view = client_a.get(published.trace_id)
    if a_view.counters.helped >= initial_helped + 1:
        break
    sleep(0.5)
```

### Why N=20 default

Twenty trials is the smallest sample where a 95% threshold tolerates
exactly one failure (`19/20 = 95%` passes; `18/20 = 90%` fails).
This trades resolution for cost: `--trials 100` is strictly more
informative but burns 100 traces against the dev corpus per run.
20 is the daily-heartbeat default; a developer debugging a regression
runs `--trials 100` for higher resolution.

### Phase budgets

| Phase             | Timeout        | Poll interval | Rationale |
|-------------------|----------------|---------------|-----------|
| `propagate`       | 5 s            | 200 ms        | Matches existing integration-suite tolerance for D1 indexing latency. |
| `counter_confirm` | 10 s           | 500 ms        | Doubles the propagate budget — feedback writes go through the Worker's counter rollup path which has its own propagation step. |

These constants live at the top of `_closure.py` and are not
configurable from the CLI. Tighter budgets are a future option once
we have a baseline.

---

## 5. closure_results.json schema

Versioned by `version: "1"` so consumers (CI alerting, trend
dashboards) can branch on a future v2 shape.

### Top-level fields

| Field                          | Type                  | Semantics |
|--------------------------------|-----------------------|-----------|
| `version`                      | `"1"`                 | Schema version. Bump on any breaking change. |
| `timestamp_utc`                | ISO-8601 string       | When the run started. UTC. |
| `sdk_version`                  | string                | `borg_collective.__version__` at run time. |
| `base_url`                     | string                | Worker URL the run targeted. |
| `n_trials`                     | int                   | Trial count (matches `--trials`). |
| `run_uuid`                     | UUID v4 string        | Per-run identifier; embedded in each trial's `error_class` for traceability. |
| `agent_a_id`                   | UUID v4 string        | A's agent_id. |
| `agent_b_id`                   | UUID v4 string        | B's agent_id. |
| `closure_rate`                 | float in [0, 1]       | `success_count / n_trials`. The headline number. |
| `signature_verification_rate`  | float in [0, 1] or null | Sigverify successes / sigverify attempts. `null` when no trial reached the verify phase. |
| `feedback_acceptance_rate`     | float in [0, 1]       | Feedback successes / feedback attempts. |
| `time_to_closure_ms`           | dict                  | Aggregate latency over successful trials only (see below). |
| `trials`                       | list of TrialResult   | Per-trial breakdown. Always full N. |

### `time_to_closure_ms` keys

`mean`, `median`, `p95`, `p99`, `min`, `max` — all floats, all
milliseconds, all computed across **successful trials only**.
A failed trial's timing is meaningless for latency baselining.

### TrialResult fields

| Field                  | Type                                     | Semantics |
|------------------------|------------------------------------------|-----------|
| `trial_index`          | int                                      | 0-based position in the trial sequence. |
| `trial_uuid`           | UUID v4 string                           | Per-trial identifier; embedded in `error_class`. |
| `agent_a_id` / `agent_b_id` | UUID v4 strings                     | Same as top-level (denormalised for per-row analysis). |
| `trace_id`             | string or null                           | Server-assigned `trace_id`; null when publish failed. |
| `signed`               | bool                                     | Did the publish succeed as `signed=true`? |
| `signature_verified`   | bool or null                             | Local sigverify result; null when the trial did not reach verify. |
| `feedback_published`   | bool                                     | Did B's feedback POST succeed? |
| `counter_updated`      | bool                                     | Did A observe `helped++` within the budget? |
| `outcome`              | string (see §7)                          | One-word classification of the trial result. |
| `duration_ms`          | int                                      | Wall-clock total of the trial. |
| `phases_ms`            | dict[str, int]                           | Per-phase wall-clock breakdown (see §1). |
| `error`                | string or null                           | Free-text failure detail. Null on `success`. |

---

## 6. Result interpretation

### closure_rate

Binary at the threshold. **>= 95% is a pass; < 95% is a Sev-1
federation regression.** The first action below threshold is to halt
shipping any change that touches the Worker, the SDK transport, or
the canonical-form module, and investigate the trial-by-trial
breakdown.

### time_to_closure_ms

Tells the latency story. The p95 baseline depends on Worker location,
edge routing, D1 propagation, and the runner IP. Establish a baseline
at v1.0 against the production domain. Until then, treat the numbers
as informational, not as an SLA.

### signature_verification_rate

Must be 100% on signed traces. Anything below 100% is a crypto
integrity failure: either canonical-form drift between Python and
TypeScript, key-rotation race, or a tampered round-trip. Investigate
immediately; below 100% is more serious than a low `closure_rate`.

### feedback_acceptance_rate

Must be 100%. Below 100% is a Worker counter-write bug — feedback
went out but the counter rollup did not register it. Cross-reference
with the Worker's `/health` schema version.

---

## 7. Failure modes

Each `TrialResult.outcome` value, what it means, and where to look:

| outcome              | Meaning                                                                                       | Investigation path |
|----------------------|-----------------------------------------------------------------------------------------------|--------------------|
| `success`            | All six transitions completed.                                                                | (no investigation needed) |
| `publish_failed`     | A's `POST /traces` raised, returned a 4xx, or returned `signed=false`.                        | Worker `/health`; SDK `signing` path; agent's pubkey enrollment state. |
| `search_timeout`     | Trace did not surface in B's search-by-error_class within 5 s.                                | D1 indexing latency; Worker `/search` route; rate-limit on B's bucket. |
| `fetch_failed`       | B's `GET /traces/:id` raised after a successful search hit (race condition, retention).       | Worker `/traces/:id` route; D1 read-after-write consistency. |
| `verify_failed`      | B fetched the trace but the Ed25519 verification failed.                                      | Canonical-form parity (Python vs Worker `verifySignature`); pubkey rotation race; tampered transit. |
| `feedback_failed`    | B's `POST /feedback` raised or returned `recorded=false / counters_updated=false`.            | Worker `/feedback` route; agent B's auth state; funnel-monotonicity violation in client. |
| `counter_timeout`    | A polled for 10 s and never observed `helped++`.                                              | Worker counter rollup path (Durable Object or cron, see spec §2.3); D1 write latency. |
| `exception`          | Any other unhandled exception during the trial. Should not occur in healthy runs.             | Stack trace in `TrialResult.error`. |

---

## 8. Running it yourself

### Via the CLI

```
borg closure-test --trials 20
```

Or, on a system where `borg` collides with another binary:

```
python -m borg_collective.cli closure-test --trials 20
```

Flags:

- `--trials INT` (default 20) — trial count.
- `--output PATH` — write the JSON result to PATH; absent, stream JSON
  to stdout.
- `--base-url URL` — override the Worker URL. Default reads
  `BORG_BASE_URL` env or the SDK's compiled-in default.
- `--verbose` / `-v` — render a Rich progress bar to stderr.

Exit codes:

- `0` — closure_rate >= 95%.
- `1` — closure_rate < 95% (measured below threshold).
- `2` — infrastructure error during setup or run (registration cap,
  network failure). Distinct from a measured low rate so monitoring
  can branch.

### Via pytest

```
BORG_CLOSURE_TEST=1 pytest tests/integration/test_closure.py -v --trials=20
```

Or:

```
pytest -m closure --trials=20
```

The pytest path writes to
`tests/integration/closure_results.json` so the artifact is
discoverable by the daily CI heartbeat.

### Cached agent pair

To avoid re-registering on every run, pin the pair via env vars:

```
export BORG_CLOSURE_AGENT_A_ID=<uuid>
export BORG_CLOSURE_AGENT_A_KEY=<64-char hex>
export BORG_CLOSURE_AGENT_B_ID=<uuid>
export BORG_CLOSURE_AGENT_B_KEY=<64-char hex>
```

The first run after a fresh checkout prints these env-var lines to
stderr — capture them into your shell rc or CI secret store.

---

## 9. CI integration

`.github/workflows/closure.yml` runs the test daily at 06:00 UTC and
on `workflow_dispatch`. It does NOT block PRs — failure is a Sev-1
investigation, not a merge blocker. Each run uploads
`closure_results.json` as an artifact retained for 90 days; trend
analysis pulls from there.

Failure to reach 95% in CI dispatches the on-call investigation flow
documented in the project's incident playbook (out of scope of this
file).

---

## 10. Spec invariant

**Any working Borg federation must pass closure-rate >= 95% over
N >= 20 trials. A regression below this threshold is a Sev-1 incident
requiring rollback.**

This sentence is the contract. It is the v1 ship gate, the daily
heartbeat assertion, and the rollback trigger. Changing the threshold
or the trial count is a v2 spec decision, not a release-prep
decision.

---

*Implementation: `src/borg_collective/_closure.py`. Tested by
`tests/test_closure_unit.py` (unit, FakeClient-driven) and
`tests/integration/test_closure.py` (live federation). First measured
results at v0.1.3 release: `tests/integration/closure_results.json`.*
