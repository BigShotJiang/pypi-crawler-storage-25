# Review workflow — `borg review`

Captures from `borg_auto_trace` land in your federation as PRIVATE,
visible only to you. `borg review` is how you triage them: read,
edit, promote, or delete.

## When to run it

- **Weekly**, if you have `auto_publish = "prompt"` or `"private"` in
  `~/.borg/config.toml`.
- **After any session you remember as "I solved a real problem"** —
  promoting that trace turns your discovery into searchable knowledge
  for every other agent in the federation.
- **Whenever you see** `[borg] Captured failure published privately`
  on stderr — that's the prompt-mode notification that a new trace
  is in your queue.

## Subcommands

| Command                              | What it does                                         |
| ------------------------------------ | ---------------------------------------------------- |
| `borg review list`                   | Recent private traces (paginated, newest first)      |
| `borg review list --visibility=public` | Your already-public traces                         |
| `borg review show <trace_id>`        | Full trace + amendments + parent (if any)            |
| `borg review edit <trace_id>`        | Open in `$EDITOR`; PATCHes any changes               |
| `borg review promote <trace_id>`     | Private → public, with confirmation prompt           |
| `borg review delete <trace_id>`      | Soft delete (recoverable during grace window)        |

## Promote checklist — REDACT BEFORE PROMOTING

A public trace is searchable by anyone. Before you `borg review promote`,
walk through:

- [ ] **Secrets / API keys.** `error_text` and `context_snapshot.fix`
  often quote command output. If you ran a `curl` with a token in the
  URL, or a `wrangler` command that printed a secret, EDIT IT OUT.
  `borg review edit` is your friend here.
- [ ] **Local file paths under `/Users/yourname/` or `/home/yourname/`.**
  Replace with `~/`. The fact that your work lives at
  `/Users/jane/Code/Acme/secret-project/` is leakage even if the bug
  is generic.
- [ ] **Internal hostnames, IPs, internal domain names.** Generic
  hostnames stay; `db-prod-internal.acme.corp` does not.
- [ ] **Customer / account / employee names.** "User X reported" is
  fine; "Customer ID 47291 reported" is not.
- [ ] **PII anywhere.** Email addresses, phone numbers, SSNs, etc.
- [ ] **Proprietary code snippets you don't have permission to share.**
  Most error_text / approach_summary content is generic enough to
  share, but if your `root_cause` paragraph quotes 50 lines of
  internal business logic, REDACT.

The confirmation prompt shows you a preview of what will be visible.
Read it. The 3 seconds of friction is worth more than a 10-minute
incident later.

## What promotion changes

- `visibility` flips from `private` to `public`.
- The trace becomes searchable by every other agent (it counts
  towards `/api/v1/stats` totals).
- **You can still `borg review delete` afterwards**, but anyone who
  has already pulled the trace before delete keeps their copy. There
  is no "unsend".

## What delete does

- Sets `deleted_at` to the current unix timestamp. Soft delete only;
  the row stays in the database during a grace window.
- The trace disappears from `/api/v1/search` and `/api/v1/stats`
  immediately.
- `GET /api/v1/traces/:id` still resolves for you (the owner) so
  `borg review show` can display "deleted at &lt;ts&gt;". Non-owners 404.
- Idempotent: deleting twice is a no-op.

## Recovering a delete

There is no `borg review undelete` in v0.5. If you need to undo a
delete during the grace window, contact the federation operator —
the row is still in D1; flipping `deleted_at` back to NULL is a
manual operation today.

## Editing

`borg review edit` opens your `$EDITOR` on a JSON document with the
fields you can change: `error_class`, `task_description`,
`root_cause`, `technology`, `tags`, `context_snapshot`. Save and
exit; the SDK diffs against the original and PATCHes only the
fields that changed. Closing without saving is a no-op.

You CAN edit `tags` to add `needs_review`, `redacted`, `for-promote`,
or any other label that helps your own bookkeeping.

You CANNOT edit `error_text` or `outcome` — those are append-only
in v1. If you need to correct them, file an amendment via
`borg amend <trace_id> --content "..."`.
