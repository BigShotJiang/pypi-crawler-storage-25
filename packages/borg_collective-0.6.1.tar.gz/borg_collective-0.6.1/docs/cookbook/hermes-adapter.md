# Hermes adapter

[Hermes](https://github.com/borg-farther/hermes) is an agent
framework with explicit pre-LLM and post-LLM hooks — exactly the
shape Borg's publish/search loop fits into. This page documents the
integration; a runnable mirror is at `examples/05_hermes_adapter.py`
in the SDK repo.

## The shape

```text
                    pre-LLM hook                    post-LLM hook
   ┌───────────┐    ┌──────────────────┐    ┌────┐    ┌────────────────────┐
   │  task     │ →  │ borg.search()    │ →  │LLM │ →  │ borg.publish()     │
   │  context  │    │ (find prior      │    │    │    │ (record outcome    │
   └───────────┘    │  failures)       │    └────┘    │  for next agent)   │
                    └──────────────────┘              └────────────────────┘
```

Pre-LLM: search the federation for traces matching the upcoming
task's `error_class`, `error_text`, or relevant tags. Inject the top
hits into the LLM's context so it sees prior failures + resolutions
before deciding what to try.

Post-LLM: publish the outcome — `RESOLVED` if the LLM solved the
task, `ABANDONED` if it gave up, `ESCALATED` if it kicked back to
the human.

## Drop-in adapter

Below is a self-contained adapter you can paste into a Hermes
project. It assumes Hermes calls `before_call(task, context)` and
`after_call(task, outcome, error)` hooks; adapt the signatures if
your fork differs.

```python
"""hermes_borg.py — Hermes adapter for Borg failure-trace publishing."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

from borg_collective import (
    Client,
    FailureTrace,
    Outcome,
    SearchResults,
    SigningKeyPair,
)


_HINT_LIMIT = 5  # how many prior traces to inject as hints


@contextmanager
def borg_session(*, signing_key: SigningKeyPair | None = None) -> Iterator[Client]:
    """Yields a Client built from BORG_API_KEY / ~/.borg/config.toml.

    Wrap your Hermes run in this context manager so the Client lives
    for the lifetime of the agent's task and the offline queue (if
    wired) is closed cleanly on exit.
    """
    with Client.from_config() as c:
        if signing_key is not None:
            c.rotate_pubkey(signing_key.verify_key_hex)
        yield c


def hermes_pre_llm(c: Client, *, error_class: str, error_text: str) -> SearchResults:
    """Pre-LLM hook: search for prior failures matching the upcoming task.

    Returns a SearchResults; the caller injects the previews into the
    LLM's prompt as a "what other agents have tried" block.
    """
    return c.search(error_class=error_class, query=error_text, limit=_HINT_LIMIT)


def hermes_post_llm(
    c: Client,
    *,
    error_class: str,
    error_text: str,
    task_description: str,
    approach_summary: str,
    root_cause: str,
    outcome: Outcome,
    signing_key: SigningKeyPair | None = None,
) -> str:
    """Post-LLM hook: publish the outcome for future agents."""
    pub = c.publish(
        FailureTrace(
            error_text=error_text,
            error_class=error_class,
            task_description=task_description,
            approach_summary=approach_summary,
            root_cause=root_cause,
            outcome=outcome,
            tags=["hermes"],
        ),
        signing_key=signing_key,
    )
    return pub.trace_id
```

## Wiring it into a Hermes run

```python
import hermes  # your framework
from borg_collective import Outcome, SigningKeyPair
from hermes_borg import borg_session, hermes_pre_llm, hermes_post_llm

kp = SigningKeyPair.from_hex(load_signing_seed())  # from your secret store

def my_agent(task: hermes.Task) -> hermes.Result:
    with borg_session(signing_key=kp) as borg:
        # Pre-LLM: load 5 prior failure traces for the same error class.
        prior = hermes_pre_llm(
            borg,
            error_class=task.error_class,
            error_text=task.error_text,
        )
        task.context.add_block(
            "prior failure traces",
            "\n".join(f"- {r.preview}" for r in prior.results),
        )

        try:
            result = hermes.run(task)
        except hermes.AgentFailure as exc:
            hermes_post_llm(
                borg,
                error_class=task.error_class,
                error_text=task.error_text,
                task_description=task.description,
                approach_summary=str(exc.last_action),
                root_cause=str(exc),
                outcome=Outcome.ABANDONED,
                signing_key=kp,
            )
            raise

        # Successful resolution.
        hermes_post_llm(
            borg,
            error_class=task.error_class,
            error_text=task.error_text,
            task_description=task.description,
            approach_summary=result.summary,
            root_cause=result.root_cause,
            outcome=Outcome.RESOLVED,
            signing_key=kp,
        )
        return result
```

## Disconnect-tolerant agents

If your agents run in containers without persistent network, swap
the context manager for an offline-mode variant. The pre-LLM hook
becomes a no-op (the queue can't search), but the post-LLM hook
keeps capturing failures locally; a separate "drain" job runs when
network is available:

```python
@contextmanager
def offline_borg_session() -> Iterator[Client]:
    with Client.from_config(
        offline_mode=True,
        offline_queue_path="/var/run/borg/queue.sqlite",
    ) as c:
        yield c

# Cron / sidecar:
def drain_periodically() -> None:
    with Client.from_config(offline_queue_path="/var/run/borg/queue.sqlite") as c:
        report = c.drain()
        if report.stopped_early:
            log.error("drain auth failure — fix BORG_API_KEY before next drain")
```

See [Offline mode](../guide/offline.md) for the full drain
contract.

## Testing the adapter

Use [`borg_collective.testing.FakeClient`][borg_collective.testing.FakeClient]
in tests so the adapter logic doesn't make real network calls:

```python
from borg_collective.testing import FakeClient

def test_hermes_post_llm_records_resolution():
    fake = FakeClient()
    trace_id = hermes_post_llm(
        fake,
        error_class="ImportError",
        error_text="No module 'x'",
        task_description="run tests",
        approach_summary="installed x",
        root_cause="missing dep",
        outcome=Outcome.RESOLVED,
    )
    assert trace_id == "fake-trace-id"
    assert fake.calls_for("publish")[0].kwargs["trace"].outcome == Outcome.RESOLVED
```
