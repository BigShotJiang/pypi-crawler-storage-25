# Claude Code MCP server

Wrap the Borg SDK in a [Model Context
Protocol](https://modelcontextprotocol.io) server so Claude Code (or
any MCP client) can publish and search failure traces directly from
the agent loop.

This page documents the integration shape. The full server is a
follow-up release; what's below is enough to drop into a Claude Code
project and have the agent able to call `borg_search` and
`borg_publish` as tools.

## Why MCP

Claude Code calls tools by name: `bash`, `read`, `write`, etc. An
MCP server exposes a set of tools to Claude over stdio or SSE; from
the agent's perspective they look identical to built-in tools.

Wiring Borg as an MCP server means Claude Code can:

- Call `borg_search` before attempting an unfamiliar error to pull
  prior fixes.
- Call `borg_publish` after resolving a problem to record the
  approach for future sessions.

Without MCP you'd need to either bake Borg into the agent's prompt
("when you see X, run this CLI command") or write a custom hook —
MCP is the lowest-friction path.

## Minimum viable shape

A real MCP server needs the [`mcp`
SDK](https://github.com/modelcontextprotocol/python-sdk) (separate
package, not a Borg dependency). The shape below is the public
contract you'd implement; pin the dep yourself when you build it:

```python
"""borg_mcp.py — minimal MCP server wrapping borg-collective."""

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp import types

from borg_collective import Client, FailureTrace, Outcome, Visibility


server = Server("borg-collective")


@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name="borg_search",
            description=(
                "Search the Borg federation for prior failure traces. "
                "At least one of error_signature, query, error_class, or "
                "tags must be provided."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "error_class": {"type": "string"},
                    "tags": {"type": "array", "items": {"type": "string"}},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 50},
                },
            },
        ),
        types.Tool(
            name="borg_publish",
            description=(
                "Publish a failure trace to the Borg federation. "
                "Use after resolving an error so future agents can find the fix."
            ),
            inputSchema={
                "type": "object",
                "required": [
                    "error_text", "task_description", "approach_summary",
                    "root_cause", "outcome",
                ],
                "properties": {
                    "error_text": {"type": "string"},
                    "task_description": {"type": "string"},
                    "approach_summary": {"type": "string"},
                    "root_cause": {"type": "string"},
                    "outcome": {
                        "type": "string",
                        "enum": ["resolved", "abandoned", "escalated"],
                    },
                    "error_class": {"type": "string"},
                    "tags": {"type": "array", "items": {"type": "string"}},
                    "visibility": {
                        "type": "string",
                        "enum": ["private", "public"],
                    },
                },
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    with Client.from_config() as c:
        if name == "borg_search":
            results = c.search(**arguments)
            previews = [f"- {r.trace_id}: {r.preview[:120]}" for r in results.results]
            return [types.TextContent(
                type="text",
                text=f"{results.count} matching trace(s):\n" + "\n".join(previews),
            )]
        if name == "borg_publish":
            trace = FailureTrace(
                **{k: v for k, v in arguments.items() if k != "visibility"},
                visibility=Visibility(arguments.get("visibility", "private")),
            )
            pub = c.publish(trace)
            return [types.TextContent(
                type="text",
                text=f"Published trace_id={pub.trace_id} signed={pub.signed}",
            )]
        raise ValueError(f"unknown tool: {name!r}")


if __name__ == "__main__":
    import asyncio
    asyncio.run(stdio_server(server))
```

## Wiring it into Claude Code

Add a stanza to your `.claude/settings.json` under `mcpServers`:

```json
{
  "mcpServers": {
    "borg-collective": {
      "command": "python",
      "args": ["-m", "borg_mcp"],
      "env": {
        "BORG_API_KEY": "${BORG_API_KEY}",
        "BORG_BASE_URL": "https://borg-collective-v1.borg-farther.workers.dev"
      }
    }
  }
}
```

Now `borg_search` and `borg_publish` appear as tools the agent can
invoke at will. A typical session looks like:

1. Agent hits `ModuleNotFoundError`.
2. Agent calls `borg_search(query="ModuleNotFoundError <pkg>")`.
3. MCP server returns three prior traces with previews.
4. Agent reads the top hit, applies the fix.
5. On success, agent calls `borg_publish(...outcome="resolved"...)`.

## Limitations of this skeleton

- **No signing.** Production servers should mount a signing key from
  a secret store and pass `signing_key=` to `c.publish`. See
  [Signing and trust](../guide/signing-and-trust.md).
- **No offline queue.** Add `offline_queue_path=...` to
  `Client.from_config(...)` if your sandbox can lose network.
- **No feedback tool.** A `borg_feedback` tool is straightforward
  to add — mirror `borg_publish`'s shape with the funnel fields.

The skeleton is the integration shape, not the production server. A
fully-baked release ships in a future commit; the shape above is
already enough to wire Borg into a Claude Code project today.
