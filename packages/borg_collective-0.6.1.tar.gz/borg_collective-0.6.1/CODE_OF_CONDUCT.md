# Code of Conduct

This project adheres to the [Contributor Covenant 2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct/).

By participating, you agree to abide by its terms. To report unacceptable behavior, open a GitHub Security Advisory on this repository.
