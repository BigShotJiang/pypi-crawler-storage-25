"""Example 01 — Publish an unsigned failure trace.

The simplest end-to-end shape: build a :class:`FailureTrace`, publish
it, print the ``trace_id`` the Worker assigned. With no ``BORG_API_KEY``
set the example uses :class:`FakeClient` and exits 0; with a key set
it hits the live Worker.

See also: ``02_publish_signed.py`` for hard-trust publishes,
``docs/guide/quickstart.md`` for the wider story.
"""

from __future__ import annotations

from _helpers import get_client, sample_trace


def main() -> int:
    with get_client() as c:
        published = c.publish(sample_trace())
    print(f"trace_id        : {published.trace_id}")
    print(f"signed          : {published.signed}")
    print(f"error_signature : {published.error_signature}")
    print(f"warning         : {published.warning}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
