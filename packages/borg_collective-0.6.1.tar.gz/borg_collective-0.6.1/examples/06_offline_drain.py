"""Example 06 — Offline mode: enqueue while disconnected, drain when online.

Constructs an ``offline_mode=True`` client pointed at a temp queue
file, publishes 3 traces (each enqueued, returns ``trace_id="local:N"``),
then constructs a regular online client on the same queue file and
drains. The Worker sees 3 publish calls in one go.

Demonstrates the disconnect-tolerant publish flow agents will use
when running in containers without persistent network.

See also: ``docs/guide/offline.md``.
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

from _helpers import sample_trace

from borg_collective import Client


def main() -> int:
    api_key = os.environ.get("BORG_API_KEY", "local-only-no-network")

    with tempfile.TemporaryDirectory() as tmpdir:
        queue_path = Path(tmpdir) / "queue.sqlite"
        print(f"queue path      : {queue_path}")

        # 1. Offline client — publish() enqueues, never hits the network.
        with Client(
            api_key=api_key,
            offline_mode=True,
            offline_queue_path=queue_path,
        ) as offline:
            for i in range(3):
                published = offline.publish(sample_trace(error_text=f"offline trace {i}"))
                print(f"enqueued        : {published.trace_id}")
            assert offline.offline_queue is not None
            print(f"queue size      : {offline.offline_queue.size()}")

        # 2. Drain. Without BORG_API_KEY the placeholder key gets a 403
        #    from the Worker, which counts as `deferred` — the queue
        #    keeps the rows so a real key can drain them later. With a
        #    real BORG_API_KEY set, all 3 drain to `drained`.
        if not os.environ.get("BORG_API_KEY"):
            print("(no BORG_API_KEY — skipping the drain step; rows stay in the queue)")
            return 0

        with Client(api_key=api_key, offline_queue_path=queue_path) as online:
            report = online.drain()
            print(f"drained         : {report.drained}")
            print(f"deferred        : {report.deferred}")
            print(f"failed          : {report.failed}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
