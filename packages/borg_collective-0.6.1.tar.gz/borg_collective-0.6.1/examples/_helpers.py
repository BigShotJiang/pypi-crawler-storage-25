"""Tiny shim shared by the examples.

Each example calls :func:`get_client` to get a Client. With no
``BORG_API_KEY`` env var set we hand back a :class:`FakeClient` so
the example runs zero-network on a fresh checkout. With the key set
we hand back a real :class:`Client` pointed at the federation Worker
(or whatever ``BORG_BASE_URL`` overrides to).

The fakes are configured with sensible default responses so the
example's print statements still print something recognisable.
"""

from __future__ import annotations

import os

from borg_collective import Client, FailureTrace, Outcome
from borg_collective._transport import DEFAULT_BASE_URL
from borg_collective.testing import FakeClient


def get_client() -> Client | FakeClient:
    """Return a real Client when ``BORG_API_KEY`` is set, else a FakeClient."""
    if os.environ.get("BORG_API_KEY"):
        return Client(
            api_key=os.environ["BORG_API_KEY"],
            base_url=os.environ.get("BORG_BASE_URL", DEFAULT_BASE_URL),
        )
    return FakeClient()


def sample_trace(error_text: str = "ModuleNotFoundError: 'nonexistent_pkg'") -> FailureTrace:
    """A minimal FailureTrace the examples reuse — recognisable not 'foo'."""
    return FailureTrace(
        error_text=error_text,
        task_description="Run the test suite for project X",
        approach_summary="pip install nonexistent_pkg; package missing on PyPI",
        root_cause="Typo in requirements; the real module is named 'existing_pkg'",
        outcome=Outcome.RESOLVED,
        error_class="ModuleNotFoundError",
        tags=["python", "import-error", "borg-example"],
    )
