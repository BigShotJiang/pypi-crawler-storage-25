"""Example 04 — Send feedback through the §2.3 funnel.

Funnel monotonicity (enforced both client-side and Worker-side):
``read=True`` requires ``retrieved=True``; ``applied=True`` requires
``read=True``; ``outcome`` requires ``applied=True``.

This example walks the full funnel — retrieved → read → applied →
helped — so the trace's counters reflect a complete success.

See also: ``docs/guide/feedback.md`` for ranking implications.
"""

from __future__ import annotations

from _helpers import get_client, sample_trace

from borg_collective import FeedbackOutcome


def main() -> int:
    with get_client() as c:
        # 1. Seed a trace to send feedback against.
        published = c.publish(sample_trace())
        print(f"trace_id        : {published.trace_id}")

        # 2. Walk the full funnel in one feedback call.
        ack = c.feedback(
            published.trace_id,
            retrieved=True,
            read=True,
            applied=True,
            outcome=FeedbackOutcome.HELPED,
            note="exact match for an ImportError I hit yesterday",
        )
    print(f"recorded        : {ack.recorded}")
    print(f"counters_updated: {ack.counters_updated}")
    print(f"note (worker)   : {ack.note or '(none)'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
