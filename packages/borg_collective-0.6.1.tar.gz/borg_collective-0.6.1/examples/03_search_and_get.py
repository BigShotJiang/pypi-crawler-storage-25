"""Example 03 — Search for prior failures, then GET one.

Publishes a trace, searches by tag, and pulls the full
:class:`TraceDetail` (trace + amendments + counters) for the top hit.
The pattern an agent uses at the START of a new task: "has anyone
hit this error before? show me their trace."

See also: ``docs/guide/search.md`` for the §2.2 ranking contract.
"""

from __future__ import annotations

from _helpers import get_client, sample_trace


def main() -> int:
    with get_client() as c:
        # 1. Seed a trace so search has something to find when running
        #    against the live Worker. Against FakeClient the default
        #    SearchResults is empty, which is fine — the script still
        #    exits 0.
        published = c.publish(sample_trace())
        print(f"seeded          : {published.trace_id}")

        # 2. Search by the unique tag the helper trace carries.
        results = c.search(tags=["borg-example"], limit=10)
        print(f"hits            : {results.count} (match_mode={results.match_mode})")
        if results.count == 0:
            print("(no live results — running against FakeClient or fresh corpus)")
            return 0

        # 3. Pull the full detail of the top hit.
        top = results.results[0]
        detail = c.get(top.trace_id)
    print(f"top trace_id    : {detail.trace.trace_id}")
    print(f"top outcome     : {detail.trace.outcome}")
    print(f"retrieved count : {detail.counters.retrieved}")
    print(f"helped count    : {detail.counters.helped}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
