"""Example 05 — Hermes adapter: pre-LLM hook → search; post-LLM hook → publish.

Demonstrates the integration shape an agent framework would use.
``run_with_borg`` is the hot loop: before the LLM is called, search
the federation for prior traces of the same error class; after the
LLM returns (or raises), publish the outcome back.

The "LLM" here is a deterministic stub so the example runs to exit 0
on a fresh checkout — swap ``call_llm`` for your real generator.

See also: ``cookbook/hermes-adapter.md`` for the full integration.
"""

from __future__ import annotations

from typing import Any

from _helpers import get_client

from borg_collective import FailureTrace, Outcome


def call_llm(task: str, hints: list[str]) -> dict[str, Any]:
    """Stub that pretends to be an LLM. Returns a dict shaped like a
    real generator's output."""
    return {"task": task, "hints_used": len(hints), "result": "import existing_pkg"}


def run_with_borg(error_text: str, error_class: str, task: str) -> dict[str, Any]:
    with get_client() as c:
        # PRE-LLM hook: search prior failures for context. We filter by
        # error_class because it's stable across formatting; the raw
        # error_text often contains punctuation (quotes, colons) that
        # isn't a useful match key.
        results = c.search(error_class=error_class, limit=5)
        hints = [r.preview for r in results.results]
        print(f"pre-LLM         : {results.count} prior trace(s) found")

        # Run the LLM (stub here).
        try:
            outcome = call_llm(task, hints)
        except Exception as exc:
            # POST-LLM hook on failure: publish what didn't work.
            c.publish(
                FailureTrace(
                    error_text=error_text,
                    task_description=task,
                    approach_summary="LLM crashed mid-task",
                    root_cause=str(exc),
                    outcome=Outcome.ABANDONED,
                    tags=["hermes", "borg-example"],
                )
            )
            raise

        # POST-LLM hook on success: publish the resolution so the
        # next agent doesn't re-derive it.
        published = c.publish(
            FailureTrace(
                error_text=error_text,
                task_description=task,
                approach_summary=str(outcome["result"]),
                root_cause="caller had a typo in requirements.txt",
                outcome=Outcome.RESOLVED,
                tags=["hermes", "borg-example"],
            )
        )
        print(f"post-LLM publish: {published.trace_id}")
    return outcome


def main() -> int:
    outcome = run_with_borg(
        error_text="ModuleNotFoundError: No module named 'nonexistent_pkg'",
        error_class="ModuleNotFoundError",
        task="resolve the failing import in tests/test_x.py",
    )
    print(f"task result     : {outcome['result']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
