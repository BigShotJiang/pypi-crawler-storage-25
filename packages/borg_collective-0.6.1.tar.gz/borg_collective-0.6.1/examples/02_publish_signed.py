"""Example 02 — Publish a SIGNED failure trace.

Generates a fresh Ed25519 keypair, enrols its verify-key on the
authenticated agent (``rotate_pubkey``), then publishes a trace with
``signing_key=`` so the SDK fills in ``error_signature``,
``signature``, and ``signer_pubkey`` over the canonical body.

The Worker verifies before persisting; on a verifier mismatch you get
:class:`SignatureError` with a canonical-form-drift hint.

See also: ``docs/guide/signing-and-trust.md``.
"""

from __future__ import annotations

from _helpers import get_client, sample_trace

from borg_collective import SigningKeyPair


def main() -> int:
    kp = SigningKeyPair.generate()
    with get_client() as c:
        # rotate_pubkey is idempotent; calling it on every publish is
        # cheap and ensures the Worker can verify the signature we
        # send. In production keep one keypair per agent on disk.
        c.rotate_pubkey(kp.verify_key_hex)
        published = c.publish(sample_trace(), signing_key=kp)
    print(f"trace_id        : {published.trace_id}")
    print(f"signed          : {published.signed}")
    print(f"error_signature : {published.error_signature}")
    print(f"signer_pubkey   : {kp.verify_key_hex}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
