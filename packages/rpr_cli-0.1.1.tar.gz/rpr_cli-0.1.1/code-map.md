# Code Map

Generated: 2026-04-16T22:51:37Z
Root: /home/harlenalvarez/development/project-getting-started
Files analyzed: 124
Languages: python, rust, typescript
Backend: rust

## Architecture Summary

Verdict: **unclear**

**Reasoning:**
- No clear entry areas detected
- No clear core areas detected
- No directory-level cycles detected
- Cycle density within threshold: 0% of files in cycles
- No bidirectional coupling between top-level directories
- No mixed-role hotspots detected

### Leaf Areas
- Sample-dot-github
- rpr-parser
- src/rpr
- tests

### Warnings
- Verdict is unclear: no clear entry directories identified; no clear core directories identified.

## Architecture Diagram

```mermaid
---
config:
  layout: elk
  theme: base
---
flowchart TB
    subgraph rpr_parser_src["rpr-parser/src"]
        subgraph rpr_parser_src_config["config"]
        end
        subgraph rpr_parser_src_models["models"]
            subgraph rpr_parser_src_models_dtos["dtos"]
            end
            subgraph rpr_parser_src_models_entities["entities"]
            end
        end
        subgraph rpr_parser_src_repos["repos"]
        end
    end


    style rpr_parser_src fill:#F2F3F4,stroke:#95A5A6,color:#000
```

## Directory Tree

```
Sample-dot-github/
  scaffolds/
    api/
    frontend/
rpr-parser/
  src/
    config/
    models/
      dtos/
      entities/
    repos/
src/
  rpr/
    agent/
      tools/
    application/
    checks/
    commands/
      generate/
    generators/
    map/
    templates/
    ui/
tests/
```

## Representative Coupling Paths

### Path 1: shortest path from entry rpr-parser/src/lib.rs to leaf rpr-parser/src/graph.rs
Files: `rpr-parser/src/lib.rs` -> `rpr-parser/src/graph.rs`
Directories: `rpr-parser/src`

## External Dependencies

***(root)*** — `re`, `sys`
**`Sample-dot-github/scaffolds/api`** — `asyncio`, `contextlib`, `fastapi`, `my_app_domain`, `starlette`
**`Sample-dot-github/scaffolds/frontend`** — `react`
**`rpr-parser/src`** — `foo`, `ignore`, `log`, `tempfile`, `tokio`, `walker`
**`rpr-parser/src/config`** — `log`
**`rpr-parser/src/models/entities`** — `sea_orm`, `uuid`
**`rpr-parser/src/repos`** — `sea_orm`
**`src/rpr`** — `__future__`, `dataclasses`, `json`, `os`, `pathlib`, `re`, `rich`, `rpr`, `subprocess`, `tomllib`, `typer`, `typing`
**`src/rpr/agent`** — `__future__`, `abc`, `asyncio`, `collections`, `dataclasses`, `datetime`, `enum`, `inspect`, `mimetypes`, `pathlib`, `re`, `rpr`, `threading`, `typer`, `typing`
**`src/rpr/agent/tools`** — `__future__`, `abc`, `dataclasses`, `pathlib`, `rpr`
**`src/rpr/application`** — `__future__`, `argparse`, `asyncio`, `collections`, `contextlib`, `dataclasses`, `datetime`, `pathlib`, `prompt_toolkit`, `rpr`, `shlex`, `typer`, `typing`
**`src/rpr/checks`** — `__future__`, `dataclasses`, `pathlib`, `rpr`, `tomllib`
**`src/rpr/commands`** — `__future__`, `asyncio`, `json`, `pathlib`, `re`, `rich`, `rpr`, `tomllib`, `typer`, `typing`, `yaml`
**`src/rpr/commands/generate`** — `__future__`, `json`, `pathlib`, `re`, `rich`, `rpr`, `typer`, `typing`
**`src/rpr/generators`** — `__future__`, `dataclasses`, `pathlib`, `re`, `rpr`, `yaml`
**`src/rpr/map`** — `__future__`, `ast`, `collections`, `dataclasses`, `datetime`, `pathlib`, `pathspec`, `re`, `rpr`, `rpr_parser`, `typing`, `warnings`
**`src/rpr/templates`** — `__future__`, `dataclasses`
**`src/rpr/ui`** — `__future__`, `asyncio`, `dataclasses`, `json`, `pathlib`, `prompt_toolkit`, `re`, `rich`, `rpr`, `sys`, `typing`
**`tests`** — `__future__`, `asyncio`, `collections`, `dataclasses`, `importlib`, `io`, `json`, `pathlib`, `prompt_toolkit`, `pytest`, `random`, `re`, `rich`, `rpr`, `rpr_parser`

## Module Responsibilities

***(root)*** — Tests
**`Sample-dot-github`** — Entry points
**`Sample-dot-github/scaffolds`** — Project scaffolds
**`Sample-dot-github/scaffolds/api`** — API layer
**`Sample-dot-github/scaffolds/frontend`** — 2 source files
**`rpr-parser`** — Infrastructure layer
**`rpr-parser/src`** — Infrastructure layer
**`rpr-parser/src/config`** — Configuration
**`rpr-parser/src/models`** — Domain models
**`rpr-parser/src/models/dtos`** — Data transfer objects
**`rpr-parser/src/models/entities`** — Domain entities
**`rpr-parser/src/repos`** — Repository implementations
**`src`** — Entry points
**`src/rpr`** — Entry points
**`src/rpr/agent`** — AI agent tools
**`src/rpr/agent/tools`** — 5 source files
**`src/rpr/application`** — Application service layer
**`src/rpr/checks`** — Health-check validators
**`src/rpr/commands`** — CLI command handlers
**`src/rpr/commands/generate`** — 6 source files
**`src/rpr/generators`** — Code generators
**`src/rpr/map`** — Code-map analysis
**`src/rpr/templates`** — Code templates
**`src/rpr/ui`** — User interface
**`tests`** — Tests

## Structural Test Coverage

**Summary:** 0 directories with strong import evidence, 6 with name-based fallback evidence, 14 with no test evidence detected.


### Fallback Coverage (name-based)
- `src/rpr` — inferred from `tests/test_context.py` *(name-based)*
- `src/rpr/application` — inferred from `tests/test_catalog.py`, `tests/test_chat_service.py`, `tests/test_completer.py` *(name-based)*
- `src/rpr/commands` — inferred from `tests/test_add.py`, `tests/test_chat.py`, `tests/test_check.py` *(name-based)*
- `src/rpr/commands/generate` — inferred from `tests/test_ui.py` *(name-based)*
- `src/rpr/map` — inferred from `tests/test_architecture.py` *(name-based)*
- `src/rpr/ui` — inferred from `tests/test_prompt_session.py` *(name-based)*

### No Test Evidence Detected
- *(root)*
- `Sample-dot-github/scaffolds/api`
- `Sample-dot-github/scaffolds/frontend`
- `rpr-parser/src`
- `rpr-parser/src/config`
- `rpr-parser/src/models`
- `rpr-parser/src/models/dtos`
- `rpr-parser/src/models/entities`
- `rpr-parser/src/repos`
- `src/rpr/agent`
- `src/rpr/agent/tools`
- `src/rpr/checks`
- `src/rpr/generators`
- `src/rpr/templates`