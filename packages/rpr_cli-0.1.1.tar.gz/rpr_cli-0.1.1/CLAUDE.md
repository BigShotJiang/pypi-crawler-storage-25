# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Install dependencies
uv sync

# Install CLI globally
uv tool install .

# Run tests
uv run pytest

# Run a single test file
uv run pytest tests/test_init.py

# Run a single test
uv run pytest tests/test_init.py::test_function_name

# Lint and format
uvx ruff check .
uvx ruff format .
```

## Architecture

RPR is a CLI tool (built with Typer) that bootstraps and manages NX + UV monorepos with a Domain-Driven Design (DDD) architecture. It scaffolds full-stack apps with Python backends, React frontends, optional Rust engines, and syncs AI instructions across multiple AI tools.

### Command Structure

- `rpr init` — bootstraps an NX workspace with UV workspace configuration
- `rpr generate [domain|api|ui|engine|storybook]` — creates new packages/apps with boilerplate
- `rpr sync rules` — reads instructions from `src/rpr/scaffolds/instructions/` and generates AI tool config files (`.cursor/rules/*.mdc`, `.github/copilot-instructions.md`, `CLAUDE.md`, `GEMINI.md`)
- `rpr add template` — extracts code blocks from markdown templates, interpolates variables, writes to target paths
- `rpr check` — validates workspace structure, instructions, packages

### Core Abstractions

**`RunContext`** (`src/rpr/context.py`) — wraps all file I/O and shell execution. Every command receives a `RunContext` and uses it for all operations. Supports `--dry-run` which previews changes without writing anything.

**`SyncConfig`** (`src/rpr/generators/base.py`) — parsed from `.rpr.yaml` in the target project. Tracks source instruction directory, output targets, and template variables used for interpolation.

**`Rule`** objects — parsed from markdown instruction files. Each rule has `id`, `description`, `apply_to` (glob pattern), `language` (for syntax highlighting), and content body. Used by all AI instruction generators.

**Template registry** (`src/rpr/templates/registry.py`) — maps template IDs (e.g. `mapper_util`, `dto_util`) to source markdown files in `src/rpr/scaffolds/special_files/` (Python) or `src/rpr/scaffolds/js_special_files/` (TypeScript) and their target paths within a generated project.

### Scaffolding System

Templates live in two places:

- `src/rpr/scaffolds/instructions/` — AI instruction markdown files bundled into the package
- `src/rpr/scaffolds/special_files/` and `src/rpr/scaffolds/js_special_files/` — code templates (Python/TypeScript) referenced by `rpr add template`

Generate commands (ui, engine, storybook) build file trees by writing individual files via `RunContext`, not by copying directory trees. Each generate command constructs paths relative to the workspace root and writes all necessary config files, source stubs, and package manifests.

### AI Instruction Generators

Each generator in `src/rpr/generators/` takes a list of `Rule` objects and produces output in a tool-specific format:

- `cursor.py` → `.cursor/rules/*.mdc` files (one per rule)
- `copilot.py` → `.github/copilot-instructions.md` (single concatenated file)
- `claude.py` → `CLAUDE.md`
- `gemini.py` → `GEMINI.md`

### Check System

`src/rpr/checks/` contains health check validators that inspect a workspace and return structured `CheckResult` objects. `rpr check` aggregates these and reports issues with Rich formatting.
