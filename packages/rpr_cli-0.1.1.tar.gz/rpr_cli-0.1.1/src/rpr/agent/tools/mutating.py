from __future__ import annotations

from rpr.agent.client import ToolArguments
from rpr.agent.control import TurnControl
from rpr.agent.tools.base import AgentTool, ToolResult, ToolSpec, resolve_project_path
from rpr.context import RunContext


class WriteFileTool(AgentTool):
    @property
    def spec(self) -> ToolSpec:
        return ToolSpec(
            name="write_file",
            description="Create or update a file in the repository.",
            is_mutating=True,
        )

    def execute(
        self,
        arguments: ToolArguments,
        ctx: RunContext,
        *,
        control: TurnControl | None = None,
    ) -> ToolResult:
        if control is not None and control.is_cancelled:
            return ToolResult(
                tool_name=self.spec.name,
                success=False,
                output="Tool execution cancelled.",
                cancelled=True,
            )
        path = resolve_project_path(ctx.project_dir, arguments.get("path"))
        content = arguments.get("content")
        if not isinstance(content, str):
            raise ValueError("Tool argument 'content' must be a string.")

        if path.exists():
            ctx.update_file(path, content)
        else:
            ctx.write_file(path, content)

        relative_path = path.relative_to(ctx.project_dir)
        return ToolResult(
            tool_name=self.spec.name,
            success=True,
            output=f"Wrote {relative_path}",
        )
