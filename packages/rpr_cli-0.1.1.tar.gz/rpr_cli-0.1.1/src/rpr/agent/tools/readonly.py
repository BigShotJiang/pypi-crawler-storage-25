from __future__ import annotations

from rpr.agent.client import ToolArguments
from rpr.agent.control import TurnControl
from rpr.agent.tools.base import AgentTool, ToolResult, ToolSpec, resolve_project_path
from rpr.context import RunContext
from rpr.map.walker import _IGNORED_DIRS


class ReadFileTool(AgentTool):
    @property
    def spec(self) -> ToolSpec:
        return ToolSpec(
            name="read_file", description="Read a file from the repository."
        )

    def execute(
        self,
        arguments: ToolArguments,
        ctx: RunContext,
        *,
        control: TurnControl | None = None,
    ) -> ToolResult:
        if control is not None and control.is_cancelled:
            return ToolResult(
                tool_name=self.spec.name,
                success=False,
                output="Tool execution cancelled.",
                cancelled=True,
            )
        path = resolve_project_path(ctx.project_dir, arguments.get("path"))
        start_line = int(arguments.get("start_line", 1))
        end_line = arguments.get("end_line")
        content = path.read_text()
        lines = content.splitlines()
        if end_line is None:
            end_line = len(lines)
        end_line = int(end_line)
        selected = lines[max(start_line - 1, 0) : max(end_line, 0)]
        output = "\n".join(
            f"{index}: {line}" for index, line in enumerate(selected, start=start_line)
        )
        return ToolResult(
            tool_name=self.spec.name,
            success=True,
            output=output or "(file is empty)",
        )


class ListDirectoryTool(AgentTool):
    @property
    def spec(self) -> ToolSpec:
        return ToolSpec(
            name="list_directory", description="List files under a directory."
        )

    def execute(
        self,
        arguments: ToolArguments,
        ctx: RunContext,
        *,
        control: TurnControl | None = None,
    ) -> ToolResult:
        if control is not None and control.is_cancelled:
            return ToolResult(
                tool_name=self.spec.name,
                success=False,
                output="Tool execution cancelled.",
                cancelled=True,
            )
        path = resolve_project_path(ctx.project_dir, arguments.get("path", "."))
        entries = sorted(
            path.iterdir(), key=lambda entry: (not entry.is_dir(), entry.name.lower())
        )
        output = "\n".join(
            f"{entry.name}/" if entry.is_dir() else entry.name for entry in entries
        )
        return ToolResult(
            tool_name=self.spec.name,
            success=True,
            output=output or "(directory is empty)",
        )


class SearchTextTool(AgentTool):
    @property
    def spec(self) -> ToolSpec:
        return ToolSpec(
            name="search_text", description="Search repository text for a query."
        )

    def execute(
        self,
        arguments: ToolArguments,
        ctx: RunContext,
        *,
        control: TurnControl | None = None,
    ) -> ToolResult:
        query = arguments.get("query")
        if not isinstance(query, str) or not query.strip():
            raise ValueError("Tool argument 'query' must be a non-empty string.")

        max_results = int(arguments.get("max_results", 20))
        normalized_query = query.casefold()
        matches: list[str] = []
        for current_root, dir_names, file_names in ctx.project_dir.walk():
            if control is not None and control.is_cancelled:
                return ToolResult(
                    tool_name=self.spec.name,
                    success=False,
                    output="Tool execution cancelled.",
                    cancelled=True,
                )
            dir_names[:] = [name for name in dir_names if name not in _IGNORED_DIRS]
            for file_name in sorted(file_names):
                if control is not None and control.is_cancelled:
                    return ToolResult(
                        tool_name=self.spec.name,
                        success=False,
                        output="Tool execution cancelled.",
                        cancelled=True,
                    )
                path = current_root / file_name
                try:
                    content = path.read_text()
                except OSError, UnicodeDecodeError:
                    continue

                for line_number, line in enumerate(content.splitlines(), start=1):
                    if control is not None and control.is_cancelled:
                        return ToolResult(
                            tool_name=self.spec.name,
                            success=False,
                            output="Tool execution cancelled.",
                            cancelled=True,
                        )
                    if normalized_query in line.casefold():
                        relative_path = path.relative_to(ctx.project_dir)
                        matches.append(f"{relative_path}:{line_number}: {line.strip()}")
                        if len(matches) >= max_results:
                            output = "\n".join(matches)
                            return ToolResult(
                                tool_name=self.spec.name, success=True, output=output
                            )

        output = "\n".join(matches) if matches else f"No matches found for: {query}"
        return ToolResult(tool_name=self.spec.name, success=True, output=output)
