from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path

from rpr.agent.client import ToolArguments
from rpr.agent.control import TurnControl
from rpr.context import RunContext


@dataclass(slots=True, frozen=True)
class ToolSpec:
    name: str
    description: str
    is_mutating: bool = False


@dataclass(slots=True, frozen=True)
class ToolResult:
    tool_name: str
    success: bool
    output: str
    cancelled: bool = False

    def as_message_content(self) -> str:
        if self.cancelled:
            status = "cancelled"
        else:
            status = "succeeded" if self.success else "failed"
        return f"Tool {self.tool_name} {status}.\n\n{self.output}".strip()


class AgentTool(ABC):
    @property
    @abstractmethod
    def spec(self) -> ToolSpec: ...

    @abstractmethod
    def execute(
        self,
        arguments: ToolArguments,
        ctx: RunContext,
        *,
        control: TurnControl | None = None,
    ) -> ToolResult: ...


def resolve_project_path(project_dir: Path, raw_path: object) -> Path:
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError("Tool argument 'path' must be a non-empty string.")

    candidate = Path(raw_path)
    resolved = (
        candidate.resolve()
        if candidate.is_absolute()
        else (project_dir / candidate).resolve()
    )
    project_root = project_dir.resolve()
    if not resolved.is_relative_to(project_root):
        raise ValueError(f"Path must stay within the project root: {project_root}")
    return resolved
