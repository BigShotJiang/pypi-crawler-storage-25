from __future__ import annotations

from dataclasses import dataclass, field

from rpr.agent.tools.base import AgentTool
from rpr.agent.tools.mutating import WriteFileTool
from rpr.agent.tools.readonly import ListDirectoryTool, ReadFileTool, SearchTextTool


@dataclass(slots=True)
class ToolRegistry:
    tools: dict[str, AgentTool] = field(default_factory=dict)

    def register(self, tool: AgentTool) -> None:
        self.tools[tool.spec.name] = tool

    def get(self, name: str) -> AgentTool | None:
        return self.tools.get(name)


def build_default_tool_registry() -> ToolRegistry:
    registry = ToolRegistry()
    for tool in (
        ReadFileTool(),
        ListDirectoryTool(),
        SearchTextTool(),
        WriteFileTool(),
    ):
        registry.register(tool)
    return registry
