from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from uuid import uuid4

from rpr.agent.approval import ApprovalMode
from rpr.agent.client import ConversationMessage, MessageContent, ToolArguments


class ToolCallStatus(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    CANCELLED = "cancelled"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass(slots=True)
class ToolCallRecord:
    call_id: str
    tool_name: str
    arguments: ToolArguments
    is_mutating: bool
    status: ToolCallStatus = ToolCallStatus.PENDING
    output: str | None = None
    error: str | None = None


@dataclass(slots=True)
class ChatSession:
    project_dir: Path
    approval_mode: ApprovalMode = ApprovalMode.ASK
    session_id: str = field(default_factory=lambda: uuid4().hex)
    title: str = "New chat"
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    messages: list[ConversationMessage] = field(default_factory=list)
    tool_calls: list[ToolCallRecord] = field(default_factory=list)

    def add_user_message(self, content: MessageContent) -> None:
        stripped = self._message_title_text(content).strip()
        if stripped and self.title == "New chat":
            self.title = stripped.splitlines()[0][:60]
        self.touch()
        self.messages.append(ConversationMessage(role="user", content=content))

    def add_assistant_message(self, content: str) -> None:
        if content:
            self.touch()
            self.messages.append(ConversationMessage(role="assistant", content=content))

    def add_tool_message(self, tool_name: str, content: str) -> None:
        self.touch()
        self.messages.append(
            ConversationMessage(role="tool", content=content, name=tool_name)
        )

    def create_tool_call(
        self,
        *,
        call_id: str,
        tool_name: str,
        arguments: ToolArguments,
        is_mutating: bool,
    ) -> ToolCallRecord:
        record = ToolCallRecord(
            call_id=call_id,
            tool_name=tool_name,
            arguments=arguments,
            is_mutating=is_mutating,
        )
        self.tool_calls.append(record)
        self.touch()
        return record

    def enable_auto_all(self) -> None:
        self.approval_mode = ApprovalMode.AUTO_ALL
        self.touch()

    def touch(self) -> None:
        self.updated_at = datetime.now(UTC)

    @staticmethod
    def _message_title_text(content: MessageContent) -> str:
        if isinstance(content, str):
            return content
        return "".join(part.text for part in content if hasattr(part, "text"))
