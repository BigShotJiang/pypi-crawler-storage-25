from __future__ import annotations

from dataclasses import dataclass, field
from threading import Event


@dataclass(slots=True)
class TurnControl:
    _cancel_requested: Event = field(default_factory=Event)

    def cancel(self) -> None:
        self._cancel_requested.set()

    @property
    def is_cancelled(self) -> bool:
        return self._cancel_requested.is_set()
