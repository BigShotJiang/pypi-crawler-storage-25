from __future__ import annotations

from enum import StrEnum


class ApprovalMode(StrEnum):
    ASK = "ask"
    AUTO_READONLY = "auto-readonly"
    AUTO_ALL = "auto-all"


class ApprovalDecision(StrEnum):
    APPROVE = "approve"
    REJECT = "reject"
    ALWAYS_ALLOW = "always-allow"


def requires_approval(*, is_mutating: bool, mode: ApprovalMode) -> bool:
    return is_mutating and mode is not ApprovalMode.AUTO_ALL
