from __future__ import annotations

import asyncio
import re
from collections.abc import AsyncGenerator, Iterator
from typing import override

from rpr.agent.client import (
    AgentClient,
    ConversationMessage,
    FilePart,
    TextDeltaEvent,
    ToolArguments,
    ToolCallRequestEvent,
    TurnCompleteEvent,
)
from rpr.agent.control import TurnControl


class MockAgentClient(AgentClient):
    """A mock agent client for testing and default behavior."""

    def __init__(self, *, model_name: str = "mock-1") -> None:
        self._model_name = model_name

    @property
    @override
    def provider_name(self) -> str:
        return "mock"

    @property
    @override
    def model_name(self) -> str:
        return self._model_name

    @override
    async def stream(
        self,
        history: list[ConversationMessage],
        *,
        system_prompt: str | None = None,
        control: TurnControl | None = None,
    ) -> AsyncGenerator[
        TextDeltaEvent | ToolCallRequestEvent | TurnCompleteEvent, None
    ]:
        del system_prompt
        last_message = history[-1]
        if last_message.role == "tool":
            async for event in self._stream_text(
                f"I used `{last_message.name}` and summarized the result below.\n\n{last_message.text_content}",
                control=control,
            ):
                yield event
            if control is None or not control.is_cancelled:
                yield TurnCompleteEvent()
            return

        if last_message.role != "user":
            async for event in self._stream_text(
                "I am ready for the next prompt.", control=control
            ):
                yield event
            if control is None or not control.is_cancelled:
                yield TurnCompleteEvent()
            return

        tool_request = self._parse_tool_request(last_message.text_content)
        if tool_request is not None:
            async for event in self._stream_text(
                "I’m going to inspect the repository before answering.\n\n",
                control=control,
            ):
                yield event
            if control is None or not control.is_cancelled:
                yield ToolCallRequestEvent(
                    call_id=f"mock-{len(history)}",
                    tool_name=tool_request[0],
                    arguments=tool_request[1],
                )
            return

        response_text = self._render_response_text(last_message)
        async for event in self._stream_text(response_text, control=control):
            yield event
        if control is None or not control.is_cancelled:
            yield TurnCompleteEvent()

    async def _stream_text(
        self,
        text: str,
        *,
        control: TurnControl | None = None,
    ) -> AsyncGenerator[TextDeltaEvent, None]:
        for chunk in self._iter_chunks(text):
            if control is not None and control.is_cancelled:
                return
            await asyncio.sleep(0.1)
            yield TextDeltaEvent(text=chunk)

    @staticmethod
    def _iter_chunks(text: str) -> Iterator[str]:
        for match in re.finditer(r"\n+|[^\s\n]+\s*", text):
            yield match.group(0)

    def _parse_tool_request(self, message: str) -> tuple[str, ToolArguments] | None:
        read_match = re.search(
            r"(?:read|show) file (?P<path>\S+)", message, re.IGNORECASE
        )
        if read_match:
            return "read_file", {"path": read_match.group("path")}

        list_match = re.search(
            r"(?:list|show) (?:directory|files)(?: (?P<path>\S+))?",
            message,
            re.IGNORECASE,
        )
        if list_match:
            return "list_directory", {"path": list_match.group("path") or "."}

        search_match = re.search(
            r"search(?: for)? (?P<query>.+)", message, re.IGNORECASE
        )
        if search_match:
            return "search_text", {"query": search_match.group("query").strip()}

        write_match = re.search(
            r"write file (?P<path>\S+)\s*:(?P<content>.+)",
            message,
            re.IGNORECASE | re.DOTALL,
        )
        if write_match:
            return "write_file", {
                "path": write_match.group("path"),
                "content": write_match.group("content").lstrip(),
            }

        return None

    def _render_response_text(self, message: ConversationMessage) -> str:
        response_text = (
            f"I received your message: '{message.text_content}'.\n\n"
            f"This is a mock response from the **Mock Provider** using `{self.model_name}`."
        )
        if not message.file_parts:
            return response_text

        attachment_lines = [
            self._format_attachment(part) for part in message.file_parts
        ]
        return f"{response_text}\n\nAttachments:\n" + "\n".join(attachment_lines)

    @staticmethod
    def _format_attachment(part: FilePart) -> str:
        if part.is_text:
            preview = (part.decoded_text() or "").splitlines()
            if preview:
                return f"- {part.path} ({part.mime_type}, {len(part.data)} bytes): {preview[0][:80]}"
        return f"- {part.path} ({part.mime_type}, {len(part.data)} bytes)"
