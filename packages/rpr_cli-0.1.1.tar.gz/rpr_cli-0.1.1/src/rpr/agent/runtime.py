from __future__ import annotations

import asyncio
import inspect
import mimetypes
import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from pathlib import Path

from rpr.agent.approval import ApprovalDecision, requires_approval
from rpr.agent.client import (
    AgentClient,
    ConversationMessage,
    FilePart,
    MessageContent,
    TextDeltaEvent,
    TextPart,
    ToolCallRequestEvent,
    TurnCompleteEvent,
)
from rpr.agent.control import TurnControl
from rpr.agent.session import ChatSession, ToolCallRecord, ToolCallStatus
from rpr.agent.tools import ToolRegistry
from rpr.agent.tools.base import ToolResult, resolve_project_path
from rpr.context import RunContext


MAX_ATTACHMENT_BYTES = 64_000
FILE_REFERENCE_PATTERN = re.compile(r"(?<!\S)@(?P<path>[A-Za-z0-9_./-]+/?)(?=\s|$)")


@dataclass(slots=True)
class RuntimeCallbacks:
    on_text_delta: Callable[[str], None]
    on_tool_call: Callable[[ToolCallRecord], None]
    on_tool_result: Callable[[ToolCallRecord, ToolResult], None]
    request_approval: Callable[
        [ToolCallRecord], ApprovalDecision | Awaitable[ApprovalDecision]
    ]
    on_attachment_notice: Callable[[str], None] = lambda _message: None


class AgentRuntime:
    def __init__(
        self,
        *,
        client: AgentClient,
        session: ChatSession,
        tools: ToolRegistry,
        ctx: RunContext,
        callbacks: RuntimeCallbacks,
        system_prompt: str | None = None,
    ) -> None:
        self._client = client
        self._session = session
        self._tools = tools
        self._ctx = ctx
        self._callbacks = callbacks
        self._system_prompt = system_prompt

    async def execute_turn(
        self, user_input: str, *, control: TurnControl | None = None
    ) -> None:
        turn_user_message = self._create_turn_user_message(user_input)
        self._session.add_user_message(user_input)
        history = [*self._session.messages[:-1], turn_user_message]

        while True:
            if self._is_cancelled(control):
                return

            assistant_content = ""
            requested_tool = False
            stream = self._client.stream(
                history,
                system_prompt=self._system_prompt,
                control=control,
            )
            async for event in stream:
                if self._is_cancelled(control):
                    break

                if isinstance(event, TextDeltaEvent):
                    assistant_content += event.text
                    self._callbacks.on_text_delta(event.text)
                    continue

                if isinstance(event, ToolCallRequestEvent):
                    if assistant_content:
                        self._session.add_assistant_message(assistant_content)
                        history.append(self._session.messages[-1])
                        assistant_content = ""

                    requested_tool = True
                    message_count = len(self._session.messages)
                    await self._handle_tool_call(event, control=control)
                    history.extend(self._session.messages[message_count:])
                    break

                if isinstance(event, TurnCompleteEvent):
                    break

            if assistant_content:
                self._session.add_assistant_message(assistant_content)
                history.append(self._session.messages[-1])

            if self._is_cancelled(control) or not requested_tool:
                return

    async def _handle_tool_call(
        self, event: ToolCallRequestEvent, *, control: TurnControl | None = None
    ) -> None:
        if self._is_cancelled(control):
            return

        tool = self._tools.get(event.tool_name)
        is_mutating = False if tool is None else tool.spec.is_mutating
        record = self._session.create_tool_call(
            call_id=event.call_id,
            tool_name=event.tool_name,
            arguments=event.arguments,
            is_mutating=is_mutating,
        )
        self._callbacks.on_tool_call(record)

        if tool is None:
            result = ToolResult(
                tool_name=event.tool_name,
                success=False,
                output=f"Unknown tool: {event.tool_name}",
            )
            record.status = ToolCallStatus.FAILED
            record.error = result.output
            self._session.add_tool_message(event.tool_name, result.as_message_content())
            self._callbacks.on_tool_result(record, result)
            return

        if requires_approval(
            is_mutating=tool.spec.is_mutating, mode=self._session.approval_mode
        ):
            if self._is_cancelled(control):
                return

            decision = self._callbacks.request_approval(record)
            if inspect.isawaitable(decision):
                decision = await decision
            if self._is_cancelled(control):
                result = ToolResult(
                    tool_name=tool.spec.name,
                    success=False,
                    output="Tool execution cancelled.",
                    cancelled=True,
                )
                record.status = ToolCallStatus.CANCELLED
                record.error = result.output
                self._session.add_tool_message(
                    tool.spec.name, result.as_message_content()
                )
                self._callbacks.on_tool_result(record, result)
                return
            if decision is ApprovalDecision.ALWAYS_ALLOW:
                self._session.enable_auto_all()
            if decision is ApprovalDecision.REJECT:
                result = ToolResult(
                    tool_name=tool.spec.name,
                    success=False,
                    output="Tool execution was rejected by the user.",
                )
                record.status = ToolCallStatus.REJECTED
                record.error = result.output
                self._session.add_tool_message(
                    tool.spec.name, result.as_message_content()
                )
                self._callbacks.on_tool_result(record, result)
                return

            record.status = ToolCallStatus.APPROVED

        if self._is_cancelled(control):
            result = ToolResult(
                tool_name=tool.spec.name,
                success=False,
                output="Tool execution cancelled.",
                cancelled=True,
            )
            record.status = ToolCallStatus.CANCELLED
            record.error = result.output
            self._session.add_tool_message(tool.spec.name, result.as_message_content())
            self._callbacks.on_tool_result(record, result)
            return

        try:
            result = await asyncio.to_thread(
                tool.execute, event.arguments, self._ctx, control=control
            )
        except Exception as exc:
            result = ToolResult(
                tool_name=event.tool_name, success=False, output=str(exc)
            )

        if result.cancelled:
            record.status = ToolCallStatus.CANCELLED
        else:
            record.status = (
                ToolCallStatus.COMPLETED if result.success else ToolCallStatus.FAILED
            )
        if result.success:
            record.output = result.output
        else:
            record.error = result.output
        self._session.add_tool_message(event.tool_name, result.as_message_content())
        self._callbacks.on_tool_result(record, result)

    @staticmethod
    def _is_cancelled(control: TurnControl | None) -> bool:
        return False if control is None else control.is_cancelled

    def _create_turn_user_message(self, user_input: str) -> ConversationMessage:
        content = self._build_user_message(user_input)
        return ConversationMessage(role="user", content=content)

    def _build_user_message(self, user_input: str) -> MessageContent:
        attachments: list[FilePart] = []
        seen_paths: set[str] = set()

        for raw_path in self._extract_paths(user_input):
            try:
                resolved = resolve_project_path(self._ctx.project_dir, raw_path)
            except ValueError:
                self._callbacks.on_attachment_notice(
                    f"Ignored @{raw_path}: path must stay within the project root."
                )
                continue

            if resolved.is_dir():
                self._callbacks.on_attachment_notice(
                    f"Ignored @{raw_path}: directories cannot be attached."
                )
                continue

            if not resolved.is_file():
                self._callbacks.on_attachment_notice(
                    f"Ignored @{raw_path}: file not found."
                )
                continue

            relative_path = resolved.relative_to(self._ctx.project_dir).as_posix()
            if relative_path in seen_paths:
                continue
            seen_paths.add(relative_path)

            attachment = self._build_file_part(resolved, relative_path)
            if attachment is None:
                continue
            attachments.append(attachment)

        if not attachments:
            return user_input

        return (TextPart(user_input), *attachments)

    def _build_file_part(self, resolved: Path, relative_path: str) -> FilePart | None:
        try:
            data = resolved.read_bytes()
        except OSError as exc:
            self._callbacks.on_attachment_notice(f"Ignored @{relative_path}: {exc}.")
            return None

        truncated = False
        if len(data) > MAX_ATTACHMENT_BYTES:
            data = data[:MAX_ATTACHMENT_BYTES]
            truncated = True

        mime_type = (
            mimetypes.guess_type(resolved.as_posix(), strict=False)[0]
            or "application/octet-stream"
        )
        suffix = (
            f" ({len(data)} bytes attached, truncated)"
            if truncated
            else f" ({len(data)} bytes attached)"
        )
        self._callbacks.on_attachment_notice(f"Attached @{relative_path}{suffix}.")
        return FilePart(path=relative_path, mime_type=mime_type, data=data)

    @staticmethod
    def _extract_paths(user_input: str) -> tuple[str, ...]:
        return tuple(
            match.group("path") for match in FILE_REFERENCE_PATTERN.finditer(user_input)
        )
