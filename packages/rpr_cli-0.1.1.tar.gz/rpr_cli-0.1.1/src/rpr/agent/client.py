from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator
from dataclasses import dataclass
from typing import Literal

from rpr.agent.control import TurnControl

type MessageRole = Literal["system", "user", "assistant", "tool"]
type ToolArguments = dict[str, object]


@dataclass(slots=True, frozen=True)
class TextPart:
    text: str


@dataclass(slots=True, frozen=True)
class FilePart:
    path: str
    mime_type: str
    data: bytes

    @property
    def is_text(self) -> bool:
        return self.mime_type.startswith("text/") or self.mime_type in {
            "application/json",
            "application/xml",
            "application/yaml",
            "application/x-yaml",
            "application/javascript",
        }

    def decoded_text(self) -> str | None:
        if not self.is_text:
            return None
        return self.data.decode("utf-8", errors="replace")


type MessagePart = TextPart | FilePart
type MessageParts = tuple[MessagePart, ...]
type MessageContent = str | MessageParts


@dataclass(slots=True, frozen=True)
class ConversationMessage:
    role: MessageRole
    content: MessageContent
    name: str | None = None

    @property
    def parts(self) -> MessageParts:
        if isinstance(self.content, str):
            return (TextPart(self.content),)
        return self.content

    @property
    def text_content(self) -> str:
        if isinstance(self.content, str):
            return self.content
        return "".join(part.text for part in self.content if isinstance(part, TextPart))

    @property
    def file_parts(self) -> tuple[FilePart, ...]:
        if isinstance(self.content, str):
            return ()
        return tuple(part for part in self.content if isinstance(part, FilePart))


@dataclass(slots=True, frozen=True)
class TextDeltaEvent:
    text: str


@dataclass(slots=True, frozen=True)
class ToolCallRequestEvent:
    call_id: str
    tool_name: str
    arguments: ToolArguments


@dataclass(slots=True, frozen=True)
class TurnCompleteEvent:
    pass


type AgentEvent = TextDeltaEvent | ToolCallRequestEvent | TurnCompleteEvent


class AgentClient(ABC):
    """Abstract base class for AI agent clients."""

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Return the name of the provider."""
        ...

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Return the active model name."""
        ...

    @abstractmethod
    async def stream(
        self,
        history: list[ConversationMessage],
        *,
        system_prompt: str | None = None,
        control: TurnControl | None = None,
    ) -> AsyncGenerator[AgentEvent, None]:
        """Stream provider-agnostic events for the current turn."""
        ...
