from __future__ import annotations

from dataclasses import dataclass

import typer

from rpr.agent.approval import ApprovalMode
from rpr.agent.client import AgentClient
from rpr.agent.mock import MockAgentClient
from rpr.agent.runtime import AgentRuntime, RuntimeCallbacks
from rpr.agent.session import ChatSession
from rpr.agent.tools import build_default_tool_registry
from rpr.context import RunContext


@dataclass(slots=True, frozen=True)
class ChatRuntimeBundle:
    ctx: RunContext
    client: AgentClient
    session: ChatSession
    runtime: AgentRuntime


def resolve_agent_client(provider: str | None, model: str | None) -> AgentClient:
    provider_name = (provider or "mock").lower()
    if provider_name != "mock":
        raise typer.BadParameter(
            "Only the mock provider is available right now.", param_hint="provider"
        )

    return MockAgentClient(model_name=model or "mock-1")


def build_chat_runtime_bundle(
    *,
    ctx: RunContext,
    client: AgentClient,
    approval_mode: ApprovalMode,
    callbacks: RuntimeCallbacks,
    session: ChatSession | None = None,
) -> ChatRuntimeBundle:
    active_session = session or ChatSession(
        project_dir=ctx.project_dir, approval_mode=approval_mode
    )
    active_session.project_dir = ctx.project_dir
    active_session.approval_mode = approval_mode
    runtime = AgentRuntime(
        client=client,
        session=active_session,
        tools=build_default_tool_registry(),
        ctx=ctx,
        callbacks=callbacks,
        system_prompt=f"Project root: {ctx.project_dir}",
    )
    return ChatRuntimeBundle(
        ctx=ctx,
        client=client,
        session=active_session,
        runtime=runtime,
    )
