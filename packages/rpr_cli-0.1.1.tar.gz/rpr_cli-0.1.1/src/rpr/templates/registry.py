from __future__ import annotations

from dataclasses import dataclass


@dataclass
class TemplateEntry:
    id: str
    description: str
    source_filename: str
    source_subdir: str
    target_path: str
    language: str


TEMPLATES: dict[str, TemplateEntry] = {
    "mapper_util": TemplateEntry(
        id="mapper_util",
        description="Mapper decorator for repo methods with DTO conversion",
        source_filename="mapper_util.md",
        source_subdir="special_files",
        target_path="packages/python/domain/src/{name_underscore}_domain/utils/mapper_util.py",
        language="python",
    ),
    "dto_util": TemplateEntry(
        id="dto_util",
        description="DtoHelper for single/list entity-to-DTO conversion",
        source_filename="dto_util.md",
        source_subdir="special_files",
        target_path="packages/python/domain/src/{name_underscore}_domain/utils/dto_util.py",
        language="python",
    ),
    "partial_update": TemplateEntry(
        id="partial_update",
        description="apply_partial_update utility for PATCH endpoints",
        source_filename="partial_update.md",
        source_subdir="special_files",
        target_path="packages/python/domain/src/{name_underscore}_domain/utils/partial_update.py",
        language="python",
    ),
    "encrypted_column": TemplateEntry(
        id="encrypted_column",
        description="SQLAlchemy EncryptedColumn TypeDecorator using Fernet",
        source_filename="encrypted_column.md",
        source_subdir="special_files",
        target_path="packages/python/domain/src/{name_underscore}_domain/utils/encrypted_column.py",
        language="python",
    ),
    "domain_settings": TemplateEntry(
        id="domain_settings",
        description="Pydantic BaseSettings with .env loading and DB/HTTP fields",
        source_filename="domain_settings.md",
        source_subdir="special_files",
        target_path="packages/python/domain/src/{name_underscore}_domain/config/settings.py",
        language="python",
    ),
    "domain_container": TemplateEntry(
        id="domain_container",
        description="Dependency Injector Container with db_engine and http_client providers",
        source_filename="domain_container.md",
        source_subdir="special_files",
        target_path="packages/python/domain/src/{name_underscore}_domain/config/container.py",
        language="python",
    ),
    "sticky_navigation": TemplateEntry(
        id="sticky_navigation",
        description="useStateNavigation React hook for URL-based state",
        source_filename="sticky-navigation.md",
        source_subdir="js_special_files",
        target_path="packages/node/{name}-ui/src/hooks/useStateNavigation.ts",
        language="typescript",
    ),
    "fetch_service": TemplateEntry(
        id="fetch_service",
        description="Centralized API service with auth, error handling, fetch",
        source_filename="fetch.service.md",
        source_subdir="js_special_files",
        target_path="packages/node/{name}-ui/src/services/base/api.service.ts",
        language="typescript",
    ),
}
