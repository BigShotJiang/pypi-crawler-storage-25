from __future__ import annotations

import json
from pathlib import Path

from rich.markup import escape
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from rpr.ui.console import console
from rpr.ui.markdown import render_markdown as render_markdown_content

R_LEFT = ["█████ ", "█   ██", "█   ██", "█████ ", "█  █  ", "█   █ ", "█    █"]

P_MID = ["█████ ", "█   ██", "█   ██", "█████ ", "█     ", "█     ", "█     "]

# This is a perfect mathematical mirror of R_LEFT
R_RIGHT = [" █████", "██   █", "██   █", " █████", "  █  █", " █   █", "█    █"]

DEEP_ORANGE_STYLE = "#ff8c00"
RED_STYLE = "#ff3b30"


def _double_width(text: str) -> str:
    return "".join(char * 2 for char in text)


def render_heading(text: str) -> None:
    console.print(f"\n[heading]{text}[/]\n")


def render_success(message: str) -> None:
    console.print(f"[success]✓[/success] {message}")


def render_warning(message: str) -> None:
    console.print(f"[warning]⚠[/warning] {message}")


def render_error(message: str) -> None:
    console.print(f"[error]✗[/error] {message}")


def render_info(message: str) -> None:
    console.print(f"[info]ℹ[/info] {message}")


def render_session_header(
    *, project_root: Path, provider: str, model: str, approval_mode: str
) -> None:
    for i in range(len(R_LEFT)):
        row_text = Text()
        row_text.append(_double_width(R_LEFT[i]), style=DEEP_ORANGE_STYLE)
        row_text.append(_double_width(" "))
        row_text.append(_double_width(P_MID[i]), style=RED_STYLE)
        row_text.append(_double_width(" "))
        row_text.append(_double_width(R_RIGHT[i]), style=DEEP_ORANGE_STYLE)
        console.print(row_text)
    # add new line
    console.print()
    console.print(
        Panel(
            (
                f"[bold]Project Root:[/] [path]{project_root}[/]\n"
                f"[bold]Provider:[/] {provider}\n"
                f"[bold]Model:[/] {model}\n"
                f"[bold]Approval Mode:[/] {approval_mode}"
            ),
            title="RPR Chat Session",
            border_style="dim",
        )
    )


def render_tool_call(
    tool_name: str, arguments: dict[str, object], *, is_mutating: bool
) -> None:
    tool_kind = "mutation" if is_mutating else "read-only"
    payload = (
        json.dumps(arguments, indent=2, sort_keys=True, default=str)
        if arguments
        else "{}"
    )
    console.print(
        Panel(
            escape(payload),
            title=f"Tool Call: {tool_name} ({tool_kind})",
            border_style="dim",
            padding=(0, 1),
        )
    )


def render_tool_result(tool_name: str, output: str, *, success: bool) -> None:
    outcome = "success" if success else "failure"
    title = f"Tool Result: {tool_name} ({outcome})"
    border_style = "dim"
    console.print(
        Panel(escape(output), title=title, border_style=border_style, padding=(0, 1))
    )


def render_approval_prompt(tool_name: str) -> None:
    console.print(
        f"[warning]Approval required:[/] {tool_name} wants to modify the repository."
    )


def render_chat_hint(message: str) -> None:
    console.print(f"[muted]{message}[/]")


def render_command_start(cmd: str, cwd: str, is_dry_run: bool = False) -> None:
    prefix = (
        "[dry_run][DRY RUN][/] Would run" if is_dry_run else "[info]\\[rpr] Running:[/]"
    )
    console.print(f"{prefix} [command]{cmd}[/]", soft_wrap=True)
    if is_dry_run:
        console.print(f"         in: [path]{cwd}[/]", soft_wrap=True)


def render_file_preview(
    path: Path | str, content: str, is_dry_run: bool = False, is_update: bool = False
) -> None:
    action = "update" if is_update else "create"

    if is_dry_run:
        prefix = f"[dry_run][DRY RUN][/] Would {action}: "
        console.print(f"\n{prefix}[path]{path}[/]", soft_wrap=True)
        console.print(f"[border]{'─' * 60}[/]")
        for i, line in enumerate(content.splitlines(), 1):
            console.print(f"  [line_number]{i:>4}[/] [border]│[/] {escape(line)}")
        console.print(f"[border]{'─' * 60}[/]")
    else:
        done_action = "Updated" if is_update else "Created"
        console.print(f"[success]{done_action}:[/][path] {path}[/]")


def render_markdown(content: str) -> None:
    render_markdown_content(content, mode="preview", use_panel=False, max_lines=None)


def render_table(title: str, columns: list[str], rows: list[list[str]]) -> None:
    table = Table(title=title, box=None, show_header=True, header_style="bold")
    for col in columns:
        table.add_column(col)
    for row in rows:
        table.add_row(*row)
    console.print(table)


def render_status_row(
    icon_char: str, area: str, path: str, status: bool, suggestion: str | None = None
) -> None:
    icon_style = "success" if status else "error"
    icon = f"[{icon_style}][{icon_char}][/{icon_style}]"
    area_display = f"{area:<20}"

    if status:
        console.print(f"  {icon} {area_display} [muted]{path}[/]")
    else:
        status_text = "[error]missing[/error]"
        suggestion_text = (
            f" → [warning]run: {suggestion}[/warning]" if suggestion else ""
        )
        console.print(f"  {icon} {area_display} {status_text}{suggestion_text}")
