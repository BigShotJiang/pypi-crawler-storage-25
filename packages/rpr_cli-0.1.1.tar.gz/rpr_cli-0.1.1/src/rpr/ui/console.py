from __future__ import annotations

import sys

from rich.console import Console
from rpr.ui.theme import theme_manager


def get_console() -> Console:
    return Console(theme=theme_manager.get_theme(), color_system="auto")


# Shared console instance
# Note: In a real app, you might want to re-initialize this if the theme changes
console = get_console()


def refresh_console():
    """Refresh the shared console instance with the current theme."""
    global console
    console = get_console()

    for module_name in (
        "rpr.ui.markdown",
        "rpr.ui.renderers",
        "rpr.context",
        "rpr.commands.chat",
        "rpr.commands.settings",
    ):
        module = sys.modules.get(module_name)
        if module is not None:
            setattr(module, "console", console)
