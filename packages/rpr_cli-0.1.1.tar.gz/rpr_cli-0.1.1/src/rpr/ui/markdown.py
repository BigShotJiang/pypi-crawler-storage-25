from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from rich.markdown import Markdown
from rich.panel import Panel

from rpr.ui.console import console

DEFAULT_MARKDOWN_PREVIEW_LINES = 120


@dataclass(frozen=True)
class MarkdownPreview:
    raw: str
    preview: str
    truncated: bool


def build_markdown_preview(
    content: str,
    *,
    max_lines: int | None = DEFAULT_MARKDOWN_PREVIEW_LINES,
) -> MarkdownPreview:
    if max_lines is None:
        return MarkdownPreview(raw=content, preview=content, truncated=False)

    lines = content.splitlines()
    if len(lines) <= max_lines:
        return MarkdownPreview(raw=content, preview=content, truncated=False)

    return MarkdownPreview(
        raw=content, preview="\n".join(lines[:max_lines]), truncated=True
    )


def render_markdown(
    content: str,
    *,
    mode: Literal["preview", "raw"] = "preview",
    title: str | None = None,
    use_panel: bool = True,
    max_lines: int | None = DEFAULT_MARKDOWN_PREVIEW_LINES,
) -> str:
    preview = build_markdown_preview(content, max_lines=max_lines)

    if mode == "raw":
        return preview.raw

    renderable = Markdown(preview.preview)
    if use_panel or title is not None:
        renderable = Panel(renderable, title=title, border_style="dim", padding=(0, 1))

    console.print(renderable)
    if preview.truncated:
        console.print("[warning](preview truncated)[/warning]")

    return preview.raw
