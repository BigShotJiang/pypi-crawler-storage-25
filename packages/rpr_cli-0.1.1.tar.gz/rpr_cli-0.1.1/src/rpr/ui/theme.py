from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from rich.theme import Theme


@dataclass
class UIStyles:
    success: str = "green"
    warning: str = "yellow"
    error: str = "red"
    info: str = "blue"
    muted: str = "dim"
    heading: str = "bold"
    command: str = "bold blue"
    dry_run: str = "bold yellow"
    path: str = "cyan"
    line_number: str = "dim"
    border: str = "dim"


def create_rich_theme(styles: UIStyles) -> Theme:
    return Theme(
        {
            "success": styles.success,
            "warning": styles.warning,
            "error": styles.error,
            "info": styles.info,
            "muted": styles.muted,
            "heading": styles.heading,
            "command": styles.command,
            "dry_run": styles.dry_run,
            "path": styles.path,
            "line_number": styles.line_number,
            "border": styles.border,
        }
    )


THEMES = {
    "standard": UIStyles(),
    "monochrome": UIStyles(
        success="bold white",
        warning="white",
        error="bold white",
        info="white",
        muted="dim",
        heading="bold",
        command="bold",
        dry_run="bold",
        path="white",
    ),
    "vibrant": UIStyles(
        success="bold bright_green",
        warning="bold bright_yellow",
        error="bold bright_red",
        info="bold bright_blue",
        command="bold bright_magenta",
        dry_run="bold bright_yellow",
        path="bright_cyan",
    ),
    "ocean": UIStyles(
        success="green",
        warning="yellow",
        error="red",
        info="blue",
        command="cyan",
        dry_run="bright_blue",
        path="bright_cyan",
        heading="bold blue",
    ),
    "dracula": UIStyles(
        success="#50fa7b",
        warning="#f1fa8c",
        error="#ff5555",
        info="#8be9fd",
        command="#bd93f9",
        dry_run="#f1fa8c",
        path="#8be9fd",
        heading="bold #ff79c6",
        muted="#6272a4",
        border="#6272a4",
    ),
}


@dataclass(slots=True, frozen=True)
class SettingDefinition:
    key: str
    description: str
    kind: str
    default: str | bool
    choices: tuple[str, ...] = ()


SETTING_DEFINITIONS = {
    "theme": SettingDefinition(
        key="theme",
        description="Terminal theme for Rich output.",
        kind="choice",
        default="standard",
        choices=tuple(THEMES),
    ),
    "approval_mode": SettingDefinition(
        key="approval_mode",
        description="Default approval mode for chat tool calls.",
        kind="choice",
        default="ask",
        choices=("ask", "auto-readonly", "auto-all"),
    ),
    "startup_help": SettingDefinition(
        key="startup_help",
        description="Show slash-command guidance when chat starts.",
        kind="bool",
        default=True,
    ),
}


def _coerce_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "t", "yes", "y", "on"}:
            return True
        if normalized in {"0", "false", "f", "no", "n", "off"}:
            return False
    raise ValueError("Expected a boolean value: true/false, yes/no, or on/off.")


class SettingsManager:
    _instance: SettingsManager | None = None
    _current_theme_name: str = "standard"
    _approval_mode_name: str = "ask"
    _startup_help: bool = True
    _config_path: Path = Path.home() / ".rpr" / "settings.json"

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SettingsManager, cls).__new__(cls)
            cls._instance._load_settings()
        return cls._instance

    @staticmethod
    def definitions() -> dict[str, SettingDefinition]:
        return SETTING_DEFINITIONS

    def _default_data(self) -> dict[str, str | bool]:
        return {
            key: definition.default for key, definition in SETTING_DEFINITIONS.items()
        }

    def _load_settings(self):
        data = self._default_data()
        if self._config_path.exists():
            try:
                loaded = json.loads(self._config_path.read_text())
            except json.JSONDecodeError, OSError:
                loaded = {}
            if isinstance(loaded, dict):
                data.update(loaded)

        self._current_theme_name = self._coerce_value(
            "theme", data.get("theme", "standard")
        )
        self._approval_mode_name = self._coerce_value(
            "approval_mode",
            data.get("approval_mode", "ask"),
        )
        self._startup_help = self._coerce_value(
            "startup_help", data.get("startup_help", True)
        )

    def _save_settings(self):
        self._config_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._config_path.write_text(
                json.dumps(
                    {
                        "theme": self._current_theme_name,
                        "approval_mode": self._approval_mode_name,
                        "startup_help": self._startup_help,
                    },
                    indent=2,
                )
            )
        except OSError:
            pass

    def _coerce_value(self, key: str, value: object) -> str | bool:
        definition = SETTING_DEFINITIONS[key]
        if definition.kind == "bool":
            return _coerce_bool(value)

        if not isinstance(value, str):
            raise ValueError(f"Expected a string value for {key}.")

        if definition.choices and value not in definition.choices:
            allowed = ", ".join(definition.choices)
            if key == "theme":
                raise ValueError(f"Unknown theme: {value}")
            raise ValueError(f"Unknown value for {key}: {value}. Valid: {allowed}")
        return value

    def get_value(self, key: str) -> str | bool:
        if key not in SETTING_DEFINITIONS:
            raise KeyError(key)
        if key == "theme":
            return self._current_theme_name
        if key == "approval_mode":
            return self._approval_mode_name
        if key == "startup_help":
            return self._startup_help
        raise KeyError(key)

    def set_value(self, key: str, value: object) -> str | bool:
        if key not in SETTING_DEFINITIONS:
            raise KeyError(key)

        coerced = self._coerce_value(key, value)
        if key == "theme":
            self._current_theme_name = coerced
        elif key == "approval_mode":
            self._approval_mode_name = coerced
        elif key == "startup_help":
            self._startup_help = coerced
        else:
            raise KeyError(key)

        self._save_settings()
        return coerced

    def describe_settings(self) -> list[tuple[SettingDefinition, str]]:
        rows: list[tuple[SettingDefinition, str]] = []
        for key, definition in SETTING_DEFINITIONS.items():
            value = self.get_value(key)
            if isinstance(value, bool):
                display = "true" if value else "false"
            else:
                display = value
            rows.append((definition, display))
        return rows

    @property
    def current_theme_name(self) -> str:
        return self._current_theme_name

    @current_theme_name.setter
    def current_theme_name(self, name: str):
        self.set_value("theme", name)

    @property
    def approval_mode_name(self) -> str:
        return self._approval_mode_name

    @approval_mode_name.setter
    def approval_mode_name(self, name: str) -> None:
        self.set_value("approval_mode", name)

    @property
    def approval_mode(self):
        from rpr.agent.approval import ApprovalMode

        return ApprovalMode(self._approval_mode_name)

    @property
    def startup_help(self) -> bool:
        return self._startup_help

    @startup_help.setter
    def startup_help(self, enabled: bool) -> None:
        self.set_value("startup_help", enabled)

    def get_theme(self) -> Theme:
        return create_rich_theme(THEMES[self._current_theme_name])

    def get_styles(self) -> UIStyles:
        return THEMES[self._current_theme_name]


settings_manager = SettingsManager()
theme_manager = settings_manager
