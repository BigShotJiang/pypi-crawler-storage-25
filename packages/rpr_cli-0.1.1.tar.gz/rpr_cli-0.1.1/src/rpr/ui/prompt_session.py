from __future__ import annotations

import asyncio
import re
import sys
from prompt_toolkit import PromptSession
from prompt_toolkit.application.current import get_app_or_none
from prompt_toolkit.completion import Completer
from prompt_toolkit.document import Document
from prompt_toolkit.filters import Condition, is_true, to_filter
from prompt_toolkit.formatted_text import AnyFormattedText
from prompt_toolkit.formatted_text.utils import fragment_list_to_text
from prompt_toolkit.history import History, InMemoryHistory
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout.dimension import Dimension
from prompt_toolkit.layout.layout import Layout
from prompt_toolkit.layout.processors import (
    Processor,
    Transformation,
    TransformationInput,
)
from prompt_toolkit.patch_stdout import patch_stdout
from prompt_toolkit.styles import Style

from rpr.agent.control import TurnControl
from rpr.application.selector import (
    TriggerSelector,
    TriggerSelectorSnapshot,
    TriggerSelectorSource,
)
from rpr.ui.theme import THEMES


PROMPT_STYLE = Style.from_dict(
    {
        "bottom-toolbar": f"bg:#111111 #020b0f",
        "bottom-toolbar.text": "",
        "file-ref": f"bold {THEMES['dracula'].path}",
        "selector.rule": "bg:#111111 #6b7280",
        "selector.row": "",
        "selector.row.selected": f"bg:#111111 {THEMES['dracula'].muted} bold",
        "selector.label": "bold",
        "selector.count": "#9ca3af",
    }
)


class FileReferenceProcessor(Processor):
    _pattern = re.compile(r"@[A-Za-z0-9_./-]+")

    def apply_transformation(
        self, transformation_input: TransformationInput
    ) -> Transformation:
        line = fragment_list_to_text(transformation_input.fragments)
        if "@" not in line:
            return Transformation(transformation_input.fragments)

        ranges = [
            match.span()
            for match in self._pattern.finditer(line)
            if match.start() == 0 or line[match.start() - 1].isspace()
        ]
        if not ranges:
            return Transformation(transformation_input.fragments)

        fragments: list[tuple[str, str] | tuple[str, str, object]] = []
        offset = 0
        range_index = 0
        active_range = ranges[range_index]

        for fragment in transformation_input.fragments:
            style, text, *rest = fragment
            segment_start = 0
            while segment_start < len(text):
                while (
                    range_index < len(ranges)
                    and offset + segment_start >= active_range[1]
                ):
                    range_index += 1
                    if range_index < len(ranges):
                        active_range = ranges[range_index]
                in_highlight = (
                    range_index < len(ranges)
                    and active_range[0] <= offset + segment_start < active_range[1]
                )
                boundary = (
                    active_range[1] - offset
                    if in_highlight and range_index < len(ranges)
                    else len(text)
                )
                if not in_highlight and range_index < len(ranges):
                    boundary = min(boundary, active_range[0] - offset)
                segment_end = min(len(text), max(segment_start + 1, boundary))
                segment_text = text[segment_start:segment_end]
                segment_style = (
                    style
                    if not in_highlight
                    else self._merge_style(style, "class:file-ref")
                )
                if rest:
                    fragments.append((segment_style, segment_text, *rest))
                else:
                    fragments.append((segment_style, segment_text))
                segment_start = segment_end
            offset += len(text)

        return Transformation(fragments)

    @staticmethod
    def _merge_style(existing: str, addition: str) -> str:
        return addition if not existing else f"{existing} {addition}"


class FramedPromptSession(PromptSession[str]):
    def _create_layout(self) -> Layout:
        layout = super()._create_layout()
        layout.current_window.dont_extend_height = to_filter(True)
        return layout

    def _get_default_buffer_control_height(self) -> Dimension:
        dimension = super()._get_default_buffer_control_height()
        if is_true(self.multiline):
            if dimension.min is not None and dimension.min > 1:
                return dimension
            return Dimension(min=1)
        if dimension.min is not None and dimension.min > 1:
            return dimension
        return Dimension(min=1, max=1, preferred=1)


class PromptSessionAdapter:
    def __init__(self) -> None:
        self._prompt_session: PromptSession[str] | None = None
        self._prompt_session_loop: asyncio.AbstractEventLoop | None = None
        self._input_lock: asyncio.Lock | None = None
        self._input_lock_loop: asyncio.AbstractEventLoop | None = None
        self._history: History = InMemoryHistory()
        self._completer: Completer | None = None
        self._selector = TriggerSelector()
        self._active_task: asyncio.Task | None = None
        self._active_control: TurnControl | None = None
        self._queued_count: int = 0
        self._next_queued_preview: str | None = None
        self._active_prompt_kind: str | None = None

    def set_active_task(self, task: asyncio.Task | None) -> None:
        self._active_task = task

    def set_active_control(self, control: TurnControl | None) -> None:
        self._active_control = control

    def set_queue_info(self, count: int, preview: str | None) -> None:
        self._queued_count = count
        self._next_queued_preview = preview

    def set_completer(self, completer: Completer) -> None:
        self._completer = completer
        selector_sources = getattr(completer, "selector_sources", None)
        if isinstance(selector_sources, tuple):
            self._selector.set_sources(
                [
                    source
                    for source in selector_sources
                    if isinstance(source, TriggerSelectorSource)
                ]
            )
        else:
            selector_source = getattr(completer, "selector_source", None)
            if isinstance(selector_source, TriggerSelectorSource):
                self._selector.set_sources([selector_source])
            else:
                self._selector.set_sources([])
        if self._prompt_session is not None:
            self._prompt_session.completer = completer

    def has_modal_input(self) -> bool:
        return self._active_prompt_kind == "modal"

    def get_prompt_session(self) -> PromptSession[str]:
        current_loop = asyncio.get_running_loop()
        if (
            self._prompt_session is None
            or self._prompt_session_loop is not current_loop
        ):
            self._prompt_session = FramedPromptSession(
                history=self._history,
                completer=self._completer,
                complete_while_typing=False,
                reserve_space_for_menu=0,
                key_bindings=self._build_key_bindings(),
                bottom_toolbar=self._render_toolbar,
                input_processors=[FileReferenceProcessor()],
                style=PROMPT_STYLE,
            )
            self._prompt_session_loop = current_loop
        return self._prompt_session

    async def read_input(
        self,
        message: str = "> ",
        *,
        multiline: bool = False,
        modal: bool = False,
    ) -> str:
        async with self._get_input_lock():
            self._active_prompt_kind = "modal" if modal else "input"
            try:
                if not sys.stdin.isatty():
                    print(message, end="", flush=True)
                    line = await asyncio.to_thread(sys.stdin.readline)
                    if not line:
                        raise EOFError
                    return line.rstrip("\n")

                with patch_stdout():
                    response = await self.get_prompt_session().prompt_async(
                        message,
                        placeholder="   Type your message, a slash command or @path/to/file",
                        multiline=multiline,
                        show_frame=True,
                    )
                return response.strip()
            finally:
                self._active_prompt_kind = None

    async def prompt(self, label: str, *, default: str | None = None) -> str:
        prompt_text = label if default is None else f"{label} [{default}]"
        response = await self.read_input(f"{prompt_text}> ")
        if not response and default is not None:
            return default
        return response

    async def confirm(self, label: str, *, default: bool = False) -> bool:
        suffix = "Y/n" if default else "y/N"
        response = await self.read_input(f"{label} [{suffix}] > ")
        if not response:
            return default
        return response.lower() in {"y", "yes"}

    def reset(self) -> None:
        self._prompt_session = None
        self._prompt_session_loop = None
        self._input_lock = None
        self._input_lock_loop = None
        self._history = InMemoryHistory()
        self._completer = None
        self._selector.reset()
        self._active_task = None
        self._active_control = None
        self._queued_count = 0
        self._next_queued_preview = None
        # Clear the PromptToolkit AppSession's cached output so the next
        # invocation binds to the current sys.stdout rather than a stale buffer.
        from prompt_toolkit.application.current import get_app_session

        get_app_session()._output = None

    def _get_input_lock(self) -> asyncio.Lock:
        current_loop = asyncio.get_running_loop()
        if self._input_lock is None or self._input_lock_loop is not current_loop:
            self._input_lock = asyncio.Lock()
            self._input_lock_loop = current_loop
        return self._input_lock

    def _build_key_bindings(self) -> KeyBindings:
        bindings = KeyBindings()

        @Condition
        def multiline_prompt_active() -> bool:
            session = self._prompt_session
            return session is not None and is_true(session.multiline)

        @Condition
        def selector_visible() -> bool:
            app = get_app_or_none()
            if app is None:
                return False
            return self._selector.is_visible(
                app.current_buffer.text,
                app.current_buffer.cursor_position,
            )

        @bindings.add("enter", filter=multiline_prompt_active & ~selector_visible)
        def submit_multiline_input(event) -> None:
            event.current_buffer.validate_and_handle()

        @bindings.add(
            "escape", "enter", filter=multiline_prompt_active & ~selector_visible
        )
        def insert_multiline_newline(event) -> None:
            event.current_buffer.newline(copy_margin=True)

        @Condition
        def agent_task_active() -> bool:
            return self._active_task is not None and not self._active_task.done()

        @bindings.add("escape", filter=~selector_visible & agent_task_active)
        def cancel_agent_task(event) -> None:
            if self._active_control is not None:
                self._active_control.cancel()
            if self._active_task is not None and not self._active_task.done():
                self._active_task.cancel()
            event.app.invalidate()

        @bindings.add("down", filter=selector_visible)
        @bindings.add("c-n", filter=selector_visible)
        def select_next(event) -> None:
            buffer = event.app.current_buffer
            self._selector.move_selection(
                buffer.text,
                buffer.cursor_position,
                step=1,
            )
            event.app.invalidate()

        @bindings.add("up", filter=selector_visible)
        @bindings.add("c-p", filter=selector_visible)
        def select_previous(event) -> None:
            buffer = event.app.current_buffer
            self._selector.move_selection(
                buffer.text,
                buffer.cursor_position,
                step=-1,
            )
            event.app.invalidate()

        @bindings.add("tab", filter=selector_visible)
        @bindings.add("enter", filter=selector_visible)
        def insert_selection(event) -> None:
            buffer = event.app.current_buffer
            application = self._selector.apply_selection(
                buffer.text,
                buffer.cursor_position,
            )
            if application is None:
                buffer.validate_and_handle()
                return
            buffer.document = Document(
                text=application.text,
                cursor_position=application.cursor_position,
            )
            event.app.invalidate()

        @bindings.add("escape", filter=selector_visible)
        def dismiss_selector(event) -> None:
            buffer = event.app.current_buffer
            self._selector.dismiss(buffer.text, buffer.cursor_position)
            event.app.invalidate()

        return bindings

    def _render_toolbar(self) -> AnyFormattedText:
        app = get_app_or_none()
        if app is not None:
            snapshot = self._selector.snapshot(
                app.current_buffer.text,
                app.current_buffer.cursor_position,
            )
            if snapshot.visible:
                width = max(40, app.output.get_size().columns)
                return self._selector_fragments(snapshot, width=width)

        fragments: list[tuple[str, str]] = []
        task_active = self._active_task is not None and not self._active_task.done()
        if task_active:
            fragments.append(("class:bottom-toolbar.text", " Press ESC to cancel"))
        if self._queued_count > 0 and self._next_queued_preview is not None:
            preview = self._next_queued_preview[:50]
            fragments.append(
                (
                    "class:bottom-toolbar.text",
                    f"  |  Queued ({self._queued_count}): {preview}...",
                )
            )
        return fragments

    def _selector_fragments(
        self, snapshot: TriggerSelectorSnapshot, *, width: int
    ) -> AnyFormattedText:
        content_width = max(20, width)
        visible_start = snapshot.visible_start + 1
        count_line = (
            f"({visible_start}/{len(snapshot.matches)})"
            if snapshot.matches
            else "(0/0)"
        )
        fragments: list[tuple[str, str]] = [
            ("class:selector.rule", self._fill_rule("▄", content_width) + "\n"),
        ]

        for offset, candidate in enumerate(snapshot.visible_matches):
            absolute_index = snapshot.visible_start + offset
            row_style = (
                "class:selector.row.selected"
                if absolute_index == snapshot.selected_index
                else "class:selector.row"
            )
            row_text = self._format_candidate_row(
                candidate.label, candidate.description, content_width
            )
            fragments.append((row_style, row_text + "\n"))

        fragments.extend(
            [
                ("class:selector.row", "▼\n"),
                ("class:selector.count", count_line.ljust(content_width) + "\n"),
                ("class:selector.rule", self._fill_rule(" ", content_width)),
            ]
        )
        return fragments

    def _format_candidate_row(self, label: str, description: str, width: int) -> str:
        label_width = min(16, max(10, width // 6))
        gap = 3
        description_width = max(0, width - label_width - gap)
        fitted_label = self._fit_panel_text(label, label_width)
        fitted_description = self._fit_panel_text(description, description_width)
        return f"{fitted_label}{' ' * gap}{fitted_description}".ljust(width)

    @staticmethod
    def _fill_rule(character: str, width: int) -> str:
        return character * width

    @staticmethod
    def _fit_panel_text(content: str, width: int) -> str:
        if len(content) <= width:
            return content.ljust(width)
        if width <= 3:
            return content[:width]
        return f"{content[: width - 3]}..."
