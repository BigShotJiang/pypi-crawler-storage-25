from __future__ import annotations

from pathlib import Path

from rpr.checks.base import CheckResult
from rpr.generators.base import SyncConfig, interpolate
from rpr.templates.registry import TEMPLATES


def check_instructions(
    project_dir: Path, variables: dict[str, str]
) -> list[CheckResult]:
    results = []

    # Cursor rules
    cursor_rules = project_dir / ".cursor" / "rules"
    cursor_ok = cursor_rules.exists() and any(cursor_rules.glob("*.mdc"))
    results.append(
        CheckResult(
            group="AI Instructions & Templates",
            area="Cursor rules",
            status=cursor_ok,
            path=str(cursor_rules) if cursor_ok else ".cursor/rules/ missing",
            suggestion="rpr sync rules --target cursor",
        )
    )

    # Copilot instructions
    copilot_file = project_dir / ".github" / "copilot-instructions.md"
    results.append(
        CheckResult(
            group="AI Instructions & Templates",
            area="Copilot instructions",
            status=copilot_file.exists(),
            path=str(copilot_file)
            if copilot_file.exists()
            else ".github/copilot-instructions.md missing",
            suggestion="rpr sync rules --target copilot",
        )
    )

    # Claude instructions
    claude_file = project_dir / "CLAUDE.md"
    results.append(
        CheckResult(
            group="AI Instructions & Templates",
            area="Claude instructions",
            status=claude_file.exists(),
            path=str(claude_file) if claude_file.exists() else "CLAUDE.md missing",
            suggestion="rpr sync rules --target claude",
        )
    )

    # Templates (only if domain package exists for Python, or UI library for JS)
    has_domain = any(project_dir.glob("packages/python/domain"))
    has_ui = any(project_dir.glob("packages/node/*-ui"))

    template_ids = [
        ("domain_settings", "has_domain"),
        ("domain_container", "has_domain"),
        ("mapper_util", "has_domain"),
        ("dto_util", "has_domain"),
        ("partial_update", "has_domain"),
        ("encrypted_column", "has_domain"),
        ("fetch_service", "has_ui"),
        ("sticky_navigation", "has_ui"),
    ]

    for tid, prereq in template_ids:
        if (prereq == "has_domain" and not has_domain) or (
            prereq == "has_ui" and not has_ui
        ):
            continue

        entry = TEMPLATES[tid]
        target_path_str = interpolate(entry.target_path, variables)
        target_path = project_dir / target_path_str

        results.append(
            CheckResult(
                group="AI Instructions & Templates",
                area=tid,
                status=target_path.exists(),
                path=str(target_path) if target_path.exists() else f"{tid} missing",
                suggestion=f"rpr add template {tid}",
            )
        )

    return results
