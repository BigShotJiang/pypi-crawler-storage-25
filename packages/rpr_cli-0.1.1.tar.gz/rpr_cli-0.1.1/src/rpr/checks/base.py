from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class CheckResult:
    area: str
    status: bool
    path: str
    suggestion: str
    group: str
