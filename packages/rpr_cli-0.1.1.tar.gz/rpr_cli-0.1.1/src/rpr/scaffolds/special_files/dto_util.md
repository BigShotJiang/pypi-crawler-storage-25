## DTO Helper Template

Target path: `/packages/python/domain/src/{name_underscore}_domain/utils/dto_util.py`

Use this helper when the same DTO mapper should support both a single entity and a list of entities without requiring separate functions.

The first Python block is the generated file used by `rpr add template dto_util`.

```python
from functools import wraps
from typing import Any, Callable, overload

class DtoHelper[ModelType, R]:
    """A smart DTO helper that can convert a single entity or a list of entities to DTO(s) without requiring separate functions."""
    def __init__(self, to_dto_func: Callable[[ModelType], R]):
        self.to_dto_func = to_dto_func
        wraps(to_dto_func)(self)

    @overload
    def __call__(self, model: ModelType, *args, **kwargs) -> R: ...

    @overload
    def __call__(self, model: list[ModelType], *args, **kwargs) -> list[R]: ...

    def __call__(self, model: Any, *args, **kwargs) -> Any:
        if isinstance(model, list):
            return [
                self.to_dto_func(*m, *args, **kwargs)
                if isinstance(m, tuple)
                else self.to_dto_func(m, *args, **kwargs)
                for m in model
            ]
        return self.to_dto_func(model, *args, **kwargs)

def dto_helper[ModelType, R](to_dto_func: Callable[[ModelType], R]) -> DtoHelper[ModelType, R]:
    return DtoHelper(to_dto_func)
```

## Why This Exists

- It removes repeated `[to_dto(item) for item in items]` boilerplate.
- It keeps the mapper call site the same whether the caller has one entity or many.
- It pairs naturally with repository and service code that already works with ORM models.

### Usage

```python
from your_app_domain.utils.dto_util import dto_helper
from your_app_domain.models.entities import User
from your_app_domain.models.dtos import UserDTO

# Define a function that converts a model to a DTO
@dto_helper
def user_to_dto(user: User) -> UserDTO:
    return UserDTO(id=user.id, name=user.name)

# Convert a single user
dto = user_to_dto(user)

# Convert a list of users
dtos = user_to_dto([user1, user2, user3])
```
