## Mapper Utility Template

Target path: `/packages/python/domain/src/{name_underscore}_domain/utils/mapper_util.py`

Use this template when repository methods should support both raw ORM access and deferred DTO conversion through `.to_dto()`.

The first Python block is the generated file used by `rpr add template mapper_util`.

```python
from __future__ import annotations
import inspect
from functools import wraps
from typing import (
    TYPE_CHECKING,
    Any,
    Awaitable,
    Callable,
    Concatenate,
    cast,
    overload
)

if TYPE_CHECKING:
    from your_app_domain.repos import BaseRepo # Another special file

class Mapper[RepoResult, DtoResult]:
    """
    Wraps a repository coroutine and provides deferred DTO conversion.
    - Await the mapper directly to get the raw ORM result.
    - Call `.to_dto()` on the mapper to get the converted DTO result.
    """
    def __init__(self, coro: Awaitable[RepoResult], dto_func: Callable[[RepoResult], DtoResult]):
        self._coro = coro
        self._dto_func = dto_func

    def __await__(self):
        return self._coro.__await__()

    async def to_dto(self) -> DtoResult | None:
        obj = await self._coro
        if obj is None:
            return None

        if isinstance(obj, tuple):
            actual_func = inspect.unwrap(self._dto_func)
            sig = inspect.signature(actual_func)
            params = list(sig.parameters.values())
            if len(params) == 1:
                return self._dto_func(obj)
            else:
                return self._dto_func(*obj)

        return self._dto_func(obj)

@overload
def mapper[Repo, RepoResult, **P](
    method: Callable[Concatenate[Repo, P], Awaitable[RepoResult]],
) -> Callable[Concatenate[Repo, P], Mapper[RepoResult, Any]]: ...

@overload
def mapper[Repo, RepoResult, DtoResult, **P](
    *,
    dto_func: Callable[[RepoResult], DtoResult],
) -> Callable[
    [Callable[Concatenate[Repo, P], Awaitable[RepoResult]]],
    Callable[Concatenate[Repo, P], Mapper[RepoResult, DtoResult]],
]: ...

def mapper(
    method: Callable[..., Awaitable[Any]] | None = None,
    *,
    dto_func: Callable[[Any], Any] | None = None,
):
    """
    Decorator for repository methods that returns a Mapper instance.

    The Mapper can then be:
     - awaited directly -> returns the raw ORM result
        - call .to_dto() -> returns the converted DTO result

     use @mapper alone to use the repository's default dto_func
     use @mapper(dto_func=your_custom_dto_func) to override the default dto_func for that specific method.

     Examples:
       @mapper
       async def get_by_id(self, id: str) -> TEntity | None:

       @mapper(dto_func=custom_dto_func)
       async def get_by_id_custom(self, id: str) -> dict[str, TEntity] | None:
    """
    def decorate_with_default[Repo, RepoResult, **P](
        func: Callable[Concatenate[Repo, P], Awaitable[RepoResult]],
    ) -> Callable[Concatenate[Repo, P], Mapper[RepoResult, Any]]:
        @wraps(func)
        def wrapper(
            self: BaseRepo, *args: P.args, **kwargs: P.kwargs
        ) -> Mapper[RepoResult, Any]:
            return Mapper(func(self, *args, **kwargs), self.dto_func)
        return wrapper

    if method is not None:
        return decorate_with_default(method)

    def decorator[Repo, RepoResult, DtoResult, **P](
        func: Callable[Concatenate[Repo, P], Awaitable[RepoResult]],
    ) -> Callable[Concatenate[Repo, P], Mapper[RepoResult, DtoResult]]:
        if dto_func is None:
            raise ValueError("dto_func must be provided when using @mapper(...)")
        typed_dto_func = cast(Callable[[RepoResult], DtoResult], dto_func)

        @wraps(func)
        def wrapper(
            self: BaseRepo, *args: P.args, **kwargs: P.kwargs
        ) -> Mapper[RepoResult, DtoResult]:
            return Mapper(func(self, *args, **kwargs), typed_dto_func)

        return wrapper

    return decorator
```

Usage

```python
from your_app_domain.repos import BaseRepo
from your_app_domain.utils import mapper
from your_app_domain.models.entities import SomeEntity
from your_app_domain.models.dtos import some_entity_to_dto, custom_dto_func

class MyRepo(BaseRepo[SomeEntity]):
    def __init__(self, engine):
        super().__init__(SomeEntity, engine, some_entity_to_dto) # Pass the default DTO conversion function

    @mapper
    async def get_by_id(self, id: str) -> SomeEntity | None:
        ...

    @mapper(dto_func=custom_dto_func)
    async def get_by_id_custom(self, id: str) -> dict[str, SomeEntity] | None:
        ...

# Usage
repo = MyRepo(engine)
result = await repo.get_by_id("some_id")  # Returns raw ORM result
dto_result = await repo.get_by_id("some_id").to_dto()  # Returns DTO result
custom_dto_result = await repo.get_by_id_custom("some_id").to_dto()  # Returns custom DTO result
```

## What This Template Solves

- Repository callers can choose between awaiting the raw ORM result and calling `.to_dto()` when they need mapped DTOs.
- The repository keeps a default mapper while still allowing per-method overrides.
- Tuple results are supported for methods that return composite values into a mapper function.

## Usage Notes

- Use `@mapper` on repository methods that should expose `.to_dto()`.
- Use `@mapper(dto_func=...)` only when a method needs a different mapping strategy than the repository default.
- Pair this with `dto_util` when the DTO mapper itself should support both single values and lists.
