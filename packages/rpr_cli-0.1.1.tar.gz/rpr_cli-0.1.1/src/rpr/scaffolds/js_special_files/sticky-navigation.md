## Internal Template Source: useStateNavigation

Target path: `/packages/node/{name}-ui/src/hooks/useStateNavigation.ts`

This markdown file is an internal generator source for `rpr add template sticky_navigation`. It is not synced project instruction guidance.

Keep the first TypeScript block as the complete generated file. `src/rpr/commands/add.py` extracts the first matching fenced block for this template.

```ts
import { useCallback, useLayoutEffect, useState } from "react";

type NavigationStateChangeDetail = {
  property: string;
  newValue: string | null;
};

type SetNavigationValueOptions = {
  replace?: boolean;
};

type SetNavigationValue = (
  newValue: string | null,
  options?: SetNavigationValueOptions,
) => void;

const normalizeValue = (value?: string | null): string => value?.trim() ?? "";

const getInitialValue = (property: string, defaultValue: string): string => {
  const currentParams = new URLSearchParams(window.location.search);
  const normalizedDefaultValue = normalizeValue(defaultValue);

  return normalizeValue(currentParams.get(property)) || normalizedDefaultValue;
};

const buildUrlFromValue = (property: string, value?: string | null): string => {
  const normalizedValue = normalizeValue(value);
  const currentParams = new URLSearchParams(window.location.search);

  if (!normalizedValue) {
    currentParams.delete(property);
  } else {
    currentParams.set(property, normalizedValue);
  }

  const newSearch = currentParams.toString();

  return newSearch
    ? `${window.location.pathname}?${newSearch}${window.location.hash}`
    : `${window.location.pathname}${window.location.hash}`;
};

export const useStateNavigation = (
  property: string,
  defaultValue = "",
): readonly [string, SetNavigationValue] => {
  const normalizedDefaultValue = normalizeValue(defaultValue);

  const [value, setValueState] = useState(() =>
    getInitialValue(property, normalizedDefaultValue),
  );

  const syncValueFromUrl = useCallback(() => {
    const nextValue = getInitialValue(property, normalizedDefaultValue);

    setValueState((previousValue) =>
      previousValue === nextValue ? previousValue : nextValue,
    );
  }, [property, normalizedDefaultValue]);

  useLayoutEffect(() => {
    syncValueFromUrl();
  }, [syncValueFromUrl]);

  useLayoutEffect(() => {
    const controller = new AbortController();

    const handleNavigationStateChange = (event: Event) => {
      const customEvent = event as CustomEvent<NavigationStateChangeDetail>;
      const { property: changedProperty, newValue } = customEvent.detail;

      if (changedProperty !== property) {
        return;
      }

      const normalizedValue = normalizeValue(newValue);

      setValueState((previousValue) =>
        previousValue === normalizedValue ? previousValue : normalizedValue,
      );
    };

    window.addEventListener(
      "NavigationStateChange",
      handleNavigationStateChange,
      { signal: controller.signal },
    );
    window.addEventListener("popstate", syncValueFromUrl, {
      signal: controller.signal,
    });

    return () => {
      controller.abort();
    };
  }, [property, syncValueFromUrl]);

  const setValue = useCallback<SetNavigationValue>(
    (newValue, options) => {
      const normalizedValue = normalizeValue(newValue);
      const newUrl = buildUrlFromValue(property, normalizedValue);
      const currentUrl = `${window.location.pathname}${window.location.search}${window.location.hash}`;

      if (newUrl === currentUrl) {
        return;
      }

      if (options?.replace) {
        window.history.replaceState(null, "", newUrl);
      } else {
        window.history.pushState(null, "", newUrl);
      }

      window.dispatchEvent(
        new CustomEvent<NavigationStateChangeDetail>("NavigationStateChange", {
          detail: {
            property,
            newValue: normalizedValue || null,
          },
        }),
      );
    },
    [property],
  );

  useLayoutEffect(() => {
    if (!normalizedDefaultValue) {
      return;
    }

    const urlValue = normalizeValue(
      new URLSearchParams(window.location.search).get(property),
    );

    if (urlValue) {
      return;
    }

    setValue(normalizedDefaultValue, { replace: true });
  }, [normalizedDefaultValue, property, setValue]);

  return [value, setValue] as const;
};
```

## Why This Uses `useLayoutEffect`

Use `useLayoutEffect` here because URL-to-state synchronization and listener registration should happen before paint. That avoids stale UI during mount and reduces the chance of missing navigation events dispatched immediately after render.

## Usage Rules

- Use this hook only in UI-layer React code.
- Pass the default value into the hook. Do not initialize state by calling `setValue` during mount.
- Use one query-string property per independently controlled state value.
- Keep stored values string-based. If a feature needs richer state, encode and decode it explicitly at the edge.
- Synced target-facing guidance belongs in `frontend.instructions.md` and should reference `.github/scaffolds/frontend/useStateNavigation.ts`.
