## Internal Template Source: API Service

Target path: `/packages/node/{name}-ui/src/services/base/api.service.ts`

This markdown file is an internal generator source for `rpr add template fetch_service`. It is not synced project instruction guidance.

Keep the first TypeScript block as the complete generated file. `src/rpr/commands/add.py` extracts the first matching fenced block for this template.

```ts
export type ApiError = {
  message: string;
  status: number;
  details?: unknown;
  response: Response;
};

declare const getToken: () => Promise<string | null>;
declare const globalErrorHandler: ((error: ApiError) => void) | undefined;

const buildUrl = (
  endpoint: string,
  params?: Record<string, unknown>,
): string => {
  // 1) Resolve full URL from base config
  // 2) Append query parameters if present
  return endpoint;
};

const createRequestInit = async (
  method: string,
  initHeaders?: HeadersInit,
  body?: BodyInit,
): Promise<RequestInit> => {
  const headers = new Headers({
    Accept: "application/json",
    ...initHeaders,
  });

  if (body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  if (!headers.has("Authorization")) {
    const token = await getToken();
    if (token) {
      headers.set("Authorization", `Bearer ${token}`);
    }
  }

  const requestInit: RequestInit = {
    method,
    headers,
  };

  if (body) {
    requestInit.body = body;
  }

  return requestInit;
};

const onApi401 = async (
  _response: Response,
  error: ApiError,
): Promise<never> => {
  // Handle 401 Unauthorized error
  return Promise.reject(error);
};

const handleError = async (response: Response): Promise<ApiError> => {
  let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
  let errorDetails = response.statusText;

  try {
    const contentType = response.headers.get("content-type");

    if (contentType && contentType.includes("application/json")) {
      const errorData = (await response.json()) as {
        message?: string;
        detail?: string;
      };

      errorMessage = errorData.message || errorData.detail || errorMessage;
      errorDetails = errorData;
    } else {
      const textError = await response.text();
      if (textError) {
        errorMessage = textError;
        errorDetails = textError;
      }
    }
  } catch (error: unknown) {
    console.error("Failed to parse default message", error);
  }

  return {
    message: errorMessage,
    status: response.status,
    details: errorDetails,
    response,
  };
};

const handleResponse = async <T>(response: Response): Promise<T> => {
  if (!response.ok) {
    const error = await handleError(response);
    if (response.status === 401) {
      return await onApi401(response, error);
    }

    // If you have a way to handle error, like a snackbar
    if (globalErrorHandler) {
      globalErrorHandler(error);
    }

    throw error;
  }

  if (response.status === 204) return undefined as T;

  const contentType = response.headers.get("content-type");
  if (contentType && contentType.includes("application/json")) {
    return await response.json();
  }

  if (contentType && contentType.includes("image/")) {
    const blob = await response.blob();
    return blob as unknown as T;
  }

  const text = await response.text();
  return text as unknown as T;
};

export const apiService = {
  async get<T>(
    endpoint: string,
    params?: Record<string, unknown>,
    headers?: HeadersInit,
  ): Promise<T> {
    const url = buildUrl(endpoint, params);
    const requestInit = await createRequestInit("GET", headers);
    const response = await fetch(url, requestInit);
    return handleResponse<T>(response);
  },

  async post<T>(
    endpoint: string,
    data?: unknown,
    headers?: HeadersInit,
  ): Promise<T> {
    const url = buildUrl(endpoint);
    const requestInit = await createRequestInit(
      "POST",
      headers,
      data ? JSON.stringify(data) : undefined,
    );
    const response = await fetch(url, requestInit);
    return handleResponse<T>(response);
  },

  async put<T>(
    endpoint: string,
    data?: unknown,
    headers?: HeadersInit,
  ): Promise<T> {
    const url = buildUrl(endpoint);
    const requestInit = await createRequestInit(
      "PUT",
      headers,
      data ? JSON.stringify(data) : undefined,
    );
    const response = await fetch(url, requestInit);
    return handleResponse<T>(response);
  },

  async delete<T>(endpoint: string, headers?: HeadersInit): Promise<T> {
    const url = buildUrl(endpoint);
    const requestInit = await createRequestInit("DELETE", headers);
    const response = await fetch(url, requestInit);
    return handleResponse<T>(response);
  },

  async patch<T>(
    endpoint: string,
    data?: unknown,
    headers?: HeadersInit,
  ): Promise<T> {
    const url = buildUrl(endpoint);
    const requestInit = await createRequestInit(
      "PATCH",
      headers,
      data ? JSON.stringify(data) : undefined,
    );
    const response = await fetch(url, requestInit);
    return handleResponse<T>(response);
  },
};
```

## What This Template Owns

- Shared request setup, including default headers and bearer-token injection
- Centralized API error parsing
- Standard response handling for JSON, text, blobs, and `204 No Content`
- Thin HTTP helpers that feature-specific services can reuse

## Integration Notes

- Replace `buildUrl` with the project's actual API base-URL logic.
- Provide a real `getToken()` implementation or wire authentication through the app's existing auth boundary.
- Connect `globalErrorHandler` to the project's notification or error-reporting path if one exists.
- Keep domain-specific services small. They should call `apiService`, not duplicate fetch behavior.
- Synced target-facing guidance belongs in `frontend.instructions.md` and should reference `.github/scaffolds/frontend/api.service.ts`.

## Usage

```ts
export const UserService = {
  getUsers: () => apiService.get<User[]>(`/users`),
};
```
