from __future__ import annotations

import re
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from rpr.cli import add_app
from rpr.context import RunContext
from rpr.generators.base import SyncConfig, interpolate
from rpr.templates.registry import TEMPLATES
from rpr.workspace import derive_variables

console = Console()


def _extract_code_blocks(markdown: str, language: str) -> list[str]:
    """Extract fenced code blocks from markdown matching the given language."""
    pattern = rf"```{language}\s*\n(.*?)```"
    matches = re.findall(pattern, markdown, re.DOTALL)
    if not matches:
        pattern = r"```\w*\s*\n(.*?)```"
        matches = re.findall(pattern, markdown, re.DOTALL)
    return matches


@add_app.command("template")
def template(
    template_id: Annotated[
        str | None,
        typer.Argument(help="Template ID to add (e.g., mapper_util, dto_util)."),
    ] = None,
    list_templates: Annotated[
        bool, typer.Option("--list", "-l", help="List all available templates.")
    ] = False,
    force: Annotated[
        bool,
        typer.Option(
            "--force", "-f", help="Overwrite existing files without prompting."
        ),
    ] = False,
    name: Annotated[
        str | None,
        typer.Option("--name", "-n", help="App name for variable interpolation."),
    ] = None,
    source: Annotated[
        str | None,
        typer.Option("--source", "-s", help="Path to the rules source directory."),
    ] = None,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Preview changes without writing.")
    ] = False,
) -> None:
    """Add a code template file to the current project."""
    ctx = RunContext(dry_run=dry_run, project_dir=Path.cwd())
    config_path = ctx.project_dir / ".rpr.yaml"
    config = SyncConfig.load(config_path)

    if name:
        variables = derive_variables(name)
    elif config.variables:
        variables = config.variables
    else:
        # For list command, we don't necessarily want to prompt
        if list_templates:
            variables = {}
        else:
            project_name = typer.prompt("Project name", default=ctx.project_dir.name)
            variables = derive_variables(project_name)

    if list_templates:
        console.print("\n[bold]Available templates:[/]\n")
        for tid, entry in TEMPLATES.items():
            console.print(f"  [bold cyan]{tid:<20}[/] {entry.description}")
            path_str = entry.target_path
            if variables:
                path_str = interpolate(path_str, variables)
            console.print(f"  {'':20} -> {path_str}")
        console.print()
        raise typer.Exit(0)

    if not template_id:
        template_id = typer.prompt("Template ID")

    if template_id not in TEMPLATES:
        console.print(f"[bold red]Error:[/] Unknown template: {template_id}")
        console.print("Run 'rpr add template --list' to see available templates.")
        raise typer.Exit(1)

    entry = TEMPLATES[template_id]

    source_dir = (
        Path(source).expanduser().resolve() if source else _find_source_dir(config)
    )
    if not source_dir:
        console.print(
            "[bold red]Error:[/] Cannot find rules source. Use --source or create .rpr.yaml"
        )
        raise typer.Exit(1)

    source_file = source_dir / entry.source_subdir / entry.source_filename
    if not source_file.exists():
        console.print(f"[bold red]Error:[/] Source file not found: {source_file}")
        raise typer.Exit(1)

    markdown = source_file.read_text()

    lang_hint = "python" if entry.language == "python" else "ts"
    code_blocks = _extract_code_blocks(markdown, lang_hint)

    if not code_blocks:
        console.print(f"[bold red]Error:[/] No code blocks found in {source_file}")
        raise typer.Exit(1)

    code = code_blocks[0].strip() + "\n"

    # Robust interpolation
    code = interpolate(code, variables)
    # Legacy support for older templates that might use these placeholders
    name_val = variables.get("name", "")
    name_underscore_val = variables.get("name_underscore", "")
    code = code.replace("your_app_domain", f"{name_underscore_val}_domain")
    code = code.replace("your-app-domain", f"{name_val}-domain")
    code = code.replace("my_app_domain", f"{name_underscore_val}_domain")
    code = code.replace("my-app-domain", f"{name_val}-domain")

    target_path_str = interpolate(entry.target_path, variables)
    target_path = ctx.project_dir / target_path_str

    if not dry_run and target_path.exists() and not force:
        console.print(f"[bold yellow]Warning:[/] File already exists: {target_path}")
        overwrite = typer.confirm("Overwrite?")
        if not overwrite:
            console.print("Skipped.")
            raise typer.Exit(0)

    console.print(f"\n[bold]Adding template:[/] {template_id}\n")
    ctx.write_file(target_path, code)

    console.print(f"\n[bold green]Done![/] Template written to {target_path}")


def _find_source_dir(config: SyncConfig) -> Path | None:
    """Try to find the source directory from SyncConfig or common locations."""
    if config.source:
        p = Path(config.source).expanduser().resolve()
        if p.exists():
            # If the source points to 'instructions', we should look at its parent
            # as templates are usually sibling directories to instructions.
            if p.name == "instructions" and (p.parent / "special_files").exists():
                return p.parent
            return p

    # Try relative to this file (development mode)
    # src/rpr/commands/add.py -> parent x 2 is src/rpr/ -> / scaffolds
    scaffold_root = Path(__file__).resolve().parent.parent / "scaffolds"
    if (scaffold_root / "special_files").exists():
        return scaffold_root

    common = Path.home() / "development" / "project-getting-started"
    if common.exists():
        return common

    return None
