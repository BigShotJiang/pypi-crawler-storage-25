from __future__ import annotations

from typing import Annotated

import typer
from rpr.cli import app
from rpr.ui.theme import SETTING_DEFINITIONS, THEMES, settings_manager, theme_manager
from rpr.ui.console import console, refresh_console
from rpr.ui.renderers import render_heading, render_info, render_success, render_table

settings_app = typer.Typer(help="Manage RPR settings and themes.")
app.add_typer(settings_app, name="settings")


def _render_settings_overview() -> None:
    rows = []
    for definition, value in settings_manager.describe_settings():
        choices = ", ".join(definition.choices) if definition.choices else "true, false"
        rows.append([definition.key, value, choices, definition.description])
    render_table("RPR Settings", ["Key", "Value", "Allowed", "Description"], rows)


def _set_setting_value(key: str, value: str) -> None:
    try:
        settings_manager.set_value(key, value)
    except KeyError:
        console.print(f"[error]Error:[/] Unknown setting: {key}")
        raise typer.Exit(1) from None
    except ValueError as exc:
        console.print(f"[error]Error:[/] {exc}")
        raise typer.Exit(1) from exc

    if key == "theme":
        refresh_console()
    render_success(
        f"Updated [bold]{key}[/] to [bold]{settings_manager.get_value(key)}[/]"
    )


@settings_app.callback(invoke_without_command=True)
def settings_root(ctx: typer.Context) -> None:
    """Inspect persisted RPR settings."""
    if ctx.invoked_subcommand is None:
        _render_settings_overview()


@settings_app.command("list")
def list_settings() -> None:
    """List all persisted settings."""
    _render_settings_overview()


@settings_app.command("get")
def get_setting(
    key: Annotated[str, typer.Argument(help="Setting key to inspect.")],
) -> None:
    """Read a single persisted setting."""
    if key not in SETTING_DEFINITIONS:
        console.print(f"[error]Error:[/] Unknown setting: {key}")
        raise typer.Exit(1)
    render_info(f"{key}: [bold]{settings_manager.get_value(key)}[/]")


@settings_app.command("set")
def set_setting(
    key: Annotated[str, typer.Argument(help="Setting key to update.")],
    value: Annotated[str, typer.Argument(help="New value for the setting.")],
) -> None:
    """Update a persisted setting."""
    _set_setting_value(key, value)


@settings_app.command("theme")
def set_theme(
    name: Annotated[
        str | None, typer.Argument(help="The name of the theme to use.")
    ] = None,
    list_themes: Annotated[
        bool, typer.Option("--list", "-l", help="List all available themes.")
    ] = False,
) -> None:
    """Get or set the terminal UI theme."""
    if list_themes:
        render_heading("Available Themes")
        current = theme_manager.current_theme_name
        for theme_name in THEMES:
            star = "[success]*[/success] " if theme_name == current else "  "
            console.print(f"{star}{theme_name}")
        return

    if name is None:
        render_info(f"Current theme: [bold]{theme_manager.current_theme_name}[/]")
        return

    try:
        settings_manager.set_value("theme", name)
    except ValueError as exc:
        console.print(f"[error]Error:[/] {exc}")
        raise typer.Exit(1) from exc

    refresh_console()
    render_success(f"Theme set to: [bold]{name}[/]")
