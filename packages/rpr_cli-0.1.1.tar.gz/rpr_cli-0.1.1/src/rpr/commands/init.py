from __future__ import annotations

from contextlib import chdir
import json
import re
import subprocess
import tomllib
from pathlib import Path
from typing import Annotated, Literal

import typer
from rich.console import Console

from rpr.cli import app
from rpr.context import RunContext
from rpr.generators.base import SyncConfig, load_rules
from rpr.generators.claude import generate_claude_rules
from rpr.generators.copilot import generate_copilot_rules
from rpr.generators.cursor import generate_cursor_rules
from rpr.generators.gemini import generate_gemini_rules
from rpr.workspace import ensure_npm_workspaces

console = Console()

NxState = Literal["new", "existing_non_nx", "already_nx"]
ScaffoldName = Literal["instructions", "domain", "api", "ui", "web", "storybook", "engine"]

_ALL_TARGETS = ["cursor", "copilot", "claude", "gemini"]
_TARGET_GENERATORS = {
    "cursor": generate_cursor_rules,
    "copilot": generate_copilot_rules,
    "claude": generate_claude_rules,
    "gemini": generate_gemini_rules,
}
_NX_BOOTSTRAP_ENV = {"NX_NO_CLOUD": "true"}
_ROOT_NODE_DEV_DEPENDENCIES = {
    "@eslint/js": "latest",
    "@nx/eslint": "latest",
    "@nx/eslint-plugin": "latest",
    "eslint": "latest",
    "eslint-plugin-import": "latest",
    "eslint-plugin-jsx-a11y": "latest",
    "eslint-plugin-react": "latest",
    "eslint-plugin-react-hooks": "latest",
    "globals": "latest",
    "prettier": "latest",
    "typescript-eslint": "latest",
}
_ROOT_NODE_SCRIPTS = {
    "format": "npx prettier --write .",
    "format:check": "npx prettier --check .",
    "lint": "npx nx run-many --target=lint --all",
    "lint:fix": "npx nx run-many --target=lint --all -- --fix",
    "typecheck": "npx nx run-many --target=typecheck --all",
}
_SCAFFOLD_DEPENDENCIES: dict[ScaffoldName, tuple[ScaffoldName, ...]] = {
    "instructions": (),
    "domain": (),
    "api": ("domain",),
    "ui": (),
    "web": ("ui",),
    "storybook": ("ui",),
    "engine": (),
}


# ---------------------------------------------------------------------------
# Detection helpers
# ---------------------------------------------------------------------------


def _detect_nx_state(project_dir: Path) -> NxState:
    """Classify the target directory as new, existing-non-NX, or already-NX."""
    if not project_dir.exists() or not any(project_dir.iterdir()):
        return "new"
    if (project_dir / "nx.json").exists() or (project_dir / "project.json").exists():
        return "already_nx"
    return "existing_non_nx"


def _detect_uv_state(project_dir: Path) -> bool:
    """Return True when the directory already has a UV-managed pyproject.toml."""
    pyproject = project_dir / "pyproject.toml"
    if not pyproject.exists():
        return False
    try:
        data = tomllib.loads(pyproject.read_text())
    except tomllib.TOMLDecodeError:
        return False
    tool = data.get("tool", {})
    return "uv" in tool


# ---------------------------------------------------------------------------
# Variable derivation
# ---------------------------------------------------------------------------


def _derive_variables(project_name: str) -> dict[str, str]:
    """Derive the four canonical token variants from the raw project name."""
    name_underscore = project_name.replace("-", "_")
    pascal = "".join(w.capitalize() for w in re.split(r"[-_]+", project_name) if w)
    return {
        "name": project_name,
        "name-of-app": project_name,
        "name_underscore": name_underscore,
        "NamePascal": pascal,
    }


def _normalize_scaffold_name(value: str) -> ScaffoldName:
    normalized = value.strip().lower()
    if normalized not in _SCAFFOLD_DEPENDENCIES:
        allowed = ", ".join(_SCAFFOLD_DEPENDENCIES)
        raise typer.BadParameter(
            f"Unknown scaffold '{value}'. Choose from: {allowed}."
        )
    return normalized  # type: ignore[return-value]


def _resolve_scaffolds(scaffolds: list[ScaffoldName] | None) -> list[ScaffoldName]:
    requested = scaffolds or ["instructions"]
    resolved: list[ScaffoldName] = []
    seen: set[ScaffoldName] = set()

    def visit(name: ScaffoldName) -> None:
        if name in seen:
            return
        seen.add(name)
        for dependency in _SCAFFOLD_DEPENDENCIES[name]:
            visit(dependency)
        resolved.append(name)

    for scaffold_name in requested:
        visit(scaffold_name)

    return resolved


def _run_requested_scaffolds(
    project_name: str,
    project_dir: Path,
    dry_run: bool,
    scaffolds: list[ScaffoldName],
    domain_migrations: bool,
) -> None:
    from rpr.commands.generate.api import api as generate_api
    from rpr.commands.generate.domain import domain as generate_domain
    from rpr.commands.generate.engine import engine as generate_engine
    from rpr.commands.generate.storybook import storybook as generate_storybook
    from rpr.commands.generate.ui import ui as generate_ui

    include_library = "ui" in scaffolds
    include_web = "web" in scaffolds

    if not scaffolds:
        return

    console.print(
        "\n[bold]Scaffolding requested project components[/]"
        f" ({', '.join(scaffolds)})\n"
    )
    with chdir(project_dir):
        scaffold_generators = {
            "domain": lambda: generate_domain(
                name=project_name,
                dry_run=dry_run,
                migrations=domain_migrations,
            ),
            "api": lambda: generate_api(name=project_name, dry_run=dry_run),
            "storybook": lambda: generate_storybook(dry_run=dry_run),
            "engine": lambda: generate_engine(name=project_name, dry_run=dry_run),
        }
        ui_handled = False
        for scaffold in scaffolds:
            if scaffold == "instructions":
                continue
            if scaffold in {"ui", "web"}:
                if ui_handled:
                    continue
                generate_ui(
                    name=project_name,
                    dry_run=dry_run,
                    include_library=include_library,
                    include_web=include_web,
                )
                ui_handled = True
                continue
            scaffold_generators[scaffold]()


# ---------------------------------------------------------------------------
# Package-bundled instruction templates
# ---------------------------------------------------------------------------


def _bundled_instructions_dir() -> Path:
    """Absolute path to the instruction templates bundled with the rpr package."""
    # src/rpr/commands/init.py  →  parent = commands/  →  parent = rpr/
    return Path(__file__).resolve().parent.parent / "scaffolds" / "instructions"


# ---------------------------------------------------------------------------
# AI instruction scaffolding
# ---------------------------------------------------------------------------


def _scaffold_ai_instructions(
    ctx: RunContext,
    project_dir: Path,
    variables: dict[str, str],
) -> None:
    instructions_dir = _bundled_instructions_dir()
    if not instructions_dir.exists():
        console.print(
            f"[bold yellow]Warning:[/] Bundled instructions not found at {instructions_dir}. "
            "Skipping AI instruction scaffolding."
        )
        return

    rules = load_rules(instructions_dir)
    if not rules:
        console.print(
            "[bold yellow]Warning:[/] No instruction rules found. Skipping scaffolding."
        )
        return

    console.print(f"\n[bold]Scaffolding AI instructions[/] ({len(rules)} rules)\n")
    for target in _ALL_TARGETS:
        console.print(f"  [bold]→[/] {target}")
        _TARGET_GENERATORS[target](rules, project_dir, variables, ctx)


# ---------------------------------------------------------------------------
# .rpr.yaml
# ---------------------------------------------------------------------------


def _write_rpr_yaml(
    ctx: RunContext,
    project_dir: Path,
    variables: dict[str, str],
) -> None:
    instructions_dir = _bundled_instructions_dir()
    config = SyncConfig(
        source=str(instructions_dir),
        targets=list(_ALL_TARGETS),
        include=[],
        exclude=[],
        variables=variables,
    )
    config_path = project_dir / ".rpr.yaml"

    if ctx.dry_run:
        import yaml

        console.print(f"\n[bold yellow][DRY RUN][/] Would write: {config_path}")
        preview = yaml.dump(
            {
                "source": config.source,
                "targets": config.targets,
                "include": config.include,
                "exclude": config.exclude,
                "variables": config.variables,
            },
            default_flow_style=False,
            sort_keys=False,
        )
        console.print(f"[dim]{'─' * 60}[/]")
        for i, line in enumerate(preview.splitlines(), 1):
            console.print(f"  [dim]{i:>4}[/] │ {line}")
        console.print(f"[dim]{'─' * 60}[/]")
        return

    config.save(config_path)
    console.print(f"[bold green]Created:[/] {config_path}")


# ---------------------------------------------------------------------------
# Root config files
# ---------------------------------------------------------------------------


def _write_nx_json(ctx: RunContext) -> None:
    content = """{
  "$schema": "./node_modules/nx/schemas/nx-schema.json",
    "neverConnectToCloud": true,
    "plugins": [
        {
            "plugin": "@nx/eslint/plugin",
            "options": {
                "targetName": "lint"
            }
        }
    ],
  "targetDefaults": {
    "build": {
      "dependsOn": ["^build"],
      "cache": true
    },
        "format": {
            "cache": true
        },
    "test": {
      "cache": true
    },
    "lint": {
      "cache": true
        },
        "typecheck": {
            "cache": true
    }
  },
  "defaultBase": "main"
}
"""
    ctx.write_file(ctx.project_dir / "nx.json", content)


def _write_root_pyproject(
    ctx: RunContext, project_name: str, python_version: str
) -> None:
    uv_require_version = _detect_uv_require_version()
    content = f"""[project]
name = "{project_name}"
version = "0.1.0"
description = "A monorepo combining NX and UV"
readme = "README.md"
requires-python = ">={python_version}"
dependencies = []

[tool.uv]
require-version = "{uv_require_version}"

[tool.uv.workspace]
members = []

[dependency-groups]
dev = [
    "pytest",
    "pytest-asyncio",
    "pytest-cov",
    "ipykernel",
    "pre-commit",
    "pyright",
    "ruff",
    "maturin",
]

[tool.ruff]
line-length = 88
target-version = "py{python_version.replace(".", "")}"
exclude = ["**/migrations/**"]

[tool.ruff.lint]
select = ["E", "F", "W", "I001"]
ignore = ["E501", "B008", "C901"]

[tool.ruff.lint.per-file-ignores]
"__init__.py" = ["F401"]
"tests/**/*.py" = ["F841"]

[tool.ruff.format]
quote-style = "double"
indent-style = "space"
line-ending = "lf"
skip-magic-trailing-comma = false

[tool.pytest.ini_options]
pythonpath = []
testpaths = []
"""
    ctx.update_file(ctx.project_dir / "pyproject.toml", content)


def _detect_uv_require_version() -> str:
    try:
        result = subprocess.run(
            ["uv", "--version"],
            capture_output=True,
            text=True,
            check=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return ">=0"

    match = re.search(r"(\d+\.\d+(?:\.\d+)?)", result.stdout)
    if not match:
        return ">=0"
    return f">={match.group(1)}"


def _write_root_package_json(ctx: RunContext, project_name: str) -> None:
    ensure_npm_workspaces(ctx, package_name=project_name)

    package_path = ctx.project_dir / "package.json"
    package = json.loads(package_path.read_text())
    package.setdefault("name", project_name)
    package["private"] = True

    scripts = package.setdefault("scripts", {})
    if not isinstance(scripts, dict):
        scripts = {}
        package["scripts"] = scripts
    scripts.update(_ROOT_NODE_SCRIPTS)

    dev_dependencies = package.setdefault("devDependencies", {})
    if not isinstance(dev_dependencies, dict):
        dev_dependencies = {}
        package["devDependencies"] = dev_dependencies

    for name, version in _ROOT_NODE_DEV_DEPENDENCIES.items():
        dev_dependencies.setdefault(name, version)

    ctx.update_file(package_path, json.dumps(package, indent=2) + "\n")


def _write_root_eslint_config(ctx: RunContext) -> None:
    content = """import js from \"@eslint/js\";
import nxPlugin from \"@nx/eslint-plugin\";
import globals from \"globals\";
import importPlugin from \"eslint-plugin-import\";
import jsxA11yPlugin from \"eslint-plugin-jsx-a11y\";
import reactPlugin from \"eslint-plugin-react\";
import reactHooksPlugin from \"eslint-plugin-react-hooks\";
import tseslint from \"typescript-eslint\";

export default [
    {
        ignores: [\"build/**\", \"coverage/**\", \"dist/**\", \"node_modules/**\", ".nx/**"],
    },
    js.configs.recommended,
    ...tseslint.configs.recommended,
    {
        files: [\"**/*.{js,jsx,ts,tsx}\"],
        plugins: {
            \"@nx\": nxPlugin,
            import: importPlugin,
            \"jsx-a11y\": jsxA11yPlugin,
            react: reactPlugin,
            \"react-hooks\": reactHooksPlugin,
        },
        languageOptions: {
            parser: tseslint.parser,
            parserOptions: {
                ecmaFeatures: {
                    jsx: true,
                },
                ecmaVersion: \"latest\",
                sourceType: \"module\",
            },
            globals: {
                ...globals.browser,
                ...globals.node,
            },
        },
        settings: {
            react: {
                version: \"detect\",
            },
        },
        rules: {
            \"@nx/enforce-module-boundaries\": [
                \"error\",
                {
                    enforceBuildableLibDependency: true,
                    allow: [],
                    depConstraints: [
                        {
                            sourceTag: \"*\",
                            onlyDependOnLibsWithTags: [\"*\"],
                        },
                    ],
                },
            ],
            \"react-hooks/exhaustive-deps\": \"warn\",
            \"react-hooks/rules-of-hooks\": \"error\",
            \"react/jsx-uses-react\": \"off\",
            \"react/react-in-jsx-scope\": \"off\",
        },
    },
];
"""
    ctx.write_file(ctx.project_dir / "eslint.config.mjs", content)


def _write_prettier_config(ctx: RunContext) -> None:
    content = """{
    \"singleQuote\": true,
    \"printWidth\": 100,
    \"semi\": true,
    \"tabWidth\": 2,
    \"trailingComma\": \"es5\"
}
"""
    ctx.write_file(ctx.project_dir / ".prettierrc", content)


def _write_prettierignore(ctx: RunContext) -> None:
    content = """build/
coverage/
dist/
node_modules/
.nx/
"""
    ctx.write_file(ctx.project_dir / ".prettierignore", content)


def _write_pre_commit_config(ctx: RunContext) -> None:
    content = """repos:
    - repo: https://github.com/pre-commit/pre-commit-hooks
        rev: v6.0.0
        hooks:
            - id: check-merge-conflict
            - id: end-of-file-fixer
            - id: trailing-whitespace
                args: [--markdown-linebreak-ext=md]
            - id: fix-byte-order-marker
            - id: mixed-line-ending
                args: [--fix=lf]
                exclude: \\.ipynb$
            - id: detect-private-key

    - repo: https://github.com/kynan/nbstripout
        rev: v0.8.2
        hooks:
            - id: nbstripout

    - repo: local
        hooks:
            - id: ruff-format
                name: Ruff format
                entry: uv run ruff format
                language: system
                types: [python]
                pass_filenames: false

            - id: ruff-lint
                name: Ruff lint
                entry: uv run ruff check --fix
                language: system
                types: [python]
                pass_filenames: false

            - id: prettier
                name: Prettier format
                entry: npx prettier --write --log-level=warn
                language: system
                types_or: [javascript, jsx, ts, tsx, json, css, scss, html, markdown]
                exclude: \\.ipynb$
                pass_filenames: true

            - id: eslint
                name: ESLint (NX)
                entry: npx nx run-many --target=lint --all --fix --exclude=engine
                language: system
                types_or: [javascript, jsx, ts, tsx]
                pass_filenames: false
"""
    ctx.write_file(ctx.project_dir / ".pre-commit-config.yaml", content)


def _write_tsconfig_base(ctx: RunContext) -> None:
    content = """{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "jsx": "react-jsx",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "baseUrl": ".",
    "paths": {}
  },
  "exclude": ["node_modules", "dist", "build"]
}
"""
    ctx.write_file(ctx.project_dir / "tsconfig.base.json", content)


def _write_gitignore(ctx: RunContext) -> None:
    content = """# Node
node_modules/
dist/
build/
.next/
*.tsbuildinfo

# Python
__pycache__/
*.py[cod]
*.egg-info/
.venv/
*.egg

# Rust
target/

# Environment
.env
.env.local
.env.*.local

# IDE
.idea/
.vscode/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# NX
.nx/

# UV
uv.lock
"""
    ctx.write_file(ctx.project_dir / ".gitignore", content)


def _write_env_example(ctx: RunContext) -> None:
    content = """# Database
DATABASE_URL=

# Auth
OAUTH_CLIENT_ID=
OAUTH_CLIENT_SECRET=

# Encryption
FERNET_KEY=

# API
API_BASE_URL=http://localhost:8000
"""
    ctx.write_file(ctx.project_dir / ".env.example", content)


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------


@app.command()
def init(
    project_name: Annotated[
        str | None, typer.Argument(help="Name of the project to create.")
    ] = None,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Preview changes without writing.")
    ] = False,
    python_version: Annotated[
        str, typer.Option("--python", help="Python version to use.")
    ] = "3.14",
    integrated: Annotated[
        bool, typer.Option("--integrated", help="Use NX integrated monorepo layout.")
    ] = False,
    scaffold: Annotated[
        list[str] | None,
        typer.Option(
            "--scaffold",
            help=(
                "Repeat to scaffold additional components: instructions, domain, "
                "api, ui, web, storybook, engine. Defaults to instructions only."
            ),
        ),
    ] = None,
    domain_migrations: Annotated[
        bool,
        typer.Option(
            "--domain-migrations",
            help=(
                "Scaffold Alembic migrations when the selected scaffolds include "
                "the domain package, directly or through a dependency such as api."
            ),
        ),
    ] = False,
) -> None:
    """Scaffold a complete NX + UV monorepo with AI instructions."""
    if not project_name:
        project_name = typer.prompt("Project name")

    selected_scaffolds = _resolve_scaffolds(
        [_normalize_scaffold_name(value) for value in scaffold or []]
    )
    if domain_migrations and "domain" not in selected_scaffolds:
        raise typer.BadParameter(
            "--domain-migrations requires a scaffold that generates the domain "
            "package, such as --scaffold domain or --scaffold api."
        )
    variables = _derive_variables(project_name)
    project_dir = Path.cwd() / project_name
    ctx = RunContext(dry_run=dry_run, project_dir=project_dir)

    console.print(f"\n[bold]Initializing RPR monorepo:[/] {project_name}\n")

    # ------------------------------------------------------------------
    # Step 1 – NX setup
    # ------------------------------------------------------------------
    nx_state = _detect_nx_state(project_dir)

    if nx_state == "already_nx":
        console.print("[bold yellow]Already an NX project.[/] Skipping NX setup.")
    elif nx_state == "new":
        nx_args = [
            f"--name={project_name}",
            "--preset=apps",
            "--nxCloud=never",
            "--interactive=false",
        ]
        if integrated:
            nx_args.append("--integrated")
        ctx.run_command(
            ["npx", "--yes", "create-nx-workspace@latest"] + nx_args,
            cwd=Path.cwd(),
            env=_NX_BOOTSTRAP_ENV,
        )
    else:  # existing_non_nx
        if not dry_run:
            console.print(
                f"[bold yellow]Warning:[/] Directory {project_dir} already exists."
            )
            if not typer.confirm("Continue with initialization in existing directory?"):
                raise typer.Exit(0)
        ctx.run_command(["git", "init"], cwd=project_dir)
        nx_cmd = [
            "npx",
            "--yes",
            "nx",
            "init",
            "--interactive=false",
            "--nxCloud=false",
        ]
        if integrated:
            nx_cmd.append("--integrated")
        ctx.run_command(nx_cmd, cwd=project_dir, env=_NX_BOOTSTRAP_ENV)

    # ------------------------------------------------------------------
    # Step 2 – UV setup
    # ------------------------------------------------------------------
    if _detect_uv_state(project_dir):
        console.print("[bold yellow]Already a UV project.[/] Skipping uv init.")
    else:
        ctx.run_command(
            [
                "uv",
                "init",
                "--no-readme",
                "--no-pin-python",
                "--python",
                python_version,
            ],
            cwd=project_dir,
        )

    # ------------------------------------------------------------------
    # Step 3 – Standard directories
    # ------------------------------------------------------------------
    ctx.ensure_dir(project_dir / "apps")
    ctx.ensure_dir(project_dir / "packages" / "node")
    ctx.ensure_dir(project_dir / "packages" / "python")

    # ------------------------------------------------------------------
    # Step 4 – Root config files
    # ------------------------------------------------------------------
    _write_nx_json(ctx)
    _write_root_pyproject(ctx, project_name, python_version)
    _write_root_package_json(ctx, project_name)
    _write_tsconfig_base(ctx)
    _write_root_eslint_config(ctx)
    _write_prettier_config(ctx)
    _write_prettierignore(ctx)
    _write_pre_commit_config(ctx)
    _write_gitignore(ctx)
    _write_env_example(ctx)

    # ------------------------------------------------------------------
    # Step 5 – AI instruction files
    # ------------------------------------------------------------------
    if "instructions" in selected_scaffolds:
        _scaffold_ai_instructions(ctx, project_dir, variables)

    # ------------------------------------------------------------------
    # Step 6 – .rpr.yaml (source path + variables block)
    # ------------------------------------------------------------------
    _write_rpr_yaml(ctx, project_dir, variables)

    # ------------------------------------------------------------------
    # Step 7 – Sync tooling dependencies
    # ------------------------------------------------------------------
    ctx.run_command(["npm", "install"], cwd=project_dir)

    # ------------------------------------------------------------------
    # Step 8 – Sync Python dependencies
    # ------------------------------------------------------------------
    ctx.run_command(["uv", "sync"], cwd=project_dir)

    # ------------------------------------------------------------------
    # Step 9 – Requested project scaffolds
    # ------------------------------------------------------------------
    _run_requested_scaffolds(
        project_name,
        project_dir,
        dry_run,
        selected_scaffolds,
        domain_migrations,
    )

    console.print(f"\n[bold green]Done![/] Project created at {project_dir}")
    console.print(f"  cd {project_name}")
    if len(selected_scaffolds) == 1 and selected_scaffolds[0] == "instructions":
        console.print(f"  rpr generate domain {project_name}")
