from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from rpr.cli import generate_app
from rpr.context import RunContext
from rpr.workspace import add_workspace_member

console = Console()


@generate_app.command()
def engine(
    name: Annotated[
        str | None, typer.Argument(help="App name (used as package prefix).")
    ] = None,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Preview changes without writing.")
    ] = False,
) -> None:
    """Scaffold a Rust + PyO3 engine package."""
    if not name:
        name = typer.prompt("App name")

    ctx = RunContext(dry_run=dry_run, project_dir=Path.cwd())
    engine_name = f"{name}-engine"
    engine_underscore = f"{name.replace('-', '_')}_engine"
    engine_root = ctx.project_dir / "packages" / "python" / engine_name

    console.print(f"\n[bold]Generating Rust/PyO3 engine:[/] {engine_name}\n")

    ctx.ensure_dir(engine_root / "src")

    _write_cargo_toml(ctx, engine_root, engine_name, engine_underscore)
    _write_lib_rs(ctx, engine_root / "src" / "lib.rs", engine_underscore)
    _write_engine_pyproject(ctx, engine_root, engine_name, engine_underscore)
    _write_pyi_stub(ctx, engine_root / f"{engine_underscore}.pyi", engine_underscore)
    _write_engine_project_json(ctx, engine_root, engine_name)

    add_workspace_member(ctx, f"packages/python/{engine_name}")
    ctx.preview_dependencies(
        manager="uv",
        target=f"packages/python/{engine_name}",
    )

    if not dry_run:
        ctx.run_command(["uv", "sync"], cwd=ctx.project_dir)

    console.print(f"\n[bold green]Done![/] Rust engine created at {engine_root}")
    console.print(f"  Build with: npx nx engine:build {engine_name}")


def _write_cargo_toml(
    ctx: RunContext, engine_root: Path, engine_name: str, engine_underscore: str
) -> None:
    content = f"""[package]
name = "{engine_name}"
version = "0.1.0"
edition = "2021"

[lib]
name = "{engine_underscore}"
crate-type = ["cdylib"]

[dependencies]
pyo3 = {{ version = "0.21", features = ["extension-module"] }}
"""
    ctx.write_file(engine_root / "Cargo.toml", content)


def _write_lib_rs(ctx: RunContext, path: Path, engine_underscore: str) -> None:
    content = f"""use pyo3::prelude::*;

#[pyfunction]
fn hello() -> PyResult<String> {{
    Ok("hello from {engine_underscore}".to_string())
}}

#[pymodule]
fn {engine_underscore}(m: &Bound<'_, PyModule>) -> PyResult<()> {{
    m.add_function(wrap_pyfunction!(hello, m)?)?;
    Ok(())
}}
"""
    ctx.write_file(path, content)


def _write_engine_pyproject(
    ctx: RunContext, engine_root: Path, engine_name: str, engine_underscore: str
) -> None:
    content = f"""[build-system]
requires = ["maturin>=1.8.2,<2.0"]
build-backend = "maturin"

[project]
name = "{engine_name}"
version = "0.1.0"
requires-python = ">=3.12"

[tool.maturin]
features = ["pyo3/extension-module"]
module-name = "{engine_underscore}"
"""
    ctx.write_file(engine_root / "pyproject.toml", content)


def _write_pyi_stub(ctx: RunContext, path: Path, engine_underscore: str) -> None:
    content = """def hello() -> str: ...
"""
    ctx.write_file(path, content)


def _write_engine_project_json(
    ctx: RunContext, engine_root: Path, engine_name: str
) -> None:
    project = {
        "name": engine_name,
        "root": f"packages/python/{engine_name}",
        "targets": {
            "engine:build": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "uv run maturin develop",
                    "cwd": f"packages/python/{engine_name}",
                },
            },
            "engine:lint": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "cargo clippy --all-targets --all-features -- -D warnings",
                    "cwd": f"packages/python/{engine_name}",
                },
            },
            "engine:format": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "cargo fmt --check",
                    "cwd": f"packages/python/{engine_name}",
                },
            },
        },
    }
    ctx.write_file(engine_root / "project.json", json.dumps(project, indent=2) + "\n")
