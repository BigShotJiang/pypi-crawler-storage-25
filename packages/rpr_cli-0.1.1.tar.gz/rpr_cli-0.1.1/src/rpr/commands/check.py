from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer
from rpr.application.checks import collect_check_report, serialize_check_results
from rpr.cli import app
from rpr.ui.console import console
from rpr.ui.renderers import render_heading, render_status_row


@app.command()
def check(
    group: Annotated[
        str | None,
        typer.Option(
            "--group",
            help="Run only a specific group: workspace, instructions, packages.",
        ),
    ] = None,
    as_json: Annotated[
        bool, typer.Option("--json", help="Emit machine-readable JSON output.")
    ] = False,
) -> None:
    """Inspect the current project and report setup status."""
    project_dir = Path.cwd()
    report = collect_check_report(project_dir, group=group)

    if as_json:
        typer.echo(json.dumps(serialize_check_results(report.results)))
        if any(not result.status for result in report.results):
            raise typer.Exit(1)
        return

    render_heading(f"rpr check — project: {report.project_name}")

    current_group = None
    for result in report.results:
        if result.group != current_group:
            current_group = result.group
            console.print(f"[heading]{current_group}[/]")

        icon_char = "✓" if result.status else "✗"
        render_status_row(
            icon_char, result.area, str(result.path), result.status, result.suggestion
        )

    console.print()

    if any(not result.status for result in report.results):
        raise typer.Exit(1)
