from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from rpr.cli import app
from rpr.map.architecture import assess_architecture
from rpr.map.chains import build_diagnostic_chains, build_representative_chains
from rpr.map.classifier import classify
from rpr.map.coverage import build_coverage_map
from rpr.map.dependencies import build_external_dependencies
from rpr.map.extractor import analyze_project, build_raw_import_inventory
from rpr.map.output import write_map
from rpr.map.responsibility import build_responsibility_summaries
from rpr.map.topology import build_directory_topology
from rpr.ui.console import console


@app.command()
def map(
    root: Annotated[
        Path,
        typer.Option("--root", help="Directory to analyze."),
    ] = Path("."),
    output: Annotated[
        Path,
        typer.Option("--output", help="Where to write the map.", dir_okay=False),
    ] = Path("code-map.md"),
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Preview actions without writing files.")
    ] = False,
    details: Annotated[
        bool,
        typer.Option(
            "--details", help="Show all files and individual node edges in the diagram."
        ),
    ] = False,
    focus: Annotated[
        str | None,
        typer.Option("--focus", help="Repo-relative directory to drill down into."),
    ] = None,
) -> None:
    """Generate a structured code map of a project."""
    resolved_root = root.resolve()

    if not resolved_root.exists() or not resolved_root.is_dir():
        console.print(
            f"[bold red]Error:[/] --root '{root}' does not exist or is not a directory."
        )
        raise typer.Exit(1)

    if focus is not None:
        focus = focus.replace("\\", "/").strip("/")

    graph = analyze_project(resolved_root)
    classified = classify(graph)
    topology = build_directory_topology(graph, resolved_root)
    assessment = assess_architecture(graph, topology)
    chains = build_representative_chains(graph, topology, assessment)
    diagnostic_chains = (
        build_diagnostic_chains(graph, topology, assessment) if details else None
    )

    raw_imports = build_raw_import_inventory(graph)
    ext_deps = build_external_dependencies(graph, raw_imports, topology)
    responsibilities = build_responsibility_summaries(topology, classified, resolved_root)
    coverage = build_coverage_map(graph, classified, topology)

    if focus is not None and focus not in topology.nodes:
        console.print(
            f"[bold red]Error:[/] --focus '{focus}' is not a directory in the analyzed project."
        )
        raise typer.Exit(1)

    if dry_run:
        console.print(f"Root to scan : {resolved_root}", soft_wrap=True)
        console.print(f"Output path  : {output}", soft_wrap=True)
        write_map(
            graph,
            classified,
            output,
            resolved_root,
            dry_run=True,
            details=details,
            topology=topology,
            assessment=assessment,
            chains=chains,
            focus=focus,
            diagnostic_chains=diagnostic_chains,
            ext_deps=ext_deps,
            responsibilities=responsibilities,
            coverage=coverage,
        )
        console.print("No files written (dry-run mode).", soft_wrap=True)
        raise typer.Exit(0)

    write_map(
        graph,
        classified,
        output,
        resolved_root,
        details=details,
        topology=topology,
        assessment=assessment,
        chains=chains,
        focus=focus,
        diagnostic_chains=diagnostic_chains,
        ext_deps=ext_deps,
        responsibilities=responsibilities,
        coverage=coverage,
    )
