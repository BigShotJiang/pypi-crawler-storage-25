from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from rpr.cli import sync_app
from rpr.context import RunContext
from rpr.generators.base import SyncConfig, load_rules
from rpr.generators.claude import generate_claude_rules
from rpr.generators.copilot import generate_copilot_rules
from rpr.generators.cursor import generate_cursor_rules
from rpr.generators.gemini import generate_gemini_rules
from rpr.workspace import derive_variables

console = Console()

TARGET_GENERATORS = {
    "cursor": generate_cursor_rules,
    "copilot": generate_copilot_rules,
    "claude": generate_claude_rules,
    "gemini": generate_gemini_rules,
}


@sync_app.command("rules")
def rules(
    target: Annotated[
        str | None,
        typer.Option(
            "--target", "-t", help="Sync only one target: cursor, copilot, or claude."
        ),
    ] = None,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Preview changes without writing.")
    ] = False,
) -> None:
    """Sync AI instructions to Cursor, Copilot, and Claude Code."""
    ctx = RunContext(dry_run=dry_run, project_dir=Path.cwd())
    config_path = ctx.project_dir / ".rpr.yaml"

    config = SyncConfig.load(config_path)

    if not config.source:
        default_source = Path(__file__).parent.parent / "scaffolds" / "instructions"
        if default_source.exists():
            config.source = str(default_source)
        else:
            config.source = typer.prompt(
                "Path to rules source directory",
                default=str(default_source),
            )
            if not dry_run:
                config.save(config_path)
                console.print(f"[bold green]Saved:[/] {config_path}")

    source_dir = Path(config.source).expanduser().resolve()
    if not source_dir.exists():
        console.print(f"[bold red]Error:[/] Source directory not found: {source_dir}")
        raise typer.Exit(1)

    if not config.variables:
        console.print("[bold yellow]Warning:[/] No variables found in .rpr.yaml.")
        project_name = typer.prompt("Project name", default=ctx.project_dir.name)
        config.variables = derive_variables(project_name)
        if not dry_run:
            config.save(config_path)
            console.print(f"[bold green]Updated variables in:[/] {config_path}")

    all_rules = load_rules(source_dir)
    if not all_rules:
        # Fallback to source_dir if no "instructions" subdir exists
        all_rules = load_rules(source_dir)

    filtered = config.filter_rules(all_rules)

    if not filtered:
        console.print("[bold yellow]Warning:[/] No rules found matching the config.")
        raise typer.Exit(0)

    console.print(f"\n[bold]Syncing {len(filtered)} rules[/]\n")

    targets = [target] if target else config.targets

    for t in targets:
        if t not in TARGET_GENERATORS:
            console.print(
                f"[bold red]Error:[/] Unknown target: {t}. Valid: cursor, copilot, claude, gemini"
            )
            continue

        console.print(f"[bold]Target:[/] {t}")
        TARGET_GENERATORS[t](filtered, ctx.project_dir, config.variables, ctx)

    console.print(f"\n[bold green]Done![/] Rules synced for: {', '.join(targets)}")
