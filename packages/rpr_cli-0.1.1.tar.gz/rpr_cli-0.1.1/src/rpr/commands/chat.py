from __future__ import annotations

import asyncio
from typing import Annotated

import typer

from rpr.agent.bootstrap import resolve_agent_client
from rpr.agent.client import AgentClient
from rpr.application.chat_service import ChatCommandService
from rpr.cli import app
from rpr.context import RunContext
from rpr.ui.theme import settings_manager


def _get_agent_client(provider: str | None, model: str | None) -> AgentClient:
    return resolve_agent_client(provider, model)


@app.command()
def chat(
    provider: Annotated[
        str | None, typer.Option(help="Override the AI provider to use.")
    ] = None,
    model: Annotated[
        str | None, typer.Option(help="Override the model to use.")
    ] = None,
    approval_mode: Annotated[
        str | None,
        typer.Option(
            help="Override the approval mode for this session.", case_sensitive=False
        ),
    ] = None,
) -> None:
    """Start an interactive chat session with the AI agent."""
    try:
        asyncio.run(
            ChatCommandService.instance().run(
                provider=provider,
                model=model,
                approval_mode_override=approval_mode,
                client_factory=_get_agent_client,
                context_factory=RunContext,
                settings=settings_manager,
            )
        )
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
