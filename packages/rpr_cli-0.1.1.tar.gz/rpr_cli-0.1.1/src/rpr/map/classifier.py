from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from rpr.map.graph import DependencyGraph
from rpr.map.walker import SourceFile

# ---------------------------------------------------------------------------
# Output type
# ---------------------------------------------------------------------------

LayerLabel = str  # one of the labels in _LAYER_MATCHERS or "unknown"


@dataclass(frozen=True)
class ClassifiedNode:
    file: SourceFile
    layer: LayerLabel
    is_leaf: bool  # True when out-degree within project == 0
    in_degree: int  # number of project files that import this file
    out_degree: int  # number of project files this file imports


# ---------------------------------------------------------------------------
# Layer predicates  (SRP: each function tests exactly one condition)
# ---------------------------------------------------------------------------


def _is_test(path: Path) -> bool:
    parts = {p.lower() for p in path.parts}
    name = path.name.lower()
    stem = path.stem.lower()
    return (
        "tests" in parts
        or "__tests__" in parts
        or stem.startswith("test_")
        or name.endswith(".test.ts")
        or name.endswith(".test.js")
    )


def _is_entry_point(path: Path) -> bool:
    parts = {p.lower() for p in path.parts}
    stem = path.stem.lower()
    return stem in {"cli", "main", "app", "__main__", "server"} or "apps" in parts


def _is_application(path: Path) -> bool:
    parts = {p.lower() for p in path.parts}
    return bool(parts & {"services", "workflows", "use_cases", "handlers"})


def _is_entity(path: Path) -> bool:
    parts = {p.lower() for p in path.parts}
    return "entities" in parts


def _is_dto(path: Path) -> bool:
    parts = {p.lower() for p in path.parts}
    return bool(parts & {"dtos", "schemas", "models"})


def _is_repository(path: Path) -> bool:
    parts = {p.lower() for p in path.parts}
    return bool(parts & {"repos", "repositories"})


def _is_infrastructure(path: Path) -> bool:
    parts = {p.lower() for p in path.parts}
    return bool(parts & {"config", "db", "orm", "migrations"})


def _is_ui_component(path: Path) -> bool:
    parts = {p.lower() for p in path.parts}
    return bool(parts & {"components", "pages", "screens", "views"})


def _is_ui_util(path: Path) -> bool:
    parts = {p.lower() for p in path.parts}
    name = path.name.lower()
    return (
        bool(parts & {"hooks", "utils"})
        or name.endswith(".hook.ts")
        or name.endswith(".util.ts")
    )


# ---------------------------------------------------------------------------
# Priority-ordered taxonomy (OCP: extend by appending, never modifying)
# ---------------------------------------------------------------------------

_LAYER_MATCHERS: list[tuple[LayerLabel, Callable[[Path], bool]]] = [
    ("test", _is_test),
    ("entry_point", _is_entry_point),
    ("application", _is_application),
    ("entity", _is_entity),
    ("dto", _is_dto),
    ("repository", _is_repository),
    ("infrastructure", _is_infrastructure),
    ("ui_component", _is_ui_component),
    ("ui_util", _is_ui_util),
]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _match_layer(path: Path) -> LayerLabel:
    """Return the first matching layer label, or 'unknown'."""
    for label, predicate in _LAYER_MATCHERS:
        if predicate(path):
            return label
    return "unknown"


def _compute_degrees(
    rel_key: str,
    edges: dict[str, list[str]],
    reverse_edges: dict[str, list[str]],
) -> tuple[int, int]:
    out_degree = len(edges.get(rel_key, []))
    in_degree = len(reverse_edges.get(rel_key, []))
    return in_degree, out_degree


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def classify(graph: DependencyGraph) -> list[ClassifiedNode]:
    """Assign a DDD architectural layer to every node in *graph*.

    Classification is deterministic and backend-agnostic: the same
    ``DependencyGraph`` structure always produces the same result regardless of
    whether it was built by the Rust engine or the Python fallback.

    Returns one :class:`ClassifiedNode` per node in ``graph.nodes``, in the
    same order.
    """
    results: list[ClassifiedNode] = []

    for node in graph.nodes:
        rel_key = node.rel_path.as_posix()
        layer = _match_layer(node.rel_path)
        in_degree, out_degree = _compute_degrees(
            rel_key, graph.edges, graph.reverse_edges
        )

        # Topology fallback: promote truly isolated entry-points that have no
        # known path pattern (unknown) but also have no importers and do have
        # at least one dependency they drive.
        if layer == "unknown" and in_degree == 0 and out_degree > 0:
            layer = "entry_point"

        results.append(
            ClassifiedNode(
                file=node,
                layer=layer,
                is_leaf=out_degree == 0,
                in_degree=in_degree,
                out_degree=out_degree,
            )
        )

    return results
