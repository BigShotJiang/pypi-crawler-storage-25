from __future__ import annotations

from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Callable, Literal

from rpr.map.walker import Language, SourceFile

# ---------------------------------------------------------------------------
# Domain aggregate
# ---------------------------------------------------------------------------


@dataclass
class DependencyGraph:
    nodes: list[SourceFile]
    edges: dict[str, list[str]]  # rel_path → [dep rel_path, ...]
    reverse_edges: dict[str, list[str]]  # rel_path → [importer rel_path, ...]
    cycles: list[list[str]]
    backend: Literal["rust", "python-fallback"]


# ---------------------------------------------------------------------------
# Private language resolvers (one per language — SRP)
# All share the same signature so they can be stored in _RESOLVERS (OCP).
# ---------------------------------------------------------------------------


def _resolve_python(
    raw: str,
    importer: SourceFile,
    known: dict[str, SourceFile],
) -> str | None:
    """Resolve a raw Python import string to a known rel_path key, or None."""
    if not raw:
        return None

    if raw.startswith("."):
        # Relative import: count leading dots to determine traversal depth.
        # "." means same package, ".." means one level up, etc.
        dots = len(raw) - len(raw.lstrip("."))
        remainder = raw.lstrip(".")

        base = PurePosixPath(str(importer.rel_path.parent))
        for _ in range(dots - 1):
            base = base.parent

        if remainder:
            candidate_base = base / PurePosixPath(remainder.replace(".", "/"))
        else:
            candidate_base = base

        for suffix in (f"{candidate_base}.py", f"{candidate_base}/__init__.py"):
            if suffix in known:
                return suffix
        return None

    # Absolute-dotted module (e.g. "rpr.context", "src.utils.helpers").
    # Single-segment names with no dots are stdlib/external — drop them.
    if "." not in raw:
        return None

    # Convert dotted form to path and suffix-match against known keys.
    path_form = raw.replace(".", "/")
    for suffix in (f"{path_form}.py", f"{path_form}/__init__.py"):
        for key in known:
            if key == suffix or key.endswith(f"/{suffix}"):
                return key
    return None


def _normalize_posix(path: str) -> str:
    """Resolve `.` and `..` components in a posix path string."""
    parts: list[str] = []
    for part in path.split("/"):
        if part == "..":
            if parts:
                parts.pop()
        elif part and part != ".":
            parts.append(part)
    return "/".join(parts)


def _resolve_ts_js(
    raw: str,
    importer: SourceFile,
    known: dict[str, SourceFile],
) -> str | None:
    """Resolve a TS/JS import specifier to a known rel_path key, or None."""
    if not raw.startswith("./") and not raw.startswith("../"):
        return None  # External package — drop.

    # Strip any existing extension so probing below works uniformly.
    base_raw = raw
    for ext in (".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"):
        if raw.endswith(ext):
            base_raw = raw[: -len(ext)]
            break

    importer_dir = str(importer.rel_path.parent).replace("\\", "/")
    raw_posix = f"{importer_dir}/{base_raw}" if importer_dir != "." else base_raw
    candidate_base = _normalize_posix(raw_posix)

    probes = [
        f"{candidate_base}.ts",
        f"{candidate_base}.tsx",
        f"{candidate_base}.js",
        f"{candidate_base}.jsx",
        f"{candidate_base}.mjs",
        f"{candidate_base}.cjs",
        f"{candidate_base}/index.ts",
        f"{candidate_base}/index.tsx",
        f"{candidate_base}/index.js",
        f"{candidate_base}/index.jsx",
    ]
    for probe in probes:
        if probe in known:
            return probe
    return None


def _resolve_rust(
    raw: str,
    importer: SourceFile,
    known: dict[str, SourceFile],
) -> str | None:
    """Resolve a raw Rust use/mod string to a known rel_path key, or None."""
    if not raw:
        return None

    # extern crate / std / super / self — always external or non-file.
    if raw.startswith("extern::") or raw.startswith("std::"):
        return None
    if raw.startswith("super::") or raw.startswith("self::"):
        return None

    # mod declaration: bare name, no "::", resolved adjacent to importer.
    if "::" not in raw:
        importer_dir = str(importer.rel_path.parent)
        prefix = "" if importer_dir == "." else f"{importer_dir}/"
        for probe in (f"{prefix}{raw}.rs", f"{prefix}{raw}/mod.rs"):
            if probe in known:
                return probe
        return None

    # use crate::X::Y — strip "crate::" prefix.
    path = raw.removeprefix("crate::")
    # Drop glob / brace suffixes (e.g. "::*", "::{Foo, Bar}").
    if path.endswith("::*"):
        path = path[:-3]
    brace = path.find("::{")
    if brace != -1:
        path = path[:brace]

    path_form = path.replace("::", "/")
    for suffix in (f"{path_form}.rs", f"{path_form}/mod.rs"):
        for key in known:
            if key == suffix or key.endswith(f"/{suffix}"):
                return key
    return None


def _resolve_cpp(
    raw: str,
    importer: SourceFile,
    known: dict[str, SourceFile],
) -> str | None:
    """Resolve a C++ #include string to a known rel_path key, or None."""
    if not raw:
        return None

    # Angle-bracket includes are system/external — drop.
    if raw.startswith("<") and raw.endswith(">"):
        return None

    # Strip surrounding quotes from quoted includes.
    header = raw.strip('"')

    # 1. Resolve relative to the importer's directory.
    importer_dir = PurePosixPath(str(importer.rel_path.parent))
    candidate = str((importer_dir / header).as_posix())
    if candidate.startswith("./"):
        candidate = candidate[2:]
    if candidate in known:
        return candidate

    # 2. Fallback: search for "include/<header>" within known paths.
    include_suffix = f"include/{header}"
    for key in known:
        if key == include_suffix or key.endswith(f"/{include_suffix}"):
            return key

    return None


# Dispatch dict: adding a new language requires only a new entry here (OCP).
_RESOLVERS: dict[
    Language, Callable[[str, SourceFile, dict[str, SourceFile]], str | None]
] = {
    "python": _resolve_python,
    "typescript": _resolve_ts_js,
    "javascript": _resolve_ts_js,
    "rust": _resolve_rust,
    "cpp": _resolve_cpp,
}


# ---------------------------------------------------------------------------
# Graph construction helpers
# ---------------------------------------------------------------------------


def _build_reverse_edges(edges: dict[str, list[str]]) -> dict[str, list[str]]:
    reverse: dict[str, list[str]] = {}
    for src, deps in edges.items():
        for dep in deps:
            reverse.setdefault(dep, []).append(src)
    # Sort for determinism.
    return {k: sorted(v) for k, v in reverse.items()}


def _detect_cycles(edges: dict[str, list[str]]) -> list[list[str]]:
    """Iterative DFS with white/gray/black coloring — no recursion."""
    WHITE, GRAY, BLACK = 0, 1, 2
    all_nodes = set(edges.keys()) | {dep for deps in edges.values() for dep in deps}
    color: dict[str, int] = {n: WHITE for n in all_nodes}

    found: list[list[str]] = []
    seen_canonical: set[tuple[str, ...]] = set()

    for start in sorted(all_nodes):
        if color[start] != WHITE:
            continue

        path_stack: list[str] = [start]
        dfs_stack: list[tuple[str, int, list[str]]] = [(start, 0, edges.get(start, []))]
        color[start] = GRAY

        while dfs_stack:
            node, idx, neighbors = dfs_stack[-1]

            if idx < len(neighbors):
                dfs_stack[-1] = (node, idx + 1, neighbors)
                neighbor = neighbors[idx]

                if color.get(neighbor, WHITE) == GRAY:
                    # Back edge — reconstruct cycle from path_stack.
                    cycle_start = path_stack.index(neighbor)
                    cycle = path_stack[cycle_start:] + [neighbor]
                    canonical = _canonical_cycle(cycle)
                    if canonical not in seen_canonical:
                        seen_canonical.add(canonical)
                        found.append(cycle)

                elif color.get(neighbor, WHITE) == WHITE:
                    color[neighbor] = GRAY
                    path_stack.append(neighbor)
                    dfs_stack.append((neighbor, 0, edges.get(neighbor, [])))
            else:
                dfs_stack.pop()
                path_stack.pop()
                color[node] = BLACK

    return found


def _canonical_cycle(cycle: list[str]) -> tuple[str, ...]:
    """Return a rotation of the cycle starting at the lexicographically smallest node."""
    body = cycle[:-1]  # drop the closing duplicate
    min_idx = body.index(min(body))
    rotated = body[min_idx:] + body[:min_idx]
    return tuple(rotated)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def build_graph(
    files: list[SourceFile],
    imports_by_file: dict[str, list[str]],
) -> DependencyGraph:
    """Build a dependency graph from discovered files and their raw imports.

    Args:
        files: All source files discovered in the project.
        imports_by_file: Maps each file's rel_path string to the raw import
            strings extracted from that file.

    Returns:
        A fully populated DependencyGraph with backend="python-fallback".
    """
    known: dict[str, SourceFile] = {
        str(f.rel_path).replace("\\", "/"): f for f in files
    }

    edges: dict[str, list[str]] = {}
    for f in files:
        key = str(f.rel_path).replace("\\", "/")
        resolver = _RESOLVERS[f.language]
        resolved: set[str] = set()
        for raw in imports_by_file.get(key, []):
            target = resolver(raw, f, known)
            if target is not None and target != key:
                resolved.add(target)
        edges[key] = sorted(resolved)

    reverse_edges = _build_reverse_edges(edges)
    cycles = _detect_cycles(edges)

    return DependencyGraph(
        nodes=files,
        edges=edges,
        reverse_edges=reverse_edges,
        cycles=cycles,
        backend="python-fallback",
    )
