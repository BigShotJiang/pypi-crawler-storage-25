from __future__ import annotations

from collections import deque
from dataclasses import dataclass

from rpr.map.architecture import ArchitectureAssessment
from rpr.map.graph import DependencyGraph
from rpr.map.topology import DirectoryTopology

# ---------------------------------------------------------------------------
# Tunable caps
# ---------------------------------------------------------------------------

_MAX_CHAINS_PER_ENTRY: int = 3
_MAX_TOTAL_CHAINS: int = 15
_MAX_CHAIN_LENGTH: int = 10


# ---------------------------------------------------------------------------
# Value objects
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RepresentativeEdgeExample:
    """A concrete file pair that substantiates an aggregated directory edge."""

    source_file: str
    target_file: str
    source_directory: str
    target_directory: str


@dataclass(frozen=True)
class RepresentativeChain:
    """An ordered file path from an entry toward a leaf (or truncated)."""

    files: tuple[str, ...]
    directories_crossed: tuple[str, ...]
    edge_examples: tuple[RepresentativeEdgeExample, ...]
    reason: str
    truncated: bool
    truncation_note: str  # "" when not truncated
    coupling_score: int = 0  # sum of directory edge support counts along this path


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _posix_parent(path: str) -> str:
    """Return the parent directory of a POSIX path string.

    "api/routes/user.py" -> "api/routes"
    "main.py"            -> ""
    ""                   -> ""
    """
    idx = path.rfind("/")
    return path[:idx] if idx != -1 else ""


def _is_init_file(path: str) -> bool:
    """Return True for package glue files that should be deprioritized."""
    basename = path.rsplit("/", 1)[-1] if "/" in path else path
    return basename in ("__init__.py", "index.ts", "index.tsx", "index.js", "mod.rs")


def _directories_for_chain(files: tuple[str, ...]) -> tuple[str, ...]:
    """Return unique parent directories in traversal order."""
    seen: set[str] = set()
    result: list[str] = []
    for f in files:
        d = _posix_parent(f)
        if d not in seen:
            seen.add(d)
            result.append(d)
    return tuple(result)


def _build_edge_examples(
    files: tuple[str, ...],
    topology: DirectoryTopology,
) -> tuple[RepresentativeEdgeExample, ...]:
    """Build one example per directory boundary crossing in the chain.

    Reuses topology representatives when available, falls back to the
    chain's own consecutive file pair.
    """
    examples: list[RepresentativeEdgeExample] = []
    seen_dir_pairs: set[tuple[str, str]] = set()
    for i in range(len(files) - 1):
        src_dir = _posix_parent(files[i])
        tgt_dir = _posix_parent(files[i + 1])
        if src_dir == tgt_dir:
            continue
        pair = (src_dir, tgt_dir)
        if pair in seen_dir_pairs:
            continue
        seen_dir_pairs.add(pair)
        topo_edge = topology.edges.get(pair)
        if topo_edge and topo_edge.representatives:
            src_file, tgt_file = topo_edge.representatives[0]
        else:
            src_file, tgt_file = files[i], files[i + 1]
        examples.append(
            RepresentativeEdgeExample(
                source_file=src_file,
                target_file=tgt_file,
                source_directory=src_dir,
                target_directory=tgt_dir,
            )
        )
    return tuple(examples)


def _bfs_to_leaf(
    start: str,
    edges: dict[str, list[str]],
    leaf_set: set[str],
    cycle_files: set[str],
) -> tuple[tuple[str, ...], bool, str]:
    """BFS from *start* toward the nearest leaf file.

    Returns ``(path, truncated, truncation_note)``.  The visited set prevents
    re-entering nodes, which implicitly handles cycles without special logic.
    """
    visited: set[str] = {start}
    queue: deque[tuple[str, list[str]]] = deque([(start, [start])])

    best_partial: list[str] = [start]

    while queue:
        current, path = queue.popleft()
        best_partial = path

        if current in leaf_set and current != start:
            return tuple(path), False, ""

        if len(path) >= _MAX_CHAIN_LENGTH:
            note = f"chain length exceeded {_MAX_CHAIN_LENGTH} files"
            if path_cycles := set(path) & cycle_files:
                note = f"cycle detected involving {sorted(path_cycles)[0]}"
            return tuple(path), True, note

        neighbors = edges.get(current, [])
        sorted_neighbors = sorted(neighbors, key=lambda f: (_is_init_file(f), f))
        for neighbor in sorted_neighbors:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [neighbor]))

    # Queue exhausted — no leaf reachable
    note = "no leaf file reachable from this entry"
    if len(best_partial) > 1 and (path_cycles := set(best_partial) & cycle_files):
        note = f"cycle detected involving {sorted(path_cycles)[0]}"
    return tuple(best_partial), True, note


def _select_chains(
    entry_files: list[str],
    graph: DependencyGraph,
    leaf_set: set[str],
) -> list[tuple[tuple[str, ...], bool, str, str]]:
    """Return raw chain tuples: (files, truncated, truncation_note, reason).

    Groups entries by depth-1 parent directory, caps per-entry-area and
    globally, and deduplicates by file set.
    """
    cycle_files: set[str] = set()
    for cycle in graph.cycles:
        cycle_files.update(cycle)

    # Group entry files by top-level (depth-1) parent directory
    entry_by_top_dir: dict[str, list[str]] = {}
    for ef in entry_files:
        top = _posix_parent(ef).split("/")[0]
        entry_by_top_dir.setdefault(top, []).append(ef)

    raw: list[tuple[tuple[str, ...], bool, str, str]] = []
    seen_file_sets: set[frozenset[str]] = set()
    chains_per_dir: dict[str, int] = {}

    for top_dir in sorted(entry_by_top_dir):
        entries = sorted(entry_by_top_dir[top_dir], key=lambda f: (_is_init_file(f), f))
        for ef in entries:
            if chains_per_dir.get(top_dir, 0) >= _MAX_CHAINS_PER_ENTRY:
                break
            if len(raw) >= _MAX_TOTAL_CHAINS:
                break

            path, truncated, note = _bfs_to_leaf(ef, graph.edges, leaf_set, cycle_files)

            if len(path) < 2:
                continue

            key = frozenset(path)
            if key in seen_file_sets:
                continue
            seen_file_sets.add(key)

            if truncated:
                reason = f"truncated path from entry {ef}"
            else:
                reason = f"shortest path from entry {ef} to leaf {path[-1]}"

            raw.append((path, truncated, note, reason))
            chains_per_dir[top_dir] = chains_per_dir.get(top_dir, 0) + 1

    return raw


def _score_chain(files: tuple[str, ...], topology: DirectoryTopology) -> int:
    """Score a chain by the sum of directory edge support counts it crosses.

    Higher support means more file edges back the same directory dependency,
    so higher-scored chains represent more-traversed architectural paths.
    """
    score = 0
    seen: set[tuple[str, str]] = set()
    for i in range(len(files) - 1):
        src_dir = _posix_parent(files[i])
        tgt_dir = _posix_parent(files[i + 1])
        if src_dir == tgt_dir:
            continue
        pair = (src_dir, tgt_dir)
        if pair in seen:
            continue
        seen.add(pair)
        edge = topology.edges.get(pair)
        if edge:
            score += edge.support
    return score


def _build_chains_impl(
    graph: DependencyGraph,
    topology: DirectoryTopology,
    assessment: ArchitectureAssessment,
) -> list[RepresentativeChain]:
    """Core chain building: BFS discovery with coupling scores attached.

    Returns chains in BFS discovery order (shortest paths first).
    """
    entry_files = sorted(assessment.entry_files)

    # Fallback for fully-cyclic or entry-less graphs: pick one representative
    # file per top-level directory from those that have outgoing edges.
    if not entry_files:
        candidates: dict[str, str] = {}
        for node in sorted(graph.nodes, key=lambda n: n.rel_path.as_posix()):
            posix = node.rel_path.as_posix()
            if not graph.edges.get(posix):
                continue
            top = _posix_parent(posix).split("/")[0]
            if top not in candidates:
                candidates[top] = posix
        entry_files = sorted(candidates.values())

    leaf_set = set(assessment.leaf_files)
    raw_chains = _select_chains(entry_files, graph, leaf_set)

    result: list[RepresentativeChain] = []
    for files, truncated, truncation_note, reason in raw_chains:
        directories = _directories_for_chain(files)
        edge_examples = _build_edge_examples(files, topology)
        score = _score_chain(files, topology)
        result.append(
            RepresentativeChain(
                files=files,
                directories_crossed=directories,
                edge_examples=edge_examples,
                reason=reason,
                truncated=truncated,
                truncation_note=truncation_note,
                coupling_score=score,
            )
        )
    return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_representative_chains(
    graph: DependencyGraph,
    topology: DirectoryTopology,
    assessment: ArchitectureAssessment,
) -> list[RepresentativeChain]:
    """Extract coupling-ranked representative dependency chains.

    Returns chains sorted by coupling significance (sum of directory edge
    support counts) highest first.  Higher-ranked chains expose the most
    architecturally traversed paths.

    When the assessment finds no entry files (e.g. a fully cyclic graph),
    falls back to one file per top-level directory that has outgoing edges.
    """
    chains = _build_chains_impl(graph, topology, assessment)
    # Stable sort by coupling_score descending preserves determinism for ties
    return sorted(chains, key=lambda c: -c.coupling_score)


def build_diagnostic_chains(
    graph: DependencyGraph,
    topology: DirectoryTopology,
    assessment: ArchitectureAssessment,
) -> list[RepresentativeChain]:
    """Extract shortest-path chains in BFS discovery order.

    Returns the same chains as ``build_representative_chains`` but ordered
    by BFS traversal (shortest paths first) rather than coupling score.
    Useful for validating graph traversal correctness and resolver behavior.
    """
    return _build_chains_impl(graph, topology, assessment)
