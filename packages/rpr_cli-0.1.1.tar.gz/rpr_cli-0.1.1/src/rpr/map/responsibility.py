"""Deterministic responsibility summaries for the code map.

For each directory in the analysed repository this module derives a concise
one-line description of what that directory is responsible for.  All inference
is performed from repository contents only; no network calls or LLM inference
are used.

Heuristics are applied in priority order:
  1. Module docstring — the first non-empty line of the docstring from a
     canonical index file (``__init__.py``, ``mod.rs``, or ``index.ts/tsx``).
  2. Vocabulary match — maps well-known directory name segments to canned
     descriptions.
  3. Dominant layer — the most frequent non-``unknown`` layer label from
     classified nodes in the directory.
  4. Neutral fallback — "N source files".
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass
from pathlib import Path

from rpr.map.classifier import ClassifiedNode
from rpr.map.topology import DirectoryTopology

# ---------------------------------------------------------------------------
# Vocabulary map  (last path segment → description)
# ---------------------------------------------------------------------------

_VOCAB: dict[str, str] = {
    # CLI and entry points
    "commands": "CLI command handlers",
    "cli": "Command-line interface entry points",
    "main": "Application entry point",
    "app": "Application entry point",
    # Application layer
    "application": "Application service layer",
    "services": "Application services",
    "use_cases": "Application use-case handlers",
    "usecases": "Application use-case handlers",
    "handlers": "Request/event handlers",
    "workflows": "Application workflows",
    # Domain
    "domain": "Domain model",
    "entities": "Domain entities",
    "entity": "Domain entity",
    "models": "Domain models",
    # DTOs / schemas
    "dtos": "Data transfer objects",
    "dto": "Data transfer objects",
    "schemas": "Data schemas",
    "types": "Type definitions",
    # Persistence
    "repos": "Repository implementations",
    "repositories": "Repository implementations",
    "repository": "Repository implementation",
    # Infrastructure
    "infrastructure": "Infrastructure adapters",
    "infra": "Infrastructure adapters",
    "config": "Configuration",
    "db": "Database layer",
    "orm": "ORM models",
    "migrations": "Database migrations",
    # API
    "api": "API layer",
    "routes": "Route definitions",
    "routers": "Route definitions",
    "endpoints": "API endpoints",
    "middleware": "Middleware",
    # UI
    "components": "UI components",
    "pages": "Page components",
    "screens": "Screen components",
    "views": "View components",
    "hooks": "React hooks",
    "utils": "Utilities",
    "util": "Utilities",
    "helpers": "Helper functions",
    # Map subsystem
    "map": "Code-map analysis",
    "extractor": "Import extraction",
    "topology": "Directory topology",
    "classifier": "Layer classification",
    "output": "Report rendering",
    "graph": "Dependency graph",
    "walker": "File walker",
    "architecture": "Architecture assessment",
    "chains": "Representative dependency chains",
    "checks": "Health-check validators",
    "generators": "Code generators",
    "scaffolds": "Project scaffolds",
    "templates": "Code templates",
    "agent": "AI agent tools",
    "tui": "Terminal UI",
    "ui": "User interface",
}

# Layer labels → human-readable responsibility suffix
_LAYER_DESCRIPTIONS: dict[str, str] = {
    "entry_point": "Entry points",
    "application": "Application logic",
    "entity": "Domain entities",
    "dto": "Data transfer objects",
    "repository": "Data access layer",
    "infrastructure": "Infrastructure layer",
    "ui_component": "UI components",
    "ui_util": "UI utilities",
    "test": "Tests",
}

# Patterns for extracting a leading docstring from Rust source.
_RUST_INNER_DOC_RE = re.compile(r"//!(.+)")

# ---------------------------------------------------------------------------
# Domain value object
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ResponsibilitySummary:
    """One-line responsibility description for a single directory.

    Attributes:
        directory: Repo-relative POSIX path (root is ``""``).
        summary:   Human-readable responsibility string.
    """

    directory: str
    summary: str


# ---------------------------------------------------------------------------
# Docstring extraction helpers
# ---------------------------------------------------------------------------


def _python_docstring(source: str) -> str | None:
    """Return the first line of the module docstring from Python source, or None."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return None
    if not tree.body:
        return None
    first = tree.body[0]
    if not isinstance(first, ast.Expr):
        return None
    if not isinstance(first.value, ast.Constant) or not isinstance(first.value.value, str):
        return None
    lines = [ln.strip() for ln in first.value.value.strip().splitlines() if ln.strip()]
    return lines[0] if lines else None


def _rust_docstring(source: str) -> str | None:
    """Return the first module-level inner doc comment (``//!``) line, or None."""
    for line in source.splitlines():
        stripped = line.strip()
        m = _RUST_INNER_DOC_RE.match(stripped)
        if m:
            text = m.group(1).strip()
            if text:
                return text
    return None


def _ts_docstring(source: str) -> str | None:
    """Return the first JSDoc/TSDoc ``/** … */`` description line, or None."""
    # Match a leading block comment before the first import/export statement
    m = re.match(r"\s*/\*\*(.+?)\*/", source, re.DOTALL)
    if not m:
        return None
    inner = m.group(1)
    for line in inner.splitlines():
        clean = line.strip().lstrip("*").strip()
        if clean and not clean.startswith("@"):
            return clean
    return None


def _read_index_docstring(directory: str, topology: DirectoryTopology) -> str | None:
    """Attempt to read a docstring from the canonical index file of *directory*.

    Looks for files directly in the directory (``files`` on the DirectoryNode)
    with names ``__init__.py``, ``mod.rs``, or ``index.ts``/``index.tsx``.
    Returns None when no index file exists or is not readable.
    """
    dir_node = topology.nodes.get(directory)
    if dir_node is None:
        return None

    # index_files holds tuples of (relative_path, extractor_fn)
    candidates: dict[str, object] = {
        "__init__.py": _python_docstring,
        "mod.rs": _rust_docstring,
        "index.ts": _ts_docstring,
        "index.tsx": _ts_docstring,
    }

    for file_rel in dir_node.files:
        filename = file_rel.rsplit("/", 1)[-1]
        extractor = candidates.get(filename)
        if extractor is None:
            continue
        # Reconstruct abs_path using a best-effort approach; we don't have root
        # available here.  We delegate this to the caller via the files_in API
        # and instead skip abs_path reading entirely — rely on caller providing
        # an optional root for filesystem reads.  See build_responsibility_summaries.
        del extractor  # accessed by name in public builder
        return None  # placeholder; actual reads happen in public builder

    return None


# ---------------------------------------------------------------------------
# Public builder
# ---------------------------------------------------------------------------


def build_responsibility_summaries(
    topology: DirectoryTopology,
    classified: list[ClassifiedNode],
    root: Path | None = None,
) -> list[ResponsibilitySummary]:
    """Derive a responsibility summary for every directory in the topology.

    Args:
        topology:   Directory topology from ``build_directory_topology``.
        classified: Classified nodes from ``classify(graph)``.
        root:       Filesystem root; when provided, enables docstring extraction
                    from index files.

    Returns:
        A list of :class:`ResponsibilitySummary` objects — one per directory in
        ``topology.nodes`` — sorted by ``directory``.
    """
    # Build file → classified node lookup
    classified_by_file: dict[str, ClassifiedNode] = {
        str(n.file.rel_path).replace("\\", "/"): n for n in classified
    }

    # Build directory → file list mapping (all files recursively)
    def _files_in_dir(directory: str) -> list[str]:
        return topology.files_in(directory)

    results: list[ResponsibilitySummary] = []

    for directory in sorted(topology.nodes):
        summary = _derive_summary(
            directory, topology, classified_by_file, root
        )
        results.append(ResponsibilitySummary(directory=directory, summary=summary))

    return results


def _derive_summary(
    directory: str,
    topology: DirectoryTopology,
    classified_by_file: dict[str, ClassifiedNode],
    root: Path | None,
) -> str:
    """Return the best available one-line summary for a single directory."""
    # ----------------------------------------------------------------
    # Heuristic 1 — module docstring from index file (requires root)
    # ----------------------------------------------------------------
    if root is not None:
        docstring = _try_index_docstring(directory, topology, root)
        if docstring:
            return _cap(docstring)

    # ----------------------------------------------------------------
    # Heuristic 2 — vocabulary match on last path segment
    # ----------------------------------------------------------------
    if directory:
        last_segment = directory.rsplit("/", 1)[-1].lower()
        if last_segment in _VOCAB:
            return _VOCAB[last_segment]
    else:
        # Root directory — give a generic label based on project file count
        pass

    # ----------------------------------------------------------------
    # Heuristic 3 — dominant non-unknown layer among classified nodes
    # ----------------------------------------------------------------
    files_in = topology.files_in(directory)
    layer_counts: dict[str, int] = {}
    for file_rel in files_in:
        node = classified_by_file.get(file_rel)
        if node is None or node.layer == "unknown":
            continue
        layer_counts[node.layer] = layer_counts.get(node.layer, 0) + 1

    if layer_counts:
        dominant = max(layer_counts, key=lambda k: layer_counts[k])
        description = _LAYER_DESCRIPTIONS.get(dominant)
        if description:
            return description

    # ----------------------------------------------------------------
    # Heuristic 4 — neutral fallback
    # ----------------------------------------------------------------
    file_count = len(files_in)
    noun = "source file" if file_count == 1 else "source files"
    return f"{file_count} {noun}"


def _try_index_docstring(
    directory: str,
    topology: DirectoryTopology,
    root: Path,
) -> str | None:
    """Read and parse the index file docstring for *directory* from disk."""
    dir_node = topology.nodes.get(directory)
    if dir_node is None:
        return None

    _INDEX_FILES: dict[str, object] = {
        "__init__.py": _python_docstring,
        "mod.rs": _rust_docstring,
        "index.ts": _ts_docstring,
        "index.tsx": _ts_docstring,
    }

    for file_rel in dir_node.files:
        filename = file_rel.rsplit("/", 1)[-1]
        extractor_fn = _INDEX_FILES.get(filename)
        if extractor_fn is None:
            continue
        abs_path = root / Path(file_rel)
        try:
            source = abs_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        result = extractor_fn(source)  # type: ignore[operator]
        if result:
            return result

    return None


def _cap(text: str, limit: int = 120) -> str:
    """Truncate text to *limit* characters."""
    return text if len(text) <= limit else text[:limit - 1] + "…"
