"""Analysis bridge — Rust-first project dependency extraction.

Primary API
-----------
``analyze_project(root)`` is the single public entry-point consumed by the
``rpr map`` command.  It returns a fully-resolved ``DependencyGraph`` domain
object, delegating the expensive crawl/parse/resolve work to the compiled Rust
extension when available and falling back to the pure-Python pipeline
otherwise.

Fallback extraction helpers
----------------------------
``extract_imports`` / ``extract_imports_batch`` parse raw import strings from
source files using the standard library (``ast`` for Python) and regular
expressions (TypeScript, JavaScript, Rust, C++).  These helpers power the
Python compatibility path and remain available for callers that need them
directly.
"""

from __future__ import annotations

import ast
import re
import warnings
from pathlib import Path
from typing import Callable

from rpr.map.graph import DependencyGraph, build_graph
from rpr.map.walker import Language, SourceFile, walk

try:
    import rpr_parser

    _RUST_AVAILABLE = True
except ImportError:
    _RUST_AVAILABLE = False

# ---------------------------------------------------------------------------
# Type alias for per-language extraction functions (LSP: uniform signature)
# ---------------------------------------------------------------------------

_ExtractFn = Callable[[str], list[str]]

# ---------------------------------------------------------------------------
# Private per-language extractors (SRP: one concern each)
# ---------------------------------------------------------------------------


def _extract_python(source: str) -> list[str]:
    """Extract raw import strings from Python source using ``ast``."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    results: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                results.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            dots = "." * (node.level or 0)
            module = node.module or ""
            results.append(dots + module)
    return results


# Patterns compiled once at import time for efficiency.
_TS_JS_PATTERNS = (
    # import ... from 'X' / "X"
    re.compile(r"""import\s+.*?from\s+['"]([^'"]+)['"]""", re.DOTALL),
    # require('X') / require("X")
    re.compile(r"""require\s*\(\s*['"]([^'"]+)['"]\s*\)"""),
    # import('X') — dynamic
    re.compile(r"""import\s*\(\s*['"]([^'"]+)['"]\s*\)"""),
)


def _extract_ts_js(source: str) -> list[str]:
    """Extract raw import specifiers from TypeScript / JavaScript source."""
    results: list[str] = []
    for pattern in _TS_JS_PATTERNS:
        results.extend(pattern.findall(source))
    return results


_RUST_USE = re.compile(r"use\s+([\w:]+(?:\s+as\s+\w+)?)\s*;")
_RUST_MOD = re.compile(r"mod\s+(\w+)\s*;")
_RUST_EXTERN = re.compile(r"extern\s+crate\s+(\w+)\s*;")


def _extract_rust(source: str) -> list[str]:
    """Extract raw import/module strings from Rust source."""
    results: list[str] = []

    for match in _RUST_USE.finditer(source):
        # Drop the alias part: "std::io as io" → "std::io"
        path = match.group(1).split(" as ")[0].strip()
        results.append(path)

    results.extend(_RUST_MOD.findall(source))
    results.extend(_RUST_EXTERN.findall(source))

    return results


_CPP_QUOTED = re.compile(r'#include\s+"([^"]+)"')
_CPP_ANGLE = re.compile(r"#include\s+<([^>]+)>")


def _extract_cpp(source: str) -> list[str]:
    """Extract raw include strings from C++ source.

    Angle-bracket includes (system headers) are emitted without the ``<>``
    delimiters; the graph resolver will drop them as external.
    """
    results: list[str] = _CPP_QUOTED.findall(source)
    results.extend(_CPP_ANGLE.findall(source))
    return results


# Dispatch dict — adding a new language requires only a new entry here (OCP).
_EXTRACTORS: dict[Language, _ExtractFn] = {
    "python": _extract_python,
    "typescript": _extract_ts_js,
    "javascript": _extract_ts_js,
    "rust": _extract_rust,
    "cpp": _extract_cpp,
}

# ---------------------------------------------------------------------------
# Public extraction API
# ---------------------------------------------------------------------------


def extract_imports(file: SourceFile) -> list[str]:
    """Extract raw import strings from a single ``SourceFile``.

    Returns an empty list for unsupported languages.  Returns an empty list
    and emits a ``UserWarning`` when the file cannot be read.
    """
    extractor = _EXTRACTORS.get(file.language)
    if extractor is None:
        return []

    try:
        source = file.abs_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        warnings.warn(f"Cannot read {file.rel_path} — skipping", stacklevel=2)
        return []

    return extractor(source)


def extract_imports_batch(
    files: list[SourceFile],
) -> dict[str, list[str]]:
    """Extract raw imports for every file; returns ``{rel_path: [import, ...]}``."""
    return {str(f.rel_path).replace("\\", "/"): extract_imports(f) for f in files}


def build_raw_import_inventory(graph: DependencyGraph) -> dict[str, list[str]]:
    """Return raw (unresolved) import strings for every file in *graph*.

    This is a convenience wrapper around :func:`extract_imports_batch` that
    accepts an already-constructed :class:`~rpr.map.graph.DependencyGraph` and
    returns the same ``{rel_path: [import, ...]}`` mapping.  The result includes
    *all* imports — both those that were resolved to in-repo edges and those
    that remain unresolved (i.e., external packages or unreadable paths).

    Callers that need only external imports should subtract the resolved edges
    stored in ``graph.edges`` from this inventory.
    """
    return extract_imports_batch(graph.nodes)


# ---------------------------------------------------------------------------
# Private path implementations
# ---------------------------------------------------------------------------


def _rust_path(root: Path) -> DependencyGraph:
    """Delegate the full analysis to the compiled Rust extension."""
    payload = rpr_parser.build_dependency_graph(str(root))
    nodes = [
        SourceFile(
            abs_path=Path(n["abs_path"]),
            rel_path=Path(n["rel_path"]),
            language=n["language"],
        )
        for n in payload["nodes"]
    ]
    return DependencyGraph(
        nodes=nodes,
        edges=payload["edges"],
        reverse_edges=payload["reverse_edges"],
        cycles=payload["cycles"],
        backend="rust",
    )


def _python_path(root: Path) -> DependencyGraph:
    """Pure-Python compatibility pipeline: walk → extract → build graph."""
    files = walk(root)
    imports_by_file = extract_imports_batch(files)
    return build_graph(files, imports_by_file)


# ---------------------------------------------------------------------------
# Primary public API
# ---------------------------------------------------------------------------


def analyze_project(root: Path) -> DependencyGraph:
    """Crawl *root* and return a fully-resolved ``DependencyGraph``.

    Delegates to the Rust engine when ``rpr_parser`` is importable; falls back
    to the Python-only pipeline otherwise.  The returned graph's ``backend``
    field indicates which path was taken.
    """
    if _RUST_AVAILABLE:
        return _rust_path(root)
    return _python_path(root)
