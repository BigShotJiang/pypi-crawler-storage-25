"""Structural test coverage evidence for the code map.

This module determines which production modules have test evidence by examining
the resolved dependency graph and the classified-node layer labels.  Coverage
is reported as a *structural* measure — it reflects whether tests exist that
import the module, not whether individual lines are exercised.

Two evidence strengths are defined:

``"strong"``
    A classified test node (``layer == "test"``) has a direct graph edge
    pointing to the production file.  This is reliable because it reflects an
    explicit import relationship recorded in the resolved dependency graph.

``"fallback"``
    A test file's stem matches ``test_<production_stem>`` and that stem maps
    uniquely to exactly one production file.  This is weaker because it relies
    on a naming convention and does not verify an actual import.

``"none"``
    No test evidence was found for the module.

Coverage is rolled up to the directory level: a directory's evidence strength
is the strongest evidence found among its files.

Note:  Inline Rust ``#[cfg(test)]`` blocks and external coverage reports (e.g.,
       ``coverage.xml``) are out of scope for this slice.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from rpr.map.classifier import ClassifiedNode
from rpr.map.graph import DependencyGraph
from rpr.map.topology import DirectoryTopology

# ---------------------------------------------------------------------------
# Domain value objects
# ---------------------------------------------------------------------------

EvidenceStrength = Literal["strong", "fallback", "none"]

_STRENGTH_RANK: dict[EvidenceStrength, int] = {"strong": 2, "fallback": 1, "none": 0}


@dataclass(frozen=True)
class CoverageRecord:
    """Test-coverage evidence for a single production directory.

    Attributes:
        module:       Repo-relative POSIX path of the production directory
                      (root is ``""``).
        evidence:     How the coverage was detected.
        test_files:   Sorted rel-paths of test files that provide the evidence.
    """

    module: str
    evidence: EvidenceStrength
    test_files: tuple[str, ...]


# ---------------------------------------------------------------------------
# Public builder
# ---------------------------------------------------------------------------


def build_coverage_map(
    graph: DependencyGraph,
    classified: list[ClassifiedNode],
    topology: DirectoryTopology,
) -> list[CoverageRecord]:
    """Compute per-directory structural test-coverage evidence.

    Args:
        graph:      The resolved dependency graph (provides edge data).
        classified: Classified nodes (provides layer labels and file identities).
        topology:   Directory topology (used to map files to directories and to
                    enumerate production directories).

    Returns:
        A list of :class:`CoverageRecord` objects — one per production
        directory that contains at least one non-test classified node — sorted
        by ``module``.  Test-only directories and empty directories are
        excluded.
    """
    # ----------------------------------------------------------------
    # Partition nodes into test nodes and production nodes
    # ----------------------------------------------------------------
    test_nodes: list[ClassifiedNode] = []
    prod_nodes: list[ClassifiedNode] = []

    for node in classified:
        if node.layer == "test":
            test_nodes.append(node)
        else:
            prod_nodes.append(node)

    # Build fast lookups
    prod_by_file: dict[str, ClassifiedNode] = {
        str(n.file.rel_path).replace("\\", "/"): n for n in prod_nodes
    }

    # ----------------------------------------------------------------
    # Strong evidence — explicit import edges from test to production
    # ----------------------------------------------------------------
    # strong_evidence[prod_file] = set(test_files)
    strong_evidence: dict[str, set[str]] = {}

    for test_node in test_nodes:
        test_rel = str(test_node.file.rel_path).replace("\\", "/")
        for dep in graph.edges.get(test_rel, []):
            if dep in prod_by_file:
                strong_evidence.setdefault(dep, set()).add(test_rel)

    # ----------------------------------------------------------------
    # Fallback evidence — test_<stem> naming convention
    # ----------------------------------------------------------------
    # Build stem → list[prod_file] mapping so we can check for uniqueness.
    prod_by_stem: dict[str, list[str]] = {}
    for prod_rel in prod_by_file:
        stem = _file_stem(prod_rel)
        prod_by_stem.setdefault(stem, []).append(prod_rel)

    # fallback_evidence[prod_file] = set(test_files)
    fallback_evidence: dict[str, set[str]] = {}

    for test_node in test_nodes:
        test_rel = str(test_node.file.rel_path).replace("\\", "/")
        test_stem = _file_stem(test_rel)
        if not test_stem.startswith("test_"):
            continue
        target_stem = test_stem[len("test_"):]
        candidates = prod_by_stem.get(target_stem, [])
        if len(candidates) != 1:
            # Ambiguous or no match — skip to avoid false positives
            continue
        prod_rel = candidates[0]
        # Only record fallback if no strong evidence already exists
        if prod_rel not in strong_evidence:
            fallback_evidence.setdefault(prod_rel, set()).add(test_rel)

    # ----------------------------------------------------------------
    # Roll up to directory level
    # ----------------------------------------------------------------
    # Map file → directory using topology
    file_to_dir: dict[str, str] = {}
    for dir_node in topology.nodes.values():
        for file_rel in dir_node.files:
            file_to_dir[file_rel] = dir_node.path

    # Determine which directories contain production files
    prod_dirs: set[str] = set()
    for prod_rel in prod_by_file:
        directory = file_to_dir.get(prod_rel, "")
        prod_dirs.add(directory)

    # Accumulate best evidence per directory
    dir_evidence: dict[str, EvidenceStrength] = {d: "none" for d in prod_dirs}
    dir_tests: dict[str, set[str]] = {d: set() for d in prod_dirs}

    for prod_rel, test_files in strong_evidence.items():
        directory = file_to_dir.get(prod_rel, "")
        if directory in prod_dirs:
            if _STRENGTH_RANK["strong"] > _STRENGTH_RANK[dir_evidence[directory]]:
                dir_evidence[directory] = "strong"
            dir_tests[directory].update(test_files)

    for prod_rel, test_files in fallback_evidence.items():
        directory = file_to_dir.get(prod_rel, "")
        if directory in prod_dirs:
            if _STRENGTH_RANK["fallback"] > _STRENGTH_RANK[dir_evidence[directory]]:
                dir_evidence[directory] = "fallback"
            dir_tests[directory].update(test_files)

    # ----------------------------------------------------------------
    # Build result list
    # ----------------------------------------------------------------
    result: list[CoverageRecord] = []
    for directory in sorted(prod_dirs):
        result.append(
            CoverageRecord(
                module=directory,
                evidence=dir_evidence[directory],
                test_files=tuple(sorted(dir_tests[directory])),
            )
        )
    return result


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _file_stem(rel_path: str) -> str:
    """Return the filename stem (no extension, no directory) of a rel_path."""
    filename = rel_path.rsplit("/", 1)[-1]
    return filename.rsplit(".", 1)[0]
