"""External dependency summarisation for the code map.

For each analysed directory, this module identifies which third-party (or
system) package identifiers appeared in raw import strings but were *not*
resolved to in-repo edges by the dependency-graph builder.  The result is a
per-directory inventory of external package names that developers can review
without consulting raw source files.

The ``DependencyGraph`` contract is intentionally left unchanged — this module
is a sibling analysis artifact, not an extension of the resolved graph.
"""

from __future__ import annotations

from dataclasses import dataclass

from rpr.map.graph import DependencyGraph
from rpr.map.topology import DirectoryTopology

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Standard Rust crate roots that are not third-party packages.
_RUST_STDLIB_ROOTS: frozenset[str] = frozenset(
    {
        "std",
        "core",
        "alloc",
        "proc_macro",
        "test",
        "self",
        "super",
        "crate",
    }
)

# Max number of packages listed per directory in the report.
_MAX_PACKAGES_PER_DIR = 15


# ---------------------------------------------------------------------------
# Domain value object
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ExternalDependencySummary:
    """Aggregated external packages pulled in by files in a single directory.

    Attributes:
        directory: Repo-relative POSIX path (root is ``""``).
        packages:  Sorted, deduplicated external package identifiers.
    """

    directory: str
    packages: tuple[str, ...]


# ---------------------------------------------------------------------------
# Language-specific import normalisation
# ---------------------------------------------------------------------------


def _normalise_python(raw: str) -> str | None:
    """Return the top-level Python package name, or None to discard.

    Relative imports (starting with ``.``) came from the same repository and
    were already considered by the graph builder; they are discarded here.
    """
    if raw.startswith("."):
        return None
    segment = raw.split(".")[0]
    return segment if segment else None


def _normalise_ts_js(raw: str) -> str | None:
    """Return the npm package specifier, or None to discard.

    Relative imports starting with ``.`` or ``/`` are in-repository references
    that were already processed by the graph builder.
    """
    if raw.startswith(".") or raw.startswith("/"):
        return None
    # Scoped packages: "@scope/name/sub" → "@scope/name"
    if raw.startswith("@"):
        parts = raw.split("/")
        if len(parts) >= 2:
            return "/".join(parts[:2])
        return raw
    # Bare specifier: "react/jsx-runtime" → "react"
    return raw.split("/")[0]


def _normalise_rust(raw: str) -> str | None:
    """Return the Rust crate root, or None to discard stdlib/self/crate paths."""
    # Strip leading "::" that sometimes appears on absolute paths
    clean = raw.lstrip(":")
    root = clean.split("::")[0].split("/")[0]
    if root in _RUST_STDLIB_ROOTS:
        return None
    return root if root else None


def _normalise_cpp(raw: str) -> str | None:
    """Return the first path segment of a C++ include, or None to discard.

    Quoted includes (``"…"``) are typically project-relative and were already
    resolved by the graph builder; only angle-bracket system/library includes
    are treated as external here.
    """
    # Quoted includes are relative → discard
    if raw.startswith('"'):
        return None
    # Angle-bracket includes: strip surrounding < >
    bare = raw.strip("<>")
    segment = bare.split("/")[0]
    return segment if segment else None


_NORMALISE_BY_LANGUAGE = {
    "python": _normalise_python,
    "typescript": _normalise_ts_js,
    "javascript": _normalise_ts_js,
    "rust": _normalise_rust,
    "cpp": _normalise_cpp,
}


# ---------------------------------------------------------------------------
# Core builder
# ---------------------------------------------------------------------------


def build_external_dependencies(
    graph: DependencyGraph,
    raw_imports: dict[str, list[str]],
    topology: DirectoryTopology,
) -> list[ExternalDependencySummary]:
    """Build per-directory external dependency summaries.

    For every file in *graph*, any raw import string that was *not* resolved to
    an in-repo graph edge is normalised into an external package name and
    attributed to the file's parent directory.  Results are deduplicated and
    sorted both within each directory and across the returned list.

    Args:
        graph:       The resolved dependency graph (read-only; provides resolved
                     edges and per-node language information).
        raw_imports: Mapping ``{file_rel_path: [raw_import, ...]}``.  Typically
                     produced by ``build_raw_import_inventory(graph)``.
        topology:    Directory topology (used to obtain the canonical directory
                     label for each file).

    Returns:
        A list of :class:`ExternalDependencySummary` objects — one per directory
        that has at least one external import — sorted by ``directory``.
        Directories with no external packages are omitted.
    """
    # Build a fast lookup set of resolved in-repo edges per file.
    resolved_per_file: dict[str, set[str]] = {
        rel: set(deps) for rel, deps in graph.edges.items()
    }

    # Build a fast lookup: file rel_path → language
    lang_by_file: dict[str, str] = {
        str(sf.rel_path).replace("\\", "/"): sf.language
        for sf in graph.nodes
    }

    # Build file → directory mapping from topology
    file_to_dir: dict[str, str] = {}
    for dir_node in topology.nodes.values():
        for file_rel in dir_node.files:
            file_to_dir[file_rel] = dir_node.path

    # Accumulate external packages per directory
    accumulator: dict[str, set[str]] = {}

    for file_rel, raw_list in raw_imports.items():
        lang = lang_by_file.get(file_rel)
        if lang is None:
            continue  # file not in graph nodes; skip
        normalise = _NORMALISE_BY_LANGUAGE.get(lang)
        if normalise is None:
            continue

        resolved = resolved_per_file.get(file_rel, set())
        directory = file_to_dir.get(file_rel, "")
        bucket = accumulator.setdefault(directory, set())

        for raw in raw_list:
            # Check whether this raw import was resolved into an in-repo edge.
            # The graph stores edge targets as rel_paths, not raw import strings,
            # so we identify external imports as those that produce no in-repo edge
            # pointing to a path that starts with the normalised identifier.
            # Simpler heuristic: if the raw import starts with "." or the directory
            # contains a file whose rel_path ends with the import path, it's
            # already captured in resolved edges.  Here we rely on the normaliser
            # to filter out relative imports and then check whether *any* resolved
            # edge target is "plausibly" this import.  The key insight is that the
            # graph builder already resolves everything it can; what remains in
            # raw_list but is absent from resolved edges is external.
            package = normalise(raw)
            if package is None:
                continue

            # If every resolved edge target represents an in-repo file, and none
            # of them looks like it came from this raw import, treat it as external.
            # We do this conservatively: we check whether any resolved edge target
            # for this file has the package as a prefix segment.
            is_in_repo = _looks_like_in_repo(package, resolved, lang)
            if not is_in_repo:
                bucket.add(package)

    # Build sorted result, omitting directories with no external packages
    result: list[ExternalDependencySummary] = []
    for directory in sorted(accumulator):
        packages = tuple(sorted(accumulator[directory]))
        if packages:
            capped = packages[:_MAX_PACKAGES_PER_DIR]
            result.append(ExternalDependencySummary(directory=directory, packages=capped))
    return result


def _looks_like_in_repo(package: str, resolved_edges: set[str], lang: str) -> bool:
    """Return True if *package* appears to be satisfied by an in-repo resolved edge.

    For Python and TS/JS the package name appears as a leading path segment or
    module path component in the resolved edge targets.  For Rust and C++ the
    same heuristic applies to crate or include names.
    """
    lower_pkg = package.lower()
    for edge_target in resolved_edges:
        # Normalise path separators and drop extension for comparison
        target_norm = edge_target.replace("\\", "/").lower()
        # e.g. "rpr/map/walker" starts with "rpr" → matches package "rpr"
        parts = target_norm.split("/")
        for part in parts:
            stem = part.rsplit(".", 1)[0]  # strip extension
            if stem == lower_pkg or part == lower_pkg:
                return True
    return False
