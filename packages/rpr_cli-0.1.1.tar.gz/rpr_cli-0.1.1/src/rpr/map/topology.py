from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from rpr.map.graph import DependencyGraph

# ---------------------------------------------------------------------------
# Private path helpers
# ---------------------------------------------------------------------------


def _posix_parent(path: str) -> str:
    """Return the parent directory of a POSIX path string.

    "api/routes/user.py" -> "api/routes"
    "main.py"            -> ""
    ""                   -> ""
    """
    idx = path.rfind("/")
    return path[:idx] if idx != -1 else ""


def _ancestors(directory: str) -> list[str]:
    """Return all ancestor directories including self and root "".

    "api/routes" -> ["api/routes", "api", ""]
    "api"        -> ["api", ""]
    ""           -> [""]
    """
    result: list[str] = []
    current = directory
    while True:
        result.append(current)
        if current == "":
            break
        current = _posix_parent(current)
    return result


def _truncate_to_depth(directory: str, depth: int) -> str:
    """Truncate a directory path to the first *depth* segments.

    _truncate_to_depth("api/routes/v2", 1) -> "api"
    _truncate_to_depth("api/routes/v2", 2) -> "api/routes"
    _truncate_to_depth("api", 1)           -> "api"
    _truncate_to_depth("", 1)              -> ""
    """
    if not directory:
        return ""
    parts = directory.split("/")
    return "/".join(parts[:depth])


# ---------------------------------------------------------------------------
# Domain value objects
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DirectoryNode:
    """A directory in the containment tree."""

    path: str  # POSIX rel_path; root is ""
    parent: str | None  # None only for root ""
    children: tuple[str, ...]  # sorted immediate child directory paths
    files: tuple[str, ...]  # sorted file rel_paths directly in this dir


@dataclass(frozen=True)
class DirectoryEdge:
    """An aggregated dependency edge between two directories."""

    source: str  # source directory POSIX path
    target: str  # target directory POSIX path
    support: int  # number of file-level edges contributing
    representatives: tuple[tuple[str, str], ...]  # sorted (src_file, dest_file) pairs


# ---------------------------------------------------------------------------
# Directory topology aggregate
# ---------------------------------------------------------------------------


@dataclass
class DirectoryTopology:
    """Directory-level projection of a file-level DependencyGraph.

    ``nodes`` preserves every discovered directory (including the root "").
    ``edges`` holds full-depth directory edges derived from file-level edges.
    Query methods produce derived views without modifying the stored state.
    """

    nodes: dict[str, DirectoryNode]  # path -> DirectoryNode
    edges: dict[tuple[str, str], DirectoryEdge]  # (src_dir, tgt_dir) -> edge
    root: str  # always ""

    # ------------------------------------------------------------------
    # Derived views
    # ------------------------------------------------------------------

    def edges_at_depth(self, depth: int) -> list[DirectoryEdge]:
        """Return directory edges with both endpoints truncated to *depth* segments.

        Edges where source == target after truncation (intra-directory) are
        excluded.  Representatives and support counts are merged across all
        full-depth edges that collapse to the same truncated pair.  The result
        is sorted by (source, target).
        """
        accumulator: dict[tuple[str, str], list[tuple[str, str]]] = {}
        for edge in self.edges.values():
            src = _truncate_to_depth(edge.source, depth)
            tgt = _truncate_to_depth(edge.target, depth)
            if src == tgt:
                continue
            key = (src, tgt)
            bucket = accumulator.setdefault(key, [])
            bucket.extend(edge.representatives)

        result: list[DirectoryEdge] = []
        for (src, tgt), pairs in sorted(accumulator.items()):
            deduped = sorted(set(pairs))
            result.append(
                DirectoryEdge(
                    source=src,
                    target=tgt,
                    support=len(deduped),
                    representatives=tuple(deduped),
                )
            )
        return result

    def top_level_edges(self) -> list[DirectoryEdge]:
        """Shorthand for ``edges_at_depth(1)``."""
        return self.edges_at_depth(1)

    def subgraph(self, directory: str) -> list[DirectoryEdge]:
        """Return edges where at least one endpoint is an immediate child of *directory*.

        Internal paths (under *directory*) are expressed at child depth — one
        segment deeper than *directory*.  External paths are truncated to
        top-level (depth 1) so outbound dependencies are readable.  Edges
        entirely outside the directory are excluded.  The root directory ("")
        returns the same result as ``top_level_edges()``.
        """
        child_depth = directory.count("/") + 2 if directory else 1
        prefix = directory + "/" if directory else ""

        def _is_under(dir_path: str) -> bool:
            if not directory:
                return True
            return dir_path == directory or dir_path.startswith(prefix)

        def _truncate_for_side(dir_path: str) -> str:
            if _is_under(dir_path):
                return _truncate_to_depth(dir_path, child_depth)
            return _truncate_to_depth(dir_path, 1)

        accumulator: dict[tuple[str, str], list[tuple[str, str]]] = {}
        for edge in self.edges.values():
            src_is_under = _is_under(edge.source)
            tgt_is_under = _is_under(edge.target)
            if not src_is_under and not tgt_is_under:
                continue

            src = _truncate_for_side(edge.source)
            tgt = _truncate_for_side(edge.target)
            if src == tgt:
                continue

            key = (src, tgt)
            bucket = accumulator.setdefault(key, [])
            bucket.extend(edge.representatives)

        result: list[DirectoryEdge] = []
        for (src, tgt), pairs in sorted(accumulator.items()):
            deduped = sorted(set(pairs))
            result.append(
                DirectoryEdge(
                    source=src,
                    target=tgt,
                    support=len(deduped),
                    representatives=tuple(deduped),
                )
            )
        return result

    def files_in(self, directory: str) -> list[str]:
        """Return all file rel_paths recursively contained under *directory*.

        The result is sorted for determinism.
        """
        collected: list[str] = []
        prefix = directory + "/" if directory else ""
        for node in self.nodes.values():
            if node.path == directory or node.path.startswith(prefix):
                collected.extend(node.files)
        return sorted(collected)


# ---------------------------------------------------------------------------
# Public builder
# ---------------------------------------------------------------------------


def build_directory_topology(graph: DependencyGraph, root: Path) -> DirectoryTopology:  # noqa: ARG001
    """Build a DirectoryTopology from a file-level DependencyGraph.

    The *root* parameter is accepted for API symmetry with other map builders
    but is not required for the computation (all paths are already relative
    inside the graph).

    Args:
        graph: The file-level dependency graph (read-only input).
        root:  The filesystem root that was analysed (unused internally).

    Returns:
        A fully populated DirectoryTopology.
    """
    # ------------------------------------------------------------------
    # Step 1: Collect all directory paths and direct-file containment.
    # ------------------------------------------------------------------
    dir_files: dict[str, list[str]] = {"": []}  # root always present

    for node in graph.nodes:
        file_key = str(node.rel_path).replace("\\", "/")
        parent_dir = _posix_parent(file_key)
        # Record the file under its immediate parent only.
        dir_files.setdefault(parent_dir, []).append(file_key)
        # Ensure every ancestor directory exists (even if it contains no
        # direct files).
        for ancestor in _ancestors(parent_dir):
            dir_files.setdefault(ancestor, [])

    # ------------------------------------------------------------------
    # Step 2: Build parent -> children index.
    # ------------------------------------------------------------------
    dir_children: dict[str, list[str]] = {d: [] for d in dir_files}

    for directory in dir_files:
        if directory == "":
            continue
        parent = _posix_parent(directory)
        dir_children.setdefault(parent, []).append(directory)

    # ------------------------------------------------------------------
    # Step 3: Construct DirectoryNode objects.
    # ------------------------------------------------------------------
    nodes: dict[str, DirectoryNode] = {}
    for directory in dir_files:
        parent: str | None = _posix_parent(directory) if directory else None
        nodes[directory] = DirectoryNode(
            path=directory,
            parent=parent,
            children=tuple(sorted(dir_children.get(directory, []))),
            files=tuple(sorted(dir_files[directory])),
        )

    # ------------------------------------------------------------------
    # Step 4: Build full-depth directory edges from file-level edges.
    # ------------------------------------------------------------------
    edge_pairs: dict[tuple[str, str], list[tuple[str, str]]] = {}

    for src_file, deps in graph.edges.items():
        src_dir = _posix_parent(src_file)
        for tgt_file in deps:
            tgt_dir = _posix_parent(tgt_file)
            if src_dir == tgt_dir:
                continue  # intra-directory at full depth — skip
            key = (src_dir, tgt_dir)
            edge_pairs.setdefault(key, []).append((src_file, tgt_file))

    # ------------------------------------------------------------------
    # Step 5: Construct DirectoryEdge objects.
    # ------------------------------------------------------------------
    edges: dict[tuple[str, str], DirectoryEdge] = {}
    for (src_dir, tgt_dir), pairs in edge_pairs.items():
        deduped = sorted(set(pairs))
        edges[(src_dir, tgt_dir)] = DirectoryEdge(
            source=src_dir,
            target=tgt_dir,
            support=len(deduped),
            representatives=tuple(deduped),
        )

    return DirectoryTopology(nodes=nodes, edges=edges, root="")


def focus_edges(
    topology: DirectoryTopology,
    directory: str,
    graph_edges: dict[str, list[str]],
) -> tuple[list[tuple[str, str]], list[tuple[str, str]], list[tuple[str, str]]]:
    """Return file-level edges classified relative to a focused directory.

    Args:
        topology:    Directory topology used to enumerate files under *directory*.
        directory:   Repo-relative POSIX path of the directory to focus on.
        graph_edges: File-level edges from ``DependencyGraph.edges``.

    Returns:
        A three-tuple ``(internal_edges, inbound_edges, outbound_edges)``:

        - *internal_edges*: ``(src_file, tgt_file)`` where both files are
          under *directory*.
        - *inbound_edges*: ``(external_file, internal_file)`` where the
          source is outside *directory* and the target is inside.
        - *outbound_edges*: ``(internal_file, external_file)`` where the
          source is inside *directory* and the target is outside.
    """
    focus_files = set(topology.files_in(directory))
    internal: list[tuple[str, str]] = []
    inbound: list[tuple[str, str]] = []
    outbound: list[tuple[str, str]] = []

    for src, targets in graph_edges.items():
        src_inside = src in focus_files
        for tgt in targets:
            tgt_inside = tgt in focus_files
            if src_inside and tgt_inside:
                internal.append((src, tgt))
            elif src_inside and not tgt_inside:
                outbound.append((src, tgt))
            elif not src_inside and tgt_inside:
                inbound.append((src, tgt))

    return sorted(internal), sorted(inbound), sorted(outbound)
