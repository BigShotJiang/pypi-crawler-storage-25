from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import pathspec

type Language = Literal["python", "typescript", "javascript", "rust", "cpp"]

_EXT_TO_LANG: dict[str, Language] = {
    ".py": "python",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".rs": "rust",
    ".cpp": "cpp",
    ".cc": "cpp",
    ".cxx": "cpp",
    ".c": "cpp",
    ".h": "cpp",
    ".hpp": "cpp",
    ".hxx": "cpp",
}

_IGNORED_DIRS: frozenset[str] = frozenset(
    {
        ".venv",
        "venv",
        ".env",
        "node_modules",
        "__pycache__",
        "dist",
        "build",
        ".nx",
        "target",
        ".git",
        "vendor",
    }
)


def _load_gitignore(root: Path) -> pathspec.PathSpec | None:
    """Load .gitignore patterns from root; returns None if file absent."""
    gitignore = root / ".gitignore"
    if not gitignore.is_file():
        return None
    lines = gitignore.read_text(encoding="utf-8", errors="replace").splitlines()
    return pathspec.PathSpec.from_lines("gitignore", lines)


@dataclass
class SourceFile:
    abs_path: Path
    rel_path: Path
    language: Language


@dataclass
class ProjectEntry:
    abs_path: Path
    rel_path: Path
    is_dir: bool


def walk(root: Path) -> list[SourceFile]:
    spec = _load_gitignore(root)
    results: list[SourceFile] = []
    _recurse(root, root, results, spec)
    return results


def list_project_entries(root: Path) -> list[ProjectEntry]:
    spec = _load_gitignore(root)
    results: list[ProjectEntry] = []
    _recurse_entries(root, root, results, spec)
    return results


def _recurse(
    root: Path,
    current: Path,
    results: list[SourceFile],
    spec: pathspec.PathSpec | None,
) -> None:
    try:
        entries = list(current.iterdir())
    except PermissionError:
        return
    for entry in entries:
        if entry.is_symlink():
            continue
        rel = entry.relative_to(root)
        if entry.is_dir():
            if entry.name in _IGNORED_DIRS:
                continue
            # Append "/" so pathspec matches directory-only patterns (e.g. "secret/")
            if spec is not None and spec.match_file(str(rel) + "/"):
                continue
            _recurse(root, entry, results, spec)
        elif entry.is_file():
            if spec is not None and spec.match_file(str(rel)):
                continue
            lang = _EXT_TO_LANG.get(entry.suffix)
            if lang is not None:
                results.append(
                    SourceFile(
                        abs_path=entry.resolve(),
                        rel_path=rel,
                        language=lang,
                    )
                )


def _recurse_entries(
    root: Path,
    current: Path,
    results: list[ProjectEntry],
    spec: pathspec.PathSpec | None,
) -> None:
    try:
        entries = sorted(
            current.iterdir(),
            key=lambda entry: (not entry.is_dir(), entry.name.lower()),
        )
    except PermissionError:
        return

    for entry in entries:
        if entry.is_symlink():
            continue
        rel = entry.relative_to(root)
        if entry.is_dir():
            if entry.name in _IGNORED_DIRS:
                continue
            if spec is not None and spec.match_file(str(rel) + "/"):
                continue
            results.append(
                ProjectEntry(abs_path=entry.resolve(), rel_path=rel, is_dir=True)
            )
            _recurse_entries(root, entry, results, spec)
            continue

        if spec is not None and spec.match_file(str(rel)):
            continue
        results.append(
            ProjectEntry(abs_path=entry.resolve(), rel_path=rel, is_dir=False)
        )
