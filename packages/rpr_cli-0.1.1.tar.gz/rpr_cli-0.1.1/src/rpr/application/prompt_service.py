from __future__ import annotations

import asyncio
from pathlib import Path
from typing import ClassVar

from prompt_toolkit.completion import Completer

from rpr.agent.approval import ApprovalMode
from rpr.agent.control import TurnControl
from rpr.agent.session import ChatSession
from rpr.application.conversation_service import (
    ConversationService,
    ConversationSummary,
    InMemoryConversationRepository,
)
from rpr.ui.prompt_session import PromptSessionAdapter


class PromptService:
    _instance: ClassVar[PromptService | None] = None

    def __init__(self) -> None:
        self._conversations = ConversationService()
        self._session = PromptSessionAdapter()

    @classmethod
    def instance(cls) -> PromptService:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def set_active_task(self, task: asyncio.Task | None) -> None:
        self._session.set_active_task(task)

    def set_active_control(self, control: TurnControl | None) -> None:
        self._session.set_active_control(control)

    def set_queue_info(self, count: int, preview: str | None) -> None:
        self._session.set_queue_info(count, preview)

    def set_completer(self, completer: Completer) -> None:
        self._session.set_completer(completer)

    def has_modal_input(self) -> bool:
        return self._session.has_modal_input()

    def get_prompt_session(self):
        return self._session.get_prompt_session()

    def list_conversations(self) -> list[ConversationSummary]:
        return self._conversations.list_conversations()

    def create_conversation(
        self, *, project_dir: Path, approval_mode: ApprovalMode
    ) -> ChatSession:
        return self._conversations.create_conversation(
            project_dir=project_dir,
            approval_mode=approval_mode,
        )

    def load_conversation(self, session_id: str) -> ChatSession:
        return self._conversations.load_conversation(session_id)

    def save_conversation(self, session: ChatSession | None = None) -> None:
        self._conversations.save_conversation(session)

    async def read_input(
        self,
        message: str = "> ",
        *,
        multiline: bool = False,
        modal: bool = False,
    ) -> str:
        return await self._session.read_input(message, multiline=multiline, modal=modal)

    async def prompt(self, label: str, *, default: str | None = None) -> str:
        return await self._session.prompt(label, default=default)

    async def confirm(self, label: str, *, default: bool = False) -> bool:
        return await self._session.confirm(label, default=default)

    def reset(self) -> None:
        self._session.reset()
        self._conversations.reset()
