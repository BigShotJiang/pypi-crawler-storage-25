from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from rpr.checks.instructions import check_instructions
from rpr.checks.packages import check_packages
from rpr.checks.workspace import check_workspace
from rpr.generators.base import SyncConfig


@dataclass(slots=True, frozen=True)
class CheckReport:
    project_name: str
    results: list[object]


def collect_check_report(project_dir: Path, group: str | None = None) -> CheckReport:
    config_path = project_dir / ".rpr.yaml"
    config = SyncConfig.load(config_path)

    variables = config.variables or {}
    project_name = variables.get("name", "(unknown)")
    requested_group = None if group is None else group.lower()
    results: list[object] = []

    if requested_group in {None, "workspace"}:
        results.extend(check_workspace(project_dir))

    if requested_group in {None, "instructions"}:
        results.extend(check_instructions(project_dir, variables))

    if requested_group in {None, "packages"}:
        results.extend(check_packages(project_dir, variables))

    return CheckReport(project_name=project_name, results=results)


def serialize_check_results(results: list[object]) -> list[dict[str, object]]:
    return [
        {
            "group": result.group,
            "area": result.area,
            "status": result.status,
            "path": result.path,
            "suggestion": result.suggestion,
        }
        for result in results
    ]
