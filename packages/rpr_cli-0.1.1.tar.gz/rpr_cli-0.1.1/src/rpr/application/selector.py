from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass


@dataclass(slots=True, frozen=True)
class TriggerSelectorCandidate:
    value: str
    label: str
    description: str
    insert_text: str
    detail: str | None = None
    keep_open_on_exact_match: bool = False


@dataclass(slots=True, frozen=True)
class TriggerSelectorSource:
    trigger: str
    candidates: tuple[TriggerSelectorCandidate, ...]
    anchored_to_start: bool = True
    hide_on_exact_match: bool = True
    case_sensitive: bool = True


@dataclass(slots=True, frozen=True)
class TriggerSelectorApplication:
    text: str
    cursor_position: int
    candidate: TriggerSelectorCandidate


@dataclass(slots=True, frozen=True)
class TriggerSelectorSnapshot:
    trigger: str | None
    query: str
    replacement_start: int
    replacement_end: int
    matches: tuple[TriggerSelectorCandidate, ...]
    visible_matches: tuple[TriggerSelectorCandidate, ...]
    selected_index: int
    visible_start: int
    dismissed: bool = False

    @property
    def selected_candidate(self) -> TriggerSelectorCandidate | None:
        if not self.matches:
            return None
        return self.matches[self.selected_index]

    @property
    def visible(self) -> bool:
        return self.trigger is not None and bool(self.matches) and not self.dismissed


class TriggerSelector:
    def __init__(
        self,
        sources: Sequence[TriggerSelectorSource] = (),
        *,
        max_visible_matches: int = 6,
    ) -> None:
        self._sources: tuple[TriggerSelectorSource, ...] = tuple(sources)
        self._max_visible_matches = max_visible_matches
        self._selected_index = 0
        self._active_key: tuple[str, int, int, str] | None = None
        self._dismissed_key: tuple[str, int, int, str] | None = None

    def set_sources(self, sources: Sequence[TriggerSelectorSource]) -> None:
        self._sources = tuple(sources)
        self.reset()

    def reset(self) -> None:
        self._selected_index = 0
        self._active_key = None
        self._dismissed_key = None

    def snapshot(
        self, text: str, cursor_position: int | None = None
    ) -> TriggerSelectorSnapshot:
        resolved_cursor_position = (
            len(text) if cursor_position is None else cursor_position
        )
        source, query, replacement_start, replacement_end = self._find_active_source(
            text=text,
            cursor_position=resolved_cursor_position,
        )
        if source is None:
            self._active_key = None
            return TriggerSelectorSnapshot(
                trigger=None,
                query="",
                replacement_start=resolved_cursor_position,
                replacement_end=resolved_cursor_position,
                matches=(),
                visible_matches=(),
                selected_index=0,
                visible_start=0,
                dismissed=False,
            )

        normalized_query = query if source.case_sensitive else query.casefold()
        matches = tuple(
            candidate
            for candidate in source.candidates
            if self._normalize_value(
                candidate.value, case_sensitive=source.case_sensitive
            ).startswith(normalized_query)
        )
        snapshot_key = (source.trigger, replacement_start, replacement_end, query)
        if snapshot_key != self._active_key:
            self._selected_index = 0
            self._dismissed_key = None
        self._active_key = snapshot_key
        exact_matches = tuple(
            candidate
            for candidate in matches
            if self._normalize_value(
                candidate.value, case_sensitive=source.case_sensitive
            )
            == normalized_query
        )
        has_exact_match = (
            source.hide_on_exact_match
            and bool(exact_matches)
            and all(
                not candidate.keep_open_on_exact_match for candidate in exact_matches
            )
        )

        if matches:
            self._selected_index = min(self._selected_index, len(matches) - 1)
        else:
            self._selected_index = 0

        visible_start = self._visible_start(self._selected_index, len(matches))
        visible_end = min(len(matches), visible_start + self._max_visible_matches)
        return TriggerSelectorSnapshot(
            trigger=source.trigger,
            query=query,
            replacement_start=replacement_start,
            replacement_end=replacement_end,
            matches=matches,
            visible_matches=matches[visible_start:visible_end],
            selected_index=self._selected_index,
            visible_start=visible_start,
            dismissed=snapshot_key == self._dismissed_key or has_exact_match,
        )

    def is_visible(self, text: str, cursor_position: int | None = None) -> bool:
        return self.snapshot(text, cursor_position).visible

    def move_selection(
        self,
        text: str,
        cursor_position: int | None = None,
        *,
        step: int,
    ) -> TriggerSelectorSnapshot:
        snapshot = self.snapshot(text, cursor_position)
        if not snapshot.visible or not snapshot.matches:
            return snapshot
        self._selected_index = (snapshot.selected_index + step) % len(snapshot.matches)
        return self.snapshot(text, cursor_position)

    def dismiss(self, text: str, cursor_position: int | None = None) -> None:
        snapshot = self.snapshot(text, cursor_position)
        if snapshot.trigger is None:
            return
        self._dismissed_key = (
            snapshot.trigger,
            snapshot.replacement_start,
            snapshot.replacement_end,
            snapshot.query,
        )

    def apply_selection(
        self,
        text: str,
        cursor_position: int | None = None,
    ) -> TriggerSelectorApplication | None:
        snapshot = self.snapshot(text, cursor_position)
        candidate = snapshot.selected_candidate
        if not snapshot.visible or candidate is None:
            return None

        new_text = (
            text[: snapshot.replacement_start]
            + candidate.insert_text
            + text[snapshot.replacement_end :]
        )
        new_cursor_position = snapshot.replacement_start + len(candidate.insert_text)
        self.reset()
        return TriggerSelectorApplication(
            text=new_text,
            cursor_position=new_cursor_position,
            candidate=candidate,
        )

    def _find_active_source(
        self,
        *,
        text: str,
        cursor_position: int,
    ) -> tuple[TriggerSelectorSource | None, str, int, int]:
        text_before_cursor = text[:cursor_position]
        for source in self._sources:
            if source.anchored_to_start:
                if not text_before_cursor.startswith(source.trigger):
                    continue
                query = text_before_cursor[len(source.trigger) :]
                if any(character.isspace() for character in query):
                    continue
                return source, query, 0, cursor_position

            trigger_index = text_before_cursor.rfind(source.trigger)
            if trigger_index < 0:
                continue
            if (
                trigger_index > 0
                and not text_before_cursor[trigger_index - 1].isspace()
            ):
                continue
            query = text_before_cursor[trigger_index + len(source.trigger) :]
            if any(character.isspace() for character in query):
                continue
            return source, query, trigger_index, cursor_position

        return None, "", cursor_position, cursor_position

    def _visible_start(self, selected_index: int, match_count: int) -> int:
        if match_count <= self._max_visible_matches:
            return 0
        max_start = match_count - self._max_visible_matches
        centered_start = selected_index - (self._max_visible_matches // 2)
        return max(0, min(centered_start, max_start))

    @staticmethod
    def _normalize_value(value: str, *, case_sensitive: bool) -> str:
        return value if case_sensitive else value.casefold()
