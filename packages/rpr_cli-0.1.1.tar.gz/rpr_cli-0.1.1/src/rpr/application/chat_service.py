from __future__ import annotations

import asyncio
from collections import deque
from contextlib import suppress
from dataclasses import dataclass
from typing import Callable
from typing import ClassVar

from prompt_toolkit import print_formatted_text
from prompt_toolkit.application.current import get_app_session
from prompt_toolkit.formatted_text import FormattedText

from rpr.agent.approval import ApprovalDecision, ApprovalMode
from rpr.agent.bootstrap import build_chat_runtime_bundle
from rpr.agent.client import AgentClient
from rpr.agent.control import TurnControl
from rpr.agent.runtime import RuntimeCallbacks
from rpr.agent.session import ToolCallRecord
from rpr.application.completer import (
    FileContextCompleter,
    MultiCompleter,
    SlashCommandCandidate,
    SlashCommandCompleter,
)
from rpr.application.prompt_service import PromptService
from rpr.application.shell import CommandShellService, ShellPresenter
from rpr.context import RunContext
from rpr.ui.console import console, refresh_console
from rpr.ui.renderers import (
    render_approval_prompt,
    render_chat_hint,
    render_error,
    render_heading,
    render_info,
    render_session_header,
    render_status_row,
    render_success,
    render_table,
    render_tool_call,
    render_tool_result,
    render_warning,
)
from rpr.ui.theme import SettingsManager

type AgentClientFactory = Callable[[str | None, str | None], AgentClient]
type ContextFactory = Callable[[], RunContext]


@dataclass(slots=True)
class AssistantStreamRenderer:
    _accumulated: str = ""
    _lines_printed: int = 0

    def append(self, chunk: str) -> None:
        self._accumulated += chunk
        output = get_app_session().output
        if self._lines_printed > 0:
            output.cursor_up(self._lines_printed)
            output.erase_down()
            output.flush()
        print_formatted_text(
            FormattedText(
                [
                    ("", "\n"),
                    ("bold fg:ansiblue", "Assistant >"),
                    ("", "\n\n"),
                    ("", self._accumulated),
                ]
            ),
        )
        # 1 (leading \n) + 1 ("Assistant >") + 2 (\n\n) + content newlines + 1 (end=\n)
        self._lines_printed = 4 + self._accumulated.count("\n")

    def flush(self) -> None:
        self._accumulated = ""
        self._lines_printed = 0


@dataclass(slots=True)
class RichShellPresenter(ShellPresenter):
    stream_renderer: AssistantStreamRenderer

    def flush(self) -> None:
        self.stream_renderer.flush()

    def append_text(self, chunk: str) -> None:
        self.stream_renderer.append(chunk)

    def heading(self, text: str) -> None:
        self.flush()
        render_heading(text)

    def info(self, message: str) -> None:
        self.flush()
        render_info(message)

    def success(self, message: str) -> None:
        self.flush()
        render_success(message)

    def warning(self, message: str) -> None:
        self.flush()
        render_warning(message)

    def error(self, message: str) -> None:
        self.flush()
        render_error(message)

    def table(self, title: str, columns: list[str], rows: list[list[str]]) -> None:
        self.flush()
        render_table(title, columns, rows)

    def status_row(
        self,
        icon_char: str,
        area: str,
        path: str,
        status: bool,
        suggestion: str | None = None,
    ) -> None:
        self.flush()
        render_status_row(icon_char, area, path, status, suggestion)

    def on_setting_changed(self, key: str) -> None:
        self.flush()
        if key == "theme":
            refresh_console()


class ChatCommandService:
    _instance: ClassVar[ChatCommandService | None] = None

    def __init__(self) -> None:
        self._prompt_service = PromptService.instance()
        self._shell_service = CommandShellService.instance()

    @classmethod
    def instance(cls) -> ChatCommandService:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    async def run(
        self,
        *,
        provider: str | None,
        model: str | None,
        approval_mode_override: str | None,
        client_factory: AgentClientFactory,
        context_factory: ContextFactory,
        settings: SettingsManager,
    ) -> None:
        ctx = context_factory()
        client = client_factory(provider, model)
        resolved_approval_mode = self._resolve_approval_mode(
            approval_mode_override, settings
        )
        conversation = self._prompt_service.create_conversation(
            project_dir=ctx.project_dir,
            approval_mode=resolved_approval_mode,
        )
        presenter = RichShellPresenter(stream_renderer=AssistantStreamRenderer())

        # Define these before bundle creation so the approval closure captures them.
        message_queue: deque[str] = deque()

        def _update_queue_display() -> None:
            preview = message_queue[0] if message_queue else None
            self._prompt_service.set_queue_info(len(message_queue), preview)

        async def _request_approval(record: ToolCallRecord) -> ApprovalDecision:
            presenter.flush()
            render_approval_prompt(record.tool_name)
            response = await self._prompt_service.read_input(
                "Approve? [a]pprove/[r]eject/[s]ession > ",
                modal=True,
            )
            normalized = response.lower()
            if normalized in {"a", "approve"}:
                return ApprovalDecision.APPROVE
            if normalized in {"s", "session", "always"}:
                return ApprovalDecision.ALWAYS_ALLOW
            return ApprovalDecision.REJECT

        bundle = self._build_runtime_bundle(
            ctx=ctx,
            client=client,
            approval_mode=resolved_approval_mode,
            presenter=presenter,
            session=conversation,
            request_approval=_request_approval,
        )
        self._shell_service.configure(
            bundle=bundle,
            presenter=presenter,
            prompts=self._prompt_service,
        )
        candidates = [
            SlashCommandCandidate(
                name=spec.name,
                description=spec.description,
                usage=spec.usage,
            )
            for spec in self._shell_service.command_specs
        ]
        self._prompt_service.set_completer(
            MultiCompleter(
                [
                    SlashCommandCompleter(candidates),
                    FileContextCompleter(ctx.project_dir),
                ]
            )
        )

        render_session_header(
            project_root=ctx.project_dir,
            provider=client.provider_name,
            model=client.model_name,
            approval_mode=bundle.session.approval_mode.value,
        )
        if settings.startup_help:
            render_chat_hint(
                "Type /help to inspect slash commands and /exit to end the session."
            )

        active_task: asyncio.Task | None = None

        def _dispatch_agent_turn(message: str) -> None:
            nonlocal active_task
            control = TurnControl()
            self._prompt_service.set_active_control(control)

            async def _run_turn() -> None:
                try:
                    await self._shell_service.handle_input(message, control=control)
                    presenter.flush()
                    self._prompt_service.save_conversation(bundle.session)
                except asyncio.CancelledError:
                    presenter.flush()
                    render_chat_hint("Response cancelled.")
                    raise
                except Exception as exc:
                    presenter.flush()
                    render_error(f"Error: {exc}")

            task = asyncio.create_task(_run_turn())
            active_task = task
            self._prompt_service.set_active_task(task)

            def _on_done(fut: asyncio.Task) -> None:
                nonlocal active_task
                active_task = None
                self._prompt_service.set_active_task(None)
                self._prompt_service.set_active_control(None)
                if message_queue:
                    next_msg = message_queue.popleft()
                    _update_queue_display()
                    _dispatch_agent_turn(next_msg)
                else:
                    _update_queue_display()

            task.add_done_callback(_on_done)

        try:
            while True:
                try:
                    if active_task is not None and not active_task.done():
                        await asyncio.sleep(0)
                        while (
                            active_task is not None
                            and not active_task.done()
                            and self._prompt_service.has_modal_input()
                        ):
                            await asyncio.sleep(0.01)

                    user_input = await self._prompt_service.read_input(
                        "> ", multiline=True
                    )
                    if not user_input:
                        continue

                    normalized = user_input.strip()
                    is_slash = normalized.startswith("/") or normalized.lower() in {
                        "exit",
                        "quit",
                    }

                    if is_slash:
                        try:
                            should_continue = await self._shell_service.handle_input(
                                normalized
                            )
                        except Exception as exc:
                            presenter.flush()
                            render_error(f"Error: {exc}")
                        else:
                            presenter.flush()
                            self._prompt_service.save_conversation(bundle.session)
                            if not should_continue:
                                if active_task is not None and not active_task.done():
                                    with suppress(asyncio.CancelledError, Exception):
                                        await active_task
                                break
                    else:
                        if active_task is not None and not active_task.done():
                            message_queue.append(normalized)
                            _update_queue_display()
                        else:
                            _dispatch_agent_turn(normalized)

                except KeyboardInterrupt, EOFError:
                    if active_task is not None and not active_task.done():
                        active_task.cancel()
                    presenter.flush()
                    render_chat_hint("Session ended.")
                    break
        finally:
            if active_task is not None and not active_task.done():
                active_task.cancel()
                with suppress(asyncio.CancelledError):
                    await active_task
            presenter.flush()
            self._prompt_service.save_conversation(bundle.session)

        render_chat_hint("Goodbye!")

    def _build_runtime_bundle(
        self,
        *,
        ctx: RunContext,
        client: AgentClient,
        approval_mode: ApprovalMode,
        presenter: RichShellPresenter,
        session,
        request_approval=None,
    ):
        callbacks = RuntimeCallbacks(
            on_text_delta=presenter.append_text,
            on_tool_call=lambda record: self._handle_tool_call_render(
                record, presenter.stream_renderer
            ),
            on_tool_result=lambda record, result: self._handle_tool_result_render(
                record, result.output, result.success
            ),
            request_approval=request_approval
            or (lambda record: self._prompt_for_approval(record, presenter=presenter)),
            on_attachment_notice=lambda message: self._handle_attachment_notice(
                message, presenter.stream_renderer
            ),
        )
        return build_chat_runtime_bundle(
            ctx=ctx,
            client=client,
            approval_mode=approval_mode,
            callbacks=callbacks,
            session=session,
        )

    def _handle_tool_call_render(
        self, record: ToolCallRecord, stream_renderer: AssistantStreamRenderer
    ) -> None:
        stream_renderer.flush()
        render_tool_call(
            record.tool_name, dict(record.arguments), is_mutating=record.is_mutating
        )

    @staticmethod
    def _handle_tool_result_render(
        record: ToolCallRecord, output: str, success: bool
    ) -> None:
        render_tool_result(record.tool_name, output, success=success)

    @staticmethod
    def _handle_attachment_notice(
        message: str, stream_renderer: AssistantStreamRenderer
    ) -> None:
        stream_renderer.flush()
        render_chat_hint(message)

    async def _prompt_for_approval(
        self,
        record: ToolCallRecord,
        *,
        presenter: RichShellPresenter,
    ) -> ApprovalDecision:
        presenter.flush()
        render_approval_prompt(record.tool_name)
        response = await self._prompt_service.read_input(
            "Approve? [a]pprove/[r]eject/[s]ession > ",
            modal=True,
        )
        normalized = response.lower()
        if normalized in {"a", "approve"}:
            return ApprovalDecision.APPROVE
        if normalized in {"s", "session", "always"}:
            return ApprovalDecision.ALWAYS_ALLOW
        return ApprovalDecision.REJECT

    @staticmethod
    def _resolve_approval_mode(
        approval_mode_override: str | None,
        settings: SettingsManager,
    ) -> ApprovalMode:
        if approval_mode_override is None:
            return settings.approval_mode

        try:
            return ApprovalMode(approval_mode_override.lower())
        except ValueError as exc:
            raise ValueError(
                "Approval mode must be ask, auto-readonly, or auto-all."
            ) from exc
