from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Protocol

from rpr.agent.approval import ApprovalMode
from rpr.agent.session import ChatSession


@dataclass(slots=True, frozen=True)
class ConversationSummary:
    session_id: str
    title: str
    project_dir: Path
    created_at: datetime
    updated_at: datetime


class ConversationRepository(Protocol):
    def save(self, session: ChatSession) -> None: ...
    def find(self, session_id: str) -> ChatSession | None: ...
    def all(self) -> list[ChatSession]: ...


class InMemoryConversationRepository:
    def __init__(self) -> None:
        self._store: dict[str, ChatSession] = {}

    def save(self, session: ChatSession) -> None:
        self._store[session.session_id] = session

    def find(self, session_id: str) -> ChatSession | None:
        return self._store.get(session_id)

    def all(self) -> list[ChatSession]:
        return list(self._store.values())


class ConversationService:
    def __init__(self, repository: ConversationRepository | None = None) -> None:
        self._repository = repository or InMemoryConversationRepository()
        self._current_session_id: str | None = None

    def list_conversations(self) -> list[ConversationSummary]:
        sessions = sorted(
            self._repository.all(),
            key=lambda session: session.updated_at,
            reverse=True,
        )
        return [
            ConversationSummary(
                session_id=session.session_id,
                title=session.title,
                project_dir=session.project_dir,
                created_at=session.created_at,
                updated_at=session.updated_at,
            )
            for session in sessions
        ]

    def create_conversation(
        self, *, project_dir: Path, approval_mode: ApprovalMode
    ) -> ChatSession:
        conversation = ChatSession(project_dir=project_dir, approval_mode=approval_mode)
        self._repository.save(conversation)
        self._current_session_id = conversation.session_id
        return conversation

    def load_conversation(self, session_id: str) -> ChatSession:
        conversation = self._repository.find(session_id)
        if conversation is None:
            raise ValueError(f"Unknown conversation: {session_id}")
        conversation.touch()
        self._current_session_id = session_id
        return conversation

    def save_conversation(self, session: ChatSession | None = None) -> None:
        if session is None:
            if self._current_session_id is None:
                return
            session = self._repository.find(self._current_session_id)
            if session is None:
                return
        session.touch()
        self._repository.save(session)
        self._current_session_id = session.session_id

    def reset(self, repository: ConversationRepository | None = None) -> None:
        self._repository = repository or InMemoryConversationRepository()
        self._current_session_id = None
