from __future__ import annotations

from rpr.application.catalog import COMMAND_CATALOG, CommandDefinition


def get_cli_definition(action_id: str) -> CommandDefinition | None:
    """Look up a CommandDefinition by action_id across all CLI-enabled commands.

    Searches recursively through the full catalog tree. Returns the first match
    where ``cmd.cli_enabled`` is True and ``cmd.action_id == action_id``.

    Example::

        get_cli_definition("generate.ui")  # → CommandDefinition(name="ui", ...)
        get_cli_definition("chat.exit")    # → None  (cli_enabled=False)
    """

    def _search(cmds: tuple[CommandDefinition, ...]) -> CommandDefinition | None:
        for cmd in cmds:
            if cmd.cli_enabled and cmd.action_id == action_id:
                return cmd
            if cmd.children:
                found = _search(cmd.children)
                if found is not None:
                    return found
        return None

    return _search(COMMAND_CATALOG)


def default_root_command() -> CommandDefinition | None:
    """Return the top-level command flagged as default_root_command, if any."""
    for cmd in COMMAND_CATALOG:
        if cmd.default_root_command:
            return cmd
    return None
