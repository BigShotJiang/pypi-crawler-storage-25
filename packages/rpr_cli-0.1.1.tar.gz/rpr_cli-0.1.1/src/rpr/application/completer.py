from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path

from prompt_toolkit.completion import CompleteEvent, Completer, Completion
from prompt_toolkit.document import Document

from rpr.application.selector import TriggerSelectorCandidate, TriggerSelectorSource
from rpr.map.walker import list_project_entries


@dataclass(slots=True, frozen=True)
class SlashCommandCandidate:
    name: str
    description: str
    usage: str


@dataclass(slots=True, frozen=True)
class FileContextCandidate:
    path: str
    is_dir: bool


class SlashCommandCompleter(Completer):
    def __init__(self, candidates: Sequence[SlashCommandCandidate]) -> None:
        self._candidates = candidates

    @property
    def selector_source(self) -> TriggerSelectorSource:
        return TriggerSelectorSource(
            trigger="/",
            candidates=tuple(
                TriggerSelectorCandidate(
                    value=candidate.name,
                    label=f"/{candidate.name}",
                    description=candidate.description,
                    insert_text=f"/{candidate.name} ",
                    detail=candidate.usage,
                )
                for candidate in self._candidates
            ),
        )

    def get_completions(
        self,
        document: Document,
        complete_event: CompleteEvent,
    ) -> Iterable[Completion]:
        text = document.text_before_cursor
        if not text.startswith("/"):
            return
        partial = text[1:]
        for candidate in self._candidates:
            if candidate.name.startswith(partial):
                yield Completion(
                    text=candidate.name,
                    start_position=-len(partial),
                    display=f"/{candidate.name}",
                    display_meta=candidate.description,
                )


class FileContextCompleter(Completer):
    def __init__(self, root: Path) -> None:
        self._root = root
        self._candidates = self._load_candidates()

    @property
    def selector_source(self) -> TriggerSelectorSource:
        return TriggerSelectorSource(
            trigger="@",
            anchored_to_start=False,
            hide_on_exact_match=True,
            case_sensitive=False,
            candidates=tuple(
                TriggerSelectorCandidate(
                    value=candidate.path,
                    label=candidate.path,
                    description="Directory" if candidate.is_dir else "File",
                    insert_text=f"@{candidate.path}",
                    detail=str(self._root / candidate.path.rstrip("/")),
                    keep_open_on_exact_match=candidate.is_dir,
                )
                for candidate in self._candidates
            ),
        )

    def get_completions(
        self,
        document: Document,
        complete_event: CompleteEvent,
    ) -> Iterable[Completion]:
        del complete_event
        query = self._extract_query(document.text_before_cursor)
        if query is None:
            return
        normalized_query = query.casefold()
        for candidate in self._candidates:
            if candidate.path.casefold().startswith(normalized_query):
                yield Completion(
                    text=candidate.path,
                    start_position=-len(query),
                    display=candidate.path,
                    display_meta="Directory" if candidate.is_dir else "File",
                )

    def _load_candidates(self) -> tuple[FileContextCandidate, ...]:
        entries = list_project_entries(self._root)
        return tuple(
            FileContextCandidate(
                path=f"{entry.rel_path.as_posix()}/"
                if entry.is_dir
                else entry.rel_path.as_posix(),
                is_dir=entry.is_dir,
            )
            for entry in entries
        )

    @staticmethod
    def _extract_query(text_before_cursor: str) -> str | None:
        trigger_index = text_before_cursor.rfind("@")
        if trigger_index < 0:
            return None
        if trigger_index > 0 and not text_before_cursor[trigger_index - 1].isspace():
            return None
        query = text_before_cursor[trigger_index + 1 :]
        if any(character.isspace() for character in query):
            return None
        return query


class MultiCompleter(Completer):
    def __init__(self, completers: Sequence[Completer]) -> None:
        self._completers = tuple(completers)

    @property
    def selector_sources(self) -> tuple[TriggerSelectorSource, ...]:
        sources: list[TriggerSelectorSource] = []
        for completer in self._completers:
            selector_sources = getattr(completer, "selector_sources", None)
            if isinstance(selector_sources, tuple):
                sources.extend(
                    source
                    for source in selector_sources
                    if isinstance(source, TriggerSelectorSource)
                )
                continue

            selector_source = getattr(completer, "selector_source", None)
            if isinstance(selector_source, TriggerSelectorSource):
                sources.append(selector_source)
        return tuple(sources)

    def get_completions(
        self,
        document: Document,
        complete_event: CompleteEvent,
    ) -> Iterable[Completion]:
        for completer in self._completers:
            yield from completer.get_completions(document, complete_event)
