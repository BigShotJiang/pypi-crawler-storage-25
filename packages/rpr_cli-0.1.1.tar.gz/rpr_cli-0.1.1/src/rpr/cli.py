from __future__ import annotations

from typing import Annotated

import typer
from rpr import __version__
from rpr.ui.console import console

app = typer.Typer(
    name="rpr",
    help="RPR CLI -- React Python Rust monorepo scaffolding orchestrator.",
    no_args_is_help=False,
)

# --- Command Imports (must be after app is defined) ---
from rpr.commands import init as _init_mod  # noqa: E402, F401
from rpr.commands import check as _check_mod  # noqa: E402, F401
from rpr.commands import settings as _settings_mod  # noqa: E402, F401
from rpr.commands import map as _map_mod  # noqa: E402, F401
from rpr.commands import chat as _chat_mod  # noqa: E402, F401

generate_app = typer.Typer(
    name="generate",
    help="Scaffold apps and packages (api, ui, domain, engine, storybook).",
    no_args_is_help=True,
)
app.add_typer(generate_app, name="generate")

sync_app = typer.Typer(
    name="sync",
    help="Sync AI instructions to Cursor, Copilot, and Claude Code.",
    no_args_is_help=True,
)
app.add_typer(sync_app, name="sync")

add_app = typer.Typer(
    name="add",
    help="Add code templates to the current project.",
    no_args_is_help=True,
)
app.add_typer(add_app, name="add")

# Import subcommands
from rpr.commands.generate import domain as _domain_mod  # noqa: E402, F401
from rpr.commands.generate import api as _api_mod  # noqa: E402, F401
from rpr.commands.generate import ui as _ui_mod  # noqa: E402, F401
from rpr.commands.generate import engine as _engine_mod  # noqa: E402, F401
from rpr.commands.generate import storybook as _storybook_mod  # noqa: E402, F401
from rpr.commands import sync as _sync_mod  # noqa: E402, F401
from rpr.commands import add as _add_mod  # noqa: E402, F401


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"rpr {__version__}")
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            "-v",
            help="Show the version and exit.",
            callback=_version_callback,
            is_eager=True,
        ),
    ] = False,
) -> None:
    if ctx.invoked_subcommand is None:
        ctx.invoke(_chat_mod.chat)


if __name__ == "__main__":
    app()
