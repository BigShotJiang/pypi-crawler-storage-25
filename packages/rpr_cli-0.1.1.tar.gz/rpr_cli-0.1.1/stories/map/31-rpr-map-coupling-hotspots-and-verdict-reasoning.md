# RPR Map Coupling Hotspots and Verdict Reasoning

## User Story

As a developer reviewing architecture health, I want hotspot and chain analysis to explain the actual coupling bottlenecks and the reasoning behind the architectural verdict so that I can act on the report instead of guessing what it means.

## Domain Context

- **Bounded Context:** Code Mapping
- **Impacted Aggregates/Entities:** `DependencyGraph`, `ArchitectureAssessment`, `Hotspot`, `ArchitectureSignal`, `RepresentativeChain`, map output sections for architecture summary, chains, and hotspots

## Technical Implementation Plan

The current architecture assessment is conservative but shallow in presentation. `src/rpr/map/architecture.py` already computes top-level degrees, hotspots, and verdicts, while `src/rpr/map/chains.py` currently chooses bounded shortest paths from entries to leaves. This story should evolve those domain objects so the report explains why the verdict was chosen and which concrete files or modules are driving coupling.

Hotspot analysis should move beyond raw file count. Add ranked coupling metrics for fan-in and fan-out at both directory and file level, using `DependencyGraph.reverse_edges` and `DependencyGraph.edges` as the source of truth. The output should identify which concrete files inside broad directories such as `src/rpr` are the actual bottlenecks, instead of only labeling the parent directory as “large.” Preserve the existing hotspot concept, but expand it so a hotspot can carry metric evidence and representative file paths.

The architecture verdict should be accompanied by reasoning. When the result is `likely_onion`, `layered_but_mixed`, or `unclear`, the markdown should state the conditions that led there: detected entry areas, detected core areas, whether directory cycles exist, whether cycle density crossed the threshold, and whether bidirectional coupling or mixed-role hotspots affected the assessment. This reasoning should come from `ArchitectureAssessment` so it is testable and reusable, not reconstructed ad hoc in the renderer.

The chains section should be re-scoped from “shortest path” to “most meaningful coupling paths.” Replace or supplement the current shortest-path selection with ranked traversals based on import support count across directory edges or repeated file-edge participation. The goal is to surface the most-traversed architectural paths, because those expose real coupling pressure better than arbitrary nearest-leaf walks. Keep the selection bounded and deterministic so large repos still produce stable markdown. Retain the existing shortest-path chains in the `--details` appendix as a graph-debugging aid, because they are still useful when validating traversal correctness and resolver behavior.

This remains a vertical slice: CLI behavior stays stable unless a light option is needed for alternate ranking modes, map domain services compute richer evidence, and the renderer prints concise rankings and reasoning. Respect SRP by keeping metric computation in analysis modules and using `output.py` only for formatting.

## Dependency & Package Requirements

No new packages are required. Use the existing graph and topology data structures already available in the repository.

## Assumptions & Open Questions

- Fan-in and fan-out counts are the primary replacement signals for the current shallow hotspot summary.
- The default report should show only the top-ranked hotspots and coupling paths, with deterministic truncation for larger repositories.
- Open question: should verdict reasoning be a dedicated markdown section, or inline bullets directly under the verdict line in the architecture summary?

## Acceptance Criteria

- The generated map ranks hotspots using coupling metrics that include fan-in and fan-out, not only file-count thresholds.
- For any hotspot directory reported in the summary, the markdown also identifies the specific file-level bottlenecks that contribute to that hotspot.
- The architecture summary includes explicit reasoning for the reported verdict, including the presence or absence of entry areas, core areas, directory cycles, cycle density issues, and bidirectional coupling signals.
- The chains or coupling-path section ranks paths by coupling significance such as repeated edge support or traversal frequency rather than only by shortest-path distance.
- When `--details` is enabled, the report retains shortest-path chains in a diagnostic appendix so developers can still debug raw graph traversal behavior.
- The output remains deterministic across repeated runs on the same repository structure.
