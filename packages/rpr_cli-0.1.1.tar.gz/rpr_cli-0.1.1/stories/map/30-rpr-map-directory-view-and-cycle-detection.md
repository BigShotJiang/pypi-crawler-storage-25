# RPR Map Directory View and Cycle Detection

## User Story

As a developer inspecting repository structure, I want a clean directory-level architecture map with targeted module drill-down and explicit cycle reporting so that I can understand the system shape without reading a noisy file graph.

## Domain Context

- **Bounded Context:** Code Mapping
- **Impacted Aggregates/Entities:** `DependencyGraph`, `DirectoryTopology`, `ArchitectureAssessment`, `CycleSummary`, `RepresentativeChain`, `map` CLI command, Markdown map output

## Technical Implementation Plan

The current map pipeline already has the right seams for this slice: `src/rpr/commands/map.py` orchestrates the request, `src/rpr/map/extractor.py` and `src/rpr/map/graph.py` build the file graph, `src/rpr/map/topology.py` projects directory relationships, `src/rpr/map/architecture.py` summarizes architecture, and `src/rpr/map/output.py` renders the markdown. This story should keep those responsibilities intact.

Default output should become a directory-first view. The main Mermaid section should render only directory nodes and directory edges derived from `DirectoryTopology`, because the current production diagram becomes unreadable when every file is shown. File-level nodes should move behind an intentional drill-down flow for one selected module or directory. Add a CLI option such as `--focus src/rpr/map` or equivalent that constrains the detailed view to a chosen subtree while still showing its inbound and outbound directory relationships to preserve context. The focused view should append a second, module-specific diagram beneath the global directory view rather than replacing it, because preserving the repository-wide orientation is the safer default UX. Keep `--details` as a diagnostic appendix if it still has value, but it must no longer be the only way to obtain a readable high-level view.

Cycle detection must be elevated from a warning-oriented signal to a first-class architectural output. The graph layer already computes file cycles, and the architecture layer already derives directory projections. This story should make the cycle contract explicit by returning complete loop paths in deterministic order and surfacing both file-level and directory-level loops in the markdown. If a loop such as `ui -> application -> commands -> ui` exists, the map must show that full loop rather than only incrementing a hotspot count or emitting a generic warning. Preserve backend parity so the same cycle behavior is observed whether analysis comes from the Rust extension or the Python fallback.

From a SOLID and DDD perspective, keep cycle detection and drill-down selection in the domain/application pipeline rather than embedding traversal logic in the renderer. `output.py` should render already-computed views; selection and aggregation rules belong in the map domain modules. Avoid introducing a monolithic “report builder” that mixes CLI parsing, graph analysis, and formatting.

## Dependency & Package Requirements

No new packages are required. Use the existing standard-library and project dependencies already present in the map pipeline.

## Assumptions & Open Questions

- The primary user need is a readable default artifact, so directory-only must become the default architecture view.
- A focused drill-down should accept repository-relative directory paths rather than individual file paths for the first version.
- Open question: should directory cycles be reported only when they involve distinct directories, or should intra-directory file cycles also appear in the top-level cycle section?

## Acceptance Criteria

- Running `rpr map` without extra flags produces a readable top-level Mermaid diagram that contains directory nodes only and does not enumerate every file in the repository.
- Running `rpr map` with a focus option for a module or directory preserves the default top-level directory diagram and appends a drill-down section that shows file-level relationships for that selected scope plus its inbound and outbound dependencies to other directories.
- When the dependency graph contains one or more cycles, the generated markdown includes an explicit cycles section listing each full loop in traversal order at both file level and directory level.
- When no cycles exist, the map does not emit a false-positive cycle section and still renders the directory-only architecture view.
- Existing Rust-backed and Python-fallback map analysis paths produce the same observable cycle reporting and directory-view behavior for equivalent input graphs.
