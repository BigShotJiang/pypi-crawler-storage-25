# RPR Map External Dependencies, Responsibilities, and Structural Test Coverage

## User Story

As a developer using the code map as an architectural inventory, I want each reported module to show its external dependencies, a concise responsibility summary, and whether tests target it so that the map highlights what the code does and where maintenance risk is concentrated.

## Business Outcome

- `rpr map` produces a more actionable report by showing which directories pull in third-party packages, what each area appears to own, and where no test evidence is detected.
- Developers can review architecture health from one artifact instead of cross-checking imports, filenames, and test files manually.

## Domain Context

- **Bounded Context:** Code Mapping
- **Primary Capability:** Enrich the generated map with bounded module metadata derived from repository contents only.
- **Existing Artifacts Involved:** `rpr.commands.map.map`, `rpr.map.extractor.analyze_project`, `rpr.map.extractor.extract_imports_batch`, `rpr.map.graph.DependencyGraph`, `rpr.map.topology.DirectoryTopology`, `rpr.map.classifier.ClassifiedNode`, `rpr.map.output.write_map`
- **New or Updated Artifacts Likely Needed:** Likely new value objects and builders for `ExternalDependencySummary`, `ResponsibilitySummary`, and `StructuralCoverageSummary` in new `src/rpr/map/dependencies.py`, `src/rpr/map/responsibility.py`, and `src/rpr/map/coverage.py`. No new persistence, DTO, or repository artifacts are expected.

## Codebase Evidence

- `src/rpr/commands/map.py` - The `map` command already orchestrates graph analysis, classification, topology, architecture assessment, and markdown rendering, so this is the natural place to invoke additional enrichment builders.
- `src/rpr/map/extractor.py` - The Python fallback path already exposes `extract_imports` and `extract_imports_batch`, which can provide raw import strings needed to preserve unresolved third-party package evidence.
- `src/rpr/map/graph.py` - `DependencyGraph` currently models only in-repo edges and deliberately drops external imports during resolution, which means external-package reporting should remain a sibling analysis artifact unless this domain contract is intentionally expanded.
- `src/rpr/map/output.py` - `write_map()` already accepts multiple optional artifacts (`topology`, `assessment`, `chains`) and renders bounded sections, so the new summaries should be added here rather than building a second report path.
- `tests/test_map_extractor.py` - Existing tests already cover raw import extraction across Python, TypeScript, JavaScript, Rust, and C++, making this the nearest place to add unresolved external-import coverage.
- `tests/test_map_output.py` - The markdown renderer is already tested section-by-section, so this file should validate the new report sections, truncation, and omission rules.
- `tests/test_map.py` - CLI-level tests already verify `map`, `map --dry-run`, and `map --details`, so they should confirm the enriched report remains available through the existing command surface.

## File Touch Plan

| Path                               | Change | Reason                                                                                                                                                                                                                                                           |
| ---------------------------------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `src/rpr/commands/map.py`          | update | Invoke the new enrichment builders after `analyze_project()`, `classify()`, and `build_directory_topology()`, then pass the resulting artifacts into `write_map()` without changing the public CLI contract unless implementation proves a new flag is required. |
| `src/rpr/map/extractor.py`         | update | Expose backend-agnostic raw import inventory that can be reused for unresolved third-party package detection even when `analyze_project()` returns a Rust-backed graph.                                                                                          |
| `src/rpr/map/dependencies.py`      | create | Roll up unresolved raw imports into bounded per-directory external dependency summaries using the same repository-relative naming used by the existing topology output.                                                                                          |
| `src/rpr/map/responsibility.py`    | create | Derive deterministic one-line responsibility summaries from file names, docstrings, public symbol names, and dominant import patterns without involving network calls or LLM inference.                                                                          |
| `src/rpr/map/coverage.py`          | create | Compute structural test coverage evidence from graph edges and classified test nodes, with a constrained fallback naming heuristic when explicit import evidence is absent.                                                                                      |
| `src/rpr/map/output.py`            | update | Render new `External Dependencies`, `Responsibilities`, and `Structural Test Coverage` sections in the default report and focused drill-down output while keeping the markdown bounded.                                                                          |
| `src/rpr/map/graph.py`             | verify | Preserve the current meaning of `DependencyGraph` as the in-repo dependency graph; only update this file if implementation needs a shared helper or explicit contract field for enrichment inputs.                                                               |
| `tests/test_map_extractor.py`      | update | Cover unresolved external imports by language and confirm the raw import inventory remains deterministic when files cannot be resolved to in-repo edges.                                                                                                         |
| `tests/test_map_output.py`         | update | Assert the new sections render when data exists, stay absent when no evidence exists, and clearly distinguish strong import-based coverage from fallback name-based coverage.                                                                                    |
| `tests/test_map.py`                | update | Validate that `rpr map` and `rpr map --dry-run` surface the enriched report without breaking the existing command behavior.                                                                                                                                      |
| `tests/test_map_dependencies.py`   | create | Unit-test package rollups, directory grouping, deduplication, and per-language normalization of unresolved imports.                                                                                                                                              |
| `tests/test_map_responsibility.py` | create | Unit-test deterministic summary generation from filenames, docstrings, and import patterns, including ambiguous directories that should fall back to a neutral summary.                                                                                          |
| `tests/test_map_coverage.py`       | create | Unit-test direct import evidence, unique-name fallback matching, and exclusion rules for test files and unsupported coverage signals.                                                                                                                            |

## Technical Implementation Plan

### Vertical Slice Summary

`rpr map` should continue to build the resolved repository graph first, then run three sibling enrichment passes over the analyzed files: one to summarize unresolved external packages, one to produce per-module responsibility text, and one to map structural test evidence. The command should pass those artifacts into `write_map()` so the default markdown and any focused drill-down sections can show enriched architectural context without changing the existing graph, topology, or verdict pipelines.

### Entry Points and Orchestration

`src/rpr/commands/map.py` is the only expected orchestration change. After `analyze_project()`, `classify()`, `build_directory_topology()`, and `assess_architecture()`, it should call the new enrichment builders and pass their results to `write_map()`. No expected change to `src/rpr/cli.py` or `src/rpr/application/shell.py` because both already delegate to the `map` command and no new public option is required for the first slice.

### Domain and Application Changes

`src/rpr/map/extractor.py` should provide raw import inventory per discovered `SourceFile`, because that information is currently available in the Python helpers but is not surfaced as a reusable artifact in the `map` command path. `src/rpr/map/dependencies.py` should compare raw imports against the resolved in-repo edges and keep only unresolved third-party or system package identifiers, normalized by language into readable package names such as Python top-level modules, npm package specifiers, and Rust crate roots. `src/rpr/map/responsibility.py` should create deterministic summaries for the same directories or focused modules already used in topology output, using stable heuristics such as directory names, dominant file stems, module docstrings, and recurring import targets. `src/rpr/map/coverage.py` should consume `DependencyGraph`, `ClassifiedNode`, and the repository-relative test file set to compute strong coverage evidence from explicit test-to-production import edges, then apply a weaker fallback only when a `tests/test_<module>.py` style file maps uniquely to one production target. No new domain aggregate or persistence layer is expected.

### API, UI, Output, or Infrastructure Changes

No expected API or UI change. `src/rpr/map/output.py` should gain bounded sections for external dependencies, responsibilities, and structural test coverage in the default markdown flow that currently renders architecture summary, topology, chains, and hotspots. The renderer should keep section sizes capped, reuse existing directory labels, and mark weaker coverage signals explicitly instead of presenting them as equivalent to import-based evidence. If a focused view is active, the same enrichment data should be rendered for that scope rather than forcing the user to infer it from the full-repository summary.

### Data, Contracts, and Edge Cases

External dependency reporting should not silently convert unresolved imports into internal graph edges; the internal `DependencyGraph` contract should continue to represent only in-repo relationships unless implementation explicitly changes that model. Responsibility summaries must be deterministic and repository-derived, with a neutral fallback when filenames and docstrings do not provide a clear signal. Structural coverage in this slice is repository-structure coverage, not line coverage; it should treat explicit test imports as strong evidence and unique-name matching as fallback evidence only. Test files themselves must not be listed as uncovered modules. The first slice should document that inline Rust `#[cfg(test)]` blocks and external coverage reports are out of scope unless implementation later extends the analyzer to inspect those constructs directly.

### Testing and Validation Plan

- `tests/test_map_dependencies.py` - Verify unresolved imports are deduplicated, grouped by reported directory, and normalized sensibly for Python, TypeScript/JavaScript, Rust, and C++ sources.
- `tests/test_map_responsibility.py` - Verify one-line summaries are deterministic, stable across repeated runs, and fall back gracefully when heuristics are weak.
- `tests/test_map_coverage.py` - Verify direct test imports count as strong evidence, unique filename matches count only as fallback evidence, and ambiguous matches do not create false positives.
- `tests/test_map_extractor.py` - Verify raw import inventory still captures unresolved external imports and unreadable files continue to fail closed.
- `tests/test_map_output.py` - Verify markdown sections render only when evidence exists, truncate long inventories, and label fallback coverage clearly.
- `tests/test_map.py` - Verify CLI-generated reports and dry-run previews include the enriched sections without requiring new flags.
- Validation commands: `uv run pytest tests/test_map.py tests/test_map_extractor.py tests/test_map_output.py tests/test_map_dependencies.py tests/test_map_responsibility.py tests/test_map_coverage.py` and `uvx ruff check src/rpr/map tests`

## Dependency & Package Requirements

No new packages required.

## Assumptions & Open Questions

- The existing `write_map()` pattern of accepting optional analysis artifacts is the preferred extension point for this slice, rather than introducing a second report writer.
- The first version should keep external dependency summaries at the same directory granularity already used by `DirectoryTopology`, with focused module detail added only when `--focus` is already in use.
- Structural coverage should be presented as detected test evidence, not as a claim of full behavioral or line coverage.
- Open question: should directories under `rpr-parser/src` with inline Rust unit tests be labeled as `no test evidence detected` in the first slice, or should the report use a softer `coverage not analyzed` label for languages whose inline test syntax is not yet parsed?
- Open question: should responsibility summaries appear in the top-level summary only, or also inline inside the focused drill-down section for `--focus` output when that would duplicate text?

## Acceptance Criteria

- Running `rpr map` produces a markdown report that includes bounded sections for external dependencies, responsibility summaries, and structural test coverage when the repository contains evidence for them.
- External dependency reporting groups unresolved third-party packages by reported module or directory without changing the meaning of the internal dependency graph or inventing new in-repo edges.
- Responsibility summaries are deterministic, derived from repository contents only, and do not require network calls or LLM inference at map-generation time.
- A test file that explicitly imports a production module is reported as strong coverage evidence for that module, while any weaker filename-based match is labeled as fallback evidence and used only when it resolves uniquely.
- Production modules or directories with no detected test evidence are surfaced in the report, and test files themselves are not misclassified as uncovered production code.
- The enriched sections remain bounded and readable in the default report and continue to work through the existing `rpr map` and `rpr map --dry-run` flows.
