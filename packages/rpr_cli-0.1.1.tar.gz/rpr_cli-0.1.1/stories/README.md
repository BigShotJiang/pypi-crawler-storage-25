# RPR CLI Stories

Use these story files to track the work for the `rpr` CLI independently from implementation.

## Purpose of the CLI

**RPR** (Repository Project Runner) is a scaffolding and orchestration CLI for NX + UV monorepos with a DDD-style architecture. It:

1. **Bootstraps** — Creates or augments NX + UV workspaces with a standard layout (apps, packages/node, packages/python).
2. **Generates** — Scaffolds domain (Python DDD), API (FastAPI), UI (React + TanStack + MUI), Rust engine (PyO3), and Storybook.
3. **Syncs AI instructions** — Writes when-to-use guidance to Cursor, VS Code Copilot, Claude, and Gemini so AI tools follow project conventions.
4. **Adds templates** — Injects code from special files (mapper_util, dto_util, fetch_service, etc.) into the project with variables replaced.

The CLI treats this repo as the single source of truth: bundled instructions live in `src/rpr/scaffolds/instructions/`, reference mirrors live in `Sample-dot-github/instructions/`, and code templates live in `special_files/` and `js_special_files/`. It orchestrates external tools (nx, uv, npx, npm) and always displays commands before execution.

## Working Rules

- Every command must support `--dry-run`.
- Always display the command when executing another CLI (per Story 00).
- Use `uv` for Python dependency management.
- Use `uv tool install` for CLI installation.
- Use `uv add` for dependency changes that should be stored in `pyproject.toml`.
- Prefer `uv run` when wiring Python commands into `npx nx`.

## Recommended Order

- [x] `00-bootstrap-cli.md`
- [x] `01-rpr-init.md`
- [x] `02-rpr-generate-domain.md`
- [x] `03-rpr-generate-api.md`
- [x] `04-rpr-generate-ui.md`
- [x] `05-rpr-generate-engine.md`
- [x] `06-rpr-generate-storybook.md`
- [x] `07-rpr-sync-rules.md`
- [x] `08-rpr-add-template.md`
- [x] `09-rpr-check.md`

## Additional Tracks

### Code Mapping

- [x] `map/11-rpr-map-command.md`
- [x] `map/12-rpr-map-file-walker.md`
- [x] `map/13-rpr-map-rust-engine.md`
- [x] `map/14-rpr-map-graph-builder.md`
- [x] `map/15-rpr-map-analysis-bridge.md`
- [x] `map/16-rpr-map-layer-classifier.md`
- [x] `map/17-rpr-map-output.md`
- [x] `map/17a-rpr-map-directory-topology.md`
- [x] `map/17b-rpr-map-architecture-assessment.md`
- [x] `map/17c-rpr-map-representative-chains.md`
- [x] `map/17d-rpr-map-multi-resolution-output.md`
- [x] `map/17e-rpr-map-unwrap-wrappers.md`
- [x] `map/17f-rpr-map-mermaid-formatting.md`
- [x] `map/17g-rpr-map-topology-mermaid-diagram.md`
- [x] `map/30-rpr-map-directory-view-and-cycle-detection.md`
- [x] `map/31-rpr-map-coupling-hotspots-and-verdict-reasoning.md`
- [x] `map/32-rpr-map-dependencies-responsibilities-and-test-coverage.md`

### Chat and Terminal UX

- [x] `chat/18-rpr-terminal-ui-foundation.md`
- [x] `chat/19-rpr-markdown-rendering.md`
- [x] `chat/20-rpr-chat-repl.md`
- [x] `chat/21-rpr-agent-tool-loop.md`
- [x] `chat/22-rpr-chat-tui.md`
- [x] `chat/23-rpr-chat-unified-command-shell.md`
- [x] `chat/24-rpr-async-chat-runtime-and-services.md`
- [x] `chat/25-rpr-prompt-service-and-conversation-lifecycle.md`
- [x] `chat/26-rpr-shared-command-catalog.md`
- [x] `chat/27-rpr-slash-command-selection-panel.md`
- [x] `chat/28-rpr-chat-cancellable-and-multiline-input.md`
- [x] `chat/29-rpr-file-context-selection.md`

## Dependency Notes

- Story `00` is the foundation for everything else.
- Story `01` (init) scaffolds the workspace and runs `rpr sync rules` (or equivalent) to create AI instructions; it does not add special files.
- Story `02` should happen before story `03` because the API depends on the domain package.
- Story `04` should happen before story `06` because Storybook depends on the UI package.
- Story `07` (sync rules) syncs instructions only; Story `08` (add template) adds special files. Init uses sync rules; domain/UI generators can prompt the user to run add template for utilities.
- Story `09` (check) can be built any time after story `00`; it is read-only and has no prerequisites of its own. It becomes more useful as other commands are implemented, since it reports on what they produce.
- Story `18` is the presentation foundation for all later chat work and should happen before stories `19` through `22`.
- Story `19` improves markdown previews for standard commands and should be implemented before `rpr map` or `rpr chat` starts emitting markdown-heavy terminal output.
- Stories `20`, `21`, and `22` are an ordered sequence: REPL first, then tool loop and approvals, then the full-screen TUI.
- Story `23` follows story `22` and consolidates chat into a single primary interactive shell with shared slash-command routing for chat and CLI command execution.
- Story `24` follows story `23` and moves the primary chat shell onto async application services with clearer orchestration boundaries.
- Story `25` follows story `24` and introduces a singleton prompt service plus conversation lifecycle management with a persistence seam for future SQLite history.
- Story `26` follows story `25` and defines the shared typed command catalog consumed by both chat and top-level CLI adapters.
- Story `27` follows story `26` and adds the slash-command selection panel and keyboard navigation driven by the shared command catalog.
- Story `13` is the production analysis engine for the map pipeline.
- Story `14` defines the shared dependency-graph contract and the Python fallback graph builder.
- Story `15` delegates whole-project dependency analysis to story `13` when available and falls back to the Python path from stories `12` and `14` when it is not.
