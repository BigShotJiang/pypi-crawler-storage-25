# Story 03: `rpr generate api <name>`

## User Story

As a developer, I want to run `rpr generate api my-app` to scaffold a FastAPI application so that I can execute it with `npx nx serve my-app-api`.

## Goal

Generate a FastAPI app that is managed by NX but executed through UV, matching the backend patterns defined in the project guidance.

## Acceptance Criteria

- [ ] Creates `apps/<name>-api/`.
- [ ] Always displays the command before executing nested CLIs (per Story 00).
- [ ] Creates a `pyproject.toml` that depends on `<name>-domain` through the UV workspace.
- [ ] Creates `project.json` with `serve`, `test`, and `lint` targets.
- [ ] Uses `uv run uvicorn` for the `serve` target.
- [ ] Scaffolds `main.py` with app factory, lifespan, middleware, and exception handling.
- [ ] Creates at least one example route file.
- [ ] Adds the app to the UV workspace members list.
- [ ] Prompts for `<name>` if omitted.
- [ ] Supports `--dry-run`; forwards to nested CLI when supported, else shows command only.

## Key Files

- `src/rpr/commands/generate/api.py`
- `src/rpr/scaffolds/api/`

## Notes

- This story depends on the domain package from Story `02`; the API consumes the domain layer.
- NX should orchestrate the app, but UV should execute the Python runtime commands.
- Keep route handlers light and align the scaffolding with your API guidance markdown.

## Definition of Done

- [ ] `npx nx serve <name>-api` maps to a UV-powered FastAPI startup command.
- [ ] Generated files follow the monorepo structure you described.
- [ ] The dry-run output clearly shows the workspace changes and generated files.
