# Story 09: `rpr check`

## User Story

As a developer, I want to run `rpr check` in any project directory and get a clear summary of what has and hasn't been set up, along with actionable recommendations, so that I know exactly which `rpr` commands to run next.

## Goal

Inspect the current project directory and report the setup status of every area the `rpr` CLI manages. Prioritize AI instructions and special templates (the most important things to get right), then report on generated packages and apps. Output should be scannable and actionable — not a wall of text.

## Output Format

Use a structured table or grouped checklist. Each area shows a status and a suggested command when the area is incomplete:

```
rpr check — project: my-app

Priority: AI Instructions & Templates
  [✓] Cursor rules          .cursor/rules/ (5 files)
  [✗] Copilot instructions  missing → run: rpr sync rules --target copilot
  [✗] CLAUDE.md             missing → run: rpr sync rules --target claude
  [✓] mapper_util           packages/python/domain/src/my_app_domain/utils/mapper_util.py
  [✗] dto_util              missing → run: rpr add template dto_util
  [✗] partial_update        missing → run: rpr add template partial_update
  [✗] fetch_service         missing → run: rpr add template fetch_service
  [✗] sticky_navigation     missing → run: rpr add template sticky_navigation

Workspace
  [✓] NX workspace          nx.json found
  [✓] UV workspace          pyproject.toml with [tool.uv.workspace] found
  [✓] .rpr.yaml             project: my-app

Generated Packages & Apps
  [✓] Domain package        packages/python/domain/
  [✗] API app               missing → run: rpr generate api my-app
  [✓] UI library            packages/node/my-app-ui/
  [✗] Storybook             missing → run: rpr generate storybook
  [✗] Engine                missing → run: rpr generate engine my-app
```

If `.rpr.yaml` is missing, the project name is unknown and the command should still run, showing `project: (unknown)` and treating all variable-dependent paths as unresolvable until `.rpr.yaml` is created.

## Check Areas

### Priority Group: AI Instructions & Templates

These are checked first because they directly affect the AI tools in every session.

| Area | Detection | Missing Suggestion |
|------|-----------|-------------------|
| Cursor rules | `.cursor/rules/*.mdc` exists and is non-empty | `rpr sync rules --target cursor` |
| Copilot instructions | `.github/copilot-instructions.md` exists | `rpr sync rules --target copilot` |
| Claude instructions | `CLAUDE.md` (or `.claude/CLAUDE.md`) exists | `rpr sync rules --target claude` |
| `mapper_util` | `*_domain/utils/mapper_util.py` exists | `rpr add template mapper_util` |
| `dto_util` | `*_domain/utils/dto_util.py` exists | `rpr add template dto_util` |
| `partial_update` | `*_domain/utils/partial_update.py` exists | `rpr add template partial_update` |
| `encrypted_column` | `*_domain/utils/encrypted_column.py` exists | `rpr add template encrypted_column` |
| `fetch_service` | `*-ui/src/services/base/api.service.ts` exists | `rpr add template fetch_service` |
| `sticky_navigation` | `*-ui/src/hooks/useStateNavigation.ts` exists | `rpr add template sticky_navigation` |

Templates are only checked when the prerequisite package exists (e.g., Python templates are skipped if no domain package is found; JS templates are skipped if no UI library is found).

### Workspace Group

| Area | Detection | Missing Suggestion |
|------|-----------|-------------------|
| NX workspace | `nx.json` exists | `rpr init <name>` |
| UV workspace | `pyproject.toml` with `[tool.uv.workspace]` section | `rpr init <name>` |
| `.rpr.yaml` config | `.rpr.yaml` exists with a `variables:` block | `rpr init <name>` |

### Generated Packages & Apps Group

| Area | Detection | Missing Suggestion |
|------|-----------|-------------------|
| Domain package | `packages/python/domain/` directory exists | `rpr generate domain <name>` |
| API app | `apps/*-api/` directory exists | `rpr generate api <name>` |
| UI library | `packages/node/*-ui/` directory exists | `rpr generate ui <name>` |
| Storybook | `packages/node/sb/` directory exists | `rpr generate storybook` |
| Engine | `packages/python/*-engine/` directory exists | `rpr generate engine <name>` |

## Acceptance Criteria

- [ ] `rpr check` runs without arguments; reads `.rpr.yaml` for project name and variables.
- [ ] Outputs a grouped, scannable status report with `[✓]` / `[✗]` indicators.
- [ ] AI instructions and templates are shown **first** (highest priority group).
- [ ] Each missing area shows the exact `rpr` command to fix it.
- [ ] Template checks are skipped when the prerequisite package does not exist (avoids false negatives).
- [ ] Works without `.rpr.yaml`; displays `project: (unknown)` and skips variable-dependent path checks gracefully.
- [ ] Does not modify any files; this is a read-only inspection command.
- [ ] Supports `--json` flag to emit machine-readable output (for scripting or CI).
- [ ] Exit code is `0` when all checks pass; non-zero when any area is missing (useful for CI).
- [ ] Supports `--group <group-name>` to run only a specific group (e.g., `rpr check --group instructions`).

## Key Files

- `src/rpr/commands/check.py`
- `src/rpr/checks/` (one checker module per group, e.g., `instructions.py`, `workspace.py`, `packages.py`)

## Notes

- The check command is intentionally read-only. It never creates files, runs generators, or invokes nested CLIs.
- Suggestions shown in the output are informational; the user must choose to act on them.
- The `--json` flag is useful for automation, linting in CI, or editor integrations that want to surface missing setup.
- When a new `rpr` command is added (e.g., a new `rpr generate` type), add a corresponding check to keep the report up to date.
- Check modules should be easy to extend: each checker returns a list of `CheckResult(area, status, path, suggestion)` objects that the output formatter renders.

## Definition of Done

- [ ] `rpr check` runs in any project directory and produces a structured report.
- [ ] AI instructions and templates are grouped at the top and always checked.
- [ ] Each missing item shows the exact command to resolve it.
- [ ] Template checks are conditional on prerequisite packages existing.
- [ ] Exit code reflects overall pass/fail status.
- [ ] `--json` output is valid JSON matching a documented schema.
- [ ] The command is documented in `rpr --help` under a `check` subcommand.
