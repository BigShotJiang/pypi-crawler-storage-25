# Story 07: `rpr sync rules`

## User Story

As a developer, I want to run `rpr sync rules` to write my AI instructions to all target tools so that Cursor, GitHub Copilot, Claude Code, and Gemini CLI all follow the same conventions.

## Goal

Treat this repo as the source of truth for AI **instructions** (when-to-use guidance) and generate tool-specific instruction files into a target project. This command syncs **instructions only** — it does not add special files (code templates). Use `rpr add template` for that.

## Instructions vs Special Files

| Type              | Source                                              | Synced By          | Purpose                                                                          |
| ----------------- | --------------------------------------------------- | ------------------ | -------------------------------------------------------------------------------- |
| **Instructions**  | `src/rpr/scaffolds/instructions/` (bundled default) | `rpr sync rules`   | When-to-use guidance; tells AI when to apply patterns, reference utilities, etc. |
| **Special files** | `special_files/`, `js_special_files/`               | `rpr add template` | Code templates; actual implementation to generate                                |

Instructions are short and reference patterns. They do not contain full implementations. Special files contain the code; `rpr add template` extracts and writes them.

## Target Platforms

| Platform              | Output Location                      | Format                                                                                                                                |
| --------------------- | ------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------- |
| **VS Code / Copilot** | `.github/copilot-instructions.md`    | Single always-on file per [VS Code custom instructions](https://code.visualstudio.com/docs/copilot/customization/custom-instructions) |
| **Cursor**            | `.cursor/rules/*.mdc`                | One `.mdc` file per rule; keep each rule small and focused                                                                            |
| **Claude**            | `CLAUDE.md` (or `.claude/CLAUDE.md`) | Single always-on instructions file                                                                                                    |
| **Gemini CLI**        | TBD (config format for Gemini CLI)   | CLI-specific instruction format                                                                                                       |

## Source Structure

- `src/rpr/scaffolds/instructions/` — bundled default source for instructions (e.g., `all.instructions.md`, `api.instructions.md`, `frontend.instructions.md`, `tooling.instructions.md`, `tooling-setup.instructions.md`)
- `Sample-dot-github/instructions/` — reference mirror of the bundled instruction set
- `all.instructions.md` → `.github/copilot-instructions.md` (project-wide)
- File-specific instructions use `applyTo` / `globs` for scoping
- Reference scaffolds can live under `.github/scaffolds/` when the target project includes them, but sync rules should treat those files as optional examples rather than mandatory output.

## Variable Token Substitution

The command reads project variables from `.rpr.yaml` under the `variables:` key (written by `rpr init`). Before writing any output file, replace all tokens in **both file content and output file paths**:

| Token               | Value source                | Example (`my-app`) |
| ------------------- | --------------------------- | ------------------ |
| `{name}`            | `variables.name`            | `my-app`           |
| `{name-of-app}`     | `variables.name-of-app`     | `my-app`           |
| `{name_underscore}` | `variables.name_underscore` | `my_app`           |
| `{NamePascal}`      | `variables.NamePascal`      | `MyApp`            |

If `.rpr.yaml` is missing or has no `variables:` block, the command must prompt the user for the project name and derive the variants on the fly, then warn that `.rpr.yaml` is not configured.

## `.mdc` Frontmatter Conversion (Cursor Rules)

Source `.instructions.md` files carry YAML frontmatter with `applyTo` and `description`. When generating `.mdc` files for Cursor, convert each field as follows:

| Source field (`applyTo` + `description`) | `.mdc` field  | Conversion rule                                |
| ---------------------------------------- | ------------- | ---------------------------------------------- |
| `description`                            | `description` | Copy verbatim                                  |
| `applyTo`                                | `globs`       | Copy verbatim (already a glob string)          |
| _(derived from `applyTo`)_               | `alwaysApply` | `true` if `applyTo == "**"`, otherwise `false` |

**Examples:**

`all.instructions.md` source frontmatter:

```yaml
applyTo: "**"
description: "Project overview, monorepo structure, and tech stack"
```

Produces `.cursor/rules/all.mdc`:

```yaml
---
description: "Project overview, monorepo structure, and tech stack"
globs: "**"
alwaysApply: true
---
```

`domain.instructions.md` source frontmatter:

```yaml
applyTo: "packages/python/domain/**"
description: "Domain layer structure, entities, DTOs, repos, and workflows"
```

Produces `.cursor/rules/domain.mdc`:

```yaml
---
description: "Domain layer structure, entities, DTOs, repos, and workflows"
globs: "packages/python/domain/**"
alwaysApply: false
---
```

Variable substitution is applied to the **body content** of each rule after frontmatter is extracted. The `globs` value is **not** variable-substituted (it is a workspace-relative path pattern, not a project-name token).

## `.rpr.yaml` Configuration Reference

`rpr sync rules` reads the following fields from `.rpr.yaml`:

```yaml
source: "src/rpr/scaffolds/instructions"
variables:
  name: "my-app"
  name-of-app: "my-app"
  name_underscore: "my_app"
  NamePascal: "MyApp"
targets:
  - cursor
  - copilot
  - claude
  - gemini
include: [] # optional: limit to specific instruction files
exclude: [] # optional: skip specific instruction files
```

## Acceptance Criteria

- [ ] Reads source markdowns from the `source` path in `.rpr.yaml`.
- [ ] Reads `variables:` block from `.rpr.yaml`; prompts and warns if missing.
- [ ] Syncs instructions from the configured bundled source path; does not add special files.
- [ ] Generates Cursor rule files in `.cursor/rules/` as `.mdc` files with correct `description`, `globs`, and `alwaysApply` frontmatter (see conversion table above).
- [ ] Sets `alwaysApply: true` only for rules where source `applyTo` is `"**"`.
- [ ] Generates Copilot file at `.github/copilot-instructions.md` (from `all.instructions.md`).
- [ ] Generates `CLAUDE.md` for Claude Code.
- [ ] Replaces all variable tokens (`{name}`, `{name-of-app}`, `{name_underscore}`, `{NamePascal}`) in file content before writing.
- [ ] Does **not** substitute tokens inside `globs` frontmatter values.
- [ ] Adds a generated-file header to managed files so they can be identified and re-synced.
- [ ] Supports `--target` to sync a single platform (e.g., `--target cursor`).
- [ ] Supports `--dry-run`.
- [ ] Always displays the command or file operations before executing (per Story 00).

## Key Files

- `src/rpr/commands/sync.py`
- `src/rpr/generators/base.py`
- `src/rpr/generators/cursor.py`
- `src/rpr/generators/copilot.py`
- `src/rpr/generators/claude.py`
- `src/rpr/scaffolds/instructions/`
- `Sample-dot-github/instructions/`

## Notes

- Preserve single-source-of-truth: instructions live in this repo; sync writes tool-specific output.
- Keep generator logic separate per target so future AI tools can be added cleanly.
- Avoid destructive overwrite for files not managed by rpr.
- Instructions = when to use; special files = what to generate. Sync rules handles instructions; add template handles special files.

## Definition of Done

- [ ] Sync works for all supported targets (Cursor, Copilot, Claude, Gemini TBD).
- [ ] Cursor `.mdc` files have correct `globs` and `alwaysApply` derived from source `applyTo`.
- [ ] `alwaysApply: true` is only set for project-wide rules (`applyTo: "**"`).
- [ ] All four variable tokens are replaced in file content; `globs` values are never substituted.
- [ ] Variables are read from `.rpr.yaml`; missing config triggers a prompt and warning.
- [ ] Generated files are clearly marked as managed (generated-file header).
- [ ] Dry-run shows every file that would be created or updated.
- [ ] Sync does not add special files; that is `rpr add template`.
