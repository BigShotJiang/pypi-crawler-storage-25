# Story 04: `rpr generate ui <name>`

## User Story

As a developer, I want to run `rpr generate ui my-app` to scaffold both the thin React app and the reusable UI library, so that I have a runnable client plus a shared frontend package with the expected stack ready to develop.

## Goal

Generate the Node-side frontend structure for both of these outputs:

1. **Thin client app** at `apps/<name>/` — the web application shell
2. **UI library** at `packages/node/<name>-ui/` — reusable components, hooks, services, state

The current generator always creates both in one command.

## Tech Stack (Required Packages)

The UI uses:

- **TanStack Query** — state management and integration with services
- **TanStack Router** — routing
- **MUI (Material-UI)** — component library

## Package Installation

The command writes app- and library-level `package.json` files, then runs `npm install` at the workspace root.

**Required packages**:

| Package                             | Purpose                               |
| ----------------------------------- | ------------------------------------- |
| `@tanstack/react-query`             | State management, service integration |
| `@tanstack/react-router`            | Routing                               |
| `@mui/material`                     | Component library                     |
| `@emotion/react`, `@emotion/styled` | MUI peer deps                         |

Install only packages that are not already listed in the target `package.json` files.

## Generated Frontend Tooling

Each generated frontend project should include:

- A project-local `eslint.config.mjs` that extends the root flat config
- A `lint` target that runs `npx eslint .`
- A separate `typecheck` target that runs `npx tsc --noEmit`
- Vite config for the app and Vitest test target for the UI library

## Special JS Files (Internal Code Templates)

The UI library uses `fetch_service` and `sticky_navigation` — these are internal template sources added via `rpr add template`, not synced instruction files and not part of `generate ui` directly.

| Template ID         | Source                                  | Output                                                     |
| ------------------- | --------------------------------------- | ---------------------------------------------------------- |
| `fetch_service`     | `js_special_files/fetch.service.md`     | `packages/node/<name>-ui/src/services/base/api.service.ts` |
| `sticky_navigation` | `js_special_files/sticky-navigation.md` | `packages/node/<name>-ui/src/hooks/useStateNavigation.ts`  |

After generating the UI library, the user runs `rpr add template fetch_service` and `rpr add template sticky_navigation` to add these files. Optionally, generate ui can offer to run `rpr add template` for both when creating the library.

## Execution Order

1. Create the UI library folders and files.
2. Create the frontend app folders and files.
3. Write project-level `package.json`, `project.json`, `tsconfig.json`, and `eslint.config.mjs` files.
4. Run `npm install` at the workspace root.

## Dry Run

- When `--dry-run` is passed, preview all generated files and skip `npm install`.
- Use dry-run in tests with a fake app to verify the intended file tree.

## Acceptance Criteria

- [ ] Creates both `apps/<name>/` and `packages/node/<name>-ui/`.
- [ ] Writes app and library `package.json` files with the required frontend dependencies.
- [ ] Creates `project.json` files with `lint` targets that run `npx eslint .`.
- [ ] Creates `project.json` files with `typecheck` targets that run `npx tsc --noEmit`.
- [ ] Writes project-local `eslint.config.mjs` files for both the app and the UI library.
- [ ] Runs `npm install` after scaffolding.
- [ ] Leaves `fetch_service` and `sticky_navigation` as follow-up `rpr add template` steps.
- [ ] Prompts for `<name>` if omitted.
- [ ] Supports `--dry-run`; previews generated files and skips installation.

## Key Files

- `src/rpr/commands/generate/ui.py`
- `js_special_files/fetch.service.md`
- `js_special_files/sticky-navigation.md`

## Notes

- The UI package holds hooks, components, services, and state.
- TanStack Query is used for state management and service integration; TanStack Router for routing; MUI for components.
- The app stays thin and consumes the UI package.
- Linting is handled by ESLint; typechecking remains a separate NX target.
- Prepares the project for Storybook later.

## Definition of Done

- [ ] The thin app and UI library are both scaffolded in one command.
- [ ] Each generated project has ESLint config plus separate lint and typecheck targets.
- [ ] TanStack Query, TanStack Router, and MUI dependencies are installed through the generated `package.json` files.
- [ ] Special JS files (fetch service, useStateNavigation) remain `rpr add template` follow-ups.
- [ ] Generated app is runnable via NX.
- [ ] Dry-run output is verifiable in tests.
