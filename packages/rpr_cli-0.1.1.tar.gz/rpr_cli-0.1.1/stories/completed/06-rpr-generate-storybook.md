# Story 06: `rpr generate storybook`

## User Story

As a developer, I want to run `rpr generate storybook` to add a Storybook package so that I can develop and test UI components in isolation.

## Goal

Generate the Storybook package only after a UI package exists, and wire it to consume stories from the UI layer.

## UI Package Detection

Before running any generator, the command must confirm that at least one UI library exists:

1. Look for directories matching `packages/node/*-ui/` that contain a `project.json` or `package.json`.
2. If none are found, print a clear error and exit:
   ```
   [rpr] Error: No UI library found at packages/node/*-ui/. Run `rpr generate ui <name>` first.
   ```
3. If more than one UI library exists, prompt the user to choose which one Storybook should target.

## NX Generator

Use the `@nx/storybook` plugin to configure Storybook for the UI library:

```bash
nx g @nx/storybook:configuration --project=<name>-ui --uiFramework=@storybook/react-vite
```

Then create the `packages/node/sb/` package manually (or via a secondary generator) to hold a standalone Storybook entrypoint that imports stories from the UI library.

Alternatively, if Storybook is configured directly on the UI library project, `packages/node/sb/` acts as a thin launcher with its own `project.json`.

Always display the NX command before executing (per Story 00).

## Acceptance Criteria

- [ ] Detects at least one UI library at `packages/node/*-ui/`; fails with a clear message if none is found.
- [ ] Prompts the user to choose a target UI library when more than one exists.
- [ ] Creates `packages/node/sb/` as the Storybook host package.
- [ ] Always displays the NX command before executing nested CLIs (per Story 00).
- [ ] Runs `nx g @nx/storybook:configuration --project=<name>-ui --uiFramework=@storybook/react-vite` (or equivalent) and displays it first.
- [ ] Configures Storybook to discover stories from `packages/node/<name>-ui/src/**/*.stories.{ts,tsx}`.
- [ ] Creates a `project.json` for `packages/node/sb/` with `storybook` and `build-storybook` NX targets (see NX Targets below).
- [ ] Writes at least one starter story file at `packages/node/<name>-ui/src/stories/Example.stories.tsx`.
- [ ] Supports `--dry-run`; forwards to nested CLI when supported, else shows command only.

## NX Targets

The `project.json` for `packages/node/sb/` must define:

| Target | Command |
|--------|---------|
| `storybook` | `storybook dev -p 6006 -c packages/node/sb/.storybook` |
| `build-storybook` | `storybook build -c packages/node/sb/.storybook -o dist/storybook` |

## Generated File Manifest

```
packages/node/sb/
├── package.json
├── project.json
└── .storybook/
    ├── main.ts          # references stories from <name>-ui
    └── preview.ts       # MUI ThemeProvider setup

packages/node/<name>-ui/src/stories/
└── Example.stories.tsx  # starter story
```

## Key Files

- `src/rpr/commands/generate/storybook.py`
- `src/rpr/scaffolds/storybook/`

## Notes

- This story depends on Story `04`.
- Keep `packages/node/sb/` focused on Storybook config, preview setup, and starter stories only.
- The command should not guess too much if no UI package is present; fail loudly and clearly.
- The `.storybook/main.ts` `stories` glob should point at the UI library, not the `sb/` package itself.

## Definition of Done

- [ ] Storybook package is generated with runnable `storybook` and `build-storybook` NX targets.
- [ ] UI package detection works; helpful error shown when the prerequisite is missing.
- [ ] Stories glob in `.storybook/main.ts` points at the correct UI library path.
- [ ] At least one starter story exists in the UI library.
- [ ] Dry-run mode previews Storybook generation without writing files.
