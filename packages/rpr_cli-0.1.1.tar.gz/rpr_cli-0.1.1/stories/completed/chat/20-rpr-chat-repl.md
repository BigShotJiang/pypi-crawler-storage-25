# Story 20: `rpr chat` — Interactive Project-Aware REPL

## User Story

As a developer, I want to run `rpr chat` and hold a persistent terminal conversation about the current repository so that I can ask questions, generate plans, and inspect code without leaving the CLI.

## Details

Introduce a new top-level `rpr chat` command that starts an interactive REPL loop. The user types prompts, receives streamed responses, and can continue the same conversation until exiting. The chat session is aware of the current working directory and can include project metadata, the active configuration, and optional read-only repository context.

This first story focuses on the REPL, not the full Claude-Code-style UI. The command should support:

- multi-turn conversation state for a single session
- `exit`, `quit`, and Ctrl-D to leave cleanly
- a visible session header showing project root and active model/provider
- streaming assistant output if the provider supports it
- clean markdown rendering for assistant responses using the shared markdown UI

A provider abstraction should be introduced now even if only one provider is implemented first. The chat loop should depend on an `AgentClient` interface rather than hardcoding a single SDK.

## Assumptions

- The first implementation may use a single configured provider, but the command surface should not assume one specific vendor forever.
- Conversation state is in-memory for a single session in this story; persistence comes later.
- The REPL is terminal-first and does not yet include side panes, file browser, or tool approvals.

## Acceptance Criteria

- [ ] `rpr chat` is registered as a top-level command in `src/rpr/cli.py`.
- [ ] Running `rpr chat` starts an interactive prompt loop until the user exits.
- [ ] The session displays the current project root and active provider/model at startup.
- [ ] Assistant responses are rendered as markdown in terminal.
- [ ] Streaming output is used when supported by the provider.
- [ ] A provider interface exists in `src/rpr/agent/` or equivalent so the REPL is not tied directly to one SDK.
- [ ] Errors from the provider are shown as styled terminal errors and the REPL remains usable.
- [ ] Tests cover startup, graceful exit commands, and provider-error handling with a fake client.
