# Story 18: Shared Terminal UI Foundation — Rich Rendering for All Commands

## User Story

As a developer using `rpr`, I want all commands to render consistent, polished terminal output so that the CLI feels intentional and easier to scan during scaffolding, checks, and agent workflows.

## Details

Create a shared UI module under `src/rpr/ui/` that wraps Rich primitives and becomes the single rendering layer for all command output. The goal is to eliminate ad hoc `console.print(...)` formatting spread across commands and replace it with reusable render helpers for headings, status rows, command previews, code blocks, markdown panels, errors, warnings, tables, progress, and diff previews.

The foundation should work for both normal commands and future interactive modes. It should expose a small set of stable functions or classes, such as `render_command_start(...)`, `render_success(...)`, `render_warning(...)`, `render_markdown(...)`, and `render_file_preview(...)`, instead of letting each command manually compose Rich markup.

The style system should define a consistent visual language:

- a small color palette for success, warning, error, info, and muted output
- consistent panel titles and padding
- command previews that clearly distinguish shell execution from file writes
- dry-run output that is visually distinct from real writes

This story is the foundation for Markdown rendering in other commands and for the chat/TUI stories that follow.

## Assumptions

- Rich remains the primary terminal-rendering dependency.
- Existing command behavior does not change semantically; only presentation is refactored.
- The UI layer is pure presentation and does not contain command logic.
- Commands continue to support plain stdout-friendly operation for scripting where needed via existing machine-readable flags like `--json`.

## Acceptance Criteria

- [ ] A new package exists at `src/rpr/ui/`.
- [ ] The package exposes a shared `Console` instance and reusable render helpers for success, warning, error, headings, tables, command previews, and file previews.
- [ ] `RunContext` in `src/rpr/context.py` delegates its terminal rendering to the shared UI layer rather than printing inline Rich markup directly.
- [ ] At least one existing non-trivial command (`rpr check`) is refactored to use the shared UI helpers.
- [ ] Dry-run output is rendered through the same UI layer and remains visually distinct from real execution.
- [ ] A small theme or style registry is defined in one place instead of hardcoding colors in multiple modules.
- [ ] Tests cover at least one helper that renders deterministic text via Rich's recording console or equivalent snapshot-style assertions.
