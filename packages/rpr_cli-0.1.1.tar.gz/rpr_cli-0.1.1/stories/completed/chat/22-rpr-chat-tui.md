# Story 22: `rpr chat --tui` — Full-Screen Claude-Code-Style Interface

## User Story

As a developer, I want a full-screen terminal interface for `rpr chat` so that I can inspect conversation history, tool activity, file context, and streamed answers in one place, similar to Claude Code.

## Details

Build a Textual-based TUI mode for `rpr chat`, exposed either as `rpr chat --tui` or a dedicated `rpr agent` command. This is not a separate agent runtime; it is a richer presentation layer on top of the session and tool model introduced in stories 20 and 21.

The interface should include, at minimum, four coordinated regions:

- chat transcript pane
- composer/input pane
- tool activity/event pane
- context pane for file previews, diffs, or session metadata

The UI should support:

- streamed assistant responses
- expandable tool events
- keyboard-first workflow
- scrollback through prior turns
- modal approval prompts for mutating actions
- status line showing model, cwd, approval mode, and token/session state if available

The goal is to make the CLI feel like a serious coding agent environment rather than a line-oriented REPL.

## Assumptions

- Textual is added as an optional dependency for interactive mode.
- Non-interactive commands remain Typer commands rendered with Rich; the TUI does not replace the rest of the CLI.
- `rpr chat` without `--tui` continues to work as the simpler REPL from story 20.

## Acceptance Criteria

- [ ] A Textual app exists under `src/rpr/tui/` or equivalent and can be launched from `rpr chat --tui`.
- [ ] The TUI shows separate panes for transcript, tool events, input, and context/preview.
- [ ] Assistant responses stream into the transcript pane incrementally.
- [ ] Tool calls appear as structured events rather than plain transcript text.
- [ ] Approval prompts for mutating actions are handled in-app without dropping back to raw stdin prompts.
- [ ] The same agent/session backend used by the REPL powers the TUI.
- [ ] Keyboard shortcuts exist for at least submit, cancel current generation, focus next pane, and open/close context view.
- [ ] Tests cover app startup plus at least one mocked interaction flow with a fake session backend.
