# Story 28: Cancellable Chat, Multiline Input, and Message Queuing

## User Story

As a developer, I want to be able to cancel long-running agent responses, enter multiline messages, and queue follow-up questions while the agent is busy, so that I have better control over the interaction and can maintain a high-velocity workflow.

## Details

This story enhances the chat experience with advanced interaction patterns: task cancellation, multiline editing, and asynchronous message queuing.

### 1. Cancellable Agent Responses

When the agent is generating a response or executing tools, the process should be cancellable by the user.

- The chat turn execution should be wrapped in an `asyncio.Task`.
- Pressing `ESC` (or `Ctrl+C` as a fallback) while an agent task is active should trigger cancellation.
- The cancellation must propagate through the `AgentRuntime` and down to the `AgentClient` (LLM SDK calls) to stop token generation and resource consumption immediately.
- A status message "Press ESC to cancel" must be displayed above the input field (e.g., using a bottom toolbar or a dedicated UI element) only while the agent is responding.

### 2. Multiline Input

The chat input should support rich multiline editing.

- Users can insert a newline by pressing a terminal-compatible modified Enter shortcut. In this implementation that shortcut is `Esc`, then `Enter`, because `Shift + Enter` is not reported distinctly by PromptToolkit on standard terminal input.
- A standard `Enter` keypress submits the message.
- The input field should automatically expand or scroll to accommodate multiple lines of text.
- This behavior should be implemented using `PromptToolkit`'s multiline capabilities.

### 3. Message Queuing and Status Display

To support a "flow" state, users should be able to submit new messages even while the agent is still processing a previous turn.

- If a message is submitted while an agent task is active, it should be added to a FIFO queue.
- A status indicator must show that messages are queued.
- A preview of the next queued message (e.g., the first sentence or first 50 characters) should be displayed above the input field to remind the user what they have already sent.
- Once the current task finishes or is cancelled, the next message in the queue should be automatically started.

### 4. Technical Alignment

- Use `asyncio.create_task` to manage the lifecycle of agent turns.
- Leverage `PromptToolkit`'s `bottom_toolbar` or `Window` elements to display "Press ESC to cancel" and queued message previews.
- Ensure `AgentRuntime`'s `TurnControl` or similar mechanism correctly handles the cancellation signal.
- The `ChatCommandService` should manage the message queue and the transition between turns.

## Acceptance Criteria

- [x] Pressing `ESC` while the agent is responding cancels the current task and stops output.
- [x] A "Press ESC to cancel" hint is visible only during active agent processing.
- [x] A terminal-compatible modified Enter shortcut inserts a newline in the chat input. In this implementation that shortcut is `Esc`, then `Enter`.
- [x] `Enter` submits the message, including multiline content.
- [x] Submitting a message while the agent is busy adds it to a queue instead of blocking or discarding it.
- [x] The UI displays a preview (first sentence/row) of the next queued message.
- [x] The agent automatically picks up the next message from the queue after finishing or cancelling the current one.
- [x] Cancellation is verified to stop LLM streaming and cooperatively stop tool execution where supported by the tool implementation.
- [x] Tests cover task cancellation, multiline input keybindings, multiline delivery, and message queue ordering.

## Test Cases

- Start a long agent response and press `ESC`. Verify that the "Assistant >" stream stops and the shell returns to the input prompt.
- Enter a multiline message using the configured modified Enter shortcut (`Esc`, then `Enter` in this terminal implementation) and verify it is delivered to the agent as a single message with newlines.
- While the agent is responding, type a new message and press `Enter`. Verify that a "Queued: [preview]..." message appears and the agent processes it immediately after the first response finishes.
- Queue multiple messages and verify they are processed in the correct order.
- Cancel a response while messages are queued and verify the next queued message starts automatically.
