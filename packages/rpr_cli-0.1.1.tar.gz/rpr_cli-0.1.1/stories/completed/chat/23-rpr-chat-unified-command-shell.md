# Story 23: `rpr chat` — Unified Interactive Command Shell

## User Story

As a developer, I want `rpr chat` to be the single interactive shell for the product so that chat, repository operations, and existing CLI commands all work through one consistent command surface.

## Details

Consolidate the current split between the simple text REPL and the full-screen interface into one interaction model. `rpr chat` should launch the primary interactive experience by default, and that experience should be backed by a single application layer for session management, command dispatch, tool use, approvals, and state transitions.

The preferred implementation is a Rich-based interactive shell, not a mandatory full-screen Textual application. Claude Code and Gemini CLI-style workflows do not require a heavy full-screen TUI to feel capable. If Rich can provide the required transcript, structured events, slash-command flows, previews, and approvals with lower complexity, that is the preferred direction.

Textual should be treated as optional infrastructure, not the architectural center of the chat system. Only retain or expand Textual usage if there is a concrete interaction need that Rich cannot support cleanly.

This story is not just a UI cleanup. It defines the command model that both the chat transcript and the rest of the CLI must share.

The implementation should introduce a dedicated command-shell application service that owns:

- slash-command parsing and routing
- session-scoped state and conversation context
- dispatch into existing RPR command handlers or application services
- command metadata, help text, arguments, and interactive follow-up flows
- presentation-agnostic events consumed by the active UI

Follow SOLID and DDD principles when shaping this work:

- keep command parsing, command execution, and UI rendering in separate units
- do not let Textual widgets or Rich console code become the source of truth for command behavior
- model slash commands as explicit application commands instead of ad hoc string checks spread across the UI
- preserve existing domain and application boundaries for `init`, `settings`, `generate`, `sync`, `add`, `check`, `map`, and chat agent behavior
- prefer shared command services or adapters over duplicating Typer logic in the chat runtime

Terminal ergonomics must account for integrated-terminal environments such as VS Code. Control-key shortcuts like `Ctrl+Q` may be intercepted by the host terminal or editor before the shell receives them. Because of that:

- slash commands are the primary interaction contract for session control and command execution
- essential actions such as exit, help, settings, and mode changes must always be available through slash commands
- keyboard shortcuts should be additive conveniences only, never the sole way to trigger important behavior
- any optional key bindings should prefer keys that degrade safely when run in integrated terminals

The unified shell should support slash-prefixed commands similar to Claude Code or Gemini CLI. At minimum:

- `/exit` ends the interactive session
- `/help` lists available slash commands and usage
- `/init` invokes the workspace bootstrap flow from inside chat
- `/settings` opens an interactive settings flow where the user can inspect and change settings without leaving chat

The broader rule is that every user-facing RPR command should have an equivalent slash-command entry point inside `rpr chat`. For commands that currently rely on standard Typer option parsing or follow-up prompts, the shell should provide one of these strategies:

- parse inline slash-command arguments
- open an interactive parameter picker or form inside the chat shell
- hand off to a shared application service that both Typer and chat can call

This story should also clarify the future of the old plain-text mode. The preferred outcome is:

- `rpr chat` launches the primary interactive shell by default
- any non-TUI fallback is treated as a compatibility mode or removed entirely
- there is one command model and one application flow, even if more than one presentation adapter survives temporarily

Special attention is required for settings and command discoverability. `/settings` should not be a thin alias that dumps the user back into raw CLI prompts. It should expose a structured in-shell interaction so users can browse configurable values, inspect current state, and confirm mutations through the same approval and event model used elsewhere in chat.

If additional packages are needed for command palettes, forms, or structured selection widgets inside the interactive shell, add them with `uv add {package-name}` and keep them scoped to the interactive experience where possible.

## Assumptions

- Story 22 explored a full-screen Textual shell, but story 23 is the consolidation story and may intentionally replace that direction with a simpler Rich-first shell.
- Typer remains the top-level CLI entrypoint for non-chat command invocation, but chat should reuse the same underlying application services rather than reimplementing command behavior.
- Some existing commands may need an intermediate application-service layer extracted from Typer command functions before they can be invoked cleanly from slash commands.
- A temporary compatibility path may exist during migration, but the target architecture is one interactive command shell, not two permanently divergent implementations.
- The product must behave sensibly inside integrated terminals, so slash commands are more reliable than editor-sensitive control-key shortcuts for essential actions.

## Acceptance Criteria

- [ ] `rpr chat` launches the primary interactive shell by default rather than requiring a separate `--tui` mode.
- [ ] The interactive shell and any remaining fallback mode use the same command application layer for session state, slash-command dispatch, approvals, and tool execution.
- [ ] Slash commands are supported with a leading `/` syntax, including at least `/help` and `/exit`.
- [ ] Existing RPR commands have corresponding slash-command entry points inside chat, including at minimum `/init`, `/settings`, `/generate`, `/sync`, `/add`, `/check`, and `/map`.
- [ ] Slash-command execution reuses shared application services or command adapters rather than duplicating business logic inside the chat UI.
- [ ] `/settings` provides an in-shell interactive flow for viewing and changing settings without dropping back to raw external prompts.
- [ ] Command discovery is available in-shell so a user can inspect available slash commands, expected arguments, and current state.
- [ ] Approval, progress, success, and failure events for slash-command execution are rendered through the same event model as agent tool activity.
- [ ] Essential shell controls do not depend on control-key shortcuts that may be intercepted by an integrated terminal or editor.
- [ ] If keyboard shortcuts exist, they are optional accelerators and every critical action has a slash-command equivalent.
- [ ] Tests cover command-surface parity, including at least one shared-command execution path invoked from both top-level CLI and chat shell entry points.
- [ ] Tests cover slash-command parsing, `/exit`, `/help`, `/settings`, and one existing non-chat command executed successfully from inside the shell.

## Test Cases

- Launch `rpr chat` and verify the primary interactive shell opens without requiring `--tui`.
- Enter `/help` and verify the command list includes supported slash commands with usage guidance.
- Enter `/exit` and verify the shell closes cleanly without stack traces or orphaned state.
- Enter `/init` in a temporary directory and verify the same application flow used by the top-level `rpr init` command is invoked.
- Enter `/settings`, inspect current values, change a setting, confirm the mutation, and verify the updated value is reflected in subsequent shell state.
- Execute another existing command such as `/check` or `/map` and verify results render in the shell using structured events instead of raw subprocess output.
- Verify one shared command path is covered by tests from both the top-level CLI entrypoint and the slash-command shell entrypoint.
- Verify essential actions remain usable when control-key shortcuts are intercepted by an integrated terminal, because slash commands continue to work.
- Verify fallback or compatibility mode, if still present, uses the same slash-command parser and command application services rather than a separate implementation.
