# Story 26: Shared Command Catalog and Typed Command DTOs

## User Story

As a developer, I want one readable typed command catalog for both chat slash commands and top-level `rpr` commands so that changing a command in one place updates help text, routing, metadata, and command discovery everywhere.

## Details

This story defines the command model that both chat and the Typer-based CLI must consume. The main problem is drift: command names, descriptions, and option semantics should not be duplicated across chat parsing, CLI registration, and help rendering.

The preferred solution is a Python-native typed catalog rather than JSON or YAML. A Python module with immutable dataclasses, TypedDict-backed DTOs, or equivalent typed records is better aligned with refactoring, discoverability, and code review in this repo.

The catalog should be the single source of truth for command metadata. It should be expressive enough to model:

- root commands and nested subcommands
- aliases and invocation names
- descriptions and long-form help text
- positional arguments
- options and flags
- default-entry metadata such as `chat` being the default root command
- interaction metadata such as whether a command is chat-available, CLI-available, or inherently interactive
- action binding metadata that tells adapters which application action a leaf command triggers

The catalog must support recursion because RPR commands are hierarchical. Examples include:

- `generate domain`
- `generate api`
- `sync rules`
- `add template`

The structure should make parent-child command relationships explicit so adapters can derive both `rpr generate ui` and `/generate ui` from the same definition tree.

Because the desired outcome is a command surface that stays readable in one place, this story should include an illustrative single-file catalog example. The exact names can change during implementation, but the intended shape should be explicit before work starts. A representative example would look like this:

```python
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


@dataclass(frozen=True, slots=True)
class CommandOption:
	long_name: str = field(
		metadata={
			"description": "Long option name rendered and invoked as --<long-name>. Spaces in labels are normalized to hyphens.",
		}
	)
	short_name: str | None = field(
		default=None,
		metadata={"description": "Optional short alias rendered and invoked as -<short-name>."},
	)
	description: str = field(metadata={"description": "Help text shown in discovery and help output."})
	value_name: str | None = field(
		default=None,
		metadata={"description": "Placeholder shown when the option expects a value, for example MODEL or PATH."},
	)
	kind: Literal["flag", "value"] = field(
		default="flag",
		metadata={"description": "Whether the option is a boolean flag or requires a value."},
	)


@dataclass(frozen=True, slots=True)
class CommandArgument:
	name: str = field(metadata={"description": "Positional argument name used in usage text."})
	description: str = field(metadata={"description": "Meaning of the argument for help and picker UIs."})
	required: bool = field(default=True, metadata={"description": "Whether the argument is required."})


@dataclass(frozen=True, slots=True)
class CommandDefinition:
	name: str = field(metadata={"description": "Canonical command token shared by CLI and slash-command adapters."})
	description: str = field(metadata={"description": "Short description shown in help and command pickers."})
	action_id: str | None = field(
		default=None,
		metadata={"description": "Stable application action identifier used for leaf-command dispatch."},
	)
	aliases: tuple[str, ...] = field(
		default_factory=tuple,
		metadata={"description": "Alternative tokens that resolve to the same command."},
	)
	arguments: tuple[CommandArgument, ...] = field(
		default_factory=tuple,
		metadata={"description": "Positional arguments accepted by this command."},
	)
	options: tuple[CommandOption, ...] = field(
		default_factory=tuple,
		metadata={"description": "Supported flags and value options."},
	)
	children: tuple["CommandDefinition", ...] = field(
		default_factory=tuple,
		metadata={"description": "Nested subcommands for grouped commands such as generate or sync."},
	)
	chat_enabled: bool = field(default=True, metadata={"description": "Whether the command is available as a slash command."})
	cli_enabled: bool = field(default=True, metadata={"description": "Whether the command is available from the top-level CLI."})
	interactive: bool = field(
		default=False,
		metadata={"description": "Whether the command usually opens a follow-up interactive flow."},
	)
	default_root_command: bool = field(
		default=False,
		metadata={"description": "Marks the command that should run when rpr is invoked without a subcommand."},
	)


COMMAND_CATALOG: tuple[CommandDefinition, ...] = (
	CommandDefinition(
		name="chat",
		description="Start the primary interactive chat shell.",
		action_id="chat.start",
		interactive=True,
		default_root_command=True,
		options=(
			CommandOption("provider", description="Override the AI provider.", value_name="PROVIDER", kind="value"),
			CommandOption("model", description="Override the model name.", value_name="MODEL", kind="value"),
		),
	),
	CommandDefinition(
		name="settings",
		description="Inspect or update persisted settings.",
		children=(
			CommandDefinition(name="list", description="List all settings.", action_id="settings.list"),
			CommandDefinition(
				name="get",
				description="Read one setting value.",
				action_id="settings.get",
				arguments=(CommandArgument("key", "Setting key to inspect"),),
			),
			CommandDefinition(
				name="set",
				description="Update one setting value.",
				action_id="settings.set",
				arguments=(
					CommandArgument("key", "Setting key to update"),
					CommandArgument("value", "New value to persist"),
				),
			),
		),
	),
	CommandDefinition(
		name="generate",
		description="Scaffold apps and packages.",
		children=(
			CommandDefinition(name="domain", description="Generate a domain package.", action_id="generate.domain"),
			CommandDefinition(name="api", description="Generate an API app.", action_id="generate.api"),
			CommandDefinition(name="ui", description="Generate a UI package.", action_id="generate.ui"),
		),
	),
)
```

This example is illustrative rather than prescriptive, but the story should preserve these characteristics:

- one readable module that defines the command tree
- immutable DTOs with self-documenting metadata
- explicit recursive structure for nested commands
- explicit action identifiers for leaf-command dispatch
- explicit flags for chat availability, CLI availability, interactivity, and default-entry behavior

DTO design should be self-documenting. Field metadata or equivalent annotations should explain the meaning of each field so the schema remains readable even when the author forgets exact conventions later. For example, option DTOs should capture concepts such as:

- full option name for rendered and invoked long-form flags
- optional short alias
- description/help text
- whether the option is a flag or expects a value
- value name or arity
- repeatability and requiredness

Leaf command DTOs should also define how execution is resolved. The catalog should not force UI layers to guess what action a command performs based on its string label. Action resolution can be an application action identifier, an adapter key, or another stable binding, but it must be explicit.

This story should also define how the Typer CLI consumes the catalog. Typer may remain the outer registration framework, but it should no longer be the canonical store for command meaning. Instead, a CLI adapter layer should project the shared catalog into Typer registration and help text.

Similarly, the chat shell should derive its slash-command parser, help output, and future completion behavior from the same catalog rather than hard-coded string dictionaries.

Follow SOLID and DDD principles:

- keep command metadata in the application layer, not in UI or framework decorators
- separate DTO definitions from parser, matcher, and execution services
- separate command definitions from command handlers
- keep DTOs immutable so changes are deliberate and easy to audit
- treat the catalog as a shared language between CLI adapters and chat-shell adapters

No new package is required for this story. Python dataclasses and typing support are sufficient.

## Assumptions

- Story 23 established the need for a unified command shell and shared command surface.
- Story 24 provides the async orchestration layer that will consume the shared catalog.
- Story 25 provides prompt/session lifecycle services but does not define command metadata.
- Typer remains the external CLI framework, but shared command metadata should live outside Typer decorators.
- A Python-native typed model is preferred over external JSON or YAML configuration for maintainability and refactor safety.

## Acceptance Criteria

- [ ] A shared command-catalog module exists and acts as the single source of truth for RPR command definitions.
- [ ] Command definitions are represented with typed immutable DTOs or dataclasses.
- [ ] DTOs include self-documenting metadata for command names, descriptions, options, arguments, and interaction flags.
- [ ] The story includes an illustrative single-file DTO example so the intended catalog shape is clear before implementation begins.
- [ ] The catalog supports nested command trees for command groups such as `generate`, `sync`, and `add`.
- [ ] The catalog can express leaf-command action bindings without requiring UI code to infer behavior from strings.
- [ ] Chat slash-command metadata is derived from the shared catalog rather than hard-coded command dictionaries.
- [ ] Top-level CLI metadata is derived from the same catalog through an adapter or registration layer.
- [ ] The catalog can represent default-entry behavior such as `chat` being the default root command.
- [ ] Tests cover recursive command lookup, DTO validation, action-binding resolution, and parity between CLI and chat command metadata.

## Test Cases

- Change a command description in the shared catalog and verify both CLI help and chat help reflect the update without editing multiple sources.
- Resolve nested commands such as `generate ui`, `sync rules`, and `add template` through recursive lookup and verify the correct leaf definition is returned.
- Verify a command marked as interactive retains that metadata for chat-side follow-up flows.
- Verify a command marked as the default root entrypoint remains the fallback when `rpr` is launched without an explicit subcommand.
- Verify a malformed command definition fails validation or tests before it can silently drift into one surface only.
