# Story 29: File Context Selection (@-commands)

## User Story

As a developer, I want to be able to reference files and directories in chat by typing `@` so that I can provide specific context (including file content) to the agent without manually typing full paths or manually reading files.

## Details

This story extends the context selection panel from Story 27 to support file and directory suggestions when the user types the `@` trigger, and implements the backend logic to resolve these references into actual attached file content for the agent.

The behavior should mirror modern AI-enabled IDEs (Gemini CLI, Claude Code):

- **UI Selection**: Typing `@` opens the selection panel showing files and directories in the current project (respecting `.gitignore`).
- **Navigation**: Typing characters filters the list; selecting a directory inserts `@dir/` and immediately narrows the candidate list to entries under that directory.
- **Tag Insertion**: Selecting a file inserts a formatted tag (e.g., `@path/to/file`) into the chat input.
- **Context Resolution**: When a message containing `@` tags is submitted, the system must:
  - Parse the message for `@path` references.
  - Resolve these paths relative to the project root.
  - Read the file bytes and infer MIME type.
  - Build a multipart turn payload shaped for Gemini- or Claude-style SDK content arrays, where the user text and the selected file payloads are separate parts.

Technical constraints:

- Reuse the selection panel UI component implemented in Story 27.
- Implement a `FileCompleter` that integrates with the shared selection mechanism.
- Ensure the `AgentRuntime` or a pre-processing service handles the resolution of `@` tags before the message reaches the LLM.
- Large projects must be handled gracefully (fast walker, limiting initial candidates).
- Avoid double-sending content if multiple `@` tags refer to the same file.

## Acceptance Criteria

- [x] Typing `@` in chat opens the shared selection panel with file and directory candidates.
- [x] Typing additional characters filters the files and directories; selecting a directory updates the candidate list.
- [x] Selecting a file inserts its path (as an `@`-prefixed tag) into the chat input at the cursor position.
- [x] When a message with `@path` is sent, the agent receives the selected file as attached multipart content alongside the user text.
- [x] The system distinguishes between text files and binary files by MIME type, and keeps attachments in a byte-backed file-part structure.
- [x] The list of files respects project-level ignore rules (e.g., `.gitignore`).
- [x] UI provides visual feedback when a file is successfully resolved and attached to the turn.

## Test Cases

- Type `@` and verify the panel shows project files and directories that are not ignored.
- Select a file and verify its path is inserted into the chat input.
- Select a directory and verify the inserted `@dir/` prefix narrows the candidate list to entries inside that directory.
- Send a message like "Explain @src/main.py" and verify the agent turn contains both the user text part and a file attachment part for `src/main.py`.
- Verify that hidden or ignored directories (like `.git`) are not shown.
- Verify that invalid `@path` tags (e.g., non-existent files) are handled gracefully (e.g., ignored or reported as an error).

## Notes

- The input keeps plain `@path/to/file` text in the buffer and uses prompt rendering to color those references distinctly.
- The current mock provider surfaces attachment metadata and text previews for verification; future provider implementations should translate the same multipart turn shape into native SDK request bodies.
