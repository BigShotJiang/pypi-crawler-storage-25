# Story 21: `rpr chat` — Tool Use, Approvals, and Session Context

## User Story

As a developer using `rpr chat`, I want the assistant to inspect and modify the repository through controlled tools so that the experience feels closer to Claude Code instead of a plain text chatbot.

## Details

Extend `rpr chat` with an agent runtime that can invoke repository tools such as file reads, searches, diffs, command execution, and file edits. The runtime should maintain session context, show tool activity in real time, and require explicit approval for mutating actions unless the user opts into a less strict mode.

The focus here is the Claude-Code-like loop:

- user asks for a task
- assistant decides whether to answer directly or call a tool
- tool calls are displayed in a dedicated, styled event format
- mutating tools require approval (`Approve`, `Reject`, `Always allow for session`)
- results are summarized back into the conversation

The agent runtime should distinguish read-only tools from mutating tools. Suggested buckets:

- read-only: list files, read file, search text, git diff, inspect config
- mutating: write file, apply patch, run install/build commands, create/delete files

This story is still terminal-based, but it establishes the behavior model that the later Textual UI will visualize more richly.

## Assumptions

- Tool execution happens through explicit adapters in `src/rpr/agent/tools/`; the agent does not call shell commands directly.
- Approval policy is session-scoped and defaults to requiring confirmation for mutating actions.
- Session context may include recent tool calls, summarized file context, and conversation history.

## Acceptance Criteria

- [ ] `rpr chat` can execute at least a minimal set of read-only tools: file read, file search, and directory listing.
- [ ] Mutating actions require an approval prompt before execution.
- [ ] The session supports an approval mode such as `ask`, `auto-readonly`, or `auto-all`.
- [ ] Tool calls and results are rendered distinctly from assistant prose.
- [ ] Conversation state includes prior tool results so the assistant can continue tasks across turns.
- [ ] A session object exists in `src/rpr/agent/session.py` or equivalent to track history, approvals, and recent context.
- [ ] Tests cover: read-only tool execution, rejected mutation, approved mutation, and approval-mode overrides.
