# Story 25: Prompt Service and Conversation Lifecycle

## User Story

As a developer, I want chat prompting and conversation lifecycle management to live in a dedicated singleton prompt service so that new sessions, existing sessions, and future persistence all follow one clear application workflow.

## Details

This story separates conversation lifecycle concerns from command parsing and runtime execution. The shell needs a dedicated application service that owns the prompt session and the lifecycle of conversations shown in the interactive experience.

The core requirement is a `PromptService` or equivalent process-scoped application service that holds a singleton PromptToolkit session and exposes explicit conversation operations:

- list conversations
- create conversation
- load conversation
- save conversation

The default behavior for `rpr chat` should be to create a new conversation when the user starts a new shell session. Even with that default, the prompt service itself should not be reinstantiated repeatedly; it should be reused for the lifetime of the process.

This story is intentionally about the application contract, not full persistence implementation. The future target is SQLite-backed history, but the design should introduce a clean persistence seam now. The prompt service should depend on a conversation repository abstraction or equivalent persistence boundary so the current in-memory implementation can later be replaced by SQLite without rewriting the shell.

The conversation model should include enough metadata to support a future history picker, for example:

- stable session identifier
- title or derived summary label
- created timestamp
- updated timestamp
- project root association
- message history and tool history references as needed

The prompt service should not own command execution or agent runtime logic. Its responsibilities are narrower:

- hold the long-lived PromptToolkit session
- coordinate which conversation is active
- create and load conversation state
- save current conversation state through a repository boundary
- expose conversation summaries to the UI for later selection workflows

This separation matters for SOLID and DDD:

- prompt/session lifecycle is an application concern, not a UI detail
- chat session records are domain/application state objects, not prompt-widget state
- persistence logic must not leak into shell command parsing
- command services should consume conversation state, not construct ad hoc history stores

The initial implementation can keep persistence in memory, but the service contract must be shaped for the SQLite path the user plans to add later. Standard-library `sqlite3` is sufficient when that later story is implemented, so no new package is required by this story.

Because PromptToolkit is already declared in [pyproject.toml](pyproject.toml), no dependency addition is needed. If a development environment does not yet have the declared dependencies installed, it should be prepared with `uv sync`.

## Assumptions

- Story 24 provides the async chat orchestration path that will consume this prompt service.
- Conversation history persistence may start in memory and move to SQLite in a later story without changing the public prompt-service contract.
- The shell will eventually present previous conversations in a selector, but that UI is not required to be fully implemented in this story.
- The prompt service is a singleton because it manages process-scoped interactive state; individual conversation records are not singletons.

## Acceptance Criteria

- [ ] A dedicated prompt/conversation application service exists and is reused as a singleton for the lifetime of the process.
- [ ] The prompt service owns a singleton PromptToolkit session instead of recreating it on each prompt.
- [ ] The prompt service exposes explicit operations for list, create, load, and save conversation flows.
- [ ] Starting a new `rpr chat` session creates a new conversation by default.
- [ ] The active conversation can be saved and later reloaded through the same service contract.
- [ ] Conversation summaries include enough metadata to support a future history-selection UI.
- [ ] Prompt/session lifecycle logic is separated from command parsing and agent runtime logic.
- [ ] A persistence seam exists so in-memory storage can later be replaced with SQLite without rewriting the shell application layer.
- [ ] Tests cover singleton prompt-service reuse, default new-conversation behavior, save/load flows, and conversation summary listing.

## Test Cases

- Start a new chat session and verify a new conversation object is created automatically.
- Save the active conversation and verify it remains accessible through the prompt service.
- Load a previously saved conversation and verify it becomes the active conversation.
- List conversations and verify the returned summaries include identifiers, timestamps, and labels suitable for a future picker UI.
- Verify repeated prompt operations reuse one prompt service instance rather than recreating the service or prompt session each time.
- Verify the prompt service can be backed by an in-memory repository now without preventing a later SQLite-backed repository implementation.
