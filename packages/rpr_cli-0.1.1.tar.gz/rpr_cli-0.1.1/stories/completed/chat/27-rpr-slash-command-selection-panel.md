# Story 27: Context Selection Panel and Keyboard Navigation

## User Story

As a developer, I want a Claude-Code-style selection panel to appear when I type specific triggers (like `/` for commands) in chat so that I can discover, filter, and choose context or commands quickly without memorizing everything.

## Details

This story implements the interactive selection experience, initially focused on slash commands from the shared command catalog (Story 26). The behavior should feel immediate and keyboard-first: the moment the user types a trigger character, the shell should open a visible panel below the input showing matching candidates.

The UI component must be designed as a generic context selector capable of rendering different types of suggestions (commands, files, etc.) based on the active trigger.

The expected interaction model is:

- typing a trigger character (e.g., `/`) opens a panel of available candidates
- typing additional text filters the candidate list incrementally
- the highlighted row can be moved with up and down arrows
- pressing `Enter` selects the highlighted candidate
- dismissing the panel leaves the current input intact

The selection panel should show enough information to support a confident choice at the point of input. At minimum each row should display:

- candidate name/invocation
- short description or metadata (e.g., file path, command purpose)
- optional icons or type indicators

PromptToolkit v3 should be used for this because the project already declares `prompt-toolkit>=3.0.52` in [pyproject.toml](pyproject.toml). The base implementation can rely on PromptToolkit completer and key-binding facilities.

The UX should distinguish between inserting a template and executing an action. The safe default is that selection inserts the candidate into the composer.

Follow SOLID and DDD principles:

- keep matching and filtering logic separate from rendering widgets
- keep key-binding rules separate from candidate generation
- keep selection as an application/UI adapter concern, not a domain concern

## Assumptions

- Story 26 provides the shared command catalog for slash-command candidates.
- Story 24 provides the async prompt loop needed to support interactive selection.
- Story 25 provides prompt-session lifecycle management.

## Acceptance Criteria

- [ ] Typing a trigger character in chat opens a visible selection panel below the input.
- [ ] The panel lists candidates relevant to the active trigger.
- [ ] Typing additional characters filters candidates incrementally.
- [ ] Up-arrow and down-arrow move the current selection.
- [ ] Pressing `Enter` selects the highlighted candidate.
- [ ] Dismissing the panel leaves the current input in a valid unchanged state except for intentional edits.
- [ ] The selection UI shows at least name and description for each candidate.
- [ ] The interaction works in the standard chat shell without requiring a separate full-screen TUI.
- [ ] Tests cover candidate filtering, keyboard navigation, and selection behavior.

## Test Cases

- Type `/` and verify the selection panel appears with available slash commands.
- Type `/se` and verify the panel filters to commands such as `/settings`.
- Use down-arrow and up-arrow to change the highlighted command and verify visual selection follows keyboard movement.
- Press `Enter` on a highlighted command and verify it is inserted into the input.
- Dismiss the panel and verify partially typed input remains intact.
