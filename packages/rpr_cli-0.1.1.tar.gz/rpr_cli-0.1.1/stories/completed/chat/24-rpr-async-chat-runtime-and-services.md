# Story 24: Async Chat Runtime and Application Services

## User Story

As a developer, I want `rpr chat` to process input, stream responses, and dispatch commands through async application services so that the default interactive experience stays responsive, composable, and easier to reason about as the shell becomes the main entrypoint.

## Details

This story follows the unified command-shell direction from story 23 and defines the service boundaries for the default chat experience now that `rpr` launches chat when no explicit command is provided.

The current chat entrypoint is carrying too much orchestration responsibility. The implementation should move the runtime flow behind dedicated application services so the Typer command remains thin and the code follows SOLID principles. The key goal is not merely to add `async` keywords, but to separate responsibilities cleanly:

- CLI adapter layer: Typer command registration and argument capture only
- application orchestration layer: session startup, prompt loop coordination, runtime wiring, and termination rules
- command-shell layer: slash-command parsing and dispatch
- runtime layer: agent event streaming, approval checks, and tool execution sequencing
- presentation layer: Rich or PromptToolkit rendering and user interaction adapters

The new async flow should cover the whole path from user input to streamed output:

- prompt input must be awaited through PromptToolkit v3 async APIs
- chat shell input handling must be async so slash-command flows and regular turns use the same non-blocking contract
- agent streaming must move to async iteration so providers can yield events naturally
- tool execution may remain synchronous internally for now, but the runtime must isolate blocking work behind an async-safe boundary such as a worker-thread adapter

This story should formalize long-lived application services. The user intent is that service instances are not recreated unnecessarily. In practical terms, the shell should define explicit singleton application services only for process-scoped coordination concerns such as chat orchestration and prompt/session coordination. Pure DTOs, value objects, and domain records should remain plain immutable instances rather than being forced into singleton patterns.

The mock agent should also better simulate a real provider. Instead of emitting an immediate tight loop of characters, the mock streaming implementation should yield chunks with a small fixed delay of roughly 100ms between emissions. The goal is deterministic, testable streaming behavior that better mirrors a provider-backed session while remaining lightweight.

The implementation should preserve the existing RPR command surface:

- `rpr` without a subcommand still opens the interactive chat shell
- `rpr chat` remains an explicit entrypoint
- slash commands still execute through the shared shell flow

Because the repo declares `prompt-toolkit>=3.0.52` in [pyproject.toml](pyproject.toml), this story should rely on PromptToolkit v3 async capabilities already in the dependency surface. If the local environment is missing the declared package, environment setup should be handled with `uv sync`; no new package is required for this story.

Follow SOLID and DDD principles explicitly:

- keep orchestration in application services rather than command modules
- do not let PromptToolkit or Rich rendering code become the owner of runtime state
- keep provider-specific streaming behind `AgentClient` abstractions
- keep tool execution rules in the runtime layer, not in shell parsing or UI code
- prefer small services with one reason to change over one large chat module with mixed concerns

## Assumptions

- Story 23 already establishes `rpr chat` as the primary interactive command shell and the default root entrypoint when no explicit command is supplied.
- PromptToolkit v3 async prompting is sufficient for the base interactive loop; no Textual-specific requirement is implied by this story.
- Existing tool implementations may remain synchronous internally in the short term, but the runtime contract exposed to the shell should become async.
- Singleton service lifetime is intended for process-scoped application services, not for domain records or ephemeral command objects.

## Acceptance Criteria

- [ ] `rpr` without a subcommand continues to launch the primary interactive chat experience.
- [ ] The Typer chat command becomes a thin adapter that delegates startup and orchestration to an application service.
- [ ] User input collection in chat uses an async PromptToolkit flow rather than a blocking prompt loop.
- [ ] Chat shell input handling is async and supports both normal user turns and slash-command dispatch through the same awaited contract.
- [ ] Agent streaming uses an async event interface rather than a synchronous generator contract.
- [ ] Blocking tool execution paths, if any remain, are isolated behind an async-safe execution boundary.
- [ ] Chat orchestration responsibilities are split into dedicated services instead of being concentrated in one command module.
- [ ] Service boundaries are explicit enough that command parsing, runtime streaming, and presentation rendering can be read independently.
- [ ] The mock agent streams in delayed chunks with approximately 100ms spacing between yields.
- [ ] Errors in provider streaming or command dispatch are rendered cleanly and do not crash the shell.
- [ ] Tests cover startup, async turn execution, provider failure handling, delayed mock streaming, and shell continuity after an error.

## Test Cases

- Launch `rpr` without a subcommand and verify the default interactive chat flow starts.
- Launch `rpr chat` and verify startup is delegated through an application service rather than directly embedding the prompt loop in the command module.
- Submit a normal user prompt and verify the turn runs through an async input and async streaming path.
- Trigger a slash command and verify the same async shell contract handles it without a separate blocking path.
- Use the mock provider and verify streamed chunks arrive over time instead of being emitted as one immediate burst.
- Simulate a provider exception and verify the error is rendered while the shell remains usable for subsequent input.
- Simulate a blocking tool call and verify the shell runtime does not require synchronous orchestration at the application boundary.
