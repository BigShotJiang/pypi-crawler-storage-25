# Story 19: Markdown Rendering — Rich Preview in Standard Commands

## User Story

As a developer using `rpr`, I want commands that produce markdown content to render that markdown nicely in the terminal while still writing the underlying `.md` file to disk so that previews are readable without opening another editor.

## Details

Add first-class markdown rendering support to the shared UI layer from story 18. Any command that produces markdown output, summaries, plans, code maps, or AI-generated artifacts should be able to pass raw markdown text to a renderer and get a clean terminal preview using `rich.markdown.Markdown`, optionally wrapped in a `Panel`.

This applies to both existing commands and new ones:

- `rpr map` should preview the generated code map in dry-run mode and optionally after successful writes.
- Future AI/agent commands should stream or display markdown responses cleanly.
- Other commands that emit documentation-like summaries should render them as markdown instead of plain strings.

The markdown renderer should support two modes:

- `preview` mode for terminal display
- `raw` mode for writing the exact markdown string to disk

The CLI should avoid mixing terminal-only decorations into the written file. The saved markdown stays strict and agent-readable; the terminal preview is the pretty layer.

## Assumptions

- Rich markdown rendering is good enough for terminal output; no external markdown formatter is required.
- The saved `.md` file is always the source of truth and remains free of ANSI codes or terminal-specific markup.
- Very large markdown outputs may be truncated in terminal preview mode, but never in the saved file.

## Acceptance Criteria

- [ ] `src/rpr/ui/markdown.py` or equivalent exposes a helper that accepts raw markdown text and renders it via Rich.
- [ ] The helper supports an optional title/panel wrapper for previews.
- [ ] Dry-run previews for markdown-producing commands render formatted markdown in terminal rather than raw plain text.
- [ ] `RunContext.write_file()` and `RunContext.update_file()` can optionally use markdown preview rendering when the target file extension is `.md`.
- [ ] The saved file content is unchanged by the preview renderer.
- [ ] Large previews can be truncated for terminal display with an explicit notice such as `(preview truncated)`.
- [ ] Tests cover markdown preview rendering and confirm the raw written content is not mutated.
