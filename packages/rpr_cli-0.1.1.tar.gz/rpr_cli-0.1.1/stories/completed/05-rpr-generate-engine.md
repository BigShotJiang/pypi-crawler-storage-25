# Story 05: `rpr generate engine <name>`

## User Story

As a developer, I want to run `rpr generate engine my-app` to scaffold a Rust + PyO3 package so that I can build Python extensions in Rust and call them from the domain layer.

## Goal

Generate the Rust engine package, its Python build metadata, and its NX wiring so the engine fits naturally into the monorepo.

## Naming Conventions

Rust and Python have different naming requirements. The scaffold must produce names that satisfy both:

| Context                                         | Form                                     | Example (`my-app`) |
| ----------------------------------------------- | ---------------------------------------- | ------------------ |
| Directory / NX project name                     | `{name}-engine` (dashes)                 | `my-app-engine`    |
| Rust crate name (`Cargo.toml` `[package].name`) | `{name}-engine` (dashes OK in Cargo)     | `my-app-engine`    |
| Python module name (imported in Python)         | `{name_underscore}_engine` (underscores) | `my_app_engine`    |
| `pyproject.toml` `[project].name`               | `{name}-engine` (dashes, PEP 508)        | `my-app-engine`    |

The Rust `lib.rs` must declare the module with the underscore form: `#[pymodule] fn my_app_engine(...)`.

## Acceptance Criteria

- [ ] Creates `packages/python/<name>-engine/`.
- [ ] Always displays the command before executing nested CLIs (per Story 00).
- [ ] Creates `Cargo.toml` with correct `[package]` and `[lib]` sections (see below).
- [ ] Creates `src/lib.rs` with a minimal `#[pymodule]` entry point using the underscore module name.
- [ ] Creates `pyproject.toml` with `[build-system]` set to `maturin` and `[tool.maturin]` config (see below).
- [ ] Creates `<name_underscore>_engine.pyi` stub alongside the package for IDE type support.
- [ ] Creates `project.json` with `engine:build`, `engine:lint`, and `engine:format` NX targets (see NX Targets below).
- [ ] Adds the engine package to `[tool.uv.workspace].members` in the root `pyproject.toml`.
- [ ] Prompts for `<name>` if omitted.
- [ ] Supports `--dry-run`; forwards to nested CLI when supported, else shows command only.

## Generated File Manifest

```
packages/python/<name>-engine/
├── Cargo.toml
├── pyproject.toml
├── project.json
├── <name_underscore>_engine.pyi    # type stub
└── src/
    └── lib.rs
```

## Key Configuration Snippets

### `Cargo.toml`

```toml
[package]
name = "{name}-engine"
version = "0.1.0"
edition = "2021"

[lib]
name = "{name_underscore}_engine"
crate-type = ["cdylib"]

[dependencies]
pyo3 = { version = "0.21", features = ["extension-module"] }
```

### `pyproject.toml`

```toml
[build-system]
requires = ["maturin>=1.8.2,<2.0"]
build-backend = "maturin"

[project]
name = "{name}-engine"
version = "0.1.0"
requires-python = ">=3.12"

[tool.maturin]
features = ["pyo3/extension-module"]
module-name = "{name_underscore}_engine"
```

## NX Targets

| Target          | Command                                                    |
| --------------- | ---------------------------------------------------------- |
| `engine:build`  | `uv run maturin develop`                                   |
| `engine:lint`   | `cargo clippy --all-targets --all-features -- -D warnings` |
| `engine:format` | `cargo fmt --check`                                        |

## Key Files

- `src/rpr/commands/generate/engine.py`
- `src/rpr/scaffolds/engine/`

## Notes

- Use `maturin` as the Python build backend.
- The `lib.name` in `Cargo.toml` must use underscores; the `[package].name` can use dashes.
- The `.pyi` stub should declare the module and any top-level functions so IDEs and type checkers can resolve symbols.
- `uv run maturin develop` is the current generated build target.

## Definition of Done

- [ ] The engine package is scaffolded with valid Rust and Python metadata.
- [ ] Naming is consistent: dashes in directory/pyproject, underscores in Rust `lib.name` and Python import.
- [ ] `[build-system]` in `pyproject.toml` uses `maturin`.
- [ ] NX targets cover `engine:build`, `engine:lint`, and `engine:format` with the correct commands.
- [ ] Workspace membership is updated.
- [ ] The preview mode clearly shows all generated files and commands.
