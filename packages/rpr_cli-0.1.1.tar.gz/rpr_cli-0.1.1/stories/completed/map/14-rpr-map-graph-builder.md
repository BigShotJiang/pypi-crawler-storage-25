# Story 14: Graph Builder — Shared Contract and Python Fallback

## User Story

As the layer classifier and output writer, I want a shared dependency graph contract plus a Python fallback graph builder so that downstream logic can stay stable while the production graph is built in Rust.

## Details

The graph builder at `src/rpr/map/graph.py` now serves two roles:

1. Define the canonical Python `DependencyGraph` model consumed by classification and output.
2. Provide the **Python fallback implementation** used only when the Rust engine from story 13 is unavailable.

In the normal path, Rust performs the project crawl, parsing, import resolution, edge construction, reverse-edge construction, and cycle detection. Python receives the result and hydrates it into the dataclass below.

### Graph structure

```python
@dataclass
class DependencyGraph:
    nodes: list[SourceFile]
    edges: dict[str, list[str]]
    reverse_edges: dict[str, list[str]]
    cycles: list[list[str]]
    backend: Literal["rust", "python-fallback"]
```

The `backend` field is part of the contract so later stories can report whether the map came from the Rust engine or the fallback path.

### Python fallback responsibilities

The Python fallback builder accepts the discovered files plus raw import strings returned by the fallback extractor helpers:

```python
def build_graph(files: list[SourceFile], imports_by_file: dict[str, list[str]]) -> DependencyGraph: ...
```

It mirrors the Rust engine's resolution rules closely enough that classification and output behave the same way regardless of backend.

### Fallback resolution logic

Given a raw import string `X` extracted from file `A`, apply language-specific rules:

**Python**

- Convert dotted module form to a candidate path such as `rpr.context` → `src/rpr/context.py`.
- For relative imports such as `from . import utils`, resolve against the importing file's directory.

**TypeScript / JavaScript**

- Imports starting with `./` or `../` are relative and are resolved against the importing file's directory.
- Try `.ts`, `.tsx`, `.js`, `.jsx`, `.mjs`, `.cjs`, plus `index.*` variants, in a deterministic order.
- Non-relative imports are treated as external and dropped.

**Rust**

- `use crate::X::Y` is intra-crate; convert `::` separators to paths and search within the same crate source tree.
- `mod foo;` resolves to `foo.rs` or `foo/mod.rs` adjacent to the importing file.
- `extern crate X` and bare `use X::...` paths are treated as external and dropped.

**C++**

- `#include "X"` resolves relative to the including file, then against any discovered `include/` directories.
- `#include <X>` is treated as external/system and dropped.

If the resolved path matches a `SourceFile` in the project, add edge `A -> B`; otherwise discard it.

### Cycle detection

The fallback builder must detect cycles and populate `DependencyGraph.cycles` so the output writer can surface them.

## Assumptions

- The graph is directed: edge `A -> B` means `A` depends on `B`.
- External packages and unresolved imports are intentionally dropped.
- Duplicate edges are deduplicated.
- `__init__.py` files are regular nodes and may carry meaningful dependency information.
- C++ `include/` directories are inferred from the discovered files; compiler flags are not parsed.
- Rust crate-root resolution is limited to the current crate; cross-crate imports are treated as external in the fallback path.

## Acceptance Criteria

- [ ] `DependencyGraph` is defined in `src/rpr/map/graph.py` with `nodes`, `edges`, `reverse_edges`, `cycles`, and `backend`.
- [ ] `build_graph(files: list[SourceFile], imports_by_file: dict[str, list[str]]) -> DependencyGraph` is the Python fallback API.
- [ ] The Rust-backed path and Python-backed path both hydrate into the same `DependencyGraph` shape.
- [ ] Edges only contain files that appear in `graph.nodes`; external and stdlib imports are dropped.
- [ ] Both `edges` and `reverse_edges` are populated.
- [ ] Relative Python imports are resolved correctly in the fallback builder.
- [ ] Relative TypeScript/JavaScript imports are resolved correctly in the fallback builder, including extension and `index.*` probing.
- [ ] Rust `use crate::` paths and `mod foo;` declarations are resolved correctly in the fallback builder.
- [ ] C++ quoted includes are resolved; angle-bracket includes are dropped in the fallback builder.
- [ ] Duplicate edges are deduplicated.
- [ ] Any detected cycles are stored in `DependencyGraph.cycles: list[list[str]]`.
- [ ] Unit tests cover the fallback builder for: Python chain, TypeScript relative import, Rust `use crate::`, Rust `mod`, C++ quoted include, C++ angle-bracket include dropped, external package dropped, and a cycle.
