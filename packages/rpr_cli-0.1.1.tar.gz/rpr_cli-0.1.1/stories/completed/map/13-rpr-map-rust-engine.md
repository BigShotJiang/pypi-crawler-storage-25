# Story 13: Rust Map Engine — Crawl, Parse, Resolve, and Return the Graph

## User Story

As the map analysis bridge, I want a compiled Rust extension exposed through PyO3 that crawls the project, parses supported languages with tree-sitter, resolves in-project dependencies, and returns the dependency graph to Python so that the expensive analysis happens outside Python.

## Details

This story covers building a Rust extension crate (`rpr_parser`) that is compiled and installed as part of the `rpr` package. Python calls into it through PyO3, but from Python's perspective it is a normal module import. Unlike the earlier parser-only design, this crate owns the **entire heavy analysis stage** for the production path:

- file discovery / directory crawling
- per-language parsing
- import extraction
- import resolution to project files
- edge deduplication
- reverse-edge construction
- cycle detection

Python then converts the returned payload into the shared `DependencyGraph` dataclass and handles only classification and markdown output.

### Why tree-sitter + Rust

tree-sitter produces concrete syntax trees from source text without executing code. Combined with Rust, Rayon, and efficient file walking, it lets the project scan and dependency-resolution phase run in parallel and tolerate malformed files. That is the performance-sensitive part of `rpr map`, so it belongs in Rust.

### Crate layout

```
rpr-parser/
  Cargo.toml
  src/
    lib.rs        ← PyO3 module entry, registers Python-visible functions
    walker.rs     ← parallel project crawling and ignore filtering
    parse.rs      ← per-language tree-sitter parsing and import capture
    resolve.rs    ← import-to-file resolution rules
    graph.rs      ← edge construction, reverse edges, cycle detection
```

The crate is compiled by `maturin` and produces a native extension importable as `rpr_parser`.

### tree-sitter grammars required

| Language   | Grammar crate            |
| ---------- | ------------------------ |
| Python     | `tree-sitter-python`     |
| TypeScript | `tree-sitter-typescript` |
| JavaScript | `tree-sitter-javascript` |
| Rust       | `tree-sitter-rust`       |
| C / C++    | `tree-sitter-cpp`        |

Each grammar is a Cargo dependency; no runtime grammar compilation is needed.

### PyO3 API surface

The Rust crate exposes a minimal Python API focused on project analysis:

```python
# Crawls the project rooted at abs_root, builds the dependency graph,
# and returns a Python-serializable payload.
def build_dependency_graph(abs_root: str) -> dict[str, object]: ...
```

Expected payload shape:

```python
{
    "nodes": [
        {"abs_path": "/abs/file.py", "rel_path": "src/file.py", "language": "python"},
    ],
    "edges": {"src/file.py": ["src/other.py"]},
    "reverse_edges": {"src/other.py": ["src/file.py"]},
    "cycles": [["src/a.py", "src/b.py", "src/a.py"]],
}
```

The Rust function is the normal code path used by story 15.

### Crawl behavior

The Rust walker mirrors the ignore behavior already established in story 12:

- include: `.py`, `.ts`, `.tsx`, `.js`, `.jsx`, `.mjs`, `.cjs`, `.rs`, `.cpp`, `.cc`, `.cxx`, `.c`, `.h`, `.hpp`, `.hxx`
- ignore directories: `.venv/`, `venv/`, `.env/`, `node_modules/`, `__pycache__/`, `dist/`, `build/`, `.nx/`, `target/`, `.git/`, `vendor/`
- do not follow symlinks

This keeps the production crawl in Rust while preserving compatibility with story 12's Python fallback walker.

### Parse and resolution rules

Rust uses tree-sitter queries or direct node traversal to capture import-relevant syntax and then resolves those imports to project files using the same high-level rules described in story 14:

- **Python**: `import_statement` and `import_from_statement`, including relative import handling.
- **TypeScript / JavaScript**: `import_statement`, `require(...)`, and dynamic `import(...)` with relative-path resolution.
- **Rust**: `use_declaration`, `mod_item`, and `extern_crate_declaration`, with `crate::` and local `mod` resolution.
- **C++**: `preproc_include`, keeping quoted includes and dropping angle-bracket includes from the in-project graph.

Malformed or partially parseable files should yield whatever imports can be recovered; they should not raise fatal errors.

### Build integration

- `maturin` is added as a build dependency in `pyproject.toml`.
- `uv run maturin develop` builds the extension in-place for development.
- `uv run maturin build --release` produces a wheel for distribution.
- The built extension is importable as `rpr_parser` from Python tests and runtime code.

## Assumptions

- A Rust toolchain (`cargo`, `rustc` >= 1.75) must be present to build the extension; it is not required at runtime if a wheel is already built.
- `maturin` is the only build tool; `setuptools-rust` is not used.
- The Python fallback pipeline from stories 12 through 15 remains fully functional for environments without Rust.
- The Rust crate does not perform layer classification or markdown rendering; those remain Python responsibilities.
- The GIL is released while the Rust engine performs project crawling and graph construction.

## Acceptance Criteria

- [ ] A `rpr-parser/` directory exists at the workspace root with a valid `Cargo.toml` declaring `pyo3`, `rayon`, and the five tree-sitter grammar crates as dependencies.
- [ ] `rpr-parser/src/lib.rs` registers a PyO3 module with `build_dependency_graph`.
- [ ] `build_dependency_graph(abs_root)` crawls the project, parses supported files, resolves in-project imports, and returns a Python-serializable graph payload.
- [ ] The Rust engine performs directory walking in parallel and respects the same ignore rules as story 12.
- [ ] The Rust engine returns `nodes`, `edges`, `reverse_edges`, and `cycles` for the project.
- [ ] The GIL is released during `build_dependency_graph` execution.
- [ ] Malformed or partially parseable files return whatever imports were found before the error and do not raise fatal exceptions.
- [ ] All five languages produce correct graph edges against fixture projects.
- [ ] `uv run maturin develop` builds and installs the extension without errors.
- [ ] `src/rpr/map/extractor.py` imports `rpr_parser` in a `try/except ImportError` block and falls back to the Python pipeline when the extension is not built.
- [ ] CI documentation explains running `maturin develop` before tests that exercise the Rust path.
- [ ] Rust unit tests (`#[cfg(test)]`) exist for crawl filtering, language-specific parsing, path resolution, and cycle detection.
