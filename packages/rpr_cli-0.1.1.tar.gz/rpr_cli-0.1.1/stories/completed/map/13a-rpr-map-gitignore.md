# Story 13.a: Respect `.gitignore` in the Map Walker and Rust Engine

## User Story

As a user running `rpr map`, I want the map generation to ignore any files and directories that are listed in `.gitignore` so that the crawl does not waste time traversing `node_modules`, virtual environments, build artefacts, or other intentionally ignored paths.

## Details

The map feature currently has a hard-coded list of common directories to ignore (e.g. `node_modules/`, `.venv/`, `target/`). However, real-world projects can have additional exclusions in their `.gitignore` (or `.git/info/exclude`) that should influence the crawl.

This story adds support for loading ignore patterns from the repository root `.gitignore` file and applying them during file discovery in both:

- The Python file walker (`src/rpr/map/walker.py`) used by the fallback pipeline
- The Rust crawler in `rpr-parser` used by the high-performance engine

Ignore patterns should behave like Git ignore patterns (supporting globs and negations) at least for the common cases needed to keep the crawl within the intended source tree.

## Assumptions

- The `.gitignore` file is located at the root of the walk (the same `--root` passed to `rpr map`).
- If no `.gitignore` exists, the walker falls back to the existing hard-coded ignore list.
- `.gitignore` patterns are applied relative to the root of the project (not the current working directory unless it matches root).
- Negated patterns (`!`) are supported for common use cases (e.g., keeping a file in an ignored directory).

## Acceptance Criteria

- [ ] The file walker loads ignore patterns from `<root>/.gitignore` (if present) and uses them to skip paths during traversal.
- [ ] The Rust engine reads and applies the same `.gitignore` patterns when crawling the project.
- [ ] Ignored paths in `.gitignore` do not appear in the final `nodes`/`edges` output.
- [ ] Tests cover:
  - ignoring `node_modules/` when present in `.gitignore` (even if it would otherwise be crawled)
  - respecting a custom ignore entry (e.g., `secret/`)
  - negation patterns e.g. `!keep-me.txt` inside an ignored directory
- [ ] The behaviour is documented (either in story 12 / 13 or in code comments) as part of the map feature.
