# Story 17.b: Map Architecture Assessment and Onion Signals

## User Story

As an AI agent, I want the map to identify likely entry areas, core areas, leaves, hotspots, and architectural risks so that I can quickly assess whether a repository follows an onion-style architecture or has structural problems.

## Domain Context

- **Bounded Context:** Code Mapping
- **Impacted Aggregates/Entities:** `DependencyGraph`, `DirectoryTopology`, `ArchitectureAssessment`, `ArchitectureSignal`, `CycleSummary`, `Hotspot`

## Technical Implementation Plan

Introduce a new analysis module at `src/rpr/map/architecture.py` that consumes the file-level `DependencyGraph` and the full `DirectoryTopology` from story 17.a. Its job is to produce an agent-readable interpretation of the structure rather than another raw graph dump.

The resulting `ArchitectureAssessment` should identify:

- likely entry files and entry directories
- likely core directories that attract many incoming dependencies but depend on little else
- leaf files and leaf directories that terminate the dependency flow
- structural cycles from the file graph summarized at the directory level
- oversized or mixed-responsibility directories that should be flagged as hotspots
- a best-effort architecture verdict such as `likely_onion`, `layered_but_mixed`, or `unclear`

The assessment should not rely on generic layer numbers. Instead it should infer architectural shape from graph topology and directory boundaries. The full directory tree remains the navigable source of truth, while the assessment is allowed to compute derived projections over that tree at different depths to understand architectural flow. For example, a repository should be considered onion-like when dependency flow mostly converges inward, the derived directory dependency views are mostly acyclic, likely entry directories sit on the outside, and likely core directories are stable dependency sinks.

This story should keep analysis responsibilities isolated from rendering responsibilities. `architecture.py` computes facts and warnings; `output.py` only formats them. That keeps the design aligned with SRP and makes the rules testable without parsing Markdown.

The assessment should be conservative. If the graph does not clearly indicate onion or layered structure, the verdict should remain `unclear` and expose why. Examples include:

- high cycle density
- multiple giant directories with cross-dependencies
- strong peer-to-peer coupling between sibling directories
- no clear inward dependency convergence

To support later output, the module should also summarize why each signal was selected, such as support counts or degree metrics. Agents need both the conclusion and the evidence.

## Dependency & Package Requirements

No new packages are required. Implement with the Python standard library and the existing graph/topology modules.

## Assumptions & Open Questions

- Architectural verdicts are heuristics and should be framed as likely patterns, not guarantees.
- The assessment should prefer false negatives over false positives when declaring a project to be onion-like.
- File-level cycles remain the source of truth; directory-level cycle summaries are derived views.
- The full directory tree must remain intact even if the assessment chooses to reason about selected projections or directory depths.
- Open question: should test directories be fully excluded from the assessment, or only from the main architecture verdict?
- Open question: should framework-specific directories such as `routes` or `controllers` increase the confidence that a directory is an entry area?

## Acceptance Criteria

- `src/rpr/map/architecture.py` exists and exposes `assess_architecture(graph: DependencyGraph, topology: DirectoryTopology) -> ArchitectureAssessment`.
- `ArchitectureAssessment` includes likely entry files, likely entry directories, likely core directories, leaf files or directories, cycle summaries, hotspots, warnings, and an overall architecture verdict.
- Architecture inference operates over the complete directory topology and may compute derived dependency views at different directory depths without discarding any physical directories from the underlying model.
- Entry areas are derived from graph topology and directory boundaries rather than generic layer numbering.
- Core directories are identified using explicit degree-based heuristics and surfaced with supporting metrics.
- Onion-style verdicts are only emitted when dependency flow is predominantly inward and the derived directory dependency views are mostly acyclic.
- Repositories with cycles or heavily cross-coupled directories are reported as `layered_but_mixed` or `unclear`, with warnings explaining the reason.
- Hotspots flag directories that are unusually large, highly connected, or internally mixed in role.
- Unit tests cover: a clean onion-like example, a cycle-heavy example, a giant mixed directory hotspot, entry/core detection, and conservative fallback to `unclear` when evidence is weak.
