# Story 11: `rpr map` — Command Bootstrap

## User Story

As a developer (or AI agent), I want to run `rpr map` so that the CLI produces a structured code map of a project that identifies architectural layers, dependencies, and entry/exit points.

## Details

Introduce a new top-level `rpr map` command. This is the entry point for the entire code-mapping feature. It accepts a root path (defaults to current directory), an output path for the generated map file, and the usual `--dry-run` flag.

The command is the orchestrator: it delegates to the file walker, import extractor, graph builder, layer classifier, and output writer — each implemented in subsequent stories. At this stage, the command infrastructure (registration, CLI flags, `--dry-run` preview) is what matters.

The output is a single Markdown file (default: `code-map.md`) written at the project root (or a path supplied by `--output`). The file is intended to be read by AI agents, not humans or visualization tools.

## Assumptions

- The command operates against a pre-existing project directory on disk.
- Supported file types are `.py`, `.ts`, `.tsx`, `.js`, `.jsx`, `.mjs`, `.cjs`, `.rs`, `.cpp`, `.cc`, `.cxx`, `.c`, `.h`, `.hpp` — all others are ignored.
- Parsing is done by the Rust/tree-sitter engine (`rpr_parser`) when available; the extractor falls back to pure Python/regex if the extension is not built (see story 17).
- `--dry-run` prints what _would_ be analyzed and written but does not modify the filesystem.
- The command is added to the main `app` typer instance in `cli.py` (not nested under `generate` or another sub-app).

## Acceptance Criteria

- [ ] `rpr map` is registered as a top-level command in `src/rpr/cli.py`.
- [ ] Command accepts `--root PATH` (default: `.`) — the directory to analyze.
- [ ] Command accepts `--output PATH` (default: `code-map.md`) — where to write the map.
- [ ] Command accepts `--dry-run` — prints the intended actions without writing any files.
- [ ] `--dry-run` prints: the root being scanned, the output path that would be written, and a "no files written" notice.
- [ ] The command module lives at `src/rpr/commands/map.py` and is imported in `cli.py`.
- [ ] The command validates that `--root` exists and is a directory; exits with a clear error message if not.
- [ ] A unit test exists that invokes the command with `--dry-run` and asserts it exits cleanly without writing files.
