# Story 17.c: Map Representative Chains and Subgraph Evidence

## User Story

As an AI agent, I want the map to show a small number of representative file chains between entry points and leaves so that I can understand concrete dependency paths without reading an exhaustive edge list.

## Domain Context

- **Bounded Context:** Code Mapping
- **Impacted Aggregates/Entities:** `DependencyGraph`, `DirectoryTopology`, `ArchitectureAssessment`, `RepresentativeChain`, `RepresentativeEdgeExample`

## Technical Implementation Plan

Introduce a focused summarization module at `src/rpr/map/chains.py` that extracts deterministic, high-signal examples from the file graph and the full directory topology. This story bridges the gap between abstract directory-level diagrams and raw file-level edges.

The module should generate two kinds of evidence:

1. Entry-to-leaf chains that illustrate how a request or dependency flow moves through the codebase.
2. Representative file examples for each aggregated directory edge, such as `api/routes/user.routes.py -> domain/repos/user.repo.py`.

The chains must remain selective. The objective is not to enumerate every path, but to provide enough concrete examples for an agent to understand how the high-level graph materializes in the code. Selection should therefore be deterministic and bounded, for example by keeping:

- the shortest path from each likely entry file to one or more leaves
- at least one representative file chain per important directory edge
- a small capped number of examples per entry area

When multiple file paths support the same architectural relationship, the module should prefer examples that cross meaningful boundaries and avoid noisy package glue files where possible. If no leaf path exists because of cycles or dense connectivity, the module should still emit a short representative chain and annotate that the path terminated early.

This story keeps the rendering concerns out of the extraction logic. `chains.py` should return structured objects with ordered file lists, the directory boundaries crossed, and a reason why the chain was selected. The examples should be selected from the full preserved directory tree while remaining compatible with whichever derived directory views later output chooses to display. That allows later output to present examples differently without changing the analysis.

## Dependency & Package Requirements

No new packages are required. Implement with the Python standard library and the existing map modules.

## Assumptions & Open Questions

- Representative chains should be deterministic across runs for the same graph.
- The module may reuse the architecture assessment's entry-file hints instead of rediscovering them independently.
- Package glue files such as `__init__.py` should be deprioritized when a more descriptive neighboring file exists.
- Open question: should chains prefer the shortest path, the most common path, or the path that crosses the most meaningful directory boundaries when these differ?
- Open question: should the output cap be global or per entry directory?

## Acceptance Criteria

- `src/rpr/map/chains.py` exists and exposes `build_representative_chains(graph: DependencyGraph, topology: DirectoryTopology, assessment: ArchitectureAssessment) -> list[RepresentativeChain]`.
- `RepresentativeChain` includes the ordered file path list, the directory boundaries crossed, and the reason the chain was selected.
- The module returns at least one representative chain for each major entry area when a path to another in-project node exists.
- Representative chains are selected from the full directory topology and remain valid evidence for any derived top-level or module-level dependency views.
- The module emits representative file examples for aggregated directory edges, reusing evidence captured in the topology layer where possible.
- Output is deterministic and bounded; it does not explode to all possible paths.
- Cyclic graphs still yield useful truncated chains with an explicit note when a complete entry-to-leaf chain cannot be found.
- Unit tests cover: simple entry-to-leaf path extraction, multiple entries with bounded output, reuse of directory-edge evidence, avoidance of duplicate chains, and truncated chain behavior in the presence of cycles.
