# Story 16: Layer Classifier — Assign DDD Architectural Layers

## User Story

As the output writer, I want each file in the dependency graph to be assigned to a DDD architectural layer so that an agent reading the map can immediately understand the structure of the codebase without exploring the files manually.

## Details

The layer classifier (`src/rpr/map/classifier.py`) remains a Python concern. It consumes the shared `DependencyGraph` from story 14 regardless of whether that graph came from the Rust engine or the Python fallback. Classification uses path-pattern heuristics first, with graph-topology fallbacks for files that do not match any known pattern.

### Layer taxonomy

| Layer                  | Label            | Heuristic                                                                                  |
| ---------------------- | ---------------- | ------------------------------------------------------------------------------------------ |
| Entry point            | `entry_point`    | `cli.py`, `main.py`, `app.py`, `__main__.py`, `server.py`, or anything under `apps/`       |
| Application / Use-case | `application`    | path contains `services/`, `workflows/`, `use_cases/`, `handlers/`                         |
| Domain entity          | `entity`         | path contains `entities/`                                                                  |
| DTO / Schema           | `dto`            | path contains `dtos/`, `schemas/`, `models/` (non-ORM)                                     |
| Repository             | `repository`     | path contains `repos/`, `repositories/`                                                    |
| Infrastructure         | `infrastructure` | path contains `config/`, `db/`, `orm/`, `migrations/`                                      |
| UI component           | `ui_component`   | path contains `components/`, `pages/`, `screens/`, `views/`                                |
| UI hook/util           | `ui_util`        | path contains `hooks/`, `utils/`, ends in `.hook.ts` or `.util.ts`                         |
| Test                   | `test`           | path contains `tests/`, `__tests__/`, filename starts with `test_` or ends with `.test.ts` |
| Unknown                | `unknown`        | does not match any above pattern                                                           |

### Topology fallbacks (applied after path matching)

- A node with **no in-edges** (nothing imports it) and any out-edges → promote to `entry_point` if not already classified.
- A node with **no out-edges** (imports nothing in-project) → note as `leaf` in metadata (does not change layer).

### Output

```python
@dataclass
class ClassifiedNode:
    file: SourceFile
    layer: str               # one of the labels above
    is_leaf: bool            # no out-edges within the project
    in_degree: int           # number of files that import this file
    out_degree: int          # number of project files this file imports
```

## Assumptions

- Path heuristics are case-insensitive.
- A file can only have one primary layer; the first matching pattern wins (ordered as in the table above).
- Test files are classified as `test` regardless of other patterns they might match.
- The classifier does not read file contents and does not care which backend produced the graph.

## Acceptance Criteria

- [ ] `classify(graph: DependencyGraph) -> list[ClassifiedNode]` is the public API of `src/rpr/map/classifier.py`.
- [ ] Each node in `graph.nodes` produces exactly one `ClassifiedNode`.
- [ ] Classification output is identical for equivalent Rust-backed and Python-fallback graphs.
- [ ] Path-pattern heuristics are applied in the priority order from the table above.
- [ ] `test` is always highest-priority (checked first).
- [ ] `entry_point` topology fallback is applied only for nodes that matched `unknown` after path matching.
- [ ] `is_leaf` is `True` when the file has zero out-edges within the project.
- [ ] `in_degree` and `out_degree` are correctly computed from `graph.edges` / `graph.reverse_edges`.
- [ ] Unit tests cover: entry point detection by filename, each DDD layer by path segment, the `unknown` fallback, the topology-based entry point promotion, and leaf detection.
