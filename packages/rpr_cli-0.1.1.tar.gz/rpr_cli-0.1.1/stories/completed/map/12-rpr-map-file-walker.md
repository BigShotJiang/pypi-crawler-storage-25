# Story 12: File Walker — Source File Discovery

## User Story

As the `rpr map` command, I want to walk a project directory and catalog every Python, TypeScript/JavaScript, Rust, and C++ source file so that only relevant files are fed to the import extractor.

## Details

The file walker is a standalone module (`src/rpr/map/walker.py`) that accepts a root directory and returns a list of `SourceFile` objects. Each `SourceFile` records the absolute path, the path relative to the root, and the detected language.

### Supported languages and extensions

| Language     | Extensions                                        |
| ------------ | ------------------------------------------------- |
| `python`     | `.py`                                             |
| `typescript` | `.ts`, `.tsx`                                     |
| `javascript` | `.js`, `.jsx`, `.mjs`, `.cjs`                     |
| `rust`       | `.rs`                                             |
| `cpp`        | `.cpp`, `.cc`, `.cxx`, `.c`, `.h`, `.hpp`, `.hxx` |

### Ignored directories

The walker must respect common ignore patterns to avoid scanning generated files, virtual environments, and third-party code:

- `.venv/`, `venv/`, `.env/`
- `node_modules/`
- `__pycache__/`, `*.pyc`
- `dist/`, `build/`, `.nx/`, `target/` (Rust build output)
- `.git/`
- `vendor/` (C++ / Rust vendored deps)

The walker should be performant on large repos: use `os.scandir` (or `pathlib.Path.rglob`) and prune ignored directories early rather than visiting them.

## Assumptions

- Files are classified by extension only (see table above). All other extensions are silently skipped.
- Symlinks are not followed to prevent cycles.
- The walker does not parse file contents — it only discovers paths.
- `.h` / `.hpp` header files are classified as `cpp` since they can contain `#include` directives the graph builder needs.

## Acceptance Criteria

- [ ] `Language = Literal["python", "typescript", "javascript", "rust", "cpp"]` is defined in `src/rpr/map/walker.py`.
- [ ] `SourceFile` is a dataclass (or `TypedDict`) with fields: `abs_path: Path`, `rel_path: Path`, `language: Language`.
- [ ] `walk(root: Path) -> list[SourceFile]` is the public API of `src/rpr/map/walker.py`.
- [ ] All extensions from the supported-languages table are correctly classified.
- [ ] Directories in the ignore list (including `target/` and `vendor/`) are pruned before recursing.
- [ ] Symlinks are not followed.
- [ ] Returns an empty list (not an error) when the root directory contains no matching files.
- [ ] Unit tests cover: discovery of one file per language, pruning of `node_modules/`, `__pycache__/`, and `target/`, and ignoring unsupported extensions.
- [ ] The walker is importable and usable independently from the rest of the map pipeline.
