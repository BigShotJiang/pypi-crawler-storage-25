# Story 15: Analysis Bridge — Rust-First Project Dependency Extraction

## User Story

As the `rpr map` command, I want a Python bridge that asks the Rust engine for a complete dependency graph and only falls back to Python extraction/building when Rust is unavailable so that the production path keeps the heavy work out of Python.

## Details

The module at `src/rpr/map/extractor.py` becomes the **bridge between the CLI and the analysis backend**. Its primary responsibility is no longer “parse one file at a time.” Instead, it exposes a project-level API that prefers the compiled Rust engine from story 13 and returns a Python `DependencyGraph` object ready for classification and output.

### Primary path — Rust engine owns crawl + parse + graph work

When `rpr_parser` is importable, the bridge delegates the entire expensive analysis phase to Rust:

```python
try:
    import rpr_parser
    _RUST_AVAILABLE = True
except ImportError:
    _RUST_AVAILABLE = False
```

Primary API:

```python
def analyze_project(root: Path) -> DependencyGraph: ...
```

Rust call:

```python
payload = rpr_parser.build_dependency_graph(str(root))
```

The payload contains discovered files, resolved edges, reverse edges, and cycles. Python hydrates that payload into the shared `DependencyGraph` dataclass defined in story 14. In this path Python does **not** call the Python walker, Python extraction helpers, or Python graph builder.

### Fallback path — Python compatibility pipeline

If the extension is not built, the bridge falls back to the Python-only path assembled from stories 12 through 14:

1. `walk(root)` discovers supported source files.
2. `extract_imports(file)` / `extract_imports_batch(files)` parse raw import strings in Python.
3. `build_graph(files, imports_by_file)` resolves imports and constructs the dependency graph.

The per-file extraction helpers still live in `src/rpr/map/extractor.py`, but they exist to support the fallback path rather than the production path.

### Fallback extraction rules

**Python** — `ast` module:

- `import X` → emit `X`
- `from X import Y` → emit `X`

**TypeScript / JavaScript** — regex:

- `import ... from 'X'` / `"X"` → emit `X`
- `require('X')` / `require("X")` → emit `X`
- Dynamic `import('X')` → emit `X`

**Rust** — regex:

- `use X::Y::Z;` → emit `X::Y::Z`
- `mod foo;` (no body block) → emit `foo`
- `extern crate X;` → emit `X`
- `use X as Y` → emit `X`, not the alias

**C++** — regex:

- `#include "X"` → emit `X`
- `#include <X>` → emit `X`

The fallback remains intentionally simpler and less accurate than the Rust path. It exists so development and CI can still run without a Rust toolchain.

## Assumptions

- The Rust engine is the expected production backend; the Python path is a compatibility fallback.
- Python remains responsible for converting the Rust payload into the shared graph dataclasses used by later stories.
- Files that fail to read or parse are skipped with a warning in both paths; they are not fatal.
- The fallback extraction helpers return raw import strings only; path resolution happens in the Python fallback graph builder from story 14.
- Dynamic Python imports such as `importlib.import_module(variable)` are not statically resolvable and are ignored in the fallback path.

## Acceptance Criteria

- [ ] `analyze_project(root: Path) -> DependencyGraph` is the primary public API of `src/rpr/map/extractor.py`.
- [ ] `extract_imports(file: SourceFile) -> list[str]` and `extract_imports_batch(files: list[SourceFile]) -> dict[str, list[str]]` remain available for the Python fallback pipeline.
- [ ] When `rpr_parser` is importable, `analyze_project()` calls `rpr_parser.build_dependency_graph(...)` and does not invoke the Python walker, Python extraction helpers, or Python graph builder.
- [ ] When `rpr_parser` is not importable, `analyze_project()` falls back to `walk(root)` + `extract_imports_batch(files)` + `build_graph(files, imports_by_file)`.
- [ ] `_RUST_AVAILABLE: bool` is a module-level flag that tests can inspect.
- [ ] The fallback extraction helpers handle all five languages.
- [ ] Unsupported languages return an empty import list without raising in the fallback helpers.
- [ ] Unreadable or unparseable files are skipped in both paths with a warning.
- [ ] The returned `DependencyGraph.backend` is `"rust"` for the Rust path and `"python-fallback"` for the Python path.
- [ ] Unit tests cover both `analyze_project()` paths and fallback extraction for: Python imports, relative Python imports, TypeScript/JavaScript `import` and `require`, Rust `use` and `mod`, C++ `#include` in both forms, and a file that fails to parse.
- [ ] Tests that exercise the Rust path are skipped with `pytest.importorskip` when `rpr_parser` is not built.
