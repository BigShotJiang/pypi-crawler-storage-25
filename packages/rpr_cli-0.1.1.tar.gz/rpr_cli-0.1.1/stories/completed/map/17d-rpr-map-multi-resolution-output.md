# Story 17.d: Map Multi-Resolution Markdown Output

## User Story

As an AI agent, I want `code-map.md` to present a high-level architecture view, a lower-level directory view, and a few representative file examples so that I can understand the codebase quickly without being overloaded by raw graph details.

## Domain Context

- **Bounded Context:** Code Mapping
- **Impacted Aggregates/Entities:** `DependencyGraph`, `ClassifiedNode`, `DirectoryTopology`, `ArchitectureAssessment`, `RepresentativeChain`, `CodeMapDocument`

## Technical Implementation Plan

Redesign `src/rpr/map/output.py` so the default `code-map.md` becomes a multi-resolution architecture artifact instead of a layer-first dump. This story should consume the structured outputs from stories 17.a through 17.c and treat the existing file classifier as supplemental metadata rather than the primary organizing principle.

The output model should explicitly distinguish between:

- the complete directory containment tree, which preserves every directory under the analyzed root for navigation
- derived top-level dependency views, which summarize relationships such as `api -> domain`
- derived module-level dependency views, which summarize deeper relationships such as `api/routes -> domain/repos`

The directory tree is the complete navigable structure. The dependency graphs are filtered or depth-scoped projections over that structure, not replacements for it.

The default Markdown should be organized into the following sections, in order:

1. Header metadata
2. Architecture summary
3. Top-level dependency graph
4. Directory containment tree
5. Module dependency graph
6. Representative chains
7. Cycles and hotspots

The architecture summary should call out likely entry areas, likely core areas, likely leaves, the overall architecture verdict, and any warnings. The top-level dependency graph should show derived edges such as `api -> domain`. The module dependency graph should show meaningful subdirectory relationships such as `api/routes -> domain/repos` and `api/routes -> domain/models/entities`. The representative chains section should provide a small number of concrete file examples that substantiate those derived graphs.

Default output should no longer lead with generic sections such as `Layer Summary`, `Entry Points`, `Layers Breakdown`, or a full raw dependency edge dump. Those are useful only as optional diagnostics. Reuse the existing `--details` flag from `rpr map` to append a lower-priority appendix containing exhaustive file-oriented details for debugging, including the raw file edge list if needed.

This story also updates the orchestration path so `src/rpr/commands/map.py` assembles the richer document from the new analysis modules before writing it. Keep each module single-purpose:

- graph building stays in the existing extractor/graph modules
- directory condensation stays in `topology.py`
- architecture inference stays in `architecture.py`
- representative chain extraction stays in `chains.py`
- rendering stays in `output.py`

That separation preserves SOLID boundaries and makes each stage independently testable.

## Dependency & Package Requirements

No new packages are required. Implement with the Python standard library and the existing map modules.

## Assumptions & Open Questions

- Markdown remains the output format; Mermaid or Graphviz may remain optional but should not be the only way to consume the map.
- The default output should optimize for agent readability over human visual polish.
- `--details` should remain opt-in for raw file-level diagnostics.
- The complete directory containment tree should always preserve every directory under the analyzed root unless it was excluded earlier by the walker.
- Open question: should the containment tree be pure text, Mermaid, or both in the default output?
- Open question: should the legacy layer summary be removed entirely or preserved only in the detailed appendix during the transition?

## Acceptance Criteria

- `src/rpr/map/output.py` is updated so the default output contains architecture summary, top-level dependency graph, directory containment tree, module dependency graph, representative chains, and cycles or hotspots.
- `src/rpr/commands/map.py` assembles the new topology, architecture assessment, and representative chains before calling the output writer.
- The directory containment tree in the default output preserves every directory under the analyzed root and serves as the navigable backbone of the document.
- The default output no longer leads with generic layer-first sections; any raw file-layer diagnostics are moved behind `--details`.
- The top-level graph shows derived directory relationships such as `api -> domain` when supported by the file graph.
- The module graph shows derived subdirectory relationships without expanding to all file edges.
- Representative chains include concrete file examples that justify at least the most important directory edges.
- Cycles and hotspot warnings are included only when present.
- `--details` appends a diagnostic appendix with raw file-level information without changing the concise high-level sections.
- Unit tests cover: default multi-resolution layout, omission of legacy sections from the default output, inclusion of representative chains, conditional hotspot and cycle sections, and `--details` behavior for the appendix.
