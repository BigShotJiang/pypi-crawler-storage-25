# Story 17.a: Map Directory Topology and Graph Condensation

## User Story

As an AI agent, I want the map pipeline to condense file dependencies into meaningful directory-level nodes so that I can understand a repository's architectural shape before drilling into individual files.

## Domain Context

- **Bounded Context:** Code Mapping
- **Impacted Aggregates/Entities:** `DependencyGraph`, `SourceFile`, `DirectoryNode`, `DirectoryEdge`, `DirectoryTopology`

## Technical Implementation Plan

Introduce a new module at `src/rpr/map/topology.py` that treats the existing file-level `DependencyGraph` as the source of truth and derives a directory-aware architecture view from it. This story is the foundation for the new multi-resolution map design and should supersede the current layer-first interpretation from stories 16 and 17.

The implementation should build three related structures from the file graph:

1. A complete directory containment index that records every directory, file, and parent-child relationship under the analyzed root.
2. A top-level dependency graph that aggregates file edges to major root-relative directories, such as `api -> domain`.
3. A module-level dependency graph that derives useful subgraphs from the full directory tree, such as `api/routes -> domain/repos`, without exploding into every file-to-file relationship.

Add a `DirectoryTopology` aggregate that contains:

- every discovered directory as a node
- parent/child containment relationships
- aggregated dependency edges at multiple directory depths with support counts
- the representative file pairs that justified each directory edge
- the list of files contained within each directory node

Directory preservation is the key behavior. Every physical folder under the analyzed root should appear as a node in the containment model so the resulting map remains navigable for an agent trying to locate files.

Summarization should happen in derived views, not by deleting directory nodes from the topology. In practice, this means the topology layer should retain the full directory tree while also computing helper projections for later stories, including:

- root-level directory edges such as `api -> domain`
- scoped subgraphs for a directory and its immediate children
- deeper dependency slices such as `domain/models -> domain/repos` or `api/routes -> domain/models/entities`
- support counts that indicate which directory-to-directory relationships are structurally important

This keeps the model aligned with SOLID by separating concerns: the file graph remains unchanged, the directory topology is a faithful projection of the filesystem, and higher-level summaries are derived views over that topology rather than lossy replacements for it.

The topology builder must also preserve enough evidence for later stories. Every aggregated directory edge should carry a deterministic set of representative file pairs so later output can show concrete examples without recomputing the graph. That preserves a clean boundary between analysis and rendering.

## Dependency & Package Requirements

No new packages are required. Implement with the Python standard library and the existing map modules.

## Assumptions & Open Questions

- The file-level `DependencyGraph` remains the canonical model and is not replaced.
- Directory paths should preserve original path casing in the output.
- `__init__.py` and other package glue files belong to their real directories and should contribute to containment and dependency evidence like any other file.
- Derived dependency views may choose which directory depth to display, but the underlying topology must still preserve the entire directory tree.
- Open question: should the top-level projection treat wrappers such as `src/` as first-class roots, or should it optionally project one level deeper when the repository has a single source container?
- Open question: should hidden directories be preserved in the topology when they are inside the analyzed root and not ignored by the walker?

## Acceptance Criteria

- `src/rpr/map/topology.py` exists and exposes `build_directory_topology(graph: DependencyGraph, root: Path) -> DirectoryTopology`.
- `DirectoryTopology` includes every discovered directory node, full containment edges, aggregated dependency edges at multiple directory depths, and representative file-pair evidence for each aggregated edge.
- A project with `api/routes/user.routes.py -> domain/repos/user.repo.py` produces directory nodes for `api`, `api/routes`, `domain`, and `domain/repos`, plus a top-level derived edge `api -> domain`.
- The same project can also produce deeper derived edges such as `api/routes -> domain/repos`, `api/routes -> domain/models/entities`, and `api/routes -> domain/models/dtos` when those file edges exist.
- No physical directories under the analyzed root are discarded from the topology model unless they were already excluded by the walker.
- Duplicate directory edges are deduplicated and include a support count representing how many file edges contributed to each aggregate at the requested depth.
- Each aggregated directory edge stores at least one representative source file and destination file pair.
- Unit tests cover: preservation of the full directory tree, top-level derived edges, module-level derived edges, deterministic containment ordering, and representative file-pair capture.
