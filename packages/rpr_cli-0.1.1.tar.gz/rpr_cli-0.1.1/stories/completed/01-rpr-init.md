# Story 01: `rpr init <project-name>`

## User Story

As a developer, I want to run `rpr init my-app` to scaffold a complete NX + UV monorepo so that I have a working project structure with both Node and Python tooling wired together, plus AI instructions for Cursor, VS Code Copilot, Claude, and Gemini CLI.

## Goal

Create the initial workspace structure, orchestrate external CLIs in the correct order, and scaffold AI instruction files for multiple tools so the generated project is immediately usable and AI-assisted.

## Project Detection & Init Flow

### NX Workspace

| Scenario                                                                  | Action                                                |
| ------------------------------------------------------------------------- | ----------------------------------------------------- |
| **Brand new project** (directory does not exist or is empty)              | Create workspace via `npx create-nx-workspace@latest` |
| **Existing non-NX project** (has files but no `nx.json` / `project.json`) | Run `npx nx init` to add NX to existing project       |
| **Already NX workspace** (has `nx.json` or `project.json`)                | Skip NX setup; inform user: "Already an NX project"   |

### UV Init

| Scenario                                                                       | Action                                                           |
| ------------------------------------------------------------------------------ | ---------------------------------------------------------------- |
| **No UV project** (no `pyproject.toml` or no UV/workspace config)              | Run `uv init` with user-selected options (e.g., `--python 3.14`) |
| **Already uses UV** (has `pyproject.toml` with UV workspace or tool.uv config) | Skip `uv init`; avoid overwriting existing config                |

## Variable Token Map

All variable tokens are derived from the single `<project-name>` argument and stored in `.rpr.yaml` under a `variables:` key so that `rpr sync rules` and other commands can read them without re-prompting.

| Token               | Derivation                       | Example (`my-app`) |
| ------------------- | -------------------------------- | ------------------ |
| `{name}`            | Raw project name as given        | `my-app`           |
| `{name-of-app}`     | Same as `{name}` (dash form)     | `my-app`           |
| `{name_underscore}` | Dashes replaced with underscores | `my_app`           |
| `{NamePascal}`      | PascalCase of the project name   | `MyApp`            |

These tokens are replaced in **both instruction file content and file paths** before writing. For example, if the project is `foo`:

- `src/{name_underscore}_domain/` → `src/foo_domain/`
- A reference to `{name-of-app}` in instruction body text → `foo`

## AI Instructions Scaffolding

Init must create **instruction files** (when-to-use guidance) for all supported AI platforms. Use the bundled source markdown files in `src/rpr/scaffolds/instructions/` as the default source of truth; `Sample-dot-github/instructions/` mirrors those files for reference. Init does **not** add special files (code templates); that is done via `rpr add template`.

## Root Tooling Defaults

Init should also scaffold the workspace-level tooling defaults needed by later generators and AI instructions:

- Root `package.json` scripts for `lint`, `lint:fix`, `format`, `format:check`, and `typecheck`
- Root `eslint.config.mjs` using ESLint flat config
- Root `.prettierrc` and `.prettierignore`
- Root `.pre-commit-config.yaml`
- Root `nx.json` plugin registration for `@nx/eslint/plugin`
- Root `pyproject.toml` dev tooling for Ruff, pytest, and pre-commit

### Target Platforms

| Platform              | Output Location                      | Format                                                                                                                                |
| --------------------- | ------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------- |
| **VS Code / Copilot** | `.github/copilot-instructions.md`    | Single always-on file per [VS Code custom instructions](https://code.visualstudio.com/docs/copilot/customization/custom-instructions) |
| **Cursor**            | `.cursor/rules/*.mdc`                | One `.mdc` file per rule; keep each rule small and focused                                                                            |
| **Claude**            | `CLAUDE.md` (or `.claude/CLAUDE.md`) | Single always-on instructions file                                                                                                    |
| **Gemini CLI**        | TBD (config format for Gemini CLI)   | CLI-specific instruction format                                                                                                       |

### VS Code / Copilot

- `all.instructions.md` → `.github/copilot-instructions.md`
- Per VS Code docs: this file is automatically detected and applied to all chat requests

### Cursor `.mdc` Frontmatter Conversion

Source `.instructions.md` files use a YAML frontmatter with `applyTo` and `description`. When writing `.mdc` files for Cursor, convert as follows:

| Source field  | `.mdc` field  | Rule                                                                           |
| ------------- | ------------- | ------------------------------------------------------------------------------ |
| `description` | `description` | Copy as-is                                                                     |
| `applyTo`     | `globs`       | Copy as-is (it is already a glob pattern)                                      |
| _(derived)_   | `alwaysApply` | `true` when `applyTo: "**"` (project-wide); `false` for all other scoped rules |

Example — `domain.instructions.md` has `applyTo: "packages/python/domain/**"`, so its `.mdc` output is:

```yaml
---
description: "Domain layer structure, entities, DTOs, repos, and workflows"
globs: "packages/python/domain/**"
alwaysApply: false
---
```

Example — `all.instructions.md` has `applyTo: "**"`, so its `.mdc` output is:

```yaml
---
description: "Project overview, monorepo structure, and tech stack for DDD architecture"
globs: "**"
alwaysApply: true
---
```

- **Keep each rule small**: Minimize context; one concern per rule; split large instructions into focused rules
- Variable tokens in the instruction body are replaced before writing (see Variable Token Map above)

### Instructions vs Special Files

**Special files** (`special_files/`, `js_special_files/`) are **code templates** to be generated. They contain the actual implementation (e.g., `dto_util.md`, `mapper_util.md`, `partial_update.md`, `fetch.service.md`, `useStateNavigation`).

**Instructions** are **when-to-use** guidance. They tell the AI:

- When to use a given special file or pattern
- What to reference in code or architecture decisions
- When to apply a mapper, DTO util, or partial update

Do **not** put the full implementation in instructions. Instructions should be short and reference the special file or pattern. The actual code lives in special files and is added via `rpr add template`.

### Rule-to-Platform Mapping (Future Extensibility)

Define a directory structure and config so that when new rules are added, the CLI knows where each rule/instruction goes:

| Source Location                   | Purpose                                                             |
| --------------------------------- | ------------------------------------------------------------------- |
| `src/rpr/scaffolds/instructions/` | Bundled source templates for instructions                           |
| `special_files/`                  | Python code templates (dto_util, mapper_util, partial_update, etc.) |
| `js_special_files/`               | Node/JS code templates (fetch service, useStateNavigation, etc.)    |

**Config-driven mapping** (e.g., `.rpr.yaml` or similar):

- Map source files to target platforms: `api.instructions.md` → Cursor rule + Copilot instruction + Claude section
- When user adds a new `.md` file, the CLI uses the config to determine:
  - Which platform(s) it targets (Cursor, Copilot, Claude, Gemini)
  - Whether it is a **special file** (code to generate) or an **instruction** (when-to-use guidance)
  - Whether it becomes a single file or is split into multiple rules
  - Glob patterns for file-specific rules

## Acceptance Criteria

- [ ] Detects project state: brand new vs existing non-NX vs already NX workspace.
- [ ] Brand new: runs `npx create-nx-workspace@latest`.
- [ ] Existing non-NX: runs `npx nx init` for existing projects.
- [ ] Already NX: skips NX setup and prints "Already an NX project".
- [ ] Runs `uv init` only when needed (no existing UV project).
- [ ] Skips `uv init` if project already uses UV.
- [ ] Creates `.github/copilot-instructions.md` from `all.instructions.md`.
- [ ] Creates Cursor rules in `.cursor/rules/` from source instructions; keeps each rule small.
- [ ] Creates `CLAUDE.md` for Claude Code.
- [ ] Creates Gemini CLI instructions (format TBD).
- [ ] Defines directory structure and config for future rule additions.
- [ ] Adds the workspace, include/exclude, and target mapping to `.rpr.yaml` (or equivalent).
- [ ] Writes a `variables:` block to `.rpr.yaml` containing `name`, `name-of-app`, `name_underscore`, and `NamePascal` derived from `<project-name>`, so `rpr sync rules` and other commands can substitute them without re-prompting.
- [ ] Replaces all variable tokens in instruction content and file paths before writing any AI instruction file.
- [ ] Runs `git init` (implicit in create-nx-workspace or explicit for nx init).
- [ ] Prompts for configuration (Python version, defaults to 3.14).
- [ ] Writes root config files: `nx.json`, `pyproject.toml`, `package.json`, `tsconfig.base.json`, `eslint.config.mjs`, `.prettierrc`, `.prettierignore`, `.pre-commit-config.yaml`, `.gitignore`, `.env.example`.
- [ ] Registers `@nx/eslint/plugin` in `nx.json` so lint targets can follow Nx ESLint conventions.
- [ ] Adds root Node tooling scripts for `lint`, `lint:fix`, `format`, `format:check`, and `typecheck`.
- [ ] Runs `npm install` after writing Node-side tooling defaults.
- [ ] Runs `uv sync` after generation.
- [ ] Prompts for `<project-name>` when omitted.
- [ ] Supports `--dry-run` and prints commands and files without creating them.

## Command Flow

1. Determine project state (brand new / existing non-NX / already NX).
2. If already NX: inform user and skip NX setup.
3. If brand new: run `npx create-nx-workspace@latest`.
4. If existing non-NX: run `git init` (if needed) and `npx nx init`.
5. Check if UV is already in use; if not, run `uv init` with selected flags.
6. Create standard directories (`apps/`, `packages/node/`, `packages/python/`).
7. Write/update root config files.
8. Scaffold AI instructions (Copilot, Cursor, Claude, Gemini CLI).
9. Write `.rpr.yaml` with source paths and target mappings.
10. Run `npm install` to install ESLint and Prettier dependencies.
11. Run `uv sync`.

## Key Files

- `src/rpr/commands/init.py`
- `src/rpr/scaffolds/instructions/` (bundled source templates)
- `Sample-dot-github/instructions/` (reference mirror of the bundled templates)
- `special_files/` (Python guidance)
- `js_special_files/` (Node/JS guidance)

## Notes

- The domain package should match conventions from AI guidance markdowns.
- Use `uv add` if stored dependencies need to be managed programmatically.
- Keep Cursor rules small: one concern per rule, under ~50 lines where possible.
- **Instructions = when to use**; special files = actual code. Mappers, DTO util, partial update, fetch service, etc.: instructions describe when to use them; the CLI generates the code from special files.
- Reference: [VS Code custom instructions](https://code.visualstudio.com/docs/copilot/customization/custom-instructions).
- The `.rpr.yaml` `variables:` block is the canonical source for token substitution. Example:

```yaml
variables:
  name: "my-app"
  name-of-app: "my-app"
  name_underscore: "my_app"
  NamePascal: "MyApp"
```

## Definition of Done

- [ ] The generated project can be opened as an NX workspace.
- [ ] Root `pyproject.toml` is configured as a UV workspace.
- [ ] Root TS config exists for later Node packages.
- [ ] Root ESLint, Prettier, and pre-commit config files exist.
- [ ] Root `package.json` contains workspace lint, format, and typecheck scripts.
- [ ] `.github/copilot-instructions.md` exists and is applied by VS Code.
- [ ] `.cursor/rules/` contains focused `.mdc` rules.
- [ ] `CLAUDE.md` exists for Claude Code.
- [ ] Config and directory structure support adding new rules without code changes.
- [ ] `.rpr.yaml` `variables:` block is written and contains all four token variants.
- [ ] Variable tokens are replaced in instruction body text and path strings before writing.
- [ ] Cursor `.mdc` files have correct `globs` and `alwaysApply` derived from source `applyTo`.
- [ ] The command is safe to preview with `--dry-run`.
