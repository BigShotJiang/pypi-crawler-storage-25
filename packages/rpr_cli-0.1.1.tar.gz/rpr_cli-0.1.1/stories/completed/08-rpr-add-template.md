# Story 08: `rpr add template <template-id>`

## User Story

As a developer, I want to run `rpr add template mapper_util` to add a specific utility file to my project so that I get the exact implementation from my templates with project-specific names filled in.

## Goal

**This command is the canonical way to add special files** (code templates) to a project. It reads markdown reference implementations from `special_files/` and `js_special_files/`, extracts the code, and writes it to the correct target path with variables replaced.

Neither `rpr init` nor `rpr generate ui` add these files directly — they delegate to or prompt the user to run `rpr add template` for each needed template.

## Instructions vs Special Files

| Type                               | Added By           | Source                                |
| ---------------------------------- | ------------------ | ------------------------------------- |
| **Instructions** (when-to-use)     | `rpr sync rules`   | `src/rpr/scaffolds/instructions/`     |
| **Special files** (code templates) | `rpr add template` | `special_files/`, `js_special_files/` |

## Template Registry

| Template ID         | Source File                             | Target Path                                                                                   |
| ------------------- | --------------------------------------- | --------------------------------------------------------------------------------------------- |
| `domain_settings`   | `special_files/domain_settings.md`      | `packages/python/domain/src/<name>_domain/config/settings.py`                                 |
| `domain_container`  | `special_files/domain_container.md`     | `packages/python/domain/src/<name>_domain/config/container.py`                                |
| `mapper_util`       | `special_files/mapper_util.md`          | Python domain package (e.g., `packages/python/domain/src/<name>_domain/utils/mapper_util.py`) |
| `dto_util`          | `special_files/dto_util.md`             | Python domain package utils                                                                   |
| `partial_update`    | `special_files/partial_update.md`       | Python domain package utils                                                                   |
| `encrypted_column`  | `special_files/encrypted_column.md`     | Python domain package (models/config)                                                         |
| `sticky_navigation` | `js_special_files/sticky-navigation.md` | `packages/node/<name>-ui/src/hooks/useStateNavigation.ts`                                     |
| `fetch_service`     | `js_special_files/fetch.service.md`     | `packages/node/<name>-ui/src/services/base/api.service.ts`                                    |

Target paths are variable-aware (e.g., `{name-of-app}`) and may depend on project structure. The registry defines the mapping.

## Acceptance Criteria

- [ ] `rpr add template --list` shows all available templates.
- [ ] Reads the source markdown for the selected template from `special_files/` or `js_special_files/`.
- [ ] Extracts the relevant code block from the markdown.
- [ ] Replaces variables such as `{name-of-app}` and project-specific import paths.
- [ ] Writes the file to the correct target location (from registry).
- [ ] Prompts before overwrite unless `--force` is used.
- [ ] Supports `--dry-run`.
- [ ] Always displays the target path and command before writing (per Story 00).
- [ ] **This command is the only way to add special files**; init and generate do not add them directly.

## Key Files

- `src/rpr/commands/add.py`
- `src/rpr/templates/registry.py`
- `special_files/` (Python templates)
- `js_special_files/` (Node/JS internal template sources)

## Notes

- Keep the registry explicit so paths stay predictable.
- Prefer one target path per template to start.
- Works with domain and UI generators; does not require them to exist first in dry-run mode.
- When `rpr generate ui` creates a UI library, the user (or a follow-up flow) runs `rpr add template fetch_service` and `rpr add template sticky_navigation` to add those files.
- `domain_settings` and `domain_container` are special in that `rpr generate domain` also writes these files initially (from bundled scaffold mirrors in `src/rpr/scaffolds/domain/`). Use `rpr add template domain_settings` or `rpr add template domain_container` to reset either file to the canonical template after project-local changes. See **Story 10** for the full settings and container contract.

## Definition of Done

- [ ] Template listing works.
- [ ] Template extraction works from markdown code fences.
- [ ] Output paths are deterministic and variable-aware.
- [ ] Dry-run previews the resolved file path and generated content.
- [ ] Add template is the canonical way to add special files; init and generate do not duplicate this logic.
