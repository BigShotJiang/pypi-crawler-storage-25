# Story 00: Bootstrap the CLI Package

## User Story

As a developer, I want a working `rpr` CLI skeleton so that I can install it and run `rpr --help`.

## Goal

Create the base Python package, register the CLI entry point, and establish shared dry-run behavior and execution display rules that all later commands can reuse.

## Acceptance Criteria

- [ ] Running `uv tool install .` or `uv sync` for local dev makes the `rpr` command available.
- [ ] `rpr --help` shows the top-level command groups: `init`, `generate`, `sync`, `add`.
- [ ] `rpr --version` prints the version.
- [ ] A shared `RunContext` dataclass exists with `dry_run`, `run_command()`, and file helper methods.
- [ ] Dry-run output is human-readable and consistent across commands.
- [ ] **Always display the command** when executing another CLI (e.g., `nx`, `uv`, `npx`).
- [ ] When `--dry-run` is passed: forward to nested CLI if it supports it; otherwise only display the command that would be executed.

## Executing Nested CLIs

When the rpr CLI invokes another CLI (e.g., `nx`, `uv`, `npx`, `git`):

1. **Always display the command** in the console before executing it, so the user can validate it is correct.
2. **Dry-run behavior**:
   - If the nested CLI supports it (e.g., `nx g ... --dry-run`), forward `--dry-run` and let it handle preview.
   - If the nested CLI does not support dry-run, do **not** execute it; only display the command that would be run.

## Testing

- When testing any command that invokes nested CLIs, use a **"fake" app** and dry-run to verify:
  - The intended command is displayed
  - The command matches expectations
  - No unintended side effects occur

## Key Files

- `pyproject.toml`
- `src/rpr/__init__.py`
- `src/rpr/cli.py`
- `src/rpr/context.py`
- `src/rpr/commands/__init__.py`

## Implementation Notes

- Use `typer` for the CLI framework.
- Register `rpr` using `[project.scripts]`.
- Build a reusable `RunContext` so every later command inherits the same execution and preview behavior.
- Dry-run should print commands and file operations without mutating the filesystem.
- `run_command()` should always print the command before execution (e.g., `[rpr] Running: nx g @nx/react:application apps/my-app`).

## Definition of Done

- [ ] Package installs with `uv`.
- [ ] Top-level CLI help works.
- [ ] Version flag works.
- [ ] Shared context is reusable by later command modules.
- [ ] Commands are always displayed before executing nested CLIs.
- [ ] Dry-run is forwarded when supported; otherwise only the command is shown.
- [ ] Story is documented well enough for another contributor to continue from here.
