import { useCallback, useLayoutEffect, useState } from "react";

type NavigationStateChangeDetail = {
  property: string;
  newValue: string | null;
};

type SetNavigationValueOptions = {
  replace?: boolean;
};

type SetNavigationValue = (
  newValue: string | null,
  options?: SetNavigationValueOptions,
) => void;

const normalizeValue = (value?: string | null): string => value?.trim() ?? "";

const getInitialValue = (property: string, defaultValue: string): string => {
  const currentParams = new URLSearchParams(window.location.search);
  const normalizedDefaultValue = normalizeValue(defaultValue);

  return normalizeValue(currentParams.get(property)) || normalizedDefaultValue;
};

const buildUrlFromValue = (property: string, value?: string | null): string => {
  const normalizedValue = normalizeValue(value);
  const currentParams = new URLSearchParams(window.location.search);

  if (!normalizedValue) {
    currentParams.delete(property);
  } else {
    currentParams.set(property, normalizedValue);
  }

  const newSearch = currentParams.toString();

  return newSearch
    ? `${window.location.pathname}?${newSearch}${window.location.hash}`
    : `${window.location.pathname}${window.location.hash}`;
};

export const useStateNavigation = (
  property: string,
  defaultValue = "",
): readonly [string, SetNavigationValue] => {
  const normalizedDefaultValue = normalizeValue(defaultValue);

  const [value, setValueState] = useState(() =>
    getInitialValue(property, normalizedDefaultValue),
  );

  const syncValueFromUrl = useCallback(() => {
    const nextValue = getInitialValue(property, normalizedDefaultValue);

    setValueState((previousValue) =>
      previousValue === nextValue ? previousValue : nextValue,
    );
  }, [property, normalizedDefaultValue]);

  useLayoutEffect(() => {
    syncValueFromUrl();
  }, [syncValueFromUrl]);

  useLayoutEffect(() => {
    const controller = new AbortController();

    const handleNavigationStateChange = (event: Event) => {
      const customEvent = event as CustomEvent<NavigationStateChangeDetail>;
      const { property: changedProperty, newValue } = customEvent.detail;

      if (changedProperty !== property) {
        return;
      }

      const normalizedValue = normalizeValue(newValue);

      setValueState((previousValue) =>
        previousValue === normalizedValue ? previousValue : normalizedValue,
      );
    };

    window.addEventListener(
      "NavigationStateChange",
      handleNavigationStateChange,
      { signal: controller.signal },
    );
    window.addEventListener("popstate", syncValueFromUrl, {
      signal: controller.signal,
    });

    return () => {
      controller.abort();
    };
  }, [property, syncValueFromUrl]);

  const setValue = useCallback<SetNavigationValue>(
    (newValue, options) => {
      const normalizedValue = normalizeValue(newValue);
      const newUrl = buildUrlFromValue(property, normalizedValue);
      const currentUrl = `${window.location.pathname}${window.location.search}${window.location.hash}`;

      if (newUrl === currentUrl) {
        return;
      }

      if (options?.replace) {
        window.history.replaceState(null, "", newUrl);
      } else {
        window.history.pushState(null, "", newUrl);
      }

      window.dispatchEvent(
        new CustomEvent<NavigationStateChangeDetail>("NavigationStateChange", {
          detail: {
            property,
            newValue: normalizedValue || null,
          },
        }),
      );
    },
    [property],
  );

  useLayoutEffect(() => {
    if (!normalizedDefaultValue) {
      return;
    }

    const urlValue = normalizeValue(
      new URLSearchParams(window.location.search).get(property),
    );

    if (urlValue) {
      return;
    }

    setValue(normalizedDefaultValue, { replace: true });
  }, [normalizedDefaultValue, property, setValue]);

  return [value, setValue] as const;
};
