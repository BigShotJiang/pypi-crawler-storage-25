export type ApiError = {
  message: string;
  status: number;
  details?: unknown;
  response: Response;
};

declare const getToken: () => Promise<string | null>;
declare const globalErrorHandler: ((error: ApiError) => void) | undefined;

const buildUrl = (
  endpoint: string,
  params?: Record<string, unknown>,
): string => {
  // Replace this with the project's actual API base URL and query handling.
  const url = new URL(endpoint, window.location.origin);

  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value === undefined || value === null || value === "") {
        return;
      }

      url.searchParams.set(key, String(value));
    });
  }

  return url.toString();
};

const createRequestInit = async (
  method: string,
  initHeaders?: HeadersInit,
  body?: BodyInit,
): Promise<RequestInit> => {
  const headers = new Headers({
    Accept: "application/json",
    ...initHeaders,
  });

  if (body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  if (!headers.has("Authorization")) {
    const token = await getToken();
    if (token) {
      headers.set("Authorization", `Bearer ${token}`);
    }
  }

  const requestInit: RequestInit = {
    method,
    headers,
  };

  if (body) {
    requestInit.body = body;
  }

  return requestInit;
};

const onApi401 = async (
  _response: Response,
  error: ApiError,
): Promise<never> => {
  return Promise.reject(error);
};

const handleError = async (response: Response): Promise<ApiError> => {
  let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
  let errorDetails: unknown = response.statusText;

  try {
    const contentType = response.headers.get("content-type");

    if (contentType && contentType.includes("application/json")) {
      const errorData = (await response.json()) as {
        message?: string;
        detail?: string;
      };

      errorMessage = errorData.message || errorData.detail || errorMessage;
      errorDetails = errorData;
    } else {
      const textError = await response.text();
      if (textError) {
        errorMessage = textError;
        errorDetails = textError;
      }
    }
  } catch (error: unknown) {
    console.error("Failed to parse default message", error);
  }

  return {
    message: errorMessage,
    status: response.status,
    details: errorDetails,
    response,
  };
};

const handleResponse = async <T>(response: Response): Promise<T> => {
  if (!response.ok) {
    const error = await handleError(response);
    if (response.status === 401) {
      return await onApi401(response, error);
    }

    if (globalErrorHandler) {
      globalErrorHandler(error);
    }

    throw error;
  }

  if (response.status === 204) {
    return undefined as T;
  }

  const contentType = response.headers.get("content-type");
  if (contentType && contentType.includes("application/json")) {
    return await response.json();
  }

  if (contentType && contentType.includes("image/")) {
    const blob = await response.blob();
    return blob as unknown as T;
  }

  const text = await response.text();
  return text as unknown as T;
};

export const apiService = {
  async get<T>(
    endpoint: string,
    params?: Record<string, unknown>,
    headers?: HeadersInit,
  ): Promise<T> {
    const url = buildUrl(endpoint, params);
    const requestInit = await createRequestInit("GET", headers);
    const response = await fetch(url, requestInit);
    return handleResponse<T>(response);
  },

  async post<T>(
    endpoint: string,
    data?: unknown,
    headers?: HeadersInit,
  ): Promise<T> {
    const url = buildUrl(endpoint);
    const requestInit = await createRequestInit(
      "POST",
      headers,
      data ? JSON.stringify(data) : undefined,
    );
    const response = await fetch(url, requestInit);
    return handleResponse<T>(response);
  },

  async put<T>(
    endpoint: string,
    data?: unknown,
    headers?: HeadersInit,
  ): Promise<T> {
    const url = buildUrl(endpoint);
    const requestInit = await createRequestInit(
      "PUT",
      headers,
      data ? JSON.stringify(data) : undefined,
    );
    const response = await fetch(url, requestInit);
    return handleResponse<T>(response);
  },

  async delete<T>(endpoint: string, headers?: HeadersInit): Promise<T> {
    const url = buildUrl(endpoint);
    const requestInit = await createRequestInit("DELETE", headers);
    const response = await fetch(url, requestInit);
    return handleResponse<T>(response);
  },

  async patch<T>(
    endpoint: string,
    data?: unknown,
    headers?: HeadersInit,
  ): Promise<T> {
    const url = buildUrl(endpoint);
    const requestInit = await createRequestInit(
      "PATCH",
      headers,
      data ? JSON.stringify(data) : undefined,
    );
    const response = await fetch(url, requestInit);
    return handleResponse<T>(response);
  },
};
