Reference example for a shared SQLModel base entity.

Use SQLModel for the model definition and raw SQLAlchemy functions only where database-level defaults are required.

```python
from datetime import datetime

from sqlalchemy import func
from sqlalchemy import DateTime, String
from sqlmodel import Field, SQLModel


class BaseEntity(SQLModel):
    id: str = Field(
        default=None,
        primary_key=True,
        sa_type=String(36),
        sa_column_kwargs={"server_default": func.gen_random_uuid()},
    )
    created_at: datetime = Field(
        default=None,
        sa_type=DateTime(timezone=True),
        sa_column_kwargs={"server_default": func.now()},
    )
    updated_at: datetime = Field(
        default=None,
        sa_type=DateTime(timezone=True),
        sa_column_kwargs={"server_default": func.now(), "onupdate": func.now()},
    )
```

Keep this as a reference, not a mandatory exact copy. If the local project already has a compatible base entity, follow that convention instead.
