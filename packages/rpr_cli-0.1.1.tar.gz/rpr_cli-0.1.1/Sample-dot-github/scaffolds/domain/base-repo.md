Reference example for a shared repository base class.

Prefer SQLModel helpers over raw SQLAlchemy session/query APIs where possible. `AsyncEngine` is the common exception because it comes from SQLAlchemy.

```python
from abc import ABC
from collections.abc import Callable
from typing import Generic, TypeVar

from sqlalchemy.ext.asyncio import AsyncEngine
from sqlmodel import SQLModel, select
from sqlmodel.ext.asyncio.session import AsyncSession

from your_app_domain.utils.mapper_util import mapper

ModelType = TypeVar("ModelType", bound=SQLModel)


class BaseRepository(Generic[ModelType], ABC):
    def __init__(
        self,
        model: type[ModelType],
        engine: AsyncEngine,
        dto_func: Callable,
    ):
        self.model = model
        self.engine = engine
        self.dto_func = dto_func

    @mapper
    async def get_by_id(self, id: str) -> ModelType | None:
        async with AsyncSession(self.engine) as session:
            statement = select(self.model).where(self.model.id == id)
            result = await session.exec(statement)
            return result.first()

    @mapper
    async def create(self, obj_in: ModelType) -> ModelType:
        async with AsyncSession(self.engine) as session:
            obj_data = obj_in.model_dump()
            db_obj = self.model(**obj_data)
            session.add(db_obj)
            await session.commit()
            await session.refresh(db_obj)
            return db_obj
```

Key point: use `AsyncSession` from `sqlmodel.ext.asyncio.session`, not the raw SQLAlchemy session type, unless the project has a specific reason to do otherwise.
