"""
Reference pattern for FastAPI main.py. Follow this when creating or modifying main.py.
Path: .github/scaffolds/api/main.py (after sync)
"""

from contextlib import asynccontextmanager

import asyncio
from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.gzip import GZipMiddleware
from starlette.responses import JSONResponse

# Replace my_app with your app name (e.g. my_app_domain.config)
from my_app_domain.config.container import Container
from my_app_domain.config.logging import get_logger

_container = Container()
logger = get_logger("API")


@asynccontextmanager
async def lifespan(app: FastAPI):
    container = _container
    container.wire(modules=[__name__])

    event_loop = asyncio.get_running_loop()
    # container.start_pubsub(event_loop)  # if using pubsub

    app.state.container = container
    try:
        yield
    finally:
        await container.try_shutdown()  # if container has shutdown logic


async def generic_exception_handler(request, exc: Exception):
    logger.error("Unhandled exception: %s", exc, exc_info=True)
    return JSONResponse(status_code=500, content={"message": "Internal server error"})


async def validation_exception_handler(request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={"message": "Validation error", "details": exc.errors()},
    )


def create_app() -> FastAPI:
    settings = _container.config()
    app = FastAPI(
        title="My App",
        description="My App API",
        version="1.0.0",
        lifespan=lifespan,
        # docs_url=None, redoc_url=None, openapi_url=None  # for internal/worker-only apps
    )

    app.add_exception_handler(Exception, generic_exception_handler)
    app.add_exception_handler(RequestValidationError, validation_exception_handler)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_allowed_origins,
        allow_credentials=True,
        allow_methods=settings.cors_allowed_methods,
        allow_headers=settings.cors_allowed_headers,
    )
    app.add_middleware(GZipMiddleware, minimum_size=1000)

    # Add custom middleware via factory if needed:
    # middleware_class = create_middleware_factory(_container)
    # app.add_middleware(middleware_class)

    from .routes import api_router_a, api_router_b

    app.include_router(api_router_a, prefix="/api/a", tags=["API A"])
    app.include_router(api_router_b, prefix="/api/b", tags=["API B"])

    return app


app = create_app()
