# Code examples / scaffolds

Reference implementations for AI instructions. When syncing rules to a project, these can be copied to `.github/scaffolds/` so instructions like "follow this pattern when creating main.py" point to an actual file.

| Path | Purpose |
|------|---------|
| `api/main.py` | FastAPI app factory, lifespan, middleware, exception handlers |
