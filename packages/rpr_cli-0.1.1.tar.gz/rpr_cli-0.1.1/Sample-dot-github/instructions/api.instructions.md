---
applyTo: "apps/*-api/**"
description: "FastAPI route patterns, dependency injection, and CRUD conventions"
---

# API Conventions

Framework: FastAPI.

When creating or modifying `main.py`, use `.github/scaffolds/api/main.py` as a reference if it exists. Follow the same overall shape: app factory, lifespan wiring, middleware registration, and exception handlers.

## Routes

- Keep route handlers thin: validate input, delegate to workflows or services, and translate the result into the response.
- Prefer one `APIRouter()` per route module.
- Set `response_model` on every public route.
- For typed parameters, prefer `Annotated[...]` with FastAPI helpers such as `Path`, `Query`, and `Body`.
- Request and response DTOs should use the project's JSON-model base so Python field names stay idiomatic while serialized JSON stays consistent.

## Dependency Injection

- Use `@inject` with `Depends(Provide[Container.<service_name>])` for services resolved from the container.
- Do not instantiate repositories or domain services directly in route handlers.
- Wire modules during startup or lifespan setup, not lazily inside request handlers.

## Error Handling

- Use `HTTPException(404)` for missing resources and other explicit `HTTPException` responses for expected client-facing failures.
- Log unexpected failures and convert them to the project's standard server-error response path.
- Do not use bare `except`; catch specific exceptions and keep error translation close to the boundary.

## CRUD

- Check existence before update or delete operations.
- Use the correct HTTP status codes: `201` for create, `200` for successful reads or updates, and `204` for deletes with no body.
- Return DTOs from route handlers, never ORM entities.
- For partial updates, use a DTO with optional fields and apply the changes through `apply_partial_update` rather than hand-written field assignment.

## Boundaries

- Route modules own HTTP concerns. They should not contain business workflows, persistence logic, or cross-service orchestration.
- Keep response shaping close to the route layer and business rules in the domain layer.
