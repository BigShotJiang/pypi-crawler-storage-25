---
applyTo: "pyproject.toml,nx.json,.pre-commit-config.yaml,package.json,apps/*/project.json,packages/**/project.json,apps/*/eslint.config.mjs,packages/**/eslint.config.mjs,packages/python/*-engine/Cargo.toml"
description: "Use when setting up or modifying Ruff, TypeScript linting, ESLint, Prettier, cargo fmt, Clippy, or pre-commit in an RPR workspace"
---

# Tooling Setup

Use this guidance when editing workspace tooling files or bootstrapping linting, formatting, and pre-commit automation.

## First Rule

- Match the existing workspace toolchain before adding anything new.
- Keep docs, Nx targets, package dependencies, and pre-commit hooks consistent with each other.
- Do not document commands that the workspace cannot actually run.

## Python Baseline

- Use Ruff for Python linting and formatting.
- Keep Ruff configuration in the root `pyproject.toml`.
- Prefer `uv run ruff check` for linting and `uv run ruff format` for formatting.
- If the workspace already has a Ruff config, extend it rather than replacing it with a different rule set.
- If bootstrapping from the current RPR defaults, preserve the existing generated baseline unless the task explicitly asks for different rules.

## TypeScript and React Baseline

- In the current RPR generator, the default `lint` target for Node and React projects is `npx eslint .`.
- Keep `typecheck` as a separate target that runs `npx tsc --noEmit`.
- Use ESLint flat config and the Nx plugin entry `@nx/eslint/plugin` in `nx.json`.
- Treat Prettier as the default formatter for Node-side code and keep it complementary to ESLint.

Valid `nx.json` plugin example:

```json
{
  "plugins": [
    {
      "plugin": "@nx/eslint/plugin",
      "options": {
        "targetName": "lint"
      }
    }
  ]
}
```

## Rust Baseline

- Use `cargo fmt --check` for formatting validation.
- Use `cargo clippy --all-targets --all-features -- -D warnings` for linting.
- In RPR-generated engine packages, prefer the existing Nx targets `engine:format` and `engine:lint`.

## Pre-commit Rules

- Keep `.pre-commit-config.yaml` syntactically valid YAML.
- Define one hook per command. Do not reuse a single hook entry for two commands.
- Hook ids, documented manual run commands, and actual entries must match exactly.
- Prefer commands the workspace already uses in `project.json`, `package.json`, or root scripts.
- When bootstrapping a fresh RPR workspace, scaffold `eslint` and `prettier` hooks with the matching config files.

Valid local hook example aligned with the current RPR defaults:

```yaml
repos:
  - repo: local
    hooks:
      - id: ruff-format
        name: Ruff format
        entry: uv run ruff format .
        language: system
        pass_filenames: false

      - id: ruff-lint
        name: Ruff lint
        entry: uv run ruff check . --fix
        language: system
        pass_filenames: false

      - id: prettier
        name: Prettier
        entry: npx prettier --write .
        language: system
        pass_filenames: false

      - id: eslint
        name: ESLint
        entry: npx eslint . --ext .js,.jsx,.ts,.tsx --fix
        language: system
        pass_filenames: false
```

## Consistency Checks

- Use `package.json`, not `packages.json`.
- If linting uses ESLint, keep a separate `typecheck` target for `npx tsc --noEmit`.
- If you introduce a hook named `eslint` or `prettier`, define that hook explicitly.
- If you document ESLint, ensure the package install, config format, Nx integration, and manual commands all match.
- If a long-form guide conflicts with the generated project defaults, update the guide or the generator so they agree.
