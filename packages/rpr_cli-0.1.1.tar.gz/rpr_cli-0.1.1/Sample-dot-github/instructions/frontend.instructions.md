---
applyTo: "packages/node/*-ui/**,apps/*/**"
description: "React components, TanStack Query/Router, MUI patterns"
---

# Frontend (UI Library)

Use React for UI composition, TanStack Query for server-state workflows, TanStack Router for routing, and MUI for the component system.

## Patterns

- Use functional components.
- Extract reusable behavior into hooks instead of duplicating component logic.
- Prefer a shared base API service at `src/services/base/api.service.ts` when the UI package needs centralized fetch behavior.
- Prefer a shared `useStateNavigation` hook at `src/hooks/useStateNavigation.ts` when UI state should persist in the URL.
- Reuse existing components, hooks, and service patterns before introducing a new abstraction.
- Use TanStack Query for server state and request lifecycles.
- Organize API access per domain: service methods in `services/`, query hooks near stateful consumers or in shared hooks when reused broadly.
- On successful mutations, update or invalidate the relevant query cache instead of forcing a full-page reload.

## Reference Scaffolds

- When creating or modifying the shared base API service at `src/services/base/api.service.ts`, use `.github/scaffolds/frontend/api.service.ts` as a reference if it exists.
- When creating or modifying the shared `useStateNavigation` hook at `src/hooks/useStateNavigation.ts`, use `.github/scaffolds/frontend/useStateNavigation.ts` as a reference if it exists.
- These scaffold files are examples, not strict requirements. Prefer existing project-local conventions if the UI package already differs.

Example mutation pattern:

```ts
type User = {
  id: string;
  name: string;
};

export const useChangeName = (id: string, newName: string) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: () => userService.changeName(id, newName),
    onSuccess: () => {
      queryClient.setQueryData<User | undefined>(["user", id], (oldData) => {
        if (!oldData) {
          return oldData;
        }

        return {
          ...oldData,
          name: newName,
        };
      });
    },
  });
};
```

## Routing

- Use TanStack Router for type-safe route definitions.
- Keep route configuration close to the app boundary. The UI library should not own application-only route composition.
- Prefer explicit route trees built from `createRootRoute`, `createRoute`, `addChildren`, and `createRouter`.

## Styling

- If a component needs non-trivial custom styling, place it in a sibling `{Component}.styles.tsx` file.
- Use Emotion through MUI's `styled` API and prefer template-literal or callback-based styled components over scattered inline style objects.

Example:

```ts
export const SomeContainer = styled(Box)`
  display: flex;
`;
```

- Prefer theme-driven colors and tokens so light and dark mode stay consistent.
- Let `Paper` and `Typography` carry default background and text colors unless a component has a specific design reason to override them.
- Create and maintain a shared app theme instead of scattering palette decisions across components.
- Use the `sx` prop sparingly. It is appropriate for one-off local adjustments or truly dynamic runtime values. Shared or repeated styles should move into the theme or a styled wrapper.
- Components should not hard-code their own layout width unless the component's contract requires it. Let parent containers control sizing.
- Prefer flexbox or grid for layout rather than margin-based positioning.
- Extend MUI theme types through a declaration file in the UI package when custom tokens are required.

## Typing

- Type every API payload and mutation input.
- Prefer `type` aliases for DTO-shaped data, `interface` for extendable service contracts, and classes only when the UI genuinely needs behavior.
- For components with children, prefer `React.PropsWithChildren<T>` over manually re-declaring a `children` field.

## Components

- Use functional components.
- Use `useLayoutEffect` only when the effect must run before paint, such as DOM measurement or URL synchronization. Use `useEffect` by default for ordinary side effects.
- Keep components as small and focused as practical.
- Isolate side effects into hooks or boundary components. Query hooks are the normal exception because they are already side-effect boundaries.
- Prefer pure helpers and deterministic render logic where possible to keep testing straightforward.
- Do not memoize by default. Add memoization only when render churn is measurable or the component contract clearly benefits from it.
- Be deliberate about prop shape and state ownership to avoid unnecessary re-renders.
