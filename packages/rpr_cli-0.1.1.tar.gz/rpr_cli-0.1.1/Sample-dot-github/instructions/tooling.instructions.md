---
applyTo: "**"
description: "Workspace tooling conventions for linting, formatting, and pre-commit"
---

# Tooling Conventions

Use the workspace's existing linting, formatting, and pre-commit setup when it already exists. Do not introduce a second parallel toolchain.

## Python

- Use Ruff for Python linting and formatting.
- Keep Ruff configuration in the root `pyproject.toml` under `[tool.ruff]`.
- Prefer workspace commands such as `uv run ruff check` and `uv run ruff format`.
- If the project already pins Ruff in dependencies, keep it there. Do not rely on undocumented cache behavior as the only installation path.

## TypeScript and React

- In RPR-generated workspaces, use ESLint flat config for JavaScript and TypeScript linting, Prettier for formatting, and `npx tsc --noEmit` as a separate typecheck target.
- Keep the root `nx.json` ESLint plugin entry and project-local `eslint.config.mjs` files aligned.
- Extend existing flat-config files instead of introducing a different ESLint config format.
- Keep `lint`, `format`, and `typecheck` responsibilities separate. Do not use TypeScript typechecking as a substitute for ESLint.

## Rust

- Use `cargo fmt --check` for formatting validation.
- Use `cargo clippy --all-targets --all-features -- -D warnings` for linting.
- Prefer existing Nx targets such as `engine:format` and `engine:lint` when they exist.

## Pre-commit

- Pre-commit hooks must call commands that already exist in the workspace.
- Keep hook ids, entries, and manual run examples aligned. Do not document a hook name that is not defined.
- Prefer running workspace-level commands through `uv run`, `npx`, `npx nx`, or existing package-manager scripts rather than ad hoc shell fragments.
- When the default Node tooling is scaffolded, keep `eslint` and `prettier` hooks aligned with the generated config files.
- Ensure YAML examples are syntactically valid before adding them to shared docs or instructions.

## Change Discipline

- Reuse existing root config files such as `pyproject.toml`, `nx.json`, `eslint.config.mjs`, and `.pre-commit-config.yaml` instead of creating duplicates.
- When a task is specifically to bootstrap tooling from scratch, keep the configuration consistent across docs, generated targets, and hook examples.
- Use `tooling-setup.instructions.md` for file-level guidance when editing root tooling config files.
