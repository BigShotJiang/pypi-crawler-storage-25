"""Tests for src/rpr/map/responsibility.py."""

from __future__ import annotations

from pathlib import Path

from rpr.map.classifier import ClassifiedNode
from rpr.map.graph import DependencyGraph
from rpr.map.responsibility import (
    _python_docstring,
    _rust_docstring,
    _ts_docstring,
    build_responsibility_summaries,
)
from rpr.map.topology import build_directory_topology
from rpr.map.walker import SourceFile

_ROOT = Path("/fake/root")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _sf(rel: str, language: str = "python") -> SourceFile:
    p = Path(rel)
    return SourceFile(abs_path=_ROOT / p, rel_path=p, language=language)


def _graph(nodes: list[SourceFile]) -> DependencyGraph:
    return DependencyGraph(
        nodes=nodes,
        edges={},
        reverse_edges={},
        cycles=[],
        backend="python-fallback",
    )


def _classified(sf: SourceFile, layer: str) -> ClassifiedNode:
    return ClassifiedNode(file=sf, layer=layer, is_leaf=True, in_degree=0, out_degree=0)


# ---------------------------------------------------------------------------
# Docstring extractor unit tests
# ---------------------------------------------------------------------------


class TestPythonDocstring:
    def test_simple_module_docstring(self):
        src = '"""This is the module docstring."""\nimport os\n'
        assert _python_docstring(src) == "This is the module docstring."

    def test_multiline_returns_first_line(self):
        src = '"""First line.\n\nSecond paragraph.\n"""\n'
        assert _python_docstring(src) == "First line."

    def test_no_docstring_returns_none(self):
        src = "import os\n"
        assert _python_docstring(src) is None

    def test_syntax_error_returns_none(self):
        src = "def bad syntax(\n"
        assert _python_docstring(src) is None

    def test_only_blank_lines_returns_none(self):
        src = '"""   \n   \n"""\n'
        assert _python_docstring(src) is None


class TestRustDocstring:
    def test_inner_doc_comment(self):
        src = "//! Module for parsing.\nuse std::io;\n"
        assert _rust_docstring(src) == "Module for parsing."

    def test_no_inner_doc_returns_none(self):
        src = "// Regular comment\nuse std::io;\n"
        assert _rust_docstring(src) is None

    def test_leading_space_stripped(self):
        src = "  //! Some detail.\n"
        assert _rust_docstring(src) == "Some detail."


class TestTsDocstring:
    def test_jsdoc_block(self):
        src = "/** Entry point component. */\nexport function App() {}\n"
        assert _ts_docstring(src) == "Entry point component."

    def test_multiline_jsdoc_first_description(self):
        src = "/**\n * Renders the sidebar.\n * @param props - component props\n */\n"
        assert _ts_docstring(src) == "Renders the sidebar."

    def test_no_jsdoc_returns_none(self):
        src = "import React from 'react';\n"
        assert _ts_docstring(src) is None


# ---------------------------------------------------------------------------
# build_responsibility_summaries integration tests
# ---------------------------------------------------------------------------


class TestBuildResponsibilitySummaries:
    def test_vocabulary_match_commands(self):
        sf = _sf("src/rpr/commands/map.py")
        g = _graph([sf])
        topology = build_directory_topology(g, _ROOT)
        classified = [_classified(sf, "entry_point")]

        results = build_responsibility_summaries(topology, classified)

        dir_to_summary = {r.directory: r.summary for r in results}
        assert dir_to_summary.get("src/rpr/commands") == "CLI command handlers"

    def test_vocabulary_match_entities(self):
        sf = _sf("domain/entities/user.py")
        g = _graph([sf])
        topology = build_directory_topology(g, _ROOT)
        classified = [_classified(sf, "entity")]

        results = build_responsibility_summaries(topology, classified)

        dir_to_summary = {r.directory: r.summary for r in results}
        assert dir_to_summary.get("domain/entities") == "Domain entities"

    def test_dominant_layer_fallback(self):
        """When no vocab match, dominant layer is used."""
        sf1 = _sf("custom_dir/a.py")
        sf2 = _sf("custom_dir/b.py")
        g = _graph([sf1, sf2])
        topology = build_directory_topology(g, _ROOT)
        classified = [
            _classified(sf1, "repository"),
            _classified(sf2, "repository"),
        ]

        results = build_responsibility_summaries(topology, classified)
        dir_to_summary = {r.directory: r.summary for r in results}
        assert dir_to_summary.get("custom_dir") == "Data access layer"

    def test_neutral_fallback_with_file_count(self):
        """When no other heuristic matches, returns N source files."""
        sf = _sf("oddball_xyz123/thing.py")
        g = _graph([sf])
        topology = build_directory_topology(g, _ROOT)
        classified = [_classified(sf, "unknown")]

        results = build_responsibility_summaries(topology, classified)
        dir_to_summary = {r.directory: r.summary for r in results}
        summary = dir_to_summary.get("oddball_xyz123", "")
        assert "1 source file" in summary

    def test_neutral_fallback_plural(self):
        """Two source files → '2 source files'."""
        sf1 = _sf("oddball_xyz123/a.py")
        sf2 = _sf("oddball_xyz123/b.py")
        g = _graph([sf1, sf2])
        topology = build_directory_topology(g, _ROOT)
        classified = [_classified(sf1, "unknown"), _classified(sf2, "unknown")]

        results = build_responsibility_summaries(topology, classified)
        dir_to_summary = {r.directory: r.summary for r in results}
        summary = dir_to_summary.get("oddball_xyz123", "")
        assert "2 source files" in summary

    def test_covers_every_topology_directory(self):
        """Every directory in topology should have a summary entry."""
        sf1 = _sf("pkg/a.py")
        sf2 = _sf("pkg/sub/b.py")
        g = _graph([sf1, sf2])
        topology = build_directory_topology(g, _ROOT)
        classified = [_classified(sf1, "unknown"), _classified(sf2, "unknown")]

        results = build_responsibility_summaries(topology, classified)
        result_dirs = {r.directory for r in results}
        assert topology.nodes.keys() == result_dirs

    def test_results_sorted_by_directory(self):
        """Returned list is sorted by directory path."""
        sf_a = _sf("zzz/mod.py")
        sf_b = _sf("aaa/mod.py")
        g = _graph([sf_a, sf_b])
        topology = build_directory_topology(g, _ROOT)
        classified = [_classified(sf_a, "unknown"), _classified(sf_b, "unknown")]

        results = build_responsibility_summaries(topology, classified)
        assert [r.directory for r in results] == sorted(r.directory for r in results)

    def test_docstring_from_root_init(self, tmp_path: Path):
        """When root is provided and __init__.py exists, its docstring is used."""
        init = tmp_path / "mypkg" / "__init__.py"
        init.parent.mkdir(parents=True)
        init.write_text('"""Handles user authentication."""\n', encoding="utf-8")

        sf = SourceFile(
            abs_path=tmp_path / "mypkg" / "__init__.py",
            rel_path=Path("mypkg/__init__.py"),
            language="python",
        )
        g = _graph([sf])
        topology = build_directory_topology(g, tmp_path)
        classified = [_classified(sf, "application")]

        results = build_responsibility_summaries(topology, classified, root=tmp_path)
        dir_to_summary = {r.directory: r.summary for r in results}
        assert dir_to_summary.get("mypkg") == "Handles user authentication."

    def test_vocab_takes_priority_over_layer(self):
        """Vocabulary match is tried before dominant-layer heuristic."""
        sf = _sf("myapp/services/engine.py")
        g = _graph([sf])
        topology = build_directory_topology(g, _ROOT)
        classified = [_classified(sf, "unknown")]  # layer is weak

        results = build_responsibility_summaries(topology, classified)
        dir_to_summary = {r.directory: r.summary for r in results}
        # "services" is in _VOCAB
        assert dir_to_summary.get("myapp/services") == "Application services"
