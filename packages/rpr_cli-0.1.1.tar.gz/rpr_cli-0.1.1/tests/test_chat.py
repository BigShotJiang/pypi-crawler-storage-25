from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from dataclasses import dataclass
from pathlib import Path
from threading import Thread
import time
from typing import override

from typer.testing import CliRunner

import rpr.commands.chat as chat_command
from rpr.agent.approval import ApprovalDecision, ApprovalMode
from rpr.agent.bootstrap import build_chat_runtime_bundle
from rpr.agent.session import ChatSession
from rpr.agent.client import (
    AgentClient,
    ConversationMessage,
    FilePart,
    TextDeltaEvent,
    TextPart,
    ToolCallRequestEvent,
    TurnCompleteEvent,
)
from rpr.agent.control import TurnControl
from rpr.agent.runtime import RuntimeCallbacks
from rpr.agent.tools.base import AgentTool, ToolResult, ToolSpec
from rpr.agent.tools.registry import ToolRegistry
from rpr.cli import app
from rpr.context import RunContext
from rpr.application.prompt_service import PromptService

runner = CliRunner()


class FailingClient(AgentClient):
    @property
    @override
    def provider_name(self) -> str:
        return "fake"

    @property
    @override
    def model_name(self) -> str:
        return "failing-model"

    @override
    async def stream(
        self,
        history: list[ConversationMessage],
        *,
        system_prompt: str | None = None,
        control: TurnControl | None = None,
    ) -> AsyncGenerator[
        TextDeltaEvent | ToolCallRequestEvent | TurnCompleteEvent, None
    ]:
        del history, system_prompt, control
        raise RuntimeError("provider exploded")
        yield TurnCompleteEvent()


class ToolClient(AgentClient):
    def __init__(
        self,
        *,
        tool_name: str,
        arguments: dict[str, object],
        final_prefix: str = "Done.",
    ) -> None:
        self._tool_name = tool_name
        self._arguments = arguments
        self._final_prefix = final_prefix

    @property
    @override
    def provider_name(self) -> str:
        return "fake"

    @property
    @override
    def model_name(self) -> str:
        return "tool-model"

    @override
    async def stream(
        self,
        history: list[ConversationMessage],
        *,
        system_prompt: str | None = None,
        control: TurnControl | None = None,
    ) -> AsyncGenerator[
        TextDeltaEvent | ToolCallRequestEvent | TurnCompleteEvent, None
    ]:
        del system_prompt, control
        last_message = history[-1]
        if last_message.role == "user":
            yield TextDeltaEvent(text="Checking the repository.\n\n")
            yield ToolCallRequestEvent(
                call_id="call-1",
                tool_name=self._tool_name,
                arguments=self._arguments,
            )
            return

        yield TextDeltaEvent(text=f"{self._final_prefix}\n\n{last_message.content}")
        yield TurnCompleteEvent()


class SlowStreamingClient(AgentClient):
    response_text = "This response should stop before it finishes."

    @property
    @override
    def provider_name(self) -> str:
        return "fake"

    @property
    @override
    def model_name(self) -> str:
        return "slow-model"

    @override
    async def stream(
        self,
        history: list[ConversationMessage],
        *,
        system_prompt: str | None = None,
        control: TurnControl | None = None,
    ) -> AsyncGenerator[
        TextDeltaEvent | ToolCallRequestEvent | TurnCompleteEvent, None
    ]:
        del history, system_prompt
        for char in self.response_text:
            if control is not None and control.is_cancelled:
                return
            await asyncio.sleep(0.01)
            yield TextDeltaEvent(text=char)
        yield TurnCompleteEvent()


class EchoLastMessageClient(AgentClient):
    @property
    @override
    def provider_name(self) -> str:
        return "fake"

    @property
    @override
    def model_name(self) -> str:
        return "echo-model"

    @override
    async def stream(
        self,
        history: list[ConversationMessage],
        *,
        system_prompt: str | None = None,
        control: TurnControl | None = None,
    ) -> AsyncGenerator[
        TextDeltaEvent | ToolCallRequestEvent | TurnCompleteEvent, None
    ]:
        del system_prompt, control
        last_message = history[-1]
        yield TextDeltaEvent(
            text=last_message.text_content.encode("unicode_escape").decode()
        )
        yield TurnCompleteEvent()


class CaptureMessageClient(AgentClient):
    def __init__(self) -> None:
        self.last_message: ConversationMessage | None = None

    @property
    @override
    def provider_name(self) -> str:
        return "fake"

    @property
    @override
    def model_name(self) -> str:
        return "capture-model"

    @override
    async def stream(
        self,
        history: list[ConversationMessage],
        *,
        system_prompt: str | None = None,
        control: TurnControl | None = None,
    ) -> AsyncGenerator[
        TextDeltaEvent | ToolCallRequestEvent | TurnCompleteEvent, None
    ]:
        del system_prompt, control
        self.last_message = history[-1]
        yield TurnCompleteEvent()


class ToolRequestClient(AgentClient):
    @property
    @override
    def provider_name(self) -> str:
        return "fake"

    @property
    @override
    def model_name(self) -> str:
        return "tool-request-model"

    @override
    async def stream(
        self,
        history: list[ConversationMessage],
        *,
        system_prompt: str | None = None,
        control: TurnControl | None = None,
    ) -> AsyncGenerator[
        TextDeltaEvent | ToolCallRequestEvent | TurnCompleteEvent, None
    ]:
        del history, system_prompt, control
        yield ToolCallRequestEvent(
            call_id="call-1",
            tool_name="cancellable_tool",
            arguments={},
        )


class CancellableTool(AgentTool):
    def __init__(self) -> None:
        self.observed_cancellation = False

    @property
    def spec(self) -> ToolSpec:
        return ToolSpec(
            name="cancellable_tool",
            description="Long-running tool for cancellation tests.",
        )

    def execute(
        self,
        arguments: dict[str, object],
        ctx: RunContext,
        *,
        control: TurnControl | None = None,
    ) -> ToolResult:
        del arguments, ctx
        while True:
            if control is not None and control.is_cancelled:
                self.observed_cancellation = True
                return ToolResult(
                    tool_name=self.spec.name,
                    success=False,
                    output="Tool execution cancelled.",
                    cancelled=True,
                )
            time.sleep(0.01)


def _set_project_dir(monkeypatch, project_dir: Path) -> None:
    monkeypatch.setattr(
        chat_command, "RunContext", lambda: RunContext(project_dir=project_dir)
    )


def _reset_prompt_service() -> None:
    PromptService.instance().reset()


def test_chat_repl_startup_and_quit():
    _reset_prompt_service()
    result = runner.invoke(app, ["chat", "--model", "mock-latest"], input="/exit\n")

    assert result.exit_code == 0
    assert "RPR Chat Session" in result.stdout
    assert "Project Root:" in result.stdout
    assert "Provider:" in result.stdout
    assert "mock" in result.stdout
    assert "Model:" in result.stdout
    assert "mock-latest" in result.stdout
    assert "Approval Mode:" in result.stdout
    assert "ask" in result.stdout
    assert "slash commands" in result.stdout
    assert "Goodbye!" in result.stdout


def test_chat_gracefully_handles_eof_exit():
    _reset_prompt_service()
    result = runner.invoke(app, ["chat"], input="")

    assert result.exit_code == 0
    assert "Session ended." in result.stdout
    assert "Goodbye!" in result.stdout


def test_chat_provider_error_keeps_session_alive(monkeypatch):
    _reset_prompt_service()
    monkeypatch.setattr(
        chat_command, "_get_agent_client", lambda provider, model: FailingClient()
    )

    result = runner.invoke(app, ["chat"], input="hello\n/exit\n")

    assert result.exit_code == 0
    assert "Error: provider exploded" in result.stdout
    assert "Goodbye!" in result.stdout


def test_chat_executes_read_only_tool(monkeypatch, tmp_path):
    _reset_prompt_service()
    target = tmp_path / "notes.txt"
    target.write_text("alpha\nbeta\n")
    _set_project_dir(monkeypatch, tmp_path)
    monkeypatch.setattr(
        chat_command,
        "_get_agent_client",
        lambda provider, model: ToolClient(
            tool_name="read_file", arguments={"path": "notes.txt"}
        ),
    )

    result = runner.invoke(app, ["chat"], input="inspect\n/exit\n")

    assert result.exit_code == 0
    assert "Tool Call: read_file" in result.stdout
    assert "1: alpha" in result.stdout
    assert "2: beta" in result.stdout
    assert "Approval required" not in result.stdout


def test_chat_rejects_mutating_tool_without_writing(monkeypatch, tmp_path):
    _reset_prompt_service()
    _set_project_dir(monkeypatch, tmp_path)
    monkeypatch.setattr(
        chat_command,
        "_get_agent_client",
        lambda provider, model: ToolClient(
            tool_name="write_file",
            arguments={"path": "notes.txt", "content": "hello from tool\n"},
        ),
    )

    result = runner.invoke(app, ["chat"], input="change it\nr\n/exit\n")

    assert result.exit_code == 0
    assert "Approval required" in result.stdout
    assert "Tool execution was rejected by the user." in result.stdout
    assert not (tmp_path / "notes.txt").exists()


def test_chat_approves_mutating_tool_and_writes_file(monkeypatch, tmp_path):
    _reset_prompt_service()
    _set_project_dir(monkeypatch, tmp_path)
    monkeypatch.setattr(
        chat_command,
        "_get_agent_client",
        lambda provider, model: ToolClient(
            tool_name="write_file",
            arguments={"path": "notes.txt", "content": "hello from tool\n"},
        ),
    )

    result = runner.invoke(app, ["chat"], input="change it\na\n/exit\n")

    assert result.exit_code == 0
    assert "Approval required" in result.stdout
    assert "Tool Result: write_file (success)" in result.stdout
    assert (tmp_path / "notes.txt").read_text() == "hello from tool\n"


def test_chat_auto_all_skips_mutation_prompt(monkeypatch, tmp_path):
    _reset_prompt_service()
    _set_project_dir(monkeypatch, tmp_path)
    monkeypatch.setattr(
        chat_command,
        "_get_agent_client",
        lambda provider, model: ToolClient(
            tool_name="write_file",
            arguments={"path": "notes.txt", "content": "hello from tool\n"},
        ),
    )

    result = runner.invoke(
        app, ["chat", "--approval-mode", "auto-all"], input="change it\n/exit\n"
    )

    assert result.exit_code == 0
    assert "Approval required" not in result.stdout
    assert (tmp_path / "notes.txt").read_text() == "hello from tool\n"


def test_chat_help():
    _reset_prompt_service()
    result = runner.invoke(app, ["chat", "--help"])
    assert result.exit_code == 0
    assert "Start an interactive chat session" in result.stdout
    assert "approval-mode" in result.stdout
    assert "--tui" not in result.stdout


def test_chat_slash_help_lists_supported_commands():
    _reset_prompt_service()
    result = runner.invoke(app, ["chat"], input="/help\n/exit\n")

    assert result.exit_code == 0
    assert "Slash Commands" in result.stdout
    assert "/settings" in result.stdout
    assert "/check" in result.stdout
    assert "/generate" in result.stdout


def test_chat_settings_flow_updates_persisted_config(monkeypatch, tmp_path):
    _reset_prompt_service()
    config_path = tmp_path / "settings.json"
    monkeypatch.setattr(chat_command.settings_manager, "_config_path", config_path)
    monkeypatch.setattr(
        chat_command.settings_manager, "_current_theme_name", "standard"
    )
    monkeypatch.setattr(chat_command.settings_manager, "_approval_mode_name", "ask")
    monkeypatch.setattr(chat_command.settings_manager, "_startup_help", True)

    result = runner.invoke(app, ["chat"], input="/settings\ntheme\nocean\ny\n/exit\n")

    assert result.exit_code == 0
    assert "RPR Settings" in result.stdout
    assert "Persist theme = ocean?" in result.stdout
    assert '"theme": "ocean"' in config_path.read_text()


@dataclass(slots=True)
class _FakeCheckResult:
    group: str
    area: str
    path: str
    status: bool
    suggestion: str | None = None


@dataclass(slots=True)
class _FakeCheckReport:
    project_name: str
    results: list[_FakeCheckResult]


def test_check_service_path_is_shared_between_cli_and_chat(monkeypatch, tmp_path):
    _reset_prompt_service()
    calls: list[tuple[str, str | None]] = []

    def fake_collect(project_dir: Path, group: str | None = None) -> _FakeCheckReport:
        calls.append((str(project_dir), group))
        return _FakeCheckReport(
            project_name="demo-app",
            results=[
                _FakeCheckResult(
                    group="Workspace", area="nx_json", path="nx.json", status=True
                )
            ],
        )

    monkeypatch.setattr("rpr.commands.check.collect_check_report", fake_collect)
    monkeypatch.setattr("rpr.application.shell.collect_check_report", fake_collect)
    _set_project_dir(monkeypatch, tmp_path)

    cli_result = runner.invoke(app, ["check"])
    chat_result = runner.invoke(app, ["chat"], input="/check\n/exit\n")

    assert cli_result.exit_code == 0
    assert chat_result.exit_code == 0
    assert "demo-app" in cli_result.output
    assert "demo-app" in chat_result.output
    assert len(calls) == 2


def test_runtime_turn_control_cancels_stream(tmp_path):
    chunks: list[str] = []
    bundle = build_chat_runtime_bundle(
        ctx=RunContext(project_dir=tmp_path),
        client=SlowStreamingClient(),
        approval_mode=ApprovalMode.ASK,
        callbacks=RuntimeCallbacks(
            on_text_delta=chunks.append,
            on_tool_call=lambda record: None,
            on_tool_result=lambda record, result: None,
            request_approval=lambda record: ApprovalDecision.REJECT,
            on_attachment_notice=lambda message: None,
        ),
    )
    control = TurnControl()
    thread = Thread(
        target=lambda: asyncio.run(
            bundle.runtime.execute_turn("cancel me", control=control)
        )
    )

    thread.start()
    time.sleep(0.05)
    control.cancel()
    thread.join(timeout=2)

    assert not thread.is_alive()
    emitted = "".join(chunks)
    assert emitted
    assert len(emitted) < len(SlowStreamingClient.response_text)


def test_runtime_turn_control_cancels_tool_execution(tmp_path):
    tool = CancellableTool()
    registry = ToolRegistry()
    registry.register(tool)
    tool_results: list[ToolResult] = []
    runtime = build_chat_runtime_bundle(
        ctx=RunContext(project_dir=tmp_path),
        client=ToolRequestClient(),
        approval_mode=ApprovalMode.AUTO_ALL,
        callbacks=RuntimeCallbacks(
            on_text_delta=lambda chunk: None,
            on_tool_call=lambda record: None,
            on_tool_result=lambda record, result: tool_results.append(result),
            request_approval=lambda record: ApprovalDecision.APPROVE,
            on_attachment_notice=lambda message: None,
        ),
    ).runtime
    runtime._tools = registry

    control = TurnControl()
    thread = Thread(
        target=lambda: asyncio.run(runtime.execute_turn("run tool", control=control))
    )

    thread.start()
    time.sleep(0.05)
    control.cancel()
    thread.join(timeout=2)

    assert not thread.is_alive()
    assert tool.observed_cancellation is True
    assert tool_results
    assert tool_results[-1].cancelled is True
    assert tool_results[-1].output == "Tool execution cancelled."


def test_rpr_default_no_subcommand_launches_chat():
    _reset_prompt_service()
    result = runner.invoke(app, [], input="/exit\n")
    assert result.exit_code == 0
    assert "RPR Chat Session" in result.stdout
    assert "Goodbye!" in result.stdout


def test_mock_streaming_yields_delayed_chunks():
    """Mock client emits chunks with ~100ms delays, not an immediate burst."""
    import time

    async def collect_with_timing() -> list[float]:
        from rpr.agent.client import ConversationMessage, TextDeltaEvent
        from rpr.agent.mock import MockAgentClient

        client = MockAgentClient()
        history = [ConversationMessage(role="user", content="hello")]
        timestamps: list[float] = []
        async for event in client.stream(history):
            if isinstance(event, TextDeltaEvent):
                timestamps.append(time.monotonic())
        return timestamps

    timestamps = asyncio.run(collect_with_timing())
    assert len(timestamps) >= 2
    gaps = [timestamps[i + 1] - timestamps[i] for i in range(len(timestamps) - 1)]
    assert all(gap >= 0.05 for gap in gaps), f"expected >=50ms gaps, got {gaps}"


def test_runtime_builds_structured_file_attachments(tmp_path):
    target = tmp_path / "notes.txt"
    target.write_text("alpha\nbeta\n")
    client = CaptureMessageClient()
    notices: list[str] = []
    bundle = build_chat_runtime_bundle(
        ctx=RunContext(project_dir=tmp_path),
        client=client,
        approval_mode=ApprovalMode.ASK,
        callbacks=RuntimeCallbacks(
            on_text_delta=lambda chunk: None,
            on_tool_call=lambda record: None,
            on_tool_result=lambda record, result: None,
            request_approval=lambda record: ApprovalDecision.REJECT,
            on_attachment_notice=notices.append,
        ),
    )

    asyncio.run(bundle.runtime.execute_turn("Explain @notes.txt"))

    assert client.last_message is not None
    assert isinstance(client.last_message.content, tuple)
    assert client.last_message.parts[0] == TextPart("Explain @notes.txt")
    assert client.last_message.file_parts == (
        FilePart(path="notes.txt", mime_type="text/plain", data=b"alpha\nbeta\n"),
    )
    assert notices == ["Attached @notes.txt (11 bytes attached)."]


def test_runtime_does_not_persist_attached_bytes_in_session(tmp_path):
    target = tmp_path / "notes.txt"
    target.write_text("alpha\nbeta\n")
    client = CaptureMessageClient()
    bundle = build_chat_runtime_bundle(
        ctx=RunContext(project_dir=tmp_path),
        client=client,
        approval_mode=ApprovalMode.ASK,
        callbacks=RuntimeCallbacks(
            on_text_delta=lambda chunk: None,
            on_tool_call=lambda record: None,
            on_tool_result=lambda record, result: None,
            request_approval=lambda record: ApprovalDecision.REJECT,
            on_attachment_notice=lambda message: None,
        ),
    )

    asyncio.run(bundle.runtime.execute_turn("Explain @notes.txt"))

    assert bundle.session.messages[-1].content == "Explain @notes.txt"
    assert client.last_message is not None
    assert isinstance(client.last_message.content, tuple)


def test_chat_attaches_file_references_and_reports_them(monkeypatch, tmp_path):
    _reset_prompt_service()
    target = tmp_path / "notes.txt"
    target.write_text("alpha\nbeta\n")
    _set_project_dir(monkeypatch, tmp_path)

    result = runner.invoke(app, ["chat"], input="Explain @notes.txt\n/exit\n")

    assert result.exit_code == 0
    assert "Attached @notes.txt (11 bytes attached)." in result.stdout
    assert "Attachments:" in result.stdout
    assert "notes.txt (text/plain, 11 bytes): alpha" in result.stdout


def test_chat_async_turn_via_mock():
    """A normal user message runs through async input and async streaming end-to-end."""
    _reset_prompt_service()
    result = runner.invoke(app, ["chat"], input="hello\n/exit\n")
    assert result.exit_code == 0
    assert "Mock Provider" in result.stdout or "mock" in result.stdout.lower()
    assert "Goodbye!" in result.stdout


def test_chat_delivers_multiline_message_as_single_turn(monkeypatch):
    _reset_prompt_service()
    monkeypatch.setattr(
        chat_command,
        "_get_agent_client",
        lambda provider, model: EchoLastMessageClient(),
    )

    responses = iter(["first line\nsecond line", "/exit"])

    async def fake_read_input(
        self, message: str = "> ", *, multiline: bool = False, modal: bool = False
    ) -> str:
        del self, message, multiline, modal
        return next(responses)

    monkeypatch.setattr(PromptService, "read_input", fake_read_input)

    result = runner.invoke(app, ["chat"])

    assert result.exit_code == 0
    assert r"first line\nsecond line" in result.stdout


def test_prompt_service_tracks_conversations(tmp_path):
    prompt_service = PromptService.instance()
    prompt_service.reset()

    session = prompt_service.create_conversation(
        project_dir=tmp_path, approval_mode=ApprovalMode.ASK
    )
    session.add_user_message("hello from history")
    prompt_service.save_conversation(session)

    summaries = prompt_service.list_conversations()
    loaded = prompt_service.load_conversation(session.session_id)

    assert len(summaries) == 1
    assert summaries[0].session_id == session.session_id
    assert summaries[0].title == "hello from history"
    assert summaries[0].created_at == session.created_at
    assert loaded is session


def test_prompt_service_returns_same_singleton():
    a = PromptService.instance()
    b = PromptService.instance()
    assert a is b


def test_conversation_summary_includes_timestamps(tmp_path):
    service = PromptService.instance()
    service.reset()
    session = service.create_conversation(
        project_dir=tmp_path, approval_mode=ApprovalMode.ASK
    )
    service.save_conversation(session)
    summaries = service.list_conversations()
    assert len(summaries) == 1
    assert summaries[0].created_at == session.created_at
    assert summaries[0].updated_at == session.updated_at


def test_in_memory_repository_can_save_find_and_list(tmp_path):
    from rpr.application.prompt_service import InMemoryConversationRepository

    repo = InMemoryConversationRepository()
    session = ChatSession(project_dir=tmp_path, approval_mode=ApprovalMode.ASK)
    assert repo.find(session.session_id) is None
    assert repo.all() == []
    repo.save(session)
    assert repo.find(session.session_id) is session
    assert len(repo.all()) == 1
