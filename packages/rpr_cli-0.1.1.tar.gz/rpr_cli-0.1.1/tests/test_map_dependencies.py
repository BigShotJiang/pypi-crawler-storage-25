"""Tests for src/rpr/map/dependencies.py."""

from __future__ import annotations

from pathlib import Path

from rpr.map.dependencies import (
    _normalise_cpp,
    _normalise_python,
    _normalise_rust,
    _normalise_ts_js,
    build_external_dependencies,
)
from rpr.map.graph import DependencyGraph
from rpr.map.topology import build_directory_topology
from rpr.map.walker import SourceFile

_ROOT = Path("/fake/root")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _sf(rel: str, language: str = "python") -> SourceFile:
    p = Path(rel)
    return SourceFile(abs_path=_ROOT / p, rel_path=p, language=language)


def _graph(
    nodes: list[SourceFile],
    edges: dict[str, list[str]] | None = None,
) -> DependencyGraph:
    edges = edges or {}
    rev: dict[str, list[str]] = {}
    for src, deps in edges.items():
        for dep in deps:
            rev.setdefault(dep, []).append(src)
    return DependencyGraph(
        nodes=nodes,
        edges=edges,
        reverse_edges=rev,
        cycles=[],
        backend="python-fallback",
    )


# ---------------------------------------------------------------------------
# Normaliser unit tests
# ---------------------------------------------------------------------------


class TestNormalisePython:
    def test_absolute_import_returns_first_segment(self):
        assert _normalise_python("os.path") == "os"

    def test_absolute_single_segment(self):
        assert _normalise_python("fastapi") == "fastapi"

    def test_relative_import_discarded(self):
        assert _normalise_python(".utils") is None

    def test_double_relative_import_discarded(self):
        assert _normalise_python("..context") is None

    def test_empty_string_discarded(self):
        assert _normalise_python("") is None


class TestNormaliseTsJs:
    def test_bare_package(self):
        assert _normalise_ts_js("react") == "react"

    def test_bare_package_with_subpath(self):
        assert _normalise_ts_js("react/jsx-runtime") == "react"

    def test_scoped_package(self):
        assert _normalise_ts_js("@tanstack/react-query") == "@tanstack/react-query"

    def test_scoped_package_with_subpath(self):
        assert _normalise_ts_js("@mui/material/Button") == "@mui/material"

    def test_relative_import_discarded(self):
        assert _normalise_ts_js("./utils") is None

    def test_absolute_path_discarded(self):
        assert _normalise_ts_js("/some/abs/path") is None


class TestNormaliseRust:
    def test_third_party_crate(self):
        assert _normalise_rust("serde::Deserialize") == "serde"

    def test_stdlib_std_discarded(self):
        assert _normalise_rust("std::collections::HashMap") is None

    def test_crate_discarded(self):
        assert _normalise_rust("crate::models") is None

    def test_self_discarded(self):
        assert _normalise_rust("self::utils") is None

    def test_super_discarded(self):
        assert _normalise_rust("super::parent") is None

    def test_leading_colons_stripped(self):
        assert _normalise_rust("::serde") == "serde"


class TestNormaliseCpp:
    def test_angle_bracket_include_returns_segment(self):
        assert _normalise_cpp("<vector>") == "vector"

    def test_angle_bracket_include_with_subpath(self):
        assert _normalise_cpp("<boost/filesystem.hpp>") == "boost"

    def test_quoted_include_discarded(self):
        assert _normalise_cpp('"local_header.h"') is None

    def test_empty_angle_bracket_discarded(self):
        assert _normalise_cpp("<>") is None


# ---------------------------------------------------------------------------
# build_external_dependencies integration tests
# ---------------------------------------------------------------------------


class TestBuildExternalDependencies:
    def test_in_repo_edge_excluded(self):
        """An import that resolves to an in-repo edge must NOT appear in the summary."""
        a = _sf("rpr/map/walker.py")
        b = _sf("rpr/map/graph.py")
        g = _graph([a, b], edges={"rpr/map/walker.py": ["rpr/map/graph.py"]})
        topology = build_directory_topology(g, _ROOT)

        # walker.py imports "rpr.map.graph" — but that resolves in-repo.
        raw = {"rpr/map/walker.py": ["rpr.map.graph"]}
        result = build_external_dependencies(g, raw, topology)
        # "rpr" maps to in-repo target "rpr/map/graph.py" → should be excluded
        for summary in result:
            assert "rpr" not in summary.packages

    def test_external_import_included(self):
        """A raw import with no in-repo edge resolution appears in the summary."""
        a = _sf("src/app.py")
        g = _graph([a])
        topology = build_directory_topology(g, _ROOT)

        raw = {"src/app.py": ["fastapi", "uvicorn"]}
        result = build_external_dependencies(g, raw, topology)
        assert len(result) == 1
        assert result[0].directory == "src"
        assert "fastapi" in result[0].packages
        assert "uvicorn" in result[0].packages

    def test_relative_python_imports_excluded(self):
        """Relative Python imports (starting with '.') are always discarded."""
        a = _sf("pkg/utils.py")
        g = _graph([a])
        topology = build_directory_topology(g, _ROOT)

        raw = {"pkg/utils.py": [".models", "..base", "requests"]}
        result = build_external_dependencies(g, raw, topology)
        assert len(result) == 1
        pkgs = result[0].packages
        assert "requests" in pkgs
        assert ".models" not in pkgs
        assert "..base" not in pkgs

    def test_packages_deduplicated(self):
        """The same external package from multiple files in one dir is listed once."""
        a = _sf("api/routes.py")
        b = _sf("api/models.py")
        g = _graph([a, b])
        topology = build_directory_topology(g, _ROOT)

        raw = {
            "api/routes.py": ["fastapi"],
            "api/models.py": ["fastapi", "pydantic"],
        }
        result = build_external_dependencies(g, raw, topology)
        assert len(result) == 1
        assert result[0].packages.count("fastapi") == 1

    def test_grouped_by_directory(self):
        """Files in different directories produce separate summaries."""
        a = _sf("api/main.py")
        b = _sf("worker/task.py")
        g = _graph([a, b])
        topology = build_directory_topology(g, _ROOT)

        raw = {
            "api/main.py": ["flask"],
            "worker/task.py": ["celery"],
        }
        result = build_external_dependencies(g, raw, topology)
        assert len(result) == 2
        dirs = {r.directory for r in result}
        assert "api" in dirs
        assert "worker" in dirs

    def test_empty_raw_imports_produces_no_result(self):
        """When raw_imports is empty, no summaries are produced."""
        a = _sf("pkg/mod.py")
        g = _graph([a])
        topology = build_directory_topology(g, _ROOT)

        result = build_external_dependencies(g, {}, topology)
        assert result == []

    def test_rust_stdlib_crates_excluded(self):
        """Rust std / core / alloc are excluded from external packages."""
        a = _sf("src/main.rs", language="rust")
        g = _graph([a])
        topology = build_directory_topology(g, _ROOT)

        raw = {"src/main.rs": ["std::io", "tokio::runtime"]}
        result = build_external_dependencies(g, raw, topology)
        pkgs = result[0].packages if result else ()
        assert "std" not in pkgs
        assert "tokio" in pkgs

    def test_ts_relative_imports_excluded(self):
        """TypeScript relative imports are excluded from summaries."""
        a = _sf("src/index.ts", language="typescript")
        g = _graph([a])
        topology = build_directory_topology(g, _ROOT)

        raw = {"src/index.ts": ["./utils", "@tanstack/react-query"]}
        result = build_external_dependencies(g, raw, topology)
        assert len(result) == 1
        pkgs = result[0].packages
        assert "@tanstack/react-query" in pkgs
        assert "./utils" not in pkgs

    def test_sorting(self):
        """Results are sorted by directory path; packages within each dir are sorted."""
        b = _sf("zoo/model.py")
        a = _sf("alpha/service.py")
        g = _graph([a, b])
        topology = build_directory_topology(g, _ROOT)

        raw = {
            "zoo/model.py": ["zlib", "aiohttp"],
            "alpha/service.py": ["boto3"],
        }
        result = build_external_dependencies(g, raw, topology)
        assert result[0].directory == "alpha"
        assert result[1].directory == "zoo"
        assert list(result[1].packages) == sorted(result[1].packages)

    def test_no_summaries_when_all_in_repo(self):
        """When every import resolves in-repo, the result is an empty list."""
        a = _sf("pkg/a.py")
        b = _sf("pkg/b.py")
        g = _graph([a, b], edges={"pkg/a.py": ["pkg/b.py"]})
        topology = build_directory_topology(g, _ROOT)

        # "pkg" is the first segment of the in-repo path "pkg/b.py"
        raw = {"pkg/a.py": ["pkg.b"]}
        result = build_external_dependencies(g, raw, topology)
        # "pkg" matches in-repo → empty
        for summary in result:
            assert "pkg" not in summary.packages
