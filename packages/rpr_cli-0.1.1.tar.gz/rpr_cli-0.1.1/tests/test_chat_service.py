from __future__ import annotations

import asyncio
from collections import deque
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from rpr.agent.control import TurnControl


def test_turn_control_cancel_stops_is_cancelled():
    control = TurnControl()
    assert not control.is_cancelled

    control.cancel()

    assert control.is_cancelled


def test_turn_control_cancel_is_idempotent():
    control = TurnControl()
    control.cancel()
    control.cancel()

    assert control.is_cancelled


def test_message_queue_fifo_ordering():
    queue: deque[str] = deque()
    queue.append("first")
    queue.append("second")
    queue.append("third")

    assert queue.popleft() == "first"
    assert queue.popleft() == "second"
    assert queue.popleft() == "third"


def test_dispatch_agent_turn_creates_task_and_sets_active():
    async def run() -> None:
        active_task: asyncio.Task | None = None
        dispatched: list[str] = []

        prompt_service = MagicMock()
        prompt_service.set_active_task = MagicMock()
        prompt_service.set_active_control = MagicMock()
        prompt_service.set_queue_info = MagicMock()
        prompt_service.save_conversation = MagicMock()

        async def fake_handle_input(
            message: str, *, control: TurnControl | None = None
        ) -> bool:
            dispatched.append(message)
            return True

        shell_service = MagicMock()
        shell_service.handle_input = fake_handle_input

        presenter = MagicMock()
        presenter.flush = MagicMock()

        def render_chat_hint(_: str) -> None:
            pass

        def render_error(_: str) -> None:
            pass

        message_queue: deque[str] = deque()

        def _update_queue_display() -> None:
            preview = message_queue[0] if message_queue else None
            prompt_service.set_queue_info(len(message_queue), preview)

        def _dispatch_agent_turn(message: str) -> None:
            nonlocal active_task
            control = TurnControl()
            prompt_service.set_active_control(control)

            async def _run_turn() -> None:
                try:
                    await shell_service.handle_input(message, control=control)
                    presenter.flush()
                    prompt_service.save_conversation(None)
                except asyncio.CancelledError:
                    presenter.flush()
                    render_chat_hint("Response cancelled.")
                    raise
                except Exception as exc:
                    presenter.flush()
                    render_error(f"Error: {exc}")

            task = asyncio.create_task(_run_turn())
            active_task = task
            prompt_service.set_active_task(task)

            def _on_done(fut: asyncio.Task) -> None:
                nonlocal active_task
                active_task = None
                prompt_service.set_active_task(None)
                prompt_service.set_active_control(None)
                if message_queue:
                    next_msg = message_queue.popleft()
                    _update_queue_display()
                    _dispatch_agent_turn(next_msg)
                else:
                    _update_queue_display()

            task.add_done_callback(_on_done)

        _dispatch_agent_turn("hello")

        assert active_task is not None
        assert not active_task.done()

        await active_task

        assert "hello" in dispatched
        assert active_task is None

    asyncio.run(run())


def test_second_message_queued_while_first_task_runs():
    async def run() -> None:
        active_task: asyncio.Task | None = None
        dispatched: list[str] = []
        barrier = asyncio.Event()

        prompt_service = MagicMock()
        prompt_service.set_active_task = MagicMock()
        prompt_service.set_active_control = MagicMock()
        prompt_service.set_queue_info = MagicMock()
        prompt_service.save_conversation = MagicMock()

        async def fake_handle_input(
            message: str, *, control: TurnControl | None = None
        ) -> bool:
            dispatched.append(message)
            if message == "first":
                await barrier.wait()
            return True

        shell_service = MagicMock()
        shell_service.handle_input = fake_handle_input

        presenter = MagicMock()
        presenter.flush = MagicMock()

        message_queue: deque[str] = deque()

        def _update_queue_display() -> None:
            preview = message_queue[0] if message_queue else None
            prompt_service.set_queue_info(len(message_queue), preview)

        def _dispatch_agent_turn(message: str) -> None:
            nonlocal active_task
            control = TurnControl()
            prompt_service.set_active_control(control)

            async def _run_turn() -> None:
                try:
                    await shell_service.handle_input(message, control=control)
                    presenter.flush()
                    prompt_service.save_conversation(None)
                except asyncio.CancelledError:
                    presenter.flush()
                    raise
                except Exception as exc:
                    presenter.flush()

            task = asyncio.create_task(_run_turn())
            active_task = task
            prompt_service.set_active_task(task)

            def _on_done(fut: asyncio.Task) -> None:
                nonlocal active_task
                active_task = None
                prompt_service.set_active_task(None)
                prompt_service.set_active_control(None)
                if message_queue:
                    next_msg = message_queue.popleft()
                    _update_queue_display()
                    _dispatch_agent_turn(next_msg)
                else:
                    _update_queue_display()

            task.add_done_callback(_on_done)

        _dispatch_agent_turn("first")

        assert active_task is not None and not active_task.done()
        message_queue.append("second")
        _update_queue_display()

        prompt_service.set_queue_info.assert_called_with(1, "second")

        barrier.set()
        await asyncio.sleep(0.05)

        assert dispatched == ["first", "second"]
        assert active_task is None

    asyncio.run(run())


def test_cancellation_triggers_queue_dequeue():
    async def run() -> None:
        active_task: asyncio.Task | None = None
        dispatched: list[str] = []

        prompt_service = MagicMock()
        prompt_service.set_active_task = MagicMock()
        prompt_service.set_active_control = MagicMock()
        prompt_service.set_queue_info = MagicMock()
        prompt_service.save_conversation = MagicMock()

        async def fake_handle_input(
            message: str, *, control: TurnControl | None = None
        ) -> bool:
            if message == "first":
                await asyncio.sleep(10)
            dispatched.append(message)
            return True

        shell_service = MagicMock()
        shell_service.handle_input = fake_handle_input

        presenter = MagicMock()
        presenter.flush = MagicMock()

        message_queue: deque[str] = deque()

        def _update_queue_display() -> None:
            preview = message_queue[0] if message_queue else None
            prompt_service.set_queue_info(len(message_queue), preview)

        def _dispatch_agent_turn(message: str) -> None:
            nonlocal active_task
            control = TurnControl()

            async def _run_turn() -> None:
                try:
                    await shell_service.handle_input(message, control=control)
                    presenter.flush()
                    prompt_service.save_conversation(None)
                except asyncio.CancelledError:
                    presenter.flush()
                    raise
                except Exception:
                    presenter.flush()

            task = asyncio.create_task(_run_turn())
            active_task = task
            prompt_service.set_active_task(task)

            def _on_done(fut: asyncio.Task) -> None:
                nonlocal active_task
                active_task = None
                prompt_service.set_active_task(None)
                prompt_service.set_active_control(None)
                if message_queue:
                    next_msg = message_queue.popleft()
                    _update_queue_display()
                    _dispatch_agent_turn(next_msg)
                else:
                    _update_queue_display()

            task.add_done_callback(_on_done)

        _dispatch_agent_turn("first")
        message_queue.append("second")

        assert active_task is not None
        active_task.cancel()

        await asyncio.sleep(0.05)

        assert "second" in dispatched
        assert active_task is None

    asyncio.run(run())
