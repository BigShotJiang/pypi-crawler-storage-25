from __future__ import annotations

import io
from collections.abc import Callable
from importlib import import_module
from pathlib import Path

import pytest
from rich.console import Console

from rpr.ui.markdown import render_markdown
from rpr.ui.renderers import (
    render_command_start,
    render_error,
    render_file_preview,
    render_session_header,
    render_success,
)
from rpr.ui.theme import theme_manager


@pytest.fixture
def recording_console() -> Console:
    return Console(width=80, force_terminal=True, color_system="truecolor", record=True)


@pytest.fixture
def plain_recording_console() -> Console:
    return Console(width=80, force_terminal=True, record=True)


@pytest.fixture
def swap_console(monkeypatch: pytest.MonkeyPatch) -> Callable[[str, Console], Console]:
    def _swap(module_name: str, console: Console) -> Console:
        module = import_module(module_name)
        monkeypatch.setattr(module, "console", console)
        return console

    return _swap


def test_render_success(
    recording_console: Console, swap_console: Callable[[str, Console], Console]
):
    swap_console("rpr.ui.renderers", recording_console)

    render_success("Operation completed")
    output = recording_console.export_text()
    assert "✓ Operation completed" in output


def test_render_error(
    plain_recording_console: Console, swap_console: Callable[[str, Console], Console]
):
    swap_console("rpr.ui.renderers", plain_recording_console)

    render_error("Something went wrong")
    output = plain_recording_console.export_text()
    assert "✗ Something went wrong" in output


def test_render_command_start(
    plain_recording_console: Console, swap_console: Callable[[str, Console], Console]
):
    swap_console("rpr.ui.renderers", plain_recording_console)

    render_command_start("ls -la", "/tmp")
    output = plain_recording_console.export_text()
    assert "[rpr] Running: ls -la" in output

    render_command_start("ls -la", "/tmp", is_dry_run=True)
    output = plain_recording_console.export_text()
    assert "[DRY RUN] Would run ls -la" in output
    assert "in: /tmp" in output


def test_render_file_preview_dry_run(
    plain_recording_console: Console,
    swap_console: Callable[[str, Console], Console],
):
    swap_console("rpr.ui.renderers", plain_recording_console)

    render_file_preview("test.txt", "hello\nworld", is_dry_run=True)
    output = plain_recording_console.export_text()
    assert "[DRY RUN] Would create: test.txt" in output
    assert "1 │ hello" in output
    assert "2 │ world" in output


def test_render_session_header_uses_truecolor_segments(
    swap_console: Callable[[str, Console], Console],
):
    stream = io.StringIO()
    console = Console(
        file=stream, force_terminal=True, color_system="truecolor", width=120
    )
    swap_console("rpr.ui.renderers", console)

    render_session_header(
        project_root=Path("/tmp/project"),
        provider="openai",
        model="gpt-5.4",
        approval_mode="ask",
    )

    output = stream.getvalue().splitlines()[0]
    orange = "\x1b[38;2;255;140;0m"
    red = "\x1b[38;2;255;59;48m"

    assert output.count(orange) == 2
    assert output.count(red) == 1


def test_render_markdown_raw_mode_returns_original_content():
    content = "# Title\n\n- alpha\n- beta\n"
    assert render_markdown(content, mode="raw") == content


def test_render_markdown_preview_supports_panel_and_truncation(
    plain_recording_console: Console,
    swap_console: Callable[[str, Console], Console],
):
    swap_console("rpr.ui.markdown", plain_recording_console)

    render_markdown(
        "# Title\n\n- alpha\n- beta\n- gamma\n",
        title="Markdown Preview",
        max_lines=3,
    )
    output = plain_recording_console.export_text()
    assert "Markdown Preview" in output
    assert "Title" in output
    assert "(preview truncated)" in output
