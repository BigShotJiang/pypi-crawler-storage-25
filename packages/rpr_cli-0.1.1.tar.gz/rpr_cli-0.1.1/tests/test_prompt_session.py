from __future__ import annotations

import asyncio
import sys
from unittest.mock import MagicMock

from prompt_toolkit.document import Document
from prompt_toolkit.keys import Keys
from prompt_toolkit.layout.processors import TransformationInput

from rpr.agent.control import TurnControl
from rpr.application.completer import (
    FileContextCompleter,
    MultiCompleter,
    SlashCommandCandidate,
    SlashCommandCompleter,
)
from rpr.ui.prompt_session import PromptSessionAdapter
from rpr.ui.prompt_session import FileReferenceProcessor


def test_prompt_session_stays_single_line_in_default_mode():
    async def run() -> None:
        adapter = PromptSessionAdapter()
        session = adapter.get_prompt_session()

        height = session._get_default_buffer_control_height()

        assert height.min == 1
        assert height.max == 1
        assert session.layout.current_window.dont_extend_height()

    asyncio.run(run())


def test_prompt_session_multiline_starts_at_one_row_and_can_grow():
    async def run() -> None:
        adapter = PromptSessionAdapter()
        session = adapter.get_prompt_session()
        session.multiline = True

        height = session._get_default_buffer_control_height()

        assert height.min == 1
        assert height.max > 1
        assert session.layout.current_window.dont_extend_height()

    asyncio.run(run())


def test_prompt_session_registers_custom_multiline_enter_bindings():
    adapter = PromptSessionAdapter()
    bindings = adapter._build_key_bindings()

    enter_bindings = bindings.get_bindings_for_keys((Keys.ControlM,))
    meta_enter_bindings = bindings.get_bindings_for_keys((Keys.Escape, Keys.ControlM))

    assert any(binding.keys == (Keys.ControlM,) for binding in enter_bindings)
    assert any(
        binding.keys == (Keys.Escape, Keys.ControlM) for binding in meta_enter_bindings
    )


def test_read_input_forwards_multiline_flag(monkeypatch):
    async def run() -> None:
        adapter = PromptSessionAdapter()
        session = adapter.get_prompt_session()
        recorded: dict[str, object] = {}

        async def fake_prompt_async(*args, **kwargs):
            del args
            recorded.update(kwargs)
            return "hello"

        monkeypatch.setattr(sys.stdin, "isatty", lambda: True)
        monkeypatch.setattr(session, "prompt_async", fake_prompt_async)

        result = await adapter.read_input(multiline=True)

        assert result == "hello"
        assert recorded["multiline"] is True
        assert recorded["show_frame"] is True

    asyncio.run(run())


def test_escape_key_binding_registered_for_task_cancellation():
    adapter = PromptSessionAdapter()
    bindings = adapter._build_key_bindings()

    escape_bindings = bindings.get_bindings_for_keys((Keys.Escape,))

    assert any(binding.keys == (Keys.Escape,) for binding in escape_bindings)


def test_toolbar_is_empty_when_idle():
    async def run() -> None:
        adapter = PromptSessionAdapter()
        adapter.get_prompt_session()

        result = adapter._render_toolbar()

        assert result == []

    asyncio.run(run())


def test_toolbar_shows_esc_hint_when_task_active():
    async def run() -> None:
        adapter = PromptSessionAdapter()
        adapter.get_prompt_session()

        task = asyncio.create_task(asyncio.sleep(60))
        adapter.set_active_task(task)

        try:
            result = adapter._render_toolbar()
            texts = [text for _, text in result]
            assert any("Press ESC to cancel" in t for t in texts)
        finally:
            task.cancel()
            async with asyncio.timeout(1):
                try:
                    await task
                except asyncio.CancelledError:
                    pass

    asyncio.run(run())


def test_toolbar_shows_queue_preview():
    async def run() -> None:
        adapter = PromptSessionAdapter()
        adapter.get_prompt_session()

        task = asyncio.create_task(asyncio.sleep(60))
        adapter.set_active_task(task)
        adapter.set_queue_info(1, "What is the meaning of life?")

        try:
            result = adapter._render_toolbar()
            texts = [text for _, text in result]
            assert any("Queued" in t for t in texts)
            assert any("What is the meaning of life?" in t for t in texts)
        finally:
            task.cancel()
            async with asyncio.timeout(1):
                try:
                    await task
                except asyncio.CancelledError:
                    pass

    asyncio.run(run())


def test_escape_key_cancels_active_task_and_control():
    async def run() -> None:
        adapter = PromptSessionAdapter()
        adapter.get_prompt_session()

        control = TurnControl()
        task = asyncio.create_task(asyncio.sleep(60))
        adapter.set_active_task(task)
        adapter.set_active_control(control)

        bindings = adapter._build_key_bindings()
        escape_bindings = bindings.get_bindings_for_keys((Keys.Escape,))
        cancel_binding = next(b for b in escape_bindings if b.keys == (Keys.Escape,))

        mock_event = MagicMock()
        cancel_binding.handler(mock_event)

        assert control.is_cancelled
        assert task.cancelled() or task.cancelling() > 0

        task.cancel()
        async with asyncio.timeout(1):
            try:
                await task
            except asyncio.CancelledError:
                pass

    asyncio.run(run())


def test_prompt_session_registers_multiple_selector_sources(tmp_path):
    async def run() -> None:
        (tmp_path / "src").mkdir()
        adapter = PromptSessionAdapter()
        adapter.set_completer(
            MultiCompleter(
                [
                    SlashCommandCompleter(
                        [
                            SlashCommandCandidate(
                                name="help", description="Show help", usage="/help"
                            ),
                        ]
                    ),
                    FileContextCompleter(tmp_path),
                ]
            )
        )

        slash_snapshot = adapter._selector.snapshot("/h", 2)
        file_snapshot = adapter._selector.snapshot("Explain @s", len("Explain @s"))

        assert slash_snapshot.visible is True
        assert file_snapshot.trigger == "@"

    asyncio.run(run())


def test_file_reference_processor_highlights_at_paths():
    async def run() -> None:
        processor = FileReferenceProcessor()
        session = PromptSessionAdapter().get_prompt_session()
        line = "Explain @src/main.py"
        transformation = processor.apply_transformation(
            TransformationInput(
                buffer_control=session.layout.current_control,
                document=Document(line),
                lineno=0,
                source_to_display=lambda index: index,
                fragments=[("", line)],
                width=len(line),
                height=1,
            )
        )

        assert transformation.fragments == [
            ("", "Explain "),
            ("class:file-ref", "@src/main.py"),
        ]

    asyncio.run(run())
