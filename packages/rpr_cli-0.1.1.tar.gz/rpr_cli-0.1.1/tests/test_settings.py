from __future__ import annotations

from pathlib import Path

from rich.console import Console
from typer.testing import CliRunner

from rpr.cli import app
from rpr.ui.theme import settings_manager, theme_manager


runner = CliRunner()


def test_settings_theme_list_shows_available_themes(monkeypatch):
    monkeypatch.setattr(
        "rpr.commands.settings.console", Console(highlight=False, no_color=True)
    )
    monkeypatch.setattr(
        "rpr.ui.renderers.console", Console(highlight=False, no_color=True)
    )

    result = runner.invoke(app, ["settings", "theme", "--list"])

    assert result.exit_code == 0, result.stdout
    assert "Available Themes" in result.stdout
    assert "standard" in result.stdout
    assert "dracula" in result.stdout


def test_settings_theme_reports_current_theme(monkeypatch):
    monkeypatch.setattr(
        "rpr.commands.settings.console", Console(highlight=False, no_color=True)
    )
    monkeypatch.setattr(
        "rpr.ui.renderers.console", Console(highlight=False, no_color=True)
    )
    monkeypatch.setattr(theme_manager, "_current_theme_name", "standard")

    result = runner.invoke(app, ["settings", "theme"])

    assert result.exit_code == 0, result.stdout
    assert "Current theme:" in result.stdout
    assert "standard" in result.stdout


def test_settings_theme_updates_theme_and_persists_to_config(monkeypatch, tmp_path):
    config_path = tmp_path / "settings.json"
    monkeypatch.setattr(
        "rpr.commands.settings.console", Console(highlight=False, no_color=True)
    )
    monkeypatch.setattr(
        "rpr.ui.renderers.console", Console(highlight=False, no_color=True)
    )
    monkeypatch.setattr(theme_manager, "_config_path", config_path)
    monkeypatch.setattr(theme_manager, "_current_theme_name", "standard")

    result = runner.invoke(app, ["settings", "theme", "ocean"])

    assert result.exit_code == 0, result.stdout
    assert "Theme set to:" in result.stdout
    assert "ocean" in result.stdout
    assert theme_manager.current_theme_name == "ocean"
    assert '"theme": "ocean"' in config_path.read_text()


def test_settings_theme_rejects_unknown_theme(monkeypatch):
    monkeypatch.setattr(
        "rpr.commands.settings.console", Console(highlight=False, no_color=True)
    )

    result = runner.invoke(app, ["settings", "theme", "nope"])

    assert result.exit_code == 1
    assert "Unknown theme: nope" in result.stdout


def test_settings_root_lists_expanded_registry(monkeypatch):
    monkeypatch.setattr(
        "rpr.commands.settings.console", Console(highlight=False, no_color=True)
    )
    monkeypatch.setattr(
        "rpr.ui.renderers.console", Console(highlight=False, no_color=True)
    )

    result = runner.invoke(app, ["settings"])

    assert result.exit_code == 0, result.stdout
    assert "RPR Settings" in result.stdout
    assert "approval_mode" in result.stdout
    assert "startup_help" in result.stdout


def test_settings_set_updates_non_theme_value(monkeypatch, tmp_path):
    config_path = tmp_path / "settings.json"
    monkeypatch.setattr(
        "rpr.commands.settings.console", Console(highlight=False, no_color=True)
    )
    monkeypatch.setattr(
        "rpr.ui.renderers.console", Console(highlight=False, no_color=True)
    )
    monkeypatch.setattr(settings_manager, "_config_path", config_path)
    monkeypatch.setattr(settings_manager, "_startup_help", True)
    monkeypatch.setattr(settings_manager, "_approval_mode_name", "ask")
    monkeypatch.setattr(settings_manager, "_current_theme_name", "standard")

    result = runner.invoke(app, ["settings", "set", "startup_help", "false"])

    assert result.exit_code == 0, result.stdout
    assert "Updated" in result.stdout
    assert settings_manager.startup_help is False
    assert '"startup_help": false' in config_path.read_text().lower()
