from __future__ import annotations

from pathlib import Path

from rpr.map.classifier import ClassifiedNode, classify
from rpr.map.graph import DependencyGraph
from rpr.map.walker import SourceFile


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _sf(rel: str, language: str = "python") -> SourceFile:
    p = Path(rel)
    return SourceFile(abs_path=Path("/fake") / p, rel_path=p, language=language)  # type: ignore[arg-type]


def _graph(
    nodes: list[SourceFile],
    edges: dict[str, list[str]] | None = None,
) -> DependencyGraph:
    edges = edges or {}
    rev: dict[str, list[str]] = {n.rel_path.as_posix(): [] for n in nodes}
    for src, deps in edges.items():
        for dep in deps:
            rev.setdefault(dep, []).append(src)
    return DependencyGraph(
        nodes=nodes,
        edges=edges,
        reverse_edges=rev,
        cycles=[],
        backend="python-fallback",
    )


def _layer(graph: DependencyGraph, rel: str) -> str:
    results = {c.file.rel_path.as_posix(): c for c in classify(graph)}
    return results[rel].layer


def _node(graph: DependencyGraph, rel: str) -> ClassifiedNode:
    results = {c.file.rel_path.as_posix(): c for c in classify(graph)}
    return results[rel]


# ---------------------------------------------------------------------------
# Entry point detection by filename
# ---------------------------------------------------------------------------


class TestLayerByFilename:
    def test_cli_py(self) -> None:
        g = _graph([_sf("src/cli.py")])
        assert _layer(g, "src/cli.py") == "entry_point"

    def test_main_py(self) -> None:
        g = _graph([_sf("src/main.py")])
        assert _layer(g, "src/main.py") == "entry_point"

    def test_app_py(self) -> None:
        g = _graph([_sf("src/app.py")])
        assert _layer(g, "src/app.py") == "entry_point"

    def test_dunder_main_py(self) -> None:
        g = _graph([_sf("src/__main__.py")])
        assert _layer(g, "src/__main__.py") == "entry_point"

    def test_server_py(self) -> None:
        g = _graph([_sf("src/server.py")])
        assert _layer(g, "src/server.py") == "entry_point"

    def test_apps_directory(self) -> None:
        g = _graph([_sf("apps/web/main.ts")])
        assert _layer(g, "apps/web/main.ts") == "entry_point"


# ---------------------------------------------------------------------------
# DDD layer detection by path segment
# ---------------------------------------------------------------------------


class TestLayerByPath:
    def test_application_services(self) -> None:
        g = _graph([_sf("src/services/order_service.py")])
        assert _layer(g, "src/services/order_service.py") == "application"

    def test_application_workflows(self) -> None:
        g = _graph([_sf("src/workflows/checkout.py")])
        assert _layer(g, "src/workflows/checkout.py") == "application"

    def test_application_use_cases(self) -> None:
        g = _graph([_sf("src/use_cases/place_order.py")])
        assert _layer(g, "src/use_cases/place_order.py") == "application"

    def test_application_handlers(self) -> None:
        g = _graph([_sf("src/handlers/event_handler.py")])
        assert _layer(g, "src/handlers/event_handler.py") == "application"

    def test_entity(self) -> None:
        g = _graph([_sf("src/entities/order.py")])
        assert _layer(g, "src/entities/order.py") == "entity"

    def test_dto_dtos(self) -> None:
        g = _graph([_sf("src/dtos/order_dto.py")])
        assert _layer(g, "src/dtos/order_dto.py") == "dto"

    def test_dto_schemas(self) -> None:
        g = _graph([_sf("src/schemas/order_schema.py")])
        assert _layer(g, "src/schemas/order_schema.py") == "dto"

    def test_dto_models(self) -> None:
        g = _graph([_sf("src/models/order.py")])
        assert _layer(g, "src/models/order.py") == "dto"

    def test_repository_repos(self) -> None:
        g = _graph([_sf("src/repos/order_repo.py")])
        assert _layer(g, "src/repos/order_repo.py") == "repository"

    def test_repository_repositories(self) -> None:
        g = _graph([_sf("src/repositories/order_repository.py")])
        assert _layer(g, "src/repositories/order_repository.py") == "repository"

    def test_infrastructure_config(self) -> None:
        g = _graph([_sf("src/config/settings.py")])
        assert _layer(g, "src/config/settings.py") == "infrastructure"

    def test_infrastructure_db(self) -> None:
        g = _graph([_sf("src/db/connection.py")])
        assert _layer(g, "src/db/connection.py") == "infrastructure"

    def test_infrastructure_orm(self) -> None:
        g = _graph([_sf("src/orm/base.py")])
        assert _layer(g, "src/orm/base.py") == "infrastructure"

    def test_infrastructure_migrations(self) -> None:
        g = _graph([_sf("src/migrations/0001_initial.py")])
        assert _layer(g, "src/migrations/0001_initial.py") == "infrastructure"

    def test_ui_component_components(self) -> None:
        g = _graph([_sf("src/components/Button.tsx")])
        assert _layer(g, "src/components/Button.tsx") == "ui_component"

    def test_ui_component_pages(self) -> None:
        g = _graph([_sf("src/pages/Home.tsx")])
        assert _layer(g, "src/pages/Home.tsx") == "ui_component"

    def test_ui_component_screens(self) -> None:
        g = _graph([_sf("src/screens/Dashboard.tsx")])
        assert _layer(g, "src/screens/Dashboard.tsx") == "ui_component"

    def test_ui_component_views(self) -> None:
        g = _graph([_sf("src/views/Profile.tsx")])
        assert _layer(g, "src/views/Profile.tsx") == "ui_component"

    def test_ui_util_hooks_dir(self) -> None:
        g = _graph([_sf("src/hooks/useAuth.ts")])
        assert _layer(g, "src/hooks/useAuth.ts") == "ui_util"

    def test_ui_util_utils_dir(self) -> None:
        g = _graph([_sf("src/utils/format.ts")])
        assert _layer(g, "src/utils/format.ts") == "ui_util"

    def test_ui_util_hook_suffix(self) -> None:
        g = _graph([_sf("src/useAuth.hook.ts")])
        assert _layer(g, "src/useAuth.hook.ts") == "ui_util"

    def test_ui_util_util_suffix(self) -> None:
        g = _graph([_sf("src/format.util.ts")])
        assert _layer(g, "src/format.util.ts") == "ui_util"


# ---------------------------------------------------------------------------
# Test layer is highest priority
# ---------------------------------------------------------------------------


class TestTestLayerPriority:
    def test_beats_application(self) -> None:
        # path matches both `tests/` and `services/` — test must win
        g = _graph([_sf("tests/services/foo.py")])
        assert _layer(g, "tests/services/foo.py") == "test"

    def test_beats_entry_point_filename(self) -> None:
        # test_ prefix beats cli stem
        g = _graph([_sf("tests/test_cli.py")])
        assert _layer(g, "tests/test_cli.py") == "test"

    def test_stem_starts_with_test_(self) -> None:
        g = _graph([_sf("src/test_order.py")])
        assert _layer(g, "src/test_order.py") == "test"

    def test_dunder_tests_dir(self) -> None:
        g = _graph([_sf("src/__tests__/order.test.ts")])
        assert _layer(g, "src/__tests__/order.test.ts") == "test"

    def test_dot_test_ts_suffix(self) -> None:
        g = _graph([_sf("src/order.test.ts")])
        assert _layer(g, "src/order.test.ts") == "test"


# ---------------------------------------------------------------------------
# Unknown fallback
# ---------------------------------------------------------------------------


class TestUnknownFallback:
    def test_unmatched_path_is_unknown(self) -> None:
        g = _graph([_sf("src/other/misc.py")])
        assert _layer(g, "src/other/misc.py") == "unknown"

    def test_unknown_with_in_edges_stays_unknown(self) -> None:
        nodes = [_sf("src/other/misc.py"), _sf("src/caller.py")]
        g = _graph(
            nodes,
            edges={
                "src/caller.py": ["src/other/misc.py"],
            },
        )
        assert _layer(g, "src/other/misc.py") == "unknown"


# ---------------------------------------------------------------------------
# Topology-based entry_point promotion
# ---------------------------------------------------------------------------


class TestTopologyEntryPoint:
    def test_no_in_edges_with_out_edges_promoted(self) -> None:
        nodes = [_sf("src/bootstrap.py"), _sf("src/other/dep.py")]
        g = _graph(
            nodes,
            edges={"src/bootstrap.py": ["src/other/dep.py"]},
        )
        assert _layer(g, "src/bootstrap.py") == "entry_point"

    def test_already_classified_not_promoted(self) -> None:
        # `services/` matches `application` — topology should not override
        nodes = [_sf("src/services/runner.py"), _sf("src/other/dep.py")]
        g = _graph(
            nodes,
            edges={"src/services/runner.py": ["src/other/dep.py"]},
        )
        assert _layer(g, "src/services/runner.py") == "application"


class TestTopologyNoPromotion:
    def test_unknown_with_in_edges_not_promoted(self) -> None:
        nodes = [_sf("src/a.py"), _sf("src/b.py")]
        g = _graph(nodes, edges={"src/b.py": ["src/a.py"]})
        assert _layer(g, "src/a.py") == "unknown"

    def test_unknown_with_no_out_edges_not_promoted(self) -> None:
        # No out-edges and no in-edges — pure leaf, stays unknown
        g = _graph([_sf("src/other/misc.py")])
        assert _layer(g, "src/other/misc.py") == "unknown"


# ---------------------------------------------------------------------------
# Leaf detection
# ---------------------------------------------------------------------------


class TestLeafDetection:
    def test_no_out_edges_is_leaf(self) -> None:
        g = _graph([_sf("src/leaf.py")])
        assert _node(g, "src/leaf.py").is_leaf is True

    def test_has_out_edges_is_not_leaf(self) -> None:
        nodes = [_sf("src/a.py"), _sf("src/b.py")]
        g = _graph(nodes, edges={"src/a.py": ["src/b.py"]})
        assert _node(g, "src/a.py").is_leaf is False

    def test_dependency_is_leaf_when_no_outgoing(self) -> None:
        nodes = [_sf("src/a.py"), _sf("src/b.py")]
        g = _graph(nodes, edges={"src/a.py": ["src/b.py"]})
        assert _node(g, "src/b.py").is_leaf is True


# ---------------------------------------------------------------------------
# Degree computation
# ---------------------------------------------------------------------------


class TestDegrees:
    def test_out_degree(self) -> None:
        nodes = [_sf("src/a.py"), _sf("src/b.py"), _sf("src/c.py")]
        g = _graph(nodes, edges={"src/a.py": ["src/b.py", "src/c.py"]})
        assert _node(g, "src/a.py").out_degree == 2

    def test_in_degree(self) -> None:
        nodes = [_sf("src/a.py"), _sf("src/b.py"), _sf("src/c.py")]
        g = _graph(
            nodes,
            edges={
                "src/a.py": ["src/c.py"],
                "src/b.py": ["src/c.py"],
            },
        )
        assert _node(g, "src/c.py").in_degree == 2

    def test_isolated_node_zero_degrees(self) -> None:
        g = _graph([_sf("src/isolated.py")])
        n = _node(g, "src/isolated.py")
        assert n.in_degree == 0
        assert n.out_degree == 0


# ---------------------------------------------------------------------------
# All nodes classified
# ---------------------------------------------------------------------------


class TestAllNodesClassified:
    def test_count_matches_graph_nodes(self) -> None:
        nodes = [_sf(f"src/file{i}.py") for i in range(5)]
        g = _graph(nodes)
        assert len(classify(g)) == len(nodes)

    def test_empty_graph(self) -> None:
        g = _graph([])
        assert classify(g) == []

    def test_order_preserved(self) -> None:
        nodes = [_sf(f"src/file{i}.py") for i in range(3)]
        g = _graph(nodes)
        classified = classify(g)
        for original, result in zip(nodes, classified):
            assert result.file is original
