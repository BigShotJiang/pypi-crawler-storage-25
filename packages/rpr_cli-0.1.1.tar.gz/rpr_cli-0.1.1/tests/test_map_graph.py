from __future__ import annotations

from pathlib import Path

from rpr.map.graph import build_graph
from rpr.map.walker import Language, SourceFile


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def _sf(rel: str, lang: Language) -> SourceFile:
    """Create a SourceFile with a synthetic abs_path derived from rel."""
    p = Path(rel)
    return SourceFile(abs_path=Path("/fake/root") / p, rel_path=p, language=lang)


# ---------------------------------------------------------------------------
# Python
# ---------------------------------------------------------------------------


class TestBuildGraphPython:
    def test_chain_a_imports_b_imports_c(self):
        a = _sf("src/a.py", "python")
        b = _sf("src/b.py", "python")
        c = _sf("src/c.py", "python")
        imports = {
            "src/a.py": ["src.b"],
            "src/b.py": ["src.c"],
            "src/c.py": [],
        }
        graph = build_graph([a, b, c], imports)
        assert graph.edges["src/a.py"] == ["src/b.py"]
        assert graph.edges["src/b.py"] == ["src/c.py"]
        assert graph.edges.get("src/c.py", []) == []
        assert graph.backend == "python-fallback"

    def test_relative_import_dot(self):
        importer = _sf("src/rpr/map/walker.py", "python")
        dep = _sf("src/rpr/map/utils.py", "python")
        imports = {"src/rpr/map/walker.py": [".utils"]}
        graph = build_graph([importer, dep], imports)
        assert "src/rpr/map/utils.py" in graph.edges["src/rpr/map/walker.py"]

    def test_relative_import_double_dot(self):
        importer = _sf("src/rpr/map/walker.py", "python")
        dep = _sf("src/rpr/context.py", "python")
        imports = {"src/rpr/map/walker.py": ["..context"]}
        graph = build_graph([importer, dep], imports)
        assert "src/rpr/context.py" in graph.edges["src/rpr/map/walker.py"]

    def test_relative_import_init_fallback(self):
        importer = _sf("src/a.py", "python")
        pkg_init = _sf("src/pkg/__init__.py", "python")
        imports = {"src/a.py": [".pkg"]}
        graph = build_graph([importer, pkg_init], imports)
        assert "src/pkg/__init__.py" in graph.edges["src/a.py"]

    def test_external_package_dropped(self):
        f = _sf("src/main.py", "python")
        imports = {"src/main.py": ["os", "sys", "json"]}
        graph = build_graph([f], imports)
        assert graph.edges.get("src/main.py", []) == []

    def test_absolute_dotted_resolved(self):
        a = _sf("src/rpr/cli.py", "python")
        b = _sf("src/rpr/context.py", "python")
        imports = {"src/rpr/cli.py": ["rpr.context"]}
        graph = build_graph([a, b], imports)
        assert "src/rpr/context.py" in graph.edges["src/rpr/cli.py"]


# ---------------------------------------------------------------------------
# TypeScript / JavaScript
# ---------------------------------------------------------------------------


class TestBuildGraphTypeScript:
    def test_relative_import_resolved_with_extension(self):
        importer = _sf("src/app/main.ts", "typescript")
        dep = _sf("src/app/utils.ts", "typescript")
        imports = {"src/app/main.ts": ["./utils"]}
        graph = build_graph([importer, dep], imports)
        assert "src/app/utils.ts" in graph.edges["src/app/main.ts"]

    def test_relative_import_tsx(self):
        importer = _sf("src/app/main.ts", "typescript")
        dep = _sf("src/app/Button.tsx", "typescript")
        imports = {"src/app/main.ts": ["./Button"]}
        graph = build_graph([importer, dep], imports)
        assert "src/app/Button.tsx" in graph.edges["src/app/main.ts"]

    def test_index_variant_resolved(self):
        importer = _sf("src/app/main.ts", "typescript")
        dep = _sf("src/app/components/index.ts", "typescript")
        imports = {"src/app/main.ts": ["./components"]}
        graph = build_graph([importer, dep], imports)
        assert "src/app/components/index.ts" in graph.edges["src/app/main.ts"]

    def test_parent_directory_import(self):
        importer = _sf("src/app/nested/page.ts", "typescript")
        dep = _sf("src/app/utils.ts", "typescript")
        imports = {"src/app/nested/page.ts": ["../utils"]}
        graph = build_graph([importer, dep], imports)
        assert "src/app/utils.ts" in graph.edges["src/app/nested/page.ts"]

    def test_external_package_dropped(self):
        f = _sf("src/app/main.ts", "typescript")
        imports = {"src/app/main.ts": ["react", "@types/node", "lodash"]}
        graph = build_graph([f], imports)
        assert graph.edges.get("src/app/main.ts", []) == []

    def test_javascript_file_resolved(self):
        importer = _sf("src/index.js", "javascript")
        dep = _sf("src/helpers.js", "javascript")
        imports = {"src/index.js": ["./helpers"]}
        graph = build_graph([importer, dep], imports)
        assert "src/helpers.js" in graph.edges["src/index.js"]


# ---------------------------------------------------------------------------
# Rust
# ---------------------------------------------------------------------------


class TestBuildGraphRust:
    def test_use_crate_resolved(self):
        importer = _sf("src/main.rs", "rust")
        dep = _sf("src/map/walker.rs", "rust")
        imports = {"src/main.rs": ["crate::map::walker"]}
        graph = build_graph([importer, dep], imports)
        assert "src/map/walker.rs" in graph.edges["src/main.rs"]

    def test_use_crate_mod_rs_variant(self):
        importer = _sf("src/main.rs", "rust")
        dep = _sf("src/map/mod.rs", "rust")
        imports = {"src/main.rs": ["crate::map"]}
        graph = build_graph([importer, dep], imports)
        assert "src/map/mod.rs" in graph.edges["src/main.rs"]

    def test_mod_declaration_rs_file(self):
        importer = _sf("src/lib.rs", "rust")
        dep = _sf("src/graph.rs", "rust")
        imports = {"src/lib.rs": ["graph"]}
        graph = build_graph([importer, dep], imports)
        assert "src/graph.rs" in graph.edges["src/lib.rs"]

    def test_mod_declaration_mod_rs(self):
        importer = _sf("src/lib.rs", "rust")
        dep = _sf("src/graph/mod.rs", "rust")
        imports = {"src/lib.rs": ["graph"]}
        graph = build_graph([importer, dep], imports)
        assert "src/graph/mod.rs" in graph.edges["src/lib.rs"]

    def test_extern_crate_dropped(self):
        f = _sf("src/lib.rs", "rust")
        imports = {"src/lib.rs": ["extern::serde", "extern::rayon"]}
        graph = build_graph([f], imports)
        assert graph.edges.get("src/lib.rs", []) == []

    def test_std_use_dropped(self):
        f = _sf("src/lib.rs", "rust")
        imports = {"src/lib.rs": ["std::collections::HashMap"]}
        graph = build_graph([f], imports)
        assert graph.edges.get("src/lib.rs", []) == []


# ---------------------------------------------------------------------------
# C++
# ---------------------------------------------------------------------------


class TestBuildGraphCpp:
    def test_quoted_include_resolved(self):
        importer = _sf("src/main.cpp", "cpp")
        dep = _sf("src/utils.h", "cpp")
        imports = {"src/main.cpp": ['"utils.h"']}
        graph = build_graph([importer, dep], imports)
        assert "src/utils.h" in graph.edges["src/main.cpp"]

    def test_quoted_include_subdirectory(self):
        importer = _sf("src/app/main.cpp", "cpp")
        dep = _sf("src/app/helpers/logger.h", "cpp")
        imports = {"src/app/main.cpp": ['"helpers/logger.h"']}
        graph = build_graph([importer, dep], imports)
        assert "src/app/helpers/logger.h" in graph.edges["src/app/main.cpp"]

    def test_include_dir_fallback(self):
        importer = _sf("src/main.cpp", "cpp")
        dep = _sf("include/utils.h", "cpp")
        imports = {"src/main.cpp": ['"utils.h"']}
        graph = build_graph([importer, dep], imports)
        assert "include/utils.h" in graph.edges["src/main.cpp"]

    def test_angle_bracket_dropped(self):
        f = _sf("src/main.cpp", "cpp")
        imports = {"src/main.cpp": ["<vector>", "<string>", "<stdio.h>"]}
        graph = build_graph([f], imports)
        assert graph.edges.get("src/main.cpp", []) == []


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestBuildGraphEdgeCases:
    def test_duplicate_edges_deduplicated(self):
        a = _sf("src/a.ts", "typescript")
        b = _sf("src/b.ts", "typescript")
        # Same file referenced twice via the same specifier.
        imports = {"src/a.ts": ["./b", "./b"]}
        graph = build_graph([a, b], imports)
        assert graph.edges["src/a.ts"].count("src/b.ts") == 1

    def test_reverse_edges_populated(self):
        a = _sf("src/a.py", "python")
        b = _sf("src/b.py", "python")
        imports = {"src/a.py": ["src.b"], "src/b.py": []}
        graph = build_graph([a, b], imports)
        assert "src/a.py" in graph.reverse_edges.get("src/b.py", [])

    def test_nodes_preserved(self):
        files = [_sf("a.py", "python"), _sf("b.ts", "typescript")]
        graph = build_graph(files, {})
        assert graph.nodes == files

    def test_backend_is_python_fallback(self):
        graph = build_graph([], {})
        assert graph.backend == "python-fallback"

    def test_no_self_edges(self):
        # An import that resolves to the importer itself should not produce a self-edge.
        f = _sf("src/utils.py", "python")
        imports = {"src/utils.py": ["src.utils"]}
        graph = build_graph([f], imports)
        assert "src/utils.py" not in graph.edges.get("src/utils.py", [])

    def test_empty_edges_still_have_all_nodes_as_keys(self):
        files = [_sf("a.py", "python"), _sf("b.py", "python")]
        graph = build_graph(files, {})
        assert "a.py" in graph.edges
        assert "b.py" in graph.edges


# ---------------------------------------------------------------------------
# Cycle detection
# ---------------------------------------------------------------------------


class TestCycleDetection:
    def test_two_node_cycle(self):
        # Use TypeScript relative imports so resolution actually produces edges.
        a = _sf("src/a.ts", "typescript")
        b = _sf("src/b.ts", "typescript")
        imports = {"src/a.ts": ["./b"], "src/b.ts": ["./a"]}
        graph = build_graph([a, b], imports)
        assert any(
            "src/a.ts" in cycle and "src/b.ts" in cycle for cycle in graph.cycles
        )

    def test_three_node_cycle(self):
        a = _sf("src/a.ts", "typescript")
        b = _sf("src/b.ts", "typescript")
        c = _sf("src/c.ts", "typescript")
        imports = {"src/a.ts": ["./b"], "src/b.ts": ["./c"], "src/c.ts": ["./a"]}
        graph = build_graph([a, b, c], imports)
        flat = [n for cycle in graph.cycles for n in cycle]
        assert "src/a.ts" in flat
        assert "src/b.ts" in flat
        assert "src/c.ts" in flat

    def test_linear_chain_no_cycle(self):
        a = _sf("src/a.ts", "typescript")
        b = _sf("src/b.ts", "typescript")
        c = _sf("src/c.ts", "typescript")
        imports = {"src/a.ts": ["./b"], "src/b.ts": ["./c"], "src/c.ts": []}
        graph = build_graph([a, b, c], imports)
        assert graph.cycles == []

    def test_self_loop_detected(self):
        # Build edges directly to simulate a self-referencing resolved graph.
        # We call build_graph with pre-resolved edges via a trick: use a file
        # whose import resolves to itself.
        # Since build_graph prevents self-edges, we test _detect_cycles directly.
        from rpr.map.graph import _detect_cycles

        cycles = _detect_cycles({"a.py": ["a.py"]})
        assert any("a.py" in cycle for cycle in cycles)

    def test_no_cycles_returns_empty_list(self):
        a = _sf("src/a.ts", "typescript")
        b = _sf("src/b.ts", "typescript")
        imports = {"src/a.ts": ["./b"], "src/b.ts": []}
        graph = build_graph([a, b], imports)
        assert graph.cycles == []

    def test_cycle_nodes_closed(self):
        """Each cycle list must start and end with the same node."""
        a = _sf("src/a.ts", "typescript")
        b = _sf("src/b.ts", "typescript")
        imports = {"src/a.ts": ["./b"], "src/b.ts": ["./a"]}
        graph = build_graph([a, b], imports)
        for cycle in graph.cycles:
            assert len(cycle) >= 2
            assert cycle[0] == cycle[-1]
