"""Tests for src/rpr/map/extractor.py.

Tests that do not require the Rust extension always pass (they exercise the
Python fallback path). Tests that require rpr_parser are skipped automatically
when the extension has not been built with ``maturin develop``.
"""

from __future__ import annotations

import warnings
from pathlib import Path
from unittest.mock import patch

import pytest

import rpr.map.extractor as extractor_module
from rpr.map.extractor import (
    analyze_project,
    extract_imports,
    extract_imports_batch,
)
from rpr.map.graph import DependencyGraph
from rpr.map.walker import SourceFile


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_source_file(
    tmp_path: Path,
    name: str,
    language: str,
    content: str = "",
) -> SourceFile:
    p = tmp_path / name
    p.write_text(content, encoding="utf-8")
    return SourceFile(abs_path=p, rel_path=Path(name), language=language)


# ---------------------------------------------------------------------------
# Module-level flag
# ---------------------------------------------------------------------------


def test_rust_available_flag_exists():
    assert hasattr(extractor_module, "_RUST_AVAILABLE")
    assert isinstance(extractor_module._RUST_AVAILABLE, bool)


# ---------------------------------------------------------------------------
# extract_imports — Python
# ---------------------------------------------------------------------------


def test_extract_imports_python_absolute(tmp_path: Path):
    f = _make_source_file(
        tmp_path, "a.py", "python", "import os\nimport rpr.map.walker\n"
    )
    result = extract_imports(f)
    assert "os" in result
    assert "rpr.map.walker" in result


def test_extract_imports_python_from(tmp_path: Path):
    f = _make_source_file(tmp_path, "a.py", "python", "from pathlib import Path\n")
    result = extract_imports(f)
    assert "pathlib" in result


def test_extract_imports_python_relative(tmp_path: Path):
    f = _make_source_file(
        tmp_path,
        "a.py",
        "python",
        "from .utils import x\nfrom ..context import y\n",
    )
    result = extract_imports(f)
    assert ".utils" in result
    assert "..context" in result


def test_extract_imports_python_syntax_error(tmp_path: Path):
    f = _make_source_file(tmp_path, "bad.py", "python", "def (\n  broken [\n")
    result = extract_imports(f)
    assert result == []


# ---------------------------------------------------------------------------
# extract_imports — TypeScript / JavaScript
# ---------------------------------------------------------------------------


def test_extract_imports_ts_import_from(tmp_path: Path):
    f = _make_source_file(
        tmp_path,
        "index.ts",
        "typescript",
        "import { x } from './utils'\n",
    )
    result = extract_imports(f)
    assert "./utils" in result


def test_extract_imports_ts_double_quote(tmp_path: Path):
    f = _make_source_file(
        tmp_path,
        "index.ts",
        "typescript",
        'import type { Foo } from "../types"\n',
    )
    result = extract_imports(f)
    assert "../types" in result


def test_extract_imports_ts_require(tmp_path: Path):
    f = _make_source_file(
        tmp_path,
        "app.js",
        "javascript",
        "const x = require('../lib')\n",
    )
    result = extract_imports(f)
    assert "../lib" in result


def test_extract_imports_ts_dynamic_import(tmp_path: Path):
    f = _make_source_file(
        tmp_path,
        "app.ts",
        "typescript",
        "const mod = import('./lazy')\n",
    )
    result = extract_imports(f)
    assert "./lazy" in result


# ---------------------------------------------------------------------------
# extract_imports — Rust
# ---------------------------------------------------------------------------


def test_extract_imports_rust_use(tmp_path: Path):
    f = _make_source_file(
        tmp_path,
        "lib.rs",
        "rust",
        "use crate::map::walker;\n",
    )
    result = extract_imports(f)
    assert "crate::map::walker" in result


def test_extract_imports_rust_mod(tmp_path: Path):
    f = _make_source_file(tmp_path, "lib.rs", "rust", "mod parser;\n")
    result = extract_imports(f)
    assert "parser" in result


def test_extract_imports_rust_extern_crate(tmp_path: Path):
    f = _make_source_file(tmp_path, "lib.rs", "rust", "extern crate serde;\n")
    result = extract_imports(f)
    assert "serde" in result


def test_extract_imports_rust_use_as_drops_alias(tmp_path: Path):
    f = _make_source_file(tmp_path, "lib.rs", "rust", "use std::io as io;\n")
    result = extract_imports(f)
    assert "std::io" in result
    assert (
        "io" not in result or result.count("std::io") >= 1
    )  # alias not a separate entry


# ---------------------------------------------------------------------------
# extract_imports — C++
# ---------------------------------------------------------------------------


def test_extract_imports_cpp_quoted(tmp_path: Path):
    f = _make_source_file(
        tmp_path,
        "main.cpp",
        "cpp",
        '#include "myheader.h"\n',
    )
    result = extract_imports(f)
    assert "myheader.h" in result


def test_extract_imports_cpp_angle(tmp_path: Path):
    f = _make_source_file(
        tmp_path,
        "main.cpp",
        "cpp",
        "#include <stdio.h>\n",
    )
    result = extract_imports(f)
    assert "stdio.h" in result


# ---------------------------------------------------------------------------
# extract_imports — edge cases
# ---------------------------------------------------------------------------


def test_extract_imports_unreadable_file(tmp_path: Path):
    p = tmp_path / "missing.py"
    # Do NOT create the file — abs_path points to a non-existent path.
    f = SourceFile(abs_path=p, rel_path=Path("missing.py"), language="python")
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result = extract_imports(f)
    assert result == []
    assert any("missing.py" in str(w.message) for w in caught)


def test_extract_imports_unsupported_language(tmp_path: Path):
    p = tmp_path / "README.md"
    p.write_text("# Hello\n")
    # Patch _EXTRACTORS to simulate an unmapped language key
    with patch.dict(extractor_module._EXTRACTORS, {}, clear=False):
        f = SourceFile(abs_path=p, rel_path=Path("README.md"), language="python")
        # Remove python temporarily
        original = extractor_module._EXTRACTORS.pop("python", None)
        try:
            result = extract_imports(f)
        finally:
            if original is not None:
                extractor_module._EXTRACTORS["python"] = original  # type: ignore[assignment]
    assert result == []


# ---------------------------------------------------------------------------
# extract_imports_batch
# ---------------------------------------------------------------------------


def test_extract_imports_batch_maps_all_files(tmp_path: Path):
    a = _make_source_file(tmp_path, "a.py", "python", "import os\n")
    b = _make_source_file(tmp_path, "b.py", "python", "import sys\n")
    result = extract_imports_batch([a, b])
    assert set(result.keys()) == {"a.py", "b.py"}
    assert "os" in result["a.py"]
    assert "sys" in result["b.py"]


def test_extract_imports_batch_empty():
    assert extract_imports_batch([]) == {}


# ---------------------------------------------------------------------------
# analyze_project — Python fallback pipeline
# ---------------------------------------------------------------------------


def test_analyze_project_returns_dependency_graph(tmp_path: Path, monkeypatch):
    monkeypatch.setattr(extractor_module, "_RUST_AVAILABLE", False)
    result = analyze_project(tmp_path)
    assert isinstance(result, DependencyGraph)


def test_analyze_project_fallback_backend(tmp_path: Path, monkeypatch):
    monkeypatch.setattr(extractor_module, "_RUST_AVAILABLE", False)
    result = analyze_project(tmp_path)
    assert result.backend == "python-fallback"


def test_analyze_project_fallback_nodes_are_source_files(tmp_path: Path, monkeypatch):
    (tmp_path / "main.py").write_text("x = 1\n")
    monkeypatch.setattr(extractor_module, "_RUST_AVAILABLE", False)
    result = analyze_project(tmp_path)
    assert len(result.nodes) == 1
    assert isinstance(result.nodes[0], SourceFile)


def test_analyze_project_fallback_builds_edges(tmp_path: Path, monkeypatch):
    (tmp_path / "b.py").write_text("B = 1\n")
    (tmp_path / "a.py").write_text("from b import B\n")
    monkeypatch.setattr(extractor_module, "_RUST_AVAILABLE", False)
    result = analyze_project(tmp_path)
    assert isinstance(result.edges, dict)
    assert "a.py" in result.edges
    # b.py is a single-segment import so resolver drops it (external/stdlib rule);
    # the important thing is the pipeline ran without error and edges is a dict.


def test_analyze_project_fallback_empty_dir(tmp_path: Path, monkeypatch):
    monkeypatch.setattr(extractor_module, "_RUST_AVAILABLE", False)
    result = analyze_project(tmp_path)
    assert result.nodes == []
    assert result.edges == {}
    assert result.cycles == []


def test_analyze_project_fallback_discovers_python_file(tmp_path: Path, monkeypatch):
    (tmp_path / "app.py").write_text("x = 1\n")
    monkeypatch.setattr(extractor_module, "_RUST_AVAILABLE", False)
    result = analyze_project(tmp_path)
    assert len(result.nodes) == 1
    assert result.nodes[0].language == "python"


# ---------------------------------------------------------------------------
# Rust-path tests — skipped when rpr_parser is not built
# ---------------------------------------------------------------------------

try:
    import rpr_parser as _rpr_parser_mod  # noqa: F401

    _HAS_RUST = True
except ImportError:
    _HAS_RUST = False

_skip_no_rust = pytest.mark.skipif(
    not _HAS_RUST,
    reason="rpr_parser not built; run: cd rpr-parser && maturin develop",
)


@_skip_no_rust
def test_rust_path_returns_dependency_graph(tmp_path: Path):
    result = analyze_project(tmp_path)
    assert isinstance(result, DependencyGraph)


@_skip_no_rust
def test_rust_path_backend_is_rust(tmp_path: Path):
    result = analyze_project(tmp_path)
    assert result.backend == "rust"


@_skip_no_rust
def test_rust_path_nodes_are_source_files(tmp_path: Path):
    (tmp_path / "main.py").write_text("pass\n")
    result = analyze_project(tmp_path)
    assert len(result.nodes) == 1
    assert isinstance(result.nodes[0], SourceFile)


@_skip_no_rust
def test_rust_path_discovers_python_files(tmp_path: Path):
    (tmp_path / "main.py").write_text("import os\n")
    result = analyze_project(tmp_path)
    langs = [n.language for n in result.nodes]
    assert "python" in langs


@_skip_no_rust
def test_rust_path_discovers_typescript_files(tmp_path: Path):
    (tmp_path / "index.ts").write_text("export const x = 1;\n")
    result = analyze_project(tmp_path)
    langs = [n.language for n in result.nodes]
    assert "typescript" in langs


@_skip_no_rust
def test_rust_path_builds_edges(tmp_path: Path):
    (tmp_path / "b.py").write_text("B = 1\n")
    (tmp_path / "a.py").write_text("from b import B\n")
    result = analyze_project(tmp_path)
    assert len(result.nodes) == 2
    assert isinstance(result.edges, dict)


@_skip_no_rust
def test_rust_path_respects_ignore_dirs(tmp_path: Path):
    (tmp_path / "main.py").write_text("x = 1\n")
    (tmp_path / "node_modules").mkdir()
    (tmp_path / "node_modules" / "lib.js").write_text("module.exports = {};\n")
    result = analyze_project(tmp_path)
    rel_paths = [str(n.rel_path) for n in result.nodes]
    assert all("node_modules" not in p for p in rel_paths)


@_skip_no_rust
def test_rust_path_cycles_is_list(tmp_path: Path):
    result = analyze_project(tmp_path)
    assert isinstance(result.cycles, list)


@_skip_no_rust
def test_rust_path_node_has_abs_path(tmp_path: Path):
    (tmp_path / "main.py").write_text("pass\n")
    result = analyze_project(tmp_path)
    assert len(result.nodes) == 1
    assert result.nodes[0].abs_path.is_absolute()


# ---------------------------------------------------------------------------
# build_raw_import_inventory
# ---------------------------------------------------------------------------

from rpr.map.extractor import build_raw_import_inventory  # noqa: E402


def _make_graph(tmp_path: Path, files: dict[str, str], language: str = "python") -> DependencyGraph:
    """Helper: write files to tmp_path and return a DependencyGraph with those nodes."""
    nodes: list[SourceFile] = []
    for name, content in files.items():
        p = tmp_path / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        nodes.append(SourceFile(abs_path=p, rel_path=Path(name), language=language))
    return DependencyGraph(
        nodes=nodes,
        edges={},
        reverse_edges={},
        cycles=[],
        backend="python-fallback",
    )


def test_build_raw_import_inventory_returns_dict(tmp_path: Path):
    """build_raw_import_inventory returns a dict keyed by rel_path strings."""
    g = _make_graph(tmp_path, {"app.py": "import os\n"})
    result = build_raw_import_inventory(g)
    assert isinstance(result, dict)
    assert "app.py" in result


def test_build_raw_import_inventory_python_imports(tmp_path: Path):
    """Raw imports from Python source are captured unresolved."""
    g = _make_graph(tmp_path, {"srv.py": "import fastapi\nfrom pathlib import Path\n"})
    result = build_raw_import_inventory(g)
    assert "fastapi" in result["srv.py"]
    assert "pathlib" in result["srv.py"]


def test_build_raw_import_inventory_empty_graph():
    """An empty graph returns an empty inventory."""
    g = DependencyGraph(nodes=[], edges={}, reverse_edges={}, cycles=[], backend="python-fallback")
    result = build_raw_import_inventory(g)
    assert result == {}


def test_build_raw_import_inventory_multiple_files(tmp_path: Path):
    """Every node in the graph is included in the inventory."""
    g = _make_graph(
        tmp_path,
        {"a.py": "import os\n", "b.py": "import sys\n"},
    )
    result = build_raw_import_inventory(g)
    assert set(result.keys()) == {"a.py", "b.py"}
    assert "os" in result["a.py"]
    assert "sys" in result["b.py"]


def test_build_raw_import_inventory_includes_unresolved(tmp_path: Path):
    """Imports that would not resolve to in-repo edges are still in the inventory."""
    g = _make_graph(tmp_path, {"main.py": "import third_party_lib\n"})
    result = build_raw_import_inventory(g)
    assert "third_party_lib" in result["main.py"]

