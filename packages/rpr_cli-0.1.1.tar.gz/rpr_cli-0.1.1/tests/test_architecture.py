from __future__ import annotations

from pathlib import Path

from rpr.map.architecture import (
    ArchitectureAssessment,
    assess_architecture,
)
from rpr.map.graph import DependencyGraph
from rpr.map.topology import build_directory_topology
from rpr.map.walker import SourceFile

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ROOT = Path("/fake/root")


def _sf(rel: str, language: str = "python") -> SourceFile:
    p = Path(rel)
    return SourceFile(abs_path=_ROOT / p, rel_path=p, language=language)  # type: ignore[arg-type]


def _make_graph(
    nodes: list[SourceFile],
    edges: dict[str, list[str]] | None = None,
    cycles: list[list[str]] | None = None,
) -> DependencyGraph:
    edges = edges or {}
    reverse: dict[str, list[str]] = {}
    for src, deps in edges.items():
        for dep in deps:
            reverse.setdefault(dep, []).append(src)
    return DependencyGraph(
        nodes=nodes,
        edges=edges,
        reverse_edges=reverse,
        cycles=cycles or [],
        backend="python-fallback",
    )


def _assess(
    nodes: list[SourceFile],
    edges: dict[str, list[str]] | None = None,
    cycles: list[list[str]] | None = None,
) -> ArchitectureAssessment:
    graph = _make_graph(nodes, edges, cycles)
    topology = build_directory_topology(graph, _ROOT)
    return assess_architecture(graph, topology)


# ---------------------------------------------------------------------------
# TestCleanOnion
# ---------------------------------------------------------------------------


class TestCleanOnion:
    """A well-layered onion: api → domain → infra."""

    def _build(self) -> ArchitectureAssessment:
        nodes = [
            _sf("api/routes/user.py"),
            _sf("domain/models/user.py"),
            _sf("domain/repos/user_repo.py"),
            _sf("infra/db/connection.py"),
        ]
        edges = {
            "api/routes/user.py": ["domain/repos/user_repo.py"],
            "domain/repos/user_repo.py": [
                "infra/db/connection.py",
                "domain/models/user.py",
            ],
        }
        return _assess(nodes, edges)

    def test_verdict_is_likely_onion(self) -> None:
        assert self._build().verdict == "likely_onion"

    def test_api_is_entry_directory(self) -> None:
        entry_dirs = [s.directory for s in self._build().entry_directories]
        assert "api" in entry_dirs

    def test_infra_is_core_directory(self) -> None:
        core_dirs = [s.directory for s in self._build().core_directories]
        assert "infra" in core_dirs

    def test_no_cycle_summaries(self) -> None:
        assert self._build().cycle_summaries == []

    def test_entry_signal_includes_metrics(self) -> None:
        a = self._build()
        sig = next(s for s in a.entry_directories if s.directory == "api")
        assert sig.in_degree == 0
        assert sig.out_degree > 0
        assert sig.file_count > 0
        assert "entry" in sig.note

    def test_core_signal_includes_metrics(self) -> None:
        a = self._build()
        sig = next(s for s in a.core_directories if s.directory == "infra")
        assert sig.in_degree > 0
        assert sig.out_degree == 0
        assert "core" in sig.note

    def test_entry_files_populated(self) -> None:
        a = self._build()
        # api/routes/user.py: nothing imports it, it imports others → entry file
        assert "api/routes/user.py" in a.entry_files

    def test_leaf_files_populated(self) -> None:
        a = self._build()
        # domain/models/user.py has no outgoing tracked deps → leaf file
        assert "domain/models/user.py" in a.leaf_files
        assert "infra/db/connection.py" in a.leaf_files


# ---------------------------------------------------------------------------
# TestCycleHeavy
# ---------------------------------------------------------------------------


class TestCycleHeavy:
    """A project where all files are in a perfect 3-way cycle."""

    def _build(self) -> ArchitectureAssessment:
        nodes = [_sf("a/f1.py"), _sf("b/f2.py"), _sf("c/f3.py")]
        edges = {
            "a/f1.py": ["b/f2.py"],
            "b/f2.py": ["c/f3.py"],
            "c/f3.py": ["a/f1.py"],
        }
        cycles = [["a/f1.py", "b/f2.py", "c/f3.py", "a/f1.py"]]
        return _assess(nodes, edges, cycles)

    def test_verdict_is_unclear(self) -> None:
        assert self._build().verdict == "unclear"

    def test_cycle_summaries_populated(self) -> None:
        a = self._build()
        assert len(a.cycle_summaries) == 1
        cs = a.cycle_summaries[0]
        assert "a/f1.py" in cs.file_cycle
        assert len(cs.directory_cycle) >= 2

    def test_cycle_summary_dir_projection(self) -> None:
        cs = self._build().cycle_summaries[0]
        # Each file maps to its parent directory
        assert "a" in cs.directory_cycle
        assert "b" in cs.directory_cycle
        assert "c" in cs.directory_cycle

    def test_warnings_mention_cycles(self) -> None:
        combined = " ".join(self._build().warnings).lower()
        assert "cycle" in combined

    def test_no_entry_dirs_when_fully_cyclic(self) -> None:
        # Every directory has both incoming and outgoing edges
        assert self._build().entry_directories == []

    def test_no_core_dirs_when_fully_cyclic(self) -> None:
        assert self._build().core_directories == []

    def test_unclear_warning_message(self) -> None:
        combined = " ".join(self._build().warnings).lower()
        assert "unclear" in combined


# ---------------------------------------------------------------------------
# TestHotspot
# ---------------------------------------------------------------------------


class TestHotspot:
    def test_large_directory_flagged(self) -> None:
        # big has 10 files; three others have 1 each → mean=13/4=3.25; 10 > 8.125
        nodes = [_sf(f"big/f{i}.py") for i in range(10)] + [
            _sf("a/x.py"),
            _sf("b/y.py"),
            _sf("c/z.py"),
        ]
        a = _assess(nodes)
        hotspot_dirs = [h.directory for h in a.hotspots]
        assert "big" in hotspot_dirs

    def test_large_hotspot_reason_label(self) -> None:
        nodes = [_sf(f"big/f{i}.py") for i in range(10)] + [
            _sf("a/x.py"),
            _sf("b/y.py"),
            _sf("c/z.py"),
        ]
        a = _assess(nodes)
        big_hs = next(h for h in a.hotspots if h.directory == "big")
        assert "large" in big_hs.reason

    def test_mixed_role_directory_flagged(self) -> None:
        # hub: in_degree=2 (from src1, src2), out_degree=2 (to dep1, dep2)
        nodes = [
            _sf("hub/f.py"),
            _sf("hub/g.py"),
            _sf("src1/a.py"),
            _sf("src2/b.py"),
            _sf("dep1/x.py"),
            _sf("dep2/y.py"),
        ]
        edges = {
            "hub/f.py": ["dep1/x.py"],
            "hub/g.py": ["dep2/y.py"],
            "src1/a.py": ["hub/f.py"],
            "src2/b.py": ["hub/g.py"],
        }
        a = _assess(nodes, edges)
        hotspot_dirs = [h.directory for h in a.hotspots]
        assert "hub" in hotspot_dirs
        hub_hs = next(h for h in a.hotspots if h.directory == "hub")
        assert "mixed_role" in hub_hs.reason

    def test_mixed_role_hotspot_metrics(self) -> None:
        nodes = [
            _sf("hub/f.py"),
            _sf("hub/g.py"),
            _sf("src1/a.py"),
            _sf("src2/b.py"),
            _sf("dep1/x.py"),
            _sf("dep2/y.py"),
        ]
        edges = {
            "hub/f.py": ["dep1/x.py"],
            "hub/g.py": ["dep2/y.py"],
            "src1/a.py": ["hub/f.py"],
            "src2/b.py": ["hub/g.py"],
        }
        a = _assess(nodes, edges)
        hub_hs = next(h for h in a.hotspots if h.directory == "hub")
        assert hub_hs.in_degree >= 2
        assert hub_hs.out_degree >= 2

    def test_hotspot_warning_emitted(self) -> None:
        nodes = [_sf(f"big/f{i}.py") for i in range(10)] + [
            _sf("a/x.py"),
            _sf("b/y.py"),
            _sf("c/z.py"),
        ]
        a = _assess(nodes)
        combined = " ".join(a.warnings)
        assert "big" in combined

    def test_non_hotspot_dirs_not_flagged(self) -> None:
        nodes = [_sf(f"big/f{i}.py") for i in range(10)] + [
            _sf("a/x.py"),
            _sf("b/y.py"),
            _sf("c/z.py"),
        ]
        a = _assess(nodes)
        hotspot_dirs = {h.directory for h in a.hotspots}
        assert "a" not in hotspot_dirs
        assert "b" not in hotspot_dirs


# ---------------------------------------------------------------------------
# TestEntryCore
# ---------------------------------------------------------------------------


class TestEntryCore:
    def test_entry_dir_has_out_no_in(self) -> None:
        nodes = [_sf("api/a.py"), _sf("domain/b.py")]
        edges = {"api/a.py": ["domain/b.py"]}
        a = _assess(nodes, edges)
        entry_dirs = {s.directory for s in a.entry_directories}
        assert "api" in entry_dirs

    def test_core_dir_has_in_no_out(self) -> None:
        nodes = [_sf("api/a.py"), _sf("domain/b.py")]
        edges = {"api/a.py": ["domain/b.py"]}
        a = _assess(nodes, edges)
        core_dirs = {s.directory for s in a.core_directories}
        assert "domain" in core_dirs

    def test_entry_and_core_are_disjoint(self) -> None:
        nodes = [_sf("api/a.py"), _sf("domain/b.py")]
        edges = {"api/a.py": ["domain/b.py"]}
        a = _assess(nodes, edges)
        entry_dirs = {s.directory for s in a.entry_directories}
        core_dirs = {s.directory for s in a.core_directories}
        assert entry_dirs.isdisjoint(core_dirs)

    def test_middle_layer_not_entry_or_core(self) -> None:
        # domain has both incoming (from api) and outgoing (to infra)
        nodes = [_sf("api/a.py"), _sf("domain/b.py"), _sf("infra/c.py")]
        edges = {
            "api/a.py": ["domain/b.py"],
            "domain/b.py": ["infra/c.py"],
        }
        a = _assess(nodes, edges)
        entry_dirs = {s.directory for s in a.entry_directories}
        core_dirs = {s.directory for s in a.core_directories}
        assert "domain" not in entry_dirs
        assert "domain" not in core_dirs

    def test_entry_files_identified(self) -> None:
        nodes = [_sf("api/main.py"), _sf("domain/service.py")]
        edges = {"api/main.py": ["domain/service.py"]}
        a = _assess(nodes, edges)
        assert "api/main.py" in a.entry_files
        assert "domain/service.py" not in a.entry_files

    def test_leaf_files_identified(self) -> None:
        nodes = [_sf("api/main.py"), _sf("domain/service.py")]
        edges = {"api/main.py": ["domain/service.py"]}
        a = _assess(nodes, edges)
        assert "domain/service.py" in a.leaf_files

    def test_leaf_dirs_are_isolated(self) -> None:
        # Dirs with no edges at all are leaf dirs
        nodes = [_sf("api/a.py"), _sf("domain/b.py"), _sf("isolated/c.py")]
        edges = {"api/a.py": ["domain/b.py"]}
        a = _assess(nodes, edges)
        assert "isolated" in a.leaf_directories
        assert "api" not in a.leaf_directories
        assert "domain" not in a.leaf_directories

    def test_core_signal_degree_metrics(self) -> None:
        nodes = [
            _sf("api/a.py"),
            _sf("api/b.py"),
            _sf("domain/x.py"),
        ]
        edges = {
            "api/a.py": ["domain/x.py"],
            "api/b.py": ["domain/x.py"],
        }
        a = _assess(nodes, edges)
        domain_sig = next(
            (s for s in a.core_directories if s.directory == "domain"), None
        )
        assert domain_sig is not None
        assert domain_sig.in_degree == 1  # only 1 unique top-level source (api)
        assert domain_sig.out_degree == 0
        assert domain_sig.file_count >= 1

    def test_entry_directories_sorted(self) -> None:
        nodes = [_sf("z/a.py"), _sf("a/b.py"), _sf("core/c.py")]
        edges = {
            "z/a.py": ["core/c.py"],
            "a/b.py": ["core/c.py"],
        }
        a = _assess(nodes, edges)
        dirs = [s.directory for s in a.entry_directories]
        assert dirs == sorted(dirs)


# ---------------------------------------------------------------------------
# TestConservativeFallback
# ---------------------------------------------------------------------------


class TestConservativeFallback:
    def test_single_top_dir_is_unclear(self) -> None:
        # Only one top-level directory — cannot assess structure
        nodes = [_sf("src/a.py"), _sf("src/b.py")]
        edges = {"src/a.py": ["src/b.py"]}
        assert _assess(nodes, edges).verdict == "unclear"

    def test_no_edges_produces_unclear(self) -> None:
        # Multiple dirs but no cross-dir edges
        nodes = [_sf("a/f.py"), _sf("b/g.py"), _sf("c/h.py")]
        assert _assess(nodes).verdict == "unclear"

    def test_high_cycle_density_produces_unclear(self) -> None:
        nodes = [_sf("x/a.py"), _sf("y/b.py"), _sf("z/c.py")]
        edges = {
            "x/a.py": ["y/b.py"],
            "y/b.py": ["z/c.py"],
            "z/c.py": ["x/a.py"],
        }
        # All 3 files in cycles → density = 100% > 15%
        cycles = [["x/a.py", "y/b.py", "z/c.py", "x/a.py"]]
        assert _assess(nodes, edges, cycles).verdict == "unclear"

    def test_bidirectional_coupling_prevents_onion(self) -> None:
        nodes = [_sf("api/a.py"), _sf("domain/b.py")]
        edges = {
            "api/a.py": ["domain/b.py"],
            "domain/b.py": ["api/a.py"],
        }
        a = _assess(nodes, edges)
        assert a.verdict == "unclear"

    def test_layered_but_mixed_with_isolated_cycle(self) -> None:
        # Clean chain api→domain→infra PLUS an isolated util↔helper cycle
        nodes = [
            _sf("api/a.py"),
            _sf("domain/b.py"),
            _sf("infra/c.py"),
            _sf("util/u.py"),
            _sf("helper/h.py"),
        ]
        edges = {
            "api/a.py": ["domain/b.py"],
            "domain/b.py": ["infra/c.py"],
            "util/u.py": ["helper/h.py"],
            "helper/h.py": ["util/u.py"],
        }
        a = _assess(nodes, edges)
        # has_entry (api), has_core (infra), but dir_cycles (util↔helper)
        assert a.verdict == "layered_but_mixed"

    def test_unclear_warning_explains_reason(self) -> None:
        nodes = [_sf("a/f.py"), _sf("b/g.py")]
        a = _assess(nodes)  # no edges
        combined = " ".join(a.warnings).lower()
        assert "unclear" in combined

    def test_empty_graph_is_unclear(self) -> None:
        a = _assess([])
        assert a.verdict == "unclear"

    def test_onion_with_intra_dir_edges(self) -> None:
        # Intra-dir edges (domain/b → domain/c) must not pollute the top-level verdict
        nodes = [
            _sf("api/a.py"),
            _sf("domain/b.py"),
            _sf("domain/c.py"),
        ]
        edges = {
            "api/a.py": ["domain/b.py"],
            "domain/b.py": ["domain/c.py"],  # intra-dir: no top-level edge created
        }
        a = _assess(nodes, edges)
        # api→domain only at top level; domain has out=0 top-level → core
        assert a.verdict == "likely_onion"


# ---------------------------------------------------------------------------
# TestDirectoryCycles
# ---------------------------------------------------------------------------


class TestDirectoryCycles:
    def test_dir_cycle_warning_emitted(self) -> None:
        nodes = [_sf("a/x.py"), _sf("b/y.py")]
        edges = {"a/x.py": ["b/y.py"], "b/y.py": ["a/x.py"]}
        a = _assess(nodes, edges)
        combined = " ".join(a.warnings).lower()
        assert "cycle" in combined

    def test_bidirectional_coupling_warning(self) -> None:
        nodes = [_sf("a/x.py"), _sf("b/y.py")]
        edges = {"a/x.py": ["b/y.py"], "b/y.py": ["a/x.py"]}
        a = _assess(nodes, edges)
        combined = " ".join(a.warnings).lower()
        assert "bidirectional" in combined

    def test_cycle_summary_directory_projection(self) -> None:
        # Cycle crosses two dirs: files in dir_a and dir_b
        nodes = [_sf("dir_a/f.py"), _sf("dir_b/g.py")]
        edges = {"dir_a/f.py": ["dir_b/g.py"], "dir_b/g.py": ["dir_a/f.py"]}
        cycles = [["dir_a/f.py", "dir_b/g.py", "dir_a/f.py"]]
        a = _assess(nodes, edges, cycles)
        assert len(a.cycle_summaries) == 1
        cs = a.cycle_summaries[0]
        assert "dir_a" in cs.directory_cycle
        assert "dir_b" in cs.directory_cycle

    def test_intra_dir_cycle_collapses_to_single_dir(self) -> None:
        # Both files in same dir: dir projection collapses to one entry
        nodes = [_sf("pkg/a.py"), _sf("pkg/b.py")]
        cycles = [["pkg/a.py", "pkg/b.py", "pkg/a.py"]]
        a = _assess(nodes, {}, cycles)
        cs = a.cycle_summaries[0]
        assert cs.directory_cycle == ("pkg",)

    def test_directory_cycles_stored(self) -> None:
        # ui -> app -> commands -> ui: directory-level cycle should be stored
        nodes = [_sf("ui/panel.py"), _sf("app/service.py"), _sf("commands/run.py")]
        edges = {
            "ui/panel.py": ["app/service.py"],
            "app/service.py": ["commands/run.py"],
            "commands/run.py": ["ui/panel.py"],
        }
        a = _assess(nodes, edges)
        assert len(a.directory_cycles) >= 1
        # The cycle should contain all three directories
        cycle_dirs = set(a.directory_cycles[0])
        assert "ui" in cycle_dirs
        assert "app" in cycle_dirs
        assert "commands" in cycle_dirs

    def test_directory_cycles_empty_when_none(self) -> None:
        # Clean layered graph: no directory cycles
        nodes = [_sf("api/cli.py"), _sf("domain/model.py"), _sf("infra/repo.py")]
        edges = {
            "api/cli.py": ["domain/model.py"],
            "domain/model.py": ["infra/repo.py"],
        }
        a = _assess(nodes, edges)
        assert a.directory_cycles == []


# ---------------------------------------------------------------------------
# TestVerdictReasoning
# ---------------------------------------------------------------------------


class TestVerdictReasoning:
    """ArchitectureAssessment.verdict_reasoning explains why the verdict was chosen."""

    def test_reasoning_populated(self) -> None:
        nodes = [_sf("api/a.py"), _sf("domain/b.py"), _sf("infra/c.py")]
        edges = {
            "api/a.py": ["domain/b.py"],
            "domain/b.py": ["infra/c.py"],
        }
        a = _assess(nodes, edges)
        assert isinstance(a.verdict_reasoning, list)
        assert len(a.verdict_reasoning) > 0

    def test_onion_reasoning_mentions_entry_and_core(self) -> None:
        nodes = [_sf("api/a.py"), _sf("domain/b.py"), _sf("infra/c.py")]
        edges = {
            "api/a.py": ["domain/b.py"],
            "domain/b.py": ["infra/c.py"],
        }
        a = _assess(nodes, edges)
        assert a.verdict == "likely_onion"
        combined = " ".join(a.verdict_reasoning).lower()
        assert "entry areas detected" in combined
        assert "core areas detected" in combined

    def test_unclear_reasoning_no_entry(self) -> None:
        # Fully cyclic — no entry areas
        nodes = [_sf("a/f.py"), _sf("b/g.py")]
        edges = {"a/f.py": ["b/g.py"], "b/g.py": ["a/f.py"]}
        a = _assess(nodes, edges)
        assert a.verdict == "unclear"
        combined = " ".join(a.verdict_reasoning).lower()
        assert "no clear entry" in combined

    def test_reasoning_mentions_dir_cycles(self) -> None:
        nodes = [_sf("ui/a.py"), _sf("app/b.py"), _sf("cmd/c.py")]
        edges = {
            "ui/a.py": ["app/b.py"],
            "app/b.py": ["cmd/c.py"],
            "cmd/c.py": ["ui/a.py"],
        }
        a = _assess(nodes, edges)
        combined = " ".join(a.verdict_reasoning).lower()
        assert "directory cycles present" in combined

    def test_reasoning_mentions_no_dir_cycles_when_clean(self) -> None:
        nodes = [_sf("api/a.py"), _sf("domain/b.py"), _sf("infra/c.py")]
        edges = {
            "api/a.py": ["domain/b.py"],
            "domain/b.py": ["infra/c.py"],
        }
        a = _assess(nodes, edges)
        combined = " ".join(a.verdict_reasoning).lower()
        assert "no directory-level cycles" in combined

    def test_reasoning_mentions_bidirectional_coupling(self) -> None:
        nodes = [_sf("api/a.py"), _sf("domain/b.py")]
        edges = {
            "api/a.py": ["domain/b.py"],
            "domain/b.py": ["api/a.py"],
        }
        a = _assess(nodes, edges)
        combined = " ".join(a.verdict_reasoning).lower()
        assert "bidirectional" in combined

    def test_reasoning_mentions_mixed_role_hotspots(self) -> None:
        nodes = [
            _sf("hub/f.py"),
            _sf("hub/g.py"),
            _sf("src1/a.py"),
            _sf("src2/b.py"),
            _sf("dep1/x.py"),
            _sf("dep2/y.py"),
        ]
        edges = {
            "hub/f.py": ["dep1/x.py"],
            "hub/g.py": ["dep2/y.py"],
            "src1/a.py": ["hub/f.py"],
            "src2/b.py": ["hub/g.py"],
        }
        a = _assess(nodes, edges)
        combined = " ".join(a.verdict_reasoning).lower()
        assert "mixed-role hotspots detected" in combined


# ---------------------------------------------------------------------------
# TestHotspotFileLevelMetrics
# ---------------------------------------------------------------------------


class TestHotspotFileLevelMetrics:
    """Hotspot objects carry file-level fan-in and fan-out evidence."""

    def _make_hub(self) -> tuple[list, dict]:
        """hub has high fan-in (imported by many), one file has high fan-out."""
        nodes = [
            _sf("hub/core.py"),
            _sf("hub/utils.py"),
            _sf("src1/a.py"),
            _sf("src2/b.py"),
            _sf("dep1/x.py"),
            _sf("dep2/y.py"),
        ]
        edges = {
            "hub/core.py": ["dep1/x.py"],
            "hub/utils.py": ["dep2/y.py"],
            "src1/a.py": ["hub/core.py"],
            "src2/b.py": ["hub/core.py"],
        }
        return nodes, edges

    def test_top_fan_in_files_populated(self) -> None:
        nodes, edges = self._make_hub()
        a = _assess(nodes, edges)
        hub_hs = next(h for h in a.hotspots if h.directory == "hub")
        # hub/core.py is imported by src1/a.py and src2/b.py → fan_in=2
        assert len(hub_hs.top_fan_in_files) >= 1
        fan_in_paths = [f for f, _ in hub_hs.top_fan_in_files]
        assert "hub/core.py" in fan_in_paths

    def test_top_fan_in_count_correct(self) -> None:
        nodes, edges = self._make_hub()
        a = _assess(nodes, edges)
        hub_hs = next(h for h in a.hotspots if h.directory == "hub")
        core_entry = next(
            (f, n) for f, n in hub_hs.top_fan_in_files if f == "hub/core.py"
        )
        assert core_entry[1] == 2  # imported by src1/a and src2/b

    def test_top_fan_out_files_populated(self) -> None:
        nodes, edges = self._make_hub()
        a = _assess(nodes, edges)
        hub_hs = next(h for h in a.hotspots if h.directory == "hub")
        assert len(hub_hs.top_fan_out_files) >= 1

    def test_zero_metric_files_excluded(self) -> None:
        # hub/utils.py has fan_in=0 (nobody imports it from outside hub)
        nodes, edges = self._make_hub()
        a = _assess(nodes, edges)
        hub_hs = next(h for h in a.hotspots if h.directory == "hub")
        fan_in_paths = [f for f, _ in hub_hs.top_fan_in_files]
        # hub/utils.py has no importers → should not appear in top_fan_in_files
        assert "hub/utils.py" not in fan_in_paths

    def test_non_hotspot_has_empty_metrics(self) -> None:
        # Small clean dirs are not hotspots and have no metric tuples
        nodes = [_sf("api/a.py"), _sf("domain/b.py"), _sf("infra/c.py")]
        edges = {
            "api/a.py": ["domain/b.py"],
            "domain/b.py": ["infra/c.py"],
        }
        a = _assess(nodes, edges)
        assert a.hotspots == []
