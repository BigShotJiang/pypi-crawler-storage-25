from __future__ import annotations

import random
from pathlib import Path

from rpr.map.architecture import assess_architecture
from rpr.map.chains import (
    RepresentativeChain,
    _MAX_CHAINS_PER_ENTRY,
    _MAX_TOTAL_CHAINS,
    build_diagnostic_chains,
    build_representative_chains,
)
from rpr.map.graph import DependencyGraph
from rpr.map.topology import build_directory_topology
from rpr.map.walker import SourceFile

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ROOT = Path("/fake/root")


def _sf(rel: str, language: str = "python") -> SourceFile:
    p = Path(rel)
    return SourceFile(abs_path=_ROOT / p, rel_path=p, language=language)  # type: ignore[arg-type]


def _make_graph(
    nodes: list[SourceFile],
    edges: dict[str, list[str]] | None = None,
    cycles: list[list[str]] | None = None,
) -> DependencyGraph:
    edges = edges or {}
    reverse: dict[str, list[str]] = {}
    for src, deps in edges.items():
        for dep in deps:
            reverse.setdefault(dep, []).append(src)
    return DependencyGraph(
        nodes=nodes,
        edges=edges,
        reverse_edges=reverse,
        cycles=cycles or [],
        backend="python-fallback",
    )


def _build_chains(
    nodes: list[SourceFile],
    edges: dict[str, list[str]] | None = None,
    cycles: list[list[str]] | None = None,
) -> list[RepresentativeChain]:
    """Full pipeline: nodes -> graph -> topology -> assessment -> chains."""
    graph = _make_graph(nodes, edges, cycles)
    topology = build_directory_topology(graph, _ROOT)
    assessment = assess_architecture(graph, topology)
    return build_representative_chains(graph, topology, assessment)


# ---------------------------------------------------------------------------
# Simple entry-to-leaf
# ---------------------------------------------------------------------------


class TestSimpleEntryToLeaf:
    """Clean onion: api -> domain -> infra."""

    _nodes = [
        _sf("api/routes/user.py"),
        _sf("domain/repos/user_repo.py"),
        _sf("infra/db/connection.py"),
    ]
    _edges = {
        "api/routes/user.py": ["domain/repos/user_repo.py"],
        "domain/repos/user_repo.py": ["infra/db/connection.py"],
    }

    def _chains(self) -> list[RepresentativeChain]:
        return _build_chains(self._nodes, self._edges)

    def test_chain_found(self) -> None:
        assert len(self._chains()) >= 1

    def test_chain_starts_at_entry(self) -> None:
        chain = self._chains()[0]
        assert chain.files[0] == "api/routes/user.py"

    def test_chain_ends_at_leaf(self) -> None:
        chain = self._chains()[0]
        assert chain.files[-1] == "infra/db/connection.py"

    def test_not_truncated(self) -> None:
        chain = self._chains()[0]
        assert chain.truncated is False
        assert chain.truncation_note == ""

    def test_directories_crossed(self) -> None:
        chain = self._chains()[0]
        assert "api/routes" in chain.directories_crossed
        assert "domain/repos" in chain.directories_crossed
        assert "infra/db" in chain.directories_crossed

    def test_directories_in_traversal_order(self) -> None:
        chain = self._chains()[0]
        dirs = chain.directories_crossed
        assert dirs.index("api/routes") < dirs.index("domain/repos")
        assert dirs.index("domain/repos") < dirs.index("infra/db")

    def test_edge_examples_present(self) -> None:
        chain = self._chains()[0]
        assert len(chain.edge_examples) >= 1

    def test_edge_example_directories_correct(self) -> None:
        chain = self._chains()[0]
        example = chain.edge_examples[0]
        assert example.source_directory == "api/routes"
        assert example.target_directory == "domain/repos"

    def test_reason_mentions_entry_and_leaf(self) -> None:
        chain = self._chains()[0]
        assert "entry" in chain.reason
        assert "leaf" in chain.reason


# ---------------------------------------------------------------------------
# Multiple entries — bounded output
# ---------------------------------------------------------------------------


class TestMultipleEntriesBounded:
    """Multiple entry directories; output must be capped."""

    def _make_multi(self, num_entries: int) -> list[RepresentativeChain]:
        """Build a graph with *num_entries* entry directories each pointing to a leaf."""
        nodes: list[SourceFile] = []
        edges: dict[str, list[str]] = {}
        for i in range(num_entries):
            entry = f"entry{i}/main.py"
            leaf = f"lib{i}/util.py"
            nodes.append(_sf(entry))
            nodes.append(_sf(leaf))
            edges[entry] = [leaf]
        return _build_chains(nodes, edges)

    def test_at_least_one_chain_per_entry_dir(self) -> None:
        chains = self._make_multi(3)
        starts = {c.files[0].split("/")[0] for c in chains}
        assert starts == {"entry0", "entry1", "entry2"}

    def test_max_chains_per_entry_respected(self) -> None:
        # Create many entry files in the same directory
        nodes: list[SourceFile] = []
        edges: dict[str, list[str]] = {}
        for i in range(_MAX_CHAINS_PER_ENTRY + 3):
            entry = f"api/handler{i}.py"
            leaf = f"infra/store{i}.py"
            nodes.append(_sf(entry))
            nodes.append(_sf(leaf))
            edges[entry] = [leaf]
        chains = _build_chains(nodes, edges)
        api_chains = [c for c in chains if c.files[0].startswith("api/")]
        assert len(api_chains) <= _MAX_CHAINS_PER_ENTRY

    def test_total_cap_respected(self) -> None:
        chains = self._make_multi(_MAX_TOTAL_CHAINS + 5)
        assert len(chains) <= _MAX_TOTAL_CHAINS

    def test_deterministic_output(self) -> None:
        chains1 = self._make_multi(5)
        chains2 = self._make_multi(5)
        assert chains1 == chains2


# ---------------------------------------------------------------------------
# Directory edge evidence reuse
# ---------------------------------------------------------------------------


class TestDirectoryEdgeEvidenceReuse:
    """Edge examples should come from topology representatives."""

    _nodes = [
        _sf("api/routes/user.py"),
        _sf("domain/repos/user_repo.py"),
        _sf("infra/db/connection.py"),
    ]
    _edges = {
        "api/routes/user.py": ["domain/repos/user_repo.py"],
        "domain/repos/user_repo.py": ["infra/db/connection.py"],
    }

    def test_edge_example_matches_topology_representative(self) -> None:
        graph = _make_graph(self._nodes, self._edges)
        topology = build_directory_topology(graph, _ROOT)
        assessment = assess_architecture(graph, topology)
        chains = build_representative_chains(graph, topology, assessment)

        assert chains, "expected at least one chain"
        chain = chains[0]
        example = chain.edge_examples[0]

        # The topology edge for this pair should exist
        topo_edge = topology.edges.get(
            (example.source_directory, example.target_directory)
        )
        assert topo_edge is not None, "topology edge missing for boundary in chain"

        # The example files must come from the topology representatives
        assert (example.source_file, example.target_file) in topo_edge.representatives


# ---------------------------------------------------------------------------
# Duplicate chain avoidance
# ---------------------------------------------------------------------------


class TestDuplicateChainAvoidance:
    """Converging entries must not produce duplicate chains."""

    def test_no_duplicate_file_sets(self) -> None:
        # Both entries converge onto the same downstream path
        nodes = [
            _sf("api/handler_a.py"),
            _sf("api/handler_b.py"),
            _sf("domain/service.py"),
            _sf("infra/store.py"),
        ]
        edges = {
            "api/handler_a.py": ["domain/service.py"],
            "api/handler_b.py": ["domain/service.py"],
            "domain/service.py": ["infra/store.py"],
        }
        chains = _build_chains(nodes, edges)
        file_sets = [frozenset(c.files) for c in chains]
        assert len(file_sets) == len(set(file_sets)), "duplicate chains found"


# ---------------------------------------------------------------------------
# Cyclic graph truncation
# ---------------------------------------------------------------------------


class TestCyclicGraphTruncation:
    """All-cycle graph must still yield truncated chains."""

    _nodes = [
        _sf("a/f1.py"),
        _sf("b/f2.py"),
        _sf("c/f3.py"),
    ]
    _edges = {
        "a/f1.py": ["b/f2.py"],
        "b/f2.py": ["c/f3.py"],
        "c/f3.py": ["a/f1.py"],
    }
    _cycles = [["a/f1.py", "b/f2.py", "c/f3.py", "a/f1.py"]]

    def _chains(self) -> list[RepresentativeChain]:
        return _build_chains(self._nodes, self._edges, self._cycles)

    def test_chains_returned_despite_cycles(self) -> None:
        assert len(self._chains()) >= 1

    def test_truncated_flag_set(self) -> None:
        for chain in self._chains():
            assert chain.truncated is True

    def test_truncation_note_non_empty(self) -> None:
        for chain in self._chains():
            assert chain.truncation_note != ""

    def test_chain_has_multiple_files(self) -> None:
        for chain in self._chains():
            assert len(chain.files) >= 2


# ---------------------------------------------------------------------------
# __init__.py deprioritization
# ---------------------------------------------------------------------------


class TestInitFileDeprioritization:
    """Non-init entry files are preferred; init files are used when necessary."""

    def test_init_file_not_first_choice(self) -> None:
        nodes = [
            _sf("api/__init__.py"),
            _sf("api/routes/user.py"),
            _sf("domain/service.py"),
        ]
        edges = {
            "api/__init__.py": ["domain/service.py"],
            "api/routes/user.py": ["domain/service.py"],
        }
        chains = _build_chains(nodes, edges)
        # The first chain should start from the descriptive file, not __init__
        first_starts = [c.files[0] for c in chains]
        assert "api/routes/user.py" in first_starts
        if len(first_starts) > 1:
            assert first_starts[0] == "api/routes/user.py"

    def test_init_file_used_when_only_option(self) -> None:
        nodes = [
            _sf("api/__init__.py"),
            _sf("domain/service.py"),
        ]
        edges = {"api/__init__.py": ["domain/service.py"]}
        chains = _build_chains(nodes, edges)
        assert len(chains) == 1
        assert chains[0].files[0] == "api/__init__.py"


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_empty_graph_returns_empty(self) -> None:
        assert _build_chains([]) == []

    def test_fully_cyclic_no_entry_files_yields_truncated_chains(self) -> None:
        # Every file has an importer — assessment.entry_files is empty.
        # The fallback picks one file per top-level directory that has outgoing
        # edges, so cyclic graphs still yield truncated chains per story 17c AC.
        nodes = [_sf("a/x.py"), _sf("b/y.py")]
        edges = {"a/x.py": ["b/y.py"], "b/y.py": ["a/x.py"]}
        chains = _build_chains(nodes, edges, [["a/x.py", "b/y.py", "a/x.py"]])
        assert len(chains) >= 1
        assert all(c.truncated for c in chains)

    def test_single_file_no_edges_returns_empty(self) -> None:
        assert _build_chains([_sf("main.py")]) == []

    def test_long_chain_truncated(self) -> None:
        # Build a chain longer than _MAX_CHAIN_LENGTH
        from rpr.map.chains import _MAX_CHAIN_LENGTH

        n = _MAX_CHAIN_LENGTH + 3
        nodes = [_sf(f"layer{i}/file.py") for i in range(n)]
        edges: dict[str, list[str]] = {}
        for i in range(n - 1):
            edges[f"layer{i}/file.py"] = [f"layer{i + 1}/file.py"]

        chains = _build_chains(nodes, edges)
        assert len(chains) >= 1
        truncated_chains = [c for c in chains if c.truncated]
        assert truncated_chains, "expected a truncated chain for a very deep graph"
        assert len(truncated_chains[0].files) <= _MAX_CHAIN_LENGTH


# ---------------------------------------------------------------------------
# Determinism
# ---------------------------------------------------------------------------


class TestDeterminism:
    _nodes = [
        _sf("api/routes/user.py"),
        _sf("api/routes/order.py"),
        _sf("domain/repos/user_repo.py"),
        _sf("domain/repos/order_repo.py"),
        _sf("infra/db/connection.py"),
    ]
    _edges = {
        "api/routes/user.py": ["domain/repos/user_repo.py"],
        "api/routes/order.py": ["domain/repos/order_repo.py"],
        "domain/repos/user_repo.py": ["infra/db/connection.py"],
        "domain/repos/order_repo.py": ["infra/db/connection.py"],
    }

    def test_same_input_same_output(self) -> None:
        c1 = _build_chains(self._nodes, self._edges)
        c2 = _build_chains(self._nodes, self._edges)
        assert c1 == c2

    def test_node_insertion_order_irrelevant(self) -> None:
        shuffled = list(self._nodes)
        random.seed(42)
        random.shuffle(shuffled)
        c1 = _build_chains(self._nodes, self._edges)
        c2 = _build_chains(shuffled, self._edges)
        assert c1 == c2


# ---------------------------------------------------------------------------
# Acceptance criteria
# ---------------------------------------------------------------------------


class TestAcceptanceCriteria:
    """Direct verification of story 17c acceptance criteria."""

    _nodes = [
        _sf("api/routes/user.py"),
        _sf("api/routes/order.py"),
        _sf("domain/services/user_service.py"),
        _sf("domain/repos/user_repo.py"),
        _sf("infra/db/connection.py"),
    ]
    _edges = {
        "api/routes/user.py": ["domain/services/user_service.py"],
        "api/routes/order.py": ["domain/repos/user_repo.py"],
        "domain/services/user_service.py": ["domain/repos/user_repo.py"],
        "domain/repos/user_repo.py": ["infra/db/connection.py"],
    }

    def _chains(self) -> list[RepresentativeChain]:
        return _build_chains(self._nodes, self._edges)

    def test_at_least_one_chain_per_major_entry_area(self) -> None:
        chains = self._chains()
        entry_dirs = {c.files[0].split("/")[0] for c in chains}
        assert "api" in entry_dirs

    def test_directories_crossed_exist_in_topology(self) -> None:
        graph = _make_graph(self._nodes, self._edges)
        topology = build_directory_topology(graph, _ROOT)
        assessment = assess_architecture(graph, topology)
        chains = build_representative_chains(graph, topology, assessment)

        all_dirs = set(topology.nodes.keys())
        for chain in chains:
            for d in chain.directories_crossed:
                assert d in all_dirs, f"directory '{d}' not in topology"

    def test_edge_examples_for_directory_edges(self) -> None:
        chains = self._chains()
        chains_with_examples = [c for c in chains if c.edge_examples]
        assert chains_with_examples, "expected at least one chain with edge examples"

    def test_bounded_output(self) -> None:
        chains = self._chains()
        assert len(chains) <= _MAX_TOTAL_CHAINS

    def test_deterministic(self) -> None:
        assert self._chains() == self._chains()

    def test_chain_files_are_valid_nodes(self) -> None:
        graph = _make_graph(self._nodes, self._edges)
        topology = build_directory_topology(graph, _ROOT)
        assessment = assess_architecture(graph, topology)
        chains = build_representative_chains(graph, topology, assessment)

        node_paths = {n.rel_path.as_posix() for n in graph.nodes}
        for chain in chains:
            for f in chain.files:
                assert f in node_paths, f"chain file '{f}' not in graph nodes"


# ---------------------------------------------------------------------------
# Coupling score
# ---------------------------------------------------------------------------


class TestCouplingScore:
    """RepresentativeChain.coupling_score reflects directory edge support."""

    _nodes = [
        _sf("api/routes/user.py"),
        _sf("domain/repos/user_repo.py"),
        _sf("infra/db/connection.py"),
    ]
    _edges = {
        "api/routes/user.py": ["domain/repos/user_repo.py"],
        "domain/repos/user_repo.py": ["infra/db/connection.py"],
    }

    def test_coupling_score_non_negative(self) -> None:
        chains = _build_chains(self._nodes, self._edges)
        for chain in chains:
            assert chain.coupling_score >= 0

    def test_coupling_score_positive_for_cross_dir_chain(self) -> None:
        # api -> domain -> infra crosses two directory edges, each with support >= 1
        chains = _build_chains(self._nodes, self._edges)
        assert chains, "expected at least one chain"
        assert chains[0].coupling_score > 0

    def test_chains_sorted_by_score_descending(self) -> None:
        # Build a graph where one chain has higher support than others
        nodes = [
            _sf("api/a.py"),
            _sf("api/b.py"),
            _sf("api/c.py"),
            _sf("domain/svc.py"),
            _sf("infra/db.py"),
        ]
        edges = {
            "api/a.py": ["domain/svc.py"],
            "api/b.py": ["domain/svc.py"],
            "api/c.py": ["domain/svc.py"],
            "domain/svc.py": ["infra/db.py"],
        }
        chains = _build_chains(nodes, edges)
        scores = [c.coupling_score for c in chains]
        assert scores == sorted(scores, reverse=True), "chains not sorted by coupling score"

    def test_coupling_score_deterministic(self) -> None:
        c1 = _build_chains(self._nodes, self._edges)
        c2 = _build_chains(self._nodes, self._edges)
        assert [c.coupling_score for c in c1] == [c.coupling_score for c in c2]

    def test_empty_graph_no_chains(self) -> None:
        chains = _build_chains([])
        assert chains == []


# ---------------------------------------------------------------------------
# build_diagnostic_chains
# ---------------------------------------------------------------------------


class TestDiagnosticChains:
    """build_diagnostic_chains returns BFS-ordered shortest-path chains."""

    _nodes = [
        _sf("api/routes/user.py"),
        _sf("domain/repos/user_repo.py"),
        _sf("infra/db/connection.py"),
    ]
    _edges = {
        "api/routes/user.py": ["domain/repos/user_repo.py"],
        "domain/repos/user_repo.py": ["infra/db/connection.py"],
    }

    def _diagnostic(self) -> list[RepresentativeChain]:
        graph = _make_graph(self._nodes, self._edges)
        topology = build_directory_topology(graph, _ROOT)
        assessment = assess_architecture(graph, topology)
        return build_diagnostic_chains(graph, topology, assessment)

    def test_diagnostic_chains_returned(self) -> None:
        assert len(self._diagnostic()) >= 1

    def test_diagnostic_same_files_as_representative(self) -> None:
        rep = _build_chains(self._nodes, self._edges)
        diag = self._diagnostic()
        rep_file_sets = {frozenset(c.files) for c in rep}
        diag_file_sets = {frozenset(c.files) for c in diag}
        assert rep_file_sets == diag_file_sets

    def test_diagnostic_has_coupling_score(self) -> None:
        for chain in self._diagnostic():
            assert chain.coupling_score >= 0

    def test_diagnostic_deterministic(self) -> None:
        graph = _make_graph(self._nodes, self._edges)
        topology = build_directory_topology(graph, _ROOT)
        assessment = assess_architecture(graph, topology)
        d1 = build_diagnostic_chains(graph, topology, assessment)
        d2 = build_diagnostic_chains(graph, topology, assessment)
        assert d1 == d2
