from __future__ import annotations

import io
import re
from pathlib import Path

import pytest

from rpr.map.architecture import assess_architecture
from rpr.map.chains import build_representative_chains
from rpr.map.classifier import ClassifiedNode
from rpr.map.coverage import CoverageRecord
from rpr.map.dependencies import ExternalDependencySummary
from rpr.map.graph import DependencyGraph
from rpr.map.output import write_map
from rpr.map.responsibility import ResponsibilitySummary
from rpr.map.topology import build_directory_topology
from rpr.map.walker import SourceFile

# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------

_ROOT = Path("/fake/root")


def _sf(rel: str, language: str = "python") -> SourceFile:
    p = Path(rel)
    return SourceFile(abs_path=_ROOT / p, rel_path=p, language=language)


def _graph(
    nodes: list[SourceFile] | None = None,
    edges: dict[str, list[str]] | None = None,
    cycles: list[list[str]] | None = None,
    backend: str = "python-fallback",
) -> DependencyGraph:
    nodes = nodes or []
    edges = edges or {}
    cycles = cycles or []
    rev: dict[str, list[str]] = {}
    for src, deps in edges.items():
        for dep in deps:
            rev.setdefault(dep, []).append(src)
    return DependencyGraph(
        nodes=nodes,
        edges=edges,
        reverse_edges=rev,
        cycles=cycles,
        backend=backend,
    )


def _classified(
    sf: SourceFile,
    layer: str,
    in_degree: int = 0,
    out_degree: int = 0,
    is_leaf: bool | None = None,
) -> ClassifiedNode:
    if is_leaf is None:
        is_leaf = out_degree == 0
    return ClassifiedNode(
        file=sf,
        layer=layer,
        is_leaf=is_leaf,
        in_degree=in_degree,
        out_degree=out_degree,
    )


def _write_and_read(
    nodes: list[ClassifiedNode],
    edges: dict[str, list[str]] | None = None,
    cycles: list[list[str]] | None = None,
    backend: str = "python-fallback",
    details: bool = False,
    tmp_path: Path | None = None,
) -> str:
    sfs = [n.file for n in nodes]
    g = _graph(nodes=sfs, edges=edges, cycles=cycles, backend=backend)
    out = (tmp_path or Path("/tmp")) / "code-map.md"
    write_map(g, nodes, out, _ROOT, details=details)
    return out.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# TestHeaderBlock
# ---------------------------------------------------------------------------


class TestHeaderBlock:
    def test_starts_with_code_map(self, tmp_path: Path) -> None:
        nodes = [_classified(_sf("src/main.py"), "entry_point", out_degree=1)]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert content.startswith("# Code Map")

    def test_header_fields_present(self, tmp_path: Path) -> None:
        nodes = [_classified(_sf("src/main.py"), "entry_point")]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "Generated:" in content
        assert "Root:" in content
        assert "Files analyzed: 1" in content
        assert "Languages: python" in content
        assert "Backend: python-fallback" in content

    def test_backend_rust(self, tmp_path: Path) -> None:
        nodes = [_classified(_sf("src/main.py"), "entry_point")]
        sfs = [n.file for n in nodes]
        g = _graph(nodes=sfs, backend="rust")
        out = tmp_path / "code-map.md"
        write_map(g, nodes, out, _ROOT)
        assert "Backend: rust" in out.read_text()

    def test_multiple_languages(self, tmp_path: Path) -> None:
        nodes = [
            _classified(_sf("src/main.py", "python"), "entry_point"),
            _classified(_sf("src/app.ts", "typescript"), "application"),
        ]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "python" in content
        assert "typescript" in content


# ---------------------------------------------------------------------------
# TestLayerTable
# ---------------------------------------------------------------------------


class TestLayerTable:
    def test_layer_table_heading(self, tmp_path: Path) -> None:
        nodes = [_classified(_sf("src/main.py"), "entry_point")]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "## Layer Summary" in content

    def test_only_non_empty_layers_appear(self, tmp_path: Path) -> None:
        nodes = [
            _classified(_sf("src/cli.py"), "entry_point"),
            _classified(_sf("src/service.py"), "application"),
        ]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "| entry_point |" in content
        assert "| application |" in content
        # Layers not in nodes should not appear
        assert "| entity |" not in content
        assert "| dto |" not in content

    def test_file_count_correct(self, tmp_path: Path) -> None:
        nodes = [
            _classified(_sf("src/cli.py"), "entry_point"),
            _classified(_sf("src/main.py"), "entry_point"),
            _classified(_sf("src/service.py"), "application"),
        ]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        # entry_point row has count 2
        assert "| entry_point | 2 |" in content
        assert "| application | 1 |" in content

    def test_single_layer_only(self, tmp_path: Path) -> None:
        nodes = [_classified(_sf("src/a.py"), "entity")]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "| entity |" in content
        assert content.count("| entry_point |") == 0


# ---------------------------------------------------------------------------
# TestEntryPoints
# ---------------------------------------------------------------------------


class TestEntryPoints:
    def test_entry_points_listed(self, tmp_path: Path) -> None:
        nodes = [
            _classified(_sf("src/cli.py"), "entry_point", out_degree=3),
            _classified(_sf("src/main.py"), "entry_point", out_degree=1),
        ]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "## Entry Points" in content
        assert "src/cli.py (out-degree: 3)" in content
        assert "src/main.py (out-degree: 1)" in content

    def test_no_entry_points_section_absent(self, tmp_path: Path) -> None:
        nodes = [_classified(_sf("src/service.py"), "application")]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "## Entry Points" not in content


# ---------------------------------------------------------------------------
# TestLayersBreakdown
# ---------------------------------------------------------------------------


class TestLayersBreakdown:
    def test_leaf_annotation_present(self, tmp_path: Path) -> None:
        leaf = _classified(
            _sf("src/base.py"), "entity", in_degree=3, out_degree=0, is_leaf=True
        )
        non_leaf = _classified(
            _sf("src/user.py"), "entity", in_degree=1, out_degree=1, is_leaf=False
        )
        content = _write_and_read([leaf, non_leaf], tmp_path=tmp_path)
        assert "src/base.py — 3 dependents, 0 dependencies (leaf)" in content
        assert "src/user.py — 1 dependents, 1 dependencies" in content
        # non-leaf must not have the suffix
        assert "src/user.py — 1 dependents, 1 dependencies (leaf)" not in content

    def test_layers_breakdown_heading(self, tmp_path: Path) -> None:
        nodes = [_classified(_sf("src/a.py"), "application")]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "## Layers Breakdown" in content

    def test_subsection_per_layer(self, tmp_path: Path) -> None:
        nodes = [
            _classified(_sf("src/cli.py"), "entry_point"),
            _classified(_sf("src/service.py"), "application"),
        ]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "### Entry Point" in content
        assert "### Application" in content


# ---------------------------------------------------------------------------
# TestCycles
# ---------------------------------------------------------------------------


class TestCycles:
    def test_cycles_section_present(self, tmp_path: Path) -> None:
        nodes = [
            _classified(_sf("src/a.py"), "application"),
            _classified(_sf("src/b.py"), "application"),
        ]
        sfs = [n.file for n in nodes]
        g = _graph(
            nodes=sfs,
            edges={"src/a.py": ["src/b.py"], "src/b.py": ["src/a.py"]},
            cycles=[["src/a.py", "src/b.py", "src/a.py"]],
        )
        out = tmp_path / "code-map.md"
        write_map(g, nodes, out, _ROOT)
        content = out.read_text()
        assert "## ⚠ Cycles Detected" in content
        assert "src/a.py → src/b.py → src/a.py" in content

    def test_cycles_section_absent_when_no_cycles(self, tmp_path: Path) -> None:
        nodes = [_classified(_sf("src/a.py"), "application")]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "Cycles" not in content


# ---------------------------------------------------------------------------
# TestEdges
# ---------------------------------------------------------------------------


class TestEdges:
    def test_test_files_excluded(self, tmp_path: Path) -> None:
        app_sf = _sf("src/service.py")
        test_sf = _sf("tests/test_service.py")
        nodes = [
            _classified(app_sf, "application", out_degree=0),
            _classified(test_sf, "test", out_degree=1),
        ]
        edges = {"tests/test_service.py": ["src/service.py"]}
        content = _write_and_read(nodes, edges=edges, tmp_path=tmp_path)
        # test file should not appear as an edge source
        assert "tests/test_service.py →" not in content

    def test_leaf_nodes_excluded(self, tmp_path: Path) -> None:
        src_sf = _sf("src/cli.py")
        leaf_sf = _sf("src/config.py")
        nodes = [
            _classified(src_sf, "entry_point", out_degree=1, is_leaf=False),
            _classified(leaf_sf, "infrastructure", out_degree=0, is_leaf=True),
        ]
        edges = {"src/cli.py": ["src/config.py"]}
        content = _write_and_read(nodes, edges=edges, tmp_path=tmp_path)
        # leaf should not appear as source
        assert "src/config.py →" not in content

    def test_edge_truncation(self, tmp_path: Path) -> None:
        # Build 310 source files each importing one unique target
        sfs_src = [_sf(f"src/mod_{i}.py") for i in range(310)]
        sfs_dep = [_sf(f"src/dep_{i}.py") for i in range(310)]
        nodes = [
            _classified(s, "application", out_degree=1, is_leaf=False) for s in sfs_src
        ] + [_classified(d, "entity", out_degree=0, is_leaf=True) for d in sfs_dep]
        # Leaf targets won't appear in edge output, but sources (non-leaf) will
        # Make targets non-leaf so they don't get excluded
        nodes = [
            _classified(s, "application", out_degree=1, is_leaf=False) for s in sfs_src
        ] + [
            _classified(d, "entity", in_degree=1, out_degree=0, is_leaf=False)
            for d in sfs_dep
        ]
        edges = {f"src/mod_{i}.py": [f"src/dep_{i}.py"] for i in range(310)}
        all_sfs = [n.file for n in nodes]
        g = _graph(nodes=all_sfs, edges=edges)
        out = tmp_path / "code-map.md"
        write_map(g, nodes, out, _ROOT)
        content = out.read_text()
        assert "truncated" in content
        assert "edges omitted" in content
        # Exactly 300 edge lines before truncation note
        edge_section = content.split("## Dependency Edges")[1]
        edge_lines = [
            ln
            for ln in edge_section.splitlines()
            if " → " in ln and "truncated" not in ln
        ]
        assert len(edge_lines) == 300

    def test_no_edges_section_absent(self, tmp_path: Path) -> None:
        # All nodes are leaves — no edges to render
        nodes = [_classified(_sf("src/a.py"), "entity", is_leaf=True)]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "## Dependency Edges" not in content


# ---------------------------------------------------------------------------
# TestDryRun
# ---------------------------------------------------------------------------


class TestDryRun:
    def test_dry_run_no_file_written(
        self, tmp_path: Path, capsys: pytest.CaptureFixture
    ) -> None:
        nodes = [_classified(_sf("src/cli.py"), "entry_point", out_degree=1)]
        sfs = [n.file for n in nodes]
        g = _graph(nodes=sfs)
        out = tmp_path / "code-map.md"
        write_map(g, nodes, out, _ROOT, dry_run=True)
        assert not out.exists()

    def test_dry_run_prints_to_stdout(
        self, tmp_path: Path, capsys: pytest.CaptureFixture
    ) -> None:
        nodes = [_classified(_sf("src/cli.py"), "entry_point", out_degree=1)]
        sfs = [n.file for n in nodes]
        g = _graph(nodes=sfs)
        out = tmp_path / "code-map.md"
        write_map(g, nodes, out, _ROOT, dry_run=True)
        captured = capsys.readouterr()
        # console.print goes to stdout
        assert "# Code Map" in captured.out

    def test_dry_run_max_30_lines(
        self, tmp_path: Path, capsys: pytest.CaptureFixture
    ) -> None:
        # Build enough nodes to produce a long output
        nodes = [_classified(_sf(f"src/mod_{i}.py"), "application") for i in range(50)]
        sfs = [n.file for n in nodes]
        g = _graph(nodes=sfs)
        out = tmp_path / "code-map.md"
        write_map(g, nodes, out, _ROOT, dry_run=True)
        captured = capsys.readouterr()
        printed_lines = captured.out.splitlines()
        assert len(printed_lines) <= 30


# ---------------------------------------------------------------------------
# TestMermaid
# ---------------------------------------------------------------------------


class TestMermaid:
    def test_mermaid_block_present(self, tmp_path: Path) -> None:
        nodes = [_classified(_sf("src/cli.py"), "entry_point")]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "```mermaid" in content

    def test_mermaid_frontmatter(self, tmp_path: Path) -> None:
        nodes = [_classified(_sf("src/cli.py"), "entry_point")]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "layout: elk" in content
        assert "theme: base" in content

    def test_mermaid_flowchart_tb(self, tmp_path: Path) -> None:
        nodes = [_classified(_sf("src/cli.py"), "entry_point")]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "flowchart TB" in content

    def test_subgraph_per_layer(self, tmp_path: Path) -> None:
        nodes = [
            _classified(_sf("src/cli.py"), "entry_point"),
            _classified(_sf("src/service.py"), "application"),
        ]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert 'subgraph entry_point_sg["entry_point"]' in content
        assert 'subgraph application_sg["application"]' in content

    def test_subgraph_to_subgraph_edges_default(self, tmp_path: Path) -> None:
        cli_sf = _sf("src/cli.py")
        svc_sf = _sf("src/service.py")
        nodes = [
            _classified(cli_sf, "entry_point", out_degree=1, is_leaf=False),
            _classified(svc_sf, "application", in_degree=1, is_leaf=True),
        ]
        edges = {"src/cli.py": ["src/service.py"]}
        content = _write_and_read(nodes, edges=edges, tmp_path=tmp_path)
        assert "entry_point_sg --> application_sg" in content

    def test_no_individual_edges_in_default_mode(self, tmp_path: Path) -> None:
        cli_sf = _sf("src/cli.py")
        svc_sf = _sf("src/service.py")
        nodes = [
            _classified(cli_sf, "entry_point", out_degree=1, is_leaf=False),
            _classified(svc_sf, "application", in_degree=1, is_leaf=True),
        ]
        edges = {"src/cli.py": ["src/service.py"]}
        content = _write_and_read(nodes, edges=edges, tmp_path=tmp_path)
        # Sanitized node-to-node edge should NOT appear in default mode
        assert "src_cli_py --> src_service_py" not in content

    def test_individual_edges_in_details_mode(self, tmp_path: Path) -> None:
        cli_sf = _sf("src/cli.py")
        svc_sf = _sf("src/service.py")
        nodes = [
            _classified(cli_sf, "entry_point", out_degree=1, is_leaf=False),
            _classified(svc_sf, "application", in_degree=1, is_leaf=False),
        ]
        edges = {"src/cli.py": ["src/service.py"]}
        content = _write_and_read(nodes, edges=edges, details=True, tmp_path=tmp_path)
        assert "src_cli_py --> src_service_py" in content

    def test_test_layer_absent_from_diagram(self, tmp_path: Path) -> None:
        nodes = [
            _classified(_sf("src/cli.py"), "entry_point"),
            _classified(_sf("tests/test_cli.py"), "test"),
        ]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "subgraph test_sg" not in content

    def test_top3_cap_in_default_mode(self, tmp_path: Path) -> None:
        # 5 nodes in the same layer — only top 3 should appear in the subgraph
        nodes = [
            _classified(_sf(f"src/svc_{i}.py"), "application", in_degree=5 - i)
            for i in range(5)
        ]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        # Count node lines inside the application subgraph (lines with ["filename"])
        # Find mermaid block
        mermaid_start = content.index("```mermaid")
        mermaid_end = content.index("```", mermaid_start + 3)
        mermaid_block = content[mermaid_start:mermaid_end]
        # Node lines inside subgraph look like: svc_0_py["svc_0.py"]
        node_lines = [ln for ln in mermaid_block.splitlines() if '["svc_' in ln]
        assert len(node_lines) == 3

    def test_same_layer_edges_not_self_looped(self, tmp_path: Path) -> None:
        # Two nodes in the same layer with an edge between them
        a_sf = _sf("src/a.py")
        b_sf = _sf("src/b.py")
        nodes = [
            _classified(a_sf, "application", out_degree=1, is_leaf=False),
            _classified(b_sf, "application", in_degree=1, is_leaf=False),
        ]
        edges = {"src/a.py": ["src/b.py"]}
        content = _write_and_read(nodes, edges=edges, tmp_path=tmp_path)
        # Self-loop should not appear
        assert "application_sg --> application_sg" not in content

    def test_subgraph_style_directives(self, tmp_path: Path) -> None:
        nodes = [_classified(_sf("src/cli.py"), "entry_point")]
        content = _write_and_read(nodes, tmp_path=tmp_path)
        assert "style entry_point_sg fill:#D6EAF8,stroke:#5B9BD5" in content


# ---------------------------------------------------------------------------
# TestEdgeCases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_empty_graph_does_not_raise(self, tmp_path: Path) -> None:
        g = _graph()
        out = tmp_path / "code-map.md"
        write_map(g, [], out, _ROOT)
        assert out.read_text().startswith("# Code Map")

    def test_output_file_overwritten(self, tmp_path: Path) -> None:
        out = tmp_path / "code-map.md"
        out.write_text("old content")
        nodes = [_classified(_sf("src/a.py"), "application")]
        sfs = [n.file for n in nodes]
        g = _graph(nodes=sfs)
        write_map(g, nodes, out, _ROOT)
        assert out.read_text() != "old content"

    def test_output_parent_dirs_created(self, tmp_path: Path) -> None:
        out = tmp_path / "nested" / "deep" / "code-map.md"
        g = _graph()
        write_map(g, [], out, _ROOT)
        assert out.exists()


# ---------------------------------------------------------------------------
# Multi-resolution helpers (17d)
# ---------------------------------------------------------------------------


def _full_pipeline_and_read(
    nodes: list[ClassifiedNode],
    edges: dict[str, list[str]] | None = None,
    cycles: list[list[str]] | None = None,
    details: bool = False,
    focus: str | None = None,
    tmp_path: Path | None = None,
) -> str:
    """Run the full topology/assessment/chains pipeline and write the map."""
    sfs = [n.file for n in nodes]
    g = _graph(nodes=sfs, edges=edges, cycles=cycles)
    root = _ROOT
    topology = build_directory_topology(g, root)
    assessment = assess_architecture(g, topology)
    chains = build_representative_chains(g, topology, assessment)
    out = (tmp_path or Path("/tmp")) / "code-map.md"
    write_map(
        g,
        nodes,
        out,
        root,
        details=details,
        topology=topology,
        assessment=assessment,
        chains=chains,
        focus=focus,
    )
    return out.read_text(encoding="utf-8")


def _multi_dir_nodes() -> tuple[list[ClassifiedNode], dict[str, list[str]]]:
    """Build a realistic multi-directory fixture with cross-directory edges."""
    cli = _classified(_sf("api/cli.py"), "entry_point", out_degree=2, is_leaf=False)
    routes = _classified(
        _sf("api/routes/user.py"),
        "application",
        in_degree=1,
        out_degree=1,
        is_leaf=False,
    )
    repo = _classified(
        _sf("domain/repos/user_repo.py"),
        "repository",
        in_degree=1,
        out_degree=1,
        is_leaf=False,
    )
    entity = _classified(
        _sf("domain/models/user.py"), "entity", in_degree=2, out_degree=0, is_leaf=True
    )
    nodes = [cli, routes, repo, entity]
    edges = {
        "api/cli.py": ["api/routes/user.py", "domain/models/user.py"],
        "api/routes/user.py": ["domain/repos/user_repo.py"],
        "domain/repos/user_repo.py": ["domain/models/user.py"],
    }
    return nodes, edges


# ---------------------------------------------------------------------------
# TestDefaultMultiResolutionLayout
# ---------------------------------------------------------------------------


class TestDefaultMultiResolutionLayout:
    def test_architecture_summary_present(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        assert "## Architecture Summary" in content

    def test_top_level_dependencies_present(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        assert "## Top-Level Dependencies" in content

    def test_directory_tree_present(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        assert "## Directory Tree" in content

    def test_module_dependencies_present(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        assert "## Module Dependencies" in content

    def test_section_ordering(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        header_pos = content.index("# Code Map")
        summary_pos = content.index("## Architecture Summary")
        tree_pos = content.index("## Directory Tree")
        assert header_pos < summary_pos < tree_pos

    def test_architecture_diagram_present(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        assert "## Architecture Diagram" in content
        assert "```mermaid" in content

    def test_mermaid_uses_elk_layout(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        assert "layout: elk" in content


# ---------------------------------------------------------------------------
# TestLegacySectionsOmittedFromDefault
# ---------------------------------------------------------------------------


class TestLegacySectionsOmittedFromDefault:
    def test_layer_summary_absent(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        assert "## Layer Summary" not in content

    def test_entry_points_section_absent(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        # The old ## Entry Points heading should not appear at the top level
        assert "\n## Entry Points" not in content

    def test_layers_breakdown_absent(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        assert "## Layers Breakdown" not in content

    def test_dependency_edges_absent(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        assert "## Dependency Edges" not in content


# ---------------------------------------------------------------------------
# TestDetailsAppendix
# ---------------------------------------------------------------------------


class TestDetailsAppendix:
    def test_appendix_heading_present(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(
            nodes, edges=edges, details=True, tmp_path=tmp_path
        )
        assert "## Diagnostic Appendix" in content

    def test_layer_summary_in_appendix(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(
            nodes, edges=edges, details=True, tmp_path=tmp_path
        )
        assert "### Layer Summary" in content

    def test_mermaid_in_appendix(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(
            nodes, edges=edges, details=True, tmp_path=tmp_path
        )
        assert "```mermaid" in content

    def test_default_sections_still_present_with_details(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(
            nodes, edges=edges, details=True, tmp_path=tmp_path
        )
        assert "## Architecture Summary" in content
        assert "## Directory Tree" in content


# ---------------------------------------------------------------------------
# TestConditionalCyclesAndHotspots
# ---------------------------------------------------------------------------


class TestConditionalCyclesAndHotspots:
    def test_no_cycles_no_section(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        assert "## Cycles and Hotspots" not in content

    def test_cycles_present_section_rendered(self, tmp_path: Path) -> None:
        a = _classified(_sf("api/a.py"), "application", out_degree=1, is_leaf=False)
        b = _classified(
            _sf("domain/b.py"), "entity", in_degree=1, out_degree=1, is_leaf=False
        )
        nodes = [a, b]
        edges = {"api/a.py": ["domain/b.py"], "domain/b.py": ["api/a.py"]}
        cycles = [["api/a.py", "domain/b.py", "api/a.py"]]
        content = _full_pipeline_and_read(
            nodes, edges=edges, cycles=cycles, tmp_path=tmp_path
        )
        assert "## Cycles and Hotspots" in content
        assert "api/a.py" in content

    def test_file_cycle_shows_full_loop_path(self, tmp_path: Path) -> None:
        # The full loop path must appear in the file cycles section
        a = _classified(_sf("ui/panel.py"), "application", out_degree=1, is_leaf=False)
        b = _classified(
            _sf("app/service.py"),
            "application",
            in_degree=1,
            out_degree=1,
            is_leaf=False,
        )
        c = _classified(
            _sf("commands/run.py"),
            "entry_point",
            in_degree=1,
            out_degree=1,
            is_leaf=False,
        )
        nodes = [a, b, c]
        edges = {
            "ui/panel.py": ["app/service.py"],
            "app/service.py": ["commands/run.py"],
            "commands/run.py": ["ui/panel.py"],
        }
        cycles = [["ui/panel.py", "app/service.py", "commands/run.py", "ui/panel.py"]]
        content = _full_pipeline_and_read(
            nodes, edges=edges, cycles=cycles, tmp_path=tmp_path
        )
        assert (
            "ui/panel.py -> app/service.py -> commands/run.py -> ui/panel.py" in content
        )

    def test_directory_cycles_section_rendered(self, tmp_path: Path) -> None:
        # Directory-level cycles should appear in a ### Directory Cycles subsection
        a = _classified(_sf("ui/panel.py"), "application", out_degree=1, is_leaf=False)
        b = _classified(
            _sf("app/service.py"),
            "application",
            in_degree=1,
            out_degree=1,
            is_leaf=False,
        )
        c = _classified(
            _sf("commands/run.py"),
            "entry_point",
            in_degree=1,
            out_degree=1,
            is_leaf=False,
        )
        nodes = [a, b, c]
        edges = {
            "ui/panel.py": ["app/service.py"],
            "app/service.py": ["commands/run.py"],
            "commands/run.py": ["ui/panel.py"],
        }
        cycles = [["ui/panel.py", "app/service.py", "commands/run.py", "ui/panel.py"]]
        content = _full_pipeline_and_read(
            nodes, edges=edges, cycles=cycles, tmp_path=tmp_path
        )
        assert "### Directory Cycles" in content
        # Should contain one of the directories in the cycle
        dir_cycles_section = content.split("### Directory Cycles")[1].split("###")[0]
        assert "ui" in dir_cycles_section or "app" in dir_cycles_section

    def test_directory_cycles_absent_when_no_dir_cycles(self, tmp_path: Path) -> None:
        # File cycle within a single directory — no directory cycle expected
        a = _classified(_sf("pkg/a.py"), "application", out_degree=1, is_leaf=False)
        b = _classified(
            _sf("pkg/b.py"), "entity", in_degree=1, out_degree=1, is_leaf=False
        )
        nodes = [a, b]
        edges = {"pkg/a.py": ["pkg/b.py"], "pkg/b.py": ["pkg/a.py"]}
        cycles = [["pkg/a.py", "pkg/b.py", "pkg/a.py"]]
        content = _full_pipeline_and_read(
            nodes, edges=edges, cycles=cycles, tmp_path=tmp_path
        )
        # File cycle section may appear, but directory cycles section should not
        assert "### Directory Cycles" not in content


# ---------------------------------------------------------------------------
# TestDirectoryTreeRendering
# ---------------------------------------------------------------------------


class TestDirectoryTreeRendering:
    def test_tree_preserves_all_directories(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        # All top-level dirs from the fixture should appear
        assert "api/" in content
        assert "domain/" in content

    def test_tree_indentation(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        tree_section = content.split("## Directory Tree")[1].split("##")[0]
        # Subdirectories should be indented (start with spaces)
        indented_lines = [ln for ln in tree_section.splitlines() if ln.startswith("  ")]
        assert len(indented_lines) > 0

    def test_tree_wrapped_in_code_block(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        tree_section = content.split("## Directory Tree")[1].split("##")[0]
        assert "```" in tree_section


# ---------------------------------------------------------------------------
# TestChainsRendering
# ---------------------------------------------------------------------------


class TestChainsRendering:
    def test_chain_files_listed(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        # Chains section should contain file paths
        if "## Representative Chains" in content:
            after = content.split("## Representative Chains")[1]
            # Grab only up to the next level-2 heading
            next_h2 = after.find("\n## ")
            chains_section = after[:next_h2] if next_h2 >= 0 else after
            assert "api/" in chains_section or "domain/" in chains_section

    def test_empty_chains_section_absent(self, tmp_path: Path) -> None:
        # A graph with no entry files and no leaf files produces no chains
        node = _classified(
            _sf("src/lone.py"), "unknown", in_degree=0, out_degree=0, is_leaf=True
        )
        content = _full_pipeline_and_read([node], tmp_path=tmp_path)
        assert "## Representative Chains" not in content


# ---------------------------------------------------------------------------
# TestBacktickFormatting
# ---------------------------------------------------------------------------


class TestBacktickFormatting:
    def test_chains_file_paths_have_backticks(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        if "## Representative Chains" in content:
            after = content.split("## Representative Chains")[1]
            next_h2 = after.find("\n## ")
            section = after[:next_h2] if next_h2 >= 0 else after
            files_lines = [ln for ln in section.splitlines() if ln.startswith("Files:")]
            assert files_lines, "Expected at least one 'Files:' line in chains"
            for line in files_lines:
                assert "`" in line

    def test_top_level_deps_have_backticks(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        if "## Top-Level Dependencies" in content:
            after = content.split("## Top-Level Dependencies")[1]
            next_h2 = after.find("\n## ")
            section = after[:next_h2] if next_h2 >= 0 else after
            dep_lines = [ln for ln in section.splitlines() if "->" in ln]
            assert dep_lines
            for line in dep_lines:
                assert "`" in line

    def test_module_deps_have_backticks(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        if "## Module Dependencies" in content:
            after = content.split("## Module Dependencies")[1]
            next_h2 = after.find("\n## ")
            section = after[:next_h2] if next_h2 >= 0 else after
            dep_lines = [ln for ln in section.splitlines() if "->" in ln]
            assert dep_lines
            for line in dep_lines:
                assert "`" in line


# ---------------------------------------------------------------------------
# TestTopologyMermaidDiagram (story 17g)
# ---------------------------------------------------------------------------


class TestTopologyMermaidDiagram:
    """The default Architecture Diagram is rendered from topology, not DDD layers."""

    def _diagram(self, content: str) -> str:
        """Extract the mermaid Architecture Diagram section."""
        if "## Architecture Diagram" not in content:
            return ""
        after = content.split("## Architecture Diagram")[1]
        next_h2 = after.find("\n## ")
        return after[:next_h2] if next_h2 >= 0 else after

    def test_no_ddd_layer_names_in_default_output(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        diagram = self._diagram(content)
        assert "unknown_sg" not in diagram
        assert "entry_point_sg" not in diagram
        assert "application_sg" not in diagram
        assert "repository_sg" not in diagram

    def test_subgraph_uses_directory_name(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        diagram = self._diagram(content)
        assert 'subgraph api["api"]' in diagram
        assert 'subgraph domain["domain"]' in diagram

    def test_edges_come_from_topology(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        diagram = self._diagram(content)
        assert "api --> domain" in diagram

    def test_root_sentinel_absent(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        diagram = self._diagram(content)
        assert 'subgraph [""]' not in diagram
        assert '"(root)"' not in diagram

    def test_sanitized_subgraph_id_no_slashes(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        diagram = self._diagram(content)
        sg_ids = re.findall(r"subgraph (\S+)\[", diagram)
        for sg_id in sg_ids:
            assert "/" not in sg_id, f"Subgraph ID contains slash: {sg_id!r}"

    def test_no_diagram_when_no_cross_dir_edges(self, tmp_path: Path) -> None:
        # All edges are intra-directory — no cross-dir flow
        n1 = _classified(_sf("api/a.py"), "entry_point", out_degree=1, is_leaf=False)
        n2 = _classified(_sf("api/b.py"), "unknown", in_degree=1, is_leaf=True)
        edges: dict[str, list[str]] = {"api/a.py": ["api/b.py"]}
        content = _full_pipeline_and_read([n1, n2], edges=edges, tmp_path=tmp_path)
        assert "## Architecture Diagram" not in content

    def test_entry_dir_gets_entry_color(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        sfs = [n.file for n in nodes]
        g = _graph(nodes=sfs, edges=edges)
        topology = build_directory_topology(g, _ROOT)
        assessment = assess_architecture(g, topology)
        chains = build_representative_chains(g, topology, assessment)
        out = tmp_path / "code-map.md"
        write_map(
            g,
            nodes,
            out,
            _ROOT,
            topology=topology,
            assessment=assessment,
            chains=chains,
        )
        content = out.read_text(encoding="utf-8")
        diagram = self._diagram(content)
        assert assessment.entry_directories, "Fixture must have entry directories"
        for sig in assessment.entry_directories:
            sg_id = re.sub(r"[/.\-]", "_", sig.directory)
            assert f"style {sg_id} fill:#D6EAF8" in diagram

    def test_core_dir_gets_core_color(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        sfs = [n.file for n in nodes]
        g = _graph(nodes=sfs, edges=edges)
        topology = build_directory_topology(g, _ROOT)
        assessment = assess_architecture(g, topology)
        chains = build_representative_chains(g, topology, assessment)
        out = tmp_path / "code-map.md"
        write_map(
            g,
            nodes,
            out,
            _ROOT,
            topology=topology,
            assessment=assessment,
            chains=chains,
        )
        content = out.read_text(encoding="utf-8")
        diagram = self._diagram(content)
        assert assessment.core_directories, "Fixture must have core directories"
        for sig in assessment.core_directories:
            sg_id = re.sub(r"[/.\-]", "_", sig.directory)
            assert f"style {sg_id} fill:#D5F5E3" in diagram

    def test_other_dir_gets_other_color(self, tmp_path: Path) -> None:
        # Add a third directory that is neither entry nor core (bidirectional) so it falls into "other"
        n_cmd = _classified(
            _sf("cmd/run.py"), "entry_point", out_degree=1, is_leaf=False
        )
        n_svc = _classified(
            _sf("svc/handler.py"), "unknown", in_degree=1, out_degree=1, is_leaf=False
        )
        n_ext = _classified(
            _sf("ext/client.py"), "unknown", in_degree=1, out_degree=1, is_leaf=False
        )
        n_lib = _classified(_sf("lib/util.py"), "unknown", in_degree=1, is_leaf=True)
        extra_nodes = [n_cmd, n_svc, n_ext, n_lib]
        extra_edges = {
            "cmd/run.py": ["svc/handler.py"],
            "svc/handler.py": ["ext/client.py"],
            "ext/client.py": ["lib/util.py"],
        }
        sfs = [n.file for n in extra_nodes]
        g = _graph(nodes=sfs, edges=extra_edges)
        topology = build_directory_topology(g, _ROOT)
        assessment = assess_architecture(g, topology)
        chains = build_representative_chains(g, topology, assessment)
        out = tmp_path / "code-map.md"
        write_map(
            g,
            extra_nodes,
            out,
            _ROOT,
            topology=topology,
            assessment=assessment,
            chains=chains,
        )
        content = out.read_text(encoding="utf-8")
        diagram = self._diagram(content)
        # svc and ext are neither entry (have in-edges) nor core (have out-edges) — they’re "other"
        other_dirs = {
            d
            for d in ("svc", "ext")
            if d not in {s.directory for s in assessment.entry_directories}
            and d not in {s.directory for s in assessment.core_directories}
            and d not in set(assessment.leaf_directories)
        }
        assert other_dirs, "Fixture must produce at least one 'other' directory"
        for d in other_dirs:
            sg_id = re.sub(r"[/.\-]", "_", d)
            assert f"style {sg_id} fill:#FEF9E7" in diagram

    def test_no_file_nodes_in_default_diagram(self, tmp_path: Path) -> None:
        # Default topology Mermaid shows directory nodes only — no individual file IDs
        svc_files = [
            _classified(_sf(f"svc/file{i}.py"), "unknown", is_leaf=True)
            for i in range(4)
        ]
        entry = _classified(
            _sf("cmd/main.py"), "entry_point", out_degree=1, is_leaf=False
        )
        edges: dict[str, list[str]] = {"cmd/main.py": ["svc/file0.py"]}
        content = _full_pipeline_and_read(
            [entry] + svc_files, edges=edges, tmp_path=tmp_path
        )
        diagram = self._diagram(content)
        # No individual file node IDs should appear in the topology diagram
        svc_file_ids = [f"svc_file{i}_py" for i in range(4)]
        shown = sum(1 for fid in svc_file_ids if fid in diagram)
        assert shown == 0, f"Expected no file nodes in default diagram, got {shown}"

    def test_ddd_layer_names_still_in_details_appendix(self, tmp_path: Path) -> None:
        # _build_mermaid(details=True) is still called from _render_details_appendix,
        # so DDD layer names should appear in the appendix when --details is used.
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(
            nodes, edges=edges, details=True, tmp_path=tmp_path
        )
        appendix = (
            content.split("## Diagnostic Appendix")[1]
            if "## Diagnostic Appendix" in content
            else ""
        )
        # The appendix contains the legacy mermaid with DDD layer names
        assert any(
            name in appendix
            for name in (
                "entry_point_sg",
                "application_sg",
                "repository_sg",
                "entity_sg",
            )
        )


    def test_no_parent_child_subgraph_edges(self, tmp_path: Path) -> None:
        """Parent→child subgraph edges must not appear in the Architecture Diagram.

        Regression guard: when api/cli.py (in api/) imports api/routes/user.py (in
        api/routes/), the topology records an edge api -> api/routes.  Without the
        fix this was emitted as ``api --> api_routes``, which Mermaid cannot render
        because it does not support edges between a parent and its own nested children.
        """
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        diagram = self._diagram(content)
        assert "api --> api_routes" not in diagram

    def test_no_ancestor_descendant_edges_invariant(self, tmp_path: Path) -> None:
        """No edge in the Architecture Diagram connects a subgraph to any ancestor or descendant.

        Parses the actual mermaid nesting structure so this catches any future
        regression regardless of which directories are involved.
        """
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        diagram = self._diagram(content)

        # Build parent_of map by parsing the nested subgraph declarations
        stack: list[str] = []
        parent_of: dict[str, str | None] = {}
        for line in diagram.splitlines():
            m = re.match(r"\s*subgraph (\S+)\[", line)
            if m:
                sg_id = m.group(1)
                parent_of[sg_id] = stack[-1] if stack else None
                stack.append(sg_id)
            elif line.strip() == "end" and stack:
                stack.pop()

        def is_ancestor(sg_id: str, candidate: str) -> bool:
            current: str | None = parent_of.get(sg_id)
            while current is not None:
                if current == candidate:
                    return True
                current = parent_of.get(current)
            return False

        edge_re = re.compile(r"^\s*(\w+)\s+-->\s+(\w+)\s*$")
        violations: list[str] = []
        for line in diagram.splitlines():
            m = edge_re.match(line)
            if not m:
                continue
            src_id, tgt_id = m.group(1), m.group(2)
            if is_ancestor(tgt_id, src_id):
                violations.append(f"{src_id} --> {tgt_id}  (parent→child)")
            if is_ancestor(src_id, tgt_id):
                violations.append(f"{src_id} --> {tgt_id}  (child→parent)")

        assert not violations, (
            "Ancestor/descendant subgraph edges found — Mermaid cannot render them:\n"
            + "\n".join(violations)
        )


class TestFocusDrilldown:
    """Tests for --focus drill-down section."""

    def test_focus_section_present(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(
            nodes, edges=edges, focus="api", tmp_path=tmp_path
        )
        assert "## Focus: api" in content

    def test_focus_absent_when_not_specified(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(nodes, edges=edges, tmp_path=tmp_path)
        assert "## Focus:" not in content

    def test_focus_mermaid_has_file_nodes(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(
            nodes, edges=edges, focus="api", tmp_path=tmp_path
        )
        # Focus section should contain file-level node IDs from api/
        assert "api_cli_py" in content or "api_routes_user_py" in content

    def test_focus_shows_external_directory_nodes(self, tmp_path: Path) -> None:
        # api depends on domain, so domain should appear as external node in focus
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(
            nodes, edges=edges, focus="api", tmp_path=tmp_path
        )
        focus_part = (
            content.split("## Focus: api")[1] if "## Focus: api" in content else ""
        )
        # domain should appear as an external reference
        assert "domain" in focus_part

    def test_focus_outbound_dependencies_listed(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(
            nodes, edges=edges, focus="api", tmp_path=tmp_path
        )
        focus_part = (
            content.split("## Focus: api")[1] if "## Focus: api" in content else ""
        )
        assert "Outbound dependencies" in focus_part

    def test_global_diagram_still_present_with_focus(self, tmp_path: Path) -> None:
        # Global architecture diagram must still appear alongside the focus section
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_and_read(
            nodes, edges=edges, focus="api", tmp_path=tmp_path
        )
        assert "## Architecture Diagram" in content
        assert "## Focus: api" in content


# ---------------------------------------------------------------------------
# Helpers for enrichment section tests
# ---------------------------------------------------------------------------


def _full_pipeline_with_enrichment(
    nodes: list[ClassifiedNode],
    edges: dict[str, list[str]] | None = None,
    ext_deps: list[ExternalDependencySummary] | None = None,
    responsibilities: list[ResponsibilitySummary] | None = None,
    coverage: list[CoverageRecord] | None = None,
    tmp_path: Path | None = None,
) -> str:
    """Run full pipeline and pass enrichment data to write_map."""
    sfs = [n.file for n in nodes]
    g = _graph(nodes=sfs, edges=edges)
    root = _ROOT
    topology = build_directory_topology(g, root)
    assessment = assess_architecture(g, topology)
    chains = build_representative_chains(g, topology, assessment)
    out = (tmp_path or Path("/tmp")) / "code-map.md"
    write_map(
        g,
        nodes,
        out,
        root,
        topology=topology,
        assessment=assessment,
        chains=chains,
        ext_deps=ext_deps,
        responsibilities=responsibilities,
        coverage=coverage,
    )
    return out.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# TestExternalDependenciesSection
# ---------------------------------------------------------------------------


class TestExternalDependenciesSection:
    def test_section_present_when_data_provided(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        ext_deps = [ExternalDependencySummary(directory="api", packages=("fastapi", "uvicorn"))]
        content = _full_pipeline_with_enrichment(
            nodes, edges=edges, ext_deps=ext_deps, tmp_path=tmp_path
        )
        assert "## External Dependencies" in content
        assert "fastapi" in content
        assert "uvicorn" in content

    def test_section_absent_when_none(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_with_enrichment(nodes, edges=edges, tmp_path=tmp_path)
        assert "## External Dependencies" not in content

    def test_section_absent_when_empty_list(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_with_enrichment(
            nodes, edges=edges, ext_deps=[], tmp_path=tmp_path
        )
        assert "## External Dependencies" not in content

    def test_directory_label_shown(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        ext_deps = [ExternalDependencySummary(directory="domain/repos", packages=("sqlalchemy",))]
        content = _full_pipeline_with_enrichment(
            nodes, edges=edges, ext_deps=ext_deps, tmp_path=tmp_path
        )
        assert "domain/repos" in content
        assert "sqlalchemy" in content


# ---------------------------------------------------------------------------
# TestResponsibilitiesSection
# ---------------------------------------------------------------------------


class TestResponsibilitiesSection:
    def test_section_present_when_data_provided(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        responsibilities = [
            ResponsibilitySummary(directory="api", summary="API layer"),
            ResponsibilitySummary(directory="domain", summary="Domain model"),
        ]
        content = _full_pipeline_with_enrichment(
            nodes, edges=edges, responsibilities=responsibilities, tmp_path=tmp_path
        )
        assert "## Module Responsibilities" in content
        assert "API layer" in content
        assert "Domain model" in content

    def test_section_absent_when_none(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_with_enrichment(nodes, edges=edges, tmp_path=tmp_path)
        assert "## Module Responsibilities" not in content

    def test_section_absent_when_empty_list(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_with_enrichment(
            nodes, edges=edges, responsibilities=[], tmp_path=tmp_path
        )
        assert "## Module Responsibilities" not in content


# ---------------------------------------------------------------------------
# TestStructuralCoverageSection
# ---------------------------------------------------------------------------


class TestStructuralCoverageSection:
    def test_section_present_when_data_provided(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        coverage = [
            CoverageRecord(
                module="api", evidence="strong", test_files=("tests/test_api.py",)
            ),
        ]
        content = _full_pipeline_with_enrichment(
            nodes, edges=edges, coverage=coverage, tmp_path=tmp_path
        )
        assert "## Structural Test Coverage" in content

    def test_section_absent_when_none(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_with_enrichment(nodes, edges=edges, tmp_path=tmp_path)
        assert "## Structural Test Coverage" not in content

    def test_section_absent_when_empty_list(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        content = _full_pipeline_with_enrichment(
            nodes, edges=edges, coverage=[], tmp_path=tmp_path
        )
        assert "## Structural Test Coverage" not in content

    def test_strong_evidence_shown(self, tmp_path: Path) -> None:
        nodes, edges = _multi_dir_nodes()
        coverage = [
            CoverageRecord(
                module="api",
                evidence="strong",
                test_files=("tests/test_api.py",),
            )
        ]
        content = _full_pipeline_with_enrichment(
            nodes, edges=edges, coverage=coverage, tmp_path=tmp_path
        )
        assert "Strong Coverage" in content
        assert "tests/test_api.py" in content

    def test_fallback_evidence_labeled(self, tmp_path: Path) -> None:
        """Fallback coverage is labeled with '(name-based)'."""
        nodes, edges = _multi_dir_nodes()
        coverage = [
            CoverageRecord(
                module="domain",
                evidence="fallback",
                test_files=("tests/test_domain.py",),
            )
        ]
        content = _full_pipeline_with_enrichment(
            nodes, edges=edges, coverage=coverage, tmp_path=tmp_path
        )
        assert "name-based" in content

    def test_no_evidence_section_present(self, tmp_path: Path) -> None:
        """Modules with no evidence appear in 'No Test Evidence Detected' subsection."""
        nodes, edges = _multi_dir_nodes()
        coverage = [
            CoverageRecord(module="api", evidence="none", test_files=())
        ]
        content = _full_pipeline_with_enrichment(
            nodes, edges=edges, coverage=coverage, tmp_path=tmp_path
        )
        assert "No Test Evidence Detected" in content

    def test_summary_counts_present(self, tmp_path: Path) -> None:
        """Coverage section header includes count totals."""
        nodes, edges = _multi_dir_nodes()
        coverage = [
            CoverageRecord(module="api", evidence="strong", test_files=("tests/test_api.py",)),
            CoverageRecord(module="domain", evidence="fallback", test_files=("tests/test_domain.py",)),
            CoverageRecord(module="infra", evidence="none", test_files=()),
        ]
        content = _full_pipeline_with_enrichment(
            nodes, edges=edges, coverage=coverage, tmp_path=tmp_path
        )
        assert "1" in content  # ≥ one count present in the summary line
        assert "Summary:" in content

    def test_all_three_enrichment_sections_together(self, tmp_path: Path) -> None:
        """All three enrichment sections can appear together in one report."""
        nodes, edges = _multi_dir_nodes()
        ext_deps = [ExternalDependencySummary(directory="api", packages=("fastapi",))]
        responsibilities = [ResponsibilitySummary(directory="api", summary="API layer")]
        coverage = [CoverageRecord(module="api", evidence="strong", test_files=("tests/test_api.py",))]
        content = _full_pipeline_with_enrichment(
            nodes,
            edges=edges,
            ext_deps=ext_deps,
            responsibilities=responsibilities,
            coverage=coverage,
            tmp_path=tmp_path,
        )
        assert "## External Dependencies" in content
        assert "## Module Responsibilities" in content
        assert "## Structural Test Coverage" in content

