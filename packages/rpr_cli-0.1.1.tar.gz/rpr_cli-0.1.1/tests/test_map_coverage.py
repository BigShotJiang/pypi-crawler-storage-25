"""Tests for src/rpr/map/coverage.py."""

from __future__ import annotations

from pathlib import Path

from rpr.map.classifier import ClassifiedNode
from rpr.map.coverage import build_coverage_map
from rpr.map.graph import DependencyGraph
from rpr.map.topology import build_directory_topology
from rpr.map.walker import SourceFile

_ROOT = Path("/fake/root")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _sf(rel: str, language: str = "python") -> SourceFile:
    p = Path(rel)
    return SourceFile(abs_path=_ROOT / p, rel_path=p, language=language)


def _graph(
    nodes: list[SourceFile],
    edges: dict[str, list[str]] | None = None,
) -> DependencyGraph:
    edges = edges or {}
    rev: dict[str, list[str]] = {}
    for src, deps in edges.items():
        for dep in deps:
            rev.setdefault(dep, []).append(src)
    return DependencyGraph(
        nodes=nodes,
        edges=edges,
        reverse_edges=rev,
        cycles=[],
        backend="python-fallback",
    )


def _classified(sf: SourceFile, layer: str) -> ClassifiedNode:
    return ClassifiedNode(file=sf, layer=layer, is_leaf=True, in_degree=0, out_degree=0)


def _coverage_map(nodes_and_layers: list[tuple[SourceFile, str]], edges: dict[str, list[str]] | None = None):
    sfs = [sf for sf, _ in nodes_and_layers]
    g = _graph(sfs, edges)
    classified = [_classified(sf, layer) for sf, layer in nodes_and_layers]
    topology = build_directory_topology(g, _ROOT)
    return build_coverage_map(g, classified, topology)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestBuildCoverageMap:

    def test_strong_evidence_via_import_edge(self):
        """Test file with edge to production file → strong evidence."""
        prod = _sf("src/app.py")
        test = _sf("tests/test_app.py")
        result = _coverage_map(
            [(prod, "application"), (test, "test")],
            edges={"tests/test_app.py": ["src/app.py"]},
        )
        rec = next((r for r in result if r.module == "src"), None)
        assert rec is not None
        assert rec.evidence == "strong"
        assert "tests/test_app.py" in rec.test_files

    def test_fallback_evidence_via_naming(self):
        """test_<stem> uniquely mapping to one production file → fallback evidence."""
        prod = _sf("src/walker.py")
        test = _sf("tests/test_walker.py")
        # No edge, only name-based matching
        result = _coverage_map([(prod, "application"), (test, "test")])
        rec = next((r for r in result if r.module == "src"), None)
        assert rec is not None
        assert rec.evidence == "fallback"
        assert "tests/test_walker.py" in rec.test_files

    def test_no_evidence_when_unrelated(self):
        """Production file with no test import or matching test stem → none."""
        prod = _sf("src/obscure_logic.py")
        test = _sf("tests/test_other.py")
        result = _coverage_map([(prod, "application"), (test, "test")])
        rec = next((r for r in result if r.module == "src"), None)
        assert rec is not None
        assert rec.evidence == "none"

    def test_ambiguous_stem_match_produces_no_fallback(self):
        """When test_X matches two production files, no false positive."""
        prod_a = _sf("pkg/walker.py")
        prod_b = _sf("utils/walker.py")  # same stem "walker" in different dir
        test = _sf("tests/test_walker.py")
        # Two production files share the stem "walker" → no unique match → fallback not granted
        result = _coverage_map([(prod_a, "application"), (prod_b, "application"), (test, "test")])
        # Neither pkg nor utils should get fallback from test_walker when ambiguous
        ambiguous_dirs = {"pkg", "utils"}
        for rec in result:
            if rec.module in ambiguous_dirs:
                assert rec.evidence == "none", (
                    f"{rec.module} should not have fallback evidence due to ambiguous stem"
                )

    def test_test_files_not_in_production_modules(self):
        """Test directories should not appear in coverage records as production modules."""
        prod = _sf("src/service.py")
        test = _sf("tests/test_service.py")
        result = _coverage_map(
            [(prod, "application"), (test, "test")],
            edges={"tests/test_service.py": ["src/service.py"]},
        )
        modules = {r.module for r in result}
        assert "tests" not in modules

    def test_strong_beats_fallback(self):
        """If a directory has both strong and fallback evidence, strong wins."""
        prod_a = _sf("src/service.py")
        prod_b = _sf("src/models.py")
        test_strong = _sf("tests/test_strong.py")
        test_fallback = _sf("tests/test_models.py")
        result = _coverage_map(
            [
                (prod_a, "application"),
                (prod_b, "application"),
                (test_strong, "test"),
                (test_fallback, "test"),
            ],
            edges={"tests/test_strong.py": ["src/service.py"]},
        )
        rec = next((r for r in result if r.module == "src"), None)
        assert rec is not None
        assert rec.evidence == "strong"

    def test_empty_graph_returns_empty(self):
        """An empty graph produces no coverage records."""
        g = _graph([])
        result = build_coverage_map(g, [], build_directory_topology(g, _ROOT))
        assert result == []

    def test_sorted_by_module(self):
        """Results are sorted by module path."""
        prod_z = _sf("zzz/main.py")
        prod_a = _sf("aaa/main.py")
        result = _coverage_map([(prod_z, "application"), (prod_a, "application")])
        modules = [r.module for r in result]
        assert modules == sorted(modules)

    def test_multiple_test_files_aggregated(self):
        """Multiple test files covering the same production dir are all recorded."""
        prod = _sf("src/service.py")
        test1 = _sf("tests/test_service_a.py")
        test2 = _sf("tests/test_service_b.py")
        result = _coverage_map(
            [(prod, "application"), (test1, "test"), (test2, "test")],
            edges={
                "tests/test_service_a.py": ["src/service.py"],
                "tests/test_service_b.py": ["src/service.py"],
            },
        )
        rec = next((r for r in result if r.module == "src"), None)
        assert rec is not None
        assert "tests/test_service_a.py" in rec.test_files
        assert "tests/test_service_b.py" in rec.test_files

    def test_root_directory_production_files(self):
        """Production files at root level (no parent directory) are covered."""
        prod = _sf("service.py")
        test = _sf("test_service.py")
        result = _coverage_map(
            [(prod, "application"), (test, "test")],
            edges={"test_service.py": ["service.py"]},
        )
        rec = next((r for r in result if r.module == ""), None)
        assert rec is not None
        assert rec.evidence == "strong"
