from pathlib import Path


def test_rpr_parser_stub_exists_with_expected_api():
    stub_path = Path(__file__).resolve().parents[1] / "rpr-parser" / "rpr_parser.pyi"

    assert stub_path.exists()

    stub = stub_path.read_text()

    assert "class DependencyGraphPayload(TypedDict):" in stub
    assert "def build_dependency_graph(abs_root: str) -> DependencyGraphPayload: ..." in stub