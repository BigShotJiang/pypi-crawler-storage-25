from __future__ import annotations

from rpr.application.completer import (
    FileContextCompleter,
    SlashCommandCandidate,
    SlashCommandCompleter,
)
from rpr.application.selector import (
    TriggerSelector,
    TriggerSelectorCandidate,
    TriggerSelectorSource,
)


def _selector(names: list[str]) -> TriggerSelector:
    completer = SlashCommandCompleter(
        [
            SlashCommandCandidate(
                name=name, description=f"{name} desc", usage=f"/{name}"
            )
            for name in names
        ]
    )
    selector = TriggerSelector([completer.selector_source])
    return selector


def test_selector_opens_for_bare_slash():
    snapshot = _selector(["help", "settings", "sync"]).snapshot("/", 1)

    assert snapshot.visible is True
    assert [candidate.value for candidate in snapshot.matches] == [
        "help",
        "settings",
        "sync",
    ]
    assert snapshot.selected_candidate is not None
    assert snapshot.selected_candidate.value == "help"


def test_selector_filters_incrementally():
    snapshot = _selector(["help", "settings", "sync"]).snapshot("/se", 3)

    assert snapshot.visible is True
    assert [candidate.value for candidate in snapshot.matches] == ["settings"]


def test_selector_hides_when_query_exactly_matches_command():
    snapshot = _selector(["exit", "help"]).snapshot("/exit", len("/exit"))

    assert snapshot.visible is False
    assert [candidate.value for candidate in snapshot.matches] == ["exit"]


def test_selector_stays_hidden_for_non_trigger_text():
    snapshot = _selector(["help"]).snapshot("hello", 5)

    assert snapshot.visible is False
    assert snapshot.matches == ()


def test_selector_closes_after_command_token_is_complete():
    snapshot = _selector(["settings"]).snapshot("/settings list", len("/settings list"))

    assert snapshot.visible is False


def test_selector_navigation_wraps_through_matches():
    selector = _selector(["help", "settings", "sync"])

    selector.move_selection("/", 1, step=1)
    snapshot = selector.snapshot("/", 1)
    assert snapshot.selected_candidate is not None
    assert snapshot.selected_candidate.value == "settings"

    selector.move_selection("/", 1, step=-1)
    snapshot = selector.snapshot("/", 1)
    assert snapshot.selected_candidate is not None
    assert snapshot.selected_candidate.value == "help"

    selector.move_selection("/", 1, step=-1)
    snapshot = selector.snapshot("/", 1)
    assert snapshot.selected_candidate is not None
    assert snapshot.selected_candidate.value == "sync"


def test_selector_apply_selection_inserts_command_text():
    selector = _selector(["settings"])

    application = selector.apply_selection("/se", 3)

    assert application is not None
    assert application.text == "/settings "
    assert application.cursor_position == len("/settings ")


def test_selector_dismiss_hides_until_query_changes():
    selector = _selector(["settings", "sync"])

    selector.dismiss("/s", 2)
    dismissed_snapshot = selector.snapshot("/s", 2)
    changed_snapshot = selector.snapshot("/sy", 3)

    assert dismissed_snapshot.visible is False
    assert changed_snapshot.visible is True
    assert [candidate.value for candidate in changed_snapshot.matches] == ["sync"]


def test_selector_supports_inline_file_trigger(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "main.py").write_text("# python")
    selector = TriggerSelector([FileContextCompleter(tmp_path).selector_source])

    snapshot = selector.snapshot("Explain @sr", len("Explain @sr"))

    assert snapshot.visible is True
    assert snapshot.query == "sr"
    assert snapshot.replacement_start == len("Explain ")
    assert [candidate.value for candidate in snapshot.matches] == [
        "src/",
        "src/main.py",
    ]


def test_selector_keeps_directory_match_visible_for_navigation():
    selector = TriggerSelector(
        [
            TriggerSelectorSource(
                trigger="@",
                anchored_to_start=False,
                hide_on_exact_match=True,
                case_sensitive=False,
                candidates=(
                    TriggerSelectorCandidate(
                        value="src/",
                        label="src/",
                        description="Directory",
                        insert_text="@src/",
                        keep_open_on_exact_match=True,
                    ),
                    TriggerSelectorCandidate(
                        value="src/main.py",
                        label="src/main.py",
                        description="File",
                        insert_text="@src/main.py",
                    ),
                ),
            )
        ]
    )

    snapshot = selector.snapshot("Explain @src/", len("Explain @src/"))

    assert snapshot.visible is True
    assert [candidate.value for candidate in snapshot.matches] == [
        "src/",
        "src/main.py",
    ]


def test_selector_hides_when_file_query_exactly_matches_path(tmp_path):
    (tmp_path / "README.md").write_text("# readme")
    selector = TriggerSelector([FileContextCompleter(tmp_path).selector_source])

    snapshot = selector.snapshot("Explain @README.md", len("Explain @README.md"))

    assert snapshot.visible is False


def test_selector_file_matching_is_case_insensitive(tmp_path):
    (tmp_path / "README.md").write_text("# readme")
    selector = TriggerSelector([FileContextCompleter(tmp_path).selector_source])

    snapshot = selector.snapshot("Explain @r", len("Explain @r"))

    assert snapshot.visible is True
    assert [candidate.value for candidate in snapshot.matches] == ["README.md"]


def test_selector_apply_selection_replaces_inline_file_token(tmp_path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "main.py").write_text("# python")
    selector = TriggerSelector([FileContextCompleter(tmp_path).selector_source])

    application = selector.apply_selection("Explain @sr please", len("Explain @sr"))

    assert application is not None
    assert application.text == "Explain @src/ please"
    assert application.cursor_position == len("Explain @src/")
