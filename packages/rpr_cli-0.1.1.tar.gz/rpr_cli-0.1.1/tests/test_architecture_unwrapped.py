from __future__ import annotations

from pathlib import Path

from rpr.map.architecture import assess_architecture
from rpr.map.graph import DependencyGraph
from rpr.map.topology import build_directory_topology
from rpr.map.walker import SourceFile

_ROOT = Path("/fake/root")


def _sf(rel: str, language: str = "python") -> SourceFile:
    p = Path(rel)
    return SourceFile(abs_path=_ROOT / p, rel_path=p, language=language)  # type: ignore[arg-type]


def _assess(
    nodes: list[SourceFile],
    edges: dict[str, list[str]] | None = None,
    cycles: list[list[str]] | None = None,
) -> any:
    edges = edges or {}
    reverse: dict[str, list[str]] = {}
    for src, deps in edges.items():
        for dep in deps:
            reverse.setdefault(dep, []).append(src)
    graph = DependencyGraph(
        nodes=nodes,
        edges=edges,
        reverse_edges=reverse,
        cycles=cycles or [],
        backend="python-fallback",
    )
    topology = build_directory_topology(graph, _ROOT)
    return assess_architecture(graph, topology)


def test_unwrapped_src_is_likely_onion() -> None:
    # top_dirs after unwrapping: {"src/api", "src/domain", "tests"}
    # Flow: tests -> src/api -> src/domain
    # tests: in=0, out=1  => entry
    # src/api: in=1, out=1 => neither entry nor core
    # src/domain: in=1, out=0 => core
    nodes = [
        _sf("src/api/routes/user.py"),
        _sf("src/domain/models/user.py"),
        _sf("tests/test_user.py"),
    ]
    edges = {
        "src/api/routes/user.py": ["src/domain/models/user.py"],
        "tests/test_user.py": ["src/api/routes/user.py"],
    }
    a = _assess(nodes, edges)

    assert a.verdict == "likely_onion"

    entry_dirs = [s.directory for s in a.entry_directories]
    core_dirs = [s.directory for s in a.core_directories]

    assert "tests" in entry_dirs
    assert "src/domain" in core_dirs
    assert "src" not in entry_dirs
    assert "src" not in core_dirs


def test_src_is_not_a_hotspot_if_unwrapped() -> None:
    # After unwrapping, top_dirs = {src/pkg0, ..., src/pkg4, a, b, c}
    # Each has exactly 1 file — no hotspots.
    nodes = [_sf(f"src/pkg{i}/f.py") for i in range(5)]
    nodes += [_sf("a/x.py"), _sf("b/y.py"), _sf("c/z.py")]

    a = _assess(nodes)

    hotspot_dirs = [h.directory for h in a.hotspots]
    assert "src" not in hotspot_dirs
    assert len(a.hotspots) == 0


def test_non_wrapper_dir_not_unwrapped() -> None:
    # "api" is not in _WRAPPER_NAMES, so it should not be unwrapped
    # even though it has children.
    nodes = [
        _sf("api/routes/user.py"),
        _sf("api/routes/order.py"),
        _sf("tests/test_user.py"),
    ]
    edges = {"tests/test_user.py": ["api/routes/user.py"]}
    a = _assess(nodes, edges)

    all_dirs = (
        [s.directory for s in a.entry_directories]
        + [s.directory for s in a.core_directories]
        + a.leaf_directories
    )
    # "api" stays as a single top-level dir; "api/routes" should not appear
    assert "api" in all_dirs
    assert "api/routes" not in all_dirs


def test_wrapper_with_no_children_not_unwrapped() -> None:
    # src/ contains only direct files, no subdirectories — should NOT be unwrapped.
    nodes = [
        _sf("src/a.py"),
        _sf("src/b.py"),
    ]
    edges = {"src/a.py": ["src/b.py"]}
    a = _assess(nodes, edges)

    # src remains the only top-level dir; verdict is unclear (only 1 dir)
    assert a.verdict == "unclear"
    all_dirs = (
        [s.directory for s in a.entry_directories]
        + [s.directory for s in a.core_directories]
        + a.leaf_directories
    )
    assert "src" in all_dirs


def test_multiple_wrappers_unwrapped() -> None:
    # Both "src" and "packages" are wrappers with children — both unwrapped.
    nodes = [
        _sf("src/api/a.py"),
        _sf("packages/utils/b.py"),
    ]
    edges = {"src/api/a.py": ["packages/utils/b.py"]}
    a = _assess(nodes, edges)

    entry_dirs = [s.directory for s in a.entry_directories]
    core_dirs = [s.directory for s in a.core_directories]

    assert "src/api" in entry_dirs
    assert "packages/utils" in core_dirs
    assert "src" not in entry_dirs + core_dirs
    assert "packages" not in entry_dirs + core_dirs


def test_edges_between_unwrapped_and_regular() -> None:
    # Edge from tests (regular) to src/api (unwrapped child) is correctly reported.
    nodes = [
        _sf("src/api/handler.py"),
        _sf("tests/test_handler.py"),
    ]
    edges = {"tests/test_handler.py": ["src/api/handler.py"]}
    a = _assess(nodes, edges)

    entry_dirs = [s.directory for s in a.entry_directories]
    core_dirs = [s.directory for s in a.core_directories]

    assert "tests" in entry_dirs
    assert "src/api" in core_dirs
    assert a.verdict == "likely_onion"
