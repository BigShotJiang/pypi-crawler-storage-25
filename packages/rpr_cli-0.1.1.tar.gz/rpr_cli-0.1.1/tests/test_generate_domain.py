from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

from rich.console import Console
from typer.testing import CliRunner

from rpr.cli import app


runner = CliRunner()


def _completed(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")


def _write_root_pyproject() -> None:
    Path("pyproject.toml").write_text(
        """[project]
name = "workspace"
version = "0.0.0"
requires-python = ">=3.12"
dependencies = []

[tool.uv.workspace]
members = []
"""
    )


def _extract_first_code_block(markdown: str) -> str:
    match = re.search(r"```(?:\w*)\n(.*?)```", markdown, re.DOTALL)
    assert match is not None
    return match.group(1)


def test_generate_domain_scaffolds_config_and_metadata(monkeypatch):
    recorded_calls: list[tuple[list[str], Path | str | None]] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        recorded_calls.append((cmd, cwd))
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)
    monkeypatch.setattr(
        "rpr.commands.generate.domain.typer.confirm", lambda *args, **kwargs: False
    )

    with runner.isolated_filesystem():
        _write_root_pyproject()

        result = runner.invoke(app, ["generate", "domain", "my-app"])
        assert result.exit_code == 0, result.stdout

        domain_root = Path("packages/python/domain")
        src_root = domain_root / "src" / "my_app_domain"

        assert domain_root.exists()
        assert (src_root / "config" / "settings.py").exists()
        assert (src_root / "config" / "container.py").exists()
        assert (src_root / "entities" / "base.py").exists()
        assert (src_root / "repos" / "base.py").exists()
        assert (domain_root / "tests" / "test_package.py").exists()

        for package_dir in [
            "",
            "entities",
            "dtos",
            "repos",
            "services",
            "workflows",
            "config",
            "utils",
        ]:
            assert (src_root / package_dir / "__init__.py").exists()

        settings = (src_root / "config" / "settings.py").read_text()
        container = (src_root / "config" / "container.py").read_text()
        project = json.loads((domain_root / "project.json").read_text())
        root_pyproject = Path("pyproject.toml").read_text()

        assert "class Settings(BaseSettings):" in settings
        assert (
            'db_host: str = Field(default="localhost", description="Database host")'
            in settings
        )
        assert (
            'db_password: str = Field(default="", description="Database password")'
            in settings
        )
        assert (
            'http_timeout: float = Field(default=30.0, description="HTTP client timeout in seconds")'
            in settings
        )
        assert "def database_url(self) -> str:" in settings

        assert "from my_app_domain.config.settings import Settings" in container
        assert "class Container(containers.DeclarativeContainer):" in container
        assert "config = providers.Singleton(Settings)" in container
        assert "settings.database_url" in container
        assert "pool_pre_ping=True" in container
        assert "pool_recycle=3600" in container
        assert "timeout=config.provided.http_timeout" in container
        assert "max_connections=config.provided.httpx_max_connections" in container
        assert (
            "max_keepalive_connections=config.provided.http_max_keepalive" in container
        )

        assert project["name"] == "domain"
        assert project["targets"]["build"]["options"]["command"] == "uv build"
        assert (
            project["targets"]["test"]["options"]["command"]
            == "uv run pytest packages/python/domain"
        )
        assert (
            project["targets"]["lint"]["options"]["command"]
            == "uv run ruff check packages/python/domain/src"
        )
        assert "migrate" not in project["targets"]
        assert '[tool.pytest.ini_options]' in (domain_root / "pyproject.toml").read_text()
        assert 'members = ["packages/python/domain"]' in root_pyproject

        assert recorded_calls[0][0] == ["uv", "sync"]
        assert recorded_calls[1][0] == [
            "uv",
            "add",
            "sqlmodel",
            "httpx",
            "dependency-injector",
            "pydantic",
            "pydantic-settings",
            "asyncpg",
        ]
        assert recorded_calls[2][0] == ["uv", "sync"]


def test_generate_domain_with_migrations_scaffolds_alembic_and_target(monkeypatch):
    recorded_calls: list[tuple[list[str], Path | str | None]] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        recorded_calls.append((cmd, cwd))
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)
    monkeypatch.setattr(
        "rpr.commands.generate.domain.typer.confirm", lambda *args, **kwargs: False
    )

    with runner.isolated_filesystem():
        _write_root_pyproject()

        result = runner.invoke(app, ["generate", "domain", "my-app", "--migrations"])
        assert result.exit_code == 0, result.stdout

        domain_root = Path("packages/python/domain")
        env_py = (domain_root / "migrations" / "env.py").read_text()
        alembic_ini = (domain_root / "alembic.ini").read_text()
        project = json.loads((domain_root / "project.json").read_text())

        assert (domain_root / "migrations" / "versions").is_dir()
        assert "script_location = %(here)s/migrations" in alembic_ini
        assert "from my_app_domain.config.settings import Settings" in env_py
        assert "import my_app_domain.entities  # noqa: F401" in env_py
        assert project["name"] == "domain"
        assert project["targets"]["migrate"]["options"]["command"] == (
            "uv run alembic -c packages/python/domain/alembic.ini"
        )
        assert project["targets"]["migrate"]["options"]["cwd"] == "."
        assert recorded_calls[1][0] == [
            "uv",
            "add",
            "sqlmodel",
            "httpx",
            "dependency-injector",
            "pydantic",
            "pydantic-settings",
            "asyncpg",
            "alembic",
        ]


def test_generate_domain_dry_run_previews_config_files(monkeypatch, capsys):
    monkeypatch.setattr(
        "rpr.context.console", Console(highlight=False, no_color=True), raising=False
    )
    monkeypatch.setattr(
        "rpr.commands.generate.domain.console", Console(highlight=False, no_color=True)
    )
    monkeypatch.setattr(
        "rpr.workspace.console", Console(highlight=False, no_color=True)
    )

    with runner.isolated_filesystem():
        _write_root_pyproject()

        result = runner.invoke(
            app, ["generate", "domain", "my-app", "--migrations", "--dry-run"]
        )
        assert result.exit_code == 0, result.stdout

        output = result.stdout + capsys.readouterr().out

        assert "DRY RUN" in output
        assert "packages/python/domain/src/my_app_domain/config" in output
        assert "packages/python/domain/src/my_app_domain/config/settings.py" in output
        assert "packages/python/domain/src/my_app_domain/config/container.py" in output
        assert "packages/python/domain/tests/test_package.py" in output
        assert "packages/python/domain/migrations/versions" in output
        assert "packages/python/domain/migrations/env.py" in output
        assert "packages/python/domain/alembic.ini" in output
        assert "Would add 'packages/python/domain' to workspace members" in output
        assert "Would install uv dependencies for packages/python/domain" in output
        assert "runtime=[sqlmodel, httpx, dependency-injector, pydantic, pydantic-settings, asyncpg, alembic]" in output
        assert not Path("packages").exists()
        assert "members = []" in Path("pyproject.toml").read_text()


def test_domain_config_scaffold_sources_stay_in_sync():
    repo_root = Path(__file__).resolve().parent.parent
    scaffold_root = repo_root / "src" / "rpr" / "scaffolds"

    settings_bundled = _extract_first_code_block(
        (scaffold_root / "domain" / "settings.md").read_text()
    )
    settings_special = _extract_first_code_block(
        (scaffold_root / "special_files" / "domain_settings.md").read_text()
    )
    container_bundled = _extract_first_code_block(
        (scaffold_root / "domain" / "container.md").read_text()
    )
    container_special = _extract_first_code_block(
        (scaffold_root / "special_files" / "domain_container.md").read_text()
    )

    assert settings_bundled == settings_special
    assert container_bundled == container_special
