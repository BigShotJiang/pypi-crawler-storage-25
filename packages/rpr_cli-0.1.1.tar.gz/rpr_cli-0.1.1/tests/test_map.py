from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from rpr.cli import app

runner = CliRunner()


def test_map_dry_run():
    """Invoke `map --dry-run` and assert no file written."""
    with runner.isolated_filesystem():
        base = Path(".")
        base.mkdir(exist_ok=True)

        result = runner.invoke(app, ["map", "--dry-run"])
        assert result.exit_code == 0
        assert "Root to scan" in result.output
        assert "Output path" in result.output
        assert "# Code Map" in result.output
        assert "No files written (dry-run mode)" in result.output
        assert not (base / "code-map.md").exists()


def test_map_writes_markdown_file():
    with runner.isolated_filesystem():
        result = runner.invoke(app, ["map"])
        assert result.exit_code == 0
        content = Path("code-map.md").read_text()
        assert content.startswith("# Code Map")
        assert "Backend:" in content


def test_map_details_flag():
    with runner.isolated_filesystem():
        result = runner.invoke(app, ["map", "--details"])
        assert result.exit_code == 0
        assert Path("code-map.md").exists()


def test_map_invalid_root():
    """Invoke with a nonexistent --root and assert error."""
    with runner.isolated_filesystem():
        result = runner.invoke(app, ["map", "--root", "/nonexistent/path"])
        assert result.exit_code == 1
        assert "Error:" in result.output or "does not exist" in result.output


def test_map_writes_enriched_sections():
    """Running `map` on a real project writes dependency/responsibility/coverage sections."""
    with runner.isolated_filesystem():
        # Create a minimal project so there's at least one source file
        Path("src").mkdir()
        Path("src/main.py").write_text("import os\n", encoding="utf-8")

        result = runner.invoke(app, ["map"])
        assert result.exit_code == 0
        content = Path("code-map.md").read_text()
        # At minimum the file was written and starts with the header
        assert content.startswith("# Code Map")
        # The enrichment sections are optional; verify the command doesn't crash
        # when they are (or aren't) present
        assert "Backend:" in content


def test_map_dry_run_with_enrichment():
    """Dry-run mode on a project with source files doesn't write any file."""
    with runner.isolated_filesystem():
        Path("pkg").mkdir()
        Path("pkg/service.py").write_text("import fastapi\n", encoding="utf-8")
        Path("tests").mkdir()
        Path("tests/test_service.py").write_text("from pkg.service import *\n", encoding="utf-8")

        result = runner.invoke(app, ["map", "--dry-run"])
        assert result.exit_code == 0
        assert "No files written (dry-run mode)" in result.output
        assert not Path("code-map.md").exists()

