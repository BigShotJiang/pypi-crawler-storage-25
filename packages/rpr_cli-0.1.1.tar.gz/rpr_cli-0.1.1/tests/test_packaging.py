from __future__ import annotations

import tomllib
from pathlib import Path

from rpr import __version__


def test_pyproject_uses_source_version_for_build_metadata() -> None:
    pyproject = tomllib.loads(Path("pyproject.toml").read_text())

    project = pyproject["project"]
    hatch_version = pyproject["tool"]["hatch"]["version"]

    assert project["name"] == "rpr-cli"
    assert project["dynamic"] == ["version"]
    assert project["scripts"]["rpr"] == "rpr.cli:app"
    assert hatch_version["path"] == "src/rpr/__init__.py"
    assert __version__