from pathlib import Path

from rpr.map.walker import list_project_entries, walk


class TestWalkerLanguageDetection:
    """Test language detection for all supported file extensions."""

    def test_python_file(self, tmp_path: Path) -> None:
        """Discover .py file with python language."""
        (tmp_path / "main.py").write_text("# python")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "python"

    def test_typescript_file(self, tmp_path: Path) -> None:
        """Discover .ts file with typescript language."""
        (tmp_path / "main.ts").write_text("// typescript")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "typescript"

    def test_tsx_file(self, tmp_path: Path) -> None:
        """Discover .tsx file with typescript language."""
        (tmp_path / "Component.tsx").write_text("// tsx")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "typescript"

    def test_javascript_file(self, tmp_path: Path) -> None:
        """Discover .js file with javascript language."""
        (tmp_path / "main.js").write_text("// javascript")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "javascript"

    def test_jsx_file(self, tmp_path: Path) -> None:
        """Discover .jsx file with javascript language."""
        (tmp_path / "Component.jsx").write_text("// jsx")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "javascript"

    def test_mjs_file(self, tmp_path: Path) -> None:
        """Discover .mjs file with javascript language."""
        (tmp_path / "main.mjs").write_text("// mjs")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "javascript"

    def test_cjs_file(self, tmp_path: Path) -> None:
        """Discover .cjs file with javascript language."""
        (tmp_path / "main.cjs").write_text("// cjs")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "javascript"

    def test_rust_file(self, tmp_path: Path) -> None:
        """Discover .rs file with rust language."""
        (tmp_path / "main.rs").write_text("// rust")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "rust"

    def test_cpp_file(self, tmp_path: Path) -> None:
        """Discover .cpp file with cpp language."""
        (tmp_path / "main.cpp").write_text("// cpp")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "cpp"

    def test_cc_file(self, tmp_path: Path) -> None:
        """Discover .cc file with cpp language."""
        (tmp_path / "main.cc").write_text("// cc")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "cpp"

    def test_cxx_file(self, tmp_path: Path) -> None:
        """Discover .cxx file with cpp language."""
        (tmp_path / "main.cxx").write_text("// cxx")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "cpp"

    def test_c_file(self, tmp_path: Path) -> None:
        """Discover .c file with cpp language."""
        (tmp_path / "main.c").write_text("// c")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "cpp"

    def test_h_file(self, tmp_path: Path) -> None:
        """Discover .h file with cpp language."""
        (tmp_path / "main.h").write_text("// h")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "cpp"

    def test_hpp_file(self, tmp_path: Path) -> None:
        """Discover .hpp file with cpp language."""
        (tmp_path / "main.hpp").write_text("// hpp")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "cpp"

    def test_hxx_file(self, tmp_path: Path) -> None:
        """Discover .hxx file with cpp language."""
        (tmp_path / "main.hxx").write_text("// hxx")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].language == "cpp"


class TestWalkerPruning:
    """Test that ignored directories are pruned."""

    def test_prune_node_modules(self, tmp_path: Path) -> None:
        """Files in node_modules are not returned."""
        (tmp_path / "src.py").write_text("# source")
        (tmp_path / "node_modules").mkdir()
        (tmp_path / "node_modules" / "lib.js").write_text("// lib")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.py")

    def test_prune_pycache(self, tmp_path: Path) -> None:
        """Files in __pycache__ are not returned."""
        (tmp_path / "src.py").write_text("# source")
        (tmp_path / "__pycache__").mkdir()
        (tmp_path / "__pycache__" / "main.cpython-39.pyc").write_text("bytecode")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.py")

    def test_prune_target(self, tmp_path: Path) -> None:
        """Files in target are not returned."""
        (tmp_path / "src.rs").write_text("// source")
        (tmp_path / "target").mkdir()
        (tmp_path / "target" / "lib.rs").write_text("// lib")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.rs")

    def test_prune_vendor(self, tmp_path: Path) -> None:
        """Files in vendor are not returned."""
        (tmp_path / "src.rs").write_text("// source")
        (tmp_path / "vendor").mkdir()
        (tmp_path / "vendor" / "lib.rs").write_text("// lib")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.rs")

    def test_prune_dist(self, tmp_path: Path) -> None:
        """Files in dist are not returned."""
        (tmp_path / "src.py").write_text("# source")
        (tmp_path / "dist").mkdir()
        (tmp_path / "dist" / "main.py").write_text("# built")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.py")

    def test_prune_build(self, tmp_path: Path) -> None:
        """Files in build are not returned."""
        (tmp_path / "src.py").write_text("# source")
        (tmp_path / "build").mkdir()
        (tmp_path / "build" / "main.py").write_text("# built")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.py")

    def test_prune_nx(self, tmp_path: Path) -> None:
        """Files in .nx are not returned."""
        (tmp_path / "src.py").write_text("# source")
        (tmp_path / ".nx").mkdir()
        (tmp_path / ".nx" / "cache").mkdir()
        (tmp_path / ".nx" / "cache" / "file.txt").write_text("cache")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.py")

    def test_prune_git(self, tmp_path: Path) -> None:
        """Files in .git are not returned."""
        (tmp_path / "src.py").write_text("# source")
        (tmp_path / ".git").mkdir()
        (tmp_path / ".git" / "config").write_text("git config")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.py")

    def test_prune_venv(self, tmp_path: Path) -> None:
        """Files in venv are not returned."""
        (tmp_path / "src.py").write_text("# source")
        (tmp_path / "venv").mkdir()
        (tmp_path / "venv" / "lib.py").write_text("# lib")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.py")

    def test_prune_dotenv(self, tmp_path: Path) -> None:
        """Files in .env are not returned."""
        (tmp_path / "src.py").write_text("# source")
        (tmp_path / ".env").mkdir()
        (tmp_path / ".env" / "config.py").write_text("# config")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.py")

    def test_prune_dotenv_folder(self, tmp_path: Path) -> None:
        """Files in .venv are not returned."""
        (tmp_path / "src.py").write_text("# source")
        (tmp_path / ".venv").mkdir()
        (tmp_path / ".venv" / "lib.py").write_text("# lib")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.py")


class TestWalkerFileSkipping:
    """Test that unsupported file extensions are skipped."""

    def test_skip_txt(self, tmp_path: Path) -> None:
        """Text files are skipped."""
        (tmp_path / "README.txt").write_text("text")
        results = walk(tmp_path)
        assert len(results) == 0

    def test_skip_json(self, tmp_path: Path) -> None:
        """JSON files are skipped."""
        (tmp_path / "config.json").write_text("{}")
        results = walk(tmp_path)
        assert len(results) == 0

    def test_skip_markdown(self, tmp_path: Path) -> None:
        """Markdown files are skipped."""
        (tmp_path / "README.md").write_text("# Title")
        results = walk(tmp_path)
        assert len(results) == 0

    def test_skip_unsupported_mixed(self, tmp_path: Path) -> None:
        """Supported and unsupported files mixed."""
        (tmp_path / "main.py").write_text("# python")
        (tmp_path / "README.md").write_text("# markdown")
        (tmp_path / "config.json").write_text("{}")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("main.py")


class TestWalkerSymlinks:
    """Test that symlinks are not followed."""

    def test_skip_symlink_file(self, tmp_path: Path) -> None:
        """Symlink files are skipped."""
        (tmp_path / "original.py").write_text("# original")
        (tmp_path / "link.py").symlink_to(tmp_path / "original.py")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("original.py")

    def test_skip_symlink_dir(self, tmp_path: Path) -> None:
        """Symlink directories are not followed."""
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("# source")
        (tmp_path / "link_src").symlink_to(tmp_path / "src")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src") / "main.py"


class TestWalkerPaths:
    """Test rel_path and abs_path correctness."""

    def test_rel_path_is_relative(self, tmp_path: Path) -> None:
        """rel_path is relative to root."""
        (tmp_path / "main.py").write_text("# python")
        results = walk(tmp_path)
        assert results[0].rel_path == Path("main.py")
        assert not results[0].rel_path.is_absolute()

    def test_abs_path_is_absolute(self, tmp_path: Path) -> None:
        """abs_path is absolute."""
        (tmp_path / "main.py").write_text("# python")
        results = walk(tmp_path)
        assert results[0].abs_path.is_absolute()

    def test_nested_rel_path(self, tmp_path: Path) -> None:
        """rel_path for nested files."""
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("# python")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src") / "main.py"

    def test_deeply_nested_rel_path(self, tmp_path: Path) -> None:
        """rel_path for deeply nested files."""
        (tmp_path / "a" / "b" / "c").mkdir(parents=True)
        (tmp_path / "a" / "b" / "c" / "main.py").write_text("# python")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("a") / "b" / "c" / "main.py"


class TestWalkerEmpty:
    """Test empty and edge case scenarios."""

    def test_empty_directory(self, tmp_path: Path) -> None:
        """Empty directory returns empty list."""
        results = walk(tmp_path)
        assert len(results) == 0

    def test_empty_directory_with_empty_subdirs(self, tmp_path: Path) -> None:
        """Directory with empty subdirs returns empty list."""
        (tmp_path / "empty1").mkdir()
        (tmp_path / "empty2").mkdir()
        results = walk(tmp_path)
        assert len(results) == 0


class TestProjectEntryListing:
    def test_lists_directories_and_files(self, tmp_path: Path) -> None:
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("# python")
        (tmp_path / "README.md").write_text("# readme")

        results = list_project_entries(tmp_path)

        assert [entry.rel_path.as_posix() for entry in results] == [
            "src",
            "src/main.py",
            "README.md",
        ]
        assert [entry.is_dir for entry in results] == [True, False, False]

    def test_listing_respects_gitignore(self, tmp_path: Path) -> None:
        (tmp_path / ".gitignore").write_text("secret/\nignored.txt\n")
        (tmp_path / "secret").mkdir()
        (tmp_path / "secret" / "hidden.py").write_text("# hidden")
        (tmp_path / "ignored.txt").write_text("ignored")
        (tmp_path / "visible.txt").write_text("visible")

        results = list_project_entries(tmp_path)

        assert [entry.rel_path.as_posix() for entry in results] == [
            ".gitignore",
            "visible.txt",
        ]


class TestWalkerMultipleFiles:
    """Test discovery of multiple files."""

    def test_multiple_files_same_type(self, tmp_path: Path) -> None:
        """Multiple files of same type are all discovered."""
        (tmp_path / "main.py").write_text("# main")
        (tmp_path / "utils.py").write_text("# utils")
        (tmp_path / "config.py").write_text("# config")
        results = walk(tmp_path)
        assert len(results) == 3
        assert all(r.language == "python" for r in results)

    def test_multiple_files_mixed_types(self, tmp_path: Path) -> None:
        """Multiple files of different types are all discovered."""
        (tmp_path / "main.py").write_text("# python")
        (tmp_path / "app.ts").write_text("// typescript")
        (tmp_path / "lib.rs").write_text("// rust")
        results = walk(tmp_path)
        assert len(results) == 3
        langs = {r.language for r in results}
        assert langs == {"python", "typescript", "rust"}

    def test_multiple_files_nested(self, tmp_path: Path) -> None:
        """Multiple nested files are all discovered."""
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("# main")
        (tmp_path / "src" / "utils.py").write_text("# utils")
        (tmp_path / "tests").mkdir()
        (tmp_path / "tests" / "test_main.py").write_text("# test")
        results = walk(tmp_path)
        assert len(results) == 3
        assert all(r.language == "python" for r in results)


class TestWalkerGitignore:
    """gitignore integration for the Python walker."""

    def test_gitignore_excludes_node_modules(self, tmp_path: Path) -> None:
        (tmp_path / ".gitignore").write_text("node_modules/\n")
        (tmp_path / "src.py").write_text("")
        nm = tmp_path / "node_modules"
        nm.mkdir()
        (nm / "lib.js").write_text("")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.py")

    def test_gitignore_excludes_custom_secret_dir(self, tmp_path: Path) -> None:
        (tmp_path / ".gitignore").write_text("secret/\n")
        (tmp_path / "src.py").write_text("")
        sec = tmp_path / "secret"
        sec.mkdir()
        (sec / "keys.py").write_text("")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.py")

    def test_gitignore_negation_re_includes_file(self, tmp_path: Path) -> None:
        (tmp_path / ".gitignore").write_text("*.py\n!important.py\n")
        (tmp_path / "ignored.py").write_text("")
        (tmp_path / "important.py").write_text("")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("important.py")

    def test_no_gitignore_falls_back_to_hard_coded(self, tmp_path: Path) -> None:
        (tmp_path / "src.py").write_text("")
        nm = tmp_path / "node_modules"
        nm.mkdir()
        (nm / "lib.js").write_text("")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("src.py")

    def test_gitignore_file_pattern_excludes_file(self, tmp_path: Path) -> None:
        (tmp_path / ".gitignore").write_text("secrets.py\n")
        (tmp_path / "main.py").write_text("")
        (tmp_path / "secrets.py").write_text("")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("main.py")

    def test_empty_gitignore_has_no_effect(self, tmp_path: Path) -> None:
        (tmp_path / ".gitignore").write_text("")
        (tmp_path / "main.py").write_text("")
        results = walk(tmp_path)
        assert len(results) == 1

    def test_gitignore_with_comments_and_blank_lines(self, tmp_path: Path) -> None:
        (tmp_path / ".gitignore").write_text(
            "# comment\n\nsecret/\n\n# another comment\n"
        )
        (tmp_path / "main.py").write_text("")
        sec = tmp_path / "secret"
        sec.mkdir()
        (sec / "keys.py").write_text("")
        results = walk(tmp_path)
        assert len(results) == 1
        assert results[0].rel_path == Path("main.py")
