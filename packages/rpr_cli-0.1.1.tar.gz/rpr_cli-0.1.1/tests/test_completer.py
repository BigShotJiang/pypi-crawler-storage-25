from __future__ import annotations

from pathlib import Path

from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document
from prompt_toolkit.formatted_text import to_plain_text

from rpr.application.completer import (
    FileContextCompleter,
    MultiCompleter,
    SlashCommandCandidate,
    SlashCommandCompleter,
)


def _make(names: list[str]) -> SlashCommandCompleter:
    return SlashCommandCompleter(
        [
            SlashCommandCandidate(name=n, description=f"{n} desc", usage=f"/{n}")
            for n in names
        ]
    )


def _ev() -> CompleteEvent:
    return CompleteEvent()


def test_bare_slash_yields_all_candidates():
    completions = list(
        _make(["init", "settings", "help"]).get_completions(Document("/"), _ev())
    )
    assert len(completions) == 3


def test_prefix_filter_narrows_candidates():
    completions = list(
        _make(["init", "settings", "sync"]).get_completions(Document("/se"), _ev())
    )
    assert [c.text for c in completions] == ["settings"]


def test_non_slash_text_yields_no_completions():
    assert list(_make(["init"]).get_completions(Document("hello"), _ev())) == []


def test_empty_string_yields_no_completions():
    assert list(_make(["init"]).get_completions(Document(""), _ev())) == []


def test_completion_text_is_name_without_slash():
    completions = list(_make(["init"]).get_completions(Document("/in"), _ev()))
    assert completions[0].text == "init"


def test_start_position_replaces_partial():
    completions = list(_make(["settings"]).get_completions(Document("/se"), _ev()))
    assert completions[0].start_position == -2  # len("se")


def test_start_position_zero_for_bare_slash():
    completions = list(_make(["init"]).get_completions(Document("/"), _ev()))
    assert completions[0].start_position == 0


def test_display_meta_equals_description():
    candidates = [
        SlashCommandCandidate(
            name="init", description="Bootstrap workspace", usage="/init"
        )
    ]
    completions = list(
        SlashCommandCompleter(candidates).get_completions(Document("/"), _ev())
    )
    assert to_plain_text(completions[0].display_meta) == "Bootstrap workspace"


def test_display_includes_slash_prefix():
    completions = list(_make(["help"]).get_completions(Document("/"), _ev()))
    assert to_plain_text(completions[0].display) == "/help"


def test_file_context_bare_at_yields_project_candidates(tmp_path: Path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "main.py").write_text("# python")
    (tmp_path / "README.md").write_text("# readme")

    completions = list(
        FileContextCompleter(tmp_path).get_completions(Document("@"), _ev())
    )

    assert [completion.text for completion in completions] == [
        "src/",
        "src/main.py",
        "README.md",
    ]


def test_file_context_prefix_filters_nested_paths(tmp_path: Path):
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "main.py").write_text("# python")
    (tmp_path / "stories").mkdir()

    completions = list(
        FileContextCompleter(tmp_path).get_completions(Document("Explain @sr"), _ev())
    )

    assert [completion.text for completion in completions] == ["src/", "src/main.py"]


def test_file_context_filter_is_case_insensitive(tmp_path: Path):
    (tmp_path / "README.md").write_text("# readme")

    completions = list(
        FileContextCompleter(tmp_path).get_completions(Document("Explain @r"), _ev())
    )

    assert [completion.text for completion in completions] == ["README.md"]


def test_multi_completer_exposes_both_selector_sources(tmp_path: Path):
    (tmp_path / "src").mkdir()
    multi = MultiCompleter(
        [
            _make(["help"]),
            FileContextCompleter(tmp_path),
        ]
    )

    assert [source.trigger for source in multi.selector_sources] == ["/", "@"]
