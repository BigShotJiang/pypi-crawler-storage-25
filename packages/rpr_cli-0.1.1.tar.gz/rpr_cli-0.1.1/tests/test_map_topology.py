from __future__ import annotations

from pathlib import Path

from rpr.map.graph import DependencyGraph
from rpr.map.topology import (
    DirectoryTopology,
    build_directory_topology,
    focus_edges,
)
from rpr.map.walker import SourceFile

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_ROOT = Path("/fake/root")


def _sf(rel: str, language: str = "python") -> SourceFile:
    p = Path(rel)
    return SourceFile(abs_path=_ROOT / p, rel_path=p, language=language)  # type: ignore[arg-type]


def _graph(
    nodes: list[SourceFile],
    edges: dict[str, list[str]] | None = None,
) -> DependencyGraph:
    edges = edges or {}
    rev: dict[str, list[str]] = {n.rel_path.as_posix(): [] for n in nodes}
    for src, deps in edges.items():
        for dep in deps:
            rev.setdefault(dep, []).append(src)
    return DependencyGraph(
        nodes=nodes,
        edges=edges,
        reverse_edges=rev,
        cycles=[],
        backend="python-fallback",
    )


def _build(
    nodes: list[SourceFile],
    edges: dict[str, list[str]] | None = None,
) -> DirectoryTopology:
    return build_directory_topology(_graph(nodes, edges), _ROOT)


# ---------------------------------------------------------------------------
# TestDirectoryPreservation
# ---------------------------------------------------------------------------


class TestDirectoryPreservation:
    def test_all_directories_discovered(self) -> None:
        nodes = [
            _sf("api/routes/user_routes.py"),
            _sf("domain/repos/user_repo.py"),
        ]
        topo = _build(nodes)
        assert set(topo.nodes) == {"", "api", "api/routes", "domain", "domain/repos"}

    def test_root_node_always_exists(self) -> None:
        topo = _build([_sf("src/app.py")])
        assert "" in topo.nodes

    def test_deeply_nested_path_creates_all_ancestors(self) -> None:
        topo = _build([_sf("a/b/c/d/file.py")])
        assert set(topo.nodes) == {"", "a", "a/b", "a/b/c", "a/b/c/d"}

    def test_parent_child_relationship(self) -> None:
        topo = _build([_sf("api/routes/user_routes.py")])
        assert "api/routes" in topo.nodes["api"].children
        assert topo.nodes["api/routes"].parent == "api"

    def test_root_parent_is_none(self) -> None:
        topo = _build([_sf("main.py")])
        assert topo.nodes[""].parent is None

    def test_files_assigned_to_correct_directory(self) -> None:
        topo = _build([_sf("api/routes/user_routes.py")])
        assert "api/routes/user_routes.py" in topo.nodes["api/routes"].files
        # Intermediate dirs should NOT contain the file directly
        assert "api/routes/user_routes.py" not in topo.nodes["api"].files

    def test_deterministic_ordering_children(self) -> None:
        nodes = [
            _sf("api/z_last.py"),
            _sf("api/a_first.py"),
        ]
        topo = _build(nodes)
        files = list(topo.nodes["api"].files)
        assert files == sorted(files)

    def test_deterministic_ordering_files(self) -> None:
        nodes = [
            _sf("src/z_module.py"),
            _sf("src/a_module.py"),
            _sf("src/m_module.py"),
        ]
        topo = _build(nodes)
        files = list(topo.nodes["src"].files)
        assert files == sorted(files)

    def test_sibling_dirs_both_present(self) -> None:
        nodes = [_sf("api/routes/a.py"), _sf("api/middleware/b.py")]
        topo = _build(nodes)
        children = set(topo.nodes["api"].children)
        assert children == {"api/routes", "api/middleware"}


# ---------------------------------------------------------------------------
# TestContainmentWithRootFiles
# ---------------------------------------------------------------------------


class TestContainmentWithRootFiles:
    def test_file_at_root_level(self) -> None:
        topo = _build([_sf("main.py")])
        assert "main.py" in topo.nodes[""].files

    def test_mix_of_root_and_nested_files(self) -> None:
        nodes = [_sf("main.py"), _sf("src/app.py")]
        topo = _build(nodes)
        assert "main.py" in topo.nodes[""].files
        assert "src/app.py" in topo.nodes["src"].files
        # main.py must NOT appear under src
        assert "main.py" not in topo.nodes["src"].files

    def test_root_has_no_parent(self) -> None:
        topo = _build([_sf("main.py")])
        assert topo.nodes[""].parent is None


# ---------------------------------------------------------------------------
# TestFullDepthDirectoryEdges
# ---------------------------------------------------------------------------


class TestFullDepthDirectoryEdges:
    def test_basic_cross_directory_edge(self) -> None:
        nodes = [_sf("api/routes/user.py"), _sf("domain/repos/user_repo.py")]
        edges = {"api/routes/user.py": ["domain/repos/user_repo.py"]}
        topo = _build(nodes, edges)
        assert ("api/routes", "domain/repos") in topo.edges

    def test_intra_directory_edge_excluded(self) -> None:
        nodes = [_sf("api/routes/a.py"), _sf("api/routes/b.py")]
        edges = {"api/routes/a.py": ["api/routes/b.py"]}
        topo = _build(nodes, edges)
        assert ("api/routes", "api/routes") not in topo.edges
        assert len(topo.edges) == 0

    def test_support_count_correct(self) -> None:
        nodes = [
            _sf("api/routes/user.py"),
            _sf("api/routes/item.py"),
            _sf("domain/repos/user_repo.py"),
            _sf("domain/repos/item_repo.py"),
        ]
        edges = {
            "api/routes/user.py": ["domain/repos/user_repo.py"],
            "api/routes/item.py": ["domain/repos/item_repo.py"],
        }
        topo = _build(nodes, edges)
        edge = topo.edges[("api/routes", "domain/repos")]
        assert edge.support == 2

    def test_representative_pairs_captured(self) -> None:
        nodes = [_sf("api/routes/user.py"), _sf("domain/repos/user_repo.py")]
        edges = {"api/routes/user.py": ["domain/repos/user_repo.py"]}
        topo = _build(nodes, edges)
        edge = topo.edges[("api/routes", "domain/repos")]
        assert (
            "api/routes/user.py",
            "domain/repos/user_repo.py",
        ) in edge.representatives

    def test_multiple_directory_edges(self) -> None:
        nodes = [
            _sf("api/routes/user.py"),
            _sf("domain/repos/user_repo.py"),
            _sf("api/middleware/auth.py"),
            _sf("infra/db/connection.py"),
        ]
        edges = {
            "api/routes/user.py": ["domain/repos/user_repo.py"],
            "api/middleware/auth.py": ["infra/db/connection.py"],
        }
        topo = _build(nodes, edges)
        assert ("api/routes", "domain/repos") in topo.edges
        assert ("api/middleware", "infra/db") in topo.edges

    def test_representatives_sorted(self) -> None:
        nodes = [
            _sf("api/routes/z_user.py"),
            _sf("api/routes/a_item.py"),
            _sf("domain/repos/z_repo.py"),
            _sf("domain/repos/a_repo.py"),
        ]
        edges = {
            "api/routes/z_user.py": ["domain/repos/z_repo.py"],
            "api/routes/a_item.py": ["domain/repos/a_repo.py"],
        }
        topo = _build(nodes, edges)
        edge = topo.edges[("api/routes", "domain/repos")]
        reps = list(edge.representatives)
        assert reps == sorted(reps)


# ---------------------------------------------------------------------------
# TestEdgesAtDepth
# ---------------------------------------------------------------------------


class TestEdgesAtDepth:
    def test_depth_1_aggregation(self) -> None:
        nodes = [_sf("api/routes/user.py"), _sf("domain/repos/user_repo.py")]
        edges = {"api/routes/user.py": ["domain/repos/user_repo.py"]}
        topo = _build(nodes, edges)
        result = topo.edges_at_depth(1)
        assert len(result) == 1
        assert result[0].source == "api"
        assert result[0].target == "domain"

    def test_depth_2_preserves_detail(self) -> None:
        nodes = [_sf("api/routes/user.py"), _sf("domain/repos/user_repo.py")]
        edges = {"api/routes/user.py": ["domain/repos/user_repo.py"]}
        topo = _build(nodes, edges)
        result = topo.edges_at_depth(2)
        assert len(result) == 1
        assert result[0].source == "api/routes"
        assert result[0].target == "domain/repos"

    def test_intra_dir_excluded_after_truncation(self) -> None:
        # Both api/routes and api/middleware collapse to "api" at depth 1
        nodes = [_sf("api/routes/a.py"), _sf("api/middleware/b.py")]
        edges = {"api/routes/a.py": ["api/middleware/b.py"]}
        topo = _build(nodes, edges)
        result = topo.edges_at_depth(1)
        assert len(result) == 0

    def test_support_counts_merge_at_depth(self) -> None:
        nodes = [
            _sf("api/routes/user.py"),
            _sf("api/routes/item.py"),
            _sf("domain/repos/user_repo.py"),
            _sf("domain/repos/item_repo.py"),
        ]
        edges = {
            "api/routes/user.py": ["domain/repos/user_repo.py"],
            "api/routes/item.py": ["domain/repos/item_repo.py"],
        }
        topo = _build(nodes, edges)
        result = topo.edges_at_depth(1)
        assert len(result) == 1
        assert result[0].support == 2

    def test_representatives_merge_at_depth(self) -> None:
        nodes = [
            _sf("api/routes/user.py"),
            _sf("api/routes/item.py"),
            _sf("domain/repos/user_repo.py"),
            _sf("domain/repos/item_repo.py"),
        ]
        edges = {
            "api/routes/user.py": ["domain/repos/user_repo.py"],
            "api/routes/item.py": ["domain/repos/item_repo.py"],
        }
        topo = _build(nodes, edges)
        result = topo.edges_at_depth(1)
        reps = set(result[0].representatives)
        assert ("api/routes/user.py", "domain/repos/user_repo.py") in reps
        assert ("api/routes/item.py", "domain/repos/item_repo.py") in reps

    def test_depth_greater_than_path_uses_full_path(self) -> None:
        nodes = [_sf("api/user.py"), _sf("domain/user_repo.py")]
        edges = {"api/user.py": ["domain/user_repo.py"]}
        topo = _build(nodes, edges)
        # depth=10 is deeper than any real dir — full dir paths returned
        result = topo.edges_at_depth(10)
        assert len(result) == 1
        assert result[0].source == "api"
        assert result[0].target == "domain"

    def test_result_sorted_by_source_target(self) -> None:
        nodes = [
            _sf("z_api/routes/user.py"),
            _sf("a_domain/repos/user_repo.py"),
            _sf("m_api/routes/item.py"),
            _sf("b_domain/repos/item_repo.py"),
        ]
        edges = {
            "z_api/routes/user.py": ["a_domain/repos/user_repo.py"],
            "m_api/routes/item.py": ["b_domain/repos/item_repo.py"],
        }
        topo = _build(nodes, edges)
        result = topo.edges_at_depth(1)
        sources = [e.source for e in result]
        assert sources == sorted(sources)


# ---------------------------------------------------------------------------
# TestTopLevelEdges
# ---------------------------------------------------------------------------


class TestTopLevelEdges:
    def test_equals_depth_1(self) -> None:
        nodes = [
            _sf("api/routes/user.py"),
            _sf("domain/repos/user_repo.py"),
            _sf("infra/db/conn.py"),
        ]
        edges = {
            "api/routes/user.py": ["domain/repos/user_repo.py"],
            "domain/repos/user_repo.py": ["infra/db/conn.py"],
        }
        topo = _build(nodes, edges)
        assert topo.top_level_edges() == topo.edges_at_depth(1)


# ---------------------------------------------------------------------------
# TestSubgraph
# ---------------------------------------------------------------------------


class TestSubgraph:
    def test_subgraph_returns_edge_among_children(self) -> None:
        nodes = [_sf("api/routes/user.py"), _sf("api/middleware/auth.py")]
        edges = {"api/routes/user.py": ["api/middleware/auth.py"]}
        topo = _build(nodes, edges)
        result = topo.subgraph("api")
        assert len(result) == 1
        assert result[0].source == "api/routes"
        assert result[0].target == "api/middleware"

    def test_subgraph_includes_outbound_edges(self) -> None:
        nodes = [_sf("api/routes/user.py"), _sf("domain/repos/user_repo.py")]
        edges = {"api/routes/user.py": ["domain/repos/user_repo.py"]}
        topo = _build(nodes, edges)
        result = topo.subgraph("api")
        assert len(result) == 1
        assert result[0].source == "api/routes"
        assert result[0].target == "domain"

    def test_subgraph_root_returns_top_level(self) -> None:
        nodes = [_sf("api/routes/user.py"), _sf("domain/repos/user_repo.py")]
        edges = {"api/routes/user.py": ["domain/repos/user_repo.py"]}
        topo = _build(nodes, edges)
        root_sg = topo.subgraph("")
        top = topo.top_level_edges()
        assert root_sg == top


# ---------------------------------------------------------------------------
# TestFilesIn
# ---------------------------------------------------------------------------


class TestFilesIn:
    def test_recursive_file_collection(self) -> None:
        nodes = [
            _sf("api/routes/user.py"),
            _sf("api/middleware/auth.py"),
            _sf("api/app.py"),
        ]
        topo = _build(nodes)
        result = topo.files_in("api")
        assert set(result) == {
            "api/routes/user.py",
            "api/middleware/auth.py",
            "api/app.py",
        }

    def test_files_in_leaf_directory(self) -> None:
        nodes = [_sf("api/routes/user.py"), _sf("api/routes/item.py")]
        topo = _build(nodes)
        result = topo.files_in("api/routes")
        assert set(result) == {"api/routes/user.py", "api/routes/item.py"}

    def test_files_in_root(self) -> None:
        nodes = [_sf("main.py"), _sf("src/app.py"), _sf("src/utils/helpers.py")]
        topo = _build(nodes)
        result = topo.files_in("")
        assert set(result) == {"main.py", "src/app.py", "src/utils/helpers.py"}

    def test_files_in_sorted(self) -> None:
        nodes = [_sf("src/z.py"), _sf("src/a.py"), _sf("src/m.py")]
        topo = _build(nodes)
        result = topo.files_in("src")
        assert result == sorted(result)


# ---------------------------------------------------------------------------
# TestEdgeCases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_empty_graph(self) -> None:
        topo = _build([])
        # Root node should still exist
        assert "" in topo.nodes
        assert len(topo.edges) == 0

    def test_single_file_no_edges(self) -> None:
        topo = _build([_sf("src/app.py")])
        assert "" in topo.nodes
        assert "src" in topo.nodes
        assert len(topo.edges) == 0

    def test_single_file_at_root(self) -> None:
        topo = _build([_sf("main.py")])
        assert "" in topo.nodes
        assert "main.py" in topo.nodes[""].files
        assert len(topo.edges) == 0

    def test_no_cross_directory_edges(self) -> None:
        nodes = [_sf("api/a.py"), _sf("api/b.py")]
        edges = {"api/a.py": ["api/b.py"]}
        topo = _build(nodes, edges)
        assert len(topo.edges) == 0

    def test_files_but_no_edges(self) -> None:
        nodes = [_sf("api/a.py"), _sf("domain/b.py")]
        topo = _build(nodes)
        assert "api" in topo.nodes
        assert "domain" in topo.nodes
        assert len(topo.edges) == 0

    def test_multiple_deps_from_same_file(self) -> None:
        nodes = [
            _sf("api/routes/user.py"),
            _sf("domain/models/user.py"),
            _sf("domain/repos/user_repo.py"),
        ]
        edges = {
            "api/routes/user.py": [
                "domain/models/user.py",
                "domain/repos/user_repo.py",
            ]
        }
        topo = _build(nodes, edges)
        # Two distinct full-depth edges from api/routes
        assert ("api/routes", "domain/models") in topo.edges
        assert ("api/routes", "domain/repos") in topo.edges


# ---------------------------------------------------------------------------
# TestDeterminism
# ---------------------------------------------------------------------------


class TestDeterminism:
    def test_same_input_same_output(self) -> None:
        nodes = [_sf("api/routes/user.py"), _sf("domain/repos/user_repo.py")]
        edges = {"api/routes/user.py": ["domain/repos/user_repo.py"]}
        topo1 = _build(nodes, edges)
        topo2 = _build(nodes, edges)
        assert topo1.nodes == topo2.nodes
        assert topo1.edges == topo2.edges

    def test_node_insertion_order_irrelevant(self) -> None:
        nodes_a = [_sf("api/routes/user.py"), _sf("domain/repos/user_repo.py")]
        nodes_b = [_sf("domain/repos/user_repo.py"), _sf("api/routes/user.py")]
        edges = {"api/routes/user.py": ["domain/repos/user_repo.py"]}
        topo_a = _build(nodes_a, edges)
        topo_b = _build(nodes_b, edges)
        assert topo_a.nodes == topo_b.nodes
        assert topo_a.edges == topo_b.edges

    def test_edges_at_depth_deterministic(self) -> None:
        nodes = [
            _sf("api/routes/user.py"),
            _sf("api/routes/item.py"),
            _sf("domain/repos/user_repo.py"),
            _sf("domain/repos/item_repo.py"),
        ]
        edges = {
            "api/routes/user.py": ["domain/repos/user_repo.py"],
            "api/routes/item.py": ["domain/repos/item_repo.py"],
        }
        topo = _build(nodes, edges)
        result1 = topo.edges_at_depth(1)
        result2 = topo.edges_at_depth(1)
        assert result1 == result2


# ---------------------------------------------------------------------------
# TestAcceptanceCriteria (story 17a explicit scenarios)
# ---------------------------------------------------------------------------


class TestAcceptanceCriteria:
    """Directly verifies the scenarios described in story 17a acceptance criteria."""

    def test_api_to_domain_scenario(self) -> None:
        """api/routes/user.routes.py -> domain/repos/user.repo.py produces the
        specified directory nodes and top-level derived edge."""
        nodes = [
            _sf("api/routes/user_routes.py"),
            _sf("domain/repos/user_repo.py"),
        ]
        edges = {"api/routes/user_routes.py": ["domain/repos/user_repo.py"]}
        topo = _build(nodes, edges)

        # All four directory nodes must exist
        for expected_dir in ("api", "api/routes", "domain", "domain/repos"):
            assert expected_dir in topo.nodes, f"Missing directory node: {expected_dir}"

        # Top-level derived edge api -> domain
        top = topo.top_level_edges()
        assert any(e.source == "api" and e.target == "domain" for e in top)

    def test_deeper_derived_edges(self) -> None:
        """api/routes -> domain/repos and api/routes -> domain/models/entities
        when those file edges exist."""
        nodes = [
            _sf("api/routes/user.py"),
            _sf("domain/repos/user_repo.py"),
            _sf("domain/models/entities/user.py"),
        ]
        edges = {
            "api/routes/user.py": [
                "domain/repos/user_repo.py",
                "domain/models/entities/user.py",
            ]
        }
        topo = _build(nodes, edges)
        assert ("api/routes", "domain/repos") in topo.edges
        assert ("api/routes", "domain/models/entities") in topo.edges

    def test_no_physical_directories_discarded(self) -> None:
        """No physical directories under the analyzed root are discarded from
        the topology model."""
        nodes = [
            _sf("api/routes/user.py"),
            _sf("api/middleware/auth.py"),
            _sf("domain/repos/user_repo.py"),
            _sf("domain/models/entities/user.py"),
            _sf("domain/models/dtos/user_dto.py"),
        ]
        topo = _build(nodes)
        expected_dirs = {
            "",
            "api",
            "api/routes",
            "api/middleware",
            "domain",
            "domain/repos",
            "domain/models",
            "domain/models/entities",
            "domain/models/dtos",
        }
        assert expected_dirs.issubset(set(topo.nodes))

    def test_duplicate_edges_deduplicated_with_support(self) -> None:
        """Duplicate directory edges are deduplicated and include a support
        count representing how many file edges contributed."""
        nodes = [
            _sf("api/routes/user.py"),
            _sf("api/routes/item.py"),
            _sf("domain/repos/user_repo.py"),
            _sf("domain/repos/item_repo.py"),
        ]
        edges = {
            "api/routes/user.py": ["domain/repos/user_repo.py"],
            "api/routes/item.py": ["domain/repos/item_repo.py"],
        }
        topo = _build(nodes, edges)
        # Only one edge object per directory pair
        assert ("api/routes", "domain/repos") in topo.edges
        edge = topo.edges[("api/routes", "domain/repos")]
        assert edge.support == 2

    def test_each_edge_has_representative_pair(self) -> None:
        """Each aggregated directory edge stores at least one representative
        source file and destination file pair."""
        nodes = [_sf("api/routes/user.py"), _sf("domain/repos/user_repo.py")]
        edges = {"api/routes/user.py": ["domain/repos/user_repo.py"]}
        topo = _build(nodes, edges)
        for edge in topo.edges.values():
            assert len(edge.representatives) >= 1
            for src_file, tgt_file in edge.representatives:
                assert src_file  # non-empty
                assert tgt_file  # non-empty


class TestFocusEdges:
    """Tests for focus_edges() domain function."""

    def test_internal_edges_within_focus(self) -> None:
        nodes = [_sf("api/a.py"), _sf("api/b.py"), _sf("domain/c.py")]
        edges = {"api/a.py": ["api/b.py"], "api/b.py": ["domain/c.py"]}
        topo = _build(nodes, edges)
        internal, inbound, outbound = focus_edges(topo, "api", edges)
        assert ("api/a.py", "api/b.py") in internal
        assert len(inbound) == 0

    def test_outbound_edges_from_focus(self) -> None:
        nodes = [_sf("api/a.py"), _sf("api/b.py"), _sf("domain/c.py")]
        edges = {"api/b.py": ["domain/c.py"]}
        topo = _build(nodes, edges)
        internal, inbound, outbound = focus_edges(topo, "api", edges)
        assert ("api/b.py", "domain/c.py") in outbound
        assert len(internal) == 0
        assert len(inbound) == 0

    def test_inbound_edges_to_focus(self) -> None:
        nodes = [_sf("cmd/main.py"), _sf("svc/handler.py")]
        edges = {"cmd/main.py": ["svc/handler.py"]}
        topo = _build(nodes, edges)
        internal, inbound, outbound = focus_edges(topo, "svc", edges)
        assert ("cmd/main.py", "svc/handler.py") in inbound
        assert len(internal) == 0
        assert len(outbound) == 0

    def test_mixed_edges(self) -> None:
        nodes = [
            _sf("api/a.py"),
            _sf("api/b.py"),
            _sf("domain/c.py"),
            _sf("ext/d.py"),
        ]
        edges = {
            "api/a.py": ["api/b.py", "domain/c.py"],
            "ext/d.py": ["api/a.py"],
        }
        topo = _build(nodes, edges)
        internal, inbound, outbound = focus_edges(topo, "api", edges)
        assert ("api/a.py", "api/b.py") in internal
        assert ("api/a.py", "domain/c.py") in outbound
        assert ("ext/d.py", "api/a.py") in inbound

    def test_empty_focus_directory(self) -> None:
        nodes = [_sf("api/a.py"), _sf("domain/b.py")]
        edges = {"api/a.py": ["domain/b.py"]}
        topo = _build(nodes, edges)
        internal, inbound, outbound = focus_edges(topo, "other", edges)
        assert internal == []
        assert inbound == []
        assert outbound == []

    def test_results_are_sorted(self) -> None:
        nodes = [_sf("api/z.py"), _sf("api/a.py"), _sf("ext/x.py")]
        edges = {"api/z.py": ["ext/x.py"], "api/a.py": ["ext/x.py"]}
        topo = _build(nodes, edges)
        internal, inbound, outbound = focus_edges(topo, "api", edges)
        assert outbound == sorted(outbound)
