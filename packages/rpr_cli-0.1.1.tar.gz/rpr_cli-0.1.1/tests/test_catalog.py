from __future__ import annotations

import pytest

from rpr.application.catalog import (
    COMMAND_CATALOG,
    CommandArgument,
    CommandDefinition,
    CommandOption,
    chat_commands,
    cli_commands,
    find_command,
    usage_string,
)


# ---------------------------------------------------------------------------
# Recursive lookup
# ---------------------------------------------------------------------------


def test_find_command_top_level_returns_match():
    result = find_command(COMMAND_CATALOG, ["init"])
    assert result is not None
    assert result.name == "init"


def test_find_command_nested_generate_ui():
    result = find_command(COMMAND_CATALOG, ["generate", "ui"])
    assert result is not None
    assert result.action_id == "generate.ui"


def test_find_command_nested_sync_rules():
    result = find_command(COMMAND_CATALOG, ["sync", "rules"])
    assert result is not None
    assert result.action_id == "sync.rules"


def test_find_command_nested_add_template():
    result = find_command(COMMAND_CATALOG, ["add", "template"])
    assert result is not None
    assert result.action_id == "add.template"


def test_find_command_unknown_returns_none():
    assert find_command(COMMAND_CATALOG, ["unknown"]) is None


def test_find_command_empty_tokens_returns_none():
    assert find_command(COMMAND_CATALOG, []) is None


def test_find_command_unknown_child_returns_none():
    assert find_command(COMMAND_CATALOG, ["generate", "nonexistent"]) is None


# ---------------------------------------------------------------------------
# DTO immutability
# ---------------------------------------------------------------------------


def test_command_definition_is_frozen():
    cmd = find_command(COMMAND_CATALOG, ["init"])
    assert cmd is not None
    with pytest.raises(AttributeError):
        cmd.name = "mutated"  # type: ignore[misc]


def test_command_option_is_frozen():
    cmd = find_command(COMMAND_CATALOG, ["init"])
    assert cmd is not None
    opt = cmd.options[0]
    with pytest.raises(AttributeError):
        opt.long_name = "mutated"  # type: ignore[misc]


def test_command_argument_is_frozen():
    cmd = find_command(COMMAND_CATALOG, ["init"])
    assert cmd is not None
    arg = cmd.arguments[0]
    with pytest.raises(AttributeError):
        arg.name = "mutated"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Action binding
# ---------------------------------------------------------------------------


def test_all_leaf_commands_have_action_id():
    def collect_leaves(cmds: tuple[CommandDefinition, ...]):
        for cmd in cmds:
            if not cmd.children:
                yield cmd
            else:
                yield from collect_leaves(cmd.children)

    for cmd in collect_leaves(COMMAND_CATALOG):
        assert cmd.action_id, f"Leaf command '{cmd.name}' has no action_id"


def test_chat_action_id():
    result = find_command(COMMAND_CATALOG, ["chat"])
    assert result is not None
    assert result.action_id == "chat.start"


# ---------------------------------------------------------------------------
# Chat / CLI parity
# ---------------------------------------------------------------------------


def test_help_and_exit_are_chat_only():
    help_cmd = find_command(COMMAND_CATALOG, ["help"])
    exit_cmd = find_command(COMMAND_CATALOG, ["exit"])
    assert help_cmd is not None and exit_cmd is not None
    assert help_cmd.chat_enabled is True
    assert help_cmd.cli_enabled is False
    assert exit_cmd.chat_enabled is True
    assert exit_cmd.cli_enabled is False


def test_cli_commands_excludes_chat_only():
    names = {cmd.name for cmd in cli_commands(COMMAND_CATALOG)}
    assert "help" not in names
    assert "exit" not in names


def test_chat_commands_includes_chat_only():
    names = {cmd.name for cmd in chat_commands(COMMAND_CATALOG)}
    assert "help" in names
    assert "exit" in names


def test_exactly_one_default_root_command():
    defaults = [cmd for cmd in COMMAND_CATALOG if cmd.default_root_command]
    assert len(defaults) == 1
    assert defaults[0].name == "chat"


# ---------------------------------------------------------------------------
# Shell service derives specs from catalog
# ---------------------------------------------------------------------------


def _reset_shell_service() -> None:
    from rpr.application.shell import CommandShellService

    CommandShellService._instance = None


def test_shell_service_spec_count_matches_catalog():
    _reset_shell_service()
    from rpr.application.shell import CommandShellService

    service = CommandShellService.instance()
    expected_count = len(chat_commands(COMMAND_CATALOG))
    assert len(service._command_specs) == expected_count
    _reset_shell_service()


def test_shell_service_spec_names_match_catalog():
    _reset_shell_service()
    from rpr.application.shell import CommandShellService

    service = CommandShellService.instance()
    catalog_names = {cmd.name for cmd in chat_commands(COMMAND_CATALOG)}
    assert set(service._command_specs.keys()) == catalog_names
    _reset_shell_service()


# ---------------------------------------------------------------------------
# Usage string generation
# ---------------------------------------------------------------------------


def test_usage_string_leaf_includes_args_and_options():
    cmd = find_command(COMMAND_CATALOG, ["init"])
    assert cmd is not None
    usage = usage_string(cmd)
    assert usage.startswith("/init")
    assert "[project-name]" in usage
    assert "--dry-run" in usage


def test_usage_string_group_uses_pipe_separated_children():
    cmd = find_command(COMMAND_CATALOG, ["generate"])
    assert cmd is not None
    usage = usage_string(cmd)
    assert "/generate" in usage
    assert "domain" in usage
    assert "|" in usage


def test_usage_string_value_option_includes_placeholder():
    cmd = find_command(COMMAND_CATALOG, ["sync", "rules"])
    assert cmd is not None
    usage = usage_string(cmd)
    assert "--target" in usage
    assert "GENERATOR" in usage
