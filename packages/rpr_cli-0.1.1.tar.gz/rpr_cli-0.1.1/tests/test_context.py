"""Tests for RunContext — dry-run behavior and command display."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import patch

from rich.console import Console

from rpr.context import RunContext


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_ctx(dry_run: bool = False, project_dir: Path | None = None) -> RunContext:
    return RunContext(dry_run=dry_run, project_dir=project_dir or Path("/fake/project"))


def completed(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")


# ---------------------------------------------------------------------------
# run_command — live mode
# ---------------------------------------------------------------------------


class TestRunCommandLive:
    def test_displays_rpr_prefix_before_executing(self, capsys):
        ctx = make_ctx(dry_run=False)
        fake_result = completed(["uv", "sync"])
        with patch("subprocess.run", return_value=fake_result) as mock_run:
            ctx.run_command(["uv", "sync"])
            mock_run.assert_called_once()

        # Rich writes to its own buffer; capture via Console injection isn't
        # straightforward with capsys, so we verify subprocess was called with
        # the unmodified command.
        args, _ = mock_run.call_args
        assert args[0] == ["uv", "sync"]

    def test_passes_cwd_to_subprocess(self, tmp_path):
        ctx = make_ctx(dry_run=False, project_dir=tmp_path)
        fake_result = completed(["uv", "sync"])
        with patch("subprocess.run", return_value=fake_result) as mock_run:
            ctx.run_command(["uv", "sync"], cwd=tmp_path / "sub")
        _, kwargs = mock_run.call_args
        assert kwargs["cwd"] == str(tmp_path / "sub")

    def test_uses_project_dir_when_no_cwd(self, tmp_path):
        ctx = make_ctx(dry_run=False, project_dir=tmp_path)
        fake_result = completed(["uv", "sync"])
        with patch("subprocess.run", return_value=fake_result) as mock_run:
            ctx.run_command(["uv", "sync"])
        _, kwargs = mock_run.call_args
        assert kwargs["cwd"] == str(tmp_path)

    def test_does_not_append_dry_run_flag_in_live_mode(self):
        ctx = make_ctx(dry_run=False)
        fake_result = completed(["nx", "g"])
        with patch("subprocess.run", return_value=fake_result) as mock_run:
            ctx.run_command(["nx", "g"], supports_dry_run=True)
        args, _ = mock_run.call_args
        assert "--dry-run" not in args[0]

    def test_passes_env_overrides_to_subprocess(self):
        ctx = make_ctx(dry_run=False)
        fake_result = completed(["npx", "nx", "init"])
        with patch("subprocess.run", return_value=fake_result) as mock_run:
            ctx.run_command(["npx", "nx", "init"], env={"NX_NO_CLOUD": "true"})
        _, kwargs = mock_run.call_args
        assert kwargs["env"]["NX_NO_CLOUD"] == "true"


# ---------------------------------------------------------------------------
# run_command — dry-run mode, nested CLI does NOT support --dry-run
# ---------------------------------------------------------------------------


class TestRunCommandDryRunUnsupported:
    def test_skips_subprocess_execution(self):
        ctx = make_ctx(dry_run=True)
        with patch("subprocess.run") as mock_run:
            ctx.run_command(["git", "init"])
        mock_run.assert_not_called()

    def test_returns_zero_exit_completed_process(self):
        ctx = make_ctx(dry_run=True)
        with patch("subprocess.run"):
            result = ctx.run_command(["git", "init"])
        assert result.returncode == 0

    def test_command_shown_in_output(self, capsys):
        ctx = make_ctx(dry_run=True)
        # Redirect Rich output to a plain console writing to stdout
        with patch("rpr.ui.renderers.console", Console(highlight=False, no_color=True)):
            with patch("subprocess.run"):
                ctx.run_command(["git", "init", "--quiet"])
        captured = capsys.readouterr().out
        assert "git init --quiet" in captured

    def test_dry_run_label_shown(self, capsys):
        ctx = make_ctx(dry_run=True)
        with patch("rpr.ui.renderers.console", Console(highlight=False, no_color=True)):
            with patch("subprocess.run"):
                ctx.run_command(["git", "init"])
        captured = capsys.readouterr().out
        assert "DRY RUN" in captured

    def test_dry_run_shows_env_prefix(self, capsys):
        ctx = make_ctx(dry_run=True)
        with patch("rpr.ui.renderers.console", Console(highlight=False, no_color=True)):
            with patch("subprocess.run"):
                ctx.run_command(["npx", "nx", "init"], env={"NX_NO_CLOUD": "true"})
        captured = capsys.readouterr().out
        assert "NX_NO_CLOUD=true npx nx init" in captured


# ---------------------------------------------------------------------------
# run_command — dry-run mode, nested CLI DOES support --dry-run
# ---------------------------------------------------------------------------


class TestRunCommandDryRunSupported:
    def test_appends_dry_run_flag_to_command(self):
        ctx = make_ctx(dry_run=True)
        fake_result = completed(["nx", "g", "--dry-run"])
        with patch("subprocess.run", return_value=fake_result) as mock_run:
            ctx.run_command(["nx", "g"], supports_dry_run=True)
        args, _ = mock_run.call_args
        assert args[0] == ["nx", "g", "--dry-run"]

    def test_actually_executes_subprocess(self):
        ctx = make_ctx(dry_run=True)
        fake_result = completed(["nx", "g", "--dry-run"])
        with patch("subprocess.run", return_value=fake_result) as mock_run:
            ctx.run_command(["nx", "g"], supports_dry_run=True)
        mock_run.assert_called_once()

    def test_does_not_show_would_run_label(self, capsys):
        ctx = make_ctx(dry_run=True)
        fake_result = completed(["nx", "g", "--dry-run"])
        with patch("rpr.ui.renderers.console", Console(highlight=False, no_color=True)):
            with patch("subprocess.run", return_value=fake_result):
                ctx.run_command(["nx", "g"], supports_dry_run=True)
        captured = capsys.readouterr().out
        assert "Would run" not in captured

    def test_shows_rpr_running_prefix(self, capsys):
        ctx = make_ctx(dry_run=True)
        fake_result = completed(["nx", "g", "--dry-run"])
        with patch("rpr.ui.renderers.console", Console(highlight=False, no_color=True)):
            with patch("subprocess.run", return_value=fake_result):
                ctx.run_command(["nx", "g"], supports_dry_run=True)
        captured = capsys.readouterr().out
        assert "[rpr] Running:" in captured


# ---------------------------------------------------------------------------
# preview_dependencies
# ---------------------------------------------------------------------------


class TestPreviewDependencies:
    def test_dry_run_shows_dependency_groups(self, capsys):
        ctx = make_ctx(dry_run=True)
        with patch("rpr.context.console", Console(highlight=False, no_color=True)):
            ctx.preview_dependencies(
                manager="uv",
                target="packages/python/domain",
                runtime=["sqlmodel", "asyncpg"],
                dev=["pytest"],
            )
        captured = capsys.readouterr().out
        assert "Would install uv dependencies for packages/python/domain" in captured
        assert "runtime=[sqlmodel, asyncpg]" in captured
        assert "dev=[pytest]" in captured

    def test_live_mode_shows_installing_message(self, capsys):
        ctx = make_ctx(dry_run=False)
        with patch("rpr.context.console", Console(highlight=False, no_color=True)):
            ctx.preview_dependencies(
                manager="npm",
                target="packages/node/sb",
                runtime=["@storybook/react-vite"],
            )
        captured = capsys.readouterr().out
        assert "Installing npm dependencies for packages/node/sb" in captured
        assert "runtime=[@storybook/react-vite]" in captured


# ---------------------------------------------------------------------------
# write_file
# ---------------------------------------------------------------------------


class TestWriteFile:
    def test_creates_file_in_live_mode(self, tmp_path):
        ctx = make_ctx(dry_run=False, project_dir=tmp_path)
        target = tmp_path / "sub" / "hello.txt"
        ctx.write_file(target, "hello world")
        assert target.read_text() == "hello world"

    def test_skips_file_creation_in_dry_run(self, tmp_path):
        ctx = make_ctx(dry_run=True, project_dir=tmp_path)
        target = tmp_path / "should_not_exist.txt"
        ctx.write_file(target, "content")
        assert not target.exists()

    def test_dry_run_shows_would_create(self, tmp_path, capsys):
        ctx = make_ctx(dry_run=True, project_dir=tmp_path)
        with patch("rpr.ui.renderers.console", Console(highlight=False, no_color=True)):
            ctx.write_file(tmp_path / "f.txt", "line1\nline2")
        captured = capsys.readouterr().out
        assert "Would create" in captured

    def test_dry_run_renders_markdown_preview_for_markdown_files(
        self, tmp_path, capsys
    ):
        ctx = make_ctx(dry_run=True, project_dir=tmp_path)
        preview_console = Console(highlight=False, no_color=True)
        with (
            patch("rpr.context.console", preview_console),
            patch("rpr.ui.markdown.console", preview_console),
        ):
            ctx.write_file(
                tmp_path / "notes.md",
                "# Notes\n\n- first item\n- second item\n",
                preview_markdown=True,
                markdown_title="Notes Preview",
            )
        captured = capsys.readouterr().out
        assert "Would create" in captured
        assert "Notes Preview" in captured
        assert "1 │" not in captured

    def test_markdown_preview_does_not_mutate_written_content(self, tmp_path):
        ctx = make_ctx(dry_run=False, project_dir=tmp_path)
        target = tmp_path / "notes.md"
        content = "# Notes\n\n- first item\n- second item\n"
        preview_console = Console(highlight=False, no_color=True)
        with (
            patch("rpr.context.console", preview_console),
            patch("rpr.ui.markdown.console", preview_console),
        ):
            ctx.write_file(target, content, preview_markdown=True)
        assert target.read_text() == content


# ---------------------------------------------------------------------------
# update_file
# ---------------------------------------------------------------------------


class TestUpdateFile:
    def test_writes_content_in_live_mode(self, tmp_path):
        ctx = make_ctx(dry_run=False, project_dir=tmp_path)
        target = tmp_path / "existing.txt"
        target.write_text("old")
        ctx.update_file(target, "new content")
        assert target.read_text() == "new content"

    def test_skips_write_in_dry_run(self, tmp_path):
        ctx = make_ctx(dry_run=True, project_dir=tmp_path)
        target = tmp_path / "existing.txt"
        target.write_text("original")
        ctx.update_file(target, "should not apply")
        assert target.read_text() == "original"

    def test_dry_run_shows_would_update(self, tmp_path, capsys):
        ctx = make_ctx(dry_run=True, project_dir=tmp_path)
        with patch("rpr.ui.renderers.console", Console(highlight=False, no_color=True)):
            ctx.update_file(tmp_path / "f.txt", "new")
        captured = capsys.readouterr().out
        assert "Would update" in captured


# ---------------------------------------------------------------------------
# ensure_dir
# ---------------------------------------------------------------------------


class TestEnsureDir:
    def test_creates_directory_in_live_mode(self, tmp_path):
        ctx = make_ctx(dry_run=False, project_dir=tmp_path)
        new_dir = tmp_path / "a" / "b" / "c"
        ctx.ensure_dir(new_dir)
        assert new_dir.is_dir()

    def test_skips_directory_creation_in_dry_run(self, tmp_path):
        ctx = make_ctx(dry_run=True, project_dir=tmp_path)
        new_dir = tmp_path / "should_not_exist"
        ctx.ensure_dir(new_dir)
        assert not new_dir.exists()

    def test_dry_run_shows_would_create_directory(self, tmp_path, capsys):
        ctx = make_ctx(dry_run=True, project_dir=tmp_path)
        with patch("rpr.ui.console.console", Console(highlight=False, no_color=True)):
            ctx.ensure_dir(tmp_path / "newdir")
        captured = capsys.readouterr().out
        assert "Would create directory" in captured
