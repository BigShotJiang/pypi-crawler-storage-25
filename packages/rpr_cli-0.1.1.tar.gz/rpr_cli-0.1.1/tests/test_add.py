from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from rpr.cli import app
import yaml

runner = CliRunner()


def _repo_scaffolds_dir() -> Path:
    return Path(__file__).resolve().parent.parent / "src" / "rpr" / "scaffolds"


def _write_rpr_config(scaffolds_dir: Path, *, name: str = "test-app") -> None:
    config = {
        "source": str(scaffolds_dir / "instructions"),
        "variables": {
            "name": name,
            "name_underscore": name.replace("-", "_"),
            "name-of-app": name,
            "NamePascal": "".join(part.capitalize() for part in name.split("-")),
        },
    }
    Path(".rpr.yaml").write_text(yaml.dump(config))


def test_add_template_list():
    with runner.isolated_filesystem():
        # Need to point to a valid source for the list command to not fail on _find_source_dir
        # but actually --list should work even without a valid source if we don't resolve paths?
        # Wait, my new --list tries to load config.

        result = runner.invoke(app, ["add", "template", "--list"])
        assert result.exit_code == 0
        assert "domain_settings" in result.stdout
        assert "domain_container" in result.stdout
        assert "mapper_util" in result.stdout
        assert "sticky_navigation" in result.stdout
        # Should show placeholders if no name/config
        assert "{name_underscore}" in result.stdout


def test_add_template_list_with_name():
    with runner.isolated_filesystem():
        result = runner.invoke(app, ["add", "template", "--list", "--name", "my-app"])
        assert result.exit_code == 0
        assert "my_app_domain" in result.stdout
        assert "my-app-ui" in result.stdout


def test_add_template_execution(monkeypatch):
    with runner.isolated_filesystem():
        project_dir = Path.cwd()

        scaffolds_dir = _repo_scaffolds_dir()
        _write_rpr_config(scaffolds_dir)

        result = runner.invoke(app, ["add", "template", "mapper_util", "--force"])
        assert result.exit_code == 0

        target_path = (
            project_dir
            / "packages/python/domain/src/test_app_domain/utils/mapper_util.py"
        )
        assert target_path.exists()
        content = target_path.read_text()
        assert "from test_app_domain.repos import BaseRepo" in content


def test_add_domain_settings_template_execution():
    with runner.isolated_filesystem():
        project_dir = Path.cwd()
        scaffolds_dir = _repo_scaffolds_dir()
        _write_rpr_config(scaffolds_dir)

        result = runner.invoke(app, ["add", "template", "domain_settings", "--force"])
        assert result.exit_code == 0, result.stdout

        target_path = (
            project_dir
            / "packages/python/domain/src/test_app_domain/config/settings.py"
        )
        assert target_path.exists()

        content = target_path.read_text()
        assert "class Settings(BaseSettings):" in content
        assert (
            'db_host: str = Field(default="localhost", description="Database host")'
            in content
        )
        assert (
            'db_encrypt_key: bytes | None = Field(default=None, description="Fernet encryption key")'
            in content
        )
        assert (
            'httpx_max_connections: int = Field(default=100, description="Maximum HTTP connections")'
            in content
        )
        assert "def database_url(self) -> str:" in content
        assert 'f"?sslmode={self.db_sslmode}"' in content


def test_add_domain_container_template_execution():
    with runner.isolated_filesystem():
        project_dir = Path.cwd()
        scaffolds_dir = _repo_scaffolds_dir()
        _write_rpr_config(scaffolds_dir)

        result = runner.invoke(app, ["add", "template", "domain_container", "--force"])
        assert result.exit_code == 0, result.stdout

        target_path = (
            project_dir
            / "packages/python/domain/src/test_app_domain/config/container.py"
        )
        assert target_path.exists()

        content = target_path.read_text()
        assert "from test_app_domain.config.settings import Settings" in content
        assert "class Container(containers.DeclarativeContainer):" in content
        assert "config = providers.Singleton(Settings)" in content
        assert "settings.database_url" in content
        assert "timeout=config.provided.http_timeout" in content
        assert "max_keepalive_connections=config.provided.http_max_keepalive" in content
        assert "override __new__" in content


def test_add_template_dry_run():
    with runner.isolated_filesystem():
        scaffolds_dir = _repo_scaffolds_dir()

        result = runner.invoke(
            app,
            [
                "add",
                "template",
                "sticky_navigation",
                "--name",
                "my-app",
                "--source",
                str(scaffolds_dir),
                "--dry-run",
            ],
        )
        assert result.exit_code == 0
        assert "[DRY RUN] Would create" in result.stdout
        assert (
            "packages/node/my-app-ui/src/hooks/useStateNavigation.ts" in result.stdout
        )
        # Verify content is shown in dry run
        assert "export const useStateNavigation" in result.stdout
