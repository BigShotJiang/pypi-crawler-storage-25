from typing import Literal, TypedDict


Language = Literal["python", "typescript", "javascript", "rust", "cpp"]


class DependencyNode(TypedDict):
    abs_path: str
    rel_path: str
    language: Language


class DependencyGraphPayload(TypedDict):
    nodes: list[DependencyNode]
    edges: dict[str, list[str]]
    reverse_edges: dict[str, list[str]]
    cycles: list[list[str]]


def init_env() -> None: ...
def close_env() -> None: ...
def reset_logging() -> None: ...
def build_dependency_graph(abs_root: str) -> DependencyGraphPayload: ...