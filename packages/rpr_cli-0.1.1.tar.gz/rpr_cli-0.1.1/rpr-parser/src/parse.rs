use crate::walker::{Language, SourceFile};
use tree_sitter::{Language as TsLanguage, Node, Parser};

pub fn parse_imports(file: &SourceFile, source: &[u8]) -> Vec<String> {
    match file.language {
        Language::Python => parse_python(source),
        Language::TypeScript => parse_typescript(source, file),
        Language::JavaScript => parse_javascript(source),
        Language::Rust => parse_rust(source),
        Language::Cpp => parse_cpp(source),
    }
}

fn node_text<'a>(node: Node, source: &'a [u8]) -> &'a str {
    node.utf8_text(source).unwrap_or("")
}

// ---------------------------------------------------------------------------
// Python
// ---------------------------------------------------------------------------

fn parse_python(source: &[u8]) -> Vec<String> {
    let mut parser = Parser::new();
    parser
        .set_language(&TsLanguage::new(tree_sitter_python::LANGUAGE))
        .expect("python grammar");

    let tree = match parser.parse(source, None) {
        Some(t) => t,
        None => return vec![],
    };

    let mut imports = Vec::new();
    let root = tree.root_node();

    let mut cursor = root.walk();
    let mut stack = vec![root];
    while let Some(node) = stack.pop() {
        match node.kind() {
            "import_statement" => {
                // import foo, import foo.bar
                for child in node.children(&mut cursor) {
                    if child.kind() == "dotted_name" || child.kind() == "aliased_import" {
                        let name_node = if child.kind() == "aliased_import" {
                            child.child(0)
                        } else {
                            Some(child)
                        };
                        if let Some(n) = name_node {
                            let text = node_text(n, source).trim().to_string();
                            if !text.is_empty() {
                                imports.push(text);
                            }
                        }
                    }
                }
            }
            "import_from_statement" => {
                // AST: module_name is either dotted_name (absolute) or relative_import (relative)
                // e.g. `from rpr.context import RunContext` → dotted_name: "rpr.context"
                // e.g. `from . import utils`              → relative_import: import_prefix "."
                // e.g. `from ..map import walker`         → relative_import: import_prefix ".." + dotted_name "map"
                let raw = {
                    let mut cur = node.walk();
                    let mut result = String::new();
                    for child in node.children(&mut cur) {
                        match child.kind() {
                            "dotted_name" => {
                                // Absolute from-import: first dotted_name is the module
                                result = node_text(child, source).trim().to_string();
                                break;
                            }
                            "relative_import" => {
                                let mut dots = String::new();
                                let mut module_name = String::new();
                                let mut rc = child.walk();
                                for rchild in child.children(&mut rc) {
                                    match rchild.kind() {
                                        "import_prefix" => {
                                            dots = node_text(rchild, source).to_string();
                                        }
                                        "." | "..." => {
                                            dots.push_str(node_text(rchild, source));
                                        }
                                        "dotted_name" => {
                                            module_name =
                                                node_text(rchild, source).trim().to_string();
                                        }
                                        _ => {}
                                    }
                                }
                                result = if module_name.is_empty() {
                                    dots
                                } else {
                                    format!("{}{}", dots, module_name)
                                };
                                break;
                            }
                            _ => {}
                        }
                    }
                    result
                };
                if !raw.is_empty() {
                    imports.push(raw);
                }
            }
            _ => {
                let mut c = node.walk();
                for child in node.children(&mut c) {
                    stack.push(child);
                }
            }
        }
    }
    imports
}

// ---------------------------------------------------------------------------
// TypeScript
// ---------------------------------------------------------------------------

fn parse_typescript(source: &[u8], file: &SourceFile) -> Vec<String> {
    let mut parser = Parser::new();
    let lang = if file
        .rel_path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("")
        == "tsx"
    {
        TsLanguage::new(tree_sitter_typescript::LANGUAGE_TSX)
    } else {
        TsLanguage::new(tree_sitter_typescript::LANGUAGE_TYPESCRIPT)
    };
    parser.set_language(&lang).expect("typescript grammar");
    extract_js_ts_imports(source, &mut parser)
}

// ---------------------------------------------------------------------------
// JavaScript
// ---------------------------------------------------------------------------

fn parse_javascript(source: &[u8]) -> Vec<String> {
    let mut parser = Parser::new();
    parser
        .set_language(&TsLanguage::new(tree_sitter_javascript::LANGUAGE))
        .expect("javascript grammar");
    extract_js_ts_imports(source, &mut parser)
}

fn extract_js_ts_imports(source: &[u8], parser: &mut Parser) -> Vec<String> {
    let tree = match parser.parse(source, None) {
        Some(t) => t,
        None => return vec![],
    };

    let mut imports = Vec::new();
    let root = tree.root_node();
    let mut stack = vec![root];

    while let Some(node) = stack.pop() {
        match node.kind() {
            "import_statement" => {
                // import ... from "specifier"
                let mut cursor = node.walk();
                for child in node.children(&mut cursor) {
                    if child.kind() == "string" {
                        let raw = node_text(child, source).trim_matches('"').trim_matches('\'').to_string();
                        if !raw.is_empty() {
                            imports.push(raw);
                        }
                        break;
                    }
                }
            }
            "call_expression" => {
                // require("...") or import("...")
                let mut cursor = node.walk();
                let children: Vec<_> = node.children(&mut cursor).collect();
                if children.len() >= 2 {
                    let callee_text = node_text(children[0], source);
                    if callee_text == "require" || callee_text == "import" {
                        // arguments node
                        if let Some(args) = children.iter().find(|n| n.kind() == "arguments") {
                            let mut ac = args.walk();
                            for arg in args.children(&mut ac) {
                                if arg.kind() == "string" {
                                    let raw = node_text(arg, source)
                                        .trim_matches('"')
                                        .trim_matches('\'')
                                        .to_string();
                                    if !raw.is_empty() {
                                        imports.push(raw);
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
                // Still recurse into call expressions
                let mut c = node.walk();
                for child in node.children(&mut c) {
                    stack.push(child);
                }
                continue;
            }
            _ => {}
        }
        let mut c = node.walk();
        for child in node.children(&mut c) {
            stack.push(child);
        }
    }
    imports
}

// ---------------------------------------------------------------------------
// Rust
// ---------------------------------------------------------------------------

fn parse_rust(source: &[u8]) -> Vec<String> {
    let mut parser = Parser::new();
    parser
        .set_language(&TsLanguage::new(tree_sitter_rust::LANGUAGE))
        .expect("rust grammar");

    let tree = match parser.parse(source, None) {
        Some(t) => t,
        None => return vec![],
    };

    let mut imports = Vec::new();
    let root = tree.root_node();
    let mut stack = vec![root];

    while let Some(node) = stack.pop() {
        match node.kind() {
            "use_declaration" => {
                // Extract the full path text (child after `use` keyword)
                let mut cursor = node.walk();
                for child in node.children(&mut cursor) {
                    match child.kind() {
                        "use" | ";" => continue,
                        _ => {
                            let text = node_text(child, source).trim().to_string();
                            if !text.is_empty() {
                                imports.push(text);
                            }
                            break;
                        }
                    }
                }
            }
            "mod_item" => {
                // Only `mod foo;` (without a body block), not `mod foo { ... }`
                let has_body = {
                    let mut cursor = node.walk();
                    let result = node.children(&mut cursor).any(|c| c.kind() == "declaration_list");
                    result
                };
                if !has_body {
                    let mut cursor = node.walk();
                    for child in node.children(&mut cursor) {
                        if child.kind() == "identifier" {
                            let name = node_text(child, source).to_string();
                            imports.push(name);
                            break;
                        }
                    }
                }
            }
            "extern_crate_declaration" => {
                let mut cursor = node.walk();
                for child in node.children(&mut cursor) {
                    if child.kind() == "identifier" {
                        let name = node_text(child, source).to_string();
                        imports.push(format!("extern::{}", name));
                        break;
                    }
                }
            }
            _ => {}
        }
        let mut c = node.walk();
        for child in node.children(&mut c) {
            stack.push(child);
        }
    }
    imports
}

// ---------------------------------------------------------------------------
// C / C++
// ---------------------------------------------------------------------------

fn parse_cpp(source: &[u8]) -> Vec<String> {
    let mut parser = Parser::new();
    parser
        .set_language(&TsLanguage::new(tree_sitter_cpp::LANGUAGE))
        .expect("cpp grammar");

    let tree = match parser.parse(source, None) {
        Some(t) => t,
        None => return vec![],
    };

    let mut imports = Vec::new();
    let root = tree.root_node();
    let mut stack = vec![root];

    while let Some(node) = stack.pop() {
        if node.kind() == "preproc_include" {
            let mut cursor = node.walk();
            for child in node.children(&mut cursor) {
                match child.kind() {
                    "string_literal" => {
                        // Quoted include — keep it (strip surrounding quotes)
                        let raw = node_text(child, source)
                            .trim_matches('"')
                            .to_string();
                        if !raw.is_empty() {
                            imports.push(raw);
                        }
                    }
                    "system_lib_string" => {
                        // Angle-bracket include — drop
                    }
                    _ => {}
                }
            }
        }
        let mut c = node.walk();
        for child in node.children(&mut c) {
            stack.push(child);
        }
    }
    imports
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::walker::{Language, SourceFile};
    use std::path::PathBuf;

    fn py_file() -> SourceFile {
        SourceFile {
            abs_path: PathBuf::from("/proj/main.py"),
            rel_path: PathBuf::from("main.py"),
            language: Language::Python,
        }
    }

    fn ts_file() -> SourceFile {
        SourceFile {
            abs_path: PathBuf::from("/proj/src/index.ts"),
            rel_path: PathBuf::from("src/index.ts"),
            language: Language::TypeScript,
        }
    }

    fn tsx_file() -> SourceFile {
        SourceFile {
            abs_path: PathBuf::from("/proj/src/App.tsx"),
            rel_path: PathBuf::from("src/App.tsx"),
            language: Language::TypeScript,
        }
    }

    fn js_file() -> SourceFile {
        SourceFile {
            abs_path: PathBuf::from("/proj/src/index.js"),
            rel_path: PathBuf::from("src/index.js"),
            language: Language::JavaScript,
        }
    }

    fn rs_file() -> SourceFile {
        SourceFile {
            abs_path: PathBuf::from("/proj/src/lib.rs"),
            rel_path: PathBuf::from("src/lib.rs"),
            language: Language::Rust,
        }
    }

    fn cpp_file() -> SourceFile {
        SourceFile {
            abs_path: PathBuf::from("/proj/src/main.cpp"),
            rel_path: PathBuf::from("src/main.cpp"),
            language: Language::Cpp,
        }
    }

    #[test]
    fn test_python_import_statement() {
        let f = py_file();
        let src = b"import os\nimport sys";
        let result = parse_imports(&f, src);
        assert!(result.contains(&"os".to_string()));
        assert!(result.contains(&"sys".to_string()));
    }

    #[test]
    fn test_python_dotted_import() {
        let f = py_file();
        let src = b"import rpr.context";
        let result = parse_imports(&f, src);
        assert!(result.contains(&"rpr.context".to_string()));
    }

    #[test]
    fn test_python_from_import() {
        let f = py_file();
        let src = b"from rpr.context import RunContext";
        let result = parse_imports(&f, src);
        assert!(result.contains(&"rpr.context".to_string()));
    }

    #[test]
    fn test_python_relative_import() {
        let f = py_file();
        let src = b"from . import utils";
        let result = parse_imports(&f, src);
        assert!(result.iter().any(|s| s.starts_with('.')));
    }

    #[test]
    fn test_python_relative_dotted() {
        let f = py_file();
        let src = b"from ..map import walker";
        let result = parse_imports(&f, src);
        assert!(result.iter().any(|s| s.starts_with("..")));
    }

    #[test]
    fn test_ts_import_statement() {
        let f = ts_file();
        let src = b"import { foo } from './bar';";
        let result = parse_imports(&f, src);
        assert!(result.contains(&"./bar".to_string()));
    }

    #[test]
    fn test_tsx_import() {
        let f = tsx_file();
        let src = b"import React from 'react';";
        let result = parse_imports(&f, src);
        assert!(result.contains(&"react".to_string()));
    }

    #[test]
    fn test_js_require() {
        let f = js_file();
        let src = b"const x = require('./utils');";
        let result = parse_imports(&f, src);
        assert!(result.contains(&"./utils".to_string()));
    }

    #[test]
    fn test_js_dynamic_import() {
        let f = js_file();
        let src = b"const mod = import('./lazy');";
        let result = parse_imports(&f, src);
        assert!(result.contains(&"./lazy".to_string()));
    }

    #[test]
    fn test_rust_use_declaration() {
        let f = rs_file();
        let src = b"use crate::map::walker;";
        let result = parse_imports(&f, src);
        assert!(result.iter().any(|s| s.contains("map") && s.contains("walker")));
    }

    #[test]
    fn test_rust_mod_item() {
        let f = rs_file();
        let src = b"mod walker;";
        let result = parse_imports(&f, src);
        assert!(result.contains(&"walker".to_string()));
    }

    #[test]
    fn test_rust_mod_with_body_not_included() {
        let f = rs_file();
        let src = b"mod walker { pub fn foo() {} }";
        let result = parse_imports(&f, src);
        // mod with body should NOT appear in imports
        assert!(!result.contains(&"walker".to_string()));
    }

    #[test]
    fn test_cpp_quoted_include() {
        let f = cpp_file();
        let src = b"#include \"utils.h\"";
        let result = parse_imports(&f, src);
        assert!(result.contains(&"utils.h".to_string()));
    }

    #[test]
    fn test_cpp_system_include_dropped() {
        let f = cpp_file();
        let src = b"#include <stdio.h>";
        let result = parse_imports(&f, src);
        assert!(result.is_empty());
    }

    #[test]
    fn test_cpp_mixed_includes() {
        let f = cpp_file();
        let src = b"#include <vector>\n#include \"mylib.h\"";
        let result = parse_imports(&f, src);
        assert_eq!(result, vec!["mylib.h".to_string()]);
    }

    #[test]
    fn test_malformed_python_no_panic() {
        let f = py_file();
        let src = b"import os\ndef broken(:\n    pass";
        // Should not panic, returns whatever was found
        let result = parse_imports(&f, src);
        let _ = result; // Just verify it doesn't panic
    }

    #[test]
    fn test_empty_source_no_panic() {
        let f = py_file();
        let result = parse_imports(&f, b"");
        assert!(result.is_empty());
    }
}
