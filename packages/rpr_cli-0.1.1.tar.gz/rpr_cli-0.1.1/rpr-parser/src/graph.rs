use crate::parse::parse_imports;
use crate::resolve::resolve_imports;
use crate::walker::{crawl, SourceFile};
use rayon::prelude::*;
use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};

pub struct GraphPayload {
    pub nodes: Vec<SourceFile>,
    pub edges: HashMap<String, Vec<String>>,
    pub reverse_edges: HashMap<String, Vec<String>>,
    pub cycles: Vec<Vec<String>>,
}

pub fn build(abs_root: String) -> Result<GraphPayload, String> {
    let root = Path::new(&abs_root);
    let files = crawl(root);

    // Build a lookup index: rel_path -> index in files vec
    let index: HashMap<PathBuf, usize> = files
        .iter()
        .enumerate()
        .map(|(i, f)| (f.rel_path.clone(), i))
        .collect();

    // Parallel parse + resolve
    let edges_raw: Vec<(usize, Vec<PathBuf>)> = files
        .par_iter()
        .enumerate()
        .filter_map(|(i, file)| {
            let source = match std::fs::read(&file.abs_path) {
                Ok(b) => b,
                Err(_) => return Some((i, vec![])),
            };
            let raw_imports = parse_imports(file, &source);
            let resolved = resolve_imports(file, &raw_imports, &index, &files);
            Some((i, resolved))
        })
        .collect();

    // Build forward edges (string rel_path -> vec of string rel_path), deduplicated
    let mut edges: HashMap<String, Vec<String>> = HashMap::new();
    for (src_idx, deps) in &edges_raw {
        if deps.is_empty() {
            continue;
        }
        let src_key = files[*src_idx].rel_path.to_string_lossy().to_string();
        let mut seen: HashSet<String> = HashSet::new();
        let mut dep_list: Vec<String> = Vec::new();
        for dep in deps {
            let dep_key = dep.to_string_lossy().to_string();
            if seen.insert(dep_key.clone()) {
                dep_list.push(dep_key);
            }
        }
        if !dep_list.is_empty() {
            edges.insert(src_key, dep_list);
        }
    }

    // Build reverse edges
    let mut reverse_edges: HashMap<String, Vec<String>> = HashMap::new();
    for (src, deps) in &edges {
        for dep in deps {
            reverse_edges
                .entry(dep.clone())
                .or_default()
                .push(src.clone());
        }
    }

    // Cycle detection: iterative DFS with white/gray/black coloring
    let cycles = detect_cycles(&edges);

    Ok(GraphPayload {
        nodes: files,
        edges,
        reverse_edges,
        cycles,
    })
}

// ---------------------------------------------------------------------------
// Cycle detection — iterative DFS with color marking
// White = 0 (unvisited), Gray = 1 (on stack), Black = 2 (done)
// ---------------------------------------------------------------------------

fn detect_cycles(edges: &HashMap<String, Vec<String>>) -> Vec<Vec<String>> {
    let mut color: HashMap<&str, u8> = HashMap::new();
    let mut cycles: Vec<Vec<String>> = Vec::new();

    for start in edges.keys() {
        if color.get(start.as_str()).copied().unwrap_or(0) == 0 {
            dfs_iterative(start, edges, &mut color, &mut cycles);
        }
    }

    cycles
}

fn dfs_iterative<'a>(
    start: &'a str,
    edges: &'a HashMap<String, Vec<String>>,
    color: &mut HashMap<&'a str, u8>,
    cycles: &mut Vec<Vec<String>>,
) {
    // Stack entries: (node, iterator_index, path_snapshot)
    // We use an explicit stack to avoid recursion depth issues.
    // Each entry is (node_key, child_index, current_path)
    let mut stack: Vec<(&'a str, usize, Vec<&'a str>)> = vec![(start, 0, vec![start])];
    color.insert(start, 1); // gray

    while let Some((node, child_idx, path)) = stack.last_mut() {
        let node = *node;
        let neighbors = edges.get(node).map(|v| v.as_slice()).unwrap_or(&[]);

        if *child_idx >= neighbors.len() {
            // All neighbors processed — mark black, pop
            color.insert(node, 2);
            stack.pop();
            continue;
        }

        let neighbor = neighbors[*child_idx].as_str();
        *child_idx += 1;

        match color.get(neighbor).copied().unwrap_or(0) {
            1 => {
                // Back edge — found a cycle. Trace path back to neighbor.
                let cycle_start = path
                    .iter()
                    .position(|&n| n == neighbor)
                    .unwrap_or(0);
                let mut cycle: Vec<String> = path[cycle_start..]
                    .iter()
                    .map(|s| s.to_string())
                    .collect();
                cycle.push(neighbor.to_string()); // close the cycle
                cycles.push(cycle);
            }
            0 => {
                // White — push onto stack
                let mut new_path = path.clone();
                new_path.push(neighbor);
                color.insert(neighbor, 1);
                stack.push((neighbor, 0, new_path));
            }
            _ => {
                // Black — already fully processed, no cycle here
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    fn edges(pairs: &[(&str, &[&str])]) -> HashMap<String, Vec<String>> {
        pairs
            .iter()
            .map(|(k, vs)| {
                (
                    k.to_string(),
                    vs.iter().map(|s| s.to_string()).collect(),
                )
            })
            .collect()
    }

    #[test]
    fn test_no_cycles_empty() {
        let e = edges(&[]);
        let cycles = detect_cycles(&e);
        assert!(cycles.is_empty());
    }

    #[test]
    fn test_no_cycles_linear_chain() {
        // A → B → C (no cycle)
        let e = edges(&[("A", &["B"]), ("B", &["C"])]);
        let cycles = detect_cycles(&e);
        assert!(cycles.is_empty());
    }

    #[test]
    fn test_simple_cycle() {
        // A → B → A
        let e = edges(&[("A", &["B"]), ("B", &["A"])]);
        let cycles = detect_cycles(&e);
        assert!(!cycles.is_empty());
        // Each cycle should start and end with the same node
        for cycle in &cycles {
            assert_eq!(cycle.first(), cycle.last());
        }
    }

    #[test]
    fn test_self_loop() {
        // A → A
        let e = edges(&[("A", &["A"])]);
        let cycles = detect_cycles(&e);
        assert!(!cycles.is_empty());
    }

    #[test]
    fn test_three_node_cycle() {
        // A → B → C → A
        let e = edges(&[("A", &["B"]), ("B", &["C"]), ("C", &["A"])]);
        let cycles = detect_cycles(&e);
        assert!(!cycles.is_empty());
    }

    #[test]
    fn test_reverse_edges_populated() {
        // build() integration would test this, but we test the logic directly
        let mut edges_map: HashMap<String, Vec<String>> = HashMap::new();
        edges_map.insert("A".to_string(), vec!["B".to_string()]);

        let mut reverse: HashMap<String, Vec<String>> = HashMap::new();
        for (src, deps) in &edges_map {
            for dep in deps {
                reverse.entry(dep.clone()).or_default().push(src.clone());
            }
        }
        assert_eq!(reverse["B"], vec!["A"]);
    }

    #[test]
    fn test_duplicate_edges_deduplicated() {
        // Simulate what build() does for dedup
        let deps = vec!["B".to_string(), "B".to_string(), "C".to_string()];
        let mut seen: HashSet<String> = HashSet::new();
        let deduped: Vec<String> = deps.into_iter().filter(|d| seen.insert(d.clone())).collect();
        assert_eq!(deduped.len(), 2);
        assert!(deduped.contains(&"B".to_string()));
        assert!(deduped.contains(&"C".to_string()));
    }

    #[test]
    fn test_build_on_empty_dir() {
        let tmp = tempfile::tempdir().unwrap();
        let result = build(tmp.path().to_string_lossy().to_string());
        assert!(result.is_ok());
        let payload = result.unwrap();
        assert!(payload.nodes.is_empty());
        assert!(payload.edges.is_empty());
        assert!(payload.cycles.is_empty());
    }

    #[test]
    fn test_build_discovers_single_file() {
        let tmp = tempfile::tempdir().unwrap();
        std::fs::write(tmp.path().join("main.py"), b"import os\n").unwrap();
        let result = build(tmp.path().to_string_lossy().to_string());
        assert!(result.is_ok());
        let payload = result.unwrap();
        assert_eq!(payload.nodes.len(), 1);
        assert_eq!(payload.nodes[0].language.as_str(), "python");
    }
}
