use log::info;
use std::env;

#[derive(Debug, Clone)]
pub struct Settings {
    pub database_url: String,
}

impl Settings {
    fn default_database_url() -> String {
        let home_dir = dirs::home_dir().expect("Could not determine the user's home directory");
        let dir_path = home_dir.join(".rpr").join("docs");
        info!("dir_path: {}", dir_path.to_string_lossy());
        let db_path = dir_path.join("rpr.db");
        info!("db_path: {}", db_path.to_string_lossy());
        // try to create path if it doesn't exist
        std::fs::create_dir_all(&dir_path).expect("Could not create directory for database");
        format!("sqlite://{}?mode=rwc", db_path.to_string_lossy())
    }

    pub fn from_env() -> Self {
        dotenvy::dotenv().ok();

        let database_url: String =
            env::var("DATABASE_URL").unwrap_or_else(|_| Self::default_database_url());
        info!("Using database URL: {}", database_url);
        Self { database_url }
    }
}
