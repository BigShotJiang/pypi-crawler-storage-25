use crate::config::settings::Settings;
use sea_orm::{ConnectOptions, Database, DatabaseConnection, DbErr};

#[derive(Debug, Clone)]
pub struct Container {
    pub settings: Settings,
    pub db: sea_orm::DatabaseConnection,
}

impl Container {
    async fn init_db(database_url: &str) -> Result<DatabaseConnection, DbErr> {
        let mut options = ConnectOptions::new(database_url.to_string());
        options.max_connections(5).min_connections(1);

        let db: DatabaseConnection = Database::connect(database_url).await?;
        assert!(db.ping().await.is_ok(), "Failed to ping the database");
        Ok(db)
    }

    pub async fn init() -> Result<Self, DbErr> {
        let settings: Settings = Settings::from_env();
        let db: DatabaseConnection = Self::init_db(&settings.database_url).await?;
        Ok(Self { settings, db })
    }

    pub async fn close(self) -> Result<(), DbErr> {
        log::info!("Closing database connection");
        self.db.close().await
    }
}
