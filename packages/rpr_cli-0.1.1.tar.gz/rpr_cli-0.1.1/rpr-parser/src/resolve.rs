use crate::walker::{Language, SourceFile};
use std::collections::HashMap;
use std::path::{Path, PathBuf};

const TS_JS_EXTENSIONS: &[&str] = &["ts", "tsx", "js", "jsx", "mjs", "cjs"];
const INDEX_NAMES: &[&str] = &["index.ts", "index.tsx", "index.js", "index.jsx", "index.mjs", "index.cjs"];

pub fn resolve_imports(
    file: &SourceFile,
    raw_imports: &[String],
    index: &HashMap<PathBuf, usize>,
    files: &[SourceFile],
) -> Vec<PathBuf> {
    raw_imports
        .iter()
        .filter_map(|raw| resolve_one(file, raw, index, files))
        .collect()
}

fn resolve_one(
    file: &SourceFile,
    raw: &str,
    index: &HashMap<PathBuf, usize>,
    files: &[SourceFile],
) -> Option<PathBuf> {
    match file.language {
        Language::Python => resolve_python(file, raw, index, files),
        Language::TypeScript | Language::JavaScript => resolve_ts_js(file, raw, index, files),
        Language::Rust => resolve_rust(file, raw, index, files),
        Language::Cpp => resolve_cpp(file, raw, index, files),
    }
}

// ---------------------------------------------------------------------------
// Python
// ---------------------------------------------------------------------------

fn resolve_python(
    file: &SourceFile,
    raw: &str,
    index: &HashMap<PathBuf, usize>,
    _files: &[SourceFile],
) -> Option<PathBuf> {
    // Handle relative imports: ".", ".foo", "..foo", etc.
    let dot_count = raw.chars().take_while(|&c| c == '.').count();

    let module_path = if dot_count > 0 {
        let rest = &raw[dot_count..];
        // Start from importer's directory, pop (dot_count - 1) levels for each extra dot
        let mut base = file.rel_path.parent()?.to_path_buf();
        for _ in 1..dot_count {
            base = base.parent().unwrap_or_else(|| Path::new("")).to_path_buf();
        }
        if rest.is_empty() {
            base
        } else {
            base.join(rest.replace('.', "/"))
        }
    } else {
        PathBuf::from(raw.replace('.', "/"))
    };

    // Try direct .py file
    let candidate_py = module_path.with_extension("py");
    if index.contains_key(&candidate_py) {
        return Some(candidate_py);
    }

    // Try __init__.py
    let candidate_init = module_path.join("__init__.py");
    if index.contains_key(&candidate_init) {
        return Some(candidate_init);
    }

    None
}

// ---------------------------------------------------------------------------
// TypeScript / JavaScript
// ---------------------------------------------------------------------------

fn resolve_ts_js(
    file: &SourceFile,
    raw: &str,
    index: &HashMap<PathBuf, usize>,
    _files: &[SourceFile],
) -> Option<PathBuf> {
    // Only resolve relative imports
    if !raw.starts_with("./") && !raw.starts_with("../") {
        return None;
    }

    let base = file.rel_path.parent()?;
    let joined = base.join(raw);
    // Normalize the path (remove . and ..)
    let normalized = normalize_path(&joined);

    // 1. Try as-is (in case it already has an extension)
    if index.contains_key(&normalized) {
        return Some(normalized.clone());
    }

    // 2. Try adding each extension
    for ext in TS_JS_EXTENSIONS {
        let candidate = normalized.with_extension(ext);
        if index.contains_key(&candidate) {
            return Some(candidate);
        }
    }

    // 3. Try as directory with index file
    for index_name in INDEX_NAMES {
        let candidate = normalized.join(index_name);
        if index.contains_key(&candidate) {
            return Some(candidate);
        }
    }

    None
}

// ---------------------------------------------------------------------------
// Rust
// ---------------------------------------------------------------------------

fn resolve_rust(
    file: &SourceFile,
    raw: &str,
    index: &HashMap<PathBuf, usize>,
    _files: &[SourceFile],
) -> Option<PathBuf> {
    // `mod foo;` entries are just the bare module name
    if !raw.contains("::") && !raw.starts_with("extern::") {
        let dir = file.rel_path.parent().unwrap_or_else(|| Path::new(""));
        // Try {dir}/foo.rs
        let candidate_rs = dir.join(format!("{}.rs", raw));
        if index.contains_key(&candidate_rs) {
            return Some(candidate_rs);
        }
        // Try {dir}/foo/mod.rs
        let candidate_mod = dir.join(raw).join("mod.rs");
        if index.contains_key(&candidate_mod) {
            return Some(candidate_mod);
        }
        return None;
    }

    // extern::name — external crate, drop
    if raw.starts_with("extern::") {
        return None;
    }

    // `use crate::X::Y` or `use super::X` — resolve within project
    let normalized = raw
        .trim_start_matches("crate::")
        .trim_start_matches("super::")
        .trim_start_matches("self::");

    // Remove glob and braces suffix: `map::walker::{foo, bar}` → `map::walker`
    let base = normalized
        .trim_end_matches("::*")
        .split("::{")
        .next()
        .unwrap_or(normalized);

    let path_segments: PathBuf = base.split("::").collect();

    // Try direct .rs file
    let candidate_rs = path_segments.with_extension("rs");
    if index.contains_key(&candidate_rs) {
        return Some(candidate_rs);
    }

    // Try mod.rs
    let candidate_mod = path_segments.join("mod.rs");
    if index.contains_key(&candidate_mod) {
        return Some(candidate_mod);
    }

    // Try with src/ prefix (common for lib crates)
    let src_rs = PathBuf::from("src").join(&candidate_rs);
    if index.contains_key(&src_rs) {
        return Some(src_rs);
    }
    let src_mod = PathBuf::from("src").join(&candidate_mod);
    if index.contains_key(&src_mod) {
        return Some(src_mod);
    }

    None
}

// ---------------------------------------------------------------------------
// C / C++
// ---------------------------------------------------------------------------

fn resolve_cpp(
    file: &SourceFile,
    raw: &str,
    index: &HashMap<PathBuf, usize>,
    _files: &[SourceFile],
) -> Option<PathBuf> {
    // Angle-bracket includes are already filtered out in parse.rs
    // Resolve relative to importer directory first
    let base = file.rel_path.parent().unwrap_or_else(|| Path::new(""));
    let candidate = base.join(raw);
    let normalized = normalize_path(&candidate);
    if index.contains_key(&normalized) {
        return Some(normalized);
    }

    // Search all discovered files for a matching filename
    // (handles include paths from project-internal include/ dirs)
    let target_name = Path::new(raw).file_name()?;
    for path in index.keys() {
        if path.file_name() == Some(target_name) {
            return Some(path.clone());
        }
    }

    None
}

// ---------------------------------------------------------------------------
// Path normalization (remove . and .. components)
// ---------------------------------------------------------------------------

fn normalize_path(path: &Path) -> PathBuf {
    let mut parts: Vec<&std::ffi::OsStr> = Vec::new();
    for component in path.components() {
        use std::path::Component;
        match component {
            Component::CurDir => {}
            Component::ParentDir => {
                parts.pop();
            }
            Component::Normal(p) => parts.push(p),
            Component::RootDir => parts.push(component.as_os_str()),
            Component::Prefix(_) => parts.push(component.as_os_str()),
        }
    }
    parts.iter().collect()
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::walker::{Language, SourceFile};
    use std::path::PathBuf;

    fn make_index(paths: &[&str]) -> (Vec<SourceFile>, HashMap<PathBuf, usize>) {
        let files: Vec<SourceFile> = paths
            .iter()
            .enumerate()
            .map(|(_i, p)| {
                let pb = PathBuf::from(p);
                let lang = match pb.extension().and_then(|e| e.to_str()).unwrap_or("") {
                    "py" => Language::Python,
                    "ts" | "tsx" => Language::TypeScript,
                    "js" | "jsx" | "mjs" | "cjs" => Language::JavaScript,
                    "rs" => Language::Rust,
                    _ => Language::Cpp,
                };
                SourceFile {
                    abs_path: PathBuf::from("/root").join(p),
                    rel_path: pb,
                    language: lang,
                }
            })
            .collect();
        let index: HashMap<PathBuf, usize> = files
            .iter()
            .enumerate()
            .map(|(i, f)| (f.rel_path.clone(), i))
            .collect();
        (files, index)
    }

    #[test]
    fn test_python_dotted_resolution() {
        let (files, index) = make_index(&["rpr/context.py", "rpr/map/walker.py"]);
        let importer = SourceFile {
            abs_path: PathBuf::from("/root/rpr/map/extractor.py"),
            rel_path: PathBuf::from("rpr/map/extractor.py"),
            language: Language::Python,
        };
        let result = resolve_imports(&importer, &["rpr.context".to_string()], &index, &files);
        assert_eq!(result, vec![PathBuf::from("rpr/context.py")]);
    }

    #[test]
    fn test_python_relative_import() {
        let (files, index) = make_index(&["rpr/map/walker.py", "rpr/map/extractor.py"]);
        let importer = SourceFile {
            abs_path: PathBuf::from("/root/rpr/map/extractor.py"),
            rel_path: PathBuf::from("rpr/map/extractor.py"),
            language: Language::Python,
        };
        let result = resolve_imports(&importer, &[".walker".to_string()], &index, &files);
        assert_eq!(result, vec![PathBuf::from("rpr/map/walker.py")]);
    }

    #[test]
    fn test_python_external_dropped() {
        let (files, index) = make_index(&["rpr/context.py"]);
        let importer = SourceFile {
            abs_path: PathBuf::from("/root/main.py"),
            rel_path: PathBuf::from("main.py"),
            language: Language::Python,
        };
        let result = resolve_imports(&importer, &["os".to_string()], &index, &files);
        assert!(result.is_empty());
    }

    #[test]
    fn test_ts_relative_resolution() {
        let (files, index) = make_index(&["src/map/walker.ts", "src/map/extractor.ts"]);
        let importer = SourceFile {
            abs_path: PathBuf::from("/root/src/map/extractor.ts"),
            rel_path: PathBuf::from("src/map/extractor.ts"),
            language: Language::TypeScript,
        };
        let result = resolve_imports(&importer, &["./walker".to_string()], &index, &files);
        assert_eq!(result, vec![PathBuf::from("src/map/walker.ts")]);
    }

    #[test]
    fn test_ts_non_relative_dropped() {
        let (files, index) = make_index(&["src/map/walker.ts"]);
        let importer = SourceFile {
            abs_path: PathBuf::from("/root/src/index.ts"),
            rel_path: PathBuf::from("src/index.ts"),
            language: Language::TypeScript,
        };
        let result = resolve_imports(&importer, &["react".to_string()], &index, &files);
        assert!(result.is_empty());
    }

    #[test]
    fn test_rust_mod_resolution() {
        let (files, index) = make_index(&["src/walker.rs", "src/lib.rs"]);
        let importer = SourceFile {
            abs_path: PathBuf::from("/root/src/lib.rs"),
            rel_path: PathBuf::from("src/lib.rs"),
            language: Language::Rust,
        };
        let result = resolve_imports(&importer, &["walker".to_string()], &index, &files);
        assert_eq!(result, vec![PathBuf::from("src/walker.rs")]);
    }

    #[test]
    fn test_rust_extern_crate_dropped() {
        let (files, index) = make_index(&["src/lib.rs"]);
        let importer = SourceFile {
            abs_path: PathBuf::from("/root/src/lib.rs"),
            rel_path: PathBuf::from("src/lib.rs"),
            language: Language::Rust,
        };
        let result = resolve_imports(&importer, &["extern::serde".to_string()], &index, &files);
        assert!(result.is_empty());
    }

    #[test]
    fn test_cpp_quoted_resolution() {
        let (files, index) = make_index(&["src/utils.h", "src/main.cpp"]);
        let importer = SourceFile {
            abs_path: PathBuf::from("/root/src/main.cpp"),
            rel_path: PathBuf::from("src/main.cpp"),
            language: Language::Cpp,
        };
        let result = resolve_imports(&importer, &["utils.h".to_string()], &index, &files);
        assert_eq!(result, vec![PathBuf::from("src/utils.h")]);
    }
}
