use config::container::Container;
use log::info;
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList};
use std::sync::{Mutex, OnceLock};
use tokio::runtime::Runtime;

mod config;
mod graph;
mod models;
mod parse;
mod repos;
mod resolve;
mod walker;

static LOGGING_INITIALIZED: OnceLock<pyo3_log::ResetHandle> = OnceLock::new();
static CONTAINER: OnceLock<Mutex<Option<Container>>> = OnceLock::new();

fn init_logging() {
    LOGGING_INITIALIZED.get_or_init(pyo3_log::init);
}

fn container_slot() -> &'static Mutex<Option<Container>> {
    CONTAINER.get_or_init(|| Mutex::new(None))
}

/// Resets the pyo3_log cache so it picks up the current Python logging configuration.
/// Call this from Python after configuring `logging.basicConfig(...)`.
#[pyfunction]
fn reset_logging() {
    if let Some(handle) = LOGGING_INITIALIZED.get() {
        handle.reset();
    }
}

/// Minimal Python-facing function for verifying the Rust extension loads.
#[pyfunction]
fn init_env(py: Python<'_>) -> PyResult<()> {
    init_logging();
    info!("Initializing environment and database connection...");

    py.detach(|| {
        let runtime = Runtime::new()
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;

        let container = runtime
            .block_on(Container::init())
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;

        let mut slot = container_slot().lock().map_err(|_| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Container mutex poisoned")
        })?;

        *slot = Some(container);
        Ok(())
    })
}

#[pyfunction]
fn close_env(py: Python<'_>) -> PyResult<()> {
    init_logging();
    info!("Closing environment and database connection...");
    py.detach(|| {
        let container = {
            let mut slot = container_slot().lock().map_err(|_| {
                PyErr::new::<pyo3::exceptions::PyRuntimeError, _>("Container mutex poisoned")
            })?;

            slot.take()
        };

        if let Some(container) = container {
            let runtime = Runtime::new()
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;

            runtime
                .block_on(container.close())
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
        }

        Ok(())
    })
}

/// Crawls the project rooted at `abs_root`, builds the dependency graph,
/// and returns a Python-serializable payload dict.
#[pyfunction]
fn build_dependency_graph(py: Python<'_>, abs_root: String) -> PyResult<Py<PyAny>> {
    let payload =
        graph::build(abs_root).map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))?;

    let dict = PyDict::new(py);

    // nodes: list[dict]
    let nodes_list = PyList::empty(py);
    for node in &payload.nodes {
        let node_dict = PyDict::new(py);
        node_dict.set_item("abs_path", node.abs_path.to_string_lossy().as_ref())?;
        node_dict.set_item("rel_path", node.rel_path.to_string_lossy().as_ref())?;
        node_dict.set_item("language", node.language.as_str())?;
        nodes_list.append(node_dict)?;
    }
    dict.set_item("nodes", nodes_list)?;

    // edges: dict[str, list[str]]
    let edges_dict = PyDict::new(py);
    for (src, deps) in &payload.edges {
        let dep_list = PyList::new(py, deps.iter().map(|s: &String| s.as_str()))?;
        edges_dict.set_item(src, dep_list)?;
    }
    dict.set_item("edges", edges_dict)?;

    // reverse_edges: dict[str, list[str]]
    let rev_dict = PyDict::new(py);
    for (tgt, srcs) in &payload.reverse_edges {
        let src_list = PyList::new(py, srcs.iter().map(|s: &String| s.as_str()))?;
        rev_dict.set_item(tgt, src_list)?;
    }
    dict.set_item("reverse_edges", rev_dict)?;

    // cycles: list[list[str]]
    let cycles_list = PyList::empty(py);
    for cycle in &payload.cycles {
        let cycle_list = PyList::new(py, cycle.iter().map(|s: &String| s.as_str()))?;
        cycles_list.append(cycle_list)?;
    }
    dict.set_item("cycles", cycles_list)?;

    Ok(dict.unbind().into_any())
}

#[pymodule]
fn rpr_parser(m: &Bound<'_, PyModule>) -> PyResult<()> {
    init_logging();
    // Register a tiny smoke-test function first so Python/Jupyter can confirm
    // the compiled module loaded before we move on to more complex APIs.
    m.add_function(wrap_pyfunction!(init_env, m)?)?;
    m.add_function(wrap_pyfunction!(close_env, m)?)?;
    m.add_function(wrap_pyfunction!(reset_logging, m)?)?;
    m.add_function(wrap_pyfunction!(build_dependency_graph, m)?)?;
    Ok(())
}
