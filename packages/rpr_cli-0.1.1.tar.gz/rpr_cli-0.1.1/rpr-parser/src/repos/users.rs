use crate::models::entities::users::{
    ActiveModel as UserActiveModel, Entity as UserEntity, Model as UserModel,
};
use crate::repos::base::Repository as BaseRepository;
use sea_orm::DatabaseConnection;

pub struct Repository {
    pub db: DatabaseConnection,
}

impl BaseRepository<UserModel, UserEntity, UserActiveModel> for Repository {
    fn db(&self) -> &DatabaseConnection {
        &self.db
    }
}
