use sea_orm::prelude::TextUuid;
use sea_orm::{
    ActiveModelBehavior, ActiveModelTrait, DatabaseConnection, DbErr, EntityTrait, IntoActiveModel,
    ModelTrait, PrimaryKeyTrait,
};

pub trait Repository<M, E, A>
where
    M: ModelTrait<Entity = E> + IntoActiveModel<A> + Send + Sync,
    E: EntityTrait<Model = M>,
    A: ActiveModelTrait<Entity = E> + ActiveModelBehavior + Send,
{
    fn db(&self) -> &DatabaseConnection;

    async fn get_all(&self) -> Result<Vec<M>, DbErr> {
        E::find().all(self.db()).await
    }

    async fn get_by_id(&self, id: TextUuid) -> Result<Option<M>, DbErr>
    where
        <<E as EntityTrait>::PrimaryKey as PrimaryKeyTrait>::ValueType: From<TextUuid>,
    {
        E::find_by_id(id).one(self.db()).await
    }

    async fn create(&self, entity: A) -> Result<M, DbErr> {
        entity.insert(self.db()).await
    }

    async fn update(&self, entity: A) -> Result<M, DbErr> {
        entity.update(self.db()).await
    }

    async fn delete(&self, id: TextUuid) -> Result<(), DbErr>
    where
        <<E as EntityTrait>::PrimaryKey as PrimaryKeyTrait>::ValueType: From<TextUuid>,
    {
        E::delete_by_id(id).exec(self.db()).await?;
        Ok(())
    }
}
