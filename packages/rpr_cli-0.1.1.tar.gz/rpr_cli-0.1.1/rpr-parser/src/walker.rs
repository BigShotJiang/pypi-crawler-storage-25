use ignore::WalkBuilder;
use std::path::{Path, PathBuf};

const IGNORED_DIRS: &[&str] = &[
    ".venv", "venv", ".env", "node_modules", "__pycache__",
    "dist", "build", ".nx", "target", ".git", "vendor",
];

#[derive(Debug, Clone, PartialEq)]
pub enum Language {
    Python,
    TypeScript,
    JavaScript,
    Rust,
    Cpp,
}

impl Language {
    pub fn as_str(&self) -> &'static str {
        match self {
            Language::Python => "python",
            Language::TypeScript => "typescript",
            Language::JavaScript => "javascript",
            Language::Rust => "rust",
            Language::Cpp => "cpp",
        }
    }
}

fn ext_to_lang(ext: &str) -> Option<Language> {
    match ext {
        "py" => Some(Language::Python),
        "ts" | "tsx" => Some(Language::TypeScript),
        "js" | "jsx" | "mjs" | "cjs" => Some(Language::JavaScript),
        "rs" => Some(Language::Rust),
        "cpp" | "cc" | "cxx" | "c" | "h" | "hpp" | "hxx" => Some(Language::Cpp),
        _ => None,
    }
}

#[derive(Debug, Clone)]
pub struct SourceFile {
    pub abs_path: PathBuf,
    pub rel_path: PathBuf,
    pub language: Language,
}

pub fn crawl(root: &Path) -> Vec<SourceFile> {
    let walker = WalkBuilder::new(root)
        .follow_links(false)
        .hidden(false) // don't auto-hide dot-files; IGNORED_DIRS handles them
        .git_ignore(true) // honour <root>/.gitignore when present
        .git_global(false) // reproducible: ignore ~/.gitignore_global
        .git_exclude(false) // reproducible: ignore .git/info/exclude
        .require_git(false) // work on non-git roots
        .filter_entry(|e| {
            if e.path_is_symlink() {
                return false;
            }
            // Hard-coded baseline: always prune these dirs regardless of gitignore
            if e.file_type().map_or(false, |ft| ft.is_dir()) {
                if let Some(name) = e.file_name().to_str() {
                    if IGNORED_DIRS.contains(&name) {
                        return false;
                    }
                }
            }
            true
        })
        .build();

    let mut files = Vec::new();
    for entry in walker.flatten() {
        if entry.path_is_symlink() || !entry.file_type().map_or(false, |ft| ft.is_file()) {
            continue;
        }
        let path = entry.path();
        let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("");
        if let Some(lang) = ext_to_lang(ext) {
            let rel_path = path.strip_prefix(root).unwrap_or(path).to_path_buf();
            files.push(SourceFile {
                abs_path: path.to_path_buf(),
                rel_path,
                language: lang,
            });
        }
    }
    files
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use tempfile::TempDir;

    fn make_temp() -> TempDir {
        tempfile::tempdir().unwrap()
    }

    fn touch(dir: &Path, rel: &str) {
        let p = dir.join(rel);
        if let Some(parent) = p.parent() {
            fs::create_dir_all(parent).unwrap();
        }
        fs::write(&p, b"").unwrap();
    }

    #[test]
    fn test_prunes_node_modules() {
        let tmp = make_temp();
        touch(tmp.path(), "src/main.py");
        touch(tmp.path(), "node_modules/lib.js");
        let files = crawl(tmp.path());
        assert_eq!(files.len(), 1);
        assert!(files[0].rel_path.starts_with("src"));
    }

    #[test]
    fn test_prunes_target() {
        let tmp = make_temp();
        touch(tmp.path(), "src/lib.rs");
        touch(tmp.path(), "target/debug/build.rs");
        let files = crawl(tmp.path());
        assert_eq!(files.len(), 1);
        assert_eq!(files[0].rel_path, PathBuf::from("src/lib.rs"));
    }

    #[test]
    fn test_prunes_venv() {
        let tmp = make_temp();
        touch(tmp.path(), "main.py");
        touch(tmp.path(), ".venv/lib/python3.12/site-packages/foo.py");
        let files = crawl(tmp.path());
        assert_eq!(files.len(), 1);
    }

    #[test]
    fn test_prunes_pycache() {
        let tmp = make_temp();
        touch(tmp.path(), "app.py");
        touch(tmp.path(), "__pycache__/app.cpython-312.pyc");
        // .pyc not in extensions, but let's also add a .py inside __pycache__
        touch(tmp.path(), "__pycache__/app.py");
        let files = crawl(tmp.path());
        assert_eq!(files.len(), 1);
        assert_eq!(files[0].rel_path, PathBuf::from("app.py"));
    }

    #[test]
    fn test_prunes_git() {
        let tmp = make_temp();
        touch(tmp.path(), "main.py");
        touch(tmp.path(), ".git/config");
        // .git/config has no recognized extension, but test directory is pruned
        let files = crawl(tmp.path());
        assert_eq!(files.len(), 1);
    }

    #[test]
    fn test_detects_python() {
        let tmp = make_temp();
        touch(tmp.path(), "foo.py");
        let files = crawl(tmp.path());
        assert_eq!(files[0].language, Language::Python);
    }

    #[test]
    fn test_detects_typescript() {
        let tmp = make_temp();
        touch(tmp.path(), "foo.ts");
        touch(tmp.path(), "bar.tsx");
        let files = crawl(tmp.path());
        assert_eq!(files.len(), 2);
        assert!(files.iter().all(|f| f.language == Language::TypeScript));
    }

    #[test]
    fn test_detects_javascript() {
        let tmp = make_temp();
        for ext in &["js", "jsx", "mjs", "cjs"] {
            touch(tmp.path(), &format!("foo.{}", ext));
        }
        let files = crawl(tmp.path());
        assert_eq!(files.len(), 4);
        assert!(files.iter().all(|f| f.language == Language::JavaScript));
    }

    #[test]
    fn test_detects_rust() {
        let tmp = make_temp();
        touch(tmp.path(), "lib.rs");
        let files = crawl(tmp.path());
        assert_eq!(files[0].language, Language::Rust);
    }

    #[test]
    fn test_detects_cpp() {
        let tmp = make_temp();
        for ext in &["cpp", "cc", "cxx", "c", "h", "hpp", "hxx"] {
            touch(tmp.path(), &format!("foo.{}", ext));
        }
        let files = crawl(tmp.path());
        assert_eq!(files.len(), 7);
        assert!(files.iter().all(|f| f.language == Language::Cpp));
    }

    #[test]
    fn test_skips_unknown_extensions() {
        let tmp = make_temp();
        touch(tmp.path(), "readme.md");
        touch(tmp.path(), "config.json");
        touch(tmp.path(), "main.py");
        let files = crawl(tmp.path());
        assert_eq!(files.len(), 1);
    }

    #[test]
    fn test_rel_path_correct() {
        let tmp = make_temp();
        touch(tmp.path(), "src/rpr/map/walker.py");
        let files = crawl(tmp.path());
        assert_eq!(files[0].rel_path, PathBuf::from("src/rpr/map/walker.py"));
    }

    #[test]
    fn test_abs_path_correct() {
        let tmp = make_temp();
        touch(tmp.path(), "main.py");
        let files = crawl(tmp.path());
        assert_eq!(files[0].abs_path, tmp.path().join("main.py"));
    }

    #[test]
    fn test_empty_dir() {
        let tmp = make_temp();
        let files = crawl(tmp.path());
        assert!(files.is_empty());
    }

    #[test]
    fn test_gitignore_excludes_node_modules_dir() {
        let tmp = make_temp();
        fs::write(tmp.path().join(".gitignore"), b"node_modules/\n").unwrap();
        touch(tmp.path(), "src/main.py");
        touch(tmp.path(), "node_modules/lib.js");
        let files = crawl(tmp.path());
        assert_eq!(files.len(), 1);
        assert!(files[0].rel_path.starts_with("src"));
    }

    #[test]
    fn test_gitignore_excludes_custom_secret_dir() {
        let tmp = make_temp();
        fs::write(tmp.path().join(".gitignore"), b"secret/\n").unwrap();
        touch(tmp.path(), "src/main.py");
        touch(tmp.path(), "secret/keys.py");
        let files = crawl(tmp.path());
        assert_eq!(files.len(), 1);
        assert!(files[0].rel_path.starts_with("src"));
    }

    #[test]
    fn test_gitignore_negation_re_includes_file() {
        let tmp = make_temp();
        fs::write(tmp.path().join(".gitignore"), b"*.py\n!important.py\n").unwrap();
        touch(tmp.path(), "ignored.py");
        touch(tmp.path(), "important.py");
        let files = crawl(tmp.path());
        assert_eq!(files.len(), 1);
        assert_eq!(files[0].rel_path, PathBuf::from("important.py"));
    }

    #[test]
    fn test_no_gitignore_falls_back_to_hard_coded() {
        let tmp = make_temp();
        touch(tmp.path(), "src/main.py");
        touch(tmp.path(), "node_modules/lib.js");
        // No .gitignore — hard-coded list still prunes node_modules
        let files = crawl(tmp.path());
        assert_eq!(files.len(), 1);
        assert!(files[0].rel_path.starts_with("src"));
    }
}
