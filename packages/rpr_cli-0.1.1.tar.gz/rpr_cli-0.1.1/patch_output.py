import sys
import re

content = """
def _render_topology_mermaid(
    topology: DirectoryTopology,
    assessment: ArchitectureAssessment,
) -> str:
    \"\"\"Render the Architecture Diagram from directory topology.

    1. Single-child empty directories (like "rpr-parser" -> "src") are collapsed.
    2. Deep directories are rendered as nested subgraphs showing the real structure.
    3. Edges connect the subgraphs to limit lines.
    \"\"\"
    # ── Step 1: dynamic forest roots from the root ("") ──
    collapsed_map: dict[str, str] = {}
    forest_roots: set[str] = set()

    root_node = topology.nodes.get("")
    if not root_node:
        return ""

    for child in root_node.children:
        curr = child
        while True:
            node = topology.nodes.get(curr)
            if not node:
                break
            if len(node.files) == 0 and len(node.children) == 1:
                curr = node.children[0]
            else:
                break
        forest_roots.add(curr)
        collapsed_map[curr] = curr

    rendered_dirs: set[str] = set()
    def _collect_dirs(d: str) -> None:
        rendered_dirs.add(d)
        node = topology.nodes.get(d)
        if node:
            for c in node.children:
                _collect_dirs(c)

    for fr in forest_roots:
        _collect_dirs(fr)

    # ── Step 2: derive edges between rendered directories ──
    active_edges: set[tuple[str, str]] = set()
    for edge in topology.edges.values():
        if edge.source in rendered_dirs and edge.target in rendered_dirs and edge.source != edge.target:
            active_edges.add((edge.source, edge.target))

    def _get_fr(d: str) -> str | None:
        for fr in forest_roots:
            if d == fr or d.startswith(fr + "/"):
                return fr
        return None

    active_forest_roots: set[str] = set()
    for src, tgt in active_edges:
        fr_src = _get_fr(src)
        fr_tgt = _get_fr(tgt)
        if fr_src: active_forest_roots.add(fr_src)
        if fr_tgt: active_forest_roots.add(fr_tgt)

    if not active_forest_roots:
        return ""

    # ── Step 3: assign roles from assessment ──────────────────────────────────
    entry_dirs = {sig.directory for sig in assessment.entry_directories}
    core_dirs = {sig.directory for sig in assessment.core_directories}
    leaf_dirs = set(assessment.leaf_directories)

    def _role(fr: str) -> str:
        if fr in entry_dirs: return "entry"
        if fr in core_dirs: return "core"
        if fr in leaf_dirs: return "leaf"
        for ed in entry_dirs:
            if fr.startswith(ed) or ed.startswith(fr): return "entry"
        for cd in core_dirs:
            if fr.startswith(cd) or cd.startswith(fr): return "core"
        for ld in leaf_dirs:
            if fr.startswith(ld) or ld.startswith(fr): return "leaf"
        return "other"

    lines: list[str] = []

    # ── Step 4: subgraph blocks (recursive) ───────────────────────────────────
    def _render_dir(d: str, label: str, depth: int) -> None:
        node = topology.nodes.get(d)
        if not node:
            return
        
        indent = "    " * depth
        sg_id = _sanitize_id(d)
        lines.append(f'{indent}subgraph {sg_id}["{label}"]')
        
        for f in node.files[:_DIAGRAM_TOP_N]:
            f_id = _sanitize_id(f)
            f_label = Path(f).name
            lines.append(f'{indent}    {f_id}["{f_label}"]')
            
        for c in node.children:
            _render_dir(c, Path(c).name, depth + 1)
            
        lines.append(f'{indent}end')

    for fr in sorted(active_forest_roots):
        label = collapsed_map[fr]
        _render_dir(fr, label, 1)

    lines.append("")

    # ── Step 5: edges ─────────────────────────────────────────────────────────
    for src, tgt in sorted(active_edges):
        lines.append(f"    {_sanitize_id(src)} --> {_sanitize_id(tgt)}")

    lines.append("")

    # ── Step 6: style directives ──────────────────────────────────────────────
    for fr in sorted(active_forest_roots):
        fill, stroke = _TOPOLOGY_COLORS[_role(fr)]
        lines.append(f"    style {_sanitize_id(fr)} fill:{fill},stroke:{stroke},color:#000")

    inner = "\\n".join(lines)
    return (
        "## Architecture Diagram\\n\\n"
        "```mermaid\\n"
        "---\\n"
        "config:\\n"
        "  layout: elk\\n"
        "  theme: base\\n"
        "---\\n"
        "flowchart TB\\n"
        f"{inner}\\n"
        "```"
    )
"""

with open("src/rpr/map/output.py", "r") as f:
    text = f.read()

pattern = re.compile(r'def _render_topology_mermaid\(.*?(?=\n\n\ndef _render_details_appendix\()', re.DOTALL)
new_text = pattern.sub(content.strip(), text)

# Important: Make sure `sys` and `re` were imported above, wait `Path` is needed in output.py but already there.

with open("src/rpr/map/output.py", "w") as f:
    f.write(new_text)

