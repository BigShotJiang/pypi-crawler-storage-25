## Special Files

This repository separates instruction files from template files.

- Instruction files explain when to use a pattern.
- Special files contain the code templates that `rpr add template` writes into a target project.

## ENV

For local development, keep `.env` ignored and commit `.env.example` with the required keys.

If a default value is safe and helpful, include it in `.env.example`.

### Python

Python templates live in `src/rpr/scaffolds/special_files`.

### Node / Typescript

Frontend and TypeScript templates live in `src/rpr/scaffolds/js_special_files`.
