# Notebooks

Hands-on material beyond the static **MkDocs** site lives in the repository: runnable **Python scripts** under [`examples/`](https://github.com/optophi/pystator/tree/main/examples) and optional **Marimo** notebooks under the flat [`notebooks/`](https://github.com/optophi/pystator/tree/main/notebooks) directory (when present in your checkout).

## Examples (`examples/`)

YAML FSMs plus scripts (order lifecycle, parallel regions, hierarchical states). From the project root:

```bash
python examples/basic_usage.py
```

Full table and learning path: [Examples & Notebooks](../examples-and-notebooks.md).

## Marimo (`notebooks/`)

Marimo demos are plain-Python `.py` notebook files. They are **not** rendered as pages in this documentation build; run them locally with Marimo after `pip install -e ".[dev]"` (or your project’s dev extra). Upstream catalog, if any, lives next to the notebooks in the repo: [`notebooks/README.md`](https://github.com/optophi/pystator/blob/main/notebooks/README.md).

## Related docs

- [Examples & Notebooks overview](../examples-and-notebooks.md)
- [Discovery guide](../guides/discovery-inference.md) — ingestion and inference workflows often exercised from notebooks
- [Tutorials](../tutorials/index.md) — [Order workflow](../tutorials/order-workflow.md), [API and UI](../tutorials/api-and-ui.md)
