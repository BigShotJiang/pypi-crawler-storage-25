# REST API

The PyStator REST API is documented and tryable in two places:

- **Swagger UI** — When the API is running, open `/docs` (e.g. `http://localhost:8004/docs`) for interactive request/response documentation and "Try it out" for every endpoint.
- **In-app API Playground** — From the PyStator UI, open the **API Playground** (Documentation) page to call endpoints with a minimal request body editor.

Both use the same OpenAPI schema; Swagger is the single source of truth for endpoint paths, methods, request bodies, and responses.

## Running the API

Start the API server:

```bash
pystator api
```

Or with uvicorn:

```bash
uvicorn pystator.api.main:app --host 0.0.0.0 --port 8004
```

Then open [http://localhost:8004/docs](http://localhost:8004/docs) for the full REST API reference.

## Stateless transition (`POST /api/v1/process`)

Send the full FSM **`config`**, **`current_state`**, **`trigger`**, and optional **`context`**. The server builds a machine with **pass-through guards** (named guards in YAML always pass unless you add custom middleware). It returns **HTTP 200** with `success`, `source_state`, `target_state`, structured `error` when the transition fails, and:

- **`actions_to_execute`** — transition actions (names + params, e.g. `code:` / `http:` specs)
- **`on_exit_actions`**, **`on_enter_actions`** — state lifecycle actions

The server **does not** execute those actions, **does not** persist entity rows, and **does not** run inline **`code:`** Python. That matches `StateMachine.process(...)` in the library: compute only. Use this for diagramming, validation flows, or when **your** app runs `ActionExecutor` after persisting state.

**Python equivalent:** `FSMService().process(...)` in `pystator.api.services.fsm_service` (same dict shape as the JSON body).

## Entity lifecycle

- **Create (initial state only):** `POST /api/v1/entities/{entity_id}/create` with JSON body `{ "machine_name": "...", "machine_version": "..." (optional), "context": {} (optional) }`. Persists the entity at the machine’s initial state and writes a history row with trigger `__entity_created__`. Returns **409** if `entity_id` already exists.
- **Process an event:** `POST /api/v1/entities/{entity_id}/events` with a `trigger` (and optional `context`, `machine_name`, `machine_version`) — runs the **orchestrator**: loads state and persisted context from the database, evaluates guards, persists the new state, **executes transition actions** (`code:`, `http:`, registry actions), writes updated context, and appends a history row. The response is returned when processing completes (synchronous HTTP). Optional **`action_results`** lists per-action outcomes (`name`, `success`, `status`, `error`). **Not** the same as `POST /process`, which is stateless compute-only and does not run actions or touch entity rows. Archived or deleted entities return **409** via `EntityNotActiveError`.
- **Dry-run:** `POST /api/v1/entities/{entity_id}/dry-run` — evaluates whether a trigger would succeed from the entity’s current state **without** persisting state, running actions, or writing history. Response includes `would_succeed`, `target_state` when applicable, and **`actions_that_would_execute`** (names only).
- **Enqueue apply-data (worker):** `POST /api/v1/entities/{entity_id}/apply-data` — enqueues a **triggerless** context merge for **`pystator worker`** (`submit_apply_data`); returns an **`event_id`**. Does not run the orchestrator inline. (There is no generic HTTP “enqueue this trigger” endpoint; use **`submit_event`** from Python or insert into **`worker_events`** for queued **named** triggers.)

## Bulk entities

Under **`/api/v1/entities/bulk`** (registered before per-entity routes so `bulk` is not captured as `entity_id`):

- **`POST .../entities/bulk/create`** — create many entities at initial state in one request; per-item errors in the response body.
- **`POST .../entities/bulk/events`** — run the same **trigger** against many **`entity_ids`**; each row uses the full orchestrator path (including action execution); per-entity results in the response.

## Settings and runtime

**`/api/v1/settings/...`** exposes database tests, DLQ checks, discovery DB config, optional **admin** **server-config** read/patch (`pystator.cfg`), and runtime overview fields useful for operators (e.g. **`allow_inline_code_actions`** / **`allow_inline_code_actions_source`** for **`code:`** actions). See OpenAPI **`/docs`** for the full list; many routes require auth when JWT is configured.

## Observability (fleet and feeds)

Under **`/api/v1/observability`** the API exposes **read-only** aggregates and feeds backed by **`transition_history`**, **`entity_states`**, and **`worker_events`**. Use these for dashboards, the workspace UI, or external monitoring—distinct from in-process **[Hooks and metrics](../guides/hooks-and-metrics.md)** on the `Orchestrator`.

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/v1/observability/summary` | Windowed KPIs: transition totals/failures, P95 duration, active entities, worker queue counts (`window_hours`, optional `machine_name` / `entity_id`). |
| GET | `/api/v1/observability/transitions` | Paginated transition history (`limit` / `offset`, filters: machine, entity, success/failed, time range). |
| GET | `/api/v1/observability/worker-events` | Paginated worker queue rows with the same style of filters. |
| GET | `/api/v1/observability/state-metrics` | Per-state ops metrics for a **required** `machine_name` (counts, dwell-style age buckets, top errors)—for diagram overlays. |
| GET | `/api/v1/observability/transition-metrics` | Per-edge aggregates by `(source_state, target_state, trigger)` for the same machine/window—edge overlays in the UI. |
| GET | `/api/v1/observability/entity-health` | Entity-centric health distribution (optional `machine_name`). |
| GET | `/api/v1/observability/transition-analytics` | Time-bucketed transition analytics (`bucket_count`, optional `machine_name`). |

Query parameters and response shapes are authoritative in **OpenAPI** (`/docs`). When JWT (or other) auth is enabled, these routes follow the same dependencies as the rest of **`/api/v1`**.

## Per-entity metrics

- **`GET /api/v1/entities/{entity_id}/metrics`** — Single-entity rollup: health score, staleness, grouped **error patterns**, latency percentiles, dwell-by-state, fleet comparison inside `window_hours`, velocity samples, etc. Returns **404** if the entity row does not exist.

Complements entity-specific **history** routes (e.g. **`GET .../history`**, **`.../history/stats`**) which return raw or summarized transition rows rather than scored metrics.

## Worker vs HTTP

For **fire-and-forget server-side** processing of **named triggers** (worker runs actions), use **`pystator.worker.submit_event`** / **`submit_event_sync`** and run **`pystator worker`** against the same database as **`PYSTATOR_DATABASE_URL`**. See [Worker](../guides/worker.md).
