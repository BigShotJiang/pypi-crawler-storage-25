# Python API Guide

This guide is the quickest way to choose the right Python entrypoint in `pystator`.

## Pick the right layer

| Use case | API surface | Typical entrypoints |
|---|---|---|
| Pure transition computation | Stateless core | `StateMachine`, `StateMachine.process` |
| Stateful per-entity processing in memory | Session wrapper | `EntitySession` |
| Persisted entity state + actions + hooks | Orchestration | `Orchestrator`, `StateStore` adapters |
| Load machine definitions from YAML/DB | Three-layer definition pipeline | `parse_machine_file`, `build_machine`, `MachineStoreClient` |
| Async queued processing | Worker subsystem | `Worker`, `submit_event`, `submit_apply_data` |
| Inferred FSM from observed events | Discovery subsystem | `InferenceEngine`, `ObservedStateEvent`, `create_discovery_store` |

## Core runtime (stateless)

```python
from pystator import StateMachine

machine = StateMachine.from_yaml("order_fsm.yaml")
result = machine.process("pending", "confirm", {"approved": True})
```

- Use this when you own persistence and side-effects externally.
- `process(...)` is deterministic and stateless.

Reference:
- [State Machine](state-machine.md)
- [Errors](errors.md)

## Stateful entity processing

```python
from pystator import EntitySession, StateMachine

machine = StateMachine.from_yaml("order_fsm.yaml")
entity = EntitySession(machine, entity_id="order-123", context={"amount": 10})
entity.send("confirm")
```

- Great for tests, scripts, and lightweight in-process state handling.
- Provides convenience properties/methods such as `is_<state>`.

Reference:
- [EntitySession](entity-session.md)

## Orchestrator + stores (production app path)

```python
from pystator import InMemoryStateStore, Orchestrator, StateMachine

machine = StateMachine.from_yaml("order_fsm.yaml")
store = InMemoryStateStore()
orchestrator = Orchestrator(machine, store)

result = orchestrator.process_event("order-123", "confirm", {"approved": True})
```

- Handles load -> process -> persist -> action execution in one call.
- Swap to SQLite/PostgreSQL/Redis/Mongo-backed stores as needed.

Reference:
- [Orchestrator](orchestrator.md)
- [Stores](stores.md)
- [Hooks](hooks.md)

## Machine-definition pipeline

```python
from pystator import build_machine, parse_machine_file

definition = parse_machine_file("order_fsm.yaml")
machine = build_machine(definition)
```

For DB-backed machine-definition lifecycle:
- `MachineStoreClient` / `SQLAlchemyMachineStore`
- `build_machine_from_store(...)`

Reference:
- [Machine definitions](machine-definitions.md)

## Discovery API

```python
from datetime import UTC, datetime
from pystator.discovery import InferenceEngine, ObservedStateEvent

engine = InferenceEngine.from_app_config()
event = ObservedStateEvent(
    entity_id="order-123",
    machine_name="order_events",
    state="OPEN",
    observed_at=datetime.now(UTC),
    source="app",
)
engine.record_observation("order_events", event)
```

- Used for inference, candidate builds, shadow diffs, and classification.
- Supports native and pluggable discovery stores.

Reference:
- [Discovery (Python)](discovery-api.md)

## Worker API

```python
from pystator.worker import submit_event_sync

event_id = submit_event_sync(
    "order_management",
    "order-123",
    "confirm",
    context={"approved": True},
)
```

- Use `submit_event*` from producers.
- Run `Worker` in a long-lived process to consume and process queue items.

Reference:
- [Worker API](worker-api.md)

## API index by module

- `pystator` (top-level curated exports)
- `pystator.discovery`
- `pystator.worker`
- `pystator.stores`
- `pystator.machine_parser` / `pystator.machine_builder` / `pystator.machine_store`

Use this page for selection, then jump into the generated per-topic reference pages for full signatures and docstrings.
