# Persistence boundaries

PyStator is stateless at the core:

- `StateMachine` + parser + transition semantics are pure, in-process logic.
- Persistence, HTTP endpoints, worker pipelines, and UI are adapters layered on top.

## Layer contract

```mermaid
flowchart TD
  core[CoreStatelessFSM] --> contracts[PersistenceContracts]
  contracts --> adapters[DBStoreAdapters]
  adapters --> api[HTTPAPI]
  adapters --> worker[Worker]
  adapters --> ui[UIWorkspace]
```

## Persistence interfaces

- Runtime entity state uses `StateStore` / `VersionedStateStore` protocols.
- Discovery uses protocol contracts in `pystator.discovery.protocols`.
- Machine-definition persistence uses:
  - `MachineStore` protocol (`pystator.machine_store.protocols`)
  - `MachineStoreClient` base class for shared lifecycle helpers

This split keeps call sites decoupled while preserving practical lifecycle ergonomics for concrete stores.

## Database responsibilities

- Alembic migrations own app schema evolution.
- Discovery SQL provisioning applies idempotent discovery DDL for SQL backends.
- CLI commands (`pystator db init|upgrade|seed`) resolve target DB URL with explicit source precedence and diagnostics.

## Design rules

- Keep stateless core free of DB/session dependencies.
- Keep adapter logic thin; enforce behavior in protocol contracts and tests.
- Prefer deterministic URL resolution and explicit logging over implicit fallbacks.

## SQLite vs PostgreSQL (ORM UUIDs)

Local tests and many notebooks use **SQLite** via `PYSTATOR_DATABASE_URL`. ORM primary keys and foreign keys that are UUIDs use a **cross-dialect** column type so SQLite stores canonical **36-character strings** while PostgreSQL keeps native **`UUID`**. That avoids SQLite type-affinity issues when reading rows (for example `transition_history.id`) that would break UUID decoding. Production schema is still evolved with **Alembic** against PostgreSQL; `create_all` on SQLite follows the same models used in unit tests.
