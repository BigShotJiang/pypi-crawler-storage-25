# How-To Guides

Practical guides for PyStator: architecture, persistence, workers, discovery, and observability.

## Core

<div class="grid cards" markdown>

-   :material-chart-timeline:{ .lg .middle } **Architecture**

    ---

    Design goals, sandwich pattern, and how components fit together.

    [:octicons-arrow-right-24: Read Guide](architecture.md)

-   :material-package-variant:{ .lg .middle } **Package structure**

    ---

    Core vs optional extras (`[api]`, `[worker]`, `[ui]`, `[all]`, `[dev]`).

    [:octicons-arrow-right-24: Read Guide](package-structure.md)

-   :material-account-circle:{ .lg .middle } **EntitySession**

    ---

    Per-entity stateful wrapper: `send()`, snapshots, auto-generated helpers.

    [:octicons-arrow-right-24: Read Guide](entity-session.md)

-   :material-file-code:{ .lg .middle } **Declarative features**

    ---

    YAML `check:` fields, effects (`set`, `timestamp`, …), optional inline `code:`, `StateMachineBuilder`.

    [:octicons-arrow-right-24: Read Guide](declarative-features.md)

</div>

## Execution and persistence

<div class="grid cards" markdown>

-   :material-timer-sand:{ .lg .middle } **Schedulers**

    ---

    Delayed transitions: asyncio, Redis, Celery.

    [:octicons-arrow-right-24: Read Guide](schedulers.md)

-   :material-database:{ .lg .middle } **State stores**

    ---

    In-memory, PostgreSQL, Redis, MongoDB, custom `StateStore` adapters.

    [:octicons-arrow-right-24: Read Guide](state-stores.md)

-   :material-layers:{ .lg .middle } **Persistence boundaries**

    ---

    Stateless core vs persistence adapters, API/worker/UI layering, and store contracts.

    [:octicons-arrow-right-24: Read Guide](persistence-boundaries.md)

-   :material-cog:{ .lg .middle } **Configuration**

    ---

    `pystator.cfg`, environment variables, database URL resolution.

    [:octicons-arrow-right-24: Read Guide](configuration.md)

-   :material-compare:{ .lg .middle } **Config Parity (PyStator/PyCharter)**

    ---

    Unified overlap matrix for env/.cfg precedence and worker/DLQ semantics.

    [:octicons-arrow-right-24: Read Guide](config-parity.md)

-   :material-rocket-launch:{ .lg .middle } **Deployment**

    ---

    Docker, Kubernetes, scaling replicas, default ports.

    [:octicons-arrow-right-24: Read Guide](deployment.md)

-   :material-robot:{ .lg .middle } **Worker**

    ---

    `pystator worker`, `submit_event`, `worker_events` queue.

    [:octicons-arrow-right-24: Read Guide](worker.md)

-   :material-tray-arrow-up:{ .lg .middle } **DLQ migration**

    ---

    Dead-letter queue configuration and migration notes.

    [:octicons-arrow-right-24: Read Guide](dlq-migration.md)

</div>

## Quality and observability

<div class="grid cards" markdown>

-   :material-magnify-scan:{ .lg .middle } **Linting**

    ---

    Static FSM warnings with `pystator.lint.lint()`.

    [:octicons-arrow-right-24: Read Guide](linting.md)

-   :material-chart-bell-curve:{ .lg .middle } **Hooks and metrics (in-process)**

    ---

    `TransitionObserver`, hooks, metrics collectors on the orchestrator; links to HTTP observability routes.

    [:octicons-arrow-right-24: Read Guide](hooks-and-metrics.md)

-   :material-swap-horizontal:{ .lg .middle } **Context and sinks**

    ---

    `TransitionContext`, event/metric sinks.

    [:octicons-arrow-right-24: Read Guide](context.md)

-   :material-graph:{ .lg .middle } **Visualization**

    ---

    Mermaid, DOT, SCXML export and statistics.

    [:octicons-arrow-right-24: Read Guide](visualization.md)

</div>

## Discovery

<div class="grid cards" markdown>

-   :material-lightbulb-on:{ .lg .middle } **Discovery (inferred FSM)**

    ---

    Inference engine, candidates, shadow mode, stores.

    [:octicons-arrow-right-24: Read Guide](discovery-inference.md)

-   :material-label:{ .lg .middle } **Classification**

    ---

    Infer state from data, `StateClassifier`, ingestion.

    [:octicons-arrow-right-24: Read Guide](classification.md)

</div>

## Need more?

- [Tutorials](../tutorials/index.md) — step-by-step workflows
- [API reference](../api/index.md) — mkdocstrings-generated Python API
- [FSM config reference](../reference/fsm-config.md) — YAML/JSON schema
