# Config Parity with PyCharter

This page documents the shared configuration contract between `pystator` and `pycharter` for overlapping runtime concerns.

## Unified precedence contract

For shared keys/behaviors, both packages resolve in this order:

1. explicit CLI/runtime argument (when supported)
2. environment variable
3. `.cfg` section value using the same env-style key
4. package fallback/default

Environment values override `.cfg` values.

## Overlapping surfaces

| Category | PyStator key(s) | PyCharter key(s) | Notes |
|---|---|---|---|
| API URL | `PYSTATOR_API_URL` | `PYCHARTER_API_URL` | UI/API proxy base URL. |
| Database URL | `PYSTATOR_DATABASE_URL` | `PYCHARTER_DATABASE_URL` | Primary SQLAlchemy URL. |
| Auth disable | `PYSTATOR_AUTH_DISABLED` | `PYCHARTER_AUTH_DISABLED` | Truthy disables auth. |
| Auth users | `PYSTATOR_AUTH_USERS` | `PYCHARTER_AUTH_USERS` | Same JSON payload shape. |
| Auth JWT secret | `PYSTATOR_AUTH_JWT_SECRET` | `PYCHARTER_AUTH_JWT_SECRET` | Built-in auth signing secret. |
| Auth service URL | `PYSTATOR_AUTH_SERVICE_URL` | `PYCHARTER_AUTH_SERVICE_URL` | External auth integration. |
| UI theme | `PYSTATOR_UI_THEME` | `PYCHARTER_UI_THEME` | Shared theme contract. |
| UI app name | `PYSTATOR_UI_APP_NAME` | `PYCHARTER_UI_APP_NAME` | Shared branding contract. |
| Worker DB URL | `PYSTATOR_WORKER_DB_URL` | `PYCHARTER_WORKER_DB_URL` | Worker-only DB override. |
| Worker poll interval | `PYSTATOR_WORKER_POLL_INTERVAL_MS` | `PYCHARTER_WORKER_POLL_INTERVAL_MS` | Milliseconds. |
| Worker concurrency | `PYSTATOR_WORKER_CONCURRENCY` | `PYCHARTER_WORKER_CONCURRENCY` | Integer >= 1. |
| Worker drain timeout | `PYSTATOR_WORKER_DRAIN_TIMEOUT_S` | `PYCHARTER_WORKER_DRAIN_TIMEOUT_S` | Seconds. |
| Worker max attempts | `PYSTATOR_WORKER_MAX_ATTEMPTS` | `PYCHARTER_WORKER_MAX_ATTEMPTS` | Retry ceiling. |
| Worker claim lease timeout | `PYSTATOR_WORKER_CLAIM_LEASE_TIMEOUT_S` | `PYCHARTER_WORKER_CLAIM_LEASE_TIMEOUT_S` | Stale claim recovery. |
| Worker retry backoff | `PYSTATOR_WORKER_RETRY_BACKOFF_BASE_MS`, `PYSTATOR_WORKER_RETRY_BACKOFF_MAX_MS` | `PYCHARTER_WORKER_RETRY_BACKOFF_BASE_MS`, `PYCHARTER_WORKER_RETRY_BACKOFF_MAX_MS` | Backoff tuning. |
| DLQ enabled | `PYSTATOR_WORKER_DLQ_ENABLED` | `PYCHARTER_WORKER_DLQ_ENABLED` | Enable/disable DLQ writes. |
| DLQ DB URL | `PYSTATOR_WORKER_DLQ_DATABASE_URL` | `PYCHARTER_WORKER_DLQ_DATABASE_URL` | Optional dedicated DLQ DB URL. |
| DLQ table | `PYSTATOR_WORKER_DLQ_TABLE_NAME` | `PYCHARTER_WORKER_DLQ_TABLE_NAME` | Default `dead_letter_queue`. |

## DLQ fallback behavior

For both packages, if DLQ is enabled and `*_WORKER_DLQ_DATABASE_URL` is unset, the DLQ store uses the resolved worker DB URL, which falls back to the main app DB URL.
