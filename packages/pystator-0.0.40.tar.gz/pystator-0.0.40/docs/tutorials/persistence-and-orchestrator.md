# Persistence and Orchestrator

Run persisted state transitions with the sandwich loop:
load -> process -> persist -> execute actions.

## What you'll build

- A machine loaded from YAML
- A state store (in-memory first; swap to SQL later)
- An `Orchestrator` that processes entity events

## 1) Create machine + orchestrator

```python
from pystator import InMemoryStateStore, Orchestrator, StateMachine

machine = StateMachine.from_yaml("order_fsm.yaml")
store = InMemoryStateStore()
orchestrator = Orchestrator(machine, store)
```

## 2) Process entity events

```python
result = orchestrator.process_event("order-123", "confirm", {"approved": True})
print(result.success, result.target_state)  # True open

result = orchestrator.process_event("order-123", "close", {})
print(result.success, result.target_state)  # True closed
```

## 3) Inspect persisted state

```python
state = store.get_state("order-123")
context = store.get_context("order-123")
print(state)    # closed
print(context)  # merged context for entity
```

## 4) Switch to SQLite/PostgreSQL stores

```python
from pystator import SQLiteStateStore

store = SQLiteStateStore("sqlite:///./pystator.db")
store.connect(auto_initialize=True)
orchestrator = Orchestrator(machine, store)
```

For PostgreSQL:

```python
from pystator import PostgresStateStore

store = PostgresStateStore("postgresql://user:pass@localhost:5432/pystator")
store.connect()
orchestrator = Orchestrator(machine, store)
```

## 5) Add actions and hooks (optional)

- Bind actions to run side-effects after successful persistence.
- Attach hooks for logging and metrics collection.

See:
- [Orchestrator API](../api/orchestrator.md)
- [Stores API](../api/stores.md)
- [Hooks API](../api/hooks.md)
