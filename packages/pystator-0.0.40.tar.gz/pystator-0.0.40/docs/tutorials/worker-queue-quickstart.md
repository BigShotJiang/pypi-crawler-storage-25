# Worker Queue Quickstart

Process events asynchronously through the durable worker queue.

## What you'll learn

- Submit events from producer code
- Run the worker service
- Understand queue + retry flow

## 1) Submit an event from any app process

```python
from pystator.worker import submit_event_sync

event_id = submit_event_sync(
    machine_name="order_management",
    entity_id="order-123",
    trigger="confirm",
    context={"approved": True},
)
print("queued", event_id)
```

## 2) Run worker process

```bash
pystator worker
```

The worker claims events, runs orchestrator processing, and updates event status.

## 3) Schedule delayed events

```python
from datetime import UTC, datetime, timedelta
from pystator.worker import submit_event_sync

submit_event_sync(
    "order_management",
    "order-123",
    "close",
    fires_at=datetime.now(UTC) + timedelta(minutes=5),
)
```

## 4) Apply-data queue (optional)

```python
from pystator.worker import submit_apply_data_sync

submit_apply_data_sync(
    machine_name="order_management",
    entity_id="order-123",
    data={"shipping_address": "new-value"},
)
```

## 5) Next steps

- [Worker API reference](../api/worker-api.md)
- [Worker guide](../guides/worker.md)
- [REST API guide](../api/rest-api.md)
