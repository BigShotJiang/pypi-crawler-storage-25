# Tutorials

Step-by-step guides to build workflows and use the API and UI.

## Available tutorials

| Tutorial | Description | Duration |
|----------|-------------|----------|
| [Python core quickstart](python-core-quickstart.md) | Fastest path for `StateMachine` in pure Python (stateless transitions). | ~10 min |
| [Persistence and orchestrator](persistence-and-orchestrator.md) | Persist entity state with stores and run the sandwich loop using `Orchestrator`. | ~15 min |
| [Discovery quickstart](discovery-quickstart.md) | Record observations and infer transition edges with `InferenceEngine`. | ~15 min |
| [Worker queue quickstart](worker-queue-quickstart.md) | Submit queued events and run the worker for async processing. | ~10 min |
| [Order workflow](order-workflow.md) | Build an order lifecycle FSM with guards and actions, run it in Python. | ~25 min |
| [API and UI](api-and-ui.md) | Run the REST API and web UI; validate configs, run process, manage machines. | ~15 min |

## Learning path

1. **Python core quickstart** — Learn stateless transition processing.
2. **Persistence and orchestrator** — Add persisted entity lifecycle.
3. **Discovery quickstart** — Infer state behavior from observed events.
4. **Worker queue quickstart** — Move processing to async queue workers.
5. **Order workflow** — End-to-end domain example with guards/actions.
6. **API and UI** — Use the same model over HTTP and UI tooling.

## Prerequisites

- Python 3.11+
- `pip install pystator` (and `pystator[api]` for the API/UI tutorial)
- [Quick start](../getting-started/quickstart.md) done (optional but helpful)

## Tutorial format

Each tutorial includes:

1. **Overview** — What you’ll build or do
2. **Steps** — Numbered instructions with copy-paste code
3. **What’s next** — Links to deeper docs or other tutorials

## Getting help

- [Concepts](../guides/concepts.md) — States, transitions, guards, actions
- [API reference](../api.md) — Full API summary
- [Examples & Notebooks](../examples-and-notebooks.md) — Runnable example list
- [GitHub Issues](https://github.com/optophi/pystator/issues)
