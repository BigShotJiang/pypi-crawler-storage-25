# Discovery Quickstart

Infer transition behavior from observed state events.

## What you'll learn

- Create a discovery engine from app config
- Record observations
- Build and inspect inferred edges

## 1) Create engine

```python
from pystator.discovery import InferenceEngine, InferenceThresholds

engine = InferenceEngine.from_app_config(
    thresholds=InferenceThresholds(min_edge_count=1, min_confidence=0.0),
)
```

## 2) Record observations

```python
from datetime import UTC, datetime
from pystator.discovery import ObservedStateEvent

machine_name = "orders_discovery_channel"

rows = [
    {"entity_id": "o-1", "state": "PENDING"},
    {"entity_id": "o-1", "state": "OPEN"},
    {"entity_id": "o-1", "state": "CLOSED"},
]

for i, row in enumerate(rows):
    ev = ObservedStateEvent(
        entity_id=row["entity_id"],
        machine_name=machine_name,
        state=row["state"],
        observed_at=datetime.now(UTC),
        source="tutorial",
        source_event_id=f"tutorial-{i:04d}",
    )
    engine.record_observation(machine_name, ev)
```

## 3) Infer transitions

```python
edges = engine.infer(machine_name)
for e in edges:
    print(e.source_state, "->", e.destination_state, "count=", e.count)
```

## 4) Draft + candidate workflow

Use draft APIs when you want filtered/manual edge selection before build/promotion.

```python
draft = engine.create_draft("orders_inference")
preview = engine.preview_edges_for_draft(draft.id)
candidate = engine.build_candidate_from_draft(draft.id)
```

## 5) Next steps

- [Discovery API reference](../api/discovery-api.md)
- [Discovery conceptual guide](../guides/discovery-inference.md)
- [Classification guide](../guides/classification.md)
