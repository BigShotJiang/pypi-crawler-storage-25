# Python Core Quickstart

Build and run a state machine in pure Python (no persistence required).

## What you'll learn

- Define a machine from YAML
- Process events with `StateMachine`
- Handle expected transition errors

## 1) Define a minimal machine

```yaml
# order_fsm.yaml
meta:
  machine_name: order_management
  version: "1.0.0"
  strict_mode: true

states:
  - { name: pending, type: initial }
  - { name: open, type: stable }
  - { name: closed, type: terminal }

transitions:
  - { trigger: confirm, source: pending, dest: open }
  - { trigger: close, source: open, dest: closed }
```

## 2) Run transitions

```python
from pystator import StateMachine

machine = StateMachine.from_yaml("order_fsm.yaml")

r1 = machine.process("pending", "confirm", {"approved": True})
r2 = machine.process(r1.target_state, "close", {})

print(r1.success, r1.target_state)  # True open
print(r2.success, r2.target_state)  # True closed
```

## 3) Handle failure paths

```python
from pystator import InvalidTransitionError, StateMachine, UndefinedTriggerError

machine = StateMachine.from_yaml("order_fsm.yaml")

try:
    machine.process("pending", "close", {})
except InvalidTransitionError:
    print("Trigger is not valid from this state")

try:
    machine.process("pending", "not_a_trigger", {})
except UndefinedTriggerError:
    print("Unknown trigger")
```

## 4) When to move beyond this

Use `EntitySession` for stateful in-memory entity handling, or `Orchestrator` with a store when you need persistence and action execution.

Next:
- [Persistence and Orchestrator](persistence-and-orchestrator.md)
- [Python API guide](../api/python-api.md)
