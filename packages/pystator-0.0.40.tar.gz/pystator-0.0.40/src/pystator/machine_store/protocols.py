"""Protocols for machine definition persistence.

The stateless core (`StateMachine`, parser, orchestrator semantics) is
storage-agnostic. Persistence adapters implement this protocol to store and
retrieve versioned machine definitions.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from pystator.machine_parser.types import MachineDefinition


@runtime_checkable
class MachineStore(Protocol):
    """Protocol contract for machine-definition persistence backends."""

    connection_string: str | None

    def connect(self) -> None: ...

    def disconnect(self) -> None: ...

    def save(self, definition: MachineDefinition) -> str: ...

    def get(
        self, name: str, version: str | None = None
    ) -> MachineDefinition | None: ...

    def list(self, name: str | None = None) -> list[MachineDefinition]: ...

    def delete(self, name: str, version: str) -> bool: ...
