"""Machine Store Client — abstract base for machine definition persistence.

All operations are keyed by ``(machine_name, version)``. Subclasses
implement backend-specific storage.

See :mod:`pystator.machine_store.protocols` for the runtime-checkable
duck-typing contract used by higher-level composition code.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from pystator.machine_parser.types import MachineDefinition


class MachineStoreClient(ABC):
    """Abstract base for machine definition storage.

    All operations are keyed by (machine_name, version).
    Implementations extend this for specific backends.
    """

    def __init__(self, connection_string: str | None = None) -> None:
        self.connection_string = connection_string
        self._connection: Any = None

    @abstractmethod
    def connect(self) -> None:
        """Establish backend connection."""

    def disconnect(self) -> None:
        """Close backend connection."""
        self._connection = None

    def _require_connection(self) -> None:
        """Raise RuntimeError if connect() has not been called."""
        if self._connection is None:
            raise RuntimeError("Not connected. Call connect() first.")

    @abstractmethod
    def save(self, definition: MachineDefinition) -> str:
        """Persist a machine definition (upsert by name + version).

        Args:
            definition: The parsed machine definition to store.

        Returns:
            The machine identifier (implementation-defined, e.g. UUID string).
        """

    @abstractmethod
    def get(self, name: str, version: str | None = None) -> MachineDefinition | None:
        """Retrieve a machine definition by name and optional version.

        When version is None, returns the latest version.

        Args:
            name: Machine name.
            version: Specific version, or None for latest.

        Returns:
            MachineDefinition if found, None otherwise.
        """

    @abstractmethod
    def list(self, name: str | None = None) -> list[MachineDefinition]:
        """List machine definitions.

        Args:
            name: If provided, filter to versions of this machine only.

        Returns:
            List of MachineDefinition objects.
        """

    @abstractmethod
    def delete(self, name: str, version: str) -> bool:
        """Delete a specific machine version.

        Args:
            name: Machine name.
            version: Version to delete.

        Returns:
            True if deleted, False if not found.
        """

    def __enter__(self) -> MachineStoreClient:
        self.connect()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.disconnect()
