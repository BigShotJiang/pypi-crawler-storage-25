"""SQLAlchemy-backed machine store (PostgreSQL + SQLite).

Wraps the existing MachineModel table with the MachineStoreClient interface.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any

from sqlalchemy import select

from pystator.machine_parser.types import MachineDefinition
from pystator.machine_store.client import MachineStoreClient

logger = logging.getLogger(__name__)


def _row_to_definition(row: Any) -> MachineDefinition:
    """Convert a MachineModel row to a MachineDefinition."""
    config = row.config_json
    meta = config.get("meta", {})
    states = config.get("states", [])
    transitions = config.get("transitions", [])

    strict_raw = row.strict_mode
    if strict_raw is None:
        strict_mode = True
    elif isinstance(strict_raw, bool):
        strict_mode = strict_raw
    else:
        strict_mode = str(strict_raw).lower() in ("true", "1", "yes")  # legacy rows

    return MachineDefinition(
        name=row.name,
        version=row.version,
        config=config,
        states=list(states),
        transitions=list(transitions),
        description=row.description,
        strict_mode=strict_mode,
    )


class SQLAlchemyMachineStore(MachineStoreClient):
    """Machine store backed by SQLAlchemy (PostgreSQL or SQLite).

    Uses the existing ``pystator.machines`` table (MachineModel).
    """

    def __init__(self, connection_string: str) -> None:
        super().__init__(connection_string=connection_string)
        self._engine: Any = None
        self._SessionFactory: Any = None

    def connect(self) -> None:
        from pystator.db.base import get_engine

        self._engine = get_engine(self.connection_string)
        self._SessionFactory = __import__(
            "sqlalchemy.orm", fromlist=["sessionmaker"]
        ).sessionmaker(bind=self._engine)
        self._connection = self._engine

    def disconnect(self) -> None:
        if self._engine is not None:
            self._engine.dispose()
            self._engine = None
        self._SessionFactory = None
        self._connection = None

    def _session(self) -> Any:
        self._require_connection()
        return self._SessionFactory()

    def save(self, definition: MachineDefinition) -> str:
        from pystator.db.models.machine import MachineModel

        session = self._session()
        try:
            existing = session.scalars(
                select(MachineModel).where(
                    MachineModel.name == definition.name,
                    MachineModel.version == definition.version,
                )
            ).first()

            if existing:
                existing.config_json = definition.config
                existing.description = definition.description
                existing.strict_mode = definition.strict_mode
                session.commit()
                return str(existing.id)
            else:
                row = MachineModel(
                    id=uuid.uuid4(),
                    name=definition.name,
                    version=definition.version,
                    description=definition.description,
                    strict_mode=definition.strict_mode,
                    config_json=definition.config,
                )
                session.add(row)
                session.commit()
                return str(row.id)
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def get(self, name: str, version: str | None = None) -> MachineDefinition | None:
        from pystator.db.models.machine import MachineModel

        session = self._session()
        try:
            stmt = select(MachineModel).where(MachineModel.name == name)
            if version is not None:
                row = session.scalars(
                    stmt.where(MachineModel.version == version)
                ).first()
            else:
                row = session.scalars(
                    stmt.order_by(MachineModel.version.desc()).limit(1)
                ).first()

            if row is None:
                return None
            return _row_to_definition(row)
        finally:
            session.close()

    def list(self, name: str | None = None) -> list[MachineDefinition]:
        from pystator.db.models.machine import MachineModel

        session = self._session()
        try:
            stmt = select(MachineModel)
            if name is not None:
                stmt = stmt.where(MachineModel.name == name)
            stmt = stmt.order_by(MachineModel.name, MachineModel.version)
            return [_row_to_definition(row) for row in session.scalars(stmt).all()]
        finally:
            session.close()

    def delete(self, name: str, version: str) -> bool:
        from pystator.db.models.machine import MachineModel

        session = self._session()
        try:
            row = session.scalars(
                select(MachineModel).where(
                    MachineModel.name == name,
                    MachineModel.version == version,
                )
            ).first()
            if row is None:
                return False
            session.delete(row)
            session.commit()
            return True
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
