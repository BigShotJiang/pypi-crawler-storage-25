"""Load catalog entries from the database and register callables."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from pystator.actions import ActionRegistry
from pystator.guards import GuardRegistry
from pystator.registry.resolve import resolve_entry_point
from pystator.registry.types import CatalogEntry, CatalogKind

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


def _row_to_entry(row: object) -> CatalogEntry:
    from pystator.db.models.registry_catalog import RegistryCatalogModel

    assert isinstance(row, RegistryCatalogModel)
    kind: CatalogKind = row.kind if row.kind in ("action", "guard") else "action"
    return CatalogEntry(
        kind=kind,
        name=row.name,
        entry_point=row.entry_point,
        description=row.description,
        params_schema=row.params_schema
        if isinstance(row.params_schema, dict)
        else None,
        enabled=bool(row.enabled),
        version_label=row.version_label,
        source="database",
    )


def load_catalog_from_database(database_url: str) -> list[CatalogEntry]:
    """Load enabled catalog rows from the database."""
    from sqlalchemy import select

    from pystator.db.base import get_session
    from pystator.db.models.registry_catalog import RegistryCatalogModel

    session = get_session(database_url)
    try:
        rows = session.scalars(
            select(RegistryCatalogModel)
            .where(RegistryCatalogModel.enabled.is_(True))
            .order_by(RegistryCatalogModel.kind, RegistryCatalogModel.name)
        ).all()
        return [_row_to_entry(row) for row in rows]
    finally:
        session.close()


def apply_catalog_entries(
    actions: ActionRegistry,
    guards: GuardRegistry,
    entries: list[CatalogEntry],
    *,
    log_name: str = "registry",
) -> tuple[int, int]:
    """Resolve entry points and register into registries.

    Skips disabled entries (DB may include ``enabled: false`` in interchange
    flows — those are skipped here).

    Returns:
        (registered_count, skipped_error_count)
    """
    ok = 0
    err = 0
    for entry in entries:
        if not entry.enabled:
            continue
        try:
            fn = resolve_entry_point(entry.entry_point)
        except (TypeError, ValueError) as exc:
            err += 1
            logger.error(
                "[%s] Skip %s %r: cannot resolve entry_point %r: %s",
                log_name,
                entry.kind,
                entry.name,
                entry.entry_point,
                exc,
            )
            continue
        if entry.kind == "action":
            metadata: dict[str, object] = {}
            if entry.description:
                metadata["description"] = entry.description
            if entry.params_schema is not None:
                metadata["params_schema"] = entry.params_schema
            if entry.version_label:
                metadata["version_label"] = entry.version_label
            if entry.source:
                metadata["source"] = entry.source
            actions.register(
                entry.name,
                fn,
                metadata=metadata if metadata else None,
            )
        else:
            guards.register(entry.name, fn)
        ok += 1
        logger.info(
            "[%s] Registered %s %r -> %r",
            log_name,
            entry.kind,
            entry.name,
            entry.entry_point,
        )
    return ok, err


def load_registry_into_registries(
    actions: ActionRegistry,
    guards: GuardRegistry,
    *,
    database_url: str | None,
    load_database: bool = True,
    log_name: str = "registry",
) -> None:
    """Load the action/guard catalog from the database only.

    Same artifact model as FSM **machine** definitions stored in ``machines``:
    there is no separate env var pointing at a registry YAML file on disk.
    Populate ``registry_catalog`` via the API, import, migrations, or seeds;
    use ``GET``/``POST .../registry/catalog/export`` and ``import`` for YAML
    interchange (like validating and saving machine configs).
    """
    entries: list[CatalogEntry] = []

    if load_database and database_url:
        try:
            db_entries = load_catalog_from_database(database_url)
            entries.extend(db_entries)
            logger.info(
                "[%s] Loaded %d catalog row(s) from database",
                log_name,
                len(db_entries),
            )
        except Exception as exc:
            logger.warning(
                "[%s] Database catalog load skipped: %s",
                log_name,
                exc,
            )

    if not entries:
        logger.debug("[%s] No catalog entries to apply", log_name)
        return

    ok, errs = apply_catalog_entries(actions, guards, entries, log_name=log_name)
    logger.info(
        "[%s] Catalog apply finished: %d registered, %d error(s)",
        log_name,
        ok,
        errs,
    )


def load_registry_from_app_config(
    actions: ActionRegistry,
    guards: GuardRegistry,
    *,
    database_url: str | None,
    log_name: str = "registry",
) -> None:
    """Convenience: read DB load flag from config and load from database."""
    from pystator.config.registry_settings import get_registry_load_database

    load_registry_into_registries(
        actions,
        guards,
        database_url=database_url,
        load_database=get_registry_load_database(),
        log_name=log_name,
    )
