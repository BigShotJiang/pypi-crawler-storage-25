"""Shared datetime defaults for ORM columns (UTC-aware)."""

from __future__ import annotations

from datetime import UTC, datetime


def utc_now() -> datetime:
    """Return current UTC time (for Column default/onupdate)."""
    return datetime.now(UTC)
