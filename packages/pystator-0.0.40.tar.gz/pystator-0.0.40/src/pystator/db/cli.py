"""
CLI commands for database management (pystator db init, pystator db upgrade)

Following Airflow/PyCharter's pattern: pystator db init, pystator db upgrade
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

try:
    import yaml  # type: ignore[import-untyped]

    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

try:
    from alembic import command
    from sqlalchemy import create_engine, inspect, text

    ALEMBIC_AVAILABLE = True
except ImportError:
    ALEMBIC_AVAILABLE = False

from pystator.config.database import set_database_url
from pystator.db.base import get_engine
from pystator.db.config import (
    detect_db_type,
    get_alembic_config,
    get_db_url,
    require_alembic,
)

# Seed directory may include this file for registry catalog rows; it is not an FSM machine.
REGISTRY_CATALOG_SEED_FILENAME = "registry_catalog.yaml"


# ---------------------------------------------------------------------------
# Command functions
# ---------------------------------------------------------------------------
def cmd_init(
    database_url: str | None = None,
    db_type: str | None = None,
    force: bool = False,
) -> int:
    """Initialize the database schema from scratch."""
    try:
        db_url = get_db_url(database_url)
        db_type = db_type or detect_db_type(db_url)
        if db_type == "sqlite":
            return _init_sqlite(db_url, force)
        return _init_postgresql(db_url, force)
    except Exception as e:
        print(f"\u274c Error: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _init_sqlite(database_url: str, force: bool = False) -> int:
    """Initialize SQLite: run migrations only (same approach as PostgreSQL)."""
    require_alembic()

    try:
        db_path = (
            database_url[10:] if database_url.startswith("sqlite:///") else database_url
        )
        if db_path != ":memory:":
            Path(db_path).parent.mkdir(parents=True, exist_ok=True)

        engine = get_engine(database_url)
        existing_tables = inspect(engine).get_table_names()

        if existing_tables and not force:
            print(
                f"\u26a0 Warning: Database already contains {len(existing_tables)} tables."
            )
            print(
                "   Use --force to reinitialize, or run 'pystator db upgrade' to apply migrations."
            )
            return 1

        if existing_tables and force:
            with engine.connect() as conn:
                conn.execute(text("PRAGMA foreign_keys=OFF"))
                for name in existing_tables:
                    conn.execute(text(f'DROP TABLE IF EXISTS "{name}"'))
                conn.execute(text("PRAGMA foreign_keys=ON"))
                conn.commit()
            print("\u2713 Dropped existing tables")

        set_database_url(database_url)
        config = get_alembic_config(database_url)
        print("Running migrations to initialize database...")
        command.upgrade(config, "head")
        print("\u2713 SQLite initialization complete!")
        return 0
    except Exception as e:
        print(f"\u274c Error initializing SQLite: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _init_postgresql(database_url: str, force: bool = False) -> int:
    """Initialize PostgreSQL: create pystator schema and run migrations."""
    require_alembic()

    try:
        set_database_url(database_url)
        config = get_alembic_config(database_url)
        engine = create_engine(database_url)
        with engine.connect() as conn:
            conn.execute(text('CREATE SCHEMA IF NOT EXISTS "pystator"'))
            conn.commit()
        print("\u2713 Created 'pystator' schema (if it didn't exist)")
        print("Running migrations to initialize database...")
        command.upgrade(config, "head")
        print("\u2713 Database initialized successfully!")
        return 0
    except Exception as e:
        print(f"\u274c Error initializing database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_upgrade(database_url: str | None = None, revision: str = "head") -> int:
    """Upgrade database to the given revision (default head)."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1
        if database_url:
            set_database_url(database_url)
        config = get_alembic_config(db_url)
        print(f"Upgrading database to revision: {revision}...")
        command.upgrade(config, revision)
        print("\u2713 Database upgraded successfully!")
        return 0
    except Exception as e:
        print(f"\u274c Error upgrading database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_downgrade(database_url: str | None = None, revision: str = "-1") -> int:
    """Downgrade database to the given revision."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1
        if database_url:
            set_database_url(database_url)
        config = get_alembic_config(db_url)
        print(f"Downgrading database to revision: {revision}...")
        command.downgrade(config, revision)
        print("\u2713 Database downgraded successfully!")
        return 0
    except Exception as e:
        print(f"\u274c Error downgrading database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_current(database_url: str | None = None) -> int:
    """Print current database revision."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1
        if database_url:
            set_database_url(database_url)
        engine = create_engine(db_url)
        with engine.connect() as connection:
            try:
                result = connection.execute(
                    text('SELECT version_num FROM "pystator".alembic_version LIMIT 1')
                )
                version = result.fetchone()
                if version:
                    print(f"Current database revision: {version[0]}")
                    return 0
            except Exception:
                pass

            from alembic.runtime.migration import MigrationContext

            context = MigrationContext.configure(connection)
            current_rev = context.get_current_revision()
            if current_rev:
                print(f"Current database revision: {current_rev}")
                return 0

        print("Database is not initialized. Run 'pystator db init' first.")
        return 1
    except Exception as e:
        print(f"\u274c Error getting current revision: {e}")
        return 1


def cmd_history(database_url: str | None = None) -> int:
    """Show migration history."""
    require_alembic()

    try:
        if database_url:
            set_database_url(database_url)
        config = get_alembic_config()
        command.history(config)
        return 0
    except Exception as e:
        print(f"\u274c Error showing history: {e}")
        return 1


def cmd_stamp(database_url: str | None = None, revision: str = "head") -> int:
    """Stamp database with a revision without running migrations."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1
        if database_url:
            set_database_url(database_url)
        config = get_alembic_config(db_url)
        print(f"Stamping database with revision: {revision}...")
        command.stamp(config, revision)
        print(f"\u2713 Database stamped successfully with revision: {revision}")
        return 0
    except Exception as e:
        print(f"\u274c Error stamping database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_seed(seed_dir: str | None = None, database_url: str | None = None) -> int:
    """Seed the database with example FSM machines and optional registry catalog rows.

    Every ``*.yaml`` / ``*.yml`` in the seed directory (except ``registry_catalog.yaml``)
    is loaded; each file may be one machine dict or a list of machines. The same
    ``machine_name`` with different ``version`` values is stored as separate rows
    (e.g. multiple ``aidx_flight_lifecycle`` seed files for v1.0.0, v1.1.0, v1.2.0).
    """
    if not YAML_AVAILABLE:
        print("\u274c Error: PyYAML is required. Install with: pip install pyyaml")
        return 1

    try:
        # Handle swapped arguments
        if seed_dir and any(
            seed_dir.startswith(prefix)
            for prefix in ("postgresql://", "postgres://", "sqlite://")
        ):
            database_url, seed_dir = seed_dir, None

        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        # Determine seed directory
        if seed_dir:
            seed_path = Path(seed_dir)
        else:
            # Package-bundled seed: pystator/data/seed
            try:
                import pystator as _pkg

                seed_path = Path(_pkg.__file__).resolve().parent / "data" / "seed"
            except (ImportError, AttributeError):
                seed_path = Path(__file__).resolve().parent.parent / "data" / "seed"

        if not seed_path.exists():
            print(f"\u274c Error: Seed directory not found: {seed_path}")
            return 1

        print(f"Loading seed data from: {seed_path}")
        rc = _seed_machines(seed_path, db_url)
        if rc != 0:
            return rc
        return _seed_registry_catalog(seed_path, db_url)
    except Exception as e:
        print(f"\u274c Error seeding database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _seed_machines(seed_path: Path, db_url: str) -> int:
    """Seed FSM machine definitions from all .yaml files via machine_parser + machine_store.

    Iterates every ``*.yaml`` / ``*.yml`` (except the registry catalog filename). Multiple
    files may define the same ``machine_name`` at different ``version`` strings; each
    combination is persisted as its own machine definition.
    """
    from pystator.machine_parser import parse_machine
    from pystator.machine_store import SQLAlchemyMachineStore

    yaml_files = [
        p
        for p in sorted(seed_path.glob("*.yaml")) + sorted(seed_path.glob("*.yml"))
        if p.name != REGISTRY_CATALOG_SEED_FILENAME
    ]
    if not yaml_files:
        print(f"  No .yaml/.yml files found in {seed_path}")
        return 0

    # Parse all YAML files (each file may contain a list of machines)
    definitions_by_key: dict[tuple[str, str], tuple[str, object]] = {}
    skipped = 0
    parse_errors: list[str] = []
    for filepath in yaml_files:
        with open(filepath, encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if data is None:
            continue
        items = data if isinstance(data, list) else [data]
        for item in items:
            try:
                defn = parse_machine(item, validate=True)
                key = (str(defn.name), str(defn.version))
                if key in definitions_by_key:
                    prev_file = definitions_by_key[key][0]
                    print(
                        f"  warn  duplicate definition for {defn.name} v{defn.version}: "
                        f"{prev_file} overridden by {filepath.name}"
                    )
                definitions_by_key[key] = (filepath.name, defn)
            except Exception as exc:
                parse_errors.append(f"{filepath.name}: {exc}")
                skipped += 1

    if parse_errors:
        print("  parse errors:")
        for line in parse_errors:
            print(f"    - {line}")

    definitions = [definitions_by_key[k] for k in sorted(definitions_by_key)]
    if not definitions:
        print("  No valid machine definitions found")
        return 0

    # Save to database
    store = SQLAlchemyMachineStore(db_url)
    try:
        store.connect()
        saved = 0
        for filename, defn in definitions:
            store.save(defn)
            state_count = len(defn.states)
            trans_count = len(defn.transitions)
            print(
                f"  {defn.name} v{defn.version}  [{filename}]"
                f"  ({state_count} states, {trans_count} transitions)"
            )
            saved += 1

        print(f"\nSeeded {saved} machine(s)", end="")
        if skipped:
            print(f" ({skipped} skipped)")
        else:
            print()
        return 0
    except Exception as e:
        raise e
    finally:
        store.disconnect()


def _seed_registry_catalog(seed_path: Path, db_url: str) -> int:
    """Upsert registry catalog rows from ``registry_catalog.yaml`` if present."""
    from datetime import UTC, datetime

    from sqlalchemy import select

    from pystator.db.base import get_session
    from pystator.db.models.registry_catalog import RegistryCatalogModel
    from pystator.errors import ConfigurationError
    from pystator.registry.resolve import resolve_entry_point
    from pystator.registry.yaml_manifest import parse_manifest_yaml_text

    catalog_path = seed_path / REGISTRY_CATALOG_SEED_FILENAME
    if not catalog_path.is_file():
        return 0

    text = catalog_path.read_text(encoding="utf-8")
    try:
        entries = parse_manifest_yaml_text(text, source=str(catalog_path.resolve()))
    except ConfigurationError as e:
        print(f"\u274c Error parsing {catalog_path.name}: {e}")
        return 1

    errors: list[str] = []
    for e in entries:
        try:
            resolve_entry_point(e.entry_point)
        except (TypeError, ValueError) as ex:
            errors.append(f"{e.kind} {e.name!r}: {ex}")
    if errors:
        print("\u274c Invalid entry_point(s) in registry catalog seed:")
        for line in errors:
            print(f"  {line}")
        return 1

    session = get_session(db_url)
    try:
        created = 0
        updated = 0
        for e in entries:
            existing = session.scalars(
                select(RegistryCatalogModel).where(
                    RegistryCatalogModel.kind == e.kind,
                    RegistryCatalogModel.name == e.name,
                )
            ).first()
            if existing is None:
                session.add(
                    RegistryCatalogModel(
                        kind=e.kind,
                        name=e.name,
                        entry_point=e.entry_point,
                        description=e.description,
                        params_schema=e.params_schema,
                        enabled=e.enabled,
                        version_label=e.version_label,
                    )
                )
                created += 1
            else:
                existing.entry_point = e.entry_point
                existing.description = e.description
                existing.params_schema = e.params_schema
                existing.enabled = e.enabled
                existing.version_label = e.version_label
                existing.updated_at = datetime.now(UTC)
                updated += 1
        session.commit()
        print(
            f"\nSeeded registry catalog: {created} created, {updated} updated"
            f" ({len(entries)} entries from {catalog_path.name})"
        )
        return 0
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def cmd_truncate(database_url: str | None = None, force: bool = False) -> int:
    """Truncate all PyStator database tables."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1
        if database_url:
            set_database_url(database_url)

        engine = create_engine(db_url)
        is_postgres = db_url.startswith(("postgresql://", "postgres://"))

        if is_postgres:
            inspector = inspect(engine)
            existing_tables = set(inspector.get_table_names(schema="pystator"))
        else:
            existing_tables = set(inspect(engine).get_table_names())

        # Tables to truncate in order (respecting FK constraints)
        tables = ["worker_events", "transition_history", "entity_states", "machines"]
        existing_tables_to_truncate = [t for t in tables if t in existing_tables]

        if not existing_tables_to_truncate:
            print("\u26a0 No PyStator tables found to truncate.")
            return 0

        print(
            f"\n\u26a0 WARNING: This will truncate {len(existing_tables_to_truncate)} table(s):"
        )
        print(f"   {', '.join(existing_tables_to_truncate)}")
        print("\n\u26a0 ALL DATA IN THESE TABLES WILL BE PERMANENTLY DELETED!")

        if not force:
            try:
                confirmation = input("\nType 'yes' to confirm: ").strip().lower()
                if confirmation not in ("yes", "y"):
                    print("\u274c Truncate cancelled.")
                    return 1
            except (EOFError, KeyboardInterrupt):
                print("\n\u274c Truncate cancelled.")
                return 1

        with engine.begin() as conn:
            if is_postgres:
                conn.execute(text("SET session_replication_role = 'replica'"))
                for table in existing_tables_to_truncate:
                    conn.execute(text(f'TRUNCATE TABLE pystator."{table}" CASCADE'))
                    print(f"  \u2713 Truncated {table}")
                conn.execute(text("SET session_replication_role = 'origin'"))
            else:
                # SQLite
                conn.execute(text("PRAGMA foreign_keys=OFF"))
                for table in existing_tables_to_truncate:
                    conn.execute(text(f'DELETE FROM "{table}"'))
                    print(f"  \u2713 Truncated {table}")
                conn.execute(text("PRAGMA foreign_keys=ON"))

        print("\n\u2713 Successfully truncated all PyStator tables!")
        return 0
    except Exception as e:
        print(f"\u274c Error truncating database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def main() -> int:
    """Main CLI entry point for pystator db commands."""
    parser = argparse.ArgumentParser(
        description="PyStator database management commands",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # init
    init_parser = subparsers.add_parser(
        "init",
        help="Initialize database schema from scratch",
        epilog=(
            "`db init` and `db upgrade` are separate commands. "
            "Do not run `db init upgrade`; use `db upgrade` to apply migrations."
        ),
    )
    init_parser.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string (defaults to sqlite:///pystator.db)",
    )
    init_parser.add_argument(
        "--db",
        "--database-type",
        dest="db_type",
        choices=["postgresql", "postgres", "sqlite"],
        default=None,
        help="Database type (auto-detected from URL if not provided)",
    )
    init_parser.add_argument(
        "--force",
        action="store_true",
        help="Proceed even if initialized",
    )

    # upgrade
    upgrade_parser = subparsers.add_parser(
        "upgrade", help="Upgrade database to latest revision"
    )
    upgrade_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )
    upgrade_parser.add_argument("--revision", default="head", help="Target revision")

    # downgrade
    downgrade_parser = subparsers.add_parser("downgrade", help="Downgrade database")
    downgrade_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )
    downgrade_parser.add_argument("--revision", default="-1", help="Target revision")

    # current
    current_parser = subparsers.add_parser(
        "current", help="Show current database revision"
    )
    current_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )

    # history
    history_parser = subparsers.add_parser("history", help="Show migration history")
    history_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )

    # stamp
    stamp_parser = subparsers.add_parser(
        "stamp", help="Stamp database with revision without running migrations"
    )
    stamp_parser.add_argument(
        "revision", nargs="?", default="head", help="Revision to stamp"
    )
    stamp_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )

    # seed
    seed_parser = subparsers.add_parser(
        "seed",
        help="Seed database with example FSM machines and built-in registry catalog",
    )
    seed_parser.add_argument(
        "seed_dir", nargs="?", help="Directory with seed YAML files"
    )
    seed_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )

    # truncate
    truncate_parser = subparsers.add_parser("truncate", help="Truncate all tables")
    truncate_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )
    truncate_parser.add_argument(
        "--force", action="store_true", help="Skip confirmation"
    )

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    commands = {
        "init": lambda: cmd_init(
            args.database_url, db_type=args.db_type, force=args.force
        ),
        "upgrade": lambda: cmd_upgrade(args.database_url, args.revision),
        "downgrade": lambda: cmd_downgrade(args.database_url, args.revision),
        "current": lambda: cmd_current(args.database_url),
        "history": lambda: cmd_history(args.database_url),
        "stamp": lambda: cmd_stamp(args.database_url, args.revision),
        "seed": lambda: cmd_seed(args.seed_dir, args.database_url),
        "truncate": lambda: cmd_truncate(args.database_url, force=args.force),
    }

    return commands.get(args.command, lambda: (parser.print_help(), 1)[1])()


if __name__ == "__main__":
    sys.exit(main())
