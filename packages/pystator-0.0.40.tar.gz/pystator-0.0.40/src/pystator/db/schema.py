"""PostgreSQL schema name and :class:`~sqlalchemy.Table` args for the main app ORM."""

from __future__ import annotations

from typing import Any

PYSTATOR_SCHEMA = "pystator"


def pystator_table_args(*constraints: Any) -> tuple[Any, ...]:
    """Append ``{\"schema\": PYSTATOR_SCHEMA}`` for core tables (SQLite strips schema in SQL)."""
    if not constraints:
        return ({"schema": PYSTATOR_SCHEMA},)
    return (*constraints, {"schema": PYSTATOR_SCHEMA})
