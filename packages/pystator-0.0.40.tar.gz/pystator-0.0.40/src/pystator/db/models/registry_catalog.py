"""
SQLAlchemy model for persisted action/guard registry catalog (metadata + entry points).

Implementation code is not stored here — only ``module:callable`` strings resolved at runtime.
"""

from __future__ import annotations

import uuid

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Index,
    String,
    Text,
    UniqueConstraint,
)

from pystator.db.base import Base
from pystator.db.datetime_utils import utc_now
from pystator.db.schema import pystator_table_args
from pystator.db.types import CrossDialectUUID


class RegistryCatalogModel(Base):
    """One row per named action or guard in the distributed catalog."""

    __tablename__ = "registry_catalog"

    id = Column(CrossDialectUUID(), primary_key=True, default=uuid.uuid4)

    kind = Column(String(20), nullable=False)  # "action" | "guard"
    name = Column(String(255), nullable=False)
    entry_point = Column(String(1024), nullable=False)
    description = Column(Text, nullable=True)
    params_schema = Column(JSON, nullable=True)
    enabled = Column(Boolean, nullable=False, default=True)
    version_label = Column(String(64), nullable=True)

    created_at = Column(DateTime(timezone=True), default=utc_now)
    updated_at = Column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)

    __table_args__ = pystator_table_args(
        UniqueConstraint("kind", "name", name="uq_registry_catalog_kind_name"),
        Index("ix_registry_catalog_kind_enabled", "kind", "enabled"),
    )
