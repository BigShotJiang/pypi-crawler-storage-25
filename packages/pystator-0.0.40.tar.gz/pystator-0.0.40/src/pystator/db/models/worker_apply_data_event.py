"""
SQLAlchemy model for apply-data worker event queue.

The ``worker_apply_data_events`` table serves as a durable queue for
high-velocity, triggerless "apply data" updates that may cause
post-transition routing (auto-transitions + when-route).

This table is intentionally separate from ``worker_events`` so backlog or
failures in data ingestion do not impact trigger-based event processing.
"""

from __future__ import annotations

import uuid

from sqlalchemy import JSON, Column, DateTime, Index, Integer, String, Text

from pystator.db.base import Base
from pystator.db.datetime_utils import utc_now
from pystator.db.schema import pystator_table_args
from pystator.db.types import CrossDialectUUID


class WorkerApplyDataEventModel(Base):
    """
    SQLAlchemy model for apply-data worker queue entries.

    Each row represents an apply-data request (data payload for an entity)
    that the worker should process. The claim lifecycle mirrors
    ``WorkerEventModel``:

        pending  ->  claimed  ->  completed | failed | dead_letter
    """

    __tablename__ = "worker_apply_data_events"

    id = Column(CrossDialectUUID(), primary_key=True, default=uuid.uuid4)

    # Which machine and entity this update targets
    machine_name = Column(String(255), nullable=False)
    entity_id = Column(String(255), nullable=False)

    # Data payload (JSON-serializable dict)
    data_json = Column(JSON, nullable=True)

    # Claim lifecycle
    status = Column(String(20), nullable=False, default="pending")
    fires_at = Column(DateTime(timezone=True), nullable=False, default=utc_now)
    claimed_by = Column(String(255), nullable=True)
    claimed_at = Column(DateTime(timezone=True), nullable=True)

    # Retry tracking
    attempt = Column(Integer, nullable=False, default=0)
    max_attempts = Column(Integer, nullable=False, default=5)
    error_message = Column(Text, nullable=True)

    # Optional idempotency key (unique when non-null)
    idempotency_key = Column(String(255), nullable=True, unique=True)

    # Audit timestamps
    created_at = Column(DateTime(timezone=True), default=utc_now)
    completed_at = Column(DateTime(timezone=True), nullable=True)

    # Optional result payload (e.g. transitions fired, final state)
    result_json = Column(JSON, nullable=True)
    # Optional correlation to transition_history.id for drill-down observability
    transition_history_id = Column(CrossDialectUUID(), nullable=True)

    __table_args__ = pystator_table_args(
        Index("ix_worker_apply_data_events_poll", "status", "fires_at"),
        Index("ix_worker_apply_data_events_entity_id", "entity_id"),
        Index("ix_worker_apply_data_events_machine_name", "machine_name"),
        Index(
            "ix_worker_apply_data_events_transition_history_id",
            "transition_history_id",
        ),
    )
