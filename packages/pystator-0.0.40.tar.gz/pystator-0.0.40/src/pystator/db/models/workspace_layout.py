"""Workspace diagram layout positions (stored separately from FSM config).

Positions are visual/presentation data and do not belong in the FSM
protocol config.  This mirrors the WorkspaceAnnotationModel pattern.
"""

from __future__ import annotations

import uuid

from sqlalchemy import Column, DateTime, Float, String, UniqueConstraint

from pystator.db.base import Base
from pystator.db.datetime_utils import utc_now
from pystator.db.schema import pystator_table_args
from pystator.db.types import CrossDialectUUID


class WorkspaceLayoutModel(Base):
    """Per-state diagram position for the workspace editor.

    Positions are visual/presentation data and are stored
    separately from the FSM config (which is a pure protocol).
    This follows the same pattern as WorkspaceAnnotationModel.
    """

    __tablename__ = "workspace_layouts"

    id = Column(CrossDialectUUID(), primary_key=True, default=uuid.uuid4)

    machine_name = Column(String(255), nullable=False, index=True)
    machine_version = Column(String(50), nullable=False, index=True)
    state_name = Column(String(255), nullable=False, index=True)

    position_x = Column(Float, nullable=False, default=0.0)
    position_y = Column(Float, nullable=False, default=0.0)

    created_at = Column(DateTime(timezone=True), default=utc_now)
    updated_at = Column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    __table_args__ = pystator_table_args(
        UniqueConstraint(
            "machine_name",
            "machine_version",
            "state_name",
            name="uq_workspace_layouts_machine_version_state",
        ),
    )
