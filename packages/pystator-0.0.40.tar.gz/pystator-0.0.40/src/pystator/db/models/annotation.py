"""
SQLAlchemy model for workspace state annotations.

Robust MVP: one note per state per (machine_name, machine_version).
Notes are anchored to state_name and do not depend on canvas coordinates.
"""

from __future__ import annotations

import uuid

from sqlalchemy import Column, DateTime, String, Text, UniqueConstraint

from pystator.db.base import Base
from pystator.db.datetime_utils import utc_now
from pystator.db.schema import pystator_table_args
from pystator.db.types import CrossDialectUUID


class WorkspaceAnnotationModel(Base):
    __tablename__ = "workspace_annotations"

    id = Column(CrossDialectUUID(), primary_key=True, default=uuid.uuid4)

    machine_name = Column(String(255), nullable=False, index=True)
    machine_version = Column(String(50), nullable=False, index=True)
    state_name = Column(String(255), nullable=False, index=True)

    body_markdown = Column(Text, nullable=False, default="")

    created_at = Column(DateTime(timezone=True), default=utc_now)
    updated_at = Column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    __table_args__ = pystator_table_args(
        UniqueConstraint(
            "machine_name",
            "machine_version",
            "state_name",
            name="uq_workspace_annotations_machine_version_state",
        ),
    )
