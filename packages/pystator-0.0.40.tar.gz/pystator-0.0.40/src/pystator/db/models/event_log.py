"""
SQLAlchemy model for the append-only event log.

Stores raw events (inputs) as the source of truth for each entity,
enabling replay and event-sourcing patterns. Unlike transition_history
(which records outcomes), the event_log captures what was requested.
"""

from __future__ import annotations

import uuid

from sqlalchemy import JSON, Column, DateTime, Index, Integer, String, UniqueConstraint

from pystator.db.base import Base
from pystator.db.datetime_utils import utc_now
from pystator.db.schema import pystator_table_args
from pystator.db.types import CrossDialectUUID


class EventLogModel(Base):
    """Append-only event log for replay and event sourcing.

    Each row records a single event sent to an entity. Events are ordered
    by ``sequence`` (monotonically increasing per entity) and are never
    modified after insertion.
    """

    __tablename__ = "event_log"

    id = Column(CrossDialectUUID(), primary_key=True, default=uuid.uuid4)

    # Entity identifier
    entity_id = Column(String(255), nullable=False)

    # Machine name (denormalized for filtering)
    machine_name = Column(String(255), nullable=True)

    # Monotonic sequence number per entity (1, 2, 3, ...)
    sequence = Column(Integer, nullable=False)

    # Event trigger name
    trigger = Column(String(255), nullable=False)

    # Raw event payload (the input, not the outcome)
    payload_json = Column(JSON, nullable=True)

    # Original Event.event_id (UUID string for idempotency)
    event_id = Column(String(64), nullable=True)

    # Event source ("api", "user", "system", etc.)
    source = Column(String(255), nullable=True)

    # Append timestamp
    created_at = Column(DateTime(timezone=True), default=utc_now)

    __table_args__ = pystator_table_args(
        UniqueConstraint("entity_id", "sequence", name="uq_event_log_entity_sequence"),
        Index("ix_event_log_entity_id", "entity_id"),
        Index("ix_event_log_created_at", "created_at"),
    )
