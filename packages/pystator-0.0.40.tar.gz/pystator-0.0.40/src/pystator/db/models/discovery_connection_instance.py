"""Registry row for a discovery backend connection (one per logical instance)."""

from __future__ import annotations

import uuid

from sqlalchemy import Column, DateTime, String, Text

from pystator.db.base import Base
from pystator.db.datetime_utils import utc_now
from pystator.db.schema import pystator_table_args
from pystator.db.types import CrossDialectUUID


class DiscoveryConnectionInstanceModel(Base):
    """Stores connection metadata for discovery; drafts reference ``id``."""

    __tablename__ = "discovery_connection_instances"

    id = Column(CrossDialectUUID(), primary_key=True, default=uuid.uuid4)
    title = Column(String(512), nullable=True)
    namespace = Column(String(512), nullable=True)
    backend = Column(String(32), nullable=False)
    connection_string = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), nullable=True, default=utc_now)
    updated_at = Column(
        DateTime(timezone=True), nullable=True, default=utc_now, onupdate=utc_now
    )

    __table_args__ = pystator_table_args()
