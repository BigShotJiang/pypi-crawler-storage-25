"""Alembic environment for PyStator DB migrations.

Mirrors PyCharter's migrations/env.py: uses PYSTATOR_DATABASE_URL,
pystator schema for PostgreSQL, no schema for SQLite.
"""

from alembic import context
from sqlalchemy import engine_from_config, pool

from pystator.config.database import resolve_database_url
from pystator.db.base import Base

# Import all models for metadata registration
from pystator.db.models import (  # noqa: F401
    DiscoveryConnectionInstanceModel,
    EntityStateModel,
    EventLogModel,
    MachineModel,
    RegistryCatalogModel,
    TransitionHistoryModel,
    WebhookModel,
    WorkerApplyDataEventModel,
    WorkerEventModel,
    WorkspaceAnnotationModel,
    WorkspaceLayoutModel,
    WorkspaceTransitionAnnotationModel,
)

config = context.config
target_metadata = Base.metadata


def run_migrations_offline() -> None:
    resolved = resolve_database_url(include_default=False)
    config_url = config.get_main_option("sqlalchemy.url")
    # Prefer explicit runtime/alembic-config URL; fallback to env/cfg when absent.
    url = config_url or resolved.url
    version_table_schema = None
    if url and url.startswith(("postgresql://", "postgres://")):
        version_table_schema = "pystator"
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        version_table_schema=version_table_schema,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    configuration = config.get_section(config.config_ini_section, {}) or {}
    config_url = str(configuration.get("sqlalchemy.url") or "").strip()
    if not config_url:
        resolved = resolve_database_url(include_default=False)
        if resolved.url:
            configuration["sqlalchemy.url"] = resolved.url
    url = str(configuration.get("sqlalchemy.url") or "").strip()
    version_table_schema = None
    if url and url.startswith(("postgresql://", "postgres://")):
        version_table_schema = "pystator"
    connectable = engine_from_config(
        configuration,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            version_table_schema=version_table_schema,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
