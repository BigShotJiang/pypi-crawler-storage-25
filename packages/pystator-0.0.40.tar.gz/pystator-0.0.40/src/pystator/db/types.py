"""Reusable SQLAlchemy column types for multi-dialect apps (PostgreSQL + SQLite).

SQLite's ``sqlite3`` driver does **not** accept :class:`uuid.UUID` as a bound
parameter—it raises ``ProgrammingError: type 'UUID' is not supported``. Native
PostgreSQL drivers accept :class:`uuid.UUID``. Types here centralize the
bind/result coercion so ORM code can always use ``uuid.UUID`` in Python.

**UUID column policy**

- All primary/foreign key UUID columns use :class:`CrossDialectUUID` so SQLite
  stores hyphenated strings (no REAL/affinity coercion) and PostgreSQL keeps
  native ``UUID``. Do not use :class:`sqlalchemy.dialects.postgresql.UUID` on
  ORM models that run against SQLite (tests, ``pystator db`` defaults).
"""

from __future__ import annotations

import uuid
from typing import Any

from sqlalchemy import String
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.types import TypeDecorator


class CrossDialectUUID(TypeDecorator[uuid.UUID]):
    """UUID primary/foreign key: PostgreSQL ``UUID``; SQLite ``TEXT`` (36 chars).

    * **Bind:** SQLite receives hyphenated strings; PostgreSQL receives
      :class:`uuid.UUID` (native driver support).
    * **Load:** Always returns :class:`uuid.UUID` in Python.

    Use for models that must run against both production PostgreSQL and local
    SQLite (tests, notebooks, ``pystator db`` defaults).
    """

    impl = String(36)
    cache_ok = True

    def load_dialect_impl(self, dialect: Any) -> Any:
        if dialect.name == "postgresql":
            return dialect.type_descriptor(PG_UUID(as_uuid=True))
        return dialect.type_descriptor(String(36))

    def process_bind_param(
        self, value: uuid.UUID | str | None, dialect: Any
    ) -> uuid.UUID | str | None:
        if value is None:
            return None
        uid = value if isinstance(value, uuid.UUID) else uuid.UUID(str(value))
        if dialect.name == "sqlite":
            return str(uid)
        return uid

    def process_result_value(
        self, value: uuid.UUID | str | bytes | None, dialect: Any
    ) -> uuid.UUID | None:
        if value is None:
            return None
        if isinstance(value, uuid.UUID):
            return value
        if isinstance(value, bytes):
            return uuid.UUID(bytes=value)
        return uuid.UUID(str(value))
