"""SQLite auto-init and Alembic upgrade (shared by API and notebooks).

Opening a session with :func:`~pystator.db.base.get_session` alone does not run
migrations. The FastAPI dependency applies this bootstrap for SQLite; marimo /
scripts should call :func:`ensure_sqlite_database_ready` before ``get_session``.
"""

from __future__ import annotations

import logging
from pathlib import Path

from sqlalchemy import create_engine

from pystator.db.base import Base
from pystator.db.config import get_alembic_config, get_migrations_dir

logger = logging.getLogger(__name__)

# Run bootstrap at most once per process per SQLite URL.
_sqlite_bootstrap_done_urls: set[str] = set()


def _run_alembic_upgrade(db_url: str) -> bool:
    """Attempt Alembic upgrade for SQLite; returns True on success."""
    try:
        from alembic import command
    except Exception as exc:
        logger.warning("Alembic unavailable for SQLite bootstrap: %s", exc)
        return False

    versions_dir = get_migrations_dir() / "versions"
    if not versions_dir.exists() or not any(versions_dir.iterdir()):
        logger.warning(
            "SQLite bootstrap: migrations directory is missing or empty: %s",
            versions_dir,
        )
        return False

    cfg = get_alembic_config(db_url)
    command.upgrade(cfg, "head")
    return True


def _try_provision_discovery() -> None:
    try:
        from pystator.discovery.provision import provision_discovery_from_app_config

        n = provision_discovery_from_app_config()
        if n:
            logger.info(
                "SQLite bootstrap: discovery schema applied (%d database(s))", n
            )
    except Exception as exc:
        logger.warning("Discovery schema provisioning failed during bootstrap: %s", exc)


def _fallback_create_all(db_url: str) -> None:
    """Fallback initializer when Alembic cannot run."""
    logger.warning(
        "Falling back to Base.metadata.create_all for SQLite bootstrap: %s", db_url
    )
    engine = create_engine(db_url)
    try:
        original_schemas = {
            table: table.schema for table in Base.metadata.tables.values()
        }
        for table in Base.metadata.tables.values():
            if table.schema == "pystator":
                table.schema = None
        Base.metadata.create_all(engine)
    finally:
        for table, schema in original_schemas.items():
            table.schema = schema
        engine.dispose()


def ensure_sqlite_database_ready(db_url: str) -> None:
    """Ensure SQLite DB path exists and schema is ready.

    No-op for non-SQLite URLs and in-memory SQLite.
    """
    if not db_url.startswith("sqlite://"):
        return
    if db_url in _sqlite_bootstrap_done_urls:
        return

    db_path = db_url[10:] if db_url.startswith("sqlite:///") else db_url
    if db_path == ":memory:":
        _sqlite_bootstrap_done_urls.add(db_url)
        return

    try:
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        try:
            _run_alembic_upgrade(db_url)
            logger.info("SQLite bootstrap migrations applied: %s", db_url)
        except Exception as mig_exc:
            logger.warning("SQLite migration bootstrap failed: %s", mig_exc)
            _fallback_create_all(db_url)
        _try_provision_discovery()
    except Exception as exc:
        logger.warning("Could not auto-initialize SQLite database: %s", exc)
    finally:
        _sqlite_bootstrap_done_urls.add(db_url)
