"""Server config table rows and PATCH application for ``pystator.cfg`` (settings UI)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pystator import __version__ as pystator_version
from pystator.config import (
    get_allow_inline_code_actions,
    get_allow_inline_code_actions_source,
    get_allow_inline_code_imports,
    get_allow_inline_code_imports_source,
    get_api_url,
    get_database_url,
    get_discovery_backend,
    get_discovery_database_url,
    get_discovery_drift_alert_threshold,
    get_discovery_drift_min_sample,
    get_discovery_drift_severe_threshold,
    get_discovery_low_sample_threshold,
    get_discovery_min_confidence,
    get_discovery_min_edge_count,
    get_ui_app_name,
    get_ui_theme,
    is_discovery_shadow_enabled,
)
from pystator.config.auth import get_auth_service_url, is_auth_disabled
from pystator.config.cfg_file_update import (
    MIRROR_TO_USER_SCOPED_SECTIONS,
    config_file_path_display,
    env_overrides,
    merge_and_write,
    normalize_bool_for_cfg,
    normalize_float_for_cfg,
    normalize_int_for_cfg,
    read_cfg_option,
    resolve_config_path_for_write,
    resolve_features_cfg_path_for_write,
)
from pystator.worker.config import WorkerConfig

# Cap request size (allow-listed keys only; this limits accidental huge payloads).
_MAX_PATCH_KEYS = 64


def _auth_mode_summary() -> str:
    if is_auth_disabled():
        return "open_no_login"
    if get_auth_service_url():
        return "external_oidc"
    return "builtin_jwt"


def _auth_label() -> str:
    mode = _auth_mode_summary()
    if mode == "open_no_login":
        return "Open (no login)"
    if mode == "external_oidc":
        return "External OAuth/OIDC"
    return "Built-in JWT users"


def _mask_database_url(url: str | None) -> str | None:
    if not url or "@" not in url:
        return url
    parts = url.split("@", 1)
    if ":" in parts[0] and "://" in parts[0]:
        user_pass = parts[0].split("://", 1)[1]
        if ":" in user_pass:
            user, _ = user_pass.split(":", 1)
            return parts[0].split("://", 1)[0] + "://" + user + ":****@" + parts[1]
    return url


def _worker_dlq_fields(wc: WorkerConfig) -> dict[str, Any]:
    if not wc.dlq_enabled:
        return {
            "dlq_enabled": False,
            "dlq_persistence": "disabled",
            "dlq_table_name": wc.dlq_table_name,
            "dlq_database_url_masked": None,
        }
    return {
        "dlq_enabled": True,
        "dlq_persistence": "database",
        "dlq_table_name": wc.dlq_table_name,
        "dlq_database_url_masked": _mask_database_url(wc.resolve_dlq_database_url()),
    }


# env_key -> (configparser section, value kind for PATCH)
PATCHABLE: dict[str, tuple[str, str]] = {
    "PYSTATOR_UI_APP_NAME": ("ui", "string"),
    "PYSTATOR_UI_THEME": ("ui", "string"),
    "PYSTATOR_API_URL": ("api", "string"),
    "PYSTATOR_DATABASE_URL": ("database", "string"),
    "PYSTATOR_ALLOW_INLINE_CODE_ACTIONS": ("features", "bool"),
    "PYSTATOR_ALLOW_INLINE_CODE_IMPORTS": ("features", "bool"),
    "PYSTATOR_DISCOVERY_BACKEND": ("discovery", "string"),
    "PYSTATOR_DISCOVERY_DATABASE_URL": ("discovery", "string"),
    "PYSTATOR_DISCOVERY_SHADOW_ENABLED": ("discovery", "bool"),
    "PYSTATOR_DISCOVERY_MIN_EDGE_COUNT": ("discovery", "int_min_1"),
    "PYSTATOR_DISCOVERY_MIN_CONFIDENCE": ("discovery", "float_0_1"),
    "PYSTATOR_DISCOVERY_DRIFT_ALERT_THRESHOLD": ("discovery", "float_0_1"),
    "PYSTATOR_DISCOVERY_DRIFT_SEVERE_THRESHOLD": ("discovery", "float_0_1"),
    "PYSTATOR_DISCOVERY_DRIFT_MIN_SAMPLE": ("discovery", "int_min_1"),
    "PYSTATOR_DISCOVERY_LOW_SAMPLE_THRESHOLD": ("discovery", "int_min_1"),
    "PYSTATOR_WORKER_POLL_INTERVAL_MS": ("worker", "int_min_1"),
    "PYSTATOR_WORKER_CONCURRENCY": ("worker", "int_min_1"),
    "PYSTATOR_WORKER_DB_URL": ("worker", "string"),
    "PYSTATOR_WORKER_DRAIN_TIMEOUT_S": ("worker", "int_min_1"),
    "PYSTATOR_WORKER_MAX_ATTEMPTS": ("worker", "int_min_1"),
    "PYSTATOR_WORKER_CLAIM_LEASE_TIMEOUT_S": ("worker", "int_min_1"),
    "PYSTATOR_WORKER_RETRY_BACKOFF_BASE_MS": ("worker", "int_min_1"),
    "PYSTATOR_WORKER_RETRY_BACKOFF_MAX_MS": ("worker", "int_min_1"),
    "PYSTATOR_WORKER_MACHINE_SOURCE": ("worker", "string"),
    "PYSTATOR_WORKER_DLQ_ENABLED": ("worker", "bool"),
    "PYSTATOR_WORKER_DLQ_DATABASE_URL": ("worker", "string"),
    "PYSTATOR_WORKER_DLQ_TABLE_NAME": ("worker", "string"),
}


def _row(
    *,
    row_id: str,
    env_key: str,
    section: str,
    kind: str,
    effective_display: str,
    source_hint: str = "",
    editable: bool = True,
) -> dict[str, Any]:
    locked = bool(env_key) and env_overrides(env_key)
    cfg_v = read_cfg_option(section, env_key) if env_key and section else None
    patch_ok = bool(env_key and env_key in PATCHABLE and editable)
    return {
        "id": row_id,
        "env_key": env_key or None,
        "section": section,
        "kind": kind,
        "effective_display": effective_display,
        "source_hint": source_hint,
        "env_locked": locked,
        "cfg_value": cfg_v,
        "editable": patch_ok and not locked,
    }


def build_server_config_rows() -> list[dict[str, Any]]:
    """Rows aligned with the settings server overview table (with edit metadata)."""
    wc = WorkerConfig()
    wdlq = _worker_dlq_fields(wc)
    raw_db = get_database_url()
    raw_disc = get_discovery_database_url()

    rows: list[dict[str, Any]] = []

    rows.append(
        _row(
            row_id="ui_app_name",
            env_key="PYSTATOR_UI_APP_NAME",
            section="ui",
            kind="string",
            effective_display=get_ui_app_name(),
            source_hint="env overrides [ui]",
        )
    )
    rows.append(
        _row(
            row_id="ui_theme",
            env_key="PYSTATOR_UI_THEME",
            section="ui",
            kind="string",
            effective_display=get_ui_theme(),
            source_hint="env overrides [ui]",
        )
    )
    rows.append(
        _row(
            row_id="release_version",
            env_key="",
            section="release",
            kind="readonly",
            effective_display=pystator_version or "—",
            editable=False,
        )
    )
    rows.append(
        _row(
            row_id="api_url",
            env_key="PYSTATOR_API_URL",
            section="api",
            kind="string",
            effective_display=get_api_url(),
            source_hint="env overrides [api]",
        )
    )
    rows.append(
        _row(
            row_id="auth_mode",
            env_key="",
            section="[auth]",
            kind="readonly",
            effective_display=_auth_label(),
            editable=False,
        )
    )
    rows.append(
        _row(
            row_id="database_url",
            env_key="PYSTATOR_DATABASE_URL",
            section="database",
            kind="password",
            effective_display=_mask_database_url(raw_db) or "(default sqlite)",
            source_hint="env overrides [database]; may also use alembic.ini",
        )
    )
    rows.append(
        _row(
            row_id="database_driver",
            env_key="",
            section="[database]",
            kind="readonly",
            effective_display="(see effective URL)",
            editable=False,
        )
    )
    rows.append(
        _row(
            row_id="inline_code_actions",
            env_key="PYSTATOR_ALLOW_INLINE_CODE_ACTIONS",
            section="features",
            kind="bool",
            effective_display=f"{get_allow_inline_code_actions()} ({get_allow_inline_code_actions_source()})",
            source_hint="features uses user-scoped cfg search when env unset",
        )
    )
    rows.append(
        _row(
            row_id="inline_code_imports",
            env_key="PYSTATOR_ALLOW_INLINE_CODE_IMPORTS",
            section="features",
            kind="bool",
            effective_display=f"{get_allow_inline_code_imports()} ({get_allow_inline_code_imports_source()})",
            source_hint="features uses user-scoped cfg search when env unset",
        )
    )
    rows.append(
        _row(
            row_id="discovery_backend",
            env_key="PYSTATOR_DISCOVERY_BACKEND",
            section="discovery",
            kind="string",
            effective_display=get_discovery_backend(),
        )
    )
    rows.append(
        _row(
            row_id="discovery_database_url",
            env_key="PYSTATOR_DISCOVERY_DATABASE_URL",
            section="discovery",
            kind="password",
            effective_display=_mask_database_url(raw_disc) or "—",
        )
    )
    rows.append(
        _row(
            row_id="discovery_shadow",
            env_key="PYSTATOR_DISCOVERY_SHADOW_ENABLED",
            section="discovery",
            kind="bool",
            effective_display="on" if is_discovery_shadow_enabled() else "off",
        )
    )
    rows.append(
        _row(
            row_id="discovery_min_edge",
            env_key="PYSTATOR_DISCOVERY_MIN_EDGE_COUNT",
            section="discovery",
            kind="number",
            effective_display=str(get_discovery_min_edge_count()),
        )
    )
    rows.append(
        _row(
            row_id="discovery_min_confidence",
            env_key="PYSTATOR_DISCOVERY_MIN_CONFIDENCE",
            section="discovery",
            kind="number",
            effective_display=str(get_discovery_min_confidence()),
        )
    )
    rows.append(
        _row(
            row_id="discovery_drift_alert",
            env_key="PYSTATOR_DISCOVERY_DRIFT_ALERT_THRESHOLD",
            section="discovery",
            kind="number",
            effective_display=str(get_discovery_drift_alert_threshold()),
        )
    )
    rows.append(
        _row(
            row_id="discovery_drift_severe",
            env_key="PYSTATOR_DISCOVERY_DRIFT_SEVERE_THRESHOLD",
            section="discovery",
            kind="number",
            effective_display=str(get_discovery_drift_severe_threshold()),
        )
    )
    rows.append(
        _row(
            row_id="discovery_drift_min_sample",
            env_key="PYSTATOR_DISCOVERY_DRIFT_MIN_SAMPLE",
            section="discovery",
            kind="number",
            effective_display=str(get_discovery_drift_min_sample()),
        )
    )
    rows.append(
        _row(
            row_id="discovery_low_sample",
            env_key="PYSTATOR_DISCOVERY_LOW_SAMPLE_THRESHOLD",
            section="discovery",
            kind="number",
            effective_display=str(get_discovery_low_sample_threshold()),
        )
    )
    rows.append(
        _row(
            row_id="worker_db_url",
            env_key="PYSTATOR_WORKER_DB_URL",
            section="worker",
            kind="password",
            effective_display=_mask_database_url(wc.db_url)
            or "(inherits database_url)",
            source_hint="env overrides [worker]",
        )
    )
    rows.append(
        _row(
            row_id="worker_poll_ms",
            env_key="PYSTATOR_WORKER_POLL_INTERVAL_MS",
            section="worker",
            kind="number",
            effective_display=str(wc.poll_interval_ms),
        )
    )
    rows.append(
        _row(
            row_id="worker_concurrency",
            env_key="PYSTATOR_WORKER_CONCURRENCY",
            section="worker",
            kind="number",
            effective_display=str(wc.concurrency),
        )
    )
    rows.append(
        _row(
            row_id="worker_drain_timeout_s",
            env_key="PYSTATOR_WORKER_DRAIN_TIMEOUT_S",
            section="worker",
            kind="number",
            effective_display=str(wc.drain_timeout_s),
        )
    )
    rows.append(
        _row(
            row_id="worker_max_attempts",
            env_key="PYSTATOR_WORKER_MAX_ATTEMPTS",
            section="worker",
            kind="number",
            effective_display=str(wc.max_attempts),
        )
    )
    rows.append(
        _row(
            row_id="worker_claim_lease_timeout_s",
            env_key="PYSTATOR_WORKER_CLAIM_LEASE_TIMEOUT_S",
            section="worker",
            kind="number",
            effective_display=str(wc.claim_lease_timeout_s),
        )
    )
    rows.append(
        _row(
            row_id="worker_retry_backoff_base_ms",
            env_key="PYSTATOR_WORKER_RETRY_BACKOFF_BASE_MS",
            section="worker",
            kind="number",
            effective_display=str(wc.retry_backoff_base_ms),
        )
    )
    rows.append(
        _row(
            row_id="worker_retry_backoff_max_ms",
            env_key="PYSTATOR_WORKER_RETRY_BACKOFF_MAX_MS",
            section="worker",
            kind="number",
            effective_display=str(wc.retry_backoff_max_ms),
        )
    )
    rows.append(
        _row(
            row_id="worker_machine_source",
            env_key="PYSTATOR_WORKER_MACHINE_SOURCE",
            section="worker",
            kind="string",
            effective_display=wc.machine_source,
        )
    )
    rows.append(
        _row(
            row_id="worker_dlq_enabled",
            env_key="PYSTATOR_WORKER_DLQ_ENABLED",
            section="worker",
            kind="bool",
            effective_display="on" if wdlq["dlq_enabled"] else "off",
        )
    )
    rows.append(
        _row(
            row_id="worker_dlq_summary",
            env_key="",
            section="[worker]",
            kind="readonly",
            effective_display=f"{wdlq['dlq_persistence']} · table {wdlq['dlq_table_name']}",
            editable=False,
        )
    )
    rows.append(
        _row(
            row_id="worker_dlq_database_url",
            env_key="PYSTATOR_WORKER_DLQ_DATABASE_URL",
            section="worker",
            kind="password",
            effective_display=wdlq["dlq_database_url_masked"] or "—",
        )
    )
    rows.append(
        _row(
            row_id="worker_dlq_table_name",
            env_key="PYSTATOR_WORKER_DLQ_TABLE_NAME",
            section="worker",
            kind="string",
            effective_display=wdlq["dlq_table_name"],
        )
    )

    return rows


def get_server_config_bundle() -> dict[str, Any]:
    existing = config_file_path_display()
    write_target = str(resolve_config_path_for_write())
    feat_target = str(resolve_features_cfg_path_for_write())
    return {
        "config_file_resolved": existing,
        "config_write_target": write_target,
        "features_config_write_target": feat_target,
        "rows": build_server_config_rows(),
    }


def apply_server_config_patch(updates: dict[str, Any]) -> tuple[Path, list[str]]:
    """Validate and write PATCH body ``{ env_key: value, ... }``. Returns path and keys written."""
    if not updates:
        raise ValueError("no updates provided")
    if len(updates) > _MAX_PATCH_KEYS:
        raise ValueError(f"too many keys (max {_MAX_PATCH_KEYS})")

    section_blobs: dict[str, dict[str, str]] = {}
    written: list[str] = []

    for env_key, raw in updates.items():
        if env_key not in PATCHABLE:
            raise ValueError(f"unknown or non-editable key: {env_key!r}")
        if env_overrides(env_key):
            raise ValueError(
                f"{env_key} is set in the process environment; unset it to manage via file"
            )
        section, kind = PATCHABLE[env_key]
        if kind == "bool":
            val = normalize_bool_for_cfg(raw)
        elif kind == "int_min_1":
            val = normalize_int_for_cfg(raw, min_val=1)
        elif kind == "float_0_1":
            val = normalize_float_for_cfg(raw, min_val=0.0, max_val=1.0)
        elif kind == "string":
            val = str(raw).strip()
        else:
            raise ValueError(f"internal: unknown kind {kind!r}")

        section_blobs.setdefault(section, {})[env_key] = val
        written.append(env_key)

    path = merge_and_write(section_blobs)
    mirror_sections = {
        s: section_blobs[s]
        for s in MIRROR_TO_USER_SCOPED_SECTIONS
        if s in section_blobs
    }
    if mirror_sections:
        alt = resolve_features_cfg_path_for_write()
        if alt.resolve() != path.resolve():
            merge_and_write(mirror_sections, target_path=alt)
    return path, written
