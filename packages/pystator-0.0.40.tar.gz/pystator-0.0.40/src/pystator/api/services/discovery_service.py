"""Service facade for inferred FSM discovery APIs."""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from functools import lru_cache
from typing import Any, Literal

from pystator.discovery import InferenceEngine, ObservedStateEvent
from pystator.discovery.models import (
    BuiltDiscoveryCandidate,
    DiscoveryDraft,
    ObservationIdentity,
    ShadowDiff,
)

logger = logging.getLogger(__name__)


def _same_discovery_registry_instance(row_id: str, requested: str) -> bool:
    """True when *row_id* refers to the same discovery connection instance as *requested*."""
    from uuid import UUID

    try:
        return UUID(str(row_id)) == UUID(str(requested))
    except ValueError:
        return str(row_id) == str(requested)


@lru_cache(maxsize=1)
def _cached_engine() -> InferenceEngine:
    """Per-process cached engine for API route handlers (default discovery instance).

    Tests can reset this via ``_cached_engine.cache_clear()`` and
    :func:`pystator.discovery.engine_cache.clear_engine_cache`.
    """
    from pystator.discovery.constants import DEFAULT_DISCOVERY_INSTANCE_ID
    from pystator.discovery.engine_cache import get_inference_engine

    return get_inference_engine(DEFAULT_DISCOVERY_INSTANCE_ID)


def _summarize_filter(d: DiscoveryDraft) -> str:
    """Return a short human-readable summary of an instance's filter."""
    if d.filter is None or d.filter.is_empty():
        return "all data"
    parts: list[str] = []
    if d.filter.channels:
        parts.append(f"{len(d.filter.channels)} channels")
    if d.filter.entity_ids:
        parts.append(f"{len(d.filter.entity_ids)} entities")
    if d.filter.sources:
        parts.append(f"{len(d.filter.sources)} sources")
    if d.filter.observed_after or d.filter.observed_before:
        parts.append("time-bounded")
    if d.filter.metadata_match:
        parts.append(f"{len(d.filter.metadata_match)} metadata")
    return " · ".join(parts) if parts else "all data"


class DiscoveryService:
    def __init__(self, engine: InferenceEngine | None = None) -> None:
        self._engine = engine or _cached_engine()

    @classmethod
    def for_instance(cls, instance_id: str) -> DiscoveryService:
        """Service bound to a specific discovery connection instance."""
        from pystator.discovery.engine_cache import get_inference_engine

        return cls(engine=get_inference_engine(instance_id))

    def record_observation(
        self,
        *,
        machine_name: str,
        entity_id: str,
        state: str,
        observed_at: datetime | None,
        source: str,
        source_event_id: str | None,
        ingest_seq: int,
        metadata: dict[str, Any] | None = None,
        ingested_at: datetime | None = None,
    ) -> bool:
        event = ObservedStateEvent(
            entity_id=entity_id,
            machine_name=machine_name,
            state=state,
            observed_at=observed_at or datetime.now(UTC),
            source=source,
            source_event_id=source_event_id,
            ingest_seq=ingest_seq,
            metadata=dict(metadata or {}),
            ingested_at=ingested_at or datetime.now(UTC),
        )
        return self._engine.record_observation(machine_name, event)

    def delete_machine_observation(
        self, machine_name: str, identity: ObservationIdentity
    ) -> bool:
        """Delete one observation row from the native store."""
        return self._engine.delete_observation(machine_name, identity)

    def delete_draft_observation(
        self,
        draft_id: str,
        *,
        instance_id: str | None,
        identity: ObservationIdentity,
    ) -> bool:
        """Delete one row when the draft uses native ``discovery_observations``."""
        draft = self._require_draft_for_native_mutation(draft_id, instance_id, None)
        return self._engine.delete_observation(draft.machine_name, identity)

    def insert_machine_observation_relative(
        self,
        machine_name: str,
        *,
        entity_id: str,
        reference: ObservationIdentity,
        position: Literal["above", "below"],
        state: str,
        source: str = "api",
        source_event_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """Insert adjacent to *reference* in newest-first order (native store)."""
        return self._engine.insert_observation_relative(
            machine_name,
            entity_id=entity_id,
            reference=reference,
            position=position,
            state=state,
            source=source,
            source_event_id=source_event_id,
            metadata=metadata,
        )

    def insert_draft_observation_relative(
        self,
        draft_id: str,
        *,
        instance_id: str | None,
        entity_id: str,
        reference: ObservationIdentity,
        position: Literal["above", "below"],
        state: str,
        source: str = "api",
        source_event_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        draft = self._require_draft_for_native_mutation(draft_id, instance_id, None)
        return self._engine.insert_observation_relative(
            draft.machine_name,
            entity_id=entity_id,
            reference=reference,
            position=position,
            state=state,
            source=source,
            source_event_id=source_event_id,
            metadata=metadata,
        )

    def _require_draft_for_native_mutation(
        self,
        draft_id: str,
        instance_id: str | None,
        machine_name: str | None,
    ) -> DiscoveryDraft:
        from pystator.discovery.constants import DEFAULT_DISCOVERY_INSTANCE_ID

        draft = self._engine.get_draft(draft_id)
        if draft is None:
            raise ValueError("draft not found")
        iid = instance_id or DEFAULT_DISCOVERY_INSTANCE_ID
        if not _same_discovery_registry_instance(draft.instance_id, iid):
            raise ValueError(
                "draft does not belong to this discovery connection instance"
            )
        if machine_name is not None and draft.machine_name != machine_name:
            raise ValueError("machine_name does not match this draft")
        if draft.observation_source is not None:
            raise ValueError(
                "Observation edits are only supported when the draft uses the "
                "native discovery_observations table (clear observation_source on the draft)"
            )
        return draft

    def build_candidate(
        self,
        machine_name: str,
        version: str | None = None,
        *,
        mode: Literal["inference", "manual"] = "inference",
        entity_ids: list[str] | None = None,
        edge_selection: list[tuple[str, str]] | None = None,
        min_edge_count: int | None = None,
        min_confidence: float | None = None,
        draft_id: str | None = None,
        filter_model: Any | None = None,
    ) -> dict[str, Any]:
        from pystator.api.models.discovery_filter import filter_model_to_dataclass

        candidate = self._engine.build_candidate(
            machine_name,
            version=version,
            mode=mode,
            entity_ids=entity_ids,
            edge_selection=edge_selection,
            min_edge_count=min_edge_count,
            min_confidence=min_confidence,
            draft_id=draft_id,
            filter=filter_model_to_dataclass(filter_model),
        )
        edges_snapshot = candidate.metadata.get("inferred_edges_snapshot")
        edges = edges_snapshot if isinstance(edges_snapshot, list) else []
        return {
            "machine_name": candidate.machine_name,
            "version": candidate.version,
            "candidate_sequence": candidate.candidate_sequence,
            "status": candidate.status,
            "config": candidate.config,
            "metadata": candidate.metadata,
            "edges": edges,
        }

    def preview_candidate_inputs(
        self,
        *,
        machine_name: str | None = None,
        filter_model: Any | None = None,
        mode: Literal["inference", "manual"] = "inference",
        entity_ids: list[str] | None = None,
        min_edge_count: int | None = None,
        min_confidence: float | None = None,
    ) -> dict[str, Any]:
        from dataclasses import replace

        from pystator.api.models.discovery_filter import filter_model_to_dataclass
        from pystator.discovery.models import DiscoveryDraftFilter

        if filter_model is not None:
            eff = filter_model_to_dataclass(filter_model) or DiscoveryDraftFilter()
        elif machine_name and str(machine_name).strip():
            eff = DiscoveryDraftFilter(channels=(str(machine_name).strip(),))
        else:
            eff = DiscoveryDraftFilter()
        if entity_ids:
            ids = tuple(sorted({x.strip() for x in entity_ids if x and x.strip()}))
            if ids and eff.entity_ids is None:
                eff = replace(eff, entity_ids=ids)
        payload = self._engine.preview_filter(
            eff,
            mode=mode,
            min_edge_count=min_edge_count,
            min_confidence=min_confidence,
        )
        return {
            "machine_name": payload["machine_name"],
            "mode": payload["mode"],
            "entity_ids_used": payload["entity_ids_used"],
            "observation_count": payload["observation_count"],
            "edges": [
                {
                    "source_state": e.source_state,
                    "destination_state": e.destination_state,
                    "count": e.count,
                    "unique_entities": e.unique_entities,
                    "unique_sources": e.unique_sources,
                    "confidence": e.confidence,
                }
                for e in payload["edges"]
            ],
            "selected_edges": [
                {
                    "source_state": e.source_state,
                    "destination_state": e.destination_state,
                    "count": e.count,
                    "unique_entities": e.unique_entities,
                    "unique_sources": e.unique_sources,
                    "confidence": e.confidence,
                }
                for e in payload["selected_edges"]
            ],
        }

    def list_entity_ids(self, machine_name: str) -> list[str]:
        store = self._engine._observations  # noqa: SLF001
        list_ids = getattr(store, "list_entity_ids", None)
        if callable(list_ids):
            return [str(x) for x in list_ids(machine_name)]
        observations = self._engine._observations.list_observations(machine_name)  # noqa: SLF001
        return sorted({x.entity_id for x in observations if x.entity_id})

    def list_machine_observations(
        self,
        machine_name: str,
        *,
        limit: int = 50,
        offset: int = 0,
        entity_id: str | None = None,
    ) -> dict[str, Any]:
        """Paginated raw observations for a machine (newest first when supported)."""
        store = self._engine._observations  # noqa: SLF001
        page_fn = getattr(store, "list_observations_page", None)
        lim = max(1, min(int(limit), 500))
        off = max(0, int(offset))
        if callable(page_fn):
            events, total = page_fn(
                machine_name, limit=lim, offset=off, entity_id=entity_id
            )
        else:
            all_obs = store.list_observations(machine_name, entity_id)
            total = len(all_obs)
            sorted_obs = sorted(
                all_obs,
                key=lambda x: (x.observed_at, x.ingest_seq, x.ingested_at),
                reverse=True,
            )
            events = sorted_obs[off : off + lim]
        items = [
            {
                "entity_id": ev.entity_id,
                "state": ev.state,
                "observed_at": ev.observed_at,
                "source": ev.source,
                "source_event_id": ev.source_event_id,
                "ingest_seq": ev.ingest_seq,
                "ingested_at": ev.ingested_at,
            }
            for ev in events
        ]
        return {
            "machine_name": machine_name,
            "items": items,
            "total": int(total),
            "limit": lim,
            "offset": off,
        }

    def list_draft_observations(
        self,
        draft_id: str,
        *,
        instance_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
        entity_id: str | None = None,
        entity_ids: list[str] | None = None,
    ) -> dict[str, Any]:
        """Paginated observations for a draft's effective scope and observation source."""
        from dataclasses import replace

        from pystator.discovery._drafts import effective_inference_filter
        from pystator.discovery.constants import DEFAULT_DISCOVERY_INSTANCE_ID

        draft = self._engine.get_draft(draft_id)
        if draft is None:
            raise ValueError("draft not found")
        iid = instance_id or DEFAULT_DISCOVERY_INSTANCE_ID
        if not _same_discovery_registry_instance(draft.instance_id, iid):
            raise ValueError(
                "draft does not belong to this discovery connection instance"
            )
        filt = effective_inference_filter(draft)
        ids_tuple: tuple[str, ...] | None = None
        if entity_ids:
            uniq = sorted({str(x).strip() for x in entity_ids if str(x).strip()})
            if uniq:
                ids_tuple = tuple(uniq)
        elif entity_id and str(entity_id).strip():
            ids_tuple = (str(entity_id).strip(),)
        if ids_tuple is not None:
            filt = replace(filt, entity_ids=ids_tuple)
        store = self._engine._observations  # noqa: SLF001
        fn = getattr(store, "list_observations_for_draft_scope", None)
        if not callable(fn):
            raise NotImplementedError(
                "This discovery backend does not support draft-scoped observation "
                "listing. Use SQLite or PostgreSQL, or MongoDB with a custom "
                "observation_source on the draft."
            )
        lim = max(1, min(int(limit), 500))
        off = max(0, int(offset))
        events, total = fn(
            filt,
            observation_source=draft.observation_source,
            limit=lim,
            offset=off,
        )
        items = [
            {
                "entity_id": ev.entity_id,
                "state": ev.state,
                "observed_at": ev.observed_at,
                "source": ev.source,
                "source_event_id": ev.source_event_id,
                "ingest_seq": ev.ingest_seq,
                "ingested_at": ev.ingested_at,
            }
            for ev in events
        ]
        return {
            "machine_name": draft.machine_name,
            "draft_id": draft_id,
            "items": items,
            "total": int(total),
            "limit": lim,
            "offset": off,
        }

    def delete_entity_observations(self, machine_name: str, entity_id: str) -> int:
        store = self._engine._observations  # noqa: SLF001
        deleter = getattr(store, "delete_observations_for_entity", None)
        if callable(deleter):
            return int(deleter(machine_name, entity_id))
        observations = self._engine._observations.list_observations(machine_name)  # noqa: SLF001
        return sum(1 for x in observations if x.entity_id == entity_id)

    def save_candidate_config(
        self,
        *,
        source_machine_name: str,
        target_machine_name: str,
        target_version: str | None,
        config: dict[str, Any],
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        version = target_version
        if not version:
            latest = self._engine.get_latest_built_candidate(target_machine_name)
            if latest is None:
                version = "0.1.0"
            else:
                parts = str(latest.version).split(".")
                if len(parts) == 3 and all(part.isdigit() for part in parts):
                    major, minor, patch = (int(p) for p in parts)
                    version = f"{major}.{minor}.{patch + 1}"
                else:
                    version = "0.1.0"
        candidate = BuiltDiscoveryCandidate(
            machine_name=target_machine_name,
            version=version,
            status="candidate",
            config=dict(config),
            metadata={
                "build_mode": "manual_config",
                "source_machine_name": source_machine_name,
                **(metadata or {}),
            },
        )
        saved = self._engine._built_candidates.save_built_candidate(candidate)  # noqa: SLF001
        return {
            "machine_name": saved.machine_name,
            "version": saved.version,
            "candidate_sequence": saved.candidate_sequence,
            "status": saved.status,
            "config": saved.config,
            "metadata": saved.metadata,
            "edges": [],
        }

    def update_candidate_status(
        self, *, machine_name: str, version: str, status: str
    ) -> BuiltDiscoveryCandidate:
        existing = self._engine.get_built_candidate(machine_name, version)
        if existing is None:
            raise ValueError(
                f"Candidate not found for machine={machine_name!r} version={version!r}"
            )
        updated = BuiltDiscoveryCandidate(
            machine_name=existing.machine_name,
            version=existing.version,
            status=status,
            config=dict(existing.config),
            created_at=existing.created_at,
            metadata=dict(existing.metadata),
            candidate_sequence=existing.candidate_sequence,
        )
        return self._engine._built_candidates.save_built_candidate(updated)  # noqa: SLF001

    def get_latest_candidate(self, machine_name: str) -> dict[str, Any] | None:
        candidate = self._engine.get_latest_built_candidate(machine_name)
        if candidate is None:
            return None
        return {
            "machine_name": candidate.machine_name,
            "version": candidate.version,
            "candidate_sequence": candidate.candidate_sequence,
            "status": candidate.status,
            "config": candidate.config,
            "metadata": candidate.metadata,
        }

    def list_candidate_summaries(self, machine_name: str) -> list[dict[str, Any]]:
        """Lightweight rows for candidate version listing (no full config)."""
        candidates = self._engine.list_built_candidates(machine_name)
        candidates = [c for c in candidates if str(c.status).lower() == "candidate"]
        candidates = sorted(
            candidates,
            key=lambda c: c.created_at,
            reverse=True,
        )
        shadow_rows = self._engine.list_shadow_diffs(machine_name, limit=5000)
        by_version: dict[str, list[ShadowDiff]] = {}
        for diff in shadow_rows:
            version = str((diff.metadata or {}).get("candidate_version") or "").strip()
            if not version:
                continue
            bucket = by_version.setdefault(version, [])
            # Keep only the most recent 200 rows per version.
            if len(bucket) < 200:
                bucket.append(diff)
        out: list[dict[str, Any]] = []
        for c in candidates:
            meta = c.metadata if isinstance(c.metadata, dict) else {}
            version_rows = by_version.get(str(c.version), [])
            shadow_total = len(version_rows)
            differs_n = sum(1 for r in version_rows if r.differs)
            out.append(
                {
                    "machine_name": c.machine_name,
                    "version": c.version,
                    "candidate_sequence": c.candidate_sequence,
                    "status": c.status,
                    "created_at": c.created_at,
                    "metadata": meta,
                    "observation_count_at_build": int(
                        meta.get("observation_count") or 0
                    ),
                    "shadow_diff_count_recent": shadow_total,
                    "drift_rate_recent": (
                        float(differs_n / shadow_total) if shadow_total else 0.0
                    ),
                    "build_mode": (
                        str(meta.get("build_mode"))
                        if meta.get("build_mode") is not None
                        else None
                    ),
                }
            )
        return out

    def get_candidate_version(
        self, machine_name: str, version: str
    ) -> BuiltDiscoveryCandidate | None:
        """Return the stored built candidate domain object, if any."""
        return self._engine.get_built_candidate(machine_name, version)

    def get_candidate_detail(
        self, machine_name: str, version: str
    ) -> dict[str, Any] | None:
        """Full candidate payload including edge diagnostics (same shape as build)."""
        candidate = self._engine.get_built_candidate(machine_name, version)
        if candidate is None:
            return None
        edges_snapshot = candidate.metadata.get("inferred_edges_snapshot")
        edges = edges_snapshot if isinstance(edges_snapshot, list) else []
        return {
            "machine_name": candidate.machine_name,
            "version": candidate.version,
            "candidate_sequence": candidate.candidate_sequence,
            "status": candidate.status,
            "config": candidate.config,
            "metadata": candidate.metadata,
            "edges": edges,
        }

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[dict[str, Any]]:
        diffs = self._engine.list_shadow_diffs(machine_name, limit=limit)
        return [
            {
                "machine_name": d.machine_name,
                "source_state": d.source_state,
                "trigger": d.trigger,
                "active_success": d.active_success,
                "active_target_state": d.active_target_state,
                "candidate_success": d.candidate_success,
                "candidate_target_state": d.candidate_target_state,
                "differs": d.differs,
                "reason": d.reason,
                "metadata": d.metadata,
            }
            for d in diffs
        ]

    def compare_against_baseline(
        self,
        machine_name: str,
        baseline_config: dict[str, Any],
        baseline_machine_name: str,
        candidate_version: str | None = None,
    ) -> list[dict[str, Any]]:
        """On-demand cross-channel shadow comparison."""
        diffs = self._engine.compare_candidate_against_baseline(
            machine_name=machine_name,
            baseline_config=baseline_config,
            baseline_machine_name=baseline_machine_name,
            candidate_version=candidate_version,
        )
        return [
            {
                "machine_name": d.machine_name,
                "source_state": d.source_state,
                "trigger": d.trigger,
                "active_success": d.active_success,
                "active_target_state": d.active_target_state,
                "candidate_success": d.candidate_success,
                "candidate_target_state": d.candidate_target_state,
                "differs": d.differs,
                "reason": d.reason,
                "metadata": d.metadata,
            }
            for d in diffs
        ]

    def run_shadow_compare(
        self,
        *,
        machine_name: str,
        active_config: dict[str, Any],
        source_state: str,
        trigger: str,
        context: dict[str, Any] | None = None,
    ) -> ShadowDiff | None:
        return self._engine.run_shadow_compare(
            machine_name=machine_name,
            active_config=active_config,
            source_state=source_state,
            trigger=trigger,
            context=context,
        )

    def list_fleet_summaries(
        self,
        *,
        query: str | None = None,
        sort: str = "machine_name",
        order: str = "asc",
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, Any]:
        """Paginated fleet index rows from the discovery store (SQL or in-memory).

        ``sort`` must be one of: machine_name, last_observation_at, observation_count,
        candidate_count, drift_rate_recent, shadow_diff_count_recent.
        ``order`` is ``asc`` or ``desc``.
        """
        store = self._engine._observations  # noqa: SLF001 — single shared store instance
        rows: list[dict[str, Any]]
        if hasattr(store, "list_fleet_summaries"):
            rows = store.list_fleet_summaries()  # type: ignore[union-attr]
            # NOTE: the current store protocol does not expose
            # limit/offset/sort/query, so pagination runs in Python
            # here. Protocol extension is deferred to a future
            # iteration; debug-log the fallback so operators can see
            # when a large fleet starts producing oversized pages.
            if len(rows) > limit * 4:
                logger.debug(
                    "list_fleet_summaries: python-level pagination over "
                    "%d rows (limit=%d). Consider pushing pagination "
                    "into the store protocol.",
                    len(rows),
                    limit,
                )
        else:
            rows = []

        qnorm = (query or "").strip().lower()
        if qnorm:
            rows = [r for r in rows if qnorm in str(r.get("machine_name", "")).lower()]

        sort_keys = {
            "machine_name",
            "last_observation_at",
            "observation_count",
            "candidate_count",
            "drift_rate_recent",
            "shadow_diff_count_recent",
        }
        key = sort if sort in sort_keys else "machine_name"
        reverse = str(order).lower() == "desc"
        min_dt = datetime.min.replace(tzinfo=UTC)

        def sort_value(row: dict[str, Any]) -> Any:
            if key == "machine_name":
                return row.get("machine_name") or ""
            v = row.get(key)
            if key == "last_observation_at" and v is None:
                return min_dt
            if isinstance(v, datetime):
                return v
            if v is None:
                return 0
            return v

        rows = sorted(rows, key=sort_value, reverse=reverse)
        total = len(rows)
        page = rows[offset : offset + max(0, limit)]
        # JSON-serializable datetimes as ISO strings for route layer
        serializable: list[dict[str, Any]] = []
        for r in page:
            item = dict(r)
            loa = item.get("last_observation_at")
            if isinstance(loa, datetime):
                item["last_observation_at"] = loa
            lcca = item.get("latest_candidate_created_at")
            if isinstance(lcca, datetime):
                item["latest_candidate_created_at"] = lcca
            serializable.append(item)
        return {
            "items": serializable,
            "total": total,
            "limit": limit,
            "offset": offset,
        }

    @staticmethod
    def draft_to_dict(d: DiscoveryDraft) -> dict[str, Any]:
        from pystator.api.models.discovery_filter import filter_dataclass_to_model

        obs = d.observation_source
        return {
            "id": d.id,
            "instance_id": d.instance_id,
            "title": d.title,
            "selected_entity_ids": list(d.selected_entity_ids),
            "mode": d.mode,
            "min_edge_count": d.min_edge_count,
            "min_confidence": d.min_confidence,
            "manual_edge_selection": [
                {"source_state": a, "destination_state": b}
                for (a, b) in d.manual_edge_selection
            ],
            "created_at": d.created_at,
            "updated_at": d.updated_at,
            "last_built_version": d.last_built_version,
            "filter": filter_dataclass_to_model(d.filter),
            "observation_source": obs.to_json_dict() if obs is not None else None,
        }

    def list_drafts_full(self, instance_id: str | None = None) -> list[dict[str, Any]]:
        """Return full draft payloads for one discovery connection instance."""
        from pystator.discovery.constants import DEFAULT_DISCOVERY_INSTANCE_ID
        from pystator.discovery.engine_cache import get_inference_engine

        iid = instance_id or DEFAULT_DISCOVERY_INSTANCE_ID
        eng = get_inference_engine(iid)

        drafts = [
            d
            for d in eng.list_all_drafts()
            if _same_discovery_registry_instance(d.instance_id, iid)
        ]
        drafts.sort(key=lambda d: d.updated_at, reverse=True)
        return [self.draft_to_dict(d) for d in drafts]

    def create_draft(
        self,
        title: str,
        *,
        instance_id: str | None = None,
        filter_model: Any | None = None,
        min_edge_count: int | None = None,
        min_confidence: float | None = None,
        observation_source: Any | None = None,
    ) -> dict[str, Any]:
        from pystator.api.models.discovery_filter import filter_model_to_dataclass
        from pystator.discovery.observation_source import ObservationSourceConfig

        obs_src: ObservationSourceConfig | None = None
        if isinstance(observation_source, dict) and observation_source:
            obs_src = ObservationSourceConfig.from_json_dict(observation_source)
            if obs_src is not None:
                obs_src.validate_identifiers()
        d = self._engine.create_draft(
            title,
            instance_id=instance_id,
            filter=filter_model_to_dataclass(filter_model),
            min_edge_count=min_edge_count,
            min_confidence=min_confidence,
            observation_source=obs_src,
        )
        return self.draft_to_dict(d)

    def patch_draft(
        self,
        draft_id: str,
        patch: dict[str, Any],
    ) -> dict[str, Any]:
        from pystator.api.models.discovery_filter import (
            DiscoveryDraftFilterModel,
            filter_model_to_dataclass,
        )

        d = self._engine.get_draft(draft_id)
        if d is None:
            raise ValueError("draft not found")

        kwargs: dict[str, Any] = {}
        if "title" in patch and patch["title"] is not None:
            kwargs["title"] = patch["title"]
        if "selected_entity_ids" in patch:
            kwargs["selected_entity_ids"] = list(patch["selected_entity_ids"] or [])
        if "mode" in patch and patch["mode"] is not None:
            kwargs["mode"] = patch["mode"]
        if "min_edge_count" in patch and patch["min_edge_count"] is not None:
            kwargs["min_edge_count"] = patch["min_edge_count"]
        if "min_confidence" in patch and patch["min_confidence"] is not None:
            kwargs["min_confidence"] = patch["min_confidence"]
        if "manual_edge_selection" in patch:
            raw = patch["manual_edge_selection"] or []
            pairs: list[tuple[str, str]] = []
            for idx, item in enumerate(raw):
                if isinstance(item, dict):
                    s = str(item.get("source_state", "")).strip()
                    dest = str(item.get("destination_state", "")).strip()
                    if s and dest:
                        pairs.append((s, dest))
                        continue
                # The Pydantic layer already rejects this with 422 for
                # HTTP callers; this branch catches direct Python calls
                # that bypass the validator. Log + skip so the store
                # never sees a malformed pair.
                logger.warning(
                    "discarding malformed manual_edge_selection entry at "
                    "index %d for draft %s",
                    idx,
                    draft_id,
                )
            kwargs["manual_edge_selection"] = pairs
        if patch.get("clear_filter"):
            kwargs["clear_filter"] = True
        elif "filter" in patch and patch["filter"] is not None:
            raw_filter = patch["filter"]
            filter_model = (
                raw_filter
                if isinstance(raw_filter, DiscoveryDraftFilterModel)
                else DiscoveryDraftFilterModel.model_validate(raw_filter)
            )
            kwargs["filter"] = filter_model_to_dataclass(filter_model)
        if "observation_source" in patch:
            from pystator.discovery.observation_source import ObservationSourceConfig

            raw = patch["observation_source"]
            if raw is None or (isinstance(raw, dict) and not raw):
                kwargs["clear_observation_source"] = True
            else:
                if not isinstance(raw, dict):
                    raise ValueError("observation_source must be an object or null")
                obs_src = ObservationSourceConfig.from_json_dict(raw)
                if obs_src is None:
                    kwargs["clear_observation_source"] = True
                else:
                    obs_src.validate_identifiers()
                    kwargs["new_observation_source"] = obs_src
        if kwargs:
            updated = self._engine.update_draft(draft_id, **kwargs)
        else:
            updated = self._engine.get_draft(draft_id)
            if updated is None:
                raise ValueError("draft not found")
        return self.draft_to_dict(updated)

    def delete_draft(self, draft_id: str) -> bool:
        d = self._engine.get_draft(draft_id)
        if d is None:
            return False
        return self._engine.delete_draft(draft_id)

    def delete_built_candidate(self, machine_name: str, version: str) -> bool:
        """Delete a built candidate. Raises ValueError if promoted."""
        existing = self._engine.get_built_candidate(machine_name, version)
        if existing is None:
            return False
        if existing.status == "promoted":
            raise ValueError("Cannot delete a promoted candidate")
        return self._engine.delete_built_candidate(machine_name, version)

    def preview_draft(self, draft_id: str) -> dict[str, Any]:
        d = self._engine.get_draft(draft_id)
        if d is None:
            raise ValueError("draft not found")
        payload = self._engine.preview_draft(draft_id)
        return {
            "machine_name": payload["machine_name"],
            "mode": payload["mode"],
            "entity_ids_used": payload["entity_ids_used"],
            "observation_count": payload["observation_count"],
            "edges": [
                {
                    "source_state": e.source_state,
                    "destination_state": e.destination_state,
                    "count": e.count,
                    "unique_entities": e.unique_entities,
                    "unique_sources": e.unique_sources,
                    "confidence": e.confidence,
                }
                for e in payload["edges"]
            ],
            "selected_edges": [
                {
                    "source_state": e.source_state,
                    "destination_state": e.destination_state,
                    "count": e.count,
                    "unique_entities": e.unique_entities,
                    "unique_sources": e.unique_sources,
                    "confidence": e.confidence,
                }
                for e in payload["selected_edges"]
            ],
        }

    def build_draft(
        self,
        draft_id: str,
        *,
        target_machine_name: str | None = None,
    ) -> dict[str, Any]:
        d = self._engine.get_draft(draft_id)
        if d is None:
            raise ValueError("draft not found")
        candidate = self._engine.build_from_draft(
            draft_id, target_machine_name=target_machine_name
        )
        edges_snapshot = candidate.metadata.get("inferred_edges_snapshot")
        edges = edges_snapshot if isinstance(edges_snapshot, list) else []
        return {
            "machine_name": candidate.machine_name,
            "version": candidate.version,
            "candidate_sequence": candidate.candidate_sequence,
            "status": candidate.status,
            "config": candidate.config,
            "metadata": candidate.metadata,
            "edges": edges,
        }

    def list_connection_instances_registry(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        query: str | None = None,
    ) -> dict[str, Any]:
        """List registered discovery connection instances (main app database)."""
        from pystator.db.base import get_session
        from pystator.db.config import get_db_url
        from pystator.discovery import instance_registry

        db_url = get_db_url()
        if not db_url:
            return {"items": [], "total": 0, "limit": limit, "offset": offset}
        session = get_session(db_url)
        try:
            rows = instance_registry.list_connection_instances(session)
        finally:
            session.close()
        q = (query or "").strip().lower()
        if q:
            rows = [
                r
                for r in rows
                if q in (r.title or "").lower()
                or q in (r.namespace or "").lower()
                or q in r.backend.lower()
                or q in r.id.lower()
            ]
        total = len(rows)
        page = rows[offset : offset + max(0, limit)]
        items = [instance_registry.connection_instance_to_dict(r) for r in page]
        return {"items": items, "total": total, "limit": limit, "offset": offset}

    def list_drafts_for_connection_instance(
        self,
        instance_id: str,
        *,
        limit: int = 50,
        offset: int = 0,
        query: str | None = None,
    ) -> dict[str, Any]:
        """Return drafts for one discovery connection instance (draft summaries)."""
        return self.list_all_instances(
            limit=limit, offset=offset, query=query, instance_id=instance_id
        )

    def list_all_instances(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        query: str | None = None,
        instance_id: str | None = None,
    ) -> dict[str, Any]:
        """Return draft summaries for a discovery connection instance.

        When ``instance_id`` is omitted, the default discovery instance is used
        (backward compatible with single-store deployments).
        """
        from pystator.api.models.discovery_filter import filter_dataclass_to_model
        from pystator.discovery.constants import DEFAULT_DISCOVERY_INSTANCE_ID
        from pystator.discovery.engine_cache import get_inference_engine

        iid = instance_id or DEFAULT_DISCOVERY_INSTANCE_ID
        eng = get_inference_engine(iid)
        drafts = eng.list_all_drafts()
        # Multiple registry connections can share one discovery DB file; drafts are
        # scoped by ``instance_id`` on each row — only return rows for this connection.
        drafts = [
            d for d in drafts if _same_discovery_registry_instance(d.instance_id, iid)
        ]
        # NOTE: the store protocol does not yet expose limit/offset
        # on list_all_drafts; pagination is applied in Python below.
        # Debug-log the fallback so operators can see when the page
        # starts over-fetching heavily.
        if len(drafts) > limit * 4:
            logger.debug(
                "list_all_instances: python-level pagination over %d "
                "drafts (limit=%d). Consider pushing pagination into "
                "the store protocol.",
                len(drafts),
                limit,
            )
        q = (query or "").strip().lower()
        if q:
            drafts = [d for d in drafts if q in (d.title or "").lower()]
        total = len(drafts)
        page = drafts[offset : offset + max(0, limit)]
        draft_ids = [d.id for d in page]
        aggregates = (
            eng._built_candidates.count_built_candidates_by_draft(  # noqa: SLF001
                draft_ids
            )
            if draft_ids
            else {}
        )
        items: list[dict[str, Any]] = []
        for d in page:
            agg = aggregates.get(d.id)
            built_count = agg.count if agg is not None else 0
            last_built_version = agg.latest_version if agg is not None else None
            obs = d.observation_source
            items.append(
                {
                    "id": d.id,
                    "instance_id": d.instance_id,
                    "catalog_slug": d.machine_name,
                    "title": d.title,
                    "filter": filter_dataclass_to_model(d.filter),
                    "filter_summary": _summarize_filter(d),
                    "min_edge_count": d.min_edge_count,
                    "min_confidence": d.min_confidence,
                    "observation_source": (
                        obs.to_json_dict() if obs is not None else None
                    ),
                    "built_count": built_count,
                    "last_built_version": last_built_version,
                    "created_at": d.created_at,
                    "updated_at": d.updated_at,
                }
            )
        return {
            "items": items,
            "total": total,
            "limit": limit,
            "offset": offset,
        }
