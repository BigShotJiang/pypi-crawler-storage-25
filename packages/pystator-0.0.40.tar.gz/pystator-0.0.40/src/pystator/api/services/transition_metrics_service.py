"""Per-edge (source, target, trigger) transition metrics for diagram augmentation."""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from pystator.db.models import TransitionHistoryModel


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _window_start(hours: int, now: datetime) -> datetime:
    return now - timedelta(hours=hours)


def _compute_p95(values: list[int]) -> int | None:
    if not values:
        return None
    sorted_values = sorted(values)
    rank = max(1, (95 * len(sorted_values) + 99) // 100)
    return sorted_values[min(rank - 1, len(sorted_values) - 1)]


@dataclass(frozen=True)
class TransitionMetricsWindow:
    start: datetime
    end: datetime


def _group_key(
    source_state: str, target_state: str | None, trigger: str
) -> tuple[str, str, str]:
    tgt = "" if target_state is None else str(target_state)
    return (str(source_state), tgt, str(trigger))


def compute_transition_edge_metrics(
    session: Session,
    machine_name: str,
    window_hours: int = 24,
) -> tuple[TransitionMetricsWindow, dict[tuple[str, str, str], dict[str, Any]]]:
    """Aggregate transition_history by (source_state, target_state, trigger) in a trailing window.

    Returns:
        (window, metrics_by_group) where each value dict has:
        attempts_total, attempts_failed, duration_p95_ms, top_error (dict or None)
    """
    now = _utc_now()
    start = _window_start(window_hours, now)
    window = TransitionMetricsWindow(start=start, end=now)

    rows = session.execute(
        select(
            TransitionHistoryModel.source_state,
            TransitionHistoryModel.target_state,
            TransitionHistoryModel.trigger,
            TransitionHistoryModel.success,
            TransitionHistoryModel.duration_ms,
            TransitionHistoryModel.error_type,
            TransitionHistoryModel.error_message,
        ).where(
            TransitionHistoryModel.machine_name == machine_name,
            TransitionHistoryModel.created_at >= start,
            TransitionHistoryModel.created_at <= now,
        )
    ).all()

    totals: dict[tuple[str, str, str], int] = defaultdict(int)
    failed: dict[tuple[str, str, str], int] = defaultdict(int)
    durations: dict[tuple[str, str, str], list[int]] = defaultdict(list)
    err_sigs: dict[tuple[str, str, str], Counter[tuple[str | None, str | None]]] = (
        defaultdict(Counter)
    )

    for src, tgt, trig, ok, dur_ms, et, em in rows:
        if src is None or trig is None:
            continue
        k = _group_key(str(src), str(tgt) if tgt is not None else None, str(trig))
        totals[k] += 1
        if not ok:
            failed[k] += 1
            sig = (
                str(et) if et is not None else None,
                str(em) if em is not None else None,
            )
            err_sigs[k][sig] += 1
        if dur_ms is not None and isinstance(dur_ms, int):
            durations[k].append(int(dur_ms))

    metrics: dict[tuple[str, str, str], dict[str, Any]] = {}
    for k in sorted(totals.keys()):
        src_s, tgt_s, trig_s = k
        top: dict[str, Any] | None = None
        counter = err_sigs.get(k)
        if counter:
            (et, em), cnt = counter.most_common(1)[0]
            top = {"error_type": et, "error_message": em, "count": int(cnt)}
        dlist = durations.get(k, [])
        metrics[k] = {
            "source_state": src_s,
            "target_state": tgt_s,
            "trigger": trig_s,
            "attempts_total": int(totals[k]),
            "attempts_failed": int(failed[k]),
            "duration_p95_ms": _compute_p95(dlist),
            "top_error": top,
        }

    return window, metrics
