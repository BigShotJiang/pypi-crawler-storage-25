"""FSM service for PyStator API.

Builds machines from config and processes events. Uses pass-through guards
so any config works without requiring guard implementations.

The build path delegates to ``machine_builder`` + ``machine_parser``
so validation and construction share a single canonical code path.
"""

from __future__ import annotations

from typing import Any

from pystator import GuardRegistry, StateMachine
from pystator.api.services.transition_outcome import outcome_from_transition_result
from pystator.errors import ConfigurationError
from pystator.machine_builder import build_machine
from pystator.machine_parser import parse_machine


def _collect_guard_names(config: dict[str, Any]) -> set[str]:
    """Collect all named guard names referenced in transitions.

    Only string guard names are collected; dict guards (inline expr or
    declarative check) are handled by the evaluator and must not be
    added to the set (dicts are unhashable).
    """
    names: set[str] = set()
    for trans in config.get("transitions", []):
        guards = trans.get("guards", [])
        if isinstance(guards, str):
            names.add(guards)
        else:
            for g in guards if isinstance(guards, list) else []:
                if isinstance(g, str):
                    names.add(g)
    return names


def _build_pass_through_guards(guard_names: set[str]) -> GuardRegistry:
    """Build a registry that passes all listed guard names (no-op for API)."""
    registry = GuardRegistry()
    for name in guard_names:
        registry.register(name, lambda ctx: True)
    return registry


def build_machine_from_config(config: dict[str, Any]) -> StateMachine:
    """Build a StateMachine from config with pass-through guards.

    All guards referenced in transitions are registered as no-op (always pass)
    so the API can compute transitions without requiring guard implementations.

    Uses ``machine_parser.parse_machine`` (validate=False — caller already
    validated) + ``machine_builder.build_machine`` for the canonical build
    path, then layers on pass-through guards.
    """
    guard_names = _collect_guard_names(config)
    guards = _build_pass_through_guards(guard_names)

    try:
        definition = parse_machine(config, validate=False)
        machine = build_machine(definition, guards=guards)
    except (ConfigurationError, ValueError):
        machine = StateMachine.from_dict(config)
        machine.bind_guards(guards)

    return machine


def validate_config(
    config: dict[str, Any],
) -> tuple[bool, list[str], dict[str, Any] | None, list[str]]:
    """Validate FSM config. Returns (valid, errors, info, warnings).

    Uses machine_parser for the canonical validation path,
    then builds a StateMachine to extract state/trigger metadata.

    ``warnings`` are non-fatal (e.g. unrecognized ``error_policy`` keys); empty when invalid.
    """
    errors: list[str] = []
    try:
        definition = parse_machine(config, validate=True)
        from pystator.config.validator import ConfigValidator

        warnings = ConfigValidator().config_warnings(config)
        machine = build_machine(definition)
        info = {
            "machine_name": definition.name,
            "version": definition.version,
            "state_names": machine.state_names,
            "trigger_names": machine.trigger_names,
            "terminal_states": machine.terminal_states,
        }
        return True, [], info, warnings
    except ConfigurationError as e:
        errors.append(str(e))
        if e.context:
            for k, v in e.context.items():
                errors.append(f"  {k}: {v}")
        return False, errors, None, []
    except Exception as e:
        errors.append(str(e))
        return False, errors, None, []


class FSMService:
    """Service for building machines and processing events."""

    def process(
        self,
        config: dict[str, Any],
        current_state: str,
        trigger: str,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Build machine from config and process one event.

        Returns a dict suitable for JSON: success, source_state, target_state,
        trigger, actions, error (:class:`FsmOutcomeError` shape), error_message,
        metadata.
        """
        machine = build_machine_from_config(config)
        ctx = context or {}
        result = machine.process(current_state, trigger, ctx)
        return outcome_from_transition_result(result)

    def validate(
        self, config: dict[str, Any]
    ) -> tuple[bool, list[str], dict[str, Any] | None, list[str]]:
        """Validate config. Returns (valid, errors, info, warnings)."""
        return validate_config(config)
