"""Response models — entity_metrics."""

from __future__ import annotations

from pydantic import BaseModel, Field

from .analytics import DurationPercentiles


class ErrorPatternItem(BaseModel):
    """Single error pattern entry for entity error breakdown."""

    error_type: str | None = Field(None, description="Error type classification")
    trigger: str = Field(..., description="Trigger that caused the failure")
    source_state: str = Field(..., description="State when failure occurred")
    count: int = Field(..., description="Number of occurrences")
    last_occurred: str = Field(..., description="ISO timestamp of most recent")


class DwellByStateItem(BaseModel):
    """Dwell time statistics for a single state."""

    state: str = Field(..., description="State name")
    avg_ms: int = Field(..., description="Average dwell time in ms")
    min_ms: int = Field(..., description="Minimum dwell time in ms")
    max_ms: int = Field(..., description="Maximum dwell time in ms")
    visit_count: int = Field(..., description="Number of times state was visited")


class FleetComparison(BaseModel):
    """Entity vs fleet performance comparison."""

    entity_failure_rate: float = Field(..., description="This entity's failure rate")
    fleet_failure_rate: float = Field(..., description="Fleet-wide failure rate")
    entity_avg_latency_ms: int | None = Field(
        None, description="This entity's avg latency"
    )
    fleet_avg_latency_ms: int | None = Field(None, description="Fleet-wide avg latency")
    latency_percentile_rank: float | None = Field(
        None, description="Percentile rank 0-100, higher=faster"
    )


class VelocityPoint(BaseModel):
    """Single point in the velocity sparkline."""

    timestamp: str = Field(..., description="ISO timestamp of transition")
    duration_ms: int = Field(..., description="Transition duration in ms")


class EntityMetricsResponse(BaseModel):
    """Comprehensive per-entity metrics."""

    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str | None = Field(None, description="Machine name")

    # P0 — Health
    health_score: int = Field(..., description="Composite health score 0-100")
    health_status: str = Field(
        ..., description="healthy (>=80), warning (>=50), critical (<50)"
    )
    staleness_seconds: int | None = Field(
        None, description="Seconds since last transition"
    )
    staleness_label: str = Field(..., description="Human-readable staleness")

    # P0 — Error breakdown
    error_patterns: list[ErrorPatternItem] = Field(default_factory=list)
    recent_failure_rate: float = Field(
        0.0, description="Failure rate of last 20 transitions"
    )

    # P1 — Performance
    latency_percentiles: DurationPercentiles = Field(
        default_factory=DurationPercentiles
    )
    dwell_by_state: list[DwellByStateItem] = Field(default_factory=list)

    # P1 — Stuck detection
    is_potentially_stuck: bool = Field(False, description="Entity appears stuck")
    stuck_state: str | None = Field(None, description="State entity may be stuck in")
    stuck_current_dwell_ms: int | None = Field(
        None, description="Current dwell in stuck state"
    )
    stuck_avg_dwell_ms: int | None = Field(
        None, description="Average dwell for stuck state"
    )

    # P2 — Behavioral
    state_revisits: dict[str, int] = Field(
        default_factory=dict, description="States visited >1 time"
    )
    has_cycles: bool = Field(False, description="Whether entity revisited any state")
    fleet_comparison: FleetComparison | None = Field(
        None, description="Fleet comparison metrics"
    )

    # P3 — Trend
    velocity_points: list[VelocityPoint] = Field(default_factory=list)
