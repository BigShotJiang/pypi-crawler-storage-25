"""Response models — settings."""

from __future__ import annotations

from pydantic import BaseModel, Field


class DatabaseConfigResponse(BaseModel):
    """Response for database configuration info."""

    configured_url: str | None = Field(None, description="Configured DB URL (masked)")
    actual_url: str = Field(..., description="Actual DB URL in use")
    database_type: str = Field(..., description="Database type (SQLite, PostgreSQL)")
    is_default: bool = Field(..., description="Whether using default SQLite")
    machine_count: int = Field(..., description="Number of stored machines")
    message: str = Field(..., description="Human-readable status message")


class DatabaseTestResponse(BaseModel):
    """Response for database connection test."""

    success: bool = Field(..., description="Whether connection succeeded")
    message: str = Field(..., description="Result message")


class DiscoveryConfigResponse(BaseModel):
    """Response for discovery configuration info."""

    backend: str = Field(..., description="Configured discovery backend")
    database_url: str | None = Field(
        None, description="Configured discovery DB URL (masked)"
    )
    shadow_enabled: bool = Field(..., description="Whether shadow mode is enabled")
    min_edge_count: int = Field(..., description="Minimum edge count threshold")
    min_confidence: float = Field(..., description="Minimum confidence threshold")
    drift_alert_threshold: float = Field(
        ...,
        description="Candidate drift alert threshold (0-1)",
    )
    drift_severe_threshold: float = Field(
        ...,
        description="Candidate drift severe threshold (0-1)",
    )
    drift_min_sample: int = Field(
        ...,
        description="Minimum shadow sample count before drift tags are considered",
    )
    low_sample_threshold: int = Field(
        ...,
        description="Sample count below which candidate is tagged as low-sample",
    )


class DiscoveryDatabaseTestResponse(BaseModel):
    """Response for discovery backend connectivity test."""

    success: bool = Field(..., description="Whether backend connection succeeded")
    message: str = Field(..., description="Result message")


class DlqTestResponse(BaseModel):
    """Response for DLQ connection test."""

    success: bool = Field(..., description="Whether DLQ connection succeeded")
    message: str = Field(..., description="Result message")


class DlqStatsResponse(BaseModel):
    """Response for DLQ statistics."""

    total_messages: int = Field(..., description="Total rows in DLQ table")
    by_reason: dict[str, int | None] = Field(default_factory=dict)
    by_stage: dict[str, int | None] = Field(default_factory=dict)
    by_status: dict[str, int | None] = Field(default_factory=dict)


class WorkerDlqConfigResponse(BaseModel):
    """Worker DLQ settings as read from env / pystator.cfg (masked URL)."""

    dlq_enabled: bool = Field(..., description="Whether worker DLQ is enabled")
    dlq_database_url: str | None = Field(
        None,
        description=(
            "Effective DLQ database URL (masked). Matches main app DB when "
            "PYSTATOR_WORKER_DLQ_DATABASE_URL is unset."
        ),
    )
    dlq_table_name: str = Field(..., description="DLQ table name")
    persistence: str = Field(
        ...,
        description="disabled or database (database includes fallback to main DB URL)",
    )
