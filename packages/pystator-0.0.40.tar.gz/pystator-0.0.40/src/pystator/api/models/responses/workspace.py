"""Response models — workspace."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field


class WorkspaceAnnotationItem(BaseModel):
    state_name: str = Field(..., description="Anchored state name")
    body_markdown: str = Field("", description="Annotation body (markdown)")
    updated_at: datetime | None = Field(None, description="Last update timestamp")


class WorkspaceAnnotationsListResponse(BaseModel):
    machine_name: str = Field(..., description="Machine name")
    machine_version: str = Field(..., description="Machine version")
    items: list[WorkspaceAnnotationItem] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Workspace layouts
# ---------------------------------------------------------------------------


class WorkspaceLayoutPosition(BaseModel):
    """Single state position in the workspace diagram."""

    x: float = Field(..., description="X coordinate")
    y: float = Field(..., description="Y coordinate")


class WorkspaceLayoutsListResponse(BaseModel):
    """All positions for a given machine version."""

    machine_name: str = Field(..., description="Machine name")
    machine_version: str = Field(..., description="Machine version")
    positions: dict[str, WorkspaceLayoutPosition] = Field(
        default_factory=dict,
        description="Map of state_name to {x, y}",
    )
