"""Response models — analytics."""

from __future__ import annotations

from pydantic import BaseModel, Field


class StateDistributionItem(BaseModel):
    """Single state distribution entry."""

    state: str = Field(..., description="State name")
    count: int = Field(..., description="Entity count in this state")
    percentage: float = Field(..., description="Percentage of total entities")


class StatusDistribution(BaseModel):
    """Entity status breakdown."""

    active: int = Field(0, description="Active entities")
    archived: int = Field(0, description="Archived entities")
    deleted: int = Field(0, description="Deleted entities")


class MachineDistributionItem(BaseModel):
    """Single machine distribution entry."""

    machine_name: str = Field(..., description="Machine name")
    count: int = Field(..., description="Entity count for this machine")


class FailingEntityItem(BaseModel):
    """Top failing entity entry."""

    entity_id: str = Field(..., description="Entity identifier")
    failure_count: int = Field(..., description="Failed transitions in window")
    last_failure_at: str = Field(..., description="Timestamp of last failure")


class EntityHealthResponse(BaseModel):
    """Entity-centric health analytics."""

    state_distribution: list[StateDistributionItem] = Field(default_factory=list)
    status_distribution: StatusDistribution = Field(default_factory=StatusDistribution)
    machine_distribution: list[MachineDistributionItem] = Field(default_factory=list)
    top_failing_entities: list[FailingEntityItem] = Field(default_factory=list)
    terminal_rate: float = Field(0.0, description="Percentage of terminal entities")
    total_entities: int = Field(0, description="Total entity count")


class TimeBucketItem(BaseModel):
    """Single time bucket for transition analytics."""

    bucket_start: str = Field(..., description="Bucket start ISO timestamp")
    bucket_end: str = Field(..., description="Bucket end ISO timestamp")
    total: int = Field(0, description="Total transitions in bucket")
    failed: int = Field(0, description="Failed transitions in bucket")
    failure_rate: float = Field(0.0, description="Failure rate in bucket")


class DurationPercentiles(BaseModel):
    """Transition duration percentiles."""

    p50: int | None = Field(None, description="50th percentile in ms")
    p75: int | None = Field(None, description="75th percentile in ms")
    p95: int | None = Field(None, description="95th percentile in ms")
    p99: int | None = Field(None, description="99th percentile in ms")


class FailingTriggerItem(BaseModel):
    """Top failing trigger entry."""

    trigger: str = Field(..., description="Trigger name")
    total: int = Field(0, description="Total transitions with this trigger")
    failed: int = Field(0, description="Failed transitions with this trigger")
    failure_rate: float = Field(0.0, description="Failure rate for this trigger")


class FailingStateItem(BaseModel):
    """Top failing source state entry."""

    state: str = Field(..., description="Source state name")
    total: int = Field(0, description="Total transitions from this state")
    failed: int = Field(0, description="Failed transitions from this state")
    failure_rate: float = Field(0.0, description="Failure rate from this state")


class VolumeTrendItem(BaseModel):
    """Single volume trend bucket."""

    bucket_start: str = Field(..., description="Bucket start ISO timestamp")
    count: int = Field(0, description="Transition count in bucket")


class TransitionAnalyticsResponse(BaseModel):
    """Transition analytics for observability dashboard."""

    time_buckets: list[TimeBucketItem] = Field(default_factory=list)
    duration_percentiles: DurationPercentiles = Field(
        default_factory=DurationPercentiles
    )
    top_failing_triggers: list[FailingTriggerItem] = Field(default_factory=list)
    top_failing_states: list[FailingStateItem] = Field(default_factory=list)
    volume_trend: list[VolumeTrendItem] = Field(default_factory=list)


class TimelineStep(BaseModel):
    """Single step in an entity journey timeline."""

    state: str = Field(..., description="State entered")
    entered_at: str = Field(..., description="When entity entered this state")
    exited_at: str | None = Field(
        None, description="When entity left (null if current)"
    )
    dwell_ms: int | None = Field(None, description="Milliseconds in this state")
    trigger_in: str | None = Field(None, description="Trigger that caused entry")
    trigger_out: str | None = Field(None, description="Trigger that caused exit")
    success: bool = Field(True, description="Whether entry transition succeeded")


class EntityTimelineResponse(BaseModel):
    """Entity journey timeline."""

    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str | None = Field(None, description="Machine name")
    current_state: str = Field(..., description="Current entity state")
    steps: list[TimelineStep] = Field(default_factory=list)
    total_dwell_ms: int = Field(0, description="Total dwell time across all states")
    states_visited: int = Field(0, description="Count of unique states visited")
