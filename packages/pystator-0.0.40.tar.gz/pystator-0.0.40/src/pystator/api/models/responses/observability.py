"""Response models — observability."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class ObservabilitySummaryResponse(BaseModel):
    """High-level operational summary for observability dashboard."""

    window_start: datetime = Field(..., description="Start of summary time window")
    window_end: datetime = Field(..., description="End of summary time window")
    active_entities: int = Field(
        ..., description="Count of active entity state records"
    )
    transitions_total: int = Field(
        ..., description="Total transition attempts in window"
    )
    transitions_failed: int = Field(
        ..., description="Failed transition attempts in window"
    )
    transition_failure_rate: float = Field(
        ..., description="Failed transitions / total transitions in window"
    )
    p95_transition_duration_ms: int | None = Field(
        None, description="P95 transition processing duration in milliseconds"
    )
    worker_pending: int = Field(..., description="Current pending worker events")
    worker_claimed: int = Field(..., description="Current claimed worker events")
    worker_failed: int = Field(..., description="Current failed worker events")
    worker_dead_letter: int = Field(
        ..., description="Current dead-letter worker events"
    )


class ObservabilityTransitionItem(BaseModel):
    """Single transition row for observability transition feed."""

    id: str = Field(..., description="Transition history record ID")
    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str | None = Field(None, description="Machine name")
    source_state: str = Field(..., description="State before transition")
    target_state: str | None = Field(None, description="State after transition")
    trigger: str = Field(..., description="Event trigger name")
    success: bool = Field(..., description="Whether transition succeeded")
    error_message: str | None = Field(None, description="Error message if failed")
    actions_executed: list[str] | None = Field(None, description="Executed actions")
    duration_ms: int | None = Field(None, description="Processing duration in ms")
    created_at: datetime = Field(..., description="Transition timestamp")


class ObservabilityTransitionsResponse(BaseModel):
    """Paginated transition feed for observability."""

    items: list[ObservabilityTransitionItem] = Field(default_factory=list)
    total: int = Field(..., description="Total count matching filters")
    limit: int = Field(..., description="Page size")
    offset: int = Field(..., description="Page offset")


class ObservabilityWorkerEventItem(BaseModel):
    """Single worker-event row for observability queue feed."""

    id: str = Field(..., description="Worker event ID")
    machine_name: str = Field(..., description="Machine name")
    entity_id: str = Field(..., description="Entity identifier")
    trigger: str = Field(..., description="Event trigger")
    status: str = Field(..., description="Worker event status")
    attempt: int = Field(..., description="Current attempt number")
    max_attempts: int = Field(..., description="Maximum attempts allowed")
    error_message: str | None = Field(None, description="Failure message")
    fires_at: datetime = Field(..., description="Scheduled fire time")
    claimed_by: str | None = Field(None, description="Worker identifier")
    claimed_at: datetime | None = Field(None, description="Claim timestamp")
    created_at: datetime | None = Field(None, description="Created timestamp")
    completed_at: datetime | None = Field(None, description="Completed timestamp")
    result_json: dict[str, Any] | None = Field(
        None, description="Optional processing result payload"
    )
    transition_history_id: str | None = Field(
        None, description="Correlated transition_history record ID when available"
    )


class ObservabilityWorkerEventsResponse(BaseModel):
    """Paginated worker-event feed for observability."""

    items: list[ObservabilityWorkerEventItem] = Field(default_factory=list)
    total: int = Field(..., description="Total count matching filters")
    limit: int = Field(..., description="Page size")
    offset: int = Field(..., description="Page offset")


class StateOpsErrorTopItem(BaseModel):
    """Top failure reason for a state within a window."""

    error_type: str | None = Field(None, description="Error type (if available)")
    error_message: str | None = Field(None, description="Error message (if available)")
    count: int = Field(..., description="Occurrences for this error signature")


class StateOpsAgeBuckets(BaseModel):
    """Age bucket counts for entities in a state (seconds since last transition)."""

    le_5m: int = Field(0, description="Entities with age <= 5 minutes")
    le_30m: int = Field(0, description="Entities with age <= 30 minutes (and > 5m)")
    gt_30m: int = Field(0, description="Entities with age > 30 minutes")


class StateOpsMetricsItem(BaseModel):
    """Operational metrics for a single state in a machine."""

    state_name: str = Field(..., description="State name")
    entity_count: int = Field(..., description="Current entity count in this state")
    age_p95_seconds: int | None = Field(
        None, description="P95 age in seconds since last transition"
    )
    age_oldest_seconds: int | None = Field(
        None, description="Oldest entity age in seconds since last transition"
    )
    age_buckets: StateOpsAgeBuckets = Field(
        default_factory=StateOpsAgeBuckets,
        description="Bucketized entity ages for quick stuckness triage",
    )
    failed_transition_count: int = Field(
        0,
        description=(
            "Failed transitions in the window where source_state OR target_state matches this state"
        ),
    )
    successful_target_entries_count: int = Field(
        0,
        description=(
            "Successful transition_history rows in the window whose target_state is this state"
        ),
    )
    top_error: StateOpsErrorTopItem | None = Field(
        None, description="Most common failure signature for this state (windowed)"
    )


class ObservabilityStateMetricsResponse(BaseModel):
    """Per-state operational metrics for a machine over a trailing window."""

    machine_name: str = Field(..., description="Machine name")
    window_start: datetime = Field(..., description="Start of metrics window (UTC)")
    window_end: datetime = Field(..., description="End of metrics window (UTC)")
    items: list[StateOpsMetricsItem] = Field(
        default_factory=list, description="Metrics by state"
    )


class TransitionOpsMetricsItem(BaseModel):
    """Aggregated transition_history metrics for one (source, target, trigger) in a window."""

    source_state: str = Field(..., description="Source state name")
    target_state: str = Field(
        ...,
        description="Target state name (empty string when history target was null)",
    )
    trigger: str = Field(..., description="Trigger name")
    attempts_total: int = Field(
        ..., description="Total transition_history rows in window"
    )
    attempts_failed: int = Field(..., description="Rows with success=false")
    duration_p95_ms: int | None = Field(
        None,
        description="P95 of duration_ms over rows with non-null duration in this group",
    )
    top_error: StateOpsErrorTopItem | None = Field(
        None,
        description="Most common failure signature in this group (windowed)",
    )


class ObservabilityTransitionMetricsResponse(BaseModel):
    """Per-edge transition metrics for a machine over a trailing window."""

    machine_name: str = Field(..., description="Machine name")
    window_start: datetime = Field(..., description="Start of metrics window (UTC)")
    window_end: datetime = Field(..., description="End of metrics window (UTC)")
    items: list[TransitionOpsMetricsItem] = Field(
        default_factory=list,
        description="Metrics grouped by source_state, target_state, trigger",
    )
