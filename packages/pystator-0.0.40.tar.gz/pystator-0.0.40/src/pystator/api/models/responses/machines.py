"""Response models — machines."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from .fsm import ActionRef, FsmOutcomeError


class MachineResponse(BaseModel):
    """Response for a single stored FSM machine."""

    id: str = Field(..., description="Machine UUID")
    name: str = Field(..., description="Machine name from meta")
    version: str = Field(..., description="Machine version")
    description: str | None = Field(None, description="Machine description")
    strict_mode: bool = Field(True, description="Strict mode from meta")
    config: dict[str, Any] = Field(
        ...,
        description=("Full FSM config (meta, states, transitions, error_policy)"),
    )
    revision: int = Field(1, description="Optimistic concurrency revision")
    created_at: datetime | None = Field(None, description="Created timestamp")
    updated_at: datetime | None = Field(None, description="Updated timestamp")


class MachineListItem(BaseModel):
    """Summary item for machine list."""

    id: str = Field(..., description="Machine UUID")
    name: str = Field(..., description="Machine name")
    version: str = Field(..., description="Machine version")
    namespace: str | None = Field(
        None, description="Optional namespace path from meta (slash-separated)"
    )
    description: str | None = Field(None, description="Machine description")
    created_at: datetime | None = Field(None, description="Created timestamp")
    updated_at: datetime | None = Field(None, description="Updated timestamp")


class MachineListResponse(BaseModel):
    """Response for list machines."""

    machines: list[MachineListItem] = Field(default_factory=list)
    count: int = Field(0, description="Total count")


class ProcessResponse(BaseModel):
    """Response for process endpoint."""

    success: bool = Field(..., description="Whether the transition succeeded")
    source_state: str = Field(..., description="State before transition")
    target_state: str | None = Field(
        None, description="State after transition (if success)"
    )
    trigger: str = Field(..., description="Event trigger")
    actions_to_execute: list[ActionRef] = Field(
        default_factory=list,
        description="Transition actions to run after persistence",
    )
    on_exit_actions: list[ActionRef] = Field(
        default_factory=list,
        description="Source state exit actions",
    )
    on_enter_actions: list[ActionRef] = Field(
        default_factory=list,
        description="Target state entry actions",
    )
    error: FsmOutcomeError | None = Field(
        None,
        description="Structured error when success is False",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata"
    )
