"""Response models — discovery."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from pystator.api.models.discovery_filter import DiscoveryDraftFilterModel


class DiscoveryObserveResponse(BaseModel):
    """Response for a recorded discovery observation."""

    accepted: bool = Field(..., description="Whether the observation was recorded")


class InferredEdgeResponse(BaseModel):
    """Inferred transition edge."""

    source_state: str = Field(..., description="Source state")
    destination_state: str = Field(..., description="Destination state")
    count: int = Field(..., description="Observed transition count")
    unique_entities: int = Field(..., description="Distinct entities seen on this edge")
    unique_sources: int = Field(..., description="Distinct observation sources")
    confidence: float = Field(..., description="Confidence in inferred edge")


class DiscoveryBuiltCandidateResponse(BaseModel):
    """Response for a built (persisted) inferred machine candidate."""

    machine_name: str = Field(..., description="Machine name")
    version: str = Field(..., description="Candidate version")
    candidate_sequence: int = Field(
        ...,
        ge=0,
        description=(
            "Per-machine monotonic display index (1, 2, 3, …); version remains canonical"
        ),
    )
    status: str = Field(..., description="Candidate status")
    config: dict[str, Any] = Field(..., description="Inferred machine config")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Metadata")
    edges: list[InferredEdgeResponse] = Field(
        default_factory=list, description="Inferred edge diagnostics"
    )


class DiscoveryPreviewResponse(BaseModel):
    """Response for discovery preview inference."""

    machine_name: str = Field(..., description="Machine name")
    mode: str = Field(..., description="Preview mode")
    entity_ids_used: list[str] = Field(
        default_factory=list, description="Entity IDs included in preview scope"
    )
    observation_count: int = Field(
        ..., description="Observation count in preview scope"
    )
    edges: list[InferredEdgeResponse] = Field(
        default_factory=list,
        description="Inferred edge diagnostics for preview scope",
    )
    selected_edges: list[InferredEdgeResponse] = Field(
        default_factory=list,
        description="Edges selected by threshold defaults for preview scope",
    )


class DiscoveryEntityListResponse(BaseModel):
    """Distinct entity IDs observed for a machine."""

    machine_name: str = Field(..., description="Machine name")
    entity_ids: list[str] = Field(
        default_factory=list, description="Distinct observed entity identifiers"
    )


class DiscoveryObservationItem(BaseModel):
    """One stored observation row for browsing before inference."""

    entity_id: str = Field(..., description="Entity identifier")
    state: str = Field(..., description="Observed state name")
    observed_at: datetime = Field(..., description="When the state was observed")
    source: str = Field(..., description="Origin label")
    source_event_id: str | None = Field(None, description="Optional upstream event id")
    ingest_seq: int = Field(0, description="Ingest sequence within a session")
    ingested_at: datetime = Field(..., description="When the row was stored")


class DiscoveryObservationListResponse(BaseModel):
    """Paginated observations for a discovery machine (newest first)."""

    machine_name: str = Field(..., description="Machine / channel name")
    draft_id: str | None = Field(
        None,
        description="When returned from draft-scoped explore, the draft this page belongs to",
    )
    items: list[DiscoveryObservationItem] = Field(
        default_factory=list, description="Observation rows for this page"
    )
    total: int = Field(..., ge=0, description="Total rows matching filters")
    limit: int = Field(..., ge=1, description="Page size")
    offset: int = Field(..., ge=0, description="Skip count")


class DiscoveryEntityDeleteResponse(BaseModel):
    """Delete all discovery observations for one entity in a machine."""

    machine_name: str = Field(..., description="Machine name")
    entity_id: str = Field(..., description="Entity id removed")
    deleted_count: int = Field(..., ge=0, description="Number of observations deleted")


class DiscoveryObservationDeleteOneResponse(BaseModel):
    """Result of deleting a single observation row."""

    deleted: bool = Field(
        ...,
        description="True when a matching row was removed from the store",
    )


class DiscoveryObservationInsertRelativeResponse(BaseModel):
    """Result of inserting a row relative to an existing observation."""

    accepted: bool = Field(
        ...,
        description="True when the new row was stored (false if deduplicated)",
    )


class DiscoveryDraftResponse(BaseModel):
    """Discovery draft: entity scope and settings before build."""

    id: str = Field(..., description="Draft id")
    instance_id: str = Field(
        ...,
        description="Discovery connection instance this draft belongs to",
    )
    title: str | None = Field(None, description="Unique slug / label for this draft")
    selected_entity_ids: list[str] = Field(
        default_factory=list,
        description="Entity IDs whose observations are used for preview/build",
    )
    mode: str = Field("inference", description="inference or manual")
    min_edge_count: int = Field(2, ge=1)
    min_confidence: float = Field(0.5, ge=0.0, le=1.0)
    manual_edge_selection: list[dict[str, str]] = Field(
        default_factory=list,
        description="For manual mode: source_state/destination_state pairs",
    )
    created_at: datetime = Field(..., description="Created time")
    updated_at: datetime = Field(..., description="Last update time")
    last_built_version: str | None = Field(
        None, description="Version string of last build from this draft, if any"
    )
    filter: DiscoveryDraftFilterModel | None = Field(
        None,
        description=(
            "Cross-channel filter selecting which observations this draft reads. "
            "``None`` means all channels (subject to other dimensions)."
        ),
    )
    observation_source: dict[str, Any] | None = Field(
        None,
        description="Optional table/collection and field mapping for observations.",
    )


class DiscoveryInstanceSummary(BaseModel):
    """Lightweight summary row for discovery drafts under a connection instance."""

    id: str = Field(..., description="Draft id")
    instance_id: str = Field(
        ...,
        description="Parent discovery connection instance id",
    )
    catalog_slug: str = Field(
        ...,
        description=(
            "Default catalog name for published candidates from this draft "
            "(same as the draft title slug)."
        ),
    )
    title: str | None = Field(None, description="Optional label")
    filter: DiscoveryDraftFilterModel | None = Field(
        None, description="Cross-channel filter, or null for all-channel inference."
    )
    filter_summary: str = Field(
        ..., description="Human-readable one-line summary of the filter."
    )
    min_edge_count: int = Field(
        2,
        ge=1,
        description="Minimum edge count threshold used for inference on this draft.",
    )
    min_confidence: float = Field(
        0.5,
        ge=0.0,
        le=1.0,
        description="Minimum confidence threshold used for inference on this draft.",
    )
    observation_source: dict[str, Any] | None = Field(
        None,
        description="Optional observation table/collection mapping, if any.",
    )
    built_count: int = Field(
        ..., ge=0, description="Number of built candidates produced from this instance."
    )
    last_built_version: str | None = Field(
        None, description="Version of the most recent build, if any."
    )
    created_at: datetime = Field(..., description="Created time")
    updated_at: datetime = Field(..., description="Last update time")


class DiscoveryInstancesListResponse(BaseModel):
    """Paginated list of discovery drafts for a connection instance."""

    items: list[DiscoveryInstanceSummary] = Field(default_factory=list)
    total: int = Field(..., ge=0)
    limit: int = Field(..., ge=1)
    offset: int = Field(..., ge=0)


class DiscoveryConnectionInstanceSummary(BaseModel):
    """One registered discovery backend connection (left-nav instance)."""

    id: str = Field(..., description="Connection instance id")
    title: str | None = Field(None, description="Optional label")
    namespace: str | None = Field(
        None,
        description="Optional UI folder path (slash-separated slug segments).",
    )
    backend: str = Field(..., description="Discovery store backend name")
    connection_string_masked: str = Field(
        ...,
        description="Masked connection string for display",
    )
    created_at: datetime | None = Field(None, description="Created time")
    updated_at: datetime | None = Field(None, description="Last update time")


class DiscoveryConnectionInstancesListResponse(BaseModel):
    """Paginated list of discovery connection instances."""

    items: list[DiscoveryConnectionInstanceSummary] = Field(default_factory=list)
    total: int = Field(..., ge=0)
    limit: int = Field(..., ge=1)
    offset: int = Field(..., ge=0)


class DiscoveryBuiltCandidateSummaryItem(BaseModel):
    """One summary row for a built (persisted) candidate version."""

    machine_name: str = Field(..., description="Machine name")
    version: str = Field(..., description="Candidate version")
    candidate_sequence: int = Field(
        ...,
        ge=0,
        description="Per-machine monotonic display index (1, 2, 3, …)",
    )
    status: str = Field(..., description="Candidate status")
    created_at: datetime = Field(..., description="When the candidate was saved")
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Inference metadata (counts, thresholds, …)"
    )
    observation_count_at_build: int = Field(
        0,
        description=(
            "Observation count snapshot used when this candidate was built "
            "(from candidate metadata)"
        ),
    )
    shadow_diff_count_recent: int = Field(
        0,
        description=(
            "Count of recent shadow diff rows for this candidate version "
            "(candidate-version scoped)"
        ),
    )
    drift_rate_recent: float = Field(
        0.0,
        description=(
            "Fraction of recent shadow rows for this version where differs=true "
            "(0.0 when shadow_diff_count_recent is 0)"
        ),
    )
    build_mode: str | None = Field(
        None, description="Build mode from candidate metadata (e.g., inference/manual)"
    )


class DiscoveryMachineDraftsResponse(BaseModel):
    """Drafts and built candidates for one discovery machine."""

    machine_name: str = Field(..., description="Machine name")
    drafts: list[DiscoveryDraftResponse] = Field(
        default_factory=list,
        description="Drafts (newest updated_at first)",
    )
    built_candidates: list[DiscoveryBuiltCandidateSummaryItem] = Field(
        default_factory=list, description="Built candidates newest-first"
    )


class DiscoveryFleetMachineItem(BaseModel):
    """One machine row in the discovery fleet index."""

    machine_name: str = Field(..., description="Machine name")
    last_observation_at: datetime | None = Field(
        None, description="Latest observation timestamp for this machine, if any"
    )
    observation_count: int = Field(
        0, description="Total rows in discovery_observations for this machine"
    )
    candidate_count: int = Field(
        0, description="Number of stored candidate versions for this machine"
    )
    latest_candidate_version: str | None = Field(
        None, description="Version string of the newest candidate by created_at"
    )
    latest_candidate_created_at: datetime | None = Field(
        None, description="created_at of the newest candidate"
    )
    shadow_diff_count_recent: int = Field(
        ...,
        description=(
            "Count of shadow diffs in the recent window: the latest 200 rows "
            "per machine by recorded_at (newest first)"
        ),
    )
    drift_rate_recent: float = Field(
        ...,
        description=(
            "Fraction of rows in that same window where differs=true "
            "(0.0 when shadow_diff_count_recent is 0)"
        ),
    )


class DiscoveryFleetListResponse(BaseModel):
    """Paginated discovery fleet index."""

    items: list[DiscoveryFleetMachineItem] = Field(default_factory=list)
    total: int = Field(..., description="Total rows matching query before pagination")
    limit: int = Field(..., description="Requested page size")
    offset: int = Field(..., description="Requested offset")


class DiscoveryShadowDiffResponse(BaseModel):
    """Response item for shadow comparison diagnostics."""

    machine_name: str = Field(..., description="Machine name")
    source_state: str = Field(..., description="Source state")
    trigger: str = Field(..., description="Trigger used")
    active_success: bool = Field(..., description="Active machine success result")
    active_target_state: str | None = Field(None, description="Active target state")
    candidate_success: bool = Field(..., description="Candidate machine success result")
    candidate_target_state: str | None = Field(
        None, description="Candidate target state"
    )
    differs: bool = Field(..., description="Whether active vs candidate differ")
    reason: str | None = Field(None, description="Difference reason")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Extra metadata")

    model_config = {
        "json_schema_extra": {
            "example": {
                "success": True,
                "source_state": "OPEN",
                "target_state": "FILLED",
                "trigger": "fill",
                "actions_to_execute": [{"name": "update_positions"}],
                "on_exit_actions": [],
                "on_enter_actions": [],
                "error": None,
                "metadata": {},
            }
        }
    }
