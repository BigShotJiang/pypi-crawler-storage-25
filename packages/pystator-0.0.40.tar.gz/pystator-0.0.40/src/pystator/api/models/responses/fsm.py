"""Response models — fsm."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ActionRef(BaseModel):
    """Action reference with optional params."""

    name: str = Field(..., description="Action name")
    params: dict[str, Any] = Field(
        default_factory=dict, description="Optional parameters"
    )


class FsmOutcomeError(BaseModel):
    """Structured error when a transition does not succeed (HTTP / JSON)."""

    code: str = Field(
        ...,
        description="Machine-readable code (see ErrorCode in pystator.errors)",
    )
    type: str = Field(..., description="Exception class name")
    message: str = Field(..., description="Human-readable message")
    details: dict[str, Any] | None = Field(
        None,
        description="Engine metadata (e.g. guards) and optional error_context",
    )
