"""Response models — entities."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from .fsm import FsmOutcomeError


class EntityStateResponse(BaseModel):
    """Response for entity state queries."""

    entity_id: str = Field(..., description="Entity identifier")
    current_state: str = Field(..., description="Current state name")
    machine_name: str | None = Field(None, description="Machine name")
    machine_version: str | None = Field(None, description="Machine version")
    context: dict[str, Any] = Field(default_factory=dict, description="Entity context")
    status: str = Field("active", description="Entity lifecycle status")
    workflow_status: str = Field(
        "active",
        description="FSM workflow outcome: active, complete, or failed",
    )
    is_terminal: bool | None = Field(
        None,
        description="Whether current_state is a terminal FSM state",
    )
    labels: dict[str, str] = Field(default_factory=dict, description="Entity labels")
    updated_at: datetime | None = Field(None, description="Last updated")
    created_at: datetime | None = Field(None, description="Created timestamp")
    archived_at: datetime | None = Field(None, description="Archived timestamp")
    deleted_at: datetime | None = Field(None, description="Deleted timestamp")


class CreateEntityResponse(BaseModel):
    """Response after creating an entity at initial state."""

    entity_id: str = Field(..., description="Entity identifier")
    current_state: str = Field(..., description="Initial state name")
    machine_name: str | None = Field(None, description="Machine name")
    context: dict[str, Any] = Field(default_factory=dict, description="Entity context")
    updated_at: datetime | None = Field(None, description="Last updated")
    created_at: datetime | None = Field(None, description="Created timestamp")
    transition_id: str = Field(
        ...,
        description="Transition history record ID (bootstrap row; trigger __entity_created__)",
    )


class ProcessEntityEventResponse(BaseModel):
    """Response for processing an entity event."""

    success: bool = Field(..., description="Whether transition succeeded")
    entity_id: str = Field(..., description="Entity identifier")
    source_state: str = Field(..., description="State before transition")
    target_state: str | None = Field(None, description="State after transition")
    trigger: str = Field(..., description="Event trigger name")
    actions: list[str] = Field(
        default_factory=list,
        description="Transition action names (planned for this edge)",
    )
    action_results: list[dict[str, Any]] | None = Field(
        None,
        description=(
            "Per-action execution outcomes (name, success, status, error) when "
            "actions ran inline"
        ),
    )
    error_detail: FsmOutcomeError | None = Field(
        None,
        description="Structured error when success is False",
    )
    error: str | None = Field(
        None,
        description="Deprecated: human-readable message; use error_detail.message",
    )
    shadow_diff: dict[str, Any] | None = Field(
        None, description="Optional shadow comparison output"
    )
    transition_id: str | None = Field(None, description="Transition history record ID")


class TransitionHistoryResponse(BaseModel):
    """Response for transition history queries."""

    id: str = Field(..., description="History record ID")
    entity_id: str = Field(..., description="Entity identifier")
    source_state: str = Field(..., description="State before transition")
    target_state: str | None = Field(None, description="State after transition")
    trigger: str = Field(..., description="Event trigger name")
    success: bool = Field(..., description="Whether transition succeeded")
    error_message: str | None = Field(None, description="Error message if failed")
    actions_executed: list[str] | None = Field(None, description="Executed actions")
    created_at: datetime = Field(..., description="Transition timestamp")
    duration_ms: int | None = Field(None, description="Processing duration in ms")


class EntityListResponse(BaseModel):
    """Response for listing entities."""

    entities: list[EntityStateResponse] = Field(
        default_factory=list, description="Entity records"
    )
    total: int = Field(..., description="Total count matching filters")
    limit: int = Field(..., description="Page size")
    offset: int = Field(..., description="Page offset")
    next_cursor: str | None = Field(None, description="Cursor for next page")


class EntityLabelsResponse(BaseModel):
    """Response for entity label queries."""

    entity_id: str = Field(..., description="Entity identifier")
    labels: dict[str, str] = Field(default_factory=dict, description="Entity labels")


class TriggerInfo(BaseModel):
    """Information about an available trigger from a state."""

    trigger: str = Field(..., description="Trigger name")
    target_state: str = Field(..., description="Target state name")
    has_guard: bool = Field(False, description="Whether transition has guards")
    guard_description: str | None = Field(
        None, description="Guard description if available"
    )


class AvailableTriggersResponse(BaseModel):
    """Response for available triggers query."""

    entity_id: str = Field(..., description="Entity identifier")
    current_state: str = Field(..., description="Current state name")
    triggers: list[TriggerInfo] = Field(
        default_factory=list, description="Available triggers"
    )


class DryRunResponse(BaseModel):
    """Response for dry-run transition evaluation."""

    would_succeed: bool = Field(..., description="Whether the transition would succeed")
    entity_id: str = Field(..., description="Entity identifier")
    source_state: str = Field(..., description="Current state")
    target_state: str | None = Field(
        None, description="Target state if transition would succeed"
    )
    trigger: str = Field(..., description="Trigger evaluated")
    actions_that_would_execute: list[str] = Field(
        default_factory=list, description="Actions that would run"
    )
    error_detail: str | None = Field(
        None, description="Error message if transition would fail"
    )


class ApplyDataEnqueueResponse(BaseModel):
    """Response after enqueueing an apply-data update for worker processing."""

    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str = Field(..., description="Machine name routed to")
    event_id: str = Field(..., description="Worker apply-data event ID")


class BulkCreateEntityResult(BaseModel):
    """Result for one entity in a bulk create."""

    entity_id: str = Field(..., description="Entity identifier")
    success: bool = Field(..., description="Whether creation succeeded")
    current_state: str | None = Field(None, description="Initial state if success")
    error: str | None = Field(None, description="Error message if failed")


class BulkCreateEntitiesResponse(BaseModel):
    """Response for bulk entity creation."""

    results: list[BulkCreateEntityResult] = Field(default_factory=list)
    total: int = Field(..., description="Total items processed")
    succeeded: int = Field(..., description="Items that succeeded")
    failed: int = Field(..., description="Items that failed")


class BulkProcessEventResult(BaseModel):
    """Result for one entity in bulk event processing."""

    entity_id: str = Field(..., description="Entity identifier")
    success: bool = Field(..., description="Whether transition succeeded")
    source_state: str | None = Field(None, description="State before transition")
    target_state: str | None = Field(None, description="State after transition")
    error: str | None = Field(None, description="Error message if failed")


class BulkProcessEventsResponse(BaseModel):
    """Response for bulk event processing."""

    trigger: str = Field(..., description="Trigger name processed")
    results: list[BulkProcessEventResult] = Field(default_factory=list)
    total: int = Field(..., description="Total items processed")
    succeeded: int = Field(..., description="Items that succeeded")
    failed: int = Field(..., description="Items that failed")


class HistoryStatsResponse(BaseModel):
    """Response for entity history statistics."""

    entity_id: str = Field(..., description="Entity identifier")
    total_transitions: int = Field(..., description="Total transition count")
    first_at: datetime | None = Field(None, description="Earliest transition timestamp")
    last_at: datetime | None = Field(None, description="Latest transition timestamp")
    success_count: int = Field(..., description="Successful transitions")
    failure_count: int = Field(..., description="Failed transitions")


class HistoryPurgeResponse(BaseModel):
    """Response for history purge operation."""

    entity_id: str = Field(..., description="Entity identifier")
    deleted_count: int = Field(..., description="Records deleted")
    remaining_count: int = Field(..., description="Records remaining")


class TransitionHistorySnapshotItem(BaseModel):
    """Single history record in a snapshot."""

    source_state: str = Field(..., description="State before")
    target_state: str | None = Field(None, description="State after")
    trigger: str = Field(..., description="Trigger")
    success: bool = Field(..., description="Whether succeeded")
    error_message: str | None = Field(None, description="Error if failed")
    actions_executed: list[str] | None = Field(None, description="Actions")
    created_at: datetime = Field(..., description="Timestamp")
    duration_ms: int | None = Field(None, description="Duration")


class EntitySnapshotResponse(BaseModel):
    """Full entity snapshot for export."""

    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str | None = Field(None, description="Machine name")
    current_state: str = Field(..., description="Current state")
    context: dict[str, Any] = Field(default_factory=dict, description="Context")
    status: str = Field("active", description="Lifecycle status")
    labels: dict[str, str] = Field(default_factory=dict, description="Labels")
    history: list[TransitionHistorySnapshotItem] = Field(
        default_factory=list, description="Full history"
    )
    exported_at: datetime = Field(..., description="Export timestamp")


class ImportEntityResponse(BaseModel):
    """Response after importing an entity from snapshot."""

    entity_id: str = Field(..., description="Entity identifier")
    history_count: int = Field(..., description="History records imported")
    success: bool = Field(True, description="Whether import succeeded")


class TransitionHistoryListResponse(BaseModel):
    """Response for paginated history list."""

    items: list[TransitionHistoryResponse] = Field(default_factory=list)
    total: int = Field(..., description="Total count")
    limit: int = Field(..., description="Page size")
    offset: int = Field(..., description="Page offset")
    next_cursor: str | None = Field(None, description="Cursor for next page")
