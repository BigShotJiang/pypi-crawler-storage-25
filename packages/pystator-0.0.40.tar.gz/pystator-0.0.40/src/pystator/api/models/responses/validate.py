"""Response models — validate."""

from __future__ import annotations

from pydantic import BaseModel, Field


class MachineInfo(BaseModel):
    """Machine metadata from validated config."""

    machine_name: str = Field(..., description="Machine name")
    version: str = Field(..., description="Machine version")
    state_names: list[str] = Field(..., description="State names")
    trigger_names: list[str] = Field(..., description="Trigger names")
    terminal_states: list[str] = Field(..., description="Terminal state names")


class ValidateResponse(BaseModel):
    """Response for validate endpoint."""

    valid: bool = Field(..., description="Whether the config is valid")
    errors: list[str] = Field(
        default_factory=list, description="Validation errors if invalid"
    )
    warnings: list[str] = Field(
        default_factory=list,
        description="Non-fatal issues when valid (e.g. unrecognized error_policy keys)",
    )
    info: MachineInfo | None = Field(
        None,
        description="Machine info if valid",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "valid": True,
                "errors": [],
                "warnings": [],
                "info": {
                    "machine_name": "order",
                    "version": "1.0",
                    "state_names": ["OPEN", "FILLED"],
                    "trigger_names": ["fill"],
                    "terminal_states": ["FILLED"],
                },
            }
        }
    }
