"""Request models — settings."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class DatabaseTestRequest(BaseModel):
    """Request body for testing database connection."""

    connection_string: str | None = Field(
        None, description="Full connection string (overrides individual fields)"
    )
    host: str | None = Field(None, description="Database host")
    port: int | None = Field(None, description="Database port")
    database: str | None = Field(None, description="Database name")
    username: str | None = Field(None, description="Database username")
    password: str | None = Field(None, description="Database password")


class DiscoveryDatabaseTestRequest(BaseModel):
    """Request body for testing discovery database connection."""

    backend: str = Field(..., description="Discovery backend type")
    connection_string: str | None = Field(
        None, description="Backend connection string if required"
    )


class DiscoveryConnectionInstanceCreateRequest(BaseModel):
    """Create a registered discovery connection instance (binds a database)."""

    title: str = Field(..., min_length=1, max_length=512, description="Display name")
    namespace: str | None = Field(
        None,
        max_length=512,
        description=(
            "Optional slash-separated path (slug segments) for grouping in the UI, "
            "e.g. ``team_a/prod``."
        ),
    )
    backend: str = Field(
        ..., min_length=1, max_length=32, description="sqlite, mongodb, …"
    )
    connection_string: str = Field(
        ...,
        min_length=1,
        description="Connection URL for the discovery store",
    )


class DiscoveryConnectionInstancePatchRequest(BaseModel):
    """PATCH discovery connection registry fields (omit keys you do not change)."""

    title: str | None = Field(default=None, max_length=512)
    namespace: str | None = Field(
        default=None,
        max_length=512,
        description="Set to null to clear; omit to leave unchanged.",
    )
    backend: str | None = Field(default=None, min_length=1, max_length=32)
    connection_string: str | None = Field(
        default=None,
        description="Full replacement URL; omit to leave unchanged",
    )


class ServerConfigPatchRequest(BaseModel):
    """PATCH body for ``/settings/server-config``: map env-style keys to new values."""

    values: dict[str, Any] = Field(
        ...,
        description="Keys such as PYSTATOR_UI_THEME → value written to pystator.cfg",
    )


class DlqTestRequest(BaseModel):
    """Request body for testing DLQ database connection."""

    connection_string: str | None = Field(
        None, description="Full connection string (overrides individual fields)"
    )
    host: str | None = Field(None, description="Database host")
    port: int | None = Field(None, description="Database port")
    database: str | None = Field(None, description="Database name")
    username: str | None = Field(None, description="Database username")
    password: str | None = Field(None, description="Database password")
    table_name: str | None = Field(None, description="DLQ table name")


class DlqStatsRequest(BaseModel):
    """Request body for DLQ statistics."""

    connection_string: str | None = Field(
        None, description="Full connection string (overrides individual fields)"
    )
    host: str | None = Field(None, description="Database host")
    port: int | None = Field(None, description="Database port")
    database: str | None = Field(None, description="Database name")
    username: str | None = Field(None, description="Database username")
    password: str | None = Field(None, description="Database password")
    table_name: str | None = Field(None, description="DLQ table name")
