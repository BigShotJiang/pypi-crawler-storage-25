"""Request models — discovery."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

from pystator.api.models.discovery_filter import DiscoveryDraftFilterModel
from pystator.discovery.models import ObservationIdentity


class DiscoveryObserveRequest(BaseModel):
    """Request body for recording a discovered state observation."""

    machine_name: str = Field(..., description="Machine name")
    entity_id: str = Field(..., description="Observed entity identifier")
    state: str = Field(..., description="Observed state")
    observed_at: str | None = Field(
        None, description="ISO timestamp for observation time (defaults to now)"
    )
    source: str = Field("api", description="Observation source")
    source_event_id: str | None = Field(
        None, description="Optional source event id for idempotency"
    )
    ingest_seq: int = Field(0, description="Optional ingest sequence")
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Optional additional metadata"
    )


class DiscoveryBuildCandidateRequest(BaseModel):
    """Request body for building an inferred candidate machine."""

    machine_name: str = Field(
        ...,
        description="Catalog name for the built candidate artifact",
    )
    filter: DiscoveryDraftFilterModel | None = Field(
        None,
        description=(
            "Observation scope; omit for all channels. Entity ids may also be "
            "passed via ``entity_ids`` and are merged into the filter."
        ),
    )
    version: str | None = Field(
        None, description="Optional candidate version (auto-generated when omitted)"
    )
    mode: Literal["inference", "manual"] = Field(
        "inference",
        description="Build mode: threshold inference or manual edge selection",
    )
    entity_ids: list[str] = Field(
        default_factory=list,
        description=(
            "Optional entity-id subset merged into the observation filter when "
            "the filter omits entity ids."
        ),
    )
    edge_selection: list[dict[str, str]] = Field(
        default_factory=list,
        description=(
            "Manual mode edge selection as source/destination pairs. Selected pairs "
            "bypass threshold filtering."
        ),
    )
    min_edge_count: int | None = Field(
        None, description="Optional per-build override for min edge count"
    )
    min_confidence: float | None = Field(
        None, description="Optional per-build override for min confidence"
    )


class DiscoveryPreviewRequest(BaseModel):
    """Request body for previewing inferred edges without saving a candidate."""

    machine_name: str | None = Field(
        None,
        description="Optional: restrict to this observation channel tag",
    )
    filter: DiscoveryDraftFilterModel | None = Field(
        None,
        description="Structured observation scope; when set, overrides machine_name",
    )
    mode: Literal["inference", "manual"] = Field(
        "inference",
        description="Preview mode",
    )
    entity_ids: list[str] = Field(
        default_factory=list,
        description="Optional entity-id subset merged into the filter",
    )
    min_edge_count: int | None = Field(
        None, description="Optional per-preview override for min edge count"
    )
    min_confidence: float | None = Field(
        None, description="Optional per-preview override for min confidence"
    )


class DiscoveryDraftCreateRequest(BaseModel):
    """Create an empty discovery draft (draft candidate scope)."""

    title: str = Field(
        ...,
        min_length=1,
        max_length=512,
        description="Display title; unique per connection instance",
    )
    observation_source: dict[str, Any] | None = Field(
        None,
        description=(
            "Optional observation table/collection and field mapping "
            "(see ObservationSourceConfig)."
        ),
    )
    filter: DiscoveryDraftFilterModel | None = Field(
        None,
        description=(
            "Optional filter selecting which observations this draft reads "
            "from the shared event stream. When omitted, inference uses all "
            "channels by default."
        ),
    )
    min_edge_count: int | None = Field(
        None,
        ge=1,
        description=(
            "Optional minimum edge count threshold for inference. Defaults "
            "to the engine threshold (typically ``2``)."
        ),
    )
    min_confidence: float | None = Field(
        None,
        ge=0.0,
        le=1.0,
        description=(
            "Optional minimum confidence threshold for inference. Defaults "
            "to the engine threshold (typically ``0.5``)."
        ),
    )


class DiscoveryDraftPatchRequest(BaseModel):
    """Patch draft fields; omitted keys are left unchanged."""

    title: str | None = Field(None, description="Display title")
    selected_entity_ids: list[str] | None = Field(
        None, description="Replace entity-id selection (empty list clears)"
    )
    mode: Literal["inference", "manual"] | None = Field(None)
    min_edge_count: int | None = Field(None, ge=1)
    min_confidence: float | None = Field(None, ge=0.0, le=1.0)
    manual_edge_selection: list[dict[str, str]] | None = Field(
        None,
        description="Manual mode edges as source_state/destination_state",
    )
    filter: DiscoveryDraftFilterModel | None = Field(
        None,
        description=(
            "Replace the draft's filter. Use ``clear_filter: true`` to "
            "explicitly clear the filter back to ``None``."
        ),
    )
    clear_filter: bool = Field(
        False,
        description=(
            "When ``true``, clear the draft's filter (set to ``None``). "
            "Takes precedence over any provided ``filter`` value."
        ),
    )
    observation_source: dict[str, Any] | None = Field(
        default=None,
        description=(
            "Replace the draft's observation table/collection mapping, or "
            "set to null to clear and use native ``discovery_observations`` "
            "storage. Omit this key to leave the mapping unchanged."
        ),
    )

    @field_validator("manual_edge_selection", mode="after")
    @classmethod
    def _reject_empty_edges(
        cls, v: list[dict[str, str]] | None
    ) -> list[dict[str, str]] | None:
        """Reject edges with blank ``source_state`` or ``destination_state``.

        The service layer previously silently dropped these pairs,
        producing an empty ``manual_edge_selection`` that would then
        fail a build with the cryptic "manual mode requires
        manual_edge_selection" error. Fail fast with 422 instead so
        the caller knows exactly which index was invalid.
        """
        if v is None:
            return None
        cleaned: list[dict[str, str]] = []
        for i, edge in enumerate(v):
            if not isinstance(edge, dict):
                raise ValueError(
                    f"manual_edge_selection[{i}]: expected an object with "
                    "source_state and destination_state keys"
                )
            src = str(edge.get("source_state", "")).strip()
            dst = str(edge.get("destination_state", "")).strip()
            if not src or not dst:
                raise ValueError(
                    f"manual_edge_selection[{i}]: source_state and "
                    "destination_state must be non-empty strings"
                )
            cleaned.append({"source_state": src, "destination_state": dst})
        return cleaned


class DiscoveryPromoteRequest(BaseModel):
    """Optional body for promoting a discovery candidate.

    Omit or send an empty body to preserve the legacy behavior
    (candidate is published under its own ``machine_name``).
    """

    target_machine_name: str | None = Field(
        None,
        description=(
            "Override the catalog target name. When set, the candidate is "
            "published under this name instead of its own ``machine_name``."
        ),
    )


class DiscoverySaveCandidateRequest(BaseModel):
    """Request body for saving an edited candidate config."""

    source_machine_name: str = Field(..., description="Discovery machine source name")
    target_machine_name: str = Field(
        ..., description="Machine name to save candidate under"
    )
    target_version: str | None = Field(
        None, description="Version to save under (auto-generated when omitted)"
    )
    config: dict[str, Any] = Field(..., description="Candidate FSM config")
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Optional additional metadata merged into candidate metadata",
    )


def _parse_iso_observed_at(raw: str) -> datetime:
    """Parse ``observed_at`` from wire ISO strings (used by observation row keys)."""
    try:
        dt = datetime.fromisoformat(raw)
    except ValueError as exc:
        raise ValueError(f"invalid observed_at: {raw}") from exc
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt


class DiscoveryObservationIdentityPayload(BaseModel):
    """Natural key for one discovery observation row."""

    entity_id: str = Field(..., description="Entity identifier")
    state: str = Field(..., description="Observed state name")
    observed_at: str = Field(..., description="ISO timestamp for observed_at")
    source: str = Field("api", description="Observation source label")
    source_event_id: str | None = Field(
        None, description="Optional upstream event id (null when absent)"
    )

    def to_domain(self) -> ObservationIdentity:
        """Map to the domain natural key type."""
        return ObservationIdentity(
            entity_id=self.entity_id.strip(),
            state=self.state.strip(),
            observed_at=_parse_iso_observed_at(self.observed_at),
            source=self.source.strip() or "api",
            source_event_id=self.source_event_id,
        )


class DiscoveryObservationDeleteOneRequest(BaseModel):
    """Delete a single observation row by natural key."""

    identity: DiscoveryObservationIdentityPayload


class DiscoveryObservationInsertRelativeRequest(BaseModel):
    """Insert a new observation adjacent to a reference row (newest-first order)."""

    entity_id: str = Field(..., description="Entity id (must match reference identity)")
    reference: DiscoveryObservationIdentityPayload = Field(
        ...,
        description="Existing row to insert relative to",
    )
    position: Literal["above", "below"] = Field(
        ...,
        description=(
            "``above`` inserts between the next-newer row and the reference; "
            "``below`` between the reference and the next-older row"
        ),
    )
    state: str = Field(..., description="Observed state for the new row")
    source: str = Field("api", description="Source label for the new row")
    source_event_id: str | None = Field(
        None,
        description="Optional idempotency key; a random UUID is used when omitted",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Optional metadata for the new row"
    )
