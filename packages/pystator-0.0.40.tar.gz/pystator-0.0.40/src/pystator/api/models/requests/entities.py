"""Request models — entities."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ProcessEntityEventRequest(BaseModel):
    """Request body for processing an event for an entity."""

    trigger: str = Field(..., description="Event trigger name")
    context: dict[str, Any] = Field(
        default_factory=dict, description="Optional context for guards/actions"
    )
    machine_name: str | None = Field(
        None, description="Machine name (required if entity doesn't exist yet)"
    )
    machine_version: str | None = Field(
        None, description="Machine version (defaults to latest)"
    )


class CreateEntityRequest(BaseModel):
    """Request body for creating an entity at the machine's initial state."""

    machine_name: str = Field(..., description="Machine name (stored definition)")
    machine_version: str | None = Field(
        None, description="Machine version (defaults to latest)"
    )
    context: dict[str, Any] = Field(
        default_factory=dict, description="Optional persisted entity context"
    )


class DryRunRequest(BaseModel):
    """Request body for a dry-run transition evaluation."""

    trigger: str = Field(..., description="Event trigger name")
    context: dict[str, Any] = Field(
        default_factory=dict, description="Context for guards/actions"
    )


class ApplyDataRequest(BaseModel):
    """Request body for enqueueing a triggerless apply-data update for an entity."""

    data: dict[str, Any] = Field(
        default_factory=dict,
        description="Data to merge into entity context (typically state variables)",
    )
    machine_name: str | None = Field(
        None,
        description=(
            "Optional machine name override for routing. "
            "When omitted, uses the entity's stored machine_name."
        ),
    )
    fires_at: str | None = Field(
        None,
        description="Optional ISO timestamp for delayed eligibility (defaults to now)",
    )
    idempotency_key: str | None = Field(None, description="Optional deduplication key")
    max_attempts: int | None = Field(
        None, ge=1, le=100, description="Optional per-event max attempts override"
    )


class UpdateLabelsRequest(BaseModel):
    """Request body for replacing all labels on an entity."""

    labels: dict[str, str] = Field(..., description="Key-value labels to set")


class PatchLabelsRequest(BaseModel):
    """Request body for merging labels on an entity."""

    labels: dict[str, str] = Field(..., description="Key-value labels to merge")


class BulkCreateEntityItem(BaseModel):
    """Single item in a bulk create request."""

    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str = Field(..., description="Machine name")
    machine_version: str | None = Field(None, description="Machine version")
    context: dict[str, Any] = Field(default_factory=dict, description="Entity context")


class BulkCreateEntitiesRequest(BaseModel):
    """Request body for bulk entity creation."""

    items: list[BulkCreateEntityItem] = Field(
        ..., description="Entities to create", max_length=100
    )


class BulkProcessEventsRequest(BaseModel):
    """Request body for bulk event processing."""

    trigger: str = Field(..., description="Event trigger name")
    entity_ids: list[str] = Field(
        ..., description="Entity IDs to process", max_length=100
    )
    context: dict[str, Any] = Field(default_factory=dict, description="Shared context")
    machine_name: str | None = Field(None, description="Machine name override")
    machine_version: str | None = Field(
        None,
        description=(
            "Machine definition version override. When omitted, each entity's "
            "stored machine_version is used (or latest if unset)."
        ),
    )


class ImportEntityRequest(BaseModel):
    """Request body for importing an entity from snapshot."""

    entity_id: str = Field(..., description="Entity identifier")
    machine_name: str | None = Field(None, description="Machine name")
    current_state: str = Field(..., description="Current state")
    context: dict[str, Any] = Field(default_factory=dict, description="Context")
    status: str = Field("active", description="Lifecycle status")
    labels: dict[str, str] = Field(default_factory=dict, description="Labels")
    history: list[dict[str, Any]] = Field(
        default_factory=list, description="History records"
    )
    overwrite: bool = Field(False, description="Overwrite if entity already exists")
