"""API request body models (package)."""

from __future__ import annotations

from .auth import LoginRequest
from .discovery import (
    DiscoveryBuildCandidateRequest,
    DiscoveryDraftCreateRequest,
    DiscoveryDraftPatchRequest,
    DiscoveryObservationDeleteOneRequest,
    DiscoveryObservationIdentityPayload,
    DiscoveryObservationInsertRelativeRequest,
    DiscoveryObserveRequest,
    DiscoveryPreviewRequest,
    DiscoveryPromoteRequest,
    DiscoverySaveCandidateRequest,
)
from .entities import (
    ApplyDataRequest,
    BulkCreateEntitiesRequest,
    BulkCreateEntityItem,
    BulkProcessEventsRequest,
    CreateEntityRequest,
    DryRunRequest,
    ImportEntityRequest,
    PatchLabelsRequest,
    ProcessEntityEventRequest,
    UpdateLabelsRequest,
)
from .machines import (
    MachineCreateRequest,
    MachineUpdateRequest,
    ProcessRequest,
    ValidateRequest,
)
from .settings import (
    DatabaseTestRequest,
    DiscoveryConnectionInstanceCreateRequest,
    DiscoveryConnectionInstancePatchRequest,
    DiscoveryDatabaseTestRequest,
    DlqStatsRequest,
    DlqTestRequest,
    ServerConfigPatchRequest,
)

__all__ = [
    "ApplyDataRequest",
    "BulkCreateEntitiesRequest",
    "BulkCreateEntityItem",
    "BulkProcessEventsRequest",
    "CreateEntityRequest",
    "DatabaseTestRequest",
    "DiscoveryBuildCandidateRequest",
    "DiscoveryConnectionInstanceCreateRequest",
    "DiscoveryConnectionInstancePatchRequest",
    "DiscoveryDatabaseTestRequest",
    "DiscoveryDraftCreateRequest",
    "DiscoveryDraftPatchRequest",
    "DiscoveryObservationDeleteOneRequest",
    "DiscoveryObservationIdentityPayload",
    "DiscoveryObservationInsertRelativeRequest",
    "DiscoveryObserveRequest",
    "DiscoveryPreviewRequest",
    "DiscoveryPromoteRequest",
    "DiscoverySaveCandidateRequest",
    "DlqStatsRequest",
    "DlqTestRequest",
    "DryRunRequest",
    "ImportEntityRequest",
    "LoginRequest",
    "MachineCreateRequest",
    "MachineUpdateRequest",
    "PatchLabelsRequest",
    "ProcessEntityEventRequest",
    "ProcessRequest",
    "ServerConfigPatchRequest",
    "UpdateLabelsRequest",
    "ValidateRequest",
]
