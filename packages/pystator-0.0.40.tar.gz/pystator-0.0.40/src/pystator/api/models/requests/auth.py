"""Request models — auth."""

from __future__ import annotations

from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    """Request body for authentication."""

    username: str = Field(..., description="Username")
    password: str = Field(..., description="Password")
