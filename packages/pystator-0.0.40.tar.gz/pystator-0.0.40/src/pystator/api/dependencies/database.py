"""Database session dependency for API routes."""

from __future__ import annotations

import os
from collections.abc import Generator

from fastapi import HTTPException, status
from fastapi.exceptions import RequestValidationError
from sqlalchemy import text
from sqlalchemy.orm import Session

from pystator.db.base import get_session
from pystator.db.config import (
    database_url_source_label,
    get_db_url_resolution,
    is_default_db_url,
    mask_database_url,
)
from pystator.db.sqlite_bootstrap import ensure_sqlite_database_ready

_default_db_warned: bool = False


def get_db_session() -> Generator[Session, None, None]:
    """
    FastAPI dependency to get database session.

    Defaults to SQLite (sqlite:///pystator.db) if no database URL is configured.
    Automatically initializes SQLite database if it doesn't exist or is uninitialized.
    """
    import logging

    logger = logging.getLogger(__name__)
    # Resolve URL (defaults to sqlite:///<cwd>/pystator.db when nothing configured)
    resolved = get_db_url_resolution(required=False)
    db_url = str(resolved.url or "")
    global _default_db_warned
    if is_default_db_url(db_url) and not _default_db_warned:
        _default_db_warned = True
        logger.warning(
            "No database URL configured. Using default SQLite: %s\n"
            "To use PostgreSQL, set PYSTATOR_DATABASE_URL:\n"
            "  export PYSTATOR_DATABASE_URL='postgresql://user:password@localhost:5432/pystator'",
            db_url,
        )
    else:
        logger.info(
            "Using database: %s [source=%s]",
            mask_database_url(db_url),
            database_url_source_label(resolved),
        )
    ensure_sqlite_database_ready(db_url)
    session = None
    try:
        session = get_session(db_url)
        session.execute(text("SELECT 1"))
        yield session
    except HTTPException:
        if session:
            try:
                session.rollback()
            except Exception:
                pass
        raise
    except RequestValidationError:
        if session:
            try:
                session.rollback()
            except Exception:
                pass
        raise
    except Exception as e:
        if session:
            try:
                session.rollback()
            except Exception:
                pass
        logger.error("Database session error: %s", e, exc_info=True)
        error_detail = "Failed to connect to database"
        error_msg = str(e).lower()
        if "no such table" in error_msg or (
            "table" in error_msg and "doesn't exist" in error_msg
        ):
            error_detail = "Database tables not found. Run: pystator db init"
        elif "no such column" in error_msg:
            error_detail = (
                "Database schema is out of date. Run: pystator db upgrade "
                "(then restart the API if the error persists)"
            )
        elif "database is locked" in error_msg:
            error_detail = (
                "Database is locked. Close other connections or wait and try again."
            )
        elif "permission denied" in error_msg or "access denied" in error_msg:
            error_detail = "Database permission denied. Check file permissions."
        else:
            if os.getenv("ENVIRONMENT") == "development" or not os.getenv(
                "ENVIRONMENT"
            ):
                error_detail = f"Failed to connect to database: {e}"
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=error_detail,
        )
    finally:
        if session:
            try:
                session.close()
            except Exception:
                pass
