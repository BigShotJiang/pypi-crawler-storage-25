"""Routes for inferred FSM discovery (shadow mode)."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Annotated, Any

from fastapi import APIRouter, Body, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from pystator.api.dependencies import get_db_session, get_fsm_service
from pystator.api.models.requests import (
    DiscoveryBuildCandidateRequest,
    DiscoveryConnectionInstanceCreateRequest,
    DiscoveryConnectionInstancePatchRequest,
    DiscoveryDraftCreateRequest,
    DiscoveryDraftPatchRequest,
    DiscoveryObservationDeleteOneRequest,
    DiscoveryObservationInsertRelativeRequest,
    DiscoveryObserveRequest,
    DiscoveryPreviewRequest,
    DiscoveryPromoteRequest,
    DiscoverySaveCandidateRequest,
)
from pystator.api.models.responses import (
    DiscoveryBuiltCandidateResponse,
    DiscoveryBuiltCandidateSummaryItem,
    DiscoveryConnectionInstancesListResponse,
    DiscoveryConnectionInstanceSummary,
    DiscoveryDraftResponse,
    DiscoveryEntityDeleteResponse,
    DiscoveryEntityListResponse,
    DiscoveryFleetListResponse,
    DiscoveryFleetMachineItem,
    DiscoveryInstancesListResponse,
    DiscoveryMachineDraftsResponse,
    DiscoveryObservationDeleteOneResponse,
    DiscoveryObservationInsertRelativeResponse,
    DiscoveryObservationListResponse,
    DiscoveryObserveResponse,
    DiscoveryPreviewResponse,
    DiscoveryShadowDiffResponse,
    MachineResponse,
)
from pystator.api.services.discovery_promotion import promote_discovery_candidate
from pystator.api.services.discovery_service import DiscoveryService
from pystator.api.services.fsm_service import FSMService
from pystator.db.config import get_db_url
from pystator.db.models import MachineModel
from pystator.discovery import instance_registry
from pystator.discovery.constants import DEFAULT_DISCOVERY_INSTANCE_ID
from pystator.discovery.engine_cache import clear_engine_cache_for_instance

router = APIRouter(prefix="/discovery")


def _validate_registry_backend(backend: str) -> str:
    try:
        return instance_registry.normalize_registry_backend(backend)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc


def _discovery_service(instance_id: str | None) -> DiscoveryService:
    """Resolve discovery service for a connection instance (default when omitted)."""
    return DiscoveryService.for_instance(instance_id or DEFAULT_DISCOVERY_INSTANCE_ID)


_SORT_FIELDS = frozenset(
    {
        "machine_name",
        "last_observation_at",
        "observation_count",
        "candidate_count",
        "drift_rate_recent",
        "shadow_diff_count_recent",
    }
)


@router.get(
    "/machines",
    response_model=DiscoveryFleetListResponse,
    status_code=status.HTTP_200_OK,
    summary="List machines with discovery activity (fleet index)",
    description=(
        "Aggregates per machine from discovery_observations, discovery_edges, "
        "discovery_built_candidates, discovery_drafts, and discovery_shadow_diffs. Shadow metrics use "
        "the latest 200 shadow diffs per machine (recorded_at DESC)."
    ),
)
async def list_discovery_fleet(
    query: str | None = Query(
        default=None,
        description="Case-insensitive substring filter on machine_name",
    ),
    sort: str = Query(
        default="machine_name",
        description=f"Sort field; one of: {', '.join(sorted(_SORT_FIELDS))}",
    ),
    order: str = Query(
        default="asc",
        description="Sort direction: asc or desc",
    ),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> DiscoveryFleetListResponse:
    sort_key = sort if sort in _SORT_FIELDS else "machine_name"
    order_norm = order.strip().lower()
    if order_norm not in ("asc", "desc"):
        order_norm = "asc"
    service = _discovery_service(None)
    payload = service.list_fleet_summaries(
        query=query,
        sort=sort_key,
        order=order_norm,
        limit=limit,
        offset=offset,
    )
    return DiscoveryFleetListResponse(
        items=[DiscoveryFleetMachineItem.model_validate(x) for x in payload["items"]],
        total=payload["total"],
        limit=payload["limit"],
        offset=payload["offset"],
    )


@router.get(
    "/connection-instances",
    response_model=DiscoveryConnectionInstancesListResponse,
    status_code=status.HTTP_200_OK,
    summary="List discovery connection instances (registered backends)",
    description=(
        "Returns rows from the main app database registry: one entry per "
        "discovery backend connection. Drafts are scoped under each connection."
    ),
)
async def list_discovery_connection_instances(
    query: str | None = Query(
        default=None,
        description=(
            "Case-insensitive substring match on title, namespace, backend, or id"
        ),
    ),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> DiscoveryConnectionInstancesListResponse:
    service = DiscoveryService()
    payload = service.list_connection_instances_registry(
        limit=limit, offset=offset, query=query
    )
    return DiscoveryConnectionInstancesListResponse(
        items=[
            DiscoveryConnectionInstanceSummary.model_validate(x)
            for x in payload["items"]
        ],
        total=payload["total"],
        limit=payload["limit"],
        offset=payload["offset"],
    )


@router.post(
    "/connection-instances",
    response_model=DiscoveryConnectionInstanceSummary,
    status_code=status.HTTP_201_CREATED,
    summary="Register a discovery connection instance",
)
async def create_discovery_connection_instance(
    body: DiscoveryConnectionInstanceCreateRequest,
    db: Session = Depends(get_db_session),
) -> DiscoveryConnectionInstanceSummary:
    if not get_db_url():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Application database not configured",
        )
    backend = _validate_registry_backend(body.backend)
    try:
        row = instance_registry.create_connection_instance(
            db,
            title=body.title.strip(),
            backend=backend,
            connection_string=body.connection_string.strip(),
            namespace=body.namespace,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    return DiscoveryConnectionInstanceSummary.model_validate(
        instance_registry.connection_instance_to_dict(row)
    )


@router.patch(
    "/connection-instances/{instance_id}",
    response_model=DiscoveryConnectionInstanceSummary,
    status_code=status.HTTP_200_OK,
    summary="Update discovery connection instance metadata",
)
async def patch_discovery_connection_instance(
    instance_id: str,
    body: DiscoveryConnectionInstancePatchRequest,
    db: Session = Depends(get_db_session),
) -> DiscoveryConnectionInstanceSummary:
    if not get_db_url():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Application database not configured",
        )
    fs = body.model_fields_set
    if not fs:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="No fields to update",
        )
    row0 = instance_registry.get_connection_instance(db, instance_id)
    if row0 is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Discovery connection instance not found",
        )
    if "title" in fs and (body.title is None or not str(body.title).strip()):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="title cannot be empty",
        )
    if "backend" in fs and (body.backend is None or not str(body.backend).strip()):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="backend cannot be empty",
        )
    if "connection_string" in fs and body.connection_string is None:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=(
                "connection_string must be a string when provided "
                "(use an empty string for the memory backend)"
            ),
        )

    if "namespace" in fs and body.namespace is not None:
        from pystator.discovery.slug import validate_discovery_namespace

        try:
            validate_discovery_namespace(body.namespace, "namespace")
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=str(exc),
            ) from exc

    backend_norm = (
        _validate_registry_backend(str(body.backend)) if "backend" in fs else None
    )
    eff_backend = (
        backend_norm if backend_norm is not None else row0.backend.strip().lower()
    )
    if "connection_string" in fs:
        conn_stripped = str(body.connection_string).strip()
        if eff_backend != "memory" and not conn_stripped:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="connection_string cannot be empty for this backend",
            )
    elif "backend" in fs and eff_backend != "memory":
        if not (row0.connection_string or "").strip():
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=(
                    "connection_string is required when switching to this backend; "
                    "include it in the patch"
                ),
            )

    try:
        row = instance_registry.apply_connection_instance_updates(
            db,
            instance_id,
            title="title" in fs,
            title_value=body.title.strip() if "title" in fs else None,
            backend="backend" in fs,
            backend_value=backend_norm,
            connection_string="connection_string" in fs,
            connection_string_value=(
                str(body.connection_string).strip()
                if "connection_string" in fs
                else None
            ),
            namespace="namespace" in fs,
            namespace_value=body.namespace if "namespace" in fs else None,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Discovery connection instance not found",
        )
    clear_engine_cache_for_instance(instance_id)
    return DiscoveryConnectionInstanceSummary.model_validate(
        instance_registry.connection_instance_to_dict(row)
    )


@router.delete(
    "/connection-instances/{instance_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a discovery connection instance",
)
async def delete_discovery_connection_instance(
    instance_id: str,
    db: Session = Depends(get_db_session),
) -> None:
    if not get_db_url():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Application database not configured",
        )
    from pystator.discovery.engine_cache import get_inference_engine

    try:
        n = len(get_inference_engine(instance_id).list_all_drafts())
    except Exception:
        n = 0
    if n > 0:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Cannot delete: {n} draft(s) still reference this connection",
        )
    try:
        ok = instance_registry.delete_connection_instance(db, instance_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    if not ok:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Discovery connection instance not found",
        )
    clear_engine_cache_for_instance(instance_id)


@router.get(
    "/instances",
    response_model=DiscoveryInstancesListResponse,
    status_code=status.HTTP_200_OK,
    summary="List discovery drafts for a connection instance",
    description=(
        "Paginated draft summaries. Pass ``discovery_instance_id`` to select "
        "which registered connection instance's store to read (defaults to the "
        "built-in default instance)."
    ),
)
async def list_discovery_instances(
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id (registry); default instance if omitted",
    ),
    query: str | None = Query(
        default=None,
        description="Case-insensitive substring match on draft title",
    ),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> DiscoveryInstancesListResponse:
    service = DiscoveryService()
    payload = service.list_all_instances(
        limit=limit,
        offset=offset,
        query=query,
        instance_id=discovery_instance_id,
    )
    return DiscoveryInstancesListResponse.model_validate(payload)


@router.post(
    "/observations",
    response_model=DiscoveryObserveResponse,
    status_code=status.HTTP_200_OK,
    summary="Record observed state",
)
async def record_observation(
    request: DiscoveryObserveRequest,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryObserveResponse:
    observed_at = None
    if request.observed_at:
        try:
            observed_at = datetime.fromisoformat(request.observed_at)
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid observed_at: {request.observed_at}",
            ) from exc
        # Normalize naive input (no tz offset) to UTC so downstream
        # stores don't have to branch on tz-awareness.
        if observed_at.tzinfo is None:
            observed_at = observed_at.replace(tzinfo=UTC)
    service = _discovery_service(discovery_instance_id)
    accepted = service.record_observation(
        machine_name=request.machine_name,
        entity_id=request.entity_id,
        state=request.state,
        observed_at=observed_at,
        source=request.source,
        source_event_id=request.source_event_id,
        ingest_seq=request.ingest_seq,
        metadata=request.metadata,
    )
    return DiscoveryObserveResponse(accepted=accepted)


@router.post(
    "/candidates/build",
    response_model=DiscoveryBuiltCandidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Build inferred candidate machine",
)
async def build_candidate(
    request: DiscoveryBuildCandidateRequest,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryBuiltCandidateResponse:
    service = _discovery_service(discovery_instance_id)
    edge_selection = [
        (item.get("source_state", ""), item.get("destination_state", ""))
        for item in request.edge_selection
    ]
    try:
        payload = service.build_candidate(
            request.machine_name,
            version=request.version,
            mode=request.mode,
            entity_ids=request.entity_ids,
            edge_selection=edge_selection,
            min_edge_count=request.min_edge_count,
            min_confidence=request.min_confidence,
            filter_model=request.filter,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    return DiscoveryBuiltCandidateResponse.model_validate(payload)


@router.post(
    "/candidates/preview",
    response_model=DiscoveryPreviewResponse,
    status_code=status.HTTP_200_OK,
    summary="Preview inferred edges for discovery scope",
)
async def preview_candidate(
    request: DiscoveryPreviewRequest,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryPreviewResponse:
    service = _discovery_service(discovery_instance_id)
    payload = service.preview_candidate_inputs(
        machine_name=request.machine_name,
        filter_model=request.filter,
        mode=request.mode,
        entity_ids=request.entity_ids,
        min_edge_count=request.min_edge_count,
        min_confidence=request.min_confidence,
    )
    return DiscoveryPreviewResponse.model_validate(payload)


@router.get(
    "/machines/{machine_name}/observations",
    response_model=DiscoveryObservationListResponse,
    status_code=status.HTTP_200_OK,
    summary="List raw observations for a discovery machine (paginated)",
    description=(
        "Low-level slice: rows in ``discovery_observations`` where "
        "``machine_name`` matches the path parameter, newest ``observed_at`` first. "
        "Optional ``entity_id`` narrows to one entity. "
        "For the Discovery UI and draft-aligned scope (filter + "
        "``observation_source``), prefer "
        "``GET /discovery/drafts/{draft_id}/observations`` instead."
    ),
)
async def list_machine_observations(
    machine_name: str,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
    entity_id: str | None = Query(
        default=None,
        description="If set, only observations for this entity id",
    ),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> DiscoveryObservationListResponse:
    service = _discovery_service(discovery_instance_id)
    payload = service.list_machine_observations(
        machine_name,
        limit=limit,
        offset=offset,
        entity_id=entity_id,
    )
    return DiscoveryObservationListResponse.model_validate(payload)


@router.get(
    "/drafts/{draft_id}/observations",
    response_model=DiscoveryObservationListResponse,
    status_code=status.HTTP_200_OK,
    summary="List observations for a draft scope (paginated)",
    description=(
        "Returns rows from the draft's observation source (default table or "
        "configured table/collection) constrained by the same effective filter "
        "as preview/build, plus optional ``entity_id``. Newest ``observed_at`` first."
    ),
)
async def list_draft_observations(
    draft_id: str,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id (registry row); default instance if omitted",
    ),
    entity_id: str | None = Query(
        default=None,
        description="If set, only observations for this entity id (ignored if entity_ids is set)",
    ),
    entity_ids: list[str] | None = Query(
        default=None,
        description="If set, only observations for these entity ids (repeat query param)",
    ),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> DiscoveryObservationListResponse:
    service = _discovery_service(discovery_instance_id)
    try:
        payload = service.list_draft_observations(
            draft_id,
            instance_id=discovery_instance_id,
            limit=limit,
            offset=offset,
            entity_id=entity_id,
            entity_ids=entity_ids,
        )
    except ValueError as exc:
        msg = str(exc)
        if "draft not found" in msg.lower():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=msg,
            ) from exc
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=msg,
        ) from exc
    except NotImplementedError as exc:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=str(exc),
        ) from exc
    return DiscoveryObservationListResponse.model_validate(payload)


@router.get(
    "/machines/{machine_name}/entities",
    response_model=DiscoveryEntityListResponse,
    status_code=status.HTTP_200_OK,
    summary="List distinct entity IDs for a discovery machine",
)
async def list_machine_entities(
    machine_name: str,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryEntityListResponse:
    service = _discovery_service(discovery_instance_id)
    return DiscoveryEntityListResponse(
        machine_name=machine_name,
        entity_ids=service.list_entity_ids(machine_name),
    )


@router.delete(
    "/machines/{machine_name}/entities/{entity_id}/observations",
    response_model=DiscoveryEntityDeleteResponse,
    status_code=status.HTTP_200_OK,
    summary="Delete all observations for one entity in a discovery machine",
)
async def delete_machine_entity_observations(
    machine_name: str,
    entity_id: str,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryEntityDeleteResponse:
    service = _discovery_service(discovery_instance_id)
    deleted_count = service.delete_entity_observations(machine_name, entity_id)
    return DiscoveryEntityDeleteResponse(
        machine_name=machine_name,
        entity_id=entity_id,
        deleted_count=int(deleted_count),
    )


@router.post(
    "/machines/{machine_name}/observations/delete-one",
    response_model=DiscoveryObservationDeleteOneResponse,
    status_code=status.HTTP_200_OK,
    summary="Delete one observation row by natural key",
    description=(
        "Deletes a single row in ``discovery_observations`` identified by "
        "entity, state, observed_at, source, and optional source_event_id."
    ),
)
async def delete_one_machine_observation(
    machine_name: str,
    body: DiscoveryObservationDeleteOneRequest,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryObservationDeleteOneResponse:
    try:
        identity = body.identity.to_domain()
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    service = _discovery_service(discovery_instance_id)
    deleted = service.delete_machine_observation(machine_name, identity)
    return DiscoveryObservationDeleteOneResponse(deleted=deleted)


@router.post(
    "/machines/{machine_name}/observations/insert-relative",
    response_model=DiscoveryObservationInsertRelativeResponse,
    status_code=status.HTTP_200_OK,
    summary="Insert an observation above or below a reference row",
    description=(
        "Computes ``observed_at`` / ``ingest_seq`` / ``ingested_at`` so the new row "
        "sorts between neighbors in newest-first order (same ordering as the list "
        "endpoints)."
    ),
)
async def insert_relative_machine_observation(
    machine_name: str,
    body: DiscoveryObservationInsertRelativeRequest,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryObservationInsertRelativeResponse:
    try:
        reference = body.reference.to_domain()
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    if reference.entity_id.strip() != body.entity_id.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="entity_id must match reference.entity_id",
        )
    service = _discovery_service(discovery_instance_id)
    try:
        accepted = service.insert_machine_observation_relative(
            machine_name,
            entity_id=body.entity_id.strip(),
            reference=reference,
            position=body.position,
            state=body.state.strip(),
            source=body.source.strip() or "api",
            source_event_id=body.source_event_id,
            metadata=body.metadata,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    return DiscoveryObservationInsertRelativeResponse(accepted=accepted)


@router.post(
    "/drafts/{draft_id}/observations/delete-one",
    response_model=DiscoveryObservationDeleteOneResponse,
    status_code=status.HTTP_200_OK,
    summary="Delete one observation row (draft scope, native store only)",
)
async def delete_one_draft_observation(
    draft_id: str,
    body: DiscoveryObservationDeleteOneRequest,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryObservationDeleteOneResponse:
    try:
        identity = body.identity.to_domain()
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    service = _discovery_service(discovery_instance_id)
    try:
        deleted = service.delete_draft_observation(
            draft_id,
            instance_id=discovery_instance_id,
            identity=identity,
        )
    except ValueError as exc:
        msg = str(exc)
        if "draft not found" in msg.lower():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=msg,
            ) from exc
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=msg,
        ) from exc
    return DiscoveryObservationDeleteOneResponse(deleted=deleted)


@router.post(
    "/drafts/{draft_id}/observations/insert-relative",
    response_model=DiscoveryObservationInsertRelativeResponse,
    status_code=status.HTTP_200_OK,
    summary="Insert adjacent to a row (draft scope, native store only)",
)
async def insert_relative_draft_observation(
    draft_id: str,
    body: DiscoveryObservationInsertRelativeRequest,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryObservationInsertRelativeResponse:
    try:
        reference = body.reference.to_domain()
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    if reference.entity_id.strip() != body.entity_id.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="entity_id must match reference.entity_id",
        )
    service = _discovery_service(discovery_instance_id)
    try:
        accepted = service.insert_draft_observation_relative(
            draft_id,
            instance_id=discovery_instance_id,
            entity_id=body.entity_id.strip(),
            reference=reference,
            position=body.position,
            state=body.state.strip(),
            source=body.source.strip() or "api",
            source_event_id=body.source_event_id,
            metadata=body.metadata,
        )
    except ValueError as exc:
        msg = str(exc)
        if "draft not found" in msg.lower():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=msg,
            ) from exc
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=msg,
        ) from exc
    return DiscoveryObservationInsertRelativeResponse(accepted=accepted)


@router.post(
    "/drafts",
    response_model=DiscoveryDraftResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create discovery draft (mutable scope before build)",
)
async def create_discovery_draft(
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
    request: DiscoveryDraftCreateRequest = Body(...),
) -> DiscoveryDraftResponse:
    service = _discovery_service(discovery_instance_id)
    try:
        payload = service.create_draft(
            title=request.title,
            instance_id=discovery_instance_id,
            filter_model=request.filter,
            min_edge_count=request.min_edge_count,
            min_confidence=request.min_confidence,
            observation_source=request.observation_source,
        )
    except ValueError as exc:
        msg = str(exc)
        if "duplicate draft title" in msg.lower():
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=msg,
            ) from exc
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=msg,
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    return DiscoveryDraftResponse.model_validate(payload)


@router.get(
    "/drafts",
    response_model=list[DiscoveryDraftResponse],
    status_code=status.HTTP_200_OK,
    summary="List discovery drafts for a connection instance",
)
async def list_discovery_drafts(
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> list[DiscoveryDraftResponse]:
    service = _discovery_service(discovery_instance_id)
    rows = service.list_drafts_full(discovery_instance_id)
    return [DiscoveryDraftResponse.model_validate(r) for r in rows]


@router.patch(
    "/drafts/{draft_id}",
    response_model=DiscoveryDraftResponse,
    status_code=status.HTTP_200_OK,
    summary="Update discovery draft",
)
async def patch_discovery_draft(
    draft_id: str,
    request: DiscoveryDraftPatchRequest,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryDraftResponse:
    service = _discovery_service(discovery_instance_id)
    patch = request.model_dump(exclude_unset=True)
    try:
        payload = service.patch_draft(draft_id, patch)
    except ValueError as exc:
        msg = str(exc)
        if "duplicate draft title" in msg.lower():
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=msg,
            ) from exc
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=msg,
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    return DiscoveryDraftResponse.model_validate(payload)


@router.delete(
    "/drafts/{draft_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete discovery draft",
)
async def delete_discovery_draft(
    draft_id: str,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> None:
    service = _discovery_service(discovery_instance_id)
    if not service.delete_draft(draft_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="draft not found",
        )


@router.post(
    "/drafts/{draft_id}/preview",
    response_model=DiscoveryPreviewResponse,
    status_code=status.HTTP_200_OK,
    summary="Preview inferred edges using draft scope",
)
async def preview_discovery_draft(
    draft_id: str,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryPreviewResponse:
    service = _discovery_service(discovery_instance_id)
    try:
        payload = service.preview_draft(draft_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    return DiscoveryPreviewResponse.model_validate(payload)


@router.post(
    "/drafts/{draft_id}/build",
    response_model=DiscoveryBuiltCandidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Build candidate from draft scope",
)
async def build_discovery_draft(
    draft_id: str,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryBuiltCandidateResponse:
    service = _discovery_service(discovery_instance_id)
    try:
        payload = service.build_draft(draft_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    return DiscoveryBuiltCandidateResponse.model_validate(payload)


@router.get(
    "/candidates/{machine_name}/latest",
    response_model=DiscoveryBuiltCandidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Get latest inferred candidate machine",
)
async def get_latest_candidate(
    machine_name: str,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryBuiltCandidateResponse:
    service = _discovery_service(discovery_instance_id)
    payload = service.get_latest_candidate(machine_name)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No candidate found for machine: {machine_name}",
        )
    if "edges" not in payload:
        payload["edges"] = []
    return DiscoveryBuiltCandidateResponse.model_validate(payload)


@router.get(
    "/candidates/{machine_name}",
    response_model=DiscoveryMachineDraftsResponse,
    status_code=status.HTTP_200_OK,
    summary="List drafts and built candidate versions",
)
async def list_discovery_for_machine(
    machine_name: str,
    db: Session = Depends(get_db_session),
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryMachineDraftsResponse:
    service = _discovery_service(discovery_instance_id)
    rows = service.list_candidate_summaries(machine_name)
    draft_rows: list[dict] = []
    promoted_versions = {
        str(v)
        for v in db.scalars(
            select(MachineModel.version).where(MachineModel.name == machine_name)
        ).all()
    }
    rows = [r for r in rows if str(r.get("version")) not in promoted_versions]
    return DiscoveryMachineDraftsResponse(
        machine_name=machine_name,
        drafts=[DiscoveryDraftResponse.model_validate(w) for w in draft_rows],
        built_candidates=[
            DiscoveryBuiltCandidateSummaryItem(
                machine_name=r["machine_name"],
                version=r["version"],
                candidate_sequence=int(r.get("candidate_sequence") or 0),
                status=r["status"],
                created_at=r["created_at"],
                metadata=r["metadata"],
                observation_count_at_build=int(
                    r.get("observation_count_at_build") or 0
                ),
                shadow_diff_count_recent=int(r.get("shadow_diff_count_recent") or 0),
                drift_rate_recent=float(r.get("drift_rate_recent") or 0.0),
                build_mode=(
                    str(r.get("build_mode"))
                    if r.get("build_mode") is not None
                    else None
                ),
            )
            for r in rows
        ],
    )


@router.get(
    "/candidates/{machine_name}/{candidate_version}",
    response_model=DiscoveryBuiltCandidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Get inferred candidate by version",
)
async def get_candidate_by_version(
    machine_name: str,
    candidate_version: str,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryBuiltCandidateResponse:
    service = _discovery_service(discovery_instance_id)
    payload = service.get_candidate_detail(machine_name, candidate_version)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(f"No candidate {machine_name!r} version {candidate_version!r}"),
        )
    return DiscoveryBuiltCandidateResponse.model_validate(payload)


@router.post(
    "/candidates/{machine_name}/{candidate_version}/promote",
    response_model=MachineResponse,
    status_code=status.HTTP_200_OK,
    summary="Promote candidate to stored FSM machine",
    description=(
        "Validate candidate config and upsert a row in the machines table "
        "for the same name and version as in the candidate meta."
    ),
)
async def promote_candidate(
    machine_name: str,
    candidate_version: str,
    request: DiscoveryPromoteRequest | None = Body(default=None),
    db: Session = Depends(get_db_session),
    fsm: Annotated[FSMService, Depends(get_fsm_service)] = None,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> MachineResponse:
    svc = fsm if fsm is not None else FSMService()
    discovery = _discovery_service(discovery_instance_id)
    target = request.target_machine_name if request is not None else None
    return promote_discovery_candidate(
        db,
        discovery,
        svc,
        machine_name,
        candidate_version,
        target_machine_name=target,
    )


@router.delete(
    "/candidates/{machine_name}/{candidate_version}",
    status_code=status.HTTP_200_OK,
    summary="Delete a built discovery candidate",
    description=(
        "Remove a built candidate. Promoted candidates cannot be deleted "
        "(returns 409). Non-existent candidates return 404."
    ),
)
async def delete_discovery_candidate(
    machine_name: str,
    candidate_version: str,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> dict[str, bool]:
    service = _discovery_service(discovery_instance_id)
    try:
        deleted = service.delete_built_candidate(machine_name, candidate_version)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="candidate not found",
        )
    return {"deleted": True}


@router.post(
    "/candidates/save",
    response_model=DiscoveryBuiltCandidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Save edited candidate configuration",
)
async def save_candidate(
    request: DiscoverySaveCandidateRequest,
    fsm: Annotated[FSMService, Depends(get_fsm_service)] = None,
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> DiscoveryBuiltCandidateResponse:
    svc = fsm if fsm is not None else FSMService()
    valid, errors, _, _warnings = svc.validate(request.config)
    if not valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": "Invalid FSM config", "errors": errors},
        )
    discovery = _discovery_service(discovery_instance_id)
    payload = discovery.save_candidate_config(
        source_machine_name=request.source_machine_name,
        target_machine_name=request.target_machine_name,
        target_version=request.target_version,
        config=request.config,
        metadata=request.metadata,
    )
    return DiscoveryBuiltCandidateResponse.model_validate(payload)


@router.get(
    "/shadow/{machine_name}",
    response_model=list[DiscoveryShadowDiffResponse],
    status_code=status.HTTP_200_OK,
    summary="List shadow-mode diffs",
)
async def list_shadow_diffs(
    machine_name: str,
    limit: int = Query(default=100, ge=1, le=500),
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> list[DiscoveryShadowDiffResponse]:
    service = _discovery_service(discovery_instance_id)
    rows = service.list_shadow_diffs(machine_name, limit=limit)
    return [DiscoveryShadowDiffResponse.model_validate(item) for item in rows]


@router.post(
    "/shadow/{machine_name}/compare",
    response_model=list[DiscoveryShadowDiffResponse],
    status_code=status.HTTP_200_OK,
    summary="On-demand cross-channel shadow comparison",
    description=(
        "Compare a candidate on this channel against a baseline machine "
        "from the catalog. The baseline machine can be from a different "
        "channel. Results are ephemeral (not stored)."
    ),
)
async def compare_shadow_against_baseline(
    machine_name: str,
    request: dict[str, Any] = Body(...),
    db: Session = Depends(get_db_session),
    discovery_instance_id: str | None = Query(
        default=None,
        description="Discovery connection instance id; default instance if omitted",
    ),
) -> list[DiscoveryShadowDiffResponse]:
    baseline_name = request.get("baseline_machine_name")
    if not baseline_name or not str(baseline_name).strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="baseline_machine_name is required",
        )
    baseline_name = str(baseline_name).strip()
    candidate_version = request.get("candidate_version")
    if candidate_version:
        candidate_version = str(candidate_version).strip() or None
    # Fetch baseline config from the machines catalog.
    from pystator.db.models import MachineModel

    row = (
        db.query(MachineModel)
        .filter(MachineModel.name == baseline_name)
        .order_by(MachineModel.created_at.desc())
        .first()
    )
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Baseline machine '{baseline_name}' not found in catalog",
        )
    baseline_config = row.config_dict
    service = _discovery_service(discovery_instance_id)
    rows = service.compare_against_baseline(
        machine_name=machine_name,
        baseline_config=baseline_config,
        baseline_machine_name=baseline_name,
        candidate_version=candidate_version,
    )
    return [DiscoveryShadowDiffResponse.model_validate(item) for item in rows]
