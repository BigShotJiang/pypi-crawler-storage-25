"""Workspace annotations (transition-anchored notes)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from pystator.api.dependencies import get_db_session
from pystator.db.models.transition_annotation import WorkspaceTransitionAnnotationModel

router = APIRouter(prefix="/transition-annotations")


@router.get(
    "",
    status_code=status.HTTP_200_OK,
    summary="List transition annotations for a machine version",
)
async def list_transition_annotations(
    machine_name: str = Query(..., description="Machine name"),
    machine_version: str = Query(..., description="Machine version"),
    session: Session = Depends(get_db_session),
) -> dict:
    rows = session.scalars(
        select(WorkspaceTransitionAnnotationModel)
        .where(
            WorkspaceTransitionAnnotationModel.machine_name == machine_name,
            WorkspaceTransitionAnnotationModel.machine_version == machine_version,
        )
        .order_by(WorkspaceTransitionAnnotationModel.transition_key.asc())
    ).all()
    return {
        "machine_name": machine_name,
        "machine_version": machine_version,
        "items": [
            {
                "transition_key": r.transition_key,
                "body_markdown": r.body_markdown or "",
                "updated_at": r.updated_at,
            }
            for r in rows
        ],
    }


@router.put(
    "/{machine_name}/{machine_version}/{transition_key}",
    status_code=status.HTTP_200_OK,
    summary="Upsert one transition annotation (idempotent)",
)
async def upsert_transition_annotation(
    machine_name: str,
    machine_version: str,
    transition_key: str,
    body: dict,
    session: Session = Depends(get_db_session),
) -> dict:
    body_markdown = str(body.get("body_markdown") or "")
    row = session.scalars(
        select(WorkspaceTransitionAnnotationModel).where(
            WorkspaceTransitionAnnotationModel.machine_name == machine_name,
            WorkspaceTransitionAnnotationModel.machine_version == machine_version,
            WorkspaceTransitionAnnotationModel.transition_key == transition_key,
        )
    ).first()
    if row is None:
        row = WorkspaceTransitionAnnotationModel(
            machine_name=machine_name,
            machine_version=machine_version,
            transition_key=transition_key,
            body_markdown=body_markdown,
        )
        session.add(row)
    else:
        row.body_markdown = body_markdown
    session.commit()
    return {"ok": True}


@router.delete(
    "/{machine_name}/{machine_version}/{transition_key}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete one transition annotation",
)
async def delete_transition_annotation(
    machine_name: str,
    machine_version: str,
    transition_key: str,
    session: Session = Depends(get_db_session),
) -> None:
    result = session.execute(
        delete(WorkspaceTransitionAnnotationModel).where(
            WorkspaceTransitionAnnotationModel.machine_name == machine_name,
            WorkspaceTransitionAnnotationModel.machine_version == machine_version,
            WorkspaceTransitionAnnotationModel.transition_key == transition_key,
        )
    )
    session.commit()
    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="annotation not found")
