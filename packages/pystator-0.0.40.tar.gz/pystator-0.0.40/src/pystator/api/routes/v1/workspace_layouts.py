"""Workspace diagram layout positions API."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from pystator.api.dependencies import get_db_session
from pystator.api.models.responses import (
    WorkspaceLayoutsListResponse,
)
from pystator.db.models.workspace_layout import WorkspaceLayoutModel

router = APIRouter(prefix="/layouts")


@router.get(
    "",
    response_model=WorkspaceLayoutsListResponse,
    status_code=status.HTTP_200_OK,
    summary="List layout positions for a machine version",
)
async def list_layouts(
    machine_name: str = Query(..., description="Machine name"),
    machine_version: str = Query(..., description="Machine version"),
    session: Session = Depends(get_db_session),
) -> WorkspaceLayoutsListResponse:
    """Return all saved positions as a dict keyed by state name."""
    rows = session.scalars(
        select(WorkspaceLayoutModel)
        .where(
            WorkspaceLayoutModel.machine_name == machine_name,
            WorkspaceLayoutModel.machine_version == machine_version,
        )
        .order_by(WorkspaceLayoutModel.state_name.asc())
    ).all()
    positions = {r.state_name: {"x": r.position_x, "y": r.position_y} for r in rows}
    return WorkspaceLayoutsListResponse(
        machine_name=machine_name,
        machine_version=machine_version,
        positions=positions,
    )


@router.put(
    "/{machine_name}/{machine_version}",
    status_code=status.HTTP_200_OK,
    summary="Batch upsert diagram positions",
)
async def batch_upsert_layouts(
    machine_name: str,
    machine_version: str,
    body: dict,
    session: Session = Depends(get_db_session),
) -> dict:
    """Upsert positions for multiple states at once.

    Args:
        machine_name: Machine name from path.
        machine_version: Machine version from path.
        body: ``{"positions": {"state_name": {"x": ..., "y": ...}}}``
        session: DB session dependency.

    Returns:
        ``{"ok": True, "upserted": <count>}``
    """
    positions = body.get("positions")
    if not isinstance(positions, dict):
        raise HTTPException(
            status_code=400,
            detail="body.positions must be a dict",
        )

    count = 0
    for state_name, pos in positions.items():
        if not isinstance(pos, dict):
            continue
        x = float(pos.get("x", 0))
        y = float(pos.get("y", 0))

        row = session.scalars(
            select(WorkspaceLayoutModel).where(
                WorkspaceLayoutModel.machine_name == machine_name,
                WorkspaceLayoutModel.machine_version == machine_version,
                WorkspaceLayoutModel.state_name == state_name,
            )
        ).first()
        if row is None:
            row = WorkspaceLayoutModel(
                machine_name=machine_name,
                machine_version=machine_version,
                state_name=state_name,
                position_x=x,
                position_y=y,
            )
            session.add(row)
        else:
            row.position_x = x
            row.position_y = y
        count += 1

    session.commit()
    return {"ok": True, "upserted": count}


@router.delete(
    "/{machine_name}/{machine_version}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete ALL positions for a machine version",
)
async def delete_all_layouts(
    machine_name: str,
    machine_version: str,
    session: Session = Depends(get_db_session),
) -> None:
    """Delete every saved position for a machine version.

    Used by the Reset Layout button to revert to auto-layout.
    """
    session.execute(
        delete(WorkspaceLayoutModel).where(
            WorkspaceLayoutModel.machine_name == machine_name,
            WorkspaceLayoutModel.machine_version == machine_version,
        )
    )
    session.commit()


@router.delete(
    "/{machine_name}/{machine_version}/{state_name}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete position for a single state",
)
async def delete_single_layout(
    machine_name: str,
    machine_version: str,
    state_name: str,
    session: Session = Depends(get_db_session),
) -> None:
    """Delete the saved position for one state."""
    result = session.execute(
        delete(WorkspaceLayoutModel).where(
            WorkspaceLayoutModel.machine_name == machine_name,
            WorkspaceLayoutModel.machine_version == machine_version,
            WorkspaceLayoutModel.state_name == state_name,
        )
    )
    session.commit()
    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="layout position not found")
