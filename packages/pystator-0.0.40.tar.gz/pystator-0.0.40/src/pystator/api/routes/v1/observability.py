"""Route handlers for observability dashboards.

Provides fleet-level operational visibility over entity transitions and
worker queue activity.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from pystator.api.dependencies.database import get_db_session
from pystator.api.models.responses import (
    EntityHealthResponse,
    ObservabilityStateMetricsResponse,
    ObservabilitySummaryResponse,
    ObservabilityTransitionItem,
    ObservabilityTransitionMetricsResponse,
    ObservabilityTransitionsResponse,
    ObservabilityWorkerEventItem,
    ObservabilityWorkerEventsResponse,
    StateOpsAgeBuckets,
    StateOpsErrorTopItem,
    StateOpsMetricsItem,
    TransitionAnalyticsResponse,
    TransitionOpsMetricsItem,
)
from pystator.api.services.analytics_service import (
    compute_entity_health,
    compute_transition_analytics,
)
from pystator.api.services.state_metrics_service import compute_state_metrics
from pystator.api.services.transition_metrics_service import (
    compute_transition_edge_metrics,
)
from pystator.db.models import (
    EntityStateModel,
    TransitionHistoryModel,
    WorkerEventModel,
)

router = APIRouter(prefix="/observability")


def _window_start(hours: int) -> datetime:
    """Return UTC window start timestamp for a trailing-hour window."""
    return datetime.now(UTC) - timedelta(hours=hours)


def _compute_p95(values: list[int]) -> int | None:
    """Compute p95 using nearest-rank method for a list of integer values."""
    if not values:
        return None
    sorted_values = sorted(values)
    rank = max(1, (95 * len(sorted_values) + 99) // 100)
    return sorted_values[min(rank - 1, len(sorted_values) - 1)]


@router.get(
    "/summary",
    response_model=ObservabilitySummaryResponse,
    summary="Get observability summary",
    description="Return high-level runtime KPIs for transitions and worker events.",
)
async def get_observability_summary(
    session: Annotated[Session, Depends(get_db_session)],
    window_hours: int = Query(
        default=24,
        ge=1,
        le=168,
        description="Trailing window size in hours for transition metrics",
    ),
    machine_name: str | None = Query(default=None, description="Filter by machine"),
    entity_id: str | None = Query(default=None, description="Filter by entity id"),
) -> ObservabilitySummaryResponse:
    """Return dashboard summary metrics for the selected scope."""
    end_time = datetime.now(UTC)
    start_time = _window_start(window_hours)

    th_filters = [
        TransitionHistoryModel.created_at >= start_time,
        TransitionHistoryModel.created_at <= end_time,
    ]
    if machine_name:
        th_filters.append(TransitionHistoryModel.machine_name == machine_name)
    if entity_id:
        th_filters.append(TransitionHistoryModel.entity_id == entity_id)

    transitions_total = (
        session.scalar(
            select(func.count()).select_from(TransitionHistoryModel).where(*th_filters)
        )
        or 0
    )
    transitions_failed = (
        session.scalar(
            select(func.count())
            .select_from(TransitionHistoryModel)
            .where(*th_filters, TransitionHistoryModel.success.is_(False))
        )
        or 0
    )

    duration_rows = session.execute(
        select(TransitionHistoryModel.duration_ms).where(*th_filters)
    ).all()
    durations = [
        int(row[0])
        for row in duration_rows
        if row[0] is not None and isinstance(row[0], int)
    ]

    es_filters: list = []
    if machine_name:
        es_filters.append(EntityStateModel.machine_name == machine_name)
    if entity_id:
        es_filters.append(EntityStateModel.entity_id == entity_id)
    es_count = select(func.count()).select_from(EntityStateModel)
    if es_filters:
        es_count = es_count.where(*es_filters)
    active_entities = session.scalar(es_count) or 0

    we_filters: list = []
    if machine_name:
        we_filters.append(WorkerEventModel.machine_name == machine_name)
    if entity_id:
        we_filters.append(WorkerEventModel.entity_id == entity_id)

    def _we_count(status_val: str) -> int:
        w = [*we_filters, WorkerEventModel.status == status_val]
        return (
            session.scalar(select(func.count()).select_from(WorkerEventModel).where(*w))
            or 0
        )

    worker_pending = _we_count("pending")
    worker_claimed = _we_count("claimed")
    worker_failed = _we_count("failed")
    worker_dead_letter = _we_count("dead_letter")

    failure_rate = (
        (transitions_failed / transitions_total) if transitions_total else 0.0
    )

    return ObservabilitySummaryResponse(
        window_start=start_time,
        window_end=end_time,
        active_entities=active_entities,
        transitions_total=transitions_total,
        transitions_failed=transitions_failed,
        transition_failure_rate=failure_rate,
        p95_transition_duration_ms=_compute_p95(durations),
        worker_pending=worker_pending,
        worker_claimed=worker_claimed,
        worker_failed=worker_failed,
        worker_dead_letter=worker_dead_letter,
    )


@router.get(
    "/transitions",
    response_model=ObservabilityTransitionsResponse,
    summary="List transition events",
    description="Return paginated transition history across entities with filters.",
)
async def list_observability_transitions(
    session: Annotated[Session, Depends(get_db_session)],
    machine_name: str | None = Query(default=None, description="Filter by machine"),
    entity_id: str | None = Query(default=None, description="Filter by entity id"),
    status: Literal["all", "success", "failed"] = Query(
        default="all", description="Filter by transition outcome"
    ),
    start_at: datetime | None = Query(
        default=None, description="Filter transitions at or after this UTC datetime"
    ),
    end_at: datetime | None = Query(
        default=None, description="Filter transitions at or before this UTC datetime"
    ),
    limit: int = Query(default=50, ge=1, le=200, description="Max records to return"),
    offset: int = Query(default=0, ge=0, description="Records to skip"),
) -> ObservabilityTransitionsResponse:
    """Return paginated transition history with optional filters."""
    conditions: list = []
    if machine_name:
        conditions.append(TransitionHistoryModel.machine_name == machine_name)
    if entity_id:
        conditions.append(TransitionHistoryModel.entity_id == entity_id)
    if status == "success":
        conditions.append(TransitionHistoryModel.success.is_(True))
    elif status == "failed":
        conditions.append(TransitionHistoryModel.success.is_(False))
    if start_at is not None:
        conditions.append(TransitionHistoryModel.created_at >= start_at)
    if end_at is not None:
        conditions.append(TransitionHistoryModel.created_at <= end_at)

    count_stmt = select(func.count()).select_from(TransitionHistoryModel)
    list_stmt = select(TransitionHistoryModel).order_by(
        TransitionHistoryModel.created_at.desc()
    )
    if conditions:
        count_stmt = count_stmt.where(*conditions)
        list_stmt = list_stmt.where(*conditions)
    total = session.scalar(count_stmt) or 0
    rows = session.scalars(list_stmt.offset(offset).limit(limit)).all()

    return ObservabilityTransitionsResponse(
        items=[
            ObservabilityTransitionItem(
                id=str(row.id),
                entity_id=row.entity_id,
                machine_name=row.machine_name,
                source_state=row.source_state,
                target_state=row.target_state,
                trigger=row.trigger,
                success=row.success,
                error_message=row.error_message,
                actions_executed=row.actions_executed,
                duration_ms=row.duration_ms,
                created_at=row.created_at,
            )
            for row in rows
        ],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/worker-events",
    response_model=ObservabilityWorkerEventsResponse,
    summary="List worker queue events",
    description="Return paginated worker event queue rows with filters.",
)
async def list_observability_worker_events(
    session: Annotated[Session, Depends(get_db_session)],
    machine_name: str | None = Query(default=None, description="Filter by machine"),
    entity_id: str | None = Query(default=None, description="Filter by entity id"),
    status: Literal[
        "all", "pending", "claimed", "completed", "failed", "dead_letter"
    ] = Query(default="all", description="Filter by worker event status"),
    start_at: datetime | None = Query(
        default=None,
        description="Filter events created at or after this UTC datetime",
    ),
    end_at: datetime | None = Query(
        default=None,
        description="Filter events created at or before this UTC datetime",
    ),
    limit: int = Query(default=50, ge=1, le=200, description="Max records to return"),
    offset: int = Query(default=0, ge=0, description="Records to skip"),
) -> ObservabilityWorkerEventsResponse:
    """Return paginated worker events with optional filters."""
    we_conditions: list = []
    if machine_name:
        we_conditions.append(WorkerEventModel.machine_name == machine_name)
    if entity_id:
        we_conditions.append(WorkerEventModel.entity_id == entity_id)
    if status != "all":
        we_conditions.append(WorkerEventModel.status == status)
    if start_at is not None:
        we_conditions.append(WorkerEventModel.created_at >= start_at)
    if end_at is not None:
        we_conditions.append(WorkerEventModel.created_at <= end_at)

    we_count_stmt = select(func.count()).select_from(WorkerEventModel)
    we_list_stmt = select(WorkerEventModel).order_by(WorkerEventModel.created_at.desc())
    if we_conditions:
        we_count_stmt = we_count_stmt.where(*we_conditions)
        we_list_stmt = we_list_stmt.where(*we_conditions)
    total = session.scalar(we_count_stmt) or 0
    rows = session.scalars(we_list_stmt.offset(offset).limit(limit)).all()

    return ObservabilityWorkerEventsResponse(
        items=[
            ObservabilityWorkerEventItem(
                id=str(row.id),
                machine_name=row.machine_name,
                entity_id=row.entity_id,
                trigger=row.trigger,
                status=row.status,
                attempt=row.attempt,
                max_attempts=row.max_attempts,
                error_message=row.error_message,
                fires_at=row.fires_at,
                claimed_by=row.claimed_by,
                claimed_at=row.claimed_at,
                created_at=row.created_at,
                completed_at=row.completed_at,
                result_json=row.result_json,
                transition_history_id=(
                    str(row.transition_history_id)
                    if row.transition_history_id is not None
                    else None
                ),
            )
            for row in rows
        ],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/state-metrics",
    response_model=ObservabilityStateMetricsResponse,
    summary="Get per-state operational metrics",
    description=(
        "Return minimal per-state metrics for augmenting the state diagram (counts, age, failures)."
    ),
)
async def get_observability_state_metrics(
    session: Annotated[Session, Depends(get_db_session)],
    machine_name: str = Query(..., description="Machine name (required)"),
    window_hours: int = Query(
        default=24,
        ge=1,
        le=168,
        description="Trailing window size in hours for failure metrics",
    ),
) -> ObservabilityStateMetricsResponse:
    window, metrics_by_state = compute_state_metrics(
        session=session,
        machine_name=machine_name,
        window_hours=window_hours,
    )

    items: list[StateOpsMetricsItem] = []
    for state_name, m in metrics_by_state.items():
        age_b = m.get("age_buckets") or {}
        top = m.get("top_error")
        items.append(
            StateOpsMetricsItem(
                state_name=state_name,
                entity_count=int(m.get("entity_count") or 0),
                age_p95_seconds=m.get("age_p95_seconds"),
                age_oldest_seconds=m.get("age_oldest_seconds"),
                age_buckets=StateOpsAgeBuckets(
                    le_5m=int(age_b.get("le_5m") or 0),
                    le_30m=int(age_b.get("le_30m") or 0),
                    gt_30m=int(age_b.get("gt_30m") or 0),
                ),
                failed_transition_count=int(m.get("failed_transition_count") or 0),
                successful_target_entries_count=int(
                    m.get("successful_target_entries_count") or 0
                ),
                top_error=StateOpsErrorTopItem(**top)
                if isinstance(top, dict)
                else None,
            )
        )

    return ObservabilityStateMetricsResponse(
        machine_name=machine_name,
        window_start=window.start,
        window_end=window.end,
        items=items,
    )


@router.get(
    "/transition-metrics",
    response_model=ObservabilityTransitionMetricsResponse,
    summary="Get per-edge transition metrics",
    description=(
        "Return transition_history aggregates by (source_state, target_state, trigger) "
        "for augmenting diagram edges."
    ),
)
async def get_observability_transition_metrics(
    session: Annotated[Session, Depends(get_db_session)],
    machine_name: str = Query(..., description="Machine name (required)"),
    window_hours: int = Query(
        default=24,
        ge=1,
        le=168,
        description="Trailing window size in hours",
    ),
) -> ObservabilityTransitionMetricsResponse:
    window, metrics_by_key = compute_transition_edge_metrics(
        session=session,
        machine_name=machine_name,
        window_hours=window_hours,
    )
    items: list[TransitionOpsMetricsItem] = []
    for m in sorted(
        metrics_by_key.values(),
        key=lambda row: (row["source_state"], row["target_state"], row["trigger"]),
    ):
        top = m.get("top_error")
        items.append(
            TransitionOpsMetricsItem(
                source_state=str(m["source_state"]),
                target_state=str(m["target_state"]),
                trigger=str(m["trigger"]),
                attempts_total=int(m["attempts_total"]),
                attempts_failed=int(m["attempts_failed"]),
                duration_p95_ms=m.get("duration_p95_ms"),
                top_error=StateOpsErrorTopItem(**top)
                if isinstance(top, dict)
                else None,
            )
        )
    return ObservabilityTransitionMetricsResponse(
        machine_name=machine_name,
        window_start=window.start,
        window_end=window.end,
        items=items,
    )


@router.get(
    "/entity-health",
    response_model=EntityHealthResponse,
    summary="Get entity health analytics",
    description="Return entity-centric health metrics including state/status distribution.",
)
async def get_entity_health(
    session: Annotated[Session, Depends(get_db_session)],
    window_hours: int = Query(
        default=24,
        ge=1,
        le=168,
        description="Trailing window for failure metrics",
    ),
    machine_name: str | None = Query(default=None, description="Filter by machine"),
) -> EntityHealthResponse:
    """Return entity health analytics."""
    data = compute_entity_health(session, window_hours, machine_name)
    return EntityHealthResponse(**data)


@router.get(
    "/transition-analytics",
    response_model=TransitionAnalyticsResponse,
    summary="Get transition analytics",
    description="Return time-series and aggregate transition analytics.",
)
async def get_transition_analytics(
    session: Annotated[Session, Depends(get_db_session)],
    window_hours: int = Query(
        default=24,
        ge=1,
        le=168,
        description="Trailing window size in hours",
    ),
    machine_name: str | None = Query(default=None, description="Filter by machine"),
    bucket_count: int = Query(
        default=12,
        ge=2,
        le=48,
        description="Number of time buckets",
    ),
) -> TransitionAnalyticsResponse:
    """Return transition analytics with time bucketing."""
    data = compute_transition_analytics(
        session, window_hours, machine_name, bucket_count
    )
    return TransitionAnalyticsResponse(**data)
