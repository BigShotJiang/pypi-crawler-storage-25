"""Bulk entity operations (create and event processing).

Provides batch endpoints for creating multiple entities and processing
events across multiple entities in a single request.  Each item is
processed independently; per-item errors are captured and returned
without aborting the entire batch.  A single commit covers all
successful operations at the end.
"""

from __future__ import annotations

import logging
import time
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from pystator.api.dependencies.database import get_db_session
from pystator.api.models.requests import (
    BulkCreateEntitiesRequest,
    BulkProcessEventsRequest,
)
from pystator.api.models.responses import (
    BulkCreateEntitiesResponse,
    BulkCreateEntityResult,
    BulkProcessEventResult,
    BulkProcessEventsResponse,
)
from pystator.api.services.entity_service import (
    EntityAlreadyExistsError,
    EntityNotActiveError,
    MachineNotFoundError,
    NoInitialStateForMachineError,
    create_entity_at_initial,
    process_entity_event,
)
from pystator.db.models import EntityStateModel
from pystator.shared.entity_id_validator import validate_entity_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/entities/bulk")


# ============================================================
# Helper Functions
# ============================================================


def _get_machine_config(
    session: Session,
    machine_name: str,
    machine_version: str | None = None,
) -> dict[str, Any]:
    """Load machine config from database via entity_service.load_machine_config."""
    from pystator.api.services.entity_service import (
        MachineNotFoundError,
        load_machine_config,
    )

    try:
        return load_machine_config(session, machine_name, machine_version)
    except MachineNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Machine not found: {machine_name}"
            + (f"@{machine_version}" if machine_version else ""),
        )


# ============================================================
# Route Handlers
# ============================================================


@router.post(
    "/create",
    response_model=BulkCreateEntitiesResponse,
    summary="Bulk create entities",
    description=(
        "Create multiple entities at their machine's initial state in a single "
        "request.  Each item is processed independently; per-item errors are "
        "captured and returned.  A single commit covers all successful creates."
    ),
    responses={
        200: {"description": "Bulk create results returned"},
    },
)
async def bulk_create_entities(
    request: BulkCreateEntitiesRequest,
    session: Annotated[Session, Depends(get_db_session)],
) -> BulkCreateEntitiesResponse:
    """Create multiple entities at their initial state."""
    results: list[BulkCreateEntityResult] = []
    succeeded = 0
    failed = 0

    for item in request.items:
        try:
            validate_entity_id(item.entity_id)
        except ValueError as exc:
            results.append(
                BulkCreateEntityResult(
                    entity_id=item.entity_id,
                    success=False,
                    current_state=None,
                    error=str(exc),
                )
            )
            failed += 1
            continue

        try:
            machine_config = _get_machine_config(
                session, item.machine_name, item.machine_version
            )
        except HTTPException as exc:
            results.append(
                BulkCreateEntityResult(
                    entity_id=item.entity_id,
                    success=False,
                    current_state=None,
                    error=exc.detail,
                )
            )
            failed += 1
            continue

        try:
            start_time = time.time()
            duration_ms = int((time.time() - start_time) * 1000)
            entity, _history = create_entity_at_initial(
                session,
                entity_id=item.entity_id,
                machine_name=item.machine_name,
                machine_config=machine_config,
                machine_version=item.machine_version,
                context=item.context,
                duration_ms=duration_ms,
            )
            results.append(
                BulkCreateEntityResult(
                    entity_id=entity.entity_id,
                    success=True,
                    current_state=entity.current_state,
                    error=None,
                )
            )
            succeeded += 1
        except EntityAlreadyExistsError:
            results.append(
                BulkCreateEntityResult(
                    entity_id=item.entity_id,
                    success=False,
                    current_state=None,
                    error=f"Entity already exists: {item.entity_id}",
                )
            )
            failed += 1
        except NoInitialStateForMachineError:
            results.append(
                BulkCreateEntityResult(
                    entity_id=item.entity_id,
                    success=False,
                    current_state=None,
                    error=f"Machine {item.machine_name} has no initial state",
                )
            )
            failed += 1
        except ValueError as exc:
            results.append(
                BulkCreateEntityResult(
                    entity_id=item.entity_id,
                    success=False,
                    current_state=None,
                    error=str(exc),
                )
            )
            failed += 1
        except Exception:
            logger.exception("Unexpected error creating entity %s", item.entity_id)
            results.append(
                BulkCreateEntityResult(
                    entity_id=item.entity_id,
                    success=False,
                    current_state=None,
                    error="Internal error",
                )
            )
            failed += 1

    session.commit()

    return BulkCreateEntitiesResponse(
        results=results,
        total=len(request.items),
        succeeded=succeeded,
        failed=failed,
    )


@router.post(
    "/events",
    response_model=BulkProcessEventsResponse,
    summary="Bulk process events",
    description=(
        "Process a single trigger across multiple entities in one request.  "
        "Each entity is processed independently; per-entity errors are "
        "captured and returned.  A single commit covers all successful updates."
    ),
    responses={
        200: {"description": "Bulk event processing results returned"},
    },
)
async def bulk_process_events(
    request: BulkProcessEventsRequest,
    session: Annotated[Session, Depends(get_db_session)],
) -> BulkProcessEventsResponse:
    """Process a trigger for multiple entities."""
    results: list[BulkProcessEventResult] = []
    succeeded = 0
    failed = 0

    for entity_id in request.entity_ids:
        try:
            validate_entity_id(entity_id)
        except ValueError as exc:
            results.append(
                BulkProcessEventResult(
                    entity_id=entity_id,
                    success=False,
                    source_state=None,
                    target_state=None,
                    error=str(exc),
                )
            )
            failed += 1
            continue

        try:
            entity = session.scalars(
                select(EntityStateModel).where(EntityStateModel.entity_id == entity_id)
            ).first()
            if not entity:
                results.append(
                    BulkProcessEventResult(
                        entity_id=entity_id,
                        success=False,
                        source_state=None,
                        target_state=None,
                        error=f"Entity not found: {entity_id}",
                    )
                )
                failed += 1
                continue

            pe = process_entity_event(
                session,
                entity_id=entity_id,
                trigger=request.trigger,
                machine_name=request.machine_name,
                machine_version=request.machine_version,
                context=request.context,
            )

            if pe.success:
                results.append(
                    BulkProcessEventResult(
                        entity_id=entity_id,
                        success=True,
                        source_state=pe.source_state,
                        target_state=pe.target_state,
                        error=None,
                    )
                )
                succeeded += 1
            else:
                results.append(
                    BulkProcessEventResult(
                        entity_id=entity_id,
                        success=False,
                        source_state=pe.source_state,
                        target_state=None,
                        error=pe.error_message,
                    )
                )
                failed += 1

        except EntityNotActiveError as exc:
            results.append(
                BulkProcessEventResult(
                    entity_id=entity_id,
                    success=False,
                    source_state=None,
                    target_state=None,
                    error=str(exc),
                )
            )
            failed += 1
        except MachineNotFoundError as exc:
            results.append(
                BulkProcessEventResult(
                    entity_id=entity_id,
                    success=False,
                    source_state=None,
                    target_state=None,
                    error=str(exc),
                )
            )
            failed += 1
        except NoInitialStateForMachineError as exc:
            results.append(
                BulkProcessEventResult(
                    entity_id=entity_id,
                    success=False,
                    source_state=None,
                    target_state=None,
                    error=f"Machine {exc.machine_name} has no initial state",
                )
            )
            failed += 1
        except ValueError as exc:
            results.append(
                BulkProcessEventResult(
                    entity_id=entity_id,
                    success=False,
                    source_state=None,
                    target_state=None,
                    error=str(exc),
                )
            )
            failed += 1
        except HTTPException as exc:
            results.append(
                BulkProcessEventResult(
                    entity_id=entity_id,
                    success=False,
                    source_state=None,
                    target_state=None,
                    error=exc.detail,
                )
            )
            failed += 1
        except Exception:
            logger.exception(
                "Unexpected error processing event for entity %s", entity_id
            )
            results.append(
                BulkProcessEventResult(
                    entity_id=entity_id,
                    success=False,
                    source_state=None,
                    target_state=None,
                    error="Internal error",
                )
            )
            failed += 1

    session.commit()

    return BulkProcessEventsResponse(
        trigger=request.trigger,
        results=results,
        total=len(request.entity_ids),
        succeeded=succeeded,
        failed=failed,
    )
