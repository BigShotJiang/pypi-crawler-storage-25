"""Webhook CRUD API routes.

Manage webhook subscriptions for event notifications (transition failures,
dead letter creation, dwell time exceeded).
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from pystator.api.dependencies.database import get_db_session
from pystator.db.models.webhook import WebhookModel

router = APIRouter(prefix="/webhooks")

# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

VALID_EVENT_TYPES = frozenset(
    {"transition_failed", "dead_letter_created", "dwell_time_exceeded"}
)


class WebhookCreateRequest(BaseModel):
    """Request body for creating a webhook."""

    name: str = Field(..., description="Human-readable name", max_length=255)
    url: str = Field(..., description="Target URL for HTTP POST", max_length=2048)
    events: list[str] = Field(
        ..., description="Event types to subscribe to", min_length=1
    )
    headers: dict[str, str] | None = Field(None, description="Custom HTTP headers")
    enabled: bool = Field(True, description="Whether the webhook is active")


class WebhookUpdateRequest(BaseModel):
    """Request body for updating a webhook."""

    name: str | None = Field(None, max_length=255)
    url: str | None = Field(None, max_length=2048)
    events: list[str] | None = Field(None, min_length=1)
    headers: dict[str, str] | None = None
    enabled: bool | None = None


class WebhookResponse(BaseModel):
    """Response model for a webhook."""

    id: str
    name: str
    url: str
    events: list[str]
    headers: dict[str, str] | None = None
    enabled: bool
    created_at: datetime | None = None
    updated_at: datetime | None = None


class WebhookListResponse(BaseModel):
    """Response model for listing webhooks."""

    webhooks: list[WebhookResponse]
    total: int


class WebhookTestResponse(BaseModel):
    """Response model for testing a webhook."""

    success: bool
    status_code: int | None = None
    error: str | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _row_to_response(row: WebhookModel) -> WebhookResponse:
    """Convert a WebhookModel row to a response dict."""
    return WebhookResponse(
        id=str(row.id),
        name=row.name,
        url=row.url,
        events=row.events_json or [],
        headers=row.headers_json,
        enabled=row.enabled,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


def _validate_events(events: list[str]) -> None:
    """Raise 400 if any event types are invalid."""
    invalid = set(events) - VALID_EVENT_TYPES
    if invalid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid event types: {sorted(invalid)}. "
            f"Valid types: {sorted(VALID_EVENT_TYPES)}",
        )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("", response_model=WebhookListResponse)
def list_webhooks(
    session: Annotated[Session, Depends(get_db_session)],
) -> WebhookListResponse:
    """List all webhook subscriptions."""
    rows = session.scalars(
        select(WebhookModel).order_by(WebhookModel.created_at.desc())
    ).all()
    return WebhookListResponse(
        webhooks=[_row_to_response(r) for r in rows],
        total=len(rows),
    )


@router.post("", response_model=WebhookResponse, status_code=status.HTTP_201_CREATED)
def create_webhook(
    body: WebhookCreateRequest,
    session: Annotated[Session, Depends(get_db_session)],
) -> WebhookResponse:
    """Create a new webhook subscription."""
    _validate_events(body.events)
    row = WebhookModel(
        name=body.name,
        url=body.url,
        events_json=body.events,
        headers_json=body.headers,
        enabled=body.enabled,
    )
    session.add(row)
    session.commit()
    session.refresh(row)
    return _row_to_response(row)


@router.get("/{webhook_id}", response_model=WebhookResponse)
def get_webhook(
    webhook_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> WebhookResponse:
    """Get a webhook by ID."""
    row = session.scalars(
        select(WebhookModel).where(WebhookModel.id == uuid.UUID(webhook_id))
    ).first()
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Webhook {webhook_id} not found",
        )
    return _row_to_response(row)


@router.put("/{webhook_id}", response_model=WebhookResponse)
def update_webhook(
    webhook_id: str,
    body: WebhookUpdateRequest,
    session: Annotated[Session, Depends(get_db_session)],
) -> WebhookResponse:
    """Update a webhook subscription."""
    row = session.scalars(
        select(WebhookModel).where(WebhookModel.id == uuid.UUID(webhook_id))
    ).first()
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Webhook {webhook_id} not found",
        )
    if body.name is not None:
        row.name = body.name
    if body.url is not None:
        row.url = body.url
    if body.events is not None:
        _validate_events(body.events)
        row.events_json = body.events
    if body.headers is not None:
        row.headers_json = body.headers
    if body.enabled is not None:
        row.enabled = body.enabled
    row.updated_at = datetime.now(UTC)
    session.commit()
    session.refresh(row)
    return _row_to_response(row)


@router.delete("/{webhook_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_webhook(
    webhook_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> None:
    """Delete a webhook subscription."""
    row = session.scalars(
        select(WebhookModel).where(WebhookModel.id == uuid.UUID(webhook_id))
    ).first()
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Webhook {webhook_id} not found",
        )
    session.delete(row)
    session.commit()


@router.post("/{webhook_id}/test", response_model=WebhookTestResponse)
def test_webhook(
    webhook_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> WebhookTestResponse:
    """Send a test payload to a webhook."""
    import json
    import urllib.request

    row = session.scalars(
        select(WebhookModel).where(WebhookModel.id == uuid.UUID(webhook_id))
    ).first()
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Webhook {webhook_id} not found",
        )
    payload: dict[str, Any] = {
        "event_type": "test",
        "webhook_id": str(row.id),
        "webhook_name": row.name,
        "message": "This is a test payload from PyStator.",
        "timestamp": datetime.now(UTC).isoformat(),
    }
    body = json.dumps(payload).encode("utf-8")
    headers = {"Content-Type": "application/json", **(row.headers_json or {})}
    req = urllib.request.Request(row.url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return WebhookTestResponse(success=True, status_code=resp.status)
    except Exception as exc:
        return WebhookTestResponse(success=False, error=str(exc))
