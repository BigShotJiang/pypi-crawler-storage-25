"""Database URL resolution for PyStator."""

from __future__ import annotations

import os
from configparser import ConfigParser
from dataclasses import dataclass
from typing import Literal

from pystator.config.paths import find_config_file

_ENV_KEY = "PYSTATOR_DATABASE_URL"
_ALEMBIC_PLACEHOLDER = "driver://user:pass@localhost/dbname"


@dataclass(frozen=True, slots=True)
class DatabaseUrlResolution:
    """Resolved database URL plus where it came from."""

    url: str | None
    source: Literal["explicit", "env", "cfg", "alembic_ini", "default", "unset"]
    source_detail: str | None = None


def _cfg_database_url() -> tuple[str | None, str | None]:
    """Return configured DB URL from ``pystator.cfg`` and source detail."""
    cfg_path = find_config_file("pystator.cfg")
    if not cfg_path:
        return None, None
    cfg = ConfigParser()
    cfg.read(cfg_path)
    if not cfg.has_section("database"):
        return None, None
    db_url = cfg.get("database", _ENV_KEY, fallback=None)
    if db_url:
        return db_url, str(cfg_path)
    return None, str(cfg_path)


def _alembic_ini_database_url() -> tuple[str | None, str | None]:
    """Return configured DB URL from ``alembic.ini`` and source detail."""
    alembic_ini = find_config_file("alembic.ini")
    if not alembic_ini:
        return None, None
    cfg = ConfigParser()
    cfg.read(alembic_ini)
    db_url = cfg.get("alembic", "sqlalchemy.url", fallback=None)
    if db_url and db_url != _ALEMBIC_PLACEHOLDER:
        return db_url, str(alembic_ini)
    return None, str(alembic_ini)


def resolve_database_url(
    *,
    explicit_url: str | None = None,
    include_default: bool = False,
) -> DatabaseUrlResolution:
    """Resolve DB URL with deterministic precedence and source attribution.

    Precedence:
      1) explicit argument
      2) ``PYSTATOR_DATABASE_URL`` env
      3) ``pystator.cfg`` ``[database] PYSTATOR_DATABASE_URL``
      4) ``alembic.ini`` ``[alembic] sqlalchemy.url`` (when not placeholder)
      5) default SQLite URL (only when ``include_default=True``)
    """
    if explicit_url and explicit_url.strip():
        return DatabaseUrlResolution(
            url=explicit_url.strip(),
            source="explicit",
            source_detail="explicit argument",
        )
    db_url = os.getenv(_ENV_KEY)
    if db_url:
        return DatabaseUrlResolution(
            url=db_url.strip(),
            source="env",
            source_detail=_ENV_KEY,
        )
    cfg_url, cfg_detail = _cfg_database_url()
    if cfg_url:
        return DatabaseUrlResolution(
            url=cfg_url.strip(),
            source="cfg",
            source_detail=cfg_detail,
        )
    alembic_url, alembic_detail = _alembic_ini_database_url()
    if alembic_url:
        return DatabaseUrlResolution(
            url=alembic_url.strip(),
            source="alembic_ini",
            source_detail=alembic_detail,
        )
    if include_default:
        return DatabaseUrlResolution(
            url=None,
            source="default",
            source_detail="sqlite:///<cwd>/pystator.db",
        )
    return DatabaseUrlResolution(url=None, source="unset", source_detail=None)


def get_database_url() -> str | None:
    return resolve_database_url(include_default=False).url


def set_database_url(database_url: str) -> None:
    os.environ[_ENV_KEY] = database_url
