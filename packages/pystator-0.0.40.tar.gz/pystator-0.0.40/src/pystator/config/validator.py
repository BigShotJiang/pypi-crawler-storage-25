"""Configuration validation for PyStator FSM definitions."""

from __future__ import annotations

import re
from typing import Any

from pydantic import ValidationError

from pystator.config.models import MachineConfig
from pystator.errors import ConfigurationError

_HISTORY_DEST_RE = re.compile(r"^H\*?\(\w[\w.]*\)$")
_ENTRY_EXIT_RE = re.compile(r"^(\w[\w.]*):(\w[\w.]*)$")
_WILDCARD_SOURCE = "*"

# Keys under ``error_policy`` that the runtime reads when building ``StateMachine`` / ``ErrorPolicy``.
_RECOGNIZED_ERROR_POLICY_KEYS = frozenset({"default_fallback", "retry_attempts"})


class ConfigValidator:
    """Validates FSM configuration with Pydantic and semantic rules.

    Performs two levels of validation:
    1. Pydantic schema validation (structure and types)
    2. Semantic validation (state references, exactly one initial, no transitions from terminal)

    Example:
        >>> validator = ConfigValidator()
        >>> errors = validator.validate(config)
        >>> if errors:
        ...     for error in errors:
        ...         print(f"Error: {error}")
    """

    def __init__(self) -> None:
        """Initialize the validator. Validation uses Pydantic models and semantic rules."""

    def config_warnings(self, config: dict[str, Any]) -> list[str]:
        """Non-fatal issues: unrecognized or deprecated ``error_policy`` keys.

        These do not fail :meth:`validate`; surface them in API/UI so configs stay honest.
        """
        warnings: list[str] = []
        warnings.extend(self._error_policy_key_warnings(config))
        warnings.extend(self._orchestrator_default_fallback_warnings(config))
        return warnings

    def _error_policy_key_warnings(self, config: dict[str, Any]) -> list[str]:
        warnings: list[str] = []
        ep = config.get("error_policy")
        if not isinstance(ep, dict):
            return warnings
        for key in ep:
            if key in _RECOGNIZED_ERROR_POLICY_KEYS:
                continue
            if key == "on_invalid_trigger":
                warnings.append(
                    "error_policy.on_invalid_trigger is not used by the engine; "
                    "use meta.strict_mode or meta.reject_invalid_events "
                    "(lenient: no matching transition becomes a no-op success). "
                    "Remove this key to silence this warning."
                )
            elif key == "strict_mode":
                warnings.append(
                    "error_policy.strict_mode is ignored; use meta.strict_mode, "
                    "and optionally meta.reject_invalid_events / meta.strict_guard_registry "
                    "to split invalid-event handling vs guard-registry strictness."
                )
            else:
                warnings.append(
                    f"error_policy key {key!r} is not recognized by this version of PyStator and is ignored."
                )
        return warnings

    def _orchestrator_default_fallback_warnings(
        self, config: dict[str, Any]
    ) -> list[str]:
        """Warn on meta.orchestrator_default_fallback vs error_policy.default_fallback."""
        warnings: list[str] = []
        meta = config.get("meta")
        if not isinstance(meta, dict):
            meta = {}
        raw_mode = meta.get("orchestrator_default_fallback", "off")
        if isinstance(raw_mode, bool):
            warnings.append(
                "meta.orchestrator_default_fallback is a boolean; use the string "
                "enum 'off', 'hint', or 'persist'. True is treated as 'persist' at runtime; "
                "False as 'off'."
            )
        mode = str(raw_mode).strip().lower() if isinstance(raw_mode, str) else "off"
        if isinstance(raw_mode, str) and mode not in ("off", "hint", "persist"):
            warnings.append(
                f"meta.orchestrator_default_fallback value {raw_mode!r} is not "
                "'off', 'hint', or 'persist'; the orchestrator treats it as 'off'."
            )

        ep = config.get("error_policy")
        fb: str | None = None
        if isinstance(ep, dict):
            raw_fb = ep.get("default_fallback")
            if isinstance(raw_fb, str) and raw_fb.strip():
                fb = raw_fb.strip()

        state_names = {
            str(s.get("name", ""))
            for s in config.get("states", [])
            if isinstance(s, dict) and s.get("name")
        }
        if fb and fb not in state_names:
            warnings.append(
                f"error_policy.default_fallback state {fb!r} is not defined in this "
                "machine's states; orchestrator default_fallback hint/persist is disabled."
            )

        eff = str(raw_mode).strip().lower() if isinstance(raw_mode, str) else "off"
        if isinstance(raw_mode, bool):
            eff = "persist" if raw_mode else "off"
        if eff in ("hint", "persist") and not fb:
            warnings.append(
                f"meta.orchestrator_default_fallback is '{eff}' but error_policy.default_fallback "
                "is missing or empty; the orchestrator will not apply hints or recovery."
            )
        return warnings

    def validate(self, config: dict[str, Any]) -> list[str]:
        """Validate configuration.

        Args:
            config: The configuration dictionary to validate.

        Returns:
            List of validation error messages. Empty if valid.
        """
        errors: list[str] = []

        # Pydantic (schema) validation
        try:
            MachineConfig.model_validate(config)
        except ValidationError as e:
            for err in e.errors():
                loc = ".".join(str(p) for p in err.get("loc", ()))
                msg = err.get("msg", "validation error")
                if loc:
                    errors.append(f"[{loc}] {msg}")
                else:
                    errors.append(msg)
            return errors

        # Semantic validation
        errors.extend(self._validate_semantics(config))
        return errors

    def _validate_semantics(self, config: dict[str, Any]) -> list[str]:
        """Validate semantic rules (state refs, one initial, no transitions from terminal)."""
        errors: list[str] = []

        states = config.get("states", [])
        transitions = config.get("transitions", [])

        state_names: set[str] = set()
        initial_states: list[str] = []

        for state in states:
            name = state.get("name", "")
            if name in state_names:
                errors.append(f"Duplicate state name: '{name}'")
            state_names.add(name)
            if state.get("type") == "initial":
                initial_states.append(name)

        if len(initial_states) == 0:
            errors.append(
                "No initial state defined. Exactly one state must have type='initial'"
            )
        elif len(initial_states) > 1:
            errors.append(
                f"Multiple initial states defined: {initial_states}. "
                "Exactly one state must have type='initial'"
            )

        for i, trans in enumerate(transitions):
            trigger = trans.get("trigger") or f"transition[{i}]"
            source = trans.get("source", [])
            if isinstance(source, str):
                source = [source]
            for src in source:
                if src not in state_names and not _ENTRY_EXIT_RE.match(src):
                    errors.append(
                        f"Transition '{trigger}': source state '{src}' not defined"
                    )
            dest = trans.get("dest", "")
            # Allow history destinations like H(Parent) or H*(Parent)
            # Allow entry/exit point refs like parent:point
            if (
                dest not in state_names
                and not _HISTORY_DEST_RE.match(dest)
                and not _ENTRY_EXIT_RE.match(dest)
            ):
                errors.append(
                    f"Transition '{trigger}': destination state '{dest}' not defined"
                )

        for state in states:
            timeout = state.get("timeout")
            if timeout:
                dest = timeout.get("destination", "")
                if dest and dest not in state_names:
                    errors.append(
                        f"State '{state.get('name')}': timeout destination '{dest}' not defined"
                    )

        error_policy = config.get("error_policy") or {}
        fallback = error_policy.get("default_fallback")
        if fallback and fallback not in state_names:
            errors.append(f"Error policy: fallback state '{fallback}' not defined")

        terminal_states = {s.get("name") for s in states if s.get("type") == "terminal"}
        for trans in transitions:
            source = trans.get("source", [])
            if isinstance(source, str):
                source = [source]
            for src in source:
                if src in terminal_states:
                    errors.append(
                        f"Transition '{trans.get('trigger')}': "
                        f"cannot have transitions from terminal state '{src}'"
                    )

        # Check parallel states with final regions but no join transition
        for state in states:
            if state.get("type") != "parallel":
                continue
            regions = state.get("regions", [])
            has_final = any(r.get("final") for r in regions if isinstance(r, dict))
            if not has_final:
                continue
            pname = state.get("name", "")
            join_trigger = f"_join_{pname}"
            has_join = any(
                t.get("trigger") == join_trigger
                or (isinstance(t.get("source"), str) and t.get("source") == pname)
                or (isinstance(t.get("source"), list) and pname in t.get("source", []))
                for t in transitions
                if t.get("trigger", "").startswith("_join_")
            )
            if not has_join:
                errors.append(
                    f"Parallel state '{pname}' has regions with 'final' "
                    f"but no '_join_{pname}' transition defined"
                )

        state_vars = config.get("state_variables")
        if isinstance(state_vars, list):
            seen_keys: set[str] = set()
            for item in state_vars:
                key = (
                    item
                    if isinstance(item, str)
                    else (item.get("key", "") if isinstance(item, dict) else "")
                )
                if key in seen_keys:
                    errors.append(f"Duplicate state_variable key: {key!r}")
                seen_keys.add(key)

        state_by_name: dict[str, dict[str, Any]] = {
            s.get("name", ""): s
            for s in states
            if isinstance(s, dict) and s.get("name")
        }
        terminal_names = {s.get("name") for s in states if s.get("type") == "terminal"}

        # parent / initial_child
        for state in states:
            if not isinstance(state, dict):
                continue
            sname = state.get("name", "")
            parent = state.get("parent")
            if parent is not None and isinstance(parent, str) and parent.strip():
                if parent not in state_names:
                    errors.append(
                        f"State '{sname}': parent '{parent}' is not a defined state"
                    )
                elif parent in terminal_names:
                    errors.append(
                        f"State '{sname}': parent '{parent}' is terminal; "
                        "terminal states cannot be compound parents"
                    )
            ic = state.get("initial_child")
            if ic is not None and isinstance(ic, str) and ic.strip():
                if ic not in state_names:
                    errors.append(
                        f"State '{sname}': initial_child '{ic}' is not a defined state"
                    )
                else:
                    child = state_by_name.get(ic)
                    if child and child.get("parent") != sname:
                        errors.append(
                            f"State '{sname}': initial_child '{ic}' must have "
                            f"parent '{sname}' (got {child.get('parent')!r})"
                        )

        # non-parallel must not carry regions data
        for state in states:
            if not isinstance(state, dict):
                continue
            if state.get("type") != "parallel" and state.get("regions"):
                errors.append(
                    f"State '{state.get('name')}': regions are only allowed when type is 'parallel'"
                )

        # parallel regions + global unique region names
        region_name_to_parents: dict[str, list[str]] = {}
        parallel_region_membership: dict[
            str, dict[str, frozenset[str]]
        ] = {}  # parallel_state -> region_name -> member states

        for state in states:
            if not isinstance(state, dict) or state.get("type") != "parallel":
                continue
            pname = state.get("name", "")
            regions_raw = state.get("regions") or []
            seen_region_names: set[str] = set()
            for reg in regions_raw:
                if not isinstance(reg, dict):
                    continue
                rn = reg.get("name")
                if not rn:
                    continue
                if rn in seen_region_names:
                    errors.append(
                        f"Parallel state '{pname}': duplicate region name '{rn}'"
                    )
                seen_region_names.add(rn)
                region_name_to_parents.setdefault(rn, []).append(pname)
                initial = reg.get("initial")
                if initial and initial not in state_names:
                    errors.append(
                        f"Parallel state '{pname}' region '{rn}': "
                        f"initial state '{initial}' is not defined"
                    )
                st_list = reg.get("states") or []
                if not isinstance(st_list, list):
                    continue
                members: set[str] = set()
                for st in st_list:
                    if not isinstance(st, str):
                        continue
                    if st not in state_names:
                        errors.append(
                            f"Parallel state '{pname}' region '{rn}': "
                            f"state '{st}' is not defined"
                        )
                        continue
                    members.add(st)
                if initial:
                    members.add(initial)
                if st_list and initial and initial not in st_list:
                    errors.append(
                        f"Parallel state '{pname}' region '{rn}': "
                        f"initial '{initial}' must appear in states list"
                    )
                for st in st_list:
                    if isinstance(st, str) and st in state_by_name:
                        ch = state_by_name[st]
                        p = ch.get("parent")
                        if p is not None and p != pname:
                            errors.append(
                                f"State '{st}' is listed in parallel state '{pname}' "
                                f"region '{rn}' but has parent '{p}'"
                            )
                parallel_region_membership.setdefault(pname, {})[rn] = frozenset(
                    members
                )

        for rn, plist in region_name_to_parents.items():
            unique_parents = sorted(set(plist))
            if len(unique_parents) > 1:
                errors.append(
                    f"Region name '{rn}' is defined in multiple parallel states "
                    f"{unique_parents}; region names must be unique across the machine"
                )

        # transitions with region
        for i, trans in enumerate(transitions):
            if not isinstance(trans, dict):
                continue
            trigger = trans.get("trigger") or f"transition[{i}]"
            rgn = trans.get("region")
            if not rgn or not isinstance(rgn, str) or not rgn.strip():
                continue
            owners = region_name_to_parents.get(rgn, [])
            unique_owners = sorted(set(owners))
            if not unique_owners:
                errors.append(
                    f"Transition '{trigger}': region '{rgn}' is not defined on any parallel state"
                )
                continue
            if len(unique_owners) > 1:
                errors.append(
                    f"Transition '{trigger}': region '{rgn}' is ambiguous "
                    f"(parallel states {unique_owners})"
                )
                continue
            pstate = unique_owners[0]
            pmap = parallel_region_membership.get(pstate, {})
            members = pmap.get(rgn)
            if members is None:
                errors.append(
                    f"Transition '{trigger}': region '{rgn}' has no membership on '{pstate}'"
                )
                continue
            source = trans.get("source", [])
            if isinstance(source, str):
                source = [source]
            for src in source:
                if src == _WILDCARD_SOURCE:
                    continue
                if not isinstance(src, str) or not src:
                    continue
                if src not in state_names:
                    continue
                if _ENTRY_EXIT_RE.match(src):
                    continue
                if src not in members:
                    errors.append(
                        f"Transition '{trigger}': source '{src}' is not in region "
                        f"'{rgn}' of parallel state '{pstate}'"
                    )

        return errors

    def validate_strict(self, config: dict[str, Any]) -> None:
        """Validate and raise ConfigurationError if invalid."""
        errors = self.validate(config)
        if errors:
            raise ConfigurationError(
                f"Configuration validation failed with {len(errors)} error(s)",
                context={"errors": errors},
            )


def validate_config(config: dict[str, Any], strict: bool = True) -> list[str]:
    """Validate a configuration dictionary.

    Args:
        config: The configuration dictionary to validate.
        strict: If True, raises ConfigurationError on failure.

    Returns:
        List of validation error messages.

    Raises:
        ConfigurationError: If strict=True and validation fails.
    """
    validator = ConfigValidator()
    if strict:
        validator.validate_strict(config)
        return []
    return validator.validate(config)
