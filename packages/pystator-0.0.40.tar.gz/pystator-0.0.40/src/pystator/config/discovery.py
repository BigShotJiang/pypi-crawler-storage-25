"""Discovery configuration (env + pystator.cfg)."""

from __future__ import annotations

import os
from configparser import ConfigParser

from pystator.config.paths import find_config_file

_SECTION = "discovery"
_SQL_DISCOVERY_BACKENDS = frozenset({"sqlite", "postgres", "postgresql"})


def _cfg(key: str) -> str | None:
    cfg_path = find_config_file("pystator.cfg")
    if not cfg_path:
        return None
    cfg = ConfigParser()
    cfg.read(cfg_path)
    if not cfg.has_section(_SECTION):
        return None
    return cfg.get(_SECTION, key, fallback=None)


def get_discovery_backend() -> str:
    return (
        (
            os.getenv("PYSTATOR_DISCOVERY_BACKEND")
            or _cfg("PYSTATOR_DISCOVERY_BACKEND")
            or "memory"
        )
        .strip()
        .lower()
    )


def get_discovery_database_url() -> str | None:
    return os.getenv("PYSTATOR_DISCOVERY_DATABASE_URL") or _cfg(
        "PYSTATOR_DISCOVERY_DATABASE_URL"
    )


def get_effective_discovery_database_url(
    backend: str | None = None,
) -> tuple[str | None, bool]:
    """Return discovery DB URL and whether it fell back to app DB config.

    Returns ``(url, used_app_db_fallback)``. Fallback is only applied for SQL
    discovery backends (sqlite/postgres/postgresql).
    """
    explicit = get_discovery_database_url()
    if explicit and str(explicit).strip():
        return str(explicit).strip(), False
    eff_backend = (backend or get_discovery_backend()).strip().lower()
    if eff_backend not in _SQL_DISCOVERY_BACKENDS:
        return None, False
    from pystator.db.config import get_db_url

    return get_db_url(required=False), True


def is_discovery_shadow_enabled() -> bool:
    raw = (
        os.getenv("PYSTATOR_DISCOVERY_SHADOW_ENABLED")
        or _cfg("PYSTATOR_DISCOVERY_SHADOW_ENABLED")
        or "1"
    )
    return str(raw).strip().lower() in {"1", "true", "yes", "on"}


def get_discovery_min_edge_count() -> int:
    raw = (
        os.getenv("PYSTATOR_DISCOVERY_MIN_EDGE_COUNT")
        or _cfg("PYSTATOR_DISCOVERY_MIN_EDGE_COUNT")
        or "2"
    )
    try:
        return max(1, int(raw))
    except ValueError:
        return 2


def get_discovery_min_confidence() -> float:
    raw = (
        os.getenv("PYSTATOR_DISCOVERY_MIN_CONFIDENCE")
        or _cfg("PYSTATOR_DISCOVERY_MIN_CONFIDENCE")
        or "0.5"
    )
    try:
        val = float(raw)
    except ValueError:
        return 0.5
    return min(1.0, max(0.0, val))


def get_discovery_drift_alert_threshold() -> float:
    raw = (
        os.getenv("PYSTATOR_DISCOVERY_DRIFT_ALERT_THRESHOLD")
        or _cfg("PYSTATOR_DISCOVERY_DRIFT_ALERT_THRESHOLD")
        or "0.15"
    )
    try:
        val = float(raw)
    except ValueError:
        return 0.15
    return min(1.0, max(0.0, val))


def get_discovery_drift_severe_threshold() -> float:
    raw = (
        os.getenv("PYSTATOR_DISCOVERY_DRIFT_SEVERE_THRESHOLD")
        or _cfg("PYSTATOR_DISCOVERY_DRIFT_SEVERE_THRESHOLD")
        or "0.4"
    )
    try:
        val = float(raw)
    except ValueError:
        return 0.4
    return min(1.0, max(0.0, val))


def get_discovery_drift_min_sample() -> int:
    raw = (
        os.getenv("PYSTATOR_DISCOVERY_DRIFT_MIN_SAMPLE")
        or _cfg("PYSTATOR_DISCOVERY_DRIFT_MIN_SAMPLE")
        or "3"
    )
    try:
        return max(1, int(raw))
    except ValueError:
        return 3


def get_discovery_low_sample_threshold() -> int:
    raw = (
        os.getenv("PYSTATOR_DISCOVERY_LOW_SAMPLE_THRESHOLD")
        or _cfg("PYSTATOR_DISCOVERY_LOW_SAMPLE_THRESHOLD")
        or "10"
    )
    try:
        return max(1, int(raw))
    except ValueError:
        return 10
