"""Lazy imports for optional store backend dependencies."""

from __future__ import annotations

from typing import Any


def require_pymongo() -> Any:
    try:
        import pymongo
    except ImportError as e:
        raise ImportError(
            "MongoDB stores require pymongo. Install with: pip install 'pystator[api]'"
        ) from e
    return pymongo


def require_redis() -> Any:
    try:
        import redis
    except ImportError as e:
        raise ImportError(
            "Redis stores require redis. Install with: pip install 'pystator[worker]'"
        ) from e
    return redis
