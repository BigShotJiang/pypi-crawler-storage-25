"""Orchestrator: sandwich loop (load state, process, persist, execute actions).

The app implements a state store adapter and calls
``orchestrator.process_event(entity_id, event)``.
"""

from __future__ import annotations

import inspect
import logging
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from pystator._parallel import ParallelStateConfig
from pystator._types import TransitionResult
from pystator.actions import ActionRegistry, _ActionExecutor
from pystator.errors import FSMError
from pystator.event import Event
from pystator.guards import GuardRegistry
from pystator.hooks import TransitionHook, TransitionObserver
from pystator.invoke import InvokeAdapter, run_invoke_start, run_invoke_stop
from pystator.machine import StateMachine
from pystator.orchestrator_default_fallback import (
    MD_SKIP_APPLY_HISTORY,
    build_persist_synthetic_result,
    enrich_hint_result,
    fallback_leaf_name,
    is_allowlisted_failure,
    parallel_fallback_eligible,
    parse_mode,
    scalar_fallback_eligible,
)
from pystator.state_parsing import parse_stored_state
from pystator.stores.base import AsyncStateStore, AuditStore, EventStore, StateStore
from pystator.workflow_status import persistence_flags_for_state

if TYPE_CHECKING:
    from pystator.scheduler.base import SchedulerAdapter

logger = logging.getLogger(__name__)

# Type alias for context validator functions.
# Signature: (entity_id, current_state, trigger, context) -> (ok, errors)
ContextValidatorFn = Callable[
    [str, str, str, dict[str, Any]],
    tuple[bool, list[str]],
]


class Orchestrator:
    """Runs the full FSM sandwich loop: load -> process -> persist -> execute.

    Args:
        machine: The StateMachine definition.
        state_store: Sync or async state store.
        guards: Guard registry (bound to machine automatically).
        actions: Action registry.
        context_validator: Optional callable for pre-transition context validation.
        executor: Optional _ActionExecutor (created automatically if omitted).
        scheduler: Optional scheduler for delayed transitions.
        use_initial_state_when_missing: Use machine's initial state for new entities.
        invoke_adapter: Optional adapter to start/stop invoked services on state enter/exit.
        hooks: Optional list of TransitionHook implementations for lifecycle callbacks.
        audit_store: Optional AuditStore for transition audit logging.

    Context validation options (choose one or combine):

        1. ``context_validator`` (recommended for external validation, e.g. PyCharter):
           Callable with signature ``(entity_id, state, trigger, context) -> (ok, errors)``.
           Runs BEFORE guards. Use for schema or contract validation.

        2. ``machine.meta["validate_context"]``: Config-driven, set in YAML/dict.
           Validates that required keys exist in context. Lightweight, no external deps.

        3. Guards: Use for business-rule validation that depends on state + context.
           Runs AFTER context_validator. Best for domain logic (e.g., "is_cancellable").
    """

    def __init__(
        self,
        machine: StateMachine,
        state_store: StateStore | AsyncStateStore,
        guards: GuardRegistry | None = None,
        actions: ActionRegistry | None = None,
        *,
        context_validator: ContextValidatorFn | None = None,
        executor: _ActionExecutor | None = None,
        scheduler: SchedulerAdapter | None = None,
        use_initial_state_when_missing: bool = True,
        invoke_adapter: InvokeAdapter | None = None,
        hooks: list[TransitionHook] | None = None,
        audit_store: AuditStore | None = None,
        event_store: EventStore | None = None,
    ) -> None:
        """Initialize the orchestrator.

        Args:
            machine: The StateMachine definition.
            state_store: Sync or async state store for entity persistence.
            guards: Optional guard registry (defaults to machine's registry).
            actions: Optional action registry (defaults to machine's registry).
            context_validator: Optional pre-transition context validator callable.
            executor: Optional _ActionExecutor (auto-created if omitted).
            scheduler: Optional scheduler for delayed transitions.
            use_initial_state_when_missing: Use machine's initial state for new entities.
            invoke_adapter: Optional adapter for invoked services.
            hooks: Optional list of TransitionHook implementations.
            audit_store: Optional AuditStore for transition audit logging.
            event_store: Optional EventStore for append-only event persistence.
        """
        self._machine = machine
        self._store = state_store

        # Bind guards if provided
        if guards is not None:
            machine.bind_guards(guards)

        # Use machine's registries if not explicitly provided
        self._guards = guards or machine.guard_registry
        self._actions = actions or machine.action_registry
        self._executor = executor or _ActionExecutor(self._actions, log_execution=True)
        self._context_validator = context_validator
        self._scheduler = scheduler
        self._use_initial = use_initial_state_when_missing
        self._invoke_adapter = invoke_adapter
        self._audit_store = audit_store
        self._event_store = event_store

        # Set up transition observer if hooks provided
        self._observer: TransitionObserver | None = None
        if hooks:
            self._observer = TransitionObserver()
            for hook in hooks:
                self._observer.add_hook(hook)

    @property
    def machine(self) -> StateMachine:
        """The underlying StateMachine definition."""
        return self._machine

    @property
    def store(self) -> StateStore | AsyncStateStore:
        """The state store backing this orchestrator."""
        return self._store

    def _persist_flags(self, state_name: str) -> dict[str, Any]:
        """Return persistence flags for store metadata."""
        is_t, ws = persistence_flags_for_state(self._machine, state_name)
        return {
            "is_terminal": is_t,
            "workflow_status": ws,
            "machine_name": self._machine.name,
            "machine_version": self._machine.version,
        }

    def _apply_scalar_default_fallback(
        self, prior_state: str, trigger: str, result: TransitionResult
    ) -> TransitionResult:
        """Hint or persist for allowlisted scalar failures (or pass through)."""
        mode = parse_mode(self._machine.meta)
        fb = fallback_leaf_name(
            self._machine, self._machine._error_policy.default_fallback
        )
        if mode == "off" or fb is None:
            return result
        if not scalar_fallback_eligible(result) or result.error is None:
            return result
        if mode == "hint":
            return enrich_hint_result(result, fb)
        return build_persist_synthetic_result(
            self._machine,
            source_state=prior_state,
            target_leaf=fb,
            trigger=trigger,
            original_error=result.error,
        )

    def _finalize_sync_success(
        self,
        entity_id: str,
        result: TransitionResult,
        ctx: dict[str, Any],
        store: StateStore,
    ) -> None:
        """Persist, execute actions, audit, and post-chain for a successful transition."""
        if not result.metadata.get(MD_SKIP_APPLY_HISTORY):
            self._machine._engine.apply_history(result)
        state_changed = result.target_state != result.source_state

        if state_changed:
            if self._scheduler:
                import asyncio

                try:
                    loop = asyncio.get_running_loop()
                    loop.create_task(self._scheduler.cancel_for_entity(entity_id))
                except RuntimeError:
                    asyncio.run(self._scheduler.cancel_for_entity(entity_id))

            metadata = {
                "trigger": result.trigger,
                "source_state": result.source_state,
                "target_state": result.target_state,
                **self._persist_flags(result.target_state),
            }
            if self._machine.is_parallel_state(result.target_state):
                config = self._machine.enter_parallel_state(result.target_state)
                store.set_state(entity_id, config.to_string(), metadata=metadata)
            else:
                store.set_state(entity_id, result.target_state, metadata=metadata)

        if self._invoke_adapter is not None:
            get_invoke = lambda n: self._machine.get_state(n).invoke
            run_invoke_stop(
                self._invoke_adapter,
                result.source_state,
                get_invoke,
                ctx,
            )
        if result.all_action_specs:
            ctx["new_status"] = result.target_state
            self._executor.execute(result, ctx)
        if self._invoke_adapter is not None:
            get_invoke = lambda n: self._machine.get_state(n).invoke
            run_invoke_start(
                self._invoke_adapter,
                result.target_state,
                result.source_state,
                get_invoke,
                ctx,
            )

        persist_ctx = {k: v for k, v in ctx.items() if not k.startswith("_")}
        if hasattr(store, "set_context"):
            store.set_context(entity_id, persist_ctx)

        self._machine._fire_callbacks(result, ctx)

        if self._audit_store is not None:
            transition_id = self._audit_store.record_transition(
                entity_id=entity_id,
                source_state=result.source_state,
                trigger=result.trigger,
                target_state=result.target_state,
                success=result.success,
            )
            if isinstance(transition_id, str):
                result.metadata["transition_id"] = transition_id

        self._apply_post_transition_chain(entity_id, result.target_state, ctx, store)

    async def _finalize_async_success(
        self,
        entity_id: str,
        result: TransitionResult,
        ctx: dict[str, Any],
        store: AsyncStateStore,
    ) -> None:
        """Async persist / actions / audit / post-chain for a successful transition."""
        if not result.metadata.get(MD_SKIP_APPLY_HISTORY):
            self._machine._engine.apply_history(result)
        state_changed = result.target_state != result.source_state

        if state_changed:
            if self._scheduler:
                await self._scheduler.cancel_for_entity(entity_id)

            metadata = {
                "trigger": result.trigger,
                "source_state": result.source_state,
                "target_state": result.target_state,
                **self._persist_flags(result.target_state),
            }
            if self._machine.is_parallel_state(result.target_state):
                config = self._machine.enter_parallel_state(result.target_state)
                await store.aset_state(entity_id, config.to_string(), metadata=metadata)
            else:
                await store.aset_state(
                    entity_id, result.target_state, metadata=metadata
                )

            if self._scheduler:
                await self._schedule_delayed(entity_id, result.target_state, ctx)

        if self._invoke_adapter is not None:
            get_invoke = lambda n: self._machine.get_state(n).invoke
            run_invoke_stop(
                self._invoke_adapter,
                result.source_state,
                get_invoke,
                ctx,
            )
        if result.all_action_specs:
            ctx["new_status"] = result.target_state
            await self._executor.async_execute(result, ctx)
        if self._invoke_adapter is not None:
            get_invoke = lambda n: self._machine.get_state(n).invoke
            run_invoke_start(
                self._invoke_adapter,
                result.target_state,
                result.source_state,
                get_invoke,
                ctx,
            )

        persist_ctx = {k: v for k, v in ctx.items() if not k.startswith("_")}
        if hasattr(store, "aset_context"):
            await store.aset_context(entity_id, persist_ctx)
        elif hasattr(store, "set_context"):
            store.set_context(entity_id, persist_ctx)

        await self._machine._afire_callbacks(result, ctx)

        if self._audit_store is not None:
            transition_id = self._audit_store.record_transition(
                entity_id=entity_id,
                source_state=result.source_state,
                trigger=result.trigger,
                target_state=result.target_state,
                success=result.success,
            )
            if isinstance(transition_id, str):
                result.metadata["transition_id"] = transition_id

        await self._async_apply_post_transition_chain(
            entity_id, result.target_state, ctx, store
        )

    def _detect_parallel_exit(
        self,
        config: ParallelStateConfig,
        results: list[TransitionResult],
    ) -> str | None:
        """If any result indicates a transition out of the parallel region, return that target."""
        try:
            state = self._machine.get_state(config.parallel_state)
        except Exception:
            return None
        for r in results:
            if not r.success or not r.target_state:
                continue
            region_name = r.metadata.get("region")
            if not region_name:
                continue
            region = state.get_region(region_name)
            if region and region.states and r.target_state not in region.states:
                return r.target_state
        return None

    def _process_parallel_event(
        self,
        entity_id: str,
        config: ParallelStateConfig,
        event: str | Event,
        context: dict[str, Any] | None,
        store: StateStore,
    ) -> TransitionResult:
        """Handle an event when the entity is in a parallel state."""
        ctx = dict(store.get_context(entity_id))
        if isinstance(event, Event):
            ctx.update(event.payload)
        else:
            event = Event(trigger=event)
        if context:
            ctx.update(context)
        ctx["_event"] = event
        ctx["_entity_id"] = entity_id

        if self._machine.meta.get("validate_context"):
            valid, errors = self._machine.validate_context(ctx)
            if not valid:
                return TransitionResult.failure_result(
                    source_state=config.to_string(),
                    trigger=event.trigger,
                    error=FSMError(
                        "Context validation failed",
                        context={"validation_errors": errors},
                    ),
                    metadata={"reason": "context_validation"},
                )
        if self._context_validator is not None:
            ok, val_errors = self._context_validator(
                entity_id, config.to_string(), event.trigger, ctx
            )
            if not ok:
                return TransitionResult.failure_result(
                    source_state=config.to_string(),
                    trigger=event.trigger,
                    error=FSMError(
                        f"Validation failed: {'; '.join(val_errors)}",
                        context={"validation_errors": val_errors},
                    ),
                    metadata={"reason": "context_validation"},
                )

        updated, results = self._machine.process_parallel(config, event, ctx)
        exit_state = self._detect_parallel_exit(config, results)
        if exit_state is not None:
            exit_result = next(r for r in results if r.target_state == exit_state)
            self._machine._engine.apply_history(exit_result)
            metadata = {
                "trigger": event.trigger,
                "source_state": config.to_string(),
                "target_state": exit_state,
                **self._persist_flags(exit_state),
            }
            store.set_state(entity_id, exit_state, metadata=metadata)
            if exit_result.all_action_specs:
                ctx["new_status"] = exit_state
                self._executor.execute(exit_result, ctx)
            return exit_result
        mode = parse_mode(self._machine.meta)
        fb = fallback_leaf_name(
            self._machine, self._machine._error_policy.default_fallback
        )
        primary = (
            results[0]
            if results
            else TransitionResult.no_op_result(config.to_string(), event.trigger)
        )
        if (
            mode != "off"
            and fb is not None
            and parallel_fallback_eligible(config, updated, results)
        ):
            if mode == "hint":
                primary = enrich_hint_result(
                    primary,
                    fb,
                    parallel_composite_source=config.to_string(),
                )
                store.set_state(
                    entity_id,
                    updated.to_string(),
                    metadata={
                        "trigger": event.trigger,
                        "parallel_state": updated.parallel_state,
                    },
                )
                for r in results:
                    if r.all_action_specs:
                        ctx["new_status"] = r.target_state
                        self._executor.execute(r, ctx)
                return primary
            if mode == "persist":
                orig_err = next(
                    r.error
                    for r in results
                    if r.error is not None and is_allowlisted_failure(r.error)
                )
                synthetic = build_persist_synthetic_result(
                    self._machine,
                    source_state=config.to_string(),
                    target_leaf=fb,
                    trigger=event.trigger,
                    original_error=orig_err,
                )
                self._finalize_sync_success(entity_id, synthetic, ctx, store)
                return synthetic

        store.set_state(
            entity_id,
            updated.to_string(),
            metadata={
                "trigger": event.trigger,
                "parallel_state": updated.parallel_state,
            },
        )
        for r in results:
            if r.all_action_specs:
                ctx["new_status"] = r.target_state
                self._executor.execute(r, ctx)
        return primary

    async def _process_parallel_event_async(
        self,
        entity_id: str,
        config: ParallelStateConfig,
        event: str | Event,
        context: dict[str, Any] | None,
        store: AsyncStateStore,
    ) -> TransitionResult:
        """Async: handle an event when the entity is in a parallel state."""
        ctx = dict(await store.aget_context(entity_id))
        if isinstance(event, Event):
            ctx.update(event.payload)
        else:
            event = Event(trigger=event)
        if context:
            ctx.update(context)
        ctx["_event"] = event
        ctx["_entity_id"] = entity_id

        if self._machine.meta.get("validate_context"):
            valid, errors = self._machine.validate_context(ctx)
            if not valid:
                return TransitionResult.failure_result(
                    source_state=config.to_string(),
                    trigger=event.trigger,
                    error=FSMError(
                        "Context validation failed",
                        context={"validation_errors": errors},
                    ),
                    metadata={"reason": "context_validation"},
                )
        if self._context_validator is not None:
            if inspect.iscoroutinefunction(self._context_validator):
                ok, val_errors = await self._context_validator(
                    entity_id, config.to_string(), event.trigger, ctx
                )
            else:
                ok, val_errors = self._context_validator(
                    entity_id, config.to_string(), event.trigger, ctx
                )
            if not ok:
                return TransitionResult.failure_result(
                    source_state=config.to_string(),
                    trigger=event.trigger,
                    error=FSMError(
                        f"Validation failed: {'; '.join(val_errors)}",
                        context={"validation_errors": val_errors},
                    ),
                    metadata={"reason": "context_validation"},
                )
        updated, results = await self._machine.aprocess_parallel(config, event, ctx)
        exit_state = self._detect_parallel_exit(config, results)
        if exit_state is not None:
            exit_result = next(r for r in results if r.target_state == exit_state)
            self._machine._engine.apply_history(exit_result)
            if self._scheduler:
                await self._scheduler.cancel_for_entity(entity_id)
            meta = {
                "trigger": event.trigger,
                "source_state": config.to_string(),
                "target_state": exit_state,
                **self._persist_flags(exit_state),
            }
            await store.aset_state(entity_id, exit_state, metadata=meta)
            if self._scheduler:
                await self._schedule_delayed(entity_id, exit_state, ctx)
            if exit_result.all_action_specs:
                ctx["new_status"] = exit_state
                await self._executor.async_execute(exit_result, ctx)
            return exit_result
        mode = parse_mode(self._machine.meta)
        fb = fallback_leaf_name(
            self._machine, self._machine._error_policy.default_fallback
        )
        primary = (
            results[0]
            if results
            else TransitionResult.no_op_result(config.to_string(), event.trigger)
        )
        if (
            mode != "off"
            and fb is not None
            and parallel_fallback_eligible(config, updated, results)
        ):
            if mode == "hint":
                primary = enrich_hint_result(
                    primary,
                    fb,
                    parallel_composite_source=config.to_string(),
                )
                await store.aset_state(
                    entity_id,
                    updated.to_string(),
                    metadata={
                        "trigger": event.trigger,
                        "parallel_state": updated.parallel_state,
                    },
                )
                for r in results:
                    if r.all_action_specs:
                        ctx["new_status"] = r.target_state
                        await self._executor.async_execute(r, ctx)
                return primary
            if mode == "persist":
                orig_err = next(
                    r.error
                    for r in results
                    if r.error is not None and is_allowlisted_failure(r.error)
                )
                synthetic = build_persist_synthetic_result(
                    self._machine,
                    source_state=config.to_string(),
                    target_leaf=fb,
                    trigger=event.trigger,
                    original_error=orig_err,
                )
                await self._finalize_async_success(entity_id, synthetic, ctx, store)
                return synthetic

        await store.aset_state(
            entity_id,
            updated.to_string(),
            metadata={
                "trigger": event.trigger,
                "parallel_state": updated.parallel_state,
            },
        )
        for r in results:
            if r.all_action_specs:
                ctx["new_status"] = r.target_state
                await self._executor.async_execute(r, ctx)
        return primary

    # ------------------------------------------------------------------
    # Sync API
    # ------------------------------------------------------------------

    def process_event(
        self,
        entity_id: str,
        event: str | Event,
        context: dict[str, Any] | None = None,
    ) -> TransitionResult:
        """Run the sandwich loop synchronously."""
        store = self._store
        if not isinstance(store, StateStore):
            raise TypeError(
                "process_event requires a sync StateStore "
                "(get_state, set_state, get_context)"
            )

        current_state = store.get_state(entity_id)
        if current_state is None:
            if self._use_initial:
                current_state = self._machine.get_initial_state().name
            else:
                raise ValueError(
                    f"Entity {entity_id!r} has no state and "
                    "use_initial_state_when_missing is False"
                )

        parsed = parse_stored_state(current_state, self._machine.is_parallel_state)
        if isinstance(parsed, ParallelStateConfig):
            return self._process_parallel_event(
                entity_id, parsed, event, context, store
            )

        current_state = parsed
        ctx = dict(store.get_context(entity_id))
        if isinstance(event, Event):
            ctx.update(event.payload)
        else:
            event = Event(trigger=event)
        if context:
            ctx.update(context)
        ctx["_event"] = event
        ctx["_entity_id"] = entity_id

        # Append event to event store (input, before processing)
        if self._event_store is not None:
            payload = dict(event.payload) if event.payload else None
            self._event_store.append_event(
                entity_id,
                event.trigger,
                payload=payload,
                event_id=str(event.event_id),
                source=event.source,
                machine_name=self._machine.name,
            )

        # Notify hooks: before processing
        if self._observer is not None:
            self._observer.before_process(entity_id, current_state, event.trigger, ctx)

        # Validate context if configured (inline machine validation)
        if self._machine.meta.get("validate_context"):
            valid, errors = self._machine.validate_context(ctx)
            if not valid:
                return TransitionResult.failure_result(
                    source_state=current_state,
                    trigger=event.trigger,
                    error=FSMError(
                        "Context validation failed",
                        context={"validation_errors": errors},
                    ),
                    metadata={"reason": "context_validation"},
                )

        # External context validator (e.g. PyCharter data contract validation)
        if self._context_validator is not None:
            ok, val_errors = self._context_validator(
                entity_id, current_state, event.trigger, ctx
            )
            if not ok:
                return TransitionResult.failure_result(
                    source_state=current_state,
                    trigger=event.trigger,
                    error=FSMError(
                        f"Validation failed: {'; '.join(val_errors)}",
                        context={"validation_errors": val_errors},
                    ),
                    metadata={"reason": "context_validation"},
                )

        # Notify hooks: transition starting
        if self._observer is not None:
            self._observer.before_transition(current_state, event.trigger, ctx)

        try:
            result = self._machine.process(current_state, event, ctx)
        except Exception as exc:
            if self._observer is not None:
                self._observer.on_error(exc, ctx)
            raise

        result = self._apply_scalar_default_fallback(
            current_state, event.trigger, result
        )

        if self._observer is not None:
            self._observer.after_transition(result, ctx)

        if result.success and result.target_state is not None:
            self._finalize_sync_success(entity_id, result, ctx, store)

        return result

    # ------------------------------------------------------------------
    # Async API
    # ------------------------------------------------------------------

    async def async_process_event(
        self,
        entity_id: str,
        event: str | Event,
        context: dict[str, Any] | None = None,
    ) -> TransitionResult:
        """Run the sandwich loop asynchronously."""
        store = self._store
        if not isinstance(store, AsyncStateStore):
            raise TypeError(
                "async_process_event requires an AsyncStateStore "
                "(aget_state, aset_state, aget_context)"
            )

        current_state = await store.aget_state(entity_id)
        if current_state is None:
            if self._use_initial:
                current_state = self._machine.get_initial_state().name
            else:
                raise ValueError(
                    f"Entity {entity_id!r} has no state and "
                    "use_initial_state_when_missing is False"
                )

        parsed = parse_stored_state(current_state, self._machine.is_parallel_state)
        if isinstance(parsed, ParallelStateConfig):
            return await self._process_parallel_event_async(
                entity_id, parsed, event, context, store
            )

        current_state = parsed
        ctx = dict(await store.aget_context(entity_id))
        if isinstance(event, Event):
            ctx.update(event.payload)
        else:
            event = Event(trigger=event)
        if context:
            ctx.update(context)
        ctx["_event"] = event
        ctx["_entity_id"] = entity_id

        # Append event to event store (input, before processing)
        if self._event_store is not None:
            payload = dict(event.payload) if event.payload else None
            self._event_store.append_event(
                entity_id,
                event.trigger,
                payload=payload,
                event_id=str(event.event_id),
                source=event.source,
                machine_name=self._machine.name,
            )

        # Notify hooks: before processing
        if self._observer is not None:
            self._observer.before_process(entity_id, current_state, event.trigger, ctx)

        if self._machine.meta.get("validate_context"):
            valid, errors = self._machine.validate_context(ctx)
            if not valid:
                return TransitionResult.failure_result(
                    source_state=current_state,
                    trigger=event.trigger,
                    error=FSMError(
                        "Context validation failed",
                        context={"validation_errors": errors},
                    ),
                    metadata={"reason": "context_validation"},
                )

        # External context validator (e.g. PyCharter data contract validation)
        if self._context_validator is not None:
            if inspect.iscoroutinefunction(self._context_validator):
                ok, val_errors = await self._context_validator(
                    entity_id, current_state, event.trigger, ctx
                )
            else:
                ok, val_errors = self._context_validator(
                    entity_id, current_state, event.trigger, ctx
                )
            if not ok:
                return TransitionResult.failure_result(
                    source_state=current_state,
                    trigger=event.trigger,
                    error=FSMError(
                        f"Validation failed: {'; '.join(val_errors)}",
                        context={"validation_errors": val_errors},
                    ),
                    metadata={"reason": "context_validation"},
                )

        # Notify hooks: transition starting
        if self._observer is not None:
            self._observer.before_transition(current_state, event.trigger, ctx)

        try:
            result = await self._machine.aprocess(current_state, event, ctx)
        except Exception as exc:
            if self._observer is not None:
                self._observer.on_error(exc, ctx)
            raise

        result = self._apply_scalar_default_fallback(
            current_state, event.trigger, result
        )

        if self._observer is not None:
            self._observer.after_transition(result, ctx)

        if result.success and result.target_state is not None:
            await self._finalize_async_success(entity_id, result, ctx, store)

        return result

    # ------------------------------------------------------------------
    # Post-transition chain (auto + when-route)
    # ------------------------------------------------------------------

    def _apply_post_transition_chain(
        self,
        entity_id: str,
        current_state: str,
        ctx: dict[str, Any],
        store: StateStore,
    ) -> None:
        """Run the unified auto-transition / when-route chain (sync)."""
        post_results = self._machine._engine.evaluate_post_transition(
            current_state, ctx
        )
        for pr in post_results:
            if not (pr.success and pr.target_state):
                continue
            self._machine._engine.apply_history(pr)

            md = {
                "trigger": pr.trigger,
                "source_state": pr.source_state,
                "target_state": pr.target_state,
                **self._persist_flags(pr.target_state),
            }
            store.set_state(entity_id, pr.target_state, metadata=md)

            if pr.all_action_specs:
                ctx["new_status"] = pr.target_state
                self._executor.execute(pr, ctx)

            persist_ctx = {k: v for k, v in ctx.items() if not k.startswith("_")}
            if hasattr(store, "set_context"):
                store.set_context(entity_id, persist_ctx)

            self._machine._fire_callbacks(pr, ctx)

            if self._audit_store is not None:
                self._audit_store.record_transition(
                    entity_id=entity_id,
                    source_state=pr.source_state,
                    trigger=pr.trigger,
                    target_state=pr.target_state,
                    success=pr.success,
                )

    async def _async_apply_post_transition_chain(
        self,
        entity_id: str,
        current_state: str,
        ctx: dict[str, Any],
        store: AsyncStateStore | StateStore,
    ) -> None:
        """Run the unified auto-transition / when-route chain (async)."""
        post_results = await self._machine._engine.async_evaluate_post_transition(
            current_state, ctx
        )
        for pr in post_results:
            if not (pr.success and pr.target_state):
                continue
            self._machine._engine.apply_history(pr)

            md = {
                "trigger": pr.trigger,
                "source_state": pr.source_state,
                "target_state": pr.target_state,
                **self._persist_flags(pr.target_state),
            }
            if isinstance(store, AsyncStateStore):
                await store.aset_state(entity_id, pr.target_state, metadata=md)
            else:
                store.set_state(entity_id, pr.target_state, metadata=md)

            if pr.all_action_specs:
                ctx["new_status"] = pr.target_state
                await self._executor.async_execute(pr, ctx)

            persist_ctx = {k: v for k, v in ctx.items() if not k.startswith("_")}
            if hasattr(store, "aset_context"):
                await store.aset_context(entity_id, persist_ctx)
            elif hasattr(store, "set_context"):
                store.set_context(entity_id, persist_ctx)

            await self._machine._afire_callbacks(pr, ctx)

            if self._audit_store is not None:
                self._audit_store.record_transition(
                    entity_id=entity_id,
                    source_state=pr.source_state,
                    trigger=pr.trigger,
                    target_state=pr.target_state,
                    success=pr.success,
                )

    # ------------------------------------------------------------------
    # Data-driven when-route evaluation
    # ------------------------------------------------------------------

    def apply_data(
        self,
        entity_id: str,
        data: dict[str, Any],
    ) -> list[TransitionResult]:
        """Update entity context and evaluate when-route transitions (sync).

        Loads the current state and context from the store, merges *data*,
        evaluates the post-transition chain (auto + when-routes), persists
        any resulting state changes, and returns the list of fired results.

        Requires ``classification.auto_route: true`` in the machine meta.
        """
        store = self._store
        if not isinstance(store, StateStore):
            raise TypeError("Sync apply_data requires a sync StateStore")

        current_state = store.get_state(entity_id)
        if current_state is None:
            initial = self._machine.get_initial_state()
            current_state = initial.name if initial else None
        if current_state is None:
            raise ValueError(f"No state found for entity {entity_id}")

        ctx = (
            dict(store.get_context(entity_id)) if hasattr(store, "get_context") else {}
        )
        ctx.update(data)

        results = self._machine._engine.evaluate_post_transition(current_state, ctx)
        for pr in results:
            if not (pr.success and pr.target_state):
                continue
            self._machine._engine.apply_history(pr)

            md = {
                "trigger": pr.trigger,
                "source_state": pr.source_state,
                "target_state": pr.target_state,
                **self._persist_flags(pr.target_state),
            }
            store.set_state(entity_id, pr.target_state, metadata=md)

            if pr.all_action_specs:
                ctx["new_status"] = pr.target_state
                self._executor.execute(pr, ctx)

            persist_ctx = {k: v for k, v in ctx.items() if not k.startswith("_")}
            if hasattr(store, "set_context"):
                store.set_context(entity_id, persist_ctx)

            self._machine._fire_callbacks(pr, ctx)

            if self._audit_store is not None:
                self._audit_store.record_transition(
                    entity_id=entity_id,
                    source_state=pr.source_state,
                    trigger=pr.trigger,
                    target_state=pr.target_state,
                    success=pr.success,
                )

        return results

    async def async_apply_data(
        self,
        entity_id: str,
        data: dict[str, Any],
    ) -> list[TransitionResult]:
        """Async version of :meth:`apply_data`."""
        store = self._store
        if not isinstance(store, AsyncStateStore):
            raise TypeError("async_apply_data requires an AsyncStateStore")

        current_state = await store.aget_state(entity_id)
        if current_state is None:
            initial = self._machine.get_initial_state()
            current_state = initial.name if initial else None
        if current_state is None:
            raise ValueError(f"No state found for entity {entity_id}")

        if hasattr(store, "aget_context"):
            ctx = dict(await store.aget_context(entity_id))
        elif hasattr(store, "get_context"):
            ctx = dict(store.get_context(entity_id))
        else:
            ctx = {}
        ctx.update(data)

        results = await self._machine._engine.async_evaluate_post_transition(
            current_state, ctx
        )
        for pr in results:
            if not (pr.success and pr.target_state):
                continue
            self._machine._engine.apply_history(pr)

            md = {
                "trigger": pr.trigger,
                "source_state": pr.source_state,
                "target_state": pr.target_state,
                **self._persist_flags(pr.target_state),
            }
            await store.aset_state(entity_id, pr.target_state, metadata=md)

            if pr.all_action_specs:
                ctx["new_status"] = pr.target_state
                await self._executor.async_execute(pr, ctx)

            persist_ctx = {k: v for k, v in ctx.items() if not k.startswith("_")}
            if hasattr(store, "aset_context"):
                await store.aset_context(entity_id, persist_ctx)
            elif hasattr(store, "set_context"):
                store.set_context(entity_id, persist_ctx)

            await self._machine._afire_callbacks(pr, ctx)

            if self._audit_store is not None:
                self._audit_store.record_transition(
                    entity_id=entity_id,
                    source_state=pr.source_state,
                    trigger=pr.trigger,
                    target_state=pr.target_state,
                    success=pr.success,
                )

        return results

    # ------------------------------------------------------------------
    # Delayed transition scheduling
    # ------------------------------------------------------------------

    async def _schedule_delayed(
        self, entity_id: str, state_name: str, context: dict[str, Any]
    ) -> None:
        if self._scheduler is None:
            return
        for trans in self._machine.transitions:
            if trans.is_delayed and trans.matches_source(state_name):
                ctx_copy = context.copy()

                async def _make_cb(evt: str, ctx: dict[str, Any]) -> Any:
                    async def run(_evt: str = evt, _ctx: dict[str, Any] = ctx) -> None:
                        await self.async_process_event(entity_id, _evt, _ctx)

                    return run

                cb = await _make_cb(trans.trigger, ctx_copy)
                await self._scheduler.schedule(
                    delay_ms=trans.after,  # type: ignore[arg-type]
                    callback=cb,
                    entity_id=entity_id,
                    event=trans.trigger,
                    metadata={"state": state_name},
                )

    # ------------------------------------------------------------------
    # Replay from event store
    # ------------------------------------------------------------------

    def replay(
        self,
        entity_id: str,
        *,
        up_to_sequence: int | None = None,
    ) -> list[TransitionResult]:
        """Replay an entity from the event store, returning results at each step.

        Creates a fresh in-memory EntitySession at the machine's initial state,
        then replays each persisted event in sequence order.

        Args:
            entity_id: The entity to replay.
            up_to_sequence: Stop after this sequence number (inclusive). If
                ``None``, replays all events.

        Returns:
            List of ``TransitionResult`` objects, one per replayed event.

        Raises:
            RuntimeError: If no event store is configured.
        """
        if self._event_store is None:
            raise RuntimeError("No event store configured on this orchestrator")

        limit = up_to_sequence if up_to_sequence else 10000
        events = self._event_store.get_events(entity_id, limit=limit)

        instance = self._machine.create(entity_id=entity_id)
        results: list[TransitionResult] = []
        for evt in events:
            if up_to_sequence is not None and evt["sequence"] > up_to_sequence:
                break
            payload = evt.get("payload") or {}
            result = instance.send(evt["trigger"], **payload)
            results.append(result)
        return results

    async def close(self) -> None:
        """Clean up resources (scheduler, etc.)."""
        if self._scheduler:
            await self._scheduler.close()
