'use client'

import {
  Suspense,
  useState,
  useEffect,
  useCallback,
  useRef,
  useMemo,
} from 'react'
import {
  Group,
  Panel,
  Separator,
  type PanelImperativeHandle,
} from 'react-resizable-panels'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import { ResizableWorkspaceLayout } from '@/components/layout'
import {
  useWorkspaceStore,
  selectConfig,
  selectConfigRevision,
  selectSetConfig,
  selectSyncSessionFromConfig,
  selectLastTransition,
  selectDiagramShowGuards,
  selectDiagramShowActions,
  selectDiagramShowOpsBadges,
  selectDiagramPlainNodes,
  selectDiagramHighlightState,
  selectDiagramHighlightTransition,
  selectPastLength,
  selectFutureLength,
  selectUndo,
  selectRedo,
  selectClearConfig,
  selectViewMode,
  selectSetViewMode,
} from '@/stores/workspace'
import { useToastStore } from '@/stores/toast'
import {
  WorkspaceConfigSidebar,
  type WorkspaceMainArea,
  WorkspaceTableEditor,
} from '@/components/workspace'
import { WorkspaceBuilderSidebar } from '@/components/workspace/WorkspaceBuilderSidebar'
import {
  WorkspaceDiscoveryMain,
  WorkspaceDiscoverySidebar,
} from '@/components/discovery/WorkspaceDiscoveryContext'
import { WorkspaceDiscoveryProviderGate } from '@/components/discovery/WorkspaceDiscoveryProviderGate'
import { FsmFlowDiagram, DiagramContextMenu } from '@/components/fsm-flow'
import type { DiagramContextMenuProps } from '@/components/fsm-flow'
import { WorkspaceDiagramInspector } from '@/components/workspace/inspector/WorkspaceDiagramInspector'
import { WorkspaceToolbar } from '@/components/workspace/WorkspaceToolbar'
import { WorkspaceMachinesBottomPanel } from '@/components/workspace/WorkspaceMachinesBottomPanel'
import MachineCreateModal from '@/components/machines/MachineCreateModal'
import MachineSaveModal from '@/components/machines/MachineSaveModal'
import { StateModal } from '@/components/modals/StateModal'
import { TransitionModal } from '@/components/modals/TransitionModal'
import { collectAllRegionNames } from '@/lib/fsm/regionUtils'
import type { FSMConfig } from '@/lib/types/fsm'
import { fetchApi } from '@/lib/api/client'
import {
  useWorkspaceSave,
  useStateOpsMetrics,
  useTransitionOpsMetrics,
  useWorkspaceNotes,
  useWorkspaceMachineLoader,
  useWorkspaceImportExport,
  useWorkspaceDiagramInspector,
} from '@/hooks'
import { setCollabNoteHandler, setCollabLayoutHandler, collabBroadcast } from '@/hooks/use-collab'
import type { CollabMessage } from '@/lib/collab/types'

function pct(n: number): string {
  return String(n)
}

function WorkspaceContentInner() {
  const config = useWorkspaceStore(selectConfig)
  const configRevision = useWorkspaceStore(selectConfigRevision)
  const setConfig = useWorkspaceStore(selectSetConfig)
  const syncSessionFromConfig = useWorkspaceStore(selectSyncSessionFromConfig)
  const lastTransition = useWorkspaceStore(selectLastTransition)
  const diagramShowGuards = useWorkspaceStore(selectDiagramShowGuards)
  const diagramShowActions = useWorkspaceStore(selectDiagramShowActions)
  const diagramShowOpsBadges = useWorkspaceStore(selectDiagramShowOpsBadges)
  const diagramPlainNodes = useWorkspaceStore(selectDiagramPlainNodes)
  const diagramHighlightState = useWorkspaceStore(selectDiagramHighlightState)
  const diagramHighlightTransition = useWorkspaceStore(selectDiagramHighlightTransition)
  const pastLength = useWorkspaceStore(selectPastLength)
  const futureLength = useWorkspaceStore(selectFutureLength)
  const undo = useWorkspaceStore(selectUndo)
  const redo = useWorkspaceStore(selectRedo)
  const clearConfig = useWorkspaceStore(selectClearConfig)
  const viewMode = useWorkspaceStore(selectViewMode)
  const setViewMode = useWorkspaceStore(selectSetViewMode)
  const toast = useToastStore()
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  const workspaceArea = useMemo<WorkspaceMainArea>(() => {
    const area = searchParams.get('area')
    if (area === 'discovery') return 'discovery'
    if (area === 'builder') return 'builder'
    return 'machines'
  }, [searchParams])

  const setWorkspaceArea = useCallback(
    (area: WorkspaceMainArea) => {
      const q = new URLSearchParams(searchParams.toString())
      if (area === 'machines') {
        q.delete('area')
      } else {
        q.set('area', area)
      }
      const qs = q.toString()
      router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false })
    },
    [router, pathname, searchParams]
  )

  const { status: saveStatus, save } = useWorkspaceSave(config)
  const lastSavedRef = useRef<string | null>(null)
  const [lastSavedRevision, setLastSavedRevision] = useState<number | null>(null)
  const prevSaveStatusRef = useRef(saveStatus)

  const isDirty = useMemo(() => {
    const snap = lastSavedRef.current
    if (snap === null) {
      return configRevision > 0
    }
    let matches = false
    try {
      matches = JSON.stringify(config) === snap
    } catch {
      matches = false
    }
    if (!matches) {
      return true
    }
    return lastSavedRevision !== null && configRevision !== lastSavedRevision
  }, [config, configRevision, lastSavedRevision])

  // Align last clean revision when current config matches the known server/import snapshot
  useEffect(() => {
    const snap = lastSavedRef.current
    if (snap === null) return
    try {
      if (JSON.stringify(config) === snap) {
        setLastSavedRevision(configRevision)
      }
    } catch {
      // ignore stringify failures
    }
  }, [config, configRevision])

  // Track save status transitions for toast notifications
  // NOTE: machines.refreshMachines is called in a separate effect
  // below (after the machines hook is initialised) to avoid
  // temporal dead zone issues.
  useEffect(() => {
    const prev = prevSaveStatusRef.current
    prevSaveStatusRef.current = saveStatus
    if (saveStatus.type === 'success') {
      if (prev.type === 'loading') {
        toast.success(saveStatus.message)
        lastSavedRef.current = JSON.stringify(config)
        setLastSavedRevision(configRevision)
      }
    } else if (saveStatus.type === 'error' && prev.type === 'loading') {
      toast.error(saveStatus.message)
    }
  }, [saveStatus, config, configRevision, toast])

  // --- Layout positions (separate from FSM config) ---
  const [savedPositions, setSavedPositions] = useState<
    Record<string, { x: number; y: number }>
  >({})
  const [layoutNonce, setLayoutNonce] = useState(0)

  useEffect(() => {
    const name = config?.meta?.machine_name
    if (!name) return
    const version = config.meta?.version || '1.0.0'
    console.log('[layout] loading positions for', name, version)
    fetchApi<{ positions?: Record<string, { x: number; y: number }> }>(
      `/api/v1/layouts?machine_name=${encodeURIComponent(name)}&machine_version=${encodeURIComponent(version)}`,
    )
      .then((data) => {
        console.log('[layout] loaded positions:', JSON.stringify(data.positions ?? {}))
        setSavedPositions(data.positions ?? {})
      })
      .catch((err) => {
        console.error('[layout] failed to load positions:', err)
      })
  }, [config?.meta?.machine_name, config?.meta?.version, layoutNonce])

  // --- Notes ---
  const machineNameForNotes = config.meta?.machine_name ?? ''
  const machineVersionForNotes = config.meta?.version ?? ''
  const notes = useWorkspaceNotes({
    machineName: machineNameForNotes,
    machineVersion: machineVersionForNotes,
  })

  // Register collab handler so incoming note messages update local state
  useEffect(() => {
    setCollabNoteHandler((msg: CollabMessage) => {
      const p = msg.payload as Record<string, string>
      switch (msg.type) {
        case 'NOTE_STATE_UPSERT':
          notes.applyRemoteStateNote(p.stateName, p.body)
          break
        case 'NOTE_STATE_DELETE':
          notes.applyRemoteStateNoteDelete(p.stateName)
          break
        case 'NOTE_TRANSITION_UPSERT':
          notes.applyRemoteTransitionNote(p.key, p.body)
          break
        case 'NOTE_TRANSITION_DELETE':
          notes.applyRemoteTransitionNoteDelete(p.key)
          break
      }
    })
    return () => setCollabNoteHandler(null)
  }, [notes])

  // Register collab handler for layout position updates from collaborators
  useEffect(() => {
    setCollabLayoutHandler((positions) => {
      console.log('[layout] received collab positions:', positions)
      setSavedPositions((prev) => ({ ...prev, ...positions }))
    })
    return () => setCollabLayoutHandler(null)
  }, [])

  // --- Ops metrics ---
  const opsMetricsWindowHours = 24
  const opsEnabled = diagramShowOpsBadges && (config.meta?.machine_name ?? '').trim().length > 0
  const opsMachineNameTrimmed = (config.meta?.machine_name ?? '').trim()
  const { metricsByState: opsMetricsByState, data: opsMetricsResponse } = useStateOpsMetrics({
    enabled: opsEnabled,
    machineName: opsMachineNameTrimmed,
    windowHours: opsMetricsWindowHours,
    pollMs: 15_000,
  })
  const { metricsByKey: transitionMetricsByKey } = useTransitionOpsMetrics({
    enabled: opsEnabled,
    machineName: opsMachineNameTrimmed,
    windowHours: opsMetricsWindowHours,
    pollMs: 15_000,
  })

  // --- Machine loader ---
  const machines = useWorkspaceMachineLoader({
    config,
    setConfig,
    syncSessionFromConfig,
    lastSavedRef,
  })

  // Refresh the machine list after a successful save so the version
  // dropdown shows the newly saved version.
  useEffect(() => {
    if (saveStatus.type === 'success') {
      void machines.refreshMachines()
    }
  }, [saveStatus.type, machines])

  // --- Import / Export ---
  const importExport = useWorkspaceImportExport({
    config,
    isDirty,
    setConfig,
    syncSessionFromConfig,
    lastSavedRef,
    onImportComplete: () => {
      machines.setLoadedMachineId(null)
      machines.setSelectedMachineName(null)
    },
  })

  // --- Diagram inspector + editing ---
  const diagram = useWorkspaceDiagramInspector({
    config,
    setConfig,
    syncSessionFromConfig,
    lastSavedRef,
    notesEnabled: notes.enabled,
    renameStateNote: notes.renameStateNote,
    deleteStateNotes: notes.deleteStateNotes,
  })

  const machinesToolsPanelRef = useRef<PanelImperativeHandle | null>(null)
  const [machinesToolsPanelExpanded, setMachinesToolsPanelExpanded] = useState(true)
  const focusDiagramTokenRef = useRef(0)
  const focusStateOnDiagram = useCallback(
    (stateName: string) => {
      focusDiagramTokenRef.current += 1
      diagram.setDiagramSelectRequest({
        nodeId: stateName,
        token: focusDiagramTokenRef.current,
      })
    },
    [diagram.setDiagramSelectRequest],
  )

  const toggleMachinesToolsPanel = useCallback(() => {
    const p = machinesToolsPanelRef.current
    if (!p) return
    if (p.isCollapsed()) {
      p.expand()
      setMachinesToolsPanelExpanded(true)
    } else {
      p.collapse()
      setMachinesToolsPanelExpanded(false)
    }
  }, [])

  // --- Context menu ---
  const [contextMenu, setContextMenu] = useState<DiagramContextMenuProps | null>(null)
  const [saveModalOpen, setSaveModalOpen] = useState(false)

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'z') {
        if (e.shiftKey) {
          e.preventDefault()
          redo()
        } else {
          e.preventDefault()
          undo()
        }
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 'e') {
        e.preventDefault()
        setViewMode(viewMode === 'diagram' ? 'table' : 'diagram')
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [undo, redo, viewMode, setViewMode])

  const handleSaveClick = useCallback(() => {
    setSaveModalOpen(true)
  }, [])

  const handleModalSave = useCallback(
    async (name: string, version: string) => {
      await save(name, version)
      setConfig((prev: FSMConfig) => ({
        ...prev,
        meta: { ...prev.meta, machine_name: name, version },
      }))
      setSaveModalOpen(false)
    },
    [save, setConfig],
  )

  const handleNodeDragStop = useCallback(
    async (positions: Map<string, { x: number; y: number }>) => {
      if (positions.size === 0) return
      const machineName = config?.meta?.machine_name
      const machineVersion = config?.meta?.version || '1.0.0'
      if (!machineName) return

      // Build positions object
      const posObj: Record<string, { x: number; y: number }> = {}
      for (const [name, pos] of positions) {
        posObj[name] = { x: pos.x, y: pos.y }
      }

      // Update local positions immediately for smooth UX
      setSavedPositions((prev) => ({ ...prev, ...posObj }))

      // Broadcast to collaborators so they see the move in real-time
      console.log('[layout] broadcasting positions to collab:', posObj)
      collabBroadcast({
        type: 'CONFIG_UPDATE',
        payload: {
          ...config,
          _layoutPositions: posObj,
        },
      })

      // Persist to layout API (not into FSM config)
      try {
        console.log('[layout] saving positions:', machineName, machineVersion, posObj)
        const result = await fetchApi(
          `/api/v1/layouts/${encodeURIComponent(machineName)}/${encodeURIComponent(machineVersion)}`,
          {
            method: 'PUT',
            body: JSON.stringify({ positions: posObj }),
          },
        )
        console.log('[layout] save result:', result)
      } catch (err) {
        console.error('[layout] save failed:', err)
      }
    },
    [config],
  )

  const resetLayout = useCallback(async () => {
    const machineName = config?.meta?.machine_name
    const machineVersion = config?.meta?.version || '1.0.0'
    if (!machineName) return
    try {
      await fetchApi(
        `/api/v1/layouts/${encodeURIComponent(machineName)}/${encodeURIComponent(machineVersion)}`,
        { method: 'DELETE' },
      )
      setSavedPositions({})
      setLayoutNonce((n) => n + 1)
      toast.success('Layout reset to auto-layout')
    } catch {
      toast.error('Failed to reset layout')
    }
  }, [config, toast])

  const stateNames = (config.states ?? []).map((s) => s.name)
  const regionNames = collectAllRegionNames(config.states ?? [])

  const highlightTransition =
    diagramHighlightTransition ??
    (lastTransition
      ? {
          source: lastTransition.source_state,
          target: lastTransition.target_state,
          trigger: lastTransition.trigger,
        }
      : null)

  const versionsForSelectedName = useMemo(
    () =>
      machines.selectedMachineName
        ? machines.machineList.filter(
            (m) => machines.machineDisplayPath(m) === machines.selectedMachineName,
          )
        : [],
    [machines],
  )

  const annotationsProps = useMemo(
    () => ({
      enabled: notes.enabled,
      statesWithNotes: new Set(
        Object.keys(notes.notesByState).filter(
          (k) => (notes.notesByState[k] ?? '').trim().length > 0,
        ),
      ),
      openStateName: notes.openNoteStateName,
      getBody: (stateName: string) => notes.notesByState[stateName] ?? '',
      saving: notes.noteSaving,
      deleting: notes.noteDeleting,
      machineName: machineNameForNotes,
      machineVersion: machineVersionForNotes,
      onOpen: notes.openNoteForState,
      onClose: () => notes.setOpenNoteStateName(''),
      onSave: (stateName: string, body: string) => {
        void notes.handleSaveNote(body)
        collabBroadcast({ type: 'NOTE_STATE_UPSERT', payload: { stateName, body } })
      },
      onDelete: (stateName: string) => {
        void notes.handleDeleteNote()
        collabBroadcast({ type: 'NOTE_STATE_DELETE', payload: { stateName } })
      },
    }),
    [
      notes,
      machineNameForNotes,
      machineVersionForNotes,
    ],
  )

  const transitionNotesProps = useMemo(
    () => ({
      enabled: notes.enabled,
      openKey: notes.openTransitionNoteKey,
      getBody: (k: string) => notes.notesByTransitionKey[k] ?? '',
      saving: notes.transitionNoteSaving,
      deleting: notes.transitionNoteDeleting,
      machineName: machineNameForNotes,
      machineVersion: machineVersionForNotes,
      onOpen: (k: string) => notes.setOpenTransitionNoteKey(k),
      onClose: () => notes.setOpenTransitionNoteKey(''),
      onSave: (k: string, body: string) => {
        void notes.handleSaveTransitionNote(k, body)
        collabBroadcast({ type: 'NOTE_TRANSITION_UPSERT', payload: { key: k, body } })
      },
      onDelete: (k: string) => {
        void notes.handleDeleteTransitionNote(k)
        collabBroadcast({ type: 'NOTE_TRANSITION_DELETE', payload: { key: k } })
      },
      keysWithNotes: new Set(
        Object.keys(notes.notesByTransitionKey).filter(
          (k) => (notes.notesByTransitionKey[k] ?? '').trim().length > 0,
        ),
      ),
    }),
    [
      notes,
      machineNameForNotes,
      machineVersionForNotes,
    ],
  )

  return (
    <WorkspaceDiscoveryProviderGate enabled={workspaceArea === 'discovery'}>
      <ResizableWorkspaceLayout
        groupId="workspace-layout"
        renderSidebar={(api) =>
          workspaceArea === 'discovery' ? (
            <WorkspaceDiscoverySidebar
              {...api}
              workspaceArea={workspaceArea}
              onWorkspaceAreaChange={setWorkspaceArea}
            />
          ) : workspaceArea === 'builder' ? (
            <WorkspaceBuilderSidebar
              {...api}
              workspaceArea={workspaceArea}
              onWorkspaceAreaChange={setWorkspaceArea}
              config={config}
              configRevision={configRevision}
              updateConfig={setConfig}
            />
          ) : (
            <WorkspaceConfigSidebar
              {...api}
              workspaceArea={workspaceArea}
              onWorkspaceAreaChange={setWorkspaceArea}
              machineList={machines.machineList}
              machinesLoading={machines.machinesLoading}
              machineLoadError={machines.machineLoadError}
              machines={machines.machinesForBrowse}
              selectedMachineName={machines.selectedMachineName}
              onMachineNameSelect={machines.onMachineNameSelect}
              onCreateMachineFromScratch={machines.handleCreateMachineFromScratch}
              openImportFilePicker={importExport.openImportFilePicker}
              importingConfig={importExport.importingConfig}
              onSelectStateBlock={diagram.handlePaletteStateSelect}
              onSelectTransitionBlock={diagram.handlePaletteTransitionSelect}
              onApplyTemplate={diagram.handlePaletteTemplateApply}
            />
          )
        }
      >
        <div className="relative h-full min-h-0 min-w-0 flex-1">
          {workspaceArea === 'machines' || workspaceArea === 'builder' ? (
            <div className="relative h-full min-h-0 w-full">
              <Group
                id="workspace-machines-vertical"
                orientation="vertical"
                className="flex h-full min-h-0 flex-col"
              >
                <Panel
                  id="workspace-machines-main"
                  defaultSize={pct(58)}
                  minSize={pct(28)}
                  className="min-h-0 flex flex-col"
                >
                  <div className="relative min-h-0 flex-1">
                    <input
                      ref={importExport.importInputRef}
                      type="file"
                      accept=".yaml,.yml,.json"
                      onChange={importExport.handleImportFileSelected}
                      className="hidden"
                      aria-hidden="true"
                      tabIndex={-1}
                    />
                    {viewMode === 'diagram' ? (
                      <div className="absolute inset-0">
                        <FsmFlowDiagram
                          config={config}
                          minHeight="100%"
                          showGuards={diagramShowGuards}
                          showActions={diagramShowActions}
                          plainNodes={diagramPlainNodes}
                          highlightState={diagramHighlightState}
                          highlightTransition={highlightTransition}
                          savedPositions={savedPositions}
                          resetPositionsNonce={layoutNonce}
                          onResetLayout={resetLayout}
                          editable
                          onPaneDoubleClick={diagram.handleDiagramPaneDoubleClick}
                          onPaneClick={diagram.closeDiagramInspector}
                          onNodeDoubleClick={diagram.handleDiagramNodeDoubleClick}
                          onEdgeDoubleClick={diagram.handleOpenTransitionFromLabel}
                          onEdgeTransitionPick={diagram.handleEdgeTransitionPick}
                          onConnect={diagram.handleDiagramConnect}
                          onNodesDelete={diagram.handleDiagramNodesDelete}
                          onEdgesDelete={diagram.handleDiagramEdgesDelete}
                          onNodeDragStop={handleNodeDragStop}
                          onPaletteDrop={diagram.handlePaletteDrop}
                          onDiagramSelectionChange={diagram.handleDiagramSelectionChange}
                          diagramSelectRequest={diagram.diagramSelectRequest}
                          onDiagramSelectRequestHandled={() =>
                            diagram.setDiagramSelectRequest(null)
                          }
                          clearDiagramSelectionNonce={diagram.diagramClearSelectionNonce}
                          annotations={annotationsProps}
                          opsMetrics={{
                            enabled: opsEnabled,
                            metricsByState: opsMetricsByState,
                            machineName: opsMachineNameTrimmed,
                            window: opsMetricsResponse
                              ? {
                                  start: opsMetricsResponse.window_start,
                                  end: opsMetricsResponse.window_end,
                                  hours: opsMetricsWindowHours,
                                }
                              : undefined,
                            transitionMetricsByKey: transitionMetricsByKey,
                          }}
                          transitionNotes={transitionNotesProps}
                        />
                      </div>
                    ) : (
                      <div className="absolute inset-0 overflow-hidden">
                        <WorkspaceTableEditor />
                      </div>
                    )}

                    <MachineCreateModal
                      isOpen={machines.createMachineOpen}
                      onClose={() => machines.setCreateMachineOpen(false)}
                      onSuccess={async (created) => {
                        await machines.refreshMachines()
                        if (created?.id) {
                          machines.setSelectedMachineName(created.name)
                          machines.loadMachine(created.id)
                        } else {
                          clearConfig()
                          machines.setLoadedMachineId(null)
                          machines.setSelectedMachineName(null)
                          lastSavedRef.current = null
                          setLastSavedRevision(null)
                        }
                      }}
                    />

                    <WorkspaceToolbar
                      viewMode={viewMode}
                      setViewMode={setViewMode}
                      versionsForSelectedName={versionsForSelectedName}
                      loadedMachineId={machines.loadedMachineId}
                      loadingMachine={machines.loadingMachine}
                      machinesLoading={machines.machinesLoading}
                      selectedMachineName={machines.selectedMachineName}
                      configVersion={config.meta?.version ?? ''}
                      machineLoadError={machines.machineLoadError}
                      pastLength={pastLength}
                      futureLength={futureLength}
                      undo={undo}
                      redo={redo}
                      clearConfig={clearConfig}
                      downloadCurrentConfig={importExport.downloadCurrentConfig}
                      handleSaveClick={handleSaveClick}
                      saveLoading={saveStatus.type === 'loading'}
                      isDirty={isDirty}
                      loadMachine={machines.loadMachine}
                      bottomPanelExpanded={machinesToolsPanelExpanded}
                      onToggleBottomPanel={toggleMachinesToolsPanel}
                    />

                    {contextMenu && <DiagramContextMenu {...contextMenu} />}

                    <MachineSaveModal
                      isOpen={saveModalOpen}
                      onClose={() => setSaveModalOpen(false)}
                      onSave={handleModalSave}
                      defaultName={config.meta?.machine_name ?? ''}
                      defaultVersion={config.meta?.version ?? '1.0.0'}
                    />

                    <StateModal
                      open={diagram.stateModalOpen}
                      onOpenChange={(open) => {
                        diagram.setStateModalOpen(open)
                        if (!open) diagram.clearPendingStateDrop()
                      }}
                      state={diagram.stateModalData}
                      existingStateNames={stateNames}
                      allStates={config.states ?? []}
                      onSave={diagram.handleStateSave}
                      title={diagram.stateModalMode === 'add' ? 'Add State' : 'Edit State'}
                      description={
                        diagram.stateModalMode === 'add'
                          ? 'Add a new state to the machine.'
                          : 'Edit the selected state.'
                      }
                    />

                    <TransitionModal
                      open={diagram.transitionModalOpen}
                      onOpenChange={diagram.setTransitionModalOpen}
                      transition={diagram.transitionModalData}
                      stateNames={stateNames}
                      regionNames={regionNames}
                      configStates={config.states ?? []}
                      onSave={diagram.handleTransitionSave}
                      title={
                        diagram.transitionModalMode === 'add'
                          ? 'Add Transition'
                          : 'Edit Transition'
                      }
                      description={
                        diagram.transitionModalMode === 'add'
                          ? 'Add a new transition between states.'
                          : 'Edit the selected transition.'
                      }
                    />
                  </div>
                </Panel>
                <Separator className="h-1.5 shrink-0 bg-border !cursor-ns-resize" />
                <Panel
                  id="workspace-machines-tools"
                  panelRef={machinesToolsPanelRef}
                  defaultSize={pct(42)}
                  minSize={pct(14)}
                  maxSize={pct(55)}
                  collapsible
                  collapsedSize={0}
                  className="flex min-h-0 flex-col overflow-hidden bg-background"
                  onResize={(size) => {
                    setMachinesToolsPanelExpanded(size.inPixels > 2)
                  }}
                >
                  <WorkspaceMachinesBottomPanel
                    config={config}
                    isDirty={isDirty}
                    loadedMachineId={machines.loadedMachineId}
                    selectedMachineName={machines.selectedMachineName}
                    configVersion={config.meta?.version ?? ''}
                    onFocusStateOnDiagram={focusStateOnDiagram}
                  />
                </Panel>
              </Group>
              {viewMode === 'diagram' && (
                <WorkspaceDiagramInspector
                  model={diagram.diagramInspector}
                  config={config}
                  onClose={diagram.closeDiagramInspector}
                  onStateSubmit={diagram.handleInspectorStateSave}
                  onTransitionSubmit={diagram.handleInspectorTransitionSave}
                  onActiveTransitionIndexChange={
                    diagram.handleActiveTransitionIndexChange
                  }
                />
              )}
            </div>
          ) : (
            <WorkspaceDiscoveryMain />
          )}
        </div>
      </ResizableWorkspaceLayout>
    </WorkspaceDiscoveryProviderGate>
  )
}

export default function WorkspacePage() {
  return (
    <Suspense
      fallback={
        <div className="flex h-full min-h-[200px] flex-1 items-center justify-center text-sm text-muted-foreground">
          Loading workspace…
        </div>
      }
    >
      <WorkspaceContentInner />
    </Suspense>
  )
}
