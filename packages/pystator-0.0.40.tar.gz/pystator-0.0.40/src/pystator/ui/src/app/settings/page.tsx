'use client'

import { useState } from 'react'
import { PageContainer } from '@/components/layout'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { getSettings, saveSettings, type AppSettings } from '@/lib/settings'
import {
  ApiServerCard,
  DatabaseConfigCard,
  DiscoveryConfigCard,
  DlqConfigCard,
  FsmFeaturesCard,
  ServerRuntimeOverview,
  type InlineCodeEditorPref,
} from '@/components/settings'
import { Loader2 } from 'lucide-react'
import { useAppConfigStore, selectAppName, selectVersion } from '@/stores/app-config'
import { cn } from '@/lib/utils'

const SECTION_LINKS = [
  { id: 'overview', label: 'Server runtime' },
  { id: 'browser-local', label: 'Browser' },
  { id: 'connection', label: 'API' },
  { id: 'database', label: 'Database' },
  { id: 'discovery', label: 'Discovery' },
  { id: 'dlq', label: 'DLQ' },
  { id: 'features', label: 'FSM UI' },
] as const

const navPillClass =
  'inline-flex items-center rounded-full border border-border/70 bg-muted/40 px-3 py-1 text-xs font-medium text-muted-foreground transition-colors hover:border-border hover:bg-muted hover:text-foreground'

export default function SettingsPage() {
  const appName = useAppConfigStore(selectAppName)
  const version = useAppConfigStore(selectVersion)
  const [settings, setSettings] = useState<AppSettings>(getSettings())
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)

  const handleSave = () => {
    setSaving(true)
    setMessage(null)
    try {
      saveSettings(settings)
      setMessage({
        type: 'success',
        text: 'Saved to this browser. The API URL applies on the next request; discovery, database, and DLQ values are used by test tools from this page.',
      })
    } catch (e) {
      setMessage({ type: 'error', text: String(e) })
    } finally {
      setSaving(false)
    }
  }

  return (
    <PageContainer padding="md" className="bg-muted/20">
      <div className="sticky top-0 z-30 -mx-4 mb-6 border-b border-border/70 bg-background/90 px-4 pb-4 pt-2 backdrop-blur-md sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
        <div className="mx-auto flex max-w-5xl flex-col gap-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
            <div className="min-w-0 space-y-1">
              <h1 className="text-2xl font-semibold tracking-tight">Settings</h1>
              <p className="max-w-2xl text-sm leading-relaxed text-muted-foreground">
                <span className="font-medium text-foreground">{appName}</span>
                {version ? ` · ${version}` : null}
                <span className="mx-1.5 text-border">·</span>
                <strong className="text-foreground">Server</strong> values come from the API (admins can
                patch <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">pystator.cfg</code> in
                the table below).
                <span className="mx-1.5 text-border">·</span>
                <strong className="text-foreground">Browser</strong> blocks store defaults in{' '}
                <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">localStorage</code> — use{' '}
                <strong className="text-foreground">Save browser settings</strong> after editing.
              </p>
            </div>
            <div className="flex shrink-0 flex-wrap gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => window.location.reload()}>
                Reload page
              </Button>
              <Button type="button" size="sm" onClick={handleSave} disabled={saving}>
                {saving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving…
                  </>
                ) : (
                  'Save browser settings'
                )}
              </Button>
            </div>
          </div>
          <nav className="flex flex-wrap gap-1.5" aria-label="Settings sections">
            {SECTION_LINKS.map(({ id, label }) => (
              <a key={id} href={`#${id}`} className={navPillClass}>
                {label}
              </a>
            ))}
          </nav>
        </div>
      </div>

      <div className="mx-auto max-w-5xl space-y-8 pb-10">
        {message ? (
          <Alert
            variant={message.type === 'error' ? 'destructive' : 'default'}
            className={cn(
              message.type === 'success' &&
                'border-emerald-500/40 bg-emerald-500/10 text-emerald-950 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-50',
            )}
          >
            <AlertDescription className="text-sm">{message.text}</AlertDescription>
          </Alert>
        ) : null}

        <ServerRuntimeOverview />

        <div className="h-px w-full bg-border/80" role="separator" aria-hidden />

        <section id="browser-local" className="scroll-mt-28 space-y-4">
          <div className="space-y-1">
            <h2 className="text-lg font-semibold tracking-tight">Browser-stored defaults</h2>
            <p className="max-w-3xl text-sm leading-relaxed text-muted-foreground">
              These fields map to <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">AppSettings</code>{' '}
              in <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">lib/settings.ts</code>. Every
              persisted key is editable below: API URL, database test bundle (with an on/off switch), discovery
              defaults, DLQ test bundle (with an on/off switch), and the FSM editor preference.
            </p>
          </div>

          <div className="grid gap-6 lg:grid-cols-2 lg:items-start">
            <div className="flex min-w-0 flex-col gap-6">
              <ApiServerCard
                url={settings.apiServer.url}
                onUrlChange={(url) => setSettings((s) => ({ ...s, apiServer: { ...s.apiServer, url } }))}
              />
              <DatabaseConfigCard
                enabled={settings.database.enabled}
                onEnabledChange={(enabled) =>
                  setSettings((s) => ({ ...s, database: { ...s.database, enabled } }))
                }
                connectionString={settings.database.connectionString ?? ''}
                host={settings.database.host ?? ''}
                port={settings.database.port != null ? String(settings.database.port) : ''}
                database={settings.database.database ?? ''}
                username={settings.database.username ?? ''}
                password={settings.database.password ?? ''}
                onConnectionStringChange={(v) =>
                  setSettings((s) => ({ ...s, database: { ...s.database, connectionString: v || undefined } }))
                }
                onHostChange={(v) =>
                  setSettings((s) => ({ ...s, database: { ...s.database, host: v || undefined } }))
                }
                onPortChange={(v) =>
                  setSettings((s) => ({
                    ...s,
                    database: { ...s.database, port: v ? parseInt(v, 10) : undefined },
                  }))
                }
                onDatabaseChange={(v) =>
                  setSettings((s) => ({ ...s, database: { ...s.database, database: v || undefined } }))
                }
                onUsernameChange={(v) =>
                  setSettings((s) => ({ ...s, database: { ...s.database, username: v || undefined } }))
                }
                onPasswordChange={(v) =>
                  setSettings((s) => ({ ...s, database: { ...s.database, password: v || undefined } }))
                }
              />
              <FsmFeaturesCard
                inlineCodeActionsEditor={
                  (settings.features?.inlineCodeActionsEditor ?? 'auto') as InlineCodeEditorPref
                }
                onInlineCodeActionsEditorChange={(v) =>
                  setSettings((s) => ({
                    ...s,
                    features: { ...s.features, inlineCodeActionsEditor: v },
                  }))
                }
              />
            </div>

            <div className="flex min-w-0 flex-col gap-6">
              <DiscoveryConfigCard
                backend={settings.discovery.backend}
                connectionString={settings.discovery.connectionString ?? ''}
                shadowEnabled={settings.discovery.shadowEnabled}
                minEdgeCount={String(settings.discovery.minEdgeCount)}
                minConfidence={String(settings.discovery.minConfidence)}
                driftAlertThreshold={String(settings.discovery.driftAlertThreshold)}
                driftSevereThreshold={String(settings.discovery.driftSevereThreshold)}
                driftMinSample={String(settings.discovery.driftMinSample)}
                lowSampleThreshold={String(settings.discovery.lowSampleThreshold)}
                onBackendChange={(v) =>
                  setSettings((s) => ({ ...s, discovery: { ...s.discovery, backend: v } }))
                }
                onConnectionStringChange={(v) =>
                  setSettings((s) => ({ ...s, discovery: { ...s.discovery, connectionString: v || undefined } }))
                }
                onShadowEnabledChange={(v) =>
                  setSettings((s) => ({ ...s, discovery: { ...s.discovery, shadowEnabled: v } }))
                }
                onMinEdgeCountChange={(v) =>
                  setSettings((s) => ({
                    ...s,
                    discovery: { ...s.discovery, minEdgeCount: v ? parseInt(v, 10) : 2 },
                  }))
                }
                onMinConfidenceChange={(v) =>
                  setSettings((s) => ({
                    ...s,
                    discovery: { ...s.discovery, minConfidence: v ? parseFloat(v) : 0.5 },
                  }))
                }
                onDriftAlertThresholdChange={(v) =>
                  setSettings((s) => ({
                    ...s,
                    discovery: {
                      ...s.discovery,
                      driftAlertThreshold: v ? Math.min(1, Math.max(0, parseFloat(v))) : 0.15,
                    },
                  }))
                }
                onDriftSevereThresholdChange={(v) =>
                  setSettings((s) => ({
                    ...s,
                    discovery: {
                      ...s.discovery,
                      driftSevereThreshold: v ? Math.min(1, Math.max(0, parseFloat(v))) : 0.4,
                    },
                  }))
                }
                onDriftMinSampleChange={(v) =>
                  setSettings((s) => ({
                    ...s,
                    discovery: { ...s.discovery, driftMinSample: v ? Math.max(1, parseInt(v, 10)) : 3 },
                  }))
                }
                onLowSampleThresholdChange={(v) =>
                  setSettings((s) => ({
                    ...s,
                    discovery: {
                      ...s.discovery,
                      lowSampleThreshold: v ? Math.max(1, parseInt(v, 10)) : 10,
                    },
                  }))
                }
              />
              <DlqConfigCard
                enabled={settings.dlq.enabled}
                connectionString={settings.dlq.connectionString ?? ''}
                host={settings.dlq.host ?? ''}
                port={settings.dlq.port != null ? String(settings.dlq.port) : ''}
                database={settings.dlq.database ?? ''}
                username={settings.dlq.username ?? ''}
                password={settings.dlq.password ?? ''}
                tableName={settings.dlq.tableName ?? 'dead_letter_queue'}
                onEnabledChange={(v) => setSettings((s) => ({ ...s, dlq: { ...s.dlq, enabled: v } }))}
                onConnectionStringChange={(v) =>
                  setSettings((s) => ({ ...s, dlq: { ...s.dlq, connectionString: v || undefined } }))
                }
                onHostChange={(v) => setSettings((s) => ({ ...s, dlq: { ...s.dlq, host: v || undefined } }))}
                onPortChange={(v) =>
                  setSettings((s) => ({
                    ...s,
                    dlq: { ...s.dlq, port: v ? parseInt(v, 10) : undefined },
                  }))
                }
                onDatabaseChange={(v) =>
                  setSettings((s) => ({ ...s, dlq: { ...s.dlq, database: v || undefined } }))
                }
                onUsernameChange={(v) =>
                  setSettings((s) => ({ ...s, dlq: { ...s.dlq, username: v || undefined } }))
                }
                onPasswordChange={(v) =>
                  setSettings((s) => ({ ...s, dlq: { ...s.dlq, password: v || undefined } }))
                }
                onTableNameChange={(v) =>
                  setSettings((s) => ({ ...s, dlq: { ...s.dlq, tableName: v || undefined } }))
                }
              />
            </div>
          </div>
        </section>
      </div>
    </PageContainer>
  )
}
