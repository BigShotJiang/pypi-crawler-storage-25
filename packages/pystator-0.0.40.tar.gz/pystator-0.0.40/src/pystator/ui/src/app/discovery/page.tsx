import { redirect } from 'next/navigation'
import { ROUTES } from '@/lib/constants'

/**
 * **Deprecated — legacy route only** (`LEGACY_DISCOVERY_APP_ROUTE` in `@/lib/constants`).
 *
 * Retained temporarily for bookmarks and backwards-compatible URLs. Redirects to the canonical
 * Discovery UI: {@link ROUTES.DISCOVERY}. **Do not add navigation or new links to `/discovery`** —
 * it will be removed once nothing relies on it.
 */
export default function LegacyDiscoveryRedirectPage() {
  redirect(`${ROUTES.WORKSPACE}?area=discovery`)
}
