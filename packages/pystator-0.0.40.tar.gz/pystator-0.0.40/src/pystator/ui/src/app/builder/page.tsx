'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

/**
 * Legacy /builder route — redirects to the integrated Builder mode
 * in the Workspace. The Builder is now a sidebar mode within
 * /workspace?area=builder.
 */
export default function BuilderRedirectPage() {
  const router = useRouter()
  useEffect(() => {
    router.replace('/workspace?area=builder')
  }, [router])
  return (
    <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
      Redirecting to Workspace Builder…
    </div>
  )
}
