'use client'

import { useCallback, useEffect, useState } from 'react'
import { Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { useDiscoveryConfig } from '@/hooks/useDiscoveryConfig'
import type {
  DiscoveryConnectionInstanceSummary,
  DiscoveryDraftFilterInput,
  DiscoveryInstanceSummary,
} from '@/lib/api'
import { isValidDiscoverySlug } from '@/lib/discoveryNames'
import { cn } from '@/lib/utils'
import { DiscoveryDraftCoreFields } from './DiscoveryDraftCoreFields'
import {
  DEFAULT_ENTITY_COLUMN,
  DEFAULT_OBS_CONTAINER,
  DEFAULT_STATE_COLUMN,
  isPostgresDiscoveryBackend,
  observationSourcePayload,
  supportsObservationSourceMapping,
} from './draftObservationSourceForm'
import { EMPTY_FILTER, filterHasAnyDimension } from './DiscoveryFilterBuilder'

export interface CreateDiscoveryInstanceDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** Registered discovery connections; drafts are scoped to one of these. */
  connections: DiscoveryConnectionInstanceSummary[]
  /** Prime the connection dropdown (e.g. tree selection). */
  defaultDiscoveryInstanceId: string | null
  /** Opens the register-connection dialog (e.g. stacked from the + control). */
  onRequestNewConnection: () => void
  onCreate: (args: {
    discoveryInstanceId: string
    title: string
    filter: DiscoveryDraftFilterInput | null
    minEdgeCount: number | null
    minConfidence: number | null
    observationSource: Record<string, unknown> | null
  }) => Promise<DiscoveryInstanceSummary | null>
}

/**
 * Dialog for creating a new discovery draft: pick a registered connection,
 * set the draft name slug, optional scope filter/thresholds.
 */
function connectionLabel(c: DiscoveryConnectionInstanceSummary): string {
  const t = c.title?.trim()
  const base = t || c.id.slice(0, 8)
  const ns = c.namespace?.trim()
  if (ns) return `${ns} · ${base}`
  return base
}

export function CreateDiscoveryInstanceDialog({
  open,
  onOpenChange,
  connections,
  defaultDiscoveryInstanceId,
  onRequestNewConnection,
  onCreate,
}: CreateDiscoveryInstanceDialogProps) {
  const { config } = useDiscoveryConfig()
  const defaultMinEdgeCount = String(config?.min_edge_count ?? 2)
  const defaultMinConfidence = String(config?.min_confidence ?? 0.5)

  const [discoveryInstanceId, setDiscoveryInstanceId] = useState<string>('')
  const [title, setTitle] = useState<string>('')
  const [filter, setFilter] = useState<DiscoveryDraftFilterInput>(EMPTY_FILTER)
  const [showFilter, setShowFilter] = useState<boolean>(false)
  const [showThresholds, setShowThresholds] = useState<boolean>(false)
  const [minEdgeCount, setMinEdgeCount] = useState<string>(defaultMinEdgeCount)
  const [minConfidence, setMinConfidence] = useState<string>(defaultMinConfidence)
  const [obsSchema, setObsSchema] = useState<string>('')
  const [obsContainer, setObsContainer] = useState<string>(DEFAULT_OBS_CONTAINER)
  const [entityIdColumn, setEntityIdColumn] = useState<string>(DEFAULT_ENTITY_COLUMN)
  const [stateColumn, setStateColumn] = useState<string>(DEFAULT_STATE_COLUMN)
  const [useDefaultObservationStorage, setUseDefaultObservationStorage] =
    useState<boolean>(true)
  const [submitting, setSubmitting] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!open) {
      setDiscoveryInstanceId('')
      setTitle('')
      setFilter(EMPTY_FILTER)
      setShowFilter(false)
      setShowThresholds(false)
      setMinEdgeCount(defaultMinEdgeCount)
      setMinConfidence(defaultMinConfidence)
      setObsSchema('')
      setObsContainer(DEFAULT_OBS_CONTAINER)
      setEntityIdColumn(DEFAULT_ENTITY_COLUMN)
      setStateColumn(DEFAULT_STATE_COLUMN)
      setUseDefaultObservationStorage(true)
      setError(null)
      setSubmitting(false)
    }
  }, [open, defaultMinEdgeCount, defaultMinConfidence])

  useEffect(() => {
    if (!open || connections.length === 0) return
    const preferred =
      defaultDiscoveryInstanceId &&
      connections.some((c) => c.id === defaultDiscoveryInstanceId)
        ? defaultDiscoveryInstanceId
        : connections[0].id
    setDiscoveryInstanceId((prev) => {
      if (prev && connections.some((c) => c.id === prev)) return prev
      return preferred
    })
  }, [open, connections, defaultDiscoveryInstanceId])

  const selectedConnection = connections.find((c) => c.id === discoveryInstanceId)
  const selectedBackend = selectedConnection?.backend ?? ''

  useEffect(() => {
    if (!supportsObservationSourceMapping(selectedBackend)) {
      setUseDefaultObservationStorage(true)
    }
  }, [selectedBackend])

  const titleOk = isValidDiscoverySlug(title)
  const canSubmit =
    !submitting &&
    Boolean(discoveryInstanceId) &&
    titleOk

  const handleSubmit = useCallback(async () => {
    if (!canSubmit) return
    setSubmitting(true)
    setError(null)
    try {
      const obsCustom =
        !useDefaultObservationStorage &&
        (obsContainer.trim() !== DEFAULT_OBS_CONTAINER ||
          entityIdColumn.trim() !== DEFAULT_ENTITY_COLUMN ||
          stateColumn.trim() !== DEFAULT_STATE_COLUMN ||
          (isPostgresDiscoveryBackend(selectedBackend) &&
            obsSchema.trim() !== ''))
      const obsSourceSupported = supportsObservationSourceMapping(selectedBackend)
      if (obsCustom && !obsSourceSupported) {
        setError(
          'Custom observation table or columns need a SQLite, PostgreSQL, or MongoDB discovery connection.'
        )
        setSubmitting(false)
        return
      }
      if (
        obsCustom &&
        (!obsContainer.trim() ||
          !entityIdColumn.trim() ||
          !stateColumn.trim())
      ) {
        setError(
          'Table or collection name, entity id column, and state column cannot be empty.'
        )
        setSubmitting(false)
        return
      }
      const observationSource = useDefaultObservationStorage
        ? null
        : observationSourcePayload(
            selectedBackend,
            obsContainer,
            entityIdColumn,
            stateColumn,
            obsSchema
          )
      const parsedEdge = Number(minEdgeCount)
      const parsedConf = Number(minConfidence)
      const edgeOverride =
        Number.isFinite(parsedEdge) && String(parsedEdge) !== defaultMinEdgeCount
          ? Math.max(1, Math.floor(parsedEdge))
          : null
      const confOverride =
        Number.isFinite(parsedConf) &&
        String(parsedConf) !== defaultMinConfidence
          ? Math.min(1, Math.max(0, parsedConf))
          : null
      const slug = title.trim()
      const created = await onCreate({
        discoveryInstanceId,
        title: slug,
        filter: filterHasAnyDimension(filter) ? filter : null,
        minEdgeCount: edgeOverride,
        minConfidence: confOverride,
        observationSource,
      })
      if (created) {
        onOpenChange(false)
      } else {
        setError('Failed to create draft')
      }
    } finally {
      setSubmitting(false)
    }
  }, [
    canSubmit,
    defaultMinConfidence,
    defaultMinEdgeCount,
    discoveryInstanceId,
    entityIdColumn,
    filter,
    minConfidence,
    minEdgeCount,
    obsSchema,
    obsContainer,
    onCreate,
    onOpenChange,
    selectedBackend,
    stateColumn,
    title,
    useDefaultObservationStorage,
  ])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex max-h-[90vh] max-w-md flex-col overflow-hidden gap-4">
        <DialogHeader className="shrink-0">
          <DialogTitle>New draft</DialogTitle>
          <DialogDescription>
            Pick which discovery connection stores this draft. The draft name is
            the unique slug for this draft; observation scope (which channel tags
            feed inference) is controlled under Advanced scope, not by repeating
            the draft name.
          </DialogDescription>
        </DialogHeader>

        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain pr-1">
          <div className="grid gap-3 py-0">
            <div className="space-y-1">
              <Label htmlFor="cdi-connection" className="text-xs">
                Discovery connection
              </Label>
              <div
                className={cn(
                  'flex flex-col gap-2 sm:flex-row sm:items-stretch',
                  connections.length === 0 ? 'sm:items-center' : ''
                )}
              >
                <select
                  id="cdi-connection"
                  className="flex h-9 min-w-0 flex-1 rounded-md border border-input bg-background px-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:opacity-50"
                  value={discoveryInstanceId}
                  disabled={connections.length === 0}
                  onChange={(e) => setDiscoveryInstanceId(e.target.value)}
                >
                  {connections.length === 0 ? (
                    <option value="">No connections yet</option>
                  ) : (
                    connections.map((c) => (
                      <option key={c.id} value={c.id}>
                        {connectionLabel(c)} · {c.backend}
                      </option>
                    ))
                  )}
                </select>
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  className="h-9 w-9 shrink-0"
                  title="Register a new discovery connection"
                  onClick={onRequestNewConnection}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              {connections.length === 0 ? (
                <p className="text-[11px] text-muted-foreground">
                  Add a connection with + before creating a draft.
                </p>
              ) : (
                <p className="text-[11px] text-muted-foreground">
                  Observations and builds for this draft use this registry entry.
                </p>
              )}
            </div>

            <DiscoveryDraftCoreFields
              idPrefix="cdi"
              title={title}
              onTitleChange={setTitle}
              filter={filter}
              onFilterChange={setFilter}
              showFilter={showFilter}
              onShowFilterChange={setShowFilter}
              showThresholds={showThresholds}
              onShowThresholdsChange={setShowThresholds}
              minEdgeCount={minEdgeCount}
              onMinEdgeCountChange={setMinEdgeCount}
              minConfidence={minConfidence}
              onMinConfidenceChange={setMinConfidence}
              defaultMinEdgeCount={defaultMinEdgeCount}
              defaultMinConfidence={defaultMinConfidence}
              obsSchema={obsSchema}
              onObsSchemaChange={setObsSchema}
              obsContainer={obsContainer}
              onObsContainerChange={setObsContainer}
              entityIdColumn={entityIdColumn}
              onEntityIdColumnChange={setEntityIdColumn}
              stateColumn={stateColumn}
              onStateColumnChange={setStateColumn}
              useDefaultObservationStorage={useDefaultObservationStorage}
              onUseDefaultObservationStorageChange={(v) => {
                setUseDefaultObservationStorage(v)
                if (v) {
                  setObsSchema('')
                  setObsContainer(DEFAULT_OBS_CONTAINER)
                  setEntityIdColumn(DEFAULT_ENTITY_COLUMN)
                  setStateColumn(DEFAULT_STATE_COLUMN)
                }
              }}
              selectedBackend={selectedBackend}
              error={error}
            />
          </div>
        </div>

        <DialogFooter className="shrink-0 border-t border-border/60 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
          <Button
            type="button"
            disabled={!canSubmit}
            onClick={() => void handleSubmit()}
          >
            <Plus className="mr-1.5 h-3.5 w-3.5" />
            Create draft
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
