'use client'

import { useEffect, useMemo, useState } from 'react'
import { Button } from '@/components/ui/button'
import { PromoteCandidateDialog } from '@/components/discovery/PromoteCandidateDialog'
import { DiscoveryShadowDiffCard } from '@/components/discovery/DiscoveryShadowDiffCard'
import type { UseDiscoveryWorkspaceResult } from '@/hooks/useDiscoveryWorkspace'
import { useDiscoveryBaselineMachine } from '@/hooks/useDiscoveryBaselineMachine'
import { diffFsmConfig, summarizeFsmDiffImpact } from '@/lib/fsmDiff'
import type { FSMConfig } from '@/lib/types/fsm'
import { listMachines } from '@/lib/api'
import { Eye, Loader2, Wrench } from 'lucide-react'

export interface DiscoveryReviewPanelProps {
  workspace: UseDiscoveryWorkspaceResult
  canRunScope: boolean
  canBuild: boolean
}

/**
 * Review tab: catalog baseline, shadow diffs, build, and promote — composes existing hooks only.
 */
export function DiscoveryReviewPanel({
  workspace: d,
  canRunScope,
  canBuild,
}: DiscoveryReviewPanelProps) {
  const [promoteOpen, setPromoteOpen] = useState(false)
  const [promoteTarget, setPromoteTarget] = useState<string | null>(null)
  const [catalogNames, setCatalogNames] = useState<string[]>([])

  const name = d.machineName.trim()
  const baseline = useDiscoveryBaselineMachine(d.machineName, {
    catalogMachineId: null,
  })

  useEffect(() => {
    if (!promoteOpen) return
    let cancelled = false
    void (async () => {
      try {
        const res = await listMachines()
        if (cancelled) return
        const names = Array.from(
          new Set((res.machines ?? []).map((m) => m.name).filter(Boolean))
        ).sort()
        setCatalogNames(names)
      } catch {
        /* non-fatal */
      }
    })()
    return () => {
      cancelled = true
    }
  }, [promoteOpen])

  const promoteImpact = useMemo(() => {
    if (!promoteOpen || !promoteTarget) {
      return { loading: false, summary: null as string | null, label: null as string | null }
    }
    const detailMismatch = d.detail?.version !== promoteTarget
    if (baseline.loading || d.loadingDetail || detailMismatch) {
      return { loading: true, summary: null as string | null, label: null as string | null }
    }
    if (!baseline.baselineConfig) {
      return { loading: false, summary: null as string | null, label: null as string | null }
    }
    const cfg = d.detail?.config as FSMConfig | undefined
    if (!cfg) {
      return { loading: true, summary: null as string | null, label: null as string | null }
    }
    const diff = diffFsmConfig(baseline.baselineConfig, cfg)
    return {
      loading: false,
      summary: summarizeFsmDiffImpact(diff),
      label: baseline.baselineVersion
        ? `Machines catalog · ${baseline.baselineVersion}`
        : 'Machines catalog',
    }
  }, [
    promoteOpen,
    promoteTarget,
    baseline.loading,
    baseline.baselineConfig,
    baseline.baselineVersion,
    d.loadingDetail,
    d.detail,
  ])

  const sortedBuilt = useMemo(() => {
    const next = [...d.builtCandidates]
    next.sort((a, b) => {
      const at = new Date(a.created_at).getTime()
      const bt = new Date(b.created_at).getTime()
      return bt - at
    })
    return next
  }, [d.builtCandidates])

  const editingWorkspace = Boolean(d.activeDraftId && !d.selectedVersion)

  if (!name) {
    return (
      <div className="rounded-md border border-dashed border-border/80 p-4">
        <p className="text-xs text-muted-foreground">
          Select a draft in the sidebar with a discovery machine channel to compare baselines, inspect
          shadow diffs, and ship candidates.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4 px-3 py-3">
      <section className="space-y-2" aria-labelledby="discovery-review-baseline-heading">
        <h3 id="discovery-review-baseline-heading" className="text-xs font-medium text-foreground">
          Catalog baseline
        </h3>
        {baseline.loading ? (
          <p className="text-xs text-muted-foreground">Loading baseline…</p>
        ) : baseline.error ? (
          <p className="text-xs text-destructive">{baseline.error}</p>
        ) : baseline.baselineConfig ? (
          <p className="text-xs text-muted-foreground">
            Comparing against catalog{' '}
            {baseline.baselineVersion ? (
              <span className="font-mono text-foreground">{baseline.baselineVersion}</span>
            ) : (
              'version'
            )}
            . Promotion impact uses this baseline when available.
          </p>
        ) : (
          <p className="text-xs text-muted-foreground">
            No matching machine in the catalog for this name yet — promote still works; impact summary
            may be limited.
          </p>
        )}
      </section>

      <section className="space-y-2" aria-labelledby="discovery-review-built-heading">
        <h3 id="discovery-review-built-heading" className="text-xs font-medium text-foreground">
          Built candidate
        </h3>
        {sortedBuilt.length === 0 ? (
          <p className="text-xs text-muted-foreground">
            No built versions yet. Use <strong className="font-medium">Recipes</strong> to preview and
            build, then pick a version here to promote.
          </p>
        ) : (
          <div className="flex flex-wrap items-center gap-2">
            <label htmlFor="discovery-built-select" className="sr-only">
              Select built candidate version
            </label>
            <select
              id="discovery-built-select"
              className="h-9 max-w-full min-w-[12rem] rounded-md border border-input bg-background px-2 text-xs"
              value={d.selectedVersion ?? ''}
              onChange={(e) => {
                const v = e.target.value
                d.selectVersion(v || null)
              }}
            >
              <option value="">Select a built version…</option>
              {sortedBuilt.map((c) => (
                <option key={c.version} value={c.version}>
                  {c.version}
                  {typeof c.candidate_sequence === 'number' ? ` (#${c.candidate_sequence})` : ''}
                </option>
              ))}
            </select>
            {d.loadingDetail ? (
              <Loader2 className="h-4 w-4 shrink-0 animate-spin text-muted-foreground" aria-hidden />
            ) : null}
          </div>
        )}
      </section>

      <section className="flex flex-wrap gap-2 border-b border-border/50 pb-3">
        <Button
          type="button"
          size="sm"
          variant="outline"
          className="h-8"
          disabled={!editingWorkspace || !canRunScope || d.previewLoading}
          onClick={() => void d.preview()}
          title="Run preview with current draft scope"
        >
          {d.previewLoading ? (
            <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
          ) : (
            <Eye className="mr-1.5 h-3.5 w-3.5" />
          )}
          Preview
        </Button>
        <Button
          type="button"
          size="sm"
          className="h-8"
          disabled={!editingWorkspace || !canBuild || d.building}
          onClick={() => void d.build()}
          title="Build a versioned candidate from the current draft"
        >
          {d.building ? (
            <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
          ) : (
            <Wrench className="mr-1.5 h-3.5 w-3.5" />
          )}
          Build candidate
        </Button>
        <Button
          type="button"
          size="sm"
          variant="secondary"
          className="h-8"
          disabled={!d.selectedVersion || d.promoting}
          onClick={() => {
            if (!d.selectedVersion) return
            setPromoteTarget(d.selectedVersion)
            setPromoteOpen(true)
          }}
        >
          Promote…
        </Button>
      </section>

      <section aria-labelledby="discovery-review-shadow-heading">
        <h3 id="discovery-review-shadow-heading" className="mb-2 text-xs font-medium text-foreground">
          Shadow diffs
        </h3>
        <DiscoveryShadowDiffCard
          machineName={name}
          loadingShadow={d.loadingShadow}
          shadowDiffs={d.shadowDiffs}
          onRefresh={() => void d.loadShadow()}
          availableMachineNames={d.availableMachineNames}
          baselineMachineName={d.baselineMachineName}
          onBaselineChange={d.setBaselineMachineName}
          onCompareBaseline={() => void d.compareAgainstBaseline()}
          comparingBaseline={d.comparingBaseline}
        />
      </section>

      <PromoteCandidateDialog
        open={promoteOpen}
        onOpenChange={(open) => {
          setPromoteOpen(open)
          if (!open) setPromoteTarget(null)
        }}
        machineName={name}
        version={promoteTarget}
        loading={d.promoting}
        catalogNames={catalogNames}
        showCatalogImpact
        impactLoading={promoteImpact.loading}
        impactSummary={promoteImpact.summary}
        impactBaselineLabel={promoteImpact.label}
        onConfirm={async (targetMachineName) => {
          if (!promoteTarget) return
          try {
            await d.promote(promoteTarget, { targetMachineName })
            setPromoteOpen(false)
            setPromoteTarget(null)
          } catch {
            /* surfaced in workspace */
          }
        }}
      />
    </div>
  )
}
