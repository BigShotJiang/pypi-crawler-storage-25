'use client'

import { useCallback, useEffect, useState } from 'react'
import { CheckCircle2, Loader2, XCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  getApiErrorMessage,
  patchDiscoveryConnectionInstance,
  testDiscoveryDatabase,
  type DiscoveryConnectionInstanceSummary,
  type DiscoveryDatabaseTestResponse,
} from '@/lib/api'
import { cn } from '@/lib/utils'
import {
  discoveryNamespaceHint,
  discoverySlugHint,
  isValidDiscoveryNamespace,
  isValidDiscoverySlug,
} from '@/lib/discoveryNames'

const BACKENDS = [
  { value: 'sqlite', label: 'SQLite' },
  { value: 'postgres', label: 'PostgreSQL' },
  { value: 'mongodb', label: 'MongoDB' },
  { value: 'redis', label: 'Redis' },
  { value: 'memory', label: 'Memory' },
] as const

function registryBackendToSelectValue(b: string): string {
  const x = (b ?? '').toLowerCase()
  return x === 'postgresql' ? 'postgres' : x
}

export function DiscoveryConnectionPropertiesDialog({
  open,
  onOpenChange,
  connection,
  onSaved,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  connection: DiscoveryConnectionInstanceSummary | null
  /** Called after a successful PATCH so the parent can refresh lists. */
  onSaved?: (updated: DiscoveryConnectionInstanceSummary) => void
}) {
  const [title, setTitle] = useState('')
  const [baselineTitle, setBaselineTitle] = useState('')
  const [namespace, setNamespace] = useState('')
  const [baselineNamespace, setBaselineNamespace] = useState('')
  const [backend, setBackend] = useState<string>('sqlite')
  const [baselineBackend, setBaselineBackend] = useState<string>('sqlite')
  const [connectionDraft, setConnectionDraft] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [testLoading, setTestLoading] = useState(false)
  const [testResult, setTestResult] = useState<DiscoveryDatabaseTestResponse | null>(
    null
  )

  useEffect(() => {
    if (!open || !connection) return
    const t = connection.title?.trim() ?? ''
    const b = registryBackendToSelectValue(connection.backend)
    setTitle(connection.title ?? '')
    setBaselineTitle(t)
    const ns = connection.namespace?.trim() ?? ''
    setNamespace(connection.namespace ?? '')
    setBaselineNamespace(ns)
    setBackend(b)
    setBaselineBackend(b)
    setConnectionDraft('')
    setError(null)
    setSubmitting(false)
    setTestLoading(false)
    setTestResult(null)
  }, [open, connection])

  useEffect(() => {
    setTestResult(null)
  }, [backend, connectionDraft])

  const trimmedTitle = title.trim()
  const trimmedNs = namespace.trim()
  const connTrim = connectionDraft.trim()
  const titleDirty = trimmedTitle !== baselineTitle
  const namespaceDirty = trimmedNs !== baselineNamespace
  const backendDirty = backend !== baselineBackend
  const connDirty = connTrim.length > 0
  const dirty = titleDirty || namespaceDirty || backendDirty || connDirty

  const titleOk =
    !titleDirty || (trimmedTitle.length > 0 && isValidDiscoverySlug(trimmedTitle))
  const namespaceOk = isValidDiscoveryNamespace(namespace)

  const switchingFromMemoryToPersistent =
    backendDirty && baselineBackend === 'memory' && backend !== 'memory'
  const needsConnForSwitch = switchingFromMemoryToPersistent && !connTrim

  const canTestConnection =
    !testLoading &&
    !submitting &&
    (backend === 'memory' || connTrim.length > 0)

  const handleTestConnection = useCallback(async () => {
    if (!canTestConnection) return
    setTestLoading(true)
    setTestResult(null)
    setError(null)
    try {
      const res = await testDiscoveryDatabase({
        backend,
        connection_string: connTrim.length > 0 ? connTrim : undefined,
      })
      setTestResult(res)
    } catch (e) {
      setTestResult({
        success: false,
        message: getApiErrorMessage(e, 'Connection test failed'),
      })
    } finally {
      setTestLoading(false)
    }
  }, [backend, canTestConnection, connTrim])

  const handleSave = useCallback(async () => {
    if (
      !connection ||
      !dirty ||
      submitting ||
      !titleOk ||
      !namespaceOk ||
      needsConnForSwitch
    )
      return
    setSubmitting(true)
    setError(null)
    try {
      const body: {
        title?: string | null
        namespace?: string | null
        backend?: string
        connection_string?: string
      } = {}
      if (titleDirty) {
        body.title = trimmedTitle.length > 0 ? trimmedTitle : null
      }
      if (namespaceDirty) {
        body.namespace = trimmedNs.length > 0 ? trimmedNs : null
      }
      if (backendDirty) {
        body.backend = backend
      }
      if (connDirty) {
        body.connection_string = connTrim
      }
      if (Object.keys(body).length === 0) {
        setSubmitting(false)
        return
      }
      const updated = await patchDiscoveryConnectionInstance(connection.id, body)
      const nt = updated.title?.trim() ?? ''
      const nb = registryBackendToSelectValue(updated.backend)
      setTitle(updated.title ?? '')
      setBaselineTitle(nt)
      const uns = updated.namespace?.trim() ?? ''
      setNamespace(updated.namespace ?? '')
      setBaselineNamespace(uns)
      setBackend(nb)
      setBaselineBackend(nb)
      setConnectionDraft('')
      onSaved?.(updated)
      onOpenChange(false)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to save connection'))
    } finally {
      setSubmitting(false)
    }
  }, [
    backend,
    backendDirty,
    baselineBackend,
    connDirty,
    connTrim,
    connection,
    dirty,
    namespaceDirty,
    namespaceOk,
    trimmedNs,
    needsConnForSwitch,
    onOpenChange,
    onSaved,
    submitting,
    titleDirty,
    titleOk,
    trimmedTitle,
  ])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Connection properties</DialogTitle>
          <DialogDescription>
            Change the title, namespace (sidebar folders), backend, or connection
            string. The API never returns the raw secret; enter a full URL here
            only when you want to replace what is stored.
          </DialogDescription>
        </DialogHeader>
        {connection ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="dcp-title" className="text-xs">
                Title
              </Label>
              <Input
                id="dcp-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Connection title"
                className="h-9 font-mono text-sm"
                disabled={submitting}
                aria-invalid={title.length > 0 && !isValidDiscoverySlug(trimmedTitle)}
              />
              <p className="text-[11px] text-muted-foreground">
                {discoverySlugHint()}
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="dcp-namespace" className="text-xs">
                Namespace (optional)
              </Label>
              <Input
                id="dcp-namespace"
                value={namespace}
                onChange={(e) => setNamespace(e.target.value)}
                placeholder="team_a/prod"
                className="h-9 font-mono text-sm"
                disabled={submitting}
                aria-invalid={namespace.length > 0 && !namespaceOk}
              />
              <p className="text-[11px] text-muted-foreground">
                {discoveryNamespaceHint()} Clear the field and save to remove
                from folders.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="dcp-backend" className="text-xs">
                Backend
              </Label>
              <select
                id="dcp-backend"
                className="flex h-9 w-full rounded-md border border-input bg-background px-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:opacity-50"
                value={backend}
                onChange={(e) => setBackend(e.target.value)}
                disabled={submitting}
              >
                {BACKENDS.map((b) => (
                  <option key={b.value} value={b.value}>
                    {b.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <Label htmlFor="dcp-conn" className="text-xs">
                  Connection string
                </Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="h-8 shrink-0 text-xs"
                  disabled={!canTestConnection}
                  onClick={() => void handleTestConnection()}
                >
                  {testLoading ? (
                    <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                  ) : null}
                  Test connection
                </Button>
              </div>
              <Input
                id="dcp-conn"
                placeholder="Leave blank to keep current; enter full URL to replace"
                value={connectionDraft}
                onChange={(e) => setConnectionDraft(e.target.value)}
                autoComplete="off"
                disabled={submitting}
              />
              <p className="text-[11px] text-muted-foreground">
                Current value (masked):{' '}
                <span className="break-all font-mono">
                  {connection.connection_string_masked || '—'}
                </span>
              </p>
              {testResult ? (
                <div
                  className={cn(
                    'flex items-start gap-2 rounded-md border px-2.5 py-2 text-xs',
                    testResult.success
                      ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-900 dark:text-emerald-100'
                      : 'border-destructive/40 bg-destructive/10 text-destructive'
                  )}
                  role="status"
                >
                  {testResult.success ? (
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
                  ) : (
                    <XCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  )}
                  <span className="min-w-0 break-words">{testResult.message}</span>
                </div>
              ) : null}
            </div>

            <div className="space-y-2 rounded-md border border-border/60 bg-muted/20 px-3 py-2 text-xs text-muted-foreground">
              <div className="break-all font-mono text-[11px]">ID · {connection.id}</div>
              <div className="grid grid-cols-2 gap-2 pt-1">
                <div>
                  <span className="block text-[10px] uppercase tracking-wide">
                    Created
                  </span>
                  {connection.created_at ?? '—'}
                </div>
                <div>
                  <span className="block text-[10px] uppercase tracking-wide">
                    Updated
                  </span>
                  {connection.updated_at ?? '—'}
                </div>
              </div>
            </div>

            {needsConnForSwitch ? (
              <p className="text-xs text-destructive">
                Enter a connection string when switching from memory to a persistent
                backend.
              </p>
            ) : null}
            {error ? (
              <p className="text-xs text-destructive">{error}</p>
            ) : null}
          </div>
        ) : null}

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={submitting}
          >
            Cancel
          </Button>
          <Button
            type="button"
            disabled={
              !connection ||
              !dirty ||
              !titleOk ||
              needsConnForSwitch ||
              submitting
            }
            onClick={() => void handleSave()}
          >
            {submitting ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : null}
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
