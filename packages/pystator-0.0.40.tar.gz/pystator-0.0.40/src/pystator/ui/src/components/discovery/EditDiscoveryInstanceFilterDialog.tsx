'use client'

import { useCallback, useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { useDiscoveryConfig } from '@/hooks/useDiscoveryConfig'
import type { DiscoveryDraftFilterInput, DiscoveryInstanceSummary } from '@/lib/api'
import { isValidDiscoverySlug } from '@/lib/discoveryNames'
import { DiscoveryDraftCoreFields } from './DiscoveryDraftCoreFields'
import {
  DEFAULT_ENTITY_COLUMN,
  DEFAULT_OBS_CONTAINER,
  DEFAULT_STATE_COLUMN,
  isPostgresDiscoveryBackend,
  observationSourceDictToFormFields,
  observationSourcePayload,
  supportsObservationSourceMapping,
} from './draftObservationSourceForm'
import { EMPTY_FILTER, filterHasAnyDimension } from './DiscoveryFilterBuilder'

export interface EditDiscoveryInstanceFilterDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  draft: DiscoveryInstanceSummary | null
  /** Backend of the discovery connection that owns this draft (``instance_id``). */
  connectionBackend: string
  onSave: (args: {
    title: string
    filter: DiscoveryDraftFilterInput | null
    minEdgeCount: number
    minConfidence: number
    observationSourceAction: 'omit' | 'clear' | 'set'
    observationSource?: Record<string, unknown> | null
  }) => Promise<boolean>
}

/**
 * Edit draft properties using the same fields as the create-draft dialog
 * (name, observation source, scope filter, inference thresholds).
 */
export function EditDiscoveryInstanceFilterDialog({
  open,
  onOpenChange,
  draft,
  connectionBackend,
  onSave,
}: EditDiscoveryInstanceFilterDialogProps) {
  const { config } = useDiscoveryConfig()
  const defaultMinEdgeCount = String(config?.min_edge_count ?? 2)
  const defaultMinConfidence = String(config?.min_confidence ?? 0.5)

  const [title, setTitle] = useState<string>('')
  const [filter, setFilter] = useState<DiscoveryDraftFilterInput>(EMPTY_FILTER)
  const [showFilter, setShowFilter] = useState<boolean>(false)
  const [showThresholds, setShowThresholds] = useState<boolean>(false)
  const [minEdgeCount, setMinEdgeCount] = useState<string>(defaultMinEdgeCount)
  const [minConfidence, setMinConfidence] = useState<string>(defaultMinConfidence)
  const [obsSchema, setObsSchema] = useState<string>('')
  const [obsContainer, setObsContainer] = useState<string>(DEFAULT_OBS_CONTAINER)
  const [entityIdColumn, setEntityIdColumn] = useState<string>(DEFAULT_ENTITY_COLUMN)
  const [stateColumn, setStateColumn] = useState<string>(DEFAULT_STATE_COLUMN)
  const [useDefaultObservationStorage, setUseDefaultObservationStorage] =
    useState<boolean>(true)
  const [initialHadCustomObs, setInitialHadCustomObs] = useState<boolean>(false)
  const [submitting, setSubmitting] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!open || !draft) return
    const slug = (draft.title ?? draft.catalog_slug ?? '').trim()
    setTitle(slug)
    setFilter(draft.filter ?? EMPTY_FILTER)
    const hasFilter = filterHasAnyDimension(draft.filter ?? EMPTY_FILTER)
    setShowFilter(hasFilter)
    const mec = String(draft.min_edge_count ?? defaultMinEdgeCount)
    const mcf = String(draft.min_confidence ?? defaultMinConfidence)
    setMinEdgeCount(mec)
    setMinConfidence(mcf)
    const thrOpen =
      mec !== defaultMinEdgeCount || mcf !== defaultMinConfidence
    setShowThresholds(thrOpen)
    const obsFields = observationSourceDictToFormFields(
      draft.observation_source ?? null,
      connectionBackend
    )
    setObsSchema(obsFields.obsSchema)
    setObsContainer(obsFields.obsContainer)
    setEntityIdColumn(obsFields.entityIdColumn)
    setStateColumn(obsFields.stateColumn)
    const custom =
      observationSourcePayload(
        connectionBackend,
        obsFields.obsContainer,
        obsFields.entityIdColumn,
        obsFields.stateColumn,
        obsFields.obsSchema
      ) !== null
    setUseDefaultObservationStorage(!custom)
    setInitialHadCustomObs(custom)
    setError(null)
    setSubmitting(false)
  }, [open, draft, connectionBackend, defaultMinEdgeCount, defaultMinConfidence])

  const titleOk = isValidDiscoverySlug(title)
  const canSubmit = !submitting && Boolean(draft) && titleOk

  const handleSave = useCallback(async () => {
    if (!draft || !canSubmit) return
    setSubmitting(true)
    setError(null)
    try {
      const obsCustom =
        !useDefaultObservationStorage &&
        (obsContainer.trim() !== DEFAULT_OBS_CONTAINER ||
          entityIdColumn.trim() !== DEFAULT_ENTITY_COLUMN ||
          stateColumn.trim() !== DEFAULT_STATE_COLUMN ||
          (isPostgresDiscoveryBackend(connectionBackend) &&
            obsSchema.trim() !== ''))
      const obsOk = supportsObservationSourceMapping(connectionBackend)
      if (obsCustom && !obsOk) {
        setError(
          'Custom observation table or columns need a SQLite, PostgreSQL, or MongoDB discovery connection.'
        )
        setSubmitting(false)
        return
      }
      if (
        obsCustom &&
        (!obsContainer.trim() ||
          !entityIdColumn.trim() ||
          !stateColumn.trim())
      ) {
        setError(
          'Table or collection name, entity id column, and state column cannot be empty.'
        )
        setSubmitting(false)
        return
      }
      const parsedEdge = Number(minEdgeCount)
      const parsedConf = Number(minConfidence)
      if (!Number.isFinite(parsedEdge) || parsedEdge < 1) {
        setError('Min edge count must be a number ≥ 1.')
        setSubmitting(false)
        return
      }
      if (
        !Number.isFinite(parsedConf) ||
        parsedConf < 0 ||
        parsedConf > 1
      ) {
        setError('Min confidence must be between 0 and 1.')
        setSubmitting(false)
        return
      }
      const desiredPayload = useDefaultObservationStorage
        ? null
        : observationSourcePayload(
            connectionBackend,
            obsContainer,
            entityIdColumn,
            stateColumn,
            obsSchema
          )
      let observationSourceAction: 'omit' | 'clear' | 'set' = 'omit'
      let observationSource: Record<string, unknown> | null | undefined
      if (desiredPayload === null && initialHadCustomObs) {
        observationSourceAction = 'clear'
      } else if (desiredPayload !== null) {
        observationSourceAction = 'set'
        observationSource = desiredPayload
      }
      const ok = await onSave({
        title: title.trim(),
        filter: filterHasAnyDimension(filter) ? filter : null,
        minEdgeCount: Math.max(1, Math.floor(parsedEdge)),
        minConfidence: Math.min(1, Math.max(0, parsedConf)),
        observationSourceAction,
        observationSource,
      })
      if (ok) {
        onOpenChange(false)
      } else {
        setError('Failed to save draft')
      }
    } finally {
      setSubmitting(false)
    }
  }, [
    canSubmit,
    connectionBackend,
    draft,
    entityIdColumn,
    filter,
    initialHadCustomObs,
    minConfidence,
    minEdgeCount,
    obsSchema,
    obsContainer,
    onOpenChange,
    onSave,
    stateColumn,
    title,
    useDefaultObservationStorage,
  ])

  const displayTitle = draft?.title?.trim() || draft?.catalog_slug || 'Draft'

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex max-h-[90vh] max-w-md flex-col overflow-hidden gap-4">
        <DialogHeader className="shrink-0">
          <DialogTitle>Edit draft · {displayTitle}</DialogTitle>
          <DialogDescription>
            Same settings as when creating a draft: name, optional custom
            observation storage, scope filter, and inference thresholds. Preview
            and build use this configuration.
          </DialogDescription>
        </DialogHeader>

        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain pr-1">
          {draft ? (
            <DiscoveryDraftCoreFields
              idPrefix="edit-draft"
              title={title}
              onTitleChange={setTitle}
              filter={filter}
              onFilterChange={setFilter}
              showFilter={showFilter}
              onShowFilterChange={setShowFilter}
              showThresholds={showThresholds}
              onShowThresholdsChange={setShowThresholds}
              minEdgeCount={minEdgeCount}
              onMinEdgeCountChange={setMinEdgeCount}
              minConfidence={minConfidence}
              onMinConfidenceChange={setMinConfidence}
              defaultMinEdgeCount={defaultMinEdgeCount}
              defaultMinConfidence={defaultMinConfidence}
              obsSchema={obsSchema}
              onObsSchemaChange={setObsSchema}
              obsContainer={obsContainer}
              onObsContainerChange={setObsContainer}
              entityIdColumn={entityIdColumn}
              onEntityIdColumnChange={setEntityIdColumn}
              stateColumn={stateColumn}
              onStateColumnChange={setStateColumn}
              useDefaultObservationStorage={useDefaultObservationStorage}
              onUseDefaultObservationStorageChange={(v) => {
                setUseDefaultObservationStorage(v)
                if (v) {
                  setObsSchema('')
                  setObsContainer(DEFAULT_OBS_CONTAINER)
                  setEntityIdColumn(DEFAULT_ENTITY_COLUMN)
                  setStateColumn(DEFAULT_STATE_COLUMN)
                }
              }}
              selectedBackend={connectionBackend}
              error={error}
            />
          ) : null}
        </div>

        <DialogFooter className="shrink-0 border-t border-border/60 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
          <Button
            type="button"
            disabled={!canSubmit}
            onClick={() => void handleSave()}
          >
            Save changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
