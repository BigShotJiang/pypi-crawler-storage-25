'use client'

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import { CreateDiscoveryInstanceDialog } from '@/components/discovery/CreateDiscoveryInstanceDialog'
import { CreateDiscoveryConnectionDialog } from '@/components/discovery/CreateDiscoveryConnectionDialog'
import { DiscoveryConnectionPropertiesDialog } from '@/components/discovery/DiscoveryConnectionPropertiesDialog'
import { DiscoveryTreeSidebar } from '@/components/discovery/DiscoveryTreeSidebar'
import { DiscoveryWorkspace } from '@/components/discovery/DiscoveryWorkspace'
import { EditDiscoveryInstanceFilterDialog } from '@/components/discovery/EditDiscoveryInstanceFilterDialog'
import {
  type DiscoveryConnectionMenuAction,
  type DiscoveryConnectionMenuPayload,
  type DiscoveryDraftMenuAction,
  type DiscoveryDraftMenuPayload,
} from '@/components/discovery/DiscoveryFileTreeNode'
import { useDiscoveryConnectionInstances } from '@/hooks/useDiscoveryConnectionInstances'
import { useDiscoveryInstances } from '@/hooks/useDiscoveryInstances'
import { useDiscoveryWorkspace } from '@/hooks/useDiscoveryWorkspace'
import {
  createDiscoveryDraft,
  deleteDiscoveryConnectionInstance,
  deleteDiscoveryDraft,
  getApiErrorMessage,
  listDiscoveryInstances,
  type DiscoveryConnectionInstanceSummary,
  type DiscoveryDraftFilterInput,
  type DiscoveryInstanceSummary,
} from '@/lib/api'
import { useToastStore } from '@/stores/toast'
import { buildDiscoveryTree } from '@/stores/discovery-browse'
import type { SidebarLayoutApi } from '@/components/layout/ResizableWorkspaceLayout'
import type { WorkspaceMainArea } from '@/components/workspace/WorkspaceMainAreaToggle'

export const DISCOVERY_FOCUSED_INSTANCE_KEY = 'pystator_discovery_focused_instance_id'
export const DISCOVERY_SELECTED_CONNECTION_KEY = 'pystator_discovery_selected_connection_id'

type WorkspaceDiscoveryContextValue = ReturnType<typeof useWorkspaceDiscoveryValue>

function useWorkspaceDiscoveryValue() {
  const toastError = useToastStore((s) => s.error)
  const connectionsHook = useDiscoveryConnectionInstances()
  const [selectedConnectionId, setSelectedConnectionId] = useState<string | null>(null)
  const instancesHook = useDiscoveryInstances({
    discoveryInstanceId: selectedConnectionId ?? undefined,
    enabled: selectedConnectionId != null,
  })
  const workspace = useDiscoveryWorkspace(selectedConnectionId)
  const [focusedInstanceId, setFocusedInstanceId] = useState<string | null>(null)
  const [createOpen, setCreateOpen] = useState<boolean>(false)
  const [connectionDialogOpen, setConnectionDialogOpen] = useState(false)
  const [editFilterTarget, setEditFilterTarget] =
    useState<DiscoveryInstanceSummary | null>(null)
  const [connectionProperties, setConnectionProperties] =
    useState<DiscoveryConnectionInstanceSummary | null>(null)

  const [draftsByInstance, setDraftsByInstance] = useState<
    Map<string, DiscoveryInstanceSummary[]>
  >(new Map())
  const [draftsLoading, setDraftsLoading] = useState(false)

  const loadAllDrafts = useCallback(async () => {
    const conns = connectionsHook.connections
    if (!conns.length) {
      setDraftsByInstance(new Map())
      return
    }
    setDraftsLoading(true)
    try {
      const entries = await Promise.all(
        conns.map(async (c) => {
          try {
            const res = await listDiscoveryInstances({
              discovery_instance_id: c.id,
              limit: 200,
            })
            return [c.id, res.items] as [string, DiscoveryInstanceSummary[]]
          } catch {
            return [c.id, [] as DiscoveryInstanceSummary[]] as [
              string,
              DiscoveryInstanceSummary[],
            ]
          }
        })
      )
      setDraftsByInstance(new Map(entries))
    } finally {
      setDraftsLoading(false)
    }
  }, [connectionsHook.connections])

  useEffect(() => {
    void loadAllDrafts()
  }, [loadAllDrafts])

  const treeNodes = useMemo(
    () => buildDiscoveryTree(connectionsHook.connections, draftsByInstance),
    [connectionsHook.connections, draftsByInstance]
  )

  const focusedInstance = useMemo<DiscoveryInstanceSummary | null>(() => {
    if (!focusedInstanceId) return null
    return (
      instancesHook.instances.find((i) => i.id === focusedInstanceId) ?? null
    )
  }, [focusedInstanceId, instancesHook.instances])

  const editDraftConnectionBackend = useMemo(() => {
    if (!editFilterTarget) return ''
    return (
      connectionsHook.connections.find((c) => c.id === editFilterTarget.instance_id)
        ?.backend ?? ''
    )
  }, [editFilterTarget, connectionsHook.connections])

  const handleSelectDraft = useCallback(
    (args: { draftId: string; homeChannel: string; instanceId: string }) => {
      setSelectedConnectionId(args.instanceId)
      setFocusedInstanceId(args.draftId)
      void workspace.focusInstance(args.draftId, args.homeChannel, args.instanceId)
    },
    [workspace]
  )

  const handleAfterObservation = useCallback(() => {
    void workspace.refreshAvailableMachines()
    void instancesHook.refresh()
    void connectionsHook.refresh()
    void loadAllDrafts()
  }, [workspace, instancesHook, connectionsHook, loadAllDrafts])

  const handleCreate = useCallback(
    async (args: {
      discoveryInstanceId: string
      title: string
      filter: DiscoveryDraftFilterInput | null
      minEdgeCount: number | null
      minConfidence: number | null
      observationSource: Record<string, unknown> | null
    }): Promise<DiscoveryInstanceSummary | null> => {
      try {
        const created = await createDiscoveryDraft(
          {
            title: args.title.trim(),
            filter: args.filter ?? null,
            min_edge_count: args.minEdgeCount ?? null,
            min_confidence: args.minConfidence ?? null,
            observation_source: args.observationSource ?? null,
          },
          args.discoveryInstanceId
        )
        setSelectedConnectionId(args.discoveryInstanceId)
        setFocusedInstanceId(created.id)
        void workspace.focusInstance(
          created.id,
          created.title ?? '',
          created.instance_id
        )
        void loadAllDrafts()
        return {
          id: created.id,
          instance_id: created.instance_id,
          catalog_slug: created.title ?? '',
          title: created.title,
          filter: created.filter ?? null,
          filter_summary: created.filter ? 'custom filter' : 'all channels',
          min_edge_count: created.min_edge_count,
          min_confidence: created.min_confidence,
          observation_source: created.observation_source ?? null,
          built_count: 0,
          last_built_version: null,
          created_at: created.created_at,
          updated_at: created.updated_at,
        }
      } catch {
        return null
      }
    },
    [workspace, loadAllDrafts]
  )

  const handleOpenEditFilterDialog = useCallback(
    (instance: DiscoveryInstanceSummary) => {
      setEditFilterTarget(instance)
    },
    []
  )

  const handleSaveDraft = useCallback(
    async (args: {
      title: string
      filter: DiscoveryDraftFilterInput | null
      minEdgeCount: number
      minConfidence: number
      observationSourceAction: 'omit' | 'clear' | 'set'
      observationSource?: Record<string, unknown> | null
    }): Promise<boolean> => {
      if (!editFilterTarget) return false
      const updated = await instancesHook.updateDraft({
        id: editFilterTarget.id,
        title: args.title,
        filter: args.filter,
        minEdgeCount: args.minEdgeCount,
        minConfidence: args.minConfidence,
        observationSourceAction: args.observationSourceAction,
        observationSource: args.observationSource,
      })
      if (!updated) return false
      if (focusedInstanceId === editFilterTarget.id) {
        void workspace.focusInstance(
          editFilterTarget.id,
          updated.title ?? editFilterTarget.catalog_slug,
          editFilterTarget.instance_id
        )
      }
      void loadAllDrafts()
      return true
    },
    [editFilterTarget, focusedInstanceId, instancesHook, workspace, loadAllDrafts]
  )

  const handleRefreshSidebar = useCallback(async () => {
    await connectionsHook.refresh()
    await loadAllDrafts()
    await instancesHook.refresh()
  }, [connectionsHook, loadAllDrafts, instancesHook])

  const handleDraftMenuAction = useCallback(
    async (
      action: DiscoveryDraftMenuAction,
      payload: DiscoveryDraftMenuPayload
    ) => {
      const { draftId, connectionInstanceId } = payload
      const list = draftsByInstance.get(connectionInstanceId)
      const inst = list?.find((d) => d.id === draftId)

      if (action === 'properties') {
        if (inst) {
          setEditFilterTarget(inst)
        } else {
          toastError('Could not open properties. Try Refresh.')
        }
        return
      }
      if (action === 'refresh') {
        await handleRefreshSidebar()
        return
      }
      if (action === 'delete') {
        if (
          typeof window !== 'undefined' &&
          !window.confirm(
            'Delete this discovery draft? This cannot be undone.'
          )
        ) {
          return
        }
        try {
          await deleteDiscoveryDraft(draftId, connectionInstanceId)
          await loadAllDrafts()
          await connectionsHook.refresh()
          await instancesHook.refresh()
          if (focusedInstanceId === draftId) {
            setFocusedInstanceId(null)
            workspace.selectDraft(null)
            workspace.selectVersion(null)
            workspace.setMachineName('')
          }
        } catch (e) {
          toastError(getApiErrorMessage(e, 'Failed to delete draft'))
        }
      }
    },
    [
      draftsByInstance,
      handleRefreshSidebar,
      loadAllDrafts,
      connectionsHook,
      instancesHook,
      focusedInstanceId,
      workspace,
      toastError,
    ]
  )

  const handleConnectionMenuAction = useCallback(
    async (
      action: DiscoveryConnectionMenuAction,
      payload: DiscoveryConnectionMenuPayload
    ) => {
      const { connectionInstanceId } = payload
      const conn = connectionsHook.connections.find(
        (c) => c.id === connectionInstanceId
      )

      if (action === 'create_draft') {
        setSelectedConnectionId(connectionInstanceId)
        setCreateOpen(true)
        return
      }

      if (action === 'properties') {
        if (conn) {
          setConnectionProperties(conn)
        } else {
          toastError('Could not open properties. Try Refresh.')
        }
        return
      }

      if (action === 'delete') {
        if (
          typeof window !== 'undefined' &&
          !window.confirm(
            'Delete this discovery connection? Drafts under it may become unreachable until you register a new connection.'
          )
        ) {
          return
        }
        try {
          await deleteDiscoveryConnectionInstance(connectionInstanceId)
          setConnectionProperties((p) =>
            p?.id === connectionInstanceId ? null : p
          )
          await handleRefreshSidebar()
          setFocusedInstanceId(null)
          workspace.selectDraft(null)
          workspace.selectVersion(null)
          workspace.setMachineName('')
        } catch (e) {
          toastError(getApiErrorMessage(e, 'Failed to delete connection'))
        }
      }
    },
    [
      connectionsHook.connections,
      handleRefreshSidebar,
      workspace,
      toastError,
    ]
  )

  const handleNewConnectionCreated = useCallback(
    (connectionInstanceId: string) => {
      void (async () => {
        await connectionsHook.refresh()
        setSelectedConnectionId(connectionInstanceId)
        setFocusedInstanceId(null)
        workspace.selectDraft(null)
        workspace.selectVersion(null)
        workspace.setMachineName('')
        await loadAllDrafts()
      })()
    },
    [connectionsHook, workspace, loadAllDrafts]
  )

  useEffect(() => {
    if (typeof window === 'undefined') return
    const savedConn = window.localStorage.getItem(DISCOVERY_SELECTED_CONNECTION_KEY)
    if (savedConn?.trim()) {
      setSelectedConnectionId(savedConn.trim())
    }
    const savedDraft = window.localStorage.getItem(DISCOVERY_FOCUSED_INSTANCE_KEY)
    if (savedDraft?.trim()) {
      setFocusedInstanceId(savedDraft.trim())
    }
  }, [])

  useEffect(() => {
    if (typeof window === 'undefined') return
    if (!selectedConnectionId) {
      window.localStorage.removeItem(DISCOVERY_SELECTED_CONNECTION_KEY)
      return
    }
    window.localStorage.setItem(DISCOVERY_SELECTED_CONNECTION_KEY, selectedConnectionId)
  }, [selectedConnectionId])

  useEffect(() => {
    if (!connectionsHook.connections.length) return
    setSelectedConnectionId((prev) => {
      if (prev && connectionsHook.connections.some((c) => c.id === prev)) {
        return prev
      }
      return connectionsHook.connections[0].id
    })
  }, [connectionsHook.connections])

  useEffect(() => {
    if (typeof window === 'undefined') return
    if (!focusedInstanceId) {
      window.localStorage.removeItem(DISCOVERY_FOCUSED_INSTANCE_KEY)
      return
    }
    window.localStorage.setItem(DISCOVERY_FOCUSED_INSTANCE_KEY, focusedInstanceId)
  }, [focusedInstanceId])

  useEffect(() => {
    if (!focusedInstanceId) return
    if (instancesHook.loading) return
    const exists = instancesHook.instances.some((i) => i.id === focusedInstanceId)
    if (!exists) {
      setFocusedInstanceId(null)
      workspace.selectDraft(null)
      workspace.selectVersion(null)
      workspace.setMachineName('')
    }
  }, [focusedInstanceId, instancesHook.instances, instancesHook.loading, workspace])

  useEffect(() => {
    if (!focusedInstanceId) return
    if (!selectedConnectionId) return
    if (workspace.machineName) return
    const inst = instancesHook.instances.find((i) => i.id === focusedInstanceId)
    if (!inst) return
    void workspace.focusInstance(inst.id, inst.catalog_slug, inst.instance_id)
  }, [focusedInstanceId, selectedConnectionId, instancesHook.instances, workspace])

  const sidebarError =
    connectionsHook.error ?? instancesHook.error ?? null

  const treeLoading = connectionsHook.loading || draftsLoading

  return {
    treeNodes,
    treeLoading,
    sidebarError,
    focusedInstanceId,
    handleSelectDraft,
    setConnectionDialogOpen,
    handleDraftMenuAction,
    handleConnectionMenuAction,
    createOpen,
    setCreateOpen,
    connectionDialogOpen,
    connectionProperties,
    setConnectionProperties,
    editFilterTarget,
    setEditFilterTarget,
    connectionsHook,
    loadAllDrafts,
    handleCreate,
    handleNewConnectionCreated,
    handleSaveDraft,
    editDraftConnectionBackend,
    workspace,
    focusedInstance,
    handleAfterObservation,
    selectedConnectionId,
    handleOpenEditFilterDialog,
    instancesHook,
  }
}

const WorkspaceDiscoveryContext = createContext<WorkspaceDiscoveryContextValue | null>(
  null
)

export function WorkspaceDiscoveryProvider({
  children,
}: {
  children: ReactNode
}) {
  const value = useWorkspaceDiscoveryValue()
  return (
    <WorkspaceDiscoveryContext.Provider value={value}>
      {children}
    </WorkspaceDiscoveryContext.Provider>
  )
}

export function useWorkspaceDiscovery(): WorkspaceDiscoveryContextValue {
  const ctx = useContext(WorkspaceDiscoveryContext)
  if (!ctx) {
    throw new Error('useWorkspaceDiscovery must be used within WorkspaceDiscoveryProvider')
  }
  return ctx
}

export interface WorkspaceDiscoverySidebarProps extends SidebarLayoutApi {
  workspaceArea: WorkspaceMainArea
  onWorkspaceAreaChange: (area: WorkspaceMainArea) => void
}

export function WorkspaceDiscoverySidebar({
  workspaceArea,
  onWorkspaceAreaChange,
  ...api
}: WorkspaceDiscoverySidebarProps) {
  const d = useWorkspaceDiscovery()
  return (
    <DiscoveryTreeSidebar
      api={api}
      workspaceArea={workspaceArea}
      onWorkspaceAreaChange={onWorkspaceAreaChange}
      nodes={d.treeNodes}
      loading={d.treeLoading}
      error={d.sidebarError}
      selectedDraftId={d.focusedInstanceId}
      onSelectDraft={d.handleSelectDraft}
      onCreateInstance={() => d.setConnectionDialogOpen(true)}
      onDraftMenuAction={d.handleDraftMenuAction}
      onConnectionMenuAction={d.handleConnectionMenuAction}
    />
  )
}

export function WorkspaceDiscoveryMain() {
  const d = useWorkspaceDiscovery()
  return (
    <>
      <CreateDiscoveryInstanceDialog
        open={d.createOpen}
        onOpenChange={d.setCreateOpen}
        connections={d.connectionsHook.connections}
        defaultDiscoveryInstanceId={d.selectedConnectionId}
        onRequestNewConnection={() => d.setConnectionDialogOpen(true)}
        onCreate={d.handleCreate}
      />
      <CreateDiscoveryConnectionDialog
        open={d.connectionDialogOpen}
        onOpenChange={d.setConnectionDialogOpen}
        onCreated={d.handleNewConnectionCreated}
      />
      <DiscoveryConnectionPropertiesDialog
        open={d.connectionProperties !== null}
        onOpenChange={(open) => {
          if (!open) d.setConnectionProperties(null)
        }}
        connection={d.connectionProperties}
        onSaved={() => {
          void d.connectionsHook.refresh()
          void d.loadAllDrafts()
        }}
      />
      <EditDiscoveryInstanceFilterDialog
        open={d.editFilterTarget !== null}
        onOpenChange={(open) => {
          if (!open) d.setEditFilterTarget(null)
        }}
        draft={d.editFilterTarget}
        connectionBackend={d.editDraftConnectionBackend}
        onSave={d.handleSaveDraft}
      />
      <div className="relative h-full min-h-0 w-full flex-1 overflow-hidden">
        <DiscoveryWorkspace
          mode="standalone"
          workspace={d.workspace}
          focusedInstance={d.focusedInstance}
          exploreDraftId={d.focusedInstanceId}
          onAfterObservation={d.handleAfterObservation}
          discoveryConnectionId={d.selectedConnectionId}
          onEditDraftFilter={
            d.focusedInstance
              ? () => d.handleOpenEditFilterDialog(d.focusedInstance!)
              : undefined
          }
        />
      </div>
    </>
  )
}
