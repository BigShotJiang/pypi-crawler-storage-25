'use client'

import { useRef } from 'react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import type { UseDiscoveryWorkspaceResult } from '@/hooks/useDiscoveryWorkspace'
import { DIAGRAM_VIEW_TOOLBAR_OVERLAP_RATIO, useToolbarCompression } from '@/hooks'
import { cn } from '@/lib/utils'
import { Ellipsis, Eye, Loader2, PanelBottom, Wrench } from 'lucide-react'

export interface DiscoveryToolbarProps {
  d: UseDiscoveryWorkspaceResult
  /** Bottom tools panel is expanded (resizable panel visible). */
  toolsPanelExpanded: boolean
  onToggleToolsPanel: () => void
  canRunScope: boolean
  canBuild: boolean
  /**
   * When true, Preview/Build are omitted — use when those actions live in the bottom panel
   * (e.g. Recipes / Review tabs).
   */
  hidePreviewAndBuild?: boolean
}

/**
 * Overlay toolbar for Discovery — placement, styling, and narrow-width behavior match
 * {@link WorkspaceToolbar} (absolute top-right, compression + overflow menu).
 */
export function DiscoveryToolbar({
  d,
  toolsPanelExpanded,
  onToggleToolsPanel,
  canRunScope,
  canBuild,
  hidePreviewAndBuild = false,
}: DiscoveryToolbarProps) {
  const toolbarRef = useRef<HTMLDivElement>(null)
  const isToolbarCollapsed = useToolbarCompression(
    toolbarRef,
    DIAGRAM_VIEW_TOOLBAR_OVERLAP_RATIO
  )

  const toolsLabel = toolsPanelExpanded ? 'Hide tools panel' : 'Show tools panel'

  return (
    <div
      ref={toolbarRef}
      className="absolute top-3 right-3 z-10 flex flex-row flex-wrap items-center gap-2 rounded-lg border border-border bg-background/95 px-3 py-2 shadow-md backdrop-blur-sm"
      role="toolbar"
      aria-label="Discovery actions"
    >
      {!isToolbarCollapsed ? (
        <>
          <Button
            type="button"
            variant={toolsPanelExpanded ? 'secondary' : 'ghost'}
            size="sm"
            onClick={onToggleToolsPanel}
            className={cn('shrink-0 p-2')}
            title={toolsLabel}
            aria-label={toolsLabel}
            aria-expanded={toolsPanelExpanded}
            aria-pressed={toolsPanelExpanded}
            aria-controls="discovery-standalone-tools"
          >
            <PanelBottom className="h-4 w-4" aria-hidden />
          </Button>
          {!hidePreviewAndBuild ? (
            <>
              <div className="h-5 border-l border-border" aria-hidden />
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="h-8"
                disabled={!canRunScope || d.previewLoading}
                onClick={() => void d.preview()}
              >
                {d.previewLoading ? (
                  <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Eye className="mr-1.5 h-3.5 w-3.5" />
                )}
                Preview
              </Button>
              <Button
                type="button"
                size="sm"
                className="h-8"
                disabled={!canBuild || d.building}
                onClick={() => void d.build()}
              >
                {d.building ? (
                  <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Wrench className="mr-1.5 h-3.5 w-3.5" />
                )}
                Build
              </Button>
            </>
          ) : null}
        </>
      ) : (
        <>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="shrink-0 p-2"
                aria-label="More discovery actions"
              >
                <Ellipsis className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel className="text-xs">Tools panel</DropdownMenuLabel>
              <DropdownMenuItem onClick={onToggleToolsPanel} className="text-xs">
                <PanelBottom className="mr-2 h-4 w-4" />
                {toolsPanelExpanded ? 'Hide tools panel' : 'Show tools panel'}
              </DropdownMenuItem>
              {!hidePreviewAndBuild ? (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuLabel className="text-xs">Run</DropdownMenuLabel>
                  <DropdownMenuItem
                    onClick={() => void d.preview()}
                    disabled={!canRunScope || d.previewLoading}
                    className="text-xs"
                  >
                    {d.previewLoading ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Eye className="mr-2 h-4 w-4" />
                    )}
                    Preview
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => void d.build()}
                    disabled={!canBuild || d.building}
                    className="text-xs"
                  >
                    {d.building ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Wrench className="mr-2 h-4 w-4" />
                    )}
                    Build
                  </DropdownMenuItem>
                </>
              ) : null}
            </DropdownMenuContent>
          </DropdownMenu>
        </>
      )}
    </div>
  )
}
