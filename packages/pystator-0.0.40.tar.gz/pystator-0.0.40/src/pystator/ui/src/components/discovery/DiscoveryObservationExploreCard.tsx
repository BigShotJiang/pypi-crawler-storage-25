'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Loader2, Lock, MoreVertical, Plus, RefreshCw, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from 'lucide-react'
import {
  deleteDiscoveryDraftObservation,
  getApiErrorMessage,
  insertDiscoveryDraftObservationRelative,
  listDiscoveryDraftObservations,
  type DiscoveryObservationIdentityPayload,
  type DiscoveryObservationItem,
} from '@/lib/api'
import type { UseDiscoveryWorkspaceResult } from '@/hooks/useDiscoveryWorkspace'
import { useToastStore } from '@/stores/toast'
import { cn } from '@/lib/utils'
import {
  lastPageStartOffset,
  offsetCanNext,
  offsetCanPrev,
  offsetDisplayRange,
  offsetStepNext,
  offsetStepPrev,
} from '@/lib/offsetLimitPagination'

const PAGE_SIZE = 40

/** Comma-separated IDs; empty input → no filter. */
function parseEntityIds(raw: string): string[] | null {
  const parts = raw
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
  return parts.length > 0 ? parts : null
}

function formatTs(iso: string): string {
  try {
    const d = new Date(iso)
    if (Number.isNaN(d.getTime())) return iso
    return d.toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    })
  } catch {
    return iso
  }
}

function rowKeyStable(row: DiscoveryObservationItem): string {
  return `${row.entity_id}\0${row.observed_at}\0${row.ingest_seq}\0${row.source}\0${row.source_event_id ?? ''}`
}

function rowToIdentity(row: DiscoveryObservationItem): DiscoveryObservationIdentityPayload {
  return {
    entity_id: row.entity_id,
    state: row.state,
    observed_at: row.observed_at,
    source: row.source,
    source_event_id: row.source_event_id,
  }
}

export interface DiscoveryObservationExploreCardProps {
  /** Draft id from the tree focus; explore uses this draft's filter and observation source. */
  draftId: string | null
  discoveryConnectionId?: string | null
  /** Bump after recording observations to reload the table. */
  ingestRevision?: number
  /** Opens the record-observation dialog (Workspace Discovery). */
  onOpenObservation?: () => void
  /**
   * When set, **Refresh** reloads distinct entity IDs from the API (same as the former
   * “Fetch observations” control) and then reloads this table.
   */
  workspace?: UseDiscoveryWorkspaceResult
  /**
   * When the drafts list has not yet matched ``draftId``, use this (e.g. focused instance
   * ``observation_source``) to decide if row mutations are allowed for the native table.
   */
  focusedInstanceObservationSource?: Record<string, unknown> | null
}

export function DiscoveryObservationExploreCard({
  draftId,
  discoveryConnectionId,
  ingestRevision = 0,
  onOpenObservation,
  workspace,
  focusedInstanceObservationSource,
}: DiscoveryObservationExploreCardProps) {
  const toastSuccess = useToastStore((s) => s.success)
  const toastError = useToastStore((s) => s.error)

  const [entityDraft, setEntityDraft] = useState('')
  /** Applied filter: `null` means show all entities; non-null restricts to these ids. */
  const [appliedEntityIds, setAppliedEntityIds] = useState<string[] | null>(null)
  const [offset, setOffset] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [items, setItems] = useState<DiscoveryObservationItem[]>([])
  const [total, setTotal] = useState(0)
  const [mutRevision, setMutRevision] = useState(0)

  const [pendingDelete, setPendingDelete] = useState<DiscoveryObservationItem | null>(null)
  const [insertCtx, setInsertCtx] = useState<{
    position: 'above' | 'below'
    reference: DiscoveryObservationItem
  } | null>(null)
  const [insertStateValue, setInsertStateValue] = useState('')
  const [actionBusyKey, setActionBusyKey] = useState<string | null>(null)

  const canMutateObservations = useMemo(() => {
    const id = draftId?.trim()
    if (!id) return false
    const row = workspace?.drafts?.find((x) => x.id === id)
    if (row) return row.observation_source == null
    if (focusedInstanceObservationSource !== undefined) {
      return focusedInstanceObservationSource == null
    }
    return false
  }, [draftId, workspace?.drafts, focusedInstanceObservationSource])

  const rowActionsDisabledReason = useMemo(() => {
    if (canMutateObservations) return undefined
    const id = draftId?.trim()
    if (!id) return 'Select a draft in the tree to enable row actions.'
    const row = workspace?.drafts?.find((x) => x.id === id)
    const custom =
      row != null
        ? row.observation_source != null
        : focusedInstanceObservationSource != null
    if (custom) {
      return 'This draft maps observations to a custom table/columns. Open Properties (⋮ on the draft in the left sidebar) or Draft settings on the diagram, expand Observation source, then clear those fields or restore defaults to edit rows here.'
    }
    return 'Row actions stay disabled until this draft is linked to the workspace list.'
  }, [
    canMutateObservations,
    draftId,
    workspace?.drafts,
    focusedInstanceObservationSource,
  ])

  /** Muted line under the entity filter; omit the long custom-source copy (still on row lock tooltips). */
  const observationFilterSubtitle = useMemo(() => {
    if (canMutateObservations) return null
    const id = draftId?.trim()
    if (!id) return 'Select a draft in the tree to enable row actions.'
    const row = workspace?.drafts?.find((x) => x.id === id)
    const hasCustomSource =
      row != null
        ? row.observation_source != null
        : focusedInstanceObservationSource != null
    if (hasCustomSource) return null
    return 'Row actions stay disabled until this draft is linked to the workspace list.'
  }, [canMutateObservations, draftId, workspace?.drafts, focusedInstanceObservationSource])

  const load = useCallback(async () => {
    if (!draftId?.trim()) {
      setItems([])
      setTotal(0)
      return
    }
    setLoading(true)
    setError(null)
    try {
      const res = await listDiscoveryDraftObservations(draftId.trim(), {
        limit: PAGE_SIZE,
        offset,
        ...(appliedEntityIds && appliedEntityIds.length > 0
          ? { entity_ids: appliedEntityIds }
          : {}),
        discovery_instance_id: discoveryConnectionId ?? undefined,
      })
      setItems(res.items)
      setTotal(res.total)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to load observations'))
      setItems([])
      setTotal(0)
    } finally {
      setLoading(false)
    }
  }, [draftId, offset, appliedEntityIds, discoveryConnectionId])

  useEffect(() => {
    void load()
  }, [load, ingestRevision, mutRevision])

  useEffect(() => {
    setOffset(0)
  }, [appliedEntityIds, draftId])

  useEffect(() => {
    setAppliedEntityIds(null)
    setEntityDraft('')
  }, [draftId])

  const applyEntityFilter = useCallback(() => {
    setAppliedEntityIds(parseEntityIds(entityDraft))
    setOffset(0)
  }, [entityDraft])

  const refreshAll = useCallback(async () => {
    if (workspace) {
      await workspace.refreshObservationEntities()
    }
    if (!draftId?.trim()) return
    await load()
  }, [draftId, workspace, load])

  const refreshBusy = loading || Boolean(workspace?.loadingEntityIds)

  const runDelete = useCallback(async () => {
    if (!draftId?.trim() || !pendingDelete) return
    const key = rowKeyStable(pendingDelete)
    setActionBusyKey(key)
    try {
      const res = await deleteDiscoveryDraftObservation(
        draftId.trim(),
        { identity: rowToIdentity(pendingDelete) },
        discoveryConnectionId ?? undefined
      )
      if (res.deleted) {
        toastSuccess('Observation deleted')
        setMutRevision((n) => n + 1)
      } else {
        toastError('No matching row was deleted (it may have already been removed).')
        setMutRevision((n) => n + 1)
      }
      setPendingDelete(null)
    } catch (e) {
      toastError(getApiErrorMessage(e, 'Failed to delete observation'))
    } finally {
      setActionBusyKey(null)
    }
  }, [draftId, pendingDelete, discoveryConnectionId, toastSuccess, toastError])

  const runInsert = useCallback(async () => {
    if (!draftId?.trim() || !insertCtx) return
    const state = insertStateValue.trim()
    if (!state) {
      toastError('Enter a state name for the new observation.')
      return
    }
    const ref = insertCtx.reference
    const key = rowKeyStable(ref)
    setActionBusyKey(key)
    try {
      const res = await insertDiscoveryDraftObservationRelative(
        draftId.trim(),
        {
          entity_id: ref.entity_id,
          reference: rowToIdentity(ref),
          position: insertCtx.position,
          state,
          source: 'ui',
          metadata: {},
        },
        discoveryConnectionId ?? undefined
      )
      if (res.accepted) {
        toastSuccess(
          insertCtx.position === 'above'
            ? 'Observation inserted above the selected row'
            : 'Observation inserted below the selected row'
        )
        setMutRevision((n) => n + 1)
        setInsertCtx(null)
        setInsertStateValue('')
      } else {
        toastError('Observation was not stored (duplicate natural key).')
      }
    } catch (e) {
      toastError(getApiErrorMessage(e, 'Failed to insert observation'))
    } finally {
      setActionBusyKey(null)
    }
  }, [
    draftId,
    insertCtx,
    insertStateValue,
    discoveryConnectionId,
    toastSuccess,
    toastError,
  ])

  const startInsert = useCallback(
    (position: 'above' | 'below', reference: DiscoveryObservationItem) => {
      setInsertCtx({ position, reference })
      setInsertStateValue('')
    },
    []
  )

  const { start, end } = offsetDisplayRange(offset, items.length, total)
  const canPrev = offsetCanPrev(offset)
  const canNext = offsetCanNext(offset, PAGE_SIZE, total)

  const hasDraft = Boolean(draftId?.trim())

  return (
    <>
      <div className="space-y-3">
        {/*
          Keep Observation + Refresh on one row (no wrap) so they stay visible when the table
          is empty or the panel is narrow. Toolbar is always shown so users can record observations
          before a draft is selected or before any rows exist.
        */}
        <div className="flex min-w-0 flex-nowrap items-center gap-2 overflow-x-auto py-1">
          <div className="min-w-0 w-72 shrink-0">
            <Input
              id="doe-entity-ids"
              value={entityDraft}
              onChange={(e) => setEntityDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault()
                  applyEntityFilter()
                }
              }}
              placeholder="Entity IDs, comma-separated (optional)"
              disabled={!hasDraft}
              aria-label="Filter observations by entity IDs"
              className={cn(
                'h-9 font-mono text-xs',
                'focus-visible:ring-inset focus-visible:ring-offset-0',
                !hasDraft && 'cursor-not-allowed opacity-60',
              )}
            />
          </div>
          <Button
            type="button"
            variant="secondary"
            className="h-9 shrink-0"
            onClick={applyEntityFilter}
            disabled={!hasDraft}
            title={!hasDraft ? 'Select a draft in the tree first' : undefined}
          >
            Apply
          </Button>
          {onOpenObservation ? (
            <Button
              type="button"
              variant="outline"
              className="h-9 shrink-0"
              onClick={onOpenObservation}
              title="Record observation"
            >
              <Plus className="mr-1 h-3.5 w-3.5 opacity-80" />
              Observation
            </Button>
          ) : null}
          <Button
            type="button"
            variant="outline"
            className="h-9 shrink-0"
            disabled={refreshBusy}
            onClick={() => void refreshAll()}
            title={
              workspace
                ? 'Reload entity IDs from the server, then refresh this table'
                : 'Reload this table'
            }
          >
            {refreshBusy ? (
              <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
            ) : (
              <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
            )}
            Refresh
          </Button>
        </div>

        {observationFilterSubtitle ? (
          <p className="text-[11px] text-muted-foreground">{observationFilterSubtitle}</p>
        ) : null}

        {error ? (
          <p className="text-xs text-destructive">{error}</p>
        ) : null}

        <div className="min-h-0 overflow-x-auto">
          <table className="w-full min-w-[36rem] border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-border/60 bg-muted/30 text-[10px] uppercase tracking-wide text-muted-foreground">
                <th className="px-2 py-1.5 font-medium">Entity</th>
                <th className="px-2 py-1.5 font-medium">State</th>
                <th className="px-2 py-1.5 font-medium">Observed</th>
                <th className="px-2 py-1.5 font-medium">Source</th>
                <th className="w-14 px-1 py-1.5 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.length === 0 && !loading ? (
                <tr>
                  <td
                    colSpan={5}
                    className="px-2 py-6 text-center text-muted-foreground"
                  >
                    {!hasDraft
                      ? 'No draft selected — choose a draft in the tree to list observations here.'
                      : total === 0
                        ? 'No observations in this draft’s scope.'
                        : 'No rows on this page.'}
                  </td>
                </tr>
              ) : null}
              {items.map((row, i) => {
                const sk = rowKeyStable(row)
                const busy = actionBusyKey === sk
                return (
                  <tr
                    key={`${sk}-${i}`}
                    className="border-b border-border/40 last:border-0"
                  >
                    <td className="max-w-[10rem] truncate px-2 py-1.5 font-mono text-[11px]">
                      {row.entity_id}
                    </td>
                    <td className="px-2 py-1.5 font-mono text-[11px]">{row.state}</td>
                    <td className="whitespace-nowrap px-2 py-1.5 text-[11px] text-muted-foreground">
                      {formatTs(row.observed_at)}
                    </td>
                    <td className="max-w-[8rem] truncate px-2 py-1.5 text-[11px]">
                      {row.source}
                    </td>
                    <td className="px-1 py-1 text-right align-middle">
                      {canMutateObservations ? (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              disabled={busy || refreshBusy}
                              aria-label="Row actions"
                            >
                              {busy ? (
                                <Loader2 className="h-4 w-4 animate-spin opacity-70" />
                              ) : (
                                <MoreVertical className="h-4 w-4 opacity-70" />
                              )}
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-52">
                            <DropdownMenuItem
                              onClick={() => startInsert('above', row)}
                              disabled={busy || refreshBusy}
                            >
                              Insert above (newer)
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => startInsert('below', row)}
                              disabled={busy || refreshBusy}
                            >
                              Insert below (older)
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-destructive focus:text-destructive"
                              onClick={() => setPendingDelete(row)}
                              disabled={busy || refreshBusy}
                            >
                              Delete this row
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      ) : (
                        <span
                          className="inline-flex h-8 w-8 items-center justify-center"
                          title={rowActionsDisabledReason}
                        >
                          <Lock
                            className="h-3.5 w-3.5 text-muted-foreground/55"
                            aria-hidden
                          />
                          <span className="sr-only">{rowActionsDisabledReason}</span>
                        </span>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-muted-foreground">
          <span>
            {total === 0
              ? '0 rows'
              : `${start}–${end} of ${total}${total > PAGE_SIZE ? ' (paged)' : ''}`}
          </span>
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-7 text-[11px] gap-1"
              disabled={!canPrev || refreshBusy}
              onClick={() => setOffset(0)}
              title="First page"
            >
              <ChevronsLeft className="h-3.5 w-3.5" /> First
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-7 text-[11px] gap-1"
              disabled={!canPrev || refreshBusy}
              onClick={() => setOffset((o) => offsetStepPrev(o, PAGE_SIZE))}
            >
              <ChevronLeft className="h-3.5 w-3.5" /> Prev
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-7 text-[11px] gap-1"
              disabled={!canNext || refreshBusy}
              onClick={() => setOffset((o) => offsetStepNext(o, PAGE_SIZE, total))}
            >
              Next <ChevronRight className="h-3.5 w-3.5" />
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-7 text-[11px] gap-1"
              disabled={!canNext || refreshBusy}
              onClick={() => setOffset(lastPageStartOffset(total, PAGE_SIZE))}
              title="Last page"
            >
              Last <ChevronsRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </div>

      <Dialog open={Boolean(pendingDelete)} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Delete this observation?</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            This removes one stored row for entity{' '}
            <span className="font-mono text-foreground">{pendingDelete?.entity_id}</span> at{' '}
            {pendingDelete ? formatTs(pendingDelete.observed_at) : ''}. Preview and build use
            whatever rows remain.
          </p>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button type="button" variant="outline" onClick={() => setPendingDelete(null)}>
              Cancel
            </Button>
            <Button type="button" variant="destructive" onClick={() => void runDelete()}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={Boolean(insertCtx)}
        onOpenChange={(o) => {
          if (!o) {
            setInsertCtx(null)
            setInsertStateValue('')
          }
        }}
      >
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {insertCtx?.position === 'above'
                ? 'Insert observation above'
                : 'Insert observation below'}
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            New rows are ordered by observed time (newest first in this table). The server picks
            timestamps so the row sits{' '}
            {insertCtx?.position === 'above'
              ? 'between the row above and this one'
              : 'between this row and the one below'}
            .
          </p>
          <div className="space-y-1">
            <Label htmlFor="doe-insert-state">State</Label>
            <Input
              id="doe-insert-state"
              value={insertStateValue}
              onChange={(e) => setInsertStateValue(e.target.value)}
              placeholder="e.g. pending_review"
              className="font-mono"
              onKeyDown={(e) => {
                if (e.key === 'Enter') void runInsert()
              }}
            />
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setInsertCtx(null)
                setInsertStateValue('')
              }}
            >
              Cancel
            </Button>
            <Button type="button" onClick={() => void runInsert()}>
              Insert
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
