'use client'

import { useCallback, useMemo, useRef, useState } from 'react'
import {
  Group,
  Panel,
  Separator,
  type PanelImperativeHandle,
} from 'react-resizable-panels'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { DiscoveryToolbar } from '@/components/discovery/DiscoveryToolbar'
import type { UseDiscoveryWorkspaceResult } from '@/hooks/useDiscoveryWorkspace'
import { DiscoveryStatusBanner } from '@/components/discovery/DiscoveryStatusBanner'
import { DiscoveryObservationCard } from '@/components/discovery/DiscoveryObservationCard'
import { DiscoveryObservationExploreCard } from '@/components/discovery/DiscoveryObservationExploreCard'
import {
  DiscoveryBottomPanelTabs,
  type DiscoveryBottomTabId,
} from '@/components/discovery/DiscoveryBottomPanelTabs'
import { DiscoveryRecipeWorkspacePanel } from '@/components/discovery/DiscoveryRecipeWorkspacePanel'
import { DiscoveryReviewPanel } from '@/components/discovery/DiscoveryReviewPanel'
import { FsmFlowDiagram } from '@/components/fsm-flow'
import {
  DISCOVERY_EMPTY_PREVIEW_CONFIG,
  coerceDiscoveryDetailConfig,
  inferredEdgesToPreviewFsmConfig,
} from '@/lib/discoveryDiagramConfig'

/** Percent string for react-resizable-panels vertical group. */
function pct(n: number): string {
  return String(n)
}

export interface DiscoveryWorkspaceProps {
  /** Shared workspace state (e.g. from the Discovery page with fleet panel). */
  workspace: UseDiscoveryWorkspaceResult
  /** `threeColumn`: machine + builtCandidates live in left/middle columns; baseline uses catalog row id. */
  mode?: 'standalone' | 'threeColumn'
  /**
   * Currently focused Discovery Instance summary, when one exists.
   * Used by ``threeColumn`` mode to render a context chip in the
   * right-panel header so the user always knows which instance the
   * preview/build/promote actions belong to.
   */
  focusedInstance?: import('@/lib/api').DiscoveryInstanceSummary | null
  /** Sidebar-focused draft id for explore observations (stable while viewing a built version). */
  exploreDraftId?: string | null
  /** After successful single or batch observation (refresh fleet list, etc.). */
  onAfterObservation?: () => void
  /** Discovery connection instance id (registry) for API-scoped observation queries. */
  discoveryConnectionId?: string | null
  /** Opens the draft filter editor (e.g. from chip when sidebar has no filter shortcut). */
  onEditDraftFilter?: () => void
}

export function DiscoveryWorkspace({
  workspace: d,
  mode = 'standalone',
  focusedInstance = null,
  exploreDraftId = null,
  onAfterObservation,
  discoveryConnectionId = null,
  onEditDraftFilter,
}: DiscoveryWorkspaceProps) {
  const [entityId, setEntityId] = useState('demo-entity-1')
  const [stateObs, setStateObs] = useState('observed_state')
  const [exploreRevision, setExploreRevision] = useState(0)
  const [observationDialogOpen, setObservationDialogOpen] = useState(false)
  const [bottomTab, setBottomTab] = useState<DiscoveryBottomTabId>('observation')

  const hasMachine = d.machineName.trim().length > 0
  const editingWorkspace = Boolean(d.activeDraftId && !d.selectedVersion)
  const canRunScope =
    editingWorkspace && d.selectedEntityIds.length > 0
  const canBuild =
    canRunScope &&
    (d.mode === 'inference' ||
      (d.mode === 'manual' && d.selectedEdgeKeys.length > 0))

  const observationDialog = (
    <Dialog open={observationDialogOpen} onOpenChange={setObservationDialogOpen}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Record observation</DialogTitle>
        </DialogHeader>
        <DiscoveryObservationCard
          machineName={d.machineName}
          entityId={entityId}
          observedState={stateObs}
          observing={d.observing}
          onEntityIdChange={setEntityId}
          onObservedStateChange={setStateObs}
          onObserve={async () => {
            const ok = await d.observe(entityId, stateObs)
            if (ok) {
              onAfterObservation?.()
              setExploreRevision((n) => n + 1)
              setObservationDialogOpen(false)
            }
          }}
          onBulkRecord={async (text) => {
            const ok = await d.observeBulkFromText(text)
            if (ok) {
              onAfterObservation?.()
              setExploreRevision((n) => n + 1)
              setObservationDialogOpen(false)
            }
          }}
        />
      </DialogContent>
    </Dialog>
  )

  /** Built candidate detail; else draft preview from Preview — manual uses checked edges, inference uses threshold-selected edges. */
  const diagramPreviewConfig = useMemo(() => {
    const name = d.machineName.trim()
    if (d.selectedVersion && d.loadingDetail) {
      return DISCOVERY_EMPTY_PREVIEW_CONFIG
    }
    if (d.selectedVersion && d.detail?.config) {
      return coerceDiscoveryDetailConfig(d.detail.config as Record<string, unknown>, name)
    }
    if (d.mode === 'manual') {
      const selected = new Set(d.selectedEdgeKeys)
      const manualEdges = d.previewEdges.filter((e) =>
        selected.has(`${e.source_state}|||${e.destination_state}`)
      )
      if (manualEdges.length > 0) {
        return inferredEdgesToPreviewFsmConfig(manualEdges, name)
      }
      return DISCOVERY_EMPTY_PREVIEW_CONFIG
    }
    const edges =
      d.previewSelectedEdges.length > 0 ? d.previewSelectedEdges : d.previewEdges
    if (edges.length > 0) {
      return inferredEdgesToPreviewFsmConfig(edges, name)
    }
    return DISCOVERY_EMPTY_PREVIEW_CONFIG
  }, [
    d.machineName,
    d.selectedVersion,
    d.loadingDetail,
    d.detail,
    d.mode,
    d.selectedEdgeKeys,
    d.previewEdges,
    d.previewSelectedEdges,
  ])

  /** Standalone: bottom tools panel ref (collapsible + resizable, like workspace split). */
  const toolsPanelRef = useRef<PanelImperativeHandle | null>(null)
  /** Mirrors panel collapse state for toolbar + aria (also updated from onResize). */
  const [toolsPanelExpanded, setToolsPanelExpanded] = useState(true)

  const toggleToolsPanel = useCallback(() => {
    const p = toolsPanelRef.current
    if (!p) return
    if (p.isCollapsed()) {
      p.expand()
      setToolsPanelExpanded(true)
    } else {
      p.collapse()
      setToolsPanelExpanded(false)
    }
  }, [])

  if (mode === 'threeColumn') {
    return (
      <>
        {observationDialog}
        <div className="flex h-full min-h-0 flex-col">
          <div className="shrink-0">
            <DiscoveryStatusBanner error={d.error} promoted={d.promoted} />
          </div>

          {focusedInstance ? (
            <div className="flex h-9 min-h-9 shrink-0 items-center gap-2 truncate border-b border-border/50 bg-muted/30 px-3 text-xs">
              <span className="truncate font-medium text-foreground">
                {focusedInstance.title?.trim() || 'Untitled instance'}
              </span>
              <span className="shrink-0 rounded bg-muted px-1.5 py-0.5 text-[11px] text-muted-foreground">
                {focusedInstance.filter_summary}
              </span>
              <span className="truncate font-mono text-muted-foreground">
                catalog: {focusedInstance.catalog_slug}
              </span>
            </div>
          ) : null}

          <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
            {!hasMachine ? (
              <div className="flex min-h-0 flex-1 items-center justify-center p-6 text-center text-sm text-muted-foreground">
                Pin a discovery machine from the left column to use Preview, Build, and the diagram.
              </div>
            ) : (
              <>
                <Group
                  id="discovery-right-vertical"
                  orientation="vertical"
                  className="flex min-h-0 flex-1 flex-col"
                >
                  <Panel defaultSize="58" minSize="22" className="min-h-0 flex flex-col">
                    <div className="relative flex min-h-[200px] min-w-0 flex-1 flex-col p-2">
                      <FsmFlowDiagram
                        config={diagramPreviewConfig}
                        minHeight="100%"
                        className="min-h-0 flex-1"
                        editable={false}
                        showGuards
                        showActions={false}
                        opsMetrics={{ enabled: false, metricsByState: {} }}
                      />
                    </div>
                  </Panel>
                  <Separator className="h-1.5 shrink-0 bg-border !cursor-ns-resize" />
                  <Panel defaultSize="42" minSize="18" className="flex min-h-0 flex-col">
                    <DiscoveryBottomPanelTabs
                      activeTab={bottomTab}
                      onTabChange={setBottomTab}
                      observationPanel={
                        <div className="p-3">
                          <DiscoveryObservationExploreCard
                            draftId={exploreDraftId}
                            discoveryConnectionId={discoveryConnectionId}
                            ingestRevision={exploreRevision}
                            onOpenObservation={() => setObservationDialogOpen(true)}
                            workspace={d}
                            focusedInstanceObservationSource={
                              focusedInstance &&
                              exploreDraftId &&
                              focusedInstance.id === exploreDraftId
                                ? focusedInstance.observation_source
                                : undefined
                            }
                          />
                        </div>
                      }
                      recipesPanel={
                        <div className="border-b border-border/50 px-3 py-3">
                          <DiscoveryRecipeWorkspacePanel
                            workspace={d}
                            layout="threeColumn"
                            canRunScope={canRunScope}
                            canBuild={canBuild}
                          />
                        </div>
                      }
                      reviewPanel={
                        <DiscoveryReviewPanel
                          workspace={d}
                          canRunScope={canRunScope}
                          canBuild={canBuild}
                        />
                      }
                    />
                  </Panel>
                </Group>
              </>
            )}
          </div>
        </div>
      </>
    )
  }

  return (
    <>
      {observationDialog}
      {/*
        Parity with workspace page: main area is relative; diagram is full-bleed in the top
        split; overlay toolbar is absolute top-right; bottom tools live in a collapsible
        resizable panel (react-resizable-panels), toggled only from the toolbar.
      */}
      <div className="relative h-full min-h-0 w-full">
        <Group
          id="discovery-standalone-vertical"
          orientation="vertical"
          className="flex h-full min-h-0 flex-col"
        >
          <Panel
            id="discovery-standalone-diagram"
            defaultSize={pct(58)}
            minSize={pct(28)}
            className="min-h-0 flex flex-col"
          >
            <div className="relative min-h-0 flex-1">
              <div className="absolute inset-0 min-h-0">
                {hasMachine ? (
                  <FsmFlowDiagram
                    config={diagramPreviewConfig}
                    minHeight="100%"
                    className="h-full min-h-0"
                    editable={false}
                    showGuards
                    showActions={false}
                    opsMetrics={{ enabled: false, metricsByState: {} }}
                  />
                ) : (
                  <div className="flex h-full min-h-0 items-center justify-center p-6 text-center text-sm text-muted-foreground">
                    Select a draft in the left sidebar to load the machine channel and show
                    the inferred state machine in the diagram.
                  </div>
                )}
              </div>
            </div>
          </Panel>
          <Separator className="h-1.5 shrink-0 bg-border !cursor-ns-resize" />
          <Panel
            id="discovery-standalone-tools"
            panelRef={toolsPanelRef}
            defaultSize={pct(42)}
            minSize={pct(14)}
            maxSize={pct(55)}
            collapsible
            collapsedSize={0}
            className="flex min-h-0 flex-col overflow-hidden bg-background"
            onResize={(size) => {
              setToolsPanelExpanded(size.inPixels > 2)
            }}
          >
            <DiscoveryBottomPanelTabs
              activeTab={bottomTab}
              onTabChange={setBottomTab}
              observationPanel={
                <div className="p-3">
                  <DiscoveryObservationExploreCard
                    draftId={exploreDraftId}
                    discoveryConnectionId={discoveryConnectionId}
                    ingestRevision={exploreRevision}
                    onOpenObservation={() => setObservationDialogOpen(true)}
                    workspace={d}
                    focusedInstanceObservationSource={
                      focusedInstance &&
                      exploreDraftId &&
                      focusedInstance.id === exploreDraftId
                        ? focusedInstance.observation_source
                        : undefined
                    }
                  />
                </div>
              }
              recipesPanel={
                <div className="border-b border-border/50 px-3 py-3">
                  <DiscoveryRecipeWorkspacePanel
                    workspace={d}
                    layout="standalone"
                    canRunScope={canRunScope}
                    canBuild={canBuild}
                  />
                </div>
              }
              reviewPanel={
                <DiscoveryReviewPanel
                  workspace={d}
                  canRunScope={canRunScope}
                  canBuild={canBuild}
                />
              }
            />
          </Panel>
        </Group>

        {focusedInstance ? (
          <div className="absolute top-3 left-3 z-10 flex max-w-[min(100%-8rem,28rem)] items-start gap-2 rounded-lg border border-border bg-background/95 px-2 py-1.5 text-xs shadow-md backdrop-blur-sm">
            <div className="min-w-0 flex-1 truncate pt-0.5">
              <span className="font-medium text-foreground">
                {focusedInstance.title?.trim() || 'Untitled instance'}
              </span>
              <span className="mx-1.5 shrink-0 rounded bg-muted px-1.5 py-0.5 text-[11px] text-muted-foreground">
                {focusedInstance.filter_summary}
              </span>
              <span className="font-mono text-muted-foreground">
                {focusedInstance.catalog_slug}
              </span>
            </div>
            {onEditDraftFilter ? (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-7 shrink-0 px-2 text-[11px]"
                onClick={onEditDraftFilter}
              >
                Draft settings
              </Button>
            ) : null}
          </div>
        ) : null}

        {d.error || d.promoted ? (
          <div
            className={`absolute left-3 z-10 max-w-[min(100%-10rem,24rem)] space-y-2 ${
              focusedInstance ? 'top-[3.25rem]' : 'top-3'
            }`}
          >
            <DiscoveryStatusBanner error={d.error} promoted={d.promoted} />
          </div>
        ) : null}

        <DiscoveryToolbar
          d={d}
          toolsPanelExpanded={toolsPanelExpanded}
          onToggleToolsPanel={toggleToolsPanel}
          canRunScope={canRunScope}
          canBuild={canBuild}
          hidePreviewAndBuild
        />
      </div>
    </>
  )
}
