'use client'

import { useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Plus, X } from 'lucide-react'
import { getSettings } from '@/lib/settings'
import { useAppConfigStore, selectAllowInlineCodeActions } from '@/stores/app-config'
import { FsmCodeActionEditor } from '@/components/editors/FsmCodeActionEditor'

import type { FSMActionRef } from '@/lib/types/fsm'
import {
  mergeActionMeta,
  splitActionMeta,
  type ActionRowMeta,
} from '@/lib/actionRowMeta'

export type FSMAction = FSMActionRef

type ActionKind = 'effect' | 'http' | 'named' | 'code' | 'conditional'
type EffectType =
  | 'set'
  | 'timestamp'
  | 'increment'
  | 'decrement'
  | 'append'
  | 'clear'
  | 'compute'

const EFFECT_TYPES: EffectType[] = [
  'set',
  'timestamp',
  'increment',
  'decrement',
  'append',
  'clear',
  'compute',
]

const CHECK_OPS = [
  'eq',
  'neq',
  'gt',
  'gte',
  'lt',
  'lte',
  'in',
  'not_in',
  'is_set',
  'is_null',
  'contains',
  'starts_with',
  'ends_with',
  'matches',
] as const

const HTTP_METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'] as const

const ON_ERROR_MODES = ['log', 'fail', 'ignore'] as const

const SINGLE_FIELD_EFFECTS: EffectType[] = ['timestamp', 'increment', 'decrement', 'clear']

const BORDER: Record<ActionKind, string> = {
  effect: 'border-l-emerald-500',
  http: 'border-l-sky-500',
  named: 'border-l-violet-500',
  code: 'border-l-orange-500',
  conditional: 'border-l-amber-500',
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v)
}

function classifyPayload(body: FSMActionRef): { kind: ActionKind; effectType?: EffectType } {
  if (typeof body === 'string') return { kind: 'named' }
  if (!isRecord(body)) return { kind: 'named' }
  const o = body as Record<string, unknown>
  if ('branch' in o) return { kind: 'conditional' }
  if ('http' in o) return { kind: 'http' }
  if ('code' in o) return { kind: 'code' }
  if ('name' in o) return { kind: 'named' }
  for (const t of EFFECT_TYPES) {
    if (t in o) return { kind: 'effect', effectType: t }
  }
  return { kind: 'named' }
}

function getNamedBody(body: FSMActionRef): { name: string; params?: Record<string, unknown> } {
  if (typeof body === 'string') return { name: body }
  const o = body as Record<string, unknown>
  if (typeof o.name === 'string') {
    return {
      name: o.name,
      params: isRecord(o.params) ? (o.params as Record<string, unknown>) : undefined,
    }
  }
  return { name: '' }
}

function getEffectField(body: FSMActionRef, type: EffectType): string {
  const o = body as Record<string, unknown>
  if (type === 'append') return String((o.append as { field?: string })?.field ?? '')
  return String(o[type] ?? '')
}

function getSetPair(body: FSMActionRef): [string, string] {
  const o = body as Record<string, unknown>
  if (isRecord(o.set)) {
    const entries = Object.entries(o.set as Record<string, unknown>)
    if (entries.length > 0) return [entries[0][0], String(entries[0][1])]
  }
  return ['', '']
}

function getAppendValue(body: FSMActionRef): string {
  const o = body as Record<string, unknown>
  if (isRecord(o.append)) {
    return String((o.append as { value?: unknown }).value ?? '')
  }
  return ''
}

function getComputePairs(body: FSMActionRef): { key: string; expr: string }[] {
  const o = body as Record<string, unknown>
  if (!isRecord(o.compute)) return [{ key: '', expr: '' }]
  const pairs = Object.entries(o.compute as Record<string, string>).map(([key, expr]) => ({
    key,
    expr: String(expr),
  }))
  return pairs.length > 0 ? pairs : [{ key: '', expr: '' }]
}

function buildPayload(kind: ActionKind, effectType: EffectType): FSMActionRef {
  if (kind === 'named') return ''
  if (kind === 'http') return { http: { url: '', method: 'POST' } }
  if (kind === 'code') return { code: { source: '' } }
  if (kind === 'conditional') {
    return {
      branch: {
        when: { field: '', op: 'eq', value: '' },
        then: [],
        else: [],
      },
    }
  }
  const map: Record<EffectType, FSMActionRef> = {
    set: { set: { '': '' } },
    timestamp: { timestamp: '' },
    increment: { increment: '' },
    decrement: { decrement: '' },
    append: { append: { field: '', value: '' } },
    clear: { clear: '' },
    compute: { compute: { '': '' } },
  }
  return map[effectType]
}

type HeaderRow = { key: string; value: string }

function headersToRows(h: unknown): HeaderRow[] {
  if (!isRecord(h) || Object.keys(h).length === 0) return [{ key: '', value: '' }]
  return Object.entries(h).map(([key, value]) => ({ key, value: String(value) }))
}

function rowsToHeaders(rows: HeaderRow[]): Record<string, string> {
  const o: Record<string, string> = {}
  for (const r of rows) {
    if (r.key.trim()) o[r.key.trim()] = r.value
  }
  return o
}

function getHttpInner(body: FSMActionRef): Record<string, unknown> {
  const o = body as Record<string, unknown>
  if (isRecord(o.http)) return { ...(o.http as Record<string, unknown>) }
  return { url: '', method: 'POST' }
}

function mergeHttpInner(
  prevBody: FSMActionRef,
  patch: Record<string, unknown>,
): FSMActionRef {
  const inner: Record<string, unknown> = { ...getHttpInner(prevBody) }
  for (const [k, v] of Object.entries(patch)) {
    if (v === undefined) {
      delete inner[k]
    } else {
      inner[k] = v
    }
  }
  delete inner.timeout
  delete inner.retry
  return { http: inner }
}

function getCodeSource(body: FSMActionRef): string {
  const o = body as Record<string, unknown>
  const c = o.code
  if (c === undefined) return ''
  if (typeof c === 'string') return c
  if (isRecord(c) && typeof c.source === 'string') return c.source
  return ''
}

function getBranch(body: FSMActionRef): {
  when: unknown
  then: FSMActionRef[]
  else: FSMActionRef[]
} {
  const o = body as Record<string, unknown>
  if (!isRecord(o.branch)) {
    return { when: { field: '', op: 'eq', value: '' }, then: [], else: [] }
  }
  const b = o.branch as Record<string, unknown>
  const thenRaw = b.then
  const elseRaw = b.else
  const then = Array.isArray(thenRaw) ? (thenRaw as FSMActionRef[]) : []
  const elseList = Array.isArray(elseRaw) ? (elseRaw as FSMActionRef[]) : []
  return {
    when: b.when ?? { field: '', op: 'eq', value: '' },
    then,
    else: elseList,
  }
}

interface ActionEditorProps {
  actions: FSMAction[]
  onChange: (actions: FSMAction[]) => void
  actionDefinitions?: { name: string; description?: string; parameters?: string }[]
  /** For `when` check field suggestions */
  stateVariables?: { key: string }[]
  /** Nesting budget for branch → nested ActionEditor (default 4). */
  depth?: number
}

export default function ActionEditor({
  actions,
  onChange,
  actionDefinitions,
  stateVariables,
  depth = 4,
}: ActionEditorProps) {
  const canNestBranch = depth > 0
  const serverAllowsInline = useAppConfigStore(selectAllowInlineCodeActions)
  const editorPref = getSettings().features?.inlineCodeActionsEditor ?? 'auto'
  const showCodeInKindSelect =
    editorPref === 'always' ? true : editorPref === 'never' ? false : serverAllowsInline

  const updateRow = useCallback(
    (idx: number, body: FSMActionRef, meta: ActionRowMeta) => {
      const c = [...actions]
      c[idx] = mergeActionMeta(body, meta)
      onChange(c)
    },
    [actions, onChange],
  )

  const remove = useCallback(
    (idx: number) => onChange(actions.filter((_, i) => i !== idx)),
    [actions, onChange],
  )

  const add = useCallback(() => onChange([...actions, '']), [actions, onChange])

  return (
    <div className="space-y-2">
      {actions.map((action, idx) => {
        const { body, meta } = splitActionMeta(action)
        const { kind, effectType = 'set' } = classifyPayload(body)
        const borderColor = BORDER[kind]

        const setMeta = (nextMeta: ActionRowMeta) => {
          updateRow(idx, body, nextMeta)
        }

        const setBody = (nextBody: FSMActionRef) => {
          updateRow(idx, nextBody, meta)
        }

        const changeKind = (newKind: ActionKind) => {
          const next = buildPayload(newKind, 'set')
          updateRow(idx, next, meta)
        }

        return (
          <div
            key={idx}
            className={`flex flex-col gap-2 rounded-md border p-2 border-l-4 ${borderColor}`}
          >
            {/* Header row: kind selector + inline fields (simple types) + remove button */}
            <div className="flex items-center gap-2">
              <select
                className="h-9 shrink-0 rounded-md border border-input bg-background px-2 text-sm"
                value={kind}
                onChange={(e) => changeKind(e.target.value as ActionKind)}
              >
                <option value="effect">Effect</option>
                <option value="http">HTTP</option>
                <option value="named">Named</option>
                {(showCodeInKindSelect || kind === 'code') && (
                  <option value="code">Code</option>
                )}
                {canNestBranch && <option value="conditional">Conditional</option>}
              </select>

              {/* Simple types render inline beside the kind selector */}
              {kind === 'named' && (
                <Input
                  className="h-9 min-w-0 flex-1"
                  placeholder="action name"
                  list={`action-suggestions-${idx}`}
                  value={getNamedBody(body).name}
                  onChange={(e) => {
                    const v = e.target.value.trim()
                    const nb = getNamedBody(body)
                    if (!v) setBody('')
                    else if (nb.params && Object.keys(nb.params).length > 0)
                      setBody({ name: v, params: nb.params })
                    else setBody({ name: v })
                  }}
                />
              )}

              {kind === 'effect' && (
                <div className="flex min-w-0 flex-1 flex-wrap items-center gap-2">
                  <select
                    className="h-9 rounded-md border border-input bg-background px-2 text-sm"
                    value={effectType}
                    onChange={(e) =>
                      setBody(buildPayload('effect', e.target.value as EffectType))
                    }
                  >
                    {EFFECT_TYPES.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                  {effectType === 'set' && (
                    <>
                      <Input
                        className="h-9 w-28"
                        placeholder="key"
                        value={getSetPair(body)[0]}
                        onChange={(e) =>
                          setBody({ set: { [e.target.value]: getSetPair(body)[1] } })
                        }
                      />
                      <Input
                        className="h-9 min-w-[8rem] flex-1"
                        placeholder="value"
                        value={getSetPair(body)[1]}
                        onChange={(e) =>
                          setBody({ set: { [getSetPair(body)[0]]: e.target.value } })
                        }
                      />
                    </>
                  )}
                  {SINGLE_FIELD_EFFECTS.includes(effectType) && (
                    <Input
                      className="h-9 min-w-[10rem] flex-1"
                      placeholder="field name"
                      value={getEffectField(body, effectType)}
                      onChange={(e) =>
                        setBody({ [effectType]: e.target.value } as FSMActionRef)
                      }
                    />
                  )}
                  {effectType === 'append' && (
                    <>
                      <Input
                        className="h-9 w-28"
                        placeholder="field"
                        value={getEffectField(body, 'append')}
                        onChange={(e) =>
                          setBody({
                            append: {
                              field: e.target.value,
                              value: getAppendValue(body),
                            },
                          })
                        }
                      />
                      <Input
                        className="h-9 min-w-[8rem] flex-1"
                        placeholder="value"
                        value={getAppendValue(body)}
                        onChange={(e) =>
                          setBody({
                            append: {
                              field: getEffectField(body, 'append'),
                              value: e.target.value,
                            },
                          })
                        }
                      />
                    </>
                  )}
                  {effectType === 'compute' && (
                    <ComputePairsEditor
                      pairs={getComputePairs(body)}
                      onChange={(pairs) => {
                        const compute: Record<string, string> = {}
                        for (const p of pairs) {
                          if (p.key.trim()) compute[p.key.trim()] = p.expr
                        }
                        setBody({ compute })
                      }}
                    />
                  )}
                </div>
              )}

              {kind === 'http' && (
                <div className="min-w-0 flex-1">
                  <HttpActionFields body={body} setBody={setBody} />
                </div>
              )}

              {/* Complex types use a spacer so the × button stays right-aligned */}
              {(kind === 'code' || kind === 'conditional') && <div className="flex-1" />}

              <button
                type="button"
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                onClick={() => remove(idx)}
                aria-label="Remove action"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Complex types render full-width below the header row */}
            {kind === 'code' && (
              <div>
                {!serverAllowsInline && (
                  <Alert className="mb-2 border-amber-200 bg-amber-50">
                    <AlertDescription className="text-amber-900 text-xs">
                      Inline code is disabled on the server (env or pystator.cfg). This action will
                      fail at runtime until an administrator enables it.
                    </AlertDescription>
                  </Alert>
                )}
                <FsmCodeActionEditor
                  editorId={`fsm-code-action-${idx}`}
                  value={getCodeSource(body)}
                  onChange={(source) => setBody({ code: { source } })}
                />
              </div>
            )}

            {kind === 'conditional' && canNestBranch && (
              <BranchFields
                body={body}
                setBody={setBody}
                depth={depth}
                actionDefinitions={actionDefinitions}
                stateVariables={stateVariables}
              />
            )}

            <ActionMetaStrip
              meta={meta}
              setMeta={setMeta}
              stateVariables={stateVariables}
              rowIndex={idx}
            />

            {actionDefinitions && actionDefinitions.length > 0 && (
              <datalist id={`action-suggestions-${idx}`}>
                {actionDefinitions.map((d) => (
                  <option key={d.name} value={d.name} />
                ))}
              </datalist>
            )}
          </div>
        )
      })}
      <Button type="button" variant="outline" size="sm" onClick={add} className="gap-1">
        <Plus className="h-3.5 w-3.5" />
        Add action
      </Button>
    </div>
  )
}

function ComputePairsEditor({
  pairs,
  onChange,
}: {
  pairs: { key: string; expr: string }[]
  onChange: (p: { key: string; expr: string }[]) => void
}) {
  return (
    <div className="flex w-full flex-col gap-1">
      {pairs.map((p, i) => (
        <div key={i} className="flex flex-wrap items-center gap-2">
          <Input
            className="h-9 w-28"
            placeholder="ctx key"
            value={p.key}
            onChange={(e) => {
              const c = [...pairs]
              c[i] = { ...c[i], key: e.target.value }
              onChange(c)
            }}
          />
          <Input
            className="h-9 min-w-[10rem] flex-1 font-mono text-xs"
            placeholder="expression"
            value={p.expr}
            onChange={(e) => {
              const c = [...pairs]
              c[i] = { ...c[i], expr: e.target.value }
              onChange(c)
            }}
          />
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-9 w-9 shrink-0"
            onClick={() => onChange(pairs.filter((_, j) => j !== i))}
            aria-label="Remove mapping"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      ))}
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="h-8 w-fit text-xs"
        onClick={() => onChange([...pairs, { key: '', expr: '' }])}
      >
        Add mapping
      </Button>
    </div>
  )
}

function HttpActionFields({
  body,
  setBody,
}: {
  body: FSMActionRef
  setBody: (b: FSMActionRef) => void
}) {
  const inner = getHttpInner(body)
  const url = String(inner.url ?? '')
  const method = String(inner.method ?? 'POST').toUpperCase()
  const rows = headersToRows(inner.headers)
  const bRaw = inner.body
  const bodyStr =
    bRaw === undefined || bRaw === null
      ? ''
      : typeof bRaw === 'string'
        ? bRaw
        : (() => {
            try {
              return JSON.stringify(bRaw, null, 2)
            } catch {
              return String(bRaw)
            }
          })()

  const onSuccess = isRecord(inner.on_success) ? inner.on_success : {}
  const statusKey = String(onSuccess.status_key ?? '')
  const bodyKey = String(onSuccess.body_key ?? '')
  const onError = ON_ERROR_MODES.includes(inner.on_error as (typeof ON_ERROR_MODES)[number])
    ? (inner.on_error as (typeof ON_ERROR_MODES)[number])
    : 'log'

  const buildOnSuccess = (sk: string, bk: string): Record<string, string> | undefined => {
    const o: Record<string, string> = {}
    if (sk.trim()) o.status_key = sk.trim()
    if (bk.trim()) o.body_key = bk.trim()
    return Object.keys(o).length > 0 ? o : undefined
  }

  const syncInner = (patch: Record<string, unknown>) => {
    setBody(mergeHttpInner(body, patch))
  }

  const setRows = (next: HeaderRow[]) => {
    syncInner({ headers: rowsToHeaders(next) })
  }

  return (
    <div className="flex flex-col gap-2 text-sm">
      <div className="flex flex-wrap gap-2">
        <select
          className="h-9 rounded-md border border-input bg-background px-2 text-sm"
          value={method}
          onChange={(e) => syncInner({ method: e.target.value })}
        >
          {HTTP_METHODS.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </select>
        <Input
          className="h-9 min-w-[12rem] flex-1"
          placeholder="URL (supports {{ var }} templates)"
          value={url}
          onChange={(e) => syncInner({ url: e.target.value })}
        />
      </div>
      <div className="text-muted-foreground text-xs">Headers</div>
      {rows.map((row, i) => (
        <div key={i} className="flex gap-2">
          <Input
            className="h-9 w-32"
            placeholder="name"
            value={row.key}
            onChange={(e) => {
              const c = [...rows]
              c[i] = { ...c[i], key: e.target.value }
              setRows(c)
            }}
          />
          <Input
            className="h-9 flex-1"
            placeholder="value"
            value={row.value}
            onChange={(e) => {
              const c = [...rows]
              c[i] = { ...c[i], value: e.target.value }
              setRows(c)
            }}
          />
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-9 w-9"
            onClick={() => setRows(rows.filter((_, j) => j !== i))}
            aria-label="Remove header"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      ))}
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="h-8 w-fit text-xs"
        onClick={() => setRows([...rows, { key: '', value: '' }])}
      >
        Add header
      </Button>
      <div className="text-muted-foreground text-xs">Body (JSON or plain text)</div>
      <textarea
        className="font-mono min-h-[72px] w-full rounded-md border border-input bg-background px-2 py-1.5 text-xs"
        value={bodyStr}
        onChange={(e) => {
          const t = e.target.value
          if (!t.trim()) {
            syncInner({ body: undefined })
            return
          }
          try {
            syncInner({ body: JSON.parse(t) as unknown })
          } catch {
            syncInner({ body: t })
          }
        }}
        spellCheck={false}
      />
      <div className="flex flex-wrap gap-2">
        <Input
          className="h-9 w-36"
          placeholder="on_success status_key"
          value={statusKey}
          onChange={(e) =>
            syncInner({
              on_success: buildOnSuccess(e.target.value, bodyKey),
            })
          }
        />
        <Input
          className="h-9 w-36"
          placeholder="on_success body_key"
          value={bodyKey}
          onChange={(e) =>
            syncInner({
              on_success: buildOnSuccess(statusKey, e.target.value),
            })
          }
        />
        <select
          className="h-9 rounded-md border border-input bg-background px-2 text-sm"
          value={onError}
          onChange={(e) => syncInner({ on_error: e.target.value })}
        >
          {ON_ERROR_MODES.map((m) => (
            <option key={m} value={m}>
              on_error: {m}
            </option>
          ))}
        </select>
      </div>
    </div>
  )
}

function ActionMetaStrip({
  meta,
  setMeta,
  stateVariables,
  rowIndex,
}: {
  meta: ActionRowMeta
  setMeta: (m: ActionRowMeta) => void
  stateVariables?: { key: string }[]
  rowIndex: number
}) {
  const fieldListId = `action-when-fields-${rowIndex}`
  const hasWhen = meta.when !== undefined && meta.when !== null && meta.when !== ''
  const whenStr = typeof meta.when === 'string' ? meta.when : ''
  const whenCheck =
    isRecord(meta.when) && 'field' in meta.when && 'op' in meta.when
      ? (meta.when as { field: string; op: string; value: unknown })
      : { field: '', op: 'eq', value: '' }

  return (
    <div className="rounded-md border border-dashed border-muted-foreground/30 bg-muted/10 px-2 py-1.5 text-xs">
      <div className="text-muted-foreground mb-1 font-medium">Optional: run when / timing</div>
      <label className="mb-1 flex items-center gap-2">
        <input
          type="checkbox"
          checked={hasWhen}
          onChange={(e) => {
            if (e.target.checked) {
              setMeta({ ...meta, when: { field: '', op: 'eq', value: '' } })
            } else {
              const { when: _w, ...rest } = meta
              setMeta(rest)
            }
          }}
        />
        Run only when (check or expression)
      </label>
      {hasWhen && (
        <div className="mt-2 space-y-2">
          <select
            className="h-8 rounded-md border border-input bg-background px-2 text-xs"
            value={typeof meta.when === 'string' ? 'expr' : 'check'}
            onChange={(e) => {
              if (e.target.value === 'expr') setMeta({ ...meta, when: whenStr || 'true' })
              else setMeta({ ...meta, when: whenCheck })
            }}
          >
            <option value="check">Field check</option>
            <option value="expr">Expression</option>
          </select>
          {typeof meta.when === 'string' ? (
            <Input
              className="h-8 font-mono text-xs"
              placeholder="e.g. ctx.total > 100"
              value={whenStr}
              onChange={(e) => setMeta({ ...meta, when: e.target.value })}
            />
          ) : (
            <div className="flex flex-wrap items-center gap-1.5">
              <Input
                className="h-8 w-24"
                placeholder="field"
                list={fieldListId}
                value={whenCheck.field}
                onChange={(e) =>
                  setMeta({ ...meta, when: { ...whenCheck, field: e.target.value } })
                }
              />
              {stateVariables && stateVariables.length > 0 && (
                <datalist id={fieldListId}>
                  {stateVariables.map((v) => (
                    <option key={v.key} value={v.key} />
                  ))}
                </datalist>
              )}
              <select
                className="h-8 rounded-md border border-input bg-background px-2 text-xs"
                value={whenCheck.op}
                onChange={(e) =>
                  setMeta({ ...meta, when: { ...whenCheck, op: e.target.value } })
                }
              >
                {CHECK_OPS.map((op) => (
                  <option key={op} value={op}>
                    {op}
                  </option>
                ))}
              </select>
              <Input
                className="h-8 w-24"
                placeholder="value"
                value={String(whenCheck.value ?? '')}
                onChange={(e) =>
                  setMeta({ ...meta, when: { ...whenCheck, value: e.target.value } })
                }
              />
            </div>
          )}
        </div>
      )}
      <div className="mt-2 flex flex-wrap gap-2">
        <Input
          className="h-8 w-28"
          type="number"
          step="any"
          placeholder="timeout (s)"
          value={meta.timeout ?? ''}
          onChange={(e) => {
            const v = e.target.value
            setMeta({
              ...meta,
              timeout: v === '' ? undefined : Number(v),
            })
          }}
        />
        <Input
          className="h-8 w-24"
          type="number"
          placeholder="retry"
          value={meta.retry ?? ''}
          onChange={(e) => {
            const v = e.target.value
            setMeta({
              ...meta,
              retry: v === '' ? undefined : Number(v),
            })
          }}
        />
        <Input
          className="h-8 w-28"
          type="number"
          step="any"
          placeholder="retry_backoff"
          value={meta.retry_backoff ?? ''}
          onChange={(e) => {
            const v = e.target.value
            setMeta({
              ...meta,
              retry_backoff: v === '' ? undefined : Number(v),
            })
          }}
        />
      </div>
    </div>
  )
}

function BranchFields({
  body,
  setBody,
  depth,
  actionDefinitions,
  stateVariables,
}: {
  body: FSMActionRef
  setBody: (b: FSMActionRef) => void
  depth: number
  actionDefinitions?: { name: string; description?: string; parameters?: string }[]
  stateVariables?: { key: string }[]
}) {
  const b = getBranch(body)
  const when = b.when
  const whenStr = typeof when === 'string' ? when : ''
  const whenCheck =
    isRecord(when) && 'field' in when && 'op' in when
      ? (when as { field: string; op: string; value: unknown })
      : { field: '', op: 'eq', value: '' }

  const patchBranch = (patch: Record<string, unknown>) => {
    const cur = getBranch(body)
    setBody({
      branch: {
        when: patch.when !== undefined ? patch.when : cur.when,
        then: (patch.then as FSMActionRef[] | undefined) ?? cur.then,
        else: (patch.else as FSMActionRef[] | undefined) ?? cur.else,
      },
    })
  }

  return (
    <div className="space-y-2 rounded-md border border-muted p-1.5">
      <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        Condition
      </div>
      <div className="flex items-center gap-1.5">
        <select
          className="h-8 shrink-0 rounded-md border border-input bg-background px-2 text-xs"
          value={typeof when === 'string' ? 'expr' : 'check'}
          onChange={(e) => {
            if (e.target.value === 'expr') patchBranch({ when: whenStr || 'true' })
            else patchBranch({ when: whenCheck })
          }}
        >
          <option value="check">Field check</option>
          <option value="expr">Expression</option>
        </select>
        {typeof when === 'string' ? (
          <Input
            className="h-8 min-w-0 flex-1 font-mono text-xs"
            value={whenStr}
            onChange={(e) => patchBranch({ when: e.target.value })}
          />
        ) : (
          <>
            <Input
              className="h-8 min-w-0 flex-1 text-xs"
              placeholder="field"
              value={whenCheck.field}
              onChange={(e) => patchBranch({ when: { ...whenCheck, field: e.target.value } })}
            />
            <select
              className="h-8 shrink-0 rounded-md border border-input bg-background px-1.5 text-xs"
              value={whenCheck.op}
              onChange={(e) => patchBranch({ when: { ...whenCheck, op: e.target.value } })}
            >
              {CHECK_OPS.map((op) => (
                <option key={op} value={op}>
                  {op}
                </option>
              ))}
            </select>
            <Input
              className="h-8 min-w-0 flex-1 text-xs"
              placeholder="value"
              value={String(whenCheck.value ?? '')}
              onChange={(e) => patchBranch({ when: { ...whenCheck, value: e.target.value } })}
            />
          </>
        )}
      </div>
      <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        Then
      </div>
      <ActionEditor
        actions={b.then}
        onChange={(then) => patchBranch({ then })}
        actionDefinitions={actionDefinitions}
        stateVariables={stateVariables}
        depth={depth - 1}
      />
      <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        Else
      </div>
      <ActionEditor
        actions={b.else}
        onChange={(elseList) => patchBranch({ else: elseList })}
        actionDefinitions={actionDefinitions}
        stateVariables={stateVariables}
        depth={depth - 1}
      />
    </div>
  )
}
