/** Shared observation-source helpers for create / edit draft dialogs. */

export const DEFAULT_OBS_CONTAINER = 'discovery_observations'
export const DEFAULT_ENTITY_COLUMN = 'entity_id'
export const DEFAULT_STATE_COLUMN = 'state'

export function supportsObservationSourceMapping(backend: string): boolean {
  const b = backend.toLowerCase()
  return (
    b === 'sqlite' ||
    b === 'postgres' ||
    b === 'postgresql' ||
    b === 'mongodb'
  )
}

export function isPostgresDiscoveryBackend(backend: string): boolean {
  const b = backend.toLowerCase()
  return b === 'postgres' || b === 'postgresql'
}

/** Build API ``observation_source``; ``null`` when defaults (native PyStator layout). */
export function observationSourcePayload(
  backend: string,
  container: string,
  entityCol: string,
  stateCol: string,
  schema?: string
): Record<string, unknown> | null {
  const c = container.trim()
  const e = entityCol.trim()
  const s = stateCol.trim()
  const sch = (schema ?? '').trim()
  const b = backend.toLowerCase()
  const isPg = isPostgresDiscoveryBackend(backend)
  if (!c || !e || !s) return null
  if (
    c === DEFAULT_OBS_CONTAINER &&
    e === DEFAULT_ENTITY_COLUMN &&
    s === DEFAULT_STATE_COLUMN &&
    (!isPg || sch === '')
  ) {
    return null
  }
  const field_mapping = { entity_id: e, state: s }
  if (b === 'mongodb') {
    return { collection_name: c, field_mapping }
  }
  const out: Record<string, unknown> = { table_name: c, field_mapping }
  if (isPg && sch) {
    out.schema_name = sch
  }
  return out
}

/** Reverse API payload into form fields for the edit dialog. */
export function observationSourceDictToFormFields(
  src: Record<string, unknown> | null | undefined,
  backend: string
): {
  obsSchema: string
  obsContainer: string
  entityIdColumn: string
  stateColumn: string
} {
  if (!src || typeof src !== 'object' || Object.keys(src).length === 0) {
    return {
      obsSchema: '',
      obsContainer: DEFAULT_OBS_CONTAINER,
      entityIdColumn: DEFAULT_ENTITY_COLUMN,
      stateColumn: DEFAULT_STATE_COLUMN,
    }
  }
  const b = backend.toLowerCase()
  const isPg = b === 'postgres' || b === 'postgresql'
  const explicitSchema =
    typeof src.schema_name === 'string' ? src.schema_name.trim() : ''
  let table = typeof src.table_name === 'string' ? src.table_name.trim() : ''
  const coll =
    typeof src.collection_name === 'string' ? src.collection_name : ''
  let obsSchema = ''
  let obsContainer: string
  if (isPg) {
    if (explicitSchema) {
      obsSchema = explicitSchema
      obsContainer = table || coll || DEFAULT_OBS_CONTAINER
    } else if (table.includes('.')) {
      const parts = table.split('.', 2)
      if (parts.length === 2 && parts[0] && parts[1]) {
        obsSchema = parts[0]
        obsContainer = parts[1]
      } else {
        obsContainer = table || coll || DEFAULT_OBS_CONTAINER
      }
    } else {
      obsContainer = table || coll || DEFAULT_OBS_CONTAINER
    }
  } else {
    obsContainer =
      b === 'mongodb'
        ? coll || table || DEFAULT_OBS_CONTAINER
        : table || coll || DEFAULT_OBS_CONTAINER
  }
  const fm = src.field_mapping
  let entityIdColumn = DEFAULT_ENTITY_COLUMN
  let stateColumn = DEFAULT_STATE_COLUMN
  if (fm && typeof fm === 'object' && !Array.isArray(fm)) {
    const f = fm as Record<string, unknown>
    if (typeof f.entity_id === 'string' && f.entity_id.trim()) {
      entityIdColumn = f.entity_id
    }
    if (typeof f.state === 'string' && f.state.trim()) {
      stateColumn = f.state
    }
  }
  return { obsSchema, obsContainer, entityIdColumn, stateColumn }
}
