'use client'

import type { ReactNode } from 'react'
import { WorkspaceDiscoveryProvider } from '@/components/discovery/WorkspaceDiscoveryContext'

/** Mounts discovery state only when the workspace main area is Discovery (avoids duplicate API load on Machines). */
export function WorkspaceDiscoveryProviderGate({
  enabled,
  children,
}: {
  enabled: boolean
  children: ReactNode
}) {
  if (!enabled) return <>{children}</>
  return <WorkspaceDiscoveryProvider>{children}</WorkspaceDiscoveryProvider>
}
