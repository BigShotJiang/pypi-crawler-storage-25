'use client'

import { Copy, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import type { EdgeLabelData } from '@/lib/fsmToReactFlow'

function formatUtcRange(isoStart: string, isoEnd: string): string {
  try {
    const s = new Date(isoStart).toISOString().slice(0, 16)
    const e = new Date(isoEnd).toISOString().slice(0, 16)
    return `${s}Z – ${e}Z`
  } catch {
    return `${isoStart} – ${isoEnd}`
  }
}

function formatDurationMs(ms: number | null): string {
  if (ms == null) return '—'
  if (ms >= 60_000) return `${(ms / 60_000).toFixed(1)} min`
  if (ms >= 1000) return `${(ms / 1000).toFixed(2)} s`
  return `${ms} ms`
}

function InfoRow({
  label,
  value,
  onCopy,
}: {
  label: string
  value: string
  onCopy: (text: string, label: string) => void
}) {
  return (
    <div className="space-y-1 rounded-md border bg-background px-3 py-2">
      <div className="flex items-center justify-between gap-2">
        <div className="text-xs font-semibold text-muted-foreground">{label}</div>
        <button
          type="button"
          className="inline-flex items-center gap-1 rounded px-1.5 py-1 text-xs text-muted-foreground hover:bg-muted hover:text-foreground"
          onClick={() => onCopy(value, label.toLowerCase())}
          aria-label={`Copy ${label}`}
          title={`Copy ${label}`}
        >
          <Copy className="h-3 w-3" />
          Copy
        </button>
      </div>
      <div className="font-mono text-xs whitespace-pre-wrap break-words">{value}</div>
    </div>
  )
}

type TransitionOpsRuntime = NonNullable<EdgeLabelData['transitionOpsSingle']>
type TransitionOpsGrouped = NonNullable<EdgeLabelData['transitionOpsGrouped']>
type TransitionOpsContext = NonNullable<EdgeLabelData['transitionOpsContext']>

function TopErrorBlock({
  top,
}: {
  top: NonNullable<TransitionOpsRuntime['topError']>
}) {
  return (
    <div className="space-y-1 rounded-md border bg-background px-2 py-2">
      <div className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
        Top error
      </div>
      <div className="text-[11px] font-medium">
        {(top.error_type ?? 'Error')}{' '}
        <span className="text-muted-foreground">({top.count})</span>
      </div>
      {top.error_message ? (
        <div className="text-[10px] text-muted-foreground whitespace-pre-wrap break-words">
          {top.error_message}
        </div>
      ) : null}
    </div>
  )
}

export function TransitionInfoPopover({
  title,
  subtitle,
  trigger,
  guards,
  actions,
  delay,
  region,
  timeout,
  onClose,
  onCopy,
  opsSingle,
  opsGrouped,
  opsContext,
}: {
  title: string
  subtitle: string
  trigger?: string | null
  guards?: string | null
  actions?: string | null
  delay?: string | null
  region?: string | null
  timeout?: string | null
  onClose: () => void
  onCopy: (text: string, label: string) => void
  opsSingle?: TransitionOpsRuntime | null
  opsGrouped?: TransitionOpsGrouped | null
  opsContext?: TransitionOpsContext | null
}) {
  const hasMeta =
    (delay != null && delay !== '') ||
    (region != null && region !== '') ||
    (timeout != null && timeout !== '')

  const hours = opsContext?.windowHours ?? 24
  const hasRuntime = Boolean(opsSingle) || Boolean(opsGrouped)

  return (
    <div className="w-[420px] max-w-[calc(100vw-48px)] rounded-lg border bg-background shadow-lg">
      <div className="flex items-start justify-between gap-3 border-b px-4 py-3">
        <div className="min-w-0">
          <div className="text-sm font-semibold">{title}</div>
          <div className="mt-1 font-mono text-[10px] text-muted-foreground truncate">{subtitle}</div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
          aria-label="Close"
          title="Close"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="space-y-2 p-4">
        {trigger ? <InfoRow label="Trigger" value={trigger} onCopy={onCopy} /> : null}
        {guards ? <InfoRow label="Guards" value={guards} onCopy={onCopy} /> : null}
        {actions ? <InfoRow label="Actions" value={actions} onCopy={onCopy} /> : null}

        {hasMeta ? (
          <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
            {delay ? <span>Delay: {delay}</span> : null}
            {region ? <span>Region: {region}</span> : null}
            {timeout ? <span>Timeout: {timeout}</span> : null}
          </div>
        ) : null}
      </div>

      {hasRuntime ? (
        <div className="space-y-3 border-t px-4 py-3 text-xs">
          <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
            Runtime (last {hours}h, UTC window)
          </div>
          {opsSingle ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2" title="Rows in transition_history in the window for this source, target, and trigger.">
                <span className="text-muted-foreground">Attempts</span>
                <span className="font-medium tabular-nums">{opsSingle.attemptsTotal}</span>
              </div>
              <div className="flex items-center justify-between gap-2" title="Rows with success=false.">
                <span className="text-muted-foreground">Failed</span>
                <span className="font-medium tabular-nums">{opsSingle.attemptsFailed}</span>
              </div>
              {opsSingle.durationP95Ms != null ? (
                <div
                  className="flex items-center justify-between gap-2"
                  title="P95 of recorded transition processing duration (ms) for this edge in the window."
                >
                  <span className="text-muted-foreground">Duration p95</span>
                  <span className="font-medium tabular-nums">{formatDurationMs(opsSingle.durationP95Ms)}</span>
                </div>
              ) : null}
              {opsSingle.topError ? <TopErrorBlock top={opsSingle.topError} /> : null}
            </div>
          ) : null}
          {opsGrouped ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2" title="Sum of attempts across triggers on this edge.">
                <span className="text-muted-foreground">Attempts (all triggers)</span>
                <span className="font-medium tabular-nums">{opsGrouped.aggregateAttempts}</span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-muted-foreground">Failed (all triggers)</span>
                <span className="font-medium tabular-nums">{opsGrouped.aggregateFailed}</span>
              </div>
              {opsGrouped.truncated ? (
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  Multiple triggers on this edge. Open the transition inspector for per-trigger details, or
                  reduce parallel transitions on the same source→target to see a per-trigger breakdown here.
                </p>
              ) : opsGrouped.lines.length > 0 ? (
                <div className="space-y-2 rounded-md bg-muted/30 px-2 py-2">
                  <div className="text-[10px] font-medium text-muted-foreground uppercase tracking-wide">
                    By trigger
                  </div>
                  {opsGrouped.lines.map((line) => (
                    <div key={line.trigger} className="border-b border-border/60 pb-2 last:border-0 last:pb-0">
                      <div className="font-mono text-[10px] text-foreground truncate" title={line.trigger}>
                        {line.trigger || '(no trigger)'}
                      </div>
                      <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-[10px]">
                        <span>
                          ok:{' '}
                          <span className="font-medium tabular-nums">
                            {Math.max(0, line.attemptsTotal - line.attemptsFailed)}
                          </span>
                        </span>
                        <span>
                          fail: <span className="font-medium tabular-nums">{line.attemptsFailed}</span>
                        </span>
                        {line.durationP95Ms != null ? (
                          <span>p95: {formatDurationMs(line.durationP95Ms)}</span>
                        ) : null}
                      </div>
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
          ) : null}
          {opsContext ? (
            <div className="border-t pt-2 text-[10px] leading-relaxed text-muted-foreground">
              <div className="font-mono truncate" title={opsContext.machineName}>
                Machine: {opsContext.machineName}
              </div>
              <div className="mt-1 font-mono break-all">{formatUtcRange(opsContext.windowStart, opsContext.windowEnd)}</div>
            </div>
          ) : null}
        </div>
      ) : null}

      <div className="flex justify-end border-t px-4 py-3">
        <Button type="button" onClick={onClose}>
          Done
        </Button>
      </div>
    </div>
  )
}
