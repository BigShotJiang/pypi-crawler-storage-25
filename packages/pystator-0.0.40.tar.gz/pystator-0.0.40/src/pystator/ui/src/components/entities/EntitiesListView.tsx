'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import ErrorDisplay from '@/components/ErrorDisplay'
import LoadingSpinner from '@/components/LoadingSpinner'
import EntityTable from '@/components/entities/EntityTable'
import EntityOverviewPanel from '@/components/entities/EntityOverviewPanel'
import BulkActionToolbar from '@/components/entities/BulkActionToolbar'
import CreateEntityModal from '@/components/entities/CreateEntityModal'
import { EntitiesListToolbar } from '@/components/entities/EntitiesListToolbar'
import { useEntityListStore } from '@/stores/entity-list'
import type { EntityListAggregates } from '@/stores/entity-list'
import { listMachines, deleteEntity, getMachine } from '@/lib/api'
import type { EntityState, MachineListItem } from '@/lib/api'
import { stringifyFsmConfig } from '@/lib/fsmConfigParse'
import { ChevronLeft, ChevronRight, ChevronsLeft, Plus, X } from 'lucide-react'
import { cursorStackPageNumber } from '@/lib/entityListCursorPagination'

/** Resolve list row when several machine versions share the same name (prefer most recently updated). */
function pickMachineListItemForName(
  machineList: MachineListItem[],
  machineName: string
): MachineListItem | null {
  const matches = machineList.filter((m) => m.name === machineName)
  if (matches.length === 0) return null
  if (matches.length === 1) return matches[0]
  return [...matches].sort((a, b) => {
    const ta = a.updated_at ? new Date(a.updated_at).getTime() : 0
    const tb = b.updated_at ? new Date(b.updated_at).getTime() : 0
    return tb - ta
  })[0]
}

type StatusFilter = 'active' | 'archived' | 'deleted' | 'all'

const STATUS_OPTIONS: { baseLabel: string; value: StatusFilter }[] = [
  { baseLabel: 'Active', value: 'active' },
  { baseLabel: 'Archived', value: 'archived' },
  { baseLabel: 'Deleted', value: 'deleted' },
  { baseLabel: 'All', value: 'all' },
]

function statusFilterButtonLabel(value: StatusFilter, agg: EntityListAggregates | null): string {
  const opt = STATUS_OPTIONS.find((o) => o.value === value)
  const base = opt?.baseLabel ?? value
  if (!agg) return base
  const { status } = agg
  if (value === 'active') return `${base} (${status.active.toLocaleString()})`
  if (value === 'archived') return `${base} (${status.archived.toLocaleString()})`
  if (value === 'deleted') return `${base} (${status.deleted.toLocaleString()})`
  const all = status.active + status.archived + status.deleted
  return `${base} (${all.toLocaleString()})`
}

export interface EntitiesListViewProps {
  /**
   * When true, pauses the list auto-refresh timer (e.g. full-page detail view or metrics panel open).
   */
  pauseAutoRefresh: boolean
  /** Row click: open side panel, navigate, etc. */
  onEntityOpen: (entity: EntityState) => void
  /**
   * View icon in the actions column. When omitted, matches `onEntityOpen` (e.g. legacy list navigates on both).
   */
  onEntityViewDetail?: (entity: EntityState) => void
  /** After creating an entity from the modal. */
  onEntityCreated: (entityId: string) => void
  /**
   * When false, the create/refresh toolbar is hidden (use with {@link EntitiesListToolbar} in PageHeader).
   * In that case pass controlled modal props so the header can open the create dialog.
   */
  showToolbar?: boolean
  createModalOpen?: boolean
  onCreateModalOpenChange?: (open: boolean) => void
  /** Invoked after the user triggers a manual list refresh (toolbar Refresh). */
  onAfterManualRefresh?: () => void
  /** When true, the overview card starts expanded. */
  overviewDefaultExpanded?: boolean
}

/**
 * Entity list: overview, filters, table, pagination, bulk actions, and create modal.
 */
export function EntitiesListView({
  pauseAutoRefresh,
  onEntityOpen,
  onEntityViewDetail,
  onEntityCreated,
  showToolbar = true,
  createModalOpen: createModalOpenProp,
  onCreateModalOpenChange,
  onAfterManualRefresh,
  overviewDefaultExpanded = false,
}: EntitiesListViewProps) {
  const entities = useEntityListStore((s) => s.entities)
  const total = useEntityListStore((s) => s.total)
  const aggregates = useEntityListStore((s) => s.aggregates)
  const loading = useEntityListStore((s) => s.loading)
  const storeError = useEntityListStore((s) => s.error)
  const filterMachine = useEntityListStore((s) => s.filterMachine)
  const filterState = useEntityListStore((s) => s.filterState)
  const filterStatus = useEntityListStore((s) => s.filterStatus)
  const searchText = useEntityListStore((s) => s.searchText)
  const sortBy = useEntityListStore((s) => s.sortBy)
  const sortOrder = useEntityListStore((s) => s.sortOrder)
  const cursorStack = useEntityListStore((s) => s.cursorStack)
  const nextCursor = useEntityListStore((s) => s.nextCursor)
  const selectedIds = useEntityListStore((s) => s.selectedIds)
  const autoRefreshInterval = useEntityListStore((s) => s.autoRefreshInterval)

  const fetchEntities = useEntityListStore((s) => s.fetchEntities)
  const goNextPage = useEntityListStore((s) => s.goNextPage)
  const goPrevPage = useEntityListStore((s) => s.goPrevPage)
  const goFirstPage = useEntityListStore((s) => s.goFirstPage)
  const setFilterMachine = useEntityListStore((s) => s.setFilterMachine)
  const setFilterState = useEntityListStore((s) => s.setFilterState)
  const setFilterStatus = useEntityListStore((s) => s.setFilterStatus)
  const setSearchText = useEntityListStore((s) => s.setSearchText)
  const toggleSort = useEntityListStore((s) => s.toggleSort)
  const toggleSelect = useEntityListStore((s) => s.toggleSelect)
  const toggleSelectAll = useEntityListStore((s) => s.toggleSelectAll)
  const clearSelection = useEntityListStore((s) => s.clearSelection)
  const setAutoRefreshPaused = useEntityListStore((s) => s.setAutoRefreshPaused)

  const [machines, setMachines] = useState<MachineListItem[]>([])
  const [downloadingEntityId, setDownloadingEntityId] = useState<string | null>(null)
  const [internalCreateOpen, setInternalCreateOpen] = useState(false)
  const [localError, setLocalError] = useState<Error | null>(null)

  const isModalControlled =
    createModalOpenProp !== undefined && onCreateModalOpenChange !== undefined
  const createModalOpen = isModalControlled ? createModalOpenProp : internalCreateOpen
  const setCreateModalOpen = isModalControlled ? onCreateModalOpenChange! : setInternalCreateOpen

  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const [searchInput, setSearchInput] = useState(searchText)

  const handleSearchInputChange = (value: string) => {
    setSearchInput(value)
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      setSearchText(value)
    }, 300)
  }

  useEffect(() => {
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current)
    }
  }, [])

  useEffect(() => {
    listMachines()
      .then((res) => setMachines(res.machines))
      .catch(() => {})
  }, [])

  useEffect(() => {
    fetchEntities()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (autoRefreshInterval === 0 || pauseAutoRefresh) return
    const intervalId = setInterval(() => {
      fetchEntities()
    }, autoRefreshInterval)
    return () => clearInterval(intervalId)
  }, [autoRefreshInterval, pauseAutoRefresh, fetchEntities])

  useEffect(() => {
    setAutoRefreshPaused(pauseAutoRefresh)
  }, [pauseAutoRefresh, setAutoRefreshPaused])

  const handleDelete = async (entity: EntityState) => {
    const confirmed = window.confirm(
      `Delete entity "${entity.entity_id}"? This will remove its state and history.`
    )
    if (!confirmed) return
    try {
      await deleteEntity(entity.entity_id)
      await fetchEntities()
    } catch (e) {
      setLocalError(e instanceof Error ? e : new Error(String(e)))
    }
  }

  const handleCreateSuccess = useCallback(
    (createdEntityId: string) => {
      onEntityCreated(createdEntityId)
      fetchEntities()
    },
    [onEntityCreated, fetchEntities]
  )

  const handleDownloadMachineConfig = useCallback(
    async (entity: EntityState) => {
      const name = entity.machine_name?.trim()
      if (!name) {
        setLocalError(new Error('This entity has no machine name.'))
        return
      }
      const picked = pickMachineListItemForName(machines, name)
      if (!picked) {
        setLocalError(new Error(`No machine definition found for "${name}".`))
        return
      }
      setLocalError(null)
      setDownloadingEntityId(entity.entity_id)
      try {
        const res = await getMachine(picked.id)
        const content = stringifyFsmConfig(res.config, 'yaml')
        const blob = new Blob([content], { type: 'application/x-yaml' })
        const url = URL.createObjectURL(blob)
        const link = document.createElement('a')
        link.href = url
        link.download = `${res.name}_v${res.version}.yaml`
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
        URL.revokeObjectURL(url)
      } catch (e) {
        setLocalError(e instanceof Error ? e : new Error(String(e)))
      } finally {
        setDownloadingEntityId(null)
      }
    },
    [machines]
  )

  const handleClearFilters = () => {
    setFilterMachine('')
    setFilterState('')
    setFilterStatus('active')
    setSearchInput('')
    setSearchText('')
  }

  const hasFilters = filterMachine || filterState || filterStatus !== 'active' || searchText

  const currentPage = cursorStackPageNumber(cursorStack)
  const hasPrev = cursorStack.length > 0
  const hasNext = nextCursor !== null

  const displayError = localError ?? (storeError ? new Error(storeError) : null)

  const actionRow =
    showToolbar ? (
      <EntitiesListToolbar
        onCreateClick={() => setCreateModalOpen(true)}
        onAfterManualRefresh={onAfterManualRefresh}
      />
    ) : null

  return (
    <>
      {actionRow ? <div className="flex flex-wrap items-center gap-2">{actionRow}</div> : null}

      <div className="mt-4">
        <EntityOverviewPanel
          total={
            aggregates != null
              ? aggregates.status.active + aggregates.status.archived + aggregates.status.deleted
              : total
          }
          workflow={aggregates?.workflow ?? null}
          defaultExpanded={overviewDefaultExpanded}
        />
      </div>

      {selectedIds.size > 0 && (
        <div className="mt-4">
          <BulkActionToolbar
            selectedCount={selectedIds.size}
            selectedIds={selectedIds}
            onClearSelection={clearSelection}
            onRefresh={fetchEntities}
          />
        </div>
      )}

      <div className="mt-4 flex flex-wrap items-end gap-3 rounded-lg border bg-muted/30 p-3">
        <div className="flex flex-col gap-1">
          <Label className="text-xs text-muted-foreground">Search Entity ID</Label>
          <Input
            type="text"
            placeholder="Search..."
            className="w-[180px] h-8 text-sm"
            value={searchInput}
            onChange={(e) => handleSearchInputChange(e.target.value)}
          />
        </div>

        <div className="flex flex-col gap-1">
          <Label className="text-xs text-muted-foreground">Status</Label>
          <div className="flex rounded-md border divide-x overflow-hidden">
            {STATUS_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setFilterStatus(opt.value)}
                className={`px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                  filterStatus === opt.value
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-background text-muted-foreground hover:bg-muted'
                }`}
              >
                {statusFilterButtonLabel(opt.value, aggregates)}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-1">
          <Label className="text-xs text-muted-foreground">Machine</Label>
          <select
            className="rounded-md border border-input bg-background px-2 py-1.5 text-sm min-w-[180px]"
            value={filterMachine}
            onChange={(e) => setFilterMachine(e.target.value)}
          >
            <option value="">All machines</option>
            {machines.map((m) => (
              <option key={m.id} value={m.name}>
                {m.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-1">
          <Label className="text-xs text-muted-foreground">State</Label>
          <input
            type="text"
            placeholder="e.g. pending"
            className="rounded-md border border-input bg-background px-2 py-1.5 text-sm w-[160px]"
            value={filterState}
            onChange={(e) => setFilterState(e.target.value)}
          />
        </div>

        {hasFilters && (
          <Button variant="ghost" size="sm" onClick={handleClearFilters} className="gap-1.5">
            <X className="h-3.5 w-3.5" /> Clear
          </Button>
        )}
      </div>

      {displayError && <ErrorDisplay error={displayError} className="mt-4" />}

      <div className="mt-6">
        {loading && entities.length === 0 ? (
          <div className="flex justify-center py-12">
            <LoadingSpinner />
          </div>
        ) : entities.length === 0 && !loading ? (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">No entities found</CardTitle>
              <CardDescription>
                Create an entity with the button above, or send events via the Entity API.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" size="sm" onClick={() => setCreateModalOpen(true)} className="gap-1.5">
                <Plus className="h-4 w-4" /> Create entity
              </Button>
            </CardContent>
          </Card>
        ) : (
          <>
            <EntityTable
              entities={entities}
              onView={onEntityOpen}
              onViewIconClick={onEntityViewDetail ?? onEntityOpen}
              onDelete={handleDelete}
              onDownloadMachineConfig={handleDownloadMachineConfig}
              downloadingEntityId={downloadingEntityId}
              selectedIds={selectedIds}
              onToggleSelect={toggleSelect}
              onToggleSelectAll={toggleSelectAll}
              sortBy={sortBy}
              sortOrder={sortOrder}
              onSort={toggleSort}
            />

            <div className="flex items-center justify-between mt-4">
              <p className="text-sm text-muted-foreground">
                Page {currentPage} &middot; {total} total
              </p>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={!hasPrev}
                  onClick={goFirstPage}
                  title="First page"
                >
                  <ChevronsLeft className="h-4 w-4 mr-1" /> First
                </Button>
                <Button variant="outline" size="sm" disabled={!hasPrev} onClick={goPrevPage}>
                  <ChevronLeft className="h-4 w-4 mr-1" /> Prev
                </Button>
                <Button variant="outline" size="sm" disabled={!hasNext} onClick={goNextPage}>
                  Next <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </div>
          </>
        )}
      </div>

      <CreateEntityModal
        open={createModalOpen}
        onOpenChange={setCreateModalOpen}
        onSuccess={handleCreateSuccess}
      />
    </>
  )
}
