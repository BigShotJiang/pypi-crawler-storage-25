'use client'

import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import type { DiscoveryDraftFilterInput } from '@/lib/api'
import {
  discoverySlugHint,
  isValidDiscoverySlug,
} from '@/lib/discoveryNames'
import {
  DEFAULT_OBS_CONTAINER,
  isPostgresDiscoveryBackend,
  supportsObservationSourceMapping,
} from './draftObservationSourceForm'
import { DiscoveryFilterBuilder } from './DiscoveryFilterBuilder'

export type DiscoveryDraftCoreFieldsProps = {
  idPrefix: string
  title: string
  onTitleChange: (v: string) => void
  filter: DiscoveryDraftFilterInput
  onFilterChange: (v: DiscoveryDraftFilterInput) => void
  showFilter: boolean
  onShowFilterChange: (v: boolean) => void
  showThresholds: boolean
  onShowThresholdsChange: (v: boolean) => void
  minEdgeCount: string
  onMinEdgeCountChange: (v: string) => void
  minConfidence: string
  onMinConfidenceChange: (v: string) => void
  defaultMinEdgeCount: string
  defaultMinConfidence: string
  /** PostgreSQL search_path / namespace for the observation table (optional). */
  obsSchema: string
  onObsSchemaChange: (v: string) => void
  obsContainer: string
  onObsContainerChange: (v: string) => void
  entityIdColumn: string
  onEntityIdColumnChange: (v: string) => void
  stateColumn: string
  onStateColumnChange: (v: string) => void
  /** Native `discovery_observations` layout; enables row edits in the Observations panel. */
  useDefaultObservationStorage: boolean
  onUseDefaultObservationStorageChange: (v: boolean) => void
  selectedBackend: string
  /** Inline validation / submit error */
  error: string | null
}

/**
 * Draft name, observation storage, scope filter, and inference thresholds —
 * same fields as the create-draft dialog (without connection picker).
 */
export function DiscoveryDraftCoreFields({
  idPrefix,
  title,
  onTitleChange,
  filter,
  onFilterChange,
  showFilter,
  onShowFilterChange,
  showThresholds,
  onShowThresholdsChange,
  minEdgeCount,
  onMinEdgeCountChange,
  minConfidence,
  onMinConfidenceChange,
  defaultMinEdgeCount,
  defaultMinConfidence,
  obsSchema,
  onObsSchemaChange,
  obsContainer,
  onObsContainerChange,
  entityIdColumn,
  onEntityIdColumnChange,
  stateColumn,
  onStateColumnChange,
  useDefaultObservationStorage,
  onUseDefaultObservationStorageChange,
  selectedBackend,
  error,
}: DiscoveryDraftCoreFieldsProps) {
  const obsSourceSupported = supportsObservationSourceMapping(selectedBackend)
  const showPgSchema = isPostgresDiscoveryBackend(selectedBackend)
  const titleOk = isValidDiscoverySlug(title)

  return (
    <div className="grid gap-3 py-0">
      <div className="space-y-1">
        <Label htmlFor={`${idPrefix}-title`} className="text-xs">
          Draft name
        </Label>
        <Input
          id={`${idPrefix}-title`}
          placeholder="happy_path_orders"
          value={title}
          onChange={(e) => onTitleChange(e.target.value)}
          autoFocus
          aria-invalid={title.length > 0 && !titleOk}
        />
        <p className="text-[11px] text-muted-foreground">
          Unique slug per connection (this draft&apos;s id). The API still uses
          the same slug in the{' '}
          <code className="rounded bg-muted px-0.5">
            /machines/&#123;…&#125;/drafts
          </code>{' '}
          path for routing; it is not your observation-channel list.{' '}
          {discoverySlugHint()}
        </p>
      </div>

      <div className="border-t pt-3">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Observation storage
        </p>
        <div className="mt-2 flex items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <Label
              htmlFor={`${idPrefix}-obs-use-default`}
              className="text-xs font-medium text-foreground"
            >
              Use default observation storage
            </Label>
            <p className="text-[11px] leading-snug text-muted-foreground">
              {useDefaultObservationStorage
                ? 'Built-in table and columns; the Observations panel supports insert, delete, and row actions.'
                : 'Custom table or column names; row actions in the Observations panel stay disabled.'}
            </p>
          </div>
          <Switch
            id={`${idPrefix}-obs-use-default`}
            className="mt-0.5 shrink-0"
            checked={useDefaultObservationStorage}
            onCheckedChange={onUseDefaultObservationStorageChange}
            disabled={!obsSourceSupported}
            title={
              !obsSourceSupported
                ? 'This connection type only supports default observation storage'
                : undefined
            }
          />
        </div>
        {!useDefaultObservationStorage ? (
          <div className="mt-3 grid gap-2">
            {showPgSchema ? (
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                <div className="space-y-1">
                  <Label htmlFor={`${idPrefix}-obs-schema`} className="text-xs">
                    Schema (optional)
                  </Label>
                  <Input
                    id={`${idPrefix}-obs-schema`}
                    className="h-9 font-mono text-sm"
                    value={obsSchema}
                    onChange={(e) => onObsSchemaChange(e.target.value)}
                    placeholder="public"
                    disabled={!obsSourceSupported}
                    autoComplete="off"
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor={`${idPrefix}-obs-container`} className="text-xs">
                    Table name
                  </Label>
                  <Input
                    id={`${idPrefix}-obs-container`}
                    className="h-9 font-mono text-sm"
                    value={obsContainer}
                    onChange={(e) => onObsContainerChange(e.target.value)}
                    placeholder={DEFAULT_OBS_CONTAINER}
                    disabled={!obsSourceSupported}
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-1">
                <Label htmlFor={`${idPrefix}-obs-container`} className="text-xs">
                  {selectedBackend.toLowerCase() === 'mongodb'
                    ? 'Collection name'
                    : 'Table name'}
                </Label>
                <Input
                  id={`${idPrefix}-obs-container`}
                  className="h-9 font-mono text-sm"
                  value={obsContainer}
                  onChange={(e) => onObsContainerChange(e.target.value)}
                  placeholder={DEFAULT_OBS_CONTAINER}
                  disabled={!obsSourceSupported}
                />
              </div>
            )}
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label htmlFor={`${idPrefix}-obs-entity`} className="text-xs">
                  Entity id column
                </Label>
                <Input
                  id={`${idPrefix}-obs-entity`}
                  className="h-9 font-mono text-sm"
                  value={entityIdColumn}
                  onChange={(e) => onEntityIdColumnChange(e.target.value)}
                  placeholder="entity_id"
                  disabled={!obsSourceSupported}
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor={`${idPrefix}-obs-state`} className="text-xs">
                  State column
                </Label>
                <Input
                  id={`${idPrefix}-obs-state`}
                  className="h-9 font-mono text-sm"
                  value={stateColumn}
                  onChange={(e) => onStateColumnChange(e.target.value)}
                  placeholder="state"
                  disabled={!obsSourceSupported}
                />
              </div>
            </div>
            {!obsSourceSupported ? (
              <p className="text-[11px] text-muted-foreground">
                This connection type does not support reading from a custom
                table or collection. Use SQLite, PostgreSQL, or MongoDB to point
                inference at non-default storage.
              </p>
            ) : (
              <p className="text-[11px] text-muted-foreground">
                Defaults match the native{' '}
                <code className="rounded bg-muted px-0.5">
                  {DEFAULT_OBS_CONTAINER}
                </code>{' '}
                layout
                {showPgSchema
                  ? ' (set schema when observations live outside the default search path)'
                  : ''}
                . Other columns (e.g.{' '}
                <code className="rounded bg-muted px-0.5">machine_name</code>,{' '}
                <code className="rounded bg-muted px-0.5">observed_at</code>)
                must still exist under their usual names for filters to work.
              </p>
            )}
          </div>
        ) : null}
      </div>

      <div className="border-t pt-3">
        <button
          type="button"
          className="flex w-full items-center justify-between text-left text-xs font-semibold uppercase tracking-wide text-muted-foreground hover:text-foreground"
          onClick={() => onShowFilterChange(!showFilter)}
        >
          <span>Advanced scope (filter)</span>
          <span>{showFilter ? 'Hide' : 'Show'}</span>
        </button>
        {showFilter ? (
          <div className="mt-2">
            <DiscoveryFilterBuilder value={filter} onChange={onFilterChange} />
          </div>
        ) : (
          <p className="mt-1 text-[11px] text-muted-foreground">
            With no scope filter saved, preview/build use legacy single-channel
            scope for the route slug above—not all channels. Open Advanced to
            list one or more observation channels (textarea: one per line or
            comma-separated).
          </p>
        )}
      </div>

      <div className="border-t pt-3">
        <button
          type="button"
          className="flex w-full items-center justify-between text-left text-xs font-semibold uppercase tracking-wide text-muted-foreground hover:text-foreground"
          onClick={() => onShowThresholdsChange(!showThresholds)}
        >
          <span>Thresholds (inference)</span>
          <span>{showThresholds ? 'Hide' : 'Show'}</span>
        </button>
        {showThresholds ? (
          <div className="mt-2 grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label htmlFor={`${idPrefix}-min-edge`} className="text-xs">
                Min edge count
              </Label>
              <Input
                id={`${idPrefix}-min-edge`}
                type="number"
                min={1}
                step={1}
                value={minEdgeCount}
                onChange={(e) => onMinEdgeCountChange(e.target.value)}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor={`${idPrefix}-min-conf`} className="text-xs">
                Min confidence
              </Label>
              <Input
                id={`${idPrefix}-min-conf`}
                type="number"
                min={0}
                max={1}
                step={0.05}
                value={minConfidence}
                onChange={(e) => onMinConfidenceChange(e.target.value)}
              />
            </div>
          </div>
        ) : (
          <p className="mt-1 text-[11px] text-muted-foreground">
            Defaults to engine settings (currently min edge count{' '}
            {defaultMinEdgeCount}, min confidence {defaultMinConfidence}).
          </p>
        )}
      </div>

      {error ? (
        <p className="text-xs text-destructive" role="alert">
          {error}
        </p>
      ) : null}
    </div>
  )
}
