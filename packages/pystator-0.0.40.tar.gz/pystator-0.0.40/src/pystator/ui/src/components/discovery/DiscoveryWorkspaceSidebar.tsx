'use client'

import { DiscoveryFleetIndexPanel } from '@/components/discovery/DiscoveryFleetIndexPanel'
import { SidebarPanelToggleButton, type SidebarLayoutApi } from '@/components/layout'
import type { UseDiscoveryFleetIndexResult } from '@/hooks/useDiscoveryFleetIndex'
import { cn } from '@/lib/utils'

export interface DiscoveryWorkspaceSidebarProps {
  api: SidebarLayoutApi
  fleet: UseDiscoveryFleetIndexResult
  workspaceMachineName: string
  onOpenMachine: (name: string) => void | Promise<void>
}

/**
 * Left rail originally built for the standalone `/discovery` app route (deprecated; see
 * `LEGACY_DISCOVERY_APP_ROUTE` in `@/lib/constants`). Kept for reference only — use Workspace
 * Discovery (`/workspace/?area=discovery`) going forward.
 * Used with {@link ResizableWorkspaceLayout} (resizable drag handle, same defaults as Workspace).
 */
export function DiscoveryWorkspaceSidebar({
  api,
  fleet,
  workspaceMachineName,
  onOpenMachine,
}: DiscoveryWorkspaceSidebarProps) {
  const { isPanelCollapsed, sidebarDisplayMode, onCollapseRequested, onExpandRequested } = api
  const isCompact = sidebarDisplayMode === 'compact'
  const showLabels = !isPanelCollapsed && !isCompact

  return (
    <div className="flex h-full min-h-0 flex-col border-r border-border/50 bg-muted/20">
      <div
        className={cn(
          'flex shrink-0 items-center gap-2 border-b border-border/50 bg-muted/30 px-4 py-3',
          isPanelCollapsed ? 'justify-center' : 'justify-between'
        )}
      >
        {showLabels && (
          <span className="truncate px-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Fleet
          </span>
        )}
        <SidebarPanelToggleButton
          isCollapsed={isPanelCollapsed}
          onToggle={() =>
            isPanelCollapsed ? onExpandRequested() : onCollapseRequested()
          }
        />
      </div>

      <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
        {!isPanelCollapsed && (
          <DiscoveryFleetIndexPanel
            variant="sidebarRail"
            fleet={fleet}
            workspaceMachineName={workspaceMachineName}
            onOpenMachine={onOpenMachine}
          />
        )}
      </div>
    </div>
  )
}
