'use client'

import { Button } from '@/components/ui/button'
import { DiscoveryFetchObservationEntitiesButton } from '@/components/discovery/DiscoveryRecipeWorkspacePanel'
import type { UseDiscoveryWorkspaceResult } from '@/hooks/useDiscoveryWorkspace'
import { Eye, Loader2, Plus, Wrench } from 'lucide-react'

export function DiscoveryRightPanelBottomToolbar({
  d,
  onOpenObservation,
  canRunScope,
  canBuild,
  showPreviewBuild = true,
}: {
  d: UseDiscoveryWorkspaceResult
  onOpenObservation: () => void
  canRunScope: boolean
  canBuild: boolean
  /** When false, Preview/Build are omitted (e.g. shown in the overlay toolbar). */
  showPreviewBuild?: boolean
}) {
  return (
    <div className="flex flex-wrap items-center gap-x-2 gap-y-2 border-b border-border/50 bg-muted/20 px-3 py-2">
      <Button
        type="button"
        size="sm"
        variant="outline"
        className="h-8"
        onClick={onOpenObservation}
        title="Record observation"
      >
        <Plus className="mr-1 h-3.5 w-3.5 opacity-80" />
        Observation
      </Button>
      <DiscoveryFetchObservationEntitiesButton d={d} compact />
      <span className="select-none text-muted-foreground/50" aria-hidden>
        |
      </span>
      {showPreviewBuild ? (
        <div className="ml-auto flex items-center gap-2">
          <Button
            type="button"
            size="sm"
            variant="outline"
            className="relative h-8"
            disabled={!canRunScope || d.previewLoading}
            onClick={() => void d.preview()}
          >
            {d.previewLoading ? (
              <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
            ) : (
              <Eye className="mr-1.5 h-3.5 w-3.5" />
            )}
            Preview
            {d.previewStale && !d.previewLoading && (
              <span
                className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-amber-500"
                title="Preview is outdated — click to refresh"
              />
            )}
          </Button>
          <Button
            type="button"
            size="sm"
            className="h-8"
            disabled={!canBuild || d.building}
            onClick={() => void d.build()}
          >
            {d.building ? (
              <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
            ) : (
              <Wrench className="mr-1.5 h-3.5 w-3.5" />
            )}
            Build candidate
          </Button>
        </div>
      ) : null}
    </div>
  )
}
