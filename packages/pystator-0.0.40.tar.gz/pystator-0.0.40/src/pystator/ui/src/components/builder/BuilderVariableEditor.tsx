'use client'

import { useState, useCallback } from 'react'
import { Plus, Pencil, Trash2, Check, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useBuilderStore } from '@/stores/builder'
import type { FSMStateVariable } from '@/lib/types/fsm'

const VARIABLE_TYPES = ['string', 'number', 'boolean'] as const

interface InlineFormState {
  key: string
  type: string
  description: string
}

const EMPTY_FORM: InlineFormState = { key: '', type: 'string', description: '' }

export interface BuilderVariableEditorProps {
  /** When provided, overrides the builder store. */
  variables?: FSMStateVariable[]
  onAdd?: (v: FSMStateVariable) => void
  onUpdate?: (index: number, v: FSMStateVariable) => void
  onRemove?: (index: number) => void
}

export function BuilderVariableEditor(props: BuilderVariableEditorProps = {}) {
  const storeVariables = useBuilderStore((s) => s.variables)
  const storeAdd = useBuilderStore((s) => s.addVariable)
  const storeUpdate = useBuilderStore((s) => s.updateVariable)
  const storeRemove = useBuilderStore((s) => s.removeVariable)

  const variables = props.variables ?? storeVariables
  const addVariable = props.onAdd ?? storeAdd
  const updateVariable = props.onUpdate ?? storeUpdate
  const removeVariable = props.onRemove ?? storeRemove

  const [editingIndex, setEditingIndex] = useState<number | null>(null)
  const [adding, setAdding] = useState(false)
  const [form, setForm] = useState<InlineFormState>(EMPTY_FORM)

  const startAdd = useCallback(() => {
    setAdding(true)
    setEditingIndex(null)
    setForm(EMPTY_FORM)
  }, [])

  const startEdit = useCallback(
    (index: number) => {
      const v = variables[index]
      setEditingIndex(index)
      setAdding(false)
      setForm({ key: v.key, type: v.type ?? 'string', description: v.description ?? '' })
    },
    [variables],
  )

  const cancelEdit = useCallback(() => {
    setEditingIndex(null)
    setAdding(false)
    setForm(EMPTY_FORM)
  }, [])

  const confirmAdd = useCallback(() => {
    if (!form.key.trim()) return
    const variable: FSMStateVariable = {
      key: form.key.trim(),
      type: form.type,
      description: form.description.trim() || undefined,
    }
    addVariable(variable)
    setAdding(false)
    setForm(EMPTY_FORM)
  }, [form, addVariable])

  const confirmEdit = useCallback(() => {
    if (editingIndex === null || !form.key.trim()) return
    const variable: FSMStateVariable = {
      key: form.key.trim(),
      type: form.type,
      description: form.description.trim() || undefined,
    }
    updateVariable(editingIndex, variable)
    setEditingIndex(null)
    setForm(EMPTY_FORM)
  }, [editingIndex, form, updateVariable])

  const isDuplicate =
    form.key.trim() !== '' &&
    variables.some(
      (v, i) =>
        i !== editingIndex &&
        v.key.trim().toLowerCase() === form.key.trim().toLowerCase()
    )

  return (
    <div className="flex flex-col gap-2">
      {variables.map((v, idx) =>
        editingIndex === idx ? (
          <InlineForm
            key={idx}
            form={form}
            setForm={setForm}
            onConfirm={confirmEdit}
            onCancel={cancelEdit}
            duplicateWarning={isDuplicate}
          />
        ) : (
          <div
            key={idx}
            className="flex items-center gap-2 rounded-md border border-border/50 px-3 py-2"
          >
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">
                {v.key}
                <span className="ml-1.5 text-xs text-muted-foreground">({v.type ?? 'string'})</span>
              </p>
              {v.description && (
                <p className="text-xs text-muted-foreground truncate">{v.description}</p>
              )}
            </div>
            <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={() => startEdit(idx)}>
              <Pencil className="h-3.5 w-3.5" />
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0 text-destructive" onClick={() => removeVariable(idx)}>
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </div>
        ),
      )}

      {adding && (
        <InlineForm
          form={form}
          setForm={setForm}
          onConfirm={confirmAdd}
          onCancel={cancelEdit}
          duplicateWarning={isDuplicate}
        />
      )}

      {variables.length === 0 && !adding && editingIndex === null && (
        <p className="text-xs italic text-muted-foreground">
          Variables define the context keys your machine tracks.
        </p>
      )}

      {!adding && editingIndex === null && (
        <Button variant="outline" size="sm" className="mt-1 w-full" onClick={startAdd}>
          <Plus className="mr-1.5 h-3.5 w-3.5" />
          Add Variable
        </Button>
      )}
    </div>
  )
}

/** Shared inline form for adding and editing a variable. */
function InlineForm({
  form,
  setForm,
  onConfirm,
  onCancel,
  duplicateWarning,
}: {
  form: InlineFormState
  setForm: (f: InlineFormState) => void
  onConfirm: () => void
  onCancel: () => void
  duplicateWarning?: boolean
}) {
  return (
    <div className="flex flex-col gap-2 rounded-md border border-primary/30 bg-muted/20 p-3">
      <div className="space-y-1">
        <Label className="text-xs text-muted-foreground">Key</Label>
        <Input
          value={form.key}
          onChange={(e) => setForm({ ...form, key: e.target.value })}
          placeholder="variable_name"
          className="h-8 text-sm"
          autoFocus
        />
        {duplicateWarning && (
          <p className="text-[10px] text-amber-600">Duplicate key</p>
        )}
      </div>
      <div className="space-y-1">
        <Label className="text-xs text-muted-foreground">Type</Label>
        <select
          value={form.type}
          onChange={(e) => setForm({ ...form, type: e.target.value })}
          className="h-8 w-full rounded-md border border-input bg-background px-3 text-sm"
        >
          {VARIABLE_TYPES.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </div>
      <div className="space-y-1">
        <Label className="text-xs text-muted-foreground">Description</Label>
        <Input
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          placeholder="Optional description"
          className="h-8 text-sm"
        />
      </div>
      <div className="flex justify-end gap-1.5">
        <Button variant="ghost" size="sm" className="h-7" onClick={onCancel}>
          <X className="mr-1 h-3.5 w-3.5" />
          Cancel
        </Button>
        <Button size="sm" className="h-7" onClick={onConfirm} disabled={!form.key.trim()}>
          <Check className="mr-1 h-3.5 w-3.5" />
          Save
        </Button>
      </div>
    </div>
  )
}
