'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Pencil, Plus, RotateCcw, SlidersHorizontal, Trash2 } from 'lucide-react'
import { SidebarPanelToggleButton } from '@/components/layout'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import type { TriplePanelLayoutApi } from '@/components/layout/ResizableTriplePanelLayout'
import type { UseDiscoveryConnectionInstancesResult } from '@/hooks/useDiscoveryConnectionInstances'
import type { UseDiscoveryInstancesResult } from '@/hooks/useDiscoveryInstances'
import type { DiscoveryInstanceSummary } from '@/lib/api'

function instanceInitial(label: string): string {
  const t = label.trim()
  if (!t) return '?'
  return t.charAt(0).toUpperCase()
}

function formatRelative(iso: string): string {
  const t = Date.parse(iso)
  if (Number.isNaN(t)) return ''
  const deltaSec = Math.floor((Date.now() - t) / 1000)
  if (deltaSec < 60) return 'just now'
  if (deltaSec < 3600) return `${Math.floor(deltaSec / 60)}m ago`
  if (deltaSec < 86_400) return `${Math.floor(deltaSec / 3600)}h ago`
  return `${Math.floor(deltaSec / 86_400)}d ago`
}

export interface DiscoveryInstancesPanelProps {
  api: TriplePanelLayoutApi
  connectionsHook: UseDiscoveryConnectionInstancesResult
  selectedConnectionId: string | null
  onSelectConnection: (id: string) => void
  instancesHook: UseDiscoveryInstancesResult
  focusedInstanceId: string | null
  onFocusInstance: (
    id: string,
    homeChannel: string,
    connectionInstanceId: string
  ) => void
  onOpenCreateDialog: () => void
  onOpenEditFilterDialog: (instance: DiscoveryInstanceSummary) => void
}

/**
 * Left-rail panel for the legacy standalone `/discovery` page (deprecated; kept for reference).
 * Canonical Discovery UX lives in Workspace (`/workspace/?area=discovery`).
 *
 * Shows one list of Discovery Instances (persistent, filter-configured
 * consumers of the shared observation stream). Clicking a row focuses
 * the instance; the middle column loads its builds and the right
 * workspace loads the current filter preview.
 *
 * Connection registry rows appear above the per-connection draft list.
 */
export function DiscoveryInstancesPanel({
  api,
  connectionsHook,
  selectedConnectionId,
  onSelectConnection,
  instancesHook,
  focusedInstanceId,
  onFocusInstance,
  onOpenCreateDialog,
  onOpenEditFilterDialog,
}: DiscoveryInstancesPanelProps) {
  const isCollapsed = api.isPanelCollapsed
  const isCompact = api.panelDisplayMode === 'compact'
  const showLabels = !isCollapsed && !isCompact
  const { connections, loading: loadingConnections, error: connectionsError } =
    connectionsHook
  const { instances, loading, error, removeInstance, updateTitle, setQuery, refresh } =
    instancesHook

  const handleResetClick = useCallback(() => {
    setQuery('')
    void refresh()
  }, [refresh, setQuery])

  if (isCollapsed) {
    return (
      <DiscoveryInstancesPanelCollapsed
        api={api}
        instances={instances}
        focusedInstanceId={focusedInstanceId}
        onFocusInstance={onFocusInstance}
        onOpenCreateDialog={onOpenCreateDialog}
        selectedConnectionId={selectedConnectionId}
      />
    )
  }

  return (
    <div className="flex h-full min-h-0 flex-col border-r border-border/50 bg-muted/20">
      <div className="flex h-12 min-h-12 shrink-0 items-center justify-between gap-2 border-b border-border/50 bg-muted/30 px-4 py-0">
        {showLabels ? (
          <span className="truncate px-1 text-xs font-semibold uppercase leading-none tracking-wide text-muted-foreground">
            Discovery{' '}
            <span className="text-muted-foreground/70">
              ({instances.length} drafts)
            </span>
          </span>
        ) : null}
        <div className="flex items-center gap-1">
          <button
            type="button"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-colors hover:bg-muted"
            title="Reset filter (clear search & refresh)"
            aria-label="Reset filter and refresh"
            onClick={handleResetClick}
          >
            <RotateCcw className="h-4 w-4 text-muted-foreground" />
          </button>
          <button
            type="button"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-colors hover:bg-muted"
            title="New discovery instance"
            aria-label="New discovery instance"
            onClick={onOpenCreateDialog}
          >
            <Plus className="h-4 w-4 text-muted-foreground" />
          </button>
          <SidebarPanelToggleButton
            isCollapsed={false}
            onToggle={() => api.onCollapseRequested()}
            ariaLabelCollapse="Collapse panel"
          />
        </div>
      </div>

      {(connectionsError || error) ? (
        <div className="shrink-0 border-b border-border/50 px-3 py-2">
          <p className="text-xs text-destructive" role="alert">
            {connectionsError ?? error}
          </p>
        </div>
      ) : null}

      <div className="min-h-0 flex-1 overflow-y-auto p-2">
        <p className="mb-1.5 px-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
          Connections
        </p>
        {loadingConnections && connections.length === 0 ? (
          <p className="px-2 py-2 text-center text-xs text-muted-foreground">
            Loading connections…
          </p>
        ) : connections.length === 0 ? (
          <p className="px-2 py-2 text-xs text-muted-foreground">
            No registered discovery connections.
          </p>
        ) : (
          <ul className="mb-4 space-y-1">
            {connections.map((c) => (
              <li key={c.id}>
                <button
                  type="button"
                  className={cn(
                    'w-full rounded-md border px-2 py-1.5 text-left text-xs transition-colors',
                    c.id === selectedConnectionId
                      ? 'border-primary bg-primary/10 font-medium'
                      : 'border-border/60 bg-background hover:bg-muted/50'
                  )}
                  onClick={() => onSelectConnection(c.id)}
                >
                  <span className="block truncate">
                    {c.title?.trim() || c.backend}
                  </span>
                  <span className="block truncate font-mono text-[10px] text-muted-foreground">
                    {c.id}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        )}

        <p className="mb-1.5 px-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
          Drafts
        </p>
        {!selectedConnectionId ? (
          <p className="px-2 py-4 text-center text-sm text-muted-foreground">
            Select a connection to list drafts.
          </p>
        ) : loading && instances.length === 0 ? (
          <p className="px-2 py-4 text-center text-sm text-muted-foreground">
            Loading drafts…
          </p>
        ) : instances.length === 0 ? (
          <p className="px-2 py-4 text-center text-sm text-muted-foreground">
            No drafts for this connection. Click <Plus className="inline h-3 w-3" /> to
            create one.
          </p>
        ) : (
          <ul className="space-y-1">
            {instances.map((inst) => (
              <DiscoveryInstanceRow
                key={inst.id}
                instance={inst}
                active={inst.id === focusedInstanceId}
                onFocus={() =>
                  onFocusInstance(inst.id, inst.catalog_slug, inst.instance_id)
                }
                onEditFilter={() => onOpenEditFilterDialog(inst)}
                onRename={(next) =>
                  void updateTitle({
                    id: inst.id,
                    title: next,
                  })
                }
                onDelete={() =>
                  void removeInstance({
                    id: inst.id,
                  })
                }
              />
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}

interface DiscoveryInstancesPanelCollapsedProps {
  api: TriplePanelLayoutApi
  instances: DiscoveryInstanceSummary[]
  focusedInstanceId: string | null
  selectedConnectionId: string | null
  onFocusInstance: (
    id: string,
    homeChannel: string,
    connectionInstanceId: string
  ) => void
  onOpenCreateDialog: () => void
}

function DiscoveryInstancesPanelCollapsed({
  api,
  instances,
  focusedInstanceId,
  selectedConnectionId,
  onFocusInstance,
  onOpenCreateDialog,
}: DiscoveryInstancesPanelCollapsedProps) {
  return (
    <div className="flex h-full min-h-0 flex-col border-r border-border/50 bg-muted/20">
      <div className="flex h-12 min-h-12 shrink-0 items-center justify-center gap-2 border-b border-border/50 bg-muted/30 px-4 py-0">
        <SidebarPanelToggleButton
          isCollapsed
          onToggle={() => api.onExpandRequested()}
          ariaLabelExpand="Expand panel"
        />
      </div>
      <div className="flex shrink-0 justify-center border-b border-border/50 px-1 py-2">
        <Button
          type="button"
          variant="outline"
          size="icon"
          className="h-8 w-8 shrink-0"
          title="New discovery instance"
          aria-label="New discovery instance"
          onClick={onOpenCreateDialog}
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <div className="flex min-h-0 flex-1 flex-col items-center gap-2 overflow-y-auto px-1 py-2">
        {!selectedConnectionId ? (
          <span className="px-1 text-center text-[10px] text-muted-foreground">
            Pick a connection
          </span>
        ) : null}
        {instances.map((inst) => {
          const active = inst.id === focusedInstanceId
          const label = inst.title?.trim() || inst.catalog_slug
          return (
            <Button
              key={inst.id}
              type="button"
              variant={active ? 'default' : 'outline'}
              size="icon"
              className="h-8 w-8 shrink-0 rounded-full text-xs font-semibold"
              title={`${label} · ${inst.catalog_slug}`}
              aria-label={`Focus instance ${label}`}
              aria-pressed={active}
              onClick={() =>
                onFocusInstance(inst.id, inst.catalog_slug, inst.instance_id)
              }
            >
              {instanceInitial(label)}
            </Button>
          )
        })}
      </div>
    </div>
  )
}

interface DiscoveryInstanceRowProps {
  instance: DiscoveryInstanceSummary
  active: boolean
  onFocus: () => void
  onEditFilter: () => void
  onRename: (next: string) => void
  onDelete: () => void
}

function DiscoveryInstanceRow({
  instance,
  active,
  onFocus,
  onEditFilter,
  onRename,
  onDelete,
}: DiscoveryInstanceRowProps) {
  const label = instance.title?.trim() || 'Untitled instance'
  const [editingTitle, setEditingTitle] = useState(false)
  const [draftTitle, setDraftTitle] = useState(label)
  const inputRef = useRef<HTMLInputElement>(null)

  // Re-sync the local input when the underlying instance changes
  // (e.g. another tab renamed it).
  useEffect(() => {
    if (!editingTitle) {
      setDraftTitle(label)
    }
  }, [label, editingTitle])

  // Auto-focus the input when entering edit mode.
  useEffect(() => {
    if (editingTitle) {
      inputRef.current?.focus()
      inputRef.current?.select()
    }
  }, [editingTitle])

  const commit = useCallback(() => {
    const next = draftTitle.trim()
    setEditingTitle(false)
    if (!next || next === label) {
      setDraftTitle(label)
      return
    }
    onRename(next)
  }, [draftTitle, label, onRename])

  const cancel = useCallback(() => {
    setEditingTitle(false)
    setDraftTitle(label)
  }, [label])

  return (
    <li>
      <div
        className={cn(
          'flex items-start gap-1 rounded-md border px-2 py-2 text-left text-sm transition-colors',
          active
            ? 'border-primary bg-primary/10'
            : 'border-border/60 bg-background hover:bg-muted/50'
        )}
      >
        <div className="min-w-0 flex-1">
          {editingTitle ? (
            <Input
              ref={inputRef}
              className="h-7 px-2 text-sm font-medium"
              value={draftTitle}
              onChange={(e) => setDraftTitle(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault()
                  commit()
                } else if (e.key === 'Escape') {
                  e.preventDefault()
                  cancel()
                }
              }}
              onBlur={commit}
            />
          ) : (
            <button
              type="button"
              className="block w-full truncate text-left font-medium"
              onClick={onFocus}
              onDoubleClick={() => setEditingTitle(true)}
              title="Click to focus, double-click to rename"
            >
              {label}
            </button>
          )}
          <button
            type="button"
            className="block w-full truncate text-left text-xs text-muted-foreground"
            onClick={onFocus}
          >
            catalog:{' '}
            <span className="font-mono">{instance.catalog_slug}</span>
          </button>
          <div className="mt-1 flex flex-wrap items-center gap-1 text-[11px] text-muted-foreground">
            <span className="rounded bg-muted px-1.5 py-0.5">
              {instance.filter_summary}
            </span>
            <span>·</span>
            <span>
              {instance.built_count}{' '}
              {instance.built_count === 1 ? 'build' : 'builds'}
            </span>
            <span>·</span>
            <span>{formatRelative(instance.updated_at)}</span>
          </div>
        </div>
        <div className="flex shrink-0 flex-col items-center gap-0.5">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-muted-foreground hover:text-foreground"
            aria-label={`Rename ${label}`}
            title="Rename"
            onClick={() => setEditingTitle(true)}
          >
            <Pencil className="h-3.5 w-3.5" />
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-muted-foreground hover:text-foreground"
            aria-label={`Edit draft settings for ${label}`}
            title="Edit draft settings"
            onClick={onEditFilter}
          >
            <SlidersHorizontal className="h-3.5 w-3.5" />
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-muted-foreground hover:text-destructive"
            aria-label={`Delete instance ${label}`}
            title="Delete instance"
            onClick={onDelete}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </li>
  )
}
