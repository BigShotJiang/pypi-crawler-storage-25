'use client'

import type { LucideIcon } from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import { Braces, FileCode2, FolderOpen, Play, Plus, Search } from 'lucide-react'
import {
  SidebarHeaderWithToggle,
  SidebarPanelToggleButton,
} from '@/components/layout'
import type { SidebarDisplayMode } from '@/components/layout/ResizableWorkspaceLayout'
import {
  WorkspaceMainAreaToggle,
  type WorkspaceMainArea,
} from '@/components/workspace/WorkspaceMainAreaToggle'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import type { SidebarLayoutApi } from '@/components/layout/ResizableWorkspaceLayout'
import {
  DiscoveryFileTreeNode,
  type DiscoveryConnectionMenuAction,
  type DiscoveryConnectionMenuPayload,
  type DiscoveryDraftMenuAction,
  type DiscoveryDraftMenuPayload,
} from '@/components/discovery/DiscoveryFileTreeNode'
import type { DiscoveryTreeNode } from '@/stores/discovery-browse'
import {
  filterDiscoveryTree,
  useDiscoveryBrowseStore,
} from '@/stores/discovery-browse'
import { cn } from '@/lib/utils'
import { WorkspaceMachineFormConfigTestPanels } from '@/components/workspace/WorkspaceMachineFormConfigTestPanels'

type DiscoverySidebarMode = 'browse' | 'form' | 'config' | 'test'

const discoveryModeTabs: {
  id: DiscoverySidebarMode
  label: string
  icon: LucideIcon
}[] = [
  { id: 'browse', label: 'Browse', icon: FolderOpen },
  { id: 'form', label: 'Form', icon: Braces },
  { id: 'config', label: 'Config', icon: FileCode2 },
  { id: 'test', label: 'Test', icon: Play },
]

const searchBarClass = 'shrink-0 border-b border-border px-2 py-2'
const searchInputClass = 'h-8 pl-7 text-xs'

export interface DiscoveryTreeSidebarProps {
  api: SidebarLayoutApi
  nodes: DiscoveryTreeNode[]
  loading: boolean
  error: string | null
  selectedDraftId: string | null
  onSelectDraft: (args: {
    draftId: string
    homeChannel: string
    instanceId: string
  }) => void
  /** Opens the register-connection dialog (new discovery backend). */
  onCreateInstance: () => void
  /** Per-draft instance row menu (properties, delete, refresh). */
  onDraftMenuAction?: (
    action: DiscoveryDraftMenuAction,
    payload: DiscoveryDraftMenuPayload
  ) => void
  onConnectionMenuAction?: (
    action: DiscoveryConnectionMenuAction,
    payload: DiscoveryConnectionMenuPayload
  ) => void
  /** When set with onWorkspaceAreaChange, show Machines/Discovery toggle (embedded in /workspace). */
  workspaceArea?: WorkspaceMainArea
  onWorkspaceAreaChange?: (area: WorkspaceMainArea) => void
}

export function DiscoveryTreeSidebar({
  api,
  nodes,
  loading,
  error,
  selectedDraftId,
  onSelectDraft,
  onCreateInstance,
  onDraftMenuAction,
  onConnectionMenuAction,
  workspaceArea,
  onWorkspaceAreaChange,
}: DiscoveryTreeSidebarProps) {
  const embedWorkspace =
    workspaceArea !== undefined && onWorkspaceAreaChange !== undefined
  const [discoverySidebarMode, setDiscoverySidebarMode] =
    useState<DiscoverySidebarMode>('browse')
  const [searchQuery, setSearchQuery] = useState('')
  const displayNodes = useMemo(
    () => filterDiscoveryTree(nodes, searchQuery),
    [nodes, searchQuery]
  )

  const setExpandedIds = useDiscoveryBrowseStore((s) => s.setExpandedIds)

  useEffect(() => {
    const ids = new Set<string>()
    const walk = (list: DiscoveryTreeNode[]) => {
      for (const x of list) {
        if (x.kind === 'folder') {
          ids.add(x.id)
          if (x.children?.length) walk(x.children)
        }
      }
    }
    walk(displayNodes)
    setExpandedIds(ids)
  }, [displayNodes, setExpandedIds])

  const isCollapsed = api.isPanelCollapsed
  const isCompact = api.sidebarDisplayMode === 'compact'
  const showLabels = api.sidebarDisplayMode === 'expanded'
  const filterActive = Boolean(searchQuery.trim())
  const noFilterMatches =
    filterActive && !loading && nodes.length > 0 && displayNodes.length === 0

  const headerDisplayMode: SidebarDisplayMode = isCollapsed
    ? 'collapsed'
    : api.sidebarDisplayMode

  if (isCollapsed) {
    if (embedWorkspace) {
      return (
        <div
          className="flex h-full w-full min-w-0 flex-col border-r border-border/50 bg-background shadow-sm transition-all duration-300"
          style={{ height: '100%', overflow: 'hidden' }}
        >
          <SidebarHeaderWithToggle
            isCollapsed
            displayMode="collapsed"
            onToggle={() => api.onExpandRequested()}
          />
        </div>
      )
    }
    return (
      <div className="flex h-full min-h-0 flex-col border-r border-border/50 bg-muted/20">
        <div className="flex h-12 min-h-12 shrink-0 items-center justify-center border-b border-border/50 bg-muted/30 px-2">
          <SidebarPanelToggleButton
            isCollapsed
            onToggle={() => api.onExpandRequested()}
          />
        </div>
      </div>
    )
  }

  const shellClass = embedWorkspace
    ? 'flex h-full w-full min-w-0 flex-col border-r border-border/50 bg-background shadow-sm transition-all duration-300'
    : 'flex h-full min-h-0 flex-col border-r border-border/50 bg-muted/20'

  return (
    <div
      className={shellClass}
      style={embedWorkspace ? { height: '100%', overflow: 'hidden' } : undefined}
    >
      {embedWorkspace ? (
        <>
          <SidebarHeaderWithToggle
            isCollapsed={false}
            displayMode={headerDisplayMode}
            onToggle={() => api.onCollapseRequested()}
          >
            <WorkspaceMainAreaToggle
              embedded
              value={workspaceArea}
              onChange={onWorkspaceAreaChange}
            />
          </SidebarHeaderWithToggle>
          <div className="shrink-0 border-b px-3 py-1.5">
            <div
              className="flex min-w-0 gap-0.5 overflow-x-auto"
              role="tablist"
              aria-label="Discovery sidebar tab"
            >
              {discoveryModeTabs.map((tab) => {
                const isActive = discoverySidebarMode === tab.id
                return (
                  <button
                    key={tab.id}
                    type="button"
                    role="tab"
                    aria-label={tab.label}
                    aria-selected={isActive}
                    onClick={() => setDiscoverySidebarMode(tab.id)}
                    title={tab.label}
                    className={cn(
                      'flex shrink-0 items-center rounded px-2 py-1 text-[11px] font-medium transition-colors',
                      isCompact ? 'justify-center px-1.5' : 'gap-1',
                      isActive
                        ? 'bg-muted text-foreground'
                        : 'text-muted-foreground hover:text-foreground',
                    )}
                  >
                    <tab.icon className="h-3 w-3 shrink-0" />
                    {!isCompact ? (
                      <span className="whitespace-nowrap">{tab.label}</span>
                    ) : null}
                  </button>
                )
              })}
            </div>
          </div>
        </>
      ) : (
        <div className="flex min-h-12 shrink-0 items-center justify-between gap-2 border-b border-border/50 bg-muted/30 px-2 py-2">
          {showLabels ? (
            <span className="truncate text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Discovery
            </span>
          ) : (
            <span className="sr-only">Discovery</span>
          )}
          <SidebarPanelToggleButton
            isCollapsed={false}
            onToggle={() => api.onCollapseRequested()}
          />
        </div>
      )}
      {embedWorkspace && discoverySidebarMode !== 'browse' ? (
        <div
          className={cn(
            'flex min-h-0 flex-1 flex-col',
            discoverySidebarMode === 'config'
              ? 'overflow-y-auto overflow-x-hidden'
              : 'overflow-hidden',
          )}
        >
          <WorkspaceMachineFormConfigTestPanels
            view={
              discoverySidebarMode === 'form'
                ? 'form'
                : discoverySidebarMode === 'test'
                  ? 'test'
                  : 'config'
            }
            isSidebarCollapsed={false}
          />
        </div>
      ) : (
        <>
          <div className={searchBarClass}>
            <div className="flex items-center gap-2">
              <div className="relative min-w-0 flex-1">
                <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Filter..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={searchInputClass}
                  aria-label="Filter discovery tree"
                />
              </div>
              <Button
                type="button"
                variant="outline"
                size="icon"
                className="h-8 w-8 shrink-0"
                title="Register a new discovery connection"
                aria-label="Register a new discovery connection"
                onClick={onCreateInstance}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>
          {error ? (
            <div className="shrink-0 border-b border-border/50 px-3 py-2">
              <p className="text-xs text-destructive">{error}</p>
            </div>
          ) : null}
          <div className="min-h-0 flex-1 overflow-y-auto px-1 py-2">
            {loading && nodes.length === 0 ? (
              <p className="px-2 py-4 text-center text-xs text-muted-foreground">
                Loading…
              </p>
            ) : nodes.length === 0 ? (
              <p className="px-2 py-4 text-center text-xs text-muted-foreground">
                No connections. Register a discovery connection to begin.
              </p>
            ) : noFilterMatches ? (
              <p className="px-2 py-4 text-center text-xs text-muted-foreground">
                No matches for your filter.
              </p>
            ) : (
              displayNodes.map((n) => (
                <DiscoveryFileTreeNode
                  key={n.id}
                  node={n}
                  depth={0}
                  selectedDraftId={selectedDraftId}
                  onSelectDraft={onSelectDraft}
                  onDraftMenuAction={onDraftMenuAction}
                  onConnectionMenuAction={onConnectionMenuAction}
                />
              ))
            )}
          </div>
        </>
      )}
    </div>
  )
}
