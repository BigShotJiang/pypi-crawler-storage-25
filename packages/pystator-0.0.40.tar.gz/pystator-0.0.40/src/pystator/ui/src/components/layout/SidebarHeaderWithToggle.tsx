'use client'

import { ChevronLeft, ChevronRight } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { SidebarDisplayMode } from './ResizableWorkspaceLayout'

/** Shared chevron control — matches pycharter EditorV2LeftPanel collapse button. */
export const SIDEBAR_PANEL_TOGGLE_BUTTON_CLASS =
  'shrink-0 rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground'

export interface SidebarPanelToggleButtonProps {
  /** When true, show ChevronRight (expand); when false, ChevronLeft (collapse). */
  isCollapsed: boolean
  onToggle: () => void
  /** Override default aria-label when expanded (collapse action). */
  ariaLabelCollapse?: string
  /** Override default aria-label when collapsed (expand action). */
  ariaLabelExpand?: string
}

/**
 * Chevron-only control matching {@link SidebarHeaderWithToggle} (workspace left rail).
 * Use inside toolbars that also show other icon buttons.
 */
export function SidebarPanelToggleButton({
  isCollapsed,
  onToggle,
  ariaLabelCollapse = 'Collapse sidebar',
  ariaLabelExpand = 'Expand sidebar',
}: SidebarPanelToggleButtonProps) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className={SIDEBAR_PANEL_TOGGLE_BUTTON_CLASS}
      aria-label={isCollapsed ? ariaLabelExpand : ariaLabelCollapse}
    >
      {isCollapsed ? (
        <ChevronRight className="h-4 w-4" />
      ) : (
        <ChevronLeft className="h-4 w-4" />
      )}
    </button>
  )
}

export interface SidebarHeaderWithToggleProps {
  /** When true, only the expand chevron is shown (centered). */
  isCollapsed: boolean
  /** Sidebar display mode for responsive header content. */
  displayMode?: SidebarDisplayMode
  /** Called when user clicks the toggle (collapse or expand). */
  onToggle: () => void
  /** Content shown on the left when expanded (e.g. title or tabs). Omitted when collapsed. */
  children?: React.ReactNode
  /** Optional class name for the header container. */
  className?: string
}

/**
 * Left sidebar header: optional leading content + collapse/expand control.
 * Matches pycharter editor-v2 {@link EditorV2LeftPanel} mode-toggle row (border-b px-3 py-2).
 */
export function SidebarHeaderWithToggle({
  isCollapsed,
  displayMode = isCollapsed ? 'collapsed' : 'expanded',
  onToggle,
  children,
  className,
}: SidebarHeaderWithToggleProps) {
  const showChildren = displayMode !== 'collapsed'
  return (
    <div
      className={cn(
        'flex shrink-0 items-center gap-2 border-b px-3 py-2',
        isCollapsed ? 'justify-center' : 'justify-between',
        className
      )}
    >
      {showChildren && children}
      <SidebarPanelToggleButton isCollapsed={isCollapsed} onToggle={onToggle} />
    </div>
  )
}
