'use client'

import { useState, useCallback } from 'react'
import {
  SidebarHeaderWithToggle,
  type SidebarLayoutApi,
} from '@/components/layout'
import { useBuilderStore } from '@/stores/builder'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import { BuilderStartScreen } from './BuilderStartScreen'
import { BuilderStepTabs } from './BuilderStepTabs'
import { BuilderVariableEditor } from './BuilderVariableEditor'
import { BuilderStateEditor } from './BuilderStateEditor'
import { BuilderRulesPanel } from './BuilderRulesPanel'

export interface BuilderSidebarProps extends SidebarLayoutApi {}

export function BuilderSidebar({
  isPanelCollapsed,
  sidebarDisplayMode,
  onCollapseRequested,
  onExpandRequested,
}: BuilderSidebarProps) {
  const activeStep = useBuilderStore((s) => s.activeStep)
  const machineName = useBuilderStore((s) => s.machineName)
  const machineVersion = useBuilderStore((s) => s.machineVersion)
  const setMachineMeta = useBuilderStore((s) => s.setMachineMeta)

  const isStart = activeStep === 'start'

  const handleToggle = useCallback(() => {
    if (isPanelCollapsed) {
      onExpandRequested()
    } else {
      onCollapseRequested()
    }
  }, [isPanelCollapsed, onCollapseRequested, onExpandRequested])

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <SidebarHeaderWithToggle
        isCollapsed={isPanelCollapsed}
        displayMode={sidebarDisplayMode}
        onToggle={handleToggle}
      >
        <span className="text-sm font-semibold text-foreground truncate">
          Builder
        </span>
      </SidebarHeaderWithToggle>

      {isPanelCollapsed ? null : isStart ? (
        <div className="flex-1 overflow-y-auto p-3">
          <BuilderStartScreen />
        </div>
      ) : (
        <div className="flex flex-1 flex-col overflow-hidden">
          {/* Machine name / version header */}
          <div className="shrink-0 space-y-2 border-b border-border/50 px-3 py-3">
            <div className="space-y-1">
              <Label htmlFor="builder-name" className="text-xs text-muted-foreground">
                Machine Name
              </Label>
              <Input
                id="builder-name"
                value={machineName}
                onChange={(e) => setMachineMeta(e.target.value, machineVersion)}
                placeholder="my_machine"
                className="h-8 text-sm"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="builder-version" className="text-xs text-muted-foreground">
                Version
              </Label>
              <Input
                id="builder-version"
                value={machineVersion}
                onChange={(e) => setMachineMeta(machineName, e.target.value)}
                placeholder="1.0.0"
                className="h-8 text-sm"
              />
            </div>
          </div>

          {/* Step tabs */}
          <BuilderStepTabs
            activeStep={activeStep}
            onStepChange={(step) => useBuilderStore.getState().setActiveStep(step)}
            variableCount={useBuilderStore.getState().variables.length}
            stateCount={useBuilderStore.getState().states.length}
            hasInitialState={useBuilderStore.getState().states.some((s) => s.type === 'initial')}
            hasTerminalState={useBuilderStore.getState().states.some((s) => s.type === 'terminal')}
            ruleCount={useBuilderStore.getState().rules.length}
            hasIncompleteRule={useBuilderStore.getState().rules.some((r) => !r.sourceState || !r.targetState)}
          />

          {/* Active panel content */}
          <div className="flex-1 overflow-y-auto p-3">
            {activeStep === 'variables' && <BuilderVariableEditor />}
            {activeStep === 'states' && <BuilderStateEditor />}
            {activeStep === 'rules' && <BuilderRulesPanel />}
          </div>
        </div>
      )}
    </div>
  )
}
