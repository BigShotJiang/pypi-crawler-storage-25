'use client'

import { useCallback, useId, type ReactNode } from 'react'
import { cn } from '@/lib/utils'

export type DiscoveryBottomTabId = 'observation' | 'recipes' | 'review'

const TAB_ORDER: DiscoveryBottomTabId[] = ['observation', 'recipes', 'review']

const TAB_META: Record<
  DiscoveryBottomTabId,
  { label: string; hint: string }
> = {
  observation: {
    label: 'Observation',
    hint: 'Record and browse observations for this draft’s scope.',
  },
  recipes: {
    label: 'Recipes',
    hint: 'Choose inference mode, entity scope, then Preview and Build.',
  },
  review: {
    label: 'Review',
    hint: 'Compare to catalog baseline, inspect shadow diffs, build, and promote.',
  },
}

export interface DiscoveryBottomPanelTabsProps {
  activeTab: DiscoveryBottomTabId
  onTabChange: (tab: DiscoveryBottomTabId) => void
  observationPanel: ReactNode
  recipesPanel: ReactNode
  reviewPanel: ReactNode
}

export function DiscoveryBottomPanelTabs({
  activeTab,
  onTabChange,
  observationPanel,
  recipesPanel,
  reviewPanel,
}: DiscoveryBottomPanelTabsProps) {
  const baseId = useId()
  const tablistId = `${baseId}-tablist`

  const focusAt = useCallback(
    (index: number) => {
      const id = TAB_ORDER[index]
      if (id) onTabChange(id)
    },
    [onTabChange]
  )

  const onTabKeyDown = useCallback(
    (e: React.KeyboardEvent, index: number) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        e.preventDefault()
        focusAt(Math.min(index + 1, TAB_ORDER.length - 1))
      } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        e.preventDefault()
        focusAt(Math.max(index - 1, 0))
      } else if (e.key === 'Home') {
        e.preventDefault()
        focusAt(0)
      } else if (e.key === 'End') {
        e.preventDefault()
        focusAt(TAB_ORDER.length - 1)
      }
    },
    [focusAt]
  )

  const panels: Record<DiscoveryBottomTabId, ReactNode> = {
    observation: observationPanel,
    recipes: recipesPanel,
    review: reviewPanel,
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-hidden bg-background">
      {/* Tab bar — matches pycharter WorkspaceCompanion / EditorV2 bottom companion */}
      <div className="shrink-0 border-b border-border">
        <div
          className="flex min-w-0 items-center gap-1 overflow-x-auto px-3 py-1.5"
          role="tablist"
          id={tablistId}
          aria-label="Discovery tools"
        >
          {TAB_ORDER.map((id, index) => {
            const meta = TAB_META[id]
            const selected = activeTab === id
            return (
              <button
                key={id}
                type="button"
                role="tab"
                id={`${baseId}-tab-${id}`}
                aria-selected={selected}
                aria-controls={`${baseId}-panel-${id}`}
                tabIndex={selected ? 0 : -1}
                title={meta.hint}
                onClick={() => onTabChange(id)}
                onKeyDown={(e) => onTabKeyDown(e, index)}
                className={cn(
                  'inline-flex shrink-0 items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium transition-colors',
                  selected
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {meta.label}
              </button>
            )
          })}
        </div>
        <p className="px-3 pb-2 pt-0 text-xs leading-snug text-muted-foreground">
          {TAB_META[activeTab].hint}
        </p>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden">
        {TAB_ORDER.map((id) => (
          <div
            key={id}
            id={`${baseId}-panel-${id}`}
            role="tabpanel"
            aria-labelledby={`${baseId}-tab-${id}`}
            hidden={activeTab !== id}
          >
            {panels[id]}
          </div>
        ))}
      </div>
    </div>
  )
}
