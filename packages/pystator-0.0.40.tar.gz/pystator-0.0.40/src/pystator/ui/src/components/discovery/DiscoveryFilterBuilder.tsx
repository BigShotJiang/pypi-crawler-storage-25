'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Plus, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import type { DiscoveryDraftFilterInput } from '@/lib/api'

const TEXTAREA_CLASS =
  'flex min-h-[64px] w-full rounded-md border border-input bg-background px-2 py-1.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring'

interface MetadataRow {
  key: string
  value: string
}

function metadataMatchToRows(
  m: Record<string, unknown> | null | undefined
): MetadataRow[] {
  if (!m) return []
  return Object.entries(m).map(([k, v]) => ({
    key: k,
    value: typeof v === 'string' ? v : JSON.stringify(v),
  }))
}

function rowsToMetadataMatch(
  rows: MetadataRow[]
): Record<string, unknown> | null {
  const out: Record<string, unknown> = {}
  for (const row of rows) {
    const key = row.key.trim()
    if (!key) continue
    let parsed: unknown = row.value
    try {
      parsed = JSON.parse(row.value)
    } catch {
      // Fall back to the raw string for non-JSON values.
      parsed = row.value
    }
    out[key] = parsed
  }
  return Object.keys(out).length > 0 ? out : null
}

/**
 * Controlled editor for a ``DiscoveryDraftFilterInput``.
 *
 * Keeps the parent dialog (create vs. edit) simple: the parent owns
 * the draft filter state and the "set vs clear" decision; this
 * component is a pure view that renders the textarea-based editors
 * for each dimension and bubbles changes up via ``onChange``.
 */
export interface DiscoveryFilterBuilderProps {
  value: DiscoveryDraftFilterInput
  onChange: (next: DiscoveryDraftFilterInput) => void
}

function parseList(raw: string): string[] | null {
  const parts = raw
    .split(/[\n,]+/)
    .map((s) => s.trim())
    .filter(Boolean)
  return parts.length > 0 ? parts : null
}

function listToText(list: string[] | null | undefined): string {
  return (list ?? []).join('\n')
}

function parseDateTime(raw: string): string | null {
  const trimmed = raw.trim()
  if (!trimmed) return null
  const d = new Date(trimmed)
  if (Number.isNaN(d.getTime())) return null
  return d.toISOString()
}

export function DiscoveryFilterBuilder({
  value,
  onChange,
}: DiscoveryFilterBuilderProps) {
  const setChannels = useCallback(
    (raw: string) => onChange({ ...value, channels: parseList(raw) }),
    [onChange, value]
  )
  const setEntityIds = useCallback(
    (raw: string) => onChange({ ...value, entity_ids: parseList(raw) }),
    [onChange, value]
  )
  const setSources = useCallback(
    (raw: string) => onChange({ ...value, sources: parseList(raw) }),
    [onChange, value]
  )
  const setObservedAfter = useCallback(
    (raw: string) => onChange({ ...value, observed_after: parseDateTime(raw) }),
    [onChange, value]
  )
  const setObservedBefore = useCallback(
    (raw: string) =>
      onChange({ ...value, observed_before: parseDateTime(raw) }),
    [onChange, value]
  )

  // Metadata rows are local UI state: rows with empty keys are valid
  // *while editing* (the user is mid-typing), but only the rows with
  // non-empty keys get propagated to the parent's filter via
  // ``rowsToMetadataMatch``. Re-syncing from props is guarded so we
  // don't blow away in-progress edits on every parent re-render.
  const [metadataRows, setMetadataRows] = useState<MetadataRow[]>(() =>
    metadataMatchToRows(value.metadata_match)
  )
  const lastSyncedRef = useRef<string>(JSON.stringify(value.metadata_match ?? null))

  useEffect(() => {
    const incoming = JSON.stringify(value.metadata_match ?? null)
    if (incoming !== lastSyncedRef.current) {
      lastSyncedRef.current = incoming
      setMetadataRows(metadataMatchToRows(value.metadata_match))
    }
  }, [value.metadata_match])

  const propagateMetadataRows = useCallback(
    (rows: MetadataRow[]) => {
      const next = rowsToMetadataMatch(rows)
      lastSyncedRef.current = JSON.stringify(next ?? null)
      onChange({ ...value, metadata_match: next })
    },
    [onChange, value]
  )

  const updateMetadataRow = useCallback(
    (idx: number, next: Partial<MetadataRow>) => {
      const updated = metadataRows.map((row, i) =>
        i === idx ? { ...row, ...next } : row
      )
      setMetadataRows(updated)
      propagateMetadataRows(updated)
    },
    [metadataRows, propagateMetadataRows]
  )
  const addMetadataRow = useCallback(() => {
    const updated = [...metadataRows, { key: '', value: '' }]
    setMetadataRows(updated)
    // Don't call ``propagateMetadataRows`` here — empty keys would be
    // dropped, leaving the parent's filter unchanged. The visible row
    // is purely local until the user types a key.
  }, [metadataRows])
  const removeMetadataRow = useCallback(
    (idx: number) => {
      const updated = metadataRows.filter((_, i) => i !== idx)
      setMetadataRows(updated)
      propagateMetadataRows(updated)
    },
    [metadataRows, propagateMetadataRows]
  )

  return (
    <div className="grid gap-3">
      <div className="space-y-1">
        <Label htmlFor="dfb-channels" className="text-xs">
          Channels (one per line or comma-separated)
        </Label>
        <textarea
          id="dfb-channels"
          rows={4}
          className={TEXTAREA_CLASS}
          placeholder="orders&#10;inventory"
          value={listToText(value.channels)}
          onChange={(e) => setChannels(e.target.value)}
        />
        <p className="text-[11px] text-muted-foreground">
          Producer <code className="rounded bg-muted px-0.5">machine_name</code>{' '}
          tags. Add several channels with a new line or commas. If the draft has a
          saved scope filter, leaving this box empty includes every channel
          (other dimensions can still narrow events). With no saved scope filter,
          preview uses legacy single-channel mode for the draft route slug.
        </p>
      </div>

      <div className="space-y-1">
        <Label htmlFor="dfb-entity-ids" className="text-xs">
          Entity IDs
        </Label>
        <textarea
          id="dfb-entity-ids"
          rows={2}
          className={TEXTAREA_CLASS}
          placeholder="order-123&#10;order-456"
          value={listToText(value.entity_ids)}
          onChange={(e) => setEntityIds(e.target.value)}
        />
      </div>

      <div className="space-y-1">
        <Label htmlFor="dfb-sources" className="text-xs">
          Sources
        </Label>
        <textarea
          id="dfb-sources"
          rows={2}
          className={TEXTAREA_CLASS}
          placeholder="svc&#10;worker"
          value={listToText(value.sources)}
          onChange={(e) => setSources(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-2 gap-2">
        <div className="space-y-1">
          <Label htmlFor="dfb-after" className="text-xs">
            Observed after
          </Label>
          <input
            id="dfb-after"
            type="datetime-local"
            className="flex h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
            value={
              value.observed_after
                ? new Date(value.observed_after).toISOString().slice(0, 16)
                : ''
            }
            onChange={(e) => setObservedAfter(e.target.value)}
          />
        </div>
        <div className="space-y-1">
          <Label htmlFor="dfb-before" className="text-xs">
            Observed before
          </Label>
          <input
            id="dfb-before"
            type="datetime-local"
            className="flex h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
            value={
              value.observed_before
                ? new Date(value.observed_before).toISOString().slice(0, 16)
                : ''
            }
            onChange={(e) => setObservedBefore(e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-1">
        <div className="flex items-center justify-between">
          <Label className="text-xs">Metadata match</Label>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-7 text-xs"
            onClick={addMetadataRow}
          >
            <Plus className="mr-1 h-3 w-3" /> Add
          </Button>
        </div>
        {metadataRows.length === 0 ? (
          <p className="text-[11px] text-muted-foreground">
            No metadata constraints. Add a row to require an
            observation's metadata to contain a specific key/value.
          </p>
        ) : (
          <ul className="space-y-1">
            {metadataRows.map((row, idx) => (
              <li key={idx} className="flex items-center gap-1">
                <Input
                  className="h-8 text-xs font-mono"
                  placeholder="key"
                  value={row.key}
                  onChange={(e) =>
                    updateMetadataRow(idx, { key: e.target.value })
                  }
                />
                <Input
                  className="h-8 text-xs font-mono"
                  placeholder="value (string or JSON)"
                  value={row.value}
                  onChange={(e) =>
                    updateMetadataRow(idx, { value: e.target.value })
                  }
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
                  aria-label="Remove metadata row"
                  onClick={() => removeMetadataRow(idx)}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </li>
            ))}
          </ul>
        )}
        <p className="text-[11px] text-muted-foreground">
          Values are parsed as JSON when valid; otherwise treated as
          strings. All key/value pairs must match exactly.
        </p>
      </div>
    </div>
  )
}

/** True when the filter has at least one dimension set. */
export function filterHasAnyDimension(f: DiscoveryDraftFilterInput): boolean {
  return Boolean(
    (f.channels && f.channels.length > 0) ||
      (f.entity_ids && f.entity_ids.length > 0) ||
      (f.sources && f.sources.length > 0) ||
      f.observed_after ||
      f.observed_before ||
      (f.metadata_match && Object.keys(f.metadata_match).length > 0)
  )
}

export const EMPTY_FILTER: DiscoveryDraftFilterInput = {
  channels: null,
  entity_ids: null,
  sources: null,
  observed_after: null,
  observed_before: null,
  metadata_match: null,
}
