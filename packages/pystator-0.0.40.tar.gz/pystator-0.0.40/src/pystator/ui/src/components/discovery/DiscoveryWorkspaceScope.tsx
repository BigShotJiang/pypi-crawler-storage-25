'use client'

import type { ReactNode } from 'react'
import { useState } from 'react'
import type { UseDiscoveryWorkspaceResult } from '@/hooks/useDiscoveryWorkspace'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import { Bot, Loader2, Trash2, Wrench } from 'lucide-react'

/** Shared scroll region height for recipe entity / edge tables. */
const RECIPE_TABLE_SCROLL = 'max-h-72 min-h-[10rem] overflow-auto'

/**
 * Fixed header height so step-1 and step-2 toolbars (Select all / Clear) share the same baseline
 * when the two panes sit side-by-side in the recipes grid.
 */
const RECIPE_PANE_HEADER_H = 'h-11 min-h-11 max-h-11'

function RecipePane({
  step,
  title,
  subtitle,
  actions,
  children,
}: {
  step: 1 | 2
  title: string
  subtitle?: string
  actions?: ReactNode
  children: ReactNode
}) {
  return (
    <div className="flex min-h-0 min-w-0 flex-col bg-background/50">
      <div
        className={cn(
          'flex shrink-0 flex-nowrap items-center gap-2 border-b border-border/60 bg-muted/25 px-2.5',
          RECIPE_PANE_HEADER_H,
        )}
      >
        <div className="min-w-0 flex-1 space-y-0 pr-1">
          <p className="text-[11px] font-semibold leading-none tracking-tight text-foreground">
            <span
              className="mr-1 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-primary/12 px-0.5 text-[9px] font-bold text-primary tabular-nums"
              aria-hidden
            >
              {step}
            </span>
            {title}
          </p>
          {subtitle ? (
            <p className="mt-0.5 line-clamp-1 text-[10px] leading-tight text-muted-foreground">{subtitle}</p>
          ) : null}
        </div>
        <div className="flex h-full shrink-0 flex-col justify-center">
          <div className="flex flex-nowrap items-center justify-end gap-1.5">{actions}</div>
        </div>
      </div>
      <div className="min-h-0 flex-1">{children}</div>
    </div>
  )
}

/** Entity ID checkboxes; pairs with transitions pane in the recipes bottom panel. */
export function DiscoveryEntityScopeList({ d }: { d: UseDiscoveryWorkspaceResult }) {
  const editingWorkspace = Boolean(d.activeDraftId && !d.selectedVersion)
  const [deletingId, setDeletingId] = useState<string | null>(null)

  const actions =
    editingWorkspace && d.entityIds.length > 0 ? (
      <>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="h-7 text-xs"
          onClick={() => d.setSelectedEntityIds([...d.entityIds])}
        >
          Select all
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-7 text-xs"
          disabled={d.selectedEntityIds.length === 0}
          onClick={() => d.setSelectedEntityIds([])}
        >
          Clear
        </Button>
      </>
    ) : null

  return (
    <RecipePane
      step={1}
      title="Entity scope"
      subtitle="Entity IDs for inference"
      actions={actions}
    >
      {!editingWorkspace ? (
        <p className="p-4 text-xs leading-relaxed text-muted-foreground">
          Built version or no draft selected — choose a draft workspace row to enable entity checkboxes.
        </p>
      ) : d.entityIds.length === 0 ? (
        <p className="p-4 text-xs leading-relaxed text-muted-foreground">
          No observed entity IDs yet. Use <strong className="text-foreground">Fetch observations</strong> or
          record observations, then select rows here.
        </p>
      ) : (
        <div className={RECIPE_TABLE_SCROLL}>
          <table className="w-full border-collapse text-xs">
            <thead className="sticky top-0 z-10 border-b border-border/60 bg-muted/90 backdrop-blur-sm">
              <tr className="text-left">
                <th className="w-14 px-2 py-2 font-medium text-muted-foreground">Use</th>
                <th className="px-2 py-2 font-medium text-muted-foreground">Entity ID</th>
                <th className="w-24 px-2 py-2 font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {d.entityIds.map((id) => {
                const checked = d.selectedEntityIds.includes(id)
                const deleting = deletingId === id
                return (
                  <tr key={id} className="border-b border-border/50 last:border-0">
                    <td className="px-2 py-1.5 align-middle">
                      <input
                        type="checkbox"
                        checked={checked}
                        disabled={deleting}
                        onChange={(e) => {
                          if (e.target.checked) {
                            d.setSelectedEntityIds([...d.selectedEntityIds, id])
                          } else {
                            d.setSelectedEntityIds(d.selectedEntityIds.filter((x) => x !== id))
                          }
                        }}
                      />
                    </td>
                    <td className="px-2 py-1.5 align-middle font-mono text-[11px]">{id}</td>
                    <td className="px-2 py-1.5 align-middle">
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        className="h-7 text-destructive hover:text-destructive"
                        disabled={deleting}
                        title={`Delete all observations for ${id}`}
                        onClick={() => {
                          const ok = window.confirm(
                            `Delete all discovery observations for entity ID '${id}' on machine '${d.machineName}'?`
                          )
                          if (!ok) return
                          setDeletingId(id)
                          void d
                            .deleteObservationEntity(id)
                            .finally(() => setDeletingId((curr) => (curr === id ? null : curr)))
                        }}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </RecipePane>
  )
}

export function DiscoveryWorkspaceScopeFields({ d }: { d: UseDiscoveryWorkspaceResult }) {
  const editingWorkspace = Boolean(d.activeDraftId && !d.selectedVersion)

  if (d.selectedVersion) {
    return (
      <RecipePane
        step={2}
        title="Inference thresholds"
        subtitle="Not editable while a built candidate row is selected."
        actions={null}
      >
        <p className="p-4 text-xs leading-relaxed text-muted-foreground">
          Pick a draft workspace in the list to change min edge count, min confidence, Preview, or Build.
        </p>
      </RecipePane>
    )
  }

  if (editingWorkspace && d.mode === 'inference') {
    return (
      <RecipePane
        step={2}
        title="Inference thresholds"
        subtitle="Edges in preview must meet these counts and confidence to be selected automatically."
        actions={null}
      >
        <div className="space-y-3 p-3">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="disc-min-edge-count" className="text-xs">
                Min edge count
              </Label>
              <Input
                id="disc-min-edge-count"
                type="number"
                min={1}
                value={d.minEdgeCount}
                onChange={(e) => d.setMinEdgeCount(e.target.value)}
                className="h-9 text-xs"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="disc-min-confidence" className="text-xs">
                Min confidence
              </Label>
              <Input
                id="disc-min-confidence"
                type="number"
                min={0}
                max={1}
                step={0.01}
                value={d.minConfidence}
                onChange={(e) => d.setMinConfidence(e.target.value)}
                className="h-9 text-xs"
              />
            </div>
          </div>
          {d.previewObservationCount > 0 ? (
            <p className="text-xs text-muted-foreground">
              Preview observations in scope: <span className="font-mono">{d.previewObservationCount}</span>
            </p>
          ) : null}
        </div>
      </RecipePane>
    )
  }

  return null
}

export function DiscoveryWorkspaceModeTabs({
  d,
  compact = false,
}: {
  d: UseDiscoveryWorkspaceResult
  compact?: boolean
}) {
  return (
    <div
      className="flex rounded-lg border border-border/70 bg-background/50 p-0.5"
      role="tablist"
      aria-label="Discovery mode"
    >
      <button
        type="button"
        role="tab"
        aria-label="Inference mode"
        title="Inference"
        aria-selected={d.mode === 'inference'}
        disabled={Boolean(d.selectedVersion)}
        onClick={() => d.setMode('inference')}
        className={cn(
          'inline-flex shrink-0 items-center rounded-md text-xs font-medium transition-colors',
          compact ? 'h-7 gap-1.5 justify-center px-2.5' : 'h-8 gap-1.5 px-2.5',
          d.mode === 'inference'
            ? 'bg-primary text-primary-foreground'
            : 'text-muted-foreground hover:text-foreground'
        )}
      >
        <Bot className="h-3.5 w-3.5 shrink-0" />
        <span>Inference</span>
      </button>
      <button
        type="button"
        role="tab"
        aria-label="Manual mode"
        title="Manual"
        aria-selected={d.mode === 'manual'}
        disabled={Boolean(d.selectedVersion)}
        onClick={() => d.setMode('manual')}
        className={cn(
          'inline-flex shrink-0 items-center rounded-md text-xs font-medium transition-colors',
          compact ? 'h-7 gap-1.5 justify-center px-2.5' : 'h-8 gap-1.5 px-2.5',
          d.mode === 'manual'
            ? 'bg-primary text-primary-foreground'
            : 'text-muted-foreground hover:text-foreground'
        )}
      >
        <Wrench className="h-3.5 w-3.5 shrink-0" />
        <span>Manual</span>
      </button>
    </div>
  )
}

export function DiscoveryManualEdgeChecklist({ d }: { d: UseDiscoveryWorkspaceResult }) {
  const editingWorkspace = Boolean(d.activeDraftId && !d.selectedVersion)
  if (d.mode !== 'manual') return null

  if (!editingWorkspace) {
    return (
      <RecipePane
        step={2}
        title="Transitions"
        subtitle="Inferred edges for build"
        actions={null}
      >
        <p className="p-4 text-xs leading-relaxed text-muted-foreground">
          Select a draft workspace in the tree to load transitions for the selected entities.
        </p>
      </RecipePane>
    )
  }

  const edgeActions =
    d.previewEdges.length > 0 ? (
      <>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="h-7 text-xs"
          onClick={() =>
            d.setSelectedEdgeKeys(
              d.previewEdges.map((e) => `${e.source_state}|||${e.destination_state}`)
            )
          }
        >
          Select all
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-7 text-xs"
          disabled={d.selectedEdgeKeys.length === 0}
          onClick={() => d.setSelectedEdgeKeys([])}
        >
          Clear
        </Button>
      </>
    ) : null

  return (
    <RecipePane
      step={2}
      title="Transitions"
      subtitle="Inferred edges for build"
      actions={edgeActions}
    >
      {d.previewEdges.length === 0 ? (
        <div className="flex min-h-[10rem] flex-col items-start justify-center gap-2 p-4 text-xs leading-relaxed text-muted-foreground">
          {d.previewLoading ? (
            <span className="inline-flex items-center gap-2">
              <Loader2 className="h-4 w-4 shrink-0 animate-spin opacity-70" />
              Loading edges…
            </span>
          ) : d.selectedEntityIds.length === 0 ? (
            <p>
              Select one or more entities in <strong className="text-foreground">Entity scope</strong>; edges
              load automatically for manual mode.
            </p>
          ) : (
            <p>
              No inferred transitions for this scope yet. Check observations or thresholds, then use{' '}
              <strong className="text-foreground">Preview</strong> if you need to refresh.
            </p>
          )}
        </div>
      ) : (
        <div className={RECIPE_TABLE_SCROLL}>
          <table className="w-full border-collapse text-xs">
            <thead className="sticky top-0 z-10 border-b border-border/60 bg-muted/90 backdrop-blur-sm">
              <tr className="text-left">
                <th className="w-14 px-2 py-2 font-medium text-muted-foreground">Use</th>
                <th className="px-2 py-2 font-medium text-muted-foreground">Transition</th>
                <th className="w-24 px-2 py-2 font-medium text-muted-foreground">Count</th>
                <th className="w-28 px-2 py-2 font-medium text-muted-foreground">Confidence</th>
              </tr>
            </thead>
            <tbody>
              {d.previewEdges.map((e, idx) => {
                const key = `${e.source_state}|||${e.destination_state}`
                const checked = d.selectedEdgeKeys.includes(key)
                return (
                  <tr key={`${key}-${idx}`} className="border-b border-border/50 last:border-0">
                    <td className="px-2 py-1.5 align-middle">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={(ev) => {
                          if (ev.target.checked) {
                            d.setSelectedEdgeKeys([...d.selectedEdgeKeys, key])
                          } else {
                            d.setSelectedEdgeKeys(d.selectedEdgeKeys.filter((x) => x !== key))
                          }
                        }}
                      />
                    </td>
                    <td className="px-2 py-1.5 align-middle font-mono text-[11px]">
                      {e.source_state} -&gt; {e.destination_state}
                    </td>
                    <td className="px-2 py-1.5 align-middle tabular-nums">{e.count}</td>
                    <td className="px-2 py-1.5 align-middle tabular-nums">{e.confidence.toFixed(2)}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </RecipePane>
  )
}
