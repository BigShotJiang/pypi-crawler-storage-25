'use client'

import { useCallback } from 'react'
import { ChevronDown, ChevronUp, Plus, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useBuilderStore } from '@/stores/builder'
import { cn } from '@/lib/utils'
import type { FSMState } from '@/lib/types/fsm'

const STATE_TYPES = ['initial', 'stable', 'terminal'] as const
type StateType = (typeof STATE_TYPES)[number]

const TYPE_BORDER_COLORS: Record<StateType, string> = {
  initial: 'border-l-green-500',
  stable: 'border-l-blue-500',
  terminal: 'border-l-red-500',
}

const TYPE_LABELS: Record<StateType, string> = {
  initial: 'Initial',
  stable: 'Stable',
  terminal: 'Terminal',
}

export interface BuilderStateEditorProps {
  states?: FSMState[]
  onAdd?: (s: Pick<FSMState, 'name' | 'type' | 'description'>) => void
  onUpdate?: (index: number, patch: Partial<FSMState>) => void
  onRemove?: (index: number) => void
  onReorder?: (fromIndex: number, toIndex: number) => void
}

export function BuilderStateEditor(props: BuilderStateEditorProps = {}) {
  const storeStates = useBuilderStore((s) => s.states)
  const storeAdd = useBuilderStore((s) => s.addState)
  const storeUpdate = useBuilderStore((s) => s.updateState)
  const storeRemove = useBuilderStore((s) => s.removeState)

  const states = props.states ?? storeStates
  const addState = props.onAdd ?? storeAdd
  const updateState = props.onUpdate ?? storeUpdate
  const removeState = props.onRemove ?? storeRemove

  const handleAdd = useCallback(() => {
    const isFirst = states.length === 0
    addState({
      name: '',
      type: isFirst ? 'initial' : 'stable',
      description: '',
    })
  }, [states.length, addState])

  const stateType = (s: FSMState): StateType => {
    if (s.type === 'initial' || s.type === 'stable' || s.type === 'terminal') {
      return s.type
    }
    return 'stable'
  }

  return (
    <div className="flex flex-col gap-2">
      {states.map((s, idx) => {
        const currentType = stateType(s)
        return (
          <div
            key={idx}
            className={cn(
              'flex flex-col gap-2 rounded-md border border-border/50 border-l-4 p-3',
              TYPE_BORDER_COLORS[currentType],
            )}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 space-y-2">
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Name</Label>
                  <Input
                    value={s.name}
                    onChange={(e) => updateState(idx, { name: e.target.value })}
                    placeholder="state_name"
                    className={cn(
                      'h-8 text-sm',
                      !s.name.trim() && 'border-red-400 focus-visible:ring-red-400'
                    )}
                  />
                  {!s.name.trim() && (
                    <p className="text-[10px] text-red-500">Name required</p>
                  )}
                  {s.name.trim() &&
                    states.some(
                      (other, otherIdx) =>
                        otherIdx !== idx &&
                        other.name.trim().toLowerCase() === s.name.trim().toLowerCase()
                    ) && (
                      <p className="text-[10px] text-amber-600">
                        Duplicate state name
                      </p>
                    )}
                </div>

                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Type</Label>
                  <select
                    value={currentType}
                    onChange={(e) =>
                      updateState(idx, { type: e.target.value as StateType })
                    }
                    className="h-8 w-full rounded-md border border-input bg-background px-3 text-sm"
                  >
                    {STATE_TYPES.map((t) => (
                      <option key={t} value={t}>
                        {TYPE_LABELS[t]}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Description</Label>
                  <Input
                    value={s.description ?? ''}
                    onChange={(e) => updateState(idx, { description: e.target.value })}
                    placeholder="Optional description"
                    className="h-8 text-sm"
                  />
                </div>
              </div>

              <div className="flex shrink-0 flex-col gap-0.5">
                {props.onReorder && (
                  <>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      disabled={idx === 0}
                      onClick={() => props.onReorder!(idx, idx - 1)}
                      aria-label="Move up"
                    >
                      <ChevronUp className="h-3 w-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      disabled={idx === states.length - 1}
                      onClick={() => props.onReorder!(idx, idx + 1)}
                      aria-label="Move down"
                    >
                      <ChevronDown className="h-3 w-3" />
                    </Button>
                  </>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-destructive"
                  onClick={() => removeState(idx)}
                  aria-label="Delete state"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          </div>
        )
      })}

      {states.length === 0 && (
        <p className="text-xs italic text-muted-foreground">
          Add at least one initial and one terminal state.
        </p>
      )}

      <Button variant="outline" size="sm" className="mt-1 w-full" onClick={handleAdd}>
        <Plus className="mr-1.5 h-3.5 w-3.5" />
        Add State
      </Button>
    </div>
  )
}
