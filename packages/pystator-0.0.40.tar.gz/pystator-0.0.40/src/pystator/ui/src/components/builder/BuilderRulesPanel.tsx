"use client"

import { useBuilderStore, type BuilderRule, type BuilderCondition, type BuilderAction } from "@/stores/builder"
import type { FSMState, FSMStateVariable } from "@/lib/types/fsm"
import { Button } from "@/components/ui/button"
import { RuleCard } from "./RuleCard"

export interface BuilderRulesPanelProps {
  rules?: BuilderRule[]
  states?: FSMState[]
  variables?: FSMStateVariable[]
  onAddRule?: () => void
  onUpdateRule?: (id: string, patch: Partial<BuilderRule>) => void
  onRemoveRule?: (id: string) => void
  onAddCondition?: (ruleId: string) => void
  onUpdateCondition?: (ruleId: string, condId: string, patch: Partial<BuilderCondition>) => void
  onRemoveCondition?: (ruleId: string, condId: string) => void
  onAddAction?: (ruleId: string) => void
  onUpdateAction?: (ruleId: string, actionId: string, patch: Partial<BuilderAction>) => void
  onRemoveAction?: (ruleId: string, actionId: string) => void
  onReorderRules?: (fromIndex: number, toIndex: number) => void
}

/**
 * Lists all builder rules and provides controls to add new ones.
 * Each rule is rendered as a visual RuleCard that reads like English.
 *
 * When props are provided they override the builder store reads,
 * allowing the component to be driven by the workspace bridge.
 */
export function BuilderRulesPanel(props: BuilderRulesPanelProps = {}) {
  const storeRules = useBuilderStore((s) => s.rules)
  const storeStates = useBuilderStore((s) => s.states)
  const storeVariables = useBuilderStore((s) => s.variables)
  const storeAddRule = useBuilderStore((s) => s.addRule)
  const storeUpdateRule = useBuilderStore((s) => s.updateRule)
  const storeRemoveRule = useBuilderStore((s) => s.removeRule)
  const storeAddCondition = useBuilderStore((s) => s.addCondition)
  const storeUpdateCondition = useBuilderStore((s) => s.updateCondition)
  const storeRemoveCondition = useBuilderStore((s) => s.removeCondition)
  const storeAddAction = useBuilderStore((s) => s.addAction)
  const storeUpdateAction = useBuilderStore((s) => s.updateAction)
  const storeRemoveAction = useBuilderStore((s) => s.removeAction)

  const rules = props.rules ?? storeRules
  const states = props.states ?? storeStates
  const variables = props.variables ?? storeVariables
  const addRule = props.onAddRule ?? storeAddRule
  const updateRule = props.onUpdateRule ?? storeUpdateRule
  const removeRule = props.onRemoveRule ?? storeRemoveRule
  const addCondition = props.onAddCondition ?? storeAddCondition
  const updateCondition = props.onUpdateCondition ?? storeUpdateCondition
  const removeCondition = props.onRemoveCondition ?? storeRemoveCondition
  const addAction = props.onAddAction ?? storeAddAction
  const updateAction = props.onUpdateAction ?? storeUpdateAction
  const removeAction = props.onRemoveAction ?? storeRemoveAction

  const stateNames = states.map((s) => s.name)
  const variableKeys = variables.map((v) => v.key)

  if (rules.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-4 py-12 text-center">
        <p className="text-sm text-muted-foreground">
          No rules yet. Rules define how your state machine transitions between
          states based on conditions and actions.
        </p>
        <Button onClick={addRule}>Add your first rule</Button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {rules.map((rule, idx) => (
        <RuleCard
          key={rule.id}
          rule={rule}
          ruleIndex={idx}
          isFirst={idx === 0}
          isLast={idx === rules.length - 1}
          stateNames={stateNames}
          variableKeys={variableKeys}
          onUpdate={(patch) => updateRule(rule.id, patch)}
          onRemove={() => removeRule(rule.id)}
          onMoveUp={
            props.onReorderRules ? () => props.onReorderRules!(idx, idx - 1) : undefined
          }
          onMoveDown={
            props.onReorderRules ? () => props.onReorderRules!(idx, idx + 1) : undefined
          }
          onAddCondition={() => addCondition(rule.id)}
          onUpdateCondition={(condId, patch) =>
            updateCondition(rule.id, condId, patch)
          }
          onRemoveCondition={(condId) => removeCondition(rule.id, condId)}
          onAddAction={() => addAction(rule.id)}
          onUpdateAction={(actId, patch) =>
            updateAction(rule.id, actId, patch)
          }
          onRemoveAction={(actId) => removeAction(rule.id, actId)}
        />
      ))}

      <div className="flex justify-center pt-2">
        <Button variant="outline" onClick={addRule}>
          + Add Rule
        </Button>
      </div>
    </div>
  )
}
