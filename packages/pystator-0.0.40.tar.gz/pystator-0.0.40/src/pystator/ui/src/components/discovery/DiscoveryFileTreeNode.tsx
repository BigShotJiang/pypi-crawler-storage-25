'use client'

import { useCallback } from 'react'
import {
  ChevronRight,
  ChevronDown,
  FileText,
  FilePlus,
  Folder,
  MoreVertical,
  RefreshCw,
  Server,
  Settings,
  Trash2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import type { DiscoveryTreeNode } from '@/stores/discovery-browse'
import { useDiscoveryBrowseStore } from '@/stores/discovery-browse'
import { cn } from '@/lib/utils'

const rowMenuTriggerClass =
  'h-7 w-7 shrink-0 text-muted-foreground opacity-0 pointer-events-none transition-opacity hover:text-foreground group-hover/tree-row:opacity-100 group-hover/tree-row:pointer-events-auto data-[state=open]:opacity-100 data-[state=open]:pointer-events-auto focus-visible:opacity-100 focus-visible:pointer-events-auto'

export type DiscoveryDraftMenuAction = 'properties' | 'delete' | 'refresh'

export interface DiscoveryDraftMenuPayload {
  draftId: string
  connectionInstanceId: string
}

export type DiscoveryConnectionMenuAction =
  | 'create_draft'
  | 'properties'
  | 'delete'

export interface DiscoveryConnectionMenuPayload {
  connectionInstanceId: string
}

export interface DiscoveryFileTreeNodeProps {
  node: DiscoveryTreeNode
  depth: number
  selectedDraftId: string | null
  onSelectDraft: (args: {
    draftId: string
    homeChannel: string
    instanceId: string
  }) => void
  onDraftMenuAction?: (
    action: DiscoveryDraftMenuAction,
    payload: DiscoveryDraftMenuPayload
  ) => void
  onConnectionMenuAction?: (
    action: DiscoveryConnectionMenuAction,
    payload: DiscoveryConnectionMenuPayload
  ) => void
}

export function DiscoveryFileTreeNode({
  node,
  depth,
  selectedDraftId,
  onSelectDraft,
  onDraftMenuAction,
  onConnectionMenuAction,
}: DiscoveryFileTreeNodeProps) {
  const expandedIds = useDiscoveryBrowseStore((s) => s.expandedIds)
  const toggleExpand = useDiscoveryBrowseStore((s) => s.toggleExpand)

  const isFolder = node.kind === 'folder'
  const isExpanded = expandedIds.has(node.id)
  const isDraftSelected =
    !isFolder &&
    node.draft_id != null &&
    selectedDraftId === node.draft_id

  const isConnectionInstanceFolder =
    isFolder && node.folder_type === 'instance' && node.connection_id

  const handleClick = useCallback(() => {
    if (isFolder) {
      toggleExpand(node.id)
    } else if (node.draft_id && node.catalog_slug && node.instance_id) {
      onSelectDraft({
        draftId: node.draft_id,
        homeChannel: node.catalog_slug,
        instanceId: node.instance_id,
      })
    }
  }, [isFolder, node, toggleExpand, onSelectDraft])

  const chevron = isFolder ? (
    isExpanded ? (
      <ChevronDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
    ) : (
      <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
    )
  ) : (
    <span className="w-3.5 shrink-0" />
  )

  const icon = isFolder ? (
    isConnectionInstanceFolder ? (
      <Server
        className={cn(
          'h-3.5 w-3.5 shrink-0 text-sky-600 dark:text-sky-500',
          isExpanded && 'text-sky-700 dark:text-sky-400'
        )}
        aria-hidden
      />
    ) : (
      <Folder
        className={cn(
          'h-3.5 w-3.5 shrink-0 text-amber-700/90 dark:text-amber-500/90',
          isExpanded && 'text-amber-800 dark:text-amber-400'
        )}
        aria-hidden
      />
    )
  ) : (
    <FileText className="h-3.5 w-3.5 shrink-0 text-muted-foreground" aria-hidden />
  )

  const draftMenuPayload: DiscoveryDraftMenuPayload | null =
    !isFolder && node.draft_id && node.instance_id
      ? { draftId: node.draft_id, connectionInstanceId: node.instance_id }
      : null

  const connectionMenuPayload: DiscoveryConnectionMenuPayload | null =
    isConnectionInstanceFolder && node.connection_id
      ? { connectionInstanceId: node.connection_id }
      : null

  const rowPaddingLeft = depth * 14 + 6

  return (
    <div>
      {isFolder ? (
        <div
          className="group/tree-row flex w-full min-w-0 items-center gap-0.5 rounded-md pr-0.5 hover:bg-muted/80"
          style={{ paddingLeft: `${rowPaddingLeft}px` }}
        >
          <button
            type="button"
            onClick={handleClick}
            className="flex min-w-0 flex-1 items-center gap-1.5 rounded-md py-1 pl-0 pr-1 text-left text-xs text-foreground transition-colors"
          >
            {chevron}
            {icon}
            <span className="truncate">{node.name}</span>
          </button>
          {onConnectionMenuAction && connectionMenuPayload ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className={rowMenuTriggerClass}
                  aria-label="Connection options"
                  onClick={(e) => e.stopPropagation()}
                >
                  <MoreVertical className="h-3.5 w-3.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                <DropdownMenuItem
                  className="text-xs"
                  onClick={() =>
                    onConnectionMenuAction('create_draft', connectionMenuPayload)
                  }
                >
                  <FilePlus className="text-muted-foreground" />
                  Create draft
                </DropdownMenuItem>
                <DropdownMenuItem
                  className="text-xs"
                  onClick={() =>
                    onConnectionMenuAction('properties', connectionMenuPayload)
                  }
                >
                  <Settings className="text-muted-foreground" />
                  Properties
                </DropdownMenuItem>
                <DropdownMenuItem
                  className="text-xs text-destructive focus:text-destructive"
                  onClick={() =>
                    onConnectionMenuAction('delete', connectionMenuPayload)
                  }
                >
                  <Trash2 className="text-destructive" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : null}
        </div>
      ) : (
        <div
          className="group/tree-row flex w-full min-w-0 items-center gap-0.5 rounded-md pr-0.5 hover:bg-muted/80"
          style={{ paddingLeft: `${rowPaddingLeft}px` }}
        >
          <button
            type="button"
            onClick={handleClick}
            className={cn(
              'flex min-w-0 flex-1 items-center gap-1.5 rounded-md py-1 pl-0 pr-1 text-left text-xs transition-colors',
              isDraftSelected ? 'bg-primary/10 text-primary' : 'text-foreground'
            )}
          >
            {chevron}
            {icon}
            <span className="truncate">{node.name}</span>
          </button>
          {onDraftMenuAction && draftMenuPayload ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className={rowMenuTriggerClass}
                  aria-label="Draft options"
                  onClick={(e) => e.stopPropagation()}
                >
                  <MoreVertical className="h-3.5 w-3.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem
                  className="text-xs"
                  onClick={() => onDraftMenuAction('properties', draftMenuPayload)}
                >
                  <Settings className="text-muted-foreground" />
                  Properties
                </DropdownMenuItem>
                <DropdownMenuItem
                  className="text-xs text-destructive focus:text-destructive"
                  onClick={() => onDraftMenuAction('delete', draftMenuPayload)}
                >
                  <Trash2 className="text-destructive" />
                  Delete
                </DropdownMenuItem>
                <DropdownMenuItem
                  className="text-xs"
                  onClick={() => onDraftMenuAction('refresh', draftMenuPayload)}
                >
                  <RefreshCw className="text-muted-foreground" />
                  Refresh
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : null}
        </div>
      )}

      {isFolder && isExpanded && node.children?.length ? (
        <div>
          {node.children.map((child) => (
            <DiscoveryFileTreeNode
              key={child.id}
              node={child}
              depth={depth + 1}
              selectedDraftId={selectedDraftId}
              onSelectDraft={onSelectDraft}
              onDraftMenuAction={onDraftMenuAction}
              onConnectionMenuAction={onConnectionMenuAction}
            />
          ))}
        </div>
      ) : null}
    </div>
  )
}
