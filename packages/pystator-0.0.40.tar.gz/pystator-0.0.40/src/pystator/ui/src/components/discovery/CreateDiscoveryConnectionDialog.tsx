'use client'

import { useCallback, useEffect, useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  createDiscoveryConnectionInstance,
  getApiErrorMessage,
  testDiscoveryDatabase,
  type DiscoveryDatabaseTestResponse,
} from '@/lib/api'
import { CheckCircle2, Loader2, XCircle } from 'lucide-react'
import { cn } from '@/lib/utils'
import {
  discoveryNamespaceHint,
  discoverySlugHint,
  isValidDiscoveryNamespace,
  isValidDiscoverySlug,
} from '@/lib/discoveryNames'

const BACKENDS = [
  { value: 'sqlite', label: 'SQLite' },
  { value: 'postgres', label: 'PostgreSQL' },
  { value: 'mongodb', label: 'MongoDB' },
  { value: 'redis', label: 'Redis' },
  { value: 'memory', label: 'Memory' },
] as const

export interface CreateDiscoveryConnectionDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** Called with the new registry row id after a successful create. */
  onCreated: (connectionInstanceId: string) => void
}

export function CreateDiscoveryConnectionDialog({
  open,
  onOpenChange,
  onCreated,
}: CreateDiscoveryConnectionDialogProps) {
  const [title, setTitle] = useState('')
  const [namespace, setNamespace] = useState('')
  const [backend, setBackend] = useState<string>('sqlite')
  const [connectionString, setConnectionString] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [testLoading, setTestLoading] = useState(false)
  const [testResult, setTestResult] = useState<DiscoveryDatabaseTestResponse | null>(
    null
  )

  useEffect(() => {
    if (!open) return
    setTitle('')
    setNamespace('')
    setBackend('sqlite')
    setConnectionString('')
    setError(null)
    setSubmitting(false)
    setTestLoading(false)
    setTestResult(null)
  }, [open])

  useEffect(() => {
    setTestResult(null)
  }, [backend, connectionString])

  const titleOk = isValidDiscoverySlug(title)
  const namespaceOk =
    namespace.trim().length === 0 || isValidDiscoveryNamespace(namespace)
  const canSubmit =
    !submitting &&
    titleOk &&
    namespaceOk &&
    connectionString.trim().length > 0

  const canTestConnection =
    !testLoading &&
    !submitting &&
    (backend === 'memory' || connectionString.trim().length > 0)

  const handleTestConnection = useCallback(async () => {
    if (!canTestConnection) return
    setTestLoading(true)
    setTestResult(null)
    setError(null)
    try {
      const res = await testDiscoveryDatabase({
        backend,
        connection_string:
          connectionString.trim().length > 0
            ? connectionString.trim()
            : undefined,
      })
      setTestResult(res)
    } catch (e) {
      setTestResult({
        success: false,
        message: getApiErrorMessage(e, 'Connection test failed'),
      })
    } finally {
      setTestLoading(false)
    }
  }, [backend, canTestConnection, connectionString])

  const handleSubmit = useCallback(async () => {
    if (!canSubmit) return
    setSubmitting(true)
    setError(null)
    try {
      const created = await createDiscoveryConnectionInstance({
        title: title.trim(),
        backend,
        connection_string: connectionString.trim(),
        ...(namespace.trim() ? { namespace: namespace.trim() } : {}),
      })
      onCreated(created.id)
      onOpenChange(false)
    } catch (e) {
      setError(getApiErrorMessage(e, 'Failed to register connection'))
    } finally {
      setSubmitting(false)
    }
  }, [
    backend,
    canSubmit,
    connectionString,
    onCreated,
    onOpenChange,
    namespace,
    title,
  ])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>New discovery connection</DialogTitle>
          <DialogDescription>
            Register a backend and connection string. The raw secret is never
            returned from the API after creation.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 py-2">
          {error ? (
            <p className="text-sm text-destructive">{error}</p>
          ) : null}

          <div className="space-y-1">
            <Label htmlFor="ndc-title" className="text-xs">
              Title
            </Label>
            <Input
              id="ndc-title"
              placeholder="staging_warehouse"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              autoFocus
              aria-invalid={title.length > 0 && !titleOk}
            />
            <p className="text-[11px] text-muted-foreground">{discoverySlugHint()}</p>
          </div>

          <div className="space-y-1">
            <Label htmlFor="ndc-namespace" className="text-xs">
              Namespace (optional)
            </Label>
            <Input
              id="ndc-namespace"
              placeholder="team_a/prod"
              value={namespace}
              onChange={(e) => setNamespace(e.target.value)}
              aria-invalid={namespace.length > 0 && !namespaceOk}
              className="h-9 font-mono text-sm"
            />
            <p className="text-[11px] text-muted-foreground">
              {discoveryNamespaceHint()}
            </p>
          </div>

          <div className="space-y-1">
            <Label htmlFor="ndc-backend" className="text-xs">
              Backend
            </Label>
            <select
              id="ndc-backend"
              className="flex h-9 w-full rounded-md border border-input bg-background px-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              value={backend}
              onChange={(e) => setBackend(e.target.value)}
            >
              {BACKENDS.map((b) => (
                <option key={b.value} value={b.value}>
                  {b.label}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <Label htmlFor="ndc-conn" className="text-xs">
                Connection string
              </Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-8 shrink-0 text-xs"
                disabled={!canTestConnection}
                onClick={() => void handleTestConnection()}
              >
                {testLoading ? (
                  <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                ) : null}
                Test connection
              </Button>
            </div>
            <Input
              id="ndc-conn"
              placeholder="postgresql://…"
              value={connectionString}
              onChange={(e) => setConnectionString(e.target.value)}
              autoComplete="off"
            />
            <p className="text-[11px] text-muted-foreground">
              Memory backend does not require a connection string. Other backends
              need a non-empty URL before testing.
            </p>
            {testResult ? (
              <div
                className={cn(
                  'flex items-start gap-2 rounded-md border px-2.5 py-2 text-xs',
                  testResult.success
                    ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-900 dark:text-emerald-100'
                    : 'border-destructive/40 bg-destructive/10 text-destructive'
                )}
                role="status"
              >
                {testResult.success ? (
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
                ) : (
                  <XCircle className="mt-0.5 h-4 w-4 shrink-0" />
                )}
                <span className="min-w-0 break-words">{testResult.message}</span>
              </div>
            ) : null}
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              disabled={!canSubmit}
              onClick={() => void handleSubmit()}
            >
              {submitting ? 'Creating…' : 'Create'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
