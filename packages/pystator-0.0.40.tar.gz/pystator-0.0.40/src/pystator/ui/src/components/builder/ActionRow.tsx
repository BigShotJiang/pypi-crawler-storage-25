"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"
import type { BuilderAction } from "@/stores/builder"
import { ACTION_TYPE_LABELS } from "@/lib/builder/constants"

interface ActionRowProps {
  action: BuilderAction
  variableKeys: string[]
  onChange: (patch: Partial<BuilderAction>) => void
  onRemove: () => void
}

const ACTION_TYPE_KEYS = Object.keys(ACTION_TYPE_LABELS) as BuilderAction["type"][]

/** Types where only a field selector is needed (no value). */
const FIELD_ONLY_TYPES = new Set(["timestamp", "increment", "decrement", "clear"])

function ActionFields({
  action,
  variableKeys,
  onChange,
}: {
  action: BuilderAction
  variableKeys: string[]
  onChange: (patch: Partial<BuilderAction>) => void
}) {
  switch (action.type) {
    case "set":
      return (
        <>
          <Input
            className="h-9 w-28"
            placeholder="field"
            value={action.field ?? ""}
            onChange={(e) => onChange({ field: e.target.value })}
          />
          <span className="text-xs text-muted-foreground">=</span>
          <Input
            className="h-9 w-28"
            placeholder="value"
            value={action.value ?? ""}
            onChange={(e) => onChange({ value: e.target.value })}
          />
        </>
      )

    case "append":
      return (
        <>
          <Input
            className="h-9 w-28"
            placeholder="field"
            value={action.field ?? ""}
            onChange={(e) => onChange({ field: e.target.value })}
          />
          <Input
            className="h-9 w-28"
            placeholder="value"
            value={action.value ?? ""}
            onChange={(e) => onChange({ value: e.target.value })}
          />
        </>
      )

    case "compute":
      return (
        <>
          <Input
            className="h-9 w-28"
            placeholder="result key"
            value={action.field ?? ""}
            onChange={(e) => onChange({ field: e.target.value })}
          />
          <span className="text-xs text-muted-foreground">=</span>
          <Input
            className="h-9 flex-1 min-w-[120px]"
            placeholder="expression"
            value={action.value ?? ""}
            onChange={(e) => onChange({ value: e.target.value })}
          />
        </>
      )

    case "named":
      return (
        <Input
          className="h-9 w-40"
          placeholder="action name"
          value={action.value ?? ""}
          onChange={(e) => onChange({ value: e.target.value })}
        />
      )

    case "http":
      return (
        <HttpActionTextarea
          value={action.value ?? ""}
          onChange={(v) => onChange({ value: v })}
        />
      )

    default:
      if (FIELD_ONLY_TYPES.has(action.type)) {
        return (
          <Input
            className="h-9 w-36"
            placeholder="field"
            value={action.field ?? ""}
            onChange={(e) => onChange({ field: e.target.value })}
          />
        )
      }
      return null
  }
}

export function ActionRow({ action, variableKeys, onChange, onRemove }: ActionRowProps) {
  return (
    <div className="flex items-start gap-2 flex-wrap">
      {/* Action type selector */}
      <select
        className="h-9 min-w-0 rounded-md border border-input bg-background px-2 text-sm"
        value={action.type}
        onChange={(e) =>
          onChange({ type: e.target.value as BuilderAction["type"], field: "", value: "" })
        }
      >
        {ACTION_TYPE_KEYS.map((key) => (
          <option key={key} value={key}>
            {ACTION_TYPE_LABELS[key]}
          </option>
        ))}
      </select>

      <ActionFields action={action} variableKeys={variableKeys} onChange={onChange} />

      {/* Remove button */}
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
        onClick={onRemove}
        aria-label="Remove action"
      >
        <span aria-hidden="true">&times;</span>
      </Button>
    </div>
  )
}

/** Textarea with basic JSON validation for HTTP action config. */
function HttpActionTextarea({
  value,
  onChange,
}: {
  value: string
  onChange: (v: string) => void
}) {
  const [jsonInvalid, setJsonInvalid] = useState(false)

  const handleBlur = () => {
    if (!value.trim()) {
      setJsonInvalid(false)
      return
    }
    try {
      JSON.parse(value)
      setJsonInvalid(false)
    } catch {
      setJsonInvalid(true)
    }
  }

  return (
    <div className="min-w-0 flex-1 space-y-1">
      <textarea
        className={cn(
          "min-h-[100px] w-full rounded-md border border-input bg-background px-2 py-1 text-xs font-mono resize-y",
          jsonInvalid && "border-red-400 focus-visible:ring-red-400"
        )}
        placeholder='{"url": "...", "method": "POST"}'
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onBlur={handleBlur}
      />
      {jsonInvalid && (
        <p className="text-[10px] text-red-500">Invalid JSON</p>
      )}
    </div>
  )
}
