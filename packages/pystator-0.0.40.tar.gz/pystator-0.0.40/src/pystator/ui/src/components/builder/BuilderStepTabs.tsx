'use client'

import { cn } from '@/lib/utils'

export type BuilderStep = 'variables' | 'states' | 'rules'

const TABS: { step: BuilderStep; label: string }[] = [
  { step: 'variables', label: '1. Variables' },
  { step: 'states', label: '2. States' },
  { step: 'rules', label: '3. Rules' },
]

const BADGE =
  'ml-1.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-primary/20 px-1 text-[10px] font-semibold text-primary'
const AMBER_DOT = 'ml-0.5 inline-block h-1.5 w-1.5 rounded-full bg-amber-500'

export interface BuilderStepTabsProps {
  activeStep: BuilderStep
  onStepChange: (step: BuilderStep) => void
  variableCount?: number
  stateCount?: number
  hasInitialState?: boolean
  hasTerminalState?: boolean
  ruleCount?: number
  hasIncompleteRule?: boolean
}

export function BuilderStepTabs({
  activeStep,
  onStepChange,
  variableCount = 0,
  stateCount = 0,
  hasInitialState = false,
  hasTerminalState = false,
  ruleCount = 0,
  hasIncompleteRule = false,
}: BuilderStepTabsProps) {
  return (
    <div className="flex shrink-0 gap-1">
      {TABS.map(({ step, label }) => {
        let badge: React.ReactNode = null
        let warning = false

        if (step === 'variables' && variableCount > 0) {
          badge = <span className={BADGE}>{variableCount}</span>
        }
        if (step === 'states') {
          if (stateCount > 0) {
            badge = <span className={BADGE}>{stateCount}</span>
          }
          if (stateCount > 0 && (!hasInitialState || !hasTerminalState)) {
            warning = true
          }
        }
        if (step === 'rules') {
          if (ruleCount > 0) {
            badge = <span className={BADGE}>{ruleCount}</span>
          }
          if (hasIncompleteRule) {
            warning = true
          }
        }

        return (
          <button
            key={step}
            type="button"
            onClick={() => onStepChange(step)}
            className={cn(
              'relative rounded-full px-3 py-1 text-xs font-medium transition-colors',
              activeStep === step
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:bg-muted hover:text-foreground',
            )}
          >
            {label}
            {badge}
            {warning && <span className={AMBER_DOT} title="Needs attention" />}
          </button>
        )
      })}
    </div>
  )
}
