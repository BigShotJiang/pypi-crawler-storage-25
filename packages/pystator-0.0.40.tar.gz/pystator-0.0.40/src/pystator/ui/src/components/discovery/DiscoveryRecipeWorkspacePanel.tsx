'use client'

import { Button } from '@/components/ui/button'
import {
  DiscoveryEntityScopeList,
  DiscoveryManualEdgeChecklist,
  DiscoveryWorkspaceModeTabs,
  DiscoveryWorkspaceScopeFields,
} from '@/components/discovery/DiscoveryWorkspaceScope'
import type { UseDiscoveryWorkspaceResult } from '@/hooks/useDiscoveryWorkspace'
import { cn } from '@/lib/utils'
import { Eye, Loader2, RefreshCw, Wrench } from 'lucide-react'

export interface DiscoveryRecipeWorkspacePanelProps {
  workspace: UseDiscoveryWorkspaceResult
  /** Wording for draft hint when no workspace selected. */
  layout: 'threeColumn' | 'standalone'
  className?: string
  /**
   * `full`: mode tabs + fetch + entity scope + thresholds (default).
   * `formOnly`: entity scope + thresholds + manual edges only — put mode/fetch in an external toolbar.
   */
  recipeToolbar?: 'full' | 'formOnly'
  /**
   * When `recipeToolbar` is `full` and a draft is active, gates Preview / Build (same rules as
   * workspace). Omitted when unused (e.g. `formOnly` embeds).
   */
  canRunScope?: boolean
  canBuild?: boolean
}

/**
 * Inference/manual mode, entity scope, thresholds, and manual edge checklist.
 * Used in the right panel; list actions (New/Preview/Build) stay in the middle column in fleet view.
 */
export function DiscoveryRecipeWorkspacePanel({
  workspace: d,
  layout,
  className,
  recipeToolbar = 'full',
  canRunScope,
  canBuild,
}: DiscoveryRecipeWorkspacePanelProps) {
  const hasMachine = d.machineName.trim().length > 0
  const noRowSelected = !d.activeDraftId && !d.selectedVersion

  const draftHint =
    layout === 'threeColumn'
      ? 'Select a draft or built row in the middle panel to configure scope, preview, and build.'
      : 'Select a draft or built row in the list on the left to configure scope, preview, and build.'

  if (!hasMachine) {
    return (
      <div className={cn('rounded-md border border-dashed border-border/80 p-3', className)}>
        <p className="text-xs text-muted-foreground">
          Pin or enter a discovery machine to configure inference scope and build settings.
        </p>
      </div>
    )
  }

  if (noRowSelected) {
    return (
      <div className={cn('space-y-3', className)}>
        <div className="rounded-md border border-dashed border-border/80 p-3">
          <p className="text-xs text-muted-foreground">{draftHint}</p>
        </div>
        {recipeToolbar === 'full' ? <DiscoveryFetchObservationEntitiesButton d={d} /> : null}
      </div>
    )
  }

  if (recipeToolbar === 'formOnly') {
    return (
      <div className={cn('space-y-3', className)}>
        <div className="overflow-hidden rounded-lg border border-border/70 bg-muted/10 shadow-sm">
          <div className="grid min-h-[11rem] grid-cols-1 divide-y divide-border/60 md:grid-cols-2 md:divide-x md:divide-y-0">
            <div className="min-w-0">
              <DiscoveryEntityScopeList d={d} />
            </div>
            <div className="min-w-0">
              {d.mode === 'inference' ? (
                <DiscoveryWorkspaceScopeFields d={d} />
              ) : (
                <DiscoveryManualEdgeChecklist d={d} />
              )}
            </div>
          </div>
        </div>
      </div>
    )
  }

  const showPreviewBuild =
    canRunScope !== undefined && canBuild !== undefined

  return (
    <div className={cn('space-y-3', className)}>
      <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-2 border-b border-border/50 pb-3">
        <div className="flex min-w-0 flex-wrap items-center gap-x-2 gap-y-2">
          <DiscoveryWorkspaceModeTabs d={d} />
          <span className="select-none text-muted-foreground/50" aria-hidden>
            |
          </span>
          <DiscoveryFetchObservationEntitiesButton d={d} compact />
        </div>
        {showPreviewBuild ? (
          <div className="flex shrink-0 items-center gap-2">
            <Button
              type="button"
              size="sm"
              variant="outline"
              className="h-8"
              disabled={!canRunScope || d.previewLoading}
              onClick={() => void d.preview()}
            >
              {d.previewLoading ? (
                <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
              ) : (
                <Eye className="mr-1.5 h-3.5 w-3.5" />
              )}
              Preview
            </Button>
            <Button
              type="button"
              size="sm"
              className="h-8"
              disabled={!canBuild || d.building}
              onClick={() => void d.build()}
            >
              {d.building ? (
                <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
              ) : (
                <Wrench className="mr-1.5 h-3.5 w-3.5" />
              )}
              Build candidate
            </Button>
          </div>
        ) : null}
      </div>
      <div className="overflow-hidden rounded-lg border border-border/70 bg-muted/10 shadow-sm">
        <div className="grid min-h-[11rem] grid-cols-1 divide-y divide-border/60 md:grid-cols-2 md:divide-x md:divide-y-0">
          <div className="min-w-0">
            <DiscoveryEntityScopeList d={d} />
          </div>
          <div className="min-w-0">
            {d.mode === 'inference' ? (
              <DiscoveryWorkspaceScopeFields d={d} />
            ) : (
              <DiscoveryManualEdgeChecklist d={d} />
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export function DiscoveryFetchObservationEntitiesButton({
  d,
  compact = false,
}: {
  d: UseDiscoveryWorkspaceResult
  compact?: boolean
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Button
        type="button"
        size="sm"
        variant="outline"
        title="Reload distinct entity IDs from the latest observations for this machine"
        disabled={d.loadingEntityIds}
        onClick={() => void d.refreshObservationEntities()}
      >
        {d.loadingEntityIds ? (
          <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
        ) : (
          <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
        )}
        Fetch observations
      </Button>
      {!compact ? (
        <span className="text-xs text-muted-foreground">
          Updates the entity scope list below from the server.
        </span>
      ) : null}
    </div>
  )
}
