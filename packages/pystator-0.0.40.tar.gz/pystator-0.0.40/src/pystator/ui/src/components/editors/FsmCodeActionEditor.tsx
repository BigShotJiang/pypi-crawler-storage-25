'use client'

import { Label } from '@/components/ui/label'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'

const PLACEHOLDER = `# ctx is a mutable dict (same as transition context)
ctx["order_id"] = payload.get("id")
`

const CODE_TOOLTIP =
  'Runs on the server with a mutable ctx dict (same as transition context). ' +
  'Write top-level statements; avoid pasting indented blocks from inside ' +
  'another function unless you dedent them.'

export interface FsmCodeActionEditorProps {
  value: string
  onChange: (source: string) => void
  /** Optional stable id for accessibility (e.g. action row index). */
  editorId?: string
}

/**
 * Python source editor for FSM `code:` actions — plain textarea
 * (same pattern as pygubernator's PythonExecNodeForm).
 */
export function FsmCodeActionEditor({ value, onChange, editorId }: FsmCodeActionEditorProps) {
  return (
    <TooltipProvider delayDuration={300}>
      <div className="space-y-1">
        <Tooltip>
          <TooltipTrigger asChild>
            <div>
              <Label className="cursor-help text-xs font-medium text-foreground">
                Python
              </Label>
            </div>
          </TooltipTrigger>
          <TooltipContent side="bottom" align="start" className="max-w-xs text-xs">
            {CODE_TOOLTIP}
          </TooltipContent>
        </Tooltip>
        <textarea
          id={editorId}
          className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono leading-relaxed"
          placeholder={PLACEHOLDER}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          spellCheck={false}
        />
      </div>
    </TooltipProvider>
  )
}
