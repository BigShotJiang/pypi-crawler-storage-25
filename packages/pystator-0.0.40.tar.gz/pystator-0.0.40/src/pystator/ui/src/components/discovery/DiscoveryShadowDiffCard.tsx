'use client'

import { useMemo, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Loader2 } from 'lucide-react'
import type { DiscoveryShadowDiffResponse } from '@/lib/api'

export type DiscoveryShadowFilter = 'differs' | 'all' | 'failures'

interface DiscoveryShadowDiffCardProps {
  machineName: string
  loadingShadow: boolean
  shadowDiffs: DiscoveryShadowDiffResponse[]
  onRefresh: () => void
  onNavigateToEdge?: (sourceState: string, trigger: string, candidateTarget: string | null) => void
  /** Machine names for cross-channel baseline comparison. */
  availableMachineNames?: string[]
  baselineMachineName?: string | null
  onBaselineChange?: (name: string | null) => void
  onCompareBaseline?: () => void
  comparingBaseline?: boolean
}

export function groupDiscoveryShadowDiffRows(shadowDiffs: DiscoveryShadowDiffResponse[]) {
  const map = new Map<
    string,
    { key: string; source_state: string; trigger: string; rows: DiscoveryShadowDiffResponse[] }
  >()
  for (const r of shadowDiffs) {
    const key = `${r.source_state}::${r.trigger}`
    const existing = map.get(key)
    if (existing) existing.rows.push(r)
    else map.set(key, { key, source_state: r.source_state, trigger: r.trigger, rows: [r] })
  }
  return Array.from(map.values()).sort((a, b) => a.key.localeCompare(b.key))
}

export function filterDiscoveryShadowGroups(
  grouped: ReturnType<typeof groupDiscoveryShadowDiffRows>,
  filter: DiscoveryShadowFilter
) {
  if (filter === 'all') return grouped
  if (filter === 'failures') {
    return grouped.filter((g) => g.rows.some((r) => !r.active_success || !r.candidate_success))
  }
  return grouped.filter((g) => g.rows.some((r) => r.differs))
}

export function DiscoveryShadowDiffToolbar({
  machineName,
  loadingShadow,
  filter,
  onFilterChange,
  onRefresh,
  filterId = 'shadow-filter',
  availableMachineNames,
  baselineMachineName,
  onBaselineChange,
  onCompareBaseline,
  comparingBaseline,
}: {
  machineName: string
  loadingShadow: boolean
  filter: DiscoveryShadowFilter
  onFilterChange: (f: DiscoveryShadowFilter) => void
  onRefresh: () => void
  filterId?: string
  /** Machine names for the baseline dropdown (cross-channel compare). */
  availableMachineNames?: string[]
  baselineMachineName?: string | null
  onBaselineChange?: (name: string | null) => void
  onCompareBaseline?: () => void
  comparingBaseline?: boolean
}) {
  const nameOk = machineName.trim().length > 0
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="h-8"
        onClick={onRefresh}
        disabled={!nameOk || loadingShadow}
      >
        {loadingShadow ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : null}
        Refresh shadow diffs
      </Button>
      <div className="flex items-center gap-1.5">
        <label htmlFor={filterId} className="text-xs text-muted-foreground">
          Filter
        </label>
        <select
          id={filterId}
          value={filter}
          onChange={(e) => onFilterChange(e.target.value as DiscoveryShadowFilter)}
          className="h-8 rounded-md border border-input bg-background px-2 text-xs"
        >
          <option value="differs">Differs only</option>
          <option value="failures">Failures only</option>
          <option value="all">All</option>
        </select>
      </div>
      {availableMachineNames && onBaselineChange && onCompareBaseline && (
        <div className="flex items-center gap-1.5 border-l border-border/50 pl-2">
          <label
            htmlFor={`${filterId}-baseline`}
            className="text-xs text-muted-foreground"
          >
            Baseline
          </label>
          <select
            id={`${filterId}-baseline`}
            value={baselineMachineName ?? ''}
            onChange={(e) =>
              onBaselineChange(e.target.value || null)
            }
            className="h-8 rounded-md border border-input bg-background px-2 text-xs"
          >
            <option value="">Select machine…</option>
            {availableMachineNames.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-8"
            disabled={
              !baselineMachineName || comparingBaseline || !nameOk
            }
            onClick={onCompareBaseline}
          >
            {comparingBaseline ? (
              <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
            ) : null}
            Compare
          </Button>
        </div>
      )}
    </div>
  )
}

export function DiscoveryShadowDiffTable({
  shadowDiffs,
  filter,
  onNavigateToEdge,
}: {
  shadowDiffs: DiscoveryShadowDiffResponse[]
  filter: DiscoveryShadowFilter
  onNavigateToEdge?: (sourceState: string, trigger: string, candidateTarget: string | null) => void
}) {
  const grouped = useMemo(() => groupDiscoveryShadowDiffRows(shadowDiffs), [shadowDiffs])
  const filteredGroups = useMemo(
    () => filterDiscoveryShadowGroups(grouped, filter),
    [grouped, filter]
  )

  if (filteredGroups.length === 0) {
    return (
      <p className="text-sm text-muted-foreground">
        {shadowDiffs.length === 0 ? 'No shadow diffs yet.' : 'No rows match the current filter.'}
      </p>
    )
  }

  return (
    <div className="max-h-72 overflow-auto rounded-md border text-xs">
      <table className="w-full">
        <thead className="sticky top-0 bg-muted/80 backdrop-blur">
          <tr className="border-b text-left">
            <th className="p-2">Source</th>
            <th className="p-2">Trigger</th>
            <th className="p-2">Active → Candidate</th>
            <th className="p-2">Differs</th>
            <th className="p-2">Reason</th>
          </tr>
        </thead>
        <tbody>
          {filteredGroups.slice(0, 200).map((g) => {
            const differsCount = g.rows.filter((r) => r.differs).length
            const sample = g.rows[0]
            const reason = g.rows.find((r) => r.reason)?.reason ?? null
            const activeTarget = sample.active_target_state
            const candTarget = sample.candidate_target_state
            return (
              <tr
                key={g.key}
                className="cursor-pointer border-b hover:bg-muted/50"
                onClick={() => onNavigateToEdge?.(g.source_state, g.trigger, candTarget)}
                title="Click to navigate to edge"
              >
                <td className="p-2 font-mono">{g.source_state}</td>
                <td className="p-2 font-mono">{g.trigger}</td>
                <td className="p-2 font-mono">
                  {activeTarget ?? '—'} → {candTarget ?? '—'}
                </td>
                <td className="p-2">
                  {differsCount > 0 ? `${differsCount}/${g.rows.length}` : `0/${g.rows.length}`}
                </td>
                <td className="p-2">{reason ?? '—'}</td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

export function DiscoveryShadowDiffCard({
  machineName,
  loadingShadow,
  shadowDiffs,
  onRefresh,
  onNavigateToEdge,
  availableMachineNames,
  baselineMachineName,
  onBaselineChange,
  onCompareBaseline,
  comparingBaseline,
}: DiscoveryShadowDiffCardProps) {
  const [filter, setFilter] = useState<DiscoveryShadowFilter>('differs')

  return (
    <Card>
      <CardHeader>
        <CardTitle>Shadow diff log</CardTitle>
        <CardDescription>
          Compares active vs candidate transitions at runtime, or on-demand against a baseline machine.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <DiscoveryShadowDiffToolbar
          machineName={machineName}
          loadingShadow={loadingShadow}
          filter={filter}
          onFilterChange={setFilter}
          onRefresh={onRefresh}
          availableMachineNames={availableMachineNames}
          baselineMachineName={baselineMachineName}
          onBaselineChange={onBaselineChange}
          onCompareBaseline={onCompareBaseline}
          comparingBaseline={comparingBaseline}
        />
        <DiscoveryShadowDiffTable
          shadowDiffs={shadowDiffs}
          filter={filter}
          onNavigateToEdge={onNavigateToEdge}
        />
      </CardContent>
    </Card>
  )
}
