"""Orchestrator-level default_fallback: off / hint / persist (pure helpers).

See docs/reference/fsm-config.md for the contract. Raw ``StateMachine.process``
does not use this module — only :class:`~pystator.Orchestrator`.
"""

from __future__ import annotations

import dataclasses
from typing import TYPE_CHECKING, Any, Literal

from pystator._parallel import ParallelStateConfig
from pystator._types import ActionSpec, TransitionResult
from pystator.errors import FSMError, InvalidTransitionError, UndefinedTriggerError

if TYPE_CHECKING:
    from pystator.machine import StateMachine

META_KEY = "orchestrator_default_fallback"
MD_FALLBACK_STATE = "orchestrator_default_fallback"
MD_APPLIED = "orchestrator_applied_default_fallback"
MD_RECOVERY_KIND = "orchestrator_recovery_kind"
MD_ORIGINAL_ERROR = "orchestrator_original_error"
MD_SKIP_APPLY_HISTORY = "orchestrator_skip_apply_history"
MD_PARALLEL_COMPOSITE_SOURCE = "orchestrator_parallel_composite_source"

MODE_OFF: Literal["off"] = "off"
MODE_HINT: Literal["hint"] = "hint"
MODE_PERSIST: Literal["persist"] = "persist"
FallbackMode = Literal["off", "hint", "persist"]
_MODES: frozenset[str] = frozenset({"off", "hint", "persist"})


def parse_mode(meta: dict[str, Any] | None) -> FallbackMode:
    raw = (meta or {}).get(META_KEY, "off")
    if raw is True:
        return "persist"
    if raw is False or raw is None:
        return "off"
    s = str(raw).strip().lower()
    if s in _MODES:
        return s  # type: ignore[return-value]
    return "off"


def is_allowlisted_failure(error: BaseException | None) -> bool:
    if error is None:
        return False
    if isinstance(error, UndefinedTriggerError):
        return True
    return type(error) is InvalidTransitionError


def fallback_leaf_name(machine: StateMachine, configured: str | None) -> str | None:
    if not configured or not str(configured).strip():
        return None
    name = str(configured).strip()
    if name not in machine.states:
        return None
    return name


def parallel_fallback_eligible(
    incoming: ParallelStateConfig,
    updated: ParallelStateConfig,
    results: list[TransitionResult],
) -> bool:
    if updated != incoming:
        return False
    return any(is_allowlisted_failure(r.error) for r in results)


def scalar_fallback_eligible(result: TransitionResult) -> bool:
    return (
        not result.success
        and result.error is not None
        and is_allowlisted_failure(result.error)
    )


def _error_to_original_payload(error: FSMError) -> dict[str, Any]:
    if hasattr(error, "to_dict"):
        return error.to_dict()
    return {"type": type(error).__name__, "message": str(error)}


def enrich_hint_result(
    result: TransitionResult,
    fallback_leaf: str,
    *,
    parallel_composite_source: str | None = None,
) -> TransitionResult:
    meta = {
        **result.metadata,
        MD_FALLBACK_STATE: fallback_leaf,
        MD_RECOVERY_KIND: "hint",
    }
    if parallel_composite_source is not None:
        meta[MD_PARALLEL_COMPOSITE_SOURCE] = parallel_composite_source
    err = result.error
    if err is not None and isinstance(err, FSMError):
        err.context[MD_FALLBACK_STATE] = fallback_leaf
        err.context[MD_RECOVERY_KIND] = "hint"
        if parallel_composite_source is not None:
            err.context[MD_PARALLEL_COMPOSITE_SOURCE] = parallel_composite_source
    return dataclasses.replace(result, metadata=meta)


def _exit_specs_for_source(
    machine: StateMachine, source_state: str
) -> tuple[ActionSpec, ...]:
    """Best-effort on_exit actions when leaving *source_state* (leaf or composite string)."""
    try:
        if ":" in source_state:
            parent = source_state.split(":", 1)[0].strip()
            if parent in machine.states:
                return machine.get_state(parent).on_exit
        elif source_state in machine.states:
            return machine.get_state(source_state).on_exit
    except Exception:
        pass
    return ()


def _enter_specs_for_target(
    machine: StateMachine, target_leaf: str
) -> tuple[ActionSpec, ...]:
    try:
        if target_leaf in machine.states:
            return machine.get_state(target_leaf).on_enter
    except Exception:
        pass
    return ()


def build_persist_synthetic_result(
    machine: StateMachine,
    *,
    source_state: str,
    target_leaf: str,
    trigger: str,
    original_error: FSMError,
) -> TransitionResult:
    on_exit = _exit_specs_for_source(machine, source_state)
    on_enter = _enter_specs_for_target(machine, target_leaf)
    meta: dict[str, Any] = {
        MD_APPLIED: True,
        MD_RECOVERY_KIND: "default_fallback",
        MD_FALLBACK_STATE: target_leaf,
        MD_ORIGINAL_ERROR: _error_to_original_payload(original_error),
        MD_SKIP_APPLY_HISTORY: True,
    }
    if ":" in source_state:
        meta[MD_PARALLEL_COMPOSITE_SOURCE] = source_state

    return TransitionResult.success_result(
        source_state=source_state,
        target_state=target_leaf,
        trigger=trigger,
        actions=(),
        on_exit=on_exit,
        on_enter=on_enter,
        metadata=meta,
    )
