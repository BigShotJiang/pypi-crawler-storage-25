"""CLI subcommands for discovery inference: observe, preview, build, export, list."""

from __future__ import annotations

import argparse
import logging
import os
import sys
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import replace
from datetime import UTC, datetime

from pystator.discovery.models import DiscoveryDraftFilter

logger = logging.getLogger(__name__)


@contextmanager
def _env_overrides(
    backend: str | None, connection_string: str | None
) -> Iterator[None]:
    """Temporarily set discovery env vars for the duration of one command.

    Lets ``--backend`` / ``--db`` CLI flags override the default app
    config without the CLI needing its own engine factory.
    """
    saved: dict[str, str | None] = {}
    if backend:
        saved["PYSTATOR_DISCOVERY_BACKEND"] = os.environ.get(
            "PYSTATOR_DISCOVERY_BACKEND"
        )
        os.environ["PYSTATOR_DISCOVERY_BACKEND"] = backend
    if connection_string:
        saved["PYSTATOR_DISCOVERY_DATABASE_URL"] = os.environ.get(
            "PYSTATOR_DISCOVERY_DATABASE_URL"
        )
        os.environ["PYSTATOR_DISCOVERY_DATABASE_URL"] = connection_string
    try:
        yield
    finally:
        for k, v in saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


def _make_engine():
    """Create the canonical engine from app config."""
    from pystator.discovery.service import InferenceEngine

    return InferenceEngine.from_app_config(quiet=True)


def cmd_observe(
    machine_name: str,
    entity_id: str,
    state: str,
    backend: str | None = None,
    connection_string: str | None = None,
) -> int:
    """Record a single state observation."""
    from pystator.discovery.models import ObservedStateEvent

    with _env_overrides(backend, connection_string):
        engine = _make_engine()
        event = ObservedStateEvent(
            entity_id=entity_id,
            machine_name=machine_name,
            state=state,
            observed_at=datetime.now(UTC),
        )
        try:
            engine.record_observation(machine_name, event)
            print(f"Recorded: {entity_id} -> {state} ({machine_name})")
            return 0
        except Exception as exc:
            print(f"Failed to record observation: {exc}", file=sys.stderr)
            return 1


def cmd_preview(
    machine_name: str,
    entity_ids: list[str] | None = None,
    min_count: int | None = None,
    min_confidence: float | None = None,
    backend: str | None = None,
    connection_string: str | None = None,
) -> int:
    """Preview inferred edges without building a candidate."""
    with _env_overrides(backend, connection_string):
        engine = _make_engine()
        try:
            eff: DiscoveryDraftFilter = DiscoveryDraftFilter(channels=(machine_name,))
            if entity_ids:
                ids = tuple(
                    sorted({x.strip() for x in entity_ids if x and str(x).strip()})
                )
                if ids:
                    eff = replace(eff, entity_ids=ids)
            result = engine.preview_filter(
                eff,
                min_edge_count=min_count,
                min_confidence=min_confidence,
            )
            print(f"Machine:      {result['machine_name']}")
            print(f"Observations: {result['observation_count']}")
            print(f"Entities:     {', '.join(result['entity_ids_used']) or '(none)'}")
            edges = result.get("selected_edges", [])
            if not edges:
                print("No edges above threshold.")
                return 0
            print(
                f"\n{'Source':<20} {'Destination':<20} {'Count':>6} {'Confidence':>10}"
            )
            print("-" * 60)
            for e in edges:
                print(
                    f"{e.source_state:<20} {e.destination_state:<20}"
                    f" {e.count:>6} {e.confidence:>10.2f}"
                )
            return 0
        except Exception as exc:
            print(f"Preview failed: {exc}", file=sys.stderr)
            return 1


def cmd_build(
    machine_name: str,
    version: str | None = None,
    mode: str = "inference",
    backend: str | None = None,
    connection_string: str | None = None,
) -> int:
    """Build a candidate FSM from observations."""
    with _env_overrides(backend, connection_string):
        engine = _make_engine()
        try:
            candidate = engine.build_candidate(machine_name, version, mode=mode)  # type: ignore[arg-type]
            print(f"Built: {candidate.machine_name}@{candidate.version}")
            print(f"Status: {candidate.status}")
            print(f"States: {len(candidate.config.get('states', {}))}")
            return 0
        except Exception as exc:
            print(f"Build failed: {exc}", file=sys.stderr)
            return 1


def cmd_export(
    machine_name: str,
    fmt: str = "mermaid",
    version: str | None = None,
    output: str | None = None,
    backend: str | None = None,
    connection_string: str | None = None,
) -> int:
    """Export a candidate diagram (mermaid or dot)."""
    from pystator.discovery._visualization import candidate_to_dot, candidate_to_mermaid

    with _env_overrides(backend, connection_string):
        engine = _make_engine()
        try:
            if version:
                candidate = engine.get_built_candidate(machine_name, version)
            else:
                candidate = engine.get_latest_built_candidate(machine_name)
            if candidate is None:
                print(f"No candidate found for {machine_name}", file=sys.stderr)
                return 1
            render = candidate_to_mermaid if fmt == "mermaid" else candidate_to_dot
            diagram = render(candidate)
            if output:
                with open(output, "w") as fh:
                    fh.write(diagram)
                print(f"Written to {output}")
            else:
                print(diagram)
            return 0
        except Exception as exc:
            print(f"Export failed: {exc}", file=sys.stderr)
            return 1


def cmd_list(
    machine_name: str,
    backend: str | None = None,
    connection_string: str | None = None,
) -> int:
    """List built candidates for a machine."""
    with _env_overrides(backend, connection_string):
        engine = _make_engine()
        try:
            candidates = engine.list_built_candidates(machine_name)
            if not candidates:
                print("No candidates found.")
                return 0
            print(f"{'Version':<20} {'Status':<12} {'Created'}")
            print("-" * 56)
            for c in candidates:
                created = c.created_at.isoformat(timespec="seconds")
                print(f"{c.version:<20} {c.status:<12} {created}")
            print(f"\n{len(candidates)} candidate(s)")
            return 0
        except Exception as exc:
            print(f"List failed: {exc}", file=sys.stderr)
            return 1


def main() -> int:
    """CLI entry point for ``pystator discovery`` subcommands."""
    parser = argparse.ArgumentParser(
        description="Discovery inference commands",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", help="Command to run")

    def add_backend_args(p: argparse.ArgumentParser) -> None:
        """Add common --backend and --db arguments (override app config)."""
        p.add_argument(
            "--backend",
            default=None,
            help="Override discovery store backend (default: from app config)",
        )
        p.add_argument(
            "--db",
            default=None,
            help="Override discovery connection string (default: from app config)",
        )

    # observe
    obs_p = sub.add_parser("observe", help="Record a state observation")
    obs_p.add_argument("machine_name")
    obs_p.add_argument("--entity", required=True)
    obs_p.add_argument("--state", required=True)
    add_backend_args(obs_p)

    # preview
    prev_p = sub.add_parser("preview", help="Preview inferred edges")
    prev_p.add_argument("machine_name")
    prev_p.add_argument("--entities", nargs="+")
    prev_p.add_argument("--min-count", type=int)
    prev_p.add_argument("--min-confidence", type=float)
    add_backend_args(prev_p)

    # build
    build_p = sub.add_parser("build", help="Build a candidate FSM")
    build_p.add_argument("machine_name")
    build_p.add_argument("--version")
    build_p.add_argument("--mode", choices=["inference", "manual"], default="inference")
    add_backend_args(build_p)

    # export
    exp_p = sub.add_parser("export", help="Export candidate diagram")
    exp_p.add_argument("machine_name")
    exp_p.add_argument(
        "--format", dest="fmt", choices=["mermaid", "dot"], default="mermaid"
    )
    exp_p.add_argument("--version")
    exp_p.add_argument("-o", "--output")
    add_backend_args(exp_p)

    # list
    list_p = sub.add_parser("list", help="List built candidates")
    list_p.add_argument("machine_name")
    add_backend_args(list_p)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    commands = {
        "observe": lambda: cmd_observe(
            args.machine_name,
            entity_id=args.entity,
            state=args.state,
            backend=args.backend,
            connection_string=args.db,
        ),
        "preview": lambda: cmd_preview(
            args.machine_name,
            entity_ids=getattr(args, "entities", None),
            min_count=getattr(args, "min_count", None),
            min_confidence=getattr(args, "min_confidence", None),
            backend=args.backend,
            connection_string=args.db,
        ),
        "build": lambda: cmd_build(
            args.machine_name,
            version=getattr(args, "version", None),
            mode=getattr(args, "mode", "inference"),
            backend=args.backend,
            connection_string=args.db,
        ),
        "export": lambda: cmd_export(
            args.machine_name,
            fmt=getattr(args, "fmt", "mermaid"),
            version=getattr(args, "version", None),
            output=getattr(args, "output", None),
            backend=args.backend,
            connection_string=args.db,
        ),
        "list": lambda: cmd_list(
            args.machine_name,
            backend=args.backend,
            connection_string=args.db,
        ),
    }

    return commands.get(args.command, lambda: (parser.print_help(), 1)[1])()


if __name__ == "__main__":
    sys.exit(main())
