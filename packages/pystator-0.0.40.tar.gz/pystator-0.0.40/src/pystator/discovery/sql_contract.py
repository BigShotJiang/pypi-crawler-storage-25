"""Shared SQL contract constants for discovery SQL backends.

This module centralizes table names and common select fragments so DDL,
provisioning, and SQL stores evolve against one schema contract.
"""

from __future__ import annotations

DISCOVERY_OBSERVATIONS_TABLE = "discovery_observations"
DISCOVERY_EDGES_TABLE = "discovery_edges"
DISCOVERY_BUILT_CANDIDATES_TABLE = "discovery_built_candidates"
DISCOVERY_SHADOW_DIFFS_TABLE = "discovery_shadow_diffs"
DISCOVERY_DRAFTS_TABLE = "discovery_drafts"

DISCOVERY_BASE_TABLES: tuple[str, ...] = (
    DISCOVERY_OBSERVATIONS_TABLE,
    DISCOVERY_EDGES_TABLE,
    DISCOVERY_BUILT_CANDIDATES_TABLE,
    DISCOVERY_SHADOW_DIFFS_TABLE,
    DISCOVERY_DRAFTS_TABLE,
)

OBSERVATION_NATIVE_COLUMNS = (
    "entity_id, state, observed_at, source, source_event_id, "
    "metadata_json, ingested_at, ingest_seq"
)

OBSERVATION_ORDER_ASC = "entity_id, observed_at, ingest_seq, ingested_at"
OBSERVATION_ORDER_DESC = "observed_at DESC, ingest_seq DESC, ingested_at DESC"
