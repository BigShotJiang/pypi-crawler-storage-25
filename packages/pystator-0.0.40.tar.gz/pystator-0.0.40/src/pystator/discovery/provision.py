"""Apply discovery SQL schema from config (db CLI, API SQLite bootstrap)."""

from __future__ import annotations

import logging
from collections.abc import Iterable
from pathlib import Path

from sqlalchemy import create_engine

from pystator.config import (
    get_discovery_backend,
    get_effective_discovery_database_url,
)
from pystator.discovery.sql_schema import apply_discovery_schema

logger = logging.getLogger(__name__)

_SQL_DISCOVERY_BACKENDS = frozenset({"sqlite", "postgres", "postgresql"})


def _url_dedupe_key(url: str) -> str:
    """Stable key so equivalent sqlite URLs are provisioned once."""
    u = url.strip()
    if u.startswith("sqlite:///"):
        path_part = u[10:]
        if path_part == ":memory:":
            return u
        try:
            return f"sqlite:///{Path(path_part).resolve()}"
        except OSError:
            return u
    return u


def _dedupe_urls(urls: Iterable[str]) -> list[str]:
    seen: dict[str, str] = {}
    for raw in urls:
        if not raw or not str(raw).strip():
            continue
        u = str(raw).strip()
        key = _url_dedupe_key(u)
        if key not in seen:
            seen[key] = u
    return list(seen.values())


def provision_discovery_sql_databases(urls: Iterable[str]) -> int:
    """Run idempotent discovery DDL on each distinct URL. Returns count of engines used."""
    unique = _dedupe_urls(urls)
    count = 0
    for url in unique:
        engine = create_engine(url, future=True)
        try:
            apply_discovery_schema(engine)
            count += 1
        finally:
            engine.dispose()
    return count


def provision_discovery_from_app_config() -> int:
    """Read discovery backend/URL from config; provision SQL databases if applicable."""
    backend = get_discovery_backend().strip().lower()
    if backend in {"memory", "mongodb", "redis"}:
        return 0
    if backend not in _SQL_DISCOVERY_BACKENDS:
        return 0
    raw_url, used_app_fallback = get_effective_discovery_database_url(backend)
    if used_app_fallback:
        logger.info(
            "Discovery backend %r has no dedicated discovery URL; "
            "using app database URL as fallback for discovery provisioning.",
            backend,
        )
    if not raw_url or not str(raw_url).strip():
        logger.warning(
            "Discovery backend is %r but PYSTATOR_DISCOVERY_DATABASE_URL is unset; "
            "skipping discovery schema provisioning.",
            backend,
        )
        return 0
    return provision_discovery_sql_databases([raw_url])
