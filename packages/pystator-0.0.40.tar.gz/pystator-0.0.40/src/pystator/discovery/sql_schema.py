"""Idempotent DDL for SQL-backed discovery stores (SQLite and PostgreSQL)."""

from __future__ import annotations

from sqlalchemy import inspect, text
from sqlalchemy.engine import Engine

from pystator.discovery.sql_contract import DISCOVERY_BASE_TABLES
from pystator.discovery.sql_names import discovery_schema, discovery_table_ident


def _move_public_discovery_tables_to_pystator(engine: Engine) -> None:
    """If legacy tables exist only in ``public``, move them to ``pystator``."""
    if engine.dialect.name != "postgresql":
        return
    with engine.begin() as conn:
        for table in DISCOVERY_BASE_TABLES:
            conn.execute(
                text(
                    f"""
                    DO $$
                    BEGIN
                        IF EXISTS (
                            SELECT 1 FROM pg_tables
                            WHERE schemaname = 'public' AND tablename = '{table}'
                        ) AND NOT EXISTS (
                            SELECT 1 FROM pg_tables
                            WHERE schemaname = 'pystator' AND tablename = '{table}'
                        ) THEN
                            EXECUTE 'ALTER TABLE public.{table} SET SCHEMA pystator';
                        END IF;
                    END $$;
                    """
                )
            )


# Tables first (CREATE TABLE IF NOT EXISTS). Indexes run separately after
# :func:`ensure_draft_instance_columns` so legacy ``discovery_drafts`` rows
# get ``instance_id`` before ``idx_discovery_drafts_instance_*`` / unique index.


def _discovery_table_ddls(qualified_prefix: str) -> tuple[str, ...]:
    """``qualified_prefix`` is ``\"pystator.\"`` for PostgreSQL or empty for SQLite."""
    qp = qualified_prefix
    return (
        f"""
    CREATE TABLE IF NOT EXISTS {qp}discovery_observations (
      machine_name TEXT NOT NULL,
      entity_id TEXT NOT NULL,
      state TEXT NOT NULL,
      observed_at TEXT NOT NULL,
      source TEXT NOT NULL,
      source_event_id TEXT,
      metadata_json TEXT NOT NULL,
      ingested_at TEXT NOT NULL,
      ingest_seq INTEGER NOT NULL DEFAULT 0,
      UNIQUE(machine_name, entity_id, state, observed_at, source, source_event_id)
    )
    """,
        f"""
    CREATE TABLE IF NOT EXISTS {qp}discovery_edges (
      machine_name TEXT NOT NULL,
      source_state TEXT NOT NULL,
      destination_state TEXT NOT NULL,
      count INTEGER NOT NULL,
      unique_entities INTEGER NOT NULL,
      unique_sources INTEGER NOT NULL,
      confidence REAL NOT NULL,
      last_seen_at TEXT,
      UNIQUE(machine_name, source_state, destination_state)
    )
    """,
        f"""
    CREATE TABLE IF NOT EXISTS {qp}discovery_built_candidates (
      machine_name TEXT NOT NULL,
      version TEXT NOT NULL,
      status TEXT NOT NULL,
      config_json TEXT NOT NULL,
      metadata_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      candidate_sequence INTEGER NOT NULL,
      UNIQUE(machine_name, version),
      UNIQUE(machine_name, candidate_sequence)
    )
    """,
        f"""
    CREATE TABLE IF NOT EXISTS {qp}discovery_shadow_diffs (
      machine_name TEXT NOT NULL,
      source_state TEXT NOT NULL,
      trigger TEXT NOT NULL,
      active_success INTEGER NOT NULL,
      active_target_state TEXT,
      candidate_success INTEGER NOT NULL,
      candidate_target_state TEXT,
      differs INTEGER NOT NULL,
      reason TEXT,
      metadata_json TEXT NOT NULL,
      recorded_at TEXT NOT NULL
    )
    """,
        f"""
    CREATE TABLE IF NOT EXISTS {qp}discovery_drafts (
      id TEXT PRIMARY KEY,
      instance_id TEXT NOT NULL DEFAULT '00000000-0000-4000-8000-000000000001',
      machine_name TEXT NOT NULL,
      title TEXT,
      selected_entity_ids_json TEXT NOT NULL DEFAULT '[]',
      mode TEXT NOT NULL DEFAULT 'inference',
      min_edge_count INTEGER NOT NULL DEFAULT 2,
      min_confidence REAL NOT NULL DEFAULT 0.5,
      manual_edge_selection_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      last_built_version TEXT,
      filter_json TEXT NOT NULL DEFAULT '{{}}',
      observation_source_json TEXT NOT NULL DEFAULT '{{}}'
    )
    """,
    )


def _discovery_index_ddls(qualified_prefix: str) -> tuple[str, ...]:
    qp = qualified_prefix
    return (
        f"""
    CREATE INDEX IF NOT EXISTS idx_discovery_obs_machine_observed
    ON {qp}discovery_observations(machine_name, observed_at)
    """,
        f"""
    CREATE INDEX IF NOT EXISTS idx_discovery_edges_machine
    ON {qp}discovery_edges(machine_name)
    """,
        f"""
    CREATE INDEX IF NOT EXISTS idx_discovery_built_candidates_machine_created
    ON {qp}discovery_built_candidates(machine_name, created_at)
    """,
        f"""
    CREATE INDEX IF NOT EXISTS idx_discovery_shadow_machine_recorded
    ON {qp}discovery_shadow_diffs(machine_name, recorded_at)
    """,
        f"""
    CREATE INDEX IF NOT EXISTS idx_discovery_drafts_machine_updated
    ON {qp}discovery_drafts(machine_name, updated_at)
    """,
        f"""
    CREATE INDEX IF NOT EXISTS idx_discovery_drafts_instance_updated
    ON {qp}discovery_drafts(instance_id, updated_at)
    """,
    )


def _insp_schema(engine: Engine) -> str | None:
    return discovery_schema(engine)


def _has_table(insp, engine: Engine, name: str) -> bool:
    sch = _insp_schema(engine)
    if sch:
        return name in insp.get_table_names(schema=sch)
    return name in insp.get_table_names()


def migrate_legacy_discovery_names(engine: Engine) -> None:
    """Rename pre-2026 discovery tables if present (idempotent)."""
    insp = inspect(engine)
    if engine.dialect.name == "postgresql":
        with engine.begin() as conn:
            pub = set(insp.get_table_names(schema="public"))
            pys = set(insp.get_table_names(schema="pystator"))
            if (
                "discovery_candidates" in pub
                and "discovery_built_candidates" not in pys
                and "discovery_built_candidates" not in pub
            ):
                conn.execute(
                    text(
                        "ALTER TABLE public.discovery_candidates "
                        "RENAME TO discovery_built_candidates"
                    )
                )
                conn.execute(
                    text(
                        "ALTER TABLE public.discovery_built_candidates "
                        "SET SCHEMA pystator"
                    )
                )
        insp = inspect(engine)
        with engine.begin() as conn:
            pub = set(insp.get_table_names(schema="public"))
            pys = set(insp.get_table_names(schema="pystator"))
            if (
                "discovery_workspaces" in pub
                and "discovery_drafts" not in pys
                and "discovery_drafts" not in pub
            ):
                conn.execute(
                    text(
                        "ALTER TABLE public.discovery_workspaces "
                        "RENAME TO discovery_drafts"
                    )
                )
                conn.execute(
                    text("ALTER TABLE public.discovery_drafts SET SCHEMA pystator")
                )
        return

    tables = set(insp.get_table_names())
    with engine.begin() as conn:
        if (
            "discovery_candidates" in tables
            and "discovery_built_candidates" not in tables
        ):
            conn.execute(
                text(
                    "ALTER TABLE discovery_candidates RENAME TO discovery_built_candidates"
                )
            )
            tables.discard("discovery_candidates")
            tables.add("discovery_built_candidates")
        if "discovery_workspaces" in tables and "discovery_drafts" not in tables:
            conn.execute(
                text("ALTER TABLE discovery_workspaces RENAME TO discovery_drafts")
            )


def ensure_candidate_sequence_column(engine: Engine) -> None:
    """Add candidate_sequence to legacy discovery_built_candidates and backfill (idempotent)."""
    insp = inspect(engine)
    sch = _insp_schema(engine)
    if not _has_table(insp, engine, "discovery_built_candidates"):
        return
    cols = {
        c["name"] for c in insp.get_columns("discovery_built_candidates", schema=sch)
    }
    if "candidate_sequence" in cols:
        return

    dialect = engine.dialect.name
    dt = discovery_table_ident(engine, "discovery_built_candidates")
    with engine.begin() as conn:
        conn.execute(text(f"ALTER TABLE {dt} ADD COLUMN candidate_sequence INTEGER"))
        if dialect == "sqlite":
            conn.execute(
                text(
                    f"""
                    UPDATE {dt} AS t
                    SET candidate_sequence = (
                      SELECT COUNT(*)
                      FROM {dt} AS o
                      WHERE o.machine_name = t.machine_name
                        AND (
                          o.created_at < t.created_at
                          OR (o.created_at = t.created_at AND o.version < t.version)
                        )
                    ) + 1
                    """
                )
            )
        else:
            conn.execute(
                text(
                    f"""
                    UPDATE {dt} AS t
                    SET candidate_sequence = sub.seq
                    FROM (
                      SELECT machine_name, version,
                             ROW_NUMBER() OVER (
                               PARTITION BY machine_name
                               ORDER BY created_at ASC, version ASC
                             ) AS seq
                      FROM {dt}
                    ) AS sub
                    WHERE t.machine_name = sub.machine_name AND t.version = sub.version
                    """
                )
            )
        conn.execute(
            text(
                f"CREATE UNIQUE INDEX IF NOT EXISTS "
                f"ux_discovery_built_candidates_machine_sequence "
                f"ON {dt}(machine_name, candidate_sequence)"
            )
        )


def ensure_draft_filter_column(engine: Engine) -> None:
    """Add filter_json to legacy discovery_drafts (idempotent)."""
    insp = inspect(engine)
    if not _has_table(insp, engine, "discovery_drafts"):
        return
    sch = _insp_schema(engine)
    cols = {c["name"] for c in insp.get_columns("discovery_drafts", schema=sch)}
    if "filter_json" in cols:
        return
    dt = discovery_table_ident(engine, "discovery_drafts")
    with engine.begin() as conn:
        conn.execute(
            text(
                f"ALTER TABLE {dt} ADD COLUMN filter_json TEXT NOT NULL DEFAULT '{{}}'"
            )
        )


def ensure_draft_instance_columns(engine: Engine) -> None:
    """Add instance_id and observation_source_json to discovery_drafts (idempotent)."""
    from pystator.discovery.constants import DEFAULT_DISCOVERY_INSTANCE_ID

    insp = inspect(engine)
    if not _has_table(insp, engine, "discovery_drafts"):
        return
    sch = _insp_schema(engine)
    cols = {c["name"] for c in insp.get_columns("discovery_drafts", schema=sch)}
    dt = discovery_table_ident(engine, "discovery_drafts")
    with engine.begin() as conn:
        if "instance_id" not in cols:
            conn.execute(
                text(
                    f"ALTER TABLE {dt} ADD COLUMN instance_id TEXT NOT NULL "
                    f"DEFAULT '{DEFAULT_DISCOVERY_INSTANCE_ID}'"
                )
            )
            cols.add("instance_id")
        if "observation_source_json" not in cols:
            conn.execute(
                text(
                    f"ALTER TABLE {dt} ADD COLUMN observation_source_json "
                    "TEXT NOT NULL DEFAULT '{}'"
                )
            )


def ensure_draft_title_column(engine: Engine) -> None:
    """Add title to legacy discovery_drafts (idempotent)."""
    insp = inspect(engine)
    if not _has_table(insp, engine, "discovery_drafts"):
        return
    sch = _insp_schema(engine)
    cols = {c["name"] for c in insp.get_columns("discovery_drafts", schema=sch)}
    if "title" in cols:
        return
    dt = discovery_table_ident(engine, "discovery_drafts")
    with engine.begin() as conn:
        conn.execute(text(f"ALTER TABLE {dt} ADD COLUMN title TEXT"))


def ensure_draft_title_uniqueness(engine: Engine) -> None:
    """Backfill empty titles, resolve duplicates, add unique index (idempotent)."""
    insp = inspect(engine)
    if not _has_table(insp, engine, "discovery_drafts"):
        return
    dialect = engine.dialect.name
    sch = _insp_schema(engine)
    dt = discovery_table_ident(engine, "discovery_drafts")
    idx_name = "uq_discovery_drafts_instance_title"
    existing = {ix["name"] for ix in insp.get_indexes("discovery_drafts", schema=sch)}
    with engine.begin() as conn:
        rows = conn.execute(
            text(
                f"SELECT id, instance_id, machine_name, title "
                f"FROM {dt} ORDER BY updated_at"
            )
        ).fetchall()
        for rid, inst_id, machine_name, title_col in rows:
            t = (title_col or "").strip()
            if not t:
                t = (machine_name or "draft").strip() or "draft"
            conn.execute(
                text(f"UPDATE {dt} SET title = :t WHERE id = :id"),
                {"t": t, "id": rid},
            )
        rows = conn.execute(
            text(f"SELECT id, instance_id, title FROM {dt} ORDER BY updated_at")
        ).fetchall()
        used: set[tuple[str, str]] = set()
        for rid, inst_id, title_col in rows:
            inst = str(inst_id)
            raw = str(title_col or "").strip() or "draft"
            base = raw
            candidate = base
            n = 2
            while (inst, candidate) in used:
                candidate = f"{base}_{n}"
                n += 1
            used.add((inst, candidate))
            if candidate != raw:
                conn.execute(
                    text(f"UPDATE {dt} SET title = :t WHERE id = :id"),
                    {"t": candidate, "id": rid},
                )
        if idx_name not in existing and dialect in ("sqlite", "postgresql"):
            conn.execute(
                text(
                    f"CREATE UNIQUE INDEX IF NOT EXISTS {idx_name} "
                    f"ON {dt}(instance_id, title)"
                )
            )


def migrate_legacy_draft_entity_ids(engine: Engine) -> int:
    """Convert legacy ``selected_entity_ids`` scoping to explicit filters.

    Before the ``DiscoveryDraftFilter`` system, drafts used
    ``selected_entity_ids`` to scope which entities the preview/build
    workflows read. With the filter system in place, the engine's
    ``effective_inference_filter`` no longer merges
    ``selected_entity_ids`` into the filter. This migration ensures
    every draft that relied on the old path gets an explicit
    ``filter_json`` with ``entity_ids`` populated.

    Idempotent: drafts that already have a non-empty ``filter_json``
    are skipped. Returns the number of drafts migrated.
    """
    insp = inspect(engine)
    if not _has_table(insp, engine, "discovery_drafts"):
        return 0
    import json

    dt = discovery_table_ident(engine, "discovery_drafts")
    migrated = 0
    with engine.begin() as conn:
        rows = conn.execute(
            text(f"SELECT id, selected_entity_ids_json, filter_json FROM {dt}")
        ).fetchall()
        for row_id, sel_json, filt_json in rows:
            sel = json.loads(sel_json or "[]")
            filt = json.loads(filt_json or "{}")
            # Only migrate if the draft has entity IDs but no
            # meaningful filter (empty dict or all-null fields).
            has_entity_ids = isinstance(sel, list) and len(sel) > 0
            filter_is_empty = not filt or all(
                v is None or v == [] or v == () for v in filt.values()
            )
            if has_entity_ids and filter_is_empty:
                new_filter = {"entity_ids": sel}
                conn.execute(
                    text(f"UPDATE {dt} SET filter_json = :fj WHERE id = :id"),
                    {"fj": json.dumps(new_filter), "id": row_id},
                )
                migrated += 1
    return migrated


def apply_discovery_schema(engine: Engine) -> None:
    """Create discovery tables and indexes if missing (idempotent)."""
    migrate_legacy_discovery_names(engine)
    _move_public_discovery_tables_to_pystator(engine)
    prefix = "pystator." if engine.dialect.name == "postgresql" else ""
    table_ddls = _discovery_table_ddls(prefix)
    index_ddls = _discovery_index_ddls(prefix)
    with engine.begin() as conn:
        for stmt in table_ddls:
            conn.execute(text(stmt))
    ensure_candidate_sequence_column(engine)
    ensure_draft_filter_column(engine)
    ensure_draft_title_column(engine)
    ensure_draft_instance_columns(engine)
    migrate_legacy_draft_entity_ids(engine)
    with engine.begin() as conn:
        for stmt in index_ddls:
            conn.execute(text(stmt))
    ensure_draft_title_uniqueness(engine)
