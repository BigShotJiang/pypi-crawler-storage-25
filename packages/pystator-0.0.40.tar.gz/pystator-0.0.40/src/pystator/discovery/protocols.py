"""Protocols for discovery persistence and querying."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

from pystator.discovery.models import (
    BuiltByDraftAggregate,
    BuiltDiscoveryCandidate,
    DiscoveryDraft,
    DiscoveryDraftFilter,
    ObservationIdentity,
    ObservedStateEvent,
    ShadowDiff,
)

if TYPE_CHECKING:
    from pystator.discovery.observation_source import ObservationSourceConfig


@runtime_checkable
class ObservationStore(Protocol):
    def add_observation(self, event: ObservedStateEvent) -> bool: ...

    def list_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> list[ObservedStateEvent]: ...

    def list_entity_ids(self, machine_name: str) -> list[str]: ...

    def delete_observations_for_entity(
        self, machine_name: str, entity_id: str
    ) -> int: ...

    def delete_observation(
        self, machine_name: str, identity: ObservationIdentity
    ) -> bool:
        """Delete a single observation row matching the natural key. Returns True if a row was removed."""
        ...

    def resolve_observations(
        self,
        filter: DiscoveryDraftFilter,
        *,
        observation_source: ObservationSourceConfig | None = None,
        limit: int = 50_000,
    ) -> tuple[list[ObservedStateEvent], bool]:
        """Resolve observations matching *filter* across all channels.

        Args:
            filter: Filter selecting observations from the shared event
                stream.
            observation_source: Optional per-draft table/collection and
                field mapping; implementations may ignore when unsupported.
            limit: Maximum rows to return. When the underlying result
                exceeds *limit* the returned list is truncated and the
                second tuple element is ``True``.

        Returns:
            Tuple of ``(events, limit_reached)``.
        """
        ...

    def list_all_channels(self) -> list[str]:
        """Return distinct ``machine_name`` values across all observations."""
        ...

    def list_all_sources(self) -> list[str]:
        """Return distinct ``source`` values across all observations."""
        ...


@runtime_checkable
class BuiltDiscoveryCandidateStore(Protocol):
    """Persistence for built (materialized) discovery candidate FSM snapshots."""

    def save_built_candidate(
        self, candidate: BuiltDiscoveryCandidate
    ) -> BuiltDiscoveryCandidate: ...

    def get_built_candidate(
        self, machine_name: str, version: str
    ) -> BuiltDiscoveryCandidate | None: ...

    def get_latest_built_candidate(
        self, machine_name: str
    ) -> BuiltDiscoveryCandidate | None: ...

    def list_built_candidates(
        self, machine_name: str
    ) -> list[BuiltDiscoveryCandidate]: ...

    def delete_built_candidate(self, machine_name: str, version: str) -> bool:
        """Delete a built candidate. Returns True if deleted."""
        ...

    def count_built_candidates_by_draft(
        self, draft_ids: list[str]
    ) -> dict[str, BuiltByDraftAggregate]:
        """Per-draft built-candidate aggregates in one round-trip.

        Looks up rows in ``discovery_built_candidates`` whose
        ``metadata_json`` carries a ``draft_id`` matching one of
        *draft_ids*. Drafts with zero matching builds are absent from
        the returned dict. Used by the Discovery Instances list to
        avoid N+1 queries.

        Args:
            draft_ids: Draft (instance) ids to aggregate over.

        Returns:
            Dict keyed by draft id with the corresponding aggregate.
            Empty input → empty dict.
        """
        ...


@runtime_checkable
class ShadowResultStore(Protocol):
    def record_shadow_diff(self, diff: ShadowDiff) -> None: ...

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]: ...


@runtime_checkable
class DraftStore(Protocol):
    """Persistence for discovery drafts (mutable scope before build)."""

    def save_draft(self, draft: DiscoveryDraft) -> DiscoveryDraft: ...

    def get_draft(self, draft_id: str) -> DiscoveryDraft | None: ...

    def list_all_drafts(self) -> list[DiscoveryDraft]:
        """Return every draft across all channels, newest updated first."""
        ...

    def delete_draft(self, draft_id: str) -> bool: ...
