"""Qualified discovery table names (PostgreSQL ``pystator`` schema vs unqualified SQLite)."""

from __future__ import annotations

from sqlalchemy.engine import Engine


def discovery_schema(engine: Engine | None) -> str | None:
    """Return ``pystator`` for PostgreSQL discovery DDL/SQL; ``None`` for SQLite."""
    if engine is None:
        return None
    return "pystator" if engine.dialect.name == "postgresql" else None


def discovery_table_ident(engine: Engine, base: str) -> str:
    """SQL fragment for a discovery table: ``pystator.name`` or ``name``."""
    sch = discovery_schema(engine)
    return f"{sch}.{base}" if sch else base
