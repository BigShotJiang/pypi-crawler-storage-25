"""Resolve default discovery backend + URL from app config (env / cfg)."""

from __future__ import annotations

import os


def resolve_default_discovery_connection(
    *, quiet: bool = False
) -> tuple[str, str | None]:
    """Return ``(backend, db_url)`` matching :meth:`InferenceEngine.from_app_config`.

    ``db_url`` may be None when backend is memory.
    """
    from pystator.config.discovery import (
        get_discovery_backend,
        get_discovery_database_url,
        get_effective_discovery_database_url,
    )
    from pystator.db.config import get_db_url

    backend = get_discovery_backend()
    discovery_url = get_discovery_database_url()
    effective_url, _ = get_effective_discovery_database_url(backend)
    db_url = effective_url

    if backend == "memory" and not discovery_url:
        if db_url is None:
            db_url = get_db_url(required=False)
            if not quiet:
                print(f"ℹ Using default SQLite database: {db_url}")
        backend = "sqlite"
        if os.environ.get("PYSTATOR_DISCOVERY_BACKEND", "").strip().lower() == "memory":
            backend = "memory"
            db_url = None

    return backend, db_url
