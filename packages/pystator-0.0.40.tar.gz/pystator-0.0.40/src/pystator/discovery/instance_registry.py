"""CRUD for discovery connection instances (registry in the main app database)."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import select, text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session

from pystator.discovery.connection_resolution import (
    resolve_default_discovery_connection,
)
from pystator.discovery.constants import DEFAULT_DISCOVERY_INSTANCE_ID
from pystator.discovery.slug import (
    validate_discovery_namespace,
    validate_discovery_slug,
)

logger = logging.getLogger(__name__)


class _Unset:
    """Sentinel for PATCH fields that were not provided."""


_UNSET = _Unset()

_REGISTRY_BACKENDS = frozenset(
    {"memory", "sqlite", "postgres", "postgresql", "mongodb", "redis"}
)


def normalize_registry_backend(name: str) -> str:
    """Lowercase backend id; raises :class:`ValueError` if not allowed."""
    b = str(name).strip().lower()
    if b not in _REGISTRY_BACKENDS:
        raise ValueError(f"Unsupported discovery backend: {name!r}")
    return b


def _validate_row_backend_connection(backend: str, connection_string: str) -> None:
    if backend.strip().lower() == "memory":
        return
    if not (connection_string or "").strip():
        raise ValueError("connection_string is required for this discovery backend")


def _repair_sqlite_discovery_connection_rows(session: Session) -> None:
    """Remove legacy rows whose ``id`` has wrong SQLite affinity (REAL/INTEGER).

    Normal paths use :class:`~pystator.db.types.CrossDialectUUID`, which binds
    UUIDs as strings on SQLite. Older or hand-edited DBs may still have
    non-text ``id`` cells; those rows cannot load through the ORM and are
    deleted so a fresh default row can be inserted.
    """
    bind = session.get_bind()
    if bind is None or bind.dialect.name != "sqlite":
        return
    try:
        rows = session.execute(
            text(
                "SELECT rowid FROM discovery_connection_instances "
                "WHERE typeof(id) NOT IN ('text', 'blob')"
            )
        ).fetchall()
    except OperationalError:
        return
    for (rowid,) in rows:
        session.execute(
            text("DELETE FROM discovery_connection_instances WHERE rowid = :rid"),
            {"rid": rowid},
        )
        logger.warning(
            "Removed discovery_connection_instances rowid=%s (invalid id type on SQLite)",
            rowid,
        )
    if rows:
        session.flush()


@dataclass(frozen=True, slots=True)
class DiscoveryConnectionInstance:
    """Public view of a row in ``discovery_connection_instances``."""

    id: str
    title: str | None
    namespace: str | None
    backend: str
    connection_string: str
    created_at: datetime | None
    updated_at: datetime | None


def ensure_default_discovery_instance(session: Session) -> None:
    """Insert the default discovery instance row if missing (idempotent)."""
    from pystator.db.models.discovery_connection_instance import (
        DiscoveryConnectionInstanceModel,
    )

    _repair_sqlite_discovery_connection_rows(session)
    uid = UUID(DEFAULT_DISCOVERY_INSTANCE_ID)
    row = session.get(DiscoveryConnectionInstanceModel, uid)
    if row is not None:
        return

    backend, db_url = resolve_default_discovery_connection(quiet=True)
    now = datetime.now(UTC)
    session.add(
        DiscoveryConnectionInstanceModel(
            id=uid,
            title="default",
            backend=backend,
            connection_string=db_url or "",
            created_at=now,
            updated_at=now,
        )
    )
    session.commit()


def list_connection_instances(session: Session) -> list[DiscoveryConnectionInstance]:
    from pystator.db.models.discovery_connection_instance import (
        DiscoveryConnectionInstanceModel,
    )

    ensure_default_discovery_instance(session)
    stmt = select(DiscoveryConnectionInstanceModel).order_by(
        DiscoveryConnectionInstanceModel.created_at.desc()
    )
    rows = list(session.execute(stmt).scalars().all())
    out = [
        DiscoveryConnectionInstance(
            id=str(r.id),
            title=r.title,
            namespace=getattr(r, "namespace", None),
            backend=r.backend,
            connection_string=r.connection_string,
            created_at=r.created_at,
            updated_at=r.updated_at,
        )
        for r in rows
    ]
    out.sort(
        key=lambda r: (
            (r.namespace or "").lower(),
            (r.title or "").lower(),
            r.id.lower(),
        )
    )
    return out


def create_connection_instance(
    session: Session,
    *,
    title: str | None,
    backend: str,
    connection_string: str,
    namespace: str | None = None,
) -> DiscoveryConnectionInstance:
    from pystator.db.models.discovery_connection_instance import (
        DiscoveryConnectionInstanceModel,
    )

    if title is None or not str(title).strip():
        raise ValueError("title cannot be empty")
    title_clean = validate_discovery_slug(str(title), "title")
    ns_clean = validate_discovery_namespace(namespace, "namespace")
    now = datetime.now(UTC)
    row = DiscoveryConnectionInstanceModel(
        title=title_clean,
        namespace=ns_clean,
        backend=normalize_registry_backend(backend),
        connection_string=connection_string,
        created_at=now,
        updated_at=now,
    )
    session.add(row)
    session.commit()
    session.refresh(row)
    return DiscoveryConnectionInstance(
        id=str(row.id),
        title=row.title,
        namespace=getattr(row, "namespace", None),
        backend=row.backend,
        connection_string=row.connection_string,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


def get_connection_instance(
    session: Session, instance_id: str
) -> DiscoveryConnectionInstance | None:
    from pystator.db.models.discovery_connection_instance import (
        DiscoveryConnectionInstanceModel,
    )

    _repair_sqlite_discovery_connection_rows(session)
    try:
        uid = UUID(instance_id)
    except ValueError:
        return None
    row = session.get(DiscoveryConnectionInstanceModel, uid)
    if row is None:
        return None
    return DiscoveryConnectionInstance(
        id=str(row.id),
        title=row.title,
        namespace=getattr(row, "namespace", None),
        backend=row.backend,
        connection_string=row.connection_string,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


def update_connection_instance(
    session: Session,
    instance_id: str,
    *,
    title: str | None | _Unset = _UNSET,
    backend: str | _Unset = _UNSET,
    connection_string: str | _Unset = _UNSET,
    namespace: str | None | _Unset = _UNSET,
) -> DiscoveryConnectionInstance | None:
    """Update fields. Use :data:`_UNSET` for any field to leave it unchanged."""
    from pystator.db.models.discovery_connection_instance import (
        DiscoveryConnectionInstanceModel,
    )

    _repair_sqlite_discovery_connection_rows(session)
    try:
        uid = UUID(instance_id)
    except ValueError:
        return None
    row = session.get(DiscoveryConnectionInstanceModel, uid)
    if row is None:
        return None
    if title is not _UNSET:
        if title is None or not str(title).strip():
            raise ValueError("title cannot be empty")
        row.title = validate_discovery_slug(str(title), "title")
    if backend is not _UNSET:
        row.backend = normalize_registry_backend(backend)
    if connection_string is not _UNSET:
        row.connection_string = connection_string
    if namespace is not _UNSET:
        row.namespace = validate_discovery_namespace(namespace, "namespace")
    _validate_row_backend_connection(row.backend, row.connection_string)
    row.updated_at = datetime.now(UTC)
    session.commit()
    session.refresh(row)
    return DiscoveryConnectionInstance(
        id=str(row.id),
        title=row.title,
        namespace=getattr(row, "namespace", None),
        backend=row.backend,
        connection_string=row.connection_string,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


def apply_connection_instance_updates(
    session: Session,
    instance_id: str,
    *,
    title: bool,
    title_value: str | None,
    backend: bool,
    backend_value: str | None,
    connection_string: bool,
    connection_string_value: str | None,
    namespace: bool = False,
    namespace_value: str | None = None,
) -> DiscoveryConnectionInstance | None:
    """Apply PATCH semantics: only include fields marked ``True``."""
    return update_connection_instance(
        session,
        instance_id,
        title=(title_value if title else _UNSET),
        backend=(backend_value if backend else _UNSET),
        connection_string=(connection_string_value if connection_string else _UNSET),
        namespace=(namespace_value if namespace else _UNSET),
    )


def delete_connection_instance(session: Session, instance_id: str) -> bool:
    from pystator.db.models.discovery_connection_instance import (
        DiscoveryConnectionInstanceModel,
    )

    _repair_sqlite_discovery_connection_rows(session)
    if instance_id == DEFAULT_DISCOVERY_INSTANCE_ID:
        raise ValueError("Cannot delete the default discovery connection instance")
    try:
        uid = UUID(instance_id)
    except ValueError:
        return False
    row = session.get(DiscoveryConnectionInstanceModel, uid)
    if row is None:
        return False
    session.delete(row)
    session.commit()
    return True


def connection_instance_to_dict(c: DiscoveryConnectionInstance) -> dict[str, Any]:
    return {
        "id": c.id,
        "title": c.title,
        "namespace": c.namespace,
        "backend": c.backend,
        "connection_string_masked": _mask_url(c.connection_string),
        "created_at": c.created_at,
        "updated_at": c.updated_at,
    }


def _mask_url(url: str) -> str:
    if not url or "@" not in url:
        return url
    head, tail = url.rsplit("@", 1)
    if "://" not in head:
        return url
    scheme, rest = head.split("://", 1)
    if ":" in rest:
        user, _hostpart = rest.split(":", 1)
        return f"{scheme}://{user}:***@{tail}"
    return f"{scheme}://***@{tail}"
