"""Per-instance InferenceEngine cache (keyed by discovery connection instance id)."""

from __future__ import annotations

import logging
from threading import Lock
from typing import TYPE_CHECKING
from uuid import UUID

if TYPE_CHECKING:
    from pystator.discovery.service import InferenceEngine

logger = logging.getLogger(__name__)

_lock = Lock()
_engine_cache: dict[str, InferenceEngine] = {}


def get_inference_engine(instance_id: str) -> InferenceEngine:
    """Return the inference engine for a registered discovery connection instance."""

    key = instance_id.strip()
    with _lock:
        cached = _engine_cache.get(key)
        if cached is not None:
            return cached

    eng = _resolve_engine(key)
    with _lock:
        _engine_cache[key] = eng
    return eng


def _resolve_engine(instance_id: str) -> InferenceEngine:
    from pystator.discovery.constants import DEFAULT_DISCOVERY_INSTANCE_ID
    from pystator.discovery.service import InferenceEngine

    if instance_id == DEFAULT_DISCOVERY_INSTANCE_ID:
        return InferenceEngine.from_app_config(quiet=True)

    try:
        uid = UUID(instance_id)
    except ValueError:
        return InferenceEngine.from_app_config(quiet=True)

    try:
        from pystator.db.base import get_session
        from pystator.db.config import get_db_url
        from pystator.db.models.discovery_connection_instance import (
            DiscoveryConnectionInstanceModel,
        )

        db_url = get_db_url()
        if not db_url:
            logger.warning("No app database URL; using default discovery engine")
            return InferenceEngine.from_app_config(quiet=True)

        session = get_session(db_url)
        try:
            row = session.get(DiscoveryConnectionInstanceModel, uid)
        finally:
            session.close()
    except Exception as exc:
        logger.warning("Could not load discovery instance %s: %s", instance_id, exc)
        return InferenceEngine.from_app_config(quiet=True)

    if row is None:
        if instance_id == DEFAULT_DISCOVERY_INSTANCE_ID:
            return InferenceEngine.from_app_config(quiet=True)
        raise ValueError(f"Unknown discovery connection instance: {instance_id}")

    return InferenceEngine.for_connection(row.backend, row.connection_string or None)


def clear_engine_cache() -> None:
    """Clear cached engines (for tests)."""
    with _lock:
        _engine_cache.clear()


def clear_engine_cache_for_instance(instance_id: str) -> None:
    """Drop one cached engine (e.g. after registry connection string changes)."""
    key = instance_id.strip()
    with _lock:
        _engine_cache.pop(key, None)
