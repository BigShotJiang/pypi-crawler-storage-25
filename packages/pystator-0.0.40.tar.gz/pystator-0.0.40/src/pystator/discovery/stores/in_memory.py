"""In-memory discovery store implementation."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import replace
from datetime import UTC, datetime
from typing import Any

from pystator.discovery.models import (
    BuiltByDraftAggregate,
    BuiltDiscoveryCandidate,
    DiscoveryDraft,
    DiscoveryDraftFilter,
    ObservationIdentity,
    ObservedStateEvent,
    ShadowDiff,
)


def _to_utc(dt: datetime) -> datetime:
    """Return *dt* as a UTC-aware datetime.

    Naive inputs (``tzinfo is None``) are interpreted as already-UTC
    and re-stamped. Aware inputs are returned unchanged. Mirrors the
    SQL store's ``_to_utc`` helper so filter comparisons are tz-safe
    even if a caller feeds us a mixed aware/naive input set.
    """
    return dt if dt.tzinfo is not None else dt.replace(tzinfo=UTC)


class InMemoryDiscoveryStore:
    """Single in-memory store implementing all discovery protocols."""

    def __init__(self) -> None:
        self._observations: dict[str, list[ObservedStateEvent]] = defaultdict(list)
        self._dedupe: set[tuple[str, str, str, str, str | None, str]] = set()
        self._built_candidates: dict[str, list[BuiltDiscoveryCandidate]] = defaultdict(
            list
        )
        self._shadow: dict[str, list[ShadowDiff]] = defaultdict(list)
        self._drafts: dict[str, DiscoveryDraft] = {}

    def add_observation(self, event: ObservedStateEvent) -> bool:
        # Normalize to UTC-aware on write so downstream filter
        # comparisons never have to branch on tz-awareness.
        if event.observed_at.tzinfo is None:
            event = replace(event, observed_at=event.observed_at.replace(tzinfo=UTC))
        key = (
            event.machine_name,
            event.entity_id,
            event.state,
            event.observed_at.isoformat(),
            event.source_event_id,
            event.source,
        )
        if key in self._dedupe:
            return False
        self._dedupe.add(key)
        self._observations[event.machine_name].append(event)
        return True

    def list_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> list[ObservedStateEvent]:
        items = self._observations.get(machine_name, [])
        if entity_id is None:
            return list(items)
        return [ev for ev in items if ev.entity_id == entity_id]

    def list_observations_page(
        self,
        machine_name: str,
        *,
        limit: int = 50,
        offset: int = 0,
        entity_id: str | None = None,
    ) -> tuple[list[ObservedStateEvent], int]:
        items = self.list_observations(machine_name, entity_id)
        total = len(items)
        lim = max(1, min(int(limit), 500))
        off = max(0, int(offset))
        sorted_items = sorted(
            items,
            key=lambda ev: (ev.observed_at, ev.ingest_seq, ev.ingested_at),
            reverse=True,
        )
        page = sorted_items[off : off + lim]
        return page, total

    def list_entity_ids(self, machine_name: str) -> list[str]:
        items = self._observations.get(machine_name, [])
        return sorted({ev.entity_id for ev in items if ev.entity_id})

    def delete_observations_for_entity(self, machine_name: str, entity_id: str) -> int:
        items = self._observations.get(machine_name, [])
        if not items:
            return 0
        kept = [ev for ev in items if ev.entity_id != entity_id]
        deleted = len(items) - len(kept)
        if deleted <= 0:
            return 0
        self._observations[machine_name] = kept
        self._dedupe = {
            key
            for key in self._dedupe
            if not (key[0] == machine_name and key[1] == entity_id)
        }
        return deleted

    def _dedupe_key(
        self, event: ObservedStateEvent
    ) -> tuple[str, str, str, str, str | None, str]:
        return (
            event.machine_name,
            event.entity_id,
            event.state,
            event.observed_at.isoformat(),
            event.source_event_id,
            event.source,
        )

    def delete_observation(
        self, machine_name: str, identity: ObservationIdentity
    ) -> bool:
        items = self._observations.get(machine_name, [])
        if not items:
            return False
        for idx, ev in enumerate(items):
            if ev.entity_id != identity.entity_id or ev.state != identity.state:
                continue
            if ev.source != identity.source:
                continue
            if (ev.source_event_id or None) != (identity.source_event_id or None):
                continue
            oa, ob = ev.observed_at, identity.observed_at
            if oa.tzinfo is None and ob.tzinfo is not None:
                oa = oa.replace(tzinfo=UTC)
            if ob.tzinfo is None and oa.tzinfo is not None:
                ob = ob.replace(tzinfo=UTC)
            if oa != ob:
                continue
            removed = items.pop(idx)
            self._dedupe.discard(self._dedupe_key(removed))
            return True
        return False

    def resolve_observations(
        self,
        filter: DiscoveryDraftFilter,
        *,
        observation_source: object | None = None,
        limit: int = 50_000,
    ) -> tuple[list[ObservedStateEvent], bool]:
        """Resolve observations matching *filter* across all channels.

        Empty list semantics mirror the SQL store: an explicit empty
        tuple/list (distinct from ``None``) for ``channels``,
        ``entity_ids``, or ``sources`` matches zero events. Truncation
        is computed by filling one over the limit and slicing.
        """
        if observation_source is not None:
            raise ValueError(
                "Custom observation_source is not supported on the in-memory "
                "discovery store; use SQLite or PostgreSQL."
            )
        # Empty-collection short-circuits: explicit `()` means "match
        # zero" (the Pydantic API layer rejects this case with 422;
        # this guard is defense-in-depth for direct Python callers).
        if filter.channels is not None and not filter.channels:
            return [], False
        if filter.entity_ids is not None and not filter.entity_ids:
            return [], False
        if filter.sources is not None and not filter.sources:
            return [], False
        channels = set(filter.channels) if filter.channels is not None else None
        entity_ids = set(filter.entity_ids) if filter.entity_ids is not None else None
        sources = set(filter.sources) if filter.sources is not None else None
        meta_match = dict(filter.metadata_match) if filter.metadata_match else None
        normalized_limit = max(1, int(limit))
        out: list[ObservedStateEvent] = []
        overflow = False
        for channel_name, events in self._observations.items():
            if channels is not None and channel_name not in channels:
                continue
            for ev in events:
                if entity_ids is not None and ev.entity_id not in entity_ids:
                    continue
                if sources is not None and ev.source not in sources:
                    continue
                # Normalize both sides so naive/aware mixing (e.g. a
                # pre-hardening stored event against an aware filter)
                # does not raise TypeError.
                if filter.observed_after is not None and _to_utc(
                    ev.observed_at
                ) < _to_utc(filter.observed_after):
                    continue
                if filter.observed_before is not None and _to_utc(
                    ev.observed_at
                ) > _to_utc(filter.observed_before):
                    continue
                if meta_match is not None and not all(
                    ev.metadata.get(k) == v for k, v in meta_match.items()
                ):
                    continue
                # Fill one over the limit so we can detect "exactly
                # limit" vs "more than limit" matches accurately.
                if len(out) >= normalized_limit + 1:
                    overflow = True
                    break
                out.append(ev)
            if overflow:
                break
        out.sort(
            key=lambda e: (
                e.machine_name,
                e.entity_id,
                e.observed_at,
                e.ingest_seq,
                e.ingested_at,
            )
        )
        if len(out) > normalized_limit:
            return out[:normalized_limit], True
        return out, overflow

    def list_observations_for_draft_scope(
        self,
        filter: DiscoveryDraftFilter,
        *,
        observation_source: object | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[ObservedStateEvent], int]:
        if observation_source is not None:
            raise NotImplementedError(
                "Custom observation_source is not supported on the in-memory "
                "discovery store; use SQLite or PostgreSQL."
            )
        events, _ = self.resolve_observations(
            filter, observation_source=None, limit=500_000
        )
        events.sort(
            key=lambda e: (e.observed_at, e.ingest_seq, e.ingested_at),
            reverse=True,
        )
        total = len(events)
        lim = max(1, min(int(limit), 500))
        off = max(0, int(offset))
        return events[off : off + lim], total

    def list_all_channels(self) -> list[str]:
        """Return distinct ``machine_name`` values across all observations."""
        return sorted(self._observations.keys())

    def list_all_sources(self) -> list[str]:
        """Return distinct ``source`` values across all observations."""
        sources: set[str] = set()
        for events in self._observations.values():
            sources.update(ev.source for ev in events if ev.source)
        return sorted(sources)

    def save_built_candidate(
        self, candidate: BuiltDiscoveryCandidate
    ) -> BuiltDiscoveryCandidate:
        existing = self._built_candidates[candidate.machine_name]
        for idx, item in enumerate(existing):
            if item.version == candidate.version:
                saved = replace(candidate, candidate_sequence=item.candidate_sequence)
                existing[idx] = saved
                return saved
        next_seq = max((c.candidate_sequence for c in existing), default=0) + 1
        saved = replace(candidate, candidate_sequence=next_seq)
        existing.append(saved)
        existing.sort(key=lambda c: c.created_at)
        return saved

    def get_built_candidate(
        self, machine_name: str, version: str
    ) -> BuiltDiscoveryCandidate | None:
        for c in self._built_candidates.get(machine_name, []):
            if c.version == version:
                return c
        return None

    def get_latest_built_candidate(
        self, machine_name: str
    ) -> BuiltDiscoveryCandidate | None:
        items = self._built_candidates.get(machine_name, [])
        return items[-1] if items else None

    def list_built_candidates(self, machine_name: str) -> list[BuiltDiscoveryCandidate]:
        return list(self._built_candidates.get(machine_name, []))

    def delete_built_candidate(self, machine_name: str, version: str) -> bool:
        items = self._built_candidates.get(machine_name, [])
        for idx, c in enumerate(items):
            if c.version == version:
                items.pop(idx)
                return True
        return False

    def count_built_candidates_by_draft(
        self, draft_ids: list[str]
    ) -> dict[str, BuiltByDraftAggregate]:
        """Per-draft built-candidate aggregates over the in-memory store."""
        if not draft_ids:
            return {}
        wanted = set(draft_ids)
        # Walk every built candidate across every channel; in-memory
        # store is small enough that O(n) is fine.
        per_draft: dict[str, list[BuiltDiscoveryCandidate]] = {}
        for cands in self._built_candidates.values():
            for c in cands:
                d_id = c.metadata.get("draft_id")
                if not isinstance(d_id, str) or d_id not in wanted:
                    continue
                per_draft.setdefault(d_id, []).append(c)
        out: dict[str, BuiltByDraftAggregate] = {}
        for d_id, cands in per_draft.items():
            cands.sort(key=lambda c: c.created_at, reverse=True)
            latest = cands[0]
            out[d_id] = BuiltByDraftAggregate(
                draft_id=d_id,
                count=len(cands),
                latest_version=latest.version,
                latest_created_at=latest.created_at,
            )
        return out

    def record_shadow_diff(self, diff: ShadowDiff) -> None:
        self._shadow[diff.machine_name].append(diff)

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        items = self._shadow.get(machine_name, [])
        if limit <= 0:
            return []
        return list(items[-limit:])

    def as_dict(self) -> dict[str, Any]:
        return {
            "observations": {k: len(v) for k, v in self._observations.items()},
            "built_candidates": {k: len(v) for k, v in self._built_candidates.items()},
            "shadow": {k: len(v) for k, v in self._shadow.items()},
        }

    def list_fleet_summaries(self) -> list[dict[str, Any]]:
        """Same semantics as SQL store: shadow window = latest 200 diffs per machine."""
        names: set[str] = set()
        names |= set(self._observations.keys())
        names |= set(self._built_candidates.keys())
        names |= set(self._shadow.keys())
        names |= {d.machine_name for d in self._drafts.values()}
        out: list[dict[str, Any]] = []
        for machine_name in sorted(names):
            obs = self._observations.get(machine_name, [])
            observation_count = len(obs)
            last_observation_at: datetime | None = None
            if obs:
                last_observation_at = max(e.observed_at for e in obs)

            cands = self._built_candidates.get(machine_name, [])
            candidate_count = len(cands)
            latest_candidate_version: str | None = None
            latest_candidate_created_at: datetime | None = None
            if cands:
                best = max(cands, key=lambda c: (c.created_at, c.version))
                latest_candidate_version = best.version
                latest_candidate_created_at = best.created_at

            shadow_all = self._shadow.get(machine_name, [])
            recent = sorted(shadow_all, key=lambda d: d.recorded_at, reverse=True)[:200]
            shadow_diff_count_recent = len(recent)
            differs_n = sum(1 for d in recent if d.differs)
            drift_rate_recent = (
                differs_n / shadow_diff_count_recent
                if shadow_diff_count_recent
                else 0.0
            )

            out.append(
                {
                    "machine_name": machine_name,
                    "last_observation_at": last_observation_at,
                    "observation_count": observation_count,
                    "candidate_count": candidate_count,
                    "latest_candidate_version": latest_candidate_version,
                    "latest_candidate_created_at": latest_candidate_created_at,
                    "shadow_diff_count_recent": shadow_diff_count_recent,
                    "drift_rate_recent": drift_rate_recent,
                }
            )
        return out

    def save_draft(self, draft: DiscoveryDraft) -> DiscoveryDraft:
        self._drafts[draft.id] = draft
        return draft

    def get_draft(self, draft_id: str) -> DiscoveryDraft | None:
        return self._drafts.get(draft_id)

    def list_all_drafts(self) -> list[DiscoveryDraft]:
        """Return every draft across all channels, newest updated first."""
        items = list(self._drafts.values())
        items.sort(key=lambda d: d.updated_at, reverse=True)
        return items

    def delete_draft(self, draft_id: str) -> bool:
        if draft_id in self._drafts:
            del self._drafts[draft_id]
            return True
        return False
