"""Private SQL-backed discovery store shared by SQLite and PostgreSQL."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import bindparam, create_engine, event, text
from sqlalchemy.engine import Engine

from pystator.discovery.constants import DEFAULT_DISCOVERY_INSTANCE_ID
from pystator.discovery.models import (
    BuiltByDraftAggregate,
    BuiltDiscoveryCandidate,
    DiscoveryDraft,
    DiscoveryDraftFilter,
    ObservationIdentity,
    ObservedStateEvent,
    ShadowDiff,
)
from pystator.discovery.observation_source import (
    ObservationFieldMapping,
    ObservationSourceConfig,
)
from pystator.discovery.sql_contract import (
    DISCOVERY_OBSERVATIONS_TABLE,
    OBSERVATION_NATIVE_COLUMNS,
    OBSERVATION_ORDER_ASC,
    OBSERVATION_ORDER_DESC,
)
from pystator.discovery.sql_schema import apply_discovery_schema


def _dt_parse(value: Any) -> datetime:
    """Parse a datetime value, normalizing naive results to UTC.

    Accepts ``datetime`` instances and ISO-8601 strings (with the ``Z``
    suffix coerced to ``+00:00``). Naive datetimes from either source
    are assumed to be UTC and stamped accordingly so downstream
    comparisons stay aware-vs-aware.
    """
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=UTC)
    if isinstance(value, str):
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=UTC)
    raise ValueError(f"Cannot parse datetime value: {value!r}")


def _to_utc(value: datetime) -> datetime:
    """Return *value* normalized to UTC (naive → UTC, aware → converted)."""
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


def _filter_to_json(filter: DiscoveryDraftFilter | None) -> str:
    """Serialize a draft filter to JSON for storage."""
    if filter is None or filter.is_empty():
        return "{}"
    payload: dict[str, Any] = {}
    if filter.channels is not None:
        payload["channels"] = list(filter.channels)
    if filter.entity_ids is not None:
        payload["entity_ids"] = list(filter.entity_ids)
    if filter.sources is not None:
        payload["sources"] = list(filter.sources)
    if filter.observed_after is not None:
        payload["observed_after"] = filter.observed_after.isoformat()
    if filter.observed_before is not None:
        payload["observed_before"] = filter.observed_before.isoformat()
    if filter.metadata_match is not None:
        payload["metadata_match"] = dict(filter.metadata_match)
    return json.dumps(payload)


def _observation_source_to_json(src: ObservationSourceConfig | None) -> str:
    if src is None:
        return "{}"
    return json.dumps(src.to_json_dict())


def _filter_from_json(raw: Any) -> DiscoveryDraftFilter | None:
    """Parse filter JSON back into a ``DiscoveryDraftFilter`` or ``None``."""
    if not raw:
        return None
    try:
        data = json.loads(raw) if isinstance(raw, str) else raw
    except (TypeError, ValueError):
        return None
    if not isinstance(data, dict) or not data:
        return None
    channels = tuple(str(x) for x in data["channels"]) if "channels" in data else None
    entity_ids = (
        tuple(str(x) for x in data["entity_ids"]) if "entity_ids" in data else None
    )
    sources = tuple(str(x) for x in data["sources"]) if "sources" in data else None
    observed_after = (
        _dt_parse(data["observed_after"]) if data.get("observed_after") else None
    )
    observed_before = (
        _dt_parse(data["observed_before"]) if data.get("observed_before") else None
    )
    metadata_match: tuple[tuple[str, Any], ...] | None = None
    mm = data.get("metadata_match")
    if isinstance(mm, dict) and mm:
        metadata_match = tuple((str(k), v) for k, v in mm.items())
    return DiscoveryDraftFilter(
        channels=channels,
        entity_ids=entity_ids,
        sources=sources,
        observed_after=observed_after,
        observed_before=observed_before,
        metadata_match=metadata_match,
    )


def _build_filter_clause(
    filter: DiscoveryDraftFilter,
) -> tuple[str, dict[str, Any], list[str]]:
    """Assemble SQL WHERE fragments for a ``DiscoveryDraftFilter``.

    Returns:
        Tuple of ``(clause, params, expanding_param_names)``. The clause
        is appended after ``WHERE 1=1`` so it always starts with ``AND``
        or is empty. ``expanding_param_names`` must be bound with
        ``bindparam(name, expanding=True)`` at query assembly time.

    ``metadata_match`` is intentionally NOT applied in SQL — it is
    filtered in Python after fetch to avoid dialect-specific JSON
    operators. Callers are responsible for the Python pass.

    Empty list semantics: when a list dimension (``channels``,
    ``entity_ids``, ``sources``) is explicitly an empty tuple/list
    (distinct from ``None``), the clause becomes ``AND 1=0`` so the
    query matches zero rows. The Pydantic API layer rejects this
    case with 422; this is a defense-in-depth guard for direct
    Python callers (tests, scripts).
    """
    parts: list[str] = []
    params: dict[str, Any] = {}
    expanders: list[str] = []
    if filter.channels is not None:
        if not filter.channels:
            parts.append("AND 1=0")
        else:
            parts.append("AND machine_name IN :_f_channels")
            params["_f_channels"] = list(filter.channels)
            expanders.append("_f_channels")
    if filter.entity_ids is not None:
        if not filter.entity_ids:
            parts.append("AND 1=0")
        else:
            parts.append("AND entity_id IN :_f_entity_ids")
            params["_f_entity_ids"] = list(filter.entity_ids)
            expanders.append("_f_entity_ids")
    if filter.sources is not None:
        if not filter.sources:
            parts.append("AND 1=0")
        else:
            parts.append("AND source IN :_f_sources")
            params["_f_sources"] = list(filter.sources)
            expanders.append("_f_sources")
    if filter.observed_after is not None:
        parts.append("AND observed_at >= :_f_observed_after")
        params["_f_observed_after"] = _to_utc(filter.observed_after).isoformat()
    if filter.observed_before is not None:
        parts.append("AND observed_at <= :_f_observed_before")
        params["_f_observed_before"] = _to_utc(filter.observed_before).isoformat()
    return " ".join(parts), params, expanders


def _build_filter_clause_for_mapping(
    filter: DiscoveryDraftFilter,
    fm: ObservationFieldMapping,
) -> tuple[str, dict[str, Any], list[str]]:
    """Like :func:`_build_filter_clause` but uses *fm* for physical column names."""
    col_mn = fm.machine_name
    col_eid = fm.entity_id
    col_src = fm.source
    col_obs = fm.observed_at
    parts: list[str] = []
    params: dict[str, Any] = {}
    expanders: list[str] = []
    if filter.channels is not None:
        if not filter.channels:
            parts.append("AND 1=0")
        else:
            parts.append(f"AND t.{col_mn} IN :_f_channels")
            params["_f_channels"] = list(filter.channels)
            expanders.append("_f_channels")
    if filter.entity_ids is not None:
        if not filter.entity_ids:
            parts.append("AND 1=0")
        else:
            parts.append(f"AND t.{col_eid} IN :_f_entity_ids")
            params["_f_entity_ids"] = list(filter.entity_ids)
            expanders.append("_f_entity_ids")
    if filter.sources is not None:
        if not filter.sources:
            parts.append("AND 1=0")
        else:
            parts.append(f"AND t.{col_src} IN :_f_sources")
            params["_f_sources"] = list(filter.sources)
            expanders.append("_f_sources")
    if filter.observed_after is not None:
        parts.append(f"AND t.{col_obs} >= :_f_observed_after")
        params["_f_observed_after"] = _to_utc(filter.observed_after).isoformat()
    if filter.observed_before is not None:
        parts.append(f"AND t.{col_obs} <= :_f_observed_before")
        params["_f_observed_before"] = _to_utc(filter.observed_before).isoformat()
    return " ".join(parts), params, expanders


def _mapped_select_list_sql(fm: ObservationFieldMapping) -> str:
    """SELECT list for alias ``t`` (mapped observation table)."""
    meta_col = fm.metadata or "metadata_json"
    se_expr = (
        f"t.{fm.source_event_id} AS source_event_id"
        if fm.source_event_id
        else "CAST(NULL AS TEXT) AS source_event_id"
    )
    return (
        f"t.{fm.machine_name} AS machine_name, "
        f"t.{fm.entity_id} AS entity_id, t.{fm.state} AS state, "
        f"t.{fm.observed_at} AS observed_at, t.{fm.source} AS source, "
        f"{se_expr}, "
        f"COALESCE(t.{meta_col}, '{{}}') AS metadata_json, "
        f"t.{fm.observed_at} AS ingested_at, "
        f"CAST(0 AS INTEGER) AS ingest_seq"
    )


def _rows_to_observed_state_events(rows: list[Any]) -> list[ObservedStateEvent]:
    return [
        ObservedStateEvent(
            entity_id=row["entity_id"],
            machine_name=row["machine_name"],
            state=row["state"],
            observed_at=_dt_parse(row["observed_at"]),
            source=row["source"],
            source_event_id=row["source_event_id"],
            metadata=json.loads(row["metadata_json"] or "{}"),
            ingested_at=_dt_parse(row["ingested_at"]),
            ingest_seq=int(row["ingest_seq"] or 0),
        )
        for row in rows
    ]


def _apply_metadata_match(
    events: list[ObservedStateEvent],
    metadata_match: tuple[tuple[str, Any], ...],
) -> list[ObservedStateEvent]:
    """Python-side filter: keep events whose ``metadata`` matches all pairs."""
    expected = dict(metadata_match)
    return [
        ev for ev in events if all(ev.metadata.get(k) == v for k, v in expected.items())
    ]


def _compute_post_filter_truncation(
    events: list[ObservedStateEvent], sql_truncated: bool, limit: int
) -> tuple[list[ObservedStateEvent], bool]:
    """Truncate *events* to *limit* and report whether truncation occurred.

    Truncation semantics, in priority order:

    1. If the post-filter event list exceeds *limit*, slice to *limit*
       and return ``True`` — this is the precise case.
    2. If the post-filter event list is empty, return ``False`` — there
       is nothing being hidden from the caller. We only warn about
       truncation when there are visible results to "show more" of.
    3. Otherwise return ``sql_truncated`` — best-effort: SQL hit its
       ceiling, so more matching events may exist beyond the window.

    Args:
        events: Events after any Python post-filtering.
        sql_truncated: Whether the underlying SQL query hit its row
            ceiling.
        limit: Caller-requested upper bound on returned events.

    Returns:
        Tuple of ``(events_truncated_to_limit, limit_reached_flag)``.
    """
    if len(events) > limit:
        return events[:limit], True
    if not events:
        return events, False
    return events, sql_truncated


def _draft_from_row(row: Any) -> DiscoveryDraft:
    sel = json.loads(row["selected_entity_ids_json"] or "[]")
    if not isinstance(sel, list):
        sel = []
    manual = json.loads(row["manual_edge_selection_json"] or "[]")
    pairs: list[tuple[str, str]] = []
    if isinstance(manual, list):
        for item in manual:
            if isinstance(item, dict):
                s = item.get("source_state") or item.get("source")
                d = item.get("destination_state") or item.get("dest")
                if isinstance(s, str) and isinstance(d, str):
                    pairs.append((s, d))
            elif isinstance(item, list | tuple) and len(item) == 2:
                pairs.append((str(item[0]), str(item[1])))
    try:
        filter_raw = row["filter_json"]
    except KeyError:
        # Defensive: legacy rows queried via a SELECT that pre-dates the
        # ``filter_json`` column. SQLAlchemy ``RowMapping`` raises only
        # ``KeyError`` for missing keys.
        filter_raw = None
    try:
        inst_raw = row["instance_id"]
    except KeyError:
        inst_raw = None
    try:
        obs_src_raw = row["observation_source_json"]
    except KeyError:
        obs_src_raw = None
    obs_src: ObservationSourceConfig | None = None
    if obs_src_raw:
        try:
            data = (
                json.loads(obs_src_raw) if isinstance(obs_src_raw, str) else obs_src_raw
            )
            if isinstance(data, dict) and data:
                obs_src = ObservationSourceConfig.from_json_dict(data)
        except (TypeError, ValueError):
            obs_src = None
    return DiscoveryDraft(
        id=row["id"],
        instance_id=str(inst_raw or DEFAULT_DISCOVERY_INSTANCE_ID),
        machine_name=row["machine_name"],
        title=row["title"] or None,
        selected_entity_ids=tuple(str(x) for x in sel),
        mode=str(row["mode"] or "inference"),
        min_edge_count=int(row["min_edge_count"] or 2),
        min_confidence=float(row["min_confidence"] or 0.5),
        manual_edge_selection=tuple(pairs),
        created_at=_dt_parse(row["created_at"]),
        updated_at=_dt_parse(row["updated_at"]),
        last_built_version=row["last_built_version"] or None,
        filter=_filter_from_json(filter_raw),
        observation_source=obs_src,
    )


def _built_from_row(row: Any) -> BuiltDiscoveryCandidate:
    seq = row.get("candidate_sequence")
    if seq is None:
        seq = 0
    return BuiltDiscoveryCandidate(
        machine_name=row["machine_name"],
        version=row["version"],
        status=row["status"],
        config=json.loads(row["config_json"]),
        metadata=json.loads(row["metadata_json"] or "{}"),
        created_at=_dt_parse(row["created_at"]),
        candidate_sequence=int(seq),
    )


class _SQLDiscoveryStoreBase:
    def __init__(self, connection_string: str) -> None:
        self.connection_string = connection_string
        self._engine: Engine | None = None

    def connect(self) -> None:
        self._engine = create_engine(self.connection_string, future=True)
        if self._engine.dialect.name == "postgresql":

            def _set_search_path(
                dbapi_conn: object,
                _connection_record: object,
                _connection_proxy: object,
            ) -> None:
                # Use pool "checkout", not engine "connect": new connections fire
                # "connect" once, but pooled checkouts reuse connections and the pool
                # may reset session state so search_path must be set every checkout.
                cur = dbapi_conn.cursor()
                cur.execute("SET search_path TO pystator, public")
                cur.close()

            event.listen(self._engine.pool, "checkout", _set_search_path)
        self._initialize_schema()

    def disconnect(self) -> None:
        if self._engine is not None:
            self._engine.dispose()
            self._engine = None

    def _require_engine(self) -> Engine:
        if self._engine is None:
            raise RuntimeError("Not connected. Call connect() first.")
        return self._engine

    def _initialize_schema(self) -> None:
        apply_discovery_schema(self._require_engine())

    def list_fleet_summaries(self) -> list[dict[str, Any]]:
        """One row per machine with discovery aggregates.

        Shadow metrics use the **latest 200** shadow diffs per machine
        (``recorded_at`` DESC): ``shadow_diff_count_recent`` is the count in
        that window; ``drift_rate_recent`` is the fraction where ``differs`` is true.
        """
        engine = self._require_engine()
        sql = """
            WITH machine_names AS (
              SELECT machine_name FROM discovery_observations
              UNION SELECT machine_name FROM discovery_built_candidates
              UNION SELECT machine_name FROM discovery_shadow_diffs
              UNION SELECT machine_name FROM discovery_drafts
            ),
            obs_agg AS (
              SELECT machine_name,
                     COUNT(*) AS observation_count,
                     MAX(observed_at) AS last_observation_at
              FROM discovery_observations
              GROUP BY machine_name
            ),
            cand_agg AS (
              SELECT machine_name,
                     COUNT(*) AS candidate_count,
                     MAX(created_at) AS latest_candidate_created_at
              FROM discovery_built_candidates
              GROUP BY machine_name
            ),
            latest_cand AS (
              SELECT machine_name, version AS latest_candidate_version
              FROM (
                SELECT machine_name, version, created_at,
                       ROW_NUMBER() OVER (
                         PARTITION BY machine_name
                         ORDER BY created_at DESC, version DESC
                       ) AS rk
                FROM discovery_built_candidates
              ) z
              WHERE rk = 1
            ),
            shadow_recent AS (
              SELECT machine_name,
                     SUM(CASE WHEN differs = 1 THEN 1 ELSE 0 END) AS shadow_differs,
                     COUNT(*) AS shadow_total
              FROM (
                SELECT machine_name, differs,
                       ROW_NUMBER() OVER (
                         PARTITION BY machine_name
                         ORDER BY recorded_at DESC
                       ) AS rn
                FROM discovery_shadow_diffs
              ) t
              WHERE rn <= 200
              GROUP BY machine_name
            )
            SELECT
              mn.machine_name,
              COALESCE(oa.observation_count, 0) AS observation_count,
              oa.last_observation_at,
              COALESCE(ca.candidate_count, 0) AS candidate_count,
              lc.latest_candidate_version,
              ca.latest_candidate_created_at,
              COALESCE(sr.shadow_total, 0) AS shadow_diff_count_recent,
              CASE WHEN COALESCE(sr.shadow_total, 0) > 0
                   THEN CAST(sr.shadow_differs AS REAL) / sr.shadow_total
                   ELSE 0.0
              END AS drift_rate_recent
            FROM machine_names mn
            LEFT JOIN obs_agg oa ON mn.machine_name = oa.machine_name
            LEFT JOIN cand_agg ca ON mn.machine_name = ca.machine_name
            LEFT JOIN latest_cand lc ON mn.machine_name = lc.machine_name
            LEFT JOIN shadow_recent sr ON mn.machine_name = sr.machine_name
            """
        with engine.begin() as conn:
            rows = conn.execute(text(sql)).mappings().all()
        out: list[dict[str, Any]] = []
        for row in rows:
            loa = row["last_observation_at"]
            lcca = row["latest_candidate_created_at"]
            out.append(
                {
                    "machine_name": row["machine_name"],
                    "last_observation_at": _dt_parse(loa) if loa else None,
                    "observation_count": int(row["observation_count"] or 0),
                    "candidate_count": int(row["candidate_count"] or 0),
                    "latest_candidate_version": row["latest_candidate_version"],
                    "latest_candidate_created_at": _dt_parse(lcca) if lcca else None,
                    "shadow_diff_count_recent": int(
                        row["shadow_diff_count_recent"] or 0
                    ),
                    "drift_rate_recent": float(row["drift_rate_recent"] or 0.0),
                }
            )
        return out

    def add_observation(self, event: ObservedStateEvent) -> bool:
        engine = self._require_engine()
        machine_name = event.machine_name
        with engine.begin() as conn:
            result = conn.execute(
                text(
                    f"""
                    INSERT INTO {DISCOVERY_OBSERVATIONS_TABLE} (
                      machine_name, entity_id, state, observed_at, source, source_event_id,
                      metadata_json, ingested_at, ingest_seq
                    ) VALUES (
                      :machine_name, :entity_id, :state, :observed_at, :source, :source_event_id,
                      :metadata_json, :ingested_at, :ingest_seq
                    )
                    ON CONFLICT(machine_name, entity_id, state, observed_at, source, source_event_id)
                    DO NOTHING
                    """
                ),
                {
                    "machine_name": machine_name,
                    "entity_id": event.entity_id,
                    "state": event.state,
                    "observed_at": event.observed_at.isoformat(),
                    "source": event.source,
                    "source_event_id": event.source_event_id,
                    "metadata_json": json.dumps(event.metadata),
                    "ingested_at": event.ingested_at.isoformat(),
                    "ingest_seq": event.ingest_seq,
                },
            )
        return bool(result.rowcount and result.rowcount > 0)

    def list_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> list[ObservedStateEvent]:
        engine = self._require_engine()
        sql = f"""
            SELECT {OBSERVATION_NATIVE_COLUMNS}
            FROM {DISCOVERY_OBSERVATIONS_TABLE}
            WHERE machine_name = :machine_name
        """
        params: dict[str, Any] = {"machine_name": machine_name}
        if entity_id:
            sql += " AND entity_id = :entity_id"
            params["entity_id"] = entity_id
        sql += f" ORDER BY {OBSERVATION_ORDER_ASC}"
        with engine.begin() as conn:
            rows = conn.execute(text(sql), params).mappings().all()
        return [
            ObservedStateEvent(
                entity_id=row["entity_id"],
                machine_name=machine_name,
                state=row["state"],
                observed_at=_dt_parse(row["observed_at"]),
                source=row["source"],
                source_event_id=row["source_event_id"],
                metadata=json.loads(row["metadata_json"] or "{}"),
                ingested_at=_dt_parse(row["ingested_at"]),
                ingest_seq=int(row["ingest_seq"] or 0),
            )
            for row in rows
        ]

    def count_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> int:
        engine = self._require_engine()
        sql = (
            f"SELECT COUNT(*) AS n FROM {DISCOVERY_OBSERVATIONS_TABLE} "
            "WHERE machine_name = :machine_name"
        )
        params: dict[str, Any] = {"machine_name": machine_name}
        if entity_id:
            sql += " AND entity_id = :entity_id"
            params["entity_id"] = entity_id
        with engine.begin() as conn:
            row = conn.execute(text(sql), params).mappings().first()
        return int(row["n"] or 0) if row else 0

    def list_observations_page(
        self,
        machine_name: str,
        *,
        limit: int = 50,
        offset: int = 0,
        entity_id: str | None = None,
    ) -> tuple[list[ObservedStateEvent], int]:
        """Return a page of observations (newest ``observed_at`` first) and total count."""
        engine = self._require_engine()
        total = self.count_observations(machine_name, entity_id)
        lim = max(1, min(int(limit), 500))
        off = max(0, int(offset))
        sql = f"""
            SELECT {OBSERVATION_NATIVE_COLUMNS}
            FROM {DISCOVERY_OBSERVATIONS_TABLE}
            WHERE machine_name = :machine_name
        """
        params: dict[str, Any] = {"machine_name": machine_name, "lim": lim, "off": off}
        if entity_id:
            sql += " AND entity_id = :entity_id"
            params["entity_id"] = entity_id
        sql += f"""
            ORDER BY {OBSERVATION_ORDER_DESC}
            LIMIT :lim OFFSET :off
        """
        with engine.begin() as conn:
            rows = conn.execute(text(sql), params).mappings().all()
        items = [
            ObservedStateEvent(
                entity_id=row["entity_id"],
                machine_name=machine_name,
                state=row["state"],
                observed_at=_dt_parse(row["observed_at"]),
                source=row["source"],
                source_event_id=row["source_event_id"],
                metadata=json.loads(row["metadata_json"] or "{}"),
                ingested_at=_dt_parse(row["ingested_at"]),
                ingest_seq=int(row["ingest_seq"] or 0),
            )
            for row in rows
        ]
        return items, total

    def list_entity_ids(self, machine_name: str) -> list[str]:
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    f"""
                    SELECT DISTINCT entity_id
                    FROM {DISCOVERY_OBSERVATIONS_TABLE}
                    WHERE machine_name = :machine_name
                    ORDER BY entity_id
                    """
                ),
                {"machine_name": machine_name},
            ).all()
        return [str(row[0]) for row in rows if row and row[0]]

    def delete_observations_for_entity(self, machine_name: str, entity_id: str) -> int:
        engine = self._require_engine()
        with engine.begin() as conn:
            result = conn.execute(
                text(
                    f"""
                    DELETE FROM {DISCOVERY_OBSERVATIONS_TABLE}
                    WHERE machine_name = :machine_name AND entity_id = :entity_id
                    """
                ),
                {"machine_name": machine_name, "entity_id": entity_id},
            )
        return int(result.rowcount or 0)

    def delete_observation(
        self, machine_name: str, identity: ObservationIdentity
    ) -> bool:
        engine = self._require_engine()
        params = {
            "machine_name": machine_name,
            "entity_id": identity.entity_id,
            "state": identity.state,
            "observed_at": identity.observed_at.isoformat(),
            "source": identity.source,
            "source_event_id": identity.source_event_id,
        }
        with engine.begin() as conn:
            result = conn.execute(
                text(
                    f"""
                    DELETE FROM {DISCOVERY_OBSERVATIONS_TABLE}
                    WHERE machine_name = :machine_name
                      AND entity_id = :entity_id
                      AND state = :state
                      AND observed_at = :observed_at
                      AND source = :source
                      AND (
                        (:source_event_id IS NULL AND source_event_id IS NULL)
                        OR source_event_id = :source_event_id
                      )
                    """
                ),
                params,
            )
        return bool(result.rowcount and result.rowcount > 0)

    def resolve_observations(
        self,
        filter: DiscoveryDraftFilter,
        *,
        observation_source: ObservationSourceConfig | None = None,
        limit: int = 50_000,
    ) -> tuple[list[ObservedStateEvent], bool]:
        """Resolve observations matching *filter* across all channels.

        When ``filter.metadata_match`` is set, the Python post-filter
        runs *after* SQL fetches. To give that post-filter room to
        find ``limit`` matches even when many SQL rows are dropped,
        the SQL ceiling is raised to ``limit * 4 + 1``. This is a
        heuristic — pathological selectivity (e.g. 1 in 1000 rows
        match metadata_match) could still produce a misleading
        ``limit_reached=False`` for very large datasets. At current
        data volumes (<1M observations) this is acceptable; the
        upgrade path is dialect-specific JSON operators (deferred).

        When *observation_source* is set, reads from the configured
        table using *field_mapping*; ``ingested_at`` / ``ingest_seq``
        are synthesized from ``observed_at`` and ``0`` so external
        tables need not match PyStator's full native schema.
        """
        engine = self._require_engine()
        has_metadata_filter = bool(filter.metadata_match)
        normalized_limit = max(1, int(limit))
        sql_ceiling = (
            normalized_limit * 4 + 1 if has_metadata_filter else normalized_limit + 1
        )

        if observation_source is None:
            clause, params, expanders = _build_filter_clause(filter)
            sql = text(
                "SELECT machine_name, entity_id, state, observed_at, source, "
                "source_event_id, metadata_json, ingested_at, ingest_seq "
                "FROM discovery_observations "
                f"WHERE 1=1 {clause} "
                "ORDER BY machine_name, entity_id, observed_at, ingest_seq, ingested_at "
                "LIMIT :_sql_ceiling"
            )
        else:
            observation_source.validate_identifiers()
            fm = observation_source.field_mapping or ObservationFieldMapping()
            table_ref = observation_source.effective_table_name()
            clause, params, expanders = _build_filter_clause_for_mapping(filter, fm)
            proj = _mapped_select_list_sql(fm)
            sql = text(
                f"SELECT {proj} "
                f"FROM {table_ref} AS t "
                f"WHERE 1=1 {clause} "
                f"ORDER BY t.{fm.machine_name}, t.{fm.entity_id}, "
                f"t.{fm.observed_at} "
                "LIMIT :_sql_ceiling"
            )

        for name in expanders:
            sql = sql.bindparams(bindparam(name, expanding=True))
        params["_sql_ceiling"] = sql_ceiling
        with engine.begin() as conn:
            rows = conn.execute(sql, params).mappings().all()
        sql_truncated = len(rows) >= sql_ceiling
        events = _rows_to_observed_state_events(rows)
        if has_metadata_filter:
            events = _apply_metadata_match(events, filter.metadata_match)
        return _compute_post_filter_truncation(events, sql_truncated, normalized_limit)

    def list_observations_for_draft_scope(
        self,
        filter: DiscoveryDraftFilter,
        *,
        observation_source: ObservationSourceConfig | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[ObservedStateEvent], int]:
        """Paginated observations matching *filter* and optional *observation_source*.

        Ordering matches :meth:`list_observations_page` (newest ``observed_at`` first).
        When ``filter.metadata_match`` is set, uses :meth:`resolve_observations` with a
        large limit (accurate only when the matching set is below that cap).
        """
        lim = max(1, min(int(limit), 500))
        off = max(0, int(offset))

        if filter.metadata_match:
            events, _ = self.resolve_observations(
                filter,
                observation_source=observation_source,
                limit=500_000,
            )
            events.sort(
                key=lambda e: (e.observed_at, e.ingest_seq, e.ingested_at),
                reverse=True,
            )
            total = len(events)
            return events[off : off + lim], total

        engine = self._require_engine()
        if observation_source is None:
            clause, params, expanders = _build_filter_clause(filter)
            count_sql = text(
                f"SELECT COUNT(*) AS n FROM discovery_observations WHERE 1=1 {clause}"
            )
            data_sql = text(
                "SELECT machine_name, entity_id, state, observed_at, source, "
                "source_event_id, metadata_json, ingested_at, ingest_seq "
                f"FROM discovery_observations WHERE 1=1 {clause} "
                "ORDER BY observed_at DESC, ingest_seq DESC, ingested_at DESC "
                "LIMIT :_lim OFFSET :_off"
            )
        else:
            observation_source.validate_identifiers()
            fm = observation_source.field_mapping or ObservationFieldMapping()
            table_ref = observation_source.effective_table_name()
            clause, params, expanders = _build_filter_clause_for_mapping(filter, fm)
            proj = _mapped_select_list_sql(fm)
            count_sql = text(
                f"SELECT COUNT(*) AS n FROM {table_ref} AS t WHERE 1=1 {clause}"
            )
            data_sql = text(
                f"SELECT {proj} FROM {table_ref} AS t WHERE 1=1 {clause} "
                f"ORDER BY t.{fm.observed_at} DESC "
                "LIMIT :_lim OFFSET :_off"
            )

        qparams = dict(params)
        qparams["_lim"] = lim
        qparams["_off"] = off
        for name in expanders:
            count_sql = count_sql.bindparams(bindparam(name, expanding=True))
            data_sql = data_sql.bindparams(bindparam(name, expanding=True))
        with engine.begin() as conn:
            total_row = conn.execute(count_sql, qparams).mappings().first()
            total = int((total_row or {}).get("n") or 0)
            rows = conn.execute(data_sql, qparams).mappings().all()
        return _rows_to_observed_state_events(list(rows)), total

    def list_all_channels(self) -> list[str]:
        """Return distinct ``machine_name`` values across all observations."""
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    "SELECT DISTINCT machine_name FROM discovery_observations "
                    "ORDER BY machine_name"
                )
            ).all()
        return [str(row[0]) for row in rows if row and row[0]]

    def list_all_sources(self) -> list[str]:
        """Return distinct ``source`` values across all observations."""
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    "SELECT DISTINCT source FROM discovery_observations ORDER BY source"
                )
            ).all()
        return [str(row[0]) for row in rows if row and row[0]]

    def save_built_candidate(
        self, candidate: BuiltDiscoveryCandidate
    ) -> BuiltDiscoveryCandidate:
        engine = self._require_engine()
        mn = candidate.machine_name
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    INSERT INTO discovery_built_candidates (
                      machine_name, version, status, config_json, metadata_json, created_at,
                      candidate_sequence
                    ) VALUES (
                      :machine_name, :version, :status, :config_json, :metadata_json, :created_at,
                      (SELECT COALESCE(MAX(candidate_sequence), 0) + 1
                       FROM discovery_built_candidates WHERE machine_name = :machine_name_seq)
                    )
                    ON CONFLICT(machine_name, version)
                    DO UPDATE SET
                      status = excluded.status,
                      config_json = excluded.config_json,
                      metadata_json = excluded.metadata_json,
                      created_at = excluded.created_at
                    """
                ),
                {
                    "machine_name": mn,
                    "version": candidate.version,
                    "status": candidate.status,
                    "config_json": json.dumps(candidate.config),
                    "metadata_json": json.dumps(candidate.metadata),
                    "created_at": candidate.created_at.isoformat(),
                    "machine_name_seq": mn,
                },
            )
        out = self.get_built_candidate(mn, candidate.version)
        if out is None:
            # Internal invariant: the row we just upserted must be
            # readable back. A ``None`` here means the row was
            # rolled back, deleted, or the read raced past the
            # write — none of which should be silent.
            raise RuntimeError(
                f"built candidate vanished after save: {mn}/{candidate.version}"
            )
        return out

    def get_built_candidate(
        self, machine_name: str, version: str
    ) -> BuiltDiscoveryCandidate | None:
        engine = self._require_engine()
        with engine.begin() as conn:
            row = (
                conn.execute(
                    text(
                        """
                    SELECT machine_name, version, status, config_json, metadata_json, created_at, candidate_sequence
                    FROM discovery_built_candidates
                    WHERE machine_name = :machine_name AND version = :version
                    """
                    ),
                    {"machine_name": machine_name, "version": version},
                )
                .mappings()
                .first()
            )
        if row is None:
            return None
        return _built_from_row(row)

    def get_latest_built_candidate(
        self, machine_name: str
    ) -> BuiltDiscoveryCandidate | None:
        engine = self._require_engine()
        with engine.begin() as conn:
            row = (
                conn.execute(
                    text(
                        """
                    SELECT machine_name, version, status, config_json, metadata_json, created_at, candidate_sequence
                    FROM discovery_built_candidates
                    WHERE machine_name = :machine_name
                    ORDER BY created_at DESC
                    LIMIT 1
                    """
                    ),
                    {"machine_name": machine_name},
                )
                .mappings()
                .first()
            )
        if row is None:
            return None
        return _built_from_row(row)

    def list_built_candidates(self, machine_name: str) -> list[BuiltDiscoveryCandidate]:
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    """
                    SELECT machine_name, version, status, config_json, metadata_json, created_at, candidate_sequence
                    FROM discovery_built_candidates
                    WHERE machine_name = :machine_name
                    ORDER BY created_at DESC
                    """
                ),
                {"machine_name": machine_name},
            ).mappings()
            result = rows.all()
        return [_built_from_row(row) for row in result]

    def delete_built_candidate(self, machine_name: str, version: str) -> bool:
        """Delete a specific built candidate version."""
        engine = self._require_engine()
        with engine.begin() as conn:
            r = conn.execute(
                text(
                    "DELETE FROM discovery_built_candidates "
                    "WHERE machine_name = :mn AND version = :v"
                ),
                {"mn": machine_name, "v": version},
            )
        return bool(r.rowcount and r.rowcount > 0)

    def count_built_candidates_by_draft(
        self, draft_ids: list[str]
    ) -> dict[str, BuiltByDraftAggregate]:
        """Per-draft built-candidate aggregates in one round-trip.

        Branches on ``engine.dialect.name`` between SQLite
        (``json_extract``) and PostgreSQL (``->>``). Mirrors the
        precedent set by :func:`ensure_candidate_sequence_column`.
        """
        if not draft_ids:
            return {}
        engine = self._require_engine()
        dialect = engine.dialect.name
        # Per-dialect JSON path expression for the draft_id key.
        if dialect == "sqlite":
            draft_id_expr = "json_extract(metadata_json, '$.draft_id')"
        else:
            # PostgreSQL (and any other dialect using JSONB-like ops)
            draft_id_expr = "(metadata_json::jsonb ->> 'draft_id')"
        sql = text(
            f"""
            SELECT
              {draft_id_expr} AS draft_id,
              COUNT(*) AS n,
              MAX(created_at) AS latest_at
            FROM discovery_built_candidates
            WHERE {draft_id_expr} IN :_f_draft_ids
            GROUP BY {draft_id_expr}
            """
        ).bindparams(bindparam("_f_draft_ids", expanding=True))
        latest_version_sql = text(
            f"""
            SELECT b.version, {draft_id_expr} AS draft_id, b.created_at
            FROM discovery_built_candidates b
            WHERE {draft_id_expr} IN :_f_draft_ids
            ORDER BY b.created_at DESC
            """
        ).bindparams(bindparam("_f_draft_ids", expanding=True))
        with engine.begin() as conn:
            count_rows = (
                conn.execute(sql, {"_f_draft_ids": list(draft_ids)}).mappings().all()
            )
            version_rows = (
                conn.execute(latest_version_sql, {"_f_draft_ids": list(draft_ids)})
                .mappings()
                .all()
            )
        # Walk version rows in created_at DESC order; first hit per
        # draft_id is the latest. Cheaper than a window function and
        # works on both dialects without further branching.
        latest_by_draft: dict[str, str] = {}
        for vrow in version_rows:
            d_id = vrow["draft_id"]
            if d_id is None or d_id in latest_by_draft:
                continue
            latest_by_draft[d_id] = str(vrow["version"])
        out: dict[str, BuiltByDraftAggregate] = {}
        for crow in count_rows:
            d_id = crow["draft_id"]
            if d_id is None:
                continue
            d_id_str = str(d_id)
            out[d_id_str] = BuiltByDraftAggregate(
                draft_id=d_id_str,
                count=int(crow["n"] or 0),
                latest_version=latest_by_draft.get(d_id_str),
                latest_created_at=_dt_parse(crow["latest_at"])
                if crow["latest_at"]
                else None,
            )
        return out

    def record_shadow_diff(self, diff: ShadowDiff) -> None:
        engine = self._require_engine()
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    INSERT INTO discovery_shadow_diffs (
                      machine_name, source_state, trigger, active_success, active_target_state,
                      candidate_success, candidate_target_state, differs, reason, metadata_json, recorded_at
                    ) VALUES (
                      :machine_name, :source_state, :trigger, :active_success, :active_target_state,
                      :candidate_success, :candidate_target_state, :differs, :reason, :metadata_json, :recorded_at
                    )
                    """
                ),
                {
                    "machine_name": diff.machine_name,
                    "source_state": diff.source_state,
                    "trigger": diff.trigger,
                    "active_success": 1 if diff.active_success else 0,
                    "active_target_state": diff.active_target_state,
                    "candidate_success": 1 if diff.candidate_success else 0,
                    "candidate_target_state": diff.candidate_target_state,
                    "differs": 1 if diff.differs else 0,
                    "reason": diff.reason,
                    "metadata_json": json.dumps(diff.metadata),
                    "recorded_at": diff.recorded_at.isoformat(),
                },
            )

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    """
                    SELECT machine_name, source_state, trigger, active_success, active_target_state,
                           candidate_success, candidate_target_state, differs, reason, metadata_json, recorded_at
                    FROM discovery_shadow_diffs
                    WHERE machine_name = :machine_name
                    ORDER BY recorded_at DESC
                    LIMIT :limit
                    """
                ),
                {"machine_name": machine_name, "limit": max(0, limit)},
            ).mappings()
            result = rows.all()
        return [
            ShadowDiff(
                machine_name=row["machine_name"],
                source_state=row["source_state"],
                trigger=row["trigger"],
                active_success=bool(row["active_success"]),
                active_target_state=row["active_target_state"],
                candidate_success=bool(row["candidate_success"]),
                candidate_target_state=row["candidate_target_state"],
                differs=bool(row["differs"]),
                reason=row["reason"],
                metadata=json.loads(row["metadata_json"] or "{}"),
                recorded_at=_dt_parse(row["recorded_at"]),
            )
            for row in result
        ]

    def save_draft(self, draft: DiscoveryDraft) -> DiscoveryDraft:
        engine = self._require_engine()
        manual_json = json.dumps(
            [
                {"source_state": a, "destination_state": b}
                for (a, b) in draft.manual_edge_selection
            ]
        )
        with engine.begin() as conn:
            conn.execute(
                text(
                    """
                    INSERT INTO discovery_drafts (
                      id, instance_id, machine_name, title, selected_entity_ids_json, mode,
                      min_edge_count, min_confidence, manual_edge_selection_json,
                      created_at, updated_at, last_built_version, filter_json,
                      observation_source_json
                    ) VALUES (
                      :id, :instance_id, :machine_name, :title, :selected_entity_ids_json, :mode,
                      :min_edge_count, :min_confidence, :manual_edge_selection_json,
                      :created_at, :updated_at, :last_built_version, :filter_json,
                      :observation_source_json
                    )
                    ON CONFLICT(id) DO UPDATE SET
                      instance_id = excluded.instance_id,
                      machine_name = excluded.machine_name,
                      title = excluded.title,
                      selected_entity_ids_json = excluded.selected_entity_ids_json,
                      mode = excluded.mode,
                      min_edge_count = excluded.min_edge_count,
                      min_confidence = excluded.min_confidence,
                      manual_edge_selection_json = excluded.manual_edge_selection_json,
                      updated_at = excluded.updated_at,
                      last_built_version = excluded.last_built_version,
                      filter_json = excluded.filter_json,
                      observation_source_json = excluded.observation_source_json
                    """
                ),
                {
                    "id": draft.id,
                    "instance_id": draft.instance_id,
                    "machine_name": draft.machine_name,
                    "title": draft.title,
                    "selected_entity_ids_json": json.dumps(
                        list(draft.selected_entity_ids)
                    ),
                    "mode": draft.mode,
                    "min_edge_count": draft.min_edge_count,
                    "min_confidence": draft.min_confidence,
                    "manual_edge_selection_json": manual_json,
                    "created_at": draft.created_at.isoformat(),
                    "updated_at": draft.updated_at.isoformat(),
                    "last_built_version": draft.last_built_version,
                    "filter_json": _filter_to_json(draft.filter),
                    "observation_source_json": _observation_source_to_json(
                        draft.observation_source
                    ),
                },
            )
        return draft

    def get_draft(self, draft_id: str) -> DiscoveryDraft | None:
        engine = self._require_engine()
        with engine.begin() as conn:
            row = (
                conn.execute(
                    text(
                        """
                    SELECT id, instance_id, machine_name, title, selected_entity_ids_json, mode,
                           min_edge_count, min_confidence, manual_edge_selection_json,
                           created_at, updated_at, last_built_version, filter_json,
                           observation_source_json
                    FROM discovery_drafts
                    WHERE id = :id
                    """
                    ),
                    {"id": draft_id},
                )
                .mappings()
                .first()
            )
        if row is None:
            return None
        return _draft_from_row(row)

    def list_all_drafts(self) -> list[DiscoveryDraft]:
        """Return every draft across all channels, newest updated first."""
        engine = self._require_engine()
        with engine.begin() as conn:
            rows = conn.execute(
                text(
                    """
                    SELECT id, instance_id, machine_name, title, selected_entity_ids_json, mode,
                           min_edge_count, min_confidence, manual_edge_selection_json,
                           created_at, updated_at, last_built_version, filter_json,
                           observation_source_json
                    FROM discovery_drafts
                    ORDER BY updated_at DESC
                    """
                ),
            ).mappings()
            result = rows.all()
        return [_draft_from_row(row) for row in result]

    def delete_draft(self, draft_id: str) -> bool:
        engine = self._require_engine()
        with engine.begin() as conn:
            r = conn.execute(
                text("DELETE FROM discovery_drafts WHERE id = :id"),
                {"id": draft_id},
            )
        return bool(r.rowcount and r.rowcount > 0)
