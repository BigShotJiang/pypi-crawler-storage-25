"""PostgreSQL discovery store."""

from __future__ import annotations

from sqlalchemy.engine.url import make_url

from pystator.discovery.stores._sql import _SQLDiscoveryStoreBase


def _validate_postgres_url(connection_string: str) -> None:
    """Accept canonical URLs and SQLAlchemy driver forms (e.g. postgresql+psycopg2://)."""
    try:
        url = make_url(connection_string)
    except Exception as exc:
        raise ValueError(
            f"PostgresDiscoveryStore requires a valid PostgreSQL URL, got: {connection_string!r}"
        ) from exc
    dialect = (url.drivername or "").split("+", 1)[0].lower()
    if dialect not in ("postgresql", "postgres"):
        raise ValueError(
            f"PostgresDiscoveryStore requires a postgresql:// URL, got: {connection_string!r}"
        )


class PostgresDiscoveryStore(_SQLDiscoveryStoreBase):
    def __init__(self, connection_string: str) -> None:
        _validate_postgres_url(connection_string)
        super().__init__(connection_string)
