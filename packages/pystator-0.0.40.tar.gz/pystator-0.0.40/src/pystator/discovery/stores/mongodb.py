"""MongoDB discovery store."""

from __future__ import annotations

from datetime import datetime

from pystator.discovery.constants import DEFAULT_DISCOVERY_INSTANCE_ID
from pystator.discovery.models import (
    BuiltByDraftAggregate,
    BuiltDiscoveryCandidate,
    DiscoveryDraft,
    DiscoveryDraftFilter,
    ObservationIdentity,
    ObservedStateEvent,
    ShadowDiff,
)
from pystator.discovery.observation_source import (
    ObservationFieldMapping,
    ObservationSourceConfig,
)
from pystator.stores import deps as store_deps


def _mongo_built_from_doc(row: dict) -> BuiltDiscoveryCandidate:
    return BuiltDiscoveryCandidate(
        machine_name=row["machine_name"],
        version=row["version"],
        status=row["status"],
        config=dict(row["config"]),
        metadata=dict(row.get("metadata") or {}),
        created_at=row.get("created_at") or datetime.utcnow(),
        candidate_sequence=int(row.get("candidate_sequence") or 0),
    )


class MongoDBDiscoveryStore:
    def __init__(self, connection_string: str, database_name: str = "pystator") -> None:
        self._pymongo = store_deps.require_pymongo()
        if not connection_string.startswith(("mongodb://", "mongodb+srv://")):
            raise ValueError(
                f"MongoDBDiscoveryStore requires a mongodb:// URL, got: {connection_string!r}"
            )
        self.connection_string = connection_string
        self.database_name = database_name
        self._client = None
        self._db = None

    def connect(self) -> None:
        self._client = self._pymongo.MongoClient(self.connection_string)
        self._db = self._client[self.database_name]
        db = self._db
        coll_names = db.list_collection_names()
        if (
            "discovery_candidates" in coll_names
            and "discovery_built_candidates" not in coll_names
        ):
            db["discovery_candidates"].rename("discovery_built_candidates")
        if (
            "discovery_workspaces" in coll_names
            and "discovery_drafts" not in coll_names
        ):
            db["discovery_workspaces"].rename("discovery_drafts")
        db["discovery_observations"].create_index(
            [
                ("machine_name", 1),
                ("entity_id", 1),
                ("state", 1),
                ("observed_at", 1),
                ("source", 1),
                ("source_event_id", 1),
            ],
            unique=True,
        )
        db["discovery_built_candidates"].create_index(
            [("machine_name", 1), ("version", 1)], unique=True
        )
        db["discovery_drafts"].create_index([("id", 1)], unique=True)
        db["discovery_drafts"].create_index([("machine_name", 1), ("updated_at", -1)])

    def disconnect(self) -> None:
        if self._client is not None:
            self._client.close()
        self._client = None
        self._db = None

    def _require_db(self):
        if self._db is None:
            raise RuntimeError("Not connected. Call connect() first.")
        return self._db

    def add_observation(self, event: ObservedStateEvent) -> bool:
        db = self._require_db()
        doc = {
            "machine_name": event.machine_name,
            "entity_id": event.entity_id,
            "state": event.state,
            "observed_at": event.observed_at,
            "source": event.source,
            "source_event_id": event.source_event_id,
            "metadata": event.metadata,
            "ingested_at": event.ingested_at,
            "ingest_seq": event.ingest_seq,
        }
        try:
            db["discovery_observations"].insert_one(doc)
            return True
        except Exception:
            return False

    def list_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> list[ObservedStateEvent]:
        db = self._require_db()
        query = {"machine_name": machine_name}
        if entity_id:
            query["entity_id"] = entity_id
        rows = (
            db["discovery_observations"]
            .find(query)
            .sort(
                [
                    ("entity_id", 1),
                    ("observed_at", 1),
                    ("ingest_seq", 1),
                    ("ingested_at", 1),
                ]
            )
        )
        return [
            ObservedStateEvent(
                entity_id=row["entity_id"],
                machine_name=machine_name,
                state=row["state"],
                observed_at=row["observed_at"],
                source=row["source"],
                source_event_id=row.get("source_event_id"),
                metadata=dict(row.get("metadata") or {}),
                ingested_at=row["ingested_at"],
                ingest_seq=int(row.get("ingest_seq") or 0),
            )
            for row in rows
        ]

    def list_entity_ids(self, machine_name: str) -> list[str]:
        db = self._require_db()
        ids = db["discovery_observations"].distinct(
            "entity_id", {"machine_name": machine_name}
        )
        return sorted(str(x) for x in ids if x)

    def delete_observations_for_entity(self, machine_name: str, entity_id: str) -> int:
        db = self._require_db()
        result = db["discovery_observations"].delete_many(
            {"machine_name": machine_name, "entity_id": entity_id}
        )
        return int(result.deleted_count or 0)

    def delete_observation(
        self, machine_name: str, identity: ObservationIdentity
    ) -> bool:
        db = self._require_db()
        filt: dict = {
            "machine_name": machine_name,
            "entity_id": identity.entity_id,
            "state": identity.state,
            "observed_at": identity.observed_at,
            "source": identity.source,
        }
        if identity.source_event_id is None:
            filt["source_event_id"] = None
        else:
            filt["source_event_id"] = identity.source_event_id
        result = db["discovery_observations"].delete_one(filt)
        return bool(result.deleted_count and result.deleted_count > 0)

    def resolve_observations(
        self,
        filter: DiscoveryDraftFilter,
        *,
        observation_source: ObservationSourceConfig | None = None,
        limit: int = 50_000,
    ) -> tuple[list[ObservedStateEvent], bool]:
        """Resolve observations from a configured collection (draft-scoped).

        Without *observation_source*, this store does not support the
        legacy fleet filter query (use SQL or in-memory).
        """
        if observation_source is None:
            raise NotImplementedError(
                "Filter-based resolve_observations requires observation_source "
                "on MongoDB, or use the SQL / in-memory backend."
            )
        observation_source.validate_identifiers()
        fm = observation_source.field_mapping or ObservationFieldMapping()
        db = self._require_db()
        coll = db[observation_source.effective_collection_name()]
        q: dict = {}
        if filter.channels is not None:
            if not filter.channels:
                return [], False
            q[fm.machine_name] = {"$in": list(filter.channels)}
        if filter.entity_ids is not None:
            if not filter.entity_ids:
                return [], False
            q[fm.entity_id] = {"$in": list(filter.entity_ids)}
        if filter.sources is not None:
            if not filter.sources:
                return [], False
            q[fm.source] = {"$in": list(filter.sources)}
        time_bounds: dict = {}
        if filter.observed_after is not None:
            time_bounds["$gte"] = filter.observed_after
        if filter.observed_before is not None:
            time_bounds["$lte"] = filter.observed_before
        if time_bounds:
            q[fm.observed_at] = time_bounds
        has_metadata_filter = bool(filter.metadata_match)
        normalized_limit = max(1, int(limit))
        sql_ceiling = (
            normalized_limit * 4 + 1 if has_metadata_filter else normalized_limit + 1
        )
        cursor = (
            coll.find(q)
            .sort([(fm.machine_name, 1), (fm.entity_id, 1), (fm.observed_at, 1)])
            .limit(sql_ceiling)
        )
        rows = list(cursor)
        sql_truncated = len(rows) >= sql_ceiling
        meta_key = fm.metadata or "metadata_json"

        def _meta(doc: dict) -> dict:
            raw = doc.get(meta_key)
            if raw is None:
                return {}
            if isinstance(raw, dict):
                return dict(raw)
            return {}

        events: list[ObservedStateEvent] = []
        for doc in rows:
            observed_at = doc.get(fm.observed_at)
            if observed_at is None:
                continue
            if not isinstance(observed_at, datetime):
                continue
            ingested_at = doc.get("ingested_at")
            if not isinstance(ingested_at, datetime):
                ingested_at = observed_at
            seid = doc.get(fm.source_event_id) if fm.source_event_id else None
            events.append(
                ObservedStateEvent(
                    entity_id=str(doc.get(fm.entity_id) or ""),
                    machine_name=str(doc.get(fm.machine_name) or ""),
                    state=str(doc.get(fm.state) or ""),
                    observed_at=observed_at,
                    source=str(doc.get(fm.source) or ""),
                    source_event_id=(
                        str(seid) if seid is not None and str(seid) != "" else None
                    ),
                    metadata=_meta(doc),
                    ingested_at=ingested_at,
                    ingest_seq=int(doc.get("ingest_seq") or 0),
                )
            )
        if has_metadata_filter and filter.metadata_match:
            events = [
                ev
                for ev in events
                if all(ev.metadata.get(k) == v for k, v in filter.metadata_match)
            ]
        if len(events) > normalized_limit:
            return events[:normalized_limit], True
        return events, sql_truncated

    def list_observations_for_draft_scope(
        self,
        filter: DiscoveryDraftFilter,
        *,
        observation_source: ObservationSourceConfig | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[ObservedStateEvent], int]:
        if observation_source is None:
            raise NotImplementedError(
                "MongoDB draft-scoped observation listing requires observation_source "
                "on the draft; use SQLite or PostgreSQL for the default "
                "discovery_observations table."
            )
        lim = max(1, min(int(limit), 500))
        off = max(0, int(offset))
        if filter.metadata_match:
            events, _ = self.resolve_observations(
                filter, observation_source=observation_source, limit=500_000
            )
            events.sort(
                key=lambda e: (e.observed_at, e.ingest_seq, e.ingested_at),
                reverse=True,
            )
            total = len(events)
            return events[off : off + lim], total

        observation_source.validate_identifiers()
        fm = observation_source.field_mapping or ObservationFieldMapping()
        db = self._require_db()
        coll = db[observation_source.effective_collection_name()]
        q: dict = {}
        if filter.channels is not None:
            if not filter.channels:
                return [], 0
            q[fm.machine_name] = {"$in": list(filter.channels)}
        if filter.entity_ids is not None:
            if not filter.entity_ids:
                return [], 0
            q[fm.entity_id] = {"$in": list(filter.entity_ids)}
        if filter.sources is not None:
            if not filter.sources:
                return [], 0
            q[fm.source] = {"$in": list(filter.sources)}
        time_bounds: dict = {}
        if filter.observed_after is not None:
            time_bounds["$gte"] = filter.observed_after
        if filter.observed_before is not None:
            time_bounds["$lte"] = filter.observed_before
        if time_bounds:
            q[fm.observed_at] = time_bounds

        total = int(coll.count_documents(q))
        meta_key = fm.metadata or "metadata_json"

        def _meta(doc: dict) -> dict:
            raw = doc.get(meta_key)
            if raw is None:
                return {}
            if isinstance(raw, dict):
                return dict(raw)
            return {}

        cursor = coll.find(q).sort([(fm.observed_at, -1)]).skip(off).limit(lim)
        events: list[ObservedStateEvent] = []
        for doc in cursor:
            observed_at = doc.get(fm.observed_at)
            if observed_at is None or not isinstance(observed_at, datetime):
                continue
            ingested_at = doc.get("ingested_at")
            if not isinstance(ingested_at, datetime):
                ingested_at = observed_at
            seid = doc.get(fm.source_event_id) if fm.source_event_id else None
            events.append(
                ObservedStateEvent(
                    entity_id=str(doc.get(fm.entity_id) or ""),
                    machine_name=str(doc.get(fm.machine_name) or ""),
                    state=str(doc.get(fm.state) or ""),
                    observed_at=observed_at,
                    source=str(doc.get(fm.source) or ""),
                    source_event_id=(
                        str(seid) if seid is not None and str(seid) != "" else None
                    ),
                    metadata=_meta(doc),
                    ingested_at=ingested_at,
                    ingest_seq=int(doc.get("ingest_seq") or 0),
                )
            )
        return events, total

    def list_all_channels(self) -> list[str]:
        raise NotImplementedError(
            "list_all_channels requires the SQL or in-memory backend."
        )

    def list_all_sources(self) -> list[str]:
        raise NotImplementedError(
            "list_all_sources requires the SQL or in-memory backend."
        )

    def save_built_candidate(
        self, candidate: BuiltDiscoveryCandidate
    ) -> BuiltDiscoveryCandidate:
        db = self._require_db()
        coll = db["discovery_built_candidates"]
        existing = coll.find_one(
            {"machine_name": candidate.machine_name, "version": candidate.version}
        )
        if existing is not None:
            seq = int(existing.get("candidate_sequence") or 0)
        else:
            max_row = coll.find_one(
                {"machine_name": candidate.machine_name},
                sort=[("candidate_sequence", -1)],
            )
            max_seq = (
                int(max_row["candidate_sequence"])
                if max_row and max_row.get("candidate_sequence") is not None
                else 0
            )
            seq = max_seq + 1
        doc = {
            "machine_name": candidate.machine_name,
            "version": candidate.version,
            "status": candidate.status,
            "config": candidate.config,
            "metadata": candidate.metadata,
            "created_at": candidate.created_at,
            "candidate_sequence": seq,
        }
        coll.replace_one(
            {"machine_name": candidate.machine_name, "version": candidate.version},
            doc,
            upsert=True,
        )
        out = self.get_built_candidate(candidate.machine_name, candidate.version)
        assert out is not None
        return out

    def get_built_candidate(
        self, machine_name: str, version: str
    ) -> BuiltDiscoveryCandidate | None:
        db = self._require_db()
        row = db["discovery_built_candidates"].find_one(
            {"machine_name": machine_name, "version": version}
        )
        if not row:
            return None
        return _mongo_built_from_doc(row)

    def get_latest_built_candidate(
        self, machine_name: str
    ) -> BuiltDiscoveryCandidate | None:
        db = self._require_db()
        row = db["discovery_built_candidates"].find_one(
            {"machine_name": machine_name}, sort=[("created_at", -1)]
        )
        if not row:
            return None
        return _mongo_built_from_doc(row)

    def list_built_candidates(self, machine_name: str) -> list[BuiltDiscoveryCandidate]:
        db = self._require_db()
        rows = (
            db["discovery_built_candidates"]
            .find({"machine_name": machine_name})
            .sort([("created_at", -1)])
        )
        return [_mongo_built_from_doc(row) for row in rows]

    def delete_built_candidate(self, machine_name: str, version: str) -> bool:
        db = self._require_db()
        result = db["discovery_built_candidates"].delete_one(
            {"machine_name": machine_name, "version": version}
        )
        return result.deleted_count > 0

    def count_built_candidates_by_draft(
        self, draft_ids: list[str]
    ) -> dict[str, BuiltByDraftAggregate]:
        """Filter-based aggregates require the SQL or in-memory backend."""
        raise NotImplementedError(
            "count_built_candidates_by_draft requires the SQL or in-memory backend."
        )

    def record_shadow_diff(self, diff: ShadowDiff) -> None:
        db = self._require_db()
        db["discovery_shadow_diffs"].insert_one(
            {
                "machine_name": diff.machine_name,
                "source_state": diff.source_state,
                "trigger": diff.trigger,
                "active_success": diff.active_success,
                "active_target_state": diff.active_target_state,
                "candidate_success": diff.candidate_success,
                "candidate_target_state": diff.candidate_target_state,
                "differs": diff.differs,
                "reason": diff.reason,
                "recorded_at": diff.recorded_at,
                "metadata": diff.metadata,
            }
        )

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        db = self._require_db()
        rows = (
            db["discovery_shadow_diffs"]
            .find({"machine_name": machine_name})
            .sort([("recorded_at", -1)])
            .limit(max(0, limit))
        )
        return [
            ShadowDiff(
                machine_name=row["machine_name"],
                source_state=row["source_state"],
                trigger=row["trigger"],
                active_success=bool(row["active_success"]),
                active_target_state=row.get("active_target_state"),
                candidate_success=bool(row["candidate_success"]),
                candidate_target_state=row.get("candidate_target_state"),
                differs=bool(row["differs"]),
                reason=row.get("reason"),
                recorded_at=row["recorded_at"],
                metadata=dict(row.get("metadata") or {}),
            )
            for row in rows
        ]

    def _doc_to_draft(self, row: dict) -> DiscoveryDraft:
        sel = row.get("selected_entity_ids") or []
        manual = row.get("manual_edge_selection") or []
        pairs: list[tuple[str, str]] = []
        for item in manual:
            if isinstance(item, dict):
                s = item.get("source_state")
                d = item.get("destination_state")
                if isinstance(s, str) and isinstance(d, str):
                    pairs.append((s, d))
        obs_raw = row.get("observation_source")
        obs_src: ObservationSourceConfig | None = None
        if isinstance(obs_raw, dict) and obs_raw:
            obs_src = ObservationSourceConfig.from_json_dict(obs_raw)
        return DiscoveryDraft(
            id=row["id"],
            instance_id=str(row.get("instance_id") or DEFAULT_DISCOVERY_INSTANCE_ID),
            machine_name=row["machine_name"],
            title=row.get("title"),
            selected_entity_ids=tuple(str(x) for x in sel),
            mode=str(row.get("mode") or "inference"),
            min_edge_count=int(row.get("min_edge_count") or 2),
            min_confidence=float(row.get("min_confidence") or 0.5),
            manual_edge_selection=tuple(pairs),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            last_built_version=row.get("last_built_version"),
            observation_source=obs_src,
        )

    def save_draft(self, draft: DiscoveryDraft) -> DiscoveryDraft:
        db = self._require_db()
        obs_doc = (
            draft.observation_source.to_json_dict()
            if draft.observation_source is not None
            else None
        )
        db["discovery_drafts"].replace_one(
            {"id": draft.id},
            {
                "id": draft.id,
                "instance_id": draft.instance_id,
                "machine_name": draft.machine_name,
                "title": draft.title,
                "selected_entity_ids": list(draft.selected_entity_ids),
                "mode": draft.mode,
                "min_edge_count": draft.min_edge_count,
                "min_confidence": draft.min_confidence,
                "manual_edge_selection": [
                    {"source_state": a, "destination_state": b}
                    for (a, b) in draft.manual_edge_selection
                ],
                "created_at": draft.created_at,
                "updated_at": draft.updated_at,
                "last_built_version": draft.last_built_version,
                "observation_source": obs_doc,
            },
            upsert=True,
        )
        return draft

    def get_draft(self, draft_id: str) -> DiscoveryDraft | None:
        db = self._require_db()
        row = db["discovery_drafts"].find_one({"id": draft_id})
        if not row:
            return None
        return self._doc_to_draft(dict(row))

    def list_all_drafts(self) -> list[DiscoveryDraft]:
        """Return every draft across all channels, newest updated first."""
        db = self._require_db()
        rows = db["discovery_drafts"].find({}).sort([("updated_at", -1)])
        return [self._doc_to_draft(dict(r)) for r in rows]

    def delete_draft(self, draft_id: str) -> bool:
        db = self._require_db()
        r = db["discovery_drafts"].delete_one({"id": draft_id})
        return bool(r.deleted_count)
