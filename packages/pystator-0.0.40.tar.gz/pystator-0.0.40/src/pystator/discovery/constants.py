"""Discovery package constants."""

from __future__ import annotations

# Bootstrap id for drafts created before multi-instance; matches registry backfill.
DEFAULT_DISCOVERY_INSTANCE_ID = "00000000-0000-4000-8000-000000000001"
