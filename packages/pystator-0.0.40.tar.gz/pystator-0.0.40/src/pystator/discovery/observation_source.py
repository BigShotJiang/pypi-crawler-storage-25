"""Per-draft observation source: container name and optional field mapping."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

DEFAULT_OBSERVATION_TABLE = "discovery_observations"
DEFAULT_OBSERVATION_COLLECTION = "discovery_observations"

_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*\Z")


def validate_safe_identifier(name: str, *, field: str) -> str:
    """Allow single SQL/Mongo path segments (letters, digits, underscore)."""
    s = str(name).strip()
    if not _IDENTIFIER_RE.match(s):
        raise ValueError(
            f"Invalid {field} {name!r}: use ASCII letters, digits, and underscore only"
        )
    return s


def validate_safe_table_or_collection(name: str, *, field: str) -> str:
    """Validate ``table`` or ``schema.table`` / collection name."""
    n = str(name).strip()
    if not n:
        raise ValueError(f"{field} cannot be empty")
    if "." in n:
        a, b = n.split(".", 1)
        if "." in b:
            raise ValueError(f"Invalid {field} {name!r}: at most one '.' is allowed")
        return f"{validate_safe_identifier(a, field=f'{field} (schema)')}.{validate_safe_identifier(b, field=f'{field} (name)')}"
    return validate_safe_identifier(n, field=field)


@dataclass(frozen=True, slots=True)
class ObservationFieldMapping:
    """Maps external document/row fields to ObservedStateEvent components.

    Keys are logical names; values are field paths (dot notation for nested
    Mongo keys, e.g. ``events.0.state``) or simple column names for SQL.
    """

    entity_id: str = "entity_id"
    machine_name: str = "machine_name"
    state: str = "state"
    observed_at: str = "observed_at"
    source: str = "source"
    source_event_id: str | None = "source_event_id"
    metadata: str | None = None  # if None, remainder goes empty


@dataclass(frozen=True, slots=True)
class ObservationSourceConfig:
    """Where to read observations for a draft and how to map rows to events.

    When *mapping* is None, the store uses PyStator-native column/field names
    in the configured table/collection.

    For PostgreSQL, *schema_name* may be set instead of embedding the schema in
    *table_name* (``schema.table``). When *schema_name* is set, *table_name*
    must be a single unqualified identifier (no ``.``).
    """

    table_name: str | None = None  # SQL; default DEFAULT_OBSERVATION_TABLE
    schema_name: str | None = None  # SQL (e.g. PostgreSQL); optional schema qualifier
    collection_name: str | None = None  # Mongo; default DEFAULT_OBSERVATION_COLLECTION
    field_mapping: ObservationFieldMapping | None = None

    def effective_table_name(self) -> str:
        schema = (self.schema_name or "").strip()
        table_part = (self.table_name or DEFAULT_OBSERVATION_TABLE).strip()
        if schema:
            if "." in table_part:
                raise ValueError(
                    "table_name must not contain '.' when schema_name is set; "
                    "use schema_name and an unqualified table_name"
                )
            return f"{schema}.{table_part}"
        return self.table_name or DEFAULT_OBSERVATION_TABLE

    def effective_collection_name(self) -> str:
        return self.collection_name or DEFAULT_OBSERVATION_COLLECTION

    def validate_identifiers(self) -> None:
        """Raise :class:`ValueError` if any configured name is not a safe identifier."""
        validate_safe_table_or_collection(
            self.effective_table_name(), field="observation table_name"
        )
        validate_safe_table_or_collection(
            self.effective_collection_name(), field="observation collection_name"
        )
        fm = self.field_mapping or ObservationFieldMapping()
        validate_safe_identifier(fm.machine_name, field="field_mapping.machine_name")
        validate_safe_identifier(fm.entity_id, field="field_mapping.entity_id")
        validate_safe_identifier(fm.state, field="field_mapping.state")
        validate_safe_identifier(fm.observed_at, field="field_mapping.observed_at")
        validate_safe_identifier(fm.source, field="field_mapping.source")
        if fm.source_event_id:
            validate_safe_identifier(
                fm.source_event_id, field="field_mapping.source_event_id"
            )
        meta_col = fm.metadata or "metadata_json"
        validate_safe_identifier(meta_col, field="field_mapping.metadata")

    def to_json_dict(self) -> dict[str, Any]:
        m = self.field_mapping
        return {
            "table_name": self.table_name,
            "schema_name": self.schema_name,
            "collection_name": self.collection_name,
            "field_mapping": (
                None
                if m is None
                else {
                    "entity_id": m.entity_id,
                    "machine_name": m.machine_name,
                    "state": m.state,
                    "observed_at": m.observed_at,
                    "source": m.source,
                    "source_event_id": m.source_event_id,
                    "metadata": m.metadata,
                }
            ),
        }

    @classmethod
    def from_json_dict(
        cls, raw: dict[str, Any] | None
    ) -> ObservationSourceConfig | None:
        if not raw:
            return None
        fm_raw = raw.get("field_mapping")
        fm: ObservationFieldMapping | None = None
        if isinstance(fm_raw, dict) and fm_raw:
            fm = ObservationFieldMapping(
                entity_id=str(fm_raw.get("entity_id", "entity_id")),
                machine_name=str(fm_raw.get("machine_name", "machine_name")),
                state=str(fm_raw.get("state", "state")),
                observed_at=str(fm_raw.get("observed_at", "observed_at")),
                source=str(fm_raw.get("source", "source")),
                source_event_id=fm_raw.get("source_event_id"),
                metadata=fm_raw.get("metadata"),
            )
        sn = raw.get("schema_name")
        schema_name: str | None = None
        if isinstance(sn, str) and sn.strip():
            schema_name = sn.strip()
        return cls(
            table_name=raw.get("table_name"),
            schema_name=schema_name,
            collection_name=raw.get("collection_name"),
            field_mapping=fm,
        )
