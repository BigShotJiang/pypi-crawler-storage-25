"""Helpers for ordering discovery observations (newest-first UI, stable tie-breaks)."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Literal

from pystator.discovery.models import ObservationIdentity, ObservedStateEvent

_US = timedelta(microseconds=1)


def observation_identity_from_event(ev: ObservedStateEvent) -> ObservationIdentity:
    """Build a natural key from a loaded observation row."""
    return ObservationIdentity(
        entity_id=ev.entity_id,
        state=ev.state,
        observed_at=ev.observed_at,
        source=ev.source,
        source_event_id=ev.source_event_id,
    )


def sort_key_desc(ev: ObservedStateEvent) -> tuple[datetime, int, datetime]:
    """Sort key matching SQL ``ORDER BY observed_at DESC, ingest_seq DESC, ingested_at DESC``."""
    return (ev.observed_at, ev.ingest_seq, ev.ingested_at)


def identity_matches_event(
    identity: ObservationIdentity, ev: ObservedStateEvent
) -> bool:
    """Return True if *ev* matches the natural key carried by *identity*."""
    if ev.entity_id != identity.entity_id or ev.state != identity.state:
        return False
    if ev.source != identity.source:
        return False
    if (ev.source_event_id or None) != (identity.source_event_id or None):
        return False
    oa = ev.observed_at
    ob = identity.observed_at
    if oa.tzinfo is None and ob.tzinfo is not None:
        oa = oa.replace(tzinfo=UTC)
    if ob.tzinfo is None and oa.tzinfo is not None:
        ob = ob.replace(tzinfo=UTC)
    return oa == ob


def neighbors_for_relative_insert(
    events_newest_first: list[ObservedStateEvent],
    reference: ObservationIdentity,
    position: Literal["above", "below"],
) -> tuple[ObservedStateEvent | None, ObservedStateEvent | None]:
    """Return ``(upper, lower)`` sort bounds for a new row (newest-first list).

    *upper* is strictly newer than the inserted row (closer to the top of the table);
    *lower* is strictly older. Either may be ``None`` at the ends of the list.

    ``position`` is interpreted relative to the **reference** row as shown in the UI
    (newest at the top): *above* inserts between the next-newer row and the reference;
    *below* inserts between the reference and the next-older row.
    """
    idx = next(
        (
            i
            for i, ev in enumerate(events_newest_first)
            if identity_matches_event(reference, ev)
        ),
        -1,
    )
    if idx < 0:
        raise ValueError("reference observation not found in the provided sequence")

    if position == "above":
        upper = events_newest_first[idx - 1] if idx > 0 else None
        lower = events_newest_first[idx]
        return upper, lower

    upper = events_newest_first[idx]
    lower = events_newest_first[idx + 1] if idx + 1 < len(events_newest_first) else None
    return upper, lower


def _cmp_desc(a: ObservedStateEvent, b: ObservedStateEvent) -> int:
    ka, kb = sort_key_desc(a), sort_key_desc(b)
    if ka > kb:
        return 1
    if ka < kb:
        return -1
    return 0


def compute_sort_tuple_between(
    upper: ObservedStateEvent | None,
    lower: ObservedStateEvent | None,
) -> tuple[datetime, int, datetime]:
    """Pick ``(observed_at, ingest_seq, ingested_at)`` strictly between *upper* and *lower*.

    When *upper* is ``None``, the new row becomes the newest in the slice. When *lower*
    is ``None``, the new row becomes the oldest. *upper* must be newer than *lower*
    when both are set.
    """
    now = datetime.now(UTC)

    if upper is not None and lower is not None:
        if _cmp_desc(upper, lower) <= 0:
            raise ValueError("upper must be newer than lower for insertion")

    if upper is None and lower is None:
        return now, 0, now

    if upper is None:
        assert lower is not None
        # New row is newer than *lower* (the current top row).
        if now > lower.observed_at:
            return now, 0, now
        if now == lower.observed_at:
            return now, lower.ingest_seq + 1, now
        return lower.observed_at + _US, 0, now

    if lower is None:
        assert upper is not None
        # New row is older than *upper* (the current bottom row).
        oat = upper.observed_at - _US
        if oat < upper.observed_at:
            return oat, upper.ingest_seq, min(now, upper.ingested_at)
        ing = upper.ingested_at - _US if upper.ingested_at.tzinfo else upper.ingested_at
        return upper.observed_at, upper.ingest_seq - 1, ing

    assert upper is not None and lower is not None
    u, lower_event = upper, lower

    if u.observed_at > lower_event.observed_at + _US:
        mid = lower_event.observed_at + (u.observed_at - lower_event.observed_at) / 2
        if mid <= lower_event.observed_at:
            mid = lower_event.observed_at + _US
        if mid >= u.observed_at:
            mid = u.observed_at - _US
        if lower_event.observed_at < mid < u.observed_at:
            return mid, 0, now

    if u.observed_at > lower_event.observed_at:
        mid = lower_event.observed_at + _US
        if mid < u.observed_at:
            return mid, 0, now

    # Same observed_at: use ingest_seq gap if possible.
    if (
        u.observed_at == lower_event.observed_at
        and u.ingest_seq > lower_event.ingest_seq + 1
    ):
        mid_seq = (u.ingest_seq + lower_event.ingest_seq) // 2
        if lower_event.ingest_seq < mid_seq < u.ingest_seq:
            return u.observed_at, mid_seq, now

    if (
        u.observed_at == lower_event.observed_at
        and u.ingest_seq > lower_event.ingest_seq
    ):
        # Consecutive ingest_seq on the same timestamp: split on ingested_at.
        if u.ingested_at > lower_event.ingested_at + _US:
            delta = u.ingested_at - lower_event.ingested_at
            ing_mid = lower_event.ingested_at + delta / 2
            if lower_event.ingested_at < ing_mid < u.ingested_at:
                return u.observed_at, u.ingest_seq, ing_mid

    # Last resort: nudge observed_at one microsecond above *lower* toward *upper*.
    bumped = lower_event.observed_at + _US
    if bumped < u.observed_at:
        return bumped, 0, now
    if bumped == u.observed_at and u.ingest_seq > 0:
        return bumped, u.ingest_seq - 1, min(now, u.ingested_at)

    raise ValueError("cannot derive a strict sort position between the two neighbors")
