"""Draft management for discovery inference workflows."""

from __future__ import annotations

import uuid
from dataclasses import replace
from datetime import UTC, datetime
from typing import Any, Literal

from pystator.discovery.constants import DEFAULT_DISCOVERY_INSTANCE_ID
from pystator.discovery.models import DiscoveryDraft, DiscoveryDraftFilter
from pystator.discovery.observation_source import ObservationSourceConfig
from pystator.discovery.protocols import DraftStore

_MISSING_NEW_OBSERVATION_SOURCE = object()


def effective_inference_filter(draft: DiscoveryDraft) -> DiscoveryDraftFilter:
    """Return the draft's filter for inference scoping.

    Legacy drafts that stored entity scope in ``selected_entity_ids``
    instead of a proper ``DiscoveryDraftFilter`` should be migrated
    via :func:`migrate_legacy_draft_entity_ids` at schema-apply time.
    After migration, this function simply returns the stored filter
    (or an empty filter that reads all observations).
    """
    return draft.filter if draft.filter is not None else DiscoveryDraftFilter()


class DraftManager:
    """Manages discovery draft lifecycle: create, update, preview, build.

    Encapsulates all draft CRUD and the preview/build workflows that
    delegate back to the parent ``InferenceEngine`` for inference and
    candidate building.

    Args:
        draft_store: Persistence backend for drafts.
        default_min_edge_count: Default minimum edge count from thresholds.
        default_min_confidence: Default minimum confidence from thresholds.
        engine: The parent ``InferenceEngine`` used for preview and build
            operations.
    """

    def __init__(
        self,
        draft_store: DraftStore,
        thresholds: Any,
        engine: Any,
    ) -> None:
        self._drafts = draft_store
        self._thresholds = thresholds
        self._engine = engine

    def _normalize_draft_title(self, title: str) -> str:
        from pystator.discovery.slug import validate_discovery_slug

        return validate_discovery_slug(str(title), "draft title")

    def _draft_title_taken(
        self,
        instance_id: str,
        normalized_title: str,
        exclude_draft_id: str | None = None,
    ) -> bool:
        for d in self.list_all_drafts():
            if d.instance_id != instance_id:
                continue
            if exclude_draft_id is not None and d.id == exclude_draft_id:
                continue
            existing = (d.title or "").strip()
            if existing == normalized_title:
                return True
        return False

    def create_draft(
        self,
        title: str,
        *,
        instance_id: str = DEFAULT_DISCOVERY_INSTANCE_ID,
        filter: DiscoveryDraftFilter | None = None,
        min_edge_count: int | None = None,
        min_confidence: float | None = None,
        observation_source: ObservationSourceConfig | None = None,
    ) -> DiscoveryDraft:
        """Create a new discovery draft with default settings.

        Args:
            title: Unique slug per connection instance; also the default
                catalog name for built candidates.
            filter: Optional filter for which observations this draft reads.
            min_edge_count: Optional override for the engine default
                minimum edge count threshold. Clamped to ``>= 1``.
            min_confidence: Optional override for the engine default
                minimum confidence threshold. Clamped to ``[0, 1]``.

        Returns:
            The persisted draft with a generated UUID.
        """
        now = datetime.now(UTC)
        thr = self._thresholds
        resolved_title = self._normalize_draft_title(title)
        if self._draft_title_taken(instance_id, resolved_title):
            raise ValueError(
                f"duplicate draft title under this connection instance: {resolved_title!r}"
            )
        resolved_min_edge_count = (
            max(1, int(min_edge_count))
            if min_edge_count is not None
            else thr.min_edge_count
        )
        resolved_min_confidence = (
            min(1.0, max(0.0, float(min_confidence)))
            if min_confidence is not None
            else thr.min_confidence
        )
        draft = DiscoveryDraft(
            id=str(uuid.uuid4()),
            instance_id=instance_id,
            machine_name=resolved_title,
            title=resolved_title,
            selected_entity_ids=(),
            mode="inference",
            min_edge_count=resolved_min_edge_count,
            min_confidence=resolved_min_confidence,
            manual_edge_selection=(),
            created_at=now,
            updated_at=now,
            last_built_version=None,
            filter=filter,
            observation_source=observation_source,
        )
        return self._drafts.save_draft(draft)

    def list_all_drafts(self) -> list[DiscoveryDraft]:
        """List every draft across all channels, newest updated first."""
        return self._drafts.list_all_drafts()

    def get_draft(self, draft_id: str) -> DiscoveryDraft | None:
        """Retrieve a draft by ID.

        Args:
            draft_id: Unique draft identifier.

        Returns:
            The draft, or ``None`` if not found.
        """
        return self._drafts.get_draft(draft_id)

    def delete_draft(self, draft_id: str) -> bool:
        """Delete a draft by ID.

        Args:
            draft_id: Unique draft identifier.

        Returns:
            True if the draft was deleted, False if not found.
        """
        return self._drafts.delete_draft(draft_id)

    def update_draft(
        self,
        draft_id: str,
        *,
        title: str | None = None,
        selected_entity_ids: list[str] | None = None,
        mode: Literal["inference", "manual"] | None = None,
        min_edge_count: int | None = None,
        min_confidence: float | None = None,
        manual_edge_selection: list[tuple[str, str]] | None = None,
        filter: DiscoveryDraftFilter | None = None,
        clear_filter: bool = False,
        new_observation_source: ObservationSourceConfig
        | object = _MISSING_NEW_OBSERVATION_SOURCE,
        clear_observation_source: bool = False,
    ) -> DiscoveryDraft:
        """Partially update a draft's settings.

        Pass ``None`` (or omit the argument) to leave a field unchanged.
        Title clearing (setting back to ``None`` after being set) is
        handled at the patch-layer via key-presence semantics rather
        than through this engine-level method.

        Filter semantics:
            - ``filter=None`` and ``clear_filter=False`` → leave
              the draft's filter unchanged.
            - ``filter=<value>`` → set the filter to *value*.
            - ``clear_filter=True`` → clear the filter (set to ``None``).
              Takes precedence over any explicit ``filter`` argument.

        Args:
            draft_id: Unique draft identifier.
            title: New title (``None`` = leave unchanged).
            selected_entity_ids: Entity IDs merged into the inference filter
                when the filter omits ``entity_ids``.
            mode: ``"inference"`` or ``"manual"``.
            min_edge_count: Minimum edge count threshold.
            min_confidence: Minimum confidence threshold.
            manual_edge_selection: Explicit edge pairs for manual mode.
            filter: New filter value (``None`` = leave unchanged).
            clear_filter: When ``True``, clear the filter.
            new_observation_source: Replace observation source (pass a
                config instance). Use the sentinel default to leave it
                unchanged.
            clear_observation_source: When ``True``, clear to native
                storage (``None``). Takes precedence over
                *new_observation_source*.

        Returns:
            The updated draft.

        Raises:
            ValueError: If the draft is not found.
        """
        draft = self._drafts.get_draft(draft_id)
        if draft is None:
            raise ValueError(f"draft not found: {draft_id}")
        # Compare each incoming field to the current stored value and
        # only stage real changes. If nothing actually changes, this
        # is a no-op — we deliberately do NOT bump ``updated_at`` in
        # that case, so a PATCH that re-sends identical state
        # (e.g. from the UI's auto-preview path) doesn't cause the
        # draft to jump to the top of the ``list_all_drafts`` order
        # and look to the user like "a new instance was created".
        updates: dict[str, Any] = {}
        if title is not None:
            nt = self._normalize_draft_title(title)
            if nt != (draft.title or "").strip():
                if self._draft_title_taken(
                    draft.instance_id, nt, exclude_draft_id=draft_id
                ):
                    raise ValueError(
                        f"duplicate draft title under this connection instance: {nt!r}"
                    )
                updates["title"] = nt
                updates["machine_name"] = nt
        if selected_entity_ids is not None:
            new_ids = tuple(selected_entity_ids)
            if new_ids != draft.selected_entity_ids:
                updates["selected_entity_ids"] = new_ids
        if mode is not None and mode != draft.mode:
            updates["mode"] = mode
        if min_edge_count is not None:
            new_mec = max(1, int(min_edge_count))
            if new_mec != draft.min_edge_count:
                updates["min_edge_count"] = new_mec
        if min_confidence is not None:
            new_mc = min(1.0, max(0.0, float(min_confidence)))
            if abs(new_mc - draft.min_confidence) > 1e-9:
                updates["min_confidence"] = new_mc
        if manual_edge_selection is not None:
            new_edges = tuple((str(a), str(b)) for a, b in manual_edge_selection)
            if new_edges != draft.manual_edge_selection:
                updates["manual_edge_selection"] = new_edges
        if clear_filter:
            if draft.filter is not None:
                updates["filter"] = None
        elif filter is not None and filter != draft.filter:
            updates["filter"] = filter
        if clear_observation_source:
            if draft.observation_source is not None:
                updates["observation_source"] = None
        elif new_observation_source is not _MISSING_NEW_OBSERVATION_SOURCE:
            if not isinstance(new_observation_source, ObservationSourceConfig):
                raise TypeError(
                    "new_observation_source must be ObservationSourceConfig"
                )
            new_observation_source.validate_identifiers()
            if new_observation_source != draft.observation_source:
                updates["observation_source"] = new_observation_source
        if not updates:
            return draft
        updates["updated_at"] = datetime.now(UTC)
        new_draft = replace(draft, **updates)
        return self._drafts.save_draft(new_draft)

    def preview_draft(self, draft_id: str) -> dict[str, Any]:
        """Preview inferred edges for a draft's scope without building."""
        draft = self._drafts.get_draft(draft_id)
        if draft is None:
            raise ValueError(f"draft not found: {draft_id}")
        eff = effective_inference_filter(draft)
        return self._engine.preview_filter(
            eff,
            mode=draft.mode,
            min_edge_count=draft.min_edge_count,
            min_confidence=draft.min_confidence,
            observation_source=draft.observation_source,
        )

    def build_from_draft(
        self,
        draft_id: str,
        *,
        target_machine_name: str | None = None,
    ) -> Any:
        """Build a candidate machine from the draft's scope and settings.

        Args:
            draft_id: Unique draft identifier.
            target_machine_name: Override for the published candidate's
                catalog name. When omitted, the draft's catalog slug
                (``machine_name`` column) is used.

        Returns:
            The built ``BuiltDiscoveryCandidate``.

        Raises:
            ValueError: If the draft is not found or is in manual mode
                without edge selections.
        """
        draft = self._drafts.get_draft(draft_id)
        if draft is None:
            raise ValueError(f"draft not found: {draft_id}")
        edge_sel: list[tuple[str, str]] | None = None
        if draft.mode == "manual":
            edge_sel = list(draft.manual_edge_selection)
            if not edge_sel:
                raise ValueError(
                    "manual mode requires manual_edge_selection on the draft"
                )
        eff = effective_inference_filter(draft)
        cand = self._engine.build_candidate(
            draft.machine_name,
            mode=draft.mode,
            entity_ids=None,
            edge_selection=edge_sel,
            min_edge_count=draft.min_edge_count,
            min_confidence=draft.min_confidence,
            draft_id=draft.id,
            filter=eff,
            target_machine_name=target_machine_name,
            observation_source=draft.observation_source,
        )
        updated = replace(
            draft,
            last_built_version=cand.version,
            updated_at=datetime.now(UTC),
        )
        self._drafts.save_draft(updated)
        return cand
