"""Stateless inference engine for observed-state machine discovery."""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, replace
from typing import Any, Literal

from pystator.discovery._drafts import DraftManager
from pystator.discovery._inference import (
    build_machine_config,
    edges_to_dict,
    infer_edges,
    next_version,
)
from pystator.discovery.constants import DEFAULT_DISCOVERY_INSTANCE_ID
from pystator.discovery.models import (
    BuiltDiscoveryCandidate,
    DiscoveryDraft,
    DiscoveryDraftFilter,
    InferredEdge,
    ObservationIdentity,
    ObservedStateEvent,
    ShadowDiff,
)
from pystator.discovery.observation_ordering import (
    compute_sort_tuple_between,
    neighbors_for_relative_insert,
    sort_key_desc,
)
from pystator.discovery.observation_source import ObservationSourceConfig
from pystator.discovery.protocols import (
    BuiltDiscoveryCandidateStore,
    DraftStore,
    ObservationStore,
    ShadowResultStore,
)
from pystator.machine import StateMachine

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class InferenceThresholds:
    """Threshold parameters for edge filtering during inference."""

    min_edge_count: int = 2
    min_confidence: float = 0.5


class InferenceEngine:
    """Primary discovery API: ingest, infer, and shadow-compare."""

    def __init__(
        self,
        observation_store: ObservationStore,
        built_candidate_store: BuiltDiscoveryCandidateStore,
        shadow_store: ShadowResultStore,
        thresholds: InferenceThresholds | None = None,
        *,
        draft_store: DraftStore | None = None,
    ) -> None:
        """Initialize the inference engine.

        Args:
            observation_store: Store for observed state events.
            built_candidate_store: Store for built (persisted) candidate FSM snapshots.
            shadow_store: Store for shadow comparison results.
            thresholds: Optional edge-count and confidence thresholds.
            draft_store: Draft scopes before build; defaults to *observation_store* if it
                implements draft persistence (same combined store).
        """
        self._observations = observation_store
        self._built_candidates = built_candidate_store
        self._shadow = shadow_store
        self._thresholds = thresholds or InferenceThresholds()
        self._drafts: DraftStore = draft_store or observation_store  # type: ignore[assignment]
        self._draft_manager = DraftManager(self._drafts, self._thresholds, self)

    @classmethod
    def for_connection(
        cls,
        backend: str,
        connection_string: str | None,
        *,
        thresholds: InferenceThresholds | None = None,
    ) -> InferenceEngine:
        """Build an engine for an explicit backend and connection (per discovery instance)."""
        from pystator.config.discovery import (
            get_discovery_min_confidence,
            get_discovery_min_edge_count,
        )
        from pystator.discovery.stores import create_discovery_store

        store = create_discovery_store(
            backend,
            connection_string=connection_string,
            options={"database_name": "pystator"},
        )
        if hasattr(store, "connect"):
            store.connect()

        if thresholds is None:
            thresholds = InferenceThresholds(
                min_edge_count=get_discovery_min_edge_count(),
                min_confidence=get_discovery_min_confidence(),
            )

        return cls(
            observation_store=store,
            built_candidate_store=store,
            shadow_store=store,
            thresholds=thresholds,
            draft_store=store,
        )

    @classmethod
    def from_app_config(
        cls,
        *,
        thresholds: InferenceThresholds | None = None,
        quiet: bool = False,
    ) -> InferenceEngine:
        """Create a discovery engine from pystator's app config.

        This is the **canonical** way to create an inference engine.  The
        notebook, CLI, API server, and tests all use this factory so that
        data written by one component is visible to the others.

        Resolution order (matches every other pystator module):

        1. ``PYSTATOR_DISCOVERY_BACKEND`` (env or ``pystator.cfg [discovery]``)
        2. ``PYSTATOR_DISCOVERY_DATABASE_URL`` (env or ``pystator.cfg [discovery]``)
        3. ``PYSTATOR_DATABASE_URL`` (fallback to shared app database)
        4. ``sqlite:///<cwd>/pystator.db`` (default, matching
           :func:`pystator.db.config.get_db_url`)

        If the resolved backend is ``"memory"`` and no discovery URL is
        explicitly set, the backend is upgraded to ``"sqlite"`` pointing
        at the default path.  This keeps behavior consistent with
        ``worker``, ``machine_store``, and API bootstrap — all of which
        default to persistent SQLite so data survives process restarts.

        Thresholds, if not provided, are read from
        ``PYSTATOR_DISCOVERY_MIN_EDGE_COUNT`` and
        ``PYSTATOR_DISCOVERY_MIN_CONFIDENCE``.

        The returned engine has its store already connected — safe for
        immediate use in notebooks, CLI, API, and tests.

        Args:
            thresholds: Optional explicit thresholds (overrides env config).
            quiet: Suppress the "using default SQLite" info print.

        Returns:
            Configured InferenceEngine with a live store connection.
        """
        from pystator.discovery.connection_resolution import (
            resolve_default_discovery_connection,
        )

        backend, db_url = resolve_default_discovery_connection(quiet=quiet)
        return cls.for_connection(backend, db_url, thresholds=thresholds)

    def record_observation(self, machine_name: str, event: ObservedStateEvent) -> bool:
        """Record an observed state event for a machine.

        Args:
            machine_name: Expected machine name (must match event).
            event: The observed state event to record.

        Returns:
            True if the observation was successfully stored.

        Raises:
            ValueError: If the event's machine_name does not match.
        """
        if event.machine_name != machine_name:
            raise ValueError(
                f"Event machine_name '{event.machine_name}' does not match "
                f"expected '{machine_name}'"
            )
        return self._observations.add_observation(event)

    def delete_observation(
        self, machine_name: str, identity: ObservationIdentity
    ) -> bool:
        """Delete a single observation row identified by its natural key."""
        return self._observations.delete_observation(machine_name, identity)

    def insert_observation_relative(
        self,
        machine_name: str,
        *,
        entity_id: str,
        reference: ObservationIdentity,
        position: Literal["above", "below"],
        state: str,
        source: str = "api",
        source_event_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """Insert an observation adjacent to *reference* in newest-first table order.

        *position* ``above`` places the new row between the next-newer neighbor and
        *reference*; ``below`` places it between *reference* and the next-older row.
        """
        if reference.entity_id != entity_id:
            raise ValueError("reference.entity_id must match entity_id")
        events = self._observations.list_observations(machine_name, entity_id)
        events.sort(key=sort_key_desc, reverse=True)
        upper, lower = neighbors_for_relative_insert(events, reference, position)
        oat, iseq, ing = compute_sort_tuple_between(upper, lower)
        uid = source_event_id or str(uuid.uuid4())
        event = ObservedStateEvent(
            entity_id=entity_id,
            machine_name=machine_name,
            state=state,
            observed_at=oat,
            source=source,
            source_event_id=uid,
            metadata=dict(metadata or {}),
            ingest_seq=iseq,
            ingested_at=ing,
        )
        return self.record_observation(machine_name, event)

    def record_observations(
        self, machine_name: str, events: list[ObservedStateEvent]
    ) -> int:
        """Record multiple observations in one call.

        Args:
            machine_name: Machine all events must belong to.
            events: List of observed state events to record.

        Returns:
            Number of events accepted (deduplicated).

        Raises:
            ValueError: If any event's machine_name doesn't match.
        """
        accepted = 0
        for event in events:
            if event.machine_name != machine_name:
                raise ValueError(
                    f"Event machine_name '{event.machine_name}' "
                    f"doesn't match '{machine_name}'"
                )
            if self._observations.add_observation(event):
                accepted += 1
        return accepted

    def _resolve_thresholds(
        self, min_edge_count: int | None, min_confidence: float | None
    ) -> InferenceThresholds:
        """Merge caller overrides with engine defaults."""
        return InferenceThresholds(
            min_edge_count=max(
                1, int(min_edge_count or self._thresholds.min_edge_count)
            ),
            min_confidence=min(
                1.0,
                max(
                    0.0,
                    float(
                        min_confidence
                        if min_confidence is not None
                        else self._thresholds.min_confidence
                    ),
                ),
            ),
        )

    def _build_preview_payload(
        self,
        observations: list[ObservedStateEvent],
        *,
        mode: Literal["inference", "manual"],
        thresholds: InferenceThresholds,
        label: str,
        limit_reached: bool = False,
    ) -> dict[str, Any]:
        """Assemble the standard preview payload from a fetched event set."""
        edges = infer_edges(observations)
        selected = [
            e
            for e in edges
            if e.count >= thresholds.min_edge_count
            and e.confidence >= thresholds.min_confidence
        ]
        entity_ids_used = sorted(
            {obs.entity_id for obs in observations if obs.entity_id}
        )
        source_channels_used = sorted(
            {obs.machine_name for obs in observations if obs.machine_name}
        )
        return {
            "machine_name": label,
            "mode": mode,
            "entity_ids_used": entity_ids_used,
            "source_channels_used": source_channels_used,
            "observation_count": len(observations),
            "observation_limit_reached": limit_reached,
            "edges": edges,
            "selected_edges": selected,
            "thresholds": {
                "min_edge_count": thresholds.min_edge_count,
                "min_confidence": thresholds.min_confidence,
            },
        }

    def preview_filter(
        self,
        filter: DiscoveryDraftFilter,
        *,
        mode: Literal["inference", "manual"] = "inference",
        min_edge_count: int | None = None,
        min_confidence: float | None = None,
        observation_source: ObservationSourceConfig | None = None,
    ) -> dict[str, Any]:
        """Preview inferred edges from events matching *filter*.

        This is the canonical path for filter-based Discovery Instances:
        events are resolved across all channels via
        ``ObservationStore.resolve_observations`` and then fed through
        the inference pipeline used for draft preview and build.

        Args:
            filter: Filter selecting observations from the shared event
                stream.
            mode: Inference mode (``"inference"`` or ``"manual"``).
            min_edge_count: Override minimum edge count threshold.
            min_confidence: Override minimum confidence threshold.
            observation_source: Per-draft observation table/collection mapping.

        Returns:
            Dict with inferred edges, selected edges, and metadata,
            plus ``observation_limit_reached`` and
            ``source_channels_used`` (list of channels contributing
            observations).
        """
        observations, limit_reached = self._observations.resolve_observations(
            filter, observation_source=observation_source
        )
        thresholds = self._resolve_thresholds(min_edge_count, min_confidence)
        if filter.channels and len(filter.channels) == 1:
            label = filter.channels[0]
        elif filter.channels:
            label = "|".join(filter.channels)
        else:
            label = "<filter>"
        return self._build_preview_payload(
            observations,
            mode=mode,
            thresholds=thresholds,
            label=label,
            limit_reached=limit_reached,
        )

    def build_candidate(
        self,
        machine_name: str,
        version: str | None = None,
        *,
        mode: Literal["inference", "manual"] = "inference",
        entity_ids: list[str] | None = None,
        edge_selection: list[tuple[str, str]] | None = None,
        min_edge_count: int | None = None,
        min_confidence: float | None = None,
        draft_id: str | None = None,
        filter: DiscoveryDraftFilter | None = None,
        target_machine_name: str | None = None,
        observation_source: ObservationSourceConfig | None = None,
    ) -> BuiltDiscoveryCandidate:
        """Build and store a candidate machine from observations.

        Args:
            machine_name: Catalog name for the built candidate when
                *target_machine_name* is omitted (default publish target).
            version: Explicit version string (auto-incremented if omitted).
            mode: ``"inference"`` uses threshold filtering; ``"manual"``
                requires explicit *edge_selection*.
            entity_ids: Optional entity-id subset merged into *filter*
                when the filter omits ``entity_ids``.
            edge_selection: Required for manual mode; list of
                ``(source, dest)`` pairs to include.
            min_edge_count: Override minimum edge count threshold.
            min_confidence: Override minimum confidence threshold.
            draft_id: Optional originating draft id (recorded in metadata).
            filter: Observation scope; ``None`` means all channels (and
                dimensions unset) via ``resolve_observations``.
            target_machine_name: Override for the persisted candidate's
                ``machine_name``.
            observation_source: Per-draft observation table/collection mapping.

        Returns:
            The persisted built discovery candidate.

        Raises:
            ValueError: If manual mode is used without *edge_selection*
                or selection contains unknown edge pairs.
        """
        eff: DiscoveryDraftFilter = (
            filter if filter is not None else DiscoveryDraftFilter()
        )
        if entity_ids:
            normalized_ids = tuple(
                sorted({x.strip() for x in entity_ids if x and x.strip()})
            )
            if normalized_ids and eff.entity_ids is None:
                eff = replace(eff, entity_ids=normalized_ids)
        preview = self.preview_filter(
            eff,
            mode=mode,
            min_edge_count=min_edge_count,
            min_confidence=min_confidence,
            observation_source=observation_source,
        )
        edges: list[InferredEdge] = preview["edges"]
        thresholds = self._resolve_thresholds(min_edge_count, min_confidence)
        selected: list[InferredEdge]
        normalized_selection = sorted(set(edge_selection or []))
        if mode == "manual":
            if not normalized_selection:
                raise ValueError("manual mode requires non-empty edge_selection")
            allowed = set(normalized_selection)
            selected = [
                e for e in edges if (e.source_state, e.destination_state) in allowed
            ]
            if len(selected) != len(allowed):
                existing = {(e.source_state, e.destination_state) for e in edges}
                missing = sorted(allowed - existing)
                raise ValueError(
                    "edge_selection contains pairs not present in inferred edges: "
                    f"{missing}"
                )
        else:
            selected = [
                e
                for e in edges
                if e.count >= thresholds.min_edge_count
                and e.confidence >= thresholds.min_confidence
            ]
        effective_name = target_machine_name or machine_name
        config = build_machine_config(effective_name, selected)
        meta: dict[str, Any] = {
            "edge_count": len(edges),
            "selected_edge_count": len(selected),
            "build_mode": mode,
            "build_scope": {
                "catalog_slug": machine_name,
                "entity_ids": preview["entity_ids_used"],
                "source_channels_used": preview.get("source_channels_used", []),
                "edge_selection": [
                    {"source_state": src, "destination_state": dst}
                    for (src, dst) in normalized_selection
                ],
            },
            "observation_count": preview["observation_count"],
            "thresholds": {
                "min_edge_count": thresholds.min_edge_count,
                "min_confidence": thresholds.min_confidence,
            },
            "inferred_edges_snapshot": edges_to_dict(edges),
            "selected_edges_snapshot": edges_to_dict(selected),
        }
        if draft_id:
            meta["draft_id"] = draft_id
        if version is None:
            latest = self._built_candidates.get_latest_built_candidate(effective_name)
            resolved_version = next_version(latest.version if latest else None)
        else:
            resolved_version = version
        candidate = BuiltDiscoveryCandidate(
            machine_name=effective_name,
            version=resolved_version,
            status="candidate",
            config=config,
            metadata=meta,
        )
        return self._built_candidates.save_built_candidate(candidate)

    # -- Draft delegation ------------------------------------------------------

    def create_draft(
        self,
        title: str,
        *,
        instance_id: str | None = None,
        filter: DiscoveryDraftFilter | None = None,
        min_edge_count: int | None = None,
        min_confidence: float | None = None,
        observation_source: ObservationSourceConfig | None = None,
    ) -> DiscoveryDraft:
        """Create a new discovery draft scope."""
        return self._draft_manager.create_draft(
            title,
            instance_id=instance_id or DEFAULT_DISCOVERY_INSTANCE_ID,
            filter=filter,
            min_edge_count=min_edge_count,
            min_confidence=min_confidence,
            observation_source=observation_source,
        )

    def get_draft(self, draft_id: str) -> DiscoveryDraft | None:
        """Retrieve a draft by ID."""
        return self._draft_manager.get_draft(draft_id)

    def list_all_drafts(self) -> list[DiscoveryDraft]:
        """List every draft across all channels, newest updated first."""
        return self._draft_manager.list_all_drafts()

    def delete_draft(self, draft_id: str) -> bool:
        """Delete a draft by ID."""
        return self._draft_manager.delete_draft(draft_id)

    def update_draft(self, draft_id: str, **kwargs: Any) -> DiscoveryDraft:
        """Partially update a draft's settings.

        Keyword arguments are forwarded to :meth:`DraftManager.update_draft`.
        """
        return self._draft_manager.update_draft(draft_id, **kwargs)

    def preview_draft(self, draft_id: str) -> dict[str, Any]:
        """Preview inferred edges for a draft's scope without building."""
        return self._draft_manager.preview_draft(draft_id)

    def build_from_draft(
        self,
        draft_id: str,
        *,
        target_machine_name: str | None = None,
    ) -> BuiltDiscoveryCandidate:
        """Build a candidate machine from the draft's scope and settings."""
        return self._draft_manager.build_from_draft(
            draft_id, target_machine_name=target_machine_name
        )

    # -- Shadow comparison -----------------------------------------------------

    def run_shadow_compare(
        self,
        *,
        machine_name: str,
        active_config: dict[str, Any],
        source_state: str,
        trigger: str,
        context: dict[str, Any] | None = None,
        candidate_version: str | None = None,
    ) -> ShadowDiff | None:
        """Run a shadow comparison between active and candidate machines.

        Args:
            machine_name: Machine name.
            active_config: Active machine configuration dict.
            source_state: Current state to process from.
            trigger: Event trigger name.
            context: Optional context dict for processing.
            candidate_version: Specific candidate version (latest if None).

        Returns:
            A ShadowDiff capturing any divergence, or None if no candidate.
        """
        candidate = (
            self._built_candidates.get_built_candidate(machine_name, candidate_version)
            if candidate_version
            else self._built_candidates.get_latest_built_candidate(machine_name)
        )
        if candidate is None:
            return None
        active_result = StateMachine.from_dict(active_config).process(
            source_state, trigger, context or {}
        )
        candidate_result = StateMachine.from_dict(candidate.config).process(
            source_state, trigger, context or {}
        )
        differs = (active_result.success != candidate_result.success) or (
            active_result.target_state != candidate_result.target_state
        )
        reason: str | None = None
        if differs:
            if active_result.success != candidate_result.success:
                reason = "success_mismatch"
            else:
                reason = "target_state_mismatch"
        diff = ShadowDiff(
            machine_name=machine_name,
            source_state=source_state,
            trigger=trigger,
            active_success=active_result.success,
            active_target_state=active_result.target_state,
            candidate_success=candidate_result.success,
            candidate_target_state=candidate_result.target_state,
            differs=differs,
            reason=reason,
            metadata={"candidate_version": candidate.version},
        )
        self._shadow.record_shadow_diff(diff)
        return diff

    def compare_candidate_against_baseline(
        self,
        *,
        machine_name: str,
        baseline_config: dict[str, Any],
        baseline_machine_name: str,
        candidate_version: str | None = None,
    ) -> list[ShadowDiff]:
        """On-demand cross-channel comparison.

        Compares every ``(source_state, trigger)`` pair defined in the
        candidate's transitions against a baseline machine config. The
        results are ephemeral (not recorded to the shadow diff store).

        Args:
            machine_name: Discovery channel the candidate was built on.
            baseline_config: Baseline machine configuration dict.
            baseline_machine_name: Human-readable name for the baseline
                (stored in metadata for UI display).
            candidate_version: Specific candidate to compare. Uses
                latest if ``None``.

        Returns:
            List of ``ShadowDiff`` objects, one per transition pair.
            Empty list if no candidate exists.
        """
        candidate = (
            self._built_candidates.get_built_candidate(machine_name, candidate_version)
            if candidate_version
            else self._built_candidates.get_latest_built_candidate(machine_name)
        )
        if candidate is None:
            return []
        cand_machine = StateMachine.from_dict(candidate.config)
        baseline_machine = StateMachine.from_dict(baseline_config)
        # Extract all (source, trigger) pairs from the candidate's transitions.
        transitions = candidate.config.get("transitions", [])
        pairs: list[tuple[str, str]] = []
        for t in transitions:
            sources = t.get("source", [])
            if isinstance(sources, str):
                sources = [sources]
            trigger = t.get("trigger", "")
            for src in sources:
                if src and trigger:
                    pairs.append((src, trigger))
        diffs: list[ShadowDiff] = []
        for source_state, trigger in pairs:
            try:
                active_result = baseline_machine.process(source_state, trigger, {})
            except Exception:
                active_result = type(
                    "R", (), {"success": False, "target_state": None}
                )()
            try:
                cand_result = cand_machine.process(source_state, trigger, {})
            except Exception:
                cand_result = type("R", (), {"success": False, "target_state": None})()
            differs = (active_result.success != cand_result.success) or (
                active_result.target_state != cand_result.target_state
            )
            reason: str | None = None
            if differs:
                reason = (
                    "success_mismatch"
                    if active_result.success != cand_result.success
                    else "target_state_mismatch"
                )
            diffs.append(
                ShadowDiff(
                    machine_name=machine_name,
                    source_state=source_state,
                    trigger=trigger,
                    active_success=active_result.success,
                    active_target_state=active_result.target_state,
                    candidate_success=cand_result.success,
                    candidate_target_state=cand_result.target_state,
                    differs=differs,
                    reason=reason,
                    metadata={
                        "candidate_version": candidate.version,
                        "baseline_machine_name": baseline_machine_name,
                    },
                )
            )
        return diffs

    # -- Built candidate queries -----------------------------------------------

    def get_latest_built_candidate(
        self, machine_name: str
    ) -> BuiltDiscoveryCandidate | None:
        """Return the latest built candidate for *machine_name*."""
        return self._built_candidates.get_latest_built_candidate(machine_name)

    def list_built_candidates(self, machine_name: str) -> list[BuiltDiscoveryCandidate]:
        """Return all saved built candidates for *machine_name*, store-defined order."""
        return self._built_candidates.list_built_candidates(machine_name)

    def get_built_candidate(
        self, machine_name: str, version: str
    ) -> BuiltDiscoveryCandidate | None:
        """Return a specific built candidate version, if present."""
        return self._built_candidates.get_built_candidate(machine_name, version)

    def delete_built_candidate(self, machine_name: str, version: str) -> bool:
        """Delete a specific built candidate version. Returns True if deleted."""
        return self._built_candidates.delete_built_candidate(machine_name, version)

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        """Return shadow diffs for *machine_name*."""
        return self._shadow.list_shadow_diffs(machine_name, limit=limit)

    # -- Diagram export --------------------------------------------------------

    def export_candidate_diagram(
        self,
        machine_name: str,
        version: str | None = None,
        format: Literal["mermaid", "dot"] = "mermaid",
        **kwargs: Any,
    ) -> str:
        """Export a built candidate as a diagram string.

        Args:
            machine_name: Machine name.
            version: Candidate version (latest if None).
            format: Diagram format (``"mermaid"`` or ``"dot"``).
            **kwargs: Passed to the diagram renderer.

        Returns:
            Diagram markup string.

        Raises:
            ValueError: If no candidate exists for the machine.
        """
        if version:
            candidate = self._built_candidates.get_built_candidate(
                machine_name, version
            )
        else:
            candidate = self._built_candidates.get_latest_built_candidate(machine_name)
        if candidate is None:
            raise ValueError(f"No candidate found for '{machine_name}'")

        from pystator.discovery._visualization import (
            candidate_to_dot,
            candidate_to_mermaid,
        )

        if format == "mermaid":
            return candidate_to_mermaid(candidate, **kwargs)
        return candidate_to_dot(candidate, **kwargs)
