"""Discovery connection and draft naming — same character rules as FSM ``machine_name`` (lowercase, digits, underscores)."""

from __future__ import annotations

import re

DISCOVERY_SLUG_PATTERN = re.compile(r"^[a-z0-9_]+$")


def validate_discovery_slug(value: str, field: str) -> str:
    """Return stripped value or raise ValueError if it is not a valid slug."""
    s = (value or "").strip()
    if not s:
        raise ValueError(f"{field} cannot be empty")
    if not DISCOVERY_SLUG_PATTERN.fullmatch(s):
        raise ValueError(
            f"{field} must contain only lowercase letters, digits, and underscores"
        )
    return s


def validate_discovery_slug_optional(value: str | None, field: str) -> str | None:
    """Same as :func:`validate_discovery_slug` but allows None / empty → None."""
    if value is None:
        return None
    s = value.strip()
    if not s:
        return None
    return validate_discovery_slug(s, field)


def validate_discovery_namespace(value: str | None, field: str) -> str | None:
    """Normalize and validate a slash-separated path of discovery slugs; empty → None."""
    if value is None:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    collapsed = "/".join(p for p in raw.replace("//", "/").split("/") if p.strip())
    if not collapsed:
        return None
    without_edges = collapsed.strip("/")
    if not without_edges:
        return None
    parts = [p.strip() for p in without_edges.split("/") if p.strip()]
    if not parts:
        return None
    validated = [
        validate_discovery_slug(p, f"{field} segment {i + 1}")
        for i, p in enumerate(parts)
    ]
    return "/".join(validated)
