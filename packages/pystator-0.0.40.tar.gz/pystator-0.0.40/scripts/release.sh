#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────
# release.sh — Stage, commit, push, merge, tag, and release.
#
# Run from the repository root.
#
# Usage:
#   ./scripts/release.sh commit        # git add + commit on current branch
#   ./scripts/release.sh push          # commit + push current branch
#   ./scripts/release.sh merge-dev     # push + merge current branch → develop
#   ./scripts/release.sh merge-main    # push develop + open/merge PR develop → main (needs: gh)
#   ./scripts/release.sh tag           # tag main with next patch version
#   ./scripts/release.sh release       # all of the above end-to-end
#
# The commit message is generated automatically from staged changes.
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

DEVELOP="develop"
MAIN="main"
REMOTE="origin"

# ─────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────

die()  { echo "ERROR: $*" >&2; exit 1; }
info() { echo "  → $*"; }

next_patch_tag() {
    local latest
    latest=$(git tag --sort=-v:refname | head -1)
    if [[ -z "$latest" ]]; then
        echo "v0.0.1"; return
    fi
    local major minor patch
    IFS='.' read -r major minor patch <<< "${latest#v}"
    echo "v${major}.${minor}.$((patch + 1))"
}

current_branch() {
    git branch --show-current
}

# GitHub owner/repo from origin (ssh or https URL).
github_owner_repo() {
    local url
    url=$(git remote get-url "$REMOTE" 2>/dev/null || true)
    [[ -n "$url" ]] || return 1
    url="${url%.git}"
    if [[ "$url" =~ github\.com[:/]([^/]+)/(.+)$ ]]; then
        echo "${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
        return 0
    fi
    return 1
}

# Latest conclusion for .github/workflows/test.yml on main (prefer gh; else GitHub REST API).
ci_conclusion_main_test_workflow() {
    if command -v gh &>/dev/null; then
        gh run list --branch=main --workflow=test.yml --limit=1 --json conclusion --jq '.[0].conclusion' 2>/dev/null || echo "unknown"
        return
    fi
    local owner_repo api json status
    owner_repo=$(github_owner_repo) || {
        echo "unknown"
        return
    }
    if ! command -v curl &>/dev/null; then
        echo "unknown"
        return
    fi
    api="https://api.github.com/repos/${owner_repo}/actions/workflows/test.yml/runs?branch=main&per_page=1"
    local curl_args=(
        -sS
        -H "Accept: application/vnd.github+json"
        -H "User-Agent: optophi-release.sh"
    )
    if [[ -n "${GITHUB_TOKEN:-}" ]]; then
        curl_args+=(-H "Authorization: Bearer ${GITHUB_TOKEN}")
    elif [[ -n "${GH_TOKEN:-}" ]]; then
        curl_args+=(-H "Authorization: Bearer ${GH_TOKEN}")
    fi
    json=$(curl "${curl_args[@]}" "$api" 2>/dev/null) || {
        echo "unknown"
        return
    }
    if command -v jq &>/dev/null; then
        status=$(printf '%s' "$json" | jq -r '(.workflow_runs[0].conclusion) // "unknown"')
    else
        status=$(printf '%s' "$json" | python3 -c 'import json,sys
try:
    d = json.load(sys.stdin)
    r = d.get("workflow_runs") or []
    c = r[0].get("conclusion") if r else None
    print(c if c else "unknown")
except Exception:
    print("unknown")') || status="unknown"
    fi
    echo "$status"
}

has_changes() {
    [[ -n "$(git status --porcelain)" ]]
}

# Build a conventional commit message from the changed files.
generate_commit_message() {
    local added modified deleted
    added=$(git diff --cached --name-only --diff-filter=A | wc -l)
    modified=$(git diff --cached --name-only --diff-filter=M | wc -l)
    deleted=$(git diff --cached --name-only --diff-filter=D | wc -l)

    # Detect the dominant type of change from file paths
    local files
    files=$(git diff --cached --name-only)

    local type="chore"
    local scope=""
    local desc=""

    if echo "$files" | grep -qE "^(src|lib)/"; then
        # Source code changes
        if echo "$files" | grep -qE "test"; then
            type="test"
            desc="update tests"
        elif echo "$files" | grep -qE "\.github/|cliff\.toml|\.pre-commit"; then
            type="ci"
            desc="update CI and release automation"
        elif echo "$files" | grep -qE "docs/|README|CONTRIBUTING|CHANGELOG|SECURITY"; then
            type="docs"
            desc="update documentation"
        elif [[ $added -gt 0 && $modified -eq 0 ]]; then
            type="feat"
            desc="add new functionality"
        elif [[ $deleted -gt 0 && $added -eq 0 ]]; then
            type="refactor"
            desc="remove unused code"
        else
            type="feat"
            desc="update package"
        fi
    elif echo "$files" | grep -qE "\.github/|cliff\.toml|\.pre-commit|pyproject"; then
        type="ci"
        desc="update CI and release automation"
    elif echo "$files" | grep -qE "docs/|README|CONTRIBUTING|CHANGELOG|SECURITY"; then
        type="docs"
        desc="update documentation"
    else
        type="chore"
        desc="update repository files"
    fi

    # Summarize file changes
    local summary=""
    local file_count
    file_count=$(echo "$files" | wc -l)
    if [[ $file_count -le 3 ]]; then
        summary=$(echo "$files" | tr '\n' ', ' | sed 's/,$//')
        desc="update ${summary}"
    fi

    echo "${type}: ${desc}"
}

# ─────────────────────────────────────────────────────────────────
# Commands
# ─────────────────────────────────────────────────────────────────

cmd_commit() {
    echo ""
    echo "── Commit ──"

    if ! has_changes; then
        info "Working tree clean, nothing to commit."
        return 0
    fi

    git add -A
    local msg
    msg=$(generate_commit_message)
    info "Message: ${msg}"
    git commit -m "$msg"
    info "Committed."
}

cmd_push() {
    cmd_commit

    local branch
    branch=$(current_branch)
    echo ""
    echo "── Push ${branch} ──"

    git push "$REMOTE" "$branch"
    info "Pushed to ${REMOTE}/${branch}."
}

cmd_merge_dev() {
    local branch
    branch=$(current_branch)

    # If not on develop, push current branch then merge into develop
    if [[ "$branch" == "$DEVELOP" ]]; then
        cmd_push
        return 0
    fi

    cmd_push

    echo ""
    echo "── Merge ${branch} → ${DEVELOP} ──"

    git checkout "$DEVELOP"
    git pull "$REMOTE" "$DEVELOP" --rebase 2>/dev/null || true
    git merge "$branch" --no-edit
    git push "$REMOTE" "$DEVELOP"
    info "Merged ${branch} → ${DEVELOP} and pushed."

    git checkout "$branch"
}

# Merge develop → main via GitHub PR (required when main is protected: "PR before merge").
cmd_merge_main() {
    cmd_merge_dev

    echo ""
    echo "── Merge ${DEVELOP} → ${MAIN} (GitHub pull request) ──"

    if ! command -v gh &>/dev/null; then
        die "Merging into protected ${MAIN} needs GitHub CLI. Install: https://cli.github.com/ then run: gh auth login"
    fi
    if ! gh auth status &>/dev/null; then
        die "GitHub CLI is not logged in. Run: gh auth login"
    fi

    local gh_repo
    gh_repo=$(github_owner_repo) || die "Could not parse owner/repo from git remote \"${REMOTE}\". Use a github.com URL (HTTPS or git@github.com:ORG/REPO.git)."
    export GH_REPO="$gh_repo"
    info "GitHub repo for gh: ${gh_repo}"
    if ! gh repo view "$gh_repo" &>/dev/null; then
        die "GitHub CLI cannot access \"${gh_repo}\" (GraphQL: repository not found). Fix: (1) git remote -v — if the repo moved, run: git remote set-url origin git@github.com:OWNER/REPO.git (2) gh auth login — use an account with access to that repo (3) For GitHub Enterprise, set GH_HOST and use the enterprise hostname in origin."
    fi

    git fetch "$REMOTE" "$DEVELOP" "$MAIN"

    local ahead
    ahead=$(git rev-list --count "${REMOTE}/${MAIN}..${REMOTE}/${DEVELOP}" 2>/dev/null || echo "0")
    if [[ "$ahead" -eq 0 ]]; then
        info "No commits on ${REMOTE}/${DEVELOP} that are not already in ${REMOTE}/${MAIN}; nothing to merge."
        return 0
    fi

    git push "$REMOTE" "$DEVELOP"
    info "Pushed ${REMOTE}/${DEVELOP}."

    local pr_num
    pr_num=$(gh pr list --base "$MAIN" --head "$DEVELOP" --state open --json number --jq '.[0].number // empty')
    if [[ -z "$pr_num" ]]; then
        info "Opening pull request ${DEVELOP} → ${MAIN}..."
        gh pr create --base "$MAIN" --head "$DEVELOP" \
            --title "chore: merge ${DEVELOP} into ${MAIN}" \
            --body "Automated merge from \`scripts/release.sh merge-main\` (or \`release\`)."
        pr_num=$(gh pr list --base "$MAIN" --head "$DEVELOP" --state open --json number --jq '.[0].number // empty')
        [[ -n "$pr_num" ]] || die "Failed to create or find PR ${DEVELOP} → ${MAIN}."
    else
        info "Using existing open PR #${pr_num}."
    fi

    # --auto: merge when required checks pass (no need to click Merge in the browser).
    info "Requesting merge for PR #${pr_num} (auto-merge when checks pass)..."
    if ! gh pr merge "$pr_num" --merge --auto 2>/dev/null; then
        info "Auto-merge not available (e.g. already mergeable). Trying immediate merge..."
        gh pr merge "$pr_num" --merge || die "PR #${pr_num} could not be merged. Fix checks/reviews or merge manually: gh pr view ${pr_num} --web"
    fi

    info "Waiting until PR #${pr_num} is merged..."
    local waited=0
    local max_wait=${RELEASE_PR_WAIT_SECONDS:-3600}
    while true; do
        local state
        state=$(gh pr view "$pr_num" --json state --jq '.state' 2>/dev/null || echo "UNKNOWN")
        if [[ "$state" == "MERGED" ]]; then
            info "Merged ${DEVELOP} → ${MAIN} on GitHub."
            break
        fi
        if [[ "$state" != "OPEN" ]]; then
            die "PR #${pr_num} is ${state}; expected MERGED or OPEN."
        fi
        if [[ "$waited" -ge "$max_wait" ]]; then
            die "Timed out after ${max_wait}s waiting for PR #${pr_num}. If reviews are required, approve on GitHub or widen bypass rules. Check: gh pr view ${pr_num}"
        fi
        sleep 5
        waited=$((waited + 5))
    done

    git fetch "$REMOTE" "$MAIN"
}

cmd_tag() {
    echo ""
    echo "── Tag ──"

    # Latest CI on main: gh if installed, else curl + api.github.com (use GITHUB_TOKEN or GH_TOKEN for private repos)
    info "Checking CI status on main..."
    local status
    status=$(ci_conclusion_main_test_workflow)
    if [[ "$status" == "failure" ]]; then
        die "CI is failing on main. Fix tests before tagging."
    elif [[ "$status" == "success" ]]; then
        info "CI passed on main."
    else
        info "CI status: ${status} (proceeding anyway)"
    fi

    local branch
    branch=$(current_branch)

    git checkout "$MAIN"
    git pull "$REMOTE" "$MAIN" --rebase 2>/dev/null || true

    local tag
    tag=$(next_patch_tag)
    info "Creating tag: ${tag}"

    git tag "$tag"
    git push "$REMOTE" "$tag"
    info "Pushed ${tag}. CI will now:"
    info "  • Run tests"
    info "  • Generate changelog via git-cliff"
    info "  • Create GitHub Release"
    info "  • Publish to PyPI"

    git checkout "$branch"
}

cmd_release() {
    echo "═══════════════════════════════════════"
    echo "  Full release pipeline"
    echo "═══════════════════════════════════════"

    cmd_merge_main
    cmd_tag

    echo ""
    echo "═══════════════════════════════════════"
    echo "  Release complete."
    echo "═══════════════════════════════════════"
}

# ─────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────

if [[ $# -eq 0 ]]; then
    echo "Usage: ./scripts/release.sh <command>"
    echo ""
    echo "Commands:"
    echo "  commit       Stage all changes and commit with auto-generated message"
    echo "  push         Commit + push current branch"
    echo "  merge-dev    Push + merge current branch → develop"
    echo "  merge-main   Push develop + PR merge develop → main (requires gh CLI)"
    echo "  tag          Create next patch tag on main and push"
    echo "  release      All of the above (full release pipeline)"
    exit 0
fi

case "$1" in
    commit)     cmd_commit ;;
    push)       cmd_push ;;
    merge-dev)  cmd_merge_dev ;;
    merge-main) cmd_merge_main ;;
    tag)        cmd_tag ;;
    release)    cmd_release ;;
    *)          die "Unknown command: $1" ;;
esac
