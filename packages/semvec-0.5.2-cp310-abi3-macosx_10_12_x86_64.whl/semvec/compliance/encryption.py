"""Per-user encryption helpers for stored embeddings (P1 #7).

The event store keeps every memory's raw embedding. A backup leak
of the SQLite file (or pgvector dump) hands the attacker a vector
they can run cosine-similarity against any text they have a
plausible candidate for — partial re-identification through
"semantic fingerprinting" without decrypting any plaintext.

This module wraps each embedding with:

1. A **per-user key**, derived via HKDF-SHA256 from the operator's
   shared seed and the ``user_id`` salt. The seed never leaves the
   operator's HSM; the per-user key is regenerated on every
   read/write so a leak of one user's key does not compromise the
   others.
2. **AES-GCM** with a fresh 12-byte nonce per write — authenticated,
   no separate MAC needed. The serialised ciphertext is
   ``nonce || ciphertext || tag`` packed as bytes.
3. The plaintext layout is the embedding packed as little-endian
   ``float32`` (cosine similarity stays well within float32 noise
   on 384..1024-d vectors). The dimension is recovered as
   ``len(plaintext) // 4`` so no separate length field is needed.

This is **opt-in** via :class:`SqliteEventStore`'s
``encryption_seed=`` kwarg — passing the operator seed flips the
store into encrypting mode. Reads / writes from the same store
instance are then transparent to the rest of the compliance pack;
:meth:`SqliteEventStore.list_by_user` returns plaintext embeddings
and the application never sees the ciphertext.
"""

from __future__ import annotations

import os
import struct
from collections.abc import Iterable

from cryptography.hazmat.primitives import hashes, hmac
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

_HKDF_INFO = b"semvec-compliance/embedding-key/v1"
_NONCE_LEN = 12  # AES-GCM standard
_TAG_LEN = 16  # AES-GCM standard


def derive_user_key(operator_seed: bytes, user_id: str) -> bytes:
    """Derive a 32-byte AES-256 key from ``operator_seed`` and ``user_id``.

    ``operator_seed`` is a tenant-wide secret (typically 32 random
    bytes from the operator's HSM); ``user_id`` salts the derivation
    so two users sharing the same seed end up with different keys
    and cosine cross-correlation across encrypted dumps yields no
    information.
    """
    if len(operator_seed) < 16:
        raise ValueError(
            "operator_seed must be at least 16 bytes; " f"got {len(operator_seed)} bytes"
        )
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=user_id.encode("utf-8"),
        info=_HKDF_INFO,
    )
    return hkdf.derive(operator_seed)


def encrypt_embedding(emb: Iterable[float], key: bytes) -> bytes:
    """Encrypt the embedding vector, returning ``nonce || ct || tag``.

    Plaintext layout is ``float32[len(emb)]`` little-endian. The
    nonce is freshly random for every call — never reused under the
    same key (AES-GCM requires it).
    """
    if len(key) != 32:
        raise ValueError(f"AES-256 key must be 32 bytes; got {len(key)}")
    coords = list(emb)
    plaintext = struct.pack(f"<{len(coords)}f", *coords)
    nonce = os.urandom(_NONCE_LEN)
    aead = AESGCM(key)
    ct_and_tag = aead.encrypt(nonce, plaintext, associated_data=None)
    return nonce + ct_and_tag


def decrypt_embedding(blob: bytes, key: bytes) -> list[float]:
    """Inverse of :func:`encrypt_embedding`. Raises ``InvalidTag``
    on tampered ciphertext / wrong key — propagate to the caller."""
    if len(key) != 32:
        raise ValueError(f"AES-256 key must be 32 bytes; got {len(key)}")
    if len(blob) < _NONCE_LEN + _TAG_LEN:
        raise ValueError("ciphertext blob too short")
    nonce, ct = blob[:_NONCE_LEN], blob[_NONCE_LEN:]
    aead = AESGCM(key)
    plaintext = aead.decrypt(nonce, ct, associated_data=None)
    n = len(plaintext) // 4
    if n * 4 != len(plaintext):
        raise ValueError(
            "decrypted plaintext length not a multiple of 4 " "(corrupted float32 stream)"
        )
    return list(struct.unpack(f"<{n}f", plaintext))


def hash_embedding(emb: Iterable[float], key: bytes) -> bytes:
    """HMAC-SHA256 fingerprint of the embedding under the per-user
    key. Used by indexing layers (e.g. dedup, fast lookup) that
    need a stable per-write identifier without decrypting the
    ciphertext. Constant-time vs the verifier's key."""
    if len(key) != 32:
        raise ValueError(f"key must be 32 bytes; got {len(key)}")
    coords = list(emb)
    h = hmac.HMAC(key, hashes.SHA256())
    h.update(struct.pack(f"<{len(coords)}f", *coords))
    return h.finalize()


__all__ = [
    "derive_user_key",
    "encrypt_embedding",
    "decrypt_embedding",
    "hash_embedding",
]
