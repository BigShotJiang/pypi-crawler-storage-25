"""Append-only event store for the compliance pack.

The event store is the *single source of truth* for everything written
into the persistent semantic state. The 3-tier memory, the EMA vector
and the literal cache are derived views that can be rebuilt at any
time by replaying the event stream.

Two backends ship with the pack:

* :class:`SqliteEventStore` — file-backed SQLite, embeddings stored
  as JSON arrays. Default for development, testing, single-process
  deployments. Cosine similarity falls back to a NumPy scan over the
  user's events.
* :class:`PostgresEventStore` — Postgres + ``pgvector`` extension,
  embeddings stored as ``vector(n)``, similarity via the ``<=>``
  operator. Right for production multi-tenant servers.

The two backends share the :class:`EventStore` ABC so consumers
(:mod:`semvec.compliance.event_replay`, REST routes, retention
sweeper) never special-case the storage layer.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from abc import ABC, abstractmethod
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import numpy as np


@dataclass(frozen=True)
class MemoryEvent:
    """One immutable change in the user's persistent state.

    Stored fields:

    * ``event_id`` — UUID4 primary key.
    * ``user_id`` — tenant identifier.
    * ``created_at`` — UTC, tz-aware.
    * ``content`` — verbatim user text.
    * ``embedding`` — numeric vector (length = state dimension).
    * ``meta`` — arbitrary JSON-safe metadata (source channel,
      checkpoint number, ...).
    * ``source_event_id`` — back-reference for derived events
      (e.g. a literal-cache fact extracted from a chat turn).
    """

    event_id: uuid.UUID
    user_id: str
    created_at: datetime
    content: str
    embedding: list[float]
    meta: dict[str, Any] = field(default_factory=dict)
    source_event_id: uuid.UUID | None = None

    @classmethod
    def fresh(
        cls,
        *,
        user_id: str,
        content: str,
        embedding: list[float],
        meta: dict[str, Any] | None = None,
        source_event_id: uuid.UUID | None = None,
    ) -> MemoryEvent:
        """Construct a ready-to-append event with a fresh UUID and
        ``created_at = now``."""
        return cls(
            event_id=uuid.uuid4(),
            user_id=user_id,
            created_at=datetime.now(timezone.utc),
            content=content,
            embedding=list(embedding),
            meta=dict(meta or {}),
            source_event_id=source_event_id,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_id": str(self.event_id),
            "user_id": self.user_id,
            "created_at": self.created_at.isoformat(),
            "content": self.content,
            "embedding": list(self.embedding),
            "meta": dict(self.meta),
            "source_event_id": (str(self.source_event_id) if self.source_event_id else None),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemoryEvent:
        ts = data["created_at"]
        if isinstance(ts, str):
            dt = datetime.fromisoformat(ts)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
        else:
            dt = ts
        sid = data.get("source_event_id")
        return cls(
            event_id=uuid.UUID(str(data["event_id"])),
            user_id=data["user_id"],
            created_at=dt,
            content=data["content"],
            embedding=list(data["embedding"]),
            meta=dict(data.get("meta") or {}),
            source_event_id=uuid.UUID(str(sid)) if sid else None,
        )


# ---------------------------------------------------------------------------
# EventStore ABC


class EventStore(ABC):
    """Storage backend for :class:`MemoryEvent`. Implementations must
    be thread-safe — the FastAPI app may dispatch concurrent
    requests, and the replay path runs from background tasks."""

    @abstractmethod
    def init_schema(self) -> None: ...

    @abstractmethod
    def append(self, event: MemoryEvent) -> MemoryEvent: ...

    @abstractmethod
    def get(self, event_id: uuid.UUID) -> MemoryEvent | None: ...

    @abstractmethod
    def list_by_user(self, user_id: str) -> list[MemoryEvent]: ...

    @abstractmethod
    def query_by_user(
        self,
        user_id: str,
        *,
        query_embedding: list[float] | None,
        limit: int,
    ) -> list[MemoryEvent]: ...

    @abstractmethod
    def count_for_user(self, user_id: str) -> int: ...

    @abstractmethod
    def delete(self, event_id: uuid.UUID) -> bool: ...

    @abstractmethod
    def delete_by_user(self, user_id: str) -> int: ...

    @abstractmethod
    def delete_older_than(self, user_id: str, cutoff: datetime) -> int: ...


# ---------------------------------------------------------------------------
# SQLite backend


class SqliteEventStore(EventStore):
    """File-backed SQLite event store.

    Embeddings serialise as JSON arrays — fine up to a few million
    events on a single machine. For production multi-tenant deploys
    use :class:`PostgresEventStore`.
    """

    def __init__(
        self,
        path: str = ":memory:",
        *,
        encryption_seed: bytes | None = None,
    ) -> None:
        """``encryption_seed`` (P1 #7, opt-in) — when supplied, every
        embedding is wrapped with AES-GCM under a per-user key
        derived from the seed via HKDF-SHA256. The plaintext stored
        on disk is then a binary ciphertext blob (base64-armoured for
        the SQLite TEXT column) instead of a JSON float array. The
        seed never leaves the process; reads / writes from the same
        store instance are transparent to the rest of the compliance
        pack.

        ``encryption_seed=None`` (default) → embeddings stored as
        cleartext JSON arrays — bit-identical to pre-0.5.0 behaviour
        for back-compat. Switching an existing store between
        encrypted and unencrypted modes is unsupported; pick one at
        provisioning time.
        """
        self._path = path
        # ``check_same_thread=False`` lets FastAPI dispatch from worker
        # threads safely; we serialise inside ``_connect`` via a
        # short-lived connection per operation when the store is
        # file-backed.
        self._connect_kwargs = {"check_same_thread": False}
        # ``:memory:`` databases are tied to a single connection — the
        # naive per-operation approach would land ``init_schema()`` and
        # ``append()`` in disjoint ephemeral DBs. We keep one connection
        # alive for the store's lifetime and serialise access with a
        # lock so concurrent FastAPI workers don't corrupt the DB.
        self._is_memory = path == ":memory:"
        self._memory_conn: sqlite3.Connection | None = None
        self._memory_lock = threading.Lock() if self._is_memory else None
        if self._is_memory:
            self._memory_conn = sqlite3.connect(":memory:", **self._connect_kwargs)
            self._memory_conn.row_factory = sqlite3.Row
        self._encryption_seed = encryption_seed
        if encryption_seed is not None and len(encryption_seed) < 16:
            raise ValueError(
                "encryption_seed must be at least 16 bytes; " f"got {len(encryption_seed)} bytes"
            )

    @property
    def encryption_enabled(self) -> bool:
        return self._encryption_seed is not None

    def _serialise_embedding(self, user_id: str, embedding: list[float]) -> str:
        if self._encryption_seed is None:
            return json.dumps(embedding)
        from base64 import b64encode

        from semvec.compliance.encryption import (
            derive_user_key,
            encrypt_embedding,
        )

        key = derive_user_key(self._encryption_seed, user_id)
        return b64encode(encrypt_embedding(embedding, key)).decode("ascii")

    def _deserialise_embedding(self, user_id: str, raw: str) -> list[float]:
        if self._encryption_seed is None:
            return list(json.loads(raw))
        from base64 import b64decode

        from semvec.compliance.encryption import (
            decrypt_embedding,
            derive_user_key,
        )

        key = derive_user_key(self._encryption_seed, user_id)
        return decrypt_embedding(b64decode(raw), key)

    @contextmanager
    def _connect(self):
        """Yield a SQLite connection.

        For ``:memory:`` stores the same connection is reused for the
        store's lifetime, guarded by a lock so concurrent threads
        cannot interleave statements. For file-backed stores a fresh
        short-lived connection is opened per operation — same trade-off
        the SQLite docs recommend for multi-threaded CLI tooling.
        """
        if self._is_memory:
            assert self._memory_conn is not None
            assert self._memory_lock is not None
            with self._memory_lock:
                yield self._memory_conn
                self._memory_conn.commit()
            return
        conn = sqlite3.connect(self._path, **self._connect_kwargs)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def init_schema(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS memory_events (
                    event_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    content TEXT NOT NULL,
                    embedding TEXT NOT NULL,
                    meta TEXT NOT NULL,
                    source_event_id TEXT
                )
                """
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_events_user "
                "ON memory_events (user_id, created_at)"
            )

    def append(self, event: MemoryEvent) -> MemoryEvent:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO memory_events "
                "(event_id, user_id, created_at, content, embedding, "
                "meta, source_event_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    str(event.event_id),
                    event.user_id,
                    event.created_at.isoformat(),
                    event.content,
                    self._serialise_embedding(event.user_id, event.embedding),
                    json.dumps(event.meta),
                    str(event.source_event_id) if event.source_event_id else None,
                ),
            )
        return event

    def _row_to_event(self, row: sqlite3.Row) -> MemoryEvent:
        return MemoryEvent(
            event_id=uuid.UUID(row["event_id"]),
            user_id=row["user_id"],
            created_at=datetime.fromisoformat(row["created_at"]),
            content=row["content"],
            embedding=self._deserialise_embedding(row["user_id"], row["embedding"]),
            meta=json.loads(row["meta"]),
            source_event_id=(uuid.UUID(row["source_event_id"]) if row["source_event_id"] else None),
        )

    def get(self, event_id: uuid.UUID) -> MemoryEvent | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM memory_events WHERE event_id = ?",
                (str(event_id),),
            ).fetchone()
        return self._row_to_event(row) if row else None

    def list_by_user(self, user_id: str) -> list[MemoryEvent]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM memory_events " "WHERE user_id = ? ORDER BY created_at ASC",
                (user_id,),
            ).fetchall()
        return [self._row_to_event(r) for r in rows]

    def query_by_user(
        self,
        user_id: str,
        *,
        query_embedding: list[float] | None,
        limit: int,
    ) -> list[MemoryEvent]:
        events = self.list_by_user(user_id)
        if query_embedding is None:
            # Most-recent first when no similarity target is given.
            return list(reversed(events))[:limit]
        q = np.asarray(query_embedding, dtype=np.float64)
        qn = float(np.linalg.norm(q))
        if qn < 1e-12:
            return events[:limit]
        scored: list[tuple[float, MemoryEvent]] = []
        for ev in events:
            v = np.asarray(ev.embedding, dtype=np.float64)
            vn = float(np.linalg.norm(v))
            if vn < 1e-12:
                continue
            cos = float(np.dot(q, v) / (qn * vn))
            scored.append((cos, ev))
        scored.sort(key=lambda t: t[0], reverse=True)
        return [ev for _, ev in scored[:limit]]

    def count_for_user(self, user_id: str) -> int:
        with self._connect() as conn:
            (n,) = conn.execute(
                "SELECT COUNT(*) FROM memory_events WHERE user_id = ?",
                (user_id,),
            ).fetchone()
        return int(n)

    def delete(self, event_id: uuid.UUID) -> bool:
        with self._connect() as conn:
            cur = conn.execute(
                "DELETE FROM memory_events WHERE event_id = ?",
                (str(event_id),),
            )
            return cur.rowcount > 0

    def delete_by_user(self, user_id: str) -> int:
        with self._connect() as conn:
            cur = conn.execute(
                "DELETE FROM memory_events WHERE user_id = ?",
                (user_id,),
            )
            return int(cur.rowcount)

    def delete_older_than(self, user_id: str, cutoff: datetime) -> int:
        with self._connect() as conn:
            cur = conn.execute(
                "DELETE FROM memory_events " "WHERE user_id = ? AND created_at < ?",
                (user_id, cutoff.isoformat()),
            )
            return int(cur.rowcount)


__all__ = [
    "EventStore",
    "MemoryEvent",
    "SqliteEventStore",
]
