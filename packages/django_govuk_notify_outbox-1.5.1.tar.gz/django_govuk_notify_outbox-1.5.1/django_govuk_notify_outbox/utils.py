import traceback
from datetime import timedelta
from functools import partial
from typing import Any, Callable, Optional

from django.db import transaction
from django.utils.timezone import now
from notifications_python_client.errors import HTTPError

from . import settings
from .models import EmailMessage, EmailMessageEvent, Message
from .tasks import send_email


def send_email_notification(
    email_address: str,
    template_id: str,
    personalisation: Optional[dict[str, Any]] = None,
    reference: Optional[str] = None,
    email_reply_to_id: Optional[str] = None,
    one_click_unsubscribe_url: Optional[str] = None,
) -> EmailMessage:
    email_message = EmailMessage.objects.create(
        email_address=email_address,
        template_id=template_id,
        personalisation=personalisation,
        reference=reference,
        email_reply_to_id=email_reply_to_id,
        one_click_unsubscribe_url=one_click_unsubscribe_url,
        send_to_notify_retry_intervals=settings.DJANGO_GOVUK_NOTIFY_OUTBOX__SEND_TO_NOTIFY_RETRY_INTERVALS,
        send_to_notify_abandon_after=now(
        ) + timedelta(seconds=settings.DJANGO_GOVUK_NOTIFY_OUTBOX__SEND_TO_NOTIFY_ABANDON_AFTER)
    )
    email_message.events.create(type=EmailMessageEvent.TYPE_CREATE)
    transaction.on_commit(partial(send_email.delay, email_message.id))
    return email_message
