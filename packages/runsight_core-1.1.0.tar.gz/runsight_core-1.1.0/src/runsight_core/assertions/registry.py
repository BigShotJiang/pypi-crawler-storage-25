"""Plugin registry, not- prefix handling, and assertion dispatchers."""

from __future__ import annotations

import asyncio
import json
from typing import Any

from jsonpath_ng import parse as jp_parse

from runsight_core.assertions.base import AssertionContext, GradingResult
from runsight_core.assertions.scoring import AssertionsResult

_REGISTRY: dict[str, type] = {}

NOT_PREFIX = "not-"


def register_assertion(type_str: str, handler: type) -> None:
    """Register an assertion handler class by type string."""
    _REGISTRY[type_str] = handler


def _get_handler(type_str: str) -> type:
    """Look up a handler by type string. Raises KeyError if not found."""
    if type_str not in _REGISTRY:
        raise KeyError(f"Unknown assertion type: {type_str!r}")
    return _REGISTRY[type_str]


def _apply_transform(transform: str, output: str) -> str | GradingResult:
    """Apply a transform to the output before assertion evaluation.

    Returns the transformed string on success, or a failing GradingResult on error.
    """
    if ":" not in transform:
        return GradingResult(
            passed=False,
            score=0.0,
            reason=f"Unknown transform format: {transform!r}",
            assertion_type="transform",
        )

    kind, path = transform.split(":", 1)

    if kind != "json_path":
        return GradingResult(
            passed=False,
            score=0.0,
            reason=f"Unknown transform type: {kind!r}",
            assertion_type="transform",
        )

    try:
        data = json.loads(output)
    except (json.JSONDecodeError, ValueError):
        return GradingResult(
            passed=False,
            score=0.0,
            reason="Transform json_path failed: output is not valid JSON",
            assertion_type="transform",
        )

    expr = jp_parse(path)
    matches = expr.find(data)
    if not matches:
        return GradingResult(
            passed=False,
            score=0.0,
            reason=f"Transform json_path: path {path!r} not found in output",
            assertion_type="transform",
        )

    extracted = matches[0].value
    return str(extracted) if not isinstance(extracted, str) else extracted


def run_assertion(
    *,
    type: str,
    output: str,
    context: AssertionContext,
    value: Any = "",
    threshold: float | None = None,
    weight: float = 1.0,
    metric: str | None = None,
    transform: str | None = None,
) -> GradingResult:
    """Dispatch a single assertion by type string and return its GradingResult."""
    if transform is not None:
        transformed = _apply_transform(transform, output)
        if isinstance(transformed, GradingResult):
            return transformed
        output = transformed

    negated = type.startswith(NOT_PREFIX)
    base_type = type[len(NOT_PREFIX) :] if negated else type

    handler_cls = _get_handler(base_type)
    try:
        handler = handler_cls(value=value)
    except TypeError:
        handler = handler_cls()
    result = handler.evaluate(output, context)

    if negated:
        return GradingResult(
            passed=not result.passed,
            score=1.0 - result.score,
            reason=result.reason,
            named_scores=result.named_scores,
            tokens_used=result.tokens_used,
            component_results=result.component_results,
            assertion_type=result.assertion_type,
            metadata=result.metadata,
        )

    return result


async def run_assertions(
    config: list[dict[str, Any]],
    *,
    output: str,
    context: AssertionContext,
    max_concurrent: int = 10,
) -> AssertionsResult:
    """Run a list of assertion configs concurrently and return aggregated results."""
    agg = AssertionsResult()

    if not config:
        return agg

    semaphore = asyncio.Semaphore(max_concurrent)

    async def _run_one(cfg: dict[str, Any]) -> tuple[GradingResult, float]:
        async with semaphore:
            weight = cfg.get("weight", 1.0)
            result = run_assertion(
                type=cfg["type"],
                output=output,
                context=context,
                value=cfg.get("value", ""),
                threshold=cfg.get("threshold"),
                weight=weight,
                metric=cfg.get("metric"),
                transform=cfg.get("transform"),
            )
            if cfg.get("metric"):
                result.named_scores[cfg["metric"]] = result.score
            return result, weight

    tasks = [_run_one(cfg) for cfg in config]
    completed = await asyncio.gather(*tasks)

    for result, weight in completed:
        agg.add_result(result, weight=weight)

    return agg
