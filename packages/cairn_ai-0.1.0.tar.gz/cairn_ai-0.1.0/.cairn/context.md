# Cairn context — multi-module — 2026-03-15

_Auto-generated from runtime signal. Do not edit manually._

# cairn

## distill (17 records) [distill]

- PATTERN error in test_backtest.py (414 occurrences)  _(conf: 1.00)_
- PASS tests/test_tier_features.py::TestNewRules::test_print_statement_rule  _(conf: 1.00)_
- PASS tests/test_tier_features.py::TestNewRules::test_magic_number_rule  _(conf: 1.00)_
- PASS tests/test_tier_features.py::TestGitBlame::test_blame_records_returns_empty_for_non_git  _(conf: 1.00)_
- PASS tests/test_tier_features.py::TestAnnotateClear::test_clear_dry_run_shows_diff  _(conf: 1.00)_
- _…and 12 more_

## distill (1 record) [distill]

- PATTERN AssertionError in test_new_features.py (1 occurrence)  _(conf: 1.00)_

# inject

## distill (1 record) [distill]

- PATTERN broad_except in pytest_plugin.py (31 occurrences)  _(conf: 1.00)_

# scripts

## distill (1 record) [distill]

- PATTERN print_statement in prime_from_oss.py (52 occurrences)  _(conf: 1.00)_
