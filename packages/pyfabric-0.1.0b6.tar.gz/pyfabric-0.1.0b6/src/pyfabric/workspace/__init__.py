"""Fabric workspace management operations."""
