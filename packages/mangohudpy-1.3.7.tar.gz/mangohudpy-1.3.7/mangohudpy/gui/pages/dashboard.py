"""Dashboard page: per-game StatCards with newest session stats."""
from __future__ import annotations
import argparse
import platform
import re as _re
from pathlib import Path
from typing import Any, Dict, Optional

from PySide6.QtCore import Qt, QThreadPool
from PySide6.QtWidgets import (
    QGridLayout, QGroupBox, QFormLayout, QLabel, QPushButton, QScrollArea,
    QSplitter, QVBoxLayout, QWidget,
)

from mangohudpy.constants import BENCH_LOG_DIR, MAX_LOGS_PER_GAME
from mangohudpy.utils import _fcol, discover_games, find_logs, parse_csv, pctl, sf
from mangohudpy.gui.widgets import LogViewer, StatCard
from mangohudpy.gui.worker import Worker


def _collect_system_info() -> dict:
    """Collect current machine specs using stdlib only."""
    info: dict = {}

    # CPU — model name + core count from /proc/cpuinfo
    try:
        cpu_model = ""
        core_count = 0
        for line in Path("/proc/cpuinfo").read_text().splitlines():
            if not cpu_model and line.startswith("model name"):
                cpu_model = line.split(":", 1)[1].strip()
            if not core_count and line.startswith("cpu cores"):
                core_count = int(line.split(":", 1)[1].strip())
            if cpu_model and core_count:
                break
        info["cpu"] = f"{cpu_model} ({core_count} cores)" if core_count else cpu_model
    except Exception:
        info["cpu"] = platform.processor() or "Unknown"

    # GPU — glxinfo, fall back to drm sysfs
    try:
        import subprocess
        out = subprocess.run(
            ["glxinfo"], capture_output=True, text=True, timeout=3
        ).stdout
        for line in out.splitlines():
            if "OpenGL renderer string:" in line:
                info["gpu"] = line.split(":", 1)[1].strip()
                break
        else:
            raise ValueError("renderer not found")
    except Exception:
        try:
            for uevent in Path("/sys/class/drm").glob("*/device/uevent"):
                content = uevent.read_text()
                m = _re.search(r"PCI_ID=\w+:(\w+)", content)
                if m:
                    info["gpu"] = f"GPU {m.group(1)}"
                    break
            else:
                info["gpu"] = "Unknown"
        except Exception:
            info["gpu"] = "Unknown"

    # RAM — /proc/meminfo MemTotal in kB → GB
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemTotal:"):
                kb = int(line.split()[1])
                info["ram"] = f"{kb / 1024 / 1024:.1f} GB"
                break
        else:
            info["ram"] = "Unknown"
    except Exception:
        info["ram"] = "Unknown"

    # OS — /etc/os-release PRETTY_NAME
    try:
        for line in Path("/etc/os-release").read_text().splitlines():
            if line.startswith("PRETTY_NAME="):
                info["os"] = line.split("=", 1)[1].strip().strip('"')
                break
        else:
            info["os"] = platform.system()
    except Exception:
        info["os"] = platform.system()

    # Kernel
    info["kernel"] = platform.uname().release

    # Resolution — populated later via Qt
    info["resolution"] = ""

    return info


def _build_game_stats(csv_path: Path) -> Dict[str, Any]:
    """Return summary stats dict for a single CSV log."""
    cols, rows = parse_csv(csv_path)
    if not rows:
        return {"avg_fps": 0.0, "low1": 0.0, "jitter": 0.0, "sessions": 1}

    fk = _fcol(cols, ["fps", "FPS"])
    ftk = _fcol(cols, ["frametime", "frametime_ms", "Frametime"])
    fps_vals = sorted([sf(r.get(fk, "0")) for r in rows]) if fk else []
    ft_vals = sorted([sf(r.get(ftk, "0")) for r in rows]) if ftk else []

    avg_fps = sum(fps_vals) / len(fps_vals) if fps_vals else 0.0
    low1 = pctl(fps_vals, 1) if fps_vals else 0.0
    jitter = (pctl(ft_vals, 99) - pctl(ft_vals, 1)) if ft_vals else 0.0

    return {"avg_fps": avg_fps, "low1": low1, "jitter": jitter, "sessions": 1}


class DashboardPage(QWidget):
    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        splitter = QSplitter(Qt.Orientation.Vertical)
        outer.addWidget(splitter)

        # ── top pane: header + stat cards ────────────────────────────
        top = QWidget()
        layout = QVBoxLayout(top)

        hdr = QWidget()
        hdr_layout = QVBoxLayout(hdr)
        hdr_layout.setContentsMargins(0, 0, 0, 0)
        hdr_layout.addWidget(QLabel("<h2>Dashboard</h2>"))
        self.organize_btn = QPushButton("Organize Now")
        self.organize_btn.clicked.connect(self._run_organize)
        hdr_layout.addWidget(self.organize_btn)
        layout.addWidget(hdr)

        # ── system info panel ─────────────────────────────────────────
        sys_group = QGroupBox("System Information")
        sys_group.setCheckable(True)
        sys_group.setChecked(True)
        sys_layout = QFormLayout(sys_group)
        sys_layout.setContentsMargins(8, 4, 8, 4)
        sys_layout.setSpacing(2)
        sys_layout.setHorizontalSpacing(32)

        self._resolution_label = QLabel("—")
        self._sys_labels: dict[str, QLabel] = {}
        for field, key in [
            ("OS",         "os"),
            ("Kernel",     "kernel"),
            ("CPU",        "cpu"),
            ("GPU",        "gpu"),
            ("RAM",        "ram"),
            ("Resolution", "resolution"),
        ]:
            if key == "resolution":
                val_label = self._resolution_label
            else:
                val_label = QLabel("Loading\u2026")
                self._sys_labels[key] = val_label
            val_label.setTextInteractionFlags(
                Qt.TextInteractionFlag.TextSelectableByMouse
            )
            sys_layout.addRow(QLabel(f"<b>{field}:</b>"), val_label)
        layout.addWidget(sys_group)
        self._load_system_info()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self._cards_widget = QWidget()
        self._cards_layout = QGridLayout(self._cards_widget)
        self._cards_layout.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        scroll.setWidget(self._cards_widget)
        layout.addWidget(scroll, stretch=1)

        splitter.addWidget(top)

        # ── bottom pane: log output ───────────────────────────────────
        self.log = LogViewer()
        splitter.addWidget(self.log)

        splitter.setSizes([520, 200])
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 1)

        self._current_game = ""
        self.refresh()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        if self._resolution_label.text() in ("—", ""):
            from PySide6.QtGui import QGuiApplication
            screen = QGuiApplication.primaryScreen()
            if screen:
                sz = screen.size()
                self._resolution_label.setText(f"{sz.width()}×{sz.height()}")

    def on_game_selected(self, game: str) -> None:
        self._current_game = game
        self.refresh()

    def refresh(self) -> None:
        while self._cards_layout.count():
            item = self._cards_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        games = [self._current_game] if self._current_game else discover_games()
        col_count = 3
        added = 0
        for game in games:
            logs = find_logs(game=game)
            if not logs:
                continue
            newest = max(logs, key=lambda p: p.stat().st_mtime)
            stats = _build_game_stats(newest)
            stats["sessions"] = len(logs)
            card = StatCard(game)
            card.set_stats(**stats)
            self._cards_layout.addWidget(card, added // col_count, added % col_count)
            added += 1

        if added == 0:
            self._cards_layout.addWidget(
                QLabel("No games found. Play a game with MangoHud, then click Organize Now."),
                0, 0,
            )

    def _load_system_info(self) -> None:
        """Load system info in a background thread to avoid blocking the UI."""
        _result: list[dict] = []

        def _collect() -> None:
            _result.append(_collect_system_info())

        def _on_done() -> None:
            if _result:
                info = _result[0]
                for key, label in self._sys_labels.items():
                    label.setText(info.get(key, "—") or "—")
                # Resolution is set via showEvent using Qt screen info

        self._sys_info_worker = Worker(_collect)
        self._sys_info_worker.signals.finished.connect(
            _on_done, Qt.ConnectionType.QueuedConnection
        )
        QThreadPool.globalInstance().start(self._sys_info_worker)

    def _run_organize(self) -> None:
        from mangohudpy.organize import cmd_organize
        args = argparse.Namespace(
            source=None,
            dest=str(BENCH_LOG_DIR),
            max_logs=MAX_LOGS_PER_GAME,
            dry_run=False,
        )
        self.organize_btn.setEnabled(False)
        self.log.clear_log()
        worker = Worker(cmd_organize, args)
        worker.signals.output.connect(self.log.append_line)
        worker.signals.error.connect(self.log.append_line)
        worker.signals.finished.connect(self._organize_done)
        QThreadPool.globalInstance().start(worker)

    def _organize_done(self) -> None:
        self.organize_btn.setEnabled(True)
        self.refresh()
