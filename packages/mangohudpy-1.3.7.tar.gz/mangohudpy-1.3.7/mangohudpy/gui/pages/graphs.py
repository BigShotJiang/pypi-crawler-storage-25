"""Graphs page: FlightlessSomething-style tabbed inline charts."""
from __future__ import annotations
from pathlib import Path
from typing import List, Optional, Tuple

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QButtonGroup, QComboBox, QFileDialog, QGridLayout, QHBoxLayout,
    QHeaderView, QLabel, QListWidget, QListWidgetItem, QMessageBox, QPushButton,
    QRadioButton, QScrollArea, QSizePolicy, QSplitter, QTabWidget,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from mangohudpy.gui.widgets import LogViewer
from mangohudpy.utils import _extract_game_name, _fcol, find_logs, parse_csv, pctl, sf

_RUN_COLORS = [
    "#7cb5ec", "#f7a35c", "#90ed7d", "#f15c80",
    "#e4d354", "#8085e9", "#2b908f", "#f45b5b",
]

# (attr_name, display_label, unit, more_is_better)
_METRIC_DEFS = [
    ("cpu_load",       "CPU Load",       "%",   True),
    ("gpu_load",       "GPU Load",       "%",   True),
    ("cpu_temp",       "CPU Temp",       "°C",  False),
    ("gpu_temp",       "GPU Temp",       "°C",  False),
    ("cpu_power",      "CPU Power",      "W",   False),
    ("gpu_power",      "GPU Power",      "W",   False),
    ("ram",            "RAM",            "MB",  False),
    ("vram",           "VRAM",           "MB",  False),
    ("gpu_core_clock", "GPU Core Clock", "MHz", True),
    ("gpu_mem_clock",  "GPU Mem Clock",  "MHz", True),
    ("swap",           "Swap",           "MB",  False),
]
_BG   = "#212529"
_TEXT = "#e0e0e0"
_GRID = "#3a3a3a"


# ── matplotlib helpers ─────────────────────────────────────────────────

def _mpl_available() -> bool:
    try:
        import matplotlib  # noqa: F401
        return True
    except ImportError:
        return False


def _style_ax(ax, fig, title: str, xlabel: str = "", ylabel: str = "") -> None:
    fig.patch.set_facecolor(_BG)
    ax.set_facecolor(_BG)
    ax.set_title(title, color=_TEXT, fontsize=11, fontweight="bold", pad=6)
    ax.set_xlabel(xlabel, color=_TEXT, fontsize=9)
    ax.set_ylabel(ylabel, color=_TEXT, fontsize=9)
    ax.tick_params(colors=_TEXT, labelsize=8)
    ax.grid(True, color=_GRID, linewidth=0.5)
    for spine in ax.spines.values():
        spine.set_color(_GRID)


class _MplCanvas:
    """Wraps a matplotlib Figure + FigureCanvasQTAgg + NavigationToolbar."""

    def __init__(self, fig_w: float = 8.0, fig_h: float = 3.5, dpi: int = 96):
        from matplotlib.backends.backend_qtagg import (
            FigureCanvasQTAgg, NavigationToolbar2QT,
        )
        from matplotlib.figure import Figure

        self.fig = Figure(figsize=(fig_w, fig_h), dpi=dpi,
                          facecolor=_BG, tight_layout=True)

        # Subclass inline so wheel events propagate to the scroll area
        class _Canvas(FigureCanvasQTAgg):
            def wheelEvent(self_, event):
                event.ignore()

        self.canvas = _Canvas(self.fig)
        self.canvas.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed
        )
        self.canvas.setMinimumHeight(int(fig_h * dpi))

        self.toolbar = NavigationToolbar2QT(self.canvas, None)
        self.toolbar.setStyleSheet(
            "QToolBar { background: #2d2d2d; border: none; spacing: 2px; }"
            "QToolButton { color: #e0e0e0; background: transparent; }"
            "QToolButton:hover { background: #3a3a3a; }"
        )

    def widget(self) -> QWidget:
        """Return a QWidget containing toolbar + canvas."""
        w = QWidget()
        w.setStyleSheet("background: #212529;")
        vbox = QVBoxLayout(w)
        vbox.setContentsMargins(0, 0, 0, 0)
        vbox.setSpacing(0)
        vbox.addWidget(self.toolbar)
        vbox.addWidget(self.canvas)
        self._container = w
        return w

    def setVisible(self, visible: bool) -> None:
        """Show or hide the container widget (toolbar + canvas)."""
        if hasattr(self, "_container"):
            self._container.setVisible(visible)

    def draw(self):
        self.canvas.draw_idle()


# ── scroll area that always handles wheel events ───────────────────────

class _WheelScrollArea(QScrollArea):
    def wheelEvent(self, event):
        dy = event.angleDelta().y()
        self.verticalScrollBar().setValue(
            self.verticalScrollBar().value() - dy // 3
        )
        event.accept()


def _scrollable(widget: QWidget) -> _WheelScrollArea:
    sa = _WheelScrollArea()
    sa.setWidget(widget)
    sa.setWidgetResizable(True)
    sa.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    sa.setStyleSheet("QScrollArea { border: none; background: #212529; }")
    return sa


# ── run data ───────────────────────────────────────────────────────────

class _RunData:
    def __init__(self, path: Path):
        self.path  = path
        self.label = path.stem
        cols, rows = parse_csv(path)
        self.rows  = rows

        def _v(cands):
            k = _fcol(cols, cands)
            return [sf(r.get(k, "0")) for r in rows] if k else []

        self.fps           = _v(["fps", "FPS"])
        self.frametime     = _v(["frametime", "frametime_ms", "Frametime"])
        self.cpu_temp      = _v(["cpu_temp",  "CPU_Temp"])
        self.gpu_temp      = _v(["gpu_temp",  "GPU_Temp"])
        self.cpu_power     = _v(["cpu_power", "CPU_Power"])
        self.gpu_power     = _v(["gpu_power", "GPU_Power"])
        self.ram           = _v(["ram",  "RAM"])
        self.vram          = _v(["vram", "VRAM"])
        self.cpu_load      = _v(["cpu_load", "CPULoad", "cpu load"])
        self.gpu_load      = _v(["gpu_load", "GPULoad", "gpu load"])
        self.gpu_core_clock = _v(["gpu_core_clock", "GPU_CoreClock", "core_clock"])
        self.gpu_mem_clock  = _v(["gpu_mem_clock",  "GPU_MemClock",  "mem_clock"])
        self.swap           = _v(["swap", "Swap"])

        self._downsample(2000)
        self._parse_spec(path)

    def _downsample(self, max_pts: int) -> None:
        """Stride-sample all series to at most max_pts points."""
        all_series = [
            getattr(self, a) for a in (
                "fps", "frametime", "cpu_temp", "gpu_temp", "cpu_power",
                "gpu_power", "ram", "vram", "cpu_load", "gpu_load",
                "gpu_core_clock", "gpu_mem_clock", "swap",
            )
        ]
        n = max((len(s) for s in all_series if s), default=0)
        if n <= max_pts:
            return
        stride = max(1, (n + max_pts - 1) // max_pts)
        for attr in ("fps", "frametime", "cpu_temp", "gpu_temp", "cpu_power",
                     "gpu_power", "ram", "vram", "cpu_load", "gpu_load",
                     "gpu_core_clock", "gpu_mem_clock", "swap"):
            setattr(self, attr, getattr(self, attr)[::stride])

    def _parse_spec(self, path: Path) -> None:
        """Populate spec_* attributes from MangoHud CSV line 1."""
        _defaults = {
            "spec_os": "—", "spec_cpu": "—", "spec_gpu": "—",
            "spec_ram": "—", "spec_kernel": "—", "spec_scheduler": "—",
        }
        try:
            import re as _re
            raw = path.read_text(encoding="utf-8", errors="replace").splitlines()
            lines = [s for s in raw if s.strip()]
            lines = [ln for ln in lines
                     if not _re.match(r"^v\d", ln.strip())
                     and not _re.match(r"^-{3}", ln.strip())]
            if len(lines) < 2:
                for k, v in _defaults.items():
                    setattr(self, k, v)
                return
            _SPEC = {"os", "cpu", "gpu", "ram", "kernel", "driver", "cpuscheduler"}
            keys = [k.strip().lower() for k in lines[0].split(",")]
            if len(_SPEC & set(keys)) < 3:
                for k, v in _defaults.items():
                    setattr(self, k, v)
                return
            vals = [v.strip() for v in lines[1].split(",")]
            spec = dict(zip(keys, vals))
            ram_kb = float(spec.get("ram", "0") or "0")
            if ram_kb >= 1024 * 1024:
                ram_str = f"{ram_kb / 1024 / 1024:.1f} GB"
            elif ram_kb >= 1024:
                ram_str = f"{ram_kb / 1024:.0f} MB"
            else:
                ram_str = f"{int(ram_kb)} kB" if ram_kb > 0 else "—"
            self.spec_os        = spec.get("os",           "—") or "—"
            self.spec_cpu       = spec.get("cpu",          "—") or "—"
            self.spec_gpu       = spec.get("gpu",          "—") or "—"
            self.spec_ram       = ram_str
            self.spec_kernel    = spec.get("kernel",       "—") or "—"
            self.spec_scheduler = spec.get("cpuscheduler", "—") or "—"
        except Exception:
            for k, v in _defaults.items():
                setattr(self, k, v)

    def fps_stats(self) -> Optional[Tuple[float, float, float]]:
        if not self.fps:
            return None
        s = sorted(self.fps)
        return pctl(s, 1), sum(s) / len(s), pctl(s, 97)

    def fps_density(self):
        try:
            import numpy as np
        except ImportError:
            return [], []
        if not self.fps:
            return [], []
        arr = np.array(self.fps)
        counts, edges = np.histogram(arr, bins=60)
        return list((edges[:-1] + edges[1:]) / 2), list(counts.astype(float))

    def fps_stats_extended(self) -> Optional[dict]:
        """Full statistics dict for FPS. Requires numpy."""
        if not self.fps:
            return None
        try:
            import numpy as np
        except ImportError:
            return None
        arr = np.array(self.fps)
        pcts = np.percentile(arr, [1, 5, 10, 25, 50, 75, 90, 95, 97, 99])
        return {
            "p01": float(pcts[0]), "p05": float(pcts[1]),
            "p10": float(pcts[2]), "p25": float(pcts[3]),
            "avg": float(arr.mean()), "median": float(pcts[4]),
            "p75": float(pcts[5]), "p90": float(pcts[6]),
            "p95": float(pcts[7]), "p97": float(pcts[8]),
            "p99": float(pcts[9]),
            "std": float(arr.std(ddof=1)),
            "variance": float(arr.var(ddof=1)),
            "iqr": float(pcts[5] - pcts[3]),
        }

    def frametime_stats(self) -> Optional[Tuple[float, float, float]]:
        if not self.frametime:
            return None
        s = sorted(self.frametime)
        return pctl(s, 1), sum(s) / len(s), pctl(s, 97)

    def frametime_density(self):
        try:
            import numpy as np
        except ImportError:
            return [], []
        if not self.frametime:
            return [], []
        arr = np.array(self.frametime)
        counts, edges = np.histogram(arr, bins=60)
        return list((edges[:-1] + edges[1:]) / 2), list(counts.astype(float))


# ── GraphsPage ─────────────────────────────────────────────────────────

class GraphsPage(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        splitter = QSplitter(Qt.Orientation.Vertical)
        outer.addWidget(splitter)

        # ── top: controls + tabs ──────────────────────────────────────
        top = QWidget()
        layout = QVBoxLayout(top)
        layout.setContentsMargins(8, 8, 8, 4)
        layout.addWidget(QLabel("<h2>Graphs</h2>"))

        # CSV picker row
        pick_row = QHBoxLayout()
        self.log_combo = QComboBox()
        self.log_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
        self.log_combo.currentIndexChanged.connect(self._load_selected)
        pick_row.addWidget(self.log_combo, stretch=1)
        browse_btn = QPushButton("Browse…")
        browse_btn.clicked.connect(self._browse)
        pick_row.addWidget(browse_btn)
        add_btn = QPushButton("Add Run")
        add_btn.setToolTip("Overlay another CSV on all charts")
        add_btn.clicked.connect(self._add_run)
        pick_row.addWidget(add_btn)
        layout.addLayout(pick_row)

        # Loaded runs list with per-run remove
        runs_row = QHBoxLayout()
        self._runs_list = QListWidget()
        self._runs_list.setMaximumHeight(64)
        self._runs_list.setToolTip("Select a run then click Remove to delete it")
        runs_row.addWidget(self._runs_list, stretch=1)
        remove_btn = QPushButton("Delete File")
        remove_btn.clicked.connect(self._remove_selected)
        runs_row.addWidget(remove_btn)
        layout.addLayout(runs_row)

        if not _mpl_available():
            layout.addWidget(QLabel(
                "matplotlib not installed. Run: pip install matplotlib"
            ))
            splitter.addWidget(top)
            self.log = LogViewer()
            splitter.addWidget(self.log)
            self._runs: List[_RunData] = []
            return

        # Tab widget
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet(
            "QTabWidget::pane { border: 1px solid #3a3a3a; background: #212529; }"
            "QTabBar::tab { background: #2d2d2d; color: #e0e0e0; padding: 4px 12px; }"
            "QTabBar::tab:selected { background: #7cb5ec; color: #000; }"
        )
        # ── specs table (shown when ≥1 run loaded) ────────────────────
        self._specs_table = QTableWidget(6, 0)
        self._specs_table.setVerticalHeaderLabels(
            ["OS", "CPU", "GPU", "RAM", "Kernel", "Scheduler"]
        )
        self._specs_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self._specs_table.setMaximumHeight(160)
        self._specs_table.setStyleSheet(
            "QTableWidget { background: #212529; color: #e0e0e0; "
            "gridline-color: #3a3a3a; border: 1px solid #3a3a3a; }"
            "QHeaderView::section { background: #2d2d2d; color: #e0e0e0; "
            "border: 1px solid #3a3a3a; padding: 2px; }"
        )
        self._specs_table.setVisible(False)
        layout.addWidget(self._specs_table)

        # ── comparison toolbar (shown when ≥2 runs loaded) ────────────
        cmp_row = QHBoxLayout()
        cmp_row.addWidget(QLabel("Baseline:"))
        self._baseline_combo = QComboBox()
        self._baseline_combo.currentIndexChanged.connect(self._on_baseline_changed)
        cmp_row.addWidget(self._baseline_combo)
        cmp_row.addSpacing(16)
        cmp_row.addWidget(QLabel("View:"))
        self._mode_numbers = QRadioButton("Numbers")
        self._mode_diff    = QRadioButton("+/- Diff")
        self._mode_pct     = QRadioButton("% Diff")
        self._mode_numbers.setChecked(True)
        self._cmp_group = QButtonGroup(self)
        for btn in (self._mode_numbers, self._mode_diff, self._mode_pct):
            self._cmp_group.addButton(btn)
            cmp_row.addWidget(btn)
            btn.toggled.connect(self._on_mode_changed)
        cmp_row.addStretch()
        self._cmp_widget = QWidget()
        self._cmp_widget.setLayout(cmp_row)
        self._cmp_widget.setVisible(False)
        layout.addWidget(self._cmp_widget)

        layout.addWidget(self.tabs, stretch=1)
        self._build_tabs()

        splitter.addWidget(top)

        # ── bottom: log ───────────────────────────────────────────────
        self.log = LogViewer()
        splitter.addWidget(self.log)
        splitter.setSizes([600, 120])
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 1)

        self._game = ""
        self._runs: List[_RunData] = []
        self._refresh_combo()

    # ── comparison helpers ────────────────────────────────────────────

    def _cmp_mode(self) -> str:
        if self._mode_diff.isChecked():
            return "diff"
        if self._mode_pct.isChecked():
            return "pct"
        return "numbers"

    def _baseline_run(self):
        idx = self._baseline_combo.currentIndex()
        return self._runs[idx] if 0 <= idx < len(self._runs) else None

    def _on_baseline_changed(self) -> None:
        self._render_fps()
        self._render_frametime()

    def _on_mode_changed(self) -> None:
        self._render_fps()
        self._render_frametime()

    def _update_specs_table(self) -> None:
        t = self._specs_table
        t.setColumnCount(len(self._runs))
        t.setHorizontalHeaderLabels([r.label for r in self._runs])
        spec_attrs = [
            "spec_os", "spec_cpu", "spec_gpu",
            "spec_ram", "spec_kernel", "spec_scheduler",
        ]
        for col, run in enumerate(self._runs):
            for row, attr in enumerate(spec_attrs):
                val = getattr(run, attr, "—")
                item = QTableWidgetItem(val)
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                t.setItem(row, col, item)
        t.setVisible(bool(self._runs))

    # ── tab construction ──────────────────────────────────────────────

    def _build_tabs(self) -> None:
        self.tabs.clear()

        # ── Tab 1: FPS ────────────────────────────────────────────────
        self._cv_fps_line    = _MplCanvas(8, 3.2)
        self._cv_fps_bar     = _MplCanvas(8, 1.8)
        self._cv_fps_density = _MplCanvas(8, 2.2)
        fps_w = QWidget()
        fps_w.setStyleSheet("background: #212529;")
        fps_vb = QVBoxLayout(fps_w)
        fps_vb.setSpacing(6)
        fps_vb.setContentsMargins(4, 4, 4, 4)
        for cv in (self._cv_fps_line, self._cv_fps_bar, self._cv_fps_density):
            fps_vb.addWidget(cv.widget())
        fps_vb.addStretch()
        self.tabs.addTab(_scrollable(fps_w), "FPS")

        # ── Tab 2: Frametime ──────────────────────────────────────────
        self._cv_ft_line    = _MplCanvas(8, 3.2)
        self._cv_ft_bar     = _MplCanvas(8, 1.8)
        self._cv_ft_density = _MplCanvas(8, 2.2)
        ft_w = QWidget()
        ft_w.setStyleSheet("background: #212529;")
        ft_vb = QVBoxLayout(ft_w)
        ft_vb.setSpacing(6)
        ft_vb.setContentsMargins(4, 4, 4, 4)
        for cv in (self._cv_ft_line, self._cv_ft_bar, self._cv_ft_density):
            ft_vb.addWidget(cv.widget())
        ft_vb.addStretch()
        self.tabs.addTab(_scrollable(ft_w), "Frametime")

        # ── Tab 3: Summary ────────────────────────────────────────────
        self._cv_summary: dict = {}
        sum_w = QWidget()
        sum_w.setStyleSheet("background: #212529;")
        sum_vb = QVBoxLayout(sum_w)
        sum_vb.setSpacing(6)
        sum_vb.setContentsMargins(4, 4, 4, 4)
        for attr, label, unit, _ in _METRIC_DEFS:
            cv = _MplCanvas(8, 1.6)
            self._cv_summary[attr] = cv
            sum_vb.addWidget(cv.widget())
        sum_vb.addStretch()
        self.tabs.addTab(_scrollable(sum_w), "Summary")

        # ── Tab 4: All Data ───────────────────────────────────────────
        self._cv_alldata: dict = {}
        all_w = QWidget()
        all_w.setStyleSheet("background: #212529;")
        all_grid = QGridLayout(all_w)
        all_grid.setSpacing(6)
        all_grid.setContentsMargins(4, 4, 4, 4)
        for i, (attr, label, unit, _) in enumerate(_METRIC_DEFS):
            cv = _MplCanvas(4, 2.2)
            self._cv_alldata[attr] = cv
            all_grid.addWidget(cv.widget(), i // 2, i % 2)
        self.tabs.addTab(_scrollable(all_w), "All Data")

    # ── game/combo ────────────────────────────────────────────────────

    def on_game_selected(self, game: str) -> None:
        self._game = game
        self._refresh_combo()

    def _refresh_combo(self) -> None:
        from mangohudpy.constants import BENCH_LOG_DIR
        self.log_combo.blockSignals(True)
        self.log_combo.clear()

        # Always scan organized folders for current symlinks.
        # Filter to selected game if one is active; otherwise show all.
        current_resolved: set = set()
        if BENCH_LOG_DIR.is_dir():
            game_filter = self._game.lower() if self._game else None
            candidates = []
            for game_dir in BENCH_LOG_DIR.iterdir():
                if not game_dir.is_dir():
                    continue
                symlink = game_dir / f"{game_dir.name}-current-mangohud.csv"
                if not symlink.is_symlink() or not symlink.exists():
                    continue
                resolved = symlink.resolve()
                if game_filter and not resolved.stem.lower().startswith(game_filter):
                    continue
                candidates.append((symlink.stat().st_mtime, symlink.name, resolved))
            for _, sym_name, resolved in sorted(candidates, key=lambda x: x[0], reverse=True):
                self.log_combo.addItem(sym_name, userData=resolved)
                current_resolved.add(resolved)

        logs = find_logs(game=self._game or None)
        for p in sorted(logs, key=lambda p: p.stat().st_mtime, reverse=True):
            if p.resolve() in current_resolved:
                continue  # already listed via symlink
            self.log_combo.addItem(p.name, userData=p)

        self.log_combo.blockSignals(False)
        if self.log_combo.count() > 0:
            self.log_combo.setCurrentIndex(0)
            self._load_selected()

    def _browse(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Select CSV", "", "CSV Files (*.csv)"
        )
        if path:
            p = Path(path)
            self.log_combo.insertItem(0, p.name, userData=p)
            self.log_combo.setCurrentIndex(0)

    # ── loading ───────────────────────────────────────────────────────

    def _load_selected(self) -> None:
        csv_path: Optional[Path] = self.log_combo.currentData()
        if csv_path is None or not csv_path.exists():
            self.log.append_line("No valid log selected.")
            return
        self._runs.clear()
        self._runs_list.clear()
        self._do_load(csv_path)

    def _add_run(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Add CSV run", "", "CSV Files (*.csv)"
        )
        if path:
            self._do_load(Path(path))

    def _do_load(self, path: Path) -> None:
        try:
            run = _RunData(path)
            self._runs.append(run)
            item = QListWidgetItem(run.label)
            item.setForeground(
                QColor(_RUN_COLORS[(len(self._runs) - 1) % len(_RUN_COLORS)])
            )
            self._runs_list.addItem(item)
            self.log.append_line(
                f"Loaded: {path.name}  ({len(run.rows)} samples)"
            )
            self._baseline_combo.addItem(run.label)
            # Default baseline = lowest avg FPS run
            best_idx, best_avg = 0, float("inf")
            for i, r in enumerate(self._runs):
                st = r.fps_stats()
                if st and st[1] < best_avg:
                    best_avg, best_idx = st[1], i
            self._baseline_combo.blockSignals(True)
            self._baseline_combo.setCurrentIndex(best_idx)
            self._baseline_combo.blockSignals(False)
            self._specs_table.setVisible(True)
            self._cmp_widget.setVisible(len(self._runs) >= 2)
            self._render_all()
        except Exception as exc:
            self.log.append_line(f"Error: {exc}")

    def _remove_selected(self) -> None:
        row = self._runs_list.currentRow()
        if row < 0 or row >= len(self._runs):
            return
        run = self._runs[row]
        reply = QMessageBox.question(
            self, "Delete File",
            f"Permanently delete {run.path.name}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return
        deleted_path = run.path
        try:
            deleted_path.unlink()
            self.log.append_line(f"Deleted: {deleted_path.name}")
        except OSError as exc:
            self.log.append_line(f"Error deleting {deleted_path.name}: {exc}")
            return
        self._fix_current_symlink(deleted_path)
        self._runs.pop(row)
        self._runs_list.takeItem(row)
        self._baseline_combo.removeItem(row)
        self._specs_table.setVisible(bool(self._runs))
        self._cmp_widget.setVisible(len(self._runs) >= 2)
        for i in range(self._runs_list.count()):
            self._runs_list.item(i).setForeground(
                QColor(_RUN_COLORS[i % len(_RUN_COLORS)])
            )
        # Block signals so _refresh_combo doesn't trigger spurious _load_selected calls
        self.log_combo.blockSignals(True)
        self._refresh_combo()
        self.log_combo.blockSignals(False)
        if not self._runs and self.log_combo.count() > 0:
            # Auto-select the next available file in the combo
            self.log_combo.setCurrentIndex(0)
            self._load_selected()
        else:
            self._render_all()

    def _fix_current_symlink(self, deleted_path: Path) -> None:
        """Relink the game's current-run symlink if it now points to the deleted file.

        Organized game folders contain a ``{game}-current-mangohud.csv`` symlink
        that tracks the newest log.  Deleting the target leaves a broken link;
        this method repoints it at the next-newest real CSV (or removes it if
        none remain).
        """
        parent = deleted_path.parent
        symlink = parent / f"{parent.name}-current-mangohud.csv"
        # is_symlink() is True even for broken links; exists() is False when broken
        if not symlink.is_symlink() or symlink.exists():
            return
        csvs = sorted(
            [p for p in parent.glob("*.csv")
             if not p.name.endswith("-current-mangohud.csv")
             and not p.name.endswith("_summary.csv")
             and p.name != "current.csv"
             and not p.is_symlink()],
            key=lambda p: p.stat().st_mtime,
        )
        symlink.unlink()
        if csvs:
            symlink.symlink_to(csvs[-1].name)
            self.log.append_line(f"Relinked: {symlink.name} -> {csvs[-1].name}")
        else:
            self.log.append_line(f"Removed stale symlink: {symlink.name} (no logs remain)")

    # ── rendering ─────────────────────────────────────────────────────

    def _render_all(self) -> None:
        if not _mpl_available():
            return
        self._render_fps()
        self._render_frametime()
        self._render_summary()
        self._render_alldata()
        self._update_specs_table()

    def _render_fps(self) -> None:
        mode     = self._cmp_mode()
        baseline = self._baseline_run()
        b_stats  = baseline.fps_stats() if baseline else None

        # ── line chart ────────────────────────────────────────────────
        fig = self._cv_fps_line.fig
        fig.clear()
        ax = fig.add_subplot(111)
        _style_ax(ax, fig, "FPS over Time", "Sample", "FPS")
        _add_subtitle(ax, "More is better")
        for i, run in enumerate(self._runs):
            if not run.fps:
                continue
            c = _RUN_COLORS[i % len(_RUN_COLORS)]
            x = list(range(len(run.fps)))
            ax.plot(x, run.fps, color=c, lw=1.0)
            ax.fill_between(x, run.fps, alpha=0.15, color=c)
        if self._runs:
            _bottom_legend(ax, self._runs, _RUN_COLORS)
        self._cv_fps_line.draw()

        # ── bar chart (comparison-aware) ──────────────────────────────
        fig2 = self._cv_fps_bar.fig
        fig2.clear()
        ax2 = fig2.add_subplot(111)
        sfx = {"numbers": "", "diff": " (+/- vs baseline)", "pct": " (% vs baseline)"}[mode]
        _style_ax(ax2, fig2, f"Min / Avg / Max FPS{sfx}", "FPS", "")
        _add_subtitle(ax2, "More is better")
        bar_h = 0.22
        for i, run in enumerate(self._runs):
            stats = run.fps_stats()
            if not stats:
                continue
            p1, avg, p97 = stats
            if mode != "numbers" and b_stats:
                bp1, bavg, bp97 = b_stats
                p1  = _calc_diff(p1,  bp1,  mode)
                avg = _calc_diff(avg, bavg, mode)
                p97 = _calc_diff(p97, bp97, mode)
            y = i * (bar_h * 3 + 0.12)
            for val, offset, pos_col in [
                (p97, y,            "#2ecc71"),
                (avg, y + bar_h,    "#3498db"),
                (p1,  y + bar_h*2,  "#2ecc71"),
            ]:
                color = pos_col if val >= 0 else "#e74c3c"
                ax2.barh(offset, val, height=bar_h, color=color)
                fmt = f"{val:+.1f}" if mode != "numbers" else f"{val:.1f}"
                nudge = max(abs(val) * 0.01, 0.5) * (1 if val >= 0 else -1)
                ax2.text(val + nudge, offset + bar_h / 2, fmt,
                         va="center", ha="left" if val >= 0 else "right",
                         color=_TEXT, fontsize=8)
        ax2.set_yticks([])
        if mode != "numbers" and b_stats:
            ax2.axvline(0, color=_TEXT, linewidth=0.8, linestyle="--", alpha=0.5)
        if self._runs:
            from matplotlib.lines import Line2D
            from matplotlib.patches import Patch
            run_handles = [
                Line2D([0], [0], color=_RUN_COLORS[i % len(_RUN_COLORS)], lw=2, label=r.label)
                for i, r in enumerate(self._runs)
            ]
            metric_handles = [
                Patch(color="#2ecc71", label="97th"),
                Patch(color="#3498db", label="Avg"),
                Patch(color="#2ecc71", label="1%"),
            ]
            ax2.legend(
                handles=run_handles + metric_handles,
                loc="upper center",
                bbox_to_anchor=(0.5, -0.18),
                ncol=max(1, min(4, len(self._runs) + len(metric_handles))),
                facecolor=_BG, edgecolor=_GRID,
                labelcolor=_TEXT, fontsize=8, framealpha=0.8,
            )
        self._cv_fps_bar.draw()

        # ── density chart ─────────────────────────────────────────────
        fig3 = self._cv_fps_density.fig
        fig3.clear()
        ax3 = fig3.add_subplot(111)
        _style_ax(ax3, fig3, "FPS Density", "FPS", "Count")
        _add_subtitle(ax3, "More is better")
        for i, run in enumerate(self._runs):
            centres, counts = run.fps_density()
            if not centres:
                continue
            c = _RUN_COLORS[i % len(_RUN_COLORS)]
            ax3.plot(centres, counts, color=c, lw=1.2)
            ax3.fill_between(centres, counts, alpha=0.3, color=c)
        if self._runs:
            _bottom_legend(ax3, self._runs, _RUN_COLORS)
        self._cv_fps_density.draw()

    def _render_frametime(self) -> None:
        mode     = self._cmp_mode()
        baseline = self._baseline_run()
        b_stats  = baseline.frametime_stats() if baseline else None

        # ── line chart ────────────────────────────────────────────────
        fig = self._cv_ft_line.fig
        fig.clear()
        ax = fig.add_subplot(111)
        _style_ax(ax, fig, "Frametime over Time", "Sample", "ms")
        _add_subtitle(ax, "Less is better")
        for i, run in enumerate(self._runs):
            if not run.frametime:
                continue
            c = _RUN_COLORS[i % len(_RUN_COLORS)]
            x = list(range(len(run.frametime)))
            ax.plot(x, run.frametime, color=c, lw=1.0)
            ax.fill_between(x, run.frametime, alpha=0.15, color=c)
        if self._runs:
            _bottom_legend(ax, self._runs, _RUN_COLORS)
        self._cv_ft_line.draw()

        # ── bar chart (comparison-aware) ──────────────────────────────
        fig2 = self._cv_ft_bar.fig
        fig2.clear()
        ax2 = fig2.add_subplot(111)
        sfx = {"numbers": "", "diff": " (+/- vs baseline)", "pct": " (% vs baseline)"}[mode]
        _style_ax(ax2, fig2, f"Min / Avg / Max Frametime{sfx}", "ms", "")
        _add_subtitle(ax2, "Less is better")
        bar_h = 0.22
        for i, run in enumerate(self._runs):
            stats = run.frametime_stats()
            if not stats:
                continue
            p1, avg, p97 = stats
            if mode != "numbers" and b_stats:
                bp1, bavg, bp97 = b_stats
                p1  = _calc_diff(p1,  bp1,  mode)
                avg = _calc_diff(avg, bavg, mode)
                p97 = _calc_diff(p97, bp97, mode)
            y = i * (bar_h * 3 + 0.12)
            for val, offset, pos_col in [
                (p1,  y,            "#2ecc71"),
                (avg, y + bar_h,    "#3498db"),
                (p97, y + bar_h*2,  "#e74c3c"),
            ]:
                if mode != "numbers":
                    color = "#2ecc71" if val <= 0 else "#e74c3c"  # for frametime, negative=better=green
                else:
                    color = pos_col
                ax2.barh(offset, val, height=bar_h, color=color)
                fmt = f"{val:+.1f}" if mode != "numbers" else f"{val:.1f}"
                nudge = max(abs(val) * 0.01, 0.1) * (1 if val >= 0 else -1)
                ax2.text(val + nudge, offset + bar_h / 2, fmt,
                         va="center", ha="left" if val >= 0 else "right",
                         color=_TEXT, fontsize=8)
        ax2.set_yticks([])
        if mode != "numbers" and b_stats:
            ax2.axvline(0, color=_TEXT, linewidth=0.8, linestyle="--", alpha=0.5)
        if self._runs:
            from matplotlib.lines import Line2D
            from matplotlib.patches import Patch
            run_handles = [
                Line2D([0], [0], color=_RUN_COLORS[i % len(_RUN_COLORS)], lw=2, label=r.label)
                for i, r in enumerate(self._runs)
            ]
            metric_handles = [
                Patch(color="#2ecc71", label="1%"),
                Patch(color="#3498db", label="Avg"),
                Patch(color="#e74c3c", label="97th"),
            ]
            ax2.legend(
                handles=run_handles + metric_handles,
                loc="upper center",
                bbox_to_anchor=(0.5, -0.18),
                ncol=max(1, min(4, len(self._runs) + len(metric_handles))),
                facecolor=_BG, edgecolor=_GRID,
                labelcolor=_TEXT, fontsize=8, framealpha=0.8,
            )
        self._cv_ft_bar.draw()

        # ── density chart ─────────────────────────────────────────────
        fig3 = self._cv_ft_density.fig
        fig3.clear()
        ax3 = fig3.add_subplot(111)
        _style_ax(ax3, fig3, "Frametime Density", "ms", "Count")
        _add_subtitle(ax3, "Less is better")
        for i, run in enumerate(self._runs):
            centres, counts = run.frametime_density()
            if not centres:
                continue
            c = _RUN_COLORS[i % len(_RUN_COLORS)]
            ax3.plot(centres, counts, color=c, lw=1.2)
            ax3.fill_between(centres, counts, alpha=0.3, color=c)
        if self._runs:
            _bottom_legend(ax3, self._runs, _RUN_COLORS)
        self._cv_ft_density.draw()

    def _render_summary(self) -> None:
        """Summary tab: avg bar chart per metric."""
        for attr, label, unit, more_is_better in _METRIC_DEFS:
            cv = self._cv_summary[attr]
            fig = cv.fig
            fig.clear()
            ax = fig.add_subplot(111)
            subtitle = "More is better" if more_is_better else "Less is better"
            _style_ax(ax, fig, f"{label} Average", unit, "")
            _add_subtitle(ax, subtitle)
            bar_h = 0.4
            has = False
            for i, run in enumerate(self._runs):
                vals = getattr(run, attr)
                if not vals or not any(v > 0 for v in vals):
                    continue
                avg = sum(vals) / len(vals)
                c = _RUN_COLORS[i % len(_RUN_COLORS)]
                ax.barh(i * (bar_h + 0.1), avg, height=bar_h, color=c)
                ax.text(avg + avg * 0.01, i * (bar_h + 0.1) + bar_h / 2,
                        f"{avg:.1f}", va="center", color=_TEXT, fontsize=8)
                has = True
            ax.set_yticks([])
            if has:
                _bottom_legend(ax, self._runs, _RUN_COLORS)
            cv.draw()

    def _render_alldata(self) -> None:
        """All Data tab: line chart per metric in 2-col grid."""
        for attr, label, unit, more_is_better in _METRIC_DEFS:
            cv = self._cv_alldata[attr]
            fig = cv.fig
            fig.clear()
            ax = fig.add_subplot(111)
            subtitle = "More is better" if more_is_better else "Less is better"
            _style_ax(ax, fig, label, "Sample", unit)
            _add_subtitle(ax, subtitle)
            has = False
            for i, run in enumerate(self._runs):
                vals = getattr(run, attr)
                if not vals or not any(v > 0 for v in vals):
                    continue
                c = _RUN_COLORS[i % len(_RUN_COLORS)]
                ax.plot(range(len(vals)), vals, color=c, lw=0.8)
                has = True
            if has:
                _bottom_legend(ax, self._runs, _RUN_COLORS)
            cv.draw()
            cv.setVisible(has)


# ── legend helper — always below the axes ─────────────────────────────

def _bottom_legend(ax, runs: list, colors: list) -> None:
    """Add a colour-coded legend below the axes, one entry per run."""
    from matplotlib.lines import Line2D
    handles = [
        Line2D([0], [0], color=colors[i % len(colors)], lw=2, label=r.label)
        for i, r in enumerate(runs)
    ]
    ax.legend(
        handles=handles,
        loc="upper center",
        bbox_to_anchor=(0.5, -0.18),
        ncol=max(1, min(4, len(runs))),
        facecolor=_BG,
        edgecolor=_GRID,
        labelcolor=_TEXT,
        fontsize=8,
        framealpha=0.8,
    )


def _add_subtitle(ax, text: str) -> None:
    """Dimmed 'More/Less is better' annotation below chart title."""
    ax.annotate(
        text, xy=(0.5, 1.02), xycoords="axes fraction",
        ha="center", va="bottom", fontsize=7,
        color="#888888", style="italic",
    )


def _calc_diff(value: float, baseline: float, mode: str) -> float:
    """Comparison value based on mode: 'numbers', 'diff', or 'pct'."""
    if mode == "numbers":
        return value
    if mode == "diff":
        return value - baseline
    if mode == "pct":
        return ((value - baseline) / baseline * 100) if baseline != 0 else 0.0
    return value
