from pydantic import BaseModel, Field
from typing import Annotated


class TranscribeParameter(BaseModel):
    audio: Annotated[bytes, Field(..., description="Audio")]
    filename: Annotated[str, Field(..., description="File name")]
