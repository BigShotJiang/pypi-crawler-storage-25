from ..dtos.soap import (
    StrictSOAPDTO,
    SOAPDTOMixin,
)
from ..mixins.transcription import Transcript
from ...common.mixins import Notes


class TranscriptionSchema(
    Notes[str],
    SOAPDTOMixin[StrictSOAPDTO],
    Transcript[str],
):
    pass
