"""Internal constants — not part of the public API."""

from typing import List
import httpx

DEFAULT_TIMEOUT = httpx.Timeout(300.0, connect=10.0)
DEFAULT_STREAM_TIMEOUT = httpx.Timeout(connect=10.0, read=None, write=60.0, pool=60.0)
DEFAULT_BASE_URL = "https://weirdpablo--rooster-api.modal.run"
_API_KEY_HEADER = "X-API-Key"

AVAILABLE_MODELS: List[str] = [
    "1984-m0-brute",
    "1984-m0-sm",
    "1984-m1-unified",
    "1984-m2-light",
    "1984-m2-preview",
    "1984-m3-0317",
    "1984-m3-0404",
    "1984-m3-0421",
    "1984-m3-0424",
    "1984-c0-0427",
]
