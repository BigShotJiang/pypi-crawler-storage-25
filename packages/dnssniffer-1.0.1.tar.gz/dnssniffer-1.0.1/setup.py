from setuptools import setup, find_packages

setup(
    name="dnssniffer",
    version="1.0.1",
    description="DNS Packet Sniffer with ML Detection",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'dnssniffer': ['*.txt', '*.pkl'],
    },
    install_requires=[
        "scapy",
        "numpy",
        "scikit-learn"
    ],
    entry_points={
        "console_scripts": [
            "dnssniffer=dnssniffer.dns_packet_sniff:main",
        ],
    },
)
