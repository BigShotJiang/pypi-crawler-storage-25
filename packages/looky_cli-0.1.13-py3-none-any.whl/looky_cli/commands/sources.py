from __future__ import annotations

import difflib
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import typer
import yaml
from rich.console import Console

from looky_cli.client import LookyClient, LookyClientError
from looky_cli.commands.billing import build_authenticated_client, relogin_command, require_billing_context
from looky_cli.workspace import LocalWorkspace, WorkspaceResolutionError, resolve_local_workspace

console = Console()
app = typer.Typer(help="Manage runtime source configuration.")

_SOURCES_FILE = Path("runtime") / "sources.runtime.yml"
_SOURCES_FILE_ALT = Path("runtime") / "sources.runtime.yaml"

_SENSITIVE_KEYS = {
    "password", "passwd", "secret", "token", "api_key", "api_secret",
    "private_key", "service_account_key", "service_account_json",
    "credentials_json", "credentials", "connection_string", "connection_url",
    "database_url", "db_url", "auth_token",
}
_SENSITIVE_RE = re.compile(r"^(\s*)([\w_]+)(\s*:\s*)(.+)$")
_SOURCE_ALIAS_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_MODEL_SOURCE_ALIAS_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*)\.(?:table|sql)\s*\(")


class SourceRenameError(ValueError):
    """Raised when the source alias cannot be renamed safely."""


class SourceRenameBlockedError(SourceRenameError):
    """Raised when model files still reference the alias being renamed."""

    def __init__(self, old_alias: str, references: list[str]) -> None:
        self.old_alias = old_alias
        self.references = references
        super().__init__(
            f"Cannot rename source alias '{old_alias}' because it is referenced by model files."
        )


@dataclass(frozen=True)
class RenameSourceResult:
    sources_path: Path
    introspection_renamed: bool
    introspection_from: Path
    introspection_to: Path


@app.command("list")
def sources_list() -> None:
    """Show the runtime sources currently active on the server."""
    client, workspace = _resolve()
    workspace_id = workspace.workspace_id

    with console.status(f"Fetching sources for [bold]{workspace_id}[/bold]…"):
        try:
            result = client.get(f"/api/workspaces/{workspace_id}/sources/files")
        except LookyClientError as exc:
            _handle_error(exc, workspace_id, relogin=relogin_command(workspace.root_context))

    content = result.get("content")
    if not content:
        console.print(f"[yellow]No sources configured for workspace [bold]{workspace_id}[/bold].[/yellow]")
        raise typer.Exit(0)

    console.print(f"[dim]runtime/sources.runtime.yml on [bold]{workspace_id}[/bold]:[/dim]\n")
    console.print(_redact_yaml(content))
    console.print("\n[dim]Credential values are redacted.[/dim]")


@app.command("diff")
def sources_diff(
    plain: bool = typer.Option(
        False, "--plain", help="Output raw unified diff — pipe to delta, less, etc."
    ),
) -> None:
    """Show differences between local and server runtime sources config."""
    client, workspace = _resolve()
    workspace_id = workspace.workspace_id
    root = workspace.root

    local_sources_path = root / _SOURCES_FILE
    if not local_sources_path.is_file():
        console.print(
            f"[yellow]Local [bold]{_SOURCES_FILE}[/bold] not found in [bold]{root}[/bold].[/yellow]"
        )
        raise typer.Exit(1)

    local_content = local_sources_path.read_text(encoding="utf-8")

    with console.status(f"Fetching sources for [bold]{workspace_id}[/bold]…"):
        try:
            result = client.get(f"/api/workspaces/{workspace_id}/sources/files")
        except LookyClientError as exc:
            _handle_error(exc, workspace_id, relogin=relogin_command(workspace.root_context))

    server_content = result.get("content") or ""

    if local_content == server_content:
        console.print(
            f"[green]✓ [bold]{_SOURCES_FILE}[/bold] is identical on local and server.[/green]"
        )
        raise typer.Exit(0)

    diff_lines = list(
        difflib.unified_diff(
            server_content.splitlines(keepends=True),
            local_content.splitlines(keepends=True),
            fromfile=f"server/{_SOURCES_FILE}",
            tofile=f"local/{_SOURCES_FILE}",
            lineterm="",
        )
    )

    if plain:
        import sys
        # Plain output: redact sensitive lines before piping
        sys.stdout.write("\n".join(_redact_diff_line(l) for l in diff_lines) + "\n")
        raise typer.Exit(0)

    for line in diff_lines:
        safe = _redact_diff_line(line)
        if safe.startswith("---") or safe.startswith("+++"):
            console.print(f"[bold dim]{safe}[/bold dim]")
        elif safe.startswith("@@"):
            console.print(f"[cyan]{safe}[/cyan]")
        elif safe.startswith("+"):
            console.print(f"[green]{safe}[/green]")
        elif safe.startswith("-"):
            console.print(f"[red]{safe}[/red]")
        else:
            console.print(f"[dim]{safe}[/dim]")

    console.print("\n[dim]Credential values are redacted.[/dim]")


@app.command("rename")
def sources_rename(
    old_alias: str = typer.Argument(..., help="Existing source alias to rename"),
    new_alias: str = typer.Argument(..., help="New source alias"),
) -> None:
    """Rename a local source alias safely before pushing."""
    workspace = _resolve_local_workspace()

    try:
        result = rename_local_source_alias(workspace.root, old_alias=old_alias, new_alias=new_alias)
    except SourceRenameBlockedError as exc:
        console.print(
            f"[red]Cannot rename source alias [bold]{exc.old_alias}[/bold]: it is still used in models.[/red]"
        )
        console.print("[yellow]Update these files first, then run the rename again:[/yellow]")
        for rel in exc.references:
            console.print(f"  - [bold]{rel}[/bold]")
        raise typer.Exit(1)
    except SourceRenameError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1)

    rel_sources_path = result.sources_path.relative_to(workspace.root).as_posix()
    console.print(
        f"[green]✓ Renamed source alias [bold]{old_alias}[/bold] → [bold]{new_alias}[/bold] "
        f"in [bold]{rel_sources_path}[/bold].[/green]"
    )

    if result.introspection_renamed:
        old_rel = result.introspection_from.relative_to(workspace.root).as_posix()
        new_rel = result.introspection_to.relative_to(workspace.root).as_posix()
        console.print(
            f"[green]✓ Renamed introspection file [bold]{old_rel}[/bold] → [bold]{new_rel}[/bold].[/green]"
        )
    else:
        old_rel = result.introspection_from.relative_to(workspace.root).as_posix()
        console.print(
            f"[yellow]No introspection file found at [bold]{old_rel}[/bold]; skipping introspection rename.[/yellow]"
        )

    console.print(
        "[dim]Next step: run [bold]looky push[/bold] to publish the updated source alias.[/dim]"
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _redact_yaml_line(line: str) -> str:
    """Replace the value of a sensitive YAML key with [redacted]."""
    m = _SENSITIVE_RE.match(line)
    if m and m.group(2).lower() in _SENSITIVE_KEYS:
        return f"{m.group(1)}{m.group(2)}{m.group(3)}[redacted]"
    return line


def _redact_yaml(content: str) -> str:
    return "\n".join(_redact_yaml_line(l) for l in content.splitlines())


def _redact_diff_line(line: str) -> str:
    """Redact sensitive values inside a unified-diff line (preserves +/-/space prefix)."""
    if not line:
        return line
    prefix = line[0] if line[0] in ("+", "-", " ") else ""
    body = line[1:] if prefix else line
    return prefix + _redact_yaml_line(body)


def rename_local_source_alias(root: Path, *, old_alias: str, new_alias: str) -> RenameSourceResult:
    old_alias = (old_alias or "").strip()
    new_alias = (new_alias or "").strip()

    if not _SOURCE_ALIAS_RE.match(old_alias):
        raise SourceRenameError(
            f"Invalid old alias '{old_alias}'. Aliases must match [A-Za-z_][A-Za-z0-9_]*."
        )
    if not _SOURCE_ALIAS_RE.match(new_alias):
        raise SourceRenameError(
            f"Invalid new alias '{new_alias}'. Aliases must match [A-Za-z_][A-Za-z0-9_]*."
        )
    if old_alias == new_alias:
        raise SourceRenameError("Old alias and new alias are the same; nothing to rename.")

    sources_path = _resolve_local_sources_path(root)
    data, sources = _load_sources_yaml(sources_path)

    if old_alias not in sources:
        raise SourceRenameError(
            f"Source alias '{old_alias}' was not found in {sources_path.relative_to(root).as_posix()}."
        )
    if new_alias in sources:
        raise SourceRenameError(
            f"Source alias '{new_alias}' already exists in {sources_path.relative_to(root).as_posix()}."
        )

    references = _find_model_source_alias_references(root, alias=old_alias)
    if references:
        raise SourceRenameBlockedError(old_alias=old_alias, references=references)

    introspection_dir = root / "runtime" / "introspection"
    introspection_from = introspection_dir / f"{old_alias}.json"
    introspection_to = introspection_dir / f"{new_alias}.json"
    if introspection_from.exists() and introspection_to.exists():
        raise SourceRenameError(
            f"Cannot rename introspection file: target already exists at "
            f"{introspection_to.relative_to(root).as_posix()}."
        )

    renamed_sources: dict[str, Any] = {}
    for alias, spec in sources.items():
        if alias == old_alias:
            renamed_sources[new_alias] = spec
        else:
            renamed_sources[alias] = spec
    data["sources"] = renamed_sources

    sources_path.write_text(
        yaml.safe_dump(data, sort_keys=False, allow_unicode=False),
        encoding="utf-8",
    )

    introspection_renamed = False
    if introspection_from.exists():
        introspection_from.rename(introspection_to)
        introspection_renamed = True

    return RenameSourceResult(
        sources_path=sources_path,
        introspection_renamed=introspection_renamed,
        introspection_from=introspection_from,
        introspection_to=introspection_to,
    )


def _resolve_local_sources_path(root: Path) -> Path:
    yml_path = root / _SOURCES_FILE
    yaml_path = root / _SOURCES_FILE_ALT

    has_yml = yml_path.is_file()
    has_yaml = yaml_path.is_file()

    if has_yml and has_yaml:
        raise SourceRenameError(
            "Ambiguous runtime source config: both runtime/sources.runtime.yml and "
            "runtime/sources.runtime.yaml exist. Keep only one file and retry."
        )
    if has_yml:
        return yml_path
    if has_yaml:
        return yaml_path

    raise SourceRenameError(
        "Runtime source config not found. Expected runtime/sources.runtime.yml or "
        "runtime/sources.runtime.yaml."
    )


def _load_sources_yaml(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    try:
        parsed = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise SourceRenameError(f"{path.name} is not valid YAML: {exc}") from exc
    except OSError as exc:
        raise SourceRenameError(f"Failed to read {path}: {exc}") from exc

    if parsed is None:
        parsed = {}
    if not isinstance(parsed, dict):
        raise SourceRenameError(f"{path.name} must contain a top-level YAML object.")

    sources = parsed.get("sources")
    if not isinstance(sources, dict):
        raise SourceRenameError(f"{path.name} must define 'sources' as a mapping.")

    return parsed, sources


def _find_model_source_alias_references(root: Path, *, alias: str) -> list[str]:
    models_dir = root / "content" / "models"
    if not models_dir.is_dir():
        return []

    refs: list[str] = []
    for model_file in sorted(models_dir.rglob("*.malloy")):
        try:
            text = model_file.read_text(encoding="utf-8")
        except OSError:
            continue

        aliases = set(_MODEL_SOURCE_ALIAS_RE.findall(text))
        if alias in aliases:
            refs.append(model_file.relative_to(root).as_posix())
    return refs


def _resolve_local_workspace() -> LocalWorkspace:
    try:
        return resolve_local_workspace(Path.cwd())
    except WorkspaceResolutionError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc


def _resolve() -> tuple[LookyClient, LocalWorkspace]:
    try:
        workspace = resolve_local_workspace(Path.cwd())
    except WorkspaceResolutionError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc
    client = build_authenticated_client(workspace.root_context)
    require_billing_context(
        workspace.root_context,
        client,
        expected_billing_account_id=workspace.billing_account_id,
    )

    return client, workspace


def _handle_error(exc: LookyClientError, workspace_id: str, *, relogin: str | None = None) -> None:
    if exc.status_code == 401:
        if relogin:
            console.print(f"[red]Token expired or revoked. Run [bold]{relogin}[/bold] again.[/red]")
        else:
            console.print("[red]Token expired or revoked for the linked root. Run [bold]looky login <url> <root_path>[/bold] again.[/red]")
    elif exc.status_code == 403:
        console.print(f"[red]Access denied to workspace [bold]{workspace_id}[/bold].[/red]")
    elif exc.status_code == 404:
        console.print(f"[red]Workspace [bold]{workspace_id}[/bold] not found.[/red]")
    else:
        console.print(f"[red]Error: {exc}[/red]")
    raise typer.Exit(1)
