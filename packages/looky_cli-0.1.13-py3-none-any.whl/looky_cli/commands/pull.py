from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from looky_cli.client import LookyClient, LookyClientError
from looky_cli.commands.billing import build_authenticated_client, relogin_command, require_billing_context
from looky_cli.workspace import WorkspaceResolutionError, resolve_billing_directory

console = Console()


def pull(
    workspace_slug: str = typer.Argument(..., help="Workspace slug to pull into the current billing directory"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing files without prompting"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be written without writing anything"),
) -> None:
    """Pull workspace content from the server to a local directory."""
    slug = _normalize_workspace_slug(workspace_slug)
    try:
        billing_dir = resolve_billing_directory(Path.cwd())
    except WorkspaceResolutionError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc

    workspace_id = f"{billing_dir.billing_account_id}/{slug}"
    client = build_authenticated_client(billing_dir.root_context)
    require_billing_context(
        billing_dir.root_context,
        client,
        expected_billing_account_id=billing_dir.billing_account_id,
    )

    dest = billing_dir.billing_path / slug

    with console.status(f"Fetching workspace [bold]{workspace_id}[/bold]…"):
        try:
            result = client.get(f"/api/workspaces/{workspace_id}/content/files")
        except LookyClientError as exc:
            if exc.status_code == 401:
                console.print(
                    "[red]Token expired or revoked. Run "
                    f"[bold]{relogin_command(billing_dir.root_context)}[/bold] again.[/red]"
                )
            elif exc.status_code == 403:
                console.print(f"[red]Access denied to workspace [bold]{workspace_id}[/bold].[/red]")
            elif exc.status_code == 404:
                console.print(f"[red]Workspace [bold]{workspace_id}[/bold] not found.[/red]")
            else:
                console.print(f"[red]Error: {exc}[/red]")
            raise typer.Exit(1) from exc

    files: list[dict] = result.get("files") or []
    if not files:
        console.print(f"[yellow]Workspace [bold]{workspace_id}[/bold] has no content files.[/yellow]")
        return

    if not force and not dry_run and dest.exists() and any(dest.iterdir()):
        console.print(f"[yellow]Destination [bold]{dest}[/bold] already exists and is not empty.[/yellow]")
        if not typer.confirm("Overwrite existing files?"):
            raise typer.Exit(0)

    created = 0
    updated = 0
    unchanged = 0

    rows: list[tuple[str, str, str]] = []

    backup_ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    backup_root = dest / ".bk" / backup_ts
    backed_up: list[str] = []

    for file in files:
        rel_path = str(file.get("path") or "").strip()
        content = str(file.get("content") or "")
        if not rel_path or rel_path.startswith(".bk/") or rel_path.startswith("secrets/"):
            continue

        target = (dest / rel_path).resolve()

        try:
            target.relative_to(dest.resolve())
        except ValueError:
            console.print(f"[red]Skipping unsafe path: {rel_path}[/red]")
            continue

        if dry_run:
            if target.exists():
                rows.append((rel_path, "update", "[yellow]~[/yellow]"))
            else:
                rows.append((rel_path, "create", "[green]+[/green]"))
            continue

        target.parent.mkdir(parents=True, exist_ok=True)

        if target.exists():
            existing = target.read_text(encoding="utf-8", errors="replace")
            if _hash(existing) == _hash(content):
                unchanged += 1
                rows.append((rel_path, "unchanged", "[dim]=[/dim]"))
                continue
            bk_path = backup_root / rel_path
            bk_path.parent.mkdir(parents=True, exist_ok=True)
            bk_path.write_text(existing, encoding="utf-8")
            backed_up.append(rel_path)
            target.write_text(content, encoding="utf-8")
            updated += 1
            rows.append((rel_path, "updated", "[yellow]~[/yellow]"))
        else:
            target.write_text(content, encoding="utf-8")
            created += 1
            rows.append((rel_path, "created", "[green]+[/green]"))

    _print_file_table(rows)

    if dry_run:
        console.print(f"\n[dim]Dry run — nothing written. {len(rows)} file(s) would be affected.[/dim]")
        return

    parts = []
    if created:
        parts.append(f"[green]{created} created[/green]")
    if updated:
        parts.append(f"[yellow]{updated} updated[/yellow]")
    if unchanged:
        parts.append(f"[dim]{unchanged} unchanged[/dim]")

    summary = ", ".join(parts) if parts else "nothing to do"
    console.print(f"\n[bold]{workspace_id}[/bold] pulled to [bold]{dest}[/bold] — {summary}")
    if backed_up:
        console.print(f"[dim]Backup of {len(backed_up)} overwritten file(s) saved to .bk/{backup_ts}/[/dim]")


def _normalize_workspace_slug(workspace_slug: str) -> str:
    slug = workspace_slug.strip().strip("/")
    if not slug or "/" in slug or slug in {".", ".."}:
        console.print("[red]Workspace slug must be a single path segment.[/red]")
        raise typer.Exit(1)
    return slug


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _print_file_table(rows: list[tuple[str, str, str]]) -> None:
    if not rows:
        return
    t = Table(show_header=True, header_style="bold", box=None, padding=(0, 1))
    t.add_column("", width=2, no_wrap=True)
    t.add_column("File")
    t.add_column("Status", style="dim")
    for path, status, icon in rows:
        t.add_row(icon, path, status)
    console.print(t)
