from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from looky_cli.client import LookyClient, LookyClientError
from looky_cli.commands.billing import build_authenticated_client, require_billing_context
from looky_cli.workspace import LocalWorkspace, WorkspaceResolutionError, resolve_local_workspace

console = Console()
app = typer.Typer(help="List content in a workspace.")


@app.command("visualizations")
def list_visualizations() -> None:
    """List published visualizations in a workspace."""
    client, workspace = _resolve()
    wid = workspace.workspace_id

    with console.status(f"Fetching visualizations for [bold]{wid}[/bold]…"):
        try:
            items = client.get(f"/api/workspaces/{wid}/visualizations")
        except LookyClientError as exc:
            _handle_error(exc, wid)

    if not isinstance(items, list):
        items = []

    if not items:
        console.print(f"[yellow]No published visualizations in workspace [bold]{wid}[/bold].[/yellow]")
        raise typer.Exit(0)

    t = Table(show_header=True, header_style="bold", box=None, padding=(0, 1))
    t.add_column("ID")
    t.add_column("Title")
    t.add_column("Type", style="dim")
    t.add_column("Tags", style="dim")
    t.add_column("Dashboards", justify="right", style="dim")

    for v in items:
        tags = ", ".join(v.get("tags") or [])
        dash_count = str(v.get("dashboard_refs_count") or 0)
        t.add_row(
            str(v.get("id") or ""),
            str(v.get("title") or ""),
            str(v.get("type") or ""),
            tags,
            dash_count,
        )

    console.print(t)
    console.print(f"\n[dim]{len(items)} visualization(s) in [bold]{wid}[/bold][/dim]")


@app.command("dashboards")
def list_dashboards() -> None:
    """List published dashboards in a workspace."""
    client, workspace = _resolve()
    wid = workspace.workspace_id

    with console.status(f"Fetching dashboards for [bold]{wid}[/bold]…"):
        try:
            items = client.get(f"/api/workspaces/{wid}/dashboards")
        except LookyClientError as exc:
            _handle_error(exc, wid)

    if not isinstance(items, list):
        items = []

    if not items:
        console.print(f"[yellow]No published dashboards in workspace [bold]{wid}[/bold].[/yellow]")
        raise typer.Exit(0)

    t = Table(show_header=True, header_style="bold", box=None, padding=(0, 1))
    t.add_column("ID")
    t.add_column("Title")
    t.add_column("Tags", style="dim")

    for d in items:
        tags = ", ".join(d.get("tags") or [])
        t.add_row(
            str(d.get("id") or ""),
            str(d.get("title") or ""),
            tags,
        )

    console.print(t)
    console.print(f"\n[dim]{len(items)} dashboard(s) in [bold]{wid}[/bold][/dim]")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _resolve() -> tuple[LookyClient, LocalWorkspace]:
    try:
        workspace = resolve_local_workspace(Path.cwd())
    except WorkspaceResolutionError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc

    client = build_authenticated_client(workspace.root_context)
    require_billing_context(
        workspace.root_context,
        client,
        expected_billing_account_id=workspace.billing_account_id,
    )

    return client, workspace


def _handle_error(exc: LookyClientError, workspace_id: str) -> None:
    if exc.status_code == 401:
        console.print("[red]Token expired or revoked. Run [bold]looky login[/bold] again.[/red]")
    elif exc.status_code == 403:
        console.print(f"[red]Access denied to workspace [bold]{workspace_id}[/bold].[/red]")
    elif exc.status_code == 404:
        console.print(f"[red]Workspace [bold]{workspace_id}[/bold] not found.[/red]")
    else:
        console.print(f"[red]Error: {exc}[/red]")
    raise typer.Exit(1)
