from __future__ import annotations

import hashlib
from pathlib import Path

import typer
from rich.console import Console

from looky_cli.client import LookyClient, LookyClientError
from looky_cli.commands.billing import relogin_command, require_billing_context
from looky_cli.commands.diff import _is_push_only, _push_only_labels
from looky_cli.commands.push import collect_local_files
from looky_cli.workspace import WorkspaceResolutionError, resolve_local_workspace

console = Console()


def status() -> None:
    """Show connection info and workspace sync state at a glance."""
    try:
        workspace = resolve_local_workspace(Path.cwd())
    except WorkspaceResolutionError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc
    root_context = workspace.root_context
    url = root_context.url
    token = root_context.token
    cached_user = root_context.user

    console.print()
    console.print(f"  [dim]root[/dim]       [bold]{root_context.root_path}[/bold]")
    console.print(f"  [dim]instance[/dim]   {url}")

    workspace_id = workspace.workspace_id
    if not token:
        console.print(
            "  [dim]user[/dim]       "
            "[yellow]not logged in — run "
            f"[bold]looky login {url} {root_context.root_path}[/bold][/yellow]"
        )
    else:
        user_label = _format_user(cached_user)
        console.print(f"  [dim]user[/dim]       {user_label}")
    console.print(f"  [dim]billing[/dim]    {workspace.billing_account_id}")
    console.print(f"  [dim]workspace[/dim]  [bold]{workspace_id}[/bold]  [dim]({workspace.root})[/dim]")

    if not token or not url:
        console.print("  [dim]sync[/dim]       [dim]—[/dim]")
        console.print()
        return

    client = LookyClient(url=url, token=token)
    require_billing_context(
        root_context,
        client,
        expected_billing_account_id=workspace.billing_account_id,
    )

    # -----------------------------------------------------------------------
    # Sync status — one network call, fails gracefully
    # -----------------------------------------------------------------------
    all_local = collect_local_files(workspace.root)
    push_only = [f["path"] for f in all_local if _is_push_only(f["path"])]
    local_map = {f["path"]: f["content"] for f in all_local if not _is_push_only(f["path"])}

    try:
        with console.status("  Checking sync…", spinner="dots"):
            result = client.get(f"/api/workspaces/{workspace_id}/content/files")
    except LookyClientError as exc:
        if exc.status_code == 401:
            msg = (
                "[yellow]token expired — run "
                f"[bold]{relogin_command(root_context)}[/bold][/yellow]"
            )
        elif exc.status_code == 404:
            msg = "[yellow]workspace not found on server — run [bold]looky create[/bold][/yellow]"
        else:
            msg = f"[yellow]unreachable ({exc})[/yellow]"
        console.print(f"  [dim]sync[/dim]       {msg}")
        console.print()
        return

    server_files = result.get("files") or []
    server_map = {
        str(f.get("path") or "").strip(): str(f.get("content") or "")
        for f in server_files
        if not str(f.get("path") or "").startswith(".bk/")
    }

    added = modified = deleted = unchanged = 0
    for path in sorted(set(local_map) | set(server_map)):
        in_local = path in local_map
        in_server = path in server_map
        if in_local and not in_server:
            added += 1
        elif in_server and not in_local:
            deleted += 1
        elif _hash(local_map[path]) == _hash(server_map[path]):
            unchanged += 1
        else:
            modified += 1

    if not added and not modified and not deleted:
        sync_line = f"[green]✓ up to date[/green]  [dim]({unchanged} file(s))[/dim]"
    else:
        parts = []
        if added:
            parts.append(f"[green]{added} to add[/green]")
        if modified:
            parts.append(f"[yellow]{modified} to update[/yellow]")
        if deleted:
            parts.append(f"[red]{deleted} to delete[/red]")
        if unchanged:
            parts.append(f"[dim]{unchanged} unchanged[/dim]")
        sync_line = "  ·  ".join(parts)

    console.print(f"  [dim]sync[/dim]       {sync_line}")

    if added or modified or deleted:
        console.print(
            "  [dim]           Run [bold]looky diff[/bold] to see details "
            "or [bold]looky push[/bold] to deploy.[/dim]"
        )

    if push_only:
        labels = _push_only_labels(push_only)
        console.print(
            f"  [dim]           {', '.join(labels)} not compared — push-only[/dim]"
        )

    console.print()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _format_user(user: dict) -> str:
    name = f"{user.get('first_name', '')} {user.get('last_name', '')}".strip()
    email = user.get("email", "")
    if name and email:
        return f"{name}  [dim]({email})[/dim]"
    return email or name or "[dim]unknown[/dim]"


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()
