from __future__ import annotations

import difflib
import hashlib
from pathlib import Path

import typer
from rich.console import Console

from looky_cli.client import LookyClientError
from looky_cli.commands.billing import build_authenticated_client, relogin_command, require_billing_context
from looky_cli.commands.push import collect_local_files
from looky_cli.workspace import WorkspaceResolutionError, resolve_local_workspace

# The server GET endpoint returns workspace.yml + content/ + runtime/introspection/.
# runtime/sources.runtime.yml and secrets/ remain push-only.
_PUSH_ONLY_PREFIXES = {"secrets/"}
_PUSH_ONLY_PATHS = {"runtime/sources.runtime.yml", "runtime/sources.runtime.yaml"}

console = Console()


def diff(
    no_sync: bool = typer.Option(
        False,
        "--no-sync",
        help="Ignore server-only files — mirrors push --no-sync",
    ),
    stat: bool = typer.Option(
        False,
        "--stat",
        help="Show file-level summary only, without inline diffs",
    ),
    plain: bool = typer.Option(
        False,
        "--plain",
        help="Output raw unified diff to stdout — pipe to delta, diff-so-fancy, less, etc.",
    ),
) -> None:
    """Show what would change if you ran looky push."""
    try:
        workspace = resolve_local_workspace(Path.cwd())
    except WorkspaceResolutionError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc
    root = workspace.root
    client = build_authenticated_client(workspace.root_context)
    require_billing_context(
        workspace.root_context,
        client,
        expected_billing_account_id=workspace.billing_account_id,
    )

    # -----------------------------------------------------------------------
    # Collect local and server files
    # -----------------------------------------------------------------------
    all_local = collect_local_files(root)
    push_only = [f["path"] for f in all_local if _is_push_only(f["path"])]
    local_map = {f["path"]: f["content"] for f in all_local if not _is_push_only(f["path"])}

    workspace_id = workspace.workspace_id

    with console.status(f"Fetching [bold]{workspace_id}[/bold] from server…"):
        try:
            result = client.get(f"/api/workspaces/{workspace_id}/content/files")
        except LookyClientError as exc:
            if exc.status_code == 401:
                console.print(
                    "[red]Token expired or revoked. Run "
                    f"[bold]{relogin_command(workspace.root_context)}[/bold] again.[/red]"
                )
            elif exc.status_code == 403:
                console.print(f"[red]Access denied to workspace [bold]{workspace_id}[/bold].[/red]")
            elif exc.status_code == 404:
                console.print(
                    f"[red]Workspace [bold]{workspace_id}[/bold] not found on server.[/red]\n"
                    f"Register it first from [bold]{workspace.root.parent}[/bold]: "
                    f"[bold]looky create {workspace.workspace_slug}[/bold]"
                )
            else:
                console.print(f"[red]Error: {exc}[/red]")
            raise typer.Exit(1) from exc

    server_files = result.get("files") or []
    server_map = {
        str(f.get("path") or "").strip(): str(f.get("content") or "")
        for f in server_files
        if not str(f.get("path") or "").startswith(".bk/")
    }

    # -----------------------------------------------------------------------
    # Compare
    # -----------------------------------------------------------------------
    added: list[str] = []
    deleted: list[str] = []
    modified: list[str] = []
    unchanged: list[str] = []

    for path in sorted(set(local_map) | set(server_map)):
        in_local = path in local_map
        in_server = path in server_map

        if in_local and not in_server:
            added.append(path)
        elif in_server and not in_local:
            if not no_sync:
                deleted.append(path)
        elif _hash(local_map[path]) == _hash(server_map[path]):
            unchanged.append(path)
        else:
            modified.append(path)

    if not added and not deleted and not modified:
        if not plain:
            console.print(
                f"[green]✓ [bold]{workspace_id}[/bold] is up to date — nothing would change on push.[/green]"
            )
            if push_only:
                labels = _push_only_labels(push_only)
                console.print(
                    f"[dim]{', '.join(labels)} not shown — push-only, server does not expose them for comparison.[/dim]"
                )
        raise typer.Exit(0)

    # -----------------------------------------------------------------------
    # Output — plain mode: raw unified diff to stdout, no Rich markup
    # -----------------------------------------------------------------------
    if plain:
        for path in added:
            _emit_plain_diff(path, "", local_map[path])
        for path in deleted:
            _emit_plain_diff(path, server_map[path], "")
        for path in modified:
            _emit_plain_diff(path, server_map[path], local_map[path])
        raise typer.Exit(0)

    # -----------------------------------------------------------------------
    # Output — rich mode: colored, human-readable
    # -----------------------------------------------------------------------
    for path in added:
        console.print(f"[green]+ {path}[/green]")

    for path in deleted:
        console.print(f"[red]- {path}[/red]")

    for path in modified:
        console.print(f"[yellow]~ {path}[/yellow]")
        if not stat:
            _print_inline_diff(path, server_map[path], local_map[path])

    parts = []
    if added:
        parts.append(f"[green]{len(added)} to add[/green]")
    if modified:
        parts.append(f"[yellow]{len(modified)} to update[/yellow]")
    if deleted:
        parts.append(f"[red]{len(deleted)} to delete[/red]")
    if unchanged:
        parts.append(f"[dim]{len(unchanged)} unchanged[/dim]")

    console.print(f"\n[bold]{workspace_id}[/bold] — {', '.join(parts)}")

    if push_only:
        labels = _push_only_labels(push_only)
        console.print(
            f"[dim]{', '.join(labels)} not shown — push-only, server does not expose them for comparison.[/dim]"
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _is_push_only(path: str) -> bool:
    rel = Path(path).as_posix()
    if rel in _PUSH_ONLY_PATHS:
        return True
    return any(rel.startswith(prefix) for prefix in _PUSH_ONLY_PREFIXES)


def _push_only_labels(paths: list[str]) -> list[str]:
    labels: list[str] = []
    if any(Path(p).as_posix() in _PUSH_ONLY_PATHS for p in paths):
        labels.append("runtime/sources.runtime.yml")
    if any(Path(p).as_posix().startswith("secrets/") for p in paths):
        labels.append("secrets/")
    return labels


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _emit_plain_diff(path: str, server_content: str, local_content: str) -> None:
    """Write a standard unified diff block to stdout — no Rich markup."""
    import sys
    server_lines = server_content.splitlines(keepends=True)
    local_lines = local_content.splitlines(keepends=True)
    lines = list(
        difflib.unified_diff(
            server_lines,
            local_lines,
            fromfile=f"server/{path}",
            tofile=f"local/{path}",
            lineterm="",
        )
    )
    if lines:
        sys.stdout.write("\n".join(lines) + "\n\n")


def _print_inline_diff(path: str, server_content: str, local_content: str) -> None:
    server_lines = server_content.splitlines(keepends=True)
    local_lines = local_content.splitlines(keepends=True)

    diff_lines = list(
        difflib.unified_diff(
            server_lines,
            local_lines,
            fromfile=f"server/{path}",
            tofile=f"local/{path}",
            lineterm="",
        )
    )

    if not diff_lines:
        return

    for line in diff_lines:
        if line.startswith("---") or line.startswith("+++"):
            console.print(f"[bold dim]{line}[/bold dim]")
        elif line.startswith("@@"):
            console.print(f"[cyan]{line}[/cyan]")
        elif line.startswith("+"):
            console.print(f"[green]{line}[/green]")
        elif line.startswith("-"):
            console.print(f"[red]{line}[/red]")
        else:
            console.print(f"[dim]{line}[/dim]")

    console.print()
