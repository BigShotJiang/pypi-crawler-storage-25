from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from looky_cli.client import LookyClientError
from looky_cli.commands.billing import relogin_command, require_authenticated_client, require_billing_context

console = Console()


def workspaces() -> None:
    """List workspaces available to you on the connected looky instance."""
    root_context, client = require_authenticated_client(Path.cwd(), exact_root=True)
    require_billing_context(root_context, client)

    try:
        result = client.get("/api/workspaces")
    except LookyClientError as exc:
        if exc.status_code == 401:
            console.print(
                "[red]Token expired or revoked. Run "
                f"[bold]{relogin_command(root_context)}[/bold] again.[/red]"
            )
        else:
            console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from exc

    items = result.get("workspaces") or []
    if not items:
        console.print("[dim]No workspaces found.[/dim]")
        return

    t = Table(show_header=True, header_style="bold")
    t.add_column("ID")
    t.add_column("Name")
    t.add_column("Access")
    t.add_column("Description", no_wrap=False)

    for w in items:
        access = str(w.get("access_mode") or "read")
        desc = str(w.get("description") or "")
        t.add_row(
            str(w.get("id", "")),
            str(w.get("name", "")),
            access,
            desc,
        )

    console.print(t)
