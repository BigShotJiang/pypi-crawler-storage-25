from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from looky_cli.client import LookyClient, LookyClientError
from looky_cli.commands.billing import build_authenticated_client, relogin_command, require_billing_context
from looky_cli.validator import validate, Issue
from looky_cli.workspace import WorkspaceResolutionError, resolve_local_workspace

console = Console()

PUSH_SKIP = {".venv/", "__pycache__/", ".git/", ".bk/"}
CONTENT_PREFIXES = ("content/", "workspace.yml")
SETTINGS_PREFIXES = ("runtime/", "secrets/")

# The server writes a fresh ``heartbeat_at`` every ~30s while the job is
# running. If we go this long without a bump, the job is stuck or the
# server crashed — exit the poll loop instead of hanging forever.
STALE_HEARTBEAT_SECONDS = 120


def _should_skip(rel: str) -> bool:
    parts = Path(rel).parts
    for skip in PUSH_SKIP:
        if skip.rstrip("/") in parts:
            return True
    return False


def collect_local_files(root: Path) -> list[dict[str, str]]:
    """Collect every pushable file under the workspace root, preserving
    directory traversal order. Includes ``workspace.yml``, ``content/**``,
    ``runtime/**``, ``secrets/**``. Callers filter to the push scope they
    need (content vs settings).
    """
    files: list[dict[str, str]] = []

    for candidate in [root / "workspace.yml"]:
        if candidate.is_file():
            rel = candidate.relative_to(root).as_posix()
            try:
                files.append({"path": rel, "content": candidate.read_text(encoding="utf-8")})
            except (OSError, UnicodeDecodeError):
                pass

    for collect_dir in [root / "content", root / "runtime", root / "secrets"]:
        if not collect_dir.is_dir():
            continue
        for file_path in sorted(collect_dir.rglob("*")):
            if not file_path.is_file():
                continue
            rel = file_path.relative_to(root).as_posix()
            if _should_skip(rel):
                continue
            try:
                files.append({"path": rel, "content": file_path.read_text(encoding="utf-8")})
            except (OSError, UnicodeDecodeError):
                pass

    return files


def push(
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be sent (and, for content push, run validation); don't upload"),
    no_sync: bool = typer.Option(False, "--no-sync", help="Add/update files only — do not delete server files missing locally"),
    settings: bool = typer.Option(
        False,
        "--settings",
        help="Push runtime config and secrets (runtime/** + secrets/**) instead of content. Mutually exclusive with the default content push. Use this on first-time workspace setup, or when updating connection config / credentials.",
    ),
    strict: bool = typer.Option(
        False,
        "--strict",
        help="Content push only: also validate every query against the live data source catalog (PG EXPLAIN / BQ estimateQueryCost). Catches raw-SQL function errors, GRANT/RLS, and dialect surprises the Malloy compile alone cannot see. Costs one per-viz roundtrip to the source.",
    ),
) -> None:
    """Push a local workspace to a looky instance.

    Two mutually-exclusive scopes:

    - Default (no flag): pushes authoring content — ``content/**`` and
      ``workspace.yml``. Gated by a hard server-side validate.
    - ``--settings``: pushes runtime config — ``runtime/**`` and
      ``secrets/**``. No validate (this IS how you deploy the config
      validate runs against).

    Every push is one scope or the other, never both at the same time.
    On a brand-new workspace the first call must be
    ``looky push --settings`` — the server rejects content push with
    ``settingsNotDeployed`` when there's no ``runtime/sources.runtime.yml``
    deployed yet.
    """
    try:
        workspace = resolve_local_workspace(Path.cwd())
    except WorkspaceResolutionError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc
    root = workspace.root
    scope_label = "settings" if settings else "content"
    scope_prefixes = SETTINGS_PREFIXES if settings else CONTENT_PREFIXES

    # -----------------------------------------------------------------------
    # Collect files scoped to the requested push mode
    # -----------------------------------------------------------------------
    all_files = collect_local_files(root)
    files = [
        f for f in all_files
        if any(f["path"].startswith(p) if p.endswith("/") else f["path"] == p for p in scope_prefixes)
    ]

    if not files:
        console.print(f"[yellow]No {scope_label} files to push.[/yellow]")
        raise typer.Exit(0)

    # -----------------------------------------------------------------------
    # Validation — content only. Settings push is the config deploy step
    # that validate depends on, so it cannot gate itself.
    # -----------------------------------------------------------------------
    if not settings:
        console.print(f"Validating [bold]{root.name}[/bold]…")
        local = validate(root, root_path=workspace.root_context.root_path)
        if local.errors:
            _print_issues(local.issues)
            console.print(
                f"\n[red bold]✗ {len(local.errors)} local error(s) — fix them before pushing.[/red bold]"
            )
            raise typer.Exit(1)

        remote_issues = _run_remote_validation(workspace, strict=strict)
        all_issues = list(local.issues) + remote_issues
        _print_issues(all_issues)
        error_issues = [i for i in all_issues if i.level == "error"]
        if error_issues:
            console.print(
                f"\n[red bold]✗ {len(error_issues)} error(s) — fix them before pushing.[/red bold]"
            )
            raise typer.Exit(1)
        if not all_issues:
            console.print("[green]✓ Workspace looks good.[/green]")

    if dry_run:
        _print_file_list(files)
        console.print(f"\n[dim]Dry run — {len(files)} {scope_label} file(s) would be pushed. Nothing sent.[/dim]")
        raise typer.Exit(0)

    # -----------------------------------------------------------------------
    # Push
    # -----------------------------------------------------------------------
    client = build_authenticated_client(workspace.root_context)
    require_billing_context(
        workspace.root_context,
        client,
        expected_billing_account_id=workspace.billing_account_id,
    )
    workspace_id = workspace.workspace_id
    scope_segment = "settings" if settings else "content"

    with console.status(f"Pushing {scope_label} → [bold]{workspace_id}[/bold] on {workspace.root_context.url}…"):
        try:
            result_data = client.put(
                f"/api/workspaces/{workspace_id}/{scope_segment}/files",
                json={"files": files, "sync": not no_sync},
            )
        except LookyClientError as exc:
            if exc.status_code == 401:
                console.print(
                    "[red]Token expired or revoked. Run "
                    f"[bold]{relogin_command(workspace.root_context)}[/bold] again.[/red]"
                )
            elif exc.status_code == 403:
                console.print(f"[red]Access denied to workspace [bold]{workspace_id}[/bold].[/red]")
            elif exc.status_code == 404:
                console.print(
                    f"[red]Workspace [bold]{workspace_id}[/bold] does not exist on the server.[/red]\n"
                    f"Register it first from [bold]{workspace.root.parent}[/bold]: "
                    f"[bold]looky create {workspace.workspace_slug}[/bold]"
                )
            elif exc.status_code == 409 and _has_api_error_type(exc, "settingsNotDeployed"):
                console.print(
                    f"[red]Workspace [bold]{workspace_id}[/bold] has no deployed settings yet.[/red]\n"
                    f"Deploy them first: [bold]looky push --settings[/bold]"
                )
            else:
                console.print(f"[red]Push failed: {exc}[/red]")
            raise typer.Exit(1) from exc

    created = result_data.get("created") or []
    updated = result_data.get("updated") or []
    unchanged = result_data.get("unchanged") or []
    deleted = result_data.get("deleted") or []
    backup_ref = result_data.get("backup_ref")

    _print_push_result(created, updated, unchanged, deleted)
    parts = []
    if created:
        parts.append(f"[green]{len(created)} created[/green]")
    if updated:
        parts.append(f"[yellow]{len(updated)} updated[/yellow]")
    if deleted:
        parts.append(f"[red]{len(deleted)} deleted[/red]")
    if unchanged:
        parts.append(f"[dim]{len(unchanged)} unchanged[/dim]")
    console.print(f"\n[bold]{workspace_id}[/bold] {scope_label} pushed — {', '.join(parts) or 'nothing changed'}")
    if backup_ref:
        backed_up_count = len(updated) + len(deleted)
        console.print(f"[dim]Server backup of {backed_up_count} file(s) saved to .bk/{backup_ref}/[/dim]")


def _has_api_error_type(exc: LookyClientError, type_key: str) -> bool:
    """Return True when the canonical ``{"errors":[{typeKey:ctx}]}``
    envelope's first entry has the given ``type_key``.
    """
    payload = getattr(exc, "payload", None)
    if not isinstance(payload, dict):
        return False
    errors = payload.get("errors")
    if not isinstance(errors, list) or not errors or not isinstance(errors[0], dict):
        return False
    return next(iter(errors[0]), None) == type_key


def validate_cmd(
    strict: bool = typer.Option(
        False,
        "--strict",
        help="Also validate every query against the live data source catalog (PG EXPLAIN / BQ estimateQueryCost). Catches raw-SQL function errors, GRANT/RLS, and dialect surprises the Malloy compile alone cannot see. Costs one per-viz roundtrip to the source.",
    ),
) -> None:
    """Validate a local workspace.

    Runs both layers:
      1. Local sanity checks (YAML shape, cross-refs) — fast, no network.
      2. Server-side sandbox: compiles every Malloy model, dry-runs every
         published viz against BigQuery / Postgres. Authoritative.

    Prints one combined report and exits 1 if any errors.
    """
    try:
        workspace = resolve_local_workspace(Path.cwd())
    except WorkspaceResolutionError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc
    root = workspace.root

    console.print(f"Validating [bold]{root.name}[/bold]…\n")

    # Fast local pass. If it already errors, don't bother with the remote
    # round-trip — the server would likely say the same.
    local = validate(root, root_path=workspace.root_context.root_path)
    if local.errors:
        _print_issues(local.issues)
        console.print(
            f"\n[red bold]✗ {len(local.errors)} local error(s).[/red bold]"
        )
        raise typer.Exit(1)

    # Authoritative server-side pass.
    remote_issues = _run_remote_validation(workspace, strict=strict)
    all_issues = list(local.issues) + remote_issues
    _print_issues(all_issues)

    error_count = sum(1 for i in all_issues if i.level == "error")
    warn_count = sum(1 for i in all_issues if i.level == "warning")
    if error_count:
        console.print(f"\n[red bold]✗ {error_count} error(s).[/red bold]")
        raise typer.Exit(1)
    if not all_issues:
        console.print("[green bold]✓ Workspace looks good.[/green bold]")
    elif warn_count:
        console.print(f"\n[yellow]{warn_count} warning(s).[/yellow]")
    raise typer.Exit(0)


# ---------------------------------------------------------------------------
# Remote validation helper — shared by `validate` and `push`.
# ---------------------------------------------------------------------------

def _run_remote_validation(
    workspace,
    *,
    strict: bool = False,
) -> list[Issue]:
    """Submit the local workspace content to the server's async validate
    queue, poll for terminal status, and return the issue list.

    Errors from the HTTP layer (auth, network) raise ``typer.Exit(1)``
    directly — they're not content errors.

    Crash detection is heartbeat-based: the server republishes
    ``heartbeat_at`` every ~30s while the job runs; the CLI aborts if
    two heartbeat windows go by with no bump (see
    ``STALE_HEARTBEAT_SECONDS``). No wall-clock timeout — the job takes
    as long as it takes.

    ``strict`` flows through to the server and asks the query-engine
    to also validate every query against the live data-source catalog
    (PG ``EXPLAIN`` bounded by ``statement_timeout``, BQ
    ``estimateQueryCost``). Off by default — compile-only matches what
    BigQuery workspaces already get for free.
    """
    client = build_authenticated_client(workspace.root_context)
    require_billing_context(
        workspace.root_context,
        client,
        expected_billing_account_id=workspace.billing_account_id,
    )
    # Validate only submits content scope (``content/**`` + ``workspace.yml``).
    # The server uses its own deployed ``runtime/`` + ``secrets/`` — settings
    # live behind the separate push endpoint and never ride a validate
    # payload.
    all_files = collect_local_files(workspace.root)
    files = [
        f for f in all_files
        if any(
            f["path"].startswith(p) if p.endswith("/") else f["path"] == p
            for p in CONTENT_PREFIXES
        )
    ]
    workspace_id = workspace.workspace_id

    import time
    submit_url = f"/api/workspaces/{workspace_id}/content/files/validation-jobs"
    started_at = time.monotonic()

    submit_body: dict = {"files": files}
    if strict:
        submit_body["strict"] = True

    with console.status(
        f"[dim]Submitting validate job to {workspace.root_context.url}"
        + (" [strict]" if strict else "")
        + "…[/dim]"
    ):
        try:
            submit = client.post(
                submit_url,
                json=submit_body,
                timeout=60.0,  # short — this call only queues the job
            )
        except LookyClientError as exc:
            elapsed = time.monotonic() - started_at
            if exc.status_code == 401:
                console.print(
                    "[red]Token expired or revoked. Run "
                    f"[bold]{relogin_command(workspace.root_context)}[/bold].[/red]"
                )
            elif exc.status_code == 403:
                console.print(
                    f"[red]Access denied to workspace [bold]{workspace_id}[/bold].[/red]"
                )
            elif exc.status_code == 404:
                payload = getattr(exc, "payload", None)
                type_key: str | None = None
                if isinstance(payload, dict):
                    errors = payload.get("errors")
                    if isinstance(errors, list) and errors and isinstance(errors[0], dict):
                        type_key = next(iter(errors[0]), None)
                if type_key == "workspaceNotFound":
                    console.print(
                        f"[red]Workspace [bold]{workspace_id}[/bold] does not exist on the server.[/red]\n"
                        f"Register it first: [bold]looky create {workspace.workspace_slug}[/bold]"
                    )
                else:
                    console.print(
                        f"[red]Async validate endpoint not available on {workspace.root_context.url}.[/red]\n"
                        "[yellow]The server is running an older build without async validate. "
                        "Upgrade the server, or downgrade the CLI to a pre-async version.[/yellow]"
                    )
            else:
                _print_remote_error(exc, workspace, elapsed=elapsed)
            raise typer.Exit(1) from exc

    job_id = str((submit or {}).get("job_id") or "").strip()
    submit_rid = str((submit or {}).get("request_id") or "").strip()
    if not job_id:
        console.print("[red]Server accepted the submit but did not return a job_id.[/red]")
        raise typer.Exit(1)

    status_url = f"/api/workspaces/{workspace_id}/content/files/validation-jobs/{job_id}"

    data: dict = {}
    with console.status(
        f"[dim]Validating… job {job_id[:8]} rid={submit_rid or '?'}[/dim]"
    ) as status_line:
        while True:
            elapsed = time.monotonic() - started_at

            try:
                data = client.get(status_url, timeout=10.0)
            except LookyClientError as exc:
                if exc.status_code == 404:
                    console.print(
                        f"[red]Job {job_id[:8]} disappeared from the server "
                        "(TTL expired or app restarted). Re-run to submit a fresh job.[/red]"
                    )
                    raise typer.Exit(1) from exc
                _print_remote_error(exc, workspace, elapsed=elapsed)
                raise typer.Exit(1) from exc

            status_value = str((data or {}).get("status") or "").strip()
            if status_value == "running":
                heartbeat_at = (data or {}).get("heartbeat_at")
                if isinstance(heartbeat_at, (int, float)):
                    stale_for = time.time() - float(heartbeat_at)
                    if stale_for > STALE_HEARTBEAT_SECONDS:
                        console.print(
                            f"[red]Job {job_id[:8]} heartbeat is stale "
                            f"({stale_for:.0f}s since last update — server likely crashed). "
                            f"Re-run when the server is healthy.[/red]"
                        )
                        raise typer.Exit(1)
                progress = (data or {}).get("progress") or {}
                done = progress.get("done") if isinstance(progress, dict) else None
                total = progress.get("total") if isinstance(progress, dict) else None
                if isinstance(done, int) and isinstance(total, int) and total > 0:
                    status_line.update(
                        f"[dim]Validating… {done}/{total} · job {job_id[:8]} "
                        f"({elapsed:.0f}s)[/dim]"
                    )
                else:
                    status_line.update(
                        f"[dim]Validating… job {job_id[:8]} ({elapsed:.0f}s)[/dim]"
                    )
                time.sleep(2.0)
                continue
            if status_value == "error":
                err_msg = str((data or {}).get("error") or "unknown error")
                console.print(f"[red]Validate job failed: {err_msg}[/red]")
                raise typer.Exit(1)
            if status_value == "done":
                break
            console.print(
                f"[red]Unexpected job status: {status_value!r}. Server may be inconsistent.[/red]"
            )
            raise typer.Exit(1)

    result = (data or {}).get("result") or {}
    issues: list[Issue] = []
    for item in result.get("issues") or []:
        if not isinstance(item, dict):
            continue
        issues.append(Issue(
            level=item.get("level", "error"),
            code=str(item.get("code", "MR???")),
            message=str(item.get("message", "")),
            file=item.get("file"),
            viz_id=item.get("viz_id"),
            query_ref=item.get("query_ref"),
            line=item.get("line") if isinstance(item.get("line"), int) else None,
            column=item.get("column") if isinstance(item.get("column"), int) else None,
        ))

    rid = result.get("request_id") or submit_rid
    viz_count = result.get("viz_count", 0)
    model_count = result.get("model_count", 0)
    scope_parts = []
    if model_count:
        scope_parts.append(f"{model_count} model(s)")
    if viz_count:
        scope_parts.append(f"{viz_count} visualization(s)")
    scope = " + ".join(scope_parts) if scope_parts else "no content"
    suffix = "" if issues else " · all green"
    console.print(
        f"[dim]Server validated {scope} · rid={rid}{suffix}[/dim]"
    )
    return issues


def _print_remote_error(
    exc: LookyClientError,
    workspace,
    *,
    elapsed: float,
) -> None:
    """Render a non-opaque error when a validate HTTP call fails for a
    reason other than 401/403/404. Prints status, reason, body preview,
    and request id; flags HTML-looking bodies as likely proxy error
    pages so the user knows to look upstream of Flask.
    """
    status = exc.status_code
    reason = (exc.reason_phrase or "").strip()
    rid = (exc.request_id or "").strip()
    body = (exc.body_preview or "").strip()
    message = str(exc).strip() or "unknown error"

    title = "Remote validation failed"
    if status:
        title += f" · HTTP {status}"
        if reason:
            title += f" {reason}"
    title += f" · elapsed {elapsed:.1f}s"
    console.print(f"[red bold]{title}[/red bold]")

    console.print(f"[red]{message}[/red]")
    if rid:
        console.print(f"[dim]request-id: {rid}[/dim]")

    # Heuristic: the submit / poll calls are short (≤60s each), so an
    # HTML body on a non-2xx almost always means an intermediate proxy
    # (e.g. Cloudflare edge) intercepted the request before it reached
    # Flask — usually a 502/504 page framed in HTML.
    looks_like_html = body.startswith("<") if body else False
    if looks_like_html:
        console.print(
            "\n[yellow]The response looks like a proxy error page, not Flask's output.[/yellow]\n"
            "[yellow]Likely cause: an intermediate proxy (e.g. Cloudflare edge) intercepted the request "
            "before it reached the origin. Check server logs for request-id="
            f"{rid or '(not exposed)'} to confirm whether Flask saw it.[/yellow]"
        )

    if body:
        console.print(
            f"\n[dim]Response body preview (first ~400 chars):[/dim]\n"
            f"[dim]{body[:400]}[/dim]"
        )


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------

def _print_issues(issues: list[Issue]) -> None:
    if not issues:
        return
    t = Table(show_header=True, header_style="bold", box=None, padding=(0, 1))
    t.add_column("", width=6, no_wrap=True)
    t.add_column("Code", style="dim", no_wrap=True)
    t.add_column("File", style="dim")
    t.add_column("Viz", style="dim")
    t.add_column("Loc", style="dim", no_wrap=True)
    t.add_column("Message")
    for issue in issues:
        level_str = "[red]ERROR[/red]" if issue.level == "error" else "[yellow]WARN[/yellow]"
        loc = ""
        if issue.line is not None:
            loc = f"{issue.line}"
            if issue.column is not None:
                loc = f"{issue.line}:{issue.column}"
        # Trim the server-side message: keep just the essence for the table,
        # let the developer open the file to see the caret.
        message = issue.message.splitlines()[0] if issue.message else ""
        t.add_row(
            level_str,
            issue.code,
            issue.file or "",
            issue.viz_id or "",
            loc,
            message,
        )
    console.print(t)


def _print_file_list(files: list[dict]) -> None:
    t = Table(show_header=True, header_style="bold", box=None, padding=(0, 1))
    t.add_column("File")
    t.add_column("Size", justify="right", style="dim")
    for f in files:
        size = f"{len(f.get('content', ''))} B"
        t.add_row(f["path"], size)
    console.print(t)


def _print_push_result(created: list, updated: list, unchanged: list, deleted: list | None = None) -> None:
    deleted = deleted or []
    all_files = (
        [(p, "[green]+[/green]", "created") for p in created]
        + [(p, "[yellow]~[/yellow]", "updated") for p in updated]
        + [(p, "[red]-[/red]", "deleted") for p in deleted]
        + [(p, "[dim]=[/dim]", "unchanged") for p in unchanged]
    )
    if not any([created, updated, deleted]):
        return
    t = Table(show_header=True, header_style="bold", box=None, padding=(0, 1))
    t.add_column("", width=2, no_wrap=True)
    t.add_column("File")
    t.add_column("", style="dim")
    for path, icon, status in sorted(all_files, key=lambda x: x[0]):
        t.add_row(icon, path, status)
    console.print(t)
