from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from looky_cli.client import LookyClientError
from looky_cli.commands.billing import build_authenticated_client, relogin_command, require_billing_context
from looky_cli.workspace import WorkspaceResolutionError, resolve_local_workspace

console = Console()


def rollback(
    backup_ref: Optional[str] = typer.Option(
        None,
        "--ref",
        "-r",
        help="Backup reference to restore (e.g. 20260309-143022). Omit to list available backups.",
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt"),
) -> None:
    """Restore a workspace on the server to a previous backup."""
    try:
        workspace = resolve_local_workspace(Path.cwd())
    except WorkspaceResolutionError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc
    client = build_authenticated_client(workspace.root_context)
    require_billing_context(
        workspace.root_context,
        client,
        expected_billing_account_id=workspace.billing_account_id,
    )
    workspace_id = workspace.workspace_id
    url = workspace.root_context.url

    # -----------------------------------------------------------------------
    # List backups if no ref given, or let the user pick
    # -----------------------------------------------------------------------
    if not backup_ref:
        with console.status(f"Fetching backups for [bold]{workspace_id}[/bold]…"):
            try:
                result = client.get(f"/api/workspaces/{workspace_id}/content/files/backups")
            except LookyClientError as exc:
                _handle_error(exc, workspace_id, relogin=relogin_command(workspace.root_context))

        backups: list[dict] = result.get("backups") or []
        if not backups:
            console.print(f"[yellow]No backups found for workspace [bold]{workspace_id}[/bold].[/yellow]")
            raise typer.Exit(0)

        _print_backups(backups)
        console.print(
            "\n[dim]Pass [bold]--ref <ref>[/bold] to restore a specific backup.[/dim]"
        )
        raise typer.Exit(0)

    # -----------------------------------------------------------------------
    # Restore
    # -----------------------------------------------------------------------
    if not force:
        console.print(
            f"[yellow]This will restore [bold]{workspace_id}[/bold] on [bold]{url}[/bold] "
            f"to backup [bold]{backup_ref}[/bold].[/yellow]\n"
            "[dim]Note: files created after this backup will NOT be removed.[/dim]"
        )
        if not typer.confirm("Proceed with rollback?"):
            raise typer.Exit(0)

    with console.status(f"Rolling back [bold]{workspace_id}[/bold] to [bold]{backup_ref}[/bold]…"):
        try:
            result = client.post(
                f"/api/workspaces/{workspace_id}/content/files/backups/{backup_ref}/restore",
            )
        except LookyClientError as exc:
            _handle_error(exc, workspace_id, relogin=relogin_command(workspace.root_context))

    restored: list[str] = result.get("restored") or []

    if not restored:
        console.print("[yellow]No files were restored — the backup may be empty.[/yellow]")
        raise typer.Exit(0)

    t = Table(show_header=True, header_style="bold", box=None, padding=(0, 1))
    t.add_column("", width=2)
    t.add_column("File")
    for path in restored:
        t.add_row("[cyan]↩[/cyan]", path)
    console.print(t)

    console.print(
        f"\n[bold]{workspace_id}[/bold] rolled back to [bold]{backup_ref}[/bold] "
        f"— [cyan]{len(restored)} file(s) restored[/cyan]"
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _print_backups(backups: list[dict]) -> None:
    t = Table(show_header=True, header_style="bold", box=None, padding=(0, 1))
    t.add_column("Ref", no_wrap=True)
    t.add_column("Files", justify="right", style="dim")
    t.add_column("Sample", style="dim")
    for bk in backups:
        ref = str(bk.get("ref") or "")
        files: list[str] = bk.get("files") or []
        sample = files[0] if files else ""
        suffix = f" + {len(files) - 1} more" if len(files) > 1 else ""
        t.add_row(ref, str(len(files)), f"{sample}{suffix}")
    console.print(t)


def _handle_error(exc: LookyClientError, workspace_id: str, *, relogin: str | None = None) -> None:
    if exc.status_code == 401:
        if relogin:
            console.print(f"[red]Token expired or revoked. Run [bold]{relogin}[/bold] again.[/red]")
        else:
            console.print("[red]Token expired or revoked for the linked root. Run [bold]looky login <url> <root_path>[/bold] again.[/red]")
    elif exc.status_code == 403:
        console.print(f"[red]Write access required for workspace [bold]{workspace_id}[/bold].[/red]")
    elif exc.status_code == 404:
        console.print(f"[red]{exc}[/red]")
    else:
        console.print(f"[red]Error: {exc}[/red]")
    raise typer.Exit(1)
