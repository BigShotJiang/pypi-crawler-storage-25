"""Billing account commands for the looky CLI."""
from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from looky_cli import config as cfg
from looky_cli.client import LookyClient, LookyClientError
from looky_cli.workspace import RootContext, WorkspaceResolutionError, resolve_root_context

console = Console()
app = typer.Typer(help="Manage billing account context.")


def relogin_command(root_context: RootContext) -> str:
    return f"looky login {root_context.url} {root_context.root_path}"


def require_root_context(path: Path, *, exact_root: bool) -> RootContext:
    try:
        root_context = resolve_root_context(path.resolve())
    except WorkspaceResolutionError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc

    if exact_root and root_context.current_path != root_context.root_path:
        console.print(
            f"[red]This command must be run from the linked root [bold]{root_context.root_path}[/bold].[/red]"
        )
        raise typer.Exit(1)

    return root_context


def build_authenticated_client(root_context: RootContext) -> LookyClient:
    if not root_context.token:
        console.print(
            "[red]Not logged in for the linked root "
            f"[bold]{root_context.root_path}[/bold]. Run "
            f"[bold]looky login {root_context.url} {root_context.root_path}[/bold] first.[/red]"
        )
        raise typer.Exit(1)
    return LookyClient(url=root_context.url, token=root_context.token)


def require_authenticated_client(path: Path, *, exact_root: bool) -> tuple[RootContext, LookyClient]:
    root_context = require_root_context(path, exact_root=exact_root)
    return root_context, build_authenticated_client(root_context)


def require_billing_context(
    root_context: RootContext,
    client: LookyClient,
    *,
    expected_billing_account_id: str | None = None,
) -> str:
    """
    If billing is enabled, require an active billing account.
    Prints error and raises typer.Exit(1) if not set.
    """
    try:
        client.get("/api/auth/me")
    except LookyClientError:
        pass
    bid = root_context.billing_account_id
    if not bid:
        console.print(
            "[red]No active billing account for linked root "
            f"[bold]{root_context.root_path}[/bold]. Run "
            "[bold]looky billing use <id>[/bold] first.[/red]"
        )
        raise typer.Exit(1)
    if expected_billing_account_id and bid != expected_billing_account_id:
        console.print(
            "[red]Active billing account "
            f"[bold]{bid}[/bold] does not match the current path. Expected "
            f"[bold]{expected_billing_account_id}[/bold]. Run "
            f"[bold]looky billing use {expected_billing_account_id}[/bold] "
            f"from [bold]{root_context.root_path}[/bold] first.[/red]"
        )
        raise typer.Exit(1)
    return bid


@app.command("list")
def billing_list() -> None:
    """List billing accounts you have access to (owner, developer, or read)."""
    root_context, client = require_authenticated_client(Path.cwd(), exact_root=True)
    try:
        result = client.get("/api/billing-accounts")
    except LookyClientError as exc:
        if exc.status_code == 401:
            console.print(
                "[red]Token expired or revoked. Run "
                f"[bold]{relogin_command(root_context)}[/bold] again.[/red]"
            )
        else:
            console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from exc

    accounts = result.get("billing_accounts") or []
    current = root_context.billing_account_id

    if not accounts:
        console.print("[yellow]No billing accounts available. You need access as owner, developer, or read.[/yellow]")
        return

    t = Table(show_header=True, header_style="bold")
    t.add_column("ID")
    t.add_column("Name")
    t.add_column("Role")
    t.add_column("", width=4)

    for a in accounts:
        bid = str(a.get("id") or "")
        name = str(a.get("display_name") or bid)
        role = str(a.get("role") or "")
        marker = " *" if bid == current else ""
        t.add_row(bid, name, role, marker)

    console.print(t)
    if current:
        console.print(f"\n[dim]* = active billing account ([bold]{current}[/bold])[/dim]")
    else:
        console.print(
            "\n[yellow]No active billing account. Run [bold]looky billing use &lt;id&gt;[/bold] to set one.[/yellow]"
        )


@app.command("use")
def billing_use(
    billing_account_id: str = typer.Argument(..., help="Billing account ID to activate"),
) -> None:
    """Set the active billing account. Validates you have access (SA, owner, developer, or read)."""
    root_context, client = require_authenticated_client(Path.cwd(), exact_root=True)

    bid = billing_account_id.strip()
    if not bid:
        console.print("[red]Billing account ID is required.[/red]")
        raise typer.Exit(1)

    try:
        client.get(f"/api/billing-accounts/{bid}/access")
    except LookyClientError as exc:
        if exc.status_code == 401:
            console.print(
                "[red]Token expired or revoked. Run "
                f"[bold]{relogin_command(root_context)}[/bold] again.[/red]"
            )
        elif exc.status_code == 403:
            console.print(
                f"[red]No access to billing account [bold]{bid}[/bold]. "
                "Run [bold]looky billing list[/bold] to see available accounts.[/red]"
            )
        elif exc.status_code == 400:
            console.print(f"[red]{exc}[/red]")
        else:
            console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(1) from exc

    cfg.set_root_billing_account_id(root_context.root_path, bid)
    console.print(f"[green]Active billing account set to [bold]{bid}[/bold].[/green]")
