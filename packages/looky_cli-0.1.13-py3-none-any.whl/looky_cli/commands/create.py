from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from looky_cli.client import LookyClient, LookyClientError
from looky_cli.commands.billing import build_authenticated_client, relogin_command, require_billing_context
from looky_cli.workspace import WorkspaceResolutionError, resolve_billing_directory

console = Console()


def create(
    workspace_slug: str = typer.Argument(..., help="Workspace slug to create under the current billing directory"),
    name: str = typer.Option(None, "--name", "-n", help="Human-readable workspace name"),
    description: str = typer.Option("", "--description", "-d", help="Short description"),
    local_only: bool = typer.Option(
        False,
        "--local-only",
        help="Only create the local skeleton, skip server registration",
    ),
) -> None:
    """
    Register a new workspace on the server and scaffold it locally.

    The workspace is registered on the server first (fails if it already exists),
    then the local directory skeleton is created. The calling user is automatically
    granted write access.
    """
    slug = _normalize_workspace_slug(workspace_slug)
    try:
        billing_dir = resolve_billing_directory(Path.cwd())
    except WorkspaceResolutionError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc

    workspace_id = f"{billing_dir.billing_account_id}/{slug}"
    resolved_name = name or slug
    dest = billing_dir.billing_path / slug

    client: LookyClient | None = None
    if not local_only:
        client = build_authenticated_client(billing_dir.root_context)
        require_billing_context(
            billing_dir.root_context,
            client,
            expected_billing_account_id=billing_dir.billing_account_id,
        )

    if not local_only:
        with console.status(f"Registering [bold]{workspace_id}[/bold] on {billing_dir.root_context.url}…"):
            try:
                result = client.post(  # type: ignore[union-attr]
                    "/api/workspaces",
                    json={
                        "workspace_id": workspace_id,
                        "name": resolved_name,
                        "description": description,
                    },
                )
            except LookyClientError as exc:
                if exc.status_code == 409:
                    console.print(
                        f"[red]Workspace [bold]{workspace_id}[/bold] already exists on the server. "
                        f"Use [bold]looky pull {slug}[/bold] from [bold]{billing_dir.billing_path}[/bold] "
                        "to get its content.[/red]"
                    )
                elif exc.status_code == 401:
                    console.print(
                        "[red]Token expired or revoked. Run "
                        f"[bold]{relogin_command(billing_dir.root_context)}[/bold] again.[/red]"
                    )
                elif exc.status_code == 400:
                    console.print(f"[red]Invalid input: {exc}[/red]")
                else:
                    console.print(f"[red]Failed to create workspace: {exc}[/red]")
                raise typer.Exit(1) from exc

        console.print(
            f"[green]✓ Workspace [bold]{workspace_id}[/bold] registered on server "
            f"(access: {result.get('access_mode', 'write')})[/green]"
        )

    # -----------------------------------------------------------------------
    # Local skeleton
    # -----------------------------------------------------------------------
    if dest.exists() and any(dest.iterdir()):
        console.print(
            f"[yellow]Local directory [bold]{dest}[/bold] already exists and is not empty — skipping skeleton.[/yellow]"
        )
    else:
        _scaffold_local(dest, workspace_slug=slug, name=resolved_name, description=description)
        console.print(f"[green]✓ Local skeleton created at [bold]{dest}[/bold][/green]")

    _print_next_steps(workspace_id, dest)


def _normalize_workspace_slug(workspace_slug: str) -> str:
    slug = workspace_slug.strip().strip("/")
    if not slug or "/" in slug or slug in {".", ".."}:
        console.print("[red]Workspace slug must be a single path segment.[/red]")
        raise typer.Exit(1)
    return slug


def _scaffold_local(dest: Path, *, workspace_slug: str, name: str, description: str) -> None:
    dest.mkdir(parents=True, exist_ok=True)

    ws_yml = dest / "workspace.yml"
    ws_yml.write_text(
        f"id: {workspace_slug}\n"
        f"name: {name}\n"
        + (f"description: {description}\n" if description else "")
        + "ui:\n"
        "  default_locale: en\n"
        "  supported_locales: [en, es]\n",
        encoding="utf-8",
    )

    for subdir in (
        "content/models",
        "content/visualizations",
        "content/dashboards",
        "content/exports",
        "runtime",
    ):
        (dest / subdir).mkdir(parents=True, exist_ok=True)

    runtime_example = dest / "runtime" / "sources.runtime.yml"
    runtime_example.write_text(
        "# Runtime source configuration — DO NOT commit secrets.\n"
        "# See docs for supported types: bigquery, postgres.\n\n"
        "sources:\n"
        "  my_bigquery:\n"
        "    type: bigquery\n"
        "    project_id: \"my-gcp-project\"\n"
        "    credentials_file: \"secrets/my-sa.json\"\n"
        "    dataset: \"finance_analytics\"  # Use for a single dataset\n"
        "    # datasets:                    # Use this instead when you need multiple datasets\n"
        "    #   - \"finance_analytics\"\n"
        "    #   - \"other_project.shared_dataset\"\n\n"
        "  my_postgres:\n"
        "    type: postgres\n"
        "    host: \"db.example.com\"\n"
        "    port: 5432\n"
        "    database: \"analytics\"\n"
        "    user: \"looky_reader\"\n"
        "    password_env: \"LOOKY_PG_PASSWORD\"  # Recommended over inline password\n"
        "    # schemas: [\"public\", \"finance\"]  # Optional; defaults to non-system schemas\n",
        encoding="utf-8",
    )

    secrets_gitkeep = dest / "secrets" / ".gitkeep"
    secrets_gitkeep.parent.mkdir(parents=True, exist_ok=True)
    secrets_gitkeep.touch()


def _print_next_steps(workspace_id: str, dest: Path) -> None:
    console.print(f"\n[bold]Next steps:[/bold]")
    t = Table(show_header=False, box=None, padding=(0, 1))
    t.add_column(style="dim", no_wrap=True)
    t.add_column()
    t.add_row("1.", f"Add your source config in [bold]{dest}/runtime/sources.runtime.yml[/bold]")
    t.add_row("2.", f"Add credentials to [bold]{dest}/secrets/[/bold]  (never commit these)")
    t.add_row("3.", f"Write your Malloy models in [bold]{dest}/content/models/[/bold]")
    t.add_row("4.", f"Change into [bold]{dest}[/bold] and run [bold]looky validate[/bold]")
    t.add_row("5.", f"From [bold]{dest}[/bold], run [bold]looky push[/bold] when ready")
    console.print(t)
