"""
HTTP client for the looky API.
"""
from __future__ import annotations

import re
from typing import Any

import httpx


class LookyClientError(Exception):
    def __init__(
        self,
        message: str,
        *,
        status_code: int = 0,
        payload: dict[str, Any] | None = None,
        reason_phrase: str = "",
        body_preview: str = "",
        request_id: str = "",
    ):
        super().__init__(message)
        self.status_code = status_code
        # Full parsed response body when the server returned JSON. Callers
        # read `payload["errors"][0]` to distinguish error kinds beyond the
        # HTTP status (e.g. 404 "workspaceNotFound" vs 404 "endpoint missing
        # on an older server build that returned an HTML page").
        self.payload = payload
        # Transport-level details — callers need these when the body wasn't
        # JSON (e.g. an edge/proxy served an HTML error page).
        self.reason_phrase = reason_phrase
        self.body_preview = body_preview
        # X-Request-Id from the response headers if the server/proxy provided
        # one. Present even when the body is a generic error page, which is
        # the only anchor the user has to correlate with server logs.
        self.request_id = request_id


# ---- helpers for building informative error messages --------------------

_HTML_LIKE_RE = re.compile(r"^\s*<", re.IGNORECASE)
_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"\s+")


def _looks_like_html(body: str) -> bool:
    return bool(body) and bool(_HTML_LIKE_RE.match(body))


def _raw_body_preview(resp: httpx.Response, limit: int = 400) -> str:
    try:
        text = resp.text or ""
    except Exception:
        return ""
    return text[:limit]


def _extract_request_id(resp: httpx.Response) -> str:
    try:
        return str(resp.headers.get("x-request-id") or resp.headers.get("cf-ray") or "").strip()
    except Exception:
        return ""


def _summarize_html_body(body: str, limit: int = 240) -> str:
    """Return a compact single-line excerpt of an HTML error page — useful
    when an edge proxy (Cloudflare, nginx) interposes and replaces our JSON
    response with its own page."""
    no_tags = _TAG_RE.sub(" ", body or "")
    collapsed = _WS_RE.sub(" ", no_tags).strip()
    return collapsed[:limit]


def _build_error_message(resp: httpx.Response, data: Any) -> str:
    """Compose a one-line, self-describing error message from the response.
    Priorities:
      1. If the server replied with the canonical `{"errors": [...]}`
         envelope, surface the first typeKey.
      2. Otherwise include status + reason + a body snippet (HTML summarized).
    Never returns the empty string.
    """
    status = resp.status_code
    reason = (getattr(resp, "reason_phrase", "") or "").strip()

    if isinstance(data, dict):
        errors = data.get("errors")
        if isinstance(errors, list) and errors:
            first = errors[0]
            if isinstance(first, dict):
                type_key = next(iter(first), None)
                if isinstance(type_key, str) and type_key.strip():
                    header = f"HTTP {status}"
                    if reason:
                        header += f" {reason}"
                    return f"{header}: {type_key.strip()}"

    raw = _raw_body_preview(resp, limit=800)
    if raw:
        if _looks_like_html(raw):
            snippet = _summarize_html_body(raw)
            header = f"HTTP {status}"
            if reason:
                header += f" {reason}"
            return f"{header} (HTML body — likely an intermediate proxy): {snippet}"
        # Non-JSON plain-text body — strip to a line.
        collapsed = _WS_RE.sub(" ", raw).strip()
        header = f"HTTP {status}"
        if reason:
            header += f" {reason}"
        return f"{header}: {collapsed[:240]}"

    header = f"HTTP {status}"
    if reason:
        header += f" {reason}"
    return f"{header} (empty response body)"


class LookyClient:
    def __init__(self, *, url: str, token: str | None = None, timeout: float = 30.0):
        self.base_url = url.rstrip("/")
        self.token = token
        self.timeout = timeout

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def _request(self, method: str, path: str, *, timeout: float | None = None, **kwargs: Any) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        try:
            resp = httpx.request(
                method,
                url,
                headers=self._headers(),
                timeout=timeout if timeout is not None else self.timeout,
                **kwargs,
            )
        except httpx.ConnectError as exc:
            raise LookyClientError(f"Cannot connect to {self.base_url}: {exc}") from exc
        except httpx.TimeoutException as exc:
            raise LookyClientError(f"Request timed out: {exc}") from exc
        except httpx.RequestError as exc:
            raise LookyClientError(f"Request error: {exc}") from exc

        try:
            data = resp.json()
        except Exception:
            data = None

        if not resp.is_success:
            raise LookyClientError(
                _build_error_message(resp, data),
                status_code=resp.status_code,
                payload=data if isinstance(data, dict) else None,
                reason_phrase=getattr(resp, "reason_phrase", "") or "",
                body_preview=_raw_body_preview(resp),
                request_id=_extract_request_id(resp),
            )

        return data if isinstance(data, dict) else {}

    def get(self, path: str, *, timeout: float | None = None, **kwargs: Any) -> dict[str, Any]:
        return self._request("GET", path, timeout=timeout, **kwargs)

    def post(
        self,
        path: str,
        json: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        return self._request("POST", path, timeout=timeout, json=json, **kwargs)

    def put(
        self,
        path: str,
        json: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        return self._request("PUT", path, timeout=timeout, json=json, **kwargs)

    def delete(self, path: str, *, timeout: float | None = None, **kwargs: Any) -> dict[str, Any]:
        return self._request("DELETE", path, timeout=timeout, **kwargs)

    def otp_start(self, email: str) -> dict[str, Any]:
        return self.post("/api/auth/one-time-pins", json={"email": email, "expiration_minutes": 10})

    def otp_authenticate(self, *, method_id: str, email: str, code: str) -> dict[str, Any]:
        return self.post(
            "/api/auth/sessions",
            json={
                "method_id": method_id,
                "email": email,
                "code": code,
                "session_duration_minutes": 60,
            },
            params={"mode": "cli"},
        )

    def whoami(self) -> dict[str, Any]:
        return self.get("/api/auth/me")

    def revoke_token(self) -> dict[str, Any]:
        return self.delete("/api/auth/sessions")
