from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from looky_cli import config as cfg


class WorkspaceResolutionError(Exception):
    pass


@dataclass(frozen=True)
class RootContext:
    root_path: Path
    current_path: Path
    url: str
    token: str | None
    user: dict[str, Any]
    billing_account_id: str | None


@dataclass(frozen=True)
class BillingDirectory:
    root_context: RootContext
    billing_path: Path
    billing_account_id: str


@dataclass(frozen=True)
class LocalWorkspace:
    root_context: RootContext
    root: Path
    workspace_file: Path
    billing_account_id: str
    workspace_slug: str
    workspace_id: str


def resolve_root_context(path: Path) -> RootContext:
    resolved_path = path.resolve()
    binding = cfg.find_workspace_root_binding(resolved_path)
    if binding is None:
        raise WorkspaceResolutionError(
            f"no linked workspace root found for {resolved_path}. "
            "Run `looky login <url> <root_path>` first."
        )

    root_path = Path(str(binding.get("root_path") or "")).resolve()
    url = str(binding.get("url") or "").strip()
    if not url:
        raise WorkspaceResolutionError(f"linked workspace root '{root_path}' has no URL configured")
    session = cfg.get_session(url)
    return RootContext(
        root_path=root_path,
        current_path=resolved_path,
        url=url,
        token=str(session.get("token") or "").strip() or None,
        user=dict(session.get("user") or {}),
        billing_account_id=cfg.get_root_billing_account_id(root_path),
    )


def resolve_billing_directory(path: Path) -> BillingDirectory:
    root_context = resolve_root_context(path)
    rel_parts = _relative_parts(root_context.current_path, root_context.root_path)
    if len(rel_parts) != 1:
        raise WorkspaceResolutionError(
            f"this command must be run from a billing directory under '{root_context.root_path}'"
        )
    billing_path = (root_context.root_path / rel_parts[0]).resolve()
    return BillingDirectory(
        root_context=root_context,
        billing_path=billing_path,
        billing_account_id=rel_parts[0],
    )


def canonical_workspace_id_from_path(workspace_root: Path, *, root_path: Path) -> str:
    resolved_root = workspace_root.resolve()
    rel_parts = _relative_parts(resolved_root, root_path.resolve())
    if len(rel_parts) != 2 or not rel_parts[0] or not rel_parts[1]:
        raise WorkspaceResolutionError(
            f"expected workspace layout under '{root_path}': <billing_account_id>/<workspace_slug>/"
        )
    return f"{rel_parts[0]}/{rel_parts[1]}"


def infer_workspace_root(path: Path, *, root_path: Path) -> Path:
    resolved_path = path.resolve()
    rel_parts = _relative_parts(resolved_path, root_path.resolve())
    if len(rel_parts) < 2:
        raise WorkspaceResolutionError(
            f"this command must be run from a workspace directory under '{root_path}/<billing_account_id>/<workspace_slug>/'"
        )
    return (root_path / rel_parts[0] / rel_parts[1]).resolve()


def resolve_local_workspace(path: Path) -> LocalWorkspace:
    root_context = resolve_root_context(path)
    workspace_root = infer_workspace_root(root_context.current_path, root_path=root_context.root_path)
    workspace_file = workspace_root / "workspace.yml"
    if not workspace_file.is_file():
        raise WorkspaceResolutionError(
            f"workspace.yml not found in {workspace_root}. "
            f"Expected workspace layout under '{root_context.root_path}/<billing_account_id>/<workspace_slug>/'"
        )

    workspace_id = canonical_workspace_id_from_path(workspace_root, root_path=root_context.root_path)
    billing_account_id, workspace_slug = workspace_id.split("/", 1)
    metadata_id = read_workspace_id_field(workspace_file)
    if metadata_id is None:
        raise WorkspaceResolutionError("workspace.yml must define top-level 'id'")
    if metadata_id != workspace_slug:
        raise WorkspaceResolutionError(
            f"workspace.yml id must match the workspace slug '{workspace_slug}'"
        )

    return LocalWorkspace(
        root_context=root_context,
        root=workspace_root,
        workspace_file=workspace_file,
        billing_account_id=billing_account_id,
        workspace_slug=workspace_slug,
        workspace_id=workspace_id,
    )


def read_workspace_id_field(workspace_file: Path) -> str | None:
    try:
        text = workspace_file.read_text(encoding="utf-8")
    except OSError as exc:
        raise WorkspaceResolutionError(f"failed to read {workspace_file}: {exc}") from exc

    for raw_line in text.splitlines():
        line = raw_line.rstrip()
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if line[:1].isspace():
            continue
        if not line.startswith("id:"):
            continue
        value = _strip_inline_comment(line.split(":", 1)[1]).strip()
        if not value:
            return None
        if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
            value = value[1:-1]
        value = value.strip()
        return value or None

    return None


def _relative_parts(path: Path, root_path: Path) -> tuple[str, ...]:
    try:
        rel = path.resolve().relative_to(root_path.resolve())
    except ValueError as exc:
        raise WorkspaceResolutionError(f"path '{path}' is not inside linked root '{root_path}'") from exc
    return tuple(part for part in rel.parts if part and part != ".")


def _strip_inline_comment(value: str) -> str:
    in_single = False
    in_double = False

    for index, char in enumerate(value):
        if char == "'" and not in_double:
            in_single = not in_single
            continue
        if char == '"' and not in_single:
            in_double = not in_double
            continue
        if char == "#" and not in_single and not in_double:
            return value[:index]

    return value
