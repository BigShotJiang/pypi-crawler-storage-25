from __future__ import annotations

import typer

from looky_cli.commands import auth, billing, create, diff, list_cmd, pull, push, rollback, sources, status, workspaces

app = typer.Typer(
    name="looky",
    help="Publish and manage content on a looky instance.",
    no_args_is_help=True,
)

app.add_typer(billing.app, name="billing")
app.add_typer(list_cmd.app, name="list")
app.add_typer(sources.app, name="sources")

app.command("login")(auth.login)
app.command("logout")(auth.logout)
app.command("whoami")(auth.whoami)
app.command("workspaces")(workspaces.workspaces)
app.command("create")(create.create)
app.command("diff")(diff.diff)
app.command("rollback")(rollback.rollback)
app.command("status")(status.status)
app.command("pull")(pull.pull)
app.command("push")(push.push)
app.command("validate")(push.validate_cmd)

if __name__ == "__main__":
    app()
