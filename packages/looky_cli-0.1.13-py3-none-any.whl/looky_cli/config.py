"""
Config file management for the looky CLI.

Config is stored at ~/.looky/config.json.
Schema:
  {
    "sessions": {
      "https://<instance>.looky.studio": {
        "url": "https://<instance>.looky.studio",
        "token": "...",
        "token_expires_at": "2026-...",
        "user": { "id": 1, "email": "...", "role": "..." }
      }
    },
    "workspace_roots": {
      "/absolute/path/to/your/content": {
        "url": "https://<instance>.looky.studio",
        "billing_account_id": "<billing-account-id>"
      }
    }
  }
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


CONFIG_DIR = Path.home() / ".looky"
CONFIG_FILE = CONFIG_DIR / "config.json"


def _normalize_url(url: str) -> str:
    return str(url or "").strip().rstrip("/")


def _normalize_root_path(root_path: Path | str) -> str:
    return str(Path(root_path).expanduser().resolve())


def _load_raw() -> dict[str, Any]:
    if not CONFIG_FILE.exists():
        return {"sessions": {}, "workspace_roots": {}}
    try:
        raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {"sessions": {}, "workspace_roots": {}}
    return _migrate_legacy_schema(raw)


def _migrate_legacy_schema(data: dict[str, Any]) -> dict[str, Any]:
    sessions = data.get("sessions")
    roots = data.get("workspace_roots")
    if isinstance(sessions, dict) and isinstance(roots, dict):
        return {
            "sessions": sessions,
            "workspace_roots": roots,
        }

    migrated: dict[str, Any] = {"sessions": {}, "workspace_roots": {}}
    instances = data.get("instances") or {}
    if isinstance(instances, dict):
        for entry in instances.values():
            if not isinstance(entry, dict):
                continue
            url = _normalize_url(str(entry.get("url") or ""))
            if not url:
                continue
            session = migrated["sessions"].get(url) or {"url": url}
            token = str(entry.get("token") or "").strip()
            expires_at = str(entry.get("token_expires_at") or "").strip()
            user = entry.get("user") or {}
            if token:
                session["token"] = token
            if expires_at:
                session["token_expires_at"] = expires_at
            if isinstance(user, dict) and user:
                session["user"] = {
                    "id": user.get("id"),
                    "email": user.get("email"),
                    "first_name": user.get("first_name"),
                    "last_name": user.get("last_name"),
                    "role": user.get("role"),
                }
            migrated["sessions"][url] = session
    return migrated


def _save_raw(data: dict[str, Any]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    payload = {
        "sessions": data.get("sessions") or {},
        "workspace_roots": data.get("workspace_roots") or {},
    }
    CONFIG_FILE.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    CONFIG_FILE.chmod(0o600)


def get_session(url: str) -> dict[str, Any]:
    data = _load_raw()
    return dict((data.get("sessions") or {}).get(_normalize_url(url)) or {})


def save_session(
    url: str,
    *,
    token: str,
    expires_at: str,
    user: dict[str, Any],
) -> None:
    normalized_url = _normalize_url(url)
    if not normalized_url:
        raise ValueError("url is required")
    data = _load_raw()
    sessions = data.setdefault("sessions", {})
    sessions[normalized_url] = {
        "url": normalized_url,
        "token": token,
        "token_expires_at": expires_at,
        "user": {
            "id": user.get("id"),
            "email": user.get("email"),
            "first_name": user.get("first_name"),
            "last_name": user.get("last_name"),
            "role": user.get("role"),
        },
    }
    _save_raw(data)


def clear_session(url: str) -> None:
    normalized_url = _normalize_url(url)
    data = _load_raw()
    sessions = data.get("sessions") or {}
    sessions.pop(normalized_url, None)
    _save_raw(data)


def bind_workspace_root(root_path: Path | str, *, url: str) -> None:
    normalized_root = _normalize_root_path(root_path)
    normalized_url = _normalize_url(url)
    if not normalized_url:
        raise ValueError("url is required")
    root = Path(normalized_root)
    if not root.is_dir():
        raise ValueError(f"workspace root not found: {root}")

    data = _load_raw()
    roots = data.setdefault("workspace_roots", {})
    for existing_root_str in list(roots.keys()):
        existing_root = Path(existing_root_str)
        if existing_root == root:
            continue
        if _contains_path(existing_root, root) or _contains_path(root, existing_root):
            raise ValueError(
                f"workspace root '{root}' overlaps with existing linked root '{existing_root}'"
            )

    binding = dict(roots.get(normalized_root) or {})
    billing_account_id = binding.get("billing_account_id")
    roots[normalized_root] = {"url": normalized_url}
    if billing_account_id:
        roots[normalized_root]["billing_account_id"] = billing_account_id
    _save_raw(data)


def find_workspace_root_binding(path: Path | str) -> dict[str, Any] | None:
    resolved_path = Path(path).expanduser().resolve()
    data = _load_raw()
    roots = data.get("workspace_roots") or {}
    best_match: tuple[int, Path, dict[str, Any]] | None = None

    for root_str, binding in roots.items():
        root = Path(root_str)
        if not isinstance(binding, dict):
            continue
        if not _contains_path(root, resolved_path):
            continue
        score = len(root.parts)
        if best_match is None or score > best_match[0]:
            best_match = (score, root, binding)

    if best_match is None:
        return None

    _, root, binding = best_match
    out = dict(binding)
    out["root_path"] = str(root)
    return out


def get_root_billing_account_id(root_path: Path | str) -> str | None:
    data = _load_raw()
    roots = data.get("workspace_roots") or {}
    binding = roots.get(_normalize_root_path(root_path)) or {}
    value = binding.get("billing_account_id")
    return str(value).strip() if value else None


def set_root_billing_account_id(root_path: Path | str, billing_account_id: str) -> None:
    normalized_root = _normalize_root_path(root_path)
    bid = str(billing_account_id or "").strip()
    if not bid:
        raise ValueError("billing_account_id is required")
    data = _load_raw()
    roots = data.setdefault("workspace_roots", {})
    binding = dict(roots.get(normalized_root) or {})
    if not binding:
        raise ValueError(f"workspace root is not linked: {normalized_root}")
    binding["billing_account_id"] = bid
    roots[normalized_root] = binding
    _save_raw(data)


def clear_root_billing_account_id(root_path: Path | str) -> None:
    normalized_root = _normalize_root_path(root_path)
    data = _load_raw()
    roots = data.get("workspace_roots") or {}
    binding = dict(roots.get(normalized_root) or {})
    if not binding:
        return
    binding.pop("billing_account_id", None)
    roots[normalized_root] = binding
    _save_raw(data)


def _contains_path(parent: Path, child: Path) -> bool:
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False
