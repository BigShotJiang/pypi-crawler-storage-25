"""
Local workspace validator — runs before push and as a standalone command.

Levels:
  error   — blocks push
  warning — reported but does not block
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None  # type: ignore[assignment]

from vizspec import (
    validate_dashboard as _validate_dashboard_schema,
    validate_viz_spec as _validate_viz_spec_schema,
)

from looky_cli.workspace import WorkspaceResolutionError, canonical_workspace_id_from_path

CRON_RE = re.compile(
    r"^(\*|[0-9,-/]+)\s+"
    r"(\*|[0-9,-/]+)\s+"
    r"(\*|[0-9,-/]+)\s+"
    r"(\*|[0-9,-/]+)\s+"
    r"(\*|[0-9,-/]+)$"
)

VALID_LAYOUT_MODES = {"fluid_grid", "document"}
VALID_SOURCE_TYPES = {"bigquery", "postgres"}


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class Issue:
    level: Literal["error", "warning"]
    code: str
    message: str
    file: str | None = None
    # Extra fields populated by the server-side validator (MR### issues).
    # Local validation uses the base fields only.
    viz_id: str | None = None
    query_ref: str | None = None
    line: int | None = None
    column: int | None = None

    def __str__(self) -> str:
        prefix = "ERROR" if self.level == "error" else "WARN "
        loc = f" [{self.file}]" if self.file else ""
        return f"{prefix}{loc} {self.message}"


@dataclass
class ValidationResult:
    workspace_root: Path
    issues: list[Issue] = field(default_factory=list)

    def error(self, code: str, message: str, file: str | None = None) -> None:
        self.issues.append(Issue("error", code, message, file))

    def warn(self, code: str, message: str, file: str | None = None) -> None:
        self.issues.append(Issue("warning", code, message, file))

    @property
    def errors(self) -> list[Issue]:
        return [i for i in self.issues if i.level == "error"]

    @property
    def warnings(self) -> list[Issue]:
        return [i for i in self.issues if i.level == "warning"]

    @property
    def ok(self) -> bool:
        return not self.errors


# ---------------------------------------------------------------------------
# YAML helpers
# ---------------------------------------------------------------------------

def _load_yaml(path: Path) -> tuple[dict[str, Any] | None, str | None]:
    """Return (parsed, error_message). parsed is None on failure."""
    if yaml is None:
        return None, "PyYAML is not installed"
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        return None, str(exc)
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        return None, str(exc)
    if data is None:
        return {}, None
    if not isinstance(data, dict):
        return None, "expected a YAML mapping at top level"
    return data, None


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------

def _check_workspace_yml(
    result: ValidationResult,
    root: Path,
    *,
    root_path: Path | None,
) -> dict[str, Any]:
    ws_file = root / "workspace.yml"
    rel = "workspace.yml"

    if not ws_file.exists():
        result.error("WS001", "workspace.yml is missing")
        return {}

    data, err = _load_yaml(ws_file)
    if err or data is None:
        result.error("WS002", f"workspace.yml is not valid YAML: {err}", rel)
        return {}

    workspace_id = str(data.get("id") or "").strip()
    try:
        if root_path is None:
            raise WorkspaceResolutionError("linked workspace root is required for canonical validation")
        expected_workspace_id = canonical_workspace_id_from_path(root, root_path=root_path)
    except WorkspaceResolutionError as exc:
        result.error("WS004", str(exc), rel)
        expected_workspace_id = None

    if not workspace_id:
        result.error("WS003", "workspace.yml is missing required field 'id'", rel)
    elif expected_workspace_id:
        expected_workspace_slug = expected_workspace_id.split("/", 1)[1]
        if workspace_id != expected_workspace_slug:
            result.error(
                "WS006",
                "workspace.yml 'id' "
                f"({workspace_id!r}) does not match the workspace slug ({expected_workspace_slug!r})",
                rel,
            )

    if not str(data.get("name") or "").strip():
        result.error("WS005", "workspace.yml is missing required field 'name'", rel)

    return data


def _check_runtime(result: ValidationResult, root: Path) -> dict[str, Any]:
    """Returns parsed sources dict keyed by alias."""
    runtime_file = root / "runtime" / "sources.runtime.yml"
    rel = "runtime/sources.runtime.yml"

    if not runtime_file.exists():
        result.warn("RT001", "runtime/sources.runtime.yml is missing (server may have it configured)")
        return {}

    data, err = _load_yaml(runtime_file)
    if err or data is None:
        result.warn("RT002", f"runtime/sources.runtime.yml is not valid YAML: {err}", rel)
        return {}

    raw_sources = data.get("sources") or {}
    if not isinstance(raw_sources, dict) or not raw_sources:
        result.warn("RT003", "runtime/sources.runtime.yml has no sources defined", rel)
        return {}

    sources: dict[str, Any] = {}
    for alias, spec in raw_sources.items():
        if not isinstance(spec, dict):
            result.warn("RT004", f"source '{alias}': expected a mapping", rel)
            continue

        source_type = str(spec.get("type") or "").strip().lower()
        if source_type not in VALID_SOURCE_TYPES:
            result.warn(
                "RT005",
                f"source '{alias}': unsupported type {source_type!r} (expected: {', '.join(sorted(VALID_SOURCE_TYPES))})",
                rel,
            )
            sources[alias] = spec
            continue

        if source_type == "bigquery":
            if not str(spec.get("project_id") or "").strip():
                result.error("RT006", f"source '{alias}' (bigquery): missing 'project_id'", rel)
            creds = str(spec.get("credentials_file") or "").strip()
            if not creds:
                result.error("RT007", f"source '{alias}' (bigquery): missing 'credentials_file'", rel)
            else:
                # Paths starting with /workspace/ are server-side Docker paths — skip local check.
                if not creds.startswith("/workspace/") and not Path(creds).is_absolute():
                    creds_path = root / creds
                    if not creds_path.exists():
                        result.warn(
                            "RT008",
                            f"source '{alias}' (bigquery): credentials_file not found: {creds}",
                            rel,
                        )

        elif source_type == "postgres":
            connection_string = str(
                spec.get("connection_string") or spec.get("connectionString") or ""
            ).strip()
            if not connection_string:
                for req in ("host", "database", "user"):
                    if not str(spec.get(req) or "").strip():
                        result.error("RT009", f"source '{alias}' (postgres): missing '{req}'", rel)
                if not spec.get("password_env") and not spec.get("password"):
                    result.warn("RT010", f"source '{alias}' (postgres): no 'password_env' or 'password' set", rel)

        sources[alias] = spec

    return sources


def _collect_source_aliases_from_model(text: str) -> set[str]:
    """Heuristic: find identifiers used as <alias>.table(...) or <alias>.sql(...)."""
    return set(re.findall(r"\b([A-Za-z_][A-Za-z0-9_]*)\.(?:table|sql)\s*\(", text))


def _check_models(
    result: ValidationResult,
    content_root: Path,
    known_sources: dict[str, Any],
) -> set[str]:
    """Returns the set of model relative paths (from content_root) that exist."""
    models_dir = content_root / "models"
    if not models_dir.is_dir():
        return set()

    existing_malloy: set[str] = set()

    for f in sorted(models_dir.rglob("*.malloy")):
        rel = f.relative_to(content_root).as_posix()
        existing_malloy.add(rel)

        if known_sources:
            try:
                text = f.read_text(encoding="utf-8")
                aliases = _collect_source_aliases_from_model(text)
                for alias in aliases:
                    if alias not in known_sources:
                        result.error(
                            "MD001",
                            f"model uses source alias '{alias}' not found in runtime/sources.runtime.yml (fatal)",
                            rel,
                        )
            except OSError:
                pass

    for f in sorted(models_dir.rglob("*.cache.yml")):
        rel = f.relative_to(content_root).as_posix()
        data, err = _load_yaml(f)
        if err or data is None:
            result.error("MD002", f"cache sidecar is not valid YAML: {err}", rel)
            continue

        model_ref = str(data.get("model") or "").strip()
        if not model_ref:
            result.warn("MD003", "cache sidecar missing 'model' field", rel)
        elif model_ref not in existing_malloy:
            result.error(
                "MD004",
                f"cache sidecar 'model' points to non-existent file: {model_ref!r}",
                rel,
            )

    return existing_malloy


def _check_visualizations(
    result: ValidationResult,
    content_root: Path,
    existing_malloy: set[str],
) -> set[str]:
    """Returns the set of valid viz IDs found."""
    viz_dir = content_root / "visualizations"
    if not viz_dir.is_dir():
        return set()

    viz_ids: set[str] = set()
    seen_ids: dict[str, str] = {}

    for f in sorted(viz_dir.rglob("*.yml")):
        rel = f.relative_to(content_root).as_posix()
        data, err = _load_yaml(f)
        if err or data is None:
            result.error("VZ001", f"visualization is not valid YAML: {err}", rel)
            continue

        viz_id = str(data.get("id") or "").strip()
        if not viz_id:
            result.error("VZ002", "visualization missing required field 'id'", rel)
        else:
            if viz_id in seen_ids:
                result.error(
                    "VZ003",
                    f"duplicate visualization id '{viz_id}' (also in {seen_ids[viz_id]})",
                    rel,
                )
            else:
                seen_ids[viz_id] = rel
                viz_ids.add(viz_id)

            if viz_id != f.stem:
                result.warn(
                    "VZ004",
                    f"visualization id '{viz_id}' does not match filename '{f.stem}.yml'",
                    rel,
                )

        if not str(data.get("title") or "").strip():
            result.error("VZ005", "visualization missing required field 'title'", rel)

        if not str(data.get("type") or "").strip():
            result.error("VZ006", "visualization missing required field 'type'", rel)

        query_ref = str(data.get("query") or "").strip()
        if not query_ref:
            result.error("VZ007", "visualization missing required field 'query'", rel)
        elif "::" not in query_ref:
            result.error(
                "VZ008",
                f"visualization 'query' must be in 'path/to/model.malloy::query_name' format, got: {query_ref!r}",
                rel,
            )
        else:
            model_path, _ = query_ref.split("::", 1)
            if model_path not in existing_malloy:
                result.error(
                    "VZ009",
                    f"visualization 'query' references non-existent model: {model_path!r}",
                    rel,
                )

        # Schema validation (VZ020). The schema is the canonical vizSpec contract —
        # unknown keys, wrong types, and obsolete synonyms are rejected here.
        # Errors from jsonschema are surfaced raw (no "did you mean" hints).
        for issue in _validate_viz_spec_schema(data):
            result.error("VZ020", f"{issue.path}: {issue.message}", rel)

    return viz_ids


def _check_dashboards(
    result: ValidationResult,
    content_root: Path,
    known_viz_ids: set[str],
) -> set[str]:
    """Returns the set of valid dashboard IDs found."""
    dash_dir = content_root / "dashboards"
    if not dash_dir.is_dir():
        return set()

    dash_ids: set[str] = set()
    seen_ids: dict[str, str] = {}

    for f in sorted(dash_dir.rglob("*.yml")):
        rel = f.relative_to(content_root).as_posix()
        data, err = _load_yaml(f)
        if err or data is None:
            result.error("DB001", f"dashboard is not valid YAML: {err}", rel)
            continue

        dash_id = str(data.get("id") or "").strip()
        if not dash_id:
            result.error("DB002", "dashboard missing required field 'id'", rel)
        else:
            if dash_id in seen_ids:
                result.error(
                    "DB003",
                    f"duplicate dashboard id '{dash_id}' (also in {seen_ids[dash_id]})",
                    rel,
                )
            else:
                seen_ids[dash_id] = rel
                dash_ids.add(dash_id)

            if dash_id != f.stem:
                result.warn(
                    "DB004",
                    f"dashboard id '{dash_id}' does not match filename '{f.stem}.yml'",
                    rel,
                )

        if not str(data.get("title") or "").strip():
            result.error("DB005", "dashboard missing required field 'title'", rel)

        layout_mode = str(data.get("layout_mode") or "").strip()
        if not layout_mode:
            result.error("DB006", "dashboard missing required field 'layout_mode'", rel)
        elif layout_mode not in VALID_LAYOUT_MODES:
            result.error(
                "DB007",
                f"dashboard 'layout_mode' must be one of {sorted(VALID_LAYOUT_MODES)}, got: {layout_mode!r}",
                rel,
            )

        items = data.get("items") or []
        for item in items:
            if not isinstance(item, dict):
                continue
            viz_id = str(item.get("visualization") or "").strip()
            if not viz_id:
                continue
            if viz_id not in known_viz_ids:
                result.error(
                    "DB008",
                    f"dashboard item references unknown visualization: '{viz_id}'",
                    rel,
                )

        # Schema validation (DB009). Catches unknown filter types, typos in
        # preset ids, malformed select options_query, etc. — at push time
        # rather than runtime.
        for issue in _validate_dashboard_schema(data):
            result.error("DB009", f"{issue.path}: {issue.message}", rel)

    return dash_ids


def _check_exports(
    result: ValidationResult,
    content_root: Path,
    known_dash_ids: set[str],
) -> None:
    exports_dir = content_root / "exports"
    if not exports_dir.is_dir():
        return

    seen_ids: dict[str, str] = {}

    for f in sorted(exports_dir.rglob("*.yml")):
        rel = f.relative_to(content_root).as_posix()
        data, err = _load_yaml(f)
        if err or data is None:
            result.error("EX001", f"export is not valid YAML: {err}", rel)
            continue

        export_id = str(data.get("id") or "").strip()
        if not export_id:
            result.error("EX002", "export missing required field 'id'", rel)
        else:
            if export_id in seen_ids:
                result.error(
                    "EX003",
                    f"duplicate export id '{export_id}' (also in {seen_ids[export_id]})",
                    rel,
                )
            else:
                seen_ids[export_id] = rel

        dash_id = str(data.get("dashboard_id") or "").strip()
        if not dash_id:
            result.error("EX004", "export missing required field 'dashboard_id'", rel)
        elif dash_id not in known_dash_ids:
            result.error(
                "EX005",
                f"export 'dashboard_id' references unknown dashboard: '{dash_id}'",
                rel,
            )

        schedule = data.get("schedule") or {}
        cron = str(schedule.get("cron") or "").strip() if isinstance(schedule, dict) else ""
        if not cron:
            result.warn("EX006", "export has no 'schedule.cron' defined", rel)
        elif not CRON_RE.match(cron):
            result.error("EX007", f"export 'schedule.cron' is not a valid cron expression: {cron!r}", rel)

        dest = data.get("destination") or {}
        if not isinstance(dest, dict) or not str(dest.get("type") or "").strip():
            result.error("EX008", "export missing required field 'destination.type'", rel)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def validate(workspace_root: Path, *, root_path: Path | None = None) -> ValidationResult:
    """
    Validate a local workspace directory.
    Returns a ValidationResult with all errors and warnings found.
    """
    result = ValidationResult(workspace_root=workspace_root)

    if yaml is None:
        result.error("SYS001", "PyYAML is required for validation (pip install pyyaml)")
        return result

    _check_workspace_yml(result, workspace_root, root_path=root_path)
    known_sources = _check_runtime(result, workspace_root)

    content_root = workspace_root / "content"
    if not content_root.is_dir():
        result.warn("CT001", "content/ directory is missing or empty")
        return result

    existing_malloy = _check_models(result, content_root, known_sources)
    viz_ids = _check_visualizations(result, content_root, existing_malloy)
    dash_ids = _check_dashboards(result, content_root, viz_ids)
    _check_exports(result, content_root, dash_ids)

    return result
