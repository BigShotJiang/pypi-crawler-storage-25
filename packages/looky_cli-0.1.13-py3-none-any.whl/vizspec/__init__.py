"""Canonical JSON Schema + validator for looky vizSpec and dashboard YAMLs.

Single source of truth shared between the CLI (``looky validate`` / ``looky push``)
and the app backend (defensive validation on push receive).

Public surface:
- ``validate_viz_spec(data)`` — validate a parsed viz YAML dict; returns a list
  of ``ValidationIssue`` (empty list on success).
- ``validate_dashboard(data)`` — validate a parsed dashboard YAML dict; returns
  a list of ``ValidationIssue``. Filters inside the dashboard are dispatched by
  ``type`` to per-filter-type schemas.
- ``SCHEMAS_BY_TYPE`` — mapping of viz type string (e.g. ``"bar"``) to its
  loaded JSON Schema dict.
- ``FILTER_SCHEMAS_BY_TYPE`` — mapping of filter type string (e.g.
  ``"date_range_preset"``) to its loaded JSON Schema dict.
- ``get_schema(viz_type)`` / ``get_filter_schema(filter_type)`` — look up one
  schema; raises ``KeyError`` on unknown type.
- ``walk_field_refs`` / ``mapping_slot_keys`` / ``collect_format_keys`` —
  walkers for the ``x-looky-field-ref`` annotation; used by the remote
  validator to cross-check viz YAMLs against the dry-run schema (VZ030 / VZ031).
- ``ValidationIssue`` — dataclass describing a single schema violation.
"""

from vizspec.field_refs import collect_format_keys, mapping_slot_keys, walk_field_refs
from vizspec.loader import (
    FILTER_SCHEMAS_BY_TYPE,
    SCHEMAS_BY_TYPE,
    get_filter_schema,
    get_schema,
)
from vizspec.validator import ValidationIssue, validate_dashboard, validate_viz_spec

__all__ = [
    "FILTER_SCHEMAS_BY_TYPE",
    "SCHEMAS_BY_TYPE",
    "ValidationIssue",
    "collect_format_keys",
    "get_filter_schema",
    "get_schema",
    "mapping_slot_keys",
    "validate_dashboard",
    "validate_viz_spec",
    "walk_field_refs",
]
