"""Load and expose all schemas at import time.

Schemas live as JSON files in ``vizspec/schemas/``:

- ``viz.<type>.schema.json`` — one per viz renderer, keyed by viz type.
- ``viz.base.schema.json`` — shared envelope ($defs, common required keys).
- ``filter.<type>.schema.json`` — one per filter type, referenced by the
  dashboard schema's ``oneOf``.
- ``dashboard.schema.json`` — top-level dashboard YAML shape.

The loader reads every matching file and exposes the result via:

- ``SCHEMAS_BY_TYPE`` — viz type → schema dict.
- ``FILTER_SCHEMAS_BY_TYPE`` — filter type → schema dict.
- ``DASHBOARD_SCHEMA`` — the loaded dashboard schema (or ``None`` if absent).
- ``BASE_SCHEMA`` — the shared envelope.
"""

from __future__ import annotations

import json
from pathlib import Path

_SCHEMAS_DIR = Path(__file__).parent / "schemas"

BASE_SCHEMA_FILENAME = "viz.base.schema.json"
DASHBOARD_SCHEMA_FILENAME = "dashboard.schema.json"


def _load_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as fh:
        return json.load(fh)


def _type_from_filename(name: str, prefix: str) -> str:
    # ``viz.bar.schema.json`` (prefix=``viz.``) → ``bar``
    # ``filter.cutoff_date.schema.json`` (prefix=``filter.``) → ``cutoff_date``
    stem = name[len(prefix):-len(".schema.json")]
    return stem


def _load_all_schemas() -> tuple[dict, dict, dict, dict | None]:
    base: dict = {}
    by_viz_type: dict[str, dict] = {}
    by_filter_type: dict[str, dict] = {}
    dashboard: dict | None = None
    if not _SCHEMAS_DIR.is_dir():
        return base, by_viz_type, by_filter_type, dashboard
    for path in sorted(_SCHEMAS_DIR.iterdir()):
        if not path.name.endswith(".schema.json"):
            continue
        if path.name == BASE_SCHEMA_FILENAME:
            base = _load_json(path)
            continue
        if path.name == DASHBOARD_SCHEMA_FILENAME:
            dashboard = _load_json(path)
            continue
        if path.name.startswith("viz."):
            viz_type = _type_from_filename(path.name, "viz.")
            by_viz_type[viz_type] = _load_json(path)
            continue
        if path.name.startswith("filter."):
            filter_type = _type_from_filename(path.name, "filter.")
            by_filter_type[filter_type] = _load_json(path)
            continue
    return base, by_viz_type, by_filter_type, dashboard


BASE_SCHEMA, SCHEMAS_BY_TYPE, FILTER_SCHEMAS_BY_TYPE, DASHBOARD_SCHEMA = _load_all_schemas()


def get_schema(viz_type: str) -> dict:
    """Return the JSON Schema for ``viz_type`` or raise ``KeyError``."""
    try:
        return SCHEMAS_BY_TYPE[viz_type]
    except KeyError as exc:
        known = ", ".join(sorted(SCHEMAS_BY_TYPE)) or "(none loaded)"
        raise KeyError(f"Unknown viz type: {viz_type!r}. Known types: {known}.") from exc


def get_filter_schema(filter_type: str) -> dict:
    """Return the JSON Schema for ``filter_type`` or raise ``KeyError``."""
    try:
        return FILTER_SCHEMAS_BY_TYPE[filter_type]
    except KeyError as exc:
        known = ", ".join(sorted(FILTER_SCHEMAS_BY_TYPE)) or "(none loaded)"
        raise KeyError(f"Unknown filter type: {filter_type!r}. Known types: {known}.") from exc
