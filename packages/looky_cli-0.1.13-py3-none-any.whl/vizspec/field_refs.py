"""Walker for ``x-looky-field-ref`` annotations on viz schemas.

A property in a viz schema is annotated ``x-looky-field-ref: true`` when its
string value is the name of a column in the query result. The walker yields
every (path, field_name) pair the YAML declares so the validator can cross-
check them against the schema returned by ``dry_run_malloy_query``.

``mapping_slot_keys`` returns the canonical role names declared under a viz
type's ``mapping`` property; ``collect_format_keys`` enumerates the keys of
``viz_spec['format']``.
"""

from __future__ import annotations

from typing import Any, Iterator


_FIELD_REF_KEY = "x-looky-field-ref"


def walk_field_refs(schema: Any, data: Any, path: str = "") -> Iterator[tuple[str, str]]:
    """Yield ``(path, field_name)`` for each field-ref reference declared in ``data``.

    A property is a field-ref if its schema fragment carries
    ``x-looky-field-ref: true``. The walker descends into ``object``
    properties and ``array`` items only; ``$ref`` is not followed.
    """
    if not isinstance(schema, dict):
        return

    if schema.get(_FIELD_REF_KEY) is True:
        if isinstance(data, str):
            yield (path or "<root>", data)
        return

    schema_type = schema.get("type")

    if schema_type == "object" and isinstance(data, dict):
        properties = schema.get("properties") or {}
        for key, sub_schema in properties.items():
            if key in data:
                sub_path = f"{path}.{key}" if path else key
                yield from walk_field_refs(sub_schema, data[key], sub_path)
        return

    if schema_type == "array" and isinstance(data, list):
        items_schema = schema.get("items") or {}
        for index, item in enumerate(data):
            sub_path = f"{path}[{index}]"
            yield from walk_field_refs(items_schema, item, sub_path)
        return


def mapping_slot_keys(viz_schema: Any) -> set[str]:
    """Return the top-level keys declared in ``viz_schema.properties.mapping.properties``."""
    if not isinstance(viz_schema, dict):
        return set()
    properties = viz_schema.get("properties") or {}
    mapping_schema = properties.get("mapping") or {}
    if not isinstance(mapping_schema, dict):
        return set()
    mapping_props = mapping_schema.get("properties") or {}
    if not isinstance(mapping_props, dict):
        return set()
    return {key for key in mapping_props.keys() if isinstance(key, str)}


def collect_format_keys(viz_spec: Any) -> Iterator[tuple[str, str]]:
    """Yield ``(path, key)`` for every key declared in ``viz_spec['format']``."""
    if not isinstance(viz_spec, dict):
        return
    fmt = viz_spec.get("format")
    if not isinstance(fmt, dict):
        return
    for key in fmt.keys():
        if isinstance(key, str):
            yield (f"format.{key}", key)
