from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Optional

from cleancloud.core.confidence import ConfidenceLevel
from cleancloud.core.evidence import Evidence
from cleancloud.core.risk import RiskLevel


@dataclass
class Finding:
    provider: str
    rule_id: str
    resource_type: str
    resource_id: str
    region: Optional[str]

    title: str
    summary: str
    reason: str

    risk: RiskLevel
    confidence: ConfidenceLevel

    detected_at: datetime
    details: Dict[str, Any]
    evidence: Evidence

    estimated_monthly_cost_usd: Optional[float] = None
    account_id: Optional[str] = None
    account_name: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "provider": self.provider,
            "rule_id": self.rule_id,
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "region": self.region,
            "title": self.title,
            "summary": self.summary,
            "reason": self.reason,
            "risk": self.risk.value,
            "confidence": self.confidence.value,
            "detected_at": self.detected_at.isoformat(),
            "details": self.details,
            "evidence": self.evidence,
        }
        if self.estimated_monthly_cost_usd is not None:
            d["estimated_monthly_cost_usd"] = self.estimated_monthly_cost_usd
        if self.account_id is not None:
            d["account_id"] = self.account_id
        if self.account_name is not None:
            d["account_name"] = self.account_name
        return d
