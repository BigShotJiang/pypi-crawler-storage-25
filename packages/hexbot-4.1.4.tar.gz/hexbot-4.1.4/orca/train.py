"""
Orca Training Pipeline -- standalone AlphaZero-style self-play trainer.

Extracted from train_dashboard.py: pure training logic with no Flask,
no SocketIO, no HTML. Works as both a library and a CLI.

Library usage:
    from orca.train import OrcaTrainer
    trainer = OrcaTrainer(iterations=100, games_per_iter=30)
    trainer.run()

CLI usage:
    python -m orca.train --iterations 100 --games-per-iter 30
"""

from __future__ import annotations

import argparse
import glob
import math
import multiprocessing
import os
import pickle
import random
import signal
import sys
import threading
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch

from bot import (
    HexNet, MCTS, ReplayBuffer, self_play_game, train_step,
    get_device, BOARD_SIZE, NUM_SIMULATIONS, BATCH_SIZE, LEARNING_RATE, L2_REG,
    TrainingSample, OnnxPredictor, export_onnx,
    POSITION_CATALOG, generate_puzzles, augment_sample,
    load_human_games, load_online_games, find_forced_move,
    encode_state, create_network, BatchedMCTS, BatchedNNAlphaBeta,
    self_play_game_v2, CGameState,
    migrate_checkpoint_5to7, migrate_checkpoint_filters,
    TrainingObserver,
)
from main import HexGame


# ---------------------------------------------------------------------------
# Timestamped print helper
# ---------------------------------------------------------------------------

_builtin_print = print

def _ts_print(*args, **kwargs):
    """Print with HH:MM:SS timestamp prefix."""
    ts = datetime.now().strftime("%H:%M:%S")
    _builtin_print(f"[{ts}]", *args, **kwargs)

# Module-level alias used throughout this file
print = _ts_print


# ---------------------------------------------------------------------------
# PrintObserver -- stdout-based TrainingObserver
# ---------------------------------------------------------------------------

class PrintObserver:
    """Logs training events to stdout with timestamps. Implements TrainingObserver."""

    def __init__(self):
        self._stop = threading.Event()

    def on_iteration_start(self, iteration: int, total: int) -> None:
        pass  # Logged inline by the trainer

    def on_game_complete(self, game_idx: int, total_games: int,
                         move_history: list, result: float,
                         num_samples: int,
                         analysis_data: list = None,
                         game_type: str = 'selfplay',
                         orca_result: float = None) -> None:
        winner = "P0" if result > 0 else ("P1" if result < 0 else "draw")
        tag = f" [{game_type}]" if game_type != 'selfplay' else ""
        if game_type == 'vs_ramora' and orca_result is not None:
            who = "Orca" if orca_result > 0 else ("SealBot" if orca_result < 0 else "draw")
            tag = f" [vs SealBot: {who} wins]"
        print(f"  |  Game {game_idx}/{total_games}: {winner} "
              f"in {len(move_history)} moves ({num_samples} samples){tag}")

    def on_iteration_complete(self, metrics: dict) -> None:
        loss = metrics.get("loss", {})
        print(f"  |  Iteration {metrics.get('iteration', '?')} complete: "
              f"loss={loss.get('total', 0):.4f} "
              f"elo={metrics.get('elo', 0):.0f} "
              f"games={metrics.get('games', 0)} "
              f"samples={metrics.get('samples', 0)}")

    def on_training_complete(self) -> None:
        print("Training complete.")

    def should_stop(self) -> bool:
        return self._stop.is_set()

    def request_stop(self):
        self._stop.set()

    def reset_stop(self):
        self._stop.clear()


# ---------------------------------------------------------------------------
# Curriculum: adaptive MCTS sim count and game count by iteration
# ---------------------------------------------------------------------------

_curriculum_start_time: Optional[float] = None
_curriculum_last_elo: Optional[float] = None
_curriculum_stall_iters: int = 0


def get_curriculum_sims(iteration: int, configured_sims: int = 0) -> int:
    """Return configured sims directly (no curriculum scaling)."""
    if configured_sims <= 0:
        from orca.config import NUM_SIMULATIONS
        configured_sims = NUM_SIMULATIONS
    return configured_sims


def update_curriculum_plateau(current_elo: float) -> None:
    """Track ELO plateaus to trigger curriculum boosts."""
    global _curriculum_last_elo, _curriculum_stall_iters
    if _curriculum_last_elo is not None:
        if abs(current_elo - _curriculum_last_elo) < 15:
            _curriculum_stall_iters += 1
        else:
            _curriculum_stall_iters = 0
    _curriculum_last_elo = current_elo


def get_curriculum_games(iteration: int, base: int) -> int:
    """Return configured games_per_iter directly (no scaling)."""
    return base


# ---------------------------------------------------------------------------
# Self-play workers (run in subprocesses)
# ---------------------------------------------------------------------------

def _self_play_worker_v2(net_state_dict: dict, net_config: str, num_sims: int,
                         games: int, positions: Optional[list] = None,
                         use_alphabeta: bool = True, ab_depth: int = 8) -> list:
    """V2 worker: CGameState + NNAlphaBeta or BatchedMCTS."""
    try:
        from bot import (CGameState, BatchedMCTS, BatchedNNAlphaBeta,
                         self_play_game_v2, create_network,
                         migrate_checkpoint_5to7, migrate_checkpoint_filters)
    except ImportError as e:
        print(f"  |  FATAL: Worker import failed: {e}")
        return []

    import time as _time, os as _os

    import torch as _torch

    t_load = _time.perf_counter()
    net = create_network(net_config)
    # Strip _orig_mod. prefix from torch.compile() state dicts
    raw = {k.replace('_orig_mod.', ''): v for k, v in dict(net_state_dict).items()}
    migrated = migrate_checkpoint_5to7(raw)
    migrated = migrate_checkpoint_filters(migrated)
    net.load_state_dict(migrated, strict=False)
    net.eval()

    # Try GPU in subprocess (MPS/CUDA much faster than CPU)
    _dev = 'cpu'
    try:
        if _torch.backends.mps.is_available():
            net = net.to('mps')
            _dev = 'mps'
    except Exception:
        pass
    try:
        if _dev == 'cpu' and _torch.cuda.is_available():
            net = net.to('cuda')
            _dev = 'cuda'
    except Exception:
        pass

    t_load = _time.perf_counter() - t_load

    if use_alphabeta:
        searcher = BatchedNNAlphaBeta(net, depth=ab_depth, nn_depth=5)
    else:
        searcher = BatchedMCTS(net, num_simulations=num_sims, batch_size=32)

    pid = _os.getpid()
    _builtin_print(f"  |  [Worker {pid}] loaded in {t_load:.1f}s on {_dev}, "
                   f"playing {games} games ({num_sims} sims)")

    results = []
    for i in range(games):
        t_game = _time.perf_counter()
        pos = None
        hints = None
        if positions and i < len(positions):
            entry = positions[i]
            if isinstance(entry, tuple) and len(entry) == 2:
                pos, hints = entry
            elif isinstance(entry, dict):
                pos = entry
        samples, move_history, analysis_data = self_play_game_v2(
            net, searcher, start_position=pos, hint_moves=hints)
        t_game = _time.perf_counter() - t_game
        winner = "P0" if (samples and samples[0].result > 0) else "P1"
        _builtin_print(f"  |  [W{pid}] game {i+1}/{games}: {winner} "
                       f"{len(move_history)}mv {t_game:.1f}s "
                       f"({t_game / max(len(move_history), 1):.2f}s/mv)")
        serialized = []
        for s in samples:
            serialized.append({
                "state": s.encoded_state.numpy(),
                "policy": s.policy_target,
                "player": s.player,
                "result": s.result,
                "threat": s.threat_label,
                "priority": s.priority,
            })
        result_val = samples[0].result if samples else 0.0
        results.append((serialized, [list(m) for m in move_history],
                        result_val, len(samples), analysis_data))
    return results


def _self_play_worker_v1(onnx_path: str, num_sims: int,
                         games: int,
                         positions: Optional[list] = None) -> list:
    """V1 worker: ONNX Runtime for CPU inference."""
    predictor = OnnxPredictor(onnx_path)
    mcts = MCTS(predictor, num_simulations=num_sims)

    results = []
    for i in range(games):
        pos = None
        hints = None
        if positions and i < len(positions):
            entry = positions[i]
            if isinstance(entry, tuple) and len(entry) == 2:
                pos, hints = entry
            elif isinstance(entry, dict):
                pos = entry
        samples, move_history = self_play_game(
            predictor, mcts, start_position=pos, hint_moves=hints)
        serialized = []
        for s in samples:
            serialized.append({
                "state": s.encoded_state.numpy(),
                "policy": s.policy_target,
                "player": s.player,
                "result": s.result,
                "threat": s.threat_label,
                "priority": s.priority,
            })
        result_val = samples[0].result if samples else 0.0
        results.append((serialized, [list(m) for m in move_history],
                        result_val, len(samples)))
    return results


# ---------------------------------------------------------------------------
# ModelVault -- compressed weight storage for past generations
# ---------------------------------------------------------------------------

class ModelVault:
    """Stores compressed (fp16) weights for every evaluated generation."""

    def __init__(self, max_models: int = 200):
        self.models: list = []  # [(iteration, state_dict_cpu_fp16), ...]
        self.max_models = max_models

    def add(self, iteration: int, state_dict: dict):
        compressed = {k: v.detach().cpu().half() for k, v in state_dict.items()}
        self.models.append((iteration, compressed))
        if len(self.models) > self.max_models:
            n = len(self.models)
            keep = {0, n - 1}
            keep.update(range(max(0, n - 20), n))
            step = max(1, n // 50)
            keep.update(range(0, n, step))
            self.models = [self.models[i] for i in sorted(keep)]

    def get_net(self, idx: int, device) -> HexNet:
        """Load a stored model by index, return on device."""
        _, state = self.models[idx]
        state_fp32 = {k: v.float() for k, v in state.items()}
        init_w = state_fp32.get("conv_init.weight")
        if init_w is not None:
            nf = init_w.shape[0]
            nb = 0
            while f"res_blocks.{nb}.conv1.weight" in state_fp32:
                nb += 1
            net = HexNet(num_filters=nf, num_res_blocks=max(nb, 4))
        else:
            net = HexNet(num_filters=64, num_res_blocks=4)
        net.load_state_dict(state_fp32, strict=False)
        net.to(device)
        net.eval()
        return net

    def __len__(self):
        return len(self.models)


# ---------------------------------------------------------------------------
# GenerationalArena -- round-robin ELO evaluation
# ---------------------------------------------------------------------------

class GenerationalArena:
    """Evaluates current model via round-robin + baseline matches.

    Plays against:
    1. Past generations from the model vault (relative improvement)
    2. Random bot (anchored baseline, expected ~500 ELO)
    3. Heuristic bot (anchored baseline, expected ~1000 ELO)

    The combined score gives a more accurate ELO than generations alone.
    """

    def __init__(self, device: torch.device, games_per_opponent: int = 4,
                 num_sims: int = 30, max_opponents: int = 6,
                 baseline_games: int = 4):
        self.device = device
        self.games_per_opponent = games_per_opponent
        self.num_sims = num_sims
        self.max_opponents = max_opponents
        self.baseline_games = baseline_games
        self.matchup_history: list = []

    def evaluate(self, current_net: HexNet, vault: ModelVault,
                 current_elo: float) -> float:
        """Play round-robin + baselines. Returns updated ELO."""
        import math
        current_net.eval()
        mcts_cur = MCTS(current_net, num_simulations=self.num_sims)

        total_wins = total_losses = total_draws = 0
        matchups = {}

        # 1. Play against past generations
        n = len(vault)
        if n > 0:
            opponent_indices = self._select_opponents(n)
            for opp_idx in opponent_indices:
                opp_net = vault.get_net(opp_idx, self.device)
                mcts_opp = MCTS(opp_net, num_simulations=self.num_sims)
                opp_iter = vault.models[opp_idx][0]
                w = l = d = 0
                for g in range(self.games_per_opponent):
                    if g % 2 == 0:
                        r = self._play(mcts_cur, mcts_opp)
                    else:
                        r = -self._play(mcts_opp, mcts_cur)
                    if r > 0: w += 1
                    elif r < 0: l += 1
                    else: d += 1
                matchups[f"gen_{opp_iter}"] = {"w": w, "l": l, "d": d}
                total_wins += w; total_losses += l; total_draws += d
                del opp_net, mcts_opp

        # 2. Play against random baseline (anchored at ~500 ELO)
        if self.baseline_games > 0:
            w_rand, l_rand = self._play_vs_baseline(mcts_cur, 'random')
            matchups["vs_random"] = {"w": w_rand, "l": l_rand, "d": 0}
            total_wins += w_rand; total_losses += l_rand

        # 3. Play against heuristic baseline (anchored at ~1000 ELO)
        if self.baseline_games > 0:
            w_heur, l_heur = self._play_vs_baseline(mcts_cur, 'heuristic')
            matchups["vs_heuristic"] = {"w": w_heur, "l": l_heur, "d": 0}
            total_wins += w_heur; total_losses += l_heur

        # 4. Play against SealBot (anchored at ~1200 ELO + survival bonus)
        # 4. Play against SealBot
        w_ramora = l_ramora = 0
        avg_survival = 0
        try:
            from orca.config import ELO_SEALBOT_GAMES
            n_seal = ELO_SEALBOT_GAMES if ELO_SEALBOT_GAMES > 0 else 0
            if n_seal > 0:
                # Temporarily override baseline_games for SealBot count
                old_bg = self.baseline_games
                self.baseline_games = n_seal
                w_ramora, l_ramora, avg_survival = self._play_vs_ramora(mcts_cur)
                self.baseline_games = old_bg
                matchups["vs_ramora"] = {
                    "w": w_ramora, "l": l_ramora, "d": 0,
                    "avg_survival": round(avg_survival, 1),
                }
                total_wins += w_ramora; total_losses += l_ramora
                print(f"  |  vs SealBot: {w_ramora}W/{l_ramora}L "
                      f"avg_survival={avg_survival:.0f} moves")
        except Exception as e:
            print(f"  |  SealBot eval skipped: {e}")

        self.matchup_history.append(matchups)

        # Compute ELO from combined results
        total_games = total_wins + total_losses + total_draws
        if total_games == 0:
            return current_elo

        # Weighted ELO: generational score + baseline anchoring
        gen_score = (total_wins + 0.5 * total_draws) / total_games
        gen_elo = current_elo + 16 * (gen_score - 0.5) * max(1, n)

        # Anchor from baselines (more stable reference)
        if self.baseline_games > 0:
            rand_wr = w_rand / max(self.baseline_games, 1)
            heur_wr = w_heur / max(self.baseline_games, 1)
            rand_wr = max(0.05, min(0.95, rand_wr))
            heur_wr = max(0.05, min(0.95, heur_wr))
            rand_elo = 500 + 400 * math.log10(rand_wr / (1 - rand_wr))
            heur_elo = 1000 + 400 * math.log10(heur_wr / (1 - heur_wr))

            if w_ramora + l_ramora > 0:
                # Survival-based scoring: even losing, surviving longer = progress
                # Win = 1.0, Loss with 50+ moves = 0.3, Loss with 30 moves = 0.15
                survival_bonus = min(avg_survival / 150.0, 0.4) if avg_survival > 0 else 0
                ramora_wr = w_ramora / max(w_ramora + l_ramora, 1)
                # Add survival bonus: losing at 50 moves counts as ~0.3 instead of 0
                effective_wr = ramora_wr + (1 - ramora_wr) * survival_bonus
                effective_wr = max(0.05, min(0.95, effective_wr))
                ramora_elo = 1200 + 400 * math.log10(effective_wr / (1 - effective_wr))
                new_elo = 0.5 * gen_elo + 0.15 * rand_elo + 0.15 * heur_elo + 0.2 * ramora_elo
            else:
                new_elo = 0.6 * gen_elo + 0.2 * rand_elo + 0.2 * heur_elo
        else:
            new_elo = gen_elo

        return new_elo

    def _play_vs_baseline(self, mcts_cur, baseline_type: str):
        """Play against a baseline bot. Returns (wins, losses)."""
        from orca.encoding import CGameState
        wins = losses = 0
        for g in range(self.baseline_games):
            game = CGameState(max_total_stones=200)
            cur_is_p0 = (g % 2 == 0)
            while not game.is_terminal:
                if (game.current_player == 0) == cur_is_p0:
                    # Current model's turn
                    policy = mcts_cur.search(game, temperature=0.1, add_noise=False)
                    if not policy:
                        break
                    best = max(policy, key=policy.get)
                else:
                    # Baseline's turn
                    if baseline_type == 'random':
                        candidates = game.legal_moves()
                        best = candidates[random.randint(0, len(candidates) - 1)]
                    else:  # heuristic
                        try:
                            from bot import find_forced_move as _ffm
                            forced = _ffm(game)
                            if forced:
                                best = forced
                            else:
                                candidates = game.legal_moves()
                                best = candidates[0] if candidates else (0, 0)
                        except Exception as e:
                            print(f"  |  WARN: Heuristic baseline error: {e}")
                            candidates = game.legal_moves()
                            best = candidates[0] if candidates else (0, 0)
                game.place_stone(*best)
            result = game.result_for(0)  # from P0 perspective
            if not cur_is_p0:
                result = -result  # flip if current model was P1
            if result > 0: wins += 1
            elif result < 0: losses += 1
        return wins, losses

    def _play_vs_ramora(self, mcts_cur):
        """Play against SealBot. Returns (wins, losses, avg_survival).
        avg_survival = average game length when losing (higher = better defense).
        """
        from opponents.ramora.adapter import play_match, create_ramora_bot
        from orca.config import RAMORA_TIME_LIMIT
        ramora = create_ramora_bot(time_limit=RAMORA_TIME_LIMIT)
        wins = losses = 0
        survival_moves = []
        for g in range(self.baseline_games):
            orca_first = (g % 2 == 0)
            result = play_match(mcts_cur, None, ramora, orca_plays_first=orca_first)
            if result['winner'] == 'orca':
                wins += 1
            elif result['winner'] == 'ramora':
                losses += 1
                survival_moves.append(result['num_moves'])
        avg_survival = sum(survival_moves) / max(len(survival_moves), 1)
        return wins, losses, avg_survival

    def _select_opponents(self, n: int) -> list:
        if n <= self.max_opponents:
            return list(range(n))
        selected = {0, n - 1}
        step = max(1, n // (self.max_opponents - 2))
        for i in range(1, self.max_opponents - 1):
            selected.add(min(i * step, n - 1))
        return sorted(selected)

    def _play(self, mcts_p0: MCTS, mcts_p1: MCTS) -> float:
        from orca.encoding import CGameState
        game = CGameState(max_total_stones=200)
        while not game.is_terminal:
            mcts = mcts_p0 if game.current_player == 0 else mcts_p1
            policy = mcts.search(game, temperature=0.1, add_noise=False)
            if not policy:
                break
            best = max(policy, key=policy.get)
            game.place_stone(*best)
        return game.result_for(0)  # +1 if P0 won, -1 if P1 won, 0 draw


# ---------------------------------------------------------------------------
# AutoTuner -- self-improving hyperparameter controller
# ---------------------------------------------------------------------------

class AutoTuner:
    """Observes metrics after each iteration and adjusts hyperparams.
    Rule-based + trend detection. No external ML needed."""

    def __init__(self):
        self.loss_history: list = []
        self.elo_history: list = []
        self.decisions: list = []

        self.params = {
            "lr": 0.001,
            "sims": 10,
            "mix_normal": 0.60,
            "mix_catalog": 0.05,
            "mix_endgame": 0.15,
            "mix_formation": 0.15,
            "mix_sequence": 0.05,
            "hint_blend": 0.3,
            "temp_threshold": 20,
            "train_steps": 200,
        }
        self.param_history: list = []

    def _log(self, iteration: int, msg: str):
        self.decisions.append((iteration, msg))
        print(f"  |  AutoTuner: {msg}")

    def update(self, metrics: dict, iteration: int) -> dict:
        """Observe metrics, return updated params for next iteration."""
        p = self.params.copy()

        total_loss = metrics.get("total_loss", 0)
        self.loss_history.append(total_loss)

        elo = metrics.get("elo")
        if elo is not None:
            self.elo_history.append(elo)

        changes = []

        # MCTS sims: capped at 50 for training
        if p["sims"] > 50:
            p["sims"] = 50
            changes.append("sims->50 (training cap)")

        # Game mix: include tactical positions from the start
        # Endgame/formation positions force blocking and advanced patterns
        p["mix_normal"] = 0.60
        p["mix_endgame"] = 0.15
        p["mix_catalog"] = 0.05
        p["mix_formation"] = 0.15
        p["mix_sequence"] = 0.05

        # Hint blend: decay over time
        p["hint_blend"] = max(0.0, 0.3 - iteration * 0.015)

        # Train steps: increase if loss decreasing and buffer full
        buf_fill = metrics.get("buffer_fill", 0)
        loss_decreasing = (len(self.loss_history) >= 3 and
                           self.loss_history[-1] < self.loss_history[-3] * 0.95)
        if buf_fill > 0.9 and loss_decreasing and p["train_steps"] < 300:
            p["train_steps"] = min(300, p["train_steps"] + 50)
            changes.append(f"train_steps->{p['train_steps']}")

        if changes:
            self._log(iteration, " | ".join(changes))
        else:
            self._log(iteration, "no changes")

        # Normalize mix ratios
        total_mix = sum(p[k] for k in [
            "mix_normal", "mix_catalog", "mix_endgame",
            "mix_formation", "mix_sequence"])
        if abs(total_mix - 1.0) > 0.01:
            for k in ["mix_normal", "mix_catalog", "mix_endgame",
                       "mix_formation", "mix_sequence"]:
                p[k] /= total_mix

        self.params = p
        self.param_history.append(p.copy())
        return p


# ---------------------------------------------------------------------------
# OrcaTrainer -- the core training loop
# ---------------------------------------------------------------------------

class OrcaTrainer:
    """Standalone AlphaZero-style training pipeline.

    Every parameter can be overridden via constructor kwargs, CLI args,
    or by editing orca/config.py. Parameters default to None which means
    "use the value from orca/config.py".

    Example:
        # Use defaults from config.py
        trainer = OrcaTrainer(iterations=100)

        # Override specific params
        trainer = OrcaTrainer(
            iterations=50,
            lr=0.002,
            batch_size=512,
            mcts_sims=100,
            net_config='orca-transformer',
        )

        trainer.run()
    """

    def __init__(
        self,
        # Pipeline
        iterations: int = 999_999,
        games_per_iter: Optional[int] = None,
        train_steps: Optional[int] = None,
        resume: bool = True,
        device: Optional[str] = None,
        num_workers: Optional[int] = None,
        # Network
        net_config: str = "standard",
        # Optimizer
        lr: Optional[float] = None,
        weight_decay: Optional[float] = None,
        # LR scheduler
        scheduler_T0: Optional[int] = None,
        scheduler_Tmult: Optional[int] = None,
        scheduler_eta_min: Optional[float] = None,
        # Search
        mcts_sims: Optional[int] = None,
        mcts_batch_size: Optional[int] = None,
        # Replay buffer
        buffer_size: Optional[int] = None,
        batch_size: Optional[int] = None,
        # ELO evaluation
        elo_every: Optional[int] = None,
        elo_games: Optional[int] = None,
        # Observer
        observer: Optional[TrainingObserver] = None,
        # Vault
        vault_size: int = 200,
        # Feature toggles
        use_curriculum: bool = True,
        use_auto_tuner: bool = True,
        use_adaptive_lr: bool = True,
        use_augmentation: bool = True,
        use_mixed_precision: bool = True,
        grad_clip: float = 1.0,
        # Plateau detection
        plateau_threshold: Optional[float] = None,
        plateau_iters: Optional[int] = None,
        plateau_sim_boost: Optional[int] = None,
        # Arena
        elo_sims: Optional[int] = None,
        elo_max_opponents: Optional[int] = None,
        elo_baseline_games: Optional[int] = None,
    ):
        from orca.config import (
            DEFAULT_GAMES_PER_ITER, DEFAULT_TRAIN_STEPS,
            LEARNING_RATE as CFG_LR, L2_REG as CFG_L2,
            COSINE_T0, COSINE_T_MULT, COSINE_ETA_MIN,
            NUM_SIMULATIONS as CFG_SIMS, MCTS_BATCH_SIZE as CFG_MCTS_BS,
            REPLAY_BUFFER_SIZE as CFG_BUF, BATCH_SIZE as CFG_BATCH,
            ELO_EVAL_EVERY, ELO_EVAL_GAMES, ELO_EVAL_SIMS, ELO_MAX_OPPONENTS,
            ELO_BASELINE_GAMES,
            MAX_WORKERS, VAULT_MAX_MODELS,
            PLATEAU_THRESHOLD, PLATEAU_ITERS, PLATEAU_SIM_BOOST,
        )

        # Pipeline
        self.num_iterations = iterations
        self.games_per_iter = games_per_iter or DEFAULT_GAMES_PER_ITER
        self.train_steps = train_steps or DEFAULT_TRAIN_STEPS
        self.resume = resume
        self.net_config = net_config

        # Optimizer
        self.lr = lr or CFG_LR
        self.weight_decay = weight_decay or CFG_L2

        # Scheduler
        self.scheduler_T0 = scheduler_T0 or COSINE_T0
        self.scheduler_Tmult = scheduler_Tmult or COSINE_T_MULT
        self.scheduler_eta_min = scheduler_eta_min or COSINE_ETA_MIN

        # Search
        self.mcts_sims = mcts_sims or CFG_SIMS
        self.mcts_batch_size = mcts_batch_size or CFG_MCTS_BS

        # Replay
        self.buffer_size = buffer_size or CFG_BUF
        self.batch_size = batch_size or CFG_BATCH

        # ELO
        self.elo_every = elo_every or ELO_EVAL_EVERY
        self.elo_games = elo_games or ELO_EVAL_GAMES
        self.elo_sims = elo_sims or ELO_EVAL_SIMS
        self.elo_max_opponents = elo_max_opponents or ELO_MAX_OPPONENTS
        self.elo_baseline_games = elo_baseline_games if elo_baseline_games is not None else ELO_BASELINE_GAMES

        # Plateau
        self.plateau_threshold = plateau_threshold or PLATEAU_THRESHOLD
        self.plateau_iters = plateau_iters or PLATEAU_ITERS
        self.plateau_sim_boost = plateau_sim_boost or PLATEAU_SIM_BOOST

        # Device + workers
        self.device = torch.device(device) if device else get_device()
        self.observer = observer or PrintObserver()
        cpu_count = multiprocessing.cpu_count()
        self.num_workers = num_workers or min(MAX_WORKERS, max(2, cpu_count - 2))

        # Feature toggles
        self.use_curriculum = use_curriculum
        self.use_auto_tuner = use_auto_tuner
        self.use_adaptive_lr = use_adaptive_lr
        self.use_augmentation = use_augmentation
        self.use_mixed_precision = use_mixed_precision and self.device.type == 'cuda'
        self.grad_clip = grad_clip

        # Initialized in run()
        self.net: Optional[HexNet] = None
        self.model_vault = ModelVault(max_models=vault_size or VAULT_MAX_MODELS)
        self.arena = GenerationalArena(
            self.device,
            games_per_opponent=self.elo_games,
            num_sims=self.elo_sims,
            max_opponents=self.elo_max_opponents,
            baseline_games=self.elo_baseline_games,
        )

        # Simple metrics dict (replaces MetricsStore)
        self.metrics: Dict = {
            "iterations": [],
            "elo_history": [{"iteration": 0, "elo": 1000.0}],
            "current_elo": 1000.0,
            "total_games": 0,
            "is_training": False,
        }

    # -- Checkpoint discovery ------------------------------------------------

    @staticmethod
    def _find_latest_checkpoint() -> Optional[str]:
        ckpts = glob.glob("hex_checkpoint_*.pt")
        if not ckpts:
            return None
        def _iter_num(path):
            try:
                return int(path.replace("hex_checkpoint_", "").replace(".pt", ""))
            except ValueError:
                return -1
        ckpts.sort(key=_iter_num)
        return ckpts[-1]

    # -- Main training loop --------------------------------------------------

    def run(self):
        """Execute the full training pipeline. Blocks until done or stopped."""
        self.metrics["is_training"] = True

        # Build network
        self.net = create_network(self.net_config).to(self.device)
        param_count = sum(p.numel() for p in self.net.parameters())

        print(f"\n{'=' * 60}")
        print(f"  ORCA TRAINING PIPELINE")
        print(f"{'=' * 60}")
        print(f"  Network:     {self.net_config} ({param_count:,} params)")
        print(f"  Device:      {self.device}")
        print(f"  Iterations:  {self.num_iterations}")
        print(f"  Games/iter:  {self.games_per_iter}")
        print(f"  Train steps: {self.train_steps}/iter")

        # Detect C engine
        use_v2 = False
        try:
            CGameState()
            use_v2 = True
            print(f"  Engine:      C engine (v2)")
        except Exception as e:
            print(f"  Engine:      Python (v1) -- C engine unavailable: {e}")

        optimizer = torch.optim.Adam(
            self.net.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            optimizer, T_0=self.scheduler_T0, T_mult=self.scheduler_Tmult,
            eta_min=self.scheduler_eta_min)
        replay_buffer = ReplayBuffer()
        auto_tuner = AutoTuner()

        # Mixed precision (CUDA only)
        grad_scaler = None
        if self.use_mixed_precision:
            grad_scaler = torch.amp.GradScaler('cuda')
            print(f"  Mixed precision: ON (FP16)")
        else:
            print(f"  Mixed precision: OFF ({self.device.type})")

        # -- Resume from checkpoint ------------------------------------------
        start_iteration = 0
        if self.resume:
            start_iteration = self._restore_checkpoint(
                optimizer, scheduler, replay_buffer, auto_tuner)
        else:
            print(f"  Fresh start (--fresh)")

        # torch.compile for CUDA (after checkpoint restore)
        if self.device.type == 'cuda' and hasattr(torch, 'compile'):
            try:
                self.net = torch.compile(self.net, mode='reduce-overhead')
                print(f"  torch.compile: ON")
            except Exception as e:
                print(f"  torch.compile: failed ({e})")

        print(f"  Workers:     {self.num_workers}")
        print(f"  LR:          {optimizer.param_groups[0]['lr']:.5f}")
        print(f"{'=' * 60}\n")

        # -- Iteration loop --------------------------------------------------
        for iteration in range(start_iteration, self.num_iterations):
            if self.observer.should_stop():
                print(f"\n  Training stopped at iteration {iteration}")
                break
            self.observer.on_iteration_start(iteration, self.num_iterations)

            t0 = time.perf_counter()

            # Curriculum
            current_sims = max(auto_tuner.params["sims"],
                               get_curriculum_sims(iteration, self.mcts_sims))
            current_games = get_curriculum_games(iteration, self.games_per_iter)
            current_lr = optimizer.param_groups[0]["lr"]

            hours = ((time.perf_counter() - _curriculum_start_time) / 3600
                     if _curriculum_start_time else 0)
            print(f"  +-- Iter {iteration + 1}/{self.num_iterations} "
                  f"| sims={current_sims} | games={current_games} "
                  f"| lr={current_lr:.4f} | {hours:.1f}h")

            # Load human games on first iteration
            if iteration == 0:
                self._load_human_games(replay_buffer)

            # Export ONNX for workers
            self.net.eval()
            onnx_path = f"/tmp/hex_model_{iteration}.onnx"
            t_exp = time.perf_counter()
            export_onnx(self.net, onnx_path)
            self.net.to(self.device)
            print(f"  |  ONNX export: {time.perf_counter() - t_exp:.1f}s")

            # Split games: SealBot (90%) + self-play (10%)
            collected_samples = []
            total_samples = 0
            try:
                from orca.config import RAMORA_GAME_FRACTION
                n_ramora = max(1, int(current_games * RAMORA_GAME_FRACTION))
                selfplay_games = max(5, current_games - n_ramora)
            except ImportError:
                n_ramora = 0
                selfplay_games = current_games

            # -- PARALLEL: Train on GPU + SealBot games on CPU -----------------
            # Training uses self.net on GPU. SealBot games use a COPY on CPU.
            # They run simultaneously — GPU trains while SealBot's C++ thinks.
            losses = {"total": 0, "value": 0, "policy": 0}
            train_time = 0
            actual_steps = auto_tuner.params.get("train_steps", self.train_steps)

            # Start SealBot games in background thread
            # Uses a cloned network so training can run simultaneously
            t_ramora_start = time.perf_counter()
            seal_thread = None
            seal_result = [None]
            if n_ramora > 0:
                seal_net = create_network(self.net_config)
                # Strip _orig_mod. prefix from torch.compile() state dicts
                sd = {k.replace('_orig_mod.', ''): v for k, v in self.net.state_dict().items()}
                seal_net.load_state_dict(sd, strict=False)
                seal_net.to(self.device)
                seal_net.eval()

                # Save/restore self.net so _play_vs_ramora_batch uses the clone
                _orig_net = self.net
                def _seal_worker():
                    try:
                        self.net = seal_net
                        result = self._play_vs_ramora_batch(
                            n_ramora, current_sims, replay_buffer, collected_samples)
                        seal_result[0] = result
                    except Exception as e:
                        print(f"  |  SealBot thread error: {e}")
                        import traceback; traceback.print_exc()
                        seal_result[0] = {'wins': 0, 'losses': 0, 'draws': 0, 'samples': 0}
                    finally:
                        self.net = _orig_net

                seal_thread = threading.Thread(target=_seal_worker, daemon=True)
                seal_thread.start()

            # GPU training runs while SealBot plays in background
            if len(replay_buffer) >= BATCH_SIZE:
                print(f"  |  Training: {actual_steps} steps on {self.device} "
                      f"(batch={BATCH_SIZE}, buffer={len(replay_buffer)})...")
                t1 = time.perf_counter()
                self.net.train()
                for step in range(actual_steps):
                    losses = train_step(
                        self.net, optimizer, replay_buffer, self.device,
                        grad_scaler=grad_scaler)
                    if (step + 1) % 50 == 0:
                        elapsed = time.perf_counter() - t1
                        print(f"  |    step {step+1}/{actual_steps} "
                              f"loss={losses['total']:.4f} "
                              f"({elapsed:.0f}s, {(step+1)/elapsed:.1f} steps/s)")
                train_time = time.perf_counter() - t1
                sps = actual_steps / train_time if train_time > 0 else 0
                scheduler.step()
                self._last_policy_loss = losses.get('policy', 99.0)
                soft_mode = "SOFT" if self._last_policy_loss < 3.0 else "ONE-HOT"
                print(f"  |  Training done: {train_time:.1f}s ({sps:.0f} steps/s) "
                      f"loss={losses['total']:.4f} "
                      f"(v={losses['value']:.4f} p={losses['policy']:.4f}) "
                      f"lr={optimizer.param_groups[0]['lr']:.6f} "
                      f"[policy targets: {soft_mode}]")
            else:
                print(f"  |  Training skipped: buffer too small "
                      f"({len(replay_buffer)}<{BATCH_SIZE})")

            # Wait for SealBot thread to finish
            if seal_thread is not None:
                seal_thread.join(timeout=900)  # 15 min max
                sr = seal_result[0]
                if sr:
                    # Samples already pushed to replay_buffer by _play_vs_ramora_batch
                    total_samples += sr.get('samples', 0)
                    self.metrics.setdefault('ramora_wins', 0)
                    self.metrics.setdefault('ramora_losses', 0)
                    self.metrics.setdefault('ramora_draws', 0)
                    self.metrics['ramora_wins'] += sr.get('wins', 0)
                    self.metrics['ramora_losses'] += sr.get('losses', 0)
                    self.metrics['ramora_draws'] += sr.get('draws', 0)
            self._last_ramora_time = time.perf_counter() - t_ramora_start

            # -- Self-play (small batch, parallel workers) --------------------
            all_positions = self._build_position_mix(
                selfplay_games, auto_tuner.params)

            t_sp = time.perf_counter()
            sp_result = self._run_self_play(
                use_v2, current_sims, selfplay_games, all_positions,
                onnx_path, replay_buffer)
            t_selfplay = time.perf_counter() - t_sp

            game_idx = sp_result["game_idx"]
            total_samples += sp_result["total_samples"]
            total_moves = sp_result["total_moves"]
            wins = sp_result["wins"]
            collected_samples.extend(sp_result["collected_samples"])

            gps = game_idx / t_selfplay if t_selfplay > 0 else 0
            print(f"  |  Self-play done: {game_idx} games, "
                  f"{total_samples} samples, {t_selfplay:.1f}s "
                  f"({gps:.1f} games/s)")
            print(f"  |  Wins: P0={wins[0]} P1={wins[1]} draw={wins[2]}")

            # Load online games
            self._load_online_games(replay_buffer, collected_samples)

            # Symmetry augmentation
            t_aug = time.perf_counter()
            aug_count = 0
            for sample in collected_samples:
                for aug in augment_sample(sample):
                    replay_buffer.push(aug)
                    aug_count += 1
            total_samples += aug_count
            print(f"  |  Augmentation: +{aug_count} samples "
                  f"({time.perf_counter() - t_aug:.1f}s) "
                  f"-> buffer={len(replay_buffer)}/{replay_buffer.buffer.maxlen}")

            sp_time = time.perf_counter() - t0

            elo_str = ""

            # -- ELO evaluation ------------------------------
            # Always add to vault (even if eval is running)
            self.model_vault.add(iteration + 1, self.net.state_dict())

            # -- ELO evaluation (synchronous — MPS can't do background inference)
            if (len(replay_buffer) >= BATCH_SIZE
                    and (iteration + 1) % self.elo_every == 0
                    and len(self.model_vault) > 1):
                n_opp = min(self.arena.max_opponents,
                            len(self.model_vault) - 1)
                n_eval_games = (n_opp * self.arena.games_per_opponent
                               + self.arena.baseline_games * 2)  # +random +heuristic
                print(f"  |  ELO evaluation ({n_eval_games} games vs "
                      f"{n_opp} generations + baselines, "
                      f"vault={len(self.model_vault)})...")
                t_elo = time.perf_counter()
                try:
                    self.net.eval()
                    new_elo = self.arena.evaluate(
                        self.net, self.model_vault, self.metrics["current_elo"])
                    delta = new_elo - self.metrics["current_elo"]
                    sign = "+" if delta >= 0 else ""
                    self.metrics["current_elo"] = new_elo
                    self.metrics["elo_history"].append(
                        {"iteration": iteration + 1, "elo": round(new_elo, 1)})
                    update_curriculum_plateau(new_elo)
                    elo_str = f" | ELO {new_elo:.0f} ({sign}{delta:.0f})"
                    print(f"  |  ELO: {new_elo:.0f} ({sign}{delta:.0f}) "
                          f"in {time.perf_counter() - t_elo:.1f}s")

                    best = self.metrics.get("best_elo", 1000.0)
                    if new_elo > best:
                        self.metrics["best_elo"] = new_elo
                        self.metrics["best_iteration"] = iteration + 1
                        torch.save({"model_state_dict": self.net.state_dict(),
                                    "iteration": iteration + 1, "elo": new_elo},
                                   "hex_best.pt")
                        print(f"  |  NEW BEST ELO (saved hex_best.pt)")
                except Exception as e:
                    print(f"  |  ELO eval error: {e}")
                    import traceback; traceback.print_exc()

            # -- Metrics & AutoTuner -----------------------------------------
            avg_len = total_moves / max(game_idx, 1)
            total_time = time.perf_counter() - t0
            iter_metrics = {
                "iteration": iteration + 1,
                "games": game_idx,
                "samples": total_samples,
                "wins": wins,
                "self_play_time": round(sp_time, 1),
                "train_time": round(train_time, 1),
                "loss": losses,
                "buffer_size": len(replay_buffer),
                "avg_game_length": round(avg_len, 1),
                "elo": round(self.metrics["current_elo"], 1),
                "workers": self.num_workers,
                "sims": current_sims,
                "lr": round(optimizer.param_groups[0]["lr"], 5),
                "ramora_wins": self.metrics.get("ramora_wins", 0),
                "ramora_losses": self.metrics.get("ramora_losses", 0),
                "ramora_draws": self.metrics.get("ramora_draws", 0),
            }
            self.metrics["iterations"].append(iter_metrics)
            self.metrics["total_games"] = self.metrics.get("total_games", 0) + game_idx
            self.observer.on_iteration_complete(iter_metrics)

            at_metrics = {
                "total_loss": losses.get("total", 0),
                "value_loss": losses.get("value", 0),
                "policy_loss": losses.get("policy", 0),
                "elo": self.metrics["current_elo"],
                "games_per_sec": gps,
                "buffer_fill": len(replay_buffer) / replay_buffer.buffer.maxlen,
            }
            new_params = auto_tuner.update(at_metrics, iteration)
            for pg in optimizer.param_groups:
                pg["lr"] = new_params["lr"]

            # -- Detailed iteration summary ------------------------------------
            import psutil
            ram = psutil.virtual_memory()
            mem_line = f"RAM {ram.percent}% ({ram.used/1e9:.1f}/{ram.total/1e9:.1f}GB)"
            if self.device.type == 'cuda':
                gpu_alloc = torch.cuda.memory_allocated() / 1e9
                gpu_peak = torch.cuda.max_memory_allocated() / 1e9
                gpu_total = getattr(torch.cuda.get_device_properties(0),
                                    'total_memory', 0) / 1e9
                mem_line += f" | GPU {gpu_alloc:.1f}/{gpu_total:.1f}GB (peak {gpu_peak:.1f}GB)"
                torch.cuda.reset_peak_memory_stats()

            t_ramora = getattr(self, '_last_ramora_time', 0)
            print(f"  |  Buffer: {len(replay_buffer):,} samples | {mem_line}")
            print(f"  |  Timing: ramora={t_ramora:.1f}s sp={t_selfplay:.1f}s "
                  f"train={train_time:.1f}s total={total_time:.1f}s")
            print(f"  +-- Iter {iteration + 1} done: {total_time:.1f}s "
                  f"| {game_idx} games | {total_samples} samples{elo_str}")
            print()

            # -- Checkpoint -------------------------------------------------------
            from orca.config import CHECKPOINT_EVERY
            if (iteration + 1) % CHECKPOINT_EVERY == 0:
                self._save_checkpoint(
                    iteration, optimizer, scheduler, replay_buffer, auto_tuner)


        print(f"\n{'=' * 60}")
        print(f"  TRAINING COMPLETE -- {self.num_iterations} iterations")
        print(f"  Final ELO: {self.metrics['current_elo']:.0f}")
        print(f"  Total games: {self.metrics['total_games']}")
        print(f"{'=' * 60}\n")
        self.metrics["is_training"] = False
        self.observer.on_training_complete()

    # -- Helpers -------------------------------------------------------------

    def _restore_checkpoint(self, optimizer, scheduler, replay_buffer,
                            auto_tuner) -> int:
        """Restore from latest checkpoint. Returns start iteration."""
        resume_path = self._find_latest_checkpoint()
        if not resume_path:
            print(f"  No checkpoint found -- starting fresh")
            return 0

        try:
            ckpt = torch.load(resume_path, map_location=self.device,
                              weights_only=False)
            raw_sd = ckpt["model_state_dict"]
            # Strip _orig_mod. prefix from torch.compile() checkpoints
            raw_sd = {k.replace('_orig_mod.', ''): v for k, v in raw_sd.items()}
            migrated_sd = migrate_checkpoint_5to7(raw_sd)
            migrated_sd = migrate_checkpoint_filters(migrated_sd)
            old_shape = raw_sd.get("conv_init.weight", None)
            new_shape = migrated_sd.get("conv_init.weight", None)
            arch_changed = (old_shape is not None and new_shape is not None
                            and old_shape.shape != new_shape.shape)
            self.net.load_state_dict(migrated_sd, strict=False)

            if arch_changed:
                print(f"    Fresh optimizer (architecture migrated)")
            elif "optimizer_state_dict" in ckpt:
                try:
                    optimizer.load_state_dict(ckpt["optimizer_state_dict"])
                except Exception as e:
                    print(f"    WARN: Could not restore optimizer: {e}")
            else:
                print(f"    Fresh optimizer (no optimizer in checkpoint)")

            start_iteration = ckpt.get("iteration", 0) + 1

            # Reset frozen LR
            for pg in optimizer.param_groups:
                if pg["lr"] < 1e-4:
                    pg["lr"] = 0.001
                    print(f"    LR was frozen, reset to 0.001")

            if "scheduler_state_dict" in ckpt:
                try:
                    scheduler.load_state_dict(ckpt["scheduler_state_dict"])
                except Exception as e:
                    print(f"  |  WARN: Scheduler restore failed: {e}")

            # Restore replay buffer
            buf_path = os.path.join(os.path.dirname(resume_path),
                                    "replay_buffer.pkl")
            if os.path.exists(buf_path):
                try:
                    with open(buf_path, "rb") as f:
                        buf_data = pickle.load(f)
                    replay_buffer.buffer.extend(buf_data.get("buffer", []))
                    replay_buffer.priorities.extend(buf_data.get("priorities", []))
                    print(f"    Restored replay buffer: "
                          f"{len(replay_buffer.buffer)} samples")
                except Exception as e:
                    print(f"    Could not restore buffer: {e}")

            # Restore metrics
            if "metrics" in ckpt:
                m = ckpt["metrics"]
                self.metrics["iterations"] = m.get("iterations", [])
                self.metrics["elo_history"] = m.get("elo_history", [])
                self.metrics["current_elo"] = m.get("current_elo", 1000)
                self.metrics["total_games"] = m.get("total_games", 0)

            # Restore AutoTuner
            if "auto_tuner" in ckpt:
                at = ckpt["auto_tuner"]
                auto_tuner.params = at.get("params", auto_tuner.params)
                auto_tuner.params["lr"] = optimizer.param_groups[0]["lr"]
                # Clamp train_steps to current cap
                if auto_tuner.params.get("train_steps", 200) > 300:
                    auto_tuner.params["train_steps"] = 300
                # Keep the tactical mix — don't reset to 100% normal
                auto_tuner.params.setdefault("mix_normal", 0.60)
                auto_tuner.params.setdefault("mix_endgame", 0.15)
                auto_tuner.params.setdefault("mix_formation", 0.15)
                auto_tuner.loss_history = at.get("loss_history", [])
                auto_tuner.elo_history = at.get("elo_history", [])

            current_lr = optimizer.param_groups[0]["lr"]
            print(f"  Resumed from {resume_path} (iter {start_iteration})")
            print(f"    ELO: {self.metrics['current_elo']:.0f}, "
                  f"Games: {self.metrics['total_games']}, "
                  f"LR: {current_lr:.5f}")
            return start_iteration

        except Exception as e:
            print(f"  Failed to resume: {e} -- starting fresh")
            return 0

    def _load_human_games(self, replay_buffer: ReplayBuffer):
        """Load human games into the replay buffer on first iteration."""
        human_path = os.path.join(os.path.dirname(__file__), "..",
                                  "human_games.jsonl")
        if os.path.exists(human_path):
            t0 = time.perf_counter()
            human_samples = load_human_games(human_path, max_games=500,
                                             min_elo=1000)
            for s in human_samples:
                s.priority = 0.8
                replay_buffer.push(s)
            print(f"  |  Human games: {len(human_samples)} samples loaded "
                  f"({time.perf_counter() - t0:.1f}s)")
        else:
            print(f"  |  Human games: not found")

    def _load_online_games(self, replay_buffer: ReplayBuffer,
                           collected_samples: list):
        """Load new online games (human feedback)."""
        online_path = os.path.join(os.path.dirname(__file__), "..",
                                   "online_games.jsonl")
        if not hasattr(self, "_online_lines_read"):
            self._online_lines_read = 0
        try:
            online_samples, new_pos = load_online_games(
                online_path, start_line=self._online_lines_read)
            if online_samples:
                for s in online_samples:
                    replay_buffer.push(s)
                    collected_samples.append(s)
                self._online_lines_read = new_pos
                print(f"  |  Online games: +{len(online_samples)} samples")
        except Exception as e:
            if str(e):
                print(f"  |  WARN: Online games load failed: {e}")

    def _play_vs_ramora_batch(self, n_games: int, current_sims: int,
                              replay_buffer: ReplayBuffer,
                              collected_samples: list) -> dict:
        """Play games against SealBot and collect rich training samples.

        Collects samples from BOTH players:
        - Orca moves: soft MCTS distribution as policy target
        - SealBot moves: expert demonstration (one-hot, lower priority)

        Uses temporal value decay so the value head learns which positions
        are more dangerous (not flat -1.0 for every position in a loss).
        """
        from opponents.ramora.adapter import create_ramora_bot, play_match
        from orca.config import RAMORA_TIME_LIMIT, BLOCKING_PRIORITY_BOOST
        from orca.search import BatchedMCTS
        from orca.encoding import CGameState, c_encode_state, c_compute_threat_label
        from orca.data import TrainingSample
        import numpy as np

        self.net.eval()
        # Use full sims — at 50 sims MCTS is blind (2 plies), producing garbage data
        seal_sims = current_sims
        mcts = BatchedMCTS(self.net, num_simulations=seal_sims, batch_size=64)
        ramora = create_ramora_bot(time_limit=RAMORA_TIME_LIMIT)
        print(f"  |  SealBot games: {n_games} games, {seal_sims} sims, "
              f"{RAMORA_TIME_LIMIT}s/move for SealBot")

        wins = losses = draws = 0
        total_samp = 0
        t0 = time.perf_counter()
        GAMMA = 0.99  # gentle temporal value decay (0.97 was too aggressive)

        for i in range(n_games):
            if self.observer.should_stop():
                break
            orca_first = (i % 2 == 0)
            result = play_match(mcts, self.net, ramora, orca_plays_first=orca_first)

            game = CGameState(max_total_stones=200)
            moves = result['moves']
            orca_policies = result.get('orca_policies', [])
            orca_policy_idx = 0
            n_moves = len(moves)

            # Base game result
            orca_won = result['winner'] == 'orca'
            base_orca_result = 1.0 if orca_won else (-1.0 if result['winner'] == 'ramora' else 0.0)

            samples = []
            for idx, (who, q, r) in enumerate(moves):
                enc, oq, orr = c_encode_state(game)
                threat = c_compute_threat_label(game)

                # Temporal value decay: positions far from end get weaker signal
                distance_from_end = n_moves - idx
                decay = GAMMA ** distance_from_end

                if who == 'orca':
                    # --- Orca's move ---
                    # Auto-switch: one-hot when loss is high (random network),
                    # soft MCTS distribution once network has basic patterns.
                    use_soft = (hasattr(self, '_last_policy_loss') and
                                self._last_policy_loss < 3.0 and
                                orca_policy_idx < len(orca_policies) and
                                orca_policies[orca_policy_idx])

                    policy_target = np.zeros(19 * 19, dtype=np.float32)
                    if use_soft:
                        # Soft MCTS distribution (better signal once network is trained)
                        for (mq, mr), prob in orca_policies[orca_policy_idx].items():
                            mi, mj = mq - oq, mr - orr
                            if 0 <= mi < 19 and 0 <= mj < 19:
                                policy_target[mi * 19 + mj] = prob
                        s = policy_target.sum()
                        if s > 1e-6:
                            policy_target /= s
                        else:
                            policy_target = np.zeros(19 * 19, dtype=np.float32)
                            iq, ir = q - oq, r - orr
                            if 0 <= iq < 19 and 0 <= ir < 19:
                                policy_target[iq * 19 + ir] = 1.0
                    else:
                        # One-hot (safe for random/early network)
                        iq, ir = q - oq, r - orr
                        if 0 <= iq < 19 and 0 <= ir < 19:
                            policy_target[iq * 19 + ir] = 1.0
                    if orca_policy_idx < len(orca_policies):
                        orca_policy_idx += 1

                    # Recency-weighted priority (late game matters more)
                    recency = (idx + 1) / max(n_moves, 1)
                    priority = 1.0 + 2.0 * recency  # 1.0 early → 3.0 late

                    s = TrainingSample(
                        encoded_state=enc,
                        policy_target=policy_target,
                        player=game.current_player,
                        result=max(-1.0, min(1.0, base_orca_result * decay)),
                        threat_label=threat,
                        priority=priority,
                    )
                    samples.append(s)
                    replay_buffer.push(s)
                    collected_samples.append(s)

                else:
                    # --- SealBot's move: skip for now ---
                    # Expert demo samples disabled until loss stabilizes.
                    # They may confuse the value head with mixed perspectives.
                    # TODO: re-enable once loss < 3.0 (same auto-switch as soft targets)
                    pass

                game.place_stone(q, r)

            # --- Hindsight priority boost: find critical blocking moments ---
            try:
                game2 = CGameState(max_total_stones=200)
                prev_orca_sample_idx = None
                for idx, (who, q, r) in enumerate(moves):
                    if who == 'orca':
                        prev_orca_sample_idx = idx
                    elif who == 'ramora' and prev_orca_sample_idx is not None:
                        # After SealBot moves, check if it created threats
                        game2.place_stone(q, r)
                        seal_player = game2._lib.board_get_current_player(game2._ptr)
                        # Check threats BEFORE this move (seal's move created them)
                        wm = game2._lib.board_count_winning_moves(
                            game2._ptr, 1 - seal_player)
                        if wm >= 2:
                            # SealBot created 2+ threats — preceding Orca move was critical
                            for s in samples:
                                if hasattr(s, '_move_idx') and s._move_idx == prev_orca_sample_idx:
                                    s.priority = max(s.priority, BLOCKING_PRIORITY_BOOST)
                        continue
                    game2.place_stone(q, r)
            except Exception:
                pass  # hindsight boost is optional

            total_samp += len(samples)
            w = result['winner']
            if w == 'orca': wins += 1
            elif w == 'ramora': losses += 1
            else: draws += 1

            # Emit for dashboard
            move_list = [(q, r) for _, q, r in moves]
            if w == 'orca':
                result_val = 1.0 if orca_first else -1.0
            elif w == 'ramora':
                result_val = -1.0 if orca_first else 1.0
            else:
                result_val = 0.0
            orca_result_val = 1.0 if w == 'orca' else (-1.0 if w == 'ramora' else 0.0)
            self.observer.on_game_complete(
                game_idx=i + 1, total_games=n_games,
                move_history=move_list, result=result_val,
                num_samples=len(samples),
                analysis_data=None,
                game_type='vs_ramora',
                orca_result=orca_result_val)

        elapsed = time.perf_counter() - t0
        print(f"  |  SealBot done: {n_games} games, {wins}W/{losses}L/{draws}D, "
              f"{total_samp} samples ({elapsed:.1f}s)")
        return {'wins': wins, 'losses': losses, 'draws': draws, 'samples': total_samp}

    def _build_position_mix(self, current_games: int,
                            params: dict) -> list:
        """Build shuffled position list for self-play workers."""
        from bot import GUIDED_POSITIONS, get_guided_positions_by_level

        ap = params
        mix = (ap["mix_normal"], ap["mix_catalog"], ap["mix_endgame"],
               ap["mix_formation"], ap["mix_sequence"])
        n_normal = int(current_games * mix[0])
        n_catalog = int(current_games * mix[1])
        n_endgame = int(current_games * mix[2])
        n_formation = int(current_games * mix[3])
        n_sequence = current_games - n_normal - n_catalog - n_endgame - n_formation

        print(f"  |  Game mix: {n_normal} normal + {n_catalog} catalog + "
              f"{n_endgame} endgame + {n_formation} formation + "
              f"{n_sequence} sequence")

        catalog_keys = list(POSITION_CATALOG.keys())
        catalog_positions = [
            (POSITION_CATALOG[random.choice(catalog_keys)], None)
            for _ in range(n_catalog)
        ]

        l1 = get_guided_positions_by_level(1)
        l2 = get_guided_positions_by_level(2)
        l3 = get_guided_positions_by_level(3)

        endgame_positions = [random.choice(l1) if l1 else (None, None)
                             for _ in range(n_endgame)]
        formation_positions = [random.choice(l2) if l2 else (None, None)
                               for _ in range(n_formation)]
        sequence_positions = [random.choice(l3) if l3 else (None, None)
                              for _ in range(n_sequence)]

        puzzle_positions = generate_puzzles(n_endgame // 2)
        extra_puzzles = [(p, None) for p in puzzle_positions]

        all_positions = (
            catalog_positions + endgame_positions + formation_positions +
            sequence_positions + extra_puzzles[:n_endgame // 2] +
            [(None, None)] * n_normal
        )
        all_positions = all_positions[:current_games]
        while len(all_positions) < current_games:
            all_positions.append((None, None))
        random.shuffle(all_positions)
        return all_positions

    def _run_gpu_self_play(self, current_sims: int, current_games: int,
                           all_positions: list,
                           replay_buffer: ReplayBuffer) -> dict:
        """GPU-accelerated self-play using threaded workers + shared GPU inference.

        Instead of spawning processes that each load the network on CPU,
        this uses threads that share a single GPU inference server.
        The C engine game logic runs on CPU threads while NN inference
        is batched on GPU. 5-10x faster than process-based on CUDA.
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed
        from orca.data import self_play_game_v2
        from orca.search import BatchedMCTS

        print(f"  |  Self-play: threaded ({self.device}, "
              f"{self.num_workers} threads, {current_sims} sims)...")

        # Network stays on GPU - shared by all threads (no per-worker loading)
        self.net.eval()
        mcts = BatchedMCTS(self.net, num_simulations=current_sims, batch_size=64)

        total_samples = 0
        total_moves = 0
        wins = [0, 0, 0]
        game_idx = 0
        collected_samples = []
        results_lock = threading.Lock()

        def _play_one_game(game_num):
            """Play a single game in a thread."""
            import io, contextlib
            entry = all_positions[game_num] if game_num < len(all_positions) else None
            pos, hints = None, None
            if isinstance(entry, tuple) and len(entry) == 2:
                pos, hints = entry
            elif isinstance(entry, dict):
                pos = entry
            with contextlib.redirect_stdout(io.StringIO()):
                samples, moves, *rest = self_play_game_v2(
                    self.net, mcts, start_position=pos, hint_moves=hints)
            analysis = rest[0] if rest else None
            result_val = samples[0].result if samples else 0.0
            return samples, moves, result_val, analysis

        with ThreadPoolExecutor(max_workers=self.num_workers) as pool:
            futures = {pool.submit(_play_one_game, i): i
                       for i in range(current_games)}

            for future in as_completed(futures):
                if self.observer.should_stop():
                    break
                try:
                    samples, moves, result_val, ana_data = future.result()
                except Exception as e:
                    print(f"  |  GPU worker error: {e}")
                    continue

                with results_lock:
                    for s in samples:
                        replay_buffer.push(s)
                        collected_samples.append(s)
                    total_samples += len(samples)
                    total_moves += len(moves)
                    if result_val > 0: wins[0] += 1
                    elif result_val < 0: wins[1] += 1
                    else: wins[2] += 1
                    game_idx += 1
                    self.observer.on_game_complete(
                        game_idx, current_games,
                        [list(m) for m in moves],
                        result_val, len(samples),
                        analysis_data=ana_data)

        return {
            "game_idx": game_idx,
            "total_samples": total_samples,
            "total_moves": total_moves,
            "wins": wins,
            "collected_samples": collected_samples,
        }

    def _run_self_play(self, use_v2: bool, current_sims: int,
                       current_games: int, all_positions: list,
                       onnx_path: str,
                       replay_buffer: ReplayBuffer) -> dict:
        """Dispatch parallel self-play and collect results."""
        # Distribute positions across workers
        chunks = []
        chunk_positions = []
        remaining = current_games
        pos_offset = 0
        for i in range(self.num_workers):
            c = remaining // (self.num_workers - i)
            chunks.append(c)
            chunk_positions.append(all_positions[pos_offset:pos_offset + c])
            pos_offset += c
            remaining -= c

        active_chunks = [c for c in chunks if c > 0]
        print(f"  |  Dispatching {len(active_chunks)} workers: {active_chunks}")

        total_samples = 0
        total_moves = 0
        wins = [0, 0, 0]
        game_idx = 0
        collected_samples = []
        worker_errors = 0

        if use_v2 and self.device.type == 'cuda':
            # Threaded self-play: shared GPU network (CUDA only, MPS has GIL issues)
            return self._run_gpu_self_play(
                current_sims, current_games, all_positions, replay_buffer)

        if use_v2:
            # Strip _orig_mod. prefix from torch.compile() before sending to workers
            net_state = {k.replace('_orig_mod.', ''): v.cpu()
                         for k, v in self.net.state_dict().items()}
            print(f"  |  Self-play: V2 (C engine + MCTS {current_sims} sims)...")

            GAMES_PER_FUTURE = 2

            with ProcessPoolExecutor(max_workers=self.num_workers) as pool:
                futures = []
                flat_positions = []
                for c, pos in zip(chunks, chunk_positions):
                    for gi in range(c):
                        p = pos[gi] if pos and gi < len(pos) else None
                        flat_positions.append(p)
                for i in range(0, len(flat_positions), GAMES_PER_FUTURE):
                    batch_pos = flat_positions[i:i + GAMES_PER_FUTURE]
                    pos_arg = ([p for p in batch_pos]
                               if any(batch_pos) else None)
                    futures.append(
                        pool.submit(_self_play_worker_v2, net_state,
                                    self.net_config, current_sims,
                                    len(batch_pos), pos_arg,
                                    use_alphabeta=False))

                print(f"  |  {len(futures)} futures "
                      f"({GAMES_PER_FUTURE} games each)")

                for future in as_completed(futures):
                    if self.observer.should_stop():
                        break
                    try:
                        batch_results = future.result()
                    except Exception as e:
                        worker_errors += 1
                        print(f"  |  Worker error: {e}")
                        import traceback
                        traceback.print_exc()
                        continue

                    for item in batch_results:
                        # Support both old 4-tuple and new 5-tuple format
                        if len(item) >= 5:
                            ser, move_hist, result_val, n_samp, ana_data = item[:5]
                        else:
                            ser, move_hist, result_val, n_samp = item[:4]
                            ana_data = None
                        for sd in ser:
                            sample = TrainingSample(
                                encoded_state=torch.from_numpy(sd["state"]),
                                policy_target=sd["policy"],
                                player=sd["player"],
                                result=sd["result"],
                                threat_label=sd.get("threat"),
                                priority=sd.get("priority", 1.0),
                            )
                            replay_buffer.push(sample)
                            collected_samples.append(sample)
                        total_samples += n_samp
                        total_moves += len(move_hist)
                        if result_val > 0:
                            wins[0] += 1
                        elif result_val < 0:
                            wins[1] += 1
                        else:
                            wins[2] += 1
                        game_idx += 1
                        self.observer.on_game_complete(
                            game_idx, current_games, move_hist,
                            result_val, n_samp,
                            analysis_data=ana_data)
        else:
            print(f"  |  Self-play: V1 (ONNX Runtime)...")
            with ProcessPoolExecutor(max_workers=self.num_workers) as pool:
                futures = [
                    pool.submit(_self_play_worker_v1, onnx_path,
                                current_sims, c, pos)
                    for c, pos in zip(chunks, chunk_positions) if c > 0
                ]
                for future in as_completed(futures):
                    if self.observer.should_stop():
                        break
                    try:
                        batch_results = future.result()
                    except Exception as e:
                        worker_errors += 1
                        print(f"  |  Worker error: {e}")
                        import traceback
                        traceback.print_exc()
                        continue

                    for item in batch_results:
                        if len(item) >= 5:
                            ser, move_hist, result_val, n_samp, ana_data = item[:5]
                        else:
                            ser, move_hist, result_val, n_samp = item[:4]
                            ana_data = None
                        for sd in ser:
                            sample = TrainingSample(
                                encoded_state=torch.from_numpy(sd["state"]),
                                policy_target=sd["policy"],
                                player=sd["player"],
                                result=sd["result"],
                                threat_label=sd.get("threat"),
                                priority=sd.get("priority", 1.0),
                            )
                            replay_buffer.push(sample)
                            collected_samples.append(sample)
                        total_samples += n_samp
                        total_moves += len(move_hist)
                        if result_val > 0:
                            wins[0] += 1
                        elif result_val < 0:
                            wins[1] += 1
                        else:
                            wins[2] += 1
                        game_idx += 1
                        self.observer.on_game_complete(
                            game_idx, current_games, move_hist,
                            result_val, n_samp,
                            analysis_data=ana_data)

        if worker_errors > 0:
            print(f"  |  {worker_errors} worker(s) failed")

        return {
            "game_idx": game_idx,
            "total_samples": total_samples,
            "total_moves": total_moves,
            "wins": wins,
            "collected_samples": collected_samples,
        }

    def _save_checkpoint(self, iteration: int, optimizer, scheduler,
                         replay_buffer: ReplayBuffer, auto_tuner: AutoTuner):
        """Save model checkpoint and replay buffer."""
        ckpt_path = f"hex_checkpoint_{iteration + 1}.pt"
        torch.save({
            "iteration": iteration,
            "model_state_dict": self.net.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "scheduler_state_dict": scheduler.state_dict(),
            "metrics": {
                "iterations": self.metrics["iterations"],
                "elo_history": self.metrics["elo_history"],
                "current_elo": self.metrics["current_elo"],
                "total_games": self.metrics["total_games"],
            },
            "auto_tuner": {
                "params": auto_tuner.params,
                "loss_history": auto_tuner.loss_history,
                "elo_history": auto_tuner.elo_history,
            },
        }, ckpt_path)

        try:
            buf_path = "replay_buffer.pkl"
            with open(buf_path, "wb") as f:
                pickle.dump({
                    "buffer": list(replay_buffer.buffer),
                    "priorities": list(replay_buffer.priorities),
                }, f, protocol=pickle.HIGHEST_PROTOCOL)
        except Exception as e:
            print(f"  Buffer save failed: {e}")

        print(f"  Checkpoint saved: {ckpt_path} + buffer "
              f"({len(replay_buffer.buffer)} samples)")


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Orca Training Pipeline - AlphaZero-style self-play trainer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m orca.train                          # train with defaults
  python -m orca.train --fresh --iterations 50  # fresh start, 50 iters
  python -m orca.train --lr 0.002 --batch-size 512 --mcts-sims 100
  python -m orca.train --config orca-transformer --device cuda

All parameters default to values in orca/config.py. CLI args override config.
        """)

    # Pipeline
    g = parser.add_argument_group("pipeline")
    g.add_argument("--iterations", type=int, default=999999,
                   help="Training iterations (default: infinite)")
    g.add_argument("--games-per-iter", type=int, default=None,
                   help="Games per iteration (default: from curriculum)")
    g.add_argument("--train-steps", type=int, default=None,
                   help="Gradient steps per iteration (default: 200)")
    g.add_argument("--resume", action="store_true", default=True,
                   help="Resume from latest checkpoint (default)")
    g.add_argument("--fresh", action="store_true",
                   help="Start fresh, ignore existing checkpoints")
    g.add_argument("--workers", type=int, default=None,
                   help="Parallel self-play workers (default: auto)")

    # Network
    g = parser.add_argument_group("network")
    g.add_argument("--config", type=str, default="standard",
                   choices=["fast", "standard", "large", "hybrid", "orca-transformer"],
                   help="Network architecture (default: standard)")
    g.add_argument("--device", type=str, default=None,
                   help="Device: cuda, mps, cpu (default: auto)")

    # Optimizer
    g = parser.add_argument_group("optimizer")
    g.add_argument("--lr", type=float, default=None,
                   help="Learning rate (default: 0.001)")
    g.add_argument("--weight-decay", type=float, default=None,
                   help="L2 regularization (default: 1e-4)")
    g.add_argument("--scheduler-t0", type=int, default=None,
                   help="CosineAnnealing T_0 (default: 50)")
    g.add_argument("--scheduler-tmult", type=int, default=None,
                   help="CosineAnnealing T_mult (default: 2)")
    g.add_argument("--scheduler-eta-min", type=float, default=None,
                   help="CosineAnnealing eta_min (default: 1e-4)")

    # Search
    g = parser.add_argument_group("search")
    g.add_argument("--mcts-sims", type=int, default=None,
                   help="MCTS simulations per move (default: 400)")
    g.add_argument("--mcts-batch", type=int, default=None,
                   help="MCTS batch size for NN eval (default: 64)")

    # Replay buffer
    g = parser.add_argument_group("replay buffer")
    g.add_argument("--buffer-size", type=int, default=None,
                   help="Replay buffer capacity (default: 400000)")
    g.add_argument("--batch-size", type=int, default=None,
                   help="Training batch size (default: 1024)")

    # ELO
    g = parser.add_argument_group("evaluation")
    g.add_argument("--elo-every", type=int, default=None,
                   help="ELO eval frequency in iterations (default: 2)")
    g.add_argument("--elo-games", type=int, default=None,
                   help="Games per ELO evaluation (default: 4)")

    # Plateau detection
    g = parser.add_argument_group("plateau detection")
    g.add_argument("--plateau-threshold", type=float, default=None,
                   help="ELO delta to detect stall (default: 15)")
    g.add_argument("--plateau-iters", type=int, default=None,
                   help="Stall iterations before boosting sims (default: 10)")
    g.add_argument("--plateau-boost", type=int, default=None,
                   help="Extra sims on plateau (default: 50)")

    # Arena
    g = parser.add_argument_group("arena")
    g.add_argument("--elo-sims", type=int, default=None,
                   help="MCTS sims during ELO games (default: 30)")
    g.add_argument("--elo-max-opponents", type=int, default=None,
                   help="Max past versions to play against (default: 6)")

    # Feature toggles
    g = parser.add_argument_group("feature toggles")
    g.add_argument("--no-curriculum", action="store_true",
                   help="Disable adaptive sim/game curriculum (use fixed values)")
    g.add_argument("--no-auto-tuner", action="store_true",
                   help="Disable AutoTuner hyperparameter adjustment")
    g.add_argument("--no-adaptive-lr", action="store_true",
                   help="Disable cosine annealing LR (use fixed LR)")
    g.add_argument("--no-augmentation", action="store_true",
                   help="Disable symmetry data augmentation")
    g.add_argument("--no-ab-hybrid", action="store_true",
                   help="Disable AB pre-check in MCTS (let MCTS handle wins/blocks)")

    args = parser.parse_args()

    # Apply AB hybrid toggle to config at runtime
    if args.no_ab_hybrid:
        try:
            import orca.config
            orca.config.USE_AB_HYBRID = False
        except Exception as e:
            print(f"WARN: Could not disable AB hybrid: {e}")

    trainer = OrcaTrainer(
        iterations=args.iterations,
        games_per_iter=args.games_per_iter,
        train_steps=args.train_steps,
        resume=not args.fresh,
        device=args.device,
        net_config=args.config,
        num_workers=args.workers,
        lr=args.lr,
        weight_decay=args.weight_decay,
        scheduler_T0=args.scheduler_t0,
        scheduler_Tmult=args.scheduler_tmult,
        scheduler_eta_min=args.scheduler_eta_min,
        mcts_sims=args.mcts_sims,
        mcts_batch_size=args.mcts_batch,
        buffer_size=args.buffer_size,
        batch_size=args.batch_size,
        elo_every=args.elo_every,
        elo_games=args.elo_games,
        use_curriculum=not args.no_curriculum,
        use_auto_tuner=not args.no_auto_tuner,
        use_adaptive_lr=not args.no_adaptive_lr,
        use_augmentation=not args.no_augmentation,
        plateau_threshold=args.plateau_threshold,
        plateau_iters=args.plateau_iters,
        plateau_sim_boost=args.plateau_boost,
        elo_sims=args.elo_sims,
        elo_max_opponents=args.elo_max_opponents,
    )

    def _sigint_handler(sig, frame):
        print("\nCtrl+C received, finishing current iteration...")
        trainer.observer.request_stop()

    signal.signal(signal.SIGINT, _sigint_handler)

    trainer.run()


if __name__ == "__main__":
    main()
