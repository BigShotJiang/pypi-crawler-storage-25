from __future__ import annotations

import os
import re
import tomllib
from dataclasses import dataclass
from pathlib import Path

CONFIG_PATH = Path.home() / ".config" / "clickup-work" / "config.toml"


class ConfigError(Exception):
    pass


def add_folder_to_repo(nickname: str, folder_id: str) -> None:
    """Add `folder_id` to `[repos.<nickname>].folder_ids` in the config.

    Preserves the file byte-for-byte outside the single line we touch:
    comments, ordering, other keys, all kept. If `folder_ids` doesn't
    exist yet, a new single-line entry is inserted at the end of the
    block. If it exists (single- or multi-line), it's rewritten as a
    single-line list with the new id appended. Duplicates are no-ops.

    Writes are atomic: we build the new text in memory, parse it with
    `tomllib` to verify validity, write to a `.tmp` sibling, then
    `replace()` it into place. On any failure the original is
    untouched.
    """
    if not folder_id:
        raise ConfigError("folder_id is empty; nothing to add")
    if not CONFIG_PATH.exists():
        raise ConfigError(f"config not found at {CONFIG_PATH}")

    text = CONFIG_PATH.read_text()

    # Find the [repos.<nickname>] header. Allow both quoted and bare form.
    header_re = re.compile(
        rf'^\[\s*repos\.(?:"{re.escape(nickname)}"|{re.escape(nickname)})\s*\]\s*$',
        re.MULTILINE,
    )
    header_match = header_re.search(text)
    if not header_match:
        raise ConfigError(f"[repos.{nickname}] not found in {CONFIG_PATH}")

    # Section body runs from the end of the header line to the next [section]
    # header (any kind) or EOF.
    body_start = header_match.end()
    next_header = re.search(r'^\[', text[body_start:], re.MULTILINE)
    body_end = body_start + next_header.start() if next_header else len(text)

    block = text[body_start:body_end]

    # Existing single-or-multi-line `folder_ids = [...]` line.
    # `[^\]]*` spans newlines since character classes aren't bounded by `.`.
    folder_ids_re = re.compile(
        r'^(\s*folder_ids\s*=\s*)\[([^\]]*)\](.*)$',
        re.MULTILINE,
    )
    fm = folder_ids_re.search(block)

    if fm:
        existing: list[str] = []
        for part in fm.group(2).split(","):
            part = part.strip().strip('"').strip("'")
            if part:
                existing.append(part)
        if folder_id in existing:
            return  # already mapped — no-op, don't churn the file
        existing.append(folder_id)
        formatted = ", ".join(f'"{i}"' for i in existing)
        new_line = f"{fm.group(1)}[{formatted}]{fm.group(3)}"
        new_block = block[:fm.start()] + new_line + block[fm.end():]
    else:
        # Insert before trailing whitespace (so a blank line before the next
        # section stays a blank line).
        head = block.rstrip("\n")
        tail = block[len(head):]
        new_block = head + f'\nfolder_ids  = ["{folder_id}"]' + tail

    new_text = text[:body_start] + new_block + text[body_end:]

    # Round-trip through tomllib — if the rewrite isn't valid TOML, bail out
    # before the user's config is touched.
    try:
        tomllib.loads(new_text)
    except tomllib.TOMLDecodeError as e:
        raise ConfigError(
            f"internal error: folder_ids rewrite produced invalid TOML "
            f"({e}). Config not modified."
        ) from None

    # Atomic write: tmp file, then replace.
    tmp_path = CONFIG_PATH.with_suffix(CONFIG_PATH.suffix + ".tmp")
    tmp_path.write_text(new_text)
    tmp_path.replace(CONFIG_PATH)


_TOKEN_LINE_RE = re.compile(r'^\s*token\s*=\s*.*$', re.MULTILINE)
_TOKEN_FORMAT_RE = re.compile(r"^[A-Za-z0-9_\-]+$")


def save_token(token: str) -> None:
    """Persist a top-level `token = "..."` line in config.toml.

    Creates the file (and parent dir) if needed. If a top-level `token` line
    already exists (above any `[section]` header), it is replaced; otherwise
    a new line is inserted at the top of the file. Sets the file mode to
    0600 so only the owner can read it. Atomic via .tmp + replace; the
    rewrite is round-tripped through tomllib before replacing the original.
    """
    if not token:
        raise ConfigError("token is empty; nothing to save")
    if not _TOKEN_FORMAT_RE.fullmatch(token):
        raise ConfigError(
            "token has unexpected characters (allowed: letters, digits, _, -). "
            "Did stray whitespace get pasted?"
        )

    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    existing = CONFIG_PATH.read_text() if CONFIG_PATH.exists() else ""

    # Only edit the head of the file (everything before the first [section])
    # so we never touch a `token =` that happens to live inside a sub-table.
    first_section = re.search(r'^\[', existing, re.MULTILINE)
    head_end = first_section.start() if first_section else len(existing)
    head = existing[:head_end]
    rest = existing[head_end:]

    if _TOKEN_LINE_RE.search(head):
        new_head = _TOKEN_LINE_RE.sub(f'token = "{token}"', head, count=1)
    elif head.strip():
        new_head = f'token = "{token}"\n' + head
    else:
        new_head = f'token = "{token}"\n' + head

    new_text = new_head + rest

    try:
        tomllib.loads(new_text)
    except tomllib.TOMLDecodeError as e:
        raise ConfigError(
            f"internal error: token rewrite produced invalid TOML "
            f"({e}). Config not modified."
        ) from None

    tmp_path = CONFIG_PATH.with_suffix(CONFIG_PATH.suffix + ".tmp")
    tmp_path.write_text(new_text)
    os.chmod(tmp_path, 0o600)
    tmp_path.replace(CONFIG_PATH)


_WORKLOAD_HEADER_RE = re.compile(r'^\[[ \t]*workload[ \t]*\][ \t]*$', re.MULTILINE)
# Use [ \t]* (not \s*) so the match doesn't eat the leading newline that
# separates the [workload] header from the hours_per_day line. With \s*,
# `^` matched at the newline and \s* consumed it; the rewrite then glued
# `[workload]` straight onto the value, producing invalid TOML.
_HOURS_PER_DAY_LINE_RE = re.compile(
    r'^[ \t]*hours_per_day[ \t]*=.*$',
    re.MULTILINE,
)


def write_workload_capacity(hours_per_day: float) -> None:
    """Persist `[workload].hours_per_day` to config.toml.

    Three cases handled, in order:
      1. The [workload] block exists with an `hours_per_day` line → replace
         that line in place.
      2. The [workload] block exists but no `hours_per_day` → insert one
         inside the existing block.
      3. No [workload] block → append a fresh one at the end of the file.

    Round-trips through tomllib before replacing the original; preserves the
    file's existing mode (0600 if `save_token` set it).
    """
    if hours_per_day <= 0 or hours_per_day > 24:
        raise ConfigError(
            f"hours_per_day must be between 0 and 24 (got {hours_per_day})."
        )

    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    existing = CONFIG_PATH.read_text() if CONFIG_PATH.exists() else ""

    # `:g` drops trailing zeros: 4.0 → "4", 4.5 → "4.5".
    formatted = f"{hours_per_day:g}"
    new_line = f"hours_per_day = {formatted}"

    header_match = _WORKLOAD_HEADER_RE.search(existing)
    if header_match:
        body_start = header_match.end()
        next_header = re.search(r'^\[', existing[body_start:], re.MULTILINE)
        body_end = (
            body_start + next_header.start() if next_header else len(existing)
        )
        block = existing[body_start:body_end]
        line_match = _HOURS_PER_DAY_LINE_RE.search(block)
        if line_match:
            new_block = (
                block[:line_match.start()]
                + new_line
                + block[line_match.end():]
            )
        else:
            head = block.rstrip("\n")
            tail = block[len(head):]
            new_block = head + f"\n{new_line}" + tail
        new_text = existing[:body_start] + new_block + existing[body_end:]
    else:
        if existing and not existing.endswith("\n"):
            existing += "\n"
        sep = "\n" if existing else ""
        new_text = existing + f"{sep}[workload]\n{new_line}\n"

    try:
        tomllib.loads(new_text)
    except tomllib.TOMLDecodeError as e:
        raise ConfigError(
            f"internal error: workload rewrite produced invalid TOML "
            f"({e}). Config not modified."
        ) from None

    tmp_path = CONFIG_PATH.with_suffix(CONFIG_PATH.suffix + ".tmp")
    tmp_path.write_text(new_text)
    # Preserve existing mode (so save_token's 0600 isn't widened by us).
    if CONFIG_PATH.exists():
        try:
            os.chmod(tmp_path, CONFIG_PATH.stat().st_mode & 0o777)
        except OSError:
            pass
    tmp_path.replace(CONFIG_PATH)


def append_repo_block(nickname: str, path: str, base_branch: str) -> None:
    """Append a [repos.<nickname>] block to the config file.

    Creates the file (and its parent dir) if it doesn't exist yet. Preserves
    existing content/ordering/comments — plain text append, no TOML rewrite.
    Raises ConfigError if the nickname is already defined.
    """
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)

    existing = ""
    if CONFIG_PATH.exists():
        existing = CONFIG_PATH.read_text()
        # Detect existing [repos.<nickname>] (allow quoted form too).
        pattern = re.compile(
            rf'^\s*\[\s*repos\.(?:"{re.escape(nickname)}"|{re.escape(nickname)})\s*\]',
            re.MULTILINE,
        )
        if pattern.search(existing):
            raise ConfigError(
                f"a repo named '{nickname}' already exists in {CONFIG_PATH}. "
                f"Pick a different nickname or edit the config directly."
            )

    block = (
        f"\n[repos.{nickname}]\n"
        f'path        = "{path}"\n'
        f'base_branch = "{base_branch}"\n'
    )

    # Ensure a trailing newline before appending.
    if existing and not existing.endswith("\n"):
        existing += "\n"

    CONFIG_PATH.write_text(existing + block)


@dataclass(frozen=True)
class Repo:
    name: str
    path: Path
    base_branch: str  # may be "" to mean auto-detect at runtime
    branch_prefix: str  # may be "" to mean infer from ClickUp task type
    folder_ids: tuple[str, ...]  # ClickUp folder ids that route to this repo
    tags: tuple[str, ...]  # ClickUp tag names that route to this repo (case-insensitive)


# Default daily capacity used when [workload] is absent from config. 8 matches
# a full-time day; part-time users override via `workload set-capacity`.
DEFAULT_HOURS_PER_DAY = 8.0


@dataclass(frozen=True)
class WorkloadConfig:
    hours_per_day: float


@dataclass(frozen=True)
class Config:
    default_repo: str
    team_id: str
    list_id: str
    token: str  # optional; env CLICKUP_API_TOKEN wins when both are set
    repos: dict[str, Repo]  # keyed by nickname
    workload: WorkloadConfig


def validate_repo_path(raw: str) -> Path:
    repo_path = Path(os.path.expanduser(raw)).resolve()
    if not repo_path.exists():
        raise ConfigError(f"repo path does not exist: {repo_path}")
    if not (repo_path / ".git").exists():
        raise ConfigError(f"repo path is not a git repo (no .git dir): {repo_path}")
    return repo_path


def _parse_repo_block(name: str, block: dict) -> Repo:
    raw_path = (block.get("path") or "").strip()
    if not raw_path:
        raise ConfigError(f"[repos.{name}] is missing required `path`")
    # Don't fail config load if a registered repo's directory has gone missing
    # (renamed, moved, on another machine). Repo-touching commands will hit a
    # clear error when they actually try to use it; repo-agnostic commands
    # (login, workload) shouldn't be blocked by an unrelated stale entry.
    path = Path(os.path.expanduser(raw_path)).resolve()
    base = str(block.get("base_branch", "")).strip()
    prefix = str(block.get("branch_prefix", "")).strip().strip("/")
    raw_folders = block.get("folder_ids") or []
    if not isinstance(raw_folders, list):
        raise ConfigError(f"[repos.{name}].folder_ids must be an array of strings")
    folders = tuple(str(f).strip() for f in raw_folders if str(f).strip())
    raw_tags = block.get("tags") or []
    if not isinstance(raw_tags, list):
        raise ConfigError(f"[repos.{name}].tags must be an array of strings")
    tags = tuple(str(t).strip() for t in raw_tags if str(t).strip())
    return Repo(
        name=name,
        path=path,
        base_branch=base,
        branch_prefix=prefix,
        folder_ids=folders,
        tags=tags,
    )


def load() -> Config:
    if not CONFIG_PATH.exists():
        raise ConfigError(
            f"no config yet at {CONFIG_PATH}\n"
            f"\n"
            f"the easy way — register your first repo with one command:\n"
            f"  clickup-work add-repo /path/to/your/repo\n"
            f"\n"
            f"or hand-edit (see config.toml.example in the repo for the format):\n"
            f"  mkdir -p {CONFIG_PATH.parent} && $EDITOR {CONFIG_PATH}"
        )

    with CONFIG_PATH.open("rb") as f:
        raw = tomllib.load(f)

    repos: dict[str, Repo] = {}

    # New shape: [repos.<name>] tables.
    repos_tbl = raw.get("repos") or {}
    if not isinstance(repos_tbl, dict):
        raise ConfigError("`repos` must be a table of named repo blocks")
    for name, block in repos_tbl.items():
        if not isinstance(block, dict):
            raise ConfigError(f"[repos.{name}] must be a table")
        repos[name] = _parse_repo_block(name, block)

    # Back-compat: flat repo_path + base_branch at the top becomes an unnamed
    # repo available only when --repo is omitted or given as a path.
    legacy_path = (raw.get("repo_path") or "").strip()
    if legacy_path and not repos:
        repos["default"] = Repo(
            name="default",
            path=Path(os.path.expanduser(legacy_path)).resolve(),
            base_branch=str(raw.get("base_branch", "")).strip(),
            branch_prefix="",
            folder_ids=(),
            tags=(),
        )

    default_repo = str(raw.get("default_repo", "")).strip()
    if default_repo and default_repo not in repos:
        raise ConfigError(
            f"default_repo='{default_repo}' is not defined under [repos.*]. "
            f"Known names: {', '.join(sorted(repos.keys())) or '(none)'}"
        )

    workload_block = raw.get("workload") or {}
    if not isinstance(workload_block, dict):
        raise ConfigError("[workload] must be a table")
    raw_hours = workload_block.get("hours_per_day", DEFAULT_HOURS_PER_DAY)
    try:
        hours_per_day = float(raw_hours)
    except (TypeError, ValueError):
        raise ConfigError(
            f"[workload].hours_per_day must be a number (got {raw_hours!r}). "
            f"Run `clickup-work workload set-capacity 4` to fix it."
        ) from None
    if hours_per_day <= 0 or hours_per_day > 24:
        raise ConfigError(
            f"[workload].hours_per_day must be between 0 and 24 "
            f"(got {hours_per_day})."
        )

    return Config(
        default_repo=default_repo,
        team_id=str(raw.get("team_id", "")).strip(),
        list_id=str(raw.get("list_id", "")).strip(),
        token=str(raw.get("token", "")).strip(),
        repos=repos,
        workload=WorkloadConfig(hours_per_day=hours_per_day),
    )


def resolve_repo(
    cfg: Config,
    repo_arg: str | None,
) -> Repo:
    """Resolve `--repo` argument (nickname or path) against the loaded config."""
    # Case 1: no --repo → use default_repo from config
    if not repo_arg:
        if not cfg.default_repo:
            if len(cfg.repos) == 1:
                return next(iter(cfg.repos.values()))
            names = ", ".join(sorted(cfg.repos.keys())) or "(none defined)"
            raise ConfigError(
                "no --repo given and no default_repo in config.\n"
                f"available repos: {names}\n"
                "pass --repo <name> or set default_repo in config.toml"
            )
        return cfg.repos[cfg.default_repo]

    # Case 2: nickname lookup
    if repo_arg in cfg.repos:
        return cfg.repos[repo_arg]

    # Case 3: looks like a path → treat as ad-hoc repo, no preset base_branch
    if repo_arg.startswith(("/", "~", "./", "../")):
        return Repo(
            name=Path(repo_arg).name,
            path=validate_repo_path(repo_arg),
            base_branch="",
            branch_prefix="",
            folder_ids=(),
            tags=(),
        )

    names = ", ".join(sorted(cfg.repos.keys())) or "(none defined)"
    raise ConfigError(
        f"unknown repo: '{repo_arg}'\n"
        f"known names: {names}\n"
        f"(or pass an absolute/~ path)"
    )
