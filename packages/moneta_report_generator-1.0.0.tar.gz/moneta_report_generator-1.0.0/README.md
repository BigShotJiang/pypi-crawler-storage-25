# Moneta Report Generator

Professional-grade Excel financial report generator for the Moneta bank statement analysis platform.

## Features

- Converts JSON analysis output into a beautifully styled, multi-tab Excel workbook
- Moneta branded design system with traffic-light risk visualization
- 12 specialized tabs covering every aspect of financial analysis
- Resilient error handling - reports always generate even with missing data
- Print/PDF optimized with proper page setup
- Hyperlinked navigation system across all tabs
- Indonesia-friendly number formatting (IDR)

## Quick Start

```bash
pip install -e .
moneta-report --input report_output.json --output MonetaReport.xlsx
```

## Docker

```bash
docker build -t moneta-report-generator .
docker run -v $(pwd)/data:/data moneta-report-generator --input /data/report_output.json --output /data/MonetaReport.xlsx
```

## Project Structure

```
moneta/
  __init__.py          # Package init
  cli.py               # Command-line interface
  engine.py            # Main report generation engine
  design.py            # Moneta design system (colors, fonts, styles)
  tabs/
    __init__.py
    cover.py           # Cover sheet
    account_summary.py # Account Summary tab
    eod_detailed.py    # EOD Balance Detailed (per account)
    eod_combined.py    # EOD Balance Combined (all accounts)
    liquidity.py       # Liquidity Health Metrics
    txn_summary.py     # Transaction Summary
    pl_actual.py       # P&L from Transactions (Actual + Annualized)
    pl_forecast.py     # P&L Forecast
    balance_sheet.py   # Balance Sheet
    metrics.py         # Financial Metrics / Ratios
    dscr.py            # DSCR & DBR
    fraud.py           # Fraud Analysis
tests/
  test_engine.py       # Unit + integration tests
```
