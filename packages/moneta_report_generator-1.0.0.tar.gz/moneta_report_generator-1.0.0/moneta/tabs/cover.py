"""
Cover Sheet
===========
The first tab the user sees.  Shows:
- Moneta brand bar
- Company name (account holder)
- Statement period
- Report generation timestamp
- Table of contents with hyperlinks to every tab
- Fraud probability score with traffic-light badge
"""

from datetime import datetime
from openpyxl.styles import Alignment, Border, Side

from moneta.design import (
    Colors, FONT_COVER_COMPANY, FONT_COVER_DETAIL, FONT_GOLD_TITLE,
    FONT_SECTION, FONT_SUBTITLE, FONT_NAV, FONT_BODY, FONT_BODY_BOLD,
    FONT_SMALL, FONT_TITLE, FONT_HEADER, FONT_KPI_VALUE,
    FILL_NAVY, FILL_DARK_BLUE, FILL_GOLD, FILL_WHITE, FILL_PALE_BLUE,
    FILL_LIGHT_BLUE, FILL_GREEN, FILL_AMBER, FILL_RED,
    FONT_GREEN, FONT_AMBER, FONT_RED,
    BORDER_THIN, ALIGN_CENTER, ALIGN_LEFT, ALIGN_RIGHT,
    TAB_NAMES, setup_print, safe_get, auto_width, _sheet_hyperlink
)


def build(wb, data):
    """Build the Cover sheet."""
    ws = wb.active
    ws.title = "Cover"
    ws.sheet_properties.tabColor = Colors.GOLD

    # Column widths
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 40
    ws.column_dimensions["C"].width = 35
    ws.column_dimensions["D"].width = 20
    ws.column_dimensions["E"].width = 20
    ws.column_dimensions["F"].width = 3

    # --- Brand bar ---
    for col in range(1, 7):
        c = ws.cell(row=1, column=col)
        c.fill = FILL_NAVY
        c = ws.cell(row=2, column=col)
        c.fill = FILL_NAVY

    ws.merge_cells("B1:E1")
    ws.row_dimensions[1].height = 10
    ws.row_dimensions[2].height = 50

    ws.merge_cells("B2:E2")
    title_cell = ws.cell(row=2, column=2, value="MONETA")
    title_cell.font = FONT_GOLD_TITLE
    title_cell.alignment = ALIGN_CENTER

    # Gold accent line
    for col in range(1, 7):
        c = ws.cell(row=3, column=col)
        c.fill = FILL_GOLD
    ws.row_dimensions[3].height = 4

    # --- Company info ---
    row = 5
    ws.row_dimensions[row].height = 40
    ws.merge_cells(f"B{row}:E{row}")
    company_name = _extract_company_name(data)
    cell = ws.cell(row=row, column=2, value=company_name)
    cell.font = FONT_COVER_COMPANY
    cell.alignment = ALIGN_CENTER

    row = 6
    ws.merge_cells(f"B{row}:E{row}")
    subtitle = ws.cell(row=row, column=2, value="Bank Statement Analysis Report")
    subtitle.font = FONT_SUBTITLE
    subtitle.alignment = ALIGN_CENTER

    # --- Key details ---
    row = 8
    details = [
        ("Statement Period", _extract_period(data)),
        ("Report Generated", datetime.now().strftime("%d %B %Y, %H:%M")),
        ("Currency", _extract_currency(data)),
        ("Accounts Analyzed", _extract_account_count(data)),
    ]

    for label, value in details:
        ws.cell(row=row, column=2, value=label).font = FONT_BODY
        ws.cell(row=row, column=2).alignment = ALIGN_RIGHT
        vc = ws.cell(row=row, column=3, value=value)
        vc.font = FONT_BODY_BOLD
        vc.alignment = ALIGN_LEFT
        row += 1

    # --- Fraud probability score ---
    row += 1
    ws.merge_cells(f"B{row}:C{row}")
    fp_label = ws.cell(row=row, column=2, value="Overall Fraud Probability Score")
    fp_label.font = FONT_BODY_BOLD
    fp_label.alignment = ALIGN_CENTER

    fraud_prob = safe_get(data, "fraud", "fraud_probability", default=None)
    row += 1
    ws.merge_cells(f"B{row}:C{row}")
    ws.row_dimensions[row].height = 35
    if fraud_prob is not None:
        pct = fraud_prob * 100 if fraud_prob <= 1 else fraud_prob
        score_cell = ws.cell(row=row, column=2, value=f"{pct:.1f}%")
        score_cell.font = FONT_KPI_VALUE
        score_cell.alignment = ALIGN_CENTER
        if pct < 20:
            score_cell.fill = FILL_GREEN
        elif pct < 50:
            score_cell.fill = FILL_AMBER
        else:
            score_cell.fill = FILL_RED
    else:
        ws.cell(row=row, column=2, value="N/A").font = FONT_KPI_VALUE

    # --- Table of contents ---
    row += 2
    ws.merge_cells(f"B{row}:E{row}")
    toc_header = ws.cell(row=row, column=2, value="Report Contents")
    toc_header.font = FONT_SECTION
    toc_header.fill = FILL_DARK_BLUE
    toc_header.alignment = ALIGN_LEFT
    for c in range(3, 6):
        ws.cell(row=row, column=c).fill = FILL_DARK_BLUE

    row += 1
    tab_descriptions = {
        "Cover": "This page - report overview and navigation",
        "Account Summary": "Bank account details and statement metadata",
        "EOD Detailed": "Daily end-of-day balances per account with business/non-business split",
        "EOD Combined": "Combined daily end-of-day balances across all accounts",
        "Liquidity": "Liquidity health metrics, runway analysis and monitoring alerts",
        "Transaction Summary": "Credits, debits, business vs non-business transaction breakdown",
        "P&L Actual": "Profit & loss derived from bank transactions (actual and annualized)",
        "P&L Forecast": "Forward-looking P&L forecast (6 months)",
        "Balance Sheet": "Reconstructed balance sheet from bank statement data",
        "Financial Metrics": "Key financial ratios - margins, current ratio, quick ratio",
        "DSCR & DBR": "Debt service coverage ratio and debt burden ratio analysis",
        "Fraud Analysis": "Fraud indicators, risk flags and suspicious transaction details",
    }

    for i, tab_name in enumerate(TAB_NAMES):
        is_alt = i % 2 == 1
        fill = FILL_PALE_BLUE if is_alt else FILL_WHITE

        num_cell = ws.cell(row=row, column=2, value=f"{i + 1}.")
        num_cell.font = FONT_BODY
        num_cell.fill = fill
        num_cell.alignment = ALIGN_RIGHT
        num_cell.border = BORDER_THIN

        link_cell = ws.cell(row=row, column=3, value=tab_name)
        link_cell.font = FONT_NAV
        link_cell.fill = fill
        link_cell.alignment = ALIGN_LEFT
        link_cell.border = BORDER_THIN
        link_cell.hyperlink = _sheet_hyperlink(tab_name)

        desc_cell = ws.cell(row=row, column=4, value=tab_descriptions.get(tab_name, ""))
        desc_cell.font = FONT_SMALL
        desc_cell.fill = fill
        desc_cell.alignment = ALIGN_LEFT
        desc_cell.border = BORDER_THIN

        ws.cell(row=row, column=5).fill = fill
        ws.cell(row=row, column=5).border = BORDER_THIN

        row += 1

    # --- Footer ---
    row += 2
    ws.merge_cells(f"B{row}:E{row}")
    footer = ws.cell(row=row, column=2,
                     value="This report is generated by Moneta and is confidential. "
                           "Data derived from bank statements provided by the account holder.")
    footer.font = FONT_SMALL
    footer.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # Print setup
    setup_print(ws, landscape=False, title="Moneta Report - Cover")

    return ws


def _extract_company_name(data):
    """Extract company name from data."""
    try:
        detailed = safe_get(data, "eod", "Detailed")
        if detailed and len(detailed) > 0:
            return detailed[0].get("Account Holder", "Company Name")
    except Exception:
        pass
    return "Company Name"


def _extract_period(data):
    """Extract statement period."""
    try:
        acct = safe_get(data, "account_summary")
        if acct and isinstance(acct, str):
            lines = acct.strip().split("\n")
            for line in lines:
                if "Period - From" in line:
                    parts = line.split()
                    return f"{parts[-2]} to {parts[-1]}" if len(parts) >= 3 else "See Account Summary"
        # Try from detailed data
        detailed = safe_get(data, "eod", "Detailed")
        if detailed:
            months = []
            for acct_data in detailed:
                for month_data in acct_data.get("Data", []):
                    months.append(month_data.get("Month", ""))
            if months:
                return f"{months[0].replace('_', ' ')} to {months[-1].replace('_', ' ')}"
    except Exception:
        pass
    return "See Account Summary"


def _extract_currency(data):
    """Extract currency."""
    try:
        acct = safe_get(data, "account_summary")
        if acct and isinstance(acct, str) and "IDR" in acct:
            return "IDR (Indonesian Rupiah)"
    except Exception:
        pass
    return "IDR (Indonesian Rupiah)"


def _extract_account_count(data):
    """Count analyzed accounts."""
    try:
        detailed = safe_get(data, "eod", "Detailed")
        if detailed:
            return str(len(detailed))
    except Exception:
        pass
    return "N/A"
