"""
Transaction Summary Tab
=======================
Three sections:
1. Transaction Summary (Total Credits/Debits, Business Credits/Debits, Avg/Min EOD)
2. Business Transaction categories
3. Non-Business Transaction categories
"""

from moneta.design import (
    apply_header_row, apply_section_title, apply_data_row, apply_total_row,
    write_nav_bar, auto_width, setup_print, freeze_pane,
    safe_get, parse_number, NUM_FMT_IDR, Colors,
    FONT_BODY, FONT_BODY_BOLD
)


def build(wb, data):
    """Build the Transaction Summary tab."""
    ws = wb.create_sheet("Transaction Summary")
    ws.sheet_properties.tabColor = Colors.BLUE

    row = 1
    write_nav_bar(ws, row, "Transaction Summary")

    txn = safe_get(data, "transaction_summary", default={})

    # --- Section 1: Transaction Summary ---
    row = 3
    apply_section_title(ws, row, "Transaction Summary", col_span=6)
    row += 1

    summary_raw = txn.get("Transaction Summary", "")
    if summary_raw:
        row = _parse_summary_table(ws, row, summary_raw)
    else:
        ws.cell(row=row, column=1, value="No transaction summary data available.")
        row += 1

    # --- Section 2: Business Transactions ---
    row += 1
    apply_section_title(ws, row, "Business Transactions by Category", col_span=6)
    row += 1

    biz_raw = txn.get("Business Transaction", "")
    if biz_raw:
        row = _parse_category_table(ws, row, biz_raw)
    else:
        ws.cell(row=row, column=1, value="No business transaction data available.")
        row += 1

    # --- Section 3: Non-Business Transactions ---
    row += 1
    apply_section_title(ws, row, "Non-Business Transactions", col_span=6)
    row += 1

    nonbiz_raw = txn.get("Non-Business Transaction", "")
    if nonbiz_raw:
        row = _parse_category_table(ws, row, nonbiz_raw)
    else:
        ws.cell(row=row, column=1, value="No non-business transaction data available.")
        row += 1

    auto_width(ws, min_width=14, max_width=30)
    setup_print(ws, landscape=True, title="Moneta Report - Transaction Summary")
    freeze_pane(ws, "A4")
    return ws


def _parse_summary_table(ws, start_row, text):
    """Parse the transaction summary table."""
    lines = text.strip().split("\n")
    if not lines:
        return start_row

    # Header: "Category                Category      OCT_2025      NOV_2025      DEC_2025"
    header_parts = lines[0].split()
    # Find month columns
    months = []
    for p in header_parts:
        if "_" in p and any(m in p for m in ["JAN", "FEB", "MAR", "APR", "MAY", "JUN",
                                              "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]):
            months.append(p.replace("_", " "))

    row = start_row
    headers = ["Category"] + months
    apply_header_row(ws, row, headers)
    row += 1

    for i, line in enumerate(lines[1:]):
        parts = line.split()
        if not parts:
            continue

        # Skip index number at start
        start_idx = 0
        if parts[0].isdigit():
            start_idx = 1

        # Extract numeric values from end
        num_values = []
        remaining = list(parts[start_idx:])
        for _ in range(len(months)):
            if remaining:
                val = parse_number(remaining[-1])
                num_values.insert(0, val)
                remaining.pop()

        category = " ".join(remaining)
        row_data = [category] + num_values

        apply_data_row(ws, row, row_data, is_alt=(i % 2 == 1),
                       bold_first=True, num_fmt=NUM_FMT_IDR)
        row += 1

    return row


def _parse_category_table(ws, start_row, text):
    """Parse business/non-business category tables."""
    lines = text.strip().split("\n")
    if not lines:
        return start_row

    # Header: "   No                      Category  Total Credit   Total Debit"
    row = start_row
    headers = ["No", "Category", "Total Credit", "Total Debit"]
    apply_header_row(ws, row, headers)
    row += 1

    for i, line in enumerate(lines[1:]):
        parts = line.split()
        if not parts:
            continue

        # Skip if header repeat
        if "No" in parts and "Category" in parts:
            continue

        # First is index, last two are amounts
        if len(parts) >= 3:
            idx = parts[0]
            if not idx.isdigit():
                continue
            debit = parse_number(parts[-1])
            credit = parse_number(parts[-2])
            category = " ".join(parts[1:-2])

            row_data = [int(idx), category, credit, debit]
            apply_data_row(ws, row, row_data, is_alt=(i % 2 == 1),
                           bold_first=False, num_fmt=NUM_FMT_IDR)
            row += 1

    return row
