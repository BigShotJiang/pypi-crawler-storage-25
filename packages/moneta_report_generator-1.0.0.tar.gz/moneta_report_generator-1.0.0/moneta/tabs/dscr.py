"""
DSCR & DBR Tab
==============
Debt Service Coverage Ratio and Debt Burden Ratio analysis.
Monthly table with traffic-light formatting.
"""

from moneta.design import (
    apply_header_row, apply_section_title, apply_data_row,
    write_nav_bar, auto_width, setup_print, freeze_pane,
    traffic_light_cell, safe_get, parse_number,
    NUM_FMT_RATIO, Colors,
    FONT_BODY, FONT_BODY_BOLD, FILL_WHITE, FILL_PALE_BLUE,
    ALIGN_LEFT, ALIGN_CENTER, BORDER_THIN
)


def build(wb, data):
    """Build the DSCR & DBR tab."""
    ws = wb.create_sheet("DSCR & DBR")
    ws.sheet_properties.tabColor = Colors.DARK_BLUE

    row = 1
    write_nav_bar(ws, row, "DSCR & DBR")

    row = 3
    apply_section_title(ws, row, "Debt Service Coverage Ratio & Debt Burden Ratio", col_span=8)
    row += 1

    raw = safe_get(data, "dscr_dbr", default="")

    if isinstance(raw, str) and raw.strip():
        row = _parse_dscr_table(ws, row, raw)
    else:
        ws.cell(row=row, column=1, value="No DSCR/DBR data available.")

    auto_width(ws, min_width=14, max_width=35)
    setup_print(ws, landscape=True, title="Moneta Report - DSCR & DBR")
    freeze_pane(ws, "A5")
    return ws


def _parse_dscr_table(ws, start_row, text):
    """Parse the DSCR/DBR table."""
    lines = text.strip().split("\n")
    if not lines:
        return start_row

    # Header line
    header_line = lines[0]
    # Extract column names
    header_parts = []
    current = ""
    in_spaces = True
    for ch in header_line:
        if ch == " ":
            if current:
                in_spaces = True
        else:
            if in_spaces and current:
                header_parts.append(current.strip())
                current = ""
            in_spaces = False
        current += ch

    if current.strip():
        header_parts.append(current.strip())

    # Simplified: split by double-space
    headers = [h.strip() for h in header_line.split("  ") if h.strip()]

    row = start_row
    apply_header_row(ws, row, headers)
    row += 1

    for i, line in enumerate(lines[1:]):
        if not line.strip() or line.strip().startswith("["):
            continue

        parts = [p.strip() for p in line.split("  ") if p.strip()]
        if not parts:
            continue

        # Skip index
        if parts[0].isdigit():
            parts = parts[1:]

        # Write month label
        if parts:
            label_cell = ws.cell(row=row, column=1, value=parts[0].replace("_", " "))
            label_cell.font = FONT_BODY_BOLD
            label_cell.fill = FILL_PALE_BLUE if (i % 2 == 1) else FILL_WHITE
            label_cell.border = BORDER_THIN
            label_cell.alignment = ALIGN_LEFT

        # Write values with traffic lights
        for j, val_str in enumerate(parts[1:]):
            col = 2 + j
            val = parse_number(val_str)
            header_name = headers[j + 1] if (j + 1) < len(headers) else ""

            cell = ws.cell(row=row, column=col)
            cell.border = BORDER_THIN
            cell.alignment = ALIGN_CENTER

            # Determine if this is DSCR or DBR by header name
            if "DSCR" in header_name or "Coverage" in header_name:
                # DSCR: higher is better. <1.2 amber, <1.0 red
                cell.value = val
                cell.number_format = '0.00"x"'
                traffic_light_cell(ws, row, col, val,
                                   thresholds=(1.2, 1.0), reverse=True)
                if isinstance(val, (int, float)):
                    ws.cell(row=row, column=col).number_format = '0.00"x"'
            elif "DBR" in header_name or "Burden" in header_name:
                # DBR: lower is better. >0.4 amber, >0.6 red
                cell.value = val
                cell.number_format = '0.00"x"'
                traffic_light_cell(ws, row, col, val,
                                   thresholds=(0.5, 1.0), reverse=False)
                if isinstance(val, (int, float)):
                    ws.cell(row=row, column=col).number_format = '0.00"x"'
            else:
                cell.value = val_str
                cell.fill = FILL_PALE_BLUE if (i % 2 == 1) else FILL_WHITE

        row += 1

    return row
