"""
EOD Detailed Tab
================
Shows daily end-of-day balances for each bank account separately,
with columns: Month, Day, Beginning Balance, Debit(business),
Debit(non-business), Credit(business), Credit(non-business), Ending Balance.
One section per account, each with its own header.
"""

from moneta.design import (
    apply_header_row, apply_section_title, apply_data_row, apply_total_row,
    write_nav_bar, auto_width, setup_print, freeze_pane,
    safe_get, NUM_FMT_IDR, Colors, FONT_BODY, FILL_WHITE,
    ALIGN_CENTER, BORDER_THIN
)


COLUMNS = [
    "Month", "Day", "Beginning Balance",
    "Debit, business", "Debit, non-business",
    "Credit, business", "Credit, non-business",
    "Ending Balance"
]


def build(wb, data):
    """Build the EOD Detailed tab."""
    ws = wb.create_sheet("EOD Detailed")
    ws.sheet_properties.tabColor = Colors.BLUE

    row = 1
    write_nav_bar(ws, row, "EOD Detailed")

    detailed = safe_get(data, "eod", "Detailed", default=[])

    if not detailed:
        row = 3
        apply_section_title(ws, row, "End-of-Day Balances - Detailed", col_span=8)
        row += 1
        ws.cell(row=row, column=1, value="No detailed EOD data available.")
        auto_width(ws)
        setup_print(ws, title="Moneta Report - EOD Detailed")
        return ws

    row = 3

    for acct_idx, account in enumerate(detailed):
        holder = account.get("Account Holder", "Unknown")
        bank = account.get("Bank", "Unknown").upper()
        acct_num = account.get("Account Number", "N/A")

        title = f"{holder} - {bank} ({acct_num})"
        apply_section_title(ws, row, title, col_span=8)
        row += 1

        apply_header_row(ws, row, COLUMNS)
        row += 1

        account_data = account.get("Data", [])
        row_count = 0

        for month_block in account_data:
            month_name = month_block.get("Month", "")
            daily = month_block.get("Daily", [])

            for day_entry in daily:
                for day_num, values in day_entry.items():
                    row_values = [
                        month_name,
                        int(day_num),
                        values.get("Beginning Balance", 0),
                        values.get("Debit, business", 0),
                        values.get("Debit, non-business", 0),
                        values.get("Credit, business", 0),
                        values.get("Credit, non-business", 0),
                        values.get("Ending Balance", 0),
                    ]
                    apply_data_row(
                        ws, row, row_values,
                        is_alt=(row_count % 2 == 1),
                        bold_first=True,
                        num_fmt=NUM_FMT_IDR
                    )
                    row += 1
                    row_count += 1

        row += 1  # space between accounts

    auto_width(ws, min_width=12, max_width=22)
    setup_print(ws, landscape=True, title="Moneta Report - EOD Detailed")
    freeze_pane(ws, "A5")
    return ws
