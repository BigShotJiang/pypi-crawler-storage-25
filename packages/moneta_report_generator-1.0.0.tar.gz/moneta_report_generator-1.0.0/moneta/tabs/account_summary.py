"""
Account Summary Tab
===================
Displays bank account metadata: bank name, account number, account type,
currency, holder name, statement period, etc.
"""

from moneta.design import (
    apply_header_row, apply_section_title, apply_data_row,
    write_nav_bar, auto_width, setup_print, freeze_pane,
    safe_get, FONT_TITLE, FILL_WHITE, ALIGN_LEFT, ALIGN_CENTER,
    BORDER_THIN, Colors
)


def build(wb, data):
    """Build the Account Summary tab."""
    ws = wb.create_sheet("Account Summary")
    ws.sheet_properties.tabColor = Colors.NAVY

    row = 1
    write_nav_bar(ws, row, "Account Summary")

    row = 3
    apply_section_title(ws, row, "Account Summary", col_span=6)

    raw = safe_get(data, "account_summary", default="")

    if isinstance(raw, str) and raw.strip():
        row = _parse_text_table(ws, row + 1, raw)
    elif isinstance(raw, dict):
        row = _build_from_dict(ws, row + 1, raw)
    elif isinstance(raw, list):
        row = _build_from_list(ws, row + 1, raw)
    else:
        row += 1
        ws.cell(row=row, column=1, value="No account summary data available.")

    auto_width(ws, min_width=12, max_width=30)
    setup_print(ws, landscape=True, title="Moneta Report - Account Summary")
    freeze_pane(ws, "A4")
    return ws


def _parse_text_table(ws, start_row, text):
    """Parse the pandas-style text table from the JSON."""
    lines = text.strip().split("\n")
    if not lines:
        return start_row

    # Find the header line (first line with content)
    # Format: "                      Item          Account 1          Account 2"
    header_line = lines[0]
    # Split by multiple spaces
    headers = [h.strip() for h in header_line.split("  ") if h.strip()]

    row = start_row
    apply_header_row(ws, row, headers)
    row += 1

    for i, line in enumerate(lines[1:]):
        parts = [p.strip() for p in line.split("  ") if p.strip()]
        # The first element might have a number prefix like "0"
        if parts and parts[0].isdigit():
            parts = parts[1:]
        apply_data_row(ws, row, parts, is_alt=(i % 2 == 1), bold_first=True)
        row += 1

    return row


def _build_from_dict(ws, start_row, data_dict):
    """Build from a dictionary structure."""
    row = start_row
    headers = list(data_dict.keys())
    apply_header_row(ws, row, headers)
    row += 1

    values = list(data_dict.values())
    apply_data_row(ws, row, values)
    return row + 1


def _build_from_list(ws, start_row, data_list):
    """Build from a list of dicts."""
    if not data_list:
        return start_row

    row = start_row
    headers = list(data_list[0].keys())
    apply_header_row(ws, row, headers)
    row += 1

    for i, item in enumerate(data_list):
        values = [item.get(h, "") for h in headers]
        apply_data_row(ws, row, values, is_alt=(i % 2 == 1))
        row += 1

    return row
