"""
P&L Actual Tab
==============
Two sections on one sheet:
1. P&L from Transactions (Actual period) - with Revenue, COGS, OPEX, Interest Income
2. P&L from Transactions (Annualized) - same structure, annualized figures
Each section shows categories, line items, and totals.
"""

from moneta.design import (
    apply_header_row, apply_section_title, apply_data_row, apply_total_row,
    write_nav_bar, auto_width, setup_print, freeze_pane,
    safe_get, parse_number, NUM_FMT_IDR, Colors,
    FONT_BODY, FONT_BODY_BOLD, FILL_LIGHT_BLUE
)


# Order of P&L categories for display
PL_CATEGORY_ORDER = ["Revenue", "COGS", "Interest Income", "OPEX"]
PL_CATEGORY_LABELS = {
    "Revenue": "Revenue",
    "COGS": "Cost of Goods Sold (COGS)",
    "Interest Income": "Interest Income",
    "OPEX": "Operating Expenses (OPEX)",
}


def build(wb, data):
    """Build the P&L Actual tab."""
    ws = wb.create_sheet("P&L Actual")
    ws.sheet_properties.tabColor = Colors.DARK_BLUE

    row = 1
    write_nav_bar(ws, row, "P&L Actual")

    pl_data = safe_get(data, "pl_from_transactions", default={})

    # --- Section 1: Actual ---
    row = 3
    apply_section_title(ws, row, "Profit & Loss from Transactions (Actual Period)", col_span=4)
    row += 1

    actual = pl_data.get("actual", {})
    if actual:
        row = _build_pl_section(ws, row, actual)
    else:
        ws.cell(row=row, column=1, value="No actual P&L data available.")
        row += 1

    # --- Section 2: Annualized ---
    row += 1
    apply_section_title(ws, row, "Profit & Loss from Transactions (Annualized)", col_span=4)
    row += 1

    annualized = pl_data.get("annualized", {})
    if annualized:
        row = _build_pl_section(ws, row, annualized)
    else:
        ws.cell(row=row, column=1, value="No annualized P&L data available.")
        row += 1

    auto_width(ws, min_width=14, max_width=40)
    setup_print(ws, landscape=False, title="Moneta Report - P&L Actual")
    freeze_pane(ws, "A4")
    return ws


def _build_pl_section(ws, start_row, pl_dict):
    """Build a P&L section from the nested dict structure."""
    row = start_row
    headers = ["Category", "Line Item", "Amount (IDR)"]
    apply_header_row(ws, row, headers)
    row += 1

    grand_revenue = 0
    grand_cogs = 0
    grand_opex = 0
    grand_interest = 0
    idx = 0

    for category in PL_CATEGORY_ORDER:
        items = pl_dict.get(category, {})
        if not items:
            continue

        cat_label = PL_CATEGORY_LABELS.get(category, category)
        cat_total = sum(items.values())

        for item_name, amount in items.items():
            row_data = [cat_label, item_name, amount]
            apply_data_row(ws, row, row_data, is_alt=(idx % 2 == 1),
                           bold_first=True, num_fmt=NUM_FMT_IDR)
            row += 1
            idx += 1

        if len(items) > 1:
            apply_total_row(ws, row, [f"Total {cat_label}", "", cat_total],
                            num_fmt=NUM_FMT_IDR)
            row += 1

        if category == "Revenue":
            grand_revenue = cat_total
        elif category == "COGS":
            grand_cogs = cat_total
        elif category == "OPEX":
            grand_opex = cat_total
        elif category == "Interest Income":
            grand_interest = cat_total

    # Computed rows
    row += 1
    gross_profit = grand_revenue - grand_cogs
    apply_total_row(ws, row, ["Gross Profit", "", gross_profit], num_fmt=NUM_FMT_IDR)
    row += 1

    op_profit = gross_profit - grand_opex
    apply_total_row(ws, row, ["Operating Profit", "", op_profit], num_fmt=NUM_FMT_IDR)
    row += 1

    net_income = op_profit + grand_interest
    apply_total_row(ws, row, ["Net Income (before tax)", "", net_income], num_fmt=NUM_FMT_IDR)
    row += 1

    return row
