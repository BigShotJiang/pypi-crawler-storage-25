"""
Financial Metrics Tab
=====================
Key financial ratios with traffic-light formatting:
- Gross Margin (%)
- Operating Margin (%)
- Net Margin (%)
- Current Ratio
- Cash Ratio
- Quick Ratio
Includes the text formula column for reference.
"""

from moneta.design import (
    apply_header_row, apply_section_title, apply_data_row,
    write_nav_bar, auto_width, setup_print, freeze_pane,
    traffic_light_cell, safe_get, parse_number,
    NUM_FMT_PCT_1, Colors,
    FONT_BODY, FONT_BODY_BOLD, FILL_WHITE, FILL_PALE_BLUE,
    ALIGN_LEFT, BORDER_THIN
)


# Thresholds for traffic lights: (amber, red, reverse)
# reverse=True means lower is worse
METRIC_THRESHOLDS = {
    "Gross Margin (%)":     (30, 15, True),    # <15 red, <30 amber
    "Operating Margin (%)": (15, 5, True),
    "Net Margin (%)":       (10, 3, True),
    "Current Ratio":        (1.5, 1.0, True),  # <1.0 red
    "Cash Ratio":           (0.3, 0.1, True),
    "Quick Ratio":          (1.0, 0.5, True),
}


def build(wb, data):
    """Build the Financial Metrics tab."""
    ws = wb.create_sheet("Financial Metrics")
    ws.sheet_properties.tabColor = Colors.DARK_BLUE

    row = 1
    write_nav_bar(ws, row, "Financial Metrics")

    row = 3
    apply_section_title(ws, row, "Financial Metrics & Ratios", col_span=6)
    row += 1

    raw = safe_get(data, "metrics", default="")

    if isinstance(raw, str) and raw.strip():
        row = _parse_metrics_table(ws, row, raw)
    else:
        ws.cell(row=row, column=1, value="No financial metrics data available.")

    auto_width(ws, min_width=14, max_width=50)
    setup_print(ws, landscape=True, title="Moneta Report - Financial Metrics")
    freeze_pane(ws, "A5")
    return ws


def _parse_metrics_table(ws, start_row, text):
    """Parse the metrics table with traffic-light formatting."""
    lines = text.strip().split("\n")
    if not lines:
        return start_row

    # The table has columns: Metric, Value, Threshold, Text Formula
    # But the pandas truncation makes this tricky
    # We know from the JSON it has at least Metric and Text Formula

    row = start_row
    headers = ["Metric", "Value", "Status", "Formula"]
    apply_header_row(ws, row, headers)
    row += 1

    for i, line in enumerate(lines[1:]):
        if not line.strip() or line.strip().startswith("["):
            continue

        parts = line.split()
        if not parts:
            continue

        # Skip index
        start_idx = 0
        if parts[0].isdigit():
            start_idx = 1

        remaining = parts[start_idx:]
        if not remaining:
            continue

        # Try to extract the metric name and value
        # Metric names end with (%) or are multi-word
        # Values are typically at certain positions

        # Find "..." which indicates truncation
        line_clean = line.strip()
        if "..." in line_clean:
            # Truncated line - extract what we can
            before_dots = line_clean.split("...")[0].strip()
            after_dots = line_clean.split("...")[-1].strip()

            idx_parts = before_dots.split()
            if idx_parts and idx_parts[0].isdigit():
                idx_parts = idx_parts[1:]

            metric_name = " ".join(idx_parts)
            formula = after_dots

            # Try to get a numeric value
            metric_value = _estimate_metric_value(metric_name, data)

            # Write row
            label_cell = ws.cell(row=row, column=1, value=metric_name)
            label_cell.font = FONT_BODY_BOLD
            label_cell.fill = FILL_PALE_BLUE if (i % 2 == 1) else FILL_WHITE
            label_cell.border = BORDER_THIN
            label_cell.alignment = ALIGN_LEFT

            if metric_value is not None:
                thresholds = METRIC_THRESHOLDS.get(metric_name)
                if thresholds:
                    amber_t, red_t, reverse = thresholds
                    traffic_light_cell(ws, row, 2, metric_value,
                                       thresholds=(amber_t, red_t), reverse=reverse)
                    if isinstance(metric_value, float):
                        ws.cell(row=row, column=2).number_format = '0.00'
                else:
                    ws.cell(row=row, column=2, value=metric_value).border = BORDER_THIN
            else:
                ws.cell(row=row, column=2, value="N/A").border = BORDER_THIN

            # Status
            status_cell = ws.cell(row=row, column=3, value="")
            status_cell.border = BORDER_THIN
            if metric_value is not None and metric_name in METRIC_THRESHOLDS:
                amber_t, red_t, reverse = METRIC_THRESHOLDS[metric_name]
                if reverse:
                    if metric_value <= red_t:
                        status_cell.value = "Critical"
                    elif metric_value <= amber_t:
                        status_cell.value = "Warning"
                    else:
                        status_cell.value = "Healthy"
                traffic_light_cell(ws, row, 3, status_cell.value)

            # Formula
            formula_cell = ws.cell(row=row, column=4, value=formula)
            formula_cell.font = FONT_BODY
            formula_cell.fill = FILL_PALE_BLUE if (i % 2 == 1) else FILL_WHITE
            formula_cell.border = BORDER_THIN
            formula_cell.alignment = ALIGN_LEFT

            row += 1

    return row


# Store data reference for metric calculation
data = None


def _estimate_metric_value(metric_name, report_data):
    """Estimate metric values from available data."""
    try:
        pl = safe_get(report_data, "pl_from_transactions", "actual", default={})

        revenue = sum(safe_get(pl, "Revenue", default={}).values())
        cogs = sum(safe_get(pl, "COGS", default={}).values())
        opex = sum(safe_get(pl, "OPEX", default={}).values())
        interest = sum(safe_get(pl, "Interest Income", default={}).values())

        gross_profit = revenue - cogs
        op_profit = gross_profit - opex
        net_profit = op_profit + interest

        bs_raw = safe_get(report_data, "balance_sheet", default="")

        if metric_name == "Gross Margin (%)":
            return (gross_profit / revenue * 100) if revenue else None
        elif metric_name == "Operating Margin (%)":
            return (op_profit / revenue * 100) if revenue else None
        elif metric_name == "Net Margin (%)":
            return (net_profit / revenue * 100) if revenue else None

        # Parse balance sheet values
        bs_values = _parse_bs_values(bs_raw)
        current_assets = bs_values.get("Current Assets", 0)
        current_liabilities = bs_values.get("Current Liabilities", 0)
        cash = bs_values.get("Cash", 0)
        inventory = bs_values.get("Inventory", 0)

        if metric_name == "Current Ratio":
            return (current_assets / current_liabilities) if current_liabilities else None
        elif metric_name == "Cash Ratio":
            return (cash / current_liabilities) if current_liabilities else None
        elif metric_name == "Quick Ratio":
            return ((current_assets - inventory) / current_liabilities) if current_liabilities else None

    except Exception:
        pass
    return None


def _parse_bs_values(bs_text):
    """Parse balance sheet text to extract values."""
    values = {}
    if not isinstance(bs_text, str):
        return values

    for line in bs_text.strip().split("\n"):
        parts = line.split()
        if len(parts) >= 2:
            # Skip index
            start = 1 if parts[0].isdigit() else 0
            val = parse_number(parts[-1])
            name = " ".join(parts[start:-1])
            values[name] = val

    return values
