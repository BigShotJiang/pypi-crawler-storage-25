"""
Balance Sheet Tab
=================
Reconstructed balance sheet from bank statement data.
Rows: Cash, AR, Inventory, Current Assets, Fixed Assets,
      Current Liabilities, Long-Term Liabilities, Total Assets, Total Liabilities
"""

from moneta.design import (
    apply_header_row, apply_section_title, apply_data_row, apply_total_row,
    write_nav_bar, auto_width, setup_print, freeze_pane,
    safe_get, parse_number, NUM_FMT_IDR, Colors
)

# Rows that are subtotals / totals
TOTAL_ROWS = {"Current Assets", "Total Assets", "Total Liabilities"}


def build(wb, data):
    """Build the Balance Sheet tab."""
    ws = wb.create_sheet("Balance Sheet")
    ws.sheet_properties.tabColor = Colors.DARK_BLUE

    row = 1
    write_nav_bar(ws, row, "Balance Sheet")

    row = 3
    apply_section_title(ws, row, "Balance Sheet (Reconstructed)", col_span=4)
    row += 1

    raw = safe_get(data, "balance_sheet", default="")

    if isinstance(raw, str) and raw.strip():
        row = _parse_balance_sheet(ws, row, raw)
    else:
        ws.cell(row=row, column=1, value="No balance sheet data available.")

    auto_width(ws, min_width=14, max_width=28)
    setup_print(ws, landscape=False, title="Moneta Report - Balance Sheet")
    freeze_pane(ws, "A5")
    return ws


def _parse_balance_sheet(ws, start_row, text):
    """Parse pandas text balance sheet."""
    lines = text.strip().split("\n")
    if not lines:
        return start_row

    # Header: "                    Item    2025-12-31"
    header_parts = lines[0].split()
    date_cols = [p for p in header_parts if p not in ("Item",) and "-" in p]

    row = start_row
    headers = ["Item"] + date_cols
    apply_header_row(ws, row, headers)
    row += 1

    for i, line in enumerate(lines[1:]):
        if not line.strip() or line.strip().startswith("["):
            continue

        parts = line.split()
        if not parts:
            continue

        # Skip index
        start_idx = 0
        if parts[0].isdigit():
            start_idx = 1

        # Extract numeric values from end
        num_values = []
        remaining = list(parts[start_idx:])
        for _ in range(len(date_cols)):
            if remaining:
                val = parse_number(remaining[-1])
                num_values.insert(0, val)
                remaining.pop()

        item_name = " ".join(remaining)
        if item_name == "...":
            continue

        row_data = [item_name] + num_values

        if item_name in TOTAL_ROWS:
            apply_total_row(ws, row, row_data, num_fmt=NUM_FMT_IDR)
        else:
            apply_data_row(ws, row, row_data, is_alt=(i % 2 == 1),
                           bold_first=True, num_fmt=NUM_FMT_IDR)
        row += 1

    return row
