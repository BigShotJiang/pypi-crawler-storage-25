"""
EOD Combined Tab
================
Shows the combined end-of-day balance across ALL accounts, one column per month,
rows = days 1-31.
"""

from moneta.design import (
    apply_header_row, apply_section_title, apply_data_row, apply_total_row,
    write_nav_bar, auto_width, setup_print, freeze_pane,
    safe_get, NUM_FMT_IDR, Colors, parse_number
)


def build(wb, data):
    """Build the EOD Combined tab."""
    ws = wb.create_sheet("EOD Combined")
    ws.sheet_properties.tabColor = Colors.BLUE

    row = 1
    write_nav_bar(ws, row, "EOD Combined")

    row = 3
    apply_section_title(ws, row, "End-of-Day Combined Balance (All Accounts)", col_span=6)
    row += 1

    raw = safe_get(data, "eod", "Combined", default="")

    if isinstance(raw, str) and raw.strip():
        row = _parse_text_table(ws, row, raw)
    else:
        ws.cell(row=row, column=1, value="No combined EOD data available.")

    auto_width(ws, min_width=12, max_width=22)
    setup_print(ws, landscape=True, title="Moneta Report - EOD Combined")
    freeze_pane(ws, "A5")
    return ws


def _parse_text_table(ws, start_row, text):
    """Parse pandas text representation into rows."""
    lines = text.strip().split("\n")
    if not lines:
        return start_row

    # First line is headers
    header_parts = lines[0].split()
    # headers = ["Day/Month", "OCT_2025", "NOV_2025", "DEC_2025", ...]
    headers = []
    for part in header_parts:
        if part.isdigit():
            continue
        headers.append(part.replace("_", " "))

    row = start_row
    apply_header_row(ws, row, headers)
    row += 1

    for i, line in enumerate(lines[1:]):
        parts = line.split()
        if not parts:
            continue
        # First element may be index, skip if numeric
        values = []
        for p in parts:
            if p == "Day/Month":
                continue
            try:
                values.append(parse_number(p))
            except Exception:
                values.append(p)

        # Skip the index column (first numeric)
        if len(values) > len(headers):
            values = values[1:]

        # First value is day number
        parsed = []
        for j, v in enumerate(values):
            if j == 0:
                parsed.append(int(v) if isinstance(v, float) and v == int(v) else v)
            else:
                parsed.append(v)

        apply_data_row(
            ws, row, parsed,
            is_alt=(i % 2 == 1),
            bold_first=True,
            num_fmt=NUM_FMT_IDR
        )
        row += 1

    return row
