"""
Fraud Analysis Tab
==================
The most complex tab.  Sections:
1. Fraud probability score (large KPI badge)
2. Fraud indicator summary table (20 indicators with status traffic lights)
3. Detailed cases for each triggered indicator
"""

from moneta.design import (
    apply_header_row, apply_section_title, apply_data_row,
    write_nav_bar, auto_width, setup_print, freeze_pane,
    traffic_light_cell, safe_get, parse_number,
    Colors, NUM_FMT_IDR, NUM_FMT_DATE,
    FONT_TITLE, FONT_KPI_VALUE, FONT_BODY, FONT_BODY_BOLD, FONT_SECTION,
    FONT_HEADER, FONT_SMALL, FONT_GREEN, FONT_AMBER, FONT_RED,
    FILL_NAVY, FILL_DARK_BLUE, FILL_BLUE, FILL_WHITE, FILL_PALE_BLUE,
    FILL_LIGHT_BLUE, FILL_GREEN, FILL_AMBER, FILL_RED,
    FILL_FRAUD_HIGH, FILL_FRAUD_MEDIUM, FILL_FRAUD_LOW, FILL_FRAUD_NONE,
    ALIGN_CENTER, ALIGN_LEFT, BORDER_THIN, BORDER_HEADER
)


def build(wb, data):
    """Build the Fraud Analysis tab."""
    ws = wb.create_sheet("Fraud Analysis")
    ws.sheet_properties.tabColor = Colors.FRAUD_HIGH

    row = 1
    write_nav_bar(ws, row, "Fraud Analysis")

    fraud = safe_get(data, "fraud", default={})

    # --- Section 1: Fraud Probability Score ---
    row = 3
    apply_section_title(ws, row, "Fraud Probability Assessment", col_span=10)
    row += 1

    fraud_prob = fraud.get("fraud_probability", None)
    ws.row_dimensions[row].height = 40

    score_label = ws.cell(row=row, column=1, value="Overall Fraud Probability")
    score_label.font = FONT_BODY_BOLD
    score_label.alignment = ALIGN_LEFT

    if fraud_prob is not None:
        pct = fraud_prob * 100 if fraud_prob <= 1 else fraud_prob
        score_cell = ws.cell(row=row, column=2, value=pct / 100)
        score_cell.number_format = '0.0%'
        score_cell.font = FONT_KPI_VALUE
        score_cell.alignment = ALIGN_CENTER

        if pct < 20:
            score_cell.fill = FILL_GREEN
            risk = "Low Risk"
        elif pct < 50:
            score_cell.fill = FILL_AMBER
            risk = "Medium Risk"
        else:
            score_cell.fill = FILL_RED
            risk = "High Risk"

        risk_cell = ws.cell(row=row, column=3, value=risk)
        risk_cell.font = FONT_BODY_BOLD
        risk_cell.alignment = ALIGN_CENTER
        if pct < 20:
            risk_cell.fill = FILL_GREEN
        elif pct < 50:
            risk_cell.fill = FILL_AMBER
        else:
            risk_cell.fill = FILL_RED
    else:
        ws.cell(row=row, column=2, value="N/A").font = FONT_KPI_VALUE

    row += 2

    # --- Section 2: Fraud Indicator Summary ---
    apply_section_title(ws, row, "Fraud Indicator Summary", col_span=10)
    row += 1

    cases = fraud.get("cases", {})
    if cases:
        headers = ["No", "Fraud Indicator", "Cases Found", "Status"]
        apply_header_row(ws, row, headers)
        row += 1

        for i, (indicator, case_list) in enumerate(cases.items()):
            count = len(case_list) if isinstance(case_list, list) else 0

            num_cell = ws.cell(row=row, column=1, value=i + 1)
            num_cell.font = FONT_BODY
            num_cell.fill = FILL_PALE_BLUE if (i % 2 == 1) else FILL_WHITE
            num_cell.border = BORDER_THIN
            num_cell.alignment = ALIGN_CENTER

            name_cell = ws.cell(row=row, column=2, value=indicator)
            name_cell.font = FONT_BODY_BOLD if count > 0 else FONT_BODY
            name_cell.fill = FILL_PALE_BLUE if (i % 2 == 1) else FILL_WHITE
            name_cell.border = BORDER_THIN
            name_cell.alignment = ALIGN_LEFT

            count_cell = ws.cell(row=row, column=3, value=count)
            count_cell.font = FONT_BODY
            count_cell.fill = FILL_PALE_BLUE if (i % 2 == 1) else FILL_WHITE
            count_cell.border = BORDER_THIN
            count_cell.alignment = ALIGN_CENTER

            # Traffic light for status
            if count == 0:
                status_val = "Clear"
            elif count <= 3:
                status_val = "Low"
            elif count <= 10:
                status_val = "Medium"
            else:
                status_val = "High"

            traffic_light_cell(ws, row, 4, status_val)
            row += 1

    row += 1

    # --- Section 3: Detailed Cases ---
    apply_section_title(ws, row, "Detailed Fraud Cases", col_span=10)
    row += 1

    for indicator, case_list in cases.items():
        if not isinstance(case_list, list) or not case_list:
            continue

        # Sub-header for this indicator
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=10)
        ind_cell = ws.cell(row=row, column=1,
                           value=f"{indicator} ({len(case_list)} cases)")
        ind_cell.font = FONT_HEADER
        ind_cell.fill = FILL_BLUE
        ind_cell.alignment = ALIGN_LEFT
        ind_cell.border = BORDER_HEADER
        for c in range(2, 11):
            ws.cell(row=row, column=c).fill = FILL_BLUE
            ws.cell(row=row, column=c).border = BORDER_HEADER
        row += 1

        # Build headers from first case's keys
        if case_list:
            case_keys = list(case_list[0].keys())
            # Limit to reasonable number of columns
            display_keys = case_keys[:10]

            apply_header_row(ws, row, display_keys)
            row += 1

            for j, case in enumerate(case_list):
                values = []
                for key in display_keys:
                    val = case.get(key, "")
                    if isinstance(val, dict):
                        # Nested dict - flatten
                        val = "; ".join(f"{k}: {v}" for k, v in val.items())
                    values.append(val)

                apply_data_row(ws, row, values, is_alt=(j % 2 == 1),
                               num_fmt=NUM_FMT_IDR)
                row += 1

        row += 1

    auto_width(ws, min_width=12, max_width=40)
    setup_print(ws, landscape=True, title="Moneta Report - Fraud Analysis")
    freeze_pane(ws, "A4")
    return ws
