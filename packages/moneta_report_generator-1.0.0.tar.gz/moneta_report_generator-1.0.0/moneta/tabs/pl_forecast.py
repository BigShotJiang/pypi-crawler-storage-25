"""
P&L Forecast Tab
================
Forward-looking P&L forecast table.
Rows: Revenue, COGS, Gross Profit, OPEX, Operating Profit,
      Interest Income, Interest Expense, Profit Before Taxes, Taxes, Net Profit
Columns: months (DEC_2025 through JUN_2026)
"""

from moneta.design import (
    apply_header_row, apply_section_title, apply_data_row, apply_total_row,
    write_nav_bar, auto_width, setup_print, freeze_pane,
    safe_get, parse_number, NUM_FMT_IDR, Colors,
    FONT_BODY_BOLD, FILL_LIGHT_BLUE, BORDER_THIN, ALIGN_LEFT
)


# Rows that should be bold (subtotals / key lines)
BOLD_ROWS = {"Gross Profit", "Operating Profit", "Profit before taxes", "Net Profit"}


def build(wb, data):
    """Build the P&L Forecast tab."""
    ws = wb.create_sheet("P&L Forecast")
    ws.sheet_properties.tabColor = Colors.DARK_BLUE

    row = 1
    write_nav_bar(ws, row, "P&L Forecast")

    row = 3
    apply_section_title(ws, row, "Profit & Loss Forecast", col_span=10)
    row += 1

    raw = safe_get(data, "pl_forecast", default="")

    if isinstance(raw, str) and raw.strip():
        row = _parse_forecast_table(ws, row, raw)
    else:
        ws.cell(row=row, column=1, value="No P&L forecast data available.")

    auto_width(ws, min_width=14, max_width=22)
    setup_print(ws, landscape=True, title="Moneta Report - P&L Forecast")
    freeze_pane(ws, "A5")
    return ws


def _parse_forecast_table(ws, start_row, text):
    """Parse the pandas text forecast table."""
    lines = text.strip().split("\n")
    if not lines:
        return start_row

    # Extract headers from first line
    header_line = lines[0]
    header_parts = header_line.split()
    months = []
    for p in header_parts:
        if "_" in p and any(m in p for m in ["JAN", "FEB", "MAR", "APR", "MAY", "JUN",
                                              "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]):
            months.append(p.replace("_", " "))

    row = start_row
    headers = ["Item"] + months
    apply_header_row(ws, row, headers)
    row += 1

    for i, line in enumerate(lines[1:]):
        if not line.strip():
            continue
        # Skip summary lines like "[10 rows x 8 columns]"
        if line.strip().startswith("["):
            continue

        parts = line.split()
        if not parts:
            continue

        # Skip index
        start_idx = 0
        if parts[0].isdigit():
            start_idx = 1

        # Extract numeric values from end
        num_values = []
        remaining = list(parts[start_idx:])
        for _ in range(len(months)):
            if remaining:
                val = parse_number(remaining[-1])
                num_values.insert(0, val)
                remaining.pop()

        item_name = " ".join(remaining)
        # Handle "..." (truncated display)
        if item_name == "...":
            continue

        row_data = [item_name] + num_values

        is_bold_row = item_name in BOLD_ROWS

        if is_bold_row:
            apply_total_row(ws, row, row_data, num_fmt=NUM_FMT_IDR)
        else:
            apply_data_row(ws, row, row_data, is_alt=(i % 2 == 1),
                           bold_first=True, num_fmt=NUM_FMT_IDR)
        row += 1

    return row
