"""
Liquidity Tab
=============
Three sections:
1. Liquidity Health Metrics (Avg EoD, MoM %, Days below threshold, Volatility)
2. Runway and Stress Capacity (Runway days, Survivability %)
3. Monitoring Alerts (Low Balance Breach, Volatility Jump, Runway Deterioration)
   - with traffic-light formatting
"""

from moneta.design import (
    apply_header_row, apply_section_title, apply_data_row,
    write_nav_bar, auto_width, setup_print, freeze_pane,
    traffic_light_cell, safe_get, parse_number,
    NUM_FMT_IDR, NUM_FMT_PCT_1, Colors,
    FONT_BODY, FONT_BODY_BOLD, FILL_WHITE, FILL_PALE_BLUE,
    ALIGN_LEFT, ALIGN_RIGHT, ALIGN_CENTER, BORDER_THIN
)


def build(wb, data):
    """Build the Liquidity tab."""
    ws = wb.create_sheet("Liquidity")
    ws.sheet_properties.tabColor = Colors.BLUE

    row = 1
    write_nav_bar(ws, row, "Liquidity")

    liquidity = safe_get(data, "liquidity", default={})

    # --- Section 1: Health Metrics ---
    row = 3
    apply_section_title(ws, row, "Liquidity Health Metrics", col_span=6)
    row += 1

    health_raw = liquidity.get("Liquidity Health Metrics", "")
    if health_raw:
        row = _parse_metric_table(ws, row, health_raw, num_fmt=NUM_FMT_IDR)
    else:
        ws.cell(row=row, column=1, value="No liquidity health data available.")
        row += 1

    # --- Section 2: Runway and Stress ---
    row += 1
    apply_section_title(ws, row, "Runway and Stress Capacity", col_span=6)
    row += 1

    runway_raw = liquidity.get("Runway and Stress Capacity", "")
    if runway_raw:
        row = _parse_metric_table(ws, row, runway_raw, num_fmt='#,##0.0',
                                  traffic_lights={
                                      "Runway (Days)": (60, 30, True),
                                      "Survivability (%)": (80, 50, True),
                                  })
    else:
        ws.cell(row=row, column=1, value="No runway data available.")
        row += 1

    # --- Section 3: Monitoring Alerts ---
    row += 1
    apply_section_title(ws, row, "Monitoring Alerts", col_span=6)
    row += 1

    alerts_raw = liquidity.get("Monitoring Alerts", "")
    if alerts_raw:
        row = _parse_alert_table(ws, row, alerts_raw)
    else:
        ws.cell(row=row, column=1, value="No monitoring alerts data available.")
        row += 1

    auto_width(ws, min_width=14, max_width=25)
    setup_print(ws, landscape=True, title="Moneta Report - Liquidity")
    freeze_pane(ws, "A4")
    return ws


def _parse_metric_table(ws, start_row, text, num_fmt=None, traffic_lights=None):
    """Parse a pandas-style metric table."""
    lines = text.strip().split("\n")
    if not lines:
        return start_row

    # First line: "Month  OCT_2025  NOV_2025  DEC_2025"
    header_parts = lines[0].split()
    months = [p.replace("_", " ") for p in header_parts[1:] if not p.isdigit()]

    row = start_row
    headers = ["Metric"] + months
    apply_header_row(ws, row, headers)
    row += 1

    for i, line in enumerate(lines[1:]):
        # Metric name may contain spaces, values are at end
        parts = line.split()
        if not parts:
            continue

        # Find where the numeric values start (from the right)
        num_values = []
        remaining = list(parts)
        for _ in range(len(months)):
            if remaining:
                try:
                    val = parse_number(remaining[-1])
                    num_values.insert(0, val)
                    remaining.pop()
                except Exception:
                    break

        metric_name = " ".join(remaining)
        row_data = [metric_name] + num_values

        apply_data_row(ws, row, row_data, is_alt=(i % 2 == 1),
                       bold_first=True, num_fmt=num_fmt)

        # Apply traffic lights if specified
        if traffic_lights and metric_name in traffic_lights:
            amber_t, red_t, reverse = traffic_lights[metric_name]
            for j, val in enumerate(num_values):
                traffic_light_cell(ws, row, 2 + j, val,
                                   thresholds=(amber_t, red_t), reverse=reverse)

        row += 1

    return row


def _parse_alert_table(ws, start_row, text):
    """Parse monitoring alerts table with True/False traffic lights."""
    lines = text.strip().split("\n")
    if not lines:
        return start_row

    header_parts = lines[0].split()
    months = [p.replace("_", " ") for p in header_parts[1:] if not p.isdigit()]

    row = start_row
    headers = ["Alert"] + months
    apply_header_row(ws, row, headers)
    row += 1

    for i, line in enumerate(lines[1:]):
        parts = line.split()
        if not parts:
            continue

        # Alert name can have multiple words, boolean values at end
        bool_values = []
        remaining = list(parts)
        for _ in range(len(months)):
            if remaining:
                val = remaining[-1]
                bool_values.insert(0, val)
                remaining.pop()

        alert_name = " ".join(remaining)

        # Write label
        label_cell = ws.cell(row=row, column=1, value=alert_name)
        label_cell.font = FONT_BODY_BOLD
        label_cell.fill = FILL_PALE_BLUE if (i % 2 == 1) else FILL_WHITE
        label_cell.border = BORDER_THIN
        label_cell.alignment = ALIGN_LEFT

        # Write traffic-light values
        for j, val in enumerate(bool_values):
            traffic_light_cell(ws, row, 2 + j, val)

        row += 1

    return row
