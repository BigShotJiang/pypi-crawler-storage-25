"""Moneta Report Generator - Professional Excel financial report builder."""
__version__ = "1.0.0"
