"""
Moneta Report Engine
====================
The main orchestrator.  Loads JSON data, creates the workbook, calls each
tab builder in order, and saves the output file.

Error philosophy: The report MUST always be generated.  If a section fails,
log the error, write a placeholder message in the sheet, and continue to
the next section.
"""

import json
import logging
import traceback
from pathlib import Path

from openpyxl import Workbook

from moneta.tabs import (
    cover,
    account_summary,
    eod_detailed,
    eod_combined,
    liquidity,
    txn_summary,
    pl_actual,
    pl_forecast,
    balance_sheet,
    metrics,
    dscr,
    fraud,
)
from moneta.design import safe_get

logger = logging.getLogger("moneta")

# Ordered list of tab builders
TAB_BUILDERS = [
    ("Cover",               cover.build),
    ("Account Summary",     account_summary.build),
    ("EOD Detailed",        eod_detailed.build),
    ("EOD Combined",        eod_combined.build),
    ("Liquidity",           liquidity.build),
    ("Transaction Summary", txn_summary.build),
    ("P&L Actual",          pl_actual.build),
    ("P&L Forecast",        pl_forecast.build),
    ("Balance Sheet",       balance_sheet.build),
    ("Financial Metrics",   metrics.build),
    ("DSCR & DBR",          dscr.build),
    ("Fraud Analysis",      fraud.build),
]


def load_data(input_path: str) -> dict:
    """Load and validate the input JSON data.

    Args:
        input_path: Path to the report_output.json file.

    Returns:
        Parsed dictionary.  Returns empty dict on failure (never raises).
    """
    try:
        path = Path(input_path)
        if not path.exists():
            logger.error("Input file not found: %s", input_path)
            return {}

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, dict):
            logger.error("Input JSON is not a dictionary")
            return {}

        logger.info("Loaded JSON with %d top-level keys: %s",
                     len(data), list(data.keys()))
        return data

    except json.JSONDecodeError as e:
        logger.error("JSON parse error: %s", e)
        return {}
    except Exception as e:
        logger.error("Failed to load input: %s", e)
        return {}


def generate_report(data: dict, output_path: str) -> str:
    """Generate the complete Moneta Excel report.

    Args:
        data:        The parsed report_output dictionary.
        output_path: Where to save the .xlsx file.

    Returns:
        The path to the generated file.
    """
    wb = Workbook()
    errors = []

    for tab_name, builder_fn in TAB_BUILDERS:
        try:
            logger.info("Building tab: %s", tab_name)
            builder_fn(wb, data)
            logger.info("  -> %s: OK", tab_name)
        except Exception as e:
            error_msg = f"{tab_name}: {e}"
            logger.error("  -> %s: FAILED - %s", tab_name, e)
            logger.debug(traceback.format_exc())
            errors.append(error_msg)

            # Create a placeholder sheet so the tab still exists
            try:
                if tab_name != "Cover":
                    ws = wb.create_sheet(tab_name)
                    ws.cell(row=1, column=1,
                            value=f"Error generating {tab_name}: {e}")
                    ws.cell(row=2, column=1,
                            value="Please check the input data and try again.")
            except Exception:
                pass

    # Remove default "Sheet" if Cover was successfully created
    if "Sheet" in wb.sheetnames and "Cover" in wb.sheetnames:
        try:
            del wb["Sheet"]
        except Exception:
            pass

    # Save
    try:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        wb.save(str(out))
        logger.info("Report saved to: %s", out)
    except Exception as e:
        logger.error("Failed to save report: %s", e)
        raise

    if errors:
        logger.warning("Report generated with %d tab error(s): %s",
                        len(errors), errors)

    return str(out)


def generate_from_file(input_path: str, output_path: str) -> str:
    """End-to-end: load JSON -> generate Excel.

    Args:
        input_path:  Path to report_output.json
        output_path: Path for the output .xlsx

    Returns:
        Path to the generated file.
    """
    data = load_data(input_path)
    return generate_report(data, output_path)
