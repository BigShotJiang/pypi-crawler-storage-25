"""
Command-line interface for Moneta Report Generator.

Usage:
    moneta-report --input report_output.json --output MonetaReport.xlsx
    python -m moneta.cli --input report_output.json --output MonetaReport.xlsx
"""

import argparse
import logging
import sys
from pathlib import Path

from moneta.engine import generate_from_file


def main():
    parser = argparse.ArgumentParser(
        prog="moneta-report",
        description="Moneta Report Generator - Convert JSON analysis data "
                    "into a professionally styled Excel workbook.",
    )
    parser.add_argument(
        "--input", "-i",
        required=True,
        help="Path to the input report_output.json file.",
    )
    parser.add_argument(
        "--output", "-o",
        default="MonetaReport.xlsx",
        help="Path for the generated Excel file (default: MonetaReport.xlsx).",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging.",
    )

    args = parser.parse_args()

    # Set up logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    logger = logging.getLogger("moneta")

    # Validate input
    if not Path(args.input).exists():
        logger.error("Input file not found: %s", args.input)
        sys.exit(1)

    # Generate
    try:
        output = generate_from_file(args.input, args.output)
        logger.info("Report generated successfully: %s", output)
        print(f"\nReport saved to: {output}")
    except Exception as e:
        logger.error("Fatal error: %s", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
