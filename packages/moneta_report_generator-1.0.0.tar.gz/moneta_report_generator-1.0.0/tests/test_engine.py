"""
Moneta Report Generator - Test Suite
=====================================
Tests cover:
1. Data loading (valid, invalid, missing)
2. Each tab builder individually
3. Full integration test with real data
4. Error resilience (missing keys, empty data)
5. Output validation (file exists, all tabs present, no empty tabs)
"""

import json
import os
import tempfile
from pathlib import Path

import pytest
from openpyxl import Workbook, load_workbook

from moneta.engine import load_data, generate_report, generate_from_file
from moneta.design import (
    safe_get, parse_number, apply_header_row, apply_data_row,
    apply_section_title, traffic_light_cell, TAB_NAMES
)
from moneta.tabs import (
    cover, account_summary, eod_detailed, eod_combined,
    liquidity, txn_summary, pl_actual, pl_forecast,
    balance_sheet, metrics, dscr, fraud
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
SAMPLE_JSON = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
    "report_output.json"
)


@pytest.fixture
def sample_data():
    """Load the real sample data."""
    if os.path.exists(SAMPLE_JSON):
        with open(SAMPLE_JSON, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


@pytest.fixture
def empty_data():
    """Empty data dict for resilience testing."""
    return {}


@pytest.fixture
def minimal_data():
    """Minimal data with just enough to not crash."""
    return {
        "eod": {"Detailed": [], "Report": [], "Combined": ""},
        "liquidity": {},
        "transaction_summary": {},
        "pl_from_transactions": {"actual": {}, "annualized": {}},
        "pl_forecast": "",
        "balance_sheet": "",
        "metrics": "",
        "dscr_dbr": "",
        "account_summary": "",
        "fraud": {"fraud_probability": 0.0, "cases": {}},
    }


@pytest.fixture
def output_path():
    """Temporary output file."""
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f:
        path = f.name
    yield path
    if os.path.exists(path):
        os.unlink(path)


# ---------------------------------------------------------------------------
# Unit tests - Design system helpers
# ---------------------------------------------------------------------------
class TestDesignHelpers:
    def test_safe_get_basic(self):
        data = {"a": {"b": {"c": 42}}}
        assert safe_get(data, "a", "b", "c") == 42

    def test_safe_get_missing(self):
        data = {"a": 1}
        assert safe_get(data, "b", "c", default="N/A") == "N/A"

    def test_safe_get_list(self):
        data = {"items": [10, 20, 30]}
        assert safe_get(data, "items", 1) == 20

    def test_parse_number_int(self):
        assert parse_number(42) == 42

    def test_parse_number_float(self):
        assert parse_number(3.14) == 3.14

    def test_parse_number_string(self):
        assert parse_number("1,234,567") == 1234567

    def test_parse_number_ratio(self):
        assert parse_number("1.33x") == 1.33

    def test_parse_number_none(self):
        assert parse_number(None) == 0.0

    def test_parse_number_empty(self):
        assert parse_number("") == 0.0

    def test_parse_number_bad(self):
        assert parse_number("abc") == 0.0

    def test_apply_header_row(self):
        wb = Workbook()
        ws = wb.active
        apply_header_row(ws, 1, ["A", "B", "C"])
        assert ws.cell(1, 1).value == "A"
        assert ws.cell(1, 2).value == "B"
        assert ws.cell(1, 3).value == "C"

    def test_apply_data_row(self):
        wb = Workbook()
        ws = wb.active
        apply_data_row(ws, 1, ["Label", 100, 200.5])
        assert ws.cell(1, 1).value == "Label"
        assert ws.cell(1, 2).value == 100
        assert ws.cell(1, 3).value == 200.5

    def test_apply_section_title(self):
        wb = Workbook()
        ws = wb.active
        apply_section_title(ws, 1, "Test Section", col_span=4)
        assert ws.cell(1, 1).value == "Test Section"

    def test_traffic_light_bool_true(self):
        wb = Workbook()
        ws = wb.active
        cell = traffic_light_cell(ws, 1, 1, True)
        assert cell.value == "YES"

    def test_traffic_light_bool_false(self):
        wb = Workbook()
        ws = wb.active
        cell = traffic_light_cell(ws, 1, 1, False)
        assert cell.value == "No"

    def test_traffic_light_numeric(self):
        wb = Workbook()
        ws = wb.active
        # Low value, reverse=True means bad
        cell = traffic_light_cell(ws, 1, 1, 5, thresholds=(30, 10), reverse=True)
        assert cell.value == 5


# ---------------------------------------------------------------------------
# Unit tests - Data loading
# ---------------------------------------------------------------------------
class TestDataLoading:
    def test_load_valid_json(self, sample_data):
        if not sample_data:
            pytest.skip("No sample data available")
        assert isinstance(sample_data, dict)
        assert "eod" in sample_data

    def test_load_nonexistent(self):
        result = load_data("/nonexistent/file.json")
        assert result == {}

    def test_load_invalid_json(self, output_path):
        with open(output_path.replace(".xlsx", ".json"), "w") as f:
            f.write("{invalid json")
        result = load_data(output_path.replace(".xlsx", ".json"))
        assert result == {}
        os.unlink(output_path.replace(".xlsx", ".json"))


# ---------------------------------------------------------------------------
# Unit tests - Individual tab builders
# ---------------------------------------------------------------------------
class TestTabBuilders:
    def test_cover_with_data(self, sample_data):
        if not sample_data:
            pytest.skip("No sample data")
        wb = Workbook()
        ws = cover.build(wb, sample_data)
        assert ws.title == "Cover"

    def test_cover_empty(self, empty_data):
        wb = Workbook()
        ws = cover.build(wb, empty_data)
        assert ws.title == "Cover"

    def test_account_summary_with_data(self, sample_data):
        if not sample_data:
            pytest.skip("No sample data")
        wb = Workbook()
        ws = account_summary.build(wb, sample_data)
        assert ws.title == "Account Summary"

    def test_eod_detailed_with_data(self, sample_data):
        if not sample_data:
            pytest.skip("No sample data")
        wb = Workbook()
        ws = eod_detailed.build(wb, sample_data)
        assert ws.title == "EOD Detailed"

    def test_eod_combined_with_data(self, sample_data):
        if not sample_data:
            pytest.skip("No sample data")
        wb = Workbook()
        ws = eod_combined.build(wb, sample_data)
        assert ws.title == "EOD Combined"

    def test_liquidity_with_data(self, sample_data):
        if not sample_data:
            pytest.skip("No sample data")
        wb = Workbook()
        ws = liquidity.build(wb, sample_data)
        assert ws.title == "Liquidity"

    def test_txn_summary_with_data(self, sample_data):
        if not sample_data:
            pytest.skip("No sample data")
        wb = Workbook()
        ws = txn_summary.build(wb, sample_data)
        assert ws.title == "Transaction Summary"

    def test_pl_actual_with_data(self, sample_data):
        if not sample_data:
            pytest.skip("No sample data")
        wb = Workbook()
        ws = pl_actual.build(wb, sample_data)
        assert ws.title == "P&L Actual"

    def test_pl_forecast_with_data(self, sample_data):
        if not sample_data:
            pytest.skip("No sample data")
        wb = Workbook()
        ws = pl_forecast.build(wb, sample_data)
        assert ws.title == "P&L Forecast"

    def test_balance_sheet_with_data(self, sample_data):
        if not sample_data:
            pytest.skip("No sample data")
        wb = Workbook()
        ws = balance_sheet.build(wb, sample_data)
        assert ws.title == "Balance Sheet"

    def test_metrics_with_data(self, sample_data):
        if not sample_data:
            pytest.skip("No sample data")
        wb = Workbook()
        ws = metrics.build(wb, sample_data)
        assert ws.title == "Financial Metrics"

    def test_dscr_with_data(self, sample_data):
        if not sample_data:
            pytest.skip("No sample data")
        wb = Workbook()
        ws = dscr.build(wb, sample_data)
        assert ws.title == "DSCR & DBR"

    def test_fraud_with_data(self, sample_data):
        if not sample_data:
            pytest.skip("No sample data")
        wb = Workbook()
        ws = fraud.build(wb, sample_data)
        assert ws.title == "Fraud Analysis"


# ---------------------------------------------------------------------------
# Resilience tests - every builder with empty data
# ---------------------------------------------------------------------------
class TestResilience:
    def test_cover_empty(self, empty_data):
        wb = Workbook()
        cover.build(wb, empty_data)

    def test_account_summary_empty(self, empty_data):
        wb = Workbook()
        account_summary.build(wb, empty_data)

    def test_eod_detailed_empty(self, empty_data):
        wb = Workbook()
        eod_detailed.build(wb, empty_data)

    def test_eod_combined_empty(self, empty_data):
        wb = Workbook()
        eod_combined.build(wb, empty_data)

    def test_liquidity_empty(self, empty_data):
        wb = Workbook()
        liquidity.build(wb, empty_data)

    def test_txn_summary_empty(self, empty_data):
        wb = Workbook()
        txn_summary.build(wb, empty_data)

    def test_pl_actual_empty(self, empty_data):
        wb = Workbook()
        pl_actual.build(wb, empty_data)

    def test_pl_forecast_empty(self, empty_data):
        wb = Workbook()
        pl_forecast.build(wb, empty_data)

    def test_balance_sheet_empty(self, empty_data):
        wb = Workbook()
        balance_sheet.build(wb, empty_data)

    def test_metrics_empty(self, empty_data):
        wb = Workbook()
        metrics.build(wb, empty_data)

    def test_dscr_empty(self, empty_data):
        wb = Workbook()
        dscr.build(wb, empty_data)

    def test_fraud_empty(self, empty_data):
        wb = Workbook()
        fraud.build(wb, empty_data)

    def test_full_report_empty(self, empty_data, output_path):
        """Full report with empty data should still produce a file."""
        result = generate_report(empty_data, output_path)
        assert os.path.exists(result)
        wb = load_workbook(result)
        assert len(wb.sheetnames) > 0

    def test_full_report_minimal(self, minimal_data, output_path):
        """Full report with minimal data should still produce a file."""
        result = generate_report(minimal_data, output_path)
        assert os.path.exists(result)


# ---------------------------------------------------------------------------
# Integration test - full pipeline with real data
# ---------------------------------------------------------------------------
class TestIntegration:
    def test_full_report_with_real_data(self, sample_data, output_path):
        """Generate the complete report and validate all tabs are present."""
        if not sample_data:
            pytest.skip("No sample data")

        result = generate_report(sample_data, output_path)
        assert os.path.exists(result)

        wb = load_workbook(result)

        # Check all expected tabs exist
        expected_tabs = TAB_NAMES
        for tab in expected_tabs:
            assert tab in wb.sheetnames, f"Missing tab: {tab}"

        # Check Cover tab has content
        cover_ws = wb["Cover"]
        assert cover_ws.cell(2, 2).value == "MONETA"

        # Check Account Summary has data
        acct_ws = wb["Account Summary"]
        assert acct_ws.max_row > 3

        # Check EOD Detailed has data
        eod_ws = wb["EOD Detailed"]
        assert eod_ws.max_row > 10

        # Check Fraud tab has the probability score
        fraud_ws = wb["Fraud Analysis"]
        assert fraud_ws.max_row > 5

    def test_end_to_end_from_file(self, output_path):
        """Test the full file-to-file pipeline."""
        if not os.path.exists(SAMPLE_JSON):
            pytest.skip("No sample JSON file")

        result = generate_from_file(SAMPLE_JSON, output_path)
        assert os.path.exists(result)

        wb = load_workbook(result)
        assert len(wb.sheetnames) == len(TAB_NAMES)

    def test_report_file_size(self, sample_data, output_path):
        """Report should be a reasonable size."""
        if not sample_data:
            pytest.skip("No sample data")

        generate_report(sample_data, output_path)
        size = os.path.getsize(output_path)
        assert size > 1000, "Report too small - likely empty"
        assert size < 50_000_000, "Report too large"
