""" gitodo-bin-linux-arm64-gnu """


def main() -> None:
    print("  gitodo-bin-linux-arm64-gnu  ")
