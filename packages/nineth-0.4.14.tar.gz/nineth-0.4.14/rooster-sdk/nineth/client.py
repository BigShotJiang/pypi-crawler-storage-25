"""Python client for the 1984 model API."""

from __future__ import annotations

import json
import os
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional, Union

import httpx

from nineth._constants import (
    DEFAULT_BASE_URL,
    DEFAULT_STREAM_TIMEOUT,
    DEFAULT_TIMEOUT,
    AVAILABLE_MODELS,
    _API_KEY_HEADER,
)
from nineth._helpers import (
    _build_payload,
    _parse_sse_lines,
    _raise_for_status,
    _raise_for_stream_event,
    _trim_event,
    _trim_response,
)
from nineth._streaming import _coalesce_deltas, _service_status_delta


class NinethAPIError(RuntimeError):
    """Raised when the API returns an error response."""


# ---------------------------------------------------------------------------
# ModelProxy — the `client.model` namespace
# ---------------------------------------------------------------------------

class _ModelProxy:
    """Provides ``client.model.request(...)``."""

    def __init__(self, client: "NinethClient") -> None:
        self._client = client

    def request(
        self,
        task_input: str,
        *,
        model: Optional[str] = None,
        stream: bool = False,
        reasoning: Optional[str] = None,
        show_reasoning: bool = False,
        max_iterations: int = 10,
        continuous: Optional[bool] = None,
        images: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
    ) -> Union[Dict[str, Any], Iterator[Dict[str, Any]]]:
        """
        Send a task to the model.

        Args:
            task_input:     The task or question for the model.
            model:          Model name, e.g. ``"1984-m3-0317"``.
                            Falls back to the client ``default_model``.
            stream:         ``True`` → yields live text deltas as they arrive.
                            ``False`` (default) → returns the full response at once.
            reasoning:      Reasoning depth hint: ``"low"``, ``"medium"``, or ``"high"``.
            show_reasoning: Include the model's internal reasoning in the output.
            max_iterations: How many model turns the server may run. Default: ``10``.
            continuous:     Keep the loop running even without service calls.
                            Defaults to ``True`` when ``max_iterations > 10``.
            images:         Base64-encoded images for multimodal requests.
            system_prompt:  Override the default system prompt.

        Returns:
            When ``stream=False``: a dict with ``final_response`` and ``iterations``.
            When ``stream=True``:  an iterator of event dicts. Text arrives as
            ``{"type": "model_delta", "data": {"text": "..."}}``. The last event
            is ``{"type": "result", ...}`` with the full ``final_response``.

        Raises:
            ValueError:      When no model is configured.
            NinethAPIError:  When the server returns an error.
        """
        resolved_model = model or self._client.default_model
        if not resolved_model:
            raise ValueError(
                "A model is required. Pass model=... or set default_model / NINETH_MODEL."
            )
        if stream:
            return self._client._stream_request(
                task_input, resolved_model,
                reasoning=reasoning, show_reasoning=show_reasoning,
                max_iterations=max_iterations, continuous=continuous,
                images=images, system_prompt=system_prompt,
            )
        return self._client._buffered_request(
            task_input, resolved_model,
            reasoning=reasoning, show_reasoning=show_reasoning,
            max_iterations=max_iterations, continuous=continuous,
            images=images, system_prompt=system_prompt,
        )


class _AsyncModelProxy:
    """Async version of ``_ModelProxy``. Used on ``AsyncNinethClient``."""

    def __init__(self, client: "AsyncNinethClient") -> None:
        self._client = client

    async def request(
        self,
        task_input: str,
        *,
        model: Optional[str] = None,
        stream: bool = False,
        reasoning: Optional[str] = None,
        show_reasoning: bool = False,
        max_iterations: int = 10,
        continuous: Optional[bool] = None,
        images: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
    ) -> Union[Dict[str, Any], AsyncIterator[Dict[str, Any]]]:
        """
        Send a task to the model (async).

        When ``stream=False`` awaits the full response and returns a dict.
        When ``stream=True`` returns an async iterator::

            async for event in await client.model.request("task", stream=True):
                if event["type"] == "model_delta":
                    print(event["data"]["text"], end="")
        """
        resolved_model = model or self._client.default_model
        if not resolved_model:
            raise ValueError(
                "A model is required. Pass model=... or set default_model / NINETH_MODEL."
            )
        if stream:
            return self._client._stream_request(
                task_input, resolved_model,
                reasoning=reasoning, show_reasoning=show_reasoning,
                max_iterations=max_iterations, continuous=continuous,
                images=images, system_prompt=system_prompt,
            )
        return await self._client._buffered_request(
            task_input, resolved_model,
            reasoning=reasoning, show_reasoning=show_reasoning,
            max_iterations=max_iterations, continuous=continuous,
            images=images, system_prompt=system_prompt,
        )


# ---------------------------------------------------------------------------
# Public clients
# ---------------------------------------------------------------------------

class NinethClient:
    """
    Synchronous client for the 1984 model API.

    Basic usage::

        from nineth import NinethClient

        with NinethClient(default_model="1984-m3-0317") as client:
            response = client.model.request("Summarise BTC today.")
            print(response["final_response"])

    Streaming::

        with NinethClient(default_model="1984-m3-0317") as client:
            for event in client.model.request("Summarise BTC today.", stream=True):
                if event["type"] == "model_delta":
                    print(event["data"]["text"], end="", flush=True)
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        *,
        default_model: Optional[str] = None,
        timeout: Union[httpx.Timeout, float, None] = DEFAULT_TIMEOUT,
        stream_timeout: Union[httpx.Timeout, float, None] = DEFAULT_STREAM_TIMEOUT,
        headers: Optional[Dict[str, str]] = None,
    ):
        resolved_base_url = (base_url or os.getenv("NINETH_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        resolved_api_key = api_key or os.getenv("NINETH_API_KEY")

        request_headers: Dict[str, str] = dict(headers or {})
        if resolved_api_key:
            request_headers.setdefault(_API_KEY_HEADER, resolved_api_key)

        self.base_url = resolved_base_url
        self.api_key = resolved_api_key
        self.default_model: Optional[str] = (
            default_model
            or os.getenv("NINETH_DEFAULT_MODEL")
            or os.getenv("NINETH_MODEL")
        )
        self._stream_timeout = stream_timeout
        self._http = httpx.Client(
            base_url=resolved_base_url,
            timeout=timeout,
            headers=request_headers or None,
        )
        self.model = _ModelProxy(self)

    def _ensure_api_key(self) -> None:
        if not self.api_key and _API_KEY_HEADER not in self._http.headers:
            raise ValueError(
                "Authentication required. Pass api_key=... or set NINETH_API_KEY."
            )

    def health(self) -> Dict[str, Any]:
        """Check that the API is reachable.  Does not require authentication."""
        response = self._http.get("/health")
        _raise_for_status(response)
        return response.json()

    def _buffered_request(
        self,
        task_input: str,
        model: str,
        *,
        reasoning: Optional[str],
        show_reasoning: bool,
        max_iterations: int,
        images: Optional[List[str]],
        system_prompt: Optional[str],
        continuous: Optional[bool] = None,
    ) -> Dict[str, Any]:
        self._ensure_api_key()
        payload = _build_payload(
            task_input, model,
            reasoning=reasoning, show_reasoning=show_reasoning,
            max_iterations=max_iterations, images=images,
            system_prompt=system_prompt, continuous=continuous,
        )
        response = self._http.post("/model", json=payload)
        _raise_for_status(response)
        return _trim_response(response.json())

    def _stream_request(
        self,
        task_input: str,
        model: str,
        *,
        reasoning: Optional[str],
        show_reasoning: bool,
        max_iterations: int,
        images: Optional[List[str]],
        system_prompt: Optional[str],
        continuous: Optional[bool] = None,
    ) -> Iterator[Dict[str, Any]]:
        self._ensure_api_key()
        payload = _build_payload(
            task_input, model,
            reasoning=reasoning, show_reasoning=show_reasoning,
            max_iterations=max_iterations, images=images,
            system_prompt=system_prompt, continuous=continuous,
        )
        with self._http.stream("POST", "/model/stream", json=payload, timeout=self._stream_timeout) as response:
            _raise_for_status(response)
            for event in _coalesce_deltas(_parse_sse_lines(response.iter_lines())):
                _raise_for_stream_event(event)
                yield _trim_event(event)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "NinethClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


class AsyncNinethClient:
    """
    Asynchronous client for the 1984 model API.

    Basic usage::

        import asyncio
        from nineth import AsyncNinethClient

        async def main():
            async with AsyncNinethClient(default_model="1984-m3-0317") as client:
                response = await client.model.request("Summarise ETH today.")
                print(response["final_response"])

        asyncio.run(main())
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        *,
        default_model: Optional[str] = None,
        timeout: Union[httpx.Timeout, float, None] = DEFAULT_TIMEOUT,
        stream_timeout: Union[httpx.Timeout, float, None] = DEFAULT_STREAM_TIMEOUT,
        headers: Optional[Dict[str, str]] = None,
    ):
        resolved_base_url = (base_url or os.getenv("NINETH_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        resolved_api_key = api_key or os.getenv("NINETH_API_KEY")

        request_headers: Dict[str, str] = dict(headers or {})
        if resolved_api_key:
            request_headers.setdefault(_API_KEY_HEADER, resolved_api_key)

        self.base_url = resolved_base_url
        self.api_key = resolved_api_key
        self.default_model: Optional[str] = (
            default_model
            or os.getenv("NINETH_DEFAULT_MODEL")
            or os.getenv("NINETH_MODEL")
        )
        self._stream_timeout = stream_timeout
        self._http = httpx.AsyncClient(
            base_url=resolved_base_url,
            timeout=timeout,
            headers=request_headers or None,
        )
        self.model = _AsyncModelProxy(self)

    def _ensure_api_key(self) -> None:
        if not self.api_key and _API_KEY_HEADER not in self._http.headers:
            raise ValueError(
                "Authentication required. Pass api_key=... or set NINETH_API_KEY."
            )

    async def health(self) -> Dict[str, Any]:
        """Check that the API is reachable.  Does not require authentication."""
        response = await self._http.get("/health")
        _raise_for_status(response)
        return response.json()

    async def _buffered_request(
        self,
        task_input: str,
        model: str,
        *,
        reasoning: Optional[str],
        show_reasoning: bool,
        max_iterations: int,
        continuous: Optional[bool] = None,
        images: Optional[List[str]],
        system_prompt: Optional[str],
    ) -> Dict[str, Any]:
        self._ensure_api_key()
        payload = _build_payload(
            task_input, model,
            reasoning=reasoning, show_reasoning=show_reasoning,
            max_iterations=max_iterations, continuous=continuous,
            images=images, system_prompt=system_prompt,
        )
        response = await self._http.post("/model", json=payload)
        _raise_for_status(response)
        return _trim_response(response.json())

    def _stream_request(
        self,
        task_input: str,
        model: str,
        *,
        reasoning: Optional[str],
        show_reasoning: bool,
        max_iterations: int,
        continuous: Optional[bool] = None,
        images: Optional[List[str]],
        system_prompt: Optional[str],
    ) -> AsyncIterator[Dict[str, Any]]:
        self._ensure_api_key()
        payload = _build_payload(
            task_input, model,
            reasoning=reasoning, show_reasoning=show_reasoning,
            max_iterations=max_iterations, continuous=continuous,
            images=images, system_prompt=system_prompt,
        )

        async def _gen() -> AsyncIterator[Dict[str, Any]]:
            async with self._http.stream(
                "POST",
                "/model/stream",
                json=payload,
                timeout=self._stream_timeout,
            ) as response:
                _raise_for_status(response)
                event_type = "message"
                data_lines: list[str] = []
                delta_buffer = ""

                async def _flush() -> Optional[Dict[str, Any]]:
                    nonlocal delta_buffer
                    if delta_buffer:
                        evt: Dict[str, Any] = {"type": "model_delta", "data": {"text": delta_buffer}}
                        delta_buffer = ""
                        return evt
                    return None

                async for raw_line in response.aiter_lines():
                    line = raw_line.rstrip("\r")
                    if not line:
                        if data_lines:
                            parsed: Dict[str, Any] = json.loads("\n".join(data_lines))
                            parsed.setdefault("type", event_type)
                            _raise_for_stream_event(parsed)
                            if parsed.get("type") == "model_delta":
                                delta_buffer += parsed.get("data", {}).get("text", "")
                                if delta_buffer and (delta_buffer[-1] in " \n\t" or len(delta_buffer) >= 80):
                                    yield {"type": "model_delta", "data": {"text": delta_buffer}}
                                    delta_buffer = ""
                            else:
                                flushed = await _flush()
                                if flushed:
                                    yield _trim_event(flushed)
                                if parsed.get("type") == "service_call":
                                    svc = parsed.get("data", {}).get("service_name", "")
                                    status = _service_status_delta(svc)
                                    if status:
                                        yield status
                                yield _trim_event(parsed)
                        event_type = "message"
                        data_lines = []
                        continue
                    if line.startswith(":"):
                        continue
                    if line.startswith("event:"):
                        event_type = line.split(":", 1)[1].strip()
                        continue
                    if line.startswith("data:"):
                        data_lines.append(line.split(":", 1)[1].strip())

                if data_lines:
                    parsed = json.loads("\n".join(data_lines))
                    parsed.setdefault("type", event_type)
                    _raise_for_stream_event(parsed)
                    if parsed.get("type") == "model_delta":
                        delta_buffer += parsed.get("data", {}).get("text", "")
                    else:
                        flushed = await _flush()
                        if flushed:
                            yield _trim_event(flushed)
                        yield _trim_event(parsed)
                if delta_buffer:
                    yield {"type": "model_delta", "data": {"text": delta_buffer}}

        return _gen()

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncNinethClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()
