"""Internal HTTP and payload helpers — not part of the public API."""

from __future__ import annotations

import json
from typing import Any, Dict, Iterator, List, Optional

import httpx


# ---------------------------------------------------------------------------
# Payload builder
# ---------------------------------------------------------------------------

def _build_payload(
    task_input: str,
    model: str,
    *,
    max_iterations: int,
    reasoning: Optional[str],
    show_reasoning: bool,
    images: Optional[List[str]],
    system_prompt: Optional[str],
    continuous: Optional[bool] = None,
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "task_input": task_input,
        "model": model,
        "max_iterations": max_iterations,
        "show_reasoning": show_reasoning,
        "continuous": continuous if continuous is not None else (max_iterations > 10),
    }
    if reasoning is not None:
        payload["reasoning_effort"] = reasoning
    if images:
        payload["images"] = images
    if system_prompt:
        payload["system_prompt"] = system_prompt
    return payload


# ---------------------------------------------------------------------------
# Error helpers
# ---------------------------------------------------------------------------

def _raise_for_status(response: httpx.Response) -> None:
    try:
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        from nineth.client import NinethAPIError
        message = response.text.strip() or str(exc)
        raise NinethAPIError(message) from exc


def _raise_for_stream_event(event: Dict[str, Any]) -> None:
    if event.get("type") != "error":
        return
    from nineth.client import NinethAPIError
    data = event.get("data", {})
    if isinstance(data, dict):
        message = data.get("message") or data.get("error") or "Streaming request failed."
    else:
        message = str(data) or "Streaming request failed."
    raise NinethAPIError(message)


# ---------------------------------------------------------------------------
# SSE parser
# ---------------------------------------------------------------------------

def _parse_sse_lines(lines: Iterator[str]) -> Iterator[Dict[str, Any]]:
    event_type = "message"
    data_lines: list[str] = []

    for raw_line in lines:
        line = raw_line.rstrip("\r")
        if not line:
            if data_lines:
                payload = json.loads("\n".join(data_lines))
                payload.setdefault("type", event_type)
                yield payload
            event_type = "message"
            data_lines = []
            continue
        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            event_type = line.split(":", 1)[1].strip()
            continue
        if line.startswith("data:"):
            data_lines.append(line.split(":", 1)[1].strip())

    if data_lines:
        payload = json.loads("\n".join(data_lines))
        payload.setdefault("type", event_type)
        yield payload


# ---------------------------------------------------------------------------
# Response trimming
# ---------------------------------------------------------------------------

_BUFFERED_KEEP = {
    "final_response", "iterations", "thinking",
    "service_calls", "service_responses", "usage", "events",
}


def _trim_response(body: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in body.items() if k in _BUFFERED_KEEP}


def _trim_event(event: Dict[str, Any]) -> Dict[str, Any]:
    return event
