"""Character-level normalization and segmentation."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

from riff_kg.config import KgConfig


@dataclass(frozen=True)
class TextSegmentPiece:
    """Half-open range [char_offset_start, char_offset_end) over normalized text."""

    char_offset_start: int
    char_offset_end: int
    body: str

    def __post_init__(self) -> None:
        if self.char_offset_end < self.char_offset_start:
            raise ValueError("char_offset_end must be >= char_offset_start")
        expected_len = self.char_offset_end - self.char_offset_start
        if len(self.body) != expected_len:
            raise ValueError("body length must match half-open span")


def normalize_text(raw: str) -> str:
    """Strip, Unicode NFC, collapse runs of whitespace/newlines (conservative)."""
    t = unicodedata.normalize("NFC", (raw or "").strip())
    t = re.sub(r"\r\n", "\n", t)
    t = re.sub(r"\n{4,}", "\n\n\n", t)
    t = re.sub(r"[ \t]{2,}", " ", t)
    return t


def segment_text(normalized: str, cfg: KgConfig) -> list[TextSegmentPiece]:
    """Split normalized text into >=1 segment using kit chunk policy."""
    if not normalized:
        return [TextSegmentPiece(0, 0, "")]

    n = len(normalized)
    if n <= cfg.chunk_if_longer_than_chars:
        return [TextSegmentPiece(0, n, normalized)]

    if cfg.chunking_strategy == "semantic":
        return _segment_text_semantic(normalized, cfg)
    return _segment_text_char(normalized, cfg)


def _segment_text_char(normalized: str, cfg: KgConfig) -> list[TextSegmentPiece]:
    """Legacy fixed-width character window chunking."""
    max_len = cfg.chunk_max_chars
    overlap = min(cfg.chunk_overlap_chars, max_len - 1) if max_len > 1 else 0
    n = len(normalized)
    pieces: list[TextSegmentPiece] = []
    start = 0
    while start < n:
        end = min(start + max_len, n)
        body = normalized[start:end]
        pieces.append(TextSegmentPiece(start, end, body))
        if end == n:
            break
        nxt = max(0, end - overlap)
        if nxt <= start:
            nxt = end
        start = nxt
    return pieces


def _segment_text_semantic(normalized: str, cfg: KgConfig) -> list[TextSegmentPiece]:
    """Prefer paragraph/sentence/whitespace boundaries within max window."""
    n = len(normalized)
    max_len = cfg.chunk_max_chars
    overlap = min(cfg.chunk_overlap_chars, max_len - 1) if max_len > 1 else 0
    min_seek = max(1, max_len // 3)

    paragraph_breaks = {
        m.end()
        for m in re.finditer(r"\n{2,}", normalized)
    }
    sentence_breaks = {
        m.end()
        for m in re.finditer(r'[.!?]["\')\]]?\s+', normalized)
    }
    whitespace_breaks = {
        m.end()
        for m in re.finditer(r"\s+", normalized)
    }

    pieces: list[TextSegmentPiece] = []
    start = 0
    while start < n:
        hard_end = min(start + max_len, n)
        if hard_end == n:
            end = n
        else:
            soft_min = min(start + min_seek, hard_end)
            end = _best_breakpoint(start, soft_min, hard_end, paragraph_breaks)
            if end is None:
                end = _best_breakpoint(start, soft_min, hard_end, sentence_breaks)
            if end is None:
                end = _best_breakpoint(start, soft_min, hard_end, whitespace_breaks)
            if end is None:
                end = hard_end

        pieces.append(TextSegmentPiece(start, end, normalized[start:end]))
        if end == n:
            break

        nxt = max(0, end - overlap)
        if nxt <= start:
            nxt = end
        while nxt < n and normalized[nxt].isspace():
            nxt += 1
        start = nxt

    return pieces


def _best_breakpoint(
    start: int,
    soft_min: int,
    hard_end: int,
    breaks: set[int],
) -> int | None:
    candidates = [b for b in breaks if soft_min <= b <= hard_end and b > start]
    if not candidates:
        return None
    return max(candidates)
