﻿"""Runtime configuration: chunking, embeddings, closed-world type registry."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class KgConfig(BaseModel):
    """Kit behavior for one Riff app deployment. Load from JSON/YAML or env."""

    model_config = {"extra": "forbid"}

    embedding_dimension: int = Field(default=768, ge=32, le=4096)
    chunk_max_chars: int = Field(default=8000, ge=500)
    chunk_overlap_chars: int = Field(default=400, ge=0)
    chunk_if_longer_than_chars: int = Field(
        default=12000,
        ge=1000,
        description="Below this size, keep a single segment (still stored as segment index 0).",
    )
    chunking_strategy: Literal["char", "semantic"] = Field(
        default="char",
        description="Chunking strategy: fixed character windows or semantic boundary-aware windows.",
    )
    entity_types: tuple[str, ...] = Field(
        default=("Entity",),
        description="Allowed entity type labels at commit validation.",
    )
    relation_types: tuple[str, ...] = Field(
        default=("related_to",),
        description="Allowed relation predicates at commit validation.",
    )
    profile_uri: str | None = Field(
        default=None,
        description="Optional storage key or path to extraction JSON schema profile.",
    )

    def effective_chunking(self) -> dict[str, int | str]:
        return {
            "chunk_max_chars": self.chunk_max_chars,
            "chunk_overlap_chars": self.chunk_overlap_chars,
            "chunk_if_longer_than_chars": self.chunk_if_longer_than_chars,
            "chunking_strategy": self.chunking_strategy,
        }
