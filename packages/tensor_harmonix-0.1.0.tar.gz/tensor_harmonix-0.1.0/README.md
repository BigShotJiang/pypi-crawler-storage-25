# Fully-Differentiable Tensor Spherical Harmonics in JAX

<p align="center">
<img width="596" height="409" alt="image" src="https://github.com/user-attachments/assets/e16fd0c7-a2c3-4651-8f65-731e23a16eb1" />
</p>

Here, we have implemented the *tensor spherical harmonics* in [JAX](https://github.com/jax-ml/jax), building on top of the [e3nn-jax](https://github.com/e3nn/e3nn-jax) framework. 

```bash
uv pip install tensor-harmonix
```

The [tensor spherical harmonics](https://scipp-legacy.pbsci.ucsc.edu/~haber/archives/physics214_13/tensor_harmonics.pdf) are functions defined on the sphere $S^2$ mapping each point to a $SO(3)$ irrep of type $s$, making the whole function transforms as the tensor product rep $s \otimes l$ of $SO(3)$ for different values of $l$. The usual (scalar) [spherical harmonics](https://en.wikipedia.org/wiki/Spherical_harmonics) are simply $s = 0$, as $0 \otimes l \equiv l$. Thus, the tensor spherical harmonics are a generalization of the spherical harmonics to arbitrary spin $s \geq 0$.

For example, to create the tensor spherical harmonic corresponding to $s = 2, l = 1, j = 2, m_j = 0$:
```python
from tensor_harmonix import TensorSphericalHarmonics
x = TensorSphericalHarmonics.tensor_spherical_harmonic(s=2, l=1, j=2, mj=0, parity=1)
```

To obtain the coefficients of the tensor spherical harmonics from a tensor field:
```python
x = TensorSphericalHarmonics.from_tensor_signal(
    tensor_signal, # e3nn.SphericalSignal with dimension [2s + 1, res_beta, res_alpha].
    s=2,
    lmax=10,
    parity=1
)
```
and to convert the coefficients back to a tensor field at a given resolution (here, a $100 \times 99$ Gauss-Legendre Grid):
```python
tensor_signal = x.to_tensor_signal(
    res_beta=100,
    res_alpha=99,
    quadrature="gausslegendre"
)
```

If you only want to evaluate the tensor spherical harmonic coefficients at a given set of points, you can do:
```python
points = jax.random.normal(jax.random.PRNGKey(0), shape=(10, 3))  # 10 random points
points = points / jnp.linalg.norm(points, axis=-1, keepdims=True)  # Normalize to lie on the sphere

values_at_points = x.at_points(points) # e3nn.IrrepsArray with shape [10, 2s + 1] containing the values of the tensor spherical harmonic at the given points.
```

Further, we have implemented the corresponding *tensor spherical tensor product* (TSTP) which interacts two tensor fields on the sphere.
See our [preprint](https://arxiv.org/abs/2602.21466) to understand how the tensor spherical tensor product enables faster Clebsch-Gordan tensor products.

```python
x = TensorSphericalHarmonics.normal(s=2, lmax=2, parity=1, key=jax.random.PRNGKey(0))
y = TensorSphericalHarmonics.normal(s=2, lmax=2, parity=1, key=jax.random.PRNGKey(1))

z = x.reduce_pointwise_tensor_product(y, s_out=3, res_beta=100, res_alpha=99, quadrature="gausslegendre")
```

Our implementation directly leads to the *vector spherical harmonics* by simply setting $s = 1$:
```python
from tensor_harmonix import VectorSphericalHarmonics
x = VectorSphericalHarmonics.vector_spherical_harmonic(l=1, j=2, mj=0, parity=1)
```
as well as the corresponding *vector spherical tensor product* (VSTP) which interacts two vector fields on the sphere:
```python
x = VectorSphericalHarmonics.normal(lmax=2, parity=1, key=jax.random.PRNGKey(0))
y = VectorSphericalHarmonics.normal(lmax=2, parity=1, key=jax.random.PRNGKey(1))

z = x.reduce_pointwise_cross_product(y, res_beta=100, res_alpha=99, quadrature="gausslegendre")
```

See our [example notebooks](https://github.com/atomicarchitects/tensor-spherical-harmonics/tree/main/examples)!

## Citation

Please cite our [preprint](https://arxiv.org/abs/2602.21466) if you use this repository:

```bibtex
@misc{xie2026asymptoticallyfastclebschgordantensor,
  title={Asymptotically Fast Clebsch-Gordan Tensor Products with Vector Spherical Harmonics}, 
  author={YuQing Xie and Ameya Daigavane and Mit Kotak and Tess Smidt},
  year={2026},
  eprint={2602.21466},
  archivePrefix={arXiv},
  primaryClass={cs.LG},
  url={https://arxiv.org/abs/2602.21466}, 
}
```
