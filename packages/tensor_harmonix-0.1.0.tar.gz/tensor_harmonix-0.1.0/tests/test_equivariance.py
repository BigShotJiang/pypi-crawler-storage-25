import jax
import jax.numpy as jnp
import e3nn_jax as e3nn
import pytest

from tensor_harmonix import TensorSphericalHarmonics, VectorSphericalHarmonics


@pytest.mark.parametrize("lmax", [0, 1, 2, 3])
@pytest.mark.parametrize("seed", [0, 1, 2, 3, 4])
def test_reduce_pointwise_tensor_product_equivariance(seed, lmax):
    x_key, y_key, R_key = jax.random.split(jax.random.PRNGKey(seed), 3)

    x = TensorSphericalHarmonics.normal(s=2, lmax=lmax, parity=1, key=x_key)
    y = TensorSphericalHarmonics.normal(s=2, lmax=lmax, parity=1, key=y_key)

    tp_kwargs = dict(s_out=3, res_beta=100, res_alpha=99, quadrature="gausslegendre")
    z = x.reduce_pointwise_tensor_product(y, **tp_kwargs)

    R = e3nn.rand_matrix(key=R_key)

    z_rot = z.rotate(R)
    z_rot_from_xy = x.rotate(R).reduce_pointwise_tensor_product(y.rotate(R), **tp_kwargs)

    assert jnp.allclose(z_rot.coeffs.array, z_rot_from_xy.coeffs.array, atol=1e-4), "Equivariance check failed: arrays not close enough"


@pytest.mark.parametrize("lmax", [0, 1, 2, 3])
@pytest.mark.parametrize("seed", [0, 1, 2, 3, 4])
def test_reduce_pointwise_cross_product_equivariance(seed, lmax):
    x_key, y_key, R_key = jax.random.split(jax.random.PRNGKey(seed), 3)

    x = VectorSphericalHarmonics.normal(lmax=lmax, parity=1, key=x_key)
    y = VectorSphericalHarmonics.normal(lmax=lmax, parity=1, key=y_key)

    tp_kwargs = dict(res_beta=100, res_alpha=99, quadrature="gausslegendre")
    z = x.reduce_pointwise_cross_product(y, **tp_kwargs)

    R = e3nn.rand_matrix(key=R_key)

    z_rot = z.rotate(R)
    z_rot_from_xy = x.rotate(R).reduce_pointwise_cross_product(y.rotate(R), **tp_kwargs)

    assert jnp.allclose(z_rot.coeffs.array, z_rot_from_xy.coeffs.array, atol=1e-4), "Equivariance check failed: arrays not close enough"