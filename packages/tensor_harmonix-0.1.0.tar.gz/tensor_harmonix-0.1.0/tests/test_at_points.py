import jax
import jax.numpy as jnp
import e3nn_jax as e3nn
import pytest

from tensor_harmonix import TensorSphericalHarmonics


@pytest.mark.parametrize("s", [0, 1, 2, 3])
@pytest.mark.parametrize("lmax", [0, 1, 2, 3])
@pytest.mark.parametrize("seed", [0, 1, 2, 3, 4])
def test_at_points_matches_grid_values(seed, s, lmax):
    tsh_key, beta_key, alpha_key = jax.random.split(jax.random.PRNGKey(seed), 3)

    res_beta = 100
    res_alpha = 99
    quadrature = "gausslegendre"

    true_tsh = TensorSphericalHarmonics.normal(s=s, lmax=lmax, parity=1, key=tsh_key)
    true_signal = true_tsh.to_tensor_signal(res_beta, res_alpha, quadrature)

    random_indices_beta = jax.random.choice(beta_key, res_beta, shape=(10,), replace=False)
    random_indices_alpha = jax.random.choice(alpha_key, res_alpha, shape=(9,), replace=False)

    for i in range(10):
        for j in range(9):
            point = true_signal.grid_vectors[random_indices_beta[i], random_indices_alpha[j]]
            value = true_tsh.at_points(point).array
            expected = true_signal.grid_values[:, random_indices_beta[i], random_indices_alpha[j]]

            diff = jnp.linalg.norm(value - expected)
            assert jnp.allclose(value, expected, atol=2e-5), f"Mismatch at point {point}: value={value}, expected={expected}, diff={diff}"