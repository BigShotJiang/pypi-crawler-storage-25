"""Implements the Vector Spherical Harmonics (VSH) and Vector Spherical Tensor Product (VSTP)."""

import jax
import jax.numpy as jnp
import numpy as np
import e3nn_jax as e3nn

from .tensor_spherical_harmonics import TensorSphericalHarmonics


@jax.tree_util.register_pytree_node_class
class VectorSphericalHarmonics(TensorSphericalHarmonics):
    """VSH: TSH with s=1 fixed."""

    def __init__(self, coeffs: e3nn.IrrepsArray, lmax: int, parity: int = 1):
        super().__init__(coeffs, s=1, lmax=lmax, parity=parity)

    @classmethod
    def get_irreps(cls, *, lmax: int, parity: int) -> e3nn.Irreps:
        return TensorSphericalHarmonics.get_irreps(s=1, lmax=lmax, parity=parity)

    @classmethod
    def zeros(cls, *, lmax: int, parity: int) -> "VectorSphericalHarmonics":
        return cls(
            e3nn.zeros(cls.get_irreps(lmax=lmax, parity=parity)),
            lmax=lmax,
            parity=parity,
        )

    @classmethod
    def normal(cls, *, lmax: int, parity: int, key) -> "VectorSphericalHarmonics":
        return cls(
            e3nn.normal(cls.get_irreps(lmax=lmax, parity=parity), key),
            lmax=lmax,
            parity=parity,
        )

    @classmethod
    def vector_spherical_harmonic(
        cls, l: int, j: int, mj: int, parity: int = 1
    ) -> "VectorSphericalHarmonics":
        tsh = TensorSphericalHarmonics.tensor_spherical_harmonic(
            s=1, l=l, j=j, mj=mj, parity=parity
        )
        return cls(tsh.coeffs, lmax=l, parity=parity)

    @classmethod
    def from_tensor_signal(cls, sig: e3nn.SphericalSignal, lmax: int, parity: int = 1):
        return super().from_tensor_signal(sig, s=1, lmax=lmax, parity=parity)

    def rotate(self, R: jnp.ndarray) -> "VectorSphericalHarmonics":
        result = super().rotate(R)
        return VectorSphericalHarmonics(
            result.coeffs, lmax=self.lmax, parity=self.parity
        )

    def tree_flatten(self):
        return (self.coeffs,), (self.lmax, self.parity)

    @classmethod
    def tree_unflatten(cls, aux_data, children):
        lmax, parity = aux_data
        return cls(children[0], lmax=lmax, parity=parity)

    def reduce_pointwise_cross_product(
        self,
        other: "VectorSphericalHarmonics",
        res_beta: int,
        res_alpha: int,
        quadrature: str = "gausslegendre",
    ) -> "VectorSphericalHarmonics":
        """Computes the pointwise cross product on the sphere, and converts back to VSH coefficients."""
        tsh = self.reduce_pointwise_tensor_product(
            other,
            s_out=1,
            res_beta=res_beta,
            res_alpha=res_alpha,
            quadrature=quadrature,
        )
        return VectorSphericalHarmonics(tsh.coeffs, lmax=tsh.lmax, parity=tsh.parity)

    def plot(
        self,
        res_beta: int = 100,
        res_alpha: int = 99,
        quadrature: str = "gausslegendre",
        size_ref: float = 0.1,
    ):
        """Plot the vector signal as arrows on a sphere."""
        try:
            import plotly.graph_objects as go
        except ImportError:
            raise ImportError(
                "Plotting requires plotly. Please install it with `pip install plotly nbformat>=4.2.0`."
            )

        # Convert to vector signal and extract grid vectors and values
        vector_signal = self.to_tensor_signal(res_beta, res_alpha, quadrature)

        n_dim, res_beta, res_alpha = vector_signal.grid_values.shape
        assert n_dim == 3, (
            f"Expected grid_values to have first dimension=3 for 3D vectors; got first dimension={n_dim}"
        )

        assert vector_signal.grid_vectors.shape == (res_beta, res_alpha, 3), (
            f"Expected grid_vectors to have shape ({res_beta}, {res_alpha}, 3)"
        )
        x, y, z = (
            vector_signal.grid_vectors[:, :, 0],
            vector_signal.grid_vectors[:, :, 1],
            vector_signal.grid_vectors[:, :, 2],
        )

        assert vector_signal.grid_values.shape == (3, res_beta, res_alpha), (
            f"Expected grid_values to have shape (3, {res_beta}, {res_alpha})"
        )
        u, v, w = (
            vector_signal.grid_values[0],
            vector_signal.grid_values[1],
            vector_signal.grid_values[2],
        )

        fig = go.Figure(
            data=go.Cone(
                x=x.flatten(),
                y=y.flatten(),
                z=z.flatten(),
                u=u.flatten(),
                v=v.flatten(),
                w=w.flatten(),
                sizemode="raw",
                sizeref=size_ref,
                colorscale="RdBu",
                anchor="tail",
            )
        )
        fig.update_layout(title="Vector Field on Sphere", scene=dict(aspectmode="data"))
        return fig
