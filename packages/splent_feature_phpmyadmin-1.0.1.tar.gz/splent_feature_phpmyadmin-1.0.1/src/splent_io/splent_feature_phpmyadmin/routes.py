# No routes — phpMyAdmin runs as an external Docker container.
# The sidebar hook links directly to its port.
