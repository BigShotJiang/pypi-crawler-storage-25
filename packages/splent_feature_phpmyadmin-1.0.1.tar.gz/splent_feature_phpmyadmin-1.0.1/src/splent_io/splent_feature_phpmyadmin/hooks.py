from splent_framework.hooks.template_hooks import register_template_hook
from flask import current_app


def phpmyadmin_sidebar_link():
    port = current_app.config.get("PMA_HOST_PORT", "8081")
    return (
        '<li class="sidebar-item">'
        f'<a class="sidebar-link" href="http://localhost:{port}" target="_blank">'
        '<i class="align-middle" data-feather="database"></i> '
        '<span class="align-middle">phpMyAdmin</span>'
        "</a>"
        "</li>"
    )


register_template_hook("layout.authenticated_sidebar", phpmyadmin_sidebar_link)
