"""
phpMyAdmin feature configuration.

Exposes the phpMyAdmin URL so hooks can link to it.
"""

import os


def inject_config(app):
    app.config.update(
        {
            "PMA_HOST_PORT": os.getenv("PMA_HOST_PORT", "8081"),
        }
    )
