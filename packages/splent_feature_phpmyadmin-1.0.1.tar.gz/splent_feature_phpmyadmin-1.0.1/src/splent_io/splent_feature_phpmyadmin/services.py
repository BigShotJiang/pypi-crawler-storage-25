# No services — phpMyAdmin is a Docker-only infrastructure feature.
