"""Agent_BRICK - A lightweight HTTP client for BRICK Knowledge Graph API."""

__version__ = "0.1.2"

# 延迟加载，避免循环导入
__all__ = ["query_relation", "rank", "enrich"]

def __getattr__(name):
    if name == "query_relation":
        from querygraph import query_relation
        return query_relation
    elif name == "rank":
        from rankgraph import rank
        return rank
    elif name == "enrich":
        from rankgraph import enrich
        return enrich
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
