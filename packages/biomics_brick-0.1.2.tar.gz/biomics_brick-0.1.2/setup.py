#!/usr/bin/env python3
"""Setup for Agent_BRICK CLI tools."""

from setuptools import setup, find_packages

setup(
    name="Agent_BRICK",
    version="0.1.0",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "BRICK_qr=Agent_BRICK.qr:main",
            "BRICK_rk=Agent_BRICK.rk:main",
        ],
    },
    install_requires=[
        "pandas",
        "requests",
        "scipy",
    ],
    python_requires=">=3.8",
)
