"""LogicVein API Client Library"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("lvi-api-client")
except PackageNotFoundError:
    __version__ = "unknown"

from .lvi_api_client import LogicVeinAPIClient

__all__ = ["LogicVeinAPIClient"]
