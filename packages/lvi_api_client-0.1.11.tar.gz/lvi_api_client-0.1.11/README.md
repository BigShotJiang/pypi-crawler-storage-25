# LogicVein API Client

A Python client for interacting with the LogicVein API.

## Installation

From PyPI:

```bash
pip install lvi-api-client
```

From TestPyPI (pre-release / testing):

```bash
pip install \
  --index-url https://test.pypi.org/simple/ \
  --extra-index-url https://pypi.org/simple/ \
  lvi-api-client
```

See [PUBLISHING.md](PUBLISHING.md) for instructions on publishing new releases.

## Usage

```bash
from lvi_api_client import LogicVeinAPIClient

client = LogicVeinAPIClient(host="your-lvi-server", api_token="your-token")
devices = client.search_devices_in_network()
```
