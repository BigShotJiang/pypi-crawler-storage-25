"""Extensions module for nebo."""
