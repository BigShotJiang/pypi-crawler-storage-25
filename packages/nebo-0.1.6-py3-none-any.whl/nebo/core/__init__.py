"""Core module for nebo."""
