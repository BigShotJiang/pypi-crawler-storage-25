"""MCP module for nebo."""
