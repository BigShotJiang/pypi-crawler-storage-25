"""Logging module for nebo."""
