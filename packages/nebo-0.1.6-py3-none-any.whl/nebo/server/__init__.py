"""Server module for nebo."""
