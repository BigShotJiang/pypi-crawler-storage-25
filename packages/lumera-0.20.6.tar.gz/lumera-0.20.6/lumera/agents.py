"""
Agent invocation, live chat, and management for Lumera.

This module provides a high-level interface for invoking and managing Lumera
agents (AI-powered assistants with tools and skills).

Synchronous invocation:
    invoke()         - Invoke an agent synchronously, returns structured response

Live invocation:
    start_live()     - Start a reconnectable live run and return a thin run handle
    stream_live()    - Stream live SSE events for an agent session/run
    get_live_state() - Derive the latest live snapshot from stream/history
    get_history()    - Read parsed durable session history
    abort_live()     - Abort the active run for a session

Agent management:
    list()           - List all agents
    get()            - Get agent by ID
"""

from __future__ import annotations

import base64
import builtins
import mimetypes
import os
from typing import Any, Iterator, Mapping

__all__ = [
    "invoke",
    "start_live",
    "stream_live",
    "get_live_state",
    "get_history",
    "abort_live",
    "list",
    "get",
    "InvokeResult",
    "AgentLiveState",
    "AgentLiveEnvelope",
    "AgentLiveRun",
    "AgentLiveStreamError",
    "Agent",
]

from ._live import (
    LiveEnvelopeBase,
    LiveRunBase,
    LiveStateBase,
    LiveStreamError,
    _apply_live_envelope_to_state_data,
    _coerce_mapping,
    _live_state_from_history,
    _normalize_live_state_data,
    _normalize_session_id,
    _stream_live_request,
)
from ._utils import LumeraAPIError, _api_request


# ============================================================================
# InvokeResult Class
# ============================================================================


class InvokeResult:
    """Result from invoking an agent."""

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    @property
    def output(self) -> str:
        return self._data.get("output", "")

    @property
    def tool_calls(self) -> list[dict[str, Any]]:
        return self._data.get("tool_calls", [])

    @property
    def usage(self) -> dict[str, Any] | None:
        return self._data.get("usage")

    @property
    def session_id(self) -> str:
        return self._data.get("session_id", "")

    @property
    def success(self) -> bool:
        return self._data.get("success", False)

    @property
    def error(self) -> str | None:
        return self._data.get("error")

    def __repr__(self) -> str:
        status = "ok" if self.success else f"error: {self.error}"
        preview = self.output[:60] + "..." if len(self.output) > 60 else self.output
        return f"InvokeResult({status}, output={preview!r})"


# ============================================================================
# Live thin-client types
# ============================================================================


class AgentLiveState(LiveStateBase):
    """Latest live snapshot for an agent session."""


class AgentLiveEnvelope(LiveEnvelopeBase):
    """Single envelope from the agent live SSE stream."""

    _state_cls = AgentLiveState


class AgentLiveStreamError(LiveStreamError):
    """Raised when an agent live SSE stream ends before terminal state."""


class AgentLiveRun(LiveRunBase):
    """Thin live-run handle returned by :func:`start_live`."""

    def __init__(
        self,
        agent_id: str,
        session_id: str,
        request_id: str | None,
        status: str,
    ) -> None:
        self.agent_id = agent_id
        super().__init__(
            session_id=session_id,
            request_id=request_id,
            status=status,
            stream_fn=lambda **kwargs: stream_live(
                self.agent_id,
                session_id=self.session_id,
                request_id=self.request_id,
                **kwargs,
            ),
            state_fn=lambda **kwargs: get_live_state(
                self.agent_id,
                session_id=self.session_id,
                request_id=self.request_id,
                last_event_id=self.last_event_id,
                **kwargs,
            ),
            history_fn=lambda **kwargs: get_history(
                self.agent_id,
                session_id=self.session_id,
                **kwargs,
            ),
            abort_fn=lambda **kwargs: abort_live(
                self.agent_id,
                session_id=self.session_id,
                **kwargs,
            ),
            state_cls=AgentLiveState,
        )

    def state(self, *, timeout: int = 30) -> AgentLiveState:
        return super().state(timeout=timeout)

    def stream(
        self,
        *,
        wait_ms: int | None = 10000,
        last_event_id: str | None = None,
        timeout: int = 300,
    ) -> Iterator[AgentLiveEnvelope]:
        return super().stream(wait_ms=wait_ms, last_event_id=last_event_id, timeout=timeout)

    def wait(self, *, timeout: int = 300, poll_interval: float = 0.5) -> AgentLiveState:
        return super().wait(timeout=timeout, poll_interval=poll_interval)

    def print_stream(
        self,
        *,
        show_tools: bool = True,
        show_thinking: bool = False,
        show_usage: bool = True,
        show_resets: bool = True,
        timestamps: bool = False,
        wait_ms: int | None = 10000,
        timeout: int = 300,
        file=None,
    ) -> AgentLiveState:
        return super().print_stream(
            show_tools=show_tools,
            show_thinking=show_thinking,
            show_usage=show_usage,
            show_resets=show_resets,
            timestamps=timestamps,
            wait_ms=wait_ms,
            timeout=timeout,
            file=file,
        )

    def __repr__(self) -> str:
        return (
            f"AgentLiveRun(agent_id={self.agent_id!r}, session_id={self.session_id!r}, "
            f"request_id={self.request_id!r}, status={self.status!r})"
        )


# ============================================================================
# Agent Class
# ============================================================================


class Agent:
    """An agent record."""

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    @property
    def id(self) -> str:
        return self._data["id"]

    @property
    def external_id(self) -> str:
        return self._data.get("external_id", "")

    @property
    def name(self) -> str:
        return self._data.get("name", "")

    @property
    def description(self) -> str:
        return self._data.get("description", "")

    @property
    def managed(self) -> bool:
        return self._data.get("managed", False)

    def invoke(
        self,
        message: str,
        *,
        files: list[str | os.PathLike[str]] | None = None,
        session_id: str | None = None,
        timeout: int = 300,
    ) -> InvokeResult:
        return invoke(self.id, message, files=files, session_id=session_id, timeout=timeout)

    def start_live(
        self,
        message: str,
        *,
        files: list[str | os.PathLike[str]] | None = None,
        session_id: str | None = None,
        timeout: int = 30,
    ) -> AgentLiveRun:
        return start_live(self.id, message, files=files, session_id=session_id, timeout=timeout)

    def get_live_state(
        self,
        *,
        session_id: str | None = None,
        request_id: str | None = None,
        timeout: int = 30,
    ) -> AgentLiveState:
        return get_live_state(self.id, session_id=session_id, request_id=request_id, timeout=timeout)

    def get_history(self, *, session_id: str | None = None, timeout: int = 30) -> list[dict[str, Any]]:
        return get_history(self.id, session_id=session_id, timeout=timeout)

    def abort_live(self, *, session_id: str | None = None, timeout: int = 30) -> bool:
        return abort_live(self.id, session_id=session_id, timeout=timeout)

    def __repr__(self) -> str:
        return f"Agent(id={self.id!r}, name={self.name!r})"


# ============================================================================
# Helpers
# ============================================================================


def _encode_file(path: str | os.PathLike[str]) -> dict[str, str]:
    """Read a file from disk and return an inline file dict for the API."""
    path = os.fspath(path)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"File not found: {path}")

    filename = os.path.basename(path)
    content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"

    with open(path, "rb") as f:
        data = f.read()

    return {
        "filename": filename,
        "content": base64.standard_b64encode(data).decode("ascii"),
        "content_type": content_type,
    }


# ============================================================================
# Module-level functions
# ============================================================================


def invoke(
    agent_id: str,
    message: str,
    *,
    files: list[str | os.PathLike[str]] | None = None,
    session_id: str | None = None,
    timeout: int = 300,
) -> InvokeResult:
    """Invoke an agent synchronously and return structured result.

    ``agent_id`` may be either the internal agent ID or the agent's
    ``external_id``.
    """
    payload: dict[str, Any] = {"message": message}
    if session_id:
        payload["session_id"] = session_id
    if files:
        payload["files"] = [_encode_file(f) for f in files]
    result = _api_request(
        "POST",
        f"agents/{agent_id}/invoke",
        json_body=payload,
        timeout=timeout,
    )
    return InvokeResult(_coerce_mapping(result, name="agent invoke"))


def start_live(
    agent_id: str,
    message: str,
    *,
    files: list[str | os.PathLike[str]] | None = None,
    session_id: str | None = None,
    timeout: int = 30,
) -> AgentLiveRun:
    """Start a reconnectable live run for an agent.

    ``agent_id`` may be either the internal agent ID or the agent's
    ``external_id``.
    """
    payload: dict[str, Any] = {"message": message}
    if session_id:
        payload["session_id"] = session_id
    if files:
        payload["files"] = [_encode_file(f) for f in files]

    result = _api_request(
        "POST",
        f"agents/{agent_id}/live/start",
        json_body=payload,
        timeout=timeout,
    )
    data = _coerce_mapping(result, name="agent live start")
    return AgentLiveRun(
        agent_id=agent_id,
        session_id=data.get("session_id", _normalize_session_id(session_id)),
        request_id=data.get("request_id"),
        status=data.get("status", ""),
    )


def get_live_state(
    agent_id: str,
    *,
    session_id: str | None = None,
    request_id: str | None = None,
    last_event_id: str | None = None,
    timeout: int = 30,
) -> AgentLiveState:
    """Derive the latest live snapshot for an agent session.

    Active live snapshots are reconstructed from ``/live/stream`` and require a
    ``request_id``. When no request-local snapshot is available, this falls
    back to durable ``/history`` and returns the latest completed assistant turn
    for the session.
    """
    normalized_session_id = _normalize_session_id(session_id)
    state_data: dict[str, Any] | None = None

    if request_id:
        params: dict[str, Any] = {
            "session_id": normalized_session_id,
            "request_id": request_id,
            "wait_ms": 0,
        }
        try:
            for envelope in _stream_live_request(
                f"agents/{agent_id}/live/stream",
                params=params,
                last_event_id=last_event_id,
                timeout=timeout,
                envelope_cls=AgentLiveEnvelope,
                error_cls=AgentLiveStreamError,
                require_terminal=False,
            ):
                state_data = _apply_live_envelope_to_state_data(
                    state_data,
                    envelope,
                    session_id=normalized_session_id,
                    request_id=request_id,
                    fallback_status="running",
                )
                if envelope.kind == "snapshot":
                    break
        except LumeraAPIError as exc:
            if exc.status_code != 409:
                raise
        if state_data is not None:
            return AgentLiveState(state_data)

    history = get_history(agent_id, session_id=normalized_session_id, timeout=timeout)
    history_state = _live_state_from_history(
        history,
        session_id=normalized_session_id,
        request_id=request_id,
    )
    if history_state is not None:
        return AgentLiveState(history_state)

    if request_id:
        return AgentLiveState(
            _normalize_live_state_data(
                None,
                session_id=normalized_session_id,
                request_id=request_id,
                fallback_status="running",
            )
        )
    raise RuntimeError(
        "Live state snapshots now require request_id; use start_live().wait() or stream()"
    )


def get_history(
    agent_id: str,
    *,
    session_id: str | None = None,
    timeout: int = 30,
) -> list[dict[str, Any]]:
    """Fetch parsed durable session history for an agent session."""
    result = _api_request(
        "GET",
        f"agents/{agent_id}/history",
        params={"session_id": _normalize_session_id(session_id)},
        timeout=timeout,
    )
    data = _coerce_mapping(result, name="agent history")
    messages = data.get("messages")
    if not isinstance(messages, builtins.list):
        raise RuntimeError(f"Unexpected agent history response: messages={type(messages)!r}")
    return [dict(m) if isinstance(m, Mapping) else {"value": m} for m in messages]


def abort_live(agent_id: str, *, session_id: str | None = None, timeout: int = 30) -> bool:
    """Abort the active run for an agent session."""
    result = _api_request(
        "POST",
        f"agents/{agent_id}/abort",
        params={"session_id": _normalize_session_id(session_id)},
        timeout=timeout,
    )
    data = _coerce_mapping(result, name="agent abort")
    return bool(data.get("success", False))


def stream_live(
    agent_id: str,
    *,
    session_id: str | None = None,
    request_id: str | None = None,
    wait_ms: int | None = 10000,
    last_event_id: str | None = None,
    timeout: int = 300,
) -> Iterator[AgentLiveEnvelope]:
    """Stream live SSE envelopes for an agent session/run."""
    if wait_ms is not None and wait_ms < 0:
        raise ValueError("wait_ms must be >= 0")

    params: dict[str, Any] = {"session_id": _normalize_session_id(session_id)}
    if request_id:
        params["request_id"] = request_id
    if wait_ms is not None:
        params["wait_ms"] = wait_ms

    yield from _stream_live_request(
        f"agents/{agent_id}/live/stream",
        params=params,
        last_event_id=last_event_id,
        timeout=timeout,
        envelope_cls=AgentLiveEnvelope,
        error_cls=AgentLiveStreamError,
    )


def list(*, limit: int = 50, offset: int = 0) -> list[Agent]:
    """List all agents."""
    result = _api_request("GET", "agents", params={"limit": limit, "offset": offset})
    agents_data = result.get("agents", []) if isinstance(result, dict) else result
    return [Agent(a) for a in agents_data]


def get(agent_id: str) -> Agent:
    """Get an agent by ID or external_id."""
    result = _api_request("GET", f"agents/{agent_id}")
    return Agent(_coerce_mapping(result, name="agent get"))
