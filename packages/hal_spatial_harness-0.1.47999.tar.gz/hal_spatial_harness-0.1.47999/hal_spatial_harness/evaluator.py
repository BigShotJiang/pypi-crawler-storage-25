# ================= STANDARD LIB =================
import os
from pathlib import Path

# ================= DATA =================
import pandas as pd



from .evaluator_cross_model_diagnostic_synthesis import cross_model_diagnostic_synthesis
from .evaluator_error_taxonomy_induction import error_taxonomy_induction
from .evaluator_structured_signal_extraction import structured_signal_extraction





def HarnessEvaluator(results_path,custom_error_taxonomies=None,max_concurrent=10,model_name="gemma-4-31b-it"):

    results_path=Path(results_path)


    error_taxonomies= custom_error_taxonomies if custom_error_taxonomies else {
        "E1":"perceptual failure — model misidentified or failed to detect a spatial element in the image",
        "E2":"grounding failure — model identified elements but failed to anchor them in the correct spatial frame of reference",
        "E3":"spatial transformation failure — model understood the spatial arrangement but failed to correctly apply a rotation, reflection, or perspective change)",
        "E4":"quantitative spatial failure — failure on counting, distance estimation, or measurement",
        "E5":"multi-step reasoning failure — model solved one spatial step correctly but failed on a subsequent step requiring the first as input",
        "E6":"language-spatial mapping failure — model misunderstood the spatial language in the question, e.g., confused 'left of X' with 'right of X'",
        "E7":"format/refusal failure — model did not produce a valid answer regardless of spatial competence",
    } 

    for model_folder in results_path.iterdir():
        if model_folder.is_dir():
            prev_df_path=(model_folder/"agent_scores.csv")
            prev_df=None
            
            if os.path.exists(prev_df_path) :
                prev_df=pd.read_csv(prev_df_path)
                
            structured_signal_extraction(
                list(model_folder.glob("*.csv"))[0],
                max_concurrent=max_concurrent,
                model_name=model_name,
                prev_df=prev_df
            )
            error_taxonomy_induction(
                list(model_folder.glob("agent_scores.csv"))[0],
                error_taxonomies=error_taxonomies,
                model_name=model_name,
            )

    

    cross_model_diagnostic_synthesis(results_path.rglob("agent_scores.csv"),results_path)

