#!/usr/bin/env python3
"""
test_brain_sync.py — Tests for brain_sync.py multi-agent sync

Covers:
- Export creates valid JSON
- Import handles new records
- Import handles conflicts (newer wins)
- Import skips duplicates
- Credential filtering works
- Round-trip: export -> import -> verify data matches
"""

import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from brain_sync import (
    _CREDENTIAL_PATTERNS,
    _contains_credentials,
    _filter_memory,
    _is_blocked_memory,
    _SYNC_SCHEMA,
    _now_iso,
    export_delta,
    import_delta,
    import_delta_data,
    resolve_conflicts,
    get_status,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _create_test_db(db_path: str):
    """Create a minimal test DB with the required tables."""
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            memory_class TEXT DEFAULT 'semantic',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1,
            source_agent TEXT,
            consolidated_from TEXT
        );

        CREATE TABLE IF NOT EXISTS skill_executions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            skill_name TEXT NOT NULL,
            success INTEGER,
            tokens_used INTEGER,
            duration_seconds REAL,
            error_message TEXT,
            execution_context TEXT,
            created TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS skill_versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            skill_name TEXT NOT NULL,
            version INTEGER NOT NULL,
            skill_path TEXT,
            content_snapshot TEXT,
            content_diff TEXT,
            parent_version_id INTEGER,
            evolution_type TEXT,
            trigger TEXT,
            metric_before REAL,
            metric_after REAL,
            created TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1,
            UNIQUE(skill_name, version)
        );
    """)
    conn.executescript(_SYNC_SCHEMA)
    conn.commit()
    return conn


@pytest.fixture
def neuro_db(tmp_path):
    """Create Neuro's test database."""
    db_path = str(tmp_path / "neuro" / "aibrain.db")
    os.makedirs(str(tmp_path / "neuro"), exist_ok=True)
    conn = _create_test_db(db_path)
    conn.close()
    return db_path


@pytest.fixture
def case_db(tmp_path):
    """Create Case's test database."""
    db_path = str(tmp_path / "case" / "aibrain.db")
    os.makedirs(str(tmp_path / "case"), exist_ok=True)
    conn = _create_test_db(db_path)
    conn.close()
    return db_path


@pytest.fixture
def sync_dir(tmp_path):
    """Shared sync directory."""
    d = tmp_path / "sync"
    d.mkdir()
    return str(d)


def _insert_memory(db_path, name, content, mem_type="project",
                   importance=0.5, created=None, updated=None,
                   source_agent=None):
    """Helper to insert a memory."""
    conn = sqlite3.connect(db_path)
    ts = created or _now_iso()
    upd = updated or ts
    conn.execute("""
        INSERT INTO memories (name, type, content, importance, created, updated, source_agent)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (name, mem_type, content, importance, ts, upd, source_agent))
    conn.commit()
    conn.close()


def _insert_skill_execution(db_path, skill_name, success=1,
                            tokens_used=100, duration=1.0, created=None):
    conn = sqlite3.connect(db_path)
    ts = created or _now_iso()
    conn.execute("""
        INSERT INTO skill_executions (skill_name, success, tokens_used, duration_seconds, created)
        VALUES (?, ?, ?, ?, ?)
    """, (skill_name, success, tokens_used, duration, ts))
    conn.commit()
    conn.close()


def _insert_skill_version(db_path, skill_name, version, content="v1 content",
                          created=None):
    conn = sqlite3.connect(db_path)
    ts = created or _now_iso()
    conn.execute("""
        INSERT INTO skill_versions (skill_name, version, content_snapshot, created)
        VALUES (?, ?, ?, ?)
    """, (skill_name, version, content, ts))
    conn.commit()
    conn.close()


def _count_memories(db_path):
    conn = sqlite3.connect(db_path)
    c = conn.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
    conn.close()
    return c


def _get_memory(db_path, name):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    row = conn.execute("SELECT * FROM memories WHERE name=? AND active=1", (name,)).fetchone()
    conn.close()
    return dict(row) if row else None


# ---------------------------------------------------------------------------
# Tests: Export
# ---------------------------------------------------------------------------

class TestExport:
    def test_export_creates_valid_json(self, neuro_db, tmp_path):
        """Export creates a valid, parseable JSON file."""
        _insert_memory(neuro_db, "test_memory", "some content")
        _insert_skill_execution(neuro_db, "code_review", success=1)

        out = str(tmp_path / "delta.json")
        delta = export_delta(neuro_db, since_timestamp="2000-01-01T00:00:00",
                             output_path=out, agent_id="neuro")

        # File exists and is valid JSON
        assert os.path.exists(out)
        with open(out) as f:
            loaded = json.load(f)

        assert loaded["schema_version"] == 1
        assert loaded["agent_id"] == "neuro"
        assert "exported_at" in loaded
        assert "since" in loaded
        assert loaded["counts"]["total"] > 0

    def test_export_includes_new_memories(self, neuro_db, tmp_path):
        _insert_memory(neuro_db, "m1", "first memory", created="2025-01-01T00:00:00")
        _insert_memory(neuro_db, "m2", "second memory", created="2026-04-01T00:00:00")

        delta = export_delta(neuro_db, since_timestamp="2026-01-01T00:00:00",
                             agent_id="neuro")

        names = [m["name"] for m in delta["memories"]]
        assert "m2" in names
        assert "m1" not in names

    def test_export_includes_skill_executions(self, neuro_db):
        _insert_skill_execution(neuro_db, "code_review", created="2026-04-01T00:00:00")

        delta = export_delta(neuro_db, since_timestamp="2026-01-01T00:00:00",
                             agent_id="neuro")
        assert delta["counts"]["skill_executions"] == 1

    def test_export_includes_skill_versions(self, neuro_db):
        _insert_skill_version(neuro_db, "code_review", 1, created="2026-04-01T00:00:00")

        delta = export_delta(neuro_db, since_timestamp="2026-01-01T00:00:00",
                             agent_id="neuro")
        assert delta["counts"]["skill_versions"] == 1

    def test_export_empty_when_nothing_new(self, neuro_db):
        _insert_memory(neuro_db, "old", "old content", created="2020-01-01T00:00:00",
                       updated="2020-01-01T00:00:00")

        delta = export_delta(neuro_db, since_timestamp="2025-01-01T00:00:00",
                             agent_id="neuro")
        assert delta["counts"]["total"] == 0

    def test_export_updates_sync_state(self, neuro_db):
        _insert_memory(neuro_db, "m1", "content")
        export_delta(neuro_db, since_timestamp="2000-01-01T00:00:00", agent_id="neuro")

        conn = sqlite3.connect(neuro_db)
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT * FROM sync_state WHERE agent_id='neuro'").fetchone()
        conn.close()
        assert row is not None
        assert row["last_export"] is not None


# ---------------------------------------------------------------------------
# Tests: Import
# ---------------------------------------------------------------------------

class TestImport:
    def test_import_new_memories(self, neuro_db, case_db, tmp_path):
        """Import inserts memories that don't exist locally."""
        _insert_memory(case_db, "case_finding", "Found XSS on target",
                       importance=0.8)

        out = str(tmp_path / "case_delta.json")
        export_delta(case_db, since_timestamp="2000-01-01T00:00:00",
                     output_path=out, agent_id="case")

        report = import_delta(neuro_db, out, agent_id="neuro")

        assert report["memories"]["imported"] == 1
        mem = _get_memory(neuro_db, "case_finding")
        assert mem is not None
        assert mem["content"] == "Found XSS on target"
        assert mem["source_agent"] == "case"

    def test_import_skips_own_delta(self, neuro_db, tmp_path):
        """Should skip importing own delta files."""
        _insert_memory(neuro_db, "my_mem", "my content")

        out = str(tmp_path / "neuro_delta.json")
        export_delta(neuro_db, since_timestamp="2000-01-01T00:00:00",
                     output_path=out, agent_id="neuro")

        report = import_delta(neuro_db, out, agent_id="neuro")
        assert report.get("skipped") == "own_delta"

    def test_import_skips_duplicates(self, neuro_db, case_db, tmp_path):
        """Existing memory with same name+type is not duplicated."""
        _insert_memory(neuro_db, "shared_mem", "neuro version",
                       updated="2026-04-01T00:00:00", importance=0.7)
        _insert_memory(case_db, "shared_mem", "neuro version",
                       updated="2026-03-01T00:00:00", importance=0.5)

        out = str(tmp_path / "case_delta.json")
        export_delta(case_db, since_timestamp="2000-01-01T00:00:00",
                     output_path=out, agent_id="case")

        report = import_delta(neuro_db, out, agent_id="neuro")

        # Should be skipped (local is newer + same content)
        assert report["memories"]["skipped"] == 1
        assert _count_memories(neuro_db) == 1

    def test_import_newer_wins(self, neuro_db, case_db, tmp_path):
        """Remote memory with newer timestamp overwrites local."""
        _insert_memory(neuro_db, "evolving", "old version",
                       updated="2026-01-01T00:00:00")
        _insert_memory(case_db, "evolving", "new version from Case",
                       updated="2026-04-01T00:00:00")

        out = str(tmp_path / "case_delta.json")
        export_delta(case_db, since_timestamp="2000-01-01T00:00:00",
                     output_path=out, agent_id="case")

        report = import_delta(neuro_db, out, agent_id="neuro")

        assert report["memories"]["updated"] == 1
        mem = _get_memory(neuro_db, "evolving")
        assert "new version from Case" in mem["content"]

    def test_import_higher_importance_wins(self, neuro_db, case_db, tmp_path):
        """Memory with significantly higher importance wins regardless of timestamp."""
        _insert_memory(neuro_db, "critical_finding", "minor note",
                       updated="2026-04-01T00:00:00", importance=0.3)
        _insert_memory(case_db, "critical_finding", "CRITICAL: RCE found",
                       updated="2026-03-01T00:00:00", importance=0.9)

        out = str(tmp_path / "case_delta.json")
        export_delta(case_db, since_timestamp="2000-01-01T00:00:00",
                     output_path=out, agent_id="case")

        report = import_delta(neuro_db, out, agent_id="neuro")

        assert report["memories"]["updated"] == 1
        mem = _get_memory(neuro_db, "critical_finding")
        assert "CRITICAL: RCE found" in mem["content"]

    def test_import_skill_executions_appended(self, neuro_db, case_db, tmp_path):
        """Skill executions are always appended (no conflict)."""
        _insert_skill_execution(case_db, "nmap_scan", success=1,
                                created="2026-04-01T12:00:00")
        _insert_skill_execution(case_db, "nmap_scan", success=0,
                                created="2026-04-01T13:00:00")

        out = str(tmp_path / "case_delta.json")
        export_delta(case_db, since_timestamp="2000-01-01T00:00:00",
                     output_path=out, agent_id="case")

        report = import_delta(neuro_db, out, agent_id="neuro")
        assert report["skill_executions"]["imported"] == 2

    def test_import_skill_version_newer_only(self, neuro_db, case_db, tmp_path):
        """Only import skill versions that are newer than local."""
        _insert_skill_version(neuro_db, "code_review", 3)
        _insert_skill_version(case_db, "code_review", 2,
                              created="2026-04-01T00:00:00")

        out = str(tmp_path / "case_delta.json")
        export_delta(case_db, since_timestamp="2000-01-01T00:00:00",
                     output_path=out, agent_id="case")

        report = import_delta(neuro_db, out, agent_id="neuro")
        # Version 2 < local version 3, so it should be skipped
        assert report["skill_versions"]["skipped"] == 1

    def test_import_skill_version_new_skill(self, neuro_db, case_db, tmp_path):
        """Import skill version for a skill we don't have locally."""
        _insert_skill_version(case_db, "port_scanner", 1,
                              content="scan all ports", created="2026-04-01T00:00:00")

        out = str(tmp_path / "case_delta.json")
        export_delta(case_db, since_timestamp="2000-01-01T00:00:00",
                     output_path=out, agent_id="case")

        report = import_delta(neuro_db, out, agent_id="neuro")
        assert report["skill_versions"]["imported"] == 1

    def test_dry_run_no_changes(self, neuro_db, case_db, tmp_path):
        """Dry run reports what would happen without actually importing."""
        _insert_memory(case_db, "dry_test", "should not appear")

        out = str(tmp_path / "case_delta.json")
        export_delta(case_db, since_timestamp="2000-01-01T00:00:00",
                     output_path=out, agent_id="case")

        report = import_delta(neuro_db, out, dry_run=True, agent_id="neuro")

        assert report["memories"]["imported"] == 1  # reported as would-import
        assert _count_memories(neuro_db) == 0  # but nothing actually inserted


# ---------------------------------------------------------------------------
# Tests: Credential Filtering
# ---------------------------------------------------------------------------

class TestCredentialFiltering:
    def test_filters_api_key(self):
        assert _contains_credentials("my api_key = sk-abc123def456") is True

    def test_filters_bearer_token(self):
        assert _contains_credentials("Authorization: Bearer eyJhbGciOi...") is True

    def test_filters_github_pat(self):
        assert _contains_credentials("token: ghp_1234567890abcdefghijklmnopqrstuvwxyz") is True

    def test_filters_aws_key(self):
        assert _contains_credentials("AKIAIOSFODNN7EXAMPLE") is True

    def test_filters_private_key(self):
        assert _contains_credentials("-----BEGIN PRIVATE KEY-----") is True

    def test_allows_normal_content(self):
        assert _contains_credentials("This is a normal finding about SQL injection") is False

    def test_filters_password_field(self):
        assert _contains_credentials("password = hunter2") is True

    def test_blocked_memory_name(self):
        assert _is_blocked_memory("telegram_token") is True
        assert _is_blocked_memory("github_pat_backup") is True
        assert _is_blocked_memory("normal_project_note") is False

    def test_filter_memory_blocks_creds(self):
        mem = {"name": "test", "content": "api_key = sk-12345678901234567890", "tags": ""}
        assert _filter_memory(mem) is None

    def test_filter_memory_blocks_named(self):
        mem = {"name": "telegram_token", "content": "safe content", "tags": ""}
        assert _filter_memory(mem) is None

    def test_filter_memory_allows_clean(self):
        mem = {"name": "xss_finding", "content": "Found reflected XSS on /search", "tags": "vuln"}
        assert _filter_memory(mem) is not None

    def test_export_filters_credentials(self, neuro_db, tmp_path):
        """Export should omit memories containing credentials."""
        _insert_memory(neuro_db, "legit_mem", "normal content")
        _insert_memory(neuro_db, "secret_mem", "password = super_secret_123")
        _insert_memory(neuro_db, "telegram_token", "safe text but blocked name")

        delta = export_delta(neuro_db, since_timestamp="2000-01-01T00:00:00",
                             agent_id="neuro")

        names = [m["name"] for m in delta["memories"]]
        assert "legit_mem" in names
        assert "secret_mem" not in names
        assert "telegram_token" not in names
        assert delta["counts"]["memories"] == 1


# ---------------------------------------------------------------------------
# Tests: Conflict Resolution
# ---------------------------------------------------------------------------

class TestConflictResolution:
    def test_newer_timestamp_wins(self):
        local = {"name": "x", "content": "old", "updated": "2026-01-01T00:00:00",
                 "importance": 0.5}
        remote = {"name": "x", "content": "new", "updated": "2026-04-01T00:00:00",
                  "importance": 0.5}
        action, winner = resolve_conflicts(local, remote)
        assert action == "keep_remote"
        assert winner["content"] == "new"

    def test_higher_importance_wins(self):
        local = {"name": "x", "content": "low", "updated": "2026-04-01T00:00:00",
                 "importance": 0.3}
        remote = {"name": "x", "content": "high", "updated": "2026-01-01T00:00:00",
                  "importance": 0.9}
        action, winner = resolve_conflicts(local, remote)
        assert action == "keep_remote"

    def test_same_content_keeps_local(self):
        local = {"name": "x", "content": "same", "updated": "2026-01-01T00:00:00",
                 "importance": 0.5}
        remote = {"name": "x", "content": "same", "updated": "2026-04-01T00:00:00",
                  "importance": 0.5}
        action, _ = resolve_conflicts(local, remote)
        assert action == "keep_local"

    def test_same_timestamp_different_content_keeps_both(self):
        local = {"name": "x", "content": "version A", "updated": "2026-04-01T00:00:00",
                 "importance": 0.5}
        remote = {"name": "x", "content": "version B", "updated": "2026-04-01T00:00:00",
                  "importance": 0.5}
        action, winner = resolve_conflicts(local, remote)
        assert action == "keep_both"
        assert winner is None


# ---------------------------------------------------------------------------
# Tests: Round-trip
# ---------------------------------------------------------------------------

class TestRoundTrip:
    def test_full_roundtrip(self, neuro_db, case_db, tmp_path):
        """Export from Case, import to Neuro, verify data matches."""
        # Case generates data
        _insert_memory(case_db, "case_finding_1", "SQL injection on /api/users",
                       mem_type="project", importance=0.8)
        _insert_memory(case_db, "case_finding_2", "Open redirect on /login",
                       mem_type="project", importance=0.6)
        _insert_skill_execution(case_db, "nmap_scan", success=1, tokens_used=500,
                                duration=12.5, created="2026-04-01T12:00:00")
        _insert_skill_version(case_db, "nmap_scan", 1, content="nmap -sV -sC",
                              created="2026-04-01T12:00:00")

        # Export from Case
        out = str(tmp_path / "case_delta.json")
        delta = export_delta(case_db, since_timestamp="2000-01-01T00:00:00",
                             output_path=out, agent_id="case")

        assert delta["counts"]["memories"] == 2
        assert delta["counts"]["skill_executions"] == 1
        assert delta["counts"]["skill_versions"] == 1

        # Import to Neuro
        report = import_delta(neuro_db, out, agent_id="neuro")

        assert report["memories"]["imported"] == 2
        assert report["skill_executions"]["imported"] == 1
        assert report["skill_versions"]["imported"] == 1

        # Verify data in Neuro's DB
        m1 = _get_memory(neuro_db, "case_finding_1")
        assert m1 is not None
        assert m1["content"] == "SQL injection on /api/users"
        assert m1["source_agent"] == "case"
        assert m1["importance"] == 0.8

        m2 = _get_memory(neuro_db, "case_finding_2")
        assert m2 is not None
        assert m2["content"] == "Open redirect on /login"

        # Verify skill data
        conn = sqlite3.connect(neuro_db)
        conn.row_factory = sqlite3.Row
        exes = conn.execute("SELECT * FROM skill_executions").fetchall()
        assert len(exes) == 1
        assert exes[0]["skill_name"] == "nmap_scan"

        vers = conn.execute("SELECT * FROM skill_versions").fetchall()
        assert len(vers) == 1
        assert vers[0]["skill_name"] == "nmap_scan"
        assert vers[0]["version"] == 1
        conn.close()

    def test_bidirectional_sync(self, neuro_db, case_db, tmp_path):
        """Both agents export and import each other's data."""
        # Neuro has data
        _insert_memory(neuro_db, "neuro_mem", "Windows finding")
        _insert_skill_execution(neuro_db, "web_scan", success=1,
                                created="2026-04-01T10:00:00")

        # Case has data
        _insert_memory(case_db, "case_mem", "Linux finding")
        _insert_skill_execution(case_db, "port_scan", success=1,
                                created="2026-04-01T11:00:00")

        # Export both
        neuro_out = str(tmp_path / "neuro_delta.json")
        case_out = str(tmp_path / "case_delta.json")

        export_delta(neuro_db, since_timestamp="2000-01-01T00:00:00",
                     output_path=neuro_out, agent_id="neuro")
        export_delta(case_db, since_timestamp="2000-01-01T00:00:00",
                     output_path=case_out, agent_id="case")

        # Cross-import
        import_delta(neuro_db, case_out, agent_id="neuro")
        import_delta(case_db, neuro_out, agent_id="case")

        # Both should have both memories
        assert _get_memory(neuro_db, "case_mem") is not None
        assert _get_memory(case_db, "neuro_mem") is not None
        assert _count_memories(neuro_db) == 2
        assert _count_memories(case_db) == 2


# ---------------------------------------------------------------------------
# Tests: Status
# ---------------------------------------------------------------------------

class TestStatus:
    def test_status_on_fresh_db(self, neuro_db):
        status = get_status(neuro_db, agent_id="neuro")
        assert status["agent_id"] == "neuro"
        assert status["last_export"] is None
        assert status["last_import"] is None

    def test_status_after_export(self, neuro_db):
        _insert_memory(neuro_db, "m1", "content")
        export_delta(neuro_db, since_timestamp="2000-01-01T00:00:00", agent_id="neuro")

        status = get_status(neuro_db, agent_id="neuro")
        assert status["last_export"] is not None
        assert status["total_exported"] >= 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
