"""
harness.py — Universal Execution Harness for AIBrain.

Every task, workflow, skill execution, and agent action passes through this
harness. It wraps execution with:

1. Classification — what type of task is this?
2. Budget check — is there budget remaining?
3. Authority check — does this agent/workflow have permission?
4. Model routing — pick the right model (deterministic/simple/judgment/complex)
5. Execution — run the actual task with timeout
6. Evaluation — score output quality (0.0-1.0)
7. Audit trail — log everything with before/after state
8. Verification — did the result actually succeed?
9. Learning — store corrections, update skill principles
10. Retry/escalate — if quality below threshold, retry or escalate

This is the core engine. Every other feature plugs into it.

Usage:
    from aibrain.core.harness import execute, HarnessConfig

    result = execute(
        task="post_to_linkedin",
        action=lambda: post_linkedin(content),
        config=HarnessConfig(
            authority="standard",
            task_type="deterministic",
            max_cost_cents=10,
        ),
    )
    # result.success — did it complete?
    # result.quality — 0.0-1.0 quality score
    # result.cost_cents — actual cost
    # result.model_used — which model executed
    # result.audit_id — reference to audit trail entry
    # result.retries — how many attempts were needed
"""

import json
import logging
import sqlite3
import time
import traceback
import secrets
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional

log = logging.getLogger("aibrain.harness")


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

class TaskType(Enum):
    """Task classification for model routing."""
    DETERMINISTIC = "deterministic"   # No LLM needed — code only
    SIMPLE = "simple"                 # Haiku / local model
    JUDGMENT = "judgment"             # Sonnet
    COMPLEX = "complex"              # Opus


class Authority(Enum):
    """Permission level for task execution."""
    READ_ONLY = "read_only"
    STANDARD = "standard"
    ELEVATED = "elevated"
    ADMIN = "admin"


AUTHORITY_CAPABILITIES = {
    Authority.READ_ONLY: {
        "allowed": {"read_file", "search_memory", "query_db", "list_files"},
        "denied": {"write_file", "send_email", "git_push", "delete_file",
                   "spend_money", "execute_command", "post_to_platform"},
    },
    Authority.STANDARD: {
        "allowed": {"read_file", "write_file", "search_memory", "store_memory",
                    "query_db", "list_files", "format_text"},
        "denied": {"send_email", "git_push", "delete_file", "spend_money",
                   "post_to_platform"},
    },
    Authority.ELEVATED: {
        "allowed": {"read_file", "write_file", "send_email", "git_push",
                    "search_memory", "store_memory", "query_db",
                    "post_to_platform", "execute_command"},
        "requires_approval": {"delete_file", "spend_money"},
    },
    Authority.ADMIN: {
        "allowed": {"*"},
        "requires_approval": set(),
    },
}

MODEL_MAP = {
    TaskType.DETERMINISTIC: "code_only",
    TaskType.SIMPLE: "haiku",
    TaskType.JUDGMENT: "sonnet",
    TaskType.COMPLEX: "opus",
}


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@dataclass
class HarnessConfig:
    """Configuration for a harnessed execution."""
    task_type: str = "judgment"           # deterministic, simple, judgment, complex
    authority: str = "standard"           # read_only, standard, elevated, admin
    max_cost_cents: int = 1000            # budget cap for this execution
    timeout_seconds: int = 300            # max execution time
    quality_threshold: float = 0.5        # minimum quality to accept (0.0-1.0)
    max_retries: int = 1                  # retry attempts on low quality
    require_approval: bool = False        # block until human approves
    audit: bool = True                    # log to audit trail
    actor: str = "system"                 # who initiated this
    tags: list = field(default_factory=list)  # metadata tags


# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------

@dataclass
class HarnessResult:
    """Result from a harnessed execution."""
    success: bool = False
    output: Any = None
    error: Optional[str] = None
    quality: float = 0.0
    cost_cents: int = 0
    model_used: str = "unknown"
    duration_ms: int = 0
    retries: int = 0
    audit_id: str = ""
    run_id: str = ""
    task_type: str = ""
    authority_check: str = "passed"
    budget_check: str = "passed"
    evaluation_detail: str = ""


# ---------------------------------------------------------------------------
# Core Harness
# ---------------------------------------------------------------------------

def execute(
    task: str,
    action: Callable,
    config: HarnessConfig = None,
    before_state: dict = None,
) -> HarnessResult:
    """
    Execute a task through the full harness pipeline.

    This is the ONLY way tasks should be executed in AIBrain.
    Everything passes through here — no exceptions.
    """
    if config is None:
        config = HarnessConfig()

    run_id = secrets.token_urlsafe(8)
    result = HarnessResult(run_id=run_id, task_type=config.task_type)
    start_time = time.time()

    try:
        # ─── Step 1: Classification ───────────────────────────
        task_type = TaskType(config.task_type)
        result.model_used = MODEL_MAP.get(task_type, "sonnet")

        # ─── Step 2: Budget Check ─────────────────────────────
        budget_ok, budget_msg = _check_budget(config)
        if not budget_ok:
            result.budget_check = "failed"
            result.error = budget_msg
            _log_audit(run_id, config, task, result, before_state)
            return result

        # ─── Step 3: Authority Check ──────────────────────────
        auth_ok, auth_msg = _check_authority(task, config)
        if not auth_ok:
            result.authority_check = "failed"
            result.error = auth_msg
            _log_audit(run_id, config, task, result, before_state)
            return result

        # ─── Step 4: Approval Gate ────────────────────────────
        if config.require_approval:
            approved = _check_approval(task, config)
            if not approved:
                result.error = "Awaiting approval"
                result.authority_check = "pending_approval"
                _log_audit(run_id, config, task, result, before_state)
                return result

        # ─── Step 5: Execute with Timeout ─────────────────────
        attempt = 0
        while attempt <= config.max_retries:
            try:
                output = action()
                result.output = output
                result.success = True
                result.error = None
            except Exception as e:
                result.error = str(e)
                result.success = False
                log.warning("Harness execution error (attempt %d): %s",
                           attempt + 1, e)

            # ─── Step 6: Evaluate Quality ─────────────────────
            if result.success:
                quality, detail = _evaluate_quality(task, result.output, config)
                result.quality = quality
                result.evaluation_detail = detail

                if quality >= config.quality_threshold:
                    break  # Good enough — accept

                log.info("Quality %.2f below threshold %.2f (attempt %d)",
                        quality, config.quality_threshold, attempt + 1)

            attempt += 1
            result.retries = attempt

    except Exception as e:
        result.error = f"Harness error: {e}\n{traceback.format_exc()}"
        result.success = False
        log.error("Harness pipeline error: %s", e)

    # ─── Step 7: Record Timing ────────────────────────────
    result.duration_ms = int((time.time() - start_time) * 1000)

    # ─── Step 8: Audit Trail ──────────────────────────────
    if config.audit:
        result.audit_id = _log_audit(run_id, config, task, result, before_state)

    # ─── Step 9: Learning ─────────────────────────────────
    if result.success and result.quality > 0:
        _record_learning(task, result, config)

    # ─── Step 10: Budget Update ───────────────────────────
    _update_budget(config, result.cost_cents)

    return result


# ---------------------------------------------------------------------------
# Pipeline Steps
# ---------------------------------------------------------------------------

def _check_budget(config: HarnessConfig) -> tuple[bool, str]:
    """Check if budget allows this execution."""
    try:
        from aibrain_licensing import check_tier, get_license
        lic = get_license()
        # For now, always allow — budget enforcement comes from tier limits
        # on resource creation (memories, workflows), not per-execution
        return True, "ok"
    except ImportError:
        return True, "ok"


def _check_authority(task: str, config: HarnessConfig) -> tuple[bool, str]:
    """Check if the configured authority level allows this task.

    Two-layer check:
    1. Harness authority level (read_only/standard/elevated/admin)
    2. Database agent_permissions table (allow_always/require_approval/deny)
    """
    try:
        authority = Authority(config.authority)
    except ValueError:
        return True, "unknown authority level — defaulting to allow"

    caps = AUTHORITY_CAPABILITIES.get(authority, {})
    allowed = caps.get("allowed", set())
    denied = caps.get("denied", set())
    needs_approval = caps.get("requires_approval", set())

    # Extract the action type from the task name
    action = task.split(".")[0] if "." in task else task
    # Also check the second part (e.g., "workflow.heartbeat" → check "heartbeat" too)
    sub_action = task.split(".")[-1] if "." in task else task

    if "*" in allowed:
        # Admin level — still check DB permissions for explicit denials
        pass
    elif action in denied:
        return False, f"Authority '{config.authority}' denies action '{action}'"
    elif action in needs_approval:
        return False, f"Action '{action}' requires approval at authority level '{config.authority}'"

    # Layer 2: Check database permissions
    try:
        db_path = _find_db()
        if db_path:
            import sqlite3
            db = sqlite3.connect(str(db_path))
            db.row_factory = sqlite3.Row

            # Check for explicit deny or require_approval
            for check_action in [action, sub_action]:
                row = db.execute(
                    "SELECT permission FROM agent_permissions WHERE action_type=? AND (target=? OR target='*') ORDER BY target DESC LIMIT 1",
                    (check_action, config.actor)
                ).fetchone()

                if row:
                    perm = row["permission"]
                    if perm == "deny":
                        db.close()
                        return False, f"Permission denied: '{check_action}' is explicitly denied in agent_permissions"
                    elif perm == "require_approval":
                        # Log that approval is needed but don't block (soft gate for now)
                        log.info("Action '%s' requires approval (soft gate)", check_action)

            db.close()
    except Exception as e:
        log.debug("Permission DB check failed: %s", e)

    return True, "ok"


def _check_approval(task: str, config: HarnessConfig) -> bool:
    """Check if this task has been approved (placeholder for approval queue)."""
    # TODO: Integrate with approval queue (aibrain_db.py approvals table)
    # For now, log that approval is needed and return True (soft gate)
    log.info("Approval requested for task: %s (soft gate — auto-approved)", task)
    return True


def _evaluate_quality(task: str, output: Any, config: HarnessConfig) -> tuple[float, str]:
    """
    Evaluate the quality of task output.

    Returns (score 0.0-1.0, detail string).

    For deterministic tasks: binary pass/fail based on output existence.
    For LLM tasks: can use critic-generator pattern for deeper evaluation.
    """
    task_type = TaskType(config.task_type)

    if output is None:
        return 0.0, "no output produced"

    score = 0.0
    detail_parts = []

    # ─── Type-aware evaluation ────────────────────────────
    # Dict with status/success keys (structured result)
    if isinstance(output, dict):
        if output.get("success") or output.get("status") in ("ok", "healthy", "done"):
            score = 0.9
            detail_parts.append("dict: success indicator present")
        elif output.get("error") or output.get("status") == "failed":
            score = 0.2
            detail_parts.append("dict: error indicator present")
        else:
            score = 0.7
            detail_parts.append("dict: structured output returned")

    # Tuple (common for count-based results like (ok, failed))
    elif isinstance(output, tuple):
        if len(output) >= 2 and isinstance(output[0], (int, float)):
            ok_count = output[0]
            fail_count = output[1] if len(output) > 1 else 0
            if isinstance(fail_count, (int, float)) and fail_count == 0 and ok_count > 0:
                score = 1.0
                detail_parts.append(f"tuple: {ok_count} ok, {fail_count} failed")
            elif ok_count > 0:
                score = 0.7
                detail_parts.append(f"tuple: {ok_count} ok, {fail_count} failed")
            else:
                score = 0.3
                detail_parts.append(f"tuple: {ok_count} ok, {fail_count} failed")
        else:
            score = 0.6
            detail_parts.append("tuple: non-numeric tuple returned")

    # Boolean
    elif isinstance(output, bool):
        score = 1.0 if output else 0.0
        detail_parts.append(f"bool: {output}")

    # List (results collection)
    elif isinstance(output, list):
        score = 0.8 if len(output) > 0 else 0.3
        detail_parts.append(f"list: {len(output)} items")

    # String or other
    else:
        output_str = str(output)

        # Deterministic: any non-empty output is good
        if task_type == TaskType.DETERMINISTIC:
            score = 0.9 if len(output_str) > 0 else 0.0
            detail_parts.append("deterministic: output produced")
        # Simple
        elif task_type == TaskType.SIMPLE:
            score = 0.8 if len(output_str) > 5 else 0.3
            detail_parts.append("simple: text output")
        # Judgment/Complex: deeper analysis
        else:
            score = 0.5  # base score
            if len(output_str) > 50:
                score += 0.1
                detail_parts.append("reasonable length")
            elif len(output_str) < 10:
                score -= 0.2
                detail_parts.append("very short output")

        # Error/success signal check for string outputs
        error_signals = ["error", "failed", "exception", "traceback"]
        success_signals = ["success", "completed", "done", "posted", "created", "saved"]
        output_lower = str(output).lower()

        if any(sig in output_lower for sig in error_signals):
            score -= 0.2
            detail_parts.append("contains error signals")
        if any(sig in output_lower for sig in success_signals):
            score += 0.1
            detail_parts.append("contains success signals")

    return max(0.0, min(1.0, score)), "; ".join(detail_parts) or "evaluated"


def _log_audit(
    run_id: str,
    config: HarnessConfig,
    task: str,
    result: HarnessResult,
    before_state: dict = None,
) -> str:
    """Log execution to audit trail."""
    audit_id = secrets.token_urlsafe(8)

    try:
        # Try to log to aibrain.db execution_log table
        db_path = _find_db()
        if db_path:
            db = sqlite3.connect(str(db_path))
            db.execute("PRAGMA journal_mode=WAL")

            # Create table if it doesn't exist
            db.execute("""
                CREATE TABLE IF NOT EXISTS execution_log (
                    id TEXT PRIMARY KEY,
                    run_id TEXT NOT NULL,
                    actor TEXT NOT NULL,
                    action TEXT NOT NULL,
                    entity_type TEXT,
                    entity_id TEXT,
                    detail TEXT,
                    quality_score REAL,
                    model_used TEXT,
                    cost_cents INTEGER DEFAULT 0,
                    duration_ms INTEGER DEFAULT 0,
                    before_state TEXT,
                    after_state TEXT,
                    success INTEGER DEFAULT 0,
                    error TEXT,
                    task_type TEXT,
                    authority TEXT,
                    retries INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            db.execute("""
                INSERT INTO execution_log
                (id, run_id, actor, action, entity_type, detail, quality_score,
                 model_used, cost_cents, duration_ms, before_state, after_state,
                 success, error, task_type, authority, retries)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, [
                audit_id, run_id, config.actor, task,
                "task",
                json.dumps({
                    "tags": config.tags,
                    "evaluation": result.evaluation_detail,
                    "budget_check": result.budget_check,
                    "authority_check": result.authority_check,
                }),
                result.quality, result.model_used, result.cost_cents,
                result.duration_ms,
                json.dumps(before_state) if before_state else None,
                json.dumps({"output_preview": str(result.output)[:500]}) if result.output else None,
                1 if result.success else 0,
                result.error,
                config.task_type, config.authority, result.retries,
            ])
            db.commit()
            db.close()

    except Exception as e:
        log.warning("Failed to write audit log: %s", e)

    return audit_id


def _record_learning(task: str, result: HarnessResult, config: HarnessConfig):
    """Record execution outcome for skill learning and evolution."""
    try:
        db_path = _find_db()
        if not db_path:
            return

        db = sqlite3.connect(str(db_path))
        db.execute("PRAGMA journal_mode=WAL")

        # Record in evolution_outcomes for pattern detection
        db.execute("""
            CREATE TABLE IF NOT EXISTS evolution_outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT, source_id TEXT, action TEXT,
                result TEXT, details TEXT, failure_reason TEXT,
                duration_seconds REAL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        db.execute("""
            INSERT INTO evolution_outcomes (source, source_id, action, result, details, duration_seconds)
            VALUES (?, ?, ?, ?, ?, ?)
        """, [
            "harness", result.run_id, task,
            "success" if result.success else "failure",
            json.dumps({
                "quality": result.quality,
                "model": result.model_used,
                "cost_cents": result.cost_cents,
                "task_type": config.task_type,
                "retries": result.retries,
            }),
            result.duration_ms / 1000.0,
        ])
        db.commit()
        db.close()

    except Exception as e:
        log.debug("Learning record failed: %s", e)


def _update_budget(config: HarnessConfig, cost_cents: int):
    """Update budget tracking after execution."""
    if cost_cents <= 0:
        return
    try:
        db_path = _find_db()
        if not db_path:
            return

        db = sqlite3.connect(str(db_path))
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("""
            INSERT INTO costs (timestamp, model, category, tokens_in, tokens_out,
                             cost_usd, latency_ms, workflow_id, success, notes)
            VALUES (datetime('now'), ?, ?, 0, 0, ?, 0, ?, 1, ?)
        """, [
            config.task_type, "harness",
            cost_cents / 100.0,
            config.actor,
            f"task={config.tags[0] if config.tags else 'unknown'}",
        ])
        db.commit()
        db.close()
    except Exception as e:
        log.debug("Budget update failed: %s", e)


def _find_db() -> Optional[Path]:
    """Find the aibrain database."""
    import os
    root = Path(os.environ.get("AIBRAIN_ROOT",
                os.environ.get("AIBRAIN_DB", "").replace("aibrain.db", "") or
                Path.home() / "aibrain"))
    db_path = root / "aibrain.db"
    if db_path.exists():
        return db_path

    # Try project directory
    for candidate in [Path("aibrain.db"), Path(__file__).parent.parent.parent / "aibrain.db"]:
        if candidate.exists():
            return candidate

    return None


# ---------------------------------------------------------------------------
# Convenience Wrappers
# ---------------------------------------------------------------------------

def execute_deterministic(task: str, action: Callable, actor: str = "system",
                          tags: list = None) -> HarnessResult:
    """Execute a deterministic task (no LLM, code only)."""
    return execute(task, action, HarnessConfig(
        task_type="deterministic",
        authority="standard",
        max_cost_cents=0,
        timeout_seconds=60,
        quality_threshold=0.1,
        max_retries=0,
        actor=actor,
        tags=tags or [task],
    ))


def execute_simple(task: str, action: Callable, actor: str = "system",
                   tags: list = None) -> HarnessResult:
    """Execute a simple task (Haiku/local model)."""
    return execute(task, action, HarnessConfig(
        task_type="simple",
        authority="standard",
        max_cost_cents=10,
        timeout_seconds=120,
        quality_threshold=0.5,
        max_retries=1,
        actor=actor,
        tags=tags or [task],
    ))


def execute_judgment(task: str, action: Callable, actor: str = "system",
                     tags: list = None) -> HarnessResult:
    """Execute a judgment task (Sonnet)."""
    return execute(task, action, HarnessConfig(
        task_type="judgment",
        authority="elevated",
        max_cost_cents=100,
        timeout_seconds=300,
        quality_threshold=0.6,
        max_retries=1,
        actor=actor,
        tags=tags or [task],
    ))


def execute_complex(task: str, action: Callable, actor: str = "system",
                    tags: list = None) -> HarnessResult:
    """Execute a complex task (Opus)."""
    return execute(task, action, HarnessConfig(
        task_type="complex",
        authority="admin",
        max_cost_cents=1000,
        timeout_seconds=600,
        quality_threshold=0.7,
        max_retries=2,
        actor=actor,
        tags=tags or [task],
    ))
