"""
workflow_runner.py — Run any workflow through the execution harness.

Wraps existing workflow functions with eval, audit, authority, and model routing.
Drop-in replacement for direct workflow execution.

Usage:
    from aibrain.core.workflow_runner import run_workflow

    result = run_workflow("heartbeat", dry_run=True)
    result = run_workflow("db_backup")
    result = run_workflow("email_auto_reply", authority="elevated")

Or from CLI:
    python -m aibrain.core.workflow_runner heartbeat --dry-run
    python -m aibrain.core.workflow_runner db_backup
"""

import importlib
import logging
import sys
from pathlib import Path
from typing import Optional

from aibrain.core.harness import (
    execute, HarnessConfig, HarnessResult,
    execute_deterministic, execute_simple
)

log = logging.getLogger("aibrain.workflow_runner")

# Workflow directory
WORKFLOW_DIR = Path(__file__).parent.parent.parent / "workflows"

# Workflow metadata — task type, authority, budget
# This is the per-workflow capability scoping Decker asked for
WORKFLOW_REGISTRY = {
    # Deterministic: no LLM needed, just code execution
    "heartbeat": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "db_backup": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "stack_snapshot": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "service_monitor": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "smart_file_organizer": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},

    # Simple: light LLM use for formatting/parsing
    "telegram_check": {"task_type": "simple", "authority": "standard", "max_cost": 5},
    "morning_briefing": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "download_tracker": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},

    # Judgment: needs real LLM reasoning
    "cross_domain_questions": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "contradiction_detector": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "evolution_auto_loop": {"task_type": "judgment", "authority": "elevated", "max_cost": 200},
    "evolution_experiment": {"task_type": "complex", "authority": "elevated", "max_cost": 500},

    # Elevated: can send emails, push to git, post to platforms
    "email_auto_reply": {"task_type": "judgment", "authority": "elevated", "max_cost": 100},
    "email_to_task": {"task_type": "simple", "authority": "elevated", "max_cost": 10},
    "social_poster": {"task_type": "deterministic", "authority": "elevated", "max_cost": 0},
    "send_outreach": {"task_type": "deterministic", "authority": "elevated", "max_cost": 0},
    "instagram_poster": {"task_type": "deterministic", "authority": "elevated", "max_cost": 0},

    # Complex: architecture, security, novel reasoning
    "code_review_runner": {"task_type": "complex", "authority": "elevated", "max_cost": 300},

    # Knowledge: memory and brain operations
    "knowledge_graph_builder": {"task_type": "judgment", "authority": "standard", "max_cost": 100},
    "memory_lifecycle": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "memory_consolidation": {"task_type": "judgment", "authority": "standard", "max_cost": 100},
    "memory_md_sync": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "learning_extractor": {"task_type": "judgment", "authority": "standard", "max_cost": 100},
    "auto_experiment": {"task_type": "complex", "authority": "elevated", "max_cost": 500},

    # Research & monitoring: read-heavy, low authority
    "arxiv_tracker": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "daily_research": {"task_type": "judgment", "authority": "read_only", "max_cost": 50},
    "rss_digest": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "newsletter_digest": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "github_digest": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "security_advisories": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "price_watcher": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "weather_briefing": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "uptime_monitor": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "seo_monitor": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "social_listener": {"task_type": "simple", "authority": "read_only", "max_cost": 10},

    # Productivity: standard authority
    "daily_planner": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "calendar_manager": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "habit_tracker": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "expense_tracker": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "meeting_notes": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "bookmark_organizer": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "document_parser": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "contact_enricher": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "file_declutter": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "weekly_report": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "report_generator": {"task_type": "judgment", "authority": "standard", "max_cost": 50},

    # Content: standard to elevated
    "content_calendar": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "seo_workflow_template": {"task_type": "judgment", "authority": "standard", "max_cost": 50},

    # Email & comms: elevated (can send)
    "email_triage": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "morning_check_email_summarize": {"task_type": "simple", "authority": "standard", "max_cost": 10},

    # Job search: elevated (can apply/respond)
    "job_search_apply": {"task_type": "judgment", "authority": "elevated", "max_cost": 100},
    "job_response_checker": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "job_tracker_db": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "interview_prep": {"task_type": "judgment", "authority": "standard", "max_cost": 50},

    # Code & dev: elevated (can write files, run commands)
    "dependency_auditor": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "git_monitor": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "friday_check_github_new": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "cli_anything_bridge": {"task_type": "judgment", "authority": "elevated", "max_cost": 100},

    # Risk & analysis: elevated
    "risk_analyst": {"task_type": "complex", "authority": "elevated", "max_cost": 200},
    "claude_interview": {"task_type": "complex", "authority": "standard", "max_cost": 300},
}


def run_workflow(
    name: str,
    dry_run: bool = False,
    actor: str = "system",
    authority: Optional[str] = None,
    **kwargs
) -> HarnessResult:
    """
    Run a workflow through the execution harness.

    The harness handles: classification, budget, authority, execution,
    evaluation, audit trail, learning, and retry.
    """
    # Look up workflow metadata
    meta = WORKFLOW_REGISTRY.get(name, {
        "task_type": "judgment",  # default to judgment (safe)
        "authority": "standard",
        "max_cost": 100,
    })

    # Override authority if explicitly provided
    if authority:
        meta["authority"] = authority

    # Find the workflow module
    workflow_path = WORKFLOW_DIR / f"{name}.py"
    if not workflow_path.exists():
        return HarnessResult(
            success=False,
            error=f"Workflow '{name}' not found at {workflow_path}",
        )

    # Import and find the run function
    def _execute_workflow():
        """Load and run the workflow."""
        # Add workflow dir to path if needed
        wf_dir = str(WORKFLOW_DIR)
        if wf_dir not in sys.path:
            sys.path.insert(0, wf_dir)

        # Also add parent for imports
        parent_dir = str(WORKFLOW_DIR.parent)
        if parent_dir not in sys.path:
            sys.path.insert(0, parent_dir)

        # Clear sys.argv to prevent workflow's argparse from firing on import
        original_argv = sys.argv[:]
        sys.argv = [name]
        try:
            # Force reimport if already cached
            if name in sys.modules:
                del sys.modules[name]
            mod = importlib.import_module(name)
        except SystemExit:
            # Some modules call argparse at import level — catch the exit
            raise RuntimeError(f"Workflow '{name}' has module-level argparse that conflicts. Use direct import.")
        except ImportError as e:
            raise RuntimeError(f"Cannot import workflow '{name}': {e}")
        finally:
            sys.argv = original_argv

        # Find the run function
        run_fn = getattr(mod, "run", None)
        if run_fn is None:
            # Try common alternatives
            for fn_name in [f"run_{name}", "main", "run_pipeline", "run_scan",
                           "run_backup", "run_auto_loop", "run_full_cycle"]:
                run_fn = getattr(mod, fn_name, None)
                if run_fn:
                    break

        if run_fn is None:
            raise RuntimeError(f"Workflow '{name}' has no run() function")

        # Execute — handle different function signatures gracefully
        import inspect
        sig = inspect.signature(run_fn)
        params = sig.parameters

        call_kwargs = dict(kwargs)
        if dry_run and "dry_run" in params:
            call_kwargs["dry_run"] = True

        # Only pass kwargs the function actually accepts
        if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()):
            return run_fn(**call_kwargs)  # accepts **kwargs
        else:
            filtered = {k: v for k, v in call_kwargs.items() if k in params}
            return run_fn(**filtered)

    # Configure harness
    config = HarnessConfig(
        task_type=meta["task_type"],
        authority=meta["authority"],
        max_cost_cents=meta["max_cost"],
        timeout_seconds=300,
        quality_threshold=0.3,  # workflows have lower threshold — they're established
        max_retries=0,  # don't retry workflows automatically
        actor=actor,
        tags=[name, "workflow"],
    )

    log.info("Running workflow '%s' through harness [type=%s, auth=%s]",
             name, meta["task_type"], meta["authority"])

    result = execute(
        task=f"workflow.{name}",
        action=_execute_workflow,
        config=config,
    )

    if result.success:
        log.info("Workflow '%s' completed: quality=%.2f, duration=%dms",
                name, result.quality, result.duration_ms)
    else:
        log.warning("Workflow '%s' failed: %s", name, result.error)

    return result


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Run workflow through harness")
    parser.add_argument("workflow", help="Workflow name (e.g. heartbeat, db_backup)")
    parser.add_argument("--dry-run", action="store_true", help="Preview mode")
    parser.add_argument("--actor", default="cli", help="Who initiated this")
    parser.add_argument("--authority", help="Override authority level")

    args = parser.parse_args()

    # Clear sys.argv BEFORE running workflow (prevents imported modules' argparse from firing)
    sys.argv = [sys.argv[0]]

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    result = run_workflow(
        args.workflow,
        dry_run=args.dry_run,
        actor=args.actor,
        authority=args.authority,
    )

    print(f"\n{'='*50}")
    print(f"Workflow: {args.workflow}")
    print(f"Success:  {result.success}")
    print(f"Quality:  {result.quality:.2f}")
    print(f"Model:    {result.model_used}")
    print(f"Duration: {result.duration_ms}ms")
    print(f"Audit ID: {result.audit_id}")
    if result.error:
        print(f"Error:    {result.error}")
    print(f"{'='*50}")
