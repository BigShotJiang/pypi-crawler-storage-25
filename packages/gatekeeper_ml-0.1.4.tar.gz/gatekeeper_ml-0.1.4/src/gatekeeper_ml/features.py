"""Feature engineering utilities for the gatekeeper classifier."""

from __future__ import annotations

import math
import re
from collections import Counter
from typing import Sequence

import numpy as np
from scipy import sparse
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import FeatureUnion

from . import config


_SQLI_KEYWORD_RE = re.compile(r"\b(select|union|or|and|from|where)\b", re.IGNORECASE)
_SQLI_OPERATOR_RE = re.compile(r"[=<>]")


def shannon_entropy(text: str) -> float:
    """Calculates Shannon entropy for a string.

    Args:
        text: Input text.

    Returns:
        Shannon entropy score.
    """
    if not text:
        return 0.0

    counts = Counter(text)
    length = len(text)
    entropy = 0.0
    for count in counts.values():
        probability = count / length
        entropy -= probability * math.log2(probability)
    return entropy


class TextStatsExtractor(BaseEstimator, TransformerMixin):
    """Extracts lightweight handcrafted statistical text features."""

    _SUSPICIOUS_SPECIAL_CHARS = frozenset("%<>/\\\"|&$(){}[]`")
    _SAFE_PROTOCOL_CHARS = frozenset(" -_.:,;")
    _FEATURE_NAMES = (
        "length",
        "entropy",
        "non_alnum_ratio",
        "digit_ratio",
        "space_ratio",
        "special_char_ratio",
        "percent_encoded_count",
        "slash_ratio",
        "sqli_indicator_count",
    )

    def fit(self, X: Sequence[str], y: Sequence[int] | None = None) -> "TextStatsExtractor":
        """No-op fit for sklearn compatibility."""
        return self

    def transform(self, X: Sequence[str]) -> sparse.csr_matrix:
        """Transforms strings into numeric feature vectors.

        Args:
            X: Input strings.

        Returns:
            Sparse matrix of engineered statistics.
        """
        rows = [self._extract_features(text or "") for text in X]
        array = np.asarray(rows, dtype=np.float32)
        return sparse.csr_matrix(array)

    def _extract_features(self, text: str) -> list[float]:
        """Computes numeric features for a single string."""
        length = len(text)
        if length == 0:
            return [0.0] * len(self._FEATURE_NAMES)

        sqli_indicator_count = self._count_sqli_indicators(text)
        num_non_alnum = sum(
            1
            for char in text
            if not char.isalnum()
            and char not in self._SAFE_PROTOCOL_CHARS
            and (char not in "'=" or sqli_indicator_count > 0)
        )
        num_digits = sum(1 for char in text if char.isdigit())
        num_spaces = sum(1 for char in text if char.isspace())
        num_special = sum(1 for char in text if char in self._SUSPICIOUS_SPECIAL_CHARS)
        if sqli_indicator_count > 0:
            num_special += text.count("'") + text.count("=")
        encoded_byte_count = text.count("%")
        slash_count = text.count("/") + text.count("\\")

        return [
            float(length),
            float(shannon_entropy(text)),
            num_non_alnum / length,
            num_digits / length,
            num_spaces / length,
            num_special / length,
            float(encoded_byte_count),
            slash_count / length,
            float(sqli_indicator_count),
        ]

    def _count_sqli_indicators(self, text: str) -> int:
        """Counts quote-driven SQLi indicators in the string."""
        if "'" not in text:
            return 0

        keyword_count = len(_SQLI_KEYWORD_RE.findall(text))
        operator_count = len(_SQLI_OPERATOR_RE.findall(text))
        quote_count = text.count("'")

        if keyword_count == 0 and operator_count == 0:
            return 0

        return quote_count + keyword_count + operator_count

    def get_feature_names_out(self, input_features: Sequence[str] | None = None) -> np.ndarray:
        """Returns output feature names for sklearn compatibility."""
        return np.asarray(self._FEATURE_NAMES, dtype=object)


def build_tfidf_vectorizer() -> TfidfVectorizer:
    """Builds the character-level TF-IDF vectorizer."""
    return TfidfVectorizer(
        analyzer="char",
        ngram_range=config.TFIDF_NGRAM_RANGE,
        min_df=config.TFIDF_MIN_DF,
        max_features=config.TFIDF_MAX_FEATURES,
        sublinear_tf=config.TFIDF_SUBLINEAR_TF,
        lowercase=False,
    )


def build_feature_union() -> FeatureUnion:
    """Builds the combined feature union used for training and inference."""
    return FeatureUnion(
        transformer_list=[
            ("char_tfidf", build_tfidf_vectorizer()),
            ("text_stats", TextStatsExtractor()),
        ]
    )
