"""Training pipeline for the gatekeeper suspicious payload classifier."""

from __future__ import annotations

import argparse
import shutil
import json
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any

import joblib
import matplotlib
import numpy as np
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    precision_recall_fscore_support,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from . import config
from .data_loader import load_dataset
from .features import build_feature_union

matplotlib.use("Agg")
import matplotlib.pyplot as plt

sns.set_theme(style="whitegrid")

FEATURE_IMPORTANCE_PLOT_PATH = config.MODELS_DIR / "feature_importance.png"
CONFUSION_MATRIX_PLOT_PATH = config.MODELS_DIR / "confusion_matrix.png"
ROC_CURVE_PLOT_PATH = config.MODELS_DIR / "roc_curve.png"
EVALUATION_REPORT_PATH = config.MODELS_DIR / "evaluation_report.txt"


def build_training_pipeline() -> Pipeline:
    """Creates the sklearn pipeline for feature extraction and classification."""
    classifier = RandomForestClassifier(
        n_estimators=config.RF_N_ESTIMATORS,
        max_depth=config.RF_MAX_DEPTH,
        min_samples_split=config.RF_MIN_SAMPLES_SPLIT,
        min_samples_leaf=config.RF_MIN_SAMPLES_LEAF,
        class_weight=config.RF_CLASS_WEIGHT,
        n_jobs=-1,
        random_state=config.RANDOM_STATE,
    )

    return Pipeline(
        steps=[
            ("features", build_feature_union()),
            ("classifier", classifier),
        ]
    )


def _get_feature_names(pipeline: Pipeline) -> list[str]:
    """Returns feature names from the fitted feature union."""
    features_step = pipeline.named_steps["features"]
    feature_names = features_step.get_feature_names_out()
    return [str(name) for name in feature_names]


def _normalize_feature_name(feature_name: str) -> str:
    """Converts sklearn composite feature names into readable labels."""
    if "__" in feature_name:
        return feature_name.split("__", maxsplit=1)[1]
    return feature_name


def _build_feature_importance_records(pipeline: Pipeline) -> list[dict[str, Any]]:
    """Builds a sortable feature importance table from the fitted pipeline."""
    classifier = pipeline.named_steps["classifier"]
    feature_names = _get_feature_names(pipeline)
    importances = classifier.feature_importances_

    records: list[dict[str, Any]] = []
    for feature_name, importance in zip(feature_names, importances):
        normalized_name = _normalize_feature_name(feature_name)
        records.append(
            {
                "feature_name": normalized_name,
                "importance": float(importance),
                "feature_group": (
                    "custom_stats"
                    if feature_name.startswith("text_stats__")
                    else "tfidf_char"
                ),
            }
        )

    records.sort(key=lambda item: item["importance"], reverse=True)
    return records


def _plot_feature_importance(feature_records: list[dict[str, Any]], output_path: Path) -> None:
    """Saves a top-20 feature importance bar chart."""
    top_records = feature_records[:20]
    labels = [record["feature_name"] for record in reversed(top_records)]
    values = [record["importance"] for record in reversed(top_records)]
    groups = [record["feature_group"] for record in reversed(top_records)]
    palette = {"custom_stats": "#c0392b", "tfidf_char": "#1f77b4"}
    colors = [palette[group] for group in groups]

    figure, axis = plt.subplots(figsize=(12, 8))
    axis.barh(labels, values, color=colors)
    axis.set_title("Top 20 Feature Importances")
    axis.set_xlabel("Importance")
    axis.set_ylabel("Feature")

    custom_patch = plt.Line2D([0], [0], color=palette["custom_stats"], lw=6)
    tfidf_patch = plt.Line2D([0], [0], color=palette["tfidf_char"], lw=6)
    axis.legend(
        [custom_patch, tfidf_patch],
        ["Custom Stats", "TF-IDF"],
        loc="lower right",
    )
    figure.tight_layout()
    figure.savefig(output_path, dpi=200, bbox_inches="tight")
    plt.close(figure)


def _plot_confusion_matrix(y_true: list[int], y_pred: np.ndarray, output_path: Path) -> None:
    """Saves a normalized confusion matrix heatmap."""
    matrix = confusion_matrix(y_true, y_pred, normalize="true")
    figure, axis = plt.subplots(figsize=(6, 5))
    sns.heatmap(
        matrix,
        annot=True,
        fmt=".2f",
        cmap="Blues",
        xticklabels=["Normal (0)", "Suspicious (1)"],
        yticklabels=["Normal (0)", "Suspicious (1)"],
        ax=axis,
    )
    axis.set_title("Normalized Confusion Matrix")
    axis.set_xlabel("Predicted Label")
    axis.set_ylabel("True Label")
    figure.tight_layout()
    figure.savefig(output_path, dpi=200, bbox_inches="tight")
    plt.close(figure)


def _plot_roc_curve(y_true: list[int], y_score: np.ndarray, auc_value: float, output_path: Path) -> None:
    """Saves the ROC curve figure."""
    false_positive_rate, true_positive_rate, _ = roc_curve(y_true, y_score)
    figure, axis = plt.subplots(figsize=(7, 6))
    axis.plot(false_positive_rate, true_positive_rate, label=f"ROC AUC = {auc_value:.4f}", lw=2)
    axis.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Random Guess")
    axis.set_title("ROC Curve")
    axis.set_xlabel("False Positive Rate")
    axis.set_ylabel("True Positive Rate")
    axis.legend(loc="lower right")
    figure.tight_layout()
    figure.savefig(output_path, dpi=200, bbox_inches="tight")
    plt.close(figure)


def _build_benchmark_batch(samples: list[str], target_size: int = 1000) -> list[str]:
    """Builds a fixed-size batch for lightweight inference benchmarking."""
    if not samples:
        return [""] * target_size

    batch: list[str] = []
    while len(batch) < target_size:
        remaining = target_size - len(batch)
        batch.extend(samples[:remaining])
    return batch


def _measure_average_inference_time(pipeline: Pipeline, samples: list[str]) -> float:
    """Measures average inference latency in milliseconds per sample."""
    benchmark_batch = _build_benchmark_batch(samples=samples, target_size=1000)
    started_at = perf_counter()
    pipeline.predict(benchmark_batch)
    elapsed_ms = (perf_counter() - started_at) * 1000.0
    return elapsed_ms / len(benchmark_batch)


def _write_evaluation_report(
    metrics: dict[str, Any],
    classification_report_text: str,
    output_path: Path,
) -> None:
    """Writes a human-readable evaluation report to disk."""
    report = (
        "Gatekeeper ML Evaluation Report\n"
        "===============================\n\n"
        f"Precision: {metrics['precision']:.4f}\n"
        f"Recall: {metrics['recall']:.4f}\n"
        f"F1-Score: {metrics['f1_score']:.4f}\n"
        f"ROC AUC: {metrics['roc_auc']:.4f}\n"
        f"Average Inference Time (1000-sample batch): "
        f"{metrics['average_inference_time_ms']:.6f} ms/sample\n"
        f"Threshold: {metrics['threshold']:.2f}\n\n"
        "Per-Class Classification Report\n"
        "-------------------------------\n"
        f"{classification_report_text}\n"
    )
    output_path.write_text(report, encoding="utf-8")


def _build_explainability_summary(
    feature_records: list[dict[str, Any]],
    top_k: int = 20,
) -> str:
    """Builds a short explainability summary for console output."""
    top_records = feature_records[:top_k]
    custom_records = [
        record for record in top_records if record["feature_group"] == "custom_stats"
    ]
    tfidf_count = sum(1 for record in top_records if record["feature_group"] == "tfidf_char")

    if custom_records:
        custom_summary = ", ".join(
            f"{record['feature_name']} ({record['importance']:.4f})"
            for record in custom_records
        )
    else:
        custom_summary = "No custom features appeared in the top-ranked features."

    return (
        f"Top {top_k} features contain {len(custom_records)} custom stats feature(s) "
        f"and {tfidf_count} TF-IDF feature(s).\n"
        f"Custom feature summary: {custom_summary}"
    )


def _evaluate_model(pipeline: Pipeline, X_test: list[str], y_test: list[int]) -> dict[str, Any]:
    """Evaluates the pipeline with a recall-oriented decision threshold."""
    probabilities = pipeline.predict_proba(X_test)[:, 1]
    predictions = (probabilities >= config.INFERENCE_SUSPICIOUS_THRESHOLD).astype(int)

    precision, recall, f1_score, _ = precision_recall_fscore_support(
        y_test,
        predictions,
        average="binary",
        zero_division=0,
    )
    report = classification_report(y_test, predictions, zero_division=0, output_dict=True)
    report_text = classification_report(
        y_test,
        predictions,
        target_names=["Normal (0)", "Suspicious (1)"],
        zero_division=0,
    )
    auc_value = roc_auc_score(y_test, probabilities)
    average_inference_time_ms = _measure_average_inference_time(pipeline, samples=X_test)
    feature_records = _build_feature_importance_records(pipeline)

    _plot_feature_importance(feature_records=feature_records, output_path=FEATURE_IMPORTANCE_PLOT_PATH)
    _plot_confusion_matrix(y_true=y_test, y_pred=predictions, output_path=CONFUSION_MATRIX_PLOT_PATH)
    _plot_roc_curve(
        y_true=y_test,
        y_score=probabilities,
        auc_value=auc_value,
        output_path=ROC_CURVE_PLOT_PATH,
    )

    metrics = {
        "precision": float(precision),
        "recall": float(recall),
        "f1_score": float(f1_score),
        "roc_auc": float(auc_value),
        "average_inference_time_ms": float(average_inference_time_ms),
        "threshold": config.INFERENCE_SUSPICIOUS_THRESHOLD,
        "classification_report": report,
        "top_features": feature_records[:20],
        "explainability_summary": _build_explainability_summary(feature_records),
    }
    _write_evaluation_report(
        metrics=metrics,
        classification_report_text=report_text,
        output_path=EVALUATION_REPORT_PATH,
    )
    return metrics


def train_and_save_model(force_refresh: bool = False) -> dict[str, Any]:
    """Trains the gatekeeper model and persists the final artifact.

    Args:
        force_refresh: Whether to rebuild the dataset from remote sources.

    Returns:
        Dictionary containing metrics and artifact metadata.
    """
    config.MODELS_DIR.mkdir(parents=True, exist_ok=True)

    dataframe = load_dataset(force_refresh=force_refresh)
    X = dataframe["text"].astype(str).tolist()
    y = dataframe["label"].astype(int).tolist()

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=config.TEST_SIZE,
        random_state=config.RANDOM_STATE,
        stratify=y,
    )

    pipeline = build_training_pipeline()
    pipeline.fit(X_train, y_train)

    metrics = _evaluate_model(pipeline, X_test=X_test, y_test=y_test)
    artifact = {
        "model": pipeline,
        "threshold": config.INFERENCE_SUSPICIOUS_THRESHOLD,
        "metrics": metrics,
        "trained_at_utc": datetime.now(timezone.utc).isoformat(),
    }

    joblib.dump(artifact, config.MODEL_PATH)
    config.PACKAGE_MODELS_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(config.MODEL_PATH, config.PACKAGED_MODEL_PATH)
    config.METRICS_PATH.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    return artifact


def format_metrics(metrics: dict[str, Any]) -> str:
    """Formats the core evaluation metrics for console output.

    Args:
        metrics: Metrics dictionary returned by training evaluation.

    Returns:
        Human-readable metrics string.
    """
    return (
        f"Precision: {metrics['precision']:.4f}\n"
        f"Recall:    {metrics['recall']:.4f}\n"
        f"F1-Score:  {metrics['f1_score']:.4f}\n"
        f"Threshold: {metrics['threshold']:.2f}"
    )


def main() -> None:
    """Command-line entrypoint for model training."""
    parser = argparse.ArgumentParser(description="Train the gatekeeper payload classifier.")
    parser.add_argument(
        "--force-refresh",
        action="store_true",
        help="Rebuild the processed dataset before training.",
    )
    args = parser.parse_args()

    artifact = train_and_save_model(force_refresh=args.force_refresh)
    metrics = artifact["metrics"]

    print("Training complete")
    print(format_metrics(metrics))
    print(metrics["explainability_summary"])


if __name__ == "__main__":
    main()
