"""Low-latency inference wrapper for suspicious payload detection."""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

import joblib

from . import config


_INTEGER_RE = re.compile(r"^\d+$")
_UUID_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-"
    r"[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$"
)
_CRITICAL_ATTACK_RE = re.compile(
    r"(xterm|xp_cmdshell|/etc/passwd|boot\.ini|/bin/bash|nc\s+-e|tftp\s+-i|"
    r"wget\s+http|curl\s+http|bulk\s+insert|openrowset)",
    re.IGNORECASE,
)
_SAFE_TOKEN_RE = re.compile(r"^[A-Za-z0-9_.-]{1,48}$")
_SAFE_URI_RE = re.compile(r"^/[A-Za-z0-9/_\-.]{1,128}$")
_SAFE_HTTP_URL_RE = re.compile(r"^https?://[^\s'\"<>\r\n\t]+$", re.IGNORECASE)
_SAFE_HEADER_VALUE_RE = re.compile(r"^[A-Za-z0-9 ,;=:/+_.-]{1,256}$")
_DIGEST_AUTH_RE = re.compile(
    r"^Digest\s+(nonce|cnonce|uri|qop|opaque|username|nc|response).*",
    re.IGNORECASE,
)
_EXACT_OS_SIGNATURE_RE = re.compile(
    r"^(Windows (95|98|NT)|Mac OS X|Linux|Solaris|Win9x|WinNT|FreeBSD|MIPS|StrongARM|PowerPC|x86)$",
    re.IGNORECASE,
)
_CLIENT_VERSION_LIST_RE = re.compile(
    r"^[a-zA-Z0-9\-]+/\d+\.\d+(?:,\s*[a-zA-Z0-9\-]+/\d+\.\d+)*$"
)
_CHARSET_LIST_RE = re.compile(
    r"^(iso-8859-\d|windows-\d+|utf-\d|shift_jis|us-ascii|cp-\d+).*",
    re.IGNORECASE,
)
_HTTP_DATE_RE = re.compile(
    r"^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun),\s+\d{1,2}\s+"
    r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+"
    r"(?:\d{2}|\d{4})\s+\d{2}:\d{2}:\d{2}\s+"
    r"(?:GMT|UTC|CET|CEST|EET|EEST|PST|PDT|MST|MDT|CST|CDT|EST|EDT)$"
)
_QUOTED_ETAG_RE = re.compile(r'^"[^"\r\n]+"$')
_WEAK_ETAG_RE = re.compile(r'^W/"[^"\r\n]+"$')
_SAFE_MEDIA_RANGE_RE = re.compile(
    r"^[A-Za-z*]+/[A-Za-z0-9.+*-]+(?:\s*;\s*[A-Za-z-]+=[A-Za-z0-9._-]+)?"
    r"(?:\s*,\s*[A-Za-z*]+/[A-Za-z0-9.+*-]+(?:\s*;\s*[A-Za-z-]+=[A-Za-z0-9._-]+)?)*$"
)
_SAFE_ACCEPT_LANGUAGE_RE = re.compile(
    r"^[A-Za-z]{1,8}(?:-[A-Za-z]{1,8})?(?:;\s*q=\d(?:\.\d+)?)?"
    r"(?:,\s*[A-Za-z]{1,8}(?:-[A-Za-z]{1,8})?(?:;\s*q=\d(?:\.\d+)?)?)*$"
)
_SAFE_ENCODING_LIST_RE = re.compile(r"^[A-Za-z0-9*-]+(?:,\s*[A-Za-z0-9*-]+)*$")
_SAFE_CACHE_CONTROL_RE = re.compile(r"^[A-Za-z-]+(?:=\d+)?(?:,\s*[A-Za-z-]+(?:=\d+)?)*$")
_SAFE_COOKIE_RE = re.compile(
    r"^[A-Za-z0-9_.-]+=[A-Za-z0-9._~+/-]+(?:;\s*[A-Za-z0-9_.-]+=[A-Za-z0-9._~+/-]+)*$"
)
_SAFE_ETAG_RE = re.compile(r'^W?/"[A-Za-z0-9._-]+"$')
_QUALITY_VALUE_RE = re.compile(
    r"^(?:\*|[A-Za-z0-9!#$&^_.+-]+)(?:/[A-Za-z0-9!#$&^_.+-]+)?\s*;\s*q=0?\.\d+$",
    re.IGNORECASE,
)
_CHARSET_TOKEN_RE = re.compile(r"^[A-Za-z0-9_-]+-\d{3,5}$", re.IGNORECASE)
_BOUNDARY_SEPARATOR_RE = re.compile(r"^(?=[~=\-]{8,}$)[~=\-]+$")
_EMAIL_RE = re.compile(
    r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@"
    r"[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+$"
)
_PURE_VERSION_RE = re.compile(r'^\$Version="\d+(?:\.\d+)*"$')
_NTLM_HEADER_RE = re.compile(r"^NTLM\s+[A-Za-z0-9+/]+={0,2}$", re.IGNORECASE)
_OS_ARCH_SIGNATURE_RE = re.compile(
    r"^(?:Windows NT(?:\s+\d+(?:\.\d+)*)?|Win64|WOW64|x86_64|amd64|i[3-6]86|"
    r"arm64|aarch64|MIPS|PowerPC|ppc64|sparc64)$",
    re.IGNORECASE,
)


class PayloadClassifier:
    """Loads the model once and performs efficient batch predictions."""

    _instances: dict[Path, "PayloadClassifier"] = {}

    def __new__(cls, model_path: str | Path | None = None) -> "PayloadClassifier":
        """Returns a singleton instance per resolved model path."""
        resolved_model_path = cls._resolve_model_path(model_path)
        instance = cls._instances.get(resolved_model_path)
        if instance is None:
            instance = super().__new__(cls)
            instance._initialized = False
            instance._resolved_model_path = resolved_model_path
            cls._instances[resolved_model_path] = instance
        return instance

    def __init__(self, model_path: str | Path | None = None) -> None:
        """Initializes the classifier and loads the persisted artifact.

        Args:
            model_path: Optional custom model path.

        Raises:
            FileNotFoundError: If the model artifact does not exist.
            ValueError: If the model artifact is malformed.
        """
        if getattr(self, "_initialized", False):
            return

        resolved_model_path = getattr(self, "_resolved_model_path", self._resolve_model_path(model_path))
        if not resolved_model_path.exists():
            raise FileNotFoundError(
                "Gatekeeper model artifact was not found. "
                f"Resolved path: {resolved_model_path}. "
                "Provide `model_path=...`, set `GATEKEEPER_MODEL_PATH`, or place "
                "a packaged model at `src/gatekeeper_ml/models/payload_classifier.pkl`."
            )

        artifact: dict[str, Any] = joblib.load(resolved_model_path)
        if "model" not in artifact:
            raise ValueError("Invalid model artifact: missing 'model' key.")

        self._pipeline = artifact["model"]
        self._threshold = float(
            artifact.get("threshold", config.INFERENCE_SUSPICIOUS_THRESHOLD)
        )
        self._initialized = True

    @staticmethod
    def _resolve_model_path(model_path: str | Path | None) -> Path:
        """Resolves model path using argument, environment, then packaged default."""
        if model_path:
            return Path(model_path).expanduser().resolve()

        environment_path = os.getenv("GATEKEEPER_MODEL_PATH")
        if environment_path:
            return Path(environment_path).expanduser().resolve()

        return (Path(__file__).parent / "models" / "payload_classifier.pkl").resolve()

    def _contains_high_risk_marker(self, text: str) -> bool:
        """Checks whether the text contains markers that should skip the safe path."""
        lower_text = text.lower()
        return any(keyword in lower_text for keyword in config.SUSPICIOUS_KEYWORDS)

    def _matches_critical_blacklist(self, candidate: str) -> bool:
        """Matches one-hit-kill attack signatures that bypass the ML model."""
        return _CRITICAL_ATTACK_RE.search(candidate) is not None

    def _matches_safe_http_structure(self, candidate: str) -> bool:
        """Matches known-safe HTTP-native structures using precompiled regexes."""
        return any(
            pattern.fullmatch(candidate)
            for pattern in (
                _DIGEST_AUTH_RE,
                _EXACT_OS_SIGNATURE_RE,
                _CLIENT_VERSION_LIST_RE,
                _CHARSET_LIST_RE,
                _HTTP_DATE_RE,
                _QUOTED_ETAG_RE,
                _WEAK_ETAG_RE,
                _SAFE_MEDIA_RANGE_RE,
                _SAFE_ACCEPT_LANGUAGE_RE,
                _SAFE_ENCODING_LIST_RE,
                _SAFE_CACHE_CONTROL_RE,
                _SAFE_COOKIE_RE,
                _SAFE_ETAG_RE,
                _QUALITY_VALUE_RE,
                _CHARSET_TOKEN_RE,
                _BOUNDARY_SEPARATOR_RE,
                _EMAIL_RE,
                _PURE_VERSION_RE,
                _NTLM_HEADER_RE,
                _OS_ARCH_SIGNATURE_RE,
            )
        )

    def _is_fastpath_safe(self, text: str) -> bool:
        """Identifies inputs that are safe enough to bypass the ML model.

        The heuristic is intentionally conservative because recall is favored over
        precision in this gatekeeping system.

        Args:
            text: Raw input string.

        Returns:
            True if the value should immediately be labeled normal.
        """
        candidate = text.strip()
        if not candidate:
            return True
        if self._contains_high_risk_marker(candidate):
            return False
        if _INTEGER_RE.fullmatch(candidate):
            return True
        if _UUID_RE.fullmatch(candidate):
            return True
        if candidate.lower() in config.SAFE_HTTP_HEADER_NAMES:
            return True
        if _DIGEST_AUTH_RE.fullmatch(candidate):
            return True
        if _EXACT_OS_SIGNATURE_RE.fullmatch(candidate):
            return True
        if _CLIENT_VERSION_LIST_RE.fullmatch(candidate):
            return True
        if _CHARSET_LIST_RE.fullmatch(candidate):
            return True
        if _SAFE_HTTP_URL_RE.fullmatch(candidate):
            return True
        if (
            candidate in config.SAFE_ACCEPT_VALUES
            or candidate in config.SAFE_ACCEPT_ENCODING_VALUES
            or candidate in config.SAFE_ACCEPT_LANGUAGE_VALUES
            or candidate in config.SAFE_CACHE_CONTROL_VALUES
            or candidate in config.SAFE_MIME_TYPES
        ):
            return True
        if self._matches_safe_http_structure(candidate):
            return True
        if _SAFE_TOKEN_RE.fullmatch(candidate) and len(candidate) <= 24:
            return True
        if _SAFE_URI_RE.fullmatch(candidate) and ".." not in candidate and "%" not in candidate:
            return True
        if any(char in candidate for char in "<>{}|$`\\'"):
            return False
        if "\"" in candidate and not (
            _QUOTED_ETAG_RE.fullmatch(candidate)
            or _WEAK_ETAG_RE.fullmatch(candidate)
            or _PURE_VERSION_RE.fullmatch(candidate)
        ):
            return False
        if _SAFE_ENCODING_LIST_RE.fullmatch(candidate) and "/" not in candidate:
            return True

        if ":" in candidate:
            header_name, header_value = candidate.split(":", 1)
            normalized_header_name = header_name.strip().lower()
            normalized_header_value = header_value.strip()
            if (
                normalized_header_name in config.SAFE_HTTP_HEADER_NAMES
                and _SAFE_HEADER_VALUE_RE.fullmatch(normalized_header_value)
                and "%" not in normalized_header_value
            ):
                return True
            if normalized_header_name in {"referer", "origin"} and _SAFE_HTTP_URL_RE.fullmatch(
                normalized_header_value
            ):
                return True
            if _HTTP_DATE_RE.fullmatch(normalized_header_value):
                return True
            if _DIGEST_AUTH_RE.fullmatch(normalized_header_value):
                return True
            if (
                normalized_header_name == "accept"
                and (
                    _SAFE_MEDIA_RANGE_RE.fullmatch(normalized_header_value)
                    or _QUALITY_VALUE_RE.fullmatch(normalized_header_value)
                    or normalized_header_value == "*/*"
                )
            ):
                return True
            if (
                normalized_header_name == "accept-language"
                and (
                    _SAFE_ACCEPT_LANGUAGE_RE.fullmatch(normalized_header_value)
                    or _CHARSET_TOKEN_RE.fullmatch(normalized_header_value)
                    or "q=0." in normalized_header_value.lower()
                )
            ):
                return True
            if normalized_header_name in {"accept-charset", "charset"} and (
                _CHARSET_LIST_RE.fullmatch(normalized_header_value)
            ):
                return True
            if (
                normalized_header_name == "accept-encoding"
                and _SAFE_ENCODING_LIST_RE.fullmatch(normalized_header_value)
            ):
                return True
            if (
                normalized_header_name == "cache-control"
                and _SAFE_CACHE_CONTROL_RE.fullmatch(normalized_header_value)
            ):
                return True
            if normalized_header_name == "cookie" and _SAFE_COOKIE_RE.fullmatch(
                normalized_header_value
            ):
                return True
            if normalized_header_name == "authorization" and _NTLM_HEADER_RE.fullmatch(
                normalized_header_value
            ):
                return True
            if normalized_header_name in {"user-agent", "server"} and (
                _OS_ARCH_SIGNATURE_RE.search(normalized_header_value) is not None
            ):
                return True
            if normalized_header_name in {"x-client-version", "client-version"} and (
                _CLIENT_VERSION_LIST_RE.fullmatch(normalized_header_value)
            ):
                return True
            if normalized_header_name in {"etag", "if-none-match"} and _SAFE_ETAG_RE.fullmatch(
                normalized_header_value
            ):
                return True
            if normalized_header_name == "content-type" and (
                _SAFE_MEDIA_RANGE_RE.fullmatch(normalized_header_value)
                or "boundary=" in normalized_header_value.lower()
            ):
                return True
            if normalized_header_name == "content-disposition" and "filename=" in normalized_header_value.lower():
                return True

        return False

    def predict_batch(self, inputs: list[str]) -> list[int]:
        """Predicts suspiciousness for a batch of strings.

        Args:
            inputs: Raw strings to classify.

        Returns:
            List of binary predictions where 0 is normal and 1 is suspicious.
        """
        if not inputs:
            return []

        predictions: list[int | None] = [None] * len(inputs)
        deferred_inputs: list[str] = []
        deferred_indexes: list[int] = []

        for index, value in enumerate(inputs):
            text = value or ""
            if self._matches_critical_blacklist(text):
                predictions[index] = 1
            elif self._is_fastpath_safe(text):
                predictions[index] = 0
            else:
                deferred_inputs.append(text)
                deferred_indexes.append(index)

        if deferred_inputs:
            if hasattr(self._pipeline, "predict_proba"):
                probabilities = self._pipeline.predict_proba(deferred_inputs)[:, 1]
                deferred_predictions = [
                    1 if probability >= self._threshold else 0
                    for probability in probabilities
                ]
            else:
                deferred_predictions = list(self._pipeline.predict(deferred_inputs))

            for index, prediction in zip(deferred_indexes, deferred_predictions):
                predictions[index] = int(prediction)

        return [int(prediction or 0) for prediction in predictions]
