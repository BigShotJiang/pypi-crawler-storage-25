"""Gatekeeper ML package for fast suspicious payload classification."""

from .predict import PayloadClassifier

__all__ = ["PayloadClassifier"]
