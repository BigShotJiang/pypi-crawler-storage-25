import importlib.util
import io
import logging
import subprocess
import sys
from contextlib import contextmanager
from typing import Generator, List, Optional, Tuple

from alembic import autogenerate, command
from alembic.config import Config
from alembic.runtime.environment import EnvironmentContext, IncludeNameFn
from alembic.script import ScriptDirectory
from attrs import define, field
from sqlalchemy import Engine, MetaData, text


def default_pretty_script(script):
    pass


try:
    # Try to prettify the generated script using black if available
    if importlib.util.find_spec("black"):

        def pretty_script(script):
            try:
                # Format the script content using black
                result = subprocess.run(
                    [
                        sys.executable,
                        "-m",
                        "black",
                        "-q",
                        script.path,
                    ],
                    # input=script.render().encode(),
                    capture_output=True,
                    check=True,
                )
                # Update the script with formatted content
                # script.script_content = result.stdout.decode()
                print(result.stdout.decode())
            except subprocess.CalledProcessError:
                # If black fails, keep the original content
                pass

    else:
        pretty_script = default_pretty_script
except ImportError:
    # If black is not available, keep the original content
    pretty_script = default_pretty_script


@define
class DbVer:
    """Utilities for working with database versions."""

    engine: Engine
    migrations: str
    schema: Optional[str] = None
    main_options: List[Tuple[str, str]] = field(factory=list)
    section_options: List[Tuple[str, str, str]] = field(factory=list)
    script_dir: str = field(default="exdrf_al:db_ver:alembic")

    @contextmanager
    def alembic_config(self) -> Generator[Config, None, None]:
        """Get the alembic config.

        Yields:
            The alembic config.
        """

        # Create the instance.
        alembic_cfg = Config()

        # Set the main options.
        alembic_cfg.set_main_option("script_location", self.script_dir)
        alembic_cfg.set_main_option("path_separator", "os")
        alembic_cfg.set_main_option("version_locations", self.migrations)
        for key, value in self.main_options:
            alembic_cfg.set_main_option(key, value)

        # Default options in sections.
        alembic_cfg.set_section_option("loggers", "keys", "root,sqlalchemy,alembic")
        alembic_cfg.set_section_option("handlers", "keys", "console")
        alembic_cfg.set_section_option("formatters", "keys", "generic")

        alembic_cfg.set_section_option("logger_root", "level", "WARN")
        alembic_cfg.set_section_option("logger_root", "handlers", "console")
        alembic_cfg.set_section_option("logger_root", "qualname", "")

        alembic_cfg.set_section_option("logger_sqlalchemy", "level", "WARN")
        alembic_cfg.set_section_option("logger_sqlalchemy", "handlers", "")
        alembic_cfg.set_section_option(
            "logger_sqlalchemy", "qualname", "sqlalchemy.engine"
        )

        alembic_cfg.set_section_option("logger_alembic", "level", "INFO")
        alembic_cfg.set_section_option("logger_alembic", "handlers", "")
        alembic_cfg.set_section_option("logger_alembic", "qualname", "alembic")

        alembic_cfg.set_section_option("handler_console", "class", "StreamHandler")
        alembic_cfg.set_section_option("handler_console", "args", "(sys.stderr,)")
        alembic_cfg.set_section_option("handler_console", "level", "NOTSET")
        alembic_cfg.set_section_option("handler_console", "formatter", "generic")

        alembic_cfg.set_section_option(
            "formatter_generic",
            "format",
            r"%%(levelname)-5.5s [%%(name)s] %%(message)s",
        )
        alembic_cfg.set_section_option("formatter_generic", "datefmt", r"%%H:%%M:%%S")

        # Set the section options.
        for section, key, value in self.section_options:
            alembic_cfg.set_section_option(section, key, value)

        # Set the schema in attributes so env.py can use it.
        alembic_cfg.attributes["schema"] = self.schema

        # Set the connection.
        if self.engine is not None:
            with self.engine.begin() as connection:
                # Inform alembic to use the connection.
                alembic_cfg.attributes["connection"] = connection
                yield alembic_cfg
        else:
            yield alembic_cfg

    def set_version(self, version: str = "heads"):
        """Set the version inside the database as the latest version.

        Args:
            version: The version to set.
        """
        with self.alembic_config() as alembic_cfg:
            command.stamp(alembic_cfg, version)

    def create_tables(self, metadata: MetaData):
        """Create all tables in the database.

        Args:
            metadata: The metadata to create the tables from.
        """
        # Create all tables.
        with self.engine.begin() as conn:
            metadata.create_all(conn)

            # Load the Alembic configuration and generate the
            # version table, "stamping" it with the most recent rev:
            self.set_version()

    def upgrade(self, target: str = "heads"):
        """Run migrations on the database.

        Args:
            engine: The database engine.
            migrations: The migrations module (`myapp:migrations`).
        """
        from exdrf_al.sql_formatter import disable_sql_formatter

        with disable_sql_formatter():
            with self.alembic_config() as alembic_cfg:
                command.upgrade(alembic_cfg, target)

    def initial(self, metadata, message: str = "Initial schema"):
        """Create the initial migration that creates the tables.

        Args:
            message: The message to be used in the migration.
        """
        with self.alembic_config() as alembic_cfg:
            alembic_cfg.attributes["metadata"] = metadata
            alembic_cfg.attributes["schema"] = None
            command.revision(alembic_cfg, message=message, autogenerate=True)

    def downgrade(self, target: str = "-1"):
        """Restore previous version.

        Args:
            target: The target version.
        """
        with self.alembic_config() as alembic_cfg:
            command.downgrade(alembic_cfg, target)

    def autogenerate(
        self,
        metadata: MetaData,
        message: Optional[str] = None,
        include_filter: Optional[IncludeNameFn] = None,
        use_sql: bool = False,
    ) -> str:
        """Generate migrations.

        Args:
            metadata: The metadata to create the tables from.
            message: The message to be used in the migration.
            include_filter: The filter to be used in the migration.
            use_sql: Whether to use SQL or not.
        """
        with self.alembic_config() as alembic_cfg:
            output_buffer = io.StringIO()
            alembic_cfg.stdout = output_buffer
            alembic_cfg.attributes["metadata"] = metadata
            if include_filter:
                alembic_cfg.attributes["include_name"] = include_filter

            # Following code was borrowed from command.revision.
            script_directory = ScriptDirectory.from_config(alembic_cfg)
            command_args = dict(
                message=message,
                autogenerate=autogenerate,
                sql=False,
                head="head",
                splice=False,
                branch_label=None,
                version_path=None,
                rev_id=None,
                depends_on=None,
            )

            revision_context = autogenerate.RevisionContext(
                alembic_cfg,
                script_directory,
                command_args,
                process_revision_directives=None,
            )

            def retrieve_migrations(rev, context):
                revision_context.run_autogenerate(rev, context)
                return []

            with EnvironmentContext(
                alembic_cfg,
                script_directory,
                fn=retrieve_migrations,
                as_sql=use_sql,
                template_args=revision_context.template_args,
                revision_context=revision_context,
                include_name=include_filter,
            ):
                script_directory.run_env()

            # Go through the generated scripts and format them.
            scripts = []
            for script in revision_context.generate_scripts():
                pretty_script(script)
                scripts.append(script)
            assert len(scripts) > 0

        return output_buffer.getvalue()

    def get_history(self):
        """Get the history of the migrations.

        Returns:
            A list of tuples, where each tuple contains (revision_key, message).
            The message is the migration message or an empty string if not
            available. Revisions are returned in chronological order from
            base to head.
        """
        with self.alembic_config() as alembic_cfg:
            script_directory = ScriptDirectory.from_config(alembic_cfg)
            # Get all revisions by walking the revision graph
            # walk_revisions() returns scripts in topological order
            # (base to heads)
            revisions = []
            for script in script_directory.walk_revisions():
                message = script.doc if script.doc else ""
                revisions.append((script.revision, message))

        return revisions

    def _alembic_version_table_sql(self, alembic_cfg: Config) -> str:
        """Return the SQL identifier for the Alembic version table.

        Args:
            alembic_cfg: Active Alembic configuration.

        Returns:
            Qualified ``schema.table`` when a schema is configured.
        """

        alembic_version_table = (
            alembic_cfg.get_main_option("version_table") or "alembic_version"
        )
        if self.schema:
            quoted_schema = f'"{self.schema}"'
            return f"{quoted_schema}.{alembic_version_table}"
        return alembic_version_table

    def get_head_revisions(self) -> List[str]:
        """Return all head revision ids from configured Alembic scripts.

        Returns:
            Sorted head revision ids, or an empty list when no scripts exist.
        """

        with self.alembic_config() as alembic_cfg:
            script_directory = ScriptDirectory.from_config(alembic_cfg)
            return sorted(script_directory.get_heads())

    def get_current_versions(self) -> List[str]:
        """Return all revision ids stored in the Alembic version table.

        Branched migration graphs may record one row per applied head.

        Returns:
            Sorted revision ids, or an empty list when the table is missing or
            empty.
        """

        try:
            with self.engine.connect() as conn:
                with self.alembic_config() as alembic_cfg:
                    table_name = self._alembic_version_table_sql(alembic_cfg)
                try:
                    result = conn.execute(
                        text(f"SELECT version_num FROM {table_name} ORDER BY 1")
                    )
                except Exception as exc:
                    logging.getLogger(__name__).debug(
                        "Error reading Alembic version rows: %s.",
                        exc,
                        exc_info=True,
                    )
                    return []
                return [row[0] for row in result.fetchall()]
        except Exception as exc:
            if "psycopg2.errors.UndefinedTable" not in str(exc):
                logging.getLogger(__name__).error(
                    "Error getting current versions of the database.",
                    exc_info=True,
                )
            return []

    def get_current_version(self) -> Optional[str]:
        """Get the current database revision label for display.

        When multiple heads are recorded, returns a comma-separated list in
        sorted order.

        Returns:
            One revision id, a comma-separated list, or ``None``.
        """

        versions = self.get_current_versions()
        if not versions:
            return None
        if len(versions) == 1:
            return versions[0]
        return ", ".join(versions)

    def needs_migration(self) -> bool:
        """Return whether the database is missing any configured head revision.

        Returns:
            ``True`` when at least one Alembic head is not recorded in the
            version table.
        """

        heads = set(self.get_head_revisions())
        if not heads:
            return False
        return set(self.get_current_versions()) != heads

    def get_latest_version(self) -> Optional[str]:
        """Return the configured Alembic head revision label for display.

        When the script graph has multiple heads, returns a comma-separated list
        in sorted order (same format as :meth:`get_current_version`).

        Returns:
            One head revision id, a comma-separated list, or ``None`` when no
            scripts exist (for example empty ``version_locations``).
        """

        heads = self.get_head_revisions()
        if not heads:
            logging.getLogger(__name__).warning(
                "No Alembic revision scripts were found; "
                "check script_location and version_locations "
                "(e.g. EXDRF_DB_MIGRATIONS_DIR)."
            )
            return None
        if len(heads) == 1:
            return heads[0]
        return ", ".join(heads)
