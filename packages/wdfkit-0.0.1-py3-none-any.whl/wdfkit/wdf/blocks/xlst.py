# -*- coding: utf-8 -*-
"""Parse ``XLST`` spectral / X-axis coordinate block."""

from __future__ import annotations

from ...internal import constants as const
from ...spectral import resolve_spectral_axis
from ..binary_io import read_from_file
from ..block_index import indices_named
from ..parse_context import ParseContext


def parse_xlst(ctx: ParseContext) -> None:
    name = "XLST"
    for i in indices_named(ctx.blocks, name):
        ctx.print_block_header(name, i)
        ctx.f.seek(ctx.blocks["BlockOffsets"][i] + 16)
        xldt = read_from_file(ctx.f)
        ctx.params["XlistDataType"] = const.DATA_TYPES.get(
            xldt, f"{xldt}_unknown"
        )
        xldu = read_from_file(ctx.f)
        ctx.params["XlistDataUnits"] = const.DATA_UNITS.get(
            xldu, f"{xldu}_unknown"
        )
        x_values = read_from_file(ctx.f, "<f", count=ctx.npoints)
        spectral_spec = resolve_spectral_axis(
            ctx.params["XlistDataUnits"], ctx.spectral_dim
        )
        ctx.spectral_dim_name = spectral_spec.dim_name
        ctx.coord_dict = {
            **ctx.coord_dict,
            ctx.spectral_dim_name: (
                ctx.spectral_dim_name,
                x_values,
                {
                    "long_name": ctx.params["XlistDataUnits"],
                    "units": spectral_spec.units,
                },
            ),
        }

    if ctx.verbose and ctx.spectral_dim_name:
        xv = ctx.coord_dict[ctx.spectral_dim_name][1]
        print(f"{'The shape of the x_values is':-<40s} : \t{xv.shape} ")
        print(
            f"*These are the \"{ctx.params['XlistDataType']}"
            f"\" recordings in \"{ctx.params['XlistDataUnits']}\" units"
        )
