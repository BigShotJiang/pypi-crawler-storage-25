from datetime import date, datetime
from pydantic.main import BaseModel
from typing import Optional


class CountryDto(BaseModel):
    country_id: Optional[str] = None
    country_name: Optional[str] = None
    country_code: Optional[str] = None


CountryDto.model_rebuild()
