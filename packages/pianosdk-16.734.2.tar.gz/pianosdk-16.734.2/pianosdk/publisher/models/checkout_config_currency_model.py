from datetime import date, datetime
from pydantic.main import BaseModel
from typing import Optional


class CheckoutConfigCurrencyModel(BaseModel):
    code: Optional[str] = None
    name: Optional[str] = None
    symbol: Optional[str] = None


CheckoutConfigCurrencyModel.model_rebuild()
