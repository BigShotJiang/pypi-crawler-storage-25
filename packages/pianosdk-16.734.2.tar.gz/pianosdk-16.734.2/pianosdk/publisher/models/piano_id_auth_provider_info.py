from datetime import date, datetime
from pydantic.main import BaseModel
from typing import Optional


class PianoIdAuthProviderInfo(BaseModel):
    name: Optional[str] = None
    source: Optional[str] = None


PianoIdAuthProviderInfo.model_rebuild()
