# CHANGELOG


## v1.0.14 (2026-05-17)


## v1.0.13 (2026-05-17)

### Bug Fixes

- Readme
  ([`67aae77`](https://github.com/anogowski/data-to-xml/commit/67aae771e5d50ac619cdafd30f22bb2101102390))


## v1.0.12 (2026-05-17)

### Bug Fixes

- Combine workflows
  ([`00d16f0`](https://github.com/anogowski/data-to-xml/commit/00d16f01cc7b6ba863166fc4faab27a908cd197c))


## v1.0.11 (2026-05-17)

### Bug Fixes

- Project naming
  ([`52d72f3`](https://github.com/anogowski/data-to-xml/commit/52d72f32c16cbfa5bfb1f0ab3b6f11837f20b49e))


## v1.0.10 (2026-05-17)

### Bug Fixes

- Python-semantic-release@v9
  ([`105808a`](https://github.com/anogowski/data-to-xml/commit/105808a9b6d08a4484ff5c6b0ddbff7831407430))

- Release after tagging
  ([`e042696`](https://github.com/anogowski/data-to-xml/commit/e042696bd76c24031ee8102b28c7edca168fb4cd))

- Toml and auto tag
  ([`49a6184`](https://github.com/anogowski/data-to-xml/commit/49a61840ec7bd7758ed1defc61b5adfec8a98907))

### Chores

- Auto tag
  ([`eaa6bbd`](https://github.com/anogowski/data-to-xml/commit/eaa6bbdb6db986518c8ef26b30edf00f2a7ff1d1))


## v1.0.9 (2024-11-13)


## v1.0.8 (2024-11-13)


## v1.0.7 (2024-10-28)


## v1.0.5 (2024-10-25)


## v1.0.4 (2024-10-25)


## v1.0.3 (2024-10-25)


## v1.0.2 (2024-10-25)


## v1.0.1 (2024-10-25)


## v1.0.0 (2024-10-25)
