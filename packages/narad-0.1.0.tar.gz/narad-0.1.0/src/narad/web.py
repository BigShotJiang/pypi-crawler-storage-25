from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from narad import db, store

PACKAGE_DIR = Path(__file__).parent
templates = Jinja2Templates(directory=PACKAGE_DIR / "templates")

app = FastAPI(title="Narad")
app.mount("/static", StaticFiles(directory=PACKAGE_DIR / "static"), name="static")


@app.get("/", response_class=HTMLResponse)
def home(request: Request) -> HTMLResponse:
    with db.session() as conn:
        data = store.today(conn)
        contacts = store.list_contacts(conn, limit=12)
        open_tasks = store.list_tasks(conn, status="open", limit=12)
    return templates.TemplateResponse(
        request,
        "home.html",
        {"today": data, "contacts": contacts, "open_tasks": open_tasks},
    )


@app.get("/contacts", response_class=HTMLResponse)
def contacts(request: Request, q: str = "") -> HTMLResponse:
    with db.session() as conn:
        results = store.search(conn, q, limit=30) if q.strip() else []
        rows = store.list_contacts(conn, limit=50)
    return templates.TemplateResponse(
        request,
        "contacts.html",
        {"contacts": rows, "query": q, "results": results},
    )


@app.post("/contacts")
def create_contact(
    name: str = Form(...),
    company: str = Form(""),
    title: str = Form(""),
    email: str = Form(""),
    phone: str = Form(""),
    location: str = Form(""),
    source: str = Form(""),
    tags: str = Form(""),
) -> RedirectResponse:
    tag_list = [tag.strip() for tag in tags.split(",") if tag.strip()]
    with db.session() as conn:
        created = store.create_contact(
            conn,
            name,
            organization=company or None,
            title=title or None,
            email=email or None,
            phone=phone or None,
            location=location or None,
            source=source or None,
            tags=tag_list,
        )
    return _redirect(f"/contacts/{created.id}")


@app.get("/contacts/{contact_id}", response_class=HTMLResponse)
def contact_detail(request: Request, contact_id: int) -> HTMLResponse:
    with db.session() as conn:
        detail = store.contact_detail(conn, contact_id)
    return templates.TemplateResponse(request, "contact_detail.html", detail)


@app.post("/contacts/{contact_id}/edit")
def edit_contact(
    contact_id: int,
    name: str = Form(...),
    company: str = Form(""),
    title: str = Form(""),
    email: str = Form(""),
    phone: str = Form(""),
    location: str = Form(""),
    source: str = Form(""),
    tags: str = Form(""),
) -> RedirectResponse:
    tag_list = [tag.strip() for tag in tags.split(",") if tag.strip()]
    with db.session() as conn:
        store.update_contact(
            conn,
            contact_id,
            name=name,
            organization=company,
            title=title,
            email=email,
            phone=phone,
            location=location,
            source=source,
            tags=tag_list,
        )
    return _redirect(f"/contacts/{contact_id}")


@app.post("/contacts/{contact_id}/notes")
def add_contact_note(
    contact_id: int,
    body: str = Form(...),
    kind: str = Form("note"),
    channel: str = Form(""),
) -> RedirectResponse:
    with db.session() as conn:
        store.create_interaction(
            conn,
            body,
            contact=contact_id,
            kind=kind or "note",
            channel=channel or None,
        )
    return _redirect(f"/contacts/{contact_id}")


@app.post("/contacts/{contact_id}/tasks")
def add_contact_task(
    contact_id: int,
    title: str = Form(...),
    due: str = Form(""),
) -> RedirectResponse:
    with db.session() as conn:
        store.create_task(conn, title, due=due or None, contact=contact_id)
    return _redirect(f"/contacts/{contact_id}")


@app.post("/tasks/{task_id}/done")
def complete_task(task_id: int, return_to: str = Form("/")) -> RedirectResponse:
    with db.session() as conn:
        store.complete_task(conn, task_id)
    return _redirect(return_to or "/")


@app.get("/tasks", response_class=HTMLResponse)
def tasks(request: Request, status: str = "open") -> HTMLResponse:
    with db.session() as conn:
        rows = store.list_tasks(conn, status=status, limit=100)
    return templates.TemplateResponse(request, "tasks.html", {"tasks": rows, "status": status})


def _redirect(path: str) -> RedirectResponse:
    return RedirectResponse(path, status_code=303)
