from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass
from datetime import date, datetime, timedelta


@dataclass(frozen=True)
class Created:
    kind: str
    id: int
    label: str


class _Unset:
    pass


_UNSET = _Unset()


def now_text() -> str:
    return datetime.now().replace(microsecond=0).isoformat(sep=" ")


def parse_due(value: str | None) -> str | None:
    if not value:
        return None
    normalized = value.strip().lower()
    today = date.today()
    if normalized == "today":
        return today.isoformat()
    if normalized == "tomorrow":
        return (today + timedelta(days=1)).isoformat()
    if normalized in {"next week", "week"}:
        return (today + timedelta(days=7)).isoformat()
    try:
        return date.fromisoformat(normalized).isoformat()
    except ValueError as exc:
        raise ValueError("Use today, tomorrow, next week, or YYYY-MM-DD for due dates.") from exc


def create_organization(
    conn: sqlite3.Connection,
    name: str,
    website: str | None = None,
    industry: str | None = None,
    location: str | None = None,
    tags: list[str] | None = None,
) -> Created:
    existing = conn.execute(
        "SELECT id, name FROM organizations WHERE name = ? COLLATE NOCASE AND deleted_at IS NULL",
        (name,),
    ).fetchone()
    if existing:
        org_id = int(existing["id"])
        _set_tags(conn, "organization", org_id, tags or [])
        _index_organization(conn, org_id)
        return Created("organization", org_id, existing["name"])

    cur = conn.execute(
        """
        INSERT INTO organizations (name, website, industry, location)
        VALUES (?, ?, ?, ?)
        """,
        (name.strip(), website, industry, location),
    )
    org_id = int(cur.lastrowid)
    _set_tags(conn, "organization", org_id, tags or [])
    _index_organization(conn, org_id)
    return Created("organization", org_id, name.strip())


def create_contact(
    conn: sqlite3.Connection,
    name: str,
    organization: str | None = None,
    title: str | None = None,
    email: str | None = None,
    phone: str | None = None,
    location: str | None = None,
    tags: list[str] | None = None,
    source: str | None = None,
) -> Created:
    org_id = None
    if organization:
        org_id = create_organization(conn, organization).id

    cur = conn.execute(
        """
        INSERT INTO contacts (name, organization_id, title, email, phone, location, source)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (name.strip(), org_id, title, email, phone, location, _clean_label(source)),
    )
    contact_id = int(cur.lastrowid)
    _set_tags(conn, "contact", contact_id, tags or [])
    _index_contact(conn, contact_id)
    return Created("contact", contact_id, name.strip())


def update_contact(
    conn: sqlite3.Connection,
    contact_id: int,
    *,
    name: str | None | _Unset = _UNSET,
    organization: str | None | _Unset = _UNSET,
    title: str | None | _Unset = _UNSET,
    email: str | None | _Unset = _UNSET,
    phone: str | None | _Unset = _UNSET,
    location: str | None | _Unset = _UNSET,
    source: str | None | _Unset = _UNSET,
    tags: list[str] | None | _Unset = _UNSET,
) -> sqlite3.Row:
    existing = conn.execute(
        "SELECT id FROM contacts WHERE id = ? AND deleted_at IS NULL",
        (contact_id,),
    ).fetchone()
    if not existing:
        raise LookupError(f"No contact found for id {contact_id}.")

    assignments: list[str] = []
    values: list[object] = []

    if not isinstance(name, _Unset):
        clean_name = (name or "").strip()
        if not clean_name:
            raise ValueError("Contact name cannot be blank.")
        assignments.append("name = ?")
        values.append(clean_name)

    if not isinstance(organization, _Unset):
        org_id = None
        clean_org = _clean_text(organization)
        if clean_org:
            org_id = create_organization(conn, clean_org).id
        assignments.append("organization_id = ?")
        values.append(org_id)

    for column, value in (
        ("title", title),
        ("email", email),
        ("phone", phone),
        ("location", location),
    ):
        if not isinstance(value, _Unset):
            assignments.append(f"{column} = ?")
            values.append(_clean_text(value))

    if not isinstance(source, _Unset):
        assignments.append("source = ?")
        values.append(_clean_label(source))

    tags_changed = not isinstance(tags, _Unset)
    if tags_changed:
        _replace_tags(conn, "contact", contact_id, tags or [])

    if assignments or tags_changed:
        updated = now_text()
        assignments.append("updated_at = ?")
        values.append(updated)
        values.append(contact_id)
        conn.execute(
            f"UPDATE contacts SET {', '.join(assignments)} WHERE id = ?",
            values,
        )

    _index_contact(conn, contact_id)
    return conn.execute("SELECT * FROM contacts WHERE id = ?", (contact_id,)).fetchone()


def create_interaction(
    conn: sqlite3.Connection,
    body: str,
    contact: str | int | None = None,
    organization: str | int | None = None,
    kind: str = "note",
    channel: str | None = None,
    occurred_at: str | None = None,
) -> Created:
    contact_row = find_contact(conn, contact) if contact else None
    org_row = find_organization(conn, organization) if organization else None
    org_id = org_row["id"] if org_row else None
    if contact_row and not org_id:
        org_id = contact_row["organization_id"]

    cur = conn.execute(
        """
        INSERT INTO interactions (contact_id, organization_id, kind, channel, body, occurred_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            contact_row["id"] if contact_row else None,
            org_id,
            kind,
            _clean_label(channel),
            body.strip(),
            occurred_at or now_text(),
        ),
    )
    interaction_id = int(cur.lastrowid)
    _index_interaction(conn, interaction_id)
    return Created("interaction", interaction_id, kind)


def create_task(
    conn: sqlite3.Connection,
    title: str,
    due: str | None = None,
    contact: str | int | None = None,
    organization: str | int | None = None,
) -> Created:
    contact_row = find_contact(conn, contact) if contact else None
    org_row = find_organization(conn, organization) if organization else None
    org_id = org_row["id"] if org_row else None
    if contact_row and not org_id:
        org_id = contact_row["organization_id"]
    due_at = parse_due(due)

    cur = conn.execute(
        """
        INSERT INTO tasks (title, contact_id, organization_id, due_at)
        VALUES (?, ?, ?, ?)
        """,
        (title.strip(), contact_row["id"] if contact_row else None, org_id, due_at),
    )
    task_id = int(cur.lastrowid)
    _index_task(conn, task_id)
    return Created("task", task_id, title.strip())


def complete_task(conn: sqlite3.Connection, task_id: int) -> sqlite3.Row:
    row = conn.execute(
        "SELECT * FROM tasks WHERE id = ? AND deleted_at IS NULL",
        (task_id,),
    ).fetchone()
    if not row:
        raise LookupError(f"No task found for id {task_id}.")
    completed = now_text()
    conn.execute(
        "UPDATE tasks SET completed_at = ?, updated_at = ? WHERE id = ?",
        (completed, completed, task_id),
    )
    _index_task(conn, task_id)
    return conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()


def find_contact(conn: sqlite3.Connection, value: str | int) -> sqlite3.Row:
    row = _find_entity(conn, "contacts", value)
    if not row:
        raise LookupError(f"No contact found for {value!r}.")
    return row


def find_organization(conn: sqlite3.Connection, value: str | int) -> sqlite3.Row:
    row = _find_entity(conn, "organizations", value)
    if not row:
        raise LookupError(f"No organization found for {value!r}.")
    return row


def list_contacts(
    conn: sqlite3.Connection,
    tag: str | None = None,
    limit: int = 50,
) -> list[sqlite3.Row]:
    params: list[object] = []
    where = ["c.deleted_at IS NULL"]
    join = ""
    if tag:
        join = """
        JOIN contact_tags ct ON ct.contact_id = c.id
        JOIN tags t ON t.id = ct.tag_id
        """
        where.append("t.name = ? COLLATE NOCASE")
        params.append(tag)
    params.append(limit)
    return conn.execute(
        f"""
        SELECT c.*, o.name AS organization_name, group_concat(t2.name, ', ') AS tag_names
        FROM contacts c
        LEFT JOIN organizations o ON o.id = c.organization_id
        LEFT JOIN contact_tags ct2 ON ct2.contact_id = c.id
        LEFT JOIN tags t2 ON t2.id = ct2.tag_id
        {join}
        WHERE {" AND ".join(where)}
        GROUP BY c.id
        ORDER BY c.updated_at DESC, c.id DESC
        LIMIT ?
        """,
        params,
    ).fetchall()


def list_tasks(
    conn: sqlite3.Connection,
    status: str = "open",
    limit: int = 50,
) -> list[sqlite3.Row]:
    where = ["t.deleted_at IS NULL"]
    if status == "open":
        where.append("t.completed_at IS NULL")
    elif status == "done":
        where.append("t.completed_at IS NOT NULL")
    return conn.execute(
        f"""
        SELECT t.*, c.name AS contact_name, o.name AS organization_name
        FROM tasks t
        LEFT JOIN contacts c ON c.id = t.contact_id
        LEFT JOIN organizations o ON o.id = t.organization_id
        WHERE {" AND ".join(where)}
        ORDER BY t.completed_at IS NOT NULL, t.due_at IS NULL, t.due_at, t.id DESC
        LIMIT ?
        """,
        (limit,),
    ).fetchall()


def today(conn: sqlite3.Connection) -> dict[str, list[sqlite3.Row]]:
    today_value = date.today().isoformat()
    overdue = conn.execute(
        """
        SELECT t.*, c.name AS contact_name, o.name AS organization_name
        FROM tasks t
        LEFT JOIN contacts c ON c.id = t.contact_id
        LEFT JOIN organizations o ON o.id = t.organization_id
        WHERE t.deleted_at IS NULL
          AND t.completed_at IS NULL
          AND t.due_at IS NOT NULL
          AND t.due_at < ?
        ORDER BY t.due_at, t.id
        """,
        (today_value,),
    ).fetchall()
    due = conn.execute(
        """
        SELECT t.*, c.name AS contact_name, o.name AS organization_name
        FROM tasks t
        LEFT JOIN contacts c ON c.id = t.contact_id
        LEFT JOIN organizations o ON o.id = t.organization_id
        WHERE t.deleted_at IS NULL
          AND t.completed_at IS NULL
          AND t.due_at = ?
        ORDER BY t.id
        """,
        (today_value,),
    ).fetchall()
    recent = conn.execute(
        """
        SELECT i.*, c.name AS contact_name, o.name AS organization_name
        FROM interactions i
        LEFT JOIN contacts c ON c.id = i.contact_id
        LEFT JOIN organizations o ON o.id = i.organization_id
        WHERE i.deleted_at IS NULL
        ORDER BY i.occurred_at DESC, i.id DESC
        LIMIT 8
        """
    ).fetchall()
    return {"overdue": overdue, "due": due, "recent": recent}


def search(conn: sqlite3.Connection, query: str, limit: int = 20) -> list[sqlite3.Row]:
    if not query.strip():
        return []
    tokens = re.findall(r"[\w]+", query)
    fts_query = " ".join(f"{token}*" for token in tokens)
    if not fts_query:
        return []
    return conn.execute(
        """
        SELECT entity_type, entity_id, title, body, tags, bm25(search_index) AS rank
        FROM search_index
        WHERE search_index MATCH ?
        ORDER BY rank
        LIMIT ?
        """,
        (fts_query, limit),
    ).fetchall()


def _clean_label(value: str | None) -> str | None:
    if not value:
        return None
    cleaned = value.strip().lower()
    return cleaned or None


def _clean_text(value: str | None) -> str | None:
    if not value:
        return None
    cleaned = value.strip()
    return cleaned or None


def contact_detail(conn: sqlite3.Connection, contact_id: int) -> dict[str, object]:
    contact = conn.execute(
        """
        SELECT c.*, o.name AS organization_name, group_concat(t.name, ', ') AS tag_names
        FROM contacts c
        LEFT JOIN organizations o ON o.id = c.organization_id
        LEFT JOIN contact_tags ct ON ct.contact_id = c.id
        LEFT JOIN tags t ON t.id = ct.tag_id
        WHERE c.id = ? AND c.deleted_at IS NULL
        GROUP BY c.id
        """,
        (contact_id,),
    ).fetchone()
    if not contact:
        raise LookupError(f"No contact found for id {contact_id}.")
    interactions = conn.execute(
        """
        SELECT i.*, c.name AS contact_name, o.name AS organization_name
        FROM interactions i
        LEFT JOIN contacts c ON c.id = i.contact_id
        LEFT JOIN organizations o ON o.id = i.organization_id
        WHERE i.contact_id = ? AND i.deleted_at IS NULL
        ORDER BY occurred_at DESC, id DESC
        """,
        (contact_id,),
    ).fetchall()
    tasks = conn.execute(
        """
        SELECT t.*, c.name AS contact_name, o.name AS organization_name
        FROM tasks t
        LEFT JOIN contacts c ON c.id = t.contact_id
        LEFT JOIN organizations o ON o.id = t.organization_id
        WHERE t.contact_id = ? AND t.deleted_at IS NULL
        ORDER BY completed_at IS NOT NULL, due_at IS NULL, due_at, id DESC
        """,
        (contact_id,),
    ).fetchall()
    return {"contact": contact, "interactions": interactions, "tasks": tasks}


def rebuild_search(conn: sqlite3.Connection) -> int:
    conn.execute("DELETE FROM search_index")
    count = 0
    for row in conn.execute("SELECT id FROM organizations WHERE deleted_at IS NULL"):
        _index_organization(conn, row["id"])
        count += 1
    for row in conn.execute("SELECT id FROM contacts WHERE deleted_at IS NULL"):
        _index_contact(conn, row["id"])
        count += 1
    for row in conn.execute("SELECT id FROM interactions WHERE deleted_at IS NULL"):
        _index_interaction(conn, row["id"])
        count += 1
    for row in conn.execute("SELECT id FROM tasks WHERE deleted_at IS NULL"):
        _index_task(conn, row["id"])
        count += 1
    return count


def _find_entity(conn: sqlite3.Connection, table: str, value: str | int) -> sqlite3.Row | None:
    text = str(value).strip()
    if text.isdigit():
        row = conn.execute(
            f"SELECT * FROM {table} WHERE id = ? AND deleted_at IS NULL",
            (int(text),),
        ).fetchone()
        if row:
            return row
    rows = conn.execute(
        f"""
        SELECT * FROM {table}
        WHERE name LIKE ? COLLATE NOCASE AND deleted_at IS NULL
        ORDER BY CASE WHEN name = ? COLLATE NOCASE THEN 0 ELSE 1 END, updated_at DESC
        LIMIT 2
        """,
        (f"%{text}%", text),
    ).fetchall()
    if len(rows) > 1 and rows[0]["name"].lower() != text.lower():
        names = ", ".join(f"{row['id']}:{row['name']}" for row in rows)
        raise LookupError(f"Multiple matches for {value!r}: {names}. Use an id.")
    return rows[0] if rows else None


def _set_tags(conn: sqlite3.Connection, kind: str, entity_id: int, names: list[str]) -> None:
    clean = sorted({name.strip().lower() for name in names if name and name.strip()})
    if not clean:
        return
    table = "contact_tags" if kind == "contact" else "organization_tags"
    id_col = "contact_id" if kind == "contact" else "organization_id"
    for name in clean:
        tag = conn.execute("SELECT id FROM tags WHERE name = ? COLLATE NOCASE", (name,)).fetchone()
        if tag:
            tag_id = tag["id"]
        else:
            tag_id = conn.execute("INSERT INTO tags (name) VALUES (?)", (name,)).lastrowid
        conn.execute(
            f"INSERT OR IGNORE INTO {table} ({id_col}, tag_id) VALUES (?, ?)",
            (entity_id, tag_id),
        )


def _replace_tags(conn: sqlite3.Connection, kind: str, entity_id: int, names: list[str]) -> None:
    table = "contact_tags" if kind == "contact" else "organization_tags"
    id_col = "contact_id" if kind == "contact" else "organization_id"
    conn.execute(f"DELETE FROM {table} WHERE {id_col} = ?", (entity_id,))
    _set_tags(conn, kind, entity_id, names)


def _tag_names(conn: sqlite3.Connection, kind: str, entity_id: int) -> str:
    table = "contact_tags" if kind == "contact" else "organization_tags"
    id_col = "contact_id" if kind == "contact" else "organization_id"
    row = conn.execute(
        f"""
        SELECT group_concat(t.name, ' ') AS names
        FROM {table} et
        JOIN tags t ON t.id = et.tag_id
        WHERE et.{id_col} = ?
        """,
        (entity_id,),
    ).fetchone()
    return row["names"] or ""


def _replace_index(
    conn: sqlite3.Connection,
    entity_type: str,
    entity_id: int,
    title: str,
    body: str,
    tags: str = "",
) -> None:
    conn.execute(
        "DELETE FROM search_index WHERE entity_type = ? AND entity_id = ?",
        (entity_type, str(entity_id)),
    )
    conn.execute(
        """
        INSERT INTO search_index (entity_type, entity_id, title, body, tags)
        VALUES (?, ?, ?, ?, ?)
        """,
        (entity_type, str(entity_id), title, body, tags),
    )


def _index_organization(conn: sqlite3.Connection, org_id: int) -> None:
    row = conn.execute("SELECT * FROM organizations WHERE id = ?", (org_id,)).fetchone()
    if not row:
        return
    body = " ".join(filter(None, [row["website"], row["industry"], row["location"]]))
    _replace_index(
        conn,
        "organization",
        org_id,
        row["name"],
        body,
        _tag_names(conn, "organization", org_id),
    )


def _index_contact(conn: sqlite3.Connection, contact_id: int) -> None:
    row = conn.execute(
        """
        SELECT c.*, o.name AS organization_name
        FROM contacts c
        LEFT JOIN organizations o ON o.id = c.organization_id
        WHERE c.id = ?
        """,
        (contact_id,),
    ).fetchone()
    if not row:
        return
    body = " ".join(
        filter(
            None,
            [
                row["organization_name"],
                row["title"],
                row["email"],
                row["phone"],
                row["location"],
                row["source"],
            ],
        )
    )
    _replace_index(
        conn,
        "contact",
        contact_id,
        row["name"],
        body,
        _tag_names(conn, "contact", contact_id),
    )


def _index_interaction(conn: sqlite3.Connection, interaction_id: int) -> None:
    row = conn.execute(
        """
        SELECT i.*, c.name AS contact_name, o.name AS organization_name
        FROM interactions i
        LEFT JOIN contacts c ON c.id = i.contact_id
        LEFT JOIN organizations o ON o.id = i.organization_id
        WHERE i.id = ?
        """,
        (interaction_id,),
    ).fetchone()
    if not row:
        return
    title = " ".join(
        filter(None, [row["kind"], row["channel"], row["contact_name"], row["organization_name"]])
    )
    _replace_index(conn, "interaction", interaction_id, title, row["body"])


def _index_task(conn: sqlite3.Connection, task_id: int) -> None:
    row = conn.execute(
        """
        SELECT t.*, c.name AS contact_name, o.name AS organization_name
        FROM tasks t
        LEFT JOIN contacts c ON c.id = t.contact_id
        LEFT JOIN organizations o ON o.id = t.organization_id
        WHERE t.id = ?
        """,
        (task_id,),
    ).fetchone()
    if not row:
        return
    body = " ".join(filter(None, [row["contact_name"], row["organization_name"], row["due_at"]]))
    _replace_index(
        conn,
        "task",
        task_id,
        row["title"],
        body,
        "done" if row["completed_at"] else "open",
    )
