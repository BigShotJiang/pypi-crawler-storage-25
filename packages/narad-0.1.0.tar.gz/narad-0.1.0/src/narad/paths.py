from __future__ import annotations

import os
from pathlib import Path

APP_DIR_NAME = ".narad"
DB_FILE_NAME = "narad.db"


def narad_home() -> Path:
    configured = os.environ.get("NARAD_HOME")
    if configured:
        return Path(configured).expanduser()
    return Path.home() / APP_DIR_NAME


def database_path() -> Path:
    configured = os.environ.get("NARAD_DB")
    if configured:
        return Path(configured).expanduser()
    return narad_home() / DB_FILE_NAME


def ensure_home() -> Path:
    home = narad_home()
    home.mkdir(parents=True, exist_ok=True)
    (home / "backups").mkdir(exist_ok=True)
    (home / "exports").mkdir(exist_ok=True)
    (home / "logs").mkdir(exist_ok=True)
    return home
