from __future__ import annotations

from typing import Annotated

import typer
import uvicorn
from rich.console import Console
from rich.table import Table

from narad import db, store
from narad.paths import database_path, ensure_home, narad_home

app = typer.Typer(help="Narad, a lightweight personal CRM.")
add_app = typer.Typer(help="Add records.")
edit_app = typer.Typer(help="Edit records.")
list_app = typer.Typer(help="List records.")
app.add_typer(add_app, name="add")
app.add_typer(edit_app, name="edit")
app.add_typer(list_app, name="list")
console = Console()


def main() -> None:
    try:
        app()
    except (LookupError, ValueError) as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1) from exc


@app.command()
def init() -> None:
    """Create ~/.narad and initialize the SQLite database."""
    home = ensure_home()
    path = db.init_db()
    console.print(f"[green]Ready[/green] {home}")
    console.print(f"Database: {path}")


@add_app.command()
def org(
    name: Annotated[str, typer.Argument(help="Organization name")],
    website: Annotated[str | None, typer.Option("--website", "-w")] = None,
    industry: Annotated[str | None, typer.Option("--industry", "-i")] = None,
    location: Annotated[str | None, typer.Option("--location", "-l")] = None,
    tag: Annotated[list[str] | None, typer.Option("--tag", "-t")] = None,
) -> None:
    with db.session() as conn:
        created = store.create_organization(conn, name, website, industry, location, tag)
    console.print(f"[green]organization[/green] #{created.id} {created.label}")


@add_app.command()
def contact(
    name: Annotated[str, typer.Argument(help="Contact name")],
    company: Annotated[str | None, typer.Option("--company", "-c")] = None,
    title: Annotated[str | None, typer.Option("--title")] = None,
    email: Annotated[str | None, typer.Option("--email", "-e")] = None,
    phone: Annotated[str | None, typer.Option("--phone", "-p")] = None,
    location: Annotated[str | None, typer.Option("--location", "-l")] = None,
    source: Annotated[str | None, typer.Option("--source", "-s")] = None,
    tag: Annotated[list[str] | None, typer.Option("--tag", "-t")] = None,
) -> None:
    with db.session() as conn:
        created = store.create_contact(
            conn,
            name,
            organization=company,
            title=title,
            email=email,
            phone=phone,
            location=location,
            tags=tag,
            source=source,
        )
    console.print(f"[green]contact[/green] #{created.id} {created.label}")


@add_app.command()
def note(
    body: Annotated[str, typer.Argument(help="Note body")],
    contact: Annotated[str | None, typer.Option("--contact", "-c")] = None,
    org: Annotated[str | None, typer.Option("--org", "-o")] = None,
    kind: Annotated[str, typer.Option("--kind", "-k")] = "note",
    channel: Annotated[str | None, typer.Option("--channel")] = None,
) -> None:
    with db.session() as conn:
        created = store.create_interaction(
            conn,
            body,
            contact=contact,
            organization=org,
            kind=kind,
            channel=channel,
        )
    console.print(f"[green]note[/green] #{created.id}")


@add_app.command()
def task(
    title: Annotated[str, typer.Argument(help="Task title")],
    due: Annotated[str | None, typer.Option("--due", "-d")] = None,
    contact: Annotated[str | None, typer.Option("--contact", "-c")] = None,
    org: Annotated[str | None, typer.Option("--org", "-o")] = None,
) -> None:
    with db.session() as conn:
        created = store.create_task(conn, title, due=due, contact=contact, organization=org)
    console.print(f"[green]task[/green] #{created.id} {created.label}")


@edit_app.command("contact")
def edit_contact(
    contact_id: Annotated[int, typer.Argument(help="Contact ID")],
    name: Annotated[str | None, typer.Option("--name")] = None,
    company: Annotated[str | None, typer.Option("--company", "-c")] = None,
    title: Annotated[str | None, typer.Option("--title")] = None,
    email: Annotated[str | None, typer.Option("--email", "-e")] = None,
    phone: Annotated[str | None, typer.Option("--phone", "-p")] = None,
    location: Annotated[str | None, typer.Option("--location", "-l")] = None,
    source: Annotated[str | None, typer.Option("--source", "-s")] = None,
    tag: Annotated[list[str] | None, typer.Option("--tag", "-t")] = None,
    clear_tags: Annotated[bool, typer.Option("--clear-tags")] = False,
) -> None:
    if tag is not None and clear_tags:
        raise ValueError("Use either --tag to replace tags or --clear-tags, not both.")

    updates: dict[str, object] = {}
    for key, value in (
        ("name", name),
        ("organization", company),
        ("title", title),
        ("email", email),
        ("phone", phone),
        ("location", location),
        ("source", source),
    ):
        if value is not None:
            updates[key] = value
    if clear_tags:
        updates["tags"] = []
    elif tag is not None:
        updates["tags"] = tag

    with db.session() as conn:
        row = store.update_contact(conn, contact_id, **updates)
    console.print(f"[green]contact[/green] #{row['id']} {row['name']}")


@list_app.command("contacts")
def contacts(
    tag: Annotated[str | None, typer.Option("--tag", "-t")] = None,
    limit: Annotated[int, typer.Option("--limit", "-n")] = 50,
) -> None:
    with db.session() as conn:
        rows = store.list_contacts(conn, tag=tag, limit=limit)
    table = Table("ID", "Name", "Company", "Source", "Email", "Phone", "Tags")
    for row in rows:
        table.add_row(
            str(row["id"]),
            row["name"],
            row["organization_name"] or "",
            row["source"] or "",
            row["email"] or "",
            row["phone"] or "",
            row["tag_names"] or "",
        )
    console.print(table)


@list_app.command("tasks")
def tasks(
    status: Annotated[str, typer.Option("--status", "-s", help="open, done, or all")] = "open",
    limit: Annotated[int, typer.Option("--limit", "-n")] = 50,
) -> None:
    with db.session() as conn:
        rows = store.list_tasks(conn, status=status, limit=limit)
    _print_tasks(rows)


@app.command()
def today() -> None:
    """Show overdue tasks, tasks due today, and recent interactions."""
    with db.session() as conn:
        data = store.today(conn)
    console.print("[bold]Today[/bold]")
    console.print("\n[red]Overdue[/red]")
    _print_tasks(data["overdue"])
    console.print("\n[yellow]Due today[/yellow]")
    _print_tasks(data["due"])
    console.print("\n[cyan]Recent notes[/cyan]")
    _print_interactions(data["recent"])


@app.command()
def search(
    query: Annotated[str, typer.Argument(help="Text to search")],
    limit: Annotated[int, typer.Option("--limit", "-n")] = 20,
) -> None:
    with db.session() as conn:
        rows = store.search(conn, query, limit)
    table = Table("Type", "ID", "Title", "Body", "Tags")
    for row in rows:
        table.add_row(
            row["entity_type"],
            str(row["entity_id"]),
            row["title"] or "",
            _clip(row["body"] or "", 70),
            row["tags"] or "",
        )
    console.print(table)


@app.command()
def show(contact_id: Annotated[int, typer.Argument(help="Contact ID")]) -> None:
    with db.session() as conn:
        detail = store.contact_detail(conn, contact_id)
    contact = detail["contact"]
    console.print(f"[bold]#{contact['id']} {contact['name']}[/bold]")
    if contact["organization_name"]:
        console.print(f"Company: {contact['organization_name']}")
    if contact["title"]:
        console.print(f"Title: {contact['title']}")
    if contact["email"]:
        console.print(f"Email: {contact['email']}")
    if contact["phone"]:
        console.print(f"Phone: {contact['phone']}")
    if contact["source"]:
        console.print(f"Source: {contact['source']}")
    if contact["tag_names"]:
        console.print(f"Tags: {contact['tag_names']}")
    console.print("\n[cyan]Tasks[/cyan]")
    _print_tasks(detail["tasks"])
    console.print("\n[cyan]Timeline[/cyan]")
    _print_interactions(detail["interactions"])


@app.command()
def done(task_id: Annotated[int, typer.Argument(help="Task ID")]) -> None:
    with db.session() as conn:
        row = store.complete_task(conn, task_id)
    console.print(f"[green]done[/green] #{row['id']} {row['title']}")


@app.command("search-reindex")
def search_reindex() -> None:
    with db.session() as conn:
        count = store.rebuild_search(conn)
    console.print(f"[green]indexed[/green] {count} records")


@app.command()
def path() -> None:
    """Print Narad paths."""
    console.print(f"Home: {narad_home()}")
    console.print(f"Database: {database_path()}")


@app.command()
def serve(
    host: Annotated[str, typer.Option("--host")] = "127.0.0.1",
    port: Annotated[int, typer.Option("--port", "-p")] = 8765,
    reload: Annotated[bool, typer.Option("--reload")] = False,
) -> None:
    """Start the local browser UI."""
    db.init_db()
    console.print(f"[green]Narad UI[/green] http://{host}:{port}")
    uvicorn.run("narad.web:app", host=host, port=port, reload=reload)


def _print_tasks(rows) -> None:
    table = Table("ID", "Due", "Task", "Contact", "Company", "Done")
    for row in rows:
        table.add_row(
            str(row["id"]),
            row["due_at"] or "",
            row["title"],
            row["contact_name"] or "",
            row["organization_name"] or "",
            "yes" if row["completed_at"] else "",
        )
    console.print(table)


def _print_interactions(rows) -> None:
    table = Table("ID", "When", "Kind", "Channel", "Who", "Note")
    for row in rows:
        table.add_row(
            str(row["id"]),
            row["occurred_at"] or "",
            row["kind"] or "",
            row["channel"] or "",
            row["contact_name"] or row["organization_name"] or "",
            _clip(row["body"], 90),
        )
    console.print(table)


def _clip(value: str, length: int) -> str:
    return value if len(value) <= length else f"{value[: length - 1]}..."
