# Splatlogger (c) 2025 Shadow Doggo.

import argparse
import ipaddress
import os
import sys
import time
import webbrowser
from datetime import datetime
from typing import NamedTuple
from xml.etree import ElementTree

import requests
import userpaths  # type: ignore[import-untyped]

from .cemu_gecko import CemuGecko, CemuGeckoException
from .data import Pointers, Offsets, PlayerInfo
from .match_logger import MatchLogger
from .tcpgecko import TCPGecko, TCPGeckoException
from .tcpgecko_aroma import TCPGeckoAroma

_VERSION = "1.6.2"


class Options(NamedTuple):
    log_level: str
    auto_logging: bool
    log_latest: bool
    silent_logging: bool
    aroma: bool
    cemu: bool
    stack: int | None


class AccountInfo(NamedTuple):
    pnid: str
    mii_name: str
    request_error: str


def main() -> None:
    print(f"Splatlogger v{_VERSION} by Shadow Doggo\n")

    parser = argparse.ArgumentParser(description="A CLI PID (Principal ID)/PNID grabber and match logger for Splatoon.")
    parser.add_argument("-ip", help="Your Wii U's LAN IP address.")
    parser.add_argument("-log-level", help="Set how much data should be logged (see README).",
                        choices=["none", "standard", "extended", "stats"], default="standard")
    parser.add_argument("-auto",
                        help="Enable auto logging (see README).",
                        choices=["all", "latest"], nargs="?", const="all")
    parser.add_argument("-aroma", help="Switch to Aroma mode. Enable if using the TCPGecko Aroma plugin.",
                        action="store_true")
    parser.add_argument("-cemu",
                        help="Switch to Cemu mode (optional: PID of the Cemu process).", metavar="PID",
                        nargs="?", const=-1)
    parser.add_argument("-stack",
                        help="Beginning address of the stack space for Default Core 1 (Cemu only, see README).",
                        metavar="Address (in hex)")
    parser.add_argument("-silent", help="Disable printing logs to the console.", action="store_true")

    if os.path.isfile(os.path.join(userpaths.get_my_documents(), "Splatlogger/args.txt")):
        with open((os.path.join(userpaths.get_my_documents(), "Splatlogger/args.txt")), encoding="utf-8") as f:
            args = parser.parse_args(f.read().split())
    else:
        args = parser.parse_args()

    if len(sys.argv) == 1:
        print('No arguments were provided. Run "splatlogger -h" for help.')
        print("Would you like to open the README? (y/n)")
        if input().lower() in ("y", "yes"):
            webbrowser.open("https://codeberg.org/ShadowDoggo/Splatlogger/src/branch/main/README.md")

        sys.exit()

    if args.aroma and args.cemu:
        print("Cannot use both Aroma and Cemu modes.")
        sys.exit()

    stack_addr: int | None = None
    if args.stack:
        try:
            stack_addr = int(args.stack, 16)
        except ValueError:
            print("Invalid stack address. Please provide a valid hex value.")
            sys.exit()

    options = Options(log_level=args.log_level,
                      auto_logging=args.auto in ("all", "latest"),
                      log_latest=args.auto == "latest",
                      silent_logging=args.silent,
                      aroma=args.aroma,
                      cemu=args.cemu is not None,
                      stack=stack_addr)

    ptr_offset = 0
    gecko: TCPGecko | TCPGeckoAroma | CemuGecko
    if args.cemu:
        ptr_offset = 0x503000
        try:
            print("Opening Cemu process...")
            gecko = CemuGecko(int(args.cemu))
        except CemuGeckoException as e:
            print(e)
            sys.exit()
    else:
        try:
            ipaddress.ip_address(args.ip)
            print(f"Connecting to: {args.ip}")
            gecko = TCPGeckoAroma(args.ip) if options.aroma else TCPGecko(args.ip)
        except ValueError:
            print("Please provide a valid IP address.")
            sys.exit()
        except TCPGeckoException as e:
            print(e)
            sys.exit()

    for _ in range(3):
        try:
            static_mem_adr = gecko.peek32(Pointers.STATIC_MEM - ptr_offset)
            player_info_ary_adr = gecko.peek32(static_mem_adr + Offsets.STATICMEM_PLAYER_INFO_ARY)
            assert static_mem_adr != 0 and player_info_ary_adr != 0

            print("Success.\n" if options.cemu else "Connected.\n")
            break
        except (OSError, TimeoutError, TCPGeckoException) as e:
            print(f"\nAn error has occurred: {e}\nRetrying in 10 seconds...")
            time.sleep(10)
        except AssertionError:
            print("\nCould not find StaticMem and PlayerInfoAry address.\nRetrying in 10 seconds...")
            time.sleep(10)
    else:
        print("\nFailed after 3 tries.")
        sys.exit()

    match_logger: MatchLogger | None = None
    if options.log_level != "none":
        match_logger = MatchLogger(gecko, options.log_level, options.auto_logging, options.aroma,
                                   options.cemu, options.stack, static_mem_adr)
        try:
            match_logger.create_new_log()
        except OSError as e:
            print(f"Failed to create log file: {e}")
            sys.exit()

    if options.auto_logging and match_logger:
        print("Auto logging enabled.")
        _auto_log(options, gecko, match_logger, player_info_ary_adr)

    for _ in range(3):
        try:
            _splatlog(options, gecko, match_logger, player_info_ary_adr, match_count=1)
            break
        except (OSError, TimeoutError, TCPGeckoException) as e:
            print(f"\nAn error has occurred: {e}\nRetrying in 10 seconds...")
            time.sleep(10)
    else:
        print("\nFailed after 3 tries.")
        sys.exit()


def _auto_log(options: Options, gecko: TCPGecko | CemuGecko, match_logger: MatchLogger,
              player_info_ary_adr: int) -> None:
    match_in_progress = False
    count = 0
    retry_count = 0
    ptr_offset = 0x503000 if options.cemu else 0
    while True:
        try:
            main_mgr_vs_game_adr = gecko.peek32(Pointers.MAIN_MGR_VS_GAME - ptr_offset)
            if main_mgr_vs_game_adr == 0:
                match_in_progress = False

            if not match_in_progress and main_mgr_vs_game_adr != 0:  # Trigger logging when a VS match is loaded.
                match_in_progress = True
                count += 1

                if options.log_latest:
                    match_logger.create_new_log()

                if not options.silent_logging:
                    print(f"\nMatch {count}\n")

                time.sleep(1)

                for _ in range(3):
                    try:
                        _splatlog(options, gecko, match_logger, player_info_ary_adr, count)
                        break
                    except (OSError, TimeoutError, TCPGeckoException) as e:
                        print(f"\nAn error has occurred: {e}\nRetrying in 10 seconds...")
                        time.sleep(10)
                else:
                    print("\nFailed after 3 tries.")
                    sys.exit()

            retry_count = 0
            time.sleep(10)
        except KeyboardInterrupt:
            print("\nExiting.")
            sys.exit()
        except (OSError, TimeoutError, TCPGeckoException) as e:
            if retry_count < 3:
                print(f"\nAn error has occurred: {e}\nRetrying in 10 seconds...")
                retry_count += 1
                time.sleep(10)
            else:
                print("\nFailed after 3 tries.")
                sys.exit()


def _splatlog(options: Options, gecko: TCPGecko | CemuGecko, match_logger: MatchLogger | None,
              player_info_ary_adr: int, match_count: int) -> None:
    session_id = 0
    player_count = 8
    request_errors: list[str] = []
    player_info_list: list[PlayerInfo] = []
    date = datetime.now()
    ptr_offset = 0x503000 if options.cemu else 0

    session_adr = gecko.peek32(Pointers.SESSION - ptr_offset)
    if session_adr != 0:
        session_id_idx = int.from_bytes(gecko.peek_raw(session_adr + Offsets.SESSION_ID_IDX,
                                                       length=1), byteorder="big")
        session_id = gecko.peek32(session_adr + session_id_idx * 4 + Offsets.SESSION_ID)

    main_mgr_base_adr = gecko.peek32(Pointers.MAIN_MGR_BASE - ptr_offset)
    if main_mgr_base_adr != 0 and gecko.peek8(Pointers.MAIN_MGR_VS_GAME - ptr_offset) != 0:
        player_mgr_adr = gecko.peek32(main_mgr_base_adr + Offsets.MAINMGR_PLAYER_MGR)
        if player_mgr_adr != 0:
            player_count = gecko.peek8(player_mgr_adr + Offsets.PLAYERMGR_PLAYER_COUNT)
    else:
        print("You are currently not in a match. Logging previous match data "
              "(Player 1 data will be your own, Session ID will be the current one).\n")

    print(f"{'Player':<8} | {'PID (Hex)':<10} | {'PID (Dec)':<10} | {'PNID':<16} | Name\n"
          f"{'-' * 73}")

    for player_idx in range(player_count):
        player_info_raw = gecko.peek_raw(gecko.peek32(player_info_ary_adr + player_idx * 0x4),
                                         length=0xD4)

        player_pid = int.from_bytes(player_info_raw[0xD0:0xD4], byteorder="big")
        if player_pid != 0:
            player_name = (player_info_raw[0x6:0x26]
                           .decode("utf-16-be")
                           .split("\u0000")[0]
                           .replace("\n", "")
                           .replace("\r", ""))

            act_info = _get_act_info(player_pid)
            if act_info.request_error != "":
                request_errors.append(act_info.request_error)

            if options.log_level != "none":
                player_info = PlayerInfo(
                    idx=player_idx,
                    pid=player_pid,
                    pnid=act_info.pnid,
                    name=player_name,
                    mii_name=act_info.mii_name,
                    team=int.from_bytes(player_info_raw[0x33:0x34], byteorder="big"),
                    gender=int.from_bytes(player_info_raw[0x37:0x38], byteorder="big"),
                    skin_tone=int.from_bytes(player_info_raw[0x3B:0x3C], byteorder="big"),
                    eye_color=int.from_bytes(player_info_raw[0x3F:0x40], byteorder="big"),
                    weapon=int.from_bytes(player_info_raw[0x46:0x48], byteorder="big"),
                    sub_weapon=int.from_bytes(player_info_raw[0x4A:0x4C], byteorder="big"),
                    special_weapon=int.from_bytes(player_info_raw[0x4D:0x50], byteorder="big"),
                    shoes=int.from_bytes(player_info_raw[0x54:0x58], byteorder="big"),
                    clothes=int.from_bytes(player_info_raw[0x70:0x74], byteorder="big"),
                    headgear=int.from_bytes(player_info_raw[0x8C:0x90], byteorder="big"),
                    level=int.from_bytes(player_info_raw[0xAF:0xB0], byteorder="big", signed=True) + 1,
                    rank=int.from_bytes(player_info_raw[0xB3:0xB4], byteorder="big", signed=True)
                )
                player_info_list.append(player_info)

            if not options.silent_logging:
                print(f"Player {player_idx + 1} | "
                      f"0x{f'{player_pid:X}':<8} | "
                      f"{player_pid:<10} | "
                      f"{act_info.pnid:<16} | "
                      f"{player_name} {f'({act_info.mii_name})' if player_name != act_info.mii_name else ''}")

    if not options.silent_logging:
        print()
        if request_errors:
            print("Failed to get account data for one or more players: "
                  f"{'; '.join(request_errors)}\n")

        if session_id != 0:
            print(f"Session ID: 0x{session_id:X} ({session_id})")
        else:
            print("Session ID: None")

        print(f"Fetched at: {date.strftime('%Y-%m-%d %H:%M:%S')}")

    if options.log_level != "none" and match_logger:
        match_logger.log_match(date, session_id, match_count, player_info_list)


def _get_act_info(player_pid: int) -> AccountInfo:
    pnid = ""
    mii_name = ""
    request_error = ""

    for _ in range(3):
        try:
            response = requests.get(
                f"https://account.pretendo.cc/v1/api/miis?pids={player_pid}",
                headers={"X-Nintendo-Client-ID": "a2efa818a34fa16b8afbc8a74eba3eda",
                         "X-Nintendo-Client-Secret": "c91cdb5658bd4954ade78533a339cf9a"},
                timeout=5
            )

            try:
                root = ElementTree.fromstring(response.text)
            except ElementTree.ParseError:
                return AccountInfo("", "", "Got empty or invalid response.")

            if not (isinstance(root[0].find("user_id"), ElementTree.Element) and
                    isinstance(root[0].find("name"), ElementTree.Element)):
                return AccountInfo("", "", "Got empty or invalid response.")

            pnid = root[0].find("user_id").text  # type: ignore
            mii_name = (root[0].find("name")  # type: ignore
                               .text
                               .replace("\n", "")
                               .replace("\r", ""))
            break
        except (requests.HTTPError, AssertionError) as ex:
            request_error = str(ex)
            time.sleep(1)

    return AccountInfo(pnid, mii_name, request_error)


if __name__ == "__main__":
    main()
