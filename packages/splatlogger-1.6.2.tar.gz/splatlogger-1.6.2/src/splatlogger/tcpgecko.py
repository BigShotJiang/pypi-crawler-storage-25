# Copyright (c) 2015 wiiudev
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.

# Splatlogger (c) 2025 Shadow Doggo.
# This is a modified, stripped-down version of pyGecko's tcpgecko.py.

import socket
import struct


class TCPGecko:
    """Python library for use with TCPGecko."""
    def __init__(self, ip: str, *, port: int=7331, timeout: int=10) -> None:
        self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP)
        self._socket.settimeout(timeout)
        try:
            self._socket.connect((ip, port))
        except (OSError, TimeoutError) as e:
            raise TCPGeckoException(f"Failed to connect: {e}") from e

    def peek_raw(self, address: int, length: int) -> bytes:
        """Read raw memory starting at address and ending at address + length.
        Returns a bytes object.
        """
        if length == 0:
            raise TCPGeckoException("Reading memory requires a length (# of bytes).")

        if not self._valid_range(address, length):
            raise TCPGeckoException(f"Address 0x{address:X} is outside the valid range.")

        if not self._valid_access(address, length, access="read"):
            raise TCPGeckoException(f"Cannot read from address 0x{address:X}.")

        ret = b""
        if length > 1024:  # Read in chunks if length is over 1024 bytes.
            for _ in range(length // 1024):  # Number of blocks, ignores extra.
                if length > 1024:
                    ret += self._peek_request(address, length=1024)

                    address += 1024
                    length -= 1024
                else:
                    ret += self._peek_request(address, length)
        else:
            ret = self._peek_request(address, length)

        return ret

    def peek8(self, address: int, *, signed: bool=False) -> int:
        """Get an 8-bit integer value stored at the specified address."""
        return int.from_bytes(self.peek_raw(address + 3, length=1), byteorder="big", signed=signed)

    def peek16(self, address: int, *, signed: bool=False) -> int:
        """Get a 16-bit integer value stored at the specified address."""
        return int.from_bytes(self.peek_raw(address + 2, length=2), byteorder="big", signed=signed)

    def peek32(self, address: int, *, signed: bool=False) -> int:
        """Get a 32-bit integer value stored at the specified address."""
        return int.from_bytes(self.peek_raw(address, length=4), byteorder="big", signed=signed)

    def peek_float(self, address: int) -> float:
        """Get a floating point value stored at the specified address."""
        return struct.unpack(">f", self.peek_raw(address, length=4))[0]

    def read_string(self, address: int, length: int=1, encoding: str="utf-8") -> str:
        """Read a string of text starting at the specified address."""
        return self.peek_raw(address, length).decode(encoding)

    def _peek_request(self, address: int, length: int) -> bytes:
        self._socket.send(b"\x04")
        request = struct.pack(">II", address, address + length)
        self._socket.send(request)

        status = self._socket.recv(1)
        if status == b"\xbd":
            return self._socket.recv(length)
        if status == b"\xb0":
            return b"\x00" * length

        raise TCPGeckoException("Failed to read memory.")

    @staticmethod
    def _valid_range(address: int, length: int) -> bool:
        end_address = address + length

        if 0x01000000 <= address and end_address <= 0x01800000:
            return True
        if 0x0E000000 <= address and end_address <= 0x10000000:  # Depends on the game.
            return True
        if 0x10000000 <= address and end_address <= 0x50000000:  # Doesn't quite go to 5.
            return True
        if 0xE0000000 <= address and end_address <= 0xE4000000:
            return True
        if 0xE8000000 <= address and end_address <= 0xEA000000:
            return True
        if 0xF4000000 <= address and end_address <= 0xF6800000:
            return True
        if 0xF8000000 <= address and end_address <= 0xFB800000:
            return True
        if 0xFFFE0000 <= address and end_address <= 0xFFFFFFFF:
            return True

        return False

    @staticmethod
    def _valid_access(address: int, length: int, access: str) -> bool:
        end_address = address + length

        if 0x01000000 <= address and end_address <= 0x01800000:
            if access == "read":  return True
            if access == "write": return False
            return False
        if 0x0E000000 <= address and end_address <= 0x10000000:  # Depends on the game, may be EG 0x0E3.
            if access == "read":  return True
            if access == "write": return False
            return False
        if 0x10000000 <= address and end_address <= 0x50000000:
            if access == "read":  return True
            if access == "write": return True
            return False
        if 0xE0000000 <= address and end_address <= 0xE4000000:
            if access == "read":  return True
            if access == "write": return False
            return False
        if 0xE8000000 <= address and end_address <= 0xEA000000:
            if access == "read":  return True
            if access == "write": return False
            return False
        if 0xF4000000 <= address and end_address <= 0xF6000000:
            if access == "read":  return True
            if access == "write": return False
            return False
        if 0xF6000000 <= address and end_address <= 0xF6800000:
            if access == "read":  return True
            if access == "write": return False
            return False
        if 0xF8000000 <= address and end_address <= 0xFB000000:
            if access == "read":  return True
            if access == "write": return False
            return False
        if 0xFB000000 <= address and end_address <= 0xFB800000:
            if access == "read":  return True
            if access == "write": return False
            return False
        if 0xFFFE0000 <= address and end_address <= 0xFFFFFFFF:
            if access == "read":  return True
            if access == "write": return True
            return False

        return False


class TCPGeckoException(Exception): pass
