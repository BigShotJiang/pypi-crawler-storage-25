"""Chat agent loop with OpenAI-compatible NVIDIA NIM tools API."""

from __future__ import annotations

import getpass
import os
from pathlib import Path
from typing import Any

from openai import APIStatusError, OpenAI

from mahanai import colors as C
from mahanai.config import (
    clear_saved_api_key,
    config_file_path,
    resolve_api_key,
    save_api_key,
)
from mahanai.system_info import describe_runtime
from mahanai.tools import TOOLS, execute_tool, normalize_tool_arguments_json

NVIDIA_BASE_URL = "https://integrate.api.nvidia.com/v1"
# Use the exact id from GET https://integrate.api.nvidia.com/v1/models (dots, not underscores).
DEFAULT_MODEL = "nvidia/nemotron-nano-12b-v2-vl"

_STARTUP_ASCII = r"""
================================================================

███╗   ███╗ █████╗ ██╗  ██╗ █████╗ ███╗   ██╗ █████╗ ██╗
████╗ ████║██╔══██╗██║  ██║██╔══██╗████╗  ██║██╔══██╗██║
██╔████╔██║███████║███████║███████║██╔██╗ ██║███████║██║
██║╚██╔╝██║██╔══██║██╔══██║██╔══██║██║╚██╗██║██╔══██║██║
██║ ╚═╝ ██║██║  ██║██║  ██║██║  ██║██║ ╚████║██║  ██║██║
╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝     
          
================================================================
  Finale 1.0  |  NVIDIA NIM  |  /api-key to save key (persists)
  Replies stream live (MAHANAI_STREAM=0 to wait for full text)
  /help  /exit  /quit
================================================================
""".strip(
    "\n"
)


def _streaming_enabled() -> bool:
    v = os.environ.get("MAHANAI_STREAM", "1").strip().lower()
    return v not in ("0", "false", "no", "off")


def _tool_calls_from_stream(stream: Any) -> tuple[str, list[dict[str, Any]]]:
    """Print token deltas to stdout; return (full_text, tool_calls or [])."""
    content_parts: list[str] = []
    tc_acc: dict[int, dict[str, str]] = {}

    for chunk in stream:
        if not chunk.choices:
            continue
        ch = chunk.choices[0]
        d = ch.delta
        if d.content:
            print(d.content, end="", flush=True)
            content_parts.append(d.content)
        if d.tool_calls:
            for tc in d.tool_calls:
                idx = tc.index
                if idx not in tc_acc:
                    tc_acc[idx] = {"id": "", "name": "", "arguments": ""}
                if tc.id:
                    tc_acc[idx]["id"] = tc.id
                if tc.function:
                    if tc.function.name:
                        tc_acc[idx]["name"] = tc.function.name
                    if tc.function.arguments:
                        tc_acc[idx]["arguments"] += tc.function.arguments

    full = "".join(content_parts)
    if not tc_acc:
        return full, []

    tool_calls_list: list[dict[str, Any]] = []
    for idx in sorted(tc_acc.keys()):
        t = tc_acc[idx]
        tool_calls_list.append(
            {
                "id": t["id"],
                "type": "function",
                "function": {
                    "name": t["name"],
                    "arguments": t["arguments"] or "{}",
                },
            }
        )
    return full, tool_calls_list


def run_turn(
    client: OpenAI,
    model: str,
    messages: list[dict[str, Any]],
    workspace: Path,
    max_tool_rounds: int = 32,
    *,
    stream: bool | None = None,
) -> str:
    use_stream = _streaming_enabled() if stream is None else stream
    rounds = 0
    while rounds < max_tool_rounds:
        rounds += 1
        if use_stream:
            api_stream = client.chat.completions.create(
                model=model,
                messages=messages,
                tools=TOOLS,
                tool_choice="auto",
                parallel_tool_calls=False,
                stream=True,
            )
            full_content, tool_calls_list = _tool_calls_from_stream(api_stream)
        else:
            response = client.chat.completions.create(
                model=model,
                messages=messages,
                tools=TOOLS,
                tool_choice="auto",
                parallel_tool_calls=False,
            )
            msg = response.choices[0].message
            full_content = msg.content or ""
            if msg.tool_calls:
                print(full_content, end="", flush=True)
                tool_calls_list = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.function.name,
                            "arguments": tc.function.arguments or "{}",
                        },
                    }
                    for tc in msg.tool_calls
                ]
            else:
                print(full_content, end="", flush=True)
                return full_content

        if not tool_calls_list:
            return full_content

        for tc in tool_calls_list:
            fn = tc["function"]
            fn["arguments"] = normalize_tool_arguments_json(fn.get("arguments") or "")

        assistant_msg: dict[str, Any] = {
            "role": "assistant",
            "tool_calls": tool_calls_list,
        }
        if full_content:
            assistant_msg["content"] = full_content
        messages.append(assistant_msg)

        if use_stream:
            print(flush=True)

        for tc in tool_calls_list:
            fn = tc["function"]
            result = execute_tool(fn["name"], fn["arguments"], workspace)
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tc["id"],
                    "content": result,
                }
            )

        if not use_stream:
            print(flush=True)

    limit_msg = (
        "[MahanAI] Stopped after maximum tool rounds; "
        "last messages may still be useful in context."
    )
    print(limit_msg, end="", flush=True)
    return limit_msg


def build_system_prompt(workspace: Path) -> str:
    env_line = describe_runtime()
    comspec = os.environ.get("ComSpec", "cmd.exe")
    return (
        "You are MahanAI, a capable coding and system assistant (Finale 1.0). "
        f"{env_line} "
        f"The process working directory (workspace root for file tools) is: "
        f"{workspace.resolve().as_posix()}. "
        "To run shell commands you MUST call the run_command tool—do not only show fenced code blocks "
        "or ask the user whether to run something. Execute immediately with the tool (one short sentence "
        "beforehand is fine). "
        f"run_command uses the system shell (on Windows this is usually {comspec} via COMSPEC), "
        "not interactive PowerShell unless you invoke it explicitly, e.g. "
        "powershell -NoProfile -Command \"New-Item -ItemType Directory -Force -Path 'dir\\\\sub'\". "
        "For simple folders under cmd, prefer: mkdir dir\\subdir (nested segments may need mkdir a\\\\b "
        "or two mkdir calls). "
        "Use read_file, write_file, list_directory, append_file when they fit the task. "
        "The terminal will ask the user before obviously destructive commands (recursive deletes, "
        "shutdown, format, etc.). "
        "Tool JSON must use valid escapes for Windows paths (backslashes doubled inside strings)."
    )


def _slash_command(line: str) -> tuple[str, str]:
    u = line.strip()
    if not u.startswith("/"):
        return "", ""
    tail = u[1:].strip()
    if not tail:
        return "/", ""
    parts = tail.split(None, 1)
    cmd = "/" + parts[0].lower()
    arg = parts[1].strip() if len(parts) > 1 else ""
    return cmd, arg


def _print_help() -> None:
    cfg = config_file_path()
    print(
        f"{C.DIM}"
        f"  /api-key [key]   Save NVIDIA API key to {cfg}\n"
        f"  /api-key         Prompt for key (hidden input)\n"
        f"  /api-key clear   Remove saved key from disk\n"
        f"  Env MAHANAI_API_KEY overrides the saved file.\n"
        f"  /help  /exit  /quit{C.RST}\n"
    )


def main() -> None:
    workspace = Path.cwd()
    api_key = resolve_api_key()
    client: OpenAI | None = (
        OpenAI(base_url=NVIDIA_BASE_URL, api_key=api_key) if api_key else None
    )

    system_prompt = build_system_prompt(workspace)
    history: list[dict[str, Any]] = [{"role": "system", "content": system_prompt}]

    print(f"{C.BANNER}{_STARTUP_ASCII}{C.RST}\n")
    if not api_key:
        print(
            f"{C.ERR}No API key yet.{C.RST} Use {C.OK}/api-key{C.RST} or set "
            f"{C.DIM}MAHANAI_API_KEY{C.RST} / .env\n"
        )

    model = os.environ.get("MAHANAI_MODEL", DEFAULT_MODEL)

    while True:
        try:
            print(f"{C.USER}You{C.RST}: ", end="", flush=True)
            user = input().strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not user:
            continue
        if user.lower() in {"exit", "quit"}:
            break

        if user.startswith("/"):
            cmd, rest = _slash_command(user)
            if cmd in {"/exit", "/quit"}:
                break
            if cmd == "/help":
                _print_help()
                continue
            if cmd == "/api-key":
                sub = rest.strip().lower()
                if sub == "clear":
                    clear_saved_api_key()
                    print(f"{C.OK}Saved API key removed from disk.{C.RST}")
                    api_key = resolve_api_key()
                    client = (
                        OpenAI(base_url=NVIDIA_BASE_URL, api_key=api_key)
                        if api_key
                        else None
                    )
                    continue
                new_key = rest.strip() if rest.strip() else getpass.getpass("API key: ").strip()
                if not new_key:
                    print(f"{C.ERR}Empty key; nothing saved.{C.RST}")
                    continue
                save_api_key(new_key)
                os.environ["MAHANAI_API_KEY"] = new_key
                client = OpenAI(base_url=NVIDIA_BASE_URL, api_key=new_key)
                print(
                    f"{C.OK}API key saved to{C.RST} {C.DIM}{config_file_path()}{C.RST}\n"
                )
                continue
            print(f"{C.ERR}Unknown command.{C.RST} Try {C.DIM}/help{C.RST}\n")
            continue

        if client is None:
            print(
                f"{C.ERR}Set an API key first:{C.RST} {C.OK}/api-key{C.RST} or "
                f"{C.DIM}MAHANAI_API_KEY{C.RST}\n"
            )
            continue

        history.append({"role": "user", "content": user})
        print(f"\n{C.BOT}MahanAI{C.RST}: ", end="", flush=True)
        try:
            reply = run_turn(client, model, history, workspace)
        except APIStatusError as e:
            print()
            err = str(e)
            if getattr(e, "status_code", None) == 404:
                err += (
                    "\nIf this says 'page not found', check MAHANAI_MODEL: NVIDIA lists exact "
                    "names at GET /v1/models (e.g. deepseek-ai/deepseek-v3.2 uses dots, not v3_2)."
                )
            print(f"{C.ERR}[MahanAI API error]{C.RST} {err}\n")
            history.pop()
            continue
        print("\n")
        history.append({"role": "assistant", "content": reply})
