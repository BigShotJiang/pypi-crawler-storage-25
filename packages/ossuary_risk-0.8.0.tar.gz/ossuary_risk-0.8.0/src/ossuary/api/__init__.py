"""API module for ossuary."""
