# mnemo-brain-mcp

MCP (Model Context Protocol) bridge to query your [Mnemo](https://github.com/komrxn/Khusayinbek_brain) second brain from **Claude Code**, **Cursor**, **Cline**, **Windsurf**, and any MCP-compatible AI tool.

## What is this?

This is a friendly fork of [`desimpkins/daniel-lightrag-mcp`](https://github.com/desimpkins/daniel-lightrag-mcp). The protocol logic is identical; the package is renamed for one reason: a clean PyPI install for [Mnemo](https://github.com/komrxn/Khusayinbek_brain) users.

If you're using a standalone LightRAG server (not Mnemo), the upstream package works fine — and you'll get upstream's updates faster.

## Install

```bash
pip install mnemo-brain-mcp
```

After install the `mnemo-brain-mcp` command is on your `PATH`.

## Configure

Point the bridge at your local LightRAG-API server (Mnemo runs it at `127.0.0.1:9621` by default):

### Claude Code

Edit `~/.claude/claude_mcp_config.json` (or run `claude mcp add`):

```json
{
  "mcpServers": {
    "mnemo-brain": {
      "command": "mnemo-brain-mcp",
      "env": {
        "LIGHTRAG_BASE_URL": "http://localhost:9621",
        "LIGHTRAG_API_KEY": "<paste contents of secrets/lightrag_api_key.txt>"
      }
    }
  }
}
```

Restart Claude Code. Try:

> *"What does my brain know about my current projects?"*

### Cursor

`Settings → MCP → Add new MCP server`. Same JSON shape as above.

### Cline / Windsurf

See their docs for the `mcpServers` config location — the JSON shape is the same.

## What this gives you

22 tools over MCP, including:

| Tool | Purpose |
| --- | --- |
| `query_text` / `query_text_stream` | Hybrid semantic + graph search |
| `get_knowledge_graph` | Subgraph around a label |
| `get_graph_labels` | All entity labels |
| `check_entity_exists` | Quick existence probe |
| `get_documents` | List indexed sources |
| `get_health` | Server health |
| `insert_text` / `update_entity` / `delete_document` / ... | Write operations (be careful — see below) |

For the full tool list see the upstream docs in the [`archive/`](archive/) directory.

## Security note

This bridge exposes write tools (`insert_text`, `update_entity`, `delete_document`, ...). Granting your coding tool access to this MCP server **grants it write access** to the LightRAG knowledge graph.

For Mnemo specifically: the canonical writer to your Obsidian vault is the Telegram bot. Anything an MCP client `insert_text`'s into the graph lives **only in the LightRAG index**, not in your Markdown notes. To write to your vault, message the bot.

## Credit

Original code by [@desimpkins](https://github.com/desimpkins). Renamed and republished with thanks. MIT-licensed both upstream and here.

## License

MIT.
