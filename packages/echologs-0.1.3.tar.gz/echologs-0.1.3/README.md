# echologs

Monitoring and observability for Python automation scripts.

Every execution logged. Every error captured. Get instant alerts when your scripts break.

## Install
```bash
pip install echologs
```

## Quickstart
```python
from dotenv import load_dotenv
load_dotenv()
import echologs

with echologs.run():
    # your existing code — nothing changes
    print("Hello from EchoLogs!")
```

Set `ECHOLOGS_API_KEY` in your `.env` file. Get your key at [app.echologs.com](https://app.echologs.com).

## What it does

- Logs every execution with duration, stdout, stderr and status
- Sends email or Slack alerts instantly on failure
- Shows pass rate and failure streaks in your dashboard
- Zero changes to your existing code

## Links

- Dashboard: [app.echologs.com](https://app.echologs.com)
- Docs: [app.echologs.com/docs](https://app.echologs.com/docs)
- npm (JavaScript): [npmjs.com/package/echologs](https://npmjs.com/package/echologs)