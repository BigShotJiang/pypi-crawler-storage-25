import os
from .client import EchoLogsClient
from .monitor import _monitor_context
import functools

_client = None

def _get_client():
    global _client
    if _client is None and (key := os.environ.get("ECHOLOGS_API_KEY")):
        _client = EchoLogsClient(api_key=key)
    return _client

def init(api_key=None):
    global _client
    key = api_key or os.environ.get("ECHOLOGS_API_KEY")
    if not key:
        raise ValueError("No API key. Pass it to init() or set ECHOLOGS_API_KEY.")
    _client = EchoLogsClient(api_key=key)

def run(name=None):
    client = _get_client()
    if client is None:
        raise RuntimeError("EchoLogs not initialised. Set ECHOLOGS_API_KEY or call init() first.")
    return _monitor_context(client=client, name=name)

def monitor(name=None):
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            with run(name=name or fn.__name__):
                return fn(*args, **kwargs)
        return wrapper

    if callable(name):
        fn, name_ = name, None
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            with run(name=fn.__name__):
                return fn(*args, **kwargs)
        return wrapper

    return decorator