import sys
import io
import time
import inspect
import os
import traceback
from contextlib import contextmanager

# Patterns that indicate a file is NOT the user's script
_SKIP_PATTERNS = [
    'echologs',
    'site-packages',
    'contextlib',
    'functools',
    'importlib',
    'runpy',
    'threading',
    '_bootstrap',
    os.path.dirname(os.__file__),  # Python stdlib folder on this machine
]


def _get_caller_filename():
    """
    Walk up the call stack to find the actual user script file.
    Skips echologs internals, stdlib modules, and site-packages.
    """
    for frame_info in inspect.stack():
        filename = frame_info.filename

        # Skip anonymous/internal frames
        if filename.startswith('<'):
            continue

        # Skip anything matching known internal patterns
        if any(pattern in filename for pattern in _SKIP_PATTERNS):
            continue

        # This is the user's file
        return os.path.splitext(os.path.basename(filename))[0]

    return 'unknown'


class _StreamCapture(io.StringIO):
    """
    Wraps sys.stdout or sys.stderr.
    Passes all writes through to the real stream so the developer
    still sees their output in the terminal, while also capturing
    everything for sending to EchoLogs.
    """
    def __init__(self, real_stream):
        super().__init__()
        self._real = real_stream

    def write(self, data):
        self._real.write(data)  # pass through — terminal still shows output
        super().write(data)     # capture for EchoLogs

    def flush(self):
        self._real.flush()


@contextmanager
def _monitor_context(client, name=None):
    """
    Core monitoring context manager.
    Captures stdout, stderr, timing, and errors automatically.
    Re-raises any exception after capturing it so the user's
    own error handling still works normally.
    """
    script_name = name or _get_caller_filename()

    # Replace stdout and stderr with capturing wrappers
    out_capture = _StreamCapture(sys.stdout)
    err_capture = _StreamCapture(sys.stderr)
    sys.stdout  = out_capture
    sys.stderr  = err_capture

    start      = time.time()
    status     = 'pass'
    error_text = None

    try:
        yield  # run the user's code block

    except Exception:
        status     = 'fail'
        error_text = traceback.format_exc()
        raise      # always re-raise — never swallow user exceptions

    finally:
        # Restore streams first — must happen even if send() fails
        sys.stdout = out_capture._real
        sys.stderr = err_capture._real

        duration_ms = round((time.time() - start) * 1000)

        stdout_val = out_capture.getvalue() or None
        stderr_val = err_capture.getvalue() or None

        # Send to EchoLogs — swallows its own errors so it
        # never crashes the user's script
        client.send(
            script_name = script_name,
            status      = status,
            stdout      = stdout_val,
            stderr      = stderr_val,
            error       = error_text,
            duration_ms = duration_ms,
        )