import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "proto"))

import grpc
import qubecore_pb2
import qubecore_pb2_grpc


class QubeClient:

    def __init__(self, host: str = "localhost", port: int = 50051) -> None:
        self._channel = grpc.insecure_channel(f"{host}:{port}")
        self._stub = qubecore_pb2_grpc.QubeCoreStub(self._channel)

    def submit_gate_job(
        self,
        backend_name: str,
        gate_circuits: list[str],
        shots: int,
        priority: int | None = None,
        optimization_level: int | None = None,
    ) -> str:
        request = qubecore_pb2.SubmitGateJobRequest(
            backend_name=backend_name,
            gate_circuits=gate_circuits,
            shots=shots,
        )
        if priority is not None:
            request.priority = priority
        if optimization_level is not None:
            request.optimization_level = optimization_level

        resp = self._stub.SubmitGateJob(request)
        if not resp.success:
            raise RuntimeError(resp.message)
        return resp.job_id

    def get_job_status(self, job_id: str) -> dict:
        resp = self._stub.GetJobStatus(qubecore_pb2.JobRequest(job_id=job_id))
        if not resp.found:
            raise ValueError(resp.message)
        return {
            "job_id":       resp.job_id,
            "status":       resp.status,
            "priority":     resp.priority,
            "submitted_at": resp.submitted_at,
            "started_at":   resp.started_at,
            "finished_at":  resp.finished_at,
            "error":        resp.error,
        }

    def get_job_result(self, job_id: str) -> dict:
        resp = self._stub.GetJobResult(qubecore_pb2.JobRequest(job_id=job_id))
        if not resp.found:
            raise ValueError(resp.message)
        return {
            "job_id":  resp.job_id,
            "status":  resp.status,
            "results": [
                {
                    "counts_json":        r.counts_json,
                    "s11_json":           r.s11_json,
                    "qubit_mapping_json": r.qubit_mapping_json,
                }
                for r in resp.results
            ],
        }

    def cancel_job(self, job_id: str) -> str:
        resp = self._stub.CancelJob(qubecore_pb2.JobRequest(job_id=job_id))
        if not resp.success:
            raise RuntimeError(resp.message)
        return resp.message

    def close(self) -> None:
        self._channel.close()

    def __enter__(self) -> "QubeClient":
        return self

    def __exit__(self, *args) -> None:
        self.close()
