# QubeCore-Client

Python client SDK for QubeCore — Quantum Computing Operating System.

## Overview

QubeCore Client provides a Python-friendly interface for communicating
with QubeCore Server over gRPC. QubeCli, QubeLab, and QubeGate all
depend on this package.

## Requirements

- Python 3.11+
- QubeCore Server

## Installation

```bash
pip install qubecore-client
```

## Quick Start

```python
from qubecore_client import QubeClient

client = QubeClient(host="localhost", port=50051)

    # Submit a job
    job_id = client.submit_gate_job(
        backend_name="backend1",
        gate_circuits=[
            "OPENQASM 2.0;\ninclude \"qelib1.inc\";\nqreg q[2];\ncreg c[2];\nh q[0];\ncx q[0],q[1];\nmeasure q -> c;"
        ],
        shots=100,
    )
    print("job_id:", job_id)

    # Check status
    status = client.get_job_status(job_id)
    print("status:", status["status"])

    # Fetch result
    result = client.get_job_result(job_id)
    print("result:", result)

    # Cancel job (only possible while status is PENDING)
    message = client.cancel_job(job_id)
    print("cancel:", message)
```

## API

| Method | Description |
|--------|------|
| `submit_gate_job()` | Submits a gate-circuit execution job and returns a `job_id` |
| `get_job_status()` | Retrieves the current job status |
| `get_job_result()` | Retrieves the job result |
| `cancel_job()` | Cancels a job (only possible while status is PENDING) |

## `submit_gate_job` Parameters

| Parameter | Type | Required | Description |
|----------|------|------|------|
| `backend_name` | `str` | Yes | Backend name (`backend1`, `backend2`, `kreo.sc-20`) |
| `gate_circuits` | `list[str]` | Yes | List of circuit strings (QASM2/QASM3/JSON) |
| `shots` | `int` | Yes | Number of execution shots |
| `priority` | `int` | No | Priority from 1 to 4 (default: 3 = NORMAL) |
| `optimization_level` | `int` | No | Transpile optimization level from 0 to 3 (no default) |

## Compatibility

| qubecore-client | qubecore |
|----------------|----------|
| 1.x | 1.x |

## License

MIT