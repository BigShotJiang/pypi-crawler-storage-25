"""Core VectorDB functionality tests."""
