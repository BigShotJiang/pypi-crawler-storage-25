from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, Literal
from urllib.parse import urlencode

import httpx

from .utils.core import JsonObject, require_non_empty

KANBAN_COLUMNS = ("planning", "in_progress", "blocked", "review", "completed")
KANBAN_PRIORITIES = ("urgent", "high", "medium", "low")
DEFAULT_TIMEOUT_SECONDS = 10.0
KANBAN_PATH = "/rest/v1/kanban_tasks"

KanbanColumn = Literal["planning", "in_progress", "blocked", "review", "completed"]


@dataclass(frozen=True)
class AgentKanbanContext:
    org_id: str
    root_job_id: str
    job_id: str | None = None
    action: str | None = None


def context_from_env() -> AgentKanbanContext:
    org_id = require_non_empty(
        os.getenv("FREESOLO_TRAINING_ORG_ID", ""),
        "FREESOLO_TRAINING_ORG_ID",
    )
    job_id = os.getenv("FREESOLO_TRAINING_JOB_ID") or None
    root_job_id = (
        os.getenv("FREESOLO_TRAINING_ROOT_JOB_ID")
        or job_id
        or require_non_empty("", "FREESOLO_TRAINING_ROOT_JOB_ID")
    )
    return AgentKanbanContext(
        org_id=org_id,
        root_job_id=root_job_id,
        job_id=job_id,
        action=os.getenv("FREESOLO_TRAINING_ACTION") or None,
    )


class AgentKanban:
    """Internal Freesolo agent planning board client.

    The worker runtime provides Supabase service credentials and
    FREESOLO_TRAINING_* scope variables. Normal user applications should not
    use this client.
    """

    def __init__(
        self,
        *,
        supabase_url: str | None = None,
        service_role_key: str | None = None,
        context: AgentKanbanContext | None = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
    ) -> None:
        self.supabase_url = (supabase_url or os.getenv("SUPABASE_URL") or "").rstrip("/")
        self.service_role_key = service_role_key or os.getenv("SUPABASE_SERVICE_ROLE_KEY") or ""
        if not self.supabase_url:
            raise ValueError("SUPABASE_URL is required")
        if not self.service_role_key:
            raise ValueError("SUPABASE_SERVICE_ROLE_KEY is required")
        self.context = context or context_from_env()
        self.timeout = timeout

    def plan(
        self,
        *,
        title: str,
        description: str | None = None,
        task_key: str,
        priority: str = "medium",
    ) -> JsonObject:
        return self._upsert(
            title=title,
            description=description,
            task_key=task_key,
            column="planning",
            priority=priority,
        )

    def start(
        self,
        *,
        task_key: str,
        description: str | None = None,
    ) -> JsonObject:
        return self._upsert(
            description=description,
            task_key=task_key,
            column="in_progress",
        )

    def review(
        self,
        *,
        task_key: str,
        description: str | None = None,
    ) -> JsonObject:
        return self._upsert(
            description=description,
            task_key=task_key,
            column="review",
        )

    def block(
        self,
        *,
        task_key: str,
        description: str | None = None,
        priority: str = "high",
    ) -> JsonObject:
        return self._upsert(
            description=description,
            task_key=task_key,
            column="blocked",
            priority=priority,
        )

    def complete(
        self,
        *,
        task_key: str,
        description: str | None = None,
    ) -> JsonObject:
        return self._upsert(
            description=description,
            task_key=task_key,
            column="completed",
        )

    def _upsert(
        self,
        *,
        title: str | None = None,
        description: str | None = None,
        task_key: str,
        column: KanbanColumn = "planning",
        priority: str | None = None,
    ) -> JsonObject:
        _validate_column(column)
        task_key = require_non_empty(task_key, "task_key")
        if priority is not None:
            _validate_priority(priority)

        existing = self._find_by_task_key(task_key)
        if existing is None and title is None:
            raise ValueError("title is required when creating a kanban task")

        payload = self._task_payload(
            title=title,
            description=description,
            task_key=task_key,
            column=column,
            priority=priority,
            existing=existing,
        )
        if existing is not None:
            return self._patch_task(str(existing["id"]), payload)

        payload["position"] = self._next_position(column)
        return self._insert_task(payload)

    def list_tasks(self) -> list[JsonObject]:
        response = self._request(
            "GET",
            self._url(
                {
                    "select": "id,title,description,column,priority,position,agent_metadata,updated_at",
                    "org_id": f"eq.{self.context.org_id}",
                    "root_job_id": f"eq.{self.context.root_job_id}",
                    "order": "position.asc",
                }
            ),
        )
        return [_task_summary(row) for row in _rows(response)]

    def _task_payload(
        self,
        *,
        title: str | None,
        description: str | None,
        task_key: str,
        column: KanbanColumn,
        priority: str | None,
        existing: JsonObject | None,
    ) -> JsonObject:
        agent_metadata = _metadata_payload(
            context=self.context,
            task_key=task_key,
            existing=existing,
        )
        payload: JsonObject = {
            "column": column,
            "agent_metadata": agent_metadata,
            "updated_at": datetime.now(UTC).isoformat(),
        }
        if title is not None:
            payload["title"] = require_non_empty(title, "title")
        if description is not None:
            payload["description"] = description.strip() or None
        if priority is not None:
            payload["priority"] = priority
        if existing is None:
            payload["org_id"] = self.context.org_id
            payload["root_job_id"] = self.context.root_job_id
            payload.setdefault("priority", "medium")
        return payload

    def _find_by_task_key(self, task_key: str) -> JsonObject | None:
        response = self._request(
            "GET",
            self._url(
                {
                    "select": "id,title,description,column,priority,agent_metadata",
                    "org_id": f"eq.{self.context.org_id}",
                    "root_job_id": f"eq.{self.context.root_job_id}",
                    "limit": "500",
                }
            ),
        )
        for row in _rows(response):
            agent_metadata = row.get("agent_metadata")
            if isinstance(agent_metadata, dict) and agent_metadata.get("task_key") == task_key:
                return row
        return None

    def _next_position(self, column: KanbanColumn) -> int:
        response = self._request(
            "GET",
            self._url(
                {
                    "select": "position",
                    "org_id": f"eq.{self.context.org_id}",
                    "root_job_id": f"eq.{self.context.root_job_id}",
                    "column": f"eq.{column}",
                    "order": "position.desc",
                    "limit": "1",
                }
            ),
        )
        rows = _rows(response)
        if not rows or not isinstance(rows[0].get("position"), int):
            return 0
        return int(rows[0]["position"]) + 1

    def _insert_task(self, payload: JsonObject) -> JsonObject:
        response = self._request("POST", self._url(), json=payload)
        return _task_summary(_first_row(response))

    def _patch_task(self, task_id: str, payload: JsonObject) -> JsonObject:
        response = self._request(
            "PATCH",
            self._url({"id": f"eq.{task_id}"}),
            json=payload,
        )
        return _task_summary(_first_row(response))

    def _url(self, params: dict[str, str] | None = None) -> str:
        url = f"{self.supabase_url}{KANBAN_PATH}"
        if not params:
            return url
        return f"{url}?{urlencode(params)}"

    def _headers(self) -> dict[str, str]:
        return {
            "apikey": self.service_role_key,
            "Authorization": f"Bearer {self.service_role_key}",
            "Content-Type": "application/json",
            "Prefer": "return=representation",
        }

    def _request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        with httpx.Client(timeout=self.timeout) as client:
            response = client.request(method, url, headers=self._headers(), **kwargs)
        response.raise_for_status()
        return response


def _metadata_payload(
    *,
    context: AgentKanbanContext,
    task_key: str,
    existing: JsonObject | None,
) -> JsonObject:
    current = {}
    if existing is not None and isinstance(existing.get("agent_metadata"), dict):
        current = dict(existing["agent_metadata"])
    current.update(
        {
            "agent_managed": True,
            "task_key": task_key,
            "job_id": context.job_id,
            "root_job_id": context.root_job_id,
            "action": context.action,
            "updated_at": datetime.now(UTC).isoformat(),
        }
    )
    return current


def _validate_column(column: str) -> None:
    if column not in KANBAN_COLUMNS:
        raise ValueError(f"column must be one of: {', '.join(KANBAN_COLUMNS)}")


def _validate_priority(priority: str) -> None:
    if priority not in KANBAN_PRIORITIES:
        raise ValueError(f"priority must be one of: {', '.join(KANBAN_PRIORITIES)}")


def _rows(response: httpx.Response) -> list[JsonObject]:
    parsed = response.json()
    if not isinstance(parsed, list):
        raise ValueError("kanban API returned a non-list response")
    return [row for row in parsed if isinstance(row, dict)]


def _first_row(response: httpx.Response) -> JsonObject:
    rows = _rows(response)
    if not rows:
        raise ValueError("kanban API did not return a task")
    return rows[0]


def _task_summary(row: JsonObject) -> JsonObject:
    raw_metadata = row.get("agent_metadata")
    agent_metadata = dict(raw_metadata) if isinstance(raw_metadata, dict) else {}
    return {
        "id": row.get("id"),
        "task_key": agent_metadata.get("task_key"),
        "title": row.get("title"),
        "description": row.get("description"),
        "column": row.get("column"),
        "priority": row.get("priority"),
        "position": row.get("position"),
        "org_id": row.get("org_id"),
        "root_job_id": row.get("root_job_id") or agent_metadata.get("root_job_id"),
        "job_id": agent_metadata.get("job_id"),
        "action": agent_metadata.get("action"),
        "updated_at": row.get("updated_at"),
    }


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Update the Freesolo agent kanban board.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    plan_parser = subparsers.add_parser("plan")
    plan_parser.add_argument("--key", required=True, dest="task_key")
    plan_parser.add_argument("--title", required=True)
    plan_parser.add_argument("--description")
    plan_parser.add_argument("--priority", choices=KANBAN_PRIORITIES)

    for command in ("start", "review", "block", "complete"):
        move_parser = subparsers.add_parser(command)
        move_parser.add_argument("--key", required=True, dest="task_key")
        move_parser.add_argument("--description")

    subparsers.add_parser("list")
    return parser


def main() -> None:
    args = _build_parser().parse_args()
    client = AgentKanban()
    if args.command == "list":
        result: Any = client.list_tasks()
    else:
        kwargs = {
            "task_key": args.task_key,
            "description": args.description,
        }
        if hasattr(args, "title"):
            kwargs["title"] = args.title
        if getattr(args, "priority", None):
            kwargs["priority"] = args.priority
        result = getattr(client, args.command)(**kwargs)
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
