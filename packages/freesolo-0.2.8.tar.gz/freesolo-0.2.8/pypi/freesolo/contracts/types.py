from __future__ import annotations

from typing import TypedDict


class ChatMessage(TypedDict):
    role: str
    content: str


class ContractMessageSpec(TypedDict, total=False):
    role: str
    content: str


class EvaluationSpec(TypedDict, total=False):
    name: str
    description: str


class PromptConfig(TypedDict, total=False):
    system: str
    user: str
    messages: list[ContractMessageSpec]


class ContractSpec(TypedDict, total=False):
    prompt: PromptConfig
    evaluations: list[EvaluationSpec]


__all__ = [
    "ChatMessage",
    "ContractMessageSpec",
    "ContractSpec",
    "EvaluationSpec",
    "PromptConfig",
]
