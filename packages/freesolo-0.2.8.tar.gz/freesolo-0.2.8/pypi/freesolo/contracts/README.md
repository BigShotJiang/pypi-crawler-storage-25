# Contracts

The contract is the source of truth for generated repo behavior.

## Public Imports

```python
from freesolo.contracts import (
    build_oracle_messages,
    extract_contract_spec,
    load_contract_spec,
    load_contract_text,
)
```

## Expected Contract File

Generated repos should treat `freesolo/TRAINING_CONTRACT.md` or
`TRAINING_CONTRACT.md` as read-only approved input, depending on where the
repo-level agent wrote it. Do not edit the approved contract during optimizer or
training runs.

The contract should be a JSON object with prompt text and evaluation scorers:

```json
{
  "prompt": {
    "system": "Follow the task contract.",
    "user": "{task}"
  },
  "evaluations": [
    {
      "name": "correctness",
      "description": "Checks whether the response satisfies the task using the required evidence."
    }
  ]
}
```

`load_contract_spec(path)` returns that JSON object when present. Legacy fenced
JSON blocks tagged `freesolo-contract` are still supported.

## Agent Guidance

- Use `load_contract_text(...)` whenever a package helper needs the prose
  contract.
- Use `load_contract_spec(...)` to seed prompt text and output-shape
  expectations.
- Use `build_oracle_messages(...)` for oracle generation instead of rebuilding
  prompt rendering.
- GEPA candidates may optimize model-facing prompt text derived from
  `prompt.system` and `prompt.user`; they must not rewrite the approved contract.
