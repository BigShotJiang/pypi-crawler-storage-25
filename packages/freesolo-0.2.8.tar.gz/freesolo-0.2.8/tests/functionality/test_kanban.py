from __future__ import annotations

from typing import Any, ClassVar
from urllib.parse import parse_qs, urlparse

import httpx
import pytest
from freesolo.kanban import AgentKanban, AgentKanbanContext, _build_parser


class _FakeHttpClient:
    calls: ClassVar[list[dict[str, Any]]] = []
    tasks: ClassVar[list[dict[str, Any]]] = []

    def __init__(self, *, timeout: float) -> None:
        self.timeout = timeout

    def __enter__(self) -> _FakeHttpClient:
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        self.calls.append({"method": method, "url": url, **kwargs})
        request = httpx.Request(method, url)
        if method == "GET":
            parsed = urlparse(url)
            params = parse_qs(parsed.query)
            if params.get("select") == ["position"]:
                column = params.get("column", ["eq.planning"])[0].removeprefix("eq.")
                positions = [
                    {"position": task["position"]}
                    for task in self.tasks
                    if task.get("column") == column
                ]
                positions.sort(key=lambda row: row["position"], reverse=True)
                return httpx.Response(200, json=positions[:1], request=request)
            return httpx.Response(200, json=self.tasks, request=request)
        if method == "POST":
            payload = dict(kwargs["json"])
            payload["id"] = f"task-{len(self.tasks) + 1}"
            self.tasks.append(payload)
            return httpx.Response(201, json=[payload], request=request)
        if method == "PATCH":
            payload = dict(kwargs["json"])
            self.tasks[0].update(payload)
            return httpx.Response(200, json=[self.tasks[0]], request=request)
        raise AssertionError(f"unexpected method {method}")


@pytest.fixture(autouse=True)
def _reset_fake_http(monkeypatch: pytest.MonkeyPatch) -> None:
    _FakeHttpClient.calls = []
    _FakeHttpClient.tasks = []
    monkeypatch.setattr("freesolo.kanban.httpx.Client", _FakeHttpClient)


def _client() -> AgentKanban:
    return AgentKanban(
        supabase_url="https://supabase.test",
        service_role_key="service-role",
        context=AgentKanbanContext(
            org_id="org-1",
            root_job_id="root-1",
            job_id="job-1",
            action="optimize",
        ),
    )


def test_agent_kanban_plan_creates_root_scoped_task() -> None:
    task = _client().plan(
        task_key="baseline-eval",
        title="Run baseline evaluation",
        description="Evaluate the current prompt before changing files.",
        priority="high",
    )

    assert task["org_id"] == "org-1"
    assert task["root_job_id"] == "root-1"
    assert task["column"] == "planning"
    assert task["priority"] == "high"
    assert task["position"] == 0
    assert task["task_key"] == "baseline-eval"
    assert task["job_id"] == "job-1"
    assert task["action"] == "optimize"


def test_agent_kanban_start_updates_existing_task_by_key() -> None:
    client = _client()
    client.plan(task_key="baseline-eval", title="Run baseline evaluation")

    task = client.start(
        task_key="baseline-eval",
        description="Command is running against dev30.",
    )

    assert task["title"] == "Run baseline evaluation"
    assert task["column"] == "in_progress"
    assert task["description"] == "Command is running against dev30."
    assert task["task_key"] == "baseline-eval"
    patch_calls = [call for call in _FakeHttpClient.calls if call["method"] == "PATCH"]
    assert len(patch_calls) == 1
    assert "id=eq.task-1" in patch_calls[0]["url"]


def test_agent_kanban_list_returns_agent_friendly_task_keys() -> None:
    client = _client()
    client.plan(task_key="baseline-eval", title="Run baseline evaluation")
    client.plan(task_key="grpo-probe", title="Run GRPO probe")

    tasks = client.list_tasks()

    assert [task["task_key"] for task in tasks] == ["baseline-eval", "grpo-probe"]
    assert tasks[0] == {
        "id": "task-1",
        "task_key": "baseline-eval",
        "title": "Run baseline evaluation",
        "description": None,
        "column": "planning",
        "priority": "medium",
        "position": 0,
        "org_id": "org-1",
        "root_job_id": "root-1",
        "job_id": "job-1",
        "action": "optimize",
        "updated_at": tasks[0]["updated_at"],
    }


def test_agent_kanban_cli_uses_command_specific_arguments() -> None:
    parser = _build_parser()

    plan_args = parser.parse_args(
        ["plan", "--key", "baseline-eval", "--title", "Run baseline eval", "--priority", "high"]
    )
    start_args = parser.parse_args(["start", "--key", "baseline-eval", "--description", "Running now."])

    assert plan_args.title == "Run baseline eval"
    assert plan_args.priority == "high"
    assert not hasattr(start_args, "title")
    assert not hasattr(start_args, "priority")
    with pytest.raises(SystemExit):
        parser.parse_args(["start", "--key", "baseline-eval", "--title", "Unexpected"])
    with pytest.raises(SystemExit):
        parser.parse_args(["plan", "--key", "baseline-eval", "--title", "Run", "--meta", "split=dev30"])
    with pytest.raises(SystemExit):
        parser.parse_args(["update", "--key", "baseline-eval", "--column", "review"])


def test_agent_kanban_uses_training_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SUPABASE_URL", "https://supabase.test")
    monkeypatch.setenv("SUPABASE_SERVICE_ROLE_KEY", "service-role")
    monkeypatch.setenv("FREESOLO_TRAINING_ORG_ID", "org-env")
    monkeypatch.setenv("FREESOLO_TRAINING_ROOT_JOB_ID", "root-env")
    monkeypatch.setenv("FREESOLO_TRAINING_JOB_ID", "job-env")
    monkeypatch.setenv("FREESOLO_TRAINING_ACTION", "training")

    task = AgentKanban().plan(task_key="train-long", title="Launch long GRPO run")

    assert task["org_id"] == "org-env"
    assert task["root_job_id"] == "root-env"
    assert task["job_id"] == "job-env"
    assert task["action"] == "training"
