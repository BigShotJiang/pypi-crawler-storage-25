# 📅 AzerAI Reminder Plugin

**AzerAI** - Azərbaycan dilində qabaqcıl səsli AI asistent xatırladıcı üçün plugin

## Xüsusiyyətlər

- ⏰ **Zamanlı xatırladıcılar** - Specific tarix və saatda
- 📅 **Günlük xatırladıcılar** - Hər gün təkrar olunan
- ⏸️ **Pause/Resume** - Xatırladıcıları idarə et
- 🗑️ **Sil** - Artıq lazım olmayanları sil
- 💾 **JSON saxlama** - Məlumatlar lokal olaraq saxlanılır
- 🔄 **APScheduler** - Güclü zamanlayıcı sistemi

## Platform Dəstəyi

- 💻 **Windows** - Windows 10/11 dəstəklənir
- 🍎 **macOS** - macOS 10.15+ dəstəklənir  
- 🐧 **Linux** - Ubuntu, CentOS, Debian dəstəklənir
- 🐍 **Python** - Python 3.8+ tələb olunur

## Quraşdırma

```bash
pip install AzerAI-Plugins-Reminder
```

## İstifadə

Plugin avtomatik olaraq AzerAI tərəfindən aşkar edilir.

### Əmrlər

- `"5 dəqiqə sonra mənə xatırlat"` - Vaxtlı xatırladıcı
- `"Hər gün saat 09:00da mənə xatırlat"` - Günlük xatırladıcı
- `"Xatırladıcılarmı göstər"` - Siyahı
- `"X xatırladıcınızı dayandırın"` - Pause
- `"X xatırladıcınızı davam et"` - Resume
- `"X xatırladıcınızı sil"` - Sil

## Fayl struktur

```
azerai_plugins_reminder/
├── __init__.py
├── info.py
├── main.py
└── prompts.py
```

## Fayllar

- `azerai_reminders.json` - Xatırladıcı məlumatları

## Asılılıqlar

- `livekit-agents` - AI agent framework
- `apscheduler` - Zamanlayıcı

## 📄 Lisenziya

Bu layihə MIT Lisenziyası ilə lisenziyalaşdırılıb - [LICENSE](https://github.com/AzerStudio-Dev/AzerAI-Plugins-Reminder/blob/main/LICENSE) faylına baxın.

## 📞 Əlaqə

- **Müəllif:** AzerStudio Dev
- **Email:** Info.AzerStudioDev@gmail.com
- **GitHub:** https://github.com/AzerStudio-Dev/AzerAI-Plugins-Reminder
- **PyPI:** https://pypi.org/project/AzerAI-Plugins-Reminder/

---

**🇦🇿 Azərbaycanın ilk tam plugin ekosistemli AI asistentinin Reminder plugini!** 🚀
