"""
AzerAI Reminder Plugin - Plugin Haqqında Məlumatlar Və Metadata
"""
PLUGIN_INFO = {
    "name": "azerai-plugins-reminder",
    "version": "5.0.1",
    "author": "AzerStudio Dev",
    "description": "AzerAI Reminder Plugin - Xatırladıcı Plugin"
}