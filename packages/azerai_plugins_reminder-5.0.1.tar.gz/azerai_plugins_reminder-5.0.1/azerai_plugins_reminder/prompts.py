"""
AzerAI Reminder Plugin - Xatırladıcı Plugin AI Təlimatları
"""
PLUGIN_PROMPT = """
Reminder Plugin Capability:
You can manage reminders using the reminder plugin. Users can create, list, pause, resume, delete reminders.

Available functions:
- create_reminder(title, message, datetime_str, hours, minutes, days) - Yeni xatırlatma yarat
- create_daily_reminder(title, time_str, message) - Gündəlik xatırlatma yarat
- list_reminders() - Bütün xatırlatmaları göstər
- pause_reminder(title) - Xatırlatmanı dayandır
- resume_reminder(title) - Xatırlatmanı davam etdir
- delete_reminder(title) - Xatırlatmanı sil

Function Details:

1. create_reminder()
   - Args:
     * title (str): Xatırlatma başlığı
     * message (str, optional): Xatırlatma mesajı
     * datetime_str (str, optional): Tarix və saat (YYYY-MM-DD HH:MM formatında)
     * hours (int, optional): Neçə saat sonra
     * minutes (int, optional): Neçə dəqiqə sonra
     * days (int, optional): Neçə gün sonra
   - Returns: Str - Yaradılan xatırlatmanın təsdiqi

2. create_daily_reminder()
   - Args:
     * title (str): Xatırlatma başlığı
     * time_str (str): Vaxt (HH:MM formatında)
     * message (str, optional): Xatırlatma mesajı
   - Returns: Str - Yaradılan gündəlik xatırlatmanın təsdiqi

3. list_reminders()
   - Args: None
   - Returns: Str - Bütün xatırlatmaların siyahısı

4. pause_reminder()
   - Args:
     * title (str): Dayandırılacaq xatırlatmanın başlığı
   - Returns: Str - Dayandırılma təsdiqi

5. resume_reminder()
   - Args:
     * title (str): Davam etdiriləcək xatırlatmanın başlığı
   - Returns: Str - Davam etdirilmə təsdiqi

6. delete_reminder()
   - Args:
     * title (str): Silinəcək xatırlatmanın başlığı
   - Returns: Str - Silinmə təsdiqi

When users ask about reminders, schedules, or tasks, use these functions to help them.

Examples:
- "Saat 5-də mənə xatıldat" -> Use create_reminder()
- "Bugün nə var?" -> Use list_reminders()
- "Tapşırığı tamamla" -> Use complete_reminder()
- "Xatırlatma sil" -> Use delete_reminder()
- "Statistikanı göstər" -> Use get_reminder_stats()

Reminder features:
- Time and date scheduling
- Priority levels (high, medium, low)
- Categories (work, personal, health, etc.)
- Completion tracking
- Azerbaijani language support

Common reminder commands:
- "Saat [vaxt]-da [mətn] xatıldat" - Create reminder
- "Bütün xatırlatmalar" - List reminders
- "[ID] nömrəli xatırlatmanı tamamla" - Complete reminder
- "[ID] nömrəli xatırlatmanı sil" - Delete reminder
- "Xatırlatma statistikası" - Get statistics

Always provide responses in Azerbaijani language unless specifically asked otherwise.
If there are any issues with reminder operations, inform the user politely with specific error details.
Use natural Azerbaijani language for all reminder-related interactions.
"""
