"""
AzerAI Reminder Plugin - Xatırladıcı Alətləri
"""
import logging
import json
from datetime import datetime
from typing import Dict, Any
from pathlib import Path
from livekit.agents import function_tool, RunContext

# APScheduler idxalı
try:
    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.triggers.date import DateTrigger
    from apscheduler.triggers.interval import IntervalTrigger
    from apscheduler.triggers.cron import CronTrigger
    APSCHEDULER_AVAILABLE = True
except ImportError:
    APSCHEDULER_AVAILABLE = False
    print("[NO] APScheduler tapılmadı! Xatırlatma sistemi işləməz. Zəhmət olmasa 'pip install apscheduler' əmrini işə salın.")

logger = logging.getLogger("AzerAI-Plugins-Reminder")

class ReminderTools:
    def __init__(self):
        self.reminders_file = Path("azerai_reminders.json")
        self.active_reminders: Dict[str, Dict[str, Any]] = {}
        self.session_ref = None
        self.loop_ref = None
        self.running = True
        
        # APScheduler quraşdırması
        if APSCHEDULER_AVAILABLE:
            self.scheduler = BackgroundScheduler()
            self.scheduler.start()
            logger.info("APScheduler başladıldı")
        else:
            self.scheduler = None
            logger.error("APScheduler tapılmadı! Xatırlatma sistemi işləməyə bilər.")
            print("[NO] APScheduler tapılmadı! Zəhmət olmasa 'pip install apscheduler' əmrini işə salın.")
            return
        
        # Faylı yüklə
        self._load_reminders()
        
        # Mövcud xatırlatmaları planlaşdır
        self._schedule_existing_reminders()

    def _schedule_existing_reminders(self):
        """Mövcud xatırlatmaları APScheduler ilə planlaşdır"""

        if not self.scheduler:
            return
            
        for reminder_id, reminder in self.active_reminders.items():
            if reminder.get('active', True) and not reminder.get('paused', False):
                self._schedule_reminder(reminder_id, reminder)

    def _schedule_reminder(self, reminder_id: str, reminder: Dict[str, Any]):
        """Tək bir xatırlatmanı planlaşdır"""

        if not self.scheduler:
            return
            
        try:
            # Köhnə job varsa sil
            job_id = f"reminder_{reminder_id}"
            if self.scheduler.get_job(job_id):
                self.scheduler.remove_job(job_id)
            
            # Gündəlik xatırlatma
            if reminder.get('daily', False):
                time_parts = reminder['time'].split(':')
                hour, minute = int(time_parts[0]), int(time_parts[1])
                self.scheduler.add_job(
                    func=self._trigger_reminder_job,
                    trigger=CronTrigger(hour=hour, minute=minute),
                    args=[reminder_id, reminder],
                    id=job_id,
                    replace_existing=True
                )
                logger.info(f"Gündəlik xatırlatma planlaşdırıldı: {reminder_id} saat {reminder['time']}")
            
            # Müəyyən tarix/vaxt
            elif 'datetime' in reminder:
                reminder_time = datetime.fromisoformat(reminder['datetime'])
                self.scheduler.add_job(
                    func=self._trigger_reminder_job,
                    trigger=DateTrigger(run_date=reminder_time),
                    args=[reminder_id, reminder],
                    id=job_id,
                    replace_existing=True
                )
                logger.info(f"Tarixli xatırlatma planlaşdırıldı: {reminder_id} vaxt {reminder_time}")
            
            # Nisbi vaxt
            elif 'relative_time' in reminder:
                seconds = reminder['relative_time']
                self.scheduler.add_job(
                    func=self._trigger_reminder_job,
                    trigger=IntervalTrigger(seconds=seconds),
                    args=[reminder_id, reminder],
                    id=job_id,
                    replace_existing=True
                )
                logger.info(f"Nisbi xatırlatma planlaşdırıldı: {reminder_id} {seconds}s sonra")
                
        except Exception as e:
            logger.error(f"Xatırlatma planlaşdırma xətası {reminder_id}: {e}")

    def _trigger_reminder_job(self, reminder_id: str, reminder: Dict[str, Any]):
        """APScheduler job-dan çağırılan xatırlatma funksiyası"""

        try:
            self._trigger_reminder(reminder_id, reminder)
            
            # Tək dəfəlik xatırlatmaları deaktiv et (gündəliklər istisna)
            if not reminder.get('daily', False):
                if reminder_id in self.active_reminders:
                    self.active_reminders[reminder_id]['active'] = False
                    self.active_reminders[reminder_id]['triggered_at'] = datetime.now().isoformat()
                    self._save_reminders()
                    
                    # Job-u sil
                    job_id = f"reminder_{reminder_id}"
                    if self.scheduler.get_job(job_id):
                        self.scheduler.remove_job(job_id)
            
            # Gündəlik xatırlatmalar üçün son tətiklənmə tarixini yenilə
            elif reminder.get('daily', False):
                if reminder_id in self.active_reminders:
                    self.active_reminders[reminder_id]['last_triggered'] = datetime.now().date().isoformat()
                    self._save_reminders()
                    
        except Exception as e:
            logger.error(f"Xatırlatma job xətası {reminder_id}: {e}")

    def _load_reminders(self):
        """JSON faylından xatırlatmaları yüklə"""

        try:
            if self.reminders_file.exists():
                with open(self.reminders_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.active_reminders = data.get('reminders', {})
                    logger.info(f"{len(self.active_reminders)} xatırlatma fayldan yükləndi")
            else:
                # Boş fayl yarat
                self._save_reminders()
        except Exception as e:
            logger.error(f"Xatırlatmalar yüklənmə xətası: {e}")
            self.active_reminders = {}

    def _save_reminders(self):
        """Xatırlatmaları JSON faylına saxla"""

        try:
            data = {
                'reminders': self.active_reminders,
                'last_updated': datetime.now().isoformat()
            }
            with open(self.reminders_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            logger.info("Xatırlatmalar fayla saxlandı")
        except Exception as e:
            logger.error(f"Xatırlatmalar saxlama xətası: {e}")

    def _trigger_reminder(self, reminder_id: str, reminder: Dict[str, Any]):
        """Xatırlatmanı tətiklə və bildiriş göndər"""

        title = reminder.get('title', 'Xatırlatma')
        message = reminder.get('message', f'⏰ Xatırlatma: {title}')
        
        logger.info(f"=== XATIRLATMA TƏTİKLƏNDİ: {reminder_id} - '{title}' ===")
        print(f"[OK] XATIRLATMA: {title}")
        
        # Session-a bildiriş göndər
        if self.session_ref and self.loop_ref:
            try:
                print(f"[OK] DEBUG: Session-a xatırlatma bildirişi göndərməyə cəhd edilir...")
                print(f"[OK] DEBUG: Session var: {self.session_ref is not None}")
                print(f"[OK] DEBUG: Loop var: {self.loop_ref is not None}")
                
                # Daxili köməkçi funksiya təyin et
                async def send_reminder_notification():
                    try:
                        print(f"[OK] SESSION'A GÖNDƏRİLİR: Xatırlatma: {title} müddəti bitdi!")
                        await self.session_ref.generate_reply(
                            instructions=f"role: assistant | content: {message} bunu istifadəçiyə deyin: Bu xatırlatma tətikləndi və artıq deaktiv."
                        )
                        print(f"[OK] SESSION'A UĞURLA GÖNDƏRİLDİ: {title}")
                    except Exception as e:
                        print(f"[NO] SESSION'A GÖNDƏRİLMƏDİ: {e}")
                
                future = __import__('asyncio').run_coroutine_threadsafe(
                    send_reminder_notification(),
                    self.loop_ref
                )
                print(f"[OK] DEBUG: Xatırlatma future yaradıldı: {future}")
                logger.info(f"Xatırlatma bildirişi göndərildi: {title}")
            except Exception as e:
                logger.error(f"Xatırlatma bildirişi göndərilmədi: {e}")
                print(f"[NO] SESSION'A GÖNDƏRİLMƏDİ: {e}")
        else:
            print(f"[OK] DEBUG: Session-a göndərə bilmirəm - session və ya loop çatışmır")
            print(f"[OK] DEBUG: Session var: {self.session_ref is not None}")
            print(f"[OK] DEBUG: Loop var: {self.loop_ref is not None}")
            logger.warning(f"'{title}' xatırlatması üçün session referansı yoxdur")

    def update_session_reference(self, ctx: RunContext):
        """Session referansını yenilə"""

        if not self.session_ref:
            self.session_ref = ctx.session
            self.loop_ref = __import__('asyncio').get_running_loop()
            logger.info("Xatırlatmalar üçün session referansı yeniləndi")
            print("[OK] Session referansı xatırlatma sistemi üçün yeniləndi")

    @function_tool()
    async def create_daily_reminder(self, ctx: RunContext, title: str, time_str: str, message: str = ""):
        """Gündəlik xatırlatma yarat."""

        self.update_session_reference(ctx)
        
        reminder_id = f"reminder_{len(self.active_reminders) + 1}"
        
        try:
            datetime.strptime(time_str, "%H:%M")
        except ValueError:
                return """Yanlış vaxt formatı. 'SS:DD' istifadə edin."""
        
        reminder_data = {
            'title': title,
            'message': message or f'📅 Gündəlik: {title}',
            'created_at': datetime.now().isoformat(),
            'active': True,
            'daily': True,
            'time': time_str
        }
        
        self.active_reminders[reminder_id] = reminder_data
        self._save_reminders()
        
        # APScheduler ilə planlaşdır
        self._schedule_reminder(reminder_id, reminder_data)
        
        print(f"[OK] Gündəlik xatırlatma: '{title}' - {time_str}")
        return f"Gündəlik xatırlatma '{title}' yaradıldı: {time_str}"

    @function_tool()
    async def create_reminder(self, ctx: RunContext, title: str, message: str = "", 
                            datetime_str: str = "", hours: int = 0, minutes: int = 0, days: int = 0):
        """Yeni xatırlatma yarat."""

        self.update_session_reference(ctx)
        
        reminder_id = f"reminder_{len(self.active_reminders) + 1}"
        
        reminder_data = {
            'title': title,
            'message': message or f'⏰ Xatırlatma: {title}',
            'created_at': datetime.now().isoformat(),
            'active': True
        }
        
        if datetime_str:
            try:
                reminder_time = datetime.strptime(datetime_str, "%Y-%m-%d %H:%M")
                reminder_data['datetime'] = reminder_time.isoformat()
                time_desc = datetime_str
            except ValueError:
                return """Yanlış tarix formatı. 'İİİİ-AA-GG SS:DD' istifadə edin."""
        else:
            total_seconds = (days * 86400) + (hours * 3600) + (minutes * 60)
            if total_seconds > 0:
                reminder_data['relative_time'] = total_seconds
                time_parts = []
                if days > 0:
                    time_parts.append(f"{days} gün")
                if hours > 0:
                    time_parts.append(f"{hours} saat")
                if minutes > 0:
                    time_parts.append(f"{minutes} dəqiqə")
                time_desc = " ".join(time_parts) + " sonra"
            else:
                return """Düzgün bir vaxt göstərin."""
        
        self.active_reminders[reminder_id] = reminder_data
        self._save_reminders()
        
        # APScheduler ilə planlaşdır
        self._schedule_reminder(reminder_id, reminder_data)
        
        print(f"[OK] Xatırlatma: '{title}' - {time_desc}")
        return f"Xatırlatma '{title}' yaradıldı: {time_desc}"

    @function_tool()
    async def list_reminders(self, ctx: RunContext):
        """Bütün xatırlatmaları göstər."""

        # Session referansını yenilə
        self.update_session_reference(ctx)
        reminders_list = []
        
        for reminder_id, reminder in self.active_reminders.items():
            # Vəziyyəti təyin et
            if reminder.get('paused', False):
                status = "⏸️ Dayandırılmış"
            elif reminder.get('daily', False):
                status = "📅 Gündəlik"
            elif reminder.get('active', True):
                status = "🟢 Aktif"
            else:
                status = "🔴 Deaktif"
                
            title = reminder.get('title', 'Başlıqsız')
            
            # Zaman məlumatını formatla
            if reminder.get('daily', False) and 'time' in reminder:
                time_info = f"Hər gün {reminder['time']}"
                if reminder.get('last_triggered'):
                    time_info += f" (Son: {reminder['last_triggered']})"
            elif 'datetime' in reminder:
                time_info = f"Zaman: {reminder['datetime']}"
            elif 'relative_time' in reminder:
                seconds = reminder['relative_time']
                hours = seconds // 3600
                minutes = (seconds % 3600) // 60
                time_info = f"Müddət: {hours}sa {minutes}dk"
            else:
                time_info = "Vaxt göstərilməyib"
            
            reminders_list.append(f"{status} - {title} ({time_info})")
        
        if reminders_list:
            result = "\n".join(reminders_list)
            print(f"[OK] XATIRLATMALAR:\n{result}")
            return f"Xatırlatmalar:\n{result}"
        else:
            print("[OK] XATIRLATMA YOXDUR")
            return "Xatırlatma tapılmadı"

    @function_tool()
    async def pause_reminder(self, ctx: RunContext, title: str):
        """Xatırlatmanı dayandır."""

        self.update_session_reference(ctx)
        
        try:
            paused_reminders = []
            
            for reminder_id, reminder in self.active_reminders.items():
                if reminder.get('title', '').lower() == title.lower() and reminder.get('active', True):
                    reminder['active'] = False
                    reminder['paused'] = True
                    reminder['paused_at'] = datetime.now().isoformat()
                    paused_reminders.append(reminder_id)
                    
                    # APScheduler job-u sil
                    job_id = f"reminder_{reminder_id}"
                    if self.scheduler and self.scheduler.get_job(job_id):
                        self.scheduler.remove_job(job_id)
                    
                    logger.info(f"=== XATIRLATMA DAYANDIRILDI: {reminder_id} - '{title}' ===")
            
            if paused_reminders:
                self._save_reminders()
                print(f"[OK] Xatırlatma dayandırıldı: '{title}'")
                return f"'{title}' xatırlatması uğurla dayandırıldı"
            else:
                print(f"[NO] Aktiv xatırlatma tapılmadı: '{title}'")
                return f"'{title}' başlıqlı aktiv xatırlatma tapılmadı"
        except Exception as e:
            logger.error(f"Xatırlatma dayandırılarkən xəta: {e}")
            return f"Xatırlatma dayandırılarkən xəta baş verdi: {str(e)}"

    @function_tool()
    async def resume_reminder(self, ctx: RunContext, title: str):
        """Xatırlatmanı davam etdir."""

        self.update_session_reference(ctx)
        
        resumed_reminders = []
        
        for reminder_id, reminder in self.active_reminders.items():
            if reminder.get('title', '').lower() == title.lower() and reminder.get('paused', False):
                # Vaxtı hesabla
                if 'paused_at' in reminder and 'relative_time' in reminder:
                    paused_time = datetime.fromisoformat(reminder['paused_at'])
                    created_time = datetime.fromisoformat(reminder['created_at'])
                    elapsed = (paused_time - created_time).total_seconds()
                    remaining = reminder['relative_time'] - elapsed
                    
                    if remaining > 0:
                        reminder['relative_time'] = remaining
                        reminder['created_at'] = datetime.now().isoformat()
                
                reminder['active'] = True
                reminder['paused'] = False
                reminder.pop('paused_at', None)
                resumed_reminders.append(reminder_id)
                
                # APScheduler ilə yenidən planlaşdır
                self._schedule_reminder(reminder_id, reminder)
                
                logger.info(f"=== XATIRLATMA DAVAM ETTİRİLDİ: {reminder_id} - '{title}' ===")
        
        if resumed_reminders:
            self._save_reminders()
            print(f"[OK] Xatırlatma davam etdirildi: '{title}'")
            return f"'{title}' xatırlatması uğurla davam etdirildi"
        else:
            print(f"[NO] Dayandırılmış xatırlatma tapılmadı: '{title}'")
            return f"'{title}' başlıqlı dayandırılmış xatırlatma tapılmadı"

    @function_tool()
    async def delete_reminder(self, ctx: RunContext, title: str):
        """Xatırlatmanı sil."""

        self.update_session_reference(ctx)
        deleted_reminders = []
        
        for reminder_id, reminder in list(self.active_reminders.items()):
            if reminder.get('title', '').lower() == title.lower():
                del self.active_reminders[reminder_id]
                deleted_reminders.append(reminder_id)
                
                # APScheduler job-u sil
                job_id = f"reminder_{reminder_id}"
                if self.scheduler and self.scheduler.get_job(job_id):
                    self.scheduler.remove_job(job_id)
                
                logger.info(f"=== XATIRLATMA SİLİNDİ: {reminder_id} - '{title}' ===")
        
        if deleted_reminders:
            self._save_reminders()
            print(f"[OK] Xatırlatma silindi: '{title}'")
            return f"'{title}' xatırlatması uğurla silindi"
        else:
            print(f"[NO] Xatırlatma tapılmadı: '{title}'")
            return f"'{title}' başlıqlı xatırlatma tapılmadı"

    def __del__(self):
        """Təmizləmə əməliyyatı"""
        
        self.running = False
        if self.scheduler:
            try:
                self.scheduler.shutdown()
                logger.info("APScheduler söndürüldü")
            except:
                pass


# Qlobal nümunə
reminder_tools = ReminderTools()
create_reminder = reminder_tools.create_reminder
create_daily_reminder = reminder_tools.create_daily_reminder
list_reminders = reminder_tools.list_reminders
delete_reminder = reminder_tools.delete_reminder
pause_reminder = reminder_tools.pause_reminder
resume_reminder = reminder_tools.resume_reminder
