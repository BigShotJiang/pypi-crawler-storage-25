"""Allow running crosscheck as: python -m crosscheck"""
from crosscheck.cli import cli

if __name__ == "__main__":
    cli()
