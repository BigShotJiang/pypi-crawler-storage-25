from serial.tools.list_ports import comports
import serial

# Find which port the ESP32 is on.
def findPort():
    VID = 0x303A
    PID = 0x1001
    ports = comports()
    portName = None
    for port in ports:
        if port.pid == PID and port.vid == VID:
            portName = port.name
            break
    return portName

# Get and configure Serial instance
def getSerial(numBits):
    SPEED = 3065 # How many messages Arduino can send to computer per second
    timeout = (numBits / SPEED) * 1.3 + 5 # 30% extra time plus startup time
    ser = serial.Serial(timeout=timeout)
    ser.baudrate = 250000
    ser.port = findPort()
    return ser

# Send a request for bits
def reqBits(numBits):
    ser = getSerial(numBits)
    ser.open()
    print("Beginning Handshake")
    handshake(ser, numBits)
    bits = ser.read_until(size=numBits)
    ser.close()
    return bits

def handshake(ser, numBits):
    numBitsByte = str(numBits).encode()
    print(numBitsByte)
    ser.write(numBitsByte)
    numBytes = len(numBitsByte)
    print("Number of Bytes in ByteString Sent: " + str(numBytes))
    bits = ser.read_until(size=numBytes)
    print("Bits: " + str(bits))
    print("Bits Decoded: " + str(bits.decode()))
    if int(bits.decode().strip()) == numBits:
        ser.write(numBitsByte)
        print("Match!")
    else:
        print("No Match!")
    return

def receiveTest(size):
    ser = getSerial(size)
    ser.open()
    return ser.read_until(size=size)