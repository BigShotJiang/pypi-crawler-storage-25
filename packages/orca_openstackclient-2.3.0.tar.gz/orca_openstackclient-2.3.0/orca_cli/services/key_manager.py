"""High-level operations on Barbican key-manager resources."""

from __future__ import annotations

from typing import Any

from orca_cli.core.client import OrcaClient, with_version
from orca_cli.models.key_manager import Acl, Order, Secret, SecretContainer


class KeyManagerService:
    """Typed wrapper around Barbican ``/v1`` endpoints."""

    def __init__(self, client: OrcaClient) -> None:
        self._client = client
        self._base = with_version(client.key_manager_url, "v1")

    # ── secrets ────────────────────────────────────────────────────────

    def find_secrets(self, *,
                     params: dict[str, Any] | None = None) -> list[Secret]:
        data = self._client.get(f"{self._base}/secrets", params=params)
        return data.get("secrets", [])

    def get_secret(self, secret_id: str) -> Secret:
        return self._client.get(f"{self._base}/secrets/{secret_id}")

    def create_secret(self, body: dict[str, Any]) -> Secret:
        data = self._client.post(f"{self._base}/secrets", json=body)
        return data if data else {}

    def delete_secret(self, secret_id: str) -> None:
        self._client.delete(f"{self._base}/secrets/{secret_id}")

    def get_secret_payload(self, secret_id: str) -> str:
        """Fetch the raw payload for a secret.

        Barbican returns the payload with whatever ``Content-Type`` matches
        the original storage (``text/plain``, ``application/octet-stream``,
        ...) and not as JSON, so the call goes through ``client.get_stream``
        with an explicit ``Accept: text/plain`` rather than ``client.get``.
        """
        url = f"{self._base}/secrets/{secret_id}/payload"
        with self._client.get_stream(
            url, extra_headers={"Accept": "text/plain"},
        ) as resp:
            resp.read()
            if resp.status_code != 200:
                from orca_cli.core.exceptions import APIError
                raise APIError(resp.status_code, resp.text[:300])
            return resp.text

    # ── secret ACL ─────────────────────────────────────────────────────

    def get_secret_acl(self, secret_id: str) -> Acl:
        return self._client.get(f"{self._base}/secrets/{secret_id}/acl")

    def update_secret_acl(self, secret_id: str,
                          body: dict[str, Any]) -> dict:
        return self._client.put(
            f"{self._base}/secrets/{secret_id}/acl", json=body,
        ) or {}

    def delete_secret_acl(self, secret_id: str) -> None:
        self._client.delete(f"{self._base}/secrets/{secret_id}/acl")

    # ── containers ─────────────────────────────────────────────────────

    def find_containers(
        self, *, params: dict[str, Any] | None = None,
    ) -> list[SecretContainer]:
        data = self._client.get(f"{self._base}/containers", params=params)
        return data.get("containers", [])

    def get_container(self, container_id: str) -> SecretContainer:
        return self._client.get(f"{self._base}/containers/{container_id}")

    def create_container(self, body: dict[str, Any]) -> SecretContainer:
        data = self._client.post(f"{self._base}/containers", json=body)
        return data if data else {}

    def delete_container(self, container_id: str) -> None:
        self._client.delete(f"{self._base}/containers/{container_id}")

    # ── orders ─────────────────────────────────────────────────────────

    def find_orders(self, *,
                    params: dict[str, Any] | None = None) -> list[Order]:
        data = self._client.get(f"{self._base}/orders", params=params)
        return data.get("orders", [])

    def get_order(self, order_id: str) -> Order:
        return self._client.get(f"{self._base}/orders/{order_id}")

    def create_order(self, body: dict[str, Any]) -> Order:
        data = self._client.post(f"{self._base}/orders", json=body)
        return data if data else {}

    def delete_order(self, order_id: str) -> None:
        self._client.delete(f"{self._base}/orders/{order_id}")

    # ── consumers (per-container) ──────────────────────────────────────
    # Consumers register an opaque {service, name, URL} on a container
    # to indicate "this resource consumes that container". OSC exposes
    # them as ``secret consumer create/delete/list``.

    def find_consumers(self, container_id: str) -> list[dict[str, Any]]:
        data = self._client.get(
            f"{self._base}/containers/{container_id}/consumers"
        )
        return data.get("consumers", [])

    def add_consumer(self, container_id: str,
                     name: str, url: str) -> dict[str, Any]:
        data = self._client.post(
            f"{self._base}/containers/{container_id}/consumers",
            json={"name": name, "URL": url},
        )
        return data if data else {}

    def remove_consumer(self, container_id: str,
                        name: str, url: str) -> None:
        # Barbican accepts the same body shape on DELETE.
        self._client.delete(
            f"{self._base}/containers/{container_id}/consumers",
            json={"name": name, "URL": url},
        )

    # ── secret payload upload (after metadata-only secret create) ──────

    def put_secret_payload(self, secret_id: str, payload: bytes,
                           content_type: str = "application/octet-stream",
                           content_encoding: str | None = None) -> None:
        """Upload the data half of a previously-created metadata secret.

        ``orca secret create --no-payload`` returns a 'pending' secret
        whose payload is uploaded in a second PUT — useful for large
        secrets or when the payload comes from a separate workflow.
        """
        extra = {"Content-Type": content_type}
        if content_encoding:
            extra["Content-Encoding"] = content_encoding
        self._client.put_stream(
            f"{self._base}/secrets/{secret_id}",
            content=payload, content_type=content_type,
            extra_headers=({"Content-Encoding": content_encoding}
                           if content_encoding else None),
        )
