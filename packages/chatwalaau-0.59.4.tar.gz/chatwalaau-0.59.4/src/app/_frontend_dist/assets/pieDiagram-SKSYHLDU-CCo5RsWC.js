import{t as e}from"./ordinal-3qmO7xdp.js";import{t}from"./arc-DfxFMpt_.js";import{Cn as n,Fn as r,L as i,Ln as a,Lt as o,M as s,Pn as c,Pt as l,Qt as u,Xn as d,Yn as f,Zt as p,_n as m,bn as h,mn as g,wn as _,xn as v,yn as y}from"./index-DIWvYzG5.js";import{t as b}from"./mermaid-parser.core-DLkAK4-i.js";import{t as x}from"./chunk-4BX2VUAB-DR7mzBYQ.js";function S(e,t){return t<e?-1:t>e?1:t>=e?0:NaN}function C(e){return e}function w(){var e=C,t=S,n=null,r=u(0),i=u(p),a=u(0);function s(s){var c,l=(s=o(s)).length,u,d,f=0,m=Array(l),h=Array(l),g=+r.apply(this,arguments),_=Math.min(p,Math.max(-p,i.apply(this,arguments)-g)),v,y=Math.min(Math.abs(_)/l,a.apply(this,arguments)),b=y*(_<0?-1:1),x;for(c=0;c<l;++c)(x=h[m[c]=c]=+e(s[c],c,s))>0&&(f+=x);for(t==null?n!=null&&m.sort(function(e,t){return n(s[e],s[t])}):m.sort(function(e,n){return t(h[e],h[n])}),c=0,d=f?(_-l*b)/f:0;c<l;++c,g=v)u=m[c],x=h[u],v=g+(x>0?x*d:0)+b,h[u]={data:s[u],index:c,value:x,startAngle:g,endAngle:v,padAngle:y};return h}return s.value=function(t){return arguments.length?(e=typeof t==`function`?t:u(+t),s):e},s.sortValues=function(e){return arguments.length?(t=e,n=null,s):t},s.sort=function(e){return arguments.length?(n=e,t=null,s):n},s.startAngle=function(e){return arguments.length?(r=typeof e==`function`?e:u(+e),s):r},s.endAngle=function(e){return arguments.length?(i=typeof e==`function`?e:u(+e),s):i},s.padAngle=function(e){return arguments.length?(a=typeof e==`function`?e:u(+e),s):a},s}var T=y.pie,E={sections:new Map,showData:!1,config:T},D=E.sections,O=E.showData,k=structuredClone(T),A={getConfig:f(()=>structuredClone(k),`getConfig`),clear:f(()=>{D=new Map,O=E.showData,g()},`clear`),setDiagramTitle:a,getDiagramTitle:_,setAccTitle:r,getAccTitle:v,setAccDescription:c,getAccDescription:h,addSection:f(({label:e,value:t})=>{if(t<0)throw Error(`"${e}" has invalid value: ${t}. Negative values are not allowed in pie charts. All slice values must be >= 0.`);D.has(e)||(D.set(e,t),d.debug(`added new section: ${e}, with value: ${t}`))},`addSection`),getSections:f(()=>D,`getSections`),setShowData:f(e=>{O=e},`setShowData`),getShowData:f(()=>O,`getShowData`)},j=f((e,t)=>{x(e,t),t.setShowData(e.showData),e.sections.map(t.addSection)},`populateDb`),M={parse:f(async e=>{let t=await b(`pie`,e);d.debug(t),j(t,A)},`parse`)},N=f(e=>`
  .pieCircle{
    stroke: ${e.pieStrokeColor};
    stroke-width : ${e.pieStrokeWidth};
    opacity : ${e.pieOpacity};
  }
  .pieOuterCircle{
    stroke: ${e.pieOuterStrokeColor};
    stroke-width: ${e.pieOuterStrokeWidth};
    fill: none;
  }
  .pieTitleText {
    text-anchor: middle;
    font-size: ${e.pieTitleTextSize};
    fill: ${e.pieTitleTextColor};
    font-family: ${e.fontFamily};
  }
  .slice {
    font-family: ${e.fontFamily};
    fill: ${e.pieSectionTextColor};
    font-size:${e.pieSectionTextSize};
    // fill: white;
  }
  .legend text {
    fill: ${e.pieLegendTextColor};
    font-family: ${e.fontFamily};
    font-size: ${e.pieLegendTextSize};
  }
`,`getStyles`),P=f(e=>{let t=[...e.values()].reduce((e,t)=>e+t,0),n=[...e.entries()].map(([e,t])=>({label:e,value:t})).filter(e=>e.value/t*100>=1).sort((e,t)=>t.value-e.value);return w().value(e=>e.value)(n)},`createPieArcs`),F={parser:M,db:A,renderer:{draw:f((r,a,o,c)=>{d.debug(`rendering pie chart
`+r);let u=c.db,f=n(),p=s(u.getConfig(),f.pie),h=l(a),g=h.append(`g`);g.attr(`transform`,`translate(225,225)`);let{themeVariables:_}=f,[v]=i(_.pieOuterStrokeWidth);v??=2;let y=p.textPosition,b=t().innerRadius(0).outerRadius(185),x=t().innerRadius(185*y).outerRadius(185*y);g.append(`circle`).attr(`cx`,0).attr(`cy`,0).attr(`r`,185+v/2).attr(`class`,`pieOuterCircle`);let S=u.getSections(),C=P(S),w=[_.pie1,_.pie2,_.pie3,_.pie4,_.pie5,_.pie6,_.pie7,_.pie8,_.pie9,_.pie10,_.pie11,_.pie12],T=0;S.forEach(e=>{T+=e});let E=C.filter(e=>(e.data.value/T*100).toFixed(0)!==`0`),D=e(w);g.selectAll(`mySlices`).data(E).enter().append(`path`).attr(`d`,b).attr(`fill`,e=>D(e.data.label)).attr(`class`,`pieCircle`),g.selectAll(`mySlices`).data(E).enter().append(`text`).text(e=>(e.data.value/T*100).toFixed(0)+`%`).attr(`transform`,e=>`translate(`+x.centroid(e)+`)`).style(`text-anchor`,`middle`).attr(`class`,`slice`),g.append(`text`).text(u.getDiagramTitle()).attr(`x`,0).attr(`y`,-400/2).attr(`class`,`pieTitleText`);let O=[...S.entries()].map(([e,t])=>({label:e,value:t})),k=g.selectAll(`.legend`).data(O).enter().append(`g`).attr(`class`,`legend`).attr(`transform`,(e,t)=>{let n=22*O.length/2;return`translate(216,`+(t*22-n)+`)`});k.append(`rect`).attr(`width`,18).attr(`height`,18).style(`fill`,e=>D(e.label)).style(`stroke`,e=>D(e.label)),k.append(`text`).attr(`x`,22).attr(`y`,14).text(e=>u.getShowData()?`${e.label} [${e.value}]`:e.label);let A=512+Math.max(...k.selectAll(`text`).nodes().map(e=>e?.getBoundingClientRect().width??0));h.attr(`viewBox`,`0 0 ${A} 450`),m(h,450,A,p.useMaxWidth)},`draw`)},styles:N};export{F as diagram};