"""OpenAI provider that prefers the official SDK when available.

`OpenAIProvider` is the hosted/OpenAI-SDK-backed provider. It can also target
OpenAI-compatible APIs via ``base_url`` when callers explicitly want that
behavior, but local HTTP runtimes should generally use
``OpenAICompatibleHTTPProvider`` and its thin presets such as ``OMLXProvider``.
"""
from __future__ import annotations
import importlib

from typing import Any, Dict, Iterable, List, Optional
from types import ModuleType

from .exceptions import ModelitoProviderError
from .messages import Response, flatten_message_inputs


def _fallback_text_from_messages(messages: Any) -> str:
    try:
        flattened = flatten_message_inputs(messages or [])
    except Exception:
        return ""
    return "\n".join(
        item.get("content", "")
        for item in flattened
        if item.get("content")
    )



def _extract_text_from_response(res: Any) -> str:
    if not res:
        return ""
    # dict-like responses
    try:
        if isinstance(res, dict):
            if "text" in res:
                return str(res.get("text") or "")
            if "output" in res:
                out = res.get("output")
                if isinstance(out, list) and out:
                    first = out[0]
                    if isinstance(first, dict):
                        return str(first.get("content") or first)
                    return str(first)
                return str(out or "")
            choices = res.get("choices")
            if isinstance(choices, list) and choices:
                first = choices[0]
                if isinstance(first, dict):
                    msg = first.get("message") or {}
                    return str(msg.get("content") or first.get("text") or "")
                return str(first)
        # object-like responses
        choices = getattr(res, "choices", None)
        if choices:
            first = choices[0]
            message = getattr(first, "message", None)
            if message is not None:
                return str(getattr(message, "content", "") or "")
            return str(getattr(first, "text", "") or str(first))
    except Exception:
        pass
    return ""


def _to_plain_data(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _to_plain_data(inner) for key, inner in value.items()}
    if isinstance(value, list):
        return [_to_plain_data(item) for item in value]
    if hasattr(value, "model_dump"):
        try:
            return _to_plain_data(value.model_dump())
        except Exception:
            pass
    if hasattr(value, "dict"):
        try:
            return _to_plain_data(value.dict())
        except Exception:
            pass
    if hasattr(value, "__dict__"):
        try:
            data = {
                key: inner
                for key, inner in vars(value).items()
                if not key.startswith("_")
            }
            if data:
                return _to_plain_data(data)
        except Exception:
            pass
    return value


class OpenAIProvider:
    """OpenAI provider using the official SDK when available.

    Methods provided:
    - `list_models()` — best-effort model enumeration using `openai.Model.list()`.
    - `summarize(messages, settings)` — attempts a chat completion via the
      SDK and falls back to a deterministic join of message contents.

    Args:
        api_key: OpenAI API key (optional; can be omitted for local servers).
        model: Model name to use (default: "gpt-3.5-turbo").
        base_url: Custom API endpoint URL (e.g., for local OpenAI-compatible servers
                  like llama.cpp/llama-server, vLLM, LM Studio, etc.).
        client: Pre-constructed OpenAI client (optional; overrides SDK-based creation).
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        base_url: Optional[str] = None,
        client: Any = None,
        timeout: float = 20.0,
        strict: bool = False,
        **_: Any,
    ):
        self.api_key = api_key
        self.model = model or "gpt-3.5-turbo"
        self.base_url = base_url
        self._client = client
        self.timeout = float(timeout)
        self.strict = bool(strict)
        self._openai: Optional[ModuleType] = None
        try:
            self._openai = importlib.import_module("openai")
        except Exception:
            self._openai = None

        # Try to construct a modern client if none was provided.
        if self._client is None and self._openai is not None:
            try:
                if hasattr(self._openai, "OpenAI"):
                    try:
                        # Build kwargs for OpenAI client
                        kwargs: Dict[str, Any] = {}
                        if api_key:
                            kwargs["api_key"] = api_key
                        if base_url:
                            kwargs["base_url"] = base_url
                        self._client = self._openai.OpenAI(
                            **kwargs) if kwargs else self._openai.OpenAI()
                    except Exception:
                        self._client = None
            except Exception:
                self._client = None

    def list_models(self) -> List[str]:
        try:
            if self._openai is not None:
                client = self._client or self._openai
                if hasattr(client, "Model") and hasattr(client.Model, "list"):
                    try:
                        res = client.Model.list()
                        data = getattr(res, "data", None) or res
                        return [getattr(m, "id", str(m)) for m in (data or [])]
                    except Exception:
                        pass
                if self._openai is not None and hasattr(self._openai, "Model") and hasattr(self._openai.Model, "list"):
                    try:
                        res = self._openai.Model.list()
                        return [getattr(m, "id", str(m)) for m in getattr(res, "data", [])]
                    except Exception:
                        pass
        except Exception:
            pass
        return []

    def summarize(self, messages: Iterable[Any], settings: Optional[dict[str, Any]] = None) -> str:
        msgs = flatten_message_inputs(messages)

        # Try SDK-backed chat completion (modern and legacy APIs).
        if self._openai is not None:
            try:
                client = self._client
                if client and hasattr(client, "chat") and hasattr(client.chat, "completions") and hasattr(client.chat.completions, "create"):
                    res = client.chat.completions.create(
                        model=self.model, messages=msgs, **(settings or {}))
                    text = _extract_text_from_response(res)
                    if text:
                        return text

                oi = self._openai
                if oi is not None and hasattr(oi, "ChatCompletion") and hasattr(oi.ChatCompletion, "create"):
                    res = oi.ChatCompletion.create(
                        model=self.model, messages=msgs, **(settings or {}))
                    text = _extract_text_from_response(res)
                    if text:
                        return text
            except Exception:
                pass

        # Deterministic fallback — operate on the flattened `msgs` list
        try:
            parts = []
            for m in (msgs or []):
                if isinstance(m, dict):
                    parts.append(str(m.get("content", "") or ""))
                else:
                    parts.append(str(m))
            return "\n".join(p for p in parts if p)
        except Exception:
            return ""

    def raw_complete(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        request_payload = dict(payload or {})
        request_payload.setdefault("model", self.model)

        client = self._client or self._openai
        if client is not None:
            try:
                chat = getattr(client, "chat", None)
                if chat is not None:
                    completions = getattr(chat, "completions", None)
                    if completions is not None and hasattr(completions, "create"):
                        res = completions.create(**request_payload)
                        plain = _to_plain_data(res)
                        if isinstance(plain, dict):
                            return plain
                        return {"raw": plain}

                oi = self._openai
                if oi is not None and hasattr(oi, "ChatCompletion") and hasattr(oi.ChatCompletion, "create"):
                    res = oi.ChatCompletion.create(**request_payload)
                    plain = _to_plain_data(res)
                    if isinstance(plain, dict):
                        return plain
                    return {"raw": plain}
            except Exception as exc:
                if self.strict:
                    raise ModelitoProviderError(str(exc)) from exc

        if self.strict:
            raise ModelitoProviderError("OpenAI provider unavailable")

        text = _fallback_text_from_messages(request_payload.get("messages", []))
        return {
            "id": "chatcmpl-modelito-fallback",
            "object": "chat.completion",
            "created": 0,
            "model": request_payload.get("model", self.model),
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": text},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
        }

    def raw_stream(self, payload: Dict[str, Any]) -> Iterable[Dict[str, Any]]:
        request_payload = dict(payload or {})
        request_payload.setdefault("model", self.model)
        request_payload["stream"] = True

        client = self._client or self._openai
        if client is not None:
            try:
                chat = getattr(client, "chat", None)
                if chat is not None:
                    completions = getattr(chat, "completions", None)
                    if completions is not None:
                        if hasattr(completions, "stream"):
                            for event in completions.stream(**request_payload):
                                plain = _to_plain_data(event)
                                if isinstance(plain, dict):
                                    yield plain
                            return
                        if hasattr(completions, "create"):
                            for event in completions.create(**request_payload):
                                plain = _to_plain_data(event)
                                if isinstance(plain, dict):
                                    yield plain
                            return

                oi = self._openai
                if oi is not None and hasattr(oi, "ChatCompletion") and hasattr(oi.ChatCompletion, "create"):
                    for event in oi.ChatCompletion.create(**request_payload):
                        plain = _to_plain_data(event)
                        if isinstance(plain, dict):
                            yield plain
                    return
            except Exception as exc:
                if self.strict:
                    raise ModelitoProviderError(str(exc)) from exc

        if self.strict:
            raise ModelitoProviderError("OpenAI provider unavailable")

        text = _extract_text_from_response(self.raw_complete(request_payload))
        if not text:
            return
        yield {
            "id": "chatcmpl-modelito-fallback",
            "object": "chat.completion.chunk",
            "created": 0,
            "model": request_payload.get("model", self.model),
            "choices": [
                {"index": 0, "delta": {"role": "assistant"}, "finish_reason": None}
            ],
        }
        yield {
            "id": "chatcmpl-modelito-fallback",
            "object": "chat.completion.chunk",
            "created": 0,
            "model": request_payload.get("model", self.model),
            "choices": [
                {"index": 0, "delta": {"content": text}, "finish_reason": None}
            ],
        }
        yield {
            "id": "chatcmpl-modelito-fallback",
            "object": "chat.completion.chunk",
            "created": 0,
            "model": request_payload.get("model", self.model),
            "choices": [
                {"index": 0, "delta": {}, "finish_reason": "stop"}
            ],
        }

    def chat(self, messages: Iterable[Any], settings: Optional[dict[str, Any]] = None) -> Response:
        payload: Dict[str, Any] = {"model": self.model,
                                   "messages": flatten_message_inputs(messages), "stream": False}
        if isinstance(settings, dict):
            payload.update(settings)

        data = self.raw_complete(payload)
        text = _extract_text_from_response(data)

        model_name: Optional[str] = None
        finish_reason: Optional[str] = None
        tokens_in: Optional[int] = None
        tokens_out: Optional[int] = None

        if isinstance(data, dict):
            model_value = data.get("model")
            if isinstance(model_value, str):
                model_name = model_value
            choices = data.get("choices")
            if isinstance(choices, list) and choices:
                first = choices[0]
                if isinstance(first, dict):
                    reason = first.get("finish_reason")
                    if isinstance(reason, str):
                        finish_reason = reason
            usage = data.get("usage")
            if isinstance(usage, dict):
                prompt_tokens = usage.get("prompt_tokens")
                completion_tokens = usage.get("completion_tokens")
                if isinstance(prompt_tokens, int):
                    tokens_in = prompt_tokens
                if isinstance(completion_tokens, int):
                    tokens_out = completion_tokens

        return Response(
            text=text,
            raw=data,
            model=model_name,
            finish_reason=finish_reason,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
        )

    def stream(self, messages: Iterable[Any], settings: Optional[dict[str, Any]] = None) -> Iterable[str]:
        """Streaming provider surface attempting SDK streaming first.

        Tries several common client shapes (modern and legacy). Falls back
        to chunked deterministic output when streaming is unavailable.
        """

        msgs = flatten_message_inputs(messages)

        import json

        def _extract_delta_text(event: Any) -> str:
            if not event:
                return ""
            # string payloads may be newline/json-prefixed
            if isinstance(event, str):
                s = event.strip()
                if s.startswith("data: "):
                    s = s[6:]
                try:
                    event = json.loads(s)
                except Exception:
                    return s

            # dict-like
            if isinstance(event, dict):
                for k in ("text", "content", "output"):
                    if k in event and isinstance(event.get(k), str):
                        return event.get(k) or ""
                choices = event.get("choices")
                if isinstance(choices, list) and choices:
                    first = choices[0]
                    if isinstance(first, dict):
                        delta = first.get("delta") or first.get("message") or {}
                        if isinstance(delta, dict):
                            if "content" in delta:
                                c = delta.get("content") or ""
                                if isinstance(c, str):
                                    return c
                                if isinstance(c, list):
                                    return "".join(str(x) for x in c)
                        if "message" in first and isinstance(first["message"], dict):
                            return str(first["message"].get("content") or "")
                        if "text" in first:
                            return str(first.get("text") or "")
                    else:
                        return str(first)

            # object-like
            try:
                choices = getattr(event, "choices", None)
                if choices:
                    first = choices[0]
                    delta = getattr(first, "delta", None)
                    if delta:
                        if isinstance(delta, dict) and "content" in delta:
                            return str(delta.get("content") or "")
                        return str(delta)
                    msg = getattr(first, "message", None)
                    if msg:
                        return str(getattr(msg, "content", "") or "")
                for attr in ("text", "content", "output"):
                    val = getattr(event, attr, None)
                    if val:
                        return str(val)
            except Exception:
                pass
            return ""

        client = self._client or self._openai
        if client is not None:
            try:
                # Preferred modern shape: client.chat.completions.stream(...)
                chat = getattr(client, "chat", None)
                if chat is not None:
                    comps = getattr(chat, "completions", None)
                    if comps is not None:
                        if hasattr(comps, "stream"):
                            for evt in comps.stream(model=self.model, messages=msgs, **(settings or {})):
                                txt = _extract_delta_text(evt)
                                if txt:
                                    yield txt
                            return
                        if hasattr(comps, "create"):
                            try:
                                for evt in comps.create(model=self.model, messages=msgs, stream=True, **(settings or {})):
                                    txt = _extract_delta_text(evt)
                                    if txt:
                                        yield txt
                                return
                            except TypeError:
                                # create() may not accept stream param
                                pass

                # legacy module-level ChatCompletion.create(..., stream=True)
                oi = self._openai
                if oi is not None and hasattr(oi, "ChatCompletion") and hasattr(oi.ChatCompletion, "create"):
                    try:
                        for evt in oi.ChatCompletion.create(model=self.model, messages=msgs, stream=True, **(settings or {})):
                            txt = _extract_delta_text(evt)
                            if txt:
                                yield txt
                        return
                    except Exception:
                        pass

                # Newer "responses" streaming API
                if hasattr(client, "responses") and hasattr(client.responses, "stream"):
                    try:
                        for evt in client.responses.stream(model=self.model, input=msgs, **(settings or {})):
                            txt = _extract_delta_text(evt)
                            if txt:
                                yield txt
                        return
                    except Exception:
                        pass
            except Exception:
                pass

        # Fallback: deterministic chunked output
        text = self.summarize(messages, settings=settings)
        if not text:
            return
        chunk_size = 64
        try:
            if isinstance(settings, dict) and "chunk_size" in settings:
                chunk_size = int(settings.get("chunk_size", chunk_size) or chunk_size)
        except Exception:
            pass
        for i in range(0, len(text), chunk_size):
            yield text[i: i + chunk_size]

    async def acomplete(self, messages: Iterable[Any], settings: Optional[dict[str, Any]] = None) -> str:
        """Async wrapper for `summarize()` using a threadpool executor."""
        try:
            import asyncio

            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(None, lambda: self.summarize(messages, settings=settings))
        except Exception:
            return self.summarize(messages, settings=settings)

    def embed(self, texts: Iterable[str], **kwargs: Any) -> List[List[float]]:
        """Attempt to use provider SDK for embeddings, fallback to stub.

        Supports common client shapes (modern and legacy). Returns a list
        of vectors for each input text.
        """
        try:
            client = self._client or self._openai
            if client is not None:
                # modern client: client.embeddings.create(input=[...])
                emb_api = getattr(client, "embeddings", None)
                if emb_api is not None and hasattr(emb_api, "create"):
                    res = emb_api.create(input=list(texts or []), **kwargs)
                    data = getattr(res, "data", None) if not isinstance(
                        res, dict) else res.get("data")
                    out: List[List[float]] = []
                    for item in (data or []):
                        if isinstance(item, dict) and "embedding" in item:
                            out.append(list(item.get("embedding") or []))
                        else:
                            out.append(list(getattr(item, "embedding", [])))
                    if out:
                        return out

                # older shape: client.Embedding.create(input=[...])
                if hasattr(client, "Embedding") and hasattr(client.Embedding, "create"):
                    res = client.Embedding.create(input=list(texts or []), **kwargs)
                    data = getattr(res, "data", None) if not isinstance(
                        res, dict) else res.get("data")
                    out = []
                    for item in (data or []):
                        if isinstance(item, dict) and "embedding" in item:
                            out.append(list(item.get("embedding") or []))
                        else:
                            out.append(list(getattr(item, "embedding", [])))
                    if out:
                        return out
        except Exception:
            pass

        # Fallback to test stub
        try:
            from .embeddings import embed_texts
        except Exception:
            from modelito.embeddings import embed_texts

        dim = int(kwargs.get("dim", 8))
        return embed_texts(texts or [], dim=dim)
