import os
import re
from setuptools import setup, find_packages

c_modules = []

try:
    from Cython.Build import cythonize
    from Cython import __version__ as cython_version

    print(f'Using Cython {cython_version} to build cython modules')
    c_modules = cythonize('clickhouse_connect/driverc/*.pyx', language_level='3str')
except ImportError as ex:
    print('Cython Install Failed, Not Building C Extensions: ', ex)
    cythonize = None
except Exception as ex:  # pylint: disable=broad-exception-caught
    print('Cython Build Failed, Not Building C Extensions: ', ex)
    cythonize = None


def run_setup(try_c: bool = True):
    if try_c:
        kwargs = {
            'ext_modules': c_modules,
        }
    else:
        kwargs = {}

    project_dir = os.path.abspath(os.path.dirname(__file__))
    with open(os.path.join(project_dir, 'README.md'), encoding='utf-8') as read_me:
        long_desc = read_me.read()

    version = 'development'
    if os.path.isfile('.dev_version'):
        with open(os.path.join(project_dir, '.dev_version'), encoding='utf-8') as version_file:
            version = version_file.readline()
    else:
        with open(os.path.join(project_dir, 'clickhouse_connect', '__version__.py'), encoding='utf-8') as version_file:
            file_version = version_file.read().strip()
            match = re.search(r"version\s*=\s*['\"](.+)['\"]", file_version)
            if match is None:
                raise ValueError(f'invalid version {file_version} in clickhouse_connect/__version__.py')
            version = match.group(1)

    setup(
        name='clickhouse-connect',
        author='ClickHouse Inc.',
        author_email='clients@clickhouse.com',
        keywords=['clickhouse', 'superset', 'sqlalchemy', 'http', 'driver'],
        description='ClickHouse Database Core Driver for Python, Pandas, and Superset',
        version=version,
        long_description=long_desc,
        long_description_content_type='text/markdown',
        url='https://github.com/ClickHouse/clickhouse-connect',
        packages=find_packages(exclude=['tests*']),
        python_requires='>=3.9,<3.15',
        license='Apache License 2.0',
        install_requires=[
            'certifi',
            'urllib3>=1.26',
            'pytz',
            'zstandard; python_version<"3.14"',
            'zstandard>=0.25.0; python_version>="3.14"',
            'lz4; python_version<"3.14"',
            'lz4>=4.4.5; python_version>="3.14"'
        ],
        extras_require={
            'sqlalchemy': ['sqlalchemy>=1.4.40,<3.0'],
            'numpy': ['numpy'],
            'pandas': ['pandas<3'],
            'polars': ['polars>=1.0'],
            'arrow': ['pyarrow>=22.0; python_version>="3.14"', 'pyarrow; python_version<"3.14"'],
            'orjson': ['orjson'],
            'tzlocal': ['tzlocal>=4.0'],
        },
        tests_require=['pytest'],
        entry_points={
            'sqlalchemy.dialects': ['clickhousedb.connect=clickhouse_connect.cc_sqlalchemy.dialect:ClickHouseDialect',
                                    'clickhousedb=clickhouse_connect.cc_sqlalchemy.dialect:ClickHouseDialect']
        },
        classifiers=[
            'Development Status :: 4 - Beta',
            'Intended Audience :: Developers',
            'License :: OSI Approved :: Apache Software License',
            'Programming Language :: Python :: 3.9',
            'Programming Language :: Python :: 3.10',
            'Programming Language :: Python :: 3.11',
            'Programming Language :: Python :: 3.12',
            'Programming Language :: Python :: 3.13',
            'Programming Language :: Python :: 3.14',
        ],
        **kwargs
    )


try:
    run_setup()
# pylint: disable=broad-exception-caught
except (Exception, IOError, SystemExit) as e:
    print(f'Unable to compile C extensions for faster performance due to {e}, will use pure Python')
    run_setup(False)
