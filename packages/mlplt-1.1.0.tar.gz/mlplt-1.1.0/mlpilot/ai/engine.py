"""
mlpilot/ai/engine.py
Shared zero-config engine for local LLM fallback.
"""

from __future__ import annotations

import os
import sys
from typing import Optional

# Global cache to persist the model across different components
_MODEL_CACHE = {}

def call_builtin_llm(prompt: str, system_prompt: str = "You are a professional data scientist.") -> Optional[str]:
    """
    Universally shared zero-config fallback engine.
    Uses Qwen2.5-0.5B-Instruct (local-first).
    """
    global _MODEL_CACHE
    try:
        import torch
        import transformers
        # ABSOLUTE SILENCE: Force HF to be quiet even if env vars fail
        from huggingface_hub.utils import disable_progress_bars
        disable_progress_bars()
        
        from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
        transformers.logging.set_verbosity_error()
        
        # Stricter instructions for the tiny model
        if "Python code" in system_prompt:
             system_prompt += " Output ONLY clean Python code. No conversational text, no markers, no markdown. Start directly with the first line of code."

        if "pipeline" not in _MODEL_CACHE:
            model_id = "Qwen/Qwen2.5-0.5B-Instruct"
            device = "cuda" if torch.cuda.is_available() else "cpu"
            
            tokenizer = AutoTokenizer.from_pretrained(model_id)
            model = AutoModelForCausalLM.from_pretrained(
                model_id,
                dtype=torch.float32 if device == "cpu" else torch.float16,
                low_cpu_mem_usage=True
            ).to(device)
            
            _MODEL_CACHE["pipeline"] = pipeline(
                "text-generation",
                model=model,
                tokenizer=tokenizer,
                device=device
            )

        pipe = _MODEL_CACHE["pipeline"]
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ]
        
        p = pipe.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        
        outputs = pipe(
            p,
            max_new_tokens=512,
            do_sample=False,
            pad_token_id=pipe.tokenizer.eos_token_id
        )
        
        return outputs[0]["generated_text"][len(p):].strip()
    except Exception:
        return None
