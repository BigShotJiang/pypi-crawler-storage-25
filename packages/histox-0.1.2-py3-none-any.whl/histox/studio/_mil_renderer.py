import numpy as np
import histox as hx
from typing import Optional
from rich import print

from ._renderer import Renderer
from histox.model.extractors import rebuild_extractor

# -----------------------------------------------------------------------------

if hx.util.tf_available:
    import tensorflow as tf
    import histox.io.tensorflow
    hx.util.allow_gpu_memory_growth()
if hx.util.torch_available:
    import torch
    import torchvision
    import histox.io.torch

# -----------------------------------------------------------------------------

class MILRenderer(Renderer):

    def __init__(self, *args, mil_model_path: Optional[str] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.mil_model = None
        self.mil_config = None
        self.extractor = None
        self.normalizer = None
        if mil_model_path:
            self.load_model(mil_model_path)

    def load_model(self, mil_model_path: str, device: Optional[str] = None) -> None:
        hx.log.info("Loading MIL model at {}".format(mil_model_path))
        if device is None:
            from histox.model import torch_utils
            device = torch_utils.get_device()
        self.device = device
        self.extractor, self.normalizer = rebuild_extractor(
            mil_model_path, native_normalizer=(hx.slide_backend()=='cucim')
        )
        self.mil_model, self.mil_config = hx.mil.utils.load_model_weights(mil_model_path)
        self.mil_model.to(self.device)
        self._model = self.mil_model
        hx.log.info("Model loading successful")

    def _convert_img_to_bag(self, img, res):
        """Convert an image into bag format."""
        if self.extractor.backend == 'torch':
            dtype = torch.uint8
        else:
            dtype = tf.uint8
        img = np.expand_dims(img, 0)
        img = hx.io.convert_dtype(img, dtype=dtype)
        if self.normalizer:
            img  = self.normalizer.transform(img)
            if self.extractor.backend == 'torch':
                img = img.to(torch.uint8)
                res.normalized = hx.io.torch.as_whc(img[0]).cpu().numpy()
            else:
                img = tf.cast(img, tf.uint8)
                res.normalized = hx.io.convert_dtype(img[0], np.uint8)
        if self.extractor.backend == 'torch':
            img = img.to(self.device)
        bag = self.extractor(img)
        return bag

    def _predict_bag(self, bag, attention=False):
        """Generate MIL predictions from bag."""

        # Convert to torch tensor
        if hx.util.tf_available and isinstance(bag, tf.Tensor):
            bag = bag.numpy()
        if isinstance(bag, np.ndarray):
            bag = torch.from_numpy(bag)

        # Add a batch dimension & send to GPU
        bag = torch.unsqueeze(bag, dim=0)
        bag = bag.to(self.device)

        # Run model
        preds, att = self.mil_config.predict(
            self.mil_model,
            bag,
            attention=attention,
            device=self.device,
            attention_pooling='avg'
        )
        return preds, att

    def _run_models(
        self,
        img,
        res,
        focus_img=None,
        assess_focus=None,
        **kwargs
    ):
        """Generate an MIL single-bag prediction."""
        # Check focus.
        if focus_img is not None:
            res.in_focus = self._image_in_focus(focus_img, method=assess_focus)
            if not res.in_focus:
                return

        bag = self._convert_img_to_bag(img, res)
        preds, att = self._predict_bag(bag, attention=True)
        if isinstance(att, list):
            if len(att):
                att = np.stack(att)
            else:
                att = None
        if att is not None and len(att.shape):
            att = np.mean(att)
        res.predictions = preds[0]
        res.uncertainty = None if att is None else att

    def _render_impl(self, res, *args, **kwargs):
        if self.mil_model is not None:
            kwargs['use_model'] = True
        super()._render_impl(res, *args, **kwargs)


class MultimodalMILRenderer(Renderer):

    def __init__(self, *args, mil_model_path: Optional[str] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.mil_model = None
        self.mil_config = None

    def load_model(self, mil_model_path: str, device: Optional[str] = None) -> None:
        print("Not loading multimodal MIL model.")

    def _run_models(*args, **kwargs):
        print("Not running multimodal MIL model.")
