"""Tests for PTM_SSL_VERIFY env var + verify_ssl kwarg (v0.6.1)."""

from __future__ import annotations

import pytest

from ptm_client import PTMClient

BASE = "http://ptm.test"
TOKEN = "ptm_u_testtoken"


@pytest.fixture
def clean_ssl_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("PTM_SSL_VERIFY", raising=False)


def test_default_verifies_certificates(clean_ssl_env: None) -> None:
    client = PTMClient(BASE, TOKEN)
    assert client._verify is True


def test_env_var_false_disables_verification(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PTM_SSL_VERIFY", "false")
    client = PTMClient(BASE, TOKEN)
    assert client._verify is False


@pytest.mark.parametrize("falsy", ["false", "FALSE", "0", "no", "off"])
def test_env_var_falsy_variants(monkeypatch: pytest.MonkeyPatch, falsy: str) -> None:
    monkeypatch.setenv("PTM_SSL_VERIFY", falsy)
    client = PTMClient(BASE, TOKEN)
    assert client._verify is False


@pytest.mark.parametrize("truthy", ["true", "TRUE", "1", "yes", "on", "anything"])
def test_env_var_truthy_variants(monkeypatch: pytest.MonkeyPatch, truthy: str) -> None:
    monkeypatch.setenv("PTM_SSL_VERIFY", truthy)
    client = PTMClient(BASE, TOKEN)
    assert client._verify is True


def test_kwarg_overrides_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PTM_SSL_VERIFY", "false")
    client = PTMClient(BASE, TOKEN, verify_ssl=True)
    assert client._verify is True


def test_kwarg_disables_when_env_unset(clean_ssl_env: None) -> None:
    client = PTMClient(BASE, TOKEN, verify_ssl=False)
    assert client._verify is False
