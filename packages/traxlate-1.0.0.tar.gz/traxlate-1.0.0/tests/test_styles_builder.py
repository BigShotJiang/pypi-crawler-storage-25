"""Regression tests for tts_styles_builder gender filtering.

Specifically guards against the helium-voice bug where unknown-gender
Piper voices ended up surfaced under female cast voices and played as
male audio at synth time."""
from __future__ import annotations
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# Allow running from tests/ subdir as well as repo root.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import tts_styles_builder as tsb

passed = 0
failed = 0


def check(name: str, ok: bool, detail: str = "") -> None:
    global passed, failed
    if ok:
        print(f"  ✓ {name}")
        passed += 1
    else:
        print(f"  ✗ {name}    {detail}")
        failed += 1


def section(t: str) -> None:
    print()
    print(f"── {t} " + "─" * (66 - len(t)))


section("_candidate_gender — unknown Piper is NOT neutral")
# When a Piper voice is not in the gender map, we MUST return "unknown",
# not "neutral", so it doesn't slip into a female list and play as male.
pmap = {"fa_IR-ganji-medium": "female",
        "fa_IR-gyro-medium":  "male"}
check("known female Piper voice → 'female'",
      tsb._candidate_gender("piper", "fa_IR-ganji-medium", pmap) == "female")
check("known male Piper voice → 'male'",
      tsb._candidate_gender("piper", "fa_IR-gyro-medium", pmap) == "male")
check("UNKNOWN Piper voice → 'unknown' (not 'neutral')",
      tsb._candidate_gender("piper", "fa", pmap) == "unknown",
      detail=f"got {tsb._candidate_gender('piper', 'fa', pmap)!r}")
check("Supertonic always 'neutral' (true multi-speaker)",
      tsb._candidate_gender("supertonic", "fa", pmap) == "neutral")
check("MMS always 'neutral'",
      tsb._candidate_gender("mms", "fa", pmap) == "neutral")
check("Kokoro always 'neutral'",
      tsb._candidate_gender("kokoro", "en-us", pmap) == "neutral")


section("build_styles_for_lang — unknown Piper dropped from gender lists")
candidates = [
    {"engine": "piper", "arg": "fa_IR-ganji-medium", "score": 0.86},  # female
    {"engine": "piper", "arg": "fa_IR-gyro-medium",  "score": 0.87},  # male
    {"engine": "piper", "arg": "fa",                  "score": 0.82},  # UNKNOWN — must NOT leak into female
    {"engine": "supertonic", "arg": "fa",             "score": 0.84},  # neutral, OK for both
]
entry = tsb.build_styles_for_lang(candidates, pmap)
female = entry.get("female", [])
male = entry.get("male", [])
# Female list should contain ganji (female) + supertonic (neutral),
# NOT "fa" Piper unknown.
female_args = [(it["engine"], it["arg"]) for it in female]
check("female list contains ganji-medium",
      ("piper", "fa_IR-ganji-medium") in female_args)
check("female list contains supertonic",
      ("supertonic", "fa") in female_args)
check("female list does NOT contain unknown-gender Piper 'fa'",
      ("piper", "fa") not in female_args,
      detail=f"female_args={female_args}")
check("male list contains gyro-medium",
      ("piper", "fa_IR-gyro-medium") in [(it["engine"], it["arg"]) for it in male])
check("male list contains supertonic",
      ("supertonic", "fa") in [(it["engine"], it["arg"]) for it in male])
check("male list does NOT contain unknown-gender Piper 'fa'",
      ("piper", "fa") not in [(it["engine"], it["arg"]) for it in male],
      detail=f"male_args={[(it['engine'], it['arg']) for it in male]}")


section("styles_for — runtime defence against stale data")
# Simulate a stale overrides_auto.json where someone previously tagged a
# Piper voice as 'neutral' (the bug we are fixing) and put it into the
# female list. The runtime filter must drop it before serving.
stale_overrides = {
    "fa": {
        "female": [
            {"engine": "piper", "arg": "fa_IR-ganji-medium",
             "gender": "female", "score": 0.86, "label": "Ganji"},
            # The bug: Piper voice tagged 'neutral' but actually male at runtime
            {"engine": "piper", "arg": "fa",
             "gender": "neutral", "score": 0.82, "label": "Piper fa"},
            # Engine-level neutral (Supertonic) — must STAY
            {"engine": "supertonic", "arg": "fa",
             "gender": "neutral", "score": 0.84, "label": "Premium"},
        ],
        "male": [
            {"engine": "piper", "arg": "fa_IR-gyro-medium",
             "gender": "male", "score": 0.87, "label": "Gyro"},
            {"engine": "piper", "arg": "fa",
             "gender": "neutral", "score": 0.82, "label": "Piper fa"},
        ],
    }
}
result_female = tsb.styles_for(stale_overrides, "fa", "female")
result_male = tsb.styles_for(stale_overrides, "fa", "male")
result_unknown_cast = tsb.styles_for(stale_overrides, "fa", None)

fem_args = [(it["engine"], it["arg"]) for it in result_female]
check("female cast: bad Piper-neutral 'fa' stripped at runtime",
      ("piper", "fa") not in fem_args,
      detail=f"female result: {fem_args}")
check("female cast: legit female-tagged Piper kept",
      ("piper", "fa_IR-ganji-medium") in fem_args)
check("female cast: engine-level neutral (Supertonic) kept",
      ("supertonic", "fa") in fem_args)

male_args = [(it["engine"], it["arg"]) for it in result_male]
check("male cast: bad Piper-neutral 'fa' stripped at runtime",
      ("piper", "fa") not in male_args,
      detail=f"male result: {male_args}")
check("male cast: legit male-tagged Piper kept",
      ("piper", "fa_IR-gyro-medium") in male_args)


section("_gender_safe_for_cast — explicit predicate truth table")
g = tsb._gender_safe_for_cast
check("no cast constraint → anything passes",
      g({"engine": "piper", "gender": "unknown"}, None))
check("matching female Piper → pass",
      g({"engine": "piper", "gender": "female"}, "female"))
check("matching male Piper → pass",
      g({"engine": "piper", "gender": "male"}, "male"))
check("Supertonic neutral under female cast → pass",
      g({"engine": "supertonic", "gender": "neutral"}, "female"))
check("Supertonic neutral under male cast → pass",
      g({"engine": "supertonic", "gender": "neutral"}, "male"))
check("Piper neutral under female cast → BLOCKED",
      not g({"engine": "piper", "gender": "neutral"}, "female"))
check("Piper unknown under female cast → BLOCKED",
      not g({"engine": "piper", "gender": "unknown"}, "female"))
check("Piper male under female cast → BLOCKED",
      not g({"engine": "piper", "gender": "male"}, "female"))
check("Piper female under male cast → BLOCKED",
      not g({"engine": "piper", "gender": "female"}, "male"))


print()
print("=" * 60)
print(f"passed: {passed}   failed: {failed}")
if failed == 0:
    print("✅ ALL TESTS PASSED")
    sys.exit(0)
print("❌ FAILED")
sys.exit(1)
