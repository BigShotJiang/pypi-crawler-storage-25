"""Self-test for tts_lang_specialists.py — runs OFFLINE.

We can't render actual audio without the engine + GPU, but we CAN verify:
  1. The sidecar imports cleanly (no syntax errors, no import-time crashes).
  2. EXTRA_LEXICON / EXTRA_SYMBOLS / EXTRA_SYMBOL_PATTERNS contain the
     entries we expect per language.
  3. The simulated preprocessor pass produces the right output for canonical
     sentences (catches regressions in expansion order, replacement bugs,
     dedup logic).
  4. Handler builders that don't require pip libs return correctly.
  5. install_into() against a stub parent module wires everything correctly.

Run with:  python -u tests/test_lang_specialists.py
Exit code 0 = all green; 1 = at least one failure.
"""
from __future__ import annotations

import os
import re
import sys
import types
from typing import Any

# Force UTF-8 on the Windows console so box-drawing chars + non-ASCII
# specimen text don't crash the test.
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))


# ── Test infrastructure ─────────────────────────────────────────────────
_PASS = 0
_FAIL = 0
_FAILURES: list[str] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    global _PASS, _FAIL
    if ok:
        _PASS += 1
        print(f"  ✓ {name}")
    else:
        _FAIL += 1
        msg = f"  ✗ {name}" + (f"   [{detail}]" if detail else "")
        print(msg)
        _FAILURES.append(name + (f": {detail}" if detail else ""))


def section(title: str) -> None:
    print(f"\n── {title} " + "─" * max(2, 60 - len(title)))


# ── Sidecar import + structure ─────────────────────────────────────────
section("sidecar import")
import tts_lang_specialists as spec  # noqa: E402

check("module imports without error",
      hasattr(spec, "install_into") and hasattr(spec, "get_handler"))
check("EXTRA_LEXICON exists and is a dict", isinstance(spec.EXTRA_LEXICON, dict))
check("EXTRA_SYMBOLS exists and is a dict", isinstance(spec.EXTRA_SYMBOLS, dict))
check("EXTRA_SYMBOL_PATTERNS exists and is a dict",
      isinstance(spec.EXTRA_SYMBOL_PATTERNS, dict))
check("_BUILDERS exists and is a dict", isinstance(spec._BUILDERS, dict))


# ── Stub parent module — emulates dub_engine_v2 for install_into() ─────
# Build a fake parent with the minimum surface area install_into needs.
section("install_into() against stub parent")


class _StubPreprocessor:
    """Minimal stub for parent's _TTSPreprocessor."""
    def __init__(self):
        self._handlers: dict = {}
        self._handler_tried: set = set()

    def _get_handler(self, base):  # original — sidecar should wrap this
        return None


_stub = types.SimpleNamespace(
    _TTS_LEXICON={"fa": {"X": "Y"}, "ar": {"Z": "W"}},  # some pre-existing
    _TTS_SYMBOL_EXPANSIONS={"de": [("DM", " D-Mark")]},
    _TTS_SYMBOL_PATTERNS={},
    tts_preprocessor=_StubPreprocessor(),
)

# Reset module-level install flag so we can call install fresh.
spec._INSTALLED = False
spec._StubPreprocessor = _StubPreprocessor  # not really needed but keeps lint happy
# Reset the class-level installed flag too (in case test runs multiple times)
if hasattr(_StubPreprocessor, "_sidecar_installed"):
    delattr(_StubPreprocessor, "_sidecar_installed")

spec.install_into(_stub)

check("install marked complete", spec._INSTALLED)
check("monkey-patch flag set on preprocessor class",
      getattr(_StubPreprocessor, "_sidecar_installed", False))
check("install_into is idempotent (second call no-op)",
      (spec.install_into(_stub) or True) and spec._INSTALLED)


# ── Helper: simulate the parent preprocessor pipeline ──────────────────
# Same logic as _TTSPreprocessor in dub_engine_v2.py, simplified for the
# parts we need to verify per language.
def _simulate_preprocess(lang: str, text: str, stub) -> str:
    """Apply (in order) lexicon → symbol patterns → symbol expansions.
    Mirrors the parent's preprocessor for the layers we override here."""
    base = lang.split("-")[0].lower()
    out = text

    # 1. Lexicon
    lex = stub._TTS_LEXICON.get(lang) or stub._TTS_LEXICON.get(base)
    if lex:
        for src, dst in lex.items():
            out = re.sub(rf"(?<!\w){re.escape(src)}(?!\w)", dst, out)

    # 2. Symbol patterns (regex)
    pats = (stub._TTS_SYMBOL_PATTERNS.get(lang)
            or stub._TTS_SYMBOL_PATTERNS.get(base))
    if pats:
        for pat, repl in pats:
            out = re.sub(pat, repl, out)

    # 3. Symbol expansions (literal substring)
    syms = (stub._TTS_SYMBOL_EXPANSIONS.get(lang)
            or stub._TTS_SYMBOL_EXPANSIONS.get(base))
    if syms:
        for sym, exp in syms:
            out = out.replace(sym, exp)
        out = re.sub(r"  +", " ", out)

    return out


# ═══════════════════════════════════════════════════════════════════════
# Per-language tests (alphabetical)
# ═══════════════════════════════════════════════════════════════════════


# ── af (Afrikaans) ─────────────────────────────────────────────────────
section("af — Afrikaans")

af_syms = dict(spec.EXTRA_SYMBOLS.get("af", []))
check("af percent expands to 'persent' (Afrikaans, NOT 'percent')",
      "persent" in af_syms.get("%", ""),
      detail=f"got: {af_syms.get('%')!r}")
check("af pound expands to 'pond'",
      "pond" in af_syms.get("£", ""))
check("af kg expands to 'kilogram'",
      "kilogram" in af_syms.get("kg", ""))
check("af Dr. expands to 'Dokter'",
      af_syms.get("Dr.") == "Dokter")
check("af Mev. expands to 'Mevrou'",
      af_syms.get("Mev.") == "Mevrou")
check("af bv. expands to 'byvoorbeeld'",
      af_syms.get("bv.") == "byvoorbeeld")

# End-to-end on a canonical Afrikaans sentence.
af_input  = "Dr. Botha het 5%, &, en 100 km gery. Dit kos R 50."
af_output = _simulate_preprocess("af", af_input, _stub)
check("af E2E: 'Dr.' → 'Dokter ' in pipeline output",
      "Dokter" in af_output,
      detail=f"out={af_output!r}")
check("af E2E: '%' → ' persent' applied",
      "persent" in af_output,
      detail=f"out={af_output!r}")
check("af E2E: 'km' → ' kilometer' applied",
      "kilometer" in af_output,
      detail=f"out={af_output!r}")

# ── ak (Akan / Twi) ────────────────────────────────────────────────────
section("ak — Akan / Twi")
ak_syms = dict(spec.EXTRA_SYMBOLS.get("ak", []))
check("ak percent uses Akan phrasing ('nkyem ɔha')",
      "nkyem" in ak_syms.get("%", ""))
check("ak '&' expands to ' ne '",
      ak_syms.get("&") == " ne ")


# ── am (Amharic) ───────────────────────────────────────────────────────
section("am — Amharic")
am_syms = dict(spec.EXTRA_SYMBOLS.get("am", []))
check("am percent expands to Amharic 'በመቶ'",
      "በመቶ" in am_syms.get("%", ""))
check("am $ expands to 'ዶላር'",
      "ዶላር" in am_syms.get("$", ""))
check("am kg expands to 'ኪሎግራም'",
      "ኪሎግራም" in am_syms.get("kg", ""))
check("am has lexicon for Microsoft",
      spec.EXTRA_LEXICON.get("am", {}).get("Microsoft") == "ማይክሮሶፍት")

# Verify am handler converts Ge'ez digits → ASCII
am_handler = spec.get_handler("am")
check("am handler builds (no pip dep needed)", am_handler is not None)
if am_handler:
    check("am handler: '፫ ሰዓት' → '3 ሰዓት'",
          am_handler("፫ ሰዓት") == "3 ሰዓት",
          detail=f"got {am_handler('፫ ሰዓት')!r}")
    check("am handler: multi-digit '፪፻' → '210' (concat OK; reader still TODO)",
          "2" in am_handler("፪፻") and "100" in am_handler("፪፻"),
          detail=f"got {am_handler('፪፻')!r}")


# ── ar (Arabic) ────────────────────────────────────────────────────────
section("ar — Arabic")
ar_lex = spec.EXTRA_LEXICON.get("ar", {})
check("ar lexicon has WhatsApp → واتساب",
      ar_lex.get("WhatsApp") == "واتساب")
check("ar lexicon has TikTok → تيك توك",
      ar_lex.get("TikTok") == "تيك توك")
check("ar lexicon has ChatGPT",
      "ChatGPT" in ar_lex)
check("ar lexicon has at least 15 entries",
      len(ar_lex) >= 15, detail=f"got {len(ar_lex)}")

ar_syms = dict(spec.EXTRA_SYMBOLS.get("ar", []))
check("ar m² → 'متر مربع'",
      ar_syms.get("m²") == " متر مربع")
check("ar °C → 'درجة مئوية'",
      ar_syms.get("°C") == " درجة مئوية")
check("ar AM/PM → 'صباحاً' / 'مساءً'",
      "صباح" in ar_syms.get("AM", "") and "مساء" in ar_syms.get("PM", ""))

# Handler: mishkal may or may not be installed locally. Either outcome is
# acceptable; the sidecar shipped what it could.
ar_handler = spec.get_handler("ar")
if ar_handler is None:
    print("    [info] mishkal/camel-tools not installed locally — handler "
          "will be None until pip install on the server. This is expected "
          "for dev environments.")
    check("ar handler safely None when deps missing", True)
else:
    # Smoke: handler should run on real Arabic without raising.
    sample = "كتب الولد الدرس"
    out = ar_handler(sample)
    check("ar handler runs without raising on Arabic text",
          isinstance(out, str) and len(out) > 0,
          detail=f"out={out!r}")


# ── az (Azerbaijani) ───────────────────────────────────────────────────
section("az — Azerbaijani")
az_syms = dict(spec.EXTRA_SYMBOLS.get("az", []))
check("az % → 'faiz'", az_syms.get("%") == " faiz")
check("az manat (AZN) currency",
      "manat" in az_syms.get("AZN", ""))
check("az lexicon has YouTube → 'Yutub'",
      spec.EXTRA_LEXICON.get("az", {}).get("YouTube") == "Yutub")


# ── bg (Bulgarian) ─────────────────────────────────────────────────────
section("bg — Bulgarian")
bg_syms = dict(spec.EXTRA_SYMBOLS.get("bg", []))
check("bg % → 'процента'", "процента" in bg_syms.get("%", ""))
check("bg BGN → 'лева'", "лева" in bg_syms.get("BGN", ""))
check("bg lexicon has Google → 'Гугъл'",
      spec.EXTRA_LEXICON.get("bg", {}).get("Google") == "Гугъл")


# ── bm (Bambara) ───────────────────────────────────────────────────────
section("bm — Bambara")
bm_syms = dict(spec.EXTRA_SYMBOLS.get("bm", []))
check("bm % uses Bambara phrasing",
      "kɛmɛsara" in bm_syms.get("%", ""))


# ── bn (Bengali) ───────────────────────────────────────────────────────
section("bn — Bengali")
bn_syms = dict(spec.EXTRA_SYMBOLS.get("bn", []))
check("bn % → 'শতাংশ'", "শতাংশ" in bn_syms.get("%", ""))
check("bn lexicon has YouTube → 'ইউটিউব'",
      spec.EXTRA_LEXICON.get("bn", {}).get("YouTube") == "ইউটিউব")

bn_handler = spec.get_handler("bn")
check("bn number-reader handler builds", bn_handler is not None)
if bn_handler:
    check("bn '5' → 'পাঁচ'",
          bn_handler("5") == "পাঁচ",
          detail=f"got {bn_handler('5')!r}")
    check("bn '100' → 'এক শত'",
          "এক" in bn_handler("100") and "শত" in bn_handler("100"),
          detail=f"got {bn_handler('100')!r}")
    check("bn '1000' → contains 'হাজার'",
          "হাজার" in bn_handler("1000"),
          detail=f"got {bn_handler('1000')!r}")
    check("bn '100000' → contains 'লক্ষ' (lakh, Indian numbering)",
          "লক্ষ" in bn_handler("100000"),
          detail=f"got {bn_handler('100000')!r}")


# ── ca (Catalan) ───────────────────────────────────────────────────────
section("ca — Catalan")
ca_syms = dict(spec.EXTRA_SYMBOLS.get("ca", []))
check("ca % → 'per cent'", "per cent" in ca_syms.get("%", ""))
check("ca m² → 'metres quadrats'",
      "metres quadrats" in ca_syms.get("m²", ""))


# ── cs (Czech) ─────────────────────────────────────────────────────────
section("cs — Czech")
cs_syms = dict(spec.EXTRA_SYMBOLS.get("cs", []))
check("cs % → 'procent'", "procent" in cs_syms.get("%", ""))
check("cs CZK → 'korun českých'",
      "korun" in cs_syms.get("CZK", ""))
check("cs tj. → 'to jest'", cs_syms.get("tj.") == " to jest")
check("cs lexicon: iPhone → 'ajfón' (Czech phonetic)",
      spec.EXTRA_LEXICON.get("cs", {}).get("iPhone") == "ajfón")


# ── cy (Welsh) ─────────────────────────────────────────────────────────
section("cy — Welsh")
cy_syms = dict(spec.EXTRA_SYMBOLS.get("cy", []))
check("cy % → 'y cant'", "y cant" in cy_syms.get("%", ""))
check("cy & → 'a'", cy_syms.get("&") == " a ")

cy_handler = spec.get_handler("cy")
check("cy number-reader handler builds", cy_handler is not None)
if cy_handler:
    check("cy '5' → 'pump'",
          cy_handler("5") == "pump",
          detail=f"got {cy_handler('5')!r}")
    check("cy '20' → 'dau ddeg' (modern decimal)",
          cy_handler("20") == "dau ddeg",
          detail=f"got {cy_handler('20')!r}")
    check("cy '100' → 'cant'",
          cy_handler("100") == "cant",
          detail=f"got {cy_handler('100')!r}")
    check("cy '1000' → 'mil'",
          cy_handler("1000") == "mil",
          detail=f"got {cy_handler('1000')!r}")


# ── da (Danish) ────────────────────────────────────────────────────────
section("da — Danish")
da_syms = dict(spec.EXTRA_SYMBOLS.get("da", []))
check("da % → 'procent'", "procent" in da_syms.get("%", ""))
check("da DKK → 'kroner'", "kroner" in da_syms.get("DKK", ""))
check("da osv. → 'og så videre'", da_syms.get("osv.") == " og så videre")


# ── de (German) ────────────────────────────────────────────────────────
section("de — German")
de_syms = dict(spec.EXTRA_SYMBOLS.get("de", []))
check("de Mio. → 'Millionen'", "Millionen" in de_syms.get("Mio.", ""))
check("de Mrd. → 'Milliarden'", "Milliarden" in de_syms.get("Mrd.", ""))
check("de z.B. → 'zum Beispiel'", de_syms.get("z.B.") == " zum Beispiel")
check("de kWh → 'Kilowattstunden'",
      "Kilowattstunden" in de_syms.get("kWh", ""))
check("de lexicon has Telegram → 'Telegramm'",
      spec.EXTRA_LEXICON.get("de", {}).get("Telegram") == "Telegramm")


# ── ee (Ewe) ───────────────────────────────────────────────────────────
section("ee — Ewe")
ee_syms = dict(spec.EXTRA_SYMBOLS.get("ee", []))
check("ee & → 'kple'", ee_syms.get("&") == " kple ")


# ── el (Greek) ─────────────────────────────────────────────────────────
section("el — Greek")
el_syms = dict(spec.EXTRA_SYMBOLS.get("el", []))
check("el kg → 'κιλά'", "κιλά" in el_syms.get("kg", ""))
check("el π.χ. → 'παραδείγματος χάριν'",
      "παραδείγματος" in el_syms.get("π.χ.", ""))
check("el lexicon has Google → 'Γκουγκλ'",
      spec.EXTRA_LEXICON.get("el", {}).get("Google") == "Γκουγκλ")

el_handler = spec.get_handler("el")
check("el handler builds (polytonic-monotonic + optional accentor)",
      el_handler is not None)
if el_handler:
    # Polytonic → monotonic should ALWAYS work (no pip dep)
    check("el polytonic→monotonic: 'ἀγαθός' loses breathing mark",
          "ἀ" not in el_handler("ἀγαθός"),
          detail=f"got {el_handler('ἀγαθός')!r}")
    # Modern text passes through unchanged
    check("el modern Greek 'Καλημέρα' passes through",
          "Καλημέρα" in el_handler("Καλημέρα"),
          detail=f"got {el_handler('Καλημέρα')!r}")


# ── en (English) ───────────────────────────────────────────────────────
section("en — English")
en_syms = dict(spec.EXTRA_SYMBOLS.get("en", []))
check("en CHF → 'Swiss francs'", "Swiss" in en_syms.get("CHF", ""))
check("en mph → 'miles per hour'",
      "miles per hour" in en_syms.get("mph", ""))
check("en e.g. → 'for example'", en_syms.get("e.g.") == " for example")
check("en TB → 'terabytes'", "terabytes" in en_syms.get("TB", ""))
check("en lexicon has ChatGPT → 'Chat G P T'",
      spec.EXTRA_LEXICON.get("en", {}).get("ChatGPT") == "Chat G P T")
check("en lexicon has API → 'A P I'",
      spec.EXTRA_LEXICON.get("en", {}).get("API") == "A P I")
check("en lexicon has TikTok → 'Tick Tock'",
      spec.EXTRA_LEXICON.get("en", {}).get("TikTok") == "Tick Tock")


# ── es (Spanish) ───────────────────────────────────────────────────────
section("es — Spanish")
es_syms = dict(spec.EXTRA_SYMBOLS.get("es", []))
check("es m² → 'metros cuadrados'", "metros cuadrados" in es_syms.get("m²", ""))
check("es Sra. → 'señora'", "señora" in es_syms.get("Sra.", ""))
check("es Avda. → 'avenida'", "avenida" in es_syms.get("Avda.", ""))
check("es lexicon has WhatsApp → 'GuasáÁp'",
      spec.EXTRA_LEXICON.get("es", {}).get("WhatsApp") == "GuasáÁp")
# Dialect tables
es_mx_syms = dict(spec.EXTRA_SYMBOLS.get("es-mx", []))
check("es-mx $ → 'pesos' (Mexico default)",
      "pesos" in es_mx_syms.get("$", ""))


# ── et (Estonian) ──────────────────────────────────────────────────────
section("et — Estonian")
et_syms = dict(spec.EXTRA_SYMBOLS.get("et", []))
check("et % → 'protsenti'", "protsenti" in et_syms.get("%", ""))
check("et jne. → 'ja nii edasi'", et_syms.get("jne.") == " ja nii edasi")


# ── eu (Basque) ────────────────────────────────────────────────────────
section("eu — Basque")
eu_syms = dict(spec.EXTRA_SYMBOLS.get("eu", []))
check("eu % → 'ehuneko'", "ehuneko" in eu_syms.get("%", ""))

eu_handler = spec.get_handler("eu")
check("eu number-reader handler builds", eu_handler is not None)
if eu_handler:
    check("eu '5' → 'bost'", eu_handler("5") == "bost",
          detail=f"got {eu_handler('5')!r}")
    check("eu '20' → 'hogei'", eu_handler("20") == "hogei",
          detail=f"got {eu_handler('20')!r}")
    check("eu '30' → 'hogeita hamar' (Basque vigesimal)",
          eu_handler("30") == "hogeita hamar",
          detail=f"got {eu_handler('30')!r}")
    # 100+ deliberately passes through to engine phonemizer (handler
    # used to read it digit-by-digit as "bat zero zero" which is wrong).
    check("eu '100' passes through to engine (Basque grammar deferred)",
          eu_handler("100") == "100",
          detail=f"got {eu_handler('100')!r}")
    check("eu '1234' passes through to engine",
          eu_handler("1234") == "1234",
          detail=f"got {eu_handler('1234')!r}")
    # Mixed text still converts 0-99 numbers it can handle.
    check("eu mixed text: '5 eta 100' → 'bost eta 100' (5 converted, 100 not)",
          eu_handler("5 eta 100") == "bost eta 100",
          detail=f"got {eu_handler('5 eta 100')!r}")


# ── fa (Persian) ───────────────────────────────────────────────────────
section("fa — Persian")
fa_lex = spec.EXTRA_LEXICON.get("fa", {})
check("fa lexicon has WhatsApp → 'واتساپ'",
      fa_lex.get("WhatsApp") == "واتساپ")
check("fa lexicon has ChatGPT → 'چت جی پی تی'",
      fa_lex.get("ChatGPT") == "چت جی پی تی")
check("fa lexicon has ≥ 15 new entries (beyond parent)",
      len(fa_lex) >= 15, detail=f"got {len(fa_lex)}")

fa_syms = dict(spec.EXTRA_SYMBOLS.get("fa", []))
check("fa Persian semicolon ؛ → '، '", fa_syms.get("؛") == "، ")
check("fa m² → 'متر مربع'", "متر مربع" in fa_syms.get("m²", ""))
check("fa °C → 'درجه سانتی‌گراد'",
      "سانتی‌گراد" in fa_syms.get("°C", ""))

fa_handler = spec.get_handler("fa")
if fa_handler is None:
    print("    [info] parsivar not installed locally — parent's hazm "
          "specialist will run instead. Expected in dev environments.")
    check("fa handler safely None when parsivar missing", True)
else:
    sample = "می‌خوام برم خونه"
    out = fa_handler(sample)
    check("fa parsivar handler runs without raising",
          isinstance(out, str) and len(out) > 0,
          detail=f"out={out!r}")


# ── ff (Fula) ──────────────────────────────────────────────────────────
section("ff — Fula")
ff_syms = dict(spec.EXTRA_SYMBOLS.get("ff", []))
check("ff & → 'e'", ff_syms.get("&") == " e ")


# ── fi (Finnish) ───────────────────────────────────────────────────────
section("fi — Finnish")
fi_syms = dict(spec.EXTRA_SYMBOLS.get("fi", []))
check("fi % → 'prosenttia'", "prosenttia" in fi_syms.get("%", ""))
check("fi esim. → 'esimerkiksi'", fi_syms.get("esim.") == " esimerkiksi")


# ── fr (French) ────────────────────────────────────────────────────────
section("fr — French")
fr_syms = dict(spec.EXTRA_SYMBOLS.get("fr", []))
check("fr m² → 'mètres carrés'", "mètres carrés" in fr_syms.get("m²", ""))
check("fr Mme → 'Madame'", "Madame" in fr_syms.get("Mme", ""))
check("fr p.ex. → 'par exemple'", fr_syms.get("p.ex.") == " par exemple")
check("fr lexicon has ChatGPT → 'Tchat G P T'",
      spec.EXTRA_LEXICON.get("fr", {}).get("ChatGPT") == "Tchat G P T")


# ── ga (Irish) ─────────────────────────────────────────────────────────
section("ga — Irish")
ga_syms = dict(spec.EXTRA_SYMBOLS.get("ga", []))
check("ga % → 'faoin gcéad'", "faoin gcéad" in ga_syms.get("%", ""))
check("ga srl. → 'agus araile'", ga_syms.get("srl.") == " agus araile")


# ── gl (Galician) ──────────────────────────────────────────────────────
section("gl — Galician")
gl_syms = dict(spec.EXTRA_SYMBOLS.get("gl", []))
check("gl % → 'por cento'", "por cento" in gl_syms.get("%", ""))
check("gl Sra. → 'señora'", "señora" in gl_syms.get("Sra.", ""))


# ── gu (Gujarati) ──────────────────────────────────────────────────────
section("gu — Gujarati")
gu_syms = dict(spec.EXTRA_SYMBOLS.get("gu", []))
check("gu % → 'ટકા'", "ટકા" in gu_syms.get("%", ""))
check("gu lexicon: Google → 'ગુગલ'",
      spec.EXTRA_LEXICON.get("gu", {}).get("Google") == "ગુગલ")

gu_handler = spec.get_handler("gu")
check("gu number-reader builds", gu_handler is not None)
if gu_handler:
    check("gu Gujarati digit '૫' → ASCII '5' then 'પાંચ'",
          gu_handler("૫") == "પાંચ", detail=f"got {gu_handler('૫')!r}")
    check("gu '100000' → contains 'લાખ' (lakh)",
          "લાખ" in gu_handler("100000"),
          detail=f"got {gu_handler('100000')!r}")


# ── ha (Hausa) ─────────────────────────────────────────────────────────
section("ha — Hausa")
ha_syms = dict(spec.EXTRA_SYMBOLS.get("ha", []))
check("ha % → 'kashi cikin ɗari'", "kashi" in ha_syms.get("%", ""))


# ── he (Hebrew) ────────────────────────────────────────────────────────
section("he — Hebrew")
he_syms = dict(spec.EXTRA_SYMBOLS.get("he", []))
check("he % → 'אחוז'", "אחוז" in he_syms.get("%", ""))
check("he NIS → 'שקלים'", "שקלים" in he_syms.get("NIS", ""))
check("he °C → 'מעלות צלזיוס'",
      "מעלות" in he_syms.get("°C", ""))
check("he lexicon has Google → 'גוגל'",
      spec.EXTRA_LEXICON.get("he", {}).get("Google") == "גוגל")
check("he lexicon has WhatsApp → 'ווטסאפ'",
      spec.EXTRA_LEXICON.get("he", {}).get("WhatsApp") == "ווטסאפ")

# Validator: must accept Hebrew-with-nikud, reject IPA, reject Latin.
_v = spec._is_hebrew_with_nikud
check("he validator accepts שָׁלוֹם (real nikud)", _v("שָׁלוֹם"))
check("he validator accepts vocalized sentence",
      _v("שָׁלוֹם, עוֹלָם!"))
check("he validator rejects bare consonants (no nikud)",
      not _v("שלום עולם"))
check("he validator rejects IPA output",  not _v("ʃˈlm ʕoˈlam"))
check("he validator rejects Latin output", not _v("shalom olam"))
check("he validator rejects empty string", not _v(""))
check("he validator rejects None-like garbage", not _v("???"))

he_handler = spec.get_handler("he")
if he_handler is None:
    print("    [info] no validated Hebrew backend installed locally — "
          "production behavior: MMS-heb pronounces raw consonants until "
          "transformers + dicta model (or nakdimon) is reachable.")
    check("he handler safely None when deps missing", True)
else:
    # Behavioral contract on production:
    #   (a) handler must never raise
    #   (b) handler must NEVER emit non-Hebrew (IPA leak) — this is the
    #       contract that protects MMS-heb from corrupted input
    #   (c) handler must pass through input that already has nikud
    sample = "שלום עולם"
    out = he_handler(sample)
    check("he handler runs without raising",
          isinstance(out, str) and len(out) > 0,
          detail=f"out={out!r}")
    check("he handler output is Hebrew (never IPA/Latin)",
          all(ord(c) < 0x80 or 0x0590 <= ord(c) <= 0x05FF
              or 0x2000 <= ord(c) <= 0x206F
              for c in out),
          detail=f"out={out!r}")
    already = "שָׁלוֹם, עוֹלָם"
    check("he handler is idempotent on already-vocalized input",
          he_handler(already) == already,
          detail=f"in={already!r} out={he_handler(already)!r}")


# ── hi (Hindi) ─────────────────────────────────────────────────────────
section("hi — Hindi")
hi_syms = dict(spec.EXTRA_SYMBOLS.get("hi", []))
check("hi INR → 'रुपये'", "रुपये" in hi_syms.get("INR", ""))
check("hi Smt. → 'श्रीमती'", "श्रीमती" in hi_syms.get("Smt.", ""))
check("hi lexicon has WhatsApp → 'व्हाट्सऐप'",
      spec.EXTRA_LEXICON.get("hi", {}).get("WhatsApp") == "व्हाट्सऐप")
check("hi lexicon ≥ 12 entries",
      len(spec.EXTRA_LEXICON.get("hi", {})) >= 12)


# ── hr (Croatian) ──────────────────────────────────────────────────────
section("hr — Croatian")
hr_syms = dict(spec.EXTRA_SYMBOLS.get("hr", []))
check("hr % → 'posto'", "posto" in hr_syms.get("%", ""))
check("hr npr. → 'na primjer'", hr_syms.get("npr.") == " na primjer")


# ── hu (Hungarian) ─────────────────────────────────────────────────────
section("hu — Hungarian")
hu_syms = dict(spec.EXTRA_SYMBOLS.get("hu", []))
check("hu pl. → 'például'", hu_syms.get("pl.") == " például")
check("hu HUF → 'forint'", "forint" in hu_syms.get("HUF", ""))


# ── id (Indonesian) ────────────────────────────────────────────────────
section("id — Indonesian")
id_syms = dict(spec.EXTRA_SYMBOLS.get("id", []))
check("id IDR → 'rupiah'", "rupiah" in id_syms.get("IDR", ""))
check("id dll. → 'dan lain-lain'", id_syms.get("dll.") == " dan lain-lain")


# ── ig (Igbo) ──────────────────────────────────────────────────────────
section("ig — Igbo")
ig_syms = dict(spec.EXTRA_SYMBOLS.get("ig", []))
check("ig & → 'na'", ig_syms.get("&") == " na ")


# ── is (Icelandic) ─────────────────────────────────────────────────────
section("is — Icelandic")
is_syms = dict(spec.EXTRA_SYMBOLS.get("is", []))
check("is % → 'prósent'", "prósent" in is_syms.get("%", ""))
check("is ISK → 'krónur'", "krónur" in is_syms.get("ISK", ""))
check("is o.s.frv. → 'og svo framvegis'",
      is_syms.get("o.s.frv.") == " og svo framvegis")
is_handler = spec.get_handler("is")
if is_handler is None:
    print("    [info] num2words not installed locally — Icelandic digits "
          "fall through to Piper-is's built-in reader until pip install.")
    check("is handler safely None when num2words missing", True)
else:
    out = is_handler("Það kostar 1234 krónur")
    check("is num handler runs without raising",
          isinstance(out, str) and len(out) > 0,
          detail=f"out={out!r}")
    check("is '1234' is converted (not still bare digits)",
          "1234" not in out, detail=f"out={out!r}")
    check("is text with no digits passes through unchanged",
          is_handler("Halló heimur") == "Halló heimur")
    # Decimal handling (period and comma separators both accepted).
    out_dot = is_handler("3.14")
    check("is decimal '3.14' uses 'komma'",
          "komma" in out_dot, detail=f"out={out_dot!r}")
    out_com = is_handler("2,5")
    check("is decimal '2,5' (comma separator) also handled",
          "komma" in out_com, detail=f"out={out_com!r}")


# ── it (Italian) ───────────────────────────────────────────────────────
section("it — Italian")
it_syms = dict(spec.EXTRA_SYMBOLS.get("it", []))
check("it Sig.ra → 'signora'", "signora" in it_syms.get("Sig.ra", ""))
check("it ecc. → 'eccetera'", it_syms.get("ecc.") == " eccetera")


# ── ja (Japanese) ──────────────────────────────────────────────────────
section("ja — Japanese")
ja_lex = spec.EXTRA_LEXICON.get("ja", {})
check("ja lexicon: WhatsApp → 'ワッツアップ'",
      ja_lex.get("WhatsApp") == "ワッツアップ")
check("ja lexicon: ChatGPT → 'チャットジーピーティー'",
      ja_lex.get("ChatGPT") == "チャットジーピーティー")
check("ja lexicon ≥ 15 entries", len(ja_lex) >= 15)

ja_syms = dict(spec.EXTRA_SYMBOLS.get("ja", []))
check("ja m² → '平方メートル'", "平方メートル" in ja_syms.get("m²", ""))
check("ja a.m. → '午前'", "午前" in ja_syms.get("a.m.", ""))

ja_handler = spec.get_handler("ja")
if ja_handler is None:
    print("    [info] pyopenjtalk not installed locally — Japanese will "
          "go through Supertonic-ja with raw kanji until pip install.")
    check("ja handler safely None when pyopenjtalk missing", True)
else:
    sample = "今日は天気が良いです"
    out = ja_handler(sample)
    check("ja pyopenjtalk handler runs without raising",
          isinstance(out, str) and len(out) > 0,
          detail=f"out={out!r}")


# ── jv (Javanese) ──────────────────────────────────────────────────────
section("jv — Javanese")
jv_syms = dict(spec.EXTRA_SYMBOLS.get("jv", []))
check("jv & → 'lan'", jv_syms.get("&") == " lan ")


# ── ka (Georgian) ──────────────────────────────────────────────────────
section("ka — Georgian")
ka_syms = dict(spec.EXTRA_SYMBOLS.get("ka", []))
check("ka GEL → 'ლარი'", "ლარი" in ka_syms.get("GEL", ""))
check("ka lexicon: Google → 'გუგლი'",
      spec.EXTRA_LEXICON.get("ka", {}).get("Google") == "გუგლი")


# ── kk (Kazakh) ────────────────────────────────────────────────────────
section("kk — Kazakh")
kk_syms = dict(spec.EXTRA_SYMBOLS.get("kk", []))
check("kk KZT → 'теңге'", "теңге" in kk_syms.get("KZT", ""))


# ── km (Khmer) ─────────────────────────────────────────────────────────
section("km — Khmer")
km_syms = dict(spec.EXTRA_SYMBOLS.get("km", []))
check("km KHR → 'រៀល'", "រៀល" in km_syms.get("KHR", ""))
check("km lexicon: YouTube → 'យូធូប'",
      spec.EXTRA_LEXICON.get("km", {}).get("YouTube") == "យូធូប")


# ── kn (Kannada) ───────────────────────────────────────────────────────
section("kn — Kannada")
kn_syms = dict(spec.EXTRA_SYMBOLS.get("kn", []))
check("kn % → 'ಪ್ರತಿಶತ'", "ಪ್ರತಿಶತ" in kn_syms.get("%", ""))

kn_handler = spec.get_handler("kn")
check("kn number-reader builds", kn_handler is not None)
if kn_handler:
    check("kn '5' → 'ಐದು'", kn_handler("5") == "ಐದು")
    check("kn Kannada digit '೫' → 'ಐದು'", kn_handler("೫") == "ಐದು")
    check("kn '100000' → contains 'ಲಕ್ಷ'",
          "ಲಕ್ಷ" in kn_handler("100000"))


# ── ko (Korean) ────────────────────────────────────────────────────────
section("ko — Korean")
ko_lex = spec.EXTRA_LEXICON.get("ko", {})
check("ko lexicon: WhatsApp → '왓츠앱'", ko_lex.get("WhatsApp") == "왓츠앱")
check("ko lexicon: ChatGPT → '챗 지피티'",
      ko_lex.get("ChatGPT") == "챗 지피티")
check("ko lexicon ≥ 12 entries", len(ko_lex) >= 12)

ko_syms = dict(spec.EXTRA_SYMBOLS.get("ko", []))
check("ko KRW → '원'", "원" in ko_syms.get("KRW", ""))
check("ko a.m. → '오전'", "오전" in ko_syms.get("a.m.", ""))

ko_handler = spec.get_handler("ko")
if ko_handler is None:
    print("    [info] g2pk not installed locally — Korean will go through "
          "Supertonic-ko with raw Hangul. Liaison/sandhi handled at engine.")
    check("ko handler safely None when g2pk missing", True)
else:
    sample = "한국말 잘 합니다"
    out = ko_handler(sample)
    check("ko g2pK handler runs without raising",
          isinstance(out, str) and len(out) > 0,
          detail=f"out={out!r}")


# ── ku (Kurdish) ───────────────────────────────────────────────────────
section("ku — Kurdish")
ku_syms = dict(spec.EXTRA_SYMBOLS.get("ku", []))
check("ku & → 'û'", ku_syms.get("&") == " û ")


# ── ky (Kyrgyz) ────────────────────────────────────────────────────────
section("ky — Kyrgyz")
ky_syms = dict(spec.EXTRA_SYMBOLS.get("ky", []))
check("ky KGS → 'сом'", "сом" in ky_syms.get("KGS", ""))


# ── lb (Luxembourgish) ─────────────────────────────────────────────────
section("lb — Luxembourgish")
lb_syms = dict(spec.EXTRA_SYMBOLS.get("lb", []))
check("lb asw. → 'a sou weider'", lb_syms.get("asw.") == " a sou weider")


# ── lg (Luganda) ───────────────────────────────────────────────────────
section("lg — Luganda")
lg_syms = dict(spec.EXTRA_SYMBOLS.get("lg", []))
check("lg & → 'ne'", lg_syms.get("&") == " ne ")


# ── lo (Lao) ───────────────────────────────────────────────────────────
section("lo — Lao")
lo_syms = dict(spec.EXTRA_SYMBOLS.get("lo", []))
check("lo LAK → 'ກີບ'", "ກີບ" in lo_syms.get("LAK", ""))

lo_handler = spec.get_handler("lo")
check("lo handler builds (digit reader always available)", lo_handler is not None)
if lo_handler:
    check("lo Lao digit '໕' → 'ຫ້າ'",
          "ຫ້າ" in lo_handler("໕"),
          detail=f"got {lo_handler('໕')!r}")
    check("lo '100' → contains 'ຮ້ອຍ'",
          "ຮ້ອຍ" in lo_handler("100"),
          detail=f"got {lo_handler('100')!r}")


# ── lt (Lithuanian) ────────────────────────────────────────────────────
section("lt — Lithuanian")
lt_syms = dict(spec.EXTRA_SYMBOLS.get("lt", []))
check("lt % → 'procentų'", "procentų" in lt_syms.get("%", ""))
check("lt pvz. → 'pavyzdžiui'", lt_syms.get("pvz.") == " pavyzdžiui")


# ── lv (Latvian) ───────────────────────────────────────────────────────
section("lv — Latvian")
lv_syms = dict(spec.EXTRA_SYMBOLS.get("lv", []))
check("lv % → 'procentu'", "procentu" in lv_syms.get("%", ""))
check("lv piem. → 'piemēram'", lv_syms.get("piem.") == " piemēram")


# ── mk (Macedonian) ────────────────────────────────────────────────────
section("mk — Macedonian")
mk_syms = dict(spec.EXTRA_SYMBOLS.get("mk", []))
check("mk MKD → 'денари'", "денари" in mk_syms.get("MKD", ""))


# ── ml (Malayalam) ─────────────────────────────────────────────────────
section("ml — Malayalam")
ml_handler = spec.get_handler("ml")
check("ml number-reader builds", ml_handler is not None)
if ml_handler:
    check("ml Malayalam digit '൫' → 'അഞ്ച്'",
          "അഞ്ച്" in ml_handler("൫"))
    check("ml '100000' → contains 'ലക്ഷം'",
          "ലക്ഷം" in ml_handler("100000"))


# ── mn (Mongolian) ─────────────────────────────────────────────────────
section("mn — Mongolian")
mn_syms = dict(spec.EXTRA_SYMBOLS.get("mn", []))
check("mn MNT → 'төгрөг'", "төгрөг" in mn_syms.get("MNT", ""))


# ── mr (Marathi) ───────────────────────────────────────────────────────
section("mr — Marathi")
mr_handler = spec.get_handler("mr")
check("mr number-reader builds", mr_handler is not None)
if mr_handler:
    check("mr '5' → 'पाच'", mr_handler("5") == "पाच")
    check("mr '100000' → contains 'लाख'", "लाख" in mr_handler("100000"))


# ── ms (Malay) ─────────────────────────────────────────────────────────
section("ms — Malay")
ms_syms = dict(spec.EXTRA_SYMBOLS.get("ms", []))
check("ms MYR → 'ringgit'", "ringgit" in ms_syms.get("MYR", ""))
check("ms dll. → 'dan lain-lain'", ms_syms.get("dll.") == " dan lain-lain")


# ── mt (Maltese) ───────────────────────────────────────────────────────
section("mt — Maltese")
mt_syms = dict(spec.EXTRA_SYMBOLS.get("mt", []))
check("mt eċċ. → 'eċċetera'", mt_syms.get("eċċ.") == " eċċetera")


# ── my (Burmese) ───────────────────────────────────────────────────────
section("my — Burmese")
my_syms = dict(spec.EXTRA_SYMBOLS.get("my", []))
check("my MMK → 'ကျပ်'", "ကျပ်" in my_syms.get("MMK", ""))

my_handler = spec.get_handler("my")
check("my handler builds (digit + number reader)", my_handler is not None)
if my_handler:
    check("my Burmese digit '၅' → 'ငါး'",
          "ငါး" in my_handler("၅"))
    check("my '100' → contains 'ရာ'",
          "ရာ" in my_handler("100"))


# ── ne (Nepali) ────────────────────────────────────────────────────────
section("ne — Nepali")
ne_handler = spec.get_handler("ne")
check("ne handler builds", ne_handler is not None)
if ne_handler:
    check("ne '5' → 'पाँच'", ne_handler("5") == "पाँच")


# ── nl (Dutch) ─────────────────────────────────────────────────────────
section("nl — Dutch")
nl_syms = dict(spec.EXTRA_SYMBOLS.get("nl", []))
check("nl bv. → 'bijvoorbeeld'", nl_syms.get("bv.") == " bijvoorbeeld")
check("nl Dhr. → 'heer'", "heer" in nl_syms.get("Dhr.", ""))


# ── no (Norwegian) ─────────────────────────────────────────────────────
section("no — Norwegian")
no_syms = dict(spec.EXTRA_SYMBOLS.get("no", []))
check("no NOK → 'kroner'", "kroner" in no_syms.get("NOK", ""))
no_handler = spec.get_handler("no")
if no_handler is None:
    print("    [info] num2words not installed locally — Norwegian digits "
          "fall through to Piper-no's built-in reader until pip install.")
    check("no handler safely None when num2words missing", True)
else:
    out = no_handler("Det koster 1234 kroner")
    check("no num handler runs without raising",
          isinstance(out, str) and len(out) > 0,
          detail=f"out={out!r}")
    check("no '1234' is converted (not still bare digits)",
          "1234" not in out, detail=f"out={out!r}")
    check("no text with no digits passes through unchanged",
          no_handler("Hei verden") == "Hei verden")
    # Decimal handling.
    out_dot = no_handler("3.14")
    check("no decimal '3.14' uses 'komma'",
          "komma" in out_dot, detail=f"out={out_dot!r}")
    out_com = no_handler("2,5")
    check("no decimal '2,5' (comma separator) also handled",
          "komma" in out_com, detail=f"out={out_com!r}")


# ── om (Oromo) ─────────────────────────────────────────────────────────
section("om — Oromo")
om_syms = dict(spec.EXTRA_SYMBOLS.get("om", []))
check("om & → 'fi'", om_syms.get("&") == " fi ")


# ── or (Odia) ──────────────────────────────────────────────────────────
section("or — Odia")
or_handler = spec.get_handler("or")
check("or handler builds", or_handler is not None)
if or_handler:
    check("or Odia digit '୫' → 'ପାଞ୍ଚ'",
          "ପାଞ୍ଚ" in or_handler("୫"))


# ── pa (Punjabi) ───────────────────────────────────────────────────────
section("pa — Punjabi")
pa_handler = spec.get_handler("pa")
check("pa handler builds", pa_handler is not None)
if pa_handler:
    check("pa Gurmukhi digit '੫' → 'ਪੰਜ'",
          "ਪੰਜ" in pa_handler("੫"))


# ── pl (Polish) ────────────────────────────────────────────────────────
section("pl — Polish")
pl_syms = dict(spec.EXTRA_SYMBOLS.get("pl", []))
check("pl PLN → 'złotych'", "złotych" in pl_syms.get("PLN", ""))
check("pl np. → 'na przykład'", pl_syms.get("np.") == " na przykład")


# ── ps (Pashto) ────────────────────────────────────────────────────────
section("ps — Pashto")
ps_handler = spec.get_handler("ps")
check("ps script-fix handler builds", ps_handler is not None)
if ps_handler:
    check("ps Persian digit '۵' → ASCII '5'",
          "5" in ps_handler("۵"),
          detail=f"got {ps_handler('۵')!r}")


# ── pt (Portuguese) ────────────────────────────────────────────────────
section("pt — Portuguese")
pt_syms = dict(spec.EXTRA_SYMBOLS.get("pt", []))
check("pt Sra. → 'senhora'", "senhora" in pt_syms.get("Sra.", ""))
pt_br_syms = dict(spec.EXTRA_SYMBOLS.get("pt-br", []))
check("pt-br R$ → 'reais'", "reais" in pt_br_syms.get("R$", ""))


# ── ro (Romanian) ──────────────────────────────────────────────────────
section("ro — Romanian")
ro_syms = dict(spec.EXTRA_SYMBOLS.get("ro", []))
check("ro RON → 'lei'", "lei" in ro_syms.get("RON", ""))


# ── ru (Russian) ───────────────────────────────────────────────────────
section("ru — Russian")
ru_lex = spec.EXTRA_LEXICON.get("ru", {})
check("ru lexicon WhatsApp → 'Ватсап'", ru_lex.get("WhatsApp") == "Ватсап")
check("ru lexicon ChatGPT → 'Чат ДЖиПиТи'",
      ru_lex.get("ChatGPT") == "Чат ДЖиПиТи")
check("ru lexicon ≥ 15 entries", len(ru_lex) >= 15)

ru_syms = dict(spec.EXTRA_SYMBOLS.get("ru", []))
check("ru RUB → 'рублей'", "рублей" in ru_syms.get("RUB", ""))
check("ru т.е. → 'то есть'", ru_syms.get("т.е.") == " то есть")

ru_handler = spec.get_handler("ru")
if ru_handler is None:
    print("    [info] ruaccent not installed locally — parent's russtress "
          "(~80% accuracy) will run instead. ruaccent gives ~96%.")
    check("ru handler safely None when ruaccent missing", True)
else:
    out = ru_handler("Привет мир")
    check("ru ruaccent handler runs",
          isinstance(out, str) and len(out) > 0)


# ── rw (Kinyarwanda) ───────────────────────────────────────────────────
section("rw — Kinyarwanda")
rw_syms = dict(spec.EXTRA_SYMBOLS.get("rw", []))
check("rw & → 'na'", rw_syms.get("&") == " na ")


# ── sd (Sindhi) ────────────────────────────────────────────────────────
section("sd — Sindhi")
sd_handler = spec.get_handler("sd")
check("sd script-fix handler builds", sd_handler is not None)
if sd_handler:
    check("sd Arabic digit '٥' → '5'",
          "5" in sd_handler("٥"))


# ── si (Sinhala) ───────────────────────────────────────────────────────
section("si — Sinhala")
si_syms = dict(spec.EXTRA_SYMBOLS.get("si", []))
check("si LKR → 'රුපියල්'", "රුපියල්" in si_syms.get("LKR", ""))


# ── sk (Slovak) ────────────────────────────────────────────────────────
section("sk — Slovak")
sk_syms = dict(spec.EXTRA_SYMBOLS.get("sk", []))
check("sk napr. → 'napríklad'", sk_syms.get("napr.") == " napríklad")


# ── sl (Slovenian) ─────────────────────────────────────────────────────
section("sl — Slovenian")
sl_syms = dict(spec.EXTRA_SYMBOLS.get("sl", []))
check("sl npr. → 'na primer'", sl_syms.get("npr.") == " na primer")


# ── sn (Shona) ─────────────────────────────────────────────────────────
section("sn — Shona")
sn_syms = dict(spec.EXTRA_SYMBOLS.get("sn", []))
check("sn & → 'ne'", sn_syms.get("&") == " ne ")


# ── so (Somali) ────────────────────────────────────────────────────────
section("so — Somali")
so_syms = dict(spec.EXTRA_SYMBOLS.get("so", []))
check("so & → 'iyo'", so_syms.get("&") == " iyo ")


# ── sq (Albanian) ──────────────────────────────────────────────────────
section("sq — Albanian")
sq_syms = dict(spec.EXTRA_SYMBOLS.get("sq", []))
check("sq p.sh. → 'për shembull'",
      sq_syms.get("p.sh.") == " për shembull")


# ── sr (Serbian) ───────────────────────────────────────────────────────
section("sr — Serbian")
sr_syms = dict(spec.EXTRA_SYMBOLS.get("sr", []))
check("sr RSD → 'динара'", "динара" in sr_syms.get("RSD", ""))

sr_handler = spec.get_handler("sr")
check("sr Latin→Cyrillic handler builds", sr_handler is not None)
if sr_handler:
    # Latin input → Cyrillic
    check("sr Latin 'Beograd' → contains Cyrillic 'Београд'",
          "Београд" in sr_handler("Beograd"),
          detail=f"got {sr_handler('Beograd')!r}")
    # Already-Cyrillic passes through
    check("sr Cyrillic 'Београд' passes through unchanged",
          sr_handler("Београд") == "Београд")
    # Digraph handling
    check("sr 'Ljubav' → 'Љубав'",
          "Љ" in sr_handler("Ljubav"),
          detail=f"got {sr_handler('Ljubav')!r}")


# ── st (Sesotho) ───────────────────────────────────────────────────────
section("st — Sesotho")
st_syms = dict(spec.EXTRA_SYMBOLS.get("st", []))
check("st & → 'le'", st_syms.get("&") == " le ")


# ── su (Sundanese) ─────────────────────────────────────────────────────
section("su — Sundanese")
su_syms = dict(spec.EXTRA_SYMBOLS.get("su", []))
check("su & → 'jeung'", su_syms.get("&") == " jeung ")


# ── sv (Swedish) ───────────────────────────────────────────────────────
section("sv — Swedish")
sv_syms = dict(spec.EXTRA_SYMBOLS.get("sv", []))
check("sv SEK → 'kronor'", "kronor" in sv_syms.get("SEK", ""))
check("sv t.ex. → 'till exempel'", sv_syms.get("t.ex.") == " till exempel")


# ── sw (Swahili) ───────────────────────────────────────────────────────
section("sw — Swahili")
sw_syms = dict(spec.EXTRA_SYMBOLS.get("sw", []))
check("sw KES → 'shilingi'", "shilingi" in sw_syms.get("KES", ""))


# ── ta (Tamil) ─────────────────────────────────────────────────────────
section("ta — Tamil")
ta_handler = spec.get_handler("ta")
check("ta handler builds", ta_handler is not None)
if ta_handler:
    check("ta Tamil digit '௫' → 'ஐந்து'",
          "ஐந்து" in ta_handler("௫"))
    check("ta '100000' → contains 'லட்சம்'",
          "லட்சம்" in ta_handler("100000"))


# ── te (Telugu) ────────────────────────────────────────────────────────
section("te — Telugu")
te_handler = spec.get_handler("te")
check("te handler builds", te_handler is not None)
if te_handler:
    check("te Telugu digit '౫' → 'ఐదు'",
          "ఐదు" in te_handler("౫"))


# ── tg (Tajik) ─────────────────────────────────────────────────────────
section("tg — Tajik")
tg_syms = dict(spec.EXTRA_SYMBOLS.get("tg", []))
check("tg TJS → 'сомонӣ'", "сомонӣ" in tg_syms.get("TJS", ""))


# ── th (Thai) ──────────────────────────────────────────────────────────
section("th — Thai")
th_syms = dict(spec.EXTRA_SYMBOLS.get("th", []))
check("th THB → 'บาท'", "บาท" in th_syms.get("THB", ""))
check("th lexicon: WhatsApp → 'วอตส์แอป'",
      spec.EXTRA_LEXICON.get("th", {}).get("WhatsApp") == "วอตส์แอป")

th_handler = spec.get_handler("th")
if th_handler is None:
    print("    [info] pythainlp not installed locally — Thai falls back "
          "to parent (which may also lack pythainlp).")
    check("th handler safely None when pythainlp missing", True)
else:
    out = th_handler("ผมชอบกินข้าว")
    check("th handler runs (segments words)",
          isinstance(out, str) and len(out) > 0)


# ── ti (Tigrinya) ──────────────────────────────────────────────────────
section("ti — Tigrinya")
ti_handler = spec.get_handler("ti")
check("ti Ge'ez digit handler builds", ti_handler is not None)
if ti_handler:
    check("ti Ge'ez '፫' → '3'", "3" in ti_handler("፫"))


# ── tl (Tagalog) ───────────────────────────────────────────────────────
section("tl — Tagalog")
tl_syms = dict(spec.EXTRA_SYMBOLS.get("tl", []))
check("tl PHP → 'piso'", "piso" in tl_syms.get("PHP", ""))
check("tl atbp. → 'at iba pa'", tl_syms.get("atbp.") == " at iba pa")


# ── tn (Tswana) ────────────────────────────────────────────────────────
section("tn — Tswana")
tn_syms = dict(spec.EXTRA_SYMBOLS.get("tn", []))
check("tn & → 'le'", tn_syms.get("&") == " le ")


# ── tr (Turkish) ───────────────────────────────────────────────────────
section("tr — Turkish")
tr_syms = dict(spec.EXTRA_SYMBOLS.get("tr", []))
check("tr TRY → 'Türk lirası'", "Türk" in tr_syms.get("TRY", ""))
check("tr ör. → 'örneğin'", tr_syms.get("ör.") == " örneğin")
check("tr lexicon: ChatGPT → 'Çet G P T'",
      spec.EXTRA_LEXICON.get("tr", {}).get("ChatGPT") == "Çet G P T")


# ── tw (Twi) ───────────────────────────────────────────────────────────
section("tw — Twi")
tw_syms = dict(spec.EXTRA_SYMBOLS.get("tw", []))
check("tw % uses Twi phrasing",
      "nkyem" in tw_syms.get("%", ""))


# ── uk (Ukrainian) ─────────────────────────────────────────────────────
section("uk — Ukrainian")
uk_syms = dict(spec.EXTRA_SYMBOLS.get("uk", []))
check("uk UAH → 'гривень'", "гривень" in uk_syms.get("UAH", ""))
check("uk lexicon: ChatGPT → 'ЧатДжіПіТі'",
      spec.EXTRA_LEXICON.get("uk", {}).get("ChatGPT") == "ЧатДжіПіТі")

uk_handler = spec.get_handler("uk")
if uk_handler is None:
    print("    [info] ukrainian-word-stress not installed locally.")
    check("uk handler safely None when lib missing", True)
else:
    out = uk_handler("Привіт")
    check("uk stress handler runs", isinstance(out, str) and len(out) > 0)


# ── ur (Urdu) ──────────────────────────────────────────────────────────
section("ur — Urdu")
ur_syms = dict(spec.EXTRA_SYMBOLS.get("ur", []))
check("ur PKR → 'روپے'", "روپے" in ur_syms.get("PKR", ""))
check("ur lexicon: WhatsApp → 'واٹس ایپ'",
      spec.EXTRA_LEXICON.get("ur", {}).get("WhatsApp") == "واٹس ایپ")
ur_handler = spec.get_handler("ur")
check("ur script-fix handler builds", ur_handler is not None)
if ur_handler:
    check("ur '۵' → '5'", "5" in ur_handler("۵"))


# ── uz (Uzbek) ─────────────────────────────────────────────────────────
section("uz — Uzbek")
uz_syms = dict(spec.EXTRA_SYMBOLS.get("uz", []))
check("uz UZS → 'so'm'", "so'm" in uz_syms.get("UZS", ""))


# ── vi (Vietnamese) ────────────────────────────────────────────────────
section("vi — Vietnamese")
vi_syms = dict(spec.EXTRA_SYMBOLS.get("vi", []))
check("vi VND → 'đồng'", "đồng" in vi_syms.get("VND", ""))
check("vi TS. → 'Tiến sĩ'", "Tiến sĩ" in vi_syms.get("TS.", ""))
check("vi v.v. → 'vân vân'", vi_syms.get("v.v.") == " vân vân")

vi_handler = spec.get_handler("vi")
if vi_handler is None:
    print("    [info] vinorm not installed locally.")
    check("vi handler safely None when vinorm missing", True)
else:
    out = vi_handler("Tôi có 100 đồng")
    check("vi vinorm handler runs", isinstance(out, str) and len(out) > 0)


# ── wo (Wolof) ─────────────────────────────────────────────────────────
section("wo — Wolof")
wo_syms = dict(spec.EXTRA_SYMBOLS.get("wo", []))
check("wo & → 'ak'", wo_syms.get("&") == " ak ")


# ── xh (Xhosa) ─────────────────────────────────────────────────────────
section("xh — Xhosa")
xh_syms = dict(spec.EXTRA_SYMBOLS.get("xh", []))
check("xh & → 'kunye'", xh_syms.get("&") == " kunye ")


# ── yo (Yoruba) ────────────────────────────────────────────────────────
section("yo — Yoruba")
yo_syms = dict(spec.EXTRA_SYMBOLS.get("yo", []))
check("yo Dr. → 'Dókítà'", "Dókítà" in yo_syms.get("Dr.", ""))


# ── zh (Chinese) ───────────────────────────────────────────────────────
section("zh — Chinese")
zh_lex = spec.EXTRA_LEXICON.get("zh", {})
check("zh Microsoft → '微软'", zh_lex.get("Microsoft") == "微软")
check("zh Google → '谷歌'", zh_lex.get("Google") == "谷歌")
check("zh TikTok → '抖音' (Chinese version)",
      zh_lex.get("TikTok") == "抖音")
check("zh lexicon ≥ 12 entries", len(zh_lex) >= 12)

zh_syms = dict(spec.EXTRA_SYMBOLS.get("zh", []))
check("zh CNY → '人民币'", "人民币" in zh_syms.get("CNY", ""))
check("zh a.m. → '上午'", "上午" in zh_syms.get("a.m.", ""))

zh_handler = spec.get_handler("zh")
if zh_handler is None:
    print("    [info] cn2an not installed locally.")
    check("zh handler safely None when cn2an missing", True)
else:
    out = zh_handler("我有 100 个苹果")
    check("zh cn2an handler runs", isinstance(out, str) and len(out) > 0)


# ── zu (Zulu) ──────────────────────────────────────────────────────────
section("zu — Zulu")
zu_syms = dict(spec.EXTRA_SYMBOLS.get("zu", []))
check("zu & → 'futhi'", zu_syms.get("&") == " futhi ")


# ── COVERAGE summary ───────────────────────────────────────────────────
section("Coverage summary")
all_langs_covered = set(spec.EXTRA_LEXICON) | set(spec.EXTRA_SYMBOLS) | set(spec._BUILDERS)
print(f"  total languages with ANY sidecar entry: {len(all_langs_covered)}")
print(f"  languages with EXTRA_LEXICON  : {len(spec.EXTRA_LEXICON)}")
print(f"  languages with EXTRA_SYMBOLS  : {len(spec.EXTRA_SYMBOLS)}")
print(f"  languages with handler (_BUILDERS): {len(spec._BUILDERS)}")
print(f"  handler languages: {sorted(spec._BUILDERS.keys())}")
check("≥ 90 languages get any sidecar improvement",
      len(all_langs_covered) >= 90,
      detail=f"got {len(all_langs_covered)}")


# ── Summary ────────────────────────────────────────────────────────────
print(f"\n{'=' * 64}")
print(f"passed: {_PASS}   failed: {_FAIL}")
if _FAIL:
    print("\nFailures:")
    for f in _FAILURES:
        print(f"  - {f}")
    sys.exit(1)
print("\n✅ ALL TESTS PASSED")
sys.exit(0)
