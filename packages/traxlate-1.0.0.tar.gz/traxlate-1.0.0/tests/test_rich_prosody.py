"""Regression tests for tts_rich_prosody.

Tests the extract → apply round-trip on synthetic signals so we can
catch regressions without depending on real TTS renders.

Run: python -u tests/test_rich_prosody.py"""
from __future__ import annotations
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import tts_rich_prosody as rp

passed = 0
failed = 0


def check(name: str, ok: bool, detail: str = "") -> None:
    global passed, failed
    if ok:
        print(f"  ✓ {name}")
        passed += 1
    else:
        print(f"  ✗ {name}    {detail}")
        failed += 1


def section(t: str) -> None:
    print()
    print(f"── {t} " + "─" * (66 - len(t)))


SR = 22050


def _gen_rising_pitch(dur: float = 2.5, f0_lo: float = 150, f0_hi: float = 280,
                      sr: int = SR) -> np.ndarray:
    """Synthetic signal with rising pitch (like an excited utterance)."""
    n = int(sr * dur)
    t = np.linspace(0, dur, n, endpoint=False)
    f0 = np.linspace(f0_lo, f0_hi, n)
    phase = 2 * np.pi * np.cumsum(f0) / sr
    amp = 0.5 * (1 + 0.3 * np.sin(2 * np.pi * 3.0 * t))
    return (amp * np.sin(phase)).astype(np.float32)


def _gen_flat(dur: float = 2.0, f0: float = 150, sr: int = SR) -> np.ndarray:
    """Steady sine — represents emotionally-neutral TTS output."""
    n = int(sr * dur)
    t = np.linspace(0, dur, n, endpoint=False)
    return (0.4 * np.sin(2 * np.pi * f0 * t)).astype(np.float32)


# ════════════════════════════════════════════════════════════════════════
section("extract_rich_prosody — schema + value sanity")
# ════════════════════════════════════════════════════════════════════════
audio = _gen_rising_pitch()
profile = rp.extract_rich_prosody(audio, SR)
if profile is None:
    print("    [skip] parselmouth not installed — skipping all tests")
    print(f"\npassed: {passed}   failed: {failed}")
    sys.exit(0 if failed == 0 else 1)

check("returns dict",        isinstance(profile, dict))
check("version == 1",        profile.get("version") == 1)
check("duration_s reasonable",
      isinstance(profile.get("duration_s"), float)
      and 2.0 < profile["duration_s"] < 3.0)
check("median_pitch_hz in human-speech range (60-500)",
      60.0 < float(profile["median_pitch_hz"]) < 500.0)
check("f0_range_st > 0 for rising signal",
      float(profile["f0_range_st"]) > 1.0)
check("pitch_contour_st has N_CONTROL_POINTS entries",
      len(profile["pitch_contour_st"]) == rp.N_CONTROL_POINTS)
check("intensity_contour_db has N_CONTROL_POINTS entries",
      len(profile["intensity_contour_db"]) == rp.N_CONTROL_POINTS)
check("voiced_fraction in [0, 1]",
      0.0 <= float(profile["voiced_fraction"]) <= 1.0)
check("voiced_fraction is high for pure-tone signal (≥0.7)",
      float(profile["voiced_fraction"]) >= 0.7)
check("silence_intervals is a list",
      isinstance(profile["silence_intervals"], list))
check("pitch contour LAST point > FIRST point for rising signal",
      profile["pitch_contour_st"][-1] > profile["pitch_contour_st"][0],
      detail=f"first={profile['pitch_contour_st'][0]}, "
             f"last={profile['pitch_contour_st'][-1]}")
check("intensity_min_db < intensity_max_db",
      float(profile["intensity_min_db"]) <= float(profile["intensity_max_db"]))


# ════════════════════════════════════════════════════════════════════════
section("extract — edge cases")
# ════════════════════════════════════════════════════════════════════════
check("empty audio → None",
      rp.extract_rich_prosody(np.array([], dtype=np.float32), SR) is None)
check("too-short audio (0.2s) → None",
      rp.extract_rich_prosody(_gen_flat(dur=0.2), SR) is None)
silent = np.zeros(SR * 2, dtype=np.float32)
check("silent audio → None (no voiced frames)",
      rp.extract_rich_prosody(silent, SR) is None)


# ════════════════════════════════════════════════════════════════════════
section("apply_rich_prosody — output shape + identity preservation")
# ════════════════════════════════════════════════════════════════════════
flat_input = _gen_flat(dur=2.0, f0=150)
result = rp.apply_rich_prosody(flat_input, SR, profile, strength=0.85)
check("output is np.ndarray",         isinstance(result, np.ndarray))
check("output preserves length",      len(result) == len(flat_input))
check("output dtype float32",         result.dtype == np.float32)
check("output peak doesn't clip",     float(np.max(np.abs(result))) < 1.0)
check("output RMS is non-zero",       float(np.sqrt(np.mean(result ** 2))) > 0.001)

# Verify the apply actually MODIFIED the signal (not just passthrough)
diff = float(np.mean(np.abs(result - flat_input)))
check("output != input (transfer happened)", diff > 0.01,
      detail=f"mean abs diff = {diff:.5f}")


# ════════════════════════════════════════════════════════════════════════
section("apply — pitch contour ACTUALLY transferred")
# ════════════════════════════════════════════════════════════════════════
import parselmouth  # already loaded by extract
ps_in  = parselmouth.Sound(flat_input.astype(np.float64), sampling_frequency=SR)
ps_out = parselmouth.Sound(result.astype(np.float64),     sampling_frequency=SR)
voiced_in  = ps_in.to_pitch(time_step=0.01).selected_array["frequency"]
voiced_in  = voiced_in[voiced_in > 50]
voiced_out = ps_out.to_pitch(time_step=0.01).selected_array["frequency"]
voiced_out = voiced_out[voiced_out > 50]
range_in  = float(voiced_in.max() - voiced_in.min())   if voiced_in.size > 5 else 0.0
range_out = float(voiced_out.max() - voiced_out.min()) if voiced_out.size > 5 else 0.0
check("output pitch RANGE > input pitch range (contour was added)",
      range_out > range_in + 5.0,
      detail=f"in_range={range_in:.1f}Hz  out_range={range_out:.1f}Hz")

# Voice identity preserved: median pitch of output stays close to input median
med_in  = float(np.median(voiced_in))  if voiced_in.size > 5 else 0.0
med_out = float(np.median(voiced_out)) if voiced_out.size > 5 else 0.0
check("output MEDIAN pitch within ±10% of input (identity preserved)",
      abs(med_out - med_in) / max(med_in, 1.0) < 0.10,
      detail=f"med_in={med_in:.1f}  med_out={med_out:.1f}")


# ════════════════════════════════════════════════════════════════════════
section("apply — strength controls transfer magnitude")
# ════════════════════════════════════════════════════════════════════════
r_full = rp.apply_rich_prosody(flat_input, SR, profile, strength=1.0)
r_half = rp.apply_rich_prosody(flat_input, SR, profile, strength=0.5)
r_zero = rp.apply_rich_prosody(flat_input, SR, profile, strength=0.0)
diff_zero = float(np.mean(np.abs(r_zero - flat_input)))
check("strength=0 → returns ~unchanged input",
      diff_zero < 0.001,
      detail=f"diff={diff_zero}")

# Strength should monotonically affect the OUTPUT PITCH RANGE (the actual
# perceptual quantity prosody transfer modulates). Time-domain diff isn't
# monotonic w.r.t. strength because of phase divergence — but the pitch
# range a Praat analysis sees IS the thing we control.
def _pitch_range_hz(audio_arr: np.ndarray) -> float:
    ps = parselmouth.Sound(audio_arr.astype(np.float64), sampling_frequency=SR)
    voiced = ps.to_pitch(time_step=0.01).selected_array["frequency"]
    voiced = voiced[voiced > 50]
    return float(voiced.max() - voiced.min()) if voiced.size > 5 else 0.0

range_zero = _pitch_range_hz(r_zero)
range_half = _pitch_range_hz(r_half)
range_full = _pitch_range_hz(r_full)
check("pitch range grows with strength: zero <= half <= full",
      range_zero <= range_half + 5 and range_half <= range_full + 5,
      detail=f"zero={range_zero:.1f}  half={range_half:.1f}  full={range_full:.1f}")
check("strength=1.0 produces noticeably wider pitch range than strength=0",
      range_full > range_zero + 20,
      detail=f"full={range_full:.1f}  zero={range_zero:.1f}")


# ════════════════════════════════════════════════════════════════════════
section("apply — robustness (must NEVER raise; returns input on errors)")
# ════════════════════════════════════════════════════════════════════════
check("None profile → returns input unchanged",
      rp.apply_rich_prosody(flat_input, SR, None) is flat_input)
check("wrong-version profile → returns input unchanged",
      rp.apply_rich_prosody(flat_input, SR,
                            {"version": 99, "pitch_contour_st": [],
                             "intensity_contour_db": []}) is flat_input)
check("empty audio → returns input unchanged",
      rp.apply_rich_prosody(np.array([], dtype=np.float32), SR, profile)
      .size == 0)
# Very short audio (under 0.2s) should pass through unchanged
short = _gen_flat(dur=0.15)
check("too-short audio (0.15s) → returns input unchanged",
      rp.apply_rich_prosody(short, SR, profile) is short)


# ════════════════════════════════════════════════════════════════════════
section("flat_profile_to_rich — bridge for legacy callers")
# ════════════════════════════════════════════════════════════════════════
flat_emotion = {"speed_ratio": 1.15, "pitch_delta_st": 1.5,
                "energy_ratio": 1.2, "pause_scale": 0.8}
synth = rp.flat_profile_to_rich(flat_emotion, duration_s=2.5)
check("flat profile → rich is dict with version=1",
      isinstance(synth, dict) and synth.get("version") == 1)
check("synthetic rich has N_CONTROL_POINTS pitch points",
      len(synth["pitch_contour_st"]) == rp.N_CONTROL_POINTS)
check("synthetic rich pitch is CONSTANT (= flat delta)",
      all(p == flat_emotion["pitch_delta_st"]
          for p in synth["pitch_contour_st"]))
check("neutral flat profile → None (don't apply needless work)",
      rp.flat_profile_to_rich({"speed_ratio": 1.0, "pitch_delta_st": 0,
                               "energy_ratio": 1.0, "pause_scale": 1.0})
      is None)


print()
print("=" * 60)
print(f"passed: {passed}   failed: {failed}")
if failed == 0:
    print("✅ ALL TESTS PASSED")
    sys.exit(0)
print("❌ FAILED")
sys.exit(1)
