"""
Localization file-format parsers — the ingest/emit layer of the platform.

One uniform contract for every format a dev team ships:

    units = extract(text, fmt)                      # -> list[Unit(key, source, comment)]
    # translate each unit.source (placeholder-protected via i18n_protect)
    new_text = merge(text, fmt, {key: translation}) # write targets back, losslessly

Supported `fmt`: "json" (nested), "arb" (Flutter), "strings" (Apple),
"po" (gettext), "xliff" (1.2). Auto-detect by extension via detect_format(path).

Design:
  * merge() patches in place where the file carries metadata we must not lose
    (PO headers/comments/refs, XLIFF structure); JSON/ARB preserve key order
    and array shapes.
  * Pure stdlib (json, re, xml.etree). Run `python i18n_formats.py` for tests.
"""
from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Optional


@dataclass
class Unit:
    key: str
    source: str
    comment: Optional[str] = None


def detect_format(path: str) -> str:
    p = path.lower()
    for ext, fmt in ((".arb", "arb"), (".json", "json"), (".strings", "strings"),
                     (".po", "po"), (".pot", "po"), (".xlf", "xliff"), (".xliff", "xliff")):
        if p.endswith(ext):
            return fmt
    raise ValueError(f"unknown localization format for {path!r}")


# ── JSON (nested, arrays) ──────────────────────────────────────────────────
def _json_flatten(obj, prefix: str, out: "list[Unit]") -> None:
    if isinstance(obj, str):
        out.append(Unit(prefix, obj))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            _json_flatten(v, f"{prefix}[{i}]", out)
    elif isinstance(obj, dict):
        for k, v in obj.items():
            _json_flatten(v, f"{prefix}.{k}" if prefix else k, out)


_KEY_SEG = re.compile(r"([^.\[\]]+)|\[(\d+)\]")


def _json_set(root, key: str, value: str) -> None:
    segs = [(m.group(1), m.group(2)) for m in _KEY_SEG.finditer(key)]
    cur = root
    for i, (name, idx) in enumerate(segs):
        last = i == len(segs) - 1
        if idx is not None:
            j = int(idx)
            if last:
                cur[j] = value
            else:
                cur = cur[j]
        else:
            if last:
                cur[name] = value
            else:
                cur = cur[name]


def _json_extract(text: str) -> "list[Unit]":
    out: "list[Unit]" = []
    _json_flatten(json.loads(text), "", out)
    return out


def _json_merge(text: str, tr: "dict[str,str]") -> str:
    obj = json.loads(text)
    for k, v in tr.items():
        try:
            _json_set(obj, k, v)
        except (KeyError, IndexError, TypeError):
            pass  # key vanished since extract — skip rather than crash
    return json.dumps(obj, ensure_ascii=False, indent=2) + "\n"


# ── Flutter / Android .arb (JSON + @metadata) ──────────────────────────────
def _arb_extract(text: str) -> "list[Unit]":
    obj = json.loads(text)
    out = []
    for k, v in obj.items():
        if k.startswith("@") or not isinstance(v, str):
            continue
        meta = obj.get(f"@{k}")
        desc = meta.get("description") if isinstance(meta, dict) else None
        out.append(Unit(k, v, desc))
    return out


def _arb_merge(text: str, tr: "dict[str,str]") -> str:
    obj = json.loads(text)
    for k, v in tr.items():
        if k in obj and not k.startswith("@"):
            obj[k] = v
    return json.dumps(obj, ensure_ascii=False, indent=2) + "\n"


# ── Apple .strings ──────────────────────────────────────────────────────────
_STRINGS_RE = re.compile(
    r'(?:/\*(?P<comment>.*?)\*/\s*)?'
    r'"(?P<key>(?:[^"\\]|\\.)*)"\s*=\s*"(?P<val>(?:[^"\\]|\\.)*)"\s*;',
    re.DOTALL,
)


def _unescape(s: str) -> str:
    return (s.replace('\\"', '"').replace("\\n", "\n")
             .replace("\\t", "\t").replace("\\\\", "\\"))


def _escape(s: str) -> str:
    return (s.replace("\\", "\\\\").replace('"', '\\"')
             .replace("\n", "\\n").replace("\t", "\\t"))


def _strings_extract(text: str) -> "list[Unit]":
    return [Unit(_unescape(m.group("key")), _unescape(m.group("val")),
                 (m.group("comment") or "").strip() or None)
            for m in _STRINGS_RE.finditer(text)]


def _strings_merge(text: str, tr: "dict[str,str]") -> str:
    def repl(m: re.Match) -> str:
        key = _unescape(m.group("key"))
        if key not in tr:
            return m.group(0)
        # replace only this entry's value, preserving comment + key + spacing
        return re.sub(r'=\s*"(?:[^"\\]|\\.)*"\s*;',
                      f'= "{_escape(tr[key])}";', m.group(0), count=1)
    return _STRINGS_RE.sub(repl, text)


# ── gettext .po ──────────────────────────────────────────────────────────────
def _po_unquote(lines: "list[str]") -> str:
    parts = [re.search(r'"((?:[^"\\]|\\.)*)"', ln).group(1)
             for ln in lines if re.search(r'"((?:[^"\\]|\\.)*)"', ln)]
    return _unescape("".join(parts))


def _po_blocks(text: str) -> "list[list[str]]":
    blocks, cur = [], []
    for line in text.splitlines():
        if line.strip() == "":
            if cur:
                blocks.append(cur); cur = []
        else:
            cur.append(line)
    if cur:
        blocks.append(cur)
    return blocks


def _po_msgid(block: "list[str]") -> "tuple[str, Optional[str]]":
    comment, ml, grab = None, [], False
    for ln in block:
        if ln.startswith("#."):
            comment = ln[2:].strip()
        if ln.startswith("msgid "):
            grab, ml = True, [ln]
        elif grab and ln.startswith('"'):
            ml.append(ln)
        elif grab:
            grab = False
    return _po_unquote(ml), comment


def _po_extract(text: str) -> "list[Unit]":
    out = []
    for b in _po_blocks(text):
        key, comment = _po_msgid(b)
        if key:  # skip header (empty msgid)
            out.append(Unit(key, key, comment))
    return out


def _po_merge(text: str, tr: "dict[str,str]") -> str:
    out_blocks = []
    for b in _po_blocks(text):
        key, _ = _po_msgid(b)
        if key and key in tr:
            new = []
            skip = False
            for ln in b:
                if ln.startswith("msgstr "):
                    new.append(f'msgstr {_po_quote(tr[key])}')
                    skip = True            # drop any continuation lines of old msgstr
                elif skip and ln.startswith('"'):
                    continue
                else:
                    skip = False
                    new.append(ln)
            out_blocks.append(new)
        else:
            out_blocks.append(b)
    # entries are separated by a blank line — preserve that or re-parsing merges them
    return "\n\n".join("\n".join(b) for b in out_blocks) + "\n"


def _po_quote(s: str) -> str:
    return '"' + _escape(s) + '"'


# ── XLIFF 1.2 (<trans-unit id><source/><target/>) ──────────────────────────
_XLIFF_NS = "urn:oasis:names:tc:xliff:document:1.2"


def _xliff_extract(text: str) -> "list[Unit]":
    root = ET.fromstring(text)
    out = []
    for tu in root.iter():
        if tu.tag.rsplit("}", 1)[-1] != "trans-unit":
            continue
        src = next((c for c in tu if c.tag.rsplit("}", 1)[-1] == "source"), None)
        note = next((c for c in tu if c.tag.rsplit("}", 1)[-1] == "note"), None)
        if src is not None and (src.text or "").strip():
            out.append(Unit(tu.get("id") or src.text, src.text,
                            (note.text.strip() if note is not None and note.text else None)))
    return out


def _xliff_merge(text: str, tr: "dict[str,str]") -> str:
    ET.register_namespace("", _XLIFF_NS)
    root = ET.fromstring(text)
    for tu in root.iter():
        if tu.tag.rsplit("}", 1)[-1] != "trans-unit":
            continue
        src = next((c for c in tu if c.tag.rsplit("}", 1)[-1] == "source"), None)
        key = tu.get("id") or (src.text if src is not None else None)
        if key not in tr:
            continue
        tgt = next((c for c in tu if c.tag.rsplit("}", 1)[-1] == "target"), None)
        if tgt is None:
            tag = f"{{{_XLIFF_NS}}}target" if "}" in tu.tag else "target"
            tgt = ET.SubElement(tu, tag)
        tgt.text = tr[key]
    return ET.tostring(root, encoding="unicode")


# ── dispatch ─────────────────────────────────────────────────────────────────
_EXTRACT = {"json": _json_extract, "arb": _arb_extract, "strings": _strings_extract,
            "po": _po_extract, "xliff": _xliff_extract}
_MERGE = {"json": _json_merge, "arb": _arb_merge, "strings": _strings_merge,
          "po": _po_merge, "xliff": _xliff_merge}


def extract(text: str, fmt: str) -> "list[Unit]":
    return _EXTRACT[fmt](text)


def merge(text: str, fmt: str, translations: "dict[str,str]") -> str:
    return _MERGE[fmt](text, translations)


# ─────────────────────────────────────────────────────────────────────────────
def _run_tests() -> None:
    ok = 0

    def check(name, cond, extra=""):
        nonlocal ok
        print(f"  [{'ok' if cond else 'FAIL'}] {name}{('' if cond else ' — ' + str(extra))}")
        assert cond, f"{name} {extra}"
        ok += 1

    # JSON nested + arrays
    js = '{"a":"Hello","b":{"c":"World"},"d":["x","y"]}'
    u = extract(js, "json")
    check("json extract", [x.key for x in u] == ["a", "b.c", "d[0]", "d[1]"], [x.key for x in u])
    out = merge(js, "json", {"a": "Hola", "b.c": "Mundo", "d[1]": "Z"})
    o = json.loads(out)
    check("json merge", o["a"] == "Hola" and o["b"]["c"] == "Mundo" and o["d"] == ["x", "Z"], o)

    # ARB skips @metadata
    arb = '{"@@locale":"en","hi":"Hi","@hi":{"description":"greeting"},"bye":"Bye"}'
    u = extract(arb, "arb")
    check("arb skips @keys", [x.key for x in u] == ["hi", "bye"], [x.key for x in u])
    check("arb comment", u[0].comment == "greeting")
    check("arb merge keeps meta", json.loads(merge(arb, "arb", {"hi": "Hola"}))["@hi"]["description"] == "greeting")

    # Apple .strings with comment + value containing escaped quote
    st = '/* Greeting */\n"hi" = "Hello \\"there\\"";\n"bye"="Bye";'
    u = extract(st, "strings")
    check("strings extract", [x.key for x in u] == ["hi", "bye"] and u[0].source == 'Hello "there"', u)
    m = merge(st, "strings", {"hi": "Hola", "bye": "Adiós"})
    u2 = extract(m, "strings")
    check("strings merge", u2[0].source == "Hola" and u2[1].source == "Adiós", u2)
    check("strings keeps comment", "/* Greeting */" in m)

    # gettext .po with header + comment, multiline msgstr collapse
    po = ('msgid ""\nmsgstr "Content-Type: text/plain"\n\n'
          '#. nav label\nmsgid "Home"\nmsgstr ""\n\n'
          'msgid "About"\nmsgstr ""\n')
    u = extract(po, "po")
    check("po skips header", [x.key for x in u] == ["Home", "About"], [x.key for x in u])
    check("po comment", u[0].comment == "nav label")
    m = merge(po, "po", {"Home": "Inicio", "About": "Acerca de"})
    check("po merge sets msgstr", 'msgstr "Inicio"' in m and 'msgstr "Acerca de"' in m, m)
    check("po keeps header", "Content-Type" in m)
    check("po re-extract stable", [x.key for x in extract(m, "po")] == ["Home", "About"])

    # XLIFF 1.2
    xl = (f'<xliff version="1.2" xmlns="{_XLIFF_NS}"><file><body>'
          '<trans-unit id="k1"><source>Hello</source></trans-unit>'
          '<trans-unit id="k2"><source>Bye</source><target>old</target></trans-unit>'
          '</body></file></xliff>')
    u = extract(xl, "xliff")
    check("xliff extract", [x.key for x in u] == ["k1", "k2"] and u[0].source == "Hello", u)
    m = merge(xl, "xliff", {"k1": "Hola", "k2": "Adiós"})
    check("xliff sets targets", "<target>Hola</target>" in m and "<target>Adiós</target>" in m, m)

    # detect_format
    check("detect", detect_format("a/b/app.arb") == "arb" and detect_format("x.po") == "po"
          and detect_format("y.xliff") == "xliff")

    print(f"\n{ok} checks passed.")


if __name__ == "__main__":
    _run_tests()
