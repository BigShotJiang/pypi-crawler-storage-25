"""
traxlate — official Python SDK.

One client that ties the whole localization toolchain together. Every call is
placeholder-safe (masks `{vars}`, ICU, `<tags>`, `%s`, URLs before translation,
validates, restores) and dogfoods the Traxlate engine.

    from traxlate import TraxlateClient
    tx = TraxlateClient(api_key="tr_live_…")            # or base_url=... for self-host

    tx.translate("Hello {name}", "en", "es")            # -> "Hola {name}"
    tx.translate_texts(["A", "B"], "en", "fr")          # -> ["…", "…"]
    tx.localize_html(html, "de")                        # whole page, markup preserved
    tx.localize_file("locales/en.json", "locales/es.json", "es")   # any supported format

Connectors (Zapier, CMS plugins, CI, etc.) sit on this — they never re-implement
protection, batching, format handling, or HTML extraction.

Pure stdlib (urllib). Run `python traxlate.py` for the offline test suite.
"""
from __future__ import annotations

import json
import urllib.request
from dataclasses import dataclass

import i18n_protect as _protect
import i18n_formats as _fmts
import web_localize as _web
from localize import flores, localize_file as _localize_file, LocaleReport


@dataclass
class TranslateResult:
    translations: "list[str]"
    cohesion: "list[float]"
    issues: "list[str]"          # placeholder-validation problems, "<index>: <detail>"


class TraxlateClient:
    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = "https://traxlate.com",
        engine_path: str = "/api/v1/translate_batch",   # authenticated, billed
        transport=None,            # injectable for tests: (texts, src_flores, tgt_flores)->(list,list)
        chunk: int = 60,
        timeout: int = 540,
    ) -> None:
        self.api_key = api_key
        self._url = base_url.rstrip("/") + engine_path
        self._chunk = chunk
        self._timeout = timeout
        self._transport = transport or self._http_transport

    # ── transport ────────────────────────────────────────────────────────
    def _http_transport(self, texts, src_f, tgt_f, contexts=None):
        translations, cohesion = [], []
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        for i in range(0, len(texts), self._chunk):
            sl = texts[i:i + self._chunk]
            payload = {"texts": sl, "source_lang": src_f, "target_lang": tgt_f}
            if contexts is not None:
                payload["contexts"] = contexts[i:i + self._chunk]
            body = json.dumps(payload).encode()
            req = urllib.request.Request(self._url, data=body, headers=headers)
            with urllib.request.urlopen(req, timeout=self._timeout) as r:
                data = json.loads(r.read().decode())
            tr = data.get("translations") or []
            if len(tr) != len(sl):
                raise RuntimeError(f"engine returned {len(tr)} for {len(sl)} texts")
            translations += tr
            cs = data.get("cohesion_scores")
            cohesion += cs if isinstance(cs, list) and len(cs) == len(sl) else [None] * len(sl)
        return translations, cohesion

    # ── text ─────────────────────────────────────────────────────────────
    def translate_detailed(self, texts: "list[str]", source: str = "en", target: str = "es") -> TranslateResult:
        masked, token_sets = [], []
        for t in texts:
            m, toks = _protect.protect(t)
            masked.append(m)
            token_sets.append(toks)
        raw, cohesion = self._transport(masked, flores(source), flores(target))
        out, issues = [], []
        for i, (o, toks, src) in enumerate(zip(raw, token_sets, texts)):
            problems = _protect.validate(o, toks)
            if problems:
                issues.append(f"{i}: {'; '.join(problems)}")
                # never ship a broken placeholder
                if any("dropped" in p or "duplicated" in p for p in problems):
                    out.append(src)
                    continue
            out.append(_protect.restore(o, toks))
        return TranslateResult(out, list(cohesion), issues)

    def translate_texts(self, texts, source="en", target="es") -> "list[str]":
        return self.translate_detailed(texts, source, target).translations

    def translate(self, text: str, source: str = "en", target: str = "es") -> str:
        return self.translate_texts([text], source, target)[0]

    # ── html ─────────────────────────────────────────────────────────────
    def localize_html(self, html: str, target: str, source: str = "en") -> str:
        sources = _web.extract_html(html)
        translated = self.translate_texts(sources, source, target)
        return _web.apply_html(html, dict(zip(sources, translated)))

    # ── files ────────────────────────────────────────────────────────────
    def localize_file(self, in_path: str, out_path: str, target: str,
                      source: str = "en", fmt: str = "auto", overwrite: bool = False) -> LocaleReport:
        f = _fmts.detect_format(in_path) if fmt == "auto" else fmt
        with open(in_path, encoding="utf-8") as fh:
            src_text = fh.read()
        existing = None
        try:
            with open(out_path, encoding="utf-8") as fh:
                existing = fh.read()
        except FileNotFoundError:
            pass
        out_text, report = _localize_file(src_text, f, source, target, existing,
                                          self._transport, cache_for_locale={}, overwrite=overwrite)
        with open(out_path, "w", encoding="utf-8") as fh:
            fh.write(out_text)
        return report


# ─────────────────────────────────────────────────────────────────────────
def _run_tests() -> None:
    ok = 0

    def check(name, cond, extra=""):
        nonlocal ok
        print(f"  [{'ok' if cond else 'FAIL'}] {name}{('' if cond else ' — ' + str(extra))}")
        assert cond, f"{name} {extra}"
        ok += 1

    # fake engine: uppercase the masked text (placeholders are already masked out)
    def fake(texts, src_f, tgt_f, contexts=None):
        return [t.upper() for t in texts], [0.9] * len(texts)

    tx = TraxlateClient(transport=fake)

    check("flores mapping used", flores("ar") == "arb_Arab")
    check("translate one", tx.translate("Hello {name}", "en", "es") == "HELLO {name}")
    check("translate many", tx.translate_texts(["a", "b"], "en", "fr") == ["A", "B"])

    det = tx.translate_detailed(["Hi {n}", "Bye"], "en", "de")
    check("detailed translations", det.translations == ["HI {n}", "BYE"])
    check("detailed cohesion", det.cohesion == [0.9, 0.9])
    check("detailed no issues", det.issues == [])

    html = '<p>Hello {name}</p><img alt="A cat"><script>x()</script>'
    out = tx.localize_html(html, "es")
    check("html text translated", "<p>HELLO {name}</p>" in out)
    check("html alt translated", 'alt="A CAT"' in out)
    check("html script untouched", "x()" in out)

    # file round-trip via a temp file
    import tempfile, os, json as _json
    d = tempfile.mkdtemp()
    src = os.path.join(d, "en.json")
    dst = os.path.join(d, "es.json")
    with open(src, "w", encoding="utf-8") as f:
        f.write(_json.dumps({"hi": "Hello {user}", "bye": "Goodbye"}))
    rep = tx.localize_file(src, dst, "es")
    o = _json.load(open(dst, encoding="utf-8"))
    check("file localized", o["hi"] == "HELLO {user}" and o["bye"] == "GOODBYE")
    check("file report", rep.translated == 2 and rep.issues == [])

    print(f"\n{ok} checks passed.")


if __name__ == "__main__":
    _run_tests()
