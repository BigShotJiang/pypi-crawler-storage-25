"""
web_localize.py — crawl a site and extract/re-insert translatable content.

The front half of the website-localization product:

    pages = crawl(seed_url, max_pages=50)              # {url: html}, same-origin
    segs  = extract_html(html)                          # unique translatable strings
    # translate each seg.source (placeholder-protected via i18n_protect)
    localized = apply_html(html, {source: translation}) # markup preserved byte-for-byte

What it translates: visible text nodes + translatable attributes
(`alt`, `title`, `placeholder`, `aria-label`) + `<meta>` description / Open Graph
/ Twitter card content + `<title>`. Deduped by source string, so a nav link that
appears on every page is one unit (and one TM hit).

What it leaves alone: `<script>`, `<style>`, `<noscript>`, `<template>`, `<svg>`,
and `<code>/<pre>/<kbd>/<samp>/<var>` (raw), plus any element marked
`translate="no"` / `[data-no-translate]`.

Keying by source string suits the JS-snippet delivery (swap matching nodes at
runtime) and the server proxy alike. Start tags are reproduced from their exact
original bytes, so re-insertion only changes the text/attribute values.

Known v1 limitation: inline markup splits a sentence ("Read <a>more</a>" → "Read",
"more"). Inline-run merging (emit the block's inner HTML as one unit, protect the
inline tags via i18n_protect) is the next refinement and is noted in the roadmap.

Pure stdlib (html.parser, urllib). Run `python web_localize.py` for tests.
"""
from __future__ import annotations

import re
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

SKIP = {"script", "style", "noscript", "template", "svg"}     # content not output for translation, kept verbatim
RAW = {"code", "pre", "kbd", "samp", "var"}                    # kept verbatim, not translated
ATTRS = ("alt", "title", "placeholder", "aria-label")          # translatable attributes on any element
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input",
        "link", "meta", "param", "source", "track", "wbr"}


class _Doc(HTMLParser):
    """Parses HTML into an ops list reused for both extract and apply."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=False)
        self.ops: list = []                # ("lit", s) | ("text", s) | ("tag", rawtag, [(attr,val)])
        self._skip_depth = 0
        self._raw_depth = 0
        self._no_depth = 0                 # inside translate="no"

    # tags ----------------------------------------------------------------
    def handle_starttag(self, tag, attrs):
        self._starttag(tag, attrs, self.get_starttag_text() or f"<{tag}>")

    def handle_startendtag(self, tag, attrs):
        raw = self.get_starttag_text() or f"<{tag}/>"
        self._starttag(tag, attrs, raw, self_closing=True)

    def _starttag(self, tag, attrs, raw, self_closing=False):
        ad = {k: (v or "") for k, v in attrs}
        translatable = []
        if ad.get("translate", "").lower() != "no" and "data-no-translate" not in ad and self._no_depth == 0:
            for a in ATTRS:
                if ad.get(a, "").strip():
                    translatable.append((a, ad[a]))
            if tag == "meta":
                name = (ad.get("name") or ad.get("property") or "").lower()
                if name in {"description", "og:title", "og:description", "twitter:title",
                            "twitter:description"} and ad.get("content", "").strip():
                    translatable.append(("content", ad["content"]))
        self.ops.append(("tag", raw, translatable))

        if tag in SKIP:
            self._skip_depth += 1
        elif tag in RAW:
            self._raw_depth += 1
        if not self_closing and tag not in VOID:
            if ad.get("translate", "").lower() == "no" or "data-no-translate" in ad:
                self._no_depth += 1
        # track that this element opened a no-translate scope so endtag can close it
        self._no_open_stack = getattr(self, "_no_open_stack", [])
        if not self_closing and tag not in VOID:
            self._no_open_stack.append(ad.get("translate", "").lower() == "no" or "data-no-translate" in ad)

    def handle_endtag(self, tag):
        self.ops.append(("lit", f"</{tag}>"))
        if tag in SKIP and self._skip_depth:
            self._skip_depth -= 1
        elif tag in RAW and self._raw_depth:
            self._raw_depth -= 1
        stack = getattr(self, "_no_open_stack", [])
        if stack:
            was_no = stack.pop()
            if was_no and self._no_depth:
                self._no_depth -= 1

    # content -------------------------------------------------------------
    def handle_data(self, data):
        if self._skip_depth or self._raw_depth or self._no_depth:
            self.ops.append(("lit", data))
        elif data.strip():
            self.ops.append(("text", data))
        else:
            self.ops.append(("lit", data))

    def handle_comment(self, data):
        self.ops.append(("lit", f"<!--{data}-->"))

    def handle_entityref(self, name):
        self.ops.append(("lit", f"&{name};"))

    def handle_charref(self, name):
        self.ops.append(("lit", f"&#{name};"))

    def handle_decl(self, decl):
        self.ops.append(("lit", f"<!{decl}>"))

    def unknown_decl(self, data):
        self.ops.append(("lit", f"<![{data}]>"))

    def handle_pi(self, data):
        self.ops.append(("lit", f"<?{data}>"))


def _parse(html: str) -> _Doc:
    d = _Doc()
    d.feed(html)
    d.close()
    return d


def extract_html(html: str) -> "list[str]":
    """Unique translatable source strings (text content, in document order)."""
    seen, out = set(), []
    for op in _parse(html).ops:
        sources = []
        if op[0] == "text":
            sources = [op[1].strip()]
        elif op[0] == "tag":
            sources = [v.strip() for _a, v in op[2]]
        for s in sources:
            if s and s not in seen:
                seen.add(s)
                out.append(s)
    return out


def _swap_attr(raw_tag: str, attr: str, new_val: str) -> str:
    esc = new_val.replace('"', "&quot;")
    return re.sub(rf'({attr}\s*=\s*)(".*?"|\'.*?\')',
                  lambda m: f'{m.group(1)}"{esc}"', raw_tag, count=1, flags=re.DOTALL)


def apply_html(html: str, translations: "dict[str,str]") -> str:
    """Re-emit the HTML with text/attributes replaced by `translations` (keyed by
    source string). Markup is reproduced from original bytes; whitespace around
    text is preserved."""
    parts = []
    for op in _parse(html).ops:
        if op[0] == "lit":
            parts.append(op[1])
        elif op[0] == "text":
            raw = op[1]
            key = raw.strip()
            if key in translations:
                # preserve original leading/trailing whitespace around the text
                lead = raw[: len(raw) - len(raw.lstrip())]
                trail = raw[len(raw.rstrip()):]
                parts.append(lead + translations[key] + trail)
            else:
                parts.append(raw)
        elif op[0] == "tag":
            raw, attrs = op[1], op[2]
            for attr, val in attrs:
                if val.strip() in translations:
                    raw = _swap_attr(raw, attr, translations[val.strip()])
            parts.append(raw)
    return "".join(parts)


# ── crawler ──────────────────────────────────────────────────────────────
_HREF = re.compile(r'href\s*=\s*["\']([^"\']+)["\']', re.I)


def discover_links(html: str, base_url: str) -> "list[str]":
    out, base_host = [], urlparse(base_url).netloc
    for href in _HREF.findall(html):
        if href.startswith(("mailto:", "tel:", "javascript:", "#")):
            continue
        u = urljoin(base_url, href)
        pu = urlparse(u)
        if pu.scheme in ("http", "https") and pu.netloc == base_host:
            out.append(u.split("#")[0])
    return out


def _http_fetch(url: str) -> str:
    import urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": "TraxlateLocalizeBot/1.0"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.read().decode("utf-8", errors="replace")


def crawl(seed: str, max_pages: int = 50, fetch_fn=_http_fetch) -> "dict[str,str]":
    """Same-origin breadth-first crawl. Returns {url: html}. `fetch_fn` is
    injectable so this is testable offline."""
    seen, queue, pages = set(), [seed], {}
    while queue and len(pages) < max_pages:
        url = queue.pop(0)
        if url in seen:
            continue
        seen.add(url)
        try:
            html = fetch_fn(url)
        except Exception:
            continue
        pages[url] = html
        for link in discover_links(html, url):
            if link not in seen:
                queue.append(link)
    return pages


# ─────────────────────────────────────────────────────────────────────────
def _run_tests() -> None:
    ok = 0

    def check(name, cond, extra=""):
        nonlocal ok
        print(f"  [{'ok' if cond else 'FAIL'}] {name}{('' if cond else ' — ' + str(extra))}")
        assert cond, f"{name} {extra}"
        ok += 1

    html = (
        '<!DOCTYPE html><html><head>'
        '<title>Welcome</title>'
        '<meta name="description" content="Best translation platform">'
        '<meta property="og:title" content="Traxlate">'
        '<style>.x{color:red}</style>'
        '<script>var t="do not translate";</script>'
        '</head><body>'
        '<h1>Hello world</h1>'
        '<p>Translate documents.</p>'
        '<button aria-label="Close dialog">X</button>'
        '<img src="a.png" alt="A photo">'
        '<pre><code>const a = 1;</code></pre>'
        '<span translate="no">BrandName</span>'
        '<p>Translate documents.</p>'  # duplicate → deduped
        '</body></html>'
    )
    segs = extract_html(html)
    check("extracts visible text", "Hello world" in segs and "Translate documents." in segs)
    check("extracts <title>", "Welcome" in segs)
    check("extracts meta description", "Best translation platform" in segs)
    check("extracts og:title", "Traxlate" in segs)
    check("extracts alt", "A photo" in segs)
    check("extracts aria-label", "Close dialog" in segs)
    check("text X extracted", "X" in segs)
    check("skips script", not any("do not translate" in s for s in segs))
    check("skips style", not any("color:red" in s for s in segs))
    check("skips code/pre", not any("const a" in s for s in segs))
    check("respects translate=no", "BrandName" not in segs)
    check("dedupes", segs.count("Translate documents.") == 1)

    tr = {s: s.upper() for s in segs}
    out = apply_html(html, tr)
    check("text replaced", "<h1>HELLO WORLD</h1>" in out)
    check("alt replaced", 'alt="A PHOTO"' in out)
    check("meta replaced", 'content="BEST TRANSLATION PLATFORM"' in out)
    check("title replaced", "<title>WELCOME</title>" in out)
    check("script untouched", 'var t="do not translate"' in out)
    check("code untouched", "const a = 1;" in out)
    check("translate=no untouched", ">BrandName<" in out)
    check("structure preserved", out.startswith("<!DOCTYPE html><html><head>") and "<img " in out)

    # crawler (offline, fake fetch) — same-origin only, external dropped
    site = {
        "https://x.co/": '<a href="/about">About</a><a href="https://other.com/y">Ext</a><a href="/about">dup</a>',
        "https://x.co/about": '<a href="/">Home</a>',
    }
    pages = crawl("https://x.co/", fetch_fn=lambda u: site[u])
    check("crawl finds same-origin pages", set(pages) == {"https://x.co/", "https://x.co/about"})
    check("crawl excludes external", all("other.com" not in u for u in pages))

    print(f"\n{ok} checks passed.")


if __name__ == "__main__":
    _run_tests()
