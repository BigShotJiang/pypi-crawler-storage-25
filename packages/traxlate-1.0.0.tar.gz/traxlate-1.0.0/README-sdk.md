# traxlate — Python SDK

Official Python client for the [Traxlate](https://traxlate.com) translation API. Every call is **placeholder-safe** (masks `{vars}`, ICU, `<tags>`, `%s`, URLs before translation, validates, restores) and runs against the authenticated, billed API (`POST /api/v1/translate_batch`).

```bash
pip install traxlate
```

```python
from traxlate import TraxlateClient

tx = TraxlateClient(api_key="tr_live_…")          # key from traxlate.com/dashboard/api-keys

tx.translate("Hello {name}", "en", "es")          # -> "Hola {name}"
tx.translate_texts(["A", "B"], "en", "fr")        # -> ["…", "…"]
tx.localize_html(html, "de")                      # whole page, markup preserved
tx.localize_file("locales/en.json", "locales/es.json", "es")   # JSON/ARB/.strings/PO/XLIFF
```

For self-hosted engines, pass `base_url="https://your-host"`.

## CLI

The package also installs a `traxlate-localize` command for continuous file localization (change-detection cache, placeholder protection, source-side sense normalization):

```bash
traxlate-localize en.json --to es,fr,de --engine https://traxlate.com/api/v1/translate_batch
```

## What it handles for you

- Placeholder protection: `{vars}`, ICU plurals/selects, `<html>` tags, `%s`/`%1$d`, URLs/emails — masked, validated, restored; falls back to source on any hard failure so a broken placeholder never ships.
- Brand/entity preservation: names, acronyms and codes are protected by the engine.
- Formats: JSON, ARB, `.strings`, PO, XLIFF (extract + merge, structure-preserving).

License: MIT
