"""
localize.py — Traxlate localization CLI.

Point it at a project file (any supported format), give it target locales, and it
extracts strings, protects placeholders, translates them through the Traxlate
engine, validates that nothing broke, and writes locale files. Re-runs only
translate what changed (continuous localization) thanks to a content-hash cache.

    python localize.py app.en.arb --to es,fr,de
    python localize.py locales/en.json --to es --engine https://traxlate.com/api/engine/api/translate_batch
    python localize.py messages.po --to fr --out "{dir}/{base}.{locale}{ext}" --dry-run

Pipeline per locale (see i18n_protect + i18n_formats):
    extract -> protect -> batched translate -> validate placeholders -> restore -> merge

Exit code is non-zero if any segment failed placeholder validation, so CI can gate.
Pure stdlib (urllib). Run `python localize.py --selftest` for an offline test.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import time
import urllib.request
from dataclasses import dataclass, field

import i18n_formats as fmts
import i18n_protect as protect

# Minimal locale -> FLORES-200 map (engine validates these). Extend as needed;
# unknown locales pass through unchanged so explicit FLORES codes also work.
FLORES = {
    "en": "eng_Latn", "es": "spa_Latn", "fr": "fra_Latn", "de": "deu_Latn",
    "it": "ita_Latn", "pt": "por_Latn", "nl": "nld_Latn", "sv": "swe_Latn",
    "pl": "pol_Latn", "tr": "tur_Latn", "ru": "rus_Cyrl", "uk": "ukr_Cyrl",
    "ar": "arb_Arab", "fa": "pes_Arab", "he": "heb_Hebr", "ur": "urd_Arab",
    "hi": "hin_Deva", "bn": "ben_Beng", "ja": "jpn_Jpan", "ko": "kor_Hang",
    "zh": "zho_Hans", "zh-Hant": "zho_Hant", "th": "tha_Thai", "vi": "vie_Latn",
    "id": "ind_Latn", "ms": "zsm_Latn", "el": "ell_Grek", "cs": "ces_Latn",
}
def flores(loc: str) -> str:
    return FLORES.get(loc, loc)


@dataclass
class LocaleReport:
    locale: str
    total: int = 0
    translated: int = 0
    skipped_unchanged: int = 0
    issues: "list[str]" = field(default_factory=list)   # placeholder-validation failures
    cohesion: "list[float]" = field(default_factory=list)

    @property
    def mean_cohesion(self) -> float:
        vals = [c for c in self.cohesion if c is not None and c >= 0]
        return round(sum(vals) / len(vals), 3) if vals else float("nan")


# ── source-side sense normalization (our catalog chrome only) ──────────────
# A bare UI word ("Home", "turnaround", "caps") has no sense signal in itself,
# so the council commits to the wrong sense (Home→"dwelling", caps→"layers"). A
# disambiguating GLOSS proved unreliable (coin flip — sometimes leaves the term
# in English). What works reliably is the engine's own _HOMOGRAPH_VERB_FORMS
# trick: rewrite the ambiguous English term to an unambiguous synonym BEFORE
# translation, so the correct sense propagates to all 200 languages at once
# (verified ES/FR/DE). This is a tiny, source-side, all-language map for OUR
# marketing chrome — not the user-text translation lab. Two scopes keep it safe:
#   _NORM_EXACT  — only when the WHOLE short string is the term (nav labels);
#                  never touches the word inside prose ("welcome home").
#   _NORM_PHRASE — word/phrase level anywhere; only unambiguous rewrites.
CONTEXT_MAX_CHARS = 48
_NORM_EXACT = {
    "home": "Homepage",
}
# Verified safe against the whole catalog: all 26 "cap(s)" hits are the spend/
# size-limit sense (no "hat"/"capital"); all "turnaround" hits are delivery time.
_NORM_PHRASE = {
    "turnaround": "delivery time",
    "caps": "limits",
    "cap": "limit",
    "re-render": "regenerate",
    "re-rendering": "regenerating",
    # "ship" is always the deliver/launch sense in this catalog (verified: 24/24
    # occurrences, zero boat nouns). The bare word collapses to the boat noun in
    # de/es/fr ("Schiff"/"barco"/"navire"), so normalise to "deliver".
    "shipping": "delivering",
    "shipped": "delivered",
    "ships": "delivers",
    "ship": "deliver",
}

# Models occasionally prefix a spurious list-marker ("- Ja. …"). The single-
# sentence path strips it; the merge path didn't, so ~137 leaked into the
# catalog. Our EN source never starts with a marker, so stripping a leading one
# from any translation is always safe.
_LEADING_MARKER_RE = re.compile(r"^\s*[-*•–]\s+")


def strip_leading_marker(text: str) -> str:
    return _LEADING_MARKER_RE.sub("", text, count=1) if text else text


def is_degenerate(text: str) -> bool:
    """Detect hallucinated/garbage output. Happens when a whole string is a
    protected entity (brand/acronym/number) — it masks to a lone sentinel and the
    council "translates" the bare sentinel into junk ("FAQ"→"ZXXXX", "API"→
    "0 0 0 0", "ElevenLabs"→"زرتشت زرتشت…"). Caller falls back to the source,
    which for these brand/number strings is the correct output anyway."""
    t = (text or "").strip()
    if not t:
        return False
    if re.fullmatch(r"[\W_]+", t):                       # only punctuation/symbols
        return True
    if re.search(r"(.)\1{5,}", t):                       # a char repeated 6+ times
        return True
    if "ZXQTERM" in t or re.search(r"\bZX{2,}", t):      # mangled protection sentinel
        return True
    toks = t.split()
    if len(toks) >= 4 and len(set(toks)) == 1:           # one token repeated 4+ times
        return True
    return False
_NORM_PHRASE_RE = re.compile(
    r"\b(" + "|".join(re.escape(k) for k in sorted(_NORM_PHRASE, key=len, reverse=True)) + r")\b",
    re.IGNORECASE,
) if _NORM_PHRASE else None


def normalize_source(text: str) -> str:
    """Rewrite ambiguous chrome terms to unambiguous synonyms (source side)."""
    t = text.strip()
    exact = _NORM_EXACT.get(t.lower())
    if exact is not None and len(t) <= CONTEXT_MAX_CHARS:
        return text.replace(t, exact)
    if _NORM_PHRASE_RE is not None:
        def _sub(m):
            repl = _NORM_PHRASE[m.group(0).lower()]
            return repl[:1].upper() + repl[1:] if m.group(0)[:1].isupper() else repl
        return _NORM_PHRASE_RE.sub(_sub, text)
    return text


# ── engine call (chunked) ────────────────────────────────────────────────
# Set LOCALIZE_PROGRESS=<path> to get a flushed per-chunk progress line — the
# only live signal during a long bulk run (files are written per-locale only).
def http_translate_batch(url: str, chunk: int = 60):
    prog_path = os.getenv("LOCALIZE_PROGRESS")

    def _log(msg: str) -> None:
        if not prog_path:
            return
        with open(prog_path, "a", encoding="utf-8") as fh:
            fh.write(msg + "\n")
            fh.flush()

    def call(texts, src_f, tgt_f, contexts=None):
        translations, cohesion = [], []
        nchunks = (len(texts) + chunk - 1) // chunk
        t0 = time.time()
        for ci, i in enumerate(range(0, len(texts), chunk), 1):
            sl = texts[i:i + chunk]
            payload = {"texts": sl, "source_lang": src_f, "target_lang": tgt_f}
            if contexts is not None:
                payload["contexts"] = contexts[i:i + chunk]
            body = json.dumps(payload).encode()
            req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
            ct = time.time()
            with urllib.request.urlopen(req, timeout=540) as r:
                data = json.loads(r.read().decode())
            tr = data.get("translations") or []
            if len(tr) != len(sl):
                raise RuntimeError(f"engine returned {len(tr)} for {len(sl)} texts")
            translations += tr
            cs = data.get("cohesion_scores")
            cohesion += (cs if isinstance(cs, list) and len(cs) == len(sl) else [None] * len(sl))
            _log(f"[{time.strftime('%H:%M:%S')}] {src_f}->{tgt_f} chunk {ci}/{nchunks} "
                 f"({len(translations)}/{len(texts)} strings) {time.time()-ct:.0f}s "
                 f"elapsed {time.time()-t0:.0f}s")
        return translations, cohesion
    return call


# ── change-detection cache ───────────────────────────────────────────────
def _hash(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8")).hexdigest()[:16]


def load_cache(path: str) -> dict:
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_cache(path: str, cache: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)


# ── core ─────────────────────────────────────────────────────────────────
def localize_file(
    src_text: str, fmt: str, source_locale: str, target_locale: str,
    existing_target_text: str | None, translate_batch_fn, *,
    cache_for_locale: dict, overwrite: bool = False,
) -> "tuple[str, LocaleReport]":
    """Translate one source file into one locale. Pure of I/O so it's testable."""
    units = fmts.extract(src_text, fmt)
    report = LocaleReport(target_locale, total=len(units))

    # Which keys actually need (re)translation? New, source-changed, or --overwrite.
    to_do = []
    for u in units:
        h = _hash(u.source)
        if not overwrite and cache_for_locale.get(u.key) == h:
            report.skipped_unchanged += 1
        else:
            to_do.append((u, h))

    new_translations: "dict[str,str]" = {}
    if to_do:
        # protect every source string; remember tokens to restore + validate
        masked, token_sets = [], []
        for u, _h in to_do:
            # 1) rewrite ambiguous chrome terms to unambiguous synonyms (source side)
            # 2) mask placeholders ({vars}/ICU/<tags>/%s/URLs) — these the engine
            #    can't know about. Brands/acronyms (DeepL, PDF, GDPR) are NOT masked
            #    here: the engine protects entities itself, and client-side masking
            #    of long acronym lists was dropping sentinels (the 29-issue bug).
            m, toks = protect.protect(normalize_source(u.source))
            masked.append(m)
            token_sets.append(toks)
        translated, cohesion = translate_batch_fn(
            masked, flores(source_locale), flores(target_locale))
        for (u, h), out, toks, coh in zip(to_do, translated, token_sets, cohesion):
            issues = protect.validate(out, toks)
            final = strip_leading_marker(protect.restore(out, toks))
            if issues:
                report.issues.append(f"{u.key}: {'; '.join(issues)}")
                # keep source on hard failure so we never ship a broken placeholder
                if any("dropped" in i or "duplicated" in i for i in issues):
                    final = u.source
            # Hallucinated/garbage output (usually a whole-string brand/acronym) —
            # fall back to source, which is the correct text for those anyway.
            if is_degenerate(final) and not is_degenerate(u.source):
                final = u.source
                report.issues.append(f"{u.key}: degenerate output -> kept source")
            new_translations[u.key] = final
            report.translated += 1
            report.cohesion.append(coh)
            cache_for_locale[u.key] = h

    # Choose the merge BASE (the template the translations are written onto):
    #  • --overwrite (full regen): always the SOURCE, so the output structure
    #    mirrors en.json exactly. Merging onto an existing target can inherit a
    #    corrupted shape (e.g. a prior tool wrote arrays as dicts) and then
    #    silently drop array-of-object keys — the bug that leaked stale values.
    #  • incremental: the existing target (preserve prior translations), or the
    #    source as a template when no target exists yet.
    if overwrite or existing_target_text is None:
        base = src_text
    else:
        base = existing_target_text
    out_text = fmts.merge(base, fmt, new_translations) if new_translations else base

    # Safety net: confirm every freshly translated key actually landed. Catches
    # any silent merge/structure mismatch (fmts merge swallows nav errors).
    if new_translations:
        landed = {u.key: u.source for u in fmts.extract(out_text, fmt)}
        lost = [k for k in new_translations if landed.get(k) != new_translations[k]]
        if lost:
            report.issues.append(f"merge dropped {len(lost)} key(s): {lost[:5]}")
    return out_text, report


def _out_path(src_path: str, locale: str, pattern: str) -> str:
    d = os.path.dirname(src_path)
    fn = os.path.basename(src_path)
    base, ext = os.path.splitext(fn)
    # strip a trailing ".en"-style source-locale tag from the base if present
    return pattern.format(dir=d or ".", base=base, ext=ext, locale=locale, name=base)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Traxlate localization CLI")
    ap.add_argument("source", nargs="?", help="source file (e.g. en.json, app.arb)")
    ap.add_argument("--to", help="comma-separated target locales, e.g. es,fr,de")
    ap.add_argument("--from", dest="src_locale", default="en", help="source locale (default en)")
    ap.add_argument("--format", default="auto", help="auto|json|arb|strings|po|xliff")
    ap.add_argument("--engine", default=os.environ.get("TRAXLATE_ENGINE",
                    "https://traxlate.com/api/engine/api/translate_batch"))
    ap.add_argument("--out", default="{dir}/{base}.{locale}{ext}",
                    help="output path pattern (vars: dir base name ext locale)")
    ap.add_argument("--cache", default=".localize-cache.json")
    ap.add_argument("--overwrite", action="store_true", help="retranslate everything")
    ap.add_argument("--dry-run", action="store_true", help="report what would translate, no calls/writes")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args(argv)

    if args.selftest:
        return _selftest()
    if not args.source or not args.to:
        ap.error("source file and --to are required")

    fmt = fmts.detect_format(args.source) if args.format == "auto" else args.format
    with open(args.source, encoding="utf-8") as f:
        src_text = f.read()
    locales = [l.strip() for l in args.to.split(",") if l.strip()]
    cache = load_cache(args.cache)
    tr_fn = http_translate_batch(args.engine)
    rc = 0

    for loc in locales:
        out_path = _out_path(args.source, loc, args.out)
        existing = None
        if os.path.exists(out_path):
            with open(out_path, encoding="utf-8") as f:
                existing = f.read()
        cache_loc = cache.setdefault(loc, {})

        if args.dry_run:
            units = fmts.extract(src_text, fmt)
            todo = sum(1 for u in units if args.overwrite or cache_loc.get(u.key) != _hash(u.source))
            print(f"  {loc}: {todo}/{len(units)} strings would translate -> {out_path}")
            continue

        out_text, rep = localize_file(src_text, fmt, args.src_locale, loc, existing,
                                      tr_fn, cache_for_locale=cache_loc, overwrite=args.overwrite)
        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(out_text)
        flag = f" · {len(rep.issues)} PLACEHOLDER ISSUES" if rep.issues else ""
        print(f"  {loc}: translated {rep.translated}, unchanged {rep.skipped_unchanged} · "
              f"mean cohesion {rep.mean_cohesion}{flag} -> {out_path}")
        for i in rep.issues[:10]:
            print(f"      ! {i}")
        if rep.issues:
            rc = 2

    if not args.dry_run:
        save_cache(args.cache, cache)
    return rc


# ─────────────────────────────────────────────────────────────────────────
def _selftest() -> int:
    ok = 0

    def check(name, cond):
        nonlocal ok
        print(f"  [{'ok' if cond else 'FAIL'}] {name}")
        assert cond, name
        ok += 1

    # fake engine: "translate" = uppercase the masked text, perfect cohesion,
    # placeholders preserved (because they were masked out).
    def fake(texts, src_f, tgt_f, contexts=None):
        return [t.upper() for t in texts], [0.95] * len(texts)

    src = json.dumps({"greeting": "Hello {name}", "cta": "Buy <b>now</b>", "n": "Plain"})
    cache: dict = {}
    out, rep = localize_file(src, "json", "en", "es", None, fake, cache_for_locale=cache)
    o = json.loads(out)
    # the fake uppercases visible words too; what matters is the {name}/<b></b>
    # placeholders came back intact, not the casing of "now".
    check("placeholders survived", o["greeting"] == "HELLO {name}" and o["cta"] == "BUY <b>NOW</b>")
    check("all translated", rep.translated == 3 and rep.skipped_unchanged == 0)
    check("no placeholder issues", rep.issues == [])
    check("cache populated", len(cache) == 3)

    # second run: nothing changed -> everything skipped (change detection)
    out2, rep2 = localize_file(src, "json", "en", "es", out, fake, cache_for_locale=cache)
    check("change-detect skips unchanged", rep2.translated == 0 and rep2.skipped_unchanged == 3)

    # change one source string -> only that one re-translates
    src3 = json.dumps({"greeting": "Hello {name}!", "cta": "Buy <b>now</b>", "n": "Plain"})
    _, rep3 = localize_file(src3, "json", "en", "es", out, fake, cache_for_locale=cache)
    check("change-detect retranslates only changed", rep3.translated == 1 and rep3.skipped_unchanged == 2)

    # a broken engine that DROPS a placeholder -> flagged + source kept (not shipped)
    def broken(texts, src_f, tgt_f, contexts=None):
        return [protect._RESTORE.sub("", t) for t in texts], [0.5] * len(texts)  # eats every token
    out4, rep4 = localize_file(json.dumps({"k": "Hi {name}"}), "json", "en", "es", None,
                               broken, cache_for_locale={})
    check("dropped placeholder flagged", len(rep4.issues) == 1)
    check("broken segment falls back to source", json.loads(out4)["k"] == "Hi {name}")

    # ── array-of-object overwrite must NOT inherit a corrupted target shape ──
    arr_src = json.dumps({"faqs": [{"a": "One"}, {"a": "Two"}]})
    corrupt = json.dumps({"faqs": {"0": {"a": "Uno"}, "1": {"a": "Dos"}}})  # arrays-as-dicts
    outA, repA = localize_file(arr_src, "json", "en", "es", corrupt, fake,
                               cache_for_locale={}, overwrite=True)
    oA = json.loads(outA)
    check("overwrite rebuilds correct array structure", isinstance(oA["faqs"], list))
    check("array-of-object keys translated (no silent drop)",
          oA["faqs"][0]["a"] == "ONE" and oA["faqs"][1]["a"] == "TWO")
    check("merge-drop safety net clean", not any("merge dropped" in i for i in repA.issues))

    # ── source-side sense normalization (catalog chrome) ──
    check("exact nav term normalized", normalize_source("Home") == "Homepage")
    check("exact term untouched in prose", normalize_source("Welcome home, friend") == "Welcome home, friend")
    check("phrase term normalized in sentence",
          normalize_source("{days}-day turnaround per 5,000 chars") == "{days}-day delivery time per 5,000 chars")
    check("usage caps -> usage limits", normalize_source("Every key has usage caps.") == "Every key has usage limits.")

    # normalization feeds the transport (the engine sees the unambiguous source)
    seen = {}
    def norm_fake(texts, src_f, tgt_f, contexts=None):
        seen["t"] = texts
        return [t.upper() for t in texts], [0.95] * len(texts)
    localize_file(json.dumps({"nav.home": "Home"}), "json", "en", "es", None,
                  norm_fake, cache_for_locale={})
    check("normalized source reaches engine", seen["t"][0] == "Homepage")

    print(f"\n{ok} checks passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
