"""
Placeholder / markup / ICU protection for machine translation.

Real-world UI and web strings are full of things that MUST survive translation
byte-for-byte or the app breaks: variables (`{name}`, `%s`), ICU plural/select
blocks, HTML tags & entities, handlebars, URLs, emails. MT models happily
translate, reorder, or drop them. This module masks them out before translation
and restores them after — and *validates* that none were lost or duplicated, so
a bad segment can be flagged instead of shipped.

    masked, tokens = protect(source)
    translated_masked = engine.translate(masked, ...)        # MT never sees the tokens' contents
    issues = validate(translated_masked, tokens)             # [] == safe
    final = restore(translated_masked, tokens)

Design:
  * Sentinels are `⟦N⟧` (rare math brackets). Restore tolerates whitespace the
    model may inject (`⟦ 0 ⟧`) and stays case-insensitive on the brackets.
  * ICU plural/select blocks are protected *whole* — breaking their structure
    crashes apps, so we never risk it (translating the inner sub-messages is a
    later, optional refinement).
  * `validate()` is the safety net: if the model dropped or cloned a token, you
    get a precise report and can fall back / retry / human-review that segment.

Pure stdlib. Run `python i18n_protect.py` for the test suite.
"""
from __future__ import annotations

import re
from typing import Callable

# Sentinel wrapping a token index. We use the engine's own battle-tested ASCII
# marker (ZXQTERM<n>ZXQ) instead of unicode brackets, because the translation
# council passes this through intact whereas it mangles "⟦n⟧" (which silently
# forced source-fallback on every string with a placeholder or name).
_OPEN, _CLOSE = "ZXQTERM", "ZXQ"

# Ordered, most-specific-first. None of these contain capturing groups, so a
# single combined alternation can scan left-to-right, non-overlapping.
_PATTERNS: list[tuple[str, str]] = [
    # HTML / XML tags  (<a href="...">, </p>, <br/>)
    ("tag",        r"</?[A-Za-z][^<>]*?/?>"),
    # HTML entities  (&amp; &#39; &#x2F;)
    ("entity",     r"&(?:#\d+|#x[0-9A-Fa-f]+|[A-Za-z][A-Za-z0-9]*);"),
    # Handlebars / Mustache  ({{user.name}}, {{> partial}})
    ("handlebars", r"\{\{[^{}]+\}\}"),
    # printf / format specifiers  (%s, %d, %1$s, %.2f, %(name)s)
    ("printf",     r"%(?:\(\w+\))?(?:\d+\$)?[-+ 0#]*\d*(?:\.\d+)?[bcdeEfFgGosuxX%@]"),
    # Simple named/indexed placeholders  ({name}, {0}, {user_id})
    ("var",        r"\{[A-Za-z0-9_.\- ]*[A-Za-z0-9_.\-]\}"),
    # Bare URLs and emails
    ("url",        r"https?://[^\s<>()]+"),
    ("email",      r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}"),
    # Escaped control sequences that appear literally in resource strings
    ("escape",     r"\\[nrt]"),
]
_COMBINED = re.compile("|".join(f"(?:{p})" for _, p in _PATTERNS))

# An ICU block is a balanced {...} whose argument uses a known formatter.
_ICU_KEYWORDS = ("plural", "select", "selectordinal", "number", "date", "time")
_RESTORE = re.compile(_OPEN + r"\s*(\d+)\s*" + _CLOSE, re.IGNORECASE)


def _mask_icu(text: str, add: Callable[[str], str]) -> str:
    """Replace whole ICU plural/select/number/date blocks with a sentinel."""
    out: list[str] = []
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch == "{" and not text.startswith("{{", i):
            # find the matching close brace (balanced)
            depth, j = 0, i
            while j < n:
                if text[j] == "{":
                    depth += 1
                elif text[j] == "}":
                    depth -= 1
                    if depth == 0:
                        break
                j += 1
            if depth == 0 and j < n:
                block = text[i : j + 1]
                inner = block[1:-1]
                # ICU args look like:  {name, plural, ...}  /  {when, date, short}
                head = inner.split(",", 2)
                if len(head) >= 2 and head[1].strip() in _ICU_KEYWORDS:
                    out.append(add(block))
                    i = j + 1
                    continue
        out.append(ch)
        i += 1
    return "".join(out)


def _mask_terms(text: str, dnt, glossary, add: Callable[[str], str]) -> str:
    """Mask do-not-translate brand terms and glossary source-terms.

    A masked DNT term restores to its ORIGINAL text (so "DeepL" can never become
    "La profundidad"). A masked glossary term restores to its TARGET — the engine
    never sees the word and we splice in the pinned translation afterwards. Hard
    term enforcement using only our own masking."""
    lookup: dict[str, tuple[str, str]] = {}
    for t in dnt or ():
        if t:
            lookup[t.lower()] = ("dnt", t)
    for src, tgt in (glossary or {}).items():
        if src:
            lookup[src.lower()] = ("glo", tgt)
    if not lookup:
        return text
    terms = sorted(lookup.keys(), key=len, reverse=True)   # longest first
    pat = re.compile(r"(?<!\w)(" + "|".join(re.escape(t) for t in terms) + r")(?!\w)", re.IGNORECASE)

    def repl(m: re.Match) -> str:
        kind, val = lookup[m.group(0).lower()]
        return add(m.group(0) if kind == "dnt" else val)
    return pat.sub(repl, text)


_WORD = re.compile(r"[^\W_]+(?:[._'\-][^\W_]+)*", re.UNICODE)


def _is_entity(tok: str) -> bool:
    """Shape-based proper-noun / identifier detector — NO word list.

    Catches the tokens MT mistranslates as common nouns: CamelCase brands
    (DeepL, ElevenLabs, HeyGen, WordPress), ALL-CAPS acronyms (GDPR, API, SRT,
    USCIS), and alphanumerics (m2m100, H100). Deliberately does NOT touch plain
    TitleCase words (Hello, Spanish, Legal) — those are normal language and may
    need translating. Generalises to arbitrary input, which a glossary cannot."""
    if len(tok) < 2 or not any(c.isalpha() for c in tok):
        return False
    if tok.isupper():                                   # GDPR, API, SRT, USCIS
        return True
    if any(c.isdigit() for c in tok):                   # m2m100, H100, GPT4
        return True
    for i in range(1, len(tok)):                        # internal capital → CamelCase
        if tok[i].isupper() and tok[i - 1].isalpha():
            return True
    return False


def protect(text: str, *, dnt=(), glossary=None, auto_entities: bool = False) -> tuple[str, list[str]]:
    """Mask everything that must survive translation. Returns (masked, tokens).

    `dnt` (do-not-translate brand terms) and `glossary` (source -> target) give
    explicit control; `auto_entities` turns on the list-free proper-noun guard
    (recommended for arbitrary user text) so brands/acronyms survive without any
    curated list."""
    tokens: list[str] = []

    def add(s: str) -> str:
        tokens.append(s)
        return f"{_OPEN}{len(tokens) - 1}{_CLOSE}"

    text = _mask_terms(text, dnt, glossary, add)
    # Entity guard runs on near-raw text (after term masking, BEFORE tag/
    # placeholder masking) so its word-scan never collides with sentinels —
    # an all-ASCII sentinel glued to text (e.g. <b>now</b>) would otherwise be
    # swallowed as one "word".
    if auto_entities:
        def _ent(m: re.Match) -> str:
            w = m.group(0)
            if _RESTORE.fullmatch(w):          # never re-mask an isolated sentinel
                return w
            return add(w) if _is_entity(w) else w
        text = _WORD.sub(_ent, text)
    text = _mask_icu(text, add)
    text = _COMBINED.sub(lambda m: add(m.group(0)), text)
    return text, tokens


def restore(text: str, tokens: list[str]) -> str:
    """Put the protected spans back, tolerant of spacing the model injected."""
    def repl(m: re.Match) -> str:
        idx = int(m.group(1))
        return tokens[idx] if 0 <= idx < len(tokens) else m.group(0)
    return _RESTORE.sub(repl, text)


def validate(translated_masked: str, tokens: list[str]) -> list[str]:
    """Return a list of problems; empty list means the translation is safe.

    Catches the two dangerous MT failure modes: a placeholder the model
    *dropped* (would break the app) and one it *duplicated* (would double-print
    a variable). Order is intentionally NOT checked — languages reorder."""
    found = [int(x) for x in _RESTORE.findall(translated_masked)]
    counts: dict[int, int] = {}
    for idx in found:
        counts[idx] = counts.get(idx, 0) + 1
    issues: list[str] = []
    for idx in range(len(tokens)):
        c = counts.get(idx, 0)
        if c == 0:
            issues.append(f"dropped placeholder {idx} ({tokens[idx]!r})")
        elif c > 1:
            issues.append(f"duplicated placeholder {idx} ({tokens[idx]!r}) ×{c}")
    for idx in counts:
        if idx >= len(tokens):
            issues.append(f"hallucinated placeholder index {idx}")
    return issues


def translate_protected(text: str, translate_fn: Callable[[str], str]) -> tuple[str, list[str]]:
    """Convenience: protect → translate → validate → restore.
    Returns (final_text, issues). If issues is non-empty, caller should treat
    the result as low-confidence (retry / fall back to source / human review)."""
    masked, tokens = protect(text)
    if not tokens:
        return translate_fn(text), []          # nothing to protect — translate raw
    translated = translate_fn(masked)
    issues = validate(translated, tokens)
    return restore(translated, tokens), issues


# ─────────────────────────────────────────────────────────────────────────
# Test suite — run: python i18n_protect.py
# ─────────────────────────────────────────────────────────────────────────
def _run_tests() -> None:
    ok = 0

    def check(name: str, cond: bool, extra: str = "") -> None:
        nonlocal ok
        status = "ok" if cond else "FAIL"
        if cond:
            ok += 1
        print(f"  [{status}] {name}{(' — ' + extra) if extra and not cond else ''}")
        assert cond, f"{name} {extra}"

    # 1) round-trip: protect then restore yields the original exactly
    samples = [
        "Hello {name}, you have {count} unread messages.",
        "Welcome %s — you are user %1$d of %d.",
        'Click <a href="/x?a=1&b=2">here</a> &amp; continue.',
        "Hi {{user.name}}, see {{> footer}}.",
        "Email us at help@traxlate.com or visit https://traxlate.com/docs?x=1.",
        "Line one\\nLine two\\tTabbed.",
        "{count, plural, one {# item left} other {# items left}}",
        "{gender, select, male {He} female {She} other {They}} replied.",
        "Mix: <b>{n}</b> files for %s at https://a.co — {when, date, short}.",
    ]
    for s in samples:
        masked, toks = protect(s)
        check(f"round-trip exact: {s[:40]!r}", restore(masked, toks) == s)

    # 2) the model never sees protected content (no raw vars/tags leak through)
    masked, toks = protect('Save <b>{count}</b> with %s at https://x.co')
    check("all spans masked", not re.search(r"[<>{}%]|https?://", masked), masked)
    # <b>, {count}, </b>, %s, https://x.co  → five protected spans
    check("token count", len(toks) == 5, f"got {len(toks)}: {toks}")

    # 3) ICU block is protected WHOLE (structure can't be broken)
    masked, toks = protect("{count, plural, one {# item} other {# items}}")
    check("ICU is one token", len(toks) == 1 and toks[0].startswith("{count, plural"))

    # 4) simulate a model that reorders + injects spaces around tokens (RTL-ish)
    masked, toks = protect("Save {count} files to {dir}")
    pretend = masked.replace("Save", "Guardar").replace("files to", "archivos en")
    pretend = pretend.replace(_OPEN + "0" + _CLOSE, _OPEN + " 0 " + _CLOSE)  # injected spaces
    a, b = pretend.split(" archivos en ")  # reorder the two placeholders
    reordered = b.strip() + " archivos en " + a.split("Guardar ")[1].strip()
    check("validate passes after reorder+spacing", validate(reordered, toks) == [])
    check("restore after reorder", "{count}" in restore(reordered, toks) and "{dir}" in restore(reordered, toks))

    # 5) validate CATCHES a dropped placeholder
    masked, toks = protect("You have {count} new {type} alerts")
    dropped = masked.replace(_OPEN + "1" + _CLOSE, "")  # model ate {type}
    issues = validate(dropped, toks)
    check("dropped placeholder caught", any("dropped placeholder 1" in i for i in issues), str(issues))

    # 6) validate CATCHES a duplicated placeholder
    dup = masked + " " + _OPEN + "0" + _CLOSE
    check("duplicated placeholder caught", any("duplicated placeholder 0" in i for i in validate(dup, toks)))

    # 7) end-to-end helper with a fake translator that keeps tokens intact
    def fake_tr(t: str) -> str:
        return t.replace("Hello", "Hola").replace("messages", "mensajes")
    final, issues = translate_protected("Hello {user}, {n} messages", fake_tr)
    check("e2e clean", issues == [] and final == "Hola {user}, {n} mensajes", final)

    # 8) no-placeholder strings pass straight through
    final, issues = translate_protected("Just plain text.", lambda t: "Texto simple.")
    check("plain passthrough", final == "Texto simple." and issues == [])

    # 9) do-not-translate brand + glossary term pinning
    masked, toks = protect("Try DeepL for dubbing.", dnt=["DeepL"], glossary={"dubbing": "doblaje"})
    check("brand+term masked out", "DeepL" not in masked and "dubbing" not in masked)
    pretend = masked.replace("Try", "Prueba").replace("for", "para")   # engine does its thing
    out = restore(pretend, toks)
    check("DNT brand restored verbatim", "DeepL" in out)
    check("glossary pins target term", "doblaje" in out and "dubbing" not in out)

    # 10) multi-word DNT + case-insensitive match, longest-first
    masked, toks = protect("google translate vs Google.", dnt=["Google Translate", "Google"])
    check("multi-word + case-insensitive DNT", restore(
        masked.replace("vs", "frente a"), toks) == "google translate frente a Google.")

    # 11) list-free auto entity guard: brands/acronyms/identifiers preserved,
    #     normal words left translatable
    check("entity: CamelCase", _is_entity("DeepL") and _is_entity("ElevenLabs") and _is_entity("WordPress"))
    check("entity: ALLCAPS", _is_entity("GDPR") and _is_entity("API") and _is_entity("USCIS"))
    check("entity: alphanumeric", _is_entity("m2m100") and _is_entity("H100"))
    check("entity: NOT plain words", not _is_entity("Hello") and not _is_entity("Spanish")
          and not _is_entity("legal") and not _is_entity("Don't"))
    masked, toks = protect("Try DeepL and ElevenLabs with GDPR via m2m100.", auto_entities=True)
    check("auto masks brands/acronyms", all(x not in masked for x in ("DeepL", "ElevenLabs", "GDPR", "m2m100")))
    check("auto keeps normal words", "Try" in masked and "with" in masked and "via" in masked)
    out = restore(masked.replace("Try", "Prueba").replace("and", "y").replace("with", "con").replace("via", "vía"), toks)
    check("auto restores entities verbatim", out == "Prueba DeepL y ElevenLabs con GDPR vía m2m100.")

    print(f"\n{ok} checks passed.")


if __name__ == "__main__":
    _run_tests()
