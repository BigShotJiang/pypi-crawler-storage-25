"""Async transport helpers for the Sandai operator client."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, Optional

from .config import ClientConfig
from .transport import CeleryTransport

logger = logging.getLogger(__name__)


class AsyncTransportAdapter:
    """Async wrapper over the shared synchronous Celery transport."""

    def __init__(self, config: ClientConfig, logger_: Optional[logging.Logger] = None):
        self.config = config
        self.logger = logger_ or logger
        self.celery = CeleryTransport(config, logger=self.logger)
        self.app = self.celery.app
        self._closed = False

    async def aclose(self) -> None:
        if self._closed:
            return
        self._closed = True
        await asyncio.to_thread(self.celery.close)

    async def send_task(self, task_name: str, *, kwargs: Dict[str, Any], queue: str) -> Any:
        return await asyncio.to_thread(
            self.celery.send_task,
            task_name,
            kwargs=kwargs,
            queue=queue,
        )

    async def get_result(self, async_result: Any, *, timeout: int) -> Any:
        return await asyncio.to_thread(self.celery.get_result, async_result, timeout=timeout)

    async def forget(self, async_result: Any) -> None:
        await asyncio.to_thread(self.celery.forget, async_result)

    async def result_exists(self, async_result: Any) -> bool:
        return await asyncio.to_thread(self.celery.result_exists, async_result)

    async def get_state(self, async_result: Any) -> str:
        return await asyncio.to_thread(self.celery.get_state, async_result)
