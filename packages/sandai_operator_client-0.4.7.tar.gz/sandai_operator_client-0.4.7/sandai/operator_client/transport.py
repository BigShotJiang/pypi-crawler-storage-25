"""Celery transport adapter for the Sandai operator client."""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional

from celery.result import AsyncResult

from .config import ClientConfig
from .shared_transport import (
    acquire_shared_app,
    acquire_shared_backend,
    acquire_shared_broker,
    release_shared_app,
    release_shared_backend,
    release_shared_broker,
)

_PENDING_STATES = {"PENDING", "RECEIVED", "STARTED", "RETRY"}


class BoundedRedisAsyncResult(AsyncResult):
    """AsyncResult wrapper that keeps Redis result access on the bounded path."""

    def __init__(self, task_id: str, *, app: Any, transport: "CeleryTransport"):
        super().__init__(task_id, app=app)
        self.id = task_id
        self._sandai_transport = transport

    def get(self, timeout: Optional[int] = None, propagate: bool = True, **kwargs: Any) -> Any:
        effective_timeout = self._sandai_transport.config.timeout if timeout is None else int(timeout)
        result = self._sandai_transport.get_result(self, timeout=effective_timeout)
        if propagate and isinstance(result, BaseException):
            raise result
        return result

    def forget(self) -> None:
        self._sandai_transport.forget(self)

    @property
    def state(self) -> str:
        return self._sandai_transport.get_state(self)

    def ready(self) -> bool:
        return self.state not in _PENDING_STATES


class CeleryTransport:
    """Wrap shared Celery app creation and bounded task/result interactions."""

    def __init__(self, config: ClientConfig, logger: Optional[logging.Logger] = None):
        self.config = config
        self.logger = logger or logging.getLogger(__name__)
        self._broker_state = acquire_shared_broker(config)
        self._backend_state = acquire_shared_backend(config)
        self._prefer_backend_polling = self._supports_backend_polling()
        self._app_state = None
        if not self._prefer_backend_polling:
            self._app_state = acquire_shared_app(config)
        self.app = self._broker_state.app if self._prefer_backend_polling else self._app_state.app
        self._closed = False

    def _supports_backend_polling(self) -> bool:
        return self._backend_state.redis_client is not None

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._app_state is not None:
            release_shared_app(self._app_state)
        release_shared_broker(self._broker_state)
        release_shared_backend(self._backend_state)

    def _wrap_async_result(self, async_result: AsyncResult) -> AsyncResult:
        task_id = getattr(async_result, "id", None)
        if not self._prefer_backend_polling or not task_id:
            return async_result
        return BoundedRedisAsyncResult(task_id, app=self.app, transport=self)

    def send_task(self, task_name: str, *, kwargs: Dict[str, Any], queue: str) -> AsyncResult:
        if self.config.debug:
            self.logger.debug("sending task to queue=%s payload=%s", queue, kwargs)
        with self._broker_state.limiter.acquire(self.config.pool_acquire_timeout):
            connection_factory = getattr(self.app, "connection_for_write", None)
            if callable(connection_factory):
                connection_ctx = connection_factory()
                if hasattr(connection_ctx, "__enter__") and hasattr(connection_ctx, "__exit__"):
                    with connection_ctx as connection:
                        try:
                            from kombu import Producer

                            producer = Producer(connection, auto_declare=False)
                        except ImportError:  # pragma: no cover - test stubs without kombu
                            producer = None
                        result = self.app.send_task(
                            task_name,
                            kwargs=kwargs,
                            queue=queue,
                            connection=connection,
                            producer=producer,
                        )
                else:
                    result = self.app.send_task(task_name, kwargs=kwargs, queue=queue)
            else:
                result = self.app.send_task(task_name, kwargs=kwargs, queue=queue)
        wrapped = self._wrap_async_result(result)
        if self.config.debug:
            self.logger.debug("task submitted id=%s", getattr(wrapped, "id", None))
        return wrapped

    def _poll_result_meta(self, task_id: str, *, timeout: int) -> Any:
        deadline = time.monotonic() + max(0, timeout)
        backend = self._backend_state.app.backend
        redis_client = self._backend_state.redis_client
        while True:
            with self._backend_state.limiter.acquire(self.config.pool_acquire_timeout):
                payload = redis_client.get(backend.get_key_for_task(task_id))
                if not payload:
                    meta = {"status": "PENDING", "result": None}
                else:
                    meta = backend.decode_result(payload)

            status = str(meta.get("status", "PENDING")) if isinstance(meta, dict) else "PENDING"
            if status not in _PENDING_STATES:
                result = meta.get("result") if isinstance(meta, dict) else None
                if isinstance(result, BaseException):
                    raise result
                return result

            if time.monotonic() >= deadline:
                raise TimeoutError(f"operation timed out after {timeout} seconds")
            time.sleep(0.05)

    def get_result(self, async_result: AsyncResult, *, timeout: int) -> Any:
        task_id = getattr(async_result, "id", None)
        if getattr(self, "_prefer_backend_polling", False) and task_id:
            return self._poll_result_meta(task_id, timeout=timeout)
        result = async_result.get(timeout=timeout, propagate=False)
        if isinstance(result, BaseException):
            raise result
        return result

    def forget(self, async_result: AsyncResult) -> None:
        task_id = getattr(async_result, "id", None)
        backend = getattr(self._backend_state.app, "backend", None)
        if getattr(self, "_prefer_backend_polling", False) and task_id:
            with self._backend_state.limiter.acquire(self.config.pool_acquire_timeout):
                self._backend_state.redis_client.delete(backend.get_key_for_task(task_id))
            return
        async_result.forget()

    def result_exists(self, async_result: AsyncResult) -> bool:
        task_id = getattr(async_result, "id", None)
        backend = getattr(self._backend_state.app, "backend", None)
        if getattr(self, "_prefer_backend_polling", False) and task_id:
            with self._backend_state.limiter.acquire(self.config.pool_acquire_timeout):
                payload = self._backend_state.redis_client.get(backend.get_key_for_task(task_id))
                meta = {"status": "PENDING", "result": None} if not payload else backend.decode_result(payload)
            status = str(meta.get("status", "PENDING")) if isinstance(meta, dict) else "PENDING"
            return status != "PENDING"
        return getattr(async_result, "state", "PENDING") != "PENDING"

    def get_state(self, async_result: AsyncResult) -> str:
        task_id = getattr(async_result, "id", None)
        backend = getattr(self._backend_state.app, "backend", None)
        if getattr(self, "_prefer_backend_polling", False) and task_id:
            with self._backend_state.limiter.acquire(self.config.pool_acquire_timeout):
                payload = self._backend_state.redis_client.get(backend.get_key_for_task(task_id))
                meta = {"status": "PENDING", "result": None} if not payload else backend.decode_result(payload)
            return str(meta.get("status", "PENDING")) if isinstance(meta, dict) else "PENDING"
        return str(getattr(async_result, "state", "PENDING"))
