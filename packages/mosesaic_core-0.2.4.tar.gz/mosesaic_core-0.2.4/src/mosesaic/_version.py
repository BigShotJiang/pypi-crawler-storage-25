try:
    from importlib.metadata import version
    __version__ = version("mosesaic-core")
except Exception:
    __version__ = "unknown"

from mosesaic.core import (
    AgentMessage,
    MessageType,
    AgentContext,
    AgentRuntime,
    AgentDefinition,
    SupervisorPolicy,
    AgentCostEvent,
    agent,
)

__all__ = [
    "__version__",
    "AgentMessage",
    "MessageType",
    "AgentContext",
    "AgentRuntime",
    "AgentDefinition",
    "SupervisorPolicy",
    "AgentCostEvent",
    "agent",
]
