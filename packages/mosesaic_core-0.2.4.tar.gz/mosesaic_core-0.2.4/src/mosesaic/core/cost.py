from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone

from mosesaic.exceptions import MosesaicBudgetExceeded


@dataclass
class AgentCostEvent:
    """Records the cost of a single LLM call."""

    agent_name: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    trace_id: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class CostTracker:
    """Tracks cumulative spend per agent and enforces budget limits.

    Usage:
        tracker = CostTracker(budget_usd=0.50, agent_name="researcher")
        tracker.check_before_call(estimated_cost_usd=0.02, call_description="llm.chat")
        # ... make the call ...
        tracker.record(AgentCostEvent(...))
    """

    def __init__(
        self,
        budget_usd: float | None = None,
        agent_name: str | None = None,
    ) -> None:
        self._budget_usd = budget_usd
        self._agent_name = agent_name
        self._events: list[AgentCostEvent] = []
        self._spent_by_agent: dict[str, float] = defaultdict(float)
        self._total_spent: float = 0.0

    @property
    def spent_usd(self) -> float:
        return self._total_spent

    @property
    def remaining_usd(self) -> float | None:
        if self._budget_usd is None:
            return None
        return max(0.0, self._budget_usd - self._total_spent)

    def record(self, event: AgentCostEvent) -> None:
        """Record a completed LLM call's cost."""
        self._events.append(event)
        self._total_spent += event.cost_usd
        self._spent_by_agent[event.agent_name] += event.cost_usd

    def check_before_call(self, estimated_cost_usd: float, call_description: str) -> None:
        """Raise MosesaicBudgetExceeded if this call would exceed the budget.

        Call this BEFORE every LLM call. If no budget_usd configured, always passes.
        """
        if self._budget_usd is None:
            return
        if self._total_spent + estimated_cost_usd > self._budget_usd:
            raise MosesaicBudgetExceeded(
                agent_name=self._agent_name or "unknown",
                spent_usd=self._total_spent,
                budget_usd=self._budget_usd,
                blocked_call=call_description,
            )

    def spent_by_agent(self, agent_name: str) -> float:
        return self._spent_by_agent.get(agent_name, 0.0)

    def all_events(self) -> list[AgentCostEvent]:
        return list(self._events)
