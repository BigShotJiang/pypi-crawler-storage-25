"""Shared progress event channel for streaming workflow execution details.

Usage:
    - RunRegistry._execute_workflow sets _progress_queue before running a workflow.
    - LLMContext.chat(), AgentContext.spawn(), and _runner.py call emit_progress().
    - The SSE route drains the queue every 250ms and forwards events to the client.

All emitters use emit_progress() which is non-blocking and safe to call from any
depth of the nested spawn tree — the queue propagates via asyncio ContextVar.
"""

from __future__ import annotations

import asyncio
from contextvars import ContextVar
from dataclasses import dataclass

# Set by RunRegistry before starting a workflow run; inherited by all child
# coroutines in the same task (asyncio propagates ContextVars to child tasks).
_progress_queue: ContextVar[asyncio.Queue | None] = ContextVar(
    "_progress_queue", default=None
)


@dataclass
class ProgressEvent:
    """A single progress notification emitted during workflow execution."""

    type: str
    """
    One of:
      step_start  — a workflow step (director) began
      step_done   — a workflow step finished
      spawn_start — a specialist agent was spawned by a director
      spawn_done  — a spawned specialist finished
      llm_call    — ctx.llm.chat() completed; carries model/provider/cost
    """
    agent: str
    """Name of the agent emitting or being described by this event."""

    parent: str | None = None
    """For spawn events: the director that spawned this specialist."""

    model: str | None = None
    """Model ID used for this LLM call (e.g. 'claude-opus-4-6')."""

    provider: str | None = None
    """Provider name (e.g. 'anthropic', 'groq', 'ollama')."""

    input_tokens: int | None = None
    output_tokens: int | None = None
    cost_usd: float | None = None


def emit_progress(event: ProgressEvent) -> None:
    """Emit a progress event to the current run's queue (non-blocking, safe to ignore)."""
    q = _progress_queue.get()
    if q is not None:
        try:
            q.put_nowait(event)
        except asyncio.QueueFull:
            pass  # never block an agent for a progress event
