from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Coroutine, Literal

from mosesaic.core.context import AgentContext


@dataclass
class SupervisorPolicy:
    """Controls restart and budget behaviour for an agent.

    Args:
        budget_usd: Hard spend cap. None = unlimited.
        max_restarts: How many times to restart before escalating.
        restart_window_seconds: Restart count resets after this many seconds.
        on_failure: What to do after max_restarts exceeded.
    """

    budget_usd: float | None = None
    max_restarts: int = 3
    restart_window_seconds: int = 60
    on_failure: Literal["restart", "escalate", "stop"] = "restart"


@dataclass
class AgentDefinition:
    """The result of applying @agent to an async function.

    Do not instantiate directly — use the @agent decorator.
    """

    name: str
    fn: Callable[[AgentContext], Coroutine[Any, Any, None]]
    supervisor_policy: SupervisorPolicy = field(default_factory=SupervisorPolicy)
    tools: list[str] = field(default_factory=list)
    system_prompt: str | None = None
    governance_tier: int = 1


def agent(
    name: str,
    supervisor: SupervisorPolicy | None = None,
    tools: list[str] | None = None,
    system_prompt: str | None = None,
    governance_tier: int = 1,
) -> Callable:
    """Decorator that registers an async function as an agent.

    Args:
        name: Unique agent name.
        supervisor: Restart + budget policy. Defaults to SupervisorPolicy().
        tools: Explicit allow-list of tool names. Empty = unrestricted.
        system_prompt: System prompt prepended to every LLM chat call.
        governance_tier: 1=auto, 2=async-notify human, 3=sync human_gate.
            Must be 1, 2, or 3.

    Usage:
        @agent(name="researcher", supervisor=SupervisorPolicy(budget_usd=0.50))
        async def researcher(ctx: AgentContext) -> None:
            msg = await ctx.receive()
            ...
    """
    if governance_tier not in (1, 2, 3):
        raise ValueError(
            f"governance_tier must be 1, 2, or 3, got {governance_tier!r}"
        )

    def decorator(fn: Callable) -> AgentDefinition:
        return AgentDefinition(
            name=name,
            fn=fn,
            supervisor_policy=supervisor or SupervisorPolicy(),
            tools=tools or [],
            system_prompt=system_prompt,
            governance_tier=governance_tier,
        )

    return decorator
