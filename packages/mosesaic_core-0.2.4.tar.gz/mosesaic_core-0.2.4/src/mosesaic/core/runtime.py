from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator

import anyio

from mosesaic.core.agent import AgentDefinition
from mosesaic.core.bus import MessageBus
from mosesaic.core.message import AgentMessage, MessageType
from mosesaic.core.spawner import Spawner
from mosesaic.core.supervisor import Supervisor
from mosesaic.exceptions import MosesaicAgentNotFound

logger = logging.getLogger(__name__)


class AgentRuntime:
    """The main entry point for Mosesaic.

    Register agents, then use as an async context manager to start them.
    Send messages via runtime.send(). Inspect the event log via runtime.event_log().

    Usage (no LLM):
        runtime = AgentRuntime()
        runtime.register(my_agent)
        async with runtime.run():
            await runtime.send("my-agent", payload="start task")

    Usage (with LLM):
        from mosesaic.llm.registry import ProviderRegistry
        from mosesaic.llm.providers.anthropic import AnthropicProvider
        registry = ProviderRegistry()
        registry.register(AnthropicProvider(api_key=...))
        runtime = AgentRuntime(llm=registry)
    """

    def __init__(
        self,
        llm: Any | None = None,
        tools: Any | None = None,
        tool_policy: Any | None = None,
        memory: Any | None = None,
        llm_overrides: dict[str, str] | None = None,
    ) -> None:
        self._bus = MessageBus()
        self._definitions: dict[str, AgentDefinition] = {}
        self._supervisors: dict[str, Supervisor] = {}
        self._llm_registry = llm          # ProviderRegistry or None
        self._tool_registry = tools       # ToolRegistry or None
        self._tool_policy = tool_policy   # ToolPolicy or None
        self._memory = memory             # MemoryContext or None
        self._llm_overrides: dict[str, str] = llm_overrides or {}

    def _make_llm_factory(self):
        """Build a factory that creates an LLMContext per agent, if registry is set."""
        if self._llm_registry is None:
            return None
        registry = self._llm_registry
        overrides = self._llm_overrides

        def factory(agent_name: str, cost_tracker: Any, system_prompt: str | None = None) -> Any:
            from mosesaic.llm.context import LLMContext  # lazy — avoids hard dep in core
            return LLMContext(
                registry=registry,
                cost_tracker=cost_tracker,
                agent_name=agent_name,
                system_prompt=system_prompt,
                preferred_model=overrides.get(agent_name),
            )

        return factory

    def _make_tools_factory(self, definition: AgentDefinition | None = None):
        """Build a factory that creates a ToolContext per agent, if registry is set.

        If definition.tools is non-empty, the ToolContext is restricted to only
        those tools via ToolPolicy.allow_only (capability manifest pattern).
        """
        if self._tool_registry is None:
            return None
        registry = self._tool_registry
        global_policy = self._tool_policy
        allowed_tools = definition.tools if definition is not None else []

        def factory(agent_name: str) -> Any:
            from mosesaic.tools.context import ToolContext  # lazy — avoids hard dep in core
            from mosesaic.tools.policy import ToolPolicy    # lazy
            if allowed_tools:
                # Per-agent allow-list overrides global policy
                policy = ToolPolicy(allow_only=list(allowed_tools))
            else:
                policy = global_policy
            return ToolContext(registry=registry, policy=policy, agent_name=agent_name)

        return factory

    def register(self, definition: AgentDefinition) -> None:
        """Register an agent definition with the runtime."""
        self._definitions[definition.name] = definition
        tools_factory = self._make_tools_factory(definition)
        spawner = Spawner(
            llm_factory=self._make_llm_factory(),
            tools_factory=tools_factory,
            memory=self._memory,
        )
        self._supervisors[definition.name] = Supervisor(
            definition=definition,
            bus=self._bus,
            llm_factory=self._make_llm_factory(),
            tools_factory=tools_factory,
            memory=self._memory,
            spawner=spawner,
        )
        self._bus.register(definition.name)
        logger.debug("Registered agent '%s'", definition.name)

    @asynccontextmanager
    async def run(self) -> AsyncIterator[None]:
        """Start all registered agents. Use as: async with runtime.run(): ..."""
        async with anyio.create_task_group() as tg:
            for name, supervisor in self._supervisors.items():
                tg.start_soon(self._run_supervisor, name, supervisor)
            try:
                yield
            finally:
                tg.cancel_scope.cancel()

    async def _run_supervisor(self, name: str, supervisor: Supervisor) -> None:
        try:
            await supervisor.run()
        except Exception as exc:
            logger.error("Agent '%s' terminated: %s", name, exc)

    async def send(self, to: str, payload: Any, type: MessageType = MessageType.TASK) -> None:
        """Send a message from the runtime (external caller) to a registered agent."""
        if to not in self._definitions:
            raise MosesaicAgentNotFound(
                f"Agent '{to}' is not registered. Call runtime.register() first.",
                agent_name=to,
            )
        msg = AgentMessage(
            from_agent="__runtime__",
            to_agent=to,
            type=type,
            payload=payload,
        )
        await self._bus.send(msg)

    def event_log(self) -> list[AgentMessage]:
        """Return all messages ever sent through this runtime's bus."""
        return self._bus.event_log()

    def total_cost_usd(self) -> float:
        """Return total spend across all agents in this runtime."""
        total = 0.0
        for supervisor in self._supervisors.values():
            if supervisor._cost_tracker is not None:
                total += supervisor._cost_tracker.spent_usd
        return total

    # ── Lifecycle controls ────────────────────────────────────────────────────

    def _lifecycle(self, agent_name: str):
        if agent_name not in self._supervisors:
            raise MosesaicAgentNotFound(
                f"Agent '{agent_name}' is not registered.", agent_name=agent_name
            )
        return self._supervisors[agent_name].lifecycle

    def pause(self, agent_name: str) -> None:
        """Pause an agent at its next ctx.checkpoint() call."""
        self._lifecycle(agent_name).pause()

    def resume(self, agent_name: str) -> None:
        """Resume a paused agent."""
        self._lifecycle(agent_name).resume()

    def stop(self, agent_name: str) -> None:
        """Stop an agent — cancel its current execution scope."""
        self._lifecycle(agent_name).stop()

    async def send_external(self, to: str, payload: Any, type: MessageType = MessageType.TASK) -> None:
        """Queue a message before the runtime starts (for run_until_complete)."""
        msg = AgentMessage(
            from_agent="__runtime__",
            to_agent=to,
            type=type,
            payload=payload,
        )
        # Register the inbox so the message isn't lost before agents start
        self._bus.register(to)
        await self._bus.send(msg)

    async def run_until_complete(self, timeout: float | None = None) -> None:
        """Silent mode — start all agents and wait until every one exits naturally.

        Unlike ``run()``, this does not cancel agents when the block exits.
        Instead it waits for all agents to return (or raises on timeout).

        Args:
            timeout: Maximum seconds to wait. None = wait forever.
        """
        with anyio.fail_after(timeout) if timeout is not None else anyio.CancelScope() as scope:
            async with anyio.create_task_group() as tg:
                for name, supervisor in self._supervisors.items():
                    tg.start_soon(self._run_supervisor, name, supervisor)
