from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any

import anyio

from mosesaic.core.bus import MessageBus
from mosesaic.core.context import AgentContext
from mosesaic.core.cost import CostTracker
from mosesaic.core.lifecycle import AgentLifecycle
from mosesaic.exceptions import MosesaicBudgetExceeded, MosesaicMaxRestartsExceeded

if TYPE_CHECKING:
    from mosesaic.core.agent import AgentDefinition

logger = logging.getLogger(__name__)


class Supervisor:
    """Runs an agent under a restart and budget policy.

    The Supervisor:
    1. Creates an AgentContext for the agent
    2. Runs the agent's async function
    3. On failure, checks restart policy and retries or escalates
    4. MosesaicBudgetExceeded is always terminal (never retried)

    Usage:
        supervisor = Supervisor(definition=my_agent_def, bus=bus)
        await supervisor.run()  # runs until agent exits cleanly or policy exhausted
    """

    def __init__(
        self,
        definition: AgentDefinition,
        bus: MessageBus,
        llm_factory: Any | None = None,
        tools_factory: Any | None = None,
        memory: Any | None = None,
        spawner: Any | None = None,
    ) -> None:
        self._definition = definition
        self._bus = bus
        self._llm_factory = llm_factory    # callable(agent_name, cost_tracker, system_prompt) → LLMContext
        self._tools_factory = tools_factory  # callable(agent_name) → ToolContext
        self._memory = memory              # MemoryContext shared across all agents
        self._spawner = spawner            # Spawner for ctx.spawn() / ctx.pool()
        self._cost_tracker: CostTracker | None = None  # set on first run(), exposed for runtime
        self.lifecycle: AgentLifecycle = AgentLifecycle()  # exposed for AgentRuntime controls

    async def run(self) -> None:
        policy = self._definition.supervisor_policy
        cost_tracker = CostTracker(
            budget_usd=policy.budget_usd,
            agent_name=self._definition.name,
        )
        self._cost_tracker = cost_tracker  # exposed for AgentRuntime.total_cost_usd()
        llm = (
            self._llm_factory(self._definition.name, cost_tracker, self._definition.system_prompt)
            if self._llm_factory is not None
            else None
        )
        tools = (
            self._tools_factory(self._definition.name)
            if self._tools_factory is not None
            else None
        )
        ctx = AgentContext(
            agent_name=self._definition.name,
            bus=self._bus,
            cost_tracker=cost_tracker,
            lifecycle=self.lifecycle,
            llm=llm,
            tools=tools,
            memory=self._memory,
            spawner=self._spawner,
        )

        restarts: list[float] = []
        attempt = 0

        while True:
            attempt += 1
            try:
                with anyio.CancelScope() as scope:
                    self.lifecycle.attach_cancel_scope(scope)
                    await self._definition.fn(ctx)
                if scope.cancelled_caught:
                    return  # stopped externally — clean exit
                return  # natural exit

            except MosesaicBudgetExceeded:
                # Budget exceeded is always terminal — never restart
                logger.error(
                    "Agent '%s' exceeded budget after %d attempt(s). Stopping.",
                    self._definition.name,
                    attempt,
                )
                raise

            except Exception as exc:
                now = time.monotonic()
                # Purge restarts outside the window
                restarts = [t for t in restarts if now - t < policy.restart_window_seconds]
                restarts.append(now)

                if len(restarts) > policy.max_restarts:
                    raise MosesaicMaxRestartsExceeded(
                        message=(
                            f"Agent '{self._definition.name}' exceeded max_restarts="
                            f"{policy.max_restarts} within {policy.restart_window_seconds}s. "
                            f"Last error: {exc}"
                        ),
                        agent_name=self._definition.name,
                    ) from exc

                if policy.on_failure == "stop":
                    raise MosesaicMaxRestartsExceeded(
                        message=f"Agent '{self._definition.name}' failed and policy=stop. Error: {exc}",
                        agent_name=self._definition.name,
                    ) from exc

                logger.warning(
                    "Agent '%s' failed (attempt %d/%d): %s. Restarting.",
                    self._definition.name,
                    attempt,
                    policy.max_restarts + 1,
                    exc,
                )
