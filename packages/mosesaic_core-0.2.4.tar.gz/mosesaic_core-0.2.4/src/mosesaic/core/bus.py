from __future__ import annotations

from anyio.streams.memory import MemoryObjectReceiveStream, MemoryObjectSendStream

import anyio

from mosesaic.core.message import AgentMessage

# Default inbox buffer — how many messages can queue before send() blocks
_INBOX_CAPACITY = 100


class MessageBus:
    """Routes typed immutable messages between agents.

    Each agent gets its own inbox (MemoryObjectStream pair).
    All messages are written to the event log before delivery.

    Usage:
        bus = MessageBus()
        bus.register("my-agent")
        await bus.send(AgentMessage(...))
        msg = await bus.receive("my-agent")
    """

    def __init__(self, inbox_capacity: int = _INBOX_CAPACITY) -> None:
        self._inbox_capacity = inbox_capacity
        self._senders: dict[str, MemoryObjectSendStream[AgentMessage]] = {}
        self._receivers: dict[str, MemoryObjectReceiveStream[AgentMessage]] = {}
        self._event_log: list[AgentMessage] = []

    def register(self, agent_name: str) -> None:
        """Create an inbox for an agent. Idempotent."""
        if agent_name not in self._senders:
            send, recv = anyio.create_memory_object_stream[AgentMessage](
                max_buffer_size=self._inbox_capacity,
            )
            self._senders[agent_name] = send
            self._receivers[agent_name] = recv

    async def send(self, message: AgentMessage) -> None:
        """Deliver a message to the recipient's inbox. Registers inbox if needed.

        Writes to event log BEFORE delivery — log is authoritative even if
        delivery fails.
        """
        self._event_log.append(message)
        self.register(message.to_agent)
        await self._senders[message.to_agent].send(message)

    async def receive(self, agent_name: str) -> AgentMessage:
        """Wait for the next message in an agent's inbox."""
        self.register(agent_name)
        return await self._receivers[agent_name].receive()

    async def broadcast(self, message: AgentMessage) -> None:
        """Send a copy of message to every registered agent's inbox."""
        self._event_log.append(message)
        for agent_name, sender in self._senders.items():
            copy = AgentMessage(
                from_agent=message.from_agent,
                to_agent=agent_name,
                type=message.type,
                payload=message.payload,
                trace_id=message.trace_id,
                parent_message_id=message.parent_message_id,
            )
            await sender.send(copy)

    def event_log(self) -> list[AgentMessage]:
        """Return a snapshot of all messages ever sent through this bus."""
        return list(self._event_log)
