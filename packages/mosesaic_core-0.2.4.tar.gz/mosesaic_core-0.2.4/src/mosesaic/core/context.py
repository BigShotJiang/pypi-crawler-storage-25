from __future__ import annotations

from typing import TYPE_CHECKING, Any
from uuid import UUID, uuid4

from mosesaic.core.bus import MessageBus
from mosesaic.core.cost import CostTracker
from mosesaic.core.message import AgentMessage, MessageType

if TYPE_CHECKING:
    from mosesaic.core.lifecycle import AgentLifecycle
    from typing import Protocol

    class _LLMContext(Protocol):
        async def chat(self, messages: Any, **kwargs: Any) -> Any: ...


class AgentContext:
    """The interface agents use to interact with the Mosesaic runtime.

    Agents receive a context at startup. They use it to send/receive messages,
    check their budget, and access shared state. They never import from
    mosesaic.core directly — only through this interface.

    Args:
        agent_name: The name this agent is registered under.
        bus: The shared MessageBus for this runtime.
        cost_tracker: This agent's budget tracker.
        lifecycle: Pause/resume/stop controller injected by Supervisor.
        trace_id: Optional trace ID to attach to outgoing messages.
    """

    def __init__(
        self,
        agent_name: str,
        bus: MessageBus,
        cost_tracker: CostTracker,
        lifecycle: AgentLifecycle | None = None,
        llm: Any | None = None,
        tools: Any | None = None,
        memory: Any | None = None,
        trace_id: UUID | None = None,
        spawner: Any | None = None,
    ) -> None:
        self._agent_name = agent_name
        self._bus = bus
        self._cost_tracker = cost_tracker
        self._lifecycle = lifecycle
        self._llm = llm
        self._tools = tools
        self._memory = memory
        self._trace_id = trace_id or uuid4()
        self._spawner = spawner

    @property
    def name(self) -> str:
        return self._agent_name

    @property
    def trace_id(self) -> UUID:
        return self._trace_id

    @property
    def cost(self) -> CostTracker:
        """Access cost tracker — check remaining budget or record spend."""
        return self._cost_tracker

    @property
    def tools(self) -> Any:
        """Access the tool interface — call ctx.tools.call(name, **kwargs).

        Raises RuntimeError if no tool registry was provided to the runtime.
        """
        if self._tools is None:
            raise RuntimeError(
                "No tool registry registered. Pass a ToolRegistry to AgentRuntime."
            )
        return self._tools

    @property
    def memory(self) -> Any:
        """Access the three-tier memory interface — short, working, long.

        Raises RuntimeError if no memory was provided to the runtime.
        """
        if self._memory is None:
            raise RuntimeError(
                "No memory registered. Pass a MemoryContext to AgentRuntime."
            )
        return self._memory

    @property
    def llm(self) -> Any:
        """Access the LLM interface — call ctx.llm.chat(...) to invoke a model.

        Raises RuntimeError if no LLM registry was provided to the runtime.
        """
        if self._llm is None:
            raise RuntimeError(
                "No LLM provider registered. Pass a ProviderRegistry to AgentRuntime."
            )
        return self._llm

    async def send(
        self,
        to: str,
        payload: Any,
        type: MessageType = MessageType.TASK,
        parent_message_id: UUID | None = None,
    ) -> None:
        """Send a message to another agent."""
        msg = AgentMessage(
            from_agent=self._agent_name,
            to_agent=to,
            type=type,
            payload=payload,
            trace_id=self._trace_id,
            parent_message_id=parent_message_id,
        )
        await self._bus.send(msg)

    async def receive(self) -> AgentMessage:
        """Wait for the next message in this agent's inbox."""
        return await self._bus.receive(self._agent_name)

    async def reply(self, original: AgentMessage, payload: Any) -> None:
        """Send a RESULT reply to the sender of original."""
        await self._bus.send(original.reply(payload=payload))

    async def checkpoint(self) -> None:
        """Yield control to the runtime — blocks here if the agent is paused.

        Call this between meaningful units of work. The more frequently you
        call it, the more responsive pause/stop will be. It is a no-op when
        no lifecycle is attached (e.g. in unit tests).
        """
        if self._lifecycle is not None:
            await self._lifecycle.checkpoint()

    async def spawn(self, definition: Any, payload: Any, *, timeout: float = 120.0) -> Any:
        """Spawn a child agent in isolation and return its output.

        The child runs in its own MessageBus. Its output is the last message
        it sent before returning.

        Raises:
            RuntimeError: If no spawner was configured for this runtime.
            TimeoutError: If the child does not finish within timeout seconds.
        """
        if self._spawner is None:
            raise RuntimeError(
                "No spawner configured. AgentRuntime injects one automatically "
                "when you register agents — ensure you are using AgentRuntime."
            )
        from mosesaic.core.progress import emit_progress, ProgressEvent
        emit_progress(ProgressEvent(
            type="spawn_start",
            agent=definition.name,
            parent=self._agent_name,
        ))
        result = await self._spawner.spawn(definition, payload, timeout=timeout)
        emit_progress(ProgressEvent(
            type="spawn_done",
            agent=definition.name,
            parent=self._agent_name,
        ))
        return result

    async def pool(
        self,
        definition: Any,
        items: list[Any],
        *,
        concurrency: int = 4,
        timeout: float = 120.0,
    ) -> list[Any]:
        """Spawn one child per item with bounded concurrency; collect results in order.

        Raises:
            RuntimeError: If no spawner was configured for this runtime.
        """
        if self._spawner is None:
            raise RuntimeError(
                "No spawner configured. AgentRuntime injects one automatically "
                "when you register agents — ensure you are using AgentRuntime."
            )
        return await self._spawner.pool(
            definition, items, concurrency=concurrency, timeout=timeout
        )
