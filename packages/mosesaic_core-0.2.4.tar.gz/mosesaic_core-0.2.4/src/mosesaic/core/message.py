from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import UUID, uuid4


class MessageType(str, Enum):
    TASK = "task"
    RESULT = "result"
    ERROR = "error"
    BROADCAST = "broadcast"
    BUDGET_EXCEEDED = "budget_exceeded"


@dataclass(frozen=True)
class AgentMessage:
    """Immutable message passed between agents via the MessageBus.

    Never instantiate with explicit id/trace_id/timestamp — let the defaults generate them.
    Use .reply() to create response messages that preserve the causal chain.
    """

    from_agent: str
    to_agent: str
    type: MessageType
    payload: Any
    id: UUID = field(default_factory=uuid4)
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    trace_id: UUID = field(default_factory=uuid4)
    parent_message_id: UUID | None = None

    def reply(self, payload: Any, type: MessageType = MessageType.RESULT) -> AgentMessage:
        """Create a reply that preserves trace_id and sets parent_message_id."""
        return AgentMessage(
            from_agent=self.to_agent,
            to_agent=self.from_agent,
            type=type,
            payload=payload,
            trace_id=self.trace_id,
            parent_message_id=self.id,
        )
