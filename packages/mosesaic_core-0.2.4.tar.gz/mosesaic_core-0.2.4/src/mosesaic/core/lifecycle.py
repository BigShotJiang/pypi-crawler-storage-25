from __future__ import annotations

import anyio


class AgentLifecycle:
    """Controls pause/resume/stop for a single agent.

    Agents call ``await lifecycle.checkpoint()`` at natural suspension points
    (between meaningful units of work). The lifecycle blocks the coroutine
    while paused, and cancels it when stopped.

    Usage (internal — wired by Supervisor):
        lifecycle = AgentLifecycle()
        with anyio.CancelScope() as scope:
            lifecycle.attach_cancel_scope(scope)
            await agent_fn(ctx)  # ctx.checkpoint() delegates here

    External control (via AgentRuntime):
        runtime.pause("my-agent")
        runtime.resume("my-agent")
        runtime.stop("my-agent")
    """

    def __init__(self) -> None:
        # _run_event: set = running, unset = paused.
        # We replace it on each pause() so we can re-pause after resume.
        self._run_event: anyio.Event = anyio.Event()
        self._run_event.set()
        self._stopped: bool = False
        self._cancel_scope: anyio.CancelScope | None = None

    def attach_cancel_scope(self, scope: anyio.CancelScope) -> None:
        """Attach the agent's cancel scope so stop() can cancel it."""
        self._cancel_scope = scope

    async def checkpoint(self) -> None:
        """Block here while paused. Returns immediately when running.

        Agents should call this between meaningful units of work. The more
        frequently it is called, the more responsive pause/stop will be.
        """
        if self._stopped:
            # Trigger cancellation via the attached scope
            if self._cancel_scope is not None:
                self._cancel_scope.cancel()
            # Yield so the cancellation propagates
            await anyio.sleep(0)
            return
        await self._run_event.wait()

    def pause(self) -> None:
        """Pause the agent at its next checkpoint()."""
        # Replace with a new unset event — old event may already be set
        self._run_event = anyio.Event()

    def resume(self) -> None:
        """Resume a paused agent."""
        self._stopped = False
        self._run_event.set()

    def stop(self) -> None:
        """Stop the agent — cancel its scope and unblock any waiting checkpoint."""
        self._stopped = True
        self._run_event.set()  # Unblock checkpoint() so it can see _stopped=True
        if self._cancel_scope is not None:
            self._cancel_scope.cancel()

    @property
    def is_paused(self) -> bool:
        return not self._run_event.is_set() and not self._stopped

    @property
    def is_stopped(self) -> bool:
        return self._stopped
