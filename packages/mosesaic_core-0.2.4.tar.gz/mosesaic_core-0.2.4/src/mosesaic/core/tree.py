"""SupervisorTree — a named, embeddable group of agents on a shared bus.

Use SupervisorTree when you want to bundle a fixed set of cooperating agents
under a single named unit. Agents within the tree share a bus and can message
each other by name. The tree can be started once and left running.

    tree = (
        SupervisorTree("auth-subsystem")
        .add(token_validator)
        .add(session_manager, policy=SupervisorPolicy(max_restarts=5))
    )

    async with tree.run():
        await tree.send("token-validator", payload=request)
        result = await tree.receive("session-manager")  # if needed

Compared to AgentRuntime:
  - Has a name (useful for logging, nesting, identity)
  - Fluent .add() API
  - Designed for embedding: can be composed into larger systems
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Any, AsyncIterator

from mosesaic.core.agent import AgentDefinition, SupervisorPolicy
from mosesaic.core.message import AgentMessage
from mosesaic.core.runtime import AgentRuntime


class SupervisorTree:
    """A named group of agents running on a shared bus under supervision.

    Args:
        name: Identifier for this tree — used in logs and for nesting.
        llm: ProviderRegistry for LLM access, or None.
        tools: ToolRegistry for tool access, or None.
        tool_policy: ToolPolicy to enforce, or None.
        memory: MemoryContext shared across all agents in the tree, or None.
    """

    def __init__(
        self,
        name: str,
        *,
        llm: Any | None = None,
        tools: Any | None = None,
        tool_policy: Any | None = None,
        memory: Any | None = None,
    ) -> None:
        self._name = name
        self._runtime = AgentRuntime(
            llm=llm,
            tools=tools,
            tool_policy=tool_policy,
            memory=memory,
        )

    @property
    def name(self) -> str:
        return self._name

    def add(
        self,
        definition: AgentDefinition,
        *,
        policy: SupervisorPolicy | None = None,
    ) -> "SupervisorTree":
        """Register a child agent. Fluent — returns self for chaining.

        Args:
            definition: Agent to add.
            policy: Override the agent's own SupervisorPolicy, or None to use it as-is.
        """
        if policy is not None:
            # Create a modified definition with the override policy
            definition = AgentDefinition(
                name=definition.name,
                fn=definition.fn,
                supervisor_policy=policy,
                tools=definition.tools,
            )
        self._runtime.register(definition)
        return self

    @asynccontextmanager
    async def run(self) -> AsyncIterator[None]:
        """Start all registered agents. Yields while they run; cancels on exit."""
        async with self._runtime.run():
            yield

    async def send(self, to: str, payload: Any) -> None:
        """Send an external message into the tree."""
        await self._runtime.send(to, payload)

    def event_log(self) -> list[AgentMessage]:
        """All messages sent through this tree's bus."""
        return self._runtime.event_log()

    def total_cost_usd(self) -> float:
        """Total LLM spend across all agents in this tree."""
        return self._runtime.total_cost_usd()
