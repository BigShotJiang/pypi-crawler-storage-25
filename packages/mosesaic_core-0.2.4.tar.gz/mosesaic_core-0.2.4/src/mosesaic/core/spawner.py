"""Spawner — dynamic agent spawning from within an agent context.

Each call to spawn() creates a fully isolated mini-runtime (fresh MessageBus,
fresh AgentContext) so the child cannot interfere with the caller's bus.
The child's output is the last message it sent before returning.

pool() runs multiple spawn() calls concurrently with bounded concurrency,
collecting results in order.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

import anyio

if TYPE_CHECKING:
    from mosesaic.core.agent import AgentDefinition


class Spawner:
    """Enables an agent to dynamically spawn child agents in isolation.

    Injected into AgentContext by AgentRuntime and SupervisorTree.
    Each spawned child gets its own bus and a new Spawner so it can
    itself spawn grandchildren (unlimited nesting).

    Args:
        llm_factory: Callable(agent_name, cost_tracker, system_prompt) → LLMContext, or None.
        tools_factory: Callable(agent_name) → ToolContext, or None.
        memory: MemoryContext shared across all agents, or None.
    """

    def __init__(
        self,
        llm_factory: Any | None = None,
        tools_factory: Any | None = None,
        memory: Any | None = None,
    ) -> None:
        self._llm_factory = llm_factory
        self._tools_factory = tools_factory
        self._memory = memory

    async def spawn(
        self,
        definition: AgentDefinition,
        payload: Any,
        *,
        timeout: float = 120.0,
    ) -> Any:
        """Run definition with payload in isolation; return its output.

        The child runs in its own MessageBus. Its output is the last message
        it sent (via ctx.send) before returning. Returns None if it sent nothing.

        Raises:
            TimeoutError: If the child does not complete within timeout seconds.
            Any exception raised by the child propagates to the caller.
        """
        from mosesaic.core.bus import MessageBus
        from mosesaic.core.context import AgentContext
        from mosesaic.core.cost import CostTracker
        from mosesaic.core.lifecycle import AgentLifecycle
        from mosesaic.core.message import AgentMessage, MessageType

        bus = MessageBus()
        bus.register(definition.name)

        await bus.send(
            AgentMessage(
                from_agent="__spawner__",
                to_agent=definition.name,
                type=MessageType.TASK,
                payload=payload,
            )
        )

        cost_tracker = CostTracker(agent_name=definition.name)
        lifecycle = AgentLifecycle()

        llm = (
            self._llm_factory(definition.name, cost_tracker, definition.system_prompt)
            if self._llm_factory is not None
            else None
        )
        tools = (
            self._tools_factory(definition.name)
            if self._tools_factory is not None
            else None
        )
        # Child gets its own Spawner so it can spawn grandchildren
        child_spawner = Spawner(
            llm_factory=self._llm_factory,
            tools_factory=self._tools_factory,
            memory=self._memory,
        )

        ctx = AgentContext(
            agent_name=definition.name,
            bus=bus,
            cost_tracker=cost_tracker,
            lifecycle=lifecycle,
            llm=llm,
            tools=tools,
            memory=self._memory,
            spawner=child_spawner,
        )

        with anyio.fail_after(timeout):
            await definition.fn(ctx)

        sent = [m for m in bus.event_log() if m.from_agent == definition.name]
        return sent[-1].payload if sent else None

    async def pool(
        self,
        definition: AgentDefinition,
        items: list[Any],
        *,
        concurrency: int = 4,
        timeout: float = 120.0,
    ) -> list[Any]:
        """Spawn one child per item with bounded concurrency; collect results in order.

        Args:
            definition: Agent to spawn for each item.
            items: List of payloads — one per child.
            concurrency: Maximum simultaneous children (semaphore).
            timeout: Per-child timeout in seconds.

        Returns:
            Results in the same order as items.
        """
        results: list[Any] = [None] * len(items)
        semaphore = anyio.Semaphore(concurrency)

        async def run_one(idx: int, item: Any) -> None:
            async with semaphore:
                results[idx] = await self.spawn(definition, item, timeout=timeout)

        async with anyio.create_task_group() as tg:
            for i, item in enumerate(items):
                tg.start_soon(run_one, i, item)

        return results
