class MosesaicError(Exception):
    """Base class for all Mosesaic errors."""

    def __init__(self, message: str, trace_id: str | None = None, agent_name: str | None = None):
        super().__init__(message)
        self.trace_id = trace_id
        self.agent_name = agent_name

    def __str__(self) -> str:
        parts = [super().__str__()]
        if self.agent_name:
            parts.append(f"  agent:    {self.agent_name}")
        if self.trace_id:
            parts.append(f"  trace_id: {self.trace_id}")
            parts.append(f"  hint:     Run `mosesaic inspect {self.trace_id}` for full context")
        return "\n".join(parts)


class MosesaicBudgetExceeded(MosesaicError):
    """Raised when an agent exceeds its configured budget_usd."""

    def __init__(
        self,
        agent_name: str,
        spent_usd: float,
        budget_usd: float,
        blocked_call: str,
        trace_id: str | None = None,
    ):
        msg = (
            f"MosesaicBudgetExceeded:\n"
            f"  agent:    {agent_name}\n"
            f"  spent:    ${spent_usd:.4f} of ${budget_usd:.2f} budget\n"
            f"  blocked:  {blocked_call}\n"
            f"  hint:     Increase budget_usd in @agent(...) or reduce task scope"
        )
        super().__init__(msg, trace_id=trace_id, agent_name=agent_name)
        self.spent_usd = spent_usd
        self.budget_usd = budget_usd


class MosesaicAgentNotFound(MosesaicError):
    """Raised when a message is sent to an unregistered agent."""


class MosesaicMaxRestartsExceeded(MosesaicError):
    """Raised when a supervised agent exceeds its restart limit."""
