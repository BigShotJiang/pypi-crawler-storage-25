import pytest

# All async tests use asyncio backend (uvloop in production, asyncio in tests)
# pytest-anyio picks this up automatically via pyproject.toml anyio_backend = "asyncio"
