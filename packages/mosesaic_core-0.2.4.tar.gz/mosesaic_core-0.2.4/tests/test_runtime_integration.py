import anyio
import pytest

from mosesaic.core.agent import SupervisorPolicy, agent
from mosesaic.core.context import AgentContext
from mosesaic.core.message import MessageType
from mosesaic.core.runtime import AgentRuntime


@pytest.mark.anyio
async def test_runtime_routes_message_between_two_agents():
    received_by_b = []

    @agent(name="agent-a")
    async def agent_a(ctx: AgentContext) -> None:
        await ctx.receive()  # wait for start signal
        await ctx.send("agent-b", payload="hello from A")

    @agent(name="agent-b")
    async def agent_b(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        received_by_b.append(msg.payload)

    runtime = AgentRuntime()
    runtime.register(agent_a)
    runtime.register(agent_b)

    async with runtime.run():
        await runtime.send("agent-a", payload="start")
        await anyio.sleep(0.1)

    assert received_by_b == ["hello from A"]


@pytest.mark.anyio
async def test_runtime_event_log_captures_all_messages():
    @agent(name="ping")
    async def ping(ctx: AgentContext) -> None:
        await ctx.receive()
        await ctx.send("pong", payload="ping")

    @agent(name="pong")
    async def pong(ctx: AgentContext) -> None:
        await ctx.receive()

    runtime = AgentRuntime()
    runtime.register(ping)
    runtime.register(pong)

    async with runtime.run():
        await runtime.send("ping", payload="start")
        await anyio.sleep(0.1)

    log = runtime.event_log()
    payloads = [m.payload for m in log]
    assert "start" in payloads
    assert "ping" in payloads


@pytest.mark.anyio
async def test_runtime_raises_on_unregistered_agent():
    runtime = AgentRuntime()
    with pytest.raises(Exception, match="not registered"):
        await runtime.send("ghost-agent", payload="hello")


@pytest.mark.anyio
async def test_runtime_total_cost_tracking():
    @agent(name="costly", supervisor=SupervisorPolicy(budget_usd=1.00))
    async def costly(ctx: AgentContext) -> None:
        from mosesaic.core.cost import AgentCostEvent
        await ctx.receive()
        ctx.cost.record(AgentCostEvent(
            agent_name="costly", model="claude-opus-4-6",
            input_tokens=100, output_tokens=50, cost_usd=0.05, trace_id="t",
        ))

    runtime = AgentRuntime()
    runtime.register(costly)

    async with runtime.run():
        await runtime.send("costly", payload="go")
        await anyio.sleep(0.1)

    assert runtime.total_cost_usd() >= 0.05
