"""Tests for agent pause/resume/stop lifecycle controls."""
import anyio
import pytest

from mosesaic.core.agent import agent
from mosesaic.core.context import AgentContext
from mosesaic.core.lifecycle import AgentLifecycle
from mosesaic.core.runtime import AgentRuntime


@pytest.mark.anyio
async def test_lifecycle_pause_blocks_checkpoint():
    """A paused agent blocks at ctx.checkpoint() until resumed."""
    reached_after_pause = []

    lifecycle = AgentLifecycle()
    lifecycle.pause()

    async def run():
        await lifecycle.checkpoint()
        reached_after_pause.append(True)

    async with anyio.create_task_group() as tg:
        tg.start_soon(run)
        await anyio.sleep(0.05)
        assert reached_after_pause == [], "Should still be blocked"
        lifecycle.resume()
        await anyio.sleep(0.05)
        tg.cancel_scope.cancel()

    assert reached_after_pause == [True]


@pytest.mark.anyio
async def test_lifecycle_stop_cancels_waiting_checkpoint():
    """stop() unblocks a checkpoint and cancels the agent's scope."""
    lifecycle = AgentLifecycle()
    lifecycle.pause()

    cancelled = []

    async def run():
        try:
            with anyio.CancelScope() as scope:
                lifecycle.attach_cancel_scope(scope)
                await lifecycle.checkpoint()
        except Exception:
            cancelled.append(True)
            raise

    async with anyio.create_task_group() as tg:
        tg.start_soon(run)
        await anyio.sleep(0.05)
        lifecycle.stop()
        await anyio.sleep(0.05)
        tg.cancel_scope.cancel()


@pytest.mark.anyio
async def test_runtime_pause_and_resume_agent():
    """Runtime can pause and resume a running agent."""
    checkpoints_hit = []

    @agent(name="worker")
    async def worker(ctx: AgentContext) -> None:
        await ctx.receive()
        for i in range(3):
            await ctx.checkpoint()
            checkpoints_hit.append(i)

    runtime = AgentRuntime()
    runtime.register(worker)

    async with runtime.run():
        await runtime.send("worker", payload="start")
        await anyio.sleep(0.05)
        runtime.pause("worker")
        count_at_pause = len(checkpoints_hit)
        await anyio.sleep(0.05)
        assert len(checkpoints_hit) == count_at_pause, "No new checkpoints while paused"
        runtime.resume("worker")
        await anyio.sleep(0.1)

    assert len(checkpoints_hit) == 3


@pytest.mark.anyio
async def test_runtime_stop_agent():
    """Runtime can stop an individual agent without stopping the runtime."""
    agent_b_ran = []

    @agent(name="stoppable")
    async def stoppable(ctx: AgentContext) -> None:
        await ctx.receive()
        await ctx.checkpoint()
        await ctx.checkpoint()

    @agent(name="observer")
    async def observer(ctx: AgentContext) -> None:
        await ctx.receive()
        agent_b_ran.append(True)

    runtime = AgentRuntime()
    runtime.register(stoppable)
    runtime.register(observer)

    async with runtime.run():
        await runtime.send("stoppable", payload="go")
        await runtime.send("observer", payload="go")
        await anyio.sleep(0.05)
        runtime.stop("stoppable")
        await anyio.sleep(0.1)

    assert agent_b_ran == [True], "Observer should still have run"


@pytest.mark.anyio
async def test_runtime_run_until_complete():
    """run_until_complete() runs all agents to natural exit — silent mode."""
    results = []

    @agent(name="task-a")
    async def task_a(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        results.append(f"a:{msg.payload}")

    @agent(name="task-b")
    async def task_b(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        results.append(f"b:{msg.payload}")

    runtime = AgentRuntime()
    runtime.register(task_a)
    runtime.register(task_b)

    await runtime.send_external("task-a", payload="done")
    await runtime.send_external("task-b", payload="done")

    await runtime.run_until_complete(timeout=2.0)

    assert "a:done" in results
    assert "b:done" in results
