import pytest
from mosesaic.core.agent import agent
from mosesaic.core.runtime import AgentRuntime
from mosesaic.core.context import AgentContext


@pytest.mark.anyio
async def test_agent_tool_list_enforced():
    """An agent with tools=['allowed_tool'] cannot call 'other_tool'."""
    from mosesaic.tools.registry import ToolRegistry
    from mosesaic.tools.tool import tool

    @tool(name="allowed_tool")
    def allowed_tool() -> str:
        return "ok"

    @tool(name="other_tool")
    def other_tool() -> str:
        return "forbidden"

    registry = ToolRegistry()
    registry.register(allowed_tool)
    registry.register(other_tool)

    results = {}

    @agent(name="restricted", tools=["allowed_tool"])
    async def restricted_agent(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        results["allowed"] = await ctx.tools.call("allowed_tool")
        results["denied"] = await ctx.tools.call("other_tool")

    runtime = AgentRuntime(tools=registry)
    runtime.register(restricted_agent)
    async with runtime.run():
        await runtime.send("restricted", payload="go")
        import anyio
        await anyio.sleep(0.1)

    assert results["allowed"].success is True
    assert results["denied"].success is False
    assert "denied" in results["denied"].error.lower() or "policy" in results["denied"].error.lower()


@pytest.mark.anyio
async def test_agent_empty_tool_list_allows_all():
    """An agent with tools=[] (default) can call any registered tool."""
    from mosesaic.tools.registry import ToolRegistry
    from mosesaic.tools.tool import tool

    @tool(name="any_tool")
    def any_tool() -> str:
        return "yes"

    registry = ToolRegistry()
    registry.register(any_tool)

    results = {}

    @agent(name="unrestricted")  # tools=[] by default
    async def unrestricted_agent(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        results["result"] = await ctx.tools.call("any_tool")

    runtime = AgentRuntime(tools=registry)
    runtime.register(unrestricted_agent)
    async with runtime.run():
        await runtime.send("unrestricted", payload="go")
        import anyio
        await anyio.sleep(0.1)

    assert results["result"].success is True
