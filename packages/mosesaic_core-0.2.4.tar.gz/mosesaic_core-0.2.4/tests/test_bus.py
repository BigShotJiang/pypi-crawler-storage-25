import anyio
import pytest

from mosesaic.core.bus import MessageBus
from mosesaic.core.message import AgentMessage, MessageType


@pytest.mark.anyio
async def test_send_and_receive():
    bus = MessageBus()
    msg = AgentMessage(from_agent="A", to_agent="B", type=MessageType.TASK, payload="hello")

    await bus.send(msg)
    received = await bus.receive("B")

    assert received.id == msg.id
    assert received.payload == "hello"


@pytest.mark.anyio
async def test_messages_routed_to_correct_recipient():
    bus = MessageBus()
    msg_b = AgentMessage(from_agent="A", to_agent="B", type=MessageType.TASK, payload="for B")
    msg_c = AgentMessage(from_agent="A", to_agent="C", type=MessageType.TASK, payload="for C")

    await bus.send(msg_b)
    await bus.send(msg_c)

    received_c = await bus.receive("C")
    received_b = await bus.receive("B")

    assert received_b.payload == "for B"
    assert received_c.payload == "for C"


@pytest.mark.anyio
async def test_broadcast_received_by_all_registered():
    bus = MessageBus()
    bus.register("X")
    bus.register("Y")

    broadcast = AgentMessage(
        from_agent="orchestrator",
        to_agent="__broadcast__",
        type=MessageType.BROADCAST,
        payload="shutdown",
    )
    await bus.broadcast(broadcast)

    x_msg = await bus.receive("X")
    y_msg = await bus.receive("Y")

    assert x_msg.payload == "shutdown"
    assert y_msg.payload == "shutdown"


@pytest.mark.anyio
async def test_event_log_records_all_messages():
    bus = MessageBus()
    msg = AgentMessage(from_agent="A", to_agent="B", type=MessageType.TASK, payload=42)

    await bus.send(msg)

    log = bus.event_log()
    assert len(log) == 1
    assert log[0].id == msg.id


@pytest.mark.anyio
async def test_receive_timeout_raises():
    bus = MessageBus()
    with pytest.raises(TimeoutError):
        with anyio.fail_after(0.05):
            await bus.receive("nobody")
