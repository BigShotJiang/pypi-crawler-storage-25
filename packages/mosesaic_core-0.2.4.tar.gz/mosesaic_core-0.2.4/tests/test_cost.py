import pytest

from mosesaic.core.cost import AgentCostEvent, CostTracker
from mosesaic.exceptions import MosesaicBudgetExceeded


def test_cost_event_creation():
    event = AgentCostEvent(
        agent_name="researcher",
        model="claude-opus-4-6",
        input_tokens=1240,
        output_tokens=380,
        cost_usd=0.0157,
        trace_id="abc-123",
    )
    assert event.agent_name == "researcher"
    assert event.cost_usd == 0.0157


def test_tracker_accumulates_spend():
    tracker = CostTracker(budget_usd=1.00)
    tracker.record(AgentCostEvent(
        agent_name="A", model="claude-haiku-4-5",
        input_tokens=100, output_tokens=50, cost_usd=0.01, trace_id="t1",
    ))
    tracker.record(AgentCostEvent(
        agent_name="A", model="claude-haiku-4-5",
        input_tokens=100, output_tokens=50, cost_usd=0.02, trace_id="t1",
    ))
    assert abs(tracker.spent_usd - 0.03) < 1e-9
    assert abs(tracker.remaining_usd - 0.97) < 1e-9


def test_tracker_raises_on_budget_exceeded():
    tracker = CostTracker(budget_usd=0.05, agent_name="researcher")
    tracker.record(AgentCostEvent(
        agent_name="researcher", model="claude-opus-4-6",
        input_tokens=500, output_tokens=200, cost_usd=0.04, trace_id="t1",
    ))
    with pytest.raises(MosesaicBudgetExceeded) as exc_info:
        tracker.check_before_call(estimated_cost_usd=0.02, call_description="llm.chat(claude-opus-4-6)")
    assert exc_info.value.spent_usd == pytest.approx(0.04)
    assert exc_info.value.budget_usd == 0.05


def test_tracker_allows_call_within_budget():
    tracker = CostTracker(budget_usd=1.00, agent_name="researcher")
    # Should not raise
    tracker.check_before_call(estimated_cost_usd=0.50, call_description="llm.chat")


def test_tracker_no_budget_never_raises():
    tracker = CostTracker(budget_usd=None)
    tracker.record(AgentCostEvent(
        agent_name="A", model="x", input_tokens=9999999,
        output_tokens=9999999, cost_usd=9999.0, trace_id="t",
    ))
    tracker.check_before_call(estimated_cost_usd=9999.0, call_description="anything")


def test_tracker_events_by_agent():
    tracker = CostTracker()
    tracker.record(AgentCostEvent(
        agent_name="A", model="m", input_tokens=1, output_tokens=1, cost_usd=0.01, trace_id="t",
    ))
    tracker.record(AgentCostEvent(
        agent_name="B", model="m", input_tokens=1, output_tokens=1, cost_usd=0.02, trace_id="t",
    ))
    assert tracker.spent_by_agent("A") == pytest.approx(0.01)
    assert tracker.spent_by_agent("B") == pytest.approx(0.02)
    assert tracker.spent_by_agent("C") == 0.0
