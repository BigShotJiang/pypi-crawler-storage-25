from dataclasses import FrozenInstanceError
from datetime import datetime
from uuid import UUID

import pytest

from mosesaic.core.message import AgentMessage, MessageType


def test_message_creation_sets_defaults():
    msg = AgentMessage(
        from_agent="sender",
        to_agent="receiver",
        type=MessageType.TASK,
        payload="hello",
    )
    assert msg.from_agent == "sender"
    assert msg.to_agent == "receiver"
    assert msg.type == MessageType.TASK
    assert msg.payload == "hello"
    assert isinstance(msg.id, UUID)
    assert isinstance(msg.trace_id, UUID)
    assert isinstance(msg.timestamp, datetime)
    assert msg.parent_message_id is None


def test_message_is_immutable():
    msg = AgentMessage(from_agent="a", to_agent="b", type=MessageType.TASK, payload=1)
    with pytest.raises(FrozenInstanceError):
        msg.payload = 2  # frozen=True must raise


def test_reply_swaps_agents_and_inherits_trace():
    original = AgentMessage(
        from_agent="A", to_agent="B", type=MessageType.TASK, payload="do work"
    )
    reply = original.reply(payload="done")
    assert reply.from_agent == "B"
    assert reply.to_agent == "A"
    assert reply.type == MessageType.RESULT
    assert reply.trace_id == original.trace_id
    assert reply.parent_message_id == original.id
    assert reply.payload == "done"


def test_reply_error():
    original = AgentMessage(
        from_agent="A", to_agent="B", type=MessageType.TASK, payload="do work"
    )
    err = original.reply(payload="boom", type=MessageType.ERROR)
    assert err.type == MessageType.ERROR
    assert err.from_agent == "B"


def test_message_types_are_strings():
    # MessageType values must be plain strings so they serialize to JSON cleanly
    assert MessageType.TASK == "task"
    assert MessageType.RESULT == "result"
    assert MessageType.ERROR == "error"
    assert MessageType.BROADCAST == "broadcast"
    assert MessageType.BUDGET_EXCEEDED == "budget_exceeded"


def test_unique_ids_per_message():
    m1 = AgentMessage(from_agent="a", to_agent="b", type=MessageType.TASK, payload=1)
    m2 = AgentMessage(from_agent="a", to_agent="b", type=MessageType.TASK, payload=1)
    assert m1.id != m2.id
    assert m1.trace_id != m2.trace_id
