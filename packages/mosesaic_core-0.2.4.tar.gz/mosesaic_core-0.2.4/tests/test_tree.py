"""Tests for SupervisorTree — named group supervisor."""

import pytest
import anyio

from mosesaic.core.agent import agent, SupervisorPolicy
from mosesaic.core.context import AgentContext
from mosesaic.core.tree import SupervisorTree
from mosesaic.exceptions import MosesaicMaxRestartsExceeded


# ── Helpers ───────────────────────────────────────────────────────────────────


@agent(name="echo")
async def echo_agent(ctx: AgentContext) -> None:
    msg = await ctx.receive()
    await ctx.send("__out__", msg.payload)


@agent(name="upper")
async def upper_agent(ctx: AgentContext) -> None:
    msg = await ctx.receive()
    await ctx.send("__out__", str(msg.payload).upper())


@agent(name="relay")
async def relay_agent(ctx: AgentContext) -> None:
    """Receives a message and forwards it to 'upper'."""
    msg = await ctx.receive()
    await ctx.send("upper", msg.payload)


# ── Basic tree behaviour ──────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_tree_has_name():
    tree = SupervisorTree("my-tree")
    assert tree.name == "my-tree"


@pytest.mark.anyio
async def test_tree_add_is_fluent():
    tree = SupervisorTree("t").add(echo_agent).add(upper_agent)
    assert tree is not None  # fluent chain returned same tree


@pytest.mark.anyio
async def test_tree_routes_message_to_agent():
    received = []

    @agent(name="recorder")
    async def recorder(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        received.append(msg.payload)

    tree = SupervisorTree("test-tree").add(recorder)

    async with tree.run():
        await tree.send("recorder", "hello-tree")
        await anyio.sleep(0.05)

    assert received == ["hello-tree"]


@pytest.mark.anyio
async def test_tree_agents_communicate_via_shared_bus():
    """relay → upper on the shared bus."""
    upper_received = []

    @agent(name="upper-spy")
    async def upper_spy(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        upper_received.append(str(msg.payload).upper())

    @agent(name="relay-to-upper-spy")
    async def relay_to_upper_spy(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        await ctx.send("upper-spy", msg.payload)

    tree = (
        SupervisorTree("comm-tree")
        .add(relay_to_upper_spy)
        .add(upper_spy)
    )

    async with tree.run():
        await tree.send("relay-to-upper-spy", "world")
        await anyio.sleep(0.1)

    assert upper_received == ["WORLD"]


@pytest.mark.anyio
async def test_tree_event_log_captures_messages():
    tree = SupervisorTree("log-tree").add(echo_agent)

    async with tree.run():
        await tree.send("echo", "captured")
        await anyio.sleep(0.05)

    log = tree.event_log()
    payloads = [m.payload for m in log]
    assert "captured" in payloads


@pytest.mark.anyio
async def test_tree_total_cost_starts_at_zero():
    tree = SupervisorTree("cost-tree").add(echo_agent)
    async with tree.run():
        await tree.send("echo", "x")
        await anyio.sleep(0.05)
    assert tree.total_cost_usd() == 0.0


# ── Policy override ───────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_tree_add_overrides_policy():
    """add(policy=...) should replace the agent's own policy."""
    call_count = 0

    @agent(name="flaky-tree-agent", supervisor=SupervisorPolicy(max_restarts=0, on_failure="stop"))
    async def flaky(ctx: AgentContext) -> None:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            raise RuntimeError("first run fails")
        await ctx.receive()

    # Override: allow 1 restart
    tree = SupervisorTree("policy-tree").add(
        flaky, policy=SupervisorPolicy(max_restarts=1, on_failure="restart")
    )

    async with tree.run():
        await tree.send("flaky-tree-agent", "go")
        await anyio.sleep(0.2)

    assert call_count == 2  # initial run failed, one restart succeeded


# ── Restart behaviour ─────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_tree_restarts_failing_child():
    restart_count = 0

    @agent(
        name="tree-flaky",
        supervisor=SupervisorPolicy(max_restarts=2, on_failure="restart"),
    )
    async def tree_flaky(ctx: AgentContext) -> None:
        nonlocal restart_count
        restart_count += 1
        if restart_count < 3:
            raise RuntimeError("transient")
        await ctx.receive()

    tree = SupervisorTree("restart-tree").add(tree_flaky)

    async with tree.run():
        await tree.send("tree-flaky", "go")
        await anyio.sleep(0.2)

    assert restart_count == 3  # initial + 2 restarts


# ── Multiple trees ────────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_two_trees_are_independent():
    """Each tree has its own bus — messages don't bleed across."""
    received_a: list[str] = []
    received_b: list[str] = []

    @agent(name="collector-a")
    async def collector_a(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        received_a.append(msg.payload)

    @agent(name="collector-b")
    async def collector_b(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        received_b.append(msg.payload)

    tree_a = SupervisorTree("tree-A").add(collector_a)
    tree_b = SupervisorTree("tree-B").add(collector_b)

    async with tree_a.run(), tree_b.run():
        await tree_a.send("collector-a", "from-A")
        await tree_b.send("collector-b", "from-B")
        await anyio.sleep(0.1)

    assert received_a == ["from-A"]
    assert received_b == ["from-B"]
