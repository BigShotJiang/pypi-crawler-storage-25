"""Tests for Spawner — dynamic agent spawning and work pools."""

import pytest
import anyio

from mosesaic.core.agent import agent, SupervisorPolicy
from mosesaic.core.context import AgentContext
from mosesaic.core.runtime import AgentRuntime
from mosesaic.core.spawner import Spawner


# ── Helpers ───────────────────────────────────────────────────────────────────


@agent(name="double")
async def double_agent(ctx: AgentContext) -> None:
    msg = await ctx.receive()
    await ctx.send("__out__", msg.payload * 2)


@agent(name="upper")
async def upper_agent(ctx: AgentContext) -> None:
    msg = await ctx.receive()
    await ctx.send("__out__", str(msg.payload).upper())


@agent(name="always-fails")
async def always_fails_agent(ctx: AgentContext) -> None:
    await ctx.receive()
    raise ValueError("child always fails")


@agent(name="hangs-forever")
async def hangs_forever_agent(ctx: AgentContext) -> None:
    await ctx.receive()
    await anyio.sleep(9999)


@agent(name="sends-nothing")
async def sends_nothing_agent(ctx: AgentContext) -> None:
    await ctx.receive()  # receive but send nothing


# ── Spawner.spawn() ───────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_spawn_returns_child_output():
    spawner = Spawner()
    result = await spawner.spawn(double_agent, 21)
    assert result == 42


@pytest.mark.anyio
async def test_spawn_returns_none_when_child_sends_nothing():
    spawner = Spawner()
    result = await spawner.spawn(sends_nothing_agent, "anything")
    assert result is None


@pytest.mark.anyio
async def test_spawn_propagates_child_exception():
    spawner = Spawner()
    with pytest.raises(ValueError, match="child always fails"):
        await spawner.spawn(always_fails_agent, "go")


@pytest.mark.anyio
async def test_spawn_timeout_raises():
    spawner = Spawner()
    with pytest.raises(TimeoutError):
        await spawner.spawn(hangs_forever_agent, "go", timeout=0.05)


@pytest.mark.anyio
async def test_spawn_multiple_sequential():
    spawner = Spawner()
    r1 = await spawner.spawn(double_agent, 5)
    r2 = await spawner.spawn(upper_agent, "hello")
    assert r1 == 10
    assert r2 == "HELLO"


# ── Spawner.pool() ────────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_pool_results_in_order():
    spawner = Spawner()
    results = await spawner.pool(double_agent, [1, 2, 3, 4, 5])
    assert results == [2, 4, 6, 8, 10]


@pytest.mark.anyio
async def test_pool_empty_list_returns_empty():
    spawner = Spawner()
    results = await spawner.pool(double_agent, [])
    assert results == []


@pytest.mark.anyio
async def test_pool_bounded_concurrency():
    """At most `concurrency` children should run at the same time."""
    import anyio

    peak_concurrent = 0
    current_concurrent = 0

    @agent(name="counter")
    async def counter_agent(ctx: AgentContext) -> None:
        nonlocal peak_concurrent, current_concurrent
        await ctx.receive()
        current_concurrent += 1
        peak_concurrent = max(peak_concurrent, current_concurrent)
        await anyio.sleep(0.05)  # hold the slot briefly
        current_concurrent -= 1
        await ctx.send("__out__", "done")

    spawner = Spawner()
    await spawner.pool(counter_agent, list(range(8)), concurrency=3)
    assert peak_concurrent <= 3


@pytest.mark.anyio
async def test_pool_propagates_exception_from_any_child():
    spawner = Spawner()
    # anyio task groups wrap concurrent exceptions in ExceptionGroup
    with pytest.raises(ExceptionGroup) as exc_info:
        await spawner.pool(always_fails_agent, ["a", "b"])
    assert any(
        isinstance(e, ValueError) and "child always fails" in str(e)
        for e in exc_info.value.exceptions
    )


# ── ctx.spawn() from within an agent ─────────────────────────────────────────


@pytest.mark.anyio
async def test_ctx_spawn_delegates_to_child():
    received = []

    @agent(name="orchestrator")
    async def orchestrator(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        result = await ctx.spawn(double_agent, msg.payload)
        received.append(result)

    runtime = AgentRuntime()
    runtime.register(orchestrator)

    async with runtime.run():
        await runtime.send("orchestrator", payload=7)
        await anyio.sleep(0.1)

    assert received == [14]


@pytest.mark.anyio
async def test_ctx_pool_fan_out_and_collect():
    collected = []

    @agent(name="fan-out")
    async def fan_out(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        items = msg.payload  # list of numbers
        results = await ctx.pool(double_agent, items, concurrency=2)
        collected.extend(results)

    runtime = AgentRuntime()
    runtime.register(fan_out)

    async with runtime.run():
        await runtime.send("fan-out", payload=[3, 4, 5])
        await anyio.sleep(0.2)

    assert sorted(collected) == [6, 8, 10]


@pytest.mark.anyio
async def test_ctx_spawn_raises_without_spawner():
    """ctx.spawn() raises RuntimeError when no spawner is injected."""
    from mosesaic.core.bus import MessageBus
    from mosesaic.core.cost import CostTracker
    from mosesaic.core.message import AgentMessage, MessageType

    bus = MessageBus()
    bus.register("bare")
    ctx = AgentContext(
        agent_name="bare",
        bus=bus,
        cost_tracker=CostTracker(agent_name="bare"),
        spawner=None,
    )
    with pytest.raises(RuntimeError, match="No spawner configured"):
        await ctx.spawn(double_agent, 1)


# ── Nested spawn (spawned agent can itself spawn) ─────────────────────────────


@pytest.mark.anyio
async def test_nested_spawn():
    """Agent A spawns agent B, which spawns agent C."""

    @agent(name="triple")
    async def triple_agent(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        # spawn double, then double again → 4×
        doubled = await ctx.spawn(double_agent, msg.payload)
        quadrupled = await ctx.spawn(double_agent, doubled)
        await ctx.send("__out__", quadrupled)

    spawner = Spawner()
    result = await spawner.spawn(triple_agent, 3)
    assert result == 12  # 3 → 6 → 12
