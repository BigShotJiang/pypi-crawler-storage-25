import anyio
import pytest

from mosesaic.core.agent import SupervisorPolicy, agent
from mosesaic.core.bus import MessageBus
from mosesaic.core.context import AgentContext
from mosesaic.core.message import AgentMessage, MessageType
from mosesaic.core.supervisor import Supervisor
from mosesaic.exceptions import MosesaicMaxRestartsExceeded


@pytest.mark.anyio
async def test_supervisor_restarts_failing_agent():
    restart_count = 0

    @agent(name="flaky", supervisor=SupervisorPolicy(max_restarts=2, on_failure="restart"))
    async def flaky(ctx: AgentContext) -> None:
        nonlocal restart_count
        restart_count += 1
        if restart_count < 2:
            raise RuntimeError("transient failure")
        # Second run: receive and exit cleanly
        await ctx.receive()

    bus = MessageBus()
    supervisor = Supervisor(definition=flaky, bus=bus)

    msg = AgentMessage(from_agent="test", to_agent="flaky", type=MessageType.TASK, payload="go")
    await bus.send(msg)

    async with anyio.create_task_group() as tg:
        tg.start_soon(supervisor.run)
        await anyio.sleep(0.1)
        tg.cancel_scope.cancel()

    assert restart_count == 2


@pytest.mark.anyio
async def test_supervisor_raises_after_max_restarts():
    call_count = 0

    @agent(name="always-fails", supervisor=SupervisorPolicy(max_restarts=2, on_failure="restart"))
    async def always_fails(ctx: AgentContext) -> None:
        nonlocal call_count
        call_count += 1
        raise RuntimeError("always fails")

    bus = MessageBus()
    supervisor = Supervisor(definition=always_fails, bus=bus)

    msg = AgentMessage(
        from_agent="test", to_agent="always-fails", type=MessageType.TASK, payload="go"
    )
    await bus.send(msg)

    with pytest.raises(MosesaicMaxRestartsExceeded):
        with anyio.fail_after(1.0):
            await supervisor.run()

    assert call_count == 3  # initial + 2 restarts


@pytest.mark.anyio
async def test_supervisor_enforces_budget():
    @agent(
        name="expensive",
        supervisor=SupervisorPolicy(budget_usd=0.01),
    )
    async def expensive(ctx: AgentContext) -> None:
        from mosesaic.core.cost import AgentCostEvent
        ctx.cost.record(AgentCostEvent(
            agent_name="expensive", model="claude-opus-4-6",
            input_tokens=1000, output_tokens=500, cost_usd=0.02, trace_id="t",
        ))
        ctx.cost.check_before_call(estimated_cost_usd=0.01, call_description="next call")

    bus = MessageBus()
    supervisor = Supervisor(definition=expensive, bus=bus)

    msg = AgentMessage(
        from_agent="test", to_agent="expensive", type=MessageType.TASK, payload="go"
    )
    await bus.send(msg)

    with anyio.fail_after(1.0):
        with pytest.raises(Exception):
            await supervisor.run()
