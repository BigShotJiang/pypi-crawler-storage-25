import anyio
import pytest

from mosesaic.core.agent import AgentDefinition, SupervisorPolicy, agent
from mosesaic.core.bus import MessageBus
from mosesaic.core.context import AgentContext
from mosesaic.core.cost import CostTracker
from mosesaic.core.message import AgentMessage, MessageType


def test_agent_decorator_returns_definition():
    @agent(name="my-agent")
    async def my_agent(ctx: AgentContext) -> None:
        pass

    assert isinstance(my_agent, AgentDefinition)
    assert my_agent.name == "my-agent"


def test_agent_definition_defaults():
    @agent(name="test")
    async def test_agent(ctx: AgentContext) -> None:
        pass

    assert test_agent.supervisor_policy.budget_usd is None
    assert test_agent.supervisor_policy.max_restarts == 3
    assert test_agent.supervisor_policy.on_failure == "restart"


def test_agent_supervisor_policy_custom():
    @agent(
        name="budget-agent",
        supervisor=SupervisorPolicy(budget_usd=0.50, max_restarts=1, on_failure="stop"),
    )
    async def budget_agent(ctx: AgentContext) -> None:
        pass

    assert budget_agent.supervisor_policy.budget_usd == 0.50
    assert budget_agent.supervisor_policy.max_restarts == 1
    assert budget_agent.supervisor_policy.on_failure == "stop"


@pytest.mark.anyio
async def test_context_send_puts_message_on_bus():
    bus = MessageBus()
    cost_tracker = CostTracker()
    ctx = AgentContext(agent_name="A", bus=bus, cost_tracker=cost_tracker)

    await ctx.send("B", payload="hello")

    msg = await bus.receive("B")
    assert msg.from_agent == "A"
    assert msg.to_agent == "B"
    assert msg.payload == "hello"
    assert msg.type == MessageType.TASK


@pytest.mark.anyio
async def test_context_receive_gets_message_from_bus():
    bus = MessageBus()
    cost_tracker = CostTracker()
    ctx = AgentContext(agent_name="B", bus=bus, cost_tracker=cost_tracker)

    msg = AgentMessage(from_agent="A", to_agent="B", type=MessageType.TASK, payload="work")
    await bus.send(msg)

    received = await ctx.receive()
    assert received.payload == "work"


def test_agent_system_prompt_default_is_none():
    @agent(name="no-persona")
    async def no_persona(ctx: AgentContext) -> None:
        pass

    assert no_persona.system_prompt is None


def test_agent_system_prompt_stored():
    @agent(name="with-persona", system_prompt="You are a senior developer.")
    async def with_persona(ctx: AgentContext) -> None:
        pass

    assert with_persona.system_prompt == "You are a senior developer."


def test_agent_governance_tier_default_is_one():
    @agent(name="t")
    async def fn(ctx):
        pass

    assert fn.governance_tier == 1


def test_agent_governance_tier_stored():
    @agent(name="t", governance_tier=3)
    async def fn(ctx):
        pass

    assert fn.governance_tier == 3


def test_agent_governance_tier_invalid_raises():
    with pytest.raises(ValueError, match="governance_tier"):
        @agent(name="t", governance_tier=4)
        async def fn(ctx):
            pass
