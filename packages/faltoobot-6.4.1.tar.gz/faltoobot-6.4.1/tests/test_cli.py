import io
import shlex
import subprocess
import sys
from pathlib import Path

from faltoobot.cli import app as cli
from faltoobot.config import Config


def make_config(tmp_path: Path) -> Config:
    home = tmp_path / "home"
    root = home / ".faltoobot"
    return Config(
        home=home,
        root=root,
        config_file=root / "config.toml",
        log_file=root / "faltoobot.log",
        sessions_dir=root / "sessions",
        session_db=root / "session.db",
        launch_agent=home / "Library" / "LaunchAgents" / "com.faltoobot.agent.plist",
        run_script=root / "run.sh",
        openai_api_key="",
        openai_oauth="",
        openai_model="gpt-5.4",
        openai_thinking="high",
        openai_fast=False,
        openai_transcription_model="gpt-4o-transcribe",
        allow_group_chats=set(),
        allowed_chats=set(),
        bot_name="Faltoo",
        browser_binary="",
    )


def test_write_run_script_uses_whatsapp_service(tmp_path: Path) -> None:
    config = make_config(tmp_path)

    cli._write_run_script(config)

    text = config.run_script.read_text()
    assert text.startswith("#!/bin/sh\n")
    assert f"cd {shlex.quote(config.root.as_posix())}" in text
    assert (
        f"exec {shlex.quote(sys.executable)} -m faltoobot.cli.app {cli.SERVICE_COMMAND}"
        in text
    )


def test_write_systemd_service_redirects_to_log(tmp_path: Path) -> None:
    config = make_config(tmp_path)
    cli._write_run_script(config)

    cli._write_systemd_service(config)

    text = cli._linux_service_file(config).read_text()
    assert "Description=Faltoobot WhatsApp bot" in text
    assert "WantedBy=default.target" in text
    assert shlex.quote(config.run_script.as_posix()) in text
    assert shlex.quote(config.log_file.as_posix()) in text


def test_install_service_uses_systemd_on_linux(tmp_path: Path, monkeypatch) -> None:
    config = make_config(tmp_path)
    calls: list[tuple[tuple[str, ...], bool]] = []

    def fake_systemctl(
        *args: str, check: bool = True
    ) -> subprocess.CompletedProcess[str]:
        calls.append((args, check))
        return subprocess.CompletedProcess(["systemctl", "--user", *args], 0, "", "")

    monkeypatch.setattr(cli.sys, "platform", "linux")
    monkeypatch.setattr(cli, "ensure_config_file", lambda: config.config_file)
    monkeypatch.setattr(cli, "_run_systemctl", fake_systemctl)

    cli._install_service(config)

    assert config.run_script.exists()
    assert cli._linux_service_file(config).exists()
    assert calls == [
        (("daemon-reload",), True),
        (("enable", "faltoobot.service"), True),
    ]


def test_render_log_line_uses_level_colors() -> None:
    assert cli._render_log_line("2026-03-17 INFO faltoobot: ok").style == "cyan"
    assert (
        cli._render_log_line(
            "13:03:05.809 [whatsmeow.Client.Socket WARNING] - noisy"
        ).style
        == "yellow"
    )
    assert (
        cli._render_log_line("Traceback (most recent call last):").style == "bold red"
    )


def test_run_update_command_upgrades_then_bootstraps(
    tmp_path: Path, monkeypatch
) -> None:
    config = make_config(tmp_path)
    calls: list[tuple[str, ...]] = []
    migrations: list[dict[str, str]] = []
    versions = iter(["1.6.0", "1.6.0"])

    monkeypatch.setattr(cli, "build_config", lambda: config)
    monkeypatch.setattr(cli, "_uv_bin", lambda: "uv")
    monkeypatch.setattr(cli, "_run_cmd", lambda *args: calls.append(args))
    monkeypatch.setattr(cli, "package_version", lambda name: next(versions))
    crontab: list[str] = []
    monkeypatch.setattr(
        cli, "_ensure_crontab_path", lambda: crontab.append("ran") or True
    )
    reinstalls: list[str] = []
    monkeypatch.setattr(
        cli,
        "_run_migrations",
        lambda config, **kwargs: migrations.append(kwargs) or ["sessions"],
    )
    monkeypatch.setattr(cli, "_service_installed", lambda config: True)
    monkeypatch.setattr(
        cli, "_reinstall_service", lambda config: reinstalls.append("ran")
    )
    recorded_updates: list[tuple[str, str]] = []
    monkeypatch.setattr(
        cli, "record_update", lambda old, new: recorded_updates.append((old, new))
    )

    result = cli.run_update_command(config)

    assert calls == [("uv", "tool", "upgrade", "faltoobot")]
    assert crontab == ["ran"]
    assert migrations == [{"previous_version": "1.6.0", "current_version": "1.6.0"}]
    assert recorded_updates == [("1.6.0", "1.6.0")]
    assert reinstalls == ["ran"]
    assert result == config


def test_run_update_command_reexecs_when_new_version_was_installed(
    tmp_path: Path, monkeypatch
) -> None:
    config = make_config(tmp_path)
    calls: list[tuple[str, ...]] = []
    versions = iter(["1.6.0", "1.6.1"])
    reexecs: list[str] = []

    monkeypatch.setattr(cli, "build_config", lambda: config)
    monkeypatch.setattr(cli, "_uv_bin", lambda: "uv")
    monkeypatch.setattr(cli, "_run_cmd", lambda *args: calls.append(args))
    monkeypatch.setattr(cli, "package_version", lambda name: next(versions))
    reinstalls: list[str] = []
    monkeypatch.setattr(
        cli, "_reinstall_service", lambda config: reinstalls.append("ran")
    )
    monkeypatch.delenv(cli.PREVIOUS_VERSION_ENV, raising=False)
    monkeypatch.setattr(cli, "_reexec_current_command", lambda: reexecs.append("ran"))
    monkeypatch.setattr(
        cli,
        "_ensure_crontab_path",
        lambda: (_ for _ in ()).throw(AssertionError("should not run")),
    )

    result = cli.run_update_command(config)

    assert calls == [("uv", "tool", "upgrade", "faltoobot")]
    assert reinstalls == []
    assert reexecs == ["ran"]
    assert cli.os.environ[cli.PREVIOUS_VERSION_ENV] == "1.6.0"
    assert result is None


def test_run_update_command_records_original_version_after_reexec(
    tmp_path: Path, monkeypatch
) -> None:
    config = make_config(tmp_path)
    versions = iter(["6.1.0", "6.1.0"])
    recorded_updates: list[tuple[str, str]] = []

    monkeypatch.setenv(cli.PREVIOUS_VERSION_ENV, "6.0.0")
    monkeypatch.setattr(cli, "build_config", lambda: config)
    monkeypatch.setattr(cli, "_uv_bin", lambda: "uv")
    monkeypatch.setattr(cli, "_run_cmd", lambda *args: None)
    monkeypatch.setattr(cli, "package_version", lambda name: next(versions))
    monkeypatch.setattr(cli, "_ensure_crontab_path", lambda: True)
    monkeypatch.setattr(cli, "_run_migrations", lambda config, **kwargs: [])
    monkeypatch.setattr(cli, "_service_installed", lambda config: False)
    monkeypatch.setattr(
        cli, "record_update", lambda old, new: recorded_updates.append((old, new))
    )

    result = cli.run_update_command(config)

    assert recorded_updates == [("6.0.0", "6.1.0")]
    assert cli.PREVIOUS_VERSION_ENV not in cli.os.environ
    assert result == config


def test_run_whatsapp_command_runs_service_flow(tmp_path: Path, monkeypatch) -> None:
    config = make_config(tmp_path)
    calls: list[str] = []

    monkeypatch.setattr(cli, "run_update_command", lambda config=None: config)
    monkeypatch.setattr(
        cli, "_reinstall_service", lambda config: calls.append("reinstall")
    )
    monkeypatch.setattr(cli, "show_logs", lambda config=None: calls.append("logs"))

    cli.run_whatsapp_command(config)

    assert calls == ["reinstall", "logs"]


def test_run_migrations_reports_actual_changes(tmp_path: Path, monkeypatch) -> None:
    config = make_config(tmp_path)

    monkeypatch.setattr(cli, "migrate_config_file", lambda path: False)
    monkeypatch.setattr(
        cli,
        "run_migrations",
        lambda config, **kwargs: ["migration:remove-session-last-used"],
    )

    assert cli._run_migrations(config) == [
        "sessions",
        "migration:remove-session-last-used",
    ]
    assert config.sessions_dir.exists()


def test_run_migrations_is_quiet_when_clean(tmp_path: Path, monkeypatch) -> None:
    config = make_config(tmp_path)
    config.sessions_dir.mkdir(parents=True)

    monkeypatch.setattr(cli, "migrate_config_file", lambda path: False)
    monkeypatch.setattr(cli, "run_migrations", lambda config, **kwargs: [])

    assert cli._run_migrations(config) == []


def test_run_update_command_creates_default_config(tmp_path: Path, monkeypatch) -> None:
    config = make_config(tmp_path)
    versions = iter(["1.6.0", "1.6.0"])

    monkeypatch.setattr(cli, "build_config", lambda: config)
    monkeypatch.setattr(cli, "_uv_bin", lambda: "uv")
    monkeypatch.setattr(cli, "_run_cmd", lambda *args: None)
    monkeypatch.setattr(cli, "package_version", lambda name: next(versions))
    monkeypatch.setattr(cli, "_ensure_crontab_path", lambda: True)
    monkeypatch.setattr(cli, "_run_migrations", lambda config, **kwargs: [])
    monkeypatch.setattr(cli, "_service_installed", lambda config: False)

    result = cli.run_update_command(config)

    assert result == config


def test_handle_codex_login_command(monkeypatch) -> None:
    calls: list[str] = []

    monkeypatch.setattr(cli, "run_openai_login", lambda console: calls.append("login"))

    cli.handle_command(cli.argparse.Namespace(command="codex-login"), None)

    assert calls == ["login"]


def test_parse_args_hides_service_command_from_help(monkeypatch, capsys) -> None:
    monkeypatch.setattr(cli.sys, "argv", ["faltoobot", "--help"])

    try:
        cli.parse_args()
    except SystemExit:
        pass
    else:
        raise AssertionError("expected help to exit")

    assert "whatsapp-service" not in capsys.readouterr().out


def test_parse_args_accepts_hidden_service_command(monkeypatch) -> None:
    monkeypatch.setattr(cli.sys, "argv", ["faltoobot", cli.SERVICE_COMMAND])

    args = cli.parse_args()

    assert args.command == cli.SERVICE_COMMAND


def test_run_notify_command_formats_message_with_source(monkeypatch) -> None:
    seen: dict[str, str | None] = {}
    monkeypatch.setattr(
        cli.notify_queue,
        "enqueue_notification",
        lambda chat_key, message, *, source=None: (
            seen.__setitem__("chat_key", chat_key)
            or seen.__setitem__("message", message)
            or seen.__setitem__("source", source)
            or "notify-1"
        ),
    )

    result = cli.run_notify_command(
        cli.argparse.Namespace(
            chat_key="code@demo",
            message="Hello from cron",
            source="cron:daily-ops",
        )
    )

    assert result == "notify-1"
    assert seen["chat_key"] == "code@demo"
    assert seen["source"] == "cron:daily-ops"
    message = seen["message"]
    assert message is not None
    assert "Hello from cron" in message


def test_run_notify_command_reads_message_from_stdin(monkeypatch) -> None:
    seen: dict[str, str | None] = {}
    monkeypatch.setattr(
        cli.notify_queue,
        "enqueue_notification",
        lambda chat_key, message, *, source=None: (
            seen.__setitem__("chat_key", chat_key)
            or seen.__setitem__("message", message)
            or seen.__setitem__("source", source)
            or "notify-1"
        ),
    )

    class FakeStdin(io.StringIO):
        def isatty(self) -> bool:
            return False

    monkeypatch.setattr(cli.sys, "stdin", FakeStdin("Hello from stdin\n"))

    result = cli.run_notify_command(
        cli.argparse.Namespace(
            chat_key="code@demo",
            message=None,
            source="monitor:disk-usage",
        )
    )

    assert result == "notify-1"
    assert seen["chat_key"] == "code@demo"
    assert seen["source"] == "monitor:disk-usage"
    message = seen["message"]
    assert message is not None
    assert "Hello from stdin" in message


def test_run_browser_command_installs_playwright_chrome_when_binary_missing(
    tmp_path: Path, monkeypatch
) -> None:
    config = make_config(tmp_path)
    calls: list[tuple[str, ...]] = []
    seen: dict[str, str] = {}

    monkeypatch.setattr(cli, "build_config", lambda: config)
    monkeypatch.setattr(cli, "_run_cmd", lambda *args: calls.append(args))
    installed = iter([None, "/tmp/chrome"])
    monkeypatch.setattr(
        cli.browser_runtime, "default_browser_binary", lambda: next(installed)
    )
    monkeypatch.setattr(
        cli.browser_runtime,
        "open_browser",
        lambda *, root, binary, url=None: seen.update(
            {"root": str(root), "binary": binary, "url": url or ""}
        ),
    )

    cli.run_browser_command(cli.argparse.Namespace(url="https://example.com"), config)

    assert calls == [(sys.executable, "-m", "playwright", "install", "chrome")]
    assert seen == {
        "root": str(config.root),
        "binary": "/tmp/chrome",
        "url": "https://example.com",
    }
    data = cli.merge_config(cli.load_toml(config.config_file))
    assert data["browser"]["binary"] == "/tmp/chrome"


def test_run_browser_command_rejects_missing_configured_binary(
    tmp_path: Path, monkeypatch
) -> None:
    config = make_config(tmp_path)
    config.browser_binary = "/tmp/does-not-exist"

    try:
        cli.run_browser_command(cli.argparse.Namespace(url=None), config)
    except SystemExit as exc:
        assert str(exc) == "Configured browser binary not found: /tmp/does-not-exist"
    else:
        raise AssertionError("Expected SystemExit")


def test_run_whatsapp_auth_surfaces_libmagic_help(monkeypatch, tmp_path: Path) -> None:
    config = make_config(tmp_path)

    original_import = __import__

    def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "faltoobot.whatsapp.login":
            raise ImportError("failed to find libmagic. Check your installation")
        return original_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(cli.sys, "platform", "darwin")
    monkeypatch.setattr("builtins.__import__", fake_import)

    try:
        cli._run_whatsapp_auth(config)
    except SystemExit as exc:
        assert str(exc) == (
            "WhatsApp support requires libmagic on macOS. Install it with `brew install libmagic` and rerun the command."
        )
    else:
        raise AssertionError("expected SystemExit")


def test_non_whatsapp_commands_do_not_import_whatsapp(monkeypatch) -> None:
    calls: list[str] = []

    def fake_update(config=None):
        calls.append("update")

    monkeypatch.setattr(cli, "run_update_command", fake_update)

    cli.handle_command(cli.argparse.Namespace(command="update"), None)

    assert calls == ["update"]


def test_crontab_path_value_appends_uv_bin() -> None:
    value = cli._crontab_path_value(Path("/tmp/uv-bin"), "/usr/bin:/bin")

    assert value == "/usr/bin:/bin:/tmp/uv-bin"


def test_ensure_crontab_path_inserts_path_for_empty_crontab(monkeypatch) -> None:
    monkeypatch.setattr(cli, "_uv_tool_bin_dir", lambda: Path("/tmp/uv-bin"))
    monkeypatch.setattr(cli, "_load_crontab", lambda: "")
    monkeypatch.setattr(cli.os, "environ", {"PATH": "/usr/bin:/bin"})
    written: list[str] = []
    monkeypatch.setattr(cli, "_write_crontab", lambda text: written.append(text))

    changed = cli._ensure_crontab_path()

    assert changed is True
    assert written == ["PATH=/usr/bin:/bin:/tmp/uv-bin\n"]


def test_ensure_crontab_path_updates_existing_path(monkeypatch) -> None:
    monkeypatch.setattr(cli, "_uv_tool_bin_dir", lambda: Path("/tmp/uv-bin"))
    monkeypatch.setattr(
        cli,
        "_load_crontab",
        lambda: "PATH=/usr/bin:/bin\n* * * * * faltoochat\n",
    )
    written: list[str] = []
    monkeypatch.setattr(cli, "_write_crontab", lambda text: written.append(text))

    changed = cli._ensure_crontab_path()

    assert changed is True
    assert written == ["PATH=/usr/bin:/bin:/tmp/uv-bin\n* * * * * faltoochat\n"]


def test_ensure_crontab_path_skips_when_already_present(monkeypatch) -> None:
    monkeypatch.setattr(cli, "_uv_tool_bin_dir", lambda: Path("/tmp/uv-bin"))
    monkeypatch.setattr(
        cli, "_load_crontab", lambda: "PATH=/usr/bin:/bin:/tmp/uv-bin\n"
    )
    monkeypatch.setattr(
        cli,
        "_write_crontab",
        lambda text: (_ for _ in ()).throw(AssertionError("should not write")),
    )

    changed = cli._ensure_crontab_path()

    assert changed is False
