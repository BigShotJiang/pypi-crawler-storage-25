"""Lightweight version definitions shared by packaging and runtime code."""

__version__ = "1.4.12"
__api_version__ = "0279"
