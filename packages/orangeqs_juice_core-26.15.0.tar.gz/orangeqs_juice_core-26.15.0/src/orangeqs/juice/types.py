"""Common type definitions used in Juice."""

from __future__ import annotations

from abc import abstractmethod
from typing import Protocol, TypeVar, runtime_checkable


@runtime_checkable
class Comparable(Protocol):
    """Protocol type that supports comparison."""

    @abstractmethod
    def __eq__(self: ComparableT, value: ComparableT, /) -> bool:  # noqa: D105  # pyright: ignore[reportIncompatibleMethodOverride]
        pass

    @abstractmethod
    def __ne__(self: ComparableT, value: ComparableT, /) -> bool:  # noqa: D105  # pyright: ignore[reportIncompatibleMethodOverride]
        pass

    @abstractmethod
    def __lt__(self: ComparableT, value: ComparableT, /) -> bool:  # noqa: D105  # pyright: ignore[reportIncompatibleMethodOverride]
        pass

    @abstractmethod
    def __gt__(self: ComparableT, value: ComparableT, /) -> bool:  # noqa: D105  # pyright: ignore[reportIncompatibleMethodOverride]
        pass

    @abstractmethod
    def __le__(self: ComparableT, value: ComparableT, /) -> bool:  # noqa: D105  # pyright: ignore[reportIncompatibleMethodOverride]
        pass

    @abstractmethod
    def __ge__(self: ComparableT, value: ComparableT, /) -> bool:  # noqa: D105  # pyright: ignore[reportIncompatibleMethodOverride]
        pass


ComparableT = TypeVar("ComparableT", bound=Comparable)
