"""IPython implementation of a OrangeQS Juice service."""

import asyncio
import json
import logging
import signal
import threading
from types import TracebackType
from typing import TYPE_CHECKING, Any, ClassVar

import tornado
import tornado.platform.asyncio
from ipykernel.ipkernel import IPythonKernel
from ipykernel.kernelapp import IPKernelApp
from ipykernel.zmqshell import ZMQInteractiveShell
from IPython.core.async_helpers import get_asyncio_loop
from IPython.core.interactiveshell import (
    ExecutionInfo,
    ExecutionResult,
    InteractiveShell,
)
from traitlets.config import ArgvType

from orangeqs.juice.client.ipython import ipython_client_async
from orangeqs.juice.schemas.ipython import (
    IPythonKernelConfigs,
    KernelConnectionInfo,
    KernelConnectionRegistry,
)
from orangeqs.juice.service._service import Service
from orangeqs.juice.task import Task

if TYPE_CHECKING:
    from jupyter_client.asynchronous.client import AsyncKernelClient

_logger = logging.getLogger(__name__)


class _NoArgvIPKernelApp(IPKernelApp):
    """IPKernelApp subclass that does not parse sys.argv on initialization.

    This prevents issues when the service is started with command line arguments
    that are not recognized by IPython. Also happens in other environments like pytest.
    """

    def parse_command_line(self, argv: ArgvType = None) -> None:
        """Override to skip parsing sys.argv."""
        pass


class _IPythonTask(Task):
    """Schema for executing IPython code for the service side.

    The only goal of this class is to deserialize task payloads with a `code` property.
    This class should not be subclasses to define specific tasks,
    use {class}`~.tasks.IPythonTask` instead.

    The fields of this class should be kept in sync with the fields of
    {class}`~.tasks.IPythonTask`.
    """

    model_config = {"extra": "ignore"}

    # See `orangeqs.juice.tasks.IPythonTask` for the meaning of these fields.
    code: str
    run_async: bool

    @classmethod
    def type(cls) -> str:
        """Return the unique name of the task type.

        Always returns `"IPythonTask"` to ensure all IPython tasks are deserialized
        using this class and routed to the same handler.
        """
        return "IPythonTask"

    parallel: ClassVar[bool] = False


class IPythonService(Service):
    """IPython service implementation for OrangeQS Juice."""

    def __init__(
        self,
        service_name: str,
        /,
        *,
        init_module: str | None = None,
    ) -> None:
        """Initialize an IPython OrangeQS Juice service.

        This services runs as an IPython kernel.

        Parameters
        ----------
        service_name : str
            The name of the service. Will be used to load the service configuration.
        init_module : str, optional
            The module to run on service startup.
            This module should contain any setup code required for the service.
            It will be executed as code cell on startup: `from {init_module} import *`.
            Defaults to none, which means no initialization code is run.
        """
        super().__init__(service_name)
        self._init_module = init_module

        # Store a copy of the event loop that will later be used by IPython.
        # This is used to have access to a loop before IPython is fully started.
        self._ipython_loop = get_asyncio_loop()
        asyncio.set_event_loop(self._ipython_loop)

        self._kernel_app: _NoArgvIPKernelApp = _NoArgvIPKernelApp()

        connection_info = _load_kernel_connection_info(self.service_name).model_dump(
            exclude_none=True
        )
        _logger.debug("Applying kernel connection config %s", connection_info)
        self._kernel_app.load_connection_info(connection_info)

        self._kernel_app.initialize()  # type: ignore partially Unknown type

        self._store_kernel_connection_info()

        assert self._kernel_app.shell is not None, (
            "IPKernelApp shell is not initialized"
        )
        assert isinstance(self._kernel_app.shell, ZMQInteractiveShell), (
            f"IPKernelApp shell is {type(self._kernel_app.shell)}, "
            "which is not an instance of ZMQInteractiveShell"
        )
        self._shell = self._kernel_app.shell

        assert isinstance(self._kernel_app.kernel, IPythonKernel), (  # pyright: ignore[reportUnknownMemberType]
            f"IPKernelApp kernel is {type(self._kernel_app.kernel)}, "  # pyright: ignore[reportUnknownMemberType, reportUnknownArgumentType]
            "which is not an instance of IPythonKernel"
        )
        self._kernel = self._kernel_app.kernel  # pyright: ignore[reportUnknownMemberType]

        # Store the last execution result to be able to return it in the task response.
        self._last_execute_result: ExecutionResult | None = None
        self._shell.events.register("post_run_cell", self._store_execute_result)  # pyright: ignore[reportUnknownMemberType]

        self._kernel_client: AsyncKernelClient | None = None
        self._kernel_client_lock = asyncio.Lock()

        self.register_handler(_IPythonTask, self._handle_ipython_task)

        self._init_module_executed_event = threading.Event()

    def start(self) -> None:
        """Start an IPython OrangeQS Juice service."""
        super().start()

        self._setup_signal_handlers()
        self._shell.set_custom_exc((Exception,), _service_exception_handler)  # pyright: ignore[reportUnknownMemberType]
        self._execute_init_module()

        self._kernel_app.start()

    @property
    def loop(self) -> asyncio.AbstractEventLoop:
        """The event loop used by the IPython kernel.

        Raises
        ------
        RuntimeError
            If the IPython kernel is using a different event loop than the one
            set in the constructor. This should never happen, but is there to catch
            any future IPython changes that cause the kernel to use a different loop.
        """
        if not hasattr(self._kernel_app, "io_loop"):
            # IPython app has not been started yet, so we cannot get the current loop.
            # Instead we return the loop we stored on initialization, and assume that
            # IPython will use this loop later when it starts.
            return self._ipython_loop
        if not isinstance(
            self._kernel_app.io_loop, tornado.platform.asyncio.BaseAsyncIOLoop
        ):
            raise RuntimeError(
                f"IPKernelApp IO loop is {type(self._kernel_app.io_loop)}, "
                "which is not an instance of BaseAsyncIOLoop"
            )
        current_ipython_loop = self._kernel_app.io_loop.asyncio_loop
        if current_ipython_loop is not self._ipython_loop:
            # If this error is raised, it's likely that either IPython, asyncio
            # or tornado.ioloop changed how event loops are created or managed.
            raise RuntimeError(
                "Current IPython loop is different from the loop set in the "
                "constructor, but expected them to be the same. "
            )
        return current_ipython_loop

    def _store_execute_result(self, result: ExecutionResult) -> None:
        """Store the execution result of the last executed task."""
        if (
            result.info is not None
            and isinstance(result.info, ExecutionInfo)  # pyright: ignore[reportUnknownMemberType]
            and result.info.cell_id is None  # pyright: ignore[reportUnknownMemberType]
        ):
            # For code cells executed through a proxy kernel, the cell_id is defined.
            # For code executed through an ipyclient the cell_id is None.
            # We only want to store the result for code executed as a task (which uses
            # an ipyclient), otherwise we might overwrite the result of a task with the
            # result of proxy kernel code cell.
            # FIXME: There is a race condition if another ipyclient (not a proxy
            # kernel) executes code at the same time, as it might overwrite
            # the last execution result.
            self._last_execute_result = result

    async def _handle_ipython_task(
        self, task: _IPythonTask, wait_for_init_module: bool = True
    ) -> dict[str, Any]:
        """Handle an IPython task by executing the code in the IPython shell."""
        if wait_for_init_module:
            # Wait for the init module to be executed before handling any tasks,
            # to ensure that the service is fully initialized before handling any tasks.
            _logger.debug(
                "Waiting for init module to be executed before handling task..."
            )
            await asyncio.get_running_loop().run_in_executor(
                None, self._init_module_executed_event.wait
            )

        _logger.debug("Executing IPython code: %s", task.code)
        if task.run_async:
            execution_result = await self._shell.run_cell_async(  # pyright: ignore[reportUnknownMemberType]
                raw_cell=task.code, transformed_cell=task.code
            )
        else:
            async with self._kernel_client_lock:
                if self._kernel_client is None:
                    self._kernel_client = ipython_client_async(
                        self.service_name, self._kernel_connection_registry
                    )
                    self._kernel_client.start_channels()
                    await self._kernel_client.wait_for_ready()
                self._last_execute_code = task.code
                await self._kernel_client.execute_interactive(  # pyright: ignore[reportUnknownMemberType]
                    task.code,
                    # Require silent=False to get the execution result.
                    silent=False,
                    store_history=False,
                    stop_on_error=False,
                )
                assert self._last_execute_result is not None
                execution_result = self._last_execute_result

        error = execution_result.error_before_exec or execution_result.error_in_exec
        if error:
            return {
                "status": "error",
                "ename": type(error).__name__,
                "evalue": str(error),
            }

        result = execution_result.result
        try:
            # Check if the result is JSON serializable
            json.dumps(result)
        except (TypeError, OverflowError):
            # If not, convert it to a string representation already
            result = repr(result)

        return {"status": "ok", "result": result}

    def _store_kernel_connection_info(self) -> None:
        """Store the full ipykernel connection info in shared runtime data.

        This data is used in two ways:
        - To reuse the random ports from the last runtime on service restart.
        - To provide the connection info to clients for connecting to the kernel.
        """
        connection_info = KernelConnectionInfo.model_validate(
            self._kernel_app.get_connection_info()
        )
        self._kernel_connection_registry = KernelConnectionRegistry(
            services={self.service_name: connection_info},
        )
        self._kernel_connection_registry.store(key=self.service_name, exist_ok=True)

    def _execute_init_module(self) -> None:
        """Execute the initialization module for the service if specified."""
        if self._init_module is None:
            _logger.info("No init module specified, skipping init module execution.")
            return

        _logger.info(f"Executing init module {self._init_module}")
        try:
            # It's very important to use the asyncio loop that will later
            # be used by IPython! Otherwise objects might be created
            # in the wrong event loop.
            init_result = self.loop.run_until_complete(
                self._handle_ipython_task(
                    _IPythonTask(
                        code=f"from {self._init_module} import *",
                        # Kernel is not started yet, so we need to execute the code
                        # without using the kernel client.
                        run_async=True,
                    ),
                    # No need to wait for the init module, as we are executing it here.
                    wait_for_init_module=False,
                )
            )
            self._shell.user_ns["JUICE_INIT_RESULT"] = init_result  # pyright: ignore[reportUnknownMemberType]

            if init_result.get("status") != "ok":
                raise RuntimeError(
                    f"Error encountered while running {self._init_module}: "
                    f"{init_result}"
                )

            _logger.info(f"Successfully executed init module {self._init_module}")
        except Exception as e:
            _logger.error(f"Failed to execute init module {self._init_module}: {e}")
            raise RuntimeError(
                f"Failed to execute init module {self._init_module}"
            ) from e
        finally:
            self._init_module_executed_event.set()

    def _setup_signal_handlers(self) -> None:
        """Set up signal handlers for graceful termination."""
        signal.signal(signal.SIGTERM, self._terminate)
        _logger.debug("Signal handlers for SIGTERM set up.")

    def _terminate(self, signum: int, frame: object) -> None:
        """Terminate the IPKernelApp."""
        self._kernel_app.exit()


def _service_exception_handler(
    shell: InteractiveShell,
    etype: type[BaseException],
    evalue: BaseException,
    tb: TracebackType | None,
    tb_offset: int | None = None,
) -> None:
    """Log uncaught IPython exceptions and show traceback."""
    logger = logging.getLogger()
    logger.error(
        f"Uncaught exception: {etype.__name__}: {evalue}",
        exc_info=(etype, evalue, tb),
        extra={"skip_stdout": True},  # Skip stdout, let showtraceback handle it
    )
    shell.showtraceback((etype, evalue, tb), tb_offset=tb_offset)  # type: ignore


def _load_kernel_connection_info(service_name: str) -> KernelConnectionInfo:
    """Load the kernel connection info from config and shared runtime data.

    This method retrieves the connection info config for the IPython kernel.
    It takes the config from `IPythonKernelConfigs` and applies sensible defaults:
    - Ports: default to the ports from the last runtime data.
    - Key: default to the key from the last runtime data.
    - IP: default to `juice-{service_name}`

    Parameters
    ----------
    service_name : str
        The name of the service for which to load the connection info.

    Returns
    -------
    IPythonKernelConfig
        The connection info for the IPython kernel.
    """
    connection_info = KernelConnectionInfo()

    # Load ports and key from last shared runtime data
    connection_registry = KernelConnectionRegistry.load()
    if service_name in connection_registry.services:
        last_connect_info = connection_registry.services[service_name]
        connection_info = connection_info.model_copy(
            update=last_connect_info.model_dump(
                include={
                    "hb_port",
                    "iopub_port",
                    "shell_port",
                    "stdin_port",
                    "control_port",
                    "key",
                }
            )
        )

    connection_info.ip = f"juice-{service_name}"

    # Override data with config values
    ipykernel_configs = IPythonKernelConfigs.load()
    if service_name in ipykernel_configs.services:
        ipython_config = ipykernel_configs.services[service_name]
        connection_info = connection_info.model_copy(
            update=ipython_config.model_dump(exclude_none=True)
        )

    return connection_info
