"""Data Structures for Throttling."""

from __future__ import annotations

import importlib
from enum import Flag
from typing import Annotated, Any, ClassVar

import pint
from pint import Unit
from pydantic import Field, field_serializer, model_validator
from typing_extensions import Self

from orangeqs.juice.messaging import Event
from orangeqs.juice.settings import BaseConfigurable, Configurable


class ParameterMonitorConfig(Configurable):
    """Parameter Monitor configuration.

    This configuration defines the juice parameters
    to monitor for throttling and their thresholds.
    """

    filename: ClassVar[str] = "parameter-monitor"
    """Filename for configuration."""

    juice_topic_monitoring_units: dict[str, JuiceTopicMonitorConfig] = Field(
        default_factory=dict
    )
    """Dictionary of Juice Topic Monitor units.

    The key is the unique identifier for the unit,
     and the value is the configuration for that unit.
    """


class JuiceTopicMonitorConfig(BaseConfigurable):
    """Base monitoring configuration for individual units.

    Defines a topic and field to monitor, and thresholds for warning and throttling.
    """

    display_label: str
    """Human-readable description to display in the UI."""

    unit: str = "1"
    """Unit that the value is measured in. Must be compatible with `pint.Unit()`.

    Defaults to dimensionless unit.
    """

    monitored_topic: str
    """Juice topic to subscribe for monitoring the unit."""

    monitored_event_type: str
    """Type of the event to monitor.

    This should be the full module path of the event class,
    e.g. `orangeqs.juice.system_monitor.data_structures.TemperaturePoint`.

    The field specified in `monitored_field` should be present in
    the data of this event."""

    monitored_field: str
    """Field in the topic data to monitor."""

    warn_if_larger: float | None = None
    """Warn users if the unit is above a certain value."""

    throttle_if_larger: float | None = None
    """Pause executing experiments if the unit is above a certain value."""

    throttle_grace_interval: float = 0.0
    """
    Interval between detection of throttled state and actually throttling.

    This value can be used if the value can fluctuate. If it is set to non-zero time,
    system will monitor value for that time to ensure that system should be throttled.
    """

    stop_throttle_if_smaller: float | None = None
    """
    Resume executing experiments if the unit is below a certain value.

    In general, this value should be less than `throttle_if_larger`. For example,
    if we are running equipment that is constantly heating up under the load and
    throttle at 90°C, it may be wise to wait until it cools down to 80°C before
    resuming experiments.

    If `throttle_if_larger` is specified, `stop_throttle_if_smaller` will be set
    to the same value by default. If `stop_throttle_if_smaller` is larger than
    `throttle_if_larger`, settings won't pass validation.
    """
    stop_throttle_grace_interval: float = 0.0
    """
    Interval between detection of safe state and actually resuming.

    This value can be used if the value can fluctuate. If it is set to non-zero time,
    system will monitor value for that time to ensure that system should be resumed.
    """

    @model_validator(mode="after")
    def _validate_event_type_and_field(self) -> Self:
        module_path, _, class_name = self.monitored_event_type.rpartition(".")
        try:
            module = importlib.import_module(module_path)
            event_class = getattr(module, class_name)
        except (ImportError, AttributeError) as e:
            raise ValueError(
                f"Monitored event type {self.monitored_event_type} cannot be imported."
            ) from e

        if not issubclass(event_class, Event):
            raise ValueError(
                f"Monitored event type {self.monitored_event_type} is not"
                " a subclass of Event."
            )

        if self.monitored_field not in event_class.model_fields:
            raise ValueError(
                f"Monitored field {self.monitored_field} is not present in "
                f"{self.monitored_event_type}."
            )

        return self

    @model_validator(mode="after")
    def _validate_unit(self) -> Self:
        try:
            Unit(self.unit)
        except pint.errors.UndefinedUnitError:
            raise ValueError(f"Unit {self.unit} is not recognized by Pint.")
        return self

    @model_validator(mode="after")
    def _throttle_if_larger_stop_if_smaller_relation(self) -> Self:
        if self.throttle_if_larger is not None:
            if self.stop_throttle_if_smaller is None:
                self.stop_throttle_if_smaller = self.throttle_if_larger
            elif self.throttle_if_larger < self.stop_throttle_if_smaller:
                raise ValueError(
                    "Inconsistent configuration of monitoring unit for "
                    f"{self.display_label}: `throttle_if_larger` is smaller than "
                    "stop_throttle_if_smaller."
                )
        elif self.stop_throttle_if_smaller is not None:
            raise ValueError(
                "Inconsistent configuration of monitoring unit for "
                f"{self.display_label}: `stop_throttle_if_smaller` is defined, "
                "but `throttle_if_larger` is not defined."
            )

        return self


class ThrottleState(Flag):
    """Throttle state of a monitoring unit.

    Attributes
    ----------
    THROTTLED : ThrottleState
        The unit is throttled.
    WARNING : ThrottleState
        The unit is not throttled, but passed the warning threshold.
    SAFE : ThrottleState
        The unit is not throttled.
    """

    SAFE = 0
    WARNING = 1
    THROTTLED = 2


class ThrottleStateEvent(Event):
    """Throttle state event for pubsub and database update.

    For the global system throttle state, `id` should be set to "SYSTEM" and
    `value` set to None.
    """

    measurement: ClassVar[str] = "throttle_state"
    """Measurement name for throttle state."""

    def topic(self) -> str:
        """Return the topic for the throttle state event."""
        return f"throttle_state.{self.id}"

    throttled: ThrottleState
    """Whether the unit is currently throttled."""

    value: Any
    """The value of the monitored parameter.

    Marked as None for the global system throttle state."""

    id: Annotated[str, "tag"]
    """ID for the unit that this event is associated with.

    Marked as SYSTEM for the global system throttle state."""

    @field_serializer("throttled")
    def serialize_throttle_state(self, value: ThrottleState) -> int:
        """Serialize the ThrottleState to an integer for storage in InfluxDB."""
        return value.value
