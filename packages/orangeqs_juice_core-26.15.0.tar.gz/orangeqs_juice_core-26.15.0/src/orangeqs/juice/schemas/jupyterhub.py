"""Schema definitions for JupyterHub API responses."""

from pydantic import AwareDatetime, BaseModel


class ActiveUser(BaseModel):
    """Model representing an active user."""

    name: str
    last_activity: AwareDatetime
