"""Handler to serve thumbnail images for dashboard pages."""

import logging
from typing import Any

import tornado.web
from typing_extensions import override

from orangeqs.juice.dashboard.utils import DashboardConfig

_logger = logging.getLogger(__name__)

_DEFAULT_IMAGE = "orangeqs.juice.dashboard.static:images/thumbnails/unknown.svg"


def _load_svg_image(import_path: str) -> bytes:
    """Load an SVG image from the given import path."""
    import importlib.resources

    module_path, _, image_path = import_path.rpartition(":")
    image = importlib.resources.files(module_path).joinpath(image_path)
    with image.open("rb") as f:
        return f.read()


def _extract_image_path(
    category: str, page: str | None, config: DashboardConfig
) -> str | None:
    """Extract the image import path from the dashboard configuration."""
    category_entry = config.categories.get(category)
    if not category_entry:
        return None

    if page:
        page_entry = category_entry.pages.get(page)
        if not page_entry:
            return None
        image_path = page_entry.image
    else:
        image_path = category_entry.image

    return image_path


class PageThumbnailHandler(tornado.web.RequestHandler):
    """Serve thumbnail images for dashboard pages."""

    @override
    def initialize(
        self,
        template_variables: dict[str, Any],
        *args,  # noqa: ANN002 # type: ignore
        **kwargs,  # noqa: ANN003 # type: ignore
    ) -> None:
        """Discard template variables."""
        super().initialize(*args, **kwargs)
        self._config = DashboardConfig.load(cache=True)

    def get(self) -> None:
        """Serve thumbnail images for dashboard pages.

        Expects two query parameters to identify the page:
        - 'category' - the category key of the page
        - 'page' - the page key within the category, optional
        """
        category = self.get_query_argument("category")
        page = self.get_query_argument("page", None)

        image_path = _extract_image_path(category, page, self._config)
        if not image_path:
            image_path = _DEFAULT_IMAGE

        self.set_header("Content-Type", "image/svg+xml")
        self.finish(_load_svg_image(image_path))  # pyright: ignore[reportUnknownMemberType]
