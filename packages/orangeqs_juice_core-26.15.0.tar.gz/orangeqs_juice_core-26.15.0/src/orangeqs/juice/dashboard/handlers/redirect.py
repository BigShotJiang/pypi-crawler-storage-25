"""Handler to redirect user to the overview page."""

import logging

from orangeqs.juice.dashboard.dashboard_handlers import MainHandler

_logger = logging.getLogger(__name__)


class RedirectToHomeHandler(MainHandler):
    """Handler to redirect to the home page of the dashboard."""

    overview_url = "/core/home"

    def get(self) -> None:
        """Redirect to the overview page."""
        _logger.debug("Redirecting to home page.")
        self.redirect(f"{self.overview_url}")
