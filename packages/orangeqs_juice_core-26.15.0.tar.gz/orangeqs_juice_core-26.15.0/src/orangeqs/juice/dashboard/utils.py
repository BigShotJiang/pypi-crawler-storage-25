"""Utilities for dashboard."""

from __future__ import annotations

import asyncio
import logging
import os
import re
import traceback
import warnings
from collections.abc import Callable
from datetime import datetime, timezone
from functools import partial
from inspect import Signature, signature
from typing import TYPE_CHECKING, Any, ClassVar

import pandas as pd
from bokeh.application import Application
from bokeh.application.handlers import FunctionHandler
from bokeh.document import Document
from bokeh.models import ImportedStyleSheet
from jinja2 import BaseLoader, ChoiceLoader, Environment, PackageLoader
from jinja2 import Template as JinjaTemplate
from panel.template import Template
from panel.viewable import ServableMixin
from pydantic import Field, model_validator
from typing_extensions import override

from orangeqs.juice._entrypoints import collect_entry_points
from orangeqs.juice._util import load_object_reference
from orangeqs.juice.client.pubsub import subscriber_async
from orangeqs.juice.settings import BaseConfigurable, Configurable

if TYPE_CHECKING:
    from collections.abc import Callable, Generator, Iterator

    from bokeh.application.application import SessionContext
    from tornado import web


_logger = logging.getLogger(__name__)

TORNADO_APPLICATIONS = collect_entry_points(group="juice.dashboard.tornado")
BOKEH_APPLICATIONS = collect_entry_points(group="juice.dashboard.bokeh")


def _jupyterhub_service_prefix() -> str:
    """Get the JupyterHub service prefix without trailing slash.

    Looks up the `JUPYTERHUB_SERVICE_PREFIX` environment variable to determine the
    prefix. This variable usually contains the prefix for the user container, e.g.
    `/user/<username>`. Ensures that the returned prefix has no trailing slash.
    """
    prefix = os.environ.get("JUPYTERHUB_SERVICE_PREFIX", "")
    if prefix.endswith("/"):
        prefix = prefix[:-1]
    return prefix


def dashboard_base_url() -> str:
    """Get the base URL for the dashboard without trailing slash.

    The URL consists of:
    - The JupyterHub service prefix (e.g. `/user/<username>`)
    - The endpoint for the dashboard, which is `/dashboard`

    An example full URL would be `/user/<username>/dashboard`.
    """
    return f"{_jupyterhub_service_prefix()}/dashboard"


def filebrowser_base_url() -> str:
    """Get the base URL for the filebrowser without trailing slash.

    A direct link to a specific path in the file browser can be constructed as
    `{filebrowser_base_url()}/path/to/directory`.

    The URL returned by this function consists of:
    - The JupyterHub service prefix (e.g. `/user/<username>`)
    - The proxy path for the file browser, which is `/filebrowser`
    - The endpoint to serve files of the file browser, which is `/files`

    An example returned URL is `/user/<username>/filebrowser/files`.
    """
    return f"{_jupyterhub_service_prefix()}/filebrowser/files"


def jupyterlab_base_url() -> str:
    """Get the base URL for JupyterLab without trailing slash.

    The URL consists of:
    - The JupyterHub service prefix (e.g. `/user/<username>`)
    - The endpoint to serve JupyterLab, which is `/lab`

    An example full URL would be `/user/<username>/lab`.
    """
    return f"{_jupyterhub_service_prefix()}/lab"


def vscode_base_url() -> str:
    """Get the base URL for VS Code without trailing slash.

    The URL consists of:
    - The JupyterHub service prefix (e.g. `/user/<username>`)
    - The endpoint to serve VS Code, which is `/vscode`

    An example full URL would be `/user/<username>/vscode`.
    Specific folders can be opened by adding `?folder=path/to/folder` to the URL.
    """
    return f"{_jupyterhub_service_prefix()}/vscode"


def influxdb2_base_url() -> str:
    """Get the base URL for InfluxDB2 without trailing slash.

    The URL consists of:
    - The JupyterHub service prefix (e.g. `/user/<username>`)
    - The endpoint to serve InfluxDB2, which is `/influxdb2`

    An example full URL would be `/user/<username>/influxdb2`.
    """
    return f"{_jupyterhub_service_prefix()}/influxdb2"


def _config_to_entry_points(
    config: DashboardConfig,
) -> Generator[DashboardEntry, Any, None]:
    """Yield dashboard entries with entry points from the dashboard configuration."""
    for category in config.categories.values():
        if category.entry_point:
            yield category
        for page in category.pages.values():
            if page.entry_point:
                yield page


def collect_dashboard_applications() -> tuple[
    list[tuple[str, type[web.RequestHandler], dict[str, Any]]],
    dict[str, Callable[..., Template] | Application],
]:
    """Collect all dashboard applications defined by extensions.

    Returns
    -------
    dict[str, type[web.RequestHandler], dict[str, Any]]
        A dictionary mapping URL paths to Tornado request handlers
        and their initialization arguments.
    dict[str, Application]
        A dictionary mapping URL paths to Bokeh applications.
    """
    dashboard_config = DashboardConfig.load(cache=True)
    # Assemble template variables
    template_variables = {
        "base_url": dashboard_base_url(),
        **dashboard_config.model_dump(),
    }

    # Collect tornado applications from entry points
    applications: list[tuple[str, type[web.RequestHandler], dict[str, Any]]] = []
    _logger.debug("Collecting tornado applications from entry points")
    for method_name, entry_point in TORNADO_APPLICATIONS.items():
        _logger.debug(f"Found tornado entry point: {method_name} -> {entry_point.name}")
        handler = entry_point.load()
        applications.append(
            (
                f"/{method_name.lstrip('/')}",
                handler,
                {"template_variables": template_variables},
            )
        )

    # Collect bokeh applications from entry points
    bokeh_apps: dict[str, Callable[[], Template] | Application] = {}
    _logger.debug("Collecting bokeh applications from entry points")
    for entry in _config_to_entry_points(dashboard_config):
        assert entry.url, f"Entry {entry} has an entry point but no URL"
        _logger.debug(f"Found Bokeh entry point: {entry.url} -> {entry.entry_point}")
        try:
            bokeh_apps[f"/{entry.url.lstrip('/')}"] = _build_page_handler(
                template_variables, entry
            )

        except Exception as e:
            _logger.error(f"Failed to load Bokeh app {entry.entry_point}: {e}")

    return applications, bokeh_apps


def _build_error_document_handler(
    template_variables: dict[str, Any],
    traceback: str,
    entry: DashboardEntry,
    message: str,
) -> Callable[[], Template]:
    """Build an error document handler that displays the given information.

    This is used as a fallback when loading or calling an app function fails,
    to show a user-friendly error message in the browser.
    """

    def _error_document() -> Template:
        from orangeqs.juice.dashboard import juice_environment

        template = juice_environment.get_panel_template("base_juice.html")
        for k, v in template_variables.items():
            template.add_variable(k, v)
        template.add_variable("load_failed", True)
        template.add_variable("load_failed_message", message)
        template.add_variable("traceback", traceback)
        template.add_variable("page_title", entry.name)
        return template

    return _error_document


def _build_page_handler(
    template_variables: dict[str, Any], entry: DashboardEntry
) -> Application | Callable[[], Template]:
    """Build a Bokeh application or Panel template factory for a dashboard entry.

    Handles errors gracefully by returning an error document handler if the entry point
    cannot be loaded or called successfully.
    """
    try:
        assert entry.entry_point is not None, f"Entry {entry} has no entry point"
        app_function = load_object_reference(entry.entry_point)
        kind = _classify_app_function(app_function)

        try:
            if kind == "doc_modifier":
                # TODO: Handle errors while calling Bokeh applications.
                return Application(  # type: ignore
                    FunctionHandler(partial(app_function, template_variables))
                )
            elif kind == "panel_factory":

                def _app() -> Template:
                    try:
                        return app_function(template_variables)
                    except Exception:
                        _logger.exception(
                            f"Failed to call app function for entry {entry}."
                        )
                        return _build_error_document_handler(
                            template_variables,
                            traceback.format_exc(),
                            entry,
                            f"Error while calling page function {entry.entry_point}",
                        )()

                return _app
            else:
                raise RuntimeError(f"Unexpected app function kind: {kind}")
        except TypeError as e:
            raise TypeError(
                "Cannot determine how to handle app function"
                f"{app_function.__name__!r}: {e}."
                "Expected a Bokeh doc-modifier or a Panel viewable factory."
            )
    except Exception:
        _logger.exception(f"Failed to load app function for entry {entry}.")
        return _build_error_document_handler(
            template_variables,
            traceback.format_exc(),
            entry,
            f"Error while loading page function {entry.entry_point}",
        )


def _classify_app_function(func: Callable[..., Any]) -> str:
    """
    Determine what kind of app function a function is.

    If the function has a Bokeh Document as a parameter, it will be
    classified as a Bokeh Document modification function. For example
    `create_overview_doc(template_variables: dict[str, Any], doc: Document) -> None`.
    If the return annotation is servable by Panel or the literal string "Template"
    it will be classified as a Panel Template creation function. For example
    `create_overview_doc(template_variables: dict[str, Any]) -> Template`.

    Parameters
    ----------
        func: Callable[..., Any]
            The function to classify.

    Returns
    -------
        Either "doc_modifier" for Bokeh Document modification functions or panel_factory
        for Panel Template creation functions.
    """
    sig = signature(func)

    params = list(sig.parameters.values())
    has_doc_param = any(p.annotation is Document or p.name == "doc" for p in params)

    return_ann = sig.return_annotation

    # Function modifies a Bokeh doc
    if has_doc_param:
        return "doc_modifier"

    # Function produces a Panel viewable
    if return_ann is not Signature.empty and (
        (isinstance(return_ann, type) and issubclass(return_ann, ServableMixin))
        or isinstance(return_ann, str)
        and return_ann.split(".")[-1] == "Template"
    ):
        return "panel_factory"

    raise TypeError(f"Unrecognised signature: {params} -> {return_ann}")


def _url_to_name(url: str) -> str:
    """Convert a URL path to a human-readable name.

    Replaces `-`, `_`, and `/` with spaces and capitalizes each word.
    """
    words = re.split(r"[-/_]+", url.strip("/"))
    return " ".join(word.capitalize() for word in words)


def _common_apps() -> dict[str, DashboardCategory]:
    """Build a list of dashboard applications."""
    entries: dict[str, DashboardCategory] = {}
    # This category needs to be in sync with the one in dashboard.toml
    entries["extensions"] = DashboardCategory(
        order=20,
        name="Extensions",
        pages={},
    )
    entries["extensions"].pages["instrument"] = DashboardEntry(
        order=10,
        name="Instrument Monitor",
        url="instrument-monitor",
        description=("Instrument and quantum device state explorer."),
        image="orangeqs.juice.dashboard.static:images/thumbnails/juice.svg",
    )
    entries["extensions"].pages["graph"] = DashboardEntry(
        order=20,
        name="Graph Monitor",
        url="graph-monitor",
        description=("Calibration graph progress and analyzed experiment results."),
        image="orangeqs.juice.dashboard.static:images/thumbnails/juice.svg",
    )
    entries["extensions"].pages["plot"] = DashboardEntry(
        order=30,
        name="Plot Monitor",
        url="plot-monitor",
        description=("Live plotting of experimental results."),
        image="orangeqs.juice.dashboard.static:images/thumbnails/juice.svg",
    )
    entries["extensions"].pages["fridge-automation"] = DashboardEntry(
        order=40,
        name="Fridge Automation",
        url="fridge-automation",
        description=("Automated control of the cryogenic system."),
        image="orangeqs.juice.dashboard.static:images/thumbnails/juice.svg",
    )
    return entries


class DashboardEntry(BaseConfigurable):
    """Dashboard page entry. Appears on the homepage and the navigation bar."""

    name: str
    """Human-readable name of the entry."""

    url: str | None = None
    """URL path of the entry, or None if not a link.

    If `entry_point` is defined, this will be the URL the page will be served at.
    If not provided, will be determined automatically by using the key of the
    category and page, i.e. `{category_key}/{page_key}`.

    Otherwise this can be any URL pointing to an internal or external resource.
    In that case it applies the following rules to determine how to handle the URL:
    - If the URL starts with `http://` or `https://`, it's considered an absolute URL.
    - If the URL starts with a `/`, it's considered an absolute path on the current
      domain.
    - Otherwise the URL is considered relative to the dashboard base URL, which is
      useful for linking to specific dashboard pages.

    The URL supports the following placeholders. All placeholders have a leading `/`,
    but no trailing `/`.
    - `{base_url}`: Base URL for the JupyterHub user, e.g. `/user/<username>`.
    - `{dashboard_base_url}`: See {py:func}`~.dashboard_base_url`.
    - `{filebrowser_base_url}`: See {py:func}`~.filebrowser_base_url`.
    - `{jupyterlab_base_url}`: See {py:func}`~.jupyterlab_base_url`.
    - `{vscode_base_url}`: See {py:func}`~.vscode_base_url`.
    - `{influxdb2_base_url}`: See {py:func}`~.influxdb2_base_url`.
    """

    image: str | None = None
    """Optional image for the entry.

    Must be of the form `importable.module:filepath`, where `filepath` is the path to
    the image file relative to the module. For example,
    `my_module.static:images/my_image.png`.

    Don't forget to include the image file in the package data of your package,
    see for example <https://setuptools.pypa.io/en/latest/userguide/datafiles.html>
    for how to do this using `setuptools`.
    """

    entry_point: str | None = None
    """Object reference to the function that instantiates the page this entry links to.

    Also referred to as the "entry point". This function will be called to instantiate
    the page that this entry refers to.
    Must be of the form `importable.module:callable`.
    """

    description: str | None = None
    """Optional description of the entry, shown on the homepage."""

    order: int = Field(default=100, ge=0)
    """
    Order of the entry in the navigation bar and home page.

    Lower numbers appear first.
    """

    new_tab: bool = False
    """Whether to open the link in a new tab."""


class DashboardCategory(DashboardEntry):
    """Dashboard category. Appears on the home page and the navigation bar.

    Note that a category entry also supports linking to a page. However, this link
    will only show up in the navigation bar, not on the homepage.
    """

    pages: dict[str, DashboardEntry] = Field(default_factory=dict)
    """Sub-pages under this category, keyed by unique keys."""


class DashboardConfig(Configurable):
    """Configuration for the dashboard.

    Defines the pages and categories that appears on the home page and navigation bar.
    """

    filename: ClassVar[str] = "dashboard"

    categories: dict[str, DashboardCategory] = Field(default_factory=dict)
    """Categories for the dashboard pages, keyed by unique keys."""

    def add_page_from_entrypoint(self, url: str, entry_point: str) -> None:
        """Add a page to the dashboard by URL.

        If the page URL is found in the common apps, it will be added as that entry.

        Otherwise, this assumes the URL is of the form "category/page" or just "page".
        Automatically creates categories as needed.
        """
        warnings.warn(
            "Adding pages using entry points is deprecated and will be removed in a "
            "future release. Pages should be added through the dashboard.toml "
            "configuration file instead.",
            DeprecationWarning,
        )
        # TODO: Remove the logic for finding entries in the common apps
        # once all extensions have migrated.
        existing_category, existing_page = _find_entry_in_common_apps(url)

        # Only handle page entries, not pure category entries
        if existing_category and existing_page:
            _logger.debug(
                f"Adding page from entry point {entry_point} to existing entry"
            )
            category_key, category = existing_category
            if category_key not in self.categories:
                category = category.model_copy(deep=True)
                category.pages = {}
                self.categories[category_key] = category
            else:
                # Copy attributes onto the existing category, but don't override them.
                current_category = self.categories[category_key]
                if not current_category.order:
                    current_category.order = category.order
                if not current_category.name:
                    current_category.name = category.name
                if not current_category.description:
                    current_category.description = category.description
                if not current_category.image:
                    current_category.image = category.image
                if not current_category.url:
                    current_category.url = category.url
                if not current_category.entry_point:
                    current_category.entry_point = category.entry_point
                if not current_category.new_tab:
                    current_category.new_tab = category.new_tab

            page_key, page = existing_page
            page = page.model_copy(deep=True)
            page.entry_point = entry_point
            self.categories[category_key].pages[page_key] = page
            return

        _logger.debug(f"Adding page from entry point {entry_point} with URL {url}")

        url = url.strip("/")
        if not url:
            # Cannot add a page with an empty URL
            return

        category_url, _, relative_page_url = url.partition("/")

        if category_url not in self.categories:
            self.categories[category_url] = DashboardCategory(
                name=_url_to_name(category_url)
            )
        category: DashboardCategory = self.categories[category_url]

        if relative_page_url:
            # Add the page to the category
            page = DashboardEntry(
                name=_url_to_name(relative_page_url),
                url=url,
                entry_point=entry_point,
            )
            category.pages[relative_page_url] = page
        else:
            # Make the category entry point to this page.
            category.url = url
            category.entry_point = entry_point

    @model_validator(mode="after")
    def _fill_missing_urls(self) -> DashboardConfig:
        """Fill missing URLs for entries that don't have them explicitly set.

        URLs are determined from the key of the category and page.
        """
        for category_key, category in self.categories.items():
            if category.url is None and category.entry_point is not None:
                category.url = category_key
            for page_key, page in category.pages.items():
                if page.url is None and page.entry_point is None:
                    raise ValueError(
                        f"Page {page.name} in category {category.name} "
                        "has no URL or entry point defined. "
                        "Pages must have either a URL or an entry point defined."
                    )
                if page.url is None and page.entry_point is not None:
                    page.url = f"{category_key}/{page_key}"
        return self

    @model_validator(mode="after")
    def _format_urls(self) -> DashboardConfig:
        """Format the URLs with placeholders for common URLs."""
        replacements = {
            "base_url": _jupyterhub_service_prefix(),
            "dashboard_base_url": dashboard_base_url(),
            "filebrowser_base_url": filebrowser_base_url(),
            "jupyterlab_base_url": jupyterlab_base_url(),
            "vscode_base_url": vscode_base_url(),
            "influxdb2_base_url": influxdb2_base_url(),
        }
        for category in self.categories.values():
            if (category_url := category.url) is not None:
                category.url = category_url.format(**replacements)
            for page in category.pages.values():
                if (page_url := page.url) is not None:
                    page.url = page_url.format(**replacements)
        return self

    @model_validator(mode="after")
    def _add_from_entrypoints(self) -> DashboardConfig:
        """Add pages from entry points to the configuration."""
        for url, entry_point in BOKEH_APPLICATIONS.items():
            self.add_page_from_entrypoint(url, entry_point.value)
        return self


HOME_PAGE_APPS = _common_apps()
"""Predefined common applications for the dashboard homepage.

These are also used to populate the navigation bar.
"""


def _find_entry_in_common_apps(
    url: str,
) -> tuple[tuple[str, DashboardCategory] | None, tuple[str, DashboardEntry] | None]:
    """Find an entry in the common apps by URL.

    Returns
    -------
    tuple[tuple[str, DashboardCategory], tuple[str, DashboardEntry] | None] | None
        The category key, category, entry key and entry if the URL exists as a page.
        The category_key and category if the URL exists as a category.
        Otherwise `None` if the URL is not found in the common apps.
    """
    for category_key, category in HOME_PAGE_APPS.items():
        if category.url == url:
            return (category_key, category), None
        for entry_key, entry in category.pages.items():
            if entry.url == url:
                return (category_key, category), (entry_key, entry)
    return None, None


def subscribe_to_events_task(
    doc: Document,
    subscriptions: list[tuple[type, str]],
    handler: Callable[[Any], None],
) -> asyncio.Task[Any]:
    """
    Create and manage an async task to listen for pub/sub events.

    WARNING: The returned task must be kept referenced to avoid being garbage collected.

    Parameters
    ----------
        doc: Document
            The Bokeh document to schedule callbacks on.
        subscriptions: list[tuple[type, str]]
            A list of (event class, topic) tuples to subscribe to.
        handler: Callable[[Any], None]
            A callable to handle each incoming event.

    Returns
    -------
        An asyncio.Task managing the subscription.

    Example:
        class SomeDashboardComponent:
            def __init__(self, client, doc):
                self.client = client
                self.doc = doc
                self.listener_task = subscribe_to_events_task(
                    self.doc,
                    [(QuantityUpdate, "he3_flow")],
                    self._handle_event
                )

            def _handle_event(self, event):
                # Process event (e.g. update a ColumnDataSource)
                self.source.patch({...})
    """

    async def listen() -> None:
        subscriber = subscriber_async()
        for event_class, topic in subscriptions:
            subscriber.subscribe(event_class, topic=topic)

            _logger.debug("Subscribed to %s on topic %s", event_class, topic)

        while True:
            event = await subscriber.get()
            try:
                doc.add_next_tick_callback(partial(handler, event))
            except Exception as e:
                _logger.warning(f"Could not schedule callback: {e}")
                break

    task = asyncio.create_task(listen())

    def on_done(t: asyncio.Task[Any]) -> None:
        try:
            exc = t.exception()
            if exc:
                _logger.exception(f"Listener crashed: {exc}")
        except asyncio.CancelledError:
            _logger.info("Listener was cancelled.")
        except Exception:
            _logger.exception("Unexpected exception in listener")

    task.add_done_callback(on_done)

    def _on_session_destroyed(
        session_context: SessionContext, task: asyncio.Task[Any]
    ) -> None:
        if not task.done():
            task.cancel()
            _logger.info("Listener task cancelled due to session end.")

    doc.on_session_destroyed(partial(_on_session_destroyed, task=task))

    return task


def get_palette(count: int) -> list[str]:
    """Return OQS color palette for <count> colors, repeating."""
    base_list = [
        "#326299",  # oqs_blue
        "#EA7422",  # oqs_orange
        "#7CB75D",  # oqs_green
        "#E62D27",  # oqs_red
        "#F9BF0C",  # oqs_amber
        "#45D4D2",  # oqs_cyan
    ]

    def cycle() -> Iterator[str]:
        """Cycle through base_list of colors."""
        while True:
            yield from base_list

    return [x for (_, x) in zip(range(count), cycle())]


def get_stylesheet(path: str) -> ImportedStyleSheet:
    """Retrieve CSS file hosted by the singleuser server."""
    return ImportedStyleSheet(url=dashboard_base_url() + f"/static/juice/css/{path}")


def to_local_time(dt: datetime) -> datetime:
    """
    Convert a datetime object to the local timezone.

    Parameters
    ----------
        dt (datetime): The datetime object to convert. It should be timezone-aware.
                       If the input datetime is naive (lacking timezone information),
                       it will be assumed to be in UTC, and a warning will be raised.

    Returns
    -------
        datetime: The datetime object converted to the local timezone.

    Notes
    -----
        - If the input is a pandas.Timestamp, it will be handled similarly, with naive
          timestamps being assumed to be in UTC.
        - A warning will be logged if the input datetime or pandas.Timestamp is naive.
    """
    if isinstance(dt, pd.Timestamp):
        if dt.tz is None:
            _logger.warning(
                "Input pandas Timestamp is naive (no timezone info), assuming UTC.",
                stacklevel=2,
            )
            dt = dt.tz_localize(tz=timezone.utc)
        return dt.tz_convert(datetime.now().astimezone().tzinfo)
    if dt.tzinfo is None or dt.tzinfo.utcoffset(dt) is None:
        _logger.warning(
            "Input datetime is naive (no timezone info), assuming UTC.", stacklevel=2
        )
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone()


class JuiceEnvironment(Environment):
    """Manage the Jinja template environment for Juice."""

    _template_paths = [
        "orangeqs.juice.dashboard",
        "orangeqs.juice.dashboard.pages.templates",
    ]

    @override
    def __init__(
        self,
        extra_loaders: BaseLoader | list[BaseLoader] | None = None,
        extra_template_paths: str | list[str] | None = None,
    ) -> None:
        """Juice template environment.

        Parameters
        ----------
            extra_loaders: BaseLoader | list[BaseLoader] = None
                Extra Jinja template loaders. Useful for Juice Extensions that cannot
                place templates in the Juice Core templates directory.
            extra_template_paths: str | list[str] = None
                Extra template paths. For example `orangeqs.juice_ext.my_ext.templates`.
        """
        template_paths: list[str] = self._template_paths
        if extra_template_paths:
            if isinstance(extra_template_paths, list):
                template_paths += extra_template_paths
            else:
                template_paths.append(extra_template_paths)
        loaders: list[BaseLoader] = [
            PackageLoader(p, package_path="") for p in template_paths
        ]
        if extra_loaders:
            if isinstance(extra_loaders, list):
                loaders += extra_loaders
            else:
                loaders.append(extra_loaders)
        super().__init__(loader=ChoiceLoader(loaders))

    def get_jinja_template(self, file_name: str) -> JinjaTemplate:
        """Retrieve a Jinja template by name."""
        return self.get_template(file_name)

    def get_panel_template(self, file_name: str) -> Template:
        """Retrieve a template by file name as a Panel template.

        For Juice Extensions: Note that if the directory the template file
        is in has not been added with extra_loaders or extra_template_paths
        in the init function beforehand, it will not be found.
        """
        return Template(self.get_template(file_name))
