"""Overview dashboard page."""

import logging
from typing import Any

import panel as pn
from panel.template import Template

from orangeqs.juice.dashboard import juice_environment
from orangeqs.juice.dashboard.widgets import (
    ActiveUserWidget,
    ControlPCOverviewTable,
    ParameterMonitorWidget,
    ServiceUsageOverviewTable,
    SystemThrottleStateDisplay,
)

_logger = logging.getLogger(__name__)


def create_system_overview_doc(template_variables: dict[str, Any]) -> Template:
    """Create the system overview page."""
    _logger.debug(
        "create_system_overview_doc called with template_variables: %s",
        template_variables,
    )

    # Setup Jinja2 environment
    template = juice_environment.get_panel_template("system_overview.html")

    _logger.debug("Adding ControlPCOverviewTable to Bokeh document.")

    control_pc_table = ControlPCOverviewTable()
    service_usage_table = ServiceUsageOverviewTable()
    parameter_monitor_widget = ParameterMonitorWidget()
    system_throttle_state_display = SystemThrottleStateDisplay()
    active_user_widget = ActiveUserWidget()

    # Initial update and periodic updates every second
    pn.state.execute(control_pc_table.start)
    pn.state.execute(service_usage_table.start)
    pn.state.execute(parameter_monitor_widget.start)
    pn.state.execute(system_throttle_state_display.start)
    pn.state.add_periodic_callback(active_user_widget.update, 1000)

    template.add_panel("control_pc_table", control_pc_table.table)
    template.add_panel("service_usage_table", service_usage_table.table)
    template.add_panel("parameter_monitor", parameter_monitor_widget.table)
    template.add_panel(
        "system_throttle_state_display", system_throttle_state_display.root
    )
    template.add_panel("active_user_widget", active_user_widget.root)

    # setting up document title
    template.add_variable("page_title", "System Overview")
    for k, v in template_variables.items():
        template.add_variable(k, v)
    _logger.debug(
        f"System Overview doc rendered with template variables: {template_variables}"
    )
    return template
