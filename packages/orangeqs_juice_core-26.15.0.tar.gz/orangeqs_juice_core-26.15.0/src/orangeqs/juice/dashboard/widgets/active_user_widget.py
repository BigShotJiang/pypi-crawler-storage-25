"""Active User Widget for the OrangeQS Juice Dashboard."""

import logging

import pandas as pd
from panel.widgets import Tabulator

from orangeqs.juice.client.jupyterhub import list_active_users
from orangeqs.juice.dashboard.utils import get_stylesheet, to_local_time

from ._constants import DATETIME_FORMAT

_logger = logging.getLogger(__name__)


class ActiveUserWidget:
    """Widget to display active users in the OrangeQS Juice Dashboard."""

    def __init__(self) -> None:
        self.root = Tabulator(
            pd.DataFrame(columns=["name", "last_activity"]),
            **{
                "layout": "fit_data_stretch",
                "show_index": False,
                "disabled": True,  # Make the cells uneditable
                "sizing_mode": "stretch_width",
                "stylesheets": [get_stylesheet("custom-bokeh.css")],
            },
            titles={
                "name": "Username",
                "last_activity": "Last Action",
            },
        )

    def update(self) -> None:
        """Fetch active user data and update the widget."""
        # Fetch active user data from your data source
        users = list_active_users()
        _logger.info("Fetched %d active users.", len(users))
        df = pd.DataFrame(
            [
                {
                    "name": user.name,
                    "last_activity": to_local_time(user.last_activity).strftime(
                        DATETIME_FORMAT
                    ),
                }
                for user in users
            ]
        )
        self.root.value = df
