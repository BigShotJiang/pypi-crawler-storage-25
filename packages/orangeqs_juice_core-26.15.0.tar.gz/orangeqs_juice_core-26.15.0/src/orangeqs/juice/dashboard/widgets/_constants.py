"""Constants for the OrangeQS Juice Dashboard."""

DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S %Z"
