"""Widget that displays service usages."""

from typing import TYPE_CHECKING, Any

import pint
from bokeh.io import curdoc
from bokeh.layouts import row
from bokeh.models import Div
from pint import Quantity
from typing_extensions import override

from orangeqs.juice.client.influxdb2 import influxdb2_query_api_async
from orangeqs.juice.dashboard.utils import subscribe_to_events_task
from orangeqs.juice.dashboard.widgets.common import DataTableWidget
from orangeqs.juice.schemas.parameter_monitor import (
    JuiceTopicMonitorConfig,
    ParameterMonitorConfig,
    ThrottleState,
    ThrottleStateEvent,
)

if TYPE_CHECKING:
    from collections.abc import Callable

import logging

logger = logging.getLogger(__name__)


class ThrottleStateDisplay:
    """Throttle state of a monitoring unit used for display."""

    _instances: dict[ThrottleState, "ThrottleStateDisplay"] = {}

    def __init__(
        self, value: int, name: str, description: str, icon: str, color: str
    ) -> None:
        """Create a new instance of the throttle state."""
        self.value = value
        self.name = name
        self.description = description
        self.icon = icon
        self.color = color

    @classmethod
    def register(cls, value: int, description: str, icon: str, color: str) -> None:
        """Register a new display type."""
        state = ThrottleState(value)
        assert state.name is not None
        cls._instances[state] = cls(state.value, state.name, description, icon, color)

    @classmethod
    def from_state(cls, state: ThrottleState) -> "ThrottleStateDisplay":
        """Return the state that should be displayed.

        Returns the highest priority (value) state that is present in the current flags.
        """
        result = ThrottleState.SAFE
        for option in ThrottleState:
            if option in state and (state.value > result.value):
                result = option
        return cls._instances[result]


ThrottleStateDisplay.register(0, "System is healthy.", "🟢", "black")
ThrottleStateDisplay.register(
    1,
    "System is close to being throttled.",
    "🟠",
    "orange",
)
ThrottleStateDisplay.register(2, "System is throttled.", "🔴", "red")


class MonitoringUnitState(JuiceTopicMonitorConfig):
    """Current state of a monitoring unit."""

    state: ThrottleState
    value: Any

    def format(self, value: Any) -> str | None:  # noqa: ANN401
        """Format the value for display using the unit."""
        if value is None:
            return None
        quantity = Quantity(value, self.unit)
        try:
            try:
                return f"{quantity:.3g~#P}"
            except ValueError:
                # Cannot format using 'g', so we let python decide.
                return f"{quantity:~#P}"
        except pint.errors.OffsetUnitCalculusError:
            # Use a method that does not require multiplication or division
            try:
                return f"{quantity:.3g~P}"
            except ValueError:
                return f"{quantity:~P}"


class SystemThrottleStateDisplay:
    """Display overall system throttle state."""

    def __init__(self) -> None:
        self.warning = Div(
            text="Loading throttle state...", styles={"font-size": "1.5em"}
        )
        self.icon = Div(
            text=ThrottleStateDisplay.from_state(ThrottleState.WARNING).icon,
            styles={
                "padding-left": "10px",
                "font-size": "1.5em",
                "align-content": "center",
            },
        )

        self.root = row(self.icon, self.warning)

        self.subscriber_task = subscribe_to_events_task(
            doc=curdoc(),
            subscriptions=[(ThrottleStateEvent, "throttle_state.SYSTEM")],
            handler=self._update_event_handler,
        )

    async def start(self) -> None:
        """Start the widget by performing an initial update."""
        ret = await ThrottleStateEvent.query_async(
            bucket="task-manager",
            query_api=influxdb2_query_api_async(),
            filters={"id": "SYSTEM"},
            limit=1,
            start="-30s",
            sort="desc",
        )
        if ret:
            curdoc().add_next_tick_callback(
                lambda: self._update_warning(ret[0].throttled)
            )

    def _update_event_handler(self, event: ThrottleStateEvent) -> None:
        logger.debug(
            f"Handling SystemThrottleEvent with throttle state {event.throttled}."
        )
        self._update_warning(event.throttled)

    def _update_warning(self, state: ThrottleState) -> None:
        """Update the warning text and icon based on the throttle state."""
        formatted_state = ThrottleStateDisplay.from_state(state)
        self.warning.text = formatted_state.description
        self.icon.text = formatted_state.icon


class ParameterMonitorWidget(DataTableWidget):
    """Parameter Monitor and Throttling Display Widget."""

    def __init__(self) -> None:
        logger.info("Initializing ParameterMonitorWidget.")
        self._cfg = ParameterMonitorConfig.load()
        self._query_api = influxdb2_query_api_async()

        logger.debug(self._cfg)
        super().__init__(
            column_display_names={
                "state": "State",
                "value": "Value",
                "stop_throttle_if_smaller": "Safe Threshold",
                "throttle_if_larger": "Throttle Threshold",
            },
            row_names=[
                item.display_label
                for item in self._cfg.juice_topic_monitoring_units.values()
            ],
            row_names_column_name="Parameter",
            column_names=[
                "state",
                "value",
                "stop_throttle_if_smaller",
                "throttle_if_larger",
            ],
            data_table_opts={"index_position": None, "autosize_mode": "fit_columns"},
        )

        self._formatters: dict[
            str, Callable[[MonitoringUnitState, Any], str | None]
        ] = {
            "value": lambda state, value: state.format(value),
            "stop_throttle_if_smaller": lambda state, value: state.format(value),
            "throttle_if_larger": lambda state, value: state.format(value),
        }

        self.subscriber_task = subscribe_to_events_task(
            doc=curdoc(),
            subscriptions=[(ThrottleStateEvent, "throttle_state")],
            handler=self._update_event_handler,
        )

    async def start(self) -> None:
        """Start the widget by performing an initial update."""
        logger.info("Starting ParameterMonitorWidget with initial update.")
        pass

    @override
    async def _update(self) -> None:
        """Update the compressor widget data.

        We are using pubsub instead of periodic updates so this method is not used.
        """
        pass

    def update(self) -> None:
        """Update the compressor widget data."""
        pass

    def _update_event_handler(self, event: ThrottleStateEvent) -> None:
        logger.debug(
            f"Handling ThrottleStateEvent for unit {event.id} with value {event.value}"
            f" and throttle state {event.throttled}."
        )
        unit_state = self._build_monitoring_unit_state(event)
        if unit_state:
            self._update_table(unit_state)

    def _update_table(self, state: MonitoringUnitState) -> None:
        """Update the data table with the new state."""
        formatted_state = ThrottleStateDisplay.from_state(state.state)
        formatted_value = state.format(state.value)
        formatted_stop_throttle_if_smaller = state.format(
            state.stop_throttle_if_smaller
        )
        formatted_throttle_if_larger = state.format(state.throttle_if_larger)

        idx = self._data.index[self._data["Parameter"] == state.display_label][0]

        self._data.loc[idx, "State"] = f"{formatted_state.icon} {formatted_state.name}"
        self._data.loc[idx, "Value"] = formatted_value
        self._data.loc[idx, "Safe Threshold"] = formatted_stop_throttle_if_smaller
        self._data.loc[idx, "Throttle Threshold"] = formatted_throttle_if_larger
        self.param.trigger("_data")

    def _build_monitoring_unit_state(
        self, event: ThrottleStateEvent
    ) -> MonitoringUnitState | None:
        """Build the monitoring unit state from the event."""
        config = next(
            (
                config
                for id, config in self._cfg.juice_topic_monitoring_units.items()
                if id == event.id
            ),
            None,
        )
        if not config:
            logger.warning(
                f"No configuration found for monitoring unit with id {event.id}"
            )
            return None
        return MonitoringUnitState(
            display_label=config.display_label,
            monitored_event_type=config.monitored_event_type,
            monitored_field=config.monitored_field,
            monitored_topic=config.monitored_topic,
            unit=config.unit,
            throttle_if_larger=config.throttle_if_larger,
            stop_throttle_if_smaller=config.stop_throttle_if_smaller,
            state=event.throttled,
            value=event.value,
        )
