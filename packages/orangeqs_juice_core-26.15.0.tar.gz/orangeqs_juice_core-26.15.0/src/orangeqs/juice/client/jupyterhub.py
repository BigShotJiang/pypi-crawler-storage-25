"""Module to list active users from the JupyterHub API."""

import os

import requests

from orangeqs.juice.schemas.jupyterhub import ActiveUser


def list_active_users() -> list[ActiveUser]:
    """List all active users from the JupyterHub API.

    Requires the JUPYTERHUB_API_TOKEN and JUPYTERHUB_API_URL
    environment variables to be set.

    Returns
    -------
        A list of usernames for active users (users with running servers).
    """
    api_token = os.environ.get("JUPYTERHUB_API_TOKEN")
    api_url = os.environ.get("JUPYTERHUB_API_URL")
    if not api_token or not api_url:
        raise RuntimeError(
            "JUPYTERHUB_API_TOKEN and JUPYTERHUB_API_URL must be set in the env. "
            "You are probably not running this code in the singleuser container."
        )

    headers = {"Authorization": f"token {api_token}"}
    response = requests.get(f"{api_url}/users?state=active", headers=headers)
    response.raise_for_status()
    users = response.json()
    # Filter for active users (with running servers)
    active_users = [
        ActiveUser.model_validate(user) for user in users
    ]  # servers dict is non-empty if user has running server
    return active_users
