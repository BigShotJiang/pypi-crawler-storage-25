"""Parameter monitor and throttle module."""

from __future__ import annotations

import asyncio
import importlib
import itertools
import logging
import time
from abc import abstractmethod
from typing import TYPE_CHECKING, Any, Generic, TypeVar

from orangeqs.juice import Client
from orangeqs.juice._util import rerun_on_exception
from orangeqs.juice.client import influxdb2
from orangeqs.juice.client.pubsub import publish_event
from orangeqs.juice.schemas.parameter_monitor import (
    JuiceTopicMonitorConfig,
    ParameterMonitorConfig,
    ThrottleState,
    ThrottleStateEvent,
)
from orangeqs.juice.types import Comparable

if TYPE_CHECKING:
    from collections.abc import Iterable

    import pandas as pd

logger = logging.getLogger(__name__)


ComparableT = TypeVar("ComparableT", bound=Comparable)


class ParameterMonitorUnit(Generic[ComparableT]):
    """Monitoring unit that can signal the system to enter throttled state.

    This class only specifies the generic logic for monitoring a value
    Inherit from this class to implement a monitoring unit for a specific data
    source/type. See class`{JuiceTopicMonitor}` for an example implementation.
    """

    def __init__(
        self,
        id: str,
        cfg: JuiceTopicMonitorConfig,
    ) -> None:
        self._id = id
        self._stop_throttle_if_smaller = cfg.stop_throttle_if_smaller
        self._stop_throttle_grace_interval = cfg.stop_throttle_grace_interval
        self._throttle_if_larger = cfg.throttle_if_larger
        self._throttle_grace_interval = cfg.throttle_grace_interval
        self._warn_if_larger = cfg.warn_if_larger
        self._last_value: Any | None = None
        # To allow exit of the throttle state straight away
        self._safe_start_time: float | None = 0.0
        self._above_bounds_start_time: float | None = None
        # Default state is throttled, because before first update
        self._state: ThrottleState = (
            ThrottleState.THROTTLED
            if self._throttle_if_larger is not None
            else ThrottleState.SAFE
        )

    def update_with_value(self, new_value: ComparableT | None) -> None:
        """Update throttle state based on new value.

        Warning: the value must be serializable by Pydantic
        """
        if self._throttle_if_larger is not None and (
            new_value is None or new_value >= self._throttle_if_larger
        ):
            if self._safe_start_time is not None:
                self._safe_start_time = None
            now = time.time()
            if self._above_bounds_start_time is None:
                logger.warning(
                    f"Monitoring unit {self._id}: value is too high, system enters "
                    f"throttled state in {self._throttle_grace_interval} seconds"
                )
                self._above_bounds_start_time = now
            if now - self._above_bounds_start_time >= self._throttle_grace_interval:
                # Set the throttle flag
                self._state |= ThrottleState.THROTTLED
        elif self._stop_throttle_if_smaller is not None and (
            new_value is not None and new_value < self._stop_throttle_if_smaller
        ):
            if self._above_bounds_start_time is not None:
                self._above_bounds_start_time = None
            now = time.time()
            if self._safe_start_time is None:
                self._safe_start_time = now
                logger.info(
                    f"Monitoring unit {self._id}: value is safe, system exits throttle "
                    f"state in {self._stop_throttle_grace_interval} seconds."
                )
            if now - self._safe_start_time >= self._stop_throttle_grace_interval:
                # Clear the throttle flag
                self._state &= ~ThrottleState.THROTTLED
        else:
            if self._above_bounds_start_time is not None:
                self._above_bounds_start_time = None
            if self._safe_start_time is not None:
                self._safe_start_time = None
        if self._warn_if_larger is not None and (
            new_value is None or new_value >= self._warn_if_larger
        ):
            # Set the warning flag
            self._state |= ThrottleState.WARNING
        elif self._warn_if_larger is not None and (
            new_value is not None and new_value < self._warn_if_larger
        ):
            # Clear the warning flag
            self._state &= ~ThrottleState.WARNING

        self._last_value = new_value
        logger.debug(f"THROTTLE: {self.state}")

    @property
    def state(self) -> bool:
        """Throttle State."""
        return ThrottleState.THROTTLED in self._state

    @property
    def full_state(self) -> ThrottleStateEvent:
        """Metadata of the throttle unit."""
        return ThrottleStateEvent(
            id=self._id,
            throttled=self._state,
            value=self._last_value,
        )


class ParameterMonitorUnitManager:
    """ParameterMonitor unit managing multiple child ParameterMonitor units.

    Additionally, it can have child ParameterMonitor unit managers.
    """

    def children(self) -> Iterable[ParameterMonitorUnitManager]:
        """List of child ParameterMonitor unit managers."""
        return []

    def units(self) -> Iterable[ParameterMonitorUnit[Comparable]]:
        """List of ParameterMonitor units managed by this manager."""
        return []

    @property
    def state(self) -> bool:
        """Whether any units in this manager are throttled."""
        return any(
            child.state for child in itertools.chain(self.units(), self.children())
        )

    @property
    def full_states(self) -> Iterable[ThrottleStateEvent]:
        """Full states of all descendant monitoring units."""
        return itertools.chain(
            (unit.full_state for unit in self.units()),
            *(manager.full_states for manager in self.children()),
        )

    @abstractmethod
    async def update(self) -> None:
        """Update throttle state of children.

        This method should update both all child monitoring unit managers and
        the monitoring units managed by this unit.
        """
        pass


class JuiceTopicMonitor(ParameterMonitorUnitManager):
    """Parameter Monitor Manager to manage fields of a Juice Topic."""

    def __init__(self, *, id: str, config: JuiceTopicMonitorConfig) -> None:
        self._cfg = config
        self.monitoring_unit: ParameterMonitorUnit[Comparable] = ParameterMonitorUnit(
            id=id,
            cfg=config,
        )
        self._juice_client: Client = Client()

        module_path, _, class_name = self._cfg.monitored_event_type.rpartition(".")
        module = importlib.import_module(module_path)
        event_class = getattr(module, class_name)

        self._subscriber = self._juice_client.subscriber_async()
        self._subscriber.subscribe(event_class, topic=self._cfg.monitored_topic)

        self._last_received_value = None
        self._event_expiration_window = 5.0  # FIXME: Make this configurable?

        logger.debug(
            f"Subscribed to {event_class} on topic {self._cfg.monitored_topic}"
        )

    async def update(self) -> None:
        last_event = None
        last_event_time = None
        while True:
            try:
                event = await self._subscriber.get(timeout=0.1)  # Flush queue
                last_event = event
                last_event_timestamp: pd.Timestamp = event.time
                last_event_time = last_event_timestamp.timestamp()
            except asyncio.TimeoutError:
                break
        if last_event is not None and last_event_time is not None:
            now = time.time()
            # If the event is recent enough, use it; otherwise, set to inf
            last_message_is_too_old = (
                now - last_event_time > self._event_expiration_window
            )
            message_has_configured_field = hasattr(
                last_event, self._cfg.monitored_field
            )

            if message_has_configured_field and not last_message_is_too_old:
                value = getattr(last_event, self._cfg.monitored_field)
                self._last_received_value = value
            elif not message_has_configured_field:
                logger.warning(
                    f"Event of type {type(last_event).__name__} does  "
                    f"not have field '{self._cfg.monitored_field}'. "
                    f"Marking as throttled."
                )
                self._last_received_value = None
            elif last_message_is_too_old:
                logger.warning(
                    f"Last event for {self._cfg.monitored_event_type} on topic"
                    f" {self._cfg.monitored_topic} older than "
                    f"{self._event_expiration_window}"
                    f" seconds. Unit will throttle after grace interval."
                )
                self._last_received_value = None
        else:
            logger.warning(
                f"No events received for {self._cfg.monitored_event_type} on "
                f"topic {self._cfg.monitored_topic}. Unit will throttle after"
                f" grace interval."
            )
            self._last_received_value = None

        if self._last_received_value is not None:
            self.monitoring_unit.update_with_value(self._last_received_value)
        else:
            logger.warning(
                f"Monitoring unit {self._cfg.display_label} did not receive any"
                " value. Unit will throttle after grace interval."
            )
            self.monitoring_unit.update_with_value(None)

    def units(self) -> Iterable[ParameterMonitorUnit[Comparable]]:
        """Children monitoring units."""
        return [self.monitoring_unit]


class SystemParameterMonitor(ParameterMonitorUnitManager):
    """Monitor multiple monitoring units and notify when throttling is required.

    Reads the configuration and initializes the monitoring units based on it.
    On every update, it will write the current throttle state to the database,
    including the invidual states of all monitoring units.
    """

    def __init__(self, *, config: ParameterMonitorConfig) -> None:
        self.juice_topic_monitors: dict[str, JuiceTopicMonitor] = {
            _id: JuiceTopicMonitor(id=_id, config=cfg)
            for _id, cfg in config.juice_topic_monitoring_units.items()
        }
        self._bucket = "task-manager"  # FIXME: Make this configurable?

        self._last_throttle_state: bool = False
        if not self.juice_topic_monitors:
            logger.warning(
                "System throttling is enabled, but there are no throttling units "
                "available."
            )
        self._juice_client: Client = Client()

        self._publisher = self._juice_client.publisher_async()

        ## This should not really be a JuiceTopicMonitor, but it is a convenient way to
        ## reuse the logic for monitoring and publishing the throttle state
        self._heartbeat_unit = ParameterMonitorUnit[Comparable](
            id="heartbeat",
            cfg=JuiceTopicMonitorConfig(
                display_label="System Throttle Heartbeat",
                monitored_event_type="orangeqs.juice.schemas.parameter_monitor.ThrottleStateEvent",
                monitored_field="throttled",
                monitored_topic="dummy_topic",
            ),
        )
        self._heartbeat_unit.update_with_value(1)

    async def init_async(self) -> None:
        """Initialize the children and perform an update."""
        self._write_api = influxdb2.influxdb2_write_api_async()
        await asyncio.gather(
            *[monitor.update() for monitor in self.juice_topic_monitors.values()],
            self.run(),
        )

    @rerun_on_exception
    async def run(self) -> None:
        """Run the System Parameter Monitor.

        This runs a loop that updates state and publishers at regular intervals
        """
        while True:
            start = asyncio.get_event_loop().time()

            await self.update()

            elapsed = asyncio.get_event_loop().time() - start
            await asyncio.sleep(max(0, 5.0 - elapsed))

    async def _update_state(self, timeout: float | None = None) -> bool:
        """Update throttle state."""
        if len(self.juice_topic_monitors) == 0:
            return True

        _ = await asyncio.gather(*(component.update() for component in self.children()))
        if self.state != self._last_throttle_state:
            if self._last_throttle_state is False:
                logger.warning("System entered throttled state.")
            else:
                logger.warning("System exited throttled state.")

        self._last_throttle_state = self.state
        return True

    async def update(self) -> None:
        """Update state and store in the configured database."""
        success = await self._update_state()
        if success:
            state_event = self.system_throttle_state
            messages = self.full_states
            tasks: list[asyncio.Task[None]] = [
                asyncio.create_task(
                    publish_event(
                        event=message,
                        publisher=self._publisher,
                        write_api=self._write_api,
                        bucket=self._bucket,
                    )
                )
                for message in messages
            ]
            tasks.append(
                asyncio.create_task(
                    publish_event(
                        event=state_event,
                        publisher=self._publisher,
                        write_api=self._write_api,
                        bucket=self._bucket,
                    )
                )
            )
            await asyncio.gather(*tasks)
        else:
            logger.error("Failed to update system throttling state.")

    def children(self) -> Iterable[ParameterMonitorUnitManager]:
        """Child monitoring unit managers."""
        return self.juice_topic_monitors.values()

    def units(self) -> Iterable[ParameterMonitorUnit[Comparable]]:
        """Child monitoring units."""
        return [self._heartbeat_unit]

    @property
    def system_throttle_state(self) -> ThrottleStateEvent:
        """Return the current system throttle state."""
        system_state_value = max(
            (event.throttled.value for event in self.full_states),
            default=ThrottleState.SAFE.value,
        )
        return ThrottleStateEvent(
            id="SYSTEM",
            throttled=ThrottleState(system_state_value),
            value=None,
        )
