"""Republish Telegraf events to other Juice services."""

import asyncio
import logging
import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from orangeqs.juice.client.influxdb2 import influxdb2_query_api_async
from orangeqs.juice.client.pubsub import publisher_async
from orangeqs.juice.orchestration.settings import OrchestrationSettings

from .schemas import (
    PodmanStatsEvent,
    TelegrafCpuEvent,
    TelegrafDiskEvent,
    TelegrafDiskIoEvent,
    TelegrafMemEvent,
    TelegrafProcessesEvent,
    TelegrafSwapEvent,
    TelegrafSystemdUnitsEvent,
    TelegrafSystemEvent,
)

if TYPE_CHECKING:
    from orangeqs.juice.messaging.protocol import Event

_TELEGRAPH_BUCKET = OrchestrationSettings.load().telegraf.influxdb2_bucket
_UPDATE_INTERVAL_SECONDS = 5.0
_NANOSECONDS_TO_SECONDS = 1_000_000_000

_logger = logging.getLogger(__name__)


async def publish_telegraf() -> None:
    """Query Telegraf events and publish them to other Juice services."""
    api = influxdb2_query_api_async()
    publisher = publisher_async()
    event_classes = [
        TelegrafCpuEvent,
        TelegrafDiskEvent,
        TelegrafDiskIoEvent,
        TelegrafMemEvent,
        TelegrafProcessesEvent,
        TelegrafSwapEvent,
        TelegrafSystemdUnitsEvent,
        TelegrafSystemEvent,
        PodmanStatsEvent,
    ]

    last_timestamps = {event_cls: "-15s" for event_cls in event_classes}

    while True:
        start_time = time.monotonic()
        events: list[Event] = []
        try:
            for event_cls in event_classes:
                current_events = await event_cls.query_async(
                    api,
                    start=last_timestamps[event_cls],
                    bucket=_TELEGRAPH_BUCKET,
                    output="list",
                )

                if current_events:
                    current_events.sort(key=lambda e: e.time)
                    # Setting timestamp exactly to the last event's time ensures
                    # That we always get atleast one event
                    last_timestamps[event_cls] = (
                        f"time(v: "
                        f"""{
                            int(
                                current_events[-1].time.timestamp()
                                * _NANOSECONDS_TO_SECONDS
                            )
                        })"""
                    )
                else:
                    _logger.warning(
                        f"No events found for {event_cls.__name__} \
                          since {last_timestamps[event_cls]}"
                    )
                events.extend(current_events)
            for e in events:
                # Default time generator of the Point class
                e.time = datetime.now(timezone.utc)

            await asyncio.gather(*(publisher.publish(event) for event in events))
        except Exception as e:
            _logger.error(f"Error in Telegraf republishing loop: {e}")
        elapsed = time.monotonic() - start_time
        sleep_time = max(0, _UPDATE_INTERVAL_SECONDS - elapsed)
        await asyncio.sleep(sleep_time)
