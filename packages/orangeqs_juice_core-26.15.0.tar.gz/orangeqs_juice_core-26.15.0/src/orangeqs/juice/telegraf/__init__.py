"""Telegraf integration for Juice."""

from .publisher import publish_telegraf
from .schemas import (
    PodmanStatsEvent,
    TelegrafCpuEvent,
    TelegrafDiskEvent,
    TelegrafDiskIoEvent,
    TelegrafMemEvent,
    TelegrafProcessesEvent,
    TelegrafSwapEvent,
    TelegrafSystemdUnitsEvent,
    TelegrafSystemEvent,
)

__all__ = [
    "publish_telegraf",
    "TelegrafCpuEvent",
    "TelegrafDiskEvent",
    "TelegrafDiskIoEvent",
    "TelegrafMemEvent",
    "TelegrafProcessesEvent",
    "TelegrafSwapEvent",
    "TelegrafSystemEvent",
    "TelegrafSystemdUnitsEvent",
    "PodmanStatsEvent",
]
