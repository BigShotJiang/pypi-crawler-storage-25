"""Pydantic schemas for Telegraf-written InfluxDB measurements.

These schemas mirror the measurements configured in
`orangeqs/juice/orchestration/templates/telegraf.conf.j2`.

They are intended for querying Telegraf data via `orangeqs.juice.database.Event`.
Only a stable subset of common Telegraf fields/tags is modeled; InfluxDB columns
not present in a schema are dropped automatically by `Event.query()` / `query_async()`.
"""

from __future__ import annotations

from typing import Annotated, ClassVar

from pydantic import Field
from pydantic.fields import FieldInfo

from orangeqs.juice.messaging.protocol import Event


class TelegrafCpuEvent(Event):
    """Telegraf `inputs.cpu` measurement."""

    measurement: ClassVar[str] = "cpu"

    cpu: Annotated[str, "tag"] = ""

    usage_idle: float = 0.0
    usage_user: float = 0.0
    usage_system: float = 0.0
    usage_iowait: float = 0.0
    usage_irq: float = 0.0
    usage_softirq: float = 0.0
    usage_nice: float = 0.0
    usage_guest: float = 0.0
    usage_steal: float = 0.0

    def topic(self) -> str:
        """Return the topic `cpu`."""
        return "cpu"


class TelegrafDiskEvent(Event):
    """Telegraf `inputs.disk` measurement."""

    measurement: ClassVar[str] = "disk"

    path: Annotated[str, "tag"] = ""

    total: int = 0
    free: int = 0
    used: int = 0
    used_percent: float = 0.0

    inodes_total: int = 0
    inodes_free: int = 0
    inodes_used: int = 0

    def topic(self) -> str:
        """Return the topic `disk`."""
        return "disk"


class TelegrafDiskIoEvent(Event):
    """Telegraf `inputs.diskio` measurement."""

    measurement: ClassVar[str] = "diskio"

    reads: int = 0
    writes: int = 0
    read_bytes: int = 0
    write_bytes: int = 0
    read_time: int = 0
    write_time: int = 0
    io_time: int = 0
    weighted_io_time: int = 0
    iops_in_progress: int = 0

    def topic(self) -> str:
        """Return the topic `diskio`."""
        return "diskio"


class TelegrafMemEvent(Event):
    """Telegraf `inputs.mem` measurement."""

    measurement: ClassVar[str] = "mem"

    total: int = 0
    free: int = 0
    used: int = 0
    used_percent: float = 0.0

    available: int = 0
    available_percent: float = 0.0

    buffers: int = 0
    cached: int = 0
    shared: int = 0

    # Telegraf commonly reports swap_* in the mem measurement as well.
    # (And the dashboard queries these fields from measurement "mem".)
    swap_total: int = 0
    swap_free: int = 0

    def topic(self) -> str:
        """Return the topic `mem`."""
        return "mem"


class TelegrafProcessesEvent(Event):
    """Telegraf `inputs.processes` measurement."""

    measurement: ClassVar[str] = "processes"

    total: int = 0
    running: int = 0
    sleeping: int = 0
    stopped: int = 0
    zombies: int = 0
    dead: int = 0
    paging: int = 0
    blocked: int = 0
    unknown: int = 0

    def topic(self) -> str:
        """Return the topic `processes`."""
        return "processes"


class TelegrafSwapEvent(Event):
    """Telegraf `inputs.swap` measurement."""

    measurement: ClassVar[str] = "swap"

    total: int = 0
    used: int = 0
    free: int = 0
    used_percent: float = 0.0
    free_percent: float = 0.0

    def topic(self) -> str:
        """Return the topic `swap`."""
        return "swap"


class TelegrafSystemEvent(Event):
    """Telegraf `inputs.system` measurement."""

    measurement: ClassVar[str] = "system"

    load1: float = 0.0
    load5: float = 0.0
    load15: float = 0.0
    n_users: int = 0
    n_cpus: int = 0
    uptime: int = 0
    host: str = ""

    def topic(self) -> str:
        """Return the topic `system`."""
        return "system"


class TelegrafSystemdUnitsEvent(Event):
    """Telegraf `inputs.systemd_units` measurement (units matching `pattern`)."""

    measurement: ClassVar[str] = "systemd_units"

    load: str = ""
    active: str = ""
    sub: str = ""

    def topic(self) -> str:
        """Return the topic `systemd_units`."""
        return "systemd_units"


class PodmanStatsEvent(Event):
    """Telegraf `inputs.exec` (`podman stats`) measurement."""

    def __getitem__(self, key: str) -> float | str:
        """Allow dict-like access to fields for easier DataFrame construction."""
        return getattr(self, key)

    measurement: ClassVar[str] = "podman_stats"

    cpu_percent: float = 0.0
    mem_percent: float = 0.0
    mem_usage: str = ""
    block_io: str = ""
    cpu_time: str = ""
    id: str = ""
    net_io: str = ""
    pids: int = 0
    db_name: Annotated[str, "tag"] = Field(alias="name", default="")

    def topic(self) -> str:
        """Return the topic `podman_stats`."""
        return "podman_stats"


model_fn = PodmanStatsEvent.model_fields
PodmanStatsEvent.model_fields = model_fn | {
    "name": FieldInfo(annotation=str, default_factory=None)
}  # type: ignore
