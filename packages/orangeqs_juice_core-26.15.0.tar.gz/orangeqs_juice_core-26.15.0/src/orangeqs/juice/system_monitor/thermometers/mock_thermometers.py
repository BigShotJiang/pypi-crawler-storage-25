"""Mock implementations of system monitoring heater."""

import asyncio

import numpy as np

from orangeqs.juice.system_monitor.data_structures import TemperaturePoint
from orangeqs.juice.system_monitor.mock_settings import MockThermometrySettings


class MockThermometry:
    """Mock class for Thermometry unit."""

    def __init__(self, thermometry_config: MockThermometrySettings) -> None:
        """Initialize the Thermometers mock."""
        self._thermometers_config = thermometry_config
        self._temperatures: dict[str, float] = {
            thermometer_id: settings.mock_temperature
            for thermometer_id, settings in thermometry_config.thermometers.items()
        }

    @property
    def temperatures(self) -> list[TemperaturePoint]:
        """Return the temperature measurements."""
        return [
            TemperaturePoint(
                sensor_id=sensor_id,
                component_id=self._thermometers_config.component_id,
                temperature=temp,
                level=self._thermometers_config.thermometers[sensor_id].level,
            )
            for sensor_id, temp in self._temperatures.items()
        ]

    async def update(self) -> bool:
        """Update the temperatures with some random noise."""
        for sensor_id in self._temperatures:
            center_temp = self._thermometers_config.thermometers[
                sensor_id
            ].mock_temperature
            current_temp = self._temperatures[sensor_id]
            random_sample = np.random.normal(center_temp, center_temp * 0.05)
            # Filter to simulate gradual changes
            self._temperatures[sensor_id] = 0.9 * current_temp + 0.1 * random_sample
        return True


async def mock_sample_heatup(
    thermo: MockThermometry,
    targets: dict[str, float],
    duration: float = 10.0,
    wait_duration: float = 10,
    interval: float = 0.1,
) -> bool:
    """
    Gradually ramp the temperatures to the target values over the specified duration.

    Then waits for a specified duration at the target temperatures,
    adding some random noise to simulate real conditions.
    """
    steps = int(duration / (interval))
    wait_steps = int(wait_duration / (interval))
    start = {sid: thermo._temperatures[sid] for sid in targets}  # pyright: ignore[reportPrivateUsage]
    deltas = {sid: (targets[sid] - start[sid]) / steps for sid in targets}

    # ramp linearly
    for i in range(steps):
        for sid, delta in deltas.items():
            thermo._temperatures[sid] = start[sid] + i * delta  # pyright: ignore[reportPrivateUsage]
        await asyncio.sleep(interval)

    # Wait at the target temperature
    for _ in range(wait_steps):
        for sid, delta in deltas.items():
            random_sample = np.random.normal(0, thermo._temperatures[sid] * 0.05)  # pyright: ignore[reportPrivateUsage]
            thermo._temperatures[sid] = targets[sid] + +random_sample  # pyright: ignore[reportPrivateUsage]
        await asyncio.sleep(interval)

    return True
