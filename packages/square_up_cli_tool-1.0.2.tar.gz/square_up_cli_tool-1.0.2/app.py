import streamlit as st
import os
import tempfile
from PIL import Image
from image_processor import process_image

st.set_page_config(page_title="Image Rotator & Cropper", layout="wide", page_icon="📸")

st.title("📸 Image Rotator & Cropper")
st.markdown("Easily process scanned documents or photographs. Upload an image, choose a cropping mode, and either let Auto-Deskew fix the alignment or adjust it manually!")

# Sidebar styling
st.sidebar.title("Configuration")
st.sidebar.markdown("Use these options to configure exactly how your image is processed.")

rotation_type = st.sidebar.radio(
    "Rotation Mode", 
    ["Auto-Deskew", "Manual Rotation"],
    help="Auto-Deskew detects text layout angle. Manual lets you slide to your perfect angle."
)

rotation_angle = 0.0
if rotation_type == "Manual Rotation":
    rotation_angle = st.sidebar.slider("Rotation Angle (Degrees)", -180.0, 180.0, 0.0, step=0.5)
    
crop_mode = st.sidebar.selectbox(
    "Cropping Mode", 
    ["close", "flush"], 
    format_func=lambda x: "Close (leaves a tiny sliver of scanner bed)" if x == "close" else "Flush (crops INSIDE the shape to remove all background)",
    help="How closely should we crop to the detected content block?"
)

uploaded_file = st.file_uploader("Drag and drop your image (JPG, PNG, TIFF, WEBP, HEIC)", type=['jpg', 'jpeg', 'png', 'tiff', 'webp', 'heic'])

if uploaded_file is not None:
    # Build columns for preview
    col_input, col_output = st.columns(2)
    
    with col_input:
        st.subheader("Original Preview")
        st.image(uploaded_file, use_container_width=True)
        
    process_btn = st.sidebar.button("Process Image", type="primary", use_container_width=True)
    
    if process_btn:
        with st.spinner("Processing..."):
            # Write uploaded buffer to a named temp file
            ext = uploaded_file.name.split('.')[-1]
            with tempfile.NamedTemporaryFile(delete=False, suffix=f".{ext}") as tmp_in:
                tmp_in.write(uploaded_file.getbuffer())
                input_path = tmp_in.name
                
            output_path = input_path + "_processed.jpg"
            auto_deskew = (rotation_type == "Auto-Deskew")
            
            # Process using our core logic
            res_path = process_image(
                input_path=input_path,
                output_path=output_path,
                rotation_angle=rotation_angle,
                auto_deskew=auto_deskew,
                crop_mode=crop_mode
            )
            
            if res_path and os.path.exists(res_path):
                with col_output:
                    st.subheader("Processed Result")
                    result_img = Image.open(res_path)
                    st.image(result_img, use_container_width=True)
                    
                    with open(res_path, "rb") as file:
                        st.download_button(
                            label="⬇️ Download Processed Image",
                            data=file,
                            file_name=f"processed_{uploaded_file.name}.jpg",
                            mime="image/jpeg",
                            use_container_width=True,
                            type="primary"
                        )
            else:
                st.error("Failed to process image. Make sure the content has distinct elements that can be thresholded or provide a different cropping mode.")
                
            # Clean up temp files
            try:
                os.remove(input_path)
                if os.path.exists(output_path):
                    os.remove(output_path)
            except:
                pass
