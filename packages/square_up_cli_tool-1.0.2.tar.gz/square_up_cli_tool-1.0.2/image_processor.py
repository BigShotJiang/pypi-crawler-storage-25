import argparse
import os
import cv2
import numpy as np
from PIL import Image
from pillow_heif import register_heif_opener

# Register HEIF opener for Pillow to handle HEIC files automatically
register_heif_opener()

def get_object_mask(image_cv):
    """
    Finds the largest distinct object against a flatbed background using dynamic Canny edge detection.
    """
    gray = cv2.cvtColor(image_cv, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (7, 7), 0)
    
    # Use Otsu's thresholding to dynamically find optimal Canny thresholds
    val, _ = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    lower = int(max(0, 0.5 * val))
    upper = int(min(255, 1.5 * val))
    edges = cv2.Canny(blurred, lower, upper)
    
    # Thicken edges and close shapes to form a solid blob
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
    dilated = cv2.dilate(edges, kernel, iterations=3)
    closed = cv2.morphologyEx(dilated, cv2.MORPH_CLOSE, kernel, iterations=2)
    
    contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
        
    # Sort contours by area descending to find the largest object
    contours = sorted(contours, key=cv2.contourArea, reverse=True)
    return contours[0]

def get_deskew_angle(image_cv):
    """
    Computes pure geometric angle to orthogonally align the detected bounding box.
    """
    contour = get_object_mask(image_cv)
    if contour is None or cv2.contourArea(contour) < 500:
        return 0.0
        
    rect = cv2.minAreaRect(contour)
    box = cv2.boxPoints(rect)
    
    # Calculate angles for all 4 edges
    edges_angles = []
    for i in range(4):
        p1 = box[i]
        p2 = box[(i+1)%4]
        dx = p2[0] - p1[0]
        dy = p2[1] - p1[1]
        
        # Skip zero length edges just in case
        if dx == 0 and dy == 0:
            continue
            
        angle_deg = np.degrees(np.arctan2(dy, dx))
        
        # Normalize angle to [-45, 45) range (difference from horizontal/vertical)
        norm_angle = angle_deg % 90
        if norm_angle > 45:
            norm_angle -= 90
            
        edges_angles.append(norm_angle)
        
    # Python median effectively averages the remaining sides, ignoring noise on 1 weird edge
    skew_angle = np.median(edges_angles) if edges_angles else 0.0
    return skew_angle

def rotate_image(image, angle):
    """Rotate PIL image by given angle, seamlessly blending with scanner background."""
    bg = image.getpixel((5, 5))
    if isinstance(bg, int):
        bg = (bg, bg, bg)
    elif len(bg) > 3:
        bg = bg[:3]
        
    return image.rotate(angle, expand=True, resample=Image.Resampling.BICUBIC, fillcolor=bg)

def crop_image(image_cv, crop_mode):
    """
    Finds the deskewed object's boundary and applies exact relative percentage padding.
    """
    contour = get_object_mask(image_cv)
    if contour is None:
        print("[WARNING] No object found to crop. Returning original.")
        return image_cv
        
    x, y, w, h = cv2.boundingRect(contour)
    img_h, img_w = image_cv.shape[:2]
    
    # Safety feature for extremely huge padding
    if w > img_w * 0.98 and h > img_h * 0.98:
         print("[WARNING] Object boundary merges with image boundaries (or is identically sized). Proceeding as-is.")
         return image_cv
    
    if crop_mode == "flush":
        pad_pct = -0.035  # -3.5% (Draws deep enough to eliminate all edge shadows and uneven cuts)
    else:
        pad_pct = 0.015  # 1.5% (Leaves a tiny border)
        
    pad_y = int(h * pad_pct)
    pad_x = int(w * pad_pct)
    
    new_x = max(0, x - pad_x)
    new_y = max(0, y - pad_y)
    new_w = min(img_w - new_x, w + 2 * pad_x)
    new_h = min(img_h - new_y, h + 2 * pad_y)
    
    # Final Crop
    return image_cv[new_y:new_y+new_h, new_x:new_x+new_w]

def process_image(input_path, output_path=None, rotation_angle=None, auto_deskew=False, crop_mode='close'):
    """
    Main pipeline to run rotation, then cropping.
    """
    try:
        if not os.path.exists(input_path):
            raise FileNotFoundError(f"File {input_path} not found.")
            
        pil_img = Image.open(input_path)
        
        # Ensure we have RGB
        if pil_img.mode != "RGB":
            pil_img = pil_img.convert("RGB")
            
        final_angle = 0.0
        
        # Determine rotation
        if auto_deskew:
            cv_img_for_deskew = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)
            final_angle = get_deskew_angle(cv_img_for_deskew)
            print(f"[INFO] Auto-deskew detected skew. Correcting by {final_angle:.2f} degrees")
        elif rotation_angle is not None and rotation_angle != 0.0:
            final_angle = rotation_angle
            print(f"[INFO] Applying manual rotation: {final_angle} degrees")
            
        # Rotate
        if final_angle != 0.0:
            pil_img = rotate_image(pil_img, final_angle)
            
        # Convert to CV2 format for cropping
        cv_img_to_crop = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)
        print(f"[INFO] Cropping image using '{crop_mode}' mode.")
        cropped_cv_img = crop_image(cv_img_to_crop, crop_mode=crop_mode)
        
        # Convert back to PIL for output serialization
        final_pil_img = Image.fromarray(cv2.cvtColor(cropped_cv_img, cv2.COLOR_BGR2RGB))
        
        # Generate target path
        if output_path is None:
            input_dir = os.path.dirname(os.path.abspath(input_path))
            filename = os.path.basename(input_path)
            base, ext = os.path.splitext(filename)
            
            # Standardize exotic types to JPG by default (keeping TIFF uncompressed)
            if ext.lower() in ['.heic', '.webp']:
                ext = '.jpg'
                
            # Automatically route default outputs to a dedicated subfolder
            out_dir = os.path.join(input_dir, "processed_scans")
            os.makedirs(out_dir, exist_ok=True)
            output_path = os.path.join(out_dir, f"{base}_rotated_cropped{ext}")
        else:
            # Ensure user-provided custom directory exists
            out_dir = os.path.dirname(os.path.abspath(output_path))
            if out_dir:
                os.makedirs(out_dir, exist_ok=True)
            
        save_kwargs = {}
        if output_path.lower().endswith(('.jpg', '.jpeg')):
            save_kwargs['quality'] = 95
            
        final_pil_img.save(output_path, **save_kwargs)
        print(f"[SUCCESS] Saved processed image to: {output_path}")
        return output_path
        
    except Exception as e:
        print(f"[ERROR] Process failed for {input_path}: {e}")
        return None

def main():
    parser = argparse.ArgumentParser(description="Image Rotator & Cropper")
    parser.add_argument("--input", "-i", type=str, required=True, help="Path to input image file OR a directory of images.")
    parser.add_argument("--output", "-o", type=str, default=None, help="Path to output file or directory. Appends _rotated_cropped if omitted.")
    parser.add_argument("--rotate", "-r", type=float, default=0.0, help="Manual rotation angle in degrees (positive or negative)")
    parser.add_argument("--auto-deskew", "-a", action="store_true", help="Automatically detect and correct layout skew")
    parser.add_argument("--mode", "-m", choices=["close", "flush"], default="close", help="Crop mode: 'close' (leaves tiny outer border) or 'flush' (cuts slightly inward to eliminate scanner bed completely)")
    
    args = parser.parse_args()
    
    if os.path.isdir(args.input):
        valid_exts = {'.jpg', '.jpeg', '.png', '.tiff', '.tif', '.webp', '.heic'}
        if args.output and not os.path.isdir(args.output):
            os.makedirs(args.output, exist_ok=True)
            
        count = 0
        for f in os.listdir(args.input):
            ext = os.path.splitext(f)[1].lower()
            if ext in valid_exts:
                in_path = os.path.join(args.input, f)
                out_path = None
                
                if args.output:
                    base = os.path.splitext(f)[0]
                    out_ext = ext if ext in ['.tif', '.tiff'] else '.jpg'
                    out_path = os.path.join(args.output, f"{base}_rotated_cropped{out_ext}")
                    
                print(f"\n--- Processing {f} ---")
                process_image(
                    input_path=in_path,
                    output_path=out_path,
                    rotation_angle=args.rotate,
                    auto_deskew=args.auto_deskew,
                    crop_mode=args.mode
                )
                count += 1
        print(f"\n[DONE] Successfully batch-processed {count} images from '{args.input}'!")
    else:
        process_image(
            input_path=args.input,
            output_path=args.output,
            rotation_angle=args.rotate,
            auto_deskew=args.auto_deskew,
            crop_mode=args.mode
        )

if __name__ == "__main__":
    main()
