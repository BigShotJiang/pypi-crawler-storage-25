# Square Up (Image Rotator & Cropper)

A production-ready CLI and Web UI tool for automatically or manually deskewing scanned pages, photographs, postcards, and books. Leverages advanced OpenCV contour detection to dynamically isolate objects from flatbed scanner backgrounds, dropping messy edges gracefully. Natively supports formats including JPG, PNG, TIFF, TIF, HEIC, and WEBP.

## Features
- **Auto-Deskew**: Automatically detects the physical edges of items against a scanner bed to perfectly upright tilted scans using trigonometric geometry. 
- **Manual Rotation**: Manually set precision rotation angles.
- **Smart Cropping**: Professional modes for `close` (leaves a tiny sliver of scanner bed) and `flush` (cuts exactly inside the physical boundary to bleed out all background).
- **Web UI**: Interactive Streamlit app for simple drag-and-drop viewing and processing.
- **Raw Processing**: Processes and outputs `.tif` and `.tiff` formats completely uncompressed.

## Installation (macOS / Linux / Windows)

To install this tool safely on your system without conflicting with global packages, we strongly recommend using a Python Virtual Environment.

**1. Clone or Download the Repository**
Navigate to the directory where you downloaded these files in your terminal:
```bash
cd /path/to/where/you/saved/this
```

**2. Create and Activate a Virtual Environment**
Creating an isolated environment ensures `pip` behaves nicely with your system (especially on newer versions of macOS).
```bash
python3 -m venv venv
source venv/bin/activate
```
*(On Windows, activate using: `venv\Scripts\activate`)*

**3. Install the Tool**
This project uses a standard `pyproject.toml` file. You can install the tool directly into your environment like this:
```bash
pip install -e .
```
This automatically installs all requirements (OpenCV, Streamlit, Pillow, etc.) and registers the custom command `sup` to your terminal.

---

## Usage

### 1. Command Line Interface (`sup` command)
Because you installed the tool via `pip`, you don't need to run messy python scripts. You can just use the short command `sup`!

```bash
# Auto-Deskew and flush cut a vintage postcard to remove the scanner bed completely
sup -i your_postcard.tif --auto-deskew --mode flush

# Auto-Deskew and leave a tiny 1-2% physical border around the object
sup -i scan.jpg --auto-deskew --mode close

# Manual rotation by -10.5 degrees and exact flush crop
sup -i image.heic -r -10.5 --mode flush

# Specify a custom output path
sup -i input.png -o output_dir/fixed.jpg --auto-deskew
```

### 2. Interactive Web UI
If you prefer a visual approach where you can drag and drop your images and use sliders to fix your scans dynamically, start the interactive web app:

```bash
streamlit run app.py
```

This will automatically launch the tool in your web browser!
