**AI_easy** là một thư viện Python mạnh mẽ nhưng đơn giản, được thiết kế để giúp các lập trình viên và học sinh tiếp cận với Machine Learning (ML) và Reinforcement Learning (RL) một cách nhanh chóng nhất.

Thư viện này đóng gói các thuật toán phức tạp từ PyTorch và Scikit-learn thành các lớp (class) dễ sử dụng, phù hợp cho việc học tập, nghiên cứu hoặc giải các bài toán HSG Tin học.

## 🌟 Tính năng chính

* **Machine Learning:** Hỗ trợ Decision Tree, Random Forest và đánh giá mô hình phân loại chuyên sâu.
* **Deep Learning:** Xây dựng mạng Neural đa tầng (MLP) chỉ với vài dòng code.
* **Reinforcement Learning:** * **Q-Learning:** Thuật toán bảng Q cơ bản.
    * **Deep Q-Learning (DQN):** Tích hợp Target Network và Experience Replay giúp AI học chơi game và giải mê cung.
* **Tối ưu phần cứng:** Tự động nhận diện và sử dụng NVIDIA GPU (CUDA) để tăng tốc huấn luyện.

## 📦 Cài đặt

Bạn có thể cài đặt trực tiếp từ PyPI:

```bash
pip install AInotHard