from .aiNothard import (
    machine_learning, 
    deep_learning, 
    Q_Learning, 
    deep_q_learning,
    ainothard
)

__version__ = "1.0.0"
__author__ = "Nguyễn Quốc Đạt"