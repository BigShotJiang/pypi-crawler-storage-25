from setuptools import setup, find_packages

setup(
    name="AInotHard", 
    version="1.1.0",
    author="Nguyễn Quốc Đạt",
    description="support for machine learning, deep learning, Q-Learning, and deep Q-Learning",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "torch",
        "numpy",
        "scikit-learn",
        "joblib",
        "transformers"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)