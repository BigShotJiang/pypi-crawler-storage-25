from .parser import CN_RegionParser

__all__ = ["CN_RegionParser"]