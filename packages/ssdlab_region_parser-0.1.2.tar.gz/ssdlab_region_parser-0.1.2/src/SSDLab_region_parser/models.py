from dataclasses import dataclass, field
import pandas as pd


@dataclass
class CN_RegionParseResult:
    province_name: object = pd.NA
    province_code: object = pd.NA
    city_name: object = pd.NA
    city_code: object = pd.NA
    county_name: object = pd.NA
    county_code: object = pd.NA

    matched_words: list[str] = field(default_factory=list)
    kept_words: list[str] = field(default_factory=list)
    dropped_words: list[str] = field(default_factory=list)
    best_match: object = pd.NA

    def to_dict(self) -> dict:
        return {
            "省级名称": self.province_name,
            "省级代码": self.province_code,
            "城市名称": self.city_name,
            "城市代码": self.city_code,
            "区县名称": self.county_name,
            "区县代码": self.county_code,
            # "matched_words": self.matched_words,
            # "kept_words": self.kept_words,
            # "dropped_words": self.dropped_words,
            # "best_match": self.best_match,
        }
    
    # series
    def to_series(self) -> pd.Series:
        return pd.Series(self.to_dict())

    # tuple
    def to_tuple(self) -> tuple:
        return (
            self.province_name, self.province_code,
            self.city_name, self.city_code,
            self.county_name, self.county_code
        )

    # list
    def to_list(self) -> list:
        return [
            self.province_name, self.province_code,
            self.city_name, self.city_code,
            self.county_name, self.county_code,
        ]

    # str
    def to_str(self) -> str:
        return (
            f"省级名称：{self.province_name}    省份代码：{self.province_code} | "
            f"城市名称：{self.city_name}    城市代码：{self.city_code} | "
            f"区县名称：{self.county_name}    区县代码：{self.county_code}"
        )


@dataclass
class CN_RegionResources:
    df_region_code: pd.DataFrame
    province_keywords: list[str]
    city_keywords: list[str]
    county_keywords: list[str]
    region_keywords: list[str]
    word_set: set[str]
    province_dict: dict
    city_dict: dict
    county_dict: dict
    region_mapping_dict: dict
    df_paths: pd.DataFrame
    word_to_paths: dict