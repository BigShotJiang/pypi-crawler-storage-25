import jieba
jieba.setLogLevel(jieba.logging.WARN)
import pandas as pd

from .resources import build_region_resources, load_keywords_into_jieba
from .models import CN_RegionParseResult


class CN_RegionParser:
    def __init__(self):
        self.resources = build_region_resources()
        load_keywords_into_jieba(self.resources.region_keywords)

    @staticmethod
    def _deduplicate_keep_order(words: list[str]) -> list[str]:
        seen = set()
        result = []
        for word in words:
            if pd.isna(word):
                continue
            word = str(word).strip()
            if not word:
                continue
            if word not in seen:
                seen.add(word)
                result.append(word)
        return result

    def extract_region(self, text: str) -> str:
        if pd.isna(text):
            return pd.NA
        text = str(text).strip()
        if not text:
            return pd.NA

        words = jieba.lcut(text)
        matched = [w for w in words if w in self.resources.word_set]
        matched = self._deduplicate_keep_order(matched)
        return " ".join(matched) if matched else pd.NA

    def extract_region_lcut_all(self, text: str) -> str:
        if pd.isna(text):
            return pd.NA
        text = str(text).strip()
        if not text:
            return pd.NA

        words = jieba.lcut(text, cut_all=True)
        matched = [w for w in words if w in self.resources.word_set]
        matched = self._deduplicate_keep_order(matched)
        return " ".join(matched) if matched else pd.NA

    def extract_region_lcut_for_search(self, text: str) -> str:
        if pd.isna(text):
            return pd.NA
        text = str(text).strip()
        if not text:
            return pd.NA

        words = jieba.lcut_for_search(text)
        matched = [w for w in words if w in self.resources.word_set]
        matched = self._deduplicate_keep_order(matched)
        return " ".join(matched) if matched else pd.NA

    def extract_candidates(self, text: str) -> dict:
        a1 = self.extract_region(text)
        a2 = self.extract_region_lcut_all(text)
        a3 = self.extract_region_lcut_for_search(text)

        a1_list = a1.split() if pd.notna(a1) else []
        a2_list = a2.split() if pd.notna(a2) else []
        a3_list = a3.split() if pd.notna(a3) else []

        merged = self._deduplicate_keep_order(a1_list + a2_list + a3_list)

        return {
            "extract_region": a1,
            "extract_region_lcut_all": a2,
            "extract_region_lcut_for_search": a3,
            "merged_words": merged,
        }

    def can_coexist_in_same_path(self, w1: str, w2: str) -> bool:
        paths1 = self.resources.word_to_paths.get(w1, set())
        paths2 = self.resources.word_to_paths.get(w2, set())
        return len(paths1 & paths2) > 0

    def keep_words_by_chain(self, words: list[str]) -> dict:
        if not words:
            return {
                "kept_words": [],
                "dropped_words": [],
                "common_paths": set(),
            }

        kept = []
        dropped = []

        current_paths = None

        for word in words:
            word_paths = self.resources.word_to_paths.get(word, set())

            if not word_paths:
                dropped.append(word)
                continue

            if current_paths is None:
                kept.append(word)
                current_paths = set(word_paths)
                continue

            overlap = current_paths & word_paths
            if overlap:
                kept.append(word)
                current_paths = overlap
            else:
                dropped.append(word)

        return {
            "kept_words": kept,
            "dropped_words": dropped,
            "common_paths": current_paths if current_paths is not None else set(),
        }

    def parse(self, text: str):
        candidates = self.extract_candidates(text)
        filtered = self.keep_words_by_chain(candidates["merged_words"])

        best = self.find_best_match(
            kept_words=filtered["kept_words"],
            common_paths=filtered["common_paths"],
        )

        # matched_words = self.map_words_to_standard_names(filtered["kept_words"])

        prov, city, county = self.fill_region_by_best(
            best=best,
            context_list=filtered["kept_words"],
        )

        region_info = self.expand_region_codes(prov, city, county)

        return CN_RegionParseResult(
            province_name = region_info["省级名称"],
            province_code = region_info["省级代码"],
            city_name = region_info["城市名称"],
            city_code = region_info["城市代码"],
            county_name = region_info["区县名称"],
            county_code = region_info["区县代码"],
            # matched_words = matched_words,
            # kept_words = filtered["kept_words"],
            # dropped_words = filtered["dropped_words"],
            # best_match = best,
        )
    
    def map_words_to_standard_names(self, words: list[str]) -> list[str]:
        mapped = []
        for word in words:
            std = self.resources.region_mapping_dict.get(word, word)
            if std not in mapped:
                mapped.append(std)
        return mapped
    
    @staticmethod
    def _split_path(path: str) -> tuple[str, str, str]:
        parts = str(path).split("|")
        parts = parts + [""] * (3 - len(parts))
        return parts[0], parts[1], parts[2]

    def find_best_match(self, kept_words: list[str], common_paths: set) -> object:
        if not kept_words:
            return pd.NA

        std_words = self.map_words_to_standard_names(kept_words)

        province_names = set(self.resources.df_region_code["省级名称"].dropna().astype(str))
        city_names = set(self.resources.df_region_code["城市名称"].dropna().astype(str))
        county_names = set(self.resources.df_region_code["区县名称"].dropna().astype(str))

        provs = [w for w in std_words if w in province_names]
        cities = [w for w in std_words if w in city_names]
        counties = [w for w in std_words if w in county_names]

        # 情况1：唯一合法路径，优先返回最细层级
        if len(common_paths) == 1:
            path = next(iter(common_paths))
            prov, city, county = self._split_path(path)
            if county:
                return county
            if city:
                return city
            if prov:
                return prov

        # 情况2：如果明确命中了区县，优先区县
        if len(counties) == 1:
            return counties[0]

        # 情况3：如果明确命中了城市，返回城市
        if len(cities) == 1:
            return cities[0]

        # 情况4：如果只明确到省
        if len(provs) == 1:
            return provs[0]

        # 情况5：多个候选时，从 kept_words 末尾往前找最细层级
        for w in reversed(std_words):
            if w in county_names:
                return w
        for w in reversed(std_words):
            if w in city_names:
                return w
        for w in reversed(std_words):
            if w in province_names:
                return w

        return pd.NA
    
    def fill_region_by_best(self, best: object, context_list: list[str]) -> tuple[object, object, object]:
        if pd.isna(best):
            return pd.NA, pd.NA, pd.NA

        df = self.resources.df_region_code
        std_context = self.map_words_to_standard_names(context_list)

        province_names = set(df["省级名称"].dropna().astype(str))
        city_names = set(df["城市名称"].dropna().astype(str))
        county_names = set(df["区县名称"].dropna().astype(str))

        # 1) best 是省级：只返回省
        if best in province_names:
            return best, pd.NA, pd.NA

        # 2) best 是市级：返回省、市；区县留空
        if best in city_names:
            rows = df[df["城市名称"] == best].copy()
            if rows.empty:
                return pd.NA, best, pd.NA

            best_score = -1
            best_row = None

            for _, row in rows.iterrows():
                score = 0
                if row["省级名称"] in std_context:
                    score += 1
                if row["城市名称"] in std_context:
                    score += 1

                if score > best_score:
                    best_score = score
                    best_row = row

            if best_row is None:
                best_row = rows.iloc[0]

            return best_row["省级名称"], best_row["城市名称"], pd.NA

        # 3) best 是区县级：返回完整省、市、县
        if best in county_names:
            rows = df[df["区县名称"] == best].copy()
            if rows.empty:
                return pd.NA, pd.NA, best

            best_score = -1
            best_row = None

            for _, row in rows.iterrows():
                score = 0
                if row["省级名称"] in std_context:
                    score += 1
                if row["城市名称"] in std_context:
                    score += 1
                if row["区县名称"] in std_context:
                    score += 1

                if score > best_score:
                    best_score = score
                    best_row = row

            if best_row is None:
                best_row = rows.iloc[0]

            return best_row["省级名称"], best_row["城市名称"], best_row["区县名称"]

        return pd.NA, pd.NA, pd.NA
    def expand_region_codes(self, prov: object, city: object, county: object) -> dict:
        df = self.resources.df_region_code

        result = {
            "省级名称": prov,
            "省级代码": pd.NA,
            "城市名称": city,
            "城市代码": pd.NA,
            "区县名称": county,
            "区县代码": pd.NA,
        }

        if pd.notna(prov) and pd.notna(city) and pd.notna(county):
            row = df[
                (df["省级名称"] == prov) &
                (df["城市名称"] == city) &
                (df["区县名称"] == county)
            ]
            if not row.empty:
                row = row.iloc[0]
                result["省级代码"] = row.get("省份代码", pd.NA)
                result["城市代码"] = row.get("城市代码", pd.NA)
                result["区县代码"] = row.get("区县代码", pd.NA)
                return result

        if pd.notna(prov) and pd.notna(city):
            row = df[
                (df["省级名称"] == prov) &
                (df["城市名称"] == city)
            ]
            if not row.empty:
                row = row.iloc[0]
                result["省级代码"] = row.get("省份代码", pd.NA)
                result["城市代码"] = row.get("城市代码", pd.NA)

        if pd.notna(prov):
            row = df[df["省级名称"] == prov]
            if not row.empty:
                row = row.iloc[0]
                result["省级代码"] = row.get("省份代码", pd.NA)

        return result