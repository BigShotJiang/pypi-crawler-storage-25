import logging
import shutil
from typing import Annotated

import tyro
from cli_base.cli_tools.git import Git
from cli_base.cli_tools.verbosity import setup_logging
from rich import print

from mposcli.cli_app import app
from mposcli.mpos_utils import get_mpos_path
from mposcli.shared_tyro import DEFAULT_VERBOSITY, TyroVerbosityArgType


logger = logging.getLogger(__name__)

GIT_JOBS_DEFAULT = 16


def _update_submodules(git: Git, *, cleanup, shallow_clone, reset_submodules, jobs: int):
    if reset_submodules:
        git.git_verbose_check_call('submodule', 'deinit', '--force', '--all')
        modules_path = git.cwd / '.git' / 'modules'
        if modules_path.exists():
            shutil.rmtree(modules_path)
        git.git_verbose_check_call('gc', '--aggressive', '--prune=now')

        args = ('submodule', 'update', '--init', '--recursive', '--jobs', str(jobs))
        if shallow_clone:
            args += ('--depth', '1')
        git.git_verbose_check_call(*args)
    else:
        git.git_verbose_check_call('submodule', 'sync', '--recursive')
        git.git_verbose_check_call('submodule', 'foreach', '--recursive', 'git', 'reset', '--hard')
        git.git_verbose_check_call('submodule', 'foreach', '--recursive', 'git', 'clean', '-ffdx')
        git.git_verbose_check_call('submodule', 'foreach', '--recursive', 'git', 'fetch', '--all', '--jobs', str(jobs))

        args = ('submodule', 'update', '--init', '--recursive', '--force', '--jobs', str(jobs))
        if shallow_clone:
            args += ('--depth', '1')
        git.git_verbose_check_call(*args)

    if cleanup:
        git.git_verbose_check_call(
            'submodule', 'foreach', '--recursive', 'git', 'gc', '--prune=now',
        )


@app.command
def update_submodules(
    cleanup: Annotated[
        bool,
        tyro.conf.arg(help='Cleanup unnecessary files and optimize the local repository, too?'),
    ] = True,
    shallow_clone: Annotated[
        bool,
        tyro.conf.arg(help='Submodules only a shallow clone with --depth=1?'),
    ] = True,
    reset_submodules: Annotated[
        bool,
        tyro.conf.arg(help='Drop and recreate all submodules? (Takes a while)'),
    ] = False,
    jobs: Annotated[
        int,
        tyro.conf.arg(help='git submodule update --jobs argument, i.e. how many submodules to update in parallel'),
    ] = GIT_JOBS_DEFAULT,
    verbosity: TyroVerbosityArgType = DEFAULT_VERBOSITY,
):
    """
    Updates MicroPythonOS git submodules only.
    Use "mposcli update" to update the main repository and optionally the submodules as well.
    see: https://docs.micropythonos.com/os-development/linux/#optional-updating-the-code
    """
    setup_logging(verbosity=verbosity)
    mpos_path = get_mpos_path()
    git = Git(cwd=mpos_path)
    _update_submodules(git, cleanup=cleanup, shallow_clone=shallow_clone, reset_submodules=reset_submodules, jobs=jobs)


@app.command
def update(
    cleanup: Annotated[
        bool,
        tyro.conf.arg(help='Cleanup unnecessary files and optimize the local repository, too?'),
    ] = True,
    shallow_clone: Annotated[
        bool,
        tyro.conf.arg(help='Submodules only a shallow clone with --depth=1?'),
    ] = True,
    reset_submodules: Annotated[
        bool,
        tyro.conf.arg(help='Drop and recreate all submodules? (Takes a while)'),
    ] = False,
    jobs: Annotated[
        int,
        tyro.conf.arg(help='git submodule update --jobs argument, i.e. how many submodules to update in parallel'),
    ] = GIT_JOBS_DEFAULT,
    verbosity: TyroVerbosityArgType = DEFAULT_VERBOSITY,
):
    """
    Update MicroPythonOS repository. Assume that there is a "origin" and/or "upstream" remote configured.
    Will also ask if you want to update the submodules as well, which is recommended.
    """
    setup_logging(verbosity=verbosity)
    mpos_path = get_mpos_path()
    git = Git(cwd=mpos_path)

    main_branch_name = git.get_main_branch_name()
    print(f'The main branch is: [yellow blue]{main_branch_name}')

    git.git_verbose_check_call('fetch', '--all')

    output = git.git_verbose_check_output('remote')
    remotes = output.splitlines()
    print(f'Git {remotes=}')

    for remote_name in ('origin', 'upstream'):
        if remote_name in remotes:
            git.git_verbose_check_call(
                'rebase', '--no-verify', f'{remote_name}/{main_branch_name}', '--force', exit_on_error=True
            )
        else:
            print(f'[yellow]Remote "{remote_name}" not found, skipping rebase to it.')

    if cleanup:
        print('\nCleaning up the git repository...\n')
        git.git_verbose_check_call('gc', '--aggressive', '--prune=now')

    print('\n')
    if input('Do you want to update submodules as well? [Y/n] (default: Yes): ') in ('y', ''):
        print('\nUpdating submodules...\n')
        _update_submodules(
            git, cleanup=cleanup, shallow_clone=shallow_clone, reset_submodules=reset_submodules, jobs=jobs
        )
