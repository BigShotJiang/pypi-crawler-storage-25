import logging

from cli_base.cli_tools.shell_completion import setup_tyro_shell_completion
from cli_base.cli_tools.verbosity import setup_logging
from rich import print  # noqa

from mposcli.cli_dev import app
from mposcli.shared_tyro import DEFAULT_VERBOSITY, TyroVerbosityArgType


logger = logging.getLogger(__name__)


@app.command
def shell_completion(verbosity: TyroVerbosityArgType = DEFAULT_VERBOSITY, remove: bool = False) -> None:
    """
    Setup shell completion for this CLI (Currently only for bash shell)
    """
    setup_logging(verbosity=verbosity)
    setup_tyro_shell_completion(
        prog_name='mposcli_dev_cli',
        remove=remove,
    )
