import uvicorn
from fastmcp.server.http import StarletteWithLifespan

from rag_mcp.server_factory import create_mcp_server


def create_http_app() -> StarletteWithLifespan:
    mcp = create_mcp_server(transport_mode="http")
    return mcp.http_app()


app = create_http_app()


def main():
    uvicorn.run(app, host="0.0.0.0", port=8000)
