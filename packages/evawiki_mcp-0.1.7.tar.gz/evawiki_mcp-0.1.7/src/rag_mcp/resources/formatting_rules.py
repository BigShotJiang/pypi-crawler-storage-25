from fastmcp import FastMCP
from pydantic import Field

ROLE_AND_SCOPE = """
Ты — специалист по написанию и форматированию статей в EvaWiki.

Используй этот режим, когда пользователь просит:
- написать статью в EvaWiki
- создать документацию в EvaWiki
- обновить документ EvaWiki
- отформатировать текст для EvaWiki
- опубликовать статью
- написать вики-статью
- добавить раздел в EvaWiki

Также используй этот режим, если пользователь упоминает:
EvaWiki, evawiki, вики-статью, документацию в wiki.
"""

HTML_FORMATTING_RULES = """
EvaWiki принимает HTML-контент.

Правила:
- Все заголовки должны иметь уникальный data-id
- Используй <h1>, <h2>, <h3>, <h4> с человекочитаемыми data-id на латинице через дефис
- Для абзацев используй <p>
- Для жирного текста используй <strong>
- Для встроенного кода используй <code>...</code>
- Для нумерованных списков используй <ol><li>...</li></ol>
- Для маркированных списков используй <ul><li>...</li></ul>
- Для таблиц используй <table>, <tr>, <th>, <td>
- Для ссылок используй <a href="...">...</a>
- Для внутренних ссылок EvaWiki используй относительные пути вида /project/Document/DOC-000001
- Не используй Markdown в итоговом результате
- Не используй эмодзи в статьях
"""

CODE_BLOCK_RULES = """
Все блоки кода должны быть оформлены только так:
<pre class="language-xxx"><code class="language-xxx">...</code></pre>

Поддерживаемые языки:
- Java -> language-java
- Groovy / Gradle -> language-groovy
- JSON -> language-json
- YAML -> language-yaml
- Bash / Shell -> language-bash
- SQL -> language-sql
- XML -> language-xml
- Python -> language-python
- TypeScript -> language-typescript

Правила:
- Встроенный код внутри текста оформляй только через <code>, без <pre>
- Не используй markdown fenced blocks
- Сохраняй переносы строк внутри кода
- Если язык не определён, используй нейтральный <pre><code> без выдуманного класса
"""

CODE_BLOCK_EXAMPLES = r"""
Java:
<pre class="language-java"><code class="language-java">RestAssured.given()
    .filter(new SwaggerCoverageV3RestAssured())
    .get("/api/v1/category");</code></pre>

JSON:
<pre class="language-json"><code class="language-json">{
  "rules": {
    "status": { "enable": true }
  }
}</code></pre>

Bash:
<pre class="language-bash"><code class="language-bash">./swagger-coverage-commandline \
  -s spec.json \
  -i swagger-coverage-output</code></pre>

YAML:
<pre class="language-yaml"><code class="language-yaml">openapi: 3.0.0
paths:
  /api/v1/category:
    get:
      responses:
        '200':
          description: OK</code></pre>
"""

UPDATE_SAFETY_RULES = """
При обновлении существующего документа:
- учитывай текущее содержимое документа
- не удаляй разделы, которые пользователь не просил удалять
- сохраняй существующую структуру, если пользователь не запросил реорганизацию
- новые data-id не должны конфликтовать с существующими
- если добавляется раздел, встрои его в логичное место структуры
"""

DRAFT_PUBLISH_WORKFLOW = """
Рекомендуемый workflow:
1. Уточни код документа DOC-XXXXXX или найди документ через поиск
2. Если документ существует, сначала прочитай его
3. Подготовь HTML-контент
4. Сохрани как черновик
5. Дай пользователю ссылку на черновик:
   https://<evawiki.base.url>/project/Document/DOC-XXXXXX?vf=draft
6. После подтверждения пользователя опубликуй документ
"""


def register_formatting_rules(server: FastMCP) -> None:

    @server.resource("resource://evawiki/role-and-scope")
    def resource_role_and_scope() -> str:
        return ROLE_AND_SCOPE

    @server.resource("resource://evawiki/html-formatting-rules")
    def resource_html_formatting_rules() -> str:
        return HTML_FORMATTING_RULES

    @server.resource("resource://evawiki/code-block-rules")
    def resource_code_block_rules() -> str:
        return CODE_BLOCK_RULES

    @server.resource("resource://evawiki/code-block-examples")
    def resource_code_block_examples() -> str:
        return CODE_BLOCK_EXAMPLES

    @server.resource("resource://evawiki/update-safety-rules")
    def resource_update_safety_rules() -> str:
        return UPDATE_SAFETY_RULES

    @server.resource("resource://evawiki/draft-publish-workflow")
    def resource_draft_publish_workflow() -> str:
        return DRAFT_PUBLISH_WORKFLOW

    @server.prompt(
        name="evawiki_format_html",
        title="EvaWiki: format HTML",
        description=(
            """
Преобразует исходный текст в HTML-фрагмент для EvaWiki. 
Использовать для первичного форматирования статьи, документации 
или черновика, когда нужно получить чистый EvaWiki-совместимый HTML 
с уникальными data-id в заголовках и корректным оформлением кодовых блоков.
            """
        ),
    )
    def evawiki_format_html(
        text: str = Field(..., description="Исходный текст документа или статьи"),
        title: str = Field(default="", description="Заголовок документа или статьи"),
    ) -> str:
        return f"""
    Сформируй итоговый HTML-контент для EvaWiki.
    
    Параметры:
    - Заголовок: {title}
    
    Задача:
    - Преобразуй исходный текст в чистый HTML для EvaWiki.
    - Не используй Markdown.
    - Все заголовки снабди уникальными data-id.
    - Кодовые блоки оформи строго по правилам EvaWiki.
    - Не используй эмодзи.
    - Верни только HTML-фрагмент статьи.
    
    Обязательно опирайся на ресурсы:
    - resource://evawiki/html-formatting-rules
    - resource://evawiki/code-block-rules
    - resource://evawiki/code-block-examples
    
    Исходный материал:
    {text}
    """

    @server.prompt(
        name="evawiki_create_article",
        title="EvaWiki: create article",
        description=(
            """
Создаёт новую статью или подготавливает новый документ для EvaWiki 
на основе исходного текста. Использовать, когда нужно с нуля собрать 
HTML-статью, документацию или черновик в формате EvaWiki с корректной 
структурой, уникальными data-id и правильным оформлением кодовых блоков.
            """
        ),
    )
    def evawiki_create_article(
        document_code: str = Field(
            ...,
            description="Код документа EvaWiki в формате DOC-XXXXXX, если он уже известен.",
        ),
        title: str = Field(..., description="Итоговый заголовок статьи или документа."),
        topic: str = Field(
            ...,
            description="Краткая тема или предмет статьи, чтобы задать контекст и структуру.",
        ),
        source_text: str = Field(
            ...,
            description="Исходный текст, черновик, тезисы или материал, из которого нужно собрать статью.",
        ),
    ) -> str:
        return f"""
    Сформируй итоговый HTML-контент для новой статьи EvaWiki.
    
    Входные данные:
    - Код документа: {document_code}
    - Заголовок: {title}
    - Тема: {topic}
    
    Задача:
    - Подготовь новую статью для EvaWiki на основе исходного текста.
    - Если document_code уже существует, сначала прочитай текущий документ.
    - Преобразуй материал в чистый HTML для EvaWiki.
    - Не используй Markdown.
    - Все заголовки снабди уникальными data-id.
    - Кодовые блоки оформи строго по правилам EvaWiki.
    - Не используй эмодзи.
    - По умолчанию ориентируйся на сохранение результата как черновика.
    - Верни только HTML-фрагмент статьи.
    
    Обязательно опирайся на ресурсы:
    - resource://evawiki/role-and-scope
    - resource://evawiki/html-formatting-rules
    - resource://evawiki/code-block-rules
    - resource://evawiki/code-block-examples
    - resource://evawiki/draft-publish-workflow
    
    Исходный материал:
    {source_text}
    """

    @server.prompt(
        name="evawiki_update_article",
        title="EvaWiki: update article",
        description=(
            """
Обновляет существующий документ EvaWiki с сохранением остального контента. 
Использовать, когда нужно внести изменения в уже существующую статью, 
добавить или переписать отдельные фрагменты, не удаляя несвязанные разделы и не ломая текущую структуру документа.
            """
        ),
    )
    def evawiki_update_article(
        document_code: str = Field(
            ..., description="Код существующего документа EvaWiki в формате DOC-XXXXXX."
        ),
        change_request: str = Field(
            ...,
            description="Описание того, какие именно изменения нужно внести в существующий документ.",
        ),
        new_content: str = Field(
            ...,
            description="Новый текст, фрагменты или данные, которые нужно встроить в документ.",
        ),
    ) -> str:
        return f"""
    Обнови существующий документ EvaWiki.
    
    Параметры:
    - Код документа: {document_code}
    
    Задача:
    - Сначала прочитай текущее содержимое документа.
    - Затем примени только те изменения, которые описаны пользователем.
    - Не удаляй существующий контент без явного указания.
    - Сохрани существующую структуру документа, если пользователь не запросил её изменить.
    - Итог оформи в HTML для EvaWiki.
    - Все новые заголовки снабди уникальными data-id.
    - Кодовые блоки оформи строго по правилам EvaWiki.
    - Сохрани результат как черновик, если пользователь явно не попросил публикацию.
    - Верни только HTML итоговой версии документа.
    
    Запрос на изменение:
    {change_request}
    
    Новый контент:
    {new_content}
    
    Обязательно опирайся на ресурсы:
    - resource://evawiki/html-formatting-rules
    - resource://evawiki/code-block-rules
    - resource://evawiki/code-block-examples
    - resource://evawiki/update-safety-rules
    - resource://evawiki/draft-publish-workflow
    """

    @server.prompt(
        name="evawiki_add_section",
        title="EvaWiki: add section",
        description=(
            """
Добавляет новый раздел в существующий документ EvaWiki без полной переработки всей статьи. 
Использовать, когда нужно встроить новый блок, подраздел или раздел в уже готовую структуру документа, 
сохранив логику и форматирование существующего содержимого.
            """
        ),
    )
    def evawiki_add_section(
        document_code: str = Field(
            ..., description="Код существующего документа EvaWiki в формате DOC-XXXXXX."
        ),
        section_title: str = Field(
            ...,
            description="Заголовок нового раздела, который нужно добавить в документ.",
        ),
        section_html_or_text: str = Field(
            ...,
            description="Содержимое нового раздела: сырой текст, черновой HTML или структурированный материал.",
        ),
    ) -> str:
        return f"""
    Добавь новый раздел в документ EvaWiki.

    Параметры:
    - Код документа: {document_code}
    - Заголовок раздела: {section_title}

    Задача:
    - Сначала прочитай существующий документ.
    - Найди логичное место для вставки нового раздела.
    - Не нарушай текущую структуру документа без необходимости.
    - Преобразуй содержимое раздела в HTML по правилам EvaWiki.
    - Обеспечь уникальные data-id для новых заголовков.
    - Кодовые блоки оформи строго по правилам EvaWiki.
    - Сохрани результат как черновик.
    - Верни только HTML итоговой версии документа.

    Содержимое раздела:
    {section_html_or_text}

    Обязательно опирайся на ресурсы:
    - resource://evawiki/html-formatting-rules
    - resource://evawiki/code-block-rules
    - resource://evawiki/code-block-examples
    - resource://evawiki/update-safety-rules
    - resource://evawiki/draft-publish-workflow
    """
