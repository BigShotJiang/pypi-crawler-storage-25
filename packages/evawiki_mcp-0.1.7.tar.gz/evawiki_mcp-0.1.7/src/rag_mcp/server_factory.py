from typing import Any, Literal

from fastmcp import FastMCP
from mcp.types import ToolAnnotations

from rag_mcp.api.routes import register_routes
from rag_mcp.resources.formatting_rules import register_formatting_rules
from rag_mcp.settings import app_settings
from rag_mcp.tools.attachments._models import (
    AttachmentDownloadResult,
    AttachmentMetadataList,
    AttachmentUploadMetadata,
)
from rag_mcp.tools.attachments.create import (
    evawiki_attachment_upload_from_file,
    evawiki_attachment_upload_from_url,
)
from rag_mcp.tools.attachments.download import evawiki_attachment_download
from rag_mcp.tools.attachments.list import evawiki_attachment_list
from rag_mcp.tools.common.overview import get_overview
from rag_mcp.tools.documents._models import (
    DocumentMetadata,
    DocumentMetadataList,
    DocumentMetadataShort,
)
from rag_mcp.tools.documents.draft_create import evawiki_document_draft_create
from rag_mcp.tools.documents.draft_update import evawiki_document_draft_update
from rag_mcp.tools.documents.get import evawiki_document_get, evawiki_document_text_get
from rag_mcp.tools.documents.publish import evawiki_document_publish
from rag_mcp.tools.documents.search import evawiki_document_search
from rag_mcp.tools.project.document_tree import get_documents_tree_by_project
from rag_mcp.tools.project.project_list import ProjectListResult, project_list
from rag_mcp.tools.rag.semantic_search import search_by_query
from rag_mcp.tools.utils import LlmToolSchemaTransformer, mcp_adapter

read_only_annotations = ToolAnnotations(readOnlyHint=True)
destructive_annotations = ToolAnnotations(destructiveHint=True)


def create_mcp_server(transport_mode: Literal["http", "stdio"] = "stdio") -> FastMCP:
    server = FastMCP("evawiki-rag-mcp-server")

    for func in get_mcp_tool_functions(transport_mode):
        transformed_tool = LlmToolSchemaTransformer(**func).transform()
        server.add_tool(transformed_tool)

    register_formatting_rules(server)

    register_routes(server)

    return server


def get_mcp_tool_functions(transport_mode: Literal["http", "stdio"]):

    func_list = []

    def add_func(
        name: str,
        name_or_fn,
        *,
        tags: set[str] | None = None,
        annotations: ToolAnnotations | None = None,
        output_schema: Any | None = None,
    ):
        func_list.append(
            dict(
                name=name,
                tags=tags,
                name_or_fn=name_or_fn,
                annotations=annotations,
                output_schema=output_schema,
            )
        )

    # attachments
    add_func(
        "evawiki_attachment_upload_from_url",
        mcp_adapter(evawiki_attachment_upload_from_url),
        tags={"write"},
        output_schema=AttachmentUploadMetadata.model_json_schema(),
    )

    if transport_mode == "stdio":
        add_func(
            "evawiki_attachment_upload_from_file",
            mcp_adapter(evawiki_attachment_upload_from_file),
            tags={"write"},
            output_schema=AttachmentUploadMetadata.model_json_schema(),
        )
        add_func(
            "evawiki_attachment_download",
            mcp_adapter(evawiki_attachment_download),
            tags={"read"},
            output_schema=AttachmentDownloadResult.model_json_schema(),
            annotations=read_only_annotations,
        )

    add_func(
        "evawiki_attachment_list",
        mcp_adapter(evawiki_attachment_list),
        tags={"read"},
        output_schema=AttachmentMetadataList.model_json_schema(),
        annotations=read_only_annotations,
    )

    # common
    add_func(
        "evawiki_overview_get",
        mcp_adapter(get_overview),
        tags={"read"},
        annotations=read_only_annotations,
    )

    # documents
    add_func(
        "evawiki_document_draft_create",
        mcp_adapter(evawiki_document_draft_create),
        tags={"write"},
        output_schema=DocumentMetadataShort.model_json_schema(),
    )
    add_func(
        "evawiki_document_get",
        mcp_adapter(evawiki_document_get),
        tags={"read"},
        output_schema=DocumentMetadata.model_json_schema(),
        annotations=read_only_annotations,
    )
    add_func(
        "evawiki_document_text_get",
        mcp_adapter(evawiki_document_text_get),
        tags={"read"},
        annotations=read_only_annotations,
    )
    add_func(
        "evawiki_document_draft_update",
        mcp_adapter(evawiki_document_draft_update),
        tags={"write"},
    )
    add_func(
        "evawiki_document_publish",
        mcp_adapter(evawiki_document_publish),
        tags={"write"},
    )
    add_func(
        "evawiki_document_search",
        mcp_adapter(evawiki_document_search),
        tags={"read"},
        output_schema=DocumentMetadataList.model_json_schema(),
        annotations=read_only_annotations,
    )
    # project
    add_func(
        "evawiki_project_list",
        mcp_adapter(project_list),
        tags={"read"},
        output_schema=ProjectListResult.model_json_schema(),
        annotations=read_only_annotations,
    )

    add_func(
        "evawiki_project_documents_tree",
        mcp_adapter(get_documents_tree_by_project),
        tags={"read"},
        annotations=read_only_annotations,
    )

    # rag
    if app_settings.evawiki_rag_enabled:
        add_func(
            "evawiki_ask_query",
            mcp_adapter(search_by_query),
            tags={"read"},
        )

    return func_list
