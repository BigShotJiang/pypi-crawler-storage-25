import functools
import json
from copy import deepcopy
from typing import (
    Any,
    Callable,
    Type,
    TypeVar,
    get_origin,
)

import yaml
from fastmcp.exceptions import ToolError
from fastmcp.tools import Tool, ToolResult
from mcp.types import TextContent, ToolAnnotations
from pydantic import (
    Field,
    TypeAdapter,
    ValidationError,
)
from rag_mcp.settings import app_settings

T = TypeVar("T")


def dumps_content(model: dict[Any, Any], include_decoration: bool = True) -> str:

    class IndentDumper(yaml.Dumper):
        def increase_indent(self, flow=False, indentless=False):
            return super(IndentDumper, self).increase_indent(flow, False)

    def dumps_to_yaml(model: dict[Any, Any]) -> str:
        return yaml.dump(
            model,
            allow_unicode=True,
            sort_keys=False,
            default_flow_style=False,
            indent=2,
            Dumper=IndentDumper,
        )

    def dumps_to_json(model: dict[Any, Any]) -> str:
        return TypeAdapter(dict).dump_json(model, indent=2).decode()

    if app_settings.evawiki_content_format == "json":
        dump_str = dumps_to_json(model)
        return f"```json\n{dump_str}\n```" if include_decoration else dump_str
    elif app_settings.evawiki_content_format == "yaml":
        dump_str = dumps_to_yaml(model)
        return f"```yaml\n{dump_str}\n```" if include_decoration else dump_str
    return ""


def process_response(response, model_class: Type[T]) -> T | str:
    """Универсальный метод для валидации JSON в любую модель Pydantic."""
    raw_data = raise_response_data(response=response)
    try:
        result_data = TypeAdapter(dict).validate_json(raw_data).get("result", {})
        if model_class != dict:
            return TypeAdapter(model_class).validate_python(result_data)
        return result_data
    except (ValidationError, AttributeError) as e:
        if hasattr(model_class, "from_json") and not get_origin(model_class):
            return model_class.from_json(raw_data)
        raise RuntimeError(f"Validation Error: {str(e)}")


def raise_response_data(response) -> str:
    raw_data = response.data.decode("utf-8") if response.data else "{}"
    result_data = TypeAdapter(dict).validate_json(raw_data)
    if 200 <= response.status <= 299 and not result_data.get("error"):
        return raw_data
    try:
        error_data = result_data.get("error", {})
        message = error_data.get("message", "Unknown error")
        status_code = error_data.get("code", response.status)
    except json.JSONDecodeError:
        message = raw_data
        status_code = response.status
    raise RuntimeError(f"Error [{status_code}]: {message}")


def mcp_adapter(logic_func: Callable):
    @functools.wraps(logic_func)
    def wrapper(*args, **kwargs) -> ToolResult:
        try:
            func_result = logic_func(*args, **kwargs)
            return _build_success_result(func_result)

        except ValidationError as e:
            short_error = "; ".join(
                [f"{'.'.join(err['loc'])}: {err['msg']}" for err in e.errors()]
            )
            error_message = f"Validation error: {short_error}"
        except PermissionError as e:
            error_message = f"Call rejected: {str(e)}"
        except Exception as e:
            error_message = f"Error occured: {str(e)}"
        raise ToolError(error_message)

    return wrapper


def _build_success_result(
    result: Any,
) -> ToolResult:
    if isinstance(result, tuple):
        content, structured_result = result
    else:
        content, structured_result = "Tool call execution passed", result
    return ToolResult(
        content=[TextContent(type="text", text=content)],
        structured_content=structured_result,
    )


class LlmToolSchemaTransformer:
    SCALAR_TYPES = {"string", "integer", "boolean"}

    @staticmethod
    def llm_field_optional_int(description: str) -> Any:
        return Field(
            default=None, description=description, json_schema_extra={"type": "integer"}
        )

    @staticmethod
    def llm_field_optional_bool(description: str, default: bool | None = None) -> Any:
        return Field(
            default=default,
            description=description,
            json_schema_extra={"type": "boolean"},
        )

    @staticmethod
    def llm_field_optional_str(
        description: str, default: str | None = None, examples: list[Any] | None = None
    ) -> Any:
        return Field(
            default=default,
            description=description,
            json_schema_extra={"type": "string"},
            examples=examples,
        )

    def __init__(
        self,
        name_or_fn: Any,
        name: str,
        tags: set[str] | None = None,
        annotations: ToolAnnotations | None = None,
        output_schema: Any | None = None,
        **kwargs
    ):
        self.name_or_fn = name_or_fn
        self.name = name
        self.tags = tags
        self.annotations = annotations
        self.output_schema = output_schema

    def _collapse_nullable_anyof_node(self, node: Any) -> Any:
        if isinstance(node, dict):
            node = deepcopy(node)

            if "anyOf" in node and isinstance(node["anyOf"], list) and len(node["anyOf"]) == 2:
                variants = node["anyOf"]

                dict_variants = [v for v in variants if isinstance(v, dict)]
                if len(dict_variants) == 2:
                    null_variant = next((v for v in dict_variants if v.get("type") == "null"), None)
                    scalar_variant = next(
                        (v for v in dict_variants if v.get("type") in LlmToolSchemaTransformer.SCALAR_TYPES),
                        None,
                    )

                    if null_variant is not None and scalar_variant is not None:
                        merged = deepcopy(scalar_variant)

                        for k, v in node.items():
                            if k == "anyOf":
                                continue
                            merged[k] = self._collapse_nullable_anyof_node(v)
                        return self._collapse_nullable_anyof_node(merged)

            return {k: self._collapse_nullable_anyof_node(v) for k, v in node.items()}

        if isinstance(node, list):
            return [self._collapse_nullable_anyof_node(item) for item in node]

        return node

    def _patch_tool_schema_inplace(self, tool_obj: Any) -> Any:
        if hasattr(tool_obj, "parameters") and isinstance(tool_obj.parameters, dict):
            tool_obj.parameters = self._collapse_nullable_anyof_node(tool_obj.parameters)

        if hasattr(tool_obj, "inputSchema") and isinstance(tool_obj.inputSchema, dict):
            tool_obj.inputSchema = self._collapse_nullable_anyof_node(tool_obj.inputSchema)
        return tool_obj

    def transform(self) -> Tool:
        transformed = Tool.from_tool(self.name_or_fn, name=self.name, tags=self.tags, annotations=self.annotations, output_schema=self.output_schema)
        return self._patch_tool_schema_inplace(transformed)


