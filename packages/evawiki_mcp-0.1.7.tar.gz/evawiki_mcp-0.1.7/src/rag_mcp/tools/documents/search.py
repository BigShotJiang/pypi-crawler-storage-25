from evawiki_client import (
    CmfDocumentListRequestKwargs,
)
from evawiki_client.models.cmf_document_list_request import CmfDocumentListRequest
from pydantic import Field

from rag_mcp.services.evawiki import get_api_client
from rag_mcp.tools.documents._models import DocumentMetadata, DocumentMetadataList
from rag_mcp.tools.utils import (
    dumps_content,
    process_response,
)


def evawiki_document_search(
    name_filter: str = Field(..., description="Фильтрация по имени документов"),
) -> DocumentMetadataList:
    """
    Выполняет поиск документов по вхождению подстроки в названии.

    USE THIS TOOL WHEN:
    - Вам нужно найти документы по части названия (например, "GetPartner" найдет "ФТ-2 Получение партнеров GetPartner по товарам")

    BEHAVIOR:
    - При отсутствии совпадений возвращает пустой список
    - Возвращает документы без содержимого (только метаданные)
    """
    filter = []
    if name_filter:
        filter.extend(["name", "LIKE", f"%{name_filter}%"])
    if not filter:
        raise ValueError("name_filter is required")

    api_instance = get_api_client()

    kwargs = CmfDocumentListRequestKwargs(filter=filter)
    request = CmfDocumentListRequest(kwargs=kwargs)
    response = api_instance.cmf_document_list_without_preload_content(
        cmf_document_list_request=request
    )
    data: list[dict] = process_response(response, list[dict])

    model = build_model_from_response_data(data)
    model_data = model.model_dump(exclude_none=True)
    return dumps_content(model_data), model_data


def build_model_from_response_data(data_list: list[dict]) -> DocumentMetadataList:
    l = []
    for data in data_list:
        l.append(DocumentMetadata(**data))
    return DocumentMetadataList(documents=l)


#
# if __name__ == "__main__":
#     evawiki_document_search(name_filter="8 - draft")
