from evawiki_client import (
    CmfDocumentCreateRequest,
    CmfDocumentCreateRequestKwargs,
    CmfDocumentGetRequest,
    CmfDocumentGetRequestKwargs,
)
from pydantic import Field

from rag_mcp.services.evawiki import get_api_client
from rag_mcp.tools.documents._models import DocumentMetadataShort
from rag_mcp.tools.utils import (
    LlmToolSchemaTransformer,
    process_response,
)


def evawiki_document_draft_create(
    name: str = Field(..., description="Заголовок документа EvaWiki"),
    parent: str | None = LlmToolSchemaTransformer.llm_field_optional_str(
        description="Код родительского раздела"
    ),
    text_draft: str | None = LlmToolSchemaTransformer.llm_field_optional_str(
        description="Html-содержимое документа EvaWiki"
    ),
) -> DocumentMetadataShort:
    """
    Создает документ EvaWiki со статусом черновика и возвращает его код.

    USE THIS TOOL WHEN:
    - Нужно создать новый документ в EvaWiki
    """
    client = get_api_client()

    kwargs: CmfDocumentCreateRequestKwargs = CmfDocumentCreateRequestKwargs(
        name=name, tree_parent=parent, text_draft=text_draft, full_screen=True
    )
    cmf_document_create_request: CmfDocumentCreateRequest = CmfDocumentCreateRequest(
        kwargs=kwargs
    )
    response = client.cmf_document_create_without_preload_content(
        cmf_document_create_request=cmf_document_create_request
    )
    document_id: str = process_response(response, dict)

    kwargs = CmfDocumentGetRequestKwargs(
        fields=["code"], filter=["id", "==", document_id]
    )
    request = CmfDocumentGetRequest(kwargs=kwargs)
    response = client.cmf_document_get_without_preload_content(
        cmf_document_get_request=request
    )
    data: dict = process_response(response, dict)
    model = DocumentMetadataShort(**data)
    return f"Документ {name} успешно создан, его код: {data['code']}", model


# if __name__ == "__main__":
#     evawiki_document_draft_create(name="testdoc9", parent="FL-002837", text_draft=None)
