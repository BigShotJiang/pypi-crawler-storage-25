from markdownify import markdownify as md
from pydantic import BaseModel, Field, field_validator

from rag_mcp.tools.utils import LlmToolSchemaTransformer


class OverviewItemInfo(BaseModel):
    title: str
    url: str
    id: str | None = None
    items: list["OverviewItemInfo"] = Field(default_factory=list)


class OverviewInfo(BaseModel):
    items: list["OverviewItemInfo"] = Field(default_factory=list)


class DocumentMetadataShort(BaseModel):
    id: str = Field(..., description="Идентификатор документа")
    name: str = Field(..., description="Заголовок документа")
    code: str = Field(..., description="Код документа")


class DocumentMetadata(DocumentMetadataShort):
    headline: str | None = LlmToolSchemaTransformer.llm_field_optional_str(
        description="Описание документа"
    )
    age_days: str | None = LlmToolSchemaTransformer.llm_field_optional_str(
        description="Возраст документа"
    )
    project_id: str | None = LlmToolSchemaTransformer.llm_field_optional_str(
        description="Идентификатор проекта"
    )
    doc_version: str | None = LlmToolSchemaTransformer.llm_field_optional_str(
        description="Версия документа"
    )

    # @field_validator('text')
    # @classmethod
    # def html_to_markdown(cls, v):
    #     if isinstance(v, str) and "<" in v and ">" in v:
    #         return md(v, strip=['script', 'style'], heading_style="ATX")
    #     return v


class DocumentMetadataList(BaseModel):
    documents: list[DocumentMetadata] = Field(default_factory=list)
