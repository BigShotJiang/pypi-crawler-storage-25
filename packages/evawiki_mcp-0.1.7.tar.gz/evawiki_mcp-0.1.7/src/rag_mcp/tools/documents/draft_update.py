import re

from evawiki_client import (
    CmfDocumentCreateRequestKwargs,
    CmfDocumentGetRequest,
    CmfDocumentGetRequestKwargs,
    CmfDocumentUpdateRequest,
)
from mcp.types import CallToolResult
from pydantic import Field

from rag_mcp.services.evawiki import get_api_client
from rag_mcp.tools.utils import (
    LlmToolSchemaTransformer,
    process_response,
    raise_response_data,
)


def evawiki_document_draft_update(
    code: str = Field(..., description="Код документа", examples=["DOC-039481"]),
    name: str | None = LlmToolSchemaTransformer.llm_field_optional_str(
        description="Новый заголовок документа EvaWiki"
    ),
    text_draft: str | None = LlmToolSchemaTransformer.llm_field_optional_str(
        description="Новый html‑черновик содержимого документа EvaWiki"
    ),
):
    """
    Обновляет документ EvaWiki и сохраняет как черновик.

    USE THIS TOOL WHEN:
    - Нужно изменить заголовок существующего документа EvaWiki
    - Нужно обновить текстовое содержимое (html-разметка) документа
    - Необходимо частично изменить документ без перезаписи неизменённых полей

    INPUT GUIDELINES:
    - Хотя бы один из параметров (name или text_draft) должен быть указан

    BEHAVIOR:
    - Изменяет только переданные поля, остальные остаются без изменений
    - Документ сохраняется как черновик (draft)
    """
    client = get_api_client()

    if not re.match(r"DOC-\d+", code):
        raise ValueError("Document code does not correspond to pattern DOC-xxxx")

    kwargs = CmfDocumentGetRequestKwargs(fields=["id"], filter=["code", "==", code])
    request = CmfDocumentGetRequest(kwargs=kwargs)
    response = client.cmf_document_get_without_preload_content(
        cmf_document_get_request=request
    )
    data: dict = process_response(response, dict)

    doc_id = data["id"]

    update_data = {}
    if name:
        update_data["name"] = name
    if text_draft:
        update_data["text_draft"] = text_draft

    kwargs: CmfDocumentCreateRequestKwargs = CmfDocumentCreateRequestKwargs(
        **update_data
    )
    cmf_document_update_request: CmfDocumentUpdateRequest = CmfDocumentUpdateRequest(
        args=[doc_id], kwargs=kwargs
    )
    response = client.cmf_document_update_without_preload_content(
        cmf_document_update_request=cmf_document_update_request
    )
    raise_response_data(response)
    return f"Документ {code} успешно обновлен", {}


# if __name__ == "__main__":
#     evawiki_document_draft_update(
#         code="DOC-061781", name="", text_draft="Тест документ 7 +++"
#     )
