import re
from typing import Literal

from evawiki_client import CmfDocumentGetRequest, CmfDocumentGetRequestKwargs
from mcp.types import CallToolResult
from pydantic import Field

from rag_mcp.services.evawiki import get_api_client
from rag_mcp.tools.documents._models import DocumentMetadata
from rag_mcp.tools.utils import dumps_content, process_response


def evawiki_document_get(
    code: str = Field(..., description="Код документа", examples=["DOC-039481"]),
) -> DocumentMetadata:
    """
    Получает документ EvaWiki по его коду с метаданными.

    USE THIS TOOL WHEN:
    - нужно получить метаданные документа по коду

    BEHAVIOR:
    - Возвращает данные документа без текстового содержимого
    """
    data: dict = _get_document(
        code,
        document_fields=[
            "project_id",
            "tree_parent",
            "doc_version",
            "age_days",
            "head_line",
            "label",
        ],
    )

    model = _build_model_from_response_data(data)
    model_data = model.model_dump(exclude_none=True)
    return dumps_content(model_data), model


def evawiki_document_text_get(
    code: str = Field(..., description="Код документа", examples=["DOC-039481"]),
    state: Literal["published", "draft"] = Field(
        default="published",
        description="Состояние документа, для которого получаем текст",
    ),
):
    """
    Получает текст документа EvaWiki.

    USE THIS TOOL WHEN:
    - нужно получить текст опубликованного документа или черновика.

    INPUT GUIDELINES:
    - state:
        - Если "published", то возвращается текст опубликованного документа.
        - Если "draft" , то возвращается текст документа в состоянии draft (черновик).
    """
    property = "text_draft" if state == "draft" else "text"
    data: dict = _get_document(code, document_fields=[property])

    return (
        f"Текст {'черновика' if state == 'draft' else 'опубликованного'} документа {code} ниже:\n{data.get(property)}",
        {"result": data.get(property)},
    )


def _get_document(code: str, document_fields: list[str]) -> dict:
    api_instance = get_api_client()

    if re.match(r"DOC-\d+", code):
        doc_filter = ["code", "=", code]
    else:
        raise ValueError("Document code does not correspond to pattern DOC-xxxx")

    kwargs = CmfDocumentGetRequestKwargs(fields=document_fields, filter=doc_filter)
    request = CmfDocumentGetRequest(kwargs=kwargs)
    response = api_instance.cmf_document_get_without_preload_content(
        cmf_document_get_request=request
    )
    data: dict = process_response(response, dict)
    return data


def _build_model_from_response_data(data: dict) -> DocumentMetadata:
    return DocumentMetadata(**data)


# if __name__ == "__main__":
#     print(evawiki_document_get("DOC-061781"))
#     print("ok")
