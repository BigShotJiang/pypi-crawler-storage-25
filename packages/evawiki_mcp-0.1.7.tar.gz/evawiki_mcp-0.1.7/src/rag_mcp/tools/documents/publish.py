import re

from evawiki_client import (
    CmfDocumentDoPublishRequest,
    CmfDocumentGetRequest,
    CmfDocumentGetRequestKwargs,
)
from pydantic import Field

from rag_mcp.services.evawiki import get_api_client
from rag_mcp.tools.utils import (
    process_response,
    raise_response_data,
)


def evawiki_document_publish(
    code: str = Field(..., description="Код документа", examples=["DOC-039481"]),
):
    """
    Публикует документ EvaWiki.

    USE THIS TOOL WHEN:
    - Нужно текст черновика документа EvaWiki сделать общедоступным

    BEHAVIOR:
    - Текст черновика документа становится общедоступным, документ считается опубликованным
    - Старый текст опубликованного документа удаляется
    """
    client = get_api_client()

    if not re.match(r"DOC-\d+", code):
        raise ValueError("Document code does not correspond to pattern DOC-xxxx")

    kwargs = CmfDocumentGetRequestKwargs(fields=["id"], filter=["code", "==", code])
    request = CmfDocumentGetRequest(kwargs=kwargs)
    response = client.cmf_document_get_without_preload_content(
        cmf_document_get_request=request
    )
    data: dict = process_response(response, dict)

    request: CmfDocumentDoPublishRequest = CmfDocumentDoPublishRequest(
        args=[data["id"]]
    )
    response = client.cmf_document_do_publish_without_preload_content(
        cmf_document_do_publish_request=request
    )
    raise_response_data(response)
    return f"Документ {code} успешно опубликован", {}


if __name__ == "__main__":
    evawiki_document_publish(code="DOC-061781")
