from pydantic import BaseModel, Field

from rag_mcp.tools.utils import LlmToolSchemaTransformer


class AttachmentUploadMetadata(BaseModel):
    """Описание вложения"""

    source: str = Field(..., description="Источник вложения")
    url: str = Field(..., description="http(s)-ссылка вложения на EvaWiki")


class AttachmentMetadata(BaseModel):
    """Метаданные вложения"""

    id: str = Field(..., description="Идентификатор вложения")
    name: str = Field(..., description="Название вложения")
    code: str = Field(..., description="Код вложения")
    url: str = Field(..., description="http(s)-ссылка вложения")
    parent_id: str | None = LlmToolSchemaTransformer.llm_field_optional_str(
        description="Идентификатор объекта EvaWiki, например: документ или задача, к которому прикреплено вложение"
    )
    project_id: str | None = LlmToolSchemaTransformer.llm_field_optional_str(
        description="Идентификатор проекта"
    )


class AttachmentMetadataList(BaseModel):
    """Контейнер с метаданными вложений"""

    attachments: list[AttachmentMetadata] = Field(
        default_factory=list, description="Список метаданных вложений"
    )


class AttachmentDownloadResult(BaseModel):
    """Результат скачивания вложения"""

    url: str = Field(..., description="http(s)-ссылка вложения на EvaWiki")
    path: str = Field(..., description="Локальный путь, по которому сохранён файл")
    size_bytes: int = Field(..., description="Размер скачанного файла в байтах")
