from typing import Any
from urllib.parse import urljoin

from evawiki_client import (
    CmfAttachmentListRequest,
    CmfTaskListRequestKwargs,
)
from pydantic import Field

from rag_mcp.services.evawiki import get_api_client
from rag_mcp.settings import app_settings
from rag_mcp.tools.attachments._models import AttachmentMetadata, AttachmentMetadataList
from rag_mcp.tools.utils import dumps_content, process_response


def evawiki_attachment_list(
    parent_id: str = Field(
        ...,
        description="Идентификатор объекта EvaWiki, например: документ или задача, к которому прикреплены вложения",
        examples=["CmfDocument:12e86b30-5521-11f1-b409-0242ac110002"],
    ),
) -> AttachmentMetadataList:
    """
    Получает список описаний вложений в EvaWiki, которые прикреплены к документу

    USE THIS TOOL WHEN:
    - нужно получить список описаний вложений в EvaWiki

    BEHAVIOR:
    - Возвращает описание вложений без содержимого
    """
    client = get_api_client()
    kwargs: CmfTaskListRequestKwargs = CmfTaskListRequestKwargs(
        filter=["parent_id", "==", parent_id], fields=["url"]
    )
    cmf_attachment_list_request: CmfAttachmentListRequest = CmfAttachmentListRequest(
        kwargs=kwargs
    )
    response = client.cmf_attachment_list_without_preload_content(
        cmf_attachment_list_request=cmf_attachment_list_request
    )
    data: list[dict] = process_response(response, list[dict])
    model = _build_model_from_response_data(data)
    model_data = model.model_dump(exclude_none=True)
    return (
        f"Найдено {len(model.attachments)} вложений: \n {dumps_content(model_data)}",
        model,
    )


def _build_model_from_response_data(data_list: list[dict]) -> AttachmentMetadataList:
    return AttachmentMetadataList(
        attachments=[AttachmentMetadata(**_transform_data(data)) for data in data_list]
    )


def _transform_data(data: dict[str, Any]) -> dict:
    if "url" in data and data["url"] and not data["url"].startswith("http"):
        data["url"] = urljoin(app_settings.evawiki_endpoint, data["url"])
    return data
