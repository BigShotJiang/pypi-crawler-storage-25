import base64
import re
from pathlib import Path
from typing import Literal

import httpx
from evawiki_client import (
    CmfAttachmentCreateRequest,
    CmfAttachmentCreateRequestKwargs,
    CmfAttachmentGetRequest,
    CmfAttachmentGetRequestKwargs,
)
from pydantic import Field

from rag_mcp.services.evawiki import get_api_client
from rag_mcp.tools.attachments._models import AttachmentUploadMetadata
from rag_mcp.tools.utils import process_response


def evawiki_attachment_upload_from_file(
    parent: str = Field(
        ...,
        description="Код объекта EvaWiki, например: документ или задача, к которому прикрепляется вложение",
        examples=["DOC-061650"],
    ),
    source: str = Field(..., description="Локальный путь к файлу"),
) -> AttachmentUploadMetadata:
    """
    Создает вложение в EvaWiki по переданному файлу и возвращает ссылку на вложение.

    USE THIS TOOL WHEN:
    - нужно разместить файл вложением в EvaWiki и получить ссылку на него
    - нужно опубликовать изображение в документе EvaWiki

    INPUT GUIDELINES:
    - code: Код документа (например, "DOC-039481").

    BEHAVIOR:
    - В EvaWiki создается вложение
    - Внешний url-адрес передается обратно как результат
    """

    content = _load_bytes(source, "file")
    external_url = _create_attachment_from_bytes(
        parent=parent, filename=Path(source).name, content=content
    )
    model = AttachmentUploadMetadata(source=source, url=external_url)
    return (
        f"Вложение успешно создано и доступно по ссылке: {external_url}",
        model,
    )


def evawiki_attachment_upload_from_url(
    parent: str = Field(
        ...,
        description="Код объекта EvaWiki, например: документ или задача, к которому прикрепляется вложение",
        examples=["DOC-061650"],
    ),
    filename: str = Field(
        ...,
        description="Имя файла с расширением",
        examples=["report.json", "image.png"],
    ),
    source: str = Field(..., description="http(s)-ссылка с вложением"),
) -> AttachmentUploadMetadata:
    """
    Создает вложение в EvaWiki по http(s)-ссылке и возвращает ссылку на вложение.

    USE THIS TOOL WHEN:
    - нужно разместить файл вложением в EvaWiki и получить ссылку на него
    - нужно опубликовать изображение в документе EvaWiki

    BEHAVIOR:
    - В EvaWiki создается вложение
    - Внешний url-адрес передается обратно как результат
    """
    content = _load_bytes(source, "url")
    external_url = _create_attachment_from_bytes(
        parent=parent, filename=filename, content=content
    )
    model = AttachmentUploadMetadata(source=source, url=external_url)
    return (
        f"Вложение успешно создано и доступно по ссылке: {external_url}",
        model,
    )


def _load_bytes(source: str, source_type: Literal["file", "url"]) -> bytes:
    if source_type == "file":
        return Path(source).read_bytes()
    if source_type == "url":
        r = httpx.get(source, timeout=60)
        r.raise_for_status()
        return r.content
    raise ValueError(f"Unsupported source_type: {source_type}")


def _create_attachment_from_bytes(parent: str, filename: str, content: bytes):
    content_base64 = base64.b64encode(content).decode("utf-8")
    client = get_api_client()

    if not re.match(r"DOC-\d+", parent):
        #     doc_filter = ["code", "=", parent_code]
        # else:
        raise ValueError("Document code does not correspond to pattern DOC-xxxx")

    file_bytes = base64.b64decode(content_base64)
    size_bytes = len(file_bytes)

    # Шаг 1: Создаем пустое вложение
    cmf_attachment_create_request = CmfAttachmentCreateRequest(
        kwargs=CmfAttachmentCreateRequestKwargs(
            name=filename, parent=parent, size=size_bytes
        ),
    )

    response = client.cmf_attachment_create_without_preload_content(
        cmf_attachment_create_request=cmf_attachment_create_request
    )
    attachment_id: str = process_response(response, dict)
    print(f"attachment_id: {attachment_id}")

    # Шаг 2: Получаем URL для загрузки файла
    cmf_attachment_get_request = CmfAttachmentGetRequest(
        kwargs=CmfAttachmentGetRequestKwargs(
            filter=["id", "==", attachment_id], fields=["url"]
        )
    )
    response = client.cmf_attachment_get_without_preload_content(
        cmf_attachment_get_request=cmf_attachment_get_request
    )
    result_data: dict = process_response(response, dict)
    external_path = result_data["url"]
    print(f"external_url: {external_path}")

    # Шаг 3: Загружаем файл через api_client (urllib3)
    external_url = f"{client.api_client.configuration.host}{external_path}"
    files_params = client.api_client.files_parameters({"file": (filename, file_bytes)})
    auth_headers = {
        v["key"]: v["value"]
        for v in client.api_client.configuration.auth_settings().values()
        if v["in"] == "header"
    }
    r = client.api_client.rest_client.request(
        method="POST",
        url=external_url,
        headers={"Content-Type": "multipart/form-data", **auth_headers},
        post_params=files_params,
    )
    if r.status != 200:
        raise Exception(f"Не удалось загрузить вложение - {r.data.decode('utf-8')}")
    return external_url
