from pathlib import Path

import httpx
from pydantic import Field

from rag_mcp.services.evawiki import get_api_client
from rag_mcp.tools.attachments._models import AttachmentDownloadResult


def evawiki_attachment_download(
    url: str = Field(
        ...,
        description="http(s)-ссылка вложения на сайте EvaWiki",
        examples=["https://evawiki.int.vkusvill.ru/api/attachments/abc123/file.png"],
    ),
    path: str = Field(
        ...,
        description="Локальный путь для сохранения вложения (включая имя файла)",
        examples=["/tmp/file.png", "./downloads/report.pdf"],
    ),
) -> AttachmentDownloadResult:
    """
    Скачивает вложение с сайта EvaWiki и сохраняет его в локальную файловую систему.

    USE THIS TOOL WHEN:
    - нужно скачать вложение из EvaWiki на локальный диск
    - нужно сохранить файл из EvaWiki по его url

    BEHAVIOR:
    - Скачивает файл по указанной ссылке с аутентификацией EvaWiki
    - Сохраняет файл по указанному локальному пути
    - Создаёт родительские директории при необходимости
    """
    client = get_api_client()
    auth_headers = {
        v["key"]: v["value"]
        for v in client.api_client.configuration.auth_settings().values()
        if v["in"] == "header"
    }

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)

    with httpx.stream("GET", url, headers=auth_headers, timeout=120) as response:
        response.raise_for_status()
        with open(target, "wb") as f:
            for chunk in response.iter_bytes(chunk_size=8192):
                f.write(chunk)

    size = target.stat().st_size
    model = AttachmentDownloadResult(url=url, path=str(target), size_bytes=size)
    return (
        f"Вложение успешно скачано и сохранено: {target} ({size} байт)",
        model,
    )
