from evawiki_client import CmfProjectListRequest, CmfTaskListRequestKwargs
from mcp.types import CallToolResult
from pydantic import BaseModel, Field

from rag_mcp.services.evawiki import get_api_client
from rag_mcp.tools.utils import dumps_content, process_response


class ProjectInfoResult(BaseModel):
    """
    Краткие сведения о проекте
    """

    id: str = Field(..., description="Идентификатор проекта")
    code: str = Field(..., description="Код проекта")
    name: str = Field(..., description="Заголовок проекта")


class ProjectListResult(BaseModel):
    """
    Контейнер проектов EvaWiki
    """

    projects: list[ProjectInfoResult] = Field(
        default_factory=list, description="Список с проектами"
    )


def project_list() -> ProjectListResult:
    """Получает список всех доступних проектов EvaWiki.

    USE THIS TOOL WHEN:
    - Вам нужно получить ID или код проекта для использования в других методах
    - Необходимо проверить доступность конкретного проекта

    BEHAVIOR:
    - Возвращает только базовые поля: id, code, name
    - Пустой список означает, что у пользователя нет доступных проектов (это не ошибка)
    """
    client = get_api_client()
    request = CmfProjectListRequest(
        kwargs=CmfTaskListRequestKwargs(fields=["id", "code", "name"])
    )
    response = client.cmf_project_list_without_preload_content(
        cmf_project_list_request=request
    )
    data: list[dict] = process_response(response, list[dict])
    model = build_model_from_response_data(data)
    model_data = model.model_dump(exclude_none=True)
    return (
        f"Найдено {len(model.projects)} проектов: \n {dumps_content(model_data)}",
        model_data,
    )


def build_model_from_response_data(data_list: list[dict]) -> ProjectListResult:
    return ProjectListResult(projects=[ProjectInfoResult(**data) for data in data_list])


# if __name__ == "__main__":
#     print(project_list())
