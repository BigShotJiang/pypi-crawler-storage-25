from evawiki_client import (
    CmfMenuTreeGetTreeRequest,
    CmfMenuTreeGetTreeRequestKwargs,
)
from pydantic import Field

from rag_mcp.services.evawiki import get_api_client
from rag_mcp.tools.utils import dumps_content, process_response


def get_documents_tree_by_project(
    project_id: str = Field(
        ...,
        description="Идентификатор проекта",
    ),
):
    """Получает иерархию разделов и документов по проекту EvaWiki.

    USE THIS TOOL WHEN:
    - Требуется получить структуру всех документов проекта.
    """
    api_instance = get_api_client()
    request = CmfMenuTreeGetTreeRequest(
        kwargs=CmfMenuTreeGetTreeRequestKwargs(
            tree_parent_id=project_id, only_archived=False
        )
    )
    response = api_instance.cmf_menu_tree_get_tree_without_preload_content(
        cmf_menu_tree_get_tree_request=request
    )
    document_nodes: list = process_response(response, list)
    model_data = {"data": build_doc_tree(document_nodes)}

    return (
        f"У проекта {project_id} найдены следующие разделы и документы: \n {dumps_content(model_data)}",
        model_data,
    )


# if __name__ == "__main__":
#     res = get_menu_tree(project_id="CmfProject:8da9665c-8fa2-11f0-b6ae-0242ac110002")
#     print("ok")


def build_doc_tree(document_nodes: list):
    tree_nodes = []
    for node in document_nodes:
        tree_node = {
            "id": node.get("id"),
            "code": node.get("code"),
            "name": node.get("name"),
            # "kind": node.get("ui_name"),
        }

        if node.get("tree_nodes"):
            tree_node["nodes"] = build_doc_tree(node.get("tree_nodes"))

        tree_nodes.append(tree_node)
    return tree_nodes
