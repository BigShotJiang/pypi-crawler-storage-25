import logging
import time

import httpx
from mcp.types import CallToolResult
from pydantic import BaseModel, Field
from rag_mcp.settings import app_settings

from rag_mcp.tools.utils import dumps_content

logger = logging.getLogger(__name__)

POLL_INTERVAL_SECONDS = 3
MAX_POLL_ITERATIONS = 90  # 90 * 3s = 270s max wait


class RagResponseInfo(BaseModel):
    query: str
    output: str


def search_by_query(
    query: str = Field(
        ..., description="Запрос для выполнения семантического поиска в RAG"
    ),
) -> CallToolResult:
    """Выполняет семантический поиск в базе знаний EvaWiki и получить сгенерированный ответ.

    USE THIS TOOL WHEN:
    - Пользователь задаёт вопрос о внутренней документации, процессах или инструкциях EvaWiki.
    - Необходимо найти релевантную информацию по техническому или бизнес-запросу.
    - Требуется получить контекстуальный ответ на основе документов системы.

    INPUT GUIDELINES:
    - query: Естественный язык (русский или английский). Используйте полные вопросы, а не ключевые слова.
    - Для повышения точности уточняйте контекст (например, "как настроить OAuth в админке", а не просто "OAuth").

    BEHAVIOR:
    - Создаёт асинхронную задачу в RAG API и опрашивает результат с интервалом 3 секунды.
    - Максимальное время ожидания — 270 секунд.
    """
    if not query:
        raise ValueError("No query provided")

    response_result = _call_rag_api(query)

    model = RagResponseInfo(query=query, output=response_result or "Ответа нет")
    model_data = model.model_dump(exclude_none=True)
    return dumps_content(model_data), model_data


def _call_rag_api(query: str) -> str:
    base_url = app_settings.evawiki_rag_url.rstrip("/")

    task_id = _submit_task(base_url, query)
    return _poll_task(base_url, task_id)


def _submit_task(base_url: str, query: str) -> str:
    url = f"{base_url}/api/v1/tasks"
    try:
        with httpx.Client(timeout=10.0) as client:
            response = client.post(url, json={"query": query})
            response.raise_for_status()
            data = response.json()
            return data["task_id"]
    except httpx.TimeoutException:
        logger.error("RAG API submit timed out for query: %s", query)
        raise RuntimeError("RAG API submit timed out")
    except httpx.HTTPStatusError as e:
        logger.error(
            "RAG API returned error %s: %s", e.response.status_code, e.response.text
        )
        raise RuntimeError(f"RAG API error: {e.response.status_code}")
    except httpx.ConnectError:
        logger.error("Cannot connect to RAG API at %s", base_url)
        raise RuntimeError(f"Cannot connect to RAG API at {base_url}")


def _poll_task(base_url: str, task_id: str) -> str:
    url = f"{base_url}/api/v1/tasks/{task_id}"
    try:
        with httpx.Client(timeout=10.0) as client:
            for _ in range(MAX_POLL_ITERATIONS):
                response = client.get(url)
                response.raise_for_status()
                data = response.json()
                status = data["status"]

                if status == "succeeded":
                    return data.get("output", "")
                if status == "failed":
                    raise RuntimeError(
                        f"RAG task failed: {data.get('error', 'unknown error')}"
                    )

                time.sleep(POLL_INTERVAL_SECONDS)

            raise RuntimeError("RAG task timed out after 120s")
    except httpx.TimeoutException:
        logger.error("RAG API poll timed out for task: %s", task_id)
        raise RuntimeError("RAG API poll timed out")
    except httpx.HTTPStatusError as e:
        logger.error(
            "RAG API returned error %s: %s", e.response.status_code, e.response.text
        )
        raise RuntimeError(f"RAG API error: {e.response.status_code}")
    except httpx.ConnectError:
        logger.error("Cannot connect to RAG API at %s", base_url)
        raise RuntimeError(f"Cannot connect to RAG API at {base_url}")
