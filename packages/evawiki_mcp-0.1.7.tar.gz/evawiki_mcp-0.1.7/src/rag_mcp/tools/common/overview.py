import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed

from evawiki_client import (
    CmfMenuTreeGetTreeRequest,
    CmfMenuTreeGetTreeRequestKwargs,
    CmfProjectListRequest,
    CmfTaskListRequestKwargs,
)
from rag_mcp.settings import app_settings
from tenacity import retry, stop_after_attempt, wait_exponential

from rag_mcp.services.evawiki import get_api_client
from rag_mcp.tools.documents._models import OverviewInfo, OverviewItemInfo
from rag_mcp.tools.utils import process_response

logger = logging.getLogger(__name__)


def log_retry_stats(retry_state):
    if retry_state.outcome.failed:
        exception = retry_state.outcome.exception()
        logger.warning(
            f"Retrying... Attempt: {retry_state.attempt_number}. "
            f"Exception Type: {type(exception).__name__}. "
            f"Message: {exception}"
        )
        if hasattr(exception, "status_code"):
            logger.warning(f"HTTP Status Code: {exception.status_code}")


@retry(
    wait=wait_exponential(multiplier=1, min=2, max=10),
    stop=stop_after_attempt(100),
    after=log_retry_stats,
    reraise=True,
)
def get_document_tree_for_project(project_info: OverviewItemInfo, api_instance):
    request = CmfMenuTreeGetTreeRequest(
        kwargs=CmfMenuTreeGetTreeRequestKwargs(
            tree_parent_id=project_info.id, only_archived=False, level=1
        )
    )
    response = api_instance.cmf_menu_tree_get_tree_without_preload_content(
        cmf_menu_tree_get_tree_request=request
    )
    document_nodes: list = process_response(response, list)
    for document_data in sorted(
        filter(
            lambda v: (
                v.get("class_name") == "CmfDocument"
                and "orderno" in v
                and "name" in v
                and "code" in v
            ),
            document_nodes,
        ),
        key=lambda x: x["orderno"],
    ):
        project_info.items.append(
            OverviewItemInfo(
                title=document_data.get("name"),
                url=f"{app_settings.evawiki_endpoint}/project/Document/{document_data.get('code')}",
            )
        )
    return project_info


@retry(
    wait=wait_exponential(multiplier=1, min=2, max=10),
    stop=stop_after_attempt(100),
    after=log_retry_stats,
    reraise=True,
)
def call_project_list(api_instance):
    return api_instance.cmf_project_list_without_preload_content(
        cmf_project_list_request=CmfProjectListRequest(
            kwargs=CmfTaskListRequestKwargs()
        )
    )


def get_batch_generator(project_list: list[dict]):
    for project_data in project_list:
        if project_id := project_data.get("project_id"):
            yield OverviewItemInfo(
                id=project_id,
                title=project_data.get("name"),
                url=f"{app_settings.evawiki_endpoint}/project/{project_data.get('code')}",
            )


def get_max_worker_threads():
    count = (os.cpu_count() or 2) / 2 or 1
    return count


def get_overview():
    """Получает двухуровневый обзор справочной системы EvaWiki (проекты → документы первого уровня).

    USE THIS TOOL WHEN:
    - Пользователю нужно навигационное дерево справочной системы.
    - Требуется получить структуру всех проектов и их корневых документов.
    - Необходимо сформировать оглавление для поиска контента.

    INPUT GUIDELINES:
    - Метод не требует входных параметров.
    - Данные получаются через EvaWiki API с а Automatic retry при ошибках (до 100 попыток).

    BEHAVIOR:
    - Возвращает Markdown-форматированную строку с иерархией: # [Проект](url) → - [Документ](url)
    - Параллельно запрашивает дерево документов для каждого проекта (level=1).
    - При ошибке для конкретного проекта продолжает обрабатывать остальные.

    LIMITATIONS & ERRORS:
    - 401 Unauthorized: Недействительный или просроченный API токен EvaWiki.
    - При сетевых ошибках автоматически ретраится с экспоненциальной задержкой (до 100 попыток).
    - Если у проекта нет документов первого уровня, он не включается в результат.
    """

    api_instance = get_api_client()

    overview: OverviewInfo = OverviewInfo()

    response = call_project_list(api_instance)
    project_list: list = process_response(response, list)

    batches = get_batch_generator(project_list)

    futures = {}
    with ThreadPoolExecutor(max_workers=2) as executor:
        for i, project_info in enumerate(batches, start=1):
            future = executor.submit(
                get_document_tree_for_project, project_info, api_instance
            )
            futures[future] = i
        print(f"--- Все задачи ({len(futures)}) добавлены в очередь ---\n")

        for future in as_completed(futures):
            batch_num = futures[future]
            try:
                result = future.result()
                if result.items:
                    overview.items.append(result)

                print(f"Результат получен в пакете: {batch_num}")
            except Exception as e:
                print(f"Ошибка в пакете {batch_num}: {e}")

    output = []

    for item in overview.items:
        output.append(f"# [{item.title.strip()}]({item.url.strip()})\n")
        for doc in item.items:
            output.append(f"- [{doc.title.strip()}]({doc.url.strip()})")
        output.append("")

    str_result = "\n".join(output).strip()
    return str_result, overview.model_dump(exclude_none=True)
