from importlib.metadata import PackageNotFoundError, version

from fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import JSONResponse


def register_routes(server: FastMCP) -> None:
    """Инструменты MCP для сервисных маршрутов."""

    @server.custom_route("/health", methods=["GET"])
    def health_check(request: Request) -> JSONResponse:  # noqa: ARG001
        """Проверка здоровья сервиса.

        Returns:

            JSONResponse: A JSON response with status 'ok' and version information.

        """
        try:
            pkg_version = version("evawiki-rag")
        except PackageNotFoundError:
            pkg_version = "unknown"
        return JSONResponse({"status": "ok", "version": pkg_version})
