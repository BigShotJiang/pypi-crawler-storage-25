import os
from pathlib import Path
from typing import Literal, Optional

from pydantic import SecretStr, computed_field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    evawiki_endpoint: Optional[str] = ""
    evawiki_token: Optional[SecretStr] = None
    evawiki_rag_url: Optional[str] = ""
    evawiki_content_format: Literal["yaml", "json"] = "yaml"

    @computed_field
    @property
    def evawiki_rag_enabled(self) -> bool:
        return isinstance(self.evawiki_rag_url, str) and len(self.evawiki_rag_url) > 0

    model_config = SettingsConfigDict(
        env_file_encoding="utf-8", extra="ignore", validate_default=False
    )


file_name = os.getenv("APP_CONFIG_FILE", ".env.defaults")
app_settings = Settings(_env_file=f"{Path(__file__).resolve().parents[5]}/{file_name}")
print(app_settings.model_dump())
