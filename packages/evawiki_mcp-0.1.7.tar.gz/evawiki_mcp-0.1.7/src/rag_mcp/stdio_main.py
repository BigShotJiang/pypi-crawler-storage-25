from rag_mcp.server_factory import create_mcp_server


def create_server():
    return create_mcp_server(transport_mode="stdio")


def main():
    create_server().run(transport="stdio")


if __name__ == "__main__":
    main()
