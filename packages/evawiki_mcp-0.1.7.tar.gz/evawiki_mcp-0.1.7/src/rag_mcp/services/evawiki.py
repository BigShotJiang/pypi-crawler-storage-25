import os

from evawiki_client import DefaultApi
from evawiki_client.api_client import ApiClient
from evawiki_client.configuration import Configuration
from fastmcp.server.dependencies import get_http_headers

from rag_mcp.settings import app_settings


def resolve_evawiki_credentials() -> tuple[str, str]:
    headers = get_http_headers() or {}

    endpoint = (headers.get("evawiki-endpoint") or "").rstrip("/")
    token = headers.get("evawiki-token") or ""

    if not endpoint:
        endpoint = (app_settings.evawiki_endpoint or "").rstrip("/")

    if not token:
        token = app_settings.evawiki_token.get_secret_value() or ""

    # if app_settings.langfuse.environment == "dev" and not endpoint and not token:
    #     endpoint = app_settings.evawiki.endpoint
    #     token = app_settings.evawiki.token

    if not endpoint or not token:
        missing = []
        if not endpoint:
            missing.append("evawiki-endpoint/EVAWIKI_ENDPOINT")
        if not token:
            missing.append("evawiki-token/EVAWIKI_TOKEN")
        raise ValueError("Missing credentials: " + ", ".join(missing))

    # return "https://evawiki.int.vkusvill.ru", "uB6wtUEFk1ENCKFkLvGA"
    return endpoint, token


def get_api_client() -> DefaultApi:
    """Get configured API client for EvaWiki.

    Reads headers from configuration, validates required headers,
    fetches access token, and returns configured API client.

    Returns:

        ApiClient: Configured API client instance.

    Raises:
        ValueError: If required headers are missing.

    """
    endpoint, token = resolve_evawiki_credentials()
    configuration = Configuration(host=endpoint, access_token=token)
    return DefaultApi(ApiClient(configuration))
