"""reprompt-cli has been renamed to ctxray. Install ctxray instead."""
