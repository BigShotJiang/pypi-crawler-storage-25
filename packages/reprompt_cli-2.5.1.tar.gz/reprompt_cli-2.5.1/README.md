# reprompt-cli has been renamed to ctxray

```bash
pip install ctxray
```

This package now only installs [ctxray](https://pypi.org/project/ctxray/) as a dependency.

See the new repo: https://github.com/ctxray/ctxray
