from fastapi.templating import Jinja2Templates
from auf_deutsch.paths import package_path

templates = Jinja2Templates(directory=str(package_path("templates")))
templates.env.filters["enumerate"] = enumerate
