import json
from pathlib import Path

from auf_deutsch.paths import package_path

PACKS_DIR = package_path("content", "packs")
DIALOGUES_DIR = package_path("content", "dialogues")
STORIES_DIR = package_path("content", "stories")
GRAMMAR_DIR = package_path("content", "grammar")
LISTENING_DIR = package_path("content", "listening")
CURRICULUM_PATH = package_path("content", "curriculum.json")

LEVEL_ORDER = {"A1": 1, "A2": 2, "B1": 3, "B2": 4, "C1": 5, "C2": 6}
PACK_DEFAULTS = {
    "alphabet_spelling": {
        "recommended_order": 10,
        "prerequisites": [],
        "can_do": "Spell your name, email address, and basic details clearly.",
        "focus": "Alphabet, spelling, and contact details",
    },
    "numbers_basics": {
        "recommended_order": 20,
        "prerequisites": ["alphabet_spelling"],
        "can_do": "Understand prices, quantities, and simple numbers in daily life.",
        "focus": "Numbers 0-100 and practical counting",
    },
    "classroom_study": {
        "recommended_order": 25,
        "prerequisites": ["alphabet_spelling"],
        "can_do": "Follow a beginner lesson, ask for help, and handle the most common classroom instructions.",
        "focus": "Course language, study basics, and asking for repetition",
    },
    "greetings": {
        "recommended_order": 30,
        "prerequisites": ["alphabet_spelling"],
        "can_do": "Say hello, introduce yourself, and end a conversation politely.",
        "focus": "Everyday greetings and first-contact phrases",
    },
    "core_verbs": {
        "recommended_order": 40,
        "prerequisites": ["greetings"],
        "can_do": "Use the highest-frequency German verbs to talk about daily actions and needs.",
        "focus": "Essential everyday verbs and simple sentence frames",
    },
    "modal_verbs": {
        "recommended_order": 50,
        "prerequisites": ["core_verbs"],
        "can_do": "Say what you can, want, must, and should do in simple real situations.",
        "focus": "Modal verbs and practical need / ability language",
    },
    "math_basics": {
        "recommended_order": 60,
        "prerequisites": ["numbers_basics"],
        "can_do": "Handle simple calculations, decimals, and percentages in daily situations.",
        "focus": "Basic maths, decimal numbers, and practical calculations",
    },
    "numbers_time": {
        "recommended_order": 70,
        "prerequisites": ["numbers_basics"],
        "can_do": "Ask for the time, understand schedules, and say when something happens.",
        "focus": "Clock time, dates, and time questions",
    },
    "dates_calendar": {
        "recommended_order": 80,
        "prerequisites": ["numbers_basics"],
        "can_do": "Talk about days, dates, and simple calendar plans.",
        "focus": "Days, months, and ordinal dates",
    },
    "family_basics": {
        "recommended_order": 90,
        "prerequisites": ["greetings"],
        "can_do": "Talk simply about family members and relationships.",
        "focus": "Family vocabulary and basic personal talk",
    },
    "adjectives_basics": {
        "recommended_order": 95,
        "prerequisites": ["greetings", "core_verbs"],
        "can_do": "Describe people, places, prices, and situations with useful everyday adjectives.",
        "focus": "High-frequency descriptive adjectives for daily conversation",
    },
    "daily_routine": {
        "recommended_order": 100,
        "prerequisites": ["core_verbs", "numbers_time"],
        "can_do": "Describe your normal day with short, practical sentences.",
        "focus": "Morning-to-evening routine language",
    },
    "home_rooms": {
        "recommended_order": 110,
        "prerequisites": ["family_basics", "core_verbs"],
        "can_do": "Name rooms, furniture, and where things are in a home.",
        "focus": "Rooms, furniture, and location language",
    },
    "core_prepositions": {
        "recommended_order": 115,
        "prerequisites": ["numbers_time", "home_rooms"],
        "can_do": "Use the most useful time and place chunks naturally instead of translating word by word.",
        "focus": "Preposition chunks for time, place, movement, and routine",
    },
    "food_basics": {
        "recommended_order": 120,
        "prerequisites": ["greetings", "numbers_basics"],
        "can_do": "Recognize common food names and buy simple ingredients with confidence.",
        "focus": "Food names, meals, and ingredient vocabulary",
    },
    "cooking_basics": {
        "recommended_order": 130,
        "prerequisites": ["food_basics"],
        "can_do": "Understand simple recipe language and talk about basic cooking steps.",
        "focus": "Kitchen verbs, tools, and simple cooking actions",
    },
    "clothes_basics": {
        "recommended_order": 155,
        "prerequisites": ["home_rooms", "weather_basics"],
        "can_do": "Talk about clothes, sizes, colors, and what you are wearing.",
        "focus": "Clothing vocabulary and fitting-room language",
    },
    "weather_basics": {
        "recommended_order": 150,
        "prerequisites": ["core_verbs", "numbers_time"],
        "can_do": "Understand the weather and connect it to plans, clothes, and travel.",
        "focus": "Weather, temperature, seasons, and forecasts",
    },
    "hobbies_leisure": {
        "recommended_order": 165,
        "prerequisites": ["daily_routine", "feelings"],
        "can_do": "Talk about free time, sports, music, reading, and going out.",
        "focus": "Hobbies, interests, and leisure plans",
    },
    "directions_basics": {
        "recommended_order": 170,
        "prerequisites": ["greetings", "numbers_time"],
        "can_do": "Ask for directions and understand simple route instructions.",
        "focus": "Moving around town and landmarks",
    },
    "city_services_basics": {
        "recommended_order": 175,
        "prerequisites": ["greetings", "directions_basics"],
        "can_do": "Find essential places in town and understand simple direction and service words.",
        "focus": "City places, public services, and basic orientation",
    },
    "transport": {
        "recommended_order": 180,
        "prerequisites": ["numbers_time", "directions_basics"],
        "can_do": "Buy tickets and talk about basic travel situations.",
        "focus": "Stations, transport, and getting around",
    },
    "body_health": {
        "recommended_order": 190,
        "prerequisites": ["greetings", "family_basics"],
        "can_do": "Name common body parts and explain simple health problems.",
        "focus": "Body vocabulary and essential health phrases",
    },
    "feelings": {
        "recommended_order": 200,
        "prerequisites": ["greetings", "body_health"],
        "can_do": "Say how you feel physically and emotionally.",
        "focus": "Feelings, moods, and common reactions",
    },
    "help_clarify": {
        "recommended_order": 210,
        "prerequisites": ["greetings", "alphabet_spelling"],
        "can_do": "Ask people to repeat, slow down, or explain clearly.",
        "focus": "Repair phrases for real conversations",
    },
    "appointments": {
        "recommended_order": 240,
        "prerequisites": ["body_health", "dates_calendar", "help_clarify"],
        "can_do": "Book, move, and confirm simple appointments.",
        "focus": "Scheduling and appointment language",
    },
    "bakery": {
        "recommended_order": 220,
        "prerequisites": ["food_basics", "numbers_basics"],
        "can_do": "Order bread, pastries, and simple items in a bakery.",
        "focus": "Food ordering and quantities",
    },
    "restaurant_cafe": {
        "recommended_order": 225,
        "prerequisites": ["food_basics", "greetings", "numbers_basics"],
        "can_do": "Order food and drinks, ask for the bill, and handle simple cafe or restaurant situations.",
        "focus": "Menus, ordering, reservations, and paying",
    },
    "shopping": {
        "recommended_order": 230,
        "prerequisites": ["greetings", "numbers_basics"],
        "can_do": "Ask for prices, sizes, and basic help in shops.",
        "focus": "Shopping essentials and price language",
    },
    "small_talk": {
        "recommended_order": 250,
        "prerequisites": ["greetings", "daily_routine"],
        "can_do": "Keep a simple conversation going with familiar topics.",
        "focus": "Friendly small talk and social questions",
    },
    "home_tasks": {
        "recommended_order": 260,
        "prerequisites": ["daily_routine", "family_basics", "cooking_basics", "home_rooms"],
        "can_do": "Talk about chores, home needs, and simple problems at home.",
        "focus": "Home, cleaning, and practical daily tasks",
    },
    "making_plans": {
        "recommended_order": 270,
        "prerequisites": ["numbers_time", "dates_calendar", "small_talk"],
        "can_do": "Arrange a meeting and agree on a time and place.",
        "focus": "Invitations, time, and planning together",
    },
    "problems": {
        "recommended_order": 280,
        "prerequisites": ["home_tasks", "help_clarify"],
        "can_do": "Explain small problems and ask for practical help.",
        "focus": "Breakdowns, mistakes, and quick fixes",
    },
    "housing_services": {
        "recommended_order": 290,
        "prerequisites": ["home_tasks", "problems", "appointments"],
        "can_do": "Handle rent, repairs, internet, registration, and other apartment admin tasks.",
        "focus": "Housing, landlord, and service-provider language",
    },
    "work_basics": {
        "recommended_order": 300,
        "prerequisites": ["small_talk", "making_plans"],
        "can_do": "Handle simple work introductions and basic office talk.",
        "focus": "Workplace basics and polite requests",
    },
    "course_office_a2": {
        "recommended_order": 302,
        "prerequisites": ["classroom_study", "appointments", "work_basics"],
        "can_do": "Handle course registration, office questions, certificates, and study logistics in German.",
        "focus": "Language school, study office, deadlines, and course admin",
    },
    "travel_problems_a2": {
        "recommended_order": 305,
        "prerequisites": ["transport", "problems", "making_plans"],
        "can_do": "Handle delays, missed connections, platform changes, and ticket problems in German.",
        "focus": "Travel disruptions, station language, and getting help",
    },
    "opinions": {
        "recommended_order": 310,
        "prerequisites": ["small_talk"],
        "can_do": "Give simple opinions and agree or disagree politely.",
        "focus": "Preferences, opinions, and reactions",
    },
    "social_reactions_a2": {
        "recommended_order": 315,
        "prerequisites": ["small_talk", "opinions"],
        "can_do": "React more naturally, soften disagreement, and keep everyday conversations moving.",
        "focus": "Agreement, hesitation, compromise, and flexible speaking chunks",
    },
    "phone_texting": {
        "recommended_order": 320,
        "prerequisites": ["making_plans", "work_basics"],
        "can_do": "Send short practical messages and manage a quick phone call.",
        "focus": "Messages, calls, and arranging things remotely",
    },
    "public_services_a2": {
        "recommended_order": 325,
        "prerequisites": ["appointments", "housing_services", "phone_texting"],
        "can_do": "Deal with forms, documents, registration offices, banks, and post-office tasks.",
        "focus": "Documents, forms, offices, and service counters",
    },
    "payments_bank_post_a2": {
        "recommended_order": 327,
        "prerequisites": ["shopping", "public_services_a2"],
        "can_do": "Pay, send parcels, solve card issues, and handle simple bank and post-office tasks.",
        "focus": "Payments, parcels, bank counters, and receipt language",
    },
    "everyday_verbs_a2": {
        "recommended_order": 329,
        "prerequisites": ["work_basics", "phone_texting"],
        "can_do": "Use the next layer of practical A2 verbs for admin, plans, tasks, and daily coordination.",
        "focus": "High-frequency A2 action verbs and real-life use patterns",
    },
    "verb_patterns_a2": {
        "recommended_order": 330,
        "prerequisites": ["modal_verbs", "small_talk", "opinions"],
        "can_do": "Use common A2 verb frames with the right prepositions, reflexive forms, and objects.",
        "focus": "Verb-preposition patterns and reusable sentence frames",
    },
    "separable_verbs_a2": {
        "recommended_order": 340,
        "prerequisites": ["verb_patterns_a2", "phone_texting", "appointments"],
        "can_do": "Handle common A2 actions like calling back, cancelling, filling out forms, bringing things, and coming by.",
        "focus": "High-value separable verbs for admin, work, and daily coordination",
    },
}

_packs_cache: list = []
_dialogues_cache: list = []
_stories_cache: list = []
_grammar_tracks_cache: list = []
_grammar_lessons_cache: list = []
_listening_cache: list = []
_curriculum_levels_cache: list = []
_phrase_index: dict = {}
_pack_index: dict = {}
_phrase_to_pack: dict = {}
_grammar_lesson_index: dict = {}
_listening_index: dict = {}
_curriculum_pack_index: dict = {}


def _level_rank(level: str | None) -> int:
    return LEVEL_ORDER.get((level or "").upper(), 999)


def level_matches(item_level: str | None, max_level: str | None) -> bool:
    if not max_level:
        return True
    return _level_rank(item_level) <= _level_rank(max_level)


def _normalize_phrase(phrase: dict) -> dict:
    normalized = dict(phrase)
    if not normalized.get("usage") and normalized.get("usage_note"):
        normalized["usage"] = normalized["usage_note"]
    if not normalized.get("examples") and (normalized.get("example_de") or normalized.get("example_en")):
        normalized["examples"] = [{
            "de": normalized.get("example_de", ""),
            "en": normalized.get("example_en", ""),
        }]
    normalized.setdefault("examples", [])
    normalized.setdefault("variations", [])
    normalized.setdefault("related_ids", [])
    normalized.setdefault("tags", [])
    return normalized


def _normalize_pack(pack: dict) -> dict:
    normalized = dict(pack)
    defaults = PACK_DEFAULTS.get(normalized.get("pack_id", ""), {})
    curriculum_meta = _curriculum_pack_index.get(normalized.get("pack_id", ""), {})
    if not normalized.get("pack_name") and normalized.get("name"):
        normalized["pack_name"] = normalized["name"]
    if not normalized.get("cover_emoji") and normalized.get("emoji"):
        normalized["cover_emoji"] = normalized["emoji"]
    if not normalized.get("situation") and normalized.get("description"):
        normalized["situation"] = normalized["description"]
    if "recommended_order" not in normalized and "recommended_order" in defaults:
        normalized["recommended_order"] = defaults["recommended_order"]
    if "prerequisites" not in normalized and "prerequisites" in defaults:
        normalized["prerequisites"] = list(defaults["prerequisites"])
    if not normalized.get("can_do") and "can_do" in defaults:
        normalized["can_do"] = defaults["can_do"]
    if not normalized.get("focus") and "focus" in defaults:
        normalized["focus"] = defaults["focus"]
    normalized.setdefault("curriculum_level", curriculum_meta.get("curriculum_level", normalized.get("level", "")))
    normalized.setdefault("curriculum_level_title", curriculum_meta.get("curriculum_level_title", normalized.get("level", "")))
    normalized.setdefault("curriculum_group_id", curriculum_meta.get("curriculum_group_id", ""))
    normalized.setdefault("curriculum_group_title", curriculum_meta.get("curriculum_group_title", ""))
    normalized.setdefault("curriculum_group_summary", curriculum_meta.get("curriculum_group_summary", ""))
    normalized.setdefault("curriculum_group_order", curriculum_meta.get("curriculum_group_order", 999))
    normalized.setdefault("pack_name", normalized.get("pack_id", "Pack"))
    normalized.setdefault("cover_emoji", "📚")
    normalized.setdefault("situation", "")
    normalized.setdefault("recommended_order", 999)
    normalized.setdefault("prerequisites", [])
    normalized.setdefault("can_do", "Build a practical new German skill in this situation.")
    normalized.setdefault("focus", normalized["situation"] or "Practical everyday German")
    normalized["phrases"] = [_normalize_phrase(phrase) for phrase in normalized.get("phrases", [])]
    return normalized


def _normalize_curriculum_level(level_data: dict) -> dict:
    normalized = dict(level_data)
    normalized.setdefault("level", "A1")
    normalized.setdefault("title", normalized["level"])
    normalized.setdefault("description", "")
    groups = []
    for index, group in enumerate(normalized.get("groups", []), start=1):
        item = dict(group)
        item.setdefault("group_id", item.get("id", f"{normalized['level'].lower()}_group_{index}"))
        item.setdefault("title", item["group_id"].replace("_", " ").title())
        item.setdefault("summary", "")
        item.setdefault("pack_ids", [])
        item.setdefault("order", index * 10)
        item["level"] = normalized["level"]
        item["level_title"] = normalized["title"]
        item["level_description"] = normalized["description"]
        groups.append(item)
    groups.sort(key=lambda item: (item.get("order", 999), item.get("title", "")))
    normalized["groups"] = groups
    return normalized


def _load_curriculum():
    global _curriculum_levels_cache, _curriculum_pack_index
    _curriculum_levels_cache = []
    _curriculum_pack_index = {}

    if not CURRICULUM_PATH.exists():
        return

    try:
        data = json.loads(CURRICULUM_PATH.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"[content] Error loading curriculum {CURRICULUM_PATH}: {exc}")
        return

    for level_data in data.get("levels", []):
        level = _normalize_curriculum_level(level_data)
        _curriculum_levels_cache.append(level)
        for group in level.get("groups", []):
            for pack_id in group.get("pack_ids", []):
                _curriculum_pack_index[pack_id] = {
                    "curriculum_level": level["level"],
                    "curriculum_level_title": level["title"],
                    "curriculum_group_id": group["group_id"],
                    "curriculum_group_title": group["title"],
                    "curriculum_group_summary": group["summary"],
                    "curriculum_group_order": group["order"],
                }

    _curriculum_levels_cache.sort(key=lambda item: _level_rank(item.get("level")))


def _normalize_dialogue(dialogue: dict) -> dict:
    normalized = dict(dialogue)
    normalized.setdefault("lines", [])
    return normalized


def _normalize_story(story: dict) -> dict:
    normalized = dict(story)
    paragraphs = []
    for paragraph in normalized.get("paragraphs", []):
        para = dict(paragraph)
        highlights = []
        for highlight in para.get("highlighted_phrases", []):
            item = dict(highlight)
            if not item.get("phrase_id") and item.get("id"):
                item["phrase_id"] = item["id"]
            if not item.get("usage") and item.get("usage_note"):
                item["usage"] = item["usage_note"]
            highlights.append(item)
        para["highlighted_phrases"] = highlights
        paragraphs.append(para)

    questions = []
    for question in normalized.get("comprehension_questions", []):
        item = dict(question)
        if not item.get("question_de") and item.get("de"):
            item["question_de"] = item["de"]
        if not item.get("question_en") and item.get("en"):
            item["question_en"] = item["en"]
        questions.append(item)

    normalized.setdefault("cover_emoji", "📖")
    normalized.setdefault("situation", "")
    normalized["paragraphs"] = paragraphs
    normalized["comprehension_questions"] = questions
    normalized.setdefault("vocab_spotlight", [])
    return normalized


def _normalize_listening_exercise(exercise: dict) -> dict:
    normalized = dict(exercise)
    normalized.setdefault("exercise_id", normalized.get("id", "listening_exercise"))
    normalized.setdefault("title", "Listening Exercise")
    normalized.setdefault("level", "A1")
    normalized.setdefault("cover_emoji", "🎧")
    normalized.setdefault("situation", "")
    normalized.setdefault("focus", "")
    normalized.setdefault("estimated_minutes", 5)
    normalized.setdefault("lines", [])
    normalized.setdefault("questions", [])
    normalized.setdefault("related_pack_ids", [])
    normalized.setdefault("tips", [])
    normalized.setdefault("recommended_order", 999)
    return normalized


def _normalize_grammar_lesson(lesson: dict, track: dict) -> dict:
    normalized = dict(lesson)
    normalized.setdefault("lesson_id", normalized.get("id", "grammar_lesson"))
    normalized.setdefault("title", "Grammar Lesson")
    normalized.setdefault("level", track.get("level", "A1"))
    normalized.setdefault("category", "grammar")
    normalized.setdefault("summary", "")
    normalized.setdefault("why_it_matters", "")
    normalized.setdefault("memory_hook", "")
    normalized.setdefault("pattern", "")
    normalized.setdefault("core_rules", [])
    normalized.setdefault("quick_frames", [])
    normalized.setdefault("important_verbs", [])
    normalized.setdefault("connector_map", [])
    normalized.setdefault("preposition_map", [])
    normalized.setdefault("examples", [])
    normalized.setdefault("common_mistakes", [])
    normalized.setdefault("micro_drills", [])
    normalized.setdefault("real_life_mission", "")
    normalized.setdefault("related_pack_ids", [])
    normalized.setdefault("related_lessons", [])
    normalized.setdefault("estimated_minutes", 8)
    normalized.setdefault("order", 999)
    normalized["track_id"] = track["track_id"]
    normalized["track_title"] = track["title"]
    return normalized


def _normalize_grammar_track(track: dict) -> dict:
    normalized = dict(track)
    normalized.setdefault("track_id", normalized.get("id", "grammar_track"))
    normalized.setdefault("title", normalized.get("track_id", "Grammar Track"))
    normalized.setdefault("level", "A1")
    normalized.setdefault("intro", "")
    normalized.setdefault("outcomes", [])
    lessons = []
    for lesson in normalized.get("lessons", []):
        lessons.append(_normalize_grammar_lesson(lesson, normalized))
    lessons.sort(key=lambda item: (item.get("order", 999), item.get("title", "")))
    normalized["lessons"] = lessons
    return normalized


def load_all():
    global _packs_cache, _dialogues_cache, _stories_cache, _grammar_tracks_cache, _grammar_lessons_cache
    global _listening_cache, _curriculum_levels_cache, _phrase_index, _pack_index, _phrase_to_pack
    global _grammar_lesson_index, _listening_index, _curriculum_pack_index
    _packs_cache = []
    _dialogues_cache = []
    _stories_cache = []
    _grammar_tracks_cache = []
    _grammar_lessons_cache = []
    _listening_cache = []
    _curriculum_levels_cache = []
    _phrase_index = {}
    _pack_index = {}
    _phrase_to_pack = {}
    _grammar_lesson_index = {}
    _listening_index = {}
    _curriculum_pack_index = {}

    _load_curriculum()

    for f in sorted(PACKS_DIR.glob("*.json")):
        try:
            pack = _normalize_pack(json.loads(f.read_text(encoding="utf-8")))
            _packs_cache.append(pack)
            _pack_index[pack["pack_id"]] = pack
            for phrase in pack.get("phrases", []):
                _phrase_index[phrase["id"]] = phrase
                _phrase_to_pack[phrase["id"]] = pack["pack_id"]
        except Exception as e:
            print(f"[content] Error loading pack {f}: {e}")

    for f in sorted(DIALOGUES_DIR.glob("*.json")):
        try:
            dialogue = _normalize_dialogue(json.loads(f.read_text(encoding="utf-8")))
            _dialogues_cache.append(dialogue)
        except Exception as e:
            print(f"[content] Error loading dialogue {f}: {e}")

    if STORIES_DIR.exists():
        for f in sorted(STORIES_DIR.glob("*.json")):
            try:
                story = _normalize_story(json.loads(f.read_text(encoding="utf-8")))
                _stories_cache.append(story)
            except Exception as e:
                print(f"[content] Error loading story {f}: {e}")

    if GRAMMAR_DIR.exists():
        for f in sorted(GRAMMAR_DIR.glob("*.json")):
            try:
                track = _normalize_grammar_track(json.loads(f.read_text(encoding="utf-8")))
                _grammar_tracks_cache.append(track)
                for lesson in track.get("lessons", []):
                    _grammar_lessons_cache.append(lesson)
                    _grammar_lesson_index[lesson["lesson_id"]] = lesson
            except Exception as e:
                print(f"[content] Error loading grammar track {f}: {e}")

    if LISTENING_DIR.exists():
        for f in sorted(LISTENING_DIR.glob("*.json")):
            try:
                exercise = _normalize_listening_exercise(json.loads(f.read_text(encoding="utf-8")))
                _listening_cache.append(exercise)
                _listening_index[exercise["exercise_id"]] = exercise
            except Exception as e:
                print(f"[content] Error loading listening exercise {f}: {e}")

    print(
        f"[content] Loaded {len(_packs_cache)} packs, {len(_dialogues_cache)} dialogues, "
        f"{len(_stories_cache)} stories, {len(_grammar_lessons_cache)} grammar lessons, "
        f"{len(_listening_cache)} listening exercises, {len(_phrase_index)} phrases."
    )


def get_all_packs() -> list:
    return _packs_cache


def get_pack(pack_id: str) -> dict | None:
    return _pack_index.get(pack_id)


def get_phrase(phrase_id: str) -> dict | None:
    return _phrase_index.get(phrase_id)


def get_all_dialogues() -> list:
    return _dialogues_cache


def get_dialogues_for_pack(pack_id: str, max_level: str | None = None) -> list:
    return [
        dialogue for dialogue in _dialogues_cache
        if dialogue.get("pack_id") == pack_id and level_matches(dialogue.get("level"), max_level)
    ]


def get_all_phrase_ids() -> list:
    return list(_phrase_index.keys())


def get_phrase_pack_id(phrase_id: str) -> str | None:
    return _phrase_to_pack.get(phrase_id)


def get_packs_for_level(max_level: str | None) -> list:
    return [pack for pack in _packs_cache if level_matches(pack.get("level"), max_level)]


def get_all_stories() -> list:
    return _stories_cache


def get_story(story_id: str) -> dict | None:
    for s in _stories_cache:
        if s["story_id"] == story_id:
            return s
    return None


def get_all_grammar_tracks() -> list:
    return _grammar_tracks_cache


def get_all_grammar_lessons() -> list:
    return _grammar_lessons_cache


def get_grammar_lessons_for_level(max_level: str | None) -> list:
    return [
        lesson for lesson in _grammar_lessons_cache
        if level_matches(lesson.get("level"), max_level)
    ]


def get_grammar_track(track_id: str) -> dict | None:
    for track in _grammar_tracks_cache:
        if track["track_id"] == track_id:
            return track
    return None


def get_grammar_lesson(lesson_id: str) -> dict | None:
    return _grammar_lesson_index.get(lesson_id)


def get_all_listening_exercises() -> list:
    return _listening_cache


def get_listening_exercise(exercise_id: str) -> dict | None:
    return _listening_index.get(exercise_id)


def get_listening_for_level(max_level: str | None) -> list:
    return [
        exercise for exercise in _listening_cache
        if level_matches(exercise.get("level"), max_level)
    ]


def get_curriculum_levels(max_level: str | None = None) -> list:
    if not max_level:
        return _curriculum_levels_cache
    return [
        level for level in _curriculum_levels_cache
        if level_matches(level.get("level"), max_level)
    ]
