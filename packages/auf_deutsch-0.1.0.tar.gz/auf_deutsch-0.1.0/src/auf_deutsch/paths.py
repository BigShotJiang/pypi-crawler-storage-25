from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path

APP_DIR_NAME = "auf-deutsch"
PACKAGE_ROOT = Path(__file__).resolve().parent


def package_path(*parts: str) -> Path:
    return PACKAGE_ROOT.joinpath(*parts)


def _user_data_root() -> Path:
    explicit = os.getenv("AUF_DATA_DIR")
    if explicit:
        return Path(explicit).expanduser()
    home = Path.home()
    if sys.platform == "win32":
        base = Path(os.getenv("LOCALAPPDATA") or os.getenv("APPDATA") or (home / "AppData" / "Local"))
    elif sys.platform == "darwin":
        base = home / "Library" / "Application Support"
    else:
        base = Path(os.getenv("XDG_DATA_HOME") or (home / ".local" / "share"))
    return base / APP_DIR_NAME


def user_data_path(*parts: str) -> Path:
    root = _user_data_root().expanduser()
    root.mkdir(parents=True, exist_ok=True)
    return root.joinpath(*parts)


def runtime_static_dir() -> Path:
    static_dir = user_data_path("static")
    static_dir.mkdir(parents=True, exist_ok=True)
    (static_dir / "audio").mkdir(parents=True, exist_ok=True)
    return static_dir


def ensure_runtime_static_assets() -> Path:
    source_dir = package_path("static")
    target_dir = runtime_static_dir()
    for source in source_dir.rglob("*"):
        if source.is_dir():
            continue
        relative = source.relative_to(source_dir)
        target = target_dir / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists() or source.stat().st_mtime > target.stat().st_mtime:
            shutil.copy2(source, target)
    return target_dir
