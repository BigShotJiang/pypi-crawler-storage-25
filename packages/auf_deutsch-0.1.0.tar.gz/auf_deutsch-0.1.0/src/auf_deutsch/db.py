import os
import sqlite3
from datetime import date
from pathlib import Path

from auf_deutsch.paths import user_data_path

DB_PATH = Path(os.getenv("AUF_DB_PATH")).expanduser() if os.getenv("AUF_DB_PATH") else user_data_path("progress.db")


def get_db():
    import time as _time
    for attempt in range(2):
        try:
            DB_PATH.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(DB_PATH), timeout=5)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            return conn
        except sqlite3.OperationalError as e:
            if attempt == 0 and "locked" in str(e).lower():
                _time.sleep(0.25)
                continue
            raise


def init_db():
    conn = get_db()
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS phrase_progress (
            phrase_id TEXT PRIMARY KEY,
            status TEXT DEFAULT 'new',
            ease_score REAL DEFAULT 2.5,
            interval_days INTEGER DEFAULT 0,
            due_date TEXT DEFAULT NULL,
            review_count INTEGER DEFAULT 0,
            lapse_count INTEGER DEFAULT 0,
            last_reviewed TEXT DEFAULT NULL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS session_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            phrases_reviewed INTEGER DEFAULT 0,
            phrases_learned INTEGER DEFAULT 0,
            duration_seconds INTEGER DEFAULT 0,
            completed INTEGER DEFAULT 0
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS story_progress (
            story_id TEXT PRIMARY KEY,
            date_read TEXT NOT NULL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS pack_quiz_attempt (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pack_id TEXT NOT NULL,
            date_taken TEXT NOT NULL,
            score INTEGER NOT NULL,
            total INTEGER NOT NULL
        )
    """)

    # Default settings
    defaults = {
        "daily_goal": "5",
        "level": "A1",
        "reminder_time": "19:00",
        "notifications_enabled": "false",
        "ui_lang": "en",
    }
    for k, v in defaults.items():
        c.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))

    conn.commit()
    conn.close()


def get_setting(key: str, default=None):
    conn = get_db()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key: str, value: str):
    conn = get_db()
    conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
    conn.commit()
    conn.close()


def get_phrase_progress(phrase_id: str):
    conn = get_db()
    row = conn.execute("SELECT * FROM phrase_progress WHERE phrase_id=?", (phrase_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def ensure_phrase_progress(phrase_id: str):
    conn = get_db()
    conn.execute(
        "INSERT OR IGNORE INTO phrase_progress (phrase_id) VALUES (?)", (phrase_id,)
    )
    conn.commit()
    conn.close()


def get_all_progress():
    conn = get_db()
    rows = conn.execute("SELECT * FROM phrase_progress").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_due_phrases(limit=5):
    today = date.today().isoformat()
    conn = get_db()
    rows = conn.execute(
        """SELECT phrase_id FROM phrase_progress
           WHERE status IN ('learning', 'review')
           AND (due_date IS NULL OR due_date <= ?)
           ORDER BY due_date ASC, last_reviewed ASC
           LIMIT ?""",
        (today, limit),
    ).fetchall()
    conn.close()
    return [r["phrase_id"] for r in rows]


def get_new_phrases_not_in_progress(all_phrase_ids: list, limit=2):
    conn = get_db()
    known = set(
        r["phrase_id"] for r in conn.execute("SELECT phrase_id FROM phrase_progress").fetchall()
    )
    conn.close()
    result = [pid for pid in all_phrase_ids if pid not in known]
    return result[:limit]


def get_weak_phrases(limit=3):
    conn = get_db()
    rows = conn.execute(
        """SELECT phrase_id FROM phrase_progress
           WHERE status NOT IN ('new')
           ORDER BY ease_score ASC, lapse_count DESC
           LIMIT ?""",
        (limit,),
    ).fetchall()
    conn.close()
    return [r["phrase_id"] for r in rows]


def log_session_start():
    today = date.today().isoformat()
    conn = get_db()
    c = conn.cursor()
    c.execute(
        "INSERT INTO session_log (date, phrases_reviewed, phrases_learned, duration_seconds, completed) VALUES (?,0,0,0,0)",
        (today,),
    )
    session_id = c.lastrowid
    conn.commit()
    conn.close()
    return session_id


def update_session_log(session_id: int, **kwargs):
    if not kwargs:
        return
    sets = ", ".join(f"{k}=?" for k in kwargs)
    vals = list(kwargs.values()) + [session_id]
    conn = get_db()
    conn.execute(f"UPDATE session_log SET {sets} WHERE id=?", vals)
    conn.commit()
    conn.close()


def get_session_history(days=7):
    conn = get_db()
    rows = conn.execute(
        """SELECT date, SUM(phrases_reviewed) as reviewed, SUM(phrases_learned) as learned,
           SUM(duration_seconds) as duration, MAX(completed) as completed
           FROM session_log
           WHERE date >= date('now', ?)
           GROUP BY date ORDER BY date ASC""",
        (f"-{days} days",),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_review_streak():
    conn = get_db()
    rows = conn.execute(
        """SELECT DISTINCT date FROM session_log
           WHERE phrases_reviewed > 0 OR phrases_learned > 0
           ORDER BY date DESC"""
    ).fetchall()
    conn.close()
    if not rows:
        return 0
    streak = 0
    today = date.today()
    for i, row in enumerate(rows):
        d = date.fromisoformat(row["date"])
        expected = today - __import__("datetime").timedelta(days=i)
        if d == expected:
            streak += 1
        else:
            break
    return streak


def get_session_completed_today() -> bool:
    today = date.today().isoformat()
    conn = get_db()
    row = conn.execute(
        "SELECT COUNT(*) as cnt FROM session_log WHERE date=? AND completed=1",
        (today,),
    ).fetchone()
    conn.close()
    return (row["cnt"] if row else 0) > 0


def reset_all_progress():
    conn = get_db()
    conn.execute("DELETE FROM phrase_progress")
    conn.execute("DELETE FROM session_log")
    conn.execute("DELETE FROM story_progress")
    conn.execute("DELETE FROM pack_quiz_attempt")
    conn.commit()
    conn.close()


def log_story_read(story_id: str):
    today = date.today().isoformat()
    conn = get_db()
    conn.execute(
        "INSERT OR REPLACE INTO story_progress (story_id, date_read) VALUES (?, ?)",
        (story_id, today),
    )
    conn.execute(
        "INSERT INTO session_log (date, phrases_reviewed, phrases_learned, duration_seconds, completed) VALUES (?,0,0,0,1)",
        (today,),
    )
    conn.commit()
    conn.close()


def get_read_story_ids() -> set:
    conn = get_db()
    rows = conn.execute("SELECT story_id FROM story_progress").fetchall()
    conn.close()
    return {r["story_id"] for r in rows}


def get_total_learned():
    conn = get_db()
    row = conn.execute(
        "SELECT COUNT(*) as cnt FROM phrase_progress WHERE status IN ('review','mastered')"
    ).fetchone()
    conn.close()
    return row["cnt"] if row else 0


def log_pack_quiz_attempt(pack_id: str, score: int, total: int):
    today = date.today().isoformat()
    conn = get_db()
    conn.execute(
        "INSERT INTO pack_quiz_attempt (pack_id, date_taken, score, total) VALUES (?, ?, ?, ?)",
        (pack_id, today, score, total),
    )
    conn.commit()
    conn.close()


def get_latest_pack_quiz_attempts() -> dict[str, dict]:
    conn = get_db()
    rows = conn.execute(
        """
        SELECT a.pack_id, a.date_taken, a.score, a.total
        FROM pack_quiz_attempt a
        INNER JOIN (
            SELECT pack_id, MAX(id) AS latest_id
            FROM pack_quiz_attempt
            GROUP BY pack_id
        ) latest ON latest.latest_id = a.id
        """
    ).fetchall()
    conn.close()
    return {row["pack_id"]: dict(row) for row in rows}
