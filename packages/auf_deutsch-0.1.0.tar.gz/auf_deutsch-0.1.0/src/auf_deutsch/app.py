import os
import webbrowser
import threading
from datetime import datetime, date
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.exceptions import HTTPException
import uvicorn

from auf_deutsch import content_loader, db, learning_engine
from auf_deutsch.audio_gen import clean_audio_cache, generate_all_audio
from auf_deutsch.paths import ensure_runtime_static_assets, runtime_static_dir
from auf_deutsch.routers import authoring as authoring_router
from auf_deutsch.routers import grammar as grammar_router
from auf_deutsch.routers import listening as listening_router
from auf_deutsch.routers import packs as packs_router
from auf_deutsch.routers import progress as progress_router
from auf_deutsch.routers import session as session_router
from auf_deutsch.routers import stories as stories_router
from auf_deutsch.routers import vocabulary as vocabulary_router
from auf_deutsch.template_env import templates

app = FastAPI(title="Auf Deutsch")

_SESSION_SIZES = {
    "5": {"due": 5, "new": 2},
    "10": {"due": 8, "new": 3},
    "15": {"due": 12, "new": 4},
}
ensure_runtime_static_assets()
app.mount("/static", StaticFiles(directory=str(runtime_static_dir())), name="static")

app.include_router(session_router.router)
app.include_router(packs_router.router)
app.include_router(progress_router.router)
app.include_router(stories_router.router)
app.include_router(authoring_router.router)
app.include_router(grammar_router.router)
app.include_router(listening_router.router)
app.include_router(vocabulary_router.router)

# Greeting pools rotated by day-of-month (3 per slot → no repeat within 3 days)
_GREETINGS = {
    "morning": [
        ("Guten Morgen", "Good morning — ready to learn?"),
        ("Moin!", "Morning! Let's do some German."),
        ("Guten Morgen", "Good morning — your words are waiting."),
    ],
    "afternoon": [
        ("Guten Tag", "Good afternoon — time for a quick session?"),
        ("Hallo", "Hello! A few minutes of German today?"),
        ("Servus!", "Hey there! (Bavarian/Austrian)"),
    ],
    "evening": [
        ("Guten Abend", "Good evening — end the day with German!"),
        ("Na?", "Hey — ready to practise?"),
        ("Guten Abend", "Good evening — just 5 minutes before bed?"),
    ],
}


@app.on_event("startup")
async def startup():
    db.init_db()
    content_loader.load_all()
    clean_audio_cache()
    if os.getenv("AUF_SKIP_STARTUP_AUDIO", "").strip().lower() not in {"1", "true", "yes", "on"}:
        generate_all_audio(
            content_loader.get_all_packs(),
            content_loader.get_all_dialogues(),
            content_loader.get_all_listening_exercises(),
        )
    print(f"[app] Auf Deutsch is running at {os.getenv('AUF_BROWSER_URL', 'http://127.0.0.1:8000')}")


@app.exception_handler(404)
async def not_found(request: Request, exc: HTTPException):
    return templates.TemplateResponse("404.html", {"request": request}, status_code=404)


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    selected_level = db.get_setting("level", "A1")
    daily_goal = db.get_setting("daily_goal", "5")
    session_size = _SESSION_SIZES.get(daily_goal, _SESSION_SIZES["5"])

    packs = content_loader.get_all_packs()
    visible_packs = content_loader.get_packs_for_level(selected_level) or packs
    has_content = len(packs) > 0
    visible_phrase_ids = {ph["id"] for pack in visible_packs for ph in pack["phrases"]}
    all_progress_rows = db.get_all_progress()
    pack_cards = learning_engine.annotate_packs(visible_packs, all_progress_rows)

    due = learning_engine.filter_due_phrase_ids(
        db.get_due_phrases(limit=session_size["due"] * 3),
        visible_phrase_ids,
        session_size["due"],
    )
    new_ids = learning_engine.choose_new_phrase_ids(pack_cards, all_progress_rows, session_size["new"])
    weak = db.get_weak_phrases(limit=3)
    weak_phrases = []
    for pid in weak:
        phrase = content_loader.get_phrase(pid)
        pack_id = content_loader.get_phrase_pack_id(pid)
        if phrase and (not pack_id or pack_id in {pack["pack_id"] for pack in visible_packs}):
            weak_phrases.append(phrase)

    all_done = has_content and len(due) == 0 and len(new_ids) == 0

    hour = datetime.now().hour
    day_idx = date.today().day % 3
    slot = "morning" if hour < 12 else ("afternoon" if hour < 18 else "evening")
    greeting_de, greeting_en = _GREETINGS[slot][day_idx]

    estimated_minutes = max(1, (len(due) * 30 + len(new_ids) * 60 + 90) // 60)

    reminder_time = db.get_setting("reminder_time", "19:00")
    notifications_enabled = db.get_setting("notifications_enabled", "false")
    streak = db.get_review_streak()
    session_done_today = db.get_session_completed_today()
    recent_history = db.get_session_history(days=7)
    weekly_snapshot = learning_engine.build_weekly_consistency(recent_history, daily_goal)

    now_hm = datetime.now().strftime("%H:%M")
    show_reminder_banner = (
        notifications_enabled == "true"
        and now_hm >= reminder_time
        and not session_done_today
    )

    stories = [
        story for story in content_loader.get_all_stories()
        if content_loader.level_matches(story.get("level"), selected_level)
    ]
    read_ids = db.get_read_story_ids()
    story_cards = [{
        **s,
        "read_time": s.get("read_time_minutes", max(2, len(s.get("paragraphs", [])))),
        "is_read": s["story_id"] in read_ids,
    } for s in stories]
    next_story = next((story for story in story_cards if not story["is_read"]), story_cards[0] if story_cards else None)

    starter_cards = [card for card in pack_cards if card.get("recommended_order", 999) <= 100][:7]
    recommended_pack = learning_engine.get_recommended_pack(pack_cards)
    today_plan = learning_engine.build_today_plan(
        len(due),
        len(new_ids),
        recommended_pack,
        story_cards,
        session_done_today,
    )
    practical_wins = learning_engine.collect_practical_wins(pack_cards)
    habit_hint = learning_engine.build_habit_hint(reminder_time)

    return templates.TemplateResponse("home.html", {
        "request": request,
        "greeting_de": greeting_de,
        "greeting_en": greeting_en,
        "selected_level": selected_level,
        "daily_goal": daily_goal,
        "streak": streak,
        "due_count": len(due),
        "new_count": len(new_ids),
        "estimated_minutes": estimated_minutes,
        "all_done": all_done,
        "has_content": has_content,
        "weak_phrases": weak_phrases,
        "starter_cards": starter_cards,
        "recommended_pack": recommended_pack,
        "pack_cards": pack_cards,
        "story_cards": story_cards,
        "next_story": next_story,
        "today_plan": today_plan,
        "practical_wins": practical_wins,
        "weekly_snapshot": weekly_snapshot,
        "habit_hint": habit_hint,
        "reminder_time": reminder_time,
        "notifications_enabled": notifications_enabled,
        "session_done_today": session_done_today,
        "show_reminder_banner": show_reminder_banner,
    })


def open_browser():
    import time
    time.sleep(1.2)
    webbrowser.open(os.getenv("AUF_BROWSER_URL", "http://127.0.0.1:8000"))


def run_server(host: str = "127.0.0.1", port: int = 8000, open_browser_on_start: bool = True):
    if open_browser_on_start:
        t = threading.Thread(target=open_browser, daemon=True)
        t.start()
    uvicorn.run("auf_deutsch.app:app", host=host, port=port, reload=False)


if __name__ == "__main__":
    should_open_browser = os.getenv("AUF_OPEN_BROWSER", "1").strip().lower() not in {"0", "false", "no", "off"}
    run_server(host="127.0.0.1", port=8000, open_browser_on_start=should_open_browser)
