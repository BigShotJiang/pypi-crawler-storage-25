import random
from typing import Any

PACK_UNLOCK_THRESHOLD = 70
WEEKLY_TARGETS = {"5": 4, "10": 5, "15": 6}


def is_learned_status(status: str | None) -> bool:
    return status in ("review", "mastered")


def build_progress_map(progress_rows: list[dict]) -> dict[str, dict]:
    return {row["phrase_id"]: row for row in progress_rows}


def annotate_packs(packs: list[dict], progress_rows: list[dict]) -> list[dict]:
    progress_map = build_progress_map(progress_rows)

    annotated = []
    for pack in sorted(packs, key=lambda item: (item.get("recommended_order", 999), item.get("pack_name", ""))):
        total = len(pack.get("phrases", []))
        learned = sum(
            1 for phrase in pack.get("phrases", [])
            if is_learned_status(progress_map.get(phrase["id"], {}).get("status"))
        )
        pct = int(learned / total * 100) if total else 0
        annotated.append({
            **pack,
            "total": total,
            "learned": learned,
            "pct": pct,
        })

    by_id = {pack["pack_id"]: pack for pack in annotated}
    result = []
    for pack in annotated:
        prerequisites = pack.get("prerequisites", [])
        blocked_by = []
        for prerequisite_id in prerequisites:
            prerequisite = by_id.get(prerequisite_id)
            if prerequisite and prerequisite["pct"] < PACK_UNLOCK_THRESHOLD:
                blocked_by.append(prerequisite)

        result.append({
            **pack,
            "unlocked": len(blocked_by) == 0,
            "blocked_by": blocked_by,
            "is_complete": pack["pct"] >= 100,
            "quiz_available": pack["total"] >= 4,
            "is_foundation": pack.get("recommended_order", 999) <= 100,
            "stage_label": (
                "Locked" if blocked_by else
                "Completed" if pack["pct"] >= 100 else
                "Strong" if pack["pct"] >= PACK_UNLOCK_THRESHOLD else
                "In progress" if pack["pct"] > 0 else
                "Ready"
            ),
        })
    return result


def get_recommended_pack(pack_cards: list[dict]) -> dict | None:
    for pack in pack_cards:
        if pack.get("unlocked") and not pack.get("is_complete"):
            return pack
    for pack in pack_cards:
        if not pack.get("is_complete"):
            return pack
    return pack_cards[0] if pack_cards else None


def get_next_unlocked_packs(pack_cards: list[dict], limit: int = 3) -> list[dict]:
    result = []
    for pack in pack_cards:
        if not pack.get("unlocked") or pack.get("is_complete"):
            continue
        result.append(pack)
        if len(result) >= limit:
            break
    return result


def collect_practical_wins(pack_cards: list[dict], min_pct: int = PACK_UNLOCK_THRESHOLD, limit: int = 3) -> list[dict]:
    wins = [
        pack for pack in pack_cards
        if pack.get("pct", 0) >= min_pct
    ]
    wins.sort(key=lambda pack: (-pack.get("pct", 0), pack.get("recommended_order", 999), pack.get("pack_name", "")))
    return wins[:limit]


def build_today_plan(
    due_count: int,
    new_count: int,
    recommended_pack: dict | None,
    story_cards: list[dict],
    session_done_today: bool,
) -> list[dict]:
    tasks: list[dict] = []

    study_copy = []
    if due_count:
        study_copy.append(f"{due_count} review")
    if new_count:
        study_copy.append(f"{new_count} new")
    if not study_copy:
        study_copy.append("Light reinforcement")

    tasks.append({
        "title": "Core session",
        "summary": " + ".join(study_copy),
        "hint": "Keep the daily habit small and repeatable.",
        "href": "/session",
        "cta": "Start today's session" if not session_done_today else "Do a light extra round",
        "is_done": session_done_today,
        "tone": "primary",
    })

    if recommended_pack:
        tasks.append({
            "title": recommended_pack["pack_name"],
            "summary": recommended_pack.get("can_do", recommended_pack.get("situation", "")),
            "hint": recommended_pack.get("focus", ""),
            "href": f"/packs/{recommended_pack['pack_id']}",
            "cta": "Open lesson",
            "is_done": False,
            "tone": "secondary",
        })
        if recommended_pack.get("quiz_available") and recommended_pack.get("pct", 0) >= 35:
            tasks.append({
                "title": "Mini-quiz",
                "summary": f"Check how solid {recommended_pack['pack_name']} feels before you move on.",
                "hint": "Fast mixed practice: listening, dictation, and choice.",
                "href": f"/packs/{recommended_pack['pack_id']}/quiz",
                "cta": "Take mini-quiz",
                "is_done": False,
                "tone": "secondary",
            })

    next_story = next((story for story in story_cards if not story.get("is_read")), story_cards[0] if story_cards else None)
    if next_story:
        tasks.append({
            "title": "Story practice",
            "summary": f"{next_story['title_de']} · {next_story.get('read_time', 2)} min read",
            "hint": "Use a short story to connect phrases in context.",
            "href": f"/stories/{next_story['story_id']}",
            "cta": "Read story",
            "is_done": next_story.get("is_read", False),
            "tone": "secondary",
        })

    return tasks[:4]


def build_weekly_consistency(history_rows: list[dict], daily_goal: str) -> dict:
    target_days = WEEKLY_TARGETS.get(daily_goal, 5)
    active_days = 0
    minutes = 0
    for row in history_rows:
        studied = ((row.get("reviewed") or 0) + (row.get("learned") or 0)) > 0 or bool(row.get("completed"))
        if studied:
            active_days += 1
        duration_seconds = row.get("duration") or 0
        if duration_seconds > 0:
            minutes += max(1, round(duration_seconds / 60))

    pct = min(100, int((active_days / target_days) * 100)) if target_days else 0
    status = (
        "On track" if active_days >= target_days else
        "Close" if active_days == target_days - 1 else
        "Build momentum"
    )
    return {
        "target_days": target_days,
        "active_days": active_days,
        "minutes": minutes,
        "pct": pct,
        "status": status,
        "days_left": max(0, target_days - active_days),
    }


def build_habit_hint(reminder_time: str) -> str:
    hour = int((reminder_time or "19:00").split(":")[0])
    if hour < 11:
        return "Tie German to breakfast or your first coffee so it happens before the day gets noisy."
    if hour < 16:
        return "Use a fixed lunch or mid-afternoon slot so practice stays predictable."
    return "Treat German like an evening reset: short session, then story or quiz."


def build_session_outcomes(pack_cards: list[dict], touched_pack_ids: list[str], limit: int = 3) -> list[dict]:
    by_id = {pack["pack_id"]: pack for pack in pack_cards}
    outcomes = []
    for pack_id in touched_pack_ids:
        pack = by_id.get(pack_id)
        if not pack:
            continue
        outcomes.append({
            "pack_id": pack["pack_id"],
            "pack_name": pack["pack_name"],
            "cover_emoji": pack.get("cover_emoji", "📚"),
            "can_do": pack.get("can_do", ""),
            "pct": pack.get("pct", 0),
        })
    if not outcomes:
        outcomes = [
            {
                "pack_id": pack["pack_id"],
                "pack_name": pack["pack_name"],
                "cover_emoji": pack.get("cover_emoji", "📚"),
                "can_do": pack.get("can_do", ""),
                "pct": pack.get("pct", 0),
            }
            for pack in collect_practical_wins(pack_cards, min_pct=1, limit=limit)
        ]
    return outcomes[:limit]


def filter_due_phrase_ids(due_ids: list[str], allowed_phrase_ids: set[str], limit: int) -> list[str]:
    return [phrase_id for phrase_id in due_ids if phrase_id in allowed_phrase_ids][:limit]


def choose_new_phrase_ids(pack_cards: list[dict], progress_rows: list[dict], limit: int) -> list[str]:
    progress_map = build_progress_map(progress_rows)
    new_ids: list[str] = []

    for pack in pack_cards:
        if not pack.get("unlocked"):
            continue
        for phrase in pack.get("phrases", []):
            if phrase["id"] in progress_map:
                continue
            new_ids.append(phrase["id"])
            if len(new_ids) >= limit:
                return new_ids
    return new_ids


def _make_rng(seed: str) -> random.Random:
    return random.Random(seed)


def _pick_distractors(
    target_phrase: dict,
    phrase_pool: list[dict],
    count: int,
    *,
    answer_key: str,
    seed: str,
) -> list[str]:
    rng = _make_rng(seed)
    candidates = [
        phrase[answer_key] for phrase in phrase_pool
        if phrase["id"] != target_phrase["id"] and phrase.get(answer_key) != target_phrase.get(answer_key)
    ]
    rng.shuffle(candidates)
    seen = set()
    distractors = []
    for candidate in candidates:
        if candidate in seen:
            continue
        seen.add(candidate)
        distractors.append(candidate)
        if len(distractors) >= count:
            break
    return distractors


def build_multiple_choice_step(target_phrase: dict, phrase_pool: list[dict], seed: str) -> dict:
    choices = _pick_distractors(target_phrase, phrase_pool, 3, answer_key="de", seed=seed)
    choices.append(target_phrase["de"])
    rng = _make_rng(f"{seed}:shuffle")
    rng.shuffle(choices)
    return {
        "type": "multiple_choice",
        "phrase_id": target_phrase["id"],
        "prompt": target_phrase["en"],
        "choices": choices,
        "correct_choice": target_phrase["de"],
    }


def build_meaning_match_question(target_phrase: dict, phrase_pool: list[dict], seed: str) -> dict:
    choices = _pick_distractors(target_phrase, phrase_pool, 3, answer_key="en", seed=seed)
    choices.append(target_phrase["en"])
    rng = _make_rng(f"{seed}:shuffle")
    rng.shuffle(choices)
    return {
        "type": "meaning_match",
        "phrase_id": target_phrase["id"],
        "prompt": f"What does '{target_phrase['de']}' mean?",
        "choices": choices,
        "correct_choice": target_phrase["en"],
    }


def build_listening_step(target_phrase: dict, phrase_pool: list[dict], seed: str) -> dict:
    choices = _pick_distractors(target_phrase, phrase_pool, 3, answer_key="en", seed=seed)
    choices.append(target_phrase["en"])
    rng = _make_rng(f"{seed}:shuffle")
    rng.shuffle(choices)
    return {
        "type": "listening",
        "phrase_id": target_phrase["id"],
        "prompt": "Listen and choose the meaning.",
        "choices": choices,
        "correct_choice": target_phrase["en"],
    }


def build_dictation_step(target_phrase: dict) -> dict:
    return {
        "type": "dictation",
        "phrase_id": target_phrase["id"],
        "prompt": "Listen and type what you hear.",
    }


def build_scenario_question(target_phrase: dict, phrase_pool: list[dict], seed: str) -> dict:
    choices = _pick_distractors(target_phrase, phrase_pool, 3, answer_key="de", seed=seed)
    choices.append(target_phrase["de"])
    rng = _make_rng(f"{seed}:shuffle")
    rng.shuffle(choices)
    scenario = target_phrase.get("usage") or (
        target_phrase.get("examples", [{}])[0].get("en")
        if target_phrase.get("examples")
        else target_phrase.get("en", "")
    )
    return {
        "type": "scenario",
        "phrase_id": target_phrase["id"],
        "prompt": f"Which German phrase fits this situation? {scenario}",
        "choices": choices,
        "correct_choice": target_phrase["de"],
    }


PACK_DRILLS: dict[str, list[dict[str, Any]]] = {
    "numbers_basics": [
        {
            "type": "drill",
            "prompt": "Which number is 'einundzwanzig'?",
            "choices": ["12", "21", "31", "91"],
            "correct_choice": "21",
            "explanation": "German puts the ones before the tens: ein-und-zwanzig = one-and-twenty.",
        },
        {
            "type": "drill",
            "prompt": "Which number is 'siebenundvierzig'?",
            "choices": ["74", "47", "57", "67"],
            "correct_choice": "47",
            "explanation": "The pattern is always ones + 'und' + tens: sieben-und-vierzig = 47.",
        },
        {
            "type": "drill",
            "prompt": "How do you say 58 in German?",
            "choices": ["fünfundachtzig", "achtundfünfzig", "fünfzigacht", "achtfünfzig"],
            "correct_choice": "achtundfünfzig",
            "explanation": "58 = eight-and-fifty in German: achtundfünfzig.",
        },
    ],
    "numbers_time": [
        {
            "type": "drill",
            "prompt": "What time is 'Es ist halb vier'?",
            "choices": ["4:30", "3:30", "3:15", "4:15"],
            "correct_choice": "3:30",
            "explanation": "'Halb vier' means halfway to four, so it is 3:30.",
        },
        {
            "type": "drill",
            "prompt": "What time is 'Es ist Viertel vor drei'?",
            "choices": ["2:15", "2:30", "2:45", "3:15"],
            "correct_choice": "2:45",
            "explanation": "'Viertel vor drei' is a quarter before three.",
        },
        {
            "type": "drill",
            "prompt": "Which German time matches 7:30?",
            "choices": ["halb sieben", "halb acht", "sieben Uhr fünfzehn", "Viertel nach sieben"],
            "correct_choice": "halb acht",
            "explanation": "German says the coming hour: 7:30 = halb acht.",
        },
    ],
    "dates_calendar": [
        {
            "type": "drill",
            "prompt": "How do you say 'March 5th' in German?",
            "choices": ["der fünf März", "der fünfte März", "fünf März", "der fünfste März"],
            "correct_choice": "der fünfte März",
            "explanation": "Dates use ordinal numbers: der fünfte März.",
        },
        {
            "type": "drill",
            "prompt": "What does 'am Montag' mean?",
            "choices": ["every Monday", "on Monday", "this Monday morning", "from Monday"],
            "correct_choice": "on Monday",
            "explanation": "'Am' is the standard way to say 'on' with days: am Montag.",
        },
    ],
    "math_basics": [
        {
            "type": "drill",
            "prompt": "How do Germans usually say 1.5 out loud?",
            "choices": ["eins Punkt fünf", "eins Komma fünf", "eins mit fünf", "eins Strich fünf"],
            "correct_choice": "eins Komma fünf",
            "explanation": "German reads decimal numbers with 'Komma', not 'Punkt'.",
        },
        {
            "type": "drill",
            "prompt": "What does 'zwölf geteilt durch drei' equal?",
            "choices": ["3", "4", "6", "9"],
            "correct_choice": "4",
            "explanation": "zwölf geteilt durch drei = 12 divided by 3 = 4.",
        },
        {
            "type": "drill",
            "prompt": "What does 'fünfzig Prozent' mean?",
            "choices": ["five euros", "fifteen percent", "fifty percent", "five hundred percent"],
            "correct_choice": "fifty percent",
            "explanation": "'Prozent' maps directly to 'percent'.",
        },
    ],
    "food_basics": [
        {
            "type": "drill",
            "prompt": "Which shopping list sounds natural in German?",
            "choices": [
                "Ich brauche Zwiebeln und Tomaten.",
                "Ich brauche schneiden und Pfanne.",
                "Ich brauche Prozent und Reis.",
                "Ich brauche links und rechts.",
            ],
            "correct_choice": "Ich brauche Zwiebeln und Tomaten.",
            "explanation": "This is a practical ingredient list sentence for shopping or cooking.",
        },
        {
            "type": "drill",
            "prompt": "What does 'frische Kräuter' mean?",
            "choices": ["fresh herbs", "fried potatoes", "sweet soup", "hot pan"],
            "correct_choice": "fresh herbs",
            "explanation": "'frisch' = fresh and 'Kräuter' = herbs.",
        },
    ],
    "cooking_basics": [
        {
            "type": "drill",
            "prompt": "Which phrase would you use in a recipe?",
            "choices": ["Lass das zehn Minuten kochen.", "Wie komme ich zum Bahnhof?", "Das ist zu teuer.", "Welches Datum ist heute?"],
            "correct_choice": "Lass das zehn Minuten kochen.",
            "explanation": "This is a direct, practical cooking instruction.",
        },
        {
            "type": "drill",
            "prompt": "What is 'eine Pfanne'?",
            "choices": ["a pan", "an oven", "a spoon", "a plate"],
            "correct_choice": "a pan",
            "explanation": "'die Pfanne' is the standard word for a frying pan.",
        },
    ],
    "core_verbs": [
        {
            "type": "drill",
            "prompt": "Which sentence uses 'wissen' correctly?",
            "choices": [
                "Ich weiß die Antwort nicht.",
                "Ich weiß meinen Nachbarn gut.",
                "Weißt du dieses Restaurant?",
                "Ich weiß nach Hause.",
            ],
            "correct_choice": "Ich weiß die Antwort nicht.",
            "explanation": "'wissen' is for facts and information, not people or places.",
        },
        {
            "type": "drill",
            "prompt": "Which verb best fits? 'Ich ___ den Bus um acht Uhr.'",
            "choices": ["nehme", "finde", "bleibe", "gebe"],
            "correct_choice": "nehme",
            "explanation": "German uses 'den Bus nehmen' for taking the bus.",
        },
    ],
    "modal_verbs": [
        {
            "type": "drill",
            "prompt": "Which sentence is polite in a cafe?",
            "choices": [
                "Ich möchte einen Tee, bitte.",
                "Ich muss einen Tee.",
                "Ich darf einen Tee.",
                "Ich kann einen Tee.",
            ],
            "correct_choice": "Ich möchte einen Tee, bitte.",
            "explanation": "'möchte' is the natural polite form for ordering or asking.",
        },
        {
            "type": "drill",
            "prompt": "What is correct after a modal verb?",
            "choices": [
                "Ich kann heute kommen.",
                "Ich kann heute komme.",
                "Ich kann komme heute.",
                "Ich kann heute gekommen.",
            ],
            "correct_choice": "Ich kann heute kommen.",
            "explanation": "After a modal, the second verb stays in the infinitive.",
        },
    ],
    "home_rooms": [
        {
            "type": "drill",
            "prompt": "Where would you normally find 'das Bett'?",
            "choices": ["im Schlafzimmer", "im Flur", "in der Küche", "im Badschrank"],
            "correct_choice": "im Schlafzimmer",
            "explanation": "'das Bett' belongs in the bedroom: im Schlafzimmer.",
        },
        {
            "type": "drill",
            "prompt": "What does 'auf dem Tisch' mean?",
            "choices": ["under the table", "next to the table", "on the table", "to the table"],
            "correct_choice": "on the table",
            "explanation": "'auf' with a location here means 'on the table'.",
        },
    ],
    "clothes_basics": [
        {
            "type": "drill",
            "prompt": "What would you say in a fitting room?",
            "choices": [
                "Das passt gut.",
                "Das wohnt gut.",
                "Das regnet gut.",
                "Das kocht gut.",
            ],
            "correct_choice": "Das passt gut.",
            "explanation": "'Das passt gut' is the common phrase for something fitting well.",
        },
        {
            "type": "drill",
            "prompt": "Which verb means 'to try on'?",
            "choices": ["tragen", "anprobieren", "bezahlen", "finden"],
            "correct_choice": "anprobieren",
            "explanation": "'anprobieren' is the fitting-room verb for trying clothes on.",
        },
    ],
    "weather_basics": [
        {
            "type": "drill",
            "prompt": "What does 'Es ist bewölkt' mean?",
            "choices": ["It is windy", "It is cloudy", "It is snowy", "It is foggy"],
            "correct_choice": "It is cloudy",
            "explanation": "'bewölkt' means cloudy.",
        },
        {
            "type": "drill",
            "prompt": "How do Germans say 10.5 degrees out loud?",
            "choices": ["zehn Punkt fünf Grad", "zehn Komma fünf Grad", "zehn mit fünf Grad", "zehn halb fünf Grad"],
            "correct_choice": "zehn Komma fünf Grad",
            "explanation": "German reads decimals with 'Komma', including temperatures.",
        },
    ],
    "hobbies_leisure": [
        {
            "type": "drill",
            "prompt": "Which phrase means 'to go for a walk'?",
            "choices": ["Sport treiben", "spazieren gehen", "Freunde treffen", "Musik hören"],
            "correct_choice": "spazieren gehen",
            "explanation": "'spazieren gehen' is the standard phrase for going for a walk.",
        },
        {
            "type": "drill",
            "prompt": "Which plan sounds natural for a weekend?",
            "choices": [
                "Am Samstag treffe ich Freunde.",
                "Am Samstag fülle ich die Schuhe aus.",
                "Am Samstag ist der Pullover müde.",
                "Am Samstag regnet das Kino.",
            ],
            "correct_choice": "Am Samstag treffe ich Freunde.",
            "explanation": "This is a natural leisure sentence using a core hobby frame.",
        },
    ],
    "adjectives_basics": [
        {
            "type": "drill",
            "prompt": "Which adjective means 'expensive'?",
            "choices": ["billig", "teuer", "frei", "neu"],
            "correct_choice": "teuer",
            "explanation": "'teuer' is the standard adjective for something expensive.",
        },
        {
            "type": "drill",
            "prompt": "What does 'Ist hier noch frei?' mean?",
            "choices": [
                "Is it expensive here?",
                "Is this still free / available?",
                "Is it already closed here?",
                "Is this still difficult?",
            ],
            "correct_choice": "Is this still free / available?",
            "explanation": "'frei' often means available, especially for seats, tables, and time slots.",
        },
    ],
    "core_prepositions": [
        {
            "type": "drill",
            "prompt": "Which chunk means 'at home'?",
            "choices": ["nach Hause", "zu Hause", "von zu Hause", "im Hause"],
            "correct_choice": "zu Hause",
            "explanation": "German splits this idea into three chunks: nach Hause, zu Hause, von zu Hause.",
        },
        {
            "type": "drill",
            "prompt": "Which phrase fits an exact time?",
            "choices": ["im acht Uhr", "um acht Uhr", "an acht Uhr", "bei acht Uhr"],
            "correct_choice": "um acht Uhr",
            "explanation": "Use 'um' for exact clock times.",
        },
    ],
    "restaurant_cafe": [
        {
            "type": "drill",
            "prompt": "What would you say when you want the bill?",
            "choices": [
                "Die Rechnung, bitte.",
                "Die Küche, bitte.",
                "Getrennt Uhr, bitte.",
                "Der Tisch, bitte.",
            ],
            "correct_choice": "Die Rechnung, bitte.",
            "explanation": "This is the standard short restaurant phrase for asking for the bill.",
        },
        {
            "type": "drill",
            "prompt": "Which phrase sounds natural when ordering?",
            "choices": [
                "Ich hätte gern einen Tee.",
                "Ich kenne gern einen Tee.",
                "Ich bin gern einen Tee.",
                "Ich gehe gern einen Tee.",
            ],
            "correct_choice": "Ich hätte gern einen Tee.",
            "explanation": "'Ich hätte gern ...' is a very natural polite ordering pattern.",
        },
    ],
    "classroom_study": [
        {
            "type": "drill",
            "prompt": "Which phrase is best when you did not understand the teacher?",
            "choices": [
                "Ich habe das nicht verstanden.",
                "Ich nehme das nicht.",
                "Ich öffne das nicht.",
                "Ich koche das nicht.",
            ],
            "correct_choice": "Ich habe das nicht verstanden.",
            "explanation": "This is the most practical repair phrase in a language class.",
        },
        {
            "type": "drill",
            "prompt": "What does 'buchstabieren' mean?",
            "choices": ["to repeat", "to spell", "to explain", "to underline"],
            "correct_choice": "to spell",
            "explanation": "'buchstabieren' is the classroom verb for spelling a word or name.",
        },
    ],
    "city_services_basics": [
        {
            "type": "drill",
            "prompt": "Which phrase means 'straight ahead'?",
            "choices": ["um die Ecke", "links abbiegen", "geradeaus", "geschlossen"],
            "correct_choice": "geradeaus",
            "explanation": "'geradeaus' is the core direction word for going straight.",
        },
        {
            "type": "drill",
            "prompt": "Where would you go to send a letter?",
            "choices": ["zur Apotheke", "zur Post", "zur Bushaltestelle", "zur Ampel"],
            "correct_choice": "zur Post",
            "explanation": "'die Post' is the place for letters and parcels.",
        },
    ],
    "travel_problems_a2": [
        {
            "type": "drill",
            "prompt": "What does 'Das Gleis hat sich geändert' mean?",
            "choices": [
                "The train is full",
                "The platform has changed",
                "The ticket is invalid",
                "The station is closed",
            ],
            "correct_choice": "The platform has changed",
            "explanation": "This is one of the most important station-announcement phrases at A2.",
        },
        {
            "type": "drill",
            "prompt": "Which phrase means 'to miss the connection'?",
            "choices": [
                "den Anschluss verpassen",
                "die Fahrkarte umtauschen",
                "das Gleis ändern",
                "mit dem Bus fahren",
            ],
            "correct_choice": "den Anschluss verpassen",
            "explanation": "'den Anschluss verpassen' is the practical travel phrase for missing a transfer.",
        },
    ],
    "public_services_a2": [
        {
            "type": "drill",
            "prompt": "What is usually missing on a form if you still need to sign it?",
            "choices": ["die Nummer", "die Unterschrift", "die Kaution", "die Reservierung"],
            "correct_choice": "die Unterschrift",
            "explanation": "'die Unterschrift' is the signature on a form or contract.",
        },
        {
            "type": "drill",
            "prompt": "Which phrase sounds natural at an office?",
            "choices": [
                "Bitte zuerst eine Nummer ziehen.",
                "Bitte zuerst den Zug verpassen.",
                "Bitte zuerst im Cafe bestellen.",
                "Bitte zuerst die Jacke anprobieren.",
            ],
            "correct_choice": "Bitte zuerst eine Nummer ziehen.",
            "explanation": "This is a classic office waiting-system phrase.",
        },
    ],
    "course_office_a2": [
        {
            "type": "drill",
            "prompt": "What is 'die Teilnahmebescheinigung'?",
            "choices": ["the course fee", "the attendance certificate", "the placement test", "the classroom key"],
            "correct_choice": "the attendance certificate",
            "explanation": "This is a common document word at language schools and courses.",
        },
        {
            "type": "drill",
            "prompt": "Which sentence sounds natural at a course office?",
            "choices": [
                "Könnten Sie mir das Material schicken?",
                "Könnten Sie mir das Wetter schicken?",
                "Könnten Sie mir den Bahnhof kochen?",
                "Könnten Sie mir die Jacke abbiegen?",
            ],
            "correct_choice": "Könnten Sie mir das Material schicken?",
            "explanation": "This is a natural A2 office request about course materials.",
        },
    ],
    "social_reactions_a2": [
        {
            "type": "drill",
            "prompt": "Which reaction means 'It depends'?",
            "choices": ["Genau.", "Kommt darauf an.", "Auf keinen Fall.", "Das stimmt."],
            "correct_choice": "Kommt darauf an.",
            "explanation": "This is one of the most useful A2 reaction chunks for nuanced answers.",
        },
        {
            "type": "drill",
            "prompt": "Which phrase helps when two people prefer different times?",
            "choices": [
                "Lass uns einen Kompromiss finden.",
                "Das ist um die Ecke.",
                "Ich hebe Geld ab.",
                "Der Unterricht fällt aus.",
            ],
            "correct_choice": "Lass uns einen Kompromiss finden.",
            "explanation": "This phrase helps move from disagreement to a practical solution.",
        },
    ],
    "payments_bank_post_a2": [
        {
            "type": "drill",
            "prompt": "What does 'Geld abheben' mean?",
            "choices": ["to transfer money", "to count money", "to withdraw cash", "to borrow money"],
            "correct_choice": "to withdraw cash",
            "explanation": "'abheben' is the standard bank verb for taking cash out.",
        },
        {
            "type": "drill",
            "prompt": "Which phrase is useful when a card payment fails?",
            "choices": [
                "Meine Karte funktioniert nicht.",
                "Meine Karte lernt nicht.",
                "Meine Karte ist um die Ecke.",
                "Meine Karte ist eine Prüfung.",
            ],
            "correct_choice": "Meine Karte funktioniert nicht.",
            "explanation": "A short direct problem phrase for shops, stations, and banks.",
        },
    ],
    "everyday_verbs_a2": [
        {
            "type": "drill",
            "prompt": "Which verb best fits? 'Wir müssen den Termin auf nächste Woche ___. '",
            "choices": ["verschieben", "abholen", "ausdrucken", "überprüfen"],
            "correct_choice": "verschieben",
            "explanation": "'verschieben' is the practical verb for moving an appointment to another time.",
        },
        {
            "type": "drill",
            "prompt": "What does 'unterlagen ausdrucken' mean?",
            "choices": ["to sign documents", "to discuss documents", "to print documents", "to check documents"],
            "correct_choice": "to print documents",
            "explanation": "'ausdrucken' is the common office and study verb for printing.",
        },
    ],
    "housing_services": [
        {
            "type": "drill",
            "prompt": "What is 'die Kaution'?",
            "choices": ["the repair", "the deposit", "the rent increase", "the key"],
            "correct_choice": "the deposit",
            "explanation": "'die Kaution' is the deposit for a rented flat.",
        },
        {
            "type": "drill",
            "prompt": "Which phrase is useful with a landlord or technician?",
            "choices": [
                "Können wir einen Termin vereinbaren?",
                "Ich esse später im Wohnzimmer.",
                "Es ist sonnig im Vertrag.",
                "Die Schuhe passen der Heizung.",
            ],
            "correct_choice": "Können wir einen Termin vereinbaren?",
            "explanation": "This is a common service and appointment phrase in housing situations.",
        },
    ],
    "verb_patterns_a2": [
        {
            "type": "drill",
            "prompt": "Which sentence uses the right German pattern for 'wait for'?",
            "choices": [
                "Ich warte auf den Bus.",
                "Ich warte den Bus.",
                "Ich warte für den Bus.",
                "Ich warte an den Bus.",
            ],
            "correct_choice": "Ich warte auf den Bus.",
            "explanation": "'warten' needs 'auf + accusative' in German.",
        },
        {
            "type": "drill",
            "prompt": "Which pair is correct?",
            "choices": [
                "sich freuen auf + Akkusativ",
                "sich freuen mit + Dativ",
                "sich freuen zu + Akkusativ",
                "sich freuen über + Dativ",
            ],
            "correct_choice": "sich freuen auf + Akkusativ",
            "explanation": "For something in the future, German uses 'sich freuen auf + accusative'.",
        },
    ],
    "separable_verbs_a2": [
        {
            "type": "drill",
            "prompt": "Which sentence has the separable verb in the right place?",
            "choices": [
                "Ich rufe dich später zurück.",
                "Ich zurückrufe dich später.",
                "Ich rufe zurück dich später.",
                "Ich später dich zurückrufe.",
            ],
            "correct_choice": "Ich rufe dich später zurück.",
            "explanation": "In a main clause, the verb root stays early and the prefix moves to the end.",
        },
        {
            "type": "drill",
            "prompt": "What does 'das Formular ausfüllen' mean?",
            "choices": ["to print the form", "to sign the form", "to fill out the form", "to send the form"],
            "correct_choice": "to fill out the form",
            "explanation": "'ausfüllen' is the standard verb for completing a form.",
        },
    ],
}


def get_pack_drills(pack_id: str) -> list[dict]:
    return [dict(drill) for drill in PACK_DRILLS.get(pack_id, [])]


def choose_session_drill(preferred_pack_ids: list[str]) -> dict | None:
    for pack_id in preferred_pack_ids:
        drills = get_pack_drills(pack_id)
        if drills:
            return drills[0]
    return None


def build_session_steps(
    review_ids: list[str],
    new_ids: list[str],
    dialogue: dict | None,
    produce_phrase: dict | None,
    phrase_pool: list[dict],
    preferred_pack_ids: list[str],
) -> list[dict]:
    phrase_by_id = {phrase["id"]: phrase for phrase in phrase_pool}
    steps: list[dict] = []

    for phrase_id in review_ids:
        steps.append({"type": "review", "phrase_id": phrase_id})
    for phrase_id in new_ids:
        steps.append({"type": "learn", "phrase_id": phrase_id})

    exercise_targets = [phrase_by_id[phrase_id] for phrase_id in new_ids + review_ids if phrase_id in phrase_by_id]
    if exercise_targets:
        steps.append(build_listening_step(exercise_targets[0], phrase_pool, f"{exercise_targets[0]['id']}:listen"))
    if len(exercise_targets) > 1:
        steps.append(build_multiple_choice_step(exercise_targets[1], phrase_pool, f"{exercise_targets[1]['id']}:mc"))
    if exercise_targets:
        steps.append(build_dictation_step(exercise_targets[0]))

    drill = choose_session_drill(preferred_pack_ids)
    if drill:
        steps.append(drill)

    if dialogue:
        steps.append({"type": "dialogue", "dialogue_id": dialogue["dialogue_id"]})
    if produce_phrase:
        steps.append({"type": "produce", "phrase_id": produce_phrase["id"]})
    steps.append({"type": "complete"})
    return steps


def build_pack_quiz(pack: dict, all_packs: list[dict], question_count: int = 7) -> list[dict]:
    phrase_pool = [phrase for other_pack in all_packs for phrase in other_pack.get("phrases", [])]
    rng = _make_rng(f"quiz:{pack['pack_id']}")
    phrases = list(pack.get("phrases", []))
    rng.shuffle(phrases)

    questions: list[dict] = []
    if phrases:
        questions.append(build_meaning_match_question(phrases[0], phrase_pool, f"{pack['pack_id']}:meaning:0"))
    if len(phrases) > 1:
        questions.append(build_listening_step(phrases[1], phrase_pool, f"{pack['pack_id']}:listen:1"))
    if len(phrases) > 2:
        questions.append(build_dictation_step(phrases[2]))
    if len(phrases) > 3:
        questions.append(build_scenario_question(phrases[3], phrase_pool, f"{pack['pack_id']}:scenario:3"))
    if len(phrases) > 4:
        questions.append(build_multiple_choice_step(phrases[4], phrase_pool, f"{pack['pack_id']}:mc:4"))

    drills = get_pack_drills(pack["pack_id"])
    for drill in drills:
        questions.append(drill)

    idx = 5
    while len(questions) < question_count and idx < len(phrases):
        if idx % 2 == 0:
            questions.append(build_meaning_match_question(phrases[idx], phrase_pool, f"{pack['pack_id']}:meaning:{idx}"))
        else:
            questions.append(build_multiple_choice_step(phrases[idx], phrase_pool, f"{pack['pack_id']}:mc:{idx}"))
        idx += 1

    return questions[:question_count]


def grade_quiz_submission(questions: list[dict], submitted: dict[str, str], phrase_by_id: dict[str, dict]) -> list[dict]:
    graded = []
    for index, question in enumerate(questions):
        key = f"q{index}"
        given_answer = (submitted.get(key) or "").strip()
        correct_answer = question.get("correct_choice", "")
        if question["type"] == "dictation":
            phrase = phrase_by_id.get(question["phrase_id"], {})
            correct_answer = phrase.get("de", "")
            is_correct = given_answer.casefold() == correct_answer.casefold()
        else:
            is_correct = given_answer == correct_answer

        graded.append({
            **question,
            "submitted": given_answer,
            "correct_answer": correct_answer,
            "is_correct": is_correct,
        })
    return graded


def quiz_score(graded_questions: list[dict]) -> tuple[int, int]:
    total = len(graded_questions)
    score = sum(1 for question in graded_questions if question.get("is_correct"))
    return score, total
