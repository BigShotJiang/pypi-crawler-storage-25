import csv
import io
from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse

from auf_deutsch import content_loader, learning_engine
from auf_deutsch.db import (
    get_all_progress, get_review_streak, get_total_learned,
    get_session_history, get_setting, set_setting, reset_all_progress,
    get_latest_pack_quiz_attempts,
)
from auf_deutsch.template_env import templates

router = APIRouter()


@router.get("/progress", response_class=HTMLResponse)
async def progress_page(request: Request):
    packs = content_loader.get_all_packs()
    progress_rows = get_all_progress()
    all_progress = {p["phrase_id"]: p for p in progress_rows}
    pack_stats = learning_engine.annotate_packs(packs, progress_rows)
    latest_quizzes = get_latest_pack_quiz_attempts()
    for pack in pack_stats:
        pack["latest_quiz"] = latest_quizzes.get(pack["pack_id"])

    from datetime import date, timedelta
    today = date.today()
    history = get_session_history(days=7)
    history_map = {r["date"]: r for r in history}
    weekly_snapshot = learning_engine.build_weekly_consistency(history, get_setting("daily_goal", "5"))

    chart_days = []
    max_reviewed = 1
    for i in range(6, -1, -1):
        d = (today - timedelta(days=i)).isoformat()
        day_label = (today - timedelta(days=i)).strftime("%a")
        entry = history_map.get(d, {})
        reviewed = (entry.get("reviewed") or 0) + (entry.get("learned") or 0)
        max_reviewed = max(max_reviewed, reviewed)
        chart_days.append({"label": day_label, "date": d, "count": reviewed})

    total_due = sum(
        1 for p in all_progress.values()
        if p["status"] in ("learning", "review") and
        (p["due_date"] is None or p["due_date"] <= today.isoformat())
    )

    return templates.TemplateResponse("progress.html", {
        "request": request,
        "total_learned": get_total_learned(),
        "total_due": total_due,
        "streak": get_review_streak(),
        "pack_stats": pack_stats,
        "recommended_pack": learning_engine.get_recommended_pack(pack_stats),
        "practical_wins": learning_engine.collect_practical_wins(pack_stats, limit=4),
        "weekly_snapshot": weekly_snapshot,
        "habit_hint": learning_engine.build_habit_hint(get_setting("reminder_time", "19:00")),
        "chart_days": chart_days,
        "max_reviewed": max_reviewed,
    })


@router.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    daily_goal = get_setting("daily_goal", "5")
    reminder_time = get_setting("reminder_time", "19:00")
    return templates.TemplateResponse("settings.html", {
        "request": request,
        "reminder_time": reminder_time,
        "notifications_enabled": get_setting("notifications_enabled", "false"),
        "daily_goal": daily_goal,
        "level": get_setting("level", "A1"),
        "ui_lang": get_setting("ui_lang", "en"),
        "weekly_snapshot": learning_engine.build_weekly_consistency(get_session_history(days=7), daily_goal),
        "habit_hint": learning_engine.build_habit_hint(reminder_time),
        "saved": request.query_params.get("saved"),
        "reset": request.query_params.get("reset"),
        "regen": request.query_params.get("regen"),
    })


@router.post("/settings", response_class=RedirectResponse)
async def save_settings(
    reminder_time: str = Form("19:00"),
    notifications_enabled: str = Form("false"),
    daily_goal: str = Form("5"),
    level: str = Form("A1"),
    ui_lang: str = Form("en"),
):
    set_setting("reminder_time", reminder_time)
    set_setting("notifications_enabled", notifications_enabled)
    set_setting("daily_goal", daily_goal)
    set_setting("level", level)
    set_setting("ui_lang", ui_lang)
    return RedirectResponse("/settings?saved=1", status_code=303)


@router.post("/settings/reset-progress")
async def settings_reset():
    reset_all_progress()
    return RedirectResponse("/settings?reset=1", status_code=303)


@router.post("/settings/regenerate-audio")
async def settings_regen_audio():
    from auf_deutsch.audio_gen import regenerate_all_audio
    regenerate_all_audio(
        content_loader.get_all_packs(),
        content_loader.get_all_dialogues(),
        content_loader.get_all_listening_exercises(),
    )
    return RedirectResponse("/settings?regen=1", status_code=303)


@router.get("/settings/export-progress")
async def export_progress():
    all_prog = get_all_progress()
    phrase_index = {
        ph["id"]: ph
        for pack in content_loader.get_all_packs()
        for ph in pack.get("phrases", [])
    }
    pack_map = {
        ph["id"]: pack["pack_id"]
        for pack in content_loader.get_all_packs()
        for ph in pack.get("phrases", [])
    }

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "phrase_id", "de", "en", "pack_id", "status",
        "ease_score", "interval_days", "review_count",
        "lapse_count", "last_reviewed", "due_date",
    ])
    for p in all_prog:
        phrase = phrase_index.get(p["phrase_id"], {})
        writer.writerow([
            p["phrase_id"],
            phrase.get("de", ""),
            phrase.get("en", ""),
            pack_map.get(p["phrase_id"], ""),
            p["status"],
            p["ease_score"],
            p["interval_days"],
            p["review_count"],
            p["lapse_count"],
            p["last_reviewed"] or "",
            p["due_date"] or "",
        ])

    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=auf_deutsch_progress.csv"},
    )
