import time
import uuid
from fastapi import APIRouter, Request, Form, Cookie
from fastapi.responses import HTMLResponse, RedirectResponse

from auf_deutsch import learning_engine
from auf_deutsch.audio_gen import ensure_audio
from auf_deutsch.content_loader import (
    get_all_dialogues,
    get_dialogues_for_pack,
    get_packs_for_level,
    get_phrase,
    get_phrase_pack_id,
    level_matches,
)
from auf_deutsch.db import (
    get_all_progress, get_due_phrases, ensure_phrase_progress,
    log_session_start, update_session_log, get_setting, get_review_streak,
)
from auf_deutsch.srs import update_progress
from auf_deutsch.template_env import templates

router = APIRouter()

# In-memory session store: session_id -> session dict
_sessions: dict = {}

# Rating display config: icon + label in en and de
_RATING_META = {
    "again": {"icon": "🔴", "label_en": "Again",  "label_de": "Nochmal"},
    "hard":  {"icon": "🟠", "label_en": "Hard",   "label_de": "Schwer"},
    "good":  {"icon": "🟢", "label_en": "Good",   "label_de": "Gut"},
    "easy":  {"icon": "✨", "label_en": "Easy",   "label_de": "Leicht"},
    "learn": {"icon": "✅", "label_en": "Learned", "label_de": "Gelernt"},
}
_SESSION_SIZES = {
    "5": {"due": 5, "new": 2},
    "10": {"due": 8, "new": 3},
    "15": {"due": 12, "new": 4},
}
_UI_COPY = {
    "en": {
        "steps": {
            "review": "Review",
            "learn": "New",
            "dialogue": "Dialogue",
            "produce": "Recall",
            "multiple_choice": "Choice",
            "listening": "Listen",
            "dictation": "Dictation",
            "drill": "Drill",
            "complete": "Done",
        },
        "review_prompt": "How do you say in German?",
        "produce_prompt": "How do you say:",
        "listening_prompt": "Listen and choose the meaning.",
        "choice_prompt": "Choose the best German phrase.",
        "dictation_prompt": "Listen and type what you hear.",
        "input_placeholder": "Type in German…",
        "reveal": "Reveal",
        "check": "Check",
        "play": "Play",
        "previous": "Back",
        "continue": "Continue",
        "submit_answer": "Submit answer",
        "learned": "I've got it",
        "your_answer": "Your answer",
        "correct": "Correct",
        "try_again": "Not quite",
        "usage": "Usage",
        "examples": "Examples",
        "variation": "Variation",
        "grammar": "Grammar",
        "dialogue_empty": "No dialogue available.",
    },
    "de": {
        "steps": {
            "review": "Wiederholung",
            "learn": "Neu",
            "dialogue": "Dialog",
            "produce": "Produktion",
            "multiple_choice": "Auswahl",
            "listening": "Hören",
            "dictation": "Diktat",
            "drill": "Training",
            "complete": "Fertig",
        },
        "review_prompt": "Wie sagt man das auf Deutsch?",
        "produce_prompt": "Wie sagt man:",
        "listening_prompt": "Hör zu und wähle die Bedeutung.",
        "choice_prompt": "Wähle die beste deutsche Phrase.",
        "dictation_prompt": "Hör zu und tippe, was du hörst.",
        "input_placeholder": "Tippe auf Deutsch…",
        "reveal": "Aufdecken",
        "check": "Prüfen",
        "play": "Anhören",
        "previous": "Zurück",
        "continue": "Weiter",
        "submit_answer": "Antwort senden",
        "learned": "Ich hab's",
        "your_answer": "Deine Antwort",
        "correct": "Richtig",
        "try_again": "Noch nicht ganz",
        "usage": "Verwendung",
        "examples": "Beispiele",
        "variation": "Variation",
        "grammar": "Grammatik",
        "dialogue_empty": "Kein Dialog verfügbar.",
    },
}


def _make_session(steps: list) -> dict:
    return {
        "steps": steps,
        "current": 0,
        "start_time": time.time(),
        "phrases_reviewed": 0,
        "phrases_learned": 0,
        "activity_log": [],   # {"de", "en", "action", "grammar_note"}
        "db_session_id": None,
        "reveal": False,
        "last_answer": "",
        "last_correct": None,
    }


def _get_session(session_id: str):
    return _sessions.get(session_id)


def _find_dialogue(dialogue_id: str):
    for d in get_all_dialogues():
        if d["dialogue_id"] == dialogue_id:
            return d
    return None


def _pick_dialogue(preferred_pack_ids: list[str], max_level: str) -> dict | None:
    seen = set()
    for pack_id in preferred_pack_ids:
        if not pack_id or pack_id in seen:
            continue
        seen.add(pack_id)
        pack_dialogues = get_dialogues_for_pack(pack_id, max_level=max_level)
        if pack_dialogues:
            return pack_dialogues[0]

    for dialogue in get_all_dialogues():
        if level_matches(dialogue.get("level"), max_level):
            return dialogue
    return get_all_dialogues()[0] if get_all_dialogues() else None


@router.get("/session", response_class=HTMLResponse)
async def start_session(request: Request, session_id: str = Cookie(default=None)):
    selected_level = get_setting("level", "A1")
    daily_goal = get_setting("daily_goal", "5")
    session_size = _SESSION_SIZES.get(daily_goal, _SESSION_SIZES["5"])

    packs = get_packs_for_level(selected_level)
    all_progress_rows = get_all_progress()
    pack_cards = learning_engine.annotate_packs(packs, all_progress_rows)
    visible_phrase_ids = {ph["id"] for pack in packs for ph in pack["phrases"]}
    phrase_pool = [phrase for pack in packs for phrase in pack["phrases"]]

    due = learning_engine.filter_due_phrase_ids(
        get_due_phrases(limit=session_size["due"] * 3),
        visible_phrase_ids,
        session_size["due"],
    )
    new_ids = learning_engine.choose_new_phrase_ids(pack_cards, all_progress_rows, session_size["new"])

    preferred_pack_ids = [get_phrase_pack_id(pid) for pid in new_ids + due]
    dialogue = _pick_dialogue(preferred_pack_ids, selected_level)

    produce_phrase = None
    if new_ids:
        produce_phrase = get_phrase(new_ids[0])
    elif due:
        produce_phrase = get_phrase(due[0])

    for pid in new_ids:
        ensure_phrase_progress(pid)

    db_sid = log_session_start()
    steps = learning_engine.build_session_steps(
        due,
        new_ids,
        dialogue,
        produce_phrase,
        phrase_pool,
        [pack_id for pack_id in preferred_pack_ids if pack_id],
    )
    sess = _make_session(steps)
    sess["db_session_id"] = db_sid

    sid = str(uuid.uuid4())
    _sessions[sid] = sess

    response = RedirectResponse("/session/step", status_code=303)
    response.set_cookie("session_id", sid, max_age=3600)
    return response


@router.get("/session/step", response_class=HTMLResponse)
async def session_step(request: Request, session_id: str = Cookie(default=None)):
    sess = _get_session(session_id)
    if not sess:
        return RedirectResponse("/", status_code=303)

    idx = sess["current"]
    steps = sess["steps"]
    if idx >= len(steps):
        return RedirectResponse("/", status_code=303)

    step = steps[idx]
    total = len(steps)
    step_num = idx + 1
    ui_lang = get_setting("ui_lang", "en")
    copy = _UI_COPY.get(ui_lang, _UI_COPY["en"])
    label_key = "label_de" if ui_lang == "de" else "label_en"

    ctx = {
        "request": request,
        "step": step,
        "step_num": step_num,
        "total": total,
        "reveal": sess.get("reveal", False),
        "last_answer": sess.get("last_answer", ""),
        "last_correct": sess.get("last_correct"),
        "ui_lang": ui_lang,
        "copy": copy,
        "rating_labels": {
            key: value[label_key]
            for key, value in _RATING_META.items()
            if key in ("again", "hard", "good", "easy")
        },
    }

    stype = step["type"]

    if stype == "review":
        phrase = get_phrase(step["phrase_id"])
        audio_url = ensure_audio(phrase["id"], phrase["de"]) if phrase else ""
        ctx.update({"phrase": phrase, "audio_url": audio_url})
        return templates.TemplateResponse("session.html", ctx)

    elif stype == "learn":
        phrase = get_phrase(step["phrase_id"])
        audio_url = ensure_audio(phrase["id"], phrase["de"]) if phrase else ""
        ctx.update({"phrase": phrase, "audio_url": audio_url})
        return templates.TemplateResponse("session.html", ctx)

    elif stype == "dialogue":
        dialogue = _find_dialogue(step["dialogue_id"])
        line_audios = []
        if dialogue:
            for i, line in enumerate(dialogue["lines"]):
                key = f"{dialogue['dialogue_id']}_{i}"
                url = ensure_audio(key, line["de"])
                line_audios.append(url)
        ctx.update({"dialogue": dialogue, "line_audios": line_audios})
        return templates.TemplateResponse("session.html", ctx)

    elif stype == "produce":
        phrase = get_phrase(step["phrase_id"])
        audio_url = ensure_audio(phrase["id"], phrase["de"]) if phrase else ""
        ctx.update({"phrase": phrase, "audio_url": audio_url})
        return templates.TemplateResponse("session.html", ctx)

    elif stype in ("multiple_choice", "listening"):
        phrase = get_phrase(step["phrase_id"])
        audio_url = ensure_audio(phrase["id"], phrase["de"]) if phrase else ""
        ctx.update({"phrase": phrase, "audio_url": audio_url, "exercise": step})
        return templates.TemplateResponse("session.html", ctx)

    elif stype == "dictation":
        phrase = get_phrase(step["phrase_id"])
        audio_url = ensure_audio(phrase["id"], phrase["de"]) if phrase else ""
        ctx.update({"phrase": phrase, "audio_url": audio_url, "exercise": step})
        return templates.TemplateResponse("session.html", ctx)

    elif stype == "drill":
        ctx.update({"exercise": step})
        return templates.TemplateResponse("session.html", ctx)

    elif stype == "complete":
        duration = int(time.time() - sess["start_time"])
        db_sid = sess.get("db_session_id")
        if db_sid:
            update_session_log(
                db_sid,
                phrases_reviewed=sess["phrases_reviewed"],
                phrases_learned=sess["phrases_learned"],
                duration_seconds=duration,
                completed=1,
            )
        # Find grammar tip from reviewed phrases
        grammar_tip = None
        for entry in sess["activity_log"]:
            if entry.get("grammar_note"):
                grammar_tip = entry
                break

        selected_level = get_setting("level", "A1")
        all_progress_rows = get_all_progress()
        pack_cards = learning_engine.annotate_packs(get_packs_for_level(selected_level), all_progress_rows)
        recommended_pack = learning_engine.get_recommended_pack(pack_cards)
        touched_pack_ids = []
        for entry in sess["activity_log"]:
            phrase_id = entry.get("phrase_id")
            pack_id = get_phrase_pack_id(phrase_id) if phrase_id else None
            if pack_id and pack_id not in touched_pack_ids:
                touched_pack_ids.append(pack_id)

        ctx.update({
            "phrases_reviewed": sess["phrases_reviewed"],
            "phrases_learned": sess["phrases_learned"],
            "duration": duration,
            "activity_log": sess["activity_log"],
            "grammar_tip": grammar_tip,
            "recommended_pack": recommended_pack,
            "session_outcomes": learning_engine.build_session_outcomes(pack_cards, touched_pack_ids),
            "practical_wins": learning_engine.collect_practical_wins(pack_cards),
            "reminder_time": get_setting("reminder_time", "19:00"),
            "streak": get_review_streak(),
        })
        return templates.TemplateResponse("complete.html", ctx)

    return RedirectResponse("/", status_code=303)


@router.post("/session/next", response_class=RedirectResponse)
async def session_next(
    request: Request,
    action: str = Form(default="next"),
    answer: str = Form(default=""),
    session_id: str = Cookie(default=None),
):
    sess = _get_session(session_id)
    if not sess:
        return RedirectResponse("/", status_code=303)

    idx = sess["current"]
    steps = sess["steps"]
    step = steps[idx]
    stype = step["type"]

    sess["reveal"] = False
    sess["last_answer"] = ""
    sess["last_correct"] = None

    if action == "previous":
        if sess["current"] > 0:
            sess["current"] -= 1
        return RedirectResponse("/session/step", status_code=303)

    if stype == "review":
        if action == "reveal":
            sess["reveal"] = True
            sess["last_answer"] = answer
            return RedirectResponse("/session/step", status_code=303)
        elif action in ("again", "hard", "good", "easy"):
            phrase = get_phrase(step["phrase_id"]) or {}
            update_progress(step["phrase_id"], action)
            sess["phrases_reviewed"] += 1
            sess["activity_log"].append({
                "phrase_id": step["phrase_id"],
                "de": phrase.get("de", ""),
                "en": phrase.get("en", ""),
                "action": action,
                "grammar_note": phrase.get("grammar_note", ""),
                "icon": _RATING_META[action]["icon"],
                "label_en": _RATING_META[action]["label_en"],
            })
            db_sid = sess.get("db_session_id")
            if db_sid:
                update_session_log(db_sid, phrases_reviewed=sess["phrases_reviewed"])
            sess["current"] += 1

    elif stype == "learn":
        phrase = get_phrase(step["phrase_id"]) or {}
        update_progress(step["phrase_id"], "good")
        sess["phrases_learned"] += 1
        sess["activity_log"].append({
            "phrase_id": step["phrase_id"],
            "de": phrase.get("de", ""),
            "en": phrase.get("en", ""),
            "action": "learn",
            "grammar_note": phrase.get("grammar_note", ""),
            "icon": _RATING_META["learn"]["icon"],
            "label_en": _RATING_META["learn"]["label_en"],
        })
        db_sid = sess.get("db_session_id")
        if db_sid:
            update_session_log(db_sid, phrases_learned=sess["phrases_learned"])
        sess["current"] += 1

    elif stype == "dialogue":
        sess["current"] += 1

    elif stype == "produce":
        if action == "reveal":
            sess["reveal"] = True
            sess["last_answer"] = answer
            return RedirectResponse("/session/step", status_code=303)
        elif action == "next":
            sess["current"] += 1

    elif stype in ("multiple_choice", "listening", "drill"):
        if action == "check":
            submitted = answer
            correct_choice = step.get("correct_choice", "")
            sess["reveal"] = True
            sess["last_answer"] = submitted
            sess["last_correct"] = submitted == correct_choice
            return RedirectResponse("/session/step", status_code=303)
        elif action == "next":
            sess["current"] += 1

    elif stype == "dictation":
        if action == "reveal":
            phrase = get_phrase(step["phrase_id"]) or {}
            submitted = answer.strip()
            correct_text = phrase.get("de", "")
            sess["reveal"] = True
            sess["last_answer"] = submitted
            sess["last_correct"] = submitted.casefold() == correct_text.casefold()
            return RedirectResponse("/session/step", status_code=303)
        elif action == "next":
            sess["current"] += 1

    else:
        sess["current"] += 1

    return RedirectResponse("/session/step", status_code=303)
