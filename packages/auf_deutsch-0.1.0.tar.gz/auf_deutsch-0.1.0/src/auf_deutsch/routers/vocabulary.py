from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse

from auf_deutsch import content_loader
from auf_deutsch.db import get_setting
from auf_deutsch.template_env import templates

router = APIRouter()

_ARTICLES = ("der ", "die ", "das ")


def _phrase_category(phrase: dict) -> str:
    tags = {tag.lower() for tag in phrase.get("tags", [])}
    de = (phrase.get("de") or "").strip().lower()
    if "verbs" in tags or "verb" in tags or de.endswith("en") or "+ akkusativ" in de or "+ dativ" in de:
        return "verbs"
    if "adjectives" in tags or "adjective" in tags:
        return "adjectives"
    if de.startswith(_ARTICLES):
        return "nouns"
    return "chunks"


@router.get("/vocabulary", response_class=HTMLResponse)
async def vocabulary_page(request: Request):
    selected_level = get_setting("level", "A1")
    packs = content_loader.get_packs_for_level(selected_level)
    phrase_cards = []
    for pack in sorted(packs, key=lambda item: (item.get("recommended_order", 999), item.get("pack_name", ""))):
        for phrase in pack.get("phrases", []):
            phrase_cards.append({
                **phrase,
                "pack_id": pack["pack_id"],
                "pack_name": pack["pack_name"],
                "pack_emoji": pack.get("cover_emoji", "📚"),
                "category": _phrase_category(phrase),
                "search_text": " ".join([
                    phrase.get("de", ""),
                    phrase.get("en", ""),
                    pack.get("pack_name", ""),
                    " ".join(phrase.get("tags", [])),
                ]).lower(),
            })

    phrase_cards.sort(key=lambda item: (
        content_loader.LEVEL_ORDER.get(item.get("level"), 999),
        next(
            (pack.get("recommended_order", 999) for pack in packs if pack["pack_id"] == item["pack_id"]),
            999,
        ),
        item.get("de", ""),
    ))

    counts = {
        "all": len(phrase_cards),
        "verbs": sum(1 for item in phrase_cards if item["category"] == "verbs"),
        "nouns": sum(1 for item in phrase_cards if item["category"] == "nouns"),
        "adjectives": sum(1 for item in phrase_cards if item["category"] == "adjectives"),
        "chunks": sum(1 for item in phrase_cards if item["category"] == "chunks"),
    }

    core_cards = [item for item in phrase_cards if item["pack_id"] in {
        "alphabet_spelling",
        "numbers_basics",
        "greetings",
        "core_verbs",
        "modal_verbs",
        "core_prepositions",
        "adjectives_basics",
    }]

    return templates.TemplateResponse("vocabulary.html", {
        "request": request,
        "selected_level": selected_level,
        "counts": counts,
        "core_cards": core_cards,
        "phrase_cards": phrase_cards,
    })
