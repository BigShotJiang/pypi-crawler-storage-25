from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from auf_deutsch import content_loader
from auf_deutsch.audio_gen import ensure_audio
from auf_deutsch.db import get_setting
from auf_deutsch.template_env import templates

router = APIRouter()


@router.get("/listening", response_class=HTMLResponse)
async def listening_list(request: Request):
    selected_level = get_setting("level", "A1")
    exercises = content_loader.get_listening_for_level(selected_level)
    return templates.TemplateResponse("listening.html", {
        "request": request,
        "exercise": None,
        "selected_level": selected_level,
        "exercise_cards": exercises,
    })


@router.get("/listening/{exercise_id}", response_class=HTMLResponse)
async def listening_detail(request: Request, exercise_id: str):
    exercise = content_loader.get_listening_exercise(exercise_id)
    if not exercise:
        return RedirectResponse("/listening", status_code=303)

    lines = []
    for index, line in enumerate(exercise.get("lines", [])):
        audio_key = f"{exercise['exercise_id']}_{index}"
        lines.append({
            **line,
            "audio_url": ensure_audio(audio_key, line["de"]),
        })

    return templates.TemplateResponse("listening.html", {
        "request": request,
        "exercise": {**exercise, "lines": lines},
        "exercise_cards": None,
        "selected_level": get_setting("level", "A1"),
    })
