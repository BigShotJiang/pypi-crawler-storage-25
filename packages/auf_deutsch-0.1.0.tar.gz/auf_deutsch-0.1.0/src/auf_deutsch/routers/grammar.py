from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from auf_deutsch import content_loader
from auf_deutsch.db import get_setting
from auf_deutsch.template_env import templates

router = APIRouter()


def _group_lessons_by_level(lessons: list[dict]) -> list[dict]:
    grouped: dict[str, list[dict]] = {}
    for lesson in lessons:
        grouped.setdefault(lesson["level"], []).append(lesson)

    result = []
    for level in sorted(grouped.keys(), key=lambda key: content_loader.LEVEL_ORDER.get(key, 999)):
        items = sorted(grouped[level], key=lambda lesson: (lesson.get("order", 999), lesson.get("title", "")))
        categories = []
        seen = set()
        for lesson in items:
            category = lesson.get("category", "grammar")
            if category not in seen:
                seen.add(category)
                categories.append(category)
        track = next((track for track in content_loader.get_all_grammar_tracks() if track.get("level") == level), None)
        result.append({
            "level": level,
            "intro": track.get("intro", "") if track else "",
            "outcomes": track.get("outcomes", []) if track else [],
            "categories": categories,
            "lessons": items,
        })
    return result


def _group_verb_lessons(lessons: list[dict]) -> list[dict]:
    grouped: dict[str, list[dict]] = {}
    for lesson in lessons:
        if lesson.get("category") != "verbs":
            continue
        grouped.setdefault(lesson["level"], []).append(lesson)

    result = []
    for level in sorted(grouped.keys(), key=lambda key: content_loader.LEVEL_ORDER.get(key, 999)):
        items = sorted(grouped[level], key=lambda lesson: (lesson.get("order", 999), lesson.get("title", "")))
        result.append({
            "level": level,
            "lessons": items,
        })
    return result


@router.get("/grammar", response_class=HTMLResponse)
async def grammar_index(request: Request):
    selected_level = get_setting("level", "A1")
    lessons = content_loader.get_grammar_lessons_for_level(selected_level)
    return templates.TemplateResponse("grammar.html", {
        "request": request,
        "lesson": None,
        "level_groups": _group_lessons_by_level(lessons),
        "verb_groups": _group_verb_lessons(lessons),
        "selected_level": selected_level,
    })


@router.get("/grammar/{lesson_id}", response_class=HTMLResponse)
async def grammar_lesson(request: Request, lesson_id: str):
    lesson = content_loader.get_grammar_lesson(lesson_id)
    if not lesson:
        return RedirectResponse("/grammar", status_code=303)

    related_lessons = [
        related for related_id in lesson.get("related_lessons", [])
        if (related := content_loader.get_grammar_lesson(related_id))
    ]
    related_packs = [
        pack for pack_id in lesson.get("related_pack_ids", [])
        if (pack := content_loader.get_pack(pack_id))
    ]

    return templates.TemplateResponse("grammar.html", {
        "request": request,
        "lesson": lesson,
        "related_lessons": related_lessons,
        "related_packs": related_packs,
        "level_groups": None,
        "verb_groups": None,
        "selected_level": get_setting("level", "A1"),
    })
