from fastapi import APIRouter, Body, Request
from fastapi.responses import HTMLResponse
from fastapi.responses import RedirectResponse

from auf_deutsch import learning_engine
from auf_deutsch.audio_gen import ensure_audio
from auf_deutsch.content_loader import (
    get_all_packs,
    get_curriculum_levels,
    get_pack,
    get_phrase,
    level_matches,
)
from auf_deutsch.db import get_all_progress, get_latest_pack_quiz_attempts, get_setting, log_pack_quiz_attempt
from auf_deutsch.template_env import templates

router = APIRouter()


def _group_packs_by_curriculum(pack_data: list[dict], selected_level: str) -> tuple[list[dict], list[dict]]:
    pack_by_id = {pack["pack_id"]: pack for pack in pack_data}
    groups = []
    grouped_ids = set()

    for level in get_curriculum_levels(selected_level):
        for group in level.get("groups", []):
            items = [pack_by_id[pack_id] for pack_id in group.get("pack_ids", []) if pack_id in pack_by_id]
            if not items:
                continue
            groups.append({
                "level": level["level"],
                "level_title": level.get("title", level["level"]),
                "group_id": group["group_id"],
                "title": group.get("title", group["group_id"]),
                "summary": group.get("summary", ""),
                "pack_cards": items,
            })
            grouped_ids.update(pack["pack_id"] for pack in items)

    ungrouped = [pack for pack in pack_data if pack["pack_id"] not in grouped_ids]
    return groups, ungrouped


@router.get("/packs", response_class=HTMLResponse)
async def packs_page(request: Request):
    selected_level = get_setting("level", "A1")
    packs = get_all_packs()
    visible_packs = [
        pack for pack in packs
        if level_matches(pack.get("level"), selected_level)
    ]
    pack_data = learning_engine.annotate_packs(visible_packs, get_all_progress())
    latest_quizzes = get_latest_pack_quiz_attempts()
    for pack in pack_data:
        pack["latest_quiz"] = latest_quizzes.get(pack["pack_id"])
    pack_groups, ungrouped_packs = _group_packs_by_curriculum(pack_data, selected_level)

    return templates.TemplateResponse("packs.html", {
        "request": request,
        "packs": pack_data,
        "pack_groups": pack_groups,
        "ungrouped_packs": ungrouped_packs,
        "recommended_pack": learning_engine.get_recommended_pack(pack_data),
        "next_packs": learning_engine.get_next_unlocked_packs(pack_data, limit=3),
    })


@router.get("/packs/{pack_id}", response_class=HTMLResponse)
async def pack_detail(request: Request, pack_id: str):
    pack = get_pack(pack_id)
    if not pack:
        return HTMLResponse("Pack not found", status_code=404)

    all_progress_rows = get_all_progress()
    pack_cards = learning_engine.annotate_packs(get_all_packs(), all_progress_rows)
    pack_meta = next((item for item in pack_cards if item["pack_id"] == pack_id), pack)
    all_progress = {p["phrase_id"]: p for p in all_progress_rows}
    phrases_with_status = []
    for ph in pack["phrases"]:
        prog = all_progress.get(ph["id"])
        phrases_with_status.append({
            **ph,
            "status": prog["status"] if prog else "new",
            "ease_score": prog["ease_score"] if prog else 2.5,
        })

    return templates.TemplateResponse(
        "packs.html",
        {
            "request": request,
            "packs": None,
            "pack": pack_meta,
            "phrases": phrases_with_status,
            "recommended_pack": learning_engine.get_recommended_pack(pack_cards),
            "latest_quiz": get_latest_pack_quiz_attempts().get(pack_id),
            "next_packs": [
                item for item in learning_engine.get_next_unlocked_packs(pack_cards, limit=4)
                if item["pack_id"] != pack_id
            ][:3],
        },
    )


@router.get("/phrase/{phrase_id}", response_class=HTMLResponse)
async def phrase_detail(request: Request, phrase_id: str):
    phrase = get_phrase(phrase_id)
    if not phrase:
        return HTMLResponse("Phrase not found", status_code=404)

    from auf_deutsch.db import get_phrase_progress
    prog = get_phrase_progress(phrase_id)
    related_phrases = [
        related for related_id in phrase.get("related_ids", [])
        if (related := get_phrase(related_id))
    ]
    audio_url = ensure_audio(phrase["id"], phrase["de"])

    return templates.TemplateResponse(
        "phrase_detail.html",
        {
            "request": request,
            "phrase": phrase,
            "progress": prog,
            "related_phrases": related_phrases,
            "audio_url": audio_url,
        },
    )


@router.get("/packs/{pack_id}/quiz", response_class=HTMLResponse)
async def pack_quiz_page(request: Request, pack_id: str):
    pack = get_pack(pack_id)
    if not pack:
        return RedirectResponse("/packs", status_code=303)

    questions = learning_engine.build_pack_quiz(pack, get_all_packs())
    phrase_by_id = {
        phrase["id"]: phrase
        for other_pack in get_all_packs()
        for phrase in other_pack.get("phrases", [])
    }
    for question in questions:
        if question.get("phrase_id") in phrase_by_id:
            question["phrase"] = phrase_by_id[question["phrase_id"]]
            question["audio_url"] = ensure_audio(question["phrase_id"], phrase_by_id[question["phrase_id"]]["de"])

    return templates.TemplateResponse("pack_quiz.html", {
        "request": request,
        "pack": pack,
        "questions": questions,
        "graded_questions": None,
        "score": None,
        "total": None,
    })


@router.post("/packs/{pack_id}/quiz", response_class=HTMLResponse)
async def pack_quiz_submit(request: Request, pack_id: str):
    pack = get_pack(pack_id)
    if not pack:
        return RedirectResponse("/packs", status_code=303)

    form = await request.form()
    submitted = {key: value for key, value in form.items()}
    questions = learning_engine.build_pack_quiz(pack, get_all_packs())
    phrase_by_id = {
        phrase["id"]: phrase
        for other_pack in get_all_packs()
        for phrase in other_pack.get("phrases", [])
    }
    for question in questions:
        if question.get("phrase_id") in phrase_by_id:
            question["phrase"] = phrase_by_id[question["phrase_id"]]
            question["audio_url"] = ensure_audio(question["phrase_id"], phrase_by_id[question["phrase_id"]]["de"])
    graded_questions = learning_engine.grade_quiz_submission(questions, submitted, phrase_by_id)
    score, total = learning_engine.quiz_score(graded_questions)
    log_pack_quiz_attempt(pack_id, score, total)

    return templates.TemplateResponse("pack_quiz.html", {
        "request": request,
        "pack": pack,
        "questions": questions,
        "graded_questions": graded_questions,
        "score": score,
        "total": total,
    })


@router.post("/packs/{pack_id}/quiz/attempt")
async def pack_quiz_attempt(pack_id: str, payload: dict = Body(...)):
    pack = get_pack(pack_id)
    if not pack:
        return {"ok": False}

    score = int(payload.get("score", 0))
    total = int(payload.get("total", 0))
    if total > 0:
        log_pack_quiz_attempt(pack_id, score, total)
    return {"ok": True}
