import html as html_lib
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from auf_deutsch import content_loader, db
from auf_deutsch.template_env import templates

router = APIRouter()


def _build_paragraph_html(paragraph: dict, phrase_index: dict) -> str:
    """Replace highlighted phrase substrings with annotated <span> tags."""
    text = html_lib.escape(paragraph["de"])
    highlights = paragraph.get("highlighted_phrases", [])

    positioned = []
    for hp in highlights:
        escaped = html_lib.escape(hp["de"])
        pos = text.find(escaped)
        if pos >= 0:
            positioned.append((pos, hp, escaped))
    positioned.sort(key=lambda x: x[0])

    result = []
    last_end = 0
    for pos, hp, escaped in positioned:
        phrase = phrase_index.get(hp["phrase_id"], {})
        result.append(text[last_end:pos])
        de_attr  = html_lib.escape(phrase.get("de", hp["de"]))
        en_attr  = html_lib.escape(phrase.get("en", ""))
        use_attr = html_lib.escape(phrase.get("usage", ""))
        gr_attr  = html_lib.escape(phrase.get("grammar_note", ""))
        result.append(
            f'<span class="phrase-highlight" '
            f'data-id="{hp["phrase_id"]}" '
            f'data-de="{de_attr}" '
            f'data-en="{en_attr}" '
            f'data-usage="{use_attr}" '
            f'data-grammar="{gr_attr}">'
            f'{escaped}</span>'
        )
        last_end = pos + len(escaped)
    result.append(text[last_end:])
    return "".join(result)


@router.get("/stories", response_class=HTMLResponse)
async def stories_list(request: Request):
    stories = content_loader.get_all_stories()
    read_ids = db.get_read_story_ids()
    story_cards = []
    for s in stories:
        para_count = len(s.get("paragraphs", []))
        read_time = s.get("read_time_minutes", max(2, para_count))
        story_cards.append({
            **s,
            "read_time": read_time,
            "is_read": s["story_id"] in read_ids,
        })
    return templates.TemplateResponse("stories.html", {
        "request": request,
        "story_cards": story_cards,
    })


@router.get("/stories/{story_id}", response_class=HTMLResponse)
async def story_reader(request: Request, story_id: str):
    story = content_loader.get_story(story_id)
    if not story:
        return RedirectResponse("/stories")

    phrase_index = {
        ph["id"]: ph
        for pack in content_loader.get_all_packs()
        for ph in pack.get("phrases", [])
    }

    enriched_paragraphs = []
    for para in story.get("paragraphs", []):
        enriched_paragraphs.append({
            **para,
            "de_html": _build_paragraph_html(para, phrase_index),
        })

    read_ids = db.get_read_story_ids()
    read_time = story.get("read_time_minutes", max(2, len(enriched_paragraphs)))

    return templates.TemplateResponse("story_reader.html", {
        "request": request,
        "story": story,
        "paragraphs": enriched_paragraphs,
        "is_read": story_id in read_ids,
        "read_time": read_time,
    })


@router.post("/stories/{story_id}/mark-read")
async def mark_story_read(story_id: str):
    story = content_loader.get_story(story_id)
    if story:
        db.log_story_read(story_id)
    return RedirectResponse(f"/stories/{story_id}", status_code=303)
