from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse

from auf_deutsch import content_validation
from auf_deutsch.template_env import templates

router = APIRouter()


@router.get("/authoring", response_class=HTMLResponse)
async def authoring_page(request: Request):
    report = content_validation.validate_content()
    return templates.TemplateResponse("authoring.html", {
        "request": request,
        "report": report,
    })
