import sys

from auf_deutsch import content_validation


def main() -> int:
    report = content_validation.validate_content()
    summary = report["summary"]
    print(
        f"Packs: {summary['packs']} | Dialogues: {summary['dialogues']} | "
        f"Stories: {summary['stories']} | Grammar lessons: {summary['grammar_lessons']} | "
        f"Listening exercises: {summary['listening_exercises']} | Curriculum levels: {summary['curriculum_levels']} | "
        f"Phrases: {summary['phrases']}"
    )
    print(f"Errors: {summary['errors']} | Warnings: {summary['warnings']}")

    for issue in report["issues"]:
        print(f"[{issue['severity'].upper()}] {issue['file']}: {issue['message']}")

    return 1 if summary["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
