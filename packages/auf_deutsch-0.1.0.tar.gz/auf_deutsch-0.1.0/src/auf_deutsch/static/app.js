/* Auf Deutsch – app.js */

const sharedAudioPlayer = new Audio();
sharedAudioPlayer.preload = "auto";

function stopSpeech() {
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
}

function playAudioUrl(url) {
  return new Promise((resolve, reject) => {
    if (!url) {
      reject(new Error("Missing audio URL"));
      return;
    }
    sharedAudioPlayer.onended = () => resolve();
    sharedAudioPlayer.onerror = () => reject(new Error("Audio playback failed"));
    sharedAudioPlayer.pause();
    sharedAudioPlayer.src = url;
    sharedAudioPlayer.currentTime = 0;
    sharedAudioPlayer.play().catch(reject);
  });
}

function speakText(text) {
  return new Promise((resolve, reject) => {
    if (!text || !("speechSynthesis" in window)) {
      reject(new Error("Speech synthesis unavailable"));
      return;
    }
    stopSpeech();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "de-DE";
    utterance.rate = 0.92;
    utterance.onend = () => resolve();
    utterance.onerror = () => reject(new Error("Speech synthesis failed"));
    window.speechSynthesis.speak(utterance);
  });
}

function playAudioOrSpeak(url, text) {
  stopSpeech();
  if (url) {
    return playAudioUrl(url).catch(() => speakText(text));
  }
  return speakText(text).catch(() => Promise.resolve());
}

function playAudio(url, text) {
  if (!url && !text) return;
  playAudioOrSpeak(url, text).catch(() => {});
}

function playAudioSequence(items) {
  const validItems = (items || []).filter((item) => {
    if (!item) return false;
    if (typeof item === "string") return Boolean(item);
    return Boolean(item.url || item.text);
  });
  let chain = Promise.resolve();
  validItems.forEach((item) => {
    const audioItem = typeof item === "string" ? { url: item, text: "" } : item;
    chain = chain.then(() => playAudioOrSpeak(audioItem.url, audioItem.text).catch(() => {}));
  });
  return chain;
}

// Auto-focus answer input
document.addEventListener("DOMContentLoaded", () => {
  const inp = document.querySelector(".answer-input");
  if (inp) inp.focus();
});

// Allow submitting answer form with Enter key
document.addEventListener("DOMContentLoaded", () => {
  const inp = document.querySelector(".answer-input");
  if (inp) {
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        inp.closest("form").submit();
      }
    });
  }
});
