from datetime import date, timedelta
import sqlite3
from auf_deutsch.db import get_db


RATING_AGAIN = "again"
RATING_HARD = "hard"
RATING_GOOD = "good"
RATING_EASY = "easy"


def update_progress(phrase_id: str, rating: str) -> str:
    """Update SRS progress for a phrase. Returns next due date as ISO string."""
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM phrase_progress WHERE phrase_id=?", (phrase_id,)
    ).fetchone()

    today = date.today()

    if row is None:
        # Insert new
        conn.execute(
            "INSERT OR IGNORE INTO phrase_progress (phrase_id) VALUES (?)", (phrase_id,)
        )
        conn.commit()
        row = conn.execute(
            "SELECT * FROM phrase_progress WHERE phrase_id=?", (phrase_id,)
        ).fetchone()

    status = row["status"]
    ease = row["ease_score"] or 2.5
    interval = row["interval_days"] or 0
    lapses = row["lapse_count"] or 0
    reviews = row["review_count"] or 0

    if status == "new" or interval == 0:
        # First review
        if rating == RATING_AGAIN:
            new_interval = 0
            new_due = today
            new_status = "learning"
        elif rating == RATING_HARD:
            new_interval = 1
            new_due = today + timedelta(days=1)
            new_status = "learning"
        elif rating == RATING_GOOD:
            new_interval = 2
            new_due = today + timedelta(days=2)
            new_status = "learning"
        else:  # easy
            new_interval = 4
            new_due = today + timedelta(days=4)
            new_status = "review"
        new_ease = ease
    else:
        # Review card
        if rating == RATING_AGAIN:
            new_interval = 1
            new_due = today + timedelta(days=1)
            new_status = "learning"
            new_ease = max(1.3, ease - 0.2)
            lapses += 1
        elif rating == RATING_HARD:
            new_interval = max(1, int(interval * 1.2))
            new_due = today + timedelta(days=new_interval)
            new_status = "review"
            new_ease = max(1.3, ease - 0.15)
        elif rating == RATING_GOOD:
            new_interval = max(1, int(interval * ease))
            new_due = today + timedelta(days=new_interval)
            new_status = "review"
            new_ease = ease
        else:  # easy
            new_interval = max(1, int(interval * ease * 1.3))
            new_due = today + timedelta(days=new_interval)
            new_status = "mastered" if new_interval > 21 else "review"
            new_ease = min(4.0, ease + 0.15)

    reviews += 1

    conn.execute(
        """UPDATE phrase_progress SET
            status=?, ease_score=?, interval_days=?, due_date=?,
            review_count=?, lapse_count=?, last_reviewed=?
           WHERE phrase_id=?""",
        (
            new_status,
            round(new_ease, 3),
            new_interval,
            new_due.isoformat(),
            reviews,
            lapses,
            today.isoformat(),
            phrase_id,
        ),
    )
    conn.commit()
    conn.close()
    return new_due.isoformat()


def get_due_phrases(limit=5) -> list:
    today = date.today().isoformat()
    conn = get_db()
    rows = conn.execute(
        """SELECT phrase_id FROM phrase_progress
           WHERE status IN ('learning', 'review')
           AND (due_date IS NULL OR due_date <= ?)
           ORDER BY due_date ASC
           LIMIT ?""",
        (today, limit),
    ).fetchall()
    conn.close()
    return [r["phrase_id"] for r in rows]
