import hashlib
import json
import threading
from pathlib import Path

from auf_deutsch.paths import runtime_static_dir

AUDIO_DIR = runtime_static_dir() / "audio"
AUDIO_INDEX_PATH = AUDIO_DIR / "_index.json"
_audio_lock = threading.Lock()
_audio_index_cache: dict[str, dict] | None = None


def _text_hash(text: str) -> str:
    return hashlib.sha1((text or "").encode("utf-8")).hexdigest()


def _load_audio_index() -> dict[str, dict]:
    global _audio_index_cache
    if _audio_index_cache is not None:
        return _audio_index_cache
    if not AUDIO_INDEX_PATH.exists():
        _audio_index_cache = {}
        return _audio_index_cache
    try:
        _audio_index_cache = json.loads(AUDIO_INDEX_PATH.read_text(encoding="utf-8"))
    except Exception:
        _audio_index_cache = {}
    return _audio_index_cache


def _save_audio_index(index: dict[str, dict]) -> None:
    global _audio_index_cache
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    AUDIO_INDEX_PATH.write_text(json.dumps(index, indent=2, sort_keys=True), encoding="utf-8")
    _audio_index_cache = index


def _audio_url(audio_id: str) -> str:
    return f"/static/audio/{audio_id}.mp3"


def _clear_bad_audio_file(path: Path) -> None:
    if path.exists() and path.stat().st_size <= 0:
        try:
            path.unlink()
        except Exception:
            pass


def _has_valid_audio(path: Path) -> bool:
    if not path.exists():
        return False
    if path.stat().st_size <= 0:
        _clear_bad_audio_file(path)
        return False
    return True


def ensure_audio(audio_id: str, german_text: str) -> str:
    """Generate a cached mp3 for audio_id if needed. Returns the local static URL or an empty string."""
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    out_path = AUDIO_DIR / f"{audio_id}.mp3"
    text_hash = _text_hash(german_text)

    with _audio_lock:
        index = _load_audio_index()
        existing = index.get(audio_id, {})
        if _has_valid_audio(out_path):
            if existing.get("text_hash") != text_hash or existing.get("status") != "ready":
                index[audio_id] = {
                    "status": "ready",
                    "text_hash": text_hash,
                    "size": out_path.stat().st_size,
                }
                _save_audio_index(index)
            return _audio_url(audio_id)

        if existing.get("status") == "failed" and existing.get("text_hash") == text_hash:
            return ""

        index[audio_id] = {
            "status": "generating",
            "text_hash": text_hash,
        }
        _save_audio_index(index)

    tmp_path = AUDIO_DIR / f"{audio_id}.tmp.mp3"
    try:
        from gtts import gTTS

        if tmp_path.exists():
            tmp_path.unlink()
        tts = gTTS(text=german_text, lang="de", slow=False)
        tts.save(str(tmp_path))
        if not tmp_path.exists() or tmp_path.stat().st_size <= 0:
            raise RuntimeError("Generated audio file is empty.")
        tmp_path.replace(out_path)
    except Exception as exc:
        for path in (tmp_path, out_path):
            _clear_bad_audio_file(path)
        with _audio_lock:
            index = _load_audio_index()
            index[audio_id] = {
                "status": "failed",
                "text_hash": text_hash,
                "error": str(exc),
            }
            _save_audio_index(index)
        print(f"[audio] Failed to generate {audio_id}: {exc}")
        return ""

    with _audio_lock:
        index = _load_audio_index()
        index[audio_id] = {
            "status": "ready",
            "text_hash": text_hash,
            "size": out_path.stat().st_size,
        }
        _save_audio_index(index)
    return _audio_url(audio_id)


def _iter_audio_jobs(packs: list, dialogues: list, listening_exercises: list | None = None):
    for pack in packs:
        for phrase in pack.get("phrases", []):
            yield phrase["id"], phrase["de"]
    for dialogue in dialogues:
        for index, line in enumerate(dialogue.get("lines", [])):
            yield f"{dialogue['dialogue_id']}_{index}", line["de"]
    for exercise in listening_exercises or []:
        for index, line in enumerate(exercise.get("lines", [])):
            yield f"{exercise['exercise_id']}_{index}", line["de"]


def clean_audio_cache() -> None:
    """Remove broken zero-byte audio files and stale failed entries for missing files."""
    global _audio_index_cache
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    for audio_file in AUDIO_DIR.glob("*.mp3"):
        _clear_bad_audio_file(audio_file)

    with _audio_lock:
        index = _load_audio_index()
        cleaned = {}
        for audio_id, meta in index.items():
            audio_path = AUDIO_DIR / f"{audio_id}.mp3"
            if meta.get("status") == "ready" and _has_valid_audio(audio_path):
                cleaned[audio_id] = meta
                continue
            if meta.get("status") == "failed" and not audio_path.exists():
                cleaned[audio_id] = meta
        _audio_index_cache = cleaned
        _save_audio_index(cleaned)


def generate_all_audio(packs: list, dialogues: list, listening_exercises: list | None = None):
    """Background thread: generate audio for phrases, dialogues, and listening lines."""

    def _run():
        for audio_id, german_text in _iter_audio_jobs(packs, dialogues, listening_exercises):
            ensure_audio(audio_id, german_text)
        print("[audio] Background audio generation complete.")

    threading.Thread(target=_run, daemon=True).start()


def regenerate_all_audio(packs: list, dialogues: list, listening_exercises: list | None = None):
    """Delete cached mp3s and rebuild the audio index in the background."""

    def _run():
        global _audio_index_cache
        AUDIO_DIR.mkdir(parents=True, exist_ok=True)
        for audio_file in AUDIO_DIR.glob("*.mp3"):
            try:
                audio_file.unlink()
            except Exception:
                pass
        if AUDIO_INDEX_PATH.exists():
            try:
                AUDIO_INDEX_PATH.unlink()
            except Exception:
                pass
        _audio_index_cache = None
        for audio_id, german_text in _iter_audio_jobs(packs, dialogues, listening_exercises):
            ensure_audio(audio_id, german_text)
        print("[audio] Regeneration complete.")

    threading.Thread(target=_run, daemon=True).start()
