from __future__ import annotations

import argparse
import os

import uvicorn

from auf_deutsch.paths import ensure_runtime_static_assets


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="auf-deutsch",
        description="Run the Auf Deutsch local learning app.",
    )
    parser.add_argument("--host", default="127.0.0.1", help="Host interface to bind to.")
    parser.add_argument("--port", type=int, default=8000, help="Port to listen on.")
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not open the app automatically in a browser.",
    )
    parser.add_argument(
        "--skip-audio",
        action="store_true",
        help="Skip background audio generation on startup.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    ensure_runtime_static_assets()
    os.environ["AUF_OPEN_BROWSER"] = "0" if args.no_browser else "1"
    os.environ["AUF_BROWSER_URL"] = f"http://{args.host}:{args.port}"
    if args.skip_audio:
        os.environ["AUF_SKIP_STARTUP_AUDIO"] = "1"
    uvicorn.run("auf_deutsch.app:app", host=args.host, port=args.port, reload=False)
    return 0
