import json
from pathlib import Path

from auf_deutsch.paths import package_path

PACKS_DIR = package_path("content", "packs")
DIALOGUES_DIR = package_path("content", "dialogues")
STORIES_DIR = package_path("content", "stories")
GRAMMAR_DIR = package_path("content", "grammar")
LISTENING_DIR = package_path("content", "listening")
CURRICULUM_PATH = package_path("content", "curriculum.json")


def _load_json_files(directory: Path, kind: str) -> tuple[list[dict], list[dict]]:
    records = []
    issues = []
    for path in sorted(directory.glob("*.json")):
        try:
            records.append({
                "path": path,
                "kind": kind,
                "data": json.loads(path.read_text(encoding="utf-8")),
            })
        except Exception as exc:
            issues.append({
                "severity": "error",
                "file": str(path),
                "message": f"Invalid JSON: {exc}",
            })
    return records, issues


def validate_content() -> dict:
    issues: list[dict] = []
    pack_records, pack_issues = _load_json_files(PACKS_DIR, "pack")
    dialogue_records, dialogue_issues = _load_json_files(DIALOGUES_DIR, "dialogue")
    story_records, story_issues = _load_json_files(STORIES_DIR, "story")
    grammar_records, grammar_issues = _load_json_files(GRAMMAR_DIR, "grammar")
    listening_records, listening_issues = _load_json_files(LISTENING_DIR, "listening")
    curriculum_data = None
    issues.extend(pack_issues)
    issues.extend(dialogue_issues)
    issues.extend(story_issues)
    issues.extend(grammar_issues)
    issues.extend(listening_issues)
    if CURRICULUM_PATH.exists():
        try:
            curriculum_data = json.loads(CURRICULUM_PATH.read_text(encoding="utf-8"))
        except Exception as exc:
            issues.append({
                "severity": "error",
                "file": str(CURRICULUM_PATH),
                "message": f"Invalid JSON: {exc}",
            })

    pack_ids = {}
    phrase_ids = {}
    story_ids = {}
    dialogue_ids = {}
    grammar_lesson_ids = {}
    listening_ids = {}

    for record in pack_records:
        data = record["data"]
        path = str(record["path"])
        pack_id = data.get("pack_id")
        if not pack_id:
            issues.append({"severity": "error", "file": path, "message": "Missing pack_id."})
            continue
        if pack_id in pack_ids:
            issues.append({"severity": "error", "file": path, "message": f"Duplicate pack_id '{pack_id}'."})
        pack_ids[pack_id] = data

        if not data.get("pack_name") and not data.get("name"):
            issues.append({"severity": "warning", "file": path, "message": f"Pack '{pack_id}' is missing pack_name/name."})

        for prerequisite_id in data.get("prerequisites", []):
            if prerequisite_id == pack_id:
                issues.append({"severity": "error", "file": path, "message": f"Pack '{pack_id}' cannot depend on itself."})

        for phrase in data.get("phrases", []):
            phrase_id = phrase.get("id")
            if not phrase_id:
                issues.append({"severity": "error", "file": path, "message": f"Pack '{pack_id}' has a phrase without id."})
                continue
            if phrase_id in phrase_ids:
                issues.append({"severity": "error", "file": path, "message": f"Duplicate phrase_id '{phrase_id}'."})
            phrase_ids[phrase_id] = phrase

            if not phrase.get("de") or not phrase.get("en"):
                issues.append({"severity": "error", "file": path, "message": f"Phrase '{phrase_id}' needs both 'de' and 'en'."})

    for record in pack_records:
        data = record["data"]
        path = str(record["path"])
        pack_id = data.get("pack_id")
        for prerequisite_id in data.get("prerequisites", []):
            if prerequisite_id not in pack_ids:
                issues.append({"severity": "error", "file": path, "message": f"Pack '{pack_id}' depends on missing pack '{prerequisite_id}'."})
        for phrase in data.get("phrases", []):
            phrase_id = phrase.get("id")
            for related_id in phrase.get("related_ids", []):
                if related_id not in phrase_ids:
                    issues.append({"severity": "warning", "file": path, "message": f"Phrase '{phrase_id}' points to missing related phrase '{related_id}'."})

    for record in dialogue_records:
        data = record["data"]
        path = str(record["path"])
        dialogue_id = data.get("dialogue_id")
        if not dialogue_id:
            issues.append({"severity": "error", "file": path, "message": "Missing dialogue_id."})
            continue
        if dialogue_id in dialogue_ids:
            issues.append({"severity": "error", "file": path, "message": f"Duplicate dialogue_id '{dialogue_id}'."})
        dialogue_ids[dialogue_id] = data

        if data.get("pack_id") not in pack_ids:
            issues.append({"severity": "error", "file": path, "message": f"Dialogue '{dialogue_id}' points to missing pack '{data.get('pack_id')}'."})

        for phrase_id in data.get("target_phrase_ids", []):
            if phrase_id not in phrase_ids:
                issues.append({"severity": "warning", "file": path, "message": f"Dialogue '{dialogue_id}' targets missing phrase '{phrase_id}'."})

        if not data.get("lines"):
            issues.append({"severity": "warning", "file": path, "message": f"Dialogue '{dialogue_id}' has no lines."})

    for record in story_records:
        data = record["data"]
        path = str(record["path"])
        story_id = data.get("story_id")
        if not story_id:
            issues.append({"severity": "error", "file": path, "message": "Missing story_id."})
            continue
        if story_id in story_ids:
            issues.append({"severity": "error", "file": path, "message": f"Duplicate story_id '{story_id}'."})
        story_ids[story_id] = data

        for pack_id in data.get("pack_ids", []):
            if pack_id not in pack_ids:
                issues.append({"severity": "warning", "file": path, "message": f"Story '{story_id}' references missing pack '{pack_id}'."})

        for paragraph in data.get("paragraphs", []):
            german_text = paragraph.get("de", "")
            for highlight in paragraph.get("highlighted_phrases", []):
                phrase_id = highlight.get("phrase_id") or highlight.get("id")
                highlight_text = highlight.get("de", "")
                if phrase_id not in phrase_ids:
                    issues.append({"severity": "warning", "file": path, "message": f"Story '{story_id}' highlights missing phrase '{phrase_id}'."})
                if highlight_text and highlight_text not in german_text:
                    issues.append({"severity": "error", "file": path, "message": f"Story '{story_id}' highlight '{highlight_text}' is not present verbatim in its paragraph."})

    for record in grammar_records:
        data = record["data"]
        path = str(record["path"])
        track_id = data.get("track_id")
        if not track_id:
            issues.append({"severity": "error", "file": path, "message": "Missing track_id."})
            continue
        for lesson in data.get("lessons", []):
            lesson_id = lesson.get("lesson_id")
            if not lesson_id:
                issues.append({"severity": "error", "file": path, "message": f"Grammar track '{track_id}' has a lesson without lesson_id."})
                continue
            if lesson_id in grammar_lesson_ids:
                issues.append({"severity": "error", "file": path, "message": f"Duplicate grammar lesson_id '{lesson_id}'."})
            grammar_lesson_ids[lesson_id] = lesson
            if not lesson.get("title") or not lesson.get("summary"):
                issues.append({"severity": "warning", "file": path, "message": f"Grammar lesson '{lesson_id}' should have both title and summary."})
            for pack_id in lesson.get("related_pack_ids", []):
                if pack_id not in pack_ids:
                    issues.append({"severity": "warning", "file": path, "message": f"Grammar lesson '{lesson_id}' references missing pack '{pack_id}'."})

    for record in grammar_records:
        data = record["data"]
        path = str(record["path"])
        for lesson in data.get("lessons", []):
            lesson_id = lesson.get("lesson_id")
            for related_id in lesson.get("related_lessons", []):
                if related_id not in grammar_lesson_ids:
                    issues.append({"severity": "warning", "file": path, "message": f"Grammar lesson '{lesson_id}' references missing grammar lesson '{related_id}'."})

    for record in listening_records:
        data = record["data"]
        path = str(record["path"])
        exercise_id = data.get("exercise_id")
        if not exercise_id:
            issues.append({"severity": "error", "file": path, "message": "Missing exercise_id."})
            continue
        if exercise_id in listening_ids:
            issues.append({"severity": "error", "file": path, "message": f"Duplicate listening exercise_id '{exercise_id}'."})
        listening_ids[exercise_id] = data
        if not data.get("lines"):
            issues.append({"severity": "warning", "file": path, "message": f"Listening exercise '{exercise_id}' has no lines."})
        if not data.get("questions"):
            issues.append({"severity": "warning", "file": path, "message": f"Listening exercise '{exercise_id}' has no questions."})
        for pack_id in data.get("related_pack_ids", []):
            if pack_id not in pack_ids:
                issues.append({"severity": "warning", "file": path, "message": f"Listening exercise '{exercise_id}' references missing pack '{pack_id}'."})
        for question in data.get("questions", []):
            if not question.get("question_de") or not question.get("answer_de"):
                issues.append({"severity": "warning", "file": path, "message": f"Listening exercise '{exercise_id}' has a question missing question_de or answer_de."})

    curriculum_levels = 0
    if curriculum_data is not None:
        seen_groups = set()
        pack_to_group = {}
        for level in curriculum_data.get("levels", []):
            curriculum_levels += 1
            level_name = level.get("level")
            if not level_name:
                issues.append({"severity": "error", "file": str(CURRICULUM_PATH), "message": "Curriculum level entry is missing 'level'."})
                continue
            for group in level.get("groups", []):
                group_id = group.get("group_id")
                if not group_id:
                    issues.append({"severity": "error", "file": str(CURRICULUM_PATH), "message": f"Curriculum level '{level_name}' has a group without group_id."})
                    continue
                if group_id in seen_groups:
                    issues.append({"severity": "error", "file": str(CURRICULUM_PATH), "message": f"Duplicate curriculum group_id '{group_id}'."})
                seen_groups.add(group_id)
                for pack_id in group.get("pack_ids", []):
                    if pack_id not in pack_ids:
                        issues.append({"severity": "error", "file": str(CURRICULUM_PATH), "message": f"Curriculum group '{group_id}' references missing pack '{pack_id}'."})
                    if pack_id in pack_to_group:
                        issues.append({"severity": "warning", "file": str(CURRICULUM_PATH), "message": f"Pack '{pack_id}' appears in both '{pack_to_group[pack_id]}' and '{group_id}'."})
                    pack_to_group[pack_id] = group_id

    summary = {
        "packs": len(pack_records),
        "dialogues": len(dialogue_records),
        "stories": len(story_records),
        "grammar_lessons": len(grammar_lesson_ids),
        "listening_exercises": len(listening_ids),
        "curriculum_levels": curriculum_levels,
        "phrases": len(phrase_ids),
        "issues": len(issues),
        "errors": sum(1 for issue in issues if issue["severity"] == "error"),
        "warnings": sum(1 for issue in issues if issue["severity"] == "warning"),
    }
    return {
        "summary": summary,
        "issues": issues,
        "pack_files": [{"path": str(record["path"]), "pack_id": record["data"].get("pack_id"), "name": record["data"].get("pack_name") or record["data"].get("name", "")} for record in pack_records],
        "dialogue_files": [{"path": str(record["path"]), "dialogue_id": record["data"].get("dialogue_id"), "pack_id": record["data"].get("pack_id", "")} for record in dialogue_records],
        "story_files": [{"path": str(record["path"]), "story_id": record["data"].get("story_id"), "title": record["data"].get("title_de", "")} for record in story_records],
        "grammar_files": [{"path": str(record["path"]), "track_id": record["data"].get("track_id"), "title": record["data"].get("title", "")} for record in grammar_records],
        "listening_files": [{"path": str(record["path"]), "exercise_id": record["data"].get("exercise_id"), "title": record["data"].get("title", "")} for record in listening_records],
        "curriculum_file": str(CURRICULUM_PATH) if curriculum_data is not None else "",
    }
