from pathlib import Path
import re

from setuptools import find_packages, setup


ROOT = Path(__file__).parent
README = (ROOT / "README.md").read_text(encoding="utf-8")
VERSION = re.search(
    r'__version__\s*=\s*"([^"]+)"',
    (ROOT / "src" / "auf_deutsch" / "__init__.py").read_text(encoding="utf-8"),
).group(1)


setup(
    name="auf-deutsch",
    version=VERSION,
    description="Open source German learning app you can pip install and run locally.",
    long_description=README,
    long_description_content_type="text/markdown",
    license="MIT",
    url="https://github.com/jrootn/auf-deutsch",
    maintainer="jrootn",
    maintainer_email="jerardhjosekutty@yahoo.com",
    python_requires=">=3.10",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    include_package_data=True,
    package_data={
        "auf_deutsch": [
            "content/**/*.json",
            "static/**/*",
            "templates/**/*.html",
        ],
    },
    install_requires=[
        "fastapi>=0.111",
        "uvicorn>=0.30",
        "jinja2>=3.1",
        "gtts>=2.5",
        "itsdangerous>=2.2",
        "python-multipart>=0.0.9",
    ],
    extras_require={
        "dev": [
            "build>=1.2",
            "httpx>=0.27",
            "pytest>=8.2",
            "twine>=5.1",
        ],
    },
    entry_points={
        "console_scripts": [
            "auf-deutsch=auf_deutsch.cli:main",
            "auf-deutsch-validate=auf_deutsch.validate_content:main",
        ]
    },
    project_urls={
        "Homepage": "https://github.com/jrootn/auf-deutsch",
        "Source": "https://github.com/jrootn/auf-deutsch",
        "Issues": "https://github.com/jrootn/auf-deutsch/issues",
    },
    keywords=["german", "language-learning", "fastapi", "education", "srs"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Web Environment",
        "Framework :: FastAPI",
        "Intended Audience :: Education",
        "Intended Audience :: End Users/Desktop",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Education",
    ],
)
