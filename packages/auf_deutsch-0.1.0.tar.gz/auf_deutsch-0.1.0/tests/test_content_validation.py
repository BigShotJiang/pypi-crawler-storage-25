from auf_deutsch import content_validation


def test_content_has_no_errors():
    report = content_validation.validate_content()
    assert report["summary"]["errors"] == 0
