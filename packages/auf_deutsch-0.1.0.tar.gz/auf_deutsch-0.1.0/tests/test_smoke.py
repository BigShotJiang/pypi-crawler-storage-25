import importlib

from fastapi.testclient import TestClient


def test_home_page_renders(monkeypatch, tmp_path):
    monkeypatch.setenv("AUF_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("AUF_SKIP_STARTUP_AUDIO", "1")

    import auf_deutsch.paths
    import auf_deutsch.db
    import auf_deutsch.audio_gen
    import auf_deutsch.content_loader
    import auf_deutsch.template_env
    import auf_deutsch.app

    importlib.reload(auf_deutsch.paths)
    importlib.reload(auf_deutsch.db)
    importlib.reload(auf_deutsch.audio_gen)
    importlib.reload(auf_deutsch.content_loader)
    importlib.reload(auf_deutsch.template_env)
    app_module = importlib.reload(auf_deutsch.app)

    with TestClient(app_module.app) as client:
        response = client.get("/")

    assert response.status_code == 200
    assert "Auf Deutsch" in response.text
