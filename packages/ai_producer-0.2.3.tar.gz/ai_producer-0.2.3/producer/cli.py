"""``producer`` command-line entry point.

Subcommands:
    init        Scaffold producer.yaml + agent prompts + agent-state/.
    run         Long-running poll loop (default; supports --once).
    report      Write a morning report and exit.
    task add    Insert a new pending task.
    task list   List tasks (default: pending).
    kill        Arm the kill switch.
    resume      Disarm the kill switch.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import shutil
import string
import sys
from pathlib import Path

from dotenv import load_dotenv

from producer import __version__, onboarding
from producer.config import load_config
from producer.dispatch import Producer
from producer.invoker import ClaudeAgentInvoker
from producer.kill_switch import KillSwitchWatcher
from producer.ledger import LedgerClient

logger = logging.getLogger("producer.cli")

_TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "templates"
_DEFAULT_CONFIG_PATH = "producer.yaml"


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


def cmd_init(args: argparse.Namespace) -> int:
    target_root = Path(args.dir or ".").resolve()
    target_root.mkdir(parents=True, exist_ok=True)

    cfg_dst = target_root / "producer.yaml"
    if cfg_dst.exists() and not args.force:
        print(f"refusing to overwrite {cfg_dst} (use --force)")
        return 2

    src_yaml = _TEMPLATES_DIR / "producer.yaml.example"
    src_prompt = _TEMPLATES_DIR / "agent_prompt_template.md"
    src_seed = _TEMPLATES_DIR / "seed_tasks.example.json"
    if not src_yaml.exists() or not src_prompt.exists():
        print(f"templates dir missing files at {_TEMPLATES_DIR}")
        return 1

    # ---- Phase 1a: collect settings (interactive or default-only) ----
    defaults = onboarding.default_settings(target_root)
    if args.non_interactive:
        settings = dict(defaults)
    else:
        settings = onboarding.prompt_for_settings(defaults=defaults)

    # ---- Phase 1b: scaffold producer.yaml + role prompts + ledger ----
    yaml_body = string.Template(
        src_yaml.read_text(encoding="utf-8")
    ).substitute(**settings)
    cfg_dst.write_text(yaml_body, encoding="utf-8")
    cfg = load_config(cfg_dst)

    for role_name, role in cfg.roles.items():
        if role.prompt is None:
            continue
        prompt_path = cfg.project_root / role.prompt
        if prompt_path.exists() and not args.force:
            continue
        prompt_path.parent.mkdir(parents=True, exist_ok=True)
        body = string.Template(
            src_prompt.read_text(encoding="utf-8")
        ).safe_substitute(
            role=role_name,
            role_title=role_name.title(),
            project_name=cfg.project_name,
            project_root=str(cfg.project_root),
        )
        prompt_path.write_text(body, encoding="utf-8")

    cfg.ledger_db.parent.mkdir(parents=True, exist_ok=True)
    ledger = LedgerClient(db_path=cfg.ledger_db)
    ledger.append_audit(
        agent_owner="producer",
        action="schema_init",
        detail={"schema_version": 1},
    )
    ledger.close()

    seed_dst = cfg.project_root / "seed_tasks.example.json"
    if not seed_dst.exists() or args.force:
        shutil.copy2(src_seed, seed_dst)

    # ---- Phase 1c: write the bootstrap brief ----
    onboarding_md = cfg.project_root / "ONBOARDING.md"
    onboarding_md.write_text(
        onboarding.render_onboarding_md(
            project_name=cfg.project_name,
            project_root=str(cfg.project_root),
        ),
        encoding="utf-8",
    )

    print(f"initialized at {cfg.project_root}")
    print(f"  config:    {cfg_dst}")
    print(f"  ledger:    {cfg.ledger_db}")
    print(f"  prompts:   {cfg.project_root / 'agents'}/")
    print(f"  seed ex:   {seed_dst}")
    print(f"  onboard:   {onboarding_md}")

    # ---- Phase 2: handoff to claude CLI ----
    if args.no_chat:
        return 0

    # Preflight runs after scaffolding intentionally: the scaffold is durable
    # and useful even if claude isn't installed yet — user can install and re-run.
    if not onboarding.preflight_claude_on_path():
        print(
            "Note: `claude` CLI not found on PATH; skipping bootstrap chat. "
            "Install Claude Code and run `claude` in this directory to "
            "start the bootstrap chat (it will pick up ONBOARDING.md)."
        )
        return 0

    argv = onboarding.build_claude_argv(_project_root=str(cfg.project_root))
    print(f"Handing off to claude in {cfg.project_root}\u2026")
    try:
        os.execvp(argv[0], argv)
    except OSError as exc:
        print(f"Failed to launch claude: {exc}")
        print(
            "Scaffolding succeeded. Run `claude` in this directory to start "
            "the bootstrap chat."
        )
        return 0

    return 0  # unreachable on successful execvp


# ---------------------------------------------------------------------------
# run
# ---------------------------------------------------------------------------


async def _run(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    ledger = LedgerClient(db_path=cfg.ledger_db)
    invoker = ClaudeAgentInvoker(cwd=cfg.project_root, auth_config=cfg.auth)
    producer = Producer(
        config=cfg,
        ledger=ledger,
        invoker=invoker,
        kill_switch=KillSwitchWatcher(path=cfg.kill_switch),
    )
    if args.once:
        n = await producer.run_once()
        logger.info("Single-pass complete; dispatched %d task(s).", n)
        return 0
    await producer.run()
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    return asyncio.run(_run(args))


# ---------------------------------------------------------------------------
# report
# ---------------------------------------------------------------------------


def cmd_report(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    ledger = LedgerClient(db_path=cfg.ledger_db)
    producer = Producer(
        config=cfg,
        ledger=ledger,
        invoker=None,  # not used by write_morning_report
        kill_switch=KillSwitchWatcher(path=cfg.kill_switch),
    )
    path = producer.write_morning_report(target_date=args.date)
    ledger.close()
    print(str(path))
    return 0


# ---------------------------------------------------------------------------
# task add / list
# ---------------------------------------------------------------------------


def cmd_task_add(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    ledger = LedgerClient(db_path=cfg.ledger_db)
    payload = json.loads(args.payload) if args.payload else {}
    deps = args.dependencies.split(",") if args.dependencies else []
    tid = ledger.insert_task(
        agent_owner=args.agent,
        title=args.title,
        description=args.description,
        payload=payload,
        priority=args.priority,
        dependencies=[d for d in deps if d],
    )
    ledger.close()
    print(tid)
    return 0


def cmd_task_list(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    ledger = LedgerClient(db_path=cfg.ledger_db)
    sql = (
        "SELECT id, agent_owner, status, priority, title FROM tasks "
        "WHERE status = ? ORDER BY priority ASC, created_at ASC"
    )
    rows = ledger.conn.execute(sql, (args.status,)).fetchall()
    if not rows:
        print(f"(no tasks with status={args.status})")
    else:
        for r in rows:
            print(
                f"{r['id']}  p{r['priority']}  [{r['agent_owner']}]  {r['title']}"
            )
    ledger.close()
    return 0


# ---------------------------------------------------------------------------
# kill / resume
# ---------------------------------------------------------------------------


def cmd_kill(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    ks = KillSwitchWatcher(path=cfg.kill_switch)
    ks.arm(args.reason or "armed via CLI")
    print(f"kill switch armed at {ks.path}")
    return 0


def cmd_resume(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    ks = KillSwitchWatcher(path=cfg.kill_switch)
    ks.disarm()
    print(f"kill switch disarmed at {ks.path}")
    return 0


# ---------------------------------------------------------------------------
# pricing
# ---------------------------------------------------------------------------


def cmd_pricing_update(args: argparse.Namespace) -> int:
    from producer import pricing_updater

    async def _run():
        return await pricing_updater.update_pricing(dry_run=args.dry_run)

    diff = asyncio.run(_run())
    if not diff:
        print("No rate changes.")
        return 0
    for model, changes in diff.items():
        if not changes:
            continue
        print(f"{model}:")
        for k, (old, new) in changes.items():
            old_s = "<absent>" if old is None else f"{old:.4f}"
            new_s = "<absent>" if new is None else f"{new:.4f}"
            print(f"  {k}: {old_s} → {new_s}")
    if args.dry_run:
        print("(dry run — no file written)")
    return 0


# ---------------------------------------------------------------------------
# argparse wiring
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="producer",
        description="Agentic orchestration: SQLite-WAL ledger + Claude Agent SDK dispatcher.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--config",
        default=_DEFAULT_CONFIG_PATH,
        help=f"Path to producer.yaml (default: {_DEFAULT_CONFIG_PATH}).",
    )
    parser.add_argument("--debug", action="store_true", help="Verbose logging.")
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init", help="Scaffold producer.yaml + agents/ + agent-state/.")
    p_init.add_argument("--dir", default=".", help="Target directory (default: current).")
    p_init.add_argument("--force", action="store_true", help="Overwrite existing files.")
    p_init.add_argument(
        "--non-interactive",
        action="store_true",
        help="Skip prompts; use defaults derived from --dir.",
    )
    p_init.add_argument(
        "--no-chat",
        action="store_true",
        help="Skip the post-scaffold handoff to the `claude` CLI bootstrap chat.",
    )
    p_init.set_defaults(fn=cmd_init)

    p_run = sub.add_parser("run", help="Run the Producer poll loop.")
    p_run.add_argument("--once", action="store_true", help="Single pass, then exit.")
    p_run.set_defaults(fn=cmd_run)

    p_report = sub.add_parser("report", help="Write a morning report and exit.")
    p_report.add_argument(
        "--date", default=None, help="YYYY-MM-DD UTC (default: today)."
    )
    p_report.set_defaults(fn=cmd_report)

    p_task = sub.add_parser("task", help="Inspect or add tasks.")
    task_sub = p_task.add_subparsers(dest="task_command", required=True)

    p_add = task_sub.add_parser("add", help="Insert a pending task.")
    p_add.add_argument("--agent", required=True, help="agent_owner role name.")
    p_add.add_argument("--title", required=True)
    p_add.add_argument("--description", required=True)
    p_add.add_argument("--priority", type=int, default=3)
    p_add.add_argument("--payload", default=None, help="JSON object as a string.")
    p_add.add_argument(
        "--dependencies", default=None, help="Comma-separated task ids."
    )
    p_add.set_defaults(fn=cmd_task_add)

    p_list = task_sub.add_parser("list", help="List tasks (default: pending).")
    p_list.add_argument(
        "--status",
        default="pending",
        choices=("pending", "in_progress", "done", "failed", "escalated", "killed"),
    )
    p_list.set_defaults(fn=cmd_task_list)

    p_kill = sub.add_parser("kill", help="Arm the kill switch.")
    p_kill.add_argument("reason", nargs="?", default=None, help="Optional reason text.")
    p_kill.set_defaults(fn=cmd_kill)

    p_resume = sub.add_parser("resume", help="Disarm the kill switch.")
    p_resume.set_defaults(fn=cmd_resume)

    p_pricing = sub.add_parser("pricing", help="Pricing-table maintenance.")
    pricing_sub = p_pricing.add_subparsers(dest="pricing_command", required=True)

    p_update = pricing_sub.add_parser(
        "update", help="Refresh pricing.json from docs.anthropic.com."
    )
    p_update.add_argument(
        "--dry-run", action="store_true",
        help="Validate and diff, but don't write the file.",
    )
    p_update.set_defaults(fn=cmd_pricing_update)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.debug else logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )
    # Best-effort .env load — silent if missing.
    try:
        load_dotenv()
    except Exception:  # noqa: BLE001
        pass
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
