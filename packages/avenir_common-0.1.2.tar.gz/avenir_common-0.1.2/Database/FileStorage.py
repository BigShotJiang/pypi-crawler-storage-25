from os import environ as env
from bz2 import compress
import gzip
import ujson



def GB_get_db_stream(path, container, file_name):
    return open(env["GB_DefaultDataPath"]+'\\'+container+'\\'+file_name) 

def GB_get_db_bytes(path, container, file_name):
    with open(env["GB_DefaultDataPath"]+'\\'+container+'\\'+file_name, 'rb') as fp:
        return fp.read()   

def GB_get_db_json(path, container, file_name):
    with open(env["GB_DefaultDataPath"]+'\\'+container+'\\'+file_name, 'rb') as fp:
        return ujson.loads(fp.read())  


def GB_get_db_compressed(path, container, file_name):
    jo_bytes = GB_get_db_bytes(path, container, file_name)
    
    #jo_str = jo_bytes.decode('utf8')
    
    json_data = gzip.decompress(jo_bytes)     
    return ujson.loads(json_data) 

# def GB_set_db_json(connection, container, file_name, json_data):
#     blob_client = BlobServiceClient.from_connection_string(connection)
#     container_client = blob_client.get_container_client(container=container)
#     container_client.upload_blob(file_name, json_data, overwrite=True)
#     return None

# def GB_upload_json(connection, container, file_name, json_data, compress=False):
#     blob_client = BlobServiceClient.from_connection_string(connection)
#     container_client = blob_client.get_container_client(container=container)
    
#     if not container_client.exists():
#         container_client.create_container()   
         
#     if compress:
#         json_data = gzip.compress(json_data.encode('utf-8'))     
        
#     container_client.upload_blob(file_name, json_data, overwrite=True), 
#     return None

# def GB_upload_file(connection, container, file_name, FQName):

#     blob_client = BlobServiceClient.from_connection_string(connection)
#     container_client = blob_client.get_container_client(container=container)
    
#     if not container_client.exists():
#         container_client.create_container() 
        
#     with open(FQName) as f:
#         container_client.upload_blob(file_name, f.read(), overwrite=True)
#     return None

# def GB_file_exists(connection, container, file_name):
#     blob_client = BlobClient.from_connection_string(connection, container, file_name)
#     return blob_client.exists()

#     #Danger! Danger!
# def GB_destroy_container(connection, container):
#     blob_client = BlobServiceClient.from_connection_string(connection)
#     container_client = blob_client.get_container_client(container=container)
#     if container_client.exists():
#         container_client.delete_container()
        
# def GB_destroy_file(connection, container, file_name):
#     blob_client = BlobClient.from_connection_string(connection, container, file_name)
#     blob_client.delete_blob()

# def GB_container_exists(connection, container):
#     blob_client = BlobServiceClient.from_connection_string(connection)
#     container_client = blob_client.get_container_client(container=container)
#     return container_client.exists()

# def GB_container_list(connection):
#     blob_client = BlobServiceClient.from_connection_string(connection)
#     return blob_client.list_containers()

# def GB_file_list(connection_str, containerID, search_str):
#     blob_client = BlobServiceClient.from_connection_string(connection_str)
#     container_client = blob_client.get_container_client(container=containerID)
#     file_list = container_client.list_blobs(name_starts_with = None)
#     blobList=[]
#     for blob in file_list:
#         blobList.append(blob.name)
#     return blobList

# def GB_last_modified_list(connection_str, containerID):
#     blob_client = BlobServiceClient.from_connection_string(connection_str)
#     container_client = blob_client.get_container_client(container=containerID)
#     file_list = container_client.list_blobs()
#     blobList=[]
#     for blob in file_list:
#         blobList.append(blob['last_modified'])
#     return blobList
