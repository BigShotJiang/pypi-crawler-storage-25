from os import environ as env

from .BlobStorage import *
if "GB_DefaultDataPath" in env:
    env["GB_SPECT_MOD_DATA_CONN_ENV"] = env["GB_DefaultDataPath"]
    from .FileStorage import *
