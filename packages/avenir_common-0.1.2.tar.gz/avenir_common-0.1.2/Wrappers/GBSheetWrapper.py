import pandas as pd
import os

from io import BytesIO
import pandas._libs.lib as lib

class GBSheet():

    def __init__(self, FQName='', sheet_name=0):
        if (FQName == ''):
            self.sheet = pd.DataFrame()
        else:
            extension = os.path.splitext(FQName)[1].lower()
            if extension == '.csv':
                self.load_from_csv(FQName, sheet_name)
            else:
                self.load_from_xlsx(FQName, sheet_name)
        
    def __call__(self, row=None, col=None, value=None):
        if row is None:
            return self
        
        if col is None:
            return self.sheet.values[row]

        #resize if needed
        start_c = self.sheet.shape[1]
        if col>=start_c:
            max_row = row+1
            if max_row<self.sheet.shape[0]:
                max_row = self.sheet.shape[0]

            row_values = ['']*(max_row)
            for c in range(start_c, col+1):
                col_name = str(c)
                self.sheet[col_name] = row_values.copy()

        start_r = self.sheet.shape[0] 
        if row>=start_r:
            col_values = ['']*(start_c)
            
            for r in range(start_r, row+1):
                self.sheet.loc[r] = col_values.copy()

        #getter
        if value is None:    
            return self.sheet.iat[row, col]

        #setter
        self.sheet.iat[row, col] = value

    def save_to_xlsx(self, FQName='', sheet_name=''):
        if FQName!='':
            self.FQName = FQName

        if sheet_name!='':
            self.sheet_name = sheet_name

        writer = pd.ExcelWriter(FQName, engine = 'xlsxwriter')
        self.sheet.to_excel(writer, self.sheet_name, header=False, index=False)   
        writer.save()
        #writer.close()

    def save_to_csv(self, FQName=''):
        if FQName!='':
            self.FQName = FQName

        self.sheet.to_csv(self.FQName, header=False, index=False)

    def get_csv_buffer(self):
        csv_buffer = BytesIO()
        self.sheet.to_csv(csv_buffer, header = None, index = False, encoding = "UTF-8")
        csv_buffer.seek(0)

        return csv_buffer

    #careful, loading a new sheet will delete current data in sheet
    def load_from_xlsx(self, FQName, sheet_name=0):
        self.FQName = FQName
        self.sheet_name = sheet_name
        self.sheet = pd.read_excel(FQName,  sheet_name=sheet_name, header=None, na_filter=False)

    def load_from_csv(self, FQName, sheet_name=0):
        self.FQName = FQName
        self.sheet_name = sheet_name
        self.sheet = pd.read_csv(FQName, header=None, na_filter=False)

    def load_from_csv(self, file, FQName = '', sheet_name = 0, names = lib.no_default):
        self.FQName = FQName
        self.sheet_name = sheet_name
        self.sheet = pd.read_csv(file, header=None, na_filter=False, names=names)

    def clear_sheet(self, row_count, col_count, init=''):
        init_row = [init]*row_count
        for col in range(col_count):
            col_name = str(col)
            self.sheet[col_name] = init_row.copy()

    def isEmpty(self):
        return ((self.sheet.shape[0] == 0) and (self.sheet.shape[1] == 0))
    
    def getRowCount(self):
        return self.sheet.shape[0]

    def getColCount(self):
        return self.sheet.shape[1]

    
