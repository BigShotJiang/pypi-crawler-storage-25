# avenir-common

Shared utility, auth, database, logging, and wrapper modules for Spectrum Engine.

## Install

```bash
pip install avenir-common
```

## Notes

This package publishes the `AvenirCommon` namespace and its subpackages.
