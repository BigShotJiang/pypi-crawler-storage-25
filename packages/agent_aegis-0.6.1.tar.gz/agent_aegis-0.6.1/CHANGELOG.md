# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.4.2] — 2026-03-25

### Added

- **Auto-Instrumentation** (`aegis.auto_instrument()`) — zero-code monkey-patching that adds governance to any installed AI framework at runtime
  - **LangChain** — patches `BaseChatModel.invoke/ainvoke`, `BaseTool.invoke/ainvoke`
  - **CrewAI** — patches `Crew.kickoff/kickoff_async`, registers global `BeforeToolCallHook`
  - **OpenAI Agents SDK** — patches `Runner.run`, `Runner.run_sync`
  - **OpenAI API** — patches `Completions.create` via existing `patch_openai`
  - **Anthropic API** — patches `Messages.create` via existing `patch_anthropic`
- **`AEGIS_INSTRUMENT=1` environment variable** — activate auto-instrumentation with zero code changes
- **Default guardrail engine** — built-in guardrails (injection block, toxicity block, PII warn, prompt leak warn) that require no configuration
- **Per-framework patching** — `patch_langchain()`, `patch_crewai()`, `patch_openai_agents()` for selective instrumentation
- **Instrumentation status API** — `status()` returns current patch state, `reset()` cleanly unpatches everything
- **`InstrumentationReport`** — structured summary of what was patched, skipped, or errored

## [0.4.1] — 2026-03-24

### Changed

- **Policy cache: FIFO → LRU** — `OrderedDict` with `move_to_end()` for O(1) LRU eviction, improving cache hit rates for frequently-evaluated actions
- **Policy cache correctness** — `_is_cacheable()` now checks all conditional rules' patterns against the action, preventing unconditional cache entries from shadowing conditional rules with different params
- **Rate limiter: pre-compiled glob patterns** — module-level `_glob_to_re()` cache eliminates redundant `fnmatch` compilation on every `matches()` call
- **O(n) → O(log n) timestamp pruning** — `bisect.bisect_left/right` replaces list comprehension in rate limiter and anomaly detector hot paths
- **SQLite WAL mode** — `PRAGMA journal_mode=WAL` for concurrent read/write performance
- **SQLite indexes** — 4 indexes on `session_id`, `timestamp`, `agent_id`, `action_type` for query performance
- **Lock memory leak fix** — `reset(agent_id)` now cleans up stale `_locks` entries in rate limiter and anomaly detector
- **Batch audit flush race fix** — buffer swap moved inside lock to prevent double-flush when concurrent threads both see `should_flush=True`
- **Anomaly detection: time-bounded rate calculation** — `_compute_rate_per_minute(window=60.0)` uses fixed window instead of last-N-events span for statistically accurate rate spike detection

### Added

- **`AnomalyDetector.check_all()`** — returns all detected anomalies at once (rate spike + high block rate simultaneously); `check()` now returns the most severe
- **`GuardrailEngine.acheck()` / `acheck_and_transform()`** — async wrappers via `run_in_executor` so guardrails don't block the event loop
- **`Runtime.execute(parallel=True)`** — concurrent action execution via `asyncio.gather()` for independent actions

## [0.4.0] — 2026-03-24

### Added

- **`aegis.init()` unified entry point** — single function call activates all governance (guardrails, policy, audit, cost tracking, auto-patching)
- **Runtime Guardrails Engine** — pluggable guardrail pipeline with block/mask/warn/log actions
- **PII Detection & Masking** — 12 categories (email, credit card, SSN, Korean RRN, phone numbers, API keys, IP addresses, passport, URL credentials)
- **Prompt Injection Detection** — 10 attack categories, 85+ compiled patterns, multi-language support (Korean, Chinese, Japanese)
- **Rule Pack Ecosystem** — YAML-based community-extensible rule packs with built-in @aegis/pii-detection and @aegis/prompt-injection
- **Zero-Code Integration** — `aegis.patch_openai()`, `aegis.patch_anthropic()` monkey-patching and `@guard` decorator
- **AGEF v1** (Agent Governance Event Format) — JSON Schema standard for AI governance events
- **AGP v1** (Agent Governance Protocol) — protocol specification complementing MCP for AI governance
- **Unified YAML configuration** — `aegis.yaml` single config file for all features
- **Redis audit backend** — production audit logging via Redis
- **PostgreSQL audit backend** — production audit logging via asyncpg
- **Redis rate limiter** — distributed rate limiting via Redis

## [0.3.0] - 2026-03-24

### Added

- **MCP supply chain security**: Tool poisoning detection (10 patterns), rug-pull detection (SHA-256 manifest pinning), argument sanitization, trust scoring (L0-L4)
- **MCP SBOM generation**: Software Bill of Materials for MCP tool inventories
- **MCP vulnerability database**: Known-vulnerability lookup for MCP tools
- **Cost circuit breaker**: 17-model price table, loop detection, hierarchical budgets, thread-safe enforcement
- **Cross-framework cost tracking**: Unified CostTracker across LangChain, OpenAI, Anthropic, and Google
- **Multi-agent cost attribution**: Delegation tree tracking, subtree cost rollup, attribution reports
- **A2A communication governance**: Capability-based messaging, PII/credential auto-scrubbing, rate limiting, audit logging
- **Session replay & retroactive scan**: Replay historical sessions against new policies for what-if analysis
- **OpenTelemetry export**: Policy, cost, anomaly, and MCP events exported as OTel spans with in-memory fallback
- **Policy git integration**: Git-like versioning with commit, diff, rollback semantics

### Changed

- Development status upgraded from Alpha to Beta
- PyPI keywords expanded with MCP, cost-management, supply-chain-security, A2A, observability

### Stats

- 2,238+ tests passing
- 92% code coverage

## [0.2.0] - 2026-03-23

### Added

- **Web governance dashboard**: Real-time SPA dashboard with 7 pages (overview, audit, policy, anomalies, compliance, regulatory, system)
- **WebSocket real-time streaming**: `/ws/audit` endpoint streams audit entries live to connected dashboard clients
- **Interactive playground**: Browser-only policy playground at `/playground/` — no install, no backend, YAML + glob matching in JS
- **Policy editor**: In-dashboard YAML editor with validate and save/reload (hot-reload via PUT `/api/v1/policy`)
- **Shields.io badge endpoint**: `GET /api/v1/badge/score` returns governance score badge for README embedding
- **Policy YAML export**: `GET /api/v1/dashboard/policy/yaml` exports current policy as YAML
- **Audit JSON export**: Dashboard audit page has one-click JSON export with current filters
- **CLI `--seed-demo N`**: `aegis serve policy.yaml --seed-demo 200` populates demo audit data before starting
- **Auto-refresh dashboard**: Overview page auto-refreshes every 30s (toggleable)
- **AuditLogger pub/sub**: `subscribe()`/`unsubscribe()` callbacks for real-time entry notifications
- **Cryptographic audit chain**: SHA-256/SHA3-256 hash-linked, tamper-evident logging with `aegis audit --verify`, `--export-chain`, `--verify-chain`, and `--evidence` CLI commands
- **Regulatory compliance mapper**: EU AI Act (10 requirements), NIST AI RMF (8 requirements), SOC2 (6 requirements), and ISO 42001 mapping with automated gap analysis
- **Behavioral anomaly detection**: rate spike detection, burst analysis, new-action flagging, unusual target identification, and automatic policy generation from anomalies
- **Compliance report generator**: SOC2, GDPR, and governance reports generated directly from audit logs
- **Policy diff & impact analysis**: `aegis diff old.yaml new.yaml --replay actions.jsonl` for what-if comparison between policy versions
- **Fluent PolicyBuilder SDK**: programmatic policy definition with a chainable Python API
- **Rate limiter engine**: per-agent and global sliding-window rate limiting
- **Action replay & simulation engine**: replay historical actions against new policies for what-if analysis
- **Real-time agent monitoring dashboard**: `aegis monitor` CLI command for live operational visibility
- **Webhook notification system**: Slack, PagerDuty, and generic JSON webhook integrations for governance events
- **Enterprise tier system**: Community / Pro / Enterprise feature gating
- **GitHub Action for CI/CD governance gates**: enforce policies in pull request and deployment pipelines
- **Semantic conditions engine**: keyword matching and pluggable LLM evaluator for content-aware policy rules
- **Agent trust chain**: hierarchical identity model with delegation tokens and cascade revocation
- **Multi-tenant isolation**: TenantContext, TenantRegistry, quota enforcement via contextvars
- **RBAC**: 12 granular permissions, 5 hierarchical roles, thread-safe AccessController
- **Policy testing framework**: automated rule testing, regression detection, auto-generation
- **Policy versioning**: git-like commit, diff, rollback, tagging with JSON persistence
- **Natural language autopolicy**: `aegis autopolicy` generates YAML from natural language descriptions
- **Adversarial probe**: `aegis probe` tests policies for glob bypass, missing coverage, escalation paths

### Stats

- 1,776+ tests passing
- 27 core modules, 65 source files
- EU AI Act compliance: 10 requirements mapped
- NIST AI RMF: 8 requirements mapped
- SOC2: 6 requirements mapped

## [0.1.6] - 2026-03-23

### Added

- Standalone MCP server: `pip install 'agent-aegis[mcp]'` → `aegis-mcp-server`
- `langchain-aegis` 0.1.0: standalone PyPI package for LangChain governance integration
- MCP Registry publication (`io.github.Acacian/aegis`)
- Smithery.ai configuration (`smithery.yaml`)
- GEO (Generative Engine Optimization) for AI discoverability
- CI gate: service worker cache version bump check
- PyPI downloads badge in README

### Fixed

- MCP Registry name casing (`io.github.Acacian/aegis`)
- MCP server format and mypy strict compliance

## [0.1.4] - 2026-03-22

### Added

- Interactive playground with 14 presets for browser-based policy testing
- 10 industry-specific policy templates (healthcare, finance, legal, etc.)
- 7 framework integration cookbooks
- Docker deployment support
- GitHub Action for CI/CD policy enforcement
- 12+ example scripts covering common governance scenarios
- Production deployment guide
- Policy patterns guide
- Performance optimizations: compiled glob matching, batch audit writes, evaluation cache
- Security hardening: pinned all GitHub Actions to SHA hashes, security model guide

### Changed

- Expanded README with policy templates and compliance section

### Fixed

- Lint issues from multi-agent commit
- `mcp_demo` f-string formatting

## [0.1.3] - 2026-03-21

### Added

- MCP (Model Context Protocol) adapter
- Multi-agent orchestration foundations
- 518 tests with 92% code coverage

## [0.1.2] - 2026-03-20

### Added

- Core policy engine with YAML-based rule parsing
- Risk evaluation pipeline
- LangChain adapter
- CrewAI adapter
- OpenAI Agents adapter
- Audit logging system
- Approval handler framework

## [0.1.1] - 2026-03-19

### Added

- Initial public release on PyPI

[Unreleased]: https://github.com/Acacian/aegis/compare/v0.4.1...HEAD
[0.4.1]: https://github.com/Acacian/aegis/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/Acacian/aegis/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/Acacian/aegis/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/Acacian/aegis/compare/v0.1.6...v0.2.0
[0.1.6]: https://github.com/Acacian/aegis/compare/v0.1.4...v0.1.6
[0.1.4]: https://github.com/Acacian/aegis/compare/v0.1.3...v0.1.4
[0.1.3]: https://github.com/Acacian/aegis/compare/v0.1.2...v0.1.3
[0.1.2]: https://github.com/Acacian/aegis/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/Acacian/aegis/releases/tag/v0.1.1
