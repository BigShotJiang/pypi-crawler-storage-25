"""Per-meeting sidecar + workspace-level orphan storage for action items.

Pure sync I/O. Safe under asyncio's cooperative model as long as callers do
NOT `await` between a `load()` and a `save()` of the same file. There is no
yield point inside a single read or write, so concurrent gather()ed tasks
each see a consistent snapshot. If a caller awaits between read and write,
a lost-write is possible: hold the data in a local variable and complete
the load/mutate/save cycle without awaiting in between.
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from time import time
from typing import Any

logger = logging.getLogger(__name__)


def _sidecar_path(recordings_dir: Path, meeting_id: str) -> Path:
    return recordings_dir / f"{meeting_id}.action_items.json"


def _orphan_path(workspace_json_path: Path) -> Path:
    """Sibling file next to <name>.json: <name>.action_items.json."""
    return workspace_json_path.with_suffix(".action_items.json")


class StoreCorruptError(RuntimeError):
    """Raised when an action_items file is unreadable (malformed JSON or
    wrong shape). The bad file is renamed to ``*.broken-<epoch>`` before
    this raises, so the next call returns an empty list cleanly.

    Routes turn this into a 500 with code=corrupt so the UI can surface
    the failure as a toast instead of silently presenting an empty list.
    """

    def __init__(self, path: Path, backup: Path | None, original: Exception):
        self.path = path
        self.backup = backup
        self.original = original
        msg = f"action_items file corrupt at {path}"
        if backup is not None:
            msg += f"; renamed to {backup}"
        msg += f": {original}"
        super().__init__(msg)


def _read(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text("utf-8"))
        items = data.get("items", [])
        if not isinstance(items, list):
            raise ValueError("items must be a list")
        return items
    except (json.JSONDecodeError, ValueError) as exc:
        backup = path.with_suffix(path.suffix + f".broken-{int(time())}")
        try:
            path.rename(backup)
        except OSError:
            backup = None
        logger.warning(
            "action_items file corrupt at %s: %s; renamed to %s",
            path,
            exc,
            backup,
        )
        raise StoreCorruptError(path, backup, exc) from exc


def _write(path: Path, items: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps({"items": items}, indent=2), "utf-8")
    os.replace(tmp, path)


def load(recordings_dir: Path, meeting_id: str) -> list[dict[str, Any]]:
    return _read(_sidecar_path(recordings_dir, meeting_id))


def save(recordings_dir: Path, meeting_id: str, items: list[dict[str, Any]]) -> None:
    _write(_sidecar_path(recordings_dir, meeting_id), items)


def load_orphans(workspace_json_path: Path) -> list[dict[str, Any]]:
    return _read(_orphan_path(workspace_json_path))


def save_orphans(workspace_json_path: Path, items: list[dict[str, Any]]) -> None:
    _write(_orphan_path(workspace_json_path), items)


def list_all(
    workspace_json_path: Path, recordings_dir: Path
) -> list[dict[str, Any]]:
    """Return every item across sidecars + orphans.

    Sort order: newer meeting_id first, then within each group newer
    created_at first, then orphans appended at the end.
    """
    merged: list[tuple[str, str, dict[str, Any]]] = []

    if recordings_dir.exists():
        for path in recordings_dir.glob("*.action_items.json"):
            meeting_id = path.name.removesuffix(".action_items.json")
            for item in _read(path):
                item.setdefault("meeting_id", meeting_id)
                merged.append((meeting_id, item.get("created_at", ""), item))

    orphan_items = _read(_orphan_path(workspace_json_path))
    for item in orphan_items:
        item["meeting_id"] = None

    merged.sort(key=lambda t: (t[0], t[2].get("created_at", "")), reverse=True)
    return [item for _, _, item in merged] + orphan_items
