"""Library tools - wrap existing library handlers as agent tools."""
from __future__ import annotations

import asyncio
from typing import Any
from urllib.parse import quote

from meeting_helper.chat.registry import Tool


def _deeplink(item: dict[str, Any]) -> str | None:
    """Build the in-app deeplink path the chat UI's link interceptor can follow."""
    iid = item.get("id")
    kind = item.get("kind")
    if not iid or kind not in ("meeting", "note"):
        return None
    return f"/library/?id={quote(str(iid))}&kind={kind}"


def _with_url(item: dict[str, Any]) -> dict[str, Any]:
    link = _deeplink(item)
    if link is None:
        return item
    return {**item, "url": link}


async def _load_library_items() -> dict[str, Any]:
    """Reuse the same logic as GET /library, in-process."""
    from meeting_helper.server.routes import _list_library_items
    return await asyncio.to_thread(_list_library_items)


async def _fetch_meeting_bundle(meeting_id: str) -> dict[str, Any]:
    from meeting_helper.server.routes import _fetch_library_bundle
    return await asyncio.to_thread(_fetch_library_bundle, meeting_id)


async def _fetch_kb_entry(kb_id: str) -> dict[str, Any]:
    from meeting_helper.server.routes import _fetch_library_kb_entry
    return await asyncio.to_thread(_fetch_library_kb_entry, kb_id)


async def _search_meetings(args, ctx):
    q = (args.get("q") or "").strip().lower()
    date_from = args.get("date_from")
    date_to = args.get("date_to")
    res = await _load_library_items()
    items = res.get("items", [])

    matches: list[dict] = []
    for it in items:
        d = it.get("date") or ""
        if date_from and d < date_from:
            continue
        if date_to and d > date_to:
            continue
        if not q:
            matches.append(it)
            continue
        title = (it.get("title") or "").lower()
        if q in title:
            matches.append(it)
            continue
        # Title miss -> peek at the summary file (cheap, bounded).
        summary_filename = it.get("summary_filename") or ""
        note_filename = it.get("note_filename") or ""
        peek_filename = summary_filename or note_filename
        if peek_filename:
            try:
                from meeting_helper import config as _config_mod
                peek_path = (
                    _config_mod.get_config().recordings_dir / peek_filename
                )
                if peek_path.is_file():
                    body = peek_path.read_text(errors="ignore")[:2000].lower()
                    if q in body:
                        matches.append(it)
            except Exception:
                pass

    return {"status": "ok", "result": {"matches": [_with_url(m) for m in matches[:50]]}}


async def _list_recent(args, ctx):
    limit = int(args.get("limit", 20))
    res = await _load_library_items()
    items = res.get("items", [])
    # Already sorted newest-first by list_artifacts. Cap and return.
    return {"status": "ok", "result": {"meetings": [_with_url(it) for it in items[:limit]]}}


async def _get_meeting(args, ctx):
    mid = args.get("meeting_id")
    if not mid:
        return {"status": "error", "error": "meeting_id is required"}
    bundle = await _fetch_meeting_bundle(mid)
    if isinstance(bundle, dict):
        link = f"/library/?id={quote(str(mid))}&kind=meeting"
        bundle = {**bundle, "url": link}
    return {"status": "ok", "result": bundle}


async def _fetch_kb(args, ctx):
    kb_id = args.get("kb_id")
    if not kb_id:
        return {"status": "error", "error": "kb_id is required"}
    entry = await _fetch_kb_entry(kb_id)
    return {"status": "ok", "result": entry}


async def _get_note(args, ctx):
    note_id = args.get("note_id")
    if not note_id:
        return {"status": "error", "error": "note_id is required"}
    # note_id is the .note.md filename (matches the `id` of kind="note" rows in
    # library.search_meetings / library.list_recent).
    from pathlib import Path
    from meeting_helper.config import get_config
    note_filename = str(note_id)
    if not note_filename.endswith(".note.md"):
        note_filename = note_filename + ".note.md"
    # Reject anything that looks like a path traversal.
    if "/" in note_filename or "\\" in note_filename or ".." in note_filename:
        return {"status": "error", "error": "note_id must be a basename"}
    try:
        rec_dir = get_config().recordings_dir
        path = Path(rec_dir) / note_filename
        if not path.is_file():
            return {"status": "error", "error": f"note not found: {note_filename}"}
        body = path.read_text(errors="ignore")
    except Exception as exc:
        return {"status": "error", "error": str(exc)[:200]}
    link = f"/library/?id={quote(note_filename)}&kind=note"
    return {"status": "ok", "result": {"id": note_filename, "body": body, "url": link}}


def build_library_search_meetings() -> Tool:
    return Tool(
        name="library.search_meetings",
        description=(
            "Search past meetings by keyword (matches title; falls back to summary content). "
            "Optional date range filters (ISO date strings). Leave `q` empty to get all "
            "meetings (use library.list_recent for that intent instead — it's more direct). "
            "Returns meeting summaries; use library.get_meeting to fetch full content."
        ),
        input_schema={"q": "string?", "date_from": "string?", "date_to": "string?"},
        run=_search_meetings,
    )


def build_library_list_recent() -> Tool:
    return Tool(
        name="library.list_recent",
        description=(
            "List the N most recent past meetings (newest first). Use this when "
            "the user asks about the 'last', 'most recent', 'previous', or 'today's' "
            "meeting without giving a specific title or date. Returns meeting "
            "objects with id, title, date, and flags (has_transcript, has_summary). "
            "Use library.get_meeting to fetch the full content of any specific one."
        ),
        input_schema={"limit": "integer?"},
        run=_list_recent,
    )


def build_library_get_meeting() -> Tool:
    return Tool(
        name="library.get_meeting",
        description="Fetch the transcript, summary, and KB notes for a past meeting.",
        input_schema={"meeting_id": "string"},
        run=_get_meeting,
    )


def build_library_fetch_kb() -> Tool:
    return Tool(
        name="library.fetch_kb",
        description="Fetch a single KB entry by id.",
        input_schema={"kb_id": "string"},
        run=_fetch_kb,
    )


def build_library_get_note() -> Tool:
    return Tool(
        name="library.get_note",
        description=(
            "Fetch the full body of a standalone Note (a .note.md file in the user's "
            "Library). Use this when `library.search_meetings` / `library.list_recent` "
            "returns a row with `kind: 'note'` — the row only has the title; this tool "
            "returns the actual content."
        ),
        input_schema={"note_id": "string"},
        run=_get_note,
    )
