"""Pywebview window factory for the shell process.

Single-window app. The window points at the daemon's local server. Dev mode
(`MH_SHELL_DEV=1`) can point it at a Next.js dev server on :3000 instead;
that branch lives in __main__.py, not here.

The window also exposes a small JS API (`window.pywebview.api.*`) so the
web UI can ask the shell to spawn a fresh daemon when one isn't running —
otherwise a user with a disconnected daemon would have no way back into
the app from inside the GUI itself.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


class ShellAPI:
    """Methods exposed to the web UI via ``window.pywebview.api.<name>()``.

    Stays tiny on purpose: the shell shouldn't grow a parallel control
    plane. The only thing the UI fundamentally cannot do via the daemon's
    HTTP API is start the daemon when it isn't running. Everything else
    flows through the daemon.
    """

    def open_url(self, url: str) -> dict:
        """Open ``url`` in the user's default browser.

        The web UI calls this for external (different-origin) link clicks
        once we've disabled pywebview's default ``target="_blank"`` →
        ``webbrowser.open`` shortcut. Disabling that shortcut is what keeps
        in-app links from getting hijacked to the OS browser, but it also
        means we have to send legitimate external URLs there ourselves.

        Only http(s) URLs are honored — never let the renderer hand us a
        ``file://`` or local-protocol URL that could be abused.
        """
        import webbrowser

        try:
            normalized = (url or "").strip()
            if not normalized.lower().startswith(("http://", "https://")):
                return {"ok": False, "error": "only http(s) URLs are allowed"}
            webbrowser.open(normalized, new=2)
            return {"ok": True}
        except Exception as exc:  # noqa: BLE001 — caller surfaces this
            logger.warning("ShellAPI.open_url failed: %s", exc)
            return {"ok": False, "error": str(exc)}

    def spawn_daemon(self) -> dict:
        """Spawn a detached `meeting-helper start` subprocess.

        Returns ``{"ok": true}`` on success, ``{"ok": false, "error": ...}``
        on failure. The caller (UI) should then poll ``/health`` until the
        daemon answers.

        We briefly wait for the child to either daemonize (parent exits
        cleanly with code 0 after a successful double-fork) or crash
        (non-zero exit). If it crashed, we read the tail of the spawn log
        so the UI can show a real error toast instead of a 30s silent
        timeout.
        """
        import time
        from meeting_helper.shell.spawn import read_spawn_log_tail, spawn_daemon

        try:
            proc = spawn_daemon()
        except Exception as exc:  # noqa: BLE001 — caller handles
            logger.warning("ShellAPI.spawn_daemon failed: %s", exc)
            return {"ok": False, "error": str(exc)}

        # The daemon double-forks: the parent we spawned exits with code 0
        # within ~1s. A non-zero exit (or a still-alive parent after 2s)
        # means something went wrong — surface the spawn log to the UI.
        deadline = time.monotonic() + 2.0
        while time.monotonic() < deadline:
            rc = proc.poll()
            if rc is None:
                time.sleep(0.1)
                continue
            if rc == 0:
                return {"ok": True}
            tail = read_spawn_log_tail().strip()
            logger.warning("ShellAPI.spawn_daemon: child exited rc=%d, tail=%r", rc, tail)
            return {
                "ok": False,
                "error": tail or f"Daemon process exited with code {rc} before binding the port.",
            }
        # Still running after 2s — assume the double-fork is in flight.
        # The UI's health-poll handles the remaining wait.
        return {"ok": True}


WINDOW_TITLE = "Meeting Helper"
# Match the old Flet GUI default so existing users get the same canvas size
# they're used to. Below 900x600 the toolbar starts wrapping awkwardly, so
# that's the floor we enforce as the minimum resizable size.
DEFAULT_SIZE = (1200, 800)
MIN_SIZE = (900, 600)


def _center_position(width: int, height: int) -> tuple[int, int] | None:
    """Return top-left (x, y) that centers a `width x height` window on the
    main screen, or None when AppKit isn't usable.

    pywebview happily accepts None-equivalent (no x/y) and falls back to its
    own positioning, so we keep this best-effort: any failure on the AppKit
    path just means we don't center, not that startup fails.
    """
    try:
        from AppKit import NSScreen  # type: ignore
        screen = NSScreen.mainScreen()
        if screen is None:
            return None
        frame = screen.frame()
        sw = int(frame.size.width)
        sh = int(frame.size.height)
        return ((sw - width) // 2, (sh - height) // 2)
    except Exception:
        return None


def create_window(url: str) -> "webview.Window":
    """Construct the main app window. Import is local so tests can stub it."""
    import webview

    width, height = DEFAULT_SIZE
    logger.info("Opening shell window at %s", url)
    kwargs: dict[str, object] = {
        "url": url,
        "width": width,
        "height": height,
        "min_size": MIN_SIZE,
        "resizable": True,
        # text_select=True lets the user copy/select transcript text in the
        # WebView.
        "text_select": True,
        # Expose the shell API on window.pywebview.api in the page.
        "js_api": ShellAPI(),
    }
    pos = _center_position(width, height)
    if pos is not None:
        kwargs["x"], kwargs["y"] = pos
    return webview.create_window(WINDOW_TITLE, **kwargs)
