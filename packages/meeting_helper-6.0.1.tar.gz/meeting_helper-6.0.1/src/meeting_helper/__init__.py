"""Meeting Helper — AI meeting assistant for macOS."""

__version__ = "6.0.1"
