"""In-memory `disk` shim for tests — avoids touching the user's workspace JSON.

Mirrors the subset of `Config` that the tracker route handlers use:
trackers list/setter, active_tracker_id getter/setter, workspace_name, save().
Reads its initial state from the `AppConfig` and never persists.
"""
from __future__ import annotations


class InMemoryDiskShim:
    def __init__(self, app_config) -> None:
        self._trackers = list(getattr(app_config, "trackers", []) or [])
        self._active = getattr(app_config, "active_tracker_id", None)
        self._workspace = getattr(app_config, "workspace_name", "") or "test"
        # Tests sometimes need a workspace JSON path (e.g. for the
        # action-items orphan file). Point it at /tmp so reads return empty
        # and writes are harmless in tests; production never uses the shim.
        from pathlib import Path
        self.config_path = Path("/tmp") / f"_shim_{self._workspace}.json"

    @property
    def trackers(self) -> list[dict]:
        return list(self._trackers)

    @trackers.setter
    def trackers(self, value: list[dict]) -> None:
        self._trackers = list(value)

    @property
    def active_tracker_id(self) -> str | None:
        return self._active

    @active_tracker_id.setter
    def active_tracker_id(self, value: str | None) -> None:
        self._active = value or None

    @property
    def workspace_name(self) -> str:
        return self._workspace

    def save(self) -> None:
        # Intentional no-op for tests.
        return None
