"""WebSocket endpoint and broadcast helper."""

from __future__ import annotations

import asyncio
import json
import logging

from aiohttp import web, WSMsgType

from meeting_helper.state import state

logger = logging.getLogger(__name__)

# Per-client send timeout. A slow / stalled GUI client (network paused,
# laptop suspended, full TCP receive buffer) used to block ws.send_str
# indefinitely and stall transcripts for every other connected client.
# Anything past 2s on a localhost socket is broken; cut the cord and
# reconnect later.
_SEND_TIMEOUT_SEC = 2.0


async def ws_handler(request: web.Request) -> web.WebSocketResponse:
    ws = web.WebSocketResponse()
    await ws.prepare(request)

    state.ws_clients.add(ws)
    logger.info("Client connected (total=%d)", len(state.ws_clients))

    # Send current status
    await ws.send_str(json.dumps({"type": "status", "value": state.status}))

    # Send info bar state. Carries the daemon's idea of "is the workspace ready
    # to use feature X" so dependent UIs can hide controls accordingly.
    await ws.send_str(json.dumps(_build_info_message(request.app.get("config"))))

    # Send current meeting info if active
    if state.meeting_info:
        info = state.meeting_info
        await ws.send_str(json.dumps({
            "type": "meeting_status",
            "active": True,
            "app": getattr(info, "app_name", ""),
            "meeting_name": getattr(info, "meeting_name", "") or "",
        }))

    # Send last response for late-joining clients
    if state.last_response:
        await ws.send_str(json.dumps({"type": "done", "full_text": state.last_response}))

    # NOTE: We deliberately do NOT replay state.last_brief on reconnect.
    # An earlier attempt to replay it caused a 30-second flap loop: the GUI
    # disconnected mid-broadcast when the brief's large topic+cards payload
    # arrived, the reconnect handler then re-sent the brief, the GUI died
    # again on it, repeat for 30s. Streaming AI chunks broadcast during that
    # window were silently lost. Live broadcast is sufficient now that stale
    # GUI processes are cleaned up at startup (see flet_gui/app.py).

    # Send current session tasks snapshot
    await ws.send_str(json.dumps({
        "type": "tasks",
        "tasks": list(state.session_tasks),
    }))

    # Send initial action-items snapshot so the Copilot panel populates the
    # moment the client connects, instead of waiting for the next mutation.
    # Gated on action_items_inject_into_copilot — when the toggle is off the
    # panel doesn't render the payload anyway, and a stale push could confuse
    # late-arriving clients about whether the feature is active.
    try:
        cfg = request.app.get("config")
        if cfg is not None and getattr(
            cfg, "action_items_inject_into_copilot", True
        ):
            from pathlib import Path as _Path
            from meeting_helper.action_items import store as _ai_store
            from meeting_helper.trackers.shim import InMemoryDiskShim

            factory = request.app.get("disk_factory")
            disk = None
            if factory is not None:
                try:
                    disk = factory()
                except Exception:
                    logger.warning(
                        "disk_factory failed in initial WS action_items snapshot;"
                        " falling back to InMemoryDiskShim",
                        exc_info=True,
                    )
                    disk = None
            if disk is None:
                disk = InMemoryDiskShim(cfg)
            recordings = _Path(getattr(cfg, "recordings_dir", "") or ".")
            ws_json = _Path(getattr(disk, "config_path", ""))
            if ws_json != _Path(""):
                items = _ai_store.list_all(ws_json, recordings)
                open_items = [i for i in items if not i.get("completed")]
                await ws.send_str(json.dumps({
                    "type": "action_items_context",
                    "open_items": open_items,
                }))
    except Exception:
        logger.warning(
            "initial action_items_context push failed", exc_info=True,
        )

    # Send currently attached past conversation, if any
    if state.attached_conversation:
        ac = state.attached_conversation
        await ws.send_str(json.dumps({
            "type": "conversation_attached",
            "session_id": ac.get("session_id"),
            "title": ac.get("title"),
            "repo": ac.get("repo"),
            "chars": ac.get("chars", 0),
            "truncated": ac.get("truncated", False),
            "turn_count": ac.get("turn_count", 0),
        }))

    try:
        async for msg in ws:
            if msg.type in (WSMsgType.CLOSE, WSMsgType.ERROR):
                break
    finally:
        state.ws_clients.discard(ws)
        logger.info("Client disconnected (total=%d)", len(state.ws_clients))

    return ws


# Fields rendered by the GUI conversation-card view + overlay card view.
# Used to slim local-todo records before broadcasting them over the WebSocket.
# Full task records carry body_md, history (full event log), comments,
# mr_links, thread_links, search_tsv, custom_fields — easily 10-50 KB per
# record. ~10 cards in a single frame can exceed the GUI's `websockets` client
# default max-message-size and disconnect it mid-broadcast.
_BROADCAST_CARD_FIELDS = (
    "id", "title", "status", "sprint", "sprint_name", "due", "url",
    "kind", "board_id", "board_name",
)


def slim_card_for_broadcast(card: dict) -> dict:
    """Return a copy of *card* with only the fields the UIs render."""
    return {k: card[k] for k in _BROADCAST_CARD_FIELDS if k in card}


def build_status_payload() -> dict:
    """Return tracker readiness flags for the WebSocket info payload.

    ``tracker_active`` is the canonical field; ``local_todo_configured`` is a
    deprecated alias kept for one release so older GUI builds keep working.
    """
    tracker_active = state.tracker is not None
    return {
        "tracker_active": tracker_active,
        "local_todo_configured": tracker_active,  # deprecated alias
    }


def _build_info_message(config=None) -> dict:
    """Compose the `info` payload, including readiness flags when config is reachable.

    `config` is optional because some legacy callers don't have one in scope;
    we fall back to `get_config()` so the flags are still populated.
    """
    try:
        if config is None:
            from meeting_helper.config import get_config
            config = get_config()
    except Exception:
        config = None
    msg: dict = {
        "type": "info",
        "transcriber": state.transcriber_name,
        "provider": state.ai_provider,
        "model": state.ai_model,
    }
    # Merge tracker readiness flags (tracker_active + deprecated alias).
    msg.update(build_status_payload())
    if config is not None:
        try:
            msg["provider_configured"] = config.provider_configured
        except Exception:
            pass
    return msg


async def broadcast_info() -> None:
    """Broadcast current info bar state to all clients."""
    await broadcast(_build_info_message())


async def broadcast(message: dict) -> None:
    """Send a JSON message to all connected WebSocket clients.

    Sends are awaited concurrently via asyncio.gather so one slow client
    can't compound the per-client 2 s timeout into 2·N seconds when there
    are N stalled clients (e.g. multiple suspended laptops + an active
    user). Each send wraps in its own wait_for; results map back to clients
    by index so we can mark only the failures dead.
    """
    if not state.ws_clients:
        return

    data = json.dumps(message)
    clients = list(state.ws_clients)

    async def _send_one(ws):
        try:
            await asyncio.wait_for(ws.send_str(data), timeout=_SEND_TIMEOUT_SEC)
            return None
        except asyncio.TimeoutError:
            return ("timeout", None)
        except Exception as exc:
            return ("error", exc)

    results = await asyncio.gather(
        *(_send_one(ws) for ws in clients),
        return_exceptions=True,
    )

    msg_type = message.get("type")
    dead = []
    for ws, result in zip(clients, results):
        if result is None:
            continue
        # gather with return_exceptions=True can hand back BaseException
        # too — guard against that even though _send_one catches Exception.
        if isinstance(result, BaseException):
            logger.warning(
                "ws send raised unexpectedly (client=%s, msg type=%s): %s — dropping",
                id(ws), msg_type, result,
            )
            dead.append(ws)
            continue
        kind, exc = result
        if kind == "timeout":
            logger.warning(
                "ws send timed out after %.1fs (client=%s, msg type=%s) — dropping",
                _SEND_TIMEOUT_SEC, id(ws), msg_type,
            )
        else:
            logger.warning(
                "ws send failed (client=%s, msg type=%s): %s — dropping",
                id(ws), msg_type, exc,
            )
        dead.append(ws)

    # Drop dead clients one-by-one rather than via set subtraction, which
    # races with concurrent ws_handler add()/discard() calls and can
    # accidentally re-add a recently-disconnected client.
    for ws in dead:
        state.ws_clients.discard(ws)
