import asyncio
import atexit
import json
import os
import re
import shlex
from pathlib import Path, PurePosixPath

from tensorlake.sandbox import Sandbox, SandboxClient
from tensorlake.sandbox.exceptions import RemoteAPIError, SandboxConnectionError
from tensorlake.sandbox.models import (
    CommandResult,
    OutputMode,
    ProcessStatus,
    StdinMode,
)
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from harbor.environments.base import BaseEnvironment, ExecResult
from harbor.environments.capabilities import EnvironmentCapabilities
from harbor.models.environment_type import EnvironmentType
from harbor.models.task.config import EnvironmentConfig
from harbor.models.trial.paths import EnvironmentPaths, TrialPaths
from harbor.utils.logger import logger

# Files larger than this are uploaded in chunks via stdin to avoid HTTP 413 errors.
# Also used as the max per write_stdin call — keep well below the API body limit
# (observed failures at 4 MB).
_UPLOAD_CHUNK_SIZE = 512 * 1024  # 512 KB


class TensorLakeClientManager:
    """
    Singleton manager for the SandboxClient.

    Ensures a single shared client across all TensorLakeEnvironment
    instances, with proper cleanup at program termination.
    """

    _instance: "TensorLakeClientManager | None" = None
    _lock = asyncio.Lock()

    def __init__(self):
        self._client: SandboxClient | None = None
        self._client_lock = asyncio.Lock()
        self._logger = logger.getChild(__name__)
        self._cleanup_registered = False

    @classmethod
    async def get_instance(cls) -> "TensorLakeClientManager":
        """Get or create the singleton instance."""
        if cls._instance is None:
            async with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        assert cls._instance is not None
        return cls._instance

    @staticmethod
    def _read_tensorlake_config() -> dict:
        """Read ~/.tensorlake/config.toml if present. Returns {} on any error."""
        import tomllib

        config_path = Path.home() / ".tensorlake" / "config.toml"
        try:
            return tomllib.loads(config_path.read_text())
        except Exception:
            return {}

    async def get_client(self) -> SandboxClient:
        """Get the shared SandboxClient, creating it if necessary."""
        async with self._client_lock:
            if self._client is None:
                self._logger.debug("Creating new TensorLake SandboxClient")

                cfg = self._read_tensorlake_config()
                self._client = SandboxClient(
                    organization_id=cfg.get("organization"),
                    project_id=cfg.get("project"),
                )

                if not self._cleanup_registered:
                    atexit.register(self._cleanup_sync)
                    self._cleanup_registered = True

            return self._client

    def _cleanup_sync(self):
        """Synchronous cleanup wrapper for atexit."""
        try:
            asyncio.run(self._cleanup())
        except Exception as e:
            print(f"Error during TensorLake client cleanup: {e}")

    async def _cleanup(self):
        """No-op: SandboxClient has no persistent connection to close."""
        async with self._client_lock:
            self._client = None


class TensorLakeEnvironment(BaseEnvironment):
    """
    Environment backed by a TensorLake MicroVM Sandbox.

    Uses the tensorlake.sandbox.SandboxClient SDK. Provides the same
    public interface as DaytonaEnvironment:
        start / stop / exec / upload_file / upload_dir /
        download_file / download_dir / is_dir / is_file / attach

    Prerequisites:
      pip install tensorlake tenacity
      export TENSORLAKE_API_KEY="your-api-key"

    To register: add TENSORLAKE to the EnvironmentType enum and update
    harbor/environments/factory.py.
    """

    @classmethod
    def preflight(cls) -> None:
        if not os.environ.get("TENSORLAKE_API_KEY"):
            raise SystemExit(
                "TensorLake requires TENSORLAKE_API_KEY to be set. "
                "Please set this environment variable and try again."
            )

    def __init__(
        self,
        environment_dir: Path,
        environment_name: str,
        session_id: str,
        trial_paths: TrialPaths,
        task_env_config: EnvironmentConfig,
        timeout_secs: int | None = None,
        snapshot_id: str | None = None,
        preinstall_packages: list[str] | None = None,
        **kwargs,
    ):
        """
        Args:
            timeout_secs: Hard timeout for the sandbox. If None the sandbox
                runs until explicitly deleted.
            snapshot_id: Optional pre-warmed snapshot ID to restore from.
            preinstall_packages: Extra apt packages to install at sandbox start.
                Use for task-specific native dependencies (e.g. build-essential,
                rustc, chromium-browser). Prefer snapshots for large or
                frequently-used package sets to avoid the install cost on every run.
                Example: ["build-essential", "rustc", "cargo"]
        """
        super().__init__(
            environment_dir=environment_dir,
            environment_name=environment_name,
            session_id=session_id,
            trial_paths=trial_paths,
            task_env_config=task_env_config,
            **kwargs,
        )
        self._timeout_secs = timeout_secs
        self._snapshot_id = snapshot_id
        self._preinstall_packages: list[str] = preinstall_packages or []

        self._client_manager: TensorLakeClientManager | None = None
        self._client: SandboxClient | None = None
        self._sandbox_id: str | None = None
        # The connected sandbox handle (returned by client.connect())
        self._sandbox: Sandbox | None = None

        # Parse WORKDIR, RUN, and COPY commands from Dockerfile if present.
        self._workdir = "/root"
        self._dockerfile_env: dict[str, str] = {}
        # Ordered list of instructions: ("RUN", workdir, cmd) or
        # ("COPY", src, dest, workdir, from_value)
        self._dockerfile_instructions: list[tuple] = []
        self._base_image: str | None = None
        self._python_version: str | None = None

        try:
            if self._dockerfile_path.exists():
                (
                    self._base_image,
                    self._workdir,
                    self._dockerfile_env,
                    self._dockerfile_instructions,
                    self._python_version,
                ) = self._parse_dockerfile(self._dockerfile_path)
        except Exception:
            pass  # Fallback to default base, /root, no RUN/COPY commands

        # Fall back to config image for Python version detection when Dockerfile has no FROM
        cfg_image = self._base_image or self.task_env_config.docker_image
        if cfg_image and cfg_image.startswith("python:"):
            try:
                tag = cfg_image.split(":", 1)[1]
                v_part = tag.split("-")[0]
                if "." in v_part and all(c.isdigit() or c == "." for c in v_part):
                    # Truncate to major.minor for apt package compatibility (e.g. 3.12.1 -> 3.12)
                    v_nums = v_part.split(".")
                    self._python_version = ".".join(v_nums[:2])
            except (IndexError, ValueError):
                pass

    # ── BaseEnvironment properties ───────────────────────────────────────

    # Official Docker Hub images whose default variant is Debian-based.
    # All of these use Debian bookworm (or bullseye) unless an explicit
    # ``ubuntu`` tag suffix is added.
    _DEBIAN_BASED_PREFIXES = (
        "debian:",
        "python:",
        "node:",
        "ruby:",
        "golang:",
        "rust:",
        "openjdk:",
        "php:",
        "perl:",
        "r-base:",
        "julia:",
        "swift:",
    )

    # Debian release codename → major version number.
    _DEBIAN_CODENAME_VERSIONS: dict[str, int] = {
        "buster": 10,
        "bullseye": 11,
        "bookworm": 12,
        "trixie": 13,
        "forky": 14,
    }

    # Debian major version number → release codename (inverse of above).
    _DEBIAN_VERSION_CODENAMES: dict[int, str] = {
        v: k for k, v in _DEBIAN_CODENAME_VERSIONS.items()
    }

    @property
    def _is_debian(self) -> bool:
        """True when the task's Dockerfile targets a Debian-based image.

        Covers official Docker Hub images that use Debian as their default
        base (python:, node:, ruby:, golang:, rust:, openjdk:, php:, …) as
        well as explicit debian: images.  Explicit ubuntu: images and missing
        FROM directives default to Ubuntu.
        """
        image = self._base_image or self.task_env_config.docker_image or ""
        if not image:
            return False
        image_lower = image.lower()
        if "ubuntu" in image_lower:
            return False
        return any(image_lower.startswith(p) for p in self._DEBIAN_BASED_PREFIXES)

    @property
    def _debian_version(self) -> int | None:
        """Return the Debian major version number targeted by the FROM image.

        Detection order:
        1. Codename in the image tag (bookworm → 12, bullseye → 11, …).
        2. Numeric version in a ``debian:NN`` tag (debian:12 → 12).
        3. Default to 12 (Bookworm) for unnamed Debian-based images such as
           ``python:3.13-slim`` or ``node:20``, which currently default to
           Bookworm on Docker Hub.
        Returns None for non-Debian images.
        """
        if not self._is_debian:
            return None
        image = (self._base_image or self.task_env_config.docker_image or "").lower()
        for codename, version in self._DEBIAN_CODENAME_VERSIONS.items():
            if codename in image:
                return version
        m = re.search(r"\bdebian:(\d+)", image)
        if m:
            return int(m.group(1))
        # Unnamed Debian-based images (python:3.x-slim, node:20, etc.) currently
        # default to Bookworm on Docker Hub.
        return 12

    @staticmethod
    def type() -> EnvironmentType:
        # Add TENSORLAKE to the EnvironmentType enum before using this.
        return EnvironmentType.TENSORLAKE

    @property
    def capabilities(self) -> EnvironmentCapabilities:
        # TensorLake supports allow_internet_access=False at creation time.
        return EnvironmentCapabilities(gpus=True, disable_internet=True)

    @property
    def _dockerfile_path(self) -> Path:
        return self.environment_dir / "Dockerfile"

    def _validate_definition(self):
        # TensorLake sandboxes use ubuntu:24.04 — no Dockerfile is required.
        # Override to no-op; remove if your base class requires a definition file.
        pass

    @staticmethod
    def _parse_dockerfile(
        path: Path,
    ) -> tuple[str | None, str, dict[str, str], list[tuple], str | None]:
        """Extract FROM, WORKDIR, ENV, RUN, and COPY commands from a Dockerfile.

        Returns:
            - base_image: the image from the first FROM directive, or None
            - final_workdir: last WORKDIR directive, defaults to "/root"
            - env: accumulated ENV key/value pairs
            - instructions: ordered list of instructions in Dockerfile order.
              Each entry is one of:
                ("RUN", workdir, command)
                ("COPY", src, dest, workdir, from_value)
              Preserving order is critical: COPYs that depend on prior RUNs
              having created destination directories must execute after those
              RUNs, not batched before them.
              from_value is the --from= argument when present (multi-stage
              build reference); None for local build-context copies.
              Other flags like --chown and --chmod are stripped.
            - python_version: extracted version if using a python: base image
        """
        base_image = None
        python_version = None
        current_workdir = "/root"
        current_env: dict[str, str] = {}
        instructions: list[tuple] = []

        raw = path.read_text()
        # Join line continuations before tokenising
        lines: list[str] = []
        pending = ""
        # raw = raw + "\\nRUN apt remove -y python3-typing-extensions"

        for raw_line in raw.splitlines():
            stripped = raw_line.rstrip()
            if stripped.endswith("\\"):
                # Check for escaped backslash
                if stripped.endswith("\\\\"):
                    lines.append(pending + stripped)
                    pending = ""
                else:
                    pending += stripped[:-1]
            else:
                lines.append(pending + stripped)
                pending = ""
        if pending:
            lines.append(pending)

        for line in lines:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(None, 1)
            if len(parts) < 2:
                continue
            instruction = parts[0].upper()
            arg = parts[1].strip()
            if instruction == "FROM":
                # Only take the first FROM (ignoring multi-stage alias targets)
                if base_image is None:
                    tokens = arg.split()
                    for t in tokens:
                        if not t.startswith("--") and t.upper() != "AS":
                            base_image = t
                            if base_image.startswith("python:"):
                                tag = base_image.split(":", 1)[1]
                                v_part = tag.split("-")[0]
                                if "." in v_part and all(
                                    c.isdigit() or c == "." for c in v_part
                                ):
                                    # Truncate to major.minor for apt package compatibility
                                    v_nums = v_part.split(".")
                                    python_version = ".".join(v_nums[:2])
                            break
            elif instruction == "WORKDIR":
                if arg.startswith("/"):
                    current_workdir = arg
                else:
                    current_workdir = str(PurePosixPath(current_workdir) / arg)
            elif instruction == "ARG":
                # ARG NAME=default_value — treat the default as an env variable
                # so that RUN commands that reference ${NAME} have it available.
                # ARG without a default (ARG NAME) is ignored; no value to inject.
                if "=" in arg:
                    k, _, v = arg.partition("=")
                    current_env[k.strip()] = v.strip()
            elif instruction == "ENV":
                try:
                    # shlex.split correctly handles quotes and spaces in values
                    tokens = shlex.split(arg)
                    if not tokens:
                        continue
                    # Support "ENV KEY=VALUE ..."
                    if "=" in tokens[0]:
                        for token in tokens:
                            if "=" in token:
                                k, _, v = token.partition("=")
                                current_env[k] = v
                    # Support deprecated "ENV KEY VALUE"
                    elif len(tokens) >= 2:
                        current_env[tokens[0]] = tokens[1]
                except ValueError:
                    # Fallback for malformed quotes
                    kv = arg.split(None, 1)
                    if len(kv) == 2:
                        current_env[kv[0]] = kv[1]
            elif instruction == "RUN":
                if arg.startswith("["):
                    try:
                        cmd_list = json.loads(arg)
                        if isinstance(cmd_list, list):
                            arg = shlex.join(cmd_list)
                    except (json.JSONDecodeError, TypeError):
                        pass
                instructions.append(("RUN", current_workdir, arg))
            elif instruction in ("COPY", "ADD"):
                tokens = []
                if arg.startswith("["):
                    try:
                        tokens = json.loads(arg)
                    except (json.JSONDecodeError, TypeError):
                        pass

                if not tokens:
                    try:
                        tokens = shlex.split(arg)
                    except ValueError:
                        pass

                if tokens and isinstance(tokens, list):
                    from_value: str | None = None
                    filtered_tokens = []
                    for t in tokens:
                        if isinstance(t, str) and t.startswith("--from="):
                            from_value = t[len("--from=") :]
                        elif isinstance(t, str) and not t.startswith("--"):
                            filtered_tokens.append(t)

                    if len(filtered_tokens) >= 2:
                        dest = filtered_tokens[-1]
                        for src in filtered_tokens[:-1]:
                            instructions.append(
                                ("COPY", src, dest, current_workdir, from_value)
                            )

        return base_image, current_workdir, current_env, instructions, python_version

    # ── Sandbox helpers ──────────────────────────────────────────────────

    def _assert_sandbox(self):
        if self._sandbox is None or self._sandbox_id is None:
            raise RuntimeError("Sandbox not found. Please call start() first.")

    @property
    def _active_sandbox(self) -> Sandbox:
        assert self._sandbox is not None
        return self._sandbox

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=15),
        reraise=True,
    )
    async def _create_sandbox(self) -> None:
        """Create (or restore) a TensorLake sandbox and connect to it."""
        assert self._client is not None

        kwargs: dict = dict(
            cpus=float(self.task_env_config.cpus),
            memory_mb=self.task_env_config.memory_mb,
            ephemeral_disk_mb=self.task_env_config.storage_mb,
            allow_internet_access=self.task_env_config.allow_internet,
            timeout_secs=self._timeout_secs
            if self._timeout_secs is not None
            else 24 * 60 * 60,
            # Generous boot timeout: concurrent runs compete for cloud capacity.
            startup_timeout=600,
        )
        if self._snapshot_id:
            kwargs["snapshot_id"] = self._snapshot_id
        else:
            if self._is_debian:
                dv = self._debian_version
                if dv == 12:
                    kwargs["image"] = "tensorlake/debian12-minimal"
                elif dv == 11:
                    kwargs["image"] = "tensorlake/debian11-minimal"
                else:
                    # Trixie (13) or unrecognised Debian version — use the default.
                    kwargs["image"] = "tensorlake/debian-minimal"
            else:
                kwargs["image"] = "tensorlake/ubuntu-minimal"

        # create_and_connect() creates the sandbox, polls until SandboxStatus.RUNNING,
        # then connects — preventing SANDBOX_NOT_RUNNING errors on immediate exec calls.
        client = self._client
        loop = asyncio.get_running_loop()
        create_future = loop.run_in_executor(
            None, lambda: client.create_and_connect(**kwargs)
        )
        try:
            self._sandbox = await asyncio.shield(create_future)
        except asyncio.CancelledError:
            try:
                self._sandbox = await asyncio.wait_for(create_future, timeout=30)
            except (asyncio.CancelledError, asyncio.TimeoutError, Exception):
                pass
            else:
                self._sandbox_id = self._active_sandbox.sandbox_id
            raise
        self._sandbox_id = self._active_sandbox.sandbox_id

    @retry(
        stop=stop_after_attempt(2),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )
    async def _delete_sandbox(self) -> None:
        assert self._client is not None and self._sandbox_id is not None
        client = self._client
        sandbox_id = self._sandbox_id
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, lambda: client.delete(sandbox_id))

    # ── Public lifecycle ─────────────────────────────────────────────────

    async def start(self, force_build: bool) -> None:
        """
        Create the sandbox and prepare the agent/verifier directories.

        `force_build` is accepted for interface parity but has no effect:
        TensorLake does not build from a Dockerfile at runtime. If you need
        pre-installed dependencies, build a snapshot first and pass its ID
        via `snapshot_id`.
        """
        if force_build:
            self.logger.warning(
                "force_build=True has no effect on TensorLakeEnvironment. "
                "TensorLake sandboxes boot from a pre-built base image. To pre-install "
                "dependencies, create a snapshot and pass snapshot_id instead."
            )

        self._client_manager = await TensorLakeClientManager.get_instance()
        self._client = await self._client_manager.get_client()

        # Set baseline environment variables before creation/start
        await self._create_sandbox()

        # Advertise sandbox capabilities via env vars so agents can adapt.
        # KVM is not available (no nested virt on TensorLake MicroVMs), and
        # Docker is not available (no container runtime). Agents that respect
        # these vars can skip -enable-kvm, avoid `docker run`, etc.
        self._persistent_env.setdefault("TENSORLAKE_SANDBOX", "1")
        self._persistent_env.setdefault("SANDBOX_KVM_AVAILABLE", "0")
        self._persistent_env.setdefault("SANDBOX_DOCKER_AVAILABLE", "0")
        self._persistent_env.setdefault("DEBIAN_FRONTEND", "noninteractive")
        # Ensure a full standard PATH is always exported.  The sandbox process
        # may start with a stripped-down PATH that omits /usr/bin, causing
        # external commands like `realpath` and `dirname` (used by uv's pytest
        # trampoline scripts) to be silently missing.
        self._persistent_env.setdefault(
            "PATH",
            "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        )

        # Merge environment variables discovered in the Dockerfile
        if self._dockerfile_env:
            for k, v in self._dockerfile_env.items():
                self._persistent_env.setdefault(k, v)

        await self.exec(
            f"mkdir -p {EnvironmentPaths.agent_dir} {EnvironmentPaths.verifier_dir} {shlex.quote(self._workdir)}",
            cwd="/",
        )

        # When restoring from a snapshot, the sandbox already has the baseline
        # setup, Dockerfile replay output, and any preinstalled packages baked
        # in. Re-running them defeats the purpose of the snapshot.
        if self._snapshot_id:
            self.logger.debug(
                "Skipping baseline setup and Dockerfile replay: restored from snapshot"
            )
            return

        # Bring up the loopback interface.
        # TensorLake MicroVMs start with `lo` in DOWN state, so connections to
        # 127.0.0.1 (used by tasks that run local servers, e.g. nginx on port
        # 8443, and verified via curl https://localhost:8443) time out instead
        # of looping back.  Bringing lo up restores standard loopback behaviour.
        await self.exec("ip link set lo up || ifconfig lo up || true", cwd="/")

        # Ubuntu 24.04 enforces PEP 668: pip install is blocked system-wide by default.
        # Many verifier test.sh scripts run `pip install pytest` and fail with
        # "externally-managed-environment". Setting break-system-packages globally
        # in pip.conf restores the Docker-like behaviour expected by task verifiers.
        await self.exec(
            'printf "[install]\\nbreak-system-packages = true\\n" > /etc/pip.conf',
            cwd="/",
        )

        # Cap setuptools at <70 globally via a pip constraints file.
        # setuptools 70+ deprecated pkg_resources as a top-level importable module.
        # Legacy packages (pystan ≤3.10, older httpstan, many scientific tools) do
        # `import pkg_resources` directly and fail with a ModuleNotFoundError when
        # setuptools ≥70 is installed.  Setting PIP_CONSTRAINT ensures that every
        # pip invocation in the sandbox — including ones inside oracle solve.sh
        # scripts and venvs — respects this cap without any per-command changes.
        await self.exec(
            "echo 'setuptools<70' > /etc/pip-constraints.txt",
            cwd="/",
        )
        self._persistent_env.setdefault("PIP_CONSTRAINT", "/etc/pip-constraints.txt")

        if not self._is_debian:
            # Replace py3compile (and py3versions) with no-ops to prevent
            # "Too many levels of symbolic links" failures in dpkg post-install
            # scripts on Ubuntu.  On Debian these utilities work correctly.
            await self.exec(
                "printf '#!/bin/sh\\nexit 0\\n'"
                " | tee /usr/bin/py3compile /usr/bin/py3versions > /dev/null"
                " && chmod +x /usr/bin/py3compile /usr/bin/py3versions",
                cwd="/",
            )

        # Install apt-get / apt wrapper scripts that silently strip OS-specific
        # version pins (e.g. curl=8.5.0-2ubuntu10.6) before passing arguments to
        # the real apt binary.  Oracle solve.sh scripts written for Ubuntu include
        # such pins; on Debian the pinned version doesn't exist, causing the entire
        # install command to fail with "Version '…' for '…' was not found" even
        # when every other requested package is available.
        # The wrappers live in /usr/local/bin so they shadow /usr/bin/apt[-get]
        # for all callers including sudo invocations.
        await self.exec(
            r"""printf '#!/bin/bash\n"""
            r"""# Harbor apt-get wrapper: strip OS-specific version pins.\n"""
            r"""args=()\n"""
            r"""for arg in "$@"; do\n"""
            r"""  if [[ "$arg" =~ ^[a-z0-9][a-z0-9.+~-]*=[a-zA-Z0-9.+~:_-]+$ ]]; then\n"""
            r"""    args+=("${arg%%=*}")\n"""
            r"""  else\n"""
            r"""    args+=("$arg")\n"""
            r"""  fi\n"""
            r"""done\n"""
            r"""exec /usr/bin/apt-get "${args[@]}"\n"""
            r"""' > /usr/local/bin/apt-get"""
            r""" && chmod +x /usr/local/bin/apt-get"""
            r""" && sed 's|/usr/bin/apt-get|/usr/bin/apt|g' /usr/local/bin/apt-get"""
            r""" > /usr/local/bin/apt"""
            r""" && chmod +x /usr/local/bin/apt""",
            cwd="/",
        )

        # Fix hostname resolution so tools that bind to the machine's hostname
        # (e.g. PyTorch GLOO collective backend, MPI) work without extra config.
        # The sandbox hostname may not be in /etc/hosts, causing gethostbyname()
        # to fail and gloo/nccl/mpi to abort or fall back to an unusable interface.
        await self.exec(
            "HOSTNAME=$(hostname);"
            ' grep -q "$HOSTNAME" /etc/hosts'
            ' || echo "127.0.0.1 $HOSTNAME" >> /etc/hosts',
            cwd="/",
        )

        # Pin Python version if detected in Dockerfile or config
        if self._python_version:
            v = self._python_version

            self.logger.debug(f"Ensuring Python {v} is installed and pinned as default")

            # Shared tail: always ensure python dev headers and symlinks are set up.
            # Update symlinks in both /usr/local/bin and /usr/bin so that the
            # pinned Python is found first regardless of PATH ordering.  Sandbox
            # images (e.g. debian12-minimal) pre-install Python at
            # /usr/local/bin/python3, which shadows /usr/bin/python3 via PATH;
            # writing to both locations guarantees the correct version is used.
            _pin_symlinks = (
                'if [ -n "$TARGET" ]; then '
                '  ln -sf "$TARGET" /usr/local/bin/python3'
                '  && ln -sf "$TARGET" /usr/local/bin/python'
                '  && ln -sf "$TARGET" /usr/bin/python3'
                '  && ln -sf "$TARGET" /usr/bin/python; '
                "fi"
            )
            _pin_tail = (
                # Always ensure python dev headers are present.
                # The interpreter may already exist but without the -dev package,
                # which is required for building C extensions (Python.h).
                "apt-get install -y python$V-dev 2>/dev/null || true; "
                "TARGET=$(command -v python$V); " + _pin_symlinks
            )

            if self._is_debian:
                dv = self._debian_version
                backports_codename = self._DEBIAN_VERSION_CODENAMES.get(dv or 0)
                if backports_codename:
                    # Enable the backports pocket so non-default Python versions
                    # (e.g. 3.12/3.13 on Bookworm, 3.10 on Bullseye) are available
                    # without requiring an Ubuntu PPA.
                    _enable_backports = (
                        f"grep -qr {backports_codename}-backports "
                        "/etc/apt/sources.list /etc/apt/sources.list.d/ 2>/dev/null "
                        f"|| (echo 'deb http://deb.debian.org/debian "
                        f"{backports_codename}-backports main' "
                        "> /etc/apt/sources.list.d/harbor-backports.list "
                        "&& apt-get update -qq); "
                    )
                    # uv fallback: if apt cannot supply the requested Python
                    # version (e.g. python3.10 is absent from the minimal
                    # sandbox apt repos), download a standalone CPython binary
                    # via uv and symlink it into /usr/local/bin so that
                    # subsequent 'command -v python$V' succeeds.
                    _uv_python_fallback = (
                        "if ! command -v python$V >/dev/null 2>&1; then "
                        "  pip install --quiet uv 2>/dev/null || true; "
                        "  uv python install $V --quiet 2>/dev/null || true; "
                        "  _UV_PY=$(uv python find $V 2>/dev/null); "
                        '  if [ -n "$_UV_PY" ]; then '
                        '    ln -sf "$_UV_PY" /usr/local/bin/python$V; '
                        "  fi; "
                        "fi; "
                    )
                    pin_cmd = (
                        f"V={shlex.quote(v)}; "
                        + _enable_backports
                        + "if ! command -v python$V >/dev/null 2>&1; then "
                        "  apt-get install -y python$V "
                        f"  || apt-get install -y -t {backports_codename}-backports "
                        "    python$V python$V-dev python$V-venv || true; "
                        "fi; "
                        + _uv_python_fallback
                        + f"(apt-get install -y python$V-dev "
                        f"|| apt-get install -y -t {backports_codename}-backports "
                        "  python$V-dev) 2>/dev/null || true; "
                        "TARGET=$(command -v python$V); " + _pin_symlinks
                    )
                else:
                    # Trixie or unknown Debian — Python is already in main repos.
                    pin_cmd = (
                        f"V={shlex.quote(v)}; "
                        "if ! command -v python$V >/dev/null 2>&1; then "
                        "  apt-get update -qq && "
                        "  apt-get install -y python$V python$V-dev python$V-venv || true; "
                        "fi; " + _pin_tail
                    )
            else:
                # Ubuntu: use the deadsnakes PPA for non-native Python versions.
                pin_cmd = (
                    f"V={shlex.quote(v)}; "
                    "if ! command -v python$V >/dev/null 2>&1; then "
                    "  apt-get update -qq && apt-get install -y software-properties-common && "
                    "  add-apt-repository -y ppa:deadsnakes/ppa && apt-get update -qq && "
                    "  apt-get install -y python$V python$V-dev python$V-venv || true; "
                    "fi; " + _pin_tail
                )
            await self.exec(pin_cmd, cwd="/")

            # Create pip / pip3 wrappers that always call the pinned python3 -m pip.
            # Without this, solve.sh scripts that run bare `pip install …` install
            # packages into the Ubuntu system Python (3.12), while `python3` executes
            # scripts under the pinned version (e.g., 3.13), producing
            # "No module named '…'" errors at runtime.
            await self.exec(
                "printf '#!/bin/sh\\nexec python3 -m pip \"$@\"\\n'"
                " | tee /usr/local/bin/pip /usr/local/bin/pip3 > /dev/null"
                " && chmod +x /usr/local/bin/pip /usr/local/bin/pip3",
                cwd="/",
            )

            # When the pinned python3 lives in a non-standard location (e.g. a
            # uv-managed CPython in ~/.local/share/uv/python/…/bin/), scripts
            # installed by `pip install <tool>` (pytest, black, mypy, …) land in
            # that same bin directory which is NOT in the default PATH.  Query the
            # actual interpreter location and prepend its directory to the
            # persistent PATH so every subsequent exec() — including the verifier's
            # test.sh — can find those scripts without any per-script symlink dance.
            py_bin_result = await self.exec(
                "python3 -c 'import sys, os; print(os.path.dirname(os.path.realpath(sys.executable)))'",
                cwd="/",
            )
            py_bin = (py_bin_result.stdout or "").strip()
            if py_bin and py_bin not in ("/usr/bin", "/usr/local/bin"):
                current_path = self._persistent_env.get("PATH", "")
                if py_bin not in current_path:
                    self._persistent_env["PATH"] = f"{py_bin}:{current_path}"
                    self.logger.debug(f"Prepended {py_bin} to PATH for pinned python3")

        # Ensure 'python' resolves to python3 if it is missing.
        # Many solve.sh scripts call bare 'python' which is absent on Debian/Ubuntu
        # images that only ship python3.  Runs after the pin step so that any
        # version-specific symlink created there takes precedence; this only fires
        # when no 'python' command exists yet.  pin_cmd now only symlinks when a
        # version-specific binary is found, so this never races against a circular
        # self-symlink on /usr/bin/python3.
        await self.exec(
            "command -v python >/dev/null 2>&1"
            ' || ln -sf "$(command -v python3)" /usr/local/bin/python',
            cwd="/",
        )

        # Ensure /dev/fd is available for bash process substitution (<(...) syntax).
        # TensorLake MicroVMs may not symlink /dev/fd to /proc/self/fd by default,
        # causing scripts that use <(...) or >(...) to fail with
        # "/dev/fd/63: No such file or directory".
        await self.exec(
            "[ -e /dev/fd ] || ln -sf /proc/self/fd /dev/fd",
            cwd="/",
        )

        # Unmount all stacked /tmp filesystems (typically a tmpfs layer from the
        # MicroVM image) so that /tmp becomes a plain directory on the root
        # filesystem.  This allows os.rename() / shutil.move() between the workdir
        # and /tmp to succeed as an atomic same-device rename; otherwise Linux's
        # rename(2) returns EXDEV because it checks mount points, not just device
        # numbers, and a separate /tmp mount counts as a different filesystem even
        # when it is backed by the same block device.
        await self.exec(
            "while umount /tmp 2>/dev/null; do true; done && chmod 1777 /tmp || true",
            cwd="/",
        )

        # Install any task-specific packages requested via preinstall_packages.
        # Prefer snapshots for large/common sets; this is for occasional one-offs.
        if self._preinstall_packages:
            pkgs = " ".join(shlex.quote(p) for p in self._preinstall_packages)
            self.logger.debug(f"Pre-installing packages: {pkgs}")
            await self.exec(
                f"apt-get update -qq && apt-get install -y {pkgs}",
                cwd="/",
            )

        # Pre-install build-essential for slim/minimal base images.
        # Images like python:3.x-slim-bookworm ship without gcc/make, causing
        # any pip install that builds from source (e.g. rcsb-api, docopt) to
        # fail with "command 'gcc' failed: No such file or directory".
        # Also pre-install libglib2.0-0: required by opencv-python and other
        # GLib-based packages.  Slim images omit it; full Docker Hub python:x.y
        # images include it, so tasks authored against those images expect it.
        if self._base_image and "slim" in self._base_image:
            await self.exec(
                "apt-get update -qq && apt-get install -y --no-install-recommends"
                " build-essential libglib2.0-0",
                cwd="/",
            )
        elif self._is_debian:
            # Full (non-slim) Debian-based images also lack libglib2.0-0 in the
            # TensorLake minimal sandbox, even though the Docker Hub python:x.y
            # full image ships it.  Install it so opencv-python and similar GLib
            # packages can load their shared libraries without ImportError.
            await self.exec(
                "apt-get update -qq && apt-get install -y --no-install-recommends"
                " libglib2.0-0 || true",
                cwd="/",
            )

        # Install a pass-through sudo wrapper.
        # The sandbox runs as root, so sudo is unnecessary — but many solve.sh oracle
        # scripts call 'sudo apt-get' and will abort immediately if sudo is missing.
        # Creating a thin wrapper that exec's its arguments lets those scripts work
        # without modification.
        await self.exec(
            "command -v sudo >/dev/null 2>&1"
            " || { printf '#!/bin/sh\\nexec \"$@\"\\n' > /usr/local/bin/sudo"
            " && chmod +x /usr/local/bin/sudo; }",
            cwd="/",
        )

        if self._is_debian:
            # On Debian, the system python3-setuptools is sometimes installed as an
            # empty namespace stub, causing "cannot import name 'find_packages' from
            # setuptools (unknown location)" when any package's setup.py is built.
            # Pre-installing setuptools via pip gives pip full ownership and a
            # working copy with all legacy APIs intact.
            await self.exec(
                "pip install --quiet --ignore-installed setuptools",
                cwd="/",
            )

            # Provide a gets() compatibility shim for legacy C code.
            # Debian Trixie (glibc 2.40) removed gets() from the C standard library.
            # Old C programs that use gets() will fail to link with "undefined reference
            # to 'gets'" without this shim.  We compile a tiny shared library that
            # re-implements gets() using fgets() and strip the trailing newline to
            # preserve the original gets() semantics.
            # Note: use (char)10 instead of '\n' to avoid single-quote escaping issues
            # in the printf format string.
            await self.exec(
                "printf "
                "'#include <stdio.h>\\n"
                "#include <string.h>\\n"
                "char *gets(char *s){\\n"
                "  char *r=fgets(s,65536,stdin);\\n"
                "  if(r){size_t l=strlen(r);"
                "if(l&&r[l-1]==(char)10)r[l-1]=0;}\\n"
                "  return r;\\n"
                "}\\n'"
                " > /tmp/_gets_compat.c"
                " && gcc -shared -fPIC -o /usr/local/lib/libgets.so /tmp/_gets_compat.c"
                " && ldconfig"
                " || true",
                cwd="/",
            )
        else:
            # Ubuntu 24.04 ships blinker and numpy as apt packages without pip
            # RECORD files, causing "Cannot uninstall … RECORD file not found"
            # when pip tries to upgrade them.  Removing the dist-packages entries
            # and pre-installing via pip gives pip ownership of both packages.
            await self.exec(
                "rm -rf"
                " /usr/lib/python3/dist-packages/blinker*"
                " /usr/local/lib/python3.*/dist-packages/blinker*"
                " /usr/lib/python3/dist-packages/numpy*"
                " /usr/lib/python3/dist-packages/numpy"
                " /usr/lib/python3/dist-packages/numpy-*",
                cwd="/",
            )
            await self.exec(
                "pip install --quiet numpy",
                cwd="/",
            )
            # Pre-install software-properties-common so that oracle solve.sh scripts
            # that call 'add-apt-repository ppa:...' find the command available.
            await self.exec(
                "apt-get install -y --no-install-recommends software-properties-common"
                " 2>/dev/null || true",
                cwd="/",
            )

        # Pre-install tqdm for all sandbox types (Debian and Ubuntu).
        # tqdm is widely used by data-processing scripts (e.g. reshard-c4-data)
        # and is not available by default in the sandbox Python.  Installing it
        # here means any `uv run script.py` or bare `python script.py` that
        # imports tqdm will find it without needing task-specific setup.
        await self.exec(
            "pip install --quiet tqdm",
            cwd="/",
        )

        # Replay Dockerfile instructions (COPY/ADD and RUN) in their original order.
        # Preserving order is critical: many tasks have RUN commands that create
        # directories (e.g. `apt-get install nginx`, `git clone ...`) that must
        # exist before a subsequent COPY can land files in them.  Batching all
        # COPYs first and all RUNs second breaks those workflows.
        #
        # If the Dockerfile has no COPY/RUN instructions at all, fall back to
        # uploading the whole build context so existing no-Dockerfile tasks are
        # unaffected.
        has_copy = any(ins[0] == "COPY" for ins in self._dockerfile_instructions)
        has_run = any(ins[0] == "RUN" for ins in self._dockerfile_instructions)

        if self.environment_dir.exists() and not has_copy and not has_run:
            # No Dockerfile instructions: upload everything to workdir (legacy behaviour).
            await self.upload_dir(self.environment_dir, self._workdir)
        else:
            for ins in self._dockerfile_instructions:
                if ins[0] == "COPY":
                    _, src, dest, copy_workdir, from_value = ins
                    if from_value is not None:
                        await self._handle_multistage_copy(
                            src, dest, copy_workdir, from_value
                        )
                    elif self.environment_dir.exists():
                        await self._handle_copy_command(src, dest, copy_workdir)
                else:  # RUN
                    _, cmd_workdir, run_cmd = ins
                    run_cmd = self._adapt_run_command(run_cmd)
                    self.logger.debug(f"Dockerfile RUN: {run_cmd[:120]}")
                    result = await self.exec(run_cmd, cwd=cmd_workdir)
                    if result.return_code == 100 and re.search(
                        r"\bapt(?:-get)?\s+install\b", run_cmd
                    ):
                        # apt exit 100 means a package was not found.  Retry by
                        # installing each package individually so that one missing
                        # package (e.g. 'telnet' renamed in a newer distro) doesn't
                        # prevent all others (e.g. 'expect', 'tmux') from installing.
                        self.logger.warning(
                            f"apt install exited 100, retrying per-package: {run_cmd[:80]!r}"
                        )
                        result = await self._apt_install_individually(
                            run_cmd, cwd=cmd_workdir
                        )
                    if result.return_code != 0:
                        self.logger.warning(
                            f"Dockerfile RUN exited {result.return_code}: {run_cmd[:120]!r}"
                        )

    # Shell script appended to any RUN that installs chromium/chromium-driver.
    # Ubuntu 24.04 ships `chromium` as a snap stub — the binary at /usr/bin/chromium
    # just prints "please install the snap" and exits, making chromedriver crash.
    # We replace it with Google Chrome Stable + a matching chromedriver from the
    # Chrome for Testing distribution.
    _CHROMIUM_REPLACEMENT = (
        # Download + install Google Chrome Stable .deb
        "wget -q -O /tmp/_chrome.deb "
        "https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb "
        "&& apt-get install -y /tmp/_chrome.deb "
        "&& rm /tmp/_chrome.deb "
        # Symlink so code that hardcodes /usr/bin/chromium still works
        "&& ln -sf /usr/bin/google-chrome /usr/bin/chromium "
        # Download matching chromedriver from Chrome for Testing using the
        # installed Chrome version. Pure shell avoids python3 -c quoting hazards.
        # google-chrome --version prints e.g. "Google Chrome 135.0.7049.84 "
        "&& CHROME_VER=$(google-chrome --version | awk '{print $3}') "
        "&& wget -q -O /tmp/_cd.zip "
        '"https://storage.googleapis.com/chrome-for-testing-public/${CHROME_VER}/linux64/chromedriver-linux64.zip" '
        "&& unzip -o /tmp/_cd.zip -d /tmp/ "
        "&& cp /tmp/chromedriver-linux64/chromedriver /usr/bin/chromedriver "
        "&& chmod +x /usr/bin/chromedriver "
        "&& rm -rf /tmp/_cd.zip /tmp/chromedriver-linux64"
    )

    # Packages that map to the snap stub on Ubuntu 24.04 noble.
    _CHROMIUM_PKG_RE = re.compile(r"\b(chromium(?:-browser|-driver|-chromedriver)?)\b")

    def _adapt_run_command(self, cmd: str) -> str:
        """Rewrite apt/pip idioms in Dockerfile RUN commands for the sandbox image.

        Transformations applied to both Ubuntu and Debian sandboxes:
          • Prepend 'apt-get update -qq || true && DEBIAN_FRONTEND=noninteractive'
            to any 'apt install' that doesn't already include an update step.
          • Replace bare 'pip' / 'pip3' with 'python -m pip' / 'python3 -m pip'.
          • Fix mteb pip installs to pin compatible transformers/Pillow versions.

        Ubuntu-only transformations (skipped for Debian sandboxes):
          • Replace Debian deb-src apt sources with Ubuntu noble equivalents.
          • Replace chromium/chromium-driver apt packages with Google Chrome Stable
            + a matching chromedriver (Ubuntu ships chromium as a snap stub).
          • Replace libgl1-mesa-glx (removed in Ubuntu 22.04+) with libgl1.
        """
        # Ensure apt package lists are fresh before any standalone 'apt install'
        # command, and that DEBIAN_FRONTEND is set to suppress interactive prompts.
        # Use '|| true' after apt-get update so that GPG/network warnings don't
        # short-circuit the install step.
        # Also inject -o Acquire::Max-FutureTime=86400 into every apt-get update so
        # that sandboxes whose system clock is slightly in the future don't reject
        # freshly-signed InRelease files ("Release file is not yet valid").
        if re.search(r"\bapt(?:-get)?\s+install\b", cmd) and not re.search(
            r"\bapt(?:-get)?\s+update\b", cmd
        ):
            cmd = (
                "apt-get update -o Acquire::Max-FutureTime=86400 -qq || true"
                " && DEBIAN_FRONTEND=noninteractive " + cmd
            )
        elif re.search(r"\bapt(?:-get)?\s+update\b", cmd) and re.search(
            r"\bapt(?:-get)?\s+install\b", cmd
        ):
            # Inject Max-FutureTime into the existing update invocation and add || true.
            cmd = re.sub(
                r"(apt(?:-get)?\s+update)((?:\s+[^&|;\s][^&|;]*)?)",
                r"\1 -o Acquire::Max-FutureTime=86400\2 || true ",
                cmd,
                count=1,
            )
            cmd = "DEBIAN_FRONTEND=noninteractive " + cmd

        # Replace libgl1-mesa-glx with libgl1.
        # libgl1-mesa-glx was removed in Ubuntu 22.04+ and Debian bookworm+;
        # libgl1 is the correct replacement on both distributions.
        cmd = re.sub(r"\blibgl1-mesa-glx\b", "libgl1", cmd)

        if not self._is_debian:
            # Replace chromium snap-stub packages with Google Chrome + chromedriver.
            if TensorLakeEnvironment._CHROMIUM_PKG_RE.search(cmd):
                cmd = TensorLakeEnvironment._CHROMIUM_PKG_RE.sub("", cmd)
                cmd = re.sub(r"(-y\s)\s+", r"\1", cmd)
                cmd = (
                    cmd.rstrip(" &|;")
                    + " && "
                    + TensorLakeEnvironment._CHROMIUM_REPLACEMENT
                )

        # Strip explicit apt version pins (pkg=X.Y.Z-os1) from apt-get install commands.
        # Pinned versions are almost always OS/release-specific and do not exist in the
        # sandbox's package repository, causing the entire install to exit 100.
        # Removing the pin installs the latest available version, which is sufficient.
        if re.search(r"\bapt(?:-get)?\s+install\b", cmd):
            cmd = re.sub(r"\b([a-z0-9][a-z0-9.+~-]*)=[a-zA-Z0-9.+~:_-]+", r"\1", cmd)

        # Replace bare 'pip' / 'pip3' with 'python -m pip' / 'python3 -m pip'.
        cmd = re.sub(
            r"(^|&&|\|\||[;\|])\s*pip(\d*)(?![-\w])", r"\1 python\2 -m pip ", cmd
        )

        # Fix mteb pip installs: pin transformers==4.49.0 and pillow alongside any
        # mteb install.  Older mteb versions (e.g. 1.36.8) declare transformers>=4.6.0,
        # which allows versions that lack AutoModelForVision2Seq; 4.49.0 is the first
        # reliably compatible release.  Using an exact pin (==) avoids the resolver
        # backtracking that makes >=4.49.0 infeasible on Python 3.10.  Pillow is an
        # undeclared runtime dependency in several mteb evaluation pipelines.
        # TMPDIR is redirected to ~ so that large model downloads don't exhaust /tmp.
        if re.search(r"\bpython\d*\s+-m\s+pip\b.*\binstall\b", cmd) and re.search(
            r"\bmteb\b", cmd
        ):
            cmd = re.sub(
                r"(\bmteb(?:==[^\s\"']+)?)",
                r'\1 "transformers==4.49.0" pillow',
                cmd,
            )
            cmd = "export TMPDIR=~/tmp && mkdir -p $TMPDIR && " + cmd
        # Link the gets() compatibility shim for C/C++ compile+link commands on Debian.
        # Debian Trixie (glibc 2.40) removed gets() from libc; old C programs using
        # gets() fail to link with "undefined reference to 'gets'".  We built a shim
        # shared library in start() and add -lgets here only when actually compiling
        # and linking (not for compile-only -c, preprocessor -E, or assembly -S steps).
        # Guard against apt-get install commands that list gcc/g++ as package names —
        # appending -lgets there corrupts the subsequent `rm -rf /var/lib/apt/lists/*`
        # step and causes the entire RUN to exit 1.
        if self._is_debian and re.search(r"\b(?:gcc|cc|g\+\+|c\+\+)\b", cmd):
            if not re.search(r"\s+-[cES]\b", cmd) and not re.search(
                r"\bapt(?:-get)?\s+install\b", cmd
            ):
                cmd = re.sub(r"(\b(?:gcc|cc|g\+\+|c\+\+)\b[^&|;]*)", r"\1 -lgets", cmd)
        return cmd

    async def _apt_install_individually(
        self, failed_cmd: str, cwd: str | None = None
    ) -> "ExecResult":
        """Retry a failed apt install by installing each package separately.

        When a batch apt-get install exits 100 (package not found), one missing
        package prevents the rest from being installed.  This method extracts the
        package list and installs each one individually, skipping unavailable ones.

        Returns the result of the last install attempt; callers should treat a
        non-zero exit as a warning only (some packages may have succeeded).
        """
        # Find the 'install ... packages' portion
        install_match = re.search(
            r"\bapt(?:-get)?\s+install\b(.*)", failed_cmd, re.DOTALL
        )
        if not install_match:
            return ExecResult(return_code=100)

        args_str = install_match.group(1)
        packages = [
            t
            for t in args_str.split()
            if not t.startswith("-") and t not in ("apt-get", "apt", "install")
        ]

        last_result = ExecResult(return_code=0)
        for pkg in packages:
            result = await self.exec(
                f"apt-get install -y {shlex.quote(pkg)} 2>/dev/null"
                f" || echo 'WARNING: apt-get install {pkg} skipped (not found)'",
                cwd=cwd,
            )
            last_result = result
        return last_result

    async def _handle_multistage_copy(
        self,
        src: str,
        dest: str,
        copy_workdir: str,
        from_value: str,
    ) -> None:
        """Handle Dockerfile `COPY --from=<image-or-stage> ...` instructions.

        Multi-stage build references cannot be replicated without a Docker daemon.
        For known tool images (currently: astral-sh/uv) we install the tool via
        an alternative method.  All other --from= COPYs are skipped with a warning.
        """
        # Resolve dest relative to copy_workdir when not absolute
        if not dest.startswith("/"):
            dest = str(PurePosixPath(copy_workdir) / dest)
        dest_dir = dest.rstrip("/") or "/"

        if "astral-sh/uv" in from_value:
            # Extract version if present in the image name (e.g. ghcr.io/astral-sh/uv:0.5.1)
            uv_spec = "uv"
            if ":" in from_value:
                tag = from_value.rsplit(":", 1)[1]
                if (
                    tag
                    and tag not in ("latest", "alpine", "slim")
                    and any(c.isdigit() for c in tag)
                ):
                    uv_spec = f"uv=={tag.lstrip('v')}"

            # The Dockerfile copies the uv/uvx binaries from the official uv image.
            # Install uv via pip and symlink the binaries to the expected destination.
            self.logger.debug(
                f"Installing {uv_spec} (detected COPY --from={from_value}); "
                f"using pip as an alternative to Docker multi-stage copy"
            )

            result = await self.exec(
                f"pip install {shlex.quote(uv_spec)} --quiet && "
                f"mkdir -p {shlex.quote(dest_dir)} && "
                f'ln -sf "$(which uv)" {shlex.quote(dest_dir)}/uv && '
                f'ln -sf "$(which uvx 2>/dev/null || which uv)" '
                f"{shlex.quote(dest_dir)}/uvx",
                cwd="/",
            )
            if result.return_code != 0:
                self.logger.warning(
                    f"Failed to install uv as replacement for COPY --from={from_value}"
                )
        else:
            # Generic multi-stage reference — can be another named build stage
            # (e.g. --from=build) or an arbitrary image.  Both require Docker to
            # replicate and are skipped here.
            self.logger.warning(
                f"COPY --from={from_value!r} cannot be replicated without Docker "
                f"(source: {src!r} → {dest!r}); skipping"
            )

    async def _handle_copy_command(
        self,
        src: str,
        dest: str,
        copy_workdir: str,
    ) -> None:
        """Upload files/directories as specified by a Dockerfile COPY/ADD instruction.

        Mirrors Docker's COPY semantics:
        - Source is resolved relative to the environment (build context) directory.
        - Destination is resolved relative to copy_workdir when not absolute.
        - Directory sources: the *contents* are uploaded, not the directory itself,
          matching Docker's `COPY subdir/ /dest/` behaviour.
        - File sources: uploaded to dest, appending basename when dest ends with /.
        - Glob sources ("." or "./"): upload entire build context to dest.
        """
        # Preserve the original dest string to detect trailing slash BEFORE resolution.
        dest_is_dir_hint = dest.endswith("/") or dest in (".", "./")

        # Resolve dest against the workdir active at COPY time if it is relative.
        if not dest.startswith("/"):
            dest = str(PurePosixPath(copy_workdir) / dest)

        dest = dest.rstrip("/") or "/"

        src_clean = src.rstrip("/")
        src_path = self.environment_dir / src_clean

        if src in (".", "./"):
            # COPY . /dest → upload entire build context to dest
            await self.upload_dir(self.environment_dir, dest)
        elif src_path.is_dir():
            # COPY subdir/ /dest → upload the CONTENTS of subdir (not the dir itself).
            # This is the key difference from uploading environment_dir wholesale:
            # `COPY task-deps/ ./` must put model.pth at /app/model.pth,
            # not at /app/task-deps/model.pth.
            await self.upload_dir(src_path, dest)
        elif src_path.is_file():
            if dest_is_dir_hint:
                # COPY file.txt /dest/ → /dest/file.txt
                await self.exec(f"mkdir -p {shlex.quote(dest)}", cwd="/")
                remote_dest = f"{dest}/{src_path.name}"
            else:
                # COPY file.txt /dest — Docker semantics: if dest is an existing
                # directory in the sandbox, copy into it; otherwise use dest as the
                # exact target path (file rename).  We check the live sandbox state
                # rather than guessing from the path name, so patterns like
                # `COPY default.conf /etc/nginx/sites-available/default` work
                # correctly whether or not the path already exists.
                r = await self.exec(
                    f"test -d {shlex.quote(dest)} && echo dir || echo file",
                    cwd="/",
                )
                if (r.stdout or "").strip() == "dir":
                    remote_dest = f"{dest}/{src_path.name}"
                else:
                    remote_dest = dest
                    # Ensure the parent directory exists before uploading.
                    parent = str(PurePosixPath(dest).parent)
                    if parent != dest:
                        await self.exec(f"mkdir -p {shlex.quote(parent)}", cwd="/")
            await self.upload_file(src_path, remote_dest)
        else:
            self.logger.warning(
                f"COPY source not found in build context: {src!r} "
                f"(resolved: {src_path}) — skipping"
            )

    async def stop(self, delete: bool) -> None:
        if not delete:
            self.logger.info(
                f"Keeping sandbox alive. Sandbox ID: {self._sandbox_id}\n"
                f"Connect via: tl sbx ssh {self._sandbox_id}"
            )
            self._client_manager = None
            self._client = None
            return
        try:
            if self._sandbox_id is None:
                self.logger.warning("Sandbox not found. Please call start() first.")
            else:
                try:
                    await self._delete_sandbox()
                except Exception as e:
                    self.logger.error(f"Error deleting sandbox {self._sandbox_id}: {e}")
                finally:
                    try:
                        if self._sandbox is not None:
                            self._active_sandbox.close()
                    except Exception:
                        pass
                    self._sandbox = None
                    self._sandbox_id = None
        finally:
            self._client_manager = None
            self._client = None

    # ── Command execution ────────────────────────────────────────────────

    @retry(
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((RemoteAPIError, SandboxConnectionError)),
        reraise=True,
    )
    async def exec(
        self,
        command: str,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
        timeout_sec: int | None = None,
        user: str | int | None = None,
        discard_stdout: bool = False,
    ) -> ExecResult:
        self._assert_sandbox()
        user = self._resolve_user(user)
        env = self._merge_env(env)

        # Strip apt version pins (pkg=X.Y.Z-os1) from any apt install command.
        # This covers solve.sh oracle scripts that pin Ubuntu/Debian-specific versions
        # which do not exist in the sandbox's package repository.
        if re.search(r"\bapt(?:-get)?\s+install\b", command):
            command = re.sub(
                r"\b([a-z0-9][a-z0-9.+~-]*)=[a-zA-Z0-9.+~:_-]+", r"\1", command
            )

        # Build the command string carefully to handle environment variables and users.
        # Using 'export' ensures variables persist through compound commands (&&, ;).
        env_prefix = ""
        if env:
            exports = [f"export {k}={shlex.quote(v)}" for k, v in env.items()]
            env_prefix = "; ".join(exports) + "; "

        if user is not None:
            if isinstance(user, int):
                user_arg = f"$(getent passwd {user} | cut -d: -f1)"
            else:
                user_arg = shlex.quote(str(user))
            command = (
                f"{env_prefix}su {user_arg} -s /bin/bash -c {shlex.quote(command)}"
            )
        elif env:
            command = f"{env_prefix}{command}"

        target_cwd = cwd or self._workdir
        if timeout_sec:
            command = f"timeout {timeout_sec} bash -c {shlex.quote(command)}"
        if target_cwd:
            command = f"cd {shlex.quote(target_cwd)} && bash -c {shlex.quote(command)}"

        # Commands that pipe through tee already write their output to a file.
        # Capturing that same stream in TensorLake's in-memory buffer causes
        # SIGPIPE (exit 141) when the output is large (e.g. claude's verbose
        # JSON stream). Auto-discard stdout in this case so the sandbox daemon
        # never buffers the stream.
        if "| tee " in command:
            discard_stdout = True

        loop = asyncio.get_running_loop()
        try:
            result = await self._run_command_async(
                loop, command, discard_stdout=discard_stdout
            )
        except (RemoteAPIError, SandboxConnectionError) as e:
            self.logger.warning(
                f"TensorLake exec failed for sandbox {self._sandbox_id}, will retry: {e}"
            )
            raise
        return ExecResult(
            stdout=result.stdout,
            stderr=result.stderr or "",
            return_code=result.exit_code,
        )

    async def _run_command_async(
        self,
        loop: asyncio.AbstractEventLoop,
        command: str,
        discard_stdout: bool = False,
    ) -> CommandResult:
        """Run a bash command asynchronously, polling until completion.

        By default stdout is captured (OutputMode.CAPTURE) so callers can
        read command output (version detection, skill discovery, cat, echo,
        etc.).  Pass discard_stdout=True for commands known to produce large
        output that would overflow the sandbox daemon's in-memory buffer —
        specifically the long-running agent run command, whose stdout is
        already written to /logs/agent/*.txt via tee.

        sandbox.run() uses OutputMode.CAPTURE by default, which buffers all
        stdout in the sandbox daemon's memory. Commands that produce large
        output (e.g. claude's verbose JSON stream) can overflow this buffer,
        causing SIGPIPE (exit 141) inside the sandbox shell.  The agent run
        path avoids this by piping through tee and setting discard_stdout=True
        so the sandbox daemon never has to buffer the stream.

        Polling is done asynchronously: each get_process() call occupies a
        thread only for the HTTP round-trip (~ms). Between polls we yield back
        to the event loop via asyncio.sleep(), so concurrent trials don't
        exhaust the thread pool even when commands run for hours.

        CancelledError (raised when asyncio.wait_for fires on the trial
        timeout) is caught so we can kill the sandbox process before
        re-raising — otherwise the process keeps running inside the sandbox
        for the full 25-hour safety deadline.
        """
        proc = await loop.run_in_executor(
            None,
            lambda: self._active_sandbox.start_process(
                command="bash",
                args=["-lc", command],
                stdout_mode=OutputMode.DISCARD
                if discard_stdout
                else OutputMode.CAPTURE,
            ),
        )
        # Safety deadline: 25 hours — well beyond any legitimate task duration.
        deadline = loop.time() + 25 * 3600
        try:
            while True:
                info = await loop.run_in_executor(
                    None, lambda: self._active_sandbox.get_process(proc.pid)
                )
                if info.status != ProcessStatus.RUNNING:
                    break
                if loop.time() > deadline:
                    await loop.run_in_executor(
                        None, lambda: self._active_sandbox.kill_process(proc.pid)
                    )
                    raise RemoteAPIError(
                        0, "Process polling timed out — sandbox daemon may be stuck"
                    )
                await asyncio.sleep(0.1)
        except asyncio.CancelledError:
            # Trial timeout fired. Kill the sandbox process so it doesn't
            # keep running for the full 25-hour safety deadline, then
            # re-raise so the cancellation propagates normally.
            try:
                await loop.run_in_executor(
                    None, lambda: self._active_sandbox.kill_process(proc.pid)
                )
            except Exception:
                pass
            raise

        stderr_resp = await loop.run_in_executor(
            None, lambda: self._active_sandbox.get_stderr(proc.pid)
        )
        if not discard_stdout:
            stdout_resp = await loop.run_in_executor(
                None, lambda: self._active_sandbox.get_stdout(proc.pid)
            )
        else:
            stdout_resp = None

        if info.exit_code is not None:
            if info.exit_code == -1:
                # The sandbox daemon sometimes reports exit_code=-1 for a
                # process that has already exited normally (PTY cleanup),
                # independent of the SIGHUP signal path below.  Re-poll up
                # to 3 times to resolve the real exit code before treating
                # this as a transient error and letting exec() retry.
                for _attempt in range(3):
                    await asyncio.sleep(1.0)
                    try:
                        info = await loop.run_in_executor(
                            None,
                            lambda: self._active_sandbox.get_process(proc.pid),
                        )
                        if info.exit_code is not None and info.exit_code != -1:
                            exit_code = info.exit_code
                            break
                    except Exception:
                        pass
                else:
                    raise RemoteAPIError(
                        0,
                        "Process reported exit_code=-1 (sandbox daemon cleanup?)",
                    )
            else:
                exit_code = info.exit_code
        elif info.signal is not None:
            if info.signal == 1:
                # SIGHUP — the sandbox daemon closed the controlling terminal.
                # This can arrive during the polling loop for a process that
                # actually completed successfully: the daemon tears down the
                # pty and delivers SIGHUP *after* the process already exited.
                # Re-poll up to 3 times with a short back-off to check whether
                # a real exit code is now available before raising so the
                # exec() retry fires.
                for _attempt in range(3):
                    await asyncio.sleep(1.0)
                    try:
                        info = await loop.run_in_executor(
                            None, lambda: self._active_sandbox.get_process(proc.pid)
                        )
                        if info.exit_code is not None:
                            # -1 from the sandbox after SIGHUP means the PTY
                            # was cleaned up after the process already exited
                            # normally — map to 0 rather than propagating a
                            # spurious failure.
                            exit_code = 0 if info.exit_code == -1 else info.exit_code
                            break
                    except Exception:
                        pass
                else:
                    # Process still has no exit code after re-polling — treat
                    # as a transient connection drop and let exec() retry.
                    raise RemoteAPIError(
                        0, "Process killed by SIGHUP (sandbox connection drop?)"
                    )
            else:
                exit_code = -info.signal
        else:
            raise RemoteAPIError(
                0, "Process completed with indeterminate state (no exit code or signal)"
            )

        return CommandResult(
            exit_code=exit_code,
            stdout="\n".join(stdout_resp.lines) if stdout_resp is not None else "",
            stderr="\n".join(stderr_resp.lines),
        )

    # ── File operations ──────────────────────────────────────────────────

    @retry(
        stop=stop_after_attempt(2),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )
    async def upload_file(self, source_path: Path | str, target_path: str) -> None:
        self._assert_sandbox()
        data = Path(source_path).read_bytes()
        loop = asyncio.get_running_loop()
        if len(data) <= _UPLOAD_CHUNK_SIZE:
            await loop.run_in_executor(
                None, lambda: self._active_sandbox.write_file(target_path, data)
            )
        else:
            await self._upload_large_file(target_path, data)

    async def _upload_large_file(self, target_path: str, data: bytes) -> None:
        """Upload a large file in chunks via stdin to avoid HTTP 413 body-size errors."""
        loop = asyncio.get_running_loop()
        proc = await loop.run_in_executor(
            None,
            lambda: self._active_sandbox.start_process(
                command="bash",
                args=["-c", f"cat > {shlex.quote(target_path)}"],
                stdin_mode=StdinMode.PIPE,
                stdout_mode=OutputMode.DISCARD,
                stderr_mode=OutputMode.DISCARD,
            ),
        )
        try:
            for i in range(0, len(data), _UPLOAD_CHUNK_SIZE):
                chunk = data[i : i + _UPLOAD_CHUNK_SIZE]
                await loop.run_in_executor(
                    None, lambda c=chunk: self._active_sandbox.write_stdin(proc.pid, c)
                )
            await loop.run_in_executor(
                None, lambda: self._active_sandbox.close_stdin(proc.pid)
            )
            while True:
                info = await loop.run_in_executor(
                    None, lambda: self._active_sandbox.get_process(proc.pid)
                )
                if info.status != ProcessStatus.RUNNING:
                    break
                await asyncio.sleep(0.1)
            if info.exit_code != 0:
                raise RuntimeError(
                    f"Remote write to {target_path!r} failed with exit code {info.exit_code}"
                )
        except Exception:
            try:
                await loop.run_in_executor(
                    None, lambda: self._active_sandbox.kill_process(proc.pid)
                )
            except Exception:
                pass
            raise

    async def upload_dir(self, source_dir: Path | str, target_dir: str) -> None:
        self._assert_sandbox()
        source_dir = Path(source_dir)
        files = [p for p in source_dir.rglob("*") if p.is_file()]

        # Create all unique remote directories in a single exec call to avoid
        # one round-trip per file (which causes EnvironmentStartTimeoutError on
        # large directories).
        dirs = {target_dir} | {
            str(PurePosixPath(target_dir) / f.relative_to(source_dir).parent.as_posix())
            for f in files
        }
        await self.exec("mkdir -p " + " ".join(shlex.quote(d) for d in sorted(dirs)))

        for file_path in files:
            dest = str(
                PurePosixPath(target_dir) / file_path.relative_to(source_dir).as_posix()
            )
            await self.upload_file(file_path, dest)

    @retry(
        stop=stop_after_attempt(2),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )
    async def download_file(self, source_path: str, target_path: Path | str) -> None:
        self._assert_sandbox()
        loop = asyncio.get_running_loop()
        data = await loop.run_in_executor(
            None, lambda: self._active_sandbox.read_file(source_path)
        )
        target = Path(target_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(bytes(data))

    async def download_dir(self, source_dir: str, target_dir: Path | str) -> None:
        self._assert_sandbox()
        target_dir = Path(target_dir)
        target_dir.mkdir(parents=True, exist_ok=True)

        loop = asyncio.get_running_loop()
        listing = await loop.run_in_executor(
            None, lambda: self._active_sandbox.list_directory(source_dir)
        )

        for entry in listing.entries:
            remote_path = f"{source_dir.rstrip('/')}/{entry.name}"
            local_path = target_dir / entry.name
            if entry.is_dir:
                await self.download_dir(remote_path, local_path)
            else:
                await self.download_file(remote_path, local_path)

    # ── Interactive shell ─────────────────────────────────────────────────

    async def attach(self) -> None:
        """Open an interactive shell in the sandbox via the TensorLake CLI."""
        self._assert_sandbox()
        # `tl sbx ssh <id>` opens an interactive shell — equivalent to Daytona's SSH.
        assert self._sandbox_id is not None
        os.execvp("tl", ["tl", "sbx", "ssh", self._sandbox_id])
