import asyncio
import asyncio.subprocess
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

from pydantic import BaseModel

from harbor.environments.base import BaseEnvironment, ExecResult
from harbor.environments.capabilities import EnvironmentCapabilities
from harbor.environments.docker import (
    COMPOSE_BASE_PATH,
    COMPOSE_BUILD_PATH,
    COMPOSE_NO_NETWORK_PATH,
    COMPOSE_PREBUILT_PATH,
    COMPOSE_WINDOWS_KEEPALIVE_PATH,
)
from harbor.models.environment_type import EnvironmentType
from harbor.models.task.config import EnvironmentConfig, TaskOS
from harbor.models.trial.config import ServiceVolumeConfig
from harbor.models.trial.paths import EnvironmentPaths, TrialPaths
from harbor.utils.env import resolve_env_vars


def _sanitize_docker_image_name(name: str) -> str:
    """
    Sanitize a name to be a valid Docker image name.

    See: https://github.com/opencontainers/distribution-spec/blob/5e57cc0a07ea002e507a65d4757e823f133fcb52/spec.md#pulling-manifests
    """
    # Convert to lowercase
    name = name.lower()
    # If the first character is not alphanumeric, prepend '0'
    if not re.match(r"^[a-z0-9]", name):
        name = "0" + name
    # Replace any character that is not a-z, 0-9, ., _, - with -
    # Note: / is not allowed here because we want only one directory hierarchy.
    name = re.sub(r"[^a-z0-9._-]", "-", name)
    return name


def _sanitize_docker_compose_project_name(name: str) -> str:
    """
    Sanitize a name to be a valid Docker Compose project name.

    See: https://docs.docker.com/compose/how-tos/project-name/
    """
    # Convert to lowercase
    name = name.lower()
    # If the first character is not alphanumeric, prepend '0'
    if not re.match(r"^[a-z0-9]", name):
        name = "0" + name
    # Replace any character that is not a-z, 0-9, -, or _ with -
    name = re.sub(r"[^a-z0-9_-]", "-", name)
    return name


class DockerEnvironmentEnvVars(BaseModel):
    main_image_name: str
    context_dir: str
    host_verifier_logs_path: str
    host_agent_logs_path: str
    host_artifacts_path: str
    env_verifier_logs_path: str
    env_agent_logs_path: str
    env_artifacts_path: str
    prebuilt_image_name: str | None = None
    cpus: int = 1
    memory: str = "1G"

    def to_env_dict(self, include_os_env: bool = True) -> dict[str, str]:
        env_dict = {} if not include_os_env else os.environ.copy()

        for field_name, value in self.model_dump(exclude_none=True).items():
            if value is None:
                continue

            env_dict[f"{field_name.upper()}"] = str(value)

        return env_dict


class DockerEnvironment(BaseEnvironment):
    _DOCKER_COMPOSE_BASE_PATH = COMPOSE_BASE_PATH
    _DOCKER_COMPOSE_BUILD_PATH = COMPOSE_BUILD_PATH
    _DOCKER_COMPOSE_PREBUILT_PATH = COMPOSE_PREBUILT_PATH
    _DOCKER_COMPOSE_NO_NETWORK_PATH = COMPOSE_NO_NETWORK_PATH

    _DOCKER_COMPOSE_WINDOWS_KEEPALIVE_PATH = COMPOSE_WINDOWS_KEEPALIVE_PATH

    # Class-level lock per image name to prevent parallel builds of the same image.
    _image_build_locks: dict[str, asyncio.Lock] = {}

    @staticmethod
    def _detect_daemon_os() -> str | None:
        """Return the Docker daemon's OSType (e.g. 'linux' or 'windows'), or None on error."""
        try:
            result = subprocess.run(
                ["docker", "info", "--format", "{{.OSType}}"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            value = result.stdout.strip().lower()
            return value or None
        except Exception:
            return None

    @staticmethod
    def _detect_windows_containers() -> bool:
        """Detect if Docker is running in Windows container mode.

        Retained for back-compat with existing test fixtures.  New code should
        rely on :attr:`task_os` derived from ``task.toml``'s ``[environment].os``
        field; this helper is now used only for daemon-mode validation.
        """
        if sys.platform != "win32":
            return False
        return DockerEnvironment._detect_daemon_os() == "windows"

    @classmethod
    def preflight(cls) -> None:
        if not shutil.which("docker"):
            raise SystemExit(
                "Docker is not installed or not on PATH. "
                "Please install Docker and try again."
            )
        try:
            subprocess.run(
                ["docker", "info"],
                capture_output=True,
                timeout=10,
                check=True,
            )
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            raise SystemExit(
                "Docker daemon is not running. Please start Docker and try again."
            )

    def __init__(
        self,
        environment_dir: Path,
        environment_name: str,
        session_id: str,
        trial_paths: TrialPaths,
        task_env_config: EnvironmentConfig,
        keep_containers: bool = False,
        mounts_json: list[ServiceVolumeConfig] | None = None,
        *args,
        **kwargs,
    ):
        super().__init__(
            environment_dir=environment_dir,
            environment_name=environment_name,
            session_id=session_id,
            trial_paths=trial_paths,
            task_env_config=task_env_config,
            **kwargs,
        )

        self._keep_containers = keep_containers
        self._is_windows_container = task_env_config.os == TaskOS.WINDOWS
        self._env_paths = (
            EnvironmentPaths.for_windows()
            if self._is_windows_container
            else EnvironmentPaths()
        )
        self._mounts_json = mounts_json
        self._mounts_compose_path: Path | None = None

        # Select the platform-specific file-transfer and exec helpers.
        if self._is_windows_container:
            import uuid

            from harbor.environments.docker.docker_windows import WindowsOps

            self._windows_container_name = f"harbor-{uuid.uuid4().hex[:12]}"
            self._platform = WindowsOps(self, self._windows_container_name)
        else:
            from harbor.environments.docker.docker_unix import UnixOps

            self._windows_container_name: str | None = None
            self._platform = UnixOps(self)

        self._env_vars = DockerEnvironmentEnvVars(
            main_image_name=_sanitize_docker_image_name(f"hb__{environment_name}"),
            context_dir=str(self.environment_dir.resolve().absolute()),
            host_verifier_logs_path=trial_paths.verifier_dir.resolve()
            .absolute()
            .as_posix(),
            host_agent_logs_path=trial_paths.agent_dir.resolve().absolute().as_posix(),
            host_artifacts_path=trial_paths.artifacts_dir.resolve()
            .absolute()
            .as_posix(),
            env_verifier_logs_path=str(self._env_paths.verifier_dir),
            env_agent_logs_path=str(self._env_paths.agent_dir),
            env_artifacts_path=str(self._env_paths.artifacts_dir),
            prebuilt_image_name=task_env_config.docker_image,
            cpus=task_env_config.cpus,
            memory=f"{task_env_config.memory_mb}M",
        )
        self._use_prebuilt = False

        self._compose_task_env: dict[str, str] = {}
        if task_env_config.env and self._uses_compose:
            self._compose_task_env = resolve_env_vars(task_env_config.env)

        resolved_task_keys = set(self._compose_task_env.keys()) | set(
            self._persistent_env.keys()
        )
        if resolved_task_keys:
            harbor_keys = set(self._env_vars.to_env_dict(include_os_env=False).keys())
            collisions = harbor_keys & resolved_task_keys
            if collisions:
                self.logger.warning(
                    "Environment vars override Harbor compose variable(s): %s",
                    ", ".join(sorted(collisions)),
                )

    @staticmethod
    def type() -> EnvironmentType:
        return EnvironmentType.DOCKER

    @property
    def env_paths(self) -> EnvironmentPaths:
        return self._env_paths

    @property
    def _uses_compose(self) -> bool:
        return self._environment_docker_compose_path.exists()

    @property
    def capabilities(self) -> EnvironmentCapabilities:
        return EnvironmentCapabilities(
            disable_internet=True,
            windows=True,
            mounted=True,
        )

    @property
    def _dockerfile_path(self) -> Path:
        return self.environment_dir / "Dockerfile"

    @property
    def _environment_docker_compose_path(self) -> Path:
        return self.environment_dir / "docker-compose.yaml"

    @property
    def _docker_compose_paths(self) -> list[Path]:
        """
        Returns the docker-compose file(s) to use.

        Two options for task authors:

        Option 1: Simple task (just Dockerfile)
        - No docker-compose needed
        - Uses: base + build/prebuilt

        Option 2: Task with extra services (docker-compose.yaml)
        - Create docker-compose.yaml with additional services or overrides
        - Uses: base + build/prebuilt + docker-compose.yaml
        - Task file is last so it can override scalars from build/prebuilt
        - Relative paths (e.g. build context) resolve relative to the file
          where they are defined, regardless of -f order

        For Windows-container tasks, a keepalive override is inserted between
        build/prebuilt and the task's own docker-compose.yaml. This lets the
        keepalive override the Linux `tail -f /dev/null` baked into
        build/prebuilt, while still allowing a Windows task's own compose
        file to override the keepalive command if it needs a different
        long-running process.

        When allow_internet is False, the no-network compose file is appended
        last to set network_mode: none on the main service.
        """
        build_or_prebuilt = (
            self._DOCKER_COMPOSE_PREBUILT_PATH
            if self._use_prebuilt
            else self._DOCKER_COMPOSE_BUILD_PATH
        )

        paths = [self._DOCKER_COMPOSE_BASE_PATH, build_or_prebuilt]

        if self._is_windows_container:
            paths.append(self._DOCKER_COMPOSE_WINDOWS_KEEPALIVE_PATH)

        if self._environment_docker_compose_path.exists():
            paths.append(self._environment_docker_compose_path)

        if self._mounts_compose_path:
            paths.append(self._mounts_compose_path)

        if not self.task_env_config.allow_internet:
            paths.append(self._DOCKER_COMPOSE_NO_NETWORK_PATH)

        return paths

    def _write_mounts_compose_file(self) -> Path:
        """Write a docker-compose override file with additional volume mounts."""
        compose = {"services": {"main": {"volumes": self._mounts_json}}}
        path = self.trial_paths.trial_dir / "docker-compose-mounts.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(compose, indent=2))
        return path

    def _validate_definition(self):
        if (
            not self._dockerfile_path.exists()
            and not self._environment_docker_compose_path.exists()
        ):
            raise FileNotFoundError(
                f"{self._dockerfile_path} and {self._environment_docker_compose_path} "
                "not found. Please ensure at least one of these files exist."
            )

    async def _run_docker_compose_command(
        self, command: list[str], check: bool = True, timeout_sec: int | None = None
    ) -> ExecResult:
        """Run a docker compose command and return the result."""
        full_command = [
            "docker",
            "compose",
            "--project-name",
            _sanitize_docker_compose_project_name(self.session_id),
            "--project-directory",
            str(self.environment_dir.resolve().absolute()),
        ]
        for path in self._docker_compose_paths:
            full_command.extend(["-f", str(path.resolve().absolute())])
        full_command.extend(command)

        env = self._env_vars.to_env_dict(include_os_env=True)
        if self._compose_task_env:
            env.update(self._compose_task_env)
        if self._persistent_env:
            env.update(self._persistent_env)
        # Inject after user env so it cannot be accidentally overridden.
        if self._windows_container_name:
            env["HARBOR_CONTAINER_NAME"] = self._windows_container_name

        process = await asyncio.create_subprocess_exec(
            *full_command,
            env=env,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )

        try:
            if timeout_sec:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    process.communicate(), timeout=timeout_sec
                )
            else:
                stdout_bytes, stderr_bytes = await process.communicate()
        except asyncio.TimeoutError:
            process.terminate()
            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    process.communicate(), timeout=5
                )
            except asyncio.TimeoutError:
                process.kill()
                stdout_bytes, stderr_bytes = await process.communicate()
            raise RuntimeError(f"Command timed out after {timeout_sec} seconds")

        stdout = stdout_bytes.decode(errors="replace") if stdout_bytes else None
        stderr = stderr_bytes.decode(errors="replace") if stderr_bytes else None

        result = ExecResult(
            stdout=stdout,
            stderr=stderr,
            return_code=process.returncode or 0,
        )

        if check and result.return_code != 0:
            raise RuntimeError(
                f"Docker compose command failed for environment {self.environment_name}. "
                f"Command: {' '.join(full_command)}. "
                f"Return code: {result.return_code}. "
                f"Stdout: {result.stdout}. "
                f"Stderr: {result.stderr}. "
            )

        return result

    def _validate_daemon_mode(self) -> None:
        """Verify the Docker daemon mode matches the task's declared OS.

        Raises ``RuntimeError`` with remediation guidance when the task
        targets Windows but Docker Desktop is in Linux container mode (or
        vice versa), or when a Windows task is launched on a non-Windows
        host.
        """
        if self._is_windows_container and sys.platform != "win32":
            raise RuntimeError(
                "Task declares [environment].os = 'windows' but the host is "
                f"not Windows ({sys.platform!r}). Windows containers require "
                "a Windows host with Docker Desktop in Windows container mode."
            )

        daemon_os = self._detect_daemon_os()
        if daemon_os is None:
            # Could not query the daemon; defer to docker compose to error.
            return

        expected = "windows" if self._is_windows_container else "linux"
        if daemon_os != expected:
            switch_to = "Windows" if expected == "windows" else "Linux"
            raise RuntimeError(
                f"Task declares [environment].os = {expected!r} but the Docker "
                f"daemon is running in {daemon_os!r} container mode. "
                f"Switch Docker Desktop to {switch_to} containers "
                "(right-click the system tray icon → 'Switch to "
                f"{switch_to} containers...') and try again."
            )

    async def _validate_image_os(self, image_name: str) -> None:
        """Verify the Docker image's OS matches the task's declared OS.

        Runs ``docker inspect --format "{{.Os}}" <image>`` and raises
        ``RuntimeError`` on mismatch.  Silently skipped when the image cannot
        be inspected (e.g. not yet pulled in unusual edge cases).
        """
        try:
            result = await asyncio.create_subprocess_exec(
                "docker",
                "inspect",
                "--format",
                "{{.Os}}",
                image_name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await result.communicate()
        except Exception as e:
            self.logger.debug(f"Skipping image OS validation for {image_name}: {e}")
            return

        if result.returncode != 0:
            self.logger.debug(
                f"Skipping image OS validation for {image_name}: "
                f"docker inspect returned {result.returncode}"
            )
            return

        image_os = stdout.decode("utf-8", errors="replace").strip().lower()
        expected = "windows" if self._is_windows_container else "linux"
        if image_os and image_os != expected:
            raise RuntimeError(
                f"Task declares [environment].os = {expected!r} but Docker image "
                f"{image_name!r} reports OS {image_os!r}. Use a "
                f"{expected}-compatible base image, or update [environment].os "
                "in task.toml to match the image."
            )

    async def start(self, force_build: bool):
        if self._mounts_json:
            self._mounts_compose_path = self._write_mounts_compose_file()

        self._use_prebuilt = not force_build and self.task_env_config.docker_image

        # Fail fast if the daemon mode disagrees with the task's declared OS.
        self._validate_daemon_mode()

        if not self._use_prebuilt:
            # Serialize image builds: if multiple environments with the same image name
            # start concurrently, only one builds while others wait for the cached image.
            lock = self._image_build_locks.setdefault(
                self.environment_name, asyncio.Lock()
            )
            async with lock:
                await self._run_docker_compose_command(["build"])

        # Validate image OS after build/pull but before container start.
        image_to_check = (
            self.task_env_config.docker_image
            if self._use_prebuilt
            else self._env_vars.main_image_name
        )
        if image_to_check:
            await self._validate_image_os(image_to_check)

        # Remove any stale containers from previous runs with the same session ID.
        try:
            await self._run_docker_compose_command(["down", "--remove-orphans"])
        except RuntimeError:
            pass

        await self._run_docker_compose_command(["up", "--detach", "--wait"])

        # Make log directories world-writable so non-root agent/verifier
        # users can write to them.  (No-op for Windows containers which do
        # not use Unix file permissions.)
        if not self._is_windows_container:
            await self.exec(
                f"chmod 777 {self._env_paths.agent_dir} {self._env_paths.verifier_dir}"
            )

    async def prepare_logs_for_host(self) -> None:
        """Chown the bind-mounted logs directory to the host user.

        On Linux, files created inside the container are owned by the agent
        UID.  The host process (which may run as a different UID) cannot read
        them until ownership is corrected.  This is a no-op on macOS/Windows
        where Docker Desktop's VM layer handles ownership transparently.
        """
        try:
            await self._chown_to_host_user(
                str(self._env_paths.logs_dir), recursive=True
            )
        except Exception as e:
            self.logger.warning(f"Failed to chown logs directory: {e}")

    async def stop(self, delete: bool):
        # Best-effort: fix ownership of bind-mounted directories so the host
        # user can read/write/delete them after the container is gone.
        await self.prepare_logs_for_host()

        if self._keep_containers and delete:
            self.logger.warning(
                "Both `keep_containers` and `--delete` option are set. "
                "keep_containers takes precedence."
            )
        if self._keep_containers:
            try:
                await self._run_docker_compose_command(["stop"])
            except Exception as e:
                self.logger.warning(f"Docker compose stop failed: {e}")
        elif delete:
            try:
                await self._run_docker_compose_command(
                    ["down", "--rmi", "all", "--volumes", "--remove-orphans"]
                )
            except Exception as e:
                self.logger.warning(f"Docker compose down failed: {e}")
        else:
            try:
                await self._run_docker_compose_command(["down"])
            except Exception as e:
                self.logger.warning(f"Docker compose down failed: {e}")

    async def upload_file(self, source_path: Path | str, target_path: str):
        await self._platform.upload_file(source_path, target_path)

    async def upload_dir(self, source_dir: Path | str, target_dir: str):
        await self._platform.upload_dir(source_dir, target_dir)

    async def _chown_to_host_user(self, path: str, recursive: bool = False) -> None:
        """Best-effort chown of a container path to the host user's UID:GID.

        No-op on Windows (where os.getuid/os.getgid are unavailable).
        """
        if not hasattr(os, "getuid"):
            return
        flag = "-R " if recursive else ""
        await self.exec(
            f"chown {flag}{os.getuid()}:{os.getgid()} {shlex.quote(path)}", user="root"
        )

    async def download_file(self, source_path: str, target_path: Path | str):
        await self._platform.download_file(source_path, target_path)

    async def download_dir(self, source_dir: str, target_dir: Path | str):
        await self._platform.download_dir(source_dir, target_dir)

    async def exec(
        self,
        command: str,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
        timeout_sec: int | None = None,
        user: str | int | None = None,
    ) -> ExecResult:
        user = self._resolve_user(user)
        env = self._merge_env(env)

        exec_command = ["exec"]

        effective_cwd = cwd or self.task_env_config.workdir
        if effective_cwd:
            exec_command.extend(["-w", effective_cwd])

        if env:
            for key, value in env.items():
                exec_command.extend(["-e", f"{key}={value}"])

        if user is not None:
            exec_command.extend(["-u", str(user)])

        exec_command.append("main")
        exec_command.extend(self._platform.exec_shell_args(command))

        return await self._run_docker_compose_command(
            exec_command, check=False, timeout_sec=timeout_sec
        )

    async def attach(self) -> None:
        if self._is_windows_container:
            raise NotImplementedError(
                "Interactive attach is not yet supported for Windows containers."
            )

        variables = " ".join(
            f"export {k}={shlex.quote(str(v))}"
            for k, v in self._env_vars.to_env_dict(include_os_env=False).items()
        )

        # Build the -f flags for docker compose
        compose_file_args = []
        for path in self._docker_compose_paths:
            compose_file_args.extend(
                ["-f", shlex.quote(str(path.resolve().absolute()))]
            )

        project_name = _sanitize_docker_compose_project_name(self.session_id)
        compose_base = [
            "docker",
            "compose",
            "--project-name",
            project_name,
        ] + compose_file_args

        os.execvp(
            "bash",
            [
                "bash",
                "-c",
                f"{variables}; "
                + " ".join(compose_base + ["exec", "-it", "main", "bash"])
                + "; "
                + " ".join(compose_base + ["down"]),
            ],
        )
