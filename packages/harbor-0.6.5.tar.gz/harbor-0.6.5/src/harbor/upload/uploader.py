"""Core orchestrator for uploading job results to Supabase."""

import asyncio
import logging
import tarfile
import time
from collections.abc import Callable
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Any
from uuid import UUID

from pydantic import BaseModel

from harbor.db.types import PublicJobVisibility
from harbor.models.job.config import JobConfig
from harbor.models.job.result import JobResult
from harbor.models.trial.result import TrialResult
from harbor.upload.db_client import UploadDB
from harbor.upload.storage import UploadStorage

logger = logging.getLogger(__name__)


class TrialUploadResult(BaseModel):
    trial_name: str
    task_name: str
    reward: float | int | None = None
    archive_size_bytes: int = 0
    upload_time_sec: float = 0.0
    skipped: bool = False
    error: str | None = None


class JobStartResult(BaseModel):
    """Result of :meth:`Uploader.start_job`.

    Carries the caches the streaming-upload hook handler needs for each
    per-trial upload (so it doesn't re-upsert agent/model per trial) and a
    sentinel indicating whether the row existed server-side already.
    """

    job_id: UUID
    visibility: PublicJobVisibility
    already_existed: bool
    shared_orgs: list[str] = []
    shared_users: list[str] = []
    # agent_cache: (name, version) -> agent_id
    agent_cache: dict[tuple[str, str], str] = {}
    # model_cache: (name, provider) -> model_id. Provider is None when the
    # user ran with a bare model name (no "<provider>/" prefix) — the cache
    # key has to preserve that distinction so a user running both
    # `-m gpt-5.4` and `-m openai/gpt-5.4` in the same job doesn't collide
    # into one cache entry.
    model_cache: dict[tuple[str, str | None], str] = {}


class JobUploadResult(BaseModel):
    job_name: str
    job_id: str
    visibility: PublicJobVisibility
    shared_orgs: list[str] = []
    shared_users: list[str] = []
    job_already_existed: bool = False
    n_trials_uploaded: int = 0
    n_trials_skipped: int = 0
    n_trials_failed: int = 0
    total_time_sec: float = 0.0
    trial_results: list[TrialUploadResult] = []


# Allowlist of entries included in each archive. Everything else in the
# directory is intentionally left out — random scratch files, editor
# metadata, or secrets a user happens to drop in the job_dir don't leak into
# shared artifacts. A missing entry is silently skipped (most are optional).
#
# Per-trial archive: self-contained trial subdir. Consumed by the viewer UI
# (artifact browser) and by `harbor trial download`.
_TRIAL_ARCHIVE_INCLUDES: tuple[str, ...] = (
    "config.json",
    "result.json",
    "analysis.md",
    "agent",
    "verifier",
    "artifacts",
    "trial.log",
    "exception.txt",
)

# Per-step archive entries under ``steps/{step_name}/``. Multi-step trials
# may leave other task/setup files under the step tree; only runtime outputs
# should be uploaded as trial artifacts.
_STEP_ARCHIVE_INCLUDES: tuple[str, ...] = (
    "agent",
    "verifier",
    "artifacts",
)

# Per-job archive: job-level allowlist + every trial subdir, each filtered
# through `_TRIAL_ARCHIVE_INCLUDES`. Consumed by `harbor job download`.
_JOB_ARCHIVE_INCLUDES: tuple[str, ...] = (
    "config.json",
    "lock.json",
    "result.json",
    "analysis.md",
    "job.log",
)


class Uploader:
    def __init__(self) -> None:
        self.db = UploadDB()
        self.storage = UploadStorage()
        self._agent_cache_lock = asyncio.Lock()
        self._model_cache_lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # Streaming primitives
    # ------------------------------------------------------------------
    #
    # `upload_job` below composes these three for the standalone CLI.
    # `harbor run --upload` uses them individually:
    #   1. `start_job(...)` at run start — inserts the job row with
    #      `archive_path=NULL` and primes the agent/model caches.
    #   2. `upload_single_trial(...)` registered as a `TrialEvent.END` hook —
    #      runs once per trial as they finish, in parallel with the next
    #      trial's work.
    #   3. `finalize_job(...)` at run end — builds the job archive, uploads
    #      it, writes `archive_path` + `finished_at` onto the row.
    # A crash between 1 and 3 leaves the row in "in-progress" state
    # (archive_path NULL); `harbor upload <job_dir>` later is an idempotent
    # sweep that fills any missing trials and finalizes if needed.

    async def start_job(
        self,
        *,
        job_id: UUID,
        job_name: str,
        started_at: datetime,
        config: dict[str, Any],
        visibility: PublicJobVisibility | None = None,
        share_orgs: list[str] | None = None,
        share_users: list[str] | None = None,
        confirm_non_member_orgs: bool = False,
        n_planned_trials: int | None = None,
    ) -> JobStartResult:
        """Insert the job row (or detect an existing one) from an explicit
        spec — no disk reads.

        The spec-based signature lets `harbor run --upload` call this before
        the run produces any ``result.json`` files. The standalone
        ``upload_job`` path reads ``result.json`` + ``config.json`` itself
        and then calls this with the extracted fields.

        ``archive_path`` / ``finished_at`` / ``log_path`` are left ``NULL`` —
        :meth:`finalize_job` writes them at end-of-run. The returned caches
        start empty; :meth:`_upload_single_trial` lazily upserts agents +
        models as it sees them.

        Visibility rules:
        - ``None`` + new row → default ``"private"``
        - ``None`` + existing row → keep server value
        - explicit + existing row → ``update_job_visibility`` if different
        """
        await self.db.get_user_id()  # auth check

        existing_visibility = await self.db.get_job_visibility(job_id)
        already_existed = existing_visibility is not None

        if not already_existed:
            effective_visibility: PublicJobVisibility = visibility or "private"
            await self.db.insert_job(
                id=job_id,
                job_name=job_name,
                started_at=started_at,
                finished_at=None,  # filled by finalize_job
                config=config,
                log_path=None,  # filled by finalize_job
                archive_path=None,  # filled by finalize_job
                visibility=effective_visibility,
                n_planned_trials=n_planned_trials,
            )
        else:
            assert existing_visibility is not None
            if visibility is not None and visibility != existing_visibility:
                await self.db.update_job_visibility(job_id, visibility)
                effective_visibility = visibility
                logger.debug(
                    "Job %s already existed; flipped visibility %s → %s.",
                    job_id,
                    existing_visibility,
                    visibility,
                )
            else:
                effective_visibility = existing_visibility

        shared_orgs: list[str] = []
        shared_users: list[str] = []
        if share_orgs or share_users:
            shares = await self.db.add_job_shares(
                job_id=job_id,
                org_names=share_orgs or [],
                usernames=share_users or [],
                confirm_non_member_orgs=confirm_non_member_orgs,
            )
            shared_orgs = [
                str(org.get("name"))
                for org in shares.get("orgs", [])
                if isinstance(org, dict) and org.get("name")
            ]
            shared_users = [
                str(user.get("github_username") or user.get("id"))
                for user in shares.get("users", [])
                if isinstance(user, dict)
                and (user.get("github_username") or user.get("id"))
            ]

        return JobStartResult(
            job_id=job_id,
            visibility=effective_visibility,
            already_existed=already_existed,
            shared_orgs=shared_orgs,
            shared_users=shared_users,
            agent_cache={},
            model_cache={},
        )

    async def upload_single_trial(
        self,
        *,
        trial_result: TrialResult,
        trial_dir: Path | None,
        job_id: UUID,
        agent_cache: dict[tuple[str, str], str],
        model_cache: dict[tuple[str, str | None], str],
    ) -> TrialUploadResult:
        """Upload one trial's archive + trajectory and insert its DB rows.

        Public API so `harbor run --upload`'s `on_trial_ended` hook can call
        it directly. Idempotent: returns ``skipped=True`` if the trial row
        already exists server-side (another hook fired, or a previous
        streaming run already persisted this trial).
        """
        return await self._upload_single_trial(
            trial_result=trial_result,
            trial_dir=trial_dir,
            job_id=job_id,
            agent_cache=agent_cache,
            model_cache=model_cache,
        )

    async def finalize_job(
        self,
        job_dir: Path,
        *,
        job_result: JobResult,
        job_config: JobConfig,
    ) -> None:
        """Build + upload the job archive and write the completion fields.

        Called once at end-of-run (streaming) or after all per-trial uploads
        complete (batch `upload_job`). Idempotency at this level is the
        caller's responsibility — the idempotent-sweep in :meth:`upload_job`
        only calls this when the server row still has ``archive_path=NULL``.
        """
        log_path: str | None = None
        job_log = job_dir / "job.log"
        if job_log.exists():
            log_path = f"jobs/{job_result.id}/job.log"
            await self.storage.upload_large_file(
                job_log,
                log_path,
                content_type="text/plain",
            )

        archive_path = f"jobs/{job_result.id}/job.tar.gz"
        local_archive_path = job_dir / ".harbor-upload" / "job.tar.gz"
        upload_url_path = local_archive_path.with_suffix(
            local_archive_path.suffix + ".tus-url"
        )
        if not (local_archive_path.exists() and upload_url_path.exists()):
            upload_url_path.unlink(missing_ok=True)
            _create_job_archive_file(job_dir, local_archive_path)
        await self.storage.upload_large_file(
            local_archive_path,
            archive_path,
            content_type="application/gzip",
        )

        await self.db.finalize_job(
            job_result.id,
            archive_path=archive_path,
            log_path=log_path,
            finished_at=job_result.finished_at or datetime.now(),
        )
        local_archive_path.unlink(missing_ok=True)
        upload_url_path.unlink(missing_ok=True)
        try:
            local_archive_path.parent.rmdir()
        except OSError:
            pass

    # ------------------------------------------------------------------
    # Top-level orchestrator (idempotent sweep)
    # ------------------------------------------------------------------

    async def upload_job(
        self,
        job_dir: Path,
        *,
        visibility: PublicJobVisibility | None = None,
        share_orgs: list[str] | None = None,
        share_users: list[str] | None = None,
        confirm_non_member_orgs: bool = False,
        max_concurrency: int = 10,
        on_trial_start: Callable[[TrialResult], None] | None = None,
        on_trial_complete: Callable[[TrialResult, TrialUploadResult], None]
        | None = None,
    ) -> JobUploadResult:
        """Upload a ``job_dir`` to Supabase — idempotent end-to-end.

        This is the public entry point for both:

        * **First-time upload** (standalone ``harbor upload``) — inserts the
          row, uploads every trial, uploads the job archive, finalizes.
        * **Resume after crash / streaming finalize** — detects existing
          server state, uploads only the trials that aren't already there,
          finalizes only if the row's ``archive_path`` is still ``NULL``.

        Re-running always converges to "complete upload."

        Visibility semantics (unchanged):
        * ``visibility=None`` → new jobs default to private; existing untouched.
        * ``visibility="public"``/``"private"`` → always applied, updated if
          the existing row's value differs.
        """
        t0 = time.monotonic()

        job_result, job_config, trial_results, trial_dirs = _load_job_from_disk(job_dir)

        start = await self.start_job(
            job_id=job_result.id,
            job_name=job_config.job_name,
            started_at=job_result.started_at,
            config=job_config.model_dump(mode="json"),
            visibility=visibility,
            share_orgs=share_orgs,
            share_users=share_users,
            confirm_non_member_orgs=confirm_non_member_orgs,
            n_planned_trials=job_result.n_total_trials,
        )

        # Eagerly upsert agents + models on the batch path. Streaming relies
        # on the per-trial lazy upsert in `_upload_single_trial`; here we
        # know the full trial set up front so this saves N round-trips on
        # the hot path.
        agent_cache, model_cache = await self._upsert_dimensions(trial_results)
        start.agent_cache.update(agent_cache)
        start.model_cache.update(model_cache)

        # Resume path: skip trials that already exist on the server so a
        # re-run after a partial streaming upload doesn't double-write.
        existing_trial_ids: set[UUID] = set()
        if start.already_existed:
            existing_trial_ids = await self.db.list_trial_ids_for_job(start.job_id)

        # Concurrent per-trial uploads. The `_upload_single_trial` body
        # double-checks existence via `trial_exists` so two concurrent
        # resume flows don't collide — the list-then-upload gap is purely
        # an optimization, not a correctness boundary.
        sem = asyncio.Semaphore(max_concurrency)

        async def _upload_trial(tr: TrialResult) -> TrialUploadResult:
            async with sem:
                if on_trial_start:
                    on_trial_start(tr)
                if tr.id in existing_trial_ids:
                    result = TrialUploadResult(
                        trial_name=tr.trial_name,
                        task_name=tr.task_name,
                        reward=_extract_primary_reward(tr),
                        skipped=True,
                    )
                else:
                    result = await self._upload_single_trial(
                        trial_result=tr,
                        trial_dir=trial_dirs.get(tr.trial_name),
                        job_id=start.job_id,
                        agent_cache=start.agent_cache,
                        model_cache=start.model_cache,
                    )
                if on_trial_complete:
                    on_trial_complete(tr, result)
                return result

        async with asyncio.TaskGroup() as tg:
            tasks = [tg.create_task(_upload_trial(tr)) for tr in trial_results]

        trial_upload_results = [t.result() for t in tasks]

        # Finalize only if the server row doesn't already have a job archive.
        # Covers: fresh upload (always finalize) + streaming finalize (row
        # exists with archive_path=NULL → finalize) + completed re-upload
        # (row exists with archive_path set → skip).
        remote = await self.db.get_job(start.job_id)
        if remote is not None and remote.get("archive_path") is None:
            await self.finalize_job(
                job_dir, job_result=job_result, job_config=job_config
            )

        elapsed = time.monotonic() - t0
        return JobUploadResult(
            job_name=job_config.job_name,
            job_id=str(start.job_id),
            visibility=start.visibility,
            shared_orgs=start.shared_orgs,
            shared_users=start.shared_users,
            job_already_existed=start.already_existed,
            n_trials_uploaded=sum(
                1 for r in trial_upload_results if not r.skipped and r.error is None
            ),
            n_trials_skipped=sum(1 for r in trial_upload_results if r.skipped),
            n_trials_failed=sum(1 for r in trial_upload_results if r.error is not None),
            total_time_sec=elapsed,
            trial_results=trial_upload_results,
        )

    async def _upsert_dimensions(
        self, trial_results: list[TrialResult]
    ) -> tuple[
        dict[tuple[str, str], str],
        dict[tuple[str, str | None], str],
    ]:
        """Eagerly upsert every agent + model referenced by these trials.

        Returns caches keyed by identity tuples so the per-trial upload path
        can skip the lookup on the hot path. Model cache key preserves
        ``provider=None`` as a distinct identity (see ``JobStartResult``).
        """
        agent_cache: dict[tuple[str, str], str] = {}
        model_cache: dict[tuple[str, str | None], str] = {}
        for tr in trial_results:
            agent_key = (tr.agent_info.name, tr.agent_info.version)
            if agent_key not in agent_cache:
                agent_cache[agent_key] = await self.db.upsert_agent(
                    tr.agent_info.name, tr.agent_info.version
                )
            if tr.agent_info.model_info is not None:
                model_key = (
                    tr.agent_info.model_info.name,
                    tr.agent_info.model_info.provider,
                )
                if model_key not in model_cache:
                    model_cache[model_key] = await self.db.upsert_model(
                        tr.agent_info.model_info.name,
                        tr.agent_info.model_info.provider,
                    )
        return agent_cache, model_cache

    async def _upload_single_trial(
        self,
        *,
        trial_result: TrialResult,
        trial_dir: Path | None,
        job_id: UUID,
        agent_cache: dict[tuple[str, str], str],
        model_cache: dict[tuple[str, str | None], str],
    ) -> TrialUploadResult:
        primary_reward = _extract_primary_reward(trial_result)

        try:
            # Idempotency: skip if trial already uploaded
            if await self.db.trial_exists(trial_result.id):
                return TrialUploadResult(
                    trial_name=trial_result.trial_name,
                    task_name=trial_result.task_name,
                    reward=primary_reward,
                    skipped=True,
                )

            t0 = time.monotonic()
            archive_path: str | None = None
            trajectory_path: str | None = None
            archive_size = 0

            if trial_dir is not None:
                # Create and upload trial archive
                archive_bytes = _create_trial_archive(trial_dir)
                archive_size = len(archive_bytes)
                archive_path = f"trials/{trial_result.id}/trial.tar.gz"
                await self.storage.upload_bytes(archive_bytes, archive_path)

                # Upload trajectory separately for direct access
                traj_file = trial_dir / "agent" / "trajectory.json"
                if traj_file.exists():
                    direct_trajectory_path = f"trials/{trial_result.id}/trajectory.json"
                    try:
                        await self.storage.upload_file(
                            traj_file, direct_trajectory_path
                        )
                    except Exception as exc:
                        # The trial archive already contains agent/trajectory.json,
                        # so a failed direct upload should degrade access to the
                        # convenience path rather than poison the whole trial upload.
                        logger.debug(
                            "Failed to upload direct trajectory for trial %s; "
                            "continuing with archive only: %s: %s",
                            trial_result.trial_name,
                            type(exc).__name__,
                            exc,
                        )
                    else:
                        trajectory_path = direct_trajectory_path

            # Upsert the agent if we haven't seen this (name, version) pair
            # yet. This lazy path matters for the streaming flow — hooks see
            # trials one at a time and the cache is initially empty; the
            # batch flow pre-populates the cache via _upsert_dimensions.
            agent_key = (
                trial_result.agent_info.name,
                trial_result.agent_info.version,
            )
            async with self._agent_cache_lock:
                if agent_key not in agent_cache:
                    agent_cache[agent_key] = await self.db.upsert_agent(
                        trial_result.agent_info.name, trial_result.agent_info.version
                    )
                agent_id = agent_cache[agent_key]

            await self.db.insert_trial(
                id=trial_result.id,
                trial_name=trial_result.trial_name,
                task_name=trial_result.task_name,
                task_content_hash=trial_result.task_checksum,
                job_id=job_id,
                agent_id=agent_id,
                started_at=trial_result.started_at,
                finished_at=trial_result.finished_at,
                config=trial_result.config.model_dump(mode="json"),
                rewards=(
                    trial_result.verifier_result.rewards
                    if trial_result.verifier_result
                    else None
                ),
                exception_type=(
                    trial_result.exception_info.exception_type
                    if trial_result.exception_info
                    else None
                ),
                archive_path=archive_path,
                trajectory_path=trajectory_path,
                environment_setup_started_at=_timing_field(
                    trial_result.environment_setup, "started_at"
                ),
                environment_setup_finished_at=_timing_field(
                    trial_result.environment_setup, "finished_at"
                ),
                agent_setup_started_at=_timing_field(
                    trial_result.agent_setup, "started_at"
                ),
                agent_setup_finished_at=_timing_field(
                    trial_result.agent_setup, "finished_at"
                ),
                agent_execution_started_at=_timing_field(
                    trial_result.agent_execution, "started_at"
                ),
                agent_execution_finished_at=_timing_field(
                    trial_result.agent_execution, "finished_at"
                ),
                verifier_started_at=_timing_field(trial_result.verifier, "started_at"),
                verifier_finished_at=_timing_field(
                    trial_result.verifier, "finished_at"
                ),
            )

            # Insert trial_model row if model info and token data available.
            # Same lazy-upsert pattern as agent above.
            if trial_result.agent_info.model_info is not None:
                model_key = (
                    trial_result.agent_info.model_info.name,
                    trial_result.agent_info.model_info.provider,
                )
                async with self._model_cache_lock:
                    if model_key not in model_cache:
                        model_cache[model_key] = await self.db.upsert_model(
                            trial_result.agent_info.model_info.name,
                            trial_result.agent_info.model_info.provider,
                        )
                    model_id = model_cache[model_key]

                agent_result = trial_result.agent_result
                await self.db.insert_trial_model(
                    trial_id=trial_result.id,
                    model_id=model_id,
                    n_input_tokens=(
                        agent_result.n_input_tokens if agent_result else None
                    ),
                    n_cache_tokens=(
                        agent_result.n_cache_tokens if agent_result else None
                    ),
                    n_output_tokens=(
                        agent_result.n_output_tokens if agent_result else None
                    ),
                    cost_usd=agent_result.cost_usd if agent_result else None,
                )

            elapsed = time.monotonic() - t0
            return TrialUploadResult(
                trial_name=trial_result.trial_name,
                task_name=trial_result.task_name,
                reward=primary_reward,
                archive_size_bytes=archive_size,
                upload_time_sec=elapsed,
            )

        except Exception as exc:
            logger.debug("Failed to upload trial %s: %s", trial_result.trial_name, exc)
            return TrialUploadResult(
                trial_name=trial_result.trial_name,
                task_name=trial_result.task_name,
                reward=primary_reward,
                error=f"{type(exc).__name__}: {exc}",
            )


def _load_job_from_disk(
    job_dir: Path,
) -> tuple[JobResult, JobConfig, list[TrialResult], dict[str, Path]]:
    """Load the job_dir's result.json + config.json + every trial's result.json.

    Returns the parent result/config plus a parallel list of child trial
    results and a name→path map the uploader uses to find each trial's
    on-disk subdir. Used by both ``start_job`` and ``upload_job`` — kept as
    a single helper so both paths load the same trial set with the same
    ordering and detection rules.
    """
    job_result = JobResult.model_validate_json((job_dir / "result.json").read_text())
    job_config = JobConfig.model_validate_json((job_dir / "config.json").read_text())
    trial_dirs: dict[str, Path] = {}
    trial_results: list[TrialResult] = []
    for child in sorted(job_dir.iterdir()):
        if child.is_dir() and (child / "result.json").exists():
            trial_dirs[child.name] = child
            trial_results.append(
                TrialResult.model_validate_json((child / "result.json").read_text())
            )
    return job_result, job_config, trial_results, trial_dirs


def _timing_field(timing: object | None, field: str) -> datetime | None:
    if timing is None:
        return None
    value = getattr(timing, field, None)
    if isinstance(value, datetime):
        return value
    return None


def _extract_primary_reward(trial_result: TrialResult) -> float | int | None:
    if (
        trial_result.verifier_result is not None
        and trial_result.verifier_result.rewards
    ):
        rewards = trial_result.verifier_result.rewards
        # Use "reward" key if available, otherwise first value
        if "reward" in rewards:
            return rewards["reward"]
        return next(iter(rewards.values()))
    return None


def _create_trial_archive(trial_dir: Path) -> bytes:
    """Create a tar.gz archive of the allowlisted entries in a trial dir.

    Only entries in ``_TRIAL_ARCHIVE_INCLUDES`` are included. Missing
    optional entries (e.g. ``exception.txt`` when the trial didn't fail,
    ``analysis.md`` when no analysis was written) are silently skipped.
    Entries live at the root of the archive so extraction into an empty
    ``trial_dir`` restores the original layout.
    """
    buf = BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        _add_trial_archive_entries(tar, trial_dir)
    return buf.getvalue()


def _add_trial_archive_entries(
    tar: tarfile.TarFile, trial_dir: Path, *, arcname_prefix: str = ""
) -> None:
    """Add allowlisted trial entries to an open tar archive."""
    for name in _TRIAL_ARCHIVE_INCLUDES:
        path = trial_dir / name
        if path.exists():
            tar.add(path, arcname=f"{arcname_prefix}{name}")

    steps_dir = trial_dir / "steps"
    if not steps_dir.exists():
        return

    for step_dir in sorted(p for p in steps_dir.iterdir() if p.is_dir()):
        for name in _STEP_ARCHIVE_INCLUDES:
            path = step_dir / name
            if path.exists():
                tar.add(
                    path,
                    arcname=f"{arcname_prefix}steps/{step_dir.name}/{name}",
                )


def _create_job_archive(job_dir: Path) -> bytes:
    """Create a tar.gz archive of a job_dir: top-level allowlist + trial subdirs.

    Top-level files from ``_JOB_ARCHIVE_INCLUDES`` are included. Then every
    child directory with a ``result.json`` inside is treated as a trial
    subdir, and its contents are filtered through ``_TRIAL_ARCHIVE_INCLUDES``
    (same detection rule ``Uploader.upload_job`` uses to enumerate trials).
    Entries are rooted at ``{job_name}/...`` so ``extractall`` into an
    ``output_dir`` produces ``output_dir/{job_name}/...``.
    """
    buf = BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        _add_job_archive_entries(tar, job_dir)
    return buf.getvalue()


def _create_job_archive_file(job_dir: Path, archive_path: Path) -> None:
    """Create the job archive on disk to avoid holding large jobs in memory."""
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive_path, mode="w:gz") as tar:
        _add_job_archive_entries(tar, job_dir)


def _add_job_archive_entries(tar: tarfile.TarFile, job_dir: Path) -> None:
    root = job_dir.name
    for name in _JOB_ARCHIVE_INCLUDES:
        path = job_dir / name
        if path.exists():
            tar.add(path, arcname=f"{root}/{name}")
    for child in sorted(job_dir.iterdir()):
        if not (child.is_dir() and (child / "result.json").exists()):
            continue
        _add_trial_archive_entries(
            tar,
            child,
            arcname_prefix=f"{root}/{child.name}/",
        )
