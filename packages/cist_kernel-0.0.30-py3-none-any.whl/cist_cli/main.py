from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any

import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from . import __version__
from .network import CloudCourier
from .parser import CISTParser, ValidationError

load_dotenv()

# On Windows, pip --user installs scripts to a folder not on PATH by default.
# Detect this and print a one-time actionable fix before the user hits a
# confusing "not recognized" error (they'd have to be running via python -m to
# even reach this point, so we can give them instructions to fix it properly).

def _warn_windows_path() -> None:
    if sys.platform != "win32":
        return
    scripts_dir = Path(os.environ.get("APPDATA", "")) / "Python" / f"Python{sys.version_info.major}{sys.version_info.minor}" / "Scripts"
    if not scripts_dir.exists():
        return
    path_dirs = [Path(p) for p in os.environ.get("PATH", "").split(os.pathsep)]
    if scripts_dir not in path_dirs:
        _console = Console(stderr=True)
        _console.print(
            f"\n[yellow bold]Windows PATH notice:[/yellow bold] "
            f"[cyan]{scripts_dir}[/cyan] is not on your PATH.\n"
            f"Run this once in PowerShell to fix it permanently, then reopen your terminal:\n\n"
            f'  [bold][Environment]::SetEnvironmentVariable("PATH", $env:PATH + ";{scripts_dir}", "User")[/bold]\n'
        )

_warn_windows_path()

_EDITOR_CANDIDATES: dict[str, list[str]] = {
    "darwin": [
        "/Applications/Antigravity.app/Contents/Resources/app/bin/antigravity",
        str(Path.home() / "Applications/Antigravity.app/Contents/Resources/app/bin/antigravity"),
        "/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code",
        str(Path.home() / "Applications/Visual Studio Code.app/Contents/Resources/app/bin/code"),
    ],
    "win32": [
        str(Path(os.environ.get("LOCALAPPDATA", "")) / "Programs/Antigravity/bin/antigravity.cmd"),
        str(Path(os.environ.get("LOCALAPPDATA", "")) / "Programs/Microsoft VS Code/bin/code.cmd"),
        str(Path(os.environ.get("PROGRAMFILES", "")) / "Microsoft VS Code/bin/code.cmd"),
    ],
    "linux": [
        "/usr/bin/antigravity",
        "/usr/local/bin/antigravity",
        "/usr/bin/code",
        "/snap/bin/code",
        "/usr/local/bin/code",
        str(Path.home() / ".local/bin/code"),
    ],
}

def _find_all_editors() -> list[str]:
    """Return a list of ALL found Antigravity and VS Code executables to sync."""
    found_editors = []
    seen_base_paths = set()
    
    def _add_if_unique(exe_path: str | None):
        if not exe_path:
            return
        
        # Normalize the path and strip the extension (.exe, .cmd, etc.)
        # This prevents 'code.EXE' and 'code.cmd' from being treated as 2 different editors!
        normalized = os.path.normcase(os.path.normpath(exe_path))
        base_path, _ = os.path.splitext(normalized)
        
        if base_path not in seen_base_paths:
            seen_base_paths.add(base_path)
            found_editors.append(exe_path)

    # 1. Check system PATH first
    for cmd in ["antigravity", "agy", "code", "code-insiders"]:
        _add_if_unique(shutil.which(cmd))
            
    # 2. Check hardcoded fallback paths
    platform = sys.platform if sys.platform in _EDITOR_CANDIDATES else "linux"
    for candidate in _EDITOR_CANDIDATES[platform]:
        if Path(candidate).exists():
            _add_if_unique(candidate)
            
    return found_editors

# Extension IDs that used invalid publisher names (spaces) — must be evicted.
# We ONLY hardcode this because it's a historical typo the script can't guess.
_LEGACY_EXTENSION_IDS: list[str] = [
    "tooig research lab.cist",
]

def _read_vsix_id(vsix: Path) -> str | None:
    """Dynamically read the VSIX package.json to get the current extension ID."""
    try:
        with zipfile.ZipFile(vsix) as archive:
            with archive.open("extension/package.json") as package_file:
                package = json.load(package_file)
        return f"{package['publisher']}.{package['name']}"
    except Exception:
        return None

def _extension_install_roots() -> list[Path]:
    """Generate a list of all possible extension directories for legacy cleanup."""
    configured_root = os.environ.get("VSCODE_EXTENSIONS", "").strip()
    user_home = Path(os.environ.get("USERPROFILE") or str(Path.home()))

    roots: list[Path] = []
    if configured_root:
        roots.append(Path(configured_root))

    roots.extend([
        user_home / ".antigravity" / "extensions",
        user_home / ".vscode" / "extensions",
        user_home / ".vscode-insiders" / "extensions"
    ])

    return list(set(roots)) # Remove duplicates

def _remove_extension_dirs(root: Path, prefixes: list[str]) -> None:
    if not root.is_dir():
        return
    for entry in root.iterdir():
        if not entry.is_dir():
            continue
        name_lower = entry.name.lower()
        if any(name_lower.startswith(prefix.lower()) for prefix in prefixes):
            try:
                shutil.rmtree(entry)
            except OSError:
                pass

def _remove_legacy_extensions(editors: list[str], vsix_path: Path | None) -> None:
    """Uninstall old CIST extension versions and the currently bundled version to clear cache."""
    
    # Dynamically build the list of targets to uninstall
    targets = list(_LEGACY_EXTENSION_IDS)
    if vsix_path:
        current_id = _read_vsix_id(vsix_path)
        if current_id and current_id not in targets:
            targets.append(current_id)

    # 1. Via Official CLI
    for exe in editors:
        for ext_id in targets:
            subprocess.run(
                [exe, "--uninstall-extension", ext_id],
                capture_output=True,
                text=True,
            )

    # 2. Manual fallback sweep
    prefixes = [f"{ext_id.lower()}-" for ext_id in targets]
    for root in _extension_install_roots():
        _remove_extension_dirs(root, prefixes)

def _latest_bundled_vsix() -> Path | None:
    assets_dir = Path(__file__).parent / "assets"
    vsix_files = sorted(assets_dir.glob("*.vsix"))
    if not vsix_files:
        return None
    return vsix_files[-1]

def _install_vscode_extension(editors: list[str], vsix: Path) -> tuple[bool, str]:
    """Install the bundled extension properly using the official CLIs."""
    if not editors:
        return False, "No compatible editor found (checked Antigravity and VS Code)."

    successes = []
    errors = []

    for exe in editors:
        exe_name = Path(exe).name
        try:
            # By using subprocess, the editors handle their own internal caching
            subprocess.run(
                [exe, "--install-extension", str(vsix), "--force"],
                capture_output=True,
                text=True,
                check=True
            )
            successes.append(f"Installed to {exe_name}")
        except subprocess.CalledProcessError as e:
            err_msg = e.stderr.strip() or e.stdout.strip()
            errors.append(f"Failed on {exe_name}: {err_msg}")

    if successes:
        msg = "\n  ".join(successes)
        if errors:
            msg += "\n  [yellow]Warnings:[/yellow]\n  " + "\n  ".join(errors)
        return True, msg

    return False, "\n  ".join(errors)

def _sync_vscode_extension() -> tuple[bool, str]:
    if os.environ.get("CIST_SKIP_VSCODE_INSTALL") == "1":
        return False, "[dim]Extension install skipped (CIST_SKIP_VSCODE_INSTALL=1)[/dim]"

    editors = _find_all_editors()
    vsix = _latest_bundled_vsix()
    
    if vsix is None:
        return False, "[yellow]![/yellow] Bundled extension not found in cist_cli/assets"

    # Pass the VSIX down so it can dynamically read the ID to uninstall first
    _remove_legacy_extensions(editors, vsix)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task(description="Installing extension...", total=None)
        ok, install_output = _install_vscode_extension(editors, vsix)

    if ok:
        lines = [f"[green]✓[/green] Extension synced from [cyan]{vsix.name}[/cyan]"]
        if install_output:
            lines.append(f"  [dim]{install_output}[/dim]")
        lines.append("  [dim]Reload window to activate: Ctrl+Shift+P → Developer: Reload Window[/dim]")
        return True, "\n".join(lines)

    detail = f"\n  [dim]{install_output}[/dim]" if install_output else ""
    return (
        False,
        "[yellow]![/yellow] Extension install failed."
        + detail
    )

EXAMPLE_CONTRACT = """# this contract uses the hyper nursery to deliver the price of oil over a period of 14 days to max at least $24,000 in pnl

use math
use hyper

# define a few utility functions to halp in the contract design
write fn get_oil_price():
    # the definition of the variables used in the function
    which defines:
        oil_price = hype.get_price("OIL")
        time_in_minutes=math.floor(compute.now()/60)
        current_time=compute.now()

    then:
        # the logic to fetch the price of oil every 3 minutes
        if time_in_minutes % 3 == 0:
            oil_price = hype.get_price("OIL")
        else:
            oil_price = hype.get_price("OIL")

    then:
        return oil_price

# parse the loop in as the execution intent for the contract to run indefinitely and fetch the price of oil every 3 minutes, allowing for trading decisions based on the price movements over a 14-day period to maximize potential profit and loss (PnL) up to $24,000.
contract OilPriceMonitor:
    which defines:
        # the contract will run indefinitely, fetching the price of oil every 3 minutes
        while True:
            oil_price = get_oil_price()

            then:
                if oil_price > 80.0:
                    print("Oil price is high, consider selling.")
                elif oil_price < 40.0:
                    print("Oil price is low, consider buying.")
                else:
                    print("Oil price is stable, hold your position.")
            
            then:
                compute.sleep(180)  # sleep for 3 minutes (180 seconds)
                # define execution intent to run the contract for a period of 14 days
                if compute.now() >= current_time + 14 * 24 * 60 * 60:
                    break


# using the math module to do bernoulli equation calculations for fluid dynamics related to oil extraction and transportation, which can be crucial for making informed trading decisions based on the physical properties of oil and its behavior under different conditions.
write bernoulli_equation(a, b, c):
    which defines::attr:
        # the Bernoulli equation is a fundamental principle in fluid dynamics that describes the behavior of a fluid under varying conditions of flow and height. It is expressed as:
        # P + 0.5 * ρ * v^2 + ρ * g * h = constant
        # where P is the pressure, ρ is the fluid density, v is the flow velocity, g is the acceleration due to gravity, and h is the height above a reference point.
        # In this function, we will calculate the pressure (P) based on the other parameters (a, b, c) which represent velocity (v), height (h), and fluid density (ρ) respectively.

        velocity = a
        instructions = "mathematical expression for the Bernoulli equation using the defined variables"
        height = b
        density = c
        gravity = 9.81  # acceleration due to gravity in m/s^2

    then:
        # using raw mathematical operations to calculate the pressure based on the Bernoulli equation
        kinetic_energy = 0.5 * density * velocity ** 2
        potential_energy = density * gravity * height
        pressure_ord = kinetic_energy + potential_energy
        
        # using the math module to define the pressure variable based on the calculated kinetic and potential energy, which can be crucial for understanding the dynamics of oil flow and making informed trading decisions based on the physical properties of oil.
        pressure = math.define(attr)
        return pressure
"""

app = typer.Typer(
    name="cist",
    help="Contract Instruction Set",
    no_args_is_help=True,
)
console = Console()


def _resolve_cis_path(filepath: Path) -> Path:
    resolved = filepath.expanduser().resolve()
    if resolved.suffix.lower() != ".cis":
        console.print(f"[red]Error:[/red] Expected .cis file, got {resolved.suffix}")
        raise typer.Exit(1)
    return resolved


def _print_warnings(result: dict[str, Any]) -> None:
    warnings = result.get("warnings", [])
    for warning in warnings:
        console.print(
            f"[yellow]! Line {warning.line}:[/yellow] {warning.message}"
        )


@app.callback()
def callback() -> None:
    """CIST - Contract Instruction Set Toolkit."""


def _init_workspace(path: Path) -> None:
    target = path.expanduser().resolve()
    target.mkdir(parents=True, exist_ok=True)

    # ── workspace skeleton ────────────────────────────────────────────────────
    contracts_dir = target / "contracts"
    contracts_dir.mkdir(exist_ok=True)

    example_file = contracts_dir / "example.cis"
    if not example_file.exists():
        example_file.write_text(EXAMPLE_CONTRACT, encoding="utf-8")

    env_file = target / ".env"
    if not env_file.exists():
        env_file.write_text(
            "# CIST Cloud API\nCIST_CLOUD_API_KEY=\nCIST_CLOUD_ENDPOINT=https://api.cist.io/v1\n",
            encoding="utf-8",
        )

    # ── VS Code extension install ──────────────────────────────────────────────
    _, vscode_line = _sync_vscode_extension()

    # ── summary ───────────────────────────────────────────────────────────────
    console.print(
        Panel.fit(
            f"[bold green]CIST Ready[/bold green]\n\n"
            f"Workspace:  [cyan]{target}[/cyan]\n"
            f"Contracts:  [cyan]{contracts_dir}[/cyan]\n"
            f"Example:    [cyan]{example_file}[/cyan]\n"
            f"Config:     [cyan]{env_file}[/cyan]\n\n"
            f"{vscode_line}\n\n"
            f"Next steps:\n"
            f"  1. Add your API key to [bold].env[/bold]\n"
            f"  2. Open [bold]{example_file.name}[/bold] and start writing\n"
            f"  3. Run [bold]cist compile <file.cis>[/bold] to build and deploy",
            title=f"cist-kernel v{__version__}",
        )
    )


@app.command()
def init(
    path: Path = typer.Option(
        Path("."),
        "--path",
        "-p",
        file_okay=False,
        help="Target directory",
    ),
) -> None:
    """Initialize a CIST workspace."""
    _init_workspace(path=path)


@app.command("sync-vscode-extension")
def sync_vscode_extension() -> None:
    """Install or update the bundled VS Code extension."""
    ok, message = _sync_vscode_extension()
    console.print(message)
    if not ok:
        raise typer.Exit(1)


@app.command()
def compile(
    filepath: Path = typer.Argument(
        ...,
        exists=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to .cis file",
    ),
    deploy: bool = typer.Option(
        False,
        "--deploy",
        "-d",
        help="Deploy to live execution",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
) -> None:
    """Validate locally, then stream the CIST source to the cloud compiler."""
    resolved = _resolve_cis_path(filepath)
    parser = CISTParser()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task(description="Checking syntax...", total=None)
        try:
            ast = parser.validate_file(resolved)
        except ValidationError as exc:
            console.print(f"[red]Syntax error:[/red] {exc}")
            raise typer.Exit(1) from exc

    _print_warnings(ast)
    modules_str = ", ".join(ast["modules"]) or "none"
    console.print(
        f"[green]✓[/green] [bold]{resolved.name}[/bold]  "
        f"[dim]{ast['line_count']} lines · modules: {modules_str} · "
        f"{ast['data_streams']} data stream(s)[/dim]"
    )
    if verbose:
        console.print(f"[dim]  modules  : {ast['modules']}[/dim]")
        console.print(f"[dim]  streams  : {ast['data_streams']}[/dim]")

    console.print("[cyan]Connecting to CIST Cloud...[/cyan]")
    try:
        courier = CloudCourier()
        for event in courier.stream_compile(ast, deploy=deploy):
            event_type = event.get("type")
            if event_type == "log":
                console.print(f"[dim][Cloud][/dim] {event.get('message', '')}")
            elif event_type == "artifact":
                console.print(
                    f"[bold green]ok Compiled:[/bold green] {event.get('artifact_id', 'unknown')}"
                )
            elif event_type == "error":
                console.print(
                    f"[bold red]x Build Error:[/bold red] {event.get('message', '')}"
                )
                raise typer.Exit(1)
            elif event_type == "complete":
                console.print("[green]Compilation complete[/green]")
    except ValueError as exc:
        console.print(f"[bold red]Configuration Error:[/bold red] {exc}")
        raise typer.Exit(1) from exc
    except ConnectionError as exc:
        console.print(f"[bold red]Connection Failed:[/bold red] {exc}")
        raise typer.Exit(1) from exc


if __name__ == "__main__":
    app()