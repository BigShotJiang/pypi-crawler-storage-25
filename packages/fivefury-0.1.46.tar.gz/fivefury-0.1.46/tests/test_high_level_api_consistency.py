from __future__ import annotations

from fivefury import (
    BoundSphere,
    BoundType,
    CarGen,
    CutCamera,
    CutScene,
    DistantLodLightsSoa,
    EntityDef,
    GrassInstanceBatch,
    InstancedMapData,
    LodLight,
    LodLightsSoa,
    MloInstanceDef,
    Texture,
    TextureFormat,
    Ybn,
    Ymap,
    YmapCarGenFlags,
    YmapContentFlags,
    YmapEntityFlags,
    YmapFlags,
    YmapLodLevel,
    YmapLodLightCategory,
    YmapLodLightType,
    YmapMloInstanceFlags,
    YmapPriorityLevel,
    Ytd,
    Ytyp,
)


def _simple_bound() -> BoundSphere:
    return BoundSphere(
        bound_type=BoundType.SPHERE,
        sphere_radius=1.0,
        box_max=(1.0, 1.0, 1.0),
        margin=0.0,
        box_min=(-1.0, -1.0, -1.0),
        box_center=(0.0, 0.0, 0.0),
        sphere_center=(0.0, 0.0, 0.0),
    )


def test_high_level_consistency_surface() -> None:
    ytd = Ytd()
    ytd.add_texture(
        Texture.from_raw(
            bytes([255, 0, 0, 255] * 16),
            width=4,
            height=4,
            format=TextureFormat.A8R8G8B8,
            mip_count=1,
            name="test",
        )
    )
    assert ytd.build().validate() == []

    ybn = Ybn.from_bound(_simple_bound())
    ybn.set_bound(_simple_bound())
    assert ybn.build().validate() == []

    ytyp = Ytyp(name="test")
    ytyp.create_archetype("prop_box")
    ytyp.add_dependency("props")
    assert ytyp.build().validate() == []

    ymap = Ymap(name="test")
    ymap.add_entity(EntityDef(archetype_name="prop_box"))
    assert ymap.build(auto_flags=True).validate() == []

    cut = CutScene.create(duration=1.0)
    cut.add_binding(CutCamera("cam_main"))
    assert cut.build().validate() == []


def test_ymap_enum_values_match_dev_sources() -> None:
    assert YmapContentFlags.ENTITIES_HD == 1 << 0
    assert YmapContentFlags.ENTITIES_LOD == 1 << 1
    assert YmapContentFlags.ENTITIES_CONTAINER_LOD == 1 << 2
    assert YmapContentFlags.MLO == 1 << 3
    assert YmapContentFlags.BLOCKINFO == 1 << 4
    assert YmapContentFlags.OCCLUDER == 1 << 5
    assert YmapContentFlags.ENTITIES_USING_PHYSICS == 1 << 6
    assert YmapContentFlags.LOD_LIGHTS == 1 << 7
    assert YmapContentFlags.DISTANT_LOD_LIGHTS == 1 << 8
    assert YmapContentFlags.ENTITIES_CRITICAL == 1 << 9
    assert YmapContentFlags.INSTANCE_LIST == 1 << 10

    assert YmapEntityFlags.DONT_INSTANCE_COLLISION == 1 << 2
    assert YmapEntityFlags.IS_FIXED == 1 << 5
    assert YmapEntityFlags.LIGHTS_CAST_STATIC_SHADOWS == 1 << 11
    assert YmapEntityFlags.ONLY_RENDER_IN_MIRROR_REFLECTIONS == 1 << 21
    assert YmapEntityFlags.EMBEDDED_COLLISIONS_DISABLED == YmapEntityFlags.DONT_INSTANCE_COLLISION

    assert YmapMloInstanceFlags.GPS_ON == 1 << 0
    assert YmapMloInstanceFlags.CAP_CONTENTS_ALPHA == 1 << 1
    assert YmapMloInstanceFlags.SHORT_FADE == 1 << 2
    assert YmapMloInstanceFlags.SPECIAL_BEHAVIOUR_3 == 1 << 5

    assert YmapCarGenFlags.FORCESPAWN == 1 << 0
    assert YmapCarGenFlags.POLICE == 1 << 2
    assert YmapCarGenFlags.DURING_DAY == 1 << 5
    assert YmapCarGenFlags.PREVENT_ENTRY == 1 << 12


def test_ymap_typed_enums_roundtrip_and_recalculate_cleanly() -> None:
    entity = EntityDef(
        archetype_name="prop_test",
        flags=YmapEntityFlags.IS_FIXED | YmapEntityFlags.DONT_INSTANCE_COLLISION,
        lod_level=YmapLodLevel.DEPTH_LOD,
        priority_level=YmapPriorityLevel.OPTIONAL_MEDIUM,
    )
    parsed_entity = EntityDef.from_meta(entity.to_meta())
    assert isinstance(parsed_entity.flags, YmapEntityFlags)
    assert isinstance(parsed_entity.lod_level, YmapLodLevel)
    assert isinstance(parsed_entity.priority_level, YmapPriorityLevel)
    assert parsed_entity.flags == (YmapEntityFlags.IS_FIXED | YmapEntityFlags.DONT_INSTANCE_COLLISION)
    assert parsed_entity.lod_level is YmapLodLevel.DEPTH_LOD
    assert parsed_entity.priority_level is YmapPriorityLevel.OPTIONAL_MEDIUM

    mlo = MloInstanceDef(
        archetype_name="int_test_mlo",
        mlo_inst_flags=YmapMloInstanceFlags.GPS_ON | YmapMloInstanceFlags.SHORT_FADE,
    )
    parsed_mlo = MloInstanceDef.from_meta(mlo.to_meta())
    assert isinstance(parsed_mlo.mlo_inst_flags, YmapMloInstanceFlags)
    assert parsed_mlo.mlo_inst_flags == (YmapMloInstanceFlags.GPS_ON | YmapMloInstanceFlags.SHORT_FADE)

    car_gen = CarGen.create(
        "adder",
        (1.0, 2.0, 3.0),
        flags=YmapCarGenFlags.POLICE | YmapCarGenFlags.DURING_DAY,
    )
    parsed_car_gen = CarGen.from_meta(car_gen.to_meta())
    assert isinstance(parsed_car_gen.flags, YmapCarGenFlags)
    assert parsed_car_gen.flags == (YmapCarGenFlags.POLICE | YmapCarGenFlags.DURING_DAY)

    ymap = Ymap(name="test.ymap")
    ymap.entities.extend(
        [
            EntityDef(archetype_name="prop_hd", lod_level=YmapLodLevel.DEPTH_HD),
            EntityDef(archetype_name="prop_lod", lod_level=YmapLodLevel.DEPTH_LOD),
            EntityDef(archetype_name="prop_slod1", lod_level=YmapLodLevel.DEPTH_SLOD1),
            EntityDef(archetype_name="prop_slod2", lod_level=YmapLodLevel.DEPTH_SLOD2),
            MloInstanceDef(archetype_name="int_test_mlo"),
        ]
    )
    ymap.block.version = 1
    ymap.physics_dictionaries.append("test_physics")
    ymap.instanced_data = InstancedMapData(grass_instance_list=[GrassInstanceBatch()])
    ymap.lod_lights = LodLightsSoa()
    ymap.lod_lights.append(LodLight())
    ymap.distant_lod_lights = DistantLodLightsSoa()
    ymap.distant_lod_lights.append((0.0, 0.0, 0.0), 0)
    ymap.box_occluders.append(
        {
            "iCenterX": 0,
            "iCenterY": 0,
            "iCenterZ": 0,
            "iCosZ": 0,
            "iLength": 0,
            "iWidth": 0,
            "iHeight": 0,
            "iSinZ": 0,
        }
    )
    ymap.recalculate_flags()

    assert isinstance(ymap.flags, YmapFlags)
    assert isinstance(ymap.content_flags, YmapContentFlags)
    assert ymap.flags == YmapFlags.HAS_LODS
    assert ymap.content_flags == (
        YmapContentFlags.ENTITIES_HD
        | YmapContentFlags.ENTITIES_LOD
        | YmapContentFlags.ENTITIES_CONTAINER_LOD
        | YmapContentFlags.ENTITIES_CRITICAL
        | YmapContentFlags.MLO
        | YmapContentFlags.BLOCKINFO
        | YmapContentFlags.ENTITIES_USING_PHYSICS
        | YmapContentFlags.INSTANCE_LIST
        | YmapContentFlags.LOD_LIGHTS
        | YmapContentFlags.DISTANT_LOD_LIGHTS
        | YmapContentFlags.OCCLUDER
    )


def test_ymap_lod_light_helpers_follow_dev_ng_bit_layout() -> None:
    light = LodLight()
    light.time_flags = 0xABCDE
    light.is_street_light = True
    light.is_corona_only = True
    light.light_type = YmapLodLightType.CAPSULE
    light.state_flags_2 = 0
    light.dont_use_in_cutscene = True

    assert light.time_flags == 0xABCDE
    assert light.is_street_light is True
    assert light.is_corona_only is True
    assert light.light_type is YmapLodLightType.CAPSULE
    assert light.dont_use_in_cutscene is True
    assert light.state_flags_1 == 3
    assert light.state_flags_2 == 1
    assert light.time_and_state_flags == (
        0xABCDE | (3 << 24) | (int(YmapLodLightType.CAPSULE) << 26) | (1 << 31)
    )

    distant = DistantLodLightsSoa.from_meta(
        {
            "position": [(0.0, 0.0, 0.0)],
            "RGBI": [0xFFFFFFFF],
            "numStreetLights": 1,
            "category": int(YmapLodLightCategory.LARGE),
        }
    )
    assert isinstance(distant.category, YmapLodLightCategory)
    assert distant.category is YmapLodLightCategory.LARGE


def test_ymap_build_normalizes_street_light_prefix_and_count() -> None:
    ymap = Ymap(name="lod_lights_test")

    ymap.lod_light(
        position=(10.0, 0.0, 0.0),
        direction=(0.0, 0.0, -1.0),
        is_street_light=False,
        colour=(255, 0, 0),
        intensity=200,
    )
    ymap.lod_light(
        position=(20.0, 0.0, 0.0),
        direction=(0.0, 0.0, -1.0),
        is_street_light=True,
        colour=(0, 255, 0),
        intensity=180,
    )

    ymap.build()

    lights = ymap.iter_lod_lights()
    assert len(lights) == 2
    assert lights[0].is_street_light is True
    assert lights[1].is_street_light is False
    assert lights[0].position == (20.0, 0.0, 0.0)
    assert lights[1].position == (10.0, 0.0, 0.0)
    assert ymap.distant_lod_lights is not None
    assert ymap.distant_lod_lights.num_street_lights == 1


def test_lod_light_semantic_pack_helpers_match_dev_ng_ranges() -> None:
    light = LodLight()
    light.cone_inner_angle_degrees = 30.0
    light.cone_outer_angle_degrees = 60.0
    light.corona_intensity_value = 16.0
    light.capsule_extent = 70.0
    light.colour = (12, 34, 56)
    light.intensity = 200

    assert light.cone_inner_angle == round(30.0 * (255.0 / 180.0))
    assert light.cone_outer_angle_or_cap_ext == round(70.0 * (255.0 / 140.0))
    assert light.corona_intensity == round(16.0 * (255.0 / 32.0))
    assert light.colour == (12, 34, 56)
    assert light.intensity == 200
