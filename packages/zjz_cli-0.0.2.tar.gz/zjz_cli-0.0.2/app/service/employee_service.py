import re

from app.api import zjz_api
from app.service.config_manager import cfg_mgr


class EmployeeService:
    def get_employee_list(self, uid: str, keyword: str = ''):
        uid = cfg_mgr.get_abs_uid(uid)
        res_list = []
        total_cnt = 0
        page = 1
        while True:
            res = zjz_api.get_employee_list(uid, keyword, page)
            if res.get('code') != 200:
                return {
                    'code': res['code'],
                    'msg': res['msg'],
                }
            data = res.get('data')
            items = data.get('items')
            total_cnt = data.get('total_count')
            res_list.extend(items)
            if len(res_list) <= len(res_list):
                break
            page += 1
        msg = f'一共{total_cnt}名员工'
        if keyword:
            msg = f'共搜索出{total_cnt}名符合要求的员工'
        return {
            'code': 200,
            'msg': msg,
            'data': {
                'uid': uid,
                'ryxx': res_list,
            },
        }

    def _parse_jmsfz(self, jmsfz: str) -> tuple:
        if not jmsfz or len(jmsfz) != 18:
            return False, None, None
        if not re.match(r'^\d{17}[\dX]$', jmsfz):
            return False, None, None
        # 加权因子
        factors = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
        # 校验码对应表
        check_codes = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2']
        # 计算前17位加权和
        total = sum(int(jmsfz[i]) * factors[i] for i in range(17))
        remainder = total % 11
        if jmsfz[17] != check_codes[remainder]:
            return False, None, None
        xb_code = int(jmsfz[16])
        xb = 2 if xb_code % 2 == 0 else 1
        csrq = f"{jmsfz[6:10]}-{jmsfz[10:12]}-{jmsfz[12:14]}"
        return True, xb, csrq

    def add_employee(self, uid: str, data: dict) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        return zjz_api.add_employee(uid, data)

    def update_employee(self, employee_id: str, data: dict) -> dict:
        return zjz_api.update_employee(employee_id, data)
