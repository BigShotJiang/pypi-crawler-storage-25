from app.api import zjz_api
from app.service.config_manager import cfg_mgr


class AccountService:
    def sms_verify_code(self, phone: str) -> dict:
        res = zjz_api.sms_verify_code(phone)
        if res.get('code') != 200:
            return res
        data = res.get('data', {})
        expire_in = data.get('expire_in')
        return {
            'code': 200,
            'msg': f'获取成功，请在 {expire_in} 秒内完成验证'
        }

    def _get_default_select_user(self, users: list) -> tuple:
        if not users:
            return 0, None
        user_cnt = len(users)
        if user_cnt == 0:
            return 0, None
        if user_cnt == 1:
            return user_cnt, users[0]
        for user in users:
            if user['cpy_id'] and user['cpy_name']:
                return user_cnt, user
        return user_cnt, users[0]

    def sms_code_login(self, phone: str, code: str) -> dict:
        res = zjz_api.verify_sms_code(phone, code)
        if res.get('code') != 200:
            return res
        data = res.get('data')
        users = data.get('users', [])
        curr_uid = ''
        cpy_description_info = ''
        user_cnt, curr_user = self._get_default_select_user(users)
        if curr_user:
            curr_uid = curr_user['uid']
            cpy_name = curr_user['cpy_name']
            if user_cnt > 1:
                cpy_description_info = f'账号下一共有{user_cnt}个公司。'
                if cpy_name:
                    cpy_description_info += f'当前已经切换至 {cpy_name}'
            elif cpy_name:
                cpy_description_info = cpy_name
        cfg_mgr.update_configs({
            'aid': data.get('aid', ''),
            'curr_uid': curr_uid,
            'phone': data.get('phone', ''),
            'token': data.get('token', ''),
            'users': users,
        })
        return {
            'code': 200,
            'msg': f'账号绑定成功！{cpy_description_info}'
        }

    def get_switchable_user(self):
        users = cfg_mgr.get_config('users', [])
        user_cnt = len(users)
        if user_cnt == 0:
            return {
                'code': 400,
                'msg': '没有可切换的公司列表'
            }
        curr_uid = cfg_mgr.get_config('curr_uid', '')
        return {
            'code': 200,
            'msg': f'一共{user_cnt}个公司，当前正使用uid={curr_uid}',
            'data': [
                {
                    'uid': user['uid'],
                    'cpy_name': user['cpy_name'],
                    'tax_no': user['tax_no'],
                    'active': True if user['uid'] == curr_uid else False,
                }
                for user in users
            ]
        }

    def switch_to(self, uid: str):
        data = self.get_switchable_user()
        users = data.get('data', [])
        if len(users) == 0:
            return {
                'code': 400,
                'msg': '当前没有可切换的公司'
            }
        condition = lambda item: item['uid'] == uid
        user = next((item for item in users if condition(item)), None)
        if not user:
            return {
                'code': 404,
                'msg': f'没有找到符合uid={uid}条件的公司信息'
            }
        cfg_mgr.update_config('curr_uid', uid)
        cpy_name = f" {user['cpy_name']}"
        return {
            'code': 200,
            'msg': f'切换成功{cpy_name}'
        }
