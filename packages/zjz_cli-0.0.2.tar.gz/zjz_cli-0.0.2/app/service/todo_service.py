from app.api import zjz_api
from app.service.config_manager import cfg_mgr


class TodoService:
    def get_todo_list(self, uid: str) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)

        todo_res = zjz_api.get_todo_list(uid)
        if todo_res.get('code') != 200:
            return todo_res
        todo_list = (todo_res.get('data') or {}).get('list') or []
        pending_cnt = len([item for item in todo_list if item.get('state') == 0])

        return {
            'code': 200,
            'msg': f'代办共 {len(todo_list)} 项，未完成 {pending_cnt} 项',
            'data': {
                'uid': uid,
                'todo_list': todo_list,
            }
        }

    def before_set_month_audited(self, year: int, month: int, uid: str) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        
        if not year or year < 1970:
            return {
                'code': 400,
                'msg': 'year 不合法',
            }
        if not month or month < 1 or month > 12:
            return {
                'code': 400,
                'msg': 'month 不合法（1-12）',
            }
        
        audit_res = zjz_api.before_set_month_audited(year, month, uid)
        if audit_res.get('code') != 200:
            return audit_res
        data = audit_res.get('data') or {}
        state = data.get('state')
        reason = data.get('reason', '')
        msg = '允许提交审账' if state else f'暂不允许提交审账：{reason}'

        return {
            'code': 200,
            'msg': msg,
            'data': {
                'uid': uid,
                'year': year,
                'month': month,
                'state': state,
                'reason': reason,
            }
        }

    def set_month_audited(self, year: int, month: int, uid: str = '') -> dict:
        uid = cfg_mgr.get_abs_uid(uid)

        if not year or year < 1970:
            return {
                'code': 400,
                'msg': 'year 不合法',
            }
        if not month or month < 1 or month > 12:
            return {
                'code': 400,
                'msg': 'month 不合法（1-12）',
            }
        
        audit_res = zjz_api.set_month_audited(year, month, uid)
        if audit_res.get('code') != 200:
            return audit_res
        return {
            'code': 200,
            'msg': '提交成功',
            'data': {
                'uid': uid
            }
        }
