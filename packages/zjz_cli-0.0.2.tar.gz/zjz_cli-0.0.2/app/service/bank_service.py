import re
from datetime import datetime

from app.api import zjz_api
from app.service.config_manager import cfg_mgr


class BankService:
    def _validate_page_and_date_range(self, current: int, date_begin: str, date_end: str) -> tuple:
        if not current or current < 1:
            current = 1
        if (date_begin and not date_end) or (date_end and not date_begin):
            return False, {
                'code': 400,
                'msg': 'date_begin 和 date_end 需要同时填写',
            }
        if date_begin and not re.match(r'^\d{4}-\d{2}-\d{2}$', date_begin):
            return False, {
                'code': 400,
                'msg': 'date_begin 格式不正确，期望 YYYY-MM-DD',
            }
        if date_end and not re.match(r'^\d{4}-\d{2}-\d{2}$', date_end):
            return False, {
                'code': 400,
                'msg': 'date_end 格式不正确，期望 YYYY-MM-DD',
            }
        if date_begin and date_end:
            try:
                begin_dt = datetime.strptime(date_begin, '%Y-%m-%d')
                end_dt = datetime.strptime(date_end, '%Y-%m-%d')
                if begin_dt > end_dt:
                    return False, {
                        'code': 400,
                        'msg': 'date_begin 不能晚于 date_end',
                    }
            except ValueError:
                return False, {
                    'code': 400,
                    'msg': 'date_begin / date_end 解析失败，期望 YYYY-MM-DD',
                }
        return True, {
            'current': current,
            'date_begin': date_begin,
            'date_end': date_end,
        }

    def get_bank_bill_data_list(self, uid: str, current: int = 1, date_begin: str = '', date_end: str = '') -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        ok, validated = self._validate_page_and_date_range(current, date_begin, date_end)
        if not ok:
            return validated
        current = validated['current']

        res = zjz_api.get_bank_bill_data_list(uid, current, date_begin, date_end)
        if res.get('code') != 200:
            return {
                'code': res.get('code'),
                'msg': res.get('msg'),
            }
        data = res.get('data') or {}
        items = data.get('items') or []
        total_cnt = data.get('total_count')
        return {
            'code': 200,
            'msg': '查询成功',
            'data': {
                'uid': uid,
                'cnt': total_cnt if total_cnt is not None else len(items),
                'bill_list': items,
            }
        }

    def choose_bank_use(self, uid: str, bill_id: int, rule_text: str) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        if not bill_id or bill_id <= 0:
            return {
                'code': 400,
                'msg': 'id 不合法',
            }
        if not rule_text:
            return {
                'code': 400,
                'msg': 'rule_text 不能为空',
            }
        res = zjz_api.choose_bank_use(uid, bill_id, rule_text)
        if res.get('code') != 200:
            return res
        return {
            'code': 200,
            'msg': '录入成功',
            'data': {
                'uid': uid,
                'id': bill_id,
                'rule_text': rule_text,
            }
        }

    def set_month_bank_no_water(self, uid: str, year: int, month: int) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        if not year or year < 1970:
            return {
                'code': 400,
                'msg': 'year 不合法',
            }
        if not month or month < 1 or month > 12:
            return {
                'code': 400,
                'msg': 'month 不合法（1-12）',
            }
        res = zjz_api.set_month_bank_no_water(uid, year, month)
        if res.get('code') != 200:
            return res
        return {
            'code': 200,
            'msg': '设置成功',
            'data': {
                'uid': uid,
                'year': year,
                'month': month,
            }
        }

