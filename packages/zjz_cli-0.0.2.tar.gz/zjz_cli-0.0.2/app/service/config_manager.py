import os
import json
import tempfile
from pathlib import Path


class ConfigManager:
    def __init__(self):
        # 1. 确定配置目录：用户主目录下的 .zjz_cli
        self.cfg = {}
        self.config_dir = Path.home() / ".zjz_cli"
        # ~/.zjz_cli/config.json
        self.config_file = self.config_dir / "config.json"

        # 2. 确定缓存目录：系统的临时目录下的 zjz_cli_cache
        # gettempdir() 会自动处理 Windows 的 %TEMP% 或 Linux 的 /tmp
        # eg: /var/folders/fg/wqt2ts914bgf735xsd07yqk00000gn/T/zjz_cli_cache
        self.cache_dir = Path(tempfile.gettempdir()) / "zjz_cli_cache"

        # 3. 初始化：确保目录存在
        self.config_dir.mkdir(exist_ok=True)
        self.cache_dir.mkdir(exist_ok=True)

    def load_config(self) -> dict:
        """读取配置，如果不存在则返回默认空字典"""
        if not self.config_file.exists():
            return {}
        try:
            with open(self.config_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            return {}

    def init_config(self):
        self.cfg = self.load_config()

    def save_config(self, data: dict):
        """保存配置"""
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        self.cfg = data

    def update_config(self, key: str, value):
        """修改单个配置项"""
        config = self.load_config()
        config[key] = value
        self.save_config(config)

    def update_configs(self, data: dict):
        """修改多个配置"""
        config = self.load_config()
        for k, v in data.items():
            config[k] = v
        self.save_config(config)

    def get_config(self, key: str, default_val=None):
        return self.cfg.get(key, default_val)

    def get_abs_uid(self, uid: str) -> str:
        if uid:
            return uid
        return self.get_config('curr_uid', '')

    def get_cache_path(self, key: str) -> Path:
        """根据 key 获取缓存文件路径"""
        # 简单的文件名清洗，防止路径遍历攻击
        safe_key = key.replace("/", "_").replace("\\", "_")
        return self.cache_dir / safe_key

    def set_cache(self, key: str, content: str):
        """写入缓存"""
        path = self.get_cache_path(key)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)

    def get_cache(self, key: str) -> str | None:
        """读取缓存"""
        path = self.get_cache_path(key)
        if path.exists():
            with open(path, 'r', encoding='utf-8') as f:
                return f.read()
        return None

    def clear_cache(self):
        """清空所有缓存"""
        for file in self.cache_dir.iterdir():
            if file.is_file():
                file.unlink()


cfg_mgr = ConfigManager()
cfg_mgr.init_config()
