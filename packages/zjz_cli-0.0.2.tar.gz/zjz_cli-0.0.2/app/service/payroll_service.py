from app.api import zjz_api
from app.service.config_manager import cfg_mgr


class PayrollService:
    def get_payroll(self, uid: str, year: int, month: int) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        payroll_res = zjz_api.get_payroll(uid, year, month)
        if payroll_res.get('code') != 200:
            return payroll_res
        return {
            'code': 200,
            'msg': '',
            'data': {
                'uid': uid,
                'year': year,
                'month': month,
                'payroll': payroll_res.get('data').get('items'),
            }
        }

    def get_payroll_creation_status(self, uid: str, year: int, month: int) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        payroll_res = zjz_api.get_payroll_creation_status(uid, year, month)
        if payroll_res.get('code') != 200:
            return payroll_res
        data = payroll_res.get('data') | {
            'uid': uid,
            'year': year,
            'month': month,
        }
        return {
            'code': 200,
            'msg': '',
            'data': data
        }

    def get_preview_payroll(self, uid: str, year: int, month: int) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        payroll_res = zjz_api.get_preview_payroll(uid, year, month)
        if payroll_res.get('code') != 200:
            return payroll_res
        return {
            'code': 200,
            'msg': '',
            'data': {
                'uid': uid,
                'year': year,
                'month': month,
                'payroll': payroll_res.get('data'),
            }
        }

    def create_payroll(self, uid: str, year: int, month: int, data: list) -> dict:
        uid = cfg_mgr.get_abs_uid(uid)
        return zjz_api.create_payroll(uid, year, month, data)
