from app.api.zjz_req import zjz_req


def sms_verify_code(phone: str) -> dict:
    return zjz_req.get_client().post_json('login/sms', {
        'phone': phone,
    })


def verify_sms_code(phone: str, code: str) -> dict:
    return zjz_req.get_client().post_json('login/sms-2-token', {
        'phone': phone,
        'sms': code,
    })


def get_employee_list(uid: str = None, keyword: str = '', page: int = 1) -> dict:
    if not page or page < 1:
        page = 1
    return zjz_req.get_client().get('ryxx', params={
        'uid': uid,
        'keyword': keyword,
        'page': page
    })


def add_employee(uid: str, data: dict) -> dict:
    data['uid'] = uid
    return zjz_req.get_client().post_json('ryxx', data)


def update_employee(employee_id: str, data: dict) -> dict:
    return zjz_req.get_client().put('ryxx', {
        'id': employee_id,
        'data': data,
    })


def get_payroll(uid: str, year: int, month: int) -> dict:
    month_str = f"{year}-{month:02d}"
    return zjz_req.get_client().get('payroll', params={
        'uid': uid,
        'month': month_str
    })


def get_payroll_creation_status(uid: str, year: int, month: int) -> dict:
    month_str = f"{year}-{month:02d}"
    return zjz_req.get_client().get('payroll/creation-status', params={
        'uid': uid,
        'month': month_str
    })


def get_preview_payroll(uid: str, year: int, month: int) -> dict:
    month_str = f"{year}-{month:02d}"
    return zjz_req.get_client().get('payroll/preview', params={
        'uid': uid,
        'month': month_str
    })


def create_payroll(uid: str, year: int, month: int, data: list) -> dict:
    month_str = f"{year}-{month:02d}"
    return zjz_req.get_client().post_json('payroll', {
        'uid': uid,
        'month': month_str,
        'data': data
    })


def get_sales_invoice_data_list(uid: str, current: int = 1, invoice_number: str = '', invoice_date_begin: str = '', invoice_date_end: str = '', status: str = '') -> dict:
    return zjz_req.get_client().get('invoice/sales_invoice_data_list', params={
        'uid': uid,
        'current': current,
        'invoice_number': invoice_number,
        'invoice_date_begin': invoice_date_begin,
        'invoice_date_end': invoice_date_end,
        'status': status,
    })


def set_month_no_sales_invoice(uid: str, year: int, month: int) -> dict:
    return zjz_req.get_client().post_json('invoice/set_month_no_sales_invoice', {
        'uid': uid,
        'year': year,
        'month': month,
    })


def get_income_invoice_data_list(uid: str, current: int = 1, invoice_number: str = '', invoice_date_begin: str = '', invoice_date_end: str = '', status: str = '') -> dict:
    return zjz_req.get_client().get('invoice/income_invoice_data_list', params={
        'uid': uid,
        'current': current,
        'invoice_number': invoice_number,
        'invoice_date_begin': invoice_date_begin,
        'invoice_date_end': invoice_date_end,
        'status': status,
    })


def set_month_no_invoice(uid: str, year: int, month: int) -> dict:
    return zjz_req.get_client().post_json('invoice/set_month_no_invoice', {
        'uid': uid,
        'year': year,
        'month': month,
    })


def invoice_can_choose_use_list(uid: str, goods_name: str, total_tax_price: str, total_money: str) -> dict:
    return zjz_req.get_client().get('invoice/invoice_can_choose_use_list', params={
        'uid': uid,
        'goods_name': goods_name,
        'total_tax_price': total_tax_price,
        'total_money': total_money,
    })


def invoice_choose_use(uid: str, invoice_id: int, category: str, is_pay: str, payee: str) -> dict:
    return zjz_req.get_client().post_json('invoice/invoice_choose_use', {
        'uid': uid,
        'invoice_id': invoice_id,
        'category': category,
        'is_pay': is_pay,
        'payee': payee,
    })


def get_todo_list(uid: str = '') -> dict:
    params = {}
    if uid:
        params['uid'] = uid
    return zjz_req.get_client().get('todo-list', params=params)


def before_set_month_audited(year: int, month: int, uid: str = '') -> dict:
    params = {
        'year': year,
        'month': month,
    }
    if uid:
        params['uid'] = uid
    return zjz_req.get_client().get('audit/before_set_month_audited', params=params)


def set_month_audited(year: int, month: int, uid: str = '') -> dict:
    payload = {
        'year': year,
        'month': month,
    }
    if uid:
        payload['uid'] = uid
    return zjz_req.get_client().post_json('audit/set_month_audited', payload)


def get_bank_bill_data_list(uid: str, current: int = 1, date_begin: str = '', date_end: str = '') -> dict:
    params = {
        'current': current,
        'date_begin': date_begin,
        'date_end': date_end,
    }
    if uid:
        params['uid'] = uid
    return zjz_req.get_client().get('bank/bill_data_list', params=params)


def choose_bank_use(uid: str, bill_id: int, rule_text: str) -> dict:
    payload = {
        'id': bill_id,
        'rule_text': rule_text,
    }
    if uid:
        payload['uid'] = uid
    return zjz_req.get_client().post_json('bank/bank_bill_choose_use', payload)


def set_month_bank_no_water(uid: str, year: int, month: int) -> dict:
    payload = {
        'year': year,
        'month': month,
    }
    if uid:
        payload['uid'] = uid
    return zjz_req.get_client().post_json('bank/set_month_no_water', payload)
