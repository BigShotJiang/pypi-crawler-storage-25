from app.service.config_manager import cfg_mgr
from app.util.http_client import HttpClient


class ZjzReq:
    def __init__(self):
        self.headers = {}
        self.base_url: str = "https://www.zijizhang.com/ai/skill"
        self.client = None

    def get_client(self):
        auth_token = self.headers.get('Authorization')
        if not auth_token:
            token = cfg_mgr.get_config('token')
            if token:
                self.headers['Authorization'] = f'Bearer {token}'
                self.client = None
        if not self.client:
            self.client = HttpClient(base_url=self.base_url, headers=self.headers)
        return self.client

zjz_req = ZjzReq()