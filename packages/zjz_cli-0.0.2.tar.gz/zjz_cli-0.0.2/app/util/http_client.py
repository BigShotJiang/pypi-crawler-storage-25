import httpx
from typing import Any, Dict, Optional, Union


class HttpClient:
    def __init__(
        self,
        base_url: str = "",
        timeout: int = 60,
        headers: Optional[Dict[str, str]] = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers=headers or {},
        )

    def close(self):
        self.client.close()

    def _request(
        self,
        method: str,
        url: str,
        *,
        params: Optional[Dict] = None,
        headers: Optional[Dict] = None,
        json: Optional[Any] = None,
        data: Optional[Dict] = None,
        files: Optional[Dict] = None,
    ) -> httpx.Response:
        try:
            response = self.client.request(
                method=method,
                url=url,
                params=params,
                headers=headers,
                json=json,
                data=data,
                files=files,
            )
            response.raise_for_status()
            return response
        except httpx.HTTPStatusError as e:
            raise RuntimeError(f"HTTP错误: {e.response.status_code} {e.response.text}") from e
        except httpx.RequestError as e:
            raise RuntimeError(f"请求异常: {str(e)}") from e

    # -------- 基础方法 --------
    def get(self, url: str, **kwargs) -> Dict:
        return self._request("GET", url, **kwargs).json()

    def delete(self, url: str, **kwargs) -> Dict:
        return self._request("DELETE", url, **kwargs).json()

    def put(self, url: str, json: Optional[Any] = None, **kwargs) -> Dict:
        return self._request("PUT", url, json=json, **kwargs).json()

    # -------- POST 扩展 --------
    def post_json(self, url: str, json: Any, **kwargs) -> Dict:
        return self._request("POST", url, json=json, **kwargs).json()

    def post_form(self, url: str, data: Dict[str, Any], **kwargs) -> Dict:
        return self._request("POST", url, data=data, **kwargs).json()

    def post_file(
        self,
        url: str,
        files: Dict[str, Union[str, tuple]],
        data: Optional[Dict] = None,
        **kwargs,
    ) -> Dict:
        """
        files 示例：
        {
            "file": ("filename.txt", open("file.txt", "rb"), "text/plain")
        }
        """
        return self._request("POST", url, files=files, data=data, **kwargs).json()