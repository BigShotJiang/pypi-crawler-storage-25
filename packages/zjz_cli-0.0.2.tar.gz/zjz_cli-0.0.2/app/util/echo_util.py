import json
import typer


def echo_http_res(http_res: dict):
    fg = typer.colors.RED
    if http_res.get('code') == 200:
        fg = typer.colors.GREEN
    typer.secho(json.dumps(http_res, indent=4, ensure_ascii=False), fg=fg)
