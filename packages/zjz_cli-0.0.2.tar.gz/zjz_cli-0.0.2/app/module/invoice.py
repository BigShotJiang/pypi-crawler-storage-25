import typer

from app.service.invoice_service import InvoiceService
from app.util import echo_util

invoice_app = typer.Typer()


@invoice_app.command(
    name='get_sales_invoice_data_list',
    help="获取销项发票列表")
def get_sales_invoice_data_list(
        uid: str = typer.Option('', '--uid', help='用户uid'),
        current: int = typer.Option(1, '--current', help='页码'),
        invoice_number: str = typer.Option('', '--invoice_number', help='发票号码 关键字，指定发票号码查询，如果为空则查询全部'),
        invoice_date_begin: str = typer.Option('', '--invoice_date_begin', help='发票日期开始 关键字，指定发票日期开始查询（如果要使用，invoice_date_begin和invoice_date_end两个都需要），如果为空则不限制，日期格式为YYYY-MM-DD，例如2024-01-01'),
        invoice_date_end: str = typer.Option('', '--invoice_date_end', help='发票日期结束 关键字，指定发票日期结束查询（如果要使用，invoice_date_begin和invoice_date_end两个都需要），如果为空则不限制，日期格式为YYYY-MM-DD，例如2024-01-31'),
):
    service = InvoiceService()
    res = service.get_sales_invoice_data_list(uid, current, invoice_number, invoice_date_begin, invoice_date_end)
    echo_util.echo_http_res(res)


@invoice_app.command(
    name='get_income_invoice_data_list',
    help="获取进项/收到的发票列表")
def get_income_invoice_data_list(
        uid: str = typer.Option('', '--uid', help='用户uid'),
        current: int = typer.Option(1, '--current', help='页码'),
        invoice_number: str = typer.Option('', '--invoice_number', help='发票号码关键字（精确匹配），不传则查询全部'),
        invoice_date_begin: str = typer.Option('', '--invoice_date_begin', help='开票日期开始（YYYY-MM-DD；如需使用需与 invoice_date_end 同时传）'),
        invoice_date_end: str = typer.Option('', '--invoice_date_end', help='开票日期结束（YYYY-MM-DD；如需使用需与 invoice_date_begin 同时传）'),
        status: str = typer.Option('', '--status', help='发票状态（审核中/待确认/已拒绝/已入账），不传则查询全部'),
):
    service = InvoiceService()
    res = service.get_income_invoice_data_list(uid, current, invoice_number, invoice_date_begin, invoice_date_end, status)
    echo_util.echo_http_res(res)


@invoice_app.command(
    name='set_month_no_sales_invoice',
    help="标记某个月份无销项/开出的发票",
    no_args_is_help=True)
def set_month_no_sales_invoice(
    uid: str = typer.Option('', '--uid', help='用户uid'),
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
):
    service = InvoiceService()
    res = service.set_month_no_sales_invoice(uid, year, month)
    echo_util.echo_http_res(res)


@invoice_app.command(
    name='set_month_no_invoice',
    help="标记某个月份无进项/收到的发票",
    no_args_is_help=True)
def set_month_no_invoice(
    uid: str = typer.Option('', '--uid', help='用户uid'),
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
):
    service = InvoiceService()
    res = service.set_month_no_invoice(uid, year, month)
    echo_util.echo_http_res(res)


@invoice_app.command(
    name='invoice_can_choose_use_list',
    help="进项发票：查询可选用途列表",
    no_args_is_help=True)
def invoice_can_choose_use_list(
    uid: str = typer.Option('', '--uid', help='用户uid（不传则使用当前已切换在用的 uid）'),
    goods_name: str = typer.Option(..., '--goods_name', help='货物/服务名称（用于推荐用途）'),
    total_tax_price: str = typer.Option(..., '--total_tax_price', help='价税合计（建议传“元”，如 113.00）'),
    total_money: str = typer.Option(..., '--total_money', help='不含税金额（建议传“元”，如 100.00）'),
):
    service = InvoiceService()
    res = service.invoice_can_choose_use_list(uid, goods_name, total_tax_price, total_money)
    echo_util.echo_http_res(res)


@invoice_app.command(
    name='invoice_choose_use',
    help="进项发票：选择用途并入账",
    no_args_is_help=True)
def invoice_choose_use(
    uid: str = typer.Option('', '--uid', help='用户uid（不传则使用当前已切换在用的 uid）'),
    invoice_id: int = typer.Option(..., '--invoice_id', help='发票 id'),
    category: str = typer.Option(..., '--category', help='用途/类目（来自 invoice_can_choose_use_list.items[].id'),
    is_pay: str = typer.Option(..., '--is_pay', help='支付方式（对公银行支付/员工垫付/老板垫付/现金支付）'),
    payee: str = typer.Option(..., '--payee', help='垫付人/收款人（服务端会按支付方式校验）'),
):
    service = InvoiceService()
    res = service.invoice_choose_use(uid, invoice_id, category, is_pay, payee)
    echo_util.echo_http_res(res)
