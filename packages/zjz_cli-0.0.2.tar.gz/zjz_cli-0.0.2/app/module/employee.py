import json
import typer

from app.service.employee_service import EmployeeService
from app.util import echo_util

employee_app = typer.Typer()


@employee_app.command(
    name='get_employee_list',
    help="获取员工列表",
    epilog="""使用示例\n\nzjz_cli employee get_employee_list""")
def get_employee_list(
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid'),
        keyword: str = typer.Option('', '--keyword', help='姓名/证件号码 关键字，支持模糊搜索，如果为空则查询全部')
):
    service = EmployeeService()
    res = service.get_employee_list(uid, keyword)
    echo_util.echo_http_res(res)


@employee_app.command(
    name='add_employee',
    help="添加员工",
    no_args_is_help=True)
def add_employee(
        data: str = typer.Argument(..., help='员工信息的json字符串'),
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid')
):
    data_obj = json.loads(data)
    service = EmployeeService()
    res = service.add_employee(uid, data_obj)
    echo_util.echo_http_res(res)


@employee_app.command(
    name='update_employee',
    help='更新员工信息',
    no_args_is_help=True)
def update_employee(
        employee_id: str = typer.Argument(..., help='员工id'),
        data: str = typer.Argument(..., help='需要更新信息的json字符串')
):
    data_obj = json.loads(data)
    service = EmployeeService()
    res = service.update_employee(employee_id, data_obj)
    echo_util.echo_http_res(res)
