import typer

from app.service.todo_service import TodoService
from app.util import echo_util

todo_app = typer.Typer()


@todo_app.command(
    name='get_todo_list',
    help="获取代办列表")
def get_todo_list(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid（不传则使用当前已切换在用的 uid）'),
):
    service = TodoService()
    res = service.get_todo_list(uid)
    echo_util.echo_http_res(res)


@todo_app.command(
    name='before_set_month_audited',
    help="提交审账前确认",
    no_args_is_help=True)
def before_set_month_audited(
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid（不传则使用当前已切换在用的 uid）'),
):
    service = TodoService()
    res = service.before_set_month_audited(year, month, uid)
    echo_util.echo_http_res(res)


@todo_app.command(
    name='set_month_audited',
    help="提交审账",
    no_args_is_help=True)
def set_month_audited(
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid（不传则使用当前已切换在用的 uid）'),
):
    service = TodoService()
    res = service.set_month_audited(year, month, uid)
    echo_util.echo_http_res(res)
