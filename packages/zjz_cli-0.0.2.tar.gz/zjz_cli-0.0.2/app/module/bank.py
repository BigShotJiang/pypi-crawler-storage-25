import typer

from app.service.bank_service import BankService
from app.util import echo_util

bank_app = typer.Typer()


@bank_app.command(
    name='get_bank_bill_data_list',
    help="获取银行回单/流水列表")
def get_bank_bill_data_list(
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid（不传则使用当前已切换在用的 uid）'),
    current: int = typer.Option(1, '--current', help='页码，默认 1'),
    date_begin: str = typer.Option('', '--date_begin', help='交易日期开始（YYYY-MM-DD；如需使用需与 date_end 同时传）'),
    date_end: str = typer.Option('', '--date_end', help='交易日期结束（YYYY-MM-DD；如需使用需与 date_begin 同时传）'),
):
    service = BankService()
    res = service.get_bank_bill_data_list(uid, current, date_begin, date_end)
    echo_util.echo_http_res(res)


@bank_app.command(
    name='choose_bank_use',
    help="回单选择用途/入账",
    no_args_is_help=True)
def choose_bank_use(
    bill_id: int = typer.Argument(...,help='回单单据 id（来自 get_bank_bill_data_list 返回 bill_list[].id）'),
    rule_text: str = typer.Argument(..., help='用途文本（建议从 bill_list[].use_list 中选择）'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid（不传则使用当前已切换在用的 uid）'),
):
    service = BankService()
    res = service.choose_bank_use(uid, bill_id, rule_text)
    echo_util.echo_http_res(res)


@bank_app.command(
    name='set_month_bank_no_water',
    help="标记某个月份无银行回单/流水",
    no_args_is_help=True)
def set_month_bank_no_water(
    year: int = typer.Argument(..., help='年份，如 2026'),
    month: int = typer.Argument(..., help='月份(1-12)，如 3'),
    uid: str = typer.Option('', '--uid', help='公司唯一标识uid（不传则使用当前已切换在用的 uid）'),
):
    service = BankService()
    res = service.set_month_bank_no_water(uid, year, month)
    echo_util.echo_http_res(res)

