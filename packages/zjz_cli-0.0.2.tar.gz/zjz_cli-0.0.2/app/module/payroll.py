import json
import typer

from app.service.payroll_service import PayrollService
from app.util import echo_util

payroll_app = typer.Typer()


def parse_month(month_str: str) -> tuple:
    try:
        parts = month_str.split('-')
        if len(parts) != 2:
            raise typer.BadParameter("格式必须为 yyyy-mm，例如 2026-04")
        year = int(parts[0])
        month_val = int(parts[1])
        if not (1 <= month_val <= 12):
            raise typer.BadParameter("月份必须在 1 到 12 之间")
        return year, month_val
    except ValueError:
        raise typer.BadParameter("年份和月份必须是数字，例如 2026-04")


@payroll_app.command(
    name='get_payroll',
    help="获取工资单",
    epilog="""使用示例\n\nzjz_cli payroll get_payroll 2026-04""")
def get_payroll(
        month: str = typer.Argument(..., help='工资单月份，如 2026-04'),
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid')
):
    req_year, req_month = parse_month(month)
    service = PayrollService()
    res = service.get_payroll(uid, req_year, req_month)
    echo_util.echo_http_res(res)


@payroll_app.command(
    name='get_payroll_creation_status',
    help="获取工资单创建状态",
    no_args_is_help=True)
def get_payroll_creation_status(
        month: str = typer.Argument(..., help='按月时间，如 2026-04'),
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid')
):
    req_year, req_month = parse_month(month)
    service = PayrollService()
    res = service.get_payroll_creation_status(uid, req_year, req_month)
    echo_util.echo_http_res(res)


@payroll_app.command(
    name='get_preview_payroll',
    help="获取预览工资单",
    no_args_is_help=True)
def get_preview_payroll(
        month: str = typer.Argument(..., help='工资单月份，如 2026-04'),
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid')
):
    req_year, req_month = parse_month(month)
    service = PayrollService()
    res = service.get_preview_payroll(uid, req_year, req_month)
    echo_util.echo_http_res(res)


@payroll_app.command(
    name='create_payroll',
    help='创建工资单',
    no_args_is_help=True)
def create_payroll(
        month: str = typer.Argument(..., help='工资单月份，如 2026-04'),
        data: str = typer.Argument(..., help='工资单列表的json字符串'),
        uid: str = typer.Option('', '--uid', help='公司唯一标识uid')
):
    req_year, req_month = parse_month(month)
    data_obj = json.loads(data)
    service = PayrollService()
    res = service.create_payroll(uid, req_year, req_month, data_obj)
    echo_util.echo_http_res(res)
