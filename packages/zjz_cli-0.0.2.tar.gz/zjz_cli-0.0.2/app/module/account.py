import typer

from app.service.account_service import AccountService
from app.util import echo_util

account_app = typer.Typer()


@account_app.command(
    name='get_sms_verify_code',
    help='获取登录的短信验证码',
    no_args_is_help=True)
def get_sms_verify_code(phone: str = typer.Argument(..., help='自记账的登录手机号')):
    service = AccountService()
    res = service.sms_verify_code(phone)
    echo_util.echo_http_res(res)


@account_app.command(
    name='verify_sms_code',
    help='通过短信验证码登录',
    no_args_is_help=True)
def verify_sms_code(
        phone: str = typer.Argument(..., help='手机号'),
        code: str = typer.Argument(..., help='短信验证码')):
    service = AccountService()
    res = service.sms_code_login(phone, code)
    echo_util.echo_http_res(res)


@account_app.command(
    name='get_switchable_users',
    help='获取可切换的公司列表')
def get_switchable_users():
    service = AccountService()
    res = service.get_switchable_user()
    echo_util.echo_http_res(res)


@account_app.command(
    name='switch_to',
    help='切换公司',
    no_args_is_help=True)
def switch_to(uid: str = typer.Argument(..., help='公司唯一标识uid')):
    service = AccountService()
    res = service.switch_to(uid)
    echo_util.echo_http_res(res)
