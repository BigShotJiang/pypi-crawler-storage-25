## zjz_cli

Cli tool for zjz

### Use VENV

```shell
mkdir .venv
cd .venv
python3.12 -m venv .
source .venv/bin/activate
```

### Install dependence

```shell
pip install -r requirements.txt
```

### Build

#### For pyinstaller

```shell
pyinstaller --onefile --name zjz_cli --clean --noupx main.py
```

### For Pypi

```shell
python -m build
```

### Dependence

If you add dependence, add here

```shell
pip install typer
pip install pyinstaller
pip install httpx
pip install --upgrade build twine
```

### Export requirements

If you add dependence, export it

```shell
pip freeze > requirements.txt
```
