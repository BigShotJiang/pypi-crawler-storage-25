import typer

from app.module.account import account_app
from app.module.employee import employee_app
from app.module.bank import bank_app
from app.module.payroll import payroll_app
from app.module.invoice import invoice_app
from app.module.todo import todo_app

app = typer.Typer(
    name="zjz_cli",
    help="自记账的cli工具箱",
    add_completion=True
)

app.add_typer(account_app, name="account")
app.add_typer(employee_app, name="employee")
app.add_typer(bank_app, name="bank")
app.add_typer(invoice_app, name="invoice")
app.add_typer(payroll_app, name="payroll")
app.add_typer(todo_app, name="todo")

if __name__ == '__main__':
    app()
