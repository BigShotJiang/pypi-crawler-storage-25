"""
### Tribulnation Kucoin
> An SDK to connect Kucoin with the Tribulnation ecosystem.

- Details
"""