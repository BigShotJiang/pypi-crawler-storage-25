# Tribulnation Kucoin SDK

> An SDK to connect Kucoin with the Tribulnation ecosystem.

🚧 Under construction.