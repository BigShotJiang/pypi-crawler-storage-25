//! Error conversion from FlowgentraError to typed Python exceptions.
//!
//! Mapping rationale:
//!
//! | FlowgentraError variant          | Python exception         | Reason |
//! |----------------------------------|--------------------------|--------|
//! | NodeNotFound                     | KeyError                 | Missing key in a dict/registry |
//! | InvalidEdge, InvalidStateTransition, ValidationError | ValueError | Bad value / schema |
//! | ConfigError, YamlError           | ValueError               | Bad configuration |
//! | TimeoutError, ExecutionTimeout   | TimeoutError             | Standard Python timeout |
//! | IoError                          | OSError                  | File / network I/O |
//! | SerializationError               | ValueError               | Bad data shape |
//! | CycleDetected, RecursionLimitExceeded, NoTerminationPath | RecursionError | Graph cycle/limit |
//! | All others                       | RuntimeError             | Generic runtime failure |

use pyo3::prelude::*;
use pyo3::exceptions::{
    PyKeyError, PyOSError, PyRecursionError, PyRuntimeError, PyTimeoutError, PyValueError,
};
use flowgentra_ai::core::error::FlowgentraError;

/// Convert a `FlowgentraError` to the most appropriate Python exception type.
///
/// Each variant is mapped to a semantically matching built-in Python exception
/// so that callers can catch specific error categories without inspecting the
/// message string.
pub fn to_py_err(e: FlowgentraError) -> PyErr {
    let hint = e.hint();
    let msg = match hint {
        Some(h) => format!("{}\nHint: {}", e, h),
        None => format!("{}", e),
    };

    match &e {
        // ── Missing node / key ──────────────────────────────────────────────
        FlowgentraError::NodeNotFound(_) => PyKeyError::new_err(msg),

        // ── Bad values / schemas ────────────────────────────────────────────
        FlowgentraError::ValidationError(_)
        | FlowgentraError::InvalidEdge(_)
        | FlowgentraError::InvalidStateTransition(_)
        | FlowgentraError::ConfigError(_)
        | FlowgentraError::YamlError(_)
        | FlowgentraError::SerializationError(_) => PyValueError::new_err(msg),

        // ── Timeout ─────────────────────────────────────────────────────────
        FlowgentraError::TimeoutError | FlowgentraError::ExecutionTimeout(_) => {
            PyTimeoutError::new_err(msg)
        }

        // ── I/O ─────────────────────────────────────────────────────────────
        FlowgentraError::IoError(_) => PyOSError::new_err(msg),

        // ── Cycle / recursion ───────────────────────────────────────────────
        FlowgentraError::CycleDetected
        | FlowgentraError::RecursionLimitExceeded { .. }
        | FlowgentraError::NoTerminationPath { .. } => PyRecursionError::new_err(msg),

        // ── Everything else → RuntimeError ──────────────────────────────────
        _ => PyRuntimeError::new_err(msg),
    }
}

/// Convert any `Display` error to a Python `RuntimeError`.
///
/// Use this for non-`FlowgentraError` types (e.g. `VectorStoreError`,
/// `sqlx::Error`) where no semantic mapping is possible.
pub fn to_py_err_generic(e: impl std::fmt::Display) -> PyErr {
    PyRuntimeError::new_err(format!("{}", e))
}
