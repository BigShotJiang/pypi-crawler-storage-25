"""Tool registry, execution, and built-in tools.

This module provides interfaces for registering tools, executing tool calls,
and includes built-in implementations of common tools.

Examples:
    Register and use tools:

        from flowgentra_ai.tools import ToolRegistry, ToolNode, create_tool_node

        registry = ToolRegistry()
        tool_node = ToolNode(registry)
        
        # Add tool node to graph
        builder.add_node("tools", tool_node)
        
    Use built-in tools:
    
        from flowgentra_ai.tools import CalculatorTool, WebRequestTool
        
        calc = CalculatorTool()
        web = WebRequestTool()
"""

from flowgentra_ai._native import tools as _t

ToolCallRequest = _t.ToolCallRequest
ToolCallResult = _t.ToolCallResult
ToolRegistry = _t.ToolRegistry
JsonSchema = _t.JsonSchema
ToolNode = _t.ToolNode
create_tool_node = _t.py_create_tool_node
store_tool_calls = _t.py_store_tool_calls
check_tools_condition = _t.py_check_tools_condition
CalculatorTool = _t.CalculatorTool
SearchTool = _t.SearchTool
WebRequestTool = _t.WebRequestTool
FilesTool = _t.FilesTool

__all__ = [
    # Core types
    "ToolCallRequest",
    "ToolCallResult",
    "ToolRegistry",
    "JsonSchema",
    # Tool node execution
    "ToolNode",
    "create_tool_node",
    "store_tool_calls",
    "check_tools_condition",
    # Built-in tools
    "CalculatorTool",
    "SearchTool",
    "WebRequestTool",
    "FilesTool",
]
