"""Graph and state management for workflow execution.

This module provides the core graph building and execution APIs compatible with LangGraph.

Examples:
    Build a simple state graph:

        from flowgentra_ai.graph import StateGraph, END

        class MyState(TypedDict):
            messages: List[str]
            score: float

        def process_node(state: dict) -> dict:
            return {"messages": state["messages"] + ["processed"]}

        builder = StateGraph(MyState)
        builder.add_node("process", process_node)
        builder.set_entry_point("process")
        builder.add_edge("process", END)
        graph = builder.compile()
"""

from flowgentra_ai._native import graph as _g, nodes as _n

StateGraph = _g.StateGraph
CompiledGraph = _g.CompiledGraph
END = _g.END
MessageGraph = _n.MessageGraph
MessageGraphBuilder = _n.MessageGraphBuilder

__all__ = [
    "StateGraph",
    "CompiledGraph",
    "MessageGraph",
    "MessageGraphBuilder",
    "END",
]
