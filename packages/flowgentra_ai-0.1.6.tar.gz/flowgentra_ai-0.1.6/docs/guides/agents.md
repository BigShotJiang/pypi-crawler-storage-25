# Agents

An **agent** is a graph that loops: it reasons, picks an action (usually a tool call or an LLM call), observes the result, and repeats — until it has a final answer.

Flowgentra provides multiple ways to create agents, from simple builder patterns to advanced memory-aware multi-user systems.

---

## Creating Agents: Overview

### Method 1: AgentBuilder with Predefined Strategy (Simple)

Use built-in agent types for the most common scenarios.

```python
from flowgentra_ai.agent import AgentBuilder, AgentType

agent = (
    AgentBuilder(AgentType.zero_shot_react())
    .with_name("my_agent")
    .with_llm_config("gpt-4")
    .build_graph()
)
```

### Method 2: Agent.from_config_path() (Production)

YAML-based configuration for production deployments. Best for complex workflows.

```python
from flowgentra_ai.agent import Agent

agent = Agent.from_config_path("./agent_config.yaml")
```

### Method 3: MemoryAwareAgent (Multi-User)

Automatically manages per-user memory and conversation history.

```python
from flowgentra_ai.agent import MemoryAwareAgent

agent = MemoryAwareAgent(
    base_agent=graph,
    memory_type="conversation",
    max_messages=100
)

# Each user gets isolated memory
result = agent.run_with_user_id("user-123", "What is quantum computing?")
```

### Method 4: Custom Graph-Based Agent

Build custom logic by composing a StateGraph manually.

```python
from flowgentra_ai.graph import StateGraph, END
from flowgentra_ai.agent import ToolNode

builder = StateGraph()
builder.add_node("llm", llm_node)
builder.add_node("tools", ToolNode(registry))
builder.set_entry_point("llm")
builder.add_edge("llm", "tools")
builder.add_edge("tools", "llm")
```

---

## Predefined Agent Types

Flowgentra provides four built-in agent strategies optimized for different scenarios.

### ZeroShotReAct: Reasoning without Examples

**Constructor:**
```python
AgentType.zero_shot_react(
    temperature: float = 0.7,
    max_tokens: int = 2048,
    retries: int = 0
) -> ZeroShotReActConfig
```

The classic ReAct (Reason + Act) loop. The agent reasons step-by-step, decides which tool to call, observes the result, and loops until it has an answer — **without** needing example demonstrations.

**Internal Loop:**
```
Input Query
    │
    ▼
[LLM: Reason]  ◄──────────────────────────────┐
    │ "I need to search for..."               │
    ▼                                          │
[Decide]                                       │
    │                                          │
    ├─► Tool call? YES ──► [Execute Tools]    │
    │       │              │ (get observation)│
    │       └──────────────┴──────────────────┘
    │
    └─► Tool call? NO ───► [Generate Answer]
```

**Parameters:**
- `temperature` (float): Randomness (0.0 = deterministic, 1.0 = creative), default 0.7
- `max_tokens` (int): Max tokens in LLM response, default 2048
- `retries` (int): Retry failed LLM calls, default 0

**Best for:**
- ✅ General-purpose tasks with tools
- ✅ Information gathering (search, APIs, databases)
- ✅ Calculations and text processing
- ✅ When you don't have examples to learn from

**Example:**
```python
from flowgentra_ai.agent import AgentBuilder, AgentType, ToolSpec

# Define tools
search = ToolSpec("web_search", "Search the web for current information")
search.add_parameter("query", "string")
search.set_required("query")

calc = ToolSpec("calculator", "Solve math problems")
calc.add_parameter("expression", "string")
calc.set_required("expression")

# Build agent
agent = (
    AgentBuilder(AgentType.zero_shot_react(temperature=0.2, max_tokens=2000))
    .with_name("research-assistant")
    .with_llm_config("gpt-4")
    .with_tool(search)
    .with_tool(calc)
    .with_system_prompt("You are a research assistant. Think step by step and cite sources.")
    .with_temperature(0.2)  # Lower for more focused reasoning
    .with_max_tokens(2000)
    .with_retries(2)        # Retry failed LLM calls up to 2 times
    .build_graph()
)

# Execute
result = agent.execute_input("What is 2847 × 3.14? Show your reasoning.")
print(result)
```

---

### FewShotReAct: Improved Accuracy with Examples

**Constructor:**
```python
AgentType.few_shot_react(
    examples: List[Example],
    temperature: float = 0.7,
    max_tokens: int = 2048,
    retries: int = 0
) -> FewShotReActConfig
```

Same loop as ZeroShotReAct, but the system prompt includes worked examples. This dramatically improves performance for specialized domains where you can provide 2-5 demonstrations.

**Parameters:**
- `examples` (List[Example]): Worked examples showing reasoning steps (1-5 recommended)
- `temperature` (float): Randomness, default 0.7
- `max_tokens` (int): Max tokens, default 2048
- `retries` (int): Retry LLM calls, default 0

**Example Structure:**
```python
class Example:
    query: str          # User question
    reasoning: str      # Step-by-step thinking
    tool_calls: List[str]  # Which tools were used
    answer: str         # Final answer
```

**Best for:**
- ✅ Specialized domains (finance, legal, medical)
- ✅ When you have 2-5 good reference examples
- ✅ Tasks requiring consistent reasoning patterns
- ✅ Improving accuracy over ZeroShot

**Example:**
```python
from flowgentra_ai.agent import AgentBuilder, AgentType, Example, ToolSpec

# Define examples
examples = [
    Example(
        query="What was Tesla's Q3 revenue in 2023?",
        reasoning="""
        Thought: I need to find Tesla's Q3 2023 financial results.
        Action: Call search_api with query "Tesla Q3 2023 revenue"
        Observation: Tesla reported $23.85B in Q3 2023 revenue
        Thought: I have the answer.
        """,
        tool_calls=["search_api"],
        answer="Tesla's Q3 2023 revenue was $23.85 billion."
    ),
    Example(
        query="Calculate the revenue growth rate",
        reasoning="""
        Thought: I need Q3 2023 revenue ($23.85B) and previous data
        Action: Call calculator with "23.85 - 22.5"
        Observation: 1.35
        Thought: Growth rate = (1.35/22.5) * 100 = 6%
        """,
        tool_calls=["calculator"],
        answer="Revenue grew approximately 6% compared to Q3 2022."
    )
]

# Build agent with examples
agent = (
    AgentBuilder(AgentType.few_shot_react(examples=examples))
    .with_name("finance-analyzer")
    .with_llm_config("gpt-4")
    .with_tool(data_tool)
    .with_memory_steps(12)  # Remember last 12 reasoning steps
    .build_graph()
)

result = agent.execute_input("What was Apple's revenue growth in 2023?")
```

---

### Conversational: Multi-Turn Dialogue

**Constructor:**
```python
AgentType.conversational(
    memory_type: str = "rolling_window",
    max_messages: int = 20,
    temperature: float = 0.7,
    system_prompt: str = ""
) -> ConversationalConfig
```

Multi-turn dialogue with persistent conversation history. The agent remembers previous messages and uses context from earlier turns.

**Parameters:**
- `memory_type` (str): "rolling_window" (keep last N messages) or "summary" (compress old turns)
- `max_messages` (int): Max messages to keep in context, default 20
- `temperature` (float): Randomness, default 0.7
- `system_prompt` (str): Initial system instruction

**Memory Strategies:**
- **"rolling_window"** (default): Keep the last N messages verbatim. Fast and simple.
- **"summary"**: Use LLM to compress older messages into summaries. Better for long conversations.

**Best for:**
- ✅ Chatbots and virtual assistants
- ✅ Multi-turn customer support
- ✅ Interactive learning systems
- ✅ When conversation context matters

**Example:**
```python
from flowgentra_ai.agent import AgentBuilder, AgentType

# Simple conversational agent (no tools)
agent = (
    AgentBuilder(AgentType.conversational(
        memory_type="rolling_window",
        max_messages=30
    ))
    .with_name("support-bot")
    .with_llm_config("gpt-4")
    .with_temperature(0.7)
    .with_max_tokens(1000)
    .with_system_prompt("""
        You are a friendly customer support representative for TechCorp.
        - Be helpful and professional
        - Remember what the user told you earlier
        - Offer solutions based on their situation
    """)
    .build_graph()
)

# Multi-turn conversation
turn1 = agent.execute_input("Hi, I can't log into my account")
# → "I'll help you regain access. Can you tell me your email?"

turn2 = agent.execute_input("It's alice@example.com")
# → "Thanks Alice! Have you tried resetting your password?"

turn3 = agent.execute_input("I tried but I didn't get the reset email")
# Agent remembers: email is alice@example.com, can't log in, reset didn't work
# → "Let me check if your email is on our system... I found it. Let me send a reset link manually..."
```

**With Tools and Conversation:**
```python
# Conversational agent with tool access (support tickets, accounts, etc)
agent = (
    AgentBuilder(AgentType.conversational(max_messages=20))
    .with_name("support-agent")
    .with_llm_config("gpt-4")
    .with_tool(lookup_account_tool)
    .with_tool(check_email_tool)
    .with_tool(create_ticket_tool)
    .build_graph()
)

# Agent can remember context AND use tools
result = agent.execute_input("My name is Bob and I want to close my account")
# Agent: "Got it Bob. Can you tell me why you want to close your account?"

result = agent.execute_input("I'm moving to a new provider")
# Agent remembers Bob wants to close account, reason is switching providers
# Agent: "I understand. Before we proceed, I should note you have 3 active services..."
```

---

### Custom Agent Graph

For full control over agent behavior, build a custom StateGraph with your own nodes and routing logic.

```python
from flowgentra_ai.graph import StateGraph, END
from flowgentra_ai.agent import ToolNode
from flowgentra_ai.tools import ToolRegistry

# Create tool registry
registry = ToolRegistry()
registry.register("search", search_fn)
registry.register("calculator", calc_fn)

# Define custom nodes
def llm_reasoning_node(state):
    """Make LLM decision: which tool to call or answer."""
    client = LLMClient.from_config(LLMConfig("openai", "gpt-4"))
    response = client.chat([Message.user(state["query"])])
    state["llm_response"] = response.content
    state["tool_calls"] = parse_tool_calls(response)
    return state

def custom_router(state):
    """Route to tool execution or end."""
    if state.get("tool_calls"):
        return "execute_tools"
    else:
        return "__end__"

# Build graph
builder = StateGraph()
builder.add_node("llm", llm_reasoning_node)
builder.add_node("tools", ToolNode(registry))
builder.set_entry_point("llm")
builder.add_conditional_edge("llm", custom_router)
builder.add_edge("tools", "llm")
graph = builder.compile()

# Execute
result = graph.invoke(State({"query": "What's 15 × 27?"}))
```

---

## AgentBuilder: Complete API

### Constructor

```python
AgentBuilder(strategy: AgentType) -> AgentBuilder
```

**Parameters:**
- `strategy` (AgentType): Agent type (ZeroShotReAct, FewShotReAct, Conversational, etc.)

**Returns:** AgentBuilder instance

### Configuration Methods

All builder methods return `self` for chaining.

```python
builder.with_name(name: str) -> AgentBuilder
builder.with_llm_config(model: str, api_key: Optional[str] = None) -> AgentBuilder
builder.with_temperature(temp: float) -> AgentBuilder
builder.with_max_tokens(tokens: int) -> AgentBuilder
builder.with_retries(retries: int) -> AgentBuilder
builder.with_system_prompt(prompt: str) -> AgentBuilder
builder.with_tool(tool: ToolSpec) -> AgentBuilder
builder.with_memory_steps(steps: int) -> AgentBuilder
builder.with_timeout_ms(ms: int) -> AgentBuilder
```

**Method Details:**

| Method | Parameters | Returns | Purpose |
|--------|-----------|---------|---------|
| `with_name` | `name: str` | AgentBuilder | Set agent name for logging |
| `with_llm_config` | `model: str, api_key: Optional[str]` | AgentBuilder | Configure LLM (e.g., "gpt-4") |
| `with_temperature` | `temp: float (0.0-1.0)` | AgentBuilder | Set LLM randomness |
| `with_max_tokens` | `tokens: int` | AgentBuilder | Set max response length |
| `with_retries` | `retries: int` | AgentBuilder | Retry failed LLM calls |
| `with_system_prompt` | `prompt: str` | AgentBuilder | Set system instruction |
| `with_tool` | `tool: ToolSpec` | AgentBuilder | Add callable tool |
| `with_memory_steps` | `steps: int` | AgentBuilder | Keep last N steps in context |
| `with_timeout_ms` | `ms: int` | AgentBuilder | Set execution timeout |

### Build Methods

```python
graph = builder.build_graph() -> StateGraph
```

Returns a compiled StateGraph executable with `invoke()`, `stream()`, etc.

**Example:**
```python
agent = (
    AgentBuilder(AgentType.zero_shot_react())
    .with_name("my-agent")
    .with_llm_config("gpt-4")
    .with_temperature(0.3)
    .with_max_tokens(1500)
    .with_system_prompt("You are helpful.")
    .with_tool(search_tool)
    .with_tool(calc_tool)
    .with_retries(2)
    .build_graph()
)
```

---

## Agent: from_config_path

For production deployments, define agents in YAML configuration files.

```python
agent = Agent.from_config_path(
    config_path: str,
    handlers_module: Optional[str] = None
) -> Agent
```

**Parameters:**
- `config_path` (str): Path to agent configuration YAML file
- `handlers_module` (Optional[str]): Python module with handler functions

**YAML Configuration:**
```yaml
name: my-agent
version: "1.0"
llm:
  provider: openai
  model: gpt-4
  temperature: 0.7
  max_tokens: 2000
memory:
  type: rolling_window
  max_messages: 20
tools:
  - web_search
  - calculator
graph:
  entry_point: classify_input
  nodes:
    - name: classify_input
      handler: classify_input_handler
    - name: search
      handler: search_handler
    - name: final_answer
      handler: final_answer_handler
  edges:
    - from: classify_input
      to: search
      condition: needs_search
    - from: classify_input
      to: final_answer
      condition: direct_answer
    - from: search
      to: final_answer
```

---

## MemoryAwareAgent: Multi-User Support

**Constructor:**
```python
MemoryAwareAgent(
    base_agent: StateGraph,
    memory_config: MemoryConfig,
    checkpointer: Optional[Checkpointer] = None
) -> MemoryAwareAgent
```

Per-user memory management for multi-user systems. Each user gets isolated conversation history.

**Parameters:**
- `base_agent` (StateGraph): Compiled agent graph
- `memory_config` (MemoryConfig): Memory configuration
- `checkpointer` (Optional[Checkpointer]): For persistence across restarts

**Methods:**

```python
# Set current user thread
agent.set_thread_id(user_id: str) -> None

# Execute one turn
result = agent.run_turn(input: str) -> str

# Get current thread
current = agent.thread_id() -> str

# Get memory statistics
stats = agent.memory_stats() -> MemoryStats

# Clear current user's memory
agent.clear_memory() -> None

# Get memory for inspection
memory = agent.get_memory(user_id: str) -> List[Message]
```

**MemoryConfig:**
```python
MemoryConfig(
    memory_type: str = "conversation",  # "conversation", "token_buffer", "summary"
    max_tokens: int = 10000,            # Max tokens stored
    compression_interval: int = 5,       # Compress every N turns
    include_system_message: bool = True
)
```

**Example:**
```python
from flowgentra_ai.agent import MemoryAwareAgent, MemoryConfig
from flowgentra_ai.memory import FileCheckpointer

# Build base agent
agent_graph = (
    AgentBuilder(AgentType.conversational())
    .with_llm_config("gpt-4")
    .with_system_prompt("You are a helpful assistant.")
    .build_graph()
)

# Wrap with multi-user memory
memory_config = MemoryConfig(
    memory_type="conversation",
    max_tokens=20000,
    compression_interval=10
)
checkpointer = FileCheckpointer("./agent_memory")

agent = MemoryAwareAgent(agent_graph, memory_config, checkpointer)

# User Alice
agent.set_thread_id("alice")
r1 = agent.run_turn("Hi! I'm Alice and I live in Paris.")
r2 = agent.run_turn("What city do I live in?")  # Remembers "Paris"

# User Bob - completely separate
agent.set_thread_id("bob")
r3 = agent.run_turn("I'm Bob, from New York")
r4 = agent.run_turn("What's my city?")  # Remembers "New York", not "Paris"

# Memory usage
stats = agent.memory_stats()
print(f"Alice's memory: {stats.message_count} messages, ~{stats.tokens} tokens")
```

---
    result = agent.run()
    print(result["response"])

    # With checkpointing
    result = agent.run_with_thread("session-123")
    ```

---

## ToolSpec: Defining Tools

```python
tool = ToolSpec(name: str, description: str) -> ToolSpec
```

Describe a tool's interface so agents know how to call it.

**Methods:**
```python
tool.add_parameter(name: str, param_type: str) -> ToolSpec
tool.set_required(name: str) -> ToolSpec
tool.set_optional(name: str, default: Any = None) -> ToolSpec
tool.set_description(desc: str) -> ToolSpec
```

**Parameter Types:** `"string"`, `"number"`, `"integer"`, `"boolean"`, `"array"`, `"object"`

**Example:**
```python
calculator = ToolSpec("calculator", "Solve mathematical expressions")
calculator.add_parameter("expression", "string")
calculator.set_required("expression")
calculator.set_description("Mathematical expression like '2 + 3 * 4'")

file_reader = ToolSpec("read_file", "Read contents of a text file")
file_reader.add_parameter("path", "string")
file_reader.add_parameter("encoding", "string")
file_reader.set_required("path")
file_reader.set_optional("encoding", "utf-8")

api_caller = ToolSpec("make_request", "Make HTTP requests")
api_caller.add_parameter("url", "string")
api_caller.add_parameter("method", "string")
api_caller.add_parameter("headers", "object")
api_caller.add_parameter("body", "object")
api_caller.set_required("url")
api_caller.set_optional("method", "GET")
```

---

## Agent Execution API

### From Graph (AgentBuilder result)

```python
result = graph.invoke(state: State) -> State
result = graph.invoke_with_thread(thread_id: str, state: State) -> State

async for node_name, state in graph.stream(state: State):
    print(f"✓ {node_name}")
```

### From Agent (Config-based)

```python
result = agent.run() -> dict
result = agent.run_with_thread(thread_id: str) -> dict
result = agent.get_state(key: str) -> Any
agent.set_state(key: str, value: Any) -> None
```

### From MemoryAwareAgent

```python
agent.set_thread_id(user_id: str) -> None
result = agent.run_turn(input: str) -> str
thread = agent.thread_id() -> str
stats = agent.memory_stats() -> MemoryStats
agent.clear_memory() -> None
```

---

## Best Practices for Agent Design

### 1. Choose the Right Agent Type

| Your Use Case | Recommended Type |
|---------------|-----------------|
| General Q&A with tools | **ZeroShotReAct** |
| Specialized domain (finance, legal) | **FewShotReAct** with examples |
| Chatbot / multi-turn conversation | **Conversational** |
| Complex production workflow | **Agent.from_config_path** |
| Multi-user system | **MemoryAwareAgent** wrapper |

### 2. Design Tools Carefully

**Good tool design:**
```python
# ✓ Simple, single purpose
search = ToolSpec("web_search", "Search the web for factual information")
search.add_parameter("query", "string")
search.set_required("query")

# ✓ Clear descriptions
weather = ToolSpec("get_current_weather", "Get real-time weather for a location")
weather.add_parameter("location", "string")
weather.add_parameter("unit", "string")  # "celsius" or "fahrenheit"
```

**Poor tool design:**
```python
# ✗ Too broad/ambiguous
do_everything = ToolSpec("api_call", "Call APIs")

# ✗ Missing required parameters
search = ToolSpec("search", "Search")  # What kind of search?

# ✗ Confusing names
tool = ToolSpec("foo", "Does stuff")
```

### 3. Use Temperature Appropriately

```python
# For analytical/deterministic reasoning
.with_temperature(0.1)  # Very focused, same answer each time

# For creative tasks
.with_temperature(0.9)  # More varied, creative responses

# Default/balanced
.with_temperature(0.7)  # Most scenarios
```

### 4. Set Reasonable Limits

```python
# Prevent runaway executions
.with_max_tokens(2000)       # Limit response length
.with_retries(2)              # Don't retry forever
.with_timeout_ms(30000)       # 30-second timeout
```

### 5. Provide Good System Prompts

```python
# Good: Specific role and task
system_prompt = """You are a customer support agent for TechCorp.
- Be professional and empathetic
- Escalate to human if issue is complex
- Reference customer's account history when available"""

# Poor: Too vague
system_prompt = "You are helpful"
```

### 6. Use Few-Shot Examples for Specialized Domains

```python
# If you have domain-specific reasoning patterns, show examples
agent = AgentBuilder(AgentType.few_shot_react(
    examples=[
        Example(query="...", reasoning="...", tool_calls=[...], answer="..."),
        Example(query="...", reasoning="...", tool_calls=[...], answer="..."),
    ]
))
```

### 7. Monitor for Common Issues

```python
# Infinite loops: Agent keeps calling tools without progress
→ Use max_steps or timeout constraints

# Hallucination: Agent makes up tool responses
→ Implement strict tool result validation

# Context overload: Too many messages in memory
→ Use memory compression or rolling window

# Tool misuse: Agent calls wrong tool repeatedly
→ Improve tool descriptions and examples
```

### 8. Test Agents Thoroughly

```python
# Test with edge cases
test_queries = [
    "What is 2+2?",              # Simple math
    "Tell me about quantum physics",  # General knowledge
    "What's the weather tomorrow in Tokyo?",  # Tool usage
    "Who is the current president of Mars?",  # Should refuse
]

for query in test_queries:
    result = agent.execute_input(query)
    print(f"Q: {query}")
    print(f"A: {result}\n")
```

---

## Common Agent Patterns

### Research Assistant (ZeroShotReAct)

```python
research_agent = (
    AgentBuilder(AgentType.zero_shot_react())
    .with_name("researcher")
    .with_llm_config("gpt-4")
    .with_tool(search_web_tool)
    .with_tool(fetch_url_tool)
    .with_tool(summarize_tool)
    .with_system_prompt("""You are a research assistant.
        1. Search for relevant information
        2. Fetch and read sources
        3. Summarize findings with citations
    """)
    .build_graph()
)
```

### Customer Support Chatbot (Conversational + Tools)

```python
support_agent = (
    AgentBuilder(AgentType.conversational(max_messages=20))
    .with_name("support-bot")
    .with_llm_config("gpt-4")
    .with_tool(lookup_customer_tool)
    .with_tool(check_order_tool)
    .with_tool(create_refund_tool)
    .with_system_prompt("""You are a helpful support agent.
        - Greet customers warmly
        - Look up their account when needed
        - Resolve issues or escalate appropriately
    """)
    .build_graph()
)
```

### Code Analysis Agent (ZeroShotReAct)

```python
code_agent = (
    AgentBuilder(AgentType.zero_shot_react())
    .with_name("code-analyzer")
    .with_llm_config("gpt-4")
    .with_tool(read_file_tool)
    .with_tool(run_tests_tool)
    .with_tool(lint_tool)
    .with_system_prompt("""You are a code analysis expert.
        - Read relevant source files
        - Run tests to understand behavior
        - Identify issues and suggest improvements
    """)
    .with_temperature(0.2)  # Analytical
    .build_graph()
)
```

### Multi-User Chatbot (MemoryAwareAgent)

```python
# Base agent
base_agent = (
    AgentBuilder(AgentType.conversational())
    .with_name("chatbot")
    .with_llm_config("gpt-4")
    .with_system_prompt("You are a helpful chatbot.")
    .build_graph()
)

# Wrap for multi-user
memory_agent = MemoryAwareAgent(
    base_agent,
    MemoryConfig(memory_type="conversation", max_tokens=50000),
    checkpointer=FileCheckpointer("./agent_memory")
)

# Use
memory_agent.set_thread_id("user-alice")
response = memory_agent.run_turn("Hi, I'm Alice")
response = memory_agent.run_turn("What's my name?")  # Remembers "Alice"
```

---
