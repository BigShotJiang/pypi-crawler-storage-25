import logging
import textwrap
from typing import Callable, Final, Generator, List, Tuple, override

from mutagen._tags import PaddingInfo
from mutagen.aiff import AIFF
from mutagen.id3 import ID3
from mutagen.id3._frames import APIC, TALB, TCMP, TCON, TIT2, TPE1, TPE2, TPOS, TPUB, TRCK, TSO2, TSOA, TSOP, TXXX, UFID
from mutagen.id3._specs import Encoding
from mutagen.mp3 import MP3

from ..config import ID3v1Policy
from ..picture.scan import PictureScanner
from .base_mutagen import AbstractMutagenTagger
from .types import BasicTag, Picture, PictureType

logger: Final = logging.getLogger(__name__)

BASIC_ID3_TEXT_FRAMES: Final[Tuple[Tuple[BasicTag, str], ...]] = (
    (BasicTag.ALBUM, "TALB"),
    (BasicTag.ALBUMSORT, "TSOA"),
    (BasicTag.ALBUMARTIST, "TPE2"),
    (BasicTag.ALBUMARTISTSORT, "TSO2"),
    (BasicTag.ARTIST, "TPE1"),
    (BasicTag.ARTISTSORT, "TSOP"),
    (BasicTag.BARCODE, "TXXX:BARCODE"),
    (BasicTag.COMPILATION, "TCMP"),
    (BasicTag.MUSICBRAINZ_ALBUMARTISTID, "TXXX:MusicBrainz Album Artist Id"),
    (BasicTag.MUSICBRAINZ_ALBUMID, "TXXX:MusicBrainz Album Id"),
    (BasicTag.MUSICBRAINZ_ALBUMRELEASECOUNTRY, "TXXX:MusicBrainz Album Release Country"),
    (BasicTag.MUSICBRAINZ_ALBUMRELEASETYPE, "TXXX:MusicBrainz Album Release Type"),
    (BasicTag.MUSICBRAINZ_ARRANGERID, "TXXX:MusicBrainz Arranger Id"),
    (BasicTag.MUSICBRAINZ_ARTISTID, "TXXX:MusicBrainz Artist Id"),
    (BasicTag.MUSICBRAINZ_COMPOSERID, "TXXX:MusicBrainz Composer Id"),
    (BasicTag.MUSICBRAINZ_CONDUCTORID, "TXXX:MusicBrainz Conductor Id"),
    (BasicTag.MUSICBRAINZ_DIRECTORID, "TXXX:MusicBrainz Director Id"),
    (BasicTag.MUSICBRAINZ_DISCID, "TXXX:MusicBrainz Disc Id"),
    (BasicTag.MUSICBRAINZ_LYRICISTID, "TXXX:MusicBrainz Lyricist Id"),
    (BasicTag.MUSICBRAINZ_MIXERID, "TXXX:MusicBrainz Mixer Id"),
    (BasicTag.MUSICBRAINZ_ORIGINALALBUMID, "TXXX:MusicBrainz Original Album Id"),
    (BasicTag.MUSICBRAINZ_ORIGINALARTISTID, "TXXX:MusicBrainz Original Artist Id"),
    (BasicTag.MUSICBRAINZ_ORIGINALRELEASEID, "TXXX:MusicBrainz Original Release Id"),
    (BasicTag.MUSICBRAINZ_PRODUCERID, "TXXX:MusicBrainz Producer Id"),
    (BasicTag.MUSICBRAINZ_RELEASEARTISTID, "TXXX:MusicBrainz Release Artist Id"),
    (BasicTag.MUSICBRAINZ_RELEASEGROUPID, "TXXX:MusicBrainz Release Group Id"),
    (BasicTag.MUSICBRAINZ_RELEASETRACKID, "TXXX:MusicBrainz Release Track Id"),
    (BasicTag.MUSICBRAINZ_REMIXERID, "TXXX:MusicBrainz Remixer Id"),
    # also UFID:http://musicbrainz.org is track id / musicbrainz_recordingid
    (BasicTag.MUSICBRAINZ_TRMID, "TXXX:MusicBrainz TRM Id"),
    (BasicTag.MUSICBRAINZ_WORKID, "TXXX:MusicBrainz Work Id"),
    (BasicTag.ORGANIZATION, "TPUB"),
    # nonstandard: this tagger will read and remove it but will not set it (OTOH, maybe should be treated same as e.g. OLD_LABEL)
    (BasicTag.RELEASECOUNTRY, "TXXX:RELEASECOUNTRY"),  # nonstandard
    (BasicTag.RELEASETYPE, "TXXX:RELEASETYPE"),  # nonstandard
    #
    (BasicTag.TITLE, "TIT2"),
    # TCON too but we use .genres instead of .text
    # TRCK and TPOS too but they are not 1:1
)
UFID_MUSICBRAINZ_OWNER: Final = "http://musicbrainz.org"

# TODO also pull other common values, like
# "composer": "tcom",
# "encoder": "tenc",
# "date": "tdrc",  # recordingdate?

TAG_TO_ID3_TEXT_FRAME: Final = dict(BASIC_ID3_TEXT_FRAMES)


class AbstractId3Tagger[_FT: MP3 | AIFF](AbstractMutagenTagger[_FT]):
    _picture_scanner: PictureScanner
    _id3v1: ID3v1Policy

    def _get_file(self) -> _FT: ...
    def _ensure_id3(self) -> ID3: ...
    def _save(self) -> None: ...

    def __init__(self, picture_scanner: PictureScanner, padding: Callable[[PaddingInfo], int], id3v1: ID3v1Policy):
        super().__init__(padding)
        self._picture_scanner = picture_scanner
        self._id3v1 = id3v1

    def get_pictures(self) -> Generator[Tuple[Picture, bytes], None, None]:
        tags: ID3 = self._file.tags  # type: ignore
        picture_frames: list[APIC] = tags.getall("APIC") if tags else []  # pyright: ignore[reportUnknownVariableType, reportUnknownMemberType]
        for frame in picture_frames:  # pyright: ignore[reportUnknownVariableType]
            image_data: bytes = bytes(frame.data)  # type: ignore
            picture_type = PictureType(frame.type)  # type: ignore
            expect_mime_type = str(frame.mime) if frame.mime and isinstance(frame.mime, str) else "Unknown"  # type: ignore
            description = str(frame.desc)  # type: ignore

            picture_info = self._picture_scanner.scan(image_data, expect_mime_type)
            picture = Picture(picture_info, picture_type, description)
            yield (picture, image_data)

    @override
    def _add_picture(self, new_picture: Picture, image_data: bytes) -> None:
        id3 = self._ensure_id3()
        description = new_picture.description
        apic = APIC(mime=new_picture.picture_info.mime_type, type=new_picture.type, data=image_data, desc=description)
        # with future mutagen 1.48 or later, docs indicate we will be able to ensure distinct hash key like this:
        # while apic.HashKey in tags:
        #     apic.salt += "x"
        while apic.HashKey in id3:  # TODO don't alter description
            description += " "
            apic = APIC(mime=new_picture.picture_info.mime_type, type=new_picture.type, data=image_data, desc=description)
        id3.add(apic)  # pyright: ignore[reportUnknownMemberType]

    @override
    def _remove_picture(self, remove_picture: Picture) -> None:
        if not self._get_file().tags:  # pyright: ignore[reportUnknownMemberType]
            logger.warning(f"could not remove {remove_picture.type.name} picture from {self._get_file().filename}: no ID3 tag")
            return
        id3 = self._ensure_id3()  # pyright: ignore[reportUnknownVariableType, reportUnknownMemberType]
        pictures = list((pic, data) for pic, data in self.get_pictures() if pic != remove_picture)
        id3.delall("APIC")  # pyright: ignore[reportUnknownMemberType]
        for pic, data in pictures:
            self._add_picture(pic, data)

    @override
    def get_tags(self) -> Tuple[Tuple[BasicTag, Tuple[str, ...]], ...]:
        basic_tags: list[Tuple[BasicTag, Tuple[str, ...]]] = []
        if self._get_file().tags:  # pyright: ignore[reportUnknownMemberType]
            id3 = self._ensure_id3()
            basic_tags.extend((tag, tuple(_must_get_text(id3, frame))) for tag, frame in BASIC_ID3_TEXT_FRAMES if frame in id3)

            if "TCON" in id3:
                basic_tags.append((BasicTag.GENRE, tuple(id3["TCON"].genres)))  # pyright: ignore[reportUnknownArgumentType, reportUnknownMemberType]

            ufid_frame = f"UFID:{UFID_MUSICBRAINZ_OWNER}"
            if ufid_frame in id3:
                ufid_data = bytes(id3[ufid_frame].data)  # pyright: ignore[reportUnknownArgumentType, reportUnknownMemberType]
                basic_tags.append((BasicTag.MUSICBRAINZ_TRACKID, (ufid_data.decode("ascii"),)))

            (track_number, track_total) = self._get_trck()
            if track_number is not None:
                basic_tags.append((BasicTag.TRACKNUMBER, (track_number,)))
            if track_total is not None:
                basic_tags.append((BasicTag.TRACKTOTAL, (track_total,)))

            (disc_number, disc_total) = self._get_tpos()
            if disc_number is not None:
                basic_tags.append((BasicTag.DISCNUMBER, (disc_number,)))
            if disc_total is not None:
                basic_tags.append((BasicTag.DISCTOTAL, (disc_total,)))

        return tuple(basic_tags)

    @override
    def _set_tag(self, tag: BasicTag, value: str | List[str] | None):
        tags = self._ensure_id3()
        if value is None:
            match tag:
                case BasicTag.GENRE:
                    del tags["TCON"]
                case BasicTag.DISCNUMBER:
                    (_, disc_total) = self._get_tpos()
                    self._set_tpos(None, disc_total)
                case BasicTag.DISCTOTAL:
                    (disc_number, _) = self._get_tpos()
                    self._set_tpos(disc_number, None)
                case BasicTag.MUSICBRAINZ_TRACKID:
                    del tags[f"UFID:{UFID_MUSICBRAINZ_OWNER}"]
                case BasicTag.OLD_ALBUM_ARTIST | BasicTag.OLD_LABEL | BasicTag.OLD_PUBLISHER | BasicTag.OLD_TOTAL_DISCS:
                    logger.warning(f"don't know how to remove {tag.name} from ID3 tag in {self._get_file().filename}")
                case BasicTag.TRACKNUMBER:
                    (_, track_total) = self._get_trck()
                    self._set_trck(None, track_total)
                case BasicTag.TRACKTOTAL:
                    (track_number, _) = self._get_trck()
                    self._set_trck(track_number, None)
                case _:
                    del tags[TAG_TO_ID3_TEXT_FRAME[tag]]
        else:
            value_list = value if isinstance(value, List) else [value]
            match tag:
                case BasicTag.ALBUM:
                    tags["TALB"] = TALB(encoding=Encoding.UTF8, text=value_list)
                case BasicTag.ALBUMSORT:
                    tags["TSOA"] = TSOA(encoding=Encoding.UTF8, text=value_list)
                case BasicTag.ALBUMARTIST:
                    tags["TPE2"] = TPE2(encoding=Encoding.UTF8, text=value_list)
                case BasicTag.ALBUMARTISTSORT:
                    tags["TSO2"] = TSO2(encoding=Encoding.UTF8, text=value_list)
                case BasicTag.ARTIST:
                    tags["TPE1"] = TPE1(encoding=Encoding.UTF8, text=value_list)
                case BasicTag.ARTISTSORT:
                    tags["TSOP"] = TSOP(encoding=Encoding.UTF8, text=value_list)
                case BasicTag.COMPILATION:
                    if value_list and value_list[0]:
                        tags["TCMP"] = TCMP(encoding=Encoding.UTF8, text=["1"])
                    elif "TCMP" in tags:
                        del tags["TCMP"]
                case BasicTag.DISCNUMBER:
                    (_, disc_total) = self._get_tpos()
                    self._set_tpos(value_list[0] if value_list[0] else None, disc_total)
                case BasicTag.DISCTOTAL:
                    (disc_number, _) = self._get_tpos()
                    self._set_tpos(disc_number, value_list[0] if value_list[0] else None)
                case BasicTag.GENRE:
                    tags["TCON"] = TCON(encoding=Encoding.UTF8, text=value_list)
                case BasicTag.MUSICBRAINZ_TRACKID:
                    tags[f"UFID:{UFID_MUSICBRAINZ_OWNER}"] = UFID(owner=UFID_MUSICBRAINZ_OWNER, data=bytes(value_list[0], "utf-8"))
                case (
                    BasicTag.OLD_ALBUM_ARTIST
                    | BasicTag.OLD_LABEL
                    | BasicTag.OLD_PUBLISHER
                    | BasicTag.OLD_TOTAL_DISCS
                    | BasicTag.RELEASECOUNTRY
                    | BasicTag.RELEASETYPE
                ):
                    raise ValueError(f"cannot set {tag.name} in ID3 tag on {self._get_file().filename}")
                case BasicTag.ORGANIZATION:
                    tags["TPUB"] = TPUB(encoding=Encoding.UTF8, text=value_list)
                case BasicTag.TITLE:
                    tags["TIT2"] = TIT2(encoding=Encoding.UTF8, text=value_list)
                case BasicTag.TRACKNUMBER:
                    (_, track_total) = self._get_trck()
                    self._set_trck(value_list[0] if value_list[0] else None, track_total)
                case BasicTag.TRACKTOTAL:
                    (track_number, _) = self._get_trck()
                    self._set_trck(track_number, value_list[0] if value_list[0] else None)
                case _:
                    frame = TAG_TO_ID3_TEXT_FRAME[tag]
                    if not frame.startswith("TXXX:"):
                        raise RuntimeError(f"unexpected frame {frame}")
                    [_, description] = frame.split(":", 1)
                    tags[frame] = TXXX(encoding=Encoding.UTF8, desc=description, text=value_list)

    def _get_tpos(self) -> Tuple[str | None, str | None]:
        values = _get_text(self._get_file().tags, "TPOS")  # pyright: ignore[reportUnknownArgumentType, reportUnknownMemberType]
        value = values[0] if values else None
        if value is None:
            return (None, None)
        # else
        if str.count(value, "/") == 1:
            (disc_number, disc_total) = value.split("/")
            return (disc_number, disc_total)
        # else
        return (value, None)

    def _get_trck(self) -> Tuple[str | None, str | None]:
        values = _get_text(self._get_file().tags, "TRCK")  # pyright: ignore[reportUnknownArgumentType, reportUnknownMemberType]
        value = values[0] if values else None
        if value is None:
            return (None, None)
        # else
        if str.count(value, "/") == 1:
            (track_number, track_total) = value.split("/")
            return (track_number, track_total)
        # else
        return (value, None)

    def _set_tpos(self, disc_number: str | None, disc_total: str | None):
        if disc_number is None and disc_total is None:
            value = None
        elif disc_total is None:
            value = disc_number
        elif disc_number is None:
            value = f"/{disc_total}"
        else:
            value = f"{disc_number}/{disc_total}"

        id3 = self._ensure_id3()
        if value is None and "TPOS" in id3:
            del id3["TPOS"]
        elif value is not None and "TPOS" not in id3:
            id3.add(TPOS(encoding=Encoding.UTF8, text=[value]))  # pyright: ignore[reportUnknownMemberType]
        elif value is not None and id3["TPOS"].text != [value]:  # pyright: ignore[reportUnknownMemberType]
            id3["TPOS"] = TPOS(encoding=Encoding.UTF8, text=[value])

    def _set_trck(self, track_number: str | None, track_total: str | None):
        if track_number is None and track_total is None:
            value = None
        elif track_total is None:
            value = track_number
        elif track_number is None:
            value = f"/{track_total}"
        else:
            value = f"{track_number}/{track_total}"

        id3 = self._ensure_id3()
        if value is None and "TRCK" in id3:
            del id3["TRCK"]
        elif value is not None and "TRCK" not in id3:
            id3.add(TRCK(encoding=Encoding.UTF8, text=[value]))  # pyright: ignore[reportUnknownMemberType]
        elif value is not None and id3["TRCK"].text != [value]:  # pyright: ignore[reportUnknownMemberType]
            id3["TRCK"] = TRCK(encoding=Encoding.UTF8, text=[value])


def _get_text(id3: ID3 | None, frame_name: str):
    if id3 is None:
        return None
    if frame_name not in id3:
        return None
    return _must_get_text(id3, frame_name)


def _must_get_text(id3: ID3, frame_name: str):
    frame = id3[frame_name]  # pyright: ignore[reportUnknownVariableType]
    if hasattr(frame, "text") and isinstance(frame.text, list) and len(frame.text):  # pyright: ignore[reportUnknownArgumentType, reportUnknownMemberType]
        return [str(text) for text in frame.text]  # pyright: ignore[reportUnknownArgumentType, reportUnknownVariableType, reportUnknownMemberType]
    # fallback if this does not look like a text frame
    return [textwrap.shorten(str(frame), width=4096)]  # pyright: ignore[reportUnknownArgumentType]
