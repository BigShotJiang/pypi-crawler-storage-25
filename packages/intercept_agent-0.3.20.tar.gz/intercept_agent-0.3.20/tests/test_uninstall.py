"""Tests for the uninstall reporting feature."""

import logging
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import httpx
import yaml
from click.testing import CliRunner

from posture_agent.main import cli
from posture_agent.services.reporter import report_uninstall


def _write_config(config_dir: Path, api_url: str = "https://api.example.com", api_key: str = "hsk_testkey123") -> Path:
    """Write a valid agent.yaml config and return the config file path."""
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / "agent.yaml"
    config_file.write_text(yaml.dump({
        "api": {
            "url": api_url,
            "api_key": api_key,
        },
    }))
    return config_file


def _make_mock_client(status_code: int = 204):
    """Create a mock httpx.Client context manager returning a given status code."""
    mock_response = MagicMock()
    mock_response.status_code = status_code

    mock_client = MagicMock()
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=False)
    mock_client.post.return_value = mock_response
    return mock_client


def _make_error_client(error: Exception):
    """Create a mock httpx.Client that raises on post."""
    mock_client = MagicMock()
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=False)
    mock_client.post.side_effect = error
    return mock_client


class TestReportUninstallSuccess:
    """Test the happy path of uninstall reporting."""

    def test_successful_report_204(self, tmp_path):
        """A 204 response should log success."""
        config_dir = tmp_path / ".config" / "intercept"
        _write_config(config_dir)

        mock_client = _make_mock_client(204)

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             patch("posture_agent.services.reporter.get_machine_fingerprint", return_value="ff" * 16), \
             patch("httpx.Client", return_value=mock_client):
            report_uninstall()

        # Verify the POST was made
        mock_client.post.assert_called_once()

    def test_correct_url_construction(self, tmp_path):
        """The uninstall URL should be correctly constructed from the config URL."""
        config_dir = tmp_path / ".config" / "intercept"
        _write_config(config_dir, api_url="https://api.example.com")

        captured = {}

        mock_client = _make_mock_client(204)
        original_post = mock_client.post

        def capture_post(url, **kwargs):
            captured["url"] = url
            captured["headers"] = kwargs.get("headers", {})
            captured["json"] = kwargs.get("json", {})
            return original_post(url, **kwargs)

        mock_client.post = capture_post

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             patch("posture_agent.services.reporter.get_machine_fingerprint", return_value="ff" * 16), \
             patch("httpx.Client", return_value=mock_client):
            report_uninstall()

        assert captured["url"] == "https://api.example.com/api/v1/core/posture/uninstall"

    def test_trailing_slash_stripped_from_url(self, tmp_path):
        """Trailing slashes on the API URL should be stripped."""
        config_dir = tmp_path / ".config" / "intercept"
        _write_config(config_dir, api_url="https://api.example.com/")

        captured = {}
        mock_client = _make_mock_client(204)

        def capture_post(url, **kwargs):
            captured["url"] = url
            resp = MagicMock()
            resp.status_code = 204
            return resp

        mock_client.post = capture_post

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             patch("posture_agent.services.reporter.get_machine_fingerprint", return_value="ff" * 16), \
             patch("httpx.Client", return_value=mock_client):
            report_uninstall()

        assert captured["url"] == "https://api.example.com/api/v1/core/posture/uninstall"

    def test_correct_headers_sent(self, tmp_path):
        """The X-API-Key header should be set from the config."""
        config_dir = tmp_path / ".config" / "intercept"
        _write_config(config_dir, api_key="hsk_testkey00000000")

        captured = {}
        mock_client = _make_mock_client(204)

        def capture_post(url, **kwargs):
            captured["headers"] = kwargs.get("headers", {})
            resp = MagicMock()
            resp.status_code = 204
            return resp

        mock_client.post = capture_post

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             patch("posture_agent.services.reporter.get_machine_fingerprint", return_value="ff" * 16), \
             patch("httpx.Client", return_value=mock_client):
            report_uninstall()

        assert captured["headers"]["X-API-Key"] == "hsk_testkey00000000"

    def test_correct_body_sent(self, tmp_path):
        """The request body should contain the machine_fingerprint."""
        config_dir = tmp_path / ".config" / "intercept"
        _write_config(config_dir)

        captured = {}
        mock_client = _make_mock_client(204)

        def capture_post(url, **kwargs):
            captured["json"] = kwargs.get("json", {})
            resp = MagicMock()
            resp.status_code = 204
            return resp

        mock_client.post = capture_post

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             patch("posture_agent.services.reporter.get_machine_fingerprint", return_value="aabb1122" * 4), \
             patch("httpx.Client", return_value=mock_client):
            report_uninstall()

        assert captured["json"] == {"machine_fingerprint": "aabb1122" * 4}

    def test_timeout_is_5_seconds(self, tmp_path):
        """The httpx client should use a 5-second timeout."""
        config_dir = tmp_path / ".config" / "intercept"
        _write_config(config_dir)

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             patch("posture_agent.services.reporter.get_machine_fingerprint", return_value="ff" * 16), \
             patch("httpx.Client") as mock_client_cls:
            mock_instance = _make_mock_client(204)
            mock_client_cls.return_value = mock_instance
            report_uninstall()

        mock_client_cls.assert_called_once()
        call_kwargs = mock_client_cls.call_args[1]
        assert call_kwargs["timeout"] == 5
        assert "User-Agent" in call_kwargs["headers"]
        assert call_kwargs["headers"]["User-Agent"].startswith("Intercept-Agent/")


class TestReportUninstallSkipConditions:
    """Test that the function gracefully skips when config is missing or incomplete."""

    def test_no_config_file(self, tmp_path, caplog):
        """When no config file exists, the function should skip and log a warning."""
        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             caplog.at_level(logging.WARNING, logger="posture_agent.services.reporter"):
            report_uninstall()

        assert any("No config file found" in msg for msg in caplog.messages)

    def test_no_api_url(self, tmp_path, caplog):
        """When the config has no API URL, the function should skip."""
        config_dir = tmp_path / ".config" / "intercept"
        _write_config(config_dir, api_url="", api_key="hsk_test")

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             caplog.at_level(logging.WARNING, logger="posture_agent.services.reporter"):
            report_uninstall()

        assert any("No API URL" in msg for msg in caplog.messages)

    def test_no_api_key(self, tmp_path, caplog):
        """When the config has no API key, the function should skip."""
        config_dir = tmp_path / ".config" / "intercept"
        _write_config(config_dir, api_key="")

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             caplog.at_level(logging.WARNING, logger="posture_agent.services.reporter"):
            report_uninstall()

        assert any("No valid API key" in msg for msg in caplog.messages)

    def test_non_hsk_api_key(self, tmp_path, caplog):
        """When the API key doesn't start with hsk_, the function should skip."""
        config_dir = tmp_path / ".config" / "intercept"
        _write_config(config_dir, api_key="invalid_key_format")

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             caplog.at_level(logging.WARNING, logger="posture_agent.services.reporter"):
            report_uninstall()

        assert any("No valid API key" in msg for msg in caplog.messages)

    def test_empty_config_file(self, tmp_path, caplog):
        """An empty config file should not crash — should log and skip."""
        config_dir = tmp_path / ".config" / "intercept"
        config_dir.mkdir(parents=True)
        config_file = config_dir / "agent.yaml"
        config_file.write_text("")

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             caplog.at_level(logging.WARNING, logger="posture_agent.services.reporter"):
            report_uninstall()

        # Empty YAML -> no api section -> no URL -> should warn
        assert any("No API URL" in msg for msg in caplog.messages)


class TestReportUninstallErrorHandling:
    """Test that errors are caught and never propagate."""

    def test_connection_error_caught(self, tmp_path, caplog):
        """A connection error should be caught — uninstall must not fail."""
        config_dir = tmp_path / ".config" / "intercept"
        _write_config(config_dir)

        mock_client = _make_error_client(httpx.ConnectError("Connection refused"))

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             patch("posture_agent.services.reporter.get_machine_fingerprint", return_value="ff" * 16), \
             patch("httpx.Client", return_value=mock_client), \
             caplog.at_level(logging.WARNING, logger="posture_agent.services.reporter"):
            # This must NOT raise
            report_uninstall()

        assert any("Failed to report uninstall" in msg for msg in caplog.messages)

    def test_timeout_error_caught(self, tmp_path, caplog):
        """A timeout error should be caught — uninstall must not fail."""
        config_dir = tmp_path / ".config" / "intercept"
        _write_config(config_dir)

        mock_client = _make_error_client(httpx.TimeoutException("Timed out"))

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             patch("posture_agent.services.reporter.get_machine_fingerprint", return_value="ff" * 16), \
             patch("httpx.Client", return_value=mock_client), \
             caplog.at_level(logging.WARNING, logger="posture_agent.services.reporter"):
            report_uninstall()

        assert any("Failed to report uninstall" in msg for msg in caplog.messages)

    def test_non_204_response_does_not_raise(self, tmp_path, caplog):
        """A non-204 response should log a warning but not raise."""
        config_dir = tmp_path / ".config" / "intercept"
        _write_config(config_dir)

        mock_client = _make_mock_client(500)

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             patch("posture_agent.services.reporter.get_machine_fingerprint", return_value="ff" * 16), \
             patch("httpx.Client", return_value=mock_client), \
             caplog.at_level(logging.WARNING, logger="posture_agent.services.reporter"):
            report_uninstall()

        assert any("HTTP 500" in msg for msg in caplog.messages)

    def test_fingerprint_error_caught(self, tmp_path, caplog):
        """If fingerprint generation fails, it should be caught."""
        config_dir = tmp_path / ".config" / "intercept"
        _write_config(config_dir)

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             patch("posture_agent.services.reporter.get_machine_fingerprint", side_effect=RuntimeError("ioreg failed")), \
             caplog.at_level(logging.WARNING, logger="posture_agent.services.reporter"):
            report_uninstall()

        assert any("Failed to report uninstall" in msg for msg in caplog.messages)

    def test_corrupt_yaml_caught(self, tmp_path, caplog):
        """A corrupt YAML config should be caught."""
        config_dir = tmp_path / ".config" / "intercept"
        config_dir.mkdir(parents=True)
        config_file = config_dir / "agent.yaml"
        config_file.write_text(": : : invalid yaml [[[")

        with patch("posture_agent.services.reporter.Path.home", return_value=tmp_path), \
             caplog.at_level(logging.WARNING, logger="posture_agent.services.reporter"):
            report_uninstall()

        assert any("Failed to report uninstall" in msg for msg in caplog.messages)


class TestUninstallCLIIntegration:
    """Test that the uninstall CLI command calls report_uninstall."""

    def test_uninstall_calls_report_before_cleanup(self):
        """The uninstall command should call report_uninstall before removing files."""
        call_order = []

        def mock_report():
            call_order.append("report_uninstall")

        original_exists = Path.exists

        def mock_plist_exists(self):
            if str(self).endswith(".plist"):
                call_order.append("plist_check")
                return False
            return original_exists(self)

        runner = CliRunner()
        with patch("posture_agent.main.report_uninstall", side_effect=mock_report), \
             patch.object(Path, "exists", mock_plist_exists), \
             patch("posture_agent.main.get_settings") as mock_settings:
            mock_settings.return_value.logging_config = {}
            mock_settings.return_value.debug = False
            result = runner.invoke(cli, ["uninstall"])

        assert result.exit_code == 0
        assert "Reporting uninstall to API" in result.output
        assert "Agent uninstalled" in result.output
        # report_uninstall must come before plist cleanup
        assert call_order.index("report_uninstall") < call_order.index("plist_check")

    def test_uninstall_proceeds_when_report_fails(self):
        """If report_uninstall raises (shouldn't happen, but defense-in-depth),
        the uninstall should still complete."""
        runner = CliRunner()
        with patch("posture_agent.main.report_uninstall", side_effect=RuntimeError("boom")), \
             patch("posture_agent.main.get_settings") as mock_settings:
            mock_settings.return_value.logging_config = {}
            mock_settings.return_value.debug = False
            # The CLI should still fail because of the unhandled exception from report_uninstall
            # But the function itself is designed to never raise. This test validates
            # that even if it somehow did, the behavior is observable.
            result = runner.invoke(cli, ["uninstall"])
            # Click catches exceptions and reports exit_code=1
            # This is expected since we're simulating a bug in report_uninstall
            assert result.exit_code != 0

    def test_uninstall_purge_works_with_report(self, tmp_path):
        """The --purge flag should still work after reporting."""
        runner = CliRunner()
        with patch("posture_agent.main.report_uninstall"), \
             patch("posture_agent.main.PLIST_PATH", tmp_path / "fake.plist"), \
             patch("posture_agent.main.get_settings") as mock_settings:
            mock_settings.return_value.logging_config = {}
            mock_settings.return_value.debug = False
            result = runner.invoke(cli, ["uninstall", "--purge"])

        assert result.exit_code == 0
        assert "Agent uninstalled" in result.output
