"""Tests for MCP server config parsing and shell utilities."""

import asyncio
import json
from pathlib import Path
from unittest.mock import patch

from posture_agent.collectors.mcp_servers import (
    MCPServersCollector,
    detect_risk_indicators,
    parse_mcp_config,
)
from posture_agent.utils.shell import _get_expanded_path, check_version, run_command


class TestParseMCPConfig:
    """Test MCP config file parsing."""

    def test_parse_standard_config(self, tmp_path):
        config = {
            "mcpServers": {
                "github": {
                    "command": "npx",
                    "args": ["-y", "@modelcontextprotocol/server-github"],
                    "env": {"GITHUB_TOKEN": "xxx"},
                },
                "filesystem": {
                    "command": "node",
                    "args": ["/path/to/fs-server.js"],
                },
            }
        }
        config_path = tmp_path / "mcp.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "claude")
        assert len(servers) == 2

        github_server = [s for s in servers if s["name"] == "github"][0]
        assert github_server["command"] == "npx"
        assert github_server["transport"] == "stdio"
        assert "GITHUB_TOKEN" in github_server["env_keys"]
        assert "credentials" in github_server["risk_indicators"]

    def test_parse_sse_transport(self, tmp_path):
        config = {
            "mcpServers": {
                "remote": {
                    "url": "https://example.com/mcp",
                    "transport": "sse",
                },
            }
        }
        config_path = tmp_path / "mcp.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "claude")
        assert len(servers) == 1
        assert servers[0]["transport"] == "sse"
        assert servers[0]["url"] == "https://example.com/mcp"
        assert "network" in servers[0]["risk_indicators"]

    def test_parse_url_without_explicit_transport(self, tmp_path):
        config = {
            "mcpServers": {
                "remote": {
                    "url": "https://example.com/mcp",
                },
            }
        }
        config_path = tmp_path / "mcp.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "claude")
        assert servers[0]["transport"] == "sse"  # default for url-based

    def test_parse_continue_format(self, tmp_path):
        config = {
            "mcpServers": {
                "my-server": {
                    "command": "node",
                    "args": ["server.js"],
                },
            }
        }
        config_path = tmp_path / "config.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "continue")
        assert len(servers) == 1
        assert servers[0]["tool"] == "continue"

    def test_parse_invalid_json(self, tmp_path):
        config_path = tmp_path / "mcp.json"
        config_path.write_text("not valid json {{{")

        servers = parse_mcp_config(config_path, "claude")
        assert servers == []

    def test_parse_missing_file(self, tmp_path):
        config_path = tmp_path / "nonexistent.json"
        servers = parse_mcp_config(config_path, "claude")
        assert servers == []

    def test_parse_non_dict_server_skipped(self, tmp_path):
        config = {
            "mcpServers": {
                "valid": {"command": "node", "args": ["server.js"]},
                "invalid": "not a dict",
                "also-invalid": 42,
            }
        }
        config_path = tmp_path / "mcp.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "claude")
        assert len(servers) == 1
        assert servers[0]["name"] == "valid"

    def test_parse_empty_mcp_servers(self, tmp_path):
        config = {"mcpServers": {}}
        config_path = tmp_path / "mcp.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "claude")
        assert servers == []

    def test_parse_no_mcp_servers_key(self, tmp_path):
        config = {"other": "data"}
        config_path = tmp_path / "mcp.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "claude")
        assert servers == []


class TestMCPCollectorPaths:
    """Test MCPServersCollector path scanning."""

    def test_collector_scans_standard_paths(self, tmp_path):
        collector = MCPServersCollector()

        # Create a claude mcp config
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        config = {
            "mcpServers": {
                "test": {"command": "echo", "args": ["hello"]},
            }
        }
        (claude_dir / "mcp.json").write_text(json.dumps(config))

        with patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert len(result.data) >= 1
        assert result.data[0]["name"] == "test"
        assert result.data[0]["tool"] == "claude"

    def test_collector_handles_exception_in_path(self, tmp_path):
        collector = MCPServersCollector()

        with patch("pathlib.Path.home", return_value=tmp_path), \
             patch("posture_agent.collectors.mcp_servers.parse_mcp_config",
                   side_effect=RuntimeError("parse error")):
            # Create a config file so the exists() check passes
            claude_dir = tmp_path / ".claude"
            claude_dir.mkdir()
            (claude_dir / "mcp.json").write_text("{}")

            result = asyncio.run(collector.collect())

        assert any("claude" in e for e in result.errors)


class TestDetectRiskIndicators:
    """Additional risk indicator tests."""

    def test_streamable_http_transport(self):
        server = {"transport": "streamable-http", "command": "node"}
        risks = detect_risk_indicators(server)
        assert "network" in risks

    def test_http_transport(self):
        server = {"transport": "http"}
        risks = detect_risk_indicators(server)
        assert "network" in risks

    def test_no_risks(self):
        server = {"command": "node", "args": ["server.js"]}
        risks = detect_risk_indicators(server)
        assert "shell" not in risks
        assert "credentials" not in risks
        assert "network" not in risks

    def test_backslash_path_in_args(self):
        server = {"command": "node", "args": ["C:\\Users\\test\\server.js"]}
        risks = detect_risk_indicators(server)
        assert "filesystem" in risks

    def test_deduplicates_risks(self):
        """Filesystem keyword in command AND path in args should not duplicate."""
        server = {"command": "file-server", "args": ["/tmp/data"]}
        risks = detect_risk_indicators(server)
        assert risks.count("filesystem") == 1


class TestShellExpandedPath:
    """Test _get_expanded_path utility."""

    def test_includes_standard_paths(self):
        path = _get_expanded_path()
        assert "/opt/homebrew/bin" in path
        assert "/usr/local/bin" in path

    def test_deduplicates_path(self):
        path = _get_expanded_path()
        parts = path.split(":")
        assert len(parts) == len(set(parts))


class TestCheckVersion:
    """Test the check_version utility."""

    def test_extracts_version_from_first_line(self):
        async def mock_run(*args, **kwargs):
            return "git version 2.43.0\n"

        with patch("posture_agent.utils.shell.run_command", side_effect=mock_run):
            version = asyncio.run(check_version("git", "--version"))

        assert version == "2.43.0"

    def test_extracts_version_from_subsequent_line(self):
        """For tools like grype that put version on a later line."""
        async def mock_run(*args, **kwargs):
            return "Application:  grype\nVersion:      0.107.1\n"

        with patch("posture_agent.utils.shell.run_command", side_effect=mock_run):
            version = asyncio.run(check_version("grype", "version"))

        assert version == "0.107.1"

    def test_returns_none_on_no_output(self):
        async def mock_run(*args, **kwargs):
            return None

        with patch("posture_agent.utils.shell.run_command", side_effect=mock_run):
            version = asyncio.run(check_version("nonexistent", "--version"))

        assert version is None

    def test_fallback_to_first_line(self):
        """When no version pattern found, returns first 50 chars."""
        async def mock_run(*args, **kwargs):
            return "some-tool no-version-here\n"

        with patch("posture_agent.utils.shell.run_command", side_effect=mock_run):
            version = asyncio.run(check_version("some-tool", "--version"))

        assert version == "some-tool no-version-here"

    def test_multi_word_version_flag(self):
        """Multi-word flags like 'version --client' are split."""
        async def mock_run(*args, **kwargs):
            if args == ("kubectl", "version", "--client"):
                return "Client Version: v1.28.0\n"
            return None

        with patch("posture_agent.utils.shell.run_command", side_effect=mock_run):
            version = asyncio.run(check_version("kubectl", "version --client"))

        assert version == "1.28.0"


class TestRunCommand:
    """Test run_command utility."""

    def test_successful_command(self):
        result = asyncio.run(run_command("echo", "hello"))
        assert result is not None
        assert "hello" in result

    def test_nonexistent_command(self):
        result = asyncio.run(run_command("nonexistent_command_xyz"))
        assert result is None

    def test_command_with_nonzero_exit(self):
        result = asyncio.run(run_command("false"))
        assert result is None
