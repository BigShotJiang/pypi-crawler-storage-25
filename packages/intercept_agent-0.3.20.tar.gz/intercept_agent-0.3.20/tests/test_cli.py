"""Tests for the CLI commands."""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from posture_agent.core.config import get_settings
from posture_agent.main import cli


class TestCLI:
    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "Intercept Developer Posture Agent" in result.output

    def test_collect_help(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["collect", "--help"])
        assert result.exit_code == 0
        assert "--report" in result.output

    def test_status(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["status"])
        assert result.exit_code == 0
        assert "Agent version" in result.output

    def test_collect_dry_run(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["collect"])
        assert result.exit_code == 0
        # Should output JSON
        assert "fingerprint" in result.output


class TestUpdateCommand:
    def test_update_help(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["update", "--help"])
        assert result.exit_code == 0
        assert "Update the agent to the latest version" in result.output

    @patch("posture_agent.core.config.Settings")
    @patch("posture_agent.main.subprocess.run")
    @patch("posture_agent.main.shutil.which")
    def test_update_with_uv(self, mock_which, mock_run, mock_settings_cls):
        """Update prefers uv when available."""
        mock_which.side_effect = lambda cmd: "/usr/local/bin/uv" if cmd == "uv" else None
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        mock_settings_cls.return_value.agent_version = "0.3.13"

        runner = CliRunner()
        result = runner.invoke(cli, ["update"])

        assert result.exit_code == 0
        assert "Upgrading with uv" in result.output
        # Verify uv was called with correct args including --system
        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert cmd[0] == "/usr/local/bin/uv"
        assert "--system" in cmd
        assert "intercept-agent" in cmd

    @patch("posture_agent.core.config.Settings")
    @patch("posture_agent.main.subprocess.run")
    @patch("posture_agent.main.shutil.which")
    def test_update_falls_back_to_pip(self, mock_which, mock_run, mock_settings_cls):
        """Update falls back to pip when uv is not available."""
        def which_side_effect(cmd):
            if cmd == "uv":
                return None
            if cmd == "pip3":
                return "/usr/bin/pip3"
            return None

        mock_which.side_effect = which_side_effect
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        mock_settings_cls.return_value.agent_version = "0.3.13"

        runner = CliRunner()
        result = runner.invoke(cli, ["update"])

        assert result.exit_code == 0
        assert "Upgrading with pip" in result.output
        cmd = mock_run.call_args[0][0]
        assert cmd[0] == "/usr/bin/pip3"

    @patch("posture_agent.main.shutil.which")
    def test_update_no_installer(self, mock_which):
        """Update fails gracefully when no installer is found."""
        mock_which.return_value = None

        runner = CliRunner()
        result = runner.invoke(cli, ["update"])

        assert result.exit_code != 0
        assert "Neither uv nor pip found" in result.output

    @patch("posture_agent.core.config.Settings")
    @patch("posture_agent.main.subprocess.run")
    @patch("posture_agent.main.shutil.which")
    def test_update_reports_version_change(self, mock_which, mock_run, mock_settings_cls):
        """Update shows old and new version when they differ."""
        mock_which.side_effect = lambda cmd: "/usr/local/bin/uv" if cmd == "uv" else None
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        mock_settings_cls.return_value.agent_version = "0.4.0"

        runner = CliRunner()
        result = runner.invoke(cli, ["update"])

        assert result.exit_code == 0
        assert "Updated:" in result.output
        assert "0.4.0" in result.output

    @patch("posture_agent.core.config.Settings")
    @patch("posture_agent.main.subprocess.run")
    @patch("posture_agent.main.shutil.which")
    def test_update_already_up_to_date(self, mock_which, mock_run, mock_settings_cls):
        """Update shows 'already up to date' when version unchanged."""
        mock_which.side_effect = lambda cmd: "/usr/local/bin/uv" if cmd == "uv" else None
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")

        settings = get_settings()
        current_version = settings.agent_version
        mock_settings_cls.return_value.agent_version = current_version

        runner = CliRunner()
        result = runner.invoke(cli, ["update"])

        assert result.exit_code == 0
        assert "Already up to date" in result.output

    @patch("posture_agent.main.subprocess.run")
    @patch("posture_agent.main.shutil.which")
    def test_update_install_failure(self, mock_which, mock_run):
        """Update reports failure when pip/uv returns non-zero."""
        mock_which.side_effect = lambda cmd: "/usr/local/bin/uv" if cmd == "uv" else None
        mock_run.return_value = MagicMock(
            returncode=1, stdout="", stderr="Could not find package"
        )

        runner = CliRunner()
        result = runner.invoke(cli, ["update"])

        assert result.exit_code != 0
        assert "Upgrade failed" in result.output
