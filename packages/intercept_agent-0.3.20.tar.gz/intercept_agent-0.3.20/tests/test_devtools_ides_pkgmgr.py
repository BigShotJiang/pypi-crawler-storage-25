"""Tests for dev_tools, IDEs, and package_managers collector error paths."""

import asyncio
from unittest.mock import patch

from posture_agent.collectors.dev_tools import DevToolsCollector
from posture_agent.collectors.ides import IDECollector
from posture_agent.collectors.package_managers import PackageManagerCollector


class TestDevToolsCollectorErrors:
    """Test dev tools error handling."""

    def test_exception_during_detection_caught(self):
        collector = DevToolsCollector()

        async def mock_run(cmd, *args):
            if cmd == "which" and args == ("git",):
                raise RuntimeError("which broke")
            return None

        with patch("posture_agent.collectors.dev_tools.run_command", side_effect=mock_run), \
             patch("posture_agent.collectors.dev_tools.check_version", return_value=None):
            result = asyncio.run(collector.collect())

        assert any("Git" in e for e in result.errors)

    def test_slow_tool_uses_longer_timeout(self):
        """Tools in _SLOW_TOOLS should use 30s timeout."""
        collector = DevToolsCollector()
        captured_timeout = {}

        async def mock_run(cmd, *args):
            if cmd == "which" and args == ("sbt",):
                return "/usr/local/bin/sbt\n"
            if cmd == "which":
                return None
            return None

        async def mock_check(binary, flag, *, timeout=10.0):
            captured_timeout[binary] = timeout
            return "1.0.0"

        with patch("posture_agent.collectors.dev_tools.run_command", side_effect=mock_run), \
             patch("posture_agent.collectors.dev_tools.check_version", side_effect=mock_check):
            result = asyncio.run(collector.collect())

        assert captured_timeout.get("sbt") == 30.0


class TestIDECollectorMocked:
    """Test IDE collector with mocked commands."""

    def test_ide_detected_via_app_bundle(self):
        collector = IDECollector()

        async def mock_run(cmd, *args):
            if cmd == "defaults" and "CFBundleShortVersionString" in args:
                return "15.2\n"
            if cmd == "which":
                return None
            return None

        # Mock the app path existence
        with patch("posture_agent.collectors.ides.run_command", side_effect=mock_run), \
             patch("posture_agent.collectors.ides.Path.exists", return_value=True), \
             patch("posture_agent.collectors.ides.check_version", return_value=None):
            result = asyncio.run(collector.collect())

        # Should find IDEs (since all Path.exists returns True)
        assert isinstance(result.data, list)
        assert len(result.data) > 0

    def test_ide_exception_caught(self):
        collector = IDECollector()

        call_count = 0

        async def mock_run(cmd, *args):
            nonlocal call_count
            call_count += 1
            if cmd == "which" and args[0] == "code":
                raise RuntimeError("which error")
            return None

        with patch("posture_agent.collectors.ides.run_command", side_effect=mock_run), \
             patch("posture_agent.collectors.ides.check_version", return_value=None):
            result = asyncio.run(collector.collect())

        assert any("VS Code" in e for e in result.errors)


class TestPackageManagerCollectorErrors:
    """Test package manager error handling."""

    def test_exception_during_detection_caught(self):
        collector = PackageManagerCollector()

        async def mock_run(cmd, *args):
            if cmd == "which" and args == ("brew",):
                raise RuntimeError("which broke")
            return None

        with patch("posture_agent.collectors.package_managers.run_command", side_effect=mock_run), \
             patch("posture_agent.collectors.package_managers.check_version", return_value=None):
            result = asyncio.run(collector.collect())

        assert any("Homebrew" in e for e in result.errors)
