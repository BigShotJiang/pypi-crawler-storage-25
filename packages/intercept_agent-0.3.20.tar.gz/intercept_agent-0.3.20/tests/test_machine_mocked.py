"""Tests for the machine collector with mocked commands."""

import asyncio
from unittest.mock import patch

from posture_agent.collectors.machine import MachineCollector


class TestMachineCollectorErrors:
    """Test error handling when system commands fail."""

    def test_cpu_brand_error_caught(self):
        collector = MachineCollector()

        async def mock_run(cmd, *args):
            if cmd == "sysctl" and args == ("-n", "machdep.cpu.brand_string"):
                raise RuntimeError("sysctl failed")
            if cmd == "sysctl" and args == ("-n", "hw.ncpu"):
                return "8\n"
            if cmd == "sysctl" and args == ("-n", "hw.memsize"):
                return "17179869184\n"
            return None

        with patch("posture_agent.collectors.machine.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["cpu_brand"] == ""
        assert any("CPU brand" in e for e in result.errors)
        assert result.data["cpu_cores"] == 8

    def test_cpu_cores_error_caught(self):
        collector = MachineCollector()

        async def mock_run(cmd, *args):
            if cmd == "sysctl" and args == ("-n", "machdep.cpu.brand_string"):
                return "Apple M3 Pro\n"
            if cmd == "sysctl" and args == ("-n", "hw.ncpu"):
                raise RuntimeError("sysctl failed")
            if cmd == "sysctl" and args == ("-n", "hw.memsize"):
                return "17179869184\n"
            return None

        with patch("posture_agent.collectors.machine.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["cpu_brand"] == "Apple M3 Pro"
        assert result.data["cpu_cores"] == 0
        assert any("CPU cores" in e for e in result.errors)

    def test_memory_error_caught(self):
        collector = MachineCollector()

        async def mock_run(cmd, *args):
            if cmd == "sysctl" and args == ("-n", "machdep.cpu.brand_string"):
                return "Apple M3 Pro\n"
            if cmd == "sysctl" and args == ("-n", "hw.ncpu"):
                return "12\n"
            if cmd == "sysctl" and args == ("-n", "hw.memsize"):
                raise RuntimeError("sysctl failed")
            return None

        with patch("posture_agent.collectors.machine.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["memory_gb"] == 0
        assert any("Memory" in e for e in result.errors)

    def test_cpu_brand_returns_none(self):
        collector = MachineCollector()

        async def mock_run(cmd, *args):
            if cmd == "sysctl" and args == ("-n", "machdep.cpu.brand_string"):
                return None
            if cmd == "sysctl" and args == ("-n", "hw.ncpu"):
                return None
            if cmd == "sysctl" and args == ("-n", "hw.memsize"):
                return None
            return None

        with patch("posture_agent.collectors.machine.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["cpu_brand"] == ""
        assert result.data["cpu_cores"] == 0
        assert result.data["memory_gb"] == 0

    def test_memory_calculation(self):
        collector = MachineCollector()

        async def mock_run(cmd, *args):
            if cmd == "sysctl" and args == ("-n", "machdep.cpu.brand_string"):
                return "Apple M3 Max\n"
            if cmd == "sysctl" and args == ("-n", "hw.ncpu"):
                return "16\n"
            if cmd == "sysctl" and args == ("-n", "hw.memsize"):
                # 36 GB
                return str(36 * 1024**3) + "\n"
            return None

        with patch("posture_agent.collectors.machine.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["cpu_brand"] == "Apple M3 Max"
        assert result.data["cpu_cores"] == 16
        assert result.data["memory_gb"] == 36.0
