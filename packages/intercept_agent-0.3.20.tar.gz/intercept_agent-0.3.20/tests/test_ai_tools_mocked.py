"""Tests for AI tools collector with mocked dependencies."""

import asyncio
from unittest.mock import patch

from posture_agent.collectors.ai_tools import AIToolsCollector


class TestAIToolsCLIErrorHandling:
    """Test error handling in CLI tool detection."""

    def test_cli_tool_exception_adds_to_errors(self):
        collector = AIToolsCollector()

        async def mock_run(cmd, *args):
            if cmd == "which" and args == ("claude",):
                raise RuntimeError("which failed")
            return None

        with patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert any("Claude Code" in e for e in result.errors)

    def test_tool_without_version_flag(self):
        """Tabnine has no version flag (None)."""
        collector = AIToolsCollector()

        async def mock_run(cmd, *args):
            if cmd == "which" and args == ("tabnine",):
                return "/usr/local/bin/tabnine\n"
            return None

        with patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run), \
             patch("posture_agent.collectors.ai_tools.check_version", return_value=None):
            result = asyncio.run(collector.collect())

        tools = [t for t in result.data if t["binary"] == "tabnine"]
        assert len(tools) == 1
        assert tools[0]["version"] == ""
        assert tools[0]["type"] == "cli"


class TestAIToolsExtensionDetection:
    """Test AI extension detection from editors."""

    def test_detects_copilot_extension_in_vscode(self):
        collector = AIToolsCollector()

        async def mock_run(cmd, *args):
            if cmd == "which" and args == ("code",):
                return "/usr/local/bin/code\n"
            if cmd == "which":
                return None
            if cmd == "code" and args == ("--list-extensions",):
                return (
                    "github.copilot\n"
                    "github.copilot-chat\n"
                    "ms-python.python\n"
                )
            return None

        with patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run), \
             patch("posture_agent.collectors.ai_tools.check_version", return_value=None):
            result = asyncio.run(collector.collect())

        ext_tools = [t for t in result.data if t["type"] == "extension"]
        ext_names = {t["name"] for t in ext_tools}
        assert "github.copilot" in ext_names
        assert "github.copilot-chat" in ext_names
        # ms-python.python is NOT an AI extension
        assert "ms-python.python" not in ext_names

    def test_editor_not_installed_skipped(self):
        collector = AIToolsCollector()

        async def mock_run(cmd, *args):
            return None  # No editors found

        with patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        ext_tools = [t for t in result.data if t["type"] == "extension"]
        assert ext_tools == []

    def test_editor_list_extensions_returns_none(self):
        collector = AIToolsCollector()

        async def mock_run(cmd, *args):
            if cmd == "which" and args == ("code",):
                return "/usr/local/bin/code\n"
            if cmd == "which":
                return None
            if cmd == "code" and args == ("--list-extensions",):
                return None  # Command fails
            return None

        with patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run), \
             patch("posture_agent.collectors.ai_tools.check_version", return_value=None):
            result = asyncio.run(collector.collect())

        ext_tools = [t for t in result.data if t["type"] == "extension"]
        assert ext_tools == []

    def test_editor_extension_exception_caught(self):
        collector = AIToolsCollector()

        async def mock_run(cmd, *args):
            if cmd == "which" and args == ("code",):
                return "/usr/local/bin/code\n"
            if cmd == "which":
                return None
            if cmd == "code" and args == ("--list-extensions",):
                raise RuntimeError("code crashed")
            return None

        with patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run), \
             patch("posture_agent.collectors.ai_tools.check_version", return_value=None):
            result = asyncio.run(collector.collect())

        assert any("AI extensions (code)" in e for e in result.errors)

    def test_extension_editor_name_correct(self):
        """Extension entries should have the correct editor display name."""
        collector = AIToolsCollector()

        async def mock_run(cmd, *args):
            if cmd == "which" and args == ("cursor",):
                return "/usr/local/bin/cursor\n"
            if cmd == "which":
                return None
            if cmd == "cursor" and args == ("--list-extensions",):
                return "sourcegraph.cody-ai\n"
            return None

        with patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run), \
             patch("posture_agent.collectors.ai_tools.check_version", return_value=None):
            result = asyncio.run(collector.collect())

        ext_tools = [t for t in result.data if t["type"] == "extension"]
        assert len(ext_tools) == 1
        assert ext_tools[0]["editor"] == "Cursor"
        assert ext_tools[0]["name"] == "sourcegraph.cody-ai"
