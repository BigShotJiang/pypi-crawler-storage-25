"""Tests for the security collector with mocked shell commands."""

import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, patch, MagicMock

import pytest

from posture_agent.collectors.base import CollectorResult
from posture_agent.collectors.security import SecurityCollector


class TestSecurityCollectorGitSigning:
    """Test git signing detection."""

    def test_signing_enabled_with_ssh_format(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "git" and args == ("config", "--global", "commit.gpgsign"):
                return "true\n"
            if cmd == "git" and args == ("config", "--global", "gpg.format"):
                return "ssh\n"
            if cmd == "git" and args == ("config", "--global", "user.name"):
                return "Test User\n"
            if cmd == "git" and args == ("config", "--global", "user.email"):
                return "test@example.com\n"
            if cmd == "ssh-add" and args == ("-l",):
                return "no identities"
            if cmd == "git" and args == ("config", "--global", "core.hooksPath"):
                return None
            if cmd == "git" and args == ("config", "credential.helper"):
                return "osxkeychain\n"
            if cmd == "git" and args == ("config", "--global", "gpg.ssh.allowedSignersFile"):
                return None
            if cmd == "printenv" and args == ("SSH_AUTH_SOCK",):
                return None
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["git_signing_enabled"] is True
        assert result.data["git_signing_format"] == "ssh"
        assert result.data["git_name"] == "Test User"
        assert result.data["git_email"] == "test@example.com"

    def test_signing_disabled(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "git" and args == ("config", "--global", "commit.gpgsign"):
                return None  # Not set
            if cmd == "git" and args == ("config", "--global", "gpg.format"):
                return None
            if cmd == "git" and args == ("config", "--global", "user.name"):
                return None
            if cmd == "git" and args == ("config", "--global", "user.email"):
                return None
            if cmd == "ssh-add" and args == ("-l",):
                return None
            if cmd == "git" and args == ("config", "--global", "core.hooksPath"):
                return None
            if cmd == "git" and args == ("config", "credential.helper"):
                return None
            if cmd == "git" and args == ("config", "--global", "gpg.ssh.allowedSignersFile"):
                return None
            if cmd == "printenv" and args == ("SSH_AUTH_SOCK",):
                return None
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["git_signing_enabled"] is False
        assert result.data["git_signing_format"] == "gpg"  # default
        assert result.data["git_name"] == ""
        assert result.data["git_email"] == ""

    def test_git_signing_exception_caught(self):
        collector = SecurityCollector()

        call_count = 0

        async def mock_run(cmd, *args):
            nonlocal call_count
            call_count += 1
            if cmd == "git" and args == ("config", "--global", "commit.gpgsign"):
                raise RuntimeError("git not found")
            # Return None for everything else
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["git_signing_enabled"] is False
        assert any("Git signing" in e for e in result.errors)


class TestSecurityCollectorSSHKeys:
    """Test SSH key detection logic."""

    def test_detects_openssh_ed25519_key(self, tmp_path):
        collector = SecurityCollector()
        ssh_dir = tmp_path / ".ssh"
        ssh_dir.mkdir()

        key_file = ssh_dir / "id_ed25519"
        # Write header that the collector recognizes as openssh key type
        key_file.write_bytes(b"-----BEGIN OPENSSH PRIVATE KEY-----\nfakedata")  # gitleaks:allow

        async def mock_run(cmd, *args):
            if cmd == "ssh-add" and args == ("-l",):
                return "256 SHA256:abc test@machine (ED25519)\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run), \
             patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_key_count"] == 1
        assert result.data["ssh_keys"][0]["name"] == "id_ed25519"
        assert result.data["ssh_keys"][0]["algorithm"] == "ed25519"
        assert result.data["ssh_agent_keys"] == 1

    def test_detects_rsa_key(self, tmp_path):
        collector = SecurityCollector()
        ssh_dir = tmp_path / ".ssh"
        ssh_dir.mkdir()

        key_file = ssh_dir / "id_rsa"
        key_file.write_bytes(b"-----BEGIN RSA PRIVATE KEY-----\nfakedata")  # gitleaks:allow

        async def mock_run(cmd, *args):
            if cmd == "ssh-add" and args == ("-l",):
                return "no identities"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run), \
             patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_key_count"] == 1
        assert result.data["ssh_keys"][0]["name"] == "id_rsa"
        assert result.data["ssh_keys"][0]["algorithm"] == "rsa"

    def test_detects_ecdsa_key(self, tmp_path):
        collector = SecurityCollector()
        ssh_dir = tmp_path / ".ssh"
        ssh_dir.mkdir()

        key_file = ssh_dir / "id_ecdsa"
        # Write header that the collector recognizes as EC key type
        key_file.write_bytes(b"-----BEGIN EC PRIVATE KEY-----\nfakedata")  # gitleaks:allow

        async def mock_run(cmd, *args):
            if cmd == "ssh-add" and args == ("-l",):
                return "no identities"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run), \
             patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_key_count"] == 1
        assert result.data["ssh_keys"][0]["algorithm"] == "ecdsa"

    def test_detects_dsa_key(self, tmp_path):
        collector = SecurityCollector()
        ssh_dir = tmp_path / ".ssh"
        ssh_dir.mkdir()

        key_file = ssh_dir / "id_dsa"
        key_file.write_bytes(b"-----BEGIN DSA PRIVATE KEY-----\nfakedata")  # gitleaks:allow

        async def mock_run(cmd, *args):
            if cmd == "ssh-add" and args == ("-l",):
                return "no identities"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run), \
             patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_key_count"] == 1
        assert result.data["ssh_keys"][0]["algorithm"] == "dsa"

    def test_skips_non_key_files(self, tmp_path):
        collector = SecurityCollector()
        ssh_dir = tmp_path / ".ssh"
        ssh_dir.mkdir()

        # These should all be skipped
        (ssh_dir / "config").write_text("Host *\n")
        (ssh_dir / "known_hosts").write_text("github.com ...\n")
        (ssh_dir / "authorized_keys").write_text("ssh-ed25519 ...\n")
        (ssh_dir / "id_rsa.pub").write_text("ssh-rsa AAAA...\n")
        (ssh_dir / "id_rsa.old").write_text("old key\n")
        (ssh_dir / "id_rsa.bak").write_text("backup\n")
        (ssh_dir / "something.log").write_text("log\n")
        (ssh_dir / "environment").write_text("ENV=val\n")
        (ssh_dir / "known_hosts.old").write_text("old hosts\n")

        async def mock_run(cmd, *args):
            if cmd == "ssh-add" and args == ("-l",):
                return "no identities"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run), \
             patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_key_count"] == 0

    def test_skips_non_files_in_ssh_dir(self, tmp_path):
        collector = SecurityCollector()
        ssh_dir = tmp_path / ".ssh"
        ssh_dir.mkdir()
        (ssh_dir / "subdir").mkdir()

        async def mock_run(cmd, *args):
            if cmd == "ssh-add" and args == ("-l",):
                return "no identities"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run), \
             patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_key_count"] == 0

    def test_no_ssh_dir(self, tmp_path):
        collector = SecurityCollector()
        # No .ssh dir created

        async def mock_run(cmd, *args):
            if cmd == "ssh-add" and args == ("-l",):
                return "no identities"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run), \
             patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_key_count"] == 0
        assert result.data["ssh_keys"] == []

    def test_ssh_agent_with_loaded_keys(self, tmp_path):
        collector = SecurityCollector()
        ssh_dir = tmp_path / ".ssh"
        ssh_dir.mkdir()

        async def mock_run(cmd, *args):
            if cmd == "ssh-add" and args == ("-l",):
                return (
                    "256 SHA256:abcdef test@machine (ED25519)\n"
                    "2048 SHA256:ghijkl test@machine (RSA)\n"
                )
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run), \
             patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_agent_keys"] == 2

    def test_ssh_agent_error_returns_zero(self, tmp_path):
        collector = SecurityCollector()
        ssh_dir = tmp_path / ".ssh"
        ssh_dir.mkdir()

        async def mock_run(cmd, *args):
            if cmd == "ssh-add" and args == ("-l",):
                return "error connecting to agent"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run), \
             patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_agent_keys"] == 0

    def test_openssh_key_without_algo_in_name(self, tmp_path):
        """An openssh key with a generic name uses 'openssh' as algorithm."""
        collector = SecurityCollector()
        ssh_dir = tmp_path / ".ssh"
        ssh_dir.mkdir()

        key_file = ssh_dir / "my_custom_key"
        key_file.write_bytes(b"-----BEGIN OPENSSH PRIVATE KEY-----\nfakedata")  # gitleaks:allow

        async def mock_run(cmd, *args):
            if cmd == "ssh-add" and args == ("-l",):
                return "no identities"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run), \
             patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_key_count"] == 1
        assert result.data["ssh_keys"][0]["algorithm"] == "openssh"


class TestSecurityCollectorFileVault:
    """Test FileVault detection."""

    def test_filevault_on(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "fdesetup" and args == ("status",):
                return "FileVault is On.\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["filevault_enabled"] is True

    def test_filevault_off(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "fdesetup" and args == ("status",):
                return "FileVault is Off.\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["filevault_enabled"] is False

    def test_filevault_command_fails(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "fdesetup":
                return None
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["filevault_enabled"] is False

    def test_filevault_exception_caught(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "fdesetup":
                raise RuntimeError("permission denied")
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["filevault_enabled"] is False
        assert any("FileVault" in e for e in result.errors)


class TestSecurityCollectorFirewall:
    """Test firewall detection."""

    def test_firewall_enabled(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "/usr/libexec/ApplicationFirewall/socketfilterfw":
                return "Firewall is enabled. (State = 1)\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["firewall_enabled"] is True

    def test_firewall_disabled(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "/usr/libexec/ApplicationFirewall/socketfilterfw":
                return "Firewall is disabled. (State = 0)\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["firewall_enabled"] is False

    def test_firewall_exception_caught(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "/usr/libexec/ApplicationFirewall/socketfilterfw":
                raise RuntimeError("not found")
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["firewall_enabled"] is False
        assert any("Firewall" in e for e in result.errors)


class TestSecurityCollectorGatekeeper:
    """Test Gatekeeper detection."""

    def test_gatekeeper_enabled(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "spctl" and args == ("--status",):
                return "assessments enabled\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["gatekeeper_enabled"] is True

    def test_gatekeeper_disabled(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "spctl" and args == ("--status",):
                return "assessments disabled\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["gatekeeper_enabled"] is False

    def test_gatekeeper_exception_caught(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "spctl":
                raise RuntimeError("spctl error")
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["gatekeeper_enabled"] is False
        assert any("Gatekeeper" in e for e in result.errors)


class TestSecurityCollectorHooksAndCredentials:
    """Test hooks path and credential helper."""

    def test_global_hooks_path_set(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "git" and args == ("config", "--global", "core.hooksPath"):
                return "/path/to/hooks\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["global_hooks_path"] == "/path/to/hooks"

    def test_global_hooks_path_not_set(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "git" and args == ("config", "--global", "core.hooksPath"):
                return None
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["global_hooks_path"] == ""

    def test_hooks_path_exception_caught(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "git" and args == ("config", "--global", "core.hooksPath"):
                raise RuntimeError("git error")
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert any("Hooks path" in e for e in result.errors)

    def test_credential_helper_osxkeychain(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "git" and args == ("config", "credential.helper"):
                return "osxkeychain\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["credential_helper"] == "osxkeychain"

    def test_credential_helper_not_set(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "git" and args == ("config", "credential.helper"):
                return None
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["credential_helper"] == ""

    def test_credential_helper_exception_caught(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "git" and args == ("config", "credential.helper"):
                raise RuntimeError("git error")
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert any("Credential helper" in e for e in result.errors)


class TestSecurityCollectorAllowedSigners:
    """Test allowed signers file detection."""

    def test_allowed_signers_configured_and_exists(self, tmp_path):
        collector = SecurityCollector()
        signers_file = tmp_path / "allowed_signers"
        signers_file.write_text("test@example.com ssh-ed25519 AAAA...\n")

        async def mock_run(cmd, *args):
            if cmd == "git" and args == ("config", "--global", "gpg.ssh.allowedSignersFile"):
                return str(signers_file) + "\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["allowed_signers_configured"] is True
        assert result.data["allowed_signers_exists"] is True

    def test_allowed_signers_configured_but_missing(self, tmp_path):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "git" and args == ("config", "--global", "gpg.ssh.allowedSignersFile"):
                return str(tmp_path / "nonexistent_file") + "\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["allowed_signers_configured"] is True
        assert result.data["allowed_signers_exists"] is False

    def test_allowed_signers_not_configured(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "git" and args == ("config", "--global", "gpg.ssh.allowedSignersFile"):
                return None
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["allowed_signers_configured"] is False
        assert result.data["allowed_signers_exists"] is False

    def test_allowed_signers_exception_caught(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "git" and args == ("config", "--global", "gpg.ssh.allowedSignersFile"):
                raise RuntimeError("git error")
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["allowed_signers_configured"] is False
        assert any("Allowed signers" in e for e in result.errors)


class TestSecurityCollectorSSHAgentType:
    """Test SSH agent type detection."""

    def test_1password_agent(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "printenv" and args == ("SSH_AUTH_SOCK",):
                return "/Users/dev/Library/Group Containers/2BUA8C4S2C.com.1password/t/agent.sock\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_agent_type"] == "1Password"

    def test_secretive_agent(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "printenv" and args == ("SSH_AUTH_SOCK",):
                return "/Users/dev/Library/Containers/com.maxgoedjen.Secretive.SecretAgent/data/socket.ssh\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_agent_type"] == "Secretive"

    def test_apple_keychain_agent(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "printenv" and args == ("SSH_AUTH_SOCK",):
                return "/private/tmp/com.apple.launchd.abc123/Listeners\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_agent_type"] == "Apple Keychain"

    def test_standard_agent(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "printenv" and args == ("SSH_AUTH_SOCK",):
                return "/tmp/ssh-xyz/agent.12345\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_agent_type"] == "standard"

    def test_no_agent(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "printenv" and args == ("SSH_AUTH_SOCK",):
                return None
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_agent_type"] == "none"

    def test_empty_agent_sock(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "printenv" and args == ("SSH_AUTH_SOCK",):
                return "\n"
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_agent_type"] == "none"

    def test_agent_type_exception_caught(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "printenv" and args == ("SSH_AUTH_SOCK",):
                raise RuntimeError("printenv error")
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert result.data["ssh_agent_type"] == "unknown"
        assert any("SSH agent type" in e for e in result.errors)


class TestSecurityCollectorGitUserException:
    """Test git user info exception handling."""

    def test_git_user_exception_caught(self):
        collector = SecurityCollector()

        async def mock_run(cmd, *args):
            if cmd == "git" and args == ("config", "--global", "user.name"):
                raise RuntimeError("git error")
            return None

        with patch("posture_agent.collectors.security.run_command", side_effect=mock_run):
            result = asyncio.run(collector.collect())

        assert any("Git user" in e for e in result.errors)
