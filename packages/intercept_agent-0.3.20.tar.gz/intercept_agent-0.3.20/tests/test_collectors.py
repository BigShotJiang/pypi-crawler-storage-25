"""Tests for posture agent collectors."""

import asyncio
from unittest.mock import AsyncMock, patch

import pytest

from posture_agent.collectors.base import CollectorResult
from posture_agent.collectors.machine import MachineCollector
from posture_agent.collectors.dev_tools import DevToolsCollector
from posture_agent.collectors.security import SecurityCollector
from posture_agent.collectors.package_managers import PackageManagerCollector
from posture_agent.collectors.ides import IDECollector
from posture_agent.collectors.ai_tools import AIToolsCollector
from posture_agent.collectors.extensions import ExtensionCollector
from posture_agent.collectors.mcp_servers import MCPServersCollector, detect_risk_indicators


@pytest.fixture
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


class TestMachineCollector:
    def test_collect_returns_result(self):
        collector = MachineCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "machine"
        assert "hostname" in result.data
        assert "os_name" in result.data
        assert "architecture" in result.data

    def test_collect_has_username(self):
        collector = MachineCollector()
        result = asyncio.run(collector.collect())
        assert "username" in result.data


class TestDevToolsCollector:
    def test_collect_returns_result(self):
        collector = DevToolsCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "dev_tools"
        assert isinstance(result.data, list)

    def test_finds_git(self):
        """Git should be installed on any dev machine."""
        collector = DevToolsCollector()
        result = asyncio.run(collector.collect())
        tool_names = [t["name"] for t in result.data]
        assert "Git" in tool_names


class TestSecurityCollector:
    def test_collect_returns_result(self):
        collector = SecurityCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "security"
        assert "git_signing_enabled" in result.data

    def test_has_ssh_info(self):
        collector = SecurityCollector()
        result = asyncio.run(collector.collect())
        assert "ssh_key_count" in result.data


class TestPackageManagerCollector:
    def test_collect_returns_result(self):
        collector = PackageManagerCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "package_managers"
        assert isinstance(result.data, list)


class TestIDECollector:
    def test_collect_returns_result(self):
        collector = IDECollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "ides"
        assert isinstance(result.data, list)


class TestAIToolsCollector:
    def test_collect_returns_result(self):
        collector = AIToolsCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "ai_tools"
        assert isinstance(result.data, list)

    def test_cli_tool_definitions_contain_expected_tools(self):
        """Verify all expected AI CLI tools are defined."""
        from posture_agent.collectors.ai_tools import AI_CLI_TOOLS

        tool_binaries = {binary for _, binary, _ in AI_CLI_TOOLS}
        expected_binaries = {
            "claude", "copilot", "aider", "kiro",
            "codex", "gemini", "q",
        }
        assert expected_binaries.issubset(tool_binaries), (
            f"Missing binaries: {expected_binaries - tool_binaries}"
        )

    def test_detects_copilot_cli(self):
        """GitHub Copilot CLI is detected when binary exists."""
        collector = AIToolsCollector()

        async def mock_run_command(cmd, *args):
            if cmd == "which" and args == ("copilot",):
                return "/usr/local/bin/copilot\n"
            return None

        async def mock_check_version(binary, flag):
            if binary == "copilot":
                return "1.0.0"
            return None

        with patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run_command), \
             patch("posture_agent.collectors.ai_tools.check_version", side_effect=mock_check_version):
            result = asyncio.run(collector.collect())

        tools = [t for t in result.data if t["binary"] == "copilot"]
        assert len(tools) == 1
        assert tools[0]["name"] == "GitHub Copilot CLI"
        assert tools[0]["type"] == "cli"
        assert tools[0]["version"] == "1.0.0"

    def test_detects_kiro(self):
        """Kiro (AWS) is detected when binary exists."""
        collector = AIToolsCollector()

        async def mock_run_command(cmd, *args):
            if cmd == "which" and args == ("kiro",):
                return "/usr/local/bin/kiro\n"
            return None

        async def mock_check_version(binary, flag):
            if binary == "kiro":
                return "0.1.0"
            return None

        with patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run_command), \
             patch("posture_agent.collectors.ai_tools.check_version", side_effect=mock_check_version):
            result = asyncio.run(collector.collect())

        tools = [t for t in result.data if t["binary"] == "kiro"]
        assert len(tools) == 1
        assert tools[0]["name"] == "Kiro"
        assert tools[0]["type"] == "cli"
        assert tools[0]["version"] == "0.1.0"

    def test_detects_amazon_q_cli(self):
        """Amazon Q Developer CLI is detected when binary exists."""
        collector = AIToolsCollector()

        async def mock_run_command(cmd, *args):
            if cmd == "which" and args == ("q",):
                return "/usr/local/bin/q\n"
            return None

        async def mock_check_version(binary, flag):
            if binary == "q":
                return "2.1.0"
            return None

        with patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run_command), \
             patch("posture_agent.collectors.ai_tools.check_version", side_effect=mock_check_version):
            result = asyncio.run(collector.collect())

        tools = [t for t in result.data if t["binary"] == "q"]
        assert len(tools) == 1
        assert tools[0]["name"] == "Amazon Q Developer CLI"
        assert tools[0]["type"] == "cli"
        assert tools[0]["version"] == "2.1.0"

    def test_tool_not_found_skipped(self):
        """Tools not found on system are silently skipped."""
        collector = AIToolsCollector()

        async def mock_run_command(cmd, *args):
            return None  # All `which` calls return nothing

        with patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run_command):
            result = asyncio.run(collector.collect())

        assert result.data == []
        assert result.errors == []


class TestExtensionCollector:
    def test_collect_returns_result(self):
        collector = ExtensionCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "extensions"
        assert isinstance(result.data, dict)


class TestMCPServersCollector:
    def test_collect_returns_result(self):
        collector = MCPServersCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "mcp_servers"
        assert isinstance(result.data, list)

    def test_risk_indicators_detects_shell(self):
        server = {"command": "bash", "args": ["-c", "echo test"]}
        risks = detect_risk_indicators(server)
        assert "shell" in risks

    def test_risk_indicators_detects_credentials(self):
        server = {"command": "npx", "env": {"GITHUB_TOKEN": "xxx", "API_KEY": "yyy"}}
        risks = detect_risk_indicators(server)
        assert "credentials" in risks

    def test_risk_indicators_detects_network(self):
        server = {"transport": "sse", "url": "https://example.com/mcp"}
        risks = detect_risk_indicators(server)
        assert "network" in risks

    def test_risk_indicators_detects_filesystem(self):
        server = {"command": "node", "args": ["/path/to/server.js"]}
        risks = detect_risk_indicators(server)
        assert "filesystem" in risks
