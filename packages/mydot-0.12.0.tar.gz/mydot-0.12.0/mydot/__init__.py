from mydot.repository import Repository
from mydot.console import console

__version__ = "0.12.0"
__all__ = ["Repository", "console"]
