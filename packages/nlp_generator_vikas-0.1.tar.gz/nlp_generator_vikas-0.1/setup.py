from setuptools import setup

setup(
    name="nlp-generator-vikas",
    version="0.1",
    py_modules=["generator"],
    entry_points={
        'console_scripts': [
            'generate-nlp=generator:generate_nlp',
        ],
    },
    author="Vikas Singh",
    description="Generates NLP Tokenization Python code",
)