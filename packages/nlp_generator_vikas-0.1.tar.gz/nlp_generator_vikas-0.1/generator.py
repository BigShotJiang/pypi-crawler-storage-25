def generate_nlp():
    code = '''import nltk
from nltk.tokenize import sent_tokenize, word_tokenize

# Download required NLTK resources
nltk.download('punkt')

def analyze_text(text):
    # Stage 1: Sentence Segmentation
    sentences = sent_tokenize(text)

    print("Segmented Sentences:")
    for i, sentence in enumerate(sentences):
        print(f"{i + 1}: {sentence}")

    # Stage 2: Word Tokenization
    print("\\nTokenized Words:")
    for i, sentence in enumerate(sentences):
        words = word_tokenize(sentence)
        print(f"Sentence {i + 1}: {words}")


# Example usage
text = "The cat is on the mat. It is sunny today. Let's go for a walk."
analyze_text(text)
'''

    with open("nlp_program.py", "w") as f:
        f.write(code)

    print("✅ nlp_program.py created!")