"""
runtime/loader.py — 工具运行时框架进程级初始化入口

职责：
    进程级一次性初始化，组装框架核心组件（pipeline / policy / registry）并统一管理工具注册。
    loader 只负责注册 RuntimeTool，不构造 StructuredTool。
    StructuredTool 构造由 factory（create_loop_agent）在 graph 构建时负责，
    通过 create_loop_agent(loader=...) 在构图时调用 to_langchain_tools() 构造 StructuredTool。

    policy_config 用于构造 DefaultPolicyEngine，在 register() 时自动注入给每个工具。
    工具无需手动传入 policy，由 loader 统一治理。

装配路径：
    ToolRuntimeLoader(policy_config=...) 构造
        → DefaultPolicyEngine(policy_config)
        → register(tool): 只存储 RuntimeTool，注入 policy
        → 传入 create_loop_agent(loader=loader, ...)
        → factory 内部调用 loader._registry.to_langchain_tools() 构造 StructuredTool
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from langchain_core.tools import BaseTool

from .adapter import LangChainAdapter
from .base import RuntimeTool
from .pipeline import ToolExecutorPipeline, ToolOutputManager
from .auto_mode.config import AutoModeConfig
from .auto_mode.config_update import (
    apply_auto_mode_config_to_engine,
    apply_auto_mode_config_to_policy,
    merge_auto_mode_config,
)
from .auto_mode.state import get_auto_mode_state
from .policy import DefaultPolicyEngine, PolicyEngine, ToolPolicyConfig
from .registry import RuntimeToolRegistry
from .prompt.handler import PermissionPromptHandler
from .resolvers import PermissionResolver
from .session_store import AgentSessionStore


class ToolRuntimeLoader:
    """
    工具运行时进程级装配入口。

    policy_config:  策略配置，构造 DefaultPolicyEngine 并自动注入给所有注册工具。
                    为 None 时不注入 policy（工具默认 allow，适用于开发/测试模式）。
    policy_engine:  直接传入自定义 PolicyEngine 实例（优先于 policy_config）。
    output_manager: 工具输出大小管控器，为 None 时使用默认配置。
    headless:       是否处于无交互（headless）模式。
                    True  — ask 走 HeadlessPromptHandler（仅 hook 链，无决议则 deny）。
                    False — ask 走 prompt_handler 或 legacy permission_resolver。
    prompt_handler: L3 PermissionPromptHandler；优先于 permission_resolver。
    permission_resolver: 旧 (name, prompt) -> bool 垫片，自动包装为 LegacyResolverPromptHandler。
    """

    def __init__(
        self,
        *,
        policy_config: ToolPolicyConfig | None = None,
        policy_engine: PolicyEngine | None = None,
        output_manager: ToolOutputManager | None = None,
        headless: bool = False,
        prompt_handler: PermissionPromptHandler | None = None,
        permission_resolver: PermissionResolver | None = None,
    ) -> None:
        self._headless = headless
        self._permission_resolver = permission_resolver
        self._prompt_handler = prompt_handler
        self._pipeline = ToolExecutorPipeline(
            output_manager=output_manager,
            headless=headless,
            prompt_handler=prompt_handler,
            permission_resolver=permission_resolver,
        )
        self._adapter = LangChainAdapter()
        self._registry = RuntimeToolRegistry(
            pipeline=self._pipeline,
            adapter=self._adapter,
        )
        self._policy_config = policy_config
        # 优先使用外部传入的 policy_engine；其次从 policy_config 构造；否则为 None
        if policy_engine is not None:
            self._policy: PolicyEngine | None = policy_engine
        elif policy_config is not None:
            self._policy = DefaultPolicyEngine(policy_config)
        else:
            self._policy = None

    def register(self, tool: RuntimeTool) -> "ToolRuntimeLoader":
        """
        注册工具并自动注入 PolicyEngine。

        注入规则：
            - 工具已有 _policy（初始化时手动传入）→ 不覆盖，保留工具自己的 policy
            - 工具无 _policy（_policy is None）→ 注入 loader 的统一 policy
        这允许个别工具使用专属 policy，其余工具统一受 loader policy 保护。
        """
        if self._policy is not None and getattr(tool, "_policy", None) is None:
            tool._policy = self._policy
        self._registry.register(tool)
        return self

    def register_default_tools(
        self,
        *,
        workspace_root: str,
        agent_home: str = ".langchain_agentx",
        include_agent: bool = True,
        include_skill: bool = False,
        agent_registry: Any | None = None,
    ) -> "ToolRuntimeLoader":
        """
        注册默认工具集（Read/Grep/Glob/Bash + 可选 Agent/Skill）。

        用于打通默认工具装配链路，避免每个调用方重复手写 register 序列。

        v0.2.0 更新：自动创建共享 ToolStateBridge 并注入给需要 cwd 的工具。
        """
        from pathlib import Path

        from langchain_agentx.tools.ask_user_question import AskUserQuestionTool
        from langchain_agentx.tools.bash import BashRuntimeTool
        from langchain_agentx.tools.glob import GlobRuntimeTool
        from langchain_agentx.tools.grep import GrepRuntimeTool
        from langchain_agentx.tools.edit import EditRuntimeTool
        from langchain_agentx.tools.read import ReadRuntimeTool
        from langchain_agentx.tools.ripgrep_plugin_exclusions import PluginCacheGlobExclusions
        from langchain_agentx.tools.task_list.tool import TaskListRuntimeTool
        from langchain_agentx.tools.user_message import UserMessageTool
        from langchain_agentx.tools.webfetch import loader as webfetch_loader
        from langchain_agentx.tools.websearch import loader as websearch_loader
        from langchain_agentx.tools.write import WriteRuntimeTool
        from langchain_agentx.tool_runtime.state_bridge import ToolStateBridge
        from langchain_agentx.workspace.config import AgentWorkspaceConfig

        wr = Path(workspace_root).resolve()
        cfg = AgentWorkspaceConfig(workspace_root=wr, agent_home=agent_home)
        plugin_ex = PluginCacheGlobExclusions(
            cache_root=str(cfg.plugin_cache_dir.resolve()),
        )

        # v0.2.0：创建共享 bridge，初始 cwd 为 workspace_root
        # Bash cd 后，Read/Write/Edit 自动感知新路径；Glob 存储摘要到同一 state
        shared_bridge = ToolStateBridge(initial_cwd=str(wr))

        self.register(ReadRuntimeTool(state_bridge=shared_bridge))
        self.register(WriteRuntimeTool(state_bridge=shared_bridge))
        self.register(EditRuntimeTool(state_bridge=shared_bridge))
        self.register(
            GrepRuntimeTool(
                workspace_root=str(wr),
                plugin_cache_glob_exclusions=plugin_ex,
            )
        )
        self.register(
            GlobRuntimeTool(
                workspace_root=str(wr),
                plugin_cache_glob_exclusions=plugin_ex,
                state_bridge=shared_bridge,
            )
        )
        self.register(BashRuntimeTool(state_bridge=shared_bridge))
        self.register(UserMessageTool())
        self.register(AskUserQuestionTool())
        self.register(TaskListRuntimeTool(config=cfg))

        websearch_loader.register(self)
        webfetch_loader.register(self)

        if include_agent:
            from langchain_agentx.tools.agent import AgentRuntimeTool

            self.register(AgentRuntimeTool(registry=agent_registry))

        if include_skill:
            from langchain_agentx.tools.skill import SkillRuntimeTool

            self.register(
                SkillRuntimeTool(
                    workspace_root=workspace_root,
                    agent_home=agent_home,
                )
            )

        return self

    def create_session(self, session_id: str | None = None) -> AgentSessionStore:
        return AgentSessionStore(session_id=session_id)

    def fork_with_tools(self, tools: list[RuntimeTool]) -> "ToolRuntimeLoader":
        """
        基于当前 loader 派生一个子 loader（共享 policy/headless 语义），并注册给定工具集。

        目的：为 subagent 组装“过滤后的工具池”而不丢失权限/管控语义。
        """
        child = ToolRuntimeLoader(
            policy_engine=self._policy,
            headless=self._headless,
            prompt_handler=self._prompt_handler,
            permission_resolver=self._permission_resolver,
        )
        for t in tools:
            child.register(t)
        return child

    def set_permission_resolver(
        self,
        permission_resolver: PermissionResolver | None,
    ) -> None:
        """更新 loader 与 pipeline 的 permission_resolver（包装为 L3 垫片）。"""
        self._permission_resolver = permission_resolver
        self._pipeline.set_permission_resolver(permission_resolver)

    def set_prompt_handler(
        self,
        prompt_handler: PermissionPromptHandler | None,
    ) -> None:
        """更新 loader 与 pipeline 的 prompt_handler。"""
        self._prompt_handler = prompt_handler
        self._pipeline.set_prompt_handler(prompt_handler)

    def update_auto_mode_config(
        self,
        *,
        enabled: bool | None = None,
        classifier_model: str | None = None,
        classifier_path: str | None = None,
        use_classifier: bool | None = None,
        auto_mode_config: AutoModeConfig | None = None,
    ) -> AutoModeConfig:
        """热更新 auto_mode 配置，下一轮 authorize 立即生效。

        Args:
            enabled: 总开关（同步 AutoModeState.enabled）
            classifier_model: 分类器模型 ID
            classifier_path: classifier_model 别名（历史命名兼容）
            use_classifier: 是否启用 L4 LLM 分类器
            auto_mode_config: 整包替换（优先级最高）

        Returns:
            生效后的 AutoModeConfig
        """
        model_id = classifier_model if classifier_model is not None else classifier_path

        if auto_mode_config is not None:
            effective = auto_mode_config
        else:
            current: AutoModeConfig | None = None
            if self._policy_config is not None:
                current = self._policy_config.auto_mode
            elif isinstance(self._policy, DefaultPolicyEngine):
                current = self._policy._config.auto_mode
            effective = merge_auto_mode_config(
                current,
                enabled=enabled,
                classifier_model=model_id,
                use_classifier=use_classifier,
            )

        if self._policy_config is not None:
            apply_auto_mode_config_to_policy(self._policy_config, effective)
        if isinstance(self._policy, DefaultPolicyEngine):
            apply_auto_mode_config_to_engine(self._policy, effective)
        elif enabled is not None:
            get_auto_mode_state().enabled = enabled

        return effective

    @property
    def policy_config(self) -> ToolPolicyConfig | None:
        return self._policy_config

    @property
    def policy(self) -> PolicyEngine | None:
        return self._policy

    @property
    def registry(self) -> RuntimeToolRegistry:
        return self._registry

    @property
    def pipeline(self) -> ToolExecutorPipeline:
        return self._pipeline

    @property
    def adapter(self) -> LangChainAdapter:
        return self._adapter

    def __repr__(self) -> str:
        return f"<ToolRuntimeLoader tools={list(self._registry._tools.keys())}>"
