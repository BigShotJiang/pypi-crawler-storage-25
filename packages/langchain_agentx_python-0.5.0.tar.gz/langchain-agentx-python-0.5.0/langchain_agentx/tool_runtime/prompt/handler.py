"""
prompt/handler.py — PermissionPromptHandler Protocol

职责：
    L3 唯一扩展点：handle(PromptRequest) -> PromptResponse。
"""

from __future__ import annotations

from typing import Protocol

from .types import PromptRequest, PromptResponse


class PermissionPromptHandler(Protocol):
    """L3 HITL 处理器协议（CLI 仓实现 CliInteractivePromptHandler）。"""

    async def handle(self, request: PromptRequest) -> PromptResponse:
        """消费 L2 ask 决策，返回 allow/deny 及可选 updated_input / permission_updates。"""
        ...
