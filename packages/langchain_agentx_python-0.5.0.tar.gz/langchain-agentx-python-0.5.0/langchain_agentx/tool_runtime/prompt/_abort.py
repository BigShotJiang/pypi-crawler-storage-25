"""
prompt/_abort.py — 协作取消等待（对齐 CC AbortSignal）

职责：
    从 ToolExecutionContext.cancel_event 轮询，供 race coordinator 与 abort task 使用。
"""

from __future__ import annotations

import asyncio
import logging
import threading
from typing import Any

from ..models import ToolExecutionContext

logger = logging.getLogger(__name__)


def _resolve_abort_event(ctx: ToolExecutionContext) -> threading.Event | asyncio.Event | None:
    signal = getattr(ctx, "abort_signal", None)
    if signal is not None:
        return signal
    return ctx.cancel_event


async def wait_for_abort(ctx: ToolExecutionContext, *, poll_interval: float = 0.05) -> None:
    """阻塞直至 abort/cancel 触发，随后抛出 CancelledError。"""
    event = _resolve_abort_event(ctx)
    if event is None:
        await asyncio.Event().wait()
        return

    if isinstance(event, asyncio.Event):
        await event.wait()
        raise asyncio.CancelledError("permission prompt aborted")

    loop = asyncio.get_running_loop()
    while True:
        if event.is_set():
            raise asyncio.CancelledError("permission prompt aborted")
        await asyncio.sleep(poll_interval)


async def run_with_branch_timeout(
    coro: Any,
    *,
    timeout: float | None,
    label: str,
) -> Any:
    if timeout is None:
        return await coro
    try:
        return await asyncio.wait_for(coro, timeout=timeout)
    except asyncio.TimeoutError:
        logger.debug("prompt branch %s timed out after %ss", label, timeout)
        return None
