"""
prompt/legacy_resolver_adapter.py — 旧 PermissionResolver 兼容垫片

职责：
    将 ``(tool_name, ask_prompt) -> bool`` 适配为 PermissionPromptHandler。
    下个 minor（0.6.0）计划移除。

链路位置：
    pipeline 仍传入 permission_resolver 时自动包装（Phase 3）。
"""

from __future__ import annotations

import warnings

from ..resolvers.base import PermissionResolver
from .types import PromptDecisionSource, PromptRequest, PromptResponse


class LegacyResolverPromptHandler:
    """单 task 等价 race：仅调用 legacy resolver，无 hook/classifier。"""

    def __init__(self, resolver: PermissionResolver) -> None:
        warnings.warn(
            "PermissionResolver is deprecated; inject PermissionPromptHandler instead. "
            "PermissionResolver will be removed in 0.6.0.",
            DeprecationWarning,
            stacklevel=2,
        )
        self._resolver = resolver

    async def handle(self, request: PromptRequest) -> PromptResponse:
        prompt = request.ask_prompt or request.ask_decision.ask_prompt
        try:
            allowed = await self._resolver(request.tool_name, prompt)
        except Exception as exc:
            return PromptResponse(
                behavior="deny",
                decision_source=PromptDecisionSource.LEGACY_RESOLVER,
                reason=f"legacy resolver failed: {exc}",
            )
        return PromptResponse(
            behavior="allow" if allowed else "deny",
            decision_source=PromptDecisionSource.LEGACY_RESOLVER,
            reason=None if allowed else (prompt or "denied by legacy resolver"),
        )
