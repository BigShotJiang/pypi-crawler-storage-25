"""
prompt/types.py — L3 HITL 数据契约

职责：
    PromptRequest / PromptResponse 与 PermissionUpdate、PromptDecisionSource。
    L2 ask 决策打包为 PromptRequest，L3 产出二态 PromptResponse。

链路位置：
    ToolExecutorPipeline ask 分支 → PermissionPromptHandler.handle（Phase 3 接线）。

当前裁剪：
    PermissionUpdate 为 CC addRules/replaceRules 等的最小 Python 镜像；持久化由 Phase 3 接入。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Literal

from ..models import AuthorizationDecision, ToolExecutionContext


class PromptDecisionSource(StrEnum):
    """L3 决议来源，对齐 CC decisionReason.type。"""

    USER_UI = "user_ui"
    PERMISSION_HOOK = "permission_hook"
    CLASSIFIER = "classifier"
    HEADLESS_FALLBACK = "headless_fallback"
    LEGACY_RESOLVER = "legacy_resolver"


@dataclass(frozen=True)
class PermissionUpdate:
    """
    用户或 hook 同意的权限规则更新（CC PermissionUpdate 子集）。

    type: addRules | replaceRules | removeRules | setMode | addDirectories | removeDirectories
    """

    type: str
    destination: str = "session"
    behavior: str | None = None
    rules: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    mode: str | None = None
    directories: tuple[str, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class PromptRequest:
    """L2 ask → L3 入参；不传 PolicyEngine 实例。"""

    tool_name: str
    input_data: dict[str, Any]
    ctx: ToolExecutionContext
    ask_decision: AuthorizationDecision
    headless: bool
    ask_prompt: str | None = None
    suggestions: tuple[PermissionUpdate, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class PromptResponse:
    """L3 → Pipeline 出参；behavior 仅 allow/deny。"""

    behavior: Literal["allow", "deny"]
    decision_source: PromptDecisionSource
    reason: str | None = None
    updated_input: dict[str, Any] | None = None
    permission_updates: tuple[PermissionUpdate, ...] = field(default_factory=tuple)
