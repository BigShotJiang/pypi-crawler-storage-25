"""
prompt/race.py — HitlRaceCoordinator（L3 默认交互 race）

职责：
    三路并发（PermissionRequest hooks / classifier / user UI）+ FIRST_COMPLETED；
    deny 优先于 allow；abort 与 hard_timeout；finally 取消余 task。

链路位置：
    交互模式 pipeline 默认 prompt_handler（Phase 3 注入）。

当前裁剪：
    hook 链为串行 awaitables 列表；classifier 单实例 Protocol。
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import replace
from typing import Protocol

from ._abort import _resolve_abort_event, run_with_branch_timeout, wait_for_abort
from .handler import PermissionPromptHandler
from .types import PromptDecisionSource, PromptRequest, PromptResponse

logger = logging.getLogger(__name__)

PromptBranch = Callable[[PromptRequest], Awaitable[PromptResponse | None]]


class PromptClassifier(Protocol):
    """可选速判分类器（如 Bash 只读启发式）。"""

    def applies_to(self, tool_name: str) -> bool:
        ...

    async def __call__(self, request: PromptRequest) -> PromptResponse | None:
        ...


def _deny(
    *,
    reason: str,
    source: PromptDecisionSource = PromptDecisionSource.HEADLESS_FALLBACK,
) -> PromptResponse:
    return PromptResponse(
        behavior="deny",
        decision_source=source,
        reason=reason,
    )


def _tag_source(
    resp: PromptResponse,
    source: PromptDecisionSource,
) -> PromptResponse:
    if resp.decision_source == source:
        return resp
    return replace(resp, decision_source=source)


async def _run_hook_chain(
    hooks: Sequence[PromptBranch],
    req: PromptRequest,
    *,
    timeout: float,
) -> PromptResponse | None:
    for index, hook in enumerate(hooks):
        try:
            resp = await run_with_branch_timeout(
                hook(req),
                timeout=timeout,
                label=f"hook[{index}]",
            )
        except Exception as exc:
            logger.warning(
                "permission hook %s failed for tool %s: %s",
                index,
                req.tool_name,
                exc,
                exc_info=True,
            )
            continue
        if resp is not None and resp.behavior in ("allow", "deny"):
            return _tag_source(resp, PromptDecisionSource.PERMISSION_HOOK)
    return None


def _consume_completed(
    done: set[asyncio.Task],
    *,
    task_sources: dict[asyncio.Task, PromptDecisionSource],
    abort_task: asyncio.Task | None,
) -> tuple[PromptResponse | None, PromptResponse | None]:
    """返回 (deny_winner, allow_winner) 本批完成中的最优。"""
    deny: PromptResponse | None = None
    allow: PromptResponse | None = None
    for task in done:
        if task is abort_task:
            continue
        source = task_sources.get(task)
        try:
            result = task.result()
        except Exception as exc:
            label = source.value if source else "unknown"
            logger.warning("prompt branch %s failed: %s", label, exc, exc_info=True)
            continue
        if result is None:
            continue
        if source is not None:
            result = _tag_source(result, source)
        if result.behavior == "deny":
            deny = result
        elif allow is None:
            allow = result
    return deny, allow


class HitlRaceCoordinator:
    """
    默认 L3 交互 race：hooks ‖ classifier ‖ user_ui。

    headless 请求应使用 :class:`HeadlessPromptHandler`；本类在 ``req.headless``
    时仅跑 hook 链并 deny 兜底。
    """

    def __init__(
        self,
        *,
        hooks: Sequence[PromptBranch] | None = None,
        classifier: PromptClassifier | None = None,
        user_ui: PromptBranch | None = None,
        hard_timeout_seconds: float = 60.0,
        hook_timeout_seconds: float = 30.0,
        classifier_timeout_seconds: float = 15.0,
    ) -> None:
        self._hooks = list(hooks or ())
        self._classifier = classifier
        self._user_ui = user_ui
        self._hard_timeout = hard_timeout_seconds
        self._hook_timeout = hook_timeout_seconds
        self._classifier_timeout = classifier_timeout_seconds

    @classmethod
    def default(cls) -> HitlRaceCoordinator:
        """无 hook/classifier/UI 的占位实例（交互期需注入 user_ui）。"""
        return cls()

    async def handle(self, request: PromptRequest) -> PromptResponse:
        if request.headless:
            return await self._run_headless(request)

        task_sources: dict[asyncio.Task, PromptDecisionSource] = {}

        if self._hooks:
            task_sources[
                asyncio.create_task(
                    _run_hook_chain(
                        self._hooks,
                        request,
                        timeout=self._hook_timeout,
                    ),
                    name="permission_hooks",
                )
            ] = PromptDecisionSource.PERMISSION_HOOK

        if self._classifier is not None and self._classifier.applies_to(request.tool_name):
            clf = self._classifier

            async def _classify(req: PromptRequest) -> PromptResponse | None:
                return await run_with_branch_timeout(
                    clf(req),
                    timeout=self._classifier_timeout,
                    label="classifier",
                )

            task_sources[
                asyncio.create_task(_classify(request), name="classifier")
            ] = PromptDecisionSource.CLASSIFIER

        if self._user_ui is not None:
            task_sources[
                asyncio.create_task(self._user_ui(request), name="user_ui")
            ] = PromptDecisionSource.USER_UI

        if not task_sources:
            return _deny(reason="no prompt participants configured")

        abort_task: asyncio.Task[None] | None = None
        if _resolve_abort_event(request.ctx) is not None:
            abort_task = asyncio.create_task(
                wait_for_abort(request.ctx),
                name="abort_wait",
            )

        pending: set[asyncio.Task] = set(task_sources.keys())
        if abort_task is not None:
            pending.add(abort_task)

        best_allow: PromptResponse | None = None

        try:
            while pending:
                done, pending = await asyncio.wait(
                    pending,
                    timeout=self._hard_timeout,
                    return_when=asyncio.FIRST_COMPLETED,
                )
                if not done:
                    return _deny(reason="prompt_timeout")

                if abort_task is not None and abort_task in done:
                    raise asyncio.CancelledError("permission prompt aborted")

                deny_hit, allow_hit = _consume_completed(
                    done,
                    task_sources=task_sources,
                    abort_task=abort_task,
                )
                if deny_hit is not None:
                    logger.debug(
                        "HITL race deny tool=%s source=%s",
                        request.tool_name,
                        deny_hit.decision_source,
                    )
                    return deny_hit
                if allow_hit is not None and best_allow is None:
                    best_allow = allow_hit
        finally:
            for task in pending:
                task.cancel()
            if pending:
                await asyncio.gather(*pending, return_exceptions=True)
            if abort_task is not None and not abort_task.done():
                abort_task.cancel()
                await asyncio.gather(abort_task, return_exceptions=True)

        if best_allow is not None:
            logger.debug(
                "HITL race allow tool=%s source=%s",
                request.tool_name,
                best_allow.decision_source,
            )
            return best_allow
        return _deny(reason="no prompt decision")

    async def _run_headless(self, request: PromptRequest) -> PromptResponse:
        if not self._hooks:
            return _deny(reason="prompts unavailable")
        resp = await _run_hook_chain(
            self._hooks,
            request,
            timeout=self._hook_timeout,
        )
        if resp is not None:
            return resp
        return _deny(reason="prompts unavailable")
