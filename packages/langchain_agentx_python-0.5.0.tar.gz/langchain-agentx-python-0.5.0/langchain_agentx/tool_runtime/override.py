"""
tool_runtime/override.py — deny 决策覆盖（L4 UX seam）

职责：
    记录 policy deny 的 tool_call，供 UI/CLI 展示覆盖横幅；
    apply_override 更新会话态，实际重试由宿主命令路由触发。

链路位置：
    pipeline deny → enrich_blocked_deny_envelope → AgentSessionStore
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from .models import AuthorizationDecision, ToolExecutionContext, ToolResultEnvelope

if TYPE_CHECKING:
    from .session_store import AgentSessionStore

OverrideDecision = Literal["allow", "confirm_deny"]
OverrideActor = Literal["user", "admin"]
RecordStatus = Literal["pending", "allow", "confirm_deny"]


@dataclass
class DenyOverrideRecord:
    """单次 deny 的覆盖记录。"""

    tool_call_id: str
    tool_name: str
    original_decision: AuthorizationDecision
    override_decision: RecordStatus = "pending"
    override_at: float | None = None
    override_by: OverrideActor | None = None

    def to_dict(self) -> dict[str, Any]:
        orig = self.original_decision
        return {
            "tool_call_id": self.tool_call_id,
            "tool_name": self.tool_name,
            "original_decision": {
                "behavior": orig.behavior,
                "message": orig.message,
                "policy_id": orig.policy_id,
                "metadata": orig.metadata,
            },
            "override_decision": self.override_decision,
            "override_at": self.override_at,
            "override_by": self.override_by,
        }


class DenyOverrideManager:
    """deny 覆盖管理器，绑定 AgentSessionStore。"""

    _STORE_KEY = "_deny_overrides"

    def __init__(self, session_store: AgentSessionStore) -> None:
        self._store = session_store
        if not hasattr(session_store, self._STORE_KEY):
            setattr(session_store, self._STORE_KEY, {})

    def _records(self) -> dict[str, DenyOverrideRecord]:
        raw = getattr(self._store, self._STORE_KEY)
        return raw if isinstance(raw, dict) else {}

    def request_override(
        self,
        tool_call_id: str,
        tool_name: str,
        original_decision: AuthorizationDecision,
        *,
        override_by: OverrideActor = "user",
    ) -> DenyOverrideRecord:
        """标记某次 deny 为待覆盖状态，返回记录供 UI 展示。"""
        if not tool_call_id:
            raise ValueError("tool_call_id is required for deny override")

        record = DenyOverrideRecord(
            tool_call_id=tool_call_id,
            tool_name=tool_name,
            original_decision=original_decision,
            override_decision="pending",
            override_by=override_by,
        )
        self._records()[tool_call_id] = record
        self._store.append_audit(
            {
                "event": "deny_override_requested",
                "ts": time.time(),
                **record.to_dict(),
            }
        )
        return record

    def get(self, tool_call_id: str) -> DenyOverrideRecord | None:
        return self._records().get(tool_call_id)

    def apply_override(self, tool_call_id: str, decision: OverrideDecision) -> bool:
        """应用覆盖决策，更新会话状态。"""
        records = self._records()
        record = records.get(tool_call_id)
        if record is None or record.override_decision != "pending":
            return False

        record.override_decision = decision
        record.override_at = time.time()
        self._store.append_audit(
            {
                "event": "deny_override_applied",
                "ts": record.override_at,
                "tool_call_id": tool_call_id,
                "override_decision": decision,
                "override_by": record.override_by,
            }
        )
        return True

    def list_pending(self) -> list[DenyOverrideRecord]:
        return [r for r in self._records().values() if r.override_decision == "pending"]


def enrich_blocked_deny_envelope(
    envelope: ToolResultEnvelope,
    *,
    ctx: ToolExecutionContext,
    auth: AuthorizationDecision,
) -> ToolResultEnvelope:
    """在 blocked deny envelope 上附加 can_override 并登记待覆盖记录。"""
    tool_call_id = ctx.tool_call_id
    if not tool_call_id or auth.behavior != "deny":
        return envelope

    meta = dict(envelope.meta or {})
    meta["can_override"] = True
    meta.setdefault("tool_call_id", tool_call_id)
    meta.setdefault("policy_id", auth.policy_id)

    store = ctx.session_store
    if store is not None:
        mgr = DenyOverrideManager(store)
        record = mgr.request_override(
            tool_call_id,
            ctx.tool_name,
            auth,
        )
        meta["deny_override"] = record.to_dict()

    envelope.meta = meta
    return envelope
