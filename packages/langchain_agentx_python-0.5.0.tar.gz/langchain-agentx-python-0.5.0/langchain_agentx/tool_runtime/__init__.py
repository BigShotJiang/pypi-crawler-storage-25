"""
tool_runtime/ — 工具运行时框架核心包

对外暴露框架的稳定公共接口，外部代码只需从此处导入，
不需要直接依赖子模块路径。
"""

from .adapter import LangChainAdapter
from .base import RuntimeTool
from .errors import (
    ToolInputSchemaError,
    ToolNotFoundError,
    ToolRegistrationError,
    ToolRuntimeError,
    blocked_envelope,
    exception_to_envelope,
    validation_error_envelope,
)
from .models import (
    AuthorizationDecision,
    ToolArtifact,
    ToolErrorInfo,
    ToolExecutionContext,
    ToolHint,
    ToolResultEnvelope,
    ValidationResult,
)
from .identical_call_cache import IdenticalCallMemo
from .loader import ToolRuntimeLoader
from .pipeline import PermissionAskInterrupt, ToolExecutorPipeline, ToolOutputManager
from .policy import DefaultPolicyEngine, PolicyEngine, ToolPolicyConfig
from .policy_decorator import PolicyEngineDecorator
from .prompt import (
    CliInteractivePolicyEngine,
    CliInteractivePromptHandler,
    HeadlessPromptHandler,
    HitlRaceCoordinator,
    LegacyResolverPromptHandler,
    PermissionPromptHandler,
    PermissionUpdate,
    PromptDecisionSource,
    PromptRequest,
    PromptResponse,
    permission_resolver_to_user_ui,
)
from .registry import RuntimeToolRegistry
from .resolvers import (
    AgentSessionPermissionResolver,
    BackgroundPermissionResolver,
    ConversationPermissionResolver,
    PermissionRequest,
    PermissionResolver,
    WorkflowPermissionResolver,
)
from .override import DenyOverrideManager, DenyOverrideRecord, enrich_blocked_deny_envelope
from .session_store import AgentSessionStore, FileReadRecord, FileWriteRecord
from .state_bridge import ToolStateBridge

__all__ = [
    # models
    "ToolExecutionContext",
    "ToolResultEnvelope",
    "ValidationResult",
    "AuthorizationDecision",
    "ToolErrorInfo",
    "ToolHint",
    "ToolArtifact",
    # base
    "RuntimeTool",
    # errors
    "ToolRuntimeError",
    "ToolRegistrationError",
    "ToolNotFoundError",
    "ToolInputSchemaError",
    "exception_to_envelope",
    "blocked_envelope",
    "validation_error_envelope",
    # policy
    "ToolPolicyConfig",
    "PolicyEngine",
    "DefaultPolicyEngine",
    "PolicyEngineDecorator",
    # prompt (L3)
    "PermissionPromptHandler",
    "PermissionUpdate",
    "PromptDecisionSource",
    "PromptRequest",
    "PromptResponse",
    "HitlRaceCoordinator",
    "HeadlessPromptHandler",
    "LegacyResolverPromptHandler",
    "CliInteractivePromptHandler",
    "CliInteractivePolicyEngine",
    "permission_resolver_to_user_ui",
    # state
    "ToolStateBridge",
    # session
    "AgentSessionStore",
    "FileReadRecord",
    "FileWriteRecord",
    # deny override (L4 UX seam)
    "DenyOverrideRecord",
    "DenyOverrideManager",
    "enrich_blocked_deny_envelope",
    # pipeline
    "ToolOutputManager",
    "ToolExecutorPipeline",
    "PermissionAskInterrupt",
    "IdenticalCallMemo",
    "PermissionResolver",
    "PermissionRequest",
    "AgentSessionPermissionResolver",
    "ConversationPermissionResolver",
    "BackgroundPermissionResolver",
    "WorkflowPermissionResolver",
    # adapter
    "LangChainAdapter",
    # registry
    "RuntimeToolRegistry",
    # loader
    "ToolRuntimeLoader",
]
