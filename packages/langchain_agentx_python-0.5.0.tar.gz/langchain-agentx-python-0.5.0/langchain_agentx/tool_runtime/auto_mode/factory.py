"""
tool_runtime/auto_mode/factory.py — Auto Mode 组件工厂

职责：
    提供工厂函数，根据配置构建完整的 Auto Mode 组件栈：
    AutoModeConfig → SafeToolAllowlist → BashReadOnlyClassifier → LLMClassifier → AutoModeAuthHook

链路位置：
    PolicyEngine 初始化 → build_auto_mode_hook() → AutoModeAuthHook

当前裁剪范围（Phase 2）：
    - 支持 L4 LLM 分类器创建
    - 支持显式传入 chat_model 或 chat_model_factory

CC 源码对照：
    - src/utils/permissions/autoModeState.ts:80-120（初始化逻辑）
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable

from .config import AutoModeConfig
from .hook import AutoModeAuthHook
from .allowlist import SafeToolAllowlist

if TYPE_CHECKING:
    from ..policy import ToolPolicyConfig


def build_auto_mode_hook(
    *,
    policy_config: "ToolPolicyConfig | None" = None,
    auto_mode_config: "AutoModeConfig | None" = None,
    bash_classifier: Any | None = None,
    llm_classifier: Any | None = None,
    chat_model: Any | None = None,
    chat_model_factory: Callable[[], Any] | None = None,
    tool_registry: Any | None = None,
    event_bus: Any | None = None,
) -> AutoModeAuthHook | None:
    """构建 Auto Mode Auth Hook。

    Args:
        policy_config: ToolPolicyConfig（用于读取 auto_mode 配置）
        auto_mode_config: 显式 AutoModeConfig（优先级高于 policy_config）
        bash_classifier: L3 Bash 只读分类器（BashReadOnlyClassifier 实例）
        llm_classifier: L4 LLM 分类器（可选，如不提供且 use_classifier=True 则自动创建）
        chat_model: 显式指定的 Chat 模型（用于 LLM 分类器）
        chat_model_factory: Chat 模型工厂函数
        tool_registry: 工具注册表（用于获取 tool 实例）
        event_bus: 事件总线（用于发射决策事件）

    Returns:
        AutoModeAuthHook 实例，如果 auto mode 未启用则返回 None
    """
    # 解析配置
    config = _resolve_auto_mode_config(policy_config, auto_mode_config)

    # 未启用时返回 None
    if not config.enabled:
        return None

    # 构建白名单
    allowlist = _build_allowlist(config)

    # 构建 Bash 只读分类器（如果未提供）
    effective_bash_classifier = bash_classifier
    if effective_bash_classifier is None:
        effective_bash_classifier = _build_bash_classifier()

    # 构建 LLM 分类器（如果需要且未提供）
    effective_llm_classifier = llm_classifier
    if effective_llm_classifier is None and config.use_classifier:
        effective_llm_classifier = _build_llm_classifier(
            config=config,
            chat_model=chat_model,
            chat_model_factory=chat_model_factory,
        )

    # 构建并返回 Hook
    return AutoModeAuthHook(
        config=config,
        allowlist=allowlist,
        bash_classifier=effective_bash_classifier,
        llm_classifier=effective_llm_classifier,
        chat_model_factory=chat_model_factory,
        tool_registry=tool_registry,
        event_bus=event_bus,
    )


def _resolve_auto_mode_config(
    policy_config: "ToolPolicyConfig | None",
    auto_mode_config: "AutoModeConfig | None" = None,
) -> AutoModeConfig:
    """解析 Auto Mode 配置。

    优先级：auto_mode_config > policy_config.auto_mode > 默认值
    """
    if auto_mode_config is not None:
        return auto_mode_config

    if policy_config is not None:
        cfg = getattr(policy_config, "auto_mode", None)
        if isinstance(cfg, AutoModeConfig):
            return cfg

    # 默认配置（未启用）
    return AutoModeConfig(enabled=False)


def _build_allowlist(config: AutoModeConfig) -> SafeToolAllowlist:
    """构建工具白名单。

    合并默认白名单与用户扩展。
    """
    return SafeToolAllowlist(
        extra=config.extra_safe_tools,
    )


def _build_bash_classifier() -> Any:
    """构建 Bash 只读分类器默认实例。

    Returns:
        BashReadOnlyClassifier 实例
    """
    from langchain_agentx.tools.bash.read_only_validation import BashReadOnlyClassifier

    return BashReadOnlyClassifier()


def _build_llm_classifier(
    *,
    config: AutoModeConfig,
    chat_model: Any | None,
    chat_model_factory: Callable[[], Any] | None,
) -> Any | None:
    """构建 LLM 分类器。

    Args:
        config: AutoModeConfig
        chat_model: 显式指定的 Chat 模型
        chat_model_factory: Chat 模型工厂函数

    Returns:
        LLMClassifier 实例，或 None（如果无法创建）
    """
    from .classifier.classifier import LLMClassifier, ClassifierConfig

    # 检查是否有可用的 chat 模型
    has_chat_model = chat_model is not None or chat_model_factory is not None or config.classifier_model is not None

    if not has_chat_model:
        # 无可用模型，返回 None（会在运行时降级到 L5）
        return None

    # 构建分类器配置
    classifier_config = ClassifierConfig(
        timeout_s=config.classifier_timeout_s,
        require_separate_classifier_model=config.require_separate_classifier_model,
    )

    return LLMClassifier(config=classifier_config)


__all__ = [
    "build_auto_mode_hook",
]
