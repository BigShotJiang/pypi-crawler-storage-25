"""
tool_runtime/auto_mode/rule_stripping.py — 危险权限规则剥离

职责：
    实现进入 auto mode 时自动剥离用户配置中过宽的 allow 规则。
    防止分类器被绕过（如 Bash(python:*) 允许任意代码执行）。

链路位置：
    PolicyEngine 模式切换（进入 auto） → strip_dangerous_rules → ToolPermissionContext

当前裁剪范围（Phase 3）：
    - Bash 工具危险模式匹配
    - 权限规则剥离与恢复
    - 事件发射

CC 源码对照：
    - src/utils/permissions/dangerousPatterns.ts — DANGEROUS_BASH_PATTERNS
    - src/utils/permissions/permissionSetup.ts:94-147 — isDangerousBashPermission
    - src/utils/permissions/permissionSetup.ts:510-553 — stripDangerousPermissionsForAutoMode
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..policy import PermissionRule

# =============================================================================
# 跨平台代码执行入口（与 CC 保持一致）
# =============================================================================

CROSS_PLATFORM_CODE_EXEC = [
    # Interpreters
    "python",
    "python3",
    "python2",
    "node",
    "deno",
    "tsx",
    "ruby",
    "perl",
    "php",
    "lua",
    # Package runners
    "npx",
    "bunx",
    "npm run",
    "yarn run",
    "pnpm run",
    "bun run",
    # Shells reachable from both (Git Bash / WSL on Windows, native on Unix)
    "bash",
    "sh",
    # Remote arbitrary-command wrapper (native OpenSSH on Win10+)
    "ssh",
]

# 默认危险 Bash 模式列表
DEFAULT_DANGEROUS_BASH_PATTERNS = [
    *CROSS_PLATFORM_CODE_EXEC,
    # Unix-only shells
    "zsh",
    "fish",
    # Command execution primitives
    "eval",
    "exec",
    "env",
    "xargs",
    "sudo",
]

# =============================================================================
# 数据结构
# =============================================================================

@dataclass(frozen=True)
class StrippedRule:
    """被剥离的权限规则。"""
    rule_value: str
    """规则字符串，如 'Bash(python:*)' 或 'Bash(*)'"""
    source: str
    """规则来源，如 'userSettings' 或 'cliArg'"""


@dataclass(frozen=True)
class StripResult:
    """规则剥离结果。"""
    kept: list["PermissionRule"]
    """保留的安全规则"""
    stripped: list[StrippedRule]
    """被剥离的危险规则"""
    """Total count of rules processed"""
    total_count: int = field(init=False)

    def __post_init__(self):
        object.__setattr__(self, "total_count", len(self.kept) + len(self.stripped))


# =============================================================================
# 危险规则判断
# =============================================================================

def is_dangerous_bash_permission(
    tool_name: str,
    rule_content: str | None,
) -> bool:
    """判断 Bash 权限规则是否危险（会绕过分类器）。

    对应 CC permissionSetup.ts:94-147 的 isDangerousBashPermission

    危险模式：
        1. 工具级 allow（Bash 无 ruleContent）- 允许所有命令
        2. 前缀规则 for 脚本解释器（python:*, node:* 等）
        3. 通配符规则匹配解释器（python*, node* 等）

    Args:
        tool_name: 工具名称，如 "Bash"
        rule_content: 规则内容，如 "python:*" 或 None

    Returns:
        如果规则危险返回 True
    """
    # 仅检查 Bash 规则
    if tool_name != "Bash":
        return False

    # 工具级 allow（Bash 无 ruleContent 或为空）- 允许所有命令
    if rule_content is None or rule_content == "":
        return True

    content = rule_content.strip().lower()

    # 独立通配符 (*) 匹配所有
    if content == "*":
        return True

    # 检查危险模式的各种变体
    for pattern in DEFAULT_DANGEROUS_BASH_PATTERNS:
        lower_pattern = pattern.lower()

        # 完全匹配模式本身（如 "python" 作为规则）
        if content == lower_pattern:
            return True

        # 前缀语法："python:*" 允许任何 python 命令
        if content == f"{lower_pattern}:*":
            return True

        # 尾部通配符："python*" 匹配 python, python3 等
        if content == f"{lower_pattern}*":
            return True

        # 空格通配符："python *" 会匹配 "python script.py"
        if content == f"{lower_pattern} *":
            return True

        # 带破折号通配符："python -*" 会匹配 "python -c 'code'"
        if content.startswith(f"{lower_pattern} -") and content.endswith("*"):
            return True

    return False


# =============================================================================
# 规则剥离器
# =============================================================================

class DangerousRuleStripper:
    """危险权限规则剥离器。

    对应 CC permissionSetup.ts:510-553 的 stripDangerousPermissionsForAutoMode

    职责：
        1. 识别危险的 allow 规则（会绕过分类器）
        2. 从上下文中移除危险规则
        3. 记录被剥离的规则用于恢复
    """

    def __init__(
        self,
        extra_patterns: list[str] | None = None,
        bash_tool_name: str = "Bash",
    ):
        """初始化剥离器。

        Args:
            extra_patterns: 额外的危险模式列表
            bash_tool_name: Bash 工具名称（用于测试灵活性）
        """
        self._patterns = [
            *DEFAULT_DANGEROUS_BASH_PATTERNS,
            *(extra_patterns or []),
        ]
        self._bash_tool_name = bash_tool_name

    def strip(
        self,
        rules: list["PermissionRule"],
    ) -> StripResult:
        """剥离危险权限规则。

        Args:
            rules: 权限规则列表（仅 allow 规则需要检查）

        Returns:
            StripResult，包含保留和被剥离的规则
        """
        kept: list[PermissionRule] = []
        stripped: list[StrippedRule] = []

        for rule in rules:
            # 只检查 allow 规则
            if rule.behavior != "allow":
                kept.append(rule)
                continue

            # 检查是否为危险规则
            if self._is_dangerous(rule):
                # 记录被剥离的规则
                rule_str = self._format_rule(rule)
                stripped.append(StrippedRule(
                    rule_value=rule_str,
                    source=rule.source,
                ))
            else:
                kept.append(rule)

        return StripResult(
            kept=kept,
            stripped=stripped,
        )

    def _is_dangerous(self, rule: "PermissionRule") -> bool:
        """判断规则是否危险。

        Args:
            rule: 权限规则

        Returns:
            如果规则危险返回 True
        """
        tool_name = rule.tool_name
        rule_content = rule.rule_content

        # 使用通用判断函数
        return is_dangerous_bash_permission(tool_name, rule_content)

    @staticmethod
    def _format_rule(rule: "PermissionRule") -> str:
        """格式化规则为字符串。

        Args:
            rule: 权限规则

        Returns:
            规则字符串，如 "Bash(python:*)"
        """
        tool_name = rule.tool_name
        rule_content = rule.rule_content

        if rule_content is None or rule_content == "":
            return f"{tool_name}(*)"
        return f"{tool_name}({rule_content})"


__all__ = [
    "CROSS_PLATFORM_CODE_EXEC",
    "DEFAULT_DANGEROUS_BASH_PATTERNS",
    "StrippedRule",
    "StripResult",
    "is_dangerous_bash_permission",
    "DangerousRuleStripper",
]
