"""
tool_runtime/auto_mode/events.py — Auto Mode 事件定义

职责：
    定义 Auto Mode 决策事件，用于前端可观测性。

链路位置：
    AutoModeAuthHook → AutoModeDecisionEvent → EventBus → 前端

当前裁剪范围：
    - 事件格式对齐设计文档 §6.1.1
    - 暂不实现 override/feedback 事件（Phase 4 前端集成）
"""

from __future__ import annotations

from dataclasses import dataclass, field
from time import time
from typing import Any


@dataclass(frozen=True)
class AutoModeDecisionEvent:
    """Auto Mode 决策事件。

    对应设计文档 §6.1.1

    Attributes:
        event: 事件类型标识，固定为 "auto_mode_decision"
        timestamp: 决策时间戳（ISO 8601 格式）
        session_id: 会话 ID
        tool_use_id: 工具调用 ID
        tool_name: 工具名称
        tool_input_preview: 工具输入预览（脱敏）
        decision: 决策详情（嵌套结构）
    """

    event: str = "auto_mode_decision"
    timestamp: str = field(default_factory=lambda: _iso_timestamp())
    session_id: str | None = None
    tool_use_id: str | None = None
    tool_name: str | None = None
    tool_input_preview: str | None = None
    decision: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_decision(
        cls,
        decision: "AutoModeDecision",
        tool_name: str | None = None,
        tool_input_preview: str | None = None,
        session_id: str | None = None,
        tool_use_id: str | None = None,
    ) -> "AutoModeDecisionEvent":
        """从 AutoModeDecision 构造事件。

        Args:
            decision: Auto Mode 决策结果
            tool_name: 工具名称
            tool_input_preview: 工具输入预览（脱敏）
            session_id: 会话 ID
            tool_use_id: 工具调用 ID

        Returns:
            AutoModeDecisionEvent 实例
        """
        from .decision import AutoModeDecision

        if not isinstance(decision, AutoModeDecision):
            decision  # type: ignore[assignment]

        return cls(
            session_id=session_id,
            tool_use_id=tool_use_id,
            tool_name=tool_name,
            tool_input_preview=tool_input_preview,
            decision={
                "behavior": decision.behavior,
                "reason": decision.reason.value,
                "layer": decision.layer,
                "confidence": decision.confidence,
                "explanation": decision.explanation,
                "matched_pattern": decision.matched_pattern,
                "classifier_thinking": decision.classifier_thinking,
                "elapsed_ms": decision.elapsed_ms,
            },
        )


def _iso_timestamp() -> str:
    """生成 ISO 8601 格式的时间戳。"""
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat(timespec="milliseconds") + "Z"
