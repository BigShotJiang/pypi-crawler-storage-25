"""
tool_runtime/auto_mode/feedback.py — Auto Mode 反馈摄入

职责：
    收集用户对 auto-approve 的纠正信号；有 endpoint 时 POST，否则追加本地 jsonl。

链路位置：
    UI/CLI → FeedbackIngest.submit → Analytics 或 ~/.cache/.../auto_mode_feedback.jsonl
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Literal
from urllib import error as urllib_error
from urllib import request as urllib_request


@dataclass
class AutoModeFeedback:
    tool_use_id: str
    tool_name: str
    was_auto_approved: bool
    user_correction: Literal["approve", "deny"] | None
    model_family: str
    timestamp: float
    session_id: str | None = None
    extra: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        out = asdict(self)
        if out.get("extra") is None:
            out.pop("extra", None)
        return out


class FeedbackIngest:
    """Auto Mode 反馈摄入：本地 jsonl 或 HTTP POST。"""

    def __init__(
        self,
        endpoint: str | None = None,
        *,
        local_path: str | Path | None = None,
        timeout_s: float = 10.0,
    ) -> None:
        self.endpoint = endpoint
        self.timeout_s = timeout_s
        if local_path is None:
            local_path = Path.home() / ".cache" / "langchain_agentx" / "auto_mode_feedback.jsonl"
        self._local_path = Path(local_path)

    def submit(self, feedback: AutoModeFeedback) -> None:
        """提交反馈：有 endpoint 时 POST，否则仅本地 jsonl。"""
        if self.endpoint:
            self._post_remote(feedback)
        else:
            self._append_local(feedback)

    def _append_local(self, feedback: AutoModeFeedback) -> None:
        self._local_path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(feedback.to_dict(), ensure_ascii=False)
        with self._local_path.open("a", encoding="utf-8") as f:
            f.write(line + "\n")

    def _post_remote(self, feedback: AutoModeFeedback) -> None:
        body = json.dumps(feedback.to_dict()).encode("utf-8")
        req = urllib_request.Request(
            self.endpoint,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib_request.urlopen(req, timeout=self.timeout_s) as resp:
                if resp.status >= 400:
                    raise OSError(f"feedback endpoint returned {resp.status}")
        except urllib_error.URLError as exc:
            raise OSError(f"failed to POST auto-mode feedback: {exc}") from exc


def feedback_from_decision_event(
    *,
    tool_use_id: str,
    tool_name: str,
    was_auto_approved: bool,
    user_correction: Literal["approve", "deny"] | None = None,
    model_family: str = "",
    session_id: str | None = None,
) -> AutoModeFeedback:
    """从 UI 事件构造 AutoModeFeedback。"""
    return AutoModeFeedback(
        tool_use_id=tool_use_id,
        tool_name=tool_name,
        was_auto_approved=was_auto_approved,
        user_correction=user_correction,
        model_family=model_family,
        timestamp=time.time(),
        session_id=session_id,
    )
