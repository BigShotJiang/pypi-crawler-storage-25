"""
tool_runtime/auto_mode/config.py — Auto Mode 配置

职责：
    Auto Mode 单一配置入口，集中管理所有 auto-mode 相关开关。
    由 settings.json 解析后传入，禁止散落开关。

链路位置：
    用户配置 → settings.json → AutoModeConfig → AutoModeAuthHook

当前裁剪范围：
    - 暂不实现 acceptEdits fast-path（L2），留待后续扩展
    - 暂不实现 PowerShell 分类器支持（Phase 1 仅关注 Bash）
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable


@dataclass(frozen=True)
class AutoModeConfig:
    """auto mode 单一配置入口，由 settings 读入，禁止散落开关。

    设计文档：docs/design-docs/tool-design/auto-mode-bash-classifier.html §5.1

    Attributes:
        enabled: 总开关。False 时整个 hook 走 passthrough，等同于未启用
        use_classifier: 是否启用 LLM 兜底。False 时 fast-path miss → ask
        classifier_model: 分类器使用的模型 ID（与主 loop 解耦，支持小模型加速）
                           None = 不配独立模型，运行时回落到 ctx.model（父 loop 模型）
                           推荐生产环境显式配 "anthropic:claude-haiku-4-5-20251001" 等小模型
        require_separate_classifier_model: True = 强制要求独立分类器模型；未配置时直接抛 AutoModeConfigError
                                         False（默认）= 允许 ctx.model 兜底，开箱即用
        classifier_timeout_s: 分类器超时（秒），超时后 fail-closed 降级为 ask
        strip_dangerous_rules: 进入 auto 时是否剥离危险 allow 规则（推荐 True）
        emit_decision_events: 是否将分类器决策投递到事件总线（前端可观测）
        transcript_max_turns: 分类器 transcript 截取的最近 N 轮（控制成本）
        extra_safe_tools: 额外的安全工具白名单（扩展 L1 白名单）
        extra_dangerous_patterns: 额外的危险 Bash 模式（扩展 DANGEROUS_BASH_PATTERNS）
    """

    # 总开关
    enabled: bool = False

    # LLM 分类器开关
    use_classifier: bool = True

    # 分类器模型配置
    classifier_model: str | None = None
    require_separate_classifier_model: bool = False

    # 分类器超时
    classifier_timeout_s: float = 8.0

    # 规则剥离
    strip_dangerous_rules: bool = True
    extra_dangerous_patterns: tuple[str, ...] = ()

    # 事件与观测
    emit_decision_events: bool = True
    transcript_max_turns: int = 20

    # 工具白名单扩展
    extra_safe_tools: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AutoModeConfig":
        """从 dict 构造，支持 camelCase / snake_case 双兼容。

        Args:
            data: 配置字典，支持 camelCase（settings.json）和 snake_case（SDK）

        Returns:
            AutoModeConfig 实例
        """
        # 辅助函数：优先 camelCase，兜底 snake_case
        def get(key: str, alt: str, default: Any = None) -> Any:
            return data.get(key, data.get(alt, default))

        # 处理 tuple 类型字段
        extra_safe = get("extraSafeTools", "extra_safe_tools", ())
        if isinstance(extra_safe, list):
            extra_safe = tuple(extra_safe)

        extra_dangerous = get("extraDangerousPatterns", "extra_dangerous_patterns", ())
        if isinstance(extra_dangerous, list):
            extra_dangerous = tuple(extra_dangerous)

        return cls(
            enabled=get("enabled", "enabled", False),
            use_classifier=get("useClassifier", "use_classifier", True),
            classifier_model=get("classifierModel", "classifier_model"),
            require_separate_classifier_model=get(
                "requireSeparateClassifierModel", "require_separate_classifier_model", False
            ),
            classifier_timeout_s=get(
                "classifierTimeoutS", "classifier_timeout_s", 8.0
            ),
            strip_dangerous_rules=get(
                "stripDangerousRules", "strip_dangerous_rules", True
            ),
            emit_decision_events=get(
                "emitDecisionEvents", "emit_decision_events", True
            ),
            transcript_max_turns=get(
                "transcriptMaxTurns", "transcript_max_turns", 20
            ),
            extra_safe_tools=extra_safe,
            extra_dangerous_patterns=extra_dangerous,
        )

    def to_dict(self) -> dict[str, Any]:
        """转换为 dict，输出 camelCase（对齐 settings.json 习惯）。

        Returns:
            camelCase 风格的配置字典
        """
        return {
            "enabled": self.enabled,
            "useClassifier": self.use_classifier,
            "classifierModel": self.classifier_model,
            "requireSeparateClassifierModel": self.require_separate_classifier_model,
            "classifierTimeoutS": self.classifier_timeout_s,
            "stripDangerousRules": self.strip_dangerous_rules,
            "emitDecisionEvents": self.emit_decision_events,
            "transcriptMaxTurns": self.transcript_max_turns,
            "extraSafeTools": list(self.extra_safe_tools) if self.extra_safe_tools else [],
            "extraDangerousPatterns": list(self.extra_dangerous_patterns) if self.extra_dangerous_patterns else [],
        }


@dataclass(frozen=True)
class AutoModeConfigError(Exception):
    """Auto Mode 配置错误。"""

    message: str


def validate_auto_mode_config(config: AutoModeConfig) -> None:
    """验证 AutoModeConfig 的有效性。

    Raises:
        AutoModeConfigError: 配置无效时
    """
    if config.classifier_timeout_s <= 0:
        raise AutoModeConfigError(
            message="classifier_timeout_s must be positive"
        )

    if config.transcript_max_turns < 0:
        raise AutoModeConfigError(
            message="transcript_max_turns must be non-negative"
        )

    if config.strip_dangerous_rules and not config.extra_dangerous_patterns:
        # 这是合法的：使用默认的 DANGEROUS_BASH_PATTERNS
        pass
