"""
tool_runtime/auto_mode/allowlist.py — L1 工具白名单

职责：
    静态白名单查表器，对应 CC SAFE_YOLO_ALLOWLISTED_TOOLS。
    命中白名单的工具直接 allow，零 LLM 调用。

链路位置：
    AutoModeAuthHook._decide() → SafeToolAllowlist.contains() → allow

当前裁剪范围：
    - 暂不包含 Edit / Write（L2 acceptEdits fast-path 待后续实现）
    - 白名单基于 CC classifierDecision.ts:56-94 迁移

CC 源码对照：
    src/utils/permissions/classifierDecision.ts: SAFE_YOLO_ALLOWLISTED_TOOLS
"""

from __future__ import annotations

from typing import Iterable


class SafeToolAllowlist:
    """静态白名单查表器。对应 CC SAFE_YOLO_ALLOWLISTED_TOOLS。

    设计文档：docs/design-docs/tool-design/auto-mode-bash-classifier.html §5.3

    命中白名单的工具直接 allow，无需调用 LLM 分类器。

    白名单内容（对照 CC）：
        - 只读文件操作：Read / Glob / Grep
        - 任务管理（仅元数据）：TodoWrite / TaskCreate / TaskGet / TaskList /
                                TaskUpdate / TaskStop / TaskOutput
        - UI / 计划态：AskUserQuestion / EnterPlanMode / ExitPlanMode
        - Skill 加载（无副作用）：Skill
        - UserMessage（带外通信）

    注意：
        Edit / Write 不进默认白名单，走 acceptEdits fast-path（L2，待实现）。
    """

    # CC SAFE_YOLO_ALLOWLISTED_TOOLS 迁移
    DEFAULT_TOOLS: frozenset[str] = frozenset({
        # 只读文件操作
        "Read",
        "Glob",
        "Grep",
        # 任务管理（仅元数据）
        "TodoWrite",
        "TaskCreate",
        "TaskGet",
        "TaskList",
        "TaskUpdate",
        "TaskStop",
        "TaskOutput",
        # UI / 计划态
        "AskUserQuestion",
        "EnterPlanMode",
        "ExitPlanMode",
        # Skill 加载（无副作用）
        "Skill",
        # UserMessage（带外通信）
        "UserMessage",
    })

    def __init__(self, extra: Iterable[str] | None = None):
        """初始化白名单。

        Args:
            extra: 额外的安全工具名称（扩展默认白名单）
        """
        self._tools: frozenset[str] = frozenset(self.DEFAULT_TOOLS) | frozenset(extra or ())

    def contains(self, tool_name: str) -> bool:
        """检查工具是否在白名单中。

        Args:
            tool_name: 工具名称

        Returns:
            True 如果在白名单中，否则 False
        """
        return tool_name in self._tools

    @property
    def tools(self) -> frozenset[str]:
        """返回当前白名单的所有工具（只读）。"""
        return self._tools
