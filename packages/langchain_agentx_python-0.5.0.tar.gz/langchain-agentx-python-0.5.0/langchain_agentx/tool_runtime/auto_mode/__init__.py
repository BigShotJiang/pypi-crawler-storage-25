"""
tool_runtime/auto_mode/ — Auto Mode 决策骨架包

职责：
    跨工具的 auto-mode 决策骨架，实现三段式决策：
    L1 工具白名单 + L3 Bash 启发式 + L4 LLM 分类器

模块划分（对应设计文档 §4.2.1）：
    - config.py: AutoModeConfig（开关 / 阈值 / 模型）
    - decision.py: AutoModeDecision dataclass + Reason 枚举
    - state.py: AutoModeState（全局开关 + 累计 denial 计数）
    - allowlist.py: SafeToolAllowlist（L1 静态白名单）
    - events.py: AutoModeDecisionEvent（前端可观测）
    - hook.py: AutoModeAuthHook（PRE_TOOL_USE Hook 集成）
    - factory.py: build_auto_mode_hook（组件工厂）

依赖方向约束（重要）：
    骨架（auto_mode/*）不得直接 import tools/bash/{read_only_validation, bash_hardening}，
    只允许 import tools/bash/auto_mode_adapter。
    这是"跨工具骨架 vs 工具自家细节"的边界（§4.2.3）。

CC 源码对照：
    - src/utils/permissions/permissions.ts（决策入口）
    - src/utils/permissions/classifierDecision.ts（L1 白名单）
    - src/utils/permissions/yoloClassifier.ts（L4 LLM 分类器，Phase 2）
    - src/utils/permissions/autoModeState.ts（状态管理）
"""

from .config import AutoModeConfig, AutoModeConfigError, validate_auto_mode_config
from .decision import (
    AutoModeDecision,
    AutoModeReason,
    _allow,
    _ask,
    _deny,
    _passthrough,
)
from .state import AutoModeState, get_auto_mode_state
from .allowlist import SafeToolAllowlist
from .events import AutoModeDecisionEvent
from .hook import AutoModeAuthHook
from .factory import build_auto_mode_hook
from .feedback import AutoModeFeedback, FeedbackIngest, feedback_from_decision_event
from .rule_stripping import (
    CROSS_PLATFORM_CODE_EXEC,
    DEFAULT_DANGEROUS_BASH_PATTERNS,
    StrippedRule,
    StripResult,
    is_dangerous_bash_permission,
    DangerousRuleStripper,
)

__all__ = [
    # Config
    "AutoModeConfig",
    "AutoModeConfigError",
    "validate_auto_mode_config",
    # Decision
    "AutoModeDecision",
    "AutoModeReason",
    "_allow",
    "_ask",
    "_deny",
    "_passthrough",
    # State
    "AutoModeState",
    "get_auto_mode_state",
    # Allowlist
    "SafeToolAllowlist",
    # Events
    "AutoModeDecisionEvent",
    # Hook
    "AutoModeAuthHook",
    # Factory
    "build_auto_mode_hook",
    # Feedback
    "AutoModeFeedback",
    "FeedbackIngest",
    "feedback_from_decision_event",
    # Rule Stripping
    "CROSS_PLATFORM_CODE_EXEC",
    "DEFAULT_DANGEROUS_BASH_PATTERNS",
    "StrippedRule",
    "StripResult",
    "is_dangerous_bash_permission",
    "DangerousRuleStripper",
]
