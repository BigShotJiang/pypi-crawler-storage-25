"""
tool_runtime/auto_mode/config_update.py — Auto Mode 配置热更新

职责：
    在运行时合并/替换 AutoModeConfig，并同步 PolicyEngine hook 与全局开关。
"""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING, Any

from .config import AutoModeConfig
from .state import get_auto_mode_state

if TYPE_CHECKING:
    from ..policy import DefaultPolicyEngine, ToolPolicyConfig


def merge_auto_mode_config(
    current: AutoModeConfig | None,
    *,
    enabled: bool | None = None,
    classifier_model: str | None = None,
    use_classifier: bool | None = None,
) -> AutoModeConfig:
    """基于当前配置生成新的 AutoModeConfig（frozen dataclass replace）。"""
    base = current if current is not None else AutoModeConfig()
    fields: dict[str, Any] = {}
    if enabled is not None:
        fields["enabled"] = enabled
    if classifier_model is not None:
        fields["classifier_model"] = classifier_model
    if use_classifier is not None:
        fields["use_classifier"] = use_classifier
    if not fields:
        return base
    return replace(base, **fields)


def apply_auto_mode_config_to_engine(
    engine: DefaultPolicyEngine,
    config: AutoModeConfig,
) -> None:
    """将 AutoModeConfig 写入 DefaultPolicyEngine 与已挂载的 hook。"""
    engine._config.auto_mode = config
    hook = engine._auto_mode_hook
    if hook is not None and hasattr(hook, "update_config"):
        hook.update_config(config)
    get_auto_mode_state().enabled = config.enabled


def apply_auto_mode_config_to_policy(
    policy_config: ToolPolicyConfig,
    config: AutoModeConfig,
) -> None:
    """更新 ToolPolicyConfig.auto_mode 字段。"""
    policy_config.auto_mode = config
    get_auto_mode_state().enabled = config.enabled
