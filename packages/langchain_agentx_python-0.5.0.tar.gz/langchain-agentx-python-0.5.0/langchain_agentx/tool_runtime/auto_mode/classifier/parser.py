"""
tool_runtime/auto_mode/classifier/parser.py — 工具调用解析器

职责：
    解析 LLM 分类器返回的 classify_result 工具调用。

链路位置：
    LLMClassifier.classify() → chat.ainvoke() → ToolUseParser.parse()

当前裁剪范围（Phase 2）：
    - 解析 classify_result 工具调用
    - 提取 thinking / should_block / reason
    - 错误处理（缺失字段、格式错误）

CC 源码对照：
    - src/utils/permissions/classifierShared.ts — tool_use 解析共享工具
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from langchain_core.messages import AIMessage


@dataclass
class ClassifierResult:
    """分类器解析结果。"""

    thinking: str
    """分类思考过程。"""

    should_block: bool
    """是否阻止此操作。"""

    reason: str
    """决策原因说明。"""

    raw: dict[str, Any] | None = None
    """原始工具调用数据（用于调试）。"""


class ParseError(Exception):
    """解析错误。"""

    def __init__(self, message: str, raw_data: Any | None = None):
        super().__init__(message)
        self.raw_data = raw_data


class ToolUseParser:
    """工具调用解析器。

    对应 CC classifierShared.ts 的 tool_use 解析逻辑。
    """

    def parse(self, response: "AIMessage") -> ClassifierResult:
        """解析 LLM 响应中的 classify_result 工具调用。

        Args:
            response: LLM 返回的 AIMessage

        Returns:
            ClassifierResult

        Raises:
            ParseError: 解析失败
        """
        if not response.tool_calls:
            raise ParseError("No tool calls in response", raw_data=response.content)

        # 查找 classify_result 工具调用
        classify_call = None
        for tool_call in response.tool_calls:
            if tool_call.get("name") == "classify_result":
                classify_call = tool_call
                break

        if not classify_call:
            raise ParseError(
                f"No classify_result tool call found. Got: {[tc.get('name') for tc in response.tool_calls]}",
                raw_data=response.tool_calls,
            )

        # 提取参数
        args = classify_call.get("args", {})
        if not isinstance(args, dict):
            raise ParseError(f"Tool args is not a dict: {type(args)}", raw_data=args)

        # 验证必填字段
        required_fields = ["thinking", "should_block", "reason"]
        missing_fields = [f for f in required_fields if f not in args]
        if missing_fields:
            raise ParseError(
                f"Missing required fields: {missing_fields}",
                raw_data=args,
            )

        thinking = args["thinking"]
        should_block = args["should_block"]
        reason = args["reason"]

        # 类型验证
        if not isinstance(thinking, str):
            raise ParseError(f"thinking must be string, got {type(thinking)}", raw_data=args)
        if not isinstance(should_block, bool):
            raise ParseError(f"should_block must be bool, got {type(should_block)}", raw_data=args)
        if not isinstance(reason, str):
            raise ParseError(f"reason must be string, got {type(reason)}", raw_data=args)

        return ClassifierResult(
            thinking=thinking,
            should_block=should_block,
            reason=reason,
            raw=args,
        )

    def parse_safe(self, response: "AIMessage") -> ClassifierResult | None:
        """安全解析，失败时返回 None。

        Args:
            response: LLM 返回的 AIMessage

        Returns:
            ClassifierResult 或 None
        """
        try:
            return self.parse(response)
        except ParseError:
            return None


# ---------------------------------------------------------------------------
# 单例实例
# ---------------------------------------------------------------------------

_default_parser: ToolUseParser | None = None


def get_tool_use_parser() -> ToolUseParser:
    """获取全局 ToolUseParser 实例。"""
    global _default_parser
    if _default_parser is None:
        _default_parser = ToolUseParser()
    return _default_parser


# 便捷函数
def parse_classifier_result(response: "AIMessage") -> ClassifierResult:
    """解析分类器结果（便捷函数）。"""
    return get_tool_use_parser().parse(__validate_response(response))


def __validate_response(response: Any) -> "AIMessage":
    """验证响应类型（内部使用）。"""
    # 延迟导入避免循环依赖
    from langchain_core.messages import AIMessage

    if not isinstance(response, AIMessage):
        raise ParseError(f"Expected AIMessage, got {type(response)}")
    return response


__all__ = [
    "ClassifierResult",
    "ParseError",
    "ToolUseParser",
    "get_tool_use_parser",
    "parse_classifier_result",
]
