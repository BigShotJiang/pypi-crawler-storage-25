"""
tool_runtime/auto_mode/classifier/transcript.py — Transcript 构建器

职责：
    为 LLM 分类器构建输入上下文（transcript）。
    安全设计：只保留 HumanMessage + AIMessage.tool_calls，丢弃 AIMessage.content。

链路位置：
    LLMClassifier.classify() → TranscriptBuilder.build() → chat.ainvoke()

当前裁剪范围（Phase 2）：
    - 实现基础 transcript 构建
    - 实现安全过滤（丢弃 assistant 文本）
    - 支持 transcript_max_turns 截取

CC 源码对照：
    - src/utils/permissions/yoloClassifier.ts:344-345 — transcript 剔除 assistant 文本
    - src/utils/permissions/classifierShared.ts — tool_use 解析共享工具
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from langchain_core.messages import BaseMessage, HumanMessage, AIMessage


@dataclass
class TranscriptConfig:
    """Transcript 构建配置。"""

    max_turns: int = 20
    """最大保留轮次（包含当前 tool_call）。"""

    include_system_messages: bool = False
    """是否包含 system 消息（分类器通常不需要）。"""

    exclude_assistant_content: bool = True
    """
    是否排除 AIMessage.content（安全设计）。

    CC 的安全设计：防止用户通过让 assistant 生成"有说服力"的文本
    来注入分类器，使其认为某个危险操作是安全的。
    """


@dataclass
class BuiltTranscript:
    """构建好的 transcript。"""

    messages: list["BaseMessage"]
    """用于传入 LLM 的消息列表。"""

    turn_count: int
    """实际保留的轮次数。"""

    filtered_content_count: int
    """被过滤掉的 assistant 内容数量。"""


class TranscriptBuilder:
    """Transcript 构建器。

    对应 CC classifierShared.ts + yoloClassifier.ts transcript 构建逻辑。

    安全设计：
        默认丢弃 AIMessage.content，只保留 tool_calls。
        这是为了防止提示词注入：用户可以让 assistant 生成
        "有说服力"的文本来影响分类器判断。
    """

    def __init__(self, config: TranscriptConfig | None = None):
        """初始化 TranscriptBuilder。

        Args:
            config: 构建配置，默认使用 TranscriptConfig()
        """
        self._config = config or TranscriptConfig()

    def build(
        self,
        messages: list["BaseMessage"],
        action_text: str,
    ) -> BuiltTranscript:
        """构建分类器输入 transcript。

        Args:
            messages: 原始消息历史（来自 conversation session）
            action_text: 当前待分类的操作描述（tool_name + tool_input）

        Returns:
            BuiltTranscript，包含过滤后的消息列表和统计信息
        """
        from langchain_core.messages import HumanMessage, AIMessage

        filtered_content_count = 0
        result_messages: list["BaseMessage"] = []

        # 从最新消息开始遍历，保留 max_turns 轮
        turn_count = 0
        for msg in reversed(messages):
            if turn_count >= self._config.max_turns:
                break

            # 处理 HumanMessage
            if isinstance(msg, HumanMessage):
                result_messages.insert(0, msg)
                turn_count += 1
                continue

            # 处理 AIMessage
            if isinstance(msg, AIMessage):
                # 安全设计：排除 assistant content
                if self._config.exclude_assistant_content and msg.content:
                    filtered_content_count += 1

                # 保留有 tool_calls 或有原始 content 的 AIMessage
                if msg.tool_calls or (self._config.exclude_assistant_content and msg.content):
                    # 创建一个不含 content 的 AIMessage
                    result_messages.insert(
                        0,
                        AIMessage(
                            content="",  # 清空 content
                            tool_calls=msg.tool_calls or [],
                            additional_kwargs=msg.additional_kwargs,
                        ),
                    )
                    # tool_calls 不算新轮次，轮次由 HumanMessage 决定
                continue

            # 可选：保留 system 消息
            if self._config.include_system_messages and msg.type == "system":
                result_messages.insert(0, msg)

        return BuiltTranscript(
            messages=result_messages,
            turn_count=turn_count,
            filtered_content_count=filtered_content_count,
        )

    def build_with_action_context(
        self,
        messages: list["BaseMessage"],
        tool_name: str,
        tool_input: dict[str, Any],
        action_text: str | None = None,
    ) -> list["BaseMessage"]:
        """构建包含当前操作上下文的 transcript。

        Args:
            messages: 原始消息历史
            tool_name: 工具名称
            tool_input: 工具输入
            action_text: 操作描述（可选，默认自动生成）

        Returns:
            用于 LLM 调用的消息列表（末尾附加当前操作上下文）
        """
        from langchain_core.messages import HumanMessage

        # 构建 transcript
        built = self.build(messages, action_text or "")

        # 添加当前操作上下文
        action_msg = HumanMessage(
            content=self._format_action_context(tool_name, tool_input, action_text)
        )
        built.messages.append(action_msg)

        return built.messages

    def _format_action_context(
        self,
        tool_name: str,
        tool_input: dict[str, Any],
        action_text: str | None,
    ) -> str:
        """格式化当前操作上下文。"""
        if action_text:
            return f"当前操作：{action_text}"

        # 默认格式
        input_preview = self._preview_input(tool_input)
        return f"当前操作：{tool_name} {input_preview}"

    def _preview_input(self, tool_input: dict[str, Any], max_len: int = 100) -> str:
        """生成输入预览（截断）。"""
        import json

        try:
            preview = json.dumps(tool_input, ensure_ascii=False)
            if len(preview) > max_len:
                preview = preview[:max_len] + "..."
            return preview
        except Exception:
            return str(tool_input)[:max_len]


# ---------------------------------------------------------------------------
# 单例实例（可选）
# ---------------------------------------------------------------------------

_default_builder: TranscriptBuilder | None = None


def get_transcript_builder(config: TranscriptConfig | None = None) -> TranscriptBuilder:
    """获取全局 TranscriptBuilder 实例。"""
    global _default_builder
    if _default_builder is None or config is not None:
        _default_builder = TranscriptBuilder(config)
    return _default_builder


__all__ = [
    "TranscriptConfig",
    "BuiltTranscript",
    "TranscriptBuilder",
    "get_transcript_builder",
]
