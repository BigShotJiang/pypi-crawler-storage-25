"""
tool_runtime/auto_mode/classifier/ — LLM 分类器子包

职责：
    实现 Auto Mode 的 L4 LLM 分类器，用于 fast-path miss 后的兜底决策。

模块划分：
    - schema.py: CLASSIFY_RESULT_TOOL_SCHEMA（工具调用 schema）
    - transcript.py: TranscriptBuilder（构建分类器输入上下文）
    - prompt.py: AutoModePromptBuilder（构建 system prompt）
    - classifier.py: LLMClassifier（核心分类逻辑）
    - parser.py: ToolUseParser（解析分类器返回）

依赖方向约束：
    本子模块可依赖 auto_mode 基础模块（config, decision），不得依赖 Bash 工具内部。

CC 源码对照：
    - src/utils/permissions/yoloClassifier.ts:1012 — classifyYoloAction
    - src/utils/permissions/yoloClassifier.ts:344-345 — transcript 安全设计
"""

from .schema import CLASSIFY_RESULT_TOOL_SCHEMA
from .transcript import TranscriptBuilder, get_transcript_builder
from .prompt import AutoModePromptBuilder, get_prompt_builder
from .classifier import LLMClassifier
from .parser import ToolUseParser, parse_classifier_result

__all__ = [
    # Schema
    "CLASSIFY_RESULT_TOOL_SCHEMA",
    # Transcript
    "TranscriptBuilder",
    "get_transcript_builder",
    # Prompt
    "AutoModePromptBuilder",
    "get_prompt_builder",
    # Classifier
    "LLMClassifier",
    # Parser
    "ToolUseParser",
    "parse_classifier_result",
]
