"""
tool_runtime/auto_mode/classifier/prompt.py — System Prompt 构建器

职责：
    为 LLM 分类器构建 system prompt。
    优先迁移 CC 提示词，中文化时保持结构一致。

链路位置：
    LLMClassifier.classify() → AutoModePromptBuilder.build() → system prompt

当前裁剪范围（Phase 2）：
    - 基础 system prompt（中文化版）
    - BLOCK/ALLOW 清单
    - uncertain → BLOCK 原则
    - 调用 classify_result tool 要求

CC 源码对照：
    - src/utils/permissions/yoloClassifier.ts:system prompt
"""

from __future__ import annotations

from dataclasses import dataclass


# ---------------------------------------------------------------------------
# System Prompt 模板（中文化版，CC 原文对照）
# ---------------------------------------------------------------------------

_DEFAULT_SYSTEM_PROMPT = """你是一个安全分类器，用于判断 AI Agent 的工具调用是否安全。

# 任务

判断当前操作是否需要用户确认。如果操作是安全的（只读、无破坏性），允许执行；否则阻止并要求用户确认。

# 判断原则

1. **不确定时阻止**：如果不确定操作是否安全，默认阻止（优先安全）
2. **只读操作通常安全**：读取文件、列出目录、搜索内容等只读操作通常允许
3. **写操作需要确认**：修改文件、执行命令、删除内容等写操作需要确认
4. **系统命令风险高**：执行 shell 命令（特别是 Bash）风险较高，需要仔细判断
5. **网络操作需谨慎**：下载、上传、网络请求等操作需要确认

# 操作类型示例

## 通常允许（ALLOW）

- 文件读取：Read、Glob、Grep
- 信息查看：ls、cat、git status、git log
- 任务管理：TaskCreate、TaskList、TaskGet（只读元数据操作）
- 交互确认：AskUserQuestion（用户交互类）

## 需要确认（BLOCK）

- 文件修改：Write、Edit
- 命令执行：Bash（特别是包含 python/node/rm/sudo 等的命令）
- 网络操作：WebSearch、WebFetch（取决于配置）
- 删除操作：rm、git clean、git reset

# 输出要求

使用 classify_result 工具返回结果：
- thinking：简述你的判断过程
- should_block：true 表示需要用户确认，false 表示允许执行
- reason：简短的原因说明（给用户看）

# 注意事项

- thinking 用于记录推理过程，可以详细一些
- reason 要简洁明了，用户会看到这个说明
- 当操作涉及路径时，注意路径是否在允许的工作目录内
- 注意命令参数：某些命令的特定参数可能带来风险（如 rm -rf）"""


@dataclass
class PromptConfig:
    """System Prompt 配置。"""

    custom_prompt: str | None = None
    """自定义 system prompt（覆盖默认模板）。"""

    include_tool_list: bool = True
    """是否在 prompt 中包含工具列表（当前未使用，预留）。"""

    language: str = "zh-CN"
    """提示词语言（zh-CN 或 en）。"""


class AutoModePromptBuilder:
    """System Prompt 构建器。

    对应 CC yoloClassifier.ts 的 system prompt 部分。

    设计原则：
        - 优先迁移 CC 提示词结构
        - 中文化时保持语义一致
        - uncertain → BLOCK 原则
    """

    def __init__(self, config: PromptConfig | None = None):
        """初始化 PromptBuilder。

        Args:
            config: 提示词配置
        """
        self._config = config or PromptConfig()

    def build(self) -> str:
        """构建 system prompt。

        Returns:
            system prompt 字符串
        """
        if self._config.custom_prompt:
            return self._config.custom_prompt

        if self._config.language == "en":
            return self._get_english_prompt()

        return _DEFAULT_SYSTEM_PROMPT

    def _get_english_prompt(self) -> str:
        """英文版 system prompt（CC 原文风格）。"""
        return """You are a safety classifier for AI Agent tool calls.

# Task

Determine if the current action requires user confirmation. If the action is safe (read-only, non-destructive), allow it; otherwise block it and require user confirmation.

# Principles

1. **When in doubt, block**: If unsure whether an action is safe, default to blocking (safety first)
2. **Read-only is usually safe**: Reading files, listing directories, searching content are usually allowed
3. **Write operations need confirmation**: Modifying files, executing commands, deleting content require confirmation
4. **System commands are high-risk**: Executing shell commands (especially Bash) carries higher risk
5. **Network operations need caution**: Downloading, uploading, network requests require confirmation

# Common Operations

## Usually Allowed (ALLOW)

- File reading: Read, Glob, Grep
- Information viewing: ls, cat, git status, git log
- Task management: TaskCreate, TaskList, TaskGet (read-only metadata)
- User interaction: AskUserQuestion

## Require Confirmation (BLOCK)

- File modification: Write, Edit
- Command execution: Bash (especially with python/node/rm/sudo)
- Network operations: WebSearch, WebFetch (depends on config)
- Deletion: rm, git clean, git reset

# Output Format

Use the classify_result tool to return:
- thinking: Brief explanation of your reasoning
- should_block: true to require confirmation, false to allow
- reason: Short explanation for the user

# Notes

- thinking records your reasoning process
- reason should be concise and user-friendly
- Pay attention to file paths when provided
- Watch command parameters: certain flags add risk (e.g., rm -rf)"""


# ---------------------------------------------------------------------------
# 单例实例
# ---------------------------------------------------------------------------

_default_builder: AutoModePromptBuilder | None = None


def get_prompt_builder(config: PromptConfig | None = None) -> AutoModePromptBuilder:
    """获取全局 PromptBuilder 实例。"""
    global _default_builder
    if _default_builder is None or config is not None:
        _default_builder = AutoModePromptBuilder(config)
    return _default_builder


__all__ = [
    "AutoModePromptBuilder",
    "PromptConfig",
    "get_prompt_builder",
]
