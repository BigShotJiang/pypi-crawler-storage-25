"""
tool_runtime/auto_mode/classifier/schema.py — LLM 分类器工具调用 Schema

职责：
    定义 classify_result 工具的 JSON Schema，用于强制 LLM 输出结构化结果。

链路位置：
    LLMClassifier.ainvoke() → chat.ainvoke(..., tools=[CLASSIFY_RESULT_TOOL_SCHEMA])
                          → ToolUseParser.parse()

当前裁剪范围（Phase 2）：
    - 基础字段：thinking, should_block, reason
    - 未来扩展：confidence, suggested_alternative

CC 源码对照：
    - src/utils/permissions/yoloClassifier.ts:BLOCK/ALLOW 工具定义
"""

from __future__ import annotations

from typing import Literal

# ---------------------------------------------------------------------------
# CLASSIFY_RESULT_TOOL_SCHEMA
# ---------------------------------------------------------------------------

CLASSIFY_RESULT_TOOL_SCHEMA: dict = {
    "type": "function",
    "function": {
        "name": "classify_result",
        "description": (
            "返回 Auto Mode 工具调用的分类结果。"
            "根据工具名称、输入参数和对话上下文，判断此操作是否安全。"
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "thinking": {
                    "type": "string",
                    "description": (
                        "分类思考过程。解释为什么做出此决策，考虑了哪些因素。"
                        "应简明扼要，不超过 200 字。"
                    ),
                },
                "should_block": {
                    "type": "boolean",
                    "description": (
                        "是否阻止此操作。"
                        "true = 阻止（需要用户确认），false = 允许（直接执行）。"
                        "当不确定时，默认为 true（优先安全）。"
                    ),
                },
                "reason": {
                    "type": "string",
                    "description": (
                        "决策原因的简短说明（给用户看）。"
                        "例如：'读取系统配置文件' 或 '删除文件'。"
                        "不超过 50 字。"
                    ),
                },
            },
            "required": ["thinking", "should_block", "reason"],
        },
    },
}


# ---------------------------------------------------------------------------
# 类型定义
# ---------------------------------------------------------------------------

ClassifierResult = dict[
    Literal["thinking", "should_block", "reason"], str | bool
]


__all__ = [
    "CLASSIFY_RESULT_TOOL_SCHEMA",
    "ClassifierResult",
]
