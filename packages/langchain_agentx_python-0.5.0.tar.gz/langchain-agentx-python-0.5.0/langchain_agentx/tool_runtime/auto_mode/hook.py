"""
tool_runtime/auto_mode/hook.py — Auto Mode Auth Hook

职责：
    Auto Mode 核心决策入口，实现 PRE_TOOL_USE Hook。
    串联 L1 工具白名单 + L3 Bash 启发式 + L4 LLM 分类器 + L5 兜底。

链路位置：
    PolicyEngine.decide() → AutoModeAuthHook() → HookResult.permission_behavior

当前裁剪范围（Phase 2 + Phase 4 SDK）：
    - 实现 L1 工具白名单 + L3 Bash 启发式 + L4 LLM 分类器
    - L2 acceptEdits fast-path 留空（后续扩展）
    - 事件发射：AutoModeDecisionEvent 通过 event_bus 下发（Phase 4 SDK）

CC 源码对照：
    - src/utils/permissions/permissions.ts:540-700（决策入口）
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any

from .config import AutoModeConfig
from .decision import (
    AutoModeDecision,
    AutoModeReason,
    _allow,
    _ask,
    _passthrough,
)
from .state import get_auto_mode_state
from .events import AutoModeDecisionEvent

if TYPE_CHECKING:
    from .allowlist import SafeToolAllowlist
    from .classifier.classifier import LLMClassifier, ClassifierInput
    from ..models import ToolExecutionContext


def _is_bash_tool(tool_name: str) -> bool:
    """检查是否为 Bash 工具（避免循环依赖）。"""
    return tool_name == "bash"


class AutoModeAuthHook:
    """
    Auto Mode 授权 Hook。

    对应 CC permissions.ts 的 auto mode 分支（540~700 行）。

    决策流程（Phase 2）：
        1. 检查 enabled + permission_mode == "auto"
        2. L1: SafeToolAllowlist 查表 → allow
        3. L3: Bash 工具 + BashReadOnlyClassifier → allow/miss
        4. L4: LLM 分类器 → allow/ask（如果启用）
        5. L5: 兜底 ask

    设计文档：docs/design-docs/tool-design/auto-mode-bash-classifier.html §5.8
    """

    def __init__(
        self,
        config: AutoModeConfig,
        allowlist: "SafeToolAllowlist",
        bash_classifier: Any | None = None,
        llm_classifier: "LLMClassifier | None" = None,
        chat_model_factory: Any | None = None,
        tool_registry: Any | None = None,
        event_bus: Any | None = None,
    ):
        """初始化 Auto Mode Auth Hook。

        Args:
            config: AutoModeConfig 配置
            allowlist: L1 工具白名单
            bash_classifier: L3 Bash 只读分类器（BashReadOnlyClassifier 实例）
            llm_classifier: L4 LLM 分类器（Phase 2）
            chat_model_factory: Chat 模型工厂函数（用于 LLM 分类器）
            tool_registry: 工具注册表（用于获取 tool 实例）
            event_bus: 事件总线（用于发射决策事件）
        """
        self._config = config
        self._allowlist = allowlist
        self._bash_classifier = bash_classifier
        self._llm_classifier = llm_classifier
        self._chat_model_factory = chat_model_factory
        self._tool_registry = tool_registry
        self._event_bus = event_bus

    def update_config(self, config: AutoModeConfig) -> None:
        """热更新 Auto Mode 配置（下一笔 decide 立即生效）。"""
        self._config = config

    def _emit_event(
        self,
        decision: AutoModeDecision,
        tool_name: str,
        tool_input: dict[str, Any],
        ctx: "ToolExecutionContext",
    ) -> None:
        """安全地发射决策事件到 event_bus。

        Args:
            decision: Auto Mode 决策结果
            tool_name: 工具名称
            tool_input: 工具输入
            ctx: 工具执行上下文
        """
        if self._event_bus is None:
            return

        try:
            event = AutoModeDecisionEvent.from_decision(
                decision=decision,
                tool_name=tool_name,
                tool_input_preview=self._build_input_preview(tool_name, tool_input),
                session_id=self._get_session_id(ctx),
                tool_use_id=self._get_tool_use_id(ctx),
            )
            self._event_bus.emit(event)
        except Exception:
            # 事件发射失败不应影响主流程
            import logging
            logger = logging.getLogger(__name__)
            logger.debug("Failed to emit AutoModeDecisionEvent", exc_info=True)

    def _build_input_preview(self, tool_name: str, tool_input: dict[str, Any]) -> str:
        """构建工具输入预览（脱敏）。

        Args:
            tool_name: 工具名称
            tool_input: 工具输入

        Returns:
            脱敏后的输入预览字符串
        """
        import json

        preview = json.dumps(tool_input, ensure_ascii=False, default=str)
        # 限制长度，避免事件过大
        if len(preview) > 500:
            preview = preview[:500] + "..."
        return preview

    def _get_session_id(self, ctx: "ToolExecutionContext") -> str | None:
        """获取会话 ID。

        Args:
            ctx: 工具执行上下文

        Returns:
            会话 ID 或 None
        """
        if hasattr(ctx, "session_id"):
            return ctx.session_id
        # 尝试从 state 中获取
        if hasattr(ctx, "state") and isinstance(ctx.state, dict):
            return ctx.state.get("session_id")
        return None

    def _get_tool_use_id(self, ctx: "ToolExecutionContext") -> str | None:
        """获取工具调用 ID。

        Args:
            ctx: 工具执行上下文

        Returns:
            工具调用 ID 或 None
        """
        # 优先用归一化字段（ToolExecutionContext.tool_call_id）
        if hasattr(ctx, "tool_call_id") and ctx.tool_call_id:
            return ctx.tool_call_id

        # 兜底：configurable 里的 tool_use_id/tool_call_id（保留向后兼容）
        if ctx.runnable_config is not None:
            configurable = getattr(ctx.runnable_config, "configurable", {})
            if isinstance(configurable, dict):
                return configurable.get("tool_use_id") or configurable.get("tool_call_id")
        return None

    @property
    def enabled(self) -> bool:
        """检查 Auto Mode 是否启用。"""
        return self._config.enabled and get_auto_mode_state().enabled

    async def decide(
        self,
        tool_name: str,
        tool_input: dict[str, Any],
        ctx: "ToolExecutionContext",
    ) -> AutoModeDecision:
        """
        执行 Auto Mode 决策。

        Args:
            tool_name: 工具名称
            tool_input: 工具入参
            ctx: 工具执行上下文

        Returns:
            AutoModeDecision 决策结果
        """
        start_time = time.perf_counter()

        # 检查是否启用 auto mode
        permission_mode = self._get_permission_mode(ctx)
        if not self.enabled or permission_mode != "auto":
            decision = _passthrough(elapsed_ms=_ms_since(start_time))
            self._emit_event(decision, tool_name, tool_input, ctx)
            return decision

        # L1: 工具白名单
        if self._allowlist.contains(tool_name):
            decision = _allow(
                layer="L1",
                reason=AutoModeReason.ALLOWLIST,
                matched_pattern=tool_name,
                elapsed_ms=_ms_since(start_time),
            )
            self._emit_event(decision, tool_name, tool_input, ctx)
            return decision

        # L3: Bash 启发式
        if tool_name == "bash":
            bash_decision = await self._decide_bash(tool_input, start_time)
            # L3 allow 则直接返回，miss 则继续到 L4
            if bash_decision.behavior == "allow":
                self._emit_event(bash_decision, tool_name, tool_input, ctx)
                return bash_decision
            # L3 miss（behavor == "ask"），继续到 L4

        # L4: LLM 分类器
        if self._llm_classifier is not None and self._config.use_classifier:
            llm_decision = await self._decide_llm(tool_name, tool_input, ctx, start_time)
            # L4 给出明确判断，直接返回
            if llm_decision.behavior in ("allow", "deny"):
                self._emit_event(llm_decision, tool_name, tool_input, ctx)
                return llm_decision
            # L4 不可用（behavior == "ask"），继续到 L5

        # L5: 兜底 ask
        decision = _ask(
            layer="L5",
            reason=AutoModeReason.NOT_IN_FAST_PATH,
            explanation="Operation not in fast-path, requires user approval",
            elapsed_ms=_ms_since(start_time),
        )
        self._emit_event(decision, tool_name, tool_input, ctx)
        return decision

    async def _decide_bash(
        self,
        tool_input: dict[str, Any],
        start_time: float,
    ) -> AutoModeDecision:
        """L3: Bash 启发式决策。"""
        command = tool_input.get("command")
        if not isinstance(command, str):
            command = ""
        command = command.strip()

        if not command:
            # 空命令，直接 allow
            return _allow(
                layer="L3",
                reason=AutoModeReason.READONLY_HEURISTIC,
                explanation="Empty Bash command",
                elapsed_ms=_ms_since(start_time),
            )

        if self._bash_classifier is None:
            # 无分类器，降级到 L4
            return _ask(
                layer="L3",
                reason=AutoModeReason.NOT_IN_FAST_PATH,
                explanation="Bash classifier not available",
                elapsed_ms=_ms_since(start_time),
            )

        # 调用 BashReadOnlyClassifier
        result = self._bash_classifier.classify(command)
        if result.is_read_only:
            return _allow(
                layer="L3",
                reason=AutoModeReason.READONLY_HEURISTIC,
                explanation=result.reason or "Bash read-only command",
                matched_pattern=command[:100],  # 预览前 100 字符
                elapsed_ms=_ms_since(start_time),
            )

        # miss → 返回 ask（会继续到 L4）
        return _ask(
            layer="L3",
            reason=AutoModeReason.NOT_IN_FAST_PATH,
            explanation=result.reason or "Bash command not in read-only allowlist",
            elapsed_ms=_ms_since(start_time),
        )

    async def _decide_llm(
        self,
        tool_name: str,
        tool_input: dict[str, Any],
        ctx: "ToolExecutionContext",
        start_time: float,
    ) -> AutoModeDecision:
        """L4: LLM 分类器决策。"""
        from .classifier.classifier import ClassifierInput, ClassifierError

        # 构建 action_text
        action_text = self._build_action_text(tool_name, tool_input)

        # 构建 ClassifierInput
        classifier_input = ClassifierInput(
            tool_name=tool_name,
            tool_input=tool_input,
            action_text=action_text,
            messages=self._get_messages(ctx),
            chat_model=self._get_chat_model(ctx),
        )

        try:
            output = await self._llm_classifier.classify(classifier_input)
            return output.decision
        except ClassifierError as e:
            # 分类器错误，降级到 L5
            return _ask(
                layer="L4",
                reason=AutoModeReason.CLASSIFIER_UNAVAILABLE,
                explanation=f"Classifier error: {e}",
                elapsed_ms=_ms_since(start_time),
            )

    def _build_action_text(self, tool_name: str, tool_input: dict[str, Any]) -> str:
        """构建操作描述文本。"""
        # 尝试使用工具的 to_auto_classifier_input
        if self._tool_registry:
            tool = self._tool_registry.get_tool(tool_name)
            if tool and hasattr(tool, "to_auto_classifier_input"):
                classifier_input = tool.to_auto_classifier_input(tool_input)
                if classifier_input:
                    return f"{tool_name}: {classifier_input}"

        # 默认格式
        import json
        input_preview = json.dumps(tool_input, ensure_ascii=False)[:200]
        return f"{tool_name} {input_preview}"

    def _get_messages(self, ctx: "ToolExecutionContext") -> list[Any]:
        """获取对话历史消息。"""
        # 从 state 中获取 messages
        if hasattr(ctx, "state") and isinstance(ctx.state, dict):
            messages = ctx.state.get("messages", [])
            if isinstance(messages, list):
                return messages
        return []

    def _get_chat_model(self, ctx: "ToolExecutionContext") -> Any | None:
        """获取 Chat 模型（四级优先级）。"""
        # 优先级 1：显式配置的 classifier_model
        if self._config.classifier_model is not None:
            return self._config.classifier_model

        # 优先级 2：工厂函数
        if self._chat_model_factory is not None:
            return self._chat_model_factory()

        # 优先级 3：从 ctx.model 获取（兜底）
        if hasattr(ctx, "model") and ctx.model is not None:
            # 记录 WARNING：使用主对话模型进行分类
            import logging
            logger = logging.getLogger(__name__)
            logger.warning(
                "Using main chat model for auto-mode classification. "
                "Consider configuring a separate classifier model for better isolation."
            )
            return ctx.model

        return None

    def _get_permission_mode(self, ctx: "ToolExecutionContext") -> str:
        """获取当前权限模式。

        读取顺序：loop_config.permission_mode → configurable.permission_mode → "default"
        """
        # 从 runnable_config 获取 permission_mode
        if ctx.runnable_config is not None:
            configurable = getattr(ctx.runnable_config, "configurable", {})
            if isinstance(configurable, dict):
                # 优先从 loop_config 读取
                loop_config = configurable.get("loop_config")
                if loop_config is not None:
                    mode = getattr(loop_config, "permission_mode", None)
                    if isinstance(mode, str):
                        return mode
                # 兜底：直接从 configurable 读取（兼容旧版配置）
                return configurable.get("permission_mode", "default")
        return "default"


def _ms_since(start_time: float) -> float:
    """计算耗时（毫秒）。"""
    return (time.perf_counter() - start_time) * 1000


