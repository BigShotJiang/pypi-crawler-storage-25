"""
tool_runtime/auto_mode/decision.py — Auto Mode 决策结果

职责：
    定义 Auto Mode 决策的数据结构，包含决策行为、原因、层级、置信度等。

链路位置：
    AutoModeAuthHook._decide() → AutoModeDecision → HookResult.permission_behavior

当前裁剪范围：
    - confidence 字段暂不用于实际决策逻辑，仅用于前端展示
    - matched_pattern 仅在启发式层（L1/L3）填充，LLM 层（L4）为 None
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from time import time
from typing import Literal


class AutoModeReason(str, Enum):
    """Auto Mode 决策原因枚举。

    对应设计文档 §5.2
    """

    ALLOWLIST = "allowlist"
    READONLY_HEURISTIC = "readonly_heuristic"
    LLM_ALLOW = "llm_classifier_allow"
    LLM_DENY = "llm_classifier_deny"
    CLASSIFIER_UNAVAILABLE = "classifier_unavailable"
    NOT_IN_FAST_PATH = "not_in_fast_path"
    DISABLED = "auto_mode_disabled"


@dataclass(frozen=True)
class AutoModeDecision:
    """Auto Mode 决策结果。

    对应设计文档 §5.2

    Attributes:
        behavior: 决策行为（allow/ask/deny/passthrough）
        reason: 决策原因（AutoModeReason 枚举）
        layer: 决策层级（L1 工具白名单 / L2 acceptEdits / L3 Bash 启发式 / L4 LLM / L5 兜底）
        confidence: 决策置信度（high/medium/low），仅用于前端展示
        explanation: 给前端展示的简短理由
        classifier_thinking: LLM 决策时的思考链（仅 L4 有值）
        elapsed_ms: 决策耗时（毫秒）
        matched_pattern: 命中的具体规则（启发式层）
        timestamp_ms: 决策时间戳（毫秒，Unix 时间）
    """

    behavior: Literal["allow", "ask", "deny", "passthrough"]
    reason: AutoModeReason
    layer: Literal["L1", "L2", "L3", "L4", "L5"]
    confidence: Literal["high", "medium", "low"]
    explanation: str
    classifier_thinking: str | None = None
    elapsed_ms: float = 0.0
    matched_pattern: str | None = None
    timestamp_ms: int = field(default_factory=lambda: int(time() * 1000))

    def to_authorization_decision(self) -> "AuthorizationDecision":
        """转换为 AuthorizationDecision（用于 PolicyEngine 集成）。"""
        from ..models import AuthorizationDecision
        from ..permission_decision import (
            POLICY_ID_PREFIX_AUTO_MODE,
            PermissionDecisionType,
            attach_decision_reason,
            make_decision_reason,
        )

        metadata = {
            "auto_mode_layer": self.layer,
            "auto_mode_reason": self.reason.value,
            "auto_mode_confidence": self.confidence,
            "auto_mode_elapsed_ms": self.elapsed_ms,
        }
        if self.classifier_thinking:
            metadata["auto_mode_thinking"] = self.classifier_thinking
        if self.matched_pattern:
            metadata["auto_mode_pattern"] = self.matched_pattern

        reason_type = (
            PermissionDecisionType.CLASSIFIER
            if self.layer == "L4"
            else PermissionDecisionType.AUTO_MODE
        )
        decision = AuthorizationDecision(
            behavior=self.behavior,
            message=self.explanation,
            policy_id=f"{POLICY_ID_PREFIX_AUTO_MODE}{self.layer}:{self.reason.value}",
            metadata=metadata,
        )
        return attach_decision_reason(
            decision,
            make_decision_reason(
                reason_type,
                layer=self.layer,
                reason=self.reason.value,
                behavior=self.behavior,
            ),
        )


@dataclass(frozen=True)
class _AllowDecision(AutoModeDecision):
    """快捷创建 allow 决策。"""

    behavior: Literal["allow", "ask", "deny", "passthrough"] = "allow"
    confidence: Literal["high", "medium", "low"] = "high"
    # 为继承字段提供默认值以修复 dataclass 字段顺序错误
    reason: AutoModeReason = AutoModeReason.ALLOWLIST
    layer: Literal["L1", "L2", "L3", "L4", "L5"] = "L1"
    explanation: str = ""
    classifier_thinking: str | None = None
    elapsed_ms: float = 0.0
    matched_pattern: str | None = None


@dataclass(frozen=True)
class _AskDecision(AutoModeDecision):
    """快捷创建 ask 决策。"""

    behavior: Literal["allow", "ask", "deny", "passthrough"] = "ask"
    confidence: Literal["high", "medium", "low"] = "low"
    # 为继承字段提供默认值以修复 dataclass 字段顺序错误
    reason: AutoModeReason = AutoModeReason.NOT_IN_FAST_PATH
    layer: Literal["L1", "L2", "L3", "L4", "L5"] = "L5"
    explanation: str = ""
    classifier_thinking: str | None = None
    elapsed_ms: float = 0.0
    matched_pattern: str | None = None


@dataclass(frozen=True)
class _DenyDecision(AutoModeDecision):
    """快捷创建 deny 决策。"""

    behavior: Literal["allow", "ask", "deny", "passthrough"] = "deny"
    confidence: Literal["high", "medium", "low"] = "high"
    # 为继承字段提供默认值以修复 dataclass 字段顺序错误
    reason: AutoModeReason = AutoModeReason.LLM_DENY
    layer: Literal["L1", "L2", "L3", "L4", "L5"] = "L4"
    explanation: str = ""
    classifier_thinking: str | None = None
    elapsed_ms: float = 0.0
    matched_pattern: str | None = None


@dataclass(frozen=True)
class _PassthroughDecision(AutoModeDecision):
    """快捷创建 passthrough 决策（未启用 auto mode）。"""

    behavior: Literal["allow", "ask", "deny", "passthrough"] = "passthrough"
    confidence: Literal["high", "medium", "low"] = "high"
    # 为继承字段提供默认值以修复 dataclass 字段顺序错误
    reason: AutoModeReason = AutoModeReason.DISABLED
    layer: Literal["L1", "L2", "L3", "L4", "L5"] = "L5"
    explanation: str = ""
    classifier_thinking: str | None = None
    elapsed_ms: float = 0.0
    matched_pattern: str | None = None


def _allow(
    layer: Literal["L1", "L2", "L3", "L4", "L5"],
    reason: AutoModeReason,
    explanation: str | None = None,
    matched_pattern: str | None = None,
    classifier_thinking: str | None = None,
    elapsed_ms: float = 0.0,
) -> AutoModeDecision:
    """快捷创建 allow 决策。"""
    if explanation is None:
        explanation = f"Allowed by {layer} ({reason.value})"
    return _AllowDecision(
        reason=reason,
        layer=layer,
        explanation=explanation,
        matched_pattern=matched_pattern,
        classifier_thinking=classifier_thinking,
        elapsed_ms=elapsed_ms,
    )


def _ask(
    layer: Literal["L1", "L2", "L3", "L4", "L5"],
    reason: AutoModeReason,
    explanation: str | None = None,
    classifier_thinking: str | None = None,
    elapsed_ms: float = 0.0,
) -> AutoModeDecision:
    """快捷创建 ask 决策。"""
    if explanation is None:
        explanation = f"Requires approval by {layer} ({reason.value})"
    return _AskDecision(
        reason=reason,
        layer=layer,
        explanation=explanation,
        classifier_thinking=classifier_thinking,
        elapsed_ms=elapsed_ms,
    )


def _deny(
    layer: Literal["L1", "L2", "L3", "L4", "L5"],
    reason: AutoModeReason,
    explanation: str | None = None,
    classifier_thinking: str | None = None,
    elapsed_ms: float = 0.0,
) -> AutoModeDecision:
    """快捷创建 deny 决策。"""
    if explanation is None:
        explanation = f"Blocked by {layer} ({reason.value})"
    return _DenyDecision(
        reason=reason,
        layer=layer,
        explanation=explanation,
        classifier_thinking=classifier_thinking,
        elapsed_ms=elapsed_ms,
    )


def _passthrough(elapsed_ms: float = 0.0) -> AutoModeDecision:
    """快捷创建 passthrough 决策（未启用 auto mode）。"""
    return _PassthroughDecision(
        reason=AutoModeReason.DISABLED,
        layer="L5",
        explanation="Auto mode is disabled",
        elapsed_ms=elapsed_ms,
    )
