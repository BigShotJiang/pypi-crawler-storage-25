"""
tool_runtime/auto_mode/state.py — Auto Mode 全局状态

职责：
    管理 Auto Mode 的全局开关和累计 denial 计数。
    对应 CC autoModeState.ts。

链路位置：
    AgentLoopConfig / settings.json → AutoModeState → AutoModeAuthHook

当前裁剪范围：
    - 暂不实现"连续 N 次 deny 自动退出 auto"逻辑（Phase 1 仅实现开关）
    - denial_count 仅用于统计，不影响决策

CC 源码对照：
    src/utils/permissions/autoModeState.ts
"""

from __future__ import annotations

from threading import Lock
from typing import ClassVar


class AutoModeState:
    """Auto Mode 全局状态管理。

    对应 CC autoModeState.ts

    Attributes:
        enabled: 全局开关，控制 Auto Mode 是否启用
        denial_count: 累计 denial 计数（LLM 分类器拒绝次数）
    """

    _instance: ClassVar[AutoModeState | None] = None
    _lock: ClassVar[Lock] = Lock()

    def __new__(cls) -> "AutoModeState":
        """单例模式，确保全局唯一状态。"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._enabled = False
                    cls._instance._denial_count = 0
        return cls._instance

    def __init__(self):
        """初始化（单例模式下实际只执行一次）。"""
        pass

    @property
    def enabled(self) -> bool:
        """获取 Auto Mode 是否启用。"""
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        """设置 Auto Mode 开关。"""
        self._enabled = value
        # 切换模式时重置 denial 计数
        if not value:
            self._denial_count = 0

    @property
    def denial_count(self) -> int:
        """获取累计 denial 计数。"""
        return self._denial_count

    def increment_denial(self) -> int:
        """增加 denial 计数，返回新值。

        Returns:
            增加后的 denial 计数
        """
        self._denial_count += 1
        return self._denial_count

    def reset_denial_count(self) -> None:
        """重置 denial 计数。"""
        self._denial_count = 0

    @classmethod
    def get(cls) -> "AutoModeState":
        """获取全局单例实例。"""
        return cls()

    @classmethod
    def reset(cls) -> None:
        """重置全局状态（用于测试）。"""
        with cls._lock:
            cls._instance = None


# 便捷函数
def get_auto_mode_state() -> AutoModeState:
    """获取全局 AutoModeState 单例。"""
    return AutoModeState.get()
