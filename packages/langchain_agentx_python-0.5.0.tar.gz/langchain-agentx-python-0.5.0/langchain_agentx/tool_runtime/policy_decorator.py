"""
policy_decorator.py — PolicyEngine 透明包装基类（L2 扩展官方路径）

职责：
    为需要包装既有 PolicyEngine 的下游（CLI 历史路径、第三方插件）提供
    官方装饰基类：透明转发 authorize / aauthorize，允许子类覆写任一入口。
    不持有 L3 状态，不访问被包装引擎的私有字段。

链路位置：
    tool_runtime L2 · 与 policy.DefaultPolicyEngine 并列，供组合扩展使用。

当前裁剪：
    仅 composition 转发；不含 prompt / HITL（见 tool_runtime/prompt/ Phase 2）。

最小示例::

    from langchain_agentx.tool_runtime.policy import DefaultPolicyEngine, ToolPolicyConfig
    from langchain_agentx.tool_runtime.policy_decorator import PolicyEngineDecorator

    inner = DefaultPolicyEngine(ToolPolicyConfig(read_roots=["/workspace"]))
    engine = PolicyEngineDecorator(inner)

    decision = engine.authorize(tool_name="read", input_data={"file_path": "..."}, ctx=ctx)
    async_decision = await engine.aauthorize(tool_name="read", input_data={"file_path": "..."}, ctx=ctx)
"""

from __future__ import annotations

from typing import Any

from .models import AuthorizationDecision, ToolExecutionContext
from .policy import PolicyEngine


class PolicyEngineDecorator(PolicyEngine):
    """
    透明转发包装器：委托内层 PolicyEngine 的同步/异步授权入口。

    子类可覆写 ``authorize`` / ``aauthorize`` 做增量逻辑，无需继承
    ``DefaultPolicyEngine`` 或访问 ``_config`` / ``_auto_mode_hook``。
    """

    def __init__(self, inner: PolicyEngine) -> None:
        self._inner = inner

    def authorize(
        self,
        *,
        tool_name: str,
        input_data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        return self._inner.authorize(
            tool_name=tool_name,
            input_data=input_data,
            ctx=ctx,
        )

    async def aauthorize(
        self,
        *,
        tool_name: str,
        input_data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        return await self._inner.aauthorize(
            tool_name=tool_name,
            input_data=input_data,
            ctx=ctx,
        )
