"""
Microcompact 阶段：对 `ToolMessage` 做轻量规范化（对齐 CC microcompact「块级收紧」的低成本子集）。

与 Claude Code 对齐：
- 对应 `query.ts` 传入 `deps.microcompact` 的意图：在 snip 之后进一步去掉 tool 输出中的冗余空白，降低无效 token；
- `ctx.query_source in microcompact_skip_query_sources` 时跳过，避免递归压缩路径（如 `compact`）死循环。

设计要点：
- 不调用 LLM；仅 `ToolMessage` 参与，避免改写 `AIMessage` 中 JSON tool_calls 结构；
- 使用 `model_copy` 保持 LangChain 消息字段完整。

注意：
- 不依赖 LangGraph；不修改 `should_end` / `finish_reason`。
"""

from __future__ import annotations

import re
from typing import Any

from langchain_core.messages import ToolMessage

from ..message_utils import estimate_tokens_from_chars, stringify_content
from ..settings import CompactionSettings, get_active_compaction_settings
from ..types import ContextCompactionContext, StageResult
from .base import CompactionStage


_BLANK_RUN = re.compile(r"\n{3,}")


def _normalize_tool_text(text: str) -> str:
    lines = [ln.rstrip() for ln in text.splitlines()]
    joined = "\n".join(lines)
    return _BLANK_RUN.sub("\n\n", joined)


class MicrocompactStage(CompactionStage):
    """CC 阶段 ③：microcompact（轻量规范化）。"""

    def __init__(self, settings: CompactionSettings | None = None) -> None:
        self._settings_override = settings

    def _effective_settings(self) -> CompactionSettings:
        return self._settings_override or get_active_compaction_settings()

    @property
    def name(self) -> str:
        return "microcompact"

    def run(self, messages: list[Any], ctx: ContextCompactionContext) -> StageResult:
        s = self._effective_settings()
        if ctx.query_source in s.microcompact_skip_query_sources:
            return StageResult(messages=messages, tokens_freed=0)
        changed = False
        out: list[Any] = []
        freed_chars = 0
        compacted_tool_ids: list[str] = []
        for m in messages:
            if not isinstance(m, ToolMessage):
                out.append(m)
                continue
            text = stringify_content(m.content)
            new_text = _normalize_tool_text(text)
            if new_text == text:
                out.append(m)
                continue
            freed_chars += len(text) - len(new_text)
            out.append(m.model_copy(update={"content": new_text}))
            # 记录被修改的工具消息 ID（使用 tool_call_id）
            tool_call_id = getattr(m, "tool_call_id", None)
            if tool_call_id:
                compacted_tool_ids.append(tool_call_id)
            changed = True
        if not changed:
            return StageResult(messages=messages, tokens_freed=0)
        return StageResult(
            messages=out,
            tokens_freed=estimate_tokens_from_chars(freed_chars, s.num_chars_per_token),
            extra={
                "microcompact_normalized": True,
                "compacted_tool_ids": compacted_tool_ids,
            },
        )
