"""
loop/subagent/runner.py — 子 Agent 同步执行路径

职责：run_subagent()，plain/fork 模式同步阻塞执行，astream_events 流式处理
在整体链路中的位置：AgentRuntimeTool.invoke() → run_subagent() → SubagentResult
CC 对照：runAgent.ts runAgent()；onProgress 回调逻辑
当前裁剪范围：v1 plain/fork 同步路径；coordinate 异步路径见 async_runner.py

执行流程（run_subagent）：
  1. 校验：is_async=True 时抛 RuntimeError，model=None 时抛 ValueError
  2. 构造 SubagentTranscriptManager（InMemoryTranscriptStore）
  3. create_subagent_graph(ctx, tools, model) 创建子图
  4. 将 ctx.initial_messages 转为 LangChain HumanMessage 列表作为图输入
  5. astream_events 循环（单线收集，CC agentMessages 累积模式）：
       on_tool_start      → on_progress(tool_use)
       on_tool_end        → on_progress(tool_result) + transcript.append()
       on_chat_model_end  → 累积 assistant 消息 + total_steps 计数 + on_progress(model_step)
       on_chain_end(LangGraph) → 仅提取 terminal_reason（不再取 messages）
  6. 从累积的 assistant 消息中提取最终内容（CC finalizeAgentTool 语义）
  7. on_progress(completed)，返回 SubagentResult
  try/finally：确保 transcript.cleanup() + cleanup_subagent_context() 必然执行
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import threading
from concurrent.futures import Future
from dataclasses import dataclass
from typing import Any, Callable

from langchain_core.messages import AIMessage, HumanMessage

from langchain_agentx.loop.subagent.context import (
    SubagentContext,
    SubagentResult,
    cleanup_subagent_context,
)
from langchain_agentx.loop.subagent.graph import create_subagent_graph
from langchain_agentx.loop.subagent.progress import (
    SubagentExecutionTrace,
    SubagentProgressEvent,
)
from langchain_agentx.loop.subagent.transcript import (
    InMemoryTranscriptStore,
    SubagentTranscriptManager,
)

logger = logging.getLogger(__name__)


def _run_coroutine_sync(coro: Any) -> Any:
    """在同步上下文运行协程；若当前已有事件循环则转到子线程执行。"""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    fut: Future[Any] = Future()

    def _runner() -> None:
        try:
            fut.set_result(asyncio.run(coro))
        except Exception as exc:
            fut.set_exception(exc)

    thread = threading.Thread(target=_runner, daemon=True)
    thread.start()
    thread.join()
    return fut.result()


@dataclass
class BackgroundLaunchedResult:
    """异步路径立即返回的凭证（coordinate 模式）。"""
    status: str  # always "async_launched"
    agent_id: str
    task_id: str


@dataclass
class _EventCollectionResult:
    """子图事件收集结果。"""
    collected_assistant_messages: list[Any]
    terminal_reason: str
    total_steps: int
    error_message: str
    last_tool_name: str
    child_run_id: str | None
    tool_step: int


def _to_message_dict(msg: Any) -> dict[str, Any]:
    """将 LangChain message 对象转为 dict，已是 dict 则直接返回。"""
    if isinstance(msg, dict):
        return msg
    role = getattr(msg, "type", None) or getattr(msg, "role", "unknown")
    # LangChain message type → role 映射
    role_map = {"human": "user", "ai": "assistant", "system": "system", "tool": "tool"}
    role = role_map.get(role, role)
    content = getattr(msg, "content", "")
    return {"role": role, "content": content}


def _extract_final_content(messages: list[Any], allowed_tool_names: set[str] | None = None) -> str:
    """从累积的 assistant 消息中提取最终文本内容。

    策略（对齐 CC finalizeAgentTool）：
    1. 从后往前找第一条有文本且不是纯工具调度消息的 AIMessage。
    2. 若所有 AIMessage 都是纯工具调度（有 tool_calls 无文本），返回空串，
       由调用方附诊断信息。

    "纯工具调度消息"定义：tool_calls 非空，或内容含退化格式工具调用文本。
    on_chat_model_end 在 ToolCallDegradationCorrector 处理前触发，因此
    collected_assistant_messages 里的退化消息尚未被纠偏，需在此处识别并跳过。
    """
    def _text_from_msg(msg: Any) -> str:
        if isinstance(msg, dict):
            if msg.get("role") in ("assistant", "ai"):
                return str(msg.get("content", ""))
        else:
            if isinstance(msg, AIMessage):  # AIMessageChunk is a subclass
                content = getattr(msg, "content", "")
                if isinstance(content, str):
                    return content
                if isinstance(content, list):
                    parts = [
                        item.get("text", "")
                        for item in content
                        if isinstance(item, dict) and item.get("type") == "text"
                    ]
                    return "".join(parts)
        return ""

    def _has_tool_calls(msg: Any) -> bool:
        # on_chat_model_end fires before ToolCallDegradationCorrector processes the message,
        # so raw degraded messages have no tool_calls but contain degradation text patterns.
        # Treat those as tool dispatch messages too, so they are skipped when extracting
        # the final summary content.
        if isinstance(msg, dict):
            if bool(msg.get("tool_calls")):
                return True
            content = str(msg.get("content", ""))
        else:
            if bool(getattr(msg, "tool_calls", None)):
                return True
            content = getattr(msg, "content", "")
            if not isinstance(content, str):
                return False
        # JSON-tag / prefix degradation formats
        if "<tool_call>" in content or "CALL_TOOL:" in content or "TOOL_CALL:" in content:
            return True
        # XML child-element / self-closing formats: <ToolName>...</ToolName> or <ToolName ... />
        # Only match tags whose names are in the known tool whitelist to avoid false positives
        # on <env>, <tool_code>, or arbitrary HTML in model output.
        if allowed_tool_names:
            for name in allowed_tool_names:
                if f"<{name}>" in content or f"<{name} " in content or f"<{name}/>" in content:
                    return True
        return False

    for msg in reversed(messages):
        text = _text_from_msg(msg)
        if text and not _has_tool_calls(msg):
            # 有文本且不是工具调度消息 — 这是真正的最终回复
            return text

    # 所有消息都是纯工具调度（或无文本），返回空串
    return ""


def _resolve_subagent_model(ctx: SubagentContext, model: Any | None) -> Any:
    if ctx.is_async:
        raise RuntimeError(
            "异步路径请调用 run_async_agent_lifecycle()，不要通过 run_subagent() 执行"
        )
    resolved_model = model if model is not None else ctx.model
    if resolved_model is None:
        raise ValueError("model is required for run_subagent")
    return resolved_model


def _build_graph_input_messages(initial_messages: list[Any]) -> list[Any]:
    return [
        HumanMessage(content=m["content"])
        if isinstance(m, dict) and m.get("role") == "user"
        else m
        for m in initial_messages
    ]


async def _emit_progress(
    ctx: SubagentContext,
    event: SubagentProgressEvent,
) -> None:
    """发射子 Agent 进度事件到父 graph。

    通过 adispatch_custom_event 将子 agent 事件冒泡到父 graph 的 astream_events 流。
    父 graph 的 config 通过 ctx.runnable_config 传递（在 _collect_subagent_events 中合并）。
    """
    from langchain_core.callbacks import adispatch_custom_event

    parent_config = getattr(ctx, "runnable_config", None)
    if parent_config is None:
        return

    try:
        await adispatch_custom_event(
            name="tool_progress",
            data={
                "tool_name": event.tool_name or "Agent",
                "tool_call_id": ctx.parent_tool_call_id,
                "agent_id": event.agent_id,
                "phase": event.type,
                "data": {
                    "subagent_type": event.subagent_type,
                    "summary": event.summary,
                    "step": event.step,
                    "parent_tool_use_id": event.parent_tool_use_id,
                },
            },
            config=parent_config,
        )
    except Exception:
        logger.debug("adispatch_custom_event failed in subagent progress", exc_info=True)


async def _handle_tool_start_event(
    *,
    ctx: SubagentContext,
    event: dict[str, Any],
    current_step: int,
    trace: SubagentExecutionTrace | None = None,
) -> tuple[int, str]:
    next_step = current_step + 1
    tool_name = event.get("name", "")
    tool_input = event.get("input", {})

    # 构建工具调用详情
    from langchain_agentx.loop.subagent.progress import SubagentToolCall

    tool_call = SubagentToolCall(
        step=next_step,
        tool_name=tool_name,
        tool_input=tool_input if isinstance(tool_input, dict) else None,
        summary=f"calling {tool_name}",
        status="running",
    )

    # 记录到执行轨迹
    if trace:
        trace.add_tool_call(tool_call)

    await _emit_progress(
        ctx,
        SubagentProgressEvent(
            type="tool_use",
            subagent_type=ctx.subagent_type,
            agent_id=ctx.agent_id,
            step=next_step,
            tool_name=tool_name,
            summary=f"calling {tool_name}",
            tool_call_detail=tool_call,
            trace=trace,
        ),
    )
    return next_step, tool_name


def _tool_end_summary_and_payload(data: dict[str, Any]) -> tuple[str, Any]:
    """从 LangGraph ``on_tool_end`` data 取 summary/payload（仅 RuntimeTool artifact，无 output 降级）。"""
    if "summary" in data:
        return str(data.get("summary") or ""), data.get("payload")
    output = data.get("output")
    if output is None:
        return "", None
    from langchain_agentx.observability.events.langchain_agentx_event_adapter import (
        LangGraphToLangchainAgentEventAdapter,
    )

    artifact = LangGraphToLangchainAgentEventAdapter._extract_artifact(output)
    if artifact is not None:
        return str(artifact.get("summary") or ""), artifact.get("payload")
    return "", None


def _is_tool_error(output: Any) -> bool:
    """判断工具输出是否是错误。

    参考 LangGraphToLangchainAgentEventAdapter._is_tool_error()。
    """
    if output is None:
        return False
    if isinstance(output, Exception):
        return True
    if isinstance(output, dict):
        return bool(output.get("error") is not None or output.get("status") == "error")
    return False


async def _handle_tool_end_event(
    *,
    ctx: SubagentContext,
    event: dict[str, Any],
    data: dict[str, Any],
    transcript: SubagentTranscriptManager,
    step: int,
    trace: SubagentExecutionTrace | None = None,
) -> None:
    tool_name = event.get("name", "")
    summary, payload = _tool_end_summary_and_payload(data)

    # 判断是否有错误
    is_error = _is_tool_error(data.get("output"))
    status: Literal["completed", "error"] = "error" if is_error else "completed"

    # 更新执行轨迹中的最后一个工具调用状态
    if trace:
        trace.update_last_status(
            status=status,
            summary=summary[:200] if summary else "",
            payload=str(payload)[:500] if payload is not None else None,
            error_message=str(data.get("output"))[:200] if is_error else None,
        )

    # 构建 transcript 内容：summary + payload（截断）
    transcript_text = summary if summary else ""
    if payload:
        payload_str = str(payload)[:300]
        transcript_text = f"{summary}\n{payload_str}" if summary else payload_str

    msg_dict = {"role": "tool", "tool_name": tool_name, "content": transcript_text}
    transcript.append(msg_dict)
    await _emit_progress(
        ctx,
        SubagentProgressEvent(
            type="tool_result",
            subagent_type=ctx.subagent_type,
            agent_id=ctx.agent_id,
            step=step,
            tool_name=tool_name,
            summary=summary[:200] if summary else "",
        ),
    )


async def _handle_chat_model_end_event(
    *,
    ctx: SubagentContext,
    data: dict[str, Any],
    collected_assistant_messages: list[Any],
    total_steps: int,
) -> int:
    output = data.get("output")
    if output is not None:
        collected_assistant_messages.append(output)
    has_tool_calls = bool(output is not None and getattr(output, "tool_calls", None))
    if not has_tool_calls:
        total_steps += 1
        await _emit_progress(
            ctx,
            SubagentProgressEvent(
                type="model_step",
                subagent_type=ctx.subagent_type,
                agent_id=ctx.agent_id,
                step=total_steps,
                summary="model responded",
            ),
        )
    return total_steps


def _handle_langgraph_end_event(
    *,
    data: dict[str, Any],
    terminal_reason: str,
    child_run_id: str | None,
) -> tuple[str, str | None]:
    output = data.get("output") or {}
    if not isinstance(output, dict):
        return terminal_reason, child_run_id
    tr = output.get("terminal_reason")
    if tr:
        terminal_reason = str(tr)
    if child_run_id is None:
        child_run_id = output.get("_run_id")
    return terminal_reason, child_run_id


async def _collect_subagent_events(
    *,
    ctx: SubagentContext,
    graph: Any,
    graph_input: dict[str, Any],
    run_tags: list[str],
    transcript: SubagentTranscriptManager,
    trace: SubagentExecutionTrace,
) -> _EventCollectionResult:
    collected_assistant_messages: list[Any] = []
    terminal_reason = "completed"
    total_steps = 0
    error_message = ""
    last_tool_name = ""
    child_run_id: str | None = None
    tool_step = 0

    # 构建子 graph config：合并父 runnable_config 使事件自动冒泡
    config = {"tags": run_tags, "recursion_limit": 9999}
    parent_runnable_config = getattr(ctx, "runnable_config", None)
    if parent_runnable_config is not None:
        if isinstance(parent_runnable_config, dict):
            # 合并父 config 的 configurable 字段，使子 graph 事件冒泡到父 graph
            configurable = parent_runnable_config.get("configurable", {})
            if configurable:
                config["configurable"] = configurable

    try:
        async for event in graph.astream_events(
            graph_input,
            config=config,
            version="v2",
        ):
            event_name = event.get("event", "")
            data = event.get("data") or {}
            if event_name == "on_tool_start":
                tool_step, last_tool_name = await _handle_tool_start_event(
                    ctx=ctx,
                    event=event,
                    current_step=tool_step,
                    trace=trace,
                )
            elif event_name == "on_tool_end":
                await _handle_tool_end_event(
                    ctx=ctx,
                    event=event,
                    data=data,
                    transcript=transcript,
                    step=tool_step,
                    trace=trace,
                )
            elif event_name == "on_chat_model_end":
                total_steps = await _handle_chat_model_end_event(
                    ctx=ctx,
                    data=data,
                    collected_assistant_messages=collected_assistant_messages,
                    total_steps=total_steps,
                )
            elif event_name == "on_chain_end" and event.get("name") == "LangGraph":
                terminal_reason, child_run_id = _handle_langgraph_end_event(
                    data=data,
                    terminal_reason=terminal_reason,
                    child_run_id=child_run_id,
                )
    except Exception as exc:
        logger.warning(
            "subagent astream_events error agent_id=%s: %s",
            ctx.agent_id,
            exc,
            exc_info=True,
        )
        error_message = str(exc)
        terminal_reason = "error"
    return _EventCollectionResult(
        collected_assistant_messages=collected_assistant_messages,
        terminal_reason=terminal_reason,
        total_steps=total_steps,
        error_message=error_message,
        last_tool_name=last_tool_name,
        child_run_id=child_run_id,
        tool_step=tool_step,
    )


async def _build_subagent_result(
    *,
    ctx: SubagentContext,
    collected: _EventCollectionResult,
    transcript: SubagentTranscriptManager,
    allowed_tool_names: set[str] | None,
    trace: SubagentExecutionTrace,
) -> SubagentResult:
    content = _extract_final_content(collected.collected_assistant_messages, allowed_tool_names)
    status = "error" if collected.terminal_reason == "error" else "completed"
    transcript.flush([_to_message_dict(m) for m in collected.collected_assistant_messages])
    if not content and status == "completed":
        diag = f"total_steps={collected.total_steps}"
        if collected.last_tool_name:
            diag += f" last_tool={collected.last_tool_name}"
        diag += f" terminal_reason={collected.terminal_reason}"
        logger.warning(
            "subagent completed with no content agent_id=%s %s",
            ctx.agent_id, diag,
        )
    # 更新 trace 的 terminal_reason
    trace.terminal_reason = collected.terminal_reason
    await _emit_progress(
        ctx,
        SubagentProgressEvent(
            type="completed",
            subagent_type=ctx.subagent_type,
            agent_id=ctx.agent_id,
            step=collected.total_steps,
            summary=content[:200] if content else "done",
            trace=trace,
        ),
    )
    return SubagentResult(
        agent_id=ctx.agent_id,
        content=content,
        status=status,
        terminal_reason=collected.terminal_reason,
        total_steps=collected.total_steps,
        error_message=collected.error_message,
        child_run_id=collected.child_run_id,
        execution_trace=trace,
    )


async def run_subagent(
    ctx: SubagentContext,
    loader: Any,
    model: Any | None = None,
    allowed_tool_names: set[str] | None = None,
) -> SubagentResult:
    """运行子 Agent（plain/fork 同步路径）。

    Args:
        ctx: 子 Agent 执行上下文
        loader: 子会话 ToolRuntimeLoader
        model: 语言模型（str 或 BaseChatModel），None 时继承 ctx.model
        allowed_tool_names: 工具白名单，用于识别 XML 退化格式（如 <Read>...</Read>）

    Returns:
        SubagentResult（包含 execution_trace 执行轨迹）

    Raises:
        RuntimeError: ctx.is_async=True 时（异步路径请调用 run_async_agent_lifecycle）
        ValueError: model 与 ctx.model 均为 None 时

    不变量：无论成功/失败，try/finally 确保 transcript.cleanup() 和
            cleanup_subagent_context() 被调用。
    """
    resolved_model = _resolve_subagent_model(ctx, model)

    store = InMemoryTranscriptStore()
    transcript = SubagentTranscriptManager(
        store=store,
        agent_id=ctx.agent_id,
        parent_agent_id=ctx.parent_agent_id,
    )
    trace = SubagentExecutionTrace()

    try:
        graph = create_subagent_graph(ctx=ctx, loader=loader, model=resolved_model)
        input_messages = _build_graph_input_messages(ctx.initial_messages)
        graph_input = {"messages": input_messages}
        run_tags = [f"subagent:{ctx.subagent_type}", f"agent_id:{ctx.agent_id}"]
        collected = await _collect_subagent_events(
            ctx=ctx,
            graph=graph,
            graph_input=graph_input,
            run_tags=run_tags,
            transcript=transcript,
            trace=trace,
        )
        return await _build_subagent_result(
            ctx=ctx,
            collected=collected,
            transcript=transcript,
            allowed_tool_names=allowed_tool_names,
            trace=trace,
        )

    finally:
        transcript.cleanup()
        cleanup_subagent_context(ctx)


async def run_subagent_with_background_signal(
    ctx: SubagentContext,
    loader: Any,
    model: Any | None = None,
    background_signal: asyncio.Event | None = None,
    on_background_request: Callable[[SubagentContext], str] | None = None,
    allowed_tool_names: set[str] | None = None,
) -> SubagentResult | BackgroundLaunchedResult:
    """同步执行中监听后台化信号（CC Promise.race 语义）。"""
    agent_task = asyncio.create_task(
        run_subagent(ctx=ctx, loader=loader, model=model, allowed_tool_names=allowed_tool_names)
    )
    if background_signal is None:
        return await agent_task

    signal_task = asyncio.create_task(background_signal.wait())
    done, pending = await asyncio.wait(
        {agent_task, signal_task},
        return_when=asyncio.FIRST_COMPLETED,
    )

    if signal_task in done and signal_task.result():
        agent_task.cancel()
        for task in pending:
            task.cancel()
        if on_background_request is None:
            raise RuntimeError("background signal received but no handler configured")
        task_id = on_background_request(ctx)
        return BackgroundLaunchedResult(
            status="async_launched",
            agent_id=ctx.agent_id,
            task_id=task_id,
        )

    signal_task.cancel()
    return await agent_task
