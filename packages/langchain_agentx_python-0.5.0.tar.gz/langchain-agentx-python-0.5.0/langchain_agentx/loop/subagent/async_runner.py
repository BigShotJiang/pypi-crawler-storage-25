"""
loop/subagent/async_runner.py — 子 Agent 异步生命周期管理

职责：
  - register_background_agent()：threading 后台启动子 Agent（旧接口，供 v1 兼容）
  - run_async_agent_lifecycle()：coordinate 模式纯 async 生命周期（计划接口，供 AgentRuntimeTool 调用）
在整体链路中的位置：AgentRuntimeTool.invoke(is_async=True) → run_async_agent_lifecycle()
CC 对照：agentToolUtils.ts runAsyncAgentLifecycle()；LocalAgentTask enqueueAgentNotification()
当前裁剪范围：v1 基础版；完整 worktree 清理 / output_file 管理为 v2

执行流程（run_async_agent_lifecycle）：
  1. 构造 output_file 路径，确保父目录存在
  2. task_runtime.update(task_id, {status: running})
  3. 临时置 ctx.is_async=False，调用 run_subagent() 执行子图
  4. 写 output_file（result.content）
  5. task_runtime.mark_terminal(completed/failed)
  异常分支：
    CancelledError → 写 "cancelled"，mark_terminal(failed, terminal_reason="cancelled")，re-raise
    其他 Exception → 写错误信息，mark_terminal(failed)
"""

from __future__ import annotations

import asyncio
import os
import threading
import uuid
from dataclasses import dataclass
from typing import Any, Callable

from langchain_agentx.task_runtime.core.types import TaskScope, TaskSpec, TaskStatus, TaskType

from .context import SubagentContext
from .runner import run_subagent


@dataclass
class BackgroundAgentHandle:
    task_id: str
    agent_id: str
    output_file: str
    thread: threading.Thread


_BACKGROUND_HANDLES: dict[str, BackgroundAgentHandle] = {}


def _ensure_parent(path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)


def _resolve_task_runtime(ctx: Any) -> Any | None:
    runtime = getattr(ctx, "task_runtime", None)
    if runtime is not None:
        return runtime
    state = getattr(ctx, "state", {})
    if isinstance(state, dict):
        return state.get("task_runtime")
    return None


def _spawn_task_record(task_runtime: Any, ctx: SubagentContext, description: str) -> str:
    if task_runtime is None:
        return str(uuid.uuid4())
    spec = TaskSpec(
        task_type=TaskType.LOCAL_AGENT,
        description=description,
        input={"prompt": description, "agent_label": ctx.subagent_type},
        scope=TaskScope(agent_id=ctx.parent_agent_id),
    )
    return task_runtime.spawn(spec)


def register_background_agent(
    *,
    ctx: SubagentContext,
    loader: Any,
    model: Any | None,
    output_dir: str,
    description: str,
    parent_ctx: Any | None = None,
) -> BackgroundAgentHandle:
    """注册并启动后台子 Agent。"""
    task_runtime = _resolve_task_runtime(parent_ctx)
    task_id = _spawn_task_record(task_runtime, ctx, description)
    output_file = os.path.join(output_dir, task_id, "output.txt")
    _ensure_parent(output_file)

    def _run() -> None:
        async def _lifecycle() -> None:
            try:
                result = await run_subagent(
                    ctx=ctx,
                    loader=loader,
                    model=model,
                )
                with open(output_file, "w", encoding="utf-8") as fp:
                    fp.write(result.content)
                if task_runtime is not None:
                    status = TaskStatus.COMPLETED if result.status == "completed" else TaskStatus.FAILED
                    task_runtime.mark_terminal(
                        task_id,
                        status,
                        result.content[:500] if result.content else (result.error_message or "subagent completed"),
                        output_file=output_file,
                        terminal_reason=result.terminal_reason or None,
                    )
            except Exception as exc:
                with open(output_file, "w", encoding="utf-8") as fp:
                    fp.write(str(exc))
                if task_runtime is not None:
                    task_runtime.mark_terminal(
                        task_id,
                        TaskStatus.FAILED,
                        f"Subagent background lifecycle failed: {exc}",
                        output_file=output_file,
                        terminal_reason="error",
                    )

        asyncio.run(_lifecycle())

    thread = threading.Thread(target=_run, daemon=True, name=f"agentx-subagent-{task_id}")
    thread.start()
    handle = BackgroundAgentHandle(
        task_id=task_id,
        agent_id=ctx.agent_id,
        output_file=output_file,
        thread=thread,
    )
    _BACKGROUND_HANDLES[task_id] = handle
    return handle


def get_background_agent_handle(task_id: str) -> BackgroundAgentHandle | None:
    return _BACKGROUND_HANDLES.get(task_id)


async def run_async_agent_lifecycle(
    task_id: str,
    ctx: SubagentContext,
    loader: Any,
    task_runtime: Any,
    output_dir: str,
) -> None:
    """coordinate 模式异步生命周期：后台执行子 Agent，完成后通过 task_runtime 写通知。

    Args:
        task_id: 已由调用方在 task_runtime 中注册的任务 ID
        ctx: 子 Agent 执行上下文（is_async 应为 True）
        tools: 工具列表
        task_runtime: TaskRuntime 实例，用于写终态通知
        output_dir: 输出文件根目录

    执行流程：
        1. mark_terminal(running)
        2. run_subagent()
        3. 写 output_file
        4. mark_terminal(completed/failed)

    CancelledError 单独捕获，写 cancelled 状态后 re-raise。
    """
    output_file = os.path.join(output_dir, task_id, "output.txt")
    _ensure_parent(output_file)

    if task_runtime is not None:
        try:
            task_runtime.update(task_id, {"status": TaskStatus.RUNNING.value})
        except Exception:
            pass

    try:
        # 子会话 is_async=True 时 run_subagent 会抛 RuntimeError，
        # 此处临时置 False 走真实执行路径（lifecycle 本身已是异步上下文）
        ctx.is_async = False
        result = await run_subagent(ctx=ctx, loader=loader, model=None)

        with open(output_file, "w", encoding="utf-8") as fp:
            fp.write(result.content)

        if task_runtime is not None:
            status = TaskStatus.COMPLETED if result.status == "completed" else TaskStatus.FAILED
            task_runtime.mark_terminal(
                task_id,
                status,
                result.content[:500] if result.content else (result.error_message or "done"),
                output_file=output_file,
                terminal_reason=result.terminal_reason or None,
            )

    except asyncio.CancelledError:
        with open(output_file, "w", encoding="utf-8") as fp:
            fp.write("cancelled")
        if task_runtime is not None:
            try:
                task_runtime.mark_terminal(
                    task_id, TaskStatus.FAILED, "subagent cancelled",
                    output_file=output_file, terminal_reason="cancelled",
                )
            except Exception:
                pass
        raise

    except Exception as exc:
        with open(output_file, "w", encoding="utf-8") as fp:
            fp.write(str(exc))
        if task_runtime is not None:
            task_runtime.mark_terminal(
                task_id,
                TaskStatus.FAILED,
                f"subagent failed: {exc}",
                output_file=output_file,
                terminal_reason="error",
            )
