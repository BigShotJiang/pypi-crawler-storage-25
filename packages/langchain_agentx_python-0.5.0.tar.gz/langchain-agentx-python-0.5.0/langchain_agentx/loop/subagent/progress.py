"""Subagent Progress Event 数据结构

职责：进度事件载荷（Channel B）
在整体链路中的位置：runner.py 构造 → AgentRuntimeTool.invoke() 的 on_progress 回调消费
CC 对照：src/agent/subagent/progress.ts onProgress 回调参数类型
当前裁剪范围：v1 基础事件类型，无 async 路径
"""

from dataclasses import dataclass, field
from typing import Any, Literal


@dataclass
class SubagentToolCall:
    """子 Agent 内部工具调用记录（与 CC 进度消息对齐）。"""
    step: int
    tool_name: str
    tool_input: dict[str, Any] | None = None
    summary: str = ""
    status: Literal["running", "completed", "error"] = "running"
    error_message: str | None = None
    payload: str | None = None
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class SubagentExecutionTrace:
    """子 Agent 执行轨迹（完整工具调用记录）。

    用于 present_for_display 返回，UI 可展示完整的执行步骤。
    对应 CC 的 progressMessages[] 和 AgentTool 的分组展示逻辑。
    """
    tool_calls: list[SubagentToolCall] = field(default_factory=list)
    total_steps: int = 0
    terminal_reason: str | None = None

    def add_tool_call(self, call: SubagentToolCall) -> None:
        """添加工具调用记录。"""
        self.tool_calls.append(call)
        self.total_steps = max(self.total_steps, call.step)

    def update_last_status(
        self,
        status: Literal["completed", "error"],
        summary: str = "",
        payload: str | None = None,
        error_message: str | None = None,
    ) -> None:
        """更新最后一个工具调用状态。"""
        if self.tool_calls:
            last = self.tool_calls[-1]
            last.status = status
            if summary:
                last.summary = summary
            if payload is not None:
                last.payload = payload
            if error_message:
                last.error_message = error_message

    def to_dict_list(self) -> list[dict[str, Any]]:
        """转换为字典列表，用于 JSON 序列化。"""
        return [
            {
                "step": c.step,
                "tool_name": c.tool_name,
                "tool_input": c.tool_input,
                "summary": c.summary,
                "status": c.status,
                "error_message": c.error_message,
                "payload": c.payload,
            }
            for c in self.tool_calls
        ]


@dataclass
class SubagentProgressEvent:
    """子 Agent 进度事件

    type 枚举：
    - tool_use: 工具调用开始
    - tool_result: 工具调用结束
    - model_step: 模型推理完成
    - hint: 后台化提示（v2）
    - completed: 子 Agent 完成

    与 CC 对齐：
    - CC 的 ProgressMessage 包含完整的 message 对象（assistant/user 消息）
    - 本 SDK 通过 tool_call_detail 携带工具调用的详细信息
    - parent_tool_use_id 用于事件冒泡，标识父级工具调用
    """
    type: Literal["tool_use", "tool_result", "model_step", "hint", "completed"]
    subagent_type: str = ""
    agent_id: str = ""
    step: int = 0
    tool_name: str = ""
    summary: str = ""
    meta: dict[str, Any] = field(default_factory=dict)
    # 新增：工具调用详情（用于 present_for_display 展示）
    tool_call_detail: SubagentToolCall | None = None
    # 新增：执行轨迹引用（共享状态）
    trace: SubagentExecutionTrace | None = None
    # 新增：父级 tool_use_id，用于事件冒泡（CC 对齐）
    parent_tool_use_id: str | None = None
