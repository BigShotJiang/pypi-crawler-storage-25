"""Loop Subagent 框架

职责：子 Agent 执行框架的公共接口导出
在整体链路中的位置：被 tools/agent/tool.py 调用
CC 对照：src/agent/subagent/ 目录
当前裁剪范围：v1 同步执行路径，stub runner
"""

from langchain_agentx.loop.subagent.context import (
    SubagentContext,
    SubagentResult,
    cleanup_subagent_context,
    create_subagent_context,
)
from langchain_agentx.loop.subagent.async_runner import (
    BackgroundAgentHandle,
    get_background_agent_handle,
    register_background_agent,
    run_async_agent_lifecycle,
)
from langchain_agentx.loop.subagent.runner import (
    BackgroundLaunchedResult,
    _run_coroutine_sync,
    run_subagent,
    run_subagent_with_background_signal,
)
from langchain_agentx.loop.subagent.transcript import (
    JsonlTranscriptStore,
    SubagentTranscriptManager,
    SubagentTranscriptStore,
)
from langchain_agentx.loop.subagent.graph import create_subagent_graph

__all__ = [
    "SubagentContext",
    "SubagentResult",
    "create_subagent_context",
    "cleanup_subagent_context",
    "run_subagent",
    "run_subagent_with_background_signal",
    "BackgroundLaunchedResult",
    "_run_coroutine_sync",
    "register_background_agent",
    "get_background_agent_handle",
    "BackgroundAgentHandle",
    "run_async_agent_lifecycle",
    "JsonlTranscriptStore",
    "SubagentTranscriptManager",
    "SubagentTranscriptStore",
    "create_subagent_graph",
]
