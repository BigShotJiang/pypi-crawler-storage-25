"""Subagent Context 与 Result 数据结构

职责：封装子会话的独立状态与继承自父会话的共享引用
在整体链路中的位置：create_subagent_context() 构造 → run_subagent() 消费
CC 对照：src/agent/subagent/context.ts SubagentContext 接口
当前裁剪范围：v1 全量；system_prompt / is_async 字段驱动执行路径选择；
      ``path_prep`` 与遗留 ``cwd``/worktree 自建二选一（编排层须传 ``path_prep``）；
      fork + worktree 时可选注入 CC 等价 ``buildWorktreeNotice`` user 消息（见 ``fork_worktree_notice``）；
      ``fork_from_parent=True`` 且父持有 ``AgentSessionStore`` 时子上下文使用 ``clone(file_state_only=True)``。
"""

import os
import shutil
import uuid
from dataclasses import dataclass
from typing import Any

from langchain_agentx.loop.runtime.subagent_execution_paths import PreparedSubagentPaths
from langchain_agentx.loop.subagent.fork_worktree_notice import build_worktree_notice
from langchain_agentx.tool_runtime.session_store import AgentSessionStore
from langchain_agentx.workspace import resolve_agent_workspace_config


@dataclass
class SubagentContext:
    """子 Agent 执行上下文

    独立字段：agent_id / initial_messages / max_steps / subagent_type / agent_depth
             system_prompt / is_async / fork_from_parent
    共享字段：session_store / tool_registry（从父会话继承）
    执行路径：fork_from_parent 决定消息构造；is_async 决定同步/异步路径路由
    """
    # 独立字段
    agent_id: str
    initial_messages: list[dict[str, Any]]
    max_steps: int | None
    subagent_type: str
    model: Any | None = None
    agent_depth: int = 0

    # 执行路径字段（由外部注入，驱动 runner 路由决策）
    system_prompt: str = ""       # 由 SubagentConfig.system_prompt_factory() 注入
    fork_from_parent: bool = False  # True = fork 模式，initial_messages 含父会话历史
    is_async: bool = False         # True = 走异步路径（coordinate/fork-async）

    # 共享字段（从父会话继承）
    session_store: Any = None  # SessionStore
    tool_registry: Any = None  # ToolRegistry
    tool_loader: Any = None  # ToolRuntimeLoader

    # 可选字段
    parent_agent_id: str | None = None
    parent_run_id: str | None = None      # 父 Agent 的 trace run_id，供 TraceLifecycleCollector/Collector 建立父子链接
    parent_tool_call_id: str | None = None  # 触发本子 Agent 的 tool_call_id
    parent_conversation_session_id: str | None = None
    enable_trace: bool = True
    runnable_config: Any = None  # 父 graph 的 runnable_config，用于子 graph 事件自动冒泡到父 graph
    isolation: str = "none"
    worktree_dir: str | None = None
    workspace_root: str = ""
    agent_home: str = ".langchain_agentx"
    cwd: str | None = None
    capabilities: Any = None  # RuntimeCapabilities，从父会话继承


@dataclass
class SubagentResult:
    """子 Agent 执行结果"""
    agent_id: str
    content: str
    status: str  # "completed" | "error" | "interrupted"
    terminal_reason: str = ""
    total_steps: int = 0
    error_message: str = ""
    output_file: str | None = None
    child_run_id: str | None = None  # 子会话的 trace session_id，供父 run 追溯
    execution_trace: Any = None  # SubagentExecutionTrace，完整工具调用记录


def create_subagent_context(
    parent_ctx: Any,
    task: str,
    subagent_type: str,
    system_prompt: str = "",
    max_steps: int | None = None,
    model: Any | None = None,
    agent_depth: int = 0,
    isolation: str = "none",
    cwd: str | None = None,
    fork_from_parent: bool = False,
    is_async: bool = False,
    *,
    path_prep: PreparedSubagentPaths | None = None,
    inject_fork_worktree_notice: bool = False,
    fork_worktree_parent_cwd: str | None = None,
    fork_worktree_path: str | None = None,
) -> SubagentContext:
    """工厂函数：从父上下文创建子 Agent 上下文

    Args:
        parent_ctx: 父会话上下文（需有 session_store / tool_registry）
        task: 子任务描述
        subagent_type: 子 Agent 类型（"general-purpose" / "explore" / "plan"）
        system_prompt: 系统提示词（由 SubagentConfig.system_prompt_factory() 提供）
        max_steps: 最大步数
        model: 子 Agent 使用模型（None 时由调用方在 runner 阶段继续继承）
        agent_depth: Agent 嵌套深度
        isolation: 隔离模式（"none" / "worktree"）
        cwd: 工作目录覆盖（与 ``path_prep`` 二选一；``path_prep`` 非空时忽略本参数的路径语义）
        fork_from_parent: True = fork 模式，initial_messages 继承父会话历史
        is_async: True = 走异步执行路径（coordinate/fork-async）
        path_prep: 由 ``SubagentExecutionPaths.prepare`` 提供时，使用其 ``effective_cwd`` /
            ``worktree_dir``，且不再在本函数内创建 worktree 目录。
        inject_fork_worktree_notice: 为 True 且 ``fork_from_parent`` 且 ``fork_worktree_path`` 非空时，
            在最终任务 user 消息前插入 CC 等价 worktree 提示（父 cwd 由 ``fork_worktree_parent_cwd`` 提供）。
        fork_worktree_parent_cwd: 父 Agent 工作目录（须在 ``run_with_cwd_override`` 子 cwd 生效前由编排层捕获）。
        fork_worktree_path: 子 Agent 的 worktree 根路径（通常即 ``path_prep.worktree_dir``）。

    Returns:
        SubagentContext 实例
    """
    agent_id = str(uuid.uuid4())
    parent_run_id_raw = getattr(parent_ctx, "run_id", None)
    if not isinstance(parent_run_id_raw, str) or not parent_run_id_raw:
        parent_run_id_raw = getattr(parent_ctx, "session_id", None)
        if not isinstance(parent_run_id_raw, str) or not parent_run_id_raw:
            parent_run_id_raw = None
    parent_conversation_id = getattr(parent_ctx, "conversation_session_id", None)
    if not isinstance(parent_conversation_id, str) or not parent_conversation_id:
        parent_conversation_id = parent_run_id_raw
    parent_tool_call_id = getattr(parent_ctx, "tool_call_id", None)
    if not isinstance(parent_tool_call_id, str) or not parent_tool_call_id:
        anchor = parent_run_id_raw or "unknown-run"
        parent_tool_call_id = f"synthetic-agent-call:{anchor}:{agent_id[:8]}"

    parent_cwd = getattr(parent_ctx, "cwd", None)

    initial_messages = [{"role": "user", "content": task}]
    if fork_from_parent:
        parent_messages = getattr(parent_ctx, "state", {}).get("messages", [])
        if isinstance(parent_messages, list):
            initial_messages = []
            for msg in parent_messages:
                if isinstance(msg, dict):
                    initial_messages.append(dict(msg))
            notice_parent = fork_worktree_parent_cwd or parent_cwd or os.getcwd()
            if (
                inject_fork_worktree_notice
                and fork_worktree_path
                and isinstance(notice_parent, str)
                and notice_parent.strip()
            ):
                initial_messages.append(
                    {
                        "role": "user",
                        "content": build_worktree_notice(
                            notice_parent.strip(),
                            fork_worktree_path,
                        ),
                    }
                )
            initial_messages.append({"role": "user", "content": task})

    parent_workspace_root = getattr(parent_ctx, "workspace_root", None) or os.getcwd()
    parent_agent_home = getattr(parent_ctx, "agent_home", ".langchain_agentx")
    worktree_dir: str | None = None
    if path_prep is not None:
        effective_cwd = path_prep.effective_cwd
        worktree_dir = path_prep.worktree_dir
    else:
        effective_cwd = cwd or parent_cwd or os.getcwd()
        if isolation == "worktree":
            workspace_cfg = resolve_agent_workspace_config(
                workspace_root=parent_workspace_root,
                agent_home=parent_agent_home,
            )
            workspace_cfg.worktrees_dir.mkdir(parents=True, exist_ok=True)
            worktree_dir = str(
                workspace_cfg.worktrees_dir / f"agentx-worktree-{uuid.uuid4().hex[:12]}"
            )
            os.makedirs(worktree_dir, exist_ok=False)
            effective_cwd = (cwd.strip() if isinstance(cwd, str) and cwd.strip() else None) or worktree_dir

    parent_store = getattr(parent_ctx, "session_store", None)
    session_store: Any = parent_store
    if fork_from_parent and isinstance(parent_store, AgentSessionStore):
        session_store = parent_store.clone(file_state_only=True)

    return SubagentContext(
        agent_id=agent_id,
        initial_messages=initial_messages,
        max_steps=max_steps,
        model=model,
        subagent_type=subagent_type,
        agent_depth=agent_depth,
        system_prompt=system_prompt,
        fork_from_parent=fork_from_parent,
        is_async=is_async,
        session_store=session_store,
        tool_registry=getattr(parent_ctx, "tool_registry", None),
        tool_loader=getattr(parent_ctx, "tool_loader", None),
        parent_agent_id=getattr(parent_ctx, "agent_id", None),
        parent_run_id=parent_run_id_raw,
        parent_tool_call_id=parent_tool_call_id,
        parent_conversation_session_id=parent_conversation_id,
        enable_trace=bool(getattr(parent_ctx, "trace_enabled", True)),
        isolation=isolation,
        worktree_dir=worktree_dir,
        workspace_root=str(parent_workspace_root),
        agent_home=str(parent_agent_home),
        cwd=effective_cwd,
        capabilities=getattr(parent_ctx, "capabilities", None),
        runnable_config=getattr(parent_ctx, "runnable_config", None),
    )


def cleanup_subagent_context(ctx: SubagentContext) -> None:
    """清理 subagent 临时资源（如 worktree 目录）。"""
    if ctx.isolation == "worktree" and ctx.worktree_dir:
        shutil.rmtree(ctx.worktree_dir, ignore_errors=True)
