"""
graph_wiring.py — Hook 与 Loop 图装配协作者（Phase 2）。

职责：
    封装 Hook 节点工厂与最小接线路径，避免 factory.py 继续膨胀。

链路位置：
    由 loop/graph/factory.py 在构图阶段调用，产出 loop_start / stop_hooks 节点。

当前裁剪范围：
    Phase 2 仅接入 `loop_start` 与 `stop_hooks` 主路径；before/after/loop_end 节点先提供工厂占位。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from uuid import uuid4

from .async_hook_runner import AsyncHookRunner
from .engine import HookEngine
from .types import AggregatedHookResult, HookContext, HookEvent


def _to_hook_result_dict(result: AggregatedHookResult) -> dict[str, Any]:
    """将 AggregatedHookResult 转换为字典，包含 Hook 输出结果（stdout/stderr/exit_code）。"""
    return {
        "prevent_continuation": result.prevent_continuation,
        "blocking_errors": list(result.blocking_errors) or None,
        "permission_behavior": result.permission_behavior,
        "hook_permission_decision_reason": result.hook_permission_decision_reason,
        "additional_contexts": list(result.additional_contexts),
        "updated_input": result.updated_input,
        "state_patch": dict(result.state_patch),
        # Hook 输出结果（对齐 CC hook_response）
        "stdouts": list(result.stdouts) or None,
        "stderrs": list(result.stderrs) or None,
        "exit_codes": list(result.exit_codes) or None,
        "combined_stdout": result.combined_stdout or None,
        "combined_stderr": result.combined_stderr or None,
    }


@dataclass
class HookGraphWiring:
    """Hook 图装配器。"""

    hook_engine: HookEngine
    trace_lifecycle_collector: Any | None = None
    session_memory: Any | None = None
    memory_extractor: Any | None = None
    agent_memory_extractor: Any | None = None
    workspace_cfg: Any | None = None
    session_id: str | None = None
    container_type: str = "interactive"
    subagent_type: str | None = None
    hook_runner: AsyncHookRunner = field(default_factory=AsyncHookRunner)

    def loop_start_node(self, state: dict[str, Any], runtime: Any) -> dict[str, Any]:
        run_id = state.get("_run_id")
        if not isinstance(run_id, str) or not run_id:
            preferred = getattr(self.trace_lifecycle_collector, "default_run_id", None)
            run_id = preferred if isinstance(preferred, str) and preferred else uuid4().hex
        state_with_run_id = dict(state)
        state_with_run_id["_run_id"] = run_id
        patch: dict[str, Any] = {"_run_id": run_id}
        patch["_hook_engine"] = self.hook_engine
        patch["_hook_runner"] = self.hook_runner
        if self.trace_lifecycle_collector is not None:
            patch.update(self.trace_lifecycle_collector.loop_start_node(state_with_run_id))
        result = self._execute_sync(HookEvent.LOOP_START, state_with_run_id)
        if result is not None:
            patch["__hook_result__"] = _to_hook_result_dict(result)
            if result.state_patch:
                patch.update(dict(result.state_patch))
        return patch

    def before_model_node(self, state: dict[str, Any], runtime: Any) -> dict[str, Any]:
        result = self._execute_sync(HookEvent.BEFORE_MODEL, state)
        patch = {"__hook_result__": _to_hook_result_dict(result)} if result is not None else {}
        if result is not None and result.state_patch:
            patch.update(dict(result.state_patch))
        if self.trace_lifecycle_collector is not None:
            patch.update(self.trace_lifecycle_collector.before_model_node(state))
        return patch

    def after_model_node(self, state: dict[str, Any], runtime: Any) -> dict[str, Any]:
        result = self._execute_sync(HookEvent.AFTER_MODEL, state)
        patch = {"__hook_result__": _to_hook_result_dict(result)} if result is not None else {}
        if result is not None and result.state_patch:
            patch.update(dict(result.state_patch))
        if self.session_memory is not None:
            self.session_memory.maybe_trigger(state)
        if self.trace_lifecycle_collector is not None:
            patch.update(self.trace_lifecycle_collector.after_model_node(state))
        return patch

    def stop_hooks_node(self, state: dict[str, Any], runtime: Any) -> dict[str, Any]:
        # 仅在 loop_controller 会读取的时机执行 stop，避免每轮额外开销。
        if not bool(state.get("should_end")):
            return {}
        if self.memory_extractor is not None and self.workspace_cfg is not None:
            self.memory_extractor.trigger_from_state(
                state=state,
                workspace_cfg=self.workspace_cfg,
                session_id=self.session_id or str(state.get("_session_id") or ""),
                container_type=self.container_type,
            )
        if self.agent_memory_extractor is not None and self.workspace_cfg is not None:
            self.agent_memory_extractor.trigger_from_state(
                state=state,
                workspace_cfg=self.workspace_cfg,
                session_id=self.session_id or str(state.get("_session_id") or ""),
                container_type=self.container_type,
                agent_type=self.subagent_type,
            )
        result = self._execute_sync(HookEvent.STOP, state)
        if result is None:
            return {}
        patch = {"__hook_result__": _to_hook_result_dict(result)}
        if result.state_patch:
            patch.update(dict(result.state_patch))
        return patch

    def loop_end_node(self, state: dict[str, Any], runtime: Any) -> dict[str, Any]:
        result = self._execute_sync(HookEvent.LOOP_END, state)
        patch = {"__hook_result__": _to_hook_result_dict(result)} if result is not None else {}
        if result is not None and result.state_patch:
            patch.update(dict(result.state_patch))
        if self.trace_lifecycle_collector is not None:
            patch.update(self.trace_lifecycle_collector.loop_end_node(state))
        return patch

    def _execute_sync(
        self, event: HookEvent, state: dict[str, Any]
    ) -> AggregatedHookResult | None:
        ctx = HookContext(event=event, state=state, session_id=state.get("_run_id"))
        return self.hook_runner.run(self.hook_engine, ctx)


__all__ = ["HookGraphWiring"]
