"""
task_runtime/integrations/tool_use_summary_provider.py — Tool Use Summary 聚合 provider

职责：
    在 task 侧聚合工具调用结果，并异步生成 queued-command summary：
    1. record_tool_result：采集单次工具结果
    2. flush_scope_summary：按 scope 生成一次摘要命令
    3. build_batch / ack / nack：复用通用 queued-command provider

边界：
    - 不依赖 loop 结构；只产出 queued-command
    - “异步”语义由 record 与 flush 解耦实现（可在不同阶段触发）
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
import time
from uuid import uuid4

from langchain_core.messages import ToolMessage

from ..core.types import QueuePriority, TaskScope
from .loop_adapter import LoopInjectionBatch
from .queued_command_provider import InMemoryQueuedCommandProvider, QueuedCommandEnvelope


@dataclass(frozen=True)
class ToolUseRecord:
    tool_name: str
    status: str  # success | error
    latency_ms: int | None = None
    tool_use_id: str | None = None
    output_preview: str | None = None
    created_at: float = field(default_factory=time.time)


class ToolUseSummaryProvider:
    """聚合工具调用记录，输出 summary queued-command。"""

    def __init__(
        self,
        backend: InMemoryQueuedCommandProvider | None = None,
        *,
        max_queue_size: int | None = None,
        ttl_sec: float | None = None,
        error_ratio_now_threshold: float = 0.5,
        avg_latency_now_threshold_ms: int = 2000,
    ) -> None:
        self._backend = backend or InMemoryQueuedCommandProvider(
            max_queue_size=max_queue_size,
            ttl_sec=ttl_sec,
        )
        self._buffers: dict[str | None, list[ToolUseRecord]] = {}
        self._seen_tool_call_ids: dict[str | None, set[str]] = {}
        self._error_ratio_now_threshold = error_ratio_now_threshold
        self._avg_latency_now_threshold_ms = avg_latency_now_threshold_ms

    def record_tool_result(
        self,
        *,
        scope: TaskScope,
        tool_name: str,
        status: str,
        latency_ms: int | None = None,
        tool_use_id: str | None = None,
        output_preview: str | None = None,
    ) -> None:
        normalized_status = "success" if status not in {"error", "failed"} else "error"
        self._buffers.setdefault(scope.agent_id, []).append(
            ToolUseRecord(
                tool_name=tool_name,
                status=normalized_status,
                latency_ms=latency_ms,
                tool_use_id=tool_use_id,
                output_preview=output_preview,
            )
        )

    def flush_scope_summary(
        self,
        *,
        scope: TaskScope,
        priority: QueuePriority | None = None,
    ) -> int:
        records = self._buffers.get(scope.agent_id, [])
        if not records:
            return 0
        summary_text, payload = _build_summary(records)
        chosen_priority = priority or self._select_priority(payload)
        dedup_key = (
            f"tool_summary:{scope.agent_id}:{payload['total_calls']}:"
            f"{payload['error_calls']}:{chosen_priority.value}"
        )
        command_id = f"tool_summary_{uuid4().hex[:10]}"
        self._backend.enqueue(
            QueuedCommandEnvelope(
                command_id=command_id,
                source="tool_use_summary",
                summary=summary_text,
                scope=scope,
                priority=chosen_priority,
                payload=payload,
                dedup_key=dedup_key,
            )
        )
        self._buffers[scope.agent_id] = []
        return 1

    def ingest_from_opencode_events(
        self,
        *,
        scope: TaskScope,
        events: list[dict],
    ) -> int:
        """从 LangChain AgentX 风格事件列表采集工具调用结果。"""
        count = 0
        for event in events:
            event_type = str(event.get("event_type") or event.get("type") or "")
            data = event.get("data") or {}
            tool_name = str(data.get("tool_name") or "")
            if not tool_name:
                continue
            if event_type in {"tool-result", "TOOL_RESULT"}:
                summary = data.get("summary") or ""
                self.record_tool_result(
                    scope=scope,
                    tool_name=tool_name,
                    status="success",
                    output_preview=str(summary)[:120],
                )
                count += 1
            elif event_type in {"tool-error", "TOOL_ERROR"}:
                self.record_tool_result(
                    scope=scope,
                    tool_name=tool_name,
                    status="error",
                    output_preview=str(data.get("error") or "")[:120],
                )
                count += 1
        return count

    def ingest_from_messages(
        self,
        *,
        scope: TaskScope,
        messages: list,
    ) -> int:
        """从 loop state.messages 自动提取 ToolMessage 结果。"""
        count = 0
        seen = self._seen_tool_call_ids.setdefault(scope.agent_id, set())
        for msg in messages:
            if not isinstance(msg, ToolMessage):
                continue
            tool_call_id = getattr(msg, "tool_call_id", None)
            if not tool_call_id:
                continue
            tool_call_id = str(tool_call_id)
            if tool_call_id in seen:
                continue
            seen.add(tool_call_id)
            tool_name = _extract_tool_name(msg)
            status = _extract_tool_status(msg)
            content = msg.content
            preview = content if isinstance(content, str) else str(content)
            self.record_tool_result(
                scope=scope,
                tool_name=tool_name,
                status=status,
                output_preview=preview[:120],
                tool_use_id=tool_call_id,
            )
            count += 1
        return count

    def build_batch(
        self,
        scope: TaskScope,
        max_priority: QueuePriority = QueuePriority.NEXT,
        *,
        limit: int = 8,
    ) -> LoopInjectionBatch:
        return self._backend.build_batch(scope, max_priority=max_priority, limit=limit)

    def ack_batch(self, batch: LoopInjectionBatch) -> None:
        self._backend.ack_batch(batch)

    def nack_batch(self, batch: LoopInjectionBatch, *, requeue: bool = True) -> None:
        self._backend.nack_batch(batch, requeue=requeue)

    def has_pending(
        self, scope: TaskScope, max_priority: QueuePriority = QueuePriority.NEXT
    ) -> bool:
        return self._backend.has_pending(scope, max_priority=max_priority)

    def _select_priority(self, payload: dict) -> QueuePriority:
        total = int(payload.get("total_calls") or 0)
        errors = int(payload.get("error_calls") or 0)
        avg_latency_ms = payload.get("avg_latency_ms")
        if total > 0 and (errors / total) >= self._error_ratio_now_threshold:
            return QueuePriority.NOW
        if isinstance(avg_latency_ms, int) and avg_latency_ms >= self._avg_latency_now_threshold_ms:
            return QueuePriority.NOW
        if errors > 0:
            return QueuePriority.NEXT
        return QueuePriority.LATER


def _build_summary(records: list[ToolUseRecord]) -> tuple[str, dict]:
    total_calls = len(records)
    error_calls = sum(1 for item in records if item.status == "error")
    success_calls = total_calls - error_calls
    tool_counter = Counter(item.tool_name for item in records)
    tool_stat = [{"tool_name": k, "count": v} for k, v in tool_counter.items()]
    latency_values = [item.latency_ms for item in records if item.latency_ms is not None]
    avg_latency_ms = int(sum(latency_values) / len(latency_values)) if latency_values else None
    summary = (
        f"tool summary: total={total_calls}, success={success_calls}, "
        f"error={error_calls}, tools={dict(tool_counter)}"
    )
    return summary, {
        "total_calls": total_calls,
        "success_calls": success_calls,
        "error_calls": error_calls,
        "tools": tool_stat,
        "avg_latency_ms": avg_latency_ms,
    }


def _extract_tool_name(msg: ToolMessage) -> str:
    extra = getattr(msg, "additional_kwargs", {}) or {}
    metadata = getattr(msg, "metadata", {}) or {}
    name = (
        getattr(msg, "tool_name", None)
        or getattr(msg, "name", None)
        or extra.get("tool_name")
        or extra.get("name")
        or metadata.get("tool_name")
        or metadata.get("name")
    )
    return str(name) if name else "unknown_tool"


def _extract_tool_status(msg: ToolMessage) -> str:
    extra = getattr(msg, "additional_kwargs", {}) or {}
    metadata = getattr(msg, "metadata", {}) or {}
    if extra.get("error") or metadata.get("error"):
        return "error"
    if str(metadata.get("status") or "").lower() == "error":
        return "error"
    content = msg.content
    if isinstance(content, str) and content.lower().startswith("error"):
        return "error"
    return "success"

