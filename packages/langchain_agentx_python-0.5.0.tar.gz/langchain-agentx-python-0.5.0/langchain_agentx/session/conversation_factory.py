"""
session/conversation_factory.py — ConversationSession 入口工厂。

职责：
    统一组装 ConversationSession 所需 graph_factory、workspace 配置与 hook_engine。

链路位置：
    作为 Web/IM 对话场景创建 ConversationSession 的便捷入口。

当前裁剪范围：
    仅覆盖基础参数透传，不包含 HTTP 框架集成。
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
from uuid import uuid4

from langchain_core.messages import BaseMessage
from langchain_core.language_models.chat_models import BaseChatModel

from ..loop.graph.factory import create_loop_agent
from ..loop.hook import HookEngine, HooksConfigSnapshot, HookRegistry, WorkspaceTrustChecker
from ..workspace import resolve_agent_workspace_config
from .conversation_session import ConversationSession


def create_conversation_session(
    model: str | BaseChatModel,
    *,
    conversation_id: str | None = None,
    workspace_root: str | Path | None = None,
    agent_home: str = ".langchain_agentx",
    hooks: HookRegistry | None = None,
    hook_engine: Any | None = None,
    initial_messages: list[BaseMessage] | None = None,
    prompt_handler: Any | None = None,
    permission_resolver: Any | None = None,
    **loop_kwargs: Any,
) -> ConversationSession:
    """创建 ConversationSession。conversation_id 未传时自动生成。"""
    resolved_id = conversation_id or f"conv-{uuid4().hex}"
    workspace_cfg = resolve_agent_workspace_config(
        workspace_root=workspace_root or Path.cwd(),
        agent_home=agent_home,
    )
    if hook_engine is None:
        snapshot = hooks.build_snapshot() if hooks is not None else HooksConfigSnapshot()
        hook_engine = HookEngine(
            snapshot,
            trust_checker=WorkspaceTrustChecker(
                headless=False,
                workspace_trust_accepted=workspace_cfg.workspace_trust_accepted,
            ),
        )

    resolved_prompt_handler = prompt_handler
    if resolved_prompt_handler is None and "prompt_handler" in loop_kwargs:
        resolved_prompt_handler = loop_kwargs.pop("prompt_handler")

    resolved_permission_resolver = permission_resolver
    if resolved_permission_resolver is None and "permission_resolver" in loop_kwargs:
        resolved_permission_resolver = loop_kwargs.pop("permission_resolver")

    def _graph_factory(
        session_id: str,
        container_type: str = "conversation",
        **_ignored: Any,
    ) -> Any:
        return create_loop_agent(
            model,
            session_id=session_id,
            workspace_root=workspace_cfg.workspace_root,
            agent_home=workspace_cfg.agent_home,
            workspace_trust_accepted=workspace_cfg.workspace_trust_accepted,
            hooks=hooks,
            prompt_handler=resolved_prompt_handler,
            permission_resolver=resolved_permission_resolver,
            container_type=container_type,
            **loop_kwargs,
        )

    return ConversationSession(
        graph_factory=_graph_factory,
        conversation_id=resolved_id,
        workspace_cfg=workspace_cfg,
        hook_engine=hook_engine,
        initial_messages=list(initial_messages or []),
    )


__all__ = ["create_conversation_session"]
