"""
tools/grep/prompt.py — 工具名与模型可见描述

对应 CC：src/tools/GrepTool/prompt.ts（getDescription）。
"""

from __future__ import annotations

TOOL_NAME = "grep"


def get_prompt() -> str:
    """面向 StructuredTool.description 的完整说明。"""
    return (
        "A powerful search tool built on ripgrep\n\n"
        "Usage:\n"
        f"- ALWAYS use {TOOL_NAME} for search tasks. NEVER invoke `grep` or `rg` as a bash command. "
        f"The {TOOL_NAME} tool respects read permissions and workspace policy.\n"
        '- Supports full regex syntax (e.g., "log.*Error", "function\\s+\\w+")\n'
        '- Filter files with glob (e.g., "*.js", "**/*.tsx") or file_type (e.g., "js", "py", "rust")\n'
        '- Output modes: "content" = matching lines; "files_with_matches" = paths only (default); '
        '"count" = per-file counts\n'
        "- For open-ended searches needing multiple rounds, use an Agent / subagent workflow if available.\n"
        "- Pattern syntax: ripgrep (not grep) — literal braces need escaping "
        "(use `interface\\{\\}` to find `interface{}` in Go)\n"
        "- Multiline matching: By default patterns match within single lines only. "
        "For cross-line patterns like `struct \\{[\\s\\S]*?field\\`, use multiline: true\n"
    )


DESCRIPTION = get_prompt()
