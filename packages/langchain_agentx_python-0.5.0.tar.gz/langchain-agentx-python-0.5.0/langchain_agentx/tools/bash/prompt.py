"""
tools/bash/prompt.py — BashRuntimeTool 工具名与 prompt 模板

对应 CC prompt.ts 的 getSimplePrompt()（简化版，去掉 sandbox/git 详细指令）。
纯字符串/常量，无 I/O，无框架依赖，可单独测试。
"""

from __future__ import annotations

TOOL_NAME = "bash"
"""工具名，面向模型暴露。"""

DESCRIPTION = "Execute shell commands in a persistent bash session."
"""简短描述（对应 CC BashTool.description）。"""

# 预期不产生 stdout 的命令（对应 CC BASH_SILENT_COMMANDS）
SILENT_COMMANDS: frozenset[str] = frozenset({
    "mv", "cp", "rm", "mkdir", "rmdir", "chmod",
    "chown", "chgrp", "touch", "ln", "cd",
    "export", "unset",
})


def get_prompt() -> str:
    """
    返回面向模型的完整使用说明（对应 CC getSimplePrompt()）。
    动态引用 limits 配置，确保 prompt 与实际限制一致。
    """
    from .limits import get_bash_limits

    limits = get_bash_limits()

    return (
        "Executes a given bash command in a persistent shell session and returns its output.\n"
        "\n"
        "The working directory persists between commands. "
        "Shell variable state does NOT persist between separate calls.\n"
        "\n"
        "Usage:\n"
        f"- By default commands timeout after {limits['default_timeout_sec']} seconds "
        f"(max {limits['max_timeout_sec']} seconds)\n"
        "- Use the timeout parameter (in seconds) to override the default timeout\n"
        "- Use run_in_background=true for commands you don't need to wait for "
        "(dev servers, long builds). Only use this if you don't need the result immediately "
        "and are OK being notified when it completes later. You do not need to check the "
        "output right away - you'll be notified when it finishes. You do not need to use '&' "
        "at the end of the command when using this parameter.\n"
        "- Commands run in sandbox mode by default; use dangerously_disable_sandbox=true "
        "only when the runtime explicitly allows bypassing sandbox execution\n"
        "- Stderr is merged into stdout for a unified terminal-like view\n"
        "\n"
        "IMPORTANT: Avoid using this tool to run find/grep/cat/head/tail/sed/awk/echo commands, "
        "unless the user explicitly instructs it or you have verified that a dedicated tool cannot "
        "accomplish the task.\n"
        "\n"
        "Prefer dedicated tools over this tool when possible:\n"
        "- Read files: Use the read_file tool (NOT cat/head/tail)\n"
        "- Write files: Use the write tool (NOT echo >/cat <<EOF)\n"
        "- Search content: Use the grep tool (NOT grep/rg)\n"
        "- File search: Use the glob tool (NOT find/ls)\n"
        "- Communication: Output text directly (NOT echo/printf)\n"
        "\n"
        "Important restrictions:\n"
        "- Avoid interactive commands (vim, ssh, python REPL) — they require a TTY\n"
        f"- Avoid sleep > {limits['sleep_block_threshold_sec']}s — "
        "use run_in_background=true instead\n"
        "- Do not retry failing commands in a sleep loop — diagnose the root cause\n"
        "- When issuing multiple commands:\n"
        "  - If independent, run multiple bash calls in parallel when appropriate\n"
        "  - If dependent, use a single bash call and chain with &&\n"
        "  - Use ';' only when earlier commands may fail\n"
    )
