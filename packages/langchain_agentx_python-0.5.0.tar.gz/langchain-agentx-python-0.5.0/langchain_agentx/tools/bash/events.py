"""
tools/bash/events.py — Bash 进度事件聚合器

职责：
    BashProgressAccumulator 聚合 stream_execute_iter 的 chunk 输出，
    按 2s 静默阈值 + 1s/4KB 触发节奏发射进度事件。

对应 CC BashTool.tsx 的 BashProgress 结构。
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class BashProgressData:
    """Bash 进度事件 payload（对齐 CC BashProgress）。"""
    output: str  # 自上次 progress 以来的增量输出
    full_output: str  # 累积全量输出（可能截断）
    elapsed_time_seconds: float  # 已耗时秒数
    total_lines: int  # 累计行数
    total_bytes: int  # 累计字节数


@dataclass
class BashProgressAccumulator:
    """Bash 进度聚合器。

    聚合策略（与 CC 行为对齐）：
        - 启动后 2s 内不发 progress（避免短命令噪声）
        - 之后按 1s tick 或累计 output_delta > 4KB 触发
        - 每次发送清空 delta 缓冲；full_output 截到最大长度（16KB）
    """

    timeout_ms: int
    start_ts: float = field(default_factory=time.monotonic)
    last_emit_ts: float = 0.0
    delta_buffer: list[str] = field(default_factory=list)
    full_output: str = ""
    total_lines: int = 0
    total_bytes: int = 0
    _now: float | None = None  # 仅用于测试，模拟当前时间

    # 配置常量
    SILENT_SECONDS: float = 2.0  # 启动后静默阈值
    EMIT_INTERVAL_SECONDS: float = 1.0  # 发射间隔
    DELTA_SIZE_BYTES: int = 4096  # 触发字节数
    MAX_FULL_OUTPUT: int = 16384  # 全量输出最大长度

    def _get_now(self) -> float:
        """获取当前时间（可被测试覆盖）。"""
        return self._now if self._now is not None else time.monotonic()

    def append(self, chunk: str) -> None:
        """追加输出 chunk。"""
        if not chunk:
            return
        self.delta_buffer.append(chunk)
        self.full_output += chunk
        self.total_bytes += len(chunk.encode("utf-8", errors="ignore"))
        self.total_lines += chunk.count("\n")

    def _elapsed(self) -> float:
        return self._get_now() - self.start_ts

    def _delta_size(self) -> int:
        return sum(len(c.encode("utf-8", errors="ignore")) for c in self.delta_buffer)

    def should_emit(self) -> bool:
        """判断是否应该发射进度事件。"""
        elapsed = self._elapsed()
        delta_bytes = self._delta_size()
        now = self._get_now()

        # 静默期内不发射
        if elapsed < self.SILENT_SECONDS:
            return False

        # 首次发射或超过时间间隔
        if self.last_emit_ts == 0.0:
            return True
        if now - self.last_emit_ts >= self.EMIT_INTERVAL_SECONDS:
            return True

        # 累计超过字节数阈值
        if delta_bytes >= self.DELTA_SIZE_BYTES:
            return True

        return False

    def to_payload(self) -> BashProgressData:
        """生成进度 payload 并重置 delta 缓冲。"""
        delta = "".join(self.delta_buffer)
        # 截断 full_output 到最大长度
        full = self.full_output
        if len(full) > self.MAX_FULL_OUTPUT:
            full = full[-self.MAX_FULL_OUTPUT:] + "\n... (truncated)"

        payload = BashProgressData(
            output=delta,
            full_output=full,
            elapsed_time_seconds=self._elapsed(),
            total_lines=self.total_lines,
            total_bytes=self.total_bytes,
        )

        # 重置 delta 缓冲和发射时间戳
        self.delta_buffer.clear()
        self.last_emit_ts = self._get_now()

        return payload


__all__ = ["BashProgressData", "BashProgressAccumulator"]
