"""
tools/bash/auto_mode_adapter.py — Bash 工具的 Auto Mode 适配层

职责：
    暴露给 auto_mode 骨架的窄接口，遵循"骨架不感知工具内部"原则。
    骨架通过此模块反向调用 Bash 工具的自家能力，无需直接 import 工具内部。

链路位置：
    auto_mode/hook.py → tools/bash/auto_mode_adapter.py → {read_only_validation, ...}

导出能力（对位 CC BashTool.tsx:442 toAutoClassifierInput 等）：
    - DANGEROUS_BASH_PATTERNS: 危险 Bash 模式常量（给 rule_stripping 用）
    - to_classifier_input(data): 提取分类器入参（command 字符串）
    - get_read_only_classification(cmd): 封装 BashReadOnlyClassifier 给 L3 用

依赖方向约束（设计文档 §4.2.3）：
    骨架（auto_mode/*）只能 import 本模块，不得 import tools/bash/{read_only_validation, ...}。
    本模块可 import tools/bash 内部模块。

CC 源码对照：
    - src/tools/BashTool/BashTool.tsx:442: toAutoClassifierInput
    - src/utils/permissions/dangerousPatterns.ts: DANGEROUS_BASH_PATTERNS
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .read_only_validation import BashReadOnlyClassification

# ---------------------------------------------------------------------------
# DANGEROUS_BASH_PATTERNS（对应 CC dangerousPatterns.ts）
# ---------------------------------------------------------------------------

# 跨平台代码执行（高风险模式）
CROSS_PLATFORM_CODE_EXEC = (
    "python",
    "python3",
    "python2",
    "node",
    "deno",
    "tsx",
    "ruby",
    "perl",
    "php",
    "lua",
    "npx",
    "bunx",
    "npm run",
    "yarn run",
    "pnpm run",
    "bun run",
    "bash",
    "sh",
    "ssh",
)

# 危险 Bash 模式前缀（进入 auto 时剥离的 allow rule pattern）
# 对应 CC dangerousPatterns.ts::DANGEROUS_BASH_PATTERNS
DANGEROUS_BASH_PATTERNS: tuple[str, ...] = (
    *CROSS_PLATFORM_CODE_EXEC,
    # Shell 内置危险命令
    "zsh",
    "fish",
    "eval",
    "exec",
    "env",
    "xargs",
    "sudo",
    # 注：CC 的 ANT-only 扩展项（'gh', 'curl', 'wget', 'kubectl', 'aws', ...）
    # 由配置而非源码控制，见 AutoModeConfig.extra_dangerous_patterns
)


# ---------------------------------------------------------------------------
# to_classifier_input（对应 CC BashTool.tsx:442）
# ---------------------------------------------------------------------------

BASH_TOOL_NAME = "bash"


def to_classifier_input(data: dict[str, Any]) -> str | None:
    """提取 Bash 工具的 Auto Mode 分类器入参。

    对应 CC BashTool.tsx:442 的 toAutoClassifierInput：
        TypeScript: (input) => input.command

    Args:
        data: 工具入参 dict（来自 tool_input）

    Returns:
        command 字符串，如果为空或无效则返回 None
    """
    cmd = data.get("command")
    if not isinstance(cmd, str):
        return None
    cmd = cmd.strip()
    if not cmd:
        return None
    return cmd


# ---------------------------------------------------------------------------
# get_read_only_classification（L3 启发式入口）
# ---------------------------------------------------------------------------

def get_read_only_classification(command: str) -> "BashReadOnlyClassification":
    """获取 Bash 命令的只读分类结果。

    封装 BashReadOnlyClassifier 给 auto_mode 骨架调用，
    避免骨架直接 import read_only_validation.py。

    Args:
        command: Bash 命令字符串

    Returns:
        BashReadOnlyClassification 结果
    """
    from .read_only_validation import BashReadOnlyClassifier

    classifier = BashReadOnlyClassifier()
    return classifier.classify(command)


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------

def is_bash_tool(tool_name: str) -> bool:
    """判断是否为 Bash 工具。"""
    return tool_name == BASH_TOOL_NAME


def get_dangerous_patterns(extra: tuple[str, ...] = ()) -> tuple[str, ...]:
    """获取危险 Bash 模式列表（含扩展）。"""
    return (*DANGEROUS_BASH_PATTERNS, *extra)
