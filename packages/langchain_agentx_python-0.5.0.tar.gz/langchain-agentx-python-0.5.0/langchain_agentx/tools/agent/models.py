"""
tools/agent/models.py — AgentRuntimeTool 输入输出模型

职责：定义 Agent 工具对模型暴露的输入/输出 schema，不承载执行逻辑。
在整体链路中的位置：ToolExecutorPipeline 的 schema 校验层；invoke() 与 present() 的数据契约。
CC 对照：src/tools/AgentTool/AgentTool.tsx 的 inputSchema / outputSchema（Zod）。
当前裁剪范围：v1 实现同步输出与异步输出模型；异步执行链路留给 v2。
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class AgentToolInput(BaseModel):
    """Agent 工具输入参数。"""

    prompt: str = Field(..., description="The task for the agent to perform")
    description: str = Field(
        ...,
        description="A short (3-5 word) description of the task",
    )
    subagent_type: str | None = Field(
        default=None,
        description=(
            "The type of specialized agent to use for this task. "
            "If omitted, defaults to 'general-purpose'."
        ),
    )
    model: Any | None = Field(
        default=None,
        description="Optional model override for the subagent.",
    )
    run_in_background: bool = Field(
        default=False,
        description="If true, run subagent in background mode.",
    )
    isolation: Literal["none", "worktree"] = Field(
        default="none",
        description=(
            'Execution isolation mode for subagent. When "worktree", a temporary '
            "directory is created; if `cwd` is also set, the effective process cwd "
            "uses `cwd` first (CC: cwd ?? worktreePath)."
        ),
    )
    cwd: str | None = Field(
        default=None,
        description=(
            "Optional working directory override for subagent. "
            "Relative paths are resolved against workspace_root; "
            "validate_input normalizes to an absolute path when workspace_root is set."
        ),
    )
    fork_from_parent: bool = Field(
        default=False,
        description="If true, inherit parent message history when creating subagent context.",
    )


class AgentToolOutput(BaseModel):
    """同步执行输出。"""

    status: Literal["completed", "error", "interrupted", "async_launched"]
    content: str = ""
    agent_id: str = ""
    total_steps: int = 0
    terminal_reason: str | None = None
    error_message: str | None = None
    task_id: str | None = None
    output_file: str | None = None
    child_run_id: str | None = None  # 子会话 trace session_id
    execution_trace: Any = None  # SubagentExecutionTrace，完整工具调用记录


class AgentToolAsyncOutput(BaseModel):
    """异步执行输出（v2 预留）。"""

    status: Literal["async_launched"]
    agent_id: str
    task_id: str
    output_file: str
    description: str
    prompt: str
    can_read_output_file: bool = True
