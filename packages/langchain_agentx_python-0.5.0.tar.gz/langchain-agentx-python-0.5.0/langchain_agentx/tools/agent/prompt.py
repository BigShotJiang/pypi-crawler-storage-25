"""
tools/agent/prompt.py — Agent 工具描述生成

职责：按当前可用 subagent 类型动态生成给模型看的工具描述。
在整体链路中的位置：AgentRuntimeTool.description 属性调用 get_prompt()。
CC 对照：src/tools/AgentTool/prompt.ts 的 getPrompt()/formatAgentLine()。
当前裁剪范围：v3 对齐 CC 主提示词核心段落，并按本工程能力做最小差异收敛。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .registry.config import SubagentConfig

TOOL_NAME = "Agent"
LEGACY_TOOL_NAME = "agent"


def format_agent_line(config: "SubagentConfig") -> str:
    """格式化单个 subagent 条目。CC 对照：formatAgentLine()，含 whenToUse 字段。"""
    when_to_use = config.when_to_use or config.description
    return f"- {config.name}: {when_to_use} (Tools: {config.tools_description})"


def get_prompt(available_agents: list["SubagentConfig"]) -> str:
    """生成 Agent 工具完整描述。"""
    agent_lines = "\n".join(format_agent_line(cfg) for cfg in available_agents) or "- None"
    return (
        "Launch a new agent to handle complex, multi-step tasks autonomously.\n\n"
        "The Agent tool launches specialized agents that can handle focused work.\n"
        "Each subagent type has different strengths and tool access.\n\n"
        "Available agent types and their tools:\n"
        f"{agent_lines}\n\n"
        "When using Agent, pass subagent_type to select a specialist.\n"
        "If subagent_type is omitted, general-purpose is used.\n\n"
        "When NOT to use Agent:\n"
        "- If you need to read one known file, call Read directly.\n"
        "- If you only need 1-2 quick searches in nearby files, use Glob/Grep directly.\n"
        "- If the task is a single-step edit you can do immediately, do it directly.\n\n"
        "Usage notes:\n"
        "- Always include a short description (3-5 words) summarizing what the agent will do.\n"
        "- Launch multiple agents concurrently whenever possible, to maximize performance.\n"
        "- The subagent result is not automatically shown to the user; summarize it yourself.\n"
        "- When the agent is done, it will return a single message back to you.\n"
        "- Use run_in_background=true for genuinely independent work. "
        "When an agent runs in the background, you will be automatically notified when it completes "
        "— do NOT sleep, poll, or proactively check on its progress. Continue with other work or "
        "respond to the user instead.\n"
        "- Foreground vs background: Use foreground (default) when you need the agent's results "
        "before you can proceed — e.g., research agents whose findings inform your next steps. "
        "Use background when you have genuinely independent work to do in parallel.\n"
        "- Each Agent invocation with subagent_type starts fresh — provide a complete task description.\n"
        "- You can set isolation='worktree' to run in a temporary git worktree.\n"
        "- You can set fork_from_parent=true to inherit parent context (fork style).\n"
        "- If cwd is provided, it must point to a safe workspace path.\n"
        "- Do not invent background subagent results before completion notifications arrive.\n\n"
        "Prompt writing guidance:\n"
        "- Brief the subagent like a smart colleague who just walked into the room — "
        "it hasn't seen this conversation, doesn't know what you've tried, doesn't understand why this task matters.\n"
        "- Explain what you're trying to accomplish and why.\n"
        "- Describe what you've already learned or ruled out.\n"
        "- Give enough context about the surrounding problem that the agent can make judgment calls.\n"
        "- For research tasks, provide the question and scope, not rigid step scripts.\n"
        "- For implementation tasks, include concrete files/symbols and expected changes.\n"
        "- Clearly tell the agent whether you expect it to write code or just to do research.\n"
    )


DESCRIPTION = get_prompt([])

# CC 对照：EXPLORE_AGENT_MIN_QUERIES（exploreAgent.ts）
_EXPLORE_MIN_QUERIES = 3
_DEFAULT_SEARCH_TOOLS = "Glob, Grep, and Bash"


def build_agent_guidance_section(
    available_tools: list,
    search_tools: str = _DEFAULT_SEARCH_TOOLS,
) -> str | None:
    """生成主 system prompt 中的 Agent 使用引导段落。

    CC 对照：prompts.ts 第 374-380 行的条件性注入。
    完全 registry 驱动：只有已注册的 agent 才会出现在引导中。
    - 若 Explore 已注册，追加 Explore 专项引导（CC 原文）。
    - 若其他 agent 有 when_to_use，追加通用 agent 选择引导。
    返回 None 表示 Agent 工具不存在或无任何 when_to_use 可注入。
    """
    agent_tool = next(
        (t for t in available_tools if getattr(t, "name", "") in (TOOL_NAME, LEGACY_TOOL_NAME)),
        None,
    )
    if agent_tool is None:
        return None
    registry = getattr(agent_tool, "_registry", None)
    if registry is None:
        return None

    registered = registry.list_all()
    registered_names = {cfg.name for cfg in registered}
    agents_with_guidance = [cfg for cfg in registered if cfg.when_to_use]

    if not agents_with_guidance:
        return None

    parts: list[str] = []

    # Explore 专项引导（CC 原文对照）
    if "Explore" in registered_names:
        parts.append(
            f"For simple, directed codebase searches (e.g. for a specific file/class/function) "
            f"use {search_tools} directly.\n"
            f"For broader codebase exploration and deep research, use the {TOOL_NAME} tool with "
            f"subagent_type=Explore. This is slower than using {search_tools} directly, so use "
            f"this only when a simple, directed search proves to be insufficient or when your task "
            f"will clearly require more than {_EXPLORE_MIN_QUERIES} queries."
        )

    # 其余有 when_to_use 的 agent（排除 Explore，已单独处理）
    others = [cfg for cfg in agents_with_guidance if cfg.name != "Explore"]
    if others:
        lines = "\n".join(f"- {cfg.name}: {cfg.when_to_use}" for cfg in others)
        parts.append(
            f"When delegating to a specialized agent, choose based on the task:\n{lines}"
        )

    return "\n\n".join(parts) if parts else None


# 向后兼容别名
build_explore_plan_guidance = build_agent_guidance_section
