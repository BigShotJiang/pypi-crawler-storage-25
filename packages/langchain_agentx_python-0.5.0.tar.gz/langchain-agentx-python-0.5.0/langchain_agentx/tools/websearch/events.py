"""
tools/websearch/events.py — WebSearch 进度事件数据结构

职责：
    定义 WebSearch progress 事件的 data 载荷类型别名（文档/类型提示用）。
    实际 progress 通过 ctx.emit_progress() 发送，phase 直接使用字符串常量。

当前裁剪范围：
    仅保留类型别名；删除 ProgressEventType/ProgressEvent 类（已废弃）。
"""

from __future__ import annotations

from typing import Any

# ---- data 结构规范（文档/类型提示用，运行时以 dict 传递）----
SearchQueryUpdateData = dict[str, Any]  # query, result_count
SearchResultsReceivedData = dict[str, Any]  # result_count, results
SearchErrorData = dict[str, Any]  # message, code?

__all__ = [
    "SearchQueryUpdateData",
    "SearchResultsReceivedData",
    "SearchErrorData",
]
