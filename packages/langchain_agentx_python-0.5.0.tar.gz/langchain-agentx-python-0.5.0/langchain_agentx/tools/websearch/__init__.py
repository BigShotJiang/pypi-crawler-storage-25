"""
tools/websearch/ — WebSearchRuntimeTool 子系统公共导出

职责：
    导出输入/输出模型、进度事件、搜索后端抽象与 Tavily 实现。

链路位置：
    loader / factory 注册；单测直接 import 本包符号。

当前裁剪范围：
    WebSearchRuntimeTool 见 tool.py（Phase 5-b）；本包 __init__ 仅导出基础设施层。
"""

from __future__ import annotations

from langchain_agentx.tools.websearch.backend import (
    SearchBackend,
    SearchBackendError,
    SearXNGSearchBackend,
    TavilySearchBackend,
)
from langchain_agentx.tools.websearch.models import SearchHit, WebSearchToolInput, WebSearchToolOutput
from langchain_agentx.tools.websearch.tool import WebSearchRuntimeTool

__all__ = [
    "SearchBackend",
    "SearchBackendError",
    "SearXNGSearchBackend",
    "TavilySearchBackend",
    "SearchHit",
    "WebSearchToolInput",
    "WebSearchToolOutput",
    "WebSearchRuntimeTool",
]
