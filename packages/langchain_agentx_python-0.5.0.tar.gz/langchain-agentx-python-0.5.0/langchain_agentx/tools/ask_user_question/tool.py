"""
tools/ask_user_question/tool.py — AskUserQuestionTool

职责：
    CC AskUserQuestion 对齐：normalize → validate → permissions（含待答两跳）→ invoke → present。

链路位置：
    ToolRuntimeLoader.register_default_tools；pipeline 对 gather_tool 短路返回 pending envelope。

当前裁剪范围：
    v3：preview HTML 校验（ctx.question_preview_format）、annotations、present 摘要；渠道禁用集合对齐 CC。
"""

from __future__ import annotations

import copy
import re
from typing import Any

from pydantic import ValidationError

from langchain_agentx.tool_runtime.base import RuntimeTool
from langchain_agentx.tool_runtime.models import (
    AuthorizationDecision,
    ToolExecutionContext,
    ToolResultEnvelope,
    ValidationResult,
)

from .constants import PRESENT_PREVIEW_SNIPPET_MAX
from .html_preview import HtmlPreviewValidator
from .models import AskUserQuestionInput, AskUserQuestionOutput, QuestionAnnotation
from .prompt import (
    ASK_USER_QUESTION_TOOL_PROMPT,
    DESCRIPTION,
    DESCRIPTION_V3_APPEND,
    TOOL_NAME,
)
from .validators import QuestionValidator

# AuthorizationDecision.metadata：pipeline 识别待答短路（值须等于 RuntimeTool.name）
GATHER_TOOL_META_KEY = "gather_tool"

# CC isEnabled：Telegram/Discord 等无 TUI 渠道
_DISABLED_CHANNELS = frozenset({"telegram", "discord"})


def _normalize_preview_format(raw: Any) -> str | None:
    if raw is None:
        return None
    if not isinstance(raw, str) or not raw.strip():
        return None
    return raw.strip().lower()


def _flatten_preview_for_present(raw: str, max_len: int) -> str:
    """去标签、折叠空白后截断（§3.8.5，供 LLM 纯文本）。"""
    t = re.sub(r"<[^>]+>", " ", raw)
    t = " ".join(t.split())
    if len(t) > max_len:
        return t[: max_len - 1] + "…"
    return t


def _selected_labels(answer: str, multi: bool) -> list[str]:
    if not isinstance(answer, str) or not answer.strip():
        return []
    if multi:
        return [x.strip() for x in answer.split(",") if x.strip()]
    return [answer.strip()]


class AskUserQuestionTool(RuntimeTool):
    """向用户发起多选题并收集答案（对齐 CC AskUserQuestionTool）。"""

    name: str = TOOL_NAME
    description: str = (
        f"{DESCRIPTION}\n\n{ASK_USER_QUESTION_TOOL_PROMPT}\n\n{DESCRIPTION_V3_APPEND}"
    )
    input_model = AskUserQuestionInput
    output_model = AskUserQuestionOutput

    is_read_only: bool = True
    is_destructive: bool = False
    is_concurrency_safe: bool = True
    never_truncate: bool = False
    dedupe_identical_calls: bool = False
    max_result_size_chars: int = 100_000

    def __init__(
        self,
        *,
        policy: Any | None = None,
        state_bridge: Any | None = None,
        question_validator: QuestionValidator | None = None,
        html_preview_validator: HtmlPreviewValidator | None = None,
    ) -> None:
        super().__init__(policy=policy, state_bridge=state_bridge)
        self._question_validator = question_validator or QuestionValidator()
        self._html_preview_validator = html_preview_validator or HtmlPreviewValidator()

    def normalize_input(
        self,
        raw: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> dict[str, Any]:
        _ = ctx
        data = dict(raw)
        questions = data.get("questions")
        if isinstance(questions, list):
            for q in questions:
                if isinstance(q, dict) and "multiSelect" not in q:
                    q["multiSelect"] = False
        if "answers" not in data or data["answers"] is None:
            data["answers"] = {}
        if "annotations" not in data or data["annotations"] is None:
            data["annotations"] = {}
        return data

    def validate_input(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> ValidationResult:
        base = self._question_validator.validate_questions_payload(data)
        if not base.ok:
            return base

        questions = data.get("questions", [])

        answers = data.get("answers") or {}
        if isinstance(answers, dict) and not answers:
            ann0 = data.get("annotations") or {}
            if isinstance(ann0, dict) and ann0:
                return ValidationResult(
                    ok=False,
                    message="annotations cannot be sent without answers (second hop only)",
                    code="ANNOTATIONS_WITHOUT_ANSWERS",
                )

        if isinstance(answers, dict) and answers:
            qtexts = [qt for qt in (q.get("question") for q in questions) if isinstance(qt, str)]
            unknown = [k for k in answers if k not in qtexts]
            if unknown:
                return ValidationResult(
                    ok=False,
                    message=f"answers keys must match question texts; unknown: {unknown!r}",
                    code="UNKNOWN_ANSWER_KEY",
                )

        ann = data.get("annotations") or {}
        if isinstance(ann, dict) and ann:
            qtexts = [qt for qt in (q.get("question") for q in questions) if isinstance(qt, str)]
            unknown_a = [k for k in ann if k not in qtexts]
            if unknown_a:
                return ValidationResult(
                    ok=False,
                    message=f"annotations keys must match question texts; unknown: {unknown_a!r}",
                    code="UNKNOWN_ANNOTATION_KEY",
                )
            for k, v in ann.items():
                if isinstance(v, QuestionAnnotation):
                    continue
                if not isinstance(v, dict):
                    return ValidationResult(
                        ok=False,
                        message=f"annotations[{k!r}] must be an object",
                        code="INVALID_ANNOTATION_SHAPE",
                    )
                try:
                    QuestionAnnotation.model_validate(v)
                except ValidationError as e:
                    return ValidationResult(
                        ok=False,
                        message=str(e),
                        code="INVALID_ANNOTATION_VALUE",
                    )

        fmt = _normalize_preview_format(getattr(ctx, "question_preview_format", None))
        if fmt is not None and fmt not in ("markdown", "html"):
            return ValidationResult(
                ok=False,
                message=(
                    "question_preview_format must be 'markdown', 'html', or unset; "
                    f"got {getattr(ctx, 'question_preview_format', None)!r}"
                ),
                code="INVALID_PREVIEW_FORMAT",
            )

        if fmt == "html":
            for qi, q in enumerate(questions):
                if not isinstance(q, dict):
                    continue
                for oi, opt in enumerate(q.get("options") or []):
                    if not isinstance(opt, dict):
                        continue
                    pv = opt.get("preview")
                    if isinstance(pv, str) and pv.strip():
                        hr = self._html_preview_validator.validate(pv)
                        if not hr.ok:
                            return ValidationResult(
                                ok=False,
                                message=f"Question {qi} option {oi}: {hr.message}",
                                code=hr.code or "ILLEGAL_HTML_PREVIEW",
                            )

        try:
            AskUserQuestionInput.model_validate(data)
        except ValidationError as e:
            return ValidationResult(
                ok=False,
                message=str(e),
                code="INVALID_INPUT_SHAPE",
            )

        return ValidationResult(ok=True)

    def check_permissions(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        base = super().check_permissions(data, ctx)
        if base.behavior == "deny":
            return base

        ch = getattr(ctx, "channels", None)
        if ch:
            lowered = {str(c).lower().strip() for c in ch if str(c).strip()}
            if _DISABLED_CHANNELS.intersection(lowered):
                return AuthorizationDecision(
                    behavior="deny",
                    message="AskUserQuestion is not available in this channel",
                    policy_id="ask_user_question_channel",
                )

        answers = data.get("answers") or {}
        if isinstance(answers, dict) and len(answers) > 0:
            return AuthorizationDecision(behavior="allow")

        questions = copy.deepcopy(data.get("questions", []))
        return AuthorizationDecision(
            behavior="ask",
            message="Answer questions?",
            ask_prompt="Answer questions?",
            policy_id="ask_user_question_pending",
            metadata={
                GATHER_TOOL_META_KEY: self.name,
                "questions": questions,
            },
        )

    def invoke(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> Any:
        _ = ctx
        inp = AskUserQuestionInput.model_validate(data)
        return AskUserQuestionOutput(
            questions=list(inp.questions),
            answers=dict(inp.answers),
            annotations=dict(inp.annotations),
        )

    def present(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> ToolResultEnvelope:
        _ = ctx
        _ = data
        if not isinstance(result, AskUserQuestionOutput):
            return super().present(data, result, ctx)

        lines = ["User has answered your questions:"]
        for q in result.questions:
            q_text = q.question
            answer = result.answers.get(q_text, "<unanswered>")
            lines.append(f"  - {q_text}: {answer}")
            if answer != "<unanswered>":
                selected = set(_selected_labels(answer, q.multiSelect))
                for opt in q.options:
                    if opt.label in selected and opt.preview:
                        snippet = _flatten_preview_for_present(
                            opt.preview, PRESENT_PREVIEW_SNIPPET_MAX
                        )
                        lines.append(f"    • [{opt.label}] preview: {snippet}")
            ann = result.annotations.get(q_text)
            if ann is not None:
                if ann.userNote:
                    note = _flatten_preview_for_present(
                        ann.userNote, PRESENT_PREVIEW_SNIPPET_MAX
                    )
                    lines.append(f"    Notes: {note}")
                if ann.selectedPreviewSnapshot:
                    snap = _flatten_preview_for_present(
                        ann.selectedPreviewSnapshot, PRESENT_PREVIEW_SNIPPET_MAX
                    )
                    lines.append(f"    Preview snapshot: {snap}")
        body = "\n".join(lines)

        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary="User has answered your questions.",
            payload=body,
            meta={
                "question_count": len(result.questions),
                "answered_count": len(result.answers),
                "has_multi_select": any(q.multiSelect for q in result.questions),
            },
        )

    def present_for_display(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> dict[str, Any] | None:
        """out-of-band：问答摘要（对位 CC AskUserQuestion UI）。"""
        _ = data, ctx
        if not isinstance(result, AskUserQuestionOutput):
            return None
        items: list[dict[str, Any]] = []
        for q in result.questions:
            q_text = q.question
            answer = result.answers.get(q_text, "")
            items.append(
                {
                    "question": q_text,
                    "answer": answer,
                    "selected_options": _selected_labels(answer, q.multiSelect),
                    "header": q.header,
                    "multi_select": q.multiSelect,
                }
            )
        return {
            "questions": items,
            "answered_count": len(result.answers),
        }
