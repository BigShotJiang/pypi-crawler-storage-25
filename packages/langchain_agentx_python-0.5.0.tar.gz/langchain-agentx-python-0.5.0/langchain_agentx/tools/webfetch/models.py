"""
tools/webfetch/models.py — WebFetch 输入输出与进度事件模型

职责：
    Pydantic 定义 WebFetchToolInput/Output、跨域重定向 RedirectResult、
    WebFetchProgressEventType / WebFetchProgressEvent。

链路位置：
    ToolExecutorPipeline schema 解析与后续 FetchBackend / RuntimeTool 序列化。

裁剪范围：
    v1 不含 CC 侧 domain preflight 错误类型的细分枚举。
"""

from __future__ import annotations

import time
from enum import StrEnum
from typing import Any
from urllib.parse import urlparse

from pydantic import BaseModel, Field, field_validator

from langchain_agentx.tools.webfetch.limits import MAX_URL_LENGTH


class WebFetchToolInput(BaseModel):
    """WebFetch 工具入参（对齐 CC：url + prompt）。"""

    url: str = Field(..., description="Fully-formed HTTP(S) URL to fetch.")
    prompt: str = Field(
        ...,
        description="What to extract or summarize from the page content.",
    )

    @field_validator("url")
    @classmethod
    def _url_non_empty_and_length(cls, v: str) -> str:
        s = v.strip()
        if not s:
            raise ValueError("url cannot be empty")
        if len(s) > MAX_URL_LENGTH:
            raise ValueError(f"url exceeds maximum length ({MAX_URL_LENGTH} characters)")
        parsed = urlparse(s)
        if parsed.scheme not in ("http", "https"):
            raise ValueError("url must use http or https scheme")
        if not parsed.hostname:
            raise ValueError("url must include a valid host")
        return s

    @field_validator("prompt")
    @classmethod
    def _prompt_non_empty(cls, v: str) -> str:
        s = v.strip()
        if not s:
            raise ValueError("prompt cannot be empty")
        return s


class RedirectResult(BaseModel):
    """跨域重定向时返回，供模型决定是否二次 WebFetch。"""

    original_url: str
    redirect_url: str
    status_code: int
    status_text: str = ""


class WebFetchToolOutput(BaseModel):
    """一次抓取或缓存命中的业务输出（供 present / payload）。"""

    url: str
    result: str = Field(
        ...,
        description="Markdown body, summary text, or user-facing status message.",
    )
    bytes: int | None = None
    code: int | None = None
    code_text: str | None = None
    duration_ms: int | None = None
    content_type: str | None = None
    is_redirect: bool = False
    redirect_url: str | None = None
    persisted_path: str | None = None
    from_cache: bool = False
    redirect: RedirectResult | None = None
