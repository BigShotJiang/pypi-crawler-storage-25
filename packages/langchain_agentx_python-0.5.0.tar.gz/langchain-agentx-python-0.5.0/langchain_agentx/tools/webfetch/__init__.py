"""
tools/webfetch — WebFetchRuntimeTool 包（URL 抓取与摘要）

职责：
    导出模型、限制、预批准域名、提示词、FetchBackend、RuntimeTool、摘要包装与 loader。

链路位置：
    ToolRuntimeLoader.register_default_tools → webfetch.loader.register。

裁剪范围：
    不含 Trace 伴侣包与 LangGraph 事件总线的自动桥接。
"""

from __future__ import annotations

from langchain_agentx.tools.webfetch.backend import (
    EgressBlockedError,
    FetchBackend,
    FetchResult,
    TooManyRedirectsError,
)
from langchain_agentx.tools.webfetch.limits import (
    CACHE_MAX_SIZE_BYTES,
    CACHE_TTL_SEC,
    FETCH_TIMEOUT_SEC,
    MAX_HTTP_CONTENT_LENGTH,
    MAX_MARKDOWN_LENGTH,
    MAX_REDIRECTS,
    MAX_URL_LENGTH,
)
from langchain_agentx.tools.webfetch.loader import is_enabled, register
from langchain_agentx.tools.webfetch.models import (
    RedirectResult,
    WebFetchToolInput,
    WebFetchToolOutput,
)
from langchain_agentx.tools.webfetch.preapproved import (
    is_preapproved_host,
    is_preapproved_url,
)
from langchain_agentx.tools.webfetch.prompt import (
    DESCRIPTION,
    TOOL_NAME,
    build_summary_prompt,
)
from langchain_agentx.tools.webfetch.summary import default_summary_model_fn
from langchain_agentx.tools.webfetch.tool import SummaryModelFn, WebFetchRuntimeTool

__all__ = [
    "CACHE_MAX_SIZE_BYTES",
    "CACHE_TTL_SEC",
    "DESCRIPTION",
    "EgressBlockedError",
    "FETCH_TIMEOUT_SEC",
    "FetchBackend",
    "FetchResult",
    "MAX_HTTP_CONTENT_LENGTH",
    "MAX_MARKDOWN_LENGTH",
    "MAX_REDIRECTS",
    "MAX_URL_LENGTH",
    "RedirectResult",
    "SummaryModelFn",
    "TOOL_NAME",
    "TooManyRedirectsError",
    "WebFetchRuntimeTool",
    "WebFetchToolInput",
    "WebFetchToolOutput",
    "build_summary_prompt",
    "default_summary_model_fn",
    "is_enabled",
    "is_preapproved_host",
    "is_preapproved_url",
    "register",
]
