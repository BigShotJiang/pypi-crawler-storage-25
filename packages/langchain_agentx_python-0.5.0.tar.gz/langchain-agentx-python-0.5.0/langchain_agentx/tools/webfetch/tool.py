"""
tools/webfetch/tool.py — WebFetchRuntimeTool

职责：
    RuntimeTool 全生命周期；编排 FetchBackend、预批准域名、摘要提示词与进度事件。

链路位置：
    ToolRuntimeLoader.register(WebFetchRuntimeTool(...))；默认由 webfetch.loader 装配。

裁剪范围：
    摘要默认可注入可调用对象；未注入时对需摘要路径返回截断正文 + 警告（Phase 5 可接默认 LLM）。
"""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any

import httpx
from pydantic import ValidationError

from langchain_agentx.tool_runtime.base import RuntimeTool
from langchain_agentx.tool_runtime.models import (
    AuthorizationDecision,
    ToolExecutionContext,
    ToolResultEnvelope,
    ValidationResult,
)
from langchain_agentx.tools.webfetch.backend import (
    EgressBlockedError,
    FetchBackend,
    FetchResult,
    TooManyRedirectsError,
)
from langchain_agentx.tools.webfetch.limits import MAX_MARKDOWN_LENGTH
from langchain_agentx.tools.webfetch.models import (
    WebFetchToolInput,
    WebFetchToolOutput,
)
from langchain_agentx.tools.webfetch.preapproved import is_preapproved_url
from langchain_agentx.tools.webfetch.prompt import DESCRIPTION, TOOL_NAME, build_summary_prompt

SummaryModelFn = Callable[[str], str]
"""接收 build_summary_prompt 生成的完整用户消息，返回摘要文本（同步）。"""


def _as_input(data: dict[str, Any]) -> WebFetchToolInput:
    return WebFetchToolInput.model_validate(data)


class WebFetchRuntimeTool(RuntimeTool):
    name: str = TOOL_NAME
    description: str = DESCRIPTION
    input_model = WebFetchToolInput
    output_model = WebFetchToolOutput
    is_read_only: bool = True
    is_concurrency_safe: bool = True
    never_truncate: bool = False

    def __init__(
        self,
        *,
        backend: FetchBackend | None = None,
        policy: Any | None = None,
        state_bridge: Any | None = None,
        summary_model_fn: SummaryModelFn | None = None,
    ) -> None:
        super().__init__(policy=policy, state_bridge=state_bridge)
        self._backend = backend or FetchBackend()
        self._summary_model_fn = summary_model_fn

    def validate_input(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> ValidationResult:
        try:
            _as_input(data)
        except ValidationError as e:
            return ValidationResult(
                ok=False,
                message=str(e),
                code="VALIDATION_ERROR",
            )
        except Exception as e:
            return ValidationResult(
                ok=False,
                message=str(e),
                code="VALIDATION_ERROR",
            )
        return ValidationResult(ok=True)

    def check_permissions(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        if not ctx.network_access_allowed:
            return AuthorizationDecision(
                behavior="deny",
                message="Web fetch is disabled (network_access_allowed=False)",
            )
        url = str(data.get("url") or "").strip()
        if is_preapproved_url(url):
            return AuthorizationDecision(behavior="allow")
        return super().check_permissions(data, ctx)

    def invoke(self, data: dict[str, Any], ctx: ToolExecutionContext) -> WebFetchToolOutput:
        parsed = _as_input(data)
        url = parsed.url
        user_prompt = parsed.prompt

        def on_redirect(payload: dict[str, Any]) -> None:
            pass  # 不再发射进度事件（与 CC 对齐）

        try:
            fr = self._backend.fetch(url, on_redirect=on_redirect)
        except (EgressBlockedError, TooManyRedirectsError) as e:
            raise
        except httpx.HTTPError as e:
            raise

        if fr.from_cache:
            pass  # 不再发射进度事件

        if fr.redirect is not None:
            return WebFetchToolOutput(
                url=url,
                result=(
                    "The URL returned a cross-origin redirect. "
                    "Fetch the content using the redirect_url in a new WebFetch call."
                ),
                bytes=fr.byte_count,
                code=fr.redirect.status_code,
                code_text=fr.redirect.status_text,
                duration_ms=fr.duration_ms,
                content_type=fr.content_type or "",
                is_redirect=True,
                redirect_url=fr.redirect.redirect_url,
                from_cache=False,
                redirect=fr.redirect,
            )

        body = fr.content
        truncated = body
        if len(body) > MAX_MARKDOWN_LENGTH:
            truncated = body[:MAX_MARKDOWN_LENGTH] + "\n\n[Content truncated due to length...]"

        pre = is_preapproved_url(url)
        skip_summary = pre and len(body) <= MAX_MARKDOWN_LENGTH

        if skip_summary:
            final_text = body
        elif self._summary_model_fn is not None:
            full_prompt = build_summary_prompt(
                is_preapproved=pre,
                content=truncated,
                user_prompt=user_prompt,
            )
            try:
                final_text = self._summary_model_fn(full_prompt)
            except Exception as e:
                final_text = (
                    truncated
                    + "\n\n[WebFetch warning: summary model failed; showing truncated markdown. "
                    + str(e)
                    + "]"
                )
        else:
            final_text = (
                truncated
                + "\n\n[WebFetch warning: no summary_model_fn configured; showing truncated markdown.]"
            )

        return WebFetchToolOutput(
            url=url,
            result=final_text,
            bytes=fr.byte_count,
            code=fr.code,
            code_text=fr.code_text,
            duration_ms=fr.duration_ms,
            content_type=fr.content_type or "",
            persisted_path=fr.persisted_path,
            from_cache=fr.from_cache,
        )

    def present(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> ToolResultEnvelope:
        if not isinstance(result, WebFetchToolOutput):
            return ToolResultEnvelope(
                status="ok",
                tool_name=self.name,
                summary=str(result),
                payload={"raw": str(result)},
            )
        r = result
        lines = [
            f"URL: {r.url}",
            f"HTTP {r.code or '—'} {r.code_text or ''}".strip(),
            f"Bytes: {r.bytes if r.bytes is not None else '—'} · "
            f"{r.duration_ms if r.duration_ms is not None else '—'} ms · "
            f"cache={'yes' if r.from_cache else 'no'}",
        ]
        if r.redirect is not None:
            lines.append(f"Redirect → {r.redirect.redirect_url}")
        if r.persisted_path:
            lines.append(f"Binary saved: {r.persisted_path}")
        summary = lines[0] + (" (redirect)" if r.redirect else "")
        body = "\n".join(lines) + "\n\n---\n\n" + r.result
        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary=summary,
            payload={"markdown": body, "output": r.model_dump()},
            meta={
                "duration_ms": r.duration_ms,
                "from_cache": r.from_cache,
                "code": r.code,
            },
        )

    def present_for_display(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> dict[str, Any] | None:
        """out-of-band：URL / HTTP 摘要（对位 CC WebFetchTool UI）。"""
        _ = data, ctx
        if not isinstance(result, WebFetchToolOutput):
            return None
        return {
            "url": result.url,
            "http_code": result.code,
            "content_length": len(result.result) if result.result else 0,
            "duration_ms": result.duration_ms,
            "from_cache": result.from_cache,
            "redirected": result.is_redirect,
        }


__all__ = ["SummaryModelFn", "WebFetchRuntimeTool"]
