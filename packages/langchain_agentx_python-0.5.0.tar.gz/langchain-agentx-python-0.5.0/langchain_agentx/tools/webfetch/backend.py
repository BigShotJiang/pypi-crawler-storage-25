"""
tools/webfetch/backend.py — HTTP 抓取、重定向、HTML→Markdown、LRU+TTL 缓存

职责：
    HtmlConverter / CacheManager 协作者 + FetchBackend 主编排；
    对齐 CC WebFetchTool/utils.ts 的 validateURL、upgradeToHttps、
    isPermittedRedirect、getWithPermittedRedirects、convertToMarkdown、URL 缓存。

链路位置：
    WebFetchRuntimeTool.invoke 调用 FetchBackend.fetch；进度经 on_redirect 回调上报。

裁剪范围：
    v1 不含 CC checkDomainBlocklist / DomainBlockedError；同步 httpx.Client；
    二进制落盘使用系统临时目录（未接 AgentWorkspaceConfig）。
"""

from __future__ import annotations

import mimetypes
import os
import re
import tempfile
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any
from urllib.parse import urljoin, urlparse

import httpx

from langchain_agentx.tools.webfetch.limits import (
    CACHE_MAX_SIZE_BYTES,
    CACHE_TTL_SEC,
    FETCH_TIMEOUT_SEC,
    MAX_HTTP_CONTENT_LENGTH,
    MAX_REDIRECTS,
    MAX_URL_LENGTH,
)
from langchain_agentx.tools.webfetch.models import RedirectResult

_DEFAULT_UA = (
    "Mozilla/5.0 (compatible; LangChain-AgentX-WebFetch/0.2; "
    "+https://github.com/GoodMood2008/langchain_agentx_python)"
)


class EgressBlockedError(RuntimeError):
    """对齐 CC：403 且 X-Proxy-Error: blocked-by-allowlist。"""

    def __init__(self, domain: str) -> None:
        self.domain = domain
        super().__init__(
            '{"error_type":"EGRESS_BLOCKED","domain":"'
            + domain
            + '","message":"Access blocked by network egress proxy."}'
        )


class TooManyRedirectsError(RuntimeError):
    """同域重定向超过 MAX_REDIRECTS。"""


@dataclass(slots=True)
class FetchResult:
    """FetchBackend.fetch 返回值（成功、缓存命中或跨域重定向）。"""

    url: str
    final_url: str
    content: str
    byte_count: int
    code: int
    code_text: str
    content_type: str
    persisted_path: str | None
    from_cache: bool
    duration_ms: int
    redirect: RedirectResult | None = None


def _strip_www(host: str) -> str:
    return host[4:] if host.startswith("www.") else host


def _is_permitted_redirect(from_url: str, to_url: str) -> bool:
    """对齐 CC isPermittedRedirect（同 www、同端口、无嵌入凭据）。"""
    try:
        a = urlparse(from_url)
        b = urlparse(to_url)
    except ValueError:
        return False
    if a.scheme != b.scheme or a.port != b.port:
        return False
    if b.username or b.password:
        return False
    ah = (a.hostname or "").lower()
    bh = (b.hostname or "").lower()
    return _strip_www(ah) == _strip_www(bh)


def _validate_url(url: str) -> None:
    if not url or not url.strip():
        raise ValueError("url cannot be empty")
    s = url.strip()
    if len(s) > MAX_URL_LENGTH:
        raise ValueError(f"url exceeds maximum length ({MAX_URL_LENGTH})")
    p = urlparse(s)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("invalid url")
    if p.username or p.password:
        raise ValueError("url must not contain embedded credentials")
    parts = p.hostname.split(".")
    if len(parts) < 2:
        raise ValueError("hostname must look like a public domain")


def _upgrade_to_https(url: str) -> str:
    p = urlparse(url.strip())
    if p.scheme == "http":
        return p._replace(scheme="https").geturl()
    return url.strip()


def _is_binary_content_type(content_type: str) -> bool:
    ct = (content_type or "").split(";")[0].strip().lower()
    if ct.startswith("text/") or ct in ("application/json", "application/xml", "application/javascript"):
        return False
    if "html" in ct:
        return False
    prefixes = ("image/", "audio/", "video/", "application/octet-stream", "application/pdf", "font/")
    return any(ct.startswith(p) for p in prefixes)


class HtmlConverter:
    """HTML→Markdown；markdownify → html2text → 极简去标签。"""

    def to_markdown(self, html: str, *, content_type: str) -> str:
        ct = (content_type or "").lower()
        if "text/html" not in ct:
            return html
        try:
            from markdownify import markdownify as md  # type: ignore[import-untyped]

            return str(md(html, heading_style="ATX")).strip()
        except ImportError:
            pass
        try:
            import html2text as _h2t  # type: ignore[import-untyped]

            h = _h2t.HTML2Text()
            h.ignore_links = False
            return h.handle(html).strip()
        except ImportError:
            pass
        return re.sub(r"<[^>]+>", " ", html)


class _UrlBodyCacheStore:
    """CC WebFetchTool/utils.ts URL_CACHE 语义：按 URL 键、TTL 过期、总字节上限 LRU 淘汰。"""

    def get(self, key: str) -> dict[str, Any] | None:
        raise NotImplementedError

    def set(self, key: str, entry: dict[str, Any]) -> None:
        raise NotImplementedError


class _CachetoolsUrlCache(_UrlBodyCacheStore):
    def __init__(
        self,
        *,
        max_bytes: int,
        ttl_sec: float,
        timer: Callable[[], float],
    ) -> None:
        from cachetools import TTLCache

        def sizeof(value: dict[str, Any]) -> int:
            return max(1, int(value.get("size_bytes", 1)))

        self._cache: Any = TTLCache(
            maxsize=max_bytes,
            ttl=ttl_sec,
            timer=timer,
            getsizeof=sizeof,
        )

    def get(self, key: str) -> dict[str, Any] | None:
        try:
            return self._cache[key]
        except KeyError:
            return None

    def set(self, key: str, entry: dict[str, Any]) -> None:
        self._cache[key] = entry


class _StdlibUrlCache(_UrlBodyCacheStore):
    """无 cachetools 时的回退（对齐 CC 始终启用 URL 缓存，而非静默禁用）。"""

    def __init__(
        self,
        *,
        max_bytes: int,
        ttl_sec: float,
        timer: Callable[[], float],
    ) -> None:
        self._max_bytes = max(1, max_bytes)
        self._ttl_sec = float(ttl_sec)
        self._timer = timer
        self._entries: dict[str, tuple[float, dict[str, Any]]] = {}
        self._lru: list[str] = []
        self._total_bytes = 0

    def _expires_at(self) -> float:
        return self._timer() + self._ttl_sec

    def _remove(self, key: str) -> None:
        packed = self._entries.pop(key, None)
        if packed is None:
            return
        _, entry = packed
        self._total_bytes = max(0, self._total_bytes - int(entry.get("size_bytes", 1)))
        if key in self._lru:
            self._lru.remove(key)

    def _touch(self, key: str) -> None:
        if key in self._lru:
            self._lru.remove(key)
        self._lru.append(key)

    def _purge_expired(self) -> None:
        now = self._timer()
        for key in list(self._entries):
            expires_at, _ = self._entries[key]
            if now >= expires_at:
                self._remove(key)

    def _evict_lru(self) -> None:
        while self._lru and self._total_bytes > self._max_bytes:
            self._remove(self._lru[0])

    def get(self, key: str) -> dict[str, Any] | None:
        self._purge_expired()
        packed = self._entries.get(key)
        if packed is None:
            return None
        expires_at, entry = packed
        if self._timer() >= expires_at:
            self._remove(key)
            return None
        self._touch(key)
        return entry

    def set(self, key: str, entry: dict[str, Any]) -> None:
        self._purge_expired()
        if key in self._entries:
            self._remove(key)
        size_bytes = max(1, int(entry.get("size_bytes", 1)))
        while self._total_bytes + size_bytes > self._max_bytes and self._lru:
            self._evict_lru()
        self._entries[key] = (self._expires_at(), entry)
        self._total_bytes += size_bytes
        self._touch(key)


def _build_url_cache_store(
    *,
    max_bytes: int,
    ttl_sec: float,
    timer: Callable[[], float],
) -> _UrlBodyCacheStore:
    try:
        return _CachetoolsUrlCache(max_bytes=max_bytes, ttl_sec=ttl_sec, timer=timer)
    except ImportError:
        return _StdlibUrlCache(max_bytes=max_bytes, ttl_sec=ttl_sec, timer=timer)


class CacheManager:
    """URL 正文缓存：TTL + 字节上限（对齐 CC LRUCache 15min / 50MB）。"""

    def __init__(
        self,
        *,
        ttl_sec: int | None = None,
        max_bytes: int | None = None,
        timer: Callable[[], float] = time.monotonic,
    ) -> None:
        self._timer = timer
        self._ttl_sec = float(ttl_sec if ttl_sec is not None else CACHE_TTL_SEC)
        self._max_bytes = max_bytes if max_bytes is not None else CACHE_MAX_SIZE_BYTES
        self._store = _build_url_cache_store(
            max_bytes=self._max_bytes,
            ttl_sec=self._ttl_sec,
            timer=self._timer,
        )

    def is_enabled(self) -> bool:
        return True

    def monotonic(self) -> float:
        """供 FetchBackend 计耗时（与 TTL timer 同源）。"""
        return float(self._timer())

    def get(self, key: str) -> dict[str, Any] | None:
        return self._store.get(key)

    def set(self, key: str, content: str, metadata: dict[str, Any]) -> None:
        size_bytes = max(1, len(content.encode("utf-8", errors="replace")))
        self._store.set(
            key,
            {
                "content": content,
                "metadata": metadata,
                "size_bytes": size_bytes,
                "ts": self._timer(),
            },
        )


def _persist_binary(content: bytes, content_type: str) -> str:
    base_ct = (content_type or "").split(";")[0].strip()
    ext = mimetypes.guess_extension(base_ct) or ".bin"
    fd, path = tempfile.mkstemp(suffix=ext, prefix="webfetch_bin_")
    try:
        os.write(fd, content)
    finally:
        os.close(fd)
    return path


class FetchBackend:
    """同步 HTTP 抓取与 Markdown 化（主编排）。"""

    def __init__(
        self,
        *,
        html_converter: HtmlConverter | None = None,
        cache: CacheManager | None = None,
        client_factory: Callable[[], httpx.Client] | None = None,
    ) -> None:
        self._html = html_converter or HtmlConverter()
        self._cache = cache or CacheManager()
        self._client_factory = client_factory

    def _build_client(self) -> httpx.Client:
        if self._client_factory is not None:
            return self._client_factory()
        timeout = httpx.Timeout(FETCH_TIMEOUT_SEC)
        return httpx.Client(timeout=timeout, follow_redirects=False)

    def fetch(
        self,
        url: str,
        *,
        on_redirect: Callable[[dict[str, Any]], Any] | None = None,
    ) -> FetchResult:
        _validate_url(url)
        cache_key = url.strip()
        t0 = self._cache.monotonic()

        cached = self._cache.get(cache_key)
        if cached is not None:
            meta = cached.get("metadata", {})
            elapsed_ms = int((self._cache.monotonic() - t0) * 1000)
            return FetchResult(
                url=cache_key,
                final_url=str(meta.get("final_url", cache_key)),
                content=str(cached["content"]),
                byte_count=int(meta.get("byte_count", 0)),
                code=int(meta.get("code", 200)),
                code_text=str(meta.get("code_text", "OK")),
                content_type=str(meta.get("content_type", "")),
                persisted_path=meta.get("persisted_path"),
                from_cache=True,
                duration_ms=max(0, elapsed_ms),
                redirect=None,
            )

        upgraded = _upgrade_to_https(cache_key)
        current = upgraded
        redirect_hops = 0
        started = time.monotonic()

        client = self._build_client()
        own_client = self._client_factory is None
        try:
            while True:
                headers = {
                    "Accept": "text/markdown, text/html, */*",
                    "User-Agent": _DEFAULT_UA,
                }
                with client.stream("GET", current, headers=headers) as resp:
                    if resp.status_code in (301, 302, 303, 307, 308):
                        resp.read()
                        loc = resp.headers.get("location")
                        if not loc:
                            raise RuntimeError("Redirect missing Location header")
                        nxt = urljoin(current, loc)
                        if _is_permitted_redirect(current, nxt):
                            if redirect_hops >= MAX_REDIRECTS:
                                raise TooManyRedirectsError(
                                    f"Too many redirects (exceeded {MAX_REDIRECTS})"
                                )
                            if on_redirect is not None:
                                on_redirect(
                                    {
                                        "from_url": current,
                                        "to_url": nxt,
                                        "status_code": resp.status_code,
                                    }
                                )
                            current = nxt
                            redirect_hops += 1
                            continue

                        elapsed_ms = int((time.monotonic() - started) * 1000)
                        return FetchResult(
                            url=cache_key,
                            final_url=current,
                            content="",
                            byte_count=0,
                            code=resp.status_code,
                            code_text=resp.reason_phrase,
                            content_type=resp.headers.get("content-type", "") or "",
                            persisted_path=None,
                            from_cache=False,
                            duration_ms=elapsed_ms,
                            redirect=RedirectResult(
                                original_url=current,
                                redirect_url=nxt,
                                status_code=resp.status_code,
                                status_text=resp.reason_phrase,
                            ),
                        )

                    if resp.status_code == 403 and resp.headers.get("x-proxy-error") == "blocked-by-allowlist":
                        host = urlparse(current).hostname or ""
                        raise EgressBlockedError(host)

                    resp.raise_for_status()

                    body = b""
                    for chunk in resp.iter_bytes():
                        body += chunk
                        if len(body) > MAX_HTTP_CONTENT_LENGTH:
                            raise RuntimeError(
                                f"response body exceeds MAX_HTTP_CONTENT_LENGTH ({MAX_HTTP_CONTENT_LENGTH})"
                            )

                    ct = resp.headers.get("content-type", "") or ""
                    code = resp.status_code
                    code_text = resp.reason_phrase

                persisted: str | None = None
                if _is_binary_content_type(ct):
                    persisted = _persist_binary(body, ct)

                text = body.decode("utf-8", errors="replace")
                if "text/html" in ct.lower():
                    md_text = self._html.to_markdown(text, content_type=ct)
                else:
                    md_text = text

                meta = {
                    "final_url": current,
                    "byte_count": len(body),
                    "code": code,
                    "code_text": code_text,
                    "content_type": ct,
                    "persisted_path": persisted,
                }
                self._cache.set(cache_key, md_text, meta)
                elapsed_ms = int((time.monotonic() - started) * 1000)
                return FetchResult(
                    url=cache_key,
                    final_url=current,
                    content=md_text,
                    byte_count=len(body),
                    code=code,
                    code_text=code_text,
                    content_type=ct,
                    persisted_path=persisted,
                    from_cache=False,
                    duration_ms=elapsed_ms,
                    redirect=None,
                )
        finally:
            if own_client:
                client.close()
