"""
task_create/tool.py — TaskCreateRuntimeTool

职责：
    创建任务：经 `TaskStoreSync.create_task` 持久化，再执行 taskCreated hooks；
    hooks 返回阻塞错误时调用 `delete_task` 回滚（与 CC TaskCreateTool 同序）。

链路位置：
    ToolExecutorPipeline → TaskCreateRuntimeTool → TaskStoreSync / HookRegistry

当前裁剪范围：
    - 不实现 CC `setAppState` / expandedView（UI）
    - teammate / team 名传入 hooks 为 None（无 CC teammate 集成）
"""

from __future__ import annotations

from typing import Any, Optional, Union

from langchain_agentx.task_runtime.tasklist import TaskCreate as TaskCreatePayload, TaskStoreSync
from langchain_agentx.tool_runtime.base import RuntimeTool
from langchain_agentx.tool_runtime.models import (
    ToolExecutionContext,
    ToolResultEnvelope,
    ValidationResult,
)
from langchain_agentx.workspace import AgentWorkspaceConfig

from .hooks import execute_task_created_hooks
from .models import CreatedTaskRef, TaskCreateInput, TaskCreateOutput
from .prompt import DESCRIPTION, TOOL_NAME


def _as_input(data: Union[TaskCreateInput, dict[str, Any]]) -> TaskCreateInput:
    if isinstance(data, TaskCreateInput):
        return data
    return TaskCreateInput.model_validate(data)


class TaskCreateRuntimeTool(RuntimeTool):
    """任务创建工具（CC TaskCreateTool 对等 v1）。"""

    name: str = TOOL_NAME
    description: str = DESCRIPTION
    input_model = TaskCreateInput
    is_read_only: bool = False
    is_concurrency_safe: bool = True

    def __init__(self, config: Optional[AgentWorkspaceConfig] = None) -> None:
        super().__init__()
        self._store = TaskStoreSync(config=config)

    def validate_input(
        self,
        data: Union[TaskCreateInput, dict[str, Any]],
        ctx: ToolExecutionContext,
    ) -> ValidationResult:
        d = _as_input(data)
        errors: list[str] = []

        if not d.subject.strip():
            errors.append("subject cannot be empty")
        if not d.description.strip():
            errors.append("description cannot be empty")

        blocks = d.blocks or []
        blocked_by = d.blocked_by or []
        for bid in blocks + blocked_by:
            if not str(bid).strip():
                errors.append("dependency task id cannot be empty")
                continue
            if not self._store.task_exists(str(bid).strip()):
                errors.append(f"dependency task does not exist: {bid}")

        if errors:
            return ValidationResult(ok=False, message="\n".join(errors))
        return ValidationResult(ok=True)

    def is_enabled(self, ctx: ToolExecutionContext) -> bool:
        return True

    def invoke(
        self,
        data: Union[TaskCreateInput, dict[str, Any]],
        ctx: ToolExecutionContext,
    ) -> TaskCreateOutput:
        d = _as_input(data)
        blocks = list(d.blocks or [])
        blocked_by = list(d.blocked_by or [])
        metadata = dict(d.metadata or {})

        payload = TaskCreatePayload(
            subject=d.subject.strip(),
            description=d.description.strip(),
            active_form=d.active_form,
            owner=None,
            status="pending",
            blocks=blocks,
            blocked_by=blocked_by,
            metadata=metadata,
        )

        task_id = self._store.create_task(payload)

        blocking = execute_task_created_hooks(
            task_id,
            d.subject.strip(),
            d.description.strip(),
            teammate_name=None,
            team_name=None,
        )

        if blocking:
            self._store.delete_task(task_id)
            return TaskCreateOutput(
                success=False,
                error="\n".join(blocking),
            )

        return TaskCreateOutput(
            success=True,
            task=CreatedTaskRef(id=task_id, subject=d.subject.strip()),
        )

    def present(
        self,
        data: Union[TaskCreateInput, dict[str, Any]],
        result: TaskCreateOutput,
        ctx: ToolExecutionContext,
    ) -> ToolResultEnvelope:
        if not result.success or result.task is None:
            return ToolResultEnvelope(
                status="error",
                tool_name=self.name,
                summary=result.error or "Task creation failed",
                payload={"success": False, "error": result.error},
            )
        t = result.task
        summary = f"Task #{t.id} created successfully: {t.subject}"
        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary=summary,
            payload={
                "success": True,
                "task": {"id": t.id, "subject": t.subject},
            },
        )

    def present_for_display(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> dict[str, Any] | None:
        """out-of-band：任务创建摘要。"""
        _ = data, ctx
        if not isinstance(result, TaskCreateOutput):
            return None
        if not result.success or result.task is None:
            return {"success": False, "error": result.error}
        return {
            "task_id": result.task.id,
            "subject": result.task.subject,
            "success": True,
        }
