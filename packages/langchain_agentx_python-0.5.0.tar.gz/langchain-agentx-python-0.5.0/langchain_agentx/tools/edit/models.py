"""
tools/edit/models.py — EditRuntimeTool 输入 / 输出模型

职责：
    Pydantic 契约；对应 CC FileEditTool types.ts。

链路位置：
    EditRuntimeTool.input_model / output_model；validate_input / invoke 返回值。

当前裁剪范围：
    v2：可选 ``include_diff`` / 输出 ``diff``（unified）。
    v3：``EditToolOutput.git_diff``；``diff`` 在含 diff 时为 **git 优先** 否则 unified。
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class EditToolInput(BaseModel):
    """Edit 工具输入（CC FileEditInput 对齐）。"""

    file_path: str = Field(..., description="Absolute path to the file to edit.")
    old_string: str = Field(..., description="Exact text to replace.")
    new_string: str = Field(..., description="Replacement text (must differ from old_string).")
    replace_all: bool = Field(
        False,
        description="If true, replace every occurrence of old_string.",
    )
    include_diff: bool = Field(
        False,
        description="If true, include a unified diff in tool result meta (v2).",
    )


class EditToolOutput(BaseModel):
    """v1 简化输出。"""

    file_path: str
    old_string: str
    new_string: str
    replaced_count: int
    original_file: str | None = Field(
        None,
        description="File content before replace; None if unavailable.",
    )
    diff: str | None = Field(
        None,
        description=(
            "When include_diff: primary diff text for the model—git diff if available, "
            "else unified old→new; None if include_diff was false or no replacement."
        ),
    )
    git_diff: str | None = Field(
        None,
        description=(
            "v3: git diff (working tree vs HEAD) for the file when generation succeeded; "
            "None if not in a repo, git failed, or no diff output. "
            "May reflect other uncommitted changes on that path, not only this edit."
        ),
    )
