"""
tools/edit — EditRuntimeTool（CC FileEditTool 对齐）

需 ToolStateBridge + 先 Read。
"""
from __future__ import annotations

from .tool import EditRuntimeTool

__all__ = ["EditRuntimeTool"]
