"""
tools/edit/limits.py — EditRuntimeTool 上限配置

职责：
    与 Read 对齐的 stat 前文件大小上限（256KB）；供 validate 使用。

链路位置：
    EditStringValidator、prompt.get_prompt() 数值说明。
"""

from __future__ import annotations

import os

DEFAULT_MAX_FILE_SIZE_BYTES = int(
    os.getenv("EDIT_TOOL_MAX_FILE_SIZE_BYTES", str(256 * 1024))
)
"""与 Read 一致：整文件编辑前 stat 拒绝过大文件。"""


def get_edit_limits() -> dict[str, int]:
    return {
        "max_file_size": DEFAULT_MAX_FILE_SIZE_BYTES,
    }
