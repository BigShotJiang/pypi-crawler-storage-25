"""
tools/edit/validator.py — EditStringValidator

职责：
    ``EditStringValidator``：单次 edit 业务校验（edit-tool-migration §3.4.2）。

链路位置：
    ``EditRuntimeTool.validate_input``。

当前裁剪范围：
    Phase 2：引号由 ``QuoteNormalizer``；非空文件禁止 ``old_string==''`` 的 edit 条。
    v3 Phase 4：``SettingsValidator`` 在 quote / 唯一性之后、staleness 之前；仅单次 ``edit``。
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from langchain_agentx.tool_runtime.models import ToolExecutionContext, ValidationResult

from .backend import apply_edit_to_content
from .limits import get_edit_limits
from .models import EditToolInput
from .quote_normalizer import QuoteNormalizer
from .settings_validator import SettingsValidator


class EditStringValidator:
    """Edit 输入语义校验（与 CC validateInput 核心顺序对齐）。"""

    def __init__(
        self,
        *,
        state_bridge: Any | None = None,
        staleness_checker: Any | None = None,
        quote_normalizer: QuoteNormalizer | None = None,
        settings_validator: SettingsValidator | None = None,
    ) -> None:
        self._state_bridge = state_bridge
        self._staleness_checker = staleness_checker
        self._quote_normalizer = quote_normalizer or QuoteNormalizer()
        self._settings_validator = settings_validator or SettingsValidator()

    def validate(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> ValidationResult:
        try:
            inp = EditToolInput.model_validate(data)
        except Exception as exc:
            return ValidationResult(ok=False, message=str(exc))

        if inp.old_string == inp.new_string:
            return ValidationResult(
                ok=False,
                message="No changes to make: old_string and new_string are the same.",
            )

        fp = inp.file_path
        if not fp or not str(fp).strip():
            return ValidationResult(ok=False, message="file_path cannot be empty")

        if not os.path.isabs(fp):
            return ValidationResult(ok=False, message="file_path must be an absolute path")

        if not os.path.exists(fp):
            return ValidationResult(ok=False, message=f"File does not exist: {fp}")

        if not os.path.isfile(fp):
            return ValidationResult(ok=False, message=f"Not a file: {fp}")

        if self._state_bridge is None:
            return ValidationResult(
                ok=False,
                message="EditRuntimeTool requires ToolStateBridge (session state).",
            )

        if not self._state_bridge.has_been_read(ctx, fp):
            return ValidationResult(
                ok=False,
                message="File has not been read yet. Read it first before writing to it.",
            )

        limits = get_edit_limits()
        try:
            file_size = os.path.getsize(fp)
        except OSError as exc:
            return ValidationResult(ok=False, message=str(exc))

        if file_size > limits["max_file_size"]:
            return ValidationResult(
                ok=False,
                message=(
                    f"File too large ({file_size} bytes, max {limits['max_file_size']} bytes)"
                ),
            )

        if inp.old_string == "":
            if file_size > 0:
                return ValidationResult(
                    ok=False,
                    message="old_string is empty but the file is not empty.",
                )
            if self._settings_validator.is_settings_file(fp):
                sv = self._settings_validator.validate_edit(fp, "", inp.new_string)
                if not sv.ok:
                    return sv
        else:
            try:
                text = Path(fp).read_text(encoding="utf-8")
            except OSError as exc:
                return ValidationResult(ok=False, message=str(exc))

            resolved = self._quote_normalizer.find_actual_old_string_in_text(
                text, inp.old_string
            )
            if resolved is None:
                return ValidationResult(
                    ok=False,
                    message="old_string not found in file.",
                )
            if resolved != inp.old_string:
                data["old_string"] = resolved
                try:
                    inp = EditToolInput.model_validate(data)
                except Exception as exc:
                    return ValidationResult(ok=False, message=str(exc))

            if not inp.replace_all:
                ur = self._check_uniqueness_text(text, inp.old_string)
                if not ur.ok:
                    return ur

            if self._settings_validator.is_settings_file(fp):
                new_content, _ = apply_edit_to_content(
                    text,
                    resolved,
                    inp.new_string,
                    inp.replace_all,
                )
                sv = self._settings_validator.validate_edit(fp, text, new_content)
                if not sv.ok:
                    return sv

        if self._staleness_checker is None:
            return ValidationResult(
                ok=False,
                message="EditRuntimeTool requires StalenessChecker (state_bridge).",
            )
        sr = self._staleness_checker.check(fp, ctx)
        if not sr.ok:
            return sr

        return ValidationResult(ok=True)

    def _check_uniqueness_text(self, text: str, old_string: str) -> ValidationResult:
        matches = len(text.split(old_string)) - 1
        if matches > 1:
            return ValidationResult(
                ok=False,
                message=(
                    f"Found {matches} matches for old_string, but replace_all is false. "
                    "Set replace_all=true or use a longer old_string that matches once."
                ),
            )
        if matches == 0:
            return ValidationResult(ok=False, message="old_string not found in file.")
        return ValidationResult(ok=True)
