"""
tools/user_message/tool.py — UserMessageTool

职责：
    RuntimeTool 生命周期编排：normalize → validate → permissions → invoke → present。

链路位置：
    ToolRuntimeLoader.register_default_tools；create_loop_agent(..., loader=)。

当前裁剪范围：
    v2 Phase 2：可选 ``tool_runtime_config.json`` 经 ``ctx.tool_config_path`` 关闭工具（``check_permissions`` → deny）；
    超长消息在 present 层裁剪（见 user-message-tool-migration.md §3.4.5）。
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from langchain_agentx.tool_runtime.base import RuntimeTool
from langchain_agentx.tool_runtime.models import (
    AuthorizationDecision,
    ToolExecutionContext,
    ToolResultEnvelope,
    ValidationResult,
)

from .attachments import AttachmentResolver, AttachmentValidator
from .models import UserMessageInput, UserMessageOutput
from .prompt import DESCRIPTION, TOOL_NAME
from .runtime_config import UserMessageRuntimeConfig


class UserMessageTool(RuntimeTool):
    """向用户发送可见消息（对齐 CC BriefTool / SendUserMessage）。"""

    name: str = TOOL_NAME
    description: str = DESCRIPTION
    input_model = UserMessageInput
    output_model = UserMessageOutput

    is_read_only: bool = True
    is_destructive: bool = False
    is_concurrency_safe: bool = True
    never_truncate: bool = False
    dedupe_identical_calls: bool = False
    max_result_size_chars: int = 100_000

    def __init__(
        self,
        *,
        policy: Any | None = None,
        state_bridge: Any | None = None,
        attachment_validator: AttachmentValidator | None = None,
        attachment_resolver: AttachmentResolver | None = None,
    ) -> None:
        super().__init__(policy=policy, state_bridge=state_bridge)
        self._validator = attachment_validator or AttachmentValidator()
        self._resolver = attachment_resolver or AttachmentResolver()

    def normalize_input(
        self,
        raw: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> dict[str, Any]:
        """路径展开、默认值；不做存在性校验（设计 §3.4.1）。"""
        data = dict(raw)
        attachments = data.get("attachments")
        if attachments is not None:
            cwd = ctx.cwd
            normalized_attachments: list[str] = []
            for raw_path in attachments:
                path = Path(raw_path).expanduser()
                if not path.is_absolute():
                    if cwd:
                        path = Path(cwd) / path
                normalized_attachments.append(str(path))
            data["attachments"] = normalized_attachments
        if "status" not in data:
            data["status"] = "normal"
        return data

    def validate_input(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> ValidationResult:
        """语义校验（设计 §3.4.2）。"""
        message = (data.get("message") or "").strip()
        if not message:
            return ValidationResult(
                ok=False,
                message="Message content cannot be empty.",
                code="EMPTY_MESSAGE",
            )

        status = data.get("status", "normal")
        if status not in ("normal", "proactive"):
            return ValidationResult(
                ok=False,
                message=(
                    f"Invalid status: {status!r}. Must be 'normal' or 'proactive'."
                ),
                code="INVALID_STATUS",
            )

        attachments = data.get("attachments")
        if attachments:
            cwd_hint = str(ctx.cwd) if ctx.cwd else None
            for attachment_path in attachments:
                result = self._validator.validate(
                    attachment_path,
                    cwd_hint=cwd_hint,
                )
                if not result.ok:
                    return result

        return ValidationResult(ok=True)

    def check_permissions(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        """
        先读 ``ctx.tool_config_path`` 下本地开关（v2 Phase 2）；否则沿用 v1 用户交互兜底（设计 §3.4.3）。
        """
        _ = data
        cfg_path = getattr(ctx, "tool_config_path", None)
        if isinstance(cfg_path, str) and cfg_path.strip():
            rt_cfg = UserMessageRuntimeConfig.load(cfg_path)
            if not rt_cfg.enabled:
                return AuthorizationDecision(
                    behavior="deny",
                    message="User message tool is disabled in tool_runtime_config.json.",
                    policy_id="user_message_disabled",
                )

        decision = super().check_permissions(data, ctx)
        if decision.behavior == "allow":
            return decision
        return AuthorizationDecision(
            behavior="allow",
            message="User interaction tool - always allowed",
        )

    def invoke(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> Any:
        """解析附件元数据并生成时间戳（设计 §3.4.4）。"""
        _ = ctx
        inp = UserMessageInput.model_validate(data)
        resolved_attachments = None
        if inp.attachments:
            resolved_attachments = self._resolver.resolve(inp.attachments)

        sent_at = datetime.now(timezone.utc).isoformat()

        return UserMessageOutput(
            message=inp.message,
            attachments=resolved_attachments,
            sent_at=sent_at,
        )

    def present(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> ToolResultEnvelope:
        """构造 ToolResultEnvelope；模型路径仅回执（payload 空）；完整消息走 present_for_display。"""
        _ = ctx
        if not isinstance(result, UserMessageOutput):
            return super().present(data, result, ctx)

        attachment_count = (
            len(result.attachments) if result.attachments is not None else 0
        )

        # 对齐 CC BriefTool.mapToolResultToToolResultBlockParam：user. + 可选后缀（无句末多余句号）
        if attachment_count > 0:
            word = "attachment" if attachment_count == 1 else "attachments"
            summary = (
                f"Message delivered to user. ({attachment_count} {word} included)"
            )
        else:
            summary = "Message delivered to user."

        message = result.message
        max_size = self.max_result_size_chars
        truncated = len(message) > max_size
        if truncated:
            summary = (
                f"Message delivered to user (truncated: {len(message)} > {max_size} chars)."
            )

        attachments_meta: list[dict[str, Any]] | None = None
        if result.attachments:
            attachments_meta = [a.model_dump() for a in result.attachments]

        meta: dict[str, Any] = {
            "status": data.get("status", "normal"),
            "attachment_count": attachment_count,
            "sent_at": result.sent_at,
            "truncated": truncated,
            "original_length": len(message) if truncated else None,
            "attachments": attachments_meta,
        }

        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary=summary,
            payload="",
            meta=meta,
        )

    def present_for_display(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> dict[str, Any] | None:
        """out-of-band：完整消息 + 附件（对位 CC BriefTool UI）。"""
        _ = data, ctx
        if not isinstance(result, UserMessageOutput):
            return None
        attachments: list[dict[str, Any]] | None = None
        if result.attachments:
            attachments = [a.model_dump() for a in result.attachments]
        return {
            "message": result.message,
            "attachments": attachments,
            "sent_at": result.sent_at,
        }
