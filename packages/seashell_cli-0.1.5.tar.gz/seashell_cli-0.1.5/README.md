# Seashell CLI

Command-line tool for querying and managing genomic data on Seashell.

## Install

```bash
pip install seashell-cli
```

## Quick Start

```bash
seashell
```

You'll be prompted for your API key (from your institution admin), username, and password. After login, you're in an interactive shell. Every example below is typed directly at the `seashell>` prompt — copy any line and paste it.

```
LIST PATIENTS
FIND VARIANTS WHERE patient=NA12878 AND gene=BRCA1
EXPORT PATIENT NA12878 FORMAT CRAM
```

## Single Query Mode

For one-off queries from a shell script, pass the query as a string argument:

```bash
seashell "FIND PATIENTS WHERE gene=BRCA1 AND significance=pathogenic"
seashell "COUNT VARIANTS WHERE patient=NA12878"
seashell --format json "LIST PATIENTS"
```

## Commands

| Command | Description |
|---|---|
| `LIST PATIENTS` | List all patients in your institution |
| `LIST GENES` | List all gene symbols |
| `COUNT VARIANTS WHERE patient=NA12878` | Count a patient's variants (sub-millisecond) |
| `COUNT PATIENTS WHERE gene=BRCA1` | Count patients matching criteria |
| `FIND VARIANTS WHERE patient=NA12878 AND gene=BRCA1` | Variants in a gene for one patient |
| `FIND PATIENTS WHERE gene=BRCA1 AND significance=pathogenic` | Carriers of a variant |
| `FIND SIMILAR TO patient=NA12878` | Genetically similar patients |
| `COMPARE PATIENTS NA12878 AND HG00096` | Jaccard similarity between two patients |
| `DIFF PATIENTS NA12878 AND HG00096` | Exact variant differences |
| `PCA PATIENTS` | Principal component analysis |
| `UPLOAD PATIENT id CRAM s3://path.cram VCF s3://path.vcf.gz` | Upload pre-aligned CRAM/BAM |
| `UPLOAD PATIENT id FASTQ s3://R1.fastq.gz s3://R2.fastq.gz` | Upload raw FASTQ |
| `UPLOAD BATCH s3://manifest.json` | Batch upload from manifest |
| `EXPORT PATIENT id FORMAT CRAM` | Export as CRAM (or BAM) |
| `DELETE PATIENT id` | Remove a patient (admin only) |
| `help` | Show all commands |

## Requirements

- Python 3.8+
- A Seashell API key (contact your institution admin)

## Documentation

https://seashell.bio/docs
