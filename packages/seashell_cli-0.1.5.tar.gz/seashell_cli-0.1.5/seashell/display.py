"""Output formatting for query results."""

import json
import sys


def infer_action(query_text):
    """Infer the action type from a GQL query string."""
    q = query_text.strip().upper()
    if q.startswith("LIST PATIENTS"): return "list_patients"
    if q.startswith("LIST GENES"): return "list_genes"
    if q.startswith("COUNT VARIANTS"): return "count_variants"
    if q.startswith("COUNT PATIENTS"): return "count_patients"
    if q.startswith("FIND VARIANTS"): return "find_variants"
    if q.startswith("FIND PATIENTS"): return "find_patients"
    if q.startswith("FIND SIMILAR"): return "find_similar"
    if q.startswith("COMPARE"): return "compare_patients"
    if q.startswith("DIFF"): return "diff_patients"
    if q.startswith("PCA"): return "pca"
    if q.startswith("COVERAGE"): return "coverage"
    if q.startswith("QC"): return "qc"
    if q.startswith("PILEUP"): return "pileup"
    if q.startswith("DELETE PATIENT"): return "delete_patient"
    return ""


def display_result(result, output_format="table", action=None):
    """Display a query result in the requested format."""
    if "error" in result:
        sys.stderr.write("Error: %s\n" % result["error"])
        return

    if output_format == "json":
        print(json.dumps(result, indent=2))
        return

    if output_format == "tsv":
        _print_tsv(result)
        return

    # Use explicit action if provided, otherwise try to read from result
    if action is None:
        action = result.get("action", "")
    latency = result.get("latency_ms", "?")

    if action == "compare_patients":
        _print_compare(result, latency)
    elif action == "find_similar":
        _print_similar(result, latency)
    elif action in ("list_patients", "find_patients", "count_patients"):
        _print_patients(result, action, latency)
    elif action in ("find_variants", "count_variants"):
        _print_variants(result, action, latency)
    elif action == "list_genes":
        print("\n  %s genes loaded" % result.get("count", "?"))
        print("  %s ms" % latency)
    elif action == "diff_patients":
        _print_diff(result, latency)
    elif action == "pca":
        _print_pca(result, latency)
    elif action == "coverage":
        _print_coverage(result, latency)
    elif action == "qc":
        _print_qc(result, latency)
    elif action == "pileup":
        _print_pileup(result, latency)
    elif action == "delete_patient":
        print("\n  Patient %s deleted." % result.get("patient_id", "?"))
        print("  %s ms" % latency)
    else:
        print(json.dumps(result, indent=2))


def _print_compare(result, latency):
    print("\n  %s vs %s" % (result.get("patient_a", "?"), result.get("patient_b", "?")))
    print("  Jaccard similarity:      %s" % result.get("jaccard_similarity", "?"))
    shared = result.get("shared_variants_estimate", result.get("shared_variants", "?"))
    print("  Shared variants (est):   %s" % shared)
    unique_a = result.get("unique_to_a_estimate", result.get("unique_to_a", "?"))
    unique_b = result.get("unique_to_b_estimate", result.get("unique_to_b", "?"))
    print("  Unique to A (est):       %s" % unique_a)
    print("  Unique to B (est):       %s" % unique_b)
    if result.get("note"):
        print("  Note: %s" % result["note"])
    print("\n  %s ms" % latency)


def _print_similar(result, latency):
    print("\n  Most similar to %s:\n" % result.get("patient", "?"))
    print("  %-15s %10s" % ("PATIENT", "JACCARD"))
    print("  %s %s" % ("-" * 15, "-" * 10))
    for r in result.get("results", []):
        print("  %-15s %10s" % (r["patient_id"], r["jaccard_similarity"]))
    print("\n  %s results | %s ms" % (result.get("count", 0), latency))


def _print_patients(result, action, latency):
    results = result.get("results", [])
    count = result.get("count", 0)
    total = result.get("total", count)

    if action == "count_patients":
        print("\n  %s of %s patients" % (count, total))
        print("  %s ms" % latency)
        return

    if not results:
        print("\n  0 patients found | %s ms" % latency)
        return

    has_variants = "variants" in results[0]
    has_matching = "matching_variants" in results[0]
    has_parent = "parent" in results[0]

    print()
    if has_variants and has_parent:
        print("  %-15s %10s %-15s" % ("PATIENT", "VARIANTS", "PARENT"))
        print("  %s %s %s" % ("-" * 15, "-" * 10, "-" * 15))
        for r in results:
            parent = r.get("parent") or "GRCh38"
            print("  %-15s %10s %-15s" % (r["patient_id"], r["variants"], parent))
    elif has_matching:
        print("  %-15s %10s" % ("PATIENT", "MATCHING"))
        print("  %s %s" % ("-" * 15, "-" * 10))
        for r in results:
            print("  %-15s %10s" % (r["patient_id"], r["matching_variants"]))
    else:
        print("  %-15s" % "PATIENT")
        print("  %s" % ("-" * 15))
        for r in results:
            print("  %-15s" % r["patient_id"])

    print("\n  %s patients | %s ms" % (count, latency))


def _print_variants(result, action, latency):
    results = result.get("results", [])
    count = result.get("count", 0)

    if action == "count_variants":
        print("\n  %s variants" % count)
        print("  %s ms" % latency)
        return

    if not results:
        print("\n  0 variants found | %s ms" % latency)
        return

    has_sig = any("significance" in r for r in results)
    has_gene = any("gene" in r for r in results)
    has_rs = any("rs_id" in r for r in results)

    print()
    header = "  %-8s %12s %-6s %-6s" % ("CHROM", "POS", "REF", "ALT")
    if has_gene:
        header += " %-12s" % "GENE"
    if has_sig:
        header += " %-20s" % "SIGNIFICANCE"
    if has_rs:
        header += " %-15s" % "RS_ID"
    print(header)
    print("  %s" % ("-" * (len(header) - 2)))

    for r in results:
        line = "  %-8s %12s %-6s %-6s" % (
            r.get("chrom", ""), r.get("pos", 0), r.get("ref", ""), r.get("alt", ""))
        if has_gene:
            line += " %-12s" % r.get("gene", "")
        if has_sig:
            line += " %-20s" % r.get("significance", "")
        if has_rs:
            line += " %-15s" % r.get("rs_id", "")
        print(line)

    print("\n  %s variants | %s ms" % (count, latency))


def _print_diff(result, latency):
    a = result.get("patient_a", "?")
    b = result.get("patient_b", "?")
    shared_count = result.get("shared_count", 0)
    unique_a_count = result.get("unique_to_a_count", 0)
    unique_b_count = result.get("unique_to_b_count", 0)
    truncated = result.get("truncated", False)

    print("\n  %s vs %s" % (a, b))
    print("  %s %12s variants" % ("Only in " + a + ":", "{:,}".format(unique_a_count)))
    print("  %s %12s variants" % ("Only in " + b + ":", "{:,}".format(unique_b_count)))
    print("  %s %12s variants" % ("Shared:" + " " * (len(a) + len(b) - 1), "{:,}".format(shared_count)))

    # Show a SAMPLE of shared variants — first PAGE_SIZE entries.
    # Rest is cached and accessed via `more` command.
    shared_sample = result.get("shared", [])
    if shared_sample:
        page_size = 25
        total_in_response = len(shared_sample)
        first_page = shared_sample[:page_size]
        print("\n  Shared variants (showing %d of %s):" % (
            len(first_page), "{:,}".format(shared_count)))
        _print_variant_table(first_page)
        remaining_in_cache = total_in_response - page_size
        if remaining_in_cache > 0:
            print('\n  Type "more" to see all')
        elif truncated:
            print('\n  Add LIMIT N to your query (e.g., LIMIT 1000) to see more.')

    print("\n  %s ms" % latency)


def _truncate(s, n):
    """Truncate a string to n chars with ellipsis."""
    if not isinstance(s, str):
        return str(s)
    if len(s) <= n:
        return s
    return s[:n - 1] + "…"


def _print_variant_table(rows):
    """Print a list of variant dicts as a table."""
    header = "  %-8s %12s %-6s %-6s %-12s" % ("CHROM", "POS", "REF", "ALT", "GENE")
    print(header)
    print("  %s" % ("-" * (len(header) - 2)))
    for r in rows:
        line = "  %-8s %12s %-6s %-6s %-12s" % (
            r.get("chrom", ""), r.get("pos", 0),
            _truncate(r.get("ref", ""), 6),
            _truncate(r.get("alt", ""), 6),
            r.get("gene", "—"))
        print(line)


def show_more(result, action, offset, page_size=25):
    """Show the next page of results from a cached query result.

    Returns the new offset after printing, or None if there's nothing more.
    """
    # Pick the right list field based on the action
    if action in ("find_variants", "count_variants"):
        items = result.get("results", [])
        total = result.get("count", len(items))
        label = "variants"
    elif action in ("list_patients", "find_patients", "count_patients"):
        items = result.get("results", [])
        total = result.get("count", len(items))
        label = "patients"
    elif action == "diff_patients":
        items = result.get("shared", [])
        total = result.get("shared_count", len(items))
        label = "shared variants"
    elif action == "find_similar":
        items = result.get("results", [])
        total = result.get("count", len(items))
        label = "matches"
    else:
        print("  No more results to show for this query type.")
        return None

    if offset >= len(items):
        if total > len(items):
            print("  No more cached results. The engine returned %d of %s %s — "
                  "use LIMIT to fetch more." % (len(items), "{:,}".format(total), label))
        else:
            print("  No more results.")
        return None

    end = min(offset + page_size, len(items))
    page = items[offset:end]

    print("\n  Showing %d-%d of %s %s:" % (offset + 1, end, "{:,}".format(total), label))

    if action == "diff_patients" or action in ("find_variants", "count_variants"):
        _print_variant_table(page)
    elif action in ("list_patients", "find_patients", "count_patients"):
        _print_patient_rows(page)
    elif action == "find_similar":
        for r in page:
            print("  %-15s %10s" % (r.get("patient_id", ""), r.get("jaccard_similarity", "")))

    remaining = len(items) - end
    if remaining > 0:
        print('\n  Type "more" to see all')
    elif total > len(items):
        print("\n  End of cached results. Add LIMIT N to your query to see more.")
    else:
        print("\n  End of results.")
    return end


def _print_patient_rows(rows):
    """Print patient rows in a table."""
    if not rows:
        return
    has_variants = "variants" in rows[0]
    has_parent = "parent" in rows[0]
    has_matching = "matching_variants" in rows[0]
    if has_variants and has_parent:
        print("  %-15s %10s %-15s" % ("PATIENT", "VARIANTS", "PARENT"))
        print("  %s %s %s" % ("-" * 15, "-" * 10, "-" * 15))
        for r in rows:
            parent = r.get("parent") or "GRCh38"
            print("  %-15s %10s %-15s" % (r["patient_id"], r["variants"], parent))
    elif has_matching:
        print("  %-15s %10s" % ("PATIENT", "MATCHING"))
        print("  %s %s" % ("-" * 15, "-" * 10))
        for r in rows:
            print("  %-15s %10s" % (r["patient_id"], r["matching_variants"]))
    else:
        print("  %-15s" % "PATIENT")
        print("  %s" % ("-" * 15))
        for r in rows:
            print("  %-15s" % r["patient_id"])


def _print_pca(result, latency):
    n_components = result.get("components", 3)
    results = result.get("results", [])
    n_patients = result.get("count", len(results))

    print("\n  PCA (%s components, %s patients)\n" % (n_components, n_patients))
    print("  %-15s %12s %12s %12s" % ("PATIENT", "PC1", "PC2", "PC3"))
    print("  %s %s %s %s" % ("-" * 15, "-" * 12, "-" * 12, "-" * 12))
    for r in results:
        pc1 = r.get("pc1", "")
        pc2 = r.get("pc2", "")
        pc3 = r.get("pc3", "")
        print("  %-15s %12s %12s %12s" % (r.get("patient_id", ""), pc1, pc2, pc3))

    var_explained = result.get("variance_explained", [])
    if var_explained:
        print("\n  Variance explained:")
        for i, v in enumerate(var_explained):
            print("    PC%d: %s" % (i + 1, v))

    print("\n  %s ms" % latency)


def _fmt_int(n):
    try:
        return "{:,}".format(int(n))
    except (TypeError, ValueError):
        return str(n)


def _print_coverage(result, latency):
    print()
    chrom = result.get("chrom", "?")
    rs = result.get("region_start", "?")
    re_ = result.get("region_end", "?")
    print("  Patient:        %s" % result.get("patient_id", "?"))
    print("  Region:         %s:%s-%s  (%s bp)" % (chrom, rs, re_, _fmt_int(result.get("region_length", "?"))))
    print("  Mean coverage:  %sx  (covered positions only)" % result.get("mean_coverage", "?"))
    print("  Mean coverage:  %sx  (entire region, includes 0x)" % result.get("mean_coverage_region", "?"))
    print("  Min / Max:      %sx / %sx" % (result.get("min_coverage", "?"), result.get("max_coverage", "?")))
    print("  Above 10x:      %s%%" % result.get("pct_above_10x", "?"))
    print("  Above 20x:      %s%%" % result.get("pct_above_20x", "?"))
    print("  Above 30x:      %s%%" % result.get("pct_above_30x", "?"))
    print("  Below 10x:      %s positions" % _fmt_int(result.get("positions_below_10x", "?")))
    print("  Covered:        %s positions" % _fmt_int(result.get("covered_positions", "?")))
    print("\n  %s ms" % latency)


def _print_qc(result, latency):
    print()
    total = result.get("total_reads", 0) or 0
    mapped = result.get("mapped_reads", 0) or 0
    pct_mapped = (100.0 * mapped / total) if total else 0.0
    print("  Patient:           %s" % result.get("patient_id", "?"))
    print("  Chromosome:        %s" % result.get("chrom", "?"))
    print("  Total reads:       %s" % _fmt_int(total))
    print("  Mapped:            %s  (%.1f%%)" % (_fmt_int(mapped), pct_mapped))
    print("  Unmapped:          %s" % _fmt_int(result.get("unmapped_reads", 0)))
    print("  Duplicates:        %s  (%.2f%%)" % (
        _fmt_int(result.get("duplicate_reads", 0)),
        (result.get("duplicate_rate", 0) or 0) * 100))
    print("  Secondary:         %s" % _fmt_int(result.get("secondary_reads", 0)))
    print("  Supplementary:     %s" % _fmt_int(result.get("supplementary_reads", 0)))
    print("  Properly paired:   %s  (%s%%)" % (
        _fmt_int(result.get("properly_paired", 0)),
        result.get("properly_paired_pct", "?")))
    print("  Mean MAPQ:         %s" % result.get("mean_mapping_quality", "?"))
    print("  Mean insert size:  %s ± %s" % (
        result.get("mean_insert_size", "?"),
        result.get("insert_size_std", "?")))
    print("\n  %s ms" % latency)


def _print_pileup(result, latency):
    print()
    print("  Patient:    %s" % result.get("patient_id", "?"))
    print("  Position:   %s:%s" % (result.get("chrom", "?"), result.get("position", "?")))
    print("  Ref base:   %s" % result.get("reference_base", "?"))
    print("  Depth:      %s" % result.get("depth", "?"))
    base_counts = result.get("base_counts", {}) or {}
    mean_q = result.get("mean_quality_per_base", {}) or {}
    if base_counts:
        depth = result.get("depth", 0) or 0
        print("  Base counts:")
        print("    Base   Count    Pct    Mean Q")
        for base in sorted(base_counts.keys(), key=lambda b: -base_counts[b]):
            count = base_counts[base]
            pct = (100.0 * count / depth) if depth else 0.0
            q = mean_q.get(base, 0)
            print("    %-4s   %5s   %5.1f%%   %s" % (base, _fmt_int(count), pct, q))
    print("\n  %s ms" % latency)


def _print_tsv(result):
    results = result.get("results", [])
    if not results:
        return
    keys = list(results[0].keys())
    print("\t".join(keys))
    for r in results:
        print("\t".join(str(r.get(k, "")) for k in keys))


def print_job_progress(job):
    """Print progress for async jobs (upload/export)."""
    status = job.get("status", "?")
    completed = job.get("patients_completed", 0)
    total = job.get("patients_total", job.get("num_patients", "?"))
    errors = len(job.get("errors", []))

    line = "\r  Progress: %s/%s" % (completed, total)
    if errors:
        line += " (%s errors)" % errors
    if status in ("complete", "complete_with_errors"):
        line += " - Done"
    sys.stdout.write(line)
    sys.stdout.flush()

    if status in ("complete", "complete_with_errors"):
        print()  # newline after progress
        if job.get("errors"):
            for err in job["errors"]:
                sys.stderr.write("  Error: %s — %s\n" % (
                    err.get("patient_id", "?"), err.get("error", "?")))
