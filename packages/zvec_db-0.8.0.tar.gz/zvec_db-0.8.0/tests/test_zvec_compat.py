"""Tests for reranker classes in zvec_db.rerankers."""

from unittest.mock import MagicMock, patch

from zvec.model.doc import Doc
from zvec.typing import MetricType

from zvec_db.rerankers import (
    ClassificationReranker,
    MultiFieldWeightedReranker,
    OpenAIDecoderReranker,
    PipelineReranker,
    RrfReranker,
    SentenceTransformerReranker,
    WeightedReranker,
)

# =============================================================================
# Score Fusion Tests
# =============================================================================


class TestRrfReranker:
    """Tests for RrfReranker."""

    def test_init_default_params(self):
        """Test initialization with default parameters."""
        reranker = RrfReranker()
        assert reranker.topn == 10
        assert reranker.rank_constant == 60

    def test_init_custom_params(self):
        """Test initialization with custom parameters."""
        reranker = RrfReranker(
            topn=20,
            rank_constant=40,
            weights={"source": 0.5},
        )
        assert reranker.topn == 20
        assert reranker.rank_constant == 40
        assert reranker.weights == {"source": 0.5}

    def test_rerank_basic(self):
        """Test basic reranking with multiple sources."""
        reranker = RrfReranker(topn=5)
        docs_a = [Doc(id="1", score=0.9), Doc(id="2", score=0.8)]
        docs_b = [Doc(id="1", score=0.85), Doc(id="3", score=0.7)]

        result = reranker.rerank({"a": docs_a, "b": docs_b})

        assert isinstance(result, list)
        assert len(result) <= 5
        assert all(isinstance(doc, Doc) for doc in result)

    def test_rerank_empty_results(self):
        """Test reranking with empty results."""
        reranker = RrfReranker()
        result = reranker.rerank({})
        assert result == []

    def test_rerank_single_source(self):
        """Test reranking with single source."""
        reranker = RrfReranker()
        docs = [Doc(id="1", score=0.9), Doc(id="2", score=0.8)]
        result = reranker.rerank({"source": docs})
        assert len(result) == 2


class TestWeightedReranker:
    """Tests for WeightedReranker."""

    def test_init_default_params(self):
        """Test initialization with default parameters."""
        reranker = WeightedReranker(metrics=MetricType.IP)
        assert reranker.topn == 10

    def test_init_custom_weights(self):
        """Test initialization with custom weights."""
        reranker = WeightedReranker(
            weights={"bm25": 0.4, "dense": 0.6}, metrics=MetricType.IP
        )
        assert reranker._weights == {"bm25": 0.4, "dense": 0.6}

    def test_rerank_basic(self):
        """Test basic weighted reranking."""
        reranker = WeightedReranker(
            weights={"a": 0.5, "b": 0.5},
            normalize={"a": "bayes", "b": "bayes"},
            metrics=MetricType.IP,
        )
        docs_a = [Doc(id="1", score=0.9), Doc(id="2", score=0.8)]
        docs_b = [Doc(id="1", score=0.85), Doc(id="3", score=0.7)]

        result = reranker.rerank({"a": docs_a, "b": docs_b})

        assert isinstance(result, list)
        assert len(result) <= 3

    def test_rerank_with_metrics(self):
        """Test reranking with metrics parameter."""
        reranker = WeightedReranker(metrics=MetricType.COSINE, normalize={"a": "bayes"})
        docs_a = [Doc(id="1", score=0.9)]
        result = reranker.rerank({"a": docs_a})
        assert isinstance(result, list)


class TestMultiFieldWeightedReranker:
    """Tests for MultiFieldWeightedReranker."""

    def test_init_default_params(self):
        """Test initialization with default parameters."""
        reranker = MultiFieldWeightedReranker(metrics=MetricType.IP)
        assert reranker.topn == 10

    def test_init_custom_weights(self):
        """Test initialization with custom source and field weights."""
        reranker = MultiFieldWeightedReranker(
            weights={"bm25": 0.6, "dense": 0.4},
            field_weights={"title": 2.0, "content": 1.0},
            metrics=MetricType.IP,
        )
        assert reranker._weights == {"bm25": 0.6, "dense": 0.4}

    def test_rerank_with_field_weights(self):
        """Test reranking with field weights."""
        reranker = MultiFieldWeightedReranker(
            weights={"a": 1.0},
            field_weights={"title": 2.0, "content": 1.0},
            metrics=MetricType.IP,
        )
        docs = [
            Doc(id="1", score=0.9, fields={"title": 0.8, "content": 0.5}),
            Doc(id="2", score=0.8, fields={"title": 0.6, "content": 0.7}),
        ]

        result = reranker.rerank({"a": docs})

        assert isinstance(result, list)


# =============================================================================
# Cross-Encoder Tests
# =============================================================================


class TestOpenAIDecoderReranker:
    """Tests for OpenAIDecoderReranker."""

    def test_init_default_params(self):
        """Test initialization with default parameters."""
        reranker = OpenAIDecoderReranker(query="test")
        assert reranker.topn == 10
        assert reranker.query == "test"
        assert reranker.model == "gpt-4o-mini"

    def test_init_custom_params(self):
        """Test initialization with custom parameters."""
        reranker = OpenAIDecoderReranker(
            topn=5,
            model="gpt-4o",
            base_url="http://localhost:8000/v1",
            query="custom query",
        )
        assert reranker.topn == 5
        assert reranker.model == "gpt-4o"
        assert reranker.query == "custom query"

    @patch(
        "zvec_db.rerankers.cross_encoder.openai_decoder.OpenAIDecoderReranker._compute_scores_batch"
    )
    def test_rerank_passes_query(self, mock_compute_scores):
        """Test that rerank passes query to underlying reranker."""
        mock_compute_scores.return_value = [0.9]

        reranker = OpenAIDecoderReranker(topn=5, query="test query")
        docs = [Doc(id="1", score=0.9, fields={"content": "test doc"})]

        # Should not raise - query is stored internally
        result = reranker.rerank({"source": docs})
        assert isinstance(result, list)
        # Verify the underlying reranker was called
        mock_compute_scores.assert_called_once()


class TestSentenceTransformerReranker:
    """Tests for SentenceTransformerReranker."""

    def test_init_default_params(self):
        """Test initialization with default parameters."""
        reranker = SentenceTransformerReranker(query="test")
        assert reranker.topn == 10
        assert reranker._query == "test"
        assert reranker._model_name == "cross-encoder/ms-marco-MiniLM-L-6-v2"

    def test_init_custom_model(self):
        """Test initialization with custom model."""
        reranker = SentenceTransformerReranker(
            model_name="cross-encoder/ms-marco-TinyBERT-L-2-v2",
            device="cpu",
            query="test query",
        )
        assert reranker._model_name == "cross-encoder/ms-marco-TinyBERT-L-2-v2"
        assert reranker._device == "cpu"

    @patch("sentence_transformers.CrossEncoder")
    def test_rerank_passes_query(self, mock_cross_encoder):
        """Test that rerank passes query to underlying reranker."""
        mock_model = MagicMock()
        mock_model.predict.return_value = [0.9]
        mock_cross_encoder.return_value = mock_model

        reranker = SentenceTransformerReranker(query="test query")
        docs = [Doc(id="1", score=0.9, fields={"content": "test doc"})]

        result = reranker.rerank({"source": docs})
        assert isinstance(result, list)


class TestClassificationReranker:
    """Tests for ClassificationReranker."""

    def test_init_default_params(self):
        """Test initialization with default parameters."""
        reranker = ClassificationReranker(query="test")
        assert reranker.topn == 10
        assert reranker._query == "test"
        assert reranker.num_classes is None  # Auto-infer from model

    def test_init_custom_num_classes(self):
        """Test initialization with custom num_classes."""
        reranker = ClassificationReranker(num_classes=3, query="test")
        assert reranker.num_classes == 3

    @patch("transformers.AutoConfig")
    @patch("transformers.AutoModelForSequenceClassification")
    @patch("transformers.AutoTokenizer")
    def test_rerank_passes_query(self, mock_tokenizer, mock_model_class, mock_config):
        """Test that rerank passes query to underlying reranker."""
        import torch

        # Mock config
        mock_config_instance = MagicMock()
        mock_config_instance.num_labels = 3
        mock_config.from_pretrained.return_value = mock_config_instance

        # Mock tokenizer
        mock_tokenizer_instance = MagicMock()
        mock_tokenizer_instance.return_value = {
            "input_ids": torch.tensor([[1, 2, 3]]),
            "attention_mask": torch.tensor([[1, 1, 1]]),
        }
        mock_tokenizer.from_pretrained.return_value = mock_tokenizer_instance

        # Mock model
        mock_model_instance = MagicMock()
        mock_model_instance.device = "cpu"
        mock_model_instance.eval.return_value = mock_model_instance
        # Mock logits for 3 classes
        mock_model_instance.return_value.logits = torch.tensor([[0.1, 0.3, 0.6]])
        mock_model_class.from_pretrained.return_value = mock_model_instance

        reranker = ClassificationReranker(
            num_classes=3,
            query="test query",
        )
        docs = [Doc(id="1", score=0.9, fields={"content": "test doc"})]

        result = reranker.rerank({"source": docs})
        assert isinstance(result, list)


# =============================================================================
# Pipeline Reranker Tests
# =============================================================================


class TestPipelineReranker:
    """Tests for PipelineReranker."""

    def test_init_single_reranker(self):
        """Test pipeline with single reranker."""
        pipeline = PipelineReranker(rerankers=[RrfReranker()])
        assert len(pipeline._rerankers) == 1

    def test_init_multiple_rerankers(self):
        """Test pipeline with multiple rerankers."""
        pipeline = PipelineReranker(
            rerankers=[
                RrfReranker(topn=50),
                WeightedReranker(weights={"pipeline": 1.0}, metrics=MetricType.IP),
            ]
        )
        assert len(pipeline._rerankers) == 2

    def test_pipeline_two_stage_fusion(self):
        """Test two-stage pipeline with fusion rerankers."""
        pipeline = PipelineReranker(
            rerankers=[
                RrfReranker(topn=5),
                WeightedReranker(
                    weights={"pipeline": 1.0}, topn=3, metrics=MetricType.IP
                ),
            ]
        )

        docs_a = [Doc(id="1", score=0.9), Doc(id="2", score=0.8)]
        docs_b = [Doc(id="1", score=0.85), Doc(id="3", score=0.7)]

        result = pipeline.rerank({"a": docs_a, "b": docs_b})

        assert isinstance(result, list)
        assert len(result) <= 3

    def test_pipeline_three_stage(self):
        """Test three-stage pipeline."""
        pipeline = PipelineReranker(
            rerankers=[
                RrfReranker(topn=10),
                WeightedReranker(
                    weights={"pipeline": 1.0}, topn=5, metrics=MetricType.IP
                ),
                WeightedReranker(
                    weights={"pipeline": 1.0}, topn=3, metrics=MetricType.IP
                ),
            ]
        )

        docs = [
            Doc(id="1", score=0.9, vectors={"embedding": [0.1, 0.2]}),
            Doc(id="2", score=0.8, vectors={"embedding": [0.3, 0.4]}),
            Doc(id="3", score=0.7, vectors={"embedding": [0.5, 0.6]}),
        ]

        result = pipeline.rerank({"source": docs})

        assert isinstance(result, list)
        assert len(result) <= 3

    @patch(
        "zvec_db.rerankers.cross_encoder.openai_decoder.OpenAIDecoderReranker._compute_scores_batch"
    )
    def test_pipeline_with_cross_encoder(self, mock_compute_scores):
        """Test pipeline with cross-encoder (mocked)."""
        mock_compute_scores.return_value = [0.9]

        pipeline = PipelineReranker(
            rerankers=[
                RrfReranker(topn=5),
                OpenAIDecoderReranker(topn=3, query="test query"),
            ]
        )

        docs_a = [Doc(id="1", score=0.9, fields={"content": "doc1"})]
        docs_b = [Doc(id="2", score=0.8, fields={"content": "doc2"})]

        result = pipeline.rerank({"a": docs_a, "b": docs_b})
        assert isinstance(result, list)

    def test_pipeline_returns_list(self):
        """Test that pipeline always returns a list, not a dict."""
        pipeline = PipelineReranker(
            rerankers=[
                RrfReranker(topn=5),
                WeightedReranker(weights={"pipeline": 1.0}, metrics=MetricType.IP),
            ]
        )

        docs = [Doc(id="1", score=0.9)]
        result = pipeline.rerank({"source": docs})

        assert isinstance(result, list)
        assert not isinstance(result, dict)

    def test_pipeline_empty_input(self):
        """Test pipeline with empty input."""
        pipeline = PipelineReranker(rerankers=[RrfReranker()])

        result = pipeline.rerank({})
        assert result == []

    def test_pipeline_custom_topn(self):
        """Test pipeline with custom topn parameter."""
        pipeline = PipelineReranker(
            rerankers=[
                RrfReranker(topn=100),
                WeightedReranker(weights={"pipeline": 1.0}, metrics=MetricType.IP),
            ],
            topn=5,
        )
        assert pipeline.topn == 5


# =============================================================================
# Integration Tests
# =============================================================================


class TestIntegration:
    """Integration tests for rerankers."""

    def test_rrf_then_weighted(self):
        """Test RRF followed by weighted reranking."""
        pipeline = PipelineReranker(
            rerankers=[
                RrfReranker(topn=10, rank_constant=60),
                WeightedReranker(
                    weights={"pipeline": 1.0},
                    normalize={"pipeline": "bayes"},
                    metrics=MetricType.IP,
                ),
            ]
        )

        docs_a = [Doc(id=str(i), score=1.0 - i * 0.1) for i in range(10)]
        docs_b = [Doc(id=str(i), score=0.95 - i * 0.1) for i in range(10)]

        result = pipeline.rerank({"a": docs_a, "b": docs_b})
        assert isinstance(result, list)
        assert len(result) <= 10

    def test_fusion_then_weighted(self):
        """Test fusion followed by weighted reranking."""
        pipeline = PipelineReranker(
            rerankers=[
                WeightedReranker(
                    weights={"a": 0.5, "b": 0.5}, topn=20, metrics=MetricType.IP
                ),
                WeightedReranker(
                    weights={"pipeline": 1.0},
                    normalize={"pipeline": "bayes"},
                    metrics=MetricType.IP,
                    topn=10,
                ),
            ]
        )

        docs_a = [
            Doc(
                id=str(i),
                score=1.0 - i * 0.05,
                vectors={"embedding": [float(i), float(i + 1)]},
            )
            for i in range(10)
        ]
        docs_b = [
            Doc(
                id=str(i + 10),
                score=0.9 - i * 0.05,
                vectors={"embedding": [float(i + 5), float(i + 6)]},
            )
            for i in range(10)
        ]

        result = pipeline.rerank({"a": docs_a, "b": docs_b})
        assert isinstance(result, list)
        assert len(result) <= 10
