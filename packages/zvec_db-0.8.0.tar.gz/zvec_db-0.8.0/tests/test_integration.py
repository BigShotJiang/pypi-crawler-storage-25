"""Integration tests for zvec-db package.

These tests verify that the different components work together correctly
in realistic usage scenarios.
"""

from zvec.model.doc import Doc
from zvec.typing import MetricType

from zvec_db.embedders import BM25Embedder, CountEmbedder, TfidfEmbedder
from zvec_db.rerankers import (
    Normalize,
    RrfReranker,
    WeightedReranker,
)


class TestSparseEmbeddingPipeline:
    """Test complete sparse embedding pipelines."""

    def test_bm25_full_pipeline(self, sample_documents):
        """Test BM25 from training to embedding."""
        # Train
        embedder = BM25Embedder(max_features=1024)
        embedder.fit(sample_documents)

        # Embed single query
        query = "brown fox"
        query_vector = embedder.embed(query)

        assert isinstance(query_vector, dict)
        assert len(query_vector) > 0

        # Embed batch
        queries = ["brown fox", "lazy dog", "quick animal"]
        query_vectors = embedder.embed(queries)

        assert isinstance(query_vectors, list)
        assert len(query_vectors) == 3
        assert all(len(v) > 0 for v in query_vectors)

    def test_tfidf_with_similarity_search(self, sample_documents):
        """Test TF-IDF with simple similarity search."""
        # Train on documents
        embedder = TfidfEmbedder(max_features=1024)
        embedder.fit(sample_documents)

        # Create document vectors
        doc_vectors = embedder.embed(sample_documents)

        # Create query vector
        query = "brown fox"
        query_vector = embedder.embed(query)

        # Simple cosine similarity search
        def cosine_sim(v1, v2):
            # Get all indices
            all_indices = set(v1.keys()) | set(v2.keys())
            dot_product = sum(v1.get(i, 0) * v2.get(i, 0) for i in all_indices)
            norm1 = sum(v**2 for v in v1.values()) ** 0.5
            norm2 = sum(v**2 for v in v2.values()) ** 0.5
            if norm1 == 0 or norm2 == 0:
                return 0.0
            return dot_product / (norm1 * norm2)

        # Rank documents by similarity
        scores = [cosine_sim(query_vector, dv) for dv in doc_vectors]
        ranked = sorted(zip(range(len(scores)), scores), key=lambda x: -x[1])

        assert len(ranked) == len(sample_documents)
        # Top result should have positive score
        assert ranked[0][1] > 0

    def test_count_embedder_save_load_roundtrip(self, sample_documents, tmp_path):
        """Test that saved and loaded CountEmbedder produce identical results."""
        # Train original embedder
        original = CountEmbedder(max_features=512)
        original.fit(sample_documents)
        original_result = original.embed("test query")

        # Save
        model_path = tmp_path / "count_model.joblib"
        original.save(str(model_path))

        # Load
        loaded = CountEmbedder()
        loaded.load(str(model_path))
        loaded_result = loaded.embed("test query")

        # Verify identical results
        assert original_result == loaded_result

    def test_bm25_save_load_roundtrip(self, sample_documents, tmp_path):
        """Test that saved and loaded BM25Embedder produce identical results."""
        original = BM25Embedder(k1=1.5, b=0.8, max_features=512)
        original.fit(sample_documents)
        original_result = original.embed("test query")

        model_path = tmp_path / "bm25_model.joblib"
        original.save(str(model_path))

        loaded = BM25Embedder()
        loaded.load(str(model_path))
        loaded_result = loaded.embed("test query")

        assert original_result == loaded_result


class TestRerankerIntegration:
    """Test reranker integration with realistic scenarios."""

    def test_rrf_with_multiple_sources(self):
        """Test RRF combining BM25 and dense retrieval results."""
        # Simulate results from two different retrieval systems
        bm25_docs = [Doc(id=f"doc_{i}", score=float(100 - i * 5)) for i in range(20)]
        dense_docs = [
            Doc(id=f"doc_{i}", score=float(0.95 - i * 0.02)) for i in range(20)
        ]

        # Add some overlapping documents
        dense_docs[0] = Doc(id="doc_0", score=0.99)  # Same as top BM25
        dense_docs[5] = Doc(id="doc_5", score=0.85)  # Same as BM25 doc_5

        query_results = {"bm25": bm25_docs, "dense": dense_docs}

        reranker = RrfReranker(topn=10)
        result = reranker.rerank(query_results)

        assert len(result) == 10
        # All results should have positive scores
        assert all(doc.score > 0 for doc in result)

    def test_weighted_rerank_with_custom_weights(self):
        """Test weighted reranking emphasizing one source."""
        bm25_docs = [Doc(id=f"bm25_{i}", score=float(50 - i)) for i in range(10)]
        dense_docs = [
            Doc(id=f"dense_{i}", score=float(0.9 - i * 0.05)) for i in range(10)
        ]

        query_results = {"bm25": bm25_docs, "dense": dense_docs}

        # Heavy weight on BM25
        reranker_bm25 = WeightedReranker(
            topn=5, weights={"bm25": 0.9, "dense": 0.1}, metrics=MetricType.IP
        )
        result_bm25 = reranker_bm25.rerank(query_results)

        # Heavy weight on dense
        reranker_dense = WeightedReranker(
            topn=5, weights={"bm25": 0.1, "dense": 0.9}, metrics=MetricType.IP
        )
        result_dense = reranker_dense.rerank(query_results)

        assert len(result_bm25) == 5
        assert len(result_dense) == 5

    def test_bayesian_normalization_for_outliers(self):
        """Test that Bayesian normalization handles score outliers."""
        # Create scores with extreme outliers
        bm25_docs = [
            Doc(id="outlier", score=1000.0),  # Extreme outlier
            *[Doc(id=f"doc_{i}", score=float(10 - i)) for i in range(10)],
        ]

        query_results = {"bm25": bm25_docs}

        # Standard normalization (metrics=MetricType.IP for BM25 scores)
        reranker_std = WeightedReranker(
            topn=5,
            metrics=MetricType.IP,  # BM25 scores are not distances
            normalize=True,  # Default/standard
        )
        result_std = reranker_std.rerank(query_results)

        # Bayesian normalization (metrics=MetricType.IP for BM25 scores)
        reranker_bayes = WeightedReranker(
            topn=5,
            metrics=MetricType.IP,  # BM25 scores are not distances
            normalize={"bm25": "bayes"},
        )
        result_bayes = reranker_bayes.rerank(query_results)

        assert len(result_std) == 5
        assert len(result_bayes) == 5

    def test_empty_and_edge_cases(self):
        """Test reranker with empty and edge case inputs."""
        reranker = RrfReranker(topn=5)

        # Empty results
        result = reranker.rerank({"bm25": [], "dense": []})
        assert len(result) == 0

        # Single source empty
        result = reranker.rerank({"bm25": [], "dense": [Doc(id="1", score=0.5)]})
        assert len(result) == 1

        # Single document per source
        result = reranker.rerank(
            {"bm25": [Doc(id="1", score=1.0)], "dense": [Doc(id="1", score=0.9)]}
        )
        assert len(result) == 1


class TestCombinedPipeline:
    """Test complete pipeline: embedding + retrieval + reranking."""

    def test_hybrid_search_pipeline(self, sample_documents):
        """Test a complete hybrid search with BM25 + reranking."""
        # Phase 1: Train BM25 embedder
        bm25 = BM25Embedder(max_features=512)
        bm25.fit(sample_documents)

        # Phase 2: Create document index (pre-compute vectors)
        doc_vectors = bm25.embed(sample_documents)

        # Phase 3: Simple retrieval function
        def retrieve(query, top_k=10):
            query_vec = bm25.embed(query)
            # Simple dot product scoring
            scores = [
                sum(
                    query_vec.get(i, 0) * dv.get(i, 0)
                    for i in query_vec.keys() & dv.keys()
                )
                for dv in doc_vectors
            ]
            # Rank by score
            ranked = sorted(zip(range(len(scores)), scores), key=lambda x: -x[1])[
                :top_k
            ]
            return [
                Doc(id=str(idx), score=float(score))
                for idx, score in ranked
                if score > 0
            ]

        # Phase 4: Retrieve with "BM25-like" scoring
        query = "brown fox animal"
        bm25_results = retrieve(query)

        # Simulate a second retrieval source (e.g., dense/semantic)
        dense_results = [
            Doc(id=str(i), score=float(0.9 - i * 0.1))
            for i in range(min(5, len(bm25_results)))
        ]

        # Phase 5: Rerank with RRF
        query_results = {"sparse_bm25": bm25_results, "dense_semantic": dense_results}

        reranker = RrfReranker(topn=5)
        final_results = reranker.rerank(query_results)

        assert len(final_results) <= 5
        # All final results should have positive scores
        assert all(doc.score > 0 for doc in final_results)

    def test_end_to_end_with_model_persistence(self, sample_documents, tmp_path):
        """Test complete pipeline with model save/load."""
        # Train and save
        embedder = BM25Embedder(k1=1.5, b=0.8, max_features=256)
        embedder.fit(sample_documents)

        model_path = tmp_path / "pipeline_model.joblib"
        embedder.save(str(model_path))

        # Load in a new instance
        loaded_embedder = BM25Embedder()
        loaded_embedder.load(str(model_path))

        # Verify loaded model works
        query = "test query"
        original_vec = embedder.embed(query)
        loaded_vec = loaded_embedder.embed(query)

        assert original_vec == loaded_vec

        # Use loaded model for retrieval
        results = loaded_embedder.embed(["query 1", "query 2"])
        assert len(results) == 2


class TestNormalizeIntegration:
    """Test Normalize utility in realistic scenarios."""

    def test_normalize_diverse_score_ranges(self):
        """Test normalization with scores from very different ranges."""
        # BM25-style scores (unbounded, can be large)
        bm25_scores = [("doc1", 150.0), ("doc2", 75.0), ("doc3", 25.0)]

        # Dense scores (typically bounded, e.g., cosine similarity)
        dense_scores = [("doc1", 0.85), ("doc2", 0.72), ("doc3", 0.45)]

        # Normalize both
        bm25_norm = Normalize()(bm25_scores)
        dense_norm = Normalize()(dense_scores)

        # Both should be in [0, 1]
        assert all(0.0 <= score <= 1.0 for _, score in bm25_norm)
        assert all(0.0 <= score <= 1.0 for _, score in dense_norm)

        # Relative ordering should be preserved
        assert bm25_norm[0][1] > bm25_norm[1][1] > bm25_norm[2][1]
        assert dense_norm[0][1] > dense_norm[1][1] > dense_norm[2][1]

    def test_normalize_with_negative_scores(self):
        """Test normalization handles negative scores correctly."""
        scores = [
            ("positive1", 10.0),
            ("positive2", 5.0),
            ("zero", 0.0),
            ("negative1", -2.0),
            ("negative2", -10.0),
        ]

        # Bayesian normalization is translation-invariant, handles all scores
        normalizer = Normalize({"method": "bayes"})
        result = normalizer(scores)

        # Order should be preserved: 5 > 2 > 0 > -1 > -5
        assert result[0][1] > result[1][1] > result[2][1] > result[3][1] > result[4][1]
        assert all(0 < s < 1 for _, s in result)
