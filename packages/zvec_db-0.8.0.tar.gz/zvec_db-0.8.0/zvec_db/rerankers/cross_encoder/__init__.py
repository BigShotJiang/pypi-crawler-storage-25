"""Cross-encoder rerankers for accurate pairwise scoring.

This module provides cross-encoder based reranking implementations.

Available Classes
-----------------
BaseCrossEncoderReranker
    Abstract base class for all cross-encoder rerankers.

SentenceTransformerReranker
    Local binary cross-encoder using Sentence Transformers.
    Uses sigmoid output for relevance scoring.

ClassificationReranker
    Local multi-class classification using HuggingFace transformers.
    Uses softmax + expected value for scoring.

OpenAIReranker
    API-based reranker using /rerank or /score endpoints.
    Supports vLLM and OpenAI-compatible APIs.

OpenAIEncoderReranker
    API-based reranker using /classify endpoint.
    Uses encoder models (BERT, RoBERTa) with expected value scoring.

OpenAIDecoderReranker
    API-based reranker using /chat/completions with logprobs.
    Uses LLM with structured output and expected value scoring.

Example Usage
-------------
.. code-block:: python

    from zvec_db.rerankers.cross_encoder import (
        SentenceTransformerReranker,
        OpenAIReranker,
        OpenAIDecoderReranker,
    )

    # Local binary cross-encoder
    reranker = SentenceTransformerReranker(
        model_name="cross-encoder/ms-marco-MiniLM-L-6-v2",
        query="machine learning"
    )
    results = reranker.rerank({"bm25": docs})

    # API /rerank endpoint
    reranker = OpenAIReranker(
        endpoint="rerank",
        base_url="http://localhost:8000",
        model="BAAI/bge-reranker-v2-m3",
        query="machine learning"
    )
    results = reranker.rerank({"bm25": docs})

    # LLM with logprobs (binary)
    reranker = OpenAIDecoderReranker(
        num_classes=2,
        model="gpt-4o-mini",
        query="machine learning"
    )
    results = reranker.rerank({"bm25": docs})

    # LLM with logprobs (multi-class 0-4)
    reranker = OpenAIDecoderReranker(
        num_classes=5,
        model="meta-llama/Llama-3-8b-instruct",
        query="machine learning"
    )
    results = reranker.rerank({"bm25": docs})
"""

from .base import BaseCrossEncoderReranker
from .classification import ClassificationReranker
from .openai import OpenAIReranker
from .openai_decoder import OpenAIDecoderReranker
from .openai_encoder import OpenAIEncoderReranker
from .sentence_transformer import SentenceTransformerReranker

__all__ = [
    "BaseCrossEncoderReranker",
    "SentenceTransformerReranker",
    "ClassificationReranker",
    "OpenAIReranker",
    "OpenAIEncoderReranker",
    "OpenAIDecoderReranker",
]
