"""Evaluation metrics for information retrieval systems.

This module provides standard IR metrics for evaluating the quality
of search results, including Precision, Recall, MRR, and NDCG.

Main Functions
--------------
precision_at_k
    Precision@K: Fraction of retrieved documents that are relevant.
recall_at_k
    Recall@K: Fraction of relevant documents that were retrieved.
mrr
    Mean Reciprocal Rank: Average of reciprocal ranks of first relevant document.
ndcg_at_k
    NDCG@K: Normalized Discounted Cumulative Gain at K.
map_score
    Mean Average Precision: Mean of average precision scores.
f1_score_at_k
    F1 Score@K: Harmonic mean of precision and recall.
f_score_at_k
    F-beta Score@K: Generalized F score with beta weighting.
hit_rate_at_k
    Hit Rate@K: Binary metric (1 if any relevant doc in top K).

Example Usage
-------------
::

    from zvec_db.evaluation import (
        precision_at_k, recall_at_k, mrr, ndcg_at_k,
        f1_score_at_k, hit_rate_at_k
    )

    # Ground truth: relevant document IDs
    relevant_ids = {"1", "3", "5"}

    # Retrieved document IDs (ranked)
    retrieved_ids = ["1", "2", "3", "4", "5"]

    # Precision@3: 2/3 (doc 1 and 3 are relevant out of top 3)
    p3 = precision_at_k(retrieved_ids, relevant_ids, k=3)

    # Recall@3: 2/3 (found 2 out of 3 relevant docs)
    r3 = recall_at_k(retrieved_ids, relevant_ids, k=3)

    # F1@3: harmonic mean of P@3 and R@3
    f1 = f1_score_at_k(retrieved_ids, relevant_ids, k=3)

    # MRR: 1/1 = 1.0 (first relevant doc is at rank 1)
    m = mrr(retrieved_ids, relevant_ids)

    # NDCG@5
    n = ndcg_at_k(retrieved_ids, relevant_ids, k=5)
"""

import math
from typing import Dict, List, Optional, Set


def precision_at_k(
    retrieved: List[str],
    relevant: Set[str],
    k: Optional[int] = None,
) -> float:
    """Calculate Precision@K.

    Precision@K measures the fraction of retrieved documents that are relevant
    among the top K results.

    Args:
        retrieved: List of retrieved document IDs (ranked).
        relevant: Set of relevant document IDs.
        k: Number of top results to consider. If None, uses all results.

    Returns:
        Precision@K value in [0, 1]. Returns 0 if k=0 or no results.

    Example:
        >>> retrieved = ["1", "2", "3", "4", "5"]
        >>> relevant = {"1", "3", "5"}
        >>> precision_at_k(retrieved, relevant, k=3)
        0.6666666666666666  # 2/3 relevant
    """
    if not retrieved or not relevant:
        return 0.0

    if k is None or k > len(retrieved):
        k = len(retrieved)

    if k == 0:
        return 0.0

    top_k = retrieved[:k]
    relevant_count = sum(1 for doc_id in top_k if doc_id in relevant)

    return relevant_count / k


def recall_at_k(
    retrieved: List[str],
    relevant: Set[str],
    k: Optional[int] = None,
) -> float:
    """Calculate Recall@K.

    Recall@K measures the fraction of relevant documents that were retrieved
    among the top K results.

    Args:
        retrieved: List of retrieved document IDs (ranked).
        relevant: Set of relevant document IDs.
        k: Number of top results to consider. If None, uses all results.

    Returns:
        Recall@K value in [0, 1]. Returns 0 if no relevant documents.

    Example:
        >>> retrieved = ["1", "2", "3", "4", "5"]
        >>> relevant = {"1", "3", "5"}
        >>> recall_at_k(retrieved, relevant, k=3)
        0.6666666666666666  # Found 2 out of 3 relevant docs
    """
    if not retrieved or not relevant:
        return 0.0

    if k is None or k > len(retrieved):
        k = len(retrieved)

    if len(relevant) == 0:
        return 0.0

    top_k = retrieved[:k]
    relevant_count = sum(1 for doc_id in top_k if doc_id in relevant)

    return relevant_count / len(relevant)


def mrr(
    retrieved: List[str],
    relevant: Set[str],
) -> float:
    """Calculate Mean Reciprocal Rank (MRR) for a single query.

    MRR is the reciprocal of the rank of the first relevant document.
    If no relevant document is found, returns 0.

    Args:
        retrieved: List of retrieved document IDs (ranked).
        relevant: Set of relevant document IDs.

    Returns:
        Reciprocal rank value in [0, 1]. Returns 0 if no relevant document found.

    Example:
        >>> retrieved = ["2", "4", "1", "3"]
        >>> relevant = {"1", "3", "5"}
        >>> mrr(retrieved, relevant)
        0.3333333333333333  # First relevant (doc 1) is at rank 3, so 1/3
    """
    if not retrieved or not relevant:
        return 0.0

    for rank, doc_id in enumerate(retrieved, start=1):
        if doc_id in relevant:
            return 1.0 / rank

    return 0.0


def dcg_at_k(
    retrieved: List[str],
    relevant: Set[str],
    k: Optional[int] = None,
    method: str = "standard",
) -> float:
    """Calculate Discounted Cumulative Gain at K.

    DCG@K measures the quality of ranking by summing the relevance of each
    document, discounted by its position.

    Args:
        retrieved: List of retrieved document IDs (ranked).
        relevant: Set of relevant document IDs.
        k: Number of top results to consider. If None, uses all results.
        method: "standard" (gain / log2(rank+1)) or "logarithmic" (gain / log2(rank+1)).

    Returns:
        DCG@K value >= 0.

    Note:
        For binary relevance (relevant/not relevant), gain is 1 for relevant
        documents and 0 otherwise.
    """
    if not retrieved or not relevant:
        return 0.0

    if k is None or k > len(retrieved):
        k = len(retrieved)

    if k == 0:
        return 0.0

    dcg = 0.0
    for rank, doc_id in enumerate(retrieved[:k], start=1):
        gain = 1.0 if doc_id in relevant else 0.0
        if method == "standard":
            # Standard: gain / log2(rank + 1)
            dcg += gain / math.log2(rank + 1)
        else:
            # Alternative: gain / log2(rank) for rank > 1, else gain
            if rank > 1:
                dcg += gain / math.log2(rank)
            else:
                dcg += gain

    return dcg


def idcg_at_k(
    relevant: Set[str],
    k: int,
) -> float:
    """Calculate Ideal Discounted Cumulative Gain at K.

    IDCG is the DCG of the ideal ranking (all relevant documents first).

    Args:
        relevant: Set of relevant document IDs.
        k: Number of top results to consider.

    Returns:
        IDCG@K value >= 0.
    """
    if not relevant or k == 0:
        return 0.0

    # Ideal ranking: all relevant docs first, then irrelevant
    ideal_relevant_count = min(len(relevant), k)

    idcg = 0.0
    for rank in range(1, ideal_relevant_count + 1):
        idcg += 1.0 / math.log2(rank + 1)

    return idcg


def ndcg_at_k(
    retrieved: List[str],
    relevant: Set[str],
    k: Optional[int] = None,
    method: str = "standard",
) -> float:
    """Calculate Normalized Discounted Cumulative Gain at K.

    NDCG@K is DCG@K normalized by the ideal DCG (IDCG), giving a value
    between 0 and 1 where 1 is perfect ranking.

    Args:
        retrieved: List of retrieved document IDs (ranked).
        relevant: Set of relevant document IDs.
        k: Number of top results to consider. If None, uses all results.
        method: "standard" or "logarithmic" discounting.

    Returns:
        NDCG@K value in [0, 1]. Returns 0 if no relevant documents or k=0.

    Example:
        >>> retrieved = ["1", "2", "3", "4", "5"]
        >>> relevant = {"1", "3", "5"}
        >>> ndcg_at_k(retrieved, relevant, k=5)
        0.884...  # Good but not perfect ranking
    """
    if not retrieved or not relevant:
        return 0.0

    if k is None or k > len(retrieved):
        k = len(retrieved)

    if k == 0:
        return 0.0

    dcg = dcg_at_k(retrieved, relevant, k, method)
    idcg = idcg_at_k(relevant, k)

    if idcg == 0:
        return 0.0

    return dcg / idcg


def average_precision(
    retrieved: List[str],
    relevant: Set[str],
) -> float:
    """Calculate Average Precision (AP) for a single query.

    AP is the average of precision values at each position where a
    relevant document is retrieved.

    Args:
        retrieved: List of retrieved document IDs (ranked).
        relevant: Set of relevant document IDs.

    Returns:
        Average Precision value in [0, 1]. Returns 0 if no relevant documents.

    Example:
        >>> retrieved = ["1", "2", "3", "4", "5"]
        >>> relevant = {"1", "3", "5"}
        >>> average_precision(retrieved, relevant)
        0.888...  # (1/1 + 2/3 + 3/5) / 3
    """
    if not retrieved or not relevant:
        return 0.0

    num_relevant = len(relevant)
    if num_relevant == 0:
        return 0.0

    ap = 0.0
    relevant_found = 0

    for rank, doc_id in enumerate(retrieved, start=1):
        if doc_id in relevant:
            relevant_found += 1
            ap += relevant_found / rank

    return ap / num_relevant


def map_score(
    queries_results: Dict[str, List[str]],
    queries_relevant: Dict[str, Set[str]],
) -> float:
    """Calculate Mean Average Precision (MAP) across multiple queries.

    MAP is the mean of Average Precision scores across all queries.

    Args:
        queries_results: Dict mapping query IDs to retrieved document lists.
        queries_relevant: Dict mapping query IDs to relevant document sets.

    Returns:
        MAP value in [0, 1]. Returns 0 if no queries.

    Example:
        >>> queries_results = {
        ...     "q1": ["1", "2", "3"],
        ...     "q2": ["2", "1", "3"],
        ... }
        >>> queries_relevant = {
        ...     "q1": {"1", "2"},
        ...     "q2": {"1", "3"},
        ... }
        >>> map_score(queries_results, queries_relevant)
        0.75  # Mean of AP for q1 and q2
    """
    if not queries_results:
        return 0.0

    ap_scores = []
    for query_id in queries_results:
        retrieved = queries_results[query_id]
        relevant = queries_relevant.get(query_id, set())
        ap_scores.append(average_precision(retrieved, relevant))

    return sum(ap_scores) / len(ap_scores)


def hit_rate_at_k(
    retrieved: List[str],
    relevant: Set[str],
    k: Optional[int] = None,
) -> float:
    """Calculate Hit Rate@K (also called Recall@K for single query).

    Hit Rate@K is 1 if at least one relevant document is in top K, 0 otherwise.

    Args:
        retrieved: List of retrieved document IDs (ranked).
        relevant: Set of relevant document IDs.
        k: Number of top results to consider. If None, uses all results.

    Returns:
        Hit Rate@K value in {0, 1}.

    Example:
        >>> retrieved = ["1", "2", "3", "4", "5"]
        >>> relevant = {"3", "5"}
        >>> hit_rate_at_k(retrieved, relevant, k=3)
        1  # Found doc 3 in top 3
    """
    if not retrieved or not relevant:
        return 0.0

    if k is None or k > len(retrieved):
        k = len(retrieved)

    top_k = retrieved[:k]
    return 1.0 if any(doc_id in relevant for doc_id in top_k) else 0.0


def f_score_at_k(
    retrieved: List[str],
    relevant: Set[str],
    k: Optional[int] = None,
    beta: float = 1.0,
) -> float:
    """Calculate F-Score@K (F-beta score).

    The F-beta score is the weighted harmonic mean of precision and recall.
    F-1 (default) gives equal weight to precision and recall.
    F-2 emphasizes recall more than precision.
    F-0.5 emphasizes precision more than recall.

    Args:
        retrieved: List of retrieved document IDs (ranked).
        relevant: Set of relevant document IDs.
        k: Number of top results to consider. If None, uses all results.
        beta: Weighting factor. beta=1 gives F1, beta>1 emphasizes recall,
              beta<1 emphasizes precision.

    Returns:
        F-beta score in [0, 1]. Returns 0 if precision + recall = 0.

    Example:
        >>> retrieved = ["1", "2", "3", "4", "5"]
        >>> relevant = {"1", "3", "5"}
        >>> f_score_at_k(retrieved, relevant, k=3)
        0.6666666666666666  # F1 of precision=0.667 and recall=0.667
    """
    if not retrieved or not relevant:
        return 0.0

    p = precision_at_k(retrieved, relevant, k)
    r = recall_at_k(retrieved, relevant, k)

    if p + r == 0:
        return 0.0

    beta_squared = beta * beta
    return (1 + beta_squared) * p * r / (beta_squared * p + r)


def f1_score_at_k(
    retrieved: List[str],
    relevant: Set[str],
    k: Optional[int] = None,
) -> float:
    """Calculate F1 Score@K (harmonic mean of precision and recall).

    F1 Score is the harmonic mean of precision and recall, giving
    equal weight to both metrics.

    Args:
        retrieved: List of retrieved document IDs (ranked).
        relevant: Set of relevant document IDs.
        k: Number of top results to consider. If None, uses all results.

    Returns:
        F1 score in [0, 1]. Returns 0 if precision + recall = 0.

    Example:
        >>> retrieved = ["1", "2", "3", "4", "5"]
        >>> relevant = {"1", "3", "5"}
        >>> f1_score_at_k(retrieved, relevant, k=3)
        0.6666666666666666
    """
    return f_score_at_k(retrieved, relevant, k, beta=1.0)
