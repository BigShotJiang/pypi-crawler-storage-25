"""Evaluation metrics for information retrieval systems.

This module provides standard IR metrics for benchmarking embedders and rerankers.

Available Metrics
-----------------
- Precision@K: Fraction of retrieved documents that are relevant
- Recall@K: Fraction of relevant documents that were retrieved
- MRR: Mean Reciprocal Rank of first relevant document
- NDCG@K: Normalized Discounted Cumulative Gain
- MAP: Mean Average Precision across queries
- Hit Rate@K: Whether at least one relevant doc is in top K
- F1 Score@K: Harmonic mean of precision and recall
- F-beta Score@K: Generalized F score with beta weighting

Example Usage
-------------
::

    from zvec_db.evaluation import (
        precision_at_k,
        recall_at_k,
        mrr,
        ndcg_at_k,
        map_score,
        f1_score_at_k,
    )

    # Single query evaluation
    retrieved = ["1", "2", "3", "4", "5"]
    relevant = {"1", "3", "5"}

    print(f"P@3: {precision_at_k(retrieved, relevant, k=3):.3f}")
    print(f"R@3: {recall_at_k(retrieved, relevant, k=3):.3f}")
    print(f"F1@3: {f1_score_at_k(retrieved, relevant, k=3):.3f}")
    print(f"MRR: {mrr(retrieved, relevant):.3f}")
    print(f"NDCG@5: {ndcg_at_k(retrieved, relevant, k=5):.3f}")

    # Multiple queries (MAP)
    queries_results = {"q1": ["1", "2"], "q2": ["3", "4"]}
    queries_relevant = {"q1": {"1"}, "q2": {"3", "4"}}
    print(f"MAP: {map_score(queries_results, queries_relevant):.3f}")
"""

from .metrics import (
    average_precision,
    dcg_at_k,
    f1_score_at_k,
    f_score_at_k,
    hit_rate_at_k,
    idcg_at_k,
    map_score,
    mrr,
    ndcg_at_k,
    precision_at_k,
    recall_at_k,
)

__all__ = [
    "precision_at_k",
    "recall_at_k",
    "mrr",
    "dcg_at_k",
    "idcg_at_k",
    "ndcg_at_k",
    "average_precision",
    "map_score",
    "hit_rate_at_k",
    "f_score_at_k",
    "f1_score_at_k",
]
