"""Retry utilities for API calls with exponential backoff.

This module provides retry logic with exponential backoff for handling
transient API failures, rate limits, and connection errors.

Available Functions
-------------------
retry_with_backoff
    Decorator for adding retry logic to functions with exponential backoff.

Example Usage
-------------
.. code-block:: python

    from zvec_db.utils.retry import retry_with_backoff

    @retry_with_backoff(
        max_retries=3,
        initial_delay=1.0,
        max_delay=60.0,
        exponential_base=2.0,
    )
    def call_api(text: str) -> dict:
        response = httpx.post(url, json={"text": text})
        response.raise_for_status()
        return response.json()
"""

from __future__ import annotations

import logging
import random
import time
from functools import wraps
from typing import Any, Callable, Optional, Tuple, Type

logger = logging.getLogger(__name__)

# Default retry configuration
DEFAULT_MAX_RETRIES = 3
DEFAULT_INITIAL_DELAY = 1.0  # seconds
DEFAULT_MAX_DELAY = 60.0  # seconds
DEFAULT_EXPONENTIAL_BASE = 2.0
DEFAULT_JITTER = 0.1  # 10% jitter


# HTTP status codes that should trigger a retry
RETRYABLE_STATUS_CODES = {
    408,  # Request Timeout
    429,  # Too Many Requests (rate limit)
    500,  # Internal Server Error
    502,  # Bad Gateway
    503,  # Service Unavailable
    504,  # Gateway Timeout
}


def _calculate_delay(
    attempt: int,
    initial_delay: float,
    max_delay: float,
    exponential_base: float,
    jitter: float,
) -> float:
    """Calculate delay for a given retry attempt.

    Uses exponential backoff with optional jitter to avoid thundering herd.

    Args:
        attempt: Current retry attempt number (0-indexed).
        initial_delay: Initial delay in seconds.
        max_delay: Maximum delay cap in seconds.
        exponential_base: Base for exponential growth.
        jitter: Random jitter factor (0.0 = no jitter, 1.0 = full random).

    Returns:
        Delay in seconds, capped at max_delay.
    """
    # Exponential backoff: initial_delay * (base ^ attempt)
    delay = initial_delay * (exponential_base**attempt)

    # Add jitter to avoid synchronized retries
    if jitter > 0:
        jitter_range = delay * jitter
        delay += random.uniform(-jitter_range, jitter_range)

    # Cap at max_delay
    return min(delay, max_delay)


def _is_retryable_error(exception: Exception, retry_on_timeout: bool) -> bool:
    """Check if an exception is retryable.

    Args:
        exception: The exception to check.
        retry_on_timeout: Whether to retry on timeout errors.

    Returns:
        True if the exception should trigger a retry.
    """
    # Import httpx lazily to avoid circular imports
    httpx = None
    try:
        import httpx as _httpx

        httpx = _httpx
    except ImportError:
        pass

    # HTTP status errors
    if httpx and isinstance(exception, httpx.HTTPStatusError):
        return exception.response.status_code in RETRYABLE_STATUS_CODES

    # Timeout errors
    if httpx and retry_on_timeout and isinstance(exception, httpx.TimeoutException):
        return True

    # Connection errors
    if httpx and isinstance(exception, (httpx.ConnectError, httpx.NetworkError)):
        return True

    # RuntimeError with retryable messages (for wrapped errors)
    if isinstance(exception, RuntimeError):
        error_msg = str(exception).lower()
        return any(
            keyword in error_msg
            for keyword in [
                "timeout",
                "timed out",
                "connection",
                "rate limit",
                "503",
                "502",
                "500",
            ]
        )

    return False


def retry_with_backoff(
    max_retries: int = DEFAULT_MAX_RETRIES,
    initial_delay: float = DEFAULT_INITIAL_DELAY,
    max_delay: float = DEFAULT_MAX_DELAY,
    exponential_base: float = DEFAULT_EXPONENTIAL_BASE,
    jitter: float = DEFAULT_JITTER,
    retry_on_timeout: bool = True,
    exception_types: Optional[Tuple[Type[Exception], ...]] = None,
) -> Callable:
    """Decorator for adding retry logic with exponential backoff.

    This decorator wraps a function to automatically retry on transient failures
    using exponential backoff with jitter. It logs retry attempts and provides
    clear error messages.

    Args:
        max_retries: Maximum number of retry attempts. Defaults to 3.
        initial_delay: Initial delay before first retry in seconds. Defaults to 1.0.
        max_delay: Maximum delay cap in seconds. Defaults to 60.0.
        exponential_base: Base for exponential backoff. Defaults to 2.0.
        jitter: Random jitter factor (0.0-1.0). Defaults to 0.1.
        retry_on_timeout: Whether to retry on timeout errors. Defaults to True.
        exception_types: Optional tuple of exception types to catch. If None,
            catches common HTTP errors (httpx.HTTPError, TimeoutError, ConnectionError).

    Returns:
        Decorated function with retry logic.

    Example:
        >>> @retry_with_backoff(max_retries=3, initial_delay=1.0)
        ... def call_api(text: str) -> dict:
        ...     response = httpx.post(url, json={"text": text})
        ...     response.raise_for_status()
        ...     return response.json()
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exception: Optional[Exception] = None

            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)

                except Exception as e:
                    last_exception = e

                    # Check if this exception is retryable
                    if exception_types:
                        is_retryable = isinstance(e, exception_types)
                    else:
                        is_retryable = _is_retryable_error(e, retry_on_timeout)

                    # Don't retry if not a retryable error or max retries reached
                    if not is_retryable or attempt >= max_retries:
                        break

                    # Calculate delay
                    delay = _calculate_delay(
                        attempt=attempt,
                        initial_delay=initial_delay,
                        max_delay=max_delay,
                        exponential_base=exponential_base,
                        jitter=jitter,
                    )

                    # Log retry attempt
                    logger.warning(
                        "%s failed (attempt %d/%d): %s. Retrying in %.2fs...",
                        func.__name__,
                        attempt + 1,
                        max_retries + 1,
                        e,
                        delay,
                    )

                    # Wait before retrying
                    time.sleep(delay)

            # All retries exhausted, raise the last exception
            error_msg = (
                f"{func.__name__} failed after {max_retries + 1} attempts. "
                f"Last error: {last_exception}"
            )
            logger.error(error_msg)

            # Re-raise the original exception type if possible
            if last_exception is not None:
                raise last_exception
            raise RuntimeError(error_msg)

        return wrapper

    return decorator


class RetryConfig:
    """Configuration for retry behavior.

    This class provides a reusable configuration object for retry logic,
    useful when you want to pass retry settings as a parameter.

    Args:
        max_retries: Maximum number of retry attempts. Defaults to 3.
        initial_delay: Initial delay before first retry in seconds. Defaults to 1.0.
        max_delay: Maximum delay cap in seconds. Defaults to 60.0.
        exponential_base: Base for exponential backoff. Defaults to 2.0.
        jitter: Random jitter factor (0.0-1.0). Defaults to 0.1.
        retry_on_timeout: Whether to retry on timeout errors. Defaults to True.

    Example:
        >>> config = RetryConfig(max_retries=5, initial_delay=0.5)
        >>> @retry_with_backoff(**config.to_dict())
        ... def my_api_call():
        ...     ...
    """

    def __init__(
        self,
        max_retries: int = DEFAULT_MAX_RETRIES,
        initial_delay: float = DEFAULT_INITIAL_DELAY,
        max_delay: float = DEFAULT_MAX_DELAY,
        exponential_base: float = DEFAULT_EXPONENTIAL_BASE,
        jitter: float = DEFAULT_JITTER,
        retry_on_timeout: bool = True,
    ):
        self.max_retries = max_retries
        self.initial_delay = initial_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
        self.jitter = jitter
        self.retry_on_timeout = retry_on_timeout

    def to_dict(self) -> dict[str, Any]:
        """Convert configuration to dictionary.

        Returns:
            Dictionary with all configuration parameters.
        """
        return {
            "max_retries": self.max_retries,
            "initial_delay": self.initial_delay,
            "max_delay": self.max_delay,
            "exponential_base": self.exponential_base,
            "jitter": self.jitter,
            "retry_on_timeout": self.retry_on_timeout,
        }

    def __repr__(self) -> str:
        return (
            f"RetryConfig(max_retries={self.max_retries}, "
            f"initial_delay={self.initial_delay}, max_delay={self.max_delay})"
        )
