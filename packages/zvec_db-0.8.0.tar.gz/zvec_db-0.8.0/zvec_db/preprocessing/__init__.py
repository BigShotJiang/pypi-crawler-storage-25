"""Text preprocessing utilities for search and embedding pipelines.

This module provides helper functions for normalizing and cleaning text
before embedding or indexing. These utilities are useful for improving
search quality by reducing noise and standardizing input.

**Note:** Stemming uses nltk's SnowballStemmer for accurate results.
Install with: ``pip install nltk`` or ``pip install "zvec-db[preprocessing]"``

Main Functions
--------------
normalize_text
    Lowercase, remove accents, normalize whitespace, and optional stemming.
remove_accents
    Replace accented characters with ASCII equivalents.
normalize_whitespace
    Collapse multiple whitespace characters into single spaces.
strip_punctuation
    Remove punctuation characters from text.
stem_word
    Apply Snowball stemming to a single word (French/English) via nltk.
remove_stopwords
    Remove common stopwords from text (French/English).

Example Usage
-------------
::

    from zvec_db.preprocessing import normalize_text, remove_accents, stem_word

    # Full normalization with stemming (recommended for French BM25)
    text = "  Ceci est un TEST avec des accents éàû !  "
    normalized = normalize_text(text, language="french")
    # → "ceci et un test avec des accent eau"

    # Just stem a word (uses nltk SnowballStemmer)
    stem_word("mangeaient", language="french")  # → "mang"
    stem_word("running", language="english")     # → "run"

    # Remove stopwords
    from zvec_db.preprocessing import remove_stopwords
    text = "le chat mange la souris"
    no_stopwords = remove_stopwords(text, language="french")
    # → "chat mange souris"
"""

from .config import Language, NormalizationConfig, normalize_text
from .normalization import (
    normalize_whitespace,
    remove_accents,
    strip_punctuation,
)
from .stemming import (
    NLTK_AVAILABLE,
    stem_word,
    stem_words,
)
from .stopwords import (
    ENGLISH_STOPWORDS,
    FRENCH_STOPWORDS,
    get_stopwords,
    remove_stopwords,
)
from .tokenization import (
    tokenize_alpha,
    tokenize_simple,
)

__all__ = [
    # Configuration
    "Language",
    "NormalizationConfig",
    "normalize_text",
    # Normalization
    "remove_accents",
    "normalize_whitespace",
    "strip_punctuation",
    # Stemming
    "stem_word",
    "stem_words",
    "NLTK_AVAILABLE",
    # Stopwords
    "remove_stopwords",
    "get_stopwords",
    "FRENCH_STOPWORDS",
    "ENGLISH_STOPWORDS",
    # Tokenization
    "tokenize_simple",
    "tokenize_alpha",
]
