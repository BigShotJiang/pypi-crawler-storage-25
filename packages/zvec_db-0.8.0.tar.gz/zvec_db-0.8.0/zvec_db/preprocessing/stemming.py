"""Snowball stemming for French and English using nltk."""

from typing import List, Literal, Tuple, Union

Language = Literal["french", "english"]

# =============================================================================
# nltk import
# =============================================================================

try:
    from nltk.stem import SnowballStemmer

    NLTK_AVAILABLE = True
except ImportError:
    NLTK_AVAILABLE = False
    SnowballStemmer = None


# =============================================================================
# Stemming functions
# =============================================================================


def _get_stemmer(language: Language):
    """Get or create a stemmer for the specified language.

    Args:
        language: Language for stemming ("french" or "english").

    Returns:
        A SnowballStemmer instance, or None if nltk is not available.
    """
    if not NLTK_AVAILABLE:
        return None
    try:
        return SnowballStemmer(language)
    except (ValueError, LookupError):
        return None


def stem_word(word: str, language: Language = "french") -> str:
    """Apply Snowball stemming to a single word.

    Uses nltk's SnowballStemmer if available. Falls back to returning
    the original word if nltk is not installed.

    Args:
        word: The word to stem.
        language: Language for stemming ("french" or "english").

    Returns:
        The stemmed word, or the original word if stemming is not available.

    Example:
        >>> stem_word("mangeaient", language="french")
        'mang'
        >>> stem_word("running", language="english")
        'run'
        >>> stem_word("ordinateurs", language="french")
        'ordin'

    Note:
        Requires nltk for Snowball stemming. Install with:
        ``pip install nltk`` or ``pip install "zvec-db[preprocessing]"``
    """
    if not word:
        return word

    stemmer = _get_stemmer(language)
    if stemmer is not None:
        return stemmer.stem(word.lower())

    # Fallback: return lowercase word if nltk not available
    return word.lower()


def stem_words(
    words: List[str],
    language: Language = "french",
    keep_original: bool = False,
) -> Union[List[str], List[Tuple[str, str]]]:
    """Apply stemming to a list of words.

    Args:
        words: List of words to stem.
        language: Language for stemming ("french" or "english").
        keep_original: If True, return (original, stemmed) pairs.

    Returns:
        List of stemmed words (or pairs if keep_original=True).

    Example:
        >>> stem_words(["mangeaient", "ordinateurs"], language="french")
        ['mang', 'ordin']
    """
    if keep_original:
        return [(w, stem_word(w, language)) for w in words]
    return [stem_word(w, language) for w in words]
