"""Text tokenization utilities."""

import re
from typing import List

from .normalization import normalize_whitespace


def tokenize_simple(text: str) -> List[str]:
    """Simple whitespace-based tokenization.

    Splits text on whitespace after basic normalization.

    Args:
        text: Input text to tokenize.

    Returns:
        List of tokens.

    Example:
        >>> tokenize_simple("Hello world  test")
        ['Hello', 'world', 'test']
    """
    if not text:
        return []
    return normalize_whitespace(text).split()


def tokenize_alpha(text: str) -> List[str]:
    """Alphabetic tokenization.

    Extracts only alphabetic words, removing numbers and punctuation.

    Args:
        text: Input text to tokenize.

    Returns:
        List of alphabetic tokens.

    Example:
        >>> tokenize_alpha("Hello123 world test456")
        ['Hello', 'world', 'test']
    """
    if not text:
        return []
    return re.findall(r"[a-zA-Z]+", text)
