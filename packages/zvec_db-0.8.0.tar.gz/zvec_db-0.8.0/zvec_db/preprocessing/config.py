"""Configuration and main pipeline for text normalization."""

from dataclasses import dataclass
from typing import Callable, List, Optional

import cloudpickle

from .normalization import normalize_whitespace as normalize_whitespace_fn
from .normalization import remove_accents as remove_accents_fn
from .normalization import strip_punctuation as strip_punctuation_fn
from .stemming import Language, stem_word
from .stopwords import remove_stopwords as remove_stopwords_fn


@dataclass
class NormalizationConfig:
    """Configuration for text normalization pipeline.

    Attributes:
        lowercase: Convert text to lowercase.
        remove_accents: Remove diacritical marks.
        normalize_whitespace: Collapse multiple whitespace.
        strip_punctuation: Remove punctuation marks.
        remove_stopwords: Remove common stopwords.
        stem: Apply Snowball stemming.
        language: Language for stemming/stopwords.
        tokenizer: Tokenizer to use, either:
            - str: HuggingFace tokenizer name (e.g., "bert-base-cased", "gbert-base")
            - Callable[[str], List[str]]: Custom tokenizer function
        pre_normalization: Optional custom function applied BEFORE the normalization pipeline.
            Signature: Callable[[str], str]. Will be serialized with cloudpickle.
        post_normalization: Optional custom function applied AFTER the normalization pipeline,
            but BEFORE the tokenizer. Signature: Callable[[str], str].
            Will be serialized with cloudpickle.

    Note:
        The ``tokenizer``, ``pre_normalization``, and ``post_normalization``
        hooks are serialized using ``cloudpickle`` when saving the config
        (via pickle/joblib). This allows lambdas and local functions to be
        preserved across save/load cycles.

        However, for best compatibility, use self-contained functions that:
        - Only use stdlib modules or widely-available packages
        - Don't rely on global variables or external state
        - Don't reference classes/objects that may not be available
          at load time

    Example:
        >>> config = NormalizationConfig(language="french", stem=True)
        >>> normalize_text("Mangeaient", config=config)
        'mang'

        >>> config = NormalizationConfig(
        ...     tokenizer="bert-base-cased",
        ...     remove_stopwords=True,
        ...     stem=True
        ... )
        >>> tokens = normalize_text("Le chat mangeait", config=config)
        >>> tokens  # List[str] from HF tokenizer after normalization
        ['le', 'chat', 'man', '##ge', '##ait']

        >>> config = NormalizationConfig(
        ...     tokenizer=lambda t: t.split(),  # Simple whitespace tokenizer
        ...     lowercase=True
        ... )
        >>> tokens = normalize_text("Hello world test", config=config)
        >>> tokens
        ['hello', 'world', 'test']
    """

    lowercase: bool = True
    remove_accents: bool = True
    normalize_whitespace: bool = True
    strip_punctuation: bool = False
    remove_stopwords: bool = False
    stem: bool = False
    language: Language = "french"
    tokenizer: Optional[str | Callable[[str], List[str]]] = None
    pre_normalization: Optional[Callable[[str], str]] = None
    post_normalization: Optional[Callable[[str], str]] = None

    # Internal attribute for caching HF tokenizer instance
    _tokenizer_instance: Optional[Callable[[str], List[str]]] = None

    def __post_init__(self):
        """Validate configuration after initialization."""
        if self.language not in ("french", "english"):
            raise ValueError(
                f"language must be 'french' or 'english', got '{self.language}'"
            )

    def __getstate__(self) -> dict:
        """Custom serialization for joblib - serialize hooks with cloudpickle."""
        state = self.__dict__.copy()
        state.pop("_tokenizer_instance", None)

        # Serialize tokenizer only if it's a callable (HF tokenizer_name is already a string)
        if callable(self.tokenizer):
            state["_tokenizer_bytes"] = cloudpickle.dumps(self.tokenizer)
            state["tokenizer"] = None

        # Serialize hooks with cloudpickle (supports lambdas and local functions)
        if self.pre_normalization:
            state["_pre_normalization_bytes"] = cloudpickle.dumps(
                self.pre_normalization
            )
            state["pre_normalization"] = None

        if self.post_normalization:
            state["_post_normalization_bytes"] = cloudpickle.dumps(
                self.post_normalization
            )
            state["post_normalization"] = None

        return state

    def __setstate__(self, state: dict):
        """Custom deserialization to reconstruct tokenizer and hooks."""
        self.__dict__.update(state)

        # Reconstruct HF tokenizer from tokenizer string
        if isinstance(self.tokenizer, str):
            try:
                self._tokenizer_instance = get_hf_tokenizer(self.tokenizer)
            except ImportError:
                self._tokenizer_instance = None

        # Deserialize custom tokenizer
        if state.get("_tokenizer_bytes"):
            self.tokenizer = cloudpickle.loads(state["_tokenizer_bytes"])

        # Deserialize hooks
        if state.get("_pre_normalization_bytes"):
            self.pre_normalization = cloudpickle.loads(
                state["_pre_normalization_bytes"]
            )

        if state.get("_post_normalization_bytes"):
            self.post_normalization = cloudpickle.loads(
                state["_post_normalization_bytes"]
            )

    @classmethod
    def minimal(cls) -> "NormalizationConfig":
        """Minimal normalization (lowercase only)."""
        return cls(
            lowercase=True,
            remove_accents=False,
            normalize_whitespace=False,
        )

    @classmethod
    def standard(cls) -> "NormalizationConfig":
        """Standard normalization (lowercase + accents + whitespace)."""
        return cls(
            lowercase=True,
            remove_accents=True,
            normalize_whitespace=True,
        )

    @classmethod
    def aggressive(cls, language: Language = "french") -> "NormalizationConfig":
        """Aggressive normalization (with stemming and stopwords)."""
        return cls(
            lowercase=True,
            remove_accents=True,
            normalize_whitespace=True,
            strip_punctuation=True,
            remove_stopwords=True,
            stem=True,
            language=language,
        )

    @classmethod
    def with_hf_tokenizer(cls, tokenizer: str, **kwargs) -> "NormalizationConfig":
        """Create a config with HuggingFace tokenizer.

        Args:
            tokenizer: HuggingFace tokenizer name (e.g., "gbert-base", "bert-base-cased").
            **kwargs: Additional arguments passed to NormalizationConfig.

        Returns:
            NormalizationConfig with HF tokenizer configured.

        Example:
            >>> config = NormalizationConfig.with_hf_tokenizer(
            ...     tokenizer="gbert-base",
            ...     remove_stopwords=True,
            ...     stem=True
            ... )
        """
        return cls(tokenizer=tokenizer, **kwargs)


def get_hf_tokenizer(tokenizer_name: str) -> Callable[[str], List[str]]:
    """Get a HuggingFace tokenizer as a callable.

    Args:
        tokenizer_name: HuggingFace model name (e.g., "gbert-base", "bert-base-cased").

    Returns:
        A callable that takes a string and returns a list of tokens.

    Example:
        >>> tokenize = get_hf_tokenizer("gbert-base")
        >>> tokens = tokenize("Le chat mange")
        >>> tokens
        ['le', 'chat', 'man', '##ge']
    """
    try:
        from transformers import AutoTokenizer
    except ImportError:
        raise ImportError(
            "transformers is required for HF tokenizers. "
            "Install with: pip install transformers"
        )

    tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)

    def tokenize(text: str) -> List[str]:
        return tokenizer.tokenize(text)

    return tokenize


def normalize_text(
    text: str,
    config: Optional[NormalizationConfig] = None,
    *,
    lowercase: Optional[bool] = None,
    remove_accents: Optional[bool] = None,
    normalize_whitespace: Optional[bool] = None,
    strip_punctuation: Optional[bool] = None,
    stem: Optional[bool] = None,
    language: Optional[Language] = None,
    remove_stopwords: Optional[bool] = None,
) -> str | List[str]:
    """Apply comprehensive text normalization.

    This function applies a pipeline of normalization steps in the following order:
    1. Pre-normalization hook (if provided)
    2. Lowercase
    3. Remove accents
    4. Normalize whitespace
    5. Strip punctuation
    6. Remove stopwords
    7. Stemming
    8. Post-normalization hook (if provided)
    9. Tokenization (if tokenizer or tokenizer_name is set)

    Can be configured using either a ``NormalizationConfig`` object or individual
    boolean parameters.

    Args:
        text: Input text to normalize.
        config: Optional NormalizationConfig object. If provided, individual
            parameters are ignored unless explicitly set.
        lowercase: Convert to lowercase.
        remove_accents: Remove diacritical marks.
        normalize_whitespace: Collapse multiple whitespace characters.
        strip_punctuation: Remove punctuation marks.
        stem: Apply Snowball stemming.
        language: Language for stemming/stopwords ("french" or "english").
        remove_stopwords: Remove common stopwords.

    Returns:
        Fully normalized text (str) or list of tokens (List[str]) if a tokenizer is set.

    Example:
        >>> normalize_text("  Ceci est un TEST éàû !  ")
        'ceci est un test avec des accent eau'

        >>> normalize_text("Ceci est un test", config=NormalizationConfig.aggressive("french"))
        'ceci et test avec accent'

        >>> normalize_text("le chat mange", language="french", remove_stopwords=True)
        'chat mange'

        >>> normalize_text(
        ...     "Le chat mange",
        ...     config=NormalizationConfig.with_hf_tokenizer("gbert-base")
        ... )
        ['le', 'chat', 'man', '##ge']

        >>> normalize_text(
        ...     "Hello world test",
        ...     config=NormalizationConfig(tokenizer=lambda t: t.split())
        ... )
        ['hello', 'world', 'test']
    """
    if not text:
        return text

    # Build config from parameters if not provided
    if config is None:
        config = NormalizationConfig(
            lowercase=lowercase if lowercase is not None else True,
            remove_accents=remove_accents if remove_accents is not None else True,
            normalize_whitespace=(
                normalize_whitespace if normalize_whitespace is not None else True
            ),
            strip_punctuation=(
                strip_punctuation if strip_punctuation is not None else False
            ),
            stem=stem if stem is not None else False,
            language=language if language is not None else "french",
            remove_stopwords=(
                remove_stopwords if remove_stopwords is not None else False
            ),
        )

    result = text

    # Step 1: Pre-normalization hook (custom)
    if config.pre_normalization:
        result = config.pre_normalization(result)

    # Step 2: Lowercase
    if config.lowercase:
        result = result.lower()

    # Step 3: Remove accents
    if config.remove_accents:
        result = remove_accents_fn(result)

    # Step 4: Normalize whitespace
    if config.normalize_whitespace:
        result = normalize_whitespace_fn(result)

    # Step 5: Strip punctuation
    if config.strip_punctuation:
        result = strip_punctuation_fn(result)

    # Step 6: Remove stopwords
    if config.remove_stopwords:
        result = remove_stopwords_fn(result, language=config.language)

    # Step 7: Stemming
    if config.stem:
        tokens = result.split()
        stemmed = [stem_word(token, config.language) for token in tokens]
        result = " ".join(stemmed)

    # Step 8: Post-normalization hook (custom)
    if config.post_normalization:
        result = config.post_normalization(result)

    # Step 9: Tokenization (custom tokenizer or HF)
    if config.tokenizer:
        if callable(config.tokenizer):
            # Custom tokenizer function
            return config.tokenizer(result)
        else:
            # HF tokenizer string - get or use cached instance
            tokenizer = getattr(config, "_tokenizer_instance", None)
            if tokenizer is None:
                tokenizer = get_hf_tokenizer(config.tokenizer)
                config._tokenizer_instance = tokenizer
            return tokenizer(result)

    return result
