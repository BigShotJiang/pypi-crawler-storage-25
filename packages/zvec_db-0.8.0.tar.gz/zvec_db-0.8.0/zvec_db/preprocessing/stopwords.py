"""Stopwords for French and English."""

from typing import Optional, Set

from .config import Language

# =============================================================================
# Stopwords
# =============================================================================

FRENCH_STOPWORDS: frozenset[str] = frozenset(
    {
        # Articles
        "le",
        "la",
        "les",
        "un",
        "une",
        "des",
        "du",
        "de",
        # Demonstratives
        "ce",
        "cet",
        "cette",
        "ces",
        # Possessives
        "mon",
        "ma",
        "mes",
        "ton",
        "ta",
        "tes",
        "son",
        "sa",
        "ses",
        "notre",
        "nos",
        "votre",
        "vos",
        "leur",
        "leurs",
        # Pronouns
        "il",
        "elle",
        "ils",
        "elles",
        "je",
        "tu",
        "nous",
        "vous",
        "on",
        "me",
        "te",
        "se",
        "lui",
        "leur",
        "y",
        "en",
        # Conjunctions
        "et",
        "ou",
        "mais",
        "donc",
        "or",
        "ni",
        "car",
        "comme",
        "si",
        "quand",
        # Prepositions
        "pour",
        "par",
        "sur",
        "dans",
        "avec",
        "sans",
        "sous",
        "entre",
        "vers",
        "à",
        "au",
        "aux",
        "chez",
        "contre",
        # Verbs (common forms)
        "a",
        "ont",
        "est",
        "sont",
        "être",
        "avoir",
        "faire",
        "dire",
        "pouvoir",
        "voir",
        "donner",
        # Quantifiers
        "tout",
        "tous",
        "toute",
        "toutes",
        "même",
        "mêmes",
        # Adverbs
        "plus",
        "moins",
        "très",
        "bien",
        "ne",
        "pas",
        "jamais",
        "rien",
        # Others
        "ci",
        "là",
        "dont",
        "où",
        "que",
        "qui",
        "quoi",
        "quel",
        "ceci",
        "cela",
        "ça",
        # Contractions (single letters)
        "c",
        "d",
        "j",
        "l",
        "m",
        "n",
        "s",
        "t",
    }
)

ENGLISH_STOPWORDS: frozenset[str] = frozenset(
    {
        # Articles
        "a",
        "an",
        "the",
        # Conjunctions
        "and",
        "or",
        "but",
        "if",
        "then",
        "else",
        "when",
        "while",
        # Prepositions
        "as",
        "at",
        "by",
        "for",
        "from",
        "in",
        "of",
        "on",
        "to",
        "with",
        "up",
        "out",
        "down",
        "over",
        "under",
        "into",
        "through",
        "about",
        "after",
        "against",
        "before",
        "below",
        "between",
        "during",
        # Pronouns
        "he",
        "she",
        "it",
        "they",
        "we",
        "you",
        "i",
        "his",
        "her",
        "its",
        "their",
        "our",
        "your",
        "mine",
        "ours",
        "theirs",
        "him",
        "them",
        "us",
        "me",
        # Verbs (common forms)
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        # Demonstratives
        "this",
        "that",
        "these",
        "those",
        "such",
        # Quantifiers
        "all",
        "each",
        "every",
        "both",
        "few",
        "more",
        "most",
        "other",
        "some",
        # Negations
        "no",
        "not",
        "only",
        "own",
        "same",
        "so",
        "than",
        "too",
        "very",
        # Modals
        "can",
        "will",
        "just",
        "should",
        "now",
    }
)

# Language-specific stopwords mapping
STOPWORDS_MAP: dict[Language, frozenset[str]] = {
    "french": FRENCH_STOPWORDS,
    "english": ENGLISH_STOPWORDS,
}


def get_stopwords(language: Language) -> frozenset[str]:
    """Get stopwords for a specified language.

    Args:
        language: Language ("french" or "english").

    Returns:
        Frozen set of stopwords for the specified language.

    Example:
        >>> len(get_stopwords("french"))
        111
    """
    return STOPWORDS_MAP.get(language, FRENCH_STOPWORDS)


def remove_stopwords(
    text: str,
    language: Language = "french",
    additional_stopwords: Optional[Set[str]] = None,
) -> str:
    """Remove stopwords from text.

    Args:
        text: Input text to process.
        language: Language for stopwords ("french" or "english").
        additional_stopwords: Optional set of additional stopwords to remove.

    Returns:
        Text with stopwords removed.

    Example:
        >>> remove_stopwords("le chat mange la souris", language="french")
        'chat mange souris'
    """
    if not text:
        return text

    stopwords = get_stopwords(language)

    if additional_stopwords:
        stopwords = stopwords.union(additional_stopwords)

    words = text.split()
    filtered = [w for w in words if w.lower() not in stopwords]

    return " ".join(filtered)
