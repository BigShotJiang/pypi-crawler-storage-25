"""Text normalization utilities."""

import re
import unicodedata

# =============================================================================
# Basic normalization functions
# =============================================================================


def remove_accents(text: str) -> str:
    """Remove accents from a string.

    Converts accented characters to their ASCII equivalents using
    Unicode NFD (Canonical Decomposition) and filtering out combining
    characters.

    Args:
        text: Input text with potential accented characters.

    Returns:
        Text with accents removed.

    Example:
        >>> remove_accents("café résumé naïve")
        'cafe resume naive'
        >>> remove_accents("àéïôû")
        'aeiou'
    """
    if not text:
        return text
    nfd = unicodedata.normalize("NFD", text)
    return "".join(c for c in nfd if unicodedata.category(c) != "Mn")


def normalize_whitespace(text: str) -> str:
    """Normalize whitespace in a string.

    Replaces all sequences of whitespace characters with a single space,
    and strips leading/trailing whitespace.

    Args:
        text: Input text with potential irregular whitespace.

    Returns:
        Text with normalized whitespace.

    Example:
        >>> normalize_whitespace("too   many\\n\\nspaces")
        'too many spaces'
        >>> normalize_whitespace("  leading and trailing  ")
        'leading and trailing'
    """
    if not text:
        return text
    return re.sub(r"\s+", " ", text).strip()


def strip_punctuation(text: str) -> str:
    """Remove punctuation characters from text.

    Removes common punctuation marks while preserving alphanumeric
    characters and whitespace.

    Args:
        text: Input text with potential punctuation.

    Returns:
        Text with punctuation removed.

    Example:
        >>> strip_punctuation("Hello, world! How are you?")
        'Hello world How are you'
        >>> strip_punctuation("test...")
        'test'
    """
    if not text:
        return text
    return re.sub(r"[^\w\s]", "", text)
