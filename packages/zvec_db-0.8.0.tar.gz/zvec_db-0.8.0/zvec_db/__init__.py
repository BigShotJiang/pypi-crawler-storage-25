"""zvec-db: Utilities for sparse/dense vectorization and reranking.

This library provides embedders for sparse and dense vectorization, as well as
rerankers for post-processing and combining search results. It is designed to
work with zvec (https://github.com/ccdv-ai/zvec).

Example Usage
-------------
::

    from zvec_db import BM25Embedder, SentenceTransformersEmbedder
    from zvec_db import WeightedReranker

    # Sparse embedding (keys are automatically sorted for zvec compatibility)
    bm25 = BM25Embedder(max_features=4096)
    bm25.fit(documents)
    sparse_vector = bm25("query")  # Keys sorted automatically

    # Dense embedding
    dense = SentenceTransformersEmbedder(model_name="all-MiniLM-L6-v2")
    dense.fit(documents)
    dense_vector = dense("query")

    # Reranking
    reranker = WeightedReranker(
        weights={"sparse": 0.4, "dense": 0.6},
        normalize="bayes",
    )
"""

from .embedders import (  # Sparse; Dense
    BM25Embedder,
    BM25LEmbedder,
    BM25PlusEmbedder,
    CountEmbedder,
    DisMaxEmbedder,
    OpenAIEmbedder,
    SentenceTransformersEmbedder,
    TfidfEmbedder,
)
from .embedders.base import SparseVector
from .preprocessing import (
    NormalizationConfig,
    normalize_text,
    remove_stopwords,
    stem_word,
)
from .rerankers import (  # Fusion; Cross-encoder; Utils
    BaseCrossEncoderReranker,
    ClassificationReranker,
    MultiFieldWeightedReranker,
    OpenAIDecoderReranker,
    OpenAIEncoderReranker,
    OpenAIReranker,
    PipelineReranker,
    RrfReranker,
    SentenceTransformerReranker,
    WeightedReranker,
)

__all__ = [
    # Sparse Embedders
    "BM25Embedder",
    "BM25LEmbedder",
    "BM25PlusEmbedder",
    "TfidfEmbedder",
    "CountEmbedder",
    "DisMaxEmbedder",
    # Dense Embedders
    "SentenceTransformersEmbedder",
    "OpenAIEmbedder",
    # Fusion Rerankers
    "RrfReranker",
    "WeightedReranker",
    "MultiFieldWeightedReranker",
    # Cross-encoder Rerankers
    "BaseCrossEncoderReranker",
    "SentenceTransformerReranker",
    "ClassificationReranker",
    "OpenAIReranker",
    "OpenAIEncoderReranker",
    "OpenAIDecoderReranker",
    # Utils
    "PipelineReranker",
    "SparseVector",
    # Preprocessing
    "NormalizationConfig",
    "normalize_text",
    "stem_word",
    "remove_stopwords",
]
