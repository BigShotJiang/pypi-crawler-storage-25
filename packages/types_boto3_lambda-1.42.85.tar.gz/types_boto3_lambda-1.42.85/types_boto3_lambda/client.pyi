"""
Type annotations for lambda service Client.

[Documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/)

Copyright 2026 Vlad Emelianov

Usage::

    ```python
    from boto3.session import Session
    from types_boto3_lambda.client import LambdaClient

    session = Session()
    client: LambdaClient = session.client("lambda")
    ```
"""

from __future__ import annotations

import sys
from collections.abc import Mapping
from typing import Any, overload

from botocore.client import BaseClient, ClientMeta
from botocore.errorfactory import BaseClientExceptions
from botocore.exceptions import ClientError as BotocoreClientError

from .paginator import (
    GetDurableExecutionHistoryPaginator,
    GetDurableExecutionStatePaginator,
    ListAliasesPaginator,
    ListCapacityProvidersPaginator,
    ListCodeSigningConfigsPaginator,
    ListDurableExecutionsByFunctionPaginator,
    ListEventSourceMappingsPaginator,
    ListFunctionEventInvokeConfigsPaginator,
    ListFunctionsByCodeSigningConfigPaginator,
    ListFunctionsPaginator,
    ListFunctionUrlConfigsPaginator,
    ListFunctionVersionsByCapacityProviderPaginator,
    ListLayersPaginator,
    ListLayerVersionsPaginator,
    ListProvisionedConcurrencyConfigsPaginator,
    ListVersionsByFunctionPaginator,
)
from .type_defs import (
    AddLayerVersionPermissionRequestTypeDef,
    AddLayerVersionPermissionResponseTypeDef,
    AddPermissionRequestTypeDef,
    AddPermissionResponseTypeDef,
    AliasConfigurationResponseTypeDef,
    CheckpointDurableExecutionRequestTypeDef,
    CheckpointDurableExecutionResponseTypeDef,
    ConcurrencyResponseTypeDef,
    CreateAliasRequestTypeDef,
    CreateCapacityProviderRequestTypeDef,
    CreateCapacityProviderResponseTypeDef,
    CreateCodeSigningConfigRequestTypeDef,
    CreateCodeSigningConfigResponseTypeDef,
    CreateEventSourceMappingRequestTypeDef,
    CreateFunctionRequestTypeDef,
    CreateFunctionUrlConfigRequestTypeDef,
    CreateFunctionUrlConfigResponseTypeDef,
    DeleteAliasRequestTypeDef,
    DeleteCapacityProviderRequestTypeDef,
    DeleteCapacityProviderResponseTypeDef,
    DeleteCodeSigningConfigRequestTypeDef,
    DeleteEventSourceMappingRequestTypeDef,
    DeleteFunctionCodeSigningConfigRequestTypeDef,
    DeleteFunctionConcurrencyRequestTypeDef,
    DeleteFunctionEventInvokeConfigRequestTypeDef,
    DeleteFunctionRequestTypeDef,
    DeleteFunctionResponseTypeDef,
    DeleteFunctionUrlConfigRequestTypeDef,
    DeleteLayerVersionRequestTypeDef,
    DeleteProvisionedConcurrencyConfigRequestTypeDef,
    EmptyResponseMetadataTypeDef,
    EventSourceMappingConfigurationResponseTypeDef,
    FunctionConfigurationResponseTypeDef,
    FunctionEventInvokeConfigResponseTypeDef,
    GetAccountSettingsResponseTypeDef,
    GetAliasRequestTypeDef,
    GetCapacityProviderRequestTypeDef,
    GetCapacityProviderResponseTypeDef,
    GetCodeSigningConfigRequestTypeDef,
    GetCodeSigningConfigResponseTypeDef,
    GetDurableExecutionHistoryRequestTypeDef,
    GetDurableExecutionHistoryResponseTypeDef,
    GetDurableExecutionRequestTypeDef,
    GetDurableExecutionResponseTypeDef,
    GetDurableExecutionStateRequestTypeDef,
    GetDurableExecutionStateResponseTypeDef,
    GetEventSourceMappingRequestTypeDef,
    GetFunctionCodeSigningConfigRequestTypeDef,
    GetFunctionCodeSigningConfigResponseTypeDef,
    GetFunctionConcurrencyRequestTypeDef,
    GetFunctionConcurrencyResponseTypeDef,
    GetFunctionConfigurationRequestTypeDef,
    GetFunctionEventInvokeConfigRequestTypeDef,
    GetFunctionRecursionConfigRequestTypeDef,
    GetFunctionRecursionConfigResponseTypeDef,
    GetFunctionRequestTypeDef,
    GetFunctionResponseTypeDef,
    GetFunctionScalingConfigRequestTypeDef,
    GetFunctionScalingConfigResponseTypeDef,
    GetFunctionUrlConfigRequestTypeDef,
    GetFunctionUrlConfigResponseTypeDef,
    GetLayerVersionByArnRequestTypeDef,
    GetLayerVersionPolicyRequestTypeDef,
    GetLayerVersionPolicyResponseTypeDef,
    GetLayerVersionRequestTypeDef,
    GetLayerVersionResponseTypeDef,
    GetPolicyRequestTypeDef,
    GetPolicyResponseTypeDef,
    GetProvisionedConcurrencyConfigRequestTypeDef,
    GetProvisionedConcurrencyConfigResponseTypeDef,
    GetRuntimeManagementConfigRequestTypeDef,
    GetRuntimeManagementConfigResponseTypeDef,
    InvocationRequestTypeDef,
    InvocationResponseTypeDef,
    InvokeAsyncRequestTypeDef,
    InvokeAsyncResponseTypeDef,
    InvokeWithResponseStreamRequestTypeDef,
    InvokeWithResponseStreamResponseTypeDef,
    ListAliasesRequestTypeDef,
    ListAliasesResponseTypeDef,
    ListCapacityProvidersRequestTypeDef,
    ListCapacityProvidersResponseTypeDef,
    ListCodeSigningConfigsRequestTypeDef,
    ListCodeSigningConfigsResponseTypeDef,
    ListDurableExecutionsByFunctionRequestTypeDef,
    ListDurableExecutionsByFunctionResponseTypeDef,
    ListEventSourceMappingsRequestTypeDef,
    ListEventSourceMappingsResponseTypeDef,
    ListFunctionEventInvokeConfigsRequestTypeDef,
    ListFunctionEventInvokeConfigsResponseTypeDef,
    ListFunctionsByCodeSigningConfigRequestTypeDef,
    ListFunctionsByCodeSigningConfigResponseTypeDef,
    ListFunctionsRequestTypeDef,
    ListFunctionsResponseTypeDef,
    ListFunctionUrlConfigsRequestTypeDef,
    ListFunctionUrlConfigsResponseTypeDef,
    ListFunctionVersionsByCapacityProviderRequestTypeDef,
    ListFunctionVersionsByCapacityProviderResponseTypeDef,
    ListLayersRequestTypeDef,
    ListLayersResponseTypeDef,
    ListLayerVersionsRequestTypeDef,
    ListLayerVersionsResponseTypeDef,
    ListProvisionedConcurrencyConfigsRequestTypeDef,
    ListProvisionedConcurrencyConfigsResponseTypeDef,
    ListTagsRequestTypeDef,
    ListTagsResponseTypeDef,
    ListVersionsByFunctionRequestTypeDef,
    ListVersionsByFunctionResponseTypeDef,
    PublishLayerVersionRequestTypeDef,
    PublishLayerVersionResponseTypeDef,
    PublishVersionRequestTypeDef,
    PutFunctionCodeSigningConfigRequestTypeDef,
    PutFunctionCodeSigningConfigResponseTypeDef,
    PutFunctionConcurrencyRequestTypeDef,
    PutFunctionEventInvokeConfigRequestTypeDef,
    PutFunctionRecursionConfigRequestTypeDef,
    PutFunctionRecursionConfigResponseTypeDef,
    PutFunctionScalingConfigRequestTypeDef,
    PutFunctionScalingConfigResponseTypeDef,
    PutProvisionedConcurrencyConfigRequestTypeDef,
    PutProvisionedConcurrencyConfigResponseTypeDef,
    PutRuntimeManagementConfigRequestTypeDef,
    PutRuntimeManagementConfigResponseTypeDef,
    RemoveLayerVersionPermissionRequestTypeDef,
    RemovePermissionRequestTypeDef,
    SendDurableExecutionCallbackFailureRequestTypeDef,
    SendDurableExecutionCallbackHeartbeatRequestTypeDef,
    SendDurableExecutionCallbackSuccessRequestTypeDef,
    StopDurableExecutionRequestTypeDef,
    StopDurableExecutionResponseTypeDef,
    TagResourceRequestTypeDef,
    UntagResourceRequestTypeDef,
    UpdateAliasRequestTypeDef,
    UpdateCapacityProviderRequestTypeDef,
    UpdateCapacityProviderResponseTypeDef,
    UpdateCodeSigningConfigRequestTypeDef,
    UpdateCodeSigningConfigResponseTypeDef,
    UpdateEventSourceMappingRequestTypeDef,
    UpdateFunctionCodeRequestTypeDef,
    UpdateFunctionConfigurationRequestTypeDef,
    UpdateFunctionEventInvokeConfigRequestTypeDef,
    UpdateFunctionUrlConfigRequestTypeDef,
    UpdateFunctionUrlConfigResponseTypeDef,
)
from .waiter import (
    FunctionActiveV2Waiter,
    FunctionActiveWaiter,
    FunctionExistsWaiter,
    FunctionUpdatedV2Waiter,
    FunctionUpdatedWaiter,
    PublishedVersionActiveWaiter,
)

if sys.version_info >= (3, 12):
    from typing import Literal, Unpack
else:
    from typing_extensions import Literal, Unpack

__all__ = ("LambdaClient",)

class Exceptions(BaseClientExceptions):
    CallbackTimeoutException: type[BotocoreClientError]
    CapacityProviderLimitExceededException: type[BotocoreClientError]
    ClientError: type[BotocoreClientError]
    CodeSigningConfigNotFoundException: type[BotocoreClientError]
    CodeStorageExceededException: type[BotocoreClientError]
    CodeVerificationFailedException: type[BotocoreClientError]
    DurableExecutionAlreadyStartedException: type[BotocoreClientError]
    EC2AccessDeniedException: type[BotocoreClientError]
    EC2ThrottledException: type[BotocoreClientError]
    EC2UnexpectedException: type[BotocoreClientError]
    EFSIOException: type[BotocoreClientError]
    EFSMountConnectivityException: type[BotocoreClientError]
    EFSMountFailureException: type[BotocoreClientError]
    EFSMountTimeoutException: type[BotocoreClientError]
    ENILimitReachedException: type[BotocoreClientError]
    FunctionVersionsPerCapacityProviderLimitExceededException: type[BotocoreClientError]
    InvalidCodeSignatureException: type[BotocoreClientError]
    InvalidParameterValueException: type[BotocoreClientError]
    InvalidRequestContentException: type[BotocoreClientError]
    InvalidRuntimeException: type[BotocoreClientError]
    InvalidSecurityGroupIDException: type[BotocoreClientError]
    InvalidSubnetIDException: type[BotocoreClientError]
    InvalidZipFileException: type[BotocoreClientError]
    KMSAccessDeniedException: type[BotocoreClientError]
    KMSDisabledException: type[BotocoreClientError]
    KMSInvalidStateException: type[BotocoreClientError]
    KMSNotFoundException: type[BotocoreClientError]
    NoPublishedVersionException: type[BotocoreClientError]
    PolicyLengthExceededException: type[BotocoreClientError]
    PreconditionFailedException: type[BotocoreClientError]
    ProvisionedConcurrencyConfigNotFoundException: type[BotocoreClientError]
    RecursiveInvocationException: type[BotocoreClientError]
    RequestTooLargeException: type[BotocoreClientError]
    ResourceConflictException: type[BotocoreClientError]
    ResourceInUseException: type[BotocoreClientError]
    ResourceNotFoundException: type[BotocoreClientError]
    ResourceNotReadyException: type[BotocoreClientError]
    S3FilesMountConnectivityException: type[BotocoreClientError]
    S3FilesMountFailureException: type[BotocoreClientError]
    S3FilesMountTimeoutException: type[BotocoreClientError]
    SerializedRequestEntityTooLargeException: type[BotocoreClientError]
    ServiceException: type[BotocoreClientError]
    SnapStartException: type[BotocoreClientError]
    SnapStartNotReadyException: type[BotocoreClientError]
    SnapStartTimeoutException: type[BotocoreClientError]
    SubnetIPAddressLimitReachedException: type[BotocoreClientError]
    TooManyRequestsException: type[BotocoreClientError]
    UnsupportedMediaTypeException: type[BotocoreClientError]

class LambdaClient(BaseClient):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda.html#Lambda.Client)
    [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/)
    """

    meta: ClientMeta

    @property
    def exceptions(self) -> Exceptions:
        """
        LambdaClient exceptions.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda.html#Lambda.Client)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#exceptions)
        """

    def can_paginate(self, operation_name: str) -> bool:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/can_paginate.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#can_paginate)
        """

    def generate_presigned_url(
        self,
        ClientMethod: str,
        Params: Mapping[str, Any] = ...,
        ExpiresIn: int = 3600,
        HttpMethod: str = ...,
    ) -> str:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/generate_presigned_url.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#generate_presigned_url)
        """

    def add_layer_version_permission(
        self, **kwargs: Unpack[AddLayerVersionPermissionRequestTypeDef]
    ) -> AddLayerVersionPermissionResponseTypeDef:
        """
        Adds permissions to the resource-based policy of a version of an <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuration-layers.html">Lambda
        layer</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/add_layer_version_permission.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#add_layer_version_permission)
        """

    def add_permission(
        self, **kwargs: Unpack[AddPermissionRequestTypeDef]
    ) -> AddPermissionResponseTypeDef:
        """
        Grants a <a
        href="https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_elements_principal.html#Principal_specifying">principal</a>
        permission to use a function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/add_permission.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#add_permission)
        """

    def checkpoint_durable_execution(
        self, **kwargs: Unpack[CheckpointDurableExecutionRequestTypeDef]
    ) -> CheckpointDurableExecutionResponseTypeDef:
        """
        Saves the progress of a <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/durable-functions.html">durable
        function</a> execution during runtime.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/checkpoint_durable_execution.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#checkpoint_durable_execution)
        """

    def create_alias(
        self, **kwargs: Unpack[CreateAliasRequestTypeDef]
    ) -> AliasConfigurationResponseTypeDef:
        """
        Creates an <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuration-aliases.html">alias</a>
        for a Lambda function version.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/create_alias.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#create_alias)
        """

    def create_capacity_provider(
        self, **kwargs: Unpack[CreateCapacityProviderRequestTypeDef]
    ) -> CreateCapacityProviderResponseTypeDef:
        """
        Creates a capacity provider that manages compute resources for Lambda functions.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/create_capacity_provider.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#create_capacity_provider)
        """

    def create_code_signing_config(
        self, **kwargs: Unpack[CreateCodeSigningConfigRequestTypeDef]
    ) -> CreateCodeSigningConfigResponseTypeDef:
        """
        Creates a code signing configuration.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/create_code_signing_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#create_code_signing_config)
        """

    def create_event_source_mapping(
        self, **kwargs: Unpack[CreateEventSourceMappingRequestTypeDef]
    ) -> EventSourceMappingConfigurationResponseTypeDef:
        """
        Creates a mapping between an event source and an Lambda function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/create_event_source_mapping.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#create_event_source_mapping)
        """

    def create_function(
        self, **kwargs: Unpack[CreateFunctionRequestTypeDef]
    ) -> FunctionConfigurationResponseTypeDef:
        """
        Creates a Lambda function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/create_function.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#create_function)
        """

    def create_function_url_config(
        self, **kwargs: Unpack[CreateFunctionUrlConfigRequestTypeDef]
    ) -> CreateFunctionUrlConfigResponseTypeDef:
        """
        Creates a Lambda function URL with the specified configuration parameters.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/create_function_url_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#create_function_url_config)
        """

    def delete_alias(
        self, **kwargs: Unpack[DeleteAliasRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Deletes a Lambda function <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuration-aliases.html">alias</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/delete_alias.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#delete_alias)
        """

    def delete_capacity_provider(
        self, **kwargs: Unpack[DeleteCapacityProviderRequestTypeDef]
    ) -> DeleteCapacityProviderResponseTypeDef:
        """
        Deletes a capacity provider.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/delete_capacity_provider.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#delete_capacity_provider)
        """

    def delete_code_signing_config(
        self, **kwargs: Unpack[DeleteCodeSigningConfigRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Deletes the code signing configuration.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/delete_code_signing_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#delete_code_signing_config)
        """

    def delete_event_source_mapping(
        self, **kwargs: Unpack[DeleteEventSourceMappingRequestTypeDef]
    ) -> EventSourceMappingConfigurationResponseTypeDef:
        """
        Deletes an <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/intro-invocation-modes.html">event
        source mapping</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/delete_event_source_mapping.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#delete_event_source_mapping)
        """

    def delete_function(
        self, **kwargs: Unpack[DeleteFunctionRequestTypeDef]
    ) -> DeleteFunctionResponseTypeDef:
        """
        Deletes a Lambda function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/delete_function.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#delete_function)
        """

    def delete_function_code_signing_config(
        self, **kwargs: Unpack[DeleteFunctionCodeSigningConfigRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Removes the code signing configuration from the function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/delete_function_code_signing_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#delete_function_code_signing_config)
        """

    def delete_function_concurrency(
        self, **kwargs: Unpack[DeleteFunctionConcurrencyRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Removes a concurrent execution limit from a function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/delete_function_concurrency.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#delete_function_concurrency)
        """

    def delete_function_event_invoke_config(
        self, **kwargs: Unpack[DeleteFunctionEventInvokeConfigRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Deletes the configuration for asynchronous invocation for a function, version,
        or alias.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/delete_function_event_invoke_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#delete_function_event_invoke_config)
        """

    def delete_function_url_config(
        self, **kwargs: Unpack[DeleteFunctionUrlConfigRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Deletes a Lambda function URL.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/delete_function_url_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#delete_function_url_config)
        """

    def delete_layer_version(
        self, **kwargs: Unpack[DeleteLayerVersionRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Deletes a version of an <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuration-layers.html">Lambda
        layer</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/delete_layer_version.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#delete_layer_version)
        """

    def delete_provisioned_concurrency_config(
        self, **kwargs: Unpack[DeleteProvisionedConcurrencyConfigRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Deletes the provisioned concurrency configuration for a function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/delete_provisioned_concurrency_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#delete_provisioned_concurrency_config)
        """

    def get_account_settings(self) -> GetAccountSettingsResponseTypeDef:
        """
        Retrieves details about your account's <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/limits.html">limits</a> and
        usage in an Amazon Web Services Region.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_account_settings.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_account_settings)
        """

    def get_alias(
        self, **kwargs: Unpack[GetAliasRequestTypeDef]
    ) -> AliasConfigurationResponseTypeDef:
        """
        Returns details about a Lambda function <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuration-aliases.html">alias</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_alias.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_alias)
        """

    def get_capacity_provider(
        self, **kwargs: Unpack[GetCapacityProviderRequestTypeDef]
    ) -> GetCapacityProviderResponseTypeDef:
        """
        Retrieves information about a specific capacity provider, including its
        configuration, state, and associated resources.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_capacity_provider.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_capacity_provider)
        """

    def get_code_signing_config(
        self, **kwargs: Unpack[GetCodeSigningConfigRequestTypeDef]
    ) -> GetCodeSigningConfigResponseTypeDef:
        """
        Returns information about the specified code signing configuration.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_code_signing_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_code_signing_config)
        """

    def get_durable_execution(
        self, **kwargs: Unpack[GetDurableExecutionRequestTypeDef]
    ) -> GetDurableExecutionResponseTypeDef:
        """
        Retrieves detailed information about a specific <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/durable-functions.html">durable
        execution</a>, including its current status, input payload, result or error
        information, and execution metadata such as start time and usage statistics.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_durable_execution.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_durable_execution)
        """

    def get_durable_execution_history(
        self, **kwargs: Unpack[GetDurableExecutionHistoryRequestTypeDef]
    ) -> GetDurableExecutionHistoryResponseTypeDef:
        """
        Retrieves the execution history for a <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/durable-functions.html">durable
        execution</a>, showing all the steps, callbacks, and events that occurred
        during the execution.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_durable_execution_history.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_durable_execution_history)
        """

    def get_durable_execution_state(
        self, **kwargs: Unpack[GetDurableExecutionStateRequestTypeDef]
    ) -> GetDurableExecutionStateResponseTypeDef:
        """
        Retrieves the current execution state required for the replay process during <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/durable-functions.html">durable
        function</a> execution.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_durable_execution_state.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_durable_execution_state)
        """

    def get_event_source_mapping(
        self, **kwargs: Unpack[GetEventSourceMappingRequestTypeDef]
    ) -> EventSourceMappingConfigurationResponseTypeDef:
        """
        Returns details about an event source mapping.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_event_source_mapping.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_event_source_mapping)
        """

    def get_function(
        self, **kwargs: Unpack[GetFunctionRequestTypeDef]
    ) -> GetFunctionResponseTypeDef:
        """
        Returns information about the function or function version, with a link to
        download the deployment package that's valid for 10 minutes.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_function.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_function)
        """

    def get_function_code_signing_config(
        self, **kwargs: Unpack[GetFunctionCodeSigningConfigRequestTypeDef]
    ) -> GetFunctionCodeSigningConfigResponseTypeDef:
        """
        Returns the code signing configuration for the specified function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_function_code_signing_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_function_code_signing_config)
        """

    def get_function_concurrency(
        self, **kwargs: Unpack[GetFunctionConcurrencyRequestTypeDef]
    ) -> GetFunctionConcurrencyResponseTypeDef:
        """
        Returns details about the reserved concurrency configuration for a function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_function_concurrency.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_function_concurrency)
        """

    def get_function_configuration(
        self, **kwargs: Unpack[GetFunctionConfigurationRequestTypeDef]
    ) -> FunctionConfigurationResponseTypeDef:
        """
        Returns the version-specific settings of a Lambda function or version.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_function_configuration.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_function_configuration)
        """

    def get_function_event_invoke_config(
        self, **kwargs: Unpack[GetFunctionEventInvokeConfigRequestTypeDef]
    ) -> FunctionEventInvokeConfigResponseTypeDef:
        """
        Retrieves the configuration for asynchronous invocation for a function,
        version, or alias.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_function_event_invoke_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_function_event_invoke_config)
        """

    def get_function_recursion_config(
        self, **kwargs: Unpack[GetFunctionRecursionConfigRequestTypeDef]
    ) -> GetFunctionRecursionConfigResponseTypeDef:
        """
        Returns your function's <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/invocation-recursion.html">recursive
        loop detection</a> configuration.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_function_recursion_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_function_recursion_config)
        """

    def get_function_scaling_config(
        self, **kwargs: Unpack[GetFunctionScalingConfigRequestTypeDef]
    ) -> GetFunctionScalingConfigResponseTypeDef:
        """
        Retrieves the scaling configuration for a Lambda Managed Instances function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_function_scaling_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_function_scaling_config)
        """

    def get_function_url_config(
        self, **kwargs: Unpack[GetFunctionUrlConfigRequestTypeDef]
    ) -> GetFunctionUrlConfigResponseTypeDef:
        """
        Returns details about a Lambda function URL.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_function_url_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_function_url_config)
        """

    def get_layer_version(
        self, **kwargs: Unpack[GetLayerVersionRequestTypeDef]
    ) -> GetLayerVersionResponseTypeDef:
        """
        Returns information about a version of an <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuration-layers.html">Lambda
        layer</a>, with a link to download the layer archive that's valid for 10
        minutes.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_layer_version.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_layer_version)
        """

    def get_layer_version_by_arn(
        self, **kwargs: Unpack[GetLayerVersionByArnRequestTypeDef]
    ) -> GetLayerVersionResponseTypeDef:
        """
        Returns information about a version of an <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuration-layers.html">Lambda
        layer</a>, with a link to download the layer archive that's valid for 10
        minutes.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_layer_version_by_arn.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_layer_version_by_arn)
        """

    def get_layer_version_policy(
        self, **kwargs: Unpack[GetLayerVersionPolicyRequestTypeDef]
    ) -> GetLayerVersionPolicyResponseTypeDef:
        """
        Returns the permission policy for a version of an <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuration-layers.html">Lambda
        layer</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_layer_version_policy.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_layer_version_policy)
        """

    def get_policy(self, **kwargs: Unpack[GetPolicyRequestTypeDef]) -> GetPolicyResponseTypeDef:
        """
        Returns the <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/access-control-resource-based.html">resource-based
        IAM policy</a> for a function, version, or alias.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_policy.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_policy)
        """

    def get_provisioned_concurrency_config(
        self, **kwargs: Unpack[GetProvisionedConcurrencyConfigRequestTypeDef]
    ) -> GetProvisionedConcurrencyConfigResponseTypeDef:
        """
        Retrieves the provisioned concurrency configuration for a function's alias or
        version.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_provisioned_concurrency_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_provisioned_concurrency_config)
        """

    def get_runtime_management_config(
        self, **kwargs: Unpack[GetRuntimeManagementConfigRequestTypeDef]
    ) -> GetRuntimeManagementConfigResponseTypeDef:
        """
        Retrieves the runtime management configuration for a function's version.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_runtime_management_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_runtime_management_config)
        """

    def invoke(self, **kwargs: Unpack[InvocationRequestTypeDef]) -> InvocationResponseTypeDef:
        """
        Invokes a Lambda function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/invoke.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#invoke)
        """

    def invoke_async(
        self, **kwargs: Unpack[InvokeAsyncRequestTypeDef]
    ) -> InvokeAsyncResponseTypeDef:
        """
        <note> <p>For asynchronous function invocation, use <a>Invoke</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/invoke_async.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#invoke_async)
        """

    def invoke_with_response_stream(
        self, **kwargs: Unpack[InvokeWithResponseStreamRequestTypeDef]
    ) -> InvokeWithResponseStreamResponseTypeDef:
        """
        Configure your Lambda functions to stream response payloads back to clients.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/invoke_with_response_stream.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#invoke_with_response_stream)
        """

    def list_aliases(
        self, **kwargs: Unpack[ListAliasesRequestTypeDef]
    ) -> ListAliasesResponseTypeDef:
        """
        Returns a list of <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuration-aliases.html">aliases</a>
        for a Lambda function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_aliases.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_aliases)
        """

    def list_capacity_providers(
        self, **kwargs: Unpack[ListCapacityProvidersRequestTypeDef]
    ) -> ListCapacityProvidersResponseTypeDef:
        """
        Returns a list of capacity providers in your account.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_capacity_providers.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_capacity_providers)
        """

    def list_code_signing_configs(
        self, **kwargs: Unpack[ListCodeSigningConfigsRequestTypeDef]
    ) -> ListCodeSigningConfigsResponseTypeDef:
        """
        Returns a list of <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuring-codesigning.html">code
        signing configurations</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_code_signing_configs.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_code_signing_configs)
        """

    def list_durable_executions_by_function(
        self, **kwargs: Unpack[ListDurableExecutionsByFunctionRequestTypeDef]
    ) -> ListDurableExecutionsByFunctionResponseTypeDef:
        """
        Returns a list of <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/durable-functions.html">durable
        executions</a> for a specified Lambda function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_durable_executions_by_function.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_durable_executions_by_function)
        """

    def list_event_source_mappings(
        self, **kwargs: Unpack[ListEventSourceMappingsRequestTypeDef]
    ) -> ListEventSourceMappingsResponseTypeDef:
        """
        Lists event source mappings.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_event_source_mappings.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_event_source_mappings)
        """

    def list_function_event_invoke_configs(
        self, **kwargs: Unpack[ListFunctionEventInvokeConfigsRequestTypeDef]
    ) -> ListFunctionEventInvokeConfigsResponseTypeDef:
        """
        Retrieves a list of configurations for asynchronous invocation for a function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_function_event_invoke_configs.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_function_event_invoke_configs)
        """

    def list_function_url_configs(
        self, **kwargs: Unpack[ListFunctionUrlConfigsRequestTypeDef]
    ) -> ListFunctionUrlConfigsResponseTypeDef:
        """
        Returns a list of Lambda function URLs for the specified function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_function_url_configs.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_function_url_configs)
        """

    def list_function_versions_by_capacity_provider(
        self, **kwargs: Unpack[ListFunctionVersionsByCapacityProviderRequestTypeDef]
    ) -> ListFunctionVersionsByCapacityProviderResponseTypeDef:
        """
        Returns a list of function versions that are configured to use a specific
        capacity provider.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_function_versions_by_capacity_provider.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_function_versions_by_capacity_provider)
        """

    def list_functions(
        self, **kwargs: Unpack[ListFunctionsRequestTypeDef]
    ) -> ListFunctionsResponseTypeDef:
        """
        Returns a list of Lambda functions, with the version-specific configuration of
        each.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_functions.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_functions)
        """

    def list_functions_by_code_signing_config(
        self, **kwargs: Unpack[ListFunctionsByCodeSigningConfigRequestTypeDef]
    ) -> ListFunctionsByCodeSigningConfigResponseTypeDef:
        """
        List the functions that use the specified code signing configuration.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_functions_by_code_signing_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_functions_by_code_signing_config)
        """

    def list_layer_versions(
        self, **kwargs: Unpack[ListLayerVersionsRequestTypeDef]
    ) -> ListLayerVersionsResponseTypeDef:
        """
        Lists the versions of an <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuration-layers.html">Lambda
        layer</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_layer_versions.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_layer_versions)
        """

    def list_layers(self, **kwargs: Unpack[ListLayersRequestTypeDef]) -> ListLayersResponseTypeDef:
        """
        Lists <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/invocation-layers.html">Lambda
        layers</a> and shows information about the latest version of each.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_layers.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_layers)
        """

    def list_provisioned_concurrency_configs(
        self, **kwargs: Unpack[ListProvisionedConcurrencyConfigsRequestTypeDef]
    ) -> ListProvisionedConcurrencyConfigsResponseTypeDef:
        """
        Retrieves a list of provisioned concurrency configurations for a function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_provisioned_concurrency_configs.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_provisioned_concurrency_configs)
        """

    def list_tags(self, **kwargs: Unpack[ListTagsRequestTypeDef]) -> ListTagsResponseTypeDef:
        """
        Returns a function, event source mapping, or code signing configuration's <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/tagging.html">tags</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_tags.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_tags)
        """

    def list_versions_by_function(
        self, **kwargs: Unpack[ListVersionsByFunctionRequestTypeDef]
    ) -> ListVersionsByFunctionResponseTypeDef:
        """
        Returns a list of <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/versioning-aliases.html">versions</a>,
        with the version-specific configuration of each.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/list_versions_by_function.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#list_versions_by_function)
        """

    def publish_layer_version(
        self, **kwargs: Unpack[PublishLayerVersionRequestTypeDef]
    ) -> PublishLayerVersionResponseTypeDef:
        """
        Creates an <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuration-layers.html">Lambda
        layer</a> from a ZIP archive.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/publish_layer_version.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#publish_layer_version)
        """

    def publish_version(
        self, **kwargs: Unpack[PublishVersionRequestTypeDef]
    ) -> FunctionConfigurationResponseTypeDef:
        """
        Creates a <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/versioning-aliases.html">version</a>
        from the current code and configuration of a function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/publish_version.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#publish_version)
        """

    def put_function_code_signing_config(
        self, **kwargs: Unpack[PutFunctionCodeSigningConfigRequestTypeDef]
    ) -> PutFunctionCodeSigningConfigResponseTypeDef:
        """
        Update the code signing configuration for the function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/put_function_code_signing_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#put_function_code_signing_config)
        """

    def put_function_concurrency(
        self, **kwargs: Unpack[PutFunctionConcurrencyRequestTypeDef]
    ) -> ConcurrencyResponseTypeDef:
        """
        Sets the maximum number of simultaneous executions for a function, and reserves
        capacity for that concurrency level.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/put_function_concurrency.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#put_function_concurrency)
        """

    def put_function_event_invoke_config(
        self, **kwargs: Unpack[PutFunctionEventInvokeConfigRequestTypeDef]
    ) -> FunctionEventInvokeConfigResponseTypeDef:
        """
        Configures options for <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/invocation-async.html">asynchronous
        invocation</a> on a function, version, or alias.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/put_function_event_invoke_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#put_function_event_invoke_config)
        """

    def put_function_recursion_config(
        self, **kwargs: Unpack[PutFunctionRecursionConfigRequestTypeDef]
    ) -> PutFunctionRecursionConfigResponseTypeDef:
        """
        Sets your function's <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/invocation-recursion.html">recursive
        loop detection</a> configuration.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/put_function_recursion_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#put_function_recursion_config)
        """

    def put_function_scaling_config(
        self, **kwargs: Unpack[PutFunctionScalingConfigRequestTypeDef]
    ) -> PutFunctionScalingConfigResponseTypeDef:
        """
        Sets the scaling configuration for a Lambda Managed Instances function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/put_function_scaling_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#put_function_scaling_config)
        """

    def put_provisioned_concurrency_config(
        self, **kwargs: Unpack[PutProvisionedConcurrencyConfigRequestTypeDef]
    ) -> PutProvisionedConcurrencyConfigResponseTypeDef:
        """
        Adds a provisioned concurrency configuration to a function's alias or version.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/put_provisioned_concurrency_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#put_provisioned_concurrency_config)
        """

    def put_runtime_management_config(
        self, **kwargs: Unpack[PutRuntimeManagementConfigRequestTypeDef]
    ) -> PutRuntimeManagementConfigResponseTypeDef:
        """
        Sets the runtime management configuration for a function's version.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/put_runtime_management_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#put_runtime_management_config)
        """

    def remove_layer_version_permission(
        self, **kwargs: Unpack[RemoveLayerVersionPermissionRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Removes a statement from the permissions policy for a version of an <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuration-layers.html">Lambda
        layer</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/remove_layer_version_permission.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#remove_layer_version_permission)
        """

    def remove_permission(
        self, **kwargs: Unpack[RemovePermissionRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Revokes function-use permission from an Amazon Web Services service or another
        Amazon Web Services account.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/remove_permission.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#remove_permission)
        """

    def send_durable_execution_callback_failure(
        self, **kwargs: Unpack[SendDurableExecutionCallbackFailureRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Sends a failure response for a callback operation in a durable execution.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/send_durable_execution_callback_failure.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#send_durable_execution_callback_failure)
        """

    def send_durable_execution_callback_heartbeat(
        self, **kwargs: Unpack[SendDurableExecutionCallbackHeartbeatRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Sends a heartbeat signal for a long-running callback operation to prevent
        timeout.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/send_durable_execution_callback_heartbeat.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#send_durable_execution_callback_heartbeat)
        """

    def send_durable_execution_callback_success(
        self, **kwargs: Unpack[SendDurableExecutionCallbackSuccessRequestTypeDef]
    ) -> dict[str, Any]:
        """
        Sends a successful completion response for a callback operation in a durable
        execution.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/send_durable_execution_callback_success.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#send_durable_execution_callback_success)
        """

    def stop_durable_execution(
        self, **kwargs: Unpack[StopDurableExecutionRequestTypeDef]
    ) -> StopDurableExecutionResponseTypeDef:
        """
        Stops a running <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/durable-functions.html">durable
        execution</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/stop_durable_execution.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#stop_durable_execution)
        """

    def tag_resource(
        self, **kwargs: Unpack[TagResourceRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Adds <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/tagging.html">tags</a> to a
        function, event source mapping, or code signing configuration.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/tag_resource.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#tag_resource)
        """

    def untag_resource(
        self, **kwargs: Unpack[UntagResourceRequestTypeDef]
    ) -> EmptyResponseMetadataTypeDef:
        """
        Removes <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/tagging.html">tags</a> from
        a function, event source mapping, or code signing configuration.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/untag_resource.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#untag_resource)
        """

    def update_alias(
        self, **kwargs: Unpack[UpdateAliasRequestTypeDef]
    ) -> AliasConfigurationResponseTypeDef:
        """
        Updates the configuration of a Lambda function <a
        href="https://docs.aws.amazon.com/lambda/latest/dg/configuration-aliases.html">alias</a>.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/update_alias.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#update_alias)
        """

    def update_capacity_provider(
        self, **kwargs: Unpack[UpdateCapacityProviderRequestTypeDef]
    ) -> UpdateCapacityProviderResponseTypeDef:
        """
        Updates the configuration of an existing capacity provider.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/update_capacity_provider.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#update_capacity_provider)
        """

    def update_code_signing_config(
        self, **kwargs: Unpack[UpdateCodeSigningConfigRequestTypeDef]
    ) -> UpdateCodeSigningConfigResponseTypeDef:
        """
        Update the code signing configuration.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/update_code_signing_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#update_code_signing_config)
        """

    def update_event_source_mapping(
        self, **kwargs: Unpack[UpdateEventSourceMappingRequestTypeDef]
    ) -> EventSourceMappingConfigurationResponseTypeDef:
        """
        Updates an event source mapping.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/update_event_source_mapping.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#update_event_source_mapping)
        """

    def update_function_code(
        self, **kwargs: Unpack[UpdateFunctionCodeRequestTypeDef]
    ) -> FunctionConfigurationResponseTypeDef:
        """
        Updates a Lambda function's code.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/update_function_code.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#update_function_code)
        """

    def update_function_configuration(
        self, **kwargs: Unpack[UpdateFunctionConfigurationRequestTypeDef]
    ) -> FunctionConfigurationResponseTypeDef:
        """
        Modify the version-specific settings of a Lambda function.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/update_function_configuration.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#update_function_configuration)
        """

    def update_function_event_invoke_config(
        self, **kwargs: Unpack[UpdateFunctionEventInvokeConfigRequestTypeDef]
    ) -> FunctionEventInvokeConfigResponseTypeDef:
        """
        Updates the configuration for asynchronous invocation for a function, version,
        or alias.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/update_function_event_invoke_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#update_function_event_invoke_config)
        """

    def update_function_url_config(
        self, **kwargs: Unpack[UpdateFunctionUrlConfigRequestTypeDef]
    ) -> UpdateFunctionUrlConfigResponseTypeDef:
        """
        Updates the configuration for a Lambda function URL.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/update_function_url_config.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#update_function_url_config)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["get_durable_execution_history"]
    ) -> GetDurableExecutionHistoryPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["get_durable_execution_state"]
    ) -> GetDurableExecutionStatePaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_aliases"]
    ) -> ListAliasesPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_capacity_providers"]
    ) -> ListCapacityProvidersPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_code_signing_configs"]
    ) -> ListCodeSigningConfigsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_durable_executions_by_function"]
    ) -> ListDurableExecutionsByFunctionPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_event_source_mappings"]
    ) -> ListEventSourceMappingsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_function_event_invoke_configs"]
    ) -> ListFunctionEventInvokeConfigsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_function_url_configs"]
    ) -> ListFunctionUrlConfigsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_function_versions_by_capacity_provider"]
    ) -> ListFunctionVersionsByCapacityProviderPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_functions_by_code_signing_config"]
    ) -> ListFunctionsByCodeSigningConfigPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_functions"]
    ) -> ListFunctionsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_layer_versions"]
    ) -> ListLayerVersionsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_layers"]
    ) -> ListLayersPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_provisioned_concurrency_configs"]
    ) -> ListProvisionedConcurrencyConfigsPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_paginator(  # type: ignore[override]
        self, operation_name: Literal["list_versions_by_function"]
    ) -> ListVersionsByFunctionPaginator:
        """
        Create a paginator for an operation.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_paginator.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_paginator)
        """

    @overload  # type: ignore[override]
    def get_waiter(  # type: ignore[override]
        self, waiter_name: Literal["function_active_v2"]
    ) -> FunctionActiveV2Waiter:
        """
        Returns an object that can wait for some condition.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_waiter.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_waiter)
        """

    @overload  # type: ignore[override]
    def get_waiter(  # type: ignore[override]
        self, waiter_name: Literal["function_active"]
    ) -> FunctionActiveWaiter:
        """
        Returns an object that can wait for some condition.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_waiter.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_waiter)
        """

    @overload  # type: ignore[override]
    def get_waiter(  # type: ignore[override]
        self, waiter_name: Literal["function_exists"]
    ) -> FunctionExistsWaiter:
        """
        Returns an object that can wait for some condition.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_waiter.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_waiter)
        """

    @overload  # type: ignore[override]
    def get_waiter(  # type: ignore[override]
        self, waiter_name: Literal["function_updated_v2"]
    ) -> FunctionUpdatedV2Waiter:
        """
        Returns an object that can wait for some condition.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_waiter.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_waiter)
        """

    @overload  # type: ignore[override]
    def get_waiter(  # type: ignore[override]
        self, waiter_name: Literal["function_updated"]
    ) -> FunctionUpdatedWaiter:
        """
        Returns an object that can wait for some condition.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_waiter.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_waiter)
        """

    @overload  # type: ignore[override]
    def get_waiter(  # type: ignore[override]
        self, waiter_name: Literal["published_version_active"]
    ) -> PublishedVersionActiveWaiter:
        """
        Returns an object that can wait for some condition.

        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/lambda/client/get_waiter.html)
        [Show types-boto3 documentation](https://youtype.github.io/types_boto3_docs/types_boto3_lambda/client/#get_waiter)
        """
