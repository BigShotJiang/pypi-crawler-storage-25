"""
@Author: 馒头 (chocolate)
@Email: neihanshenshou@163.com
@File: _ExceptionTools.py
@Time: 2023/12/22 19:58
"""


def hook_exceptions(exceptions: (tuple, set, list) = (Exception,), msg=""):
    """
    捕获指定的异常装饰器
    若未指定捕获的非基类异常(只是不建议是基类), 则默认是忽略其它异常捕获
    example: 若 exception_types = [AssertionError], 则只会捕获这个方法中抛出的AssertionError, 而会忽略类似于ValueError等其它异常
    :param exceptions: 指定的异常
    :param msg: 自定义异常描述
    :return: None
    """
    if isinstance(exceptions, (tuple, set, list)):
        exception_types = tuple(exceptions)
    elif isinstance(exceptions, type):
        exception_types = (exceptions,)
    elif exceptions is None:
        exception_types = tuple()

    else:
        raise Exception("参数类型错误: 需要将多个异常类以元组的形式上传")

    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)

            except exception_types as e:
                raise type(e)(msg or "指定的异常已被捕获")

            except Exception as e2:
                exception_types_name = [_.__name__ for _ in exception_types]
                from SteamedBun._LoggerTools.Logger import logger
                logger.warning(f"""
---------------------------------------------                    
当前的执行方法名称: {func.__name__}
未捕获到指定异常类型: {exception_types_name}
或者是故意忽略该异常: {type(e2).__name__}
--------------------------------------------- 
                    """, stacklevel=3)

        return wrapper

    return decorator


def ignore_exceptions(exceptions: (tuple, set, list) = (Exception,), msg=""):
    """
    忽略异常装饰器
    忽略指定的非基类异常(也可以是基类)
    example: 若 exception_types = [AssertionError], 若这个方法中抛出的AssertionError, 而会AssertionError异常, 捕获其它异常
    :param exceptions: 指定的异常
    :param msg: 自定义的异常描述
    :return: None
    """
    if isinstance(exceptions, (tuple, set, list)):
        exception_types = tuple(exceptions)
    elif isinstance(exceptions, type):
        exception_types = (exceptions,)
    elif exceptions is None:
        exception_types = tuple()

    else:
        raise Exception("参数类型错误: 需要将多个异常类以元组的形式上传")

    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except exception_types as e2:
                from SteamedBun._LoggerTools.Logger import logger
                logger.warning(f"""
---------------------------------------------                    
当前的执行方法名称: {func.__name__}
故意忽略的异常类型: {type(e2).__name__}
--------------------------------------------- 
                    """, stacklevel=3)
            except Exception as e:
                if msg:
                    e.args = (msg,)
                else:
                    exception_types_name = [_.__name__ for _ in exception_types]
                    e.args = (f"已经忽略指定异常:{exception_types_name}, 但捕获到其它异常: {type(e).__name__}",)
                raise e

        return wrapper

    return decorator
