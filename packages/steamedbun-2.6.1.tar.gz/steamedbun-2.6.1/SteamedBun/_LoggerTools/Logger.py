"""
@Author: 馒头 (chocolate)
@Email: neihanshenshou@163.com
@File: Logger.py
@Time: 2023/12/9 18:00
"""

import logging
import os
import sys
from pathlib import Path
from typing import Optional

from colorama import init, Fore, Style

init(autoreset=True, strip=False)


class LogLevels:
    CRITICAL = 50
    FATAL = CRITICAL
    ERROR = 40
    WARNING = 30
    WARN = WARNING
    STEP = 25
    INFO = 20
    CUSTOM = 15
    DEBUG = 10
    NOTSET = 0


# 注册自定义级别
logging.addLevelName(LogLevels.STEP, "STEP")
logging.addLevelName(LogLevels.CUSTOM, "CUSTOM")


class ColoredFormatter(logging.Formatter):
    LEVEL_COLOR_MAP = {
        LogLevels.DEBUG: Fore.BLUE,
        LogLevels.INFO: Fore.CYAN,
        LogLevels.STEP: Fore.GREEN,
        LogLevels.WARNING: Fore.YELLOW,
        LogLevels.ERROR: Fore.RED,
        LogLevels.CRITICAL: Fore.MAGENTA,
        LogLevels.CUSTOM: Fore.BLACK
    }

    def __init__(self, fmt, datefmt=None, use_color=True):
        super().__init__(fmt, datefmt)
        self.use_color = use_color

    def format(self, record):
        if not self.use_color:
            return super().format(record)

        # 保存原始属性
        orig_levelname = record.levelname
        orig_msg = record.msg

        # 1. 级别：颜色 + 加粗
        color = self.LEVEL_COLOR_MAP.get(record.levelno, "")
        record.levelname = f"{color}{Style.BRIGHT}{orig_levelname}{Style.RESET_ALL}"

        # 2. 消息：加粗
        record.msg = f"{Style.BRIGHT}{orig_msg}{Style.RESET_ALL}"

        # 3. 行号：加粗
        # record.lineno = f"{Style.BRIGHT}{orig_lineno}{Style.RESET_ALL}"

        # 格式化日志
        result = super().format(record)

        # 恢复原始值
        record.levelname = orig_levelname
        record.msg = orig_msg
        return result


# ===================== 核心日志器 =====================
class AppLogger:
    _instance: Optional['AppLogger'] = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        """单例模式，避免重复创建"""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, name: str = "app_logger"):
        if self._initialized:
            return
        # 1. 创建根日志器
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)  # 根级别设为最低，由处理器控制
        self.logger.propagate = False  # 禁止向上传递，避免重复打印

        # 2. 清空默认处理器（防止重复）
        self.logger.handlers.clear()

        # 3. 默认配置
        self._stream_handler = None
        self._file_handler = None
        self._init_default_stream_handler()

        self._initialized = True

    def _init_default_stream_handler(self):
        """初始化默认终端输出（彩色）"""
        self._stream_handler = logging.StreamHandler(sys.stdout)
        self._stream_handler.setLevel(logging.INFO)
        # 终端格式（精准显示文件名 + 行号）
        stream_fmt = (
            f"{Fore.GREEN}%(asctime)s{Style.RESET_ALL} "
            f"| %(filename)-3s "
            f"| %({'lineno':^3})s | "
            f"%(levelname)s "
            f"| %(message)s"
        )
        self._stream_handler.setFormatter(ColoredFormatter(stream_fmt, use_color=True))
        self.logger.addHandler(self._stream_handler)

    # ===================== 对外配置方法 =====================
    def set_log_file(self, filename: (str, os.path, Path), level: int = LogLevels.DEBUG):

        log_dir = os.path.dirname(filename)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)

        # 移除旧的文件处理器
        if self._file_handler:
            self.logger.removeHandler(self._file_handler)

        # 创建新文件处理器
        self._file_handler = logging.FileHandler(filename, encoding="utf-8")
        self._file_handler.setLevel(level)

        # 文件格式
        file_fmt = "%(asctime)s | %(filename)s | %(lineno)d | %(levelname)s | %(message)s"
        self._file_handler.setFormatter(logging.Formatter(file_fmt))
        self.logger.addHandler(self._file_handler)

    def set_stream_level(self, level: int):
        """设置终端日志级别"""
        if self._stream_handler:
            self._stream_handler.setLevel(level)

    def set_file_level(self, level: int):
        """设置文件日志级别"""
        if self._file_handler:
            self._file_handler.setLevel(level)

    def debug(self, msg, stacklevel=2, *args, **kwargs):
        self.logger.debug(msg, *args, **kwargs, stacklevel=stacklevel)

    def info(self, msg, stacklevel=2, *args, **kwargs):
        self.logger.info(msg, *args, **kwargs, stacklevel=stacklevel)

    def step(self, msg, stacklevel=2, *args, **kwargs):
        """自定义步骤日志"""
        self.logger.log(LogLevels.STEP, msg, *args, **kwargs, stacklevel=stacklevel)

    def custom(self, msg, stacklevel=2, *args, **kwargs):
        """自定义通用日志"""
        self.logger.log(LogLevels.CUSTOM, msg, *args, **kwargs, stacklevel=stacklevel)

    def warning(self, msg, stacklevel=2, *args, **kwargs):
        self.logger.warning(msg, *args, **kwargs, stacklevel=stacklevel)

    def error(self, msg, stacklevel=2, *args, **kwargs):
        self.logger.error(msg, *args, **kwargs, stacklevel=stacklevel)

    def critical(self, msg, stacklevel=2, *args, **kwargs):
        self.logger.critical(msg, *args, **kwargs, stacklevel=stacklevel)


logger = AppLogger()
__all__ = ["logger", "LogLevels"]
