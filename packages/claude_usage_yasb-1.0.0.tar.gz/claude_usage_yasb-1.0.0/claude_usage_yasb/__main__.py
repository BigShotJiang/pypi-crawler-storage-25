# -*- coding: utf-8 -*-
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import json
import os
from datetime import datetime, timezone

from . import firefox, chrome

CONFIG_PATH = os.path.join(os.path.expanduser('~'), '.claude_usage_yasb.json')


def load_cookies():
    cookies = firefox.read_cookies()
    if not cookies.get('sessionKey'):
        cookies = chrome.read_cookies()
    return cookies


def load_config():
    cfg = {}
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, 'r') as f:
            cfg = json.load(f)

    cookies = load_cookies()
    if cookies.get('sessionKey'):
        cfg['sessionKey'] = cookies['sessionKey']
    if cookies.get('anthropic-device-id'):
        cfg['anthropic_device_id'] = cookies['anthropic-device-id']
    if cookies.get('lastActiveOrg'):
        cfg['org_id'] = cookies['lastActiveOrg']

    if cfg:
        with open(CONFIG_PATH, 'w') as f:
            json.dump(cfg, f, indent=2)

    return cfg


def main():
    cfg = load_config()

    org_id = cfg.get('org_id', '')
    session_key = cfg.get('sessionKey', '')
    device_id = cfg.get('anthropic_device_id', '')

    if not org_id or not session_key:
        print('Claude: открой claude.ai в браузере')
        return

    try:
        from curl_cffi import requests as cf_requests
        resp = cf_requests.get(
            f'https://claude.ai/api/organizations/{org_id}/usage',
            impersonate='firefox',
            timeout=5,
            headers={
                'Accept': 'application/json',
                'anthropic-client-platform': 'web_claude_ai',
                'anthropic-client-version': '1.0.0',
                'anthropic-device-id': device_id,
                'Referer': 'https://claude.ai/settings/usage',
            },
            cookies={
                'sessionKey': session_key,
                'anthropic-device-id': device_id,
            }
        )

        if resp.status_code != 200:
            print('Claude: auth expired')
            return

        data = resp.json()
        five_hour = data.get('five_hour', {})
        session_pct = five_hour.get('utilization', 0)
        week_pct = data.get('seven_day', {}).get('utilization', 0)

        resets_str = five_hour.get('resets_at', '')
        time_left = ''
        if resets_str:
            resets_at = datetime.fromisoformat(resets_str)
            diff = int((resets_at - datetime.now(timezone.utc)).total_seconds())
            if diff > 0:
                h, m = divmod(diff // 60, 60)
                time_left = f'{h}h {m:02d}m' if h else f'{m}m'

        WARN = '#FFD700'
        OK   = '#ffffff'
        s_color = WARN if session_pct > 85 else OK
        w_color = WARN if week_pct    > 85 else OK

        s_span     = f'<span style="color:{s_color};">{session_pct:.0f}%</span>'
        w_span     = f'<span style="color:{w_color};">{week_pct:.0f}%</span>'
        timer_part = f' <span>\uf017</span> {time_left}' if time_left else ''

        print(f'<span>\uf0e7</span> {s_span}{timer_part} <span>\uf073</span> {w_span}')

    except Exception:
        print('Claude: err')


if __name__ == '__main__':
    main()