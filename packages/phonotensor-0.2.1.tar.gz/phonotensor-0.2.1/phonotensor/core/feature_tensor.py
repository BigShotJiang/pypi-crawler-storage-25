from __future__ import annotations
from typing import Any
import numpy as np

class FeatureTensor:
    __slots__ = ('_data', '_sample_rate', '_feature_type', '_n_fft', '_hop_length')

    def __init__(self, data: Any, sample_rate: int, feature_type: str='custom', n_fft: int | None=None, hop_length: int | None=None) -> None:
        if not isinstance(data, np.ndarray):
            data = np.asarray(data)
        if data.ndim == 1:
            data = data.reshape(-1, 1)
        elif data.ndim != 2:
            raise ValueError(f'FeatureTensor expects 1-D or 2-D data, got {data.ndim}-D')
        if sample_rate <= 0:
            raise ValueError(f'sample_rate must be positive, got {sample_rate}')
        self._data: np.ndarray = data
        self._data.flags.writeable = False
        self._sample_rate: int = sample_rate
        self._feature_type: str = feature_type
        self._n_fft: int | None = n_fft
        self._hop_length: int | None = hop_length

    @property
    def data(self) -> np.ndarray:
        return self._data

    @property
    def sample_rate(self) -> int:
        return self._sample_rate

    @property
    def feature_type(self) -> str:
        return self._feature_type

    @property
    def n_fft(self) -> int | None:
        return self._n_fft

    @property
    def hop_length(self) -> int | None:
        return self._hop_length

    @property
    def n_frames(self) -> int:
        return int(self._data.shape[0])

    @property
    def n_features(self) -> int:
        return int(self._data.shape[1])

    @property
    def frame_rate(self) -> float | None:
        if self._hop_length:
            return self._sample_rate / self._hop_length
        return None

    @property
    def duration(self) -> float | None:
        if self._hop_length:
            return self.n_frames * self._hop_length / self._sample_rate
        return None

    @property
    def dtype(self) -> np.dtype:
        return self._data.dtype

    @property
    def shape(self) -> tuple[int, ...]:
        return self._data.shape

    @property
    def is_complex(self) -> bool:
        return np.iscomplexobj(self._data)

    def to_numpy(self) -> np.ndarray:
        return self._data.copy()

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {'sample_rate': self._sample_rate, 'feature_type': self._feature_type, 'n_frames': self.n_frames, 'n_features': self.n_features, 'shape': list(self._data.shape), 'dtype': str(self._data.dtype)}
        if self._n_fft is not None:
            d['n_fft'] = self._n_fft
        if self._hop_length is not None:
            d['hop_length'] = self._hop_length
        return d

    def __repr__(self) -> str:
        return f"FeatureTensor(frames={self.n_frames}, features={self.n_features}, type={self._feature_type!r}, rate={self._sample_rate}Hz{(f', n_fft={self._n_fft}' if self._n_fft else '')}{(f', hop={self._hop_length}' if self._hop_length else '')})"

    def __str__(self) -> str:
        return self.summary()

    def summary(self) -> str:
        lines = ['FeatureTensor', f'  Frames     : {self.n_frames:,}', f'  Features   : {self.n_features}', f'  Type       : {self._feature_type}', f'  Sample Rate: {self._sample_rate:,} Hz', f'  Dtype      : {self.dtype}']
        if self._n_fft:
            lines.append(f'  n_fft      : {self._n_fft}')
        if self._hop_length:
            lines.append(f'  Hop Length : {self._hop_length}')
        if self.frame_rate:
            lines.append(f'  Frame Rate : {self.frame_rate:.1f} fps')
        if self.duration:
            lines.append(f'  Duration   : {self.duration:.4f} s')
        if self.is_complex:
            lines.append('  Complex    : True')
        else:
            flat = self._data.flatten()
            lines.append(f'  Min        : {float(np.min(flat)):.6f}')
            lines.append(f'  Max        : {float(np.max(flat)):.6f}')
            lines.append(f'  Mean       : {float(np.mean(flat)):.6f}')
        return '\n'.join(lines)

    @classmethod
    def from_dict(cls, d: dict[str, Any], data: np.ndarray) -> 'FeatureTensor':
        return cls(data=data, sample_rate=d.get('sample_rate', 44100), feature_type=d.get('feature_type', 'custom'), n_fft=d.get('n_fft'), hop_length=d.get('hop_length'))
