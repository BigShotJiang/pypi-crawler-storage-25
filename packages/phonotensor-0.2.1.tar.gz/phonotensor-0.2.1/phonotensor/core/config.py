from dataclasses import dataclass, field
from enum import Enum, auto

class SampleFormat(Enum):
    FLOAT32 = auto()
    INT32 = auto()
    INT24 = auto()
    INT16 = auto()

class StreamMode(Enum):
    INPUT = auto()
    OUTPUT = auto()
    DUPLEX = auto()

@dataclass(frozen=True)
class StreamConfig:
    sample_rate: int = 44100
    channels: int = 1
    sample_format: SampleFormat = SampleFormat.FLOAT32
    block_size: int = 0
    latency: float | None = None

    def __post_init__(self) -> None:
        if self.sample_rate <= 0:
            raise ValueError(f'sample_rate must be positive, got {self.sample_rate}')
        if self.channels <= 0:
            raise ValueError(f'channels must be positive, got {self.channels}')

@dataclass(frozen=True)
class DeviceConfig:
    stream_config: StreamConfig = field(default_factory=StreamConfig)
    mode: StreamMode = StreamMode.INPUT
    device_name: str | None = None
    device_index: int | None = None
