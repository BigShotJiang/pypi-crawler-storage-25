from __future__ import annotations
from typing import Any
import numpy as np

class AudioTensor:
    __slots__ = ('_data', '_sample_rate', '_channels')

    def __init__(self, data: Any, sample_rate: int=44100, channels: int | None=None) -> None:
        if not isinstance(data, np.ndarray):
            data = np.asarray(data, dtype=np.float32)
        if data.ndim == 1:
            data = data.reshape(-1, 1)
        elif data.ndim != 2:
            raise ValueError(f'AudioTensor expects 1-D or 2-D data, got {data.ndim}-D')
        inferred_channels = data.shape[1]
        if channels is not None and channels != inferred_channels:
            raise ValueError(f'channels={channels} but data has {inferred_channels} columns')
        if sample_rate <= 0:
            raise ValueError(f'sample_rate must be positive, got {sample_rate}')
        self._data: np.ndarray = data.astype(np.float32, copy=False)
        self._data.flags.writeable = False
        self._sample_rate: int = sample_rate
        self._channels: int = inferred_channels

    @property
    def data(self) -> np.ndarray:
        return self._data

    @property
    def sample_rate(self) -> int:
        return self._sample_rate

    @property
    def channels(self) -> int:
        return self._channels

    @property
    def num_samples(self) -> int:
        return int(self._data.shape[0])

    @property
    def duration(self) -> float:
        return self.num_samples / self._sample_rate

    @property
    def dtype(self) -> np.dtype:
        return self._data.dtype

    @property
    def shape(self) -> tuple[int, ...]:
        return self._data.shape

    @property
    def is_mono(self) -> bool:
        return self._channels == 1

    @property
    def is_stereo(self) -> bool:
        return self._channels == 2

    def __getitem__(self, key: Any) -> 'AudioTensor':
        sliced = self._data[key]
        if sliced.ndim == 0:
            sliced = sliced.reshape(1, -1)
        elif sliced.ndim == 1:
            sliced = sliced.reshape(-1, self._channels)
        return AudioTensor(sliced, sample_rate=self._sample_rate)

    def __len__(self) -> int:
        return self.num_samples

    def _binop(self, other: Any, op: str) -> Any:
        other_data: Any
        if isinstance(other, AudioTensor):
            if self._sample_rate != other._sample_rate:
                raise ValueError(f'Sample rate mismatch: {self._sample_rate} vs {other._sample_rate}')
            other_data = other._data
        elif isinstance(other, (int, float, np.integer, np.floating)):
            other_data = other
        elif isinstance(other, np.ndarray):
            other_data = other
        else:
            return NotImplemented
        func = getattr(np, op)
        result = func(self._data, other_data)
        return AudioTensor(result, sample_rate=self._sample_rate)

    def __add__(self, other: Any) -> Any:
        return self._binop(other, 'add')

    def __radd__(self, other: Any) -> Any:
        return self._binop(other, 'add')

    def __sub__(self, other: Any) -> Any:
        return self._binop(other, 'subtract')

    def __rsub__(self, other: Any) -> Any:
        if isinstance(other, (int, float, np.integer, np.floating)):
            result = np.subtract(other, self._data)
            return AudioTensor(result, sample_rate=self._sample_rate)
        return NotImplemented

    def __mul__(self, other: Any) -> Any:
        return self._binop(other, 'multiply')

    def __rmul__(self, other: Any) -> Any:
        return self._binop(other, 'multiply')

    def __truediv__(self, other: Any) -> Any:
        return self._binop(other, 'divide')

    def __rtruediv__(self, other: Any) -> Any:
        if isinstance(other, (int, float, np.integer, np.floating)):
            result = np.divide(other, self._data)
            return AudioTensor(result, sample_rate=self._sample_rate)
        return NotImplemented

    def __neg__(self) -> 'AudioTensor':
        return AudioTensor(-self._data, sample_rate=self._sample_rate)

    def __abs__(self) -> 'AudioTensor':
        return AudioTensor(np.abs(self._data), sample_rate=self._sample_rate)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, AudioTensor):
            return NotImplemented
        return self._sample_rate == other._sample_rate and self._channels == other._channels and np.array_equal(self._data, other._data)

    def __hash__(self) -> int:
        data_hash = hash((self._data.tobytes(), self._sample_rate, self._channels))
        return data_hash

    def __repr__(self) -> str:
        return f'AudioTensor(samples={self.num_samples}, channels={self._channels}, rate={self._sample_rate}Hz, duration={self.duration:.3f}s)'

    def __str__(self) -> str:
        return self.summary()

    def summary(self) -> str:
        peak = float(np.max(np.abs(self._data)))
        rms = float(np.sqrt(np.mean(self._data ** 2)))
        lines = ['AudioTensor', f'  Samples    : {self.num_samples:,}', f'  Channels   : {self._channels}', f'  Sample Rate: {self._sample_rate:,} Hz', f'  Duration   : {self.duration:.4f} s', f'  Dtype      : {self.dtype}', f'  Peak       : {peak:.6f}', f'  RMS        : {rms:.6f}']
        return '\n'.join(lines)

    def describe(self) -> str:
        flat = self._data.flatten()
        lines = [self.summary(), f'  Min        : {float(np.min(flat)):.6f}', f'  Max        : {float(np.max(flat)):.6f}', f'  Mean       : {float(np.mean(flat)):.6f}', f'  Std Dev    : {float(np.std(flat)):.6f}', f'  Median     : {float(np.median(flat)):.6f}']
        return '\n'.join(lines)

    def to_numpy(self) -> np.ndarray:
        return self._data.copy()

    def to_mono(self) -> 'AudioTensor':
        if self._channels == 1:
            return self
        mono = np.mean(self._data, axis=1, keepdims=True)
        return AudioTensor(mono, sample_rate=self._sample_rate)

    def to_stereo(self) -> 'AudioTensor':
        if self._channels == 2:
            return self
        if self._channels != 1:
            raise ValueError('to_stereo() only works on mono audio')
        stereo = np.repeat(self._data, 2, axis=1)
        return AudioTensor(stereo, sample_rate=self._sample_rate)

    def channel(self, index: int) -> 'AudioTensor':
        if index < 0 or index >= self._channels:
            raise IndexError(f'Channel {index} out of range for {self._channels}-channel audio')
        return AudioTensor(self._data[:, index:index + 1], sample_rate=self._sample_rate)

    def copy(self) -> 'AudioTensor':
        return AudioTensor(self._data.copy(), sample_rate=self._sample_rate)

    def time_slice(self, start: float=0.0, end: float | None=None) -> 'AudioTensor':
        start_idx = int(start * self._sample_rate)
        end_idx = int(end * self._sample_rate) if end is not None else self.num_samples
        start_idx = max(0, min(start_idx, self.num_samples))
        end_idx = max(start_idx, min(end_idx, self.num_samples))
        return AudioTensor(self._data[start_idx:end_idx], sample_rate=self._sample_rate)

    @classmethod
    def zeros(cls, duration: float, sample_rate: int=44100, channels: int=1) -> 'AudioTensor':
        n = int(duration * sample_rate)
        return cls(np.zeros((n, channels), dtype=np.float32), sample_rate=sample_rate)

    @classmethod
    def from_numpy(cls, data: np.ndarray, sample_rate: int=44100) -> 'AudioTensor':
        return cls(data, sample_rate=sample_rate)

    @classmethod
    def from_list(cls, data: list[float] | list[list[float]], sample_rate: int=44100) -> 'AudioTensor':
        return cls(np.array(data, dtype=np.float32), sample_rate=sample_rate)

    @classmethod
    def from_function(cls, fn: Any, duration: float, sample_rate: int=44100, channels: int=1) -> 'AudioTensor':
        n = int(duration * sample_rate)
        t = np.linspace(0, duration, n, endpoint=False, dtype=np.float32)
        samples = np.asarray(fn(t), dtype=np.float32)
        if samples.ndim == 1:
            samples = np.tile(samples.reshape(-1, 1), (1, channels))
        return cls(samples, sample_rate=sample_rate)
