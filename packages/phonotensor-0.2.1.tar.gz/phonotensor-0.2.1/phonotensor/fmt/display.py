from __future__ import annotations
import numpy as np
from ..core.tensor import AudioTensor
from ..ops.analysis import rms as _rms, peak as _peak, db_peak as _db_peak

def summary(tensor: AudioTensor) -> str:
    p = _peak(tensor)
    return f'AudioTensor({tensor.num_samples} samples, {tensor.channels}ch, {tensor.sample_rate}Hz, {tensor.duration:.3f}s, peak={p:.3f})'

def describe(tensor: AudioTensor) -> str:
    data = tensor.data.flatten()
    p = _peak(tensor)
    r = _rms(tensor)
    db = _db_peak(tensor)
    lines = ['╔══════════════════════════════════════╗', '║         AudioTensor Summary          ║', '╠══════════════════════════════════════╣', f'║  Samples      : {tensor.num_samples:>16,}  ║', f'║  Channels     : {tensor.channels:>16}  ║', f'║  Sample Rate  : {tensor.sample_rate:>13,} Hz  ║', f'║  Duration     : {tensor.duration:>14.4f} s  ║', f'║  Dtype        : {str(tensor.dtype):>16}  ║', '╠══════════════════════════════════════╣', f'║  Peak         : {p:>16.6f}  ║', f'║  RMS          : {r:>16.6f}  ║', f'║  Peak dBFS    : {db:>13.2f} dB  ║', f'║  Min          : {float(np.min(data)):>16.6f}  ║', f'║  Max          : {float(np.max(data)):>16.6f}  ║', f'║  Mean         : {float(np.mean(data)):>16.6f}  ║', f'║  Std Dev      : {float(np.std(data)):>16.6f}  ║', '╚══════════════════════════════════════╝']
    return '\n'.join(lines)

def waveform_ascii(tensor: AudioTensor, width: int=72, height: int=16, channel: int=0) -> str:
    data = tensor.data[:, channel]
    n = len(data)
    if n == 0:
        return '(empty)'
    if n > width:
        indices = np.linspace(0, n - 1, width, dtype=int)
        display_data = data[indices]
    else:
        display_data = data
        width = len(display_data)
    max_abs = max(float(np.max(np.abs(display_data))), 1e-10)
    half = height // 2
    normalized = (display_data / max_abs * half).astype(int)
    grid: list[list[str]] = [[' '] * width for _ in range(height)]
    center = half
    for col, val in enumerate(normalized):
        row = center - val
        row = max(0, min(height - 1, row))
        grid[row][col] = '█'
        if val > 0:
            for r in range(center, row, -1):
                if grid[r][col] == ' ':
                    grid[r][col] = '│'
        elif val < 0:
            for r in range(center, row):
                if grid[r][col] == ' ':
                    grid[r][col] = '│'
    for col in range(width):
        if grid[center][col] == ' ':
            grid[center][col] = '─'
    lines = [''.join(row) for row in grid]
    label_left = '0.000s'
    label_right = f'{tensor.duration:.3f}s'
    axis = label_left + '─' * max(0, width - len(label_left) - len(label_right)) + label_right
    lines.append(axis)
    return '\n'.join(lines)

def print_samples(tensor: AudioTensor, n: int=20, fmt: str='fixed', offset: int=0) -> str:
    data = tensor.to_numpy()
    end = min(offset + n, tensor.num_samples)
    subset = data[offset:end]
    lines = [f'Samples [{offset}:{end}] of {tensor.num_samples} ({tensor.channels}ch):']
    for i, row in enumerate(subset):
        idx = offset + i
        if fmt == 'fixed':
            vals = ', '.join((f'{v:>10.6f}' for v in row))
        elif fmt == 'scientific':
            vals = ', '.join((f'{v:>12.4e}' for v in row))
        else:
            vals = ', '.join((str(v) for v in row))
        lines.append(f'  [{idx:>6d}] {vals}')
    if end < tensor.num_samples:
        lines.append(f'  ... ({tensor.num_samples - end} more samples)')
    return '\n'.join(lines)
