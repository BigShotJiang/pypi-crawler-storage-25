from __future__ import annotations
import json
from typing import Any, Callable
import numpy as np
from ..core.tensor import AudioTensor

def to_list(tensor: AudioTensor) -> list[float] | list[list[float]]:
    data = tensor.to_numpy()
    if tensor.channels == 1:
        return [float(v) for v in data[:, 0]]
    return data.tolist()

def to_dict(tensor: AudioTensor) -> dict[str, Any]:
    return {'sample_rate': tensor.sample_rate, 'channels': tensor.channels, 'num_samples': tensor.num_samples, 'duration': tensor.duration, 'dtype': str(tensor.dtype), 'data': to_list(tensor)}

def to_json(tensor: AudioTensor, indent: int=2) -> str:
    return json.dumps(to_dict(tensor), indent=indent)

def to_csv_string(tensor: AudioTensor, delimiter: str=',') -> str:
    data = tensor.to_numpy()
    header = delimiter.join((f'ch{i}' for i in range(tensor.channels)))
    lines = [header]
    for row in data:
        lines.append(delimiter.join((f'{v:.8f}' for v in row)))
    return '\n'.join(lines)

def from_dict(d: dict[str, Any]) -> AudioTensor:
    sample_rate = int(d.get('sample_rate', 44100))
    data = np.array(d['data'], dtype=np.float32)
    return AudioTensor(data, sample_rate=sample_rate)

def from_json(json_str: str) -> AudioTensor:
    return from_dict(json.loads(json_str))

def from_function(fn: Callable[[np.ndarray], np.ndarray], duration: float, sample_rate: int=44100, channels: int=1) -> AudioTensor:
    return AudioTensor.from_function(fn, duration=duration, sample_rate=sample_rate, channels=channels)
