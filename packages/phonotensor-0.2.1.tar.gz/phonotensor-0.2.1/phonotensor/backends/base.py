from abc import ABC, abstractmethod
from types import TracebackType
from typing import Literal
import numpy as np
from ..core.config import DeviceConfig
from ..device.device import AudioDevice

class AudioStream:

    def __init__(self) -> None:
        self._active: bool = False

    @property
    def active(self) -> bool:
        return self._active

    def start(self) -> None:
        self._active = True

    def stop(self) -> None:
        self._active = False

    def __enter__(self) -> 'AudioStream':
        self.start()
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: TracebackType | None) -> Literal[False]:
        self.stop()
        return False

class AudioBackend(ABC):

    @abstractmethod
    def enumerate_devices(self) -> list[AudioDevice]:
        ...

    @abstractmethod
    def get_default_input_device(self) -> AudioDevice | None:
        ...

    @abstractmethod
    def get_default_output_device(self) -> AudioDevice | None:
        ...

    @abstractmethod
    def open_stream(self, config: DeviceConfig) -> AudioStream:
        ...

    @abstractmethod
    def read(self, stream: AudioStream, frames: int) -> np.ndarray:
        ...

    @abstractmethod
    def write(self, stream: AudioStream, data: np.ndarray) -> None:
        ...

    @abstractmethod
    def close_stream(self, stream: AudioStream) -> None:
        ...

    @abstractmethod
    def is_available(self) -> bool:
        ...
