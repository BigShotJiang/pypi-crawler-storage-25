from ..platform import AudioBackendType
from .base import AudioBackend
from .portaudio import PortAudioBackend
__all__ = ['AudioBackend', 'PortAudioBackend', 'AudioBackendType', 'get_backend']
_BACKEND_REGISTRY: dict[AudioBackendType, type[AudioBackend]] = {AudioBackendType.PORTAUDIO: PortAudioBackend}

def get_backend(backend_type: AudioBackendType) -> AudioBackend:
    cls = _BACKEND_REGISTRY.get(backend_type)
    if cls is None:
        raise ValueError(f'Unknown backend type: {backend_type}')
    backend = cls()
    if not backend.is_available():
        from ..exceptions import BackendUnavailableError
        raise BackendUnavailableError(f'Backend {backend_type.name} is not available')
    return backend
