import logging
import numpy as np
import sounddevice as sd
from ..core.config import StreamMode, DeviceConfig, SampleFormat
from ..device.device import AudioDevice
from ..exceptions import DeviceNotFoundError, DevicePermissionError, StreamError
from .base import AudioBackend, AudioStream
logger = logging.getLogger('phonotensor.backends.portaudio')
_SAMPLE_FORMAT_MAP: dict[SampleFormat, str] = {SampleFormat.FLOAT32: 'float32', SampleFormat.INT32: 'int32', SampleFormat.INT24: 'int24', SampleFormat.INT16: 'int16'}

class PortAudioStream(AudioStream):

    def __init__(self, sd_stream: sd.InputStream | sd.OutputStream | sd.Stream) -> None:
        super().__init__()
        self._sd_stream: sd.InputStream | sd.OutputStream | sd.Stream = sd_stream

    def start(self) -> None:
        self._sd_stream.start()
        self._active = True

    def stop(self) -> None:
        try:
            self._sd_stream.stop()
        except Exception:
            pass
        self._active = False

    def close(self) -> None:
        try:
            self._sd_stream.close()
        except Exception:
            pass
        self._active = False

class PortAudioBackend(AudioBackend):

    def enumerate_devices(self) -> list[AudioDevice]:
        try:
            devices = sd.query_devices()
        except OSError as exc:
            logger.error('Failed to query audio devices: %s', exc)
            raise DevicePermissionError('Cannot query audio devices — the audio subsystem is not accessible.\nCheck that audio drivers are installed and accessible to the current user.') from exc
        default_input_idx: int | None = None
        default_output_idx: int | None = None
        try:
            default_input_idx = sd.default.device[0]
        except Exception:
            pass
        try:
            default_output_idx = sd.default.device[1]
        except Exception:
            pass
        result: list[AudioDevice] = []
        for i, dev in enumerate(devices):
            host_api_info = sd.query_hostapis(dev['hostapi'])
            result.append(AudioDevice(index=i, name=dev['name'], max_input_channels=dev['max_input_channels'], max_output_channels=dev['max_output_channels'], default_sample_rate=dev['default_samplerate'], is_default_input=i == default_input_idx, is_default_output=i == default_output_idx, host_api_name=host_api_info['name']))
        return result

    def get_default_input_device(self) -> AudioDevice | None:
        try:
            idx = sd.default.device[0]
        except Exception:
            return None
        if idx < 0:
            return None
        all_devices = self.enumerate_devices()
        for d in all_devices:
            if d.index == idx:
                return d
        return None

    def get_default_output_device(self) -> AudioDevice | None:
        try:
            idx = sd.default.device[1]
        except Exception:
            return None
        if idx < 0:
            return None
        all_devices = self.enumerate_devices()
        for d in all_devices:
            if d.index == idx:
                return d
        return None

    def open_stream(self, config: DeviceConfig) -> PortAudioStream:
        dtype = _SAMPLE_FORMAT_MAP[config.stream_config.sample_format]
        stream_kwargs: dict[str, int | float | str] = {'samplerate': config.stream_config.sample_rate, 'channels': config.stream_config.channels, 'dtype': dtype, 'blocksize': config.stream_config.block_size}
        if config.stream_config.latency is not None:
            stream_kwargs['latency'] = config.stream_config.latency
        if config.device_index is not None:
            stream_kwargs['device'] = config.device_index
        elif config.device_name is not None:
            device = self._find_device_by_name(config.device_name)
            stream_kwargs['device'] = device.index
        mode_label = config.mode.name.lower()
        logger.debug('Opening %s stream: %s', mode_label, stream_kwargs)
        try:
            if config.mode == StreamMode.INPUT:
                sd_stream = sd.InputStream(**stream_kwargs)
            elif config.mode == StreamMode.OUTPUT:
                sd_stream = sd.OutputStream(**stream_kwargs)
            else:
                sd_stream = sd.Stream(**stream_kwargs)
        except OSError as exc:
            error_msg = str(exc).lower()
            if any((kw in error_msg for kw in ('permission', 'denied', 'access', 'privacy'))):
                raise DevicePermissionError(f'Cannot open {mode_label} audio stream — access denied by the OS.\nCheck your OS privacy/security settings for microphone/audio access.\nOriginal error: {exc}') from exc
            raise StreamError(f'Failed to open {mode_label} audio stream: {exc}') from exc
        except Exception as exc:
            raise StreamError(f'Failed to open {mode_label} audio stream: {exc}') from exc
        return PortAudioStream(sd_stream)

    def read(self, stream: AudioStream, frames: int) -> np.ndarray:
        if not isinstance(stream, PortAudioStream):
            raise TypeError('Expected PortAudioStream')
        if not stream.active:
            raise StreamError('Stream is not active')
        try:
            data, _ = stream._sd_stream.read(frames)
        except OSError as exc:
            error_msg = str(exc).lower()
            if any((kw in error_msg for kw in ('permission', 'denied', 'access'))):
                raise DevicePermissionError(f'Audio read failed — access denied by the OS.\nOriginal error: {exc}') from exc
            raise StreamError(f'Failed to read from stream: {exc}') from exc
        except Exception as exc:
            raise StreamError(f'Failed to read from stream: {exc}') from exc
        return np.asarray(data)

    def write(self, stream: AudioStream, data: np.ndarray) -> None:
        if not isinstance(stream, PortAudioStream):
            raise TypeError('Expected PortAudioStream')
        if not stream.active:
            raise StreamError('Stream is not active')
        try:
            stream._sd_stream.write(data)
        except OSError as exc:
            error_msg = str(exc).lower()
            if any((kw in error_msg for kw in ('permission', 'denied', 'access'))):
                raise DevicePermissionError(f'Audio write failed — access denied by the OS.\nOriginal error: {exc}') from exc
            raise StreamError(f'Failed to write to stream: {exc}') from exc
        except Exception as exc:
            raise StreamError(f'Failed to write to stream: {exc}') from exc

    def close_stream(self, stream: AudioStream) -> None:
        stream.stop()
        if isinstance(stream, PortAudioStream):
            stream.close()

    def is_available(self) -> bool:
        try:
            sd.query_devices()
            return True
        except Exception:
            return False

    def _find_device_by_name(self, name: str) -> AudioDevice:
        for device in self.enumerate_devices():
            if name.lower() in device.name.lower():
                return device
        raise DeviceNotFoundError(f"Device '{name}' not found")
