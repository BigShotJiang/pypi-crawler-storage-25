import platform
import sys
from enum import Enum, auto
from dataclasses import dataclass

class OperatingSystem(Enum):
    WINDOWS = auto()
    MACOS = auto()
    LINUX = auto()
    UNKNOWN = auto()

class AudioBackendType(Enum):
    PORTAUDIO = auto()
    WASAPI = auto()
    COREAUDIO = auto()
    ALSA = auto()
    PULSEAUDIO = auto()
_OS_BACKEND_PREFERENCE: dict[OperatingSystem, list[AudioBackendType]] = {OperatingSystem.WINDOWS: [AudioBackendType.WASAPI, AudioBackendType.PORTAUDIO], OperatingSystem.MACOS: [AudioBackendType.COREAUDIO, AudioBackendType.PORTAUDIO], OperatingSystem.LINUX: [AudioBackendType.PULSEAUDIO, AudioBackendType.ALSA, AudioBackendType.PORTAUDIO]}
_AVAILABLE_BACKENDS: set[AudioBackendType] = {AudioBackendType.PORTAUDIO}

@dataclass(frozen=True)
class PlatformInfo:
    os: OperatingSystem
    os_version: str
    machine: str
    python_version: str

def detect_os() -> OperatingSystem:
    system = platform.system().lower()
    if system == 'windows':
        return OperatingSystem.WINDOWS
    if system == 'darwin':
        return OperatingSystem.MACOS
    if system == 'linux':
        return OperatingSystem.LINUX
    return OperatingSystem.UNKNOWN

def get_platform_info() -> PlatformInfo:
    return PlatformInfo(os=detect_os(), os_version=platform.version(), machine=platform.machine(), python_version=f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')

def select_backend(preferred: AudioBackendType | None=None) -> AudioBackendType:
    if preferred is not None:
        if preferred not in _AVAILABLE_BACKENDS:
            raise ValueError(f'Backend {preferred.name} is not available on this system')
        return preferred
    os_type = detect_os()
    for candidate in _OS_BACKEND_PREFERENCE.get(os_type, [AudioBackendType.PORTAUDIO]):
        if candidate in _AVAILABLE_BACKENDS:
            return candidate
    if AudioBackendType.PORTAUDIO in _AVAILABLE_BACKENDS:
        return AudioBackendType.PORTAUDIO
    raise RuntimeError('No audio backend available')
