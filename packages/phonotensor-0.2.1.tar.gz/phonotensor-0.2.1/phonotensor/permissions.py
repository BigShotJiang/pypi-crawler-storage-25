from __future__ import annotations
import logging
import os
import subprocess
from pathlib import Path
from typing import Any
from .exceptions import DevicePermissionError, FilePermissionError, MicrophonePermissionError
from .platform import OperatingSystem, detect_os
logger = logging.getLogger('phonotensor.permissions')

def check_microphone_access() -> None:
    os_type = detect_os()
    if os_type == OperatingSystem.WINDOWS:
        _check_mic_windows()
    elif os_type == OperatingSystem.MACOS:
        _check_mic_macos()
    elif os_type == OperatingSystem.LINUX:
        _check_mic_linux()
    else:
        logger.warning('Cannot verify microphone permissions on this OS; proceeding anyway.')

def can_access_microphone() -> bool:
    try:
        check_microphone_access()
        return True
    except MicrophonePermissionError:
        return False

def check_output_device_access() -> None:
    os_type = detect_os()
    if os_type == OperatingSystem.LINUX:
        _check_audio_device_linux('output')
    _check_backend_devices('output')

def can_access_output_device() -> bool:
    try:
        check_output_device_access()
        return True
    except DevicePermissionError:
        return False

def _check_mic_windows() -> None:
    try:
        import winreg
    except ImportError:
        logger.debug('winreg not available — skipping Windows registry check')
        return
    _check_winreg_mic_key(winreg.HKEY_LOCAL_MACHINE, 'SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CapabilityAccessManager\\ConsentStore\\microphone', "System-level microphone access is disabled in Windows Privacy Settings.\nGo to Settings → Privacy & Security → Microphone and turn on 'Microphone access'.")
    _check_winreg_mic_key(winreg.HKEY_CURRENT_USER, 'SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\CapabilityAccessManager\\ConsentStore\\microphone', "Desktop app microphone access is disabled in Windows Privacy Settings.\nGo to Settings → Privacy & Security → Microphone and turn on 'Let desktop apps access your microphone'.")
    _probe_mic_stream()

def _check_winreg_mic_key(root: Any, subkey: str, deny_message: str) -> None:
    import winreg
    try:
        key = winreg.OpenKey(root, subkey)
        value, _ = winreg.QueryValueEx(key, 'Value')
        winreg.CloseKey(key)
        if isinstance(value, str) and value.lower() == 'deny':
            raise MicrophonePermissionError(deny_message)
    except FileNotFoundError:
        pass
    except MicrophonePermissionError:
        raise
    except Exception as exc:
        logger.debug('Registry check failed (non-fatal): %s', exc)

def _check_mic_macos() -> None:
    try:
        subprocess.run(['tccutil', 'read', 'Microphone'], capture_output=True, text=True, timeout=5)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    _probe_mic_stream()

def _check_mic_linux() -> None:
    _check_audio_device_linux('input')
    _probe_mic_stream()

def _check_audio_device_linux(direction: str) -> None:
    snd_dir = Path('/dev/snd')
    if not snd_dir.exists():
        raise DevicePermissionError('No audio subsystem found (/dev/snd does not exist).\nInstall ALSA or PulseAudio, or check that your audio drivers are loaded.')
    pcm_devices = list(snd_dir.glob('pcm*'))
    if not pcm_devices:
        raise DevicePermissionError('No PCM audio devices found in /dev/snd.\nCheck that an audio device is connected and drivers are loaded.')
    for dev in pcm_devices:
        if os.access(dev, os.R_OK | os.W_OK):
            return
    username = os.environ.get('USER', 'your user')
    raise DevicePermissionError(f"Cannot access audio devices in /dev/snd (permission denied).\nAdd '{username}' to the 'audio' group:  sudo usermod -aG audio {username}\nThen log out and back in.")

def _probe_mic_stream() -> None:
    try:
        import sounddevice as sd
        with sd.InputStream(channels=1, blocksize=256, dtype='float32') as stream:
            stream.read(256)
    except OSError as exc:
        error_str = str(exc).lower()
        if any((kw in error_str for kw in ('permission', 'denied', 'access', 'privacy', 'not allowed'))):
            raise MicrophonePermissionError('Microphone access denied by the operating system.\nPlease check your OS privacy / security settings and grant microphone access to this application.') from exc
        raise
    except Exception as exc:
        logger.debug('Mic probe encountered a non-OS error: %s', exc)

def _check_backend_devices(direction: str) -> None:
    try:
        import sounddevice as sd
        devices = sd.query_devices()
    except OSError as exc:
        raise DevicePermissionError(f'Cannot query audio devices — the audio subsystem is not accessible.\nCheck that audio drivers are installed and accessible to the current user.\nOriginal error: {exc}') from exc
    except Exception:
        return
    if direction == 'output':
        has_device = any((d['max_output_channels'] > 0 for d in devices))
        if not has_device:
            raise DevicePermissionError('No audio output devices found.\nCheck that speakers or headphones are connected and audio drivers are installed.')
    elif direction == 'input':
        has_device = any((d['max_input_channels'] > 0 for d in devices))
        if not has_device:
            raise DevicePermissionError('No audio input devices found.\nCheck that a microphone is connected and audio drivers are installed.')

def check_file_readable(path: str | Path) -> None:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f'File not found: {path}')
    if not os.access(path, os.R_OK):
        raise FilePermissionError(f'Cannot read file (permission denied): {path}\nCheck file permissions and ensure the current user has read access.')

def check_file_writable(path: str | Path) -> None:
    path = Path(path)
    if path.exists():
        if not os.access(path, os.W_OK):
            raise FilePermissionError(f'Cannot write to file (permission denied): {path}\nCheck file permissions or choose a different output path.')
        return
    parent = path.parent
    if not parent.exists():
        for ancestor in parent.parents:
            if ancestor.exists():
                parent = ancestor
                break
        else:
            raise FilePermissionError(f'Cannot create file — no accessible parent directory for: {path}')
    if not os.access(parent, os.W_OK):
        raise FilePermissionError(f'Cannot write to directory (permission denied): {parent}\nCheck directory permissions or choose a different output path.')

def check_directory_writable(path: str | Path) -> None:
    path = Path(path)
    if path.exists() and (not os.access(path, os.W_OK)):
        raise FilePermissionError(f'Cannot write to directory (permission denied): {path}\nCheck directory permissions.')

def can_read_file(path: str | Path) -> bool:
    try:
        check_file_readable(path)
        return True
    except (FileNotFoundError, FilePermissionError):
        return False

def can_write_file(path: str | Path) -> bool:
    try:
        check_file_writable(path)
        return True
    except FilePermissionError:
        return False
