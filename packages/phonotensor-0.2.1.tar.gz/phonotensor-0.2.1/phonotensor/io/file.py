from __future__ import annotations
import logging
from pathlib import Path
from typing import Any
import numpy as np
from ..core.tensor import AudioTensor
from ..exceptions import FilePermissionError, PhonotensorError
from ..permissions import check_file_readable, check_file_writable
logger = logging.getLogger('phonotensor.io.file')
_SOUNDFILE_FORMATS = {'wav', 'flac', 'ogg'}
_PYDUB_FORMATS = {'mp3'}

def _ensure_soundfile() -> Any:
    try:
        import soundfile as sf
        return sf
    except ImportError as e:
        raise PhonotensorError("The 'soundfile' package is required for audio file I/O. Install it with: pip install soundfile") from e

def _ensure_pydub() -> Any:
    try:
        import pydub
        return pydub
    except ImportError as e:
        raise PhonotensorError("MP3 support requires the 'pydub' package and ffmpeg. Install with: pip install phonotensor[mp3]") from e

class FileIO:

    @staticmethod
    def read(path: str | Path) -> AudioTensor:
        path = Path(path)
        check_file_readable(path)
        ext = path.suffix.lower().lstrip('.')
        logger.info('Reading audio file: %s (format=%s)', path, ext)
        if ext in _SOUNDFILE_FORMATS:
            return FileIO._read_soundfile(path)
        elif ext in _PYDUB_FORMATS:
            return FileIO._read_pydub(path)
        else:
            try:
                return FileIO._read_soundfile(path)
            except Exception:
                raise PhonotensorError(f"Unsupported audio format: '.{ext}'. Supported: {FileIO.supported_formats()}")

    @staticmethod
    def _read_soundfile(path: Path) -> AudioTensor:
        sf = _ensure_soundfile()
        try:
            data, sample_rate = sf.read(path, dtype='float32', always_2d=True)
        except PermissionError as exc:
            raise FilePermissionError(f'Cannot read audio file (OS denied access): {path}\nCheck file permissions and ensure the current user has read access.') from exc
        return AudioTensor(data, sample_rate=sample_rate)

    @staticmethod
    def _read_pydub(path: Path) -> AudioTensor:
        pydub = _ensure_pydub()
        try:
            segment = pydub.AudioSegment.from_file(str(path))
        except PermissionError as exc:
            raise FilePermissionError(f'Cannot read audio file (OS denied access): {path}\nCheck file permissions and ensure the current user has read access.') from exc
        sample_rate = segment.frame_rate
        channels = segment.channels
        samples = np.array(segment.get_array_of_samples(), dtype=np.float32)
        max_val = float(2 ** (segment.sample_width * 8 - 1))
        samples = samples / max_val
        if channels > 1:
            samples = samples.reshape(-1, channels)
        else:
            samples = samples.reshape(-1, 1)
        return AudioTensor(samples, sample_rate=sample_rate)

    @staticmethod
    def write(tensor: AudioTensor, path: str | Path, format: str | None=None, subtype: str | None=None) -> None:
        path = Path(path)
        check_file_writable(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        ext = (format or path.suffix.lower().lstrip('.')).lower()
        logger.info('Writing audio file: %s (format=%s)', path, ext)
        if ext in _SOUNDFILE_FORMATS:
            FileIO._write_soundfile(tensor, path, ext, subtype)
        elif ext in _PYDUB_FORMATS:
            FileIO._write_pydub(tensor, path, ext)
        else:
            raise PhonotensorError(f"Unsupported write format: '.{ext}'. Supported: {FileIO.supported_formats()}")

    @staticmethod
    def _write_soundfile(tensor: AudioTensor, path: Path, fmt: str, subtype: str | None) -> None:
        sf = _ensure_soundfile()
        data = tensor.to_numpy()
        try:
            sf.write(str(path), data, tensor.sample_rate, format=fmt, subtype=subtype)
        except PermissionError as exc:
            raise FilePermissionError(f'Cannot write audio file (OS denied access): {path}\nCheck directory permissions or choose a different output path.') from exc

    @staticmethod
    def _write_pydub(tensor: AudioTensor, path: Path, fmt: str) -> None:
        pydub = _ensure_pydub()
        data = tensor.to_numpy()
        int_data = np.clip(data * 32767, -32768, 32767).astype(np.int16)
        if tensor.channels > 1:
            int_data = int_data.flatten()
        segment = pydub.AudioSegment(data=int_data.tobytes(), sample_width=2, frame_rate=tensor.sample_rate, channels=tensor.channels)
        try:
            segment.export(str(path), format=fmt)
        except PermissionError as exc:
            raise FilePermissionError(f'Cannot write audio file (OS denied access): {path}\nCheck directory permissions or choose a different output path.') from exc

    @staticmethod
    def supported_formats() -> list[str]:
        formats = sorted(_SOUNDFILE_FORMATS)
        try:
            _ensure_pydub()
            formats.extend(sorted(_PYDUB_FORMATS))
        except PhonotensorError:
            pass
        return formats
