from __future__ import annotations
import csv
import json
import logging
from pathlib import Path
from typing import Any
import numpy as np
from ..core.tensor import AudioTensor
from ..exceptions import FilePermissionError
from ..permissions import check_file_readable, check_file_writable
logger = logging.getLogger('phonotensor.io.text')

class TextIO:

    @staticmethod
    def read_csv(path: str | Path, sample_rate: int=44100, delimiter: str=',', has_header: bool=True) -> AudioTensor:
        path = Path(path)
        check_file_readable(path)
        logger.info('Reading CSV: %s', path)
        rows: list[list[float]] = []
        try:
            with open(path, newline='', encoding='utf-8') as f:
                reader = csv.reader(f, delimiter=delimiter)
                if has_header:
                    next(reader, None)
                for row in reader:
                    if row:
                        rows.append([float(v) for v in row])
        except PermissionError as exc:
            raise FilePermissionError(f'Cannot read file (OS denied access): {path}') from exc
        data = np.array(rows, dtype=np.float32)
        return AudioTensor(data, sample_rate=sample_rate)

    @staticmethod
    def read_json(path: str | Path) -> AudioTensor:
        path = Path(path)
        check_file_readable(path)
        logger.info('Reading JSON: %s', path)
        try:
            with open(path, encoding='utf-8') as f:
                obj = json.load(f)
        except PermissionError as exc:
            raise FilePermissionError(f'Cannot read file (OS denied access): {path}') from exc
        sample_rate = int(obj.get('sample_rate', 44100))
        data = np.array(obj['data'], dtype=np.float32)
        return AudioTensor(data, sample_rate=sample_rate)

    @staticmethod
    def read_array(path: str | Path, sample_rate: int=44100, separator: str | None=None) -> AudioTensor:
        path = Path(path)
        check_file_readable(path)
        logger.info('Reading array: %s', path)
        rows: list[list[float]] = []
        try:
            with open(path, encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    parts = line.split(separator) if separator else line.split()
                    rows.append([float(p) for p in parts])
        except PermissionError as exc:
            raise FilePermissionError(f'Cannot read file (OS denied access): {path}') from exc
        data = np.array(rows, dtype=np.float32)
        return AudioTensor(data, sample_rate=sample_rate)

    @staticmethod
    def write_csv(tensor: AudioTensor, path: str | Path, delimiter: str=',', include_header: bool=True) -> None:
        path = Path(path)
        check_file_writable(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = tensor.to_numpy()
        logger.info('Writing CSV: %s', path)
        try:
            with open(path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f, delimiter=delimiter)
                if include_header:
                    header = [f'ch{i}' for i in range(tensor.channels)]
                    writer.writerow(header)
                for row in data:
                    writer.writerow([f'{v:.8f}' for v in row])
        except PermissionError as exc:
            raise FilePermissionError(f'Cannot write file (OS denied access): {path}') from exc

    @staticmethod
    def write_json(tensor: AudioTensor, path: str | Path, indent: int=2) -> None:
        path = Path(path)
        check_file_writable(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = tensor.to_numpy()
        logger.info('Writing JSON: %s', path)
        obj: dict[str, Any] = {'sample_rate': tensor.sample_rate, 'channels': tensor.channels, 'num_samples': tensor.num_samples, 'duration': tensor.duration, 'data': data.tolist()}
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(obj, f, indent=indent)
        except PermissionError as exc:
            raise FilePermissionError(f'Cannot write file (OS denied access): {path}') from exc

    @staticmethod
    def write_array(tensor: AudioTensor, path: str | Path, separator: str=' ', precision: int=8) -> None:
        path = Path(path)
        check_file_writable(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = tensor.to_numpy()
        fmt = f'%.{precision}f'
        logger.info('Writing array: %s', path)
        try:
            with open(path, 'w', encoding='utf-8') as f:
                for row in data:
                    line = separator.join((fmt % v for v in row))
                    f.write(line + '\n')
        except PermissionError as exc:
            raise FilePermissionError(f'Cannot write file (OS denied access): {path}') from exc

    @staticmethod
    def from_list(data: list[float] | list[list[float]], sample_rate: int=44100) -> AudioTensor:
        return AudioTensor.from_list(data, sample_rate=sample_rate)

    @staticmethod
    def from_function(fn: Any, duration: float, sample_rate: int=44100, channels: int=1) -> AudioTensor:
        return AudioTensor.from_function(fn, duration=duration, sample_rate=sample_rate, channels=channels)
