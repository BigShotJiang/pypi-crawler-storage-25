from __future__ import annotations
import logging
import numpy as np
from ..backends import get_backend
from ..core.config import DeviceConfig, StreamConfig, StreamMode
from ..core.tensor import AudioTensor
from ..device.device import AudioDevice
from ..exceptions import MicrophonePermissionError, StreamError
from ..permissions import check_microphone_access
from ..platform import AudioBackendType, select_backend
logger = logging.getLogger('phonotensor.io.mic')

class MicrophoneSource:

    def __init__(self, sample_rate: int=44100, channels: int=1, device: str | int | None=None, backend_type: AudioBackendType | None=None, skip_permission_check: bool=False) -> None:
        self._sample_rate = sample_rate
        self._channels = channels
        self._backend_type = backend_type or select_backend()
        self._backend = get_backend(self._backend_type)
        self._device_name: str | None = None
        self._device_index: int | None = None
        if isinstance(device, int):
            self._device_index = device
        elif isinstance(device, str):
            self._device_name = device
        if not skip_permission_check:
            logger.info('Checking microphone permissions...')
            check_microphone_access()
            logger.info('Microphone access granted.')

    def record(self, duration: float) -> AudioTensor:
        if duration <= 0:
            raise ValueError(f'duration must be positive, got {duration}')
        config = self._make_config(StreamMode.INPUT)
        try:
            stream = self._backend.open_stream(config)
        except StreamError as exc:
            _reraise_if_permission_error(exc)
            raise
        try:
            stream.start()
            total_frames = int(duration * self._sample_rate)
            chunks: list[np.ndarray] = []
            remaining = total_frames
            read_size = 1024
            while remaining > 0:
                n = min(read_size, remaining)
                try:
                    data = self._backend.read(stream, n)
                except StreamError as exc:
                    _reraise_if_permission_error(exc)
                    raise
                chunks.append(data)
                remaining -= n
            result = np.concatenate(chunks, axis=0)[:total_frames]
        finally:
            self._backend.close_stream(stream)
        return AudioTensor(result, sample_rate=self._sample_rate)

    def record_until_silence(self, threshold: float=0.01, silence_duration: float=1.0, max_duration: float=30.0) -> AudioTensor:
        config = self._make_config(StreamMode.INPUT)
        try:
            stream = self._backend.open_stream(config)
        except StreamError as exc:
            _reraise_if_permission_error(exc)
            raise
        try:
            stream.start()
            chunks: list[np.ndarray] = []
            read_size = 1024
            silence_frames = 0
            silence_threshold_frames = int(silence_duration * self._sample_rate)
            max_frames = int(max_duration * self._sample_rate)
            total_read = 0
            while total_read < max_frames:
                n = min(read_size, max_frames - total_read)
                try:
                    data = self._backend.read(stream, n)
                except StreamError as exc:
                    _reraise_if_permission_error(exc)
                    raise
                chunks.append(data)
                total_read += n
                rms = float(np.sqrt(np.mean(data ** 2)))
                if rms < threshold:
                    silence_frames += n
                else:
                    silence_frames = 0
                if silence_frames >= silence_threshold_frames:
                    break
            result = np.concatenate(chunks, axis=0)
        finally:
            self._backend.close_stream(stream)
        return AudioTensor(result, sample_rate=self._sample_rate)

    def list_devices(self) -> list[AudioDevice]:
        return self._backend.enumerate_devices()

    def default_device(self) -> AudioDevice | None:
        return self._backend.get_default_input_device()

    def _make_config(self, mode: StreamMode) -> DeviceConfig:
        return DeviceConfig(stream_config=StreamConfig(sample_rate=self._sample_rate, channels=self._channels), mode=mode, device_name=self._device_name, device_index=self._device_index)

def _reraise_if_permission_error(exc: StreamError) -> None:
    msg = str(exc).lower()
    cause = str(exc.__cause__).lower() if exc.__cause__ else ''
    combined = msg + ' ' + cause
    if any((kw in combined for kw in ('permission', 'denied', 'access', 'privacy', 'not allowed'))):
        raise MicrophonePermissionError(f'Microphone access denied by the operating system.\nPlease check your OS privacy / security settings and grant microphone access to this application.\nOriginal error: {exc}') from exc
