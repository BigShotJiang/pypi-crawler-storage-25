from __future__ import annotations
import logging
import numpy as np
from ..backends import get_backend
from ..core.config import DeviceConfig, StreamConfig, StreamMode
from ..core.tensor import AudioTensor
from ..exceptions import DevicePermissionError, StreamError
from ..permissions import check_output_device_access
from ..platform import AudioBackendType, select_backend
logger = logging.getLogger('phonotensor.io.player')

class AudioPlayer:

    def __init__(self, device: str | int | None=None, backend_type: AudioBackendType | None=None, skip_permission_check: bool=False) -> None:
        self._backend_type = backend_type or select_backend()
        self._backend = get_backend(self._backend_type)
        self._device_name: str | None = None
        self._device_index: int | None = None
        if isinstance(device, int):
            self._device_index = device
        elif isinstance(device, str):
            self._device_name = device
        if not skip_permission_check:
            logger.info('Checking audio output device permissions...')
            check_output_device_access()
            logger.info('Audio output access confirmed.')

    def play(self, tensor: AudioTensor, blocking: bool=True) -> None:
        config = DeviceConfig(stream_config=StreamConfig(sample_rate=tensor.sample_rate, channels=tensor.channels), mode=StreamMode.OUTPUT, device_name=self._device_name, device_index=self._device_index)
        try:
            stream = self._backend.open_stream(config)
        except StreamError as exc:
            _reraise_if_permission_error(exc)
            raise
        try:
            stream.start()
            data = tensor.to_numpy()
            write_size = 1024
            offset = 0
            total = data.shape[0]
            while offset < total:
                end = min(offset + write_size, total)
                try:
                    self._backend.write(stream, data[offset:end])
                except StreamError as exc:
                    _reraise_if_permission_error(exc)
                    raise
                offset = end
        finally:
            self._backend.close_stream(stream)

    def play_numpy(self, data: np.ndarray, sample_rate: int=44100, channels: int=1) -> None:
        tensor = AudioTensor(data, sample_rate=sample_rate)
        self.play(tensor)

def _reraise_if_permission_error(exc: StreamError) -> None:
    msg = str(exc).lower()
    cause = str(exc.__cause__).lower() if exc.__cause__ else ''
    combined = msg + ' ' + cause
    if any((kw in combined for kw in ('permission', 'denied', 'access', 'privacy', 'not allowed'))):
        raise DevicePermissionError(f'Audio output device access denied by the operating system.\nPlease check your OS audio settings and ensure output devices are available and accessible.\nOriginal error: {exc}') from exc
