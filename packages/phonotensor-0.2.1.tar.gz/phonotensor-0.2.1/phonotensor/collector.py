from __future__ import annotations
import warnings
from collections.abc import Iterator
from contextlib import contextmanager
import numpy as np
from .backends import get_backend
from .backends.base import AudioStream
from .core.config import DeviceConfig, StreamMode
from .device.device import AudioDevice
from .exceptions import StreamError
from .platform import AudioBackendType, select_backend

class AudioCollector:

    def __init__(self, config: DeviceConfig | None=None, backend_type: AudioBackendType | None=None) -> None:
        warnings.warn('AudioCollector is deprecated. Use MicrophoneSource and AudioPlayer instead.', DeprecationWarning, stacklevel=2)
        self._config: DeviceConfig = config or DeviceConfig()
        if backend_type is not None:
            self._backend_type: AudioBackendType = backend_type
        else:
            self._backend_type = select_backend()
        self._backend = get_backend(self._backend_type)
        self._stream: AudioStream | None = None

    def list_devices(self) -> list[AudioDevice]:
        return self._backend.enumerate_devices()

    def default_input_device(self) -> AudioDevice | None:
        return self._backend.get_default_input_device()

    def default_output_device(self) -> AudioDevice | None:
        return self._backend.get_default_output_device()

    @contextmanager
    def open(self, config: DeviceConfig | None=None) -> Iterator['AudioCollector']:
        stream_config = config or self._config
        self._stream = self._backend.open_stream(stream_config)
        try:
            self._stream.start()
            yield self
        finally:
            if self._stream is not None:
                self._backend.close_stream(self._stream)
                self._stream = None

    def read(self, frames: int) -> np.ndarray:
        if self._stream is None or not self._stream.active:
            raise StreamError('No active stream. Use `open()` context manager first.')
        return self._backend.read(self._stream, frames)

    def collect(self, duration_seconds: float) -> np.ndarray:
        if self._stream is None or not self._stream.active:
            raise StreamError('No active stream. Use `open()` context manager first.')
        sample_rate = self._config.stream_config.sample_rate
        total_frames = int(duration_seconds * sample_rate)
        chunks: list[np.ndarray] = []
        remaining = total_frames
        block_size = self._config.stream_config.block_size
        read_size = block_size if block_size > 0 else 1024
        while remaining > 0:
            n = min(read_size, remaining)
            data = self._backend.read(self._stream, n)
            chunks.append(data)
            remaining -= n
        result = np.concatenate(chunks, axis=0)
        return result[:total_frames]

    def play(self, data: np.ndarray, config: DeviceConfig | None=None) -> None:
        output_config = config or DeviceConfig(stream_config=self._config.stream_config, mode=StreamMode.OUTPUT)
        stream = self._backend.open_stream(output_config)
        try:
            stream.start()
            block_size = output_config.stream_config.block_size
            write_size = block_size if block_size > 0 else 1024
            offset = 0
            total_frames = data.shape[0]
            while offset < total_frames:
                end = min(offset + write_size, total_frames)
                self._backend.write(stream, data[offset:end])
                offset = end
        finally:
            self._backend.close_stream(stream)

    @property
    def is_streaming(self) -> bool:
        return self._stream is not None and self._stream.active

    @property
    def backend_type(self) -> AudioBackendType:
        return self._backend_type

    @property
    def config(self) -> DeviceConfig:
        return self._config
