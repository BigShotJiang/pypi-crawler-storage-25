from __future__ import annotations
import numpy as np
from typing import Any
from ..core.tensor import AudioTensor

def convolve(tensor: AudioTensor, kernel: AudioTensor, mode: Any='full') -> AudioTensor:
    if tensor.sample_rate != kernel.sample_rate:
        raise ValueError(f'Sample rate mismatch: {tensor.sample_rate} vs {kernel.sample_rate}')
    result_data = np.zeros((0, tensor.channels), dtype=np.float32)
    for ch in range(tensor.channels):
        kernel_ch = kernel.data[:, 0] if kernel.is_mono else kernel.data[:, min(ch, kernel.channels - 1)]
        conv = np.convolve(tensor.data[:, ch], kernel_ch, mode=mode)
        result_data = np.column_stack([result_data, conv.astype(np.float32)]) if result_data.size else conv.reshape(-1, 1).astype(np.float32)
    return AudioTensor(result_data, sample_rate=tensor.sample_rate)

def cross_correlate(a: AudioTensor, b: AudioTensor) -> AudioTensor:
    if a.sample_rate != b.sample_rate:
        raise ValueError(f'Sample rate mismatch: {a.sample_rate} vs {b.sample_rate}')
    a_data = a.data[:, 0] if a.is_mono else np.mean(a.data, axis=1)
    b_data = b.data[:, 0] if b.is_mono else np.mean(b.data, axis=1)
    corr = np.correlate(a_data, b_data, mode='full')
    return AudioTensor(corr.reshape(-1, 1).astype(np.float32), sample_rate=a.sample_rate)

def auto_correlate(tensor: AudioTensor) -> AudioTensor:
    data = tensor.data[:, 0] if tensor.is_mono else np.mean(tensor.data, axis=1)
    corr = np.correlate(data, data, mode='full')
    n = len(data)
    center = n - 1
    peaks = np.max(np.abs(corr))
    if peaks > 0:
        corr = corr / peaks
    result = corr[center:].reshape(-1, 1).astype(np.float32)
    return AudioTensor(result, sample_rate=tensor.sample_rate)
