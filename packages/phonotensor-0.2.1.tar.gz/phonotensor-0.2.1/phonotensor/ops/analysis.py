from __future__ import annotations
import numpy as np
from ..core.tensor import AudioTensor

def rms(tensor: AudioTensor) -> float:
    return float(np.sqrt(np.mean(tensor.data ** 2)))

def peak(tensor: AudioTensor) -> float:
    return float(np.max(np.abs(tensor.data)))

def duration(tensor: AudioTensor) -> float:
    return tensor.duration

def zero_crossings(tensor: AudioTensor) -> int:
    data = tensor.data[:, 0]
    signs = np.sign(data)
    crossings = np.diff(signs)
    return int(np.count_nonzero(crossings))

def energy(tensor: AudioTensor) -> float:
    return float(np.sum(tensor.data ** 2))

def db_peak(tensor: AudioTensor) -> float:
    p = peak(tensor)
    if p == 0:
        return float('-inf')
    return float(20.0 * np.log10(p))

def db_rms(tensor: AudioTensor) -> float:
    r = rms(tensor)
    if r == 0:
        return float('-inf')
    return float(20.0 * np.log10(r))

def min_sample(tensor: AudioTensor) -> float:
    return float(np.min(tensor.data))

def max_sample(tensor: AudioTensor) -> float:
    return float(np.max(tensor.data))

def mean(tensor: AudioTensor) -> float:
    return float(np.mean(tensor.data))

def std(tensor: AudioTensor) -> float:
    return float(np.std(tensor.data))
