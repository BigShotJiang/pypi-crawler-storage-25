from __future__ import annotations
import numpy as np
from ..core.tensor import AudioTensor

def sine(freq: float, duration: float, sample_rate: int=44100, amplitude: float=1.0) -> AudioTensor:
    if freq <= 0:
        raise ValueError(f'freq must be positive, got {freq}')
    if duration <= 0:
        raise ValueError(f'duration must be positive, got {duration}')
    if sample_rate <= 0:
        raise ValueError(f'sample_rate must be positive, got {sample_rate}')
    t = np.linspace(0, duration, int(duration * sample_rate), endpoint=False, dtype=np.float32)
    data = (amplitude * np.sin(2 * np.pi * freq * t)).reshape(-1, 1)
    return AudioTensor(data, sample_rate=sample_rate)

def square(freq: float, duration: float, sample_rate: int=44100, amplitude: float=1.0) -> AudioTensor:
    if freq <= 0:
        raise ValueError(f'freq must be positive, got {freq}')
    if duration <= 0:
        raise ValueError(f'duration must be positive, got {duration}')
    if sample_rate <= 0:
        raise ValueError(f'sample_rate must be positive, got {sample_rate}')
    t = np.linspace(0, duration, int(duration * sample_rate), endpoint=False, dtype=np.float32)
    data = (amplitude * np.sign(np.sin(2 * np.pi * freq * t))).reshape(-1, 1)
    return AudioTensor(data, sample_rate=sample_rate)

def sawtooth(freq: float, duration: float, sample_rate: int=44100, amplitude: float=1.0) -> AudioTensor:
    if freq <= 0:
        raise ValueError(f'freq must be positive, got {freq}')
    if duration <= 0:
        raise ValueError(f'duration must be positive, got {duration}')
    if sample_rate <= 0:
        raise ValueError(f'sample_rate must be positive, got {sample_rate}')
    t = np.linspace(0, duration, int(duration * sample_rate), endpoint=False, dtype=np.float32)
    data = (amplitude * (2.0 * (t * freq - np.floor(0.5 + t * freq)))).reshape(-1, 1)
    return AudioTensor(data, sample_rate=sample_rate)

def triangle(freq: float, duration: float, sample_rate: int=44100, amplitude: float=1.0) -> AudioTensor:
    if freq <= 0:
        raise ValueError(f'freq must be positive, got {freq}')
    if duration <= 0:
        raise ValueError(f'duration must be positive, got {duration}')
    if sample_rate <= 0:
        raise ValueError(f'sample_rate must be positive, got {sample_rate}')
    t = np.linspace(0, duration, int(duration * sample_rate), endpoint=False, dtype=np.float32)
    data = (amplitude * (2.0 * np.abs(2.0 * (t * freq - np.floor(t * freq + 0.5))) - 1.0)).reshape(-1, 1)
    return AudioTensor(data, sample_rate=sample_rate)

def impulse(duration: float, sample_rate: int=44100, amplitude: float=1.0) -> AudioTensor:
    if duration <= 0:
        raise ValueError(f'duration must be positive, got {duration}')
    if sample_rate <= 0:
        raise ValueError(f'sample_rate must be positive, got {sample_rate}')
    n = int(duration * sample_rate)
    data = np.zeros((n, 1), dtype=np.float32)
    data[0, 0] = amplitude
    return AudioTensor(data, sample_rate=sample_rate)

def white_noise(duration: float, sample_rate: int=44100, amplitude: float=1.0, seed: int | None=None) -> AudioTensor:
    if duration <= 0:
        raise ValueError(f'duration must be positive, got {duration}')
    if sample_rate <= 0:
        raise ValueError(f'sample_rate must be positive, got {sample_rate}')
    rng = np.random.default_rng(seed)
    n = int(duration * sample_rate)
    data = (amplitude * (2.0 * rng.random((n, 1)) - 1.0)).astype(np.float32)
    return AudioTensor(data, sample_rate=sample_rate)

def pink_noise(duration: float, sample_rate: int=44100, amplitude: float=1.0, seed: int | None=None) -> AudioTensor:
    if duration <= 0:
        raise ValueError(f'duration must be positive, got {duration}')
    if sample_rate <= 0:
        raise ValueError(f'sample_rate must be positive, got {sample_rate}')
    rng = np.random.default_rng(seed)
    n = int(duration * sample_rate)
    num_rows = 16
    white = rng.standard_normal((num_rows, n)).astype(np.float32)
    data = np.sum(white, axis=0)
    data /= np.max(np.abs(data)) + 1e-10
    data *= amplitude
    return AudioTensor(data.reshape(-1, 1), sample_rate=sample_rate)

def sweep(start_freq: float, end_freq: float, duration: float, sample_rate: int=44100, amplitude: float=1.0) -> AudioTensor:
    if start_freq <= 0:
        raise ValueError(f'start_freq must be positive, got {start_freq}')
    if end_freq <= 0:
        raise ValueError(f'end_freq must be positive, got {end_freq}')
    if duration <= 0:
        raise ValueError(f'duration must be positive, got {duration}')
    if sample_rate <= 0:
        raise ValueError(f'sample_rate must be positive, got {sample_rate}')
    t = np.linspace(0, duration, int(duration * sample_rate), endpoint=False, dtype=np.float32)
    phase = 2 * np.pi * (start_freq * t + (end_freq - start_freq) * t ** 2 / (2 * duration))
    data = (amplitude * np.sin(phase)).reshape(-1, 1)
    return AudioTensor(data, sample_rate=sample_rate)
