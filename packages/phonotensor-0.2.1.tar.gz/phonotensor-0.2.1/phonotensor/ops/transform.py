from __future__ import annotations
import numpy as np
from ..core.tensor import AudioTensor

def normalize(tensor: AudioTensor, peak_level: float=1.0) -> AudioTensor:
    data = tensor.to_numpy()
    current_peak = np.max(np.abs(data))
    if current_peak == 0:
        return tensor.copy()
    return AudioTensor(data * (peak_level / current_peak), sample_rate=tensor.sample_rate)

def resample(tensor: AudioTensor, target_rate: int) -> AudioTensor:
    if target_rate == tensor.sample_rate:
        return tensor.copy()
    try:
        from scipy.signal import resample as scipy_resample
    except ImportError as e:
        raise ImportError('scipy is required for resampling. Install with: pip install scipy') from e
    ratio = target_rate / tensor.sample_rate
    new_length = int(tensor.num_samples * ratio)
    data = tensor.to_numpy()
    resampled = np.zeros((new_length, tensor.channels), dtype=np.float32)
    for ch in range(tensor.channels):
        resampled[:, ch] = scipy_resample(data[:, ch], new_length).astype(np.float32)
    return AudioTensor(resampled, sample_rate=target_rate)

def reverse(tensor: AudioTensor) -> AudioTensor:
    return AudioTensor(tensor.to_numpy()[::-1].copy(), sample_rate=tensor.sample_rate)

def fade_in(tensor: AudioTensor, duration: float) -> AudioTensor:
    data = tensor.to_numpy()
    n_fade = min(int(duration * tensor.sample_rate), tensor.num_samples)
    envelope = np.linspace(0.0, 1.0, n_fade, dtype=np.float32).reshape(-1, 1)
    data[:n_fade] *= envelope
    return AudioTensor(data, sample_rate=tensor.sample_rate)

def fade_out(tensor: AudioTensor, duration: float) -> AudioTensor:
    data = tensor.to_numpy()
    n_fade = min(int(duration * tensor.sample_rate), tensor.num_samples)
    envelope = np.linspace(1.0, 0.0, n_fade, dtype=np.float32).reshape(-1, 1)
    data[-n_fade:] *= envelope
    return AudioTensor(data, sample_rate=tensor.sample_rate)

def gain(tensor: AudioTensor, db: float) -> AudioTensor:
    factor = 10.0 ** (db / 20.0)
    return AudioTensor(tensor.to_numpy() * factor, sample_rate=tensor.sample_rate)

def invert_phase(tensor: AudioTensor) -> AudioTensor:
    return -tensor

def clip(tensor: AudioTensor, min_val: float=-1.0, max_val: float=1.0) -> AudioTensor:
    data = np.clip(tensor.to_numpy(), min_val, max_val)
    return AudioTensor(data, sample_rate=tensor.sample_rate)
