from __future__ import annotations
import numpy as np
from typing import Any
from ..core.tensor import AudioTensor

def _butter_filter(data: np.ndarray, cutoff: float | list[float], sr: int, btype: Any, order: int) -> np.ndarray:
    nyq = sr / 2.0
    if isinstance(cutoff, (list, tuple)):
        for c in cutoff:
            if c >= nyq:
                raise ValueError(f'Cutoff frequency {c} Hz exceeds Nyquist ({nyq} Hz)')
        if cutoff[0] >= cutoff[1]:
            raise ValueError(f'Low cutoff ({cutoff[0]} Hz) must be less than high cutoff ({cutoff[1]} Hz)')
    else:
        if cutoff >= nyq:
            raise ValueError(f'Cutoff frequency {cutoff} Hz exceeds Nyquist ({nyq} Hz)')
        if cutoff <= 0:
            raise ValueError(f'Cutoff frequency must be positive, got {cutoff}')
    from scipy.signal import sosfilt, butter
    Wn = [c / nyq for c in cutoff] if isinstance(cutoff, (list, tuple)) else cutoff / nyq
    sos = butter(order, Wn, btype=btype, output='sos')
    return sosfilt(sos, data, axis=0)

def lowpass(tensor: AudioTensor, cutoff: float, order: int=5) -> AudioTensor:
    data = _butter_filter(tensor.to_numpy(), cutoff, tensor.sample_rate, 'low', order)
    return AudioTensor(data.astype(np.float32), sample_rate=tensor.sample_rate)

def highpass(tensor: AudioTensor, cutoff: float, order: int=5) -> AudioTensor:
    data = _butter_filter(tensor.to_numpy(), cutoff, tensor.sample_rate, 'high', order)
    return AudioTensor(data.astype(np.float32), sample_rate=tensor.sample_rate)

def bandpass(tensor: AudioTensor, low_cutoff: float, high_cutoff: float, order: int=5) -> AudioTensor:
    data = _butter_filter(tensor.to_numpy(), [low_cutoff, high_cutoff], tensor.sample_rate, 'band', order)
    return AudioTensor(data.astype(np.float32), sample_rate=tensor.sample_rate)

def bandstop(tensor: AudioTensor, low_cutoff: float, high_cutoff: float, order: int=5) -> AudioTensor:
    data = _butter_filter(tensor.to_numpy(), [low_cutoff, high_cutoff], tensor.sample_rate, 'bandstop', order)
    return AudioTensor(data.astype(np.float32), sample_rate=tensor.sample_rate)

def notch(tensor: AudioTensor, freq: float, q: float=30.0) -> AudioTensor:
    nyq = tensor.sample_rate / 2.0
    if freq <= 0:
        raise ValueError(f'freq must be positive, got {freq}')
    if freq >= nyq:
        raise ValueError(f'freq {freq} Hz must be below Nyquist ({nyq} Hz)')
    from scipy.signal import iirnotch, lfilter
    b, a = iirnotch(freq, q, fs=tensor.sample_rate)
    data = tensor.to_numpy()
    for ch in range(tensor.channels):
        data[:, ch] = lfilter(b, a, data[:, ch]).astype(np.float32)
    return AudioTensor(data, sample_rate=tensor.sample_rate)
