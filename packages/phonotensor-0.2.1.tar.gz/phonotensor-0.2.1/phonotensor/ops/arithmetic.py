from __future__ import annotations
import numpy as np
from ..core.tensor import AudioTensor
from ..exceptions import ConfigurationError

def _check_compatible(a: AudioTensor, b: AudioTensor) -> None:
    if a.sample_rate != b.sample_rate:
        raise ConfigurationError(f'Sample rate mismatch: {a.sample_rate} vs {b.sample_rate}. Resample one of them first.')
    if a.channels != b.channels:
        raise ConfigurationError(f'Channel count mismatch: {a.channels} vs {b.channels}. Convert to the same channel layout first.')

def _align_lengths(a: np.ndarray, b: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    diff = a.shape[0] - b.shape[0]
    if diff > 0:
        b = np.pad(b, ((0, diff), (0, 0)), mode='constant')
    elif diff < 0:
        a = np.pad(a, ((0, -diff), (0, 0)), mode='constant')
    return (a, b)

def add(a: AudioTensor, b: AudioTensor) -> AudioTensor:
    _check_compatible(a, b)
    d1, d2 = _align_lengths(a.to_numpy(), b.to_numpy())
    return AudioTensor(d1 + d2, sample_rate=a.sample_rate)

def subtract(a: AudioTensor, b: AudioTensor) -> AudioTensor:
    _check_compatible(a, b)
    d1, d2 = _align_lengths(a.to_numpy(), b.to_numpy())
    return AudioTensor(d1 - d2, sample_rate=a.sample_rate)

def multiply(a: AudioTensor, b: AudioTensor) -> AudioTensor:
    _check_compatible(a, b)
    d1, d2 = _align_lengths(a.to_numpy(), b.to_numpy())
    return AudioTensor(d1 * d2, sample_rate=a.sample_rate)

def scale(tensor: AudioTensor, factor: float) -> AudioTensor:
    return AudioTensor(tensor.to_numpy() * factor, sample_rate=tensor.sample_rate)

def mix(tensors: list[AudioTensor], weights: list[float] | None=None) -> AudioTensor:
    if not tensors:
        raise ValueError('At least one AudioTensor is required')
    if weights is None:
        weights = [1.0 / len(tensors)] * len(tensors)
    elif len(weights) != len(tensors):
        raise ValueError(f'weights length ({len(weights)}) must match tensors length ({len(tensors)})')
    ref = tensors[0]
    for t in tensors[1:]:
        _check_compatible(ref, t)
    max_len = max((t.num_samples for t in tensors))
    result = np.zeros((max_len, ref.channels), dtype=np.float32)
    for tensor, weight in zip(tensors, weights):
        data = tensor.to_numpy()
        result[:data.shape[0]] += data * weight
    return AudioTensor(result, sample_rate=ref.sample_rate)
