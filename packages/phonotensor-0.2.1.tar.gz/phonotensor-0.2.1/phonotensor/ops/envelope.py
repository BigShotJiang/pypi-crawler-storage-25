from __future__ import annotations
import numpy as np
from ..core.tensor import AudioTensor

def adsr(attack: float, decay: float, sustain_level: float, release: float, duration: float, sample_rate: int=44100) -> AudioTensor:
    if duration <= 0:
        raise ValueError(f'duration must be positive, got {duration}')
    if sample_rate <= 0:
        raise ValueError(f'sample_rate must be positive, got {sample_rate}')
    if attack < 0 or decay < 0 or release < 0:
        raise ValueError('attack/decay/release must be non-negative')
    if not 0 <= sustain_level <= 1:
        raise ValueError(f'sustain_level must be in [0, 1], got {sustain_level}')
    n_attack = int(attack * sample_rate)
    n_decay = int(decay * sample_rate)
    n_release = int(release * sample_rate)
    n_total = int(duration * sample_rate)
    n_sustain = max(0, n_total - n_attack - n_decay - n_release)
    envelope = np.zeros(n_total, dtype=np.float32)
    idx = 0
    for n, start, end in [(n_attack, 0.0, 1.0), (n_decay, 1.0, sustain_level)]:
        if n > 0:
            envelope[idx:idx + n] = np.linspace(start, end, n, dtype=np.float32)
            idx += n
    if n_sustain > 0:
        envelope[idx:idx + n_sustain] = sustain_level
        idx += n_sustain
    if n_release > 0:
        remaining = min(n_release, n_total - idx)
        envelope[idx:idx + remaining] = np.linspace(sustain_level, 0.0, remaining, dtype=np.float32)
    return AudioTensor(envelope.reshape(-1, 1), sample_rate=sample_rate)

def compress(tensor: AudioTensor, threshold: float=0.5, ratio: float=4.0) -> AudioTensor:
    if not 0 < threshold <= 1:
        raise ValueError(f'threshold must be in (0, 1], got {threshold}')
    if ratio <= 0:
        raise ValueError(f'ratio must be positive, got {ratio}')
    data = tensor.to_numpy()
    abs_data = np.abs(data)
    mask = abs_data > threshold
    compressed = data.copy()
    sign = np.sign(data[mask])
    over = abs_data[mask] - threshold
    compressed[mask] = sign * (threshold + over / ratio)
    return AudioTensor(compressed.astype(np.float32), sample_rate=tensor.sample_rate)

def expand(tensor: AudioTensor, threshold: float=0.1, ratio: float=2.0) -> AudioTensor:
    if threshold <= 0:
        raise ValueError(f'threshold must be positive, got {threshold}')
    if ratio <= 0:
        raise ValueError(f'ratio must be positive, got {ratio}')
    data = tensor.to_numpy()
    abs_data = np.abs(data)
    mask = abs_data < threshold
    expanded = data.copy()
    expanded[mask] = data[mask] / ratio
    return AudioTensor(expanded.astype(np.float32), sample_rate=tensor.sample_rate)

def gate(tensor: AudioTensor, threshold: float=0.01) -> AudioTensor:
    if threshold < 0:
        raise ValueError(f'threshold must be non-negative, got {threshold}')
    data = tensor.to_numpy()
    result = data.copy()
    result[np.abs(result) < threshold] = 0.0
    return AudioTensor(result.astype(np.float32), sample_rate=tensor.sample_rate)

def follow_envelope(tensor: AudioTensor, attack: float=0.01, release: float=0.1) -> AudioTensor:
    data = tensor.to_numpy()[:, 0] if tensor.is_mono else np.mean(np.abs(tensor.data), axis=1)
    abs_data = np.abs(data)
    alpha_a = 1.0 - np.exp(-1.0 / (attack * tensor.sample_rate))
    alpha_r = 1.0 - np.exp(-1.0 / (release * tensor.sample_rate))
    envelope = np.zeros_like(abs_data)
    envelope[0] = abs_data[0]
    for i in range(1, len(abs_data)):
        alpha = alpha_a if abs_data[i] >= envelope[i - 1] else alpha_r
        envelope[i] = envelope[i - 1] + alpha * (abs_data[i] - envelope[i - 1])
    return AudioTensor(envelope.reshape(-1, 1).astype(np.float32), sample_rate=tensor.sample_rate)

def apply_envelope(tensor: AudioTensor, envelope: AudioTensor) -> AudioTensor:
    data = tensor.to_numpy()
    env_data = envelope.to_numpy()
    n = min(data.shape[0], env_data.shape[0])
    if env_data.shape[1] == 1:
        result = data[:n] * env_data[:n]
    elif env_data.shape[1] == data.shape[1]:
        result = data[:n] * env_data[:n]
    else:
        raise ValueError(f'Envelope channels ({envelope.channels}) must be 1 or match audio channels ({tensor.channels})')
    if data.shape[0] > n:
        result = np.concatenate([result, np.zeros((data.shape[0] - n, data.shape[1]), dtype=np.float32)], axis=0)
    return AudioTensor(result.astype(np.float32), sample_rate=tensor.sample_rate)
