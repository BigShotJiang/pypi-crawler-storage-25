from __future__ import annotations
import numpy as np
from ..core.tensor import AudioTensor
from ..exceptions import ConfigurationError

def trim(tensor: AudioTensor, start: float=0.0, end: float | None=None) -> AudioTensor:
    return tensor.time_slice(start, end)

def pad(tensor: AudioTensor, before: float=0.0, after: float=0.0) -> AudioTensor:
    data = tensor.to_numpy()
    sr = tensor.sample_rate
    ch = tensor.channels
    parts: list[np.ndarray] = []
    if before > 0:
        parts.append(np.zeros((int(before * sr), ch), dtype=np.float32))
    parts.append(data)
    if after > 0:
        parts.append(np.zeros((int(after * sr), ch), dtype=np.float32))
    return AudioTensor(np.concatenate(parts, axis=0), sample_rate=sr)

def concatenate(*tensors: AudioTensor) -> AudioTensor:
    if not tensors:
        raise ValueError('At least one AudioTensor is required')
    ref = tensors[0]
    for t in tensors[1:]:
        if t.sample_rate != ref.sample_rate:
            raise ConfigurationError(f'Sample rate mismatch: {ref.sample_rate} vs {t.sample_rate}')
        if t.channels != ref.channels:
            raise ConfigurationError(f'Channel count mismatch: {ref.channels} vs {t.channels}')
    combined = np.concatenate([t.to_numpy() for t in tensors], axis=0)
    return AudioTensor(combined, sample_rate=ref.sample_rate)

def split(tensor: AudioTensor, at: float) -> tuple[AudioTensor, AudioTensor]:
    idx = int(at * tensor.sample_rate)
    idx = max(0, min(idx, tensor.num_samples))
    data = tensor.to_numpy()
    return (AudioTensor(data[:idx], sample_rate=tensor.sample_rate), AudioTensor(data[idx:], sample_rate=tensor.sample_rate))

def repeat(tensor: AudioTensor, times: int) -> AudioTensor:
    if times <= 0:
        raise ValueError(f'times must be positive, got {times}')
    if times == 1:
        return tensor.copy()
    data = tensor.to_numpy()
    repeated = np.tile(data, (times, 1))
    return AudioTensor(repeated, sample_rate=tensor.sample_rate)

def overlay(base: AudioTensor, layer: AudioTensor, offset: float=0.0) -> AudioTensor:
    if base.sample_rate != layer.sample_rate:
        raise ConfigurationError(f'Sample rate mismatch: {base.sample_rate} vs {layer.sample_rate}')
    if base.channels != layer.channels:
        raise ConfigurationError(f'Channel count mismatch: {base.channels} vs {layer.channels}')
    offset_samples = int(offset * base.sample_rate)
    end_samples = offset_samples + layer.num_samples
    total_length = max(base.num_samples, end_samples)
    result = np.zeros((total_length, base.channels), dtype=np.float32)
    result[:base.num_samples] += base.to_numpy()
    result[offset_samples:end_samples] += layer.to_numpy()
    return AudioTensor(result, sample_rate=base.sample_rate)

def silence(duration: float, sample_rate: int=44100, channels: int=1) -> AudioTensor:
    return AudioTensor.zeros(duration, sample_rate=sample_rate, channels=channels)

def trim_silence(tensor: AudioTensor, threshold: float=0.01, pad_seconds: float=0.05) -> AudioTensor:
    data = tensor.to_numpy()
    mono = np.mean(np.abs(data), axis=1)
    above = np.where(mono >= threshold)[0]
    if len(above) == 0:
        return AudioTensor.zeros(0.0, sample_rate=tensor.sample_rate, channels=tensor.channels)
    start = max(0, above[0] - int(pad_seconds * tensor.sample_rate))
    end = min(tensor.num_samples, above[-1] + 1 + int(pad_seconds * tensor.sample_rate))
    return AudioTensor(data[start:end], sample_rate=tensor.sample_rate)
