from __future__ import annotations
import numpy as np
from typing import Any
from ..core.feature_tensor import FeatureTensor
from ..core.tensor import AudioTensor

def fft(tensor: AudioTensor) -> FeatureTensor:
    data = tensor.data[:, 0] if tensor.is_mono else np.mean(tensor.data, axis=1)
    spectrum = np.fft.rfft(data)
    return FeatureTensor(np.abs(spectrum).reshape(1, -1), sample_rate=tensor.sample_rate, feature_type='fft', n_fft=len(data))

def power_spectrum(tensor: AudioTensor, n_fft: int | None=None) -> FeatureTensor:
    data = tensor.data[:, 0] if tensor.is_mono else np.mean(tensor.data, axis=1)
    if n_fft is None:
        n_fft = len(data)
    spectrum = np.fft.rfft(data, n=n_fft)
    power = np.abs(spectrum) ** 2
    return FeatureTensor(power.reshape(1, -1), sample_rate=tensor.sample_rate, feature_type='power_spectrum', n_fft=n_fft)

def magnitude_spectrum(tensor: AudioTensor, n_fft: int | None=None) -> FeatureTensor:
    data = tensor.data[:, 0] if tensor.is_mono else np.mean(tensor.data, axis=1)
    if n_fft is None:
        n_fft = len(data)
    spectrum = np.fft.rfft(data, n=n_fft)
    return FeatureTensor(np.abs(spectrum).reshape(1, -1), sample_rate=tensor.sample_rate, feature_type='magnitude_spectrum', n_fft=n_fft)

def phase_spectrum(tensor: AudioTensor, n_fft: int | None=None) -> FeatureTensor:
    data = tensor.data[:, 0] if tensor.is_mono else np.mean(tensor.data, axis=1)
    if n_fft is None:
        n_fft = len(data)
    spectrum = np.fft.rfft(data, n=n_fft)
    return FeatureTensor(np.angle(spectrum).reshape(1, -1), sample_rate=tensor.sample_rate, feature_type='phase_spectrum', n_fft=n_fft)

def frequency_axis(tensor_or_rate: AudioTensor | int, n_fft: int | None=None) -> np.ndarray:
    if isinstance(tensor_or_rate, AudioTensor):
        sr = tensor_or_rate.sample_rate
        if n_fft is None:
            n_fft = len(tensor_or_rate)
    else:
        sr = tensor_or_rate
        if n_fft is None:
            raise ValueError('n_fft must be provided when passing a sample rate')
    return np.fft.rfftfreq(n_fft, d=1.0 / sr)

def stft(tensor: AudioTensor, n_fft: int=2048, hop_length: int | None=None, window: str='hann') -> FeatureTensor:
    if hop_length is None:
        hop_length = n_fft // 4
    data = tensor.data[:, 0] if tensor.is_mono else np.mean(tensor.data, axis=1)
    original_len = len(data)
    win = _get_window(window, n_fft)
    n_frames_needed = 1 + max(0, original_len - n_fft + hop_length - 1) // hop_length
    padded_len = n_fft + (n_frames_needed - 1) * hop_length
    if padded_len > original_len:
        data = np.pad(data, (0, padded_len - original_len), mode='constant')
    n_frames = n_frames_needed
    n_bins = n_fft // 2 + 1
    result = np.empty((n_frames, n_bins), dtype=np.complex128)
    for i in range(n_frames):
        start = i * hop_length
        frame = data[start:start + n_fft] * win
        spectrum = np.fft.rfft(frame, n=n_fft)
        result[i] = spectrum[:n_bins]
    return FeatureTensor(result, sample_rate=tensor.sample_rate, feature_type='stft', n_fft=n_fft, hop_length=hop_length)

def istft(feature: FeatureTensor, n_fft: int | None=None, hop_length: int | None=None, window: str='hann', length: int | None=None) -> AudioTensor:
    if n_fft is None:
        n_fft = feature.n_fft or 2 * (feature.n_features - 1)
    if hop_length is None:
        hop_length = feature.hop_length or n_fft // 4
    S = feature.data
    if not np.iscomplexobj(S):
        raise ValueError('ISTFT requires complex-valued input (use STFT output)')
    n_frames = S.shape[0]
    win = _get_window(window, n_fft)
    expected_signal_len = n_fft + hop_length * (n_frames - 1)
    output = np.zeros(expected_signal_len, dtype=np.float64)
    window_sum = np.zeros(expected_signal_len, dtype=np.float64)
    for i in range(n_frames):
        start = i * hop_length
        frame = np.fft.irfft(S[i], n=n_fft)
        output[start:start + n_fft] += frame * win
        window_sum[start:start + n_fft] += win ** 2
    nonzero = window_sum > 1e-10
    output[nonzero] /= window_sum[nonzero]
    if length is not None:
        output = output[:length]
    else:
        output = output[:expected_signal_len]
    return AudioTensor(output.reshape(-1, 1).astype(np.float32), sample_rate=feature.sample_rate)

def magnitude(feature: FeatureTensor) -> FeatureTensor:
    if not np.iscomplexobj(feature.data):
        return feature
    return FeatureTensor(np.abs(feature.data).astype(np.float32), sample_rate=feature.sample_rate, feature_type=feature.feature_type + '_magnitude', n_fft=feature.n_fft, hop_length=feature.hop_length)

def phase(feature: FeatureTensor) -> FeatureTensor:
    if not np.iscomplexobj(feature.data):
        raise ValueError('Phase extraction requires complex-valued input')
    return FeatureTensor(np.angle(feature.data).astype(np.float32), sample_rate=feature.sample_rate, feature_type=feature.feature_type + '_phase', n_fft=feature.n_fft, hop_length=feature.hop_length)

def _get_window(name: str, n_fft: int) -> Any:
    windows = {'hann': np.hanning, 'hamming': np.hamming, 'blackman': np.blackman, 'bartlett': np.bartlett, 'rectangular': lambda n: np.ones(n), 'boxcar': lambda n: np.ones(n)}
    func: Any = windows.get(name.lower())
    if func is None:
        raise ValueError(f"Unknown window '{name}'. Available: {list(windows.keys())}")
    return func(n_fft).astype(np.float64)
