from __future__ import annotations
import numpy as np
from typing import Any
from ..core.feature_tensor import FeatureTensor
from ..core.tensor import AudioTensor
from .spectral import stft as _stft

def _mel_filterbank(n_mels: int, n_fft: int, sr: int, fmin: float=0.0, fmax: float | None=None) -> np.ndarray:
    if fmax is None:
        fmax = sr / 2.0

    def _hz_to_mel(f: Any) -> Any:
        return 2595.0 * np.log10(1.0 + f / 700.0)

    def _mel_to_hz(m: Any) -> Any:
        return 700.0 * (10.0 ** (m / 2595.0) - 1.0)
    mel_min = _hz_to_mel(fmin)
    mel_max = _hz_to_mel(fmax)
    mel_points = np.linspace(mel_min, mel_max, n_mels + 2)
    hz_points = _mel_to_hz(mel_points)
    fft_freqs = np.fft.rfftfreq(n_fft, 1.0 / sr)
    filterbank = np.zeros((n_mels, len(fft_freqs)), dtype=np.float32)
    for i in range(n_mels):
        f_left = hz_points[i]
        f_center = hz_points[i + 1]
        f_right = hz_points[i + 2]
        up_slope = (fft_freqs - f_left) / (f_center - f_left + 1e-10)
        down_slope = (f_right - fft_freqs) / (f_right - f_center + 1e-10)
        filterbank[i] = np.maximum(0, np.minimum(up_slope, down_slope))
    return filterbank

def mel_spectrogram(tensor: AudioTensor, n_fft: int=2048, hop_length: int | None=None, n_mels: int=128, fmin: float=0.0, fmax: float | None=None) -> FeatureTensor:
    if hop_length is None:
        hop_length = n_fft // 4
    stft_result = _stft(tensor, n_fft=n_fft, hop_length=hop_length)
    power = np.abs(stft_result.data) ** 2
    fb = _mel_filterbank(n_mels, n_fft, tensor.sample_rate, fmin, fmax)
    mel_spec = np.dot(power, fb.T).astype(np.float32)
    return FeatureTensor(mel_spec, sample_rate=tensor.sample_rate, feature_type='mel', n_fft=n_fft, hop_length=hop_length)

def mfcc(tensor: AudioTensor, n_mfcc: int=13, n_mels: int=128, n_fft: int=2048, hop_length: int | None=None, fmin: float=0.0, fmax: float | None=None) -> FeatureTensor:
    mel_spec = mel_spectrogram(tensor, n_fft=n_fft, hop_length=hop_length, n_mels=n_mels, fmin=fmin, fmax=fmax)
    log_mel = np.log(mel_spec.data + 1e-10)
    dct_matrix = _dct_matrix(n_mfcc, mel_spec.n_features)
    mfcc_data = np.dot(log_mel, dct_matrix.T).astype(np.float32)
    return FeatureTensor(mfcc_data, sample_rate=tensor.sample_rate, feature_type='mfcc', n_fft=n_fft, hop_length=mel_spec.hop_length)

def _dct_matrix(n: int, m: int) -> np.ndarray:
    mat = np.zeros((n, m), dtype=np.float32)
    for i in range(n):
        for j in range(m):
            mat[i, j] = np.cos(np.pi * (i + 1) * (j + 0.5) / m)
    return mat

def spectral_centroid(tensor: AudioTensor, n_fft: int=2048, hop_length: int | None=None) -> FeatureTensor:
    if hop_length is None:
        hop_length = n_fft // 4
    stft_result = _stft(tensor, n_fft=n_fft, hop_length=hop_length)
    mag = np.abs(stft_result.data)
    freqs = np.fft.rfftfreq(n_fft, 1.0 / tensor.sample_rate)
    freqs = freqs[:mag.shape[1]]
    centroid = np.sum(mag * freqs[np.newaxis, :], axis=1) / (np.sum(mag, axis=1) + 1e-10)
    return FeatureTensor(centroid.reshape(-1, 1).astype(np.float32), sample_rate=tensor.sample_rate, feature_type='spectral_centroid', n_fft=n_fft, hop_length=hop_length)

def spectral_rolloff(tensor: AudioTensor, threshold: float=0.85, n_fft: int=2048, hop_length: int | None=None) -> FeatureTensor:
    if hop_length is None:
        hop_length = n_fft // 4
    stft_result = _stft(tensor, n_fft=n_fft, hop_length=hop_length)
    mag = np.abs(stft_result.data)
    power = mag ** 2
    freqs = np.fft.rfftfreq(n_fft, 1.0 / tensor.sample_rate)
    freqs = freqs[:power.shape[1]]
    cumulative = np.cumsum(power, axis=1)
    total = cumulative[:, -1:]
    threshold_energy = threshold * total
    rolloff_idx = np.argmax(cumulative >= threshold_energy, axis=1)
    rolloff = freqs[rolloff_idx].astype(np.float32)
    return FeatureTensor(rolloff.reshape(-1, 1), sample_rate=tensor.sample_rate, feature_type='spectral_rolloff', n_fft=n_fft, hop_length=hop_length)

def spectral_flatness(tensor: AudioTensor, n_fft: int=2048, hop_length: int | None=None) -> FeatureTensor:
    if hop_length is None:
        hop_length = n_fft // 4
    stft_result = _stft(tensor, n_fft=n_fft, hop_length=hop_length)
    mag = np.abs(stft_result.data)
    mag = np.maximum(mag, 1e-10)
    geometric_mean = np.exp(np.mean(np.log(mag), axis=1))
    arithmetic_mean = np.mean(mag, axis=1)
    flatness = geometric_mean / (arithmetic_mean + 1e-10)
    return FeatureTensor(flatness.reshape(-1, 1).astype(np.float32), sample_rate=tensor.sample_rate, feature_type='spectral_flatness', n_fft=n_fft, hop_length=hop_length)

def spectral_bandwidth(tensor: AudioTensor, n_fft: int=2048, hop_length: int | None=None, order: int=2) -> FeatureTensor:
    if hop_length is None:
        hop_length = n_fft // 4
    stft_result = _stft(tensor, n_fft=n_fft, hop_length=hop_length)
    mag = np.abs(stft_result.data)
    freqs = np.fft.rfftfreq(n_fft, 1.0 / tensor.sample_rate)
    freqs = freqs[:mag.shape[1]]
    centroid = np.sum(mag * freqs[np.newaxis, :], axis=1) / (np.sum(mag, axis=1) + 1e-10)
    deviation = np.sum(mag * np.abs(freqs[np.newaxis, :] - centroid[:, np.newaxis]) ** order, axis=1) / (np.sum(mag, axis=1) + 1e-10)
    bandwidth = deviation ** (1.0 / order)
    return FeatureTensor(bandwidth.reshape(-1, 1).astype(np.float32), sample_rate=tensor.sample_rate, feature_type='spectral_bandwidth', n_fft=n_fft, hop_length=hop_length)
