from __future__ import annotations
import numpy as np
from ..core.tensor import AudioTensor

def _resample_signal(data: np.ndarray, n_new: int) -> np.ndarray:
    from scipy.signal import resample as _resample
    if n_new <= 0:
        return np.zeros(0, dtype=data.dtype)
    return _resample(data, n_new)

def pitch_shift(tensor: AudioTensor, semitones: float) -> AudioTensor:
    freq_ratio = 2.0 ** (semitones / 12.0)
    data = tensor.data[:, 0] if tensor.is_mono else np.mean(tensor.data, axis=1)
    n_new = max(1, int(round(len(data) / freq_ratio)))
    resampled = _resample_signal(data, n_new)
    temp = AudioTensor(resampled.reshape(-1, 1).astype(np.float32), sample_rate=tensor.sample_rate)
    result = time_stretch(temp, 1.0 / freq_ratio)
    n_target = tensor.num_samples
    out = result.data[:, 0]
    if len(out) < n_target:
        out = np.pad(out, (0, n_target - len(out)))
    else:
        out = out[:n_target]
    final = np.tile(out.reshape(-1, 1), (1, tensor.channels))
    return AudioTensor(final.astype(np.float32), sample_rate=tensor.sample_rate)

def time_stretch(tensor: AudioTensor, rate: float) -> AudioTensor:
    from scipy.signal import stft as _scipy_stft, istft as _scipy_istft
    data = tensor.data[:, 0] if tensor.is_mono else np.mean(tensor.data, axis=1)
    n_fft = 2048
    hop_length = n_fft // 4
    f, _, Zxx = _scipy_stft(data, fs=tensor.sample_rate, nperseg=n_fft, noverlap=n_fft - hop_length)
    n_frames = Zxx.shape[1]
    new_n_frames = max(1, int(round(n_frames / rate)))
    indices = np.linspace(0, n_frames - 1, new_n_frames)
    expected_phase = 2.0 * np.pi * f * hop_length / tensor.sample_rate
    new_Zxx = np.zeros((len(f), new_n_frames), dtype=np.complex128)
    prev_phase = np.angle(Zxx[:, 0]).copy()
    for i in range(new_n_frames):
        src_idx = min(int(round(indices[i])), n_frames - 1)
        frac = indices[i] - int(indices[i])
        next_idx = min(src_idx + 1, n_frames - 1)
        magnitude = (1.0 - frac) * np.abs(Zxx[:, src_idx]) + frac * np.abs(Zxx[:, next_idx])
        new_Zxx[:, i] = magnitude * np.exp(1j * prev_phase)
        if src_idx < n_frames - 1:
            phase_delta = np.angle(Zxx[:, src_idx + 1]) - np.angle(Zxx[:, src_idx])
        else:
            phase_delta = np.zeros(len(f))
        deviation = phase_delta - expected_phase
        deviation = (deviation + np.pi) % (2.0 * np.pi) - np.pi
        prev_phase = prev_phase + expected_phase + deviation
    _, reconstructed = _scipy_istft(new_Zxx, fs=tensor.sample_rate, nperseg=n_fft, noverlap=n_fft - hop_length)
    orig_energy = np.sqrt(np.mean(data ** 2))
    if len(reconstructed) > 0 and orig_energy > 0:
        recon_energy = np.sqrt(np.mean(reconstructed ** 2))
        if recon_energy > 0:
            reconstructed = reconstructed * (orig_energy / recon_energy)
    n_samples = int(round(tensor.num_samples / rate))
    if len(reconstructed) < n_samples:
        reconstructed = np.pad(reconstructed, (0, n_samples - len(reconstructed)))
    else:
        reconstructed = reconstructed[:n_samples]
    result = np.tile(reconstructed.reshape(-1, 1), (1, tensor.channels))
    return AudioTensor(result.astype(np.float32), sample_rate=tensor.sample_rate)

def estimate_f0(tensor: AudioTensor, frame_duration: float=0.05) -> list[float]:
    data = tensor.data[:, 0] if tensor.is_mono else np.mean(tensor.data, axis=1)
    sr = tensor.sample_rate
    frame_len = int(frame_duration * sr)
    min_lag = int(sr / 1000)
    max_lag = int(sr / 50)
    f0_values: list[float] = []
    pos = 0
    while pos + frame_len <= len(data):
        frame = data[pos:pos + frame_len]
        frame = frame - np.mean(frame)
        corr = np.correlate(frame, frame, mode='full')
        corr = corr[len(frame) - 1:]
        search_range = corr[min_lag:max_lag + 1]
        if len(search_range) == 0 or np.max(np.abs(search_range)) < 1e-06:
            f0_values.append(0.0)
        else:
            peak_idx = np.argmax(search_range) + min_lag
            threshold = 0.3 * corr[0]
            if corr[peak_idx] > threshold:
                f0_values.append(round(sr / peak_idx, 1))
            else:
                f0_values.append(0.0)
        pos += frame_len
    return f0_values
