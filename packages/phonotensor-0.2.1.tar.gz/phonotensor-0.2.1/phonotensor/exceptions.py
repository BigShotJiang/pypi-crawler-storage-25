class PhonotensorError(Exception):
    pass

class BackendUnavailableError(PhonotensorError):
    pass

class DeviceNotFoundError(PhonotensorError):
    pass

class StreamError(PhonotensorError):
    pass

class ConfigurationError(PhonotensorError):
    pass

class PhonotensorPermissionError(PhonotensorError):
    pass

class FilePermissionError(PhonotensorPermissionError):
    pass

class DevicePermissionError(PhonotensorPermissionError):
    pass

class MicrophonePermissionError(DevicePermissionError):
    pass
