import numpy as np
import pytest
from phonotensor import AudioTensor, FeatureTensor, ops

class TestFeatureTensor:

    def test_construction_2d(self):
        data = np.random.randn(10, 5).astype(np.float32)
        ft = FeatureTensor(data, sample_rate=44100, feature_type='custom', n_fft=1024, hop_length=256)
        assert ft.n_frames == 10
        assert ft.n_features == 5
        assert ft.feature_type == 'custom'
        assert ft.n_fft == 1024
        assert ft.hop_length == 256
        assert ft.frame_rate == pytest.approx(44100 / 256, rel=1e-06)
        assert ft.duration == pytest.approx(10 * 256 / 44100, rel=1e-06)

    def test_construction_1d(self):
        data = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        ft = FeatureTensor(data, sample_rate=16000, feature_type='test')
        assert ft.n_frames == 3
        assert ft.n_features == 1

    def test_immutable_data(self):
        data = np.ones((5, 3), dtype=np.float32)
        ft = FeatureTensor(data, sample_rate=44100, feature_type='test')
        assert not ft.data.flags.writeable

    def test_to_numpy_writable(self):
        data = np.ones((5, 3), dtype=np.float32)
        ft = FeatureTensor(data, sample_rate=44100, feature_type='test')
        copy = ft.to_numpy()
        copy[0, 0] = 999.0
        assert ft.data[0, 0] == pytest.approx(1.0)
        assert copy[0, 0] == pytest.approx(999.0)

    def test_is_complex(self):
        data = np.ones((5, 3), dtype=np.complex128)
        ft = FeatureTensor(data, sample_rate=44100, feature_type='stft')
        assert ft.is_complex is True

    def test_repr_and_summary(self):
        data = np.ones((5, 3), dtype=np.float32)
        ft = FeatureTensor(data, sample_rate=44100, feature_type='custom', n_fft=1024, hop_length=256)
        r = repr(ft)
        assert 'FeatureTensor' in r
        assert '5' in r
        s = ft.summary()
        assert 'Frames' in s
        assert 'Features' in s

    def test_invalid_dimensions(self):
        with pytest.raises(ValueError):
            FeatureTensor(np.zeros((2, 3, 4)), sample_rate=44100)

    def test_invalid_sample_rate(self):
        with pytest.raises(ValueError):
            FeatureTensor(np.zeros((5, 3)), sample_rate=0)

    def test_to_dict(self):
        data = np.ones((5, 3), dtype=np.float32)
        ft = FeatureTensor(data, sample_rate=44100, feature_type='mel', n_fft=1024, hop_length=256)
        d = ft.to_dict()
        assert d['sample_rate'] == 44100
        assert d['feature_type'] == 'mel'
        assert d['n_fft'] == 1024
        assert d['hop_length'] == 256
        assert d['n_frames'] == 5
        assert d['n_features'] == 3

    def test_frame_rate_none(self):
        data = np.ones((5, 3), dtype=np.float32)
        ft = FeatureTensor(data, sample_rate=44100, feature_type='test')
        assert ft.frame_rate is None
        assert ft.duration is None

class TestSpectral:

    def setup_method(self):
        self.tone = AudioTensor.from_function(lambda t: 0.5 * np.sin(2 * np.pi * 440 * t), duration=1.0, sample_rate=22050)

    def test_fft(self):
        result = ops.fft(self.tone)
        assert isinstance(result, FeatureTensor)
        assert result.feature_type == 'fft'
        assert result.n_frames == 1
        assert result.n_features > 0

    def test_power_spectrum(self):
        result = ops.power_spectrum(self.tone)
        assert result.feature_type == 'power_spectrum'
        assert result.n_frames == 1

    def test_magnitude_spectrum(self):
        result = ops.magnitude_spectrum(self.tone)
        assert result.feature_type == 'magnitude_spectrum'
        assert result.n_frames == 1

    def test_phase_spectrum(self):
        result = ops.phase_spectrum(self.tone)
        assert result.feature_type == 'phase_spectrum'
        assert result.n_frames == 1

    def test_stft(self):
        result = ops.stft(self.tone, n_fft=1024, hop_length=256)
        assert isinstance(result, FeatureTensor)
        assert result.feature_type == 'stft'
        assert result.is_complex
        assert result.n_fft == 1024
        assert result.hop_length == 256
        assert result.n_features == 513
        assert result.frame_rate == pytest.approx(22050 / 256, rel=1e-06)

    def test_stft_istft_roundtrip(self):
        stft_result = ops.stft(self.tone, n_fft=1024, hop_length=256)
        reconstructed = ops.istft(stft_result, length=self.tone.num_samples)
        assert reconstructed.num_samples == self.tone.num_samples
        assert reconstructed.sample_rate == self.tone.sample_rate
        orig = self.tone.data[:, 0]
        recon = reconstructed.data[:, 0]
        overlap = min(len(orig), len(recon))
        correlation = np.corrcoef(orig[:overlap], recon[:overlap])[0, 1]
        assert correlation > 0.95

    def test_magnitude_extraction(self):
        stft_result = ops.stft(self.tone, n_fft=1024, hop_length=256)
        mag = ops.magnitude(stft_result)
        assert not mag.is_complex
        assert mag.feature_type == 'stft_magnitude'

    def test_phase_extraction(self):
        stft_result = ops.stft(self.tone, n_fft=1024, hop_length=256)
        ph = ops.phase(stft_result)
        assert not ph.is_complex
        assert ph.feature_type == 'stft_phase'

    def test_frequency_axis(self):
        freqs = ops.frequency_axis(self.tone, n_fft=1024)
        assert len(freqs) == 513
        assert freqs[0] == pytest.approx(0.0)
        assert freqs[-1] == pytest.approx(22050 / 2, rel=0.001)

class TestFilter:

    def setup_method(self):
        self.tone = AudioTensor.from_function(lambda t: 0.5 * np.sin(2 * np.pi * 440 * t), duration=1.0, sample_rate=22050)

    def test_lowpass(self):
        result = ops.lowpass(self.tone, cutoff=1000)
        assert result.num_samples == self.tone.num_samples
        assert result.sample_rate == self.tone.sample_rate
        assert ops.peak(result) < ops.peak(self.tone)

    def test_highpass(self):
        result = ops.highpass(self.tone, cutoff=8000)
        assert result.num_samples == self.tone.num_samples
        assert ops.peak(result) < ops.peak(self.tone)

    def test_bandpass(self):
        result = ops.bandpass(self.tone, low_cutoff=200, high_cutoff=2000)
        assert result.num_samples == self.tone.num_samples

    def test_bandstop(self):
        result = ops.bandstop(self.tone, low_cutoff=200, high_cutoff=2000)
        assert result.num_samples == self.tone.num_samples

    def test_notch(self):
        result = ops.notch(self.tone, freq=440, q=30.0)
        assert result.num_samples == self.tone.num_samples
        assert ops.rms(result) < ops.rms(self.tone)

class TestFeatures:

    def setup_method(self):
        self.tone = AudioTensor.from_function(lambda t: 0.5 * np.sin(2 * np.pi * 440 * t), duration=1.0, sample_rate=22050)

    def test_mel_spectrogram(self):
        mel = ops.mel_spectrogram(self.tone, n_fft=1024, n_mels=80)
        assert isinstance(mel, FeatureTensor)
        assert mel.feature_type == 'mel'
        assert mel.n_features == 80
        assert mel.n_fft == 1024
        assert mel.hop_length == 256

    def test_mfcc(self):
        mfcc = ops.mfcc(self.tone, n_mfcc=13, n_fft=1024, n_mels=80)
        assert isinstance(mfcc, FeatureTensor)
        assert mfcc.feature_type == 'mfcc'
        assert mfcc.n_features == 13

    def test_spectral_centroid(self):
        sc = ops.spectral_centroid(self.tone, n_fft=1024)
        assert isinstance(sc, FeatureTensor)
        assert sc.n_features == 1
        avg_centroid = float(np.mean(sc.data))
        assert 400 < avg_centroid < 500, f'Expected ~440Hz, got {avg_centroid}'

    def test_spectral_rolloff(self):
        sr = ops.spectral_rolloff(self.tone, n_fft=1024)
        assert isinstance(sr, FeatureTensor)
        assert sr.n_features == 1

    def test_spectral_flatness(self):
        sf = ops.spectral_flatness(self.tone, n_fft=1024)
        assert isinstance(sf, FeatureTensor)
        avg_flat = float(np.mean(sf.data))
        assert avg_flat < 0.01, f'Pure tone should have low flatness, got {avg_flat}'

    def test_spectral_bandwidth(self):
        sb = ops.spectral_bandwidth(self.tone, n_fft=1024)
        assert isinstance(sb, FeatureTensor)
        assert sb.n_features == 1

class TestGenerate:

    def test_sine(self):
        s = ops.sine(440, duration=1.0)
        assert s.num_samples == 44100
        assert s.sample_rate == 44100
        assert ops.peak(s) == pytest.approx(1.0, abs=0.01)

    def test_square(self):
        s = ops.square(440, duration=0.5)
        assert s.num_samples == 22050
        assert ops.peak(s) == pytest.approx(1.0, abs=0.01)

    def test_sawtooth(self):
        s = ops.sawtooth(440, duration=0.5)
        assert s.num_samples == 22050
        assert ops.peak(s) == pytest.approx(1.0, abs=0.05)

    def test_triangle(self):
        s = ops.triangle(440, duration=0.5)
        assert s.num_samples == 22050
        assert ops.peak(s) == pytest.approx(1.0, abs=0.01)

    def test_impulse(self):
        s = ops.impulse(0.5)
        assert s.num_samples == 22050
        assert s.data[0, 0] == 1.0
        assert float(np.sum(np.abs(s.data))) == pytest.approx(1.0, abs=0.01)

    def test_white_noise(self):
        s = ops.white_noise(1.0, seed=42)
        assert s.num_samples == 44100
        assert 0.5 < ops.rms(s) < 0.7

    def test_pink_noise(self):
        s = ops.pink_noise(1.0, seed=42)
        assert s.num_samples == 44100
        assert ops.peak(s) == pytest.approx(1.0, abs=0.01)

    def test_sweep(self):
        s = ops.sweep(200, 2000, duration=1.0)
        assert s.num_samples == 44100
        assert ops.peak(s) == pytest.approx(1.0, abs=0.01)

    def test_sine_with_amplitude(self):
        s = ops.sine(440, duration=1.0, amplitude=0.3)
        assert ops.peak(s) == pytest.approx(0.3, abs=0.01)

    def test_white_noise_reproducible(self):
        s1 = ops.white_noise(1.0, seed=42)
        s2 = ops.white_noise(1.0, seed=42)
        assert np.allclose(s1.data, s2.data)

class TestEnvelope:

    def setup_method(self):
        self.tone = AudioTensor.from_function(lambda t: 0.5 * np.sin(2 * np.pi * 440 * t), duration=1.0, sample_rate=44100)

    def test_adsr(self):
        env = ops.adsr(0.1, 0.1, 0.7, 0.3, duration=1.0, sample_rate=44100)
        assert env.num_samples == 44100
        assert env.channels == 1
        assert ops.peak(env) == pytest.approx(1.0, abs=0.01)

    def test_compress(self):
        result = ops.compress(self.tone, threshold=0.3, ratio=4.0)
        assert result.num_samples == self.tone.num_samples
        assert ops.peak(result) < ops.peak(self.tone)

    def test_expand(self):
        result = ops.expand(self.tone, threshold=0.1, ratio=2.0)
        assert result.num_samples == self.tone.num_samples

    def test_gate(self):
        data = np.array([0.001, 0.5, 0.001, 0.3, 0.001], dtype=np.float32).reshape(-1, 1)
        t = AudioTensor(data, sample_rate=100)
        gated = ops.gate(t, threshold=0.01)
        assert gated.data[0, 0] == pytest.approx(0.0)
        assert abs(gated.data[1, 0]) > 0.01

    def test_follow_envelope(self):
        env = ops.follow_envelope(self.tone, attack=0.01, release=0.1)
        assert env.num_samples == self.tone.num_samples
        assert env.channels == 1

    def test_apply_envelope(self):
        env = ops.adsr(0.01, 0.01, 0.7, 0.05, duration=1.0, sample_rate=44100)
        result = ops.apply_envelope(self.tone, env)
        assert result.num_samples == self.tone.num_samples

class TestConvolution:

    def setup_method(self):
        self.tone = AudioTensor.from_function(lambda t: 0.5 * np.sin(2 * np.pi * 440 * t), duration=0.5, sample_rate=22050)

    def test_convolve_with_impulse(self):
        impulse = ops.impulse(0.01, sample_rate=22050)
        result = ops.convolve(self.tone, impulse, mode='same')
        assert result.num_samples == self.tone.num_samples

    def test_auto_correlate(self):
        result = ops.auto_correlate(self.tone)
        assert result.num_samples > 0
        assert result.channels == 1
        assert result.data[0, 0] == pytest.approx(1.0, abs=0.01)

    def test_cross_correlate(self):
        result = ops.cross_correlate(self.tone, self.tone)
        assert result.num_samples > 0

    def test_convolve_sample_rate_mismatch(self):
        other = AudioTensor(np.zeros(10), sample_rate=16000)
        with pytest.raises(ValueError):
            ops.convolve(self.tone, other)

class TestPitch:

    def setup_method(self):
        self.tone = AudioTensor.from_function(lambda t: 0.5 * np.sin(2 * np.pi * 440 * t), duration=1.0, sample_rate=22050)

    def test_estimate_f0(self):
        f0_values = ops.estimate_f0(self.tone, frame_duration=0.05)
        assert len(f0_values) > 0
        voiced = [f for f in f0_values if f > 0]
        avg_f0 = np.mean(voiced) if voiced else 0
        assert 400 < avg_f0 < 500, f'Expected ~440Hz, got {avg_f0}'

    def test_estimate_f0_silence(self):
        silence = AudioTensor.zeros(1.0, sample_rate=22050)
        f0_values = ops.estimate_f0(silence)
        assert all((f == 0.0 for f in f0_values))

    def test_pitch_shift_up(self):
        tone = ops.sine(440, duration=1.0, sample_rate=22050, amplitude=0.5)
        shifted = ops.pitch_shift(tone, 12)
        f0 = ops.estimate_f0(shifted, frame_duration=0.05)
        voiced = [f for f in f0 if f > 0]
        avg = np.mean(voiced) if voiced else 0
        assert 840 < avg < 920, f'Expected ~880Hz for +12 semitones, got {avg}'

    def test_pitch_shift_down(self):
        tone = ops.sine(440, duration=1.0, sample_rate=22050, amplitude=0.5)
        shifted = ops.pitch_shift(tone, -12)
        f0 = ops.estimate_f0(shifted, frame_duration=0.05)
        voiced = [f for f in f0 if f > 0]
        avg = np.mean(voiced) if voiced else 0
        assert 200 < avg < 250, f'Expected ~220Hz for -12 semitones, got {avg}'

    def test_pitch_shift_preserves_duration(self):
        tone = ops.sine(440, duration=2.0, sample_rate=22050, amplitude=0.5)
        shifted = ops.pitch_shift(tone, 7)
        assert abs(shifted.duration - tone.duration) < 0.1

    def test_time_stretch_faster(self):
        tone = ops.sine(440, duration=2.0, sample_rate=22050, amplitude=0.5)
        fast = ops.time_stretch(tone, 2.0)
        assert abs(fast.duration - 1.0) < 0.1
        f0 = ops.estimate_f0(fast, frame_duration=0.05)
        voiced = [f for f in f0 if f > 0]
        avg = np.mean(voiced) if voiced else 0
        assert 400 < avg < 500, f'Expected ~440Hz, got {avg}'

    def test_time_stretch_slower(self):
        tone = ops.sine(440, duration=1.0, sample_rate=22050, amplitude=0.5)
        slow = ops.time_stretch(tone, 0.5)
        assert abs(slow.duration - 2.0) < 0.1

class TestInputValidation:

    def test_sine_invalid_freq(self):
        with pytest.raises(ValueError, match='freq must be positive'):
            ops.sine(-100, duration=1.0)

    def test_sine_invalid_duration(self):
        with pytest.raises(ValueError, match='duration must be positive'):
            ops.sine(440, duration=0.0)

    def test_sweep_invalid_start_freq(self):
        with pytest.raises(ValueError, match='start_freq must be positive'):
            ops.sweep(-100, 1000, duration=1.0)

    def test_adsr_invalid_duration(self):
        with pytest.raises(ValueError, match='duration must be positive'):
            ops.adsr(0.01, 0.1, 0.7, 0.2, duration=0.0)

    def test_compress_invalid_threshold(self):
        t = ops.sine(440, duration=0.5)
        with pytest.raises(ValueError, match='threshold'):
            ops.compress(t, threshold=0.0)

    def test_compress_invalid_ratio(self):
        t = ops.sine(440, duration=0.5)
        with pytest.raises(ValueError, match='ratio'):
            ops.compress(t, ratio=-1.0)

    def test_lowpass_above_nyquist(self):
        t = ops.sine(440, duration=0.5, sample_rate=22050)
        with pytest.raises(ValueError, match='exceeds Nyquist'):
            ops.lowpass(t, cutoff=15000)

    def test_notch_above_nyquist(self):
        t = ops.sine(440, duration=0.5, sample_rate=22050)
        with pytest.raises(ValueError, match='below Nyquist'):
            ops.notch(t, freq=15000)

    def test_convolve_multi_channel_kernel(self):
        t = AudioTensor(np.random.randn(1000, 2).astype(np.float32), sample_rate=44100)
        k_stereo = AudioTensor(np.random.randn(100, 2).astype(np.float32), sample_rate=44100)
        result = ops.convolve(t, k_stereo, mode='same')
        assert result.channels == 2
        assert result.num_samples == t.num_samples
