import json
import tempfile
import os
import numpy as np
import pytest
from phonotensor import AudioTensor, FileIO, TextIO, fmt

class TestFileIO:

    def _make_tone(self):
        return AudioTensor.from_function(lambda t: 0.5 * np.sin(2 * np.pi * 440 * t), duration=0.1, sample_rate=16000)

    def test_wav_roundtrip(self):
        t = self._make_tone()
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'test.wav')
            FileIO.write(t, path)
            loaded = FileIO.read(path)
            assert loaded.num_samples == t.num_samples
            assert loaded.sample_rate == t.sample_rate

    def test_flac_roundtrip(self):
        t = self._make_tone()
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'test.flac')
            FileIO.write(t, path)
            loaded = FileIO.read(path)
            assert loaded.num_samples == t.num_samples

    def test_missing_file(self):
        with pytest.raises(FileNotFoundError):
            FileIO.read('nonexistent_file.wav')

    def test_supported_formats(self):
        formats = FileIO.supported_formats()
        assert 'wav' in formats
        assert 'flac' in formats

class TestTextIO:

    def _make_tone(self):
        return AudioTensor.from_function(lambda t: np.sin(2 * np.pi * 440 * t), duration=0.05, sample_rate=8000)

    def test_csv_roundtrip(self):
        t = self._make_tone()
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'test.csv')
            TextIO.write_csv(t, path)
            loaded = TextIO.read_csv(path, sample_rate=8000)
            assert loaded.num_samples == t.num_samples

    def test_json_roundtrip(self):
        t = self._make_tone()
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'test.json')
            TextIO.write_json(t, path)
            loaded = TextIO.read_json(path)
            assert loaded.sample_rate == 8000

    def test_array_roundtrip(self):
        t = self._make_tone()
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'test.txt')
            TextIO.write_array(t, path)
            loaded = TextIO.read_array(path, sample_rate=8000)
            assert loaded.num_samples == t.num_samples

    def test_from_list(self):
        t = TextIO.from_list([0.0, 0.5, 1.0], sample_rate=8000)
        assert t.num_samples == 3

    def test_from_function(self):
        t = TextIO.from_function(lambda x: np.ones_like(x), duration=0.5, sample_rate=8000)
        assert t.num_samples == 4000

class TestFmtDisplay:

    def _make_tone(self):
        return AudioTensor.from_function(lambda t: np.sin(2 * np.pi * 440 * t), duration=0.1, sample_rate=8000)

    def test_summary(self):
        t = self._make_tone()
        s = fmt.summary(t)
        assert 'AudioTensor' in s
        assert '8000Hz' in s

    def test_describe(self):
        t = self._make_tone()
        d = fmt.describe(t)
        assert 'Peak' in d
        assert 'RMS' in d

    def test_waveform_ascii(self):
        t = self._make_tone()
        w = fmt.waveform_ascii(t, width=40, height=10)
        assert len(w) > 0
        lines = w.split('\n')
        assert len(lines) == 11

    def test_print_samples(self):
        t = self._make_tone()
        s = fmt.print_samples(t, n=5)
        assert '[     0]' in s

class TestFmtConvert:

    def _make_tone(self):
        return AudioTensor(np.array([0.1, 0.2, 0.3], dtype=np.float32))

    def test_to_list_mono(self):
        t = self._make_tone()
        lst = fmt.to_list(t)
        assert len(lst) == 3
        assert isinstance(lst[0], float)

    def test_to_dict(self):
        t = self._make_tone()
        d = fmt.to_dict(t)
        assert d['sample_rate'] == 44100
        assert d['channels'] == 1
        assert d['num_samples'] == 3

    def test_to_json(self):
        t = self._make_tone()
        j = fmt.to_json(t)
        parsed = json.loads(j)
        assert parsed['sample_rate'] == 44100

    def test_to_csv_string(self):
        t = self._make_tone()
        csv = fmt.to_csv_string(t)
        lines = csv.strip().split('\n')
        assert lines[0] == 'ch0'
        assert len(lines) == 4
