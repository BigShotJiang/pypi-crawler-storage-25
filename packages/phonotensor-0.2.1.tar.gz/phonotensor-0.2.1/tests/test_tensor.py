import numpy as np
import pytest
from phonotensor import AudioTensor

class TestConstruction:

    def test_from_1d_array(self):
        data = np.array([0.1, 0.2, 0.3], dtype=np.float32)
        t = AudioTensor(data)
        assert t.num_samples == 3
        assert t.channels == 1
        assert t.shape == (3, 1)

    def test_from_2d_array(self):
        data = np.zeros((100, 2), dtype=np.float32)
        t = AudioTensor(data)
        assert t.channels == 2
        assert t.num_samples == 100

    def test_from_list(self):
        t = AudioTensor.from_list([0.0, 0.5, 1.0, 0.5, 0.0])
        assert t.num_samples == 5

    def test_from_function(self):
        t = AudioTensor.from_function(lambda x: np.sin(2 * np.pi * 440 * x), duration=1.0, sample_rate=16000)
        assert t.num_samples == 16000
        assert t.sample_rate == 16000
        assert abs(t.duration - 1.0) < 0.001

    def test_zeros(self):
        t = AudioTensor.zeros(0.5, sample_rate=8000, channels=2)
        assert t.num_samples == 4000
        assert t.channels == 2
        assert float(np.max(np.abs(t.data))) == 0.0

    def test_invalid_sample_rate(self):
        with pytest.raises(ValueError):
            AudioTensor(np.zeros(10), sample_rate=0)

    def test_invalid_dimensions(self):
        with pytest.raises(ValueError):
            AudioTensor(np.zeros((2, 3, 4)))

    def test_channel_mismatch(self):
        with pytest.raises(ValueError):
            AudioTensor(np.zeros((10, 2)), channels=3)

class TestProperties:

    def test_duration(self):
        t = AudioTensor(np.zeros((44100, 1)), sample_rate=44100)
        assert abs(t.duration - 1.0) < 0.001

    def test_is_mono(self):
        assert AudioTensor(np.zeros((10, 1))).is_mono
        assert not AudioTensor(np.zeros((10, 2))).is_mono

    def test_is_stereo(self):
        assert AudioTensor(np.zeros((10, 2))).is_stereo
        assert not AudioTensor(np.zeros((10, 1))).is_stereo

    def test_immutable_data(self):
        t = AudioTensor(np.zeros(10))
        assert not t.data.flags.writeable

class TestArithmetic:

    def test_add_tensors(self):
        a = AudioTensor(np.ones((10, 1)))
        b = AudioTensor(np.ones((10, 1)))
        c = a + b
        assert np.allclose(c.data, 2.0)

    def test_add_scalar(self):
        a = AudioTensor(np.ones((10, 1)))
        c = a + 1.0
        assert np.allclose(c.data, 2.0)

    def test_multiply_scalar(self):
        a = AudioTensor(np.ones((10, 1)))
        c = a * 0.5
        assert np.allclose(c.data, 0.5)

    def test_negate(self):
        a = AudioTensor(np.ones((10, 1)))
        c = -a
        assert np.allclose(c.data, -1.0)

    def test_abs(self):
        a = AudioTensor(-np.ones((10, 1)))
        c = abs(a)
        assert np.allclose(c.data, 1.0)

    def test_sample_rate_mismatch(self):
        a = AudioTensor(np.ones((10, 1)), sample_rate=44100)
        b = AudioTensor(np.ones((10, 1)), sample_rate=22050)
        with pytest.raises(ValueError):
            _ = a + b

class TestSlicing:

    def test_time_slice(self):
        t = AudioTensor(np.arange(100, dtype=np.float32).reshape(-1, 1), sample_rate=100)
        sliced = t.time_slice(0.5, 0.8)
        assert sliced.num_samples == 30

    def test_len(self):
        t = AudioTensor(np.zeros((50, 1)))
        assert len(t) == 50

class TestConversion:

    def test_to_mono(self):
        data = np.array([[1.0, 0.0], [0.0, 1.0]], dtype=np.float32)
        t = AudioTensor(data)
        mono = t.to_mono()
        assert mono.channels == 1
        assert np.allclose(mono.data[:, 0], [0.5, 0.5])

    def test_to_stereo(self):
        t = AudioTensor(np.ones((10, 1)))
        stereo = t.to_stereo()
        assert stereo.channels == 2

    def test_channel_extract(self):
        data = np.array([[1.0, 2.0], [3.0, 4.0]], dtype=np.float32)
        t = AudioTensor(data)
        ch0 = t.channel(0)
        ch1 = t.channel(1)
        assert np.allclose(ch0.data[:, 0], [1.0, 3.0])
        assert np.allclose(ch1.data[:, 0], [2.0, 4.0])

    def test_to_numpy_writable(self):
        t = AudioTensor(np.zeros(10))
        arr = t.to_numpy()
        arr[0] = 999.0
        assert arr.flags.writeable

    def test_copy(self):
        t = AudioTensor(np.ones((10, 1)))
        c = t.copy()
        assert t == c
        assert t is not c

class TestDisplay:

    def test_repr(self):
        t = AudioTensor(np.zeros((100, 1)), sample_rate=44100)
        r = repr(t)
        assert 'AudioTensor' in r
        assert '44100' in r

    def test_summary(self):
        t = AudioTensor(np.zeros((100, 1)))
        s = t.summary()
        assert 'Sample Rate' in s

    def test_describe(self):
        t = AudioTensor(np.zeros((100, 1)))
        d = t.describe()
        assert 'Min' in d

    def test_hash_equality(self):
        data = np.array([0.1, 0.2, 0.3], dtype=np.float32)
        a = AudioTensor(data, sample_rate=44100)
        b = AudioTensor(data.copy(), sample_rate=44100)
        assert a == b
        assert hash(a) == hash(b)

    def test_hash_inequality(self):
        a = AudioTensor(np.array([0.1, 0.2], dtype=np.float32), sample_rate=44100)
        b = AudioTensor(np.array([0.3, 0.4], dtype=np.float32), sample_rate=44100)
        assert a != b
        assert hash(a) != hash(b)

    def test_hash_in_set(self):
        data = np.array([0.1, 0.2, 0.3], dtype=np.float32)
        a = AudioTensor(data, sample_rate=44100)
        b = AudioTensor(data.copy(), sample_rate=44100)
        s = {a, b}
        assert len(s) == 1

    def test_getitem_integer_mono(self):
        t = AudioTensor(np.array([[0.1], [0.2], [0.3]], dtype=np.float32), sample_rate=44100)
        result = t[0]
        assert result.shape == (1, 1)
        assert result.data[0, 0] == pytest.approx(0.1)

    def test_getitem_integer_stereo(self):
        t = AudioTensor(np.array([[0.1, 0.2], [0.3, 0.4]], dtype=np.float32), sample_rate=44100)
        result = t[0]
        assert result.shape == (1, 2)
        assert result.data[0, 0] == pytest.approx(0.1)
        assert result.data[0, 1] == pytest.approx(0.2)

    def test_truediv(self):
        a = AudioTensor(np.array([[2.0], [4.0]], dtype=np.float32), sample_rate=44100)
        result = a / 2.0
        assert np.allclose(result.data, [[1.0], [2.0]])

    def test_rtruediv(self):
        a = AudioTensor(np.array([[2.0], [4.0]], dtype=np.float32), sample_rate=44100)
        result = 8.0 / a
        assert np.allclose(result.data, [[4.0], [2.0]])

    def test_from_numpy(self):
        data = np.array([0.5, 0.6, 0.7], dtype=np.float32)
        t = AudioTensor.from_numpy(data, sample_rate=22050)
        assert t.sample_rate == 22050
        assert t.num_samples == 3
