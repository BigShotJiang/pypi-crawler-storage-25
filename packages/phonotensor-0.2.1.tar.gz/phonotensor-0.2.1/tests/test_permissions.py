import os
import stat
import sys
import tempfile
import numpy as np
import pytest
from phonotensor import AudioTensor, FileIO, TextIO
from phonotensor.exceptions import FilePermissionError, MicrophonePermissionError, DevicePermissionError
from phonotensor.permissions import can_access_microphone, can_read_file, can_write_file, check_file_readable, check_file_writable
_IS_WINDOWS = sys.platform == 'win32'
_SKIP_READ_PERM = pytest.mark.skipif(_IS_WINDOWS, reason='Windows does not support revoking read permissions via os.chmod')

class TestFileReadPermissions:

    def test_check_file_readable_success(self):
        with tempfile.NamedTemporaryFile(suffix='.txt', delete=False) as f:
            f.write(b'hello')
            path = f.name
        try:
            check_file_readable(path)
        finally:
            os.unlink(path)

    def test_check_file_readable_not_found(self):
        with pytest.raises(FileNotFoundError):
            check_file_readable('nonexistent_file_12345.wav')

    @_SKIP_READ_PERM
    def test_check_file_readable_no_permission(self):
        with tempfile.NamedTemporaryFile(suffix='.txt', delete=False) as f:
            f.write(b'hello')
            path = f.name
        try:
            os.chmod(path, 0)
            with pytest.raises(FilePermissionError):
                check_file_readable(path)
        finally:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
            os.unlink(path)

    def test_can_read_file_boolean(self):
        with tempfile.NamedTemporaryFile(suffix='.txt', delete=False) as f:
            f.write(b'hello')
            path = f.name
        try:
            assert can_read_file(path) is True
        finally:
            os.unlink(path)
        assert can_read_file('nonexistent_file_99999.txt') is False

    def test_fileio_read_missing(self):
        with pytest.raises(FileNotFoundError):
            FileIO.read('totally_missing_audio.wav')

    @_SKIP_READ_PERM
    def test_fileio_read_no_permission(self):
        tone = AudioTensor.from_function(lambda t: np.sin(2 * np.pi * 440 * t), duration=0.01, sample_rate=8000)
        with tempfile.TemporaryDirectory() as tmp:
            wav_path = os.path.join(tmp, 'locked.wav')
            FileIO.write(tone, wav_path)
            os.chmod(wav_path, 0)
            try:
                with pytest.raises(FilePermissionError):
                    FileIO.read(wav_path)
            finally:
                os.chmod(wav_path, stat.S_IRUSR | stat.S_IWUSR)

    @_SKIP_READ_PERM
    def test_textio_read_csv_no_permission(self):
        tone = AudioTensor(np.array([0.1, 0.2, 0.3], dtype=np.float32))
        with tempfile.TemporaryDirectory() as tmp:
            csv_path = os.path.join(tmp, 'locked.csv')
            TextIO.write_csv(tone, csv_path)
            os.chmod(csv_path, 0)
            try:
                with pytest.raises(FilePermissionError):
                    TextIO.read_csv(csv_path)
            finally:
                os.chmod(csv_path, stat.S_IRUSR | stat.S_IWUSR)

    @_SKIP_READ_PERM
    def test_textio_read_json_no_permission(self):
        tone = AudioTensor(np.array([0.1, 0.2], dtype=np.float32))
        with tempfile.TemporaryDirectory() as tmp:
            json_path = os.path.join(tmp, 'locked.json')
            TextIO.write_json(tone, json_path)
            os.chmod(json_path, 0)
            try:
                with pytest.raises(FilePermissionError):
                    TextIO.read_json(json_path)
            finally:
                os.chmod(json_path, stat.S_IRUSR | stat.S_IWUSR)

class TestFileWritePermissions:

    def test_check_file_writable_new_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'new_file.wav')
            check_file_writable(path)

    def test_check_file_writable_existing(self):
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as f:
            path = f.name
        try:
            check_file_writable(path)
        finally:
            os.unlink(path)

    def test_check_file_writable_readonly(self):
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as f:
            path = f.name
        try:
            os.chmod(path, stat.S_IRUSR)
            with pytest.raises(FilePermissionError):
                check_file_writable(path)
        finally:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
            os.unlink(path)

    def test_can_write_file_boolean(self):
        with tempfile.TemporaryDirectory() as tmp:
            assert can_write_file(os.path.join(tmp, 'test.wav')) is True

    def test_fileio_write_readonly(self):
        tone = AudioTensor(np.array([0.1, 0.2], dtype=np.float32))
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as f:
            path = f.name
        try:
            os.chmod(path, stat.S_IRUSR)
            with pytest.raises(FilePermissionError):
                FileIO.write(tone, path)
        finally:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
            os.unlink(path)

    def test_textio_write_csv_readonly(self):
        tone = AudioTensor(np.array([0.1, 0.2], dtype=np.float32))
        with tempfile.NamedTemporaryFile(suffix='.csv', delete=False) as f:
            path = f.name
        try:
            os.chmod(path, stat.S_IRUSR)
            with pytest.raises(FilePermissionError):
                TextIO.write_csv(tone, path)
        finally:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
            os.unlink(path)

class TestMicPermissionCheck:

    def test_can_access_microphone_returns_bool(self):
        result = can_access_microphone()
        assert isinstance(result, bool)

class TestExceptionHierarchy:

    def test_permission_error_is_phonotensor_error(self):
        from phonotensor.exceptions import PhonotensorError, PhonotensorPermissionError
        assert issubclass(PhonotensorPermissionError, PhonotensorError)

    def test_file_permission_error_hierarchy(self):
        from phonotensor.exceptions import PhonotensorPermissionError, FilePermissionError
        assert issubclass(FilePermissionError, PhonotensorPermissionError)

    def test_device_permission_error_hierarchy(self):
        from phonotensor.exceptions import PhonotensorPermissionError, DevicePermissionError
        assert issubclass(DevicePermissionError, PhonotensorPermissionError)

    def test_mic_permission_error_hierarchy(self):
        from phonotensor.exceptions import DevicePermissionError, MicrophonePermissionError
        assert issubclass(MicrophonePermissionError, DevicePermissionError)

    def test_catching_base_catches_all(self):
        from phonotensor.exceptions import PhonotensorError
        with pytest.raises(PhonotensorError):
            raise FilePermissionError('test')
        with pytest.raises(PhonotensorError):
            raise MicrophonePermissionError('test')
        with pytest.raises(PhonotensorError):
            raise DevicePermissionError('test')
