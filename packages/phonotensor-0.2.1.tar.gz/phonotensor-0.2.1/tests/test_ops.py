import numpy as np
import pytest
from phonotensor import AudioTensor, ops
from phonotensor.ops import edit

class TestArithmeticOps:

    def test_add(self):
        a = AudioTensor(np.ones((100, 1)), sample_rate=16000)
        b = AudioTensor(np.ones((100, 1)) * 0.5, sample_rate=16000)
        c = ops.add(a, b)
        assert np.allclose(c.data, 1.5)

    def test_add_different_lengths(self):
        a = AudioTensor(np.ones((100, 1)), sample_rate=16000)
        b = AudioTensor(np.ones((50, 1)), sample_rate=16000)
        c = ops.add(a, b)
        assert c.num_samples == 100

    def test_scale(self):
        a = AudioTensor(np.ones((10, 1)))
        s = ops.scale(a, 0.3)
        assert np.allclose(s.data, 0.3)

    def test_mix(self):
        a = AudioTensor(np.ones((100, 1)), sample_rate=16000)
        b = AudioTensor(np.ones((100, 1)) * 2.0, sample_rate=16000)
        m = ops.mix([a, b], weights=[0.5, 0.5])
        assert np.allclose(m.data, 1.5)

    def test_mix_empty(self):
        with pytest.raises(ValueError):
            ops.mix([])

class TestTransformOps:

    def test_normalize(self):
        a = AudioTensor(np.ones((100, 1)) * 0.5)
        n = ops.normalize(a, peak_level=1.0)
        assert abs(ops.peak(n) - 1.0) < 1e-05

    def test_reverse(self):
        data = np.arange(10, dtype=np.float32).reshape(-1, 1)
        a = AudioTensor(data)
        r = ops.reverse(a)
        assert np.allclose(r.data[:, 0], [9, 8, 7, 6, 5, 4, 3, 2, 1, 0])

    def test_gain(self):
        a = AudioTensor(np.ones((10, 1)))
        g = ops.gain(a, -6.0)
        assert abs(ops.peak(g) - 0.5012) < 0.01

    def test_fade_in(self):
        a = AudioTensor(np.ones((100, 1)), sample_rate=100)
        f = ops.fade_in(a, 0.5)
        assert abs(f.data[0, 0]) < 0.02
        assert abs(f.data[-1, 0] - 1.0) < 0.02

    def test_fade_out(self):
        a = AudioTensor(np.ones((100, 1)), sample_rate=100)
        f = ops.fade_out(a, 0.5)
        assert abs(f.data[0, 0] - 1.0) < 0.02
        assert abs(f.data[-1, 0]) < 0.02

    def test_resample(self):
        a = AudioTensor(np.zeros((1000, 1)), sample_rate=16000)
        r = ops.resample(a, 8000)
        assert r.sample_rate == 8000
        assert r.num_samples == 500

class TestAnalysisOps:

    def test_rms(self):
        a = AudioTensor(np.ones((100, 1)))
        assert abs(ops.rms(a) - 1.0) < 1e-05

    def test_peak(self):
        data = np.array([0.5, -0.8, 0.3], dtype=np.float32)
        a = AudioTensor(data)
        assert abs(ops.peak(a) - 0.8) < 1e-05

    def test_zero_crossings(self):
        data = np.array([1, -1, 1, -1, 1], dtype=np.float32)
        a = AudioTensor(data)
        assert ops.zero_crossings(a) == 4

    def test_energy(self):
        data = np.ones((100, 1), dtype=np.float32)
        a = AudioTensor(data)
        assert abs(ops.energy(a) - 100.0) < 0.001

    def test_db_peak_silence(self):
        a = AudioTensor(np.zeros((10, 1)))
        assert ops.db_peak(a) == float('-inf')

    def test_duration(self):
        a = AudioTensor(np.zeros((44100, 1)), sample_rate=44100)
        assert abs(ops.duration(a) - 1.0) < 1e-05

class TestEditOps:

    def test_trim(self):
        a = AudioTensor(np.zeros((100, 1)), sample_rate=100)
        t = edit.trim(a, 0.2, 0.8)
        assert t.num_samples == 60

    def test_pad(self):
        a = AudioTensor(np.ones((100, 1)), sample_rate=100)
        p = edit.pad(a, before=0.5, after=0.5)
        assert p.num_samples == 200

    def test_concatenate(self):
        a = AudioTensor(np.ones((50, 1)), sample_rate=100)
        b = AudioTensor(np.ones((50, 1)), sample_rate=100)
        c = edit.concatenate(a, b)
        assert c.num_samples == 100

    def test_split(self):
        a = AudioTensor(np.zeros((100, 1)), sample_rate=100)
        left, right = edit.split(a, 0.5)
        assert left.num_samples == 50
        assert right.num_samples == 50

    def test_repeat(self):
        a = AudioTensor(np.ones((10, 1)))
        r = edit.repeat(a, 3)
        assert r.num_samples == 30

    def test_overlay(self):
        a = AudioTensor(np.ones((100, 1)), sample_rate=100)
        b = AudioTensor(np.ones((50, 1)), sample_rate=100)
        o = edit.overlay(a, b, offset=0.5)
        assert o.num_samples == 100

    def test_silence(self):
        s = edit.silence(1.0, sample_rate=8000)
        assert s.num_samples == 8000
        assert ops.peak(s) == 0.0

    def test_trim_silence(self):
        sig = np.concatenate([np.zeros((100, 1)), np.ones((100, 1)), np.zeros((100, 1))])
        a = AudioTensor(sig, sample_rate=100)
        t = edit.trim_silence(a, threshold=0.5)
        assert t.num_samples < a.num_samples

class TestAdditionalOps:

    def test_invert_phase(self):
        data = np.array([[0.5], [-0.3], [0.1]], dtype=np.float32)
        a = AudioTensor(data, sample_rate=44100)
        inv = ops.invert_phase(a)
        assert np.allclose(inv.data, -data)

    def test_clip(self):
        data = np.array([[-2.0], [0.5], [2.0]], dtype=np.float32)
        a = AudioTensor(data, sample_rate=44100)
        clipped = ops.clip(a, -1.0, 1.0)
        assert float(np.min(clipped.data)) >= -1.0
        assert float(np.max(clipped.data)) <= 1.0
        assert clipped.data[1, 0] == pytest.approx(0.5)

    def test_db_rms(self):
        a = AudioTensor(np.ones((100, 1), dtype=np.float32), sample_rate=44100)
        db = ops.db_rms(a)
        assert db == pytest.approx(0.0, abs=0.01)

    def test_min_sample(self):
        data = np.array([[0.1], [-0.5], [0.3]], dtype=np.float32)
        a = AudioTensor(data, sample_rate=44100)
        assert ops.min_sample(a) == pytest.approx(-0.5)

    def test_max_sample(self):
        data = np.array([[0.1], [-0.5], [0.3]], dtype=np.float32)
        a = AudioTensor(data, sample_rate=44100)
        assert ops.max_sample(a) == pytest.approx(0.3)

    def test_mean(self):
        data = np.array([[0.2], [0.4], [0.6]], dtype=np.float32)
        a = AudioTensor(data, sample_rate=44100)
        assert ops.mean(a) == pytest.approx(0.4, abs=1e-05)

    def test_std(self):
        data = np.array([[1.0], [2.0], [3.0]], dtype=np.float32)
        a = AudioTensor(data, sample_rate=44100)
        assert ops.std(a) > 0
