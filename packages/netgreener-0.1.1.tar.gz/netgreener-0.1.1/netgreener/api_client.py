"""
Lightweight API client for NetGreener CLI — wraps the REST endpoints needed by the CLI.
"""

import requests
from typing import Any

from .config import get_api_url, load_credentials


class APIError(Exception):
    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class NetGreenerClient:
    def __init__(self, token: str | None = None, base_url: str | None = None):
        self.base_url = (base_url or get_api_url()) + "/api/v1"
        self._token = token

    @classmethod
    def from_credentials(cls) -> "NetGreenerClient":
        creds = load_credentials()
        if not creds:
            raise APIError(401, "Not logged in. Run: netgreener login")
        return cls(token=creds["access_token"])

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self._token:
            h["Authorization"] = f"Bearer {self._token}"
        return h

    def _raise(self, resp: requests.Response) -> None:
        if not resp.ok:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise APIError(resp.status_code, detail)

    def login(self, email: str, password: str) -> dict:
        resp = requests.post(
            f"{self.base_url}/auth/login",
            json={"email": email, "password": password},
            timeout=15,
        )
        self._raise(resp)
        data = resp.json()
        self._token = data["access_token"]
        return data

    def get_or_create_project(self, name: str, directory: str) -> dict:
        resp = requests.get(
            f"{self.base_url}/projects",
            headers=self._headers(),
            timeout=15,
        )
        self._raise(resp)
        projects = resp.json()
        for p in projects:
            if p.get("project_name") == name:
                return p
        resp = requests.post(
            f"{self.base_url}/projects",
            headers=self._headers(),
            json={"project_name": name, "project_directory": directory, "language": "Python"},
            timeout=15,
        )
        self._raise(resp)
        return resp.json()

    def create_run_session(self, payload: dict) -> dict:
        resp = requests.post(
            f"{self.base_url}/runsessions",
            headers=self._headers(),
            json=payload,
            timeout=15,
        )
        self._raise(resp)
        return resp.json()

    def update_run_accuracy(self, run_id: int, metrics: dict) -> dict:
        resp = requests.put(
            f"{self.base_url}/runsessions/{run_id}/accuracy",
            headers=self._headers(),
            json=metrics,
            timeout=15,
        )
        self._raise(resp)
        return resp.json()

    def post_code_patterns_batch(self, patterns: list) -> dict:
        resp = requests.post(
            f"{self.base_url}/code-patterns/batch",
            headers=self._headers(),
            json={"patterns": patterns},
            timeout=30,
        )
        self._raise(resp)
        return resp.json()

    def post_surrogate_training(self, payload: dict) -> dict:
        resp = requests.post(
            f"{self.base_url}/surrogate-training",
            headers=self._headers(),
            json=payload,
            timeout=15,
        )
        self._raise(resp)
        return resp.json()

    def post_environmental_impact(self, payload: dict) -> dict:
        resp = requests.post(
            f"{self.base_url}/environmental-impact",
            headers=self._headers(),
            json=payload,
            timeout=15,
        )
        self._raise(resp)
        return resp.json()
