"""
Runs a user script as a subprocess, streams output to the real terminal,
and collects CPU/RAM/GPU metrics throughout execution.
"""

import os
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

import psutil

from .constants import CO2_KG_PER_KWH, CPU_TDP_WATTS, GPU_TDP_WATTS


@dataclass
class RunResult:
    exit_code: int
    duration_seconds: float
    cpu_percent_avg: float
    ram_gb_peak: float
    gpu_utilization_avg: float
    gpu_memory_peak_gb: float
    energy_kwh: float
    accuracy_metrics: dict = field(default_factory=dict)


def _collect_gpu_metrics(samples: list, stop_event: threading.Event) -> None:
    try:
        import pynvml
        pynvml.nvmlInit()
        device_count = pynvml.nvmlDeviceGetCount()
    except Exception:
        return

    while not stop_event.is_set():
        try:
            total_util = sum(
                pynvml.nvmlDeviceGetUtilizationRates(pynvml.nvmlDeviceGetHandleByIndex(i)).gpu
                for i in range(device_count)
            )
            total_mem = sum(
                pynvml.nvmlDeviceGetMemoryInfo(pynvml.nvmlDeviceGetHandleByIndex(i)).used / (1024 ** 3)
                for i in range(device_count)
            )
            samples.append((total_util / device_count, total_mem / device_count))
        except Exception:
            pass
        stop_event.wait(1.0)


def run_script(
    script_path: str,
    project_dir: str,
    metrics_port: int | None = None,
    extra_env: dict | None = None,
) -> RunResult:
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    if metrics_port:
        env["NETGREENER_METRICS_PORT"] = str(metrics_port)
    if extra_env:
        env.update(extra_env)

    proc = subprocess.Popen(
        [sys.executable, str(Path(script_path).resolve())],
        cwd=str(Path(project_dir).resolve()),
        env=env,
        stdout=sys.stdout,
        stderr=sys.stderr,
    )

    # Accumulators replace unbounded lists — safe for multi-hour training runs.
    cpu_sum = 0.0
    cpu_count = 0
    ram_peak = 0.0
    gpu_samples: list[tuple[float, float]] = []
    stop_event = threading.Event()

    def _collect_cpu_ram() -> None:
        nonlocal cpu_sum, cpu_count, ram_peak
        try:
            ps = psutil.Process(proc.pid)
        except psutil.NoSuchProcess:
            return
        # Prime the counter — first call always returns 0.0 (no prior measurement).
        ps.cpu_percent(interval=None)
        stop_event.wait(1.0)
        while not stop_event.is_set():
            try:
                cpu = ps.cpu_percent(interval=None)
                ram = ps.memory_info().rss / (1024 ** 3)
                cpu_sum += cpu
                cpu_count += 1
                if ram > ram_peak:
                    ram_peak = ram
            except psutil.NoSuchProcess:
                break
            stop_event.wait(1.0)

    cpu_ram_thread = threading.Thread(target=_collect_cpu_ram, daemon=True)
    gpu_thread = threading.Thread(target=_collect_gpu_metrics, args=(gpu_samples, stop_event), daemon=True)
    cpu_ram_thread.start()
    gpu_thread.start()

    start = time.monotonic()
    exit_code = proc.wait()
    duration = time.monotonic() - start

    stop_event.set()
    cpu_ram_thread.join(timeout=2)
    gpu_thread.join(timeout=2)

    cpu_avg = cpu_sum / cpu_count if cpu_count else 0.0
    gpu_util_avg = sum(s[0] for s in gpu_samples) / len(gpu_samples) if gpu_samples else 0.0
    gpu_mem_peak = max(s[1] for s in gpu_samples) if gpu_samples else 0.0

    cpu_kwh = (CPU_TDP_WATTS * (cpu_avg / 100) * duration) / 3_600_000
    gpu_kwh = (GPU_TDP_WATTS * (gpu_util_avg / 100) * duration) / 3_600_000

    return RunResult(
        exit_code=exit_code,
        duration_seconds=round(duration, 2),
        cpu_percent_avg=round(cpu_avg, 1),
        ram_gb_peak=round(ram_peak, 3),
        gpu_utilization_avg=round(gpu_util_avg, 1),
        gpu_memory_peak_gb=round(gpu_mem_peak, 3),
        energy_kwh=round(cpu_kwh + gpu_kwh, 6),
    )
