"""
NetGreener CLI entry point.

Commands:
  netgreener login              — authenticate and persist token
  netgreener logout             — clear stored credentials
  netgreener run <script> <dir> — run a script with full analysis and reporting
  netgreener status             — show current login status
  netgreener config             — show/set API server URL
"""

import getpass
import os
from pathlib import Path

import click

import threading

from .api_client import NetGreenerClient, APIError
from .config import (
    clear_credentials,
    get_api_url,
    load_credentials,
    save_api_url,
    save_credentials,
)
from .constants import CO2_KG_PER_KWH
from .reporter import console, print_error, print_info, print_login_success, print_run_report


@click.group()
def main() -> None:
    """NetGreener — measure energy, carbon, and code quality of your ML runs."""


# ---------------------------------------------------------------------------
# login / logout / status
# ---------------------------------------------------------------------------

@main.command()
@click.option("--email", prompt="Email", help="Your NetGreener account email.")
@click.option(
    "--password",
    default=None,
    help="Your password (prompted if omitted).",
)
@click.option("--api-url", default=None, help="Override API server URL.")
def login(email: str, password: str | None, api_url: str | None) -> None:
    """Authenticate and store credentials locally."""
    if api_url:
        save_api_url(api_url)

    if password is None:
        password = getpass.getpass("Password: ")

    client = NetGreenerClient()
    try:
        data = client.login(email, password)
    except APIError as e:
        print_error(str(e))
        raise SystemExit(1)

    save_credentials(data["access_token"], data["user"])
    print_login_success(data["user"])


@main.command()
def logout() -> None:
    """Clear stored credentials."""
    clear_credentials()
    print_info("Logged out.")


@main.command()
def status() -> None:
    """Show current login status."""
    creds = load_credentials()
    if not creds:
        print_info(f"Not logged in.  API: {get_api_url()}")
        return
    user = creds.get("user", {})
    print_login_success(user)
    print_info(f"API: {get_api_url()}")


# ---------------------------------------------------------------------------
# config
# ---------------------------------------------------------------------------

@main.command("config")
@click.argument("api_url", required=False)
def config_cmd(api_url: str | None) -> None:
    """Show or set the API server URL.

    \b
    Examples:
      netgreener config
      netgreener config https://netgreener.example.com
    """
    if api_url:
        save_api_url(api_url)
        print_info(f"API URL set to: {api_url}")
    else:
        print_info(f"API URL: {get_api_url()}")


# ---------------------------------------------------------------------------
# analyze
# ---------------------------------------------------------------------------

@main.command("analyze")
@click.argument("project_dir", default=".", type=click.Path(file_okay=False))
@click.option("--project-name", default=None, help="Project name (defaults to directory name).")
@click.option("--no-upload", is_flag=True, default=False, help="Analyze locally only, skip API upload.")
@click.option("--with-nlp", is_flag=True, default=False,
              help="Run GPT-based code analysis (requires login + OPENAI_API_KEY or config.yml).")
@click.option("--entry", default=None, type=click.Path(exists=True, dir_okay=False),
              help="Entry script for NLP analysis (defaults to first .py file found).")
def analyze_cmd(
    project_dir: str,
    project_name: str | None,
    no_upload: bool,
    with_nlp: bool,
    entry: str | None,
) -> None:
    """Analyze all Python files in PROJECT_DIR and upload code patterns.

    \b
    Use this when you want code quality data in the dashboard without running a script.

    \b
    Examples:
      netgreener analyze
      netgreener analyze C:\\users\\project1
      netgreener analyze . --with-nlp
      netgreener analyze . --no-upload
    """
    from .analyzer import analyze_project, build_patterns

    if with_nlp:
        if not load_credentials():
            print_error("--with-nlp requires login. Run: netgreener login")
            raise SystemExit(1)
        if not os.environ.get("OPENAI_API_KEY"):
            print_info("OPENAI_API_KEY not set — will attempt Azure fallback from config.yml")

    project_path = Path(project_dir).resolve()
    p_name = project_name or project_path.name

    print_info(f"Analyzing project: {project_path} ...")
    project_summary = analyze_project(str(project_path))

    if project_summary.get("errors"):
        for err in project_summary["errors"][:5]:
            console.print(f"  [dim yellow]warn:[/] {err}")

    file_count = project_summary.get("file_count", 0)
    total_loc = project_summary.get("total_lines_of_code", 0)
    avg_cc = project_summary.get("avg_cyclomatic_complexity", 0)
    avg_mi = project_summary.get("avg_maintainability_index", 0)
    domains = ", ".join(project_summary.get("library_domains", [])) or "none detected"

    console.print(f"\n[bold]Analysis complete[/] — {file_count} files, {total_loc} lines")
    console.print(f"  avg cyclomatic complexity : [cyan]{avg_cc}[/]")
    console.print(f"  avg maintainability index : [cyan]{avg_mi}[/]")
    console.print(f"  library domains           : [cyan]{domains}[/]")

    # NLP analysis
    nlp_features: dict = {}
    if with_nlp:
        script_path_str = entry
        if not script_path_str:
            py_files = list(project_path.rglob("*.py"))
            if py_files:
                script_path_str = str(py_files[0])
        if script_path_str:
            print_info(f"Running GPT code analysis on {Path(script_path_str).name} ...")
            from .nlp_analyzer import run_nlp_analysis
            nlp_features = run_nlp_analysis(script_path_str)
            if "error" in nlp_features:
                print_error(f"NLP analysis: {nlp_features['error']}")
                nlp_features = {}
            else:
                print_info(f"NLP analysis complete ({len(nlp_features)} features).")
        else:
            print_error("No .py files found for NLP analysis.")

    if no_upload:
        return

    creds = load_credentials()
    if not creds:
        print_info("Not logged in — skipping upload. Run: netgreener login")
        return

    try:
        client = NetGreenerClient.from_credentials()
        project = client.get_or_create_project(p_name, str(project_path))
        project_id = project["project_id"]

        patterns = build_patterns(project_summary.get("per_file", []), project_id)
        if patterns:
            client.post_code_patterns_batch(patterns)
            console.print(f"  [green]✓[/] Uploaded {len(patterns)} code pattern(s).")
        else:
            console.print("  [dim]No patterns detected.[/]")

        if project_summary:
            features_payload = {
                k: v for k, v in project_summary.items()
                if k not in ("errors", "patterns", "per_file")
            }
            if nlp_features:
                features_payload["nlp_features"] = nlp_features
            client.post_surrogate_training({
                "project_id": project_id,
                "split_type": "train",
                "features": features_payload,
            })
            console.print("  [green]✓[/] Features uploaded to surrogate training data.")

        print_info(f"Done. Visible in supervisor dashboard (project: {p_name}).")

    except APIError as e:
        print_error(f"Upload failed: {e}")
    except Exception as e:
        print_error(f"Upload error: {e}")


# ---------------------------------------------------------------------------
# run
# ---------------------------------------------------------------------------

@main.command()
@click.argument("script", type=click.Path(exists=True, dir_okay=False))
@click.argument("project_dir", default=".", type=click.Path(file_okay=False))
@click.option("--project-name", default=None, help="Project name (defaults to directory name).")
@click.option("--no-upload", is_flag=True, default=False, help="Analyze locally only, skip API upload.")
@click.option("--no-analyze", is_flag=True, default=False, help="Skip code analysis, run only.")
@click.option("--with-nlp", is_flag=True, default=False,
              help="Run GPT-based code analysis (requires login + OPENAI_API_KEY or config.yml).")
def run(
    script: str,
    project_dir: str,
    project_name: str | None,
    no_upload: bool,
    no_analyze: bool,
    with_nlp: bool,
) -> None:
    """Run SCRIPT inside PROJECT_DIR with energy and code analysis.

    \b
    Examples:
      netgreener run train.py .
      netgreener run train.py C:\\users\\project1
      netgreener run train.py . --no-upload
      netgreener run train.py . --with-nlp
    """
    from .analyzer import analyze_project
    from .executor import RunResult, run_script
    from ._metrics_server import MetricsServer

    # --with-nlp requires login
    if with_nlp:
        if not load_credentials():
            print_error("--with-nlp requires login. Run: netgreener login")
            raise SystemExit(1)
        if not os.environ.get("OPENAI_API_KEY"):
            # Will still work if Azure config.yml is present; warn but continue
            print_info("OPENAI_API_KEY not set — will attempt Azure fallback from config.yml")

    script_path = Path(script).resolve()
    project_path = Path(project_dir).resolve()
    p_name = project_name or project_path.name

    # --- Code analysis in background so script output starts immediately ---
    project_summary: dict = {}
    analysis_thread: threading.Thread | None = None
    if not no_analyze:
        print_info(f"Analyzing project: {project_path} ...")
        def _run_analysis() -> None:
            project_summary.update(analyze_project(str(project_path)))
        analysis_thread = threading.Thread(target=_run_analysis, daemon=True)
        analysis_thread.start()

    # --- Start metrics callback server ---
    received_accuracy: dict = {}

    def _on_metrics(payload: dict) -> None:
        received_accuracy.update(payload)

    metrics_server = MetricsServer(on_metrics=_on_metrics)
    metrics_server.start()

    # --- Execute script ---
    print_info(f"Running: {script_path.name}\n")
    result = run_script(
        script_path=str(script_path),
        project_dir=str(project_path),
        metrics_port=metrics_server.port,
    )
    metrics_server.stop()
    result.accuracy_metrics = received_accuracy

    if analysis_thread is not None:
        analysis_thread.join()
        if project_summary.get("errors"):
            for err in project_summary["errors"][:5]:
                console.print(f"  [dim yellow]warn:[/] {err}")

    # --- Print report ---
    print_run_report(result, project_summary, script_path.name)

    # --- NLP analysis (--with-nlp, post-run so it doesn't block output) ---
    nlp_features: dict = {}
    if with_nlp:
        print_info("Running GPT code analysis (--with-nlp) ...")
        from .nlp_analyzer import run_nlp_analysis
        nlp_features = run_nlp_analysis(str(script_path))
        if "error" in nlp_features:
            print_error(f"NLP analysis: {nlp_features['error']}")
            nlp_features = {}
        else:
            print_info(f"NLP analysis complete ({len(nlp_features)} features).")

    # --- Upload to API ---
    if not no_upload:
        _upload_results(result, project_summary, p_name, str(project_path),
                        str(script_path), nlp_features)

    raise SystemExit(result.exit_code)


def _upload_results(
    result: "RunResult",
    project_summary: dict,
    project_name: str,
    project_dir: str,
    script_path: str = "",
    nlp_features: dict | None = None,
) -> None:
    """POST run session, accuracy, environmental impact, code patterns, and surrogate training data."""
    from .executor import RunResult

    creds = load_credentials()
    if not creds:
        print_info("Not logged in — skipping upload. Run: netgreener login")
        return

    try:
        client = NetGreenerClient.from_credentials()

        project = client.get_or_create_project(project_name, project_dir)
        project_id = project["project_id"]

        # Build code patterns from cached per-file features (no second file scan)
        if project_summary and not project_summary.get("errors"):
            from .analyzer import build_patterns
            project_summary = {
                **project_summary,
                "patterns": build_patterns(project_summary.get("per_file", []), project_id),
            }

        carbon_kg = result.energy_kwh * CO2_KG_PER_KWH

        run_payload: dict = {
            "project_id": project_id,
            "duration_seconds": result.duration_seconds,
            "energy_kwh": result.energy_kwh,
            "cpu_percent_hours": result.cpu_percent_avg * result.duration_seconds / 3600,
            "ram_gb_hours": result.ram_gb_peak * result.duration_seconds / 3600,
            "process_gpu_hours": result.gpu_utilization_avg / 100 * result.duration_seconds / 3600,
        }
        if result.accuracy_metrics:
            run_payload.update(result.accuracy_metrics)

        if project_summary:
            run_payload["session_metadata"] = {
                "file_count": project_summary.get("file_count"),
                "total_lines_of_code": project_summary.get("total_lines_of_code"),
                "avg_cyclomatic_complexity": project_summary.get("avg_cyclomatic_complexity"),
                "avg_maintainability_index": project_summary.get("avg_maintainability_index"),
                "avg_halstead_volume": project_summary.get("avg_halstead_volume"),
                "library_domains": project_summary.get("library_domains", []),
            }

        run_session = client.create_run_session(run_payload)
        run_id = run_session.get("run_id") or run_session.get("id")

        # Update accuracy separately if reported (uses the dedicated endpoint)
        if result.accuracy_metrics and run_id:
            client.update_run_accuracy(run_id, result.accuracy_metrics)

        # Environmental impact record
        client.post_environmental_impact({
            "project_id": project_id,
            "run_session_id": run_id,
            "carbon_kg": round(carbon_kg, 6),
            "energy_kwh": result.energy_kwh,
        })

        # Code patterns → powers supervisor code_quality_score
        patterns = project_summary.get("patterns", []) if project_summary else []
        if patterns:
            client.post_code_patterns_batch(patterns)

        # Surrogate training data — code features + run labels for surrogate model
        if project_summary:
            features_payload = {
                k: v for k, v in project_summary.items()
                if k not in ("errors", "patterns", "per_file")
            }
            if nlp_features:
                features_payload["nlp_features"] = nlp_features
            surrogate_payload: dict = {
                "project_id": project_id,
                "split_type": "train",
                "features": features_payload,
                "label_energy_kwh": result.energy_kwh,
                "label_carbon_kg": round(carbon_kg, 6),
            }
            if result.accuracy_metrics:
                surrogate_payload["label_model_accuracy"] = result.accuracy_metrics.get("model_accuracy")
                surrogate_payload["label_f1_score"] = result.accuracy_metrics.get("f1_score")
            client.post_surrogate_training(surrogate_payload)

        print_info(f"Results uploaded (run #{run_id}). Visible in supervisor dashboard.")

    except APIError as e:
        print_error(f"Upload failed: {e}")
    except Exception as e:
        print_error(f"Upload error: {e}")
