"""
Reads CLI configuration from ~/.netgreener/config.json or environment variables.
"""

import json
import os
from pathlib import Path

_CONFIG_DIR = Path.home() / ".netgreener"
_CONFIG_FILE = _CONFIG_DIR / "config.json"
_CREDENTIALS_FILE = _CONFIG_DIR / "credentials.json"
_API_URL_KEY = "api_url"
_DEFAULT_API_URL = "http://netgreener.eastus2.cloudapp.azure.com"


def _ensure_dir() -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def _read_config() -> dict:
    try:
        return json.loads(_CONFIG_FILE.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def _write_config(data: dict) -> None:
    _ensure_dir()
    tmp = _CONFIG_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2))
    tmp.replace(_CONFIG_FILE)


def get_api_url() -> str:
    if url := os.environ.get("NETGREENER_API_URL"):
        return url.rstrip("/")
    return _read_config().get(_API_URL_KEY, _DEFAULT_API_URL).rstrip("/")


def save_api_url(url: str) -> None:
    data = _read_config()
    data[_API_URL_KEY] = url
    _write_config(data)


def load_credentials() -> dict | None:
    try:
        return json.loads(_CREDENTIALS_FILE.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def save_credentials(token: str, user: dict) -> None:
    _ensure_dir()
    _CREDENTIALS_FILE.write_text(json.dumps({"access_token": token, "user": user}, indent=2))
    try:
        _CREDENTIALS_FILE.chmod(0o600)
    except NotImplementedError:
        pass  # Windows does not support POSIX permissions


def clear_credentials() -> None:
    try:
        _CREDENTIALS_FILE.unlink()
    except FileNotFoundError:
        pass
