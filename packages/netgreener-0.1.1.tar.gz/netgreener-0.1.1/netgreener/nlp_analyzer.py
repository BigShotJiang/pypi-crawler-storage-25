"""
GPT-based NLP feature extraction for --with-nlp runs.

Uses the standard openai package (not Azure) with OPENAI_API_KEY env var.
Falls back to the repo's config.yml Azure credentials if the env var is absent.
Returns the 130+ feature dict from nlp_features_questions.json, keyed by feature name.
"""

import json
import os
import re
from pathlib import Path

_QUESTIONS_PATH = Path(__file__).parent / "_codeanalyzer" / "nlp_features_questions.json"

_MAX_CODE_CHARS = 12_000  # keep prompt under token limits


def _load_questions() -> dict[str, str]:
    try:
        return json.loads(_QUESTIONS_PATH.read_text(encoding="utf-8"))
    except Exception as e:
        raise RuntimeError(f"Could not load NLP questions file: {e}") from e


def _build_prompt(source: str, questions: dict[str, str]) -> str:
    numbered = "\n".join(
        f"{i + 1}. {q}" for i, q in enumerate(questions.values()) if q
    )
    return (
        "Analyze this Python code and answer the following questions. "
        "Respond ONLY with a valid JSON object where keys are question numbers "
        "(1, 2, 3, ...) and values are your answers.\n\n"
        f"CODE:\n{source[:_MAX_CODE_CHARS]}\n\n"
        f"QUESTIONS:\n{numbered}\n\n"
        "Respond with JSON only, no other text."
    )


def _parse_response(raw: str, questions: dict[str, str]) -> dict:
    cleaned = raw.replace("```json", "").replace("```", "").strip()
    m = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if m:
        cleaned = m.group(0)
    numbered_answers: dict = json.loads(cleaned)

    # Map numbered keys → feature names
    feature_names = list(questions.keys())
    result: dict = {}
    for str_idx, value in numbered_answers.items():
        try:
            idx = int(str_idx) - 1
            if 0 <= idx < len(feature_names):
                result[feature_names[idx]] = value
        except (ValueError, IndexError):
            pass
    return result


def run_nlp_analysis(script_path: str) -> dict:
    """
    Run GPT analysis on the given script. Returns feature dict on success,
    {"error": "..."} on failure.

    Requires either:
      - OPENAI_API_KEY env var  →  uses openai.OpenAI (standard API)
      - No env var              →  tries Azure credentials from config.yml
    """
    source = Path(script_path).read_text(encoding="utf-8", errors="replace")
    questions = _load_questions()
    prompt = _build_prompt(source, questions)

    api_key = os.environ.get("OPENAI_API_KEY")

    try:
        if api_key:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": prompt}],
                temperature=0,
                max_tokens=4000,
            )
        else:
            return {"error": "OPENAI_API_KEY environment variable is not set."}
    except ImportError:
        return {"error": "openai package not installed. Run: pip install openai"}
    except Exception as e:
        return {"error": f"OpenAI call failed: {e}"}

    try:
        return _parse_response(response.choices[0].message.content, questions)
    except Exception as e:
        return {"error": f"Failed to parse GPT response: {e}"}
