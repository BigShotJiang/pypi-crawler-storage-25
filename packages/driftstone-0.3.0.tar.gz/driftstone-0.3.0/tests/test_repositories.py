from __future__ import annotations

import json
import unittest

import httpx

from driftstone import Driftstone
from driftstone.exceptions import DriftstoneError


def json_response(payload: dict, status_code: int = 200) -> httpx.Response:
    return httpx.Response(
        status_code,
        headers={"Content-Type": "application/json"},
        content=json.dumps(payload).encode("utf-8"),
    )


class DriftstoneRepositoryTests(unittest.TestCase):
    def make_client(self, handler) -> Driftstone:
        transport = httpx.MockTransport(handler)
        http = httpx.Client(base_url="https://api.driftstone.test/v1", transport=transport)
        return Driftstone(api_key="dk-test", http_client=http)

    def test_create_repo_posts_initial_files(self) -> None:
        seen = {}

        def handler(request: httpx.Request) -> httpx.Response:
            seen["method"] = request.method
            seen["path"] = request.url.path
            seen["payload"] = json.loads(request.content.decode("utf-8"))
            return json_response(
                {
                    "success": True,
                    "data": {
                        "name": "hello-world",
                        "path": "apps",
                        "defaultBranch": "main",
                        "sha256": "sha",
                        "commitHash": "commit",
                        "storageUrl": "gs://bucket/repo.zip",
                        "gitOrigin": "gcs://bucket/org/apps/hello-world",
                    },
                }
            )

        with self.make_client(handler) as client:
            repo = client.repos.create(
                "hello-world",
                path="apps",
                initial_files={"README.md": "# Hello\n"},
                message="Initial commit",
            )

        self.assertEqual(seen["method"], "POST")
        self.assertEqual(seen["path"], "/v1/repos/create")
        self.assertEqual(seen["payload"]["initialFiles"], {"README.md": "# Hello\n"})
        self.assertEqual(seen["payload"]["path"], "apps")
        self.assertEqual(repo.name, "hello-world")
        self.assertEqual(repo.default_branch, "main")
        self.assertEqual(repo.commit_hash, "commit")

    def test_write_file_encodes_nested_path_and_maps_response(self) -> None:
        seen = {}

        def handler(request: httpx.Request) -> httpx.Response:
            seen["method"] = request.method
            seen["path"] = request.url.path
            seen["payload"] = json.loads(request.content.decode("utf-8"))
            return json_response(
                {
                    "success": True,
                    "data": {
                        "repo": "hello-world",
                        "path": "docs/README.md",
                        "branch": "feature/readme",
                        "sha256": "sha",
                        "commitHash": "commit",
                        "storageUrl": "gs://bucket/file",
                        "storagePath": "org/hello-world/docs/README.md",
                        "gitOrigin": "gcs://bucket/org/hello-world",
                        "committed": True,
                    },
                }
            )

        with self.make_client(handler) as client:
            content = client.repos.write_file(
                "hello-world",
                "docs/README.md",
                branch="feature/readme",
                message="Update docs",
                content="# Docs\n",
            )

        self.assertEqual(seen["method"], "PUT")
        self.assertEqual(seen["path"], "/v1/repos/hello-world/contents/docs/README.md")
        self.assertEqual(seen["payload"]["branch"], "feature/readme")
        self.assertEqual(content.path, "docs/README.md")
        self.assertTrue(content.committed)

    def test_create_rejects_multiple_payload_sources(self) -> None:
        with self.make_client(lambda request: json_response({})) as client:
            with self.assertRaisesRegex(DriftstoneError, "exactly one"):
                client.repos.create(
                    "hello-world",
                    initial_files={"README.md": "# Hello\n"},
                    base64_archive="UEsDBAo=",
                )


if __name__ == "__main__":
    unittest.main()
