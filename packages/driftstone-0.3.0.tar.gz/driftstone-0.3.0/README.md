## Driftstone - Python

Python SDK for the Driftstone repository API.

### Install

```bash
pip install driftstone
```

### Quick Start

```python
from driftstone import Driftstone

client = Driftstone(api_key="your-api-key")

repo = client.repos.create(
    "hello-world",
    initial_files={"README.md": "# Example Repo\n"},
)

branch = client.repos.create_branch(
    "hello-world",
    "feature/readme",
    from_ref=repo.default_branch,
)

client.repos.write_file(
    "hello-world",
    "README.md",
    branch=branch.name,
    message="Update README",
    content="# Example Repo\nUpdated content.\n",
)

client.repos.merge(
    "hello-world",
    head=branch.name,
    base=repo.default_branch,
    message="Merge README update",
)
```

### Using A Context Manager

```python
from driftstone import Driftstone

with Driftstone(api_key="your-api-key") as client:
    repo = client.repos.get("hello-world")
    readme = client.repos.read_file(
        repo.name,
        "README.md",
        branch=repo.default_branch,
    )

    print(readme.content)
```
