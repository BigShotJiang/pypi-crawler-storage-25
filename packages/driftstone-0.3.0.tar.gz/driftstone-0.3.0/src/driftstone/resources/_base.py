from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import Driftstone

class ResourceBase:
    def __init__(self, client: "Driftstone") -> None:
        self._client = client
