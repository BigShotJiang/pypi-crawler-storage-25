"""Driftstone SDK resource modules."""

from .repositories import DriftstoneRepositories

__all__ = ["DriftstoneRepositories"]
