from __future__ import annotations

import base64
from pathlib import Path
from typing import Any
from urllib.parse import quote

from ..exceptions import DriftstoneError
from ..models.repository import (
    DriftstoneBranch,
    DriftstoneContent,
    DriftstoneMerge,
    DriftstoneRepository,
    DriftstoneSync,
)
from ._base import ResourceBase


class DriftstoneRepositories(ResourceBase):
    @staticmethod
    def _require_non_empty_string(value: str, name: str) -> str:
        if not isinstance(value, str) or not value.strip():
            raise DriftstoneError(f"{name} must be a non-empty string")
        return value.strip()

    @staticmethod
    def _optional_non_empty_string(value: str | None, name: str) -> str | None:
        if value is None:
            return None
        return DriftstoneRepositories._require_non_empty_string(value, name)

    @staticmethod
    def _encode_repo(repo: str) -> str:
        normalized = DriftstoneRepositories._require_non_empty_string(repo, "repo").strip("/")
        if not normalized:
            raise DriftstoneError("repo must be a non-empty string")
        return quote(normalized, safe="")

    @staticmethod
    def _encode_path(path: str) -> str:
        normalized = DriftstoneRepositories._require_non_empty_string(path, "path").strip("/")
        if not normalized:
            raise DriftstoneError("path must be a non-empty string")
        return quote(normalized, safe="/")

    @staticmethod
    def _archive_to_base64(archive_path: str | Path) -> str:
        path = Path(archive_path)
        if not path.is_file():
            raise DriftstoneError(f"archive_path must point to a file: {path}")
        return base64.b64encode(path.read_bytes()).decode("ascii")

    def create(
        self,
        name: str,
        *,
        initial_files: dict[str, str] | None = None,
        base64_archive: str | None = None,
        archive_path: str | Path | None = None,
        path: str | None = None,
        default_branch: str = "main",
        replace_if_exists: bool = False,
        message: str | None = None,
    ) -> DriftstoneRepository:
        normalized_name = self._require_non_empty_string(name, "name")
        normalized_path = self._optional_non_empty_string(path, "path")
        normalized_default_branch = self._require_non_empty_string(default_branch, "default_branch")
        normalized_message = self._optional_non_empty_string(message, "message")

        payload_archive_values = [
            value is not None
            for value in (initial_files, base64_archive, archive_path)
        ]
        if sum(payload_archive_values) != 1:
            raise DriftstoneError("Provide exactly one of initial_files, base64_archive, or archive_path")

        if initial_files is not None and (
            not isinstance(initial_files, dict)
            or not all(isinstance(key, str) and isinstance(value, str) for key, value in initial_files.items())
        ):
            raise DriftstoneError("initial_files must be a dictionary of string file paths to string content")

        if base64_archive is not None:
            base64_payload = self._require_non_empty_string(base64_archive, "base64_archive")
        elif archive_path is not None:
            base64_payload = self._archive_to_base64(archive_path)
        else:
            base64_payload = None

        payload: dict[str, Any] = {
            "name": normalized_name,
            "defaultBranch": normalized_default_branch,
            "replaceIfExists": replace_if_exists,
        }
        if normalized_path is not None:
            payload["path"] = normalized_path
        if normalized_message is not None:
            payload["message"] = normalized_message
        if initial_files is not None:
            payload["initialFiles"] = initial_files
        if base64_payload is not None:
            payload["base64"] = base64_payload

        response = self._client._request("POST", "/repos/create", payload)
        return DriftstoneRepository._from_api(response["data"])

    def get(self, repo: str) -> DriftstoneRepository:
        response = self._client._request("GET", f"/repos/{self._encode_repo(repo)}")
        return DriftstoneRepository._from_api(response["data"])

    retrieve = get

    def list_branches(self, repo: str) -> list[DriftstoneBranch]:
        response = self._client._request("GET", f"/repos/{self._encode_repo(repo)}/branches")
        data = response.get("data")
        if not isinstance(data, list):
            raise DriftstoneError("Expected branch list response data to be a list")
        return [DriftstoneBranch._from_api(item) for item in data]

    def get_branch(self, repo: str, branch: str) -> DriftstoneBranch:
        normalized_branch = self._require_non_empty_string(branch, "branch")
        response = self._client._request(
            "GET",
            f"/repos/{self._encode_repo(repo)}/branches/{quote(normalized_branch, safe='')}",
        )
        return DriftstoneBranch._from_api(response["data"])

    def create_branch(
        self,
        repo: str,
        name: str,
        *,
        from_ref: str,
        path: str | None = None,
        base64_archive: str | None = None,
        archive_path: str | Path | None = None,
        storage_url: str | None = None,
        transform: dict[str, Any] | None = None,
        reject_sha256: str | None = None,
        message: str | None = None,
        archive_storage_path: str | None = None,
    ) -> DriftstoneBranch:
        normalized_name = self._require_non_empty_string(name, "name")
        normalized_from_ref = self._require_non_empty_string(from_ref, "from_ref")
        normalized_path = self._optional_non_empty_string(path, "path")
        normalized_storage_url = self._optional_non_empty_string(storage_url, "storage_url")
        normalized_reject_sha256 = self._optional_non_empty_string(reject_sha256, "reject_sha256")
        normalized_message = self._optional_non_empty_string(message, "message")
        normalized_archive_storage_path = self._optional_non_empty_string(
            archive_storage_path,
            "archive_storage_path",
        )

        archive_sources = [value is not None for value in (base64_archive, archive_path, storage_url)]
        if sum(archive_sources) > 1:
            raise DriftstoneError("Provide at most one of base64_archive, archive_path, or storage_url")

        if base64_archive is not None:
            base64_payload = self._require_non_empty_string(base64_archive, "base64_archive")
        elif archive_path is not None:
            base64_payload = self._archive_to_base64(archive_path)
        else:
            base64_payload = None

        if transform is not None and not isinstance(transform, dict):
            raise DriftstoneError("transform must be a dictionary")

        payload: dict[str, Any] = {
            "name": normalized_name,
            "fromRef": normalized_from_ref,
        }
        if normalized_path is not None:
            payload["path"] = normalized_path
        if base64_payload is not None:
            payload["base64"] = base64_payload
        if normalized_storage_url is not None:
            payload["storageUrl"] = normalized_storage_url
        if transform is not None:
            payload["transform"] = transform
        if normalized_reject_sha256 is not None:
            payload["rejectSha256"] = normalized_reject_sha256
        if normalized_message is not None:
            payload["message"] = normalized_message
        if normalized_archive_storage_path is not None:
            payload["archiveStoragePath"] = normalized_archive_storage_path

        response = self._client._request(
            "POST",
            f"/repos/{self._encode_repo(repo)}/branches",
            payload,
        )
        return DriftstoneBranch._from_api(response["data"])

    def read_file(
        self,
        repo: str,
        path: str,
        *,
        branch: str = "main",
    ) -> DriftstoneContent:
        response = self._client._request(
            "GET",
            f"/repos/{self._encode_repo(repo)}/contents/{self._encode_path(path)}",
            {"branch": self._require_non_empty_string(branch, "branch")},
        )
        return DriftstoneContent._from_api(response["data"])

    def write_file(
        self,
        repo: str,
        path: str,
        *,
        branch: str,
        message: str,
        content: str,
        base64_content: bool = False,
    ) -> DriftstoneContent:
        if not isinstance(content, str):
            raise DriftstoneError("content must be a string")
        response = self._client._request(
            "PUT",
            f"/repos/{self._encode_repo(repo)}/contents/{self._encode_path(path)}",
            {
                "branch": self._require_non_empty_string(branch, "branch"),
                "message": self._require_non_empty_string(message, "message"),
                "content": content,
                "base64": base64_content,
            },
        )
        return DriftstoneContent._from_api(response["data"])

    def merge(
        self,
        repo: str,
        *,
        head: str,
        base: str,
        message: str,
    ) -> DriftstoneMerge:
        response = self._client._request(
            "PUT",
            f"/repos/{self._encode_repo(repo)}/merges",
            {
                "head": self._require_non_empty_string(head, "head"),
                "base": self._require_non_empty_string(base, "base"),
                "message": self._require_non_empty_string(message, "message"),
            },
        )
        return DriftstoneMerge._from_api(response["data"])

    def sync(
        self,
        repo: str,
        *,
        branch: str,
        path: str | None = None,
        target_branches: list[str] | None = None,
        message: str | None = None,
        archive_storage_paths: dict[str, str] | None = None,
    ) -> DriftstoneSync:
        normalized_path = self._optional_non_empty_string(path, "path")
        normalized_message = self._optional_non_empty_string(message, "message")

        if target_branches is not None and (
            not isinstance(target_branches, list)
            or not all(isinstance(item, str) and item.strip() for item in target_branches)
        ):
            raise DriftstoneError("target_branches must be a list of non-empty strings")

        if archive_storage_paths is not None and (
            not isinstance(archive_storage_paths, dict)
            or not all(
                isinstance(key, str)
                and key.strip()
                and isinstance(value, str)
                and value.strip()
                for key, value in archive_storage_paths.items()
            )
        ):
            raise DriftstoneError("archive_storage_paths must be a dictionary of non-empty strings")

        payload: dict[str, Any] = {
            "branch": self._require_non_empty_string(branch, "branch"),
        }
        if normalized_path is not None:
            payload["path"] = normalized_path
        if target_branches is not None:
            payload["targetBranches"] = target_branches
        if normalized_message is not None:
            payload["message"] = normalized_message
        if archive_storage_paths is not None:
            payload["archiveStoragePaths"] = archive_storage_paths

        response = self._client._request("POST", f"/repos/{self._encode_repo(repo)}/sync", payload)
        return DriftstoneSync._from_api(response["data"])
