from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class DriftstoneRepository:
    name: str
    default_branch: str
    sha256: str | None = None
    commit_hash: str | None = None
    storage_url: str | None = None
    storage_path: str | None = None
    git_origin: str | None = None
    path: str | None = None

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneRepository":
        return cls(
            name=str(payload["name"]),
            default_branch=str(payload["defaultBranch"]),
            sha256=payload.get("sha256"),
            commit_hash=payload.get("commitHash"),
            storage_url=payload.get("storageUrl"),
            storage_path=payload.get("storagePath"),
            git_origin=payload.get("gitOrigin"),
            path=payload.get("path"),
        )


@dataclass(frozen=True, slots=True)
class DriftstoneBranch:
    name: str
    repo: str | None = None
    from_ref: str | None = None
    sha256: str | None = None
    commit_hash: str | None = None
    storage_url: str | None = None
    storage_path: str | None = None
    archive_storage_url: str | None = None
    git_origin: str | None = None
    committed: bool | None = None

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneBranch":
        return cls(
            repo=payload.get("repo"),
            name=str(payload["name"]),
            from_ref=payload.get("fromRef"),
            sha256=payload.get("sha256"),
            commit_hash=payload.get("commitHash"),
            storage_url=payload.get("storageUrl"),
            storage_path=payload.get("storagePath"),
            archive_storage_url=payload.get("archiveStorageUrl"),
            git_origin=payload.get("gitOrigin"),
            committed=payload.get("committed"),
        )


@dataclass(frozen=True, slots=True)
class DriftstoneContent:
    repo: str
    path: str
    branch: str
    sha256: str
    commit_hash: str
    storage_url: str
    storage_path: str
    git_origin: str
    content: str | None = None
    content_base64: str | None = None
    encoding: str | None = None
    size: int | None = None
    committed: bool | None = None

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneContent":
        return cls(
            repo=str(payload["repo"]),
            path=str(payload["path"]),
            branch=str(payload["branch"]),
            sha256=str(payload["sha256"]),
            commit_hash=str(payload["commitHash"]),
            content=payload.get("content"),
            content_base64=payload.get("contentBase64"),
            encoding=payload.get("encoding"),
            size=payload.get("size"),
            storage_url=str(payload["storageUrl"]),
            storage_path=str(payload["storagePath"]),
            git_origin=str(payload["gitOrigin"]),
            committed=payload.get("committed"),
        )


@dataclass(frozen=True, slots=True)
class DriftstoneMerge:
    repo: str
    head: str
    base: str
    head_commit_hash: str
    previous_base_commit_hash: str
    commit_hash: str
    sha256: str
    storage_url: str
    storage_path: str
    git_origin: str
    merged: bool

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneMerge":
        return cls(
            repo=str(payload["repo"]),
            head=str(payload["head"]),
            base=str(payload["base"]),
            head_commit_hash=str(payload["headCommitHash"]),
            previous_base_commit_hash=str(payload["previousBaseCommitHash"]),
            commit_hash=str(payload["commitHash"]),
            sha256=str(payload["sha256"]),
            storage_url=str(payload["storageUrl"]),
            storage_path=str(payload["storagePath"]),
            git_origin=str(payload["gitOrigin"]),
            merged=bool(payload["merged"]),
        )


@dataclass(frozen=True, slots=True)
class DriftstoneSync:
    repo: str
    branch: str
    commit_hash: str
    storage_path: str
    git_origin: str
    branches: list[dict[str, Any]]

    @classmethod
    def _from_api(cls, payload: Mapping[str, Any]) -> "DriftstoneSync":
        branches = payload.get("branches")
        return cls(
            repo=str(payload["repo"]),
            branch=str(payload["branch"]),
            commit_hash=str(payload["commitHash"]),
            storage_path=str(payload["storagePath"]),
            git_origin=str(payload["gitOrigin"]),
            branches=branches if isinstance(branches, list) else [],
        )
