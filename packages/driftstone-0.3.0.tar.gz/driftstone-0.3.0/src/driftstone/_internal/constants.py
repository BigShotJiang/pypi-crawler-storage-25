DEFAULT_API_BASE_URL = "https://api.driftstone.ai"
