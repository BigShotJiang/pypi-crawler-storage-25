/** @odoo-module **/
import { DropdownItem } from "@web/core/dropdown/dropdown_item";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
const { Component } = owl;
const cogMenuRegistry = registry.category("cogMenu");

export class CogMenu extends Component {
    setup() {
        this.actionService = useService("action");
        this.orm = useService("orm");
    }

    async actionRefreshMessages() {
        try {
            this.orm.call(
                "sinli.message",
                "refresh_messages",
                [],
                {}
            );

            setTimeout(() => {
                window.location.reload();
            }, 3000);

        } catch (error) {
            console.error("Error ejecutando refresh_messages:", error);
        }
    }
}
CogMenu.template = "sinli_refresh_messages_dropdown";
CogMenu.components = { DropdownItem };

export const CogMenuItem = {
    Component: CogMenu,
    groupNumber: 20,
    isDisplayed: ({ searchModel }) => {
        return searchModel.resModel === 'sinli.message';
    },
};

cogMenuRegistry.add("sinli_refresh_messages_dropdown", CogMenuItem, { sequence: 0 });