from odoo import _, models
import base64
import re
from markupsafe import Markup
import logging
_logger = logging.getLogger(__name__)
from odoo.exceptions import ValidationError

# as per https://odoo-development.readthedocs.io/en/latest/dev/py/external-imports.html
try:
    from sinli import *
except ImportError as err:
    _logger.error(err)


class SinliSaleOrder(models.Model):
    """ Extend sale order for sinli management """
    _description = "Sinli Sale Orders"
    _inherit = 'sale.order'

    def action_sinli_export_sale_order(self):

        if not self.env.company.partner_id.sinli_email:
            raise ValidationError(_("Sinli email is not set for this company."))
        elif not self.partner_id.sinli_email:
            raise ValidationError(_("Sinli email is not set for this contact."))

        sale_order = envio.v8.EnvioDoc()

        # Short_id_line
        sale_order.short_id_line.FROM = self.env.company.partner_id.sinli_email
        sale_order.short_id_line.TO = self.partner_id.sinli_email
        sale_order.short_id_line.DOCTYPE = doctype.DocumentType.ENVIO.name
        sale_order.short_id_line.TYPE = "I"
        sale_order.short_id_line.VERSION = "08"
        sale_order.short_id_line.TRANSMISION_NUMBER = "0"   # ?????
        
        # Long_id_line
        sale_order.long_id_line.FROM = self.env.company.partner_id.sinli_id
        sale_order.long_id_line.TO = self.partner_id.sinli_id
        sale_order.long_id_line.TYPE = "I"
        sale_order.long_id_line.FORMAT = "N"
        sale_order.long_id_line.DOCTYPE = doctype.DocumentType.ENVIO.name
        sale_order.long_id_line.FANDE = "FANDE"
        sale_order.long_id_line.FORMAT = "N"
        sale_order.long_id_line.VERSION = "08"

        # Header line
        header = envio.v8.EnvioDoc.Header()
        header.TYPE = "C"
        header.PROVIDER = self.partner_id.name
        header.ORDER_DATE = self.date_order.strftime('%Y%m%d')
        header.CURRENCY = "E"
        header.MAX_DELIVERY_DATE = "19700101"
        header.ASKED_DELIVERY_DATE = "19700101"
        header.STRICT_MAX_DELIVERY_DATE = False
        header.ORDER_CODE = self.name

        if not self.env.company.stock_picking_type_compra_deposito_id.id:
            raise ValidationError(_("Deposit purchase picking type is not set. Configure it in company settings."))
        
        # INVOICE_OR_NOTE: A = Albaran, F = Factura
        header.INVOICE_OR_NOTE = "A"

        # CONSIGNMENT_TYPE: F = Firm sale, D = Deposit sale      
        if self.pricelist_id.is_deposit_pricelist():
            header.CONSIGNMENT_TYPE = "D"
        else:
            header.CONSIGNMENT_TYPE = "F"

        sale_order.doc_lines.append(header)

        # Create one line for each product
        for line in self.order_line:
            # Check if product has ISBN
            formated_isbn = re.sub(r"[-\s]", "", line.product_barcode) if line.product_barcode else ""

            product = envio.v8.EnvioDoc.Detail()
            product.TYPE = "D"
            product.ISBN = formated_isbn
            product.AMOUNT = int(line.product_qty)
            product.EAN = formated_isbn
            product.PRICE = line.price_unit
            product.TITLE = line.product_id.name
            product.ORDER_CODE = self.name
            product.PRICE_NO_VAT = line.price_unit / (1 + line.tax_id.amount / 100) if line.tax_id else line.price_unit
            product.PRICE_W_VAT = line.price_unit
            product.VAT_PERCENT = line.tax_id.amount if line.tax_id else 0
            product.PRICE_TYPE = "F"    # Fixed final price
            product.AUTHORS = ", ".join(filter(None, line.product_id.authorship_ids.mapped('author_id.name'))) if line.product_id.authorship_ids else ""
            # product.DISCOUNT = 0
            sale_order.doc_lines.append(product)

        sale_order.long_id_line.LEN = len(sale_order.doc_lines) + 2     # Check if this works properly

        # Build a SINLI email subject
        subject = Subject()
        subject.FROM = self.env.company.partner_id.sinli_id
        subject.TO = self.partner_id.sinli_id
        subject.DOCTYPE = doctype.DocumentType.ENVIO.name
        subject.VERSION = "08"

        # Create attachment
        file_name = f"SINLI_{doctype.DocumentType.ENVIO.name}_{self.name}.txt"
        file_data = base64.b64encode(str.encode(str(sale_order), "windows-1252"))

        ir_values = {
            "name": file_name,
            "type": "binary",
            "datas": file_data,
            "store_fname": file_name,
            "mimetype": "text/plain",
        }
        mail_attachment = self.env["ir.attachment"].create(ir_values)

        # Create email with the sinli file as attachment
        create_values = {
            "subject": str(subject),
            "email_to": self.partner_id.sinli_email,
            "email_from": self.env.company.partner_id.sinli_email,
            "recipient_ids": [self.partner_id.id],
            "reply_to": "",
            "model": self._name,
            "res_id": self.id,
            "attachment_ids": [mail_attachment.id]  # Include attachment ID
        }
        mail = self.env["mail.mail"].create(create_values)
        mail.send()
        print(f"*****************{mail.state}")

        if mail.state == "sent":
            dialog_message = _("Sinli email succesfully sent to %s") % self.partner_id.sinli_email

            # Add reference to purchase order notes
            sinli_reference_message = Markup(_(
                "SINLI message sent: <a href=# data-oe-model='{model}' data-oe-id='{id}'>{id}</a>"
            ).format(
                model=mail._name,
                id=mail.id,
            ))
            self.message_post(body=sinli_reference_message)
        else:
            dialog_message = _("Sinli email could not be sent. Error %s.") % mail.state
            
        sinli_dialog = self.env['sinli.dialog'].create({
            'message': dialog_message,
        })

        # Return dialog containing the information about the export proccess status
        return {
            'name': 'SINLI',
            'type': 'ir.actions.act_window',
            'res_model': 'sinli.dialog',
            'view_id': self.env.ref('sinli.sinli_dialog_view_form').id,
            'view_mode': 'form',
            'target': 'new',
            'res_id': sinli_dialog.id,
        }
