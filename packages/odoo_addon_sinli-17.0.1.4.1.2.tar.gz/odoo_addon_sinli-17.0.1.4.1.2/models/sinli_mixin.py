from odoo import _, fields, models
from odoo.exceptions import ValidationError
from sinli.common.encoded_values import OrderType
from sinli import Document
from sinli.doctype import DocumentType

import io
import re, base64, logging

from datetime import datetime, time
from markupsafe import Markup
from bs4 import BeautifulSoup
from dataclasses import dataclass, field

try:
    from odoo.tools.misc import xlsxwriter
except ImportError:
    import xlsxwriter

_logger = logging.getLogger(__name__)


@dataclass(frozen = True)
class SinliImportResult:
    message: str
    order: object = None
    xls_attachment_id: int = None
    action: dict = None


class SinliImportMixin(models.AbstractModel):
    """Mixin for shared SINLI import functionalities"""
    _name = 'sinli.import.mixin'
    _description = 'SINLI Import Mixin'
    
    def _get_sinli_message(self, sinli_content):
        decoded_bytes = base64.b64decode(sinli_content)
        decoded_message = decoded_bytes.decode('windows-1252', errors='replace')
        sinli_message = Document.from_str(decoded_message)
        return sinli_message
    
    def _generate_sinli_attachment(self, body_content=None):
        if not body_content:
            raise ValidationError(_("This message does not have any content."))

        soup = BeautifulSoup(body_content, 'html.parser')
        sinli_text = soup.get_text()

        content_bytes = sinli_text.encode('windows-1252', errors='ignore')
        datas_bytes = base64.b64encode(content_bytes)
        datas_str = datas_bytes.decode('ascii')

        attachment = self.env['ir.attachment'].create({
            'name': 'sinli_message_{}.txt'.format(self.id),
            'datas': datas_str,
            'res_model': 'sinli.message',
            'res_id': self.id,
        })
        self.sinli_attachment = attachment.id

    def _find_partner_by_sinli_id(self, sinli_id):
        sender = self.env['res.partner'].search([('sinli_id', '=', sinli_id)], limit=1)
        if not sender:
            raise ValidationError(
                _("No partner found with SINLI ID: %s. Please create a partner with this Sinli ID.") % sinli_id
            )
        return sender
    
    def _validate_sinli_ids(self, sinli_message, sender):
        _logger.info("Validating SINLI IDs for message: %s", sinli_message.long_id_line)
        _logger.info("Sender SINLI ID: %s, Email: %s", sender.sinli_id, sender.sinli_email)
        _logger.info("Company SINLI ID: %s", self.env.company.partner_id.sinli_id)
        _logger.info("Message SINLI IDs - FROM: %s, TO: %s",
                     sinli_message.long_id_line.FROM, sinli_message.long_id_line.TO)
        if not (sinli_message.long_id_line.FROM):
            return _("The message does not have SINLI ID for receiver/sender.")
        
        if sinli_message.long_id_line.FROM != sender.sinli_id:
            return _("Sender's SINLI ID (%s) does not match the SINLI ID for %s.") % (
                sinli_message.long_id_line.FROM, sender.sinli_email
            )
        
        # if sinli_message.long_id_line.TO != self.env.company.partner_id.sinli_id:
        #     return _("Receiver SINLI ID (%s) does not match the company's SINLI ID.") % (
        #         sinli_message.long_id_line.TO
        #     )
        return None
    
    def _find_product_by_isbn(self, isbn):
        formatted_isbn = re.sub(r"[-\s]", "", isbn)
        self.env.cr.execute("""
            SELECT id FROM product_template
            WHERE REGEXP_REPLACE(isbn_number, '[-\\s]', '', 'g') = %s
            LIMIT 1
        """, (formatted_isbn,))
        
        result = self.env.cr.fetchone()
        return self.env['product.template'].browse(result[0]) if result else None
    
    def _get_pricelist_id(self, sender, line):
        if (not hasattr(line, 'ORDER_TYPE') or 
            not line.ORDER_TYPE or
            (sender.property_product_pricelist.is_deposit_pricelist() == 
             (line.ORDER_TYPE == OrderType.DEPOSIT))):
            return sender.property_product_pricelist.id
        
        pricelist_mapping = {
            OrderType.FIRM: self.env.company.default_pricelist_firm_sale.id,
            OrderType.DEPOSIT: self.env.company.default_pricelist_deposit_sale.id,
            OrderType.FAIRE: self.env.company.default_pricelist_fair_sale.id,
            OrderType.OTHER: self.env.company.default_pricelist_other_sale.id,
        }
        return pricelist_mapping.get(line.ORDER_TYPE)
    
    def _process_order_date(self, line):
        if hasattr(line, 'ORDER_DATE') and line.ORDER_DATE:
            date = fields.Date.from_string(line.ORDER_DATE)
            date_and_time = datetime.combine(date, time())
            return fields.Datetime.to_string(date_and_time)
        return fields.Datetime.now()
    
    def _mark_message_as_imported(self, order):
        self.generated_document = order
        self.imported = True
        self.import_date = fields.Datetime.now()
        self.import_user = self.env.user.id

    def _post_order_import_messages(self, order):
        if self._name == "import.sinli.file":
            import_method_word = _("SINLI file")
        else:
            import_method_word = _("SINLI message")

        sinli_reference_message = Markup(_(
            "Order created by importing a"
            " <a href=# data-oe-model='%(model)s' data-oe-id='%(id)s'>%(import_method_word)s</a>"
        ) % {
            "import_method_word": import_method_word,
            "model": self._name,
            "id": self.id,
        })

        order.message_post(body=sinli_reference_message)
        order_url = f"/web#id={order.id}&model={order._name}&view_type=form"
        self.post_note(_("Order imported successfully: %s") % order.name, url=order_url)

    def _import_purchase_order(self, sinli_message, sender):
        if sinli_message.long_id_line.DOCTYPE != DocumentType.ENVIO.name:
            error_message = _("The document type is not 'ENVIO', cannot import as a purchase order.")
            return SinliImportResult(message=error_message)
        
        order_lines = []
        not_imported_products = []
        not_imported_products_xls = []
        date_order = fields.Datetime.now()
        
        for line in sinli_message.doc_lines:
            if line.TYPE == "D":  # Purchase Order line
                product = self._find_product_by_isbn(line.ISBN)

                # Set price with or without VAT based on company settings
                if self.env.company.account_purchase_tax_id.price_include:
                    product_price = line.PRICE_W_VAT
                else:
                    product_price = line.PRICE_NO_VAT

                if product:
                    order_lines.append((0, 0, {
                        'product_id': product.product_variant_ids[0].id,
                        'product_qty': line.AMOUNT,
                        'product_barcode': product.barcode,
                        'price_unit': product_price,
                    }))
                else:
                    formatted_isbn = re.sub(r"[-\s]", "", line.ISBN)
                    not_imported_products.append(" - " + formatted_isbn + " ( " + line.TITLE + " )")
                    not_imported_products_xls.append({
                        'isbn': formatted_isbn,
                        'title': line.TITLE,
                        'price_unit': product_price,
                    })
            
            elif line.TYPE == "C":  # Purchase Order header
                date_order = self._process_order_date(line)

        # If there are products that could not be imported, return error message
        if not_imported_products:
            attachment_id = self.create_books_xls(not_imported_products_xls)
            message = _("Order not imported. Before importing you need to create the following books:\n%s") % (
                "\n".join(not_imported_products))
            return SinliImportResult(message=message, xls_attachment_id=attachment_id)
                        
        # Create purchase order
        purchase_order = self.env['purchase.order'].create({
            'partner_id': sender.id,
            'date_order': date_order,
            'order_line': order_lines,
        })
        
        if not purchase_order:
            return SinliImportResult(message=_("There was an error importing the order"))

        self._post_order_import_messages(purchase_order)

        order_url = f"/web#id={purchase_order.id}&model=purchase.order&view_type=form"
        message = Markup(_(
            "Order imported successfully: "
            "<a href='%(url)s'>%(name)s</a>"
        ) % {
            "url": order_url,
            "name": purchase_order.name,
        })
        return SinliImportResult(message=message, order=purchase_order)
    
    def _import_sale_order(self, sinli_message, sender):
        if sinli_message.long_id_line.DOCTYPE != DocumentType.PEDIDO.name:
            error_message = _("The document type is not 'PEDIDO', cannot import as a sale order.")
            return SinliImportResult(message=error_message)
        
        order_lines = []
        not_imported_products = []
        date_order = fields.Datetime.now()
        pricelist_id = None
        
        for line in sinli_message.doc_lines:
            if line.TYPE == "D":  # Sale Order line
                product = self._find_product_by_isbn(line.ISBN)
                if product:
                    order_lines.append((0, 0, {
                        'product_id': product.product_variant_ids[0].id,
                        'product_uom_qty': line.QUANTITY,
                        'price_unit': line.PRICE,
                    }))
                else:
                    formatted_isbn = re.sub(r"[-\s]", "", line.ISBN)
                    not_imported_products.append(" - " + formatted_isbn + " (" + line.TITLE + ")")
            
            elif line.TYPE == "C":  # Sale Order header
                date_order = self._process_order_date(line)
                pricelist_id = self._get_pricelist_id(sender, line)
                
                if not pricelist_id:
                    error_message = _("Please config the default pricelist for each type of sale order in the company settings.")
                    return SinliImportResult(message=error_message)
        
        # Create sale order
        sale_order = self.env['sale.order'].create({
            'partner_id': sender.id,
            'date_order': date_order,
            'order_line': order_lines,
            'pricelist_id': pricelist_id
        })
        
        if not sale_order:
            error_message = _("There was an error importing the order.")
            return SinliImportResult(message=error_message)
        
        self._post_order_import_messages(sale_order)

        order_url = f"/web#id={sale_order.id}&model=sale.order&view_type=form"
        message = Markup(_(
            "Order imported successfully: "
            "<a href='%(url)s'>%(name)s</a>"
        ) % {
            "url": order_url,
            "name": sale_order.name,
        })

        if not_imported_products:
            message += Markup(_(
                "<br/><br/>"
                "But the following products were not imported:"
                "<br/>%(products)s"
            ) % {
                "products": "<br/>".join(not_imported_products),
            })

        return SinliImportResult(message=message, order=sale_order)
    
    def _import_books(self, sinli_message, sender):
        books_imported = []
        not_imported_books = []
        not_imported_authorships = []
        
        for book_line in sinli_message.lines_by_type["Book"]:
            # Check if the book already exists
            if self._find_product_by_isbn(book_line.ISBN_INVOICE):
                not_imported_books.append("- " + book_line.TITLE_FULL)
                continue

            # Tax for books is always 4% in Spain
            tax_sale_4g = self.env['account.tax'].search([
                ('name', '=', '4% G'),
                ('type_tax_use', '=', 'sale')], limit=1)
            
            # Create new book product
            isbn = re.sub(r"[-\s]", "", book_line.ISBN_INVOICE)
            new_book = self.env['product.template'].create({
                'name': book_line.TITLE_FULL,
                'type': "product",
                'categ_id': self.env.ref("gestion_editorial.product_category_books").id,
                'list_price': book_line.PRICE_PV,
                'taxes_id' : [(6, 0, [tax_sale_4g.id])],
                'isbn_number': isbn,
                'barcode': isbn,
                'purchase_ok': True,
                'sale_ok': True,
            })
            
            # Create supplier info for the book
            self.env['product.supplierinfo'].create({
                'product_tmpl_id': new_book.id,
                'partner_id': sender.id,
                'price': book_line.PRICE_PVP,
                'min_qty': 0
            })
            
            # Process authors
            if book_line.AUTHORS:
                author_type_id = self.env.ref('gestion_editorial.contact_type_author').id

                for author_name in book_line.AUTHORS.split(","):
                    author_contact = self.env['res.partner'].search([
                        ('name', '=ilike', author_name),
                        ('is_author', '=', True)
                    ], limit=1)

                    if author_contact:
                        new_authorship_vals = {
                            'author_id': author_contact.id,
                            'product_id': new_book.id,
                            'contact_type': author_type_id,
                            'sales_price': 0
                        }                    
                        self.env['authorship.product'].create(new_authorship_vals)
                    else:
                        not_imported_authorships.append({
                            'author_name': author_name,
                            'book_id': new_book.id,
                        })
            
            books_imported.append("- " +new_book.name)

        import_message = _("Import completed. Books successfully imported: \n%s \nBooks that already exist and were not imported: \n%s") % (
            "\n".join(books_imported), "\n".join(not_imported_books)
        )
        self.post_note(import_message.replace("\n", "<br/>"))

        ## IF not_imported_authorships
        ## SHOW WIDGET WITH AUTHORNAME + BOOK NAME AND CONFIRM BUTTON TO CREATE THEM
        if not_imported_authorships:
            wizard = self.env['wizard.authorship.confirm'].create({
                'line_ids': [
                    (0, 0, {
                        'author_name_suggestion': authorship['author_name'],  # ← nombre del fichero
                        'author_id': False,                          # ← vacío, usuario elige
                        'book_id': authorship['book_id'],
                    })
                    for authorship in not_imported_authorships
                ],
                'import_result_info': import_message
            })

            wizard_action = {
                'type': 'ir.actions.act_window',
                'name': 'Autorías pendientes de confirmación',
                'res_model': 'wizard.authorship.confirm',
                'res_id': wizard.id,
                'view_mode': 'form',
                'target': 'new',
            }
            return SinliImportResult(message=import_message, action=wizard_action)
        
        return SinliImportResult(message=import_message)
                
    def create_books_xls(self, books_data):
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet('Libros')

        # Styles
        bold = workbook.add_format({'bold': True, 'bg_color': '#CCCCCC'})
        money = workbook.add_format({'num_format': '#,##0.00'})

        # Heads
        headers = ['ISBN', 'Nombre', 'Precio de venta', 'Categoría de producto',
                   'Tipo de producto', 'Disponible en TPV', 'Puede ser comprado', 
                   'Puede ser vendido', 'Authorships/Author', 'Authorships/Contact Type']
        for col, header in enumerate(headers):
            sheet.write(0, col, header, bold)

        # Column widths
        sheet.set_column(0, 0, 20)  # ISBN
        sheet.set_column(1, 1, 50)  # Title
        sheet.set_column(2, 2, 15)  # Price
        sheet.set_column(3, 3, 20)  # Categ
        sheet.set_column(4, 4, 20)  # Tipe
        sheet.set_column(5, 5, 20)  # TPV
        sheet.set_column(6, 6, 20)  # Purchase ok
        sheet.set_column(7, 7, 20)  # Sale ok
        sheet.set_column(8, 8, 50)  # Authorships
        sheet.set_column(9, 9, 30)  # Authorships/Contact Type

        # Data rows
        for row, product in enumerate(books_data, start=1):
            author = product.get('authors') if product.get('authors') else ''
            authorship_type = 'Autora' if product.get('authors') else ''

            sheet.write(row, 0, product['isbn'])
            sheet.write(row, 1, product['title'])
            sheet.write(row, 2, product['price_unit'], money)
            sheet.write(row, 3, 'All / Libros')
            sheet.write(row, 4, 'Producto almacenable')
            sheet.write(row, 5, 1) # TPV
            sheet.write(row, 6, 1) # Purchase ok
            sheet.write(row, 7, 1) # Sale ok
            sheet.write(row, 8, author)
            sheet.write(row, 9, authorship_type)

        workbook.close()
        output.seek(0)

        xls_data = base64.b64encode(output.read())

        attachment = self.env['ir.attachment'].create({
            'name': 'libros.xlsx',
            'type': 'binary',
            'datas': xls_data,
            'mimetype': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        })
        return attachment.id
    
    def post_note(self, message, url=None):
        if not hasattr(self, 'message_post'):
            return

        if url:
            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            url = f"{base_url}{url}"
            message += Markup(_("<br/>Link: <a href='{url}' target='_blank'>{url}</a><br/>")).format(
                url=url
            )
    
        self.message_post(
            body=Markup(message),
            message_type='comment',
            subtype_xmlid='mail.mt_note'
        )

