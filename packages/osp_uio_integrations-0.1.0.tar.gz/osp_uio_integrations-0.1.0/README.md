# osp-uio-integrations

Shared Python integration package for UiO-specific infrastructure systems such
as MREG and Nivlheim.

This repository is the concrete API-glue layer for external UiO systems. It is
meant to keep authentication, request/response handling, error mapping, and
small normalization helpers in one place so providers and transitional
orchestrator code do not duplicate that plumbing.

For maintainer-facing internals and invariants, see `src/README.md`.

## Scope

- Reusable Python clients for UiO infrastructure services
- Shared transport/auth/session glue
- API-specific response parsing and error translation
- Small stable normalized helper types where duplication would otherwise grow

## Current focus

The first concrete integration is a small sync MREG library with:

- explicit transport and auth handling
- optional interactive login for token bootstrap
- request metadata headers such as `User-Agent` and `X-Correlation-ID`
- a host-focused surface covering queries, lifecycle, history, addressing,
  contacts, CNAMEs, and explicit DNS record modules
- room to grow into further MREG areas without flattening everything into
  one module

## Non-goals

- Provider workflow or execution logic
- Ownership, approval, or placement policy
- Orchestrator/provider wire contracts
- Provider-specific planning decisions

## Install

```bash
pip install osp-uio-integrations
```

## Development

```bash
env -u VIRTUAL_ENV uv sync --extra dev
hatch shell
hatch run dev:check
hatch run dev:build
hatch run dev:verify
```

## Release

See `docs/release.md` for the manual tag and publish flow.

Create and push the annotated release tag from the checked-in release notes:

```bash
hatch run dev:tag-push
```
