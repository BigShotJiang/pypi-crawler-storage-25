# osp-uio-integrations 0.1.0

## Highlights

- Initial tagged release of the shared UiO integrations package.
- Added a reusable synchronous MREG client with typed host, record, and
  network helpers.
- Added a reusable synchronous Nivlheim client with stable error mapping and
  normalized host and file helpers.

## Included in this release

- MREG host reads, lifecycle helpers, contacts, CNAMEs, history, and DNS
  record modules.
- MREG network lookup, pagination, free-address selection, and VLAN fullness
  helpers.
- Caller-compat host adapters for code that still expects normalized dict
  shapes.
- Nivlheim host lookup, host existence checks, host deletion, file reads,
  file listing, grep parsing, and typed public models.
- Packaging metadata, typed public exports, release documentation, and
  publish/tag helper scripts.

## Operational Notes

- Requires Python 3.13 or newer.
- Runtime dependency surface is intentionally small: `httpx` only.
- Publish remains manual and gated; use `docs/release.md` for the release
  steps.
