# MREG Host Library Plan

## Status

Implemented for the current host-focused scope.

The design note is kept as an architectural record for the library-centric MREG
host port in `osp-uio-integrations`. The planned host surface described below
has now landed, including explicit RR modules under `hosts/records/`.

This plan follows the repo guidance in `AGENTS.md`:

- prefer understandable code over speculative flexibility
- keep boundaries narrow and explicit
- do not DRY out shape; DRY out knowledge
- refactor incrementally, not as a rewrite

## History

UiO already has a mature MREG client in `mreg-cli`. That codebase is useful
because it proves the API surface and the day-two operational needs:

- token-based login with interactive fallback
- request metadata headers such as `User-Agent` and `X-Correlation-ID`
- a large host surface, not just a single `get host` endpoint
- many MREG-specific quirks around lookup, ownership, record updates, and
  network/IP checks

The problem is that `mreg-cli` is centered on an interactive CLI application,
not on a reusable Python library. It mixes:

- transport code
- prompt logic
- output rendering
- API models
- mutation helpers
- command wiring

That shape works for a REPL, but it is the wrong center of gravity for a shared
library that should be imported by other code.

## Current Goal

Build a small, boring, library-first MREG client in `osp-uio-integrations`
whose first substantial domain is `hosts`.

The base should support incremental porting of the host surface without
changing the core client/domain split.

## Non-Goals

These are explicitly out of scope for the first host push:

- a full port of `mreg-cli`
- a generic resource framework for all MREG objects
- an async-first design
- prompt-toolkit REPL support
- provider or orchestrator workflow logic
- ownership or approval policy
- a broad `mreg` package with zones, groups, policies, and networks all at once

## What We Already Have

The current `osp-uio-integrations` base is enough to build on:

- sync `httpx.Client`
- token login and one retry on `401`
- `User-Agent` and `X-Correlation-ID`
- host package split into its own folder
- explicit exception types
- normalized `HostRecord`

That is a base, not a complete host implementation.

## Main Problems In The Original Code

### 1. Transport, auth, retries, logging, and compatibility fallback are mixed together

From `mreg_cli/utilities/api.py`:

```python
def _request_wrapper(
    operation_type: Literal["get", "post", "patch", "delete"],
    path: str,
    params: QueryParams | None = None,
    ok404: bool = False,
    first: bool = True,
    **data: Any,
) -> Response | None:
    ...
    result = func(
        url,
        params=params,
        json=data or None,
        timeout=MregCliConfig().http_timeout,
    )
    ...
    if (
        result.status_code == 500
        and (operation_type == "post" or operation_type == "patch")
        and params == {}
        and data
    ):
        result = func(url, params={}, timeout=MregCliConfig().http_timeout, data=data)
    ...
    if first and result.status_code == 401:
        prompt_for_password_and_try_update_token()
        return _request_wrapper(operation_type, path, params=params, first=False, **data)
```

This works, but it bundles too many responsibilities:

- request sending
- error handling
- auth refresh
- interactive prompting
- compatibility fallback
- recording/logging

That makes it hard to test and hard to reuse safely outside the CLI.

### 2. Models perform I/O and own endpoint logic

From `mreg_cli/api/abstracts.py`:

```python
class APIMixin(ABC):
    @classmethod
    def get_by_field(cls, field: str, value: str | int) -> Self | None:
        endpoint = cls.endpoint()

        if endpoint.requires_search_for_id() and field == endpoint.external_id_field():
            data = get(endpoint.with_id(value), ok404=True)
            if not data:
                return None
            data = data.json()
        else:
            data = get_item_by_key_value(cls.endpoint(), field, value, ok404=True)

        if not data:
            return None

        return cls(**data)
```

This is powerful, but it makes the data model and the transport layer depend on
each other. In a library, that becomes too magical too quickly.

### 3. CLI command boundaries are not library boundaries

From `mreg_cli/commands/host.py`:

```python
def _import_submodules(self) -> None:
    package_name = "mreg_cli.commands.host_submodules"
    package = importlib.import_module(package_name)
    ...
    for _, module_name, _ in pkgutil.iter_modules([package_dir]):
        importlib.import_module(f"{package_name}.{module_name}")
```

This is fine for command registration. It is not a pattern we should copy into
a library. A library should export explicit modules and classes, not discover
runtime command trees.

### 4. Hard host workflows mix validation, lookup, mutation, and UI output

From `mreg_cli/commands/host_submodules/a_aaaa.py`:

```python
def _ip_change(name: str, old: str, new: str, force: bool, ipversion: IP_Version) -> None:
    ...
    host = Host.get_by_any_means_or_raise(name)
    host_ip = host.get_ip(old_ip)
    ...
    check_ip_constraints(new_ip, network, host, IPOperation.CHANGE, force)
    host_ip.patch(fields={"ipaddress": str(new_ip)})
    OutputManager().add_ok(f"changed ip {old} to {new_ip} for {host}")
```

The underlying knowledge is valuable, but the code is tied to CLI concerns:

- stringly-typed command args
- direct output rendering
- implicit object methods for patching
- mixed validation and transport

## Options Considered

### Option A: Port `mreg-cli` mostly as-is

Pros:

- fastest path to raw feature count
- behavior already battle-tested

Cons:

- drags CLI structure into the library
- keeps model/transport coupling
- harder to test in focused layers
- more magical than needed

Decision:

- reject

### Option B: Build a generic MREG resource framework first

Pros:

- could reduce repeated code later

Cons:

- speculative
- violates the repo rule against abstractions without concrete need
- likely recreates a Python version of the current `APIMixin` approach

Decision:

- reject

### Option C: Build explicit domain modules on top of a small client

Pros:

- boring and testable
- aligns with AGENTS guidance
- lets us add host breadth without inventing a framework
- keeps transport, models, and domain helpers separate

Cons:

- some repetition across domains later

Decision:

- accept

## Recommended Shape

```text
src/osp_uio_integrations/mreg/
  __init__.py
  client.py
  exceptions.py
  auth/
    __init__.py
    interactive.py
    login.py
    tokens.py
  hosts/
    __init__.py
    api.py
    models.py
    queries.py
    contacts.py
    addressing.py
    cnames.py
    history.py
    lifecycle.py
```

Notes:

- `client.py` owns transport, headers, login, and retry
- `hosts/api.py` is a thin composition root, not a behavior-heavy layer
- `hosts/*.py` modules hold concrete host areas
- models stay dumb
- helpers that encode host-specific rules live under `hosts/`, not in the
  generic client

### Public Surface

The intended public surface for the first host rollout is:

- `MregClient`
- `HostsAPI`
- `HostRecord`
- documented names re-exported from `mreg/__init__.py` and `mreg/hosts/__init__.py`

Everything else under `mreg.hosts` is internal until explicitly documented
otherwise. Callers should not import internal helper modules directly.

## Concrete Design Rules

### Rule 1: Models do not call the API

Good:

```python
host = client.hosts.queries.get("foo.uio.no")
client.hosts.contacts.set("foo.uio.no", ["alice@example.com"])
```

Bad:

```python
host = HostRecord.get("foo.uio.no")
host.patch(...)
host.delete()
```

Models may:

- validate and normalize local field shape
- expose read-only convenience properties derived from their own data

Models may not:

- perform lookup or mutation
- choose endpoints
- encode multi-resource business rules

### Rule 1a: Payload parsing lives next to endpoint code

Endpoint-specific payload interpretation belongs in the host query or mutation
module that owns the endpoint, not in the generic client.

That means:

- `client.py` handles transport, auth, headers, and status mapping
- `hosts/*.py` modules translate MREG payload quirks into stable library shapes
- `HostRecord` stays a stable data shape, not an endpoint-aware object

### Rule 2: Interactive prompting is an auth edge, not a host concern

Good:

- `client.py` detects auth failure
- `auth/interactive.py` supplies credentials when allowed
- `hosts/` methods stay unaware of prompts

### Rule 3: Keep host knowledge local

Do not create a universal mutation engine with flags such as:

- `kind="cname"`
- `mode="replace"`
- `resource="record"`

Prefer explicit functions:

- `hosts.cnames.add(...)`
- `hosts.cnames.replace(...)`
- `hosts.contacts.add(...)`
- `hosts.addressing.change_ipv4(...)`

That repeats a bit of shape, but it keeps the knowledge readable.

Shared logic may be extracted only when at least two concrete host modules need
the same knowledge, not merely the same shape.

### Rule 4: `HostsAPI` is a composition root

`HostsAPI` exists to give callers one stable entrypoint, not to centralize host
behavior.

It may:

- compose sub-APIs
- expose a small number of top-level convenience methods such as `get` and
  `list`

It may not become the place where:

- payload normalization accumulates
- fallback behavior is decided
- validation helpers collect
- large convenience aliases obscure the real sub-API ownership

If a method is not a top-five common entrypoint, it should usually live only on
its sub-API.

## Error Contract

The library should define this contract before Phase 1 adds breadth.

### Missing resources

- read lookups such as `hosts.get()` return `None` when the resource is missing
- write operations raise `NotFoundError` unless documented otherwise

### Mapped failures

- unauthenticated requests raise `AuthenticationRequiredError`
- rejected credentials raise `AuthenticationFailedError`
- upstream `404` on required resources raises `NotFoundError`
- upstream `409` raises `ConflictError`
- upstream `422` raises `ValidationError`
- other upstream failures raise `RequestFailedError`
- malformed success responses raise `ResponseDecodeError`

### Exception metadata

When available, request exceptions should carry:

- HTTP status
- endpoint
- upstream request ID
- upstream correlation ID

### Retry scope

Version 1 retries only one `401` authentication failure per logical operation.

It does not automatically retry:

- `5xx` responses
- network failures
- timeouts

Those remain caller-visible failures.

## Transport Contract

### Request helpers

The client should expose explicit helpers rather than one magical wrapper:

- `get_json`
- `post_json`
- `patch_json`
- `delete_json`

These helpers may share private internals, but callers should see explicit
operations.

### Correlation IDs

One logical operation should use one correlation ID.

If a method triggers:

- initial request
- auth refresh
- retried request

all three should carry the same correlation ID.

If the caller does not supply one, the client may generate one for that logical
operation.

### Compatibility fallback

Compatibility fallback must be explicit and opt-in.

If some MREG write endpoints still require form-data fallback, the decision
must be visible at the call site, for example:

```python
self._client.patch_json(
    endpoint,
    json=payload,
    compatibility_fallback="form",
)
```

or through a clearly named domain helper that owns the legacy behavior for a
known endpoint.

The generic client must not silently retry arbitrary writes with different body
encodings.

## Cleaner Implementations For Hard Parts

### 1. Cleaner request flow

Instead of a recursive wrapper that mixes recording, prompting, and fallback,
keep the core request path narrow:

```python
def request_json(
    self,
    method: str,
    endpoint: str,
    *,
    correlation_id: str | None = None,
    **kwargs: Any,
) -> dict[str, Any] | list[Any]:
    corr_id = self._resolve_correlation_id(
        correlation_id=correlation_id,
        method=method,
        endpoint=endpoint,
    )
    self._ensure_token(correlation_id=corr_id)
    response = self._send(method, endpoint, correlation_id=corr_id, **kwargs)
    if response.status_code == 401:
        self._clear_token()
        self._login(force_prompt=self._interactive, correlation_id=corr_id)
        response = self._send(method, endpoint, correlation_id=corr_id, **kwargs)
    self._raise_for_status(response, endpoint=endpoint)
    return self._decode_json(response)
```

Why this is better:

- one logical request keeps one correlation ID
- auth retry is explicit
- prompting still happens, but only through auth
- response decoding and status handling are separate

### 2. Cleaner host mutations

Instead of `host.patch(...)` on a model, keep mutation code in one place:

```python
class HostContactsAPI:
    def __init__(self, client: MregClient) -> None:
        self._client = client

    def set(
        self,
        hostname: str,
        contacts: list[str],
        *,
        correlation_id: str | None = None,
    ) -> HostRecord:
        payload = {"contact": ",".join(contacts)}
        data = self._client.patch_json(
            f"/api/v1/hosts/{hostname}",
            json=payload,
            correlation_id=correlation_id,
        )
        return parse_host_payload(data)
```

Why this is better:

- no model magic
- all host-contact behavior is findable under one module
- straightforward to test with mocked responses
- endpoint-shape interpretation stays with the endpoint code

### 3. Cleaner IP constraint logic

The original A/AAAA code contains real business knowledge, but it is embedded
inside CLI handlers. We should keep the knowledge and move it into pure helper
functions plus explicit API calls.

Example:

```python
def validate_ip_change(
    *,
    host: HostRecord,
    old_ip: str,
    new_ip: str,
    network: NetworkRecord | None,
    force: bool,
) -> None:
    if old_ip == new_ip:
        raise ConflictError("Old and new IP are equal")
    if force:
        return
    if network is None:
        raise ValidationError("Network for new IP not found; force is required")
    if network.frozen:
        raise ValidationError(f"Network {network.cidr} is frozen; force is required")
    if new_ip in host.ipaddresses:
        raise ConflictError(f"Host {host.name} already has IP {new_ip}")
```

Then the host-addressing method can stay small:

```python
def change_ipv4(...):
    host = self._queries.get(hostname, correlation_id=correlation_id)
    network = self._networks.get_by_ip(new_ip, correlation_id=correlation_id)
    validate_ip_change(host=host, old_ip=old_ip, new_ip=new_ip, network=network, force=force)
    return self._client.patch_json(...)
```

Why this is better:

- reusable pure validation
- no CLI output dependency
- transport and validation stay separate

### 4. Cleaner host surface than one giant file

Instead of one `hosts.py` with fifty methods, keep one facade and several
focused modules:

```python
class HostsAPI:
    def __init__(self, client: MregClient) -> None:
        self._queries = HostQueries(client)
        self.contacts = HostContactsAPI(client, self._queries)
        self.addressing = HostAddressingAPI(client, self._queries)
        self.cnames = HostCnameAPI(client, self._queries)
        self.history = HostHistoryAPI(client)

    def get(self, hostname: str, *, correlation_id: str | None = None) -> HostRecord | None:
        return self._queries.get(hostname, correlation_id=correlation_id)

    def list(...):
        return self._queries.list(...)
```

Why this is better:

- callers still get `client.hosts`
- the implementation does not collapse into a god-file
- file boundaries match real host areas
- shared host lookup behavior is explicit in `HostQueries`

## Migration Position

The immediate migration target is not the `mreg-cli` application itself.

The first success condition is narrower:

- new library consumers can call host functionality without importing CLI code
- the host surface can be ported incrementally from the existing behavior
- endpoint parity matters before full CLI behavior parity

If the CLI later reuses this library, that should happen after the host library
has a stable enough surface and error contract.

## Phased Delivery Plan

### Phase 0: Base client hardening

Status:

- completed

Work:

- define and document the error contract
- decide and document compatibility fallback policy
- keep sync `httpx`
- keep token retry
- keep `User-Agent`
- keep `X-Correlation-ID`
- add explicit `get_json`, `post_json`, `patch_json`, `delete_json` helpers
- tighten request metadata in exceptions

Exit criteria:

- all CRUD-style host calls can use one consistent request surface

### Phase 1: Host queries and basic mutations

Status:

- completed

Work:

- `hosts/queries.py`
  - `get`
  - `list`
  - `find`
  - `exists`
  - `info`-style lookup by hostname first
- `hosts/contacts.py`
  - `set`
  - `unset`
  - `add`
  - `remove`
- `hosts/lifecycle.py`
  - basic host create
  - basic host delete
- `hosts/history.py`
  - fetch and normalize history responses

Exit criteria:

- the core `core.py` host commands from `mreg-cli` have a library home

### Phase 2: Addressing

Status:

- completed

Work:

- `hosts/addressing.py`
  - `show_ipv4`
  - `show_ipv6`
  - `add_ipv4`
  - `add_ipv6`
  - `change_ipv4`
  - `change_ipv6`
  - `move_ipv4`
  - `move_ipv6`
  - `remove_ipv4`
  - `remove_ipv6`
- keep validation helpers separate from transport-heavy methods; split the
  module only when real pressure appears
- add small network helper types only where host workflows need them

Exit criteria:

- the `a_aaaa.py` surface is covered without importing CLI patterns

### Phase 3: CNAMEs and RR records

Status:

- completed

Work:

- `hosts/cnames.py`
  - `add`
  - `remove`
  - `replace`
  - `list`
- `hosts/records/`
  - `hinfo.py`
  - `loc.py`
  - `mx.py`
  - `naptr.py`
  - `ptr.py`
  - `srv.py`
  - `sshfp.py`
  - `ttl.py`
  - `txt.py`

Exit criteria:

- record operations exist as explicit modules, not a mega-helper

### Phase 4: Coverage hardening

Status:

- completed for the current host-focused scope

Work:

- integration-style tests around stable request/response promises
- regression tests for tricky auth-retry and correlation-ID behavior
- a small high-signal suite for host mutation flows

Exit criteria:

- host library is safe to adopt without the CLI as the real source of truth

Note:

- the library keeps TTL operations explicit with separate host and SRV entry
  points instead of the CLI's single stringly-targeted TTL command

## Test Strategy

Per AGENTS guidance, prefer stable-boundary tests over piles of tiny mocks.

Test layers:

- unit tests for pure validation helpers
- integration-style client tests with `httpx.MockTransport`
- a few regression tests for auth retry, stale tokens, and tricky mutations

Avoid:

- dozens of low-signal tests that only vary small argument shapes
- tests that merely restate internal implementation

## Open Questions

These questions affect scope, not the base shape:

- which host mutations do we need first for real callers
- whether `info` should support only hostname in v1 or also IP/MAC lookup
- how much of network lookup should live in `mreg/networks/` versus as a
  helper used only by host addressing

## Recommended Immediate Next Steps

1. Define the public error contract and missing-resource behavior in code and
   docs.
2. Add generic `post_json`, `patch_json`, and `delete_json` helpers to the
   current client.
3. Decide the explicit compatibility fallback API for legacy form-data writes.
4. Split host queries out of `hosts/api.py` into `hosts/queries.py`.
5. Implement `hosts/contacts.py` first.
6. Implement `hosts/cnames.py` second.
7. Implement `hosts/addressing.py` third, with pure validation helpers for the
   non-trivial IP checks.

That order is intentionally boring:

- it grows the host surface
- it avoids a speculative framework
- it keeps file boundaries aligned with actual knowledge
- it moves one proven slice at a time out of the CLI shape
