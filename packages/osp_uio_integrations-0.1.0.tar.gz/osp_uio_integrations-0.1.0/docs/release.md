# Release Guide

This repo uses a manual release flow. Keep the release notes in-repo, create an
annotated tag from that file, then publish the already-verified artifacts.

## Preflight

Before tagging or publishing:

- ensure the worktree is clean
- ensure `pyproject.toml` has the intended version
- update `docs/release-notes-X.Y.Z.md` for the version you are releasing
- run the local quality gates

```bash
env -u VIRTUAL_ENV uv sync --extra dev
hatch shell
hatch run dev:check
```

## Manual tag flow

Release tags should be annotated and should use the checked-in release notes as
the tag message.

For `0.1.0`, either run the helper script:

```bash
hatch run dev:tag-push
```

Or run the equivalent commands directly:

```bash
git tag -a v0.1.0 -F docs/release-notes-0.1.0.md
git push origin v0.1.0
```

`dev:tag` creates the annotated tag locally. `dev:tag-push` creates it and
pushes it to `origin`.

## Manual/gated publish

Publishing to PyPI (or an internal index) remains intentionally manual/gated.

```bash
env -u VIRTUAL_ENV uv sync --extra dev
hatch shell
hatch run dev:check
hatch run dev:publish
```

If using a custom repository:

```bash
hatch run dev:publish -- -r <repo-name>
```

`dev:publish` behavior:
- removes `dist/` first (no stale artifact uploads)
- builds fresh wheel + sdist for the current version
- refuses publish if unexpected files are present in `dist/`
- runs `twine check` before upload
- disables keyring backend to avoid locked desktop keyring failures
- removes `dist/` again after successful upload

If you want the publish step to create and push the release tag after a
successful upload:

```bash
hatch run dev:publish -- --tag
```

When `--tag` is used, the publish script requires
`docs/release-notes-X.Y.Z.md` and uses that file as the annotated tag body.

Credentials should be stored in `~/.pypirc` (or env vars), not committed.

TestPyPI dry run publish:

```bash
hatch run dev:publish-test
```
