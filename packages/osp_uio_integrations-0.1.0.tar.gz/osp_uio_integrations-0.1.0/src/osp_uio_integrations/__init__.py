"""Shared integration clients for UiO-specific infrastructure services.

This package provides reusable Python clients and small normalization helpers
for external UiO systems such as MREG and Nivlheim. It exists to keep raw API
glue in one place so providers and other callers do not duplicate auth,
request/response handling, pagination, error mapping, or stable host and
record normalization.

It does not own provider workflow, approval policy, ownership decisions, or
orchestrator/provider wire contracts.
"""

from .mreg import MregClient
from .nivlheim import NivlheimClient
from .version import __version__

__all__ = ["MregClient", "NivlheimClient", "__version__"]
