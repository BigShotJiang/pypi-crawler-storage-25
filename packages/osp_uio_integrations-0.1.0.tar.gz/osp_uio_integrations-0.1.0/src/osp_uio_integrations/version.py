"""Package version for osp-uio-integrations."""

__version__ = "0.1.0"
