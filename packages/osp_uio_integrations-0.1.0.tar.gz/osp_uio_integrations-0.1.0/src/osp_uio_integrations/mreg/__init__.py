"""MREG client package.

This package provides a small synchronous client for the UiO MREG API. It owns
transport, token handling, and light response normalization for MREG-facing
callers. The public surface exported here is the intended import root for most
library users:

- `MregClient` for transport and composed domain APIs
- stable enums used at call boundaries
- the small exception taxonomy callers are expected to catch

It does not own orchestration policy, provider workflow, or command-line
interaction beyond an optional credentials prompt hook. Concrete submodules
under `osp_uio_integrations.mreg` remain implementation details unless they are
re-exported here or documented as public elsewhere.
"""

from .client import MregClient
from .enums import (
    AddressFamily,
    CompatibilityFallback,
    RequestMethod,
    SshfpAlgorithm,
    SshfpHashType,
    ValidationSource,
)
from .exceptions import (
    AuthenticationFailedError,
    AuthenticationRequiredError,
    ConflictError,
    ForbiddenError,
    MregError,
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
)

__all__ = [
    "AuthenticationFailedError",
    "AuthenticationRequiredError",
    "AddressFamily",
    "ConflictError",
    "ForbiddenError",
    "CompatibilityFallback",
    "MregClient",
    "MregError",
    "MutationStateUncertainError",
    "MutationStep",
    "NotFoundError",
    "RequestMethod",
    "RequestFailedError",
    "ResponseDecodeError",
    "SshfpAlgorithm",
    "SshfpHashType",
    "ValidationSource",
    "ValidationError",
]
