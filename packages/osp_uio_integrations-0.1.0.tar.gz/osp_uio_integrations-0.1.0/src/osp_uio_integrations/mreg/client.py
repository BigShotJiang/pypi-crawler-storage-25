"""Synchronous MREG transport boundary.

This module owns the low-level contract with the MREG HTTP API: token-backed
authentication, request dispatch, one-shot 401 retry, correlation-id handling,
compatibility fallback for legacy form-style writes, and translation from raw
HTTP failures into the library's stable exception taxonomy.

It does not own host-specific endpoint knowledge, record semantics, or any
workflow policy. Those concerns live in the domain modules under
``osp_uio_integrations.mreg.hosts`` so the transport layer stays reusable and
predictable.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any, TypedDict, TypeVar
from urllib.parse import parse_qs, urlparse
from uuid import uuid4

import httpx

from ..version import __version__
from .auth.interactive import CredentialPrompt, prompt_for_credentials
from .auth.login import Credentials, login_for_token
from .auth.tokens import MemoryTokenStore, TokenStore
from .enums import CompatibilityFallback, RequestMethod, ValidationSource
from .exceptions import (
    AuthenticationRequiredError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
)
from .hosts import HostRecord, HostsAPI
from .networks import NetworksAPI

_DecodedJsonT = TypeVar("_DecodedJsonT")


class MregClient:
    """Token-aware synchronous client for the MREG API.

    The client owns a few critical behaviors that callers should be able to rely
    on:

    - credentials can be supplied up front, via a persisted token store, or by
      an optional interactive prompt hook
    - every public operation gets one logical correlation id, reused across the
      request and any auth retry triggered by a stale token
    - transport failures and upstream status codes are mapped into stable local
      exception types with request metadata attached
    - compatibility fallback from JSON to form-encoded writes only happens when
      the caller opts into it at the call site

    The client deliberately does not expose a generic resource framework. Domain
    modules compose it into explicit surfaces such as ``client.hosts``.
    """

    def __init__(
        self,
        *,
        base_url: str,
        token: str | None = None,
        username: str | None = None,
        password: str | None = None,
        interactive: bool = False,
        credential_prompt: CredentialPrompt | None = None,
        token_store: TokenStore | None = None,
        timeout: float = 20.0,
        user_agent: str | None = None,
        correlation_id: str | None = None,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        """Configure one synchronous MREG client instance.

        The constructor collects the three supported authentication entry
        points for the library:

        - an already-issued token supplied directly
        - username/password credentials that can be exchanged for a token
        - an optional interactive prompt hook used when no usable token exists

        A token store may be provided so short-lived processes can reuse a
        token obtained by an earlier client instance. The injected transport is
        primarily intended for tests; domain code should normally depend on the
        public host APIs rather than a custom transport shape.

        Args:
            base_url: Root URL for the target MREG deployment. The value is
                normalized once so endpoint helpers can pass relative paths.
            token: Pre-issued API token to install immediately. This bypasses
                login until the token is rejected upstream.
            username: Username used for token acquisition when a login flow is
                needed.
            password: Password paired with ``username`` for token acquisition.
            interactive: Whether the client may prompt for credentials when no
                reusable token is available or after a ``401`` retry path.
            credential_prompt: Prompt hook used when interactive credential
                collection is enabled.
            token_store: Optional persistence boundary for reusing tokens
                across client instances.
            timeout: Per-request timeout passed to the underlying
                ``httpx.Client``.
            user_agent: Optional override for the default library user-agent.
            correlation_id: Default operation correlation id used when callers
                do not supply one explicitly.
            transport: Optional custom ``httpx`` transport, mainly useful for
                tests.
        """
        self._base_url = base_url.rstrip("/")
        self._credentials = (
            Credentials(username=username, password=password)
            if username is not None and password is not None
            else None
        )
        self._interactive = interactive
        self._credential_prompt = credential_prompt or prompt_for_credentials
        self._token_store = token_store or MemoryTokenStore()
        self._default_correlation_id = correlation_id
        self._token = token
        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            transport=transport,
            headers={"User-Agent": user_agent or self._default_user_agent()},
        )

        self.hosts = HostsAPI(self)
        self.networks = NetworksAPI(self)

    @property
    def base_url(self) -> str:
        """Return the configured MREG base URL."""
        return self._base_url

    @property
    def username(self) -> str | None:
        """Return the configured username when known."""
        if self._credentials is None:
            return None
        return self._credentials.username

    def close(self) -> None:
        """Close the underlying HTTP client.

        Closing the client only disposes the local ``httpx.Client``. Persisted
        tokens remain in the configured token store so later client instances
        can reuse them.
        """
        self._client.close()

    def __enter__(self) -> MregClient:
        """Return the client as a context manager."""
        return self

    def __exit__(self, *_: object) -> None:
        """Close the HTTP client when exiting a context manager."""
        self.close()

    def get_host_by_name(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> dict[str, Any]:
        """Return a normalized host mapping compatible with current callers.

        This is a convenience adapter for call sites that already expect the
        orchestrator-style dictionary shape. The typed host-domain surface
        remains available through ``client.hosts.queries.get(...)`` and
        ``get_host_record_by_name``. The method keeps the caller-facing shape
        small on purpose: hostname, siteadmins, and IP addresses.
        """
        record = self.get_host_record_by_name(hostname, correlation_id=correlation_id)
        if record is None:
            return {}
        return record.to_dict()

    def get_host_record_by_name(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> HostRecord | None:
        """Return one normalized typed host record, or ``None`` when absent.

        This is the preferred shared-library read contract. It exposes the
        stable host model without making callers reach into
        ``client.hosts.queries`` when they only need the common lookup path.
        """
        return self.hosts.queries.get(hostname, correlation_id=correlation_id)

    def list_hosts(
        self,
        *,
        params: dict[str, object] | None = None,
        correlation_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Return normalized host mappings from the host listing endpoint.

        This mirrors the shape already used by orchestrator while reusing the
        typed parser and pagination handling owned by the host query boundary.
        """
        return [
            record.to_dict()
            for record in self.hosts.queries.many(
                params=params,
                correlation_id=correlation_id,
            )
        ]

    def host_exists(self, hostname: str, *, correlation_id: str | None = None) -> bool:
        """Return whether MREG currently knows about the hostname.

        Existence checks intentionally reuse the normalized host lookup path so
        there is one definition of "host absent" in the shared client.
        """
        return self.hosts.queries.exists(hostname, correlation_id=correlation_id)

    def get_json(
        self,
        endpoint: str,
        *,
        params: dict[str, object] | None = None,
        soft_404: bool = False,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Fetch one JSON object or list from MREG.

        This is the normal read helper used by domain modules. It keeps the
        transport contract narrow by accepting only response bodies that decode
        into a JSON object or array. Callers that need scalar JSON values, such
        as MREG's ``first_unused`` endpoint, should use ``get_json_value``
        instead.

        Args:
            endpoint: Relative MREG endpoint path.
            params: Optional query parameters forwarded as-is to MREG.
            soft_404: When ``True``, treat ``404`` as an empty result instead
                of raising ``NotFoundError``.
            correlation_id: Optional operation id reused across the request and
                any login retry triggered by stale credentials.

        Returns:
            Decoded JSON object or list, or ``None`` when ``soft_404`` is
            enabled and the object is missing.

        Raises:
            AuthenticationRequiredError: No usable token or credentials were
                available for the request.
            RequestFailedError: Transport failure or unexpected upstream HTTP
                failure occurred.
            ResponseDecodeError: Upstream success response was not a JSON
                object or array.
        """
        return self._request_json(
            RequestMethod.GET,
            endpoint,
            params=params,
            soft_404=soft_404,
            allow_empty=False,
            compatibility_fallback=None,
            correlation_id=correlation_id,
        )

    def get_json_value(
        self,
        endpoint: str,
        *,
        params: dict[str, object] | None = None,
        soft_404: bool = False,
        correlation_id: str | None = None,
    ) -> object | None:
        """Fetch any JSON value from MREG, including scalars.

        A small set of MREG endpoints returns plain strings or numbers instead
        of JSON objects. This helper exists so those endpoints can stay
        explicit at the call site rather than forcing the regular object/list
        helper to grow ambiguous decoding rules.

        Args:
            endpoint: Relative MREG endpoint path.
            params: Optional query parameters forwarded as-is to MREG.
            soft_404: When ``True``, treat ``404`` as a missing value and
                return ``None``.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            Any successfully decoded JSON value, or ``None`` when ``soft_404``
            is enabled and the object is missing.

        Examples:
            MREG's ``first_unused`` endpoint returns a plain string IP address
            rather than a JSON object, so addressing workflows use this helper
            instead of ``get_json``.
        """
        return self._request_any_json(
            RequestMethod.GET,
            endpoint,
            params=params,
            soft_404=soft_404,
            compatibility_fallback=None,
            correlation_id=correlation_id,
        )

    def get_json_str(
        self,
        endpoint: str,
        *,
        params: dict[str, object] | None = None,
        soft_404: bool = False,
        correlation_id: str | None = None,
    ) -> str | None:
        """Fetch one JSON string value from MREG.

        This helper exists for the small scalar subset of MREG endpoints that
        return strings on success. It keeps the "expected string" contract at
        the transport edge instead of making every domain caller re-check the
        decoded type.

        Returns:
            Decoded string value, or ``None`` when ``soft_404`` is enabled and
            the object is missing.

        Raises:
            ResponseDecodeError: The upstream success response was not a JSON
                string.
        """
        value = self.get_json_value(
            endpoint,
            params=params,
            soft_404=soft_404,
            correlation_id=correlation_id,
        )
        if value is None:
            return None
        if isinstance(value, str):
            return value
        raise ResponseDecodeError(
            "MREG returned an unexpected JSON scalar shape",
            method=RequestMethod.GET,
            endpoint=endpoint,
        )

    def get_json_collection(
        self,
        endpoint: str,
        *,
        params: dict[str, object] | None = None,
        soft_404: bool = False,
        correlation_id: str | None = None,
    ) -> list[object]:
        """Fetch a list endpoint and follow pagination until exhaustion.

        Host and network callers both need one stable way to consume MREG list
        endpoints. Some return raw arrays, others return paginated objects with
        ``results`` and ``next`` links. Keeping that loop here makes
        pagination a transport capability instead of re-implementing it in each
        domain module.

        Args:
            endpoint: Relative MREG collection endpoint path.
            params: Optional query parameters for the first page request.
            soft_404: Whether ``404`` should be treated as an empty collection.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            Flattened decoded collection items across every page.
        """
        items: list[object] = []
        next_endpoint = endpoint
        next_params = params

        while True:
            page = self.get_json(
                next_endpoint,
                params=next_params,
                soft_404=soft_404,
                correlation_id=correlation_id,
            )
            if page is None:
                return items
            if isinstance(page, list):
                items.extend(page)
                return items
            if not isinstance(page, dict):
                raise ResponseDecodeError(
                    "MREG collection response was not a JSON list or paginated object",
                    method=RequestMethod.GET,
                    endpoint=next_endpoint,
                )

            results = page.get("results")
            if not isinstance(results, list):
                raise ResponseDecodeError(
                    "MREG paginated collection response did not include a results list",
                    method=RequestMethod.GET,
                    endpoint=next_endpoint,
                )
            items.extend(results)

            next_url = page.get("next")
            if not next_url:
                return items
            next_endpoint, next_params = self._parse_collection_next(
                next_url,
                current_endpoint=next_endpoint,
            )

    def _request_any_json(
        self,
        method: RequestMethod,
        endpoint: str,
        *,
        soft_404: bool,
        compatibility_fallback: CompatibilityFallback | None,
        correlation_id: str | None = None,
        **kwargs: Any,
    ) -> object | None:
        """Run the shared request lifecycle for permissive JSON decoding."""
        response = self._request(
            method,
            endpoint,
            allow_404=soft_404,
            compatibility_fallback=compatibility_fallback,
            correlation_id=correlation_id,
            **kwargs,
        )
        return self._decode_json_value(
            response,
            method=method,
            soft_404=soft_404,
            endpoint=endpoint,
        )

    def post_json(
        self,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, object] | None = None,
        compatibility_fallback: CompatibilityFallback | None = None,
        allow_empty: bool = False,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Send one JSON-backed POST request through the common write flow.

        The helper preserves the library-wide transport contract: one logical
        correlation id, one auth retry on ``401``, and optional explicit
        compatibility fallback for legacy endpoints that still require
        form-encoded writes.

        Args:
            endpoint: Relative MREG endpoint path.
            json: JSON payload for the write operation.
            params: Optional query parameters forwarded to MREG.
            compatibility_fallback: Explicit legacy fallback mode to use when a
                known endpoint still requires form-encoded writes.
            allow_empty: Whether empty success responses should be accepted as
                ``None``.
            correlation_id: Optional logical operation id for tracing.
        """
        return self._request_json(
            RequestMethod.POST,
            endpoint,
            params=params,
            json=json,
            compatibility_fallback=compatibility_fallback,
            correlation_id=correlation_id,
            allow_empty=allow_empty,
            soft_404=False,
        )

    def patch_json(
        self,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, object] | None = None,
        compatibility_fallback: CompatibilityFallback | None = None,
        allow_empty: bool = False,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Send one JSON-backed PATCH request through the common write flow.

        Domain modules use this helper for partial updates so transport
        behavior stays consistent with ``post_json`` and ``delete_json``.
        Endpoint-specific validation still belongs in the domain layer; this
        method only owns the HTTP contract.

        Args:
            endpoint: Relative MREG endpoint path.
            json: Partial JSON payload for the write operation.
            params: Optional query parameters forwarded to MREG.
            compatibility_fallback: Explicit legacy fallback mode for endpoints
                that still behave like form posts.
            allow_empty: Whether empty success responses should be accepted as
                ``None``.
            correlation_id: Optional logical operation id for tracing.
        """
        return self._request_json(
            RequestMethod.PATCH,
            endpoint,
            params=params,
            json=json,
            compatibility_fallback=compatibility_fallback,
            correlation_id=correlation_id,
            allow_empty=allow_empty,
            soft_404=False,
        )

    def delete_json(
        self,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, object] | None = None,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Send one DELETE request and tolerate empty successful responses.

        MREG delete endpoints sometimes return ``204 No Content`` and sometimes
        return a JSON body. Some delete-style mutation endpoints also require
        a small JSON payload. This helper hides that transport inconsistency
        so domain modules can treat deletion as one stable operation.

        Args:
            endpoint: Relative MREG endpoint path.
            json: Optional JSON payload for delete-style mutation endpoints.
            params: Optional query parameters forwarded to MREG.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            Decoded JSON payload when one is present, otherwise ``None`` for
            empty successful responses.
        """
        return self._request_json(
            RequestMethod.DELETE,
            endpoint,
            json=json,
            params=params,
            correlation_id=correlation_id,
            allow_empty=True,
            soft_404=False,
            compatibility_fallback=None,
        )

    def _request_json(
        self,
        method: RequestMethod,
        endpoint: str,
        *,
        soft_404: bool,
        allow_empty: bool,
        compatibility_fallback: CompatibilityFallback | None,
        correlation_id: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any] | list[Any] | None:
        """Run the shared request lifecycle for object-or-list JSON responses.

        This private helper exists to keep the public verb-specific methods
        thin while ensuring they all share the same auth retry, correlation-id,
        and decode behavior. Callers still choose explicit HTTP verbs.
        """
        return self._request_with_decoder(
            method,
            endpoint,
            decoder=self._decode_json,
            soft_404=soft_404,
            allow_empty=allow_empty,
            compatibility_fallback=compatibility_fallback,
            correlation_id=correlation_id,
            **kwargs,
        )

    def _request_with_decoder(
        self,
        method: RequestMethod,
        endpoint: str,
        *,
        decoder: Callable[..., _DecodedJsonT],
        soft_404: bool,
        allow_empty: bool,
        compatibility_fallback: CompatibilityFallback | None,
        correlation_id: str | None = None,
        **kwargs: Any,
    ) -> _DecodedJsonT:
        """Run the shared request lifecycle with one explicit decoder."""
        response = self._request(
            method,
            endpoint,
            allow_404=soft_404,
            correlation_id=correlation_id,
            compatibility_fallback=compatibility_fallback,
            **kwargs,
        )
        return decoder(
            response,
            method=method,
            endpoint=endpoint,
            soft_404=soft_404,
            allow_empty=allow_empty,
        )

    def _parse_collection_next(
        self,
        next_url: object,
        *,
        current_endpoint: str,
    ) -> tuple[str, dict[str, object] | None]:
        """Resolve one paginated ``next`` link into endpoint plus params."""
        if not isinstance(next_url, str) or not next_url.strip():
            raise ResponseDecodeError(
                "MREG paginated collection response included an invalid next link",
                method=RequestMethod.GET,
                endpoint=current_endpoint,
            )

        parsed = urlparse(next_url)
        endpoint = parsed.path or current_endpoint
        if parsed.query:
            parsed_query = parse_qs(parsed.query, keep_blank_values=True)
            params: dict[str, object] = {
                key: values[0] if len(values) == 1 else values
                for key, values in parsed_query.items()
            }
        else:
            params = None
        return endpoint, params

    def _request(
        self,
        method: RequestMethod,
        endpoint: str,
        *,
        allow_404: bool = False,
        compatibility_fallback: CompatibilityFallback | None = None,
        correlation_id: str | None = None,
        **kwargs: Any,
    ) -> httpx.Response:
        """Execute one logical request with at most one auth retry.

        Every public library call should correspond to one correlation id even
        if the first upstream attempt fails with ``401`` and the client has to
        clear the stale token, re-authenticate, and resend the request. Other
        failure modes are not retried here on purpose; callers should see
        network and upstream failures directly unless the library has a very
        specific compatibility reason to intervene.

        Args:
            method: HTTP verb for the upstream call.
            endpoint: Relative MREG endpoint path.
            allow_404: Whether ``404`` should be allowed through to the decode
                layer instead of raising immediately.
            compatibility_fallback: Optional legacy fallback mode for writes.
            correlation_id: Optional logical operation id supplied by the
                caller.
            **kwargs: Forwarded request arguments for ``httpx.Client``.

        Returns:
            The final upstream ``httpx.Response`` after any permitted auth
            retry path has completed.
        """
        request_correlation_id = self._resolve_correlation_id(
            correlation_id=correlation_id,
            method=method,
            endpoint=endpoint,
        )
        token_was_fresh = self._ensure_token(correlation_id=request_correlation_id)
        response = self._send(
            method,
            endpoint,
            correlation_id=request_correlation_id,
            compatibility_fallback=compatibility_fallback,
            **kwargs,
        )
        if response.status_code != 401:
            if not (allow_404 and response.status_code == 404):
                self._raise_for_status(response, method=method, endpoint=endpoint)
            return response
        if token_was_fresh:
            self._raise_for_status(response, method=method, endpoint=endpoint)

        self._clear_token()
        self._login(
            force_prompt=self._interactive,
            correlation_id=request_correlation_id,
        )
        response = self._send(
            method,
            endpoint,
            correlation_id=request_correlation_id,
            compatibility_fallback=compatibility_fallback,
            **kwargs,
        )
        if not (allow_404 and response.status_code == 404):
            self._raise_for_status(response, method=method, endpoint=endpoint)
        return response

    def _send(
        self,
        method: RequestMethod,
        endpoint: str,
        *,
        compatibility_fallback: CompatibilityFallback | None,
        correlation_id: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Issue one HTTP request with correlation headers attached.

        This is the only place that talks directly to ``httpx.Client`` for
        ordinary request dispatch. The optional JSON-to-form retry is kept here
        because it is a transport compatibility concern, but it remains
        visible and opt-in through the ``compatibility_fallback`` argument
        passed down from the domain call site.

        Args:
            method: HTTP verb to send upstream.
            endpoint: Relative MREG endpoint path.
            compatibility_fallback: Explicit legacy write fallback mode.
            correlation_id: Correlation id already resolved for the logical
                operation.
            **kwargs: Forwarded request arguments for ``httpx.Client``.

        Returns:
            The upstream response, or the fallback response when the explicit
            form retry path was used.

        Raises:
            RequestFailedError: The underlying HTTP client failed before an
                upstream response was received.
        """
        headers = self._request_headers(correlation_id)
        response = self._send_raw_request(
            method,
            endpoint,
            headers=headers,
            correlation_id=correlation_id,
            **kwargs,
        )

        if compatibility_fallback == CompatibilityFallback.FORM and self._should_retry_as_form(
            response,
            kwargs,
        ):
            form_kwargs = dict(kwargs)
            form_kwargs["data"] = form_kwargs.pop("json")
            return self._send_raw_request(
                method,
                endpoint,
                headers=headers,
                correlation_id=correlation_id,
                **form_kwargs,
            )
        return response

    def _send_raw_request(
        self,
        method: RequestMethod,
        endpoint: str,
        *,
        headers: dict[str, str],
        correlation_id: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Send one raw HTTP request and normalize client-side transport failures.

        The compatibility fallback path must preserve the same error contract as
        the initial attempt. Centralizing the ``httpx`` call here prevents the
        retry path from leaking raw ``httpx.HTTPError`` exceptions back to
        callers.
        """
        try:
            return self._client.request(
                method,
                endpoint,
                headers=headers,
                **kwargs,
            )
        except httpx.HTTPError as exc:
            raise RequestFailedError(
                f"MREG request failed for {endpoint}",
                method=method,
                endpoint=endpoint,
                correlation_id=correlation_id,
            ) from exc

    def _ensure_token(self, *, correlation_id: str | None) -> bool:
        """Ensure a usable token is installed before request dispatch.

        Token lookup order is deliberate: keep an already-active token if one
        exists, then try the configured token store, and only then fall back to
        an authentication flow. That keeps ordinary request paths cheap while
        still allowing interactive or credential-based recovery when needed.

        Returns:
            ``True`` when this call had to obtain a fresh token through login,
            otherwise ``False``.
        """
        if self._token:
            return False

        stored = self._token_store.load_token(
            base_url=self._base_url,
            username=self.username,
        )
        if stored:
            self._set_token(stored)
            return False

        self._login(force_prompt=self._interactive, correlation_id=correlation_id)
        return True

    def _login(self, *, force_prompt: bool, correlation_id: str | None) -> None:
        """Authenticate and install a fresh token on the client.

        The prompt hook sits exactly at this auth edge. Domain modules never
        ask users for credentials themselves; they just trigger client
        operations and let the transport boundary decide whether a prompt is
        permitted and necessary. Prompted credentials are cached on the client
        instance so a single interactive session does not keep asking for the
        same username and password.

        Args:
            force_prompt: Whether the client is allowed to collect missing
                credentials interactively for this login attempt.
            correlation_id: Correlation id for the surrounding logical
                operation.

        Raises:
            AuthenticationRequiredError: No credentials were available and
                prompting was not allowed or did not supply any.
            AuthenticationFailedError: Upstream login rejected the supplied
                credentials.
        """
        credentials = self._credentials
        if credentials is None and force_prompt:
            credentials = self._credential_prompt(
                base_url=self._base_url,
                username=self.username,
            )
            self._credentials = credentials

        if credentials is None:
            raise AuthenticationRequiredError(
                "No MREG token or credentials are available for this request",
                correlation_id=correlation_id,
            )

        token = login_for_token(
            self._client,
            credentials=credentials,
            correlation_id=correlation_id,
        )
        self._set_token(token)

    def _set_token(self, token: str) -> None:
        """Install a fresh token in memory and in the configured store."""
        self._token = token
        self._token_store.save_token(
            base_url=self._base_url,
            username=self.username,
            token=token,
        )

    def _clear_token(self) -> None:
        """Forget the active token both locally and in the configured store."""
        self._token = None
        self._token_store.clear_token(
            base_url=self._base_url,
            username=self.username,
        )

    def _decode_json(
        self,
        response: httpx.Response,
        *,
        method: RequestMethod,
        soft_404: bool,
        allow_empty: bool,
        endpoint: str,
    ) -> dict[str, Any] | list[Any] | None:
        """Decode a successful response into a JSON object or list.

        The regular domain helpers are intentionally opinionated: success
        bodies must decode into either a mapping or a sequence so endpoint
        modules can rely on stable container shapes. Invalid JSON, missing
        bodies where JSON was expected, and successful scalar payloads are all
        treated as transport-contract violations and mapped to
        ``ResponseDecodeError``.

        Args:
            response: Upstream response that has already passed status
                validation or a permitted soft-404 path.
            method: HTTP method used for the request.
            soft_404: Whether ``404`` should be converted into an empty result.
            allow_empty: Whether empty success responses are permitted.
            endpoint: Relative endpoint path used for error metadata.

        Returns:
            Decoded JSON object or list, or ``None`` when empty responses are
            explicitly allowed.

        Raises:
            ResponseDecodeError: Response body was missing or malformed for the
                expected contract.
        """
        if soft_404 and response.status_code == 404:
            return None
        if response.status_code == 204:
            if allow_empty:
                return None
            raise ResponseDecodeError(
                "MREG returned 204 No Content where a JSON body was required",
                **self._response_metadata(response, method=method, endpoint=endpoint),
            )
        if allow_empty and not response.content:
            return None
        try:
            payload = response.json()
        except ValueError as exc:
            raise ResponseDecodeError(
                "MREG returned an invalid JSON response",
                **self._response_metadata(response, method=method, endpoint=endpoint),
            ) from exc
        if isinstance(payload, dict | list):
            return payload
        raise ResponseDecodeError(
            "MREG returned an unexpected JSON shape",
            **self._response_metadata(response, method=method, endpoint=endpoint),
        )

    def _decode_json_value(
        self,
        response: httpx.Response,
        *,
        method: RequestMethod,
        endpoint: str,
        soft_404: bool,
    ) -> object | None:
        """Decode any valid JSON value for scalar-style endpoints.

        This is the permissive sibling to ``_decode_json``. It exists for the
        few endpoints where MREG legitimately returns a string, number, or
        other scalar on success.
        """
        if soft_404 and response.status_code == 404:
            return None
        if response.status_code == 204:
            return None
        try:
            return response.json()
        except ValueError as exc:
            raise ResponseDecodeError(
                "MREG returned an invalid JSON response",
                **self._response_metadata(response, method=method, endpoint=endpoint),
            ) from exc

    def _raise_for_status(
        self,
        response: httpx.Response,
        *,
        method: RequestMethod,
        endpoint: str,
    ) -> None:
        """Translate upstream HTTP status codes into stable local exceptions.

        The goal is not to preserve every upstream nuance. It is to give
        callers a small exception taxonomy they can catch consistently across
        the library while still attaching request metadata that is useful for
        debugging and tracing.

        Raises:
            AuthenticationRequiredError: Upstream rejected the request as
                unauthenticated.
            ForbiddenError: Upstream denied an authenticated caller.
            NotFoundError: Upstream object was missing and the caller did not
                opt into soft-404 handling.
            ConflictError: Upstream detected a conflicting state.
            ValidationError: Upstream rejected the payload as invalid.
            RequestFailedError: Any other non-success HTTP status.
        """
        if response.status_code < 400:
            return

        message = f"MREG request failed with status {response.status_code}"
        metadata = self._response_metadata(response, method=method, endpoint=endpoint)
        if response.status_code == 401:
            raise AuthenticationRequiredError(
                "MREG request was rejected as unauthenticated",
                **metadata,
            )
        if response.status_code == 403:
            raise ForbiddenError(message, **metadata)
        if response.status_code == 404:
            raise NotFoundError(message, **metadata)
        if response.status_code == 409:
            raise ConflictError(message, **metadata)
        if response.status_code == 422:
            raise ValidationError(message, source=ValidationSource.REMOTE, **metadata)
        raise RequestFailedError(message, **metadata)

    def _response_metadata(
        self,
        response: httpx.Response,
        *,
        method: RequestMethod,
        endpoint: str,
    ) -> ResponseMetadata:
        """Collect stable metadata copied from one upstream response.

        Exception instances attach this structure so logs and callers can tie a
        failure back to one endpoint, one method, and one pair of upstream
        request/correlation identifiers when MREG provided them.
        """
        return {
            "method": method,
            "status_code": response.status_code,
            "endpoint": endpoint,
            "request_id": response.headers.get("X-Request-Id"),
            "correlation_id": response.headers.get("X-Correlation-ID"),
        }

    def _should_retry_as_form(self, response: httpx.Response, kwargs: dict[str, Any]) -> bool:
        """Return whether explicit legacy form fallback should be attempted.

        The fallback is intentionally conservative: only retry after an
        upstream server failure and only when the original request actually had
        a JSON body that can be converted into form data.
        """
        return response.status_code == 500 and "json" in kwargs and kwargs["json"] is not None

    def _request_headers(self, correlation_id: str) -> dict[str, str]:
        """Build per-request headers from the current transport state."""
        headers = {"X-Correlation-ID": correlation_id}
        if self._token is not None:
            headers["Authorization"] = f"Token {self._token}"
        return headers

    def _default_user_agent(self) -> str:
        """Return the default user-agent used for library-originated requests."""
        return f"osp-uio-integrations/{__version__} mreg-client"

    def _resolve_correlation_id(
        self,
        *,
        correlation_id: str | None,
        method: RequestMethod,
        endpoint: str,
    ) -> str:
        """Resolve the correlation id for one logical client operation.

        The precedence is caller override, then client default, then a generated
        value derived from the request shape. Reusing the same resolved value
        across an auth retry keeps one public library call traceable as one
        operation in upstream logs.

        Args:
            correlation_id: Explicit operation id supplied by the caller.
            method: HTTP verb that will be used if a generated id is needed.
            endpoint: Endpoint path used to make generated ids easier to read.

        Returns:
            The correlation id that should be reused for every request attempt
            belonging to the same logical operation.
        """
        if correlation_id:
            return correlation_id
        if self._default_correlation_id:
            return self._default_correlation_id
        suffix = re.sub(r"[^a-z0-9]+", "_", f"{method}_{endpoint}".lower()).strip("_")
        if not suffix:
            suffix = "mreg"
        return f"{uuid4()}-{suffix}"


class ResponseMetadata(TypedDict):
    """Typed request metadata copied from an upstream response."""

    method: RequestMethod
    status_code: int
    endpoint: str
    request_id: str | None
    correlation_id: str | None
