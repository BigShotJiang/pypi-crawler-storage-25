"""Stable exception taxonomy for the MREG client.

This module owns the small set of exception types that callers are expected to
handle across transport, validation, decode, and mutation workflows.

It intentionally does not mirror every upstream MREG failure mode one-for-one.
The goal is a boring local contract with enough request metadata attached to be
operable in logs and calling code.
"""

from __future__ import annotations

from dataclasses import dataclass

from .enums import RequestMethod, ValidationSource


class MregError(Exception):
    """Base exception for MREG client failures."""


class RequestFailedError(MregError):
    """Raised when MREG or the network fails a request.

    Transport-level failures that happen before an upstream response exists do
    not carry ``status_code`` or ``request_id`` metadata. Callers should treat
    those fields as optional even though response-backed failures populate
    them.
    """

    def __init__(
        self,
        message: str,
        *,
        method: RequestMethod | None = None,
        status_code: int | None = None,
        endpoint: str | None = None,
        request_id: str | None = None,
        correlation_id: str | None = None,
    ) -> None:
        """Store stable upstream request metadata alongside the error."""
        super().__init__(message)
        self.method = method
        self.status_code = status_code
        self.endpoint = endpoint
        self.request_id = request_id
        self.correlation_id = correlation_id


@dataclass(frozen=True, slots=True)
class MutationStep:
    """One small programmatic step in a multi-part mutation workflow.

    ``name`` stays stable enough for programmatic inspection, while ``detail``
    can carry a compact endpoint- or record-specific identifier when needed.
    """

    name: str
    detail: str | None = None


class MutationStateUncertainError(MregError):
    """Raised when a write may have partially applied upstream.

    This exception intentionally does not inherit from ``RequestFailedError``.
    Callers should not accidentally swallow uncertain-state failures in broad
    handlers that currently mean "ordinary request failure".
    """

    def __init__(
        self,
        message: str,
        *,
        operation: str,
        completed_steps: tuple[MutationStep, ...] = (),
        remaining_steps: tuple[MutationStep, ...] = (),
        method: RequestMethod | None = None,
        status_code: int | None = None,
        endpoint: str | None = None,
        request_id: str | None = None,
        correlation_id: str | None = None,
    ) -> None:
        """Store mutation context alongside the uncertain-state message.

        The extra metadata mirrors the request-facing error types closely so
        callers can log or present the same transport context even though this
        exception is deliberately not part of the ``RequestFailedError``
        subclass chain.
        """
        super().__init__(message)
        self.operation = operation
        self.completed_steps = completed_steps
        self.remaining_steps = remaining_steps
        self.method = method
        self.status_code = status_code
        self.endpoint = endpoint
        self.request_id = request_id
        self.correlation_id = correlation_id


class AuthenticationRequiredError(RequestFailedError):
    """Raised when a request needs credentials or a token and none are available."""


class AuthenticationFailedError(RequestFailedError):
    """Raised when MREG rejects a login attempt or refreshed credentials fail."""


class ForbiddenError(RequestFailedError):
    """Raised when MREG denies access to a valid authenticated caller."""


class NotFoundError(RequestFailedError):
    """Raised when a requested MREG object does not exist."""


class ConflictError(RequestFailedError):
    """Raised when MREG reports a resource conflict."""


class ValidationError(RequestFailedError):
    """Raised when MREG rejects a request payload as invalid."""

    def __init__(
        self,
        message: str,
        *,
        source: ValidationSource,
        method: RequestMethod | None = None,
        status_code: int | None = None,
        endpoint: str | None = None,
        request_id: str | None = None,
        correlation_id: str | None = None,
    ) -> None:
        """Store whether the validation failure came from local or remote checks."""
        super().__init__(
            message,
            method=method,
            status_code=status_code,
            endpoint=endpoint,
            request_id=request_id,
            correlation_id=correlation_id,
        )
        self.source = source


class ResponseDecodeError(RequestFailedError):
    """Raised when MREG returns a response body the client cannot decode."""
