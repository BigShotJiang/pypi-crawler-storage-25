"""Network-oriented MREG API surface.

Public exports:

- `NetworksAPI` as the composed network entrypoint hanging off `MregClient`
- stable network and VLAN-usage models for callers that want typed results
  without importing implementation modules directly

Other modules under `osp_uio_integrations.mreg.networks` are internal
implementation details. Callers should prefer `client.networks` plus the
re-exported models here over reaching into implementation files directly.
"""

from .api import NetworksAPI
from .models import NetworkRecord, NetworkUsageRecord, VlanUsageRecord

__all__ = [
    "NetworkRecord",
    "NetworkUsageRecord",
    "NetworksAPI",
    "VlanUsageRecord",
]
