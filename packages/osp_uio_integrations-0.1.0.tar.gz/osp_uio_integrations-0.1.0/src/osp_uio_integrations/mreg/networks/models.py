"""Stable network models for MREG.

These models are the library's public return shapes for the network domain.
They are deliberately I/O-free dataclasses: nothing here calls MREG, and
nothing here decides endpoint semantics on the fly. Payload interpretation
lives next to the endpoint code that fetched it.

Each record carries a ``raw`` dictionary holding the original upstream
payload for callers that need fields the stable shape does not expose. The
top-level fields are the contract; ``raw`` is an escape hatch and may
change shape upstream without library changes.
"""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass
from typing import Any

from ..enums import AddressFamily


@dataclass(frozen=True, slots=True)
class NetworkRecord:
    """Stable network shape returned by `NetworksAPI` reads.

    Attributes:
        id: Numeric MREG network id when present.
        network: Canonical CIDR string for the network.
        vlan: Numeric VLAN identifier when MREG provided one.
        gateway: Canonical gateway IP string when present.
        prefixlen: Prefix length derived from the CIDR when not sent explicitly.
        frozen: Whether MREG reports the network as frozen for writes.
        network_address: Canonical network address derived from `network`.
        broadcast_address: Canonical IPv4 broadcast address, otherwise `None`.
        raw: Original upstream payload dictionary.
    """

    id: int | None
    network: str
    vlan: int | None
    gateway: str | None
    prefixlen: int
    frozen: bool
    network_address: str
    broadcast_address: str | None
    raw: dict[str, Any]

    @property
    def family(self) -> AddressFamily:
        """Return the address family derived from the parsed CIDR."""
        parsed = ipaddress.ip_network(self.network, strict=False)
        if parsed.version == 4:
            return AddressFamily.IPV4
        return AddressFamily.IPV6


@dataclass(frozen=True, slots=True)
class NetworkUsageRecord:
    """Usage summary for one IPv4 network inside a VLAN fullness calculation."""

    cidr: str
    capacity: int
    used: int
    unused: int
    percent_used: float


@dataclass(frozen=True, slots=True)
class VlanUsageRecord:
    """Aggregated IPv4 usage summary for every network on one VLAN."""

    vlan: int
    capacity: int
    used: int
    unused: int
    percent_used: float
    networks: tuple[NetworkUsageRecord, ...]
