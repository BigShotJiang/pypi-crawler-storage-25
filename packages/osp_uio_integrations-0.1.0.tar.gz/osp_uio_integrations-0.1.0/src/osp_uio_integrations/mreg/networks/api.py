"""Read and selection helpers for MREG networks.

This module owns the network-domain surface needed by the current OSP
consumers: network lookup, paginated network listing, free-address discovery,
and a few small client-side selection helpers that MREG does not expose
directly.

It does not own provider policy. Callers still decide when to allocate from a
VLAN, whether an address family is required, and what to do when MREG cannot
offer a candidate address.
"""

from __future__ import annotations

import ipaddress
import random
from collections.abc import Sequence
from typing import Any, cast
from urllib.parse import quote

from ..enums import AddressFamily, RequestMethod, ValidationSource
from ..exceptions import NotFoundError, RequestFailedError, ResponseDecodeError, ValidationError
from .models import NetworkRecord, NetworkUsageRecord, VlanUsageRecord


class NetworksAPI:
    """Public network facade for reads, free-address lookups, and VLAN helpers."""

    def __init__(self, client: Any) -> None:
        """Initialize the network facade."""
        self._client = client

    def get(self, network: str, *, correlation_id: str | None = None) -> NetworkRecord | None:
        """Return one normalized network record by CIDR."""
        endpoint = _network_endpoint(network)
        data = self._client.get_json(
            endpoint,
            soft_404=True,
            correlation_id=correlation_id,
        )
        if not data:
            return None
        return parse_network_payload(data, endpoint=endpoint)

    def get_required(self, network: str, *, correlation_id: str | None = None) -> NetworkRecord:
        """Return one network record and promote absence into `NotFoundError`."""
        record = self.get(network, correlation_id=correlation_id)
        if record is None:
            raise NotFoundError(
                f"Network {network!r} was not found",
                method=RequestMethod.GET,
                status_code=404,
                endpoint=_network_endpoint(network),
                correlation_id=correlation_id,
            )
        return record

    def get_by_ip(
        self,
        ipaddress_value: str,
        *,
        correlation_id: str | None = None,
    ) -> NetworkRecord | None:
        """Return the network currently owning one IP address, when any."""
        endpoint = f"/api/v1/networks/ip/{ipaddress_value}"
        data = self._client.get_json(
            endpoint,
            soft_404=True,
            correlation_id=correlation_id,
        )
        if not data:
            return None
        return parse_network_payload(data, endpoint=endpoint)

    def many(
        self,
        *,
        params: dict[str, object] | None = None,
        correlation_id: str | None = None,
    ) -> list[NetworkRecord]:
        """Return normalized network records from the network listing endpoint."""
        endpoint = "/api/v1/networks/"
        return [
            parse_network_payload(item, endpoint=endpoint)
            for item in self._client.get_json_collection(
                endpoint,
                params=params,
                correlation_id=correlation_id,
            )
        ]

    def first_unused(self, network: str, *, correlation_id: str | None = None) -> str | None:
        """Return the first unused address in one network when MREG can provide it."""
        return self._client.get_json_str(
            f"{_network_endpoint(network)}/first_unused",
            soft_404=True,
            correlation_id=correlation_id,
        )

    def random_unused(self, network: str, *, correlation_id: str | None = None) -> str | None:
        """Return one random unused address in one network when MREG can provide it."""
        return self._client.get_json_str(
            f"{_network_endpoint(network)}/random_unused",
            soft_404=True,
            correlation_id=correlation_id,
        )

    def unused_list(self, network: str, *, correlation_id: str | None = None) -> tuple[str, ...]:
        """Return rendered entries from MREG's `unused_list` endpoint."""
        return self._render_collection(
            f"{_network_endpoint(network)}/unused_list",
            correlation_id=correlation_id,
        )

    def used_host_list(self, network: str, *, correlation_id: str | None = None) -> tuple[str, ...]:
        """Return rendered entries from MREG's `used_host_list` endpoint."""
        endpoint = f"{_network_endpoint(network)}/used_host_list"
        data = self._client.get_json(
            endpoint,
            correlation_id=correlation_id,
        )
        return _render_used_host_collection(data, endpoint=endpoint)

    def pick_unused_in_network(
        self,
        network: str,
        *,
        address_pick: str = "random",
        correlation_id: str | None = None,
    ) -> str | None:
        """Return one unused address from a network using an explicit strategy."""
        pick = _normalize_strategy(
            address_pick,
            allowed={"random", "first", "last"},
            endpoint=_network_endpoint(network),
        )
        if pick == "random":
            return self.random_unused(network, correlation_id=correlation_id)
        if pick == "first":
            return self.first_unused(network, correlation_id=correlation_id)
        return self._last_unused(network, correlation_id=correlation_id)

    def pick_unused_in_vlan(
        self,
        vlan: int,
        *,
        family: AddressFamily | str | int,
        network_pick: str = "largest",
        address_pick: str = "random",
        correlation_id: str | None = None,
    ) -> tuple[NetworkRecord, str] | None:
        """Return one `(network, ip)` candidate from a VLAN when available."""
        requested_family = _normalize_family(
            family,
            endpoint="/api/v1/networks/",
        )
        network_strategy = _normalize_strategy(
            network_pick,
            allowed={"first", "last", "random", "largest", "most"},
            endpoint="/api/v1/networks/",
        )

        networks = [
            record
            for record in self.many(
                params={"vlan": vlan},
                correlation_id=correlation_id,
            )
            if record.family == requested_family
        ]
        if not networks:
            return None

        ordered = list(networks)
        if network_strategy == "random":
            random.shuffle(ordered)
        elif network_strategy == "last":
            ordered.reverse()
        elif network_strategy in {"largest", "most"}:
            ordered.sort(
                key=lambda record: int(
                    ipaddress.ip_network(record.network, strict=False).num_addresses
                ),
                reverse=True,
            )

        for record in ordered:
            address = self.pick_unused_in_network(
                record.network,
                address_pick=address_pick,
                correlation_id=correlation_id,
            )
            if address:
                return record, address
        return None

    def vlan_fullness_ipv4(
        self,
        vlan: int,
        *,
        exclude_reserved: bool = True,
        correlation_id: str | None = None,
    ) -> VlanUsageRecord:
        """Return an IPv4 capacity summary for every network on one VLAN."""
        summaries: list[NetworkUsageRecord] = []
        total_capacity = 0
        total_unused = 0

        for network in self.many(params={"vlan": vlan}, correlation_id=correlation_id):
            if network.family != AddressFamily.IPV4:
                continue
            parsed = ipaddress.ip_network(network.network, strict=False)
            capacity = _ipv4_capacity(
                cast(ipaddress.IPv4Network, parsed),
                exclude_reserved=exclude_reserved,
            )
            unused = self._estimate_unused(
                network.network,
                capacity=capacity,
                correlation_id=correlation_id,
            )
            used = max(0, capacity - unused)
            percent_used = 0.0 if capacity == 0 else round((used / capacity) * 100.0, 2)

            total_capacity += capacity
            total_unused += unused
            summaries.append(
                NetworkUsageRecord(
                    cidr=network.network,
                    capacity=capacity,
                    used=used,
                    unused=unused,
                    percent_used=percent_used,
                )
            )

        total_used = total_capacity - total_unused
        total_percent = (
            0.0
            if total_capacity == 0
            else round((total_used / total_capacity) * 100.0, 2)
        )
        return VlanUsageRecord(
            vlan=vlan,
            capacity=total_capacity,
            used=total_used,
            unused=total_unused,
            percent_used=total_percent,
            networks=tuple(summaries),
        )

    def _estimate_unused(
        self,
        network: str,
        *,
        capacity: int,
        correlation_id: str | None,
    ) -> int:
        """Estimate remaining IPv4 capacity from the lighter list endpoints first."""
        try:
            used = self.used_host_list(network, correlation_id=correlation_id)
            return max(0, capacity - len(used))
        except RequestFailedError:
            try:
                return len(self.unused_list(network, correlation_id=correlation_id))
            except RequestFailedError:
                return 0

    def _last_unused(self, network: str, *, correlation_id: str | None = None) -> str | None:
        """Compute the last unused host address when MREG has no dedicated endpoint."""
        record = self.get_required(network, correlation_id=correlation_id)
        parsed = ipaddress.ip_network(record.network, strict=False)
        first_int, last_int = _usable_bounds(parsed)
        if last_int < first_int:
            return None

        used = sorted(
            int(address)
            for address in self._used_ip_addresses(
                record.network,
                resolve_hostnames=True,
                correlation_id=correlation_id,
            )
            if address in parsed and first_int <= int(address) <= last_int
        )
        if not used:
            return str(ipaddress.ip_address(last_int))
        if used[-1] < last_int:
            return str(ipaddress.ip_address(last_int))

        index = len(used) - 1
        while index > 0 and used[index - 1] == used[index] - 1:
            index -= 1
        candidate = used[index] - 1
        if candidate < first_int:
            return None
        return str(ipaddress.ip_address(candidate))

    def _used_ip_addresses(
        self,
        network: str,
        *,
        resolve_hostnames: bool,
        correlation_id: str | None,
    ) -> set[ipaddress.IPv4Address | ipaddress.IPv6Address]:
        """Resolve the concrete used IPs MREG reports for one network."""
        identifiers = self.used_host_list(network, correlation_id=correlation_id)
        used: set[ipaddress.IPv4Address | ipaddress.IPv6Address] = set()
        hostnames: list[str] = []

        for identifier in identifiers:
            try:
                used.add(ipaddress.ip_address(identifier))
            except ValueError:
                hostnames.append(identifier)

        if used and (not resolve_hostnames or not hostnames):
            return used
        if not resolve_hostnames:
            return used
        if len(hostnames) > 200:
            raise RequestFailedError(
                "used_host_list returned too many non-IP identifiers to resolve safely",
                method=RequestMethod.GET,
                endpoint=f"{_network_endpoint(network)}/used_host_list",
                correlation_id=correlation_id,
            )

        for hostname in hostnames:
            host = self._client.hosts.queries.get(hostname, correlation_id=correlation_id)
            if host is None:
                continue
            for ipaddress_value in host.ipaddresses:
                try:
                    used.add(ipaddress.ip_address(ipaddress_value))
                except ValueError:
                    continue
        return used

    def _render_collection(
        self,
        endpoint: str,
        *,
        correlation_id: str | None,
    ) -> tuple[str, ...]:
        """Normalize list-style endpoint entries into stable string identifiers."""
        rendered: list[str] = []
        seen: set[str] = set()

        for item in self._client.get_json_collection(endpoint, correlation_id=correlation_id):
            for value in _render_collection_item(item):
                if value in seen:
                    continue
                seen.add(value)
                rendered.append(value)
        return tuple(rendered)


def parse_network_payload(payload: object, *, endpoint: str) -> NetworkRecord:
    """Interpret one upstream network payload into the stable library shape."""
    if not isinstance(payload, dict):
        raise ResponseDecodeError(
            "MREG network payload was not a JSON object",
            method=RequestMethod.GET,
            endpoint=endpoint,
        )
    payload_dict = cast(dict[str, Any], payload)

    network_value = payload_dict.get("network")
    if not isinstance(network_value, str) or not network_value.strip():
        raise ResponseDecodeError(
            "MREG network payload did not include a network value",
            method=RequestMethod.GET,
            endpoint=endpoint,
        )
    try:
        parsed = ipaddress.ip_network(network_value.strip(), strict=False)
    except ValueError as exc:
        raise ResponseDecodeError(
            "MREG network payload did not include a valid network value",
            method=RequestMethod.GET,
            endpoint=endpoint,
        ) from exc

    gateway = _optional_ip_string(payload_dict.get("gateway"))
    prefixlen = _optional_int(payload_dict.get("prefixlen"))
    return NetworkRecord(
        id=_optional_int(payload_dict.get("id")),
        network=str(parsed),
        vlan=_optional_int(payload_dict.get("vlan")),
        gateway=gateway,
        prefixlen=prefixlen if prefixlen is not None else parsed.prefixlen,
        frozen=bool(payload_dict.get("frozen")),
        network_address=str(parsed.network_address),
        broadcast_address=str(parsed.broadcast_address) if parsed.version == 4 else None,
        raw=dict(payload_dict),
    )


def _network_endpoint(network: str) -> str:
    return f"/api/v1/networks/{quote(network, safe='')}"


def _optional_int(value: object) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.strip():
        try:
            return int(value.strip())
        except ValueError:
            return None
    return None


def _optional_ip_string(value: object) -> str | None:
    if value is None:
        return None
    try:
        return str(ipaddress.ip_address(str(value)))
    except ValueError:
        return None


def _render_collection_item(item: object) -> list[str]:
    rendered: list[str] = []
    if isinstance(item, str) and item.strip():
        return [item.strip()]
    if isinstance(item, dict):
        payload = cast(dict[str, Any], item)
        for key in ("ipaddress", "ip", "ipv4", "ipv6", "address", "hostname", "host", "name"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                rendered.append(value.strip())
        nested = payload.get("ipaddresses")
        if isinstance(nested, list):
            for subitem in nested:
                rendered.extend(_render_collection_item(subitem))
        return rendered
    if isinstance(item, list):
        for subitem in item:
            rendered.extend(_render_collection_item(subitem))
    return rendered


def _render_used_host_collection(data: object, *, endpoint: str) -> tuple[str, ...]:
    """Normalize `used_host_list` responses into one identifier per used slot."""
    if isinstance(data, dict):
        payload = cast(dict[str, Any], data)
        results = payload.get("results")
        if isinstance(results, list):
            return _dedupe_rendered_values(results)
        return tuple(
            key.strip()
            for key in payload
            if isinstance(key, str) and key.strip()
        )
    if isinstance(data, list):
        return _dedupe_rendered_values(data)
    raise ResponseDecodeError(
        "MREG used_host_list response did not match a supported JSON shape",
        method=RequestMethod.GET,
        endpoint=endpoint,
    )


def _dedupe_rendered_values(items: Sequence[object]) -> tuple[str, ...]:
    """Render heterogeneous collection items into a stable deduplicated tuple."""
    rendered: list[str] = []
    seen: set[str] = set()
    for item in items:
        for value in _render_collection_item(item):
            if value in seen:
                continue
            seen.add(value)
            rendered.append(value)
    return tuple(rendered)


def _normalize_strategy(value: str, *, allowed: set[str], endpoint: str) -> str:
    normalized = value.strip().lower()
    if normalized in allowed:
        return normalized
    raise ValidationError(
        f"Invalid selection strategy {value!r}; expected one of {sorted(allowed)}",
        source=ValidationSource.LOCAL,
        method=RequestMethod.GET,
        endpoint=endpoint,
    )


def _normalize_family(value: AddressFamily | str | int, *, endpoint: str) -> AddressFamily:
    if isinstance(value, AddressFamily):
        return value
    if value in (4, "4", "ipv4", "IPV4"):
        return AddressFamily.IPV4
    if value in (6, "6", "ipv6", "IPV6"):
        return AddressFamily.IPV6
    raise ValidationError(
        f"Invalid address family {value!r}; expected ipv4/4 or ipv6/6",
        source=ValidationSource.LOCAL,
        method=RequestMethod.GET,
        endpoint=endpoint,
    )


def _ipv4_capacity(net: ipaddress.IPv4Network, *, exclude_reserved: bool) -> int:
    if not exclude_reserved:
        return int(net.num_addresses)
    if net.prefixlen == 31:
        return 2
    if net.prefixlen == 32:
        return 1
    return max(0, int(net.num_addresses) - 2)


def _usable_bounds(
    network: ipaddress.IPv4Network | ipaddress.IPv6Network,
) -> tuple[int, int]:
    if isinstance(network, ipaddress.IPv4Network):
        if network.prefixlen == 32:
            value = int(network.network_address)
            return value, value
        if network.prefixlen == 31:
            start = int(network.network_address)
            return start, start + 1
        return int(network.network_address) + 1, int(network.broadcast_address) - 1

    if int(network.num_addresses) <= 1:
        value = int(network.network_address)
        return value, value
    return (
        int(network.network_address) + 1,
        int(network.network_address) + int(network.num_addresses) - 1,
    )
