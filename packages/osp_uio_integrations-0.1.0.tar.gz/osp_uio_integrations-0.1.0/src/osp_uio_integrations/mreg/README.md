# mreg — Package Guide

The `osp_uio_integrations.mreg` package is a small synchronous Python client
for UiO's MREG API. It owns transport, token-backed authentication, request
metadata, light response normalization, and the explicit host/record APIs
exposed through `MregClient`.

It does not try to be a generic MREG framework, and it does not own provider
workflow, orchestration policy, or CLI rendering concerns. The package exists
to give other Python code a boring importable library surface for common MREG
operations.

## What Lives Here

- `client.py` — HTTP transport boundary, token handling, one-shot `401`
  retry, request metadata, compatibility fallback for legacy writes
- `auth/` — login and token helpers
- `exceptions.py` — stable exception taxonomy used across transport and domain
  operations
- `hosts/` — explicit host-facing API surface exposed as `client.hosts`

## Public Surface

Most callers should import from `osp_uio_integrations.mreg`, not from
individual implementation modules.

Primary entrypoints:

- `MregClient`
- `client.hosts`
- `client.hosts.records`

Stable supporting types:

- enums such as `AddressFamily`, `SshfpAlgorithm`, `SshfpHashType`
- exception types such as `RequestFailedError`, `ValidationError`,
  `MutationStateUncertainError`
- stable return-shape models re-exported from
  `osp_uio_integrations.mreg.hosts` and
  `osp_uio_integrations.mreg.hosts.records`

Example:

```python
from osp_uio_integrations.mreg import MregClient, MutationStateUncertainError

client = MregClient(base_url="https://mreg.example.test", token="token")

try:
    host = client.hosts.queries.get("example.uio.no")
    record = client.hosts.records.ptr.add("example.uio.no", "192.0.2.10")
finally:
    client.close()
```

## Package Shape

The package is deliberately explicit rather than generic.

```text
mreg/
  client.py          transport + auth + request/response contract
  exceptions.py      stable error taxonomy
  auth/              login and token helpers
  hosts/             host composition root and host sub-APIs
    queries.py       host lookup + payload interpretation
    lifecycle.py     create/delete
    addressing.py    A/AAAA add/change/move/remove
    contacts.py      host contact mutations
    cnames.py        alias workflows
    history.py       host history lookups
    records/         host-owned RR modules under client.hosts.records
```

The important ownership rule is that `client.py` owns transport behavior,
while `hosts/` owns endpoint-aware MREG business rules for the host domain.
Models stay small data shapes; they do not perform I/O themselves.

## Error Model

The package uses a narrow exception taxonomy rather than exposing
raw `httpx` or upstream-specific failures directly.

- `RequestFailedError` means the request failed in the ordinary sense:
  transport failure, non-success HTTP status, or another request-backed
  problem where the library is not claiming partial mutation state
- `ValidationError` means the library or MREG rejected the payload as invalid
- `ResponseDecodeError` means MREG returned a success response the client
  could not interpret into the promised shape
- `MutationStateUncertainError` means a write likely reached MREG, but the
  client could not safely confirm the resulting state

That last exception is the important one for callers doing write workflows.
MREG is not transactional. When a write succeeds upstream and follow-up
verification fails, the library reports uncertainty explicitly instead of
pretending it knows that nothing changed.

For multi-step workflows such as address move or bulk record deletion,
`MutationStateUncertainError` may include `completed_steps` and
`remaining_steps` so callers can log what probably happened.

## Design Boundaries

The package does:

- normalize request metadata such as `User-Agent` and `X-Correlation-ID`
- keep a stable exception contract
- port concrete host and RR workflows from `mreg-cli` into library-shaped
  modules
- add cheap local validations that clearly pay off

The package does not:

- implement transactional writes
- implement rollback or retry frameworks
- build a generic resource abstraction over all of MREG
- duplicate all upstream semantic validation locally
- own CLI prompts outside the optional auth prompt hook

When in doubt, prefer explicit module-local logic over shared helper
machinery.

## Read Next

- [__init__.py](__init__.py) — public import surface
- [client.py](client.py) — transport contract
- [hosts/__init__.py](hosts/__init__.py) — host-facing import surface
- [hosts/records/__init__.py](hosts/records/__init__.py) — RR-facing import
  surface
- [docs/mreg-host-library-plan.md](../../../docs/mreg-host-library-plan.md) —
  architectural background
