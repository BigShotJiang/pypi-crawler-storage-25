"""String enums for stable MREG client mode values."""

from __future__ import annotations

from enum import IntEnum, StrEnum


class RequestMethod(StrEnum):
    """Supported HTTP methods used by the MREG client."""

    GET = "GET"
    POST = "POST"
    PATCH = "PATCH"
    DELETE = "DELETE"


class CompatibilityFallback(StrEnum):
    """Explicit compatibility fallback modes for legacy MREG endpoints."""

    FORM = "form"


class ValidationSource(StrEnum):
    """Origin of a validation failure exposed by the library."""

    LOCAL = "local"
    REMOTE = "remote"


class AddressFamily(StrEnum):
    """Supported IP address families for host addressing operations."""

    IPV4 = "ipv4"
    IPV6 = "ipv6"


class SshfpAlgorithm(IntEnum):
    """Well-known SSHFP algorithm values."""

    RSA = 1
    DSA = 2
    ECDSA = 3
    ED25519 = 4
    ED448 = 6


class SshfpHashType(IntEnum):
    """Well-known SSHFP hash type values."""

    SHA1 = 1
    SHA256 = 2
