"""Explicit TTL operations for host and SRV records.

The CLI exposes TTL mutation through one stringly-targeted command that first
tries host lookup and then falls back to SRV lookup. This library keeps the
same capability but makes the resource boundary explicit: callers choose
whether they are mutating a host TTL or an SRV TTL.

That tradeoff is deliberate. It removes ambiguous lookup behavior from the
library surface while keeping the operational rules, validation, and
write-then-verify behavior in one dedicated module.
"""

from __future__ import annotations

from typing import Any

from ...enums import RequestMethod, ValidationSource
from ...exceptions import (
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
)
from ..models import HostRecord
from ..queries import HostQueries
from .models import SrvRecord
from .srv import HostSrvAPI

MIN_TTL = 300
MAX_TTL = 68400


class HostTtlAPI:
    """Operations for managing explicit TTL values.

    The CLI accepts a single name that may resolve to either a host or an SRV
    record. The library keeps these operations explicit so callers do not need
    to guess what kind of object they are mutating.

    The host and SRV entrypoints intentionally share validation rules but not
    lookup semantics. Hosts are addressed directly by hostname, while SRV TTL
    helpers require the SRV service lookup to resolve to exactly one record.
    """

    def __init__(self, client: Any, queries: HostQueries, srv: HostSrvAPI) -> None:
        """Initialize the TTL API."""
        self._client = client
        self._queries = queries
        self._srv = srv

    def get_host(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> int | None:
        """Return the explicit TTL for one host, or `None` when defaulting."""
        host = self._queries.get_required(hostname, correlation_id=correlation_id)
        return host.ttl

    def set_host(
        self,
        hostname: str,
        ttl: int,
        *,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Set an explicit TTL on one host.

        Args:
            hostname: Host whose explicit TTL should be updated.
            ttl: TTL value in seconds. The helper enforces the MREG-supported
                range before any write is sent upstream.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            Updated host record after the TTL change.

        Raises:
            MutationStateUncertainError: MREG accepted the host TTL update, but
                verification failed before the client could confirm the
                resulting host state.
        """
        validated_ttl = _validate_ttl(ttl)
        data = self._client.patch_json(
            f"/api/v1/hosts/{hostname}",
            json={"ttl": validated_ttl},
            allow_empty=True,
            correlation_id=correlation_id,
        )
        if data is None:
            try:
                return self._queries.get_required(hostname, correlation_id=correlation_id)
            except NotFoundError as exc:
                raise RequestFailedError(
                    "Host TTL update returned an empty success response, and "
                    "verification did not find the host. Inspect MREG if "
                    "needed, but this is treated as a failed mutation rather "
                    "than an uncertain partial mutation.",
                    method=RequestMethod.PATCH,
                    status_code=exc.status_code,
                    endpoint=f"/api/v1/hosts/{hostname}",
                    request_id=exc.request_id,
                    correlation_id=exc.correlation_id or correlation_id,
                ) from exc
            except RequestFailedError as exc:
                raise MutationStateUncertainError(
                    "Host TTL update reached MREG, but verification failed. "
                    "Upstream state may be partially updated. Inspect the host "
                    "TTL in MREG before deciding whether to retry.",
                    operation="set_host_ttl",
                    completed_steps=(MutationStep("ttl_patch_request"),),
                    remaining_steps=(MutationStep("verify_host_ttl"),),
                    method=RequestMethod.PATCH,
                    status_code=exc.status_code,
                    endpoint=f"/api/v1/hosts/{hostname}",
                    request_id=exc.request_id,
                    correlation_id=exc.correlation_id or correlation_id,
                ) from exc
        return self._queries.parse_host_payload(
            data,
            endpoint=f"/api/v1/hosts/{hostname}",
            method=RequestMethod.PATCH,
        )

    def remove_host(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Remove the explicit TTL from one host.

        Empty-success patch responses are verified through a fresh host lookup
        so callers either get a stable host shape back or an explicit
        uncertain-state error.
        """
        data = self._client.patch_json(
            f"/api/v1/hosts/{hostname}",
            json={"ttl": None},
            allow_empty=True,
            correlation_id=correlation_id,
        )
        if data is None:
            try:
                return self._queries.get_required(hostname, correlation_id=correlation_id)
            except NotFoundError as exc:
                raise RequestFailedError(
                    "Host TTL removal returned an empty success response, and "
                    "verification did not find the host. Inspect MREG if "
                    "needed, but this is treated as a failed mutation rather "
                    "than an uncertain partial mutation.",
                    method=RequestMethod.PATCH,
                    status_code=exc.status_code,
                    endpoint=f"/api/v1/hosts/{hostname}",
                    request_id=exc.request_id,
                    correlation_id=exc.correlation_id or correlation_id,
                ) from exc
            except RequestFailedError as exc:
                raise MutationStateUncertainError(
                    "Host TTL removal reached MREG, but verification failed. "
                    "Upstream state may be partially updated. Inspect the host "
                    "TTL in MREG before deciding whether to retry.",
                    operation="remove_host_ttl",
                    completed_steps=(MutationStep("ttl_patch_request"),),
                    remaining_steps=(MutationStep("verify_host_ttl"),),
                    method=RequestMethod.PATCH,
                    status_code=exc.status_code,
                    endpoint=f"/api/v1/hosts/{hostname}",
                    request_id=exc.request_id,
                    correlation_id=exc.correlation_id or correlation_id,
                ) from exc
        return self._queries.parse_host_payload(
            data,
            endpoint=f"/api/v1/hosts/{hostname}",
            method=RequestMethod.PATCH,
        )

    def get_service(
        self,
        service_name: str,
        *,
        correlation_id: str | None = None,
    ) -> int | None:
        """Return the explicit TTL for one uniquely identified SRV service."""
        record = self._get_unique_service(service_name, correlation_id=correlation_id)
        return record.ttl

    def set_service(
        self,
        service_name: str,
        ttl: int,
        *,
        correlation_id: str | None = None,
    ) -> SrvRecord:
        """Set an explicit TTL on one uniquely identified SRV service.

        This helper keeps the library surface explicit: callers choose SRV TTL
        mutation directly instead of relying on the CLI's ambiguous "host or
        service" lookup behavior.

        Examples:
            Callers that mean "set the TTL on the SRV service" use this method,
            while host TTL changes go through ``set_host()``. The split is
            deliberate so writes do not depend on implicit host-vs-service
            lookup order.

        Raises:
            MutationStateUncertainError: MREG accepted the SRV TTL update, but
                verification failed before the client could confirm the
                resulting SRV state.
        """
        validated_ttl = _validate_ttl(ttl)
        record = self._get_unique_service(service_name, correlation_id=correlation_id)
        if record.id is None:
            raise ResponseDecodeError(
                "MREG SRV payload did not include a record ID",
                method=RequestMethod.GET,
                endpoint="/api/v1/srvs/",
            )
        self._client.patch_json(
            f"/api/v1/srvs/{record.id}",
            json={"ttl": validated_ttl},
            allow_empty=True,
            correlation_id=correlation_id,
        )
        try:
            return self._get_unique_service(service_name, correlation_id=correlation_id)
        except NotFoundError as exc:
            raise RequestFailedError(
                "SRV TTL update returned an empty success response, and "
                "verification did not find the service. Inspect MREG if "
                "needed, but this is treated as a failed mutation rather than "
                "an uncertain partial mutation.",
                method=RequestMethod.PATCH,
                status_code=exc.status_code,
                endpoint=f"/api/v1/srvs/{record.id}",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "SRV TTL update reached MREG, but verification failed. "
                "Upstream state may be partially updated. Inspect the SRV TTL "
                "in MREG before deciding whether to retry.",
                operation="set_srv_ttl",
                completed_steps=(MutationStep("ttl_patch_request"),),
                remaining_steps=(MutationStep("verify_srv_ttl"),),
                method=RequestMethod.PATCH,
                status_code=exc.status_code,
                endpoint=f"/api/v1/srvs/{record.id}",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc

    def remove_service(
        self,
        service_name: str,
        *,
        correlation_id: str | None = None,
    ) -> SrvRecord:
        """Remove the explicit TTL from one uniquely identified SRV service.

        Empty-success patch responses are verified through the same unique SRV
        lookup used by the read helpers so ambiguity stays explicit.
        """
        record = self._get_unique_service(service_name, correlation_id=correlation_id)
        if record.id is None:
            raise ResponseDecodeError(
                "MREG SRV payload did not include a record ID",
                method=RequestMethod.GET,
                endpoint="/api/v1/srvs/",
            )
        self._client.patch_json(
            f"/api/v1/srvs/{record.id}",
            json={"ttl": None},
            allow_empty=True,
            correlation_id=correlation_id,
        )
        try:
            return self._get_unique_service(service_name, correlation_id=correlation_id)
        except NotFoundError as exc:
            raise RequestFailedError(
                "SRV TTL removal returned an empty success response, and "
                "verification did not find the service. Inspect MREG if "
                "needed, but this is treated as a failed mutation rather than "
                "an uncertain partial mutation.",
                method=RequestMethod.PATCH,
                status_code=exc.status_code,
                endpoint=f"/api/v1/srvs/{record.id}",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "SRV TTL removal reached MREG, but verification failed. "
                "Upstream state may be partially updated. Inspect the SRV TTL "
                "in MREG before deciding whether to retry.",
                operation="remove_srv_ttl",
                completed_steps=(MutationStep("ttl_patch_request"),),
                remaining_steps=(MutationStep("verify_srv_ttl"),),
                method=RequestMethod.PATCH,
                status_code=exc.status_code,
                endpoint=f"/api/v1/srvs/{record.id}",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc

    def _get_unique_service(
        self,
        service_name: str,
        *,
        correlation_id: str | None,
    ) -> SrvRecord:
        """Return exactly one SRV record for the supplied service name.

        The TTL surface intentionally rejects ambiguous service names because
        silently choosing one SRV record would make a write-heavy API
        unpredictable. Callers that need to disambiguate should use the SRV
        record API directly.

        Raises:
            NotFoundError: No SRV records matched the supplied service name.
            ValidationError: Multiple SRV records matched and the operation
                must be disambiguated by the caller.
        """
        records = self._srv.list_service(service_name, correlation_id=correlation_id)
        if not records:
            raise NotFoundError(
                f"No SRV records were found for service {service_name!r}",
                method=RequestMethod.GET,
                endpoint="/api/v1/srvs/",
            )
        if len(records) > 1:
            raise ValidationError(
                f"Service {service_name!r} matched multiple SRV records; "
                "choose the SRV API directly",
                source=ValidationSource.LOCAL,
                method=RequestMethod.GET,
                endpoint="/api/v1/srvs/",
            )
        return records[0]


def _validate_ttl(ttl: int) -> int:
    """Validate one TTL value against the supported MREG range.

    Args:
        ttl: TTL value in seconds supplied by the caller.

    Returns:
        The validated TTL value, unchanged.

    Raises:
        ValidationError: The value falls outside the supported range.
    """
    if ttl < MIN_TTL or ttl > MAX_TTL:
        raise ValidationError(
            f"Invalid TTL value: {ttl} ({MIN_TTL}->{MAX_TTL})",
            source=ValidationSource.LOCAL,
            method=RequestMethod.PATCH,
        )
    return ttl
