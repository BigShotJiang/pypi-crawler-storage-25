"""Host SSHFP record operations.

SSHFP records are collection-style host-owned records, but they still carry
well-known algorithm and hash-type values that callers should not have to
remember as loose integers. This module is where that record identity and the
enum-backed call shape meet the MREG endpoint, including the honest reporting
of partial success when bulk deletion stops mid-loop.
"""

from __future__ import annotations

from typing import Any, cast

from ...enums import CompatibilityFallback, RequestMethod, SshfpAlgorithm, SshfpHashType
from ...exceptions import (
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
)
from ..queries import HostQueries
from ._shared import extract_results, get_host_and_id, optional_int
from .models import SshfpRecord


class HostSshfpAPI:
    """Host-facing API for SSHFP record workflows.

    The API keeps SSHFP matching and bulk-removal behavior explicit while
    allowing callers to use the stable enum values exposed by the library.
    """

    def __init__(self, client: Any, queries: HostQueries) -> None:
        """Initialize the SSHFP API."""
        self._client = client
        self._queries = queries

    def many(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> list[SshfpRecord]:
        """Return SSHFP records associated with one host."""
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{hostname}",
        )
        return self._list_for_host_id(host_id, correlation_id=correlation_id)

    def _list_for_host_id(
        self,
        host_id: int,
        *,
        correlation_id: str | None,
    ) -> list[SshfpRecord]:
        """Return SSHFP records for one resolved host ID."""
        data = self._client.get_json(
            "/api/v1/sshfps/",
            params={"host": str(host_id)},
            correlation_id=correlation_id,
        )
        return [
            self._parse_sshfp_payload(item, endpoint="/api/v1/sshfps/", method=RequestMethod.GET)
            for item in extract_results(data, endpoint="/api/v1/sshfps/")
        ]

    def add(
        self,
        hostname: str,
        *,
        algorithm: int | SshfpAlgorithm,
        hash_type: int | SshfpHashType,
        fingerprint: str,
        correlation_id: str | None = None,
    ) -> SshfpRecord:
        """Add one SSHFP record to a host.

        Empty-success create responses are verified through a host-scoped
        SSHFP lookup. Existing single-record matches are treated as idempotent,
        even though ``mreg-cli`` raises on that case. If the verification
        request fails, the method raises ``MutationStateUncertainError``
        instead of guessing whether the record exists upstream.
        """
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{hostname}",
        )
        normalized_algorithm = int(algorithm)
        normalized_hash_type = int(hash_type)

        existing = self._find_matching(
            host_id,
            algorithm=normalized_algorithm,
            hash_type=normalized_hash_type,
            fingerprint=fingerprint,
            correlation_id=correlation_id,
        )
        if existing is not None:
            return existing

        created_payload = self._client.post_json(
            "/api/v1/sshfps/",
            json={
                "host": host_id,
                "algorithm": normalized_algorithm,
                "hash_type": normalized_hash_type,
                "fingerprint": fingerprint,
            },
            allow_empty=True,
            compatibility_fallback=CompatibilityFallback.FORM,
            correlation_id=correlation_id,
        )
        if isinstance(created_payload, dict):
            created = self._parse_sshfp_payload(
                created_payload,
                endpoint="/api/v1/sshfps/",
                method=RequestMethod.POST,
            )
            if (
                created.host_id != host_id
                or created.algorithm != normalized_algorithm
                or created.hash_type != normalized_hash_type
                or created.fingerprint != fingerprint
            ):
                raise ResponseDecodeError(
                    "MREG create response did not match the requested SSHFP record",
                    method=RequestMethod.POST,
                    endpoint="/api/v1/sshfps/",
                )
            return created
        if created_payload is not None:
            raise ResponseDecodeError(
                "MREG SSHFP create response did not match a supported JSON shape",
                method=RequestMethod.POST,
                endpoint="/api/v1/sshfps/",
            )
        try:
            created = self._find_matching(
                host_id,
                algorithm=normalized_algorithm,
                hash_type=normalized_hash_type,
                fingerprint=fingerprint,
                correlation_id=correlation_id,
            )
        except NotFoundError as exc:
            raise RequestFailedError(
                "SSHFP create returned an empty success response, and "
                "verification did not find the new SSHFP record. Inspect MREG "
                "if needed, but this is treated as a failed create rather than "
                "an uncertain partial mutation.",
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/sshfps/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "SSHFP create reached MREG, but verification failed. Upstream "
                "state may be partially updated. Inspect the SSHFP records in "
                "MREG before deciding whether to retry.",
                operation="create_sshfp_record",
                completed_steps=(MutationStep("create_request"),),
                remaining_steps=(MutationStep("verify_created_sshfp_record"),),
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/sshfps/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        if created is None:
            raise RequestFailedError(
                "SSHFP create returned an empty success response, and "
                "verification did not find the new SSHFP record. Inspect MREG "
                "if needed, but this is treated as a failed create rather than "
                "an uncertain partial mutation.",
                method=RequestMethod.POST,
                endpoint="/api/v1/sshfps/",
                correlation_id=correlation_id,
            )
        return created

    def remove(
        self,
        hostname: str,
        *,
        fingerprint: str | None = None,
        correlation_id: str | None = None,
    ) -> None:
        """Remove one SSHFP record, or all host SSHFP records when omitted.

        Bulk removal stays a simple for-loop on purpose. If some deletes
        succeed and a later delete fails, the method raises
        ``MutationStateUncertainError`` with the completed record ids attached.
        """
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{hostname}",
        )
        records = self._list_for_host_id(host_id, correlation_id=correlation_id)
        if fingerprint is not None:
            records = [record for record in records if record.fingerprint == fingerprint]
        if not records:
            raise NotFoundError(
                f"No matching SSHFP records were found for host {hostname!r}",
                method=RequestMethod.DELETE,
                endpoint="/api/v1/sshfps/",
            )

        deleted_ids: list[int] = []
        for record in records:
            if record.id is None:
                raise ResponseDecodeError(
                    "MREG SSHFP payload did not include a record ID",
                    method=RequestMethod.GET,
                    endpoint="/api/v1/sshfps/",
                )
            try:
                self._client.delete_json(
                    f"/api/v1/sshfps/{record.id}",
                    correlation_id=correlation_id,
                )
            except RequestFailedError as exc:
                if deleted_ids:
                    raise MutationStateUncertainError(
                        "SSHFP bulk delete stopped after partial success. "
                        "Upstream state may be partially updated. Inspect the "
                        "SSHFP records in MREG before deciding whether to retry.",
                        operation="delete_sshfp_records",
                        completed_steps=tuple(
                            MutationStep("delete_record", detail=str(record_id))
                            for record_id in deleted_ids
                        ),
                        remaining_steps=(MutationStep("delete_record", detail=str(record.id)),),
                        method=RequestMethod.DELETE,
                        status_code=exc.status_code,
                        endpoint=f"/api/v1/sshfps/{record.id}",
                        request_id=exc.request_id,
                        correlation_id=exc.correlation_id or correlation_id,
                    ) from exc
                raise
            deleted_ids.append(record.id)

    def _find_matching(
        self,
        host_id: int,
        *,
        algorithm: int,
        hash_type: int,
        fingerprint: str,
        correlation_id: str | None,
    ) -> SshfpRecord | None:
        """Return one SSHFP record matching the full identity tuple."""
        for record in self._list_for_host_id(host_id, correlation_id=correlation_id):
            if (
                record.algorithm == algorithm
                and record.hash_type == hash_type
                and record.fingerprint == fingerprint
            ):
                return record
        return None

    def _parse_sshfp_payload(
        self,
        payload: object,
        *,
        endpoint: str,
        method: RequestMethod,
    ) -> SshfpRecord:
        """Interpret one MREG SSHFP payload into the stable library shape."""
        if not isinstance(payload, dict):
            raise ResponseDecodeError(
                "MREG SSHFP payload was not a JSON object",
                method=method,
                endpoint=endpoint,
            )
        payload_dict = cast(dict[str, Any], payload)
        algorithm = optional_int(payload_dict.get("algorithm"))
        hash_type = optional_int(payload_dict.get("hash_type"))
        fingerprint = payload_dict.get("fingerprint")
        if algorithm is None:
            raise ResponseDecodeError(
                "MREG SSHFP payload did not include an algorithm value",
                method=method,
                endpoint=endpoint,
            )
        if hash_type is None:
            raise ResponseDecodeError(
                "MREG SSHFP payload did not include a hash_type value",
                method=method,
                endpoint=endpoint,
            )
        if not isinstance(fingerprint, str) or not fingerprint.strip():
            raise ResponseDecodeError(
                "MREG SSHFP payload did not include a fingerprint value",
                method=method,
                endpoint=endpoint,
            )
        return SshfpRecord(
            id=optional_int(payload_dict.get("id")),
            host_id=optional_int(payload_dict.get("host")),
            algorithm=algorithm,
            hash_type=hash_type,
            fingerprint=fingerprint.strip(),
            raw=dict(payload_dict),
        )
