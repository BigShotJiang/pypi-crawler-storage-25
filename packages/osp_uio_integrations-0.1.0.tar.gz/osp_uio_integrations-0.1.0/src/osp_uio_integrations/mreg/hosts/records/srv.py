"""SRV record operations.

SRV records are where record handling stops being purely host-owned data and
starts depending on DNS namespace rules as well. This module owns the explicit
forward-zone validation for both the service name and the target host before a
write is sent upstream. It also owns the small local numeric guards that pay
their way here plus the write-then-verify behavior needed when MREG returns an
empty success response.
"""

from __future__ import annotations

from typing import Any, cast

from ...enums import CompatibilityFallback, RequestMethod, ValidationSource
from ...exceptions import (
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
)
from ..queries import HostQueries
from ._shared import extract_results, get_host_and_id, optional_int
from .models import SrvRecord


class HostSrvAPI:
    """API for SRV record workflows.

    The class exposes SRV operations in service-and-target terms rather than
    as generic record mutations, keeping the DNS-specific SRV identity and zone
    checks visible in the library contract.
    """

    def __init__(self, client: Any, queries: HostQueries) -> None:
        """Initialize the SRV API."""
        self._client = client
        self._queries = queries

    def list_service(
        self,
        service_name: str,
        *,
        correlation_id: str | None = None,
    ) -> list[SrvRecord]:
        """Return SRV records for one service name."""
        data = self._client.get_json(
            "/api/v1/srvs/",
            params={"name": service_name},
            correlation_id=correlation_id,
        )
        records = [
            self._parse_srv_payload(item, endpoint="/api/v1/srvs/", method=RequestMethod.GET)
            for item in extract_results(data, endpoint="/api/v1/srvs/")
        ]
        return sorted(
            records,
            key=lambda record: (record.priority, record.weight, record.port, record.host_id or -1),
        )

    def add(
        self,
        service_name: str,
        *,
        target_host: str,
        priority: int,
        weight: int,
        port: int,
        ttl: int | None = None,
        correlation_id: str | None = None,
    ) -> SrvRecord:
        """Add one SRV record when the DNS identity tuple is not already present.

        The method keeps SRV-specific invariants visible at the boundary:
        forward-zone validation is required for both the service name and the
        target host, and repeated adds for the same identity tuple are treated
        as idempotent reads rather than duplicate writes.

        Args:
            service_name: SRV owner name to create.
            target_host: Existing host that should serve as the SRV target.
            priority: SRV priority value.
            weight: SRV weight value.
            port: Service port number.
            ttl: Optional explicit TTL for the new record.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            Existing or newly created SRV record matching the supplied tuple.

        Raises:
            MutationStateUncertainError: MREG accepted the create request, but
                verification failed before the client could confirm the record.
        """
        _validate_srv_inputs(priority=priority, weight=weight, port=port)
        self._require_forward_zone(service_name, correlation_id=correlation_id)
        host, host_id = get_host_and_id(
            self._queries,
            target_host,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{target_host}",
        )
        self._require_forward_zone(host.name, correlation_id=correlation_id)

        existing = self._find_matching(
            service_name,
            host_id=host_id,
            priority=priority,
            weight=weight,
            port=port,
            ttl=ttl,
            correlation_id=correlation_id,
        )
        if existing is not None:
            return existing

        payload: dict[str, object] = {
            "name": service_name,
            "host": host_id,
            "priority": priority,
            "weight": weight,
            "port": port,
        }
        if ttl is not None:
            payload["ttl"] = ttl

        created_payload = self._client.post_json(
            "/api/v1/srvs/",
            json=payload,
            allow_empty=True,
            compatibility_fallback=CompatibilityFallback.FORM,
            correlation_id=correlation_id,
        )
        if isinstance(created_payload, dict):
            created = self._parse_srv_payload(
                created_payload,
                endpoint="/api/v1/srvs/",
                method=RequestMethod.POST,
            )
            if (
                created.name != service_name
                or created.host_id != host_id
                or created.priority != priority
                or created.weight != weight
                or created.port != port
                or created.ttl != ttl
            ):
                raise ResponseDecodeError(
                    "MREG create response did not match the requested SRV record",
                    method=RequestMethod.POST,
                    endpoint="/api/v1/srvs/",
                )
            return created
        if created_payload is not None:
            raise ResponseDecodeError(
                "MREG SRV create response did not match a supported JSON shape",
                method=RequestMethod.POST,
                endpoint="/api/v1/srvs/",
            )
        try:
            created = self._find_matching(
                service_name,
                host_id=host_id,
                priority=priority,
                weight=weight,
                port=port,
                ttl=ttl,
                correlation_id=correlation_id,
            )
        except NotFoundError as exc:
            raise RequestFailedError(
                "SRV create returned an empty success response, and verification "
                "did not find the new SRV record. Inspect MREG if needed, but "
                "this is treated as a failed create rather than an uncertain "
                "partial mutation.",
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/srvs/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "SRV create reached MREG, but verification failed. Upstream "
                "state may be partially updated. Inspect the SRV record in "
                "MREG before deciding whether to retry.",
                operation="create_srv_record",
                completed_steps=(MutationStep("create_request"),),
                remaining_steps=(MutationStep("verify_created_srv_record"),),
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/srvs/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        if created is None:
            raise RequestFailedError(
                "SRV create returned an empty success response, and verification "
                "did not find the new SRV record. Inspect MREG if needed, but "
                "this is treated as a failed create rather than an uncertain "
                "partial mutation.",
                method=RequestMethod.POST,
                endpoint="/api/v1/srvs/",
                correlation_id=correlation_id,
            )
        return created

    def remove(
        self,
        service_name: str,
        *,
        target_host: str,
        priority: int,
        weight: int,
        port: int,
        correlation_id: str | None = None,
    ) -> None:
        """Remove one SRV record."""
        _, host_id = get_host_and_id(
            self._queries,
            target_host,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{target_host}",
        )
        record = self._find_matching(
            service_name,
            host_id=host_id,
            priority=priority,
            weight=weight,
            port=port,
            ttl=None,
            correlation_id=correlation_id,
            match_ttl=False,
        )
        if record is None:
            raise NotFoundError(
                "No SRV record for "
                f"{service_name!r} with target {target_host!r} matched the given values",
                method=RequestMethod.DELETE,
                endpoint="/api/v1/srvs/",
            )
        if record.id is None:
            raise ResponseDecodeError(
                "MREG SRV payload did not include a record ID",
                method=RequestMethod.GET,
                endpoint="/api/v1/srvs/",
            )
        self._client.delete_json(
            f"/api/v1/srvs/{record.id}",
            correlation_id=correlation_id,
        )

    def _find_matching(
        self,
        service_name: str,
        *,
        host_id: int,
        priority: int,
        weight: int,
        port: int,
        ttl: int | None,
        correlation_id: str | None,
        match_ttl: bool = True,
    ) -> SrvRecord | None:
        """Return one SRV record matching the supplied identity tuple.

        The helper centralizes the notion of SRV identity used by this module
        so add/remove operations stay consistent about which fields make one
        record distinct from another.
        """
        for record in self.list_service(service_name, correlation_id=correlation_id):
            if record.host_id != host_id:
                continue
            if record.priority != priority or record.weight != weight or record.port != port:
                continue
            if match_ttl and record.ttl != ttl:
                continue
            return record
        return None

    def _parse_srv_payload(
        self,
        payload: object,
        *,
        endpoint: str,
        method: RequestMethod,
    ) -> SrvRecord:
        """Interpret one MREG SRV payload into the stable library shape.

        Args:
            payload: Raw decoded JSON payload returned by an SRV endpoint.
            endpoint: Endpoint path used to annotate decode failures.
            method: HTTP method associated with the payload.

        Returns:
            Stable ``SrvRecord`` instance with the fields needed by the SRV
            API.

        Raises:
            ResponseDecodeError: Payload was not a JSON object or lacked the
                fields needed to identify the SRV record.
        """
        if not isinstance(payload, dict):
            raise ResponseDecodeError(
                "MREG SRV payload was not a JSON object",
                method=method,
                endpoint=endpoint,
            )
        payload_dict = cast(dict[str, Any], payload)
        name = payload_dict.get("name")
        if not isinstance(name, str) or not name.strip():
            raise ResponseDecodeError(
                "MREG SRV payload did not include a service name",
                method=method,
                endpoint=endpoint,
            )

        priority = optional_int(payload_dict.get("priority"))
        weight = optional_int(payload_dict.get("weight"))
        port = optional_int(payload_dict.get("port"))
        if priority is None or weight is None or port is None:
            raise ResponseDecodeError(
                "MREG SRV payload did not include priority, weight, and port values",
                method=method,
                endpoint=endpoint,
            )

        return SrvRecord(
            id=optional_int(payload_dict.get("id")),
            name=name.strip(),
            host_id=optional_int(payload_dict.get("host")),
            priority=priority,
            weight=weight,
            port=port,
            ttl=optional_int(payload_dict.get("ttl")),
            raw=dict(payload_dict),
        )

    def _require_forward_zone(
        self,
        hostname: str,
        *,
        correlation_id: str | None,
    ) -> None:
        """Ensure the supplied hostname belongs to a forward zone known by MREG."""
        zone = self._client.get_json(
            f"/api/v1/zones/forward/hostname/{hostname}",
            soft_404=True,
            correlation_id=correlation_id,
        )
        if zone:
            return
        raise NotFoundError(
            f"No forward zone was found for {hostname!r}",
            method=RequestMethod.GET,
            endpoint=f"/api/v1/zones/forward/hostname/{hostname}",
        )


def _validate_srv_inputs(*, priority: int, weight: int, port: int) -> None:
    """Apply the small SRV numeric guards that pay their way locally.

    This is intentionally not a full SRV grammar or protocol validator. The
    helper only enforces the cheap 16-bit bounds that are easy to get wrong at
    the call site and cheap to reject before any network round-trip.
    """
    if priority < 0 or priority > 65535:
        raise ValidationError(
            "SRV priority must be in 0..65535",
            source=ValidationSource.LOCAL,
            method=RequestMethod.POST,
            endpoint="/api/v1/srvs/",
        )
    if weight < 0 or weight > 65535:
        raise ValidationError(
            "SRV weight must be in 0..65535",
            source=ValidationSource.LOCAL,
            method=RequestMethod.POST,
            endpoint="/api/v1/srvs/",
        )
    if port < 1 or port > 65535:
        raise ValidationError(
            "SRV port must be in 1..65535",
            source=ValidationSource.LOCAL,
            method=RequestMethod.POST,
            endpoint="/api/v1/srvs/",
        )
