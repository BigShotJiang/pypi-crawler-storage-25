"""Composition root for explicit host-owned record modules.

This package is where the DNS resource-record port stops being "a blob of RR
helpers" and becomes a set of explicit library modules. Each record type keeps
its own endpoint knowledge and validation rules, while this composition root
simply gathers them into ``client.hosts.records``.

The goal is not a generic record framework. Shared code is limited to the small
amount of repeated host/list/payload glue that multiple concrete record modules
already proved they need.
"""

from __future__ import annotations

from typing import Any

from ..queries import HostQueries
from .hinfo import HostHinfoAPI
from .loc import HostLocAPI
from .mx import HostMxAPI
from .naptr import HostNaptrAPI
from .ptr import HostPtrAPI
from .srv import HostSrvAPI
from .sshfp import HostSshfpAPI
from .ttl import HostTtlAPI
from .txt import HostTxtAPI


class HostRecordsAPI:
    """Public entrypoint for explicit host-owned record sub-APIs.

    This class exists for ergonomics, not to centralize behavior. Each
    attribute points to a concrete record module that still owns its own rules,
    payload interpretation, and write semantics.
    """

    def __init__(self, client: Any, queries: HostQueries) -> None:
        """Initialize the host records facade."""
        self.hinfo = HostHinfoAPI(client, queries)
        self.loc = HostLocAPI(client, queries)
        self.mx = HostMxAPI(client, queries)
        self.naptr = HostNaptrAPI(client, queries)
        self.ptr = HostPtrAPI(client, queries)
        self.sshfp = HostSshfpAPI(client, queries)
        self.srv = HostSrvAPI(client, queries)
        self.ttl = HostTtlAPI(client, queries, self.srv)
        self.txt = HostTxtAPI(client, queries)
