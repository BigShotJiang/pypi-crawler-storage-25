"""Host PTR override operations.

This module owns the host-side PTR override workflows that need more than a
plain CRUD wrapper. In particular, PTR creation carries MREG-specific guard
checks around managed zones, managed networks, and reserved IP addresses, and
PTR moves need host-aware validation before the write happens.

Those rules stay here on purpose. They are endpoint-aware business constraints,
not model behavior and not generic transport concerns. Empty-success create and
move paths also verify through host/PTR lookups here so uncertainty is exposed
at the record boundary instead of leaking out as a generic decode failure.
"""

from __future__ import annotations

import ipaddress
from typing import Any, Protocol, cast
from urllib.parse import quote

from ...enums import CompatibilityFallback, RequestMethod, ValidationSource
from ...exceptions import (
    ConflictError,
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
)
from .._network import NetworkRecord, parse_network_payload
from ..models import HostRecord
from ..queries import HostQueries
from ._shared import extract_results, get_host_and_id, optional_int
from .models import PtrRecord

_PTR_ENDPOINT = "/api/v1/ptroverrides/"
_PtrRecordList = list[PtrRecord]


class _MregTransport(Protocol):
    """Minimal transport surface consumed by PTR override workflows."""

    def get_json(
        self,
        endpoint: str,
        *,
        params: dict[str, object] | None = None,
        soft_404: bool = False,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Return one decoded JSON object or list from the shared transport."""

    def post_json(
        self,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, object] | None = None,
        compatibility_fallback: CompatibilityFallback | None = None,
        allow_empty: bool = False,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Issue one JSON-backed POST request."""

    def patch_json(
        self,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, object] | None = None,
        compatibility_fallback: CompatibilityFallback | None = None,
        allow_empty: bool = False,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Issue one JSON-backed PATCH request."""

    def delete_json(
        self,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, object] | None = None,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Issue one DELETE request through the shared transport."""


class HostPtrAPI:
    """Host-facing API for PTR override workflows.

    The methods in this class expose explicit host-and-IP operations rather
    than a generic "record id" surface so callers can work in the same terms as
    the existing CLI workflows. The class owns the extra MREG validation needed
    for safe PTR creation and movement.
    """

    def __init__(self, client: _MregTransport, queries: HostQueries) -> None:
        """Initialize the PTR API."""
        self._client = client
        self._queries = queries

    def many(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> _PtrRecordList:
        """Return PTR override records associated with one host."""
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=_host_endpoint(hostname),
        )
        return self._list_for_host_id(host_id, correlation_id=correlation_id)

    def get(
        self,
        hostname: str,
        ipaddress_value: str,
        *,
        correlation_id: str | None = None,
    ) -> PtrRecord | None:
        """Return one PTR override by host and IP address, or `None` if missing."""
        target_ip = _parse_ip(
            ipaddress_value,
            method=RequestMethod.GET,
            endpoint=_PTR_ENDPOINT,
        )
        for record in self.many(hostname, correlation_id=correlation_id):
            if record.ipaddress == target_ip:
                return record
        return None

    def add(
        self,
        hostname: str,
        ipaddress_value: str,
        *,
        force: bool = False,
        correlation_id: str | None = None,
    ) -> PtrRecord:
        """Add one PTR override to a host.

        The operation is intentionally host-and-IP oriented because PTR
        creation in MREG is not just a blind record insert. The library checks
        for an existing PTR override first, then enforces the local managed-
        zone, managed-network, and reserved-IP rules unless ``force`` is used.

        Args:
            hostname: Host that should own the PTR override.
            ipaddress_value: IP address that should resolve back to the host.
            force: Whether to bypass the local managed-boundary safety checks.
                ``force`` does not bypass an existing PTR override owned by a
                different host. That conflict remains a hard stop because the
                write would otherwise merge ambiguous reverse-DNS ownership.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            Existing or newly created PTR override record.

        Raises:
            MutationStateUncertainError: MREG accepted the create request, but
                verification failed before the client could confirm the PTR
                override state.
        """
        target_ip = _parse_ip(
            ipaddress_value,
            method=RequestMethod.POST,
            endpoint=_PTR_ENDPOINT,
        )
        host, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=_host_endpoint(hostname),
        )

        existing_records = self._list_by_ip(target_ip, correlation_id=correlation_id)
        if existing_records:
            for record in existing_records:
                if record.host_id == host_id:
                    return record
            raise ConflictError(
                f"PTR override for IP {target_ip} already exists",
                method=RequestMethod.GET,
                endpoint=_PTR_ENDPOINT,
            )

        if not force:
            self._validate_ptr_add(
                host=host,
                ipaddress_value=target_ip,
                correlation_id=correlation_id,
            )

        created_payload = self._client.post_json(
            _PTR_ENDPOINT,
            json={"host": host_id, "ipaddress": target_ip},
            allow_empty=True,
            compatibility_fallback=CompatibilityFallback.FORM,
            correlation_id=correlation_id,
        )
        if isinstance(created_payload, dict):
            return self._parse_ptr_payload(created_payload, endpoint=_PTR_ENDPOINT)
        if created_payload is not None:
            raise ResponseDecodeError(
                "MREG PTR override create response did not match a supported JSON shape",
                method=RequestMethod.POST,
                endpoint=_PTR_ENDPOINT,
            )
        try:
            created = self.get(host.name, target_ip, correlation_id=correlation_id)
        except NotFoundError as exc:
            raise RequestFailedError(
                "PTR override create returned an empty success response, and "
                "verification did not find the PTR override. Inspect MREG if "
                "needed, but this is treated as a failed create rather than an "
                "uncertain partial mutation.",
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint=_PTR_ENDPOINT,
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "PTR override create reached MREG, but verification failed. "
                "Upstream state may be partially updated. Inspect the PTR "
                "override in MREG before deciding whether to retry.",
                operation="create_ptr_override",
                completed_steps=(MutationStep("create_request"),),
                remaining_steps=(MutationStep("verify_created_ptr_override"),),
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint=_PTR_ENDPOINT,
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        if created is None:
            raise RequestFailedError(
                "PTR override create returned an empty success response, and "
                "verification did not find the PTR override. Inspect MREG if "
                "needed, but this is treated as a failed create rather than an "
                "uncertain partial mutation.",
                method=RequestMethod.POST,
                endpoint=_PTR_ENDPOINT,
                correlation_id=correlation_id,
            )
        return created

    def remove(
        self,
        hostname: str,
        ipaddress_value: str,
        *,
        correlation_id: str | None = None,
    ) -> None:
        """Remove one PTR override from a host."""
        record = self.get(hostname, ipaddress_value, correlation_id=correlation_id)
        if record is None:
            raise NotFoundError(
                f"Host {hostname!r} has no PTR override for {ipaddress_value!r}",
                method=RequestMethod.DELETE,
                endpoint=_PTR_ENDPOINT,
            )
        if record.id is None:
            raise ResponseDecodeError(
                "MREG PTR override payload did not include a record ID",
                method=RequestMethod.GET,
                endpoint=_PTR_ENDPOINT,
            )
        self._client.delete_json(
            f"{_PTR_ENDPOINT}{record.id}",
            correlation_id=correlation_id,
        )

    def move(
        self,
        ipaddress_value: str,
        *,
        from_host: str,
        to_host: str,
        correlation_id: str | None = None,
    ) -> PtrRecord:
        """Move one PTR override from one host to another.

        The move surface follows ``mreg-cli``'s stricter rule that the
        destination host must not already have any PTR override. When MREG
        accepts the move but the follow-up lookup fails, this method raises
        ``MutationStateUncertainError`` rather than guessing whether the move
        applied.
        """
        target_ip = _parse_ip(
            ipaddress_value,
            method=RequestMethod.PATCH,
            endpoint=_PTR_ENDPOINT,
        )
        source_record = self.get(from_host, target_ip, correlation_id=correlation_id)
        if source_record is None:
            raise NotFoundError(
                f"Host {from_host!r} has no PTR override for {target_ip!r}",
                method=RequestMethod.PATCH,
                endpoint=_PTR_ENDPOINT,
            )

        destination_ptrs = self.many(to_host, correlation_id=correlation_id)
        if destination_ptrs:
            raise ConflictError(
                f"Host {to_host!r} already has a PTR override",
                method=RequestMethod.PATCH,
                endpoint=_PTR_ENDPOINT,
            )

        _, destination_host_id = get_host_and_id(
            self._queries,
            to_host,
            correlation_id=correlation_id,
            endpoint=_host_endpoint(to_host),
        )
        if source_record.id is None:
            raise ResponseDecodeError(
                "MREG PTR override payload did not include a record ID",
                method=RequestMethod.GET,
                endpoint=_PTR_ENDPOINT,
            )
        self._client.patch_json(
            f"{_PTR_ENDPOINT}{source_record.id}",
            json={"host": destination_host_id},
            allow_empty=True,
            correlation_id=correlation_id,
        )
        try:
            moved = self.get(to_host, target_ip, correlation_id=correlation_id)
        except NotFoundError as exc:
            raise RequestFailedError(
                "PTR override move returned an empty success response, and "
                "verification did not find the PTR override on the destination "
                "host. Inspect MREG if needed, but this is treated as a failed "
                "move rather than an uncertain partial mutation.",
                method=RequestMethod.PATCH,
                status_code=exc.status_code,
                endpoint=f"/api/v1/ptroverrides/{source_record.id}",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "PTR override move reached MREG, but verification failed. "
                "Upstream state may be partially updated. Inspect the PTR "
                "override in MREG before deciding whether to retry.",
                operation="move_ptr_override",
                completed_steps=(MutationStep("move_request"),),
                remaining_steps=(MutationStep("verify_moved_ptr_override"),),
                method=RequestMethod.PATCH,
                status_code=exc.status_code,
                endpoint=f"/api/v1/ptroverrides/{source_record.id}",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        if moved is None:
            raise RequestFailedError(
                "PTR override move returned an empty success response, and "
                "verification did not find the PTR override on the destination "
                "host. Inspect MREG if needed, but this is treated as a failed "
                "move rather than an uncertain partial mutation.",
                method=RequestMethod.PATCH,
                endpoint=f"/api/v1/ptroverrides/{source_record.id}",
                correlation_id=correlation_id,
            )
        return moved

    def _list_for_host_id(
        self,
        host_id: int,
        *,
        correlation_id: str | None,
    ) -> _PtrRecordList:
        """Return PTR overrides for one resolved host ID."""
        data = self._client.get_json(
            _PTR_ENDPOINT,
            params={"host": str(host_id)},
            correlation_id=correlation_id,
        )
        records = [
            self._parse_ptr_payload(item, endpoint=_PTR_ENDPOINT)
            for item in extract_results(data, endpoint=_PTR_ENDPOINT)
        ]
        return sorted(records, key=_sort_ptr_record)

    def _list_by_ip(
        self,
        ipaddress_value: str,
        *,
        correlation_id: str | None,
    ) -> _PtrRecordList:
        """Return PTR overrides currently using one IP address."""
        data = self._client.get_json(
            _PTR_ENDPOINT,
            params={"ipaddress": ipaddress_value},
            correlation_id=correlation_id,
        )
        records = [
            self._parse_ptr_payload(item, endpoint=_PTR_ENDPOINT)
            for item in extract_results(data, endpoint=_PTR_ENDPOINT)
        ]
        return sorted(records, key=_sort_ptr_record)

    def _validate_ptr_add(
        self,
        *,
        host: HostRecord,
        ipaddress_value: str,
        correlation_id: str | None,
    ) -> None:
        """Validate non-forced PTR creation against MREG-managed boundaries.

        Args:
            host: Destination host that should own the PTR override.
            ipaddress_value: Target IP address for the PTR override.
            correlation_id: Optional logical operation id for tracing the
                supporting network lookups.

        Raises:
            ValidationError: Host zone, network ownership, or reserved-address
                rules require the caller to opt into ``force``.
        """
        if host.zone_id is None:
            raise ValidationError(
                f"Host {host.name!r} is not in a zone controlled by MREG; force is required",
                source=ValidationSource.LOCAL,
                method=RequestMethod.POST,
                endpoint=_PTR_ENDPOINT,
            )
        network = self._get_network_by_ip(ipaddress_value, correlation_id=correlation_id)
        if network is None:
            raise ValidationError(
                f"IP {ipaddress_value} is not in a network controlled by MREG; force is required",
                source=ValidationSource.LOCAL,
                method=RequestMethod.POST,
                endpoint=_PTR_ENDPOINT,
            )
        reserved_ips = self._get_reserved_ips(network=network, correlation_id=correlation_id)
        if ipaddress_value in reserved_ips:
            raise ValidationError(
                f"IP {ipaddress_value} is reserved; force is required",
                source=ValidationSource.LOCAL,
                method=RequestMethod.POST,
                endpoint=_PTR_ENDPOINT,
            )

    def _get_network_by_ip(
        self,
        ipaddress_value: str,
        *,
        correlation_id: str | None,
    ) -> NetworkRecord | None:
        """Fetch the network containing one IP address."""
        data = self._client.get_json(
            f"/api/v1/networks/ip/{ipaddress_value}",
            soft_404=True,
            correlation_id=correlation_id,
        )
        if not data:
            return None
        return parse_network_payload(data, endpoint=f"/api/v1/networks/ip/{ipaddress_value}")

    def _get_reserved_ips(
        self,
        *,
        network: NetworkRecord,
        correlation_id: str | None,
    ) -> set[str]:
        """Return the reserved IP addresses for one network."""
        endpoint = f"/api/v1/networks/{quote(network.network, safe='')}/reserved_list"
        data = self._client.get_json(endpoint, correlation_id=correlation_id)
        if not isinstance(data, list):
            raise ResponseDecodeError(
                "MREG reserved_list response was not a JSON list",
                method=RequestMethod.GET,
                endpoint=endpoint,
            )
        return {rendered for item in data if (rendered := _try_parse_ip(item)) is not None}

    def _parse_ptr_payload(
        self,
        payload: object,
        *,
        endpoint: str,
    ) -> PtrRecord:
        """Interpret one MREG PTR override payload into the stable library shape.

        Args:
            payload: Raw decoded JSON payload returned by a PTR endpoint.
            endpoint: Endpoint path used to annotate decode failures.

        Returns:
            Stable ``PtrRecord`` instance.

        Raises:
            ResponseDecodeError: Payload was not a JSON object or lacked a
                usable IP address.
        """
        if not isinstance(payload, dict):
            raise ResponseDecodeError(
                "MREG PTR override payload was not a JSON object",
                method=RequestMethod.GET,
                endpoint=endpoint,
            )
        payload_dict = cast(dict[str, Any], payload)
        ipaddress_value = _try_parse_ip(payload_dict.get("ipaddress"))
        if ipaddress_value is None:
            raise ResponseDecodeError(
                "MREG PTR override payload did not include a valid IP address",
                method=RequestMethod.GET,
                endpoint=endpoint,
            )
        return PtrRecord(
            id=optional_int(payload_dict.get("id")),
            host_id=optional_int(payload_dict.get("host")),
            ipaddress=ipaddress_value,
            raw=dict(payload_dict),
        )

def _parse_ip(
    value: str,
    *,
    method: RequestMethod,
    endpoint: str,
) -> str:
    """Parse and canonicalize one IP string for one PTR operation boundary."""
    try:
        return str(ipaddress.ip_address(value))
    except ValueError as exc:
        raise ValidationError(
            f"{value!r} is not a valid IP address",
            source=ValidationSource.LOCAL,
            method=method,
            endpoint=endpoint,
        ) from exc


def _try_parse_ip(value: object) -> str | None:
    """Return one canonical IP string when the input is parseable."""
    if value is None:
        return None
    try:
        return str(ipaddress.ip_address(str(value)))
    except ValueError:
        return None


def _host_endpoint(hostname: str) -> str:
    """Return the host endpoint used for host-backed PTR record lookups."""
    return f"/api/v1/hosts/{hostname}"


def _sort_ptr_record(record: PtrRecord) -> tuple[str, int, int]:
    """Return a stable sort key for PTR record lists."""
    return (
        record.ipaddress,
        record.host_id if record.host_id is not None else -1,
        record.id if record.id is not None else -1,
    )
