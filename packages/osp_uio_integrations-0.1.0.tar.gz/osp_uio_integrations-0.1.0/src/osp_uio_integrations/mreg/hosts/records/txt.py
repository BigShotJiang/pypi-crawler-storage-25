"""Host TXT record operations.

TXT records are among the simpler host-owned record types, but they still need
stable list/add/remove behavior, host-scoped lookup, and post-create refetch
handling for endpoints that do not reliably return the created object. This
module keeps that verification logic local so callers see uncertain-state
errors in TXT terms rather than as generic transport noise.
"""

from __future__ import annotations

from typing import Any, cast

from ...enums import CompatibilityFallback, RequestMethod
from ...exceptions import (
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
)
from ..queries import HostQueries
from ._shared import extract_results, get_host_and_id, optional_int
from .models import TxtRecord


class HostTxtAPI:
    """Host-facing API for TXT record workflows.

    The class keeps TXT operations concrete and host-scoped instead of exposing
    a generic record-id layer. That keeps the caller contract close to the way
    the rest of the host library thinks about records.
    """

    def __init__(self, client: Any, queries: HostQueries) -> None:
        """Initialize the TXT API."""
        self._client = client
        self._queries = queries

    def many(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> list[TxtRecord]:
        """Return TXT records associated with one host."""
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{hostname}",
        )
        return self._list_for_host_id(host_id, correlation_id=correlation_id)

    def _list_for_host_id(
        self,
        host_id: int,
        *,
        correlation_id: str | None,
    ) -> list[TxtRecord]:
        """Return TXT records for one resolved host ID."""
        data = self._client.get_json(
            "/api/v1/txts/",
            params={"host": str(host_id)},
            correlation_id=correlation_id,
        )
        return [
            self._parse_txt_payload(item, endpoint="/api/v1/txts/", method=RequestMethod.GET)
            for item in extract_results(data, endpoint="/api/v1/txts/")
        ]

    def get(
        self,
        hostname: str,
        text: str,
        *,
        correlation_id: str | None = None,
    ) -> TxtRecord | None:
        """Return one TXT record by exact text, or `None` if it does not exist."""
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{hostname}",
        )
        for record in self._list_for_host_id(host_id, correlation_id=correlation_id):
            if record.text == text:
                return record
        return None

    def add(
        self,
        hostname: str,
        text: str,
        *,
        correlation_id: str | None = None,
    ) -> TxtRecord:
        """Add one TXT record to a host.

        Empty-success create responses are verified through the host-scoped TXT
        listing for the same exact text value.
        """
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{hostname}",
        )
        existing = None
        for record in self._list_for_host_id(host_id, correlation_id=correlation_id):
            if record.text == text:
                existing = record
                break
        if existing is not None:
            return existing

        created_payload = self._client.post_json(
            "/api/v1/txts/",
            json={"host": host_id, "txt": text},
            allow_empty=True,
            compatibility_fallback=CompatibilityFallback.FORM,
            correlation_id=correlation_id,
        )
        if isinstance(created_payload, dict):
            created = self._parse_txt_payload(
                created_payload,
                endpoint="/api/v1/txts/",
                method=RequestMethod.POST,
            )
            if created.host_id != host_id or created.text != text:
                raise ResponseDecodeError(
                    "MREG create response did not match the requested TXT record",
                    method=RequestMethod.POST,
                    endpoint="/api/v1/txts/",
                )
            return created
        if created_payload is not None:
            raise ResponseDecodeError(
                "MREG TXT create response did not match a supported JSON shape",
                method=RequestMethod.POST,
                endpoint="/api/v1/txts/",
            )
        try:
            created = None
            for record in self._list_for_host_id(host_id, correlation_id=correlation_id):
                if record.text == text:
                    created = record
                    break
        except NotFoundError as exc:
            raise RequestFailedError(
                "TXT create returned an empty success response, and verification "
                "did not find the new TXT record. Inspect MREG if needed, but "
                "this is treated as a failed create rather than an uncertain "
                "partial mutation.",
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/txts/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "TXT create reached MREG, but verification failed. Upstream "
                "state may be partially updated. Inspect the TXT records in "
                "MREG before deciding whether to retry.",
                operation="create_txt_record",
                completed_steps=(MutationStep("create_request"),),
                remaining_steps=(MutationStep("verify_created_txt_record"),),
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/txts/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        if created is None:
            raise RequestFailedError(
                "TXT create returned an empty success response, and verification "
                "did not find the new TXT record. Inspect MREG if needed, but "
                "this is treated as a failed create rather than an uncertain "
                "partial mutation.",
                method=RequestMethod.POST,
                endpoint="/api/v1/txts/",
                correlation_id=correlation_id,
            )
        return created

    def remove(
        self,
        hostname: str,
        text: str,
        *,
        correlation_id: str | None = None,
    ) -> None:
        """Remove one TXT record from a host by exact text."""
        record = self.get(hostname, text, correlation_id=correlation_id)
        if record is None:
            raise NotFoundError(
                f"Host {hostname!r} has no TXT record matching {text!r}",
                method=RequestMethod.DELETE,
                endpoint="/api/v1/txts/",
            )
        if record.id is None:
            raise ResponseDecodeError(
                "MREG TXT payload did not include a record ID",
                method=RequestMethod.GET,
                endpoint="/api/v1/txts/",
            )
        self._client.delete_json(
            f"/api/v1/txts/{record.id}",
            correlation_id=correlation_id,
        )

    def _parse_txt_payload(
        self,
        payload: object,
        *,
        endpoint: str,
        method: RequestMethod,
    ) -> TxtRecord:
        """Interpret one MREG TXT payload into the stable library shape."""
        if not isinstance(payload, dict):
            raise ResponseDecodeError(
                "MREG TXT payload was not a JSON object",
                method=method,
                endpoint=endpoint,
            )
        payload_dict = cast(dict[str, Any], payload)
        text = payload_dict.get("txt")
        if not isinstance(text, str) or not text.strip():
            raise ResponseDecodeError(
                "MREG TXT payload did not include record text",
                method=method,
                endpoint=endpoint,
            )
        return TxtRecord(
            id=optional_int(payload_dict.get("id")),
            host_id=optional_int(payload_dict.get("host")),
            text=text,
            raw=dict(payload_dict),
        )
