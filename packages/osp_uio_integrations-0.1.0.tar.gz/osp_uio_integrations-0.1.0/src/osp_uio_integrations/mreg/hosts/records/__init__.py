"""Host-owned RR modules.

This package contains explicit RR modules for host-bound record types. Public
exports:

- `HostRecordsAPI` for the record-oriented boundary under `client.hosts.records`
- stable record and identity models that callers may want in type hints or
  tests

Individual record modules are private implementation details so the library
can evolve their helpers and local validation logic without widening the
import contract.
"""

from .api import HostRecordsAPI
from .models import (
    HinfoRecord,
    LocRecord,
    MxRecord,
    NaptrIdentity,
    NaptrRecord,
    PtrRecord,
    SrvRecord,
    SshfpRecord,
    TxtRecord,
)

__all__ = [
    "HinfoRecord",
    "HostRecordsAPI",
    "LocRecord",
    "MxRecord",
    "NaptrIdentity",
    "NaptrRecord",
    "PtrRecord",
    "SrvRecord",
    "SshfpRecord",
    "TxtRecord",
]
