"""Shared helpers for host-owned RR modules.

This file only owns the repeated host/list/payload glue used by the first RR
modules. It is intentionally not a generic record engine.
"""

from __future__ import annotations

from ...enums import RequestMethod
from ...exceptions import ResponseDecodeError
from .._shared import extract_results as _extract_results
from ..models import HostRecord
from ..queries import HostQueries

extract_results = _extract_results


def get_host_and_id(
    queries: HostQueries,
    hostname: str,
    *,
    correlation_id: str | None,
    endpoint: str,
) -> tuple[HostRecord, int]:
    """Return one host and require a usable host ID for linked record writes."""
    host = queries.get_required(hostname, correlation_id=correlation_id)
    return host, require_host_id(host=host, endpoint=endpoint)

def optional_int(value: object) -> int | None:
    """Normalize optional integer fields from MREG payloads."""
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.isdigit():
        return int(value)
    return None


def require_host_id(*, host: HostRecord, endpoint: str) -> int:
    """Require a parsed host ID for host-linked record mutations."""
    if isinstance(host.id, int):
        return host.id
    raise ResponseDecodeError(
        "MREG host payload did not include a host ID",
        method=RequestMethod.GET,
        endpoint=endpoint,
    )
