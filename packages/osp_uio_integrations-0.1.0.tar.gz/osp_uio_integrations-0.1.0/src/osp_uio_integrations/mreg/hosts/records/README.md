# records (Host-Owned Resource Records)

The `records` package is the explicit RR surface that hangs off
`client.hosts.records`. Each resource-record type lives in its own module,
owns its endpoint knowledge, and exposes operations in the same terms
operators reason about (host name + identity tuple) instead of in raw
upstream record-id terms.

The package exists to keep RR handling out of one giant "records.py" while
still letting callers write `client.hosts.records.ptr.add(...)` instead of
chasing implementation details. The composition root in `api.py` does
nothing more than wire the per-RR sub-APIs together.

The package owns:

- per-RR endpoint mapping (`/api/v1/cnames/`, `/api/v1/srvs/`, `/api/v1/ptroverrides/`, …)
- per-RR identity rules (e.g., NAPTR by full tuple, SRV by service+target+priority+weight+port, MX by priority+exchange)
- DNS-shaped guards close to where they apply (forward-zone, managed
  network, frozen network, reserved IP, TTL bounds, 16-bit numeric ranges)
- write-then-verify reporting per record type, so uncertain mutations stay
  named in record terms

The package does not own:

- transport behavior, token refresh, or HTTP-level retries — that is
  `mreg/client.py`
- generic record abstractions across record types — there is no shared
  RecordBase
- host lifecycle or addressing semantics — those live one level up in
  `hosts/`
- CLI rendering

## What lives here

- **`api.py`** — `HostRecordsAPI`: composition root reached as
  `client.hosts.records`. No behavior of its own.
- **`models.py`** — stable RR data shapes: `HinfoRecord`, `LocRecord`,
  `MxRecord`, `NaptrRecord`, `NaptrIdentity`, `PtrRecord`, `SrvRecord`,
  `SshfpRecord`, `TxtRecord`. All frozen dataclasses; none perform I/O.
- **`hinfo.py`** — `HostHinfoAPI`: host-linked HINFO singleton.
- **`loc.py`** — `HostLocAPI`: host-linked LOC singleton.
- **`mx.py`** — `HostMxAPI`: collection-style MX with priority+exchange
  identity and a 0..65535 priority guard.
- **`naptr.py`** — `HostNaptrAPI`: full-tuple identity, force-gated bulk
  delete, partial-success reporting.
- **`ptr.py`** — `HostPtrAPI`: PTR overrides with managed-zone, managed-
  network, frozen-network, and reserved-IP guards plus host-aware moves.
- **`srv.py`** — `HostSrvAPI`: service-and-target identity, dual forward-
  zone validation, 16-bit numeric guards.
- **`sshfp.py`** — `HostSshfpAPI`: enum-typed `algorithm` / `hash_type`
  call shape with bulk-removal support.
- **`ttl.py`** — `HostTtlAPI`: explicit `set_host` / `remove_host` and
  `set_service` / `remove_service` paths; no implicit host-vs-SRV lookup.
- **`txt.py`** — `HostTxtAPI`: simple host-scoped TXT collection with
  refetch-on-empty-success.
- **`_shared.py`** — `extract_results`, `optional_int`, `get_host_and_id`,
  `require_host_id`. Only the glue every concrete module already proved it
  needs.

---

## Layer guides

### `api.py` — HostRecordsAPI composition

```python
class HostRecordsAPI:
    def __init__(self, client, queries):
        self.hinfo = HostHinfoAPI(client, queries)
        self.loc   = HostLocAPI(client, queries)
        self.mx    = HostMxAPI(client, queries)
        self.naptr = HostNaptrAPI(client, queries)
        self.ptr   = HostPtrAPI(client, queries)
        self.sshfp = HostSshfpAPI(client, queries)
        self.srv   = HostSrvAPI(client, queries)
        self.ttl   = HostTtlAPI(client, queries, self.srv)  # depends on SRV lookup
        self.txt   = HostTxtAPI(client, queries)
```

`ttl` is the only sub-API that takes a peer (`srv`) at wiring time. It
needs the SRV lookup helper to disambiguate the explicit `set_service` /
`remove_service` paths. Every other RR module is independent.

### Singleton-style RR modules: `hinfo.py`, `loc.py`

These RR types are at-most-one per host. Each module exposes
`get(hostname)`, `add(hostname, ...)` (rejects when one already exists),
`remove(hostname)`, and the standard write-then-verify behavior on
empty-success creates.

### Collection-style RR modules: `mx.py`, `txt.py`, `sshfp.py`

Each owns its own notion of record identity:

- MX: `(priority, exchange)`
- TXT: `text`
- SSHFP: `(algorithm, hash_type, fingerprint)`

`add()` is idempotent: when an equivalent record already exists, no write
is sent and the existing record is returned. `remove()` rejects ambiguous
matches unless the module documents otherwise.

### `naptr.py` — full-tuple identity with force-gated bulk delete

NAPTR identity is the full `NaptrIdentity` tuple
(`preference`, `order`, `flag`, `service`, `regex`, `replacement`).
Removal can match more than one upstream record because operators
sometimes encode duplicates intentionally; the module makes that visible:

- `remove()` without `force=True` raises when more than one record matches
- `remove()` with `force=True` deletes them in a loop and reports
  `MutationStateUncertainError` with `completed_steps` / `remaining_steps`
  if the loop stops mid-way

### `ptr.py` — PTR overrides with explicit guards

PTR creation is the heaviest record path because it carries multiple
endpoint-aware checks before the write:

- IP must parse and (for IPv4) not collide with a network/broadcast boundary
- the network managing the IP must not be `frozen` (never bypassable)
- the IP must not be reserved (`force` allows)
- the address must belong to a managed zone (`force` allows)
- a PTR override for the IP must not already exist for another host

Move paths re-run the destination guards before issuing the write and
return whether the host A/AAAA changed and whether the PTR override moved
in `AddressMoveResult` shape.

### `srv.py` — service-and-target identity with dual forward-zone checks

SRV identity is `(name, host_id, priority, weight, port[, ttl])`. `add()`
runs `_require_forward_zone` for both the service name and the target
host before issuing a create, and re-checks the same identity tuple
during empty-success verification. Numeric guards reject anything outside
0..65535 (priority/weight) and 1..65535 (port).

### `ttl.py` — explicit host-vs-SRV TTL surface

The CLI accepts an ambiguous name that may resolve to either a host or an
SRV record. The library refuses that ambiguity by exposing four explicit
methods:

```python
get_host(hostname)
set_host(hostname, ttl)
remove_host(hostname)
get_service(service_name)
set_service(service_name, ttl)
remove_service(service_name)
```

`*_service` paths require the SRV lookup to resolve to exactly one record
or they raise `ValidationError` and direct the caller at the SRV API.
`_validate_ttl` enforces `300..68400` seconds.

### `_shared.py` — tiny shared glue

```python
extract_results(data, *, endpoint)            # both list shapes
optional_int(value)                           # int | "int-string" | None
get_host_and_id(queries, hostname, *, ...)    # standard pre-write
require_host_id(*, host, endpoint)            # promotes None to ResponseDecodeError
```

Anything bigger belongs in the RR module that needs it.

---

## Design recipes

### Per-RR identity instead of generic record-id matching

Each RR module decides what makes one record distinct from another. That
keeps add-idempotency and remove-matching correct without a generic
"record key" abstraction that would have to encode every RR's quirks.

The cost is a small amount of duplication across modules. The benefit is
that NAPTR's six-field tuple, SRV's service+target+ports tuple, MX's
priority+exchange, and TXT's lone `text` value all stay obviously correct
in their own files.

### Write-then-verify, RR-shaped

Every RR module that issues a write follows the same pattern as the
host-domain modules:

```python
created = self._client.post_json(endpoint, json=payload, allow_empty=True, ...)
if isinstance(created, dict):
    parsed = self._parse_<rr>_payload(created, ...)
    if parsed != requested:                     # echo check
        raise ResponseDecodeError(...)
    return parsed
if created is not None:
    raise ResponseDecodeError(...)              # unsupported shape
try:
    return self._find_matching(...)             # verifying read
except NotFoundError as exc:
    raise RequestFailedError(...) from exc      # ordinary failure
except RequestFailedError as exc:
    raise MutationStateUncertainError(...) from exc  # uncertain partial mutation
```

The `_find_matching` step is per-RR because it needs the RR's identity
rules. The classification rule is universal.

### Bulk-delete partial-success reporting

Bulk operations (NAPTR force-delete, SSHFP cleanup, PTR sweeps) iterate
over individual upstream record ids. When the loop fails midway, the
module emits a `MutationStateUncertainError` with `completed_steps`
listing the deleted ids and `remaining_steps` listing the ones that did
not finish. Callers can log the partial state before deciding whether to
retry.

### `force` is per-RR, never global

Carrying the same convention as the host package:

| RR | What `force` does |
|---|---|
| `naptr.remove` | Allow deleting more than one matching record |
| `ptr.add` / `ptr.move` | Allow reserved addresses; allow non-managed-zone targets; **never** bypasses the frozen-network guard; does **not** override another host already owning the PTR |

There is no `force` on TXT, MX, HINFO, LOC, SSHFP, SRV, or TTL because
those operations have no destructive behavior that warrants one.

---

## Design rules

- **Models are dumb data.** No method on a record model talks to MREG.
  All payload interpretation lives in the RR module's
  `_parse_<rr>_payload` next to the endpoint it came from.
- **No generic record framework.** Shared code is `_shared.py` only.
  Resist the urge to extract a base class — RR identity differs in ways
  that are not worth hiding.
- **Empty success is verified.** Any endpoint that may return `None` is
  followed by a refetch keyed on the RR identity tuple, with the
  classification rule above.
- **`_find_matching` matches what `add()` would create.** When add and
  remove diverge in matching (e.g., SRV remove ignoring TTL), the RR
  module documents that explicitly via flags such as `match_ttl=False`.
- **Frozen networks are never overridden.** PTR's `force` only relaxes
  reserved-address and managed-zone checks.
- **TTL bounds and 16-bit numeric guards run before the network call.**
  Cheap rejections happen client-side; everything else stays
  upstream-authoritative.
- **`HostTtlAPI` does not guess.** Callers choose host TTL or SRV TTL
  explicitly. Multi-match SRV TTL writes are rejected with a pointer at
  the SRV API.

---

## Common issues

- **`MutationStateUncertainError` after a record write.** The write
  probably reached MREG but the verifying read failed. Inspect the
  affected record and check `completed_steps` / `remaining_steps`.
- **`ConflictError: HINFO/LOC already exists for host`.** These RR types
  are singletons. Use `remove()` first or update through the appropriate
  patch path.
- **`ConflictError: PTR override exists for IP X owned by host Y`.**
  PTR add refuses to silently steal an override. Move via the destination
  host's API.
- **`ValidationError: NAPTR delete matched N records; force is required`.**
  Confirm the deletion is intentional and pass `force=True`.
- **`ValidationError: SRV port must be in 1..65535`.** Local 16-bit guard.
  Adjust the value at the call site.
- **`ValidationError: Service X matched multiple SRV records`.**
  `HostTtlAPI.set_service` / `remove_service` deliberately reject
  ambiguous SRV names. Use `client.hosts.records.srv` directly.
- **`ResponseDecodeError: MREG ... payload did not include ... ID`.** The
  upstream payload shape changed. Treat as a real error; do not retry
  blindly.

---

## Mini cheat sheet

| I want to … | Use |
|---|---|
| List MX records on a host | `client.hosts.records.mx.many(host)` |
| Add an MX record | `client.hosts.records.mx.add(host, priority=10, exchange=...)` |
| Add a TXT record | `client.hosts.records.txt.add(host, text)` |
| Set HINFO for a host | `client.hosts.records.hinfo.add(host, cpu=..., os=...)` |
| Add a LOC value | `client.hosts.records.loc.add(host, value)` |
| Add an SSHFP fingerprint | `client.hosts.records.sshfp.add(host, algorithm=..., hash_type=..., fingerprint=...)` |
| Add a NAPTR record | `client.hosts.records.naptr.add(host, NaptrIdentity(...))` |
| Force-delete duplicate NAPTRs | `client.hosts.records.naptr.remove(host, identity, force=True)` |
| Add a PTR override | `client.hosts.records.ptr.add(host, ip)` |
| Add an SRV record | `client.hosts.records.srv.add(name, target_host=..., priority=..., weight=..., port=...)` |
| Set host TTL | `client.hosts.records.ttl.set_host(host, seconds)` |
| Set SRV TTL (unique) | `client.hosts.records.ttl.set_service(name, seconds)` |

See [../README.md](../README.md) for host-level guards and the broader
mutation contract, and [../../README.md](../../README.md) for the
package-level surface and exception taxonomy.
