"""Host HINFO record operations.

HINFO is operationally simple but still benefits from an explicit library
boundary because MREG treats it as a host-linked singleton record. This module
owns that singleton behavior, the create/remove rules around it, and the
write-then-verify handling for empty-success create responses.
"""

from __future__ import annotations

from typing import Any, cast

from ...enums import CompatibilityFallback, RequestMethod
from ...exceptions import (
    ConflictError,
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
)
from ..queries import HostQueries
from ._shared import extract_results, get_host_and_id, optional_int
from .models import HinfoRecord


class HostHinfoAPI:
    """Host-facing API for HINFO singleton workflows.

    Callers work in host terms, while this class owns the upstream expectation
    that a host should have zero or one HINFO record at a time.
    """

    def __init__(self, client: Any, queries: HostQueries) -> None:
        """Initialize the HINFO API."""
        self._client = client
        self._queries = queries

    def get(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> HinfoRecord | None:
        """Return the HINFO record for one host, or `None` if it does not exist."""
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{hostname}",
        )
        return self._get_for_host_id(host_id, hostname=hostname, correlation_id=correlation_id)

    def _get_for_host_id(
        self,
        host_id: int,
        *,
        hostname: str,
        correlation_id: str | None,
    ) -> HinfoRecord | None:
        """Return the HINFO record for one resolved host ID."""
        data = self._client.get_json(
            "/api/v1/hinfos/",
            params={"host": str(host_id)},
            correlation_id=correlation_id,
        )
        records = [
            self._parse_hinfo_payload(item, endpoint="/api/v1/hinfos/", method=RequestMethod.GET)
            for item in extract_results(data, endpoint="/api/v1/hinfos/")
        ]
        if not records:
            return None
        if len(records) > 1:
            raise ResponseDecodeError(
                f"MREG returned multiple HINFO records for host {hostname!r}",
                method=RequestMethod.GET,
                endpoint="/api/v1/hinfos/",
            )
        return records[0]

    def add(
        self,
        hostname: str,
        *,
        cpu: str,
        os: str,
        correlation_id: str | None = None,
    ) -> HinfoRecord:
        """Add one HINFO record to a host.

        HINFO behaves as a singleton. Empty-success create responses are
        verified through the same singleton lookup path used by ``get()``.
        """
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{hostname}",
        )
        existing = self._get_for_host_id(
            host_id,
            hostname=hostname,
            correlation_id=correlation_id,
        )
        if existing is not None:
            if existing.cpu == cpu and existing.os == os:
                return existing
            raise ConflictError(
                f"Host {hostname!r} already has HINFO set",
                method=RequestMethod.GET,
                endpoint="/api/v1/hinfos/",
            )

        created_payload = self._client.post_json(
            "/api/v1/hinfos/",
            json={"host": host_id, "cpu": cpu, "os": os},
            allow_empty=True,
            compatibility_fallback=CompatibilityFallback.FORM,
            correlation_id=correlation_id,
        )
        if isinstance(created_payload, dict):
            created = self._parse_hinfo_payload(
                created_payload,
                endpoint="/api/v1/hinfos/",
                method=RequestMethod.POST,
            )
            if created.host_id != host_id or created.cpu != cpu or created.os != os:
                raise ResponseDecodeError(
                    "MREG create response did not match the requested HINFO record",
                    method=RequestMethod.POST,
                    endpoint="/api/v1/hinfos/",
                )
            return created
        if created_payload is not None:
            raise ResponseDecodeError(
                "MREG HINFO create response did not match a supported JSON shape",
                method=RequestMethod.POST,
                endpoint="/api/v1/hinfos/",
            )
        try:
            created = self._get_for_host_id(
                host_id,
                hostname=hostname,
                correlation_id=correlation_id,
            )
        except NotFoundError as exc:
            raise RequestFailedError(
                "HINFO create returned an empty success response, and "
                "verification did not find the new HINFO record. Inspect MREG "
                "if needed, but this is treated as a failed create rather than "
                "an uncertain partial mutation.",
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/hinfos/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "HINFO create reached MREG, but verification failed. Upstream "
                "state may be partially updated. Inspect the HINFO record in "
                "MREG before deciding whether to retry.",
                operation="create_hinfo_record",
                completed_steps=(MutationStep("create_request"),),
                remaining_steps=(MutationStep("verify_created_hinfo_record"),),
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/hinfos/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        if created is None:
            raise RequestFailedError(
                "HINFO create returned an empty success response, and "
                "verification did not find the new HINFO record. Inspect MREG "
                "if needed, but this is treated as a failed create rather than "
                "an uncertain partial mutation.",
                method=RequestMethod.POST,
                endpoint="/api/v1/hinfos/",
                correlation_id=correlation_id,
            )
        return created

    def remove(self, hostname: str, *, correlation_id: str | None = None) -> None:
        """Remove the HINFO record from one host."""
        record = self.get(hostname, correlation_id=correlation_id)
        if record is None:
            raise NotFoundError(
                f"Host {hostname!r} has no HINFO record",
                method=RequestMethod.DELETE,
                endpoint="/api/v1/hinfos/",
            )
        if record.id is None:
            raise ResponseDecodeError(
                "MREG HINFO payload did not include a record ID",
                method=RequestMethod.GET,
                endpoint="/api/v1/hinfos/",
            )
        self._client.delete_json(
            f"/api/v1/hinfos/{record.id}",
            correlation_id=correlation_id,
        )

    def _parse_hinfo_payload(
        self,
        payload: object,
        *,
        endpoint: str,
        method: RequestMethod,
    ) -> HinfoRecord:
        if not isinstance(payload, dict):
            raise ResponseDecodeError(
                "MREG HINFO payload was not a JSON object",
                method=method,
                endpoint=endpoint,
            )
        payload_dict = cast(dict[str, Any], payload)
        cpu = payload_dict.get("cpu")
        os_value = payload_dict.get("os")
        if not isinstance(cpu, str) or not cpu.strip():
            raise ResponseDecodeError(
                "MREG HINFO payload did not include a CPU value",
                method=method,
                endpoint=endpoint,
            )
        if not isinstance(os_value, str) or not os_value.strip():
            raise ResponseDecodeError(
                "MREG HINFO payload did not include an OS value",
                method=method,
                endpoint=endpoint,
            )
        return HinfoRecord(
            id=optional_int(payload_dict.get("id")),
            host_id=optional_int(payload_dict.get("host")),
            cpu=cpu.strip(),
            os=os_value.strip(),
            raw=dict(payload_dict),
        )
