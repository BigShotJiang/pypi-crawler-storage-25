"""Host NAPTR record operations.

NAPTR is one of the more operationally specific record types because removal
may match more than one upstream record and therefore needs an explicit force
decision at the library call site. This module owns that visible behavior plus
the honest reporting of partial success when forced bulk deletion stops
mid-loop.
"""

from __future__ import annotations

from typing import Any, Protocol, cast

from ...enums import CompatibilityFallback, RequestMethod, ValidationSource
from ...exceptions import (
    ConflictError,
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
)
from ..queries import HostQueries
from ._shared import extract_results, get_host_and_id, optional_int
from .models import NaptrIdentity, NaptrRecord

_NAPTR_ENDPOINT = "/api/v1/naptrs/"
_NaptrRecordList = list[NaptrRecord]


class _MregTransport(Protocol):
    """Minimal transport surface consumed by NAPTR workflows."""

    def get_json(
        self,
        endpoint: str,
        *,
        params: dict[str, object] | None = None,
        soft_404: bool = False,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Return one decoded JSON object or list from the shared transport."""

    def post_json(
        self,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, object] | None = None,
        compatibility_fallback: CompatibilityFallback | None = None,
        allow_empty: bool = False,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Issue one JSON-backed POST request."""

    def delete_json(
        self,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, object] | None = None,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Issue one DELETE request through the shared transport."""


class HostNaptrAPI:
    """Host-facing API for NAPTR record workflows.

    The class keeps NAPTR matching, duplicate handling, and force-gated delete
    behavior local to the NAPTR boundary instead of hiding it inside a generic
    record helper.
    """

    def __init__(self, client: _MregTransport, queries: HostQueries) -> None:
        """Initialize the NAPTR API."""
        self._client = client
        self._queries = queries

    def many(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> _NaptrRecordList:
        """Return NAPTR records associated with one host."""
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=_host_endpoint(hostname),
        )
        return self._list_for_host_id(host_id, correlation_id=correlation_id)

    def _list_for_host_id(
        self,
        host_id: int,
        *,
        correlation_id: str | None,
    ) -> _NaptrRecordList:
        """Return NAPTR records for one resolved host ID."""
        data = self._client.get_json(
            _NAPTR_ENDPOINT,
            params={"host": str(host_id)},
            correlation_id=correlation_id,
        )
        return [
            self._parse_naptr_payload(item, endpoint=_NAPTR_ENDPOINT)
            for item in extract_results(data, endpoint=_NAPTR_ENDPOINT)
        ]

    def add(
        self,
        hostname: str,
        identity: NaptrIdentity,
        *,
        correlation_id: str | None = None,
    ) -> NaptrRecord:
        """Add one NAPTR record to a host.

        The public surface takes a normalized identity object because NAPTR
        ownership and idempotency are defined by the full tuple, not by one
        scalar field. Existing single-record matches are treated as idempotent,
        even though ``mreg-cli`` raises on that case, while duplicate existing
        matches are rejected so callers do not silently inherit ambiguous
        upstream state. Empty-success create responses are verified through a
        record match on that same identity.
        """
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=_host_endpoint(hostname),
        )
        existing = self._find_matches(host_id, identity=identity, correlation_id=correlation_id)
        if len(existing) == 1:
            return existing[0]
        if len(existing) > 1:
            raise ConflictError(
                "Multiple existing NAPTR records match this identity; remove duplicates first",
                method=RequestMethod.POST,
                endpoint=_NAPTR_ENDPOINT,
            )

        created_payload = self._client.post_json(
            _NAPTR_ENDPOINT,
            json={
                "host": host_id,
                "preference": identity.preference,
                "order": identity.order,
                "flag": identity.flag,
                "service": identity.service,
                "regex": identity.regex,
                "replacement": identity.replacement,
            },
            allow_empty=True,
            compatibility_fallback=CompatibilityFallback.FORM,
            correlation_id=correlation_id,
        )
        if isinstance(created_payload, dict):
            created = self._parse_naptr_payload(created_payload, endpoint=_NAPTR_ENDPOINT)
            if _record_identity(created) != identity:
                raise ResponseDecodeError(
                    "MREG create response did not match the requested NAPTR identity",
                    method=RequestMethod.POST,
                    endpoint=_NAPTR_ENDPOINT,
                )
            return created
        if created_payload is not None:
            raise ResponseDecodeError(
                "MREG NAPTR create response did not match a supported JSON shape",
                method=RequestMethod.POST,
                endpoint=_NAPTR_ENDPOINT,
            )

        try:
            created = self._find_matches(host_id, identity=identity, correlation_id=correlation_id)
        except NotFoundError as exc:
            raise RequestFailedError(
                "NAPTR create returned an empty success response, and "
                "verification did not find the new NAPTR record. Inspect MREG "
                "if needed, but this is treated as a failed create rather than "
                "an uncertain partial mutation.",
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint=_NAPTR_ENDPOINT,
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "NAPTR create reached MREG, but verification failed. Upstream "
                "state may be partially updated. Inspect the NAPTR records in "
                "MREG before deciding whether to retry.",
                operation="create_naptr_record",
                completed_steps=(MutationStep("create_request"),),
                remaining_steps=(MutationStep("verify_created_naptr_record"),),
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint=_NAPTR_ENDPOINT,
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        if not created:
            raise RequestFailedError(
                "NAPTR create returned an empty success response, and "
                "verification did not find the new NAPTR record. Inspect MREG "
                "if needed, but this is treated as a failed create rather than "
                "an uncertain partial mutation.",
                method=RequestMethod.POST,
                endpoint=_NAPTR_ENDPOINT,
                correlation_id=correlation_id,
            )
        if len(created) > 1:
            raise ConflictError(
                "MREG returned multiple matching NAPTR records after create",
                method=RequestMethod.POST,
                endpoint=_NAPTR_ENDPOINT,
            )
        return created[0]

    def remove(
        self,
        hostname: str,
        identity: NaptrIdentity,
        *,
        force: bool = False,
        correlation_id: str | None = None,
    ) -> None:
        """Remove matching NAPTR records from a host.

        Removal is intentionally strict. A missing record raises
        ``NotFoundError`` instead of silently succeeding so cleanup callers do
        not mistake an absent record for a successful upstream delete.

        The caller must pass `force=True` when more than one upstream record
        matches the supplied identity tuple. Matching stays strict to that full
        identity; this library intentionally does not replicate the
        ``mreg-cli`` bug that could delete every NAPTR on the host after a
        partial filter mismatch. When forced deletion partially succeeds and
        then fails, the method raises ``MutationStateUncertainError`` with the
        finished record ids attached.
        """
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=_host_endpoint(hostname),
        )
        matches = self._find_matches(host_id, identity=identity, correlation_id=correlation_id)
        if not matches:
            raise NotFoundError(
                f"No matching NAPTR records were found for host {hostname!r}",
                method=RequestMethod.DELETE,
                endpoint=_NAPTR_ENDPOINT,
            )
        if len(matches) > 1 and not force:
            raise ValidationError(
                "Multiple matching NAPTR records were found; force is required",
                source=ValidationSource.LOCAL,
                method=RequestMethod.DELETE,
                endpoint=_NAPTR_ENDPOINT,
            )

        record_ids = _require_record_ids(matches, endpoint=_NAPTR_ENDPOINT)
        deleted_ids: list[int] = []
        for record_id in record_ids:
            try:
                self._client.delete_json(
                    f"{_NAPTR_ENDPOINT}{record_id}",
                    correlation_id=correlation_id,
                )
            except RequestFailedError as exc:
                if deleted_ids:
                    raise MutationStateUncertainError(
                        "NAPTR bulk delete stopped after partial success. "
                        "Upstream state may be partially updated. Inspect the "
                        "NAPTR records in MREG before deciding whether to retry.",
                        operation="delete_naptr_records",
                        completed_steps=tuple(
                            MutationStep("delete_record", detail=str(id_)) for id_ in deleted_ids
                        ),
                        remaining_steps=(MutationStep("delete_record", detail=str(record_id)),),
                        method=RequestMethod.DELETE,
                        status_code=exc.status_code,
                        endpoint=f"{_NAPTR_ENDPOINT}{record_id}",
                        request_id=exc.request_id,
                        correlation_id=exc.correlation_id or correlation_id,
                    ) from exc
                raise
            deleted_ids.append(record_id)

    def _find_matches(
        self,
        host_id: int,
        *,
        identity: NaptrIdentity,
        correlation_id: str | None,
    ) -> _NaptrRecordList:
        """Return NAPTR records matching the supplied full identity tuple."""
        return [
            record
            for record in self._list_for_host_id(host_id, correlation_id=correlation_id)
            if _record_identity(record) == identity
        ]

    def _parse_naptr_payload(
        self,
        payload: object,
        *,
        endpoint: str,
    ) -> NaptrRecord:
        """Interpret one MREG NAPTR payload into the stable library shape."""
        if not isinstance(payload, dict):
            raise ResponseDecodeError(
                "MREG NAPTR payload was not a JSON object",
                method=RequestMethod.GET,
                endpoint=endpoint,
            )
        payload_dict = cast(dict[str, Any], payload)
        preference = optional_int(payload_dict.get("preference"))
        order = optional_int(payload_dict.get("order"))
        if preference is None:
            raise ResponseDecodeError(
                "MREG NAPTR payload did not include a preference value",
                method=RequestMethod.GET,
                endpoint=endpoint,
            )
        if order is None:
            raise ResponseDecodeError(
                "MREG NAPTR payload did not include an order value",
                method=RequestMethod.GET,
                endpoint=endpoint,
            )
        identity = _parse_naptr_identity_payload(
            payload_dict,
            endpoint=endpoint,
            preference=preference,
            order=order,
        )
        return NaptrRecord(
            id=optional_int(payload_dict.get("id")),
            host_id=optional_int(payload_dict.get("host")),
            preference=identity.preference,
            order=identity.order,
            flag=identity.flag,
            service=identity.service,
            regex=identity.regex,
            replacement=identity.replacement,
            raw=dict(payload_dict),
        )


def _parse_naptr_identity_payload(
    payload_dict: dict[str, Any],
    *,
    endpoint: str,
    preference: int,
    order: int,
) -> NaptrIdentity:
    """Parse and normalize the identity portion of one NAPTR payload."""
    flag = payload_dict.get("flag")
    service = payload_dict.get("service")
    regex = payload_dict.get("regex")
    replacement = payload_dict.get("replacement")
    if not isinstance(flag, str):
        raise ResponseDecodeError(
            "MREG NAPTR payload did not include a flag value",
            method=RequestMethod.GET,
            endpoint=endpoint,
        )
    if not isinstance(service, str):
        raise ResponseDecodeError(
            "MREG NAPTR payload did not include a service value",
            method=RequestMethod.GET,
            endpoint=endpoint,
        )
    if not isinstance(regex, str):
        raise ResponseDecodeError(
            "MREG NAPTR payload did not include a regex value",
            method=RequestMethod.GET,
            endpoint=endpoint,
        )
    if not isinstance(replacement, str) or not replacement.strip():
        raise ResponseDecodeError(
            "MREG NAPTR payload did not include a replacement value",
            method=RequestMethod.GET,
            endpoint=endpoint,
        )
    return NaptrIdentity(
        preference=preference,
        order=order,
        flag=flag,
        service=service,
        regex=regex,
        replacement=replacement,
    )


def _record_identity(record: NaptrRecord) -> NaptrIdentity:
    """Return the stable identity tuple for one normalized NAPTR record."""
    return NaptrIdentity(
        preference=record.preference,
        order=record.order,
        flag=record.flag,
        service=record.service,
        regex=record.regex,
        replacement=record.replacement,
    )


def _require_record_ids(records: _NaptrRecordList, *, endpoint: str) -> list[int]:
    """Require usable record IDs before issuing any destructive delete calls."""
    record_ids: list[int] = []
    for record in records:
        if record.id is None:
            raise ResponseDecodeError(
                "MREG NAPTR payload did not include a record ID",
                method=RequestMethod.GET,
                endpoint=endpoint,
            )
        record_ids.append(record.id)
    return record_ids


def _host_endpoint(hostname: str) -> str:
    """Return the host endpoint used for host-backed NAPTR lookups."""
    return f"/api/v1/hosts/{hostname}"
