"""Stable host-owned record models for MREG.

These models are the public return shapes for the host-owned RR sub-APIs
under :mod:`osp_uio_integrations.mreg.hosts.records`. They are deliberately
I/O-free dataclasses; nothing in this module talks to MREG. Endpoint-aware
payload interpretation lives next to the individual RR endpoints (see, for
example, :mod:`osp_uio_integrations.mreg.hosts.records.srv` and
:mod:`osp_uio_integrations.mreg.hosts.records.ptr`).

Each record carries a ``raw`` dictionary holding the original upstream
payload for callers that need fields the stable shape does not expose. The
top-level fields are the contract; ``raw`` is an escape hatch and may
change shape upstream without library changes.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class TxtRecord:
    """Stable TXT record shape returned by ``HostTxtAPI``.

    Identity for add/remove operations is the literal ``text`` value.

    Attributes:
        id: Numeric MREG TXT record id when provided.
        host_id: Numeric MREG host id this record belongs to when
            provided.
        text: TXT payload as MREG returned it.
        raw: Original upstream payload dictionary.
    """

    id: int | None
    host_id: int | None
    text: str
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class MxRecord:
    """Stable MX record shape returned by ``HostMxAPI``.

    Identity for add/remove operations is the ``(priority, exchange)``
    pair.

    Attributes:
        id: Numeric MREG MX record id when provided.
        host_id: Numeric MREG host id this record belongs to when
            provided.
        priority: MX priority value (0..65535).
        exchange: MX exchange host name as MREG returned it.
        raw: Original upstream payload dictionary.
    """

    id: int | None
    host_id: int | None
    priority: int
    exchange: str
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class HinfoRecord:
    """Stable HINFO record shape returned by ``HostHinfoAPI``.

    HINFO is a host-linked singleton: at most one record per host.

    Attributes:
        id: Numeric MREG HINFO record id when provided.
        host_id: Numeric MREG host id this record belongs to when
            provided.
        cpu: HINFO CPU field.
        os: HINFO OS field.
        raw: Original upstream payload dictionary.
    """

    id: int | None
    host_id: int | None
    cpu: str
    os: str
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class LocRecord:
    """Stable LOC record shape returned by ``HostLocAPI``.

    LOC is a host-linked singleton: at most one record per host. The
    library treats the ``value`` field as opaque and does not parse the
    LOC RFC syntax locally.

    Attributes:
        id: Numeric MREG LOC record id when provided.
        host_id: Numeric MREG host id this record belongs to when
            provided.
        value: LOC value string as MREG returned it.
        raw: Original upstream payload dictionary.
    """

    id: int | None
    host_id: int | None
    value: str
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class SshfpRecord:
    """Stable SSHFP record shape returned by ``HostSshfpAPI``.

    Identity for add/remove operations is the
    ``(algorithm, hash_type, fingerprint)`` tuple. The ``algorithm`` and
    ``hash_type`` integers correspond to the values exposed by
    :class:`osp_uio_integrations.mreg.enums.SshfpAlgorithm` and
    :class:`osp_uio_integrations.mreg.enums.SshfpHashType`; callers should
    prefer those enums at write call sites.

    Attributes:
        id: Numeric MREG SSHFP record id when provided.
        host_id: Numeric MREG host id this record belongs to when
            provided.
        algorithm: SSHFP algorithm integer.
        hash_type: SSHFP hash-type integer.
        fingerprint: Raw SSHFP fingerprint string as MREG returned it.
        raw: Original upstream payload dictionary.
    """

    id: int | None
    host_id: int | None
    algorithm: int
    hash_type: int
    fingerprint: str
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class NaptrRecord:
    """Stable NAPTR record shape returned by ``HostNaptrAPI``.

    NAPTR records are matched by their full identity tuple; see
    :class:`NaptrIdentity` for the normalized form used by add/remove
    workflows.

    Attributes:
        id: Numeric MREG NAPTR record id when provided.
        host_id: Numeric MREG host id this record belongs to when
            provided.
        preference: NAPTR preference value.
        order: NAPTR order value.
        flag: NAPTR flag string as MREG returned it.
        service: NAPTR service field.
        regex: NAPTR regex field.
        replacement: NAPTR replacement field.
        raw: Original upstream payload dictionary.
    """

    id: int | None
    host_id: int | None
    preference: int
    order: int
    flag: str
    service: str
    regex: str
    replacement: str
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class NaptrIdentity:
    """Normalized NAPTR identity tuple used by add/remove workflows.

    NAPTR operations are defined by the full record identity, not by a
    single scalar key. This value object keeps that tuple explicit and
    normalizes the whitespace-sensitive text fields once, so callers and
    library-side record matching apply the same comparison rules.

    The normalization happens in ``__post_init__`` and is the reason this
    class exists separately from :class:`NaptrRecord`: it is a write-side
    input shape that is also useful for read-side matching.

    Attributes:
        preference: NAPTR preference value.
        order: NAPTR order value.
        flag: NAPTR flag string. Surrounding whitespace is stripped.
        service: NAPTR service field. Surrounding whitespace is stripped.
        regex: NAPTR regex field. Surrounding whitespace is stripped.
        replacement: NAPTR replacement field. Surrounding whitespace is
            stripped.
    """

    preference: int
    order: int
    flag: str
    service: str
    regex: str
    replacement: str

    def __post_init__(self) -> None:
        """Strip whitespace-sensitive text fields into their stable form.

        The frozen dataclass is mutated through ``object.__setattr__`` to
        keep the post-init normalization local to construction. Callers
        never mutate ``NaptrIdentity`` instances after creation.
        """
        object.__setattr__(self, "flag", self.flag.strip())
        object.__setattr__(self, "service", self.service.strip())
        object.__setattr__(self, "regex", self.regex.strip())
        object.__setattr__(self, "replacement", self.replacement.strip())


@dataclass(frozen=True, slots=True)
class SrvRecord:
    """Stable SRV record shape returned by ``HostSrvAPI``.

    Identity for add/remove operations is the
    ``(name, host_id, priority, weight, port[, ttl])`` tuple. ``ttl`` is
    matched on add but ignored on remove.

    Attributes:
        id: Numeric MREG SRV record id when provided.
        name: SRV owner name as MREG returned it.
        host_id: Numeric MREG host id of the SRV target host when
            provided.
        priority: SRV priority value (0..65535).
        weight: SRV weight value (0..65535).
        port: SRV port number (1..65535).
        ttl: Explicit per-record TTL when set, otherwise ``None``.
        raw: Original upstream payload dictionary.
    """

    id: int | None
    name: str
    host_id: int | None
    priority: int
    weight: int
    port: int
    ttl: int | None
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class PtrRecord:
    """Stable PTR override shape returned by ``HostPtrAPI``.

    A PTR override here is the host-linked override row, not the synthesized
    PTR derived from a host's A/AAAA records. The presence of a row with
    ``host_id`` set means MREG has been told to publish a non-default PTR
    for the address.

    Attributes:
        id: Numeric MREG PTR override id when provided.
        host_id: Numeric MREG host id of the host receiving the PTR
            override when provided.
        ipaddress: Canonical IPv4 or IPv6 string the override points at.
        raw: Original upstream payload dictionary.
    """

    id: int | None
    host_id: int | None
    ipaddress: str
    raw: dict[str, Any]
