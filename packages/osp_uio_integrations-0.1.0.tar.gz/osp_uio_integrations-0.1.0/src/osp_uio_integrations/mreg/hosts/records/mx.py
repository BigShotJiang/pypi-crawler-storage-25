"""Host MX record operations.

MX records are still host-owned, but they carry a slightly richer identity
than TXT records because exchange and priority both matter. This module keeps
that identity logic, sorting, the small local priority guard, and host-scoped
lookup local to the MX boundary.
"""

from __future__ import annotations

from typing import Any, cast

from ...enums import CompatibilityFallback, RequestMethod, ValidationSource
from ...exceptions import (
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
)
from ..queries import HostQueries
from ._shared import extract_results, get_host_and_id, optional_int
from .models import MxRecord


class HostMxAPI:
    """Host-facing API for MX record workflows.

    The API exposes record identity in the same terms operators care about:
    exchange plus priority on a given host. It avoids pushing MX-specific
    matching rules back onto generic callers.
    """

    def __init__(self, client: Any, queries: HostQueries) -> None:
        """Initialize the MX API."""
        self._client = client
        self._queries = queries

    def many(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> list[MxRecord]:
        """Return MX records associated with one host."""
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{hostname}",
        )
        return self._list_for_host_id(host_id, correlation_id=correlation_id)

    def _list_for_host_id(
        self,
        host_id: int,
        *,
        correlation_id: str | None,
    ) -> list[MxRecord]:
        """Return MX records for one resolved host ID."""
        data = self._client.get_json(
            "/api/v1/mxs/",
            params={"host": str(host_id)},
            correlation_id=correlation_id,
        )
        records = [
            self._parse_mx_payload(item, endpoint="/api/v1/mxs/", method=RequestMethod.GET)
            for item in extract_results(data, endpoint="/api/v1/mxs/")
        ]
        return sorted(records, key=lambda record: (record.priority, record.exchange))

    def get(
        self,
        hostname: str,
        *,
        exchange: str,
        priority: int,
        correlation_id: str | None = None,
    ) -> MxRecord | None:
        """Return one MX record by exchange and priority, or `None` if missing."""
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{hostname}",
        )
        for record in self._list_for_host_id(host_id, correlation_id=correlation_id):
            if record.exchange == exchange and record.priority == priority:
                return record
        return None

    def add(
        self,
        hostname: str,
        *,
        exchange: str,
        priority: int,
        correlation_id: str | None = None,
    ) -> MxRecord:
        """Add one MX record to a host.

        The method validates the small 16-bit priority bound locally and uses
        a host-scoped lookup to verify empty-success create responses.
        """
        if priority < 0 or priority > 65535:
            raise ValidationError(
                "MX priority must be in 0..65535",
                source=ValidationSource.LOCAL,
                method=RequestMethod.POST,
                endpoint="/api/v1/mxs/",
            )
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{hostname}",
        )
        existing = None
        for record in self._list_for_host_id(host_id, correlation_id=correlation_id):
            if record.exchange == exchange and record.priority == priority:
                existing = record
                break
        if existing is not None:
            return existing

        created_payload = self._client.post_json(
            "/api/v1/mxs/",
            json={"host": host_id, "mx": exchange, "priority": priority},
            allow_empty=True,
            compatibility_fallback=CompatibilityFallback.FORM,
            correlation_id=correlation_id,
        )
        if isinstance(created_payload, dict):
            created = self._parse_mx_payload(
                created_payload,
                endpoint="/api/v1/mxs/",
                method=RequestMethod.POST,
            )
            if (
                created.host_id != host_id
                or created.exchange != exchange
                or created.priority != priority
            ):
                raise ResponseDecodeError(
                    "MREG create response did not match the requested MX record",
                    method=RequestMethod.POST,
                    endpoint="/api/v1/mxs/",
                )
            return created
        if created_payload is not None:
            raise ResponseDecodeError(
                "MREG MX create response did not match a supported JSON shape",
                method=RequestMethod.POST,
                endpoint="/api/v1/mxs/",
            )
        try:
            created = None
            for record in self._list_for_host_id(host_id, correlation_id=correlation_id):
                if record.exchange == exchange and record.priority == priority:
                    created = record
                    break
        except NotFoundError as exc:
            raise RequestFailedError(
                "MX create returned an empty success response, and verification "
                "did not find the new MX record. Inspect MREG if needed, but "
                "this is treated as a failed create rather than an uncertain "
                "partial mutation.",
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/mxs/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "MX create reached MREG, but verification failed. Upstream "
                "state may be partially updated. Inspect the MX records in "
                "MREG before deciding whether to retry.",
                operation="create_mx_record",
                completed_steps=(MutationStep("create_request"),),
                remaining_steps=(MutationStep("verify_created_mx_record"),),
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/mxs/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        if created is None:
            raise RequestFailedError(
                "MX create returned an empty success response, and verification "
                "did not find the new MX record. Inspect MREG if needed, but "
                "this is treated as a failed create rather than an uncertain "
                "partial mutation.",
                method=RequestMethod.POST,
                endpoint="/api/v1/mxs/",
                correlation_id=correlation_id,
            )
        return created

    def remove(
        self,
        hostname: str,
        *,
        exchange: str,
        priority: int,
        correlation_id: str | None = None,
    ) -> None:
        """Remove one MX record from a host by exchange and priority."""
        record = self.get(
            hostname,
            exchange=exchange,
            priority=priority,
            correlation_id=correlation_id,
        )
        if record is None:
            raise NotFoundError(
                f"Host {hostname!r} has no MX record for {exchange!r} with priority {priority}",
                method=RequestMethod.DELETE,
                endpoint="/api/v1/mxs/",
            )
        if record.id is None:
            raise ResponseDecodeError(
                "MREG MX payload did not include a record ID",
                method=RequestMethod.GET,
                endpoint="/api/v1/mxs/",
            )
        self._client.delete_json(
            f"/api/v1/mxs/{record.id}",
            correlation_id=correlation_id,
        )

    def _parse_mx_payload(
        self,
        payload: object,
        *,
        endpoint: str,
        method: RequestMethod,
    ) -> MxRecord:
        """Interpret one MREG MX payload into the stable library shape."""
        if not isinstance(payload, dict):
            raise ResponseDecodeError(
                "MREG MX payload was not a JSON object",
                method=method,
                endpoint=endpoint,
            )
        payload_dict = cast(dict[str, Any], payload)
        exchange = payload_dict.get("mx")
        if not isinstance(exchange, str) or not exchange.strip():
            raise ResponseDecodeError(
                "MREG MX payload did not include an exchange value",
                method=method,
                endpoint=endpoint,
            )
        priority = optional_int(payload_dict.get("priority"))
        if priority is None:
            raise ResponseDecodeError(
                "MREG MX payload did not include a priority value",
                method=method,
                endpoint=endpoint,
            )
        return MxRecord(
            id=optional_int(payload_dict.get("id")),
            host_id=optional_int(payload_dict.get("host")),
            priority=priority,
            exchange=exchange.strip(),
            raw=dict(payload_dict),
        )
