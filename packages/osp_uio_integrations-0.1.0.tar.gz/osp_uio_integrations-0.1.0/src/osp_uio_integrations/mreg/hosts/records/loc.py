"""Host LOC record operations.

Like HINFO, LOC behaves as a host-linked singleton rather than an arbitrary
collection of records. This module keeps that host-scoped singleton contract
explicit and separate from the collection-style record modules, including the
write-then-verify behavior needed when create returns an empty success
response.
"""

from __future__ import annotations

from typing import Any, cast

from ...enums import CompatibilityFallback, RequestMethod
from ...exceptions import (
    ConflictError,
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
)
from ..queries import HostQueries
from ._shared import extract_results, get_host_and_id, optional_int
from .models import LocRecord


class HostLocAPI:
    """Host-facing API for LOC singleton workflows.

    Enforces zero-or-one LOC per host and owns the write-then-verify path.
    """

    def __init__(self, client: Any, queries: HostQueries) -> None:
        """Initialize the LOC API."""
        self._client = client
        self._queries = queries

    def get(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> LocRecord | None:
        """Return the LOC record for one host, or `None` if it does not exist."""
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{hostname}",
        )
        return self._get_for_host_id(host_id, hostname=hostname, correlation_id=correlation_id)

    def _get_for_host_id(
        self,
        host_id: int,
        *,
        hostname: str,
        correlation_id: str | None,
    ) -> LocRecord | None:
        """Return the LOC record for one resolved host ID."""
        data = self._client.get_json(
            "/api/v1/locs/",
            params={"host": str(host_id)},
            correlation_id=correlation_id,
        )
        records = [
            self._parse_loc_payload(item, endpoint="/api/v1/locs/", method=RequestMethod.GET)
            for item in extract_results(data, endpoint="/api/v1/locs/")
        ]
        if not records:
            return None
        if len(records) > 1:
            raise ResponseDecodeError(
                f"MREG returned multiple LOC records for host {hostname!r}",
                method=RequestMethod.GET,
                endpoint="/api/v1/locs/",
            )
        return records[0]

    def add(
        self,
        hostname: str,
        value: str,
        *,
        correlation_id: str | None = None,
    ) -> LocRecord:
        """Add one LOC record to a host.

        LOC behaves as a singleton. When create returns an empty success
        response, this method verifies through the same singleton lookup path
        used by ``get()``.
        """
        _, host_id = get_host_and_id(
            self._queries,
            hostname,
            correlation_id=correlation_id,
            endpoint=f"/api/v1/hosts/{hostname}",
        )
        existing = self._get_for_host_id(
            host_id,
            hostname=hostname,
            correlation_id=correlation_id,
        )
        if existing is not None:
            if existing.value == value:
                return existing
            raise ConflictError(
                f"Host {hostname!r} already has LOC set",
                method=RequestMethod.GET,
                endpoint="/api/v1/locs/",
            )

        created_payload = self._client.post_json(
            "/api/v1/locs/",
            json={"host": host_id, "loc": value},
            allow_empty=True,
            compatibility_fallback=CompatibilityFallback.FORM,
            correlation_id=correlation_id,
        )
        if isinstance(created_payload, dict):
            created = self._parse_loc_payload(
                created_payload,
                endpoint="/api/v1/locs/",
                method=RequestMethod.POST,
            )
            if created.host_id != host_id or created.value != value:
                raise ResponseDecodeError(
                    "MREG create response did not match the requested LOC record",
                    method=RequestMethod.POST,
                    endpoint="/api/v1/locs/",
                )
            return created
        if created_payload is not None:
            raise ResponseDecodeError(
                "MREG LOC create response did not match a supported JSON shape",
                method=RequestMethod.POST,
                endpoint="/api/v1/locs/",
            )
        try:
            created = self._get_for_host_id(
                host_id,
                hostname=hostname,
                correlation_id=correlation_id,
            )
        except NotFoundError as exc:
            raise RequestFailedError(
                "LOC create returned an empty success response, and verification "
                "did not find the new LOC record. Inspect MREG if needed, but "
                "this is treated as a failed create rather than an uncertain "
                "partial mutation.",
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/locs/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "LOC create reached MREG, but verification failed. Upstream "
                "state may be partially updated. Inspect the LOC record in "
                "MREG before deciding whether to retry.",
                operation="create_loc_record",
                completed_steps=(MutationStep("create_request"),),
                remaining_steps=(MutationStep("verify_created_loc_record"),),
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/locs/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        if created is None:
            raise RequestFailedError(
                "LOC create returned an empty success response, and verification "
                "did not find the new LOC record. Inspect MREG if needed, but "
                "this is treated as a failed create rather than an uncertain "
                "partial mutation.",
                method=RequestMethod.POST,
                endpoint="/api/v1/locs/",
                correlation_id=correlation_id,
            )
        return created

    def remove(self, hostname: str, *, correlation_id: str | None = None) -> None:
        """Remove the LOC record from one host."""
        record = self.get(hostname, correlation_id=correlation_id)
        if record is None:
            raise NotFoundError(
                f"Host {hostname!r} has no LOC record",
                method=RequestMethod.DELETE,
                endpoint="/api/v1/locs/",
            )
        if record.id is None:
            raise ResponseDecodeError(
                "MREG LOC payload did not include a record ID",
                method=RequestMethod.GET,
                endpoint="/api/v1/locs/",
            )
        self._client.delete_json(
            f"/api/v1/locs/{record.id}",
            correlation_id=correlation_id,
        )

    def _parse_loc_payload(
        self,
        payload: object,
        *,
        endpoint: str,
        method: RequestMethod,
    ) -> LocRecord:
        if not isinstance(payload, dict):
            raise ResponseDecodeError(
                "MREG LOC payload was not a JSON object",
                method=method,
                endpoint=endpoint,
            )
        payload_dict = cast(dict[str, Any], payload)
        loc_value = payload_dict.get("loc")
        if not isinstance(loc_value, str) or not loc_value.strip():
            raise ResponseDecodeError(
                "MREG LOC payload did not include a loc value",
                method=method,
                endpoint=endpoint,
            )
        return LocRecord(
            id=optional_int(payload_dict.get("id")),
            host_id=optional_int(payload_dict.get("host")),
            value=loc_value.strip(),
            raw=dict(payload_dict),
        )
