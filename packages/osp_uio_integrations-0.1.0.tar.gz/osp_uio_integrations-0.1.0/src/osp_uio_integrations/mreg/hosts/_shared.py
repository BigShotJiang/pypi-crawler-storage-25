"""Small shared helpers for host-domain modules.

Owns only the list-shape normalization and hostname comparison helpers already
used by multiple host and record modules. Anything larger belongs in the module
that needs it.
"""

from __future__ import annotations

from typing import Any, cast

from ..enums import RequestMethod
from ..exceptions import ResponseDecodeError


def extract_results(data: object, *, endpoint: str) -> list[dict[str, Any]]:
    """Normalize supported MREG list response shapes into payload items.

    Several MREG endpoints return either a raw list or an object with
    ``results``. The rest of the host layer should not need per-endpoint logic
    just to iterate over those items.
    """
    if isinstance(data, list):
        return [cast(dict[str, Any], item) for item in data if isinstance(item, dict)]
    if isinstance(data, dict):
        payload = cast(dict[str, Any], data)
        results = payload.get("results")
        if isinstance(results, list):
            return [cast(dict[str, Any], item) for item in results if isinstance(item, dict)]
    raise ResponseDecodeError(
        "MREG list response did not match a supported JSON shape",
        method=RequestMethod.GET,
        endpoint=endpoint,
    )


def normalize_hostname_for_compare(value: str) -> str:
    """Normalize hostnames for DNS-style equality checks.

    Trailing dots and case differences are not meaningful for DNS owner names
    and showing up as a string mismatch would be a foot-gun for callers that
    compare an input name against an upstream-normalized one.
    """
    return value.strip().rstrip(".").lower()
