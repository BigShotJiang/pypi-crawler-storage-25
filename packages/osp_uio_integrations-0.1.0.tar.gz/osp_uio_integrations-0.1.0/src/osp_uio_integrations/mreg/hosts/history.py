"""Host history retrieval and normalization.

This module owns the MREG host history lookup flow. It normalizes the upstream
history payloads into a stable library shape, but it does not render
human-readable CLI output.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Protocol, cast

from ..enums import RequestMethod
from ..exceptions import ResponseDecodeError
from .models import HostHistoryRecord
from .records._shared import extract_results

_HISTORY_ENDPOINT = "/api/v1/history/"
_HostHistoryList = list[HostHistoryRecord]


class _MregTransport(Protocol):
    """Minimal transport surface consumed by host history workflows."""

    def get_json(
        self,
        endpoint: str,
        *,
        params: dict[str, object] | None = None,
        soft_404: bool = False,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Return one decoded JSON object or list from the shared transport."""


class HostHistoryAPI:
    """Read-only access to normalized host history entries.

    MREG history lookups are slightly awkward because a useful host timeline
    spans direct history rows plus related rows keyed by model ids and relation
    fields. This class owns that aggregation so callers can ask one question,
    "give me host history", and get back one stable chronological result.
    """

    def __init__(self, client: _MregTransport) -> None:
        """Initialize the host history API."""
        self._client = client

    def many(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> _HostHistoryList:
        """Return normalized history entries for one host name.

        The MREG CLI fetches history in three passes so it can include direct
        host history rows as well as related rows keyed by model id or relation.
        This method keeps that lookup behavior while returning stable library
        records instead of CLI-formatted text.

        The first pass is intentionally load-bearing for the model-id lookups
        that drive the follow-up passes. A host with no direct history rows
        cannot fan out to those follow-up queries, and the library treats that
        as an empty timeline rather than as a missing host: history retention
        is independent from host existence and an empty result is the most
        useful, least surprising thing to return.
        """
        entries = self._fetch_entries(
            params={"resource": "host", "name": hostname},
            correlation_id=correlation_id,
        )
        if not entries:
            return []

        unique_model_ids = sorted({entry.model_id for entry in entries})
        model_ids = ",".join(str(model_id) for model_id in unique_model_ids)
        combined = list(entries)
        combined.extend(
            self._fetch_entries(
                params={"resource": "host", "model_id__in": model_ids},
                correlation_id=correlation_id,
            )
        )
        combined.extend(
            self._fetch_entries(
                params={"data__relation": "hosts", "data__id__in": model_ids},
                correlation_id=correlation_id,
            )
        )
        return sorted(
            _dedupe_entries(combined),
            key=lambda entry: (entry.timestamp, entry.id),
        )

    def _fetch_entries(
        self,
        *,
        params: dict[str, object],
        correlation_id: str | None,
    ) -> _HostHistoryList:
        """Fetch and normalize one history query result set."""
        data = self._client.get_json(
            _HISTORY_ENDPOINT,
            params=params,
            correlation_id=correlation_id,
        )
        return [
            self._parse_history_payload(item, endpoint=_HISTORY_ENDPOINT)
            for item in extract_results(data, endpoint=_HISTORY_ENDPOINT)
        ]

    def _parse_history_payload(
        self,
        payload: object,
        *,
        endpoint: str,
    ) -> HostHistoryRecord:
        """Interpret one MREG history payload into the stable library shape."""
        if not isinstance(payload, dict):
            raise ResponseDecodeError(
                "MREG history payload was not a JSON object",
                method=RequestMethod.GET,
                endpoint=endpoint,
            )

        payload_dict = cast(dict[str, Any], payload)
        entry_id = _require_int(
            payload_dict.get("id"),
            field="id",
            endpoint=endpoint,
        )
        timestamp = _parse_timestamp(
            payload_dict.get("timestamp"),
            endpoint=endpoint,
        )
        user = _require_string(
            payload_dict.get("user"),
            field="user",
            endpoint=endpoint,
        )
        resource = _require_string(
            payload_dict.get("resource"),
            field="resource",
            endpoint=endpoint,
        )
        name = _require_string(
            payload_dict.get("name"),
            field="name",
            endpoint=endpoint,
        )
        model_id = _require_int(
            payload_dict.get("model_id"),
            field="model_id",
            endpoint=endpoint,
        )
        model = _require_string(
            payload_dict.get("model"),
            field="model",
            endpoint=endpoint,
        )
        action = _require_string(
            payload_dict.get("action"),
            field="action",
            endpoint=endpoint,
        )
        data = _parse_history_data(
            payload_dict.get("data"),
            endpoint=endpoint,
        )
        return HostHistoryRecord(
            id=entry_id,
            timestamp=timestamp,
            user=user,
            resource=resource,
            name=name,
            model_id=model_id,
            model=model,
            action=action,
            data=data,
            raw=dict(payload_dict),
        )


def _dedupe_entries(
    entries: _HostHistoryList,
) -> _HostHistoryList:
    """Return one copy of each history entry keyed by upstream history ID."""
    seen: set[int] = set()
    deduped: list[HostHistoryRecord] = []
    for entry in entries:
        if entry.id in seen:
            continue
        seen.add(entry.id)
        deduped.append(entry)
    return deduped


def _require_string(
    value: object,
    *,
    field: str,
    endpoint: str,
) -> str:
    """Require one non-empty string field from a history payload."""
    if isinstance(value, str) and value.strip():
        return value.strip()
    raise ResponseDecodeError(
        f"MREG history payload did not include a valid {field} value",
        method=RequestMethod.GET,
        endpoint=endpoint,
    )


def _require_int(
    value: object,
    *,
    field: str,
    endpoint: str,
) -> int:
    """Require one integer field from a history payload."""
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.isdigit():
        return int(value)
    raise ResponseDecodeError(
        f"MREG history payload did not include a valid {field} value",
        method=RequestMethod.GET,
        endpoint=endpoint,
    )


def _parse_timestamp(
    value: object,
    *,
    endpoint: str,
) -> datetime:
    """Parse one upstream history timestamp into a timezone-aware datetime."""
    if not isinstance(value, str) or not value.strip():
        raise ResponseDecodeError(
            "MREG history payload did not include a timestamp",
            method=RequestMethod.GET,
            endpoint=endpoint,
        )
    normalized = value.strip().replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise ResponseDecodeError(
            "MREG history payload did not include a valid timestamp",
            method=RequestMethod.GET,
            endpoint=endpoint,
        ) from exc


def _parse_history_data(
    value: object,
    *,
    endpoint: str,
) -> dict[str, Any]:
    """Parse the `data` field into a stable dictionary shape."""
    if isinstance(value, dict):
        return dict(cast(dict[str, Any], value))
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError as exc:
            raise ResponseDecodeError(
                "MREG history payload did not contain valid JSON data",
                method=RequestMethod.GET,
                endpoint=endpoint,
            ) from exc
        if isinstance(parsed, dict):
            return dict(cast(dict[str, Any], parsed))
    raise ResponseDecodeError(
        "MREG history payload did not include a supported data shape",
        method=RequestMethod.GET,
        endpoint=endpoint,
    )
