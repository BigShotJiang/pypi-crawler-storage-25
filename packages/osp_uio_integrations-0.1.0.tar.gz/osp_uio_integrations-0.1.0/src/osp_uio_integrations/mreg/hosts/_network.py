"""Compatibility wrapper around the public network payload parser.

Host-domain modules historically imported the tiny shared `NetworkRecord` and
`parse_network_payload` helpers from here. The public network facade now owns
the canonical model, but the host modules still use this wrapper so their
internal imports do not need to know about the wider package surface.
"""

from ..networks.api import parse_network_payload
from ..networks.models import NetworkRecord

__all__ = ["NetworkRecord", "parse_network_payload"]
