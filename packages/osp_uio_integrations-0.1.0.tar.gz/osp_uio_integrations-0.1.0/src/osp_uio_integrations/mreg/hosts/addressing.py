"""Host IP addressing operations.

This module owns the host-side A and AAAA workflows ported from ``mreg-cli``:
show, add, change, move, and remove for IPv4 and IPv6 addresses. It keeps the
MREG-specific validation rules close to the addressing transport calls, while
still separating the pure validation helpers from the request-heavy methods.

It does not try to be a generic network library. The only network and PTR
shapes defined here are the small internal pieces needed to support the host
address workflows. In particular, address move keeps the same linear
"move address, then move PTR override" behavior as ``mreg-cli`` and reports
partial success explicitly instead of attempting rollback.
"""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass
from typing import Any, Protocol, cast
from urllib.parse import quote

from ..enums import AddressFamily, CompatibilityFallback, RequestMethod, ValidationSource
from ..exceptions import (
    ConflictError,
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
)
from ._network import NetworkRecord, parse_network_payload
from ._shared import normalize_hostname_for_compare
from .models import AddressMoveResult, AddressRecord, HostRecord
from .queries import HostQueries


class _MregTransport(Protocol):
    """Minimal transport surface consumed by host addressing workflows."""

    def get_json(
        self,
        endpoint: str,
        *,
        params: dict[str, object] | None = None,
        soft_404: bool = False,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Return one decoded JSON object or list from the shared transport."""

    def get_json_value(
        self,
        endpoint: str,
        *,
        params: dict[str, object] | None = None,
        soft_404: bool = False,
        correlation_id: str | None = None,
    ) -> object | None:
        """Return one decoded JSON value from the shared transport."""

    def get_json_str(
        self,
        endpoint: str,
        *,
        params: dict[str, object] | None = None,
        soft_404: bool = False,
        correlation_id: str | None = None,
    ) -> str | None:
        """Return one decoded JSON string from the shared transport."""

    def post_json(
        self,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, object] | None = None,
        compatibility_fallback: CompatibilityFallback | None = None,
        allow_empty: bool = False,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Issue one JSON-backed POST request."""

    def patch_json(
        self,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, object] | None = None,
        compatibility_fallback: CompatibilityFallback | None = None,
        allow_empty: bool = False,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Issue one JSON-backed PATCH request."""

    def delete_json(
        self,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, object] | None = None,
        correlation_id: str | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Issue one DELETE request through the shared transport."""


@dataclass(frozen=True, slots=True)
class _PtrOverrideRecord:
    """Minimal PTR override shape needed by IP move flows."""

    id: int | None
    ipaddress: str


class HostAddressingAPI:
    """Host-facing API for A and AAAA record workflows.

    The original CLI mixed command parsing, output rendering, validation, and
    transport in the same handlers. This class keeps the same operational
    behavior but recenters it around library contracts:

    - callers work with hosts and canonical IP strings
    - local guard checks raise stable local exceptions before write calls
    - endpoint quirks such as first-unused lookup and PTR co-moves stay local
      to this addressing boundary
    """

    def __init__(self, client: _MregTransport, queries: HostQueries) -> None:
        """Initialize the addressing API."""
        self._client = client
        self._queries = queries

    def show_ipv4(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> list[AddressRecord]:
        """Return the host IPv4 address records."""
        return self._show(hostname, family=AddressFamily.IPV4, correlation_id=correlation_id)

    def show_ipv6(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> list[AddressRecord]:
        """Return the host IPv6 address records."""
        return self._show(hostname, family=AddressFamily.IPV6, correlation_id=correlation_id)

    def add_ipv4(
        self,
        hostname: str,
        ip_or_network: str,
        *,
        macaddress: str | None = None,
        force: bool = False,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Add an IPv4 address to a host."""
        return self._add(
            hostname,
            ip_or_network,
            family=AddressFamily.IPV4,
            macaddress=macaddress,
            force=force,
            correlation_id=correlation_id,
        )

    def add_ipv6(
        self,
        hostname: str,
        ip_or_network: str,
        *,
        macaddress: str | None = None,
        force: bool = False,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Add an IPv6 address to a host."""
        return self._add(
            hostname,
            ip_or_network,
            family=AddressFamily.IPV6,
            macaddress=macaddress,
            force=force,
            correlation_id=correlation_id,
        )

    def change_ipv4(
        self,
        hostname: str,
        *,
        old_ip: str,
        new_ip_or_network: str,
        force: bool = False,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Change one IPv4 address on a host."""
        return self._change(
            hostname,
            old_ip=old_ip,
            new_ip_or_network=new_ip_or_network,
            family=AddressFamily.IPV4,
            force=force,
            correlation_id=correlation_id,
        )

    def change_ipv6(
        self,
        hostname: str,
        *,
        old_ip: str,
        new_ip_or_network: str,
        force: bool = False,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Change one IPv6 address on a host."""
        return self._change(
            hostname,
            old_ip=old_ip,
            new_ip_or_network=new_ip_or_network,
            family=AddressFamily.IPV6,
            force=force,
            correlation_id=correlation_id,
        )

    def remove_ipv4(
        self,
        hostname: str,
        ipaddress_value: str,
        *,
        force: bool = False,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Remove one IPv4 address from a host."""
        return self._remove(
            hostname,
            ipaddress_value=ipaddress_value,
            family=AddressFamily.IPV4,
            force=force,
            correlation_id=correlation_id,
        )

    def remove_ipv6(
        self,
        hostname: str,
        ipaddress_value: str,
        *,
        force: bool = False,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Remove one IPv6 address from a host."""
        return self._remove(
            hostname,
            ipaddress_value=ipaddress_value,
            family=AddressFamily.IPV6,
            force=force,
            correlation_id=correlation_id,
        )

    def move_ipv4(
        self,
        ipaddress_value: str,
        *,
        from_host: str,
        to_host: str,
        correlation_id: str | None = None,
    ) -> AddressMoveResult:
        """Move one IPv4 address to another host, including any PTR override."""
        return self._move(
            ipaddress_value,
            family=AddressFamily.IPV4,
            from_host=from_host,
            to_host=to_host,
            correlation_id=correlation_id,
        )

    def move_ipv6(
        self,
        ipaddress_value: str,
        *,
        from_host: str,
        to_host: str,
        correlation_id: str | None = None,
    ) -> AddressMoveResult:
        """Move one IPv6 address to another host, including any PTR override."""
        return self._move(
            ipaddress_value,
            family=AddressFamily.IPV6,
            from_host=from_host,
            to_host=to_host,
            correlation_id=correlation_id,
        )

    def _show(
        self,
        hostname: str,
        *,
        family: AddressFamily,
        correlation_id: str | None,
    ) -> list[AddressRecord]:
        """Return host addresses filtered by family."""
        host = self._queries.get_required(hostname, correlation_id=correlation_id)
        return [
            address
            for address in _parse_host_addresses(host)
            if address.family == family
        ]

    def _add(
        self,
        hostname: str,
        ip_or_network: str,
        *,
        family: AddressFamily,
        macaddress: str | None,
        force: bool,
        correlation_id: str | None,
    ) -> HostRecord:
        """Add one address to a host after resolving MREG-specific guard rules.

        The method accepts either a concrete IP address or a network string.
        Network input is resolved through MREG's first-unused lookup so callers
        do not have to reimplement that workflow themselves.

        Args:
            hostname: Host that should receive the new address.
            ip_or_network: Concrete IP address or network identifier.
            family: Requested address family for the operation.
            macaddress: Optional MAC address to attach when supported by MREG.
            force: Whether to bypass local guard checks that normally require
                explicit user intent.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            Refetched normalized host record after the add operation completes.
        """
        host = self._queries.get_required(hostname, correlation_id=correlation_id)
        host_id = _require_host_id(host=host, endpoint=f"/api/v1/hosts/{hostname}")
        target_ip, network = self._resolve_target_ip(
            ip_or_network,
            family=family,
            correlation_id=correlation_id,
        )

        _validate_add(
            host=host,
            target_ip=target_ip,
            network=network,
            in_use=self._list_hosts_by_ip(target_ip, correlation_id=correlation_id),
            force=force,
            family=family,
        )

        payload: dict[str, object] = {"ipaddress": target_ip, "host": str(host_id)}
        if macaddress:
            payload["macaddress"] = macaddress

        created_payload = self._client.post_json(
            "/api/v1/ipaddresses/",
            json=payload,
            allow_empty=True,
            compatibility_fallback=CompatibilityFallback.FORM,
            correlation_id=correlation_id,
        )
        if isinstance(created_payload, dict) and _looks_like_host_payload(created_payload):
            return self._queries.parse_host_payload(
                created_payload,
                endpoint="/api/v1/ipaddresses/",
                method=RequestMethod.POST,
            )
        if created_payload is not None and not isinstance(created_payload, dict):
            raise ResponseDecodeError(
                "MREG IP address create response did not match a supported JSON shape",
                method=RequestMethod.POST,
                endpoint="/api/v1/ipaddresses/",
            )
        return self._queries.get_required(hostname, correlation_id=correlation_id)

    def _change(
        self,
        hostname: str,
        *,
        old_ip: str,
        new_ip_or_network: str,
        family: AddressFamily,
        force: bool,
        correlation_id: str | None,
    ) -> HostRecord:
        """Change one host address while preserving MREG validation semantics.

        The existing address is resolved from the normalized host shape first,
        then the destination is validated using the same local guard rules as
        the CLI surface before the patch request is sent upstream.

        Args:
            hostname: Host whose address should be changed.
            old_ip: Existing address currently attached to the host.
            new_ip_or_network: Concrete replacement IP or network identifier
                used for first-free allocation.
            family: Requested address family for the operation.
            force: Whether to bypass local network and ownership guard checks.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            Refetched normalized host record after the change completes.
        """
        host = self._queries.get_required(hostname, correlation_id=correlation_id)
        address = _require_host_address(host=host, ipaddress_value=old_ip, family=family)
        target_ip, network = self._resolve_target_ip(
            new_ip_or_network,
            family=family,
            correlation_id=correlation_id,
        )

        _validate_change(
            host=host,
            current_ip=address.ipaddress,
            target_ip=target_ip,
            network=network,
            in_use=self._list_hosts_by_ip(target_ip, correlation_id=correlation_id),
            force=force,
            family=family,
        )

        address_id = _require_address_id(address, endpoint=f"/api/v1/ipaddresses/{old_ip}")
        self._client.patch_json(
            f"/api/v1/ipaddresses/{address_id}",
            json={"ipaddress": target_ip},
            allow_empty=True,
            correlation_id=correlation_id,
        )
        return self._queries.get_required(hostname, correlation_id=correlation_id)

    def _remove(
        self,
        hostname: str,
        *,
        ipaddress_value: str,
        family: AddressFamily,
        force: bool,
        correlation_id: str | None,
    ) -> HostRecord:
        """Remove one address from a host with alias-safety checks.

        Removing an address through a CNAME-resolved host name can be
        surprising, so the library makes that path explicit and requires
        ``force`` before continuing.
        """
        host = self._queries.get_required(hostname, correlation_id=correlation_id)
        address = _require_host_address(host=host, ipaddress_value=ipaddress_value, family=family)

        if not force and _host_was_fetched_via_cname(hostname, host):
            raise ValidationError(
                f"{hostname!r} resolves as a CNAME for {host.name!r}; force is required",
                source=ValidationSource.LOCAL,
                method=RequestMethod.DELETE,
                endpoint=f"/api/v1/ipaddresses/{ipaddress_value}",
            )

        address_id = _require_address_id(address, endpoint=f"/api/v1/ipaddresses/{ipaddress_value}")
        self._client.delete_json(
            f"/api/v1/ipaddresses/{address_id}",
            correlation_id=correlation_id,
        )
        return self._queries.get_required(host.name, correlation_id=correlation_id)

    def _move(
        self,
        ipaddress_value: str,
        *,
        family: AddressFamily,
        from_host: str,
        to_host: str,
        correlation_id: str | None,
    ) -> AddressMoveResult:
        """Move one address, and any linked PTR override, between hosts.

        The MREG CLI treats address movement as a coupled workflow: the address
        changes owner, and a PTR override for the same IP should move with it
        when present. Keeping that coupling here makes the library surface
        explicit instead of forcing callers to rediscover it.

        Args:
            ipaddress_value: Canonical IP string to move.
            family: Required address family for the move operation.
            from_host: Current owner of the address.
            to_host: Destination host that should receive the address.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            Structured result describing whether the IP and PTR override moved.
            This object is a success-path shape only. If an earlier step
            succeeds and a later step fails, the method raises
            ``MutationStateUncertainError`` instead of returning partial
            success through ``AddressMoveResult``.
        """
        _require_address_family(ipaddress_value, family=family)
        source_host = self._queries.get_required(from_host, correlation_id=correlation_id)
        destination_host = self._queries.get_required(to_host, correlation_id=correlation_id)
        source_host_id = _require_host_id(source_host, endpoint=f"/api/v1/hosts/{from_host}")
        destination_host_id = _require_host_id(
            destination_host,
            endpoint=f"/api/v1/hosts/{to_host}",
        )
        address = _find_host_address(
            source_host,
            ipaddress_value,
            family=family,
        )
        ptr_override = _find_ptr_override(source_host, ipaddress_value)
        if address is None and ptr_override is None:
            raise NotFoundError(
                f"Host {source_host.name!r} has no IP or PTR override with address "
                f"{ipaddress_value}",
                method=RequestMethod.GET,
                endpoint=f"/api/v1/hosts/{from_host}",
            )
        if source_host_id == destination_host_id:
            return AddressMoveResult(
                ipaddress=ipaddress_value,
                moved_ip=False,
                moved_ptr_override=False,
            )

        completed_steps: list[MutationStep] = []
        moved_ip = False
        if address is not None:
            address_id = _require_address_id(
                address,
                endpoint=f"/api/v1/ipaddresses/{ipaddress_value}",
            )
            self._client.patch_json(
                f"/api/v1/ipaddresses/{address_id}",
                json={"host": destination_host_id},
                allow_empty=True,
                correlation_id=correlation_id,
            )
            moved_ip = True
            completed_steps.append(MutationStep("move_ip"))

        moved_ptr_override = False
        if ptr_override is not None:
            ptr_id = _require_ptr_override_id(
                ptr_override,
                endpoint=f"/api/v1/ptroverrides/{ipaddress_value}",
            )
            try:
                self._client.patch_json(
                    f"/api/v1/ptroverrides/{ptr_id}",
                    json={"host": destination_host_id},
                    allow_empty=True,
                    correlation_id=correlation_id,
                )
            except RequestFailedError as exc:
                if completed_steps:
                    raise MutationStateUncertainError(
                        "Moved IP address ownership, but failed to move the "
                        "PTR override. Upstream state may be partially "
                        "updated. Inspect both hosts and confirm the PTR "
                        "override state in MREG before deciding whether to retry.",
                        operation="move_address_and_ptr",
                        completed_steps=tuple(completed_steps),
                        remaining_steps=(MutationStep("move_ptr_override"),),
                        method=RequestMethod.PATCH,
                        status_code=exc.status_code,
                        endpoint=f"/api/v1/ptroverrides/{ptr_id}",
                        request_id=exc.request_id,
                        correlation_id=exc.correlation_id or correlation_id,
                    ) from exc
                raise
            moved_ptr_override = True
            completed_steps.append(MutationStep("move_ptr_override"))

        return AddressMoveResult(
            ipaddress=ipaddress_value,
            moved_ip=moved_ip,
            moved_ptr_override=moved_ptr_override,
        )

    def _resolve_target_ip(
        self,
        ip_or_network: str,
        *,
        family: AddressFamily,
        correlation_id: str | None,
    ) -> tuple[str, NetworkRecord | None]:
        """Resolve address input into one concrete target IP plus network state.

        Direct IP input is normalized and paired with the containing network
        when MREG knows about one. Network input is turned into a concrete IP
        through MREG's ``first_unused`` endpoint so the caller can use the same
        interface for both fixed and allocated addressing.

        Args:
            ip_or_network: Caller-supplied address or network string.
            family: Expected address family for the operation.
            correlation_id: Optional logical operation id for tracing the
                supporting network lookup.

        Returns:
            Tuple of ``(target_ip, network)`` where ``network`` is ``None``
            only when the input was a direct IP outside known MREG networks.
        """
        parsed = _parse_ip_or_network(ip_or_network, family=family)
        if isinstance(parsed, ipaddress._BaseAddress):
            network = self._get_network_by_ip(str(parsed), correlation_id=correlation_id)
            return str(parsed), network

        network = self._get_network_by_network(str(parsed), correlation_id=correlation_id)
        first_unused = self._client.get_json_str(
            f"/api/v1/networks/{quote(network.network, safe='')}/first_unused",
            correlation_id=correlation_id,
        )
        if first_unused is None:
            raise ResponseDecodeError(
                "MREG first_unused response did not contain an IP address string",
                method=RequestMethod.GET,
                endpoint=f"/api/v1/networks/{quote(network.network, safe='')}/first_unused",
            )
        _require_address_family(first_unused, family=family)
        return first_unused, network

    def _get_network_by_ip(
        self,
        ipaddress_value: str,
        *,
        correlation_id: str | None,
    ) -> NetworkRecord | None:
        """Fetch the network containing one IP address."""
        data = self._client.get_json(
            f"/api/v1/networks/ip/{ipaddress_value}",
            soft_404=True,
            correlation_id=correlation_id,
        )
        if not data:
            return None
        return parse_network_payload(data, endpoint=f"/api/v1/networks/ip/{ipaddress_value}")

    def _get_network_by_network(
        self,
        network_value: str,
        *,
        correlation_id: str | None,
    ) -> NetworkRecord:
        """Fetch one network by its network identifier.

        Network-based allocation cannot proceed without a concrete upstream
        network object, so this path intentionally lets the shared client raise
        ``NotFoundError`` instead of softening the ``404`` locally.
        """
        endpoint = f"/api/v1/networks/{quote(network_value, safe='')}"
        data = self._client.get_json(
            endpoint,
            correlation_id=correlation_id,
        )
        return parse_network_payload(data, endpoint=endpoint)

    def _list_hosts_by_ip(
        self,
        ipaddress_value: str,
        *,
        correlation_id: str | None,
    ) -> list[HostRecord]:
        """Return hosts currently using an IP address."""
        return self._queries.many(
            params={"ipaddresses__ipaddress": ipaddress_value},
            correlation_id=correlation_id,
        )


def _parse_ip_or_network(
    value: str,
    *,
    family: AddressFamily,
) -> ipaddress._BaseAddress | ipaddress._BaseNetwork:
    """Parse an IP or network string while enforcing the requested family.

    Trailing ``/`` and host-prefix forms (``/32`` for IPv4, ``/128`` for IPv6)
    are treated as direct IP input so callers do not need to strip them
    themselves and so the upstream first-unused lookup is not invoked for what
    is really a fixed-address request.
    """
    normalized = value.strip()
    if normalized.endswith("/"):
        normalized = normalized.rstrip("/")
    try:
        if "/" in normalized:
            parsed_network = ipaddress.ip_network(normalized, strict=False)
            _require_parsed_family(parsed_network, family=family)
            if parsed_network.prefixlen == parsed_network.max_prefixlen:
                return parsed_network.network_address
            return parsed_network
        parsed_ip = ipaddress.ip_address(normalized)
    except ValueError as exc:
        raise ValidationError(
            f"{value!r} is not a valid IP address or network",
            source=ValidationSource.LOCAL,
        ) from exc
    _require_parsed_family(parsed_ip, family=family)
    return parsed_ip


def _require_address_family(ipaddress_value: str, *, family: AddressFamily) -> None:
    """Require that one IP string matches the requested address family."""
    parsed = ipaddress.ip_address(ipaddress_value)
    _require_parsed_family(parsed, family=family)


def _require_parsed_family(
    parsed: ipaddress._BaseAddress | ipaddress._BaseNetwork,
    *,
    family: AddressFamily,
) -> None:
    """Require that one parsed IP object matches the requested family."""
    if family == AddressFamily.IPV4 and parsed.version != 4:
        raise ValidationError(
            "IPv4 operation received an IPv6 address or network",
            source=ValidationSource.LOCAL,
        )
    if family == AddressFamily.IPV6 and parsed.version != 6:
        raise ValidationError(
            "IPv6 operation received an IPv4 address or network",
            source=ValidationSource.LOCAL,
        )


def _validate_add(
    *,
    host: HostRecord,
    target_ip: str,
    network: NetworkRecord | None,
    in_use: list[HostRecord],
    force: bool,
    family: AddressFamily,
) -> None:
    """Validate an address-add operation before writing to MREG.

    The rules mirror the CLI's safety posture: unless ``force`` is in use, the
    host must not already have another address, the target address must belong
    to a managed, non-frozen network, it cannot be the network or broadcast
    boundary address, and it cannot already belong to another host.

    Raises:
        ConflictError: The target address is already attached to the same host
            or the request is otherwise self-conflicting.
        ValidationError: Local guard rules reject the add operation.
    """
    if any(existing.name == host.name and target_ip in existing.ipaddresses for existing in in_use):
        raise ConflictError(f"Host {host.name!r} already has IP {target_ip}")
    if not force and host.ipaddresses:
        raise ValidationError(
            f"Host {host.name!r} already has one or more IP addresses; force is required",
            source=ValidationSource.LOCAL,
            method=RequestMethod.POST,
            endpoint="/api/v1/ipaddresses/",
        )
    _validate_target_ip_claim(
        host=host,
        target_ip=target_ip,
        network=network,
        in_use=in_use,
        force=force,
        family=family,
        method=RequestMethod.POST,
        endpoint="/api/v1/ipaddresses/",
    )


def _validate_change(
    *,
    host: HostRecord,
    current_ip: str,
    target_ip: str,
    network: NetworkRecord | None,
    in_use: list[HostRecord],
    force: bool,
    family: AddressFamily,
) -> None:
    """Validate an address-change operation before writing to MREG.

    Change validation intentionally stays separate from add validation because
    equality with the old address is a conflict and because some caller intent
    is different when mutating an existing address versus attaching a new one.

    Raises:
        ConflictError: The requested new address is equal to the old address or
            already belongs to the same host.
        ValidationError: Local network or ownership guard rules reject the
            change operation.
    """
    if current_ip == target_ip:
        raise ConflictError("Old and new IP are equal")
    _validate_target_ip_claim(
        host=host,
        target_ip=target_ip,
        network=network,
        in_use=in_use,
        force=force,
        family=family,
        method=RequestMethod.PATCH,
        endpoint=f"/api/v1/ipaddresses/{current_ip}",
    )


def _validate_target_ip_claim(
    *,
    host: HostRecord,
    target_ip: str,
    network: NetworkRecord | None,
    in_use: list[HostRecord],
    force: bool,
    family: AddressFamily,
    method: RequestMethod,
    endpoint: str,
) -> None:
    """Validate the shared target-IP rules used by add and change operations."""
    if force:
        return
    if network is None:
        raise ValidationError(
            f"Network for {target_ip} was not found; force is required",
            source=ValidationSource.LOCAL,
            method=method,
            endpoint=endpoint,
        )
    if network.frozen:
        raise ValidationError(
            f"Network {network.network} is frozen; force is required",
            source=ValidationSource.LOCAL,
            method=method,
            endpoint=endpoint,
        )
    if target_ip in host.ipaddresses:
        raise ConflictError(f"Host {host.name!r} already has IP {target_ip}")
    _validate_network_boundary(
        target_ip,
        network=network,
        family=family,
        method=method,
    )
    other_hosts = [existing.name for existing in in_use if existing.name != host.name]
    if other_hosts:
        owners = ", ".join(sorted(other_hosts))
        raise ValidationError(
            f"IP {target_ip} is already in use by {owners}; force is required",
            source=ValidationSource.LOCAL,
            method=method,
            endpoint=endpoint,
        )


def _validate_network_boundary(
    target_ip: str,
    *,
    network: NetworkRecord,
    family: AddressFamily,
    method: RequestMethod,
) -> None:
    """Reject network and broadcast addresses when force is not in use."""
    if target_ip == network.network_address:
        raise ValidationError(
            f"IP {target_ip} is the network address of {network.network}; force is required",
            source=ValidationSource.LOCAL,
            method=method,
        )
    if (
        family == AddressFamily.IPV4
        and network.broadcast_address is not None
        and target_ip == network.broadcast_address
    ):
        raise ValidationError(
            f"IP {target_ip} is the broadcast address of {network.network}; force is required",
            source=ValidationSource.LOCAL,
            method=method,
        )


def _parse_host_addresses(
    host: HostRecord,
    *,
    strict: bool = False,
    endpoint: str | None = None,
) -> list[AddressRecord]:
    """Parse address records from the raw host payload.

    The normalized ``HostRecord.ipaddresses`` tuple is enough for simple read
    operations, but write workflows also need per-address metadata such as
    upstream address ids and MAC addresses. ``AddressRecord.family`` is still
    derived on the model itself from the canonical IP string, so this helper
    only needs to normalize the payload into a richer address view.

    When ``strict`` is enabled, malformed upstream address entries raise
    ``ResponseDecodeError`` instead of being silently dropped. Mutation paths
    use that stricter mode so corrupted host payloads do not hide behind a
    "missing address" result.
    """
    ipaddresses = host.raw.get("ipaddresses")
    if not isinstance(ipaddresses, list):
        return []
    records: list[AddressRecord] = []
    for item in ipaddresses:
        if not isinstance(item, dict):
            if strict:
                _raise_address_payload_error(
                    "MREG host payload contained a non-object address entry",
                    endpoint=endpoint or f"/api/v1/hosts/{host.name}",
                )
            continue
        ip_value = item.get("ipaddress")
        if not isinstance(ip_value, str) or not ip_value.strip():
            if strict:
                _raise_address_payload_error(
                    "MREG host payload contained an address entry without an IP value",
                    endpoint=endpoint or f"/api/v1/hosts/{host.name}",
                )
            continue
        mac_value = item.get("macaddress")
        macaddress = None
        if isinstance(mac_value, str) and mac_value.strip():
            macaddress = mac_value.strip()
        records.append(
            AddressRecord(
                id=_optional_int(item.get("id")),
                ipaddress=ip_value.strip(),
                macaddress=macaddress,
                raw=dict(cast(dict[str, Any], item)),
            )
        )
    return records


def _require_host_address(
    host: HostRecord,
    ipaddress_value: str,
    *,
    family: AddressFamily,
) -> AddressRecord:
    """Return one concrete host address record or raise when absent.

    Addressing mutations rely on upstream address ids, so this helper upgrades
    the plain host view into the richer address record required for write
    operations.
    """
    _require_address_family(ipaddress_value, family=family)
    for address in _parse_host_addresses(
        host,
        strict=True,
        endpoint=f"/api/v1/hosts/{host.name}",
    ):
        if address.ipaddress == ipaddress_value:
            if address.family != family:
                break
            return address
    raise NotFoundError(
        f"Host {host.name!r} does not have IP {ipaddress_value}",
        method=RequestMethod.GET,
        endpoint=f"/api/v1/hosts/{host.name}",
    )


def _find_host_address(
    host: HostRecord,
    ipaddress_value: str,
    *,
    family: AddressFamily,
) -> AddressRecord | None:
    """Return one concrete host address record when present."""
    _require_address_family(ipaddress_value, family=family)
    for address in _parse_host_addresses(
        host,
        strict=True,
        endpoint=f"/api/v1/hosts/{host.name}",
    ):
        if address.ipaddress == ipaddress_value and address.family == family:
            return address
    return None


def _find_ptr_override(host: HostRecord, ipaddress_value: str) -> _PtrOverrideRecord | None:
    """Return the PTR override for one IP if present."""
    ptr_overrides = host.raw.get("ptr_overrides")
    if not isinstance(ptr_overrides, list):
        return None
    for item in ptr_overrides:
        if not isinstance(item, dict):
            continue
        ptr_ip = item.get("ipaddress")
        if ptr_ip != ipaddress_value:
            continue
        return _PtrOverrideRecord(
            id=_optional_int(item.get("id")),
            ipaddress=ipaddress_value,
        )
    return None


def _require_host_id(host: HostRecord, *, endpoint: str) -> int:
    """Require a parsed host ID for host-linked mutations."""
    if isinstance(host.id, int):
        return host.id
    raise ResponseDecodeError(
        "MREG host payload did not include a host ID",
        method=RequestMethod.GET,
        endpoint=endpoint,
    )


def _require_address_id(address: AddressRecord, *, endpoint: str) -> int:
    """Require an address ID for address mutations."""
    if isinstance(address.id, int):
        return address.id
    raise ResponseDecodeError(
        "MREG address payload did not include an address ID",
        method=RequestMethod.GET,
        endpoint=endpoint,
    )


def _require_ptr_override_id(ptr: _PtrOverrideRecord, *, endpoint: str) -> int:
    """Require a PTR override ID for PTR move operations."""
    if isinstance(ptr.id, int):
        return ptr.id
    raise ResponseDecodeError(
        "MREG PTR override payload did not include an override ID",
        method=RequestMethod.GET,
        endpoint=endpoint,
    )


def _optional_int(value: object) -> int | None:
    """Normalize optional integer fields from MREG payloads."""
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.isdigit():
        return int(value)
    return None


def _looks_like_host_payload(payload: dict[str, Any]) -> bool:
    """Return whether one decoded payload looks like a host record response."""
    for key in ("name", "hostname", "host"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return True
    return False


def _host_was_fetched_via_cname(original_name: str, host: HostRecord) -> bool:
    """Return whether the requested name resolved to another host name."""
    return normalize_hostname_for_compare(
        original_name,
    ) != normalize_hostname_for_compare(host.name)


def _raise_address_payload_error(message: str, *, endpoint: str) -> None:
    """Raise one stable decode error for malformed host address payloads."""
    raise ResponseDecodeError(
        message,
        method=RequestMethod.GET,
        endpoint=endpoint,
    )
