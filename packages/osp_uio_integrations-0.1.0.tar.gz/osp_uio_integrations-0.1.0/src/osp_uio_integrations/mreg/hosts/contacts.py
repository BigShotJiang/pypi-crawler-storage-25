"""Host contact mutation workflows.

This module owns the small but important contact-editing surface for hosts.
MREG exposes both full contact replacement on the host object and atomic
add/remove/clear operations through a dedicated contacts endpoint. The library
keeps those wire-level details in one place so callers can work with stable
lists of contact identifiers.

It deliberately stays narrow: this is about mutating and normalizing the host
contact field, not about contact directory policy or richer person objects.
When contact writes return an empty success response, this module refetches the
host only to recover a stable host-shaped result or to surface uncertain-state
verification failures honestly.
"""

from __future__ import annotations

from typing import Any

from ..enums import RequestMethod, ValidationSource
from ..exceptions import (
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ValidationError,
)
from .models import HostRecord
from .queries import HostQueries


class HostContactsAPI:
    """Host-facing API for contact list mutations.

    The methods here let callers work with stable lists of contact identifiers
    while the module owns the host patch contract plus the atomic contacts
    endpoint used for add/remove workflows.
    """

    def __init__(self, client: Any, queries: HostQueries) -> None:
        """Initialize the contacts API."""
        self._client = client
        self._queries = queries

    def set(
        self,
        hostname: str,
        contacts: list[str],
        *,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Replace the host contact list with the supplied identifiers.

        Callers provide logical contact identifiers, not raw MREG payload
        shapes. This method normalizes and validates that list before
        persisting it through the host patch endpoint.
        """
        normalized = _normalize_contacts(contacts)
        return self._replace_contacts(
            hostname,
            normalized,
            correlation_id=correlation_id,
        )

    def unset(
        self,
        hostname: str,
        *,
        force: bool = False,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Clear all explicit contacts from one host.

        Clearing a single contact is treated as a normal operation, but clearing
        more than one in a single call requires ``force``. Wholesale contact
        loss on a multi-owner host is the kind of write that is hard to undo
        and easy to do by accident, so the library makes the caller opt in
        explicitly.
        """
        host = self._queries.get_required(hostname, correlation_id=correlation_id)
        if not host.siteadmins:
            return host
        if not force and len(host.siteadmins) > 1:
            raise ValidationError(
                f"Host {hostname!r} has {len(host.siteadmins)} contacts; force is required",
                source=ValidationSource.LOCAL,
                method=RequestMethod.DELETE,
                endpoint=f"/api/v1/hosts/{hostname}/contacts/",
            )
        self._client.delete_json(
            f"/api/v1/hosts/{hostname}/contacts/",
            correlation_id=correlation_id,
        )
        return self._verify_contact_state(
            hostname,
            operation="unset_host_contacts",
            method=RequestMethod.DELETE,
            endpoint=f"/api/v1/hosts/{hostname}/contacts/",
            correlation_id=correlation_id,
        )

    def add(
        self,
        hostname: str,
        contacts: list[str],
        *,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Merge contacts into the current host contact set.

        The operation is idempotent. Existing contacts keep their relative
        order and duplicates from the input are collapsed before any write is
        sent upstream.
        """
        normalized = _normalize_contacts(contacts)
        host = self._queries.get_required(hostname, correlation_id=correlation_id)
        merged = tuple(dict.fromkeys((*host.siteadmins, *normalized)))
        if merged == host.siteadmins:
            return host
        self._client.post_json(
            f"/api/v1/hosts/{hostname}/contacts/",
            json={"emails": list(normalized)},
            allow_empty=True,
            correlation_id=correlation_id,
        )
        return self._verify_contact_state(
            hostname,
            operation="add_host_contacts",
            method=RequestMethod.POST,
            endpoint=f"/api/v1/hosts/{hostname}/contacts/",
            correlation_id=correlation_id,
        )

    def remove(
        self,
        hostname: str,
        contacts: list[str],
        *,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Remove the supplied contacts from the current host contact set.

        Removing a contact that is already absent is a no-op and returns the
        current host state without issuing an unnecessary upstream patch.
        """
        normalized = set(_normalize_contacts(contacts))
        host = self._queries.get_required(hostname, correlation_id=correlation_id)
        remaining = tuple(contact for contact in host.siteadmins if contact not in normalized)
        if remaining == host.siteadmins:
            return host
        self._client.delete_json(
            f"/api/v1/hosts/{hostname}/contacts/",
            json={"emails": list(normalized)},
            correlation_id=correlation_id,
        )
        return self._verify_contact_state(
            hostname,
            operation="remove_host_contacts",
            method=RequestMethod.DELETE,
            endpoint=f"/api/v1/hosts/{hostname}/contacts/",
            correlation_id=correlation_id,
        )

    def _replace_contacts(
        self,
        hostname: str,
        contacts: tuple[str, ...],
        *,
        correlation_id: str | None,
    ) -> HostRecord:
        """Persist one normalized contact tuple through the host patch endpoint.

        The awkward upstream representation stays local to this helper so the
        public methods can remain list-oriented and explicit.
        """
        payload = {"contacts": list(contacts)}
        data = self._client.patch_json(
            f"/api/v1/hosts/{hostname}",
            json=payload,
            allow_empty=True,
            correlation_id=correlation_id,
        )
        if data is None:
            return self._verify_contact_state(
                hostname,
                operation="set_host_contacts",
                method=RequestMethod.PATCH,
                endpoint=f"/api/v1/hosts/{hostname}",
                correlation_id=correlation_id,
            )
        return self._queries.parse_host_payload(
            data,
            endpoint=f"/api/v1/hosts/{hostname}",
            method=RequestMethod.PATCH,
        )

    def _verify_contact_state(
        self,
        hostname: str,
        *,
        operation: str,
        method: RequestMethod,
        endpoint: str,
        correlation_id: str | None,
    ) -> HostRecord:
        """Verify that a contact mutation still yields a readable host state.

        This helper intentionally stops short of field-by-field contact
        comparison. The current hardening pass only answers the higher-value
        question: after an empty-success write, can the library still confirm
        host state or must it report uncertainty?
        """
        try:
            host = self._queries.get_required(hostname, correlation_id=correlation_id)
        except NotFoundError as exc:
            raise RequestFailedError(
                "Contact mutation returned an empty success response, and "
                "verification did not find the host. Inspect MREG if needed, "
                "but this is treated as a failed mutation rather than an "
                "uncertain partial mutation.",
                method=method,
                status_code=exc.status_code,
                endpoint=endpoint,
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "Contact mutation reached MREG, but verification failed. "
                "Upstream state may be partially updated. Inspect the host "
                "contact state in MREG before deciding whether to retry.",
                operation=operation,
                completed_steps=(MutationStep("contact_request"),),
                remaining_steps=(MutationStep("verify_host_contacts"),),
                method=method,
                status_code=exc.status_code,
                endpoint=endpoint,
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        return host


def _normalize_contacts(contacts: list[str]) -> tuple[str, ...]:
    """Normalize caller-supplied contacts into a stable deduplicated tuple.

    Empty strings and surrounding whitespace are removed, but the function
    still requires at least one usable contact when called. ``unset()`` uses
    its own explicit empty-tuple path instead of going through this helper.
    """
    normalized = tuple(dict.fromkeys(contact.strip() for contact in contacts if contact.strip()))
    if not normalized:
        raise ValidationError(
            "At least one non-empty contact is required",
            source=ValidationSource.LOCAL,
            method=RequestMethod.PATCH,
        )
    return normalized
