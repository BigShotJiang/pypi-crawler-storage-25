"""Stable host models for MREG.

These models are the library's public return shapes for host-domain reads.
They are deliberately I/O-free dataclasses: nothing here calls MREG, and
nothing here decides field semantics on the fly. Endpoint-aware payload
interpretation lives next to the host endpoints in ``queries.py`` and the
mutation modules.

Each record carries a ``raw`` dictionary holding the original upstream
payload for callers that need fields the stable shape does not expose. The
top-level fields are the contract; ``raw`` is an escape hatch and may
change shape upstream without library changes.
"""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from ..enums import AddressFamily


@dataclass(frozen=True, slots=True)
class HostRecord:
    """Stable host shape returned by host queries and mutations.

    Attributes:
        id: Numeric MREG host id when the upstream payload provided one,
            otherwise ``None``. Mutation modules require an id and surface a
            ``ResponseDecodeError`` when it is missing.
        name: Canonical host name as MREG returned it. Use
            ``normalize_hostname_for_compare`` from
            :mod:`osp_uio_integrations.mreg.hosts._shared` for DNS-style
            equality against caller input.
        contact: Comma-joined contact string for callers that need the
            legacy single-string form. Derived from ``siteadmins`` when
            MREG only sent the structured list.
        siteadmins: Stable tuple of contact identifiers in upstream order.
            Empty when the host has no explicit contacts. Treated as the
            authoritative contact list by ``HostContactsAPI``.
        ipaddresses: Deduplicated tuple of canonical IP address strings,
            both IPv4 and IPv6 in discovery order.
        ttl: Explicit per-host TTL when set, otherwise ``None`` (host
            defaults to its zone TTL).
        zone_id: Numeric MREG zone id when the upstream payload provided
            one, otherwise ``None``.
        raw: Original upstream payload dictionary. Escape hatch for
            callers needing fields not promoted to stable attributes.
    """

    id: int | None
    name: str
    contact: str | None
    siteadmins: tuple[str, ...]
    ipaddresses: tuple[str, ...]
    ttl: int | None
    zone_id: int | None
    raw: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        """Return the small dict shape already used by some existing callers.

        The typed dataclass is still the primary contract for the host domain.
        This adapter keeps migration friction low for code that currently
        expects a plain mapping with just the canonical hostname, siteadmins,
        and IP addresses.
        """
        return {
            "hostname": self.name,
            "siteadmins": list(self.siteadmins),
            "ipaddresses": list(self.ipaddresses),
        }


@dataclass(frozen=True, slots=True)
class CnameRecord:
    """Stable CNAME alias shape returned by ``HostCnameAPI``.

    Attributes:
        id: Numeric MREG CNAME id when the upstream payload provided one,
            otherwise ``None``.
        name: Alias label as MREG returned it.
        host_id: Numeric id of the host that owns the alias, when provided.
        raw: Original upstream payload dictionary.
    """

    id: int | None
    name: str
    host_id: int | None
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class AddressRecord:
    """Stable A/AAAA record shape returned by ``HostAddressingAPI``.

    Attributes:
        id: Numeric MREG address id when the upstream payload provided
            one, otherwise ``None``.
        ipaddress: Canonical IPv4 or IPv6 string.
        macaddress: Optional MAC address bound to the upstream address row.
        raw: Original upstream payload dictionary.
    """

    id: int | None
    ipaddress: str
    macaddress: str | None
    raw: dict[str, Any]

    @property
    def family(self) -> AddressFamily:
        """Return the address family derived from the parsed ``ipaddress``.

        The library uses ``ipaddress.ip_address`` so version detection is
        whatever Python decides for the canonical string. Callers do not
        need to keep a separate flag in sync with the address.
        """
        parsed = ipaddress.ip_address(self.ipaddress)
        if parsed.version == 4:
            return AddressFamily.IPV4
        return AddressFamily.IPV6


@dataclass(frozen=True, slots=True)
class AddressMoveResult:
    """Outcome of moving an A/AAAA address (and any PTR override) between hosts.

    The two boolean flags are reported separately so callers can tell when
    only the address row moved, only the PTR override moved, or both. A
    missing PTR override on the source host simply leaves
    ``moved_ptr_override`` as ``False``.

    Attributes:
        ipaddress: Canonical address that was moved.
        moved_ip: Whether the A/AAAA row itself was repointed at the new
            host.
        moved_ptr_override: Whether a PTR override existed and was moved
            with the address.
    """

    ipaddress: str
    moved_ip: bool
    moved_ptr_override: bool


@dataclass(frozen=True, slots=True)
class HostHistoryRecord:
    """Stable host history entry exposed by ``HostHistoryAPI.many``.

    The ``data`` field is normalized into a dictionary so callers can rely
    on one structured shape even when MREG sends a JSON-encoded string on
    the wire. The original payload is still preserved in ``raw``, so
    ``raw["data"]`` may differ in type from ``data``.

    Attributes:
        id: Numeric MREG history row id. Stable enough to deduplicate
            entries across the multi-pass history fan-out.
        timestamp: Timezone-aware moment the history row was recorded.
        user: Identity recorded by MREG as the actor for the change.
        resource: MREG resource group the row belongs to (e.g. ``host``).
        name: Owner name MREG associated with the row.
        model_id: Numeric MREG model id used to drive the second and third
            history fan-out passes (see ``HostHistoryAPI.many``).
        model: MREG model name (e.g. ``Host``).
        action: Action verb recorded by MREG (e.g. ``create``, ``update``).
        data: Structured per-row data dictionary.
        raw: Original upstream payload dictionary.
    """

    id: int
    timestamp: datetime
    user: str
    resource: str
    name: str
    model_id: int
    model: str
    action: str
    data: dict[str, Any]
    raw: dict[str, Any]
