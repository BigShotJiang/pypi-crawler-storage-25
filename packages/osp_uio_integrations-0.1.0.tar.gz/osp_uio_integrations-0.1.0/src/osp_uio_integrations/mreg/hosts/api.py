"""Host-oriented MREG composition root.

This module is the public entrypoint for the host domain. It gathers the
explicit host sub-APIs behind ``client.hosts`` so callers get one coherent
surface without collapsing the implementation back into a giant host module.

The facade wires the sub-APIs together and exposes them as attributes. It does
not re-export per-method shortcuts. Going through ``hosts.queries.get(...)`` or
``hosts.lifecycle.create(...)`` keeps host-domain ownership boundaries visible
at the call site.
"""

from __future__ import annotations

from typing import Any

from .addressing import HostAddressingAPI
from .cnames import HostCnameAPI
from .contacts import HostContactsAPI
from .history import HostHistoryAPI
from .lifecycle import HostLifecycleAPI
from .queries import HostQueries
from .records import HostRecordsAPI


class HostsAPI:
    """Public host facade composed from explicit host sub-APIs.

    The facade exposes the host domain as a small bag of focused sub-APIs.
    Callers reach for the sub-API that owns the operation they want
    (``queries`` for lookups, ``lifecycle`` for create/delete, ``addressing``
    for A/AAAA, and so on) instead of going through forwarded shortcuts.

    Cross-cutting host contracts that callers should know about:

    - library-side absence errors use the method the caller invoked, while the
      endpoint points at the host sub-API boundary that made the decision
    - ``force`` is intentionally domain-specific rather than global:
      addressing uses it for network and ownership guard checks, PTR uses it
      for managed-boundary checks but not cross-host PTR conflicts, NAPTR
      uses it only to allow destructive multi-match deletes, and lifecycle
      uses it to permit wildcard host names
    """

    def __init__(self, client: Any) -> None:
        """Initialize the host facade."""
        self.queries = HostQueries(client)
        self.addressing = HostAddressingAPI(client, self.queries)
        self.contacts = HostContactsAPI(client, self.queries)
        self.cnames = HostCnameAPI(client, self.queries)
        self.history = HostHistoryAPI(client)
        self.lifecycle = HostLifecycleAPI(client, self.queries)
        self.records = HostRecordsAPI(client, self.queries)
